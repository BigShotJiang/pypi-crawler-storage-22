#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : private_messaging.py
# | License  : MIT License © 2026 Chizoba
# | Brief    : Private messaging examples for MC5 API Client
# ────────────────★─────────────────────────────────

"""
Private messaging examples for MC5 API Client.
This script demonstrates private inbox and messaging features.
"""

import sys
import time
from mc5_api_client import MC5Client
from mc5_api_client.exceptions import MC5APIError

def main():
    """Main private messaging demonstration."""
    
    print("💬 MC5 Private Messaging System")
    print("=" * 50)
    
    # Initialize client with your credentials
    try:
        client = MC5Client(
            username="YOUR_USERNAME_HERE",
            password="YOUR_PASSWORD_HERE"
        )
        print("✅ Successfully connected to MC5 API!")
        
    except Exception as e:
        print(f"❌ Failed to connect: {e}")
        return
    
    # Example 1: Send a simple private message
    print(f"\n💬 Sending private message...")
    try:
        result = client.send_private_message(
            credential="anonymous:target_player_credential",
            message="Hey! Want to play some matches together? 🎮"
        )
        print(f"✅ Message sent successfully!")
        print(f"   To: anonymous:target_player_credential")
        print(f"   Message: Hey! Want to play some matches together? 🎮")
        
    except MC5APIError as e:
        print(f"❌ Error sending message: {e}")
    
    # Example 2: Send message with kill signature
    print(f"\n Sending message with kill signature...")
    try:
        result = client.send_private_message(
            credential="anonymous:target_player_credential",
            message="Check out my new kill signature! ",
            kill_sign_color="-974646126",
            kill_sign_name="default_killsig_80"
        )
        print(f" Message with kill signature sent!")
        print(f"   Kill Signature: default_killsig_80")
        print(f"   Kill Color: -974646126")
        print(f"   Message: Check out my new kill signature! ")
        
    except MC5APIError as e:
        print(f" Could not send message with kill signature: {e}")
    
    # Example 3: Send reply message
    print(f"\n Sending reply message...")
    try:
        result = client.send_private_message(
            credential="anonymous:target_player_credential",
            message="Sure! Let's play at 8 PM tonight! ",
            reply_to="message_id_here"  # Replace with actual message ID
        )
        print(f" Reply message sent!")
        print(f"   To: anonymous:target_player_credential")
        print(f"   Message: Sure! Let's play at 8 PM tonight! ")
        print(f"   Reply to: message_id_here")
        
    except MC5APIError as e:
        print(f" Could not send reply message: {e}")

    # Example 4: Send message with alert notification
    print(f"\n Sending message with alert...")
    try:
        result = client.send_private_message(
            credential="anonymous:target_player_credential",
            message=" Important: Clan war at 8 PM! Don't be late! ",
            alert_kairos=True
        )
        print(f" Alert message sent!")
        print(f"   Alert:  Alert notification sent")
        print(f"   Message:  Important: Clan war at 8 PM! Don't be late! ")
        
    except MC5APIError as e:
        print(f" Could not send alert message: {e}")

    # Example 5: Get inbox messages
    print(f"\n Getting inbox messages...")
    try:
        messages = client.get_inbox_messages(limit=10)
        print(f" Found {len(messages)} messages in inbox:")
        
        for i, msg in enumerate(messages[:5], 1):
            print(f"  {i}. From: {msg.get('from', 'Unknown')}")
            print(f"     Preview: {msg.get('body', 'No content')[:50]}...")
            print(f"     Type: {msg.get('type', 'Unknown')}")
            print(f"     Time: {msg.get('timestamp', 'Unknown')}")
            print()
            
    except MC5APIError as e:
        print(f" Could not get inbox messages: {e}")

    # Example 6: Bulk messaging to multiple players
    print(f"\n Sending bulk messages...")
    try:
        target_players = [
            "anonymous:player1_credential",
            "anonymous:player2_credential",
            "anonymous:player3_credential"
        ]
        
        messages = [
            "Hey everyone! Ready for clan war? ",
            "Let's practice together! ",
            "Good luck in the tournament! "
        ]
        
        for i, (credential, message) in enumerate(target_players):
            try:
                result = client.send_private_message(
                    credential=credential,
                    message=message
                )
                print(f" Message {i+1} sent to {credential}")
                time.sleep(1)  # Small delay between messages
            except MC5APIError as e:
                print(f" Failed to send to {credential}: {e}")
        
        print(f" Bulk messaging completed!")
        
    except MC5APIError as e:
        print(f" Could not send bulk messages: {e}")

    # Example 7: Message with rich formatting
    print(f"\n Sending rich formatted message...")
    try:
        formatted_message = """ Squad Invitation

 When: Tonight at 8 PM
 Where: Clan War Server
 What: Practice Match
 Prizes: 5000 XP bonus

 Requirements:
• Level 50+
• Active squad member
• Good teamwork skills
• Voice chat enabled

 Let's dominate together! """
        
        result = client.send_private_message(
            credential="anonymous:target_player_credential",
            message=formatted_message,
            kill_sign_color="-123456789",
            kill_sign_name="default_killsig_95"
        )
        print(f" Formatted message sent!")
        print(f"   Features: Rich formatting, kill signature")
        print(f"   Content:  Squad Invitation with full details")
        
    except MC5APIError as e:
        print(f" Could not send formatted message: {e}")

    # Example 8: Delete inbox message
    print(f"\n Testing message deletion...")
    try:
        # First get a message to delete
        messages = client.get_inbox_messages(limit=1)
        if messages:
            message_id = messages[0].get("id", "Unknown")
            
            print(f"Deleting message: {message_id}")
            result = client.delete_inbox_message(message_id)
            print(f" Message deleted successfully!")
        else:
            print("No messages to delete")
            
    except MC5APIError as e:
        print(f" Could not delete message: {e}")

    # Clean up
    print("\n Cleaning up...")
    try:
        client.close()
        print(" Connection closed successfully!")
        
    except Exception as e:
        print(f" Error closing connection: {e}")

    print("\n Private messaging demonstration complete!")
    print("\n What you learned:")
    print("   Send private messages")
    print("   Include kill signatures")
    print("   Send reply messages")
    print("   Send alert notifications")
    print("   Get inbox messages")
    print("   Delete messages")
    print("\n Use Cases:")
    print("   Direct player communication")
    print("   Squad invitations")
    print("   Important notifications")
    print("   Bulk messaging")
    print("   Rich formatting")
    print("   Message management")

if __name__ == "__main__":
    main()
