#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : quick_help.py
# | License  | MIT License © 2026 Chizoba
# | Brief    : Quick help commands for MC5 API Client
# ────────────────★─────────────────────────────────

"""
MC5 API Client - Quick Help Commands

Simple help system for MC5 API Client users.
"""

def show_help():
    """Display comprehensive help information."""
    print("🎮 MC5 API Client - Help System")
    print("=" * 40)
    print()
    
    print("🚀 QUICK START:")
    print("   pip install mc5_api_client")
    print()
    
    print("🔹 ONE-LINER COMMANDS:")
    print("   quick_search('f55f', 'username', 'password')")
    print("   quick_kick('9gg9', 'username', 'password', 'reason')")
    print()
    
    print("🔹 SIMPLE CLIENT:")
    print("   from mc5_api_client import SimpleMC5Client")
    print("   client = SimpleMC5Client('username', 'password')")
    print("   client.connect()")
    print("   player = client.search_player('f55f')")
    print()
    
    print("🔹 CLAN MANAGEMENT:")
    print("   members = client.get_clan_members()")
    print("   client.kick_member('9gg9', 'inactive')")
    print("   client.update_clan_settings(name='New Name')")
    print()
    
    print("🔹 ADVANCED FEATURES:")
    print("   batch_search_players(['f55f','9gg9'], 'user', 'pass')")
    print("   clan_cleanup('user', 'pass', dry_run=True)")
    print("   monitor_clan_activity('user', 'pass')")
    print()
    
    print("🔹 ERROR HANDLING:")
    print("   try:")
    print("       client.connect()")
    print("   except AuthenticationError:")
    print("       print('Check credentials')")
    print()
    
    print("📚 AVAILABLE EXAMPLES:")
    examples = [
        ('basic_usage.py', 'Core functionality'),
        ('simple_usage.py', 'User-friendly interface'),
        ('advanced_automation.py', 'Loops & automation'),
        ('clan_management.py', 'Clan operations'),
        ('player_stats.py', 'Player statistics'),
        ('private_messaging.py', 'Direct messaging'),
        ('squad_management.py', 'Squad management'),
        ('message_management.py', 'Communication'),
        ('events_and_tasks.py', 'Daily tasks'),
        ('squad_wall_management.py', 'Wall posts'),
        ('advanced_features.py', 'Advanced features'),
        ('clan_management_complete.py', 'Complete clan ops')
    ]
    
    for filename, description in examples:
        print(f"   🔸 {filename} - {description}")
    
    print()
    print("💡 RUN EXAMPLES:")
    print("   python examples/basic_usage.py")
    print("   python examples/simple_usage.py")
    print()
    
    print("🔧 COMMON ISSUES:")
    print("   ❌ 401 Error - Check username/password")
    print("   ❌ 404 Error - Player not found")
    print("   ❌ Connection - Check internet")
    print("   ❌ Permission - Check clan role")
    print()
    
    print("🎯 DOGTAG EXAMPLES:")
    dogtags = [
        ('f55f', '17,015 kills - Good player'),
        ('9gg9', '80 kills - Beginner'),
        ('78d7', '14,648 kills - Skilled'),
        ('218f', '636,223 kills - Elite!')
    ]
    
    for dogtag, description in dogtags:
        print(f"   🔸 {dogtag} - {description}")
    
    print()
    print("✅ SUCCESS TIPS:")
    print("   • Use SimpleMC5Client for easy operations")
    print("   • Auto-clan detection works automatically")
    print("   • Use dry_run=True for safe testing")
    print("   • Handle errors with try/except blocks")
    print("   • Check examples folder for more ideas")
    print()
    
    print("🚀 READY TO USE!")
    print("   pip install mc5_api_client==1.0.8")


def show_cheat_sheet():
    """Show quick reference cheat sheet."""
    print("🎯 MC5 API Client - Cheat Sheet")
    print("=" * 35)
    print()
    
    print("📦 INSTALL:")
    print("   pip install mc5_api_client")
    print()
    
    print("🔹 QUICK SEARCH:")
    print("   from mc5_api_client import quick_search")
    print("   player = quick_search('f55f', 'user', 'pass')")
    print()
    
    print("🔹 SIMPLE CLIENT:")
    print("   client = SimpleMC5Client('user', 'pass')")
    print("   client.connect()")
    print("   player = client.search_player('f55f')")
    print()
    
    print("🔹 CLAN OPS:")
    print("   members = client.get_clan_members()")
    print("   client.kick_member('9gg9', 'inactive')")
    print()
    
    print("🔹 BATCH SEARCH:")
    print("   from mc5_api_client.simple_client import batch_search_players")
    print("   results = batch_search_players(['f55f','9gg9'], 'user', 'pass')")
    print()
    
    print("🔹 SMART CLEANUP:")
    print("   from mc5_api_client.simple_client import clan_cleanup")
    print("   results = clan_cleanup('user', 'pass', dry_run=True)")
    print()
    
    print("🔹 ERROR HANDLING:")
    print("   try:")
    print("       # your code")
    print("   except AuthenticationError:")
    print("       print('Auth failed')")
    print("   except MC5APIError as e:")
    print("       print(f'Error: {e}')")


def show_examples():
    """Show available example files with descriptions."""
    print("📚 MC5 API Client - Example Files")
    print("=" * 40)
    print()
    
    examples = {
        'basic_usage.py': 'Core functionality and basic operations',
        'simple_usage.py': 'User-friendly interface examples',
        'advanced_automation.py': 'Loops, conditionals, and automation',
        'clan_management.py': 'Complete clan management examples',
        'player_stats.py': 'Player statistics and dogtag search',
        'private_messaging.py': 'Direct messaging features',
        'squad_management.py': 'Squad and group management',
        'message_management.py': 'Communication features',
        'events_and_tasks.py': 'Daily tasks and events',
        'squad_wall_management.py': 'Wall post management',
        'advanced_features.py': 'Advanced capabilities',
        'clan_management_complete.py': 'Comprehensive clan operations'
    }
    
    for filename, description in examples.items():
        print(f"🔸 {filename}")
        print(f"   {description}")
        print()
    
    print("💡 Usage: python examples/filename.py")


def show_troubleshooting():
    """Show troubleshooting guide."""
    print("🔧 MC5 API Client - Troubleshooting")
    print("=" * 40)
    print()
    
    issues = [
        {
            'error': '401 Authentication Error',
            'cause': 'Invalid username or password',
            'solution': 'Check your MC5 credentials'
        },
        {
            'error': '404 Player Not Found',
            'cause': 'Invalid dogtag or player doesn\'t exist',
            'solution': 'Verify dogtag is correct (4-8 characters)'
        },
        {
            'error': 'Connection Failed',
            'cause': 'Network issues or server down',
            'solution': 'Check internet connection and try again'
        },
        {
            'error': 'Permission Denied',
            'cause': 'Insufficient clan permissions',
            'solution': 'Ensure you have admin/leader role'
        },
        {
            'error': 'Token Expired',
            'cause': 'Access token expired',
            'solution': 'Reconnect to get new token'
        }
    ]
    
    for i, issue in enumerate(issues, 1):
        print(f"{i}. ❌ {issue['error']}")
        print(f"   Cause: {issue['cause']}")
        print(f"   Solution: {issue['solution']}")
        print()
    
    print("💡 GENERAL TIPS:")
    print("   • Always use try/except blocks")
    print("   • Test with dry_run=True first")
    print("   • Check examples for working code")
    print("   • Verify MC5 credentials are correct")


if __name__ == "__main__":
    print("🎮 MC5 API Client - Help System")
    print("=" * 35)
    print()
    print("Available commands:")
    print("   show_help()        - Complete help guide")
    print("   show_cheat_sheet() - Quick reference")
    print("   show_examples()    - List example files")
    print("   show_troubleshooting() - Common issues")
    print()
    print("🚀 Try: show_help() for complete guide")
