#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : quick_reference.py
# | License  | MIT License © 2026 Chizoba
# | Brief    | Quick reference for MC5 API Client
# ────────────────★─────────────────────────────────

"""
MC5 API Client - Quick Reference
================================

Copy and paste these examples for quick use!
"""

# ===== BASIC SETUP =====
from mc5_api_client import SimpleMC5Client, quick_update_player_score

# Connect to MC5
client = SimpleMC5Client('YOUR_USERNAME', 'YOUR_PASSWORD')
client.connect()

# ===== EVERYDAY TASKS =====

# Check your profile
profile = client.client.get_profile()
print(f"Level: {profile['level']}, Score: {profile['score']}")

# Search for player
player = client.search_player('f55f')
print(f"Kills: {player['kills']:,}")

# Get clan members
members = client.get_clan_members()
print(f"Clan has {len(members)} members")

# Send message
client.send_message('f55f', 'Want to play together?')

# ===== ADMIN FUNCTIONS =====

# Update player score (adds rating to squad)
result = quick_update_player_score(
    target_user_id="anonymous:PLAYER_CREDENTIAL",
    score=5200,
    xp=2037745,
    killsig_color="-974646126",
    killsig_id="default_killsig_80"
)

if result.get('success'):
    print(f"✅ Score updated: {result['score_updated']}")

# ===== MESSAGE MANAGEMENT =====

# Get inbox messages
messages = client.get_inbox_messages()
print(f"Found {len(messages)} messages")

# Delete message
client.delete_message('MESSAGE_ID_HERE')

# Clear inbox
client.clear_inbox()

# ===== CLAN REQUESTS =====

# Get clan requests
requests = client.get_clan_requests()
print(f"Found {len(requests)} requests")

# Accept request
client.respond_to_clan_request('REQUEST_ID', 'accept', 'Welcome!')

# Reject request
client.respond_to_clan_request('REQUEST_ID', 'reject', 'Sorry, full.')

# ===== ENCRYPTED TOKENS =====

from mc5_api_client import quick_generate_encrypted_token

# Generate encrypted token
encrypted = quick_generate_encrypted_token(
    username="anonymous:CREDENTIAL",
    password="PASSWORD"
)
print(f"Encrypted token: {encrypted['encrypted_token']}")

# Encrypt existing token
from mc5_api_client import quick_encrypt_token
encrypted = quick_encrypt_token("RAW_TOKEN_HERE")

# ===== BATCH OPERATIONS =====

# Search multiple players
dogtags = ['f55f', '9gg9', '78d7']
for dogtag in dogtags:
    player = client.search_player(dogtag)
    if player:
        print(f"{dogtag}: {player['kills']:,} kills")

# Clean up inactive members
from mc5_api_client.simple_client import clan_cleanup
results = clan_cleanup('USERNAME', 'PASSWORD', inactive_days=30)
print(f"Would kick: {results['would_kick']} members")

# ===== ERROR HANDLING =====

try:
    player = client.search_player('INVALID_TAG')
except Exception as e:
    print(f"Error: {e}")

# Use with statement (auto-cleanup)
with SimpleMC5Client('USERNAME', 'PASSWORD') as client:
    client.connect()
    player = client.search_player('f55f')
    # Connection automatically closes

# ===== COMMON DOGTAGS =====

# Elite players
elite_dogtags = ['f55f', '218f', '9gg9', '78d7']
for dogtag in elite_dogtags:
    player = client.search_player(dogtag)
    if player and player.get('kills', 0) > 10000:
        print(f"🌟 Elite: {dogtag} - {player['kills']:,} kills")

# ===== HELPFUL PRINT FORMATS =====

# Format large numbers
score = 1234567
print(f"Score: {score:,}")  # Score: 1,234,567

# Format currency
credits = 5000
print(f"Credits: {credits:,}")  # Credits: 5,000

# ===== QUICK ONE-LINERS =====

# Quick player search
from mc5_api_client import quick_search
player = quick_search('f55f', 'USERNAME', 'PASSWORD')

# Quick clan cleanup
from mc5_api_client import clan_cleanup
clan_cleanup('USERNAME', 'PASSWORD', inactive_days=30, dry_run=True)

# ===== USEFUL CONSTANTS =====

# Admin credentials
ADMIN_USERNAME = "game:mc5_system"
ADMIN_PASSWORD = "admin"

# Common scores
RATING_5200 = 5200
RATING_10000 = 10000

# Common XP values
XP_HIGH = 2037745
XP_MEDIUM = 1000000

# Kill signature colors
COLOR_WHITE = "16777215"
COLOR_RED = "-974646126"

# ===== TIPS =====

# 1. Always check if operations succeeded
if result.get('success'):
    print("✅ Success!")
else:
    print(f"❌ Error: {result.get('error')}")

# 2. Use descriptive variable names
player_dogtag = "f55f"
player_score = 5200

# 3. Add delays between operations
import time
time.sleep(1)  # Wait 1 second

# 4. Handle empty results
if members:
    print(f"Found {len(members)} members")
else:
    print("No members found")

print("🎮 MC5 Quick Reference - Ready to use!")
