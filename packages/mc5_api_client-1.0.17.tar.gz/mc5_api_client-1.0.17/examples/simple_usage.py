#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : simple_usage.py
# | License  | MIT License © 2026 Chizoba
# | Brief    : Simple usage examples for non-developers
# ────────────────★─────────────────────────────────

"""
MC5 API Client - Simple Usage Examples

These examples show how to use the simplified MC5 API client
designed for non-developers.
"""

from mc5_api_client.simple_client import SimpleMC5Client, quick_search, quick_kick

# Your MC5 credentials
USERNAME = "YOUR_USERNAME_HERE"
PASSWORD = "YOUR_PASSWORD_HERE"

def example_1_basic_search():
    """Example 1: Search for a player by dogtag"""
    print("🔍 Example 1: Search for a player")
    print("=" * 40)
    
    with SimpleMC5Client(USERNAME, PASSWORD) as client:
        if client.connect():
            # Search for a player
            player = client.search_player("f55f")
            
            if player:
                print(f"✅ Player Found!")
                print(f"   Dogtag: {player['dogtag']}")
                print(f"   Rating: {player['rating']}")
                print(f"   Kills: {player['kills']:,}")
                print(f"   K/D Ratio: {player['kd_ratio']:.2f}")
                print(f"   Headshot %: {player['headshot_percent']:.1f}%")
            else:
                print("❌ Player not found")

def example_2_clan_management():
    """Example 2: Get clan members and manage clan"""
    print("\n🏰 Example 2: Clan Management")
    print("=" * 40)
    
    with SimpleMC5Client(USERNAME, PASSWORD) as client:
        if client.connect():
            # Get your stats
            my_stats = client.get_my_stats()
            if my_stats:
                print(f"👤 Your Profile:")
                print(f"   Name: {my_stats['name']}")
                print(f"   Level: {my_stats['level']}")
                print(f"   XP: {my_stats['xp']:,}")
                print(f"   Clan: {my_stats['clan']}")
            
            # Get clan members
            members = client.get_clan_members()
            print(f"\n👥 Clan Members ({len(members)} total):")
            
            for i, member in enumerate(members[:5], 1):  # Show first 5
                status = "🟢 Online" if member['online'] else "🔴 Offline"
                print(f"   {i}. {member['name']} - Level {member['level']} - {status}")
            
            if len(members) > 5:
                print(f"   ... and {len(members) - 5} more members")

def example_3_kick_member():
    """Example 3: Kick a member by dogtag"""
    print("\n🔨 Example 3: Kick Member")
    print("=" * 40)
    
    with SimpleMC5Client(USERNAME, PASSWORD) as client:
        if client.connect():
            # Kick a member (replace with actual dogtag)
            success = client.kick_member("9gg9", "Inactive for 30 days")
            
            if success:
                print("✅ Member kicked successfully")
            else:
                print("❌ Failed to kick member")

def example_4_update_clan():
    """Example 4: Update clan settings"""
    print("\n⚙️ Example 4: Update Clan Settings")
    print("=" * 40)
    
    with SimpleMC5Client(USERNAME, PASSWORD) as client:
        if client.connect():
            # Update clan name and description
            success = client.update_clan_settings(
                name="Elite Squad 2026",
                description="Best clan in MC5! Join us!",
                member_limit=50
            )
            
            if success:
                print("✅ Clan settings updated")
            else:
                print("❌ Failed to update settings")

def example_5_send_message():
    """Example 5: Send private message"""
    print("\n💬 Example 5: Send Private Message")
    print("=" * 40)
    
    with SimpleMC5Client(USERNAME, PASSWORD) as client:
        if client.connect():
            # Send message to a player
            success = client.send_message("f55f", "Hey! Want to play together?")
            
            if success:
                print("✅ Message sent successfully")
            else:
                print("❌ Failed to send message")

def example_6_quick_functions():
    """Example 6: Quick one-liner functions"""
    print("\n⚡ Example 6: Quick Functions")
    print("=" * 40)
    
    # Quick search (one line)
    player = quick_search("218f", USERNAME, PASSWORD)
    if player:
        print(f"✅ Found: {player['kills']:,} kills")
    
    # Quick kick (one line)
    # success = quick_kick("9gg9", USERNAME, PASSWORD, "Rule violation")
    # print(f"Kick result: {success}")

def example_7_advanced_automation():
    """Example 7: Advanced automation with loops and conditionals"""
    print("\n🤖 Example 7: Advanced Automation")
    print("=" * 40)
    
    from mc5_api_client.simple_client import batch_search_players, clan_cleanup
    
    # Batch search multiple players
    dogtags = ["f55f", "9gg9", "78d7", "218f"]
    print(f"Searching for {len(dogtags)} players...")
    
    results = batch_search_players(dogtags, USERNAME, PASSWORD)
    
    # Conditional processing of results
    if results['found']:
        print(f"\n✅ Found {len(results['found'])} players:")
        for player in results['found']:
            kills = player['kills']
            if kills > 10000:
                print(f"   🌟 {player['dogtag']}: {kills:,} kills (ELITE!)")
            elif kills > 1000:
                print(f"   ⭐ {player['dogtag']}: {kills:,} kills (Skilled)")
            else:
                print(f"   👤 {player['dogtag']}: {kills:,} kills")
    
    # Smart clan cleanup
    print("\n🧹 Running intelligent clan cleanup...")
    cleanup_results = clan_cleanup(
        USERNAME, PASSWORD,
        inactive_days=30,
        min_level=15,
        dry_run=True
    )
    
    print(f"Total members: {cleanup_results['total_members']}")
    print(f"Would kick: {cleanup_results['would_kick']}")
    print(f"Protected: {cleanup_results['protected']}")
    
    if cleanup_results['would_kick'] > 0:
        print("⚠️ Consider removing inactive members")
    else:
        print("✅ Clan looks healthy!")

def main():
    """Run all examples"""
    print("🎮 MC5 API Client - Simple Usage Examples")
    print("=" * 50)
    print("📝 Replace YOUR_USERNAME_HERE and YOUR_PASSWORD_HERE with your actual MC5 credentials")
    print()
    
    # Run examples (comment out ones you don't want to run)
    
    try:
        example_1_basic_search()
        example_2_clan_management()
        # example_3_kick_member()  # Uncomment to test kicking
        # example_4_update_clan()  # Uncomment to test clan updates
        # example_5_send_message()  # Uncomment to test messaging
        example_6_quick_functions()
        example_7_advanced_automation()
        
    except Exception as e:
        print(f"❌ Error running examples: {e}")
        print("💡 Make sure you've entered your correct MC5 credentials")

if __name__ == "__main__":
    main()
