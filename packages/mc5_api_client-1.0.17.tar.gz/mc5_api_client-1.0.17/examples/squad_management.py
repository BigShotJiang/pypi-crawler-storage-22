#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : squad_management.py
# | License  : MIT License © 2026 Chizoba
# | Brief    : Squad/Group management examples for MC5 API Client
# ────────────────★─────────────────────────────────

"""
Squad/Group management examples for MC5 API Client.
This script demonstrates the powerful squad management features.
"""

import sys
import time
from mc5_api_client import MC5Client
from mc5_api_client.exceptions import MC5APIError

def main():
    """Main squad management demonstration."""
    
    print("👥 MC5 Squad/Group Management System")
    print("=" * 50)
    
    # Initialize client with your credentials
    try:
        client = MC5Client(
            username="YOUR_USERNAME_HERE",
            password="YOUR_PASSWORD_HERE"
        )
        print("✅ Successfully connected to MC5 API!")
        
    except Exception as e:
        print(f"❌ Failed to connect: {e}")
        return
    
    # Example 1: Get squad members
    group_id = "2c21d608-0077-11f1-8220-b8ca3a7095d0"  # Your squad ID
    print(f"\n👥 Getting squad members for group: {group_id}")
    try:
        members = client.get_group_members(group_id)
        print(f"✅ Found {len(members)} squad members:")
        
        for i, member in enumerate(members, 1):
            print(f"  {i}. {member.get('name', 'Unknown')} ({member.get('credential', 'Unknown')})")
            print(f"     🎮 Status: {'🟢 Online' if member.get('online') else '🔴 Offline'}")
            print(f"     🏆 Score: {member.get('_score', 'Unknown')}")
            print(f"     ⭐ XP: {member.get('_xp', 'Unknown')}")
            print(f"     🎯 Kill Sign: {member.get('_killsig_id', 'Unknown')}")
            print(f"     🎨 Kill Color: {member.get('_killsig_color', 'Unknown')}")
            print()
            
    except MC5APIError as e:
        print(f"❌ Error getting squad members: {e}")
    
    # Example 2: Update member score
    print("🏆 Updating member score...")
    try:
        credential = "YOUR_USERNAME_HERE"
        new_score = 1500
        
        result = client.update_member_score(group_id, credential, new_score)
        print(f"✅ Score updated to {new_score} for {credential}")
        
    except MC5APIError as e:
        print(f"⚠️ Could not update score: {e}")
    
    # Example 3: Update member XP
    print("⭐ Updating member XP...")
    try:
        new_xp = 2100000
        
        result = client.update_member_xp(group_id, credential, new_xp)
        print(f"✅ XP updated to {new_xp} for {credential}")
        
    except MC5APIError as e:
        print(f"⚠️ Could not update XP: {e}")
    
    # Example 4: Update kill signature
    print("🎯 Updating kill signature...")
    try:
        killsig_id = "default_killsig_90"
        killsig_color = "-123456789"
        
        result = client.update_member_killsig(group_id, credential, killsig_id, killsig_color)
        print(f"✅ Kill signature updated:")
        print(f"   ID: {killsig_id}")
        print(f"   Color: {killsig_color}")
        
    except MC5APIError as e:
        print(f"⚠️ Could not update kill signature: {e}")
    
    # Example 5: Bulk update multiple stats
    print("🔄 Bulk updating member stats...")
    try:
        result = client.update_group_member_stats(
            group_id, 
            credential,
            _score="2000",
            _xp="2500000",
            _killsig_id="default_killsig_100",
            _killsig_color="-987654321"
        )
        print("✅ Bulk stats update completed!")
        
    except MC5APIError as e:
        print(f"⚠️ Could not bulk update stats: {e}")
    
    # Example 6: Get specific member info
    print(f"\n🔍 Getting specific member info for {credential}...")
    try:
        member_info = client.get_member_by_credential(group_id, credential)
        if member_info:
            print(f"✅ Found member: {member_info.get('name', 'Unknown')}")
            print(f"   🏆 Score: {member_info.get('_score', 'Unknown')}")
            print(f"   ⭐ XP: {member_info.get('_xp', 'Unknown')}")
            print(f"   🎮 Online: {'Yes' if member_info.get('online') else 'No'}")
        else:
            print("❌ Member not found")
            
    except MC5APIError as e:
        print(f"❌ Error getting member info: {e}")
    
    # Example 7: Get online members only
    print("\n🟢 Getting online members only...")
    try:
        online_members = client.get_online_members(group_id)
        print(f"✅ Found {len(online_members)} online members:")
        
        for member in online_members:
            print(f"  - {member.get('name', 'Unknown')} (Score: {member.get('_score', 'Unknown')})")
            
    except MC5APIError as e:
        print(f"❌ Error getting online members: {e}")
    
    # Example 8: Get squad statistics
    print("\n📊 Getting squad statistics...")
    try:
        stats = client.get_group_statistics(group_id)
        print("📈 Squad Statistics:")
        print(f"   👥 Total Members: {stats.get('total_members', 0)}")
        print(f"   🟢 Online Members: {stats.get('online_members', 0)}")
        print(f"   🔴 Offline Members: {stats.get('offline_members', 0)}")
        print(f"   🏆 Total Score: {stats.get('total_score', 0)}")
        print(f"   📊 Average Score: {stats.get('average_score', 0):.1f}")
        print(f"   ⭐ Total XP: {stats.get('total_xp', 0)}")
        print(f"   📈 Average XP: {stats.get('average_xp', 0):.1f}")
        
    except MC5APIError as e:
        print(f"❌ Error getting squad statistics: {e}")
    
    # Example 9: Monitor squad activity
    print("\n👀 Monitoring squad activity (checking every 2 seconds)...")
    try:
        for i in range(3):  # Check 3 times
            print(f"\n--- Check {i+1} ---")
            online_count = len(client.get_online_members(group_id))
            stats = client.get_group_statistics(group_id)
            
            print(f"🟢 Online: {online_count}/{stats.get('total_members', 0)}")
            print(f"🏆 Top Score: {max([int(m.get('_score', 0)) for m in client.get_group_members(group_id)])}")
            
            if i < 2:  # Don't sleep after last check
                time.sleep(2)
                
    except MC5APIError as e:
        print(f"❌ Error monitoring activity: {e}")
    
    # Example 10: Squad leaderboard
    print("\n🏅 Creating squad leaderboard...")
    try:
        members = client.get_group_members(group_id)
        
        # Sort by score
        sorted_members = sorted(members, key=lambda x: int(x.get('_score', 0)), reverse=True)
        
        print("🏆 Squad Leaderboard:")
        for i, member in enumerate(sorted_members[:10], 1):  # Top 10
            name = member.get('name', 'Unknown')
            score = member.get('_score', '0')
            online = "🟢" if member.get('online') else "🔴"
            print(f"  {i:2d}. {online} {name:<20} Score: {score}")
            
    except MC5APIError as e:
        print(f"❌ Error creating leaderboard: {e}")
    
    # Clean up
    print("\n🧹 Cleaning up...")
    try:
        client.close()
        print("✅ Connection closed successfully!")
        
    except Exception as e:
        print(f"⚠️ Error closing connection: {e}")
    
    print("\n🎉 Squad management demonstration complete!")
    print("\n📚 What you learned:")
    print("   👥 Get squad members")
    print("   🏆 Update member scores")
    print("   ⭐ Update member XP")
    print("   🎯 Update kill signatures")
    print("   🔄 Bulk update stats")
    print("   🔍 Find specific members")
    print("   🟢 Get online members")
    print("   📊 Calculate squad statistics")
    print("   👀 Monitor squad activity")
    print("   🏅 Create leaderboards")
    
    print("\n🎮 Use Cases:")
    print("   📊 Squad performance tracking")
    print("   🏆 Custom leaderboards")
    print("   👥 Member activity monitoring")
    print("   🎨 Kill signature management")
    print("   📈 Progress tracking")
    print("   🎮 Squad management bots")

if __name__ == "__main__":
    main()
