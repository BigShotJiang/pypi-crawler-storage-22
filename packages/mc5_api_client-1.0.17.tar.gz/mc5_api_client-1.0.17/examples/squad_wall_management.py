#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : squad_wall_management.py
# | License  : MIT License © 2026 Chizoba
# | Brief    : Squad wall management examples for MC5 API Client
# ────────────────★─────────────────────────────────

"""
Squad wall management examples for MC5 API Client.
This script demonstrates squad wall posting and management features.
"""

import sys
import time
import json
from mc5_api_client import MC5Client
from mc5_api_client.exceptions import MC5APIError

def main():
    """Main squad wall demonstration."""
    
    print("💬 MC5 Squad Wall Management System")
    print("=" * 50)
    
    # Initialize client with your credentials
    try:
        client = MC5Client(
            username="YOUR_USERNAME_HERE",
            password="YOUR_PASSWORD_HERE"
        )
        print("✅ Successfully connected to MC5 API!")
        
    except Exception as e:
        print(f"❌ Failed to connect: {e}")
        return
    
    group_id = "2c21d608-0077-11f1-8220-b8ca3a7095d0"  # Your squad ID
    
    # Example 1: Send a simple squad wall message
    print(f"\n💬 Sending squad wall message...")
    try:
        result = client.send_squad_wall_message(
            group_id=group_id,
            message="Hello All! This is a test message from the MC5 API Client! 🎮"
        )
        message_id = result.get("id", "Unknown")
        print(f"✅ Message sent successfully!")
        print(f"   Message ID: {message_id}")
        print(f"   Content: Hello All! This is a test message from the MC5 API Client! 🎮")
        
    except MC5APIError as e:
        print(f"❌ Error sending message: {e}")
    
    # Example 2: Send message with kill signature
    print(f"\n🎯 Sending message with kill signature...")
    try:
        result = client.send_squad_wall_message(
            group_id=group_id,
            message="Check out my new kill signature! 🔥",
            player_killsig="default_killsig_90",
            player_killsig_color="-123456789"
        )
        message_id = result.get("id", "Unknown")
        print(f"✅ Message with kill signature sent!")
        print(f"   Message ID: {message_id}")
        print(f"   Kill Signature: default_killsig_90")
        print(f"   Kill Color: -123456789")
        
    except MC5APIError as e:
        print(f"⚠️ Could not send message with kill signature: {e}")
    
    # Example 3: Send announcement message
    print(f"\n📢 Sending announcement message...")
    try:
        result = client.send_squad_wall_message(
            group_id=group_id,
            message="🏆 Squad Announcement: Great match today everyone! Keep up the good work! 💪",
            msg_type=0,
            language="en",
            activity_type="user_post"
        )
        message_id = result.get("id", "Unknown")
        print(f"✅ Announcement sent!")
        print(f"   Message ID: {message_id}")
        print(f"   Type: user_post")
        print(f"   Language: en")
        
    except MC5APIError as e:
        print(f"⚠️ Could not send announcement: {e}")
    
    # Example 4: Send squad statistics message
    print(f"\n📊 Sending squad statistics message...")
    try:
        # Get current squad stats
        stats = client.get_group_statistics(group_id)
        
        stats_message = f"""📊 Squad Statistics Update:
👥 Total Members: {stats.get('total_members', 0)}
🟢 Online Now: {stats.get('online_members', 0)}
🏆 Total Score: {stats.get('total_score', 0):,}
📊 Average Score: {stats.get('average_score', 0):.1f}
⭐ Total XP: {stats.get('total_xp', 0):,}
📈 Average XP: {stats.get('average_xp', 0):.1f}

Keep up the great work squad! 🎮"""
        
        result = client.send_squad_wall_message(
            group_id=group_id,
            message=stats_message,
            player_killsig="default_killsig_100",
            player_killsig_color="-987654321"
        )
        message_id = result.get("id", "Unknown")
        print(f"✅ Statistics message sent!")
        print(f"   Message ID: {message_id}")
        print(f"   Stats included: Members, Online, Score, XP")
        
    except MC5APIError as e:
        print(f"⚠️ Could not send statistics message: {e}")
    
    # Example 5: Send welcome message to new member
    print(f"\n👋 Sending welcome message...")
    try:
        welcome_message = """🎉 Welcome to the squad! 

We're excited to have you join us! Here's what you need to know:
🎮 Be active and participate in squad activities
💪 Help us climb the leaderboards
🤝 Support your squad mates
🏆 Represent our squad with pride

If you have any questions, feel free to ask! Let's dominate together! 🔥"""
        
        result = client.send_squad_wall_message(
            group_id=group_id,
            message=welcome_message,
            player_killsig="default_killsig_80",
            player_killsig_color="-974646126"
        )
        message_id = result.get("id", "Unknown")
        print(f"✅ Welcome message sent!")
        print(f"   Message ID: {message_id}")
        print(f"   Content: Comprehensive welcome message")
        
    except MC5APIError as e:
        print(f"⚠️ Could not send welcome message: {e}")
    
    # Example 6: Send motivational message
    print(f"\n💪 Sending motivational message...")
    try:
        motivational_quotes = [
            "💪 Champions train, losers complain! Let's get better today!",
            "🔥 The only easy day was yesterday! Let's dominate!",
            "🏆 Success is the sum of small efforts repeated day in and day out!",
            "🎮 Leave it all on the battlefield! No regrets!",
            "⭐ Be the reason your squad wins today!"
        ]
        
        import random
        quote = random.choice(motivational_quotes)
        
        result = client.send_squad_wall_message(
            group_id=group_id,
            message=quote,
            player_killsig="default_killsig_95",
            player_killsig_color="-555555555"
        )
        message_id = result.get("id", "Unknown")
        print(f"✅ Motivational message sent!")
        print(f"   Message ID: {message_id}")
        print(f"   Quote: {quote}")
        
    except MC5APIError as e:
        print(f"⚠️ Could not send motivational message: {e}")
    
    # Example 7: Send event reminder
    print(f"\n📅 Sending event reminder...")
    try:
        event_message = """📅 Event Reminder Squad!

🎯 Daily Tasks: Don't forget to complete your daily tasks for rewards!
🏆 Clan Wars: Be ready for tonight's clan war at 8 PM!
⭐ Double XP: Weekend double XP event starts tomorrow!
🎮 Tournament: Squad tournament this Sunday - sign up now!

Let's show everyone what our squad is made of! 🔥"""
        
        result = client.send_squad_wall_message(
            group_id=group_id,
            message=event_message,
            activity_type="user_post"
        )
        message_id = result.get("id", "Unknown")
        print(f"✅ Event reminder sent!")
        print(f"   Message ID: {message_id}")
        print(f"   Events: Daily tasks, Clan wars, Double XP, Tournament")
        
    except MC5APIError as e:
        print(f"⚠️ Could not send event reminder: {e}")
    
    # Example 8: Try to get squad wall messages (if API supports it)
    print(f"\n📋 Getting squad wall messages...")
    try:
        messages = client.get_squad_wall_messages(group_id, limit=5)
        print(f"✅ Retrieved {len(messages)} recent messages:")
        
        for i, msg in enumerate(messages, 1):
            print(f"  {i}. Message ID: {msg.get('id', 'Unknown')}")
            print(f"     Content: {msg.get('content', 'No content')[:50]}...")
            print(f"     Author: {msg.get('author', 'Unknown')}")
            print(f"     Time: {msg.get('timestamp', 'Unknown')}")
            print()
            
    except MC5APIError as e:
        print(f"⚠️ Could not retrieve wall messages: {e}")
    
    # Example 9: Demonstrate message formatting
    print(f"\n🎨 Demonstrating message formatting...")
    try:
        formatted_message = """🎮 Squad Update 🎮

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📊 Current Squad Performance:
   • Top Scorer: Player123 with 5,420 points
   • Most Active: Player456 with 47 matches
   • Rising Star: Player789 (+250 XP today)

🏆 This Week's Achievements:
   ✅ 15 squad wins
   ✅ 3 new personal bests
   ✅ 2 members reached level 100

🎯 Next Goals:
   • Break top 100 in global rankings
   • Win 20 squad matches this week
   • Recruit 5 active members

Let's make it happen squad! 💪
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"""
        
        result = client.send_squad_wall_message(
            group_id=group_id,
            message=formatted_message,
            player_killsig="default_killsig_88",
            player_killsig_color="-777777777"
        )
        message_id = result.get("id", "Unknown")
        print(f"✅ Formatted message sent!")
        print(f"   Message ID: {message_id}")
        print(f"   Features: Performance stats, achievements, goals")
        
    except MC5APIError as e:
        print(f"⚠️ Could not send formatted message: {e}")
    
    # Clean up
    print("\n🧹 Cleaning up...")
    try:
        client.close()
        print("✅ Connection closed successfully!")
        
    except Exception as e:
        print(f"⚠️ Error closing connection: {e}")
    
    print("\n🎉 Squad wall management demonstration complete!")
    print("\n📚 What you learned:")
    print("   💬 Send squad wall messages")
    print("   🎯 Add kill signatures to messages")
    print("   📢 Send announcements")
    print("   📊 Share squad statistics")
    print("   👋 Welcome new members")
    print("   💪 Send motivational messages")
    print("   📅 Send event reminders")
    print("   🎨 Format messages beautifully")
    print("   📋 Retrieve wall messages")
    
    print("\n🎮 Use Cases:")
    print("   📢 Squad announcements")
    print("   🏆 Achievement celebrations")
    print("   📊 Performance updates")
    print("   🎉 Event reminders")
    print("   💪 Motivational posts")
    print("   👋 Member onboarding")
    print("   🎨 Rich formatting")
    print("   🤖 Automated posting")
    
    print("\n🔧 Message Features:")
    print("   ✅ JSON message formatting")
    print("   🎯 Kill signature integration")
    print("   🌐 Multi-language support")
    print("   📝 Different message types")
    print("   🎨 Rich text formatting")
    print("   📊 Statistics integration")

if __name__ == "__main__":
    main()
