# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : __init__.py
# | License  : MIT License © 2026 Chizoba
# | Brief    : Modern Combat 5 API Client Package
# ────────────────★─────────────────────────────────

"""
Modern Combat 5 API Client

A comprehensive Python library for interacting with the Modern Combat 5 API.
Provides easy access to authentication, profile management, clan operations,
messaging, and more.
"""

from typing import Optional, Dict, Any

__version__ = "1.0.16"
__author__ = "Chizoba"
__email__ = "chizoba2026@hotmail.com"
__license__ = "MIT"

from .telemetry import telemetry, report_error, report_usage, is_telemetry_enabled
from .debug import debug_mode, debug_print, debug_function, analyze_error, print_error_analysis
from .platform import Platform, get_platform_config, get_android_anonymous_credential, get_pc_anonymous_credential
from .squad_battle import SquadBattleMixin
from .transfer_quick import (
    quick_generate_transfer_code,
    quick_check_transfer_status,
    quick_get_device_linking_guide,
    quick_link_device_workflow,
    quick_validate_transfer_code,
    quick_force_new_code,
    quick_transfer_status_summary
)
from .account_quick import (
    quick_get_account_info,
    quick_get_device_history,
    quick_get_credential_summary,
    quick_analyze_account_security,
    quick_get_account_overview,
    quick_export_account_data
)
from .alerts_quick import (
    quick_start_alert_stream,
    quick_test_alert_connection,
    quick_start_alerts_with_discord,
    quick_monitor_alerts,
    create_alert_callback
)
from .federation_quick import (
    quick_get_active_sessions,
    quick_get_my_sessions,
    quick_get_session_statistics,
    quick_check_session_status,
    quick_get_server_type_sessions,
    quick_analyze_session_activity
)
from .squad_battle_quick import (
    quick_create_squad_battle_room,
    quick_post_squad_battle_result,
    quick_get_squad_battle_history,
    quick_analyze_squad_performance,
    quick_get_squad_wall_messages,
    quick_send_squad_battle_notification,
    quick_post_squad_wall_message
)
from .simple_client import (
    SimpleMC5Client,
    batch_search_players,
    clan_cleanup,
    monitor_clan_activity,
    quick_search,
    quick_kick,
    quick_remove_friend,
    quick_send_friend_request,
    quick_check_friend_status,
    quick_accept_friend_request,
    quick_sign_up_for_event,
    quick_get_event_leaderboard,
    quick_get_my_event_rank,
    quick_get_squad_invitations,
    quick_accept_squad_invitation,
    quick_decline_squad_invitation
)
from .client import MC5Client
from .auth import TokenGenerator
from .exceptions import MC5APIError, AuthenticationError, RateLimitError
from .help import help, examples, quick_reference
from .admin_client import (
    AdminMC5Client,
    create_admin_client,
    create_user_client,
    quick_add_squad_rating,
    quick_update_player_score
)

# Encrypted token convenience functions
from .auth import TokenGenerator

def quick_generate_encrypted_token(
    username: str,
    password: str,
    device_id: Optional[str] = None,
    scope: str = "alert auth chat leaderboard_ro lobby message session social config storage_ro tracking_bi feed storage leaderboard_admin social_eve social soc transaction schedule lottery voice matchmaker",
    nonce: str = "*"
) -> Dict[str, Any]:
    """
    Quick function to generate and encrypt an access token.
    
    Args:
        username: MC5 username
        password: Account password
        device_id: Device ID (generated if not provided)
        scope: Permission scopes
        nonce: Nonce value for encryption
        
    Returns:
        Dictionary containing encrypted token information
    """
    token_gen = TokenGenerator()
    try:
        result = token_gen.generate_encrypted_token(username, password, device_id, scope, nonce)
        return result
    finally:
        token_gen.close()

def quick_encrypt_token(
    access_token: str,
    nonce: str = "*"
) -> str:
    """
    Quick function to encrypt an existing access token.
    
    Args:
        access_token: Raw access token string
        nonce: Nonce value for encryption
        
    Returns:
        Encrypted token string
    """
    token_gen = TokenGenerator()
    try:
        result = token_gen.encrypt_token(access_token, nonce)
        return result
    finally:
        token_gen.close()

__all__ = [
    "MC5Client",
    "SimpleMC5Client",
    "AdminMC5Client",
    "batch_search_players",
    "clan_cleanup",
    "monitor_clan_activity",
    "quick_search",
    "quick_kick",
    "quick_remove_friend",
    "quick_send_friend_request",
    "quick_check_friend_status",
    "quick_accept_friend_request",
    "quick_sign_up_for_event",
    "quick_get_event_leaderboard",
    "quick_get_my_event_rank",
    "quick_get_squad_invitations",
    "quick_accept_squad_invitation",
    "quick_decline_squad_invitation",
    "quick_create_squad_battle_room",
    "quick_post_squad_battle_result",
    "quick_get_squad_battle_history",
    "quick_analyze_squad_performance",
    "quick_get_squad_wall_messages",
    "quick_send_squad_battle_notification",
    "quick_post_squad_wall_message",
    "quick_get_active_sessions",
    "quick_get_my_sessions",
    "quick_get_session_statistics",
    "quick_check_session_status",
    "quick_get_server_type_sessions",
    "quick_analyze_session_activity",
    "quick_start_alert_stream",
    "quick_test_alert_connection",
    "quick_start_alerts_with_discord",
    "quick_monitor_alerts",
    "create_alert_callback",
    "quick_get_account_info",
    "quick_get_device_history",
    "quick_get_credential_summary",
    "quick_analyze_account_security",
    "quick_get_account_overview",
    "quick_export_account_data",
    "quick_generate_transfer_code",
    "quick_check_transfer_status",
    "quick_get_device_linking_guide",
    "quick_link_device_workflow",
    "quick_validate_transfer_code",
    "quick_force_new_code",
    "quick_transfer_status_summary",
    "telemetry",
    "report_error",
    "report_usage",
    "is_telemetry_enabled",
    "debug_mode",
    "debug_print",
    "debug_function",
    "analyze_error",
    "print_error_analysis",
    "create_admin_client",
    "create_user_client",
    "quick_add_squad_rating",
    "quick_update_player_score",
    "TokenGenerator", 
    "MC5APIError",
    "AuthenticationError",
    "RateLimitError",
    "help",
    "examples",
    "quick_reference",
    "quick_generate_encrypted_token",
    "quick_encrypt_token"
]
