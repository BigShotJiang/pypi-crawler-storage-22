#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : account.py
# | License  | MIT License © 2026 Chizoba
# | Brief    | User account management and analytics
# ────────────────★─────────────────────────────────

import json
from typing import Optional, Dict, Any, List
from .telemetry import report_error, report_usage
from .debug import debug_function, debug_print

class AccountMixin:
    """Mixin class for user account management and analytics."""
    
    @debug_function
    def get_account_info(self) -> Dict[str, Any]:
        """
        Get comprehensive user account information.
        
        Returns:
            Complete account data including credentials, installations, and device history
        """
        try:
            url = f"{self.BASE_URLS['janus']}/users/me"
            
            params = {
                "access_token": self._token_data["access_token"]
            }
            
            debug_print("👤 Getting comprehensive account information", "info")
            result = self._make_request("GET", url, params=params)
            
            if result:
                # Analyze account data
                account_analysis = self._analyze_account_data(result)
                
                debug_print(f"✅ Account info retrieved: {len(result.get('credentials', []))} credentials, {len(result.get('installations', []))} installations", "success")
                
                report_usage("get_account_info", True, 0, {
                    "credentials_count": len(result.get('credentials', [])),
                    "installations_count": len(result.get('installations', [])),
                    "has_alias": bool(result.get('alias')),
                    "is_ghost": result.get('is_ghost', False)
                })
                
                return {
                    "account_data": result,
                    "analysis": account_analysis
                }
            
            return {"account_data": {}, "analysis": {}}
            
        except Exception as e:
            debug_print(f"❌ Failed to get account info: {e}", "error")
            report_error(e, "get_account_info", {})
            raise
    
    def _analyze_account_data(self, account_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Analyze account data for insights.
        
        Args:
            account_data: Raw account data from API
            
        Returns:
            Analysis results and statistics
        """
        try:
            credentials = account_data.get("credentials", [])
            installations = account_data.get("installations", [])
            alias = account_data.get("alias", [])
            
            # Analyze credentials
            credential_analysis = self._analyze_credentials(credentials)
            
            # Analyze installations
            installation_analysis = self._analyze_installations(installations)
            
            # Analyze account security
            security_analysis = self._analyze_security(account_data)
            
            analysis = {
                "credentials": credential_analysis,
                "installations": installation_analysis,
                "security": security_analysis,
                "account_summary": {
                    "account_id": account_data.get("account"),
                    "total_credentials": len(credentials),
                    "total_installations": len(installations),
                    "has_alias": bool(alias),
                    "alias_count": len(alias),
                    "is_ghost": account_data.get("is_ghost", False),
                    "last_login": account_data.get("last_login")
                }
            }
            
            return analysis
            
        except Exception as e:
            debug_print(f"❌ Failed to analyze account data: {e}", "error")
            return {}
    
    def _analyze_credentials(self, credentials: List[str]) -> Dict[str, Any]:
        """
        Analyze user credentials.
        
        Args:
            credentials: List of credential strings
            
        Returns:
            Credential analysis
        """
        try:
            # Count credential types
            credential_types = {}
            microsoft_count = 0
            anonymous_count = 0
            
            for cred in credentials:
                if ":" in cred:
                    cred_type = cred.split(":")[0]
                    credential_types[cred_type] = credential_types.get(cred_type, 0) + 1
                    
                    if cred_type == "microsoftgraph":
                        microsoft_count += 1
                    elif cred_type == "anonymous":
                        anonymous_count += 1
            
            # Extract unique anonymous IDs
            anonymous_ids = []
            for cred in credentials:
                if cred.startswith("anonymous:"):
                    anon_id = cred.split(":")[1]
                    if anon_id not in anonymous_ids:
                        anonymous_ids.append(anon_id)
            
            return {
                "total_credentials": len(credentials),
                "credential_types": credential_types,
                "microsoft_credentials": microsoft_count,
                "anonymous_credentials": anonymous_count,
                "unique_anonymous_ids": len(anonymous_ids),
                "latest_anonymous_id": anonymous_ids[-1] if anonymous_ids else None
            }
            
        except Exception as e:
            debug_print(f"❌ Failed to analyze credentials: {e}", "error")
            return {"total_credentials": len(credentials)}
    
    def _analyze_installations(self, installations: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Analyze device installations.
        
        Args:
            installations: List of installation data
            
        Returns:
            Installation analysis
        """
        try:
            # Count by model
            models = {}
            countries = {}
            languages = {}
            resolutions = {}
            firmware_versions = {}
            
            valid_installations = 0
            
            for install in installations:
                if install.get("model"):  # Only count valid installations
                    valid_installations += 1
                    
                    model = install.get("model", "Unknown")
                    models[model] = models.get(model, 0) + 1
                    
                    country = install.get("country", "Unknown")
                    countries[country] = countries.get(country, 0) + 1
                    
                    language = install.get("language", "Unknown")
                    languages[language] = languages.get(language, 0) + 1
                    
                    resolution = install.get("resolution", "Unknown")
                    resolutions[resolution] = resolutions.get(resolution, 0) + 1
                    
                    firmware = install.get("firmware", "Unknown")
                    firmware_versions[firmware] = firmware_versions.get(firmware, 0) + 1
            
            # Find most common values
            most_common_model = max(models.items(), key=lambda x: x[1]) if models else ("Unknown", 0)
            most_common_country = max(countries.items(), key=lambda x: x[1]) if countries else ("Unknown", 0)
            most_common_language = max(languages.items(), key=lambda x: x[1]) if languages else ("Unknown", 0)
            
            return {
                "total_installations": len(installations),
                "valid_installations": valid_installations,
                "device_models": models,
                "countries": countries,
                "languages": languages,
                "resolutions": resolutions,
                "firmware_versions": firmware_versions,
                "most_common_model": most_common_model[0],
                "most_common_model_count": most_common_model[1],
                "most_common_country": most_common_country[0],
                "most_common_language": most_common_language[0]
            }
            
        except Exception as e:
            debug_print(f"❌ Failed to analyze installations: {e}", "error")
            return {"total_installations": len(installations)}
    
    def _analyze_security(self, account_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Analyze account security.
        
        Args:
            account_data: Account data
            
        Returns:
            Security analysis
        """
        try:
            credentials = account_data.get("credentials", [])
            installations = account_data.get("installations", [])
            
            # Security metrics
            security_score = 100
            security_issues = []
            
            # Check for multiple anonymous credentials
            anonymous_count = sum(1 for cred in credentials if cred.startswith("anonymous:"))
            if anonymous_count > 10:
                security_score -= 10
                security_issues.append(f"High number of anonymous credentials: {anonymous_count}")
            
            # Check for installations from many countries
            countries = set()
            for install in installations:
                if install.get("country"):
                    countries.add(install["country"])
            
            if len(countries) > 5:
                security_score -= 15
                security_issues.append(f"Installations from many countries: {len(countries)}")
            
            # Check for ghost account
            if account_data.get("is_ghost", False):
                security_score -= 20
                security_issues.append("Account is marked as ghost")
            
            # Check for no recent login
            last_login = account_data.get("last_login")
            if not last_login:
                security_score -= 5
                security_issues.append("No recent login recorded")
            
            return {
                "security_score": max(0, security_score),
                "security_issues": security_issues,
                "risk_level": "Low" if security_score >= 80 else "Medium" if security_score >= 60 else "High",
                "unique_countries": len(countries),
                "anonymous_credential_count": anonymous_count
            }
            
        except Exception as e:
            debug_print(f"❌ Failed to analyze security: {e}", "error")
            return {"security_score": 0, "risk_level": "Unknown"}
    
    @debug_function
    def get_device_history(self) -> Dict[str, Any]:
        """
        Get device installation history.
        
        Returns:
            Device history with timeline analysis
        """
        try:
            account_data = self.get_account_info()
            installations = account_data.get("account_data", {}).get("installations", [])
            
            # Sort by device_id to create timeline
            device_timeline = []
            seen_devices = set()
            
            for install in installations:
                device_id = install.get("device_id")
                if device_id and device_id not in seen_devices:
                    seen_devices.add(device_id)
                    device_timeline.append({
                        "device_id": device_id,
                        "model": install.get("model"),
                        "country": install.get("country"),
                        "language": install.get("language"),
                        "resolution": install.get("resolution"),
                        "firmware": install.get("firmware")
                    })
            
            debug_print(f"📱 Device history: {len(device_timeline)} unique devices", "success")
            
            return {
                "device_timeline": device_timeline,
                "total_unique_devices": len(device_timeline),
                "device_summary": {
                    "most_recent_device": device_timeline[-1] if device_timeline else None,
                    "device_countries": list(set(d.get("country", "Unknown") for d in device_timeline if d.get("country")))
                }
            }
            
        except Exception as e:
            debug_print(f"❌ Failed to get device history: {e}", "error")
            report_error(e, "get_device_history", {})
            raise
    
    @debug_function
    def get_credential_summary(self) -> Dict[str, Any]:
        """
        Get credential summary and analysis.
        
        Returns:
            Credential summary with security analysis
        """
        try:
            account_data = self.get_account_info()
            credentials = account_data.get("account_data", {}).get("credentials", [])
            
            # Extract credential details
            credential_details = []
            for i, cred in enumerate(credentials):
                if ":" in cred:
                    cred_type, cred_value = cred.split(":", 1)
                    credential_details.append({
                        "index": i,
                        "type": cred_type,
                        "value": cred_value[:20] + "..." if len(cred_value) > 20 else cred_value,
                        "full_value": cred
                    })
            
            debug_print(f"🔐 Credential summary: {len(credentials)} credentials analyzed", "success")
            
            return {
                "credential_count": len(credentials),
                "credential_details": credential_details,
                "credential_types": list(set(d["type"] for d in credential_details)),
                "latest_credential": credential_details[-1] if credential_details else None
            }
            
        except Exception as e:
            debug_print(f"❌ Failed to get credential summary: {e}", "error")
            report_error(e, "get_credential_summary", {})
            raise
