#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : account_quick.py
# | License  | MIT License © 2026 Chizoba
# | Brief    | Quick functions for account management
# ────────────────★─────────────────────────────────

from typing import Optional, Dict, Any
from .simple_client import SimpleMC5Client
from .telemetry import report_usage
from .debug import debug_function, debug_print

@debug_function
def quick_get_account_info(username: str, password: str) -> Optional[Dict[str, Any]]:
    """
    Quick function to get comprehensive account information.
    
    Args:
        username: MC5 username
        password: MC5 password
        
    Returns:
        Complete account information with analysis or None if failed
    """
    try:
        with SimpleMC5Client(username, password) as client:
            if client.connect():
                account_info = client.client.get_account_info()
                
                # Display summary
                analysis = account_info.get('analysis', {})
                summary = analysis.get('account_summary', {})
                
                debug_print(f"✅ Account info retrieved", "success")
                debug_print(f"👤 Account ID: {summary.get('account_id', 'Unknown')}", "info")
                debug_print(f"🔐 Credentials: {summary.get('total_credentials', 0)}", "info")
                debug_print(f"📱 Installations: {summary.get('total_installations', 0)}", "info")
                debug_print(f"🏷️  Aliases: {summary.get('alias_count', 0)}", "info")
                debug_print(f"👻 Ghost Account: {summary.get('is_ghost', False)}", "info")
                
                return account_info
            return None
    except Exception as e:
        debug_print(f"❌ Failed to get account info: {e}", "error")
        return None

@debug_function
def quick_get_device_history(username: str, password: str) -> Optional[Dict[str, Any]]:
    """
    Quick function to get device installation history.
    
    Args:
        username: MC5 username
        password: MC5 password
        
    Returns:
        Device history with timeline or None if failed
    """
    try:
        with SimpleMC5Client(username, password) as client:
            if client.connect():
                device_history = client.client.get_device_history()
                
                total_devices = device_history.get('total_unique_devices', 0)
                debug_print(f"✅ Device history retrieved: {total_devices} unique devices", "success")
                
                # Show recent devices
                timeline = device_history.get('device_timeline', [])
                for i, device in enumerate(timeline[-3:], 1):  # Show last 3
                    model = device.get('model', 'Unknown')
                    country = device.get('country', 'Unknown')
                    debug_print(f"   Device {i}: {model} ({country})", "info")
                
                return device_history
            return None
    except Exception as e:
        debug_print(f"❌ Failed to get device history: {e}", "error")
        return None

@debug_function
def quick_get_credential_summary(username: str, password: str) -> Optional[Dict[str, Any]]:
    """
    Quick function to get credential summary.
    
    Args:
        username: MC5 username
        password: MC5 password
        
    Returns:
        Credential summary or None if failed
    """
    try:
        with SimpleMC5Client(username, password) as client:
            if client.connect():
                credential_summary = client.client.get_credential_summary()
                
                credential_count = credential_summary.get('credential_count', 0)
                debug_print(f"✅ Credential summary: {credential_count} credentials", "success")
                
                # Show credential types
                cred_types = credential_summary.get('credential_types', [])
                for cred_type in cred_types:
                    debug_print(f"   Type: {cred_type}", "info")
                
                return credential_summary
            return None
    except Exception as e:
        debug_print(f"❌ Failed to get credential summary: {e}", "error")
        return None

@debug_function
def quick_analyze_account_security(username: str, password: str) -> Optional[Dict[str, Any]]:
    """
    Quick function to analyze account security.
    
    Args:
        username: MC5 username
        password: MC5 password
        
    Returns:
        Security analysis or None if failed
    """
    try:
        with SimpleMC5Client(username, password) as client:
            if client.connect():
                account_info = client.client.get_account_info()
                security_analysis = account_info.get('analysis', {}).get('security', {})
                
                security_score = security_analysis.get('security_score', 0)
                risk_level = security_analysis.get('risk_level', 'Unknown')
                issues = security_analysis.get('security_issues', [])
                
                debug_print(f"✅ Security analysis completed", "success")
                debug_print(f"🔒 Security Score: {security_score}/100", "info")
                debug_print(f"⚠️  Risk Level: {risk_level}", "info")
                
                if issues:
                    debug_print("🚨 Security Issues:", "warning")
                    for issue in issues:
                        debug_print(f"   • {issue}", "warning")
                else:
                    debug_print("✅ No security issues detected", "success")
                
                return security_analysis
            return None
    except Exception as e:
        debug_print(f"❌ Failed to analyze security: {e}", "error")
        return None

@debug_function
def quick_get_account_overview(username: str, password: str) -> Optional[Dict[str, Any]]:
    """
    Quick function to get complete account overview.
    
    Args:
        username: MC5 username
        password: MC5 password
        
    Returns:
        Complete account overview or None if failed
    """
    try:
        with SimpleMC5Client(username, password) as client:
            if client.connect():
                # Get all account data
                account_info = client.client.get_account_info()
                device_history = client.client.get_device_history()
                credential_summary = client.client.get_credential_summary()
                
                # Create overview
                analysis = account_info.get('analysis', {})
                account_summary = analysis.get('account_summary', {})
                installation_analysis = analysis.get('installations', {})
                security_analysis = analysis.get('security', {})
                
                overview = {
                    "account_summary": account_summary,
                    "device_summary": {
                        "total_devices": device_history.get('total_unique_devices', 0),
                        "most_common_model": installation_analysis.get('most_common_model'),
                        "most_common_country": installation_analysis.get('most_common_country')
                    },
                    "credential_summary": {
                        "total_credentials": credential_summary.get('credential_count', 0),
                        "credential_types": credential_summary.get('credential_types', [])
                    },
                    "security_summary": {
                        "security_score": security_analysis.get('security_score', 0),
                        "risk_level": security_analysis.get('risk_level', 'Unknown'),
                        "security_issues": security_analysis.get('security_issues', [])
                    }
                }
                
                debug_print(f"✅ Account overview completed", "success")
                debug_print(f"👤 Account: {account_summary.get('account_id', 'Unknown')}", "info")
                debug_print(f"📱 Devices: {overview['device_summary']['total_devices']}", "info")
                debug_print(f"🔐 Credentials: {overview['credential_summary']['total_credentials']}", "info")
                debug_print(f"🔒 Security: {overview['security_summary']['security_score']}/100 ({overview['security_summary']['risk_level']})", "info")
                
                return overview
            return None
    except Exception as e:
        debug_print(f"❌ Failed to get account overview: {e}", "error")
        return None

@debug_function
def quick_export_account_data(username: str, password: str, filename: str = "account_data.json") -> bool:
    """
    Quick function to export complete account data to file.
    
    Args:
        username: MC5 username
        password: MC5 password
        filename: Output filename
        
    Returns:
        True if successful, False otherwise
    """
    try:
        with SimpleMC5Client(username, password) as client:
            if client.connect():
                # Get complete account data
                account_info = client.client.get_account_info()
                device_history = client.client.get_device_history()
                credential_summary = client.client.get_credential_summary()
                
                # Combine all data
                export_data = {
                    "export_timestamp": __import__('datetime').datetime.now().isoformat(),
                    "account_info": account_info,
                    "device_history": device_history,
                    "credential_summary": credential_summary
                }
                
                # Write to file
                import json
                with open(filename, 'w', encoding='utf-8') as f:
                    json.dump(export_data, f, indent=2, ensure_ascii=False)
                
                debug_print(f"✅ Account data exported to {filename}", "success")
                return True
            return False
    except Exception as e:
        debug_print(f"❌ Failed to export account data: {e}", "error")
        return False
