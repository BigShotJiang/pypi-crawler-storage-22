#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : admin_client.py
# | License  | MIT License © 2026 Chizoba
# | Brief    | Admin client with enhanced squad management
# ────────────────★─────────────────────────────────

"""
MC5 API Client - Admin Client

Enhanced client with admin capabilities for squad management.
Supports both regular users and admin users with special privileges.
"""

import requests
import json
from typing import Dict, List, Any, Optional
from urllib.parse import quote

from .auth import TokenGenerator
from .exceptions import MC5APIError, AuthenticationError


class AdminMC5Client:
    """Enhanced MC5 client with admin capabilities."""
    
    def __init__(self, username: str, password: str, is_admin: bool = False):
        """
        Initialize admin client.
        
        Args:
            username: MC5 username or admin username
            password: MC5 password or admin password
            is_admin: Whether using admin credentials
        """
        self.username = username
        self.password = password
        self.is_admin = is_admin
        self.token = None
        self.user_id = None
        self.squad_id = None
        self.base_url = "https://eur-osiris.gameloft.com"
        self.auth_url = "https://eur-janus.gameloft.com"
        
        # Admin-specific settings
        if is_admin:
            self.client_id = "1875:55979:6.0.0a:windows:windows"
            self.scope = "alert auth chat leaderboard_ro lobby message session social config storage_ro tracking_bi feed storage leaderboard_admin social_eve social soc transaction schedule lottery voice matchmaker profile_inventory admin bypass unrestricted"
            self.device_id = ""
        else:
            self.client_id = "1924:56128:6.0.6a:android:googleplay"
            self.scope = "alert auth chat leaderboard_ro lobby message session social"
            self.device_id = "1765668231.356923"
    
    def connect(self) -> bool:
        """Connect to MC5 API."""
        try:
            print(f"🔌 Connecting to MC5 ({'Admin' if self.is_admin else 'User'} mode)...")
            
            # Generate token
            token_gen = TokenGenerator()
            token_data = token_gen.generate_token(
                self.username,
                self.password,
                self.device_id,
                self.scope
            )
            
            if not token_data or 'access_token' not in token_data:
                print("❌ Failed to generate token")
                return False
            
            self.token = token_data['access_token']
            self.user_id = token_data.get('credential', '')
            print(f"✅ User ID: {self.user_id}")
            
            # Get user profile to find squad
            self._get_user_profile()
            
            print("✅ Connected successfully!")
            return True
            
        except Exception as e:
            print(f"❌ Connection failed: {e}")
            return False
    
    def _get_user_profile(self) -> bool:
        """Get user profile and extract squad information."""
        try:
            url = f"{self.auth_url}/games/mygame/alias/{self.user_id}"
            params = {
                'access_token': self.token
            }
            
            response = requests.get(url, params=params)
            
            if response.status_code == 200:
                profile = response.json()
                
                # Extract squad ID from groups
                groups = profile.get('groups', [])
                if groups:
                    self.squad_id = groups[0]
                    print(f"✅ Squad ID detected: {self.squad_id}")
                    return True
                else:
                    print("⚠️ No squad found in profile")
                    # For admin users, use your squad ID
                    if self.is_admin:
                        self.squad_id = "e514e40a-009c-11f1-b16a-b8ca3a7095d0"
                        print(f"✅ Using default squad ID: {self.squad_id}")
                        return True
                    return False
            else:
                print(f"❌ Failed to get profile: {response.status_code}")
                # For admin users, use your squad ID
                if self.is_admin:
                    self.squad_id = "e514e40a-009c-11f1-b16a-b8ca3a7095d0"
                    print(f"✅ Using default squad ID: {self.squad_id}")
                    return True
                return False
                
        except Exception as e:
            print(f"❌ Error getting profile: {e}")
            # For admin users, use your squad ID
            if self.is_admin:
                self.squad_id = "e514e40a-009c-11f1-b16a-b8ca3a7095d0"
                print(f"✅ Using default squad ID: {self.squad_id}")
                return True
            return False
    
    def add_squad_rating(self, rating: int = 5200) -> Dict[str, Any]:
        """
        Add rating to squad.
        
        Args:
            rating: Rating amount to add
            
        Returns:
            Result dictionary
        """
        if not self.squad_id:
            return {'error': 'No squad ID found'}
        
        try:
            print(f"⭐ Adding {rating} rating to squad...")
            
            # For admin users, we can update squad score directly
            if self.is_admin:
                return self._admin_update_squad_score(rating)
            else:
                return self._user_update_squad_score(rating)
                
        except Exception as e:
            return {'error': str(e)}
    
    def _admin_update_squad_score(self, rating: int) -> Dict[str, Any]:
        """Admin method to update squad score."""
        try:
            # Admin can update squad settings directly
            url = f"{self.base_url}/groups/{self.squad_id}"
            headers = {
                'Content-Type': 'application/x-www-form-urlencoded'
            }
            
            # Update squad score
            data = {
                'access_token': self.token,
                'operation': 'update',
                '_score': str(rating)
            }
            
            response = requests.post(url, headers=headers, data=data)
            
            print(f"🔍 Admin API Response: {response.status_code}")
            if response.status_code == 200:
                return {'success': True, 'rating_added': rating}
            else:
                print(f"🔍 Response body: {response.text}")
                return {'error': f'Failed to update squad score: {response.status_code}'}
                
        except Exception as e:
            return {'error': str(e)}
    
    def _user_update_squad_score(self, rating: int) -> Dict[str, Any]:
        """User method to update squad score."""
        try:
            # Regular users update their own score which affects squad
            url = f"{self.base_url}/groups/{self.squad_id}/members/{quote(self.user_id)}"
            headers = {
                'Content-Type': 'application/x-www-form-urlencoded'
            }
            
            # Update user score
            data = {
                'access_token': self.token,
                'operation': 'update',
                '_score': str(rating)
            }
            
            response = requests.post(url, headers=headers, data=data)
            
            if response.status_code == 200:
                return {'success': True, 'rating_added': rating}
            else:
                return {'error': f'Failed to update score: {response.status_code}'}
                
        except Exception as e:
            return {'error': str(e)}
    
    def update_player_score(self, target_user_id: str, score: int, xp: int = None, 
                          killsig_color: str = None, killsig_id: str = None) -> Dict[str, Any]:
        """
        Update player score (admin only).
        
        Args:
            target_user_id: Target player's user ID
            score: New score value
            xp: New XP value (optional)
            killsig_color: Kill signature color (optional)
            killsig_id: Kill signature ID (optional)
            
        Returns:
            Result dictionary
        """
        if not self.is_admin:
            return {'error': 'Admin privileges required'}
        
        try:
            print(f"🎯 Updating player {target_user_id} score to {score}...")
            
            url = f"{self.base_url}/groups/{self.squad_id}/members/{quote(target_user_id)}"
            headers = {
                'Content-Type': 'application/x-www-form-urlencoded'
            }
            
            data = {
                'access_token': self.token,
                'operation': 'update',
                '_score': str(score),
                'credential': target_user_id
            }
            
            # Add optional parameters
            if xp is not None:
                data['_xp'] = str(xp)
            if killsig_color is not None:
                data['_killsig_color'] = killsig_color
            if killsig_id is not None:
                data['_killsig_id'] = killsig_id
            
            response = requests.post(url, headers=headers, data=data)
            
            if response.status_code == 200:
                result = {'success': True, 'score_updated': score}
                if xp is not None:
                    result['xp_updated'] = xp
                if killsig_color is not None:
                    result['killsig_color_updated'] = killsig_color
                if killsig_id is not None:
                    result['killsig_id_updated'] = killsig_id
                return result
            else:
                return {'error': f'Failed to update player: {response.status_code}'}
                
        except Exception as e:
            return {'error': str(e)}
    
    def kick_member(self, target_user_id: str, reason: str = "Kicked by admin") -> Dict[str, Any]:
        """
        Kick member from squad (admin only).
        
        Args:
            target_user_id: Target player's user ID
            reason: Kick reason
            
        Returns:
            Result dictionary
        """
        if not self.is_admin:
            return {'error': 'Admin privileges required'}
        
        try:
            print(f"👢 Kicking member {target_user_id}...")
            
            url = f"{self.base_url}/groups/{self.squad_id}/members/{quote(target_user_id)}"
            headers = {
                'Content-Type': 'application/x-www-form-urlencoded'
            }
            
            data = {
                'access_token': self.token,
                'operation': 'delete',
                'reason': reason
            }
            
            response = requests.post(url, headers=headers, data=data)
            
            if response.status_code == 200:
                return {'success': True, 'kicked': target_user_id, 'reason': reason}
            else:
                return {'error': f'Failed to kick member: {response.status_code}'}
                
        except Exception as e:
            return {'error': str(e)}
    
    def get_squad_members(self) -> List[Dict[str, Any]]:
        """Get squad members."""
        if not self.squad_id:
            return []
        
        try:
            url = f"{self.base_url}/groups/{self.squad_id}/members"
            params = {
                'access_token': self.token
            }
            
            response = requests.get(url, params=params)
            
            if response.status_code == 200:
                return response.json()
            else:
                print(f"❌ Failed to get squad members: {response.status_code}")
                return []
                
        except Exception as e:
            print(f"❌ Error getting squad members: {e}")
            return []
    
    def get_user_stats(self) -> Dict[str, Any]:
        """Get current user statistics."""
        try:
            url = f"{self.auth_url}/games/mygame/alias/{self.user_id}"
            params = {
                'access_token': self.token
            }
            
            response = requests.get(url, params=params)
            
            if response.status_code == 200:
                return response.json()
            else:
                return {}
                
        except Exception as e:
            print(f"❌ Error getting user stats: {e}")
            return {}
    
    def close(self):
        """Close connection."""
        self.token = None
        self.user_id = None
        self.squad_id = None


# Convenience functions
def create_admin_client() -> AdminMC5Client:
    """Create admin client with default admin credentials."""
    return AdminMC5Client(
        username="game:mc5_system",
        password="admin",
        is_admin=True
    )


def create_user_client(username: str, password: str) -> AdminMC5Client:
    """Create user client."""
    return AdminMC5Client(
        username=username,
        password=password,
        is_admin=False
    )


def quick_add_squad_rating(username: str, password: str, rating: int = 5200, 
                          use_admin: bool = False) -> Dict[str, Any]:
    """
    Quick function to add rating to squad.
    
    Args:
        username: MC5 username
        password: MC5 password
        rating: Rating to add
        use_admin: Whether to use admin credentials
        
    Returns:
        Result dictionary
    """
    try:
        if use_admin:
            client = create_admin_client()
        else:
            client = create_user_client(username, password)
        
        if client.connect():
            result = client.add_squad_rating(rating)
            client.close()
            return result
        else:
            return {'error': 'Failed to connect'}
            
    except Exception as e:
        return {'error': str(e)}


def quick_update_player_score(target_user_id: str, score: int, xp: int = None,
                             killsig_color: str = None, killsig_id: str = None) -> Dict[str, Any]:
    """
    Quick function to update player score (admin only).
    
    Args:
        target_user_id: Target player's user ID
        score: New score value
        xp: New XP value (optional)
        killsig_color: Kill signature color (optional)
        killsig_id: Kill signature ID (optional)
        
    Returns:
        Result dictionary
    """
    try:
        client = create_admin_client()
        
        if client.connect():
            result = client.update_player_score(target_user_id, score, xp, killsig_color, killsig_id)
            client.close()
            return result
        else:
            return {'error': 'Failed to connect'}
            
    except Exception as e:
        return {'error': str(e)}
