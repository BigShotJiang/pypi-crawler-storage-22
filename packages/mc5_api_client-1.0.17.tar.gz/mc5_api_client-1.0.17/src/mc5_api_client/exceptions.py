# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : exceptions.py
# | License  : MIT License © 2026 Chizoba
# | Brief    : Custom exceptions for MC5 API Client
# ────────────────★─────────────────────────────────

"""
Custom exceptions for the MC5 API Client.
"""


class MC5APIError(Exception):
    """Base exception for all MC5 API related errors."""
    
    def __init__(self, message: str, status_code: int = None, response_data: dict = None):
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.response_data = response_data or {}
    
    def __str__(self) -> str:
        if self.status_code:
            return f"MC5APIError ({self.status_code}): {self.message}"
        return f"MC5APIError: {self.message}"


class AuthenticationError(MC5APIError):
    """Raised when authentication fails."""
    
    def __init__(self, message: str = "Authentication failed"):
        super().__init__(message, status_code=401)


class RateLimitError(MC5APIError):
    """Raised when rate limit is exceeded."""
    
    def __init__(self, message: str = "Rate limit exceeded", retry_after: int = None):
        super().__init__(message, status_code=429)
        self.retry_after = retry_after


class InvalidCredentialsError(AuthenticationError):
    """Raised when provided credentials are invalid."""
    
    def __init__(self, message: str = "Invalid username or password"):
        super().__init__(message)


class TokenExpiredError(AuthenticationError):
    """Raised when access token has expired."""
    
    def __init__(self, message: str = "Access token has expired"):
        super().__init__(message)


class InsufficientScopeError(MC5APIError):
    """Raised when token lacks required scope for an operation."""
    
    def __init__(self, required_scope: str):
        message = f"Insufficient scope. Required: {required_scope}"
        super().__init__(message, status_code=403)
        self.required_scope = required_scope


class NetworkError(MC5APIError):
    """Raised when network connectivity issues occur."""
    
    def __init__(self, message: str = "Network error occurred"):
        super().__init__(message)


class ValidationError(MC5APIError):
    """Raised when request validation fails."""
    
    def __init__(self, message: str = "Validation failed", field: str = None):
        super().__init__(message, status_code=400)
        self.field = field
