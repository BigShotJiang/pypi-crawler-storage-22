#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : federation.py
# | License  | MIT License © 2026 Chizoba
# | Brief    | Federation and session management APIs
# ────────────────★─────────────────────────────────

import json
from typing import Optional, Dict, Any, List
from .telemetry import report_error, report_usage
from .debug import debug_function, debug_print

class FederationMixin:
    """Mixin class for federation and session management functionality."""
    
    # Federation endpoint
    FEDERATION_BASE_URL = "https://federation-eur.gameloft.com"
    
    @debug_function
    def get_active_sessions(self, credentials: Optional[List[str]] = None) -> Dict[str, Any]:
        """
        Get active game sessions from federation server.
        
        Args:
            credentials: Optional list of user credentials to filter by
            
        Returns:
            Session information with owner details
        """
        try:
            url = f"{self.FEDERATION_BASE_URL}/sessions/{self.client_id}"
            
            # Always provide credentials parameter based on API discovery
            if credentials:
                credentials_str = ",".join(credentials)
            else:
                # Use current user's credential if none provided
                user_credential = self._token_data.get("user_credential")
                if not user_credential:
                    # Extract from access_token if needed
                    token_parts = self._token_data["access_token"].split(",")
                    for part in token_parts:
                        if "anonymous:" in part:
                            user_credential = part.strip()
                            break
                credentials_str = user_credential if user_credential else ""
            
            params = {
                "access_token": self._token_data["access_token"],
                "credentials": credentials_str
            }
            
            debug_print(f"🔍 Getting active sessions for {self.client_id}", "info")
            result = self._make_request("GET", url, params=params)
            
            if result:
                sessions = result.get("sessions", [])
                debug_print(f"✅ Found {len(sessions)} active sessions", "success")
                
                # Analyze sessions
                session_info = []
                for session in sessions:
                    owner = session.get("owner", {})
                    session_data = {
                        "session_id": session.get("created"),
                        "client_id": session.get("client_id"),
                        "created": session.get("created"),
                        "owner_info": {
                            "fed_id": owner.get("fed_id"),
                            "credential": owner.get("credential"),
                            "name": owner.get("name"),
                            "server_type": owner.get("server_type"),
                            "country": owner.get("country")
                        }
                    }
                    session_info.append(session_data)
                
                report_usage("get_active_sessions", True, 0, {
                    "sessions_found": len(sessions),
                    "client_id": self.client_id
                })
                
                return {
                    "sessions": session_info,
                    "total_count": len(sessions),
                    "client_id": self.client_id
                }
            
            return {"sessions": [], "total_count": 0}
            
        except Exception as e:
            debug_print(f"❌ Failed to get active sessions: {e}", "error")
            report_error(e, "get_active_sessions", {
                "client_id": self.client_id,
                "credentials_count": len(credentials) if credentials else 0
            })
            raise
    
    @debug_function
    def get_my_sessions(self) -> Dict[str, Any]:
        """
        Get sessions for the current user.
        
        Returns:
            User's active sessions
        """
        try:
            # Use current user's credential
            user_credential = self._token_data.get("user_credential")
            if not user_credential:
                # Extract from access_token if needed
                token_parts = self._token_data["access_token"].split(",")
                for part in token_parts:
                    if "anonymous:" in part:
                        user_credential = part.strip()
                        break
            
            if user_credential:
                return self.get_active_sessions([user_credential])
            else:
                debug_print("⚠️ Could not determine user credential", "warning")
                return {"sessions": [], "total_count": 0}
                
        except Exception as e:
            debug_print(f"❌ Failed to get user sessions: {e}", "error")
            report_error(e, "get_my_sessions", {})
            raise
    
    @debug_function
    def get_session_statistics(self) -> Dict[str, Any]:
        """
        Get statistics about active sessions.
        
        Returns:
            Session statistics and analytics
        """
        try:
            sessions_data = self.get_active_sessions()
            sessions = sessions_data.get("sessions", [])
            
            if not sessions:
                return {"error": "No sessions found"}
            
            # Analyze session data
            total_sessions = len(sessions)
            
            # Server type distribution
            server_types = {}
            countries = {}
            
            for session in sessions:
                owner_info = session.get("owner_info", {})
                
                # Count server types
                server_type = owner_info.get("server_type", "unknown")
                server_types[server_type] = server_types.get(server_type, 0) + 1
                
                # Count countries
                country = owner_info.get("country", "unknown")
                countries[country] = countries.get(country, 0) + 1
            
            # Recent sessions (last 5)
            recent_sessions = sorted(sessions, key=lambda x: x.get("created", ""), reverse=True)[:5]
            
            stats = {
                "total_sessions": total_sessions,
                "client_id": self.client_id,
                "server_type_distribution": server_types,
                "country_distribution": countries,
                "recent_sessions": recent_sessions,
                "analysis_timestamp": __import__('datetime').datetime.now().isoformat()
            }
            
            debug_print(f"✅ Session statistics analyzed: {total_sessions} sessions", "success")
            return stats
            
        except Exception as e:
            debug_print(f"❌ Failed to analyze session statistics: {e}", "error")
            report_error(e, "get_session_statistics", {})
            raise
    
    @debug_function
    def check_session_status(self, fed_id: str) -> Dict[str, Any]:
        """
        Check status of a specific session by federation ID.
        
        Args:
            fed_id: Federation ID to check
            
        Returns:
            Session status information
        """
        try:
            sessions_data = self.get_active_sessions()
            sessions = sessions_data.get("sessions", [])
            
            # Find session by fed_id
            target_session = None
            for session in sessions:
                if session.get("owner_info", {}).get("fed_id") == fed_id:
                    target_session = session
                    break
            
            if target_session:
                debug_print(f"✅ Found session for fed_id: {fed_id}", "success")
                return {
                    "found": True,
                    "session": target_session,
                    "status": "active"
                }
            else:
                debug_print(f"⚠️ No session found for fed_id: {fed_id}", "warning")
                return {
                    "found": False,
                    "status": "not_found"
                }
                
        except Exception as e:
            debug_print(f"❌ Failed to check session status: {e}", "error")
            report_error(e, "check_session_status", {"fed_id": fed_id})
            raise
    
    @debug_function
    def get_server_type_sessions(self, server_type: str) -> Dict[str, Any]:
        """
        Get sessions filtered by server type.
        
        Args:
            server_type: Server type to filter (ts, mp_server, etc.)
            
        Returns:
            Filtered sessions by server type
        """
        try:
            sessions_data = self.get_active_sessions()
            sessions = sessions_data.get("sessions", [])
            
            # Filter by server type
            filtered_sessions = []
            for session in sessions:
                owner_info = session.get("owner_info", {})
                if owner_info.get("server_type") == server_type:
                    filtered_sessions.append(session)
            
            debug_print(f"✅ Found {len(filtered_sessions)} {server_type} sessions", "success")
            
            return {
                "server_type": server_type,
                "sessions": filtered_sessions,
                "total_count": len(filtered_sessions)
            }
            
        except Exception as e:
            debug_print(f"❌ Failed to get {server_type} sessions: {e}", "error")
            report_error(e, "get_server_type_sessions", {"server_type": server_type})
            raise
