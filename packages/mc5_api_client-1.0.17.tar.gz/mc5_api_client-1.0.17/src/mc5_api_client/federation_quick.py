#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : federation_quick.py
# | License  | MIT License © 2026 Chizoba
# | Brief    | Quick functions for federation and session management
# ────────────────★─────────────────────────────────

from typing import Optional, Dict, Any, List
from .simple_client import SimpleMC5Client
from .telemetry import report_usage
from .debug import debug_function, debug_print

@debug_function
def quick_get_active_sessions(username: str, password: str, credentials: Optional[List[str]] = None) -> Optional[Dict[str, Any]]:
    """
    Quick function to get active game sessions.
    
    Args:
        username: MC5 username
        password: MC5 password
        credentials: Optional list of user credentials to filter by
        
    Returns:
        Session information or None if failed
    """
    try:
        with SimpleMC5Client(username, password) as client:
            if client.connect():
                sessions = client.client.get_active_sessions(credentials)
                debug_print(f"✅ Retrieved {sessions.get('total_count', 0)} active sessions", "success")
                return sessions
            return None
    except Exception as e:
        debug_print(f"❌ Failed to get active sessions: {e}", "error")
        return None

@debug_function
def quick_get_my_sessions(username: str, password: str) -> Optional[Dict[str, Any]]:
    """
    Quick function to get current user's sessions.
    
    Args:
        username: MC5 username
        password: MC5 password
        
    Returns:
        User's sessions or None if failed
    """
    try:
        with SimpleMC5Client(username, password) as client:
            if client.connect():
                sessions = client.client.get_my_sessions()
                debug_print(f"✅ Retrieved {sessions.get('total_count', 0)} user sessions", "success")
                return sessions
            return None
    except Exception as e:
        debug_print(f"❌ Failed to get user sessions: {e}", "error")
        return None

@debug_function
def quick_get_session_statistics(username: str, password: str) -> Optional[Dict[str, Any]]:
    """
    Quick function to get session statistics.
    
    Args:
        username: MC5 username
        password: MC5 password
        
    Returns:
        Session statistics or None if failed
    """
    try:
        with SimpleMC5Client(username, password) as client:
            if client.connect():
                stats = client.client.get_session_statistics()
                debug_print(f"✅ Session statistics analyzed: {stats.get('total_sessions', 0)} sessions", "success")
                return stats
            return None
    except Exception as e:
        debug_print(f"❌ Failed to get session statistics: {e}", "error")
        return None

@debug_function
def quick_check_session_status(username: str, password: str, fed_id: str) -> Optional[Dict[str, Any]]:
    """
    Quick function to check status of a specific session.
    
    Args:
        username: MC5 username
        password: MC5 password
        fed_id: Federation ID to check
        
    Returns:
        Session status or None if failed
    """
    try:
        with SimpleMC5Client(username, password) as client:
            if client.connect():
                status = client.client.check_session_status(fed_id)
                if status.get("found"):
                    debug_print(f"✅ Session found: {status.get('status')}", "success")
                else:
                    debug_print(f"⚠️ Session not found", "warning")
                return status
            return None
    except Exception as e:
        debug_print(f"❌ Failed to check session status: {e}", "error")
        return None

@debug_function
def quick_get_server_type_sessions(username: str, password: str, server_type: str) -> Optional[Dict[str, Any]]:
    """
    Quick function to get sessions by server type.
    
    Args:
        username: MC5 username
        password: MC5 password
        server_type: Server type (ts, mp_server, etc.)
        
    Returns:
        Filtered sessions or None if failed
    """
    try:
        with SimpleMC5Client(username, password) as client:
            if client.connect():
                sessions = client.client.get_server_type_sessions(server_type)
                debug_print(f"✅ Found {sessions.get('total_count', 0)} {server_type} sessions", "success")
                return sessions
            return None
    except Exception as e:
        debug_print(f"❌ Failed to get {server_type} sessions: {e}", "error")
        return None

@debug_function
def quick_analyze_session_activity(username: str, password: str) -> Optional[Dict[str, Any]]:
    """
    Quick function to analyze overall session activity.
    
    Args:
        username: MC5 username
        password: MC5 password
        
    Returns:
        Activity analysis or None if failed
    """
    try:
        with SimpleMC5Client(username, password) as client:
            if client.connect():
                # Get all sessions
                all_sessions = client.client.get_active_sessions()
                sessions = all_sessions.get("sessions", [])
                
                if not sessions:
                    return {"error": "No sessions found"}
                
                # Analyze activity patterns
                total_sessions = len(sessions)
                
                # Server type analysis
                server_analysis = {}
                country_analysis = {}
                
                for session in sessions:
                    owner_info = session.get("owner_info", {})
                    
                    # Server types
                    server_type = owner_info.get("server_type", "unknown")
                    server_analysis[server_type] = server_analysis.get(server_type, 0) + 1
                    
                    # Countries
                    country = owner_info.get("country", "unknown")
                    country_analysis[country] = country_analysis.get(country, 0) + 1
                
                # Find most active server type
                most_active_server = max(server_analysis.items(), key=lambda x: x[1]) if server_analysis else ("unknown", 0)
                
                # Find most active country
                most_active_country = max(country_analysis.items(), key=lambda x: x[1]) if country_analysis else ("unknown", 0)
                
                analysis = {
                    "total_sessions": total_sessions,
                    "server_type_distribution": server_analysis,
                    "country_distribution": country_analysis,
                    "most_active_server_type": most_active_server[0],
                    "most_active_server_count": most_active_server[1],
                    "most_active_country": most_active_country[0],
                    "most_active_country_count": most_active_country[1],
                    "analysis_timestamp": __import__('datetime').datetime.now().isoformat()
                }
                
                debug_print(f"✅ Activity analysis complete: {total_sessions} sessions", "success")
                return analysis
                
            return None
    except Exception as e:
        debug_print(f"❌ Failed to analyze session activity: {e}", "error")
        return None
