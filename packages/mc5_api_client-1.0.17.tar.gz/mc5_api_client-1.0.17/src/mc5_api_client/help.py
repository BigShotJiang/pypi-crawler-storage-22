#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : help.py
# | License  | MIT License © 2026 Chizoba
# | Brief    : Help system for MC5 API Client
# ────────────────★─────────────────────────────────

"""
MC5 API Client - Built-in Help System

Provides comprehensive help for users at all levels.
"""

def help(topic: str = None) -> None:
    """
    Display help information for MC5 API Client.
    
    Args:
        topic: Help topic (basic, clan, advanced, examples, troubleshooting)
    """
    if topic is None:
        _show_overview()
    elif topic.lower() == 'basic':
        _show_basic_help()
    elif topic.lower() == 'clan':
        _show_clan_help()
    elif topic.lower() == 'advanced':
        _show_advanced_help()
    elif topic.lower() == 'examples':
        _show_examples_help()
    elif topic.lower() == 'troubleshooting':
        _show_troubleshooting_help()
    else:
        print(f"❌ Unknown topic: {topic}")
        print("📋 Available topics: basic, clan, advanced, examples, troubleshooting")
        _show_overview()

def _show_overview() -> None:
    """Show help overview."""
    print("🎮 MC5 API Client - Help System")
    print("=" * 40)
    print("📚 Available Help Topics:")
    print()
    print("🔸 basic        - Get started with basic usage")
    print("🔸 clan         - Clan management operations")
    print("🔸 advanced     - Advanced automation features")
    print("🔸 examples     - Available example files")
    print("🔸 troubleshooting - Common issues and solutions")
    print()
    print("💡 Usage: help('topic_name')")
    print("💡 Examples: help('basic'), help('clan')")

def _show_basic_help() -> None:
    """Show basic usage help."""
    print("🎮 Basic Usage - Get Started")
    print("=" * 30)
    print()
    print("🚀 QUICK START:")
    print("   pip install mc5_api_client")
    print()
    print("🔹 ONE-LINER COMMANDS:")
    print("   from mc5_api_client import quick_search")
    print("   player = quick_search('f55f', 'username', 'password')")
    print()
    print("🔹 SIMPLE CLIENT:")
    print("   from mc5_api_client import SimpleMC5Client")
    print("   client = SimpleMC5Client('username', 'password')")
    print("   client.connect()")
    print("   player = client.search_player('f55f')")
    print()
    print("🔹 QUICK KICK:")
    print("   from mc5_api_client import quick_kick")
    print("   quick_kick('9gg9', 'username', 'password', 'inactive')")

def _show_clan_help() -> None:
    """Show clan management help."""
    print("🏰 Clan Management")
    print("=" * 20)
    print()
    print("🔹 GET CLAN MEMBERS:")
    print("   client = SimpleMC5Client('user', 'pass')")
    print("   client.connect()")
    print("   members = client.get_clan_members()")
    print()
    print("🔹 KICK MEMBER:")
    print("   client.kick_member('9gg9', 'inactive for 30 days')")
    print()
    print("🔹 UPDATE CLAN:")
    print("   client.update_clan_settings(name='New Clan Name')")
    print()
    print("🔹 SMART CLEANUP:")
    print("   from mc5_api_client.simple_client import clan_cleanup")
    print("   results = clan_cleanup('user', 'pass', dry_run=True)")

def _show_advanced_help() -> None:
    """Show advanced features help."""
    print("🤖 Advanced Features")
    print("=" * 25)
    print()
    print("🔹 BATCH SEARCH:")
    print("   from mc5_api_client.simple_client import batch_search_players")
    print("   results = batch_search_players(['f55f','9gg9'], 'user', 'pass')")
    print()
    print("🔹 REAL-TIME MONITORING:")
    print("   from mc5_api_client.simple_client import monitor_clan_activity")
    print("   monitor_clan_activity('user', 'pass', check_interval=60)")
    print()
    print("🔹 CONDITIONAL LOGIC:")
    print("   for player in results['found']:")
    print("       if player['kills'] > 10000:")
    print("           print(f'Elite: {player[\"dogtag\"]}')")

def _show_examples_help() -> None:
    """Show examples help."""
    print("📚 Example Files")
    print("=" * 20)
    print()
    examples = [
        ('basic_usage.py', 'Core functionality'),
        ('simple_usage.py', 'User-friendly interface'),
        ('advanced_automation.py', 'Loops & automation'),
        ('clan_management.py', 'Clan operations'),
        ('player_stats.py', 'Player statistics'),
        ('quick_help.py', 'Help system')
    ]
    
    for filename, description in examples:
        print(f"🔸 {filename} - {description}")
    
    print()
    print("💡 Usage: python examples/filename.py")

def _show_troubleshooting_help() -> None:
    """Show troubleshooting help."""
    print("🔧 Troubleshooting")
    print("=" * 20)
    print()
    issues = [
        ('401 Error', 'Check username/password'),
        ('404 Error', 'Player not found - check dogtag'),
        ('Connection Failed', 'Check internet connection'),
        ('Permission Denied', 'Check clan role/permissions')
    ]
    
    for error, solution in issues:
        print(f"❌ {error}: {solution}")
    
    print()
    print("💡 Always use try/except blocks:")
    print("   try:")
    print("       client.connect()")
    print("   except AuthenticationError:")
    print("       print('Check credentials')")


def quick_reference() -> None:
    """Show quick reference card."""
    print("🎯 MC5 API Client - Quick Reference")
    print("=" * 40)
    print()
    print("🚀 INSTALL: pip install mc5_api_client")
    print()
    print("🔹 QUICK SEARCH:")
    print("   quick_search('f55f', 'user', 'pass')")
    print()
    print("🔹 SIMPLE CLIENT:")
    print("   client = SimpleMC5Client('user', 'pass')")
    print("   client.connect()")
    print("   player = client.search_player('f55f')")
    print()
    print("🔹 CLAN OPS:")
    print("   members = client.get_clan_members()")
    print("   client.kick_member('9gg9', 'inactive')")
    print()
    print("🔹 ERROR HANDLING:")
    print("   try: except AuthenticationError:")


def examples() -> None:
    """Show available examples."""
    print("📚 Available Examples")
    print("=" * 25)
    print()
    print("🔸 basic_usage.py - Core functionality")
    print("🔸 simple_usage.py - User-friendly interface")
    print("🔸 advanced_automation.py - Loops & automation")
    print("🔸 clan_management.py - Clan operations")
    print("🔸 player_stats.py - Player statistics")
    print("🔸 private_messaging.py - Direct messaging")
    print("🔸 squad_management.py - Squad management")
    print("🔸 message_management.py - Communication")
    print("🔸 events_and_tasks.py - Daily tasks")
    print("🔸 squad_wall_management.py - Wall posts")
    print("🔸 advanced_features.py - Advanced features")
    print("🔸 clan_management_complete.py - Complete clan ops")
    print("🔸 quick_help.py - Help system")
    print()
    print("💡 Usage: python examples/filename.py")


# Export help functions
__all__ = ['help', 'quick_reference', 'examples']
