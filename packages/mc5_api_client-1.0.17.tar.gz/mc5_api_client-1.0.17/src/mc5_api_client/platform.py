#!/usr/bin/env python3
# ────────────[ KAKUZU ]────────────────────────────
# | Discord  : kakuzu_f0
# | Telegram : kakuzu_f0
# | File     : platform.py
# | License  : MIT License © 2026 Kakuzu
# | Brief    : Platform support for MC5 API Client (PC & Android)
# ────────────────★─────────────────────────────────

from enum import Enum
from typing import Dict, Any, Optional
import random
import string

class Platform(Enum):
    """Supported platforms for MC5 API."""
    PC = "pc"
    ANDROID = "android"

class PlatformConfig:
    """Configuration for different platforms."""
    
    def __init__(self, platform: Platform):
        self.platform = platform
        self._config = self._get_platform_config()
    
    def _get_platform_config(self) -> Dict[str, Any]:
        """Get platform-specific configuration."""
        configs = {
            Platform.PC: {
                "client_id": "1924:56128:6.0.6a:pc:steam",
                "device_model": "Windows PC",
                "device_resolution": "1920x1080",
                "device_country": "US",
                "device_language": "en",
                "user_agent": "MC5-PC-Client/1.0.16",
                "platform_id": "pc"
            },
            Platform.ANDROID: {
                "client_id": "1924:56128:6.0.6a:android:googleplay",
                "device_model": "SM-S931B",  # Samsung Galaxy S23 Ultra
                "device_resolution": "2340x1080",
                "device_country": "FR",
                "device_language": "en",
                "user_agent": "MC5-Android-Client/1.0.16",
                "platform_id": "android"
            }
        }
        return configs.get(self.platform, configs[Platform.PC])
    
    def get_client_id(self) -> str:
        """Get platform-specific client ID."""
        return self._config["client_id"]
    
    def get_device_info(self) -> Dict[str, str]:
        """Get platform-specific device information."""
        return {
            "device_model": self._config["device_model"],
            "device_resolution": self._config["device_resolution"],
            "device_country": self._config["device_country"],
            "device_language": self._config["device_language"]
        }
    
    def get_user_agent(self) -> str:
        """Get platform-specific user agent."""
        return self._config["user_agent"]
    
    def get_platform_id(self) -> str:
        """Get platform identifier."""
        return self._config["platform_id"]
    
    def generate_device_id(self) -> str:
        """Generate a platform-appropriate device ID."""
        if self.platform == Platform.PC:
            # PC: Generate a 16-digit numeric device ID
            return ''.join(random.choices(string.digits, k=16))
        else:
            # Android: Generate a longer device ID (like Android device IDs)
            return ''.join(random.choices(string.digits, k=19))
    
    def generate_android_credential(self) -> str:
        """Generate Android-specific anonymous credential."""
        # Android anonymous credential format: android_v2_ANMP.GloftM5HM_<encoded_data>
        base_data = f"android_v2_ANMP.GloftM5HM_{random.randint(1000000000, 9999999999)}"
        # Simple encoding simulation (in real implementation, this would be proper base64)
        encoded = base_data.replace("ANMP", "QU5NUA==").replace("GloftM5HM", "R2xvZnRNNUhN")
        return encoded

def get_platform_config(platform: Platform = Platform.PC) -> PlatformConfig:
    """Get platform configuration."""
    return PlatformConfig(platform)

def detect_platform_from_client_id(client_id: str) -> Platform:
    """Detect platform from client ID."""
    if "android" in client_id.lower():
        return Platform.ANDROID
    elif "pc" in client_id.lower() or "steam" in client_id.lower():
        return Platform.PC
    else:
        return Platform.PC  # Default to PC

def get_android_anonymous_credential() -> str:
    """Generate Android anonymous credential."""
    config = get_platform_config(Platform.ANDROID)
    return config.generate_android_credential()

def get_pc_anonymous_credential() -> str:
    """Generate PC anonymous credential."""
    return f"win8_v2_{random.randint(100000000, 999999999)}_{random.choices(string.ascii_letters + string.digits, k=20)}"
