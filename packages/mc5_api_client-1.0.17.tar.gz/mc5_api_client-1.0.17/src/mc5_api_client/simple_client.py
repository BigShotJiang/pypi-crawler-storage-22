#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : simple_client.py
# | License  | MIT License © 2026 Chizoba
# | Brief    : User-friendly MC5 API client for non-developers
# ────────────────★─────────────────────────────────

"""
MC5 Simple API Client - User Friendly Interface

A simplified version of the MC5 API Client designed for non-developers.
Provides easy-to-use methods with automatic clan detection and simplified syntax.
"""

from typing import Optional, Dict, Any, List
from .telemetry import telemetry, report_error, report_usage, is_telemetry_enabled
from .debug import debug_function, debug_print, debug_request, debug_response, print_error_analysis
from .exceptions import MC5APIError
from .client import MC5Client
from .platform import Platform

class SimpleMC5Client:
    """
    User-friendly MC5 API client for non-developers.
    
    Automatically handles clan detection and provides simplified methods
    for common operations.
    """
    
    def __init__(self, username: str, password: str, platform: Platform = Platform.PC):
        """
        Initialize SimpleMC5Client.
        
        Args:
            username: Your MC5 username (e.g., "anonymous:your_credential")
            password: Your MC5 password
            platform: Platform to use (PC or Android)
        """
        self.username = username
        self.password = password
        self.platform = platform
        self.client = MC5Client(platform=platform)  # Initialize the client without auto-auth
        self._clan_id = None
        self._profile = None
        
    @debug_function
    def connect(self) -> bool:
        """
        Connect to MC5 API with enhanced debugging.
        
        Returns:
            True if connection successful, False otherwise
        """
        try:
            # debug_print(f"🔐 Connecting to MC5 API as {self.username[:10]}...")
            
            # Authenticate
            self.client.authenticate(self.username, self.password)
            # debug_print("✅ Authentication successful", "success")
            
            # Get profile
            profile = self.client.get_profile()
            if not profile:
                debug_print("❌ Failed to get profile", "error")
                return False
            
            self._profile = profile
            # debug_print("👤 Profile loaded: " + profile.get('name', 'Unknown'), "info")
            
            # Auto-detect clan
            clan_id = profile.get('_clan_id')
            if clan_id:
                self._clan_id = clan_id
            # debug_print("🏰 Auto-detected clan: {clan_id}", "success")
                
                # Try to get clan details
                try:
                    clan_settings = self.client.get_clan_settings(clan_id)
                    if clan_settings:
                        clan_name = clan_settings.get('name', f'Clan_{clan_id[:8]}')
                        debug_print(f"🏰 Clan name: {clan_name}", "info")
                except:
                    debug_print("⚠️ Could not get clan details", "warning")
            else:
                debug_print("ℹ️ No clan detected", "info")
            
            self.connected = True
            # debug_print("🎉 Connection successful!", "success")
            return True
            
        except Exception as e:
            debug_print(f"❌ Connection failed: {e}", "error")
            print_error_analysis(e)
            report_error(e, "SimpleMC5Client.connect", {
                "username": self.username[:10] + "..."
            })
            self.connected = False
            return False
    
    def _get_clan_name(self) -> str:
        """Get the clan name if available."""
        if not self._clan_id:
            return "No clan"
        
        try:
            clan_info = self.client.get_clan_info(self._clan_id)
            return clan_info.get('name', 'Unknown clan')
        except:
            return "Unknown clan"
    
    def search_player(self, dogtag: str) -> Optional[Dict[str, Any]]:
        """
        Search for a player by their dogtag.
        
        Args:
            dogtag: Player's dogtag (4-8 characters)
            
        Returns:
            Player information or None if not found
        """
        try:
            stats = self.client.get_player_stats_by_dogtag(dogtag)
            if 'error' not in stats:
                # Parse and return simplified info
                player_credential = list(stats.keys())[0]
                player_data = stats[player_credential]
                parsed = self.client.parse_player_stats(stats)
                
                return {
                    'dogtag': dogtag,
                    'account': player_data.get('player_info', {}).get('account', 'Unknown'),
                    'rating': parsed.get('rating', 0),
                    'kills': parsed.get('overall_stats', {}).get('total_kills', 0),
                    'deaths': parsed.get('overall_stats', {}).get('total_deaths', 0),
                    'kd_ratio': parsed.get('overall_stats', {}).get('kd_ratio', 0),
                    'headshot_percent': parsed.get('overall_stats', {}).get('headshot_percentage', 0),
                    'play_time': parsed.get('overall_stats', {}).get('play_time', 0)
                }
            else:
                print(f"❌ Player not found: {stats['error']}")
                return None
                
        except Exception as e:
            print(f"❌ Error searching player: {e}")
            return None
    
    def get_my_stats(self) -> Optional[Dict[str, Any]]:
        """
        Get your own player statistics.
        
        Returns:
            Your player information or None if error
        """
        if not self._profile:
            print("❌ Not connected. Call connect() first.")
            return None
            
        try:
            return {
                'name': self._profile.get('name', 'Unknown'),
                'level': self._profile.get('level', 0),
                'xp': self._profile.get('xp', 0),
                'clan': self._get_clan_name(),
                'clan_id': self._clan_id
            }
        except Exception as e:
            print(f"❌ Error getting your stats: {e}")
            return None
    
    def get_clan_members(self) -> List[Dict[str, Any]]:
        """
        Get all members of your clan.
        
        Returns:
            List of clan members with their stats
        """
        if not self._clan_id:
            print("❌ No clan detected")
            return []
            
        try:
            members = self.client.get_clan_members(self._clan_id)
            
            simplified_members = []
            for member in members:
                simplified_members.append({
                    'name': member.get('name', 'Unknown'),
                    'level': member.get('level', 0),
                    'xp': member.get('_xp', 0),
                    'score': member.get('_score', 0),
                    'status': member.get('status', 'Unknown'),
                    'online': member.get('online', False),
                    'killsig': member.get('_killsig_id', 'default')
                })
            
            return simplified_members
            
        except Exception as e:
            print(f"❌ Error getting clan members: {e}")
            return []
    
    def kick_member(self, dogtag: str, reason: str = "Kicked from clan") -> bool:
        """
        Kick a member from your clan by their dogtag.
        
        Args:
            dogtag: Member's dogtag to kick
            reason: Reason for kicking (optional)
            
        Returns:
            True if successful, False otherwise
        """
        if not self._clan_id:
            print("❌ No clan detected")
            return False
            
        try:
            result = self.client.kick_clan_member_by_dogtag(
                dogtag=dogtag,
                clan_id=self._clan_id,
                from_name="CLAN_ADMIN"
            )
            
            if 'error' not in result:
                print(f"✅ Successfully kicked player with dogtag {dogtag}")
                return True
            else:
                print(f"❌ Failed to kick: {result['error']}")
                return False
                
        except Exception as e:
            print(f"❌ Error kicking member: {e}")
            return False
    
    def update_clan_settings(self, name: Optional[str] = None, 
                          description: Optional[str] = None,
                          member_limit: Optional[int] = None) -> bool:
        """
        Update your clan settings.
        
        Args:
            name: New clan name (optional)
            description: New clan description (optional)
            member_limit: New member limit (optional)
            
        Returns:
            True if successful, False otherwise
        """
        if not self._clan_id:
            print("❌ No clan detected")
            return False
            
        try:
            # Build settings dict with only provided values
            settings = {}
            if name:
                settings['name'] = name
            if description:
                settings['description'] = description
            if member_limit:
                settings['member_limit'] = str(member_limit)
            
            if not settings:
                print("⚠️ No settings to update")
                return False
            
            result = self.client.update_clan_settings(self._clan_id, **settings)
            
            if 'error' not in result:
                print(f"✅ Clan settings updated successfully")
                return True
            else:
                print(f"❌ Failed to update settings: {result['error']}")
                return False
                
        except Exception as e:
            print(f"❌ Error updating clan settings: {e}")
            return False
    
    def send_message(self, dogtag: str, message: str) -> bool:
        """
        Send a private message to a player.
        
        Args:
            dogtag: Player's dogtag
            message: Message to send
            
        Returns:
            True if successful, False otherwise
        """
        try:
            # First get player info to find their credential
            player_info = self.client.get_player_stats_by_dogtag(dogtag)
            if 'error' in player_info:
                print(f"❌ Player not found: {player_info['error']}")
                return False
            
            # Get credential from player data
            player_credential = list(player_info.keys())[0]
            
            # Send message
            result = self.client.send_private_message(
                credential=player_credential,
                message=message
            )
            
            if 'error' not in result:
                print(f"✅ Message sent to {dogtag}")
                return True
            else:
                print(f"❌ Failed to send message: {result['error']}")
                return False
                
        except Exception as e:
            print(f"❌ Error sending message: {e}")
            return False
    
    def get_inbox_messages(self, limit: int = 20) -> List[Dict[str, Any]]:
        """
        Get messages from your inbox.
        
        Args:
            limit: Maximum number of messages to retrieve
            
        Returns:
            List of inbox messages
        """
        try:
            messages = self.client.get_inbox_messages(limit=limit)
            print(f"✅ Retrieved {len(messages)} messages from inbox")
            return messages
        except Exception as e:
            print(f"❌ Error getting inbox messages: {e}")
            return []
    
    def delete_message(self, message_id: str) -> bool:
        """
        Delete a single message from your inbox.
        
        Args:
            message_id: ID of the message to delete
            
        Returns:
            True if successful, False otherwise
        """
        try:
            result = self.client.delete_inbox_message(message_id)
            if 'error' not in result:
                print(f"✅ Message {message_id} deleted successfully")
                return True
            else:
                print(f"❌ Failed to delete message: {result.get('error', 'Unknown error')}")
                return False
        except Exception as e:
            print(f"❌ Error deleting message: {e}")
            return False
    
    def clear_inbox(self) -> bool:
        """
        Clear all messages from your inbox.
        
        Returns:
            True if successful, False otherwise
        """
        try:
            result = self.client.clear_inbox()
            if 'error' not in result:
                print(f"✅ Inbox cleared successfully")
                return True
            else:
                print(f"❌ Failed to clear inbox: {result.get('error', 'Unknown error')}")
                return False
        except Exception as e:
            print(f"❌ Error clearing inbox: {e}")
            return False
    
    def get_clan_requests(self, request_type: str = "membership_approval") -> List[Dict[str, Any]]:
        """
        Get pending clan membership requests.
        
        Args:
            request_type: Type of requests to retrieve
            
        Returns:
            List of clan requests
        """
        try:
            requests = self.client.get_clan_requests(request_type=request_type)
            print(f"✅ Retrieved {len(requests)} clan requests")
            return requests
        except Exception as e:
            print(f"❌ Error getting clan requests: {e}")
            return []
    
    def respond_to_clan_request(self, request_id: str, action: str, message: str = "") -> bool:
        """
        Respond to a clan membership request.
        
        Args:
            request_id: ID of the request to respond to
            action: Action to take ("accept" or "reject")
            message: Optional message for the response
            
        Returns:
            True if successful, False otherwise
        """
        try:
            result = self.client.respond_to_clan_request(request_id, action, message)
            if 'error' not in result:
                print(f"✅ Clan request {action}ed successfully")
                return True
            else:
                print(f"❌ Failed to {action} clan request: {result.get('error', 'Unknown error')}")
                return False
        except Exception as e:
            print(f"❌ Error responding to clan request: {e}")
            return False
    
    def get_inactive_members(self, days_inactive: int = 30) -> List[Dict[str, Any]]:
        """
        Get members who haven't been active for specified days.
        
        Args:
            days_inactive: Number of days to consider inactive
            
        Returns:
            List of inactive members
        """
        if not self._clan_id:
            print("❌ No clan detected")
            return []
            
        try:
            members = self.client.get_clan_members(self._clan_id)
            inactive_members = []
            
            for member in members:
                # Check last online time (simplified - you'd need to parse actual date)
                if not member.get('online', False):
                    # In a real implementation, you'd check the last_online timestamp
                    # For now, we'll consider offline members as potentially inactive
                    inactive_members.append({
                        'name': member.get('name', 'Unknown'),
                        'level': member.get('level', 0),
                        'xp': member.get('_xp', 0),
                        'status': member.get('status', 'Unknown'),
                        'online': False
                    })
            
            return inactive_members
            
        except Exception as e:
            print(f"❌ Error getting inactive members: {e}")
            return []
    
    def auto_kick_inactive_members(self, days_inactive: int = 30, dry_run: bool = True) -> Dict[str, Any]:
        """
        Automatically kick inactive members with safety checks.
        
        Args:
            days_inactive: Days of inactivity to trigger kick
            dry_run: If True, only show who would be kicked without actually kicking
            
        Returns:
            Dictionary with results
        """
        inactive_members = self.get_inactive_members(days_inactive)
        
        if not inactive_members:
            return {'kicked': 0, 'skipped': 0, 'members': []}
        
        results = {'kicked': 0, 'skipped': 0, 'members': []}
        
        for member in inactive_members:
            # Safety checks
            if member['level'] > 50:  # Don't kick high-level members
                print(f"⚠️ Skipping {member['name']} (Level {member['level']} - too high)")
                results['skipped'] += 1
                continue
                
            if 'leader' in member['status'].lower() or 'admin' in member['status'].lower():
                print(f"⚠️ Skipping {member['name']} ({member['status']} - protected role)")
                results['skipped'] += 1
                continue
            
            if dry_run:
                print(f"🔍 Would kick: {member['name']} (Level {member['level']}) - Inactive for {days_inactive}+ days")
            else:
                # Note: This would need the member's dogtag, which we'd need to fetch
                print(f"🔨 Kicking {member['name']} (Level {member['level']})")
                # client.kick_member(member['dogtag'], f"Inactive for {days_inactive} days")
                results['kicked'] += 1
            
            results['members'].append(member)
        
        return results
    
    def close(self):
        """Close the connection."""
        try:
            if self.client:
                self.client.close()
                print("✅ Connection closed")
        except:
            pass
    
    def remove_friend(self, target_user_id: str, message: str = "removed", 
                     killsig_color: str = None, killsig_name: str = None) -> bool:
        """
        Send a friend removal notification message.
        
        Args:
            target_user_id: Target player's user ID
            message: Message content (default: "removed")
            killsig_color: Kill signature color (optional)
            killsig_name: Kill signature name (optional)
            
        Returns:
            True if successful, False otherwise
        """
        try:
            print(f"🔵 Sending friend removal notification to {target_user_id}...")
            result = self.client.remove_friend(target_user_id, message, killsig_color, killsig_name)
            
            if result and not result.get('error'):
                print(f"✅ Friend removal notification sent to {target_user_id}")
                return True
            else:
                print(f"❌ Failed to send friend removal notification: {result.get('error', 'Unknown error')}")
                return False
        except Exception as e:
            print(f"❌ Error removing friend: {e}")
            return False
    
    def delete_friend_connection(self, target_user_id: str) -> bool:
        """
        Delete a friend connection (actual removal from friends list).
        
        Args:
            target_user_id: Target player's user ID
            
        Returns:
            True if successful, False otherwise
        """
        try:
            print(f"🔴 Deleting friend connection with {target_user_id}...")
            result = self.client.delete_friend_connection(target_user_id)
            
            if result and not result.get('error'):
                print(f"✅ Friend connection deleted: {target_user_id}")
                return True
            else:
                print(f"❌ Failed to delete friend connection: {result.get('error', 'Unknown error')}")
                return False
        except Exception as e:
            print(f"❌ Error deleting friend connection: {e}")
            return False
    
    def send_friend_request(self, target_user_id: str, alert_kairos: bool = True) -> bool:
        """
        Send a friend request to another player.
        
        Args:
            target_user_id: Target player's user ID
            alert_kairos: Whether to send alert notification
            
        Returns:
            True if successful, False otherwise
        """
        try:
            print(f"🤝 Sending friend request to {target_user_id}...")
            result = self.client.send_friend_request(target_user_id, alert_kairos)
            
            if result and not result.get('error'):
                print(f"✅ Friend request sent to {target_user_id}")
                return True
            else:
                print(f"❌ Failed to send friend request: {result.get('error', 'Unknown error')}")
                return False
        except Exception as e:
            print(f"❌ Error sending friend request: {e}")
            return False
    
    def get_friend_connection_status(self, target_user_id: str) -> Optional[Dict[str, Any]]:
        """
        Get the connection status with a specific friend.
        
        Args:
            target_user_id: Target player's user ID
            
        Returns:
            Connection status information or None if error
        """
        try:
            print(f"🔍 Checking friend connection status with {target_user_id}...")
            result = self.client.get_friend_connection_status(target_user_id)
            
            if result and not result.get('error'):
                print(f"✅ Friend connection status retrieved")
                return result
            else:
                print(f"ℹ️ No friend connection found with {target_user_id}")
                return None
        except Exception as e:
            print(f"❌ Error checking friend connection status: {e}")
            return None
    
    # Event Management
    
    def sign_up_for_event(self, event_id: str) -> bool:
        """
        Sign up for an event.
        
        Args:
            event_id: Event ID to sign up for
            
        Returns:
            True if successful, False otherwise
        """
        try:
            print(f"🎯 Signing up for event: {event_id}")
            result = self.client.sign_up_for_event(event_id)
            
            if result and not result.get('error'):
                print(f"✅ Successfully signed up for event {event_id}")
                return True
            else:
                print(f"❌ Failed to sign up for event: {result.get('error', 'Unknown error')}")
                return False
        except Exception as e:
            print(f"❌ Error signing up for event: {e}")
            return False
    
    def get_event_leaderboard(self, event_id: str, offset: int = 0, limit: int = 100) -> Optional[Dict[str, Any]]:
        """
        Get the leaderboard for a specific event.
        
        Args:
            event_id: Event ID
            offset: Pagination offset (default: 0)
            limit: Number of entries to retrieve (default: 100)
            
        Returns:
            Event leaderboard data or None if error
        """
        try:
            print(f"🏆 Getting event leaderboard for {event_id}...")
            result = self.client.get_event_leaderboard(event_id, offset, limit)
            
            if result and 'data' in result:
                print(f"✅ Retrieved {len(result['data'])} leaderboard entries")
                return result
            else:
                print(f"❌ Failed to get event leaderboard")
                return None
        except Exception as e:
            print(f"❌ Error getting event leaderboard: {e}")
            return None
    
    def get_my_event_leaderboard_entry(self, event_id: str, limit: int = 5) -> Optional[Dict[str, Any]]:
        """
        Get your entry and surrounding players in the event leaderboard.
        
        Args:
            event_id: Event ID
            limit: Number of surrounding entries to show (default: 5)
            
        Returns:
            Your leaderboard entry with surrounding players or None if error
        """
        try:
            print(f"🔍 Getting your event leaderboard entry for {event_id}...")
            result = self.client.get_my_event_leaderboard_entry(event_id, limit)
            
            if result and 'my_entry' in result:
                my_rank = result['my_entry'].get('rank', 'Unknown')
                my_score = result['my_entry'].get('score', 0)
                print(f"✅ Your rank: {my_rank}, Score: {my_score}")
                return result
            else:
                print(f"❌ Failed to get your event leaderboard entry")
                return None
        except Exception as e:
            print(f"❌ Error getting your event leaderboard entry: {e}")
            return None
    
    # Squad/Group Management
    
    def get_squad_invitations(self) -> List[Dict[str, Any]]:
        """
        Get all pending squad invitations.
        
        Returns:
            List of squad invitations or empty list if error
        """
        try:
            print("📨 Getting squad invitations...")
            invitations = self.client.get_squad_invitations()
            
            if invitations:
                print(f"✅ Found {len(invitations)} squad invitation(s)")
                for i, invite in enumerate(invitations, 1):
                    squad_name = invite.get('group', {}).get('name', 'Unknown Squad')
                    requester = invite.get('requester', {}).get('name', 'Unknown Player')
                    print(f"   {i}. {squad_name} from {requester}")
            else:
                print("ℹ️ No squad invitations found")
            
            return invitations
        except Exception as e:
            print(f"❌ Error getting squad invitations: {e}")
            return []
    
    def accept_squad_invitation(self, invitation: Dict[str, Any]) -> bool:
        """
        Accept a squad invitation.
        
        Args:
            invitation: Squad invitation dictionary from get_squad_invitations()
            
        Returns:
            True if successful, False otherwise
        """
        try:
            group_id = invitation.get('group_id')
            message_id = invitation.get('id')
            squad_name = invitation.get('group', {}).get('name', 'Unknown Squad')
            requester = invitation.get('requester', {}).get('name', 'Unknown Player')
            
            if not group_id or not message_id:
                print("❌ Invalid invitation data")
                return False
            
            print(f"🎯 Accepting squad invitation: {squad_name} from {requester}")
            
            # Get your profile data for optional parameters
            profile = self.client.get_profile()
            credential = profile.get('credential', '')
            
            # Accept the invitation
            result = self.client.accept_squad_invitation(
                group_id=group_id,
                credential=credential,
                killsig_color=profile.get('_killsig_color'),
                killsig_id=profile.get('_killsig_id'),
                score=profile.get('_score'),
                xp=profile.get('_xp')
            )
            
            if result:
                print(f"✅ Successfully joined squad: {squad_name}")
                
                # Delete the invitation message
                print("🗑️ Cleaning up invitation message...")
                self.client.delete_squad_invitation_message(message_id)
                print("✅ Invitation message deleted")
                
                return True
            else:
                print(f"❌ Failed to join squad: {squad_name}")
                return False
        except Exception as e:
            print(f"❌ Error accepting squad invitation: {e}")
            return False
    
    def decline_squad_invitation(self, invitation: Dict[str, Any]) -> bool:
        """
        Decline a squad invitation.
        
        Args:
            invitation: Squad invitation dictionary from get_squad_invitations()
            
        Returns:
            True if successful, False otherwise
        """
        try:
            message_id = invitation.get('id')
            squad_name = invitation.get('group', {}).get('name', 'Unknown Squad')
            requester = invitation.get('requester', {}).get('name', 'Unknown Player')
            
            if not message_id:
                print("❌ Invalid invitation data")
                return False
            
            print(f"🚫 Declining squad invitation: {squad_name} from {requester}")
            
            # Decline the invitation (just delete the message)
            result = self.client.decline_squad_invitation(message_id)
            
            if result:
                print(f"✅ Successfully declined squad invitation: {squad_name}")
                return True
            else:
                print(f"❌ Failed to decline squad invitation: {squad_name}")
                return False
        except Exception as e:
            print(f"❌ Error declining squad invitation: {e}")
            return False
    
    def accept_friend_request(self, request_id: str) -> Optional[Dict[str, Any]]:
        """
        Accept an incoming friend request.
        
        Args:
            request_id: Friend request ID to accept
            
        Returns:
            Connection details or None if error
        """
        try:
            print(f"🤝 Accepting friend request: {request_id}")
            result = self.client.accept_friend_request(request_id)
            
            if result and 'requester' in result:
                requester_name = result['requester'].get('name', 'Unknown')
                print(f"✅ Successfully accepted friend request from {requester_name}")
                
                # Show connection details
                connection_type = result.get('connection_type', 'Unknown')
                print(f"   Connection type: {connection_type}")
                
                return result
            else:
                print("❌ Failed to accept friend request")
                return None
        except Exception as e:
            print(f"❌ Error accepting friend request: {e}")
            return None
    
    def __enter__(self):
        """Context manager entry."""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.close()


# Even simpler interface for absolute beginners
def quick_search(dogtag: str, username: str, password: str) -> Optional[Dict[str, Any]]:
    """
    Quick search for a player by dogtag.
    
    Args:
        dogtag: Player's dogtag to search
        username: Your MC5 username
        password: Your MC5 password
        
    Returns:
        Player information or None if not found
    """
    with SimpleMC5Client(username, password) as client:
        if client.connect():
            return client.search_player(dogtag)
    return None


def quick_kick(dogtag: str, username: str, password: str, reason: str = "Kicked") -> bool:
    """
    Quick kick a member by dogtag.
    
    Args:
        dogtag: Member's dogtag to kick
        username: Your MC5 username
        password: Your MC5 password
        reason: Reason for kicking
        
    Returns:
        True if successful, False otherwise
    """
    with SimpleMC5Client(username, password) as client:
        if client.connect():
            return client.kick_member(dogtag, reason)
    return False


def batch_search_players(dogtags: List[str], username: str, password: str) -> Dict[str, Any]:
    """
    Search for multiple players at once.
    
    Args:
        dogtags: List of dogtags to search
        username: Your MC5 username
        password: Your MC5 password
        
    Returns:
        Dictionary with search results
    """
    results = {'found': [], 'not_found': [], 'errors': []}
    
    with SimpleMC5Client(username, password) as client:
        if client.connect():
            for dogtag in dogtags:
                try:
                    player = client.search_player(dogtag)
                    if player:
                        results['found'].append(player)
                        print(f"✅ Found {dogtag}: {player['kills']:,} kills")
                    else:
                        results['not_found'].append(dogtag)
                        print(f"❌ Not found: {dogtag}")
                except Exception as e:
                    results['errors'].append({'dogtag': dogtag, 'error': str(e)})
                    print(f"⚠️ Error with {dogtag}: {e}")
    
    return results


def quick_remove_friend(target_user_id: str, username: str, password: str, 
                       message: str = "removed") -> bool:
    """
    Quick remove a friend (send notification and delete connection).
    
    Args:
        target_user_id: Target player's user ID
        username: Your MC5 username
        password: Your MC5 password
        message: Message content (default: "removed")
        
    Returns:
        True if successful, False otherwise
    """
    with SimpleMC5Client(username, password) as client:
        if client.connect():
            # Send notification first
            notification_sent = client.remove_friend(target_user_id, message)
            # Then delete connection
            connection_deleted = client.delete_friend_connection(target_user_id)
            return notification_sent and connection_deleted
    return False


def quick_send_friend_request(target_user_id: str, username: str, password: str) -> bool:
    """
    Quick send a friend request.
    
    Args:
        target_user_id: Target player's user ID
        username: Your MC5 username
        password: Your MC5 password
        
    Returns:
        True if successful, False otherwise
    """
    with SimpleMC5Client(username, password) as client:
        if client.connect():
            return client.send_friend_request(target_user_id)
    return False


def quick_check_friend_status(target_user_id: str, username: str, password: str) -> Optional[Dict[str, Any]]:
    """
    Quick check friend connection status.
    
    Args:
        target_user_id: Target player's user ID
        username: Your MC5 username
        password: Your MC5 password
        
    Returns:
        Connection status information or None if not found
    """
    with SimpleMC5Client(username, password) as client:
        if client.connect():
            return client.get_friend_connection_status(target_user_id)
    return None


def quick_sign_up_for_event(event_id: str, username: str, password: str) -> bool:
    """
    Quick sign up for an event.
    
    Args:
        event_id: Event ID to sign up for
        username: Your MC5 username
        password: Your MC5 password
        
    Returns:
        True if successful, False otherwise
    """
    with SimpleMC5Client(username, password) as client:
        if client.connect():
            return client.sign_up_for_event(event_id)
    return False


def quick_get_event_leaderboard(event_id: str, username: str, password: str, 
                               offset: int = 0, limit: int = 100) -> Optional[Dict[str, Any]]:
    """
    Quick get event leaderboard.
    
    Args:
        event_id: Event ID
        username: Your MC5 username
        password: Your MC5 password
        offset: Pagination offset (default: 0)
        limit: Number of entries to retrieve (default: 100)
        
    Returns:
        Event leaderboard data or None if error
    """
    with SimpleMC5Client(username, password) as client:
        if client.connect():
            return client.get_event_leaderboard(event_id, offset, limit)
    return None


def quick_get_my_event_rank(event_id: str, username: str, password: str, 
                          limit: int = 5) -> Optional[Dict[str, Any]]:
    """
    Quick get your event leaderboard entry and rank.
    
    Args:
        event_id: Event ID
        username: Your MC5 username
        password: Your MC5 password
        limit: Number of surrounding entries to show (default: 5)
        
    Returns:
        Your leaderboard entry with surrounding players or None if error
    """
    with SimpleMC5Client(username, password) as client:
        if client.connect():
            return client.get_my_event_leaderboard_entry(event_id, limit)
    return None


def quick_get_squad_invitations(username: str, password: str) -> List[Dict[str, Any]]:
    """
    Quick get squad invitations.
    
    Args:
        username: Your MC5 username
        password: Your MC5 password
        
    Returns:
        List of squad invitations or empty list if error
    """
    with SimpleMC5Client(username, password) as client:
        if client.connect():
            return client.get_squad_invitations()
    return []


def quick_accept_squad_invitation(invitation: Dict[str, Any], username: str, password: str) -> bool:
    """
    Quick accept a squad invitation.
    
    Args:
        invitation: Squad invitation dictionary from quick_get_squad_invitations()
        username: Your MC5 username
        password: Your MC5 password
        
    Returns:
        True if successful, False otherwise
    """
    with SimpleMC5Client(username, password) as client:
        if client.connect():
            return client.accept_squad_invitation(invitation)
    return False


def quick_decline_squad_invitation(invitation: Dict[str, Any], username: str, password: str) -> bool:
    """
    Quick decline a squad invitation.
    
    Args:
        invitation: Squad invitation dictionary from quick_get_squad_invitations()
        username: Your MC5 username
        password: Your MC5 password
        
    Returns:
        True if successful, False otherwise
    """
    with SimpleMC5Client(username, password) as client:
        if client.connect():
            return client.decline_squad_invitation(invitation)
    return False


def quick_accept_friend_request(request_id: str, username: str, password: str) -> Optional[Dict[str, Any]]:
    """
    Quick accept a friend request.
    
    Args:
        request_id: Friend request ID to accept
        username: Your MC5 username
        password: Your MC5 password
        
    Returns:
        Connection details or None if error
    """
    with SimpleMC5Client(username, password) as client:
        if client.connect():
            return client.accept_friend_request(request_id)
    return None


def clan_cleanup(username: str, password: str, 
                 inactive_days: int = 30,
                 min_level: int = 10,
                 dry_run: bool = True) -> Dict[str, Any]:
    """
    Comprehensive clan cleanup with conditional logic.
    
    Args:
        username: Your MC5 username
        password: Your MC5 password
        inactive_days: Days of inactivity to consider
        min_level: Minimum level to protect from kicking
        dry_run: If True, only show what would be done
        
    Returns:
        Dictionary with cleanup results
    """
    results = {
        'total_members': 0,
        'active_members': 0,
        'inactive_members': 0,
        'would_kick': 0,
        'protected': 0,
        'actions': []
    }
    
    with SimpleMC5Client(username, password) as client:
        if not client.connect():
            return results
        
        members = client.get_clan_members()
        results['total_members'] = len(members)
        
        for member in members:
            # Conditional logic for each member
            if member.get('online', False):
                results['active_members'] += 1
                results['actions'].append(f"✅ {member['name']} - Online (protected)")
                continue
            
            # Check level protection
            if member.get('level', 0) >= min_level:
                results['protected'] += 1
                results['actions'].append(f"🛡️ {member['name']} - Level {member['level']} (protected)")
                continue
            
            # Check role protection
            status = member.get('status', '').lower()
            if any(role in status for role in ['leader', 'admin', 'officer']):
                results['protected'] += 1
                results['actions'].append(f"👑 {member['name']} - {member['status']} (protected)")
                continue
            
            # Member is inactive and not protected
            results['inactive_members'] += 1
            results['would_kick'] += 1
            
            if dry_run:
                results['actions'].append(f"🔍 Would kick: {member['name']} - Level {member['level']}, Inactive")
            else:
                # Note: Would need dogtag for actual kicking
                results['actions'].append(f"🔨 Kicked: {member['name']} - Level {member['level']}")
    
    return results


def monitor_clan_activity(username: str, password: str, 
                         check_interval: int = 60,
                         max_checks: int = 10) -> None:
    """
    Monitor clan activity with while loop.
    
    Args:
        username: Your MC5 username
        password: Your MC5 password
        check_interval: Seconds between checks
        max_checks: Maximum number of checks to perform
    """
    import time
    
    check_count = 0
    
    with SimpleMC5Client(username, password) as client:
        if not client.connect():
            return
        
        print(f"🔍 Starting clan activity monitoring (checking every {check_interval}s)")
        
        while check_count < max_checks:
            check_count += 1
            
            try:
                members = client.get_clan_members()
                online_count = sum(1 for m in members if m.get('online', False))
                
                print(f"Check {check_count}/{max_checks}: {online_count}/{len(members)} members online")
                
                # Conditional alerts
                if online_count == 0:
                    print("🚨 Alert: No members online!")
                elif online_count > len(members) * 0.8:
                    print("🎉 High activity: Most members are online!")
                
                # Break if all members are online
                if online_count == len(members):
                    print("✅ All members are online! Stopping monitor.")
                    break
                    
            except Exception as e:
                print(f"⚠️ Error during check {check_count}: {e}")
            
            # Wait before next check (except after last check)
            if check_count < max_checks:
                time.sleep(check_interval)
        
        print(f"🏁 Monitoring completed after {check_count} checks")
