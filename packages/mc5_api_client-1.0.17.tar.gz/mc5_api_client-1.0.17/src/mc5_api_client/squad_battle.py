#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : squad_battle.py
# | License  | MIT License © 2026 Chizoba
# | Brief    | Squad battle and clan battle APIs
# ────────────────★─────────────────────────────────

import json
from typing import Optional, Dict, Any, List
from .telemetry import report_error, report_usage
from .debug import debug_function, debug_print

class SquadBattleMixin:
    """Mixin class for squad battle and clan battle functionality."""
    
    @debug_function
    def create_squad_battle_room(self, room_name: Optional[str] = None, capacity: int = 2) -> Dict[str, Any]:
        """
        Create a squad battle room.
        
        Args:
            room_name: Optional room name (generated if not provided)
            capacity: Room capacity (default: 2 for squad battles)
            
        Returns:
            Room creation response with room_id, lobby_host, lobby_port
        """
        try:
            import uuid
            
            if not room_name:
                room_name = str(uuid.uuid4())
            
            url = f"{self.BASE_URLS['anubisfinder']}/rooms/1875:55979:6.0.0a:windows:windows/quick_join"
            
            data = {
                "access_token": self._token_data["access_token"],
                "server_type": "mp_server",
                "filters": '["_name=clan_owners&creator_datacenter=None"]',
                "create_command": json.dumps({
                    "_name": "clan_owners",
                    "capacity": capacity,
                    "server_type": "mp_server"
                }),
                "name": room_name,
                "http_room": "false"
            }
            
            debug_print(f"Creating squad battle room: {room_name}", "info")
            result = self._make_request("POST", url, data=data)
            
            if result:
                debug_print(f"✅ Squad battle room created: {result.get('room_id')}", "success")
                report_usage("create_squad_battle_room", True, 0, {
                    "room_id": result.get('room_id'),
                    "capacity": capacity
                })
            
            return result
            
        except Exception as e:
            debug_print(f"❌ Failed to create squad battle room: {e}", "error")
            report_error(e, "create_squad_battle_room", {
                "room_name": room_name,
                "capacity": capacity
            })
            raise
    
    @debug_function
    def send_squad_battle_notification(self, 
                                     room_id: str,
                                     lobby_host: str,
                                     lobby_port: int,
                                     message: str = "Squad battle starting!") -> Dict[str, Any]:
        """
        Send squad battle notification via multicast message.
        
        Args:
            room_id: Room ID from battle creation
            lobby_host: Lobby host from battle creation
            lobby_port: Lobby port from battle creation
            message: Notification message
            
        Returns:
            Notification send result
        """
        try:
            url = f"{self.BASE_URLS['hermes']}/messages/inbox/multicast"
            
            # Create payload for squad battle notification
            payload_data = {
                "aps": {
                    "alert": {
                        "action-loc-key": "BL",
                        "loc-key": "M"
                    },
                    "sound": "pn_squad_invite.wav"
                },
                "h": lobby_host,
                "m": str(lobby_port),
                "p": 36843,  # Default port
                "r": room_id,
                "ts": int(__import__('time').time()),
                "type": "sb"  # Squad battle
            }
            
            data = {
                "access_token": self._token_data["access_token"],
                "payload": json.dumps(payload_data),
                "credentials": "[]",
                "alert_kairos": "true"
            }
            
            debug_print(f"Sending squad battle notification to room: {room_id}", "info")
            result = self._make_request("POST", url, data=data)
            
            if result:
                debug_print("✅ Squad battle notification sent", "success")
                report_usage("send_squad_battle_notification", True, 0, {
                    "room_id": room_id,
                    "lobby_host": lobby_host
                })
            
            return result
            
        except Exception as e:
            debug_print(f"❌ Failed to send squad battle notification: {e}", "error")
            report_error(e, "send_squad_battle_notification", {
                "room_id": room_id,
                "lobby_host": lobby_host
            })
            raise
    
    @debug_function
    def get_squad_wall_messages(self, 
                              squad_id: str,
                              limit: int = 20,
                              sort_type: str = "chronological",
                              include_fields: str = "actor,creation,id,text") -> List[Dict[str, Any]]:
        """
        Get squad wall messages including battle results.
        
        Args:
            squad_id: Squad/group ID
            limit: Number of messages to retrieve (default: 20)
            sort_type: Sort order (chronological, etc.)
            include_fields: Fields to include in response
            
        Returns:
            List of wall messages with battle information
        """
        try:
            url = f"{self.BASE_URLS['osiris']}/groups/{squad_id}/wall"
            
            params = {
                "access_token": self._token_data["access_token"],
                "sort_type": sort_type,
                "limit": str(limit),
                "include_fields": include_fields
            }
            
            debug_print(f"Getting squad wall messages for: {squad_id}", "info")
            result = self._make_request("GET", url, params=params)
            
            if result:
                battle_messages = []
                for message in result:
                    # Parse battle messages
                    if message.get("text"):
                        try:
                            text_data = json.loads(message["text"])
                            if text_data.get("msg_type") == 2:  # Battle result
                                battle_info = {
                                    "id": message.get("id"),
                                    "creation": message.get("creation"),
                                    "actor": message.get("actor"),
                                    "battle_data": text_data
                                }
                                battle_messages.append(battle_info)
                        except json.JSONDecodeError:
                            # Skip non-JSON messages
                            continue
                
                debug_print(f"✅ Found {len(battle_messages)} battle messages", "success")
                report_usage("get_squad_wall_messages", True, 0, {
                    "squad_id": squad_id,
                    "battle_messages_count": len(battle_messages)
                })
                
                return battle_messages
            
            return []
            
        except Exception as e:
            debug_print(f"❌ Failed to get squad wall messages: {e}", "error")
            report_error(e, "get_squad_wall_messages", {
                "squad_id": squad_id,
                "limit": limit
            })
            raise
    
    @debug_function
    def post_squad_battle_result(self,
                                squad_id: str,
                                squad_score: int,
                                enemy_squad_id: str,
                                enemy_squad_name: str,
                                enemy_squad_logo: str = "31",
                                enemy_squad_logo_color1: str = "16428544",
                                enemy_squad_logo_color2: str = "16428544",
                                enemy_squad_score: int = 0) -> Dict[str, Any]:
        """
        Post squad battle result to squad wall.
        
        Args:
            squad_id: Your squad ID
            squad_score: Your squad's score
            enemy_squad_id: Enemy squad ID
            enemy_squad_name: Enemy squad name
            enemy_squad_logo: Enemy squad logo ID
            enemy_squad_logo_color1: Enemy squad logo color 1
            enemy_squad_logo_color2: Enemy squad logo color 2
            enemy_squad_score: Enemy squad's score
            
        Returns:
            Post result
        """
        try:
            url = f"{self.BASE_URLS['osiris']}/groups/{squad_id}/wall"
            
            # Create battle result message
            battle_data = {
                "msg_type": 2,  # Battle result message type
                "squad_score": squad_score,
                "enemy_squad_id": enemy_squad_id,
                "enemy_squad_name": enemy_squad_name,
                "enemy_squad_logo": enemy_squad_logo,
                "enemy_squad_logo_color1": enemy_squad_logo_color1,
                "enemy_squad_logo_color2": enemy_squad_logo_color2,
                "enemy_squad_score": enemy_squad_score
            }
            
            data = {
                "access_token": self._token_data["access_token"],
                "text": json.dumps(battle_data)
            }
            
            debug_print(f"Posting battle result: {squad_score} vs {enemy_squad_score}", "info")
            result = self._make_request("POST", url, data=data)
            
            if result:
                debug_print("✅ Battle result posted to squad wall", "success")
                report_usage("post_squad_battle_result", True, 0, {
                    "squad_id": squad_id,
                    "squad_score": squad_score,
                    "enemy_squad_score": enemy_squad_score
                })
            
            return result
            
        except Exception as e:
            debug_print(f"❌ Failed to post battle result: {e}", "error")
            report_error(e, "post_squad_battle_result", {
                "squad_id": squad_id,
                "squad_score": squad_score,
                "enemy_squad_id": enemy_squad_id
            })
            raise
    
    @debug_function
    def get_squad_battle_history(self, squad_id: str, limit: int = 50) -> List[Dict[str, Any]]:
        """
        Get complete squad battle history from wall messages.
        
        Args:
            squad_id: Squad ID
            limit: Number of messages to analyze
            
        Returns:
            List of battle results with detailed information
        """
        try:
            # Get wall messages
            messages = self.get_squad_wall_messages(squad_id, limit=limit)
            
            battle_history = []
            for message in messages:
                battle_data = message.get("battle_data", {})
                
                # Extract battle information
                battle_info = {
                    "message_id": message.get("id"),
                    "creation_time": message.get("creation"),
                    "posted_by": message.get("actor", {}).get("name", "Unknown"),
                    "squad_score": battle_data.get("squad_score", 0),
                    "enemy_squad_id": battle_data.get("enemy_squad_id"),
                    "enemy_squad_name": battle_data.get("enemy_squad_name"),
                    "enemy_squad_logo": battle_data.get("enemy_squad_logo"),
                    "enemy_squad_logo_color1": battle_data.get("enemy_squad_logo_color1"),
                    "enemy_squad_logo_color2": battle_data.get("enemy_squad_logo_color2"),
                    "enemy_squad_score": battle_data.get("enemy_squad_score", 0),
                    "result": "Victory" if battle_data.get("squad_score", 0) > battle_data.get("enemy_squad_score", 0) else "Defeat"
                }
                
                battle_history.append(battle_info)
            
            debug_print(f"✅ Retrieved {len(battle_history)} battle results", "success")
            return battle_history
            
        except Exception as e:
            debug_print(f"❌ Failed to get battle history: {e}", "error")
            report_error(e, "get_squad_battle_history", {"squad_id": squad_id})
            raise
    
    @debug_function
    def analyze_squad_performance(self, squad_id: str, limit: int = 100) -> Dict[str, Any]:
        """
        Analyze squad battle performance statistics.
        
        Args:
            squad_id: Squad ID
            limit: Number of battles to analyze
            
        Returns:
            Performance statistics
        """
        try:
            battles = self.get_squad_battle_history(squad_id, limit=limit)
            
            if not battles:
                return {"error": "No battle history found"}
            
            # Calculate statistics
            total_battles = len(battles)
            victories = sum(1 for battle in battles if battle["result"] == "Victory")
            defeats = total_battles - victories
            
            total_score = sum(battle["squad_score"] for battle in battles)
            total_enemy_score = sum(battle["enemy_squad_score"] for battle in battles)
            
            avg_score = total_score / total_battles if total_battles > 0 else 0
            avg_enemy_score = total_enemy_score / total_battles if total_battles > 0 else 0
            
            win_rate = (victories / total_battles * 100) if total_battles > 0 else 0
            
            # Find most common enemies
            enemy_frequency = {}
            for battle in battles:
                enemy = battle["enemy_squad_name"]
                enemy_frequency[enemy] = enemy_frequency.get(enemy, 0) + 1
            
            top_enemies = sorted(enemy_frequency.items(), key=lambda x: x[1], reverse=True)[:5]
            
            stats = {
                "squad_id": squad_id,
                "total_battles": total_battles,
                "victories": victories,
                "defeats": defeats,
                "win_rate": round(win_rate, 2),
                "total_score": total_score,
                "total_enemy_score": total_enemy_score,
                "average_score": round(avg_score, 2),
                "average_enemy_score": round(avg_enemy_score, 2),
                "score_difference": total_score - total_enemy_score,
                "top_enemies": [{"name": name, "battles": count} for name, count in top_enemies],
                "recent_performance": battles[:10]  # Last 10 battles
            }
            
            debug_print(f"✅ Squad performance analyzed: {win_rate:.1f}% win rate", "success")
            return stats
            
        except Exception as e:
            debug_print(f"❌ Failed to analyze squad performance: {e}", "error")
            report_error(e, "analyze_squad_performance", {"squad_id": squad_id})
            raise
    
    @debug_function
    def post_squad_wall_message(self,
                                squad_id: str,
                                message: str,
                                player_killsig: str = "default_killsig_42",
                                player_killsig_color: int = -974646126,
                                language: str = "en",
                                activity_type: str = "user_post") -> Dict[str, Any]:
        """
        Post a simple message to squad wall.
        
        Args:
            squad_id: Squad/group ID
            message: Message text to post
            player_killsig: Player kill signature ID
            player_killsig_color: Kill signature color
            language: Message language (default: "en")
            activity_type: Activity type (default: "user_post")
            
        Returns:
            Post result with message ID
        """
        try:
            url = f"{self.BASE_URLS['osiris']}/groups/{squad_id}/wall"
            
            # Create message payload
            message_data = {
                "msg_body": message,
                "msg_type": 0,  # Simple message type
                "playerKillSign": player_killsig,
                "playerKillSignColor": player_killsig_color
            }
            
            data = {
                "access_token": self._token_data["access_token"],
                "text": json.dumps(message_data),
                "language": language,
                "activity_type": activity_type,
                "alert_kairos": "false"
            }
            
            debug_print(f"Posting message to squad wall: {message[:30]}...", "info")
            result = self._make_request("POST", url, data=data)
            
            if result:
                message_id = result.get('id')
                debug_print(f"✅ Message posted successfully! ID: {message_id}", "success")
                report_usage("post_squad_wall_message", True, 0, {
                    "squad_id": squad_id,
                    "message_id": message_id,
                    "message_length": len(message)
                })
            
            return result
            
        except Exception as e:
            debug_print(f"❌ Failed to post wall message: {e}", "error")
            report_error(e, "post_squad_wall_message", {
                "squad_id": squad_id,
                "message": message[:50]
            })
            raise
