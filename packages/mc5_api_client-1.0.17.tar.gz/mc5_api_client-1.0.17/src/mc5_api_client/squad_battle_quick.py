#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : squad_battle_quick.py
# | License  | MIT License © 2026 Chizoba
# | Brief    | Quick functions for squad battle operations
# ────────────────★─────────────────────────────────

from typing import Optional, Dict, Any, List
from .simple_client import SimpleMC5Client
from .telemetry import report_usage
from .debug import debug_function, debug_print

@debug_function
def quick_create_squad_battle_room(username: str, password: str, capacity: int = 2) -> Optional[Dict[str, Any]]:
    """
    Quick function to create a squad battle room.
    
    Args:
        username: MC5 username
        password: MC5 password
        capacity: Room capacity (default: 2)
        
    Returns:
        Room creation response or None if failed
    """
    try:
        with SimpleMC5Client(username, password) as client:
            if client.connect():
                result = client.client.create_squad_battle_room(capacity=capacity)
                debug_print(f"✅ Squad battle room created: {result.get('room_id')}", "success")
                return result
            return None
    except Exception as e:
        debug_print(f"❌ Failed to create squad battle room: {e}", "error")
        return None

@debug_function
def quick_post_squad_battle_result(username: str, password: str,
                                   squad_id: str,
                                   squad_score: int,
                                   enemy_squad_id: str,
                                   enemy_squad_name: str,
                                   enemy_squad_score: int = 0) -> bool:
    """
    Quick function to post squad battle result.
    
    Args:
        username: MC5 username
        password: MC5 password
        squad_id: Your squad ID
        squad_score: Your squad's score
        enemy_squad_id: Enemy squad ID
        enemy_squad_name: Enemy squad name
        enemy_squad_score: Enemy squad's score
        
    Returns:
        True if successful, False otherwise
    """
    try:
        with SimpleMC5Client(username, password) as client:
            if client.connect():
                result = client.client.post_squad_battle_result(
                    squad_id=squad_id,
                    squad_score=squad_score,
                    enemy_squad_id=enemy_squad_id,
                    enemy_squad_name=enemy_squad_name,
                    enemy_squad_score=enemy_squad_score
                )
                debug_print(f"✅ Battle result posted: {squad_score} vs {enemy_squad_score}", "success")
                return bool(result)
            return False
    except Exception as e:
        debug_print(f"❌ Failed to post battle result: {e}", "error")
        return False

@debug_function
def quick_get_squad_battle_history(username: str, password: str, squad_id: str, limit: int = 50) -> Optional[List[Dict[str, Any]]]:
    """
    Quick function to get squad battle history.
    
    Args:
        username: MC5 username
        password: MC5 password
        squad_id: Squad ID
        limit: Number of battles to retrieve
        
    Returns:
        List of battle results or None if failed
    """
    try:
        with SimpleMC5Client(username, password) as client:
            if client.connect():
                battles = client.client.get_squad_battle_history(squad_id, limit=limit)
                debug_print(f"✅ Retrieved {len(battles)} battle results", "success")
                return battles
            return None
    except Exception as e:
        debug_print(f"❌ Failed to get battle history: {e}", "error")
        return None

@debug_function
def quick_analyze_squad_performance(username: str, password: str, squad_id: str, limit: int = 100) -> Optional[Dict[str, Any]]:
    """
    Quick function to analyze squad performance.
    
    Args:
        username: MC5 username
        password: MC5 password
        squad_id: Squad ID
        limit: Number of battles to analyze
        
    Returns:
        Performance statistics or None if failed
    """
    try:
        with SimpleMC5Client(username, password) as client:
            if client.connect():
                stats = client.client.analyze_squad_performance(squad_id, limit=limit)
                debug_print(f"✅ Squad performance analyzed: {stats.get('win_rate', 0)}% win rate", "success")
                return stats
            return None
    except Exception as e:
        debug_print(f"❌ Failed to analyze squad performance: {e}", "error")
        return None

@debug_function
def quick_get_squad_wall_messages(username: str, password: str, squad_id: str, limit: int = 20) -> Optional[List[Dict[str, Any]]]:
    """
    Quick function to get squad wall messages.
    
    Args:
        username: MC5 username
        password: MC5 password
        squad_id: Squad ID
        limit: Number of messages to retrieve
        
    Returns:
        List of wall messages or None if failed
    """
    try:
        with SimpleMC5Client(username, password) as client:
            if client.connect():
                messages = client.client.get_squad_wall_messages(squad_id, limit=limit)
                debug_print(f"✅ Retrieved {len(messages)} wall messages", "success")
                return messages
            return None
    except Exception as e:
        debug_print(f"❌ Failed to get wall messages: {e}", "error")
        return None

@debug_function
def quick_post_squad_wall_message(username: str, password: str,
                                   squad_id: str,
                                   message: str,
                                   player_killsig: str = "default_killsig_42",
                                   player_killsig_color: int = -974646126) -> Optional[str]:
    """
    Quick function to post a message to squad wall.
    
    Args:
        username: MC5 username
        password: MC5 password
        squad_id: Squad ID
        message: Message text to post
        player_killsig: Player kill signature ID
        player_killsig_color: Kill signature color
        
    Returns:
        Message ID if successful, None otherwise
    """
    try:
        with SimpleMC5Client(username, password) as client:
            if client.connect():
                result = client.client.post_squad_wall_message(
                    squad_id=squad_id,
                    message=message,
                    player_killsig=player_killsig,
                    player_killsig_color=player_killsig_color
                )
                
                if result:
                    message_id = result.get('id')
                    debug_print(f"✅ Message posted! ID: {message_id}", "success")
                    return message_id
                return None
            return None
    except Exception as e:
        debug_print(f"❌ Failed to post wall message: {e}", "error")
        return None

@debug_function
def quick_send_squad_battle_notification(username: str, password: str,
                                       room_id: str,
                                       lobby_host: str,
                                       lobby_port: int) -> bool:
    """
    Quick function to send squad battle notification.
    
    Args:
        username: MC5 username
        password: MC5 password
        room_id: Room ID from battle creation
        lobby_host: Lobby host from battle creation
        lobby_port: Lobby port from battle creation
        
    Returns:
        True if successful, False otherwise
    """
    try:
        with SimpleMC5Client(username, password) as client:
            if client.connect():
                result = client.client.send_squad_battle_notification(
                    room_id=room_id,
                    lobby_host=lobby_host,
                    lobby_port=lobby_port
                )
                debug_print("✅ Squad battle notification sent", "success")
                return bool(result)
            return False
    except Exception as e:
        debug_print(f"❌ Failed to send notification: {e}", "error")
        return False
