# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : __init__.py
# | License  : MIT License © 2026 Chizoba
# | Brief    : Test package for MC5 API Client
# ────────────────★─────────────────────────────────

"""
Test package for MC5 API Client.
"""
