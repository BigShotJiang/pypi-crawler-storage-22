#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : test_auth.py
# | License  : MIT License © 2026 Chizoba
# | Brief    : Tests for authentication module
# ────────────────★─────────────────────────────────

"""
Tests for the authentication module.
"""

import pytest
from unittest.mock import Mock, patch, MagicMock
import time

from mc5_api_client.auth import TokenGenerator
from mc5_api_client.exceptions import (
    AuthenticationError,
    InvalidCredentialsError,
    NetworkError
)


class TestTokenGenerator:
    """Test cases for TokenGenerator class."""
    
    def setup_method(self):
        """Setup test fixtures."""
        self.token_gen = TokenGenerator()
    
    def teardown_method(self):
        """Cleanup after tests."""
        self.token_gen.close()
    
    def test_init(self):
        """Test TokenGenerator initialization."""
        assert self.token_gen.client_id == "1875:55979:6.0.0a:windows:windows"
        assert self.token_gen.auth_url == "https://eur-janus.gameloft.com:443/authorize"
        assert self.token_gen.timeout == 30
        assert self.token_gen.max_retries == 3
        assert self.token_gen.session is not None
    
    def test_generate_device_id(self):
        """Test device ID generation."""
        device_id1 = self.token_gen.generate_device_id()
        device_id2 = self.token_gen.generate_device_id()
        
        assert len(device_id1) == 19
        assert len(device_id2) == 19
        assert device_id1.isdigit()
        assert device_id2.isdigit()
        assert device_id1 != device_id2
    
    @patch('mc5_api_client.auth.requests.Session.post')
    def test_generate_token_success(self, mock_post):
        """Test successful token generation."""
        # Mock successful response
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "access_token": "test-token,scope1 scope2,client_id,1234567890,credential,device_id,signature"
        }
        mock_post.return_value = mock_response
        
        result = self.token_gen.generate_token(
            username="test:user",
            password="test_pass",
            device_id="1234567890123456789"
        )
        
        assert result["access_token"] == "test-token,scope1 scope2,client_id,1234567890,credential,device_id,signature"
        assert result["token_id"] == "test-token"
        assert result["scopes"] == ["scope1", "scope2"]
        assert result["client_id"] == "client_id"
        assert result["expires_at"] == 1234567890.0
        assert result["credential"] == "credential"
        assert result["device_id"] == "device_id"
        assert result["signature"] == "signature"
        assert result["device_id_used"] == "1234567890123456789"
        assert "expires_in" in result
        assert "expires_at_datetime" in result
    
    @patch('mc5_api_client.auth.requests.Session.post')
    def test_generate_token_invalid_credentials(self, mock_post):
        """Test token generation with invalid credentials."""
        mock_response = Mock()
        mock_response.status_code = 401
        mock_post.return_value = mock_response
        
        with pytest.raises(InvalidCredentialsError):
            self.token_gen.generate_token(
                username="invalid:user",
                password="wrong_pass"
            )
    
    @patch('mc5_api_client.auth.requests.Session.post')
    def test_generate_token_network_error(self, mock_post):
        """Test token generation with network error."""
        mock_post.side_effect = Exception("Network error")
        
        with pytest.raises(NetworkError):
            self.token_gen.generate_token(
                username="test:user",
                password="test_pass"
            )
    
    @patch('mc5_api_client.auth.requests.Session.post')
    def test_generate_admin_token(self, mock_post):
        """Test admin token generation."""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "access_token": "admin-token,admin_scope,client_id,1234567890,game:mc5_system,device_id"
        }
        mock_post.return_value = mock_response
        
        result = self.token_gen.generate_admin_token()
        
        assert result["access_token"] == "admin-token,admin_scope,client_id,1234567890,game:mc5_system,device_id"
        assert result["credential"] == "game:mc5_system"
    
    def test_validate_token_valid(self):
        """Test token validation for valid token."""
        future_time = time.time() + 3600  # 1 hour from now
        token_data = {
            "expires_at": future_time
        }
        
        assert self.token_gen.validate_token(token_data) is True
    
    def test_validate_token_expired(self):
        """Test token validation for expired token."""
        past_time = time.time() - 3600  # 1 hour ago
        token_data = {
            "expires_at": past_time
        }
        
        assert self.token_gen.validate_token(token_data) is False
    
    def test_validate_token_missing_expiry(self):
        """Test token validation with missing expiry."""
        token_data = {}
        
        assert self.token_gen.validate_token(token_data) is False
    
    def test_validate_token_none(self):
        """Test token validation with None token."""
        assert self.token_gen.validate_token(None) is False
    
    @patch('mc5_api_client.auth.TokenGenerator.generate_token')
    def test_refresh_token_if_needed_valid(self, mock_generate):
        """Test token refresh when token is still valid."""
        future_time = time.time() + 3600
        token_data = {
            "expires_at": future_time,
            "device_id_used": "test_device_id"
        }
        
        result = self.token_gen.refresh_token_if_needed(
            token_data,
            "test:user",
            "test_pass"
        )
        
        assert result == token_data
        mock_generate.assert_not_called()
    
    @patch('mc5_api_client.auth.TokenGenerator.generate_token')
    def test_refresh_token_if_needed_expired(self, mock_generate):
        """Test token refresh when token is expired."""
        past_time = time.time() - 3600
        old_token_data = {
            "expires_at": past_time,
            "device_id_used": "test_device_id"
        }
        
        new_token_data = {
            "access_token": "new-token",
            "expires_at": time.time() + 3600
        }
        mock_generate.return_value = new_token_data
        
        result = self.token_gen.refresh_token_if_needed(
            old_token_data,
            "test:user",
            "test_pass"
        )
        
        assert result == new_token_data
        mock_generate.assert_called_once_with(
            "test:user",
            "test_pass",
            "test_device_id"
        )
    
    def test_get_token_info(self):
        """Test parsing token information."""
        token = "token-id,scope1 scope2,client-id,1234567890,credential,device-id,signature"
        
        result = self.token_gen.get_token_info(token)
        
        assert result["token_id"] == "token-id"
        assert result["scopes"] == ["scope1", "scope2"]
        assert result["client_id"] == "client-id"
        assert result["expires_at"] == 1234567890.0
        assert result["credential"] == "credential"
        assert result["device_id"] == "device-id"
        assert result["signature"] == "signature"
    
    def test_get_token_info_invalid_format(self):
        """Test parsing token with invalid format."""
        token = "invalid-token-format"
        
        with pytest.raises(AuthenticationError):
            self.token_gen.get_token_info(token)
    
    def test_get_token_info_minimal(self):
        """Test parsing token with minimal parts."""
        token = "token-id,scope,client,123,cred,device"
        
        result = self.token_gen.get_token_info(token)
        
        assert result["token_id"] == "token-id"
        assert result["scopes"] == ["scope"]
        assert result["client_id"] == "client"
        assert result["expires_at"] == 123.0
        assert result["credential"] == "cred"
        assert result["device_id"] == "device"
        assert result["signature"] is None
