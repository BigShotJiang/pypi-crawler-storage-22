#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : test_cli.py
# | License  : MIT License © 2026 Chizoba
# | Brief    : Tests for CLI module
# ────────────────★─────────────────────────────────

"""
Tests for the CLI module.
"""

import pytest
from unittest.mock import Mock, patch, MagicMock
import tempfile
import json
from pathlib import Path

from mc5_api_client.cli import MC5CLI
from mc5_api_client.exceptions import AuthenticationError, NetworkError


class TestMC5CLI:
    """Test cases for MC5CLI class."""
    
    def setup_method(self):
        """Setup test fixtures."""
        # Use temporary directory for config
        self.temp_dir = tempfile.mkdtemp()
        self.cli = MC5CLI(debug=True)
        self.cli.config_dir = Path(self.temp_dir)
        self.cli.config_file = self.cli.config_dir / "config.json"
        self.cli.token_file = self.cli.config_dir / "token.json"
    
    def teardown_method(self):
        """Cleanup after tests."""
        self.cli.token_generator.close()
    
    def test_init(self):
        """Test CLI initialization."""
        assert self.cli.debug is True
        assert self.cli.token_generator is not None
        assert self.cli.config_dir.exists()
    
    @patch('mc5_api_client.cli.TokenGenerator.generate_token')
    def test_cmd_generate_token_success(self, mock_generate):
        """Test successful token generation command."""
        token_data = {
            "access_token": "test-token",
            "token_id": "test-id",
            "scopes": ["scope1", "scope2"],
            "expires_at": 1234567890,
            "expires_in": 3600,
            "expires_at_datetime": Mock(),
            "device_id_used": "test-device"
        }
        mock_generate.return_value = token_data
        
        # Mock args
        args = Mock()
        args.username = "test:user"
        args.password = "test_pass"
        args.device_id = None
        args.scope = "test scope"
        args.save = False
        args.save_config = False
        
        # Mock rich console if available
        with patch.object(self.cli, '_display_token_info'):
            self.cli.cmd_generate_token(args)
        
        mock_generate.assert_called_once_with(
            username="test:user",
            password="test_pass",
            device_id=None,
            scope="test scope"
        )
    
    @patch('mc5_api_client.cli.TokenGenerator.generate_token')
    def test_cmd_generate_token_save(self, mock_generate):
        """Test token generation with save option."""
        token_data = {
            "access_token": "test-token",
            "token_id": "test-id",
            "scopes": ["scope1"],
            "expires_at": 1234567890,
            "expires_in": 3600,
            "expires_at_datetime": Mock(),
            "device_id_used": "test-device"
        }
        mock_generate.return_value = token_data
        
        args = Mock()
        args.username = "test:user"
        args.password = "test_pass"
        args.device_id = None
        args.scope = "test scope"
        args.save = True
        args.save_config = False
        
        with patch.object(self.cli, '_display_token_info'):
            self.cli.cmd_generate_token(args)
        
        # Check token was saved
        assert self.cli.token_file.exists()
        with open(self.cli.token_file, 'r') as f:
            saved_token = json.load(f)
        assert saved_token["access_token"] == "test-token"
    
    @patch('mc5_api_client.cli.TokenGenerator.generate_token')
    def test_cmd_generate_token_save_config(self, mock_generate):
        """Test token generation with save config option."""
        token_data = {
            "access_token": "test-token",
            "token_id": "test-id",
            "scopes": ["scope1"],
            "expires_at": 1234567890,
            "expires_in": 3600,
            "expires_at_datetime": Mock(),
            "device_id_used": "test-device"
        }
        mock_generate.return_value = token_data
        
        args = Mock()
        args.username = "test:user"
        args.password = "test_pass"
        args.device_id = None
        args.scope = "test scope"
        args.save = False
        args.save_config = True
        
        with patch.object(self.cli, '_display_token_info'):
            self.cli.cmd_generate_token(args)
        
        # Check config was saved
        assert self.cli.config_file.exists()
        with open(self.cli.config_file, 'r') as f:
            saved_config = json.load(f)
        assert saved_config["username"] == "test:user"
        assert saved_config["device_id"] == "test-device"
        assert saved_config["default_scope"] == "test scope"
    
    @patch('mc5_api_client.cli.TokenGenerator.generate_token')
    def test_cmd_generate_token_auth_error(self, mock_generate):
        """Test token generation with authentication error."""
        mock_generate.side_effect = AuthenticationError("Invalid credentials")
        
        args = Mock()
        args.username = "test:user"
        args.password = "wrong_pass"
        args.device_id = None
        args.scope = "test scope"
        args.save = False
        args.save_config = False
        
        with patch.object(self.cli, '_print_error') as mock_print:
            self.cli.cmd_generate_token(args)
            mock_print.assert_called()
    
    @patch('mc5_api_client.cli.TokenGenerator.generate_admin_token')
    def test_cmd_generate_admin_token(self, mock_generate):
        """Test admin token generation command."""
        token_data = {
            "access_token": "admin-token",
            "token_id": "admin-id",
            "scopes": ["admin_scope"],
            "expires_at": 1234567890,
            "expires_in": 3600,
            "expires_at_datetime": Mock(),
            "device_id_used": "admin-device"
        }
        mock_generate.return_value = token_data
        
        args = Mock()
        args.device_id = None
        args.scope = "admin scope"
        args.save = False
        
        with patch.object(self.cli, '_display_token_info'):
            self.cli.cmd_generate_admin_token(args)
        
        mock_generate.assert_called_once_with(
            device_id=None,
            scope="admin scope"
        )
    
    def test_cmd_validate_token_with_saved_token(self):
        """Test token validation with saved token."""
        # Save a test token
        token_data = {
            "access_token": "test-token",
            "expires_at": 9999999999  # Far future
        }
        with open(self.cli.token_file, 'w') as f:
            json.dump(token_data, f)
        
        args = Mock()
        args.token = None
        
        with patch.object(self.cli.token_generator, 'validate_token', return_value=True):
            with patch.object(self.cli, '_print_success') as mock_print:
                self.cli.cmd_validate_token(args)
                mock_print.assert_called_with("Token is valid")
    
    def test_cmd_validate_token_no_saved_token(self):
        """Test token validation with no saved token."""
        args = Mock()
        args.token = None
        
        with patch.object(self.cli, '_print_error') as mock_print:
            self.cli.cmd_validate_token(args)
            mock_print.assert_called()
    
    def test_cmd_validate_token_with_provided_token(self):
        """Test token validation with provided token."""
        args = Mock()
        args.token = "test-token,scope,client,123,cred,device"
        
        with patch.object(self.cli.token_generator, 'get_token_info') as mock_get_info:
            mock_get_info.return_value = {"expires_at": 9999999999}
            
            with patch.object(self.cli.token_generator, 'validate_token', return_value=True):
                with patch.object(self.cli, '_print_success') as mock_print:
                    self.cli.cmd_validate_token(args)
                    mock_print.assert_called_with("Token is valid")
    
    def test_cmd_show_config(self):
        """Test show config command."""
        # Save test config and token
        config_data = {"username": "test:user", "device_id": "test-device"}
        token_data = {"access_token": "test-token", "expires_at": 1234567890}
        
        with open(self.cli.config_file, 'w') as f:
            json.dump(config_data, f)
        with open(self.cli.token_file, 'w') as f:
            json.dump(token_data, f)
        
        args = Mock()
        
        with patch.object(self.cli, '_display_token_info'):
            self.cli.cmd_show_config(args)
    
    def test_cmd_clear_config(self):
        """Test clear config command."""
        # Create test files
        self.cli.config_file.touch()
        self.cli.token_file.touch()
        
        args = Mock()
        
        with patch('mc5_api_client.cli.Confirm.ask', return_value=True):
            self.cli.cmd_clear_config(args)
        
        assert not self.cli.config_file.exists()
        assert not self.cli.token_file.exists()
    
    def test_save_config(self):
        """Test saving configuration."""
        config = {"username": "test:user", "device_id": "test-device"}
        
        self.cli._save_config(config)
        
        assert self.cli.config_file.exists()
        with open(self.cli.config_file, 'r') as f:
            saved_config = json.load(f)
        assert saved_config == config
    
    def test_load_config(self):
        """Test loading configuration."""
        config = {"username": "test:user", "device_id": "test-device"}
        with open(self.cli.config_file, 'w') as f:
            json.dump(config, f)
        
        loaded_config = self.cli._load_config()
        
        assert loaded_config == config
    
    def test_load_config_no_file(self):
        """Test loading configuration when file doesn't exist."""
        loaded_config = self.cli._load_config()
        assert loaded_config == {}
    
    def test_save_token(self):
        """Test saving token."""
        token_data = {"access_token": "test-token", "expires_at": 1234567890}
        
        self.cli._save_token(token_data)
        
        assert self.cli.token_file.exists()
        with open(self.cli.token_file, 'r') as f:
            saved_token = json.load(f)
        assert saved_token == token_data
    
    def test_load_token(self):
        """Test loading token."""
        token_data = {"access_token": "test-token", "expires_at": 1234567890}
        with open(self.cli.token_file, 'w') as f:
            json.dump(token_data, f)
        
        loaded_token = self.cli._load_token()
        
        assert loaded_token == token_data
    
    def test_load_token_no_file(self):
        """Test loading token when file doesn't exist."""
        loaded_token = self.cli._load_token()
        assert loaded_token is None
    
    def test_display_token_info(self):
        """Test displaying token information."""
        from datetime import datetime
        
        token_data = {
            "access_token": "test-token-string",
            "token_id": "test-id",
            "device_id_used": "test-device",
            "expires_in": 3600,
            "expires_at_datetime": datetime.now(),
            "scopes": ["scope1", "scope2", "scope3"]
        }
        
        # Should not raise exception
        self.cli._display_token_info(token_data)
    
    @patch('mc5_api_client.cli.argparse.ArgumentParser.parse_args')
    def test_run_generate_token_command(self, mock_parse):
        """Test running generate-token command."""
        args = Mock()
        args.command = "generate-token"
        args.debug = False
        args.no_banner = True
        args.username = "test:user"
        args.password = "test_pass"
        args.device_id = None
        args.scope = "test scope"
        args.save = False
        args.save_config = False
        
        mock_parse.return_value = args
        
        with patch.object(self.cli, 'cmd_generate_token'):
            self.cli.run()
    
    @patch('mc5_api_client.cli.argparse.ArgumentParser.parse_args')
    def test_run_no_command(self, mock_parse):
        """Test running with no command."""
        args = Mock()
        args.command = None
        args.debug = False
        args.no_banner = True
        
        mock_parse.return_value = args
        
        with patch('mc5_api_client.cli.argparse.ArgumentParser.print_help'):
            self.cli.run()
