#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : test_client.py
# | License  : MIT License © 2026 Chizoba
# | Brief    : Tests for MC5 API client
# ────────────────★─────────────────────────────────

"""
Tests for the MC5 API client.
"""

import pytest
from unittest.mock import Mock, patch, MagicMock

from mc5_api_client.client import MC5Client
from mc5_api_client.exceptions import (
    MC5APIError,
    AuthenticationError,
    TokenExpiredError,
    RateLimitError,
    InsufficientScopeError,
    NetworkError
)


class TestMC5Client:
    """Test cases for MC5Client class."""
    
    def setup_method(self):
        """Setup test fixtures."""
        self.client = MC5Client()
    
    def teardown_method(self):
        """Cleanup after tests."""
        self.client.close()
    
    def test_init(self):
        """Test MC5Client initialization."""
        assert self.client.client_id == "1875:55979:6.0.0a:windows:windows"
        assert self.client.auto_refresh is True
        assert self.client.timeout == 30
        assert self.client.max_retries == 3
        assert self.client.session is not None
        assert self.client.token_generator is not None
        assert self.client._token_data is None
    
    def test_init_with_credentials(self):
        """Test initialization with credentials."""
        with patch.object(self.client, 'authenticate') as mock_auth:
            MC5Client(
                username="test:user",
                password="test_pass"
            )
            mock_auth.assert_called_once_with("test:user", "test_pass")
    
    @patch('mc5_api_client.client.TokenGenerator.generate_token')
    def test_authenticate(self, mock_generate):
        """Test authentication."""
        token_data = {
            "access_token": "test-token",
            "expires_at": 1234567890
        }
        mock_generate.return_value = token_data
        
        result = self.client.authenticate("test:user", "test_pass")
        
        assert result == token_data
        assert self.client._token_data == token_data
        assert self.client._username == "test:user"
        assert self.client._password == "test_pass"
        mock_generate.assert_called_once_with("test:user", "test_pass", None)
    
    @patch('mc5_api_client.client.TokenGenerator.generate_admin_token')
    def test_authenticate_admin(self, mock_generate):
        """Test admin authentication."""
        token_data = {
            "access_token": "admin-token",
            "expires_at": 1234567890
        }
        mock_generate.return_value = token_data
        
        result = self.client.authenticate_admin()
        
        assert result == token_data
        assert self.client._token_data == token_data
        assert self.client._username == "game:mc5_system"
        assert self.client._password == "admin"
        mock_generate.assert_called_once_with(None)
    
    def test_is_authenticated_no_token(self):
        """Test authentication check with no token."""
        assert self.client.is_authenticated() is False
    
    def test_is_authenticated_with_valid_token(self):
        """Test authentication check with valid token."""
        self.client._token_data = {
            "expires_at": 9999999999  # Far future
        }
        with patch.object(self.client.token_generator, 'validate_token', return_value=True):
            assert self.client.is_authenticated() is True
    
    def test_is_authenticated_with_invalid_token(self):
        """Test authentication check with invalid token."""
        self.client._token_data = {
            "expires_at": 0  # Past
        }
        with patch.object(self.client.token_generator, 'validate_token', return_value=False):
            assert self.client.is_authenticated() is False
    
    def test_ensure_valid_token_no_token(self):
        """Test token validation with no token."""
        with pytest.raises(AuthenticationError):
            self.client._ensure_valid_token()
    
    def test_ensure_valid_token_valid(self):
        """Test token validation with valid token."""
        self.client._token_data = {"expires_at": 9999999999}
        with patch.object(self.client.token_generator, 'validate_token', return_value=True):
            # Should not raise exception
            self.client._ensure_valid_token()
    
    def test_ensure_valid_token_expired_no_refresh(self):
        """Test token validation with expired token and no refresh."""
        self.client._token_data = {"expires_at": 0}
        self.client.auto_refresh = False
        
        with patch.object(self.client.token_generator, 'validate_token', return_value=False):
            with pytest.raises(TokenExpiredError):
                self.client._ensure_valid_token()
    
    def test_make_request_success(self, mock_request):
        """Test successful HTTP request."""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"success": True}
        mock_request.return_value = mock_response
        
        self.client._token_data = {"access_token": "test-token", "expires_at": 9999999999}
        with patch.object(self.client.token_generator, 'validate_token', return_value=True):
            result = self.client._make_request("GET", "https://test.com")
        
        assert result == {"success": True}
        mock_request.assert_called_once()
    
    @patch('mc5_api_client.client.requests.Session.request')
    def test_make_request_unauthorized(self, mock_request):
        """Test HTTP request with unauthorized response."""
        mock_response = Mock()
        mock_response.status_code = 401
        mock_request.return_value = mock_response
        
        self.client._token_data = {"access_token": "test-token", "expires_at": 9999999999}
        with patch.object(self.client.token_generator, 'validate_token', return_value=True):
            with pytest.raises(AuthenticationError):
                self.client._make_request("GET", "https://test.com")
    
    @patch('mc5_api_client.client.requests.Session.request')
    def test_make_request_forbidden(self, mock_request):
        """Test HTTP request with forbidden response."""
        mock_response = Mock()
        mock_response.status_code = 403
        mock_response.json.return_value = {"error": "Insufficient permissions"}
        mock_request.return_value = mock_response
        
        self.client._token_data = {"access_token": "test-token", "expires_at": 9999999999}
        with patch.object(self.client.token_generator, 'validate_token', return_value=True):
            with pytest.raises(InsufficientScopeError):
                self.client._make_request("GET", "https://test.com")
    
    @patch('mc5_api_client.client.requests.Session.request')
    def test_make_request_rate_limited(self, mock_request):
        """Test HTTP request with rate limit response."""
        mock_response = Mock()
        mock_response.status_code = 429
        mock_response.headers = {"Retry-After": "60"}
        mock_request.return_value = mock_response
        
        self.client._token_data = {"access_token": "test-token", "expires_at": 9999999999}
        with patch.object(self.client.token_generator, 'validate_token', return_value=True):
            with pytest.raises(RateLimitError) as exc_info:
                self.client._make_request("GET", "https://test.com")
        
        assert exc_info.value.retry_after == 60
    
    @patch('mc5_api_client.client.requests.Session.request')
    def test_make_request_network_error(self, mock_request):
        """Test HTTP request with network error."""
        mock_request.side_effect = Exception("Network error")
        
        self.client._token_data = {"access_token": "test-token", "expires_at": 9999999999}
        with patch.object(self.client.token_generator, 'validate_token', return_value=True):
            with pytest.raises(NetworkError):
                self.client._make_request("GET", "https://test.com")
    
    @patch.object(MC5Client, '_make_request')
    def test_get_profile(self, mock_request):
        """Test getting player profile."""
        mock_request.return_value = {"name": "TestPlayer", "level": 50}
        
        self.client._token_data = {"access_token": "test-token", "expires_at": 9999999999}
        self.client._token_data = {"access_token": "test-token"}
        
        result = self.client.get_profile()
        
        assert result == {"name": "TestPlayer", "level": 50}
        mock_request.assert_called_once_with(
            "GET",
            "https://eur-osiris.gameloft.com:443/accounts/me",
            params={}
        )
    
    @patch.object(MC5Client, '_make_request')
    def test_get_clan_settings(self, mock_request):
        """Test getting clan settings."""
        mock_request.return_value = {"name": "TestClan", "member_count": 25}
        
        self.client._token_data = {"access_token": "test-token"}
        
        result = self.client.get_clan_settings("test-clan-id")
        
        assert result == {"name": "TestClan", "member_count": 25}
        mock_request.assert_called_once_with(
            "GET",
            "https://eur-osiris.gameloft.com:443/clans/test-clan-id"
        )
    
    @patch.object(MC5Client, '_make_request')
    def test_send_private_message(self, mock_request):
        """Test sending private message."""
        mock_request.return_value = {"success": True}
        
        self.client._token_data = {"access_token": "test-token"}
        
        result = self.client.send_private_message(
            credential="test:user",
            message="Hello!"
        )
        
        assert result == {"success": True}
        mock_request.assert_called_once_with(
            "POST",
            "https://eur-osiris.gameloft.com:443/messages/private",
            data={"credential": "test:user", "message": "Hello!"}
        )
    
    @patch.object(MC5Client, '_make_request')
    def test_get_events(self, mock_request):
        """Test getting events."""
        mock_request.return_value = [
            {"name": "Event1", "status": "active"},
            {"name": "Event2", "status": "ended"}
        ]
        
        self.client._token_data = {"access_token": "test-token"}
        
        result = self.client.get_events()
        
        assert len(result) == 2
        assert result[0]["name"] == "Event1"
        mock_request.assert_called_once_with(
            "GET",
            "https://eur-osiris.gameloft.com:443/events"
        )
    
    def test_convert_dogtag_to_alias(self):
        """Test dogtag to alias conversion."""
        # Test known examples from documentation
        assert self.client.convert_dogtag_to_alias("f55f") == "d33d"
        assert self.client.convert_dogtag_to_alias("ff11") == "dd99"
        assert self.client.convert_dogtag_to_alias("g6765") == "e4543"
        
        # Test digit wrapping
        assert self.client.convert_dogtag_to_alias("1234") == "9012"
        assert self.client.convert_dogtag_to_alias("4567") == "2345"
        assert self.client.convert_dogtag_to_alias("8910") == "6798"
    
    def test_context_manager(self):
        """Test using client as context manager."""
        with patch.object(self.client, 'close') as mock_close:
            with MC5Client() as client:
                assert isinstance(client, MC5Client)
            mock_close.assert_called_once()
    
    def test_get_token_info(self):
        """Test getting token information."""
        self.client._token_data = {
            "access_token": "test-token",
            "expires_at": 1234567890
        }
        
        with patch.object(self.client, '_ensure_valid_token'):
            result = self.client.get_token_info()
            
            assert result["access_token"] == "test-token"
            assert result["expires_at"] == 1234567890
