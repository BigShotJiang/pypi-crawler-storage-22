# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : __init__.py
# | License  : MIT License © 2026 Chizoba
# | Brief    : Modern Combat 5 API Client Package
# ────────────────★─────────────────────────────────

"""
Modern Combat 5 API Client

A comprehensive Python library for interacting with the Modern Combat 5 API.
Provides easy access to authentication, profile management, clan operations,
messaging, and more.
"""

from typing import Optional, Dict, Any

__version__ = "1.0.20"
__author__ = "Chizoba"
__email__ = "chizoba2026@hotmail.com"
__license__ = "MIT"

from .telemetry import telemetry, report_error, report_usage, is_telemetry_enabled
from .debug import debug_mode, debug_print, debug_function, analyze_error, print_error_analysis
from .platform import Platform, get_platform_config, get_android_anonymous_credential, get_pc_anonymous_credential
from .squad_battle import SquadBattleMixin
from .transfer_quick import (
    quick_generate_transfer_code,
    quick_check_transfer_status,
    quick_get_device_linking_guide,
    quick_link_device_workflow,
    quick_validate_transfer_code,
    quick_force_new_code,
    quick_transfer_status_summary
)
from .account_quick import (
    quick_get_account_info,
    quick_get_device_history,
    quick_get_credential_summary,
    quick_analyze_account_security,
    quick_get_account_overview,
    quick_export_account_data
)
from .alerts_quick import (
    quick_start_alert_stream,
    quick_test_alert_connection,
    quick_start_alerts_with_discord,
    quick_monitor_alerts,
    create_alert_callback
)
from .federation_quick import (
    quick_get_active_sessions,
    quick_get_my_sessions,
    quick_get_session_statistics,
    quick_check_session_status,
    quick_get_server_type_sessions,
    quick_analyze_session_activity
)
from .squad_battle_quick import (
    quick_create_squad_battle_room,
    quick_post_squad_battle_result,
    quick_get_squad_battle_history,
    quick_analyze_squad_performance,
    quick_get_squad_wall_messages,
    quick_send_squad_battle_notification,
    quick_post_squad_wall_message
)
from .simple_client import (
    SimpleMC5Client,
    batch_search_players,
    clan_cleanup,
    monitor_clan_activity,
    quick_search,
    quick_kick,
    quick_remove_friend,
    quick_send_friend_request,
    quick_check_friend_status,
    quick_accept_friend_request,
    quick_sign_up_for_event,
    quick_get_event_leaderboard,
    quick_get_my_event_rank,
    quick_get_squad_invitations,
    quick_accept_squad_invitation,
    quick_decline_squad_invitation
)
from .client import MC5Client
from .auth import TokenGenerator
from .exceptions import MC5APIError, AuthenticationError, RateLimitError
from .help import help, examples, quick_reference

# Add MC5ApiClient as an alias for backward compatibility
MC5ApiClient = MC5Client
from .admin_client import (
    AdminMC5Client,
    create_admin_client,
    create_user_client,
    quick_add_squad_rating,
    quick_update_player_score
)
from .pc_storage_client import PCStorageClient
from .storage_admin import StorageAdminMixin
from .easy_mc5 import MC5Easy

# Encrypted token convenience functions
from .auth import TokenGenerator

# Convenience functions for global ID operations
def get_global_id(device_id: str = None, device_type: str = "w10", hdidfv: str = None) -> str:
    """
    Get a global device ID from Gameloft's global ID service.
    
    Args:
        device_id: Your device ID (optional, will generate one if not provided)
        device_type: Device type (w10, android, ios, etc.)
        hdidfv: Hardware ID fingerprint (optional)
        
    Returns:
        Global device ID string
    """
    import requests
    
    # Build request parameters
    params = {
        "source": "Identifiers_6.0.0",
        "client_id": "1875:55979:6.0.0a:windows:windows",
        "device_type": device_type,
        "global_device_id": device_id or "1364509832654538259",
        "hdidfv": hdidfv or "76dfc72e-7850-4d9e-b79c-9861c7e3ea20"
    }
    
    headers = {
        "Accept": "*/*",
        "Accept-Encoding": "gzip;q=1.0, deflate;q=1.0, identity;q=0.5, *;q=0"
    }
    
    try:
        response = requests.get(
            "https://gdid.datalake.gameloft.com/assign_global_id/",
            params=params,
            headers=headers,
            timeout=30
        )
        
        if response.status_code == 200:
            return response.text.strip()
        else:
            return ""
    except Exception:
        return ""

def generate_device_id() -> str:
    """
    Generate a unique device ID for the current device.
    
    Returns:
        Generated device ID string
    """
    import uuid
    
    # Generate a unique device ID
    device_id = f"mc5_{uuid.uuid4().hex[:16]}"
    return device_id

def create_federation_session(username: str = None, password: str = None, device_id: str = None) -> Dict[str, Any]:
    """
    Create a federation session for MC5 game launch.
    
    Args:
        username: MC5 username (can use MC5_USERNAME env var)
        password: MC5 password (can use MC5_PASSWORD env var)
        device_id: Device ID for the session (optional)
        
    Returns:
        Dictionary with session information
    """
    import os
    import requests
    
    # Use environment variables if not provided
    username = username or os.getenv('MC5_USERNAME')
    password = password or os.getenv('MC5_PASSWORD')
    
    if not username or not password:
        return {"error": "Username and password are required"}
    
    try:
        # Build request parameters
        params = {
            "password": password,
            "device_id": device_id or "1364509832654538259"
        }
        
        headers = {
            "Accept": "*/*",
            "Content-Type": "application/x-www-form-urlencoded"
        }
        
        # Build URL with encoded credential
        encoded_credential = username.replace(":", "%3A")
        url = f"https://federation-eur.gameloft.com/sessions/1875%3A55979%3A6.0.0a%3Awindows%3Awindows/{encoded_credential}"
        
        # Make request
        response = requests.post(
            url,
            data=params,
            headers=headers,
            timeout=30
        )
        
        if response.status_code == 200:
            return response.json()
        else:
            return {"error": f"HTTP {response.status_code}", "response": response.text}
    
    except Exception as e:
        return {"error": str(e)}

def locate_service(service: str) -> str:
    """
    Locate a service endpoint for MC5.
    
    Args:
        service: Service name (leaderboard, matchmaker, auth, social, alert, message, lobby, gs, sp)
        
    Returns:
        Service endpoint URL or empty string if not found
    """
    import requests
    
    try:
        # Build request parameters
        params = {
            "service": service,
            "client_id": "1875:55979:6.0.0a:windows:windows"
        }
        
        headers = {
            "Accept": "*/*"
        }
        
        # Make request
        response = requests.get(
            "https://vgold-eur.gameloft.com/1875:55979:6.0.0a:windows:windows/locate",
            params=params,
            headers=headers,
            timeout=30
        )
        
        if response.status_code == 200:
            return response.text.strip()
        else:
            return ""
    
    except Exception:
        return ""

def get_all_services() -> Dict[str, str]:
    """
    Get all available service endpoints.
    
    Returns:
        Dictionary mapping service names to endpoints
    """
    services = [
        "leaderboard", "matchmaker", "auth", "social", 
        "alert", "message", "lobby", "gs", "sp"
    ]
    
    service_endpoints = {}
    
    for service in services:
        endpoint = locate_service(service)
        if endpoint:
            service_endpoints[service] = endpoint
    
    return service_endpoints

def generate_encrypted_token(
    username: str,
    password: str,
    device_id: Optional[str] = None,
    scope: str = "alert auth chat leaderboard_ro lobby message session social config storage_ro tracking_bi feed storage leaderboard_admin social_eve social soc transaction schedule lottery voice matchmaker",
    nonce: str = "*"
) -> Dict[str, Any]:
    """
    Generate and encrypt an access token.
    
    Args:
        username: MC5 username
        password: Account password
        device_id: Device ID (generated if not provided)
        scope: Permission scopes
        nonce: Nonce value for encryption
        
    Returns:
        Dictionary containing encrypted token information
    """
    token_gen = TokenGenerator()
    try:
        result = token_gen.generate_encrypted_token(username, password, device_id, scope, nonce)
        return result
    finally:
        token_gen.close()

def encrypt_token(
    access_token: str,
    nonce: str = "*"
) -> str:
    """
    Encrypt an existing access token.
    
    Args:
        access_token: Raw access token string
        nonce: Nonce value for encryption
        
    Returns:
        Encrypted token string
    """
    token_gen = TokenGenerator()
    try:
        result = token_gen.encrypt_token(access_token, nonce)
        return result
    finally:
        token_gen.close()

__all__ = [
    "MC5Client",
    "MC5ApiClient",
    "SimpleMC5Client",
    "AdminMC5Client",
    "batch_search_players",
    "clan_cleanup",
    "monitor_clan_activity",
    "quick_search",
    "quick_kick",
    "quick_remove_friend",
    "quick_send_friend_request",
    "quick_check_friend_status",
    "quick_accept_friend_request",
    "quick_sign_up_for_event",
    "quick_get_event_leaderboard",
    "quick_get_my_event_rank",
    "quick_get_squad_invitations",
    "quick_accept_squad_invitation",
    "quick_decline_squad_invitation",
    "quick_create_squad_battle_room",
    "quick_post_squad_battle_result",
    "quick_get_squad_battle_history",
    "quick_analyze_squad_performance",
    "quick_get_squad_wall_messages",
    "quick_send_squad_battle_notification",
    "quick_post_squad_wall_message",
    "quick_get_active_sessions",
    "quick_get_my_sessions",
    "quick_get_session_statistics",
    "quick_check_session_status",
    "quick_get_server_type_sessions",
    "quick_analyze_session_activity",
    "quick_start_alert_stream",
    "quick_test_alert_connection",
    "quick_start_alerts_with_discord",
    "quick_monitor_alerts",
    "create_alert_callback",
    "quick_get_account_info",
    "quick_get_device_history",
    "quick_get_credential_summary",
    "quick_analyze_account_security",
    "quick_get_account_overview",
    "quick_export_account_data",
    "quick_generate_transfer_code",
    "quick_check_transfer_status",
    "quick_get_device_linking_guide",
    "quick_link_device_workflow",
    "quick_validate_transfer_code",
    "quick_force_new_code",
    "quick_transfer_status_summary",
    "telemetry",
    "report_error",
    "report_usage",
    "is_telemetry_enabled",
    "debug_mode",
    "debug_print",
    "debug_function",
    "analyze_error",
    "print_error_analysis",
    "create_admin_client",
    "create_user_client",
    "quick_add_squad_rating",
    "quick_update_player_score",
    "TokenGenerator", 
    "MC5APIError",
    "AuthenticationError",
    "RateLimitError",
    "help",
    "examples",
    "quick_reference",
    "generate_encrypted_token",
    "encrypt_token",
    "MC5Easy",
    "quick_connect",
    "check_my_daily_tasks",
    "get_my_mc5_profile",
    "find_mc5_player",
    "get_global_id",
    "generate_device_id",
    "create_federation_session",
    "locate_service",
    "get_all_services"
]
