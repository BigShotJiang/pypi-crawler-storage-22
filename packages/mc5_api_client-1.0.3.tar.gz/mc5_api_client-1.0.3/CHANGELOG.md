# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2026-02-02

### Added
- Initial release of MC5 API Client by Chizoba
- Comprehensive authentication system with token generation
- Support for both user and admin authentication
- Modern CLI interface with Rich formatting and debug capabilities
- Full API coverage including:
  - Profile management
  - Clan operations
  - Friend management
  - Messaging system
  - Events and tasks
  - Leaderboard access
  - Game objects
  - Asset metadata
  - Alias lookup
- Automatic token refresh functionality
- Comprehensive error handling with custom exceptions
- Type hints throughout the codebase
- Extensive documentation and examples
- Unit test coverage
- PyPI package configuration
- Development environment setup
- Python 3.11+ support (beta version)

### Features
- **Authentication**: Easy token generation and management
- **CLI**: Rich command-line interface with progress indicators
- **Auto-refresh**: Automatic token renewal
- **Error Handling**: Comprehensive exception hierarchy
- **Type Safety**: Full type annotation support
- **Documentation**: Detailed README and examples
- **Testing**: Unit tests with mocking
- **Configuration**: Persistent config and token storage

### CLI Commands
- `generate-token` - Generate user access tokens
- `generate-admin-token` - Generate admin access tokens
- `validate-token` - Validate saved tokens
- `show-config` - Display configuration
- `clear-config` - Clear saved data

### API Endpoints Supported
- Authentication (Janus)
- Profile management (Osiris)
- Clan operations (Osiris)
- Friend system (Osiris)
- Messaging (Osiris)
- Events (Osiris)
- Leaderboards (Osiris/Olympus)
- Game objects (Iris)
- Asset metadata (Iris)
- Alias lookup (Janus)

### Installation
```bash
pip install mc5-api-client
```

### Development Installation
```bash
pip install mc5-api-client[dev]
```

### Example Usage
```python
from mc5_api_client import MC5Client

with MC5Client(username="user", password="pass") as client:
    profile = client.get_profile()
    events = client.get_events()
    client.send_private_message("target", "Hello!")
```

### CLI Usage
```bash
mc5 generate-token --username "user" --password "pass" --save
mc5 validate-token
mc5 show-config
```

---

## [Unreleased]

### Planned
- Additional API endpoints
- Enhanced CLI features
- Performance optimizations
- More examples and tutorials
