#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : setup.py
# | License  : MIT License © 2026 Chizoba
# | Brief    : Setup script for MC5 API Client
# ────────────────★─────────────────────────────────

"""
Setup script for MC5 API Client.
This script is kept for backward compatibility but pyproject.toml is preferred.
"""

from setuptools import setup, find_packages
import os

# Read the README file
def read_readme():
    readme_path = os.path.join(os.path.dirname(__file__), 'README.md')
    if os.path.exists(readme_path):
        with open(readme_path, 'r', encoding='utf-8') as f:
            return f.read()
    return ""

# Read requirements
def read_requirements():
    requirements_path = os.path.join(os.path.dirname(__file__), 'requirements.txt')
    if os.path.exists(requirements_path):
        with open(requirements_path, 'r', encoding='utf-8') as f:
            return [line.strip() for line in f if line.strip() and not line.startswith('#')]
    return []

setup(
    name="mc5_api_client",
    use_scm_version=False,
    version="1.0.3",
    description="A comprehensive Python library for interacting with the Modern Combat 5 API",
    long_description=read_readme(),
    long_description_content_type="text/markdown",
    author="Chizoba",
    author_email="chizoba2026@hotmail.com",
    url="https://pypi.org/project/mc5-api-client/",
    project_urls={
        "Documentation": "https://mc5-api-client.readthedocs.io/",
        "Source": "https://pypi.org/project/mc5-api-client/",
        "Tracker": "https://pypi.org/project/mc5-api-client/",
    },
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    include_package_data=True,
    package_data={
        "mc5_api_client": ["py.typed"],
    },
    install_requires=read_requirements(),
    extras_require={
        "cli": [
            "rich>=13.0.0",
            "colorama>=0.4.4",
        ],
        "dev": [
            "pytest>=7.0.0",
            "pytest-cov>=4.0.0",
            "pytest-mock>=3.10.0",
            "black>=22.0.0",
            "isort>=5.10.0",
            "mypy>=1.0.0",
            "flake8>=5.0.0",
            "pre-commit>=2.20.0",
            "build>=0.8.0",
            "twine>=4.0.0",
        ],
        "docs": [
            "sphinx>=5.0.0",
            "sphinx-rtd-theme>=1.2.0",
            "myst-parser>=0.18.0",
        ],
        "all": [
            "mc5-api-client[cli,dev,docs]",
        ],
    },
    entry_points={
        "console_scripts": [
            "mc5=mc5_api_client.cli:main",
        ],
    },
    python_requires=">=3.8",
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: Microsoft :: Windows",
        "Operating System :: POSIX :: Linux",
        "Operating System :: MacOS",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
        "Topic :: Games/Entertainment",
        "Topic :: Internet :: WWW/HTTP",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Typing :: Typed",
    ],
    keywords=[
        "modern combat 5",
        "mc5",
        "gameloft",
        "api",
        "client",
        "gaming",
        "authentication",
        "clan",
        "messaging"
    ],
    zip_safe=False,
)
