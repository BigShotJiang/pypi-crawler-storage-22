# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : __init__.py
# | License  : MIT License © 2026 Chizoba
# | Brief    : Modern Combat 5 API Client Package
# ────────────────★─────────────────────────────────

"""
Modern Combat 5 API Client

A comprehensive Python library for interacting with the Modern Combat 5 API.
Provides easy access to authentication, profile management, clan operations,
messaging, and more.
"""

__version__ = "1.0.0"
__author__ = "Chizoba"
__email__ = "chizoba2026@hotmail.com"
__license__ = "MIT"

from .client import MC5Client
from .auth import TokenGenerator
from .exceptions import MC5APIError, AuthenticationError, RateLimitError

__all__ = [
    "MC5Client",
    "TokenGenerator", 
    "MC5APIError",
    "AuthenticationError",
    "RateLimitError"
]
