# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : auth.py
# | License  : MIT License © 2026 Chizoba
# | Brief    : Authentication and token management for MC5 API
# ────────────────★─────────────────────────────────

"""
Authentication and token management for Modern Combat 5 API.
"""

import time
import hashlib
import secrets
from typing import Optional, Dict, Any
from datetime import datetime, timedelta

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from .exceptions import (
    AuthenticationError,
    InvalidCredentialsError,
    TokenExpiredError,
    NetworkError
)


class TokenGenerator:
    """
    Handles authentication and token generation for MC5 API.
    
    Supports both user authentication and admin authentication.
    """
    
    def __init__(
        self,
        client_id: str = "1875:55979:6.0.0a:windows:windows",
        auth_url: str = "https://eur-janus.gameloft.com:443/authorize",
        timeout: int = 30,
        max_retries: int = 3
    ):
        """
        Initialize the TokenGenerator.
        
        Args:
            client_id: Game client identifier
            auth_url: Authentication endpoint URL
            timeout: Request timeout in seconds
            max_retries: Maximum number of retry attempts
        """
        self.client_id = client_id
        self.auth_url = auth_url
        self.timeout = timeout
        self.max_retries = max_retries
        
        # Setup session with retry strategy
        self.session = requests.Session()
        retry_strategy = Retry(
            total=max_retries,
            status_forcelist=[429, 500, 502, 503, 504],
            allowed_methods=["HEAD", "GET", "POST"],
            backoff_factor=1
        )
        adapter = HTTPAdapter(max_retries=retry_strategy)
        self.session.mount("http://", adapter)
        self.session.mount("https://", adapter)
        
        # Default headers
        self.session.headers.update({
            "User-Agent": "MC5-API-Client/1.0.0",
            "Accept": "*/*",
            "Content-Type": "application/x-www-form-urlencoded",
            "Connection": "close"
        })
    
    def generate_device_id(self) -> str:
        """
        Generate a random device ID.
        
        Returns:
            Random 19-digit device ID
        """
        return str(secrets.randbelow(10**19)).zfill(19)
    
    def generate_token(
        self,
        username: str,
        password: str,
        device_id: Optional[str] = None,
        scope: str = "alert auth chat leaderboard_ro lobby message session social config storage_ro tracking_bi feed storage leaderboard_admin social_eve social soc transaction schedule lottery voice matchmaker"
    ) -> Dict[str, Any]:
        """
        Generate an access token for the MC5 API.
        
        Args:
            username: MC5 username (e.g., "anonymous:d2luOF92M18xNzU4NjQxNTE3Xy9bF5EFTbvwR7w1nqg2JnI=")
            password: Account password
            device_id: Device ID (generated if not provided)
            scope: Space-separated list of permission scopes
            
        Returns:
            Dictionary containing token information
            
        Raises:
            InvalidCredentialsError: If credentials are invalid
            AuthenticationError: If authentication fails for other reasons
            NetworkError: If network issues occur
        """
        if device_id is None:
            device_id = self.generate_device_id()
        
        payload = {
            "client_id": self.client_id,
            "username": username,
            "password": password,
            "scope": scope,
            "device_id": device_id
        }
        
        try:
            print(f"🔵 Generating token for user: {username[:20]}...")
            response = self.session.post(
                self.auth_url,
                data=payload,
                timeout=self.timeout
            )
            
            if response.status_code == 200:
                token_data = response.json()
                access_token = token_data.get("access_token")
                
                if not access_token:
                    raise AuthenticationError("No access token in response")
                
                # Parse token components
                token_parts = access_token.split(",")
                if len(token_parts) < 6:
                    raise AuthenticationError("Invalid token format")
                
                result = {
                    "access_token": access_token,
                    "token_id": token_parts[0],
                    "scopes": token_parts[1].split(" "),
                    "client_id": token_parts[2],
                    "expires_at": float(token_parts[3]),
                    "credential": token_parts[4],
                    "device_id": token_parts[5],
                    "signature": token_parts[6] if len(token_parts) > 6 else None,
                    "generated_at": time.time(),
                    "device_id_used": device_id
                }
                
                # Calculate expiry time
                expiry_timestamp = result["expires_at"]
                expiry_datetime = datetime.fromtimestamp(expiry_timestamp)
                result["expires_in"] = expiry_timestamp - time.time()
                result["expires_at_datetime"] = expiry_datetime
                
                print(f"🟢 Token generated successfully! Expires: {expiry_datetime}")
                return result
                
            elif response.status_code == 401:
                raise InvalidCredentialsError("Invalid username or password")
            elif response.status_code == 403:
                raise AuthenticationError("Access forbidden - check client permissions")
            else:
                error_msg = f"Authentication failed with status {response.status_code}"
                try:
                    error_data = response.json()
                    error_msg += f": {error_data.get('error_description', error_data.get('error', 'Unknown error'))}"
                except:
                    pass
                raise AuthenticationError(error_msg)
                
        except requests.exceptions.Timeout:
            raise NetworkError("Authentication request timed out")
        except requests.exceptions.ConnectionError:
            raise NetworkError("Failed to connect to authentication server")
        except requests.exceptions.RequestException as e:
            raise NetworkError(f"Network error during authentication: {str(e)}")
    
    def generate_admin_token(
        self,
        device_id: Optional[str] = None,
        scope: str = "alert auth chat leaderboard_ro lobby message session social config storage_ro tracking_bi"
    ) -> Dict[str, Any]:
        """
        Generate an admin access token.
        
        Args:
            device_id: Device ID (generated if not provided)
            scope: Admin permission scopes
            
        Returns:
            Dictionary containing admin token information
            
        Raises:
            AuthenticationError: If admin authentication fails
        """
        return self.generate_token(
            username="game:mc5_system",
            password="admin",
            device_id=device_id,
            scope=scope
        )
    
    def validate_token(self, token_data: Dict[str, Any]) -> bool:
        """
        Check if a token is still valid.
        
        Args:
            token_data: Token data from generate_token()
            
        Returns:
            True if token is valid, False otherwise
        """
        if not token_data or "expires_at" not in token_data:
            return False
        
        # Add 60 second buffer to account for clock skew
        expiry_time = token_data["expires_at"] - 60
        current_time = time.time()
        
        return current_time < expiry_time
    
    def refresh_token_if_needed(
        self,
        token_data: Dict[str, Any],
        username: str,
        password: str,
        device_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Refresh token if it's expired or will expire soon.
        
        Args:
            token_data: Current token data
            username: Account username
            password: Account password
            device_id: Device ID used for original token
            
        Returns:
            New token data if refresh was needed, original data otherwise
        """
        if self.validate_token(token_data):
            print("🟢 Current token is still valid")
            return token_data
        
        print("🟠 Token expired, generating new token...")
        return self.generate_token(username, password, device_id or token_data.get("device_id_used"))
    
    def get_token_info(self, access_token: str) -> Dict[str, Any]:
        """
        Parse and return information about an access token.
        
        Args:
            access_token: Raw access token string
            
        Returns:
            Parsed token information
        """
        parts = access_token.split(",")
        if len(parts) < 6:
            raise AuthenticationError("Invalid token format")
        
        return {
            "token_id": parts[0],
            "scopes": parts[1].split(" "),
            "client_id": parts[2],
            "expires_at": float(parts[3]),
            "credential": parts[4],
            "device_id": parts[5],
            "signature": parts[6] if len(parts) > 6 else None
        }
    
    def close(self):
        """Close the HTTP session."""
        if self.session:
            self.session.close()
