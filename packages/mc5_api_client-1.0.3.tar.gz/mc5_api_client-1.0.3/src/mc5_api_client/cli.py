# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : cli.py
# | License  : MIT License © 2026 Chizoba
# | Brief    : Modern CLI interface for MC5 API Client
# ────────────────★─────────────────────────────────

"""
Modern Command Line Interface for MC5 API Client.
Features rich output, debug capabilities, and comprehensive functionality.
"""

import os
import sys
import json
import time
import argparse
from pathlib import Path
from typing import Optional, Dict, Any
from datetime import datetime

try:
    from rich.console import Console
    from rich.table import Table
    from rich.panel import Panel
    from rich.progress import Progress, SpinnerColumn, TextColumn
    from rich.prompt import Prompt, Confirm
    from rich.syntax import Syntax
    from rich.tree import Tree
    from rich import print as rprint
    RICH_AVAILABLE = True
except ImportError:
    RICH_AVAILABLE = False
    print("🟠 Warning: Rich library not found. Install with: pip install rich")
    print("🟠 Falling back to basic output...")

from .auth import TokenGenerator
from .exceptions import MC5APIError, AuthenticationError, NetworkError


class MC5CLI:
    """
    Modern CLI interface for MC5 API operations.
    """
    
    def __init__(self, debug: bool = False):
        """
        Initialize the CLI.
        
        Args:
            debug: Enable debug output
        """
        self.debug = debug
        self.token_generator = TokenGenerator()
        self.console = Console() if RICH_AVAILABLE else None
        
        # Configuration file path
        self.config_dir = Path.home() / ".mc5"
        self.config_file = self.config_dir / "config.json"
        self.token_file = self.config_dir / "token.json"
        
        # Ensure config directory exists
        self.config_dir.mkdir(exist_ok=True)
        
        self._setup_logging()
    
    def _setup_logging(self):
        """Setup debug logging."""
        if self.debug:
            import logging
            logging.basicConfig(
                level=logging.DEBUG,
                format='🔵 %(asctime)s - %(name)s - %(levelname)s - %(message)s',
                handlers=[
                    logging.FileHandler(self.config_dir / 'debug.log'),
                    logging.StreamHandler()
                ]
            )
            self.logger = logging.getLogger(__name__)
        else:
            self.logger = None
    
    def _print(self, message: str, color: str = "white", style: str = None):
        """Print with rich formatting if available."""
        if self.console:
            if style:
                self.console.print(message, style=style)
            else:
                self.console.print(message, style=color)
        else:
            print(message)
    
    def _print_success(self, message: str):
        """Print success message."""
        self._print(f"🟢 {message}", "green")
    
    def _print_error(self, message: str):
        """Print error message."""
        self._print(f"🔴 {message}", "red")
    
    def _print_warning(self, message: str):
        """Print warning message."""
        self._print(f"🟠 {message}", "yellow")
    
    def _print_info(self, message: str):
        """Print info message."""
        self._print(f"🔵 {message}", "blue")
    
    def _print_debug(self, message: str):
        """Print debug message."""
        if self.debug:
            self._print(f"🟣 {message}", "magenta")
            if self.logger:
                self.logger.debug(message)
    
    def _show_banner(self):
        """Display the CLI banner."""
        if self.console:
            banner = Panel.fit(
                "[bold cyan]Modern Combat 5 API Client[/bold cyan]\n"
                "[dim]Version 1.0.0 | Author: Chizoba[/dim]\n"
                "[dim]Email: chizoba2026@hotmail.com[/dim]",
                border_style="cyan",
                padding=(1, 2)
            )
            self.console.print(banner)
        else:
            print("=" * 60)
            print("🎮 Modern Combat 5 API Client v1.0.0")
            print("👤 Author: Chizoba | 📧 chizoba2026@hotmail.com")
            print("=" * 60)
    
    def _save_config(self, config: Dict[str, Any]):
        """Save configuration to file."""
        try:
            with open(self.config_file, 'w') as f:
                json.dump(config, f, indent=2)
            self._print_debug(f"Configuration saved to {self.config_file}")
        except Exception as e:
            self._print_error(f"Failed to save configuration: {e}")
    
    def _load_config(self) -> Dict[str, Any]:
        """Load configuration from file."""
        if not self.config_file.exists():
            return {}
        
        try:
            with open(self.config_file, 'r') as f:
                config = json.load(f)
            self._print_debug(f"Configuration loaded from {self.config_file}")
            return config
        except Exception as e:
            self._print_error(f"Failed to load configuration: {e}")
            return {}
    
    def _save_token(self, token_data: Dict[str, Any]):
        """Save token data to file."""
        try:
            # Convert datetime to string for JSON serialization
            save_data = token_data.copy()
            if 'expires_at_datetime' in save_data:
                save_data['expires_at_datetime'] = save_data['expires_at_datetime'].isoformat()
            
            with open(self.token_file, 'w') as f:
                json.dump(save_data, f, indent=2)
            self._print_debug(f"Token saved to {self.token_file}")
        except Exception as e:
            self._print_error(f"Failed to save token: {e}")
    
    def _load_token(self) -> Optional[Dict[str, Any]]:
        """Load token data from file."""
        if not self.token_file.exists():
            return None
        
        try:
            with open(self.token_file, 'r') as f:
                token_data = json.load(f)
            
            # Convert datetime string back to datetime object
            if 'expires_at_datetime' in token_data and isinstance(token_data['expires_at_datetime'], str):
                from datetime import datetime
                token_data['expires_at_datetime'] = datetime.fromisoformat(token_data['expires_at_datetime'])
            
            self._print_debug(f"Token loaded from {self.token_file}")
            return token_data
        except Exception as e:
            self._print_error(f"Failed to load token: {e}")
            return None
    
    def cmd_generate_token(self, args):
        """Generate a new access token."""
        self._print_info("Generating new access token...")
        
        try:
            # Get credentials from args or prompt
            username = args.username or Prompt.ask("Enter username")
            password = args.password or Prompt.ask("Enter password", password=True)
            device_id = args.device_id
            
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=self.console
            ) as progress:
                task = progress.add_task("Authenticating...", total=None)
                
                token_data = self.token_generator.generate_token(
                    username=username,
                    password=password,
                    device_id=device_id,
                    scope=args.scope
                )
                
                progress.update(task, description="Token generated!")
            
            # Save token if requested
            if args.save:
                self._save_token(token_data)
                self._print_success("Token saved to configuration")
            
            # Display token information
            self._display_token_info(token_data)
            
            # Save credentials to config if requested
            if args.save_config:
                config = self._load_config()
                config['username'] = username
                config['device_id'] = token_data['device_id_used']
                config['default_scope'] = args.scope
                self._save_config(config)
                self._print_success("Credentials saved to configuration")
                
        except AuthenticationError as e:
            self._print_error(f"Authentication failed: {e}")
        except NetworkError as e:
            self._print_error(f"Network error: {e}")
        except Exception as e:
            self._print_error(f"Unexpected error: {e}")
            if self.debug:
                import traceback
                traceback.print_exc()
    
    def cmd_generate_admin_token(self, args):
        """Generate an admin access token."""
        self._print_info("Generating admin access token...")
        
        try:
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=self.console
            ) as progress:
                task = progress.add_task("Authenticating as admin...", total=None)
                
                token_data = self.token_generator.generate_admin_token(
                    device_id=args.device_id,
                    scope=args.scope
                )
                
                progress.update(task, description="Admin token generated!")
            
            # Save token if requested
            if args.save:
                self._save_token(token_data)
                self._print_success("Admin token saved to configuration")
            
            # Display token information
            self._display_token_info(token_data)
            
        except AuthenticationError as e:
            self._print_error(f"Admin authentication failed: {e}")
        except NetworkError as e:
            self._print_error(f"Network error: {e}")
        except Exception as e:
            self._print_error(f"Unexpected error: {e}")
            if self.debug:
                import traceback
                traceback.print_exc()
    
    def cmd_validate_token(self, args):
        """Validate a saved or provided token."""
        if args.token:
            # Validate provided token
            try:
                token_info = self.token_generator.get_token_info(args.token)
                # Create mock token data for validation
                token_data = {"expires_at": token_info["expires_at"]}
            except:
                self._print_error("Invalid token format")
                return
        else:
            # Validate saved token
            token_data = self._load_token()
            if not token_data:
                self._print_error("No saved token found. Use --token to provide a token.")
                return
        
        if self.token_generator.validate_token(token_data):
            self._print_success("Token is valid")
            
            if self.console:
                expiry_time = datetime.fromtimestamp(token_data["expires_at"])
                self._print_info(f"Expires at: {expiry_time}")
            else:
                self._print_info(f"Expires at: {token_data['expires_at']}")
        else:
            self._print_error("Token is expired or invalid")
    
    def cmd_show_config(self, args):
        """Show current configuration."""
        config = self._load_config()
        token_data = self._load_token()
        
        if self.console:
            # Rich table output
            table = Table(title="MC5 API Configuration")
            table.add_column("Setting", style="cyan")
            table.add_column("Value", style="white")
            
            for key, value in config.items():
                if 'password' in key.lower():
                    value = "***" if value else "Not set"
                table.add_row(key, str(value))
            
            self.console.print(table)
            
            if token_data:
                self._print_info("\nToken Information:")
                self._display_token_info(token_data)
        else:
            # Basic output
            print("Configuration:")
            for key, value in config.items():
                if 'password' in key.lower():
                    value = "***" if value else "Not set"
                print(f"  {key}: {value}")
            
            if token_data:
                print("\nToken Information:")
                self._display_token_info(token_data)
    
    def cmd_clear_config(self, args):
        """Clear saved configuration."""
        self._print_info("Clearing saved configuration...")
        
        try:
            if self.config_file.exists():
                self.config_file.unlink()
                self._print_success("Configuration cleared")
            
            if self.token_file.exists():
                self.token_file.unlink()
                self._print_success("Tokens cleared")
            
            if self.log_file.exists():
                self.log_file.unlink()
                self._print_success("Logs cleared")
                
            self._print_success("All saved data cleared successfully")
        except Exception as e:
            self._print_error(f"Failed to clear configuration: {e}")
    
    def cmd_clan(self, args):
        """Handle clan management commands."""
        if not args.clan_command:
            self._print_error("Please specify a clan command. Use 'mc5 clan --help' for available commands.")
            return
        
        # Initialize client for clan operations
        try:
            client = MC5Client()
            
            # Try to load saved token
            token_data = self._load_token()
            if token_data:
                client._token_data = token_data
                self._print_success("Using saved authentication token")
            else:
                self._print_warning("No saved token found. Please generate a token first.")
                self._print_info("Run: mc5 generate-token --username 'user:pass' --password 'pass' --save")
                return
            
        except Exception as e:
            self._print_error(f"Failed to initialize client: {e}")
            return
        
        try:
            if args.clan_command == "search":
                self._cmd_clan_search(client, args)
            elif args.clan_command == "create":
                self._cmd_clan_create(client, args)
            elif args.clan_command == "info":
                self._cmd_clan_info(client, args)
            elif args.clan_command == "members":
                self._cmd_clan_members(client, args)
            elif args.clan_command == "invite":
                self._cmd_clan_invite(client, args)
            elif args.clan_command == "applications":
                self._cmd_clan_applications(client, args)
            elif args.clan_command == "accept":
                self._cmd_clan_accept(client, args)
            elif args.clan_command == "reject":
                self._cmd_clan_reject(client, args)
            elif args.clan_command == "apply":
                self._cmd_clan_apply(client, args)
            elif args.clan_command == "stats":
                self._cmd_clan_stats(client, args)
            elif args.clan_command == "leaderboard":
                self._cmd_clan_leaderboard(client, args)
            else:
                self._print_error(f"Unknown clan command: {args.clan_command}")
                
        except Exception as e:
            self._print_error(f"Clan command failed: {e}")
        finally:
            try:
                client.close()
            except:
                pass


    def run(self):
        """Run the CLI application."""
        import sys
        if len(sys.argv) < 2:
            self._print_help()
            return
        
        command = sys.argv[1]
        
        if command == "--help" or command == "-h":
            self._print_help()
        elif command == "version":
            self._print_version()
        else:
            self._print(f"Unknown command: {command}", "red")
            self._print_help()
    
    def _print_help(self):
        """Print help information."""
        self._print("🎮 MC5 API Client CLI", "cyan")
        self._print("=" * 30, "cyan")
        self._print("\nAvailable commands:", "yellow")
        self._print("  --help, -h    Show this help message")
        self._print("  version       Show version information")
        self._print("\n📚 For more examples, see the README.md file!", "green")
    
    def _print_version(self):
        """Print version information."""
        self._print("🎮 MC5 API Client v1.0.0", "cyan")
        self._print("📦 The ultimate Modern Combat 5 API library", "green")
        self._print("👤 Author: Chizoba", "blue")
        self._print("📧 Email: chizoba2026@hotmail.com", "blue")


def main():
    """Main entry point for the CLI."""
    cli = MC5CLI()
    cli.run()


if __name__ == "__main__":
    main()
