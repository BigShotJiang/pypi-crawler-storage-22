#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : advanced_chat_example.py
# | License  : MIT License © 2026 Chizoba
# | Brief    | Advanced chat utilities example for MC5 API Client
# ────────────────★─────────────────────────────────

"""
MC5 Advanced Chat Utilities Example

This example demonstrates advanced chat functionality including templates,
broadcasting, scheduling, and analytics.

Features shown:
- Message templates and macros
- Multi-language broadcasting
- Scheduled messaging
- Chat analytics and statistics
- Smart replies and automation
- Chat monitoring and health checks
"""

import sys
import os
import time
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'src'))

from mc5_api_client import (
    AdvancedChatManager, chat_manager, create_template, use_template,
    broadcast, schedule_chat, get_chat_stats, chat_report,
    announce_to_all, announce_to_europe, announce_to_asia,
    setup_smart_replies, auto_greet, monitor_chat_health
)

def main():
    print("💬 MC5 Advanced Chat Utilities Example")
    print("=" * 45)
    
    # Example 1: Message Templates
    print("\n📝 Example 1: Message Templates")
    print("-" * 35)
    
    # Create custom templates
    create_template("welcome", "Welcome to our server! Enjoy your stay!", ['en', 'fr', 'de'])
    create_template("team_up", "Let's team up and win this match!", ['en', 'fr', 'de'])
    create_template("victory", "Victory! Well played team!", ['en', 'fr', 'de'])
    
    # Use templates
    print("📝 Using templates:")
    use_template("welcome")
    time.sleep(2)
    use_template("team_up")
    time.sleep(2)
    use_template("victory")
    
    # Example 2: Multi-language Broadcasting
    print("\n🌍 Example 2: Multi-language Broadcasting")
    print("-" * 40)
    
    print("🌍 Broadcasting to all languages...")
    results = announce_to_all("Hello everyone from around the world! 🌍")
    
    print("📊 Broadcast Results:")
    for lang, result in results.items():
        status = "✅" if result else "❌"
        print(f"   {status} {lang.upper()}: {'Success' if result else 'Failed'}")
    
    # Example 3: Regional Broadcasting
    print("\n🌐 Example 3: Regional Broadcasting")
    print("-" * 35)
    
    print("🇪🇺 Broadcasting to Europe...")
    europe_results = announce_to_europe("Greetings to our European players! 🇪🇺")
    
    print("🌏 Broadcasting to Asia...")
    asia_results = announce_to_asia("Hello to our Asian players! 🌏")
    
    # Example 4: Scheduled Messaging
    print("\n⏰ Example 4: Scheduled Messaging")
    print("-" * 35)
    
    print("⏰ Scheduling messages...")
    
    # Schedule messages at different intervals
    schedule_id1 = schedule_chat("Scheduled message 1 - 5 seconds", 5, ['en'])
    schedule_id2 = schedule_chat("Scheduled message 2 - 10 seconds", 10, ['en', 'fr'])
    schedule_id3 = schedule_chat("Scheduled message 3 - 15 seconds", 15, ['en', 'fr', 'de'])
    
    print(f"📅 Scheduled messages with IDs: {schedule_id1}, {schedule_id2}, {schedule_id3}")
    
    # Wait for scheduled messages to send
    print("⏳ Waiting for scheduled messages...")
    time.sleep(20)
    
    # Example 5: Chat Analytics
    print("\n📊 Example 5: Chat Analytics")
    print("-" * 30)
    
    stats = get_chat_stats()
    if stats:
        print(f"📊 Session Duration: {stats.get('session_duration', 'Unknown')}")
        print(f"💬 Messages Sent: {stats.get('messages_sent', 0)}")
        print(f"📈 Avg Messages/Min: {stats.get('average_messages_per_minute', 0):.1f}")
        print(f"🌐 Most Used Language: {stats.get('most_used_language', 'None')}")
        print(f"📝 Templates Available: {stats.get('templates_available', 0)}")
        print(f"⏰ Scheduled Messages: {stats.get('scheduled_messages', 0)}")
        
        print("\n📊 Messages by Language:")
        for lang, count in stats.get('messages_by_language', {}).items():
            print(f"   {lang.upper()}: {count} messages")
    else:
        print("❌ No chat statistics available")
    
    # Example 6: Chat Report
    print("\n📋 Example 6: Chat Report")
    print("-" * 30)
    
    report = chat_report()
    print(report)
    
    # Example 7: Smart Replies Setup
    print("\n🤖 Example 7: Smart Replies Setup")
    print("-" * 35)
    
    print("🤖 Setting up smart reply system...")
    setup_smart_replies()
    print("✅ Smart replies enabled (would respond to common chat messages)")
    
    # Example 8: Chat Health Monitoring
    print("\n🏥 Example 8: Chat Health Monitoring")
    print("-" * 40)
    
    print("🏥 Starting chat health monitoring...")
    print("💡 This would monitor chat connectivity in the background")
    
    # Note: In a real scenario, this would run continuously
    # monitor_chat_health()
    print("💡 Chat health monitoring started (would run continuously)")
    
    # Example 9: Advanced Template Usage
    print("\n🎨 Example 9: Advanced Template Usage")
    print("-" * 40)
    
    # Create templates with variables
    create_template("player_welcome", "Welcome {player} to level {level}!", ['en', 'fr'])
    create_template("achievement", "Congratulations {player} on {achievement}!", ['en', 'fr'])
    
    # Use templates with variables
    print("🎨 Using advanced templates with variables:")
    use_template("player_welcome", player="NewPlayer", level="5")
    time.sleep(2)
    use_template("achievement", player="ProGamer", achievement="Level 100")
    
    # Example 10: Chat Automation
    print("\n⚡ Example 10: Chat Automation")
    print("-" * 30)
    
    print("⚡ Setting up chat automation...")
    
    # Auto-greet (would run continuously)
    print("🤖 Auto-greet system ready (would greet every 30 minutes)")
    # auto_greet(30)  # Uncomment to enable
    
    print("✅ Chat automation configured")
    
    print("\n💬 Advanced Chat Example Completed!")
    print("💡 Try different templates and automation features!")
    print("🤖 Smart replies and monitoring enhance chat experience!")

if __name__ == "__main__":
    main()
