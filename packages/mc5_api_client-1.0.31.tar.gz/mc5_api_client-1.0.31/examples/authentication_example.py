#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : authentication_example.py
# | License  | MIT License © 2026 Chizoba
# | Brief    | Example of MC5 authentication with proper scopes
# ────────────────★─────────────────────────────────

"""
MC5 Authentication Example
=======================

This example demonstrates how to authenticate with MC5 servers using different methods.
Shows proper token generation and usage with correct scopes.

Setup:
1. Replace YOUR_CREDENTIAL and YOUR_PASSWORD with your actual MC5 credentials
2. Or set environment variables:
   export MC5_USERNAME="your_credential"
   export MC5_PASSWORD="your_password"
"""

import os
import sys
from mc5_api_client import MC5Client, TokenGenerator, generate_encrypted_token

def main():
    """Demonstrate MC5 authentication methods."""
    print("🔐 MC5 Authentication Examples")
    print("=" * 40)
    
    # Method 1: Use environment variables (recommended)
    username = os.getenv('MC5_USERNAME') or "YOUR_MC5_CREDENTIAL"
    password = os.getenv('MC5_PASSWORD') or "YOUR_MC5_PASSWORD"
    
    if username == "YOUR_MC5_CREDENTIAL" or password == "YOUR_MC5_PASSWORD":
        print("⚠️ Please set your MC5 credentials:")
        print("   Option 1: Set environment variables MC5_USERNAME and MC5_PASSWORD")
        print("   Option 2: Edit the username and password variables in this script")
        print()
        print("   Example:")
        print("   export MC5_USERNAME='anonymous:your_credential_here'")
        print("   export MC5_PASSWORD='your_password_here'")
        return
    
    print(f"🔑 Using credentials: {username[:30]}...")
    print()
    
    # === Method 1: Using MC5Client ===
    print("🎮 Method 1: Using MC5Client")
    print("-" * 30)
    
    try:
        client = MC5Client(username=username, password=password)
        client.authenticate()
        
        print("✅ MC5Client authentication successful!")
        print(f"   Token: {client._token_data['access_token'][:30]}...")
        print(f"   Scopes: {client._token_data.get('scopes', [])}")
        
        # Test getting profile (requires storage scope)
        try:
            profile = client.get_profile()
            print("✅ Profile retrieved successfully!")
            print(f"   Name: {profile.get('name', 'Unknown')}")
            print(f"   Level: {profile.get('level', 'Unknown')}")
        except Exception as e:
            print(f"⚠️ Profile access: {e}")
            print("   💡 This might need additional scopes like 'storage'")
        
        client.close()
        
    except Exception as e:
        print(f"❌ MC5Client authentication failed: {e}")
    
    print()
    
    # === Method 2: Using TokenGenerator directly ===
    print("🔧 Method 2: Using TokenGenerator")
    print("-" * 35)
    
    try:
        token_gen = TokenGenerator(client_id="1875:55979:6.0.0a:windows:windows")
        
        # Try with basic scopes
        basic_scopes = "alert auth chat leaderboard_ro lobby message session social"
        token_data = token_gen.generate_token(
            username=username,
            password=password,
            scope=basic_scopes
        )
        
        print("✅ TokenGenerator authentication successful!")
        print(f"   Token: {token_data['access_token'][:30]}...")
        print(f"   Scopes: {token_data.get('scopes', [])}")
        
        token_gen.close()
        
    except Exception as e:
        print(f"❌ TokenGenerator authentication failed: {e}")
    
    print()
    
    # === Method 3: Generate encrypted token ===
    print("🔒 Method 3: Generate Encrypted Token")
    print("-" * 40)
    
    try:
        encrypted_data = generate_encrypted_token(
            username=username,
            password=password,
            scope="alert auth chat social storage"
        )
        
        print("✅ Encrypted token generated successfully!")
        print(f"   Encrypted: {encrypted_data.get('encrypted_token', '')[:50]}...")
        print(f"   Nonce: {encrypted_data.get('nonce', '')}")
        
    except Exception as e:
        print(f"❌ Encrypted token generation failed: {e}")
    
    print()
    
    # === Method 4: Using MC5Easy (if available) ===
    print("🎯 Method 4: Using MC5Easy (Super Simple)")
    print("-" * 42)
    
    try:
        from mc5_api_client import MC5Easy
        
        with MC5Easy(username, password) as mc5:
            print("✅ MC5Easy authentication successful!")
            
            # Quick status
            status = mc5.quick_status()
            print("📊 Quick Status:")
            print(status)
            
    except Exception as e:
        print(f"❌ MC5Easy authentication failed: {e}")
    
    print()
    print("🎉 Authentication examples completed!")
    print("💡 Tips:")
    print("   - Use MC5Easy for everyday tasks")
    print("   - Use TokenGenerator for advanced control")
    print("   - Use MC5Client for full API access")
    print("   - Add 'storage' scope for profile access")

def demo_scopes():
    """Demonstrate different scope combinations."""
    print("\n🔍 Scope Examples")
    print("=" * 20)
    
    username = os.getenv('MC5_USERNAME')
    password = os.getenv('MC5_PASSWORD')
    
    if not username or not password:
        print("⚠️ Set MC5_USERNAME and MC5_PASSWORD environment variables to test scopes")
        return
    
    scope_examples = [
        ("Basic", "alert auth chat social"),
        ("With Storage", "alert auth chat social storage"),
        ("With Leaderboard", "alert auth chat social storage leaderboard_ro"),
        ("Full Access", "alert auth chat social storage storage_restricted storage_admin leaderboard_ro lobby message session config tracking_bi feed storage leaderboard_admin social_eve social soc transaction schedule lottery voice matchmaker")
    ]
    
    token_gen = TokenGenerator(client_id="1875:55979:6.0.0a:windows:windows")
    
    try:
        for name, scope in scope_examples:
            print(f"\n🎯 {name} Scopes:")
            print(f"   Scope: {scope}")
            
            try:
                token_data = token_gen.generate_token(
                    username=username,
                    password=password,
                    scope=scope
                )
                
                print(f"   ✅ Success! Scopes: {token_data.get('scopes', [])}")
                
            except Exception as e:
                print(f"   ❌ Failed: {e}")
    
    finally:
        token_gen.close()

if __name__ == "__main__":
    main()
    
    # Uncomment to test different scopes
    # demo_scopes()
