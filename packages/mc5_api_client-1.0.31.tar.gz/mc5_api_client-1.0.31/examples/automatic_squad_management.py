#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : automatic_squad_management.py
# | License  | MIT License © 2026 Chizoba
# | Brief    | Automatic squad management examples
# ────────────────★─────────────────────────────────

"""
Automatic Squad Management Examples for MC5 API Client

This example demonstrates the new automatic squad management feature
that eliminates the need to manually specify squad IDs.

FEATURES:
✅ Automatic squad ID detection from user profile
✅ Easy squad information retrieval
✅ Simple squad updates without manual ID
✅ Squad member management
✅ Works even when switching squads
"""

import os
from mc5_api_client import MC5Client, get_my_squad_id, get_my_squad_info, update_my_squad_info, get_my_squad_members

def main():
    """Demonstrate automatic squad management."""
    print("🎮 MC5 API Client - Automatic Squad Management")
    print("=" * 60)
    print("🚀 NEW FEATURE: No more manual squad ID required!")
    print()
    
    # Your credentials
    username = "anonymous:d2luOF92M18xNzcwMDUxNjkwXy7H33aeTVB4YZictyDq48c="
    password = "sSJKzhQ5l4vrFgov"
    
    try:
        # Initialize client
        print("🔐 Initializing client...")
        client = MC5Client(
            client_id="1875:55979:6.0.0a:windows:windows",
            username=username,
            password=password
        )
        
        print("✅ Client initialized successfully!")
        print()
        
        # Example 1: Get squad ID automatically
        print("📋 Example 1: Get Squad ID Automatically")
        print("-" * 45)
        
        squad_id = client.get_my_squad_id()
        if squad_id:
            print(f"✅ Your squad ID: {squad_id}")
            print("   (Automatically fetched from your profile)")
        else:
            print("❌ You are not currently in any squad")
            return
        
        print()
        
        # Example 2: Get squad information automatically
        print("📊 Example 2: Get Squad Information Automatically")
        print("-" * 50)
        
        squad_info = client.get_my_squad_info()
        if squad_info and 'error' not in squad_info:
            print("✅ Squad information retrieved:")
            print(f"   🏷️  Name: {squad_info.get('name', 'Unknown')}")
            print(f"   📝 Description: {squad_info.get('description', 'No description')}")
            print(f"   ⭐ Rating: {squad_info.get('rating', 'Unknown')}")
            print(f"   🎯 Min Join Value: {squad_info.get('min_join_value', 'Unknown')}")
            print(f"   🆔 Auto-fetched ID: {squad_info.get('auto_fetched_squad_id', 'Unknown')}")
        else:
            print(f"❌ Failed to get squad info: {squad_info.get('error', 'Unknown')}")
        
        print()
        
        # Example 3: Get squad members automatically
        print("👥 Example 3: Get Squad Members Automatically")
        print("-" * 45)
        
        squad_members = client.get_my_squad_members()
        if squad_members and 'error' not in squad_members:
            print("✅ Squad members retrieved:")
            print(f"   🆔 Squad ID: {squad_members.get('squad_id', 'Unknown')}")
            print(f"   👥 Member Count: {squad_members.get('member_count', 0)}")
            
            members = squad_members.get('members', [])
            if members and isinstance(members, list):
                print("   📋 Members:")
                for i, member in enumerate(members[:5]):  # Show first 5 members
                    if isinstance(member, dict):
                        name = member.get('name', member.get('nickname', 'Unknown'))
                        role = member.get('role', 'Member')
                        print(f"      {i+1}. {name} ({role})")
                
                if len(members) > 5:
                    print(f"      ... and {len(members) - 5} more members")
        else:
            print(f"❌ Failed to get squad members: {squad_members.get('error', 'Unknown')}")
        
        print()
        
        # Example 4: Update squad information automatically (DEMO)
        print("🔧 Example 4: Update Squad Information (Demo)")
        print("-" * 45)
        
        print("📝 Demo: How to update your squad automatically")
        print("   (This is a demo - we won't actually update to avoid changes)")
        print()
        print("   # Update squad name and description")
        print("   result = client.update_my_squad_info(")
        print("       name='Elite Squad',")
        print("       description='Best squad in MC5!',")
        print("       rating=2000")
        print("   )")
        print()
        print("   # The squad ID is automatically fetched!")
        print("   # No need to specify squad_id manually!")
        
        print()
        
        # Example 5: Using standalone functions
        print("🚀 Example 5: Using Standalone Functions")
        print("-" * 40)
        
        print("📝 You can also use standalone functions:")
        print()
        
        # Get squad ID using standalone function
        squad_id_standalone = get_my_squad_id(
            username=username,
            password=password
        )
        print(f"   ✅ Standalone squad ID: {squad_id_standalone}")
        
        # Get squad info using standalone function
        squad_info_standalone = get_my_squad_info(
            username=username,
            password=password
        )
        if squad_info_standalone and 'error' not in squad_info_standalone:
            print(f"   ✅ Standalone squad name: {squad_info_standalone.get('name', 'Unknown')}")
        
        print()
        
        # Example 6: Comparison with traditional method
        print("🔄 Example 6: Comparison with Traditional Method")
        print("-" * 50)
        
        print("📝 Traditional method (requires manual squad ID):")
        print("   ❌ squad_id = '12345'  # User must know this")
        print("   ❌ squad_info = client.get_clan_settings(squad_id)")
        print("   ❌ members = client.get_clan_members(squad_id)")
        print("   ❌ client.update_clan_settings(squad_id, name='New Name')")
        print()
        
        print("🚀 NEW automatic method (no squad ID needed):")
        print("   ✅ squad_info = client.get_my_squad_info()  # Auto-fetched!")
        print("   ✅ members = client.get_my_squad_members()  # Auto-fetched!")
        print("   ✅ client.update_my_squad_info(name='New Name')  # Auto-fetched!")
        print()
        
        # Example 7: Benefits
        print("💎 Example 7: Benefits of Automatic Squad Management")
        print("-" * 55)
        
        print("✅ Benefits:")
        print("   🎯 No need to remember squad ID")
        print("   🔄 Works when you switch squads")
        print("   🛡️ Error handling for users without squads")
        print("   🚀 Simpler API for everyday use")
        print("   📱 Perfect for mobile and web apps")
        print("   🔧 Easy integration with existing code")
        
        print()
        print("🎉 Automatic Squad Management is working perfectly!")
        
    except Exception as e:
        print(f"❌ Error: {e}")
        print("💡 Make sure your credentials are correct and you're in a squad")

def demonstrate_squad_switching():
    """Demonstrate how the feature works when switching squads."""
    print("\n🔄 Scenario: Squad Switching")
    print("=" * 35)
    
    print("📝 When you switch squads:")
    print("   1. Leave current squad")
    print("   2. Join new squad")
    print("   3. The automatic methods will detect the new squad!")
    print()
    
    print("🚀 No code changes needed:")
    print("   squad_info = client.get_my_squad_info()  # Always gets current squad!")
    print("   members = client.get_my_squad_members()  # Always gets current members!")
    print("   client.update_my_squad_info(name='New Name')  # Updates current squad!")

if __name__ == "__main__":
    main()
    demonstrate_squad_switching()
