#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : basic_chat_example.py
# | License  : MIT License © 2026 Chizoba
# | Brief    : Basic MC5 chat example - send messages to different languages
# ────────────────★─────────────────────────────────

"""
MC5 API Client - Basic Chat Example

This example demonstrates the ultra-simple chat functionality.
Send messages to different language channels with just one line!

Features shown:
- Basic message sending
- Multi-language support
- One-liner functions
- Connection testing
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'src'))

from mc5_api_client import send, en, fr, de, es, it, pt, ru, ja, ko, zh, hello, goodbye, test, ping, thanks, test_connection

def main():
    print("🎮 MC5 API Client - Basic Chat Example")
    print("=" * 50)
    
    # Test connection first
    print("\n🔗 Testing connection...")
    if test_connection():
        print("✅ Connection successful!")
    else:
        print("❌ Connection failed!")
        return
    
    # Basic message sending
    print("\n📤 Sending basic messages...")
    
    # Send to English chat
    result = send("Hello from Python script!")
    print(f"✅ English message sent: {result}")
    
    # Send to different languages
    languages = [
        ("en", "Hello from English!"),
        ("fr", "Bonjour du français!"),
        ("de", "Hallo von Deutsch!"),
        ("es", "¡Hola desde español!"),
        ("it", "Ciao dall'italiano!"),
        ("pt", "Olá do português!"),
        ("ru", "Привет из русского!"),
        ("ja", "こんにちはから日本語!"),
        ("ko", "안녕하세요 한국어에서!"),
        ("zh", "你好来自中文!")
    ]
    
    for lang, message in languages:
        func = globals()[lang]
        result = func(message)
        print(f"✅ {lang.upper()} message sent: {result}")
    
    # One-liner functions
    print("\n⚡ Using one-liner functions...")
    
    oneliners = [
        ("hello", hello),
        ("goodbye", goodbye),
        ("test", test),
        ("ping", ping),
        ("thanks", thanks)
    ]
    
    for name, func in oneliners:
        result = func()
        print(f"✅ {name}() sent: {result}")
    
    print("\n🎉 Basic chat example completed!")
    print("💡 Try modifying the messages and languages!")

if __name__ == "__main__":
    main()
