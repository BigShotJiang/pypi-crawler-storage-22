#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : chat_example.py
# | License  : MIT License © 2026 Chizoba
# | Brief    : MC5 Chat API example with real-time messaging
# ────────────────★─────────────────────────────────

"""
MC5 Chat API Example

This example demonstrates the MC5 chat functionality including:
- Dynamic server discovery via subscription API
- Sending messages to different language channels
- Real-time chat message listening
- Unicode name support
- Error handling and reconnection

Usage:
    python chat_example.py
"""

import sys
import os
import time
import threading
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from mc5_api_client import MC5ChatClient, send_chat_message, listen_to_chat

def print_chat_message(message_data):
    """Print incoming chat messages with formatting."""
    msg_type = message_data.get('type', 'unknown')
    
    if msg_type == 'message':
        sender = message_data.get('_senderName', 'Unknown')
        msg = message_data.get('msg', '')
        timestamp = message_data.get('sent', '')
        
        # Decode Unicode names
        try:
            from mc5_api_client import decode_unicode_name
            sender = decode_unicode_name(sender)
        except:
            pass
        
        print(f"💬 [{timestamp}] {sender}: {msg}")
        
    elif msg_type == 'room_info':
        num_members = message_data.get('num_members', 0)
        send_quota = message_data.get('send_quota', 0)
        print(f"🏠 Chat Room: {num_members} members online | Send quota: {send_quota}/min")
        
    elif msg_type == 'disconnect':
        reason = message_data.get('reason', 'Unknown')
        print(f"🔌 Disconnected: {reason}")
        
    else:
        print(f"📡 [{msg_type}] {message_data}")

def demonstrate_basic_messaging():
    """Demonstrate basic chat messaging."""
    
    print("📤 Basic Chat Messaging Demo")
    print("=" * 40)
    
    # Test English channel
    print("\n🇬🇧 Sending message to English channel...")
    result = send_chat_message("Hello from MC5 API Client!", language="en")
    
    if result.get('success'):
        print(f"✅ Message sent successfully!")
        print(f"   Message ID: {result.get('message_id')}")
        print(f"   Sent time: {result.get('sent_time')}")
    else:
        print(f"❌ Failed to send message: {result.get('error')}")
    
    # Test French channel
    print("\n🇫🇷 Sending message to French channel...")
    result = send_chat_message("Bonjour depuis le client API MC5!", language="fr")
    
    if result.get('success'):
        print(f"✅ Message sent successfully!")
        print(f"   Message ID: {result.get('message_id')}")
        print(f"   Sent time: {result.get('sent_time')}")
    else:
        print(f"❌ Failed to send message: {result.get('error')}")

def demonstrate_advanced_messaging():
    """Demonstrate advanced chat messaging with custom parameters."""
    
    print("\n📤 Advanced Chat Messaging Demo")
    print("=" * 40)
    
    client = MC5ChatClient()
    
    # Test with custom nickname and parameters
    test_messages = [
        ("Testing text support", "TestUser", "en"),
        ("Testing Unicode: jυвәιя", "UnicodeTest", "en"),
        ("Testing special chars: @#$%^&*()", "SpecialChars", "en"),
        ("Bonjour le monde!", "TestUserFR", "fr"),
    ]
    
    for message, nickname, language in test_messages:
        print(f"\n📤 Sending to {language} channel: '{message}' as '{nickname}'")
        result = client.send_message(message, nickname=nickname, language=language)
        
        if result.get('success'):
            print(f"✅ Sent successfully (ID: {result.get('message_id')})")
        else:
            print(f"❌ Failed: {result.get('error')}")
        
        time.sleep(1)  # Small delay between messages

def demonstrate_server_discovery():
    """Demonstrate dynamic server discovery via subscription API."""
    
    print("\n🔗 Dynamic Server Discovery Demo")
    print("=" * 40)
    
    client = MC5ChatClient()
    
    # Test different language channels
    languages = ["en", "fr", "de", "es"]
    
    for lang in languages:
        print(f"\n🌍 Subscribing to {lang.upper()} channel...")
        subscription = client.subscribe_to_chat_channel(lang)
        
        if subscription:
            cmd_url = subscription.get('cmd_url', '')
            if cmd_url:
                # Extract server info from URL
                parts = cmd_url.split(':')
                if len(parts) >= 3:
                    server = parts[2].split('/')[0]
                    port = parts[3].split('/')[0]
                    print(f"✅ {lang.upper()} server: {server}:{port}")
            else:
                print(f"❌ No command URL for {lang}")
        else:
            print(f"❌ Failed to subscribe to {lang}")

def demonstrate_chat_listening():
    """Demonstrate real-time chat message listening."""
    
    print("\n🎧 Real-time Chat Listening Demo")
    print("=" * 40)
    print("Listening to English chat for 15 seconds...")
    print("(Press Ctrl+C to stop early)")
    
    try:
        # Start listening to English channel
        client = listen_to_chat(
            callback=print_chat_message,
            language="en",
            use_https=False  # Use HTTP for better compatibility
        )
        
        # Listen for 15 seconds
        time.sleep(15)
        
        # Stop listening
        client.stop_listening()
        print(f"\n✅ Stopped listening")
        
    except KeyboardInterrupt:
        print(f"\n🛑 Stopped by user")
        client.stop_listening()

def demonstrate_multilingual_listening():
    """Demonstrate listening to multiple language channels."""
    
    print("\n🌍 Multilingual Chat Listening Demo")
    print("=" * 40)
    
    # Test French channel
    print("🇫🇷 Listening to French chat for 10 seconds...")
    try:
        client_fr = listen_to_chat(
            callback=print_chat_message,
            language="fr",
            use_https=False
        )
        
        time.sleep(10)
        client_fr.stop_listening()
        print(f"✅ French channel listening complete")
        
    except KeyboardInterrupt:
        print(f"🛑 Stopped by user")
        client_fr.stop_listening()

def demonstrate_context_manager():
    """Demonstrate using chat client as context manager."""
    
    print("\n🔄 Context Manager Demo")
    print("=" * 30)
    
    try:
        with MC5ChatClient() as client:
            print("✅ Connected to MC5 chat system")
            
            # Subscribe to English channel
            subscription = client.subscribe_to_chat_channel("en")
            if subscription:
                print(f"✅ Subscribed to English channel")
                print(f"   Server: {subscription.get('cmd_url', '').split(':')[2].split('/')[0]}")
            
            # Send a test message
            result = client.send_message("Context manager test!", language="en")
            if result.get('success'):
                print("✅ Message sent through context manager")
            else:
                print(f"❌ Message failed: {result.get('error')}")
                
    except Exception as e:
        print(f"❌ Context manager error: {e}")

def demonstrate_error_handling():
    """Demonstrate error handling and edge cases."""
    
    print("\n🧪 Error Handling Demo")
    print("=" * 30)
    
    # Test with invalid language
    print("🔍 Testing with invalid language...")
    result = send_chat_message("Test message", language="invalid")
    if not result.get('success'):
        print("✅ Correctly handled invalid language")
    
    # Test with very long message
    print("🔍 Testing with very long message...")
    long_message = "A" * 1000  # 1000 character message
    result = send_chat_message(long_message, language="en")
    if result.get('success'):
        print("✅ Long message handled successfully")
    else:
        print(f"❌ Long message failed: {result.get('error')}")
    
    # Test with empty message
    print("🔍 Testing with empty message...")
    result = send_chat_message("", language="en")
    if result.get('success'):
        print("✅ Empty message handled successfully")
    else:
        print(f"❌ Empty message failed: {result.get('error')}")

def main():
    """Run all chat demonstrations."""
    
    print("🎮 MC5 API Client - Chat Functionality Example")
    print("=" * 60)
    print("Comprehensive demonstration of MC5 chat API functionality")
    print("Features: Dynamic server discovery, multilingual support, real-time messaging")
    print()
    
    # Run demonstrations
    demonstrations = [
        ("Basic Messaging", demonstrate_basic_messaging),
        ("Advanced Messaging", demonstrate_advanced_messaging),
        ("Server Discovery", demonstrate_server_discovery),
        ("Chat Listening", demonstrate_chat_listening),
        ("Multilingual Listening", demonstrate_multilingual_listening),
        ("Context Manager", demonstrate_context_manager),
        ("Error Handling", demonstrate_error_handling),
    ]
    
    for demo_name, demo_func in demonstrations:
        print(f"\n{'='*60}")
        print(f"🧪 Running Demo: {demo_name}")
        print(f"{'='*60}")
        
        try:
            demo_func()
            print(f"\n✅ {demo_name} completed successfully")
        except Exception as e:
            print(f"\n❌ Error in {demo_name}: {e}")
        
        print(f"\n⏳ Waiting 2 seconds before next demo...")
        time.sleep(2)
    
    # Summary
    print(f"\n{'='*60}")
    print("📊 DEMO SUMMARY")
    print(f"{'='*60}")
    print("✅ Dynamic server discovery via subscription API")
    print("✅ Multilingual chat support (EN, FR, DE, ES)")
    print("✅ Real-time message streaming")
    print("✅ Unicode name support")
    print("✅ Context manager support")
    print("✅ Comprehensive error handling")
    print("✅ HTTP/HTTPS protocol flexibility")
    print()
    print("🎉 Chat functionality is ready for production use!")
    print()
    print("📋 Quick Reference:")
    print("   send_chat_message('Hello!', language='en')")
    print("   listen_to_chat(callback, language='en')")
    print("   MC5ChatClient().subscribe_to_chat_channel('fr')")
    print("   with MC5ChatClient() as client: ...")
    print()
    print("🚀 Ready to add to examples directory!")

if __name__ == "__main__":
    main()
