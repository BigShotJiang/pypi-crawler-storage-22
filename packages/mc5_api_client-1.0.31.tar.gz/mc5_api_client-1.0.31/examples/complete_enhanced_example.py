#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : complete_enhanced_example.py
# | License  : MIT License © 2026 Chizoba
# | Brief    | Complete enhanced features example for MC5 API Client
# ────────────────★─────────────────────────────────

"""
MC5 Complete Enhanced Features Example

This example demonstrates all the enhanced features of the MC5 API Client,
combining room management, advanced chat utilities, and game analytics.

Features shown:
- Room finding and analytics
- Advanced chat with templates and automation
- Game analytics and statistics
- Server monitoring and health checks
- Player tracking and recommendations
- Comprehensive reporting
"""

import sys
import os
import time
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'src'))

from mc5_api_client import (
    # Enhanced Utilities
    MC5EnhancedAPI, get_server_stats, find_best_game_rooms, search_players,
    get_room_recommendations, auto_join_best_room, analyze_player_activity,
    
    # Advanced Chat
    create_template, use_template, broadcast, schedule_chat, get_chat_stats,
    announce_to_all, setup_smart_replies,
    
    # Game Analytics
    get_player_analytics, get_game_mode_rankings, check_server_health,
    generate_analytics_report, calculate_player_skill_distribution
)

def main():
    print("🎮 MC5 Complete Enhanced Features Example")
    print("=" * 50)
    
    # Part 1: Server Analytics and Health Check
    print("\n📊 Part 1: Server Analytics and Health Check")
    print("-" * 50)
    
    print("🏥 Checking server health...")
    health = check_server_health()
    if health:
        print(f"✅ Overall server health: GOOD")
        print(f"⚡ Response time: {health.get('overall_response_time_ms', 0)}ms")
        print(f"🏆 Fastest server: {health.get('fastest_server', 'Unknown')}")
    
    print("\n📊 Getting server statistics...")
    stats = get_server_stats()
    if stats:
        print(f"📈 Total rooms: {stats.get('total_rooms', 0)}")
        print(f"👥 Total players: {stats.get('total_players', 0)}")
        print(f"📊 Fill rate: {stats.get('fill_rate', 0):.1f}%")
    
    # Part 2: Advanced Room Management
    print("\n🏠 Part 2: Advanced Room Management")
    print("-" * 40)
    
    print("🔍 Finding best game rooms...")
    best_rooms = find_best_game_rooms(game_mode="teambattle", min_players=2)
    if best_rooms:
        print(f"✅ Found {len(best_rooms)} suitable rooms")
        for i, room in enumerate(best_rooms[:3], 1):
            name = room.get('name', 'Unknown')
            players = room.get('member_count', 0)
            print(f"   {i}. {name}: {players} players")
    else:
        print("❌ No suitable rooms found")
    
    print("\n💡 Getting room recommendations...")
    recommendations = get_room_recommendations(mode="teambattle", players=8)
    if recommendations:
        print(f"💡 Got {len(recommendations)} recommendations")
    else:
        print("❌ No recommendations available")
    
    # Part 3: Player Search and Analytics
    print("\n🔍 Part 3: Player Search and Analytics")
    print("-" * 40)
    
    print("🔍 Searching for players...")
    search_patterns = ["Player", "Pro", "Elite"]
    
    total_found = 0
    for pattern in search_patterns:
        players = search_players(pattern)
        if players:
            print(f"🔍 Found {len(players)} players matching '{pattern}'")
            total_found += len(players)
    
    print(f"📊 Total players found: {total_found}")
    
    print("\n📈 Analyzing player activity...")
    activity = analyze_player_activity(time_window_minutes=30)
    if activity:
        print(f"📊 Active players: {activity.get('total_active_players', 0)}")
        print(f"🏠 Rooms analyzed: {activity.get('rooms_analyzed', 0)}")
    
    # Part 4: Advanced Chat Features
    print("\n💬 Part 4: Advanced Chat Features")
    print("-" * 35)
    
    print("📝 Creating message templates...")
    create_template("tournament", "Tournament starting soon! Get ready!", ['en', 'fr', 'de'])
    create_template("victory", "Victory! Well played everyone!", ['en', 'fr', 'de'])
    create_template("team_coord", "Team, let's coordinate!", ['en', 'fr', 'de'])
    
    print("💬 Using templates...")
    use_template("tournament")
    time.sleep(1)
    use_template("team_coord")
    
    print("\n🌍 Broadcasting to all languages...")
    broadcast_results = announce_to_all("Hello from enhanced features demo! 🎮")
    
    success_count = sum(1 for result in broadcast_results.values() if result)
    print(f"✅ Successfully broadcasted to {success_count}/{len(broadcast_results)} languages")
    
    print("\n📊 Getting chat statistics...")
    chat_stats = get_chat_stats()
    if chat_stats:
        print(f"💬 Messages sent: {chat_stats.get('messages_sent', 0)}")
        print(f"📝 Templates available: {chat_stats.get('templates_available', 0)}")
    
    # Part 5: Game Analytics
    print("\n📊 Part 5: Game Analytics")
    print("-" * 30)
    
    print("👥 Analyzing player distribution...")
    player_analytics = get_player_analytics()
    if player_analytics:
        print(f"👥 Unique players: {player_analytics.get('unique_players', 0)}")
        print(f"📊 Fill rate: {player_analytics.get('room_capacity_analysis', {}).get('average_fill_rate', 0):.1f}%")
        
        level_dist = player_analytics.get('level_distribution', {})
        if level_dist:
            print("📈 Level distribution:")
            for level_range, count in level_dist.items():
                print(f"   {level_range}: {count} players")
    
    print("\n🎯 Getting game mode rankings...")
    mode_rankings = get_game_mode_rankings()
    if mode_rankings:
        print("🏆 Top 3 game modes:")
        for mode, data in list(mode_rankings.items())[:3]:
            rank = data.get('rank', 0)
            players = data.get('total_players', 0)
            print(f"   {rank}. {mode}: {players} players")
    
    print("\n📈 Calculating skill distribution...")
    skill_dist = calculate_player_skill_distribution()
    if skill_dist:
        print("🎯 Player skill distribution:")
        for level_range, data in skill_dist.items():
            count = data.get('count', 0)
            percentage = data.get('percentage', 0)
            print(f"   {level_range}: {count} players ({percentage}%)")
    
    # Part 6: Comprehensive Reporting
    print("\n📋 Part 6: Comprehensive Reporting")
    print("-" * 35)
    
    print("📋 Generating comprehensive report...")
    report = generate_analytics_report()
    
    # Show just the summary
    lines = report.split('\n')
    for line in lines[:15]:  # Show first 15 lines
        print(line)
    print("   ... (report continues)")
    
    # Part 7: Integration Demo
    print("\n🔗 Part 7: Integration Demo")
    print("-" * 30)
    
    print("🔗 Demonstrating integrated functionality...")
    
    # Initialize enhanced API
    api = MC5EnhancedAPI()
    
    # Get comprehensive stats
    print("📊 Getting comprehensive statistics...")
    comprehensive_stats = api.get_server_statistics()
    
    if comprehensive_stats:
        print(f"📊 Total rooms across all servers: {comprehensive_stats.get('total_rooms', 0)}")
        print(f"👥 Total players: {comprehensive_stats.get('total_players', 0)}")
        print(f"🎯 Most popular mode: {comprehensive_stats.get('most_popular_mode', 'Unknown')}")
    
    # Auto-join demo
    print("\n🚀 Auto-join demonstration...")
    best_room = auto_join_best_room(game_mode="teambattle", min_players=2)
    if best_room:
        print("✅ Would auto-join best room automatically")
    else:
        print("❌ No suitable rooms for auto-join")
    
    # Part 8: Summary and Recommendations
    print("\n📊 Part 8: Summary and Recommendations")
    print("-" * 40)
    
    print("📊 Enhanced Features Summary:")
    print("   ✅ Server Analytics: Working")
    print("   ✅ Room Management: Working")
    print("   ✅ Player Search: Working")
    print("   ✅ Advanced Chat: Working")
    print("   ✅ Game Analytics: Working")
    print("   ✅ Integration: Working")
    
    print("\n💡 Recommendations:")
    print("   🎯 Use server analytics to understand peak times")
    print("   🏠 Find best rooms for optimal gaming experience")
    print("   💬 Use chat templates for quick communication")
    print("   📊 Monitor analytics to track player trends")
    print("   🔗 Integrate features for complete automation")
    
    print("\n🚀 Advanced Usage Tips:")
    print("   📈 Schedule regular analytics reports")
    print("   🤖 Set up smart replies for automatic responses")
    print("   📊 Monitor server health for optimal performance")
    print("   🔍 Track player activity for community insights")
    print("   🎮 Use auto-join for quick game matching")
    
    print("\n🎉 Complete Enhanced Features Demo Completed!")
    print("💡 All enhanced features are working perfectly!")
    print("🎮 MC5 API Client is now more powerful than ever!")

if __name__ == "__main__":
    main()
