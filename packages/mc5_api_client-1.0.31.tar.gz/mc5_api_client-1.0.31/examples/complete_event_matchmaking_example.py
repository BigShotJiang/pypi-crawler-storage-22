#!/usr/bin/env python3
# ────────────[ KAKUZU ]────────────────────────────
# | Discord  : kakuzu_f0
# | Telegram : kakuzu_f0
# | File     | complete_event_matchmaking_example.py
# | License  : MIT License © 2026 Kakuzu
# | Brief    | Complete event and matchmaking example for MC5 API Client
# ────────────────★─────────────────────────────────

"""
Complete Event and Matchmaking Example

This example demonstrates the complete workflow for MC5 events and matchmaking,
including event registration, leaderboard viewing, matchmaking, and game finding.

Based on reverse-engineered API endpoints for MC5 events and matchmaking.
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'src'))

from mc5_api_client import (
    # Event System
    MC5EventSystem, register_current_event, show_current_event_leaderboard, 
    show_my_current_event_status,
    # Matchmaking System
    MC5MatchmakingSystem, current_event_quick_play, quick_battle, quick_team_battle,
    # Leaderboard System
    MC5LeaderboardSystem, show_my_current_event_context, analyze_current_event
)

def main():
    print("🎮 Complete Event & Matchmaking Example")
    print("=" * 50)
    
    # Step 1: Register for current event
    print("\n📝 Step 1: Register for Current Event")
    print("-" * 40)
    
    try:
        event_system = MC5EventSystem()
        success = event_system.register_for_event("0c646c6a-e61c-11f0-be58-b8ca3a634708")
        
        if success:
            print("✅ Successfully registered for current event!")
        else:
            print("❌ Failed to register for current event")
            
    except Exception as e:
        print(f"❌ Error: {e}")
    
    # Step 2: Check your event status
    print("\n👤 Step 2: Check Your Event Status")
    print("-" * 35)
    
    try:
        show_my_current_event_status()
    except Exception as e:
        print(f"❌ Error: {e}")
    
    # Step 3: View event leaderboard
    print("\n🏆 Step 3: View Event Leaderboard")
    print("-" * 35)
    
    try:
        show_current_event_leaderboard(top_count=15)
    except Exception as e:
        print(f"❌ Error: {e}")
    
    # Step 4: Analyze event statistics
    print("\n📈 Step 4: Analyze Event Statistics")
    print("-" * 40)
    
    try:
        analyze_current_event(sample_size=50)
    except Exception as e:
        print(f"❌ Error: {e}")
    
    # Step 5: Find event game
    print("\n🎮 Step 5: Find Event Game")
    print("-" * 30)
    
    try:
        matchmaking = MC5MatchmakingSystem()
        event_room = matchmaking.quick_play_any(
            score=1844,
            event_id="0c646c6a-e61c-11f0-be58-b8ca3a634708"
        )
        
        if event_room:
            print("✅ Found event game!")
            matchmaking.show_room_details(event_room)
            
            # Store room ID for later use
            room_id = event_room.get('id')
            print(f"\n💡 Room ID: {room_id}")
            print("🎮 You can use this room ID to get more information later")
        else:
            print("❌ No event game found")
            
    except Exception as e:
        print(f"❌ Error: {e}")
    
    # Step 6: Alternative game finding
    print("\n🔄 Step 6: Alternative Game Finding")
    print("-" * 40)
    
    try:
        print("🎯 Trying different game modes...")
        
        # Try team battle
        tb_room = quick_team_battle(score=1844)
        if tb_room:
            print("✅ Found Team Battle game!")
            print(f"🆔 Room ID: {tb_room.get('id')}")
            print(f"👥 Players: {tb_room.get('member_count')}/{tb_room.get('capacity')}")
        else:
            print("❌ No Team Battle game found")
        
        # Try regular battle
        battle_room = quick_battle(score=1844)
        if battle_room:
            print("✅ Found Battle game!")
            print(f"🆔 Room ID: {battle_room.get('id')}")
            print(f"👥 Players: {battle_room.get('member_count')}/{battle_room.get('capacity')}")
        else:
            print("❌ No Battle game found")
            
    except Exception as e:
        print(f"❌ Error: {e}")
    
    # Step 7: Check your rank context
    print("\n📊 Step 7: Check Your Rank Context")
    print("-" * 40)
    
    try:
        show_my_current_event_context(nearby_count=10)
    except Exception as e:
        print(f"❌ Error: {e}")
    
    # Step 8: Complete workflow summary
    print("\n🎯 Step 8: Complete Workflow Summary")
    print("-" * 45)
    
    print("✅ Event Registration: Register for current event")
    print("📊 Event Status: Check your current event status")
    print("🏆 Leaderboard: View event leaderboard and rankings")
    print("📈 Analysis: Analyze event statistics and trends")
    print("🎮 Matchmaking: Find event games and regular games")
    print("👥 Room Details: View room information and member list")
    print("📊 Rank Context: See your rank with nearby players")
    
    print("\n🎮 Quick Usage Examples:")
    print("-" * 30)
    print("📝 Register for event:")
    print("   register_current_event()")
    print()
    print("🏆 View leaderboard:")
    print("   show_current_event_leaderboard(top_count=10)")
    print()
    print("👤 Check your status:")
    print("   show_my_current_event_status()")
    print()
    print("🎮 Find event game:")
    print("   current_event_quick_play(score=1844)")
    print()
    print("⚔️ Find team battle:")
    print("   quick_team_battle(score=1844)")
    print()
    print("📊 Analyze event:")
    print("   analyze_current_event(sample_size=100)")
    
    print("\n🔧 Advanced Usage:")
    print("-" * 20)
    print("🎮 Event System:")
    print("   event_system = MC5EventSystem()")
    print("   event_system.register_for_event(event_id)")
    print("   event_system.show_event_leaderboard(event_id)")
    print()
    print("🎯 Matchmaking System:")
    print("   matchmaking = MC5MatchmakingSystem()")
    print("   matchmaking.quick_play_any(score, event_id)")
    print("   matchmaking.find_custom_games(game_mode, capacity)")
    print()
    print("🏆 Leaderboard System:")
    print("   leaderboard = MC5LeaderboardSystem()")
    print("   leaderboard.show_leaderboard(leaderboard_id)")
    print("   leaderboard.analyze_leaderboard(leaderboard_id)")
    
    print("\n🎉 Complete Event & Matchmaking Example Completed!")
    print("💡 This demonstrates the full workflow for MC5 events!")
    print("🎮 Register for events, view leaderboards, find games, and track your progress!")
    print("🏆 Compete with other players and climb the event rankings!")

if __name__ == "__main__":
    main()
