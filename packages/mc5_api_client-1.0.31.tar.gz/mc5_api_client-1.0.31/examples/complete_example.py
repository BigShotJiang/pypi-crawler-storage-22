#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : complete_example.py
# | License  : MIT License © 2026 Chizoba
# | Brief    : Complete MC5 example - all features in one script
# ────────────────★─────────────────────────────────

"""
MC5 API Client - Complete Example

This example demonstrates all major features of the MC5 API Client.
From basic chat to advanced customization and impersonation!

Features shown:
- Basic chat and multi-language support
- Inbox API for message checking
- Impersonation and custom players
- Complete customization system
- Configuration chaining
- All in one comprehensive example
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'src'))

from mc5_api_client import (
    # Basic chat
    send, en, fr, de, es, it, pt, ru, ja, ko, zh, hello, goodbye, test, ping, thanks,
    # Inbox
    check_inbox, my_messages,
    # Impersonation
    impersonate, become_player, anonymous_spy,
    # Customization
    set_nickname, set_killsign, set_killsign_color, set_country,
    color_red, color_green, color_blue, color_yellow, color_purple, color_orange,
    country_en, country_fr, country_de, country_es, country_it, country_pt, country_ru, country_ja, country_ko, country_zh,
    with_name, with_killsign, with_country, configure,
    # Testing
    test_connection
)

def demonstrate_basic_chat():
    """Demonstrate basic chat functionality."""
    print("\n" + "="*50)
    print("📤 BASIC CHAT DEMONSTRATION")
    print("="*50)
    
    # Send basic messages
    print("\n🎮 Sending basic messages...")
    send("Hello from complete example!")
    en("Hello from English!")
    fr("Bonjour du français!")
    de("Hallo von Deutsch!")
    
    # One-liner functions
    print("\n⚡ One-liner functions...")
    hello()
    goodbye()
    test()
    ping()
    thanks()
    
    print("✅ Basic chat demonstration completed!")

def demonstrate_inbox_api():
    """Demonstrate inbox API functionality."""
    print("\n" + "="*50)
    print("📧 INBOX API DEMONSTRATION")
    print("="*50)
    
    # Send some test messages first
    print("\n📤 Sending test messages for inbox...")
    send("Test message for inbox!")
    en("Test message for inbox from English!")
    fr("Message de test pour boîte de réception!")
    
    # Check inbox
    print("\n📧 Checking inbox...")
    messages = check_inbox(5)
    if messages:
        print(f"✅ Found {len(messages)} messages in inbox")
        for i, msg in enumerate(messages[:3]):
            print(f"   {i+1}. {msg.get('body', 'N/A')[:40]}...")
    else:
        print("❌ No messages found")
    
    # Simple format
    print("\n📋 Simple format...")
    count = 0
    for sender, body, time in my_messages():
        if count < 3:
            print(f"   📨 From {sender}: {body[:30]}...")
        count += 1
    
    print(f"✅ Retrieved {count} messages in simple format")
    print("✅ Inbox API demonstration completed!")

def demonstrate_impersonation():
    """Demonstrate impersonation functionality."""
    print("\n" + "="*50)
    print("🎭 IMPERSONATION DEMONSTRATION")
    print("="*50)
    
    # Basic impersonation
    print("\n🎭 Basic impersonation...")
    impersonate("TestPlayer", "This is a test impersonation!")
    impersonate("EliteWarrior", "Elite warrior here!")
    impersonate("CasualGamer", "Just having fun!")
    
    # Custom player
    print("\n👤 Custom player creation...")
    custom_player = become_player("CustomPlayer", "FF0000")
    if custom_player:
        custom_player.msg("Custom player message!")
    
    # Anonymous spy
    print("\n🕵️ Anonymous spy mode...")
    spy = anonymous_spy()
    if spy:
        spy.msg("Secret message from spy!")
    
    print("✅ Impersonation demonstration completed!")

def demonstrate_customization():
    """Demonstrate customization functionality."""
    print("\n" + "="*50)
    print("🎨 CUSTOMIZATION DEMONSTRATION")
    print("="*50)
    
    # Basic customization
    print("\n🎨 Basic customization...")
    set_nickname("CustomPlayer").msg("Custom nickname!")
    set_killsign("default_killsig_80", "FF0000").msg("Red signature!")
    set_country("es").msg("Spanish message!", lang="es")
    
    # Color presets
    print("\n🌈 Color presets...")
    color_red().msg("Red color!")
    color_blue().msg("Blue color!")
    color_green().msg("Green color!")
    
    # Country selection
    print("\n🌍 Country selection...")
    country_ja().msg("Japanese message!", lang="ja")
    country_ru().msg("Russian message!", lang="ru")
    country_pt().msg("Portuguese message!", lang="pt")
    
    # Configuration chaining
    print("\n⛓️ Configuration chaining...")
    with_name("ChainedPlayer").msg("Chained name!")
    with_killsign("default_killsig_02", "00FF00").msg("Chained killsign!")
    with_country("fr").msg("Chained country!", lang="fr")
    
    print("✅ Customization demonstration completed!")

def demonstrate_advanced_features():
    """Demonstrate advanced features."""
    print("\n" + "="*50)
    print("🎯 ADVANCED FEATURES DEMONSTRATION")
    print("="*50)
    
    # Multi-language player
    print("\n🌐 Multi-language player...")
    player = set_nickname("MultiLingual")
    if player:
        country_en().msg("Hello from English!")
        country_fr().msg("Bonjour du français!")
        country_de().msg("Hallo von Deutsch!")
    
    # Color-changing player
    print("\n🎨 Color-changing player...")
    player = set_nickname("ColorChanger")
    if player:
        color_red().msg("Red message!")
        color_blue().msg("Blue message!")
        color_purple().msg("Purple message!")
    
    # Complex chaining
    print("\n⛓️ Complex chaining...")
    chat = with_name("AdvancedPlayer")
    chat = with_killsign("default_killsig_90", "FF00FF")
    chat = with_country("ja")
    chat.msg("Advanced chained message!", lang="ja")
    
    print("✅ Advanced features demonstration completed!")

def main():
    """Main function demonstrating all features."""
    print("🎮 MC5 API Client - Complete Example")
    print("=" * 50)
    print("This example demonstrates ALL major features!")
    
    # Test connection first
    print("\n🔗 Testing connection...")
    if test_connection():
        print("✅ Connection successful!")
    else:
        print("❌ Connection failed!")
        return
    
    # Run all demonstrations
    demonstrate_basic_chat()
    demonstrate_inbox_api()
    demonstrate_impersonation()
    demonstrate_customization()
    demonstrate_advanced_features()
    
    print("\n" + "="*50)
    print("🎉 COMPLETE EXAMPLE FINISHED!")
    print("="*50)
    print("✅ All features demonstrated successfully!")
    print("💡 Check out the individual examples for more details!")
    print("🎮 You now have access to the complete MC5 API Client!")

if __name__ == "__main__":
    main()
