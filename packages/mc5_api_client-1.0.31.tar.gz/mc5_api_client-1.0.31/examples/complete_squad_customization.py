#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : complete_squad_customization.py
# | License  | MIT License © 2026 Chizoba
# | Brief    | Complete squad customization examples
# ────────────────★─────────────────────────────────

"""
Complete Squad Customization Examples for MC5 API Client

This example demonstrates how to customize every aspect of your squad
using the automatic squad management feature.

FEATURES:
✅ Complete squad customization
✅ XP level calculation (Level 1-10)
✅ Color customization (RGB values)
✅ All squad parameters modifiable
✅ Easy-to-use helper functions
✅ Validation and error handling
"""

import os
from mc5_api_client import MC5Client

def calculate_xp_for_level(level):
    """
    Calculate XP required for a specific level.
    
    Level System:
    - Level 1: 1000 XP
    - Level 2: 2000 XP
    - ...
    - Level 10: 10000 XP (maximum)
    
    Args:
        level (int): Desired level (1-10)
        
    Returns:
        int: XP value for the level
    """
    if level < 1:
        level = 1
    elif level > 10:
        level = 10
    
    return level * 1000

def get_color_value(color_name):
    """
    Get color value for common colors.
    
    Args:
        color_name (str): Name of the color
        
    Returns:
        str: Color value in decimal format
    """
    colors = {
        'black': '0',
        'white': '16777215',
        'red': '16711680',
        'green': '65280',
        'blue': '255',
        'yellow': '16776960',
        'purple': '16711808',
        'orange': '16753920',
        'pink': '16761035',
        'cyan': '65535',
        'lime': '65280',
        'navy': '128',
        'gold': '16766720',
        'silver': '12632256',
        'maroon': '8388608',
        'teal': '32768',
        'olive': '8421376'
    }
    
    return colors.get(color_name.lower(), '0')

def customize_squad_completely():
    """
    Demonstrate complete squad customization.
    """
    print("🎮 MC5 API Client - Complete Squad Customization")
    print("=" * 60)
    print("🚀 Customize every aspect of your squad automatically!")
    print()
    
    try:
        # Initialize client
        client = MC5Client(
            client_id="1875:55979:6.0.0a:windows:windows",
            username="anonymous:d2luOF92M18xNzcwMDUxNjkwXy7H33aeTVB4YZictyDq48c=",
            password="sSJKzhQ5l4vrFgov"
        )
        
        print("✅ Client initialized successfully!")
        
        # Get current squad info
        print("\n📊 Getting current squad information...")
        squad_id = client.get_my_squad_id()
        if not squad_id:
            print("❌ No squad found!")
            return
        
        print(f"✅ Squad ID: {squad_id}")
        
        # Example 1: Basic customization
        print("\n🎨 Example 1: Basic Squad Customization")
        print("-" * 45)
        
        basic_updates = {
            "name": "Elite Warriors",
            "description": "Best squad in MC5! Join us for victories!",
            "rating": 5000,
            "member_limit": 50,
            "membership": "owner_approved",
            "_min_join_value": 1000
        }
        
        print("📝 Basic updates:")
        for key, value in basic_updates.items():
            print(f"   {key}: {value}")
        
        # Example 2: Advanced customization with colors
        print("\n🎨 Example 2: Advanced Customization with Colors")
        print("-" * 50)
        
        advanced_updates = {
            "name": "452e55e84897+",
            "description": "Professional squad with active members!",
            "rating": 3573,
            "score": 5200,
            "member_limit": 300,
            "membership": "owner_approved",
            "_logo": "1",
            "_logo_clr_prim": get_color_value("red"),     # Red primary color
            "_logo_clr_sec": get_color_value("white"),    # White secondary color
            "_min_join_value": 996699,
            "currency": 10000,
            "active_clan_label": "true",
            "active_clan_threshold": 50
        }
        
        print("📝 Advanced updates:")
        for key, value in advanced_updates.items():
            print(f"   {key}: {value}")
        
        # Example 3: Level-based customization
        print("\n🎯 Example 3: Level-Based Customization")
        print("-" * 40)
        
        target_level = 8
        level_updates = {
            "name": f"Level {target_level} Squad",
            "description": f"Elite squad at Level {target_level}!",
            "_xp": calculate_xp_for_level(target_level),
            "rating": target_level * 500,
            "_min_join_value": target_level * 100,
            "member_limit": 20 + (target_level * 5)
        }
        
        print(f"📝 Level {target_level} updates:")
        for key, value in level_updates.items():
            print(f"   {key}: {value}")
        
        # Example 4: Color themes
        print("\n🌈 Example 4: Color Themes")
        print("-" * 30)
        
        themes = {
            "Dark Theme": {
                "_logo_clr_prim": get_color_value("black"),
                "_logo_clr_sec": get_color_value("white"),
                "name": "Dark Knights"
            },
            "Fire Theme": {
                "_logo_clr_prim": get_color_value("red"),
                "_logo_clr_sec": get_color_value("orange"),
                "name": "Fire Warriors"
            },
            "Ice Theme": {
                "_logo_clr_prim": get_color_value("blue"),
                "_logo_clr_sec": get_color_value("cyan"),
                "name": "Ice Legion"
            },
            "Nature Theme": {
                "_logo_clr_prim": get_color_value("green"),
                "_logo_clr_sec": get_color_value("lime"),
                "name": "Nature Guardians"
            }
        }
        
        print("📝 Available themes:")
        for theme_name, theme_data in themes.items():
            print(f"   {theme_name}:")
            for key, value in theme_data.items():
                print(f"      {key}: {value}")
        
        # Example 5: Complete customization function
        print("\n🔧 Example 5: Complete Customization Function")
        print("-" * 45)
        
        def customize_squad(client, **kwargs):
            """
            Customize squad with any parameters.
            
            Args:
                client: MC5Client instance
                **kwargs: Any squad parameters to update
                
            Available parameters:
            - name: Squad name
            - description: Squad description
            - rating: Squad rating
            - score: Squad score
            - member_limit: Maximum members
            - membership: Membership type
            - _logo: Logo ID
            - _logo_clr_prim: Primary color (RGB decimal)
            - _logo_clr_sec: Secondary color (RGB decimal)
            - _min_join_value: Minimum join value
            - _xp: Squad XP (determines level)
            - _killsig_id: Kill signature ID
            - currency: Squad currency
            - active_clan_label: Active clan label
            - active_clan_threshold: Active clan threshold
            """
            try:
                result = client.update_my_squad_info(**kwargs)
                if result and 'error' not in result:
                    print("✅ Squad customized successfully!")
                    return result
                else:
                    print(f"❌ Customization failed: {result}")
                    return None
            except Exception as e:
                print(f"❌ Error customizing squad: {e}")
                return None
        
        # Demonstrate the function
        print("📝 Using customize_squad() function:")
        
        # Example: Apply Fire Theme
        fire_theme_result = customize_squad(client, **themes["Fire Theme"])
        if fire_theme_result:
            print("🔥 Fire theme applied successfully!")
        
        # Example: Set to Level 5
        level_5_result = customize_squad(
            client,
            name="Level 5 Elite",
            _xp=calculate_xp_for_level(5),
            rating=2500,
            member_limit=45
        )
        if level_5_result:
            print("⭐ Level 5 configuration applied!")
        
        # Example 6: Validation helper
        print("\n✅ Example 6: Validation Helper")
        print("-" * 30)
        
        def validate_squad_data(data):
            """
            Validate squad customization data.
            
            Args:
                data (dict): Squad data to validate
                
            Returns:
                tuple: (is_valid, errors)
            """
            errors = []
            
            # Validate XP/Level
            if '_xp' in data:
                xp = int(data['_xp'])
                if xp < 1000 or xp > 10000:
                    errors.append(f"XP must be between 1000 (Level 1) and 10000 (Level 10)")
            
            # Validate member limit
            if 'member_limit' in data:
                limit = int(data['member_limit'])
                if limit < 1 or limit > 300:
                    errors.append("Member limit must be between 1 and 300")
            
            # Validate colors
            for color_key in ['_logo_clr_prim', '_logo_clr_sec']:
                if color_key in data:
                    try:
                        color = int(data[color_key])
                        if color < 0 or color > 16777215:  # RGB max value
                            errors.append(f"{color_key} must be between 0 and 16777215")
                    except ValueError:
                        errors.append(f"{color_key} must be a valid number")
            
            # Validate rating
            if 'rating' in data:
                rating = int(data['rating'])
                if rating < 0 or rating > 99999:
                    errors.append("Rating must be between 0 and 99999")
            
            return len(errors) == 0, errors
        
        # Test validation
        test_data = {
            "name": "Test Squad",
            "_xp": 5000,  # Valid (Level 5)
            "member_limit": 50,  # Valid
            "_logo_clr_prim": "255",  # Valid (blue)
            "rating": 3000  # Valid
        }
        
        is_valid, errors = validate_squad_data(test_data)
        if is_valid:
            print("✅ Test data is valid!")
        else:
            print("❌ Test data has errors:")
            for error in errors:
                print(f"   - {error}")
        
        print("\n" + "=" * 60)
        print("🎉 Complete Squad Customization Demo Complete!")
        print("=" * 60)
        print()
        print("💡 What you learned:")
        print("   ✅ Basic squad customization")
        print("   ✅ Advanced customization with colors")
        print("   ✅ Level-based customization (1-10)")
        print("   ✅ Color themes (black, white, red, green, blue, etc.)")
        print("   ✅ Complete customization function")
        print("   ✅ Data validation")
        print()
        print("🚀 Use these examples to customize your squad perfectly!")
        print("🎮 All changes are applied automatically - no manual IDs needed!")
        
    except Exception as e:
        print(f"❌ Demo failed: {e}")

def show_quick_reference():
    """Show quick reference for common customizations."""
    print("\n📚 Quick Reference Guide")
    print("=" * 30)
    
    print("🎯 Common Customizations:")
    print()
    
    print("📝 Basic Info:")
    print("   name: 'Your Squad Name'")
    print("   description: 'Your squad description'")
    print("   rating: 5000")
    print()
    
    print("👥 Member Settings:")
    print("   member_limit: 50")
    print("   membership: 'owner_approved' or 'open'")
    print("   _min_join_value: 1000")
    print()
    
    print("⭐ Level & XP:")
    print("   _xp: 5000  # Level 5")
    print("   # Level 1: 1000, Level 10: 10000")
    print()
    
    print("🎨 Colors (RGB decimal):")
    print("   _logo_clr_prim: '255'      # Blue")
    print("   _logo_clr_sec: '16777215'  # White")
    print("   _logo_clr_prim: '0'        # Black")
    print("   _logo_clr_sec: '16711680'  # Red")
    print()
    
    print("💰 Economy:")
    print("   currency: '10000'")
    print("   score: '5200'")
    print()
    
    print("🏷️ Identity:")
    print("   _logo: '1'")
    print("   _killsig_id: 'default_killsig_01'")
    print()
    
    print("🏃 Activity:")
    print("   active_clan_label: 'true'")
    print("   active_clan_threshold: '50'")

def main():
    """Run the complete squad customization demo."""
    print("🎮 MC5 API Client - Complete Squad Customization")
    print("=" * 60)
    print("🚀 Learn to customize every aspect of your squad!")
    print()
    
    customize_squad_completely()
    show_quick_reference()

if __name__ == "__main__":
    main()
