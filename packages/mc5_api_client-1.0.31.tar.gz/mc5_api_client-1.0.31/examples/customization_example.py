#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : customization_example.py
# | License  : MIT License  2026 Chizoba
# | Brief    : MC5 customization example - full player customization
# ────────────────★─────────────────────────────────

"""
MC5 API Client - Customization Example

This example demonstrates the comprehensive customization functionality.
Customize your nickname, killsign, colors, and country!

Features shown:
- Basic customization (nickname, killsign, country)
- Color presets
- Country selection
- Configuration chaining
- Complete player setup
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'src'))

from mc5_api_client import (
    set_nickname, set_killsign, set_killsign_color, set_country,
    color_red, color_green, color_blue, color_yellow, color_purple, color_orange,
    country_en, country_fr, country_de, country_es, country_it, country_pt, country_ru, country_ja, country_ko, country_zh,
    with_name, with_killsign, with_country, configure, test_connection
)

def main():
    print("🎮 MC5 API Client - Customization Example")
    print("=" * 50)
    
    # Test connection first
    print("\n🔗 Testing connection...")
    if test_connection():
        print("✅ Connection successful!")
    else:
        print("❌ Connection failed!")
        return
    
    # Basic customization
    print("\n🎨 Basic Customization...")
    
    # Set nickname
    chat = set_nickname("CustomTestPlayer")
    if chat:
        print("✅ Set nickname to 'CustomTestPlayer'")
        result = chat.msg("Message with custom nickname!")
        print(f"✅ Custom nickname message sent: {result}")
    else:
        print("❌ Failed to set nickname")
    
    # Set killsign with color
    chat = set_killsign("default_killsig_80", "FF0000")
    if chat:
        print("✅ Set killsign to 'default_killsig_80' with red color")
        result = chat.msg("Message with custom killsign!")
        print(f"✅ Custom killsign message sent: {result}")
    else:
        print("❌ Failed to set killsign")
    
    # Set country/language
    chat = set_country("es")
    if chat:
        print("✅ Set country to Spanish")
        result = chat.msg("Spanish message!", lang="es")
        print(f"✅ Spanish message sent: {result}")
    else:
        print("❌ Failed to set country")
    
    # Color presets
    print("\n🌈 Color Presets...")
    
    colors = [
        ("color_red", color_red, "Red color message!"),
        ("color_green", color_green, "Green color message!"),
        ("color_blue", color_blue, "Blue color message!"),
        ("color_yellow", color_yellow, "Yellow color message!"),
        ("color_purple", color_purple, "Purple color message!"),
        ("color_orange", color_orange, "Orange color message!")
    ]
    
    for name, func, message in colors:
        chat = func()
        if chat:
            print(f"✅ Applied {name}")
            result = chat.msg(message)
            print(f"✅ {name} message sent: {result}")
        else:
            print(f"❌ Failed to apply {name}")
    
    # Country selection
    print("\n🌍 Country Selection...")
    
    countries = [
        ("country_ja", country_ja, "Japanese test!", "ja"),
        ("country_ru", country_ru, "Russian test!", "ru"),
        ("country_pt", country_pt, "Portuguese test!", "pt"),
        ("country_it", country_it, "Italian test!", "it"),
        ("country_de", country_de, "German test!", "de")
    ]
    
    for name, func, message, lang in countries:
        chat = func()
        if chat:
            print(f"✅ Set country to {lang.upper()}")
            result = chat.msg(message, lang=lang)
            print(f"✅ {lang.upper()} message sent: {result}")
        else:
            print(f"❌ Failed to set country to {lang.upper()}")
    
    # Configuration chaining
    print("\n⛓️ Configuration Chaining...")
    
    # Chain multiple customizations
    chat = with_name("ChainedPlayer")
    if chat:
        print("✅ Set name via chaining")
        result = chat.msg("Chained name test!")
        print(f"✅ Chained name message sent: {result}")
    else:
        print("❌ Failed to chain name")
    
    chat = with_killsign("default_killsig_02", "00FF00")
    if chat:
        print("✅ Set killsign via chaining")
        result = chat.msg("Chained killsign test!")
        print(f"✅ Chained killsign message sent: {result}")
    else:
        print("❌ Failed to chain killsign")
    
    chat = with_country("fr")
    if chat:
        print("✅ Set country via chaining")
        result = chat.msg("Chained country test!", lang="fr")
        print(f"✅ Chained country message sent: {result}")
    else:
        print("❌ Failed to chain country")
    
    # Advanced customization examples
    print("\n🎯 Advanced Customization Examples...")
    
    # Multi-language player
    print("🌐 Multi-language player...")
    chat = set_nickname("MultiLingual")
    if chat:
        country_en().msg("Hello from English!")
        country_fr().msg("Bonjour du français!")
        country_de().msg("Hallo von Deutsch!")
        print("✅ Multi-language messages sent")
    
    # Color-changing player
    print("🎨 Color-changing player...")
    chat = set_nickname("ColorChanger")
    if chat:
        color_red().msg("Red message!")
        color_blue().msg("Blue message!")
        color_green().msg("Green message!")
        print("✅ Color-changing messages sent")
    
    print("\n🎉 Customization example completed!")
    print("💡 Try different combinations of names, colors, and countries!")
    print("🎨 You can create unlimited custom player profiles!")

if __name__ == "__main__":
    main()
