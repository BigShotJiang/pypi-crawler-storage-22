#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : device_id_example.py
# | License  | MIT License © 2026 Chizoba
# | Brief    | Example of global ID functions
# ────────────────★─────────────────────────────────

"""
Device ID Management Example
========================

This example demonstrates how to use the new global ID functions in MC5Easy.
Shows how to get global IDs, device information, and generate device IDs.

Setup:
1. Set your MC5 credentials as environment variables:
   export MC5_USERNAME="your_credential"
   export MC5_PASSWORD="your_password"

2. Or edit the credentials directly in the script

3. Run the example:
   python device_id_example.py
"""

import os
from mc5_api_client import MC5Easy, get_global_id, get_device_info, generate_device_id

def main():
    """Demonstrate global ID functions."""
    print("🌐 MC5 Device ID Management Example")
    print("=" * 40)
    
    # Method 1: Use environment variables (recommended)
    username = os.getenv('MC5_USERNAME') or "YOUR_MC5_CREDENTIAL"
    password = os.getenv('MC5_PASSWORD') or "YOUR_MC5_PASSWORD"
    
    if username == "YOUR_MC5_CREDENTIAL" or password == "YOUR_MC5_PASSWORD":
        print("⚠️ Please set your MC5 credentials:")
        print("   Option 1: Set environment variables MC5_USERNAME and MC5_PASSWORD")
        print("   Option 2: Edit the username and password variables in this script")
        print()
        print("   Example:")
        print("   export MC5_USERNAME='anonymous:your_credential_here'")
        print("   export MC5_PASSWORD='your_password_here'")
        return
    
    print(f"🔑 Using credentials: {username[:30]}...")
    print()
    
    # === Method 1: Get Global ID ===
    print("🌐 Method 1: Get Global ID")
    print("-" * 30)
    
    try:
        with MC5Easy(username, password) as mc5:
            # Get global ID with default parameters
            global_id = mc5.get_global_id()
            print(f"✅ Global ID: {global_id}")
            
            # Get global ID with custom parameters
            custom_id = mc5.get_global_id(
                device_id="custom_device_123",
                device_type="w10",
                hdidfv="custom_hdidfv_123"
            )
            print(f"✅ Custom Global ID: {custom_id}")
            
            # Get global ID for Android
            android_id = mc5.get_global_id(
                device_type="android",
                device_id="android_device_123"
            )
            print(f"✅ Android Global ID: {android_id}")
            
    except Exception as e:
        print(f"❌ Error getting global ID: {e}")
    
    print()
    
    # === Method 2: Get Device Information ===
    print("📱 Method 2: Get Device Information")
    print("-" * 35)
    
    try:
        with MC5Easy(username, password) as mc5:
            device_info = mc5.get_device_info()
            print("✅ Device Information:")
            
            for key, value in device_info.items():
                print(f"   {key}: {value}")
            
    except Exception as e:
        print(f"❌ Error getting device info: {e}")
    
    print()
    
    # === Method 3: Generate Device ID ===
    print("🔧 Method 3: Generate Device ID")
    print("-" * 35)
    
    try:
        with MC5Easy(username, password) as mc5:
            # Generate a unique device ID
            generated_id = mc5.generate_device_id()
            print(f"✅ Generated Device ID: {generated_id}")
            
            # Generate another one
            generated_id_2 = mc5.generate_device_id()
            print(f"✅ Generated Device ID 2: {generated_id_2}")
            
    except Exception as e:
        print(f"❌ Error generating device ID: {e}")
    
    print()
    
    # === Method 4: Standalone Functions ===
    print("🔧 Method 4: Standalone Functions")
    print("-" * 35)
    
    try:
        # These work without MC5Easy if environment variables are set
        print("🔍 Getting global ID (standalone)...")
        standalone_id = get_global_id()
        print(f"✅ Standalone Global ID: {standalone_id}")
        
        print("📋 Getting device info (standalone)...")
        standalone_info = get_device_info()
        print(f"✅ Standalone Device Info: {standalone_info}")
        
        print("🔧 Generating device ID (standalone)...")
        standalone_generated = generate_device_id()
        print(f"✅ Standalone Generated ID: {standalone_generated}")
        
    except Exception as e:
        print(f"❌ Error with standalone functions: {e}")
    
    print()
    print("🎉 Device ID management completed!")
    print("💡 Tips:")
    print("   - Use MC5Easy for automatic connection management")
    print("   - Global IDs are persistent across sessions")
    print("   - Device IDs help with device tracking")
    print("   - Generated IDs are unique and secure")
    
    print()
    print("🔗 Global ID Information:")
    print("   - Endpoint: https://gdid.datalake.gameloft.com/assign_global_id/")
    print("   - Purpose: Assigns global device IDs for MC5")
    print("   - Platform: Works with PC, Android, iOS")
    print("   - Format: 19-digit numeric string")

def demo_device_id_comparison():
    """Demonstrate device ID comparison and tracking."""
    print("\n🔍 Device ID Comparison Demo")
    print("=" * 40)
    
    username = os.getenv('MC5_USERNAME') or "YOUR_MC5_CREDENTIAL"
    password = os.getenv('MC5_PASSWORD') or "YOUR_MC5_PASSWORD"
    
    if username == "YOUR_MC5_CREDENTIAL" or password == "YOUR_MC5_PASSWORD":
        print("⚠️ Please set your MC5 credentials to test device ID comparison")
        return
    
    try:
        with MC5Easy(username, password) as mc5:
            print("🔍 Comparing Device IDs...")
            
            # Get multiple global IDs
            id1 = mc5.get_global_id()
            id2 = mc5.get_global_id(device_id="test_id_1")
            id3 = mc5.get_global_id(device_id="test_id_2")
            
            print(f"   ID 1: {id1}")
            print(f"   ID 2: {id2}")
            print(f"   ID 3: {id3}")
            
            # Check if they're the same
            if id1 == id2 == id3:
                print("✅ All global IDs are the same!")
            else:
                print("⚠️ Global IDs differ - device-specific IDs")
            
            # Get device info for each
            info1 = mc5.get_device_info()
            info2 = mc5.get_device_info()
            info3 = mc5.get_device_info()
            
            print(f"   Info 1: {info1.get('profile_name', 'Unknown')} (Clan: {info1.get('has_clan', False)})")
            print(f"   Info 2: {info2.get('profile_name', 'Unknown')} (Clan: {info2.get('has_clan', False)})")
            print(f"   Info 3: {info3.get('profile_name', 'Unknown')} (Clan: {info3.get('has_clan', False)})")
            
    except Exception as e:
        print(f"❌ Error in device ID comparison: {e}")

if __name__ == "__main__":
    main()
    demo_device_id_comparison()
