#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : easy_chat.py
# | License  : MIT License © 2026 Chizoba
# | Brief    : Ultra-simple MC5 chat with spamming and all languages
# ────────────────★─────────────────────────────────

"""
Ultra-simple MC5 Chat Module

Less code, more features! Send spam, all languages, easy to use.
"""

import sys
import os
import time
import requests
import threading
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from mc5_api_client.auth import TokenGenerator

class Chat:
    """Ultra-simple MC5 chat client."""
    
    def __init__(self, user="anonymous:d2luOF92M18xNzcwMDUxNjkwXy7H33aeTVB4YZictyDq48c=", passw="sSJKzhQ5l4vrFgov"):
        self.user = user
        self.passw = passw
        self.token = None
        self.member_id = None
        self.name = "Player"
        self.killsig = "default_killsig_80"
        self.color = "12722475"
        self.lang = "en"
        
    def _get_token(self):
        """Get chat token."""
        try:
            tg = TokenGenerator()
            tg.client_id = "1875:55979:6.0.0a:windows:windows"
            r = tg.generate_token(self.user, self.passw, "alert auth chat leaderboard_ro lobby message session social")
            if r.get('access_token'):
                self.token = r.get('access_token')
                self.member_id = r.get('token_id')
                return True
        except: pass
        return False
    
    def _get_server(self):
        """Get chat server."""
        if not self._get_token(): return None
        try:
            d = {'access_token': self.token, 'language': self.lang}
            r = requests.post("https://eur-arion.gameloft.com/chat/channels/mc5_global/subscribe", data=d, 
                           headers={'User-Agent': 'ChatLibv2', 'Content-Type': 'application/x-www-form-urlencoded'}, timeout=10)
            if r.status_code == 200:
                return r.json().get('cmd_url')
        except: pass
        return None
    
    def nickname(self, nickname):
        """Set nickname."""
        self.name = nickname
        return self
        
    def set_killsig(self, sig, color="12722475"):
        """Set kill signature."""
        self.killsig = sig
        self.color = color
        return self
        
    def language(self, lang):
        """Set language."""
        self.lang = lang
        return self
        
    def msg(self, text, name=None, lang=None):
        """Send single message."""
        server = self._get_server()
        if not server: 
            print("❌ Failed to get server")
            return False
        
        name = name or self.name
        lang = lang or self.lang
        
        data = {
            'access_token': self.token,
            '_anonId': self.user,
            'user': f'{{"nickname":"{name}"}}',
            'msg': text,
            '_fedId': f'fed_id:{self.member_id}',
            '_killSign': self.killsig,
            '_killSignColor': self.color,
            '_senderName': name
        }
        
        try:
            r = requests.post(server, data=data, headers={'User-Agent': 'ChatLibv2'}, timeout=10)
            if r.status_code == 200:
                msg_id = r.json().get('msg', {}).get('id')
                print(f"✅ Sent to {lang.upper()}: {text} (ID: {msg_id})")
                return True
            else:
                print(f"❌ Failed: {r.status_code}")
                return False
        except Exception as e:
            print(f"❌ Error: {e}")
            return False
    
    def spam(self, text, count=5, delay=1, name=None, lang=None):
        """Send multiple messages (spam)."""
        name = name or self.name
        lang = lang or self.lang
        print(f"🚀 Spamming {count} messages to {lang.upper()}...")
        
        for i in range(count):
            self.msg(f"{text} [{i+1}/{count}]", name, lang)
            if i < count - 1:
                time.sleep(delay)
        
        print(f"✅ Spam complete: {count} messages sent")
    
    def listen(self, duration=30, callback=None):
        """Listen to chat."""
        if not self._get_token():
            print("❌ Failed to get token")
            return
        
        try:
            d = {'access_token': self.token, 'language': self.lang}
            r = requests.post("https://eur-arion.gameloft.com/chat/channels/mc5_global/subscribe", data=d,
                           headers={'User-Agent': 'ChatLibv2'}, timeout=10)
            if r.status_code == 200:
                url = r.json().get('listen_url')
                print(f"🎧 Listening to {self.lang.upper()} for {duration}s...")
                
                def _listen():
                    try:
                        resp = requests.get(url, stream=True, timeout=30)
                        start = time.time()
                        for line in resp.iter_lines(decode_unicode=True):
                            if line and time.time() - start < duration:
                                try:
                                    import json
                                    data = json.loads(line)
                                    if data.get('type') == 'message':
                                        sender = data.get('_senderName', 'Unknown')
                                        msg = data.get('msg', '')
                                        if callback:
                                            callback(sender, msg)
                                        else:
                                            print(f"💬 {sender}: {msg}")
                                    elif data.get('type') == 'room_info':
                                        print(f"🏠 {data.get('num_members', 0)} online")
                                except: continue
                            else: break
                        print("✅ Stopped listening")
                    except Exception as e:
                        print(f"❌ Listen error: {e}")
                
                threading.Thread(target=_listen, daemon=True).start()
                time.sleep(duration)
            else:
                print(f"❌ Failed: {r.status_code}")
        except Exception as e:
            print(f"❌ Error: {e}")

# Super simple functions
def send(text, name="Player", lang="en"):
    """Quick send message."""
    Chat().nickname(name).language(lang).msg(text)

def spam(text, count=5, delay=1, name="Player", lang="en"):
    """Quick spam messages."""
    Chat().nickname(name).spam(text, count, delay, lang=lang)

def listen(duration=30, lang="en"):
    """Quick listen to chat."""
    Chat().language(lang).listen(duration)

# Language shortcuts
def en(text, name="Player"): send(text, name, "en")
def fr(text, name="Player"): send(text, name, "fr")
def de(text, name="Player"): send(text, name, "de")
def es(text, name="Player"): send(text, name, "es")
def it(text, name="Player"): send(text, name, "it")
def ar(text, name="Player"): send(text, name, "ar")
def ru(text, name="Player"): send(text, name, "ru")
def tr(text, name="Player"): send(text, name, "tr")
def pt(text, name="Player"): send(text, name, "pt")
def id(text, name="Player"): send(text, name, "id")
def ko(text, name="Player"): send(text, name, "ko")

# Spam shortcuts
def spam_en(text, count=5): spam(text, count, lang="en")
def spam_fr(text, count=5): spam(text, count, lang="fr")
def spam_de(text, count=5): spam(text, count, lang="de")
def spam_es(text, count=5): spam(text, count, lang="es")
def spam_it(text, count=5): spam(text, count, lang="it")
def spam_ar(text, count=5): spam(text, count, lang="ar")
def spam_ru(text, count=5): spam(text, count, lang="ru")
def spam_tr(text, count=5): spam(text, count, lang="tr")
def spam_pt(text, count=5): spam(text, count, lang="pt")
def spam_id(text, count=5): spam(text, count, lang="id")
def spam_ko(text, count=5): spam(text, count, lang="ko")

# Listen shortcuts
def listen_en(duration=30): listen(duration, "en")
def listen_fr(duration=30): listen(duration, "fr")
def listen_de(duration=30): listen(duration, "de")
def listen_es(duration=30): listen(duration, "es")
def listen_it(duration=30): listen(duration, "it")
def listen_ar(duration=30): listen(duration, "ar")
def listen_ru(duration=30): listen(duration, "ru")
def listen_tr(duration=30): listen(duration, "tr")
def listen_pt(duration=30): listen(duration, "pt")
def listen_id(duration=30): listen(duration, "id")
def listen_ko(duration=30): listen(duration, "ko")

# Profile presets
def pro(): 
    c = Chat()
    c.nickname("ProPlayer")
    c.set_killsig("pro_killsig", "FF0000")
    return c

def casual(): 
    c = Chat()
    c.nickname("CasualGamer")
    c.set_killsig("casual_killsig", "00FF00")
    return c

def squad(): 
    c = Chat()
    c.nickname("SquadMember")
    c.set_killsig("squad_killsig", "0000FF")
    return c

# Demo
if __name__ == "__main__":
    print("🎮 Ultra-Simple MC5 Chat")
    print("1. Send message")
    print("2. Spam messages")
    print("3. Listen to chat")
    print("4. Multi-language demo")
    
    choice = input("Choose (1-4): ").strip()
    
    if choice == "1":
        text = input("Message: ")
        name = input("Name (Player): ") or "Player"
        lang = input("Lang (en): ") or "en"
        send(text, name, lang)
        
    elif choice == "2":
        text = input("Message: ")
        count = int(input("Count (5): ") or "5")
        spam(text, count)
        
    elif choice == "3":
        duration = int(input("Duration (30): ") or "30")
        listen(duration)
        
    elif choice == "4":
        print("🌍 Multi-language demo...")
        en("Hello from English!")
        fr("Bonjour du français!")
        de("Hallo von Deutsch!")
        es("¡Hola de español!")
        it("Ciao dall'Italia!")
        ar("مرحبا بالعربية!")
        ru("Привет из России!")
        tr("Merhaba Türkçe!")
        pt("Olá de Portugal!")
        id("Halo dari Indonesia!")
        ko("안녕하세요 한국에서!")
        listen_en(10)
