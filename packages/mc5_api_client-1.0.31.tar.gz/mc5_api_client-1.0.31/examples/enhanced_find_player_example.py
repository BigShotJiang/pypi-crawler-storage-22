#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : enhanced_find_player_example.py
# | License  : MIT License © 2026 Chizoba
# | Brief    : Enhanced find_player with proper data display order
# ────────────────★─────────────────────────────────

"""
Enhanced Find Player Example

This example demonstrates the improved find_player function that displays
player information in the proper order:

1. First: display_name, private_profile, country, alias, vip_points, xp
2. Second: fed_id, rating_duel_last, rating, rating_duel, rating_last  
3. Third: osiris_info (clan/squad information - clan_name first, then clan_id)
4. Fourth: statistics (mp first, then sp)

Usage:
    python enhanced_find_player_example.py
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from mc5_api_client import find_player, validate_dogtag_id, decode_unicode_name

def print_player_info_enhanced(result: dict):
    """Print player information in the proper display order."""
    
    if not result['success']:
        print(f"❌ Error: {result['error']}")
        return
    
    player = result['player_info']
    
    print("👤 PLAYER INFORMATION")
    print("=" * 50)
    
    # First priority: display_name, private_profile, country, alias, vip_points, xp
    print("🎯 Primary Information:")
    print(f"   👤 Display Name: {player['display_name']}")
    print(f"   🔒 Private Profile: {player['private_profile']}")
    print(f"   🌍 Country: {player['country']}")
    print(f"   🏷️  Alias: {player['alias']}")
    print(f"   💎 VIP Points: {player['vip_points']:,}")
    print(f"   📊 XP: {player['xp']:,}")
    print(f"   ⏰ Time Played: {player['time_played_combined']}")  # NEW: Combined time
    
    # Second priority: fed_id, rating_duel_last, rating, rating_duel, rating_last
    print(f"\n📈 Rating Information:")
    print(f"   🆔 Fed ID: {player['fed_id']}")
    print(f"   ⚔️  Rating Duel Last: {player['rating_duel_last']}")
    print(f"   ⭐ Rating: {player['rating']}")
    print(f"   ⚔️  Rating Duel: {player['rating_duel']}")
    print(f"   ⭐ Rating Last: {player['rating_last']}")
    
    # Third priority: osiris_info (clan/squad information)
    clan = player['clan_info']
    print(f"\n🏰 Clan/Squad Information:")
    print(f"   🏷️  Clan Name: {clan['clan_name']}")
    print(f"   🆔 Clan ID: {clan['clan_id']}")
    print(f"   🎨 Clan Logo: {clan['clan_logo']}")
    print(f"   👥 Clan Member: {clan['clan_member']}")
    print(f"   🎨 Logo Color (Primary): {clan['clan_logo_clr_prim']}")
    print(f"   🎨 Logo Color (Secondary): {clan['clan_logo_clr_sec']}")
    print(f"   👤 Display Name: {clan['display_name']}")
    
    # Fourth priority: statistics (mp first, then sp)
    stats = player['statistics']
    print(f"\n📊 Statistics Summary:")
    
    # Time breakdown (NEW)
    time_breakdown = stats.get('time_breakdown', {})
    if time_breakdown:
        print(f"   ⏰ Time Breakdown:")
        print(f"      🎮 Multiplayer: {time_breakdown.get('mp_time_formatted', '0s')}")
        print(f"      🎯 Single Player: {time_breakdown.get('sp_time_formatted', '0s')}")
        print(f"      🔄 Combined Total: {time_breakdown.get('combined_time', '0s')}")
    
    # MP Statistics
    mp_stats = stats.get('mp', {})
    if mp_stats:
        print(f"\n   🎮 Multiplayer (MP) Statistics:")
        print(f"      💀 Total Kills: {mp_stats.get('kill.total', 0):,}")
        print(f"      🎯 Total Headshots: {mp_stats.get('kill.headshots', 0):,}")
        print(f"      🔫 Total Shots: {mp_stats.get('bullet.shots', 0):,}")
        print(f"      🎪 Time Played: {mp_stats.get('time.played', 0):,} seconds")
        print(f"      🏆 Arena Wins: {mp_stats.get('game.arena.wins', 0):,}")
        print(f"      🎯 Arena Losses: {mp_stats.get('game.arena.losses', 0):,}")
    else:
        print(f"\n   🎮 Multiplayer (MP): No data available")
    
    # SP Statistics
    sp_stats = stats.get('sp', {})
    if sp_stats:
        print(f"\n   🎯 Single Player (SP) Statistics:")
        print(f"      💀 Total Kills: {sp_stats.get('kill.total', 0):,}")
        print(f"      🎯 Total Headshots: {sp_stats.get('kill.headshots', 0):,}")
        print(f"      🔫 Total Shots: {sp_stats.get('bullet.shots', 0):,}")
        print(f"      🎪 Time Played: {sp_stats.get('time.played', 0):,} seconds")
        print(f"      🏆 Campaign Wins: {sp_stats.get('game.campaign.wins', 0):,}")
        print(f"      ❌ Campaign Losses: {sp_stats.get('game.campaign.losses', 0):,}")
    else:
        print(f"\n   🎯 Single Player (SP): No data available")

def test_enhanced_find_player():
    """Test the enhanced find_player function."""
    
    print("🎮 Enhanced Find Player Test")
    print("=" * 40)
    print("Testing improved data display order and formatting")
    print()
    
    # Test 1: Basic player search
    print("1. 📋 Basic Player Search")
    print("-" * 30)
    result = find_player()
    print_player_info_enhanced(result)
    
    # Test 2: Dogtag search
    print(f"\n\n2. 🏷️ Dogtag Search ('f55f')")
    print("-" * 35)
    result = find_player(dogtag_id="f55f")
    print_player_info_enhanced(result)
    
    if result['success']:
        dogtag_info = result['dogtag_search']
        print(f"\n🏷️ Dogtag Search Results:")
        print(f"   🔍 Searched: '{dogtag_info['searched_id']}'")
        print(f"   📋 Results: {len(dogtag_info['results'])} found")
        print(f"   📦 Collection: {dogtag_info['collection_size']} items")
        
        if dogtag_info['results']:
            print(f"   ✅ Found in:")
            for i, dt_result in enumerate(dogtag_info['results'][:3], 1):
                print(f"      {i}. {dt_result['location']}")
        else:
            print(f"   ❌ Dogtag not found in user data")
    
    # Test 3: Raw response
    print(f"\n\n3. 📄 Raw Response Test")
    print("-" * 25)
    result = find_player(raw=True)
    
    if result['success'] and result['raw_response']:
        raw_size = len(str(result['raw_response']))
        print(f"✅ Raw response retrieved:")
        print(f"   📏 Size: {raw_size:,} characters")
        print(f"   🔍 Preview: {str(result['raw_response'])[:200]}...")
    else:
        print(f"❌ Error: {result.get('error', 'Unknown error')}")

def main():
    """Run enhanced find player demonstration."""
    
    print("🎮 MC5 API Client - Enhanced Find Player")
    print("=" * 55)
    print("Demonstrating improved data display and organization")
    print()
    
    # Run tests
    test_enhanced_find_player()
    
    print("\n🎉 Enhanced Find Player Example Complete!")
    print("=" * 45)
    print("✅ Data displayed in proper priority order")
    print("✅ Unicode names handled correctly")
    print("✅ Clan information organized properly")
    print("✅ Statistics (MP first, then SP) displayed")
    print("✅ Dogtag search with validation working")
    print("✅ Raw response access available")
    print()
    print("📋 Usage Examples:")
    print("   find_player()                    # Basic info with proper order")
    print("   find_player(raw=True)             # + Raw response")
    print("   find_player(dogtag_id='f55f')     # + Dogtag search")
    print("   find_player(raw=True, dogtag_id='f55f')  # Everything")

if __name__ == "__main__":
    main()
