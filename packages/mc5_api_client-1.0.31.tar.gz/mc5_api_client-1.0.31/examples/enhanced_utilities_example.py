#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : enhanced_utilities_example.py
# | License  : MIT License © 2026 Chizoba
# | Brief    | Enhanced utilities example for MC5 API Client
# ────────────────★─────────────────────────────────

"""
MC5 Enhanced Utilities Example

This example demonstrates the enhanced utilities and advanced features
of the MC5 API Client beyond basic chat and room finding.

Features shown:
- Server statistics and analytics
- Best room finding algorithms
- Player search and tracking
- Room recommendations
- Server monitoring
- Auto-join functionality
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'src'))

from mc5_api_client import (
    MC5EnhancedAPI, get_server_stats, find_best_game_rooms, search_players,
    get_room_recommendations, auto_join_best_room, analyze_player_activity
)

def main():
    print("🎮 MC5 Enhanced Utilities Example")
    print("=" * 45)
    
    # Example 1: Server Statistics
    print("\n📊 Example 1: Server Statistics")
    print("-" * 35)
    
    stats = get_server_stats()
    if stats:
        print(f"📈 Total Rooms: {stats.get('total_rooms', 0)}")
        print(f"🏠 Ranked Rooms: {stats.get('ranked_rooms', 0)}")
        print(f"🎨 Custom Rooms: {stats.get('custom_rooms', 0)}")
        print(f"🏰 Clan Rooms: {stats.get('clan_rooms', 0)}")
        print(f"👥 Total Players: {stats.get('total_players', 0)}")
        print(f"📊 Fill Rate: {stats.get('fill_rate', 0):.1f}%")
        print(f"🎯 Most Popular Mode: {stats.get('most_popular_mode', 'Unknown')}")
        
        print("\n📊 Game Modes:")
        for mode, count in stats.get('game_modes', {}).items():
            print(f"   {mode}: {count} rooms")
    else:
        print("❌ Failed to get server statistics")
    
    # Example 2: Find Best Rooms
    print("\n🎯 Example 2: Find Best Rooms")
    print("-" * 35)
    
    best_rooms = find_best_game_rooms(game_mode="teambattle", min_players=4)
    if best_rooms:
        print(f"✅ Found {len(best_rooms)} best rooms:")
        for i, room in enumerate(best_rooms[:3], 1):
            name = room.get('name', 'Unknown')
            players = room.get('member_count', 0)
            capacity = room.get('capacity', 0)
            fill_rate = room.get('fill_rate', 0)
            print(f"   {i}. {name}: {players}/{capacity} ({fill_rate:.1f}% full)")
    else:
        print("❌ No suitable rooms found")
    
    # Example 3: Search Players
    print("\n🔍 Example 3: Search Players")
    print("-" * 30)
    
    # Search for common player name patterns
    search_patterns = ["Player", "Pro", "Elite", "Warrior"]
    
    for pattern in search_patterns:
        players = search_players(pattern)
        if players:
            print(f"🔍 Found {len(players)} players matching '{pattern}':")
            for i, player in enumerate(players[:3], 1):
                name = player.get('name', 'Unknown')
                country = player.get('country', 'Unknown')
                level = player.get('level', 'Unknown')
                room = player.get('room_name', 'Unknown')
                print(f"   {i}. {name} (Lvl {level}, {country}) in {room}")
        else:
            print(f"🔍 No players found matching '{pattern}'")
    
    # Example 4: Room Recommendations
    print("\n💡 Example 4: Room Recommendations")
    print("-" * 35)
    
    recommendations = get_room_recommendations(mode="teambattle", players=8)
    if recommendations:
        print(f"💡 Found {len(recommendations)} recommendations:")
        for i, room in enumerate(recommendations, 1):
            name = room.get('name', 'Unknown')
            players = room.get('member_count', 0)
            score = room.get('match_score', 0)
            print(f"   {i}. {name}: {players} players (Score: {score})")
    else:
        print("❌ No recommendations available")
    
    # Example 5: Auto-Join Best Room
    print("\n🚀 Example 5: Auto-Join Best Room")
    print("-" * 35)
    
    best_room = auto_join_best_room(game_mode="teambattle", min_players=4)
    if best_room:
        print("✅ Successfully found and analyzed best room")
        print("💡 In a real scenario, you would join this room automatically")
    else:
        print("❌ No suitable rooms found for auto-join")
    
    # Example 6: Player Activity Analysis
    print("\n📈 Example 6: Player Activity Analysis")
    print("-" * 40)
    
    print("💡 Analyzing recent player activity...")
    activity = analyze_player_activity(time_window_minutes=60)
    
    if activity:
        print(f"📊 Total Active Players: {activity.get('total_active_players', 0)}")
        print(f"🏠 Rooms Analyzed: {activity.get('rooms_analyzed', 0)}")
        print(f"👥 Avg Players/Room: {activity.get('average_players_per_room', 0):.1f}")
        print(f"🎯 Most Active Mode: {activity.get('most_active_game_mode', 'Unknown')}")
        
        print("\n📊 Player Distribution:")
        for mode, count in activity.get('player_distribution', {}).items():
            print(f"   {mode}: {count} players")
    else:
        print("❌ Failed to analyze player activity")
    
    # Example 7: Advanced API Usage
    print("\n🔧 Example 7: Advanced API Usage")
    print("-" * 35)
    
    try:
        # Initialize enhanced API
        api = MC5EnhancedAPI()
        
        # Get comprehensive server report
        print("📋 Generating server report...")
        report = api.create_room_monitor_report()
        print(report)
        
        # Monitor rooms for a short time
        print("\n🔍 Monitoring rooms for 30 seconds...")
        
        def room_callback(rooms):
            if rooms:
                print(f"📊 Found {len(rooms)} active rooms")
                total_players = sum(room.get('member_count', 0) for room in rooms)
                print(f"   Total players: {total_players}")
        
        # Note: This would run for 30 seconds in a real scenario
        # api.monitor_rooms(room_callback, interval=10)
        print("💡 Room monitoring would run here in real scenario")
        
    except Exception as e:
        print(f"❌ Error in advanced API usage: {e}")
    
    print("\n🎉 Enhanced Utilities Example Completed!")
    print("💡 Try different parameters and explore more functions!")

if __name__ == "__main__":
    main()
