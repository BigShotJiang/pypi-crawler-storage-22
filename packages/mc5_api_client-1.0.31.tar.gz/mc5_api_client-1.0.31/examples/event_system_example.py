#!/usr/bin/env python3
# ────────────[ KAKUZU ]────────────────────────────
# | Discord  : kakuzu_f0
# | Telegram : kakuzu_f0
# | File     | event_system_example.py
# | License  : MIT License © 2026 Kakuzu
# | Brief    | Event system example for MC5 API Client
# ────────────────★─────────────────────────────────

"""
MC5 Event System Example

This example demonstrates the event functionality for Modern Combat 5,
including event registration, leaderboard viewing, and rank tracking.

Based on reverse-engineered API endpoints for MC5 events.
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'src'))

from mc5_api_client import (
    MC5EventSystem, register_event, get_event_leaderboard, get_my_event_rank,
    show_event_leaderboard, show_my_event_status, register_current_event,
    show_current_event_leaderboard, show_my_current_event_status
)

def main():
    print("🎮 MC5 Event System Example")
    print("=" * 40)
    
    # Example 1: Register for current event
    print("\n📝 Example 1: Register for Current Event")
    print("-" * 40)
    
    try:
        success = register_current_event()
        if success:
            print("✅ Successfully registered for current event!")
        else:
            print("❌ Failed to register for current event")
    except Exception as e:
        print(f"❌ Error: {e}")
    
    # Example 2: Show current event leaderboard
    print("\n🏆 Example 2: Current Event Leaderboard")
    print("-" * 40)
    
    try:
        show_current_event_leaderboard(top_count=10)
    except Exception as e:
        print(f"❌ Error: {e}")
    
    # Example 3: Show your event status
    print("\n👤 Example 3: Your Event Status")
    print("-" * 30)
    
    try:
        show_my_current_event_status()
    except Exception as e:
        print(f"❌ Error: {e}")
    
    # Example 4: Get raw event data
    print("\n📊 Example 4: Raw Event Data")
    print("-" * 30)
    
    try:
        current_event_id = "0c646c6a-e61c-11f0-be58-b8ca3a634708"
        leaderboard_data = get_event_leaderboard(current_event_id, limit=5)
        
        if leaderboard_data:
            print(f"📋 Event ID: {leaderboard_data.get('id')}")
            print(f"📅 Created: {leaderboard_data.get('created')}")
            print(f"👥 Total Entries: {leaderboard_data.get('total_entries')}")
            print(f"🏆 Division: {leaderboard_data.get('division')}")
            
            # Show top 3 players
            entries = leaderboard_data.get('data', [])
            if entries:
                print(f"\n🥇 Top 3 Players:")
                for i, entry in enumerate(entries[:3], 1):
                    name = entry.get('display_name', 'Unknown')
                    score = entry.get('score', 0)
                    clan = entry.get('_clan_name', '')
                    print(f"   {i}. {name}: {score} pts")
                    if clan:
                        print(f"      🏰 {clan}")
        else:
            print("❌ Failed to get event data")
            
    except Exception as e:
        print(f"❌ Error: {e}")
    
    # Example 5: Custom event registration
    print("\n🎯 Example 5: Custom Event Registration")
    print("-" * 40)
    
    try:
        # Initialize event system
        event_system = MC5EventSystem()
        
        # Register for a specific event
        custom_event_id = "0c646c6a-e61c-11f0-be58-b8ca3a634708"
        success = event_system.register_for_event(custom_event_id)
        
        if success:
            print("✅ Successfully registered for custom event!")
            
            # Show leaderboard for this event
            event_system.show_event_leaderboard(custom_event_id, top_count=5)
            
            # Show your status in this event
            event_system.show_my_event_status(custom_event_id)
        else:
            print("❌ Failed to register for custom event")
            
    except Exception as e:
        print(f"❌ Error: {e}")
    
    # Example 6: Event system features
    print("\n⚙️ Example 6: Event System Features")
    print("-" * 35)
    
    print("🎮 Available Event Functions:")
    print("   📝 register_event(event_id) - Register for specific event")
    print("   📊 get_event_leaderboard(event_id) - Get event leaderboard")
    print("   👤 get_my_event_rank(event_id) - Get your event rank")
    print("   🏆 show_event_leaderboard(event_id, top_count) - Show formatted leaderboard")
    print("   📈 show_my_event_status(event_id) - Show your event status")
    print()
    print("🚀 Quick Functions:")
    print("   📝 register_current_event() - Register for current event")
    print("   🏆 show_current_event_leaderboard(top_count) - Show current event leaderboard")
    print("   📈 show_my_current_event_status() - Show your current event status")
    print()
    print("🎯 Event ID Format:")
    print("   📋 Current Event: 0c646c6a-e61c-11f0-be58-b8ca3a634708")
    print("   📋 Custom Events: Use specific event IDs")
    
    print("\n🎉 Event System Example Completed!")
    print("💡 Use these functions to participate in MC5 events!")
    print("🏆 Track your progress and compete with other players!")

if __name__ == "__main__":
    main()
