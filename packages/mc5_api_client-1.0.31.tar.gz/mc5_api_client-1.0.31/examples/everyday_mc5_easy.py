#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : everyday_mc5_easy.py
# | License  | MIT License © 2026 Chizoba
# | Brief    | Super simple everyday MC5 tasks with Easy MC5
# ────────────────★─────────────────────────────────

"""
Super Simple Everyday MC5 Tasks
================================

This script shows how easy MC5 tasks can be with the new MC5Easy module.
No complex setup, no confusing API calls - just simple, readable code.

Quick Start:
    # Set your credentials as environment variables:
    # export MC5_USERNAME="your_credential"
    # export MC5_PASSWORD="your_password"
    
    # Or set them directly in the code
    
    python everyday_mc5_easy.py
"""

import os
from mc5_api_client import MC5Easy

def main():
    """Super simple everyday MC5 tasks."""
    print("🎮 Super Simple MC5 Tasks")
    print("=" * 35)
    
    # Method 1: Use environment variables (recommended)
    # Set these in your system:
    # MC5_USERNAME=your_credential
    # MC5_PASSWORD=your_password
    
    # Method 2: Set credentials directly
    username = os.getenv('MC5_USERNAME') or "YOUR_MC5_CREDENTIAL"
    password = os.getenv('MC5_PASSWORD') or "YOUR_MC5_PASSWORD"
    
    if username == "YOUR_MC5_CREDENTIAL" or password == "YOUR_MC5_PASSWORD":
        print("⚠️ Please set your MC5 credentials:")
        print("   Option 1: Set environment variables MC5_USERNAME and MC5_PASSWORD")
        print("   Option 2: Edit the username and password variables in this script")
        print()
        print("   Example:")
        print("   export MC5_USERNAME='anonymous:your_credential_here'")
        print("   export MC5_PASSWORD='your_password_here'")
        return
    
    # Initialize with context manager (auto-connects and auto-closes)
    with MC5Easy(username, password) as mc5:
        print("✅ Connected to MC5!")
        print()
        
        # === ONE-LINE TASKS ===
        
        # 1. Quick status check
        print("📊 Quick Status:")
        print(mc5.quick_status())
        print()
        
        # 2. Check daily tasks
        print("📅 Daily Tasks:")
        tasks = mc5.check_daily_tasks()
        if tasks:
            print(f"✅ You have {len(tasks)} daily task(s):")
            for task in tasks:
                print(f"   📋 {task.get('name', 'Unknown Task')}")
        else:
            print("ℹ️ No daily tasks right now")
        print()
        
        # 3. Get your profile
        print("👤 Your Profile:")
        profile = mc5.get_my_stats()
        print(f"   Name: {profile.get('name', 'Unknown')}")
        print(f"   Level: {profile.get('level', 'Unknown')}")
        print(f"   XP: {profile.get('xp', 0):,}")
        print(f"   Score: {profile.get('score', 0):,}")
        if profile.get('clan_id'):
            print(f"   Clan: {profile.get('clan_id')}")
        print()
        
        # 4. Search for a player (optional)
        search_player = input("🔍 Search for a player? (dogtag or press Enter): ").strip()
        if search_player:
            print(f"🔍 Searching for {search_player}...")
            player = mc5.find_player(search_player)
            if player.get('found'):
                print(f"✅ Found {search_player}:")
                print(f"   Kills: {player.get('kills', 0):,}")
                print(f"   Level: {player.get('level', 'Unknown')}")
                print(f"   Score: {player.get('score', 0):,}")
                print(f"   Wins: {player.get('wins', 0)}")
                print(f"   Losses: {player.get('losses', 0)}")
            else:
                print(f"❌ Player {search_player} not found")
            print()
        
        # 5. Check clan members (if in a clan)
        clan_stats = mc5.get_clan_stats()
        if clan_stats.get('total_members', 0) > 0:
            print("🏰 Your Clan:")
            print(f"   Total Members: {clan_stats['total_members']}")
            print(f"   Online Now: {clan_stats['online_members']}")
            print(f"   Total Score: {clan_stats['total_score']:,}")
            print(f"   Average Score: {clan_stats['average_score']:,}")
            
            if clan_stats.get('top_member'):
                top = clan_stats['top_member']
                print(f"   Top Member: {top.get('name', 'Unknown')} ({int(top.get('_score') or top.get('score') or 0):,})")
            print()
        
        # 6. Send a message (optional)
        send_msg = input("💬 Send a message? (y/n): ").strip().lower()
        if send_msg == 'y':
            dogtag = input("Enter friend's dogtag: ").strip()
            message = input("Enter your message: ").strip()
            
            if dogtag and message:
                success = mc5.send_message_to_friend(dogtag, message)
                if success:
                    print(f"✅ Message sent to {dogtag}")
                else:
                    print("❌ Failed to send message")
            print()
        
        # 7. Run complete daily routine
        run_routine = input("🚀 Run complete daily routine? (y/n): ").strip().lower()
        if run_routine == 'y':
            print("🚀 Running complete daily routine...")
            routine_results = mc5.run_daily_routine()
            print("✅ Daily routine completed!")
            print()
            print("📊 Routine Summary:")
            print(f"   Profile: {routine_results['profile'].get('name', 'Unknown')}")
            print(f"   Daily Tasks: {len(routine_results['daily_tasks'])}")
            print(f"   Clan Members: {routine_results['clan_stats'].get('total_members', 0)}")
        
        print()
        print("🎉 All tasks completed!")
        print("💡 Tip: Use MC5Easy for all your MC5 tasks - it's that simple!")

def demo_one_liners():
    """Demonstrate one-liner functions."""
    print("🚀 One-Liner Function Demos")
    print("=" * 35)
    
    # These work if you have environment variables set
    username = os.getenv('MC5_USERNAME')
    password = os.getenv('MC5_PASSWORD')
    
    if not username or not password:
        print("⚠️ Set MC5_USERNAME and MC5_PASSWORD environment variables to see demos")
        return
    
    try:
        # One-liner functions
        print("📅 Checking daily tasks...")
        tasks = check_my_daily_tasks(username, password)
        print(f"   Found {len(tasks)} daily tasks")
        
        print("👤 Getting profile...")
        profile = get_my_mc5_profile(username, password)
        print(f"   Profile: {profile.get('name', 'Unknown')} (Level {profile.get('level', 'Unknown')})")
        
        print("🔍 Finding player...")
        player = find_mc5_player("f55f", username, password)
        if player.get('found'):
            print(f"   Found: {player.get('kills', 0)} kills")
        else:
            print("   Not found")
            
    except Exception as e:
        print(f"❌ Demo error: {e}")

if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1 and sys.argv[1] == "--demo":
        demo_one_liners()
    else:
        main()
