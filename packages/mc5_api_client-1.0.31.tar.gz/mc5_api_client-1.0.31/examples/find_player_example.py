#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : find_player_example.py
# | License  : MIT License © 2026 Chizoba
# | Brief    : Example demonstrating find_player function with raw response
# ────────────────★─────────────────────────────────

"""
Find Player Example

This example demonstrates the find_player() function with various options:
- Basic player information retrieval
- Dogtag search with validation (4-8 characters)
- Full raw JSON response display
- Unicode name handling

Usage:
    python find_player_example.py
"""

import sys
import os
import json

# Add the src directory to Python path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from mc5_api_client import find_player, validate_dogtag_id

def test_dogtag_validation():
    """Test dogtag ID validation (4-8 characters)."""
    
    print("🏷️ Dogtag ID Validation Test")
    print("=" * 40)
    
    test_cases = [
        ("f55f", True, "Valid: 4 characters"),
        ("elite123", True, "Valid: 8 characters"),
        ("war", False, "Invalid: 3 characters (too short)"),
        ("toolong123", False, "Invalid: 10 characters (too long)"),
        ("f55f!", False, "Invalid: contains special character"),
        ("", False, "Invalid: empty string"),
        ("  elite  ", True, "Valid: 5 characters with whitespace trimmed"),
    ]
    
    for dogtag_id, expected, description in test_cases:
        result = validate_dogtag_id(dogtag_id)
        status = "✅" if result == expected else "❌"
        print(f"{status} '{dogtag_id}' -> {result} ({description})")

def test_basic_player_search():
    """Test basic player information retrieval."""
    
    print("\n👤 Basic Player Search")
    print("=" * 30)
    
    result = find_player()
    
    if result['success']:
        player = result['player_info']
        print(f"✅ Player found:")
        print(f"   Name: {player['display_name']}")
        print(f"   Clan: {player['clan_name']}")
        print(f"   Rating: {player['rating']}")
        print(f"   XP: {player['xp']}")
    else:
        print(f"❌ Error: {result['error']}")

def test_dogtag_search():
    """Test dogtag search with validation."""
    
    print("\n🏷️ Dogtag Search Test")
    print("=" * 30)
    
    # Test valid dogtag
    print("Testing valid dogtag 'f55f':")
    result = find_player(dogtag_id="f55f")
    
    if result['success']:
        dogtag_info = result['dogtag_search']
        print(f"✅ Search completed:")
        print(f"   Searched: '{dogtag_info['searched_id']}'")
        print(f"   Results: {len(dogtag_info['results'])} found")
        print(f"   Collection: {dogtag_info['collection_size']} items")
        
        if dogtag_info['results']:
            print("   Found locations:")
            for i, dt_result in enumerate(dogtag_info['results'][:3], 1):
                print(f"     {i}. {dt_result['location']}")
        else:
            print("   Dogtag not found in user data (this is expected)")
    else:
        print(f"❌ Error: {result['error']}")
    
    # Test invalid dogtag
    print("\nTesting invalid dogtag 'f':")
    result = find_player(dogtag_id="f")
    
    if not result['success']:
        print(f"✅ Correctly rejected invalid dogtag: {result['error']}")
    else:
        print("❌ Should have rejected invalid dogtag")

def test_raw_response():
    """Test raw response functionality."""
    
    print("\n📄 Raw Response Test")
    print("=" * 25)
    
    result = find_player(raw=True)
    
    if result['success'] and result['raw_response']:
        raw_size = len(str(result['raw_response']))
        print(f"✅ Raw response retrieved:")
        print(f"   Size: {raw_size:,} characters")
        print(f"   Preview: {str(result['raw_response'])[:100]}...")
    else:
        print(f"❌ Error: {result.get('error', 'Unknown error')}")

def main():
    """Run find_player function demonstration."""
    
    print("🎮 MC5 API Client - Find Player Example")
    print("=" * 50)
    print("Demonstrating find_player() function with all features")
    print()
    
    # Run tests
    test_dogtag_validation()
    test_basic_player_search()
    test_dogtag_search()
    test_raw_response()
    
    print("\n🎉 Find Player Example Complete!")
    print("=" * 40)
    print("✅ All find_player() features tested successfully")
    print("✅ Dogtag validation (4-8 characters) working")
    print("✅ Raw response display working")
    print("✅ Unicode name handling working")
    print()
    print("📋 Usage Examples:")
    print("   find_player()                    # Basic player info")
    print("   find_player(raw=True)             # + Raw response")
    print("   find_player(dogtag_id='f55f')     # + Dogtag search")
    print("   find_player(raw=True, dogtag_id='elite')  # Everything")

if __name__ == "__main__":
    main()
