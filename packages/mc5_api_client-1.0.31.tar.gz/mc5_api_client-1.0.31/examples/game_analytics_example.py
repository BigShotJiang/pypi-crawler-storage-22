#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : game_analytics_example.py
# | License  : MIT License © 2026 Chizoba
# | Brief    | Game analytics example for MC5 API Client
# ────────────────★─────────────────────────────────

"""
MC5 Game Analytics Example

This example demonstrates comprehensive game analytics and statistics
for Modern Combat 5, including player distribution, server performance,
and real-time monitoring.

Features shown:
- Player distribution analysis
- Game mode popularity rankings
- Server performance monitoring
- Player skill distribution
- Real-time analytics dashboard
- Comprehensive reporting
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'src'))

from mc5_api_client import (
    MC5GameAnalytics, get_player_analytics, get_game_mode_rankings,
    check_server_health, track_player, generate_analytics_report,
    start_real_time_monitoring, calculate_player_skill_distribution
)

def main():
    print("📊 MC5 Game Analytics Example")
    print("=" * 40)
    
    # Example 1: Player Distribution Analysis
    print("\n👥 Example 1: Player Distribution Analysis")
    print("-" * 40)
    
    player_analytics = get_player_analytics()
    if player_analytics:
        print(f"👥 Total Players Found: {player_analytics.get('total_players_found', 0)}")
        print(f"🆔 Unique Players: {player_analytics.get('unique_players', 0)}")
        print(f"🏠 Average Players/Room: {player_analytics.get('average_players_per_room', 0):.1f}")
        print(f"📊 Fill Rate: {player_analytics.get('room_capacity_analysis', {}).get('average_fill_rate', 0):.1f}%")
        
        print("\n🏠 Server Distribution:")
        for server_type, count in player_analytics.get('server_distribution', {}).items():
            print(f"   {server_type.title()}: {count} rooms")
        
        print("\n🌍 Country Distribution (Top 5):")
        country_dist = player_analytics.get('country_distribution', {})
        sorted_countries = sorted(country_dist.items(), key=lambda x: x[1], reverse=True)[:5]
        for country, count in sorted_countries:
            print(f"   {country}: {count} players")
        
        print("\n📈 Level Distribution:")
        level_dist = player_analytics.get('level_distribution', {})
        for level_range, count in level_dist.items():
            print(f"   {level_range}: {count} players")
    else:
        print("❌ Failed to get player analytics")
    
    # Example 2: Game Mode Popularity Rankings
    print("\n🎯 Example 2: Game Mode Popularity Rankings")
    print("-" * 45)
    
    mode_rankings = get_game_mode_rankings()
    if mode_rankings:
        print("🏆 Game Mode Rankings:")
        for mode, data in list(mode_rankings.items())[:5]:
            rank = data.get('rank', 0)
            rooms = data.get('rooms', 0)
            players = data.get('total_players', 0)
            avg_players = data.get('avg_players_per_room', 0)
            print(f"   {rank}. {mode}: {players} players in {rooms} rooms (avg: {avg_players}/room)")
    else:
        print("❌ Failed to get game mode rankings")
    
    # Example 3: Server Health Check
    print("\n🏥 Example 3: Server Health Check")
    print("-" * 35)
    
    server_health = check_server_health()
    if server_health:
        print(f"⚡ Overall Response Time: {server_health.get('overall_response_time_ms', 0)}ms")
        print(f"🏆 Fastest Server: {server_health.get('fastest_server', 'Unknown')}")
        print(f"👥 Most Populated Server: {server_health.get('most_populated_server', 'Unknown')}")
        
        print("\n🖥️ Server Performance:")
        for server, data in server_health.get('server_performance', {}).items():
            status = data.get('status', 'Unknown')
            response_time = data.get('response_time_ms', 0)
            players = data.get('total_players', 0)
            fill_rate = data.get('fill_rate', 0)
            status_emoji = "✅" if status == 'healthy' else "⚠️"
            print(f"   {status_emoji} {server}: {response_time}ms, {players} players, {fill_rate:.1f}% full")
    else:
        print("❌ Failed to check server health")
    
    # Example 4: Player Skill Distribution
    print("\n📈 Example 4: Player Skill Distribution")
    print("-" * 40)
    
    skill_dist = calculate_player_skill_distribution()
    if skill_dist:
        print("🎯 Player Skill Distribution:")
        for level_range, data in skill_dist.items():
            count = data.get('count', 0)
            percentage = data.get('percentage', 0)
            print(f"   {level_range}: {count} players ({percentage}%)")
    else:
        print("❌ Failed to calculate skill distribution")
    
    # Example 5: Comprehensive Analytics Report
    print("\n📋 Example 5: Comprehensive Analytics Report")
    print("-" * 45)
    
    print("📋 Generating comprehensive analytics report...")
    report = generate_analytics_report()
    print(report)
    
    # Example 6: Real-time Monitoring Demo
    print("\n📊 Example 6: Real-time Monitoring Demo")
    print("-" * 40)
    
    print("📊 Real-time monitoring demo (would run continuously):")
    print("💡 This would show a live dashboard with:")
    print("   - Real-time player counts")
    print("   - Server performance metrics")
    print("   - Top game modes")
    print("   - Peak activity times")
    
    # Note: Uncomment to actually start real-time monitoring
    # print("🚀 Starting real-time monitoring...")
    # start_real_time_monitoring(update_interval=30)
    
    # Example 7: Advanced Analytics with MC5GameAnalytics
    print("\n🔧 Example 7: Advanced Analytics")
    print("-" * 35)
    
    try:
        analytics = MC5GameAnalytics()
        
        # Get detailed player distribution
        print("🔍 Advanced player distribution analysis...")
        detailed_analysis = analytics.analyze_player_distribution()
        
        if detailed_analysis:
            print(f"📊 Peak Activity Time: {detailed_analysis.get('peak_activity_time', 'Unknown')}")
            print(f"🎮 Most Popular Game Mode: {detailed_analysis.get('most_popular_mode', 'Unknown')}")
        
        # Get game mode popularity with detailed stats
        print("\n🎯 Detailed game mode popularity...")
        detailed_modes = analytics.get_game_mode_popularity()
        
        if detailed_modes:
            print("🏆 Top 3 Game Modes by Popularity Score:")
            for mode, data in list(detailed_modes.items())[:3]:
                score = data.get('popularity_score', 0)
                rooms = data.get('rooms', 0)
                print(f"   {mode}: Score {score} ({rooms} rooms)")
        
        # Server performance analysis
        print("\n🖥️ Detailed server performance analysis...")
        server_perf = analytics.analyze_server_performance()
        
        if server_perf:
            print(f"⚡ Analysis completed in {server_perf.get('overall_response_time_ms', 0)}ms")
            print(f"🏆 Fastest server: {server_perf.get('fastest_server', 'Unknown')}")
        
    except Exception as e:
        print(f"❌ Error in advanced analytics: {e}")
    
    # Example 8: Analytics Summary
    print("\n📊 Example 8: Analytics Summary")
    print("-" * 35)
    
    print("📊 Analytics Summary:")
    print("   ✅ Player distribution analysis completed")
    print("   ✅ Game mode rankings generated")
    print("   ✅ Server health check performed")
    print("   ✅ Skill distribution calculated")
    print("   ✅ Comprehensive report generated")
    print("   ✅ Advanced analytics demonstrated")
    
    print("\n🎉 Game Analytics Example Completed!")
    print("💡 Use these analytics to understand MC5 server dynamics!")
    print("📊 Real-time monitoring provides live insights into player activity!")

if __name__ == "__main__":
    main()
