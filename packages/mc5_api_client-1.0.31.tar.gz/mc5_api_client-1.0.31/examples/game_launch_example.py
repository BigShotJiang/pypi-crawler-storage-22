#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : game_launch_example.py
# | License  | MIT License © 2026 Chizoba
# | Brief    | Example of game launch functionality
# ────────────────★─────────────────────────────────

"""
Game Launch Example
==================

This example demonstrates how to use the new game launch functionality in MC5Easy.
Shows how to create federation sessions, launch games, and manage device IDs.

Setup:
1. Set your MC5 credentials as environment variables:
   export MC5_USERNAME="your_credential"
   export MC5_PASSWORD="your_password"

2. Or edit the credentials directly in the script

3. Run the example:
   python game_launch_example.py
"""

import os
from mc5_api_client import MC5Easy, create_federation_session, get_global_id, generate_device_id

def main():
    """Demonstrate game launch functionality."""
    print("🎮 MC5 Game Launch Example")
    print("=" * 40)
    
    # Method 1: Use environment variables (recommended)
    username = os.getenv('MC5_USERNAME') or "YOUR_MC5_CREDENTIAL"
    password = os.getenv('MC5_PASSWORD') or "YOUR_MC5_PASSWORD"
    
    if username == "YOUR_MC5_CREDENTIAL" or password == "YOUR_MC5_PASSWORD":
        print("⚠️ Please set your MC5 credentials:")
        print("   Option 1: Set environment variables MC5_USERNAME and MC5_PASSWORD")
        print("   Option 2: Edit the username and password variables in this script")
        print()
        print("   Example:")
        print("   export MC5_USERNAME='anonymous:your_credential_here'")
        print("   export MC5_PASSWORD='your_password_here'")
        return
    
    print(f"🔑 Using credentials: {username[:30]}...")
    print()
    
    # === Method 1: Get Global ID ===
    print("🌐 Method 1: Get Global ID")
    print("-" * 30)
    
    try:
        global_id = get_global_id()
        print(f"✅ Global ID: {global_id}")
        
        # Get global ID with custom device ID
        custom_global_id = get_global_id(device_id="custom_device_123")
        print(f"✅ Custom Global ID: {custom_global_id}")
        
    except Exception as e:
        print(f"❌ Error getting global ID: {e}")
    
    print()
    
    # === Method 2: Generate Device ID ===
    print("🔧 Method 2: Generate Device ID")
    print("-" * 35)
    
    try:
        device_id = generate_device_id()
        print(f"✅ Generated Device ID: {device_id}")
        
        # Generate another one
        device_id_2 = generate_device_id()
        print(f"✅ Generated Device ID 2: {device_id_2}")
        
    except Exception as e:
        print(f"❌ Error generating device ID: {e}")
    
    print()
    
    # === Method 3: Create Federation Session ===
    print("🎮 Method 3: Create Federation Session")
    print("-" * 40)
    
    try:
        session = create_federation_session(username, password)
        
        if session.get("success"):
            print("✅ Federation session created successfully!")
            print(f"   Room ID: {session.get('room_id')}")
            print(f"   Controller Host: {session.get('controller_host')}")
            print(f"   TCP Port: {session.get('controller_tcp_port')}")
            print(f"   HTTP Port: {session.get('controller_http_port')}")
            print(f"   HTTPS Port: {session.get('controller_https_port')}")
            
            # Show access token info
            access_token = session.get('access_token', '')
            print(f"   Access Token: {access_token[:50]}...")
            
            # Show encrypted token
            encrypted_token = session.get('encrypted_access_token', '')
            print(f"   Encrypted Token: {encrypted_token[:50]}...")
            
        else:
            print(f"❌ Federation session failed: {session}")
            
    except Exception as e:
        print(f"❌ Error creating federation session: {e}")
    
    print()
    
    # === Method 4: Launch Game with MC5Easy ===
    print("🚀 Method 4: Launch Game with MC5Easy")
    print("-" * 40)
    
    try:
        with MC5Easy(username, password) as mc5:
            print("🎮 Creating game launch session...")
            launch_info = mc5.launch_game_session()
            
            if launch_info.get("success"):
                print("✅ Game launch session ready!")
                print(f"   Message: {launch_info.get('message')}")
                print(f"   Room ID: {launch_info.get('room_id')}")
                print(f"   Controller: {launch_info.get('controller', {}).get('host')}")
                print(f"   TCP Port: {launch_info.get('controller', {}).get('tcp_port')}")
                print(f"   HTTP Port: {launch_info.get('controller', {}).get('http_port')}")
                print(f"   HTTPS Port: {launch_info.get('controller', {}).get('https_port')}")
                
                # Show launch command
                launch_cmd = launch_info.get('launch_command', '')
                print(f"   Launch Command: {launch_cmd}")
                
                # Show parsed token
                parsed_token = launch_info.get('parsed_token', {})
                print(f"   Token ID: {parsed_token.get('token_id')}")
                print(f"   Scopes: {parsed_token.get('scopes')}")
                print(f"   Client ID: {parsed_token.get('client_id')}")
                print(f"   Timestamp: {parsed_token.get('timestamp')}")
                print(f"   Device ID: {parsed_token.get('device_id')}")
                
            else:
                print(f"❌ Game launch failed: {launch_info}")
            
    except Exception as e:
        print(f"❌ Error launching game: {e}")
    
    print()
    
    # === Method 5: Get Comprehensive Session Info ===
    print("📊 Method 5: Get Comprehensive Session Info")
    print("-" * 45)
    
    try:
        with MC5Easy(username, password) as mc5:
            print("📋 Getting comprehensive session info...")
            session_info = mc5.get_session_info()
            
            if session_info.get("success"):
                print("✅ Session info retrieved successfully!")
                
                # Show session info
                session = session_info.get('session', {})
                print(f"   Session Success: {session.get('success')}")
                print(f"   Room ID: {session.get('room_id')}")
                print(f"   Action: {session.get('action')}")
                
                # Show device info
                device_info = session_info.get('device_info', {})
                print(f"   Global ID: {device_info.get('global_id')}")
                print(f"   Device Type: {device_info.get('device_type')}")
                print(f"   Profile Name: {device_info.get('profile_name')}")
                print(f"   Profile Level: {device_info.get('profile_level')}")
                print(f"   Has Clan: {device_info.get('has_clan')}")
                
                # Show global ID
                global_id = session_info.get('global_id')
                print(f"   Global ID: {global_id}")
                
                # Show timestamp
                timestamp = session_info.get('timestamp')
                print(f"   Timestamp: {timestamp}")
                
            else:
                print(f"❌ Session info failed: {session_info}")
            
    except Exception as e:
        print(f"❌ Error getting session info: {e}")
    
    print()
    print("🎉 Game launch functionality completed!")
    print("💡 Tips:")
    print("   - Use MC5Easy for automatic session management")
    print("   - Federation sessions are required for game launch")
    print("   - Global IDs help with device tracking")
    print("   - Launch commands can be used to start the game")
    print("   - Encrypted tokens provide additional security")
    
    print()
    print("🔗 Federation Session Information:")
    print("   - Endpoint: https://federation-eur.gameloft.com/sessions/")
    print("   - Purpose: Create game launch sessions")
    print("   - Returns: Controller info, room ID, access tokens")
    print("   - Required: Username, password, device ID")

def demo_advanced_features():
    """Demonstrate advanced features."""
    print("\n🔧 Advanced Features Demo")
    print("=" * 30)
    
    username = os.getenv('MC5_USERNAME') or "YOUR_MC5_CREDENTIAL"
    password = os.getenv('MC5_PASSWORD') or "YOUR_MC5_PASSWORD"
    
    if username == "YOUR_MC5_CREDENTIAL" or password == "YOUR_MC5_PASSWORD":
        print("⚠️ Please set your MC5 credentials to test advanced features")
        return
    
    try:
        with MC5Easy(username, password) as mc5:
            print("🔍 Testing advanced features...")
            
            # Test multiple device IDs
            print("\n📱 Testing multiple device IDs:")
            device_ids = ["device_1", "device_2", "device_3"]
            
            for device_id in device_ids:
                session = mc5.create_federation_session(device_id)
                if session.get("success"):
                    print(f"   ✅ {device_id}: {session.get('room_id')}")
                else:
                    print(f"   ❌ {device_id}: Failed")
            
            # Test token parsing
            print("\n🔍 Testing token parsing:")
            session = mc5.create_federation_session()
            if session.get("success"):
                access_token = session.get('access_token', '')
                parsed = mc5._parse_access_token(access_token)
                
                print("   ✅ Token components:")
                for key, value in parsed.items():
                    if key == 'raw_token':
                        print(f"      {key}: {str(value)[:30]}...")
                    else:
                        print(f"      {key}: {value}")
            
            # Test launch command generation
            print("\n🚀 Testing launch command generation:")
            launch_info = mc5.launch_game_session()
            if launch_info.get("success"):
                launch_cmd = launch_info.get('launch_command', '')
                print(f"   ✅ Launch Command: {launch_cmd}")
                
                # Show controller info
                controller = launch_info.get('controller', {})
                print(f"   🌐 Controller: {controller.get('host')}")
                print(f"   🔌 TCP: {controller.get('tcp_port')}")
                print(f"   🌐 HTTP: {controller.get('http_port')}")
                print(f"   🔒 HTTPS: {controller.get('https_port')}")
            
    except Exception as e:
        print(f"❌ Error in advanced features: {e}")

if __name__ == "__main__":
    main()
    demo_advanced_features()
