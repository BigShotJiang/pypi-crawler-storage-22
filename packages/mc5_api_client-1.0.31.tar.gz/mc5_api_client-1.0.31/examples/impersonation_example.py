#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : impersonation_example.py
# | License  : MIT License 2026 Chizoba
# | Brief    : MC5 impersonation example - become any player
# ────────────────★─────────────────────────────────

"""
MC5 API Client - Impersonation Example

This example demonstrates the impersonation functionality.
Become any player with custom names and signatures!

Features shown:
- Basic impersonation
- Custom player creation
- Anonymous spy mode
- Preset player profiles
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'src'))

from mc5_api_client import impersonate, become_player, anonymous_spy, test_connection

def main():
    print("🎮 MC5 API Client - Impersonation Example")
    print("=" * 48)
    
    # Test connection first
    print("\n🔗 Testing connection...")
    if test_connection():
        print("✅ Connection successful!")
    else:
        print("❌ Connection failed!")
        return
    
    # Basic impersonation
    print("\n🎭 Basic Impersonation...")
    
    # Impersonate a specific player
    result = impersonate("TestPlayer", "This is a test impersonation message!")
    print(f"✅ Impersonated 'TestPlayer': {result}")
    
    # Custom player creation
    print("\n👤 Custom Player Creation...")
    
    # Create a custom player with red signature
    custom_player = become_player("CustomPlayer", "FF0000")
    if custom_player:
        print("✅ Created custom player with red signature")
        result = custom_player.msg("Custom player message!")
        print(f"✅ Custom player message sent: {result}")
    else:
        print("❌ Failed to create custom player")
    
    # Anonymous spy mode
    print("\n🕵️ Anonymous Spy Mode...")
    
    spy = anonymous_spy()
    if spy:
        print("✅ Entered anonymous spy mode")
        result = spy.msg("Secret message from anonymous spy!")
        print(f"✅ Spy message sent: {result}")
    else:
        print("❌ Failed to enter spy mode")
    
    # Multiple impersonations
    print("\n🎭 Multiple Impersonations...")
    
    players = [
        ("EliteWarrior", "Elite warrior reporting for duty!"),
        ("CasualGamer", "Just here for fun!"),
        ("ProPlayer", "Professional player here!"),
        ("StealthNinja", "..."),
        ("SquadLeader", "Squad leader ready for action!")
    ]
    
    for player_name, message in players:
        result = impersonate(player_name, message)
        if result:
            print(f"✅ Impersonated '{player_name}': {result}")
        else:
            print(f"❌ Failed to impersonate '{player_name}'")
    
    print("\n🎉 Impersonation example completed!")
    print("💡 Try different player names and messages!")
    print("⚠️  Note: Use responsibly and only for testing/educational purposes!")

if __name__ == "__main__":
    main()
