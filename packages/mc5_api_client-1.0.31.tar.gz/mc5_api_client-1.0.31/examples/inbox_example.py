#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : inbox_example.py
# | License  : MIT License © 2026 Chizoba
# | Brief    : MC5 inbox API example - check sent messages
# ────────────────★─────────────────────────────────

"""
MC5 API Client - Inbox API Example

This example demonstrates the inbox API functionality.
Check your sent messages and verify message delivery!

Features shown:
- Send test messages
- Check inbox for messages
- Get messages in simple format
- Connection testing
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'src'))

from mc5_api_client import send, en, fr, de, check_inbox, my_messages, test_connection

def main():
    print("🎮 MC5 API Client - Inbox API Example")
    print("=" * 45)
    
    # Test connection first
    print("\n🔗 Testing connection...")
    if test_connection():
        print("✅ Connection successful!")
    else:
        print("❌ Connection failed!")
        return
    
    # Send some test messages
    print("\n📤 Sending test messages...")
    
    test_messages = [
        ("EN", "Test message for inbox check!"),
        ("FR", "Message de test pour vérification de boîte de réception!"),
        ("DE", "Testnachricht für Posteingangsüberprüfung!")
    ]
    
    for lang, message in test_messages:
        if lang == "EN":
            result = send(message)
        elif lang == "FR":
            result = en(message)
        elif lang == "DE":
            result = de(message)
        
        if result:
            print(f"✅ {lang} message sent successfully")
        else:
            print(f"❌ Failed to send {lang} message")
    
    # Check inbox
    print("\n📧 Checking inbox...")
    
    try:
        # Get last 10 messages
        messages = check_inbox(10)
        
        if messages:
            print(f"✅ Found {len(messages)} messages in inbox")
            print("\n📋 Recent messages:")
            
            for i, msg in enumerate(messages[:5]):  # Show first 5
                sender = msg.get('sender', 'Unknown')
                body = msg.get('body', 'No content')
                time = msg.get('time', 'Unknown time')
                print(f"   {i+1}. From {sender}: {body[:50]}... at {time}")
        else:
            print("❌ No messages found in inbox")
            
    except Exception as e:
        print(f"❌ Error checking inbox: {e}")
    
    # Get messages in simple format
    print("\n📋 Getting messages in simple format...")
    
    try:
        message_count = 0
        for sender, body, time in my_messages():
            if message_count < 5:  # Show first 5
                print(f"   📨 From {sender}: {body[:40]}... at {time}")
            message_count += 1
        
        if message_count > 0:
            print(f"✅ Retrieved {message_count} messages total")
        else:
            print("❌ No messages retrieved")
            
    except Exception as e:
        print(f"❌ Error getting simple format: {e}")
    
    print("\n🎉 Inbox API example completed!")
    print("💡 Try sending more messages and checking the inbox!")

if __name__ == "__main__":
    main()
