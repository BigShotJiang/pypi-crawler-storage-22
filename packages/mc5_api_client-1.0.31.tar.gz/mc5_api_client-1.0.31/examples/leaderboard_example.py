#!/usr/bin/env python3
# ────────────[ KAKUZU ]────────────────────────────
# | Discord  : kakuzu_f0
# | Telegram : kakuzu_f0
# | File     | leaderboard_example.py
# | License  : MIT License © 2026 Kakuzu
# | Brief    | Leaderboard system example for MC5 API Client
# ────────────────★─────────────────────────────────

"""
MC5 Leaderboard System Example

This example demonstrates the leaderboard functionality for Modern Combat 5,
including viewing leaderboards, tracking ranks, and analyzing statistics.

Based on reverse-engineered API endpoints for MC5 leaderboards.
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'src'))

from mc5_api_client import (
    MC5LeaderboardSystem, get_leaderboard, get_my_rank, show_leaderboard,
    show_my_rank_context, analyze_leaderboard, get_current_event_leaderboard,
    show_current_event_leaderboard, get_my_current_event_rank, show_my_current_event_context,
    analyze_current_event
)

def main():
    print("🏆 MC5 Leaderboard System Example")
    print("=" * 45)
    
    # Example 1: Show current event leaderboard
    print("\n🏆 Example 1: Current Event Leaderboard")
    print("-" * 40)
    
    try:
        show_current_event_leaderboard(top_count=10)
    except Exception as e:
        print(f"❌ Error: {e}")
    
    # Example 2: Show your rank context
    print("\n👤 Example 2: Your Rank Context")
    print("-" * 30)
    
    try:
        show_my_current_event_context(nearby_count=5)
    except Exception as e:
        print(f"❌ Error: {e}")
    
    # Example 3: Get raw leaderboard data
    print("\n📊 Example 3: Raw Leaderboard Data")
    print("-" * 35)
    
    try:
        current_event_id = "0c646c6a-e61c-11f0-be58-b8ca3a634708"
        leaderboard_id = f"Leaderboard_{current_event_id}"
        
        leaderboard_data = get_leaderboard(leaderboard_id, limit=5)
        
        if leaderboard_data:
            print(f"📋 Leaderboard ID: {leaderboard_data.get('id')}")
            print(f"📅 Created: {leaderboard_data.get('created')}")
            print(f"👥 Total Entries: {leaderboard_data.get('total_entries')}")
            print(f"🏆 Division: {leaderboard_data.get('division')}")
            
            # Show top 3 entries
            entries = leaderboard_data.get('data', [])
            if entries:
                print(f"\n🥇 Top 3 Entries:")
                for i, entry in enumerate(entries[:3], 1):
                    rank = entry.get('rank', i)
                    name = entry.get('display_name', 'Unknown')
                    score = entry.get('score', 0)
                    clan = entry.get('_clan_name', '')
                    xp = entry.get('_xp', 0)
                    
                    print(f"   {i}. #{rank} {name}: {score} pts")
                    if clan:
                        print(f"      🏰 Clan: {clan}")
                    if xp:
                        print(f"      ⭐ XP: {xp:,}")
        else:
            print("❌ Failed to get leaderboard data")
            
    except Exception as e:
        print(f"❌ Error: {e}")
    
    # Example 4: Leaderboard analysis
    print("\n📈 Example 4: Leaderboard Analysis")
    print("-" * 35)
    
    try:
        stats = analyze_current_event(sample_size=50)
        
        if stats:
            print("📊 Current Event Statistics:")
            print(f"📋 Total Entries: {stats['total_entries']:,}")
            print(f"📊 Sample Size: {stats['sample_size']}")
            print(f"🏆 Top Score: {stats['top_score']:.1f}")
            print(f"🏰 Active Clans: {stats['clans']}")
            
            score_stats = stats.get('score_stats', {})
            print(f"\n💯 Score Statistics:")
            print(f"   📈 Average: {score_stats.get('avg', 0):.1f}")
            print(f"   📊 Median: {score_stats.get('median', 0):.1f}")
            print(f"   ⬇️ Minimum: {score_stats.get('min', 0):.1f}")
            print(f"   ⬆️ Maximum: {score_stats.get('max', 0):.1f}")
            
            xp_stats = stats.get('xp_stats')
            if xp_stats:
                print(f"\n⭐ XP Statistics:")
                print(f"   📈 Average: {xp_stats.get('avg', 0):,.0f}")
                print(f"   📊 Median: {xp_stats.get('median', 0):,.0f}")
                print(f"   ⬇️ Minimum: {xp_stats.get('min', 0):,.0f}")
                print(f"   ⬆️ Maximum: {xp_stats.get('max', 0):,.0f}")
        else:
            print("❌ Failed to analyze leaderboard")
            
    except Exception as e:
        print(f"❌ Error: {e}")
    
    # Example 5: Custom leaderboard viewing
    print("\n🎯 Example 5: Custom Leaderboard Viewing")
    print("-" * 40)
    
    try:
        # Initialize leaderboard system
        leaderboard_system = MC5LeaderboardSystem()
        
        current_event_id = "0c646c6a-e61c-11f0-be58-b8ca3a634708"
        leaderboard_id = f"Leaderboard_{current_event_id}"
        
        # Show leaderboard with clans and XP
        leaderboard_system.show_leaderboard(
            leaderboard_id, 
            top_count=5, 
            show_clans=True, 
            show_xp=True
        )
        
        # Show your rank context
        leaderboard_system.show_my_rank_context(leaderboard_id, nearby_count=3)
        
        # Analyze leaderboard
        leaderboard_system.show_leaderboard_analysis(leaderboard_id, sample_size=20)
        
    except Exception as e:
        print(f"❌ Error: {e}")
    
    # Example 6: Get your rank data
    print("\n👤 Example 6: Your Rank Data")
    print("-" * 25)
    
    try:
        my_rank_data = get_my_current_event_rank(limit=5)
        
        if my_rank_data:
            my_entry = my_rank_data.get('my_entry')
            if my_entry:
                print("🏆 Your Rank Information:")
                print(f"   🏆 Rank: #{my_entry.get('rank', 'N/A')}")
                print(f"   👤 Name: {my_entry.get('display_name', 'Unknown')}")
                print(f"   💯 Score: {my_entry.get('score', 0)} points")
                print(f"   🏰 Clan: {my_entry.get('_clan_name', 'None')}")
                print(f"   ⭐ XP: {my_entry.get('_xp', 0):,}")
                print(f"   🎨 Kill Sign: {my_entry.get('_killsig_id', 'None')}")
                print(f"   🎨 Kill Sign Color: {my_entry.get('_killsig_color', 'None')}")
                
                # Show nearby players
                nearby_entries = my_rank_data.get('data', [])
                if nearby_entries:
                    print(f"\n📍 Nearby Players:")
                    for entry in nearby_entries:
                        if entry.get('id') != my_entry.get('id'):
                            rank = entry.get('rank', 0)
                            name = entry.get('display_name', 'Unknown')
                            score = entry.get('score', 0)
                            clan = entry.get('_clan_name', '')
                            
                            # Show relative position
                            if rank < my_entry.get('rank', 0):
                                position = "▲"
                            else:
                                position = "▼"
                            
                            print(f"   {position} #{rank} {name}: {score} pts")
                            if clan:
                                print(f"      🏰 {clan}")
            else:
                print("❌ You are not on the leaderboard")
        else:
            print("❌ Failed to get your rank data")
            
    except Exception as e:
        print(f"❌ Error: {e}")
    
    # Example 7: Leaderboard system features
    print("\n⚙️ Example 7: Leaderboard System Features")
    print("-" * 45)
    
    print("🏆 Available Leaderboard Functions:")
    print("   📊 get_leaderboard(leaderboard_id, sort, offset, limit) - Get leaderboard data")
    print("   👤 get_my_rank(leaderboard_id, sort, limit) - Get your rank")
    print("   🏆 show_leaderboard(leaderboard_id, top_count) - Show formatted leaderboard")
    print("   📈 show_my_rank_context(leaderboard_id, nearby_count) - Show your rank context")
    print("   📊 analyze_leaderboard(leaderboard_id, sample_size) - Analyze statistics")
    print()
    print("🚀 Current Event Functions:")
    print("   📊 get_current_event_leaderboard(limit) - Get current event leaderboard")
    print("   🏆 show_current_event_leaderboard(top_count) - Show current event leaderboard")
    print("   👤 get_my_current_event_rank(limit) - Get your current event rank")
    print("   📈 show_my_current_event_context(nearby_count) - Show your rank context")
    print("   📊 analyze_current_event(sample_size) - Analyze current event")
    print()
    print("🔧 Advanced Features:")
    print("   🏆 MC5LeaderboardSystem - Main leaderboard class")
    print("   📊 Custom sorting (desc/asc)")
    print("   📄 Pagination support")
    print("   📈 Statistical analysis")
    print("   🏰 Clan information")
    print("   ⭐ XP tracking")
    print("   🎨 Kill sign information")
    
    print("\n🎉 Leaderboard System Example Completed!")
    print("💡 Use these functions to track MC5 leaderboards!")
    print("🏆 Monitor your rank and compete with other players!")
    print("📊 Analyze leaderboard statistics and trends!")

if __name__ == "__main__":
    main()
