#!/usr/bin/env python3
# ────────────[ KAKUZU ]────────────────────────────
# | Discord  : kakuzu_f0
# | Telegram : kakuzu_f0
# | File     | matchmaking_example.py
# | License  : MIT License © 2026 Kakuzu
# | Brief    | Matchmaking system example for MC5 API Client
# ────────────────★─────────────────────────────────

"""
MC5 Matchmaking System Example

This example demonstrates the matchmaking functionality for Modern Combat 5,
including quick play, custom game finding, and room management.

Based on reverse-engineered API endpoints for MC5 matchmaking.
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'src'))

from mc5_api_client import (
    MC5MatchmakingSystem, quick_play, find_game, get_room_info, show_room_details,
    quick_battle, quick_event_battle, quick_team_battle, quick_ctf, current_event_quick_play
)

def main():
    print("🎮 MC5 Matchmaking System Example")
    print("=" * 45)
    
    # Example 1: Quick play any game
    print("\n🚀 Example 1: Quick Play Any Game")
    print("-" * 35)
    
    try:
        room_data = quick_play(score=1844)
        
        if room_data:
            print("✅ Found a game!")
            show_room_details(room_data)
        else:
            print("❌ No game found")
            
    except Exception as e:
        print(f"❌ Error: {e}")
    
    # Example 2: Quick play for current event
    print("\n🏆 Example 2: Quick Play for Current Event")
    print("-" * 40)
    
    try:
        event_room = current_event_quick_play(score=1844)
        
        if event_room:
            print("✅ Found event game!")
            show_room_details(event_room)
        else:
            print("❌ No event game found")
            
    except Exception as e:
        print(f"❌ Error: {e}")
    
    # Example 3: Find specific game mode
    print("\n🎯 Example 3: Find Team Battle Game")
    print("-" * 35)
    
    try:
        tb_room = quick_team_battle(score=1844)
        
        if tb_room:
            print("✅ Found Team Battle game!")
            show_room_details(tb_room)
        else:
            print("❌ No Team Battle game found")
            
    except Exception as e:
        print(f"❌ Error: {e}")
    
    # Example 4: Find CTF game
    print("\n🚩 Example 4: Find CTF Game")
    print("-" * 25)
    
    try:
        ctf_room = quick_ctf(score=1844)
        
        if ctf_room:
            print("✅ Found CTF game!")
            show_room_details(ctf_room)
        else:
            print("❌ No CTF game found")
            
    except Exception as e:
        print(f"❌ Error: {e}")
    
    # Example 5: Custom game search
    print("\n🔍 Example 5: Custom Game Search")
    print("-" * 30)
    
    try:
        # Initialize matchmaking system
        matchmaking = MC5MatchmakingSystem()
        
        # Find custom battle game
        custom_room = matchmaking.find_custom_games(
            game_mode="battle",
            capacity=12,
            event_id="0c646c6a-e61c-11f0-be58-b8ca3a634708",
            customs_room=False
        )
        
        if custom_room:
            print("✅ Found custom game!")
            matchmaking.show_room_details(custom_room)
        else:
            print("❌ No custom game found")
            
    except Exception as e:
        print(f"❌ Error: {e}")
    
    # Example 6: Get room information
    print("\n📊 Example 6: Get Room Information")
    print("-" * 35)
    
    try:
        # Try to get info for a sample room ID
        sample_room_id = "26d2c79c-01d6-11f1-8d7e-b8ca3a70b8e0"
        room_info = get_room_info(sample_room_id)
        
        if room_info:
            print("✅ Room information retrieved!")
            show_room_details(room_info)
        else:
            print("❌ Could not retrieve room information")
            
    except Exception as e:
        print(f"❌ Error: {e}")
    
    # Example 7: Advanced matchmaking
    print("\n⚙️ Example 7: Advanced Matchmaking")
    print("-" * 35)
    
    try:
        matchmaking = MC5MatchmakingSystem()
        
        # Quick play with event
        event_room = matchmaking.quick_play_any(
            score=1844,
            event_id="0c646c6a-e61c-11f0-be58-b8ca3a634708"
        )
        
        if event_room:
            print("✅ Advanced matchmaking successful!")
            
            # Show detailed room information
            print(f"\n🎮 Room Details:")
            print(f"🆔 Room ID: {event_room.get('id')}")
            print(f"🎯 Game Mode: {event_room.get('_game_mode')}")
            print(f"👥 Members: {event_room.get('member_count')}/{event_room.get('capacity')}")
            print(f"🎮 Game Started: {event_room.get('game_started', False)}")
            print(f"🌐 Server: {event_room.get('lobby_host')}:{event_room.get('lobby_port')}")
            
            # Show members
            members = event_room.get('members', [])
            if members:
                print(f"\n👥 Room Members:")
                for i, member in enumerate(members, 1):
                    name = member.get('name', 'Unknown')
                    country = member.get('country', 'N/A')
                    score = member.get('matchmaking_score', 0)
                    print(f"   {i}. {name} ({country}) - Score: {score}")
        else:
            print("❌ Advanced matchmaking failed")
            
    except Exception as e:
        print(f"❌ Error: {e}")
    
    # Example 8: Matchmaking system features
    print("\n⚙️ Example 8: Matchmaking System Features")
    print("-" * 40)
    
    print("🎮 Available Matchmaking Functions:")
    print("   🚀 quick_play(score, event_id) - Quick play any game")
    print("   🔍 find_game(game_mode, capacity, event_id) - Find custom game")
    print("   📊 get_room_info(room_id) - Get room information")
    print("   📋 show_room_details(room_data) - Show formatted room details")
    print()
    print("🎯 Quick Functions:")
    print("   ⚔️ quick_battle(score) - Quick battle matchmaking")
    print("   🏆 quick_event_battle(event_id, score) - Quick event battle")
    print("   👥 quick_team_battle(score) - Quick team battle")
    print("   🚩 quick_ctf(score) - Quick CTF")
    print("   🎯 current_event_quick_play(score) - Current event quick play")
    print()
    print("🔧 Advanced Features:")
    print("   🎮 MC5MatchmakingSystem - Main matchmaking class")
    print("   📊 Room filtering by game mode, capacity, event")
    print("   🌐 Server information and connection details")
    print("   👥 Member list and matchmaking scores")
    print("   🎯 Event-specific matchmaking")
    
    print("\n🎉 Matchmaking System Example Completed!")
    print("💡 Use these functions to find and join MC5 games!")
    print("🎮 Quick play for instant action or custom search for specific games!")

if __name__ == "__main__":
    main()
