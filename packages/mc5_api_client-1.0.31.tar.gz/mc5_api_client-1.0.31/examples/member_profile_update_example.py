#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : member_profile_update_example.py
# | License  : MIT License © 2026 Chizoba
# | Brief    : Working example of member profile updates in squads
# ────────────────★─────────────────────────────────

"""
Working Member Profile Update Example - Modern Combat 5 API

This example demonstrates how to update individual member profiles within a squad.
This complements clan settings updates by allowing personal profile modifications.
"""

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'src'))

from mc5_api_client import (
    get_clan_info,
    update_member_profile,
    update_my_squad_profile
)

def member_profile_update_example():
    """Complete example of updating member profile in squad."""
    
    print("🎮 Modern Combat 5 - Member Profile Update Example")
    print("=" * 55)
    
    # Your MC5 credentials
    username = "anonymous:d2luOF92M18xNzcwMDUxNjkwXy7H33aeTVB4YZictyDq48c="
    password = "sSJKzhQ5l4vrFgov"
    
    print(f"🔵 Using credentials: {username[:30]}...")
    
    # Step 1: Auto-detect squad
    print("\n🔍 Step 1: Detecting your squad...")
    
    clan_info = get_clan_info(username, password)
    
    if not clan_info:
        print("❌ No squad found - you must be in a squad to update your profile")
        return False
    
    group_id = clan_info['clan_id']
    clan_name = clan_info['clan_name']
    
    print(f"🏰 Found squad: {clan_name}")
    print(f"🆔 Group ID: {group_id}")
    print(f"👤 Your Display Name: {clan_info.get('display_name', 'N/A')}")
    
    # Step 2: Define profile updates
    print("\n🔧 Step 2: Defining profile updates...")
    
    print("🎯 Available Profile Updates:")
    print("   🎨 _killsig_color: Kill signature color (RGB decimal)")
    print("   🎯 _killsig_id: Kill signature ID")
    print("   📊 _score: Member score (⚠️ Max: 5200 - higher may be flagged)")
    print("   ⭐ _xp: Member experience points")
    print()
    print("⚠️  IMPORTANT: Keep scores at or below 5200 to avoid detection!")
    print()
    
    profile_updates = {
        "_killsig_color": "16711680",  # Red color
        "_killsig_id": "default_killsig_99",  # Different kill signature
        "_score": "5000",  # Safe score (below 5200 limit)
        "_xp": "25000000"  # New XP
    }
    
    print("📝 Profile updates to apply:")
    for key, value in profile_updates.items():
        print(f"   {key}: {value}")
    
    # Step 3: Update member profile using direct method
    print(f"\n🚀 Step 3: Updating member profile...")
    
    success, result = update_member_profile(group_id, username, profile_updates, username, password)
    
    if success:
        print("✅ Member profile updated successfully!")
        print(f"📄 Response: {result[:200]}...")
    else:
        print(f"❌ Profile update failed: {result}")
        return False
    
    # Step 4: Demonstrate the convenience method
    print(f"\n🔄 Step 4: Testing convenience method...")
    
    # Different updates for the convenience method
    convenience_updates = {
        "_killsig_color": "255",  # Blue color
        "_killsig_id": "default_killsig_42",  # Another kill signature
        "_score": "5100",  # Safe score (below 5200 limit)
        "_xp": "30000000"  # Even more XP
    }
    
    print("📝 Convenience method updates:")
    for key, value in convenience_updates.items():
        print(f"   {key}: {value}")
    
    convenience_success = update_my_squad_profile(username, password, convenience_updates)
    
    if convenience_success:
        print("✅ Convenience method also successful!")
    else:
        print("❌ Convenience method failed")
    
    print("\n🎉 Member profile update workflow completed!")
    return True

def quick_profile_update():
    """Quick member profile update with predefined values."""
    
    print("⚡ Quick Profile Update")
    print("=" * 30)
    
    username = "anonymous:d2luOF92M18xNzcwMDUxNjkwXy7H33aeTVB4YZictyDq48c="
    password = "sSJKzhQ5l4vrFgov"
    
    # Predefined profile updates
    quick_updates = {
        "_killsig_color": "16777215",  # White color
        "_killsig_id": "default_killsig_42",  # Default kill signature
        "_score": "5200",  # Maximum safe score
        "_xp": "18888888"  # Lucky XP
    }
    
    print(f" Applying quick profile updates: {quick_updates}")
    
    # Use the convenience method
    success = update_my_squad_profile(username, password, quick_updates)
    
    return success

def demonstrate_color_codes():
    """Demonstrate different color codes for kill signatures."""
    
    print("\n🎨 Kill Signature Color Codes Reference")
    print("=" * 45)
    
    colors = {
        "White": "16777215",
        "Black": "0", 
        "Red": "16711680",
        "Green": "65280",
        "Blue": "255",
        "Yellow": "16776960",
        "Purple": "16711808",
        "Orange": "16753920",
        "Pink": "16761035",
        "Cyan": "65535"
    }
    
    print("🎨 Available Colors:")
    for color_name, color_code in colors.items():
        print(f"   {color_name:12}: {color_code} (0x{int(color_code):06X})")
    
    print("\n💡 Usage Example:")
    print('   profile_updates = {"_killsig_color": "16711680"}  # Red')
    print('   profile_updates = {"_killsig_color": "255"}        # Blue')

def main():
    """Run all member profile update examples."""
    
    print("🎮 Modern Combat 5 - Member Profile Update Examples")
    print("=" * 55)
    print("This example demonstrates member profile updates within squads.")
    print("This updates YOUR profile, not the squad settings.")
    print()
    
    # Show color reference
    demonstrate_color_codes()
    
    # Choose update method
    print("\nChoose update method:")
    print("1. Complete workflow with custom values")
    print("2. Quick update with predefined values")
    
    choice = input("\nEnter choice (1-2): ").strip()
    
    if choice == "1":
        member_profile_update_example()
    elif choice == "2":
        quick_profile_update()
    else:
        print("❌ Invalid choice!")
    
    print("\n🎮 Example completed! Check your profile in-game to see the changes.")
    print("💡 Note: Profile updates may take a few moments to appear in-game.")

if __name__ == "__main__":
    main()
