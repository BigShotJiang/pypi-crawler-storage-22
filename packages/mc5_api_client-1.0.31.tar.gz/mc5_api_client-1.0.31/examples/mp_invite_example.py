#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : mp_invite_example.py
# | License  : MIT License © 2026 Chizoba
# | Brief    | MP Invite system example for MC5 API Client
# ────────────────★─────────────────────────────────

"""
MC5 MP Invite System Example

This example demonstrates the MP Invite functionality for Modern Combat 5,
allowing users to create and share game invitations in global chat and squad chat.

Based on reverse-engineered API endpoints for MP Invite messages.

Features shown:
- Creating MP Invites for different game modes
- Support for all maps and custom settings
- Global chat and squad chat invitations
- VIP mode with password protection
- Quick invite functions for common scenarios
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'src'))

from mc5_api_client import (
    MC5MPInviteSystem, create_team_battle_invite, create_ctf_invite,
    create_zone_control_invite, create_vip_invite, create_duel_invite,
    send_global_invite, send_squad_invite, quick_team_battle_streets,
    quick_ctf_rooftops, quick_vip_rooftops, quick_duel_showdown,
    quick_zone_control_canals, list_game_modes, list_maps, show_invite_example
)

def main():
    print("🎮 MC5 MP Invite System Example")
    print("=" * 40)
    
    # Example 1: Show available game modes and maps
    print("\n🎮 Example 1: Available Game Modes and Maps")
    print("-" * 45)
    
    print("🎮 Game Modes:")
    list_game_modes()
    
    print("\n🗺️ Maps:")
    list_maps()
    
    # Example 2: Create different types of MP Invites
    print("\n📋 Example 2: Creating MP Invites")
    print("-" * 35)
    
    system = MC5MPInviteSystem()
    
    # Team Battle invite
    print("🏗️ Creating Team Battle invite...")
    tb_invite = create_team_battle_invite(map_index=0, max_players=12)
    print(f"   Game Mode: {tb_invite['game_mode']}")
    print(f"   Map: {tb_invite['map_name']}")
    print(f"   Max Players: {tb_invite['max_players']}")
    print(f"   Room ID: {tb_invite['room_data']['roomId']}")
    
    # CTF invite
    print("\n🚩 Creating CTF invite...")
    ctf_invite = create_ctf_invite(map_index=1, max_players=12)
    print(f"   Game Mode: {ctf_invite['game_mode']}")
    print(f"   Map: {ctf_invite['map_name']}")
    print(f"   Max Players: {ctf_invite['max_players']}")
    
    # VIP invite with password
    print("\n💎 Creating VIP invite...")
    vip_invite = create_vip_invite(password="1111", map_index=1)
    print(f"   Game Mode: {vip_invite['game_mode']}")
    print(f"   Map: {vip_invite['map_name']}")
    print(f"   Max Players: {vip_invite['max_players']}")
    print(f"   Password: 1111")
    
    # Duel invite
    print("\n⚔️ Creating Duel invite...")
    duel_invite = create_duel_invite(map_name='showdown')
    print(f"   Game Mode: {duel_invite['game_mode']}")
    print(f"   Map: {duel_invite['map_name']}")
    print(f"   Max Players: {duel_invite['max_players']}")
    
    # Example 3: Custom MP Invites with specific attributes
    print("\n⚙️ Example 3: Custom MP Invites")
    print("-" * 35)
    
    # Custom Zone Control with specific settings
    print("🎯 Creating custom Zone Control invite...")
    custom_zc = system.create_mp_invite(
        game_mode='zcm',
        map_index=3,  # Canals
        max_players=10,
        custom_attributes={
            "_fast_spawn": "false",
            "_military_support": "true",
            "_veteran": "true"
        }
    )
    print(f"   Game Mode: {custom_zc['game_mode']}")
    print(f"   Map: {custom_zc['map_name']}")
    print(f"   Custom Settings: Fast Spawn=False, Military Support=True, Veteran=True")
    
    # Example 4: Show detailed invite structure
    print("\n📊 Example 4: Detailed Invite Structure")
    print("-" * 40)
    
    show_invite_example('teambattle', 0)
    
    # Example 5: Quick Invite Functions
    print("\n⚡ Example 5: Quick Invite Functions")
    print("-" * 35)
    
    print("⚡ Quick Team Battle on Streets...")
    # Note: In real usage, this would send to global chat
    # quick_team_battle_streets()
    print("   Would send Team Battle invite to global chat")
    
    print("\n⚡ Quick CTF on Rooftops...")
    # quick_ctf_rooftops()
    print("   Would send CTF invite to global chat")
    
    print("\n⚡ Quick VIP on Rooftops...")
    # quick_vip_rooftops("1111")
    print("   Would send VIP invite with password 1111")
    
    print("\n⚡ Quick Duel on Showdown...")
    # quick_duel_showdown()
    print("   Would send Duel invite on Showdown map")
    
    print("\n⚡ Quick Zone Control on Canals...")
    # quick_zone_control_canals()
    print("   Would send Zone Control invite on Canals")
    
    # Example 6: Advanced Invite Creation
    print("\n🔧 Example 6: Advanced Invite Creation")
    print("-" * 35)
    
    # Create a tournament-style invite
    print("🏆 Creating tournament-style invite...")
    tournament_invite = system.create_mp_invite(
        game_mode='tournament',
        map_index=0,
        max_players=8,
        custom_attributes={
            "_armorTiers": "31",
            "_weaponTiers": "255",
            "_veteran": "true",
            "_fast_spawn": "true",
            "_customs_room": "true",
            "_public": "true"
        }
    )
    print(f"   Tournament Mode: {tournament_invite['game_mode']}")
    print(f"   Max Players: {tournament_invite['max_players']}")
    print(f"   Settings: Veteran, Fast Spawn, Custom Room")
    
    # Create a Free For All invite
    print("\n🆓 Creating Free For All invite...")
    ffa_invite = system.create_mp_invite(
        game_mode='ffa',
        map_index=4,  # Scramble
        max_players=16,
        custom_attributes={
            "_fast_spawn": "true",
            "_useCores": "true",
            "_useGrenades": "true"
        }
    )
    print(f"   FFA Mode: {ffa_invite['game_mode']}")
    print(f"   Map: {ffa_invite['map_name']}")
    print(f"   Max Players: {ffa_invite['max_players']}")
    
    # Example 7: Different Map Combinations
    print("\n🗺️ Example 7: Different Map Combinations")
    print("-" * 40)
    
    maps_to_test = [0, 1, 2, 3, 4, 5, 6, 7, 8]  # All regular maps
    
    for map_index in maps_to_test[:3]:  # Test first 3 maps
        map_name = system.MAPS[map_index]
        invite = system.create_mp_invite('teambattle', map_index)
        print(f"   {map_name} (Map {map_index}): Max {invite['max_players']} players")
    
    # Example 8: Invite Data Analysis
    print("\n📈 Example 8: Invite Data Analysis")
    print("-" * 30)
    
    # Create invites for all game modes and analyze
    print("📊 Creating invites for all game modes...")
    
    all_invites = []
    for game_mode in system.GAME_MODES.keys():
        try:
            if game_mode == 'duel':
                invite = create_duel_invite('showdown')
            elif game_mode == 'vip':
                invite = create_vip_invite()
            else:
                invite = system.create_mp_invite(game_mode, 0)
            
            all_invites.append({
                'mode': game_mode,
                'name': system.GAME_MODES[game_mode],
                'max_players': invite['max_players'],
                'map': invite['map_name']
            })
        except Exception as e:
            print(f"   Error creating {game_mode}: {e}")
    
    print(f"\n📊 Created {len(all_invites)} invites:")
    for invite in all_invites:
        print(f"   {invite['name']} ({invite['mode']}): {invite['max_players']} players on {invite['map']}")
    
    # Example 9: Sending Invites (Simulation)
    print("\n📤 Example 9: Sending Invites (Simulation)")
    print("-" * 40)
    
    print("📤 Simulating MP Invite sending...")
    print("💡 In real usage, these functions would send invites to chat:")
    
    # Simulate sending to global chat
    print("\n🌐 Global Chat Invites:")
    print("   quick_team_battle_streets() -> Team Battle on Streets")
    print("   quick_ctf_rooftops() -> CTF on Rooftops")
    print("   quick_duel_showdown() -> Duel on Showdown")
    
    # Simulate sending to squad chat
    print("\n🏰 Squad Chat Invites:")
    squad_id = "d1e7437c-0156-11f1-ad07-b8ca3a709038"  # Example squad ID
    print(f"   send_squad_invite('{squad_id}', 'teambattle', 0) -> Team Battle to squad")
    print(f"   send_squad_invite('{squad_id}', 'ctf', 1) -> CTF to squad")
    
    # Example 10: Best Practices
    print("\n💡 Example 10: Best Practices")
    print("-" * 30)
    
    print("💡 MP Invite Best Practices:")
    print("   🎯 Choose appropriate game mode for your audience")
    print("   🗺️ Select popular maps (Streets, Rooftops, Canals)")
    print("   👥 Set reasonable max player limits")
    print("   🔐 Use passwords for VIP/private games")
    print("   📝 Include clear descriptions in messages")
    print("   🌐 Send to appropriate chat channels")
    print("   ⏰ Time invites for peak activity periods")
    
    print("\n🎮 Popular Combinations:")
    print("   🏗️ Team Battle + Streets + 12 players")
    print("   🚩 CTF + Rooftops + 12 players")
    print("   🎯 Zone Control + Canals + 10 players")
    print("   💎 VIP + Rooftops + 16 players + password")
    print("   ⚔️ Duel + Showdown + 8 players")
    
    print("\n🎉 MP Invite System Example Completed!")
    print("💡 Use these functions to create and share game invitations!")
    print("🎮 MP Invite system makes it easy to organize games!")

if __name__ == "__main__":
    main()
