#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : room_matchmaking_example.py
# | License  : MIT License © 2026 Chizoba
# | Brief    | MC5 room and matchmaking API example
# ────────────────★─────────────────────────────────

"""
MC5 Room and Matchmaking API Example

This example demonstrates the room finding and matchmaking functionality
discovered from reverse-engineering the MC5 game client.

Features shown:
- Finding different types of rooms
- Matchmaking for various game modes
- Server type selection
- Quick join functionality
- Room filtering and analysis
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'src'))

from mc5_api_client.room_matchmaking import (
    MC5RoomAPI, find_duel_rooms, find_team_battle_rooms, 
    find_custom_rooms, quick_duel_match, quick_team_battle
)

def main():
    print("🎮 MC5 Room and Matchmaking API Example")
    print("=" * 50)
    
    # Initialize the Room API
    api = MC5RoomAPI()
    
    # Example 1: Find duel rooms
    print("\n🥋 Example 1: Finding Duel Rooms")
    print("-" * 35)
    
    duel_rooms = api.find_rooms(
        server_type="mp_server",
        game_mode="duel",
        capacity=2,
        joinable=True,
        public=True,
        limit=5
    )
    
    api.print_room_summary(duel_rooms)
    
    # Example 2: Find team battle rooms
    print("\n⚔️ Example 2: Finding Team Battle Rooms")
    print("-" * 42)
    
    team_rooms = api.find_rooms(
        server_type="mp_server",
        game_mode="teambattle",
        capacity=12,
        joinable=True,
        public=True,
        limit=5
    )
    
    api.print_room_summary(team_rooms)
    
    # Example 3: Find custom rooms (non-ranked)
    print("\n🎨 Example 3: Finding Custom Rooms (Non-Ranked)")
    print("-" * 50)
    
    custom_rooms = api.find_rooms(
        server_type="mp_server_test",  # Non-ranked servers
        customs_room=True,
        game_state="lobby",
        joinable=True,
        public=True,
        limit=5
    )
    
    api.print_room_summary(custom_rooms)
    
    # Example 4: Find all available rooms
    print("\n🌍 Example 4: Finding All Available Rooms")
    print("-" * 42)
    
    all_rooms = api.find_rooms(
        server_type="mp_server",
        joinable=True,
        public=True,
        game_started=True,
        limit=10
    )
    
    api.print_room_summary(all_rooms)
    
    # Example 5: Convenience functions
    print("\n⚡ Example 5: Using Convenience Functions")
    print("-" * 42)
    
    print("🥋 Finding duel rooms (convenience function):")
    duel_convenience = find_duel_rooms()
    api.print_room_summary(duel_convenience[:3])  # Show first 3
    
    print("\n⚔️ Finding team battle rooms (convenience function):")
    team_convenience = find_team_battle_rooms()
    api.print_room_summary(team_convenience[:3])  # Show first 3
    
    print("\n🎨 Finding custom rooms (convenience function):")
    custom_convenience = find_custom_rooms()
    api.print_room_summary(custom_convenience[:3])  # Show first 3
    
    # Example 6: Advanced filtering
    print("\n🔍 Example 6: Advanced Room Filtering")
    print("-" * 40)
    
    # Find rooms with specific criteria
    filtered_rooms = api.find_rooms(
        server_type="mp_server_test",
        game_mode="teambattle",
        game_state="lobby",
        veteran=False,
        customs_room=True,
        limit=3
    )
    
    print("🎯 Filtered rooms (Team Battle, Lobby, Non-Veteran, Custom):")
    api.print_room_summary(filtered_rooms)
    
    # Example 7: Room analysis
    print("\n📊 Example 7: Room Analysis")
    print("-" * 30)
    
    if all_rooms:
        total_rooms = len(all_rooms)
        total_players = sum(room.get('member_count', 0) for room in all_rooms)
        total_capacity = sum(room.get('capacity', 0) for room in all_rooms)
        
        game_modes = {}
        server_types = {}
        
        for room in all_rooms:
            mode = room.get('_game_mode', 'Unknown')
            server = room.get('server_type', 'Unknown')
            
            game_modes[mode] = game_modes.get(mode, 0) + 1
            server_types[server] = server_types.get(server, 0) + 1
        
        print(f"📈 Room Statistics:")
        print(f"   Total Rooms: {total_rooms}")
        print(f"   Total Players: {total_players}")
        print(f"   Total Capacity: {total_capacity}")
        print(f"   Fill Rate: {(total_players/total_capacity*100):.1f}%" if total_capacity > 0 else "   Fill Rate: N/A")
        
        print(f"\n🎯 Game Modes:")
        for mode, count in game_modes.items():
            print(f"   {mode}: {count} rooms")
        
        print(f"\n🖥️ Server Types:")
        for server, count in server_types.items():
            print(f"   {server}: {count} rooms")
    
    # Example 8: Matchmaking (requires access token)
    print("\n🎯 Example 8: Matchmaking (Requires Access Token)")
    print("-" * 50)
    
    print("💡 To use matchmaking, you need a valid access token")
    print("💡 Example usage (uncomment to use with real token):")
    print("""
    # Quick duel match
    duel_result = quick_duel_match(
        access_token="your_access_token_here",
        score=1500,
        user_name="YourName"
    )
    
    # Quick team battle
    team_result = quick_team_battle(
        access_token="your_access_token_here", 
        score=1200,
        user_name="YourName"
    )
    """)
    
    print("\n🎉 Room and Matchmaking Example Completed!")
    print("💡 Try different filters and game modes!")
    print("🔑 Note: Matchmaking requires valid access tokens")

if __name__ == "__main__":
    main()
