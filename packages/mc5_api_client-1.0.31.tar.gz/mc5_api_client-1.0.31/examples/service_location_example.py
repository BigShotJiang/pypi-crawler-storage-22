#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : service_location_example.py
# | License  | MIT License © 2026 Chizoba
# | Brief    | Example of service location functionality
# ────────────────★─────────────────────────────────

"""
Service Location Example
======================

This example demonstrates how to use the new service location functionality.
Shows how to locate MC5 services, check connection status, and find rooms.

Setup:
1. Set your MC5 credentials as environment variables:
   export MC5_USERNAME="your_credential"
   export MC5_PASSWORD="your_password"

2. Or edit the credentials directly in the script

3. Run the example:
   python service_location_example.py
"""

import os
from mc5_api_client import locate_service, get_all_services, create_federation_session

def main():
    """Demonstrate service location functionality."""
    print("🌐 MC5 Service Location Example")
    print("=" * 40)
    
    # === Method 1: Locate Individual Services ===
    print("🔍 Method 1: Locate Individual Services")
    print("-" * 40)
    
    services = ["leaderboard", "matchmaker", "auth", "social", "alert", "message", "lobby", "gs", "sp"]
    
    for service in services:
        endpoint = locate_service(service)
        if endpoint:
            print(f"✅ {service:12}: {endpoint}")
        else:
            print(f"❌ {service:12}: Not found")
    
    print()
    
    # === Method 2: Get All Services ===
    print("📊 Method 2: Get All Services")
    print("-" * 30)
    
    all_services = get_all_services()
    print(f"✅ Found {len(all_services)} services:")
    
    for service, endpoint in all_services.items():
        print(f"   {service:12}: {endpoint}")
    
    print()
    
    # === Method 3: Service Information ===
    print("ℹ️ Method 3: Service Information")
    print("-" * 35)
    
    service_info = {
        "leaderboard": {
            "description": "Player rankings and scores",
            "endpoint": all_services.get("leaderboard", "Not found"),
            "protocol": "HTTPS",
            "purpose": "Leaderboard data"
        },
        "matchmaker": {
            "description": "Game matchmaking service",
            "endpoint": all_services.get("matchmaker", "Not found"),
            "protocol": "HTTPS",
            "purpose": "Find game matches"
        },
        "auth": {
            "description": "Authentication service",
            "endpoint": all_services.get("auth", "Not found"),
            "protocol": "HTTPS",
            "purpose": "User authentication"
        },
        "social": {
            "description": "Social features service",
            "endpoint": all_services.get("social", "Not found"),
            "protocol": "HTTPS",
            "purpose": "Friends, clans, messaging"
        },
        "alert": {
            "description": "Alert notifications service",
            "endpoint": all_services.get("alert", "Not found"),
            "protocol": "HTTPS",
            "purpose": "Game alerts and notifications"
        },
        "message": {
            "description": "Messaging service",
            "endpoint": all_services.get("message", "Not found"),
            "protocol": "HTTPS",
            "purpose": "Private messages"
        },
        "lobby": {
            "description": "Lobby service",
            "endpoint": all_services.get("lobby", "Not found"),
            "protocol": "HTTPS",
            "purpose": "Game lobby management"
        }
    }
    
    for service, info in service_info.items():
        endpoint = info["endpoint"]
        if endpoint != "Not found":
            print(f"🔧 {service.upper()}")
            print(f"   Description: {info['description']}")
            print(f"   Endpoint: {endpoint}")
            print(f"   Protocol: {info['protocol']}")
            print(f"   Purpose: {info['purpose']}")
            print()
    
    # === Method 4: Federation Session with Service Info ===
    print("🎮 Method 4: Federation Session with Service Info")
    print("-" * 50)
    
    username = os.getenv('MC5_USERNAME')
    password = os.getenv('MC5_PASSWORD')
    
    if username and password:
        print(f"🔑 Using credentials: {username[:30]}...")
        
        # Create federation session
        session = create_federation_session(username, password)
        
        if session.get("success"):
            print("✅ Federation session created!")
            print(f"   Room ID: {session.get('room_id')}")
            print(f"   Controller: {session.get('controller_host')}")
            
            # Show related services
            print("\n🔗 Related Services:")
            auth_endpoint = all_services.get("auth", "Not found")
            print(f"   Auth Service: {auth_endpoint}")
            
            matchmaker_endpoint = all_services.get("matchmaker", "Not found")
            print(f"   Matchmaker: {matchmaker_endpoint}")
            
            lobby_endpoint = all_services.get("lobby", "Not found")
            print(f"   Lobby: {lobby_endpoint}")
            
        else:
            print(f"❌ Federation session failed: {session}")
    else:
        print("⚠️ No credentials found - skipping federation session")
    
    print()
    print("🎉 Service location example completed!")
    print("💡 Tips:")
    print("   - Service endpoints can change dynamically")
    print("   - Use locate_service() for real-time endpoint discovery")
    print("   - Use get_all_services() for complete service mapping")
    print("   - Federation sessions work with these service endpoints")
    print("   - Different services handle different game aspects")
    
    print()
    print("🔗 Service Location Information:")
    print("   - Base URL: https://vgold-eur.gameloft.com/")
    print("   - Path: /1875:55979:6.0.0a:windows:windows/locate")
    print("   - Method: GET")
    print("   - Parameters: service, client_id")
    print("   - Response: Plain text endpoint")

def demo_service_discovery():
    """Demonstrate advanced service discovery."""
    print("\n🔍 Advanced Service Discovery Demo")
    print("=" * 40)
    
    # Test service availability
    print("🔍 Testing Service Availability:")
    
    critical_services = ["auth", "matchmaker", "leaderboard"]
    available_services = []
    unavailable_services = []
    
    for service in critical_services:
        endpoint = locate_service(service)
        if endpoint:
            available_services.append(service)
            print(f"✅ {service}: Available ({endpoint})")
        else:
            unavailable_services.append(service)
            print(f"❌ {service}: Unavailable")
    
    print(f"\n📊 Service Status Summary:")
    print(f"   Available: {len(available_services)}/{len(critical_services)}")
    print(f"   Unavailable: {len(unavailable_services)}")
    
    if unavailable_services:
        print(f"   Missing services: {', '.join(unavailable_services)}")
    
    # Service endpoint analysis
    print("\n🌐 Service Endpoint Analysis:")
    all_services = get_all_services()
    
    domains = {}
    for service, endpoint in all_services.items():
        if endpoint:
            domain = endpoint.split(':')[0]
            if domain not in domains:
                domains[domain] = []
            domains[domain].append(service)
    
    for domain, services in domains.items():
        print(f"   {domain}: {', '.join(services)}")
    
    # Port analysis
    print("\n🔌 Port Analysis:")
    ports = {}
    for service, endpoint in all_services.items():
        if endpoint and ':' in endpoint:
            port = endpoint.split(':')[1]
            if port not in ports:
                ports[port] = []
            ports[port].append(service)
    
    for port, services in ports.items():
        print(f"   Port {port}: {', '.join(services)}")

def demo_service_integration():
    """Demonstrate service integration with other features."""
    print("\n🔗 Service Integration Demo")
    print("=" * 35)
    
    username = os.getenv('MC5_USERNAME')
    password = os.getenv('MC5_PASSWORD')
    
    if not username or not password:
        print("⚠️ Set MC5_USERNAME and MC5_PASSWORD to test integration")
        return
    
    try:
        from mc5_api_client import MC5Easy
        
        with MC5Easy(username, password) as mc5:
            print("🔗 Testing service integration...")
            
            # Get global ID
            global_id = mc5.get_global_id()
            print(f"🌐 Global ID: {global_id}")
            
            # Get all services
            all_services = get_all_services()
            print(f"📊 Available Services: {len(all_services)}")
            
            # Show how services relate to game features
            print("\n🎮 Service Integration:")
            print("   🏆 Leaderboard Service → Player rankings")
            print("   🎯 Matchmaker Service → Game matching")
            print("   🔐 Auth Service → User authentication")
            print("   👥 Social Service → Friends and clans")
            print("   🔔 Alert Service → Game notifications")
            print("   💬 Message Service → Private messages")
            print("   🏛️ Lobby Service → Game lobby management")
            
            # Show federation session integration
            print("\n🎮 Federation Session Integration:")
            session = mc5.create_federation_session()
            
            if session.get("success"):
                print(f"   ✅ Session created: {session.get('room_id')}")
                print(f"   🌐 Controller: {session.get('controller_host')}")
                print(f"   🔗 Uses auth service for authentication")
                print(f"   🎯 Uses matchmaker for game finding")
                print(f"   🏛️ Uses lobby for room management")
            
    except Exception as e:
        print(f"❌ Integration test failed: {e}")

if __name__ == "__main__":
    main()
    demo_service_discovery()
    demo_service_integration()
