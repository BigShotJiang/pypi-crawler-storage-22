#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : squad_customization_quick.py
# | License  | MIT License © 2026 Chizoba
# | Brief    | Quick squad customization examples
# ────────────────★─────────────────────────────────

"""
Quick Squad Customization Examples for MC5 API Client

This shows the most common squad customization tasks in a simple, easy-to-understand way.
"""

from mc5_api_client import MC5Client

def main():
    """Quick squad customization demo."""
    print("🎮 MC5 API Client - Quick Squad Customization")
    print("=" * 50)
    print("🚀 Easy squad customization examples!")
    print()
    
    # Initialize client
    client = MC5Client(
        client_id="1875:55979:6.0.0a:windows:windows",
        username="anonymous:d2luOF92M18xNzcwMDUxNjkwXy7H33aeTVB4YZictyDq48c=",
        password="sSJKzhQ5l4vrFgov"
    )
    
    print("✅ Client initialized!")
    
    # Example 1: Set squad to Level 8
    print("\n🎯 Example 1: Set Squad to Level 8")
    print("-" * 35)
    
    result = client.set_squad_level(8, "Level 8 Elite")
    if result and 'error' not in result:
        print("✅ Level 8 set successfully!")
    else:
        print(f"❌ Failed: {result}")
    
    # Example 2: Apply Fire Theme
    print("\n🔥 Example 2: Apply Fire Theme")
    print("-" * 30)
    
    result = client.customize_squad_theme('fire', 'Fire Warriors')
    if result and 'error' not in result:
        print("✅ Fire theme applied!")
    else:
        print(f"❌ Failed: {result}")
    
    # Example 3: Quick customization
    print("\n⚡ Example 3: Quick Customization")
    print("-" * 30)
    
    result = client.customize_squad_complete(
        name="452e55e84897+",
        rating=5000,
        member_limit=100
    )
    if result and 'error' not in result:
        print("✅ Quick customization done!")
    else:
        print(f"❌ Failed: {result}")
    
    print("\n" + "=" * 50)
    print("🎉 Quick Demo Complete!")
    print("=" * 50)
    print()
    print("💡 Available helper functions:")
    print("   🎯 set_squad_level(level, name)")
    print("   🎨 customize_squad_theme(theme, name)")
    print("   🔧 customize_squad_complete(**kwargs)")
    print()
    print("🚀 All functions work automatically - no manual IDs needed!")

if __name__ == "__main__":
    main()
