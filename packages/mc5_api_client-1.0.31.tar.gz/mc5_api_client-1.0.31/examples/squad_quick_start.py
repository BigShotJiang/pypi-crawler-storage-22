#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : squad_quick_start.py
# | License  | MIT License © 2026 Chizoba
# | Brief    | Super simple squad customization
# ────────────────★─────────────────────────────────

"""
Super Simple Squad Customization - Quick Start Guide

This shows the easiest ways to customize your squad.
Perfect for beginners!
"""

from mc5_api_client import MC5Client

def main():
    """Super simple squad customization."""
    print("🎮 MC5 API Client - Squad Quick Start")
    print("=" * 40)
    print("🚀 Easiest squad customization ever!")
    print()
    
    # Initialize client
    client = MC5Client(
        client_id="1875:55979:6.0.0a:windows:windows",
        username="anonymous:d2luOF92M18xNzcwMDUxNjkwXy7H33aeTVB4YZictyDq48c=",
        password="sSJKzhQ5l4vrFgov"
    )
    
    print("✅ Client ready!")
    
    # Most common customizations
    print("\n🎯 Most Common Customizations:")
    print("-" * 30)
    
    # 1. Change name
    print("1. Change squad name:")
    result = client.quick_set_name("My Awesome Squad")
    print(f"   ✅ {'Success!' if 'error' not in result else 'Failed'}")
    
    # 2. Set level
    print("\n2. Set to Level 5:")
    result = client.quick_set_level(5)
    print(f"   ✅ {'Success!' if 'error' not in result else 'Failed'}")
    
    # 3. Set colors
    print("\n3. Set colors (Red and White):")
    result = client.quick_set_colors("red", "white")
    print(f"   ✅ {'Success!' if 'error' not in result else 'Failed'}")
    
    # 4. Set member limit
    print("\n4. Set member limit to 50:")
    result = client.quick_set_member_limit(50)
    print(f"   ✅ {'Success!' if 'error' not in result else 'Failed'}")
    
    # 5. Set currency
    print("\n5. Set currency to 10000:")
    result = client.quick_set_currency(10000)
    print(f"   ✅ {'Success!' if 'error' not in result else 'Failed'}")
    
    # Quick setups
    print("\n🚀 Quick Setups:")
    print("-" * 20)
    
    # Professional squad
    print("6. Professional squad setup:")
    result = client.quick_setup_professional_squad("Elite Squad", level=8)
    print(f"   ✅ {'Success!' if 'error' not in result else 'Failed'}")
    
    # Gaming squad
    print("\n7. Gaming squad setup:")
    result = client.quick_setup_gaming_squad("Gaming Legends", "fire")
    print(f"   ✅ {'Success!' if 'error' not in result else 'Failed'}")
    
    print("\n" + "=" * 40)
    print("🎉 Quick Start Complete!")
    print("=" * 40)
    print()
    print("💡 Quick functions available:")
    print("   📝 quick_set_name(name)")
    print("   ⭐ quick_set_level(level)")
    print("   🎨 quick_set_colors(primary, secondary)")
    print("   👥 quick_set_member_limit(limit)")
    print("   💰 quick_set_currency(amount)")
    print("   🏆 quick_setup_professional_squad(name, level)")
    print("   🎮 quick_setup_gaming_squad(name, theme)")
    print("   🔄 quick_reset_to_defaults()")
    print()
    print("🚀 All functions work automatically - no manual IDs needed!")

if __name__ == "__main__":
    main()
