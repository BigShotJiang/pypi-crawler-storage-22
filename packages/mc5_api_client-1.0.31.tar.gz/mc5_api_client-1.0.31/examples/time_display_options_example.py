#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : time_display_options_example.py
# | License  : MIT License © 2026 Chizoba
# | Brief    : Example demonstrating time display options
# ────────────────★─────────────────────────────────

"""
Time Display Options Example

This example demonstrates the new time display options for find_player():
- "sp" - Show only single player time
- "mp" - Show only multiplayer time  
- "combined" - Show combined SP + MP time (default)
- "none" - Show no time information

Usage:
    python time_display_options_example.py
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from mc5_api_client import find_player, format_time_combined

def print_player_summary(result: dict):
    """Print a concise player summary with time display."""
    
    if not result['success']:
        print(f"❌ Error: {result['error']}")
        return
    
    player = result['player_info']
    
    print(f"👤 {player['display_name']} ({player['clan_info']['clan_name']})")
    print(f"💎 VIP: {player['vip_points']:,} | 📊 XP: {player['xp']:,}")
    print(f"⭐ Rating: {player['rating']} | 🏆 Clan: {player['clan_info']['clan_name']}")
    
    # Time display
    time_display = player.get('time_played')
    time_option = player.get('time_display_option', 'unknown')
    if time_display:
        print(f"⏰ Time ({time_option}): {time_display}")
    else:
        print(f"⏰ Time: Not displayed")
    
    # Dogtag search if applicable
    dogtag_info = result.get('dogtag_search', {})
    if dogtag_info.get('searched_id'):
        print(f"🏷️ Dogtag '{dogtag_info['searched_id']}': {len(dogtag_info['results'])} results")

def demonstrate_time_options():
    """Demonstrate all time display options."""
    
    print("🎮 MC5 API Client - Time Display Options")
    print("=" * 50)
    print("Demonstrating flexible time display options")
    print()
    
    # Test all time display options
    time_options = [
        ("combined", "Default: Combined SP + MP time"),
        ("sp", "Single Player time only"),
        ("mp", "Multiplayer time only"),
        ("none", "No time display")
    ]
    
    for option, description in time_options:
        print(f"\n{'='*60}")
        print(f"🕐 {description}")
        print(f"🔧 find_player(time_display='{option}')")
        print(f"{'='*60}")
        
        result = find_player(time_display=option)
        print_player_summary(result)
        
        # Show time breakdown for context
        if result['success']:
            time_breakdown = result['player_info']['statistics'].get('time_breakdown', {})
            print(f"\n📊 Time Breakdown:")
            print(f"   🎮 MP: {time_breakdown.get('mp_time_formatted', '0s')}")
            print(f"   🎯 SP: {time_breakdown.get('sp_time_formatted', '0s')}")
            print(f"   🔄 Total: {time_breakdown.get('combined_time', '0s')}")
        
        print(f"\n✅ Option '{option}' working correctly")

def demonstrate_with_dogtag():
    """Demonstrate time options with dogtag search."""
    
    print(f"\n{'='*60}")
    print("🏷️ Time Options with Dogtag Search")
    print(f"🔧 find_player(dogtag_id='f55f', time_display='combined')")
    print(f"{'='*60}")
    
    result = find_player(dogtag_id="f55f", time_display="combined")
    print_player_summary(result)
    
    if result['success']:
        dogtag_info = result['dogtag_search']
        print(f"\n🏷️ Dogtag Search Results:")
        print(f"   🔍 Searched: '{dogtag_info['searched_id']}'")
        print(f"   📋 Results: {len(dogtag_info['results'])} found")
        print(f"   📦 Collection: {dogtag_info['collection_size']} items")
        
        if dogtag_info['results']:
            print(f"   ✅ Found in:")
            for i, dt_result in enumerate(dogtag_info['results'][:3], 1):
                print(f"      {i}. {dt_result['location']}")
        else:
            print(f"   ❌ Dogtag not found in current player data")

def demonstrate_format_time_function():
    """Demonstrate the format_time_combined function directly."""
    
    print(f"\n{'='*60}")
    print("⏰ Direct Time Formatting")
    print(f"🔧 format_time_combined(sp_seconds, mp_seconds)")
    print(f"{'='*60}")
    
    # Sample data scenarios
    scenarios = [
        (32467, 517534, "Sample data from JSON"),
        (7200, 108000, "Casual player"),
        (3600, 3600, "Balanced player"),
        (0, 7200, "MP-only player"),
        (10800, 0, "SP-only player"),
        (0, 0, "New player"),
        (654321, 987654, "Heavy player")
    ]
    
    for sp_time, mp_time, description in scenarios:
        combined = format_time_combined(sp_time, mp_time)
        print(f"📋 {description}")
        print(f"   🎯 SP: {sp_time:,}s ({format_time_combined(sp_time, 0)})")
        print(f"   🎮 MP: {mp_time:,}s ({format_time_combined(0, mp_time)})")
        print(f"   🔄 Combined: {combined}")
        print()

def demonstrate_edge_cases():
    """Demonstrate edge cases and special scenarios."""
    
    print(f"{'='*60}")
    print("🧪 Edge Cases and Special Scenarios")
    print(f"{'='*60}")
    
    # Edge cases with sample data
    test_scenarios = [
        ("combined", "Zero gameplay time", 0, 0),
        ("sp", "Only SP time (1 hour)", 3600, 0),
        ("mp", "Only MP time (2 hours)", 0, 7200),
        ("combined", "Small time values", 65, 125),
        ("none", "No time display", 0, 0),
        ("combined", "Large time values", 654321, 987654)
    ]
    
    for option, description, sp_time, mp_time in test_scenarios:
        print(f"📋 {description}")
        print(f"🔧 find_player(time_display='{option}')")
        
        # Create mock result for demonstration
        mock_result = {
            'success': True,
            'player_info': {
                'display_name': 'Demo Player',
                'clan_info': {'clan_name': 'Demo Clan'},
                'vip_points': 10000,
                'xp': 50000,
                'rating': 1500,
                'time_played': format_time_combined(sp_time, mp_time) if option != 'none' else None,
                'time_display_option': option
            },
            'dogtag_search': {'searched_id': None, 'results': []}
        }
        
        print_player_summary(mock_result)
        print(f"   📊 Sample data: SP={sp_time}s, MP={mp_time}s")
        print(f"✅ Option '{option}' handled correctly\n")

def main():
    """Run all time display demonstrations."""
    
    print("🎮 MC5 API Client - Time Display Options Example")
    print("=" * 60)
    print("Comprehensive demonstration of flexible time display options")
    print()
    
    # Run demonstrations
    demonstrate_time_options()
    demonstrate_with_dogtag()
    demonstrate_format_time_function()
    demonstrate_edge_cases()
    
    print("🎉 Time Display Options Example Complete!")
    print("=" * 50)
    print("✅ All time display options working perfectly")
    print("✅ 'sp' - Single player time only")
    print("✅ 'mp' - Multiplayer time only")
    print("✅ 'combined' - Combined SP + MP time (default)")
    print("✅ 'none' - No time display")
    print("✅ Edge cases handled properly")
    print("✅ Dogtag search integration working")
    print("✅ Direct time formatting available")
    print()
    print("📋 Quick Reference:")
    print("   find_player()                           # Combined time")
    print("   find_player(time_display='sp')             # SP time only")
    print("   find_player(time_display='mp')             # MP time only")
    print("   find_player(time_display='combined')      # Combined time")
    print("   find_player(time_display='none')            # No time")
    print("   format_time_combined(sp, mp)               # Direct formatting")
    print()
    print("🚀 Ready for production use!")

if __name__ == "__main__":
    main()
