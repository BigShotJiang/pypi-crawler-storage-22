#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : working_clan_update_example.py
# | License  : MIT License © 2026 Chizoba
# | Brief    : Working example of clan update with automatic detection
# ────────────────★─────────────────────────────────

"""
Working Clan Update Example - Modern Combat 5 API

This example demonstrates the complete working solution for:
1. Automatic clan detection using get_batch_profiles
2. Clan information retrieval
3. Successful clan updates (name, description, rating, currency)

This is the PROVEN working method that successfully updates clan information.
"""

import sys
import os
import time
import requests

# Add local source to path for development
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'src'))

from mc5_api_client import MC5Client

def working_clan_update_example():
    """Complete working example of clan update with automatic detection."""
    
    print("🎮 Modern Combat 5 - Working Clan Update Example")
    print("=" * 55)
    
    # Your MC5 credentials
    username = "anonymous:d2luOF92M18xNzcwMDUxNjkwXy7H33aeTVB4YZictyDq48c="
    password = "sSJKzhQ5l4vrFgov"
    
    print(f"🔵 Using credentials: {username[:30]}...")
    
    # Step 1: Get clan information automatically
    print("\n🔍 Step 1: Detecting clan information...")
    
    url = "https://app-468561b3-9ecd-4d21-8241-30ed288f4d8b.gold0009.gameloft.com/1875/windows/09/public/OfficialScripts/mc5Portal.wsgi"
    
    data = {
        'op_code': 'get_batch_profiles',
        'client_id': '1875:55979:6.0.0a:windows:windows',
        'credentials': username,
        'pandora': 'https://vgold-eur.gameloft.com/1875:55979:6.0.0a:windows:windows',
        'include_fields': '_game_save,inventory'
    }
    
    print("🔵 Fetching clan data...")
    response = requests.post(url, data=data, timeout=30)
    
    if response.status_code != 200:
        print(f"🔴 Failed to get clan info: {response.status_code}")
        return False
    
    result = response.json()
    
    if username not in result:
        print("🔴 User credential not found in response")
        return False
    
    user_data = result[username]
    
    if '_game_save' not in user_data or 'osiris_info' not in user_data['_game_save']:
        print("🔴 No clan information found - user may not be in a clan")
        return False
    
    clan_info = user_data['_game_save']['osiris_info']
    clan_id = clan_info.get('clan_id')
    clan_name = clan_info.get('clan_name', 'Unknown')
    
    print(f"🏰 Found clan: {clan_name}")
    print(f"🆔 Clan ID: {clan_id}")
    print(f"👤 Display Name: {clan_info.get('display_name', 'N/A')}")
    
    # Step 2: Show current clan information
    print("\n📋 Step 2: Current clan information...")
    
    client = MC5Client(
        client_id="1875:55979:6.0.0a:windows:windows",
        username=username,
        password=password
    )
    
    current_squad = client.get_squad_info(clan_id)
    if 'error' not in current_squad:
        print("📊 Current Settings:")
        print(f"   Name: {current_squad.get('name', 'N/A')}")
        print(f"   Description: {current_squad.get('description', 'N/A')}")
        print(f"   Rating: {current_squad.get('rating', 'N/A')}")
        print(f"   Currency: {current_squad.get('currency', 'N/A')}")
        print(f"   Member Limit: {current_squad.get('member_limit', 'N/A')}")
        print(f"   Membership: {current_squad.get('membership', 'N/A')}")
    else:
        print(f"🔴 Error getting current squad info: {current_squad.get('error', 'Unknown')}")
        return False
    
    # Step 3: Define updates
    print("\n🔧 Step 3: Defining clan updates...")
    
    # IMPORTANT: Squad Membership Settings
    print("🎯 Squad Membership Options:")
    print("   🔓 Open: membership='open', _min_join_value=500 (any value)")
    print("   👥 Invitation Only: membership='member_approved', _min_join_value=999699 (fixed)")
    print("   🔒 Request Only: membership='owner_approved', _min_join_value=996699 (fixed)")
    print("   ⚠️  Rating cannot be 999699 or 996699 (reserved for membership types)")
    print()
    
    updates = {
        "name": "Elite Warriors MC5",
        "description": "Join us for epic battles and victories! 🎮",
        "_rating": 7500,
        "currency": "50000",
        "member_limit": 50,
        "membership": "owner_approved",  # Request only - leader must approve
        "_min_join_value": 996699       # ALWAYS 996699 for owner_approved
    }
    
    print("📝 Updates to apply:")
    for key, value in updates.items():
        print(f"   {key}: {value}")
    
    print(f"\n🔍 Note: Using 'owner_approved' membership with _min_join_value=996699")
    print("   This means players can request to join, but only leader can approve.")
    
    # Step 4: Perform the update
    print(f"\n🚀 Step 4: Updating clan {clan_name}...")
    
    # Use the exact working client initialization
    client = MC5Client(
        client_id="1875:55979:6.0.0a:windows:windows",
        username=username,
        password=password
    )
    
    # Extract token data
    access_token = client._token_data.get('access_token')
    token_parts = access_token.split(',')
    
    # Construct fed_id from token parts
    timestamp = token_parts[3]
    credential_short = token_parts[4].split(':')[1][:16] if ':' in token_parts[4] else token_parts[4][:16]
    fed_id = f"fed_id:{timestamp[:8]}-{timestamp[8:12]}-{timestamp[12:16]}-{credential_short[:12]}"
    
    # Build payload according to API documentation
    payload = {
        "access_token": access_token,
        "_anonId": username,
        "_fedId": fed_id,
        "timestamp": str(int(time.time()))
    }
    
    # Add updates to payload
    payload.update(updates)
    
    # Make the update request
    update_url = f"https://eur-osiris.gameloft.com:443/groups/{clan_id}"
    headers = {
        "Accept": "*/*",
        "Content-Type": "application/x-www-form-urlencoded"
    }
    
    print("🔄 Sending update request...")
    update_response = requests.post(update_url, data=payload, headers=headers, timeout=30)
    
    # Step 5: Check result
    if update_response.status_code == 200:
        print("✅ 🎉 CLAN UPDATED SUCCESSFULLY! 🎉")
        print(f"📄 Response: {update_response.text[:200]}...")
        
        # Step 6: Verify the update
        print("\n🔍 Step 5: Verifying update...")
        time.sleep(2)  # Wait for update to propagate
        
        verify_response = requests.post(url, data=data, timeout=30)
        
        if verify_response.status_code == 200:
            verify_result = verify_response.json()
            if username in verify_result:
                updated_data = verify_result[username]
                if '_game_save' in updated_data and 'osiris_info' in updated_data['_game_save']:
                    updated_clan = updated_data['_game_save']['osiris_info']
                    print("🔄 Verified Changes:")
                    print(f"   Name: {updated_clan.get('clan_name', 'N/A')}")
                    print(f"   Display Name: {updated_clan.get('display_name', 'N/A')}")
                
                # Also get detailed squad info
                updated_squad = client.get_squad_info(clan_id)
                if 'error' not in updated_squad:
                    print("📊 Updated Squad Details:")
                    print(f"   Name: {updated_squad.get('name', 'N/A')}")
                    print(f"   Description: {updated_squad.get('description', 'N/A')}")
                    print(f"   Rating: {updated_squad.get('rating', 'N/A')}")
                    print(f"   Currency: {updated_squad.get('currency', 'N/A')}")
                    print(f"   Member Limit: {updated_squad.get('member_limit', 'N/A')}")
                    print(f"   Membership: {updated_squad.get('membership', 'N/A')}")
        
        print("\n🎉 SUCCESS! Clan management workflow completed successfully!")
        return True
        
    else:
        print(f"❌ Update failed with status {update_response.status_code}")
        print(f"📄 Error: {update_response.text}")
        return False

def quick_clan_update():
    """Quick clan update with predefined values."""
    
    print("⚡ Quick Clan Update")
    print("=" * 30)
    
    username = "anonymous:d2luOF92M18xNzcwMDUxNjkwXy7H33aeTVB4YZictyDq48c="
    password = "sSJKzhQ5l4vrFgov"
    
    # Predefined updates
    quick_updates = {
        "name": "Quick Update Squad",
        "description": "Updated via quick function!",
        "_rating": 6000,
        "currency": "30000"
    }
    
    print(f"🚀 Applying quick updates: {quick_updates}")
    
    # Use the working update function
    return working_clan_update_example()

if __name__ == "__main__":
    print("🎮 Modern Combat 5 - Working Clan Update Example")
    print("=" * 55)
    print("This example demonstrates the WORKING clan update method.")
    print("It uses automatic clan detection and the correct API structure.")
    print()
    
    # Choose update method
    print("Choose update method:")
    print("1. Complete workflow with user input")
    print("2. Quick update with predefined values")
    
    choice = input("\nEnter choice (1-2): ").strip()
    
    if choice == "1":
        working_clan_update_example()
    elif choice == "2":
        quick_clan_update()
    else:
        print("❌ Invalid choice!")
    
    print("\n🎮 Example completed! Check your clan in-game to see the changes.")
