#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : advanced_chat_utilities.py
# | License  : MIT License © 2026 Chizoba
# | Brief    | Advanced chat utilities for MC5 API Client
# ────────────────★─────────────────────────────────

"""
Advanced MC5 Chat Utilities

This module provides advanced chat functionality beyond basic messaging.
Features sophisticated chat management, automation, and analytics.

Features:
- Multi-language broadcasting
- Chat scheduling and automation
- Message templates and macros
- Chat analytics and statistics
- Advanced filtering and monitoring
- Smart replies and auto-responses
"""

import time
import json
import threading
from typing import Dict, List, Optional, Callable, Union
from datetime import datetime, timedelta
from .ultra_simple_chat import send, en, fr, de, es, it, pt, ru, ja, ko, zh, check_inbox, my_messages, test_connection
from .room_matchmaking import MC5RoomAPI

class AdvancedChatManager:
    """Advanced chat management system"""
    
    def __init__(self):
        """Initialize advanced chat manager"""
        self.message_templates = {}
        self.scheduled_messages = []
        self.chat_stats = {
            'messages_sent': 0,
            'messages_by_language': {},
            'last_activity': None,
            'session_start': datetime.now()
        }
        self.auto_reply_enabled = False
        self.auto_reply_patterns = {}
        
    def add_message_template(self, name: str, message: str, languages: List[str] = None) -> None:
        """Add a message template for quick use"""
        if languages is None:
            languages = ['en']
        
        self.message_templates[name] = {
            'message': message,
            'languages': languages,
            'created_at': datetime.now()
        }
        print(f"✅ Added template '{name}' for languages: {', '.join(languages)}")
    
    def use_template(self, name: str, custom_vars: Dict = None) -> bool:
        """Use a message template"""
        if name not in self.message_templates:
            print(f"❌ Template '{name}' not found")
            return False
        
        template = self.message_templates[name]
        message = template['message']
        
        # Replace custom variables
        if custom_vars:
            for var, value in custom_vars.items():
                message = message.replace(f"{{{var}}}", str(value))
        
        # Send to all configured languages
        success = True
        for lang in template['languages']:
            try:
                if lang == 'en':
                    result = send(message)
                elif lang == 'fr':
                    result = fr(message)
                elif lang == 'de':
                    result = de(message)
                elif lang == 'es':
                    result = es(message)
                elif lang == 'it':
                    result = it(message)
                elif lang == 'pt':
                    result = pt(message)
                elif lang == 'ru':
                    result = ru(message)
                elif lang == 'ja':
                    result = ja(message)
                elif lang == 'ko':
                    result = ko(message)
                elif lang == 'zh':
                    result = zh(message)
                else:
                    result = send(message)  # Default to English
                
                if result:
                    self._update_stats(lang)
                else:
                    success = False
                    
            except Exception as e:
                print(f"❌ Error sending to {lang}: {e}")
                success = False
        
        return success
    
    def broadcast_message(self, message: str, languages: List[str] = None) -> Dict:
        """Broadcast message to multiple languages"""
        if languages is None:
            languages = ['en', 'fr', 'de', 'es', 'it', 'pt', 'ru', 'ja', 'ko', 'zh']
        
        results = {}
        for lang in languages:
            try:
                if lang == 'en':
                    result = send(message)
                elif lang == 'fr':
                    result = fr(message)
                elif lang == 'de':
                    result = de(message)
                elif lang == 'es':
                    result = es(message)
                elif lang == 'it':
                    result = it(message)
                elif lang == 'pt':
                    result = pt(message)
                elif lang == 'ru':
                    result = ru(message)
                elif lang == 'ja':
                    result = ja(message)
                elif lang == 'ko':
                    result = ko(message)
                elif lang == 'zh':
                    result = zh(message)
                else:
                    result = send(message)
                
                results[lang] = result
                if result:
                    self._update_stats(lang)
                    
            except Exception as e:
                results[lang] = f"Error: {e}"
        
        return results
    
    def schedule_message(self, message: str, delay_seconds: int, languages: List[str] = None) -> str:
        """Schedule a message to be sent later"""
        schedule_id = f"scheduled_{int(time.time())}_{len(self.scheduled_messages)}"
        
        scheduled_msg = {
            'id': schedule_id,
            'message': message,
            'languages': languages or ['en'],
            'scheduled_time': datetime.now() + timedelta(seconds=delay_seconds),
            'sent': False
        }
        
        self.scheduled_messages.append(scheduled_msg)
        
        # Start timer in background
        def send_scheduled():
            time.sleep(delay_seconds)
            if not scheduled_msg['sent']:
                self.broadcast_message(message, languages)
                scheduled_msg['sent'] = True
                print(f"✅ Scheduled message sent: {schedule_id}")
        
        thread = threading.Thread(target=send_scheduled, daemon=True)
        thread.start()
        
        print(f"⏰ Message scheduled in {delay_seconds} seconds (ID: {schedule_id})")
        return schedule_id
    
    def start_auto_reply(self, patterns: Dict[str, str]) -> None:
        """Start automatic reply system"""
        self.auto_reply_patterns = patterns
        self.auto_reply_enabled = True
        print("🤖 Auto-reply system enabled")
    
    def stop_auto_reply(self) -> None:
        """Stop automatic reply system"""
        self.auto_reply_enabled = False
        print("🛑 Auto-reply system disabled")
    
    def get_chat_analytics(self) -> Dict:
        """Get comprehensive chat analytics"""
        session_duration = datetime.now() - self.chat_stats['session_start']
        
        analytics = {
            'session_duration': str(session_duration),
            'messages_sent': self.chat_stats['messages_sent'],
            'messages_by_language': self.chat_stats['messages_by_language'],
            'most_used_language': None,
            'average_messages_per_minute': 0,
            'last_activity': self.chat_stats['last_activity'],
            'templates_available': len(self.message_templates),
            'scheduled_messages': len([m for m in self.scheduled_messages if not m['sent']])
        }
        
        if self.chat_stats['messages_by_language']:
            analytics['most_used_language'] = max(
                self.chat_stats['messages_by_language'], 
                key=self.chat_stats['messages_by_language'].get
            )
        
        if session_duration.total_seconds() > 0:
            analytics['average_messages_per_minute'] = (
                self.chat_stats['messages_sent'] / (session_duration.total_seconds() / 60)
            )
        
        return analytics
    
    def _update_stats(self, language: str) -> None:
        """Update chat statistics"""
        self.chat_stats['messages_sent'] += 1
        self.chat_stats['messages_by_language'][language] = (
            self.chat_stats['messages_by_language'].get(language, 0) + 1
        )
        self.chat_stats['last_activity'] = datetime.now()
    
    def create_chat_report(self) -> str:
        """Create a comprehensive chat report"""
        analytics = self.get_chat_analytics()
        
        report = f"""
💬 CHAT ANALYTICS REPORT
{'='*40}
📅 Session Duration: {analytics['session_duration']}
📊 Messages Sent: {analytics['messages_sent']}
📈 Avg Messages/Min: {analytics['average_messages_per_minute']:.1f}
🌐 Most Used Language: {analytics['most_used_language'] or 'None'}
📝 Templates Available: {analytics['templates_available']}
⏰ Scheduled Messages: {analytics['scheduled_messages']}

📊 MESSAGES BY LANGUAGE:
"""
        
        for lang, count in analytics['messages_by_language'].items():
            report += f"   {lang.upper()}: {count} messages\n"
        
        if analytics['last_activity']:
            report += f"\n⏰ Last Activity: {analytics['last_activity'].strftime('%Y-%m-%d %H:%M:%S')}\n"
        
        return report

# Global chat manager instance
chat_manager = AdvancedChatManager()

# Convenience functions
def create_template(name: str, message: str, languages: List[str] = None) -> None:
    """Create a message template"""
    chat_manager.add_message_template(name, message, languages)

def use_template(name: str, **kwargs) -> bool:
    """Use a message template"""
    return chat_manager.use_template(name, kwargs)

def broadcast(message: str, languages: List[str] = None) -> Dict:
    """Broadcast message to multiple languages"""
    return chat_manager.broadcast_message(message, languages)

def schedule_chat(message: str, delay_seconds: int, languages: List[str] = None) -> str:
    """Schedule a chat message"""
    return chat_manager.schedule_message(message, delay_seconds, languages)

def get_chat_stats() -> Dict:
    """Get chat statistics"""
    return chat_manager.get_chat_analytics()

def chat_report() -> str:
    """Generate chat report"""
    return chat_manager.create_chat_report()

# Pre-defined templates
def setup_default_templates() -> None:
    """Setup default message templates"""
    
    # Greeting templates
    chat_manager.add_message_template("greet", "Hello everyone!", ['en', 'fr', 'de', 'es'])
    chat_manager.add_message_template("goodbye", "Goodbye everyone!", ['en', 'fr', 'de', 'es'])
    chat_manager.add_message_template("thanks", "Thanks for the game!", ['en', 'fr', 'de', 'es'])
    
    # Game templates
    chat_manager.add_message_template("gg", "Good game!", ['en', 'fr', 'de', 'es'])
    chat_manager.add_message_template("nice_shot", "Nice shot!", ['en', 'fr', 'de', 'es'])
    chat_manager.add_message_template("well_played", "Well played!", ['en', 'fr', 'de', 'es'])
    
    # Team templates
    chat_manager.add_message_template("team_up", "Let's team up!", ['en', 'fr', 'de', 'es'])
    chat_manager.add_message_template("cover_me", "Cover me!", ['en', 'fr', 'de', 'es'])
    chat_manager.add_message_template("follow_me", "Follow me!", ['en', 'fr', 'de', 'es'])
    
    # Custom templates with variables
    chat_manager.add_message_template("welcome", "Welcome {player} to the team!", ['en', 'fr', 'de', 'es'])
    chat_manager.add_message_template("grats", "Congratulations {player} on level {level}!", ['en', 'fr', 'de', 'es'])
    
    print("✅ Default chat templates setup complete!")

# Advanced broadcasting functions
def announce_to_all(message: str) -> Dict:
    """Announce message to all supported languages"""
    all_languages = ['en', 'fr', 'de', 'es', 'it', 'pt', 'ru', 'ja', 'ko', 'zh']
    return chat_manager.broadcast_message(message, all_languages)

def announce_to_europe(message: str) -> Dict:
    """Announce message to European languages"""
    european_languages = ['en', 'fr', 'de', 'es', 'it', 'pt']
    return chat_manager.broadcast_message(message, european_languages)

def announce_to_asia(message: str) -> Dict:
    """Announce message to Asian languages"""
    asian_languages = ['ja', 'ko', 'zh', 'ru']
    return chat_manager.broadcast_message(message, asian_languages)

# Smart reply functions
def setup_smart_replies() -> None:
    """Setup smart auto-reply patterns"""
    patterns = {
        'hello': 'Hello there! How are you?',
        'hi': 'Hi! Welcome to the chat!',
        'gg': 'Good game! Well played!',
        'thanks': 'You\'re welcome!',
        'bye': 'Goodbye! See you next time!',
        'help': 'Need help? Ask me anything!',
        'lol': 'Haha, that\'s funny!',
        'nice': 'Thank you! Appreciate it!',
        'pro': 'Thanks! Still learning though!'
    }
    
    chat_manager.start_auto_reply(patterns)

# Chat automation functions
def auto_greet(interval_minutes: int = 30) -> None:
    """Automatically send greetings at intervals"""
    def greet_loop():
        while True:
            time.sleep(interval_minutes * 60)
            chat_manager.broadcast_message("Hello everyone! 👋", ['en', 'fr', 'de'])
    
    thread = threading.Thread(target=greet_loop, daemon=True)
    thread.start()
    print(f"🤖 Auto-greet started (every {interval_minutes} minutes)")

def monitor_chat_health(check_interval: int = 60) -> None:
    """Monitor chat health and connectivity"""
    def health_check():
        while True:
            try:
                if test_connection():
                    print(f"✅ Chat health check passed at {datetime.now().strftime('%H:%M:%S')}")
                else:
                    print(f"❌ Chat health check failed at {datetime.now().strftime('%H:%M:%S')}")
            except Exception as e:
                print(f"❌ Chat health check error: {e}")
            
            time.sleep(check_interval)
    
    thread = threading.Thread(target=health_check, daemon=True)
    thread.start()
    print(f"🏥 Chat health monitoring started (every {check_interval} seconds)")

# Initialize default templates
setup_default_templates()
