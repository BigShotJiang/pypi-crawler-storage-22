#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : api_adapter.py
# | License  : MIT License © 2026 Chizoba
# | Brief    : Future-proof API adapter system
# ────────────────★─────────────────────────────────

"""
Future-Proof API Adapter System

This module provides an adapter pattern to handle API changes,
version compatibility, and graceful degradation for the MC5 API client.
"""

import time
import requests
from typing import Dict, Any, Optional, Callable, List
from abc import ABC, abstractmethod
from .api_config import get_config, APIEndpoint

class APIAdapter(ABC):
    """Abstract base class for API adapters."""
    
    @abstractmethod
    def execute(self, endpoint_name: str, **kwargs) -> tuple:
        """
        Execute API request.
        
        Args:
            endpoint_name: Name of the endpoint
            **kwargs: Request parameters
            
        Returns:
            Tuple of (success: bool, response: str)
        """
        pass
    
    @abstractmethod
    def is_compatible(self, version: str) -> bool:
        """
        Check if adapter is compatible with API version.
        
        Args:
            version: API version
            
        Returns:
            True if compatible, False otherwise
        """
        pass

class StandardAPIAdapter(APIAdapter):
    """Standard API adapter for current MC5 API."""
    
    def __init__(self, client=None):
        """
        Initialize the standard adapter.
        
        Args:
            client: MC5Client instance
        """
        self.client = client
        self.config = get_config()
        self.session = requests.Session()
        
        # Default headers
        self.session.headers.update({
            "User-Agent": "MC5-API-Client/1.0.25",
            "Accept": "*/*",
            "Accept-Encoding": "gzip, deflate"
        })
    
    def execute(self, endpoint_name: str, **kwargs) -> tuple:
        """
        Execute API request with fallback handling.
        
        Args:
            endpoint_name: Name of the endpoint
            **kwargs: Request parameters
            
        Returns:
            Tuple of (success: bool, response: str)
        """
        # Get endpoint configuration
        endpoint = self.config.get_endpoint(endpoint_name)
        if not endpoint:
            return False, f"Endpoint {endpoint_name} not found"
        
        # Check if deprecated
        if endpoint.deprecated:
            print(f"⚠️ Warning: Using deprecated endpoint {endpoint_name}")
            if endpoint.replacement:
                print(f"   Consider using {endpoint.replacement} instead")
        
        try:
            # Build URL with parameter substitution
            url = self._build_url(endpoint.url, kwargs)
            
            # Prepare request data
            data = self._prepare_data(endpoint, kwargs)
            headers = self._prepare_headers(endpoint, kwargs)
            
            # Execute request
            response = self.session.request(
                method=endpoint.method,
                url=url,
                data=data,
                headers=headers,
                timeout=30
            )
            
            # Check response
            if response.status_code == 200:
                return True, response.text
            else:
                # Try fallback strategies
                return self._handle_fallback(endpoint, response, kwargs)
                
        except Exception as e:
            return self._handle_error(endpoint, e, kwargs)
    
    def _build_url(self, url_template: str, params: Dict[str, Any]) -> str:
        """Build URL with parameter substitution."""
        try:
            return url_template.format(**params)
        except KeyError as e:
            raise ValueError(f"Missing required URL parameter: {e}")
    
    def _prepare_data(self, endpoint: APIEndpoint, params: Dict[str, Any]) -> Dict[str, Any]:
        """Prepare request data."""
        data = {}
        
        # Add endpoint parameters
        for key, value in endpoint.parameters.items():
            if isinstance(value, str) and value.startswith("{") and value.endswith("}"):
                # Substitute parameter
                param_name = value.strip("{}")
                if param_name in params:
                    data[key] = params[param_name]
                else:
                    raise ValueError(f"Missing required parameter: {param_name}")
            else:
                # Use fixed value
                data[key] = value
        
        # Add additional parameters
        for key, value in params.items():
            if key not in data:
                data[key] = value
        
        return data
    
    def _prepare_headers(self, endpoint: APIEndpoint, params: Dict[str, Any]) -> Dict[str, str]:
        """Prepare request headers."""
        headers = {}
        
        # Add endpoint headers
        if endpoint.headers:
            headers.update(endpoint.headers)
        
        # Add custom headers
        if "headers" in params:
            headers.update(params["headers"])
        
        return headers
    
    def _handle_fallback(self, endpoint: APIEndpoint, response: requests.Response, params: Dict[str, Any]) -> tuple:
        """Handle response with fallback strategies."""
        status = response.status_code
        
        # Log the error
        print(f"⚠️ API request failed: {status} {response.reason}")
        
        # Try different fallback strategies based on status code
        if status == 401:
            # Authentication error - try to refresh token
            if self.client and hasattr(self.client, '_token_data'):
                return self._try_token_refresh(endpoint, params)
        
        elif status == 404:
            # Not found - try alternative endpoints
            return self._try_alternative_endpoints(endpoint.name, params)
        
        elif status == 429:
            # Rate limited - wait and retry
            return self._try_rate_limit_retry(endpoint, params)
        
        # Return original error
        return False, f"API request failed: {status} {response.text}"
    
    def _try_token_refresh(self, endpoint: APIEndpoint, params: Dict[str, Any]) -> tuple:
        """Try to refresh token and retry request."""
        try:
            if self.client and hasattr(self.client, 'authenticate'):
                print("🔄 Attempting token refresh...")
                
                # Re-authenticate
                if hasattr(self.client, '_username') and hasattr(self.client, '_password'):
                    self.client.authenticate(self.client._username, self.client._password)
                    
                    # Update access token in params
                    if hasattr(self.client, '_token_data') and 'access_token' in self.client._token_data:
                        params['access_token'] = self.client._token_data['access_token']
                        
                        # Retry the request
                        return self.execute(endpoint.name, **params)
        except Exception as e:
            print(f"❌ Token refresh failed: {e}")
        
        return False, "Authentication failed and token refresh unsuccessful"
    
    def _try_alternative_endpoints(self, endpoint_name: str, params: Dict[str, Any]) -> tuple:
        """Try alternative endpoints for the same functionality."""
        alternatives = {
            "get_batch_profiles": ["get_profile", "get_user_info"],
            "update_clan_settings": ["update_squad_info", "update_group_settings"],
            "update_member_profile": ["update_profile", "update_user_stats"]
        }
        
        if endpoint_name in alternatives:
            for alt_endpoint in alternatives[endpoint_name]:
                print(f"🔄 Trying alternative endpoint: {alt_endpoint}")
                result = self.execute(alt_endpoint, **params)
                if result[0]:  # Success
                    print(f"✅ Alternative endpoint {alt_endpoint} worked")
                    return result
        
        return False, f"No working alternative found for {endpoint_name}"
    
    def _try_rate_limit_retry(self, endpoint: APIEndpoint, params: Dict[str, Any]) -> tuple:
        """Try to retry after rate limit."""
        print("⏳ Rate limited, waiting before retry...")
        time.sleep(2)  # Wait 2 seconds
        
        try:
            response = self.session.request(
                method=endpoint.method,
                url=self._build_url(endpoint.url, params),
                data=self._prepare_data(endpoint, params),
                headers=self._prepare_headers(endpoint, params),
                timeout=30
            )
            
            if response.status_code == 200:
                print("✅ Retry successful")
                return True, response.text
        except Exception as e:
            print(f"❌ Retry failed: {e}")
        
        return False, "Rate limit retry failed"
    
    def _handle_error(self, endpoint: APIEndpoint, error: Exception, params: Dict[str, Any]) -> tuple:
        """Handle request error."""
        error_msg = str(error)
        
        print(f"❌ Request error: {error_msg}")
        
        # Try to provide helpful error messages
        if "timeout" in error_msg.lower():
            return False, "Request timed out. Please check your connection and try again."
        elif "connection" in error_msg.lower():
            return False, "Connection error. Please check your internet connection."
        elif "ssl" in error_msg.lower():
            return False, "SSL error. Please check your system's SSL configuration."
        else:
            return False, f"Request failed: {error_msg}"
    
    def is_compatible(self, version: str) -> bool:
        """Check if adapter is compatible with API version."""
        return version >= "1.0.20"  # Standard adapter works with 1.0.20+

class LegacyAPIAdapter(APIAdapter):
    """Legacy API adapter for older MC5 API versions."""
    
    def __init__(self, client=None):
        """Initialize the legacy adapter."""
        self.client = client
        self.config = get_config()
        self.session = requests.Session()
    
    def execute(self, endpoint_name: str, **kwargs) -> tuple:
        """Execute API request using legacy format."""
        # Map to legacy endpoints
        legacy_mapping = {
            "get_batch_profiles": "get_user_profile",
            "update_clan_settings": "update_squad",
            "update_member_profile": "update_user_data"
        }
        
        legacy_endpoint = legacy_mapping.get(endpoint_name, endpoint_name)
        
        # Use legacy URL format
        legacy_urls = {
            "get_user_profile": "https://mc5.arena.gameloft.com/profile",
            "update_squad": "https://mc5.arena.gameloft.com/squad/update",
            "update_user_data": "https://mc5.arena.gameloft.com/user/update"
        }
        
        if legacy_endpoint in legacy_urls:
            url = legacy_urls[legacy_endpoint]
            
            try:
                response = self.session.post(url, data=kwargs, timeout=30)
                if response.status_code == 200:
                    return True, response.text
                else:
                    return False, f"Legacy API error: {response.status_code}"
            except Exception as e:
                return False, f"Legacy API request failed: {e}"
        
        return False, f"Legacy endpoint {legacy_endpoint} not supported"
    
    def is_compatible(self, version: str) -> bool:
        """Check if adapter is compatible with API version."""
        return version < "1.0.20"  # Legacy adapter works with pre-1.0.20

class APIAdapterFactory:
    """Factory for creating API adapters."""
    
    @staticmethod
    def create_adapter(client=None, version: str = None) -> APIAdapter:
        """
        Create appropriate API adapter.
        
        Args:
            client: MC5Client instance
            version: API version (auto-detect if None)
            
        Returns:
            APIAdapter instance
        """
        config = get_config()
        target_version = version or config.current_version
        
        # Choose adapter based on version
        if target_version >= "1.0.20":
            return StandardAPIAdapter(client)
        else:
            return LegacyAPIAdapter(client)
    
    @staticmethod
    def get_compatible_adapters(version: str) -> List[APIAdapter]:
        """
        Get all adapters compatible with version.
        
        Args:
            version: API version
            
        Returns:
            List of compatible adapters
        """
        adapters = []
        
        standard = StandardAPIAdapter()
        if standard.is_compatible(version):
            adapters.append(standard)
        
        legacy = LegacyAPIAdapter()
        if legacy.is_compatible(version):
            adapters.append(legacy)
        
        return adapters

# Global adapter factory
_adapter_factory = APIAdapterFactory()

def get_adapter(client=None, version: str = None) -> APIAdapter:
    """Get appropriate API adapter."""
    return _adapter_factory.create_adapter(client, version)
