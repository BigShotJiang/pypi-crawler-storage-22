#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : api_config.py
# | License  : MIT License © 2026 Chizoba
# | Brief    : Future-proof API configuration management
# ────────────────★─────────────────────────────────

"""
Future-Proof API Configuration Management

This module provides a centralized configuration system to handle API changes,
version compatibility, and endpoint management for the MC5 API client.
"""

import json
import os
from typing import Dict, Any, Optional, List
from dataclasses import dataclass, asdict
from pathlib import Path

@dataclass
class APIEndpoint:
    """API endpoint configuration."""
    name: str
    url: str
    method: str
    version: str
    deprecated: bool = False
    deprecation_date: Optional[str] = None
    replacement: Optional[str] = None
    parameters: Dict[str, Any] = None
    headers: Dict[str, str] = None
    
    def __post_init__(self):
        if self.parameters is None:
            self.parameters = {}
        if self.headers is None:
            self.headers = {}

@dataclass
class APIVersion:
    """API version configuration."""
    version: str
    release_date: str
    support_end_date: Optional[str] = None
    deprecated: bool = False
    breaking_changes: List[str] = None
    endpoints: Dict[str, APIEndpoint] = None
    
    def __post_init__(self):
        if self.breaking_changes is None:
            self.breaking_changes = []
        if self.endpoints is None:
            self.endpoints = {}

class FutureProofConfig:
    """
    Future-proof configuration manager for MC5 API.
    
    Handles API versioning, endpoint management, and backward compatibility.
    """
    
    def __init__(self, config_file: Optional[str] = None):
        """
        Initialize the configuration manager.
        
        Args:
            config_file: Path to configuration file (optional)
        """
        self.config_file = config_file or self._get_default_config_path()
        self.current_version = "1.0.25"
        self.api_versions: Dict[str, APIVersion] = {}
        self.fallback_endpoints: Dict[str, APIEndpoint] = {}
        
        # Load configuration
        self.load_config()
        
        # Initialize default configuration if empty
        if not self.api_versions:
            self._initialize_default_config()
    
    def _get_default_config_path(self) -> str:
        """Get default configuration file path."""
        # Try user home directory first
        user_config = os.path.expanduser("~/.mc5_api_client/config.json")
        if os.path.exists(user_config):
            return user_config
        
        # Fallback to package directory
        package_dir = Path(__file__).parent
        return str(package_dir / "api_config.json")
    
    def _initialize_default_config(self):
        """Initialize default API configuration."""
        # Current API version
        current = APIVersion(
            version="1.0.25",
            release_date="2026-02-04",
            endpoints={
                "get_batch_profiles": APIEndpoint(
                    name="get_batch_profiles",
                    url="https://app-468561b3-9ecd-4d21-8241-30ed288f4d8b.gold0009.gameloft.com/1875/windows/09/public/OfficialScripts/mc5Portal.wsgi",
                    method="POST",
                    version="1.0.25",
                    parameters={
                        "op_code": "get_batch_profiles",
                        "client_id": "1875:55979:6.0.0a:windows:windows",
                        "include_fields": "_game_save,inventory"
                    }
                ),
                "update_clan_settings": APIEndpoint(
                    name="update_clan_settings",
                    url="https://eur-osiris.gameloft.com:443/groups/{clan_id}",
                    method="POST",
                    version="1.0.25",
                    parameters={
                        "access_token": "{access_token}",
                        "_anonId": "{username}",
                        "_fedId": "{fed_id}",
                        "timestamp": "{timestamp}"
                    }
                ),
                "update_member_profile": APIEndpoint(
                    name="update_member_profile",
                    url="https://eur-osiris.gameloft.com/groups/{group_id}/members/{credential}",
                    method="POST",
                    version="1.0.25",
                    parameters={
                        "access_token": "{access_token}",
                        "credential": "{credential}",
                        "operation": "update",
                        "timestamp": "{timestamp}"
                    }
                )
            }
        )
        
        self.api_versions["1.0.25"] = current
        
        # Save default configuration
        self.save_config()
    
    def load_config(self) -> bool:
        """
        Load configuration from file.
        
        Returns:
            True if successful, False otherwise
        """
        try:
            if os.path.exists(self.config_file):
                with open(self.config_file, 'r') as f:
                    data = json.load(f)
                
                # Parse API versions
                for version_str, version_data in data.get("api_versions", {}).items():
                    endpoints = {}
                    for endpoint_name, endpoint_data in version_data.get("endpoints", {}).items():
                        endpoints[endpoint_name] = APIEndpoint(**endpoint_data)
                    
                    self.api_versions[version_str] = APIVersion(
                        **{k: v for k, v in version_data.items() if k != "endpoints"},
                        endpoints=endpoints
                    )
                
                self.current_version = data.get("current_version", self.current_version)
                return True
        except Exception:
            pass  # Use default configuration
        
        return False
    
    def save_config(self) -> bool:
        """
        Save configuration to file.
        
        Returns:
            True if successful, False otherwise
        """
        try:
            # Ensure directory exists
            os.makedirs(os.path.dirname(self.config_file), exist_ok=True)
            
            data = {
                "current_version": self.current_version,
                "api_versions": {}
            }
            
            for version_str, version in self.api_versions.items():
                version_data = asdict(version)
                version_data["endpoints"] = {
                    name: asdict(endpoint) for name, endpoint in version.endpoints.items()
                }
                data["api_versions"][version_str] = version_data
            
            with open(self.config_file, 'w') as f:
                json.dump(data, f, indent=2)
            
            return True
        except Exception:
            return False
    
    def get_endpoint(self, endpoint_name: str, version: Optional[str] = None) -> Optional[APIEndpoint]:
        """
        Get API endpoint configuration.
        
        Args:
            endpoint_name: Name of the endpoint
            version: API version (uses current if None)
            
        Returns:
            APIEndpoint configuration or None if not found
        """
        target_version = version or self.current_version
        
        # Try specific version first
        if target_version in self.api_versions:
            if endpoint_name in self.api_versions[target_version].endpoints:
                endpoint = self.api_versions[target_version].endpoints[endpoint_name]
                
                # Check if deprecated
                if endpoint.deprecated:
                    print(f"⚠️ Warning: Endpoint {endpoint_name} is deprecated")
                    if endpoint.replacement:
                        print(f"   Use {endpoint.replacement} instead")
                
                return endpoint
        
        # Try fallback to older versions
        for version_str in sorted(self.api_versions.keys(), reverse=True):
            if version_str <= target_version:
                version = self.api_versions[version_str]
                if endpoint_name in version.endpoints:
                    return version.endpoints[endpoint_name]
        
        return None
    
    def add_endpoint(self, endpoint: APIEndpoint, version: str = None):
        """
        Add or update an API endpoint.
        
        Args:
            endpoint: APIEndpoint configuration
            version: API version (uses current if None)
        """
        target_version = version or self.current_version
        
        if target_version not in self.api_versions:
            self.api_versions[target_version] = APIVersion(
                version=target_version,
                release_date="2026-02-04"
            )
        
        self.api_versions[target_version].endpoints[endpoint.name] = endpoint
        self.save_config()
    
    def deprecate_endpoint(self, endpoint_name: str, replacement: str = None, version: str = None):
        """
        Deprecate an API endpoint.
        
        Args:
            endpoint_name: Name of the endpoint to deprecate
            replacement: Replacement endpoint name
            version: API version (uses current if None)
        """
        target_version = version or self.current_version
        
        if target_version in self.api_versions:
            endpoints = self.api_versions[target_version].endpoints
            if endpoint_name in endpoints:
                endpoints[endpoint_name].deprecated = True
                endpoints[endpoint_name].replacement = replacement
                self.save_config()
    
    def get_compatible_endpoints(self, min_version: str, max_version: str = None) -> Dict[str, APIEndpoint]:
        """
        Get all endpoints compatible with version range.
        
        Args:
            min_version: Minimum API version
            max_version: Maximum API version (uses current if None)
            
        Returns:
            Dictionary of compatible endpoints
        """
        target_max = max_version or self.current_version
        compatible = {}
        
        for version_str in sorted(self.api_versions.keys()):
            if min_version <= version_str <= target_max:
                version = self.api_versions[version_str]
                for name, endpoint in version.endpoints.items():
                    if not endpoint.deprecated and name not in compatible:
                        compatible[name] = endpoint
        
        return compatible
    
    def check_api_compatibility(self, required_version: str) -> Dict[str, Any]:
        """
        Check API compatibility for required version.
        
        Args:
            required_version: Required API version
            
        Returns:
            Compatibility information
        """
        result = {
            "compatible": False,
            "current_version": self.current_version,
            "required_version": required_version,
            "issues": [],
            "recommendations": []
        }
        
        # Check if required version is available
        if required_version in self.api_versions:
            result["compatible"] = True
        else:
            result["issues"].append(f"Required version {required_version} not available")
            
            # Find closest available version
            available_versions = sorted(self.api_versions.keys(), reverse=True)
            if available_versions:
                result["recommendations"].append(f"Use latest available version: {available_versions[0]}")
        
        return result

# Global configuration instance
_config_instance = None

def get_config() -> FutureProofConfig:
    """Get global configuration instance."""
    global _config_instance
    if _config_instance is None:
        _config_instance = FutureProofConfig()
    return _config_instance

def reset_config():
    """Reset global configuration instance."""
    global _config_instance
    _config_instance = None
