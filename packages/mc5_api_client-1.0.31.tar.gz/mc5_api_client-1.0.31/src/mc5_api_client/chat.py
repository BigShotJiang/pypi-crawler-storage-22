#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : chat.py
# | License  : MIT License © 2026 Chizoba
# | Brief    : MC5 Chat API client for sending and receiving messages
# ────────────────★─────────────────────────────────

"""
MC5 Chat API Client

This module provides functionality to interact with the MC5 chat system:
- Send messages to global chat channels
- Listen to chat streams (real-time messages)
- Handle dynamic chat server discovery
- Support for multiple chat servers (eur-fedex-fsg001 to eur-fedex-fsg006)
"""

import requests
import json
import time
import re
from typing import Dict, List, Optional, Any, Callable
from urllib.parse import urljoin
import threading
from .platform import get_pc_anonymous_credential, get_android_anonymous_credential

class MC5ChatClient:
    """
    MC5 Chat API Client for sending and receiving chat messages.
    
    This client handles:
    - Dynamic chat server discovery
    - Message sending to global chat
    - Real-time chat message streaming
    - Automatic server switching
    """
    
    def __init__(self, username: str = None, password: str = None):
        """
        Initialize the MC5 Chat Client.
        
        Args:
            username: MC5 username/credential (optional, uses PC anonymous if None)
            password: MC5 password (optional, uses default if None)
        """
        self.username = username or get_pc_anonymous_credential()
        self.password = password or "sSJKzhQ5l4vrFgov"
        self.session = requests.Session()
        self.access_token = None
        self.member_id = None
        self.is_listening = False
        self.listen_thread = None
        self.message_callback = None
        self.subscribed_endpoints = {}
        self.subscription_api = "https://eur-arion.gameloft.com/chat/channels/mc5_global/subscribe"
    
    def subscribe_to_chat_channel(self, language: str = "en") -> Optional[Dict[str, Any]]:
        """
        Subscribe to chat channel and get dynamic endpoints.
        
        Args:
            language: Language code (en, fr, de, etc.)
            
        Returns:
            Channel subscription data with endpoints or None if failed
        """
        if not self.access_token:
            self.get_access_token()
        
        if not self.access_token:
            print("🔴 No access token for channel subscription")
            return None
        
        # Prepare subscription data
        data = {
            'access_token': self.access_token,
            'language': language
        }
        
        try:
            response = self.session.post(
                self.subscription_api,
                data=data,
                headers={
                    'User-Agent': 'ChatLibv2',
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'Accept': '*/*'
                },
                timeout=10
            )
            
            if response.status_code == 200:
                result = response.json()
                if result.get('status') == 'ok':
                    self.subscribed_endpoints = result
                    print(f"✅ Subscribed to {language} channel")
                    print(f"   Command URL: {result.get('cmd_url')}")
                    print(f"   Listen URL: {result.get('listen_url')}")
                    print(f"   HTTPS Listen: {result.get('https_listen_url')}")
                    return result
                else:
                    print(f"🔴 Subscription failed: {result}")
                    return None
            else:
                print(f"🔴 Subscription HTTP {response.status_code}: {response.text}")
                return None
                
        except Exception as e:
            print(f" Channel subscription error: {e}")
            return None
    
    def get_access_token(self) -> Optional[str]:
        """
        Get access token for chat authentication.
        
        Returns:
            Chat-specific access token string or None if failed
        """
        # Use MC5 client to get token with chat-specific parameters
        try:
            from .client import MC5Client
            from .platform import Platform
            
            mc5_client = MC5Client(platform=Platform.PC)
            
            # Use the correct client_id format for chat authentication
            # Based on your working example: 1875:55979:6.0.0a:windows:windows
            mc5_client.client_id = "1875:55979:6.0.0a:windows:windows"
            
            # Use chat-specific scope (shorter version for chat)
            chat_scope = "alert auth chat leaderboard_ro lobby message session social"
            
            # Call token generator directly with chat parameters
            token_data = mc5_client.token_generator.generate_token(
                username=self.username,
                password=self.password,
                scope=chat_scope
            )
            
            if token_data.get('access_token'):
                self.access_token = token_data.get('access_token')
                self.member_id = token_data.get('token_id')
                print(f"✅ Chat access token obtained: {self.access_token[:20]}...")
                return self.access_token
            else:
                print(f"🔴 No access token in token result")
                print(f"🔴 Available keys: {list(token_data.keys())}")
        except Exception as e:
            print(f"🔴 Failed to get access token: {e}")
        
        return None
    
    def send_message(self, message: str, nickname: str = None, killsig: str = "default_killsig_80", 
                    killsig_color: str = "12722475", language: str = "en") -> Dict[str, Any]:
        """
        Send a message to the global chat.
        
        Args:
            message: Message content to send
            nickname: Display name (defaults to username)
            killsig: Kill signature ID
            killsig_color: Kill signature color
            language: Language channel (en, fr, de, etc.)
            
        Returns:
            Response data from the chat server
        """
        # Subscribe to get the correct endpoints for this language
        if not self.subscribed_endpoints or language not in self.subscribed_endpoints.get('cmd_url', ''):
            subscription = self.subscribe_to_chat_channel(language)
            if not subscription:
                return {"success": False, "error": "Failed to subscribe to chat channel"}
        
        # Use the subscribed command URL
        cmd_url = self.subscribed_endpoints.get('cmd_url')
        if not cmd_url:
            return {"success": False, "error": "No command URL available"}
        
        if not self.access_token:
            self.get_access_token()
        
        if not self.access_token:
            return {"success": False, "error": "No access token available"}
        
        # Prepare message data
        nickname = nickname or self.username.split(':')[0] if ':' in self.username else self.username
        
        # Extract fed_id from access token or create one
        if self.member_id:
            fed_id = f"fed_id:{self.member_id}"
        else:
            fed_id = f"fed_id:{self.access_token.split('-')[0]}"
        
        # Prepare form data
        data = {
            'access_token': self.access_token,
            '_anonId': self.username,
            'user': json.dumps({"nickname": nickname}),
            'msg': message,
            '_fedId': fed_id,
            '_killSign': killsig,
            '_killSignColor': killsig_color,
            '_senderName': nickname
        }
        
        try:
            response = self.session.post(
                cmd_url,
                data=data,
                headers={
                    'User-Agent': 'ChatLibv2',
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'Accept': '*/*'
                },
                timeout=10
            )
            
            if response.status_code == 200:
                result = response.json()
                return {
                    "success": True,
                    "message_id": result.get('msg', {}).get('id'),
                    "sent_time": result.get('msg', {}).get('sent'),
                    "response": result
                }
            else:
                return {
                    "success": False,
                    "error": f"HTTP {response.status_code}: {response.text}"
                }
                
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def listen_to_chat(self, callback: Callable[[Dict[str, Any]], None] = None, 
                      use_https: bool = False, language: str = "en") -> None:
        """
        Start listening to chat messages in a separate thread.
        
        Args:
            callback: Function to call for each received message
            use_https: Whether to use HTTPS or HTTP for listening (default: False)
            language: Language channel to listen to (en, fr, de, etc.)
        """
        # Subscribe to get the correct endpoints for this language
        if not self.subscribed_endpoints or language not in self.subscribed_endpoints.get('listen_url', ''):
            subscription = self.subscribe_to_chat_channel(language)
            if not subscription:
                print(" No available chat endpoints for listening")
                return
        
        # Use the subscribed listen URL
        listen_url = self.subscribed_endpoints.get('https_listen_url' if use_https else 'listen_url')
        if not listen_url:
            print(" No listen URL available")
            return
        
        if not self.access_token:
            self.get_access_token()
        
        if not self.access_token:
            print(" No access token for chat listening")
            return
        
        self.message_callback = callback
        self.is_listening = True
        
        # Start listening in a separate thread
        self.listen_thread = threading.Thread(
            target=self._listen_to_chat_stream,
            args=(listen_url,),
            daemon=True
        )
        self.listen_thread.start()
    
    def _listen_to_chat_stream(self, listen_url: str) -> None:
        """
        Internal method to listen to chat stream.
        
        Args:
            listen_url: The URL to listen to (from subscription API)
        """
        print(f" Listening to chat: {listen_url}")
        
        try:
            response = self.session.get(listen_url, stream=True, timeout=30)
            
            for line in response.iter_lines(decode_unicode=True):
                if line and self.is_listening:
                    try:
                        # Parse JSON message
                        message_data = json.loads(line)
                        
                        # Call callback if provided
                        if self.message_callback:
                            self.message_callback(message_data)
                        else:
                            # Default message handling
                            self._handle_chat_message(message_data)
                            
                    except json.JSONDecodeError:
                        # Skip invalid JSON lines
                        continue
                    except Exception as e:
                        print(f" Error processing message: {e}")
                        
        except Exception as e:
            print(f" Chat listening error: {e}")
        finally:
            self.is_listening = False
    
    def _handle_chat_message(self, message_data: Dict[str, Any]) -> None:
        """
        Default handler for incoming chat messages.
        
        Args:
            message_data: Parsed message data from chat stream
        """
        msg_type = message_data.get('type', 'unknown')
        
        if msg_type == 'message':
            sender = message_data.get('_senderName', 'Unknown')
            msg = message_data.get('msg', '')
            
            # Decode Unicode names
            try:
                from . import decode_unicode_name
                sender = decode_unicode_name(sender)
            except:
                pass
            
            print(f"💬 {sender}: {msg}")
            
        elif msg_type == 'room_info':
            num_members = message_data.get('num_members', 0)
            print(f" Chat room: {num_members} members online")
            
        elif msg_type == 'disconnect':
            reason = message_data.get('reason', 'Unknown')
            print(f" Disconnected: {reason}")
            
        else:
            print(f" [{msg_type}] {message_data}")
    
    def stop_listening(self) -> None:
        """Stop listening to chat messages."""
        self.is_listening = False
        if self.listen_thread:
            self.listen_thread.join(timeout=5)
    
    def get_chat_info(self) -> Dict[str, Any]:
        """
        Get information about the current chat server and room.
        
        Returns:
            Chat server and room information
        """
        if not self.current_server:
            self.select_best_server()
        
        if not self.current_server:
            return {"success": False, "error": "No available chat servers"}
        
        try:
            # Get room info from listen endpoint
            listen_url = self.current_server['https_listen_url']
            if '?' in listen_url:
                listen_url += f"&memberid={self.member_id}&language=en"
            else:
                listen_url += f"?game=1875&memberid={self.member_id}&language=en"
            
            response = self.session.get(listen_url, timeout=10)
            
            if response.status_code == 200:
                # First line should be room info
                for line in response.iter_lines(decode_unicode=True):
                    if line:
                        try:
                            room_info = json.loads(line)
                            if room_info.get('type') == 'room_info':
                                return {
                                    "success": True,
                                    "server": self.current_server,
                                    "room_info": room_info
                                }
                        except:
                            continue
                        break
            
            return {"success": False, "error": "Could not get room info"}
            
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def __enter__(self):
        """Context manager entry."""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.stop_listening()


# Convenience functions
def send_chat_message(message: str, username: str = None, 
                    password: str = None, nickname: str = None, language: str = "en") -> Dict[str, Any]:
    """
    Send a chat message using default settings.
    
    Args:
        message: Message to send
        username: MC5 username/credential (optional, uses PC anonymous if None)
        password: MC5 password (optional, uses default if None)
        nickname: Display name
        language: Language channel (en, fr, de, etc.)
        
    Returns:
        Response from chat server
    """
    with MC5ChatClient(username, password) as client:
        return client.send_message(message, nickname, language=language)


def listen_to_chat(callback: Callable[[Dict[str, Any]], None] = None,
                  username: str = None, 
                  password: str = None,
                  use_https: bool = False,
                  language: str = "en") -> MC5ChatClient:
    """
    Start listening to chat messages.
    
    Args:
        callback: Function to handle incoming messages
        username: MC5 username/credential (optional, uses PC anonymous if None)
        password: MC5 password (optional, uses default if None)
        use_https: Whether to use HTTPS or HTTP for listening (default: False)
        language: Language channel to listen to (en, fr, de, etc.)
        
    Returns:
        Chat client instance
    """
    client = MC5ChatClient(username, password)
    client.listen_to_chat(callback, use_https, language)
    return client
