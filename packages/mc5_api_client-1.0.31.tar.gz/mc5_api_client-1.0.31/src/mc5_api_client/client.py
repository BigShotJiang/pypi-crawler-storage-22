# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : client.py
# | License  : MIT License © 2026 Chizoba
# | Brief    : Main MC5 API client with comprehensive functionality
# ────────────────★─────────────────────────────────

"""
Main MC5 API client providing comprehensive access to Modern Combat 5 API endpoints.
"""

import time
import json
from typing import Optional, Dict, Any, List
from datetime import datetime
from urllib.parse import quote

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from .auth import TokenGenerator
from .telemetry import telemetry, report_error, report_usage, is_telemetry_enabled
from .squad_battle import SquadBattleMixin
from .federation import FederationMixin
from .alerts import AlertsMixin
from .account import AccountMixin
from .transfer import TransferMixin
from .platform import Platform, get_platform_config, detect_platform_from_client_id
from .storage_admin import StorageAdminMixin
from .exceptions import (
    MC5APIError,
    AuthenticationError,
    TokenExpiredError,
    RateLimitError,
    InsufficientScopeError,
    NetworkError
)


class MC5Client(SquadBattleMixin, FederationMixin, AlertsMixin, AccountMixin, TransferMixin, StorageAdminMixin):
    """
    Comprehensive MC5 API client with support for all major endpoints.
    """
    
    # API endpoints
    BASE_URLS = {
        "auth": "https://eur-janus.gameloft.com:443",
        "osiris": "https://eur-osiris.gameloft.com:443",
        "janus": "https://eur-janus.gameloft.com",
        "olympus": "https://eur-olympus.gameloft.com:443",
        "iris": "https://eur-iris.gameloft.com:443",
        "hermes": "https://eur-hermes.gameloft.com",
        "anubisfinder": "https://eur-anubisfinder.gameloft.com:443",
        "pandora": "https://vgold-eur.gameloft.com",
        "game_portal": "https://app-468561b3-9ecd-4d21-8241-30ed288f4d8b.gold0009.gameloft.com",
        "arion": "https://eur-arion.gameloft.com"
    }
    
    def __init__(
        self,
        username: Optional[str] = None,
        password: Optional[str] = None,
        platform: Platform = Platform.PC,
        client_id: Optional[str] = None,
        auto_refresh: bool = True,
        timeout: int = 30,
        max_retries: int = 3
    ):
        """
        Initialize the MC5 API client.
        
        Args:
            username: MC5 username
            password: MC5 password
            platform: Platform to use (PC or Android)
            client_id: Game client identifier (auto-generated if not provided)
            auto_refresh: Automatically refresh expired tokens
            timeout: Request timeout in seconds
            max_retries: Maximum number of retry attempts
        """
        # Set platform configuration
        self.platform = platform
        self.platform_config = get_platform_config(platform)
        
        # Use platform-specific client_id if not provided
        if client_id is None:
            self.client_id = self.platform_config.get_client_id()
        else:
            self.client_id = client_id
            # Detect platform from custom client_id
            self.platform = detect_platform_from_client_id(client_id)
            self.platform_config = get_platform_config(self.platform)
        
        self.auto_refresh = auto_refresh
        self.timeout = timeout
        self.max_retries = max_retries
        
        # Initialize token generator
        self.token_generator = TokenGenerator(
            client_id=client_id,
            timeout=timeout,
            max_retries=max_retries
        )
        
        # Setup HTTP session
        self.session = requests.Session()
        retry_strategy = Retry(
            total=max_retries,
            status_forcelist=[429, 500, 502, 503, 504],
            allowed_methods=["HEAD", "GET", "POST", "PUT", "DELETE"],
            backoff_factor=1
        )
        adapter = HTTPAdapter(max_retries=retry_strategy)
        self.session.mount("http://", adapter)
        self.session.mount("https://", adapter)
        
        # Default headers
        self.session.headers.update({
            "User-Agent": self.platform_config.get_user_agent(),
            "Accept": "*/*",
            "Content-Type": "application/x-www-form-urlencoded",
            "Connection": "close"
        })
        
        # Token storage
        self._token_data = None
        self._username = username
        self._password = password
        
        # Auto-authenticate if credentials provided
        if username and password:
            self.authenticate(username, password)
    
    def authenticate(self, username: str, password: str, device_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Authenticate and obtain access token.
        
        Args:
            username: MC5 username
            password: MC5 password
            device_id: Device ID (generated if not provided)
            
        Returns:
            Token data dictionary
        """
        self._username = username
        self._password = password
        
        # Generate platform-specific device ID if not provided
        if device_id is None:
            device_id = self.platform_config.generate_device_id()
        
        self._token_data = self.token_generator.generate_token(
            username=username,
            password=password,
            device_id=device_id
        )
        
        return self._token_data
    
    def authenticate_admin(self, device_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Authenticate as admin.
        
        Args:
            device_id: Device ID (generated if not provided)
            
        Returns:
            Admin token data dictionary
        """
        self._token_data = self.token_generator.generate_admin_token(device_id=device_id)
        self._username = "game:mc5_system"
        self._password = "admin"
        
        return self._token_data
    
    def _ensure_valid_token(self):
        """Ensure we have a valid access token."""
        if not self._token_data:
            raise AuthenticationError("No authentication token available. Call authenticate() first.")
        
        if not self.token_generator.validate_token(self._token_data):
            if self.auto_refresh and self._username and self._password:
                print("🟠 Token expired, refreshing...")
                self._token_data = self.token_generator.refresh_token_if_needed(
                    self._token_data,
                    self._username,
                    self._password
                )
            else:
                raise TokenExpiredError("Access token has expired")
    
    def _make_request(
        self,
        method: str,
        url: str,
        params: Optional[Dict[str, Any]] = None,
        data: Optional[Dict[str, Any]] = None,
        json_data: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
        require_token: bool = True
    ) -> Dict[str, Any]:
        """
        Make an HTTP request with proper error handling and telemetry.
        
        Args:
            method: HTTP method (GET, POST, PUT, DELETE)
            url: Request URL
            params: Query parameters
            data: Form data
            json_data: JSON data
            headers: Additional headers
            require_token: Whether authentication token is required
            
        Returns:
            Response JSON data
            
        Raises:
            MC5APIError: For API-related errors
            NetworkError: For network-related errors
        """
        import time
        start_time = time.time()
        function_name = f"{method.upper()} {url.split('/')[-1]}"
        
        # if is_telemetry_enabled():
        #     print(f"🔍 Debug: Making {method} request to {url}")
        
        if require_token:
            self._ensure_valid_token()
            # Add access token to params
            if params is None:
                params = {}
            params["access_token"] = self._token_data["access_token"]
        
        # Prepare request
        request_headers = self.session.headers.copy()
        if headers:
            request_headers.update(headers)
        
        try:
            response = self.session.request(
                method=method,
                url=url,
                params=params,
                data=data,
                json=json_data,
                headers=request_headers,
                timeout=self.timeout
            )
            
            duration = time.time() - start_time
            
            # Handle different response types
            if response.status_code == 200:
                try:
                    result = response.json()
                    # if is_telemetry_enabled():
                    #     print(f"✅ Debug: {method} request successful ({duration:.2f}s)")
                    report_usage(function_name, True, duration, {
                        "status_code": response.status_code,
                        "response_size": len(str(result))
                    })
                    return result
                except json.JSONDecodeError:
                    result = {"response": response.text}
                    # if is_telemetry_enabled():
                    #     print(f"✅ Debug: {method} request successful (text response, {duration:.2f}s)")
                    report_usage(function_name, True, duration, {
                        "status_code": response.status_code,
                        "response_type": "text"
                    })
                    return result
            
            elif response.status_code == 401:
                error = AuthenticationError("Unauthorized - invalid or expired token")
                # if is_telemetry_enabled():
                #     print(f"❌ Debug: Authentication failed ({duration:.2f}s)")
                report_error(error, f"{method} {url}", {
                    "status_code": response.status_code,
                    "duration": duration
                })
                raise error
            
            elif response.status_code == 403:
                try:
                    error_data = response.json()
                    error = InsufficientScopeError(error_data.get("error", "Insufficient permissions"))
                except:
                    error = InsufficientScopeError("Insufficient permissions")
                
                if is_telemetry_enabled():
                    print(f"❌ Debug: Permission denied ({duration:.2f}s)")
                report_error(error, f"{method} {url}", {
                    "status_code": response.status_code,
                    "duration": duration
                })
                raise error
            
            elif response.status_code == 429:
                retry_after = response.headers.get("Retry-After")
                error = RateLimitError(
                    "Rate limit exceeded",
                    retry_after=int(retry_after) if retry_after else None
                )
                
                if is_telemetry_enabled():
                    print(f"⏱️ Debug: Rate limit hit ({duration:.2f}s)")
                report_error(error, f"{method} {url}", {
                    "status_code": response.status_code,
                    "retry_after": retry_after,
                    "duration": duration
                })
                raise error
            
            else:
                try:
                    error_data = response.json()
                    error_msg = error_data.get("error", error_data.get("message", "Unknown error"))
                except:
                    error_msg = response.text or "Unknown error"
                
                error = MC5APIError(
                    f"Request failed with status {response.status_code}: {error_msg}",
                    status_code=response.status_code,
                    response_data=error_data if 'error_data' in locals() else {}
                )
                
                if is_telemetry_enabled():
                    print(f"❌ Debug: API error {response.status_code}: {error_msg} ({duration:.2f}s)")
                report_error(error, f"{method} {url}", {
                    "status_code": response.status_code,
                    "error_message": error_msg,
                    "duration": duration
                })
                raise error
        
        except requests.exceptions.Timeout as e:
            error = NetworkError("Request timed out")
            if is_telemetry_enabled():
                print(f"⏰ Debug: Request timeout ({time.time() - start_time:.2f}s)")
            report_error(error, f"{method} {url}", {
                "error_type": "timeout",
                "duration": time.time() - start_time
            })
            raise error
            
        except requests.exceptions.ConnectionError as e:
            error = NetworkError("Connection failed")
            if is_telemetry_enabled():
                print(f"🔌 Debug: Connection failed ({time.time() - start_time:.2f}s)")
            report_error(error, f"{method} {url}", {
                "error_type": "connection",
                "duration": time.time() - start_time
            })
            raise error
            
        except requests.exceptions.RequestException as e:
            error = NetworkError(f"Network error: {str(e)}")
            if is_telemetry_enabled():
                print(f"🌐 Debug: Network error ({time.time() - start_time:.2f}s): {e}")
            report_error(error, f"{method} {url}", {
                "error_type": "network",
                "error_message": str(e),
                "duration": time.time() - start_time
            })
            raise error
    
    # Profile Management
    
    def get_profile(self, credential: Optional[str] = None) -> Dict[str, Any]:
        """
        Get player profile information.
        
        Args:
            credential: Player credential (uses current user if not provided)
            
        Returns:
            Profile data
        """
        if credential:
            url = f"{self.BASE_URLS['osiris']}/accounts/me"
            params = {"credential": credential}
        else:
            url = f"{self.BASE_URLS['osiris']}/accounts/me"
            params = {}
        
        return self._make_request("GET", url, params=params)
    
    def update_profile(self, profile_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Update player profile.
        
        Args:
            profile_data: Profile data to update
            
        Returns:
            Updated profile data
        """
        url = f"{self.BASE_URLS['osiris']}/accounts/me"
        return self._make_request("PUT", url, data=profile_data)
    
    # Clan Management
    
    def get_clan_settings(self, clan_id: str) -> Dict[str, Any]:
        """
        Get clan settings and information.
        
        Args:
            clan_id: Clan ID
            
        Returns:
            Clan settings data including name, description, members, etc.
        """
        url = f"{self.BASE_URLS['osiris']}/clans/{clan_id}"
        return self._make_request("GET", url)
    
    def update_clan_settings(self, clan_id: str, settings: Dict[str, Any]) -> Dict[str, Any]:
        """
        Update clan settings.
        
        Args:
            clan_id: Clan ID
            settings: Clan settings to update (name, description, membership_type, etc.)
            
        Returns:
            Updated clan settings
        """
        url = f"{self.BASE_URLS['osiris']}/clans/{clan_id}"
        return self._make_request("PUT", url, data=settings)
    
    def get_clan_members(self, clan_id: str) -> List[Dict[str, Any]]:
        """
        Get all members of a clan.
        
        Args:
            clan_id: Clan ID
            
        Returns:
            List of clan members with their roles and stats
        """
        url = f"{self.BASE_URLS['osiris']}/clans/{clan_id}/members"
        response = self._make_request("GET", url)
        return response.get("members", [])
    
    def invite_clan_member(self, clan_id: str, credential: str, role: str = "member") -> Dict[str, Any]:
        """
        Invite a player to join the clan.
        
        Args:
            clan_id: Clan ID
            credential: Player credential to invite
            role: Role to assign (member, officer, etc.)
            
        Returns:
            Invitation result
        """
        url = f"{self.BASE_URLS['osiris']}/clans/{clan_id}/invitations"
        data = {
            "credential": credential,
            "role": role
        }
        return self._make_request("POST", url, data=data)
    
    def accept_clan_invitation(self, clan_id: str) -> Dict[str, Any]:
        """
        Accept a clan invitation.
        
        Args:
            clan_id: Clan ID
            
        Returns:
            Acceptance result
        """
        url = f"{self.BASE_URLS['osiris']}/clans/{clan_id}/invitations/me"
        return self._make_request("POST", url)
    
    def decline_clan_invitation(self, clan_id: str) -> Dict[str, Any]:
        """
        Decline a clan invitation.
        
        Args:
            clan_id: Clan ID
            
        Returns:
            Decline result
        """
        url = f"{self.BASE_URLS['osiris']}/clans/{clan_id}/invitations/me"
        return self._make_request("DELETE", url)
    
    def kick_clan_member(self, clan_id: str, member_credential: str) -> Dict[str, Any]:
        """
        Kick a member from the clan.
        
        Args:
            clan_id: Clan ID
            member_credential: Credential of member to kick
            
        Returns:
            Operation result
        """
        url = f"{self.BASE_URLS['osiris']}/clans/{clan_id}/members/{member_credential}"
        return self._make_request("DELETE", url)
    
    def promote_clan_member(self, clan_id: str, member_credential: str, new_role: str) -> Dict[str, Any]:
        """
        Promote a clan member to a new role.
        
        Args:
            clan_id: Clan ID
            member_credential: Credential of member to promote
            new_role: New role (officer, leader, etc.)
            
        Returns:
            Promotion result
        """
        url = f"{self.BASE_URLS['osiris']}/clans/{clan_id}/members/{member_credential}/role"
        data = {"role": new_role}
        return self._make_request("PUT", url, data=data)
    
    def demote_clan_member(self, clan_id: str, member_credential: str, new_role: str) -> Dict[str, Any]:
        """
        Demote a clan member to a new role.
        
        Args:
            clan_id: Clan ID
            member_credential: Credential of member to demote
            new_role: New role (member, etc.)
            
        Returns:
            Demotion result
        """
        url = f"{self.BASE_URLS['osiris']}/clans/{clan_id}/members/{member_credential}/role"
        data = {"role": new_role}
        return self._make_request("PUT", url, data=data)
    
    def leave_clan(self, clan_id: str) -> Dict[str, Any]:
        """
        Leave the current clan.
        
        Args:
            clan_id: Clan ID
            
        Returns:
            Leave result
        """
        url = f"{self.BASE_URLS['osiris']}/clans/{clan_id}/members/me"
        return self._make_request("DELETE", url)
    
    def get_clan_applications(self, clan_id: str) -> List[Dict[str, Any]]:
        """
        Get pending clan applications.
        
        Args:
            clan_id: Clan ID
            
        Returns:
            List of pending applications
        """
        url = f"{self.BASE_URLS['osiris']}/clans/{clan_id}/applications"
        response = self._make_request("GET", url)
        return response.get("applications", [])
    
    def accept_clan_application(self, clan_id: str, applicant_credential: str, role: str = "member") -> Dict[str, Any]:
        """
        Accept a clan application.
        
        Args:
            clan_id: Clan ID
            applicant_credential: Credential of applicant
            role: Role to assign (member, officer, etc.)
            
        Returns:
            Acceptance result
        """
        url = f"{self.BASE_URLS['osiris']}/clans/{clan_id}/applications/{applicant_credential}"
        data = {"role": role}
        return self._make_request("POST", url, data=data)
    
    def reject_clan_application(self, clan_id: str, applicant_credential: str) -> Dict[str, Any]:
        """
        Reject a clan application.
        
        Args:
            clan_id: Clan ID
            applicant_credential: Credential of applicant
            
        Returns:
            Rejection result
        """
        url = f"{self.BASE_URLS['osiris']}/clans/{clan_id}/applications/{applicant_credential}"
        return self._make_request("DELETE", url)
    
    def apply_to_clan(self, clan_id: str, message: str = "") -> Dict[str, Any]:
        """
        Apply to join a clan.
        
        Args:
            clan_id: Clan ID
            message: Application message
            
        Returns:
            Application result
        """
        url = f"{self.BASE_URLS['osiris']}/clans/{clan_id}/applications"
        data = {"message": message}
        return self._make_request("POST", url, data=data)
    
    def get_my_clan_applications(self) -> List[Dict[str, Any]]:
        """
        Get your own clan applications.
        
        Returns:
            List of your applications
        """
        url = f"{self.BASE_URLS['osiris']}/accounts/me/clan-applications"
        response = self._make_request("GET", url)
        return response.get("applications", [])
    
    def cancel_clan_application(self, clan_id: str) -> Dict[str, Any]:
        """
        Cancel a clan application.
        
        Args:
            clan_id: Clan ID
            
        Returns:
            Cancellation result
        """
        url = f"{self.BASE_URLS['osiris']}/accounts/me/clan-applications/{clan_id}"
        return self._make_request("DELETE", url)
    
    def get_clan_requests(self, request_type: str = "membership_approval") -> List[Dict[str, Any]]:
        """
        Get pending clan membership requests for the current user.
        
        Args:
            request_type: Type of requests to retrieve (default: "membership_approval")
            
        Returns:
            List of clan requests
        """
        url = f"{self.BASE_URLS['osiris']}/accounts/me/requests"
        params = {
            "request_type": request_type
        }
        response = self._make_request("GET", url, params=params)
        return response if isinstance(response, list) else []
    
    def respond_to_clan_request(self, request_id: str, action: str, message: str = "") -> Dict[str, Any]:
        """
        Respond to a clan membership request (accept/reject).
        
        Args:
            request_id: Request ID to respond to
            action: Action to take ("accept" or "reject")
            message: Optional message for the response
            
        Returns:
            Response result
        """
        url = f"{self.BASE_URLS['osiris']}/accounts/me/requests/{request_id}"
        data = {
            "action": action
        }
        if message:
            data["message"] = message
        
        return self._make_request("POST", url, data=data)
    
    def get_clan_statistics(self, clan_id: str) -> Dict[str, Any]:
        """
        Get clan statistics and performance data.
        
        Args:
            clan_id: Clan ID
            
        Returns:
            Clan statistics
        """
        url = f"{self.BASE_URLS['osiris']}/clans/{clan_id}/statistics"
        return self._make_request("GET", url)
    
    def get_clan_leaderboard(self, clan_id: str) -> List[Dict[str, Any]]:
        """
        Get clan internal leaderboard.
        
        Args:
            clan_id: Clan ID
            
        Returns:
            Clan leaderboard data
        """
        url = f"{self.BASE_URLS['osiris']}/clans/{clan_id}/leaderboard"
        response = self._make_request("GET", url)
        return response.get("leaderboard", [])
    
    def search_clans(self, query: str, limit: int = 20) -> List[Dict[str, Any]]:
        """
        Search for clans.
        
        Args:
            query: Search query
            limit: Maximum number of results
            
        Returns:
            List of matching clans
        """
        url = f"{self.BASE_URLS['osiris']}/clans/search"
        params = {
            "q": query,
            "limit": limit
        }
        response = self._make_request("GET", url, params=params)
        return response.get("clans", [])
    
    def create_clan(self, name: str, tag: str, description: str = "", membership_type: str = "open") -> Dict[str, Any]:
        """
        Create a new clan.
        
        Args:
            name: Clan name
            tag: Clan tag (short identifier)
            description: Clan description
            membership_type: Membership type (open, closed, invite_only)
            
        Returns:
            Created clan data
        """
        url = f"{self.BASE_URLS['osiris']}/clans"
        data = {
            "name": name,
            "tag": tag,
            "description": description,
            "membership_type": membership_type
        }
        return self._make_request("POST", url, data=data)
    
    def disband_clan(self, clan_id: str) -> Dict[str, Any]:
        """
        Disband a clan (leader only).
        
        Args:
            clan_id: Clan ID
            
        Returns:
            Disband result
        """
        url = f"{self.BASE_URLS['osiris']}/clans/{clan_id}"
        return self._make_request("DELETE", url)
    
    def transfer_clan_ownership(self, clan_id: str, new_leader_credential: str) -> Dict[str, Any]:
        """
        Transfer clan ownership to another member.
        
        Args:
            clan_id: Clan ID
            new_leader_credential: Credential of new leader
            
        Returns:
            Transfer result
        """
        url = f"{self.BASE_URLS['osiris']}/clans/{clan_id}/ownership"
        data = {"new_leader": new_leader_credential}
        return self._make_request("POST", url, data=data)
    
    # Group/Squad Management
    
    def get_group_members(self, group_id: str, offset: int = 0) -> List[Dict[str, Any]]:
        """
        Get all members of a group/squad.
        
        Args:
            group_id: Group/Squad ID
            offset: Pagination offset (default: 0)
            
        Returns:
            List of group members with their stats and status
        """
        url = f"{self.BASE_URLS['osiris']}/groups/{group_id}/members"
        params = {
            "group_id": group_id,
            "offset": offset
        }
        response = self._make_request("GET", url, params=params)
        return response if isinstance(response, list) else []
    
    def update_group_member_stats(self, group_id: str, credential: str, **stats) -> Dict[str, Any]:
        """
        Update a group member's stats (score, XP, kill signature, etc.).
        
        Args:
            group_id: Group/Squad ID
            credential: Member credential to update
            **stats: Stats to update (_score, _xp, _killsig_id, _killsig_color, etc.)
            
        Returns:
            Update result
        """
        url = f"{self.BASE_URLS['osiris']}/groups/{group_id}/members/{credential}"
        
        # Prepare data for form-encoded request
        data = {
            "operation": "update",
            "credential": credential
        }
        data.update(stats)
        
        return self._make_request("POST", url, data=data)
    
    def update_member_score(self, group_id: str, credential: str, score: int) -> Dict[str, Any]:
        """
        Update a member's score in the group.
        
        Args:
            group_id: Group/Squad ID
            credential: Member credential
            score: New score value
            
        Returns:
            Update result
        """
        return self.update_group_member_stats(group_id, credential, _score=str(score))
    
    def update_member_xp(self, group_id: str, credential: str, xp: int) -> Dict[str, Any]:
        """
        Update a member's XP in the group.
        
        Args:
            group_id: Group/Squad ID
            credential: Member credential
            xp: New XP value
            
        Returns:
            Update result
        """
        return self.update_group_member_stats(group_id, credential, _xp=str(xp))
    
    def update_member_killsig(self, group_id: str, credential: str, killsig_id: str, killsig_color: str) -> Dict[str, Any]:
        """
        Update a member's kill signature.
        
        Args:
            group_id: Group/Squad ID
            credential: Member credential
            killsig_id: Kill signature ID
            killsig_color: Kill signature color
            
        Returns:
            Update result
        """
        return self.update_group_member_stats(
            group_id, 
            credential, 
            _killsig_id=killsig_id,
            _killsig_color=killsig_color
        )
    
    def get_member_by_credential(self, group_id: str, credential: str) -> Optional[Dict[str, Any]]:
        """
        Get a specific member's information by credential.
        
        Args:
            group_id: Group/Squad ID
            credential: Member credential
            
        Returns:
            Member information or None if not found
        """
        members = self.get_group_members(group_id)
        for member in members:
            if member.get("credential") == credential:
                return member
        return None
    
    def get_online_members(self, group_id: str) -> List[Dict[str, Any]]:
        """
        Get all online members in a group.
        
        Args:
            group_id: Group/Squad ID
            
        Returns:
            List of online members
        """
        members = self.get_group_members(group_id)
        return [member for member in members if member.get("online", False)]
    
    def get_group_statistics(self, group_id: str) -> Dict[str, Any]:
        """
        Calculate group statistics from member data.
        
        Args:
            group_id: Group/Squad ID
            
        Returns:
            Group statistics (total members, online count, average score, etc.)
        """
        members = self.get_group_members(group_id)
        
        if not members:
            return {
                "total_members": 0,
                "online_members": 0,
                "offline_members": 0,
                "average_score": 0,
                "total_score": 0,
                "average_xp": 0,
                "total_xp": 0
            }
        
        online_count = sum(1 for member in members if member.get("online", False))
        scores = [int(member.get("_score", 0)) for member in members if member.get("_score")]
        xp_values = [int(member.get("_xp", 0)) for member in members if member.get("_xp")]
        
        return {
            "total_members": len(members),
            "online_members": online_count,
            "offline_members": len(members) - online_count,
            "average_score": sum(scores) / len(scores) if scores else 0,
            "total_score": sum(scores),
            "average_xp": sum(xp_values) / len(xp_values) if xp_values else 0,
            "total_xp": sum(xp_values)
        }
    
    def send_squad_wall_message(self, clan_id: str, message: str, msg_type: int = 0, 
                               player_killsig: str = None, player_killsig_color: str = None,
                               language: str = "en", activity_type: str = "user_post") -> Dict[str, Any]:
        """
        Send a message to the squad/group wall.
        
        Args:
            clan_id: Group/Squad ID
            message: Message content
            msg_type: Message type (0 for regular message)
            player_killsig: Player kill signature ID (optional)
            player_killsig_color: Player kill signature color (optional)
            language: Message language (default: "en")
            activity_type: Activity type (default: "user_post")
            
        Returns:
            Message post result with message ID
        """
        url = f"{self.BASE_URLS['osiris']}/groups/{clan_id}/wall"
        
        # Create message data
        message_data = {
            "msg_body": message,
            "msg_type": msg_type
        }
        
        # Add kill signature if provided
        if player_killsig:
            message_data["playerKillSign"] = player_killsig
        if player_killsig_color is not None:
            message_data["playerKillSignColor"] = player_killsig_color
        
        # Convert to JSON string as required by API
        import json
        text_json = json.dumps(message_data)
        
        # Prepare form data
        data = {
            "text": text_json + "\n",
            "language": language,
            "activity_type": activity_type,
            "alert_kairos": "false"
        }
        
        return self._make_request("POST", url, data=data)
    
    def get_squad_wall_messages(self, clan_id: str, limit: int = 20) -> List[Dict[str, Any]]:
        """
        Get messages from the squad wall.
        
        Args:
            clan_id: Group/Squad ID
            limit: Maximum number of messages to retrieve
            
        Returns:
            List of wall messages
        """
        url = f"{self.BASE_URLS['osiris']}/groups/{clan_id}/wall"
        params = {
            "limit": limit
        }
        response = self._make_request("GET", url, params=params)
        return response if isinstance(response, list) else []
    
    def delete_squad_wall_message(self, clan_id: str, message_id: str) -> Dict[str, Any]:
        """
        Delete a message from the squad wall.
        
        Args:
            clan_id: Group/Squad ID
            message_id: Message ID to delete
            
        Returns:
            Deletion result
        """
        url = f"{self.BASE_URLS['osiris']}/groups/{clan_id}/wall/{message_id}"
        return self._make_request("DELETE", url)
    
    # Private Messaging
    
    def send_private_message(self, credential: str, message: str, reply_to: str = None, 
                               kill_sign_color: str = None, kill_sign_name: str = None,
                               message_type: str = "inbox", alert_kairos: bool = False) -> Dict[str, Any]:
        """
        Send a private message to a player.
        
        Args:
            credential: Recipient credential
            message: Message content
            reply_to: Message ID to reply to (optional)
            kill_sign_color: Kill signature color (optional)
            kill_sign_name: Kill signature name (optional)
            message_type: Message type (default: "inbox")
            alert_kairos: Whether to send alert notification (default: False)
            
        Returns:
            Message send result
        """
        url = f"{self.BASE_URLS['hermes']}/messages/inbox/{credential}"
        
        # Create message data
        message_data = {
            "body": message,
            "_type": message_type
        }
        
        # Add reply_to if provided
        if reply_to:
            message_data["reply_to"] = reply_to
        
        # Add kill signature if provided
        if kill_sign_color is not None:
            message_data["_killSignColor"] = kill_sign_color
        if kill_sign_name:
            message_data["_killSignName"] = kill_sign_name
        
        # Convert to JSON string as required by API
        import json
        body_json = json.dumps(message_data)
        
        # Prepare form data
        data = {
            "from": "RxZ Saitama",  # Replace with actual sender name
            "body": body_json + "\n",
            "alert_kairos": str(alert_kairos).lower()
        }
        
        return self._make_request("POST", url, data=data)
    
    def get_inbox_messages(self, limit: int = 20) -> List[Dict[str, Any]]:
        """
        Get messages from your inbox.
        
        Args:
            limit: Maximum number of messages to retrieve
            
        Returns:
            List of inbox messages
        """
        url = f"{self.BASE_URLS['hermes']}/messages/inbox"
        params = {
            "limit": limit
        }
        response = self._make_request("GET", url, params=params)
        return response if isinstance(response, list) else []
    
    def delete_inbox_message(self, message_id: str) -> Dict[str, Any]:
        """
        Delete a message from your inbox.
        
        Args:
            message_id: Message ID to delete
            
        Returns:
            Deletion result
        """
        url = f"{self.BASE_URLS['hermes']}/messages/inbox/me"
        params = {
            "msgids": message_id
        }
        return self._make_request("DELETE", url, params=params)
    
    def delete_multiple_inbox_messages(self, message_ids: List[str]) -> Dict[str, Any]:
        """
        Delete multiple messages from your inbox at once.
        
        Args:
            message_ids: List of message IDs to delete
            
        Returns:
            Deletion result
        """
        url = f"{self.BASE_URLS['hermes']}/messages/inbox/me"
        params = {
            "msgids": ",".join(message_ids)
        }
        return self._make_request("DELETE", url, params=params)
    
    def clear_inbox(self) -> Dict[str, Any]:
        """
        Clear all messages from your inbox.
        
        Returns:
            Deletion result
        """
        # Get all messages first
        messages = self.get_inbox_messages(limit=1000)  # Get up to 1000 messages
        if messages:
            message_ids = [msg.get('id', '') for msg in messages if msg.get('id')]
            return self.delete_multiple_inbox_messages(message_ids)
        return {"status": "success", "message": "No messages to delete"}
    
    def remove_friend(self, target_user_id: str, message: str = "removed", 
                     killsig_color: str = None, killsig_name: str = None) -> Dict[str, Any]:
        """
        Send a friend removal notification message.
        
        Args:
            target_user_id: Target player's user ID
            message: Message content (default: "removed")
            killsig_color: Kill signature color (optional)
            killsig_name: Kill signature name (optional)
            
        Returns:
            Message result
        """
        url = f"{self.BASE_URLS['hermes']}/messages/inbox/{quote(target_user_id)}"
        headers = {
            'Content-Type': 'application/x-www-form-urlencoded'
        }
        
        data = {
            'access_token': self._token_data["access_token"],
            'from': self.get_profile().get('credential', ''),
            'body': message,
            'reply_to': target_user_id,
            '_type': 'friendRemoved',
            'type': 'friendRemoved'
        }
        
        # Add optional parameters
        if killsig_color:
            data['_killSignColor'] = killsig_color
            data['killSignColor'] = killsig_color
        if killsig_name:
            data['_killSignName'] = killsig_name
            data['killSignName'] = killsig_name
        
        response = self._make_request("POST", url, data=data)
        return response
    
    def delete_friend_connection(self, target_user_id: str) -> Dict[str, Any]:
        """
        Delete a friend connection (actual removal from friends list).
        
        Args:
            target_user_id: Target player's user ID
            
        Returns:
            Deletion result
        """
        url = f"{self.BASE_URLS['osiris']}/accounts/me/connections/friend/{quote(target_user_id)}/delete"
        headers = {
            'Content-Type': 'application/x-www-form-urlencoded'
        }
        
        data = {
            'access_token': self._token_data["access_token"],
            'target_credential': target_user_id
        }
        
        response = self._make_request("POST", url, data=data)
        return response
    
    def send_friend_request(self, target_user_id: str, alert_kairos: bool = True) -> Dict[str, Any]:
        """
        Send a friend request to another player.
        
        Args:
            target_user_id: Target player's user ID
            alert_kairos: Whether to send alert notification
            
        Returns:
            Friend request result
        """
        url = f"{self.BASE_URLS['osiris']}/accounts/me/connections/friend"
        headers = {
            'Content-Type': 'application/x-www-form-urlencoded'
        }
        
        data = {
            'access_token': self._token_data["access_token"],
            'target_credential': target_user_id,
            'requester_credential': self.get_profile().get('credential', ''),
            'alert_kairos': str(alert_kairos).lower()
        }
        
        response = self._make_request("POST", url, data=data)
        return response
    
    def get_friend_connection_status(self, target_user_id: str) -> Dict[str, Any]:
        """
        Get the connection status with a specific friend.
        
        Args:
            target_user_id: Target player's user ID
            
        Returns:
            Connection status information
        """
        url = f"{self.BASE_URLS['osiris']}/accounts/me/connections/friend/{quote(target_user_id)}"
        params = {
            'access_token': self._token_data["access_token"],
            'target_credential': target_user_id
        }
        
        response = self._make_request("GET", url, params=params)
        return response
    
    def accept_friend_request(self, request_id: str) -> Dict[str, Any]:
        """
        Accept an incoming friend request.
        
        Args:
            request_id: Friend request ID to accept
            
        Returns:
            Accept result with connection details
        """
        url = f"{self.BASE_URLS['osiris']}/accounts/me/requests/{request_id}/accept"
        return self._make_request("POST", url)
    
    def send_squad_wall_message(self, clan_id: str, message: str, msg_type: int = 0, 
                               player_killsig: str = None, player_killsig_color: str = None,
                               language: str = "en", activity_type: str = "user_post") -> Dict[str, Any]:
        """
        Send a message to the squad/group wall.
        
        Args:
            clan_id: Group/Squad ID
            message: Message content
            msg_type: Message type (0 for regular message)
            player_killsig: Player kill signature ID (optional)
            player_killsig_color: Player kill signature color (optional)
            language: Message language (default: "en")
            activity_type: Activity type (default: "user_post")
            
        Returns:
            Message post result with message ID
        """
        url = f"{self.BASE_URLS['osiris']}/groups/{clan_id}/wall"
        
        # Create message data
        message_data = {
            "msg_body": message,
            "msg_type": msg_type
        }
        
        # Add kill signature if provided
        if player_killsig:
            message_data["playerKillSign"] = player_killsig
        if player_killsig_color is not None:
            message_data["playerKillSignColor"] = player_killsig_color
        
        # Convert to JSON string as required by API
        import json
        text_json = json.dumps(message_data)
        
        # Prepare form data
        data = {
            "text": text_json + "\n",
            "language": language,
            "activity_type": activity_type,
            "alert_kairos": "false"
        }
        
        return self._make_request("POST", url, data=data)
    
    # Friend Management
    
    def get_friends(self) -> List[Dict[str, Any]]:
        """
        Get friends list.
        
        Returns:
            List of friends
        """
        url = f"{self.BASE_URLS['osiris']}/accounts/me/friends"
        response = self._make_request("GET", url)
        return response.get("friends", [])
    
    def check_friend_status(self, credential: str) -> Dict[str, Any]:
        """
        Check friend connection status.
        
        Args:
            credential: Target player credential
            
        Returns:
            Friend status information
        """
        url = f"{self.BASE_URLS['osiris']}/accounts/me/connections/friend/{credential}"
        return self._make_request("GET", url)
    
    # Messaging
    
    def send_squad_wall_message(self, clan_id: str, message: str) -> Dict[str, Any]:
        """
        Send message to squad wall.
        
        Args:
            clan_id: Clan ID
            message: Message content
            
        Returns:
            Message send result
        """
        url = f"{self.BASE_URLS['osiris']}/clans/{clan_id}/wall"
        data = {"message": message}
        return self._make_request("POST", url, data=data)
    
    # Events
    
    def get_events(self) -> List[Dict[str, Any]]:
        """
        Get list of active events.
        
        Returns:
            List of events
        """
        url = f"{self.BASE_URLS['osiris']}/events"
        response = self._make_request("GET", url)
        return response if isinstance(response, list) else response.get("events", [])
    
    def get_event_details(self, event_name: str) -> Dict[str, Any]:
        """
        Get details for a specific event.
        
        Args:
            event_name: Event name
            
        Returns:
            Event details
        """
        events = self.get_events()
        for event in events:
            if event.get("name") == event_name:
                return event
        raise MC5APIError(f"Event '{event_name}' not found")
    
    def sign_up_for_event(self, event_id: str) -> Dict[str, Any]:
        """
        Sign up for an event.
        
        Args:
            event_id: Event ID to sign up for
            
        Returns:
            Signup result
        """
        url = f"{self.BASE_URLS['osiris']}/events/{event_id}/participants/me"
        return self._make_request("POST", url)
    
    def get_event_leaderboard(self, event_id: str, offset: int = 0, limit: int = 100) -> Dict[str, Any]:
        """
        Get the leaderboard for a specific event.
        
        Args:
            event_id: Event ID
            offset: Pagination offset (default: 0)
            limit: Number of entries to retrieve (default: 100)
            
        Returns:
            Event leaderboard data
        """
        url = f"{self.BASE_URLS['olympus']}/leaderboards/desc/Leaderboard_{event_id}"
        params = {
            "offset": str(offset),
            "limit": str(limit)
        }
        return self._make_request("GET", url, params=params)
    
    def get_my_event_leaderboard_entry(self, event_id: str, limit: int = 5) -> Dict[str, Any]:
        """
        Get your entry and surrounding players in the event leaderboard.
        
        Args:
            event_id: Event ID
            limit: Number of surrounding entries to show (default: 5)
            
        Returns:
            Your leaderboard entry with surrounding players
        """
        url = f"{self.BASE_URLS['olympus']}/leaderboards/desc/Leaderboard_{event_id}/me"
        params = {
            "limit": str(limit)
        }
        return self._make_request("GET", url, params=params)
    
    # Squad/Group Management
    
    def get_squad_invitations(self) -> List[Dict[str, Any]]:
        """
        Get all pending squad invitations.
        
        Returns:
            List of squad invitations
        """
        url = f"{self.BASE_URLS['osiris']}/accounts/me/requests"
        params = {
            "request_type": "group_invitation"
        }
        response = self._make_request("GET", url, params=params)
        return response if isinstance(response, list) else []
    
    def accept_squad_invitation(self, group_id: str, credential: str, 
                              killsig_color: str = None, killsig_id: str = None,
                              score: str = None, xp: str = None) -> Dict[str, Any]:
        """
        Accept a squad invitation and join the squad.
        
        Args:
            group_id: Squad/group ID
            credential: Your credential (user ID)
            killsig_color: Kill signature color (optional)
            killsig_id: Kill signature ID (optional)
            score: Your score (optional)
            xp: Your XP (optional)
            
        Returns:
            Accept result
        """
        url = f"{self.BASE_URLS['osiris']}/groups/{group_id}/members/{quote(credential)}"
        data = {
            "credential": credential,
            "operation": "update"
        }
        
        # Add optional parameters
        if killsig_color is not None:
            data["_killsig_color"] = str(killsig_color)
        if killsig_id is not None:
            data["_killsig_id"] = killsig_id
        if score is not None:
            data["_score"] = str(score)
        if xp is not None:
            data["_xp"] = str(xp)
        
        return self._make_request("POST", url, data=data)
    
    def delete_squad_invitation_message(self, message_id: str) -> Dict[str, Any]:
        """
        Delete a squad invitation message after accepting/declining.
        
        Args:
            message_id: Message ID to delete
            
        Returns:
            Delete result
        """
        url = f"{self.BASE_URLS['hermes']}/messages/inbox/me"
        params = {
            "msgids": message_id
        }
        return self._make_request("DELETE", url, params=params)
    
    def decline_squad_invitation(self, message_id: str) -> Dict[str, Any]:
        """
        Decline a squad invitation by rejecting the request.
        
        Args:
            message_id: Message ID to decline/reject
            
        Returns:
            Decline result
        """
        # Use the correct endpoint to actually reject the invitation
        url = f"{self.BASE_URLS['osiris']}/accounts/me/requests/{message_id}/reject"
        return self._make_request("POST", url)
    
    # Leaderboard
    
    def get_leaderboard(self, leaderboard_type: str = "ro") -> Dict[str, Any]:
        """
        Get leaderboard data.
        
        Args:
            leaderboard_type: Leaderboard type (ro for read-only, admin for admin)
            
        Returns:
            Leaderboard data
        """
        if leaderboard_type == "admin":
            url = f"{self.BASE_URLS['olympus']}/leaderboards/desc"
        else:
            url = f"{self.BASE_URLS['osiris']}/accounts/leaderboard_{leaderboard_type}"
        
        return self._make_request("GET", url)
    
    # Game Configuration
    
    def get_game_object_catalog(self) -> List[Dict[str, Any]]:
        """
        Get game object catalog.
        
        Returns:
            List of game objects
        """
        url = f"{self.BASE_URLS['iris']}/1875/game_object_{int(time.time())}"
        response = self._make_request("GET", url, require_token=False)
        return response if isinstance(response, list) else []
    
    def get_asset_hash_metadata(self, asset_path: str) -> Dict[str, Any]:
        """
        Get asset hash metadata.
        
        Args:
            asset_path: Asset path
            
        Returns:
            Asset metadata
        """
        url = f"{self.BASE_URLS['iris']}/assets/{asset_path}/metadata/hash"
        return self._make_request("GET", url, require_token=False)
    
    # Alias and Dogtags
    
    def get_alias_info(self, alias_id: str) -> Dict[str, Any]:
        """
        Retrieve player information using alias/dogtag.
        
        Args:
            alias_id: Alias or dogtag identifier
            
        Returns:
            Player information including credential and account ID
        """
        url = f"{self.BASE_URLS['janus']}/games/mygame/alias/{alias_id}"
        params = {
            "access_token": self._token_data["access_token"]
        }
        
        return self._make_request("GET", url, params=params)
    
    def convert_dogtag_to_alias(self, dogtag: str) -> str:
        """
        Convert dogtag to alias.
        
        Args:
            dogtag: Dogtag string
            
        Returns:
            Alias string
        """
        alias = ""
        for char in dogtag.lower():
            if char.isdigit():
                # Digit conversion: (digit - 2) modulo 10
                alias_char = str((int(char) - 2) % 10)
            elif char.isalpha():
                # Letter conversion: subtract 2 from ASCII value
                alias_char = chr(ord(char) - 2)
            else:
                alias_char = char
            alias += alias_char
        return alias
    
    # Utility Methods
    
    def close(self):
        """Close the HTTP session and cleanup resources."""
        if self.session:
            self.session.close()
        if self.token_generator:
            self.token_generator.close()
    
    # Server Status Methods (for compatibility)
    
    def get_server_status(self) -> Dict[str, Any]:
        """
        Get server status information.
        
        Returns:
            Dictionary with server status
        """
        try:
            # Try to get events as a basic connectivity test
            events = self.get_events()
            return {
                "status": "online",
                "message": "MC5 servers are online",
                "events_count": len(events),
                "timestamp": time.time()
            }
        except Exception as e:
            return {
                "status": "offline",
                "message": f"Server status check failed: {str(e)}",
                "timestamp": time.time()
            }
    
    def get_online_players(self) -> Dict[str, Any]:
        """
        Get online players information (estimated).
        
        Returns:
            Dictionary with online player count
        """
        try:
            # Get events as a proxy for activity
            events = self.get_events()
            # This is an estimate - actual player count isn't directly available
            return {
                "online_players": "Unknown",
                "active_events": len(events),
                "message": "Player count not directly available via API",
                "timestamp": time.time()
            }
        except Exception as e:
            return {
                "online_players": 0,
                "error": str(e),
                "timestamp": time.time()
            }
    
    def get_server_info(self) -> Dict[str, Any]:
        """
        Get general server information.
        
        Returns:
            Dictionary with server information
        """
        try:
            return {
                "server": "Modern Combat 5",
                "region": "Europe",
                "api_version": "1.0.18",
                "endpoints": list(self.BASE_URLS.keys()),
                "client_id": self.client_id,
                "authenticated": bool(self.access_token),
                "timestamp": time.time()
            }
        except Exception as e:
            return {
                "error": str(e),
                "timestamp": time.time()
            }
    
    # Automatic Squad Management (NEW!)
    
    def get_my_squad_id(self) -> Optional[str]:
        """
        Automatically fetch the user's squad ID from their profile.
        
        This method eliminates the need to manually specify squad ID for squad operations.
        It fetches the user's profile and extracts the squad/group ID from their groups.
        
        Returns:
            Squad ID if found, None otherwise
        """
        try:
            # Get user profile which contains groups information
            profile = self.get_profile()
            
            if not profile:
                return None
                
            # Check if user has groups
            groups = profile.get('groups', [])
            if not groups:
                return None
            
            # Extract squad ID from groups (usually the first group is the squad)
            # Groups can be in different formats, handle multiple cases
            for group in groups:
                if isinstance(group, str):
                    # Simple string ID
                    return group
                elif isinstance(group, dict):
                    # Dictionary with ID field
                    if 'id' in group:
                        return group['id']
                    elif '_id' in group:
                        return group['_id']
                    elif 'group_id' in group:
                        return group['group_id']
            
            # If no group found in the expected format, try to extract from the groups string
            if groups and isinstance(groups[0], str):
                return groups[0]
                
            return None
            
        except Exception as e:
            print(f"🔴 Error fetching squad ID: {e}")
            return None
    
    def get_my_squad_info(self) -> Dict[str, Any]:
        """
        Get complete squad information using automatically fetched squad ID.
        
        Returns:
            Dictionary with squad information or error details
        """
        try:
            squad_id = self.get_my_squad_id()
            if not squad_id:
                return {
                    "error": "No squad found for this user",
                    "message": "User is not in any squad",
                    "timestamp": time.time()
                }
            
            # Get squad information using the fetched ID
            squad_info = self.get_clan_settings(squad_id)
            
            if squad_info:
                squad_info['auto_fetched_squad_id'] = squad_id
                squad_info['fetch_method'] = 'automatic'
                return squad_info
            else:
                return {
                    "error": "Failed to fetch squad details",
                    "squad_id": squad_id,
                    "message": "Squad ID found but could not fetch details",
                    "timestamp": time.time()
                }
                
        except Exception as e:
            return {
                "error": str(e),
                "message": "Failed to get squad information",
                "timestamp": time.time()
            }
    
    def update_my_squad_info(self, **kwargs) -> Dict[str, Any]:
        """
        Update squad information using automatically fetched squad ID.
        
        This is a convenience method that combines get_my_squad_id() and update_clan_settings().
        Users don't need to specify squad ID - it's automatically fetched from their profile.
        
        Args:
            **kwargs: Squad settings to update (same as update_clan_settings)
                - name: Squad name
                - description: Squad description  
                - rating: Squad rating
                - min_join_value: Minimum join value
                - logo: Squad logo ID
                - logo_clr_prim: Primary logo color
                - logo_clr_sec: Secondary logo color
        
        Returns:
            Dictionary with update result or error details
        """
        try:
            squad_id = self.get_my_squad_id()
            if not squad_id:
                return {
                    "error": "No squad found for this user",
                    "message": "Cannot update squad - user is not in any squad",
                    "timestamp": time.time()
                }
            
            # Update squad using the fetched ID
            result = self.update_clan_settings(squad_id, **kwargs)
            
            if result:
                result['auto_fetched_squad_id'] = squad_id
                result['update_method'] = 'automatic'
                return result
            else:
                return {
                    "error": "Failed to update squad",
                    "squad_id": squad_id,
                    "message": "Squad ID found but update failed",
                    "timestamp": time.time()
                }
                
        except Exception as e:
            return {
                "error": str(e),
                "message": "Failed to update squad information",
                "timestamp": time.time()
            }
    
    def get_my_squad_members(self) -> Dict[str, Any]:
        """
        Get squad members using automatically fetched squad ID.
        
        Returns:
            Dictionary with squad members or error details
        """
        try:
            squad_id = self.get_my_squad_id()
            if not squad_id:
                return {
                    "error": "No squad found for this user",
                    "message": "Cannot get squad members - user is not in any squad",
                    "timestamp": time.time()
                }
            
            # Get squad members using the fetched ID
            members = self.get_clan_members(squad_id)
            
            if members:
                return {
                    "squad_id": squad_id,
                    "members": members,
                    "member_count": len(members) if isinstance(members, list) else 0,
                    "fetch_method": "automatic",
                    "timestamp": time.time()
                }
            else:
                return {
                    "error": "Failed to fetch squad members",
                    "squad_id": squad_id,
                    "message": "Squad ID found but could not fetch members",
                    "timestamp": time.time()
                }
                
        except Exception as e:
            return {
                "error": str(e),
                "message": "Failed to get squad members",
                "timestamp": time.time()
            }
    
    # Squad Customization Helpers (NEW!)
    
    def calculate_xp_for_level(self, level: int) -> int:
        """
        Calculate XP required for a specific squad level.
        
        Level System:
        - Level 1: 1000 XP
        - Level 2: 2000 XP
        - ...
        - Level 10: 10000 XP (maximum)
        
        Args:
            level: Desired level (1-10)
            
        Returns:
            XP value for the level
        """
        if level < 1:
            level = 1
        elif level > 10:
            level = 10
        
        return level * 1000
    
    def get_color_value(self, color_name: str) -> str:
        """
        Get color value for common colors.
        
        Args:
            color_name: Name of the color
            
        Returns:
            Color value in decimal format
        """
        colors = {
            'black': '0',
            'white': '16777215',
            'red': '16711680',
            'green': '65280',
            'blue': '255',
            'yellow': '16776960',
            'purple': '16711808',
            'orange': '16753920',
            'pink': '16761035',
            'cyan': '65535',
            'lime': '65280',
            'navy': '128',
            'gold': '16766720',
            'silver': '12632256',
            'maroon': '8388608',
            'teal': '32768',
            'olive': '8421376'
        }
        
        return colors.get(color_name.lower(), '0')
    
    def customize_squad_theme(self, theme_name: str, squad_name: str = None) -> Dict[str, Any]:
        """
        Apply a predefined color theme to your squad.
        
        Args:
            theme_name: Name of the theme ('dark', 'fire', 'ice', 'nature')
            squad_name: Optional custom squad name
            
        Returns:
            Dictionary with update result or error details
        """
        themes = {
            'dark': {
                '_logo_clr_prim': self.get_color_value('black'),
                '_logo_clr_sec': self.get_color_value('white'),
                'name': squad_name or 'Dark Knights'
            },
            'fire': {
                '_logo_clr_prim': self.get_color_value('red'),
                '_logo_clr_sec': self.get_color_value('orange'),
                'name': squad_name or 'Fire Warriors'
            },
            'ice': {
                '_logo_clr_prim': self.get_color_value('blue'),
                '_logo_clr_sec': self.get_color_value('cyan'),
                'name': squad_name or 'Ice Legion'
            },
            'nature': {
                '_logo_clr_prim': self.get_color_value('green'),
                '_logo_clr_sec': self.get_color_value('lime'),
                'name': squad_name or 'Nature Guardians'
            }
        }
        
        theme = themes.get(theme_name.lower())
        if not theme:
            return {
                "error": f"Unknown theme: {theme_name}",
                "available_themes": list(themes.keys()),
                "timestamp": time.time()
            }
        
        return self.update_my_squad_info(**theme)
    
    def set_squad_level(self, level: int, squad_name: str = None) -> Dict[str, Any]:
        """
        Set squad to a specific level with appropriate settings.
        
        Args:
            level: Desired level (1-10)
            squad_name: Optional custom squad name
            
        Returns:
            Dictionary with update result or error details
        """
        if level < 1 or level > 10:
            return {
                "error": "Level must be between 1 and 10",
                "timestamp": time.time()
            }
        
        updates = {
            "name": squad_name or f"Level {level} Squad",
            "_xp": self.calculate_xp_for_level(level),
            "rating": level * 500,
            "_min_join_value": level * 100,
            "member_limit": 20 + (level * 5),
            "description": f"Elite squad at Level {level}!"
        }
        
        return self.update_my_squad_info(**updates)
    
    def customize_squad_complete(self, **kwargs) -> Dict[str, Any]:
        """
        Customize squad with any parameters and validation.
        
        Args:
            **kwargs: Any squad parameters to update
            
        Available parameters:
        - name: Squad name
        - description: Squad description
        - rating: Squad rating
        - score: Squad score
        - member_limit: Maximum members (1-300)
        - membership: Membership type ('open' or 'owner_approved')
        - _logo: Logo ID
        - _logo_clr_prim: Primary color (RGB decimal 0-16777215)
        - _logo_clr_sec: Secondary color (RGB decimal 0-16777215)
        - _min_join_value: Minimum join value
        - _xp: Squad XP (1000-10000, determines level)
        - _killsig_id: Kill signature ID
        - currency: Squad currency
        - active_clan_label: Active clan label
        - active_clan_threshold: Active clan threshold
        
        Returns:
            Dictionary with update result or error details
        """
        # Validate data
        errors = []
        
        # Validate XP/Level
        if '_xp' in kwargs:
            try:
                xp = int(kwargs['_xp'])
                if xp < 1000 or xp > 10000:
                    errors.append("XP must be between 1000 (Level 1) and 10000 (Level 10)")
            except ValueError:
                errors.append("_xp must be a valid number")
        
        # Validate member limit
        if 'member_limit' in kwargs:
            try:
                limit = int(kwargs['member_limit'])
                if limit < 1 or limit > 300:
                    errors.append("Member limit must be between 1 and 300")
            except ValueError:
                errors.append("member_limit must be a valid number")
        
        # Validate colors
        for color_key in ['_logo_clr_prim', '_logo_clr_sec']:
            if color_key in kwargs:
                try:
                    color = int(kwargs[color_key])
                    if color < 0 or color > 16777215:  # RGB max value
                        errors.append(f"{color_key} must be between 0 and 16777215")
                except ValueError:
                    errors.append(f"{color_key} must be a valid number")
        
        # Validate rating
        if 'rating' in kwargs:
            try:
                rating = int(kwargs['rating'])
                if rating < 0 or rating > 99999:
                    errors.append("Rating must be between 0 and 99999")
            except ValueError:
                errors.append("rating must be a valid number")
        
        if errors:
            return {
                "error": "Validation failed",
                "validation_errors": errors,
                "timestamp": time.time()
            }
        
        # Apply updates
        return self.update_my_squad_info(**kwargs)
    
    # Quick Squad Customization Functions (NEW!)
    
    def quick_set_name(self, name: str) -> Dict[str, Any]:
        """
        Quickly set squad name.
        
        Args:
            name: New squad name
            
        Returns:
            Dictionary with update result or error details
        """
        return self.update_my_squad_info(name=name)
    
    def quick_set_rating(self, rating: int) -> Dict[str, Any]:
        """
        Quickly set squad rating.
        
        Args:
            rating: New squad rating (0-99999)
            
        Returns:
            Dictionary with update result or error details
        """
        return self.update_my_squad_info(rating=rating)
    
    def quick_set_member_limit(self, limit: int) -> Dict[str, Any]:
        """
        Quickly set member limit.
        
        Args:
            limit: New member limit (1-300)
            
        Returns:
            Dictionary with update result or error details
        """
        return self.update_my_squad_info(member_limit=limit)
    
    def quick_set_colors(self, primary_color: str, secondary_color: str = None) -> Dict[str, Any]:
        """
        Quickly set squad colors using color names.
        
        Args:
            primary_color: Primary color name
            secondary_color: Secondary color name (optional)
            
        Returns:
            Dictionary with update result or error details
        """
        updates = {
            "_logo_clr_prim": self.get_color_value(primary_color)
        }
        
        if secondary_color:
            updates["_logo_clr_sec"] = self.get_color_value(secondary_color)
        
        return self.update_my_squad_info(**updates)
    
    def quick_set_level(self, level: int, name: str = None) -> Dict[str, Any]:
        """
        Quickly set squad to specific level.
        
        Args:
            level: Desired level (1-10)
            name: Optional custom squad name
            
        Returns:
            Dictionary with update result or error details
        """
        return self.set_squad_level(level, name)
    
    def quick_set_currency(self, amount: int) -> Dict[str, Any]:
        """
        Quickly set squad currency.
        
        Args:
            amount: Currency amount
            
        Returns:
            Dictionary with update result or error details
        """
        return self.update_my_squad_info(currency=str(amount))
    
    def quick_setup_professional_squad(self, name: str, level: int = 8) -> Dict[str, Any]:
        """
        Quick setup for professional squad with optimal settings.
        
        Args:
            name: Squad name
            level: Squad level (1-10)
            
        Returns:
            Dictionary with update result or error details
        """
        return self.customize_squad_complete(
            name=name,
            _xp=self.calculate_xp_for_level(level),
            rating=level * 1000,
            member_limit=50 + (level * 10),
            membership="owner_approved",
            _min_join_value=level * 200,
            description=f"Professional squad at Level {level}!",
            currency=str(level * 5000),
            active_clan_label="true"
        )
    
    def quick_setup_gaming_squad(self, name: str, theme: str = "fire") -> Dict[str, Any]:
        """
        Quick setup for gaming squad with theme.
        
        Args:
            name: Squad name
            theme: Color theme ('fire', 'ice', 'dark', 'nature')
            
        Returns:
            Dictionary with update result or error details
        """
        # Apply theme first
        theme_result = self.customize_squad_theme(theme, name)
        
        if theme_result and 'error' not in theme_result:
            # Add gaming-specific settings
            gaming_updates = {
                "membership": "owner_approved",
                "min_join_value": 1000,
                "currency": "10000",
                "active_clan_label": "true"
            }
            
            return self.update_my_squad_info(**gaming_updates)
        
        return theme_result
    
    def quick_reset_to_defaults(self) -> Dict[str, Any]:
        """
        Quick reset squad to default settings.
        
        Returns:
            Dictionary with update result or error details
        """
        return self.customize_squad_complete(
            name="Default Squad",
            description="Default squad description",
            rating=1000,
            member_limit=30,
            membership="open",
            _logo="1",
            _logo_clr_prim=self.get_color_value("blue"),
            _logo_clr_sec=self.get_color_value("white"),
            _min_join_value=500,
            _xp=self.calculate_xp_for_level(1),
            currency="0",
            active_clan_label="false"
        )
    
    # Events API
    
    def get_events(self, event_type: str = None, status: str = None) -> List[Dict[str, Any]]:
        """
        Fetch all active and upcoming game events.
        
        Args:
            event_type: Filter by event type (e.g., "sem_1875", "mc5_activities_event")
            status: Filter by status ("active", "ended", "upcoming")
            
        Returns:
            List of event objects with detailed information
        """
        url = f"{self.BASE_URLS['osiris']}/events"
        params = {}
        
        if event_type:
            params['category'] = event_type
        if status:
            params['status'] = status
            
        events = self._make_request("GET", url, params=params)
        return events if isinstance(events, list) else []
    
    def get_event_details(self, event_name: str) -> Dict[str, Any]:
        """
        Get detailed information about a specific event including tasks and milestones.
        
        Args:
            event_name: The name/identifier of the event
            
        Returns:
            Detailed event information with parsed tasks and milestones
        """
        events = self.get_events()
        for event in events:
            if isinstance(event, dict) and event.get('name') == event_name:
                return self._parse_event_template(event)
        return {}
    
    def _parse_event_template(self, event: Dict[str, Any]) -> Dict[str, Any]:
        """
        Parse event template to extract tasks and milestones information.
        
        Args:
            event: Raw event data from API
            
        Returns:
            Parsed event with structured tasks and milestones
        """
        parsed_event = {
            'name': event.get('name'),
            'category': event.get('category'),
            'description': event.get('description'),
            'start_date': event.get('start_date'),
            'end_date': event.get('end_date'),
            'status': event.get('status'),
            'tasks': [],
            'milestones': [],
            'tournament_info': None
        }
        
        template = event.get('_template', {})
        if template:
            tuning = template.get('event_tuning', {})
            
            # Parse tasks
            tasks_data = tuning.get('_tasks', {}).get('value', [])
            for task in tasks_data:
                parsed_task = {
                    'milestone_id': task.get('_milestone_id'),
                    'points': task.get('points', 0),
                    'condition': task.get('condition', {}),
                    'award': task.get('award', {}),
                    'condition_type': self._extract_condition_type(task.get('condition', {})),
                    'reward': self._extract_reward(task.get('award', {}))
                }
                parsed_event['tasks'].append(parsed_task)
            
            # Parse milestones
            milestones_data = tuning.get('milestones', {}).get('value', [])
            for milestone in milestones_data:
                parsed_milestone = {
                    'milestone_id': milestone.get('_milestone_id'),
                    'condition': milestone.get('condition', 0),
                    'award': milestone.get('award', {}),
                    'reward': self._extract_reward(milestone.get('award', {}))
                }
                parsed_event['milestones'].append(parsed_milestone)
            
            # Parse tournament info if present
            tournament = template.get('tournament', {})
            if tournament:
                parsed_event['tournament_info'] = {
                    'type': tournament.get('type'),
                    'leaderboard': tournament.get('leaderboard', {}),
                    'awards': tournament.get('awards', [])
                }
        
        return parsed_event
    
    def _extract_condition_type(self, condition: Dict[str, Any]) -> str:
        """
        Extract the condition type from task condition data.
        
        Args:
            condition: Condition data from task
            
        Returns:
            String representing the condition type
        """
        if not condition or 'value' not in condition:
            return 'unknown'
            
        value = condition['value']
        if isinstance(value, dict):
            # Extract the first key which represents the condition type
            return list(value.keys())[0] if value else 'unknown'
        
        return str(value)
    
    def _extract_reward(self, award: Dict[str, Any]) -> Dict[str, Any]:
        """
        Extract reward information from award data.
        
        Args:
            award: Award data from task or milestone
            
        Returns:
            Structured reward information
        """
        reward = {'type': 'unknown', 'items': []}
        
        if not award or 'value' not in award:
            return reward
            
        award_value = award['value']
        if isinstance(award_value, list):
            for item in award_value:
                if isinstance(item, dict) and 'value' in item:
                    for reward_type, reward_data in item['value'].items():
                        reward['items'].append({
                            'type': reward_type,
                            'amount': reward_data.get('value', 0) if isinstance(reward_data, dict) else reward_data
                        })
                        reward['type'] = 'items'
        
        return reward
    
    def get_daily_tasks(self) -> Dict[str, Any]:
        """
        Get current daily tasks with progress and rewards.
        
        Returns:
            Daily tasks event information with parsed tasks and milestones
        """
        events = self.get_events(event_type="mc5_activities_event")
        for event in events:
            if 'daily' in event.get('name', '').lower() or 'activities' in event.get('name', '').lower():
                return self._parse_event_template(event)
        return {}
    
    def get_squad_events(self) -> List[Dict[str, Any]]:
        """
        Get all squad/team events.
        
        Returns:
            List of squad events with detailed information
        """
        events = self.get_events(event_type="sem_1875")
        squad_events = []
        
        for event in events:
            parsed_event = self._parse_event_template(event)
            squad_events.append(parsed_event)
        
        return squad_events
    
    def get_event_progress(self, event_name: str) -> Dict[str, Any]:
        """
        Get current progress for a specific event (if available).
        
        Args:
            event_name: The name/identifier of the event
            
        Returns:
            Event progress information
        """
        # This would typically require a different endpoint for user progress
        # For now, return the event details as a base
        return self.get_event_details(event_name)
    
    def calculate_event_rewards(self, event_name: str, current_points: int = 0) -> Dict[str, Any]:
        """
        Calculate potential rewards for an event based on current points.
        
        Args:
            event_name: The name/identifier of the event
            current_points: Current points earned by the player
            
        Returns:
            Available milestones and rewards
        """
        event_details = self.get_event_details(event_name)
        if not event_details:
            return {}
        
        available_milestones = []
        total_rewards = {'type': 'items', 'items': []}
        
        for milestone in event_details.get('milestones', []):
            if current_points >= milestone['condition']:
                # Milestone is available
                available_milestones.append(milestone)
                # Add milestone rewards to total
                if milestone.get('reward', {}).get('items'):
                    total_rewards['items'].extend(milestone['reward']['items'])
        
        return {
            'event_name': event_name,
            'current_points': current_points,
            'available_milestones': available_milestones,
            'total_rewards': total_rewards,
            'next_milestone': self._get_next_milestone(event_details, current_points)
        }
    
    def _get_next_milestone(self, event_details: Dict[str, Any], current_points: int) -> Dict[str, Any]:
        """
        Get the next milestone the player can achieve.
        
        Args:
            event_details: Parsed event details
            current_points: Current points earned
            
        Returns:
            Next milestone information or empty dict if none available
        """
        milestones = sorted(event_details.get('milestones', []), key=lambda x: x.get('condition', 0))
        
        for milestone in milestones:
            if current_points < milestone.get('condition', 0):
                return milestone
        
        return {}
    
    # Account Management
    
    def import_account_data(self, from_credential: str, secret: str, platform: str = "windows", account_data: Dict[str, Any] = None) -> Dict[str, Any]:
        """
        Import account data from another platform or backup.
        
        Args:
            from_credential: Source platform credential (e.g., "microsoftgraph:..." or "anonymous:...")
            secret: Encrypted verification secret
            platform: Target platform (default: "windows")
            account_data: Platform-specific account data (optional)
            
        Returns:
            Import result with status and details
        """
        url = f"{self.BASE_URLS['osiris']}/accounts/me/import"
        params = {
            "from_credential": from_credential,
            "secret": secret
        }
        
        data = {}
        if platform:
            data["platform"] = platform
        if account_data:
            data["data"] = account_data
        
        return self._make_request("POST", url, params=params, data=data)
    
    def link_account(self, target_credential: str, platform: str = "windows") -> Dict[str, Any]:
        """
        Link current account with another platform account.
        
        Args:
            target_credential: Target platform credential to link
            platform: Target platform (default: "windows")
            
        Returns:
            Account linking result
        """
        # This would typically use a specific account linking endpoint
        # For now, using import as a base implementation
        return self.import_account_data(
            from_credential=target_credential,
            secret="",  # Would need proper secret generation
            platform=platform
        )
    
    def get_account_info(self, credential: str = None) -> Dict[str, Any]:
        """
        Get detailed account information including linked platforms.
        
        Args:
            credential: Specific credential to query (optional, uses current account if not provided)
            
        Returns:
            Account information with platform details
        """
        # This would typically use a specific account info endpoint
        # For now, returning profile as base information
        return self.get_profile()
    
    def unlink_account(self, platform_credential: str) -> Dict[str, Any]:
        """
        Unlink a previously linked platform account.
        
        Args:
            platform_credential: Platform credential to unlink
            
        Returns:
            Unlink result
        """
        # This would typically use a specific unlink endpoint
        # For now, returning a placeholder response
        return {
            "status": "success",
            "message": "Account unlink functionality requires specific endpoint implementation",
            "unlinked_credential": platform_credential
        }
    
    def migrate_account_data(self, from_platform: str, to_platform: str, include_data: List[str] = None) -> Dict[str, Any]:
        """
        Migrate account data between platforms.
        
        Args:
            from_platform: Source platform
            to_platform: Target platform
            include_data: List of data types to include (e.g., ["profile", "inventory", "progress"])
            
        Returns:
            Migration result with status and details
        """
        if include_data is None:
            include_data = ["profile", "inventory", "progress"]
        
        # This would typically use a specific migration endpoint
        # For now, returning a placeholder response
        return {
            "status": "success",
            "message": "Account migration functionality requires specific endpoint implementation",
            "from_platform": from_platform,
            "to_platform": to_platform,
            "included_data": include_data
        }
    
    # Alias/Dogtags System
    
    # Dogtag conversion mappings
    DOGTAG_SWAP = {
        '0': '8', '1': '9', '2': '0', '3': '1', '4': '2', '5': '3', 
        '6': '4', '7': '5', '8': '6', '9': '7',
        'a': 'y', 'b': 'z', 'c': 'a', 'd': 'b', 'e': 'c', 'f': 'd',
        'g': 'e', 'h': 'f', 'i': 'g', 'j': 'h', 'k': 'i', 'l': 'j',
        'm': 'k', 'n': 'l', 'o': 'm', 'p': 'n', 'q': 'o', 'r': 'p',
        's': 'q', 't': 'r', 'u': 's', 'v': 't', 'w': 'u', 'x': 'v',
        'y': 'w', 'z': 'x'
    }
    
    REVERSE_DOGTAG_SWAP = {v: k for k, v in DOGTAG_SWAP.items()}
    
    def convert_dogtag_to_alias(self, dogtag: str) -> str:
        """
        Convert a dogtag (player ID) to alias format using the correct MC5 mapping.
        
        Args:
            dogtag: Dogtag in XXXX format (hexadecimal), can be 4-8 characters
            
        Returns:
            Alias string
        """
        if not dogtag or len(dogtag) < 4 or len(dogtag) > 8:
            return dogtag
        
        return ''.join(self.DOGTAG_SWAP.get(c, c) for c in dogtag.lower())
    
    def convert_alias_to_dogtag(self, alias: str) -> str:
        """
        Convert an alias back to dogtag format using the correct MC5 mapping.
        
        Args:
            alias: Alias string
            
        Returns:
            Dogtag in XXXX format (hexadecimal)
        """
        if not alias:
            return alias
        
        return ''.join(self.REVERSE_DOGTAG_SWAP.get(c, c) for c in alias.lower())
    
    def get_alias_info(self, alias_id: str) -> Dict[str, Any]:
        """
        Retrieve player information using alias/dogtag.
        
        Args:
            alias_id: Player's alias (e.g., "d33d") or dogtag
            
        Returns:
            Player account information
        """
        url = f"{self.BASE_URLS['janus']}/games/mygame/alias/{alias_id}"
        return self._make_request("GET", url)
    
    def search_player_by_alias(self, alias: str) -> Dict[str, Any]:
        """
        Search for a player by their alias.
        
        Args:
            alias: Player alias to search for
            
        Returns:
            Player information if found
        """
        return self.get_alias_info(alias)
    
    # Game Configuration
    
    def get_asset_metadata(self, asset_path: str) -> Dict[str, Any]:
        """
        Get hash metadata for specific game assets.
        
        Args:
            asset_path: Asset path (e.g., "videos_HD_UPD18_pvx")
            
        Returns:
            Asset metadata including hash
        """
        url = f"{self.BASE_URLS['iris']}/assets/{self.client_id}/{asset_path}/metadata/hash"
        return self._make_request("GET", url)
    
    def get_game_object_catalog(self) -> List[Dict[str, Any]]:
        """
        Get the catalog of in-game objects (currencies, weapons, items, etc.).
        
        Returns:
            List of game objects with detailed information
        """
        # Use timestamp-based URL for dynamic content
        import time
        timestamp = int(time.time())
        url = f"https://iris16-gold.gameloft.com/1875/game_object_{timestamp}"
        
        try:
            return self._make_request("GET", url)
        except:
            # Fallback to static URL if dynamic fails
            fallback_url = "https://iris16-gold.gameloft.com/1875/game_object_1747885487.1257186"
            try:
                return self._make_request("GET", fallback_url)
            except:
                # Return empty catalog if both fail
                return []
    
    def get_service_urls(self) -> Dict[str, str]:
        """
        Get service URLs for the current region and client.
        
        Returns:
            Dictionary of service URLs
        """
        url = f"https://eve.gameloft.com/config/{self.client_id}/datacenters/eur/urls"
        try:
            return self._make_request("GET", url)
        except:
            # Return default URLs if endpoint fails
            return {
                "osiris": "https://eur-osiris.gameloft.com",
                "janus": "https://eur-janus.gameloft.com",
                "iris": "https://eur-iris.gameloft.com",
                "hermes": "https://eur-hermes.gameloft.com"
            }
    
    def get_game_config(self, config_type: str = "basic") -> Dict[str, Any]:
        """
        Get game configuration data.
        
        Args:
            config_type: Type of configuration to retrieve ("basic", "advanced", "all")
            
        Returns:
            Game configuration data
        """
        config_data = {
            "service_urls": self.get_service_urls(),
            "client_id": self.client_id
        }
        
        if config_type in ["advanced", "all"]:
            config_data["game_objects"] = self.get_game_object_catalog()
        
        if config_type == "all":
            config_data["asset_metadata"] = "Use get_asset_metadata() for specific assets"
        
        return config_data
    
    # Batch Operations
    
    def get_batch_profiles(self, credentials: List[str], include_fields: List[str] = None) -> Dict[str, Any]:
        """
        Get batch player profiles with detailed statistics and game save data.
        
        Args:
            credentials: List of player credentials to fetch
            include_fields: List of fields to include (default: ['_game_save', 'inventory'])
            
        Returns:
            Dictionary with player profiles containing detailed statistics
        """
        if include_fields is None:
            include_fields = ['_game_save', 'inventory']
        
        url = "https://app-468561b3-9ecd-4d21-8241-30ed288f4d8b.gold0009.gameloft.com/1875/windows/09/public/OfficialScripts/mc5Portal.wsgi"
        
        data = {
            'op_code': 'get_batch_profiles',
            'client_id': self.client_id,
            'credentials': ','.join(credentials),
            'pandora': f"https://vgold-eur.gameloft.com/{self.client_id}",
            'include_fields': ','.join(include_fields)
        }
        
        headers = {
            'Accept': '*/*',
            'Content-Type': 'application/x-www-form-urlencoded',
            'accept-encoding': 'identity'
        }
        
        return self._make_request("POST", url, data=data, headers=headers)
    
    def get_complete_player_stats(self, credentials: List[str]) -> Dict[str, Any]:
        """
        Get complete player statistics with all available fields.
        
        Args:
            credentials: List of player credentials to fetch
            
        Returns:
            Dictionary with complete player profiles
        """
        # Try to get all possible fields
        all_fields = ['_game_save', 'inventory', 'statistics', 'profile', 'achievements']
        return self.get_batch_profiles(credentials, all_fields)
    
    def get_player_stats_by_dogtag(self, dogtag: str) -> Dict[str, Any]:
        """
        Get detailed player statistics using their dogtag (in-game ID).
        Follows the exact API flow: dogtag → alias → janus lookup → batch profiles.
        
        Args:
            dogtag: Player's dogtag in XXXX format (hexadecimal), can be 4-8 characters
            
        Returns:
            Player statistics and profile information
        """
        # Convert dogtag to alias for API lookup
        alias = self.convert_dogtag_to_alias(dogtag)
        
        # Get player info using alias from janus endpoint
        try:
            player_info = self.get_alias_info(alias)
            if not player_info.get('credential'):
                return {
                    'error': f'Player not found for dogtag: {dogtag}', 
                    'dogtag': dogtag,
                    'alias': alias,
                    'janus_response': player_info
                }
        
            # Get detailed stats using the credential from batch profiles endpoint
            try:
                stats = self.get_batch_profiles([player_info['credential']])
                
                # Add dogtag and alias info to the response
                if player_info['credential'] in stats:
                    stats[player_info['credential']]['dogtag'] = dogtag
                    stats[player_info['credential']]['alias'] = alias
                    stats[player_info['credential']]['player_info'] = player_info
                    stats[player_info['credential']]['janus_response'] = player_info
                
                return stats
                
            except Exception as e:
                return {
                    'error': f'Failed to get stats for dogtag {dogtag}: {e}',
                    'dogtag': dogtag,
                    'alias': alias,
                    'player_info': player_info,
                    'janus_response': player_info
                }
        except Exception as e:
            return {
                'error': f'Failed to lookup alias {alias} for dogtag {dogtag}: {e}',
                'dogtag': dogtag,
                'alias': alias
            }
    
    # Clan Management & Profile Operations
    
    def get_profile(self) -> Dict[str, Any]:
        """
        Retrieve player profile details including name, groups, and last time played.
        
        Returns:
            Player profile information
        """
        url = f"{self.BASE_URLS['osiris']}/accounts/me"
        params = {
            "access_token": self._token_data["access_token"]
        }
        
        return self._make_request("GET", url, params=params)
    
    def update_profile(self, name: str = None, groups: str = None, games: str = None, 
                       credential: str = None, fed_id: str = None) -> Dict[str, Any]:
        """
        Update player profile (name, groups, games data).
        
        Args:
            name: Player nickname
            groups: Comma-separated clan IDs
            games: JSON string with game data
            credential: Player credential
            fed_id: Federated ID
            
        Returns:
            Update result
        """
        url = f"{self.BASE_URLS['osiris']}/accounts/me"
        
        data = {
            "access_token": self._token_data["access_token"],
            "timestamp": str(int(time.time()))
        }
        
        if name is not None:
            data["name"] = name
        if groups is not None:
            data["groups"] = groups
        if games is not None:
            data["games"] = games
        if credential is not None:
            data["credential"] = credential
        if fed_id is not None:
            data["fed_id"] = fed_id
        
        return self._make_request("POST", url, data=data)
    
    def get_clan_members(self, clan_id: str, offset: int = 0) -> List[Dict[str, Any]]:
        """
        Get all members of a clan.
        
        Args:
            clan_id: The unique identifier of the clan
            offset: Number of results to skip for pagination
            
        Returns:
            List of clan members with their details
        """
        url = f"{self.BASE_URLS['osiris']}/groups/{clan_id}/members"
        params = {
            "access_token": self._token_data["access_token"],
            "group_id": clan_id,
            "offset": str(offset)
        }
        
        response = self._make_request("GET", url, params=params)
        return response if isinstance(response, list) else []
    
    def get_squad_members(self, squad_id: str, offset: int = 0, limit: int = 100) -> Dict[str, Any]:
        """
        Get squad members list.
        
        Args:
            squad_id: Squad ID
            offset: Offset for pagination
            limit: Number of members to retrieve
            
        Returns:
            Squad members list
        """
        url = f"{self.BASE_URLS['osiris']}/groups/{squad_id}/members"
        params = {
            "access_token": self._token_data['access_token'],
            "group_id": squad_id,
            "offset": str(offset),
            "limit": str(limit)
        }
        
        return self._make_request("GET", url, params=params)
    
    def get_clan_info(self, clan_id: str) -> Dict[str, Any]:
        """
        Get detailed information about a clan.
        
        Args:
            clan_id: The unique identifier of the clan
            
        Returns:
            Clan information including settings
        """
        url = f"{self.BASE_URLS['osiris']}/groups/{clan_id}"
        params = {
            "access_token": self._token_data["access_token"]
        }
        
        return self._make_request("GET", url, params=params)
    
    def update_clan_settings(self, clan_id: str, name: str = None, description: str = None,
                            rating: str = None, score: str = None, member_limit: str = None,
                            membership: str = None, logo: str = None, logo_primary_color: str = None,
                            logo_secondary_color: str = None, min_join_value: str = None,
                            xp: str = None, currency: str = None, killsig_id: str = None,
                            active_clan_label: str = None, active_member_count: str = None,
                            active_clan_threshold: str = None) -> Dict[str, Any]:
        """
        Update clan settings and information.
        
        Args:
            clan_id: The unique identifier of the clan
            name: Clan name
            description: Clan description
            rating: Clan rating
            score: Clan score
            member_limit: Maximum number of members
            membership: Membership type (open, owner_approved, member_approved, closed)
            logo: Logo ID
            logo_primary_color: Primary logo color (0-16777215)
            logo_secondary_color: Secondary logo color (0-16777215)
            min_join_value: Minimum join value
            xp: Clan XP (max 10000)
            currency: Clan currency
            killsig_id: Kill sign ID
            active_clan_label: Whether clan label is active (true/false)
            active_member_count: Active member count
            active_clan_threshold: Active member threshold
            
        Returns:
            Update result
        """
        url = f"{self.BASE_URLS['osiris']}/groups/{clan_id}"
        
        # Get current profile for required fields
        profile = self.get_profile()
        
        data = {
            "access_token": self._token_data["access_token"],
            "_anonId": profile.get("credential", ""),
            "_fedId": profile.get("fed_id", ""),
            "timestamp": str(int(time.time()))
        }
        
        # Add optional parameters
        if name is not None:
            data["name"] = name
        if description is not None:
            data["description"] = description
        if rating is not None:
            data["_rating"] = rating
        if score is not None:
            data["score"] = score
        if member_limit is not None:
            data["member_limit"] = member_limit
        if membership is not None:
            data["membership"] = membership
        if logo is not None:
            data["_logo"] = logo
        if logo_primary_color is not None:
            data["_logo_clr_prim"] = logo_primary_color
        if logo_secondary_color is not None:
            data["_logo_clr_sec"] = logo_secondary_color
        if min_join_value is not None:
            data["_min_join_value"] = min_join_value
        if xp is not None:
            data["_xp"] = xp
        if currency is not None:
            data["currency"] = currency
        if killsig_id is not None:
            data["_killsig_id"] = killsig_id
        if active_clan_label is not None:
            data["active_clan_label"] = active_clan_label
        if active_member_count is not None:
            data["active_member_count"] = active_member_count
        if active_clan_threshold is not None:
            data["active_clan_threshold"] = active_clan_threshold
        
        return self._make_request("POST", url, data=data)
    
    def kick_clan_member_by_dogtag(self, dogtag: str, clan_id: str, from_name: str = "SYSTEM", 
                                kill_sign_name: str = "default_killsig_42", 
                                kill_sign_color: str = "-974646126") -> Dict[str, Any]:
        """
        Kick a clan member using their dogtag (in-game ID).
        
        This method follows the flow: dogtag → alias → janus lookup → credential → kick
        
        Args:
            dogtag: Player's dogtag in XXXX format (4-8 characters)
            clan_id: Clan ID to kick the member from
            from_name: Sender name (default: "SYSTEM")
            kill_sign_name: Kill sign name (default: "default_killsig_42")
            kill_sign_color: Kill sign color (default: "-974646126")
            
        Returns:
            Dictionary with kick result
        """
        # Convert dogtag to alias for API lookup
        alias = self.convert_dogtag_to_alias(dogtag)
        
        # Get player info using alias from janus endpoint
        try:
            player_info = self.get_alias_info(alias)
            if not player_info.get('credential'):
                return {
                    'error': f'Player not found for dogtag: {dogtag}', 
                    'dogtag': dogtag,
                    'alias': alias,
                    'success': False
                }
            
            # Use the credential to kick the member
            return self.kick_clan_member(
                target_fed_id=player_info['credential'],
                clan_id=clan_id,
                from_name=from_name,
                kill_sign_name=kill_sign_name,
                kill_sign_color=kill_sign_color
            )
            
        except Exception as e:
            return {
                'error': f'Failed to kick member with dogtag {dogtag}: {e}',
                'dogtag': dogtag,
                'alias': alias,
                'success': False
            }
    
    def kick_clan_member(self, target_fed_id: str, clan_id: str, from_name: str = "SYSTEM", 
                       kill_sign_name: str = "default_killsig_42", 
                       kill_sign_color: str = "-974646126") -> Dict[str, Any]:
        """
        Kick a clan member using the hermes messaging system with clan kick message type.
        
        Args:
            target_fed_id: Target player's fed_id or credential
            clan_id: Clan ID to kick the member from
            from_name: Sender name (default: "SYSTEM")
            kill_sign_name: Kill sign name (default: "default_killsig_42")
            kill_sign_color: Kill sign color (default: "-974646126")
            
        Returns:
            Dictionary with kick result
        """
        url = f"{self.BASE_URLS['hermes']}/messages/inbox/{target_fed_id}"
        
        headers = {
            'Accept': '*/*',
            'User-Agent': 'ChatLibv2',
            'Content-Type': 'application/x-www-form-urlencoded',
            'Connection': 'keep-alive'
        }
        
        data = {
            'access_token': self._token_data['access_token'],
            'alert_kairos': 'true',
            'from': from_name,
            'body': clan_id,
            'reply_to': 'game:mc5_system',
            '_killSignColor': kill_sign_color,
            '_killSignName': kill_sign_name,
            '_type': 'clankick'
        }
        
        return self._make_request("POST", url, data=data, headers=headers)
    
    def get_player_detailed_stats(self, credential: str) -> Dict[str, Any]:
        """
        Get detailed player statistics including game save and inventory.
        
        Args:
            credential: Player's credential
            
        Returns:
            Detailed player statistics and game data
        """
        return self.get_batch_profiles([credential])
    
    def parse_player_stats(self, stats_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Parse and structure player statistics for easier consumption.
        
        Args:
            stats_data: Raw stats data from get_batch_profiles
            
        Returns:
            Structured player statistics
        """
        if not stats_data or not isinstance(stats_data, dict):
            return {'error': 'Invalid stats data'}
        
        # Get the first (and likely only) player's data
        player_credential = list(stats_data.keys())[0] if stats_data else None
        if not player_credential or player_credential not in stats_data:
            return {'error': 'No player data found'}
        
        player_data = stats_data[player_credential]
        
        # Extract game save data
        game_save = player_data.get('_game_save', {})
        inventory = player_data.get('inventory', {})
        
        # Parse statistics
        parsed_stats = {
            'credential': player_credential,
            'rating': game_save.get('rating', 0),
            'rating_duel': game_save.get('rating_duel', 0),
            'rating_last': game_save.get('rating_last', 0),
            'current_skill': game_save.get('current_skill', 'unknown'),
            'current_weapon': game_save.get('current_weapon', 'unknown'),
            'current_loadout': game_save.get('current_loadout', 0),
            'kill_signature': game_save.get('killsig', {}),
            'progress': game_save.get('progress', []),
            'loadouts': game_save.get('loadouts', []),
            'statistics': game_save.get('statistics', {}),
            'inventory': inventory,
            'xp': inventory.get('xp', 0),
            'vip_points': inventory.get('vip_points', 0)
        }
        
        # Parse weapon statistics
        weapons = inventory.get('weapons', {})
        weapon_stats = []
        
        for weapon_id, weapon_data in weapons.items():
            if isinstance(weapon_data, dict):
                weapon_stats.append({
                    'id': weapon_id,
                    'kills': weapon_data.get('kills', 0),
                    'shots': weapon_data.get('shots', 0),
                    'hits': weapon_data.get('hits', 0),
                    'score': weapon_data.get('score', 0),
                    'time_used': weapon_data.get('time_used', 0)
                })
        
        # Sort by kills
        weapon_stats.sort(key=lambda x: x['kills'], reverse=True)
        parsed_stats['weapon_stats'] = weapon_stats
        
        # Parse overall statistics with detailed breakdown
        stats = game_save.get('statistics', {})
        if stats:
            sp_stats = stats.get('sp', {})
            mp_stats = stats.get('mp', {})
            
            # Calculate comprehensive kill statistics
            sp_total_kills = sp_stats.get('kill.total', 0)
            mp_total_kills = mp_stats.get('kill.total', 0)
            sp_headshots = sp_stats.get('kill.headshots', 0)
            mp_headshots = mp_stats.get('kill.headshots', 0)
            sp_assists = sp_stats.get('kill.assists', 0)
            mp_assists = mp_stats.get('kill.assists', 0)
            
            # Parse detailed kill types
            sp_kill_types = {
                'rifle': sp_stats.get('kill.rifle', 0),
                'pistol': sp_stats.get('kill.pistol', 0),
                'explosives': sp_stats.get('kill.explosives', 0),
                'melees': sp_stats.get('kill.melees', 0),
                'primsecweapon': sp_stats.get('kill.primsecweapon', 0),
                'assaults': sp_stats.get('kill.assaults', 0),
                'recon': sp_stats.get('kill.recon', 0)
            }
            
            mp_kill_types = {
                'rifle': mp_stats.get('kill.rifle', 0),
                'pistol': mp_stats.get('kill.pistol', 0),
                'explosives': mp_stats.get('kill.explosives', 0),
                'primsecweapon': mp_stats.get('kill.primsecweapon', 0),
                'assaults': mp_stats.get('kill.assaults', 0),
                'with_collected_weapons': mp_stats.get('kill.with_collected_weapons', 0)
            }
            
            # Parse killstreak stats
            sp_killstreaks = {
                'total': sp_stats.get('killstreak.total', 0),
                'assault_total': sp_stats.get('killstreak.assault.total', 0),
                'recon_total': sp_stats.get('killstreak.recon.total', 0)
            }
            
            mp_killstreaks = {
                'total': mp_stats.get('killstreak.total', 0),
                'assault_total': mp_stats.get('killstreak.assault.total', 0),
                'recon_total': mp_stats.get('killstreak.recon.total', 0)
            }
            
            parsed_stats['overall_stats'] = {
                'total_kills': sp_total_kills + mp_total_kills,
                'total_deaths': sp_stats.get('death.total', 0) + mp_stats.get('death.total', 0),
                'total_headshots': sp_headshots + mp_headshots,
                'total_assists': sp_assists + mp_assists,
                'total_time_played': sp_stats.get('time.played', 0) + mp_stats.get('time.played', 0),
                'sp_kills': sp_total_kills,
                'mp_kills': mp_total_kills,
                'sp_headshots': sp_headshots,
                'mp_headshots': mp_headshots,
                'sp_assists': sp_assists,
                'mp_assists': mp_assists,
                'sp_kill_types': sp_kill_types,
                'mp_kill_types': mp_kill_types,
                'sp_killstreaks': sp_killstreaks,
                'mp_killstreaks': mp_killstreaks,
                'weapon_kills': sum(weapon_stats[i]['kills'] for i in range(len(weapon_stats))),
                'top_weapon': weapon_stats[0] if weapon_stats else None
            }
            
            # Calculate K/D ratios
            total_deaths = sp_stats.get('death.total', 0) + mp_stats.get('death.total', 0)
            if total_deaths > 0:
                parsed_stats['overall_stats']['kd_ratio'] = (sp_total_kills + mp_total_kills) / total_deaths
            else:
                parsed_stats['overall_stats']['kd_ratio'] = float('inf')
            
            # Calculate headshot percentage
            total_kills = sp_total_kills + mp_total_kills
            if total_kills > 0:
                parsed_stats['overall_stats']['headshot_percentage'] = ((sp_headshots + mp_headshots) / total_kills) * 100
            else:
                parsed_stats['overall_stats']['headshot_percentage'] = 0
        
        return parsed_stats
    
    def get_platform_info(self) -> Dict[str, Any]:
        """
        Get current platform information.
        
        Returns:
            Platform configuration details
        """
        return {
            "platform": self.platform.value,
            "client_id": self.client_id,
            "device_info": self.platform_config.get_device_info(),
            "user_agent": self.platform_config.get_user_agent(),
            "platform_id": self.platform_config.get_platform_id()
        }
    
    def switch_platform(self, platform: Platform) -> None:
        """
        Switch to a different platform.
        
        Args:
            platform: New platform to use
        """
        self.platform = platform
        self.platform_config = get_platform_config(platform)
        self.client_id = self.platform_config.get_client_id()
        
        # Update session headers
        self.session.headers.update({
            "User-Agent": self.platform_config.get_user_agent()
        })
        
        # Reinitialize token generator with new client_id
        self.token_generator = TokenGenerator(
            client_id=self.client_id,
            timeout=self.timeout,
            max_retries=self.max_retries
        )
        
        # Clear existing token
        self._token_data = None
    
    def generate_platform_credential(self) -> str:
        """
        Generate platform-specific anonymous credential.
        
        Returns:
            Platform-appropriate anonymous credential
        """
        if self.platform == Platform.ANDROID:
            return self.platform_config.generate_android_credential()
        else:
            # PC credential format
            import random
            import string
            return f"win8_v2_{random.randint(100000000, 999999999)}_{''.join(random.choices(string.ascii_letters + string.digits, k=20))}"
    
    def subscribe_to_chat_room(self, room_id: str, language: str = "en") -> Dict[str, Any]:
        """
        Subscribe to a chat room (Android-specific).
        
        Args:
            room_id: Chat room ID
            language: Language code
            
        Returns:
            Chat subscription information
        """
        self._ensure_valid_token()
        
        url = f"{self.BASE_URLS['arion']}/chat/rooms/{room_id}/subscribe"
        data = {
            "language": language,
            "access_token": self._token_data['access_token']
        }
        
        return self._make_request("POST", url, data=data)
    
    def send_squad_message(
        self, 
        room_id: str, 
        message: str, 
        kill_sign: str = "default_killsig_03",
        kill_sign_color: str = "1212155"
    ) -> Dict[str, Any]:
        """
        Send message to squad chat room (Android-specific).
        
        Args:
            room_id: Squad room ID
            message: Message content
            kill_sign: Kill signature
            kill_sign_color: Kill signature color
            
        Returns:
            Message response
        """
        self._ensure_valid_token()
        
        # Get chat URL from subscription
        subscription = self.subscribe_to_chat_room(room_id)
        chat_url = subscription.get('cmd_url')
        
        if not chat_url:
            raise MC5APIError("Could not get chat URL from subscription")
        
        data = {
            "_killSignColor": kill_sign_color,
            "_fedId": f"fed_id:{self._token_data.get('fed_id', '')}",
            "_senderTimestamp": str(int(time.time())),
            "_senderName": self._username.split(":")[-1] if ":" in self._username else "Player",
            "_anonId": self._username,
            "_killSign": kill_sign,
            "_": "wU\\UWZ",  # Android signature
            "msg": message,
            "user": '{"nickname":"' + (self._username.split(":")[-1] if ":" in self._username else "Player") + '"}',
            "access_token": self._token_data['access_token']
        }
        
        return self._make_request("POST", chat_url, data=data)
    
    def send_global_message(
        self, 
        message: str, 
        nickname: str = "Player",
        kill_sign: str = "default_killsig_03"
    ) -> Dict[str, Any]:
        """
        Send message to global chat (Android-specific).
        
        Args:
            message: Message content
            nickname: Player nickname
            kill_sign: Kill signature
            
        Returns:
            Message response
        """
        self._ensure_valid_token()
        
        # Global chat endpoint
        url = "https://eur-fedex-fsg006.gameloft.com:54435/v1/chat/channels/mc5_global.en"
        
        data = {
            "_killSignColor": "1212155",
            "_fedId": f"fed_id:{self._token_data.get('fed_id', '')}",
            "_senderTimestamp": str(int(time.time())),
            "_senderName": nickname,
            "_anonId": self._username,
            "_killSign": kill_sign,
            "_": "wU\\UWZ",
            "msg": message,
            "user": '{"nickname":"' + nickname + '"}',
            "access_token": self._token_data['access_token']
        }
        
        return self._make_request("POST", url, data=data)
    
    def get_squad_wall(
        self, 
        room_id: str, 
        limit: int = 20,
        include_fields: List[str] = None
    ) -> List[Dict[str, Any]]:
        """
        Get squad wall posts (Android-specific).
        
        Args:
            room_id: Squad room ID
            limit: Number of posts to retrieve
            include_fields: Fields to include in response
            
        Returns:
            List of wall posts
        """
        self._ensure_valid_token()
        
        if include_fields is None:
            include_fields = ["actor", "creation", "id", "text"]
        
        url = f"{self.BASE_URLS['osiris']}/groups/{room_id}/wall"
        params = {
            "access_token": self._token_data['access_token'],
            "sort_type": "chronological",
            "limit": str(limit),
            "include_fields": ",".join(include_fields)
        }
        
        return self._make_request("GET", url, params=params)
    
    def send_private_message(
        self,
        target_credential: str,
        message: str,
        from_name: str = "Player",
        kill_sign: str = "default_killsig_03",
        kill_sign_color: str = "1212155"
    ) -> Dict[str, Any]:
        """
        Send private message (Android-specific).
        
        Args:
            target_credential: Target user's credential
            message: Message content
            from_name: Sender name
            kill_sign: Kill signature
            kill_sign_color: Kill signature color
            
        Returns:
            Message response
        """
        self._ensure_valid_token()
        
        url = f"{self.BASE_URLS['hermes']}/messages/inbox/{target_credential}"
        data = {
            "access_token": self._token_data['access_token'],
            "alert_kairos": "true",
            "from": from_name,
            "body": message,
            "reply_to": self._username,
            "_killSignColor": kill_sign_color,
            "_killSignName": kill_sign,
            "_type": "inbox"
        }
        
        return self._make_request("POST", url, data=data)
    
    def check_friend_connection(self, target_credential: str) -> Dict[str, Any]:
        """
        Check friend connection status (Android-specific).
        
        Args:
            target_credential: Target user's credential
            
        Returns:
            Friend connection status
        """
        self._ensure_valid_token()
        
        url = f"{self.BASE_URLS['osiris']}/accounts/me/connections/friend/{target_credential}"
        params = {
            "access_token": self._token_data['access_token'],
            "target_credential": target_credential
        }
        
        return self._make_request("GET", url, params=params)
    
    def remove_friend(
        self,
        target_credential: str
    ) -> Dict[str, Any]:
        """
        Remove friend connection (Android-specific).
        
        Args:
            target_credential: Target user's credential to remove
            
        Returns:
            Friend removal response
        """
        self._ensure_valid_token()
        
        url = f"{self.BASE_URLS['osiris']}/accounts/me/connections/friend/{target_credential}/delete"
        data = {
            "access_token": self._token_data['access_token'],
            "target_credential": target_credential
        }
        
        return self._make_request("POST", url, data=data)
    
    def send_friend_removed_message(
        self,
        target_credential: str,
        message: str = "removed",
        from_name: str = "Player",
        kill_sign: str = "default_killsig_03",
        kill_sign_color: str = "1212155"
    ) -> Dict[str, Any]:
        """
        Send friend removed notification message (Android-specific).
        
        Args:
            target_credential: Target user's credential
            message: Message content (default: "removed")
            from_name: Sender name
            kill_sign: Kill signature
            kill_sign_color: Kill signature color
            
        Returns:
            Message response
        """
        self._ensure_valid_token()
        
        url = f"{self.BASE_URLS['hermes']}/messages/inbox/{target_credential}"
        data = {
            "access_token": self._token_data['access_token'],
            "alert_kairos": "true",
            "from": from_name,
            "body": message,
            "reply_to": self._username,
            "_killSignColor": kill_sign_color,
            "_killSignName": kill_sign,
            "_type": "friendRemoved"
        }
        
        return self._make_request("POST", url, data=data)
    
    def update_squad_info(
        self,
        clan_id: str,
        rating: Optional[int] = None,
        score: Optional[int] = None,
        name: Optional[str] = None,
        description: Optional[str] = None,
        member_count: Optional[int] = None,
        member_limit: Optional[int] = None,
        membership: Optional[str] = None,
        logo: Optional[str] = None,
        logo_color_primary: Optional[int] = None,
        logo_color_secondary: Optional[int] = None,
        min_join_value: Optional[int] = None,
        currency: Optional[int] = None,
        active_clan_label: Optional[bool] = None
    ) -> Dict[str, Any]:
        """
        Update squad information (Android-specific).
        
        Args:
            clan_id: Squad/Clan ID to update
            rating: Squad rating value
            score: Squad score (may not update in-game)
            name: Squad name
            description: Squad description
            member_count: Current member count
            member_limit: Maximum member limit
            membership: Membership type (e.g., "owner_approved")
            logo: Logo ID
            logo_color_primary: Primary logo color
            logo_color_secondary: Secondary logo color
            min_join_value: Minimum join value
            currency: Squad currency
            active_clan_label: Whether clan label is active
            
        Returns:
            Update response
        """
        self._ensure_valid_token()
        
        url = f"{self.BASE_URLS['osiris']}/groups/{clan_id}"
        
        # Build payload with provided parameters
        payload = {
            "access_token": self._token_data['access_token'],
            "timestamp": str(int(time.time())),
            "_anonId": self._username
        }
        
        # Add optional parameters if provided
        if rating is not None:
            payload["_rating"] = str(rating)
        if score is not None:
            payload["score"] = str(score)
        if name is not None:
            payload["name"] = name
        if description is not None:
            payload["description"] = description
        if member_count is not None:
            payload["member_count"] = str(member_count)
        if member_limit is not None:
            payload["member_limit"] = str(member_limit)
        if membership is not None:
            payload["membership"] = membership
        if logo is not None:
            payload["_logo"] = logo
        if logo_color_primary is not None:
            payload["_logo_clr_prim"] = str(logo_color_primary)
        if logo_color_secondary is not None:
            payload["_logo_clr_sec"] = str(logo_color_secondary)
        if min_join_value is not None:
            payload["_min_join_value"] = str(min_join_value)
        if currency is not None:
            payload["currency"] = str(currency)
        if active_clan_label is not None:
            payload["active_clan_label"] = "true" if active_clan_label else "false"
        
        return self._make_request("POST", url, data=payload)
    
    def get_squad_info(
        self,
        clan_id: str
    ) -> Dict[str, Any]:
        """
        Get squad information (Android-specific).
        
        Args:
            clan_id: Squad/Clan ID to retrieve
            
        Returns:
            Squad information
        """
        self._ensure_valid_token()
        
        url = f"{self.BASE_URLS['osiris']}/groups/{clan_id}"
        params = {
            "access_token": self._token_data['access_token']
        }
        
        return self._make_request("GET", url, params=params)
    
    def post_to_squad_wall(
        self,
        room_id: str,
        message: str,
        kill_sign: str = "default_killsig_03",
        kill_sign_color: int = 1212155,
        language: str = "en"
    ) -> Dict[str, Any]:
        """
        Post to squad wall (Android-specific).
        
        Args:
            room_id: Squad room ID
            message: Message content
            kill_sign: Kill signature
            kill_sign_color: Kill signature color
            language: Language code
            
        Returns:
            Wall post response
        """
        self._ensure_valid_token()
        
        url = f"{self.BASE_URLS['osiris']}/groups/{room_id}/wall"
        
        post_data = {
            "msg_body": message,
            "msg_type": 0,
            "playerKillSign": kill_sign,
            "playerKillSignColor": kill_sign_color
        }
        
        data = {
            "access_token": self._token_data['access_token'],
            "text": json.dumps(post_data) + "\n",
            "language": language,
            "activity_type": "user_post",
            "alert_kairos": "false"
        }
        
        return self._make_request("POST", url, data=data)
    
    def get_game_alias(self) -> Dict[str, Any]:
        """
        Get game alias (Android-specific).
        
        Returns:
            Game alias information
        """
        self._ensure_valid_token()
        
        url = f"{self.BASE_URLS['janus']}/games/mygame/alias"
        data = {
            "access_token": self._token_data['access_token']
        }
        
        return self._make_request("POST", url, data=data)
    
    def get_batch_profiles(
        self,
        credentials: List[str],
        include_fields: List[str] = None
    ) -> Dict[str, Any]:
        """
        Get batch profiles for multiple credentials (Android-specific).
        
        Args:
            credentials: List of player credentials (fed_id:... format)
            include_fields: Fields to include in response
            
        Returns:
            Batch profile data
        """
        if include_fields is None:
            include_fields = ["_game_save", "inventory"]
        
        # Use game portal endpoint
        url = f"{self.BASE_URLS['game_portal']}/1924/190/public/OfficialScripts/mc5Portal.wsgi"
        
        data = {
            "op_code": "get_batch_profiles",
            "client_id": self.client_id,
            "credentials": ",".join(credentials),
            "pandora": f"https://vgold-eur.gameloft.com/{self.client_id}",
            "include_fields": ",".join(include_fields)
        }
        
        return self._make_request("POST", url, data=data)
    
    def __enter__(self):
        """Context manager entry."""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.close()
