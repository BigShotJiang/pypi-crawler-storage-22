#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : enhanced_utilities.py
# | License  : MIT License © 2026 Chizoba
# | Brief    | Enhanced utility functions for MC5 API Client
# ────────────────★─────────────────────────────────

"""
Enhanced MC5 API Utilities

This module provides additional utility functions to make the MC5 API Client
even more powerful and user-friendly.

Features:
- Advanced room analytics
- Player statistics and tracking
- Server monitoring
- Automated room management
- Enhanced filtering and search
- Real-time notifications
"""

import time
import json
from typing import Dict, List, Optional, Union, Callable
from datetime import datetime, timedelta
from .room_matchmaking import MC5RoomAPI
from .ultra_simple_chat import _get_chat

class MC5EnhancedAPI:
    """Enhanced MC5 API with advanced utilities"""
    
    def __init__(self, client_id: str = "1875:55979:6.0.0a:windows:windows", region: str = "eur"):
        """Initialize enhanced API client"""
        self.client_id = client_id
        self.region = region
        self.room_api = MC5RoomAPI(client_id, region)
        self.chat = _get_chat()
        
    def get_server_statistics(self) -> Dict:
        """Get comprehensive server statistics"""
        try:
            # Get all room types
            all_rooms = self.room_api.find_rooms(server_type="mp_server", limit=100)
            custom_rooms = self.room_api.find_rooms(server_type="mp_server_test", limit=100)
            clan_rooms = self.room_api.find_rooms(server_type="clan_dummy_server", limit=100)
            
            stats = {
                "total_rooms": len(all_rooms) + len(custom_rooms) + len(clan_rooms),
                "ranked_rooms": len(all_rooms),
                "custom_rooms": len(custom_rooms),
                "clan_rooms": len(clan_rooms),
                "total_players": 0,
                "total_capacity": 0,
                "game_modes": {},
                "server_types": {},
                "most_popular_mode": None,
                "fill_rate": 0.0
            }
            
            # Analyze all rooms
            all_room_data = all_rooms + custom_rooms + clan_rooms
            for room in all_room_data:
                member_count = room.get('member_count', 0)
                capacity = room.get('capacity', 0)
                game_mode = room.get('_game_mode', 'Unknown')
                server_type = room.get('server_type', 'Unknown')
                
                stats["total_players"] += member_count
                stats["total_capacity"] += capacity
                
                stats["game_modes"][game_mode] = stats["game_modes"].get(game_mode, 0) + 1
                stats["server_types"][server_type] = stats["server_types"].get(server_type, 0) + 1
            
            # Calculate most popular game mode
            if stats["game_modes"]:
                stats["most_popular_mode"] = max(stats["game_modes"], key=stats["game_modes"].get)
            
            # Calculate fill rate
            if stats["total_capacity"] > 0:
                stats["fill_rate"] = (stats["total_players"] / stats["total_capacity"]) * 100
            
            return stats
            
        except Exception as e:
            print(f"❌ Error getting server statistics: {e}")
            return {}
    
    def find_best_rooms(self, 
                       game_mode: str = "teambattle",
                       min_players: int = 4,
                       max_fill_rate: float = 80.0,
                       server_type: str = "mp_server_test") -> List[Dict]:
        """Find the best rooms based on criteria"""
        try:
            rooms = self.room_api.find_rooms(
                game_mode=game_mode,
                server_type=server_type,
                joinable=True,
                limit=50
            )
            
            best_rooms = []
            for room in rooms:
                member_count = room.get('member_count', 0)
                capacity = room.get('capacity', 0)
                
                if capacity > 0:
                    fill_rate = (member_count / capacity) * 100
                    
                    if member_count >= min_players and fill_rate <= max_fill_rate:
                        room['fill_rate'] = fill_rate
                        best_rooms.append(room)
            
            # Sort by fill rate (most filled but not full)
            best_rooms.sort(key=lambda x: x.get('fill_rate', 0), reverse=True)
            return best_rooms[:10]  # Return top 10
            
        except Exception as e:
            print(f"❌ Error finding best rooms: {e}")
            return []
    
    def monitor_rooms(self, 
                     callback: Callable[[List[Dict]], None],
                     interval: int = 30,
                     game_mode: str = "teambattle",
                     server_type: str = "mp_server_test") -> None:
        """Monitor rooms and call callback with updates"""
        print(f"🔍 Starting room monitoring (every {interval}s)...")
        print("💡 Press Ctrl+C to stop monitoring")
        
        try:
            while True:
                rooms = self.room_api.find_rooms(
                    game_mode=game_mode,
                    server_type=server_type,
                    limit=20
                )
                
                callback(rooms)
                time.sleep(interval)
                
        except KeyboardInterrupt:
            print("\n🛑 Room monitoring stopped by user")
        except Exception as e:
            print(f"❌ Error in room monitoring: {e}")
    
    def search_players_by_name(self, name_pattern: str) -> List[Dict]:
        """Search for players by name pattern across all rooms"""
        try:
            all_rooms = self.room_api.find_rooms(limit=100)
            matching_players = []
            
            for room in all_rooms:
                members = room.get('members', [])
                for member in members:
                    player_name = member.get('name', '').lower()
                    if name_pattern.lower() in player_name:
                        player_info = {
                            'name': member.get('name'),
                            'country': member.get('country'),
                            'level': member.get('level'),
                            'killSign': member.get('killSign'),
                            'room_name': room.get('name'),
                            'game_mode': room.get('_game_mode'),
                            'server_type': room.get('server_type')
                        }
                        matching_players.append(player_info)
            
            return matching_players
            
        except Exception as e:
            print(f"❌ Error searching players: {e}")
            return []
    
    def get_room_recommendations(self, 
                               preferred_mode: str = "teambattle",
                               preferred_players: int = 8,
                               skill_level: str = "medium") -> List[Dict]:
        """Get personalized room recommendations"""
        try:
            # Define skill level ranges
            skill_ranges = {
                "beginner": (0, 1000),
                "medium": (1000, 2000),
                "advanced": (2000, 3000),
                "expert": (3000, 9999)
            }
            
            min_score, max_score = skill_ranges.get(skill_level, skill_ranges["medium"])
            
            rooms = self.room_api.find_rooms(
                game_mode=preferred_mode,
                server_type="mp_server_test",
                joinable=True,
                limit=50
            )
            
            recommendations = []
            for room in rooms:
                member_count = room.get('member_count', 0)
                capacity = room.get('capacity', 0)
                
                # Check if room matches preferences
                if abs(member_count - preferred_players) <= 4:  # Within 4 players
                    room['match_score'] = 100 - abs(member_count - preferred_players) * 10
                    room['skill_match'] = "Unknown"  # Would need player score data
                    recommendations.append(room)
            
            # Sort by match score
            recommendations.sort(key=lambda x: x.get('match_score', 0), reverse=True)
            return recommendations[:5]  # Return top 5 recommendations
            
        except Exception as e:
            print(f"❌ Error getting recommendations: {e}")
            return []
    
    def create_room_monitor_report(self) -> str:
        """Create a comprehensive room monitoring report"""
        stats = self.get_server_statistics()
        
        report = f"""
🎮 MC5 SERVER MONITORING REPORT
{'='*50}
📅 Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

📊 OVERALL STATISTICS:
   Total Rooms: {stats.get('total_rooms', 0)}
   Ranked Rooms: {stats.get('ranked_rooms', 0)}
   Custom Rooms: {stats.get('custom_rooms', 0)}
   Clan Rooms: {stats.get('clan_rooms', 0)}
   
👥 PLAYER STATISTICS:
   Total Players: {stats.get('total_players', 0)}
   Total Capacity: {stats.get('total_capacity', 0)}
   Fill Rate: {stats.get('fill_rate', 0):.1f}%
   
🎯 GAME MODES:
"""
        
        for mode, count in stats.get('game_modes', {}).items():
            report += f"   {mode}: {count} rooms\n"
        
        report += f"\n🖥️ SERVER TYPES:\n"
        for server, count in stats.get('server_types', {}).items():
            report += f"   {server}: {count} rooms\n"
        
        report += f"\n🏆 MOST POPULAR MODE: {stats.get('most_popular_mode', 'Unknown')}\n"
        
        return report

# Enhanced convenience functions
def get_server_stats() -> Dict:
    """Get comprehensive server statistics"""
    api = MC5EnhancedAPI()
    return api.get_server_statistics()

def find_best_game_rooms(game_mode: str = "teambattle", min_players: int = 4) -> List[Dict]:
    """Find the best game rooms"""
    api = MC5EnhancedAPI()
    return api.find_best_rooms(game_mode=game_mode, min_players=min_players)

def search_players(name_pattern: str) -> List[Dict]:
    """Search for players by name"""
    api = MC5EnhancedAPI()
    return api.search_players_by_name(name_pattern)

def get_room_recommendations(mode: str = "teambattle", players: int = 8) -> List[Dict]:
    """Get room recommendations"""
    api = MC5EnhancedAPI()
    return api.get_room_recommendations(preferred_mode=mode, preferred_players=players)

def monitor_rooms_live(callback: Callable[[List[Dict]], None], interval: int = 30) -> None:
    """Monitor rooms with live updates"""
    api = MC5EnhancedAPI()
    api.monitor_rooms(callback=callback, interval=interval)

def generate_server_report() -> str:
    """Generate server monitoring report"""
    api = MC5EnhancedAPI()
    return api.create_room_monitor_report()

# Advanced room management functions
def auto_join_best_room(game_mode: str = "teambattle", min_players: int = 4) -> Optional[Dict]:
    """Automatically join the best available room"""
    api = MC5EnhancedAPI()
    best_rooms = api.find_best_rooms(game_mode=game_mode, min_players=min_players)
    
    if best_rooms:
        best_room = best_rooms[0]
        print(f"🎯 Found best room: {best_room.get('name', 'Unknown')}")
        print(f"   Players: {best_room.get('member_count', 0)}/{best_room.get('capacity', 0)}")
        print(f"   Fill Rate: {best_room.get('fill_rate', 0):.1f}%")
        return best_room
    else:
        print("❌ No suitable rooms found")
        return None

def analyze_player_activity(time_window_minutes: int = 60) -> Dict:
    """Analyze player activity over time window"""
    api = MC5EnhancedAPI()
    
    # Get current room data
    current_rooms = api.room_api.find_rooms(limit=100)
    
    activity = {
        "total_active_players": 0,
        "rooms_analyzed": len(current_rooms),
        "average_players_per_room": 0,
        "most_active_game_mode": None,
        "player_distribution": {}
    }
    
    total_players = 0
    game_modes = {}
    
    for room in current_rooms:
        player_count = room.get('member_count', 0)
        game_mode = room.get('_game_mode', 'Unknown')
        
        total_players += player_count
        game_modes[game_mode] = game_modes.get(game_mode, 0) + player_count
    
    activity["total_active_players"] = total_players
    activity["average_players_per_room"] = total_players / len(current_rooms) if current_rooms else 0
    
    if game_modes:
        activity["most_active_game_mode"] = max(game_modes, key=game_modes.get)
        activity["player_distribution"] = game_modes
    
    return activity
