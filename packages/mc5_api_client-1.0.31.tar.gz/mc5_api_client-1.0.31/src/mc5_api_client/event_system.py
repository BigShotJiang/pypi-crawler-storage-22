# ────────────[ KAKUZU ]────────────────────────────
# | Discord  : kakuzu_f0
# | Telegram : kakuzu_f0
# | File     : event_system.py
# | License  : MIT License © 2026 Kakuzu
# | Brief    : MC5 Event System for API Client
# ────────────────★─────────────────────────────────

"""
MC5 Event System

This module provides comprehensive event functionality for Modern Combat 5,
including event registration, participation, and event information retrieval.

Based on reverse-engineered API endpoints for MC5 events.
"""

import json
import requests
from typing import Dict, Optional, List
from datetime import datetime

from .ultra_simple_chat import _get_chat


class MC5EventSystem:
    """MC5 Event System - Register for events and get event information"""
    
    def __init__(self):
        """Initialize Event System"""
        self.chat = _get_chat()
        self.base_url = "https://eur-osiris.gameloft.com"
        
    def register_for_event(self, event_id: str) -> bool:
        """
        Register for an event
        
        Args:
            event_id: Event ID (e.g., '0c646c6a-e61c-11f0-be58-b8ca3a634708')
            
        Returns:
            True if registration successful, False otherwise
        """
        try:
            url = f"{self.base_url}/events/{event_id}/participants/me"
            
            # Get access token and credentials
            access_token = getattr(self.chat, 'access_token', 'unknown')
            credential = getattr(self.chat, 'credential', 'unknown')
            
            # Prepare data
            data = {
                'access_token': access_token
            }
            
            response = requests.post(url, data=data, timeout=10)
            
            if response.status_code == 200:
                print(f"🎉 Successfully registered for event: {event_id}")
                return True
            else:
                print(f"❌ Failed to register for event: {response.status_code}")
                print(f"📝 Response: {response.text}")
                return False
                
        except Exception as e:
            print(f"❌ Error registering for event: {e}")
            return False
    
    def get_event_leaderboard(self, event_id: str, offset: int = 0, limit: int = 100) -> Optional[Dict]:
        """
        Get event leaderboard
        
        Args:
            event_id: Event ID
            offset: Offset for pagination (default: 0)
            limit: Number of entries to retrieve (default: 100)
            
        Returns:
            Leaderboard data or None if failed
        """
        try:
            url = f"https://eur-olympus.gameloft.com/leaderboards/desc/Leaderboard_{event_id}"
            
            # Get access token and credentials
            access_token = getattr(self.chat, 'access_token', 'unknown')
            credential = getattr(self.chat, 'credential', 'unknown')
            
            # Prepare parameters
            params = {
                'access_token': access_token,
                'offset': str(offset),
                'limit': str(limit)
            }
            
            response = requests.get(url, params=params, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                print(f"📊 Retrieved leaderboard for event: {event_id}")
                print(f"👥 Total entries: {data.get('total_entries', 0)}")
                return data
            else:
                print(f"❌ Failed to get leaderboard: {response.status_code}")
                print(f"📝 Response: {response.text}")
                return None
                
        except Exception as e:
            print(f"❌ Error getting leaderboard: {e}")
            return None
    
    def get_my_event_rank(self, event_id: str, limit: int = 5) -> Optional[Dict]:
        """
        Get your rank and nearby players in event leaderboard
        
        Args:
            event_id: Event ID
            limit: Number of nearby players to show (default: 5)
            
        Returns:
            Your leaderboard entry and nearby players or None if failed
        """
        try:
            url = f"https://eur-olympus.gameloft.com/leaderboards/desc/Leaderboard_{event_id}/me"
            
            # Get access token and credentials
            access_token = getattr(self.chat, 'access_token', 'unknown')
            credential = getattr(self.chat, 'credential', 'unknown')
            
            # Prepare parameters
            params = {
                'access_token': access_token,
                'limit': str(limit)
            }
            
            response = requests.get(url, params=params, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                my_entry = data.get('my_entry')
                if my_entry:
                    rank = my_entry.get('rank', 0)
                    score = my_entry.get('score', 0)
                    print(f"🏆 Your event rank: #{rank} with {score} points")
                    return data
                else:
                    print("❌ You are not registered for this event")
                    return None
            else:
                print(f"❌ Failed to get your rank: {response.status_code}")
                print(f"📝 Response: {response.text}")
                return None
                
        except Exception as e:
            print(f"❌ Error getting your rank: {e}")
            return None
    
    def show_event_leaderboard(self, event_id: str, top_count: int = 10) -> None:
        """
        Display event leaderboard in a formatted way
        
        Args:
            event_id: Event ID
            top_count: Number of top players to show (default: 10)
        """
        data = self.get_event_leaderboard(event_id, limit=top_count)
        
        if not data:
            return
        
        print(f"\n🏆 Event Leaderboard - Top {top_count}")
        print("=" * 50)
        
        entries = data.get('data', [])
        
        for i, entry in enumerate(entries[:top_count], 1):
            rank = entry.get('rank', i)
            name = entry.get('display_name', 'Unknown')
            score = entry.get('score', 0)
            clan = entry.get('_clan_name', '')
            xp = entry.get('_xp', 0)
            
            print(f"#{rank:2d} {name:<20} {score:>8.1f} pts")
            if clan:
                print(f"     🏰 Clan: {clan}")
            print(f"     ⭐ XP: {xp}")
            print()
    
    def show_my_event_status(self, event_id: str) -> None:
        """
        Display your event status and nearby players
        
        Args:
            event_id: Event ID
        """
        data = self.get_my_event_rank(event_id)
        
        if not data:
            return
        
        print(f"\n👤 Your Event Status")
        print("=" * 30)
        
        my_entry = data.get('my_entry')
        if my_entry:
            rank = my_entry.get('rank', 0)
            score = my_entry.get('score', 0)
            name = my_entry.get('display_name', 'Unknown')
            clan = my_entry.get('_clan_name', '')
            xp = my_entry.get('_xp', 0)
            
            print(f"🏆 Rank: #{rank}")
            print(f"👤 Name: {name}")
            print(f"💯 Score: {score} points")
            if clan:
                print(f"🏰 Clan: {clan}")
            print(f"⭐ XP: {xp}")
            
            # Show nearby players
            nearby_entries = data.get('data', [])
            if nearby_entries:
                print(f"\n📍 Nearby Players:")
                for entry in nearby_entries:
                    if entry.get('id') != my_entry.get('id'):
                        rank = entry.get('rank', 0)
                        name = entry.get('display_name', 'Unknown')
                        score = entry.get('score', 0)
                        print(f"   #{rank} {name}: {score} pts")


# Convenience functions
def register_event(event_id: str) -> bool:
    """Register for an event"""
    system = MC5EventSystem()
    return system.register_for_event(event_id)


def get_event_leaderboard(event_id: str, offset: int = 0, limit: int = 100) -> Optional[Dict]:
    """Get event leaderboard"""
    system = MC5EventSystem()
    return system.get_event_leaderboard(event_id, offset, limit)


def get_my_event_rank(event_id: str, limit: int = 5) -> Optional[Dict]:
    """Get your event rank"""
    system = MC5EventSystem()
    return system.get_my_event_rank(event_id, limit)


def show_event_leaderboard(event_id: str, top_count: int = 10) -> None:
    """Show event leaderboard"""
    system = MC5EventSystem()
    system.show_event_leaderboard(event_id, top_count)


def show_my_event_status(event_id: str) -> None:
    """Show your event status"""
    system = MC5EventSystem()
    system.show_my_event_status(event_id)


# Quick event functions for common events
def register_current_event() -> bool:
    """Register for the current event"""
    current_event_id = "0c646c6a-e61c-11f0-be58-b8ca3a634708"
    return register_event(current_event_id)


def show_current_event_leaderboard(top_count: int = 10) -> None:
    """Show current event leaderboard"""
    current_event_id = "0c646c6a-e61c-11f0-be58-b8ca3a634708"
    show_event_leaderboard(current_event_id, top_count)


def show_my_current_event_status() -> None:
    """Show your current event status"""
    current_event_id = "0c646c6a-e61c-11f0-be58-b8ca3a634708"
    show_my_event_status(current_event_id)
