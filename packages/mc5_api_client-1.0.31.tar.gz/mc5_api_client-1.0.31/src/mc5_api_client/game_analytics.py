#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : game_analytics.py
# | License  : MIT License © 2026 Chizoba
# | Brief    | Game analytics and statistics for MC5 API Client
# ────────────────★─────────────────────────────────

"""
MC5 Game Analytics and Statistics

This module provides comprehensive game analytics, player statistics,
and performance tracking for Modern Combat 5.

Features:
- Player performance tracking
- Game mode analytics
- Server performance metrics
- Player ranking systems
- Match history analysis
- Real-time statistics
"""

import time
import json
from typing import Dict, List, Optional, Union, Tuple
from datetime import datetime, timedelta
from collections import defaultdict, Counter
from .room_matchmaking import MC5RoomAPI
from .advanced_chat_utilities import chat_manager

class MC5GameAnalytics:
    """Comprehensive game analytics system"""
    
    def __init__(self, client_id: str = "1875:55979:6.0.0a:windows:windows", region: str = "eur"):
        """Initialize game analytics"""
        self.client_id = client_id
        self.region = region
        self.room_api = MC5RoomAPI(client_id, region)
        self.player_data = {}
        self.match_history = []
        self.performance_metrics = defaultdict(list)
        
    def analyze_player_distribution(self) -> Dict:
        """Analyze player distribution across servers and game modes"""
        try:
            # Get room data from different server types
            ranked_rooms = self.room_api.find_rooms(server_type="mp_server", limit=100)
            custom_rooms = self.room_api.find_rooms(server_type="mp_server_test", limit=100)
            clan_rooms = self.room_api.find_rooms(server_type="clan_dummy_server", limit=100)
            
            analysis = {
                'total_players_found': 0,
                'unique_players': set(),
                'server_distribution': {
                    'ranked': len(ranked_rooms),
                    'custom': len(custom_rooms),
                    'clan': len(clan_rooms)
                },
                'game_mode_distribution': defaultdict(int),
                'country_distribution': defaultdict(int),
                'level_distribution': defaultdict(int),
                'average_players_per_room': 0,
                'peak_activity_time': None,
                'room_capacity_analysis': {
                    'total_capacity': 0,
                    'total_occupied': 0,
                    'average_fill_rate': 0
                }
            }
            
            all_rooms = ranked_rooms + custom_rooms + clan_rooms
            total_capacity = 0
            total_occupied = 0
            
            for room in all_rooms:
                members = room.get('members', [])
                member_count = room.get('member_count', 0)
                capacity = room.get('capacity', 0)
                game_mode = room.get('_game_mode', 'Unknown')
                
                # Track players
                for member in members:
                    player_name = member.get('name', 'Unknown')
                    country = member.get('country', 'Unknown')
                    level = member.get('level', '0')
                    
                    analysis['unique_players'].add(player_name)
                    analysis['country_distribution'][country] += 1
                    
                    try:
                        level_int = int(level)
                        if level_int <= 10:
                            analysis['level_distribution']['1-10'] += 1
                        elif level_int <= 25:
                            analysis['level_distribution']['11-25'] += 1
                        elif level_int <= 50:
                            analysis['level_distribution']['26-50'] += 1
                        elif level_int <= 100:
                            analysis['level_distribution']['51-100'] += 1
                        else:
                            analysis['level_distribution']['100+'] += 1
                    except:
                        analysis['level_distribution']['Unknown'] += 1
                
                analysis['game_mode_distribution'][game_mode] += member_count
                analysis['total_players_found'] += member_count
                
                total_capacity += capacity
                total_occupied += member_count
            
            # Calculate averages
            if all_rooms:
                analysis['average_players_per_room'] = analysis['total_players_found'] / len(all_rooms)
            
            analysis['room_capacity_analysis']['total_capacity'] = total_capacity
            analysis['room_capacity_analysis']['total_occupied'] = total_occupied
            
            if total_capacity > 0:
                analysis['room_capacity_analysis']['average_fill_rate'] = (
                    total_occupied / total_capacity * 100
                )
            
            analysis['unique_players'] = len(analysis['unique_players'])
            analysis['peak_activity_time'] = datetime.now().strftime('%H:%M:%S')
            
            return dict(analysis)
            
        except Exception as e:
            print(f"❌ Error analyzing player distribution: {e}")
            return {}
    
    def get_game_mode_popularity(self) -> Dict:
        """Get popularity ranking of game modes"""
        try:
            rooms = self.room_api.find_rooms(limit=200)
            
            mode_stats = defaultdict(lambda: {'rooms': 0, 'players': 0, 'avg_players': 0})
            
            for room in rooms:
                game_mode = room.get('_game_mode', 'Unknown')
                player_count = room.get('member_count', 0)
                
                mode_stats[game_mode]['rooms'] += 1
                mode_stats[game_mode]['players'] += player_count
            
            # Calculate averages and rankings
            rankings = {}
            for mode, stats in mode_stats.items():
                if stats['rooms'] > 0:
                    stats['avg_players'] = stats['players'] / stats['rooms']
                    rankings[mode] = {
                        'rank': 0,  # Will be set below
                        'rooms': stats['rooms'],
                        'total_players': stats['players'],
                        'avg_players_per_room': round(stats['avg_players'], 1),
                        'popularity_score': stats['players'] * stats['rooms']
                    }
            
            # Sort by popularity score
            sorted_modes = sorted(rankings.items(), key=lambda x: x[1]['popularity_score'], reverse=True)
            
            for rank, (mode, data) in enumerate(sorted_modes, 1):
                data['rank'] = rank
                rankings[mode] = data
            
            return rankings
            
        except Exception as e:
            print(f"❌ Error getting game mode popularity: {e}")
            return {}
    
    def analyze_server_performance(self) -> Dict:
        """Analyze server performance metrics"""
        try:
            start_time = time.time()
            
            # Test different server types
            server_types = ['mp_server', 'mp_server_test', 'clan_dummy_server']
            performance_data = {}
            
            for server_type in server_types:
                server_start = time.time()
                rooms = self.room_api.find_rooms(server_type=server_type, limit=50)
                server_response_time = time.time() - server_start
                
                total_players = sum(room.get('member_count', 0) for room in rooms)
                total_capacity = sum(room.get('capacity', 0) for room in rooms)
                
                performance_data[server_type] = {
                    'response_time_ms': round(server_response_time * 1000, 2),
                    'rooms_found': len(rooms),
                    'total_players': total_players,
                    'total_capacity': total_capacity,
                    'fill_rate': round((total_players / total_capacity * 100) if total_capacity > 0 else 0, 1),
                    'avg_players_per_room': round(total_players / len(rooms), 1) if rooms else 0,
                    'status': 'healthy' if server_response_time < 2.0 else 'slow'
                }
            
            total_time = time.time() - start_time
            
            return {
                'overall_response_time_ms': round(total_time * 1000, 2),
                'server_performance': performance_data,
                'fastest_server': min(performance_data.items(), key=lambda x: x[1]['response_time_ms'])[0],
                'most_populated_server': max(performance_data.items(), key=lambda x: x[1]['total_players'])[0],
                'analysis_time': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            }
            
        except Exception as e:
            print(f"❌ Error analyzing server performance: {e}")
            return {}
    
    def track_player_activity(self, player_name: str, duration_minutes: int = 60) -> Dict:
        """Track specific player activity over time"""
        try:
            activity_log = []
            start_time = datetime.now()
            end_time = start_time + timedelta(minutes=duration_minutes)
            
            print(f"🔍 Tracking player '{player_name}' for {duration_minutes} minutes...")
            
            while datetime.now() < end_time:
                # Search for player in current rooms
                all_rooms = self.room_api.find_rooms(limit=100)
                
                found_in_rooms = []
                for room in all_rooms:
                    members = room.get('members', [])
                    for member in members:
                        if member.get('name', '').lower() == player_name.lower():
                            found_in_rooms.append({
                                'timestamp': datetime.now().strftime('%H:%M:%S'),
                                'room_name': room.get('name', 'Unknown'),
                                'game_mode': room.get('_game_mode', 'Unknown'),
                                'server_type': room.get('server_type', 'Unknown'),
                                'country': member.get('country', 'Unknown'),
                                'level': member.get('level', 'Unknown'),
                                'killsign': member.get('killSign', 'Unknown')
                            })
                
                if found_in_rooms:
                    activity_log.extend(found_in_rooms)
                    for activity in found_in_rooms:
                        print(f"👤 Found {player_name} in {activity['game_mode']} ({activity['server_type']})")
                
                time.sleep(30)  # Check every 30 seconds
            
            return {
                'player_name': player_name,
                'tracking_duration': duration_minutes,
                'total_sightings': len(activity_log),
                'activities': activity_log,
                'most_played_mode': Counter([a['game_mode'] for a in activity_log]).most_common(1)[0] if activity_log else None,
                'preferred_server': Counter([a['server_type'] for a in activity_log]).most_common(1)[0] if activity_log else None
            }
            
        except Exception as e:
            print(f"❌ Error tracking player activity: {e}")
            return {}
    
    def generate_comprehensive_report(self) -> str:
        """Generate comprehensive game analytics report"""
        print("📊 Generating comprehensive analytics report...")
        
        # Gather all analytics
        player_dist = self.analyze_player_distribution()
        mode_popularity = self.get_game_mode_popularity()
        server_perf = self.analyze_server_performance()
        
        report = f"""
🎮 MC5 COMPREHENSIVE ANALYTICS REPORT
{'='*60}
📅 Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

👥 PLAYER DISTRIBUTION ANALYSIS:
   Total Players Found: {player_dist.get('total_players_found', 0)}
   Unique Players: {player_dist.get('unique_players', 0)}
   Average Players/Room: {player_dist.get('average_players_per_room', 0):.1f}
   
📊 SERVER DISTRIBUTION:
"""
        
        for server_type, count in player_dist.get('server_distribution', {}).items():
            report += f"   {server_type.title()}: {count} rooms\n"
        
        report += f"\n🎯 GAME MODE POPULARITY:\n"
        for mode, data in list(mode_popularity.items())[:5]:  # Top 5
            report += f"   {data['rank']}. {mode}: {data['total_players']} players ({data['avg_players_per_room']}/room)\n"
        
        report += f"\n🖥️ SERVER PERFORMANCE:\n"
        for server, data in server_perf.get('server_performance', {}).items():
            status_emoji = "✅" if data['status'] == 'healthy' else "⚠️"
            report += f"   {status_emoji} {server}: {data['response_time_ms']}ms, {data['total_players']} players\n"
        
        report += f"\n📈 ROOM CAPACITY ANALYSIS:\n"
        capacity = player_dist.get('room_capacity_analysis', {})
        report += f"   Total Capacity: {capacity.get('total_capacity', 0)}\n"
        report += f"   Total Occupied: {capacity.get('total_occupied', 0)}\n"
        report += f"   Average Fill Rate: {capacity.get('average_fill_rate', 0):.1f}%\n"
        
        return report

# Convenience functions
def get_player_analytics() -> Dict:
    """Get comprehensive player analytics"""
    analytics = MC5GameAnalytics()
    return analytics.analyze_player_distribution()

def get_game_mode_rankings() -> Dict:
    """Get game mode popularity rankings"""
    analytics = MC5GameAnalytics()
    return analytics.get_game_mode_popularity()

def check_server_health() -> Dict:
    """Check server health and performance"""
    analytics = MC5GameAnalytics()
    return analytics.analyze_server_performance()

def track_player(player_name: str, minutes: int = 30) -> Dict:
    """Track a specific player's activity"""
    analytics = MC5GameAnalytics()
    return analytics.track_player_activity(player_name, minutes)

def generate_analytics_report() -> str:
    """Generate full analytics report"""
    analytics = MC5GameAnalytics()
    return analytics.generate_comprehensive_report()

# Real-time monitoring functions
def start_real_time_monitoring(update_interval: int = 60) -> None:
    """Start real-time monitoring dashboard"""
    import threading
    
    def monitor_loop():
        while True:
            try:
                # Get current stats
                player_stats = get_player_analytics()
                server_health = check_server_health()
                
                # Clear screen and display dashboard
                print("\033[2J\033[H")  # Clear screen
                print("🎮 MC5 REAL-TIME MONITORING DASHBOARD")
                print("=" * 50)
                print(f"📊 Last Update: {datetime.now().strftime('%H:%M:%S')}")
                print(f"👥 Total Players: {player_stats.get('total_players_found', 0)}")
                print(f"🏠 Active Rooms: {player_stats.get('server_distribution', {}).get('ranked', 0) + player_stats.get('server_distribution', {}).get('custom', 0)}")
                print(f"⚡ Server Status: {server_health.get('fastest_server', 'Unknown')} (fastest)")
                
                # Show top game modes
                mode_rankings = get_game_mode_rankings()
                if mode_rankings:
                    print("\n🎯 Top Game Modes:")
                    for mode, data in list(mode_rankings.items())[:3]:
                        print(f"   {data['rank']}. {mode}: {data['total_players']} players")
                
                time.sleep(update_interval)
                
            except KeyboardInterrupt:
                print("\n🛑 Real-time monitoring stopped")
                break
            except Exception as e:
                print(f"❌ Monitoring error: {e}")
                time.sleep(update_interval)
    
    thread = threading.Thread(target=monitor_loop, daemon=True)
    thread.start()
    print(f"📊 Real-time monitoring started (updates every {update_interval} seconds)")

# Advanced statistics functions
def calculate_player_skill_distribution() -> Dict:
    """Calculate player skill level distribution"""
    analytics = MC5GameAnalytics()
    player_data = analytics.analyze_player_distribution()
    
    level_dist = player_data.get('level_distribution', {})
    total_players = sum(level_dist.values())
    
    if total_players == 0:
        return {}
    
    distribution = {}
    for level_range, count in level_dist.items():
        distribution[level_range] = {
            'count': count,
            'percentage': round((count / total_players) * 100, 1)
        }
    
    return distribution

def get_peak_activity_times() -> Dict:
    """Analyze peak activity times (placeholder for future implementation)"""
    # This would require historical data collection
    return {
        'morning_peak': '09:00-11:00',
        'afternoon_peak': '14:00-16:00',
        'evening_peak': '19:00-22:00',
        'lowest_activity': '03:00-06:00'
    }
