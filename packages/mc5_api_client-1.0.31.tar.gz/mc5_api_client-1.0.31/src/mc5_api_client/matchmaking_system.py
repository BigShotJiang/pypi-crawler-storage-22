# ────────────[ KAKUZU ]────────────────────────────
# | Discord  : kakuzu_f0
# | Telegram : kakuzu_f0
# | File     : matchmaking_system.py
# | License  : MIT License © 2026 Kakuzu
# | Brief    : MC5 Matchmaking System for API Client
# ────────────────★─────────────────────────────────

"""
MC5 Matchmaking System

This module provides comprehensive matchmaking functionality for Modern Combat 5,
including quick play, custom game finding, and room management.

Based on reverse-engineered API endpoints for MC5 matchmaking.
"""

import json
import requests
from typing import Dict, Optional, List
from datetime import datetime

from .ultra_simple_chat import _get_chat


class MC5MatchmakingSystem:
    """MC5 Matchmaking System - Find and join games"""
    
    def __init__(self):
        """Initialize Matchmaking System"""
        self.chat = _get_chat()
        self.base_url = "https://eur-anubisfinder.gameloft.com"
        self.client_id = getattr(self.chat, 'client_id', '1875:55979:6.0.0a:windows:windows')
        
    def quick_play_any(self, score: Optional[int] = None, event_id: Optional[str] = None) -> Optional[Dict]:
        """
        Quick play - find any available game
        
        Args:
            score: Your matchmaking score (optional)
            event_id: Event ID for event-specific matchmaking (optional)
            
        Returns:
            Room information or None if failed
        """
        try:
            url = f"{self.base_url}/rooms/{self.client_id}/automatch/quickplayany"
            
            # Get access token and credentials
            access_token = getattr(self.chat, 'access_token', 'unknown')
            credential = getattr(self.chat, 'credential', 'unknown')
            nickname = getattr(self.chat, 'nickname', 'Player')
            
            # Ensure nickname is a string, not a method
            if callable(nickname):
                nickname = nickname() if callable(nickname) else str(nickname)
            elif not isinstance(nickname, str):
                nickname = str(nickname)
            
            # Build filter
            filter_parts = [
                "_game_mode=battle",
                "_joinable=true",
                "capacity=12"
            ]
            
            if event_id:
                filter_parts.append(f"_event_id={event_id}")
                filter_parts.append("_event_league=x")
                filter_parts.append("_PIN=x")
            
            filter_parts.extend([
                "_customs_room=false",
                "_betAmount=0",
                "_veteran=false",
                "_automatch_name=quickplayany"
            ])
            
            filter_str = "&".join(filter_parts)
            
            # Prepare data
            data = {
                'access_token': access_token,
                'filter': filter_str,
                'user': json.dumps({"name": nickname}),
                'score': str(score or 0),
                'server_type': 'mp_server'
            }
            
            response = requests.post(url, data=data, timeout=15)
            
            if response.status_code == 200:
                room_data = response.json()
                print(f"🎮 Found game! Room ID: {room_data.get('id')}")
                print(f"👥 Players: {room_data.get('member_count', 0)}/{room_data.get('capacity', 12)}")
                print(f"🎯 Game Mode: {room_data.get('_game_mode', 'battle')}")
                return room_data
            else:
                print(f"❌ Failed to find game: {response.status_code}")
                print(f"📝 Response: {response.text}")
                return None
                
        except Exception as e:
            print(f"❌ Error in quick play: {e}")
            return None
    
    def find_custom_games(self, game_mode: str = "battle", capacity: int = 12, 
                         event_id: Optional[str] = None, customs_room: bool = False) -> Optional[Dict]:
        """
        Find custom games with specific criteria
        
        Args:
            game_mode: Game mode (battle, teambattle, ctf, etc.)
            capacity: Room capacity
            event_id: Event ID for event-specific games
            customs_room: Whether to find custom rooms
            
        Returns:
            Room information or None if failed
        """
        try:
            url = f"{self.base_url}/rooms/{self.client_id}/automatch/custom"
            
            # Get access token and credentials
            access_token = getattr(self.chat, 'access_token', 'unknown')
            credential = getattr(self.chat, 'credential', 'unknown')
            nickname = getattr(self.chat, 'nickname', 'Player')
            
            # Ensure nickname is a string, not a method
            if callable(nickname):
                nickname = nickname() if callable(nickname) else str(nickname)
            elif not isinstance(nickname, str):
                nickname = str(nickname)
            
            # Build filter
            filter_parts = [
                f"_game_mode={game_mode}",
                "_joinable=true",
                f"capacity={capacity}"
            ]
            
            if event_id:
                filter_parts.append(f"_event_id={event_id}")
                filter_parts.append("_event_league=x")
                filter_parts.append("_PIN=x")
            
            filter_parts.append(f"_customs_room={str(customs_room).lower()}")
            filter_parts.extend([
                "_betAmount=0",
                "_veteran=false",
                "_automatch_name=custom"
            ])
            
            filter_str = "&".join(filter_parts)
            
            # Prepare data
            data = {
                'access_token': access_token,
                'filter': filter_str,
                'user': json.dumps({"name": nickname}),
                'score': '0',
                'server_type': 'mp_server'
            }
            
            response = requests.post(url, data=data, timeout=15)
            
            if response.status_code == 200:
                room_data = response.json()
                print(f"🎮 Found custom game! Room ID: {room_data.get('id')}")
                print(f"👥 Players: {room_data.get('member_count', 0)}/{room_data.get('capacity', capacity)}")
                print(f"🎯 Game Mode: {room_data.get('_game_mode', game_mode)}")
                return room_data
            else:
                print(f"❌ Failed to find custom game: {response.status_code}")
                print(f"📝 Response: {response.text}")
                return None
                
        except Exception as e:
            print(f"❌ Error finding custom games: {e}")
            return None
    
    def get_room_info(self, room_id: str) -> Optional[Dict]:
        """
        Get detailed information about a specific room
        
        Args:
            room_id: Room ID
            
        Returns:
            Room information or None if failed
        """
        try:
            url = f"{self.base_url}/rooms/{room_id}"
            
            # Get access token
            access_token = getattr(self.chat, 'access_token', 'unknown')
            
            # Prepare parameters
            params = {
                'access_token': access_token
            }
            
            response = requests.get(url, params=params, timeout=10)
            
            if response.status_code == 200:
                room_data = response.json()
                print(f"📊 Room info retrieved for: {room_id}")
                return room_data
            else:
                print(f"❌ Failed to get room info: {response.status_code}")
                print(f"📝 Response: {response.text}")
                return None
                
        except Exception as e:
            print(f"❌ Error getting room info: {e}")
            return None
    
    def show_room_details(self, room_data: Dict) -> None:
        """
        Display room information in a formatted way
        
        Args:
            room_data: Room data from matchmaking response
        """
        if not room_data:
            return
        
        print(f"\n🎮 Room Details")
        print("=" * 30)
        
        room_id = room_data.get('id', 'Unknown')
        game_mode = room_data.get('_game_mode', 'Unknown')
        member_count = room_data.get('member_count', 0)
        capacity = room_data.get('capacity', 12)
        available_slots = room_data.get('available_slots', capacity - member_count)
        
        print(f"🆔 Room ID: {room_id}")
        print(f"🎯 Game Mode: {game_mode}")
        print(f"👥 Players: {member_count}/{capacity}")
        print(f"📊 Available Slots: {available_slots}")
        
        # Event information
        event_id = room_data.get('_event_id')
        if event_id:
            print(f"🏆 Event ID: {event_id}")
        
        # Server information
        lobby_host = room_data.get('lobby_host')
        if lobby_host:
            lobby_port = room_data.get('lobby_port', 'N/A')
            print(f"🌐 Server: {lobby_host}:{lobby_port}")
        
        # Members
        members = room_data.get('members', [])
        if members:
            print(f"\n👥 Members ({len(members)}):")
            for i, member in enumerate(members, 1):
                name = member.get('name', 'Unknown')
                country = member.get('country', 'N/A')
                score = member.get('matchmaking_score', 0)
                print(f"   {i}. {name} ({country}) - Score: {score}")
        
        # Owner information
        owner = room_data.get('owner')
        if owner:
            owner_name = owner.get('name', 'Unknown')
            print(f"\n👑 Room Owner: {owner_name}")
    
    def quick_event_play(self, event_id: str, score: Optional[int] = None) -> Optional[Dict]:
        """
        Quick play for specific event
        
        Args:
            event_id: Event ID
            score: Your matchmaking score (optional)
            
        Returns:
            Room information or None if failed
        """
        return self.quick_play_any(score=score, event_id=event_id)
    
    def get_available_rooms(self, game_mode: str = "battle", limit: int = 10) -> List[Dict]:
        """
        Get list of available rooms (simplified version)
        
        Args:
            game_mode: Game mode to filter by
            limit: Maximum number of rooms to return
            
        Returns:
            List of room information
        """
        rooms = []
        
        # Try to find rooms multiple times
        for i in range(limit):
            room_data = self.find_custom_games(game_mode=game_mode)
            if room_data and room_data.get('id'):
                rooms.append(room_data)
        
        return rooms


# Convenience functions
def quick_play(score: Optional[int] = None, event_id: Optional[str] = None) -> Optional[Dict]:
    """Quick play - find any available game"""
    system = MC5MatchmakingSystem()
    return system.quick_play_any(score, event_id)


def find_game(game_mode: str = "battle", capacity: int = 12, 
              event_id: Optional[str] = None) -> Optional[Dict]:
    """Find custom game with specific criteria"""
    system = MC5MatchmakingSystem()
    return system.find_custom_games(game_mode, capacity, event_id)


def get_room_info(room_id: str) -> Optional[Dict]:
    """Get room information"""
    system = MC5MatchmakingSystem()
    return system.get_room_info(room_id)


def show_room_details(room_data: Dict) -> None:
    """Show room details"""
    system = MC5MatchmakingSystem()
    system.show_room_details(room_data)


# Quick matchmaking functions
def quick_battle(score: Optional[int] = None) -> Optional[Dict]:
    """Quick battle matchmaking"""
    return quick_play(score)


def quick_event_battle(event_id: str, score: Optional[int] = None) -> Optional[Dict]:
    """Quick event battle matchmaking"""
    return quick_play(score, event_id)


def quick_team_battle(score: Optional[int] = None) -> Optional[Dict]:
    """Quick team battle matchmaking"""
    return find_game("teambattle", 12)


def quick_ctf(score: Optional[int] = None) -> Optional[Dict]:
    """Quick CTF matchmaking"""
    return find_game("ctf", 12)


def current_event_quick_play(score: Optional[int] = None) -> Optional[Dict]:
    """Quick play for current event"""
    current_event_id = "0c646c6a-e61c-11f0-be58-b8ca3a634708"
    return quick_play(score, current_event_id)
