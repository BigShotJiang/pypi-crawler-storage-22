#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : mp_invite_system.py
# | License  : MIT License © 2026 Chizoba
# | Brief    | MP Invite system for MC5 API Client
# ────────────────★─────────────────────────────────

"""
MC5 MP Invite System

This module provides comprehensive MP Invite functionality for Modern Combat 5,
allowing users to create and share game invitations in global chat and squad chat.

Based on reverse-engineered API endpoints for MP Invite messages.

Features:
- Create MP Invites for any game mode
- Support for all maps and game modes
- Custom room attributes and settings
- Global chat and squad chat invitations
- VIP mode with password protection
- Complete game mode and map support
"""

import json
import requests
from typing import Dict, List, Optional, Union
from datetime import datetime
from .ultra_simple_chat import _get_chat

class MC5MPInviteSystem:
    """MC5 MP Invite System - Create and share game invitations"""
    
    def __init__(self):
        """Initialize MP Invite system"""
        self.chat = _get_chat()
        
        # Game modes from reverse-engineered data
        self.GAME_MODES = {
            'teambattle': 'Team Battle',
            'ctf': 'Capture The Flag',
            'zcm': 'Zone Control',
            'vip': 'VIP',
            'duel': 'Duel',
            'tournament': 'Tournament',
            'ffa': 'Free For All',
            'rush': 'Rush',
            'cargo': 'Cargo',
            'battle': 'Battle Royal'
        }
        
        # Maps from reverse-engineered data
        self.MAPS = {
            0: 'Streets',
            1: 'Rooftops',
            2: 'Construction Site',
            3: 'Canals',
            4: 'Scramble',
            5: 'Museum',
            6: 'Vantage',
            7: 'Conversion',
            8: 'Overtime',
            10: 'Showdown',  # Duel map
            12: 'Abandoned Site'  # Duel map
        }
        
        # Default room attributes
        self.DEFAULT_ATTRIBUTES = {
            "_armorTiers": "31",
            "_betAmount": "0",
            "_can_spectate": "false",
            "_customs_room": "true",
            "_event_id": "x",
            "_fast_spawn": "true",
            "_friends_room": "false",
            "_game_state": "lobby",
            "_ggi": "55979",
            "_joinable": "true",
            "_military_support": "true",
            "_playerClasses": "2047",
            "_public": "true",
            "_useCores": "true",
            "_useGrenades": "true",
            "_useMaskBonus": "true",
            "_veteran": "false",
            "_weaponTiers": "255"
        }
    
    def create_mp_invite(self,
                        game_mode: str,
                        map_index: int = 0,
                        max_players: int = 12,
                        room_name: str = None,
                        password: str = None,
                        custom_attributes: Dict = None,
                        message: str = "MP Invite") -> Dict:
        """
        Create an MP Invite for sharing in chat
        
        Args:
            game_mode: Game mode (teambattle, ctf, zcm, vip, duel, etc.)
            map_index: Map index (0-8 for regular maps, 10/12 for duel maps)
            max_players: Maximum players for the room
            room_name: Custom room name
            password: Room password (for VIP mode)
            custom_attributes: Additional room attributes
            message: Message to send with the invite
            
        Returns:
            MP Invite data ready for chat sharing
        """
        # Validate game mode
        if game_mode not in self.GAME_MODES:
            raise ValueError(f"Invalid game mode: {game_mode}. Valid modes: {list(self.GAME_MODES.keys())}")
        
        # Validate map index
        if map_index not in self.MAPS:
            raise ValueError(f"Invalid map index: {map_index}. Valid maps: {list(self.MAPS.keys())}")
        
        # Build room attributes
        attributes = self.DEFAULT_ATTRIBUTES.copy()
        attributes["_game_mode"] = game_mode
        attributes["_map_index"] = str(map_index)
        
        # Apply custom attributes
        if custom_attributes:
            attributes.update(custom_attributes)
        
        # Handle VIP mode specifics
        if game_mode == 'vip':
            attributes["_can_spectate"] = "true"
            attributes["_public"] = "false"
            if password:
                attributes["_passkey"] = password
            max_players = 16  # VIP mode supports more players
        
        # Handle duel mode specifics
        elif game_mode == 'duel':
            if map_index == 10:  # Showdown
                max_players = 8
                attributes["_military_support"] = "true"
            elif map_index == 12:  # Abandoned Site
                max_players = 4
                attributes["_military_support"] = "false"
                attributes["_fast_spawn"] = "false"
        
        # Create room data
        room_data = {
            "customAttributes": attributes,
            "level": 139,  # Default level
            "maxPlayers": max_players,
            "rating": 861,  # Default rating
            "roomId": f"generated_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        }
        
        # Create MP Invite data
        mp_invite_data = {
            "msg": message,
            "_fedId": f"fed_id:{getattr(self.chat, 'fed_id', 'unknown')}",
            "_killSign": getattr(self.chat, 'killsig', 'default_killsig_80'),
            "_killSignColor": getattr(self.chat, 'color', '12722475'),
            "_messageType": "3",
            "_mp_invite": json.dumps(room_data),
            "_senderName": getattr(self.chat, 'nickname', 'Player') if isinstance(getattr(self.chat, 'nickname', 'Player'), str) else 'Player',
            "_senderTimestamp": str(int(datetime.now().timestamp()))
        }
        
        return {
            "mp_invite_data": mp_invite_data,
            "room_data": room_data,
            "game_mode": game_mode,
            "map_name": self.MAPS[map_index],
            "max_players": max_players,
            "attributes": attributes
        }
    
    def send_mp_invite_to_global(self,
                                game_mode: str,
                                map_index: int = 0,
                                language: str = 'en',
                                **kwargs) -> bool:
        """
        Send MP Invite to global chat
        
        Args:
            game_mode: Game mode
            map_index: Map index
            language: Language channel (en, fr, de, etc.)
            **kwargs: Additional arguments for create_mp_invite
            
        Returns:
            True if successful, False otherwise
        """
        try:
            invite = self.create_mp_invite(game_mode, map_index, **kwargs)
            
            # Send to global chat channel
            channel = f"mc5_global.{language}"
            url = f"https://eur-fedex-fsg001.gameloft.com:34663/v1/chat/channels/{channel}"
            
            # Prepare data for chat API
            data = {
                'access_token': getattr(self.chat, 'access_token', 'unknown'),
                '_anonId': getattr(self.chat, 'credential', 'unknown'),
                'user': json.dumps({"nickname": getattr(self.chat, 'nickname', 'Player') if isinstance(getattr(self.chat, 'nickname', 'Player'), str) else 'Player'}),
                'msg': invite['mp_invite_data']['msg'],
                '_fedId': invite['mp_invite_data']['_fedId'],
                '_killSign': invite['mp_invite_data']['_killSign'],
                '_killSignColor': invite['mp_invite_data']['_killSignColor'],
                '_messageType': invite['mp_invite_data']['_messageType'],
                '_mp_invite': invite['mp_invite_data']['_mp_invite'],
                '_senderName': invite['mp_invite_data']['_senderName'],
                '_senderTimestamp': invite['mp_invite_data']['_senderTimestamp']
            }
            
            response = requests.post(url, data=data)
            return response.status_code == 200
            
        except Exception as e:
            print(f"❌ Error sending MP invite to global chat: {e}")
            return False
    
    def send_mp_invite_to_squad(self,
                                squad_id: str,
                                game_mode: str,
                                map_index: int = 0,
                                **kwargs) -> bool:
        """
        Send MP Invite to squad chat
        
        Args:
            squad_id: Squad room ID
            game_mode: Game mode
            map_index: Map index
            **kwargs: Additional arguments for create_mp_invite
            
        Returns:
            True if successful, False otherwise
        """
        try:
            invite = self.create_mp_invite(game_mode, map_index, **kwargs)
            
            # Send to squad room
            url = f"https://eur-fedex-fsg002.gameloft.com:52052/v1/chat/rooms/{squad_id}"
            
            # Prepare data for chat API
            data = {
                'access_token': getattr(self.chat, 'access_token', 'unknown'),
                '_anonId': getattr(self.chat, 'credential', 'unknown'),
                'user': json.dumps({"nickname": getattr(self.chat, 'nickname', 'Player') if isinstance(getattr(self.chat, 'nickname', 'Player'), str) else 'Player'}),
                'msg': invite['mp_invite_data']['msg'],
                '_fedId': invite['mp_invite_data']['_fedId'],
                '_killSign': invite['mp_invite_data']['_killSign'],
                '_killSignColor': invite['mp_invite_data']['_killSignColor'],
                '_messageType': invite['mp_invite_data']['_messageType'],
                '_mp_invite': invite['mp_invite_data']['_mp_invite'],
                '_senderName': invite['mp_invite_data']['_senderName'],
                '_senderTimestamp': invite['mp_invite_data']['_senderTimestamp']
            }
            
            response = requests.post(url, data=data)
            return response.status_code == 200
            
        except Exception as e:
            print(f"❌ Error sending MP invite to squad: {e}")
            return False
    
    def get_game_modes(self) -> Dict[str, str]:
        """Get all available game modes"""
        return self.GAME_MODES.copy()
    
    def get_maps(self) -> Dict[int, str]:
        """Get all available maps"""
        return self.MAPS.copy()
    
    def create_vip_invite(self,
                         map_index: int = 1,  # Rooftops
                         password: str = "1111",
                         max_players: int = 16,
                         **kwargs) -> Dict:
        """Create a VIP mode invite with password protection"""
        return self.create_mp_invite(
            game_mode='vip',
            map_index=map_index,
            max_players=max_players,
            password=password,
            **kwargs
        )
    
    def create_duel_invite(self,
                          map_name: str = 'showdown',  # or 'abandoned'
                          **kwargs) -> Dict:
        """Create a duel mode invite"""
        if map_name.lower() == 'showdown':
            map_index = 10
            max_players = 8
        elif map_name.lower() == 'abandoned':
            map_index = 12
            max_players = 4
        else:
            raise ValueError("Duel map must be 'showdown' or 'abandoned'")
        
        return self.create_mp_invite(
            game_mode='duel',
            map_index=map_index,
            max_players=max_players,
            **kwargs
        )

# Convenience functions for quick MP invites
def create_team_battle_invite(map_index: int = 0, max_players: int = 12, **kwargs) -> Dict:
    """Create a Team Battle invite"""
    system = MC5MPInviteSystem()
    return system.create_mp_invite('teambattle', map_index, max_players, **kwargs)

def create_ctf_invite(map_index: int = 0, max_players: int = 12, **kwargs) -> Dict:
    """Create a Capture The Flag invite"""
    system = MC5MPInviteSystem()
    return system.create_mp_invite('ctf', map_index, max_players, **kwargs)

def create_zone_control_invite(map_index: int = 0, max_players: int = 12, **kwargs) -> Dict:
    """Create a Zone Control invite"""
    system = MC5MPInviteSystem()
    return system.create_mp_invite('zcm', map_index, max_players, **kwargs)

def create_vip_invite(password: str = "1111", map_index: int = 1, **kwargs) -> Dict:
    """Create a VIP mode invite with password"""
    system = MC5MPInviteSystem()
    return system.create_vip_invite(map_index, password, **kwargs)

def create_duel_invite(map_name: str = 'showdown', **kwargs) -> Dict:
    """Create a duel mode invite"""
    system = MC5MPInviteSystem()
    return system.create_duel_invite(map_name, **kwargs)

def send_global_invite(game_mode: str, map_index: int = 0, language: str = 'en', **kwargs) -> bool:
    """Send MP invite to global chat"""
    system = MC5MPInviteSystem()
    return system.send_mp_invite_to_global(game_mode, map_index, language, **kwargs)

def send_squad_invite(squad_id: str, game_mode: str, map_index: int = 0, **kwargs) -> bool:
    """Send MP invite to squad chat"""
    system = MC5MPInviteSystem()
    return system.send_mp_invite_to_squad(squad_id, game_mode, map_index, **kwargs)

# Quick invite functions for common scenarios
def quick_team_battle_streets() -> bool:
    """Quick Team Battle on Streets map"""
    return send_global_invite('teambattle', 0, 'en')

def quick_ctf_rooftops() -> bool:
    """Quick CTF on Rooftops map"""
    return send_global_invite('ctf', 1, 'en')

def quick_vip_rooftops(password: str = "1111") -> bool:
    """Quick VIP on Rooftops with password"""
    return send_global_invite('vip', 1, 'en', password=password)

def quick_duel_showdown() -> bool:
    """Quick Duel on Showdown map"""
    return send_global_invite('duel', 10, 'en')

def quick_zone_control_canals() -> bool:
    """Quick Zone Control on Canals map"""
    return send_global_invite('zcm', 3, 'en')

# Information functions
def list_game_modes() -> None:
    """List all available game modes"""
    system = MC5MPInviteSystem()
    modes = system.get_game_modes()
    print("🎮 Available Game Modes:")
    for mode, name in modes.items():
        print(f"   {mode}: {name}")

def list_maps() -> None:
    """List all available maps"""
    system = MC5MPInviteSystem()
    maps = system.get_maps()
    print("🗺️ Available Maps:")
    for index, name in sorted(maps.items()):
        print(f"   {index}: {name}")

def show_invite_example(game_mode: str = 'teambattle', map_index: int = 0) -> None:
    """Show example of MP invite data"""
    system = MC5MPInviteSystem()
    invite = system.create_mp_invite(game_mode, map_index)
    
    print(f"📋 MP Invite Example - {system.GAME_MODES[game_mode]} on {system.MAPS[map_index]}:")
    print(f"   Game Mode: {invite['game_mode']}")
    print(f"   Map: {invite['map_name']}")
    print(f"   Max Players: {invite['max_players']}")
    print(f"   Room ID: {invite['room_data']['roomId']}")
    print(f"   Message: {invite['mp_invite_data']['msg']}")
    print(f"\n📊 Room Attributes:")
    for key, value in invite['attributes'].items():
        print(f"   {key}: {value}")
