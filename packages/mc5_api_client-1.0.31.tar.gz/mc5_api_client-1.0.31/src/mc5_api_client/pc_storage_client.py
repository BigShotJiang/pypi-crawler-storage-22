# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : pc_storage_client.py
# | License  : MIT License © 2026 Chizoba
# | Brief    | PC storage admin client for MC5 API
# ────────────────★─────────────────────────────────

"""
PC Storage Admin Client for MC5 API with storage, storage_restricted, and storage_admin scopes.
Provides advanced squad management capabilities for PC platform.
"""

from typing import Optional, Dict, Any, List
from .client import MC5Client
from .platform import Platform
from .storage_admin import StorageAdminMixin
from .auth import TokenGenerator
from .exceptions import MC5APIError


class PCStorageClient(MC5Client, StorageAdminMixin):
    """
    PC Storage Admin Client with advanced squad management capabilities.
    
    This client uses storage scopes to provide admin-level squad management
    including deletion, comprehensive updates, and audit capabilities.
    """
    
    def __init__(
        self,
        username: Optional[str] = None,
        password: Optional[str] = None,
        device_id: Optional[str] = None,
        scope: str = "alert auth chat leaderboard_ro lobby message session social config storage storage_restricted storage_admin tracking_bi feed storage leaderboard_admin social_eve social soc transaction schedule lottery voice matchmaker",
        auto_refresh: bool = True,
        timeout: int = 30
    ):
        """
        Initialize PC Storage Admin Client.
        
        Args:
            username: MC5 username (default: game:mc5_system)
            password: Account password (default: admin)
            device_id: Device ID (generated if not provided)
            scope: Permission scopes with storage capabilities
            auto_refresh: Whether to auto-refresh tokens
            timeout: Request timeout in seconds
            debug_mode: Enable debug mode
        """
        # Default to game:mc5_system for storage admin
        if username is None:
            username = "game:mc5_system"
        if password is None:
            password = "admin"
        
        # Set storage-specific attributes before calling parent constructor
        self._storage_scope = scope
        self._device_id = device_id or ""
        self._username = username
        self._password = password
        
        # Initialize with PC platform
        super().__init__(
            username=username,
            password=password,
            platform=Platform.PC,
            client_id="1875:55979:6.0.0a:windows:windows",
            auto_refresh=auto_refresh,
            timeout=timeout
        )
        
        # Override token generation for storage admin
        self.token_generator = TokenGenerator()
        
        # Set storage base URL
        self._storage_base_url = "https://eur-seshat.gameloft.com"
    
    def authenticate(
        self, 
        username: Optional[str] = None, 
        password: Optional[str] = None, 
        device_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Authenticate with storage admin scopes.
        
        Args:
            username: Username (uses instance default if None)
            password: Password (uses instance default if None)
            device_id: Device ID (uses instance default if None)
            
        Returns:
            Authentication response with storage scopes
        """
        username = username or self._username
        password = password or self._password
        device_id = device_id or self._device_id
        
        try:
            token_data = self.token_generator.generate_token(
                username=username,
                password=password,
                device_id=device_id,
                scope=self._storage_scope
            )
            
            self._token_data = token_data
            self._username = username
            
            # Update session headers
            self.session.headers.update({
                "User-Agent": f"MC5-PC-Storage-Admin/1.0.17",
                "Accept": "application/json",
                "Content-Type": "application/json"
            })
            
            return token_data
            
        except Exception as e:
            raise MC5APIError(f"Storage admin authentication failed: {e}")
    
    def get_storage_info(self) -> Dict[str, Any]:
        """
        Get current storage admin information.
        
        Returns:
            Storage admin information including scopes and capabilities
        """
        if not self._token_data:
            return {"error": "Not authenticated"}
        
        return {
            "username": self._username,
            "platform": self.get_platform_info()["platform"],
            "scopes": self._token_data.get("scopes", []),
            "client_id": self.client_id,
            "has_storage": "storage" in self._token_data.get("scopes", []),
            "has_storage_restricted": "storage_restricted" in self._token_data.get("scopes", []),
            "has_storage_admin": "storage_admin" in self._token_data.get("scopes", []),
            "capabilities": self._get_storage_capabilities()
        }
    
    def _get_storage_capabilities(self) -> List[str]:
        """Get available storage capabilities based on scopes."""
        scopes = self._token_data.get("scopes", [])
        capabilities = []
        
        if "storage" in scopes:
            capabilities.extend([
                "read_squad_info",
                "update_squad_info",
                "get_all_squads",
                "get_squad_audit_log"
            ])
        
        if "storage_restricted" in scopes:
            capabilities.extend([
                "limited_squad_updates",
                "read_squad_audit_log"
            ])
        
        if "storage_admin" in scopes:
            capabilities.extend([
                "delete_squad",
                "batch_delete_squads",
                "transfer_squad_ownership",
                "full_squad_management",
                "admin_audit_access"
            ])
        
        return capabilities
    
    def quick_squad_management_report(self, squad_id: str) -> Dict[str, Any]:
        """
        Generate a comprehensive squad management report.
        
        Args:
            squad_id: Squad ID to analyze
            
        Returns:
            Comprehensive squad report
        """
        try:
            # Get squad info
            squad_info = self.get_squad_storage_info(squad_id)
            
            # Get audit log if available
            audit_log = None
            if self._has_storage_capability("get_squad_audit_log"):
                try:
                    audit_log = self.get_squad_audit_log(squad_id, limit=10)
                except:
                    audit_log = {"error": "Audit log not available"}
            
            return {
                "squad_id": squad_id,
                "squad_info": squad_info,
                "audit_log": audit_log,
                "storage_capabilities": self._get_storage_capabilities(),
                "available_actions": self._get_available_actions(squad_id)
            }
            
        except Exception as e:
            return {"error": f"Failed to generate report: {e}"}
    
    def _has_storage_capability(self, capability: str) -> bool:
        """Check if a specific storage capability is available."""
        return capability in self._get_storage_capabilities()
    
    def _get_available_actions(self, squad_id: str) -> List[str]:
        """Get available actions for a squad based on storage capabilities."""
        actions = []
        
        if self._has_storage_capability("read_squad_info"):
            actions.append("read_info")
        
        if self._has_storage_capability("update_squad_info"):
            actions.append("update_info")
        
        if self._has_storage_capability("delete_squad"):
            actions.append("delete")
        
        if self._has_storage_capability("transfer_squad_ownership"):
            actions.append("transfer_ownership")
        
        if self._has_storage_capability("get_squad_audit_log"):
            actions.append("view_audit_log")
        
        return actions
