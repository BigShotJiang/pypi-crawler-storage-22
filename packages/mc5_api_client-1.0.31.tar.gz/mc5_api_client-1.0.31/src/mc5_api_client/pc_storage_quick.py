# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : pc_storage_quick.py
# | License  : MIT License © 2026 Chizoba
# | Brief    | Quick functions for PC storage admin
# ────────────────★─────────────────────────────────

"""
Quick functions for PC Storage Admin operations.
Provides simple one-liner functions for common storage admin tasks.
"""

from typing import Optional, Dict, Any, List
from .pc_storage_client import PCStorageClient


def quick_get_squad_storage_info(squad_id: str) -> Optional[Dict[str, Any]]:
    """
    Quick function to get squad storage information.
    
    Args:
        squad_id: Squad ID to retrieve
        
    Returns:
        Squad storage information or None if failed
    """
    try:
        client = PCStorageClient()
        client.authenticate()
        return client.get_squad_storage_info(squad_id)
    except Exception:
        return None


def quick_update_squad_storage(
    squad_id: str,
    name: Optional[str] = None,
    description: Optional[str] = None,
    rating: Optional[int] = None,
    member_limit: Optional[int] = None,
    privacy: Optional[str] = None
) -> bool:
    """
    Quick function to update squad storage information.
    
    Args:
        squad_id: Squad ID to update
        name: New squad name
        description: New squad description
        rating: New squad rating
        member_limit: New member limit
        privacy: Privacy settings
        
    Returns:
        True if successful, False otherwise
    """
    try:
        client = PCStorageClient()
        client.authenticate()
        result = client.update_squad_storage(
            squad_id=squad_id,
            name=name,
            description=description,
            rating=rating,
            member_limit=member_limit,
            privacy=privacy
        )
        return True
    except Exception:
        return False


def quick_delete_squad(squad_id: str) -> bool:
    """
    Quick function to delete a squad (requires storage_admin scope).
    
    Args:
        squad_id: Squad ID to delete
        
    Returns:
        True if successful, False otherwise
    """
    try:
        client = PCStorageClient()
        client.authenticate()
        result = client.delete_squad(squad_id)
        return True
    except Exception:
        return False


def quick_get_all_squads(limit: int = 50) -> Optional[List[Dict[str, Any]]]:
    """
    Quick function to get all squads.
    
    Args:
        limit: Number of squads to retrieve
        
    Returns:
        List of squads or None if failed
    """
    try:
        client = PCStorageClient()
        client.authenticate()
        result = client.get_all_squads(limit=limit)
        return result.get('squads', []) if isinstance(result, dict) else result
    except Exception:
        return None


def quick_batch_delete_squads(squad_ids: List[str]) -> Dict[str, Any]:
    """
    Quick function to delete multiple squads.
    
    Args:
        squad_ids: List of squad IDs to delete
        
    Returns:
        Batch deletion results
    """
    try:
        client = PCStorageClient()
        client.authenticate()
        return client.batch_delete_squads(squad_ids)
    except Exception as e:
        return {"error": str(e)}


def quick_transfer_squad_ownership(
    squad_id: str,
    new_owner_credential: str
) -> bool:
    """
    Quick function to transfer squad ownership.
    
    Args:
        squad_id: Squad ID to transfer
        new_owner_credential: New owner's credential
        
    Returns:
        True if successful, False otherwise
    """
    try:
        client = PCStorageClient()
        client.authenticate()
        result = client.transfer_squad_ownership(squad_id, new_owner_credential)
        return True
    except Exception:
        return False


def quick_get_squad_audit_log(squad_id: str, limit: int = 20) -> Optional[List[Dict[str, Any]]]:
    """
    Quick function to get squad audit log.
    
    Args:
        squad_id: Squad ID to get audit log for
        limit: Number of audit entries to retrieve
        
    Returns:
        Audit log entries or None if failed
    """
    try:
        client = PCStorageClient()
        client.authenticate()
        result = client.get_squad_audit_log(squad_id, limit=limit)
        return result.get('entries', []) if isinstance(result, dict) else result
    except Exception:
        return None


def quick_squad_management_report(squad_id: str) -> Optional[Dict[str, Any]]:
    """
    Quick function to generate comprehensive squad management report.
    
    Args:
        squad_id: Squad ID to analyze
        
    Returns:
        Comprehensive squad report or None if failed
    """
    try:
        client = PCStorageClient()
        client.authenticate()
        return client.quick_squad_management_report(squad_id)
    except Exception:
        return None


def quick_check_storage_capabilities() -> Optional[Dict[str, Any]]:
    """
    Quick function to check current storage capabilities.
    
    Returns:
        Storage capabilities information or None if failed
    """
    try:
        client = PCStorageClient()
        client.authenticate()
        return client.get_storage_info()
    except Exception:
        return None


def quick_analyze_squad(squad_id: str) -> Optional[Dict[str, Any]]:
    """
    Quick function to analyze squad with all available storage data.
    
    Args:
        squad_id: Squad ID to analyze
        
    Returns:
        Squad analysis results or None if failed
    """
    try:
        client = PCStorageClient()
        client.authenticate()
        
        # Get comprehensive squad data
        squad_info = client.get_squad_storage_info(squad_id)
        audit_log = client.get_squad_audit_log(squad_id, limit=10)
        
        return {
            "squad_id": squad_id,
            "squad_info": squad_info,
            "audit_log": audit_log,
            "analysis": {
                "has_data": bool(squad_info),
                "has_audit_log": bool(audit_log),
                "available_actions": client._get_available_actions(squad_id)
            }
        }
    except Exception:
        return None
