#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : room_matchmaking.py
# | License  : MIT License © 2026 Chizoba
# | Brief    | MC5 room and matchmaking API integration
# ────────────────★─────────────────────────────────

"""
MC5 Room and Matchmaking API

This module provides access to the MC5 room finding and matchmaking system.
Based on reverse-engineered API endpoints from the game client.

Features:
- Room discovery and filtering
- Matchmaking for different game modes
- Server type selection (mp_server, mp_server_test, clan_dummy_server)
- Quick join functionality
- Custom room creation
"""

import requests
import json
import time
from typing import Dict, List, Optional, Union
from urllib.parse import urlencode, quote

class MC5RoomAPI:
    """MC5 Room and Matchmaking API Client"""
    
    def __init__(self, client_id: str = "1875:55979:6.0.0a:windows:windows", region: str = "eur"):
        """
        Initialize Room API client
        
        Args:
            client_id: Game client identifier
            region: Server region (eur, us, asia, etc.)
        """
        self.client_id = client_id
        self.region = region
        self.base_url = f"{region}-anubisfinder.gameloft.com"
        self.session = requests.Session()
        self.session.headers.update({
            'Accept': '*/*',
            'accept-encoding': 'identity',
            'User-Agent': 'MC5-API-Client/1.0.30'
        })
    
    def find_rooms(self, 
                   server_type: str = "mp_server",
                   game_mode: Optional[str] = None,
                   joinable: bool = True,
                   public: bool = True,
                   customs_room: bool = True,
                   game_started: bool = True,
                   full: bool = False,
                   limit: Optional[int] = None,
                   event_id: str = "x",
                   veteran: Optional[bool] = None,
                   game_state: Optional[str] = None,
                   members: Optional[List[str]] = None,
                   capacity: Optional[int] = None) -> List[Dict]:
        """
        Find available rooms with various filters
        
        Args:
            server_type: Server type (mp_server, mp_server_test, clan_dummy_server)
            game_mode: Game mode (duel, teambattle, etc.)
            joinable: Filter joinable rooms
            public: Filter public rooms
            customs_room: Filter custom rooms
            game_started: Filter rooms where game started
            full: Filter full rooms
            limit: Maximum number of rooms to return
            event_id: Event identifier
            veteran: Filter veteran status
            game_state: Game state filter (lobby, playing, etc.)
            members: List of member credentials to filter by
            
        Returns:
            List of room dictionaries
        """
        params = {
            'server_type': server_type,
            '_joinable': str(joinable).lower(),
            '_public': str(public).lower(),
            '_customs_room': str(customs_room).lower(),
            'game_started': str(game_started).lower(),
            'full': str(full).lower()
        }
        
        # Add optional parameters
        if game_mode:
            params['_game_mode'] = game_mode
        if capacity:
            params['capacity'] = str(capacity)
        if limit:
            params['limit'] = str(limit)
        if event_id:
            params['_event_id'] = event_id
        if veteran is not None:
            params['_veteran'] = str(veteran).lower()
        if game_state:
            params['_game_state'] = game_state
        if members:
            params['member'] = ','.join(members)
        
        url = f"https://{self.base_url}/rooms/{self.client_id}"
        
        try:
            response = self.session.get(url, params=params)
            response.raise_for_status()
            return response.json()
        except requests.RequestException as e:
            print(f"❌ Error finding rooms: {e}")
            return []
    
    def find_clan_rooms(self, clan_id: str, server_type: str = "clan_dummy_server") -> List[Dict]:
        """
        Find clan-specific rooms
        
        Args:
            clan_id: Clan identifier
            server_type: Server type for clan rooms
            
        Returns:
            List of clan room dictionaries
        """
        params = {
            f'_clan_{clan_id}': 'true',
            'server_type': server_type
        }
        
        url = f"https://{self.base_url}/rooms/{self.client_id}"
        
        try:
            response = self.session.get(url, params=params)
            response.raise_for_status()
            return response.json()
        except requests.RequestException as e:
            print(f"❌ Error finding clan rooms: {e}")
            return []
    
    def find_clan_battle_rooms(self, clan_id: str) -> List[Dict]:
        """
        Find clan battle rooms
        
        Args:
            clan_id: Clan identifier
            
        Returns:
            List of clan battle room dictionaries
        """
        params = {
            f'_clan_{clan_id}': 'true',
            '_clan_battle_room': 'true',
            'server_type': 'mp_server'
        }
        
        url = f"https://{self.base_url}/rooms/{self.client_id}"
        
        try:
            response = self.session.get(url, params=params)
            response.raise_for_status()
            return response.json()
        except requests.RequestException as e:
            print(f"❌ Error finding clan battle rooms: {e}")
            return []
    
    def automatch(self,
                  access_token: str,
                  game_mode: str = "duel",
                  automatcher: str = "quickplayany",
                  capacity: int = 2,
                  score: int = 1000,
                  user_name: str = "Player",
                  user_country: str = "US",
                  server_type: str = "mp_server",
                  bet_amount: int = 0,
                  veteran: bool = False,
                  customs_room: bool = False,
                  event_id: str = "x",
                  event_league: str = "x",
                  pin: str = "x") -> Optional[Dict]:
        """
        Join matchmaking for automatic game matching
        
        Args:
            access_token: User access token
            game_mode: Game mode (duel, teambattle, etc.)
            automatcher: Automatcher name
            capacity: Room capacity
            score: Player matchmaking score
            user_name: Player name
            user_country: Player country code
            server_type: Server type
            bet_amount: Bet amount for betting modes
            veteran: Veteran status
            customs_room: Custom room status
            event_id: Event identifier
            event_league: Event league
            pin: PIN identifier
            
        Returns:
            Room information dictionary or None if failed
        """
        url = f"https://{self.base_url}/rooms/{self.client_id}/automatch/{automatcher}"
        
        # Build filter string
        filter_params = [
            f"_game_mode={game_mode}",
            f"_joinable=true",
            f"capacity={capacity}",
            f"_event_id={event_id}",
            f"_event_league={event_league}",
            f"_PIN={pin}",
            f"_customs_room={str(customs_room).lower()}",
            f"_betAmount={bet_amount}",
            f"_veteran={str(veteran).lower()}",
            f"_automatch_name={automatcher}"
        ]
        
        data = {
            'access_token': access_token,
            'filter': '&'.join(filter_params),
            'user': f'{{"name":"{user_name}"}}\n',
            'score': str(score),
            'server_type': server_type
        }
        
        try:
            response = self.session.post(url, data=data)
            response.raise_for_status()
            return response.json()
        except requests.RequestException as e:
            print(f"❌ Error in automatch: {e}")
            return None
    
    def quick_join(self,
                   access_token: str,
                   room_name: str,
                   capacity: int = 2,
                   server_type: str = "mp_server",
                   create_command: Optional[str] = None) -> Optional[Dict]:
        """
        Quick join a room or create if doesn't exist
        
        Args:
            access_token: User access token
            room_name: Name of the room to join
            capacity: Room capacity
            server_type: Server type
            create_command: Room creation command
            
        Returns:
            Room information dictionary or None if failed
        """
        url = f"https://{self.base_url}/rooms/{self.client_id}/quick_join"
        
        if create_command is None:
            create_command = json.dumps({
                "_name": room_name,
                "capacity": capacity,
                "server_type": server_type
            }) + '\n'
        
        data = {
            'access_token': access_token,
            'server_type': server_type,
            'filters': f'["_name={room_name}&creator_datacenter=None"]',
            'create_command': create_command,
            'name': room_name,
            'http_room': 'false'
        }
        
        try:
            response = self.session.post(url, data=data)
            response.raise_for_status()
            return response.json()
        except requests.RequestException as e:
            print(f"❌ Error in quick join: {e}")
            return None
    
    def get_room_info(self, room_id: str) -> Optional[Dict]:
        """
        Get detailed information about a specific room
        
        Args:
            room_id: Room identifier
            
        Returns:
            Room information dictionary or None if failed
        """
        # This would typically be a GET request to a room-specific endpoint
        # Based on the API patterns, this might be implemented differently
        print(f"🔍 Getting room info for: {room_id}")
        print("💡 Note: Room info endpoint needs to be reverse-engineered")
        return None
    
    def print_room_summary(self, rooms: List[Dict]) -> None:
        """
        Print a summary of found rooms
        
        Args:
            rooms: List of room dictionaries
        """
        if not rooms:
            print("❌ No rooms found")
            return
        
        print(f"🎮 Found {len(rooms)} room(s):")
        print("=" * 60)
        
        for i, room in enumerate(rooms, 1):
            name = room.get('name', 'Unknown')
            game_mode = room.get('_game_mode', 'Unknown')
            member_count = room.get('member_count', 0)
            capacity = room.get('capacity', 0)
            server_type = room.get('server_type', 'Unknown')
            game_started = room.get('game_started', False)
            joinable = room.get('_joinable', False)
            
            status = "🟢 Playing" if game_started else "🟡 Lobby"
            availability = "✅ Joinable" if joinable else "❌ Not Joinable"
            
            print(f"{i}. {name}")
            print(f"   🎯 Mode: {game_mode}")
            print(f"   👥 Players: {member_count}/{capacity}")
            print(f"   🖥️  Server: {server_type}")
            print(f"   📊 Status: {status} | {availability}")
            
            # Show member names if available
            if 'members' in room and room['members']:
                member_names = [m.get('name', 'Unknown') for m in room['members']]
                print(f"   👤 Members: {', '.join(member_names)}")
            
            print()

# Convenience functions for common operations
def find_duel_rooms(client_id: str = "1875:55979:6.0.0a:windows:windows", 
                   region: str = "eur") -> List[Dict]:
    """Find duel rooms"""
    api = MC5RoomAPI(client_id, region)
    return api.find_rooms(game_mode="duel", capacity=2)

def find_team_battle_rooms(client_id: str = "1875:55979:6.0.0a:windows:windows",
                          region: str = "eur") -> List[Dict]:
    """Find team battle rooms"""
    api = MC5RoomAPI(client_id, region)
    return api.find_rooms(game_mode="teambattle", capacity=12)

def find_custom_rooms(client_id: str = "1875:55979:6.0.0a:windows:windows",
                      region: str = "eur") -> List[Dict]:
    """Find custom rooms (non-ranked)"""
    api = MC5RoomAPI(client_id, region)
    return api.find_rooms(server_type="mp_server_test", customs_room=True)

def quick_duel_match(access_token: str, 
                    score: int = 1000,
                    user_name: str = "Player",
                    client_id: str = "1875:55979:6.0.0a:windows:windows",
                    region: str = "eur") -> Optional[Dict]:
    """Quick join a duel match"""
    api = MC5RoomAPI(client_id, region)
    return api.automatch(
        access_token=access_token,
        game_mode="duel",
        capacity=2,
        score=score,
        user_name=user_name
    )

def quick_team_battle(access_token: str,
                     score: int = 1000,
                     user_name: str = "Player",
                     client_id: str = "1875:55979:6.0.0a:windows:windows",
                     region: str = "eur") -> Optional[Dict]:
    """Quick join a team battle match"""
    api = MC5RoomAPI(client_id, region)
    return api.automatch(
        access_token=access_token,
        game_mode="teambattle",
        capacity=12,
        score=score,
        user_name=user_name
    )
