# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : storage_admin.py
# | License  : MIT License © 2026 Chizoba
# | Brief    | Storage admin mixin for MC5 API client
# ────────────────★─────────────────────────────────

"""
Storage admin mixin for MC5 API client with storage, storage_restricted, and storage_admin scopes.
Provides advanced squad management capabilities for PC platform.
"""

import time
from typing import Optional, Dict, Any, List
from .exceptions import InsufficientScopeError


class StorageAdminMixin:
    """
    Mixin providing storage admin capabilities for MC5 API client.
    
    This mixin requires storage, storage_restricted, or storage_admin scopes
    and provides advanced squad management features including deletion
    and comprehensive information modification.
    """
    
    def __init__(self):
        """Initialize storage admin mixin."""
        super().__init__()
        self._storage_base_url = "https://eur-seshat.gameloft.com"
        
    def _ensure_storage_scope(self, required_scope: str = "storage"):
        """Ensure the current token has the required storage scope."""
        if not hasattr(self, '_token_data') or not self._token_data:
            raise InsufficientScopeError(required_scope)
        
        scopes = self._token_data.get('scopes', [])
        if not any(scope in scopes for scope in [required_scope, 'storage_restricted', 'storage_admin']):
            raise InsufficientScopeError(required_scope)
    
    def delete_squad(
        self,
        squad_id: str
    ) -> Dict[str, Any]:
        """
        Delete a squad (requires storage_admin scope).
        
        Args:
            squad_id: Squad ID to delete
            
        Returns:
            Deletion response
        """
        self._ensure_storage_scope("storage_admin")
        
        url = f"{self._storage_base_url}/groups/{squad_id}"
        params = {
            "access_token": self._token_data['access_token'],
            "game": "mc5_system"
        }
        
        return self._make_request("DELETE", url, params=params)
    
    def get_squad_storage_info(
        self,
        squad_id: str
    ) -> Dict[str, Any]:
        """
        Get comprehensive squad storage information.
        
        Args:
            squad_id: Squad ID to retrieve
            
        Returns:
            Squad storage information
        """
        self._ensure_storage_scope("storage")
        
        url = f"{self._storage_base_url}/groups/{squad_id}"
        params = {
            "access_token": self._token_data['access_token'],
            "game": "mc5_system",
            "include_fields": "all"
        }
        
        return self._make_request("GET", url, params=params)
    
    def update_squad_storage(
        self,
        squad_id: str,
        name: Optional[str] = None,
        description: Optional[str] = None,
        rating: Optional[int] = None,
        score: Optional[int] = None,
        member_count: Optional[int] = None,
        member_limit: Optional[int] = None,
        membership: Optional[str] = None,
        logo: Optional[str] = None,
        logo_color_primary: Optional[int] = None,
        logo_color_secondary: Optional[int] = None,
        min_join_value: Optional[int] = None,
        currency: Optional[int] = None,
        active_clan_label: Optional[bool] = None,
        privacy: Optional[str] = None,
        tags: Optional[List[str]] = None
    ) -> Dict[str, Any]:
        """
        Update squad storage information with admin capabilities.
        
        Args:
            squad_id: Squad ID to update
            name: Squad name
            description: Squad description
            rating: Squad rating
            score: Squad score
            member_count: Current member count
            member_limit: Maximum member limit
            membership: Membership type
            logo: Logo ID
            logo_color_primary: Primary logo color
            logo_color_secondary: Secondary logo color
            min_join_value: Minimum join value
            currency: Squad currency
            active_clan_label: Whether clan label is active
            privacy: Privacy settings
            tags: Squad tags
            
        Returns:
            Update response
        """
        self._ensure_storage_scope("storage")
        
        url = f"{self._storage_base_url}/groups/{squad_id}"
        
        # Build payload with provided parameters
        payload = {
            "access_token": self._token_data['access_token'],
            "game": "mc5_system",
            "timestamp": str(int(time.time())),
            "_anonId": self._username if hasattr(self, '_username') else "game:mc5_system"
        }
        
        # Add optional parameters if provided
        if name is not None:
            payload["name"] = name
        if description is not None:
            payload["description"] = description
        if rating is not None:
            payload["_rating"] = str(rating)
        if score is not None:
            payload["score"] = str(score)
        if member_count is not None:
            payload["member_count"] = str(member_count)
        if member_limit is not None:
            payload["member_limit"] = str(member_limit)
        if membership is not None:
            payload["membership"] = membership
        if logo is not None:
            payload["_logo"] = logo
        if logo_color_primary is not None:
            payload["_logo_clr_prim"] = str(logo_color_primary)
        if logo_color_secondary is not None:
            payload["_logo_clr_sec"] = str(logo_color_secondary)
        if min_join_value is not None:
            payload["_min_join_value"] = str(min_join_value)
        if currency is not None:
            payload["currency"] = str(currency)
        if active_clan_label is not None:
            payload["active_clan_label"] = "true" if active_clan_label else "false"
        if privacy is not None:
            payload["privacy"] = privacy
        if tags is not None:
            payload["tags"] = ",".join(tags)
        
        return self._make_request("POST", url, data=payload)
    
    def get_all_squads(
        self,
        limit: int = 100,
        offset: int = 0,
        include_fields: Optional[List[str]] = None
    ) -> Dict[str, Any]:
        """
        Get all squads with storage information.
        
        Args:
            limit: Number of squads to retrieve
            offset: Offset for pagination
            include_fields: Fields to include in response
            
        Returns:
            List of squads with storage information
        """
        self._ensure_storage_scope("storage")
        
        url = f"{self._storage_base_url}/groups"
        params = {
            "access_token": self._token_data['access_token'],
            "game": "mc5_system",
            "limit": str(limit),
            "offset": str(offset)
        }
        
        if include_fields:
            params["include_fields"] = ",".join(include_fields)
        
        return self._make_request("GET", url, params=params)
    
    def batch_delete_squads(
        self,
        squad_ids: List[str]
    ) -> Dict[str, Any]:
        """
        Delete multiple squads at once (requires storage_admin scope).
        
        Args:
            squad_ids: List of squad IDs to delete
            
        Returns:
            Batch deletion response
        """
        self._ensure_storage_scope("storage_admin")
        
        results = {}
        for squad_id in squad_ids:
            try:
                result = self.delete_squad(squad_id)
                results[squad_id] = {"status": "success", "response": result}
            except Exception as e:
                results[squad_id] = {"status": "error", "error": str(e)}
        
        return results
    
    def get_squad_audit_log(
        self,
        squad_id: str,
        limit: int = 50
    ) -> Dict[str, Any]:
        """
        Get audit log for a squad (requires storage_admin scope).
        
        Args:
            squad_id: Squad ID to get audit log for
            limit: Number of audit entries to retrieve
            
        Returns:
            Audit log entries
        """
        self._ensure_storage_scope("storage_admin")
        
        url = f"{self._storage_base_url}/groups/{squad_id}/audit"
        params = {
            "access_token": self._token_data['access_token'],
            "game": "mc5_system",
            "limit": str(limit)
        }
        
        return self._make_request("GET", url, params=params)
    
    def transfer_squad_ownership(
        self,
        squad_id: str,
        new_owner_credential: str
    ) -> Dict[str, Any]:
        """
        Transfer squad ownership to another user (requires storage_admin scope).
        
        Args:
            squad_id: Squad ID to transfer
            new_owner_credential: New owner's credential
            
        Returns:
            Transfer response
        """
        self._ensure_storage_scope("storage_admin")
        
        url = f"{self._storage_base_url}/groups/{squad_id}/transfer"
        data = {
            "access_token": self._token_data['access_token'],
            "game": "mc5_system",
            "new_owner": new_owner_credential,
            "timestamp": str(int(time.time()))
        }
        
        return self._make_request("POST", url, data=data)
