#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : ultra_simple_chat.py
# | License  : MIT License  2026 Chizoba
# | Brief    : Ultra-simple MC5 chat with 100+ customization functions
# ────────────────★─────────────────────────────────

"""
Ultra-Simple MC5 Chat Module - Maximum Simplicity, Maximum Power!

Just import and use - no setup required!
"""

import sys
import os
import time
import requests
import urllib.parse

# Import Chat from the current package
from .chat import MC5ChatClient as Chat

# Create global chat instance for quick functions
_global_chat = None

def _get_chat():
    """Get or create global chat instance."""
    global _global_chat
    if _global_chat is None:
        _global_chat = Chat()
    return _global_chat

# ===== ULTRA-SIMPLE SEND FUNCTIONS =====

def send(message, name=None, lang="en"):
    """Send a message - the simplest way!"""
    chat = _get_chat()
    if name:
        chat.nickname(name)
    return chat.msg(message, lang=lang)

def quick(message, lang="en"):
    """Even quicker - just message and language."""
    return _get_chat().msg(message, lang=lang)

# ===== LANGUAGE SHORTCUTS (53 LANGUAGES) =====

def en(message): return quick(message, "en")
def fr(message): return quick(message, "fr")
def de(message): return quick(message, "de")
def es(message): return quick(message, "es")
def it(message): return quick(message, "it")
def pt(message): return quick(message, "pt")
def ru(message): return quick(message, "ru")
def ja(message): return quick(message, "ja")
def ko(message): return quick(message, "ko")
def zh(message): return quick(message, "zh")
def nl(message): return quick(message, "nl")
def sv(message): return quick(message, "sv")
def no(message): return quick(message, "no")
def da(message): return quick(message, "da")
def fi(message): return quick(message, "fi")
def pl(message): return quick(message, "pl")
def cs(message): return quick(message, "cs")
def hu(message): return quick(message, "hu")
def ro(message): return quick(message, "ro")
def bg(message): return quick(message, "bg")
def hr(message): return quick(message, "hr")
def sk(message): return quick(message, "sk")
def si(message): return quick(message, "si")
def et(message): return quick(message, "et")
def lv(message): return quick(message, "lv")
def lt(message): return quick(message, "lt")
def el(message): return quick(message, "el")
def tr(message): return quick(message, "tr")
def ar(message): return quick(message, "ar")
def he(message): return quick(message, "he")
def hi(message): return quick(message, "hi")
def th(message): return quick(message, "th")
def id(message): return quick(message, "id")
def bn(message): return quick(message, "bn")
def ur(message): return quick(message, "ur")
def fa(message): return quick(message, "fa")
def uk(message): return quick(message, "uk")
def be(message): return quick(message, "be")
def kk(message): return quick(message, "kk")
def uz(message): return quick(message, "uz")
def az(message): return quick(message, "az")
def ka(message): return quick(message, "ka")
def am(message): return quick(message, "am")
def sw(message): return quick(message, "sw")
def zu(message): return quick(message, "zu")
def af(message): return quick(message, "af")
def is_(message): return quick(message, "is")
def mt(message): return quick(message, "mt")
def cy(message): return quick(message, "cy")
def ga(message): return quick(message, "ga")
def gd(message): return quick(message, "gd")
def eu(message): return quick(message, "eu")
def ca(message): return quick(message, "ca")

# ===== SPAM FUNCTIONS =====

def spam(message, count=5, delay=0.1):
    """Spam a message multiple times."""
    chat = _get_chat()
    success = 0
    for i in range(count):
        # Use different language to bypass anti-spam
        lang = f"spam{i}" if i > 0 else "en"
        if chat.msg(message, lang=lang):
            success += 1
        time.sleep(delay)
    return success

def spam_en(message, count=5, delay=0.1):
    """Spam in English with variations."""
    return spam(message, count, delay)

def spam_fr(message, count=5, delay=0.1):
    """Spam in French with variations."""
    chat = _get_chat()
    success = 0
    for i in range(count):
        lang = f"fr{i}" if i > 0 else "fr"
        if chat.msg(message, lang=lang):
            success += 1
        time.sleep(delay)
    return success

def rapid_spam(message, count=10):
    """Ultra-rapid spam with minimal delay."""
    return spam(message, count, 0.05)

def subtle_spam(count=10):
    """Subtle spam with dots and variations."""
    messages = [".", "..", "...", "....", ".....", "......", ".......", "........"]
    success = 0
    for i in range(count):
        msg = messages[i % len(messages)]
        lang = f"subtle{i}"
        if _get_chat().msg(msg, lang=lang):
            success += 1
        time.sleep(0.1)
    return success

# ===== PRESET PROFILES =====

def pro():
    """Pro player preset - red signature."""
    chat = _get_chat()
    chat.nickname("ProPlayer")
    chat.killsig("default_killsig_80", "FF0000")
    return chat

def casual():
    """Casual player preset - green signature."""
    chat = _get_chat()
    chat.nickname("CasualPlayer")
    chat.killsig("default_killsig_02", "00FF00")
    return chat

def squad():
    """Squad player preset - blue signature."""
    chat = _get_chat()
    chat.nickname("SquadPlayer")
    chat.killsig("default_killsig_72", "0000FF")
    return chat

def elite():
    """Elite player preset - purple signature."""
    chat = _get_chat()
    chat.nickname("ElitePlayer")
    chat.killsig("default_killsig_90", "FF00FF")
    return chat

def stealth():
    """Stealth preset - subtle name and signature."""
    chat = _get_chat()
    chat.nickname(".")
    chat.killsig("default_killsig_01", "808080")
    return chat

# ===== INBOX API FUNCTIONS =====

def check_inbox(limit=10):
    """Check your inbox messages."""
    try:
        chat = _get_chat()
        if not chat._get_token():
            return None
        
        # Build access token
        base_token = chat.token.split(',')[0] if ',' in chat.token else chat.token
        access_token = f"{base_token},alert auth chat leaderboard_ro lobby message session social,1875:55979:6.0.0a:windows:windows,1770208728.111963,{chat.user},1364509832654538259,eur~gold|758b6015ca27066223186f562fbdef4c"
        
        encoded_token = urllib.parse.quote(access_token, safe='')
        inbox_url = f"https://eur-hermes.gameloft.com/messages/inbox/me?access_token={encoded_token}"
        
        headers = {
            'Accept': '*/*',
            'accept-encoding': 'identity'
        }
        
        response = requests.get(inbox_url, headers=headers, timeout=10)
        
        if response.status_code == 200:
            messages = response.json()
            # Filter messages sent to us
            my_messages = [msg for msg in messages if msg.get('to') == chat.user]
            # Sort by creation time (newest first)
            my_messages.sort(key=lambda x: x.get('created', ''), reverse=True)
            return my_messages[:limit]
        else:
            return None
            
    except Exception:
        return None

def my_messages(limit=5):
    """Get your recent messages - even simpler."""
    messages = check_inbox(limit)
    if messages:
        return [(msg.get('from', 'Unknown'), msg.get('body', 'No body'), msg.get('created', 'Unknown')) for msg in messages]
    return []

def check_spam():
    """Check if your spam messages were delivered."""
    messages = check_inbox(20)
    if messages:
        # Look for recent spam-like messages
        recent_spam = []
        for msg in messages:
            body = msg.get('body', '').strip()
            # Check for spam patterns
            if (len(body) <= 10 and body.count('.') >= 1) or body in ['.', '..', '...', '....']:
                recent_spam.append((msg.get('from', 'Unknown'), body, msg.get('created', 'Unknown')))
        return recent_spam
    return []

# ===== IMPERSONATION FUNCTIONS =====

def impersonate(name, message, lang="en"):
    """Impersonate someone - just name and message."""
    chat = _get_chat()
    chat.nickname(name)
    return chat.msg(message, lang=lang)

def become_player(name, signature_color="FF0000"):
    """Become a player with custom signature."""
    chat = _get_chat()
    chat.nickname(name)
    chat.set_killsig("default_killsig_80", signature_color)
    return chat

def anonymous_spy():
    """Anonymous spy preset."""
    chat = _get_chat()
    chat.nickname("Anonymous")
    chat.set_killsig("default_killsig_01", "000000")
    return chat

# ===== LISTEN FUNCTIONS =====

def listen(duration=30):
    """Listen to chat messages."""
    return _get_chat().listen(duration)

def listen_en(duration=30):
    """Listen to English chat."""
    chat = _get_chat()
    chat.language("en")
    return chat.listen(duration)

def listen_all(duration=60):
    """Listen to all channels (if possible)."""
    return _get_chat().listen(duration)

# ===== UTILITY FUNCTIONS =====

def set_name(name):
    """Set your nickname."""
    return _get_chat().nickname(name)

def set_signature(name, color="FF0000"):
    """Set your kill signature."""
    return _get_chat().killsig(name, color)

def set_language(lang):
    """Set your language."""
    return _get_chat().language(lang)

def test_connection():
    """Test if chat is working."""
    try:
        return _get_chat().msg("Connection test", lang="en")
    except:
        return False

def get_server():
    """Get current chat server."""
    return _get_chat()._get_server()

# ===== COMPREHENSIVE CUSTOMIZATION FUNCTIONS =====

def set_killsign(signature_name, color_hex="FF0000"):
    """Set kill signature with color."""
    chat = _get_chat()
    result = chat.set_killsig(signature_name, color_hex)
    return chat  # Return chat for chaining

def set_killsign_color(color_hex):
    """Change only the kill signature color."""
    chat = _get_chat()
    # Keep current signature, change color
    result = chat.set_killsig(chat.killsig, color_hex)
    return chat  # Return chat for chaining

def set_killsign_name(signature_name):
    """Change only the kill signature name."""
    chat = _get_chat()
    # Keep current color, change signature
    current_color = getattr(chat, 'color', 'FF0000')
    result = chat.set_killsig(signature_name, current_color)
    return chat  # Return chat for chaining

def set_nickname(nickname):
    """Set your nickname (alias for set_name)."""
    chat = _get_chat()
    result = chat.nickname(nickname)
    return chat  # Return chat for chaining

def set_country(country_code):
    """Set your country/language for chat."""
    chat = _get_chat()
    result = chat.language(country_code)
    return chat  # Return chat for chaining

def set_chat_country(country_code):
    """Set chat country (alias for set_country)."""
    chat = _get_chat()
    result = chat.language(country_code)
    return chat  # Return chat for chaining

# ===== PRESET KILLSIGNS =====

def killsign_pro():
    """Set professional red signature."""
    chat = set_killsign("default_killsig_80", "FF0000")
    return chat

def killsign_casual():
    """Set casual green signature."""
    chat = set_killsign("default_killsig_02", "00FF00")
    return chat

def killsign_squad():
    """Set squad blue signature."""
    chat = set_killsign("default_killsig_72", "0000FF")
    return chat

def killsign_elite():
    """Set elite purple signature."""
    chat = set_killsign("default_killsig_90", "FF00FF")
    return chat

def killsign_stealth():
    """Set stealth gray signature."""
    chat = set_killsign("default_killsig_01", "808080")
    return chat

def killsign_gold():
    """Set gold signature."""
    chat = set_killsign("default_killsig_50", "FFD700")
    return chat

def killsign_diamond():
    """Set diamond cyan signature."""
    chat = set_killsign("default_killsig_45", "00CED1")
    return chat

def killsign_fire():
    """Set fire orange signature."""
    chat = set_killsign("default_killsig_25", "FF4500")
    return chat

def killsign_ice():
    """Set ice light blue signature."""
    chat = set_killsign("default_killsig_15", "87CEEB")
    return chat

def killsign_shadow():
    """Set shadow dark purple signature."""
    chat = set_killsign("default_killsig_35", "4B0082")
    return chat

# ===== COLOR PRESETS =====

def color_red():
    """Set red color."""
    chat = set_killsign_color("FF0000")
    return chat

def color_green():
    """Set green color."""
    chat = set_killsign_color("00FF00")
    return chat

def color_blue():
    """Set blue color."""
    chat = set_killsign_color("0000FF")
    return chat

def color_yellow():
    """Set yellow color."""
    chat = set_killsign_color("FFFF00")
    return chat

def color_purple():
    """Set purple color."""
    chat = set_killsign_color("FF00FF")
    return chat

def color_orange():
    """Set orange color."""
    chat = set_killsign_color("FFA500")
    return chat

def color_pink():
    """Set pink color."""
    chat = set_killsign_color("FFC0CB")
    return chat

def color_cyan():
    """Set cyan color."""
    chat = set_killsign_color("00FFFF")
    return chat

def color_white():
    """Set white color."""
    chat = set_killsign_color("FFFFFF")
    return chat

def color_black():
    """Set black color."""
    chat = set_killsign_color("000000")
    return chat

def color_gray():
    """Set gray color."""
    chat = set_killsign_color("808080")
    return chat

# ===== COUNTRY/LANGUAGE SELECTION =====

def country_en():
    """Set to English."""
    return set_country("en")

def country_fr():
    """Set to French."""
    return set_country("fr")

def country_de():
    """Set to German."""
    return set_country("de")

def country_es():
    """Set to Spanish."""
    return set_country("es")

def country_it():
    """Set to Italian."""
    return set_country("it")

def country_pt():
    """Set to Portuguese."""
    return set_country("pt")

def country_ru():
    """Set to Russian."""
    return set_country("ru")

def country_ja():
    """Set to Japanese."""
    return set_country("ja")

def country_ko():
    """Set to Korean."""
    return set_country("ko")

def country_zh():
    """Set to Chinese."""
    return set_country("zh")

def country_nl():
    """Set to Dutch."""
    return set_country("nl")

def country_sv():
    """Set to Swedish."""
    return set_country("sv")

def country_no():
    """Set to Norwegian."""
    return set_country("no")

def country_da():
    """Set to Danish."""
    return set_country("da")

def country_fi():
    """Set to Finnish."""
    return set_country("fi")

def country_pl():
    """Set to Polish."""
    return set_country("pl")

def country_cs():
    """Set to Czech."""
    return set_country("cs")

def country_hu():
    """Set to Hungarian."""
    return set_country("hu")

def country_ro():
    """Set to Romanian."""
    return set_country("ro")

def country_bg():
    """Set to Bulgarian."""
    return set_country("bg")

def country_hr():
    """Set to Croatian."""
    return set_country("hr")

def country_sk():
    """Set to Slovak."""
    return set_country("sk")

def country_si():
    """Set to Slovenian."""
    return set_country("si")

def country_et():
    """Set to Estonian."""
    return set_country("et")

def country_lv():
    """Set to Latvian."""
    return set_country("lv")

def country_lt():
    """Set to Lithuanian."""
    return set_country("lt")

def country_el():
    """Set to Greek."""
    return set_country("el")

def country_tr():
    """Set to Turkish."""
    return set_country("tr")

def country_ar():
    """Set to Arabic."""
    return set_country("ar")

def country_he():
    """Set to Hebrew."""
    return set_country("he")

def country_hi():
    """Set to Hindi."""
    return set_country("hi")

def country_th():
    """Set to Thai."""
    return set_country("th")

def country_id():
    """Set to Indonesian."""
    return set_country("id")

def country_bn():
    """Set to Bengali."""
    return set_country("bn")

def country_ur():
    """Set to Urdu."""
    return set_country("ur")

def country_fa():
    """Set to Persian."""
    return set_country("fa")

def country_uk():
    """Set to Ukrainian."""
    return set_country("uk")

def country_be():
    """Set to Belarusian."""
    return set_country("be")

def country_kk():
    """Set to Kazakh."""
    return set_country("kk")

def country_uz():
    """Set to Uzbek."""
    return set_country("uz")

def country_az():
    """Set to Azerbaijani."""
    return set_country("az")

def country_ka():
    """Set to Georgian."""
    return set_country("ka")

def country_am():
    """Set to Amharic."""
    return set_country("am")

def country_sw():
    """Set to Swahili."""
    return set_country("sw")

def country_zu():
    """Set to Zulu."""
    return set_country("zu")

def country_af():
    """Set to Afrikaans."""
    return set_country("af")

def country_is():
    """Set to Icelandic."""
    return set_country("is")

def country_mt():
    """Set to Maltese."""
    return set_country("mt")

def country_cy():
    """Set to Welsh."""
    return set_country("cy")

def country_ga():
    """Set to Irish."""
    return set_country("ga")

def country_gd():
    """Set to Scottish Gaelic."""
    return set_country("gd")

def country_eu():
    """Set to Basque."""
    return set_country("eu")

def country_ca():
    """Set to Catalan."""
    return set_country("ca")

# ===== COMBINED SETUP FUNCTIONS =====

def setup_player(nickname, killsign_name="default_killsig_80", color_hex="FF0000", country_code="en"):
    """Complete player setup in one function."""
    chat = _get_chat()
    chat.nickname(nickname)
    chat.killsig(killsign_name, color_hex)
    chat.language(country_code)
    return chat

def setup_pro_player(nickname, country_code="en"):
    """Setup as pro player."""
    return setup_player(nickname, "default_killsig_80", "FF0000", country_code)

def setup_casual_player(nickname, country_code="en"):
    """Setup as casual player."""
    return setup_player(nickname, "default_killsig_02", "00FF00", country_code)

def setup_squad_player(nickname, country_code="en"):
    """Setup as squad player."""
    return setup_player(nickname, "default_killsig_72", "0000FF", country_code)

def setup_elite_player(nickname, country_code="en"):
    """Setup as elite player."""
    return setup_player(nickname, "default_killsig_90", "FF00FF", country_code)

def setup_stealth_player(nickname, country_code="en"):
    """Setup as stealth player."""
    return setup_player(nickname, "default_killsig_01", "808080", country_code)

# ===== QUICK CONFIGURATION CHAINS =====

def configure():
    """Get chat instance for configuration chaining."""
    return _get_chat()

def with_name(nickname):
    """Set nickname and return chat for chaining."""
    chat = _get_chat()
    chat.nickname(nickname)
    return chat

def with_killsign(signature_name, color_hex="FF0000"):
    """Set killsign and return chat for chaining."""
    chat = _get_chat()
    chat.set_killsig(signature_name, color_hex)
    return chat

def with_country(country_code):
    """Set country and return chat for chaining."""
    chat = _get_chat()
    chat.language(country_code)
    return chat

# ===== PROFILE TEMPLATES =====

def profile_pro_gamer():
    """Pro gamer profile."""
    return setup_player("ProGamer", "default_killsig_80", "FF0000", "en")

def profile_casual_gamer():
    """Casual gamer profile."""
    return setup_player("CasualPlayer", "default_killsig_02", "00FF00", "en")

def profile_squad_leader():
    """Squad leader profile."""
    return setup_player("SquadLeader", "default_killsig_72", "0000FF", "en")

def profile_elite_warrior():
    """Elite warrior profile."""
    return setup_player("EliteWarrior", "default_killsig_90", "FF00FF", "en")

def profile_stealth_ninja():
    """Stealth ninja profile."""
    return setup_player("StealthNinja", "default_killsig_01", "808080", "en")

def profile_gold_player():
    """Gold player profile."""
    return setup_player("GoldPlayer", "default_killsig_50", "FFD700", "en")

def profile_diamond_master():
    """Diamond master profile."""
    return setup_player("DiamondMaster", "default_killsig_45", "00CED1", "en")

def profile_fire_warrior():
    """Fire warrior profile."""
    return setup_player("FireWarrior", "default_killsig_25", "FF4500", "en")

def profile_ice_queen():
    """Ice queen profile."""
    return setup_player("IceQueen", "default_killsig_15", "87CEEB", "en")

def profile_shadow_assassin():
    """Shadow assassin profile."""
    return setup_player("ShadowAssassin", "default_killsig_35", "4B0082", "en")

# ===== BATCH FUNCTIONS =====

def send_to_all(message, languages=None):
    """Send message to multiple languages."""
    if languages is None:
        languages = ["en", "fr", "de", "es", "it", "pt", "ru", "ja"]
    
    success = 0
    for lang in languages:
        if quick(message, lang):
            success += 1
        time.sleep(0.1)
    return success

def batch_spam(messages, count=3):
    """Spam multiple different messages."""
    success = 0
    for i, message in enumerate(messages):
        lang = f"batch{i}"
        for j in range(count):
            if _get_chat().msg(message, lang=lang):
                success += 1
            time.sleep(0.1)
    return success

# ===== ONE-LINER FUNCTIONS =====

def hello(): return send("Hello everyone!")
def goodbye(): return send("Goodbye everyone!")
def test(): return send("Test message")
def ping(): return send("Ping!")
def thanks(): return send("Thanks!")

# Export all functions
__all__ = [
    # Core
    'Chat', 'send', 'quick',
    
    # Languages (53)
    'en', 'fr', 'de', 'es', 'it', 'pt', 'ru', 'ja', 'ko', 'zh',
    'nl', 'sv', 'no', 'da', 'fi', 'pl', 'cs', 'hu', 'ro', 'bg', 'hr', 'sk', 'si', 'et', 'lv', 'lt', 'el', 'tr',
    'ar', 'he', 'hi', 'th', 'id', 'bn', 'ur', 'fa', 'uk', 'be', 'kk', 'uz', 'az', 'ka', 'am', 'sw', 'zu', 'af', 'is_', 'mt', 'cy', 'ga', 'gd', 'eu', 'ca',
    
    # Spam
    'spam', 'spam_en', 'spam_fr', 'rapid_spam', 'subtle_spam',
    
    # Presets
    'pro', 'casual', 'squad', 'elite', 'stealth',
    
    # Inbox
    'check_inbox', 'my_messages', 'check_spam',
    
    # Impersonation
    'impersonate', 'become_player', 'anonymous_spy',
    
    # Listen
    'listen', 'listen_en', 'listen_all',
    
    # Utility (Original)
    'set_name', 'set_signature', 'set_language', 'test_connection', 'get_server',
    
    # Comprehensive Customization
    'set_killsign', 'set_killsign_color', 'set_killsign_name', 'set_nickname', 'set_country', 'set_chat_country',
    
    # Kill Sign Presets
    'killsign_pro', 'killsign_casual', 'killsign_squad', 'killsign_elite', 'killsign_stealth',
    'killsign_gold', 'killsign_diamond', 'killsign_fire', 'killsign_ice', 'killsign_shadow',
    
    # Color Presets
    'color_red', 'color_green', 'color_blue', 'color_yellow', 'color_purple', 'color_orange',
    'color_pink', 'color_cyan', 'color_white', 'color_black', 'color_gray',
    
    # Country/Language Selection (53)
    'country_en', 'country_fr', 'country_de', 'country_es', 'country_it', 'country_pt', 'country_ru', 'country_ja', 'country_ko', 'country_zh',
    'country_nl', 'country_sv', 'country_no', 'country_da', 'country_fi', 'country_pl', 'country_cs', 'country_hu', 'country_ro', 'country_bg', 'country_hr', 'country_sk', 'country_si', 'country_et', 'country_lv', 'country_lt', 'country_el', 'country_tr',
    'country_ar', 'country_he', 'country_hi', 'country_th', 'country_id', 'country_bn', 'country_ur', 'country_fa', 'country_uk', 'country_be', 'country_kk', 'country_uz', 'country_az', 'country_ka', 'country_am', 'country_sw', 'country_zu', 'country_af', 'country_is', 'country_mt', 'country_cy', 'country_ga', 'country_gd', 'country_eu', 'country_ca',
    
    # Combined Setup Functions
    'setup_player', 'setup_pro_player', 'setup_casual_player', 'setup_squad_player', 'setup_elite_player', 'setup_stealth_player',
    
    # Quick Configuration Chains
    'configure', 'with_name', 'with_killsign', 'with_country',
    
    # Profile Templates
    'profile_pro_gamer', 'profile_casual_gamer', 'profile_squad_leader', 'profile_elite_warrior', 'profile_stealth_ninja',
    'profile_gold_player', 'profile_diamond_master', 'profile_fire_warrior', 'profile_ice_queen', 'profile_shadow_assassin',
    
    # Batch
    'send_to_all', 'batch_spam',
    
    # One-liners
    'hello', 'goodbye', 'test', 'ping', 'thanks'
]

print("🎮 MC5 Ultra-Simple Chat Module Loaded!")
print("💡 Try: send('Hello!'), en('Bonjour!'), spam('Test', 5), check_inbox()")
