#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : version_manager.py
# | License  : MIT License © 2026 Chizoba
# | Brief    : Future-proof version management system
# ────────────────★─────────────────────────────────

"""
Future-Proof Version Management System

This module provides version management, compatibility checking,
and automatic migration for the MC5 API client.
"""

import json
import warnings
from typing import Dict, Any, List, Optional, Tuple
from dataclasses import dataclass
from pathlib import Path
import requests
from datetime import datetime

@dataclass
class VersionInfo:
    """Version information structure."""
    version: str
    release_date: str
    api_version: str
    compatibility: List[str]
    breaking_changes: List[str]
    new_features: List[str]
    deprecated_features: List[str]
    migration_guide: Optional[str] = None
    download_url: Optional[str] = None

class VersionManager:
    """
    Future-proof version management for MC5 API client.
    
    Handles version checking, compatibility, and automatic updates.
    """
    
    def __init__(self):
        """Initialize version manager."""
        self.current_version = "1.0.25"
        self.api_version = "1.0.25"
        self.config_file = Path.home() / ".mc5_api_client" / "versions.json"
        self.versions_cache: Dict[str, VersionInfo] = {}
        
        # Load version cache
        self._load_versions_cache()
        
        # Initialize with current version if empty
        if not self.versions_cache:
            self._initialize_current_version()
    
    def _load_versions_cache(self):
        """Load versions cache from file."""
        try:
            if self.config_file.exists():
                with open(self.config_file, 'r') as f:
                    data = json.load(f)
                
                for version_str, version_data in data.items():
                    self.versions_cache[version_str] = VersionInfo(**version_data)
        except Exception:
            pass  # Use default
    
    def _save_versions_cache(self):
        """Save versions cache to file."""
        try:
            self.config_file.parent.mkdir(parents=True, exist_ok=True)
            
            data = {}
            for version_str, version_info in self.versions_cache.items():
                data[version_str] = {
                    "version": version_info.version,
                    "release_date": version_info.release_date,
                    "api_version": version_info.api_version,
                    "compatibility": version_info.compatibility,
                    "breaking_changes": version_info.breaking_changes,
                    "new_features": version_info.new_features,
                    "deprecated_features": version_info.deprecated_features,
                    "migration_guide": version_info.migration_guide,
                    "download_url": version_info.download_url
                }
            
            with open(self.config_file, 'w') as f:
                json.dump(data, f, indent=2)
        except Exception:
            pass
    
    def _initialize_current_version(self):
        """Initialize current version information."""
        current = VersionInfo(
            version="1.0.25",
            release_date="2026-02-04",
            api_version="1.0.25",
            compatibility=["1.0.20", "1.0.21", "1.0.22", "1.0.23", "1.0.24", "1.0.25"],
            breaking_changes=[],
            new_features=[
                "Member profile updates in squads",
                "Kill signature customization",
                "Score and XP updates",
                "Automatic squad detection",
                "Proper squad membership settings",
                "Score limitation documentation (max 5200)"
            ],
            deprecated_features=[],
            download_url="https://pypi.org/project/mc5-api-client/1.0.25/"
        )
        
        self.versions_cache["1.0.25"] = current
        self._save_versions_cache()
    
    def check_compatibility(self, required_version: str) -> Dict[str, Any]:
        """
        Check version compatibility.
        
        Args:
            required_version: Required version
            
        Returns:
            Compatibility information
        """
        result = {
            "compatible": False,
            "current_version": self.current_version,
            "required_version": required_version,
            "issues": [],
            "recommendations": [],
            "migration_needed": False
        }
        
        # Check if exact version exists
        if required_version in self.versions_cache:
            version_info = self.versions_cache[required_version]
            
            # Check if current version is in compatibility list
            if self.current_version in version_info.compatibility:
                result["compatible"] = True
            else:
                result["issues"].append(f"Current version {self.current_version} not compatible with {required_version}")
                result["migration_needed"] = True
                
                # Find compatible version
                for compatible_version in version_info.compatibility:
                    if compatible_version in self.versions_cache:
                        result["recommendations"].append(f"Upgrade to {compatible_version}")
                        break
        else:
            result["issues"].append(f"Version {required_version} not found")
            result["recommendations"].append("Use latest available version")
        
        return result
    
    def get_latest_version(self) -> Optional[VersionInfo]:
        """
        Get latest version information.
        
        Returns:
            Latest version info or None if unavailable
        """
        try:
            # Try to fetch from PyPI
            response = requests.get("https://pypi.org/pypi/mc5-api-client/json", timeout=10)
            if response.status_code == 200:
                data = response.json()
                latest_version = data["info"]["version"]
                
                # Cache the latest version
                if latest_version not in self.versions_cache:
                    latest_info = VersionInfo(
                        version=latest_version,
                        release_date=data["releases"].get(latest_version, [{}])[0].get("upload_time", ""),
                        api_version=latest_version,
                        compatibility=[latest_version],
                        breaking_changes=[],
                        new_features=[],
                        deprecated_features=[],
                        download_url=f"https://pypi.org/project/mc5-api-client/{latest_version}/"
                    )
                    
                    self.versions_cache[latest_version] = latest_info
                    self._save_versions_cache()
                
                return self.versions_cache[latest_version]
        except Exception:
            pass  # Use cached version
        
        # Return latest cached version
        if self.versions_cache:
            latest = max(self.versions_cache.keys())
            return self.versions_cache[latest]
        
        return None
    
    def check_for_updates(self) -> Dict[str, Any]:
        """
        Check for available updates.
        
        Returns:
            Update information
        """
        result = {
            "update_available": False,
            "current_version": self.current_version,
            "latest_version": self.current_version,
            "update_info": None,
            "critical_update": False
        }
        
        latest = self.get_latest_version()
        if latest and latest.version != self.current_version:
            # Compare versions
            if self._compare_versions(latest.version, self.current_version) > 0:
                result["update_available"] = True
                result["latest_version"] = latest.version
                result["update_info"] = latest
                
                # Check if critical update
                if any("security" in change.lower() or "critical" in change.lower() 
                      for change in latest.breaking_changes):
                    result["critical_update"] = True
        
        return result
    
    def _compare_versions(self, version1: str, version2: str) -> int:
        """
        Compare two version strings.
        
        Args:
            version1: First version
            version2: Second version
            
        Returns:
            1 if version1 > version2, 0 if equal, -1 if version1 < version2
        """
        try:
            v1_parts = [int(x) for x in version1.split('.')]
            v2_parts = [int(x) for x in version2.split('.')]
            
            # Pad shorter version
            max_len = max(len(v1_parts), len(v2_parts))
            v1_parts.extend([0] * (max_len - len(v1_parts)))
            v2_parts.extend([0] * (max_len - len(v2_parts)))
            
            for v1, v2 in zip(v1_parts, v2_parts):
                if v1 > v2:
                    return 1
                elif v1 < v2:
                    return -1
            
            return 0
        except Exception:
            # Fallback to string comparison
            if version1 > version2:
                return 1
            elif version1 < version2:
                return -1
            else:
                return 0
    
    def get_migration_guide(self, from_version: str, to_version: str) -> Optional[str]:
        """
        Get migration guide between versions.
        
        Args:
            from_version: Source version
            to_version: Target version
            
        Returns:
            Migration guide or None if unavailable
        """
        if to_version in self.versions_cache:
            version_info = self.versions_cache[to_version]
            return version_info.migration_guide
        
        return None
    
    def add_version(self, version_info: VersionInfo):
        """
        Add version information to cache.
        
        Args:
            version_info: Version information
        """
        self.versions_cache[version_info.version] = version_info
        self._save_versions_cache()
    
    def deprecate_version(self, version: str, deprecation_date: str = None):
        """
        Mark a version as deprecated.
        
        Args:
            version: Version to deprecate
            deprecation_date: Deprecation date
        """
        if version in self.versions_cache:
            version_info = self.versions_cache[version]
            # Add deprecation warning
            version_info.deprecated_features.append(f"Version {version} deprecated on {deprecation_date or 'unknown date'}")
            self._save_versions_cache()
    
    def warn_deprecated_usage(self, feature: str, version: str = None):
        """
        Warn about deprecated feature usage.
        
        Args:
            feature: Feature name
            version: Version where deprecated
        """
        if version:
            warnings.warn(
                f"{feature} is deprecated since version {version}. "
                f"Please check the migration guide.",
                DeprecationWarning,
                stacklevel=3
            )
        else:
            warnings.warn(
                f"{feature} is deprecated. "
                f"Please check the documentation for alternatives.",
                DeprecationWarning,
                stacklevel=3
            )
    
    def validate_api_compatibility(self, api_version: str) -> Dict[str, Any]:
        """
        Validate API compatibility.
        
        Args:
            api_version: API version to validate
            
        Returns:
            Validation result
        """
        result = {
            "valid": False,
            "api_version": api_version,
            "client_version": self.current_version,
            "issues": [],
            "recommendations": []
        }
        
        # Check if API version is supported
        if api_version in self.versions_cache:
            version_info = self.versions_cache[api_version]
            
            # Check compatibility
            if self.current_version in version_info.compatibility:
                result["valid"] = True
            else:
                result["issues"].append(f"Client version {self.current_version} not compatible with API {api_version}")
                
                # Suggest compatible client versions
                for compatible_version in version_info.compatibility:
                    if compatible_version in self.versions_cache:
                        result["recommendations"].append(f"Use client version {compatible_version}")
        else:
            result["issues"].append(f"API version {api_version} not recognized")
            result["recommendations"].append("Use a supported API version")
        
        return result

# Global version manager instance
_version_manager = None

def get_version_manager() -> VersionManager:
    """Get global version manager instance."""
    global _version_manager
    if _version_manager is None:
        _version_manager = VersionManager()
    return _version_manager

def check_version_compatibility(required_version: str) -> Dict[str, Any]:
    """Check version compatibility (convenience function)."""
    return get_version_manager().check_compatibility(required_version)

def check_for_updates() -> Dict[str, Any]:
    """Check for available updates (convenience function)."""
    return get_version_manager().check_for_updates()

def warn_deprecated(feature: str, version: str = None):
    """Warn about deprecated feature (convenience function)."""
    get_version_manager().warn_deprecated_usage(feature, version)
