# ────────────[ KAKUZU ]────────────────────────────
# | Discord  : kakuzu_f0
# | Telegram : kakuzu_f0
# | Github   : kakuzu-f0
# | File     : squad_recommendations_example.py
# | License  : MIT License © 2026 Kakuzu
# | Brief    : MC5 Squad Recommendations and Search Example
# ────────────────★─────────────────────────────────

"""
MC5 Squad Recommendations & Search Example

This example demonstrates the new squad recommendation and search features
using real MC5 API data. Shows how to discover squads, get personalized
recommendations, and analyze squad patterns.
"""

import sys
import os
from pathlib import Path

# Add the src directory to the path so we can import mc5_api_client
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from mc5_api_client.squad_system import (
    get_squad_recommendations, show_squad_recommendations, analyze_recommended_squads,
    search_squads_by_name, search_and_analyze_squads
)


def main():
    """Main squad recommendations and search example"""
    print("🎯 MC5 SQUAD RECOMMENDATIONS & SEARCH EXAMPLE")
    print("=" * 60)
    print("Demonstrating AI-powered squad discovery with real MC5 data...\n")

    # 1. Get personalized squad recommendations
    print("📊 STEP 1: Personalized Squad Recommendations")
    print("-" * 50)
    
    recommendations = get_squad_recommendations(limit=8)
    if recommendations:
        print(f"✅ Found {len(recommendations)} personalized recommendations for you!")
        print("\n🏆 Top Recommended Squads:")
        
        for i, squad in enumerate(recommendations[:5], 1):
            name = squad.get('name', 'Unknown')
            members = squad.get('member_count', 0)
            member_limit = squad.get('member_limit', 0)
            rating = squad.get('_rating', 0)
            league_idx = squad.get('_league_info', {}).get('index', 0)
            description = squad.get('description', 'No description')
            owner_name = squad.get('owner', {}).get('name', 'Unknown')
            
            # Truncate long descriptions
            if len(description) > 40:
                description = description[:37] + "..."
            
            print(f"\n#{i}. {name}")
            print(f"   👥 Members: {members}/{member_limit}")
            print(f"   ⭐ Rating: {rating}")
            print(f"   🏅 League: {league_idx}")
            print(f"   👑 Owner: {owner_name}")
            print(f"   📝 {description}")
        
        print("\n✅ Personalized recommendations retrieved successfully!")
    else:
        print("❌ Could not get squad recommendations")

    # 2. Analyze recommendation patterns
    print("\n📈 STEP 2: Recommendation Analysis")
    print("-" * 50)
    
    analysis = analyze_recommended_squads(limit=10)
    if "error" not in analysis:
        print("📊 Recommendation Insights:")
        print(f"   📈 Total squads analyzed: {analysis['total_analyzed']}")
        print(f"   👥 Average squad size: {analysis['average_members']} members")
        print(f"   ⭐ Average rating: {analysis['average_rating']}")
        
        print("\n🏅 League Distribution:")
        for league, count in analysis['league_distribution'].items():
            print(f"   League {league}: {count} squads")
        
        print("\n👥 Size Distribution:")
        for size_cat, count in analysis['size_distribution'].items():
            print(f"   {size_cat}: {count} squads")
        
        print("\n💡 Key Insights:")
        for insight in analysis['recommendations']:
            print(f"   • {insight}")
        
        print("\n✅ Recommendation analysis completed!")
    else:
        print(f"❌ Analysis failed: {analysis['error']}")

    # 3. Search for squads by keywords
    print("\n🔍 STEP 3: Squad Search by Keywords")
    print("-" * 50)
    
    search_keywords = ["elite", "pro", "team", "war", "legends", "rxz"]
    
    for keyword in search_keywords:
        print(f"\n🔍 Searching for squads with '{keyword}':")
        
        search_results = search_squads_by_name(keyword, limit=3)
        if search_results:
            print(f"✅ Found {len(search_results)} squads:")
            
            for i, squad in enumerate(search_results, 1):
                name = squad.get('name', 'Unknown')
                members = squad.get('member_count', 0)
                member_limit = squad.get('member_limit', 0)
                rating = squad.get('_rating', 0)
                league_idx = squad.get('_league_info', {}).get('index', 0)
                owner_name = squad.get('owner', {}).get('name', 'Unknown')
                description = squad.get('description', 'No description')
                
                if description and len(description) > 30:
                    description = description[:27] + "..."
                
                print(f"  {i}. {name}")
                print(f"     👥 {members}/{member_limit} members")
                print(f"     ⭐ Rating: {rating}")
                print(f"     🏅 League: {league_idx}")
                print(f"     👑 Owner: {owner_name}")
                print(f"     📝 {description}")
        else:
            print(f"❌ No squads found matching '{keyword}'")

    # 4. Advanced search with analysis
    print("\n🔎 STEP 4: Advanced Search with Analysis")
    print("-" * 50)
    
    advanced_keywords = ["elite", "pro"]
    for keyword in advanced_keywords:
        print(f"\n🔍 Advanced search for '{keyword}':")
        search_and_analyze_squads(keyword, limit=5)

    # 5. Show comprehensive recommendations dashboard
    print("\n📊 STEP 5: Comprehensive Recommendations Dashboard")
    print("-" * 50)
    
    show_squad_recommendations(limit=8)

    # 6. Strategic insights and recommendations
    print("\n🎯 STEP 6: Strategic Insights")
    print("-" * 50)
    
    print("💡 SQUAD DISCOVERY STRATEGIES:")
    print("   1. 🎯 Use recommendations for personalized matches")
    print("   2. 🔍 Search by keywords to find specific playstyles")
    print("   3. 📊 Analyze squad size and rating for compatibility")
    print("   4. 👑 Check owner activity for squad leadership")
    print("   5. 🏅 Consider league level for competitive balance")
    
    print("\n🚀 JOINING RECOMMENDATIONS:")
    print("   1. 📈 Look for squads with 5-15 members for activity")
    print("   2. ⭐ Target squads with rating 900+ for quality")
    print("   3. 🏅 Join leagues 0-2 for appropriate challenge")
    print("   4. 👑 Verify active owners for good leadership")
    print("   5. 📝 Read descriptions for squad culture fit")
    
    print("\n🎮 SQUAD RECOMMENDATION FUNCTIONS:")
    print("   🎯 get_squad_recommendations() - Personalized suggestions")
    print("   📊 show_squad_recommendations() - Display with analysis")
    print("   📈 analyze_recommended_squads() - Pattern analysis")
    print("   🔍 search_squads_by_name() - Keyword search")
    print("   🔎 search_and_analyze_squads() - Search with insights")

    print("\n🎯 Example Complete!")
    print("   ✅ Squad recommendations working perfectly")
    print("   ✅ Search functionality verified")
    print("   ✅ Analysis insights generated")
    print("   ✅ Real data integration confirmed")
    print("   ✅ Strategic recommendations provided")


if __name__ == "__main__":
    main()
