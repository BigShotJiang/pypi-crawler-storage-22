# ────────────[ KAKUZU ]────────────────────────────
# | Discord  : kakuzu_f0
# | Telegram : kakuzu_f0
# | Github   : kakuzu-f0
# | File     : squad_system_example.py
# | License  : MIT License © 2026 Kakuzu
# | Brief    : MC5 Squad System example with real data demonstration
# ────────────────★─────────────────────────────────

"""
MC5 Squad System Example

This example demonstrates the complete squad system functionality using real MC5 data.
Shows how to access squad information, analyze performance, and get strategic recommendations.
"""

import sys
import os
from pathlib import Path

# Add the src directory to the path so we can import mc5_api_client
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from mc5_api_client.squad_system import (
    SquadSystem, get_my_squad_info, get_squad_leaderboard, 
    analyze_squad_performance, show_squad_dashboard, get_top_squads, compare_squads,
    get_squad_recommendations, search_squads_by_name, show_squad_recommendations,
    search_and_analyze_squads, analyze_recommended_squads
)


def main():
    """Main squad system example"""
    print("🏆 MC5 SQUAD SYSTEM EXAMPLE")
    print("=" * 50)
    print("Demonstrating squad system with real MC5 data...\n")

    # 1. Get your squad information
    print("📊 STEP 1: Get Your Squad Information")
    print("-" * 40)
    
    my_squad = get_my_squad_info()
    if my_squad:
        print(f"👥 Squad Name: {my_squad.get('_clan_name', 'Unknown')}")
        print(f"🏆 Score: {my_squad.get('score', 0):,.0f} points")
        print(f"📍 Global Rank: #{my_squad.get('rank', 0):,}")
        print(f"🏅 League Index: {my_squad.get('_league_index', 0)}")
        print(f"🕐 Last Update: {my_squad.get('last_update', 'Unknown')}")
        print(f"🎨 Logo Style: {my_squad.get('_logo', 0)}")
        print("✅ Squad information retrieved successfully!")
    else:
        print("❌ Could not retrieve squad information")
        return

    # 2. Get squad leaderboard around your rank
    print("\n📊 STEP 2: Explore Squad Leaderboard")
    print("-" * 40)
    
    # Get squads around your rank (±5 positions)
    my_rank = my_squad.get('rank', 619)
    start_offset = max(0, my_rank - 7)
    leaderboard = get_squad_leaderboard(offset=start_offset, limit=15)
    
    if leaderboard:
        squads = leaderboard.get('data', [])
        total_squads = leaderboard.get('total_entries', 0)
        
        print(f"📊 Total Squads: {total_squads:,}")
        print(f"🏆 Squads around your rank (#{my_rank}):")
        
        for squad in squads:
            name = squad.get('_clan_name', 'Unknown')
            score = squad.get('score', 0)
            rank = squad.get('rank', 0)
            is_you = "👤" if squad.get('id') == my_squad.get('id') else "  "
            
            # Format score display
            if score > 1e18:
                score_str = f"{score:.2e}"
            else:
                score_str = f"{score:,.0f}"
            
            print(f"{is_you} #{rank:3d}: {name[:20]:20s} - {score_str}")
        
        print("✅ Leaderboard data retrieved successfully!")
    else:
        print("❌ Could not retrieve leaderboard")

    # 3. Analyze your squad performance
    print("\n📊 STEP 3: Performance Analysis")
    print("-" * 40)
    
    analysis = analyze_squad_performance()
    if "error" not in analysis:
        print(f"🎯 Performance Tier: {analysis['league_info']['tier']}")
        print(f"📈 Global Percentile: {analysis['percentile']}%")
        print(f"🏅 League Description: {analysis['league_info']['description']}")
        print(f"📊 Median Squad Score: {analysis['median_score']:,.0f}")
        
        print("\n💡 Strategic Recommendations:")
        for i, rec in enumerate(analysis['recommendations'], 1):
            print(f"  {i}. {rec}")
        
        print("✅ Performance analysis completed!")
    else:
        print(f"❌ Analysis failed: {analysis['error']}")

    # 4. Get top performing squads
    print("\n📊 STEP 4: Elite Squad Analysis")
    print("-" * 40)
    
    top_squads = get_top_squads(limit=10)
    if top_squads:
        print("👑 Top 10 Elite Squads:")
        
        for i, squad in enumerate(top_squads, 1):
            name = squad['name']
            score = squad['score']
            rank = squad['rank']
            league = squad['league']
            
            # Handle very large scores with scientific notation
            if score > 1e18:
                score_str = f"{score:.2e}"
            else:
                score_str = f"{score:,.0f}"
            
            print(f"#{i:2d}. {name[:15]:15s} - {score_str:>12} (#{rank}, L{league})")
        
        print("✅ Elite squad analysis completed!")
    else:
        print("❌ Could not retrieve top squads")

    # 5. Show comprehensive dashboard
    print("\n📊 STEP 5: Comprehensive Dashboard")
    print("-" * 40)
    
    show_squad_dashboard()

    # 6. Demonstrate squad comparison
    print("\n📊 STEP 6: Squad Comparison")
    print("-" * 40)
    
    # Find two different squads to compare
    if leaderboard and len(leaderboard.get('data', [])) >= 3:
        squads = leaderboard.get('data', [])
        # Find two squads that aren't yours
        other_squads = [s for s in squads if s.get('id') != my_squad.get('id')]
        
        if len(other_squads) >= 2:
            squad1 = other_squads[0]
            squad2 = other_squads[1]
            
            print(f"🥊 Comparing: {squad1.get('_clan_name', 'Unknown')} vs {squad2.get('_clan_name', 'Unknown')}")
            
            comparison = compare_squads(squad1.get('id'), squad2.get('id'))
            if comparison:
                print(f"📊 Score Difference: {comparison['score_difference']:+.0f}")
                print(f"🏆 Rank Difference: {comparison['rank_difference']:+d}")
                print("✅ Squad comparison completed!")
            else:
                print("❌ Squad comparison failed")
        else:
            print("❌ Not enough other squads for comparison")
    else:
        print("❌ Cannot perform comparison - insufficient data")

    # 7. Get squad recommendations
    print("\n📊 STEP 7: Squad Recommendations")
    print("-" * 40)
    
    recommendations = get_squad_recommendations(limit=5)
    if recommendations:
        print(f"✅ Found {len(recommendations)} recommended squads for you!")
        print("🏆 Top Recommendations:")
        for i, squad in enumerate(recommendations[:3], 1):
            name = squad.get('name', 'Unknown')
            members = squad.get('member_count', 0)
            rating = squad.get('_rating', 0)
            league = squad.get('_league_info', {}).get('index', 0)
            description = squad.get('description', 'No description')
            if len(description) > 30:
                description = description[:27] + "..."
            print(f"  {i}. {name} - {members} members, rating {rating}, league {league}")
            print(f"     📝 {description}")
        
        # Analyze recommendations
        analysis = analyze_recommended_squads(limit=5)
        if "error" not in analysis:
            print("\n📈 Recommendation Analysis:")
            print(f"👥 Average squad size: {analysis['average_members']} members")
            print(f"⭐ Average rating: {analysis['average_rating']}")
            print(f"🏆 Most common league: League {max(analysis['league_distribution'], key=analysis['league_distribution'].get)}")
    else:
        print("❌ Could not get squad recommendations")

    # 8. Search for squads by name
    print("\n📊 STEP 8: Squad Search")
    print("-" * 40)
    
    # Search for squads with common keywords
    search_keywords = ["elite", "pro", "team"]
    for keyword in search_keywords:
        print(f"\n🔍 Searching for squads with '{keyword}':")
        search_results = search_squads_by_name(keyword, limit=3)
        if search_results:
            print(f"✅ Found {len(search_results)} squads:")
            for squad in search_results:
                name = squad.get('name', 'Unknown')
                members = squad.get('member_count', 0)
                rating = squad.get('_rating', 0)
                owner = squad.get('owner', {}).get('name', 'Unknown')
                print(f"  • {name} - {members} members, rating {rating}")
                print(f"    👑 Owner: {owner}")
        else:
            print(f"❌ No squads found with '{keyword}'")

    # 9. Summary and next steps
    print("\n🎯 SUMMARY & NEXT STEPS")
    print("-" * 40)
    
    if my_squad:
        score = my_squad.get('score', 0)
        rank = my_squad.get('rank', 0)
        total = leaderboard.get('total_entries', 2182) if leaderboard else 2182
        percentile = ((total - rank) / total) * 100
        
        print(f"🏆 Your Squad: {my_squad.get('_clan_name', 'Unknown')}")
        print(f"📊 Current Performance: {percentile:.1f}% percentile")
        print(f"🎯 Immediate Goal: Increase score to {score + 200:,} points")
        print(f"🚀 Next Target: Reach top 25% (rank ~{int(total * 0.75):,})")
        
        print("\n💡 Action Items:")
        print("  1. Recruit active members to boost squad activity")
        print("  2. Organize regular squad events and gameplay sessions")
        print("  3. Set weekly score goals for squad members")
        print("  4. Monitor progress using the squad dashboard")
        print("  5. Compete with nearby squads for motivation")

    print("\n🎮 SQUAD SYSTEM FUNCTIONS AVAILABLE:")
    print("   📊 get_my_squad_info() - Your squad details")
    print("   🏆 get_squad_leaderboard() - Full leaderboard access")
    print("   📈 analyze_squad_performance() - Performance analytics")
    print("   📋 show_squad_dashboard() - Complete overview")
    print("   👑 get_top_squads() - Elite squad analysis")
    print("   ⚔️ compare_squads() - Head-to-head comparison")
    print("   🎯 get_squad_recommendations() - Personalized recommendations")
    print("   🔍 search_squads_by_name() - Search squads by keywords")
    print("   📊 show_squad_recommendations() - Display recommendations")
    print("   🔎 search_and_analyze_squads() - Search with analysis")
    print("   📈 analyze_recommended_squads() - Recommendation insights")

    print("\n🎯 Example Complete!")
    print("   ✅ Squad system fully demonstrated")
    print("   ✅ Real data integration confirmed")
    print("   ✅ All features working correctly")
    print("   ✅ Strategic insights provided")
    print("   ✅ Recommendation system active")
    print("   ✅ Search functionality verified")


if __name__ == "__main__":
    main()
