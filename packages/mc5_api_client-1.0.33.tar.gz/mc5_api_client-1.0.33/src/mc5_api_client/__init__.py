#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : __init__.py
# | License  : MIT License 2026 Chizoba
# | Brief    : MC5 API Client - Complete Modern Combat 5 integration
# ────────────────★─────────────────────────────────

"""
Modern Combat 5 API Client

A comprehensive Python library for interacting with the Modern Combat 5 API.
Provides easy access to authentication, profile management, clan operations,
messaging, and more.
"""

from typing import Optional, Dict, Any

__version__ = "1.0.26"
__author__ = "Chizoba"
__email__ = "chizoba2026@hotmail.com"
__license__ = "MIT"

from .telemetry import telemetry, report_error, report_usage, is_telemetry_enabled
from .debug import debug_mode, debug_print, debug_function, analyze_error, print_error_analysis
from .platform import Platform, get_platform_config, get_android_anonymous_credential, get_pc_anonymous_credential
from .squad_battle import SquadBattleMixin
from .api_config import get_config, FutureProofConfig
from .api_adapter import get_adapter, APIAdapterFactory
from .version_manager import get_version_manager, check_version_compatibility, check_for_updates
from .transfer_quick import (
    quick_generate_transfer_code,
    quick_check_transfer_status,
    quick_get_device_linking_guide,
    quick_link_device_workflow,
    quick_validate_transfer_code,
    quick_force_new_code,
    quick_transfer_status_summary
)
from .account_quick import (
    quick_get_account_info,
    quick_get_device_history,
    quick_get_credential_summary,
    quick_analyze_account_security,
    quick_get_account_overview,
    quick_export_account_data
)
from .alerts_quick import (
    quick_start_alert_stream,
    quick_test_alert_connection,
    quick_start_alerts_with_discord,
    quick_monitor_alerts,
    create_alert_callback
)
from .federation_quick import (
    quick_get_active_sessions,
    quick_get_my_sessions,
    quick_get_session_statistics,
    quick_check_session_status,
    quick_get_server_type_sessions,
    quick_analyze_session_activity
)
from .squad_battle_quick import (
    quick_create_squad_battle_room,
    quick_post_squad_battle_result,
    quick_get_squad_battle_history,
    quick_analyze_squad_performance,
    quick_get_squad_wall_messages,
    quick_send_squad_battle_notification,
    quick_post_squad_wall_message
)
from .simple_client import (
    SimpleMC5Client,
    batch_search_players,
    clan_cleanup,
    monitor_clan_activity,
    quick_search,
    quick_kick,
    quick_remove_friend,
    quick_send_friend_request,
    quick_check_friend_status,
    quick_accept_friend_request,
    quick_sign_up_for_event,
    quick_get_event_leaderboard,
    quick_get_my_event_rank,
    quick_get_squad_invitations,
    quick_accept_squad_invitation,
    quick_decline_squad_invitation
)
# Import chat functionality
from .chat import MC5ChatClient, send_chat_message, listen_to_chat
from .ultra_simple_chat import (
    send, quick, en, fr, de, es, it, pt, ru, ja, ko, zh,
    nl, sv, no, da, fi, pl, cs, hu, ro, bg, hr, sk, si, et, lv, lt, el, tr,
    ar, he, hi, th, id, bn, ur, fa, uk, be, kk, uz, az, ka, am, sw, zu, af, is_, mt, cy, ga, gd, eu, ca,
    spam, spam_en, spam_fr, rapid_spam, subtle_spam,
    pro, casual, squad, elite, stealth,
    check_inbox, my_messages, check_spam,
    impersonate, become_player, anonymous_spy,
    listen, listen_en, listen_all,
    set_name, set_signature, set_language, test_connection, get_server,
    # Comprehensive Customization
    set_killsign, set_killsign_color, set_killsign_name, set_nickname, set_country, set_chat_country,
    # Kill Sign Presets
    killsign_pro, killsign_casual, killsign_squad, killsign_elite, killsign_stealth,
    killsign_gold, killsign_diamond, killsign_fire, killsign_ice, killsign_shadow,
    # Color Presets
    color_red, color_green, color_blue, color_yellow, color_purple, color_orange,
    color_pink, color_cyan, color_white, color_black, color_gray,
    # Country/Language Selection (53)
    country_en, country_fr, country_de, country_es, country_it, country_pt, country_ru, country_ja, country_ko, country_zh,
    country_nl, country_sv, country_no, country_da, country_fi, country_pl, country_cs, country_hu, country_ro, country_bg, country_hr, country_sk, country_si, country_et, country_lv, country_lt, country_el, country_tr,
    country_ar, country_he, country_hi, country_th, country_id, country_bn, country_ur, country_fa, country_uk, country_be, country_kk, country_uz, country_az, country_ka, country_am, country_sw, country_zu, country_af, country_is, country_mt, country_cy, country_ga, country_gd, country_eu, country_ca,
    # Combined Setup Functions
    setup_player, setup_pro_player, setup_casual_player, setup_squad_player, setup_elite_player, setup_stealth_player,
    # Quick Configuration Chains
    configure, with_name, with_killsign, with_country,
    # Profile Templates
    profile_pro_gamer, profile_casual_gamer, profile_squad_leader, profile_elite_warrior, profile_stealth_ninja,
    profile_gold_player, profile_diamond_master, profile_fire_warrior, profile_ice_queen, profile_shadow_assassin,
    send_to_all, batch_spam,
    hello, goodbye, test, ping, thanks
)
from .room_matchmaking import (
    MC5RoomAPI,
    find_duel_rooms, find_team_battle_rooms, find_custom_rooms,
    quick_duel_match, quick_team_battle
)
from .enhanced_utilities import (
    MC5EnhancedAPI, get_server_stats, find_best_game_rooms, search_players,
    get_room_recommendations, monitor_rooms_live, generate_server_report,
    auto_join_best_room, analyze_player_activity
)
from .advanced_chat_utilities import (
    AdvancedChatManager, chat_manager, create_template, use_template,
    broadcast, schedule_chat, get_chat_stats, chat_report,
    announce_to_all, announce_to_europe, announce_to_asia,
    setup_smart_replies, auto_greet, monitor_chat_health
)
from .game_analytics import (
    MC5GameAnalytics, get_player_analytics, get_game_mode_rankings,
    check_server_health, track_player, generate_analytics_report,
    start_real_time_monitoring, calculate_player_skill_distribution
)
from .mp_invite_system import (
    MC5MPInviteSystem, create_team_battle_invite, create_ctf_invite,
    create_zone_control_invite, create_vip_invite, create_duel_invite,
    send_global_invite, send_squad_invite, quick_team_battle_streets,
    quick_ctf_rooftops, quick_vip_rooftops, quick_duel_showdown,
    quick_zone_control_canals, list_game_modes, list_maps, show_invite_example
)
from .event_system import (
    MC5EventSystem, register_event, get_event_leaderboard, get_my_event_rank,
    show_event_leaderboard, show_my_event_status, register_current_event,
    show_current_event_leaderboard, show_my_current_event_status
)
from .enhanced_event_system import (
    EnhancedEventSystem, register_for_current_event_enhanced, get_current_event_status_enhanced,
    find_current_event_game, track_event_progress_enhanced, analyze_my_event_performance_enhanced,
    show_event_dashboard_enhanced
)
from .matchmaking_system import (
    MC5MatchmakingSystem, quick_play, find_game, get_room_info, show_room_details,
    quick_battle, quick_event_battle, quick_team_battle, quick_ctf, current_event_quick_play
)
from .leaderboard_system import (
    MC5LeaderboardSystem, get_leaderboard, get_my_rank, show_leaderboard,
    show_my_rank_context, analyze_leaderboard, get_current_event_leaderboard,
    show_current_event_leaderboard, get_my_current_event_rank, show_my_current_event_context,
    analyze_current_event, update_leaderboard_score, update_my_score,
    update_current_event_score, update_my_current_event_score
)
from .squad_system import (
    SquadSystem, get_my_squad_info, get_squad_leaderboard, analyze_squad_performance,
    show_squad_dashboard, get_top_squads, compare_squads, get_squad_recommendations,
    search_squads_by_name, show_squad_recommendations, search_and_analyze_squads,
    analyze_recommended_squads
)
from .client import MC5Client
from .auth import TokenGenerator
from .exceptions import MC5APIError, AuthenticationError, RateLimitError
from .help import help, examples, quick_reference

# Automatic Squad Management (NEW!)
from .client import MC5Client

# Add automatic squad management methods as standalone functions
def get_my_squad_id(client=None, **kwargs):
    """Get user's squad ID automatically."""
    if client is None:
        client = MC5Client(**kwargs)
    return client.get_my_squad_id()

def get_my_squad_info(client=None, **kwargs):
    """Get user's squad information automatically."""
    if client is None:
        client = MC5Client(**kwargs)
    return client.get_my_squad_info()

def update_my_squad_info(client=None, **squad_kwargs):
    """Update user's squad information automatically."""
    client_kwargs = {k: v for k, v in squad_kwargs.items() if k in ['username', 'password', 'client_id']}
    update_kwargs = {k: v for k, v in squad_kwargs.items() if k not in ['username', 'password', 'client_id']}
    
    if client is None:
        client = MC5Client(**client_kwargs)
    return client.update_my_squad_info(**update_kwargs)

def get_my_squad_members(client=None, **kwargs):
    """Get user's squad members automatically."""
    if client is None:
        client = MC5Client(**kwargs)
    return client.get_my_squad_members()

# Working Clan Management Functions (PROVEN TO WORK!)
def get_clan_info(username: str, password: str) -> Optional[Dict[str, Any]]:
    """
    Automatically detect and retrieve clan information using get_batch_profiles.
    
    This is the PROVEN working method that successfully extracts clan information
    from the user's profile data. Now with future-proof adapter support.
    
    Args:
        username: MC5 username/credential
        password: MC5 password
        
    Returns:
        Dictionary with clan information or None if not found
        {
            'clan_name': str,
            'clan_id': str,
            'display_name': str,
            'clan_member': int,
            'clan_logo': int,
            'clan_logo_clr_prim': int,
            'clan_logo_clr_sec': int
        }
    """
    import requests
    
    try:
        # Use future-proof adapter
        adapter = get_adapter()
        
        # Prepare request parameters
        params = {
            'op_code': 'get_batch_profiles',
            'client_id': '1875:55979:6.0.0a:windows:windows',
            'credentials': username,
            'pandora': 'https://vgold-eur.gameloft.com/1875:55979:6.0.0a:windows:windows',
            'include_fields': '_game_save,inventory'
        }
        
        # Execute using adapter with fallback support
        success, result = adapter.execute('get_batch_profiles', **params)
        
        if success:
            # Parse the response
            import json
            try:
                response_data = json.loads(result) if isinstance(result, str) else result
            except:
                # Fallback parsing for different response formats
                response_data = result
            
            if username in response_data:
                user_data = response_data[username]
                if '_game_save' in user_data and 'osiris_info' in user_data['_game_save']:
                    clan_info = user_data['_game_save']['osiris_info']
                    return {
                        'clan_name': clan_info.get('clan_name'),
                        'clan_id': clan_info.get('clan_id'),
                        'display_name': clan_info.get('display_name'),
                        'clan_member': clan_info.get('clan_member'),
                        'clan_logo': clan_info.get('clan_logo'),
                        'clan_logo_clr_prim': clan_info.get('clan_logo_clr_prim'),
                        'clan_logo_clr_sec': clan_info.get('clan_logo_clr_sec')
                    }
    except Exception as e:
        # Log error for debugging
        print(f"⚠️ Error in get_clan_info: {e}")
    
    return None

# Future-proof version with version checking
def get_clan_info_v2(username: str, password: str, api_version: str = None) -> Optional[Dict[str, Any]]:
    """
    Future-proof version of get_clan_info with version checking.
    
    Args:
        username: MC5 username/credential
        password: MC5 password
        api_version: Specific API version to use (auto-detect if None)
        
    Returns:
        Dictionary with clan information or None if not found
    """
    # Check version compatibility
    if api_version:
        compatibility = check_version_compatibility(api_version)
        if not compatibility['compatible']:
            print(f"⚠️ Version compatibility issue: {compatibility['issues']}")
            for rec in compatibility['recommendations']:
                print(f"   Recommendation: {rec}")
    
    # Use version-specific adapter
    adapter = get_adapter(version=api_version)
    
    try:
        params = {
            'op_code': 'get_batch_profiles',
            'client_id': '1875:55979:6.0.0a:windows:windows',
            'credentials': username,
            'pandora': 'https://vgold-eur.gameloft.com/1875:55979:6.0.0a:windows:windows',
            'include_fields': '_game_save,inventory'
        }
        
        success, result = adapter.execute('get_batch_profiles', **params)
        
        if success:
            # Parse response with error handling
            import json
            try:
                response_data = json.loads(result) if isinstance(result, str) else result
            except json.JSONDecodeError:
                # Try different parsing methods
                try:
                    response_data = eval(result) if isinstance(result, str) else result
                except:
                    print("⚠️ Unable to parse response format")
                    return None
            
            if username in response_data:
                user_data = response_data[username]
                if '_game_save' in user_data and 'osiris_info' in user_data['_game_save']:
                    clan_info = user_data['_game_save']['osiris_info']
                    return {
                        'clan_name': clan_info.get('clan_name'),
                        'clan_id': clan_info.get('clan_id'),
                        'display_name': clan_info.get('display_name'),
                        'clan_member': clan_info.get('clan_member'),
                        'clan_logo': clan_info.get('clan_logo'),
                        'clan_logo_clr_prim': clan_info.get('clan_logo_clr_prim'),
                        'clan_logo_clr_sec': clan_info.get('clan_logo_clr_sec')
                    }
    except Exception as e:
        print(f"⚠️ Error in get_clan_info_v2: {e}")
    
    return None

def update_clan_settings(clan_id: str, updates: Dict[str, Any], username: str, password: str) -> tuple:
    """
    Update clan settings using the PROVEN working API structure.
    
    This method successfully updates clan name, description, rating, currency,
    and other settings using the correct API endpoint and token structure.
    Now with future-proof adapter support.
    
    🎯 IMPORTANT SQUAD MEMBERSHIP SETTINGS:
    - 🔓 Open: membership="open", _min_join_value=any (default 500)
    - 👥 Invitation Only: membership="member_approved", _min_join_value=999699 (fixed)
    - 🔒 Request Only: membership="owner_approved", _min_join_value=996699 (fixed)
    - ⚠️ Rating cannot be 999699 or 996699 (reserved for membership types)
    
    Args:
        clan_id: The clan ID to update
        updates: Dictionary of updates to apply
        username: MC5 username/credential
        password: MC5 password
        
    Returns:
        Tuple of (success: bool, response: str)
        
    Example:
        # Open squad (default)
        updates = {
            "name": "Elite Warriors",
            "description": "Join us for epic battles!",
            "_rating": 8500,
            "currency": "50000",
            "membership": "open",
            "_min_join_value": 500
        }
        
        # Invitation only squad
        updates = {
            "name": "Private Squad",
            "membership": "member_approved",
            "_min_join_value": 999699,  # ALWAYS this value
            "_rating": 800
        }
        
        # Request only squad  
        updates = {
            "name": "Selective Squad",
            "membership": "owner_approved",
            "_min_join_value": 996699,  # ALWAYS this value
            "_rating": 900
        }
        
        success, result = update_clan_settings(clan_id, updates, username, password)
    """
    import time
    import requests
    
    try:
        # Initialize and authenticate client
        client = MC5Client(
            client_id="1875:55979:6.0.0a:windows:windows",
            username=username,
            password=password
        )
        
        # Extract token data
        access_token = client._token_data.get('access_token')
        if not access_token:
            return False, "No access token found"
        
        token_parts = access_token.split(',')
        
        if len(token_parts) < 6:
            return False, "Invalid token format"
        
        # Construct fed_id from token parts (EXACT working method)
        timestamp = token_parts[3]
        credential_short = token_parts[4].split(':')[1][:16] if ':' in token_parts[4] else token_parts[4][:16]
        fed_id = f"fed_id:{timestamp[:8]}-{timestamp[8:12]}-{timestamp[12:16]}-{credential_short[:12]}"
        
        # Use future-proof adapter
        adapter = get_adapter(client)
        
        # Prepare request parameters
        params = {
            "clan_id": clan_id,
            "access_token": access_token,
            "_anonId": username,
            "_fedId": fed_id,
            "timestamp": str(int(time.time()))
        }
        
        # Add updates to parameters
        params.update(updates)
        
        # Execute using adapter with fallback support
        success, result = adapter.execute('update_clan_settings', **params)
        
        return success, result
        
    except Exception as e:
        return False, str(e)

# Future-proof version with version checking
def update_clan_settings_v2(clan_id: str, updates: Dict[str, Any], username: str, password: str, api_version: str = None) -> tuple:
    """
    Future-proof version of update_clan_settings with version checking.
    
    Args:
        clan_id: The clan ID to update
        updates: Dictionary of updates to apply
        username: MC5 username/credential
        password: MC5 password
        api_version: Specific API version to use (auto-detect if None)
        
    Returns:
        Tuple of (success: bool, response: str)
    """
    # Check version compatibility
    if api_version:
        compatibility = check_version_compatibility(api_version)
        if not compatibility['compatible']:
            print(f"⚠️ Version compatibility issue: {compatibility['issues']}")
            for rec in compatibility['recommendations']:
                print(f"   Recommendation: {rec}")
    
    # Use version-specific adapter
    client = MC5Client(
        client_id="1875:55979:6.0.0a:windows:windows",
        username=username,
        password=password
    )
    
    adapter = get_adapter(client, api_version)
    
    try:
        access_token = client._token_data.get('access_token')
        if not access_token:
            return False, "No access token found"
        
        token_parts = access_token.split(',')
        
        if len(token_parts) < 6:
            return False, "Invalid token format"
        
        timestamp = token_parts[3]
        credential_short = token_parts[4].split(':')[1][:16] if ':' in token_parts[4] else token_parts[4][:16]
        fed_id = f"fed_id:{timestamp[:8]}-{timestamp[8:12]}-{timestamp[12:16]}-{credential_short[:12]}"
        
        params = {
            "clan_id": clan_id,
            "access_token": access_token,
            "_anonId": username,
            "_fedId": fed_id,
            "timestamp": str(int(time.time()))
        }
        
        params.update(updates)
        
        success, result = adapter.execute('update_clan_settings', **params)
        
        return success, result
        
    except Exception as e:
        return False, str(e)

def clan_management_workflow(username: str, password: str) -> bool:
    """
    Complete clan management workflow using the PROVEN working methods.
    
    This function demonstrates the complete workflow:
    1. Auto-detect clan
    2. Get current settings
    3. Apply updates
    4. Verify changes
    
    Args:
        username: MC5 username/credential
        password: MC5 password
        
    Returns:
        True if successful, False otherwise
    """
    try:
        # Step 1: Auto-detect clan
        clan_info = get_clan_info(username, password)
        
        if not clan_info:
            print("❌ No clan found for this user")
            return False
        
        print(f"🏰 Found clan: {clan_info['clan_name']}")
        print(f"🆔 Clan ID: {clan_info['clan_id']}")
        
        # Step 2: Get current settings
        client = MC5Client(
            client_id="1875:55979:6.0.0a:windows:windows",
            username=username,
            password=password
        )
        
        current_squad = client.get_squad_info(clan_info['clan_id'])
        if 'error' not in current_squad:
            print("📋 Current Settings:")
            print(f"   Name: {current_squad.get('name')}")
            print(f"   Description: {current_squad.get('description')}")
            print(f"   Rating: {current_squad.get('rating')}")
            print(f"   Currency: {current_squad.get('currency')}")
        
        # Step 3: Apply updates (example updates)
        updates = {
            "name": "Workflow Updated Clan",
            "description": "Updated via complete workflow function!",
            "_rating": 8888,
            "currency": "44444"
        }
        
        success, result = update_clan_settings(
            clan_id=clan_info['clan_id'],
            updates=updates,
            username=username,
            password=password
        )
        
        if success:
            print("✅ Clan successfully updated!")
            
            # Step 4: Verify changes
            updated_squad = client.get_squad_info(clan_info['clan_id'])
            if 'error' not in updated_squad:
                print("🔄 Verified Changes:")
                print(f"   Name: {updated_squad.get('name')}")
                print(f"   Description: {updated_squad.get('description')}")
                print(f"   Rating: {updated_squad.get('rating')}")
                print(f"   Currency: {updated_squad.get('currency')}")
            return True
        else:
            print(f"❌ Update failed: {result}")
            return False
            
    except Exception as e:
        print(f"❌ Error: {e}")
        return False

# Member Profile Update Functions (NEW!)
def update_member_profile(group_id: str, member_credential: str, updates: Dict[str, Any], username: str, password: str) -> tuple:
    """
    Update member profile information within a squad.
    
    This method updates individual member data like kill signatures, scores, and XP
    while the member is in a squad. This complements clan settings updates by allowing
    individual member profile modifications.
    
    Args:
        group_id: The squad/group ID
        member_credential: The member's credential to update
        updates: Dictionary of member profile updates
        username: MC5 username/credential
        password: MC5 password
        
    Returns:
        Tuple of (success: bool, response: str)
        
    Example:
        # Update your own profile in squad
        clan_info = get_clan_info(username, password)
        group_id = clan_info['clan_id']
        
        profile_updates = {
            "_killsig_color": "16777215",  # White color
            "_killsig_id": "default_killsig_42",  # Kill signature ID
            "_score": "4500",  # Your score (⚠️ Max: 5200 - higher may be flagged)
            "_xp": "18873035"  # Your XP
        }
        
        success, result = update_member_profile(group_id, username, profile_updates, username, password)
    
    ⚠️ Important Score Limitation:
    - Maximum recommended score: 5200
    - Higher values may be flagged as suspicious by the game
    - Best practice: Keep scores at or below 5200 to avoid detection
    """
    import time
    import requests
    
    try:
        # Initialize and authenticate client
        client = MC5Client(
            client_id="1875:55979:6.0.0a:windows:windows",
            username=username,
            password=password
        )
        
        # Extract token data
        access_token = client._token_data.get('access_token')
        if not access_token:
            return False, "No access token found"
        
        # Build the member update URL
        url = f"https://eur-osiris.gameloft.com/groups/{group_id}/members/{member_credential}"
        
        # Build payload according to API documentation
        payload = {
            "access_token": access_token,
            "credential": member_credential,
            "operation": "update",
            "timestamp": str(int(time.time()))
        }
        
        # Add member profile updates to payload
        payload.update(updates)
        
        # Make the update request
        headers = {
            "Host": "eur-osiris.gameloft.com",
            "Accept": "*/*",
            "Content-Type": "application/x-www-form-urlencoded"
        }
        
        response = requests.post(url, headers=headers, data=payload, timeout=30)
        
        return response.status_code == 200, response.text
        
    except Exception as e:
        return False, str(e)

def update_my_squad_profile(username: str, password: str, profile_updates: Dict[str, Any]) -> bool:
    """
    Complete workflow to update your profile within your squad.
    
    This function automatically detects your squad and updates your member profile.
    You must be in a squad to use this function.
    
    Args:
        username: MC5 username/credential
        password: MC5 password
        profile_updates: Dictionary of profile updates
        
    Returns:
        True if successful, False otherwise
        
    Example:
        profile_updates = {
            "_killsig_color": "16711680",  # Red color
            "_killsig_id": "default_killsig_99",  # Different kill signature
            "_score": "5000",  # New score (⚠️ Max: 5200 - higher may be flagged)
            "_xp": "20000000"  # New XP
        }
        
        success = update_my_squad_profile(username, password, profile_updates)
    
    ⚠️ Important Score Limitation:
    - Maximum recommended score: 5200
    - Higher values may be flagged as suspicious by the game
    - Best practice: Keep scores at or below 5200 to avoid detection
    """
    try:
        # Step 1: Auto-detect your squad
        clan_info = get_clan_info(username, password)
        
        if not clan_info:
            print("❌ No squad found - you must be in a squad to update profile")
            return False
        
        group_id = clan_info['clan_id']
        member_credential = username  # Your own credential
        
        print(f"🏰 Found squad: {clan_info['clan_name']}")
        print(f"🆔 Group ID: {group_id}")
        
        # Step 2: Update your member profile
        success, result = update_member_profile(group_id, member_credential, profile_updates, username, password)
        
        if success:
            print("✅ Squad profile updated successfully!")
            print(f"   Response: {result[:100]}...")
            return True
        else:
            print(f"❌ Profile update failed: {result}")
            return False
            
    except Exception as e:
        print(f"❌ Error: {e}")
        return False

# Add MC5ApiClient as an alias for backward compatibility
MC5ApiClient = MC5Client
from .admin_client import (
    AdminMC5Client,
    create_admin_client,
    create_user_client,
    quick_add_squad_rating,
    quick_update_player_score
)
from .pc_storage_client import PCStorageClient
from .storage_admin import StorageAdminMixin
from .easy_mc5 import MC5Easy

# Encrypted token convenience functions
from .auth import TokenGenerator

# Convenience functions for global ID operations
def get_global_id(device_id: str = None, device_type: str = "w10", hdidfv: str = None) -> str:
    """
    Get a global device ID from Gameloft's global ID service.
    
    Args:
        device_id: Your device ID (optional, will generate one if not provided)
        device_type: Device type (w10, android, ios, etc.)
        hdidfv: Hardware ID fingerprint (optional)
        
    Returns:
        Global device ID string
    """
    import requests
    
    # Build request parameters
    params = {
        "source": "Identifiers_6.0.0",
        "client_id": "1875:55979:6.0.0a:windows:windows",
        "device_type": device_type,
        "global_device_id": device_id or "1364509832654538259",
        "hdidfv": hdidfv or "76dfc72e-7850-4d9e-b79c-9861c7e3ea20"
    }
    
    headers = {
        "Accept": "*/*",
        "Accept-Encoding": "gzip;q=1.0, deflate;q=1.0, identity;q=0.5, *;q=0"
    }
    
    try:
        response = requests.get(
            "https://gdid.datalake.gameloft.com/assign_global_id/",
            params=params,
            headers=headers,
            timeout=30
        )
        
        if response.status_code == 200:
            return response.text.strip()
        else:
            return ""
    except Exception:
        return ""

def generate_device_id() -> str:
    """
    Generate a unique device ID for the current device.
    
    Returns:
        Generated device ID string
    """
    import uuid
    
    # Generate a unique device ID
    device_id = f"mc5_{uuid.uuid4().hex[:16]}"
    return device_id

def create_federation_session(username: str = None, password: str = None, device_id: str = None) -> Dict[str, Any]:
    """
    Create a federation session for MC5 game launch.
    
    Args:
        username: MC5 username (can use MC5_USERNAME env var)
        password: MC5 password (can use MC5_PASSWORD env var)
        device_id: Device ID for the session (optional)
        
    Returns:
        Dictionary with session information
    """
    import os
    import requests
    
    # Use environment variables if not provided
    username = username or os.getenv('MC5_USERNAME')
    password = password or os.getenv('MC5_PASSWORD')
    
    if not username or not password:
        return {"error": "Username and password are required"}
    
    try:
        # Build request parameters
        params = {
            "password": password,
            "device_id": device_id or "1364509832654538259"
        }
        
        headers = {
            "Accept": "*/*",
            "Content-Type": "application/x-www-form-urlencoded"
        }
        
        # Build URL with encoded credential
        encoded_credential = username.replace(":", "%3A")
        url = f"https://federation-eur.gameloft.com/sessions/1875%3A55979%3A6.0.0a%3Awindows%3Awindows/{encoded_credential}"
        
        # Make request
        response = requests.post(
            url,
            data=params,
            headers=headers,
            timeout=30
        )
        
        if response.status_code == 200:
            return response.json()
        else:
            return {"error": f"HTTP {response.status_code}", "response": response.text}
    
    except Exception as e:
        return {"error": str(e)}

def locate_service(service: str) -> str:
    """
    Locate a service endpoint for MC5.
    
    Args:
        service: Service name (leaderboard, matchmaker, auth, social, alert, message, lobby, gs, sp)
        
    Returns:
        Service endpoint URL or empty string if not found
    """
    import requests
    
    try:
        # Build request parameters
        params = {
            "service": service,
            "client_id": "1875:55979:6.0.0a:windows:windows"
        }
        
        headers = {
            "Accept": "*/*"
        }
        
        # Make request
        response = requests.get(
            "https://vgold-eur.gameloft.com/1875:55979:6.0.0a:windows:windows/locate",
            params=params,
            headers=headers,
            timeout=30
        )
        
        if response.status_code == 200:
            return response.text.strip()
        else:
            return ""
    
    except Exception:
        return ""

# Dogtag Search Functions
def search_dogtag_by_id(dogtag_id: str, username: str = None, password: str = None) -> list:
    """
    Search for a specific dogtag by its ID/code.
    
    Args:
        dogtag_id: The dogtag ID/code to search for (e.g., "f55f" - use lowercase)
        username: MC5 username/credential (optional, uses default if None)
        password: MC5 password (optional, uses default if None)
    
    Returns:
        List of found dogtag information with details
        
    Example:
        results = search_dogtag_by_id("f55f")  # Use lowercase
        for result in results:
            print(f"Found: {result['location']} - {result['id_match']}")
    
    Note:
        - Always use lowercase for dogtag IDs (e.g., "f55f" not "F55F")
        - Function will automatically convert to lowercase for case-insensitive search
    """
    import json
    
    # Use default credentials if not provided
    if not username or not password:
        username = "anonymous:d2luOF92M18xNzcwMDUxNjkwXy7H33aeTVB4YZictyDq48c="
        password = "sSJKzhQ5l4vrFgov"
    
    # Convert to lowercase for consistent search
    dogtag_id = dogtag_id.lower()
    
    found_dogtags = []
    
    try:
        # Use future-proof adapter
        adapter = get_adapter()
        
        params = {
            'op_code': 'get_batch_profiles',
            'client_id': '1875:55979:6.0.0a:windows:windows',
            'credentials': username,
            'pandora': 'https://vgold-eur.gameloft.com/1875:55979:6.0.0a:windows:windows',
            'include_fields': '_game_save,inventory,statistics,progress,achievements'
        }
        
        success, result = adapter.execute('get_batch_profiles', **params)
        
        if success:
            try:
                data = json.loads(result) if isinstance(result, str) else result
                
                if username in data:
                    user_data = data[username]
                    
                    # Search in _game_save
                    if '_game_save' in user_data:
                        game_save = user_data['_game_save']
                        found = _deep_search_dogtag_id(game_save, dogtag_id, "game_save")
                        found_dogtags.extend(found)
                    
                    # Search in inventory
                    if 'inventory' in user_data:
                        inventory = user_data['inventory']
                        found = _deep_search_dogtag_id(inventory, dogtag_id, "inventory")
                        found_dogtags.extend(found)
                    
                    # Search in statistics
                    if 'statistics' in user_data:
                        statistics = user_data['statistics']
                        found = _deep_search_dogtag_id(statistics, dogtag_id, "statistics")
                        found_dogtags.extend(found)
                    
                    # Search in progress
                    if 'progress' in user_data:
                        progress = user_data['progress']
                        found = _deep_search_dogtag_id(progress, dogtag_id, "progress")
                        found_dogtags.extend(found)
                
            except Exception as e:
                print(f"⚠️ Error parsing dogtag search data: {e}")
        
        return found_dogtags
        
    except Exception as e:
        print(f"⚠️ Error searching for dogtag ID: {e}")
        return []

def _deep_search_dogtag_id(data, dogtag_id: str, section_name: str):
    """Deep search for dogtag ID in any data structure."""
    
    import json
    found = []
    dogtag_id_lower = dogtag_id.lower()
    
    def recursive_search(obj, path=""):
        if isinstance(obj, dict):
            for key, value in obj.items():
                current_path = f"{path}.{key}" if path else key
                
                # Check both key and value for dogtag ID
                if dogtag_id_lower in str(key).lower() or dogtag_id_lower in str(value).lower():
                    found.append({
                        'location': f"{section_name}.{current_path}",
                        'id_match': key if dogtag_id_lower in str(key).lower() else value,
                        'context': json.dumps({key: value}, indent=2) if isinstance(value, (dict, list)) else str(value),
                        'type': type(value).__name__,
                        'data': value if isinstance(value, dict) else None
                    })
                
                # Continue recursive search
                if isinstance(value, (dict, list)):
                    recursive_search(value, current_path)
        
        elif isinstance(obj, list):
            for i, item in enumerate(obj):
                current_path = f"{path}[{i}]"
                
                if dogtag_id_lower in str(item).lower():
                    found.append({
                        'location': f"{section_name}.{current_path}",
                        'id_match': item,
                        'context': json.dumps(item, indent=2) if isinstance(item, (dict, list)) else str(item),
                        'type': type(item).__name__,
                        'data': item if isinstance(item, dict) else None
                    })
                
                if isinstance(item, (dict, list)):
                    recursive_search(item, current_path)
    
    recursive_search(data)
    return found

def get_user_dogtag_collection(username: str = None, password: str = None) -> list:
    """
    Get all dogtags/achievements the user has collected.
    
    Args:
        username: MC5 username/credential (optional, uses default if None)
        password: MC5 password (optional, uses default if None)
    
    Returns:
        List of all dogtag-related items found in user data
        
    Example:
        collection = get_user_dogtag_collection()
        print(f"User has {len(collection)} dogtag-related items")
    """
    import json
    
    # Use default credentials if not provided
    if not username or not password:
        username = "anonymous:d2luOF92M18xNzcwMDUxNjkwXy7H33aeTVB4YZictyDq48c="
        password = "sSJKzhQ5l4vrFgov"
    
    try:
        adapter = get_adapter()
        
        params = {
            'op_code': 'get_batch_profiles',
            'client_id': '1875:55979:6.0.0a:windows:windows',
            'credentials': username,
            'pandora': 'https://vgold-eur.gameloft.com/1875:55979:6.0.0a:windows:windows',
            'include_fields': '_game_save,inventory,statistics,progress,achievements'
        }
        
        success, result = adapter.execute('get_batch_profiles', **params)
        
        if success:
            try:
                data = json.loads(result) if isinstance(result, str) else result
                
                if username in data:
                    user_data = data[username]
                    all_dogtags = []
                    
                    # Look for dogtag-related fields
                    if '_game_save' in user_data:
                        game_save = user_data['_game_save']
                        
                        # Common dogtag field names
                        dogtag_fields = ['dogtags', 'achievements', 'awards', 'medals', 'badges', 'trophies', 'rewards', 'unlocks']
                        
                        for field in dogtag_fields:
                            if field in game_save:
                                field_data = game_save[field]
                                if isinstance(field_data, list):
                                    all_dogtags.extend(field_data)
                                elif isinstance(field_data, dict):
                                    all_dogtags.extend(list(field_data.values()))
                    
                    return all_dogtags
                
            except Exception as e:
                print(f"⚠️ Error parsing dogtag collection: {e}")
        
        return []
        
    except Exception as e:
        print(f"⚠️ Error getting dogtag collection: {e}")
        return []

def decode_unicode_name(unicode_str):
    """
    Decode Unicode escape sequences to proper characters.
    
    Handles Unicode names like "j\\u03c5\\u0432\\u04d9\\u03b9\\u044f" 
    and converts them to proper display: "jυвәιя"
    
    Args:
        unicode_str: String with Unicode escape sequences
        
    Returns:
        Properly decoded Unicode string
        
    Example:
        raw_name = "j\\u03c5\\u0432\\u04d9\\u03b9\\u044f"
        decoded = decode_unicode_name(raw_name)
        print(decoded)  # Output: jυвәιя
    """
    try:
        if isinstance(unicode_str, str):
            # Handle Unicode escape sequences like \u03c5
            return unicode_str.encode().decode('unicode_escape')
        return unicode_str
    except:
        return unicode_str

def validate_dogtag_id(dogtag_id: str) -> bool:
    """
    Validate dogtag ID format (4-8 characters).
    
    Args:
        dogtag_id: The dogtag ID to validate
        
    Returns:
        True if valid, False otherwise
        
    Example:
        validate_dogtag_id("f55f")     # True (4 chars)
        validate_dogtag_id("elite123") # True (8 chars)
        validate_dogtag_id("f")       # False (too short)
        validate_dogtag_id("toolong")  # False (too long)
    """
    import re
    
    if not dogtag_id:
        return False
    
    # Remove any whitespace and convert to lowercase
    dogtag_id = dogtag_id.strip().lower()
    
    # Check length: 4-8 characters
    if len(dogtag_id) < 4 or len(dogtag_id) > 8:
        return False
    
    # Check for valid characters (alphanumeric only)
    if not re.match(r'^[a-z0-9]+$', dogtag_id):
        return False
    
    return True

def format_time_combined(seconds_sp: int, seconds_mp: int) -> str:
    """
    Format combined time from SP and MP into human-readable format.
    
    Args:
        seconds_sp: Single player time in seconds
        seconds_mp: Multiplayer time in seconds
        
    Returns:
        Formatted time string (e.g., "303h 13min 55s")
        
    Example:
        format_time_combined(3600, 1800)  # "1h 30min 0s"
        format_time_combined(0, 0)       # "0s"
    """
    total_seconds = seconds_sp + seconds_mp
    
    if total_seconds == 0:
        return "0s"
    
    hours = total_seconds // 3600
    minutes = (total_seconds % 3600) // 60
    seconds = total_seconds % 60
    
    parts = []
    if hours > 0:
        parts.append(f"{hours}h")
    if minutes > 0:
        parts.append(f"{minutes}min")
    if seconds > 0 or not parts:  # Show seconds if it's the only unit
        parts.append(f"{seconds}s")
    
    return " ".join(parts)

def find_player(raw: bool = False, dogtag_id: str = None, username: str = None, password: str = None, time_display: str = "combined"):
    """
    Find player and display information in organized format.
    
    Args:
        raw: If True, show full raw JSON response
        dogtag_id: Dogtag ID to search for (4-8 characters, lowercase)
        username: MC5 username/credential (optional, uses default if None)
        password: MC5 password (optional, uses default if None)
        time_display: Time display option - "sp", "mp", "combined", or "none" (default: "combined")
    
    Returns:
        Dictionary with player information organized in proper display order
        
    Example:
        # Basic player search
        result = find_player()
        
        # Search with dogtag
        result = find_player(dogtag_id="f55f")
        
        # Show only SP time
        result = find_player(time_display="sp")
        
        # Show only MP time
        result = find_player(time_display="mp")
        
        # Show combined time (default)
        result = find_player(time_display="combined")
        
        # Show no time
        result = find_player(time_display="none")
        
        # Show full raw response
        result = find_player(raw=True)
        
        # Search dogtag with raw response
        result = find_player(raw=True, dogtag_id="f55f")
    """
    import json
    
    # Use default credentials if not provided
    if not username or not password:
        username = "anonymous:d2luOF92M18xNzcwMDUxNjkwXy7H33aeTVB4YZictyDq48c="
        password = "sSJKzhQ5l4vrFgov"
    
    try:
        # Use future-proof adapter
        adapter = get_adapter()
        
        params = {
            'op_code': 'get_batch_profiles',
            'client_id': '1875:55979:6.0.0a:windows:windows',
            'credentials': username,
            'pandora': 'https://vgold-eur.gameloft.com/1875:55979:6.0.0a:windows:windows',
            'include_fields': '_game_save,inventory,statistics,progress,achievements'
        }
        
        success, result = adapter.execute('get_batch_profiles', **params)
        
        if not success:
            return {
                'success': False,
                'error': result,
                'raw_response': None if not raw else result
            }
        
        # Parse the response
        data = json.loads(result) if isinstance(result, str) else result
        
        if username not in data:
            return {
                'success': False,
                'error': 'User data not found',
                'raw_response': None if not raw else result
            }
        
        user_data = data[username]
        game_save = user_data.get('_game_save', {})
        
        # Get statistics for time calculation
        stats = user_data.get('statistics', {})
        mp_stats = stats.get('mp', {})
        sp_stats = stats.get('sp', {})
        
        # Calculate time based on display option
        mp_time = mp_stats.get('time.played', 0)
        sp_time = sp_stats.get('time.played', 0)
        
        # Determine time display based on option
        if time_display == "sp":
            time_display_value = format_time_combined(sp_time, 0)
        elif time_display == "mp":
            time_display_value = format_time_combined(0, mp_time)
        elif time_display == "combined":
            time_display_value = format_time_combined(sp_time, mp_time)
        elif time_display == "none":
            time_display_value = None
        else:
            # Default to combined if invalid option
            time_display_value = format_time_combined(sp_time, mp_time)
        
        # Extract player info in proper display order
        player_info = {
            # First priority: display_name, private_profile, country, alias, vip_points, xp
            'display_name': decode_unicode_name(game_save.get('osiris_info', {}).get('display_name', 'Unknown')),
            'private_profile': user_data.get('private_profile', False),
            'country': user_data.get('country', 'Unknown'),
            'alias': user_data.get('alias', 'Unknown'),
            'vip_points': user_data.get('inventory', {}).get('vip_points', 0),
            'xp': user_data.get('inventory', {}).get('xp', 0),
            'time_played': time_display_value,  # Updated: Flexible time display
            'time_display_option': time_display,  # NEW: Track which option was used
            
            # Second priority: fed_id, rating_duel_last, rating, rating_duel, rating_last
            'fed_id': username,
            'rating_duel_last': game_save.get('rating_duel_last', 0),
            'rating': game_save.get('rating', 0),
            'rating_duel': game_save.get('rating_duel', 0),
            'rating_last': game_save.get('rating_last', 0),
            
            # Third priority: osiris_info (clan/squad information)
            'clan_info': {
                'clan_name': game_save.get('osiris_info', {}).get('clan_name', 'No clan'),
                'clan_id': game_save.get('osiris_info', {}).get('clan_id', 'None'),
                'clan_logo': game_save.get('osiris_info', {}).get('clan_logo', 0),
                'clan_member': game_save.get('osiris_info', {}).get('clan_member', 0),
                'clan_logo_clr_prim': game_save.get('osiris_info', {}).get('clan_logo_clr_prim', 0),
                'clan_logo_clr_sec': game_save.get('osiris_info', {}).get('clan_logo_clr_sec', 0),
                'display_name': decode_unicode_name(game_save.get('osiris_info', {}).get('display_name', 'Unknown'))
            },
            
            # Fourth priority: statistics (mp first, then sp)
            'statistics': {
                'mp': mp_stats,
                'sp': sp_stats,
                'time_breakdown': {  # Enhanced: All time formats
                    'mp_time_seconds': mp_time,
                    'sp_time_seconds': sp_time,
                    'mp_time_formatted': format_time_combined(0, mp_time),
                    'sp_time_formatted': format_time_combined(sp_time, 0),
                    'combined_time': format_time_combined(sp_time, mp_time),
                    'current_display': time_display_value,
                    'display_option': time_display
                }
            }
        }
        
        # Dogtag search results
        dogtag_results = []
        if dogtag_id:
            # Validate dogtag ID
            if not validate_dogtag_id(dogtag_id):
                return {
                    'success': False,
                    'error': f'Invalid dogtag ID: "{dogtag_id}". Must be 4-8 alphanumeric characters.',
                    'raw_response': None if not raw else result
                }
            
            # Search for the dogtag
            dogtag_results = search_dogtag_by_id(dogtag_id, username, password)
        
        # Get user's dogtag collection
        dogtag_collection = get_user_dogtag_collection(username, password)
        
        return {
            'success': True,
            'player_info': player_info,
            'dogtag_search': {
                'searched_id': dogtag_id,
                'results': dogtag_results,
                'collection_size': len(dogtag_collection)
            },
            'raw_response': result if raw else None,
            'data_summary': {
                'has_game_save': '_game_save' in user_data,
                'has_inventory': 'inventory' in user_data,
                'has_statistics': 'statistics' in user_data,
                'has_progress': 'progress' in user_data,
                'total_progress_items': len(user_data.get('progress', [])),
                'total_weapons': len(user_data.get('inventory', {}).get('weapons', {}))
            }
        }
        
    except Exception as e:
        return {
            'success': False,
            'error': str(e),
            'raw_response': None if not raw else result
        }

def search_dogtag_by_name(dogtag_name: str, username: str = None, password: str = None) -> list:
    """
    Search for dogtags by name (more flexible than ID search).
    
    Args:
        dogtag_name: The dogtag name to search for
        username: MC5 username/credential (optional, uses default if None)
        password: MC5 password (optional, uses default if None)
    
    Returns:
        List of found dogtag information
        
    Example:
        results = search_dogtag_by_name("Elite Warrior")
        for result in results:
            print(f"Found: {result['location']}")
    """
    # Use default credentials if not provided
    if not username or not password:
        username = "anonymous:d2luOF92M18xNzcwMDUxNjkwXy7H33aeTVB4YZictyDq48c="
        password = "sSJKzhQ5l4vrFgov"
    
    # Get user's dogtag collection and search by name
    collection = get_user_dogtag_collection(username, password)
    found = []
    dogtag_name_lower = dogtag_name.lower()
    
    for item in collection:
        if isinstance(item, dict):
            # Check various name fields
            name_fields = ['name', 'title', 'display_name', 'id', 'code']
            for field in name_fields:
                if field in item and dogtag_name_lower in str(item[field]).lower():
                    found.append({
                        'location': 'dogtag_collection',
                        'id_match': item[field],
                        'context': str(item),
                        'type': 'dogtag',
                        'data': item
                    })
                    break
        elif isinstance(item, str) and dogtag_name_lower in item.lower():
            found.append({
                'location': 'dogtag_collection',
                'id_match': item,
                'context': item,
                'type': 'dogtag_string',
                'data': item
            })
    
    return found

def get_all_services() -> Dict[str, str]:
    """
    Get all available service endpoints.
    
    Returns:
        Dictionary mapping service names to endpoints
    """
    services = [
        "leaderboard", "matchmaker", "auth", "social", 
        "alert", "message", "lobby", "gs", "sp"
    ]
    
    service_endpoints = {}
    
    for service in services:
        endpoint = locate_service(service)
        if endpoint:
            service_endpoints[service] = endpoint
    
    return service_endpoints

def generate_encrypted_token(
    username: str,
    password: str,
    device_id: Optional[str] = None,
    scope: str = "alert auth chat leaderboard_ro lobby message session social config storage_ro tracking_bi feed storage leaderboard_admin social_eve social soc transaction schedule lottery voice matchmaker",
    nonce: str = "*"
) -> Dict[str, Any]:
    """
    Generate and encrypt an access token.
    
    Args:
        username: MC5 username
        password: Account password
        device_id: Device ID (generated if not provided)
        scope: Permission scopes
        nonce: Nonce value for encryption
        
    Returns:
        Dictionary containing encrypted token information
    """
    token_gen = TokenGenerator()
    try:
        result = token_gen.generate_encrypted_token(username, password, device_id, scope, nonce)
        return result
    finally:
        token_gen.close()

def encrypt_token(
    access_token: str,
    nonce: str = "*"
) -> str:
    """
    Encrypt an existing access token.
    
    Args:
        access_token: Raw access token string
        nonce: Nonce value for encryption
        
    Returns:
        Encrypted token string
    """
    token_gen = TokenGenerator()
    try:
        result = token_gen.encrypt_token(access_token, nonce)
        return result
    finally:
        token_gen.close()

__all__ = [
    "MC5Client",
    "MC5ApiClient",
    "SimpleMC5Client",
    "AdminMC5Client",
    "batch_search_players",
    "clan_cleanup",
    "monitor_clan_activity",
    "quick_search",
    "quick_kick",
    "quick_remove_friend",
    "quick_send_friend_request",
    "quick_check_friend_status",
    "quick_accept_friend_request",
    "quick_sign_up_for_event",
    "quick_get_event_leaderboard",
    "quick_get_my_event_rank",
    "quick_get_squad_invitations",
    "quick_accept_squad_invitation",
    "quick_decline_squad_invitation",
    "quick_get_my_sessions",
    "quick_get_session_statistics",
    "quick_check_session_status",
    "quick_get_server_type_sessions",
    "quick_analyze_session_activity",
    "quick_start_alert_stream",
    "quick_test_alert_connection",
    "quick_start_alerts_with_discord",
    "quick_monitor_alerts",
    "create_alert_callback",
    "quick_get_account_info",
    "quick_get_device_history",
    "quick_get_credential_summary",
    "quick_analyze_account_security",
    "quick_get_account_overview",
    "quick_export_account_data",
    "quick_generate_transfer_code",
    "quick_check_transfer_status",
    "quick_get_device_linking_guide",
    "quick_link_device_workflow",
    "quick_validate_transfer_code",
    "quick_force_new_code",
    "quick_transfer_status_summary",
    "telemetry",
    "report_error",
    "report_usage",
    "is_telemetry_enabled",
    "debug_mode",
    "debug_print",
    "debug_function",
    "analyze_error",
    "print_error_analysis",
    "create_admin_client",
    "create_user_client",
    "quick_add_squad_rating",
    "quick_update_player_score",
    "TokenGenerator", 
    "MC5APIError",
    "AuthenticationError",
    "RateLimitError",
    "help",
    "examples",
    "quick_reference",
    "generate_encrypted_token",
    "encrypt_token",
    "MC5Easy",
    "quick_connect",
    "check_my_daily_tasks",
    "get_server_status",
    "get_online_players", 
    "get_server_info",
    "get_my_squad_id",
    "get_my_squad_info",
    "update_my_squad_info",
    "get_my_squad_members",
    "calculate_xp_for_level",
    "get_color_value",
    "customize_squad_theme",
    "set_squad_level",
    "customize_squad_complete",
    "quick_set_name",
    "quick_set_rating",
    "quick_set_member_limit",
    "quick_set_colors",
    "quick_set_level",
    "quick_set_currency",
    "quick_setup_professional_squad",
    "quick_setup_gaming_squad",
    "quick_reset_to_defaults",
    "generate_device_id",
    "create_federation_session",
    "locate_service",
    "get_all_services",
    "search_dogtag_by_id",
    "get_user_dogtag_collection",
    "search_dogtag_by_name",
    "decode_unicode_name",
    "validate_dogtag_id",
    "find_player",
    "format_time_combined",
    "MC5ChatClient",
    "send_chat_message",
    "listen_to_chat",
    # Ultra-Simple Chat Functions
    "send", "quick", "en", "fr", "de", "es", "it", "pt", "ru", "ja", "ko", "zh",
    "nl", "sv", "no", "da", "fi", "pl", "cs", "hu", "ro", "bg", "hr", "sk", "si", "et", "lv", "lt", "el", "tr",
    "ar", "he", "hi", "th", "id", "bn", "ur", "fa", "uk", "be", "kk", "uz", "az", "ka", "am", "sw", "zu", "af", "is_", "mt", "cy", "ga", "gd", "eu", "ca",
    "spam", "spam_en", "spam_fr", "rapid_spam", "subtle_spam",
    "pro", "casual", "squad", "elite", "stealth",
    "check_inbox", "my_messages", "check_spam",
    "impersonate", "become_player", "anonymous_spy",
    "listen", "listen_en", "listen_all",
    "set_name", "set_signature", "set_language", "test_connection", "get_server",
    # Comprehensive Customization
    "set_killsign", "set_killsign_color", "set_killsign_name", "set_nickname", "set_country", "set_chat_country",
    # Kill Sign Presets
    "killsign_pro", "killsign_casual", "killsign_squad", "killsign_elite", "killsign_stealth",
    "killsign_gold", "killsign_diamond", "killsign_fire", "killsign_ice", "killsign_shadow",
    # Color Presets
    "color_red", "color_green", "color_blue", "color_yellow", "color_purple", "color_orange",
    "color_pink", "color_cyan", "color_white", "color_black", "color_gray",
    # Country/Language Selection (53)
    "country_en", "country_fr", "country_de", "country_es", "country_it", "country_pt", "country_ru", "country_ja", "country_ko", "country_zh",
    "country_nl", "country_sv", "country_no", "country_da", "country_fi", "country_pl", "country_cs", "country_hu", "country_ro", "country_bg", "country_hr", "country_sk", "country_si", "country_et", "country_lv", "country_lt", "country_el", "country_tr",
    "country_ar", "country_he", "country_hi", "country_th", "country_id", "country_bn", "country_ur", "country_fa", "country_uk", "country_be", "country_kk", "country_uz", "country_az", "country_ka", "country_am", "country_sw", "country_zu", "country_af", "country_is", "country_mt", "country_cy", "country_ga", "country_gd", "country_eu", "country_ca",
    # Combined Setup Functions
    "setup_player", "setup_pro_player", "setup_casual_player", "setup_squad_player", "setup_elite_player", "setup_stealth_player",
    # Quick Configuration Chains
    "configure", "with_name", "with_killsign", "with_country",
    # Profile Templates
    "profile_pro_gamer", "profile_casual_gamer", "profile_squad_leader", "profile_elite_warrior", "profile_stealth_ninja",
    "profile_gold_player", "profile_diamond_master", "profile_fire_warrior", "profile_ice_queen", "profile_shadow_assassin",
    "send_to_all", "batch_spam",
    "hello", "goodbye", "test", "ping", "thanks",
    # Room and Matchmaking API
    "MC5RoomAPI", "find_duel_rooms", "find_team_battle_rooms", "find_custom_rooms",
    "quick_duel_match", "quick_team_battle",
    # Enhanced Utilities
    "MC5EnhancedAPI", "get_server_stats", "find_best_game_rooms", "search_players",
    "get_room_recommendations", "monitor_rooms_live", "generate_server_report",
    "auto_join_best_room", "analyze_player_activity",
    # Advanced Chat Utilities
    "AdvancedChatManager", "chat_manager", "create_template", "use_template",
    "broadcast", "schedule_chat", "get_chat_stats", "chat_report",
    "announce_to_all", "announce_to_europe", "announce_to_asia",
    "setup_smart_replies", "auto_greet", "monitor_chat_health",
    # Game Analytics
    "MC5GameAnalytics", "get_player_analytics", "get_game_mode_rankings",
    "check_server_health", "track_player", "generate_analytics_report",
    "start_real_time_monitoring", "calculate_player_skill_distribution",
    # MP Invite System
    "MC5MPInviteSystem", "create_team_battle_invite", "create_ctf_invite",
    "create_zone_control_invite", "create_vip_invite", "create_duel_invite",
    "send_global_invite", "send_squad_invite", "quick_team_battle_streets",
    "quick_ctf_rooftops", "quick_vip_rooftops", "quick_duel_showdown",
    "quick_zone_control_canals", "list_game_modes", "list_maps", "show_invite_example",
    # Event System
    "MC5EventSystem", "register_event", "get_event_leaderboard", "get_my_event_rank",
    "show_event_leaderboard", "show_my_event_status", "register_current_event",
    "show_current_event_leaderboard", "show_my_current_event_status",
    # Matchmaking System
    "MC5MatchmakingSystem", "quick_play", "find_game", "get_room_info", "show_room_details",
    "quick_battle", "quick_event_battle", "quick_team_battle", "quick_ctf", "current_event_quick_play",
    # Leaderboard System
    "MC5LeaderboardSystem", "get_leaderboard", "get_my_rank", "show_leaderboard",
    "show_my_rank_context", "analyze_leaderboard", "get_current_event_leaderboard",
    "show_current_event_leaderboard", "get_my_current_event_rank", "show_my_current_event_context",
    "analyze_current_event", "update_leaderboard_score", "update_my_score",
    "update_current_event_score", "update_my_current_event_score",
    # Squad System
    "SquadSystem", "get_my_squad_info", "get_squad_leaderboard", "analyze_squad_performance",
    "show_squad_dashboard", "get_top_squads", "compare_squads", "get_squad_recommendations",
    "search_squads_by_name", "show_squad_recommendations", "search_and_analyze_squads",
    "analyze_recommended_squads"
]
