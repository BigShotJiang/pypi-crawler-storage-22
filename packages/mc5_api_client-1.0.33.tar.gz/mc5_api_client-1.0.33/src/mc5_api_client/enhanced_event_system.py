#!/usr/bin/env python3
# ────────────[ KAKUZU ]────────────────────────────
# | Discord  : kakuzu_f0
# | Telegram : kakuzu_f0
# | File     | enhanced_event_system.py
# | License  : MIT License © 2026 Kakuzu
# | Brief    | Enhanced event system with progress tracking
# ────────────────★─────────────────────────────────

"""
Enhanced Event System with Progress Tracking

This module provides comprehensive event functionality including:
- Event registration and status tracking
- Real-time progress monitoring
- Event matchmaking integration
- Performance analytics and recommendations
- Score progression tracking
"""

import requests
import json
import time
from typing import Dict, Optional, List
from datetime import datetime, timedelta

from .ultra_simple_chat import _get_chat


class EnhancedEventSystem:
    """Enhanced MC5 Event System with Progress Tracking"""
    
    def __init__(self):
        """Initialize Enhanced Event System"""
        self.chat = _get_chat()
        self.osiris_url = "https://eur-osiris.gameloft.com"
        self.olympus_url = "https://eur-olympus.gameloft.com"
        self.anubis_url = "https://eur-anubisfinder.gameloft.com"
        self.current_event_id = "0c646c6a-e61c-11f0-be58-b8ca3a634708"
        
    def register_for_event(self, event_id: str = None) -> bool:
        """
        Register for an event
        
        Args:
            event_id: Event ID (uses current event if None)
            
        Returns:
            True if successful, False otherwise
        """
        try:
            event_id = event_id or self.current_event_id
            url = f"{self.osiris_url}/events/{event_id}/participants/me"
            
            # Get access token and credentials
            access_token = getattr(self.chat, 'access_token', 'unknown')
            credential = getattr(self.chat, 'credential', 'unknown')
            
            # Prepare data
            data = {
                'access_token': access_token
            }
            
            print(f"📝 Registering for event: {event_id}")
            
            response = requests.post(url, data=data, timeout=15)
            
            if response.status_code == 200:
                result = response.json()
                print("✅ Successfully registered for event!")
                return True
            else:
                print(f"❌ Failed to register: {response.status_code}")
                print(f"📝 Response: {response.text}")
                return False
                
        except Exception as e:
            print(f"❌ Error registering for event: {e}")
            return False
    
    def get_event_leaderboard(self, event_id: str = None, offset: int = 0, limit: int = 100) -> Optional[Dict]:
        """
        Get event leaderboard data
        
        Args:
            event_id: Event ID (uses current event if None)
            offset: Offset for pagination
            limit: Number of entries to retrieve
            
        Returns:
            Leaderboard data or None if failed
        """
        try:
            event_id = event_id or self.current_event_id
            leaderboard_id = f"Leaderboard_{event_id}"
            url = f"{self.olympus_url}/leaderboards/desc/{leaderboard_id}"
            
            # Get access token
            access_token = getattr(self.chat, 'access_token', 'unknown')
            
            # Prepare parameters
            params = {
                'access_token': access_token,
                'offset': str(offset),
                'limit': str(limit)
            }
            
            response = requests.get(url, params=params, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                print(f"📊 Retrieved leaderboard: {data.get('total_entries', 0)} total entries")
                return data
            else:
                print(f"❌ Failed to get leaderboard: {response.status_code}")
                return None
                
        except Exception as e:
            print(f"❌ Error getting leaderboard: {e}")
            return None
    
    def get_my_event_status(self, event_id: str = None) -> Optional[Dict]:
        """
        Get your current event status
        
        Args:
            event_id: Event ID (uses current event if None)
            
        Returns:
            Your event status or None if failed
        """
        try:
            event_id = event_id or self.current_event_id
            leaderboard_id = f"Leaderboard_{event_id}"
            url = f"{self.olympus_url}/leaderboards/desc/{leaderboard_id}/me"
            
            # Get access token
            access_token = getattr(self.chat, 'access_token', 'unknown')
            
            # Prepare parameters
            params = {
                'access_token': access_token,
                'limit': '5'
            }
            
            response = requests.get(url, params=params, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                my_entry = data.get('my_entry')
                if my_entry:
                    return data
                else:
                    print("❌ You are not on the event leaderboard")
                    return None
            else:
                print(f"❌ Failed to get your status: {response.status_code}")
                return None
                
        except Exception as e:
            print(f"❌ Error getting your status: {e}")
            return None
    
    def find_event_game(self, score: int = 1844) -> Optional[Dict]:
        """
        Find an event game using matchmaking
        
        Args:
            score: Your matchmaking score
            
        Returns:
            Room information or None if failed
        """
        try:
            url = f"{self.anubis_url}/rooms/{self.chat.client_id}/automatch/quickplayany"
            
            # Get access token and credentials
            access_token = getattr(self.chat, 'access_token', 'unknown')
            credential = getattr(self.chat, 'credential', 'unknown')
            nickname = getattr(self.chat, 'nickname', 'Player')
            
            # Ensure nickname is a string
            if callable(nickname):
                nickname = nickname()
            elif not isinstance(nickname, str):
                nickname = str(nickname)
            
            # Build filter for event
            filter_parts = [
                "_game_mode=battle",
                "_joinable=true",
                "capacity=12",
                f"_event_id={self.current_event_id}",
                "_event_league=x",
                "_PIN=x",
                "_customs_room=false",
                "_betAmount=0",
                "_veteran=false",
                "_automatch_name=quickplayany"
            ]
            
            filter_str = "&".join(filter_parts)
            
            # Prepare data
            data = {
                'access_token': access_token,
                'filter': filter_str,
                'user': json.dumps({"name": nickname}),
                'score': str(score),
                'server_type': 'mp_server'
            }
            
            print(f"🎮 Finding event game with score {score}...")
            
            response = requests.post(url, data=data, timeout=15)
            
            if response.status_code == 200:
                room_data = response.json()
                print(f"✅ Found event game! Room ID: {room_data.get('id')}")
                print(f"👥 Players: {room_data.get('member_count', 0)}/{room_data.get('capacity', 12)}")
                print(f"🎯 Game Mode: {room_data.get('_game_mode', 'battle')}")
                return room_data
            else:
                print(f"❌ Failed to find game: {response.status_code}")
                return None
                
        except Exception as e:
            print(f"❌ Error finding event game: {e}")
            return None
    
    def track_score_progression(self, event_id: str = None, check_interval: int = 30) -> None:
        """
        Track score progression over time
        
        Args:
            event_id: Event ID (uses current event if None)
            check_interval: Seconds between checks
        """
        event_id = event_id or self.current_event_id
        print(f"📈 Tracking score progression for event: {event_id}")
        print(f"⏱️ Checking every {check_interval} seconds...")
        print("🛑 Press Ctrl+C to stop tracking")
        
        scores = []
        timestamps = []
        
        try:
            while True:
                # Get current status
                status = self.get_my_event_status(event_id)
                
                if status and status.get('my_entry'):
                    current_score = status['my_entry'].get('score', 0)
                    current_rank = status['my_entry'].get('rank', 0)
                    current_time = datetime.now()
                    
                    scores.append(current_score)
                    timestamps.append(current_time)
                    
                    print(f"📊 {current_time.strftime('%H:%M:%S')} - Score: {current_score} | Rank: #{current_rank}")
                    
                    # Show progression
                    if len(scores) > 1:
                        score_change = current_score - scores[-2]
                        if score_change > 0:
                            print(f"   📈 +{score_change} points since last check")
                        elif score_change < 0:
                            print(f"   📉 {score_change} points since last check")
                        else:
                            print(f"   ➡️ No change")
                    
                    # Show total progression
                    if len(scores) > 1:
                        total_change = current_score - scores[0]
                        time_elapsed = (current_time - timestamps[0]).total_seconds() / 60
                        rate = total_change / time_elapsed if time_elapsed > 0 else 0
                        
                        print(f"   📊 Total: +{total_change} in {time_elapsed:.1f} min ({rate:.1f} pts/min)")
                    
                    print("-" * 50)
                
                time.sleep(check_interval)
                
        except KeyboardInterrupt:
            print("\n🛑 Tracking stopped by user")
            
            # Show summary
            if scores:
                print(f"\n📊 Progression Summary:")
                print(f"   📈 Starting Score: {scores[0]}")
                print(f"   📈 Ending Score: {scores[-1]}")
                print(f"   📈 Total Change: {scores[-1] - scores[0]}")
                print(f"   ⏱️ Duration: {(timestamps[-1] - timestamps[0]).total_seconds() / 60:.1f} minutes")
                
                if len(scores) > 1:
                    avg_rate = (scores[-1] - scores[0]) / ((timestamps[-1] - timestamps[0]).total_seconds() / 60)
                    print(f"   📈 Average Rate: {avg_rate:.1f} points/minute")
    
    def analyze_event_performance(self, event_id: str = None) -> Dict:
        """
        Analyze your event performance
        
        Args:
            event_id: Event ID (uses current event if None)
            
        Returns:
            Performance analysis
        """
        try:
            event_id = event_id or self.current_event_id
            
            # Get leaderboard data
            leaderboard = self.get_event_leaderboard(event_id, limit=100)
            
            if not leaderboard:
                return {}
            
            # Get your status
            my_status = self.get_my_event_status(event_id)
            
            if not my_status:
                return {}
            
            my_entry = my_status.get('my_entry')
            if not my_entry:
                return {}
            
            # Calculate statistics
            total_entries = leaderboard.get('total_entries', 0)
            my_score = my_entry.get('score', 0)
            my_rank = my_entry.get('rank', 0)
            my_xp = my_entry.get('_xp', 0)
            
            # Get top performers
            top_entries = leaderboard.get('data', [])[:10]
            top_scores = [entry.get('score', 0) for entry in top_entries]
            
            # Calculate percentiles
            percentile = ((total_entries - my_rank) / total_entries) * 100 if total_entries > 0 else 0
            
            analysis = {
                'my_performance': {
                    'score': my_score,
                    'rank': my_rank,
                    'percentile': percentile,
                    'xp': my_xp,
                    'clan': my_entry.get('_clan_name', 'None')
                },
                'event_stats': {
                    'total_participants': total_entries,
                    'top_score': top_scores[0] if top_scores else 0,
                    'top_10_average': sum(top_scores) / len(top_scores) if top_scores else 0,
                    'median_score': self._calculate_median_score(leaderboard)
                },
                'recommendations': self._generate_recommendations(my_score, my_rank, percentile, top_scores)
            }
            
            return analysis
            
        except Exception as e:
            print(f"❌ Error analyzing performance: {e}")
            return {}
    
    def _calculate_median_score(self, leaderboard: Dict) -> float:
        """Calculate median score from leaderboard"""
        try:
            entries = leaderboard.get('data', [])
            if not entries:
                return 0.0
            
            scores = [entry.get('score', 0) for entry in entries]
            scores.sort()
            
            n = len(scores)
            if n == 0:
                return 0.0
            elif n % 2 == 1:
                return scores[n // 2]
            else:
                return (scores[n // 2 - 1] + scores[n // 2]) / 2
                
        except Exception:
            return 0.0
    
    def _generate_recommendations(self, my_score: float, my_rank: int, percentile: float, top_scores: List[float]) -> List[str]:
        """Generate performance recommendations"""
        recommendations = []
        
        if my_score == 0:
            recommendations.append("🎯 Start playing event games to earn points")
            recommendations.append("🎮 Use matchmaking to find event games quickly")
        elif my_score < 100:
            recommendations.append("📈 Keep playing! You're just getting started")
            recommendations.append("🎯 Focus on consistent gameplay to build momentum")
        elif my_score < 1000:
            recommendations.append("🚀 Good progress! Try to play more frequently")
            recommendations.append("📊 Aim for 1000+ points to reach the top 50%")
        elif my_score < 5000:
            recommendations.append("🔥 Great performance! You're in the top half")
            recommendations.append("🏆 Push for 5000+ points to reach elite status")
        else:
            recommendations.append("👑 Elite performance! You're in the top tier")
            recommendations.append("🎯 Maintain your position with consistent play")
        
        if percentile < 25:
            recommendations.append("📊 You're in the top 25% - excellent work!")
        elif percentile < 50:
            recommendations.append("📈 You're above average - keep pushing!")
        else:
            recommendations.append("🎯 Room for improvement - play more to climb the ranks")
        
        return recommendations
    
    def show_comprehensive_status(self, event_id: str = None) -> None:
        """
        Show comprehensive event status
        
        Args:
            event_id: Event ID (uses current event if None)
        """
        try:
            event_id = event_id or self.current_event_id
            
            print(f"🏆 Event Status: {event_id}")
            print("=" * 50)
            
            # Get performance analysis
            analysis = self.analyze_event_performance(event_id)
            
            if not analysis:
                print("❌ Could not get event status")
                return
            
            my_perf = analysis['my_performance']
            event_stats = analysis['event_stats']
            recommendations = analysis['recommendations']
            
            # Show your performance
            print(f"👤 Your Performance:")
            print(f"   🏆 Score: {my_perf['score']}")
            print(f"   🥇 Rank: #{my_perf['rank']:,}")
            print(f"   📊 Percentile: {my_perf['percentile']:.1f}%")
            print(f"   ⭐ XP: {my_perf['xp']:,}")
            if my_perf['clan']:
                print(f"   🏰 Clan: {my_perf['clan']}")
            
            # Show event statistics
            print(f"\n📊 Event Statistics:")
            print(f"   👥 Total Participants: {event_stats['total_participants']:,}")
            print(f"   🏆 Top Score: {event_stats['top_score']:,}")
            print(f"   📈 Top 10 Average: {event_stats['top_10_average']:.1f}")
            print(f"   📊 Median Score: {event_stats['median_score']:.1f}")
            
            # Show recommendations
            print(f"\n💡 Recommendations:")
            for i, rec in enumerate(recommendations, 1):
                print(f"   {i}. {rec}")
            
        except Exception as e:
            print(f"❌ Error showing status: {e}")


# Convenience functions
def register_for_current_event_enhanced() -> bool:
    """Register for current event"""
    system = EnhancedEventSystem()
    return system.register_for_event()


def get_current_event_status_enhanced() -> Optional[Dict]:
    """Get current event status"""
    system = EnhancedEventSystem()
    return system.get_my_event_status()


def find_current_event_game(score: int = 1844) -> Optional[Dict]:
    """Find current event game"""
    system = EnhancedEventSystem()
    return system.find_event_game(score)


def track_event_progress_enhanced(check_interval: int = 30) -> None:
    """Track event score progression"""
    system = EnhancedEventSystem()
    system.track_score_progression(check_interval=check_interval)


def analyze_my_event_performance_enhanced() -> Dict:
    """Analyze your event performance"""
    system = EnhancedEventSystem()
    return system.analyze_event_performance()


def show_event_dashboard_enhanced() -> None:
    """Show comprehensive event dashboard"""
    system = EnhancedEventSystem()
    system.show_comprehensive_status()
