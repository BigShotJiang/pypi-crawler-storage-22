# ────────────[ KAKUZU ]────────────────────────────
# | Discord  : kakuzu_f0
# | Telegram : kakuzu_f0
# | File     : leaderboard_system.py
# | License  : MIT License © 2026 Kakuzu
# | Brief    : MC5 Leaderboard System for API Client
# ────────────────★─────────────────────────────────

"""
MC5 Leaderboard System

This module provides comprehensive leaderboard functionality for Modern Combat 5,
including event leaderboards, global leaderboards, and rank tracking.

Based on reverse-engineered API endpoints for MC5 leaderboards.
"""

import json
import requests
from typing import Dict, Optional, List
from datetime import datetime

from .ultra_simple_chat import _get_chat


class MC5LeaderboardSystem:
    """MC5 Leaderboard System - View and analyze leaderboards"""
    
    def __init__(self):
        """Initialize Leaderboard System"""
        self.chat = _get_chat()
        self.base_url = "https://eur-olympus.gameloft.com"
        
    def get_leaderboard(self, leaderboard_id: str, sort: str = "desc", 
                       offset: int = 0, limit: int = 100) -> Optional[Dict]:
        """
        Get leaderboard data
        
        Args:
            leaderboard_id: Leaderboard ID (e.g., 'Leaderboard_0c646c6a-e61c-11f0-be58-b8ca3a634708')
            sort: Sort order ('desc' for descending, 'asc' for ascending)
            offset: Offset for pagination
            limit: Number of entries to retrieve
            
        Returns:
            Leaderboard data or None if failed
        """
        try:
            url = f"{self.base_url}/leaderboards/{sort}/{leaderboard_id}"
            
            # Get access token and credentials
            access_token = getattr(self.chat, 'access_token', 'unknown')
            credential = getattr(self.chat, 'credential', 'unknown')
            
            # Prepare parameters
            params = {
                'access_token': access_token,
                'offset': str(offset),
                'limit': str(limit)
            }
            
            response = requests.get(url, params=params, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                print(f"📊 Retrieved leaderboard: {leaderboard_id}")
                print(f"👥 Total entries: {data.get('total_entries', 0)}")
                return data
            else:
                print(f"❌ Failed to get leaderboard: {response.status_code}")
                print(f"📝 Response: {response.text}")
                return None
                
        except Exception as e:
            print(f"❌ Error getting leaderboard: {e}")
            return None
    
    def get_my_rank(self, leaderboard_id: str, sort: str = "desc", 
                   limit: int = 5) -> Optional[Dict]:
        """
        Get your rank and nearby players
        
        Args:
            leaderboard_id: Leaderboard ID
            sort: Sort order
            limit: Number of nearby players to show
            
        Returns:
            Your rank and nearby players or None if failed
        """
        try:
            url = f"{self.base_url}/leaderboards/{sort}/{leaderboard_id}/me"
            
            # Get access token and credentials
            access_token = getattr(self.chat, 'access_token', 'unknown')
            credential = getattr(self.chat, 'credential', 'unknown')
            
            # Prepare parameters
            params = {
                'access_token': access_token,
                'limit': str(limit)
            }
            
            response = requests.get(url, params=params, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                my_entry = data.get('my_entry')
                if my_entry:
                    rank = my_entry.get('rank', 0)
                    score = my_entry.get('score', 0)
                    print(f"🏆 Your rank: #{rank} with {score} points")
                    return data
                else:
                    print("❌ You are not on this leaderboard")
                    return None
            else:
                print(f"❌ Failed to get your rank: {response.status_code}")
                print(f"📝 Response: {response.text}")
                return None
                
        except Exception as e:
            print(f"❌ Error getting your rank: {e}")
            return None
    
    def show_leaderboard(self, leaderboard_id: str, top_count: int = 10, 
                        show_clans: bool = True, show_xp: bool = False) -> None:
        """
        Display leaderboard in a formatted way
        
        Args:
            leaderboard_id: Leaderboard ID
            top_count: Number of top players to show
            show_clans: Whether to show clan information
            show_xp: Whether to show XP information
        """
        data = self.get_leaderboard(leaderboard_id, limit=top_count)
        
        if not data:
            return
        
        entries = data.get('data', [])
        total_entries = data.get('total_entries', 0)
        
        print(f"\n🏆 Leaderboard - Top {top_count} of {total_entries}")
        print("=" * 60)
        
        for i, entry in enumerate(entries[:top_count], 1):
            rank = entry.get('rank', i)
            name = entry.get('display_name', 'Unknown')
            score = entry.get('score', 0)
            clan = entry.get('_clan_name', '')
            xp = entry.get('_xp', 0)
            killsig = entry.get('_killsig_id', '')
            killsig_color = entry.get('_killsig_color', '')
            
            # Format rank with special styling for top 3
            rank_display = f"#{rank:2d}"
            if rank == 1:
                rank_display = "🥇"
            elif rank == 2:
                rank_display = "🥈"
            elif rank == 3:
                rank_display = "🥉"
            
            print(f"{rank_display} {name:<20} {score:>10.1f} pts")
            
            if show_clans and clan:
                print(f"     🏰 Clan: {clan}")
            
            if show_xp and xp:
                print(f"     ⭐ XP: {xp:,}")
            
            if killsig:
                print(f"     🎨 Kill Sign: {killsig}")
            
            print()
    
    def show_my_rank_context(self, leaderboard_id: str, nearby_count: int = 5) -> None:
        """
        Show your rank with nearby players for context
        
        Args:
            leaderboard_id: Leaderboard ID
            nearby_count: Number of nearby players to show
        """
        data = self.get_my_rank(leaderboard_id, limit=nearby_count)
        
        if not data:
            return
        
        my_entry = data.get('my_entry')
        nearby_entries = data.get('data', [])
        
        print(f"\n👤 Your Rank Context")
        print("=" * 40)
        
        if my_entry:
            rank = my_entry.get('rank', 0)
            score = my_entry.get('score', 0)
            name = my_entry.get('display_name', 'Unknown')
            clan = my_entry.get('_clan_name', '')
            xp = my_entry.get('_xp', 0)
            
            print(f"🏆 Your Rank: #{rank}")
            print(f"👤 Name: {name}")
            print(f"💯 Score: {score} points")
            
            if clan:
                print(f"🏰 Clan: {clan}")
            
            if xp:
                print(f"⭐ XP: {xp:,}")
            
            # Show nearby players
            if nearby_entries:
                print(f"\n📍 Nearby Players:")
                for entry in nearby_entries:
                    if entry.get('id') != my_entry.get('id'):
                        rank = entry.get('rank', 0)
                        name = entry.get('display_name', 'Unknown')
                        score = entry.get('score', 0)
                        clan = entry.get('_clan_name', '')
                        
                        # Show relative position
                        if rank < my_entry.get('rank', 0):
                            position = "▲"
                        else:
                            position = "▼"
                        
                        print(f"   {position} #{rank} {name}: {score} pts")
                        if clan:
                            print(f"      🏰 {clan}")
    
    def analyze_leaderboard(self, leaderboard_id: str, sample_size: int = 100) -> Dict:
        """
        Analyze leaderboard statistics
        
        Args:
            leaderboard_id: Leaderboard ID
            sample_size: Number of entries to analyze
            
        Returns:
            Analysis statistics
        """
        data = self.get_leaderboard(leaderboard_id, limit=sample_size)
        
        if not data:
            return {}
        
        entries = data.get('data', [])
        total_entries = data.get('total_entries', 0)
        
        if not entries:
            return {}
        
        # Calculate statistics
        scores = [entry.get('score', 0) for entry in entries]
        xp_values = [entry.get('_xp', 0) for entry in entries if entry.get('_xp')]
        
        stats = {
            'total_entries': total_entries,
            'sample_size': len(entries),
            'score_stats': {
                'min': min(scores),
                'max': max(scores),
                'avg': sum(scores) / len(scores),
                'median': sorted(scores)[len(scores) // 2]
            },
            'top_score': scores[0] if scores else 0,
            'clans': len(set(entry.get('_clan_name', '') for entry in entries if entry.get('_clan_name')))
        }
        
        if xp_values:
            stats['xp_stats'] = {
                'min': min(xp_values),
                'max': max(xp_values),
                'avg': sum(xp_values) / len(xp_values),
                'median': sorted(xp_values)[len(xp_values) // 2]
            }
        
        return stats
    
    def update_score(self, leaderboard_id: str, new_score: float) -> Optional[Dict]:
        """
        Update your score on a leaderboard
        
        Args:
            leaderboard_id: Leaderboard ID
            new_score: New score to set
            
        Returns:
            Response data or None if failed
        """
        try:
            url = f"{self.base_url}/leaderboards/{leaderboard_id}"
            
            # Get access token and credentials
            access_token = getattr(self.chat, 'access_token', 'unknown')
            credential = getattr(self.chat, 'credential', 'unknown')
            
            # Prepare headers
            headers = {
                'Accept': '*/*',
                'Accept-Encoding': 'identity',
                'Content-Type': 'application/json'
            }
            
            # Prepare data
            data = {
                'access_token': access_token,
                'credential': credential,
                'score': new_score,
                'sort': 'desc'
            }
            
            print(f"🎯 Updating score to {new_score} on leaderboard: {leaderboard_id}")
            
            response = requests.post(url, headers=headers, json=data, timeout=15)
            
            if response.status_code == 200:
                result = response.json()
                print(f"✅ Score updated successfully to {new_score}!")
                return result
            else:
                print(f"❌ Failed to update score: {response.status_code}")
                print(f"📝 Response: {response.text}")
                return None
                
        except Exception as e:
            print(f"❌ Error updating score: {e}")
            return None
    
    def get_and_update_score(self, leaderboard_id: str, new_score: float) -> bool:
        """
        Get current score and update it
        
        Args:
            leaderboard_id: Leaderboard ID
            new_score: New score to set
            
        Returns:
            True if successful, False otherwise
        """
        try:
            # Get current data
            current_data = self.get_my_rank(leaderboard_id)
            
            if current_data:
                my_entry = current_data.get('my_entry')
                if my_entry:
                    current_score = my_entry.get('score', 0)
                    display_name = my_entry.get('display_name', 'Unknown')
                    
                    print(f"📊 Current Status:")
                    print(f"   👤 Player: {display_name}")
                    print(f"   🏆 Current Score: {current_score}")
                    print(f"   🥇 Current Rank: #{my_entry.get('rank', 0)}")
                    
                    # Update the score
                    print(f"🎯 Updating score from {current_score} to {new_score}")
                    
                    update_result = self.update_score(leaderboard_id, new_score)
                    
                    if update_result:
                        # Verify the update
                        verification_data = self.get_my_rank(leaderboard_id)
                        if verification_data:
                            updated_entry = verification_data.get('my_entry')
                            if updated_entry:
                                updated_score = updated_entry.get('score', 0)
                                print(f"🏆 Updated Score: {updated_score}")
                                
                                if updated_score == new_score:
                                    print("🎉 SUCCESS! Score updated correctly!")
                                    return True
                                else:
                                    print("⚠️ Score may not have updated as expected")
                                    return False
                    else:
                        print("❌ Score update failed")
                        return False
            else:
                print("❌ Could not get current leaderboard data")
                return False
                
        except Exception as e:
            print(f"❌ Error in get_and_update_score: {e}")
            return False
    
    def show_leaderboard_analysis(self, leaderboard_id: str, sample_size: int = 100) -> None:
        """
        Show leaderboard analysis
        
        Args:
            leaderboard_id: Leaderboard ID
            sample_size: Number of entries to analyze
        """
        stats = self.analyze_leaderboard(leaderboard_id, sample_size)
        
        if not stats:
            return
        
        print(f"\n📊 Leaderboard Analysis")
        print("=" * 40)
        print(f"📋 Total Entries: {stats['total_entries']:,}")
        print(f"📊 Sample Size: {stats['sample_size']}")
        print(f"🏆 Top Score: {stats['top_score']:.1f}")
        print(f"🏰 Active Clans: {stats['clans']}")
        
        score_stats = stats.get('score_stats', {})
        print(f"\n💯 Score Statistics:")
        print(f"   📈 Average: {score_stats.get('avg', 0):.1f}")
        print(f"   📊 Median: {score_stats.get('median', 0):.1f}")
        print(f"   ⬇️ Minimum: {score_stats.get('min', 0):.1f}")
        print(f"   ⬆️ Maximum: {score_stats.get('max', 0):.1f}")
        
        xp_stats = stats.get('xp_stats')
        if xp_stats:
            print(f"\n⭐ XP Statistics:")
            print(f"   📈 Average: {xp_stats.get('avg', 0):,.0f}")
            print(f"   📊 Median: {xp_stats.get('median', 0):,.0f}")
            print(f"   ⬇️ Minimum: {xp_stats.get('min', 0):,.0f}")
            print(f"   ⬆️ Maximum: {xp_stats.get('max', 0):,.0f}")


# Convenience functions
def get_leaderboard(leaderboard_id: str, sort: str = "desc", 
                   offset: int = 0, limit: int = 100) -> Optional[Dict]:
    """Get leaderboard data"""
    system = MC5LeaderboardSystem()
    return system.get_leaderboard(leaderboard_id, sort, offset, limit)


def get_my_rank(leaderboard_id: str, sort: str = "desc", limit: int = 5) -> Optional[Dict]:
    """Get your rank"""
    system = MC5LeaderboardSystem()
    return system.get_my_rank(leaderboard_id, sort, limit)


def show_leaderboard(leaderboard_id: str, top_count: int = 10) -> None:
    """Show leaderboard"""
    system = MC5LeaderboardSystem()
    system.show_leaderboard(leaderboard_id, top_count)


def show_my_rank_context(leaderboard_id: str, nearby_count: int = 5) -> None:
    """Show your rank context"""
    system = MC5LeaderboardSystem()
    system.show_my_rank_context(leaderboard_id, nearby_count)


def analyze_leaderboard(leaderboard_id: str, sample_size: int = 100) -> Dict:
    """Analyze leaderboard statistics"""
    system = MC5LeaderboardSystem()
    return system.analyze_leaderboard(leaderboard_id, sample_size)


# Current event functions
def get_current_event_leaderboard(limit: int = 100) -> Optional[Dict]:
    """Get current event leaderboard"""
    event_id = "0c646c6a-e61c-11f0-be58-b8ca3a634708"
    leaderboard_id = f"Leaderboard_{event_id}"
    return get_leaderboard(leaderboard_id, limit=limit)


def show_current_event_leaderboard(top_count: int = 10) -> None:
    """Show current event leaderboard"""
    event_id = "0c646c6a-e61c-11f0-be58-b8ca3a634708"
    leaderboard_id = f"Leaderboard_{event_id}"
    show_leaderboard(leaderboard_id, top_count)


def get_my_current_event_rank(limit: int = 5) -> Optional[Dict]:
    """Get your current event rank"""
    event_id = "0c646c6a-e61c-11f0-be58-b8ca3a634708"
    leaderboard_id = f"Leaderboard_{event_id}"
    return get_my_rank(leaderboard_id, limit=limit)


def show_my_current_event_context(nearby_count: int = 5) -> None:
    """Show your current event rank context"""
    event_id = "0c646c6a-e61c-11f0-be58-b8ca3a634708"
    leaderboard_id = f"Leaderboard_{event_id}"
    show_my_rank_context(leaderboard_id, nearby_count)


def analyze_current_event(sample_size: int = 100) -> Dict:
    """Analyze current event statistics"""
    event_id = "0c646c6a-e61c-11f0-be58-b8ca3a634708"
    leaderboard_id = f"Leaderboard_{event_id}"
    return analyze_leaderboard(leaderboard_id, sample_size)


# Score update functions
def update_leaderboard_score(leaderboard_id: str, new_score: float) -> Optional[Dict]:
    """Update score on a leaderboard"""
    system = MC5LeaderboardSystem()
    return system.update_score(leaderboard_id, new_score)


def update_my_score(leaderboard_id: str, new_score: float) -> bool:
    """Get current score and update it"""
    system = MC5LeaderboardSystem()
    return system.get_and_update_score(leaderboard_id, new_score)


# Quick score update functions
def update_current_event_score(new_score: float) -> Optional[Dict]:
    """Update score on current event leaderboard"""
    event_id = "0c646c6a-e61c-11f0-be58-b8ca3a634708"
    leaderboard_id = f"Leaderboard_{event_id}"
    return update_leaderboard_score(leaderboard_id, new_score)


def update_my_current_event_score(new_score: float) -> bool:
    """Update score on current event leaderboard with verification"""
    event_id = "0c646c6a-e61c-11f0-be58-b8ca3a634708"
    leaderboard_id = f"Leaderboard_{event_id}"
    return update_my_score(leaderboard_id, new_score)
