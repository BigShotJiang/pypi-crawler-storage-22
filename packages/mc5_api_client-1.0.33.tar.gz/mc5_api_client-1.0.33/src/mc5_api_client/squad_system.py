# ────────────[ KAKUZU ]────────────────────────────
# | Discord  : kakuzu_f0
# | Telegram : kakuzu_f0
# | Github   : kakuzu-f0
# | File     : squad_system.py
# | License  : MIT License © 2026 Kakuzu
# | Brief    : MC5 Squad/Clan management system with leaderboard access
# ────────────────★─────────────────────────────────

"""
MC5 Squad/Clan Management System

This module provides comprehensive squad/clan management functionality including:
- Squad leaderboard access
- Squad member information
- Squad performance tracking
- Squad comparison and analytics
"""

import json
import time
from typing import Dict, List, Optional, Any
from datetime import datetime
import requests
from .chat import MC5ChatClient


class SquadSystem:
    """MC5 Squad/Clan Management System"""
    
    def __init__(self, chat_client: Optional[MC5ChatClient] = None):
        """Initialize squad system
        
        Args:
            chat_client: MC5ChatClient instance for API access
        """
        self.chat_client = chat_client or MC5ChatClient()
        self.squad_leaderboard_id = "MC5_CLANS_GLOBAL_IOS"
        
        # Use the provided access token for testing
        if not self.chat_client.access_token:
            self.chat_client.access_token = "5c40a468-c037-11ee-8805-b8ca3a60b598,alert auth leaderboard_ro lobby message social chat session,1875:55979:6.0.0a:windows:windows,1770238996.706923,anonymous:d2luOF92M18xNzcwMDUxNjkwXy7H33aeTVB4YZictyDq48c=,1364509832654538259,eur~gold|d0fe66db196317e227a05c8168dc8c28"
            self.chat_client.member_id = "d1e7437c-0156-11f1-ad07-b8ca3a709038"
        
    def get_squad_leaderboard(self, offset: int = 0, limit: int = 100) -> Optional[Dict]:
        """Get squad leaderboard
        
        Args:
            offset: Starting position (default: 0)
            limit: Number of squads to retrieve (default: 100)
            
        Returns:
            Squad leaderboard data or None if failed
        """
        try:
            url = f"https://eur-olympus.gameloft.com/leaderboards/desc/{self.squad_leaderboard_id}"
            
            params = {
                'access_token': self.chat_client.access_token,
                'offset': offset,
                'limit': limit
            }
            
            response = requests.get(url, params=params, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                print(f"🏆 Retrieved {len(data.get('data', []))} squads from leaderboard")
                return data
            else:
                print(f"🔴 Error getting squad leaderboard: {response.status_code}")
                return None
                
        except Exception as e:
            print(f"🔴 Error fetching squad leaderboard: {e}")
            return None
    
    def get_my_squad_info(self) -> Optional[Dict]:
        """Get your squad information
        
        Returns:
            Your squad data or None if failed
        """
        try:
            url = f"https://eur-olympus.gameloft.com/leaderboards/desc/{self.squad_leaderboard_id}"
            
            params = {
                'access_token': self.chat_client.access_token,
                'for_entry_id': self.chat_client.member_id
            }
            
            response = requests.get(url, params=params, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                my_entry = data.get('my_entry')
                if my_entry:
                    print(f"🏆 Found your squad: {my_entry.get('_clan_name', 'Unknown')}")
                    return my_entry
                else:
                    print("🔴 Your squad not found in leaderboard")
                    return None
            else:
                print(f"🔴 Error getting squad info: {response.status_code}")
                return None
                
        except Exception as e:
            print(f"🔴 Error fetching squad info: {e}")
            return None
    
    def get_squad_neighbors(self, limit: int = 5) -> Optional[List[Dict]]:
        """Get squads around your rank
        
        Args:
            limit: Number of squads above and below to retrieve
            
        Returns:
            List of nearby squads or None if failed
        """
        try:
            my_squad = self.get_my_squad_info()
            if not my_squad:
                return None
            
            my_rank = my_squad.get('rank', 0)
            start_offset = max(0, my_rank - limit - 1)
            total_limit = limit * 2 + 1
            
            leaderboard = self.get_squad_leaderboard(offset=start_offset, limit=total_limit)
            if not leaderboard:
                return None
            
            squads = leaderboard.get('data', [])
            return squads
            
        except Exception as e:
            print(f"🔴 Error getting squad neighbors: {e}")
            return None
    
    def analyze_squad_performance(self) -> Dict:
        """Analyze squad performance and statistics
        
        Returns:
            Performance analysis dictionary
        """
        try:
            my_squad = self.get_my_squad_info()
            if not my_squad:
                return {"error": "Could not retrieve squad info"}
            
            leaderboard = self.get_squad_leaderboard(limit=1000)  # Get larger sample
            if not leaderboard:
                return {"error": "Could not retrieve leaderboard"}
            
            squads = leaderboard.get('data', [])
            total_squads = leaderboard.get('total_entries', len(squads))
            
            my_rank = int(my_squad.get('rank', 0))
            my_score = float(my_squad.get('score', 0))
            my_league = int(my_squad.get('_league_index', 0))
            
            # Calculate statistics
            percentile = ((total_squads - my_rank) / total_squads) * 100
            
            # Find top scores
            top_scores = [s.get('score', 0) for s in squads[:10]]
            median_score = 0
            if squads:
                scores = [s.get('score', 0) for s in squads]
                scores.sort()
                median_score = scores[len(scores) // 2]
            
            # League analysis
            league_info = self._analyze_league(my_league)
            
            analysis = {
                "squad_name": my_squad.get('_clan_name', 'Unknown'),
                "display_name": my_squad.get('display_name', 'Unknown'),
                "score": my_score,
                "rank": my_rank,
                "total_squads": total_squads,
                "percentile": round(percentile, 2),
                "league_index": my_league,
                "league_info": league_info,
                "top_scores": top_scores[:5],
                "median_score": median_score,
                "last_update": my_squad.get('last_update', 'Unknown'),
                "logo": {
                    "logo": my_squad.get('_logo', 0),
                    "color1": my_squad.get('_logo_color1', 0),
                    "color2": my_squad.get('_logo_color2', 0)
                },
                "recommendations": self._generate_squad_recommendations(my_rank, total_squads, my_score)
            }
            
            return analysis
            
        except Exception as e:
            print(f"🔴 Error analyzing squad performance: {e}")
            return {"error": str(e)}
    
    def _analyze_league(self, league_index: int) -> Dict:
        """Analyze league information
        
        Args:
            league_index: League index from squad data
            
        Returns:
            League analysis dictionary
        """
        league_index = int(league_index)
        
        if league_index >= 0:
            return {
                "tier": "Bronze",
                "description": "Starting league",
                "next_threshold": "Reach negative league index"
            }
        elif league_index >= -5:
            return {
                "tier": "Silver",
                "description": "Intermediate league",
                "performance": "Good progress"
            }
        elif league_index >= -10:
            return {
                "tier": "Gold",
                "description": "Advanced league",
                "performance": "Excellent"
            }
        elif league_index >= -15:
            return {
                "tier": "Platinum",
                "description": "Expert league",
                "performance": "Outstanding"
            }
        else:
            return {
                "tier": "Diamond",
                "description": "Elite league",
                "performance": "Legendary"
            }
    
    def _generate_squad_recommendations(self, rank: int, total: int, score: float) -> List[str]:
        """Generate squad improvement recommendations
        
        Args:
            rank: Current squad rank
            total: Total number of squads
            score: Current squad score
            
        Returns:
            List of recommendations
        """
        recommendations = []
        
        percentile = ((total - rank) / total) * 100
        
        if percentile < 25:
            recommendations.append("🎯 Focus on recruiting active members")
            recommendations.append("📈 Organize squad events and activities")
            recommendations.append("🏆 Set weekly score goals for members")
        elif percentile < 50:
            recommendations.append("🚀 Aim for top 25% (rank ~545)")
            recommendations.append("💪 Improve squad coordination")
            recommendations.append("🎮 Participate in more squad events")
        elif percentile < 75:
            recommendations.append("⭐ Target top 10% (rank ~218)")
            recommendations.append("🏅 Compete with higher-ranked squads")
            recommendations.append("📊 Analyze top squad strategies")
        else:
            recommendations.append("👑 Maintain elite performance")
            recommendations.append("🎯 Aim for top 100 squads")
            recommendations.append("🏆 Defend your high ranking")
        
        if score < 1000:
            recommendations.append("📈 Increase squad activity to boost score")
        
        return recommendations
    
    def show_squad_dashboard(self) -> None:
        """Display comprehensive squad dashboard"""
        print("🏆 MC5 SQUAD DASHBOARD")
        print("=" * 50)
        
        analysis = self.analyze_squad_performance()
        
        if "error" in analysis:
            print(f"🔴 Error: {analysis['error']}")
            return
        
        # Squad Info
        print(f"👥 Squad: {analysis['squad_name']}")
        print(f"🏆 Score: {analysis['score']:,.0f} points")
        print(f"📍 Rank: #{analysis['rank']:,} of {analysis['total_squads']:,}")
        print(f"📊 Percentile: {analysis['percentile']}%")
        print(f"🏅 League: {analysis['league_info']['tier']} ({analysis['league_index']})")
        print(f"🕐 Last Update: {analysis['last_update']}")
        
        # Performance
        print("\n📈 PERFORMANCE ANALYSIS")
        print("-" * 30)
        print(f"🎯 League Tier: {analysis['league_info']['description']}")
        print(f"📊 Median Score: {analysis['median_score']:,.0f}")
        print(f"🏆 Top 5 Scores: {', '.join([f'{s:,.0f}' for s in analysis['top_scores']])}")
        
        # Recommendations
        print("\n💡 RECOMMENDATIONS")
        print("-" * 20)
        for i, rec in enumerate(analysis['recommendations'], 1):
            print(f"{i}. {rec}")
        
        # Neighbors
        print("\n👥 NEARBY SQUADS")
        print("-" * 20)
        neighbors = self.get_squad_neighbors(limit=3)
        if neighbors:
            for squad in neighbors:
                name = squad.get('_clan_name', 'Unknown')
                score = squad.get('score', 0)
                rank = squad.get('rank', 0)
                marker = "👤" if squad.get('id') == self.chat_client.member_id else "  "
                print(f"{marker} #{rank}: {name} ({score:,.0f})")
    
    def get_squad_recommendations(self, limit: int = 10) -> Optional[List[Dict]]:
        """Get recommended squads based on your profile
        
        Args:
            limit: Number of recommendations to retrieve (default: 10)
            
        Returns:
            List of recommended squads or None if failed
        """
        try:
            url = "https://eur-osiris.gameloft.com/groups/categories/mc5_clan_v01/find/recommendation_score"
            
            params = {
                'access_token': self.chat_client.access_token,
                'limit': limit
            }
            
            response = requests.get(url, params=params, timeout=10)
            
            if response.status_code == 200:
                squads = response.json()
                print(f"🏆 Retrieved {len(squads)} recommended squads")
                return squads
            else:
                print(f"🔴 Error getting squad recommendations: {response.status_code}")
                return None
                
        except Exception as e:
            print(f"🔴 Error fetching squad recommendations: {e}")
            return None
    
    def search_squads_by_name(self, keywords: str, limit: int = 10, offset: int = 0) -> Optional[List[Dict]]:
        """Search for squads by name/keywords
        
        Args:
            keywords: Search keywords
            limit: Number of results to retrieve (default: 10)
            offset: Starting offset for pagination (default: 0)
            
        Returns:
            List of matching squads or None if failed
        """
        try:
            url = "https://eur-osiris.gameloft.com/groups/categories/mc5_clan_v01/find/keyword"
            
            params = {
                'access_token': self.chat_client.access_token,
                'keywords': keywords,
                'limit': limit,
                'offset': offset
            }
            
            response = requests.get(url, params=params, timeout=10)
            
            if response.status_code == 200:
                squads = response.json()
                print(f"🔍 Found {len(squads)} squads matching '{keywords}'")
                return squads
            else:
                print(f"🔴 Error searching squads: {response.status_code}")
                return None
                
        except Exception as e:
            print(f"🔴 Error searching squads: {e}")
            return None
    
    def analyze_recommended_squads(self, limit: int = 10) -> Dict:
        """Analyze recommended squads for insights
        
        Args:
            limit: Number of recommendations to analyze (default: 10)
            
        Returns:
            Analysis of recommended squads
        """
        try:
            recommended_squads = self.get_squad_recommendations(limit=limit)
            if not recommended_squads:
                return {"error": "Could not get recommended squads"}
            
            # Analyze squad characteristics
            total_squads = len(recommended_squads)
            avg_members = sum(squad.get('member_count', 0) for squad in recommended_squads) / total_squads
            avg_rating = sum(squad.get('_rating', 0) for squad in recommended_squads) / total_squads
            
            # League distribution
            league_dist = {}
            for squad in recommended_squads:
                league_idx = squad.get('_league_info', {}).get('index', 0)
                league_dist[league_idx] = league_dist.get(league_idx, 0) + 1
            
            # Member count distribution
            small_squads = len([s for s in recommended_squads if s.get('member_count', 0) <= 5])
            medium_squads = len([s for s in recommended_squads if 5 < s.get('member_count', 0) <= 15])
            large_squads = len([s for s in recommended_squads if s.get('member_count', 0) > 15])
            
            return {
                "total_analyzed": total_squads,
                "average_members": round(avg_members, 1),
                "average_rating": round(avg_rating, 1),
                "league_distribution": league_dist,
                "size_distribution": {
                    "small (1-5)": small_squads,
                    "medium (6-15)": medium_squads,
                    "large (15+)": large_squads
                },
                "recommendations": [
                    f"📊 Average squad size: {avg_members:.1f} members",
                    f"⭐ Average rating: {avg_rating:.1f}",
                    f"🏆 Most common league: League {max(league_dist, key=league_dist.get)}",
                    f"👥 {small_squads} small squads, {medium_squads} medium, {large_squads} large"
                ],
                "top_recommended": recommended_squads[:3]
            }
            
        except Exception as e:
            return {"error": f"Error analyzing recommended squads: {e}"}
    
    def show_squad_recommendations(self, limit: int = 10) -> None:
        """Display squad recommendations with analysis
        
        Args:
            limit: Number of recommendations to show (default: 10)
        """
        print("🏆 MC5 SQUAD RECOMMENDATIONS")
        print("=" * 50)
        
        squads = self.get_squad_recommendations(limit=limit)
        if not squads:
            print("❌ Could not get squad recommendations")
            return
        
        print(f"📊 Found {len(squads)} recommended squads for you:\n")
        
        for i, squad in enumerate(squads, 1):
            name = squad.get('name', 'Unknown')
            members = squad.get('member_count', 0)
            member_limit = squad.get('member_limit', 0)
            rating = squad.get('_rating', 0)
            league_idx = squad.get('_league_info', {}).get('index', 0)
            description = squad.get('description', 'No description')
            
            # Truncate long descriptions
            if len(description) > 50:
                description = description[:47] + "..."
            
            print(f"#{i:2d}. {name}")
            print(f"     👥 Members: {members}/{member_limit}")
            print(f"     ⭐ Rating: {rating}")
            print(f"     🏅 League: {league_idx}")
            print(f"     📝 {description}")
            print()
        
        # Show analysis
        analysis = self.analyze_recommended_squads(limit)
        if "error" not in analysis:
            print("📈 RECOMMENDATION ANALYSIS")
            print("-" * 30)
            for rec in analysis['recommendations']:
                print(f"• {rec}")
    
    def search_and_analyze_squads(self, keywords: str, limit: int = 10) -> None:
        """Search squads and display results with analysis
        
        Args:
            keywords: Search keywords
            limit: Number of results to show (default: 10)
        """
        print(f"🔍 SEARCHING SQUADS: '{keywords}'")
        print("=" * 50)
        
        squads = self.search_squads_by_name(keywords, limit=limit)
        if not squads:
            print(f"❌ No squads found matching '{keywords}'")
            return
        
        print(f"📊 Found {len(squads)} squads matching '{keywords}':\n")
        
        for i, squad in enumerate(squads, 1):
            name = squad.get('name', 'Unknown')
            members = squad.get('member_count', 0)
            member_limit = squad.get('member_limit', 0)
            rating = squad.get('_rating', 0)
            league_idx = squad.get('_league_info', {}).get('index', 0)
            owner_name = squad.get('owner', {}).get('name', 'Unknown')
            
            print(f"#{i:2d}. {name}")
            print(f"     👥 Members: {members}/{member_limit}")
            print(f"     ⭐ Rating: {rating}")
            print(f"     🏅 League: {league_idx}")
            print(f"     👑 Owner: {owner_name}")
            print()
        
        # Quick analysis
        avg_members = sum(s.get('member_count', 0) for s in squads) / len(squads)
        avg_rating = sum(s.get('_rating', 0) for s in squads) / len(squads)
        
        print("📈 SEARCH ANALYSIS")
        print("-" * 20)
        print(f"• Average members: {avg_members:.1f}")
        print(f"• Average rating: {avg_rating:.1f}")
        print(f"• League range: {min(s.get('_league_info', {}).get('index', 0) for s in squads)} to {max(s.get('_league_info', {}).get('index', 0) for s in squads)}")

    def compare_squads(self, squad1_id: str, squad2_id: str) -> Optional[Dict]:
        """Compare two squads
        
        Args:
            squad1_id: First squad ID
            squad2_id: Second squad ID
            
        Returns:
            Comparison data or None if failed
        """
        try:
            leaderboard = self.get_squad_leaderboard(limit=2000)  # Get larger sample for comparison
            if not leaderboard:
                return None
            
            squads = leaderboard.get('data', [])
            
            squad1 = None
            squad2 = None
            
            for squad in squads:
                if squad.get('id') == squad1_id:
                    squad1 = squad
                elif squad.get('id') == squad2_id:
                    squad2 = squad
            
            if not squad1 or not squad2:
                print("🔴 One or both squads not found")
                return None
            
            comparison = {
                "squad1": {
                    "name": squad1.get('_clan_name', 'Unknown'),
                    "score": squad1.get('score', 0),
                    "rank": squad1.get('rank', 0),
                    "league": squad1.get('_league_index', 0)
                },
                "squad2": {
                    "name": squad2.get('_clan_name', 'Unknown'),
                    "score": squad2.get('score', 0),
                    "rank": squad2.get('rank', 0),
                    "league": squad2.get('_league_index', 0)
                },
                "score_difference": squad1.get('score', 0) - squad2.get('score', 0),
                "rank_difference": squad2.get('rank', 0) - squad1.get('rank', 0)
            }
            
            return comparison
            
        except Exception as e:
            print(f"🔴 Error comparing squads: {e}")
            return None
    
    def get_top_squads(self, limit: int = 10) -> Optional[List[Dict]]:
        """Get top performing squads
        
        Args:
            limit: Number of top squads to retrieve
            
        Returns:
            List of top squads or None if failed
        """
        try:
            leaderboard = self.get_squad_leaderboard(limit=limit)
            if not leaderboard:
                return None
            
            squads = leaderboard.get('data', [])
            top_squads = []
            
            for squad in squads:
                squad_info = {
                    "rank": squad.get('rank', 0),
                    "name": squad.get('_clan_name', 'Unknown'),
                    "score": squad.get('score', 0),
                    "league": squad.get('_league_index', 0),
                    "logo": squad.get('_logo', 0),
                    "colors": {
                        "color1": squad.get('_logo_color1', 0),
                        "color2": squad.get('_logo_color2', 0)
                    }
                }
                top_squads.append(squad_info)
            
            return top_squads
            
        except Exception as e:
            print(f"🔴 Error getting top squads: {e}")
            return None


# Convenience functions
def get_my_squad_info() -> Optional[Dict]:
    """Get your squad information"""
    system = SquadSystem()
    return system.get_my_squad_info()

def get_squad_leaderboard(offset: int = 0, limit: int = 100) -> Optional[Dict]:
    """Get squad leaderboard"""
    system = SquadSystem()
    return system.get_squad_leaderboard(offset=offset, limit=limit)

def analyze_squad_performance() -> Dict:
    """Analyze your squad performance"""
    system = SquadSystem()
    return system.analyze_squad_performance()

def show_squad_dashboard() -> None:
    """Show comprehensive squad dashboard"""
    system = SquadSystem()
    system.show_squad_dashboard()

def get_top_squads(limit: int = 10) -> Optional[List[Dict]]:
    """Get top performing squads"""
    system = SquadSystem()
    return system.get_top_squads(limit=limit)

def compare_squads(squad1_id: str, squad2_id: str) -> Optional[Dict]:
    """Compare two squads"""
    system = SquadSystem()
    return system.compare_squads(squad1_id, squad2_id)

def get_squad_recommendations(limit: int = 10) -> Optional[List[Dict]]:
    """Get recommended squads based on your profile"""
    system = SquadSystem()
    return system.get_squad_recommendations(limit=limit)

def search_squads_by_name(keywords: str, limit: int = 10, offset: int = 0) -> Optional[List[Dict]]:
    """Search for squads by name/keywords"""
    system = SquadSystem()
    return system.search_squads_by_name(keywords, limit=limit, offset=offset)

def show_squad_recommendations(limit: int = 10) -> None:
    """Display squad recommendations with analysis"""
    system = SquadSystem()
    system.show_squad_recommendations(limit=limit)

def search_and_analyze_squads(keywords: str, limit: int = 10) -> None:
    """Search squads and display results with analysis"""
    system = SquadSystem()
    system.search_and_analyze_squads(keywords, limit=limit)

def analyze_recommended_squads(limit: int = 10) -> Dict:
    """Analyze recommended squads for insights"""
    system = SquadSystem()
    return system.analyze_recommended_squads(limit=limit)
