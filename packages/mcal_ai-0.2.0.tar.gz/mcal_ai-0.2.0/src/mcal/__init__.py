"""
MCAL: Memory-Context Alignment Layer

A standalone memory architecture for AI agents that preserves:
- Intent graphs (goal hierarchies)
- Reasoning chains (decision rationale)
- Goal-aware retrieval (objective-based context)

Usage:
    from mcal import MCAL
    
    mcal = MCAL(
        openai_api_key="..."  # or anthropic_api_key, or use bedrock
    )
    
    # Add conversation
    result = await mcal.add(messages, user_id="user_123")
    
    # Search with goal-awareness
    context = await mcal.get_context("What's next?", user_id="user_123")
"""

__version__ = "0.1.0"

# Main interface
from .mcal import MCAL, AddResult, SearchResult, TimingMetrics, TieredBedrockProvider

# Core models
from .core.models import (
    DecisionTrail,
    IntentGraph,
    IntentNode,
    IntentStatus,
    IntentType,
    Memory,
    MemoryType,
    RetrievalConfig,
    RetrievalResult,
    Session,
    Turn,
)

# Core components (for advanced usage)
from .core.intent_tracker import IntentTracker
from .core.reasoning_store import ReasoningStore
from .core.goal_retriever import GoalRetriever, ContextAssembler

# Streaming API (Issue #10)
from .core.streaming import (
    StreamEvent,
    StreamEventType,
    ExtractionPhase,
    StreamProgress,
    CacheHitInfo,
    PhaseResult,
)

# Backends (MemoryEntry kept for compatibility)
from .backends import (
    MemoryBackend,
    MemoryEntry,
)

# Deprecated: Mem0Backend and StandaloneBackend (Issue #53)
# Use: from mcal.backends import Mem0Backend (requires pip install mcal[mem0])

__all__ = [
    # Version
    "__version__",
    # Main interface
    "MCAL",
    "AddResult",
    "SearchResult",
    # Models
    "DecisionTrail",
    "IntentGraph",
    "IntentNode",
    "IntentStatus",
    "IntentType",
    "Memory",
    "MemoryType",
    "RetrievalConfig",
    "RetrievalResult",
    "Session",
    "Turn",
    # Core components
    "IntentTracker",
    "ReasoningStore",
    "GoalRetriever",
    "ContextAssembler",
    # Backends (for advanced usage)
    "MemoryBackend",
    "MemoryEntry",
    # Streaming (Issue #10)
    "StreamEvent",
    "StreamEventType",
    "ExtractionPhase",
    "StreamProgress",
    "CacheHitInfo",
    "PhaseResult",
    # Integrations namespace
    "integrations",
    # Integration shortcuts (lazy loaded)
    "LangGraphMemory",
    "LangGraphStore",
    "CrewAIMemory",
    "AutoGenMemory",
    "LangChainMemory",
]


# Lazy loading for integration shortcuts
def __getattr__(name: str):
    """Lazy load integration classes to avoid import errors."""
    import importlib
    
    if name == "integrations":
        return importlib.import_module("mcal.integrations")
    
    if name == "LangGraphMemory":
        try:
            mod = importlib.import_module("mcal.integrations.langgraph")
            return mod.MCALMemory
        except ImportError:
            raise ImportError(
                "LangGraph integration requires: pip install mcal[langgraph]"
            )
    
    if name == "LangGraphStore":
        try:
            mod = importlib.import_module("mcal.integrations.langgraph")
            return mod.MCALStore
        except ImportError:
            raise ImportError(
                "LangGraph integration requires: pip install mcal[langgraph]"
            )
    
    if name == "CrewAIMemory":
        try:
            mod = importlib.import_module("mcal.integrations.crewai")
            return mod.MCALCrewMemory
        except ImportError:
            raise ImportError(
                "CrewAI integration requires: pip install mcal[crewai]"
            )
    
    if name == "AutoGenMemory":
        try:
            mod = importlib.import_module("mcal.integrations.autogen")
            return mod.MCALMemoryAgent
        except ImportError:
            raise ImportError(
                "AutoGen integration requires: pip install mcal[autogen]"
            )
    
    if name == "LangChainMemory":
        try:
            mod = importlib.import_module("mcal.integrations.langchain")
            return mod.MCALChatMemory
        except ImportError:
            raise ImportError(
                "LangChain integration requires: pip install mcal[langchain]"
            )
    
    raise AttributeError(f"module 'mcal' has no attribute '{name}'")