"""MCAL Memory Backends.

Issue #53: Mem0Backend and StandaloneBackend are deprecated.
MCAL is now standalone and doesn't require external backends.
These are kept for backward compatibility.
"""

from .base import (
    MemoryBackend,
    MemoryEntry,
)

# Deprecated backends - import lazily to avoid requiring mem0ai
def __getattr__(name):
    if name == "Mem0Backend":
        import warnings
        warnings.warn(
            "Mem0Backend is deprecated. MCAL v1.0 is fully standalone. "
            "Install with 'pip install mcal[mem0]' if needed.",
            DeprecationWarning,
            stacklevel=2
        )
        from .base import Mem0Backend
        return Mem0Backend
    elif name == "StandaloneBackend":
        import warnings
        warnings.warn(
            "StandaloneBackend is deprecated. MCAL v1.0 is fully standalone.",
            DeprecationWarning,
            stacklevel=2
        )
        from .base import StandaloneBackend
        return StandaloneBackend
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

__all__ = [
    "MemoryBackend",
    "MemoryEntry",
    # Deprecated (Issue #53)
    "Mem0Backend",
    "StandaloneBackend",
]
