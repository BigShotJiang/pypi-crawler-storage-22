"""MCAL Core Components"""

from .models import (
    DecisionTrail,
    IntentGraph,
    IntentNode,
    IntentStatus,
    IntentType,
    Memory,
    MemoryType,
    RetrievalConfig,
    RetrievalResult,
    Session,
    Turn,
)
from .intent_tracker import IntentTracker
from .reasoning_store import ReasoningStore
from .goal_retriever import GoalRetriever, ContextAssembler
from .storage import MCALStorage
from .extraction_cache import ExtractionCache, CacheStats, ExtractionState
from .unified_extractor import (
    UnifiedExtractor,
    UnifiedGraph,
    GraphNode,
    GraphEdge,
    NodeType,
    EdgeType,
    DeduplicationStrategy,
    DeduplicationStats,
    graph_to_memories,
    memories_to_context_string,
)
from .streaming import (
    StreamEvent,
    StreamEventType,
    ExtractionPhase,
    StreamProgress,
    CacheHitInfo,
    PhaseResult,
)
from .embeddings import (
    EmbeddingService,
    embed_graph_nodes,
    embedding_to_bytes,
    bytes_to_embedding,
    embedding_to_base64,
    base64_to_embedding,
    get_embedding_model,
    clear_embedding_model,
)
from .vector_index import VectorIndex, build_index_from_nodes

__all__ = [
    "DecisionTrail",
    "IntentGraph",
    "IntentNode",
    "IntentStatus",
    "IntentType",
    "Memory",
    "MemoryType",
    "RetrievalConfig",
    "RetrievalResult",
    "Session",
    "Turn",
    "IntentTracker",
    "ReasoningStore",
    "GoalRetriever",
    "ContextAssembler",
    "MCALStorage",
    "ExtractionCache",
    "CacheStats",
    "ExtractionState",
    # Unified Extractor (optimized)
    "UnifiedExtractor",
    "UnifiedGraph",
    "GraphNode",
    "GraphEdge",
    "NodeType",
    "EdgeType",
    "graph_to_memories",
    "memories_to_context_string",
    # Streaming
    "StreamEvent",
    "StreamEventType",
    "ExtractionPhase",
    "StreamProgress",
    "CacheHitInfo",
    "PhaseResult",
    # Embeddings (Issue #50)
    "EmbeddingService",
    "embed_graph_nodes",
    "embedding_to_bytes",
    "bytes_to_embedding",
    "embedding_to_base64",
    "base64_to_embedding",
    "get_embedding_model",
    "clear_embedding_model",
    # Vector Search (Issue #51)
    "VectorIndex",
    "build_index_from_nodes",
]
