"""MCAL Evaluation metrics and benchmarks."""
