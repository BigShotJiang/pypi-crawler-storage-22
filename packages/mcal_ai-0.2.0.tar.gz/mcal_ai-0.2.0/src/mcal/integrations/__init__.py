"""
MCAL Framework Integrations

Provides seamless integration with popular AI agent frameworks.

Installation:
    pip install mcal[langgraph]    # LangGraph integration
    pip install mcal[crewai]       # CrewAI integration
    pip install mcal[autogen]      # AutoGen integration
    pip install mcal[integrations] # All integrations

Usage:
    # Option 1: Explicit import (recommended)
    from mcal.integrations.langgraph import MCALMemory
    
    # Option 2: Namespace access
    from mcal import integrations
    memory = integrations.langgraph.MCALMemory()
    
    # Option 3: Direct shortcut
    from mcal import LangGraphMemory
"""

from typing import TYPE_CHECKING

# Lazy imports to avoid loading dependencies until needed
if TYPE_CHECKING:
    from mcal.integrations import langgraph
    from mcal.integrations import crewai
    from mcal.integrations import autogen
    from mcal.integrations import langchain


def __getattr__(name: str):
    """Lazy load integrations to avoid import errors when extras not installed."""
    if name == "langgraph":
        try:
            from mcal.integrations import langgraph as _langgraph
            return _langgraph
        except ImportError as e:
            raise ImportError(
                f"LangGraph integration requires extra dependencies.\n"
                f"Install with: pip install mcal[langgraph]\n"
                f"Original error: {e}"
            ) from e
    
    elif name == "crewai":
        try:
            from mcal.integrations import crewai as _crewai
            return _crewai
        except ImportError as e:
            raise ImportError(
                f"CrewAI integration requires extra dependencies.\n"
                f"Install with: pip install mcal[crewai]\n"
                f"Original error: {e}"
            ) from e
    
    elif name == "autogen":
        try:
            from mcal.integrations import autogen as _autogen
            return _autogen
        except ImportError as e:
            raise ImportError(
                f"AutoGen integration requires extra dependencies.\n"
                f"Install with: pip install mcal[autogen]\n"
                f"Original error: {e}"
            ) from e
    
    elif name == "langchain":
        try:
            from mcal.integrations import langchain as _langchain
            return _langchain
        except ImportError as e:
            raise ImportError(
                f"LangChain integration requires extra dependencies.\n"
                f"Install with: pip install mcal[langchain]\n"
                f"Original error: {e}"
            ) from e
    
    raise AttributeError(f"module 'mcal.integrations' has no attribute '{name}'")


def __dir__():
    """List available integrations."""
    return ["langgraph", "crewai", "autogen", "langchain"]


__all__ = ["langgraph", "crewai", "autogen", "langchain"]
