"""
MCAL CrewAI Integration

Provides memory components for CrewAI agent crews.

Installation:
    pip install mcal[crewai]

Usage:
    from mcal.integrations.crewai import MCALCrewMemory
    
    memory = MCALCrewMemory(llm_provider="anthropic")
    crew = Crew(
        agents=[...],
        memory=memory,
    )

Status: Coming Soon
"""

from typing import Any, Dict, List, Optional

# Check for CrewAI availability
try:
    import crewai
    CREWAI_AVAILABLE = True
except ImportError:
    CREWAI_AVAILABLE = False


def _check_crewai():
    """Raise helpful error if CrewAI not installed."""
    if not CREWAI_AVAILABLE:
        raise ImportError(
            "CrewAI integration requires crewai package.\n"
            "Install with: pip install mcal[crewai]"
        )


class MCALCrewMemory:
    """
    MCAL Memory component for CrewAI workflows.
    
    Provides goal-aware memory that preserves reasoning context
    across agent crew interactions.
    
    Status: Coming Soon - Basic structure implemented.
    
    Usage:
        from mcal.integrations.crewai import MCALCrewMemory
        from crewai import Crew, Agent
        
        memory = MCALCrewMemory(llm_provider="anthropic")
        
        crew = Crew(
            agents=[agent1, agent2],
            tasks=[task1, task2],
            memory=memory,  # MCAL provides the memory layer
        )
    """
    
    def __init__(
        self,
        llm_provider: str = "anthropic",
        embedding_provider: str = "openai",
        storage_path: Optional[str] = None,
        **mcal_kwargs
    ):
        _check_crewai()
        
        # Import MCAL here to avoid circular imports
        from mcal import MCAL
        
        self._mcal = MCAL(
            llm_provider=llm_provider,
            embedding_provider=embedding_provider,
            storage_path=storage_path,
            **mcal_kwargs
        )
    
    async def save(self, key: str, value: Any, agent_name: str = "default") -> None:
        """Save information to memory."""
        # TODO: Implement CrewAI-specific save
        raise NotImplementedError("CrewAI integration coming soon")
    
    async def search(self, query: str, agent_name: str = "default") -> List[Dict[str, Any]]:
        """Search memory for relevant information."""
        # TODO: Implement CrewAI-specific search
        raise NotImplementedError("CrewAI integration coming soon")


__all__ = ["MCALCrewMemory", "CREWAI_AVAILABLE"]
