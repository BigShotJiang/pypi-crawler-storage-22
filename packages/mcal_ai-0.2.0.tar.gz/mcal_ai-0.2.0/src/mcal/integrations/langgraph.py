"""
MCAL LangGraph Integration - Backward Compatibility Shim

DEPRECATED: This module is deprecated. Use mcal-langgraph package instead.

Old way (deprecated):
    from mcal.integrations.langgraph import MCALStore

New way (recommended):
    pip install mcal-langgraph
    from mcal_langgraph import MCALStore

This module re-exports from mcal_langgraph for backward compatibility.
"""

from __future__ import annotations

import warnings

# Emit deprecation warning on import
warnings.warn(
    "mcal.integrations.langgraph is deprecated and will be removed in v1.0. "
    "Install mcal-langgraph and use 'from mcal_langgraph import MCALStore' instead.",
    DeprecationWarning,
    stacklevel=2,
)

# Try to import from new package first
try:
    from mcal_langgraph import (
        MCALStore,
        MCALMemory,
        MCALMemoryConfig,
        MCALCheckpointer,
        LANGGRAPH_AVAILABLE,
    )
except ImportError:
    # New package not installed - raise helpful error
    raise ImportError(
        "mcal-langgraph package is required for LangGraph integration.\n"
        "Install with: pip install mcal-langgraph"
    )

__all__ = [
    "MCALStore",
    "MCALMemory",
    "MCALMemoryConfig",
    "MCALCheckpointer",
    "LANGGRAPH_AVAILABLE",
]
