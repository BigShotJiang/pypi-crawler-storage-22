"""
MCAL AutoGen Integration

Goal-aware memory for Microsoft AutoGen multi-agent systems.
"""

from mcal_autogen.memory import MCALMemory

__version__ = "0.1.0"
__all__ = ["MCALMemory"]
