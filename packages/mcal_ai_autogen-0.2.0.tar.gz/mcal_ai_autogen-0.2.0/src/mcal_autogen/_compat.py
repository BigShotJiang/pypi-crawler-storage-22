"""
Compatibility layer for AutoGen imports.

Provides graceful handling when autogen packages are not installed.
"""

from typing import Any, Dict, List, Optional, TYPE_CHECKING

# Check if AutoGen is available
AUTOGEN_AVAILABLE = False
AUTOGEN_CORE_AVAILABLE = False

try:
    from autogen_core import CancellationToken
    from autogen_core.memory import (
        Memory,
        MemoryContent,
        MemoryQueryResult,
        UpdateContextResult,
        MemoryMimeType,
    )
    from autogen_core.model_context import ChatCompletionContext
    from autogen_core.models import SystemMessage
    AUTOGEN_CORE_AVAILABLE = True
    AUTOGEN_AVAILABLE = True
except ImportError:
    # Define minimal stubs for type checking
    Memory = object  # type: ignore
    MemoryContent = Any  # type: ignore
    MemoryQueryResult = Any  # type: ignore
    UpdateContextResult = Any  # type: ignore
    MemoryMimeType = Any  # type: ignore
    CancellationToken = Any  # type: ignore
    ChatCompletionContext = Any  # type: ignore
    SystemMessage = Any  # type: ignore


def check_autogen() -> None:
    """Raise ImportError if AutoGen is not available."""
    if not AUTOGEN_AVAILABLE:
        raise ImportError(
            "AutoGen packages not found. Install with: pip install mcal-autogen[autogen]"
        )


def check_autogen_core() -> None:
    """Raise ImportError if autogen-core is not available."""
    if not AUTOGEN_CORE_AVAILABLE:
        raise ImportError(
            "autogen-core not found. Install with: pip install autogen-core>=0.4.0"
        )


__all__ = [
    "AUTOGEN_AVAILABLE",
    "AUTOGEN_CORE_AVAILABLE",
    "check_autogen",
    "check_autogen_core",
    "Memory",
    "MemoryContent",
    "MemoryQueryResult",
    "UpdateContextResult",
    "MemoryMimeType",
    "CancellationToken",
    "ChatCompletionContext",
    "SystemMessage",
]
