"""
Compatibility layer for AutoGen imports.

Provides graceful handling when autogen packages are not installed.
"""

from typing import Any, Dict, List, Optional, TYPE_CHECKING

# Check if AutoGen is available
AUTOGEN_AVAILABLE = False
AUTOGEN_CORE_AVAILABLE = False

try:
    from autogen_core import CancellationToken
    from autogen_core.memory import (
        Memory,
        MemoryContent,
        MemoryQueryResult,
        UpdateContextResult,
        MemoryMimeType,
    )
    from autogen_core.model_context import ChatCompletionContext
    from autogen_core.models import SystemMessage
    AUTOGEN_CORE_AVAILABLE = True
    AUTOGEN_AVAILABLE = True
except ImportError:
    # Define minimal runtime-instantiable stubs (not just type aliases)
    # so that code paths work even without autogen-core installed.
    Memory = object  # type: ignore

    class MemoryContent:  # type: ignore
        """Stub for autogen_core.memory.MemoryContent."""
        def __init__(self, content: Any = None, mime_type: Any = None, metadata: Any = None, **kwargs: Any):
            self.content = content
            self.mime_type = mime_type or "text/plain"
            self.metadata = metadata or {}

    class MemoryQueryResult:  # type: ignore
        """Stub for autogen_core.memory.MemoryQueryResult."""
        def __init__(self, results: Any = None, **kwargs: Any):
            self.results = results or []

    class UpdateContextResult:  # type: ignore
        """Stub for autogen_core.memory.UpdateContextResult."""
        def __init__(self, memories: Any = None, **kwargs: Any):
            self.memories = memories

    class MemoryMimeType:  # type: ignore
        """Stub for autogen_core.memory.MemoryMimeType."""
        TEXT = "text/plain"
        JSON = "application/json"
        HTML = "text/html"
        BINARY = "application/octet-stream"

    CancellationToken = Any  # type: ignore
    ChatCompletionContext = Any  # type: ignore
    SystemMessage = Any  # type: ignore


def check_autogen() -> None:
    """Raise ImportError if AutoGen is not available."""
    if not AUTOGEN_AVAILABLE:
        raise ImportError(
            "AutoGen packages not found. Install with: pip install mcal-autogen[autogen]"
        )


def check_autogen_core() -> None:
    """Raise ImportError if autogen-core is not available."""
    if not AUTOGEN_CORE_AVAILABLE:
        raise ImportError(
            "autogen-core not found. Install with: pip install autogen-core>=0.4.0"
        )


__all__ = [
    "AUTOGEN_AVAILABLE",
    "AUTOGEN_CORE_AVAILABLE",
    "check_autogen",
    "check_autogen_core",
    "Memory",
    "MemoryContent",
    "MemoryQueryResult",
    "UpdateContextResult",
    "MemoryMimeType",
    "CancellationToken",
    "ChatCompletionContext",
    "SystemMessage",
]
