# mcal-crewai

Goal-aware memory integration for CrewAI agent crews.

## Installation

```bash
pip install mcal-crewai
```

## Quick Start

### Using MCALStorage (Mem0-style)

MCAL provides a storage backend that integrates directly with CrewAI's memory system:

```python
from crewai import Crew, Agent, Task, Process
from crewai.memory.short_term.short_term_memory import ShortTermMemory
from crewai.memory.long_term.long_term_memory import LongTermMemory
from crewai.memory.entity.entity_memory import EntityMemory
from mcal_crewai import MCALStorage

# Create MCAL-backed memories
short_term = ShortTermMemory(
    storage=MCALStorage(type="short_term", user_id="john")
)
long_term = LongTermMemory(
    storage=MCALStorage(type="long_term", user_id="john")
)
entity_memory = EntityMemory(
    storage=MCALStorage(type="entities", user_id="john")
)

# Use with CrewAI
crew = Crew(
    agents=[agent],
    tasks=[task],
    memory=True,
    short_term_memory=short_term,
    long_term_memory=long_term,
    entity_memory=entity_memory,
)
```

### Using External Memory

For cross-session persistence with goal awareness:

```python
from crewai.memory.external.external_memory import ExternalMemory
from mcal_crewai import MCALStorage

external = ExternalMemory(
    embedder_config={
        "provider": "mcal",
        "config": {
            "user_id": "john",
            "llm_provider": "anthropic",
            "enable_goal_tracking": True,
        }
    }
)

crew = Crew(
    agents=[...],
    tasks=[...],
    external_memory=external,
    process=Process.sequential,
)
```

## Features

### Goal-Aware Memory
Unlike basic memory systems, MCAL tracks user goals and priorities:

```python
storage = MCALStorage(
    type="long_term",
    user_id="project_manager",
    config={
        "enable_goal_tracking": True,
        "extract_priorities": True,
    }
)
```

### Context Preservation
MCAL maintains reasoning context across agent handoffs:

```python
# Agent 1 saves with context
await storage.save(
    "Research findings on market trends",
    metadata={
        "agent": "researcher",
        "goal": "market_analysis",
        "confidence": 0.95
    }
)

# Agent 2 retrieves with goal awareness
results = await storage.search(
    "What do we know about market trends?",
    limit=5,
    score_threshold=0.7
)
```

### TTL Support
Automatic expiration for short-term memories:

```python
storage = MCALStorage(
    type="short_term",
    user_id="session_user",
    default_ttl=3600,  # 1 hour
)
```

## Configuration

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `type` | str | required | Memory type: "short_term", "long_term", "entities", "external" |
| `user_id` | str | "default" | User identifier for memory isolation |
| `llm_provider` | str | "anthropic" | LLM for goal extraction |
| `embedding_provider` | str | "openai" | Embedding model provider |
| `default_ttl` | int | None | Default TTL in seconds |
| `enable_goal_tracking` | bool | True | Enable goal extraction |

## API Reference

### MCALStorage

```python
class MCALStorage(Storage):
    """MCAL storage backend for CrewAI memory."""
    
    def save(self, value: Any, metadata: dict) -> None:
        """Save value with goal-aware processing."""
    
    def search(
        self, 
        query: str, 
        limit: int = 5, 
        score_threshold: float = 0.6
    ) -> list:
        """Search with goal-aware relevance."""
    
    def reset(self) -> None:
        """Clear all stored memories."""
```

## Comparison with Mem0

| Feature | Mem0 | MCAL |
|---------|------|------|
| Basic Memory | ✓ | ✓ |
| Goal Tracking | ✗ | ✓ |
| Priority Extraction | ✗ | ✓ |
| Context Preservation | ✗ | ✓ |
| TTL Support | ✗ | ✓ |
| Local Storage | ✓ | ✓ |
| Cloud API | ✓ | Coming |

## License

MIT License
