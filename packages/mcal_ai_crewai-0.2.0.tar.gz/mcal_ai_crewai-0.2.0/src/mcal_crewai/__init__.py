"""
MCAL CrewAI Integration

Goal-aware memory for CrewAI agent crews.

Usage:
    from mcal_crewai import MCALStorage
    
    storage = MCALStorage(type="short_term", user_id="john")
    
    # Use with CrewAI memory
    from crewai.memory.short_term.short_term_memory import ShortTermMemory
    memory = ShortTermMemory(storage=storage)
"""

from mcal_crewai.storage import MCALStorage

__version__ = "0.1.0"

__all__ = [
    "MCALStorage",
    "__version__",
]
