"""
MCAL Storage Backend for CrewAI

Implements CrewAI's Storage interface with goal-aware memory.
"""

from __future__ import annotations

import threading
import time
from collections.abc import Iterable
from typing import Any, Optional


def _get_mcal(
    llm_provider: str = "anthropic",
    embedding_provider: str = "openai",
    storage_path: Optional[str] = None,
    **kwargs
) -> Any:
    """Get or create MCAL instance via the official singleton factory (Issue #106)."""
    from mcal import get_mcal
    return get_mcal(
        storage_path=storage_path,
        llm_provider=llm_provider,
        embedding_provider=embedding_provider,
        **kwargs
    )


class MCALStorage:
    """
    MCAL storage backend for CrewAI memory.
    
    This class implements CrewAI's Storage interface, providing
    goal-aware memory with context preservation for agent crews.
    
    Compatible with:
    - ShortTermMemory
    - LongTermMemory  
    - EntityMemory
    - ExternalMemory
    
    Usage:
        from mcal_crewai import MCALStorage
        from crewai.memory.short_term.short_term_memory import ShortTermMemory
        
        storage = MCALStorage(type="short_term", user_id="john")
        memory = ShortTermMemory(storage=storage)
        
    Args:
        type: Memory type - "short_term", "long_term", "entities", "external"
        crew: Optional CrewAI Crew instance
        config: Configuration dictionary with MCAL options
        user_id: User identifier for memory isolation
        default_ttl: Default TTL in seconds for memory items
        enable_goal_tracking: Whether to extract goals from content
    """
    
    SUPPORTED_TYPES = {"short_term", "long_term", "entities", "external"}
    
    def __init__(
        self,
        type: str,
        crew: Any = None,
        config: Optional[dict] = None,
        user_id: str = "default",
        default_ttl: Optional[int] = None,
        enable_goal_tracking: bool = True,
        **kwargs
    ):
        # Validate type
        if type not in self.SUPPORTED_TYPES:
            raise ValueError(
                f"Invalid type '{type}'. Must be one of: {', '.join(self.SUPPORTED_TYPES)}"
            )
        
        self.memory_type = type
        self.crew = crew
        self.config = config or {}
        # user_id priority: explicit param > config > default
        self.user_id = user_id if user_id != "default" else self.config.get("user_id", user_id)
        self.default_ttl = default_ttl
        self.enable_goal_tracking = enable_goal_tracking
        
        # Extract config values
        self.llm_provider = self.config.get("llm_provider", "anthropic")
        self.embedding_provider = self.config.get("embedding_provider", "openai")
        self.storage_path = self.config.get("storage_path")
        
        # TTL tracking (lazy expiration)
        self._ttl: dict[str, int] = {}  # key -> ttl_seconds
        self._expires_at: dict[str, float] = {}  # key -> expiration_timestamp
        
        # Thread safety
        self._lock = threading.RLock()
        
        # Internal storage (in-memory for now, will use MCAL graph later)
        self._data: dict[str, dict[str, Any]] = {}
        
        # MCAL instance (lazy loaded)
        self._mcal: Optional[Any] = None
    
    @property
    def mcal(self) -> Any:
        """Lazy load MCAL instance."""
        if self._mcal is None:
            self._mcal = _get_mcal(
                llm_provider=self.llm_provider,
                embedding_provider=self.embedding_provider,
                storage_path=self.storage_path,
            )
        return self._mcal
    
    def _generate_key(self, value: Any, metadata: dict) -> str:
        """Generate a unique key for storage."""
        import hashlib
        content = str(value) + str(metadata)
        return hashlib.sha256(content.encode()).hexdigest()[:16]
    
    def _is_expired(self, key: str) -> bool:
        """Check if a key has expired."""
        if key not in self._expires_at:
            return False
        return time.time() > self._expires_at[key]
    
    def _set_ttl(self, key: str, ttl: Optional[int] = None) -> None:
        """Set TTL for a key."""
        ttl_value = ttl or self.default_ttl
        if ttl_value is not None:
            self._ttl[key] = ttl_value
            self._expires_at[key] = time.time() + ttl_value
    
    def _cleanup_expired(self) -> None:
        """Remove expired entries (lazy cleanup)."""
        expired_keys = [
            key for key in self._expires_at 
            if time.time() > self._expires_at[key]
        ]
        for key in expired_keys:
            self._data.pop(key, None)
            self._ttl.pop(key, None)
            self._expires_at.pop(key, None)
    
    def _extract_last_content(
        self, 
        messages: Iterable[dict[str, Any]], 
        role: str
    ) -> str:
        """Extract last message content for a given role."""
        return next(
            (
                m.get("content", "")
                for m in reversed(list(messages))
                if m.get("role") == role
            ),
            "",
        )
    
    def _get_agent_name(self) -> str:
        """Get current agent name from crew context."""
        if self.crew and hasattr(self.crew, "_current_agent"):
            agent = self.crew._current_agent
            if agent and hasattr(agent, "role"):
                return str(agent.role)
        return self.config.get("agent_id", "default_agent")
    
    def save(self, value: Any, metadata: dict[str, Any]) -> None:
        """
        Save a value to MCAL storage.
        
        Args:
            value: The content to save (string, dict, or conversation)
            metadata: Additional metadata (agent, task, etc.)
        """
        with self._lock:
            # Generate key
            key = self._generate_key(value, metadata)
            
            # Process value based on type
            if isinstance(value, dict) and "messages" in value:
                # Conversation format
                messages = value.get("messages", [])
                content = self._extract_last_content(messages, "assistant")
                if not content:
                    content = self._extract_last_content(messages, "user")
            elif isinstance(value, str):
                content = value
            else:
                content = str(value)
            
            # Build storage entry
            entry = {
                "content": content,
                "raw_value": value,
                "metadata": {
                    "type": self.memory_type,
                    "user_id": self.user_id,
                    "agent": self._get_agent_name(),
                    "timestamp": time.time(),
                    **metadata,
                },
            }
            
            # Extract goals if enabled
            if self.enable_goal_tracking and content:
                entry["metadata"]["goal_tracked"] = True
                # TODO: Use MCAL's goal extraction when integrated
                # goals = self.mcal.extract_goals(content)
                # entry["metadata"]["goals"] = goals
            
            # Store with TTL
            self._data[key] = entry
            
            # Set TTL if configured
            ttl = metadata.get("ttl") or self.default_ttl
            if ttl:
                self._set_ttl(key, ttl)
            
            # Short-term memory gets default TTL if not set
            if self.memory_type == "short_term" and key not in self._ttl:
                self._set_ttl(key, 3600)  # 1 hour default for short-term
    
    def search(
        self, 
        query: str, 
        limit: int = 5, 
        score_threshold: float = 0.6
    ) -> list[Any]:
        """
        Search storage for relevant content.
        
        Args:
            query: Search query
            limit: Maximum results to return
            score_threshold: Minimum relevance score (0-1)
            
        Returns:
            List of matching results with 'content' key
        """
        with self._lock:
            # Cleanup expired entries
            self._cleanup_expired()
            
            # Simple keyword-based search for now
            # TODO: Use MCAL's semantic search when integrated
            results = []
            query_lower = query.lower()
            query_words = set(query_lower.split())
            
            for key, entry in self._data.items():
                # Skip expired
                if self._is_expired(key):
                    continue
                
                content = entry.get("content", "")
                content_lower = content.lower()
                
                # Calculate simple relevance score
                content_words = set(content_lower.split())
                overlap = query_words & content_words
                
                if overlap:
                    score = len(overlap) / max(len(query_words), 1)
                    
                    if score >= score_threshold:
                        results.append({
                            "content": content,
                            "memory": content,  # Compatibility with Mem0 format
                            "score": score,
                            "metadata": entry.get("metadata", {}),
                        })
            
            # Sort by score and limit
            results.sort(key=lambda x: x["score"], reverse=True)
            return results[:limit]
    
    def reset(self) -> None:
        """Clear all stored memories for this type."""
        with self._lock:
            self._data.clear()
            self._ttl.clear()
            self._expires_at.clear()
    
    def get_all(self) -> list[dict[str, Any]]:
        """Get all non-expired entries."""
        with self._lock:
            self._cleanup_expired()
            return [
                entry for key, entry in self._data.items()
                if not self._is_expired(key)
            ]
    
    def delete(self, key: str) -> bool:
        """Delete a specific entry by key."""
        with self._lock:
            if key in self._data:
                del self._data[key]
                self._ttl.pop(key, None)
                self._expires_at.pop(key, None)
                return True
            return False


# Alias for backward compatibility
MCALMemoryStorage = MCALStorage
