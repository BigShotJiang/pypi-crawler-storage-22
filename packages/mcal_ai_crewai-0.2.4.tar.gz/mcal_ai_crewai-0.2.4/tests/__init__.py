"""Tests for mcal-crewai package."""
