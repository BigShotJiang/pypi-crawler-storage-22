"""
Tests for MCALStorage - CrewAI Storage backend.
"""

import pytest
import time
from unittest.mock import MagicMock, patch

from mcal_crewai import MCALStorage


class TestMCALStorageInit:
    """Test MCALStorage initialization."""
    
    def test_init_with_valid_type(self):
        """Test initialization with valid memory types."""
        for memory_type in ["short_term", "long_term", "entities", "external"]:
            storage = MCALStorage(type=memory_type)
            assert storage.memory_type == memory_type
    
    def test_init_with_invalid_type(self):
        """Test initialization with invalid type raises error."""
        with pytest.raises(ValueError, match="Invalid type"):
            MCALStorage(type="invalid_type")
    
    def test_init_with_user_id(self):
        """Test initialization with user_id."""
        storage = MCALStorage(type="short_term", user_id="test_user")
        assert storage.user_id == "test_user"
    
    def test_init_with_config_user_id(self):
        """Test user_id from config."""
        storage = MCALStorage(
            type="short_term",
            config={"user_id": "config_user"}
        )
        assert storage.user_id == "config_user"
    
    def test_init_with_default_ttl(self):
        """Test initialization with default TTL."""
        storage = MCALStorage(type="short_term", default_ttl=3600)
        assert storage.default_ttl == 3600
    
    def test_init_goal_tracking_enabled(self):
        """Test goal tracking is enabled by default."""
        storage = MCALStorage(type="short_term")
        assert storage.enable_goal_tracking is True
    
    def test_init_goal_tracking_disabled(self):
        """Test goal tracking can be disabled."""
        storage = MCALStorage(type="short_term", enable_goal_tracking=False)
        assert storage.enable_goal_tracking is False


class TestMCALStorageSave:
    """Test MCALStorage save operations."""
    
    def test_save_string_value(self):
        """Test saving a simple string."""
        storage = MCALStorage(type="long_term", user_id="test")
        storage.save("Test content", {"agent": "researcher"})
        
        results = storage.get_all()
        assert len(results) == 1
        assert results[0]["content"] == "Test content"
    
    def test_save_with_metadata(self):
        """Test metadata is preserved."""
        storage = MCALStorage(type="long_term", user_id="test")
        storage.save("Content", {"agent": "writer", "task": "summarize"})
        
        results = storage.get_all()
        assert results[0]["metadata"]["agent"] == "writer"
        assert results[0]["metadata"]["task"] == "summarize"
    
    def test_save_conversation_format(self):
        """Test saving conversation format (messages list)."""
        storage = MCALStorage(type="short_term", user_id="test")
        
        conversation = {
            "messages": [
                {"role": "user", "content": "What is the weather?"},
                {"role": "assistant", "content": "It's sunny today."}
            ]
        }
        storage.save(conversation, {})
        
        results = storage.get_all()
        assert len(results) == 1
        assert "sunny" in results[0]["content"]
    
    def test_save_with_explicit_ttl(self):
        """Test saving with explicit TTL in metadata."""
        storage = MCALStorage(type="short_term", user_id="test")
        storage.save("Temporary", {"ttl": 60})
        
        # Check TTL was set
        assert len(storage._ttl) == 1
        assert len(storage._expires_at) == 1


class TestMCALStorageSearch:
    """Test MCALStorage search operations."""
    
    def test_search_finds_matching_content(self):
        """Test search finds relevant content."""
        storage = MCALStorage(type="long_term", user_id="test")
        storage.save("Python is a programming language", {})
        storage.save("JavaScript runs in browsers", {})
        
        results = storage.search("Python programming")
        assert len(results) >= 1
        assert "Python" in results[0]["content"]
    
    def test_search_respects_limit(self):
        """Test search respects limit parameter."""
        storage = MCALStorage(type="long_term", user_id="test")
        for i in range(10):
            storage.save(f"Document {i} about Python", {})
        
        results = storage.search("Python", limit=3)
        assert len(results) <= 3
    
    def test_search_returns_empty_for_no_match(self):
        """Test search returns empty for no matches."""
        storage = MCALStorage(type="long_term", user_id="test")
        storage.save("Python is great", {})
        
        results = storage.search("completely unrelated xyz")
        assert len(results) == 0
    
    def test_search_includes_score(self):
        """Test search results include relevance score."""
        storage = MCALStorage(type="long_term", user_id="test")
        storage.save("Python programming tutorial", {})
        
        results = storage.search("Python programming")
        assert len(results) >= 1
        assert "score" in results[0]
        assert 0 <= results[0]["score"] <= 1
    
    def test_search_skips_expired_content(self):
        """Test search skips expired content."""
        storage = MCALStorage(type="short_term", user_id="test")
        
        # Save with very short TTL
        storage.save("Expired content about cats", {"ttl": 1})
        storage.save("Valid content about dogs", {})
        
        # Wait for expiration
        time.sleep(1.1)
        
        results = storage.search("cats dogs")
        # Should only find dogs, not cats
        for result in results:
            assert "cats" not in result["content"].lower()


class TestMCALStorageTTL:
    """Test TTL (Time-To-Live) functionality."""
    
    def test_ttl_expiration(self):
        """Test items expire after TTL."""
        storage = MCALStorage(type="short_term", default_ttl=1)
        storage.save("Temporary data", {})
        
        # Should exist initially
        assert len(storage.get_all()) == 1
        
        # Wait for expiration
        time.sleep(1.1)
        
        # Should be gone
        assert len(storage.get_all()) == 0
    
    def test_no_ttl_means_no_expiration(self):
        """Test items without TTL don't expire."""
        storage = MCALStorage(type="long_term")  # No default_ttl
        storage.save("Permanent data", {})
        
        # Should persist
        assert len(storage.get_all()) == 1
        
        # Clear TTL tracking to ensure no expiration
        storage._expires_at.clear()
        
        time.sleep(0.1)
        assert len(storage.get_all()) == 1
    
    def test_short_term_gets_default_ttl(self):
        """Test short_term memory gets default TTL."""
        storage = MCALStorage(type="short_term")
        storage.save("Short term data", {})
        
        # Should have TTL set (1 hour default)
        assert len(storage._ttl) == 1


class TestMCALStorageReset:
    """Test reset functionality."""
    
    def test_reset_clears_all_data(self):
        """Test reset clears all stored data."""
        storage = MCALStorage(type="long_term", user_id="test")
        storage.save("Data 1", {})
        storage.save("Data 2", {})
        
        assert len(storage.get_all()) == 2
        
        storage.reset()
        
        assert len(storage.get_all()) == 0
    
    def test_reset_clears_ttl_tracking(self):
        """Test reset clears TTL tracking."""
        storage = MCALStorage(type="short_term", default_ttl=3600)
        storage.save("Data", {})
        
        assert len(storage._ttl) == 1
        assert len(storage._expires_at) == 1
        
        storage.reset()
        
        assert len(storage._ttl) == 0
        assert len(storage._expires_at) == 0


class TestMCALStorageDelete:
    """Test delete functionality."""
    
    def test_delete_existing_key(self):
        """Test deleting an existing key."""
        storage = MCALStorage(type="long_term")
        storage.save("Test data", {})
        
        keys = list(storage._data.keys())
        assert len(keys) == 1
        
        result = storage.delete(keys[0])
        assert result is True
        assert len(storage.get_all()) == 0
    
    def test_delete_nonexistent_key(self):
        """Test deleting a nonexistent key."""
        storage = MCALStorage(type="long_term")
        
        result = storage.delete("nonexistent_key")
        assert result is False


class TestMCALStorageThreadSafety:
    """Test thread safety."""
    
    def test_storage_has_lock(self):
        """Test storage has RLock for thread safety."""
        storage = MCALStorage(type="long_term")
        assert hasattr(storage, "_lock")
        assert isinstance(storage._lock, type(storage._lock))


class TestMCALStorageMemoryFormat:
    """Test compatibility with CrewAI memory format."""
    
    def test_search_returns_memory_key(self):
        """Test search results have 'memory' key for Mem0 compatibility."""
        storage = MCALStorage(type="long_term")
        storage.save("Test content for memory", {})
        
        results = storage.search("memory")
        assert len(results) >= 1
        assert "memory" in results[0]
        assert results[0]["memory"] == results[0]["content"]


class TestMCALStorageMetadataExtraction:
    """Test metadata extraction."""
    
    def test_metadata_includes_type(self):
        """Test metadata includes memory type."""
        storage = MCALStorage(type="entities")
        storage.save("Entity data", {})
        
        results = storage.get_all()
        assert results[0]["metadata"]["type"] == "entities"
    
    def test_metadata_includes_user_id(self):
        """Test metadata includes user_id."""
        storage = MCALStorage(type="long_term", user_id="john")
        storage.save("User data", {})
        
        results = storage.get_all()
        assert results[0]["metadata"]["user_id"] == "john"
    
    def test_metadata_includes_timestamp(self):
        """Test metadata includes timestamp."""
        storage = MCALStorage(type="long_term")
        storage.save("Timestamped data", {})
        
        results = storage.get_all()
        assert "timestamp" in results[0]["metadata"]
        assert results[0]["metadata"]["timestamp"] > 0


class TestMCALStorageBackwardCompatibility:
    """Test backward compatibility."""
    
    def test_alias_exists(self):
        """Test MCALMemoryStorage alias exists."""
        from mcal_crewai.storage import MCALMemoryStorage
        assert MCALMemoryStorage is MCALStorage
