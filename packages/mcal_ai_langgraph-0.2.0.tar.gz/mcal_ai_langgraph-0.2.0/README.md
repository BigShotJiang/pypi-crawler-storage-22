# mcal-langgraph

LangGraph integration for [MCAL](https://github.com/Shivakoreddi/mcla-research) - Goal-aware memory for AI agents.

## Installation

```bash
pip install mcal-langgraph
```

This will automatically install `mcal` and `langgraph` as dependencies.

## Quick Start

```python
from mcal import MCAL
from mcal_langgraph import MCALStore

# Initialize MCAL with a goal
mcal = MCAL(goal="Build a fraud detection system")

# Create LangGraph-compatible store
store = MCALStore(mcal)

# Use with LangGraph
from langgraph.prebuilt import create_react_agent

agent = create_react_agent(
    model=your_model,
    tools=your_tools,
    store=store  # Goal-aware memory!
)
```

## Features

### MCALStore (BaseStore)

Drop-in replacement for LangGraph's built-in stores with **goal-aware** memory:

```python
from mcal_langgraph import MCALStore

store = MCALStore(mcal)

# Store memories
await store.aput(
    namespace=("user_123", "memories"),
    key="decision_1",
    value={"text": "Decided to use PostgreSQL for ACID compliance"}
)

# Goal-aware search - returns memories relevant to current goals
results = await store.asearch(
    namespace_prefix=("user_123",),
    query="database choice"
)

# Results include goal context and decisions
for item in results:
    print(item.value["goals"])      # Related goals
    print(item.value["decisions"])  # Related decisions
```

### MCALMemory

Memory nodes for custom LangGraph workflows:

```python
from mcal_langgraph import MCALMemory

memory = MCALMemory(llm_provider="anthropic")

# Add as nodes in your graph
graph.add_node("update_memory", memory.update_node())
graph.add_node("get_context", memory.context_node())
```

### MCALCheckpointer

State persistence for LangGraph graphs:

```python
from mcal_langgraph import MCALCheckpointer

checkpointer = MCALCheckpointer(mcal)
graph = builder.compile(checkpointer=checkpointer)
```

## Why mcal-langgraph?

| Feature | LangGraph InMemoryStore | **MCALStore** |
|---------|------------------------|---------------|
| BaseStore interface | ✅ | ✅ |
| Namespace organization | ✅ | ✅ |
| **Goal-aware search** | ❌ | ✅ |
| **Decision tracking** | ❌ | ✅ |
| **Intent preservation** | ❌ | ✅ |

## Migrating from mcal[langgraph]

If you were using the old extras-based installation:

```python
# Old way (deprecated)
from mcal.integrations.langgraph import MCALStore

# New way (recommended)
from mcal_langgraph import MCALStore
```

The old import path still works but will show a deprecation warning.

## License

MIT
