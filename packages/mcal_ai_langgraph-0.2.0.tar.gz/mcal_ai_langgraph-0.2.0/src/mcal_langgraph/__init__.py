"""
mcal-langgraph: LangGraph integration for MCAL

Provides goal-aware memory for LangGraph agent workflows:
- MCALStore: BaseStore implementation with goal-aware search
- MCALMemory: Memory nodes for LangGraph workflows  
- MCALCheckpointer: State persistence for graphs

Installation:
    pip install mcal-langgraph

Usage:
    from mcal import MCAL
    from mcal_langgraph import MCALStore
    
    mcal = MCAL(goal="Build fraud detection system")
    store = MCALStore(mcal)
    
    # Use with LangGraph
    from langgraph.prebuilt import create_react_agent
    agent = create_react_agent(model, tools, store=store)
"""

from mcal_langgraph.store import MCALStore
from mcal_langgraph.memory import MCALMemory, MCALMemoryConfig
from mcal_langgraph.checkpointer import MCALCheckpointer
from mcal_langgraph._compat import LANGGRAPH_AVAILABLE

# Version
__version__ = "0.1.0"

__all__ = [
    "MCALStore",
    "MCALMemory",
    "MCALMemoryConfig",
    "MCALCheckpointer",
    "LANGGRAPH_AVAILABLE",
    "__version__",
]
