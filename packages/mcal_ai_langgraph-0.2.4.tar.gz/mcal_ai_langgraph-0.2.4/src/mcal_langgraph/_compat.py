"""
Compatibility layer for LangGraph imports.

Handles graceful degradation when langgraph is not installed.
"""

from __future__ import annotations
from typing import Any

# Check for LangGraph availability
try:
    from langgraph.graph import StateGraph
    from langgraph.checkpoint.base import BaseCheckpointSaver
    from langgraph.store.base import (
        BaseStore,
        Item,
        SearchItem,
        GetOp,
        PutOp,
        SearchOp,
        ListNamespacesOp,
        NamespacePath,
    )
    from langchain_core.messages import BaseMessage, HumanMessage, AIMessage
    
    LANGGRAPH_AVAILABLE = True
except ImportError:
    LANGGRAPH_AVAILABLE = False
    StateGraph = None
    BaseCheckpointSaver = object
    BaseStore = object
    Item = None
    SearchItem = None
    GetOp = None
    PutOp = None
    SearchOp = None
    ListNamespacesOp = None
    NamespacePath = None
    BaseMessage = Any
    HumanMessage = Any
    AIMessage = Any


def check_langgraph():
    """Raise helpful error if LangGraph not installed."""
    if not LANGGRAPH_AVAILABLE:
        raise ImportError(
            "mcal-langgraph requires langgraph package.\n"
            "Install with: pip install mcal-langgraph\n"
            "Or manually: pip install langgraph langchain-core"
        )


# Export everything needed by other modules
__all__ = [
    "LANGGRAPH_AVAILABLE",
    "check_langgraph",
    "StateGraph",
    "BaseCheckpointSaver",
    "BaseStore",
    "Item",
    "SearchItem",
    "GetOp",
    "PutOp",
    "SearchOp",
    "ListNamespacesOp",
    "NamespacePath",
    "BaseMessage",
    "HumanMessage",
    "AIMessage",
]
