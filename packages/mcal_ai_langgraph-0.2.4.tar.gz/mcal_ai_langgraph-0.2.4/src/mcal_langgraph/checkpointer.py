"""
MCALCheckpointer: State persistence for LangGraph graphs.

Stores graph state alongside MCAL memory for unified persistence.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from mcal_langgraph._compat import (
    check_langgraph,
    LANGGRAPH_AVAILABLE,
    BaseCheckpointSaver,
)


class MCALCheckpointer(BaseCheckpointSaver if LANGGRAPH_AVAILABLE else object):
    """
    MCAL-based checkpointer for LangGraph state persistence.
    
    Stores graph state alongside MCAL memory for unified persistence.
    
    Usage:
        from mcal_langgraph import MCALCheckpointer
        
        checkpointer = MCALCheckpointer(storage_path="~/.mcal")
        graph = StateGraph(...).compile(checkpointer=checkpointer)
    """
    
    def __init__(self, storage_path: Optional[str] = None):
        check_langgraph()
        if LANGGRAPH_AVAILABLE:
            super().__init__()
        self.storage_path = storage_path
        self._checkpoints: Dict[str, Any] = {}
    
    def get(self, config: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Get checkpoint by config."""
        thread_id = config.get("configurable", {}).get("thread_id", "default")
        return self._checkpoints.get(thread_id)
    
    def put(self, config: Dict[str, Any], checkpoint: Dict[str, Any]) -> None:
        """Save checkpoint."""
        thread_id = config.get("configurable", {}).get("thread_id", "default")
        self._checkpoints[thread_id] = checkpoint
    
    def list(self, config: Dict[str, Any]) -> List[Dict[str, Any]]:
        """List all checkpoints."""
        return list(self._checkpoints.values())


__all__ = ["MCALCheckpointer"]
