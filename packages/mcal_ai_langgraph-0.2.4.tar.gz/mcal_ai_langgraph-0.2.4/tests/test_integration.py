#!/usr/bin/env python
"""Quick integration test for mcal-langgraph package."""

# Test the new package import
from mcal_langgraph import MCALStore, MCALMemory, MCALCheckpointer, LANGGRAPH_AVAILABLE
print('✅ New package imports work')
print(f'   LANGGRAPH_AVAILABLE: {LANGGRAPH_AVAILABLE}')

# Test backward compatibility (should emit warning)
import warnings
with warnings.catch_warnings(record=True) as w:
    warnings.simplefilter('always')
    from mcal.integrations.langgraph import MCALStore as OldStore
    if any(issubclass(x.category, DeprecationWarning) for x in w):
        print('✅ Deprecation warning emitted for old import')
    print(f'   OldStore is same as new: {OldStore is MCALStore}')

# Test basic functionality
from mcal import MCAL
from unittest.mock import MagicMock, AsyncMock

mock_mcal = MagicMock()
mock_mcal.add = AsyncMock()
mock_mcal.search = AsyncMock()

store = MCALStore(mock_mcal)
print('✅ MCALStore created successfully')
print(f'   Has thread lock: {hasattr(store, "_lock")}')

# Test sync operations
store.put(('user_1',), 'key1', {'text': 'hello'})
item = store.get(('user_1',), 'key1')
print(f'✅ Put/Get works: {item.value}')

# Test search
results = store.search(('user_1',))
print(f'✅ Search works: {len(results)} results')

print()
print('🎉 All integration tests passed!')
