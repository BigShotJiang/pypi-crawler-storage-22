"""Test configuration constants."""

from mcard.config.config_constants import (
    DEFAULT_DB_PATH,
    DEFAULT_POOL_SIZE,
    DEFAULT_TIMEOUT,
    ENV_DB_PATH,
    ENV_DB_TIMEOUT,
    ENV_HASH_ALGORITHM,
    ENV_HASH_CUSTOM_FUNCTION,
    ENV_HASH_CUSTOM_LENGTH,
    ENV_HASH_CUSTOM_MODULE,
    ENV_SERVICE_LOG_LEVEL,
    TEST_DB_PATH,
)


def test_config_constants():
    """Test that configuration constants are defined correctly."""
    # Test database paths
    assert isinstance(DEFAULT_DB_PATH, str)
    assert isinstance(TEST_DB_PATH, str)
    assert DEFAULT_DB_PATH.endswith(".db")
    assert TEST_DB_PATH.endswith(".db")

    # Test pool and timeout settings
    assert isinstance(DEFAULT_POOL_SIZE, int)
    assert isinstance(DEFAULT_TIMEOUT, (int, float))
    assert DEFAULT_POOL_SIZE > 0
    assert DEFAULT_TIMEOUT > 0

    # Test environment variable names
    assert isinstance(ENV_DB_PATH, str)
    assert isinstance(ENV_DB_TIMEOUT, str)
    assert isinstance(ENV_SERVICE_LOG_LEVEL, str)
    assert isinstance(ENV_HASH_ALGORITHM, str)
    assert isinstance(ENV_HASH_CUSTOM_MODULE, str)
    assert isinstance(ENV_HASH_CUSTOM_FUNCTION, str)
    assert isinstance(ENV_HASH_CUSTOM_LENGTH, str)

    # Test environment variable name format
    env_vars = [
        ENV_DB_PATH,
        ENV_DB_TIMEOUT,
        ENV_SERVICE_LOG_LEVEL,
        ENV_HASH_ALGORITHM,
        ENV_HASH_CUSTOM_MODULE,
        ENV_HASH_CUSTOM_FUNCTION,
        ENV_HASH_CUSTOM_LENGTH,
    ]
    for var in env_vars:
        assert var.isupper()  # Environment variables should be uppercase
        assert "_" in var  # Should use snake_case
        assert not var.startswith("_")  # Should not start with underscore
        assert not var.endswith("_")  # Should not end with underscore
