from mcard.model.g_time import GTime
from mcard.model.hash.validator import HashAlgorithm


def test_stamp_now():
    g_time = GTime.stamp_now(HashAlgorithm.DEFAULT.value)
    assert isinstance(g_time, str)
    assert (
        len(g_time.split("|")) == 3
    )  # Should contain hash_function, timestamp, and region code


def test_default_hash_function():
    g_time = GTime.stamp_now(HashAlgorithm.DEFAULT.value)
    assert g_time.startswith(
        HashAlgorithm.DEFAULT.value
    )  # Assuming sha256 is the default hash function


def test_region_code():
    g_time = GTime.stamp_now(HashAlgorithm.DEFAULT.value)
    region_code = g_time.split("|")[-1]  # Get the region code from the formatted string
    assert region_code.isupper()  # Region code should be uppercase
    assert len(region_code) > 0  # Ensure region code is not empty


def test_get_hash_function():
    formatted_string = HashAlgorithm.DEFAULT.value + "|2024-12-17T01:40:19+08:00|SGT"
    assert GTime.get_hash_function(formatted_string) == HashAlgorithm.DEFAULT


def test_get_timestamp():
    formatted_string = HashAlgorithm.DEFAULT.value + "|2024-12-17T01:40:19+08:00|SGT"
    assert GTime.get_timestamp(formatted_string) == "2024-12-17T01:40:19+08:00"


def test_get_region_code():
    formatted_string = HashAlgorithm.DEFAULT.value + "|2024-12-17T01:40:19+08:00|SGT"
    assert GTime.get_region_code(formatted_string) == "SGT"
