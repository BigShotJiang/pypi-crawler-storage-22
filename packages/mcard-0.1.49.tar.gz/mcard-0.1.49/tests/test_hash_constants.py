"""Test hash-related constants."""

from mcard.model.hash.constants import (
    HASH_ALGORITHM_HIERARCHY,
    KNOWN_MD5_COLLISION_PAIRS,
)
from mcard.model.hash.enums import HashAlgorithm


def test_hash_algorithm_hierarchy():
    """Test the hash algorithm hierarchy."""
    # Test that hierarchy is a dictionary
    assert isinstance(HASH_ALGORITHM_HIERARCHY, dict)

    # Test that all hash algorithms are in the hierarchy
    all_algorithms = set(HashAlgorithm) - {HashAlgorithm.CUSTOM}
    hierarchy_algorithms = set()
    for alg in HASH_ALGORITHM_HIERARCHY.keys():
        hierarchy_algorithms.add(alg)
        hierarchy_algorithms.update(HASH_ALGORITHM_HIERARCHY[alg])
    assert all_algorithms == hierarchy_algorithms

    # Test specific hierarchy relationships
    assert HashAlgorithm.SHA512 in HASH_ALGORITHM_HIERARCHY[HashAlgorithm.SHA256]
    assert HashAlgorithm.SHA256 in HASH_ALGORITHM_HIERARCHY[HashAlgorithm.SHA1]
    assert HashAlgorithm.SHA1 in HASH_ALGORITHM_HIERARCHY[HashAlgorithm.MD5]

    # Test that CUSTOM is not in any hierarchy
    for alg, stronger_algs in HASH_ALGORITHM_HIERARCHY.items():
        assert HashAlgorithm.CUSTOM not in stronger_algs
    assert HashAlgorithm.CUSTOM not in HASH_ALGORITHM_HIERARCHY


def test_known_md5_collision_pairs():
    """Test the known MD5 collision pairs."""
    # Test that collision pairs is a list of tuples
    assert isinstance(KNOWN_MD5_COLLISION_PAIRS, list)
    for pair in KNOWN_MD5_COLLISION_PAIRS:
        assert isinstance(pair, tuple)
        assert len(pair) == 2
        assert isinstance(pair[0], bytes)
        assert isinstance(pair[1], bytes)

        # Test that pairs are different but have same length
        assert pair[0] != pair[1]
        assert len(pair[0]) == len(pair[1])

        # Test that pairs are not empty
        assert len(pair[0]) > 0
        assert len(pair[1]) > 0
