import pytest

from mcard.model.interpreter import ContentTypeInterpreter, ValidationError


def test_detect_mime_types():
    interpreter = ContentTypeInterpreter()
    # Test known signatures
    assert interpreter._detect_by_signature(b"\x89PNG\r\n\x1a\n") == "image/png"
    assert interpreter._detect_by_signature(b"\xff\xd8\xff") == "image/jpeg"
    assert interpreter._detect_by_signature(b"GIF87a") == "image/gif"
    assert interpreter._detect_by_signature(b"%PDF") == "application/pdf"
    assert interpreter._detect_by_signature(b"PK\x03\x04") == "application/zip"


def test_is_binary_content():
    interpreter = ContentTypeInterpreter()
    assert interpreter.is_binary_content(b"\x89PNG\r\n\x1a\n") is True
    assert interpreter.is_binary_content(b"Hello, World!") is False


def test_is_xml_content():
    interpreter = ContentTypeInterpreter()
    # Valid XML
    assert interpreter.is_xml_content(b'<?xml version="1.0"?><root></root>') is True
    assert interpreter.is_xml_content(b"<root></root>") is True
    # Invalid XML
    assert interpreter.is_xml_content(b"Not XML") is False
    assert interpreter.is_xml_content(b"<root><invalid>") is False


def test_is_svg_content():
    interpreter = ContentTypeInterpreter()
    assert interpreter.is_svg_content(b"<svg></svg>") is True
    assert interpreter.is_svg_content(b"Not SVG") is False


def test_get_extension():
    interpreter = ContentTypeInterpreter()
    assert interpreter.get_extension("image/png") == "png"
    assert interpreter.get_extension("application/pdf") == "pdf"


def test_validate_content():
    interpreter = ContentTypeInterpreter()
    # Test valid content
    valid_png = (
        b"\x89PNG\r\n\x1a\n" + b"\x00" * 1000
    )  # Valid PNG header + more dummy data
    assert interpreter.validate_content(valid_png) is None  # No exception
    # Test invalid content
    with pytest.raises(ValidationError):
        interpreter.validate_content(
            b"\x01\x02\x03\x04\x05"
        )  # Should raise on invalid binary
    with pytest.raises(ValidationError):
        interpreter.validate_content(b"\x89PNG\r\n\x1a\n")  # Truncated PNG
