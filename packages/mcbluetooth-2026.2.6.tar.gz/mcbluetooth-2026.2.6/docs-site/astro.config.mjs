// @ts-check
import { defineConfig } from 'astro/config';
import starlight from '@astrojs/starlight';
import icon from 'astro-icon';

// https://astro.build/config
export default defineConfig({
	// Site URL for sitemap generation
	site: 'https://mcbluetooth.example.com',

	// Disable telemetry
	telemetry: false,

	// Disable devToolbar
	devToolbar: { enabled: false },

	integrations: [
		icon(),
		starlight({
			title: 'mcbluetooth',
			description: 'Give LLMs control of your Linux Bluetooth stack',
			logo: {
				light: './src/assets/logo-light.svg',
				dark: './src/assets/logo-dark.svg',
				replacesTitle: false,
			},
			social: [
				{ icon: 'github', label: 'GitHub', href: 'https://github.com/yourusername/mcbluetooth' },
			],
			customCss: [
				'./src/styles/custom.css',
			],
			head: [
				// Favicon
				{ tag: 'link', attrs: { rel: 'icon', href: '/favicon.svg', type: 'image/svg+xml' } },
			],
			sidebar: [
				{
					label: 'Getting Started',
					items: [
						{ label: 'Introduction', slug: 'getting-started/introduction' },
						{ label: 'Installation', slug: 'getting-started/installation' },
						{ label: 'Quick Start', slug: 'getting-started/quick-start' },
					],
				},
				{
					label: 'Guides',
					items: [
						{ label: 'Adapter Management', slug: 'guides/adapters' },
						{ label: 'Device Pairing', slug: 'guides/pairing' },
						{ label: 'Audio Control', slug: 'guides/audio' },
						{ label: 'HFP Audio Gateway', slug: 'guides/hfp-ag' },
						{ label: 'BLE & GATT', slug: 'guides/ble' },
						{ label: 'OBEX File Transfer', slug: 'guides/obex' },
						{ label: 'Phonebook & Messages', slug: 'guides/phonebook-messages' },
						{ label: 'Protocol Capture', slug: 'guides/capture' },
					],
				},
				{
					label: 'Reference',
					items: [
						{ label: 'All Tools', slug: 'reference/tools' },
						{ label: 'Adapter Tools', slug: 'reference/adapter-tools' },
						{ label: 'Device Tools', slug: 'reference/device-tools' },
						{ label: 'Audio Tools', slug: 'reference/audio-tools' },
						{ label: 'HFP AG Tools', slug: 'reference/hfp-ag-tools' },
						{ label: 'BLE Tools', slug: 'reference/ble-tools' },
						{ label: 'OBEX Tools', slug: 'reference/obex-tools' },
						{ label: 'Monitor Tools', slug: 'reference/monitor-tools' },
						{ label: 'MCP Resources', slug: 'reference/resources' },
					],
				},
				{
					label: 'Explanation',
					items: [
						{ label: 'Architecture', slug: 'explanation/architecture' },
						{ label: 'Pairing Agent', slug: 'explanation/pairing-agent' },
						{ label: 'OBEX Profiles', slug: 'explanation/obex-profiles' },
					],
				},
			],
			editLink: {
				baseUrl: 'https://github.com/yourusername/mcbluetooth/edit/main/docs-site/',
			},
		}),
	],
});
