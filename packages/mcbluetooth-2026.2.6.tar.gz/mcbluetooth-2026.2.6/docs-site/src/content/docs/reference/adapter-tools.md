---
title: Adapter Tools
description: Reference for Bluetooth adapter management tools
---

Tools for managing Bluetooth hardware adapters.

## bt_list_adapters

List all Bluetooth adapters on the system.

**Parameters:** None

**Returns:**
```json
[
  {
    "name": "hci0",
    "address": "AA:BB:CC:DD:EE:FF",
    "alias": "My Laptop",
    "powered": true,
    "discoverable": false,
    "discoverable_timeout": 180,
    "pairable": true,
    "pairable_timeout": 0,
    "discovering": false
  }
]
```

**Example:**
```
bt_list_adapters
```

---

## bt_adapter_info

Get detailed information about a specific adapter.

**Parameters:**

| Name | Type | Required | Description |
|------|------|----------|-------------|
| `adapter` | string | Yes | Adapter name (e.g., "hci0") |

**Returns:**
```json
{
  "name": "hci0",
  "address": "AA:BB:CC:DD:EE:FF",
  "alias": "My Laptop",
  "class": 7995916,
  "powered": true,
  "discoverable": false,
  "discoverable_timeout": 180,
  "pairable": true,
  "pairable_timeout": 0,
  "discovering": false,
  "uuids": [
    "0000110a-0000-1000-8000-00805f9b34fb",
    "0000110c-0000-1000-8000-00805f9b34fb"
  ],
  "modalias": "usb:v1D6Bp0246d0540"
}
```

**Example:**
```
bt_adapter_info adapter="hci0"
```

---

## bt_adapter_power

Power an adapter on or off.

**Parameters:**

| Name | Type | Required | Description |
|------|------|----------|-------------|
| `adapter` | string | Yes | Adapter name |
| `on` | boolean | Yes | true to power on, false to power off |

**Returns:** Updated adapter info

**Example:**
```
bt_adapter_power adapter="hci0" on=true
```

**Notes:**
- Powering off disconnects all devices
- Stops any ongoing discovery

---

## bt_adapter_discoverable

Set adapter discoverable (visible to other devices).

**Parameters:**

| Name | Type | Required | Default | Description |
|------|------|----------|---------|-------------|
| `adapter` | string | Yes | - | Adapter name |
| `on` | boolean | Yes | - | Enable/disable discoverable |
| `timeout` | integer | No | 180 | Seconds until auto-hidden (0 = forever) |

**Returns:** Updated adapter info

**Example:**
```
# Discoverable for 5 minutes
bt_adapter_discoverable adapter="hci0" on=true timeout=300

# Discoverable forever (use carefully)
bt_adapter_discoverable adapter="hci0" on=true timeout=0

# Hide from other devices
bt_adapter_discoverable adapter="hci0" on=false
```

---

## bt_adapter_pairable

Set adapter pairable state.

**Parameters:**

| Name | Type | Required | Default | Description |
|------|------|----------|---------|-------------|
| `adapter` | string | Yes | - | Adapter name |
| `on` | boolean | Yes | - | Enable/disable pairing acceptance |
| `timeout` | integer | No | 0 | Seconds until auto-disable (0 = forever) |

**Returns:** Updated adapter info

**Example:**
```
# Accept pairings for 5 minutes
bt_adapter_pairable adapter="hci0" on=true timeout=300

# Stop accepting pairings
bt_adapter_pairable adapter="hci0" on=false
```

---

## bt_adapter_set_alias

Set adapter friendly name (alias).

**Parameters:**

| Name | Type | Required | Description |
|------|------|----------|-------------|
| `adapter` | string | Yes | Adapter name |
| `alias` | string | Yes | New friendly name |

**Returns:** Updated adapter info

**Example:**
```
bt_adapter_set_alias adapter="hci0" alias="Ryan's Desktop"
```

---

## bt_scan

Scan for nearby Bluetooth devices.

**Parameters:**

| Name | Type | Required | Default | Description |
|------|------|----------|---------|-------------|
| `adapter` | string | Yes | - | Adapter name |
| `timeout` | integer | No | 10 | Scan duration in seconds |
| `mode` | string | No | "both" | Scan mode: "classic", "ble", or "both" |

**Returns:**
```json
[
  {
    "address": "AA:BB:CC:DD:EE:FF",
    "name": "My Device",
    "alias": "My Device",
    "paired": false,
    "connected": false,
    "rssi": -65,
    "uuids": ["0000110a-..."],
    "manufacturer_data": {...},
    "service_data": {...}
  }
]
```

**Example:**
```
# Standard scan
bt_scan adapter="hci0" timeout=10

# BLE only
bt_scan adapter="hci0" timeout=15 mode="ble"

# Classic only (faster for headphones, speakers)
bt_scan adapter="hci0" timeout=10 mode="classic"
```

**Notes:**
- Starts discovery, waits for timeout, then stops
- BLE devices must be advertising to be found
- Returns devices discovered during the scan period
