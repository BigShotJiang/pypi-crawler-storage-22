---
title: Tools Overview
description: Complete reference for all mcbluetooth MCP tools
---

mcbluetooth provides **69 MCP tools** organized into functional categories.

## Tool Categories

| Category | Tools | Description |
|----------|-------|-------------|
| [Adapter](/reference/adapter-tools/) | 7 | Hardware adapter management |
| [Device](/reference/device-tools/) | 12 | Device discovery, pairing, connection |
| [Audio](/reference/audio-tools/) | 7 | PipeWire/PulseAudio integration |
| [HFP Audio Gateway](/reference/hfp-ag-tools/) | 8 | Phone role for headset testing |
| [BLE](/reference/ble-tools/) | 8 | Bluetooth Low Energy & GATT |
| [OBEX](/reference/obex-tools/) | 21 | File transfer, phonebook, messages |
| [Monitor](/reference/monitor-tools/) | 6 | Protocol capture & analysis |

## Tool Naming Convention

All tools follow the pattern `bt_<category>_<action>`:

```
bt_adapter_power      # Adapter category, power action
bt_ble_read           # BLE category, read action
bt_obex_connect       # OBEX category, connect action
```

## Common Parameters

### `adapter`

Most tools require an adapter name (e.g., `"hci0"`):

```
bt_scan adapter="hci0" timeout=10
```

Use `bt_list_adapters` to discover available adapters.

### `address`

Device Bluetooth MAC address in colon-separated format:

```
bt_connect adapter="hci0" address="AA:BB:CC:DD:EE:FF"
```

## Return Values

Tools return JSON objects with:

- **Success**: Operation-specific data
- **Errors**: `{"error": "description", "code": "ERROR_CODE"}`

## Quick Reference Table

### Adapter Tools

| Tool | Description |
|------|-------------|
| `bt_list_adapters` | List all Bluetooth adapters |
| `bt_adapter_info` | Get adapter details |
| `bt_adapter_power` | Turn adapter on/off |
| `bt_adapter_discoverable` | Set discoverable mode |
| `bt_adapter_pairable` | Set pairable mode |
| `bt_adapter_set_alias` | Set adapter name |
| `bt_scan` | Scan for devices |

### Device Tools

| Tool | Description |
|------|-------------|
| `bt_list_devices` | List known devices |
| `bt_device_info` | Get device details |
| `bt_device_set_alias` | Set device name |
| `bt_pair` | Initiate pairing |
| `bt_pair_confirm` | Confirm/reject pairing |
| `bt_pairing_status` | Check pending pairings |
| `bt_unpair` | Remove pairing |
| `bt_connect` | Connect to device |
| `bt_disconnect` | Disconnect device |
| `bt_trust` | Set trust status |
| `bt_block` | Block/unblock device |

### Audio Tools

| Tool | Description |
|------|-------------|
| `bt_audio_list` | List audio devices |
| `bt_audio_connect` | Connect audio profiles |
| `bt_audio_disconnect` | Disconnect audio |
| `bt_audio_set_profile` | Switch A2DP/HFP |
| `bt_audio_set_default` | Set default output |
| `bt_audio_volume` | Adjust volume |
| `bt_audio_mute` | Mute/unmute |

### HFP Audio Gateway Tools

| Tool | Description |
|------|-------------|
| `bt_hfp_ag_enable` | Register AG profile with BlueZ |
| `bt_hfp_ag_disable` | Unregister AG profile |
| `bt_hfp_ag_status` | Get connections and indicators |
| `bt_hfp_ag_simulate_call` | Simulate incoming call |
| `bt_hfp_ag_end_call` | End active/ringing call |
| `bt_hfp_ag_set_volume` | Set speaker/mic volume |
| `bt_hfp_ag_set_signal` | Update signal indicator |
| `bt_hfp_ag_set_battery` | Update battery indicator |

### BLE Tools

| Tool | Description |
|------|-------------|
| `bt_ble_scan` | Scan for BLE devices |
| `bt_ble_services` | List GATT services |
| `bt_ble_characteristics` | List characteristics |
| `bt_ble_read` | Read characteristic |
| `bt_ble_write` | Write characteristic |
| `bt_ble_notify` | Enable/disable notifications |
| `bt_ble_battery` | Read battery level |

### OBEX Tools

| Tool | Description |
|------|-------------|
| `bt_obex_status` | Check obexd status |
| `bt_obex_start_daemon` | Start obexd |
| `bt_obex_connect` | Create OBEX session |
| `bt_obex_disconnect` | Close session |
| `bt_obex_sessions` | List active sessions |
| `bt_obex_send_file` | Send file (OPP) |
| `bt_obex_get_vcard` | Get business card |
| `bt_obex_browse` | List files/folders |
| `bt_obex_get` | Download file |
| `bt_obex_put` | Upload file |
| `bt_obex_delete` | Delete file/folder |
| `bt_obex_mkdir` | Create folder |
| `bt_obex_transfer_status` | Check transfer progress |
| `bt_obex_transfer_cancel` | Cancel transfer |
| `bt_phonebook_pull` | Download phonebook |
| `bt_phonebook_list` | List contacts |
| `bt_phonebook_get` | Get single contact |
| `bt_phonebook_search` | Search contacts |
| `bt_phonebook_count` | Count contacts |
| `bt_messages_folders` | List message folders |
| `bt_messages_list` | List messages |
| `bt_messages_get` | Download message |
| `bt_messages_send` | Send message |

### Monitor Tools

| Tool | Description |
|------|-------------|
| `bt_capture_start` | Start HCI capture |
| `bt_capture_stop` | Stop capture |
| `bt_capture_list_active` | List active captures |
| `bt_capture_parse` | Parse capture file |
| `bt_capture_analyze` | Analyze capture |
| `bt_capture_read_raw` | Read raw packets |
