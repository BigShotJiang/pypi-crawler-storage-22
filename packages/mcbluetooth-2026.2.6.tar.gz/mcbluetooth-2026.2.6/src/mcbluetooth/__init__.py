"""mcbluetooth - Comprehensive BlueZ MCP server for Linux Bluetooth management."""

from mcbluetooth.server import main, mcp

__all__ = ["mcp", "main"]
