"""PipeWire/PulseAudio integration for Bluetooth audio control."""

from __future__ import annotations

from dataclasses import dataclass, field

import pulsectl_asyncio


@dataclass
class AudioSink:
    """Information about an audio sink (output device)."""

    name: str
    index: int
    description: str
    muted: bool
    volume_percent: int
    is_bluetooth: bool
    bluetooth_address: str | None
    state: str  # "running", "idle", "suspended"
    properties: dict[str, str] = field(default_factory=dict)


@dataclass
class AudioSource:
    """Information about an audio source (input device)."""

    name: str
    index: int
    description: str
    muted: bool
    volume_percent: int
    is_bluetooth: bool
    bluetooth_address: str | None
    state: str
    properties: dict[str, str] = field(default_factory=dict)


@dataclass
class AudioCard:
    """Information about an audio card (device with profiles)."""

    name: str
    index: int
    driver: str
    active_profile: str
    profiles: list[str]
    is_bluetooth: bool
    bluetooth_address: str | None
    properties: dict[str, str] = field(default_factory=dict)


def _extract_bt_address(props: dict[str, str]) -> str | None:
    """Extract Bluetooth address from PulseAudio properties."""
    # Try various property names used by different versions
    for key in ["device.string", "api.bluez5.address", "bluez.path"]:
        if key in props:
            value = props[key]
            # Check if it looks like a BT address
            if len(value) == 17 and value.count(":") == 5:
                return value.upper()
            # Extract from path like /org/bluez/hci0/dev_XX_XX_XX_XX_XX_XX
            if "dev_" in value:
                parts = value.split("dev_")
                if len(parts) > 1:
                    addr = parts[1].split("/")[0].replace("_", ":")
                    if len(addr) == 17:
                        return addr.upper()
    return None


def _is_bluetooth(props: dict[str, str]) -> bool:
    """Check if device is Bluetooth based on properties."""
    # Check various indicators
    if "api.bluez5.address" in props:
        return True
    if "bluez" in props.get("device.api", "").lower():
        return True
    if "bluetooth" in props.get("device.bus", "").lower():
        return True
    if props.get("device.string", "").startswith("/org/bluez"):
        return True
    return False


class PulseAudioClient:
    """Async client for PulseAudio/PipeWire audio control."""

    def __init__(self):
        self._pulse: pulsectl_asyncio.PulseAsync | None = None

    async def connect(self) -> None:
        """Connect to PulseAudio/PipeWire server."""
        if self._pulse is not None:
            return
        self._pulse = pulsectl_asyncio.PulseAsync("mcbluetooth")
        await self._pulse.connect()

    async def disconnect(self) -> None:
        """Disconnect from audio server."""
        if self._pulse:
            self._pulse.close()
            self._pulse = None

    async def _ensure_connected(self) -> None:
        """Ensure we're connected."""
        if self._pulse is None:
            await self.connect()

    async def list_sinks(self) -> list[AudioSink]:
        """List all audio sinks (output devices)."""
        await self._ensure_connected()
        assert self._pulse is not None

        sinks = []
        for sink in await self._pulse.sink_list():
            props = dict(sink.proplist)
            is_bt = _is_bluetooth(props)
            bt_addr = _extract_bt_address(props) if is_bt else None

            # Calculate average volume percentage
            vol_pct = int(sink.volume.value_flat * 100) if sink.volume else 0

            sinks.append(
                AudioSink(
                    name=sink.name,
                    index=sink.index,
                    description=sink.description or sink.name,
                    muted=sink.mute == 1,
                    volume_percent=vol_pct,
                    is_bluetooth=is_bt,
                    bluetooth_address=bt_addr,
                    state=sink.state.name.lower() if hasattr(sink.state, "name") else str(sink.state),
                    properties=props,
                )
            )
        return sinks

    async def list_sources(self) -> list[AudioSource]:
        """List all audio sources (input devices)."""
        await self._ensure_connected()
        assert self._pulse is not None

        sources = []
        for source in await self._pulse.source_list():
            # Skip monitor sources
            if ".monitor" in source.name:
                continue

            props = dict(source.proplist)
            is_bt = _is_bluetooth(props)
            bt_addr = _extract_bt_address(props) if is_bt else None

            vol_pct = int(source.volume.value_flat * 100) if source.volume else 0

            sources.append(
                AudioSource(
                    name=source.name,
                    index=source.index,
                    description=source.description or source.name,
                    muted=source.mute == 1,
                    volume_percent=vol_pct,
                    is_bluetooth=is_bt,
                    bluetooth_address=bt_addr,
                    state=source.state.name.lower() if hasattr(source.state, "name") else str(source.state),
                    properties=props,
                )
            )
        return sources

    async def list_cards(self) -> list[AudioCard]:
        """List all audio cards (devices with profiles)."""
        await self._ensure_connected()
        assert self._pulse is not None

        cards = []
        for card in await self._pulse.card_list():
            props = dict(card.proplist)
            is_bt = _is_bluetooth(props)
            bt_addr = _extract_bt_address(props) if is_bt else None

            profile_names = [p.name for p in card.profile_list]
            active_profile = card.profile_active.name if card.profile_active else ""

            cards.append(
                AudioCard(
                    name=card.name,
                    index=card.index,
                    driver=card.driver,
                    active_profile=active_profile,
                    profiles=profile_names,
                    is_bluetooth=is_bt,
                    bluetooth_address=bt_addr,
                    properties=props,
                )
            )
        return cards

    async def get_default_sink(self) -> str | None:
        """Get the name of the default sink."""
        await self._ensure_connected()
        assert self._pulse is not None

        info = await self._pulse.server_info()
        return info.default_sink_name

    async def get_default_source(self) -> str | None:
        """Get the name of the default source."""
        await self._ensure_connected()
        assert self._pulse is not None

        info = await self._pulse.server_info()
        return info.default_source_name

    async def set_default_sink(self, sink_name: str) -> None:
        """Set the default audio sink."""
        await self._ensure_connected()
        assert self._pulse is not None

        await self._pulse.sink_default_set(sink_name)

    async def set_default_source(self, source_name: str) -> None:
        """Set the default audio source."""
        await self._ensure_connected()
        assert self._pulse is not None

        await self._pulse.source_default_set(source_name)

    async def set_sink_volume(self, sink_name: str, volume_percent: int) -> None:
        """Set sink volume (0-100)."""
        await self._ensure_connected()
        assert self._pulse is not None

        volume_percent = max(0, min(150, volume_percent))  # Allow up to 150%
        vol = volume_percent / 100.0

        # Find the sink
        for sink in await self._pulse.sink_list():
            if sink.name == sink_name:
                await self._pulse.volume_set_all_chans(sink, vol)
                return
        raise ValueError(f"Sink not found: {sink_name}")

    async def set_sink_mute(self, sink_name: str, muted: bool) -> None:
        """Mute or unmute a sink."""
        await self._ensure_connected()
        assert self._pulse is not None

        for sink in await self._pulse.sink_list():
            if sink.name == sink_name:
                await self._pulse.sink_mute(sink.index, muted)
                return
        raise ValueError(f"Sink not found: {sink_name}")

    async def set_card_profile(self, card_name: str, profile_name: str) -> None:
        """Set the active profile for a card.

        For Bluetooth devices, common profiles include:
        - a2dp-sink: High quality audio output (A2DP)
        - headset-head-unit: Lower quality but with microphone (HFP/HSP)
        - off: Disable the device
        """
        await self._ensure_connected()
        assert self._pulse is not None

        for card in await self._pulse.card_list():
            if card.name == card_name:
                await self._pulse.card_profile_set(card, profile_name)
                return
        raise ValueError(f"Card not found: {card_name}")

    async def find_bluetooth_sink(self, address: str) -> AudioSink | None:
        """Find a sink by Bluetooth address."""
        address = address.upper()
        for sink in await self.list_sinks():
            if sink.bluetooth_address == address:
                return sink
        return None

    async def find_bluetooth_card(self, address: str) -> AudioCard | None:
        """Find a card by Bluetooth address."""
        address = address.upper()
        for card in await self.list_cards():
            if card.bluetooth_address == address:
                return card
        return None


# Global client instance
_audio_client: PulseAudioClient | None = None


async def get_audio_client() -> PulseAudioClient:
    """Get or create the global audio client."""
    global _audio_client
    if _audio_client is None:
        _audio_client = PulseAudioClient()
        await _audio_client.connect()
    return _audio_client
