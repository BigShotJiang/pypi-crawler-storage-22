"""MCP Resources for Bluetooth state exposure.

Resources provide a live, queryable view of Bluetooth state:
- Adapters: Available Bluetooth controllers
- Devices: Filtered by state (visible, paired, connected)

Unlike tools which perform actions, resources are read-only snapshots
that clients can poll or subscribe to for state changes.
"""

from __future__ import annotations

import json
from dataclasses import asdict

from fastmcp import FastMCP

from mcbluetooth.dbus_client import get_client


def register_resources(mcp: FastMCP) -> None:
    """Register Bluetooth state resources with the MCP server."""

    @mcp.resource(
        "bluetooth://adapters",
        name="Bluetooth Adapters",
        description="List of all Bluetooth adapters on the system with their current state",
        mime_type="application/json",
    )
    async def resource_adapters() -> str:
        """Get all Bluetooth adapters."""
        client = await get_client()
        adapters = await client.list_adapters()
        return json.dumps(
            {
                "adapters": [
                    {
                        "name": a.name,
                        "address": a.address,
                        "alias": a.alias,
                        "powered": a.powered,
                        "discoverable": a.discoverable,
                        "discovering": a.discovering,
                        "pairable": a.pairable,
                    }
                    for a in adapters
                ]
            },
            indent=2,
        )

    @mcp.resource(
        "bluetooth://paired",
        name="Paired Devices",
        description="Bluetooth devices that have been paired with this system",
        mime_type="application/json",
    )
    async def resource_devices_paired() -> str:
        """Get all paired Bluetooth devices."""
        client = await get_client()
        devices = await client.list_devices(filter_type="paired")
        return json.dumps(
            {
                "filter": "paired",
                "count": len(devices),
                "devices": [
                    {
                        "address": d.address,
                        "name": d.name or d.alias or "(unnamed)",
                        "connected": d.connected,
                        "trusted": d.trusted,
                        "adapter": d.adapter,
                        "uuids": d.uuids[:5],  # First 5 UUIDs
                    }
                    for d in devices
                ],
            },
            indent=2,
        )

    @mcp.resource(
        "bluetooth://connected",
        name="Connected Devices",
        description="Bluetooth devices currently connected to this system",
        mime_type="application/json",
    )
    async def resource_devices_connected() -> str:
        """Get all connected Bluetooth devices."""
        client = await get_client()
        devices = await client.list_devices(filter_type="connected")
        return json.dumps(
            {
                "filter": "connected",
                "count": len(devices),
                "devices": [
                    {
                        "address": d.address,
                        "name": d.name or d.alias or "(unnamed)",
                        "paired": d.paired,
                        "trusted": d.trusted,
                        "adapter": d.adapter,
                        "services_resolved": d.services_resolved,
                    }
                    for d in devices
                ],
            },
            indent=2,
        )

    @mcp.resource(
        "bluetooth://visible",
        name="Visible Devices",
        description="All Bluetooth devices visible to this system (discovered or known)",
        mime_type="application/json",
    )
    async def resource_devices_visible() -> str:
        """Get all visible/known Bluetooth devices."""
        client = await get_client()
        devices = await client.list_devices(filter_type="all")
        return json.dumps(
            {
                "filter": "all",
                "count": len(devices),
                "devices": [
                    {
                        "address": d.address,
                        "name": d.name or d.alias or "(unnamed)",
                        "rssi": d.rssi,
                        "paired": d.paired,
                        "connected": d.connected,
                        "adapter": d.adapter,
                    }
                    for d in devices
                ],
            },
            indent=2,
        )

    @mcp.resource(
        "bluetooth://trusted",
        name="Trusted Devices",
        description="Bluetooth devices marked as trusted (auto-connect enabled)",
        mime_type="application/json",
    )
    async def resource_devices_trusted() -> str:
        """Get all trusted Bluetooth devices."""
        client = await get_client()
        devices = await client.list_devices(filter_type="trusted")
        return json.dumps(
            {
                "filter": "trusted",
                "count": len(devices),
                "devices": [
                    {
                        "address": d.address,
                        "name": d.name or d.alias or "(unnamed)",
                        "paired": d.paired,
                        "connected": d.connected,
                        "adapter": d.adapter,
                    }
                    for d in devices
                ],
            },
            indent=2,
        )

    # Dynamic resource template for per-adapter info
    @mcp.resource(
        "bluetooth://adapter/{adapter_name}",
        name="Adapter Details",
        description="Detailed information about a specific Bluetooth adapter",
        mime_type="application/json",
    )
    async def resource_adapter_info(adapter_name: str) -> str:
        """Get detailed info for a specific adapter."""
        client = await get_client()
        adapter = await client.get_adapter(adapter_name)
        if not adapter:
            return json.dumps({"error": f"Adapter '{adapter_name}' not found"})
        return json.dumps(asdict(adapter), indent=2)

    # Dynamic resource for per-device info
    @mcp.resource(
        "bluetooth://device/{address}",
        name="Device Details",
        description="Detailed information about a specific Bluetooth device by address",
        mime_type="application/json",
    )
    async def resource_device_info(address: str) -> str:
        """Get detailed info for a specific device."""
        client = await get_client()
        # Search across all adapters
        devices = await client.list_devices()
        for d in devices:
            if d.address.upper() == address.upper():
                # DeviceInfo already has manufacturer_data/service_data as hex strings
                return json.dumps(asdict(d), indent=2)
        return json.dumps({"error": f"Device '{address}' not found"})
