"""FastMCP server for BlueZ Bluetooth management."""

from fastmcp import FastMCP

from mcbluetooth import resources
from mcbluetooth.tools import adapter, audio, ble, device, hfp, monitor, obex

mcp = FastMCP(
    name="mcbluetooth",
    instructions="""Bluetooth management server for Linux (BlueZ).

This server provides comprehensive control over the Linux Bluetooth stack:
- Adapter management (power, discoverable, pairable)
- Device discovery and management (scan, pair, connect)
- Audio profiles (A2DP, HFP) with PipeWire/PulseAudio integration
- BLE/GATT services (read/write characteristics, notifications)
- OBEX profiles (file transfer, phonebook access, messages)

## Resources (live state queries)
- bluetooth://adapters - All Bluetooth adapters
- bluetooth://paired - Paired devices
- bluetooth://connected - Connected devices
- bluetooth://visible - All known devices
- bluetooth://trusted - Trusted devices
- bluetooth://adapter/{name} - Specific adapter details
- bluetooth://device/{address} - Specific device details

## Tools
All tools require an explicit 'adapter' parameter (e.g., "hci0").
Use bt_list_adapters() to discover available adapters.

For pairing, use pairing_mode parameter:
- "elicit": Use MCP elicitation to request PIN from user (preferred)
- "interactive": Return awaiting status, then call bt_pair_confirm
- "auto": Auto-accept pairings (use in trusted environments only)
""",
)

# Register resources (live state)
resources.register_resources(mcp)

# Register tool modules
adapter.register_tools(mcp)
device.register_tools(mcp)
audio.register_tools(mcp)
hfp.register_tools(mcp)
ble.register_tools(mcp)
monitor.register_tools(mcp)
obex.register_tools(mcp)


def main():
    """Entry point for the mcbluetooth MCP server."""
    try:
        from importlib.metadata import version

        package_version = version("mcbluetooth")
    except Exception:
        package_version = "dev"

    print(f"🔵 mcbluetooth v{package_version}")
    print("   BlueZ MCP Server - Bluetooth management for LLMs")
    print()

    mcp.run()


if __name__ == "__main__":
    main()
