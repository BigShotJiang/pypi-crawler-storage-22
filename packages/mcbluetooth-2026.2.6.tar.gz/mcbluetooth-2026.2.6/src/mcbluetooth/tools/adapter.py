"""Adapter management tools for BlueZ."""

from __future__ import annotations

from dataclasses import asdict
from typing import Any

from fastmcp import FastMCP

from mcbluetooth.dbus_client import get_client


def register_tools(mcp: FastMCP) -> None:
    """Register adapter management tools with the MCP server."""

    @mcp.tool()
    async def bt_list_adapters() -> list[dict[str, Any]]:
        """List all Bluetooth adapters on the system.

        Returns a list of adapters with their properties including:
        - name: Adapter identifier (e.g., "hci0")
        - address: Bluetooth MAC address
        - powered: Whether adapter is on
        - discoverable: Whether adapter is visible to other devices
        - discovering: Whether currently scanning
        """
        client = await get_client()
        adapters = await client.list_adapters()
        return [asdict(a) for a in adapters]

    @mcp.tool()
    async def bt_adapter_info(adapter: str) -> dict[str, Any] | None:
        """Get detailed information about a specific adapter.

        Args:
            adapter: Adapter name (e.g., "hci0")

        Returns:
            Adapter properties or None if not found
        """
        client = await get_client()
        info = await client.get_adapter(adapter)
        return asdict(info) if info else None

    @mcp.tool()
    async def bt_adapter_power(adapter: str, on: bool) -> dict[str, Any]:
        """Power an adapter on or off.

        Args:
            adapter: Adapter name (e.g., "hci0")
            on: True to power on, False to power off

        Returns:
            Updated adapter info
        """
        client = await get_client()
        await client.set_adapter_power(adapter, on)
        info = await client.get_adapter(adapter)
        return asdict(info) if info else {"error": "Adapter not found"}

    @mcp.tool()
    async def bt_adapter_discoverable(
        adapter: str,
        on: bool,
        timeout: int = 180,
    ) -> dict[str, Any]:
        """Set adapter discoverable (visible to other devices).

        Args:
            adapter: Adapter name (e.g., "hci0")
            on: True to enable discoverable, False to disable
            timeout: Discoverable timeout in seconds (0 = forever, default 180)

        Returns:
            Updated adapter info
        """
        client = await get_client()
        await client.set_adapter_discoverable(adapter, on, timeout)
        info = await client.get_adapter(adapter)
        return asdict(info) if info else {"error": "Adapter not found"}

    @mcp.tool()
    async def bt_adapter_pairable(
        adapter: str,
        on: bool,
        timeout: int = 0,
    ) -> dict[str, Any]:
        """Set adapter pairable state.

        Args:
            adapter: Adapter name (e.g., "hci0")
            on: True to enable pairing acceptance, False to disable
            timeout: Pairable timeout in seconds (0 = forever)

        Returns:
            Updated adapter info
        """
        client = await get_client()
        await client.set_adapter_pairable(adapter, on, timeout)
        info = await client.get_adapter(adapter)
        return asdict(info) if info else {"error": "Adapter not found"}

    @mcp.tool()
    async def bt_adapter_set_alias(adapter: str, alias: str) -> dict[str, Any]:
        """Set adapter friendly name (alias).

        Args:
            adapter: Adapter name (e.g., "hci0")
            alias: New friendly name for the adapter

        Returns:
            Updated adapter info
        """
        client = await get_client()
        await client.set_adapter_alias(adapter, alias)
        info = await client.get_adapter(adapter)
        return asdict(info) if info else {"error": "Adapter not found"}
