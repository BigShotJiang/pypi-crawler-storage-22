"""Audio profile management tools for Bluetooth devices."""

from __future__ import annotations

from dataclasses import asdict
from typing import Any, Literal

from fastmcp import FastMCP

from mcbluetooth.audio import get_audio_client
from mcbluetooth.dbus_client import get_client

# Common Bluetooth audio UUIDs
A2DP_SINK_UUID = "0000110b-0000-1000-8000-00805f9b34fb"
A2DP_SOURCE_UUID = "0000110a-0000-1000-8000-00805f9b34fb"
HFP_HF_UUID = "0000111e-0000-1000-8000-00805f9b34fb"
HFP_AG_UUID = "0000111f-0000-1000-8000-00805f9b34fb"
HSP_HS_UUID = "00001108-0000-1000-8000-00805f9b34fb"
HSP_AG_UUID = "00001112-0000-1000-8000-00805f9b34fb"


def register_tools(mcp: FastMCP) -> None:
    """Register audio management tools with the MCP server."""

    @mcp.tool()
    async def bt_audio_list() -> dict[str, Any]:
        """List all audio devices including Bluetooth devices.

        Returns information about:
        - Sinks (audio outputs like speakers, headphones)
        - Sources (audio inputs like microphones)
        - Cards (devices with switchable profiles)

        Bluetooth audio devices show their MAC address.
        """
        audio = await get_audio_client()

        sinks = await audio.list_sinks()
        sources = await audio.list_sources()
        cards = await audio.list_cards()

        default_sink = await audio.get_default_sink()
        default_source = await audio.get_default_source()

        return {
            "default_sink": default_sink,
            "default_source": default_source,
            "sinks": [asdict(s) for s in sinks],
            "sources": [asdict(s) for s in sources],
            "cards": [asdict(c) for c in cards],
            "bluetooth_sinks": [asdict(s) for s in sinks if s.is_bluetooth],
            "bluetooth_cards": [asdict(c) for c in cards if c.is_bluetooth],
        }

    @mcp.tool()
    async def bt_audio_connect(adapter: str, address: str) -> dict[str, Any]:
        """Connect audio profiles to a Bluetooth device.

        This connects the A2DP (high-quality audio) and/or HFP (hands-free)
        profiles to the specified Bluetooth device.

        Args:
            adapter: Adapter name (e.g., "hci0")
            address: Device Bluetooth address

        Returns:
            Connection status and available audio info
        """
        bt_client = await get_client()

        # First ensure device is connected
        device = await bt_client.get_device(adapter, address)
        if not device:
            return {"status": "error", "error": "Device not found"}

        if not device.paired:
            return {"status": "error", "error": "Device not paired. Pair first with bt_pair."}

        if not device.connected:
            try:
                await bt_client.connect_device(adapter, address)
            except Exception as e:
                return {"status": "error", "error": f"Connection failed: {e}"}

        # Try to connect audio profiles
        errors = []
        connected_profiles = []

        for uuid, name in [(A2DP_SINK_UUID, "A2DP"), (HFP_HF_UUID, "HFP")]:
            if uuid.lower() in [u.lower() for u in device.uuids]:
                try:
                    await bt_client.connect_profile(adapter, address, uuid)
                    connected_profiles.append(name)
                except Exception as e:
                    errors.append(f"{name}: {e}")

        # Check audio system
        audio = await get_audio_client()
        sink = await audio.find_bluetooth_sink(address)
        card = await audio.find_bluetooth_card(address)

        return {
            "status": "connected" if connected_profiles else "no_audio_profiles",
            "connected_profiles": connected_profiles,
            "errors": errors if errors else None,
            "audio_sink": asdict(sink) if sink else None,
            "audio_card": asdict(card) if card else None,
        }

    @mcp.tool()
    async def bt_audio_disconnect(adapter: str, address: str) -> dict[str, Any]:
        """Disconnect audio profiles from a Bluetooth device.

        This disconnects audio profiles but keeps the device connected
        for other services (if any).

        Args:
            adapter: Adapter name (e.g., "hci0")
            address: Device Bluetooth address

        Returns:
            Disconnection status
        """
        bt_client = await get_client()

        device = await bt_client.get_device(adapter, address)
        if not device:
            return {"status": "error", "error": "Device not found"}

        errors = []
        disconnected_profiles = []

        for uuid, name in [(A2DP_SINK_UUID, "A2DP"), (HFP_HF_UUID, "HFP")]:
            if uuid.lower() in [u.lower() for u in device.uuids]:
                try:
                    await bt_client.disconnect_profile(adapter, address, uuid)
                    disconnected_profiles.append(name)
                except Exception as e:
                    errors.append(f"{name}: {e}")

        return {
            "status": "disconnected" if disconnected_profiles else "no_audio_profiles",
            "disconnected_profiles": disconnected_profiles,
            "errors": errors if errors else None,
        }

    @mcp.tool()
    async def bt_audio_set_profile(
        address: str,
        profile: Literal["a2dp", "hfp", "off"],
    ) -> dict[str, Any]:
        """Switch audio profile for a Bluetooth device.

        Bluetooth audio devices support different profiles:
        - a2dp: High-quality stereo audio (best for music)
        - hfp: Hands-free profile with microphone (lower quality, for calls)
        - off: Disable audio for this device

        Args:
            address: Device Bluetooth address
            profile: Profile to activate

        Returns:
            Status and updated card info
        """
        audio = await get_audio_client()

        card = await audio.find_bluetooth_card(address)
        if not card:
            return {"status": "error", "error": "Bluetooth audio card not found"}

        # Map profile names to PulseAudio profile names
        # These vary by PipeWire/PulseAudio version
        profile_map = {
            "a2dp": ["a2dp-sink", "a2dp_sink", "a2dp-sink-aac", "a2dp-sink-sbc"],
            "hfp": ["headset-head-unit", "headset_head_unit", "handsfree_head_unit"],
            "off": ["off"],
        }

        target_profiles = profile_map[profile]

        # Find a matching profile
        matched_profile = None
        for p in target_profiles:
            if p in card.profiles:
                matched_profile = p
                break

        if not matched_profile:
            return {
                "status": "error",
                "error": f"Profile '{profile}' not available",
                "available_profiles": card.profiles,
            }

        try:
            await audio.set_card_profile(card.name, matched_profile)
            # Refresh card info
            card = await audio.find_bluetooth_card(address)
            return {
                "status": "profile_changed",
                "profile": matched_profile,
                "card": asdict(card) if card else None,
            }
        except Exception as e:
            return {"status": "error", "error": str(e)}

    @mcp.tool()
    async def bt_audio_set_default(address: str) -> dict[str, Any]:
        """Set a Bluetooth device as the default audio output.

        Args:
            address: Device Bluetooth address

        Returns:
            Status and updated default sink info
        """
        audio = await get_audio_client()

        sink = await audio.find_bluetooth_sink(address)
        if not sink:
            return {"status": "error", "error": "Bluetooth audio sink not found"}

        try:
            await audio.set_default_sink(sink.name)
            return {
                "status": "default_set",
                "sink_name": sink.name,
                "description": sink.description,
            }
        except Exception as e:
            return {"status": "error", "error": str(e)}

    @mcp.tool()
    async def bt_audio_volume(address: str, volume: int) -> dict[str, Any]:
        """Set volume for a Bluetooth audio device.

        Args:
            address: Device Bluetooth address
            volume: Volume level 0-100 (can go up to 150 for boost)

        Returns:
            Status and updated volume info
        """
        audio = await get_audio_client()

        sink = await audio.find_bluetooth_sink(address)
        if not sink:
            return {"status": "error", "error": "Bluetooth audio sink not found"}

        try:
            await audio.set_sink_volume(sink.name, volume)
            # Refresh sink info
            sink = await audio.find_bluetooth_sink(address)
            return {
                "status": "volume_set",
                "volume": sink.volume_percent if sink else volume,
                "sink_name": sink.name if sink else None,
            }
        except Exception as e:
            return {"status": "error", "error": str(e)}

    @mcp.tool()
    async def bt_audio_mute(address: str, muted: bool) -> dict[str, Any]:
        """Mute or unmute a Bluetooth audio device.

        Args:
            address: Device Bluetooth address
            muted: True to mute, False to unmute

        Returns:
            Status and mute state
        """
        audio = await get_audio_client()

        sink = await audio.find_bluetooth_sink(address)
        if not sink:
            return {"status": "error", "error": "Bluetooth audio sink not found"}

        try:
            await audio.set_sink_mute(sink.name, muted)
            return {
                "status": "muted" if muted else "unmuted",
                "sink_name": sink.name,
            }
        except Exception as e:
            return {"status": "error", "error": str(e)}
