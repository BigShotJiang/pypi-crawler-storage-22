"""Bluetooth Low Energy (BLE) and GATT tools."""

from __future__ import annotations

import asyncio
from typing import Any

from fastmcp import FastMCP

from mcbluetooth.dbus_client import get_client

# Common BLE service UUIDs
BATTERY_SERVICE_UUID = "0000180f-0000-1000-8000-00805f9b34fb"
BATTERY_LEVEL_CHAR_UUID = "00002a19-0000-1000-8000-00805f9b34fb"
DEVICE_INFO_SERVICE_UUID = "0000180a-0000-1000-8000-00805f9b34fb"
HEART_RATE_SERVICE_UUID = "0000180d-0000-1000-8000-00805f9b34fb"
HEART_RATE_MEASUREMENT_UUID = "00002a37-0000-1000-8000-00805f9b34fb"


def _format_uuid(uuid: str) -> str:
    """Format UUID for display - short form for standard UUIDs."""
    # Standard Bluetooth UUIDs have the form 0000XXXX-0000-1000-8000-00805f9b34fb
    if uuid.lower().endswith("-0000-1000-8000-00805f9b34fb"):
        short = uuid[:8].lstrip("0") or "0"
        return f"0x{short.upper()}"
    return uuid


def register_tools(mcp: FastMCP) -> None:
    """Register BLE/GATT tools with the MCP server."""

    @mcp.tool()
    async def bt_ble_scan(
        adapter: str,
        timeout: int = 10,
        name_filter: str | None = None,
        service_filter: str | None = None,
    ) -> list[dict[str, Any]]:
        """Scan for BLE (Bluetooth Low Energy) devices.

        BLE devices advertise their presence and can be filtered by name
        or service UUID. Common services include:
        - 0x180F: Battery Service
        - 0x180D: Heart Rate Service
        - 0x180A: Device Information

        Args:
            adapter: Adapter name (e.g., "hci0")
            timeout: Scan duration in seconds
            name_filter: Only return devices with name containing this string
            service_filter: Only return devices advertising this service UUID

        Returns:
            List of BLE devices with advertisement data
        """
        client = await get_client()

        # Set BLE-specific filter
        uuids = [service_filter] if service_filter else None
        await client.set_discovery_filter(
            adapter, uuids=uuids, transport="le", duplicate_data=True
        )

        await client.start_discovery(adapter)
        try:
            await asyncio.sleep(timeout)
        finally:
            await client.stop_discovery(adapter)
            await client.remove_discovery_filter(adapter)

        devices = await client.list_devices(adapter=adapter)

        # Apply name filter
        if name_filter:
            name_filter_lower = name_filter.lower()
            devices = [d for d in devices if name_filter_lower in d.name.lower()]

        # Format for BLE-specific output
        result = []
        for d in devices:
            # Parse manufacturer data for display
            mfr_data_hex = {
                k: v.hex() if isinstance(v, bytes) else str(v)
                for k, v in d.manufacturer_data.items()
            }
            svc_data_hex = {
                k: v.hex() if isinstance(v, bytes) else str(v)
                for k, v in d.service_data.items()
            }

            result.append({
                "address": d.address,
                "name": d.name or "(unknown)",
                "rssi": d.rssi,
                "paired": d.paired,
                "connected": d.connected,
                "uuids": [_format_uuid(u) for u in d.uuids],
                "manufacturer_data": mfr_data_hex,
                "service_data": svc_data_hex,
                "appearance": d.appearance,
            })

        return result

    @mcp.tool()
    async def bt_ble_services(adapter: str, address: str) -> list[dict[str, Any]]:
        """List GATT services for a connected BLE device.

        The device must be connected for service discovery.
        Services contain characteristics that can be read/written.

        Args:
            adapter: Adapter name (e.g., "hci0")
            address: Device Bluetooth address

        Returns:
            List of GATT services with their UUIDs
        """
        client = await get_client()

        # Check device is connected
        device = await client.get_device(adapter, address)
        if not device:
            return [{"error": "Device not found"}]
        if not device.connected:
            return [{"error": "Device not connected. Use bt_connect first."}]
        if not device.services_resolved:
            # Wait a bit for services to resolve
            await asyncio.sleep(2)
            device = await client.get_device(adapter, address)
            if not device or not device.services_resolved:
                return [{"error": "Services not yet resolved. Try again in a moment."}]

        services = await client.list_gatt_services(adapter, address)
        return [
            {
                "uuid": s.uuid,
                "uuid_short": _format_uuid(s.uuid),
                "primary": s.primary,
                "path": s.path,
            }
            for s in services
        ]

    @mcp.tool()
    async def bt_ble_characteristics(
        adapter: str,
        address: str,
        service_uuid: str | None = None,
    ) -> list[dict[str, Any]]:
        """List GATT characteristics for a BLE device.

        Characteristics are the data points within a service that can be
        read, written, or subscribed to for notifications.

        Args:
            adapter: Adapter name (e.g., "hci0")
            address: Device Bluetooth address
            service_uuid: Filter to characteristics of this service (optional)

        Returns:
            List of characteristics with their properties
        """
        client = await get_client()

        device = await client.get_device(adapter, address)
        if not device or not device.connected:
            return [{"error": "Device not connected"}]

        chars = await client.list_gatt_characteristics(adapter, address, service_uuid)
        return [
            {
                "uuid": c.uuid,
                "uuid_short": _format_uuid(c.uuid),
                "path": c.path,
                "flags": c.flags,
                "notifying": c.notifying,
                "readable": "read" in c.flags,
                "writable": "write" in c.flags or "write-without-response" in c.flags,
                "notifiable": "notify" in c.flags or "indicate" in c.flags,
            }
            for c in chars
        ]

    @mcp.tool()
    async def bt_ble_read(
        adapter: str,
        address: str,
        char_uuid: str,
    ) -> dict[str, Any]:
        """Read a GATT characteristic value.

        Args:
            adapter: Adapter name (e.g., "hci0")
            address: Device Bluetooth address
            char_uuid: Characteristic UUID to read

        Returns:
            The characteristic value as hex and decoded (if possible)
        """
        client = await get_client()

        # Find the characteristic
        chars = await client.list_gatt_characteristics(adapter, address)
        target_char = None
        for c in chars:
            if c.uuid.lower() == char_uuid.lower():
                target_char = c
                break

        if not target_char:
            return {"error": f"Characteristic {char_uuid} not found"}

        if "read" not in target_char.flags:
            return {"error": "Characteristic is not readable"}

        try:
            value = await client.read_characteristic(target_char.path)
            result = {
                "uuid": char_uuid,
                "value_hex": value.hex(),
                "value_bytes": list(value),
                "length": len(value),
            }

            # Try to decode as UTF-8 string
            try:
                result["value_string"] = value.decode("utf-8")
            except UnicodeDecodeError:
                pass

            # Try to decode as integer (common for single-byte values)
            if len(value) == 1:
                result["value_int"] = value[0]
            elif len(value) == 2:
                result["value_int"] = int.from_bytes(value, "little")

            return result
        except Exception as e:
            return {"error": str(e)}

    @mcp.tool()
    async def bt_ble_write(
        adapter: str,
        address: str,
        char_uuid: str,
        value: str,
        value_type: str = "hex",
        with_response: bool = True,
    ) -> dict[str, Any]:
        """Write a value to a GATT characteristic.

        Args:
            adapter: Adapter name (e.g., "hci0")
            address: Device Bluetooth address
            char_uuid: Characteristic UUID to write
            value: Value to write
            value_type: How to interpret value - "hex" (e.g., "0102ff"),
                        "string" (UTF-8), or "int" (decimal number)
            with_response: Whether to wait for write confirmation

        Returns:
            Write status
        """
        client = await get_client()

        # Find the characteristic
        chars = await client.list_gatt_characteristics(adapter, address)
        target_char = None
        for c in chars:
            if c.uuid.lower() == char_uuid.lower():
                target_char = c
                break

        if not target_char:
            return {"error": f"Characteristic {char_uuid} not found"}

        if "write" not in target_char.flags and "write-without-response" not in target_char.flags:
            return {"error": "Characteristic is not writable"}

        # Convert value to bytes
        try:
            if value_type == "hex":
                data = bytes.fromhex(value)
            elif value_type == "string":
                data = value.encode("utf-8")
            elif value_type == "int":
                int_val = int(value)
                # Determine byte length needed
                byte_len = max(1, (int_val.bit_length() + 7) // 8)
                data = int_val.to_bytes(byte_len, "little")
            else:
                return {"error": f"Unknown value_type: {value_type}"}
        except ValueError as e:
            return {"error": f"Invalid value format: {e}"}

        try:
            write_type = "request" if with_response else "command"
            await client.write_characteristic(target_char.path, data, write_type)
            return {
                "status": "written",
                "uuid": char_uuid,
                "value_hex": data.hex(),
                "length": len(data),
            }
        except Exception as e:
            return {"error": str(e)}

    @mcp.tool()
    async def bt_ble_notify(
        adapter: str,
        address: str,
        char_uuid: str,
        enable: bool,
    ) -> dict[str, Any]:
        """Enable or disable notifications for a characteristic.

        When enabled, the device will send updates when the characteristic
        value changes (e.g., heart rate measurements, sensor data).

        Note: To receive actual notifications, you would need to set up
        a callback - this tool just enables/disables the notification mode.

        Args:
            adapter: Adapter name (e.g., "hci0")
            address: Device Bluetooth address
            char_uuid: Characteristic UUID
            enable: True to enable notifications, False to disable

        Returns:
            Notification status
        """
        client = await get_client()

        chars = await client.list_gatt_characteristics(adapter, address)
        target_char = None
        for c in chars:
            if c.uuid.lower() == char_uuid.lower():
                target_char = c
                break

        if not target_char:
            return {"error": f"Characteristic {char_uuid} not found"}

        if "notify" not in target_char.flags and "indicate" not in target_char.flags:
            return {"error": "Characteristic does not support notifications"}

        try:
            if enable:
                await client.start_notify(target_char.path)
            else:
                await client.stop_notify(target_char.path)

            return {
                "status": "notifications_enabled" if enable else "notifications_disabled",
                "uuid": char_uuid,
            }
        except Exception as e:
            return {"error": str(e)}

    @mcp.tool()
    async def bt_ble_battery(adapter: str, address: str) -> dict[str, Any]:
        """Read battery level from a BLE device.

        Many BLE devices support the standard Battery Service (0x180F).
        This is a convenience function that reads from that service.

        Args:
            adapter: Adapter name (e.g., "hci0")
            address: Device Bluetooth address

        Returns:
            Battery percentage (0-100) or error
        """
        client = await get_client()

        # First try BlueZ Battery1 interface (cached value)
        battery_level = await client.get_battery_level(adapter, address)
        if battery_level is not None:
            return {"battery_percent": battery_level, "source": "bluez_battery1"}

        # Fall back to reading GATT characteristic
        device = await client.get_device(adapter, address)
        if not device or not device.connected:
            return {"error": "Device not connected"}

        chars = await client.list_gatt_characteristics(adapter, address, BATTERY_SERVICE_UUID)
        battery_char = None
        for c in chars:
            if c.uuid.lower() == BATTERY_LEVEL_CHAR_UUID.lower():
                battery_char = c
                break

        if not battery_char:
            return {"error": "Battery service not available on this device"}

        try:
            value = await client.read_characteristic(battery_char.path)
            if len(value) >= 1:
                return {"battery_percent": value[0], "source": "gatt_characteristic"}
            return {"error": "Invalid battery value"}
        except Exception as e:
            return {"error": str(e)}
