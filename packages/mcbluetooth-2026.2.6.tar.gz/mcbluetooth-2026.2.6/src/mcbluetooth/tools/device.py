"""Device discovery and management tools for BlueZ."""

import asyncio
from dataclasses import asdict
from typing import Any, Literal

from fastmcp import Context, FastMCP

from mcbluetooth import agent
from mcbluetooth.agent import PairingMode as AgentPairingMode
from mcbluetooth.dbus_client import get_client

# Type aliases for MCP tool parameters
ScanMode = Literal["classic", "ble", "both"]
DeviceFilter = Literal["all", "paired", "connected", "trusted"]
PairingMode = Literal["elicit", "interactive", "auto"]


def register_tools(mcp: FastMCP) -> None:
    """Register device management tools with the MCP server."""

    @mcp.tool()
    async def bt_scan(
        adapter: str,
        timeout: int = 10,
        mode: ScanMode = "both",
        ctx: Context | None = None,
    ) -> list[dict[str, Any]]:
        """Scan for nearby Bluetooth devices.

        Starts discovery, waits for the specified timeout, then returns
        all discovered devices. For BLE devices, ensure they are advertising.

        Args:
            adapter: Adapter name (e.g., "hci0")
            timeout: Scan duration in seconds (default 10)
            mode: Scan mode - "classic" (BR/EDR), "ble" (Low Energy), or "both"

        Returns:
            List of discovered devices with their properties
        """
        client = await get_client()

        # Log scan start
        if ctx:
            await ctx.info(f"Starting {mode} scan on {adapter} for {timeout}s")

        # Set discovery filter based on mode
        transport = {"classic": "bredr", "ble": "le", "both": "auto"}[mode]
        await client.set_discovery_filter(adapter, transport=transport, duplicate_data=True)

        # Start discovery
        await client.start_discovery(adapter)
        if ctx:
            await ctx.debug(f"Discovery started on {adapter}")

        try:
            # Report progress during scan with periodic device count updates
            for elapsed in range(timeout):
                await asyncio.sleep(1)
                if ctx:
                    # Report progress
                    await ctx.report_progress(progress=elapsed + 1, total=timeout)
                    # Periodically log device count
                    if (elapsed + 1) % 3 == 0 or elapsed == 0:
                        devices = await client.list_devices(adapter=adapter)
                        await ctx.debug(f"Scan progress: {len(devices)} devices found")
        finally:
            # Always stop discovery
            await client.stop_discovery(adapter)
            await client.remove_discovery_filter(adapter)
            if ctx:
                await ctx.debug("Discovery stopped")

        # Return discovered devices
        devices = await client.list_devices(adapter=adapter)
        if ctx:
            await ctx.info(f"Scan complete: found {len(devices)} devices")
        return [asdict(d) for d in devices]

    @mcp.tool()
    async def bt_list_devices(
        adapter: str,
        filter: DeviceFilter = "all",
        ctx: Context | None = None,
    ) -> list[dict[str, Any]]:
        """List known Bluetooth devices.

        Returns devices that have been discovered or paired previously.
        Use bt_scan to discover new devices.

        Args:
            adapter: Adapter name (e.g., "hci0")
            filter: Filter type - "all", "paired", "connected", or "trusted"

        Returns:
            List of devices matching the filter
        """
        client = await get_client()
        if ctx:
            await ctx.debug(f"Listing {filter} devices on {adapter}")
        devices = await client.list_devices(adapter=adapter, filter_type=filter)
        if ctx:
            await ctx.info(f"Found {len(devices)} {filter} devices")
        return [asdict(d) for d in devices]

    @mcp.tool()
    async def bt_device_info(
        adapter: str,
        address: str,
        ctx: Context | None = None,
    ) -> dict[str, Any] | None:
        """Get detailed information about a specific device.

        Args:
            adapter: Adapter name (e.g., "hci0")
            address: Device Bluetooth address (e.g., "AA:BB:CC:DD:EE:FF")

        Returns:
            Device properties or None if not found
        """
        client = await get_client()
        if ctx:
            await ctx.debug(f"Getting info for {address}")
        info = await client.get_device(adapter, address)
        if info and ctx:
            await ctx.info(f"Device: {info.name or info.alias or 'unnamed'} ({address})")
        return asdict(info) if info else None

    @mcp.tool()
    async def bt_pair(
        adapter: str,
        address: str,
        pairing_mode: PairingMode = "interactive",
        timeout: int = 60,
        ctx: Context | None = None,
    ) -> dict[str, Any]:
        """Initiate pairing with a device.

        Pairing establishes a trusted relationship with a device. Some devices
        require PIN entry or confirmation during pairing.

        Args:
            adapter: Adapter name (e.g., "hci0")
            address: Device Bluetooth address
            pairing_mode: How to handle pairing requests:
                - "elicit": Use MCP elicitation to request PIN from user (if supported)
                - "interactive": Return status, then call bt_pair_confirm with PIN
                - "auto": Auto-accept pairings (for trusted environments)
            timeout: Pairing timeout in seconds (default 60)

        Returns:
            Pairing status including whether confirmation is needed
        """
        client = await get_client()

        if ctx:
            await ctx.info(f"Initiating pairing with {address} (mode: {pairing_mode})")

        # Check if already paired
        device = await client.get_device(adapter, address)
        if device and device.paired:
            if ctx:
                await ctx.info(f"Device {address} is already paired")
            return {"status": "already_paired", "device": asdict(device)}

        # Initialize and configure the pairing agent
        pairing_agent = await agent.get_agent()
        pairing_agent.set_mode(AgentPairingMode(pairing_mode))
        pairing_agent._timeout = float(timeout)

        if ctx:
            await ctx.debug(f"Agent registered with mode: {pairing_mode}")

        # Start pairing
        async def do_pair():
            try:
                await client.pair_device(adapter, address)
                return {"success": True}
            except Exception as e:
                return {"success": False, "error": str(e)}

        if pairing_mode == "auto":
            # For auto mode, just wait for pairing to complete
            result = await do_pair()
            if result["success"]:
                device = await client.get_device(adapter, address)
                if ctx:
                    await ctx.info(f"Successfully paired with {address}")
                return {"status": "paired", "device": asdict(device) if device else None}
            else:
                if ctx:
                    await ctx.error(f"Pairing failed: {result['error']}")
                return {"status": "error", "error": result["error"]}
        else:
            # For interactive/elicit modes, start pairing in background
            # and return immediately if a request is pending
            pair_task = asyncio.create_task(do_pair())

            # Wait briefly to see if pairing completes quickly or needs input
            try:
                result = await asyncio.wait_for(asyncio.shield(pair_task), timeout=3.0)
                if result["success"]:
                    device = await client.get_device(adapter, address)
                    if ctx:
                        await ctx.info(f"Successfully paired with {address}")
                    return {"status": "paired", "device": asdict(device) if device else None}
                else:
                    # Check if there's a pending request
                    pending = pairing_agent.get_pending_request(address)
                    if pending:
                        if ctx:
                            await ctx.warning(
                                f"Pairing requires {pending.request_type.value}: "
                                f"passkey={pending.passkey}"
                            )
                        return {
                            "status": "awaiting_confirmation",
                            "request_type": pending.request_type.value,
                            "passkey": pending.passkey,
                            "message": "Use bt_pair_confirm to accept or reject",
                        }
                    if ctx:
                        await ctx.error(f"Pairing failed: {result['error']}")
                    return {"status": "error", "error": result["error"]}
            except TimeoutError:
                # Pairing is still in progress - check for pending requests
                pending = pairing_agent.get_pending_request(address)
                if pending:
                    if ctx:
                        await ctx.warning(
                            f"Pairing requires {pending.request_type.value}: "
                            f"passkey={pending.passkey}"
                        )
                    return {
                        "status": "awaiting_confirmation",
                        "request_type": pending.request_type.value,
                        "passkey": pending.passkey,
                        "message": "Use bt_pair_confirm to accept or reject",
                    }
                # No request yet, pairing still in progress
                if ctx:
                    await ctx.info("Pairing in progress, waiting for device...")
                return {
                    "status": "pairing_in_progress",
                    "message": "Check bt_pairing_status or wait for device response",
                }

    @mcp.tool()
    async def bt_pair_confirm(
        adapter: str,
        address: str,
        pin: str | None = None,
        passkey: int | None = None,
        accept: bool = True,
        ctx: Context | None = None,
    ) -> dict[str, Any]:
        """Confirm or reject a pairing request.

        Use this after bt_pair returns "awaiting_confirmation" status.
        The agent will respond to BlueZ's pairing request.

        Args:
            adapter: Adapter name
            address: Device Bluetooth address
            pin: PIN code if required (string, usually 4-6 digits)
            passkey: Numeric passkey if required (0-999999)
            accept: True to accept pairing, False to reject

        Returns:
            Pairing result
        """
        client = await get_client()

        # Respond to the pending agent request
        pin_or_passkey = passkey if passkey is not None else pin
        responded = await agent.respond_to_pairing(address, accept, pin_or_passkey)

        if not responded:
            # No pending request from agent - might be using default agent
            if ctx:
                await ctx.warning(f"No pending pairing request for {address}")

        if not accept:
            if ctx:
                await ctx.info(f"Rejecting pairing with {address}")
            try:
                await client.cancel_pairing(adapter, address)
                return {"status": "pairing_rejected"}
            except Exception as e:
                # May already be cancelled
                if ctx:
                    await ctx.debug(f"Cancel pairing: {e}")
                return {"status": "pairing_rejected"}

        if ctx:
            await ctx.info(f"Confirming pairing with {address}")

        # Wait a moment for the agent to process and BlueZ to complete
        await asyncio.sleep(1.0)

        # Check if pairing succeeded
        device = await client.get_device(adapter, address)
        if device and device.paired:
            if ctx:
                await ctx.info(f"Pairing confirmed with {address}")
            return {"status": "paired", "device": asdict(device)}
        else:
            # Pairing might still be in progress
            if ctx:
                await ctx.info("Pairing in progress...")
            return {
                "status": "confirmation_sent",
                "message": "Confirmation sent to agent. Check device status.",
            }

    @mcp.tool()
    async def bt_pairing_status(
        ctx: Context | None = None,
    ) -> dict[str, Any]:
        """Get the status of pending pairing requests.

        Shows any pairing requests waiting for confirmation.

        Returns:
            List of pending pairing requests
        """
        pending = agent.get_pending_requests()
        if ctx:
            if pending:
                await ctx.info(f"Found {len(pending)} pending pairing request(s)")
            else:
                await ctx.info("No pending pairing requests")
        return {
            "pending_requests": pending,
            "count": len(pending),
        }

    @mcp.tool()
    async def bt_unpair(
        adapter: str,
        address: str,
        ctx: Context | None = None,
    ) -> dict[str, str]:
        """Remove pairing with a device.

        This removes the device from the list of known devices and
        deletes all pairing information.

        Args:
            adapter: Adapter name (e.g., "hci0")
            address: Device Bluetooth address

        Returns:
            Status of the operation
        """
        client = await get_client()
        if ctx:
            await ctx.info(f"Removing device {address}")
        try:
            await client.remove_device(adapter, address)
            if ctx:
                await ctx.info(f"Device {address} removed successfully")
            return {"status": "removed", "address": address}
        except Exception as e:
            if ctx:
                await ctx.error(f"Failed to remove device: {e}")
            return {"status": "error", "error": str(e)}

    @mcp.tool()
    async def bt_connect(
        adapter: str,
        address: str,
        ctx: Context | None = None,
    ) -> dict[str, Any]:
        """Connect to a paired device.

        Establishes an active connection to a previously paired device.
        For audio devices, this will also connect audio profiles.

        Args:
            adapter: Adapter name (e.g., "hci0")
            address: Device Bluetooth address

        Returns:
            Connection status and device info
        """
        client = await get_client()
        if ctx:
            await ctx.info(f"Connecting to {address}")
        try:
            await client.connect_device(adapter, address)
            device = await client.get_device(adapter, address)
            if ctx:
                await ctx.info(f"Connected to {device.name or address}")
            return {"status": "connected", "device": asdict(device) if device else None}
        except Exception as e:
            if ctx:
                await ctx.error(f"Connection failed: {e}")
            return {"status": "error", "error": str(e)}

    @mcp.tool()
    async def bt_disconnect(
        adapter: str,
        address: str,
        ctx: Context | None = None,
    ) -> dict[str, Any]:
        """Disconnect from a device.

        Terminates the active connection but preserves pairing.

        Args:
            adapter: Adapter name (e.g., "hci0")
            address: Device Bluetooth address

        Returns:
            Status of the operation
        """
        client = await get_client()
        if ctx:
            await ctx.info(f"Disconnecting from {address}")
        try:
            await client.disconnect_device(adapter, address)
            device = await client.get_device(adapter, address)
            if ctx:
                await ctx.info(f"Disconnected from {address}")
            return {"status": "disconnected", "device": asdict(device) if device else None}
        except Exception as e:
            if ctx:
                await ctx.error(f"Disconnect failed: {e}")
            return {"status": "error", "error": str(e)}

    @mcp.tool()
    async def bt_trust(
        adapter: str,
        address: str,
        trusted: bool,
        ctx: Context | None = None,
    ) -> dict[str, Any]:
        """Set device trust status.

        Trusted devices can connect automatically without explicit
        authorization.

        Args:
            adapter: Adapter name (e.g., "hci0")
            address: Device Bluetooth address
            trusted: True to trust, False to untrust

        Returns:
            Updated device info
        """
        client = await get_client()
        action = "Trusting" if trusted else "Untrusting"
        if ctx:
            await ctx.info(f"{action} device {address}")
        try:
            await client.set_device_trusted(adapter, address, trusted)
            device = await client.get_device(adapter, address)
            if ctx:
                await ctx.info(f"Device {address} {'trusted' if trusted else 'untrusted'}")
            return {"status": "updated", "device": asdict(device) if device else None}
        except Exception as e:
            if ctx:
                await ctx.error(f"Failed to update trust: {e}")
            return {"status": "error", "error": str(e)}

    @mcp.tool()
    async def bt_block(
        adapter: str,
        address: str,
        blocked: bool,
        ctx: Context | None = None,
    ) -> dict[str, Any]:
        """Block or unblock a device.

        Blocked devices cannot connect to this adapter.

        Args:
            adapter: Adapter name (e.g., "hci0")
            address: Device Bluetooth address
            blocked: True to block, False to unblock

        Returns:
            Updated device info
        """
        client = await get_client()
        action = "Blocking" if blocked else "Unblocking"
        if ctx:
            await ctx.info(f"{action} device {address}")
        try:
            await client.set_device_blocked(adapter, address, blocked)
            device = await client.get_device(adapter, address)
            if ctx:
                await ctx.info(f"Device {address} {'blocked' if blocked else 'unblocked'}")
            return {"status": "updated", "device": asdict(device) if device else None}
        except Exception as e:
            if ctx:
                await ctx.error(f"Failed to update block status: {e}")
            return {"status": "error", "error": str(e)}

    @mcp.tool()
    async def bt_device_set_alias(
        adapter: str,
        address: str,
        alias: str,
        ctx: Context | None = None,
    ) -> dict[str, Any]:
        """Set a friendly name for a device.

        Args:
            adapter: Adapter name (e.g., "hci0")
            address: Device Bluetooth address
            alias: New friendly name

        Returns:
            Updated device info
        """
        client = await get_client()
        if ctx:
            await ctx.info(f"Setting alias for {address} to '{alias}'")
        try:
            await client.set_device_alias(adapter, address, alias)
            device = await client.get_device(adapter, address)
            if ctx:
                await ctx.info(f"Alias set for {address}")
            return {"status": "updated", "device": asdict(device) if device else None}
        except Exception as e:
            if ctx:
                await ctx.error(f"Failed to set alias: {e}")
            return {"status": "error", "error": str(e)}
