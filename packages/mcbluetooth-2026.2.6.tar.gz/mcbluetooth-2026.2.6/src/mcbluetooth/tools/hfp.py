"""HFP Audio Gateway tools for Bluetooth MCP server.

These tools let Linux act as a phone (Audio Gateway) for testing Bluetooth
headsets and hands-free devices. The ESP32 test harness connects as the
Hands-Free Unit (headset), and these tools simulate call control from the
phone side.

Typical E2E test flow:
    1. bt_hfp_ag_enable()           → Register AG profile with BlueZ
    2. ESP32 connects as HF         → SLC auto-negotiated
    3. bt_hfp_ag_simulate_call()    → Send RING + CLIP to ESP32
    4. ESP32 answers (ATA)          → Call becomes active
    5. bt_hfp_ag_end_call()         → Terminate call
"""

from __future__ import annotations

from typing import Any, Literal

from fastmcp import FastMCP

from mcbluetooth.hfp_ag import (
    disable_hfp_ag,
    enable_hfp_ag,
    get_hfp_ag,
)


def register_tools(mcp: FastMCP) -> None:
    """Register HFP AG tools with the MCP server."""

    @mcp.tool()
    async def bt_hfp_ag_enable() -> dict[str, Any]:
        """Enable HFP Audio Gateway mode on Linux.

        Registers a custom HFP AG profile with BlueZ via ProfileManager1.
        After enabling, Bluetooth headsets (HF devices) can connect and
        Linux will act as the phone side.

        The SLC (Service Level Connection) is auto-negotiated when an HF
        device connects — feature exchange, indicator setup, and codec
        selection happen automatically.

        Returns:
            Status confirming AG profile registration.
        """
        try:
            await enable_hfp_ag()
            return {"status": "ok", "role": "audio_gateway", "profile": "HFP AG 1.7"}
        except Exception as exc:
            return {"status": "error", "error": str(exc)}

    @mcp.tool()
    async def bt_hfp_ag_disable() -> dict[str, Any]:
        """Disable HFP Audio Gateway mode.

        Unregisters the AG profile, disconnecting any active HFP sessions.

        Returns:
            Status confirming AG profile removal.
        """
        try:
            await disable_hfp_ag()
            return {"status": "ok", "disabled": True}
        except Exception as exc:
            return {"status": "error", "error": str(exc)}

    @mcp.tool()
    async def bt_hfp_ag_status() -> dict[str, Any]:
        """Get HFP Audio Gateway status.

        Returns:
            - registered: Whether the AG profile is active
            - connections: List of connected HF devices with SLC state,
              codec, volumes, and active calls
            - indicators: Current indicator values (service, call, signal, etc.)
        """
        profile = await get_hfp_ag()
        if not profile:
            return {"status": "ok", "registered": False, "connections": []}
        return {"status": "ok", **profile.get_status()}

    @mcp.tool()
    async def bt_hfp_ag_simulate_call(
        address: str,
        number: str = "5551234567",
    ) -> dict[str, Any]:
        """Simulate an incoming call to a connected HF device.

        Sends RING and +CLIP (caller ID) notifications to the headset.
        The HF device will see an incoming call and can answer (ATA) or
        reject (AT+CHUP).

        Ringing repeats every 3 seconds until answered or ended.

        Args:
            address: Bluetooth address of the connected HF device.
            number: Caller phone number to display.

        Returns:
            Status of call initiation.
        """
        profile = await get_hfp_ag()
        if not profile:
            return {"status": "error", "error": "HFP AG not enabled"}

        ok = await profile.simulate_incoming_call(address, number=number)
        if ok:
            return {"status": "ok", "call_state": "ringing", "number": number}
        return {
            "status": "error",
            "error": "No SLC connection to device (connect HF first)",
        }

    @mcp.tool()
    async def bt_hfp_ag_end_call(address: str) -> dict[str, Any]:
        """End an active or ringing call from the AG side.

        Terminates the current call and sends indicator updates to the
        HF device.

        Args:
            address: Bluetooth address of the connected HF device.

        Returns:
            Status of call termination.
        """
        profile = await get_hfp_ag()
        if not profile:
            return {"status": "error", "error": "HFP AG not enabled"}

        ok = await profile.simulate_call_end(address)
        if ok:
            return {"status": "ok", "call_state": "ended"}
        return {"status": "error", "error": "No active call to end"}

    @mcp.tool()
    async def bt_hfp_ag_set_volume(
        address: str,
        type: Literal["speaker", "microphone"],
        level: int,
    ) -> dict[str, Any]:
        """Set speaker or microphone volume on the HF device.

        Sends +VGS (speaker) or +VGM (mic) to change volume remotely.

        Args:
            address: Bluetooth address of the connected HF device.
            type: "speaker" for output volume, "microphone" for input.
            level: Volume level 0-15 (0 = muted, 15 = maximum).

        Returns:
            Status with applied volume level.
        """
        profile = await get_hfp_ag()
        if not profile:
            return {"status": "error", "error": "HFP AG not enabled"}

        if type == "speaker":
            ok = await profile.set_speaker_volume(address, level)
        else:
            ok = await profile.set_mic_volume(address, level)

        if ok:
            return {"status": "ok", "type": type, "level": level}
        return {"status": "error", "error": "No SLC connection to device"}

    @mcp.tool()
    async def bt_hfp_ag_set_signal(
        address: str,
        level: int,
    ) -> dict[str, Any]:
        """Update the signal strength indicator shown on the HF device.

        Args:
            address: Bluetooth address of the connected HF device.
            level: Signal strength 0-5.

        Returns:
            Status with applied signal level.
        """
        profile = await get_hfp_ag()
        if not profile:
            return {"status": "error", "error": "HFP AG not enabled"}

        ok = await profile.set_signal_strength(address, level)
        if ok:
            return {"status": "ok", "signal_strength": level}
        return {"status": "error", "error": "No SLC connection to device"}

    @mcp.tool()
    async def bt_hfp_ag_set_battery(
        address: str,
        level: int,
    ) -> dict[str, Any]:
        """Update the battery level indicator shown on the HF device.

        Args:
            address: Bluetooth address of the connected HF device.
            level: Battery level 0-5.

        Returns:
            Status with applied battery level.
        """
        profile = await get_hfp_ag()
        if not profile:
            return {"status": "error", "error": "HFP AG not enabled"}

        ok = await profile.set_battery_level(address, level)
        if ok:
            return {"status": "ok", "battery_level": level}
        return {"status": "error", "error": "No SLC connection to device"}
