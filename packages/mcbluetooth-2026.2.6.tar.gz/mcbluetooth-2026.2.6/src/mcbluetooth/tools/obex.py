"""OBEX profile tools for BlueZ.

OBEX (Object Exchange) provides file transfer capabilities over Bluetooth:
- OPP (Object Push): Simple file sending
- FTP (File Transfer): Full file system browsing
- PBAP (Phonebook Access): Contact/call history access
- MAP (Message Access): SMS/MMS/email access

Requires the obexd daemon to be installed and running.
"""

import asyncio
import shutil
from dataclasses import asdict
from pathlib import Path
from typing import Any, Literal

from fastmcp import Context, FastMCP

from mcbluetooth.obex_client import (
    ObexTarget,
    get_obex_client,
)

# Type aliases
PbapLocation = Literal["int", "sim"]
PbapPhonebook = Literal["pb", "ich", "och", "mch", "cch"]
PbapSearchField = Literal["name", "number", "sound"]


def register_tools(mcp: FastMCP) -> None:
    """Register OBEX tools with the MCP server."""

    # ─────────────── Setup & Status ───────────────

    @mcp.tool()
    async def bt_obex_status(
        ctx: Context | None = None,
    ) -> dict[str, Any]:
        """Check OBEX subsystem status and requirements.

        Verifies that obexd is installed and accessible. Returns status
        of the OBEX daemon and any active sessions.

        Returns:
            Status dict with obexd availability and active sessions
        """
        result: dict[str, Any] = {
            "obexd_installed": False,
            "obexd_path": None,
            "obexd_running": False,
            "dbus_accessible": False,
            "active_sessions": [],
            "issues": [],
            "recommendations": [],
        }

        # Check if obexd binary exists
        obexd_paths = [
            "/usr/lib/bluetooth/obexd",
            "/usr/libexec/bluetooth/obexd",
            "/usr/lib/bluez/obexd",
        ]

        obexd_path = None
        for path in obexd_paths:
            if Path(path).exists():
                obexd_path = path
                break

        # Also check if it's in PATH (for custom installs)
        if not obexd_path:
            obexd_path = shutil.which("obexd")

        if obexd_path:
            result["obexd_installed"] = True
            result["obexd_path"] = obexd_path
            if ctx:
                await ctx.debug(f"Found obexd at {obexd_path}")
        else:
            result["issues"].append("obexd binary not found")
            result["recommendations"].append(
                "Install bluez-obex package (Arch: pacman -S bluez-obex, "
                "Debian/Ubuntu: apt install bluez-obex)"
            )

        # Check if obexd is running (via pgrep)
        try:
            proc = await asyncio.create_subprocess_exec(
                "pgrep", "-x", "obexd",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.DEVNULL,
            )
            stdout, _ = await proc.communicate()
            if proc.returncode == 0 and stdout.strip():
                result["obexd_running"] = True
                if ctx:
                    await ctx.debug("obexd is running")
            else:
                result["issues"].append("obexd daemon is not running")
                result["recommendations"].append(
                    "Start obexd with: /usr/lib/bluetooth/obexd (or add to autostart)"
                )
        except Exception:
            result["issues"].append("Could not check if obexd is running")

        # Try to connect to D-Bus
        try:
            client = await get_obex_client()
            result["dbus_accessible"] = True

            # Get active sessions
            sessions = client.list_sessions()
            result["active_sessions"] = [
                {
                    "session_id": s.session_id,
                    "address": s.address,
                    "target": s.target,
                }
                for s in sessions
            ]

            if ctx:
                await ctx.info(
                    f"OBEX ready: {len(sessions)} active session(s)"
                )
        except Exception as e:
            error_msg = str(e)
            result["dbus_accessible"] = False
            result["issues"].append(f"Cannot connect to obexd D-Bus: {error_msg}")

            if "org.bluez.obex" in error_msg or "ServiceUnknown" in error_msg:
                result["recommendations"].append(
                    "obexd is not registered on D-Bus. Start it manually: "
                    "/usr/lib/bluetooth/obexd"
                )
            elif "Connection refused" in error_msg:
                result["recommendations"].append(
                    "Session D-Bus not available. This usually requires a desktop session."
                )

        # Determine overall status
        if result["obexd_installed"] and result["dbus_accessible"]:
            result["status"] = "ready"
            if ctx:
                await ctx.info("OBEX subsystem is ready")
        elif result["obexd_installed"]:
            result["status"] = "obexd_not_running"
        else:
            result["status"] = "not_installed"

        return result

    @mcp.tool()
    async def bt_obex_start_daemon(
        ctx: Context | None = None,
    ) -> dict[str, Any]:
        """Attempt to start the obexd daemon.

        Tries to launch obexd as a background process. This may fail if
        obexd is already running or if permissions are insufficient.

        Returns:
            Status of the daemon start attempt
        """
        # Find obexd
        obexd_paths = [
            "/usr/lib/bluetooth/obexd",
            "/usr/libexec/bluetooth/obexd",
            "/usr/lib/bluez/obexd",
        ]

        obexd_path = None
        for path in obexd_paths:
            if Path(path).exists():
                obexd_path = path
                break

        if not obexd_path:
            return {
                "success": False,
                "error": "obexd not found. Install bluez-obex package.",
            }

        # Check if already running
        try:
            proc = await asyncio.create_subprocess_exec(
                "pgrep", "-x", "obexd",
                stdout=asyncio.subprocess.PIPE,
            )
            stdout, _ = await proc.communicate()
            if proc.returncode == 0 and stdout.strip():
                if ctx:
                    await ctx.info("obexd is already running")
                return {
                    "success": True,
                    "status": "already_running",
                    "pid": stdout.decode().strip(),
                }
        except Exception:
            pass

        # Try to start obexd
        if ctx:
            await ctx.info(f"Starting obexd from {obexd_path}")

        try:
            # Start obexd in background
            proc = await asyncio.create_subprocess_exec(
                obexd_path,
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.PIPE,
                start_new_session=True,  # Detach from this process group
            )

            # Wait briefly to see if it starts
            await asyncio.sleep(1.0)

            # Check if it's running
            check = await asyncio.create_subprocess_exec(
                "pgrep", "-x", "obexd",
                stdout=asyncio.subprocess.PIPE,
            )
            stdout, _ = await check.communicate()

            if check.returncode == 0 and stdout.strip():
                if ctx:
                    await ctx.info("obexd started successfully")
                return {
                    "success": True,
                    "status": "started",
                    "pid": stdout.decode().strip(),
                }
            else:
                # Try to get error message
                if proc.stderr:
                    stderr = await proc.stderr.read()
                    error_msg = stderr.decode().strip()
                else:
                    error_msg = "Unknown error"

                return {
                    "success": False,
                    "error": f"obexd failed to start: {error_msg}",
                    "suggestions": [
                        "Check D-Bus session is available",
                        "Run manually: " + obexd_path,
                        "Check logs: journalctl --user -u obex",
                    ],
                }

        except Exception as e:
            return {"success": False, "error": str(e)}

    # ─────────────── Session Management ───────────────

    @mcp.tool()
    async def bt_obex_connect(
        address: str,
        target: ObexTarget,
        ctx: Context | None = None,
    ) -> dict[str, Any]:
        """Create an OBEX session to a device.

        Establishes a connection for file transfer or data access.
        The session_id is used for subsequent operations.

        Args:
            address: Device Bluetooth address (e.g., "AA:BB:CC:DD:EE:FF")
            target: OBEX profile to use:
                - "opp": Object Push (send files)
                - "ftp": File Transfer (browse & transfer files)
                - "pbap": Phonebook Access (read contacts)
                - "map": Message Access (read SMS/MMS)

        Returns:
            Session info with session_id for subsequent operations
        """
        if ctx:
            await ctx.info(f"Connecting OBEX {target.upper()} to {address}")

        try:
            client = await get_obex_client()
            session = await client.create_session(address, target)

            if ctx:
                await ctx.info(f"Session created: {session.session_id}")

            return {
                "success": True,
                "session_id": session.session_id,
                "address": session.address,
                "target": session.target,
                "source": session.source,
                "root": session.root,
            }
        except Exception as e:
            error_msg = str(e)
            if ctx:
                await ctx.error(f"Failed to create session: {error_msg}")

            hints = []
            if "NotFound" in error_msg or "DoesNotExist" in error_msg:
                hints.append("Device may not be in range or discoverable")
                hints.append("Ensure device is paired first with bt_pair")
            if "NotAuthorized" in error_msg or "Rejected" in error_msg:
                hints.append("Device rejected the connection")
                hints.append(f"Enable {target.upper()} profile on the device")
            if "NotSupported" in error_msg:
                hints.append(f"Device does not support {target.upper()} profile")

            return {"success": False, "error": error_msg, "hints": hints}

    @mcp.tool()
    async def bt_obex_disconnect(
        session_id: str,
        ctx: Context | None = None,
    ) -> dict[str, Any]:
        """Close an OBEX session.

        Args:
            session_id: Session ID from bt_obex_connect

        Returns:
            Status of the disconnect operation
        """
        if ctx:
            await ctx.info(f"Closing OBEX session: {session_id}")

        try:
            client = await get_obex_client()
            await client.remove_session(session_id)

            if ctx:
                await ctx.info("Session closed")
            return {"success": True, "session_id": session_id}
        except Exception as e:
            if ctx:
                await ctx.error(f"Failed to close session: {e}")
            return {"success": False, "error": str(e)}

    @mcp.tool()
    async def bt_obex_sessions(
        ctx: Context | None = None,
    ) -> dict[str, Any]:
        """List active OBEX sessions.

        Returns:
            List of active sessions with their details
        """
        try:
            client = await get_obex_client()
            sessions = client.list_sessions()

            if ctx:
                await ctx.info(f"Found {len(sessions)} active session(s)")

            return {
                "success": True,
                "sessions": [asdict(s) for s in sessions],
                "count": len(sessions),
            }
        except Exception as e:
            return {"success": False, "error": str(e)}

    # ─────────────── OPP (Object Push) ───────────────

    @mcp.tool()
    async def bt_obex_send_file(
        address: str,
        file_path: str,
        wait: bool = True,
        ctx: Context | None = None,
    ) -> dict[str, Any]:
        """Send a file to a device via Object Push Profile.

        Creates a temporary OPP session, sends the file, and closes the session.
        The receiving device will show a prompt to accept/reject.

        Args:
            address: Device Bluetooth address
            file_path: Path to the local file to send
            wait: Wait for transfer to complete (default True)

        Returns:
            Transfer status and file info
        """
        # Validate file exists
        path = Path(file_path).expanduser().resolve()
        if not path.exists():
            return {"success": False, "error": f"File not found: {file_path}"}

        if ctx:
            await ctx.info(f"Sending {path.name} to {address}")

        client = await get_obex_client()
        session = None

        try:
            # Create OPP session
            session = await client.create_session(address, "opp")
            if ctx:
                await ctx.debug(f"OPP session created: {session.session_id}")

            # Start transfer
            transfer_path = await client.opp_send_file(session.session_id, str(path))
            if ctx:
                await ctx.debug(f"Transfer started: {transfer_path}")

            if wait:
                # Wait for completion with progress
                transfer = await client.wait_for_transfer(transfer_path, timeout=300)

                if transfer.status == "complete":
                    if ctx:
                        await ctx.info(f"File sent successfully: {path.name}")
                    return {
                        "success": True,
                        "status": "complete",
                        "filename": path.name,
                        "size": transfer.size,
                        "transferred": transfer.transferred,
                    }
                else:
                    if ctx:
                        await ctx.error(f"Transfer failed: {transfer.status}")
                    return {
                        "success": False,
                        "status": transfer.status,
                        "error": "Transfer failed or was rejected",
                    }
            else:
                # Return immediately
                return {
                    "success": True,
                    "status": "started",
                    "session_id": session.session_id,
                    "transfer_path": transfer_path,
                    "message": "Transfer started. Use bt_obex_transfer_status to monitor.",
                }

        except Exception as e:
            if ctx:
                await ctx.error(f"Send failed: {e}")
            return {"success": False, "error": str(e)}

        finally:
            # Clean up session (if we waited for completion)
            if session and wait:
                try:
                    await client.remove_session(session.session_id)
                except Exception:
                    pass

    @mcp.tool()
    async def bt_obex_get_vcard(
        address: str,
        save_path: str,
        ctx: Context | None = None,
    ) -> dict[str, Any]:
        """Pull the default business card (vCard) from a device.

        Uses Object Push Profile to retrieve the device's default vCard.

        Args:
            address: Device Bluetooth address
            save_path: Local path to save the vCard file

        Returns:
            Status and saved file path
        """
        save_path_obj = Path(save_path).expanduser().resolve()
        save_path_obj.parent.mkdir(parents=True, exist_ok=True)

        if ctx:
            await ctx.info(f"Pulling vCard from {address}")

        client = await get_obex_client()
        session = None

        try:
            session = await client.create_session(address, "opp")
            transfer_path = await client.opp_pull_business_card(
                session.session_id, str(save_path_obj)
            )

            transfer = await client.wait_for_transfer(transfer_path, timeout=60)

            if transfer.status == "complete":
                if ctx:
                    await ctx.info(f"vCard saved to {save_path_obj}")
                return {
                    "success": True,
                    "status": "complete",
                    "file": str(save_path_obj),
                    "size": transfer.size,
                }
            else:
                return {
                    "success": False,
                    "status": transfer.status,
                    "error": "Failed to retrieve vCard",
                }

        except Exception as e:
            if ctx:
                await ctx.error(f"Failed to get vCard: {e}")
            return {"success": False, "error": str(e)}

        finally:
            if session:
                try:
                    await client.remove_session(session.session_id)
                except Exception:
                    pass

    # ─────────────── FTP (File Transfer) ───────────────

    @mcp.tool()
    async def bt_obex_browse(
        session_id: str,
        path: str = "/",
        ctx: Context | None = None,
    ) -> dict[str, Any]:
        """List files and folders on the device.

        Requires an active FTP session. Navigate using path parameter:
        - "/" for root
        - ".." to go up
        - "folder_name" to enter a folder

        Args:
            session_id: FTP session ID from bt_obex_connect
            path: Path to navigate to before listing ("/" = root, ".." = parent)

        Returns:
            List of files and folders with metadata
        """
        client = await get_obex_client()
        session = client.get_session(session_id)

        if not session:
            return {"success": False, "error": f"Unknown session: {session_id}"}
        if session.target != "ftp":
            return {"success": False, "error": "Session is not an FTP session"}

        try:
            # Navigate if path specified
            if path and path != ".":
                if ctx:
                    await ctx.debug(f"Navigating to: {path}")
                await client.ftp_change_folder(session_id, path)

            # List contents
            entries = await client.ftp_list_folder(session_id)

            if ctx:
                await ctx.info(f"Found {len(entries)} items")

            return {
                "success": True,
                "entries": [asdict(e) for e in entries],
                "count": len(entries),
            }

        except Exception as e:
            if ctx:
                await ctx.error(f"Browse failed: {e}")
            return {"success": False, "error": str(e)}

    @mcp.tool()
    async def bt_obex_get(
        session_id: str,
        remote_path: str,
        local_path: str,
        ctx: Context | None = None,
    ) -> dict[str, Any]:
        """Download a file from the device.

        Requires an active FTP session. The remote_path is relative to
        the current folder (use bt_obex_browse to navigate first).

        Args:
            session_id: FTP session ID
            remote_path: File name on the device
            local_path: Local path to save the file

        Returns:
            Transfer status
        """
        local_path_obj = Path(local_path).expanduser().resolve()
        local_path_obj.parent.mkdir(parents=True, exist_ok=True)

        client = await get_obex_client()
        session = client.get_session(session_id)

        if not session:
            return {"success": False, "error": f"Unknown session: {session_id}"}
        if session.target != "ftp":
            return {"success": False, "error": "Session is not an FTP session"}

        if ctx:
            await ctx.info(f"Downloading {remote_path}")

        try:
            transfer_path = await client.ftp_get_file(
                session_id, remote_path, str(local_path_obj)
            )

            transfer = await client.wait_for_transfer(transfer_path, timeout=300)

            if transfer.status == "complete":
                if ctx:
                    await ctx.info(f"Downloaded to {local_path_obj}")
                return {
                    "success": True,
                    "status": "complete",
                    "local_path": str(local_path_obj),
                    "size": transfer.size,
                }
            else:
                return {
                    "success": False,
                    "status": transfer.status,
                    "error": "Download failed",
                }

        except Exception as e:
            if ctx:
                await ctx.error(f"Download failed: {e}")
            return {"success": False, "error": str(e)}

    @mcp.tool()
    async def bt_obex_put(
        session_id: str,
        local_path: str,
        remote_path: str,
        ctx: Context | None = None,
    ) -> dict[str, Any]:
        """Upload a file to the device.

        Requires an active FTP session. The remote_path is the filename
        to use in the current remote folder.

        Args:
            session_id: FTP session ID
            local_path: Path to local file
            remote_path: Filename to use on device

        Returns:
            Transfer status
        """
        local_path_obj = Path(local_path).expanduser().resolve()
        if not local_path_obj.exists():
            return {"success": False, "error": f"File not found: {local_path}"}

        client = await get_obex_client()
        session = client.get_session(session_id)

        if not session:
            return {"success": False, "error": f"Unknown session: {session_id}"}
        if session.target != "ftp":
            return {"success": False, "error": "Session is not an FTP session"}

        if ctx:
            await ctx.info(f"Uploading {local_path_obj.name} to {remote_path}")

        try:
            transfer_path = await client.ftp_put_file(
                session_id, str(local_path_obj), remote_path
            )

            transfer = await client.wait_for_transfer(transfer_path, timeout=300)

            if transfer.status == "complete":
                if ctx:
                    await ctx.info(f"Uploaded {transfer.size} bytes")
                return {
                    "success": True,
                    "status": "complete",
                    "remote_path": remote_path,
                    "size": transfer.size,
                }
            else:
                return {
                    "success": False,
                    "status": transfer.status,
                    "error": "Upload failed",
                }

        except Exception as e:
            if ctx:
                await ctx.error(f"Upload failed: {e}")
            return {"success": False, "error": str(e)}

    @mcp.tool()
    async def bt_obex_delete(
        session_id: str,
        remote_path: str,
        ctx: Context | None = None,
    ) -> dict[str, Any]:
        """Delete a file or folder on the device.

        Args:
            session_id: FTP session ID
            remote_path: File or folder name to delete

        Returns:
            Status of the delete operation
        """
        client = await get_obex_client()
        session = client.get_session(session_id)

        if not session:
            return {"success": False, "error": f"Unknown session: {session_id}"}
        if session.target != "ftp":
            return {"success": False, "error": "Session is not an FTP session"}

        if ctx:
            await ctx.info(f"Deleting {remote_path}")

        try:
            await client.ftp_delete(session_id, remote_path)
            if ctx:
                await ctx.info("Deleted successfully")
            return {"success": True, "deleted": remote_path}
        except Exception as e:
            if ctx:
                await ctx.error(f"Delete failed: {e}")
            return {"success": False, "error": str(e)}

    @mcp.tool()
    async def bt_obex_mkdir(
        session_id: str,
        folder_name: str,
        ctx: Context | None = None,
    ) -> dict[str, Any]:
        """Create a folder on the device.

        Args:
            session_id: FTP session ID
            folder_name: Name of folder to create

        Returns:
            Status of the mkdir operation
        """
        client = await get_obex_client()
        session = client.get_session(session_id)

        if not session:
            return {"success": False, "error": f"Unknown session: {session_id}"}
        if session.target != "ftp":
            return {"success": False, "error": "Session is not an FTP session"}

        if ctx:
            await ctx.info(f"Creating folder: {folder_name}")

        try:
            await client.ftp_create_folder(session_id, folder_name)
            if ctx:
                await ctx.info("Folder created")
            return {"success": True, "folder": folder_name}
        except Exception as e:
            if ctx:
                await ctx.error(f"mkdir failed: {e}")
            return {"success": False, "error": str(e)}

    # ─────────────── PBAP (Phonebook) ───────────────

    @mcp.tool()
    async def bt_phonebook_pull(
        address: str,
        save_path: str,
        location: PbapLocation = "int",
        phonebook: PbapPhonebook = "pb",
        ctx: Context | None = None,
    ) -> dict[str, Any]:
        """Download the entire phonebook as a vCard file.

        Creates a PBAP session, downloads all contacts, and saves them.

        Args:
            address: Device Bluetooth address
            save_path: Local path to save the vCard file
            location: "int" (internal memory) or "sim" (SIM card)
            phonebook: Which phonebook to pull:
                - "pb": Main phonebook/contacts
                - "ich": Incoming call history
                - "och": Outgoing call history
                - "mch": Missed call history
                - "cch": Combined call history

        Returns:
            Status and file info
        """
        save_path_obj = Path(save_path).expanduser().resolve()
        save_path_obj.parent.mkdir(parents=True, exist_ok=True)

        if ctx:
            await ctx.info(f"Pulling {phonebook} from {address}")

        client = await get_obex_client()
        session = None

        try:
            session = await client.create_session(address, "pbap")
            if ctx:
                await ctx.debug(f"PBAP session: {session.session_id}")

            # Select phonebook
            await client.pbap_select(session.session_id, location, phonebook)

            # Pull all entries
            transfer_path = await client.pbap_pull_all(
                session.session_id, str(save_path_obj)
            )

            transfer = await client.wait_for_transfer(transfer_path, timeout=120)

            if transfer.status == "complete":
                if ctx:
                    await ctx.info(f"Phonebook saved to {save_path_obj}")
                return {
                    "success": True,
                    "status": "complete",
                    "file": str(save_path_obj),
                    "size": transfer.size,
                    "phonebook": phonebook,
                    "location": location,
                }
            else:
                return {
                    "success": False,
                    "status": transfer.status,
                    "error": "Failed to pull phonebook",
                }

        except Exception as e:
            if ctx:
                await ctx.error(f"Phonebook pull failed: {e}")
            return {"success": False, "error": str(e)}

        finally:
            if session:
                try:
                    await client.remove_session(session.session_id)
                except Exception:
                    pass

    @mcp.tool()
    async def bt_phonebook_list(
        address: str,
        location: PbapLocation = "int",
        phonebook: PbapPhonebook = "pb",
        ctx: Context | None = None,
    ) -> dict[str, Any]:
        """List phonebook entries with handles and names.

        Use the handles with bt_phonebook_get to download individual entries.

        Args:
            address: Device Bluetooth address
            location: "int" (internal) or "sim"
            phonebook: Which phonebook to list

        Returns:
            List of phonebook entries
        """
        if ctx:
            await ctx.info(f"Listing {phonebook} from {address}")

        client = await get_obex_client()
        session = None

        try:
            session = await client.create_session(address, "pbap")
            await client.pbap_select(session.session_id, location, phonebook)

            entries = await client.pbap_list(session.session_id)

            if ctx:
                await ctx.info(f"Found {len(entries)} entries")

            return {
                "success": True,
                "entries": [asdict(e) for e in entries],
                "count": len(entries),
                "phonebook": phonebook,
            }

        except Exception as e:
            if ctx:
                await ctx.error(f"List failed: {e}")
            return {"success": False, "error": str(e)}

        finally:
            if session:
                try:
                    await client.remove_session(session.session_id)
                except Exception:
                    pass

    @mcp.tool()
    async def bt_phonebook_get(
        address: str,
        handle: str,
        save_path: str,
        location: PbapLocation = "int",
        phonebook: PbapPhonebook = "pb",
        ctx: Context | None = None,
    ) -> dict[str, Any]:
        """Download a single phonebook entry by handle.

        Args:
            address: Device Bluetooth address
            handle: Entry handle from bt_phonebook_list
            save_path: Local path to save the vCard
            location: "int" or "sim"
            phonebook: Which phonebook

        Returns:
            Status and file path
        """
        save_path_obj = Path(save_path).expanduser().resolve()
        save_path_obj.parent.mkdir(parents=True, exist_ok=True)

        if ctx:
            await ctx.info(f"Getting entry {handle} from {address}")

        client = await get_obex_client()
        session = None

        try:
            session = await client.create_session(address, "pbap")
            await client.pbap_select(session.session_id, location, phonebook)

            transfer_path = await client.pbap_pull(
                session.session_id, handle, str(save_path_obj)
            )

            transfer = await client.wait_for_transfer(transfer_path, timeout=30)

            if transfer.status == "complete":
                if ctx:
                    await ctx.info(f"Entry saved to {save_path_obj}")
                return {
                    "success": True,
                    "file": str(save_path_obj),
                    "size": transfer.size,
                }
            else:
                return {"success": False, "error": "Failed to get entry"}

        except Exception as e:
            if ctx:
                await ctx.error(f"Get failed: {e}")
            return {"success": False, "error": str(e)}

        finally:
            if session:
                try:
                    await client.remove_session(session.session_id)
                except Exception:
                    pass

    @mcp.tool()
    async def bt_phonebook_search(
        address: str,
        field: PbapSearchField,
        value: str,
        location: PbapLocation = "int",
        phonebook: PbapPhonebook = "pb",
        ctx: Context | None = None,
    ) -> dict[str, Any]:
        """Search the phonebook.

        Args:
            address: Device Bluetooth address
            field: Field to search - "name", "number", or "sound"
            value: Search value
            location: "int" or "sim"
            phonebook: Which phonebook

        Returns:
            Matching entries
        """
        if ctx:
            await ctx.info(f"Searching {field}='{value}' in {phonebook}")

        client = await get_obex_client()
        session = None

        try:
            session = await client.create_session(address, "pbap")
            await client.pbap_select(session.session_id, location, phonebook)

            entries = await client.pbap_search(session.session_id, field, value)

            if ctx:
                await ctx.info(f"Found {len(entries)} matches")

            return {
                "success": True,
                "entries": [asdict(e) for e in entries],
                "count": len(entries),
            }

        except Exception as e:
            if ctx:
                await ctx.error(f"Search failed: {e}")
            return {"success": False, "error": str(e)}

        finally:
            if session:
                try:
                    await client.remove_session(session.session_id)
                except Exception:
                    pass

    @mcp.tool()
    async def bt_phonebook_count(
        address: str,
        location: PbapLocation = "int",
        phonebook: PbapPhonebook = "pb",
        ctx: Context | None = None,
    ) -> dict[str, Any]:
        """Get the number of entries in a phonebook.

        Args:
            address: Device Bluetooth address
            location: "int" or "sim"
            phonebook: Which phonebook

        Returns:
            Count of entries
        """
        if ctx:
            await ctx.info(f"Counting entries in {phonebook}")

        client = await get_obex_client()
        session = None

        try:
            session = await client.create_session(address, "pbap")
            await client.pbap_select(session.session_id, location, phonebook)

            count = await client.pbap_get_size(session.session_id)

            if ctx:
                await ctx.info(f"Phonebook has {count} entries")

            return {
                "success": True,
                "count": count,
                "phonebook": phonebook,
                "location": location,
            }

        except Exception as e:
            if ctx:
                await ctx.error(f"Count failed: {e}")
            return {"success": False, "error": str(e)}

        finally:
            if session:
                try:
                    await client.remove_session(session.session_id)
                except Exception:
                    pass

    # ─────────────── MAP (Messages) ───────────────

    @mcp.tool()
    async def bt_messages_folders(
        address: str,
        ctx: Context | None = None,
    ) -> dict[str, Any]:
        """List message folders on the device.

        Args:
            address: Device Bluetooth address

        Returns:
            List of message folders
        """
        if ctx:
            await ctx.info(f"Listing message folders from {address}")

        client = await get_obex_client()
        session = None

        try:
            session = await client.create_session(address, "map")

            folders = await client.map_list_folders(session.session_id)

            if ctx:
                await ctx.info(f"Found {len(folders)} folders")

            return {
                "success": True,
                "folders": folders,
                "count": len(folders),
            }

        except Exception as e:
            if ctx:
                await ctx.error(f"List folders failed: {e}")
            return {"success": False, "error": str(e)}

        finally:
            if session:
                try:
                    await client.remove_session(session.session_id)
                except Exception:
                    pass

    @mcp.tool()
    async def bt_messages_list(
        address: str,
        folder: str = "inbox",
        unread_only: bool = False,
        max_count: int = 100,
        ctx: Context | None = None,
    ) -> dict[str, Any]:
        """List messages in a folder.

        Args:
            address: Device Bluetooth address
            folder: Folder name (e.g., "inbox", "sent", "draft")
            unread_only: Only return unread messages
            max_count: Maximum messages to return

        Returns:
            List of messages with metadata
        """
        if ctx:
            await ctx.info(f"Listing messages in {folder}")

        client = await get_obex_client()
        session = None

        try:
            session = await client.create_session(address, "map")

            filters = {"MaxListCount": max_count}
            if unread_only:
                filters["FilterReadStatus"] = "unread"

            messages = await client.map_list_messages(
                session.session_id, folder, filters
            )

            if ctx:
                await ctx.info(f"Found {len(messages)} messages")

            return {
                "success": True,
                "messages": [asdict(m) for m in messages],
                "count": len(messages),
                "folder": folder,
            }

        except Exception as e:
            if ctx:
                await ctx.error(f"List messages failed: {e}")
            return {"success": False, "error": str(e)}

        finally:
            if session:
                try:
                    await client.remove_session(session.session_id)
                except Exception:
                    pass

    @mcp.tool()
    async def bt_messages_get(
        address: str,
        handle: str,
        save_path: str,
        include_attachment: bool = False,
        ctx: Context | None = None,
    ) -> dict[str, Any]:
        """Download a specific message by handle.

        Args:
            address: Device Bluetooth address
            handle: Message handle from bt_messages_list
            save_path: Local path to save the message
            include_attachment: Include attachments in download

        Returns:
            Status and file path
        """
        save_path_obj = Path(save_path).expanduser().resolve()
        save_path_obj.parent.mkdir(parents=True, exist_ok=True)

        if ctx:
            await ctx.info(f"Getting message {handle}")

        client = await get_obex_client()
        session = None

        try:
            session = await client.create_session(address, "map")

            transfer_path = await client.map_get_message(
                session.session_id, handle, str(save_path_obj), include_attachment
            )

            transfer = await client.wait_for_transfer(transfer_path, timeout=60)

            if transfer.status == "complete":
                if ctx:
                    await ctx.info(f"Message saved to {save_path_obj}")
                return {
                    "success": True,
                    "file": str(save_path_obj),
                    "size": transfer.size,
                }
            else:
                return {"success": False, "error": "Failed to get message"}

        except Exception as e:
            if ctx:
                await ctx.error(f"Get message failed: {e}")
            return {"success": False, "error": str(e)}

        finally:
            if session:
                try:
                    await client.remove_session(session.session_id)
                except Exception:
                    pass

    @mcp.tool()
    async def bt_messages_send(
        address: str,
        recipient: str,
        message: str,
        ctx: Context | None = None,
    ) -> dict[str, Any]:
        """Send an SMS message via MAP.

        Note: This requires the phone to support MAP message pushing.
        Not all devices support this feature.

        Args:
            address: Device Bluetooth address
            recipient: Phone number to send to
            message: Message text

        Returns:
            Status of the send operation
        """
        import tempfile

        if ctx:
            await ctx.info(f"Sending message to {recipient}")

        client = await get_obex_client()
        session = None

        try:
            session = await client.create_session(address, "map")

            # Create bMessage format
            bmessage = f"""BEGIN:BMSG
VERSION:1.0
STATUS:UNREAD
TYPE:SMS_GSM
FOLDER:
BEGIN:VCARD
VERSION:2.1
TEL:{recipient}
END:VCARD
BEGIN:BENV
BEGIN:BBODY
CHARSET:UTF-8
LENGTH:{len(message.encode('utf-8'))}
BEGIN:MSG
{message}
END:MSG
END:BBODY
END:BENV
END:BMSG
"""

            # Write to temp file
            with tempfile.NamedTemporaryFile(
                mode="w", suffix=".bmsg", delete=False
            ) as f:
                f.write(bmessage)
                msg_path = f.name

            try:
                handle = await client.map_push_message(
                    session.session_id, "outbox", msg_path
                )

                if ctx:
                    await ctx.info(f"Message sent, handle: {handle}")

                return {
                    "success": True,
                    "handle": handle,
                    "recipient": recipient,
                }

            finally:
                # Clean up temp file
                Path(msg_path).unlink(missing_ok=True)

        except Exception as e:
            error_msg = str(e)
            if ctx:
                await ctx.error(f"Send failed: {e}")

            hints = []
            if "NotSupported" in error_msg:
                hints.append("This device may not support sending messages via MAP")

            return {"success": False, "error": error_msg, "hints": hints}

        finally:
            if session:
                try:
                    await client.remove_session(session.session_id)
                except Exception:
                    pass

    # ─────────────── Transfer Management ───────────────

    @mcp.tool()
    async def bt_obex_transfer_status(
        transfer_path: str,
        ctx: Context | None = None,
    ) -> dict[str, Any]:
        """Check the status of an OBEX transfer.

        Args:
            transfer_path: Transfer path from a transfer operation

        Returns:
            Transfer status and progress
        """
        try:
            client = await get_obex_client()
            transfer = await client.get_transfer_status(transfer_path)

            progress = 0
            if transfer.size > 0:
                progress = int((transfer.transferred / transfer.size) * 100)

            if ctx:
                await ctx.info(f"Transfer: {transfer.status} ({progress}%)")

            return {
                "success": True,
                "status": transfer.status,
                "name": transfer.name,
                "size": transfer.size,
                "transferred": transfer.transferred,
                "progress_percent": progress,
            }

        except Exception as e:
            return {"success": False, "error": str(e)}

    @mcp.tool()
    async def bt_obex_transfer_cancel(
        transfer_path: str,
        ctx: Context | None = None,
    ) -> dict[str, Any]:
        """Cancel an active OBEX transfer.

        Args:
            transfer_path: Transfer path to cancel

        Returns:
            Status of cancellation
        """
        try:
            client = await get_obex_client()
            await client.cancel_transfer(transfer_path)

            if ctx:
                await ctx.info("Transfer cancelled")

            return {"success": True, "cancelled": transfer_path}

        except Exception as e:
            if ctx:
                await ctx.error(f"Cancel failed: {e}")
            return {"success": False, "error": str(e)}
