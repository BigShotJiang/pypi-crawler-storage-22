"""Tests for mcbluetooth."""
