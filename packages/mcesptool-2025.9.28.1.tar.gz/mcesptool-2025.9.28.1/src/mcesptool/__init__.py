"""
FastMCP ESPTool Server

A comprehensive FastMCP server for ESP32/ESP8266 development with esptool integration.
Provides AI-powered ESP development workflows with production-grade capabilities.
"""

__version__ = "2025.09.28.1"
__author__ = "ESP Development Team"
__description__ = "FastMCP server for ESP32/ESP8266 development with esptool integration"

# Package-level imports for easy access
from .config import ESPToolServerConfig
from .server import ESPToolServer, main

__all__ = [
    "ESPToolServer",
    "ESPToolServerConfig",
    "main",
    "__version__",
]
