"""
ESP Development Components

Modular components for ESP32/ESP8266 development workflows.
Each component provides specialized functionality while maintaining clean interfaces.
"""

from .chip_control import ChipControl
from .diagnostics import Diagnostics
from .firmware_builder import FirmwareBuilder
from .flash_manager import FlashManager
from .ota_manager import OTAManager
from .partition_manager import PartitionManager
from .production_tools import ProductionTools
from .qemu_manager import QemuManager
from .security_manager import SecurityManager

# Component registry for dynamic loading
COMPONENT_REGISTRY = {
    "chip_control": ChipControl,
    "flash_manager": FlashManager,
    "partition_manager": PartitionManager,
    "security_manager": SecurityManager,
    "firmware_builder": FirmwareBuilder,
    "ota_manager": OTAManager,
    "production_tools": ProductionTools,
    "diagnostics": Diagnostics,
    "qemu_manager": QemuManager,
}

__all__ = [
    "ChipControl",
    "FlashManager",
    "PartitionManager",
    "SecurityManager",
    "FirmwareBuilder",
    "OTAManager",
    "ProductionTools",
    "Diagnostics",
    "QemuManager",
    "COMPONENT_REGISTRY",
]
