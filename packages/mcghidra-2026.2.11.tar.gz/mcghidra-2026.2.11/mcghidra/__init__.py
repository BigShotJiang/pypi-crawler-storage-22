"""MCGhidra - AI-assisted reverse engineering bridge for Ghidra.

A multi-instance Ghidra plugin exposed via HATEOAS REST API plus an MCP
Python bridge for decompilation, analysis & binary manipulation.
"""

try:
    from importlib.metadata import version
    __version__ = version("mcghidra")
except Exception:
    __version__ = "2025.12.1"

from .server import create_server, main

__all__ = ["create_server", "main", "__version__"]
