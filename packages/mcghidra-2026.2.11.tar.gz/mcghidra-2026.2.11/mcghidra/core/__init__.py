"""Core infrastructure for MCGhidra.

Contains HTTP client, pagination, progress reporting, and logging utilities.
"""

from .filtering import (
    apply_grep,
    estimate_and_guard,
    project_fields,
)
from .http_client import (
    get_instance_url,
    safe_delete,
    safe_get,
    safe_patch,
    safe_post,
    safe_put,
    simplify_response,
)
from .logging import (
    log_debug,
    log_error,
    log_info,
    log_warning,
)
from .pagination import (
    CursorManager,
    CursorState,
    estimate_tokens,
    get_cursor_manager,
    paginate_response,
)
from .progress import (
    ProgressReporter,
    report_progress,
    report_step,
)

__all__ = [
    # HTTP client
    "safe_get",
    "safe_post",
    "safe_put",
    "safe_patch",
    "safe_delete",
    "simplify_response",
    "get_instance_url",
    # Pagination
    "CursorManager",
    "CursorState",
    "paginate_response",
    "get_cursor_manager",
    "estimate_tokens",
    # Progress
    "ProgressReporter",
    "report_progress",
    "report_step",
    # Filtering
    "project_fields",
    "apply_grep",
    "estimate_and_guard",
    # Logging
    "log_info",
    "log_debug",
    "log_warning",
    "log_error",
]
