Base Module
===========

.. automodule:: mcgrad.base
   :members:
   :undoc-members:
   :show-inheritance:
