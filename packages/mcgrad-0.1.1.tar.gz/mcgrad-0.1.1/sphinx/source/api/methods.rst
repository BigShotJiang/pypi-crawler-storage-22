Methods Module
==============

.. automodule:: mcgrad.methods
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :exclude-members: __weakref__, __dict__, __module__
