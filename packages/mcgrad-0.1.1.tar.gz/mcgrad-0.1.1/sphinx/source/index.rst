Welcome to mcgrad's API documentation!
==================================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   api/base
   api/methods
   api/metrics
   api/plotting
   api/tuning


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
