// @ts-check
import { defineConfig } from 'astro/config';
import starlight from '@astrojs/starlight';

export default defineConfig({
  site: process.env.PUBLIC_DOMAIN
    ? `https://${process.env.PUBLIC_DOMAIN}`
    : 'http://localhost:4321',

  telemetry: false,

  devToolbar: { enabled: false },

  vite: {
    server: {
      host: '0.0.0.0',
      allowedHosts: process.env.PUBLIC_DOMAIN
        ? [process.env.PUBLIC_DOMAIN, 'localhost']
        : ['localhost'],
      ...(process.env.VITE_HMR_HOST && {
        hmr: {
          host: process.env.VITE_HMR_HOST,
          protocol: 'wss',
          clientPort: 443,
        },
      }),
    },
  },

  integrations: [
    starlight({
      title: 'mcjtag',
      description: 'MCP server for JTAG/SWD/MWD debug probe communication via Model Context Protocol',

      social: [
        {
          icon: 'gitlab',
          label: 'Source',
          href: 'https://git.supported.systems/warehack.ing/mcjtag',
        },
      ],

      customCss: ['./src/styles/custom.css'],

      sidebar: [
        {
          label: 'Overview',
          items: [{ label: 'Introduction', link: '/' }],
        },
        {
          label: 'Tutorials',
          autogenerate: { directory: 'tutorials' },
        },
        {
          label: 'Guides',
          autogenerate: { directory: 'guides' },
        },
        {
          label: 'Reference',
          autogenerate: { directory: 'reference' },
        },
        {
          label: 'Concepts',
          autogenerate: { directory: 'concepts' },
        },
      ],

      tableOfContents: { minHeadingLevel: 2, maxHeadingLevel: 3 },
    }),
  ],
});
