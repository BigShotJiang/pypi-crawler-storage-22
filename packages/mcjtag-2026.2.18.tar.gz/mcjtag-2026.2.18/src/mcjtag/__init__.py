"""mcjtag — JTAG/SWD MCP Server for hardware debugging via OpenOCD."""

try:
    from importlib.metadata import version

    __version__ = version("mcjtag")
except Exception:
    __version__ = "2026.2.12"
