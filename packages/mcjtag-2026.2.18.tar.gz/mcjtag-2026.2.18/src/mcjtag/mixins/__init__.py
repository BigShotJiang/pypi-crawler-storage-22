"""MCP Mixins for mcjtag JTAG/SWD Server."""

from mcjtag.mixins.breakpoints import BreakpointMixin
from mcjtag.mixins.connection import ConnectionMixin
from mcjtag.mixins.diagnostics import DiagnosticsMixin
from mcjtag.mixins.flash import FlashMixin
from mcjtag.mixins.jtag import JTAGMixin
from mcjtag.mixins.memory import MemoryMixin
from mcjtag.mixins.raw import RawMixin
from mcjtag.mixins.registers import RegistersMixin
from mcjtag.mixins.rtt import RTTMixin
from mcjtag.mixins.svd import SVDMixin
from mcjtag.mixins.swd import SWDMixin
from mcjtag.mixins.target import TargetMixin
from mcjtag.mixins.transport import TransportMixin

__all__ = [
    "BreakpointMixin",
    "ConnectionMixin",
    "DiagnosticsMixin",
    "FlashMixin",
    "JTAGMixin",
    "MemoryMixin",
    "RawMixin",
    "RegistersMixin",
    "RTTMixin",
    "SVDMixin",
    "SWDMixin",
    "TargetMixin",
    "TransportMixin",
]
