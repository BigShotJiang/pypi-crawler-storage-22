"""Pydantic response models for mcjtag tools."""

from __future__ import annotations

from pydantic import BaseModel


class ConnectionStatus(BaseModel):
    """Result of connect/disconnect operations."""

    connected: bool
    host: str | None = None
    port: int | None = None
    process_pid: int | None = None
    message: str = ""


class TargetStateResult(BaseModel):
    """Snapshot of target execution state."""

    state: str
    pc: str | None = None
    halted: bool
    name: str = ""


class TargetControlResult(BaseModel):
    """Result of halt/resume/step/reset operations."""

    action: str
    state: str
    pc: str | None = None
    halted: bool


class MemoryDump(BaseModel):
    """Memory read result with hex values and formatted hexdump."""

    address: str
    width: int
    count: int
    values: list[str]
    hexdump: str


class MemoryWriteResult(BaseModel):
    """Confirmation of a memory write."""

    address: str
    width: int
    count: int
    written: bool


class MemorySearchResult(BaseModel):
    """Addresses where a byte pattern was found."""

    pattern: str
    start: str
    end: str
    matches: list[str]
    count: int


class RegisterSet(BaseModel):
    """One or more CPU register values."""

    registers: dict[str, str]
    count: int


class RegisterWriteResult(BaseModel):
    """Confirmation of a register write."""

    name: str
    value: str
    written: bool


class FlashBankInfo(BaseModel):
    """One flash bank descriptor."""

    index: int
    name: str
    base: str
    size: int
    sectors: int
    target: str


class FlashBanksResult(BaseModel):
    """All flash banks on the target."""

    banks: list[FlashBankInfo]
    count: int


class FlashProgramResult(BaseModel):
    """Result of a flash program operation."""

    path: str
    erased: bool
    verified: bool
    success: bool
    message: str = ""


class TAPResult(BaseModel):
    """One TAP discovered on the JTAG chain."""

    name: str
    idcode: str
    ir_length: int
    enabled: bool


class JTAGChain(BaseModel):
    """JTAG scan chain enumeration result."""

    taps: list[TAPResult]
    count: int


class JTAGShiftResult(BaseModel):
    """Result of an irscan or drscan operation."""

    operation: str
    tap: str
    value_in: str
    value_out: str
    bits: int | None = None


class SVDFieldResult(BaseModel):
    """One decoded bitfield from an SVD register."""

    name: str
    value: int
    width: int
    offset: int
    description: str


class SVDRegisterResult(BaseModel):
    """A register decoded via SVD metadata."""

    name: str
    address: str
    raw_value: str
    fields: list[SVDFieldResult]


class SVDPeripheralResult(BaseModel):
    """All registers for a peripheral, decoded via SVD."""

    peripheral: str
    registers: dict[str, SVDRegisterResult]


class SVDListResult(BaseModel):
    """List of peripherals or registers from loaded SVD."""

    peripherals: list[str] | None = None
    registers: list[str] | None = None
    svd_loaded: bool


class RawCommandResult(BaseModel):
    """Result from a raw OpenOCD TCL command."""

    command: str
    response: str


class DiagnosticCheck(BaseModel):
    """One diagnostic check result."""

    name: str
    ok: bool
    detail: str


class DiagnosticsResult(BaseModel):
    """Probe and target diagnostic summary."""

    connected: bool
    checks: list[DiagnosticCheck]
    summary: str


class TransportInfo(BaseModel):
    """Active transport and adapter details."""

    transport: str
    adapter: str
    speed_khz: int | None = None
    available_transports: list[str]


# ---------------------------------------------------------------------------
# SWD / DAP
# ---------------------------------------------------------------------------


class APInfoResult(BaseModel):
    """One Access Port discovered on the DAP."""

    index: int
    idr: str
    base: str
    ap_type: str


class DAPInfoResult(BaseModel):
    """Debug Access Port identification and AP summary."""

    name: str
    dpidr: str
    ap_count: int
    raw_info: str


class APListResult(BaseModel):
    """All Access Ports enumerated on the DAP."""

    aps: list[APInfoResult]
    count: int


class DPRegResult(BaseModel):
    """DP register read/write result."""

    address: str
    value: str
    written: bool


class APRegResult(BaseModel):
    """AP register read/write result."""

    ap: int
    address: str
    value: str
    written: bool


# ---------------------------------------------------------------------------
# Breakpoints / Watchpoints
# ---------------------------------------------------------------------------


class BreakpointInfo(BaseModel):
    """One active breakpoint."""

    number: int
    type: str
    address: str
    length: int
    enabled: bool


class BreakpointListResult(BaseModel):
    """All active breakpoints."""

    breakpoints: list[BreakpointInfo]
    count: int


class BreakpointActionResult(BaseModel):
    """Result of adding or removing a breakpoint."""

    address: str
    action: str
    success: bool


class WatchpointInfo(BaseModel):
    """One active watchpoint."""

    number: int
    address: str
    length: int
    access: str


class WatchpointListResult(BaseModel):
    """All active watchpoints."""

    watchpoints: list[WatchpointInfo]
    count: int


class WatchpointActionResult(BaseModel):
    """Result of adding or removing a watchpoint."""

    address: str
    action: str
    success: bool


# ---------------------------------------------------------------------------
# RTT (Real-Time Transfer)
# ---------------------------------------------------------------------------


class RTTSetupResult(BaseModel):
    """RTT configuration result."""

    address: str
    size: str
    id_string: str
    success: bool


class RTTStatusResult(BaseModel):
    """RTT start/stop result."""

    action: str
    success: bool


class RTTChannelInfo(BaseModel):
    """One RTT channel descriptor."""

    index: int
    name: str
    size: int
    direction: str


class RTTChannelListResult(BaseModel):
    """All RTT channels."""

    channels: list[RTTChannelInfo]
    count: int


class RTTReadResult(BaseModel):
    """Data read from an RTT up-channel."""

    channel: int
    data: str


class RTTWriteResult(BaseModel):
    """Result of writing to an RTT down-channel."""

    channel: int
    length: int
    success: bool


# ---------------------------------------------------------------------------
# Transport / Adapter
# ---------------------------------------------------------------------------


class AdapterSpeedResult(BaseModel):
    """Adapter clock speed get/set result."""

    speed_khz: int
    changed: bool
