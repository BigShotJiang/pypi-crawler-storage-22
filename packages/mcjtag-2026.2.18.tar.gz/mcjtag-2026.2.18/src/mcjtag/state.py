"""Session state shared across the MCP server lifespan."""

from __future__ import annotations

import asyncio
from dataclasses import dataclass, field

from openocd.session import Session


@dataclass
class SessionState:
    """Holds the active OpenOCD session and configuration.

    Created in the lifespan context manager and passed to all
    mixin tools via ``ctx.request_context.lifespan_context``.

    The ``lock`` serializes state-mutating operations (connect,
    disconnect) to prevent TOCTOU races when FastMCP invokes
    multiple tools concurrently.
    """

    session: Session | None = None
    svd_path: str | None = None
    managed_process: bool = False
    lock: asyncio.Lock = field(default_factory=asyncio.Lock)
