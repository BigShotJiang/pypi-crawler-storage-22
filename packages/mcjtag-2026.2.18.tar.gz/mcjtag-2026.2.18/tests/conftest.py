"""Test fixtures for mcjtag."""

import pytest


@pytest.fixture
def sample_idcode():
    """A known STM32F1 IDCODE for testing."""
    return 0x3BA00477


@pytest.fixture
def sample_register_values():
    """Sample CPU register name→value mapping."""
    return {
        "r0": 0x00000000,
        "r1": 0x20001234,
        "r2": 0x08004567,
        "sp": 0x20005000,
        "lr": 0x08001001,
        "pc": 0x08001234,
        "xPSR": 0x61000000,
    }
