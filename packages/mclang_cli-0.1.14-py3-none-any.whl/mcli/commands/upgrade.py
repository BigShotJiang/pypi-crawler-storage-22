# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# openUBMC is licensed under Mulan PSL v2.
# You can obtain a copy of Mulan PSL v2 at:
#         http://license.coscl.org.cn/MulanPSL2
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND,
# EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT,
# MERCHANTABILITY OR FIT FOR A PARTICULAR PURPOSE.
# See the Mulan PSL v2 for more details.

"""
mcli upgrade 命令

升级 mclang-cli 和 mclang-compiler 到最新版本。

功能:
- 检查 PyPI 上的最新版本
- 显示当前版本和最新版本
- 使用 pip 升级到最新版本
"""

import argparse
import subprocess
import sys
from typing import Optional, Tuple
from packaging import version as pkg_version


def run_upgrade(args) -> bool:
    """upgrade 命令主入口"""
    # 包名映射：简写 -> 实际包名
    package_alias = {
        "mcli": "mclang-cli",
        "mcc": "mclang-compiler",
    }

    # 获取用户指定的包
    requested_packages = getattr(args, "packages", None)
    upgrade_all = getattr(args, "all", False)

    # 确定要升级的包
    if upgrade_all:
        # --all: 升级所有包
        packages = ["mclang-cli", "mclang-compiler"]
    elif requested_packages:
        # 用户指定了包：验证并转换
        valid_aliases = set(package_alias.keys()) | set(package_alias.values())
        for pkg in requested_packages:
            if pkg not in valid_aliases:
                print(f"错误: 未知的包名 '{pkg}'")
                print("")
                print("支持的包名（简写/全名）:")
                print("  mcli, mclang-cli      - MCLang CLI 工具")
                print("  mcc,  mclang-compiler - MCLang 编译器")
                print("")
                print("用法:")
                print("  mcli upgrade          # 只升级 CLI 工具")
                print("  mcli upgrade --all    # 升级所有包")
                print("  mcli upgrade mcli     # 只升级 CLI 工具")
                print("  mcli upgrade mcc      # 只升级编译器")
                return False
        # 转换简写为全名
        packages = [package_alias.get(pkg, pkg) for pkg in requested_packages]
    else:
        # 默认：只升级 mcli 自己
        packages = ["mclang-cli"]

    force = getattr(args, "force", False)
    dry_run = getattr(args, "dry_run", False)
    break_system = getattr(args, "break_system_packages", False)

    print("检查可用更新...")
    print("")

    # 获取当前版本和最新版本
    updates = []
    for pkg in packages:
        current, latest = _get_version_info(pkg)
        if current and latest:
            # 比较版本：只有当 PyPI 版本更新时才显示可升级
            has_update = _is_update_available(current, latest)
            updates.append({
                "name": pkg,
                "current": current,
                "latest": latest,
                "has_update": has_update,
            })
            if has_update:
                print(f"  {pkg}: {current} -> {latest}")
            else:
                print(f"  {pkg}: {current} (已是最新)")
        else:
            print(f"  {pkg}: 无法获取版本信息")
            return False

    print("")

    # 检查是否有可用更新
    available_updates = [u for u in updates if u["has_update"]]

    if not available_updates:
        print("所有包已是最新版本")
        return True

    # 预览模式
    if dry_run:
        print("预览模式: 将升级以下包:")
        for u in available_updates:
            print(f"  {u['name']}: {u['current']} -> {u['latest']}")
        return True

    # 确认操作
    if not force:
        print("将升级以下包:")
        for u in available_updates:
            print(f"  {u['name']}: {u['current']} -> {u['latest']}")
        print("")
        response = input("继续? (yes/no): ")
        if response.lower() not in ("yes", "y"):
            print("操作已取消")
            return True

    # 执行升级
    print("")
    print("开始升级...")
    return _upgrade_packages([u["name"] for u in available_updates], break_system)


def _is_update_available(current: str, latest: str) -> bool:
    """检查是否有可用更新

    Args:
        current: 当前版本
        latest: PyPI 最新版本

    Returns:
        如果 PyPI 版本更新则返回 True
    """
    try:
        return pkg_version.parse(latest) > pkg_version.parse(current)
    except Exception:
        # 如果版本解析失败，使用字符串比较
        return latest != current


def _get_version_info(package_name: str) -> Tuple[Optional[str], Optional[str]]:
    """获取包的当前版本和最新版本

    Args:
        package_name: 包名称

    Returns:
        (当前版本, 最新版本) 元组，如果获取失败则返回 (None, None)
    """
    current = _get_installed_version(package_name)
    latest = _get_latest_version_from_pypi(package_name)
    return current, latest


def _get_installed_version(package_name: str) -> Optional[str]:
    """获取已安装的包版本

    Args:
        package_name: 包名称

    Returns:
        已安装的版本号，如果未安装则返回 None
    """
    try:
        result = subprocess.run(
            [sys.executable, "-m", "pip", "show", package_name],
            capture_output=True,
            text=True,
            check=False
        )
        if result.returncode == 0:
            for line in result.stdout.splitlines():
                if line.startswith("Version:"):
                    return line.split(":", 1)[1].strip()
        return None
    except Exception:
        return None


def _get_latest_version_from_pypi(package_name: str) -> Optional[str]:
    """从 PyPI 获取包的最新版本

    Args:
        package_name: 包名称

    Returns:
        最新版本号，如果获取失败则返回 None
    """
    import json

    try:
        # 使用 pip index API 获取最新版本
        result = subprocess.run(
            [sys.executable, "-m", "pip", "index", "versions", package_name],
            capture_output=True,
            text=True,
            check=False,
            timeout=30
        )
        if result.returncode == 0:
            # 解析 pip index versions 输出
            # 输出格式: mclang-cli (0.1.10)
            # Available versions: 0.1.10, 0.1.9, ...
            for line in result.stdout.splitlines():
                if line.startswith(f"{package_name} ("):
                    # 提取版本号: mclang-cli (0.1.10) -> 0.1.10
                    version = line.split("(")[1].split(")")[0].strip()
                    return version
    except (subprocess.TimeoutExpired, Exception):
        pass

    # 如果 pip index 失败，尝试使用 PyPI JSON API
    try:
        import urllib.request
        import urllib.error

        url = f"https://pypi.org/pypi/{package_name}/json"
        with urllib.request.urlopen(url, timeout=10) as response:
            data = json.loads(response.read().decode())
            return data["info"]["version"]
    except Exception:
        pass

    return None


def _upgrade_packages(packages: list, break_system: bool = False) -> bool:
    """升级指定的包

    Args:
        packages: 要升级的包列表
        break_system: 是否使用 --break-system-packages 标志

    Returns:
        是否成功升级
    """
    # 构建命令
    cmd = [sys.executable, "-m", "pip", "install", "--upgrade"]
    if break_system:
        cmd.append("--break-system-packages")
    cmd.extend(packages)

    result = _try_install(cmd)
    if result is None:
        return False

    if result.returncode == 0:
        return True

    # 检查是否需要 --break-system-packages 标志
    if _needs_break_system_packages(result):
        print("")
        print("检测到受保护的 Python 环境 (PEP 668)")
        print("")
        print("此环境受到保护，无法直接安装包。请选择以下方式之一：")
        print("")
        print("  1. 使用虚拟环境（推荐）:")
        print("       python3 -m venv venv")
        print("       source venv/bin/activate")
        print("       mcli upgrade")
        print("")
        print("  2. 使用 --break-system-packages 标志（可能影响系统稳定性）:")
        print("       mcli upgrade --break-system-packages")
        print("")
        print("  3. 使用用户级安装:")
        print("       pip install --upgrade --user mclang-cli mclang-compiler")
        print("")
        return False

    # 其他错误
    print("")
    print(f"升级失败，返回码: {result.returncode}")
    if result.stderr:
        # 只显示关键错误信息，过滤掉冗长的帮助文本
        error_lines = result.stderr.strip().split('\n')
        critical_errors = [line for line in error_lines
                          if line and not line.startswith(' ') and not line.startswith('×')
                          and 'error:' in line.lower() or 'ERROR' in line]
        if critical_errors:
            print(f"错误: {' '.join(critical_errors[:3])}")  # 只显示前3行
        else:
            # 显示第一行错误
            first_error = next((line for line in error_lines if line.strip()), "")
            if first_error:
                print(f"错误: {first_error[:200]}")  # 限制长度

    return False


def _try_install(cmd: list, show_output: bool = True) -> Optional[subprocess.CompletedProcess]:
    """尝试执行安装命令

    Args:
        cmd: 完整的安装命令
        show_output: 是否显示输出信息

    Returns:
        如果成功返回结果对象，失败返回 result（用于检查错误）
    """
    try:
        # 构建显示用的命令（只显示包名）
        packages = [c for c in cmd if not c.startswith("-") and c not in ["install", "upgrade", sys.executable, "python", "python3", "pip", "-m"]]
        display_cmd = f"pip install --upgrade {' '.join(packages)}"

        if show_output:
            print(f"执行: {display_cmd}")
            print("")

        result = subprocess.run(cmd, check=False, text=True, capture_output=True)

        if result.returncode == 0:
            if show_output:
                if result.stdout:
                    print(result.stdout)
                print("")
                print("升级成功!")
                print("")
                print("新版本:")
                for pkg in packages:
                    version = _get_installed_version(pkg)
                    if version:
                        print(f"  {pkg}: {version}")
                print("")
                print("请重新加载终端或重启 shell 以使更改生效")
            return result
        else:
            # 失败时也返回 result，让调用者检查是否需要重试
            return result

    except FileNotFoundError:
        if show_output:
            print("错误: 未找到 pip 命令")
        return None
    except Exception as e:
        if show_output:
            print(f"错误: 升级失败 - {e}")
        return None


def _needs_break_system_packages(result: Optional[subprocess.CompletedProcess]) -> bool:
    """检查是否需要 --break-system-packages 标志

    Args:
        result: pip 命令的执行结果

    Returns:
        如果需要该标志则返回 True
    """
    if result is None:
        return False

    error_output = result.stderr or result.stdout or ""
    return "externally-managed-environment" in error_output or "break-system-packages" in error_output


def setup_parser(subparsers) -> argparse.ArgumentParser:
    """设置 upgrade 子命令解析器"""
    parser = subparsers.add_parser(
        "upgrade",
        help="升级 mclang 到最新版本",
    )

    parser.add_argument(
        "packages",
        nargs="*",
        help="指定要升级的包（mcli 或 mcc），支持简写",
    )

    parser.add_argument(
        "-a",
        "--all",
        action="store_true",
        help="升级所有包（mcli + mcc）",
    )

    parser.add_argument(
        "-f",
        "--force",
        action="store_true",
        help="跳过确认提示",
    )

    parser.add_argument(
        "-n",
        "--dry-run",
        action="store_true",
        help="预览模式，显示可用的更新但不实际升级",
    )

    parser.add_argument(
        "--break-system-packages",
        action="store_true",
        dest="break_system_packages",
        help="使用 --break-system-packages 标志（用于 PEP 668 受保护的 Python 环境）",
    )

    return parser
