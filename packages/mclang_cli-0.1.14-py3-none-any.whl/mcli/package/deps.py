#!/usr/bin/env python3
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# openUBMC is licensed under Mulan PSL v2.
# You can use this software according to the terms and conditions of the Mulan PSL v2.
# You may obtain a copy of Mulan PSL v2 at:
#         http://license.coscl.org.cn/MulanPSL2
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND,
# EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT,
# MERCHANTABILITY OR FIT FOR A PARTICULAR PURPOSE.
# See the Mulan PSL v2 for more details.


"""
mcli 依赖管理工具模块
功能：
1. 解析和修改 service.json 依赖配置
2. 安装 Conan 包
3. 同步 .mclang/ 目录（创建 stub 软链接）
"""


import json
import os
import shutil
import subprocess
import sys
from datetime import datetime
from pathlib import Path
from typing import List, Optional

from mcli.config import get_project_config, has_project_config
from mcli.logging import get_logger


SERVICE_JSON_PATH = "mds/service.json"


def _get_packages_json_path(build_dir: Path) -> Path:
    """获取包元信息文件路径

    Args:
        build_dir: 构建目录路径

    Returns:
        packages.json 文件路径（位于构建目录内）
    """
    return build_dir / "packages.json"


def _read_packages_metadata(build_dir: Path) -> dict:
    """读取包元信息

    Args:
        build_dir: 构建目录路径

    Returns:
        包元信息字典，格式: {ref: {path, installed_at}}
    """
    packages_json_path = _get_packages_json_path(build_dir)
    if not packages_json_path.exists():
        return {}

    try:
        with open(packages_json_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except (json.JSONDecodeError, IOError):
        return {}


def _write_packages_metadata(build_dir: Path, metadata: dict) -> None:
    """写入包元信息

    Args:
        build_dir: 构建目录路径
        metadata: 包元信息
    """
    packages_json_path = _get_packages_json_path(build_dir)
    packages_json_path.parent.mkdir(parents=True, exist_ok=True)

    with open(packages_json_path, 'w', encoding='utf-8') as f:
        json.dump(metadata, f, indent=2, ensure_ascii=False)


def _check_and_clean_builddir_if_needed(build_dir: Path, current_packages: dict, project_dir: Path, logger) -> bool:
    """检查包路径是否变化，如果需要则清理构建目录和 stub

    Args:
        build_dir: 构建目录路径
        current_packages: 当前包信息 {ref: ConanPackageRef}
        project_dir: 项目目录（用于清理 .mclang/packages/）
        logger: 日志记录器

    Returns:
        是否清理了构建目录
    """
    from .conan import get_package_path, get_package_stubs_config, get_package_stubs_dir

    # 读取之前存储的包元信息
    old_metadata = _read_packages_metadata(build_dir)
    old_packages = old_metadata.get('packages', {})

    if not old_packages:
        # 首次运行，记录包信息即可
        return False

    # 检查包路径是否变化
    has_changes = False
    changed_packages = []  # 记录路径变化的包 (ref, old_path, new_path)

    for ref, pkg_ref in current_packages.items():
        current_path_obj = get_package_path(pkg_ref)
        if not current_path_obj:
            continue
        current_path = str(current_path_obj)

        # 检查旧的包路径是否存在
        if ref in old_packages:
            old_path = old_packages[ref].get('path')
            # 如果路径不同，说明包被重新安装了
            if old_path != current_path:
                has_changes = True
                changed_packages.append((ref, old_path, current_path))
        else:
            # 新增的包
            has_changes = True
            break

    # 检查是否有旧的包被移除
    if not has_changes:
        for ref in old_packages:
            if ref not in current_packages:
                has_changes = True
                break

    if has_changes:
        # 清理路径变化的包对应的 stub（针对 Windows 复制模式）
        packages_dir = project_dir / ".mclang" / "packages"
        if packages_dir.exists():
            stubs_to_remove = set()
            # 收集需要清理的 stub
            for ref, old_path, _ in changed_packages:
                old_pkg_path = Path(old_path)
                # 检查该包是否有 stub 配置
                stubs_config = get_package_stubs_config(old_pkg_path)
                if stubs_config:
                    stub_pkgs = stubs_config.get("packages", [])
                    stubs_to_remove.update(stub_pkgs)

            # 移除这些 stub 目录
            for stub_name in stubs_to_remove:
                stub_path = packages_dir / stub_name
                if stub_path.exists():
                    try:
                        if stub_path.is_symlink() or stub_path.is_dir():
                            shutil.rmtree(stub_path)
                            logger.info(f"  ✓ 已清理过期 stub: {stub_name}")
                    except OSError as e:
                        logger.warning(f"  清理 stub 失败: {stub_name}: {e}")

        # 清理构建目录
        if build_dir.exists():
            logger.info(f"检测到包缓存变化，清理构建目录: {build_dir.relative_to(build_dir.parent.parent)}/")
            try:
                shutil.rmtree(build_dir)
                logger.info(f"✓ 已清理构建目录")
                return True
            except OSError as e:
                logger.warning(f"清理构建目录失败: {e}")

    return False


def _update_packages_metadata(build_dir: Path, packages: dict, logger) -> None:
    """更新包元信息

    Args:
        build_dir: 构建目录路径
        packages: 包信息 {ref: ConanPackageRef}
        logger: 日志记录器
    """
    from .conan import get_package_path

    metadata = {
        'packages': {},
        'last_updated': datetime.now().isoformat()
    }

    for ref, pkg_ref in packages.items():
        # 使用 get_package_path 获取包路径
        pkg_path = get_package_path(pkg_ref)
        if pkg_path:
            path = str(pkg_path)
            metadata['packages'][ref] = {
                'path': path,
            }

    _write_packages_metadata(build_dir, metadata)


def parse_conan_ref(ref: str) -> tuple[str, str, str, str]:
    """解析 Conan 引用，返回 (name, version, user, channel)"""
    if "@" in ref:
        package_part, user_channel = ref.split("@", 1)
        if "/" in user_channel:
            user, channel = user_channel.split("/", 1)
        else:
            user, channel = user_channel, "unknown"
    else:
        package_part = ref
        user, channel = "", ""

    if "/" in package_part:
        name, version = package_part.split("/", 1)
    else:
        name, version = package_part, "0.0.0"

    return name, version, user, channel


def get_dependencies(project_dir: Path, dep_type: str = "test") -> List[str]:
    """获取项目依赖列表
    """
    config = get_project_config(project_dir)
    return config.get_conan_dependencies(dep_type)


def add_dependency(
    project_dir: Path,
    conan_ref: str,
    dep_type: str = "test",
    logger=None,
    **options
) -> bool:
    """添加依赖到 service.json

    Args:
        project_dir: 项目目录
        conan_ref: Conan 包引用（如 "mclboost/[>=1.0.0]"）
        dep_type: 依赖类型 ("test" 或 "build")
        logger: 日志记录器
        **options: 额外的 Conan 依赖选项（如 transitive_headers=True）

    Returns:
        是否成功
    """
    if logger is None:
        logger = get_logger("deps", project_dir, "debug")

    service_path = project_dir / SERVICE_JSON_PATH
    if not service_path.exists():
        logger.error(f"未找到 {SERVICE_JSON_PATH}")
        return False

    with open(service_path, "r", encoding="utf-8") as f:
        config = json.load(f)

    if "dependencies" not in config:
        config["dependencies"] = {}
    if dep_type not in config["dependencies"]:
        config["dependencies"][dep_type] = []

    deps = config["dependencies"][dep_type]

    for dep in deps:
        if dep.get("conan") == conan_ref:
            logger.info(f"  依赖已存在: {conan_ref}")
            return True

    dep_entry = {"conan": conan_ref}
    for key, value in options.items():
        dep_entry[key] = value
    deps.append(dep_entry)

    with open(service_path, "w", encoding="utf-8") as f:
        json.dump(config, f, indent=4, ensure_ascii=False)

    return True


def remove_dependency(
    project_dir: Path,
    package_name: str,
    dep_type: str = "test"
) -> bool:
    """从 service.json 移除依赖

    Args:
        project_dir: 项目目录
        package_name: 包名（如 "mcl_runtime"）
        dep_type: 依赖类型 ("test" 或 "build")

    Returns:
        是否成功
    """
    service_path = project_dir / SERVICE_JSON_PATH
    if not service_path.exists():
        return False

    with open(service_path, "r", encoding="utf-8") as f:
        config = json.load(f)

    if "dependencies" not in config or dep_type not in config["dependencies"]:
        return False

    deps = config["dependencies"][dep_type]
    original_length = len(deps)

    # 移除匹配的依赖（按包名匹配）
    config["dependencies"][dep_type] = [
        dep for dep in deps
        if package_name not in dep.get("conan", "")
    ]

    if len(config["dependencies"][dep_type]) == original_length:
        return False  # 没有找到要删除的依赖

    with open(service_path, "w", encoding="utf-8") as f:
        json.dump(config, f, indent=4, ensure_ascii=False)

    return True


def install_conan_package(
    project_dir: Path,
    conan_ref: str,
    profile: Optional[Path] = None,
    logger=None
) -> bool:
    """安装 Conan 包（Conan 自动处理已安装包的检测）"""
    if logger is None:
        logger = get_logger("deps", project_dir, "debug")

    logger.info(f"  安装 {conan_ref}...")

    cmd = ["conan", "install", "--requires", conan_ref]
    if profile:
        cmd.extend(["-pr:h", str(profile)])

    result = subprocess.run(cmd, cwd=project_dir, capture_output=True)
    if result.returncode != 0:
        logger.warning(f"  conan install 失败: {result.stderr.decode()}")
        return False

    logger.info(f"  ✓ {conan_ref} 已安装")
    return True


def install_conan_packages_for_project(
    project_dir: Path,
    dep_type: str = "test",
    profile: Optional[Path] = None,
    verbose: bool = False,
) -> bool:
    """为项目安装所有 Conan 依赖

    Args:
        project_dir: 项目目录
        dep_type: 依赖类型 ("test" 或 "build")
        profile: Conan profile 路径
        verbose: 是否显示详细输出

    Returns:
        是否全部成功
    """
    deps = get_dependencies(project_dir, dep_type)
    if not deps:
        return True  # 没有依赖

    all_success = True
    for conan_ref in deps:
        success = install_conan_package(project_dir, conan_ref, profile)
        if not success:
            all_success = False

    return all_success


def _collect_all_packages_info(
    project_dir: Path,
    profile_path: Optional[Path],
    dep_type: str,
    build_type: str,
    logger,
) -> dict:
    """收集所有 Conan 包的信息（用于检测缓存变化）

    Args:
        project_dir: 项目目录
        profile_path: Conan profile 路径
        dep_type: 依赖类型
        build_type: 构建类型
        logger: 日志记录器

    Returns:
        {ref: ConanPackageRef} 字典，ref 格式为 name/version
    """
    from mcli.package.conan import get_project_packages

    is_test_mode = (dep_type == "test")
    pkg_refs = get_project_packages(project_dir, profile_path=profile_path, test=is_test_mode, build_type=build_type)

    # 将列表转换为字典，以 name/version 为 key（不包含 package_id，因为它可能变化）
    packages_info = {}
    for pkg_ref in pkg_refs:
        ref_str = f"{pkg_ref.name}/{pkg_ref.version}"
        packages_info[ref_str] = pkg_ref

    return packages_info


def _collect_needed_stub_links(
    project_dir: Path,
    profile_path: Optional[Path],
    dep_type: str,
    build_type: str,
    verbose: bool,
    logger,
) -> dict:
    from mcli.package.conan import (
        get_project_packages,
        get_package_path,
        get_package_stubs_config,
        get_package_stubs_dir,
    )

    needed_stub_links = {}
    is_test_mode = (dep_type == "test")
    pkg_refs = get_project_packages(project_dir, profile_path=profile_path, test=is_test_mode, build_type=build_type)

    for pkg_ref in pkg_refs:
        source_path = get_package_path(pkg_ref)
        if not source_path:
            if verbose:
                logger.warning(f"  找不到 package '{pkg_ref.name}'")
            continue

        stubs_config = get_package_stubs_config(source_path)
        stubs_base_dir = get_package_stubs_dir(source_path)

        if stubs_base_dir and stubs_config:
            stub_pkgs = stubs_config.get("packages", [])
            for stub_pkg in stub_pkgs:
                stub_source = stubs_base_dir / stub_pkg
                if stub_source.exists():
                    link_name = stub_pkg
                    needed_stub_links[link_name] = stub_source

    return needed_stub_links


def _cleanup_broken_symlinks(packages_dir: Path, verbose: bool, logger) -> set:
    existing_links = set()
    if not packages_dir.exists():
        return existing_links

    for item in packages_dir.iterdir():
        if item.is_symlink():
            try:
                target = item.readlink()
                # 解析相对路径
                if not target.is_absolute():
                    target = (item.parent / target).resolve()
                else:
                    target = target.resolve()

                # 检查目标是否存在
                if not target.exists():
                    if verbose:
                        logger.debug(f"  移除失效的软链接 {item.name} -> {item.readlink()}")
                    item.unlink()
                    continue
            except OSError:
                if verbose:
                    logger.debug(f"  移除损坏的软链接 {item.name}")
                item.unlink()
                continue

        existing_links.add(item.name)

    return existing_links


def _remove_obsolete_links(
    packages_dir: Path,
    existing_links: set,
    needed_links: dict,
    verbose: bool,
    logger,
) -> None:
    for link_name in existing_links - set(needed_links.keys()):
        link_path = packages_dir / link_name
        if link_path.is_symlink() or link_path.exists():
            if link_path.is_symlink():
                link_path.unlink()
            elif link_path.is_dir():
                shutil.rmtree(link_path)
            else:
                link_path.unlink()
            if verbose:
                logger.debug(f"  移除 {link_name}")


def _create_stub_links(
    packages_dir: Path,
    needed_links: dict,
    verbose: bool,
    logger,
) -> int:
    synced = 0

    # Windows: 检查是否支持符号链接（需要开发者模式或权限）
    # 默认假设不支持，使用复制模式
    support_symlink = sys.platform != 'win32'

    # 环境变量 MCLI_STUB_COPY=1 时强制使用复制模式
    force_copy = os.environ.get('MCLI_STUB_COPY', '0') == '1'
    use_copy = force_copy or not support_symlink

    for link_name, source_path in needed_links.items():
        link_path = packages_dir / link_name

        # 检查是否需要更新
        need_update = False
        if link_path.is_symlink():
            current_target = link_path.resolve()
            if current_target != source_path.resolve():
                need_update = True
                link_path.unlink()
        elif link_path.exists():
            shutil.rmtree(link_path)
            need_update = True
        else:
            need_update = True

        if need_update:
            if use_copy:
                # 使用复制模式（Windows 或强制模式）
                shutil.copytree(source_path, link_path)
                if verbose:
                    logger.debug(f"  复制 {link_name} ← {source_path}")
            else:
                # 使用符号链接模式（Unix/macOS）
                try:
                    link_path.symlink_to(source_path)
                    if verbose:
                        logger.debug(f"  链接 {link_name} → {source_path}")
                except OSError as e:
                    # 符号链接失败，回退到复制模式
                    logger.warning(f"  软链接失败，使用复制: {e}")
                    shutil.copytree(source_path, link_path)
                    if verbose:
                        logger.debug(f"  复制 {link_name} ← {source_path}")
            synced += 1

    return synced


def sync_mclang_dir(project_dir: Path, profile_path: Optional[Path] = None, dep_type: str = "test", verbose: bool = False, logger=None, build_type: str = "debug", build_dir: Optional[Path] = None) -> bool:
    """同步项目 stub 包到 .mclang/packages/ 目录

    创建顶级包链接（如 mc、gtest），支持直接 `from mc import main` 导入，
    而无需 `from mcl_runtime.mc import main`。

    同时检测包缓存变化，自动清理构建目录。

    Args:
        project_dir: 项目目录
        profile_path: Conan profile 路径
        dep_type: 依赖类型
        verbose: 是否显示详细输出
        logger: 日志记录器
        build_type: 构建类型
        build_dir: 构建目录路径（用于存储 packages.json）
    """
    if logger is None:
        logger = get_logger("deps", project_dir, "debug")

    mclang_dir = project_dir / ".mclang"
    packages_dir = mclang_dir / "packages"

    mclang_dir.mkdir(exist_ok=True)
    packages_dir.mkdir(exist_ok=True)

    # 收集所有 Conan 包信息（用于检测缓存变化）
    all_packages_info = _collect_all_packages_info(
        project_dir, profile_path, dep_type, build_type, logger
    )

    # 检测包路径是否变化，如果需要则清理构建目录和 stub
    if build_dir:
        _check_and_clean_builddir_if_needed(build_dir, all_packages_info, project_dir, logger)

    # 收集所有需要的 stub 包链接
    needed_stub_links = _collect_needed_stub_links(
        project_dir, profile_path, dep_type, build_type, verbose, logger
    )

    # 清理失效的软链接，获取有效的现有链接
    existing_links_before = set(packages_dir.iterdir()) if packages_dir.exists() else set()
    existing_links = _cleanup_broken_symlinks(packages_dir, verbose, logger)

    # 移除不再需要的链接
    obsolete_links = existing_links - set(needed_stub_links.keys())
    _remove_obsolete_links(packages_dir, existing_links, needed_stub_links, verbose, logger)

    # 创建或更新 stub 包软链接
    synced = _create_stub_links(packages_dir, needed_stub_links, verbose, logger)

    # 更新包元信息（保存到构建目录）
    if build_dir:
        _update_packages_metadata(build_dir, all_packages_info, logger)

    return synced > 0 or len(existing_links - set(needed_stub_links.keys())) > 0
