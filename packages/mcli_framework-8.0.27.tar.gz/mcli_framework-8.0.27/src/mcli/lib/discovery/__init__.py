# Discovery module for MCLI commands
