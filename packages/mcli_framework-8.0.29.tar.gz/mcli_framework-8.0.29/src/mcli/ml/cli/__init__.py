"""CLI interface for ML system."""

from .main import app

__all__ = ["app"]
