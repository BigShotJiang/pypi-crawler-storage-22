"""Dashboard workflow module."""

from .dashboard_cmd import dashboard

__all__ = ["dashboard"]
