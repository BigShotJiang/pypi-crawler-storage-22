"""MCP server for LTspice circuit simulation automation."""

from importlib.metadata import version

try:
    __version__ = version("mcltspice")
except Exception:
    __version__ = "0.0.0"
