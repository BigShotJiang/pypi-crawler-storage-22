"""Configuration for mcltspice."""

import os
from pathlib import Path

# LTspice installation paths
LTSPICE_DIR = Path(
    os.environ.get("LTSPICE_DIR", Path.home() / "claude" / "ltspice" / "extracted" / "ltspice")
)

LTSPICE_EXE = LTSPICE_DIR / "LTspice.exe"
LTSPICE_LIB = LTSPICE_DIR / "lib"
LTSPICE_EXAMPLES = LTSPICE_DIR / "examples"

# Wine configuration
WINE_PREFIX = LTSPICE_DIR / ".wine"
WINE_DEBUG = os.environ.get("WINE_DEBUG", "-all")

# Simulation defaults
DEFAULT_TIMEOUT = 300  # 5 minutes
MAX_RAW_FILE_SIZE = 500 * 1024 * 1024  # 500MB


def get_wine_env() -> dict[str, str]:
    """Get environment variables for Wine execution."""
    env = os.environ.copy()
    env["WINEPREFIX"] = str(WINE_PREFIX)
    env["WINEARCH"] = "win64"
    env["WINEDEBUG"] = WINE_DEBUG
    return env


def validate_installation() -> tuple[bool, str]:
    """Check if LTspice is properly installed."""
    if not LTSPICE_DIR.exists():
        return False, f"LTspice directory not found: {LTSPICE_DIR}"
    if not LTSPICE_EXE.exists():
        return False, f"LTspice executable not found: {LTSPICE_EXE}"
    if not WINE_PREFIX.exists():
        return False, f"Wine prefix not found: {WINE_PREFIX}"
    return True, "LTspice installation OK"
