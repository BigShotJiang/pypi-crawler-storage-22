# Silicon Labs CP2102 USB to UART Bridge 

The CP2102 USB to UART Bridge provides a complete plug and play interface solution that includes royalty-free drivers. This USB 2.0 compliant device includes 0 digital I/O pins and is availble in a 5x5 mm QFN28 package.

## Links
[https://www.silabs.com/interface/usb-bridges/classic/device.cp2102](Product Page)

## Docs
[Datasheet](https://www.silabs.com/documents/public/data-sheets/CP2102-9.pdf)
[Eratta](https://www.silabs.com/documents/public/errata/CP2102Berrata.pdf)


## Application Notes
- [AN197: Serial Communication Guide](https://www.silabs.com/documents/public/application-notes/an197-serial-communications-guide-cp210x.pdf)
- [AN220: USB Driver Customization](https://www.silabs.com/documents/public/example-code/AN220SW.zip)
- [AN223: CP210x GPIO Example Software](https://www.silabs.com/documents/public/example-code/AN223SW.zip)
- [AN721: CP210x/CP211x Device Customization Guide](https://www.silabs.com/documents/public/example-code/AN721SW.zip)

## USBXpress
[Host SDK](https://www.silabs.com/documents/public/software/USBXpressHostSDK-Linux.tar)

