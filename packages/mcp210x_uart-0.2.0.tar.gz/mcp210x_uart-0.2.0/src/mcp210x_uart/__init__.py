"""mcp210x-uart - MCP server for Silicon Labs CP210x USB-UART bridge customization."""

from .server import main, mcp

__all__ = ["mcp", "main"]
