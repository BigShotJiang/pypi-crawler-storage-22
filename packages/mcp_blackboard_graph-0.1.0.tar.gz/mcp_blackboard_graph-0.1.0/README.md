# mcp-blackboard-graph
A common blackboard for a number of LLM agents to write on for coordination.
This takes the form of a directed graph. You can send messages to nodes.

This is a relative general structure but could be used for a tree of tasks.

This is pure AI-generated code - review before use.


## Installation
pipx install mcp-blackboard-graph

## Usage
mcp-blackboard-graph will be on your path. Wire it up to your mcp server.

## Alternatives
`task-tree-mcp` seems to concern itself with plans. This was too high leel for my interestes.

`mcp-blackboard` did not have messages which I really wanted.

