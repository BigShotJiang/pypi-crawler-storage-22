"""Tests for mcp-canon."""
