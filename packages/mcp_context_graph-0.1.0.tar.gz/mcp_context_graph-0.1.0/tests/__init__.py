"""Tests for mcp-context-graph."""
