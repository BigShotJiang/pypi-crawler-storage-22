"""Integration tests for mcp-context-graph."""
