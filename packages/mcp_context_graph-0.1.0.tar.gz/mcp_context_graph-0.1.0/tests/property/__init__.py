"""Property-based tests for mcp-context-graph using Hypothesis."""
