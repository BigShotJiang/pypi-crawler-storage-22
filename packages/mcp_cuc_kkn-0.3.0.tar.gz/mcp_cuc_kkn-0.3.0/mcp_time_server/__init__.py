"""
MCP Time Server - A simple MCP Server that provides time query functionality
"""

__version__ = "0.3.0"
__author__ = "Your Name"
__email__ = "your.email@example.com"
