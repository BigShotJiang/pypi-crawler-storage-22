"""MCP server for eRegistrations BPA platform."""

from fastmcp import FastMCP
from mcp.server.fastmcp.exceptions import ToolError

from mcp_eregistrations_bpa.auth import TokenManager
from mcp_eregistrations_bpa.auth.credentials import (
    delete_credentials,
    get_credentials,
    store_credentials,
)
from mcp_eregistrations_bpa.auth.oidc import is_browser_available
from mcp_eregistrations_bpa.auth.permissions import browser_login, password_login
from mcp_eregistrations_bpa.config import load_config
from mcp_eregistrations_bpa.tools import (
    register_action_tools,
    register_analysis_tools,
    register_audit_tools,
    register_behaviour_tools,
    register_bot_mapping_tools,
    register_bot_tools,
    register_classification_tools,
    register_cost_tools,
    register_debug_tools,
    register_determinant_tools,
    register_document_requirement_tools,
    register_export_tools,
    register_external_service_tools,
    register_field_tools,
    register_form_tools,
    register_message_tools,
    register_notification_tools,
    register_registration_institution_tools,
    register_registration_tools,
    register_role_status_tools,
    register_role_tools,
    register_role_unit_tools,
    register_rollback_tools,
    register_service_tools,
    register_workflow_tools,
)

mcp = FastMCP("eregistrations-bpa")

# Register BPA tools
register_service_tools(mcp)
register_registration_tools(mcp)
register_registration_institution_tools(mcp)
register_field_tools(mcp)
register_form_tools(mcp)
register_determinant_tools(mcp)
register_action_tools(mcp)
register_behaviour_tools(mcp)
register_bot_tools(mcp)
register_bot_mapping_tools(mcp)
register_external_service_tools(mcp)
register_classification_tools(mcp)
register_notification_tools(mcp)
register_message_tools(mcp)
register_role_tools(mcp)
register_role_status_tools(mcp)
register_role_unit_tools(mcp)
register_document_requirement_tools(mcp)
register_cost_tools(mcp)
register_analysis_tools(mcp)
register_audit_tools(mcp)
register_rollback_tools(mcp)
register_export_tools(mcp)
register_workflow_tools(mcp)
register_debug_tools(mcp)

# Global token manager instance (in-memory storage)
_token_manager = TokenManager()


@mcp.tool()
async def auth_login(
    username: str | None = None,
    password: str | None = None,
    persist_credentials: bool = False,
) -> dict[str, object]:
    """Authenticate with BPA. Supports browser and password grant.

    When called without credentials in a non-interactive environment,
    returns an ask_credentials response for the AI agent to handle.

    Args:
        username: BPA username (optional; enables password grant).
        password: BPA password (optional; required if username given).
        persist_credentials: Save credentials to system keyring (default: False).

    Returns:
        dict with success/ask_credentials status, user info, session duration.
    """
    from mcp_eregistrations_bpa.exceptions import AuthenticationError

    # Validation
    if username and not password:
        raise ToolError("Password is required when username is provided.")
    if password and not username:
        raise ToolError("Username is required when password is provided.")

    config = load_config()

    # Branch A: Credentials provided
    if username and password:
        result = await password_login(username, password)
        if result.get("success") and persist_credentials:
            stored = store_credentials(config.instance_id, username, password)
            if not stored:
                result["credential_storage_warning"] = (
                    "Keyring unavailable; credentials not saved."
                )
        return result

    # Branch B: No credentials, try automatic methods

    # Try keyring
    creds = get_credentials(config.instance_id)
    if creds:
        try:
            result = await password_login(creds[0], creds[1])
            if result.get("success"):
                return result
        except AuthenticationError:
            pass
        # Stale creds - clean up
        delete_credentials(config.instance_id)

    # Try browser
    if is_browser_available():
        try:
            result = await browser_login()
            if result.get("success"):
                return result
        except AuthenticationError:
            pass

    # All methods exhausted - return ask_credentials
    return {
        "action_required": "ask_credentials",
        "message": (
            "Cannot open browser for authentication. "
            "Please provide your BPA credentials."
        ),
        "fields": [
            {
                "name": "username",
                "type": "text",
                "label": "BPA Username (email)",
                "required": True,
            },
            {
                "name": "password",
                "type": "password",
                "label": "BPA Password",
                "required": True,
            },
            {
                "name": "persist_credentials",
                "type": "boolean",
                "label": "Remember credentials",
                "required": False,
            },
        ],
        "retry_tool": "auth_login",
        "instance_url": config.bpa_instance_url,
    }


async def get_connection_status() -> dict[str, object]:
    """Get current BPA connection status (internal implementation).

    Returns connection state, authenticated user, permissions, and session info.
    This is a read-only operation that does not trigger token refresh.

    Returns:
        dict: Connection status with instance URL, instance_id, user, permissions,
        and expiry.
    """
    config = load_config()

    # Check if not authenticated
    if not _token_manager.is_authenticated():
        return {
            "connected": False,
            "instance_id": config.instance_id,
            "instance_url": config.bpa_instance_url,
            "message": "Not authenticated. Run auth_login to connect.",
        }

    # Check if token has already expired
    if _token_manager.is_token_expired():
        return {
            "connected": False,
            "instance_id": config.instance_id,
            "instance_url": config.bpa_instance_url,
            "message": "Session expired. Run auth_login to reconnect.",
        }

    # Return full authenticated status
    return {
        "connected": True,
        "instance_id": config.instance_id,
        "instance_url": config.bpa_instance_url,
        "user": _token_manager.user_email,
        "permissions": _token_manager.permissions,
        "session_expires_in": f"{_token_manager.expires_in_minutes} minutes",
    }


@mcp.tool()
async def connection_status() -> dict[str, object]:
    """View current BPA connection status.

    Returns connection state, authenticated user, permissions, and session info.
    This is a read-only operation that does not trigger token refresh.

    Returns:
        dict: Connection status with instance URL, user, permissions, and expiry.
    """
    return await get_connection_status()


def get_token_manager() -> TokenManager:
    """Get the global token manager instance.

    This is used by other modules to access the authenticated session.

    Returns:
        The global TokenManager instance.
    """
    return _token_manager
