"""MCP tools for BPA bot input/output mapping operations.

This module provides tools for managing bot field mappings, cloning bots,
viewing revision history, reverting to previous revisions, and configuring
field visibility.

Write operations follow the audit-before-write pattern:
1. Validate parameters (pre-flight, no audit record if validation fails)
2. Create PENDING audit record
3. Execute BPA API call
4. Update audit record to SUCCESS or FAILED

API Endpoints used:
- POST /bot/{bot_id}/input_mapping - Create input mapping
- POST /bot/{bot_id}/output_mapping - Create output mapping
- PUT /input_mapping/{mapping_id} - Update input mapping
- PUT /output_mapping/{mapping_id} - Update output mapping
- DELETE /input_mapping/{mapping_id} - Delete input mapping
- DELETE /output_mapping/{mapping_id} - Delete output mapping
- PUT /bot/{bot_id}/input_mappings - Bulk replace input mappings
- PUT /bot/{bot_id}/output_mappings - Bulk replace output mappings
- POST /bot/{bot_id}/clone - Clone bot with all mappings
- GET /bot/{bot_id}/pagedhistory - Paginated revision history
- PUT /bot/{bot_id}/history/{revision_number} - Revert to revision
- PUT /bot/{bot_id}/input_visibility - Set input field visibility
- PUT /bot/{bot_id}/output_visibility - Set output field visibility
"""

from __future__ import annotations

from typing import Any, Literal

from mcp.server.fastmcp.exceptions import ToolError

from mcp_eregistrations_bpa.audit.context import (
    NotAuthenticatedError,
    get_current_user_email,
)
from mcp_eregistrations_bpa.audit.logger import AuditLogger
from mcp_eregistrations_bpa.bpa_client import BPAClient
from mcp_eregistrations_bpa.bpa_client.errors import (
    BPAClientError,
    BPANotFoundError,
    translate_error,
)
from mcp_eregistrations_bpa.tools.bots import _transform_bot_response
from mcp_eregistrations_bpa.tools.large_response import large_response_handler

__all__ = [
    # Read operations
    "bot_input_mapping_list",
    "bot_output_mapping_list",
    "bot_history_list",
    # Single-mapping CRUD (audited)
    "bot_input_mapping_create",
    "bot_input_mapping_update",
    "bot_input_mapping_delete",
    "bot_output_mapping_create",
    "bot_output_mapping_update",
    "bot_output_mapping_delete",
    # Bulk operations (audited, high-risk)
    "bot_input_mapping_save_all",
    "bot_output_mapping_save_all",
    # Bot-level operations (audited)
    "bot_clone",
    "bot_history_revert",
    # Visibility (audited)
    "bot_input_visibility_update",
    "bot_output_visibility_update",
    # Registration
    "register_bot_mapping_tools",
]


# =============================================================================
# Helpers
# =============================================================================


def _transform_mapping_response(data: dict[str, Any]) -> dict[str, Any]:
    """Transform mapping API response from camelCase to snake_case."""
    return {
        "id": data.get("id"),
        "source_field": data.get("sourceField"),
        "source_type": data.get("sourceType"),
        "source_field_is_multiple": data.get("sourceFieldIsMultiple", False),
        "target_field": data.get("targetField"),
        "target_type": data.get("targetType"),
        "target_field_is_multiple": data.get("targetFieldIsMultiple", False),
        "external_id": data.get("externalId"),
        "is_attribute": data.get("isAttribute", False),
        "is_cert": data.get("isCert", False),
        "format": data.get("format"),
        "input_param_type": data.get("inputParamType"),
        "json_determinant": data.get("jsonDeterminant"),
        "json_determinant_filter": data.get("jsonDeterminantFilter"),
        "target_field_properties": data.get("targetFieldProperties"),
    }


def _validate_mapping_create_params(
    bot_id: str | int,
    source_field: str,
    source_type: str,
    target_field: str,
) -> None:
    """Validate required params for mapping creation. Raises ToolError."""
    errors = []
    if not bot_id:
        errors.append("'bot_id' is required")
    if not source_field or not str(source_field).strip():
        errors.append("'source_field' is required")
    if not source_type or not str(source_type).strip():
        errors.append("'source_type' is required")
    if not target_field or not str(target_field).strip():
        errors.append("'target_field' is required")
    if errors:
        raise ToolError(
            f"Cannot create mapping: {'; '.join(errors)}. Check required fields."
        )


def _build_create_payload(
    source_field: str,
    source_type: str,
    target_field: str,
    target_type: str | None = None,
    source_field_is_multiple: bool = False,
    target_field_is_multiple: bool = False,
    is_attribute: bool = False,
    format: str | None = None,
    input_param_type: str | None = None,
    json_determinant: str | None = None,
) -> dict[str, Any]:
    """Build camelCase payload for mapping create."""
    payload: dict[str, Any] = {
        "sourceField": source_field.strip(),
        "sourceType": source_type.strip(),
        "targetField": target_field.strip(),
        "sourceFieldIsMultiple": source_field_is_multiple,
        "targetFieldIsMultiple": target_field_is_multiple,
        "isAttribute": is_attribute,
    }
    if target_type is not None:
        payload["targetType"] = target_type.strip()
    if format is not None:
        payload["format"] = format
    if input_param_type is not None:
        payload["inputParamType"] = input_param_type
    if json_determinant is not None:
        payload["jsonDeterminant"] = json_determinant
    return payload


def _build_update_payload(
    external_id: str | None = None,
    format: str | None = None,
    input_param_type: str | None = None,
    is_attribute: bool | None = None,
    is_cert: bool | None = None,
    json_determinant: str | None = None,
    json_determinant_filter: str | None = None,
    target_field_properties: str | None = None,
) -> dict[str, Any]:
    """Build camelCase payload for mapping update. Only non-None fields."""
    payload: dict[str, Any] = {}
    if external_id is not None:
        payload["externalId"] = external_id
    if format is not None:
        payload["format"] = format
    if input_param_type is not None:
        payload["inputParamType"] = input_param_type
    if is_attribute is not None:
        payload["isAttribute"] = is_attribute
    if is_cert is not None:
        payload["isCert"] = is_cert
    if json_determinant is not None:
        payload["jsonDeterminant"] = json_determinant
    if json_determinant_filter is not None:
        payload["jsonDeterminantFilter"] = json_determinant_filter
    if target_field_properties is not None:
        payload["targetFieldProperties"] = target_field_properties
    return payload


def _normalize_mapping_for_bulk(m: dict[str, Any]) -> dict[str, Any]:
    """Normalize a mapping dict (accepts both snake_case and camelCase)."""
    return {
        "sourceField": m.get("source_field") or m.get("sourceField") or "",
        "sourceType": m.get("source_type") or m.get("sourceType") or "",
        "targetField": m.get("target_field") or m.get("targetField") or "",
        "targetType": m.get("target_type") or m.get("targetType"),
        "sourceFieldIsMultiple": (
            m.get("source_field_is_multiple")
            if m.get("source_field_is_multiple") is not None
            else m.get("sourceFieldIsMultiple", False)
        ),
        "targetFieldIsMultiple": (
            m.get("target_field_is_multiple")
            if m.get("target_field_is_multiple") is not None
            else m.get("targetFieldIsMultiple", False)
        ),
        "isAttribute": (
            m.get("is_attribute")
            if m.get("is_attribute") is not None
            else m.get("isAttribute", False)
        ),
        "externalId": m.get("external_id") or m.get("externalId"),
        "targetFieldProperties": (
            m.get("target_field_properties") or m.get("targetFieldProperties")
        ),
        "jsonDeterminant": (m.get("json_determinant") or m.get("jsonDeterminant")),
        "jsonDeterminantFilter": (
            m.get("json_determinant_filter") or m.get("jsonDeterminantFilter")
        ),
    }


# =============================================================================
# Shared internal logic (DRY for input/output)
# =============================================================================


async def _mapping_create(
    bot_id: str | int,
    mapping_type: Literal["input", "output"],
    payload: dict[str, Any],
) -> dict[str, Any]:
    """Shared create logic for input/output mappings."""
    type_label = f"bot_{mapping_type}_mapping"
    endpoint = f"/bot/{bot_id}/{mapping_type}_mapping"

    try:
        user_email = get_current_user_email()
    except NotAuthenticatedError as e:
        raise ToolError(str(e))

    try:
        async with BPAClient() as client:
            # Pre-flight: verify bot exists
            try:
                await client.get(
                    "/bot/{bot_id}",
                    path_params={"bot_id": bot_id},
                    resource_type="bot",
                    resource_id=bot_id,
                )
            except BPANotFoundError:
                raise ToolError(
                    f"Bot '{bot_id}' not found. "
                    "Use 'bot_list' with service_id to see available bots."
                )

            audit_logger = AuditLogger()
            audit_id = await audit_logger.record_pending(
                user_email=user_email,
                operation_type="create",
                object_type=type_label,
                object_id=str(bot_id),
                params=payload,
            )

            try:
                result = await client.post(
                    endpoint,
                    json=payload,
                    resource_type=type_label,
                )

                created_id = result.get("id")
                await audit_logger.save_rollback_state(
                    audit_id=audit_id,
                    object_type=type_label,
                    object_id=str(created_id),
                    previous_state={
                        "id": created_id,
                        "_operation": "create",
                    },
                )

                await audit_logger.mark_success(
                    audit_id,
                    result={"mapping_id": created_id, "bot_id": str(bot_id)},
                )

                transformed = _transform_mapping_response(result)
                transformed["bot_id"] = str(bot_id)
                transformed["audit_id"] = audit_id
                return transformed

            except BPAClientError as e:
                await audit_logger.mark_failed(audit_id, str(e))
                raise translate_error(e, resource_type=type_label)

    except ToolError:
        raise
    except BPAClientError as e:
        raise translate_error(e, resource_type=type_label)


async def _mapping_update(
    mapping_id: str | int,
    mapping_type: Literal["input", "output"],
    payload: dict[str, Any],
) -> dict[str, Any]:
    """Shared update logic for input/output mappings."""
    type_label = f"bot_{mapping_type}_mapping"
    endpoint = f"/{mapping_type}_mapping/{mapping_id}"

    if not payload:
        raise ToolError(
            f"Cannot update {mapping_type} mapping: at least one field must be "
            "provided (external_id, format, is_attribute, json_determinant, etc.)."
        )

    try:
        user_email = get_current_user_email()
    except NotAuthenticatedError as e:
        raise ToolError(str(e))

    try:
        async with BPAClient() as client:
            audit_logger = AuditLogger()
            audit_id = await audit_logger.record_pending(
                user_email=user_email,
                operation_type="update",
                object_type=type_label,
                object_id=str(mapping_id),
                params=payload,
            )

            try:
                # PUT returns void — no response body
                await client.put(
                    endpoint,
                    json=payload,
                    resource_type=type_label,
                    resource_id=mapping_id,
                )

                updated_fields = list(payload.keys())
                await audit_logger.mark_success(
                    audit_id,
                    result={
                        "mapping_id": str(mapping_id),
                        "updated_fields": updated_fields,
                    },
                )

                return {
                    "mapping_id": str(mapping_id),
                    "updated_fields": updated_fields,
                    "audit_id": audit_id,
                }

            except BPAClientError as e:
                await audit_logger.mark_failed(audit_id, str(e))
                raise translate_error(
                    e, resource_type=type_label, resource_id=mapping_id
                )

    except ToolError:
        raise
    except BPAClientError as e:
        raise translate_error(e, resource_type=type_label, resource_id=mapping_id)


async def _mapping_delete(
    mapping_id: str | int,
    mapping_type: Literal["input", "output"],
) -> dict[str, Any]:
    """Shared delete logic for input/output mappings."""
    type_label = f"bot_{mapping_type}_mapping"
    endpoint = f"/{mapping_type}_mapping/{mapping_id}"

    if not mapping_id:
        raise ToolError(
            f"'mapping_id' is required. "
            f"Use 'bot_{mapping_type}_mapping_list' to find mapping IDs."
        )

    try:
        user_email = get_current_user_email()
    except NotAuthenticatedError as e:
        raise ToolError(str(e))

    try:
        async with BPAClient() as client:
            audit_logger = AuditLogger()
            audit_id = await audit_logger.record_pending(
                user_email=user_email,
                operation_type="delete",
                object_type=type_label,
                object_id=str(mapping_id),
                params={},
            )

            try:
                # DELETE returns void — no response body
                await client.delete(
                    endpoint,
                    resource_type=type_label,
                    resource_id=mapping_id,
                )

                await audit_logger.mark_success(
                    audit_id,
                    result={"deleted": True, "mapping_id": str(mapping_id)},
                )

                return {
                    "deleted": True,
                    "mapping_id": str(mapping_id),
                    "audit_id": audit_id,
                }

            except BPAClientError as e:
                await audit_logger.mark_failed(audit_id, str(e))
                raise translate_error(
                    e, resource_type=type_label, resource_id=mapping_id
                )

    except ToolError:
        raise
    except BPAClientError as e:
        raise translate_error(e, resource_type=type_label, resource_id=mapping_id)


async def _mapping_list(
    bot_id: str | int,
    mapping_type: Literal["input", "output"],
) -> dict[str, Any]:
    """Shared list logic for input/output mappings."""
    if not bot_id:
        raise ToolError(
            "'bot_id' is required. Use 'bot_list' with service_id to find bot IDs."
        )

    mapping_key = (
        "inputFieldsMapping" if mapping_type == "input" else "outputFieldsMapping"
    )
    result_key = f"{mapping_type}_mappings"

    try:
        async with BPAClient() as client:
            try:
                bot_data = await client.get(
                    "/bot/{bot_id}",
                    path_params={"bot_id": bot_id},
                    resource_type="bot",
                    resource_id=bot_id,
                )
            except BPANotFoundError:
                raise ToolError(
                    f"Bot '{bot_id}' not found. "
                    "Use 'bot_list' with service_id to see available bots."
                )
    except ToolError:
        raise
    except BPAClientError as e:
        raise translate_error(e, resource_type="bot", resource_id=bot_id)

    raw_mappings = bot_data.get(mapping_key) or []
    mappings = [_transform_mapping_response(m) for m in raw_mappings]

    return {
        result_key: mappings,
        "bot_id": str(bot_id),
        "total": len(mappings),
    }


async def _mapping_save_all(
    bot_id: str | int,
    mapping_type: Literal["input", "output"],
    mappings: list[dict[str, Any]],
) -> dict[str, Any]:
    """Shared bulk-save logic for input/output mappings."""
    type_label = f"bot_{mapping_type}_mapping"
    endpoint = f"/bot/{bot_id}/{mapping_type}_mappings"
    mapping_key = (
        "inputFieldsMapping" if mapping_type == "input" else "outputFieldsMapping"
    )

    if not bot_id:
        raise ToolError(
            "'bot_id' is required. Use 'bot_list' with service_id to find bot IDs."
        )

    if not mappings:
        raise ToolError(
            f"Cannot save {mapping_type} mappings: 'mappings' list is empty. "
            f"To delete all mappings, use bot_{mapping_type}_mapping_delete "
            "individually. Bulk save with an empty list is not allowed."
        )

    # Validate each mapping has required fields
    for i, m in enumerate(mappings):
        sf = m.get("source_field") or m.get("sourceField")
        st = m.get("source_type") or m.get("sourceType")
        tf = m.get("target_field") or m.get("targetField")
        if not sf or not st or not tf:
            raise ToolError(
                f"Mapping at index {i} is missing required fields. "
                "Each mapping needs source_field, source_type, target_field."
            )

    try:
        user_email = get_current_user_email()
    except NotAuthenticatedError as e:
        raise ToolError(str(e))

    # Normalize all mappings to camelCase
    mappings_payload = [_normalize_mapping_for_bulk(m) for m in mappings]

    try:
        async with BPAClient() as client:
            # Capture current mappings for rollback
            try:
                bot_data = await client.get(
                    "/bot/{bot_id}",
                    path_params={"bot_id": bot_id},
                    resource_type="bot",
                    resource_id=bot_id,
                )
            except BPANotFoundError:
                raise ToolError(
                    f"Bot '{bot_id}' not found. "
                    "Use 'bot_list' with service_id to see available bots."
                )

            previous_mappings = bot_data.get(mapping_key) or []
            previous_count = len(previous_mappings)

            audit_logger = AuditLogger()
            audit_id = await audit_logger.record_pending(
                user_email=user_email,
                operation_type="bulk_replace",
                object_type=type_label,
                object_id=str(bot_id),
                params={
                    "new_mapping_count": len(mappings_payload),
                    "previous_mapping_count": previous_count,
                },
            )

            # Save ALL previous mappings for rollback
            await audit_logger.save_rollback_state(
                audit_id=audit_id,
                object_type=type_label,
                object_id=str(bot_id),
                previous_state={
                    "mappings": previous_mappings,
                    "_operation": "bulk_replace",
                },
            )

            try:
                # PUT returns void
                await client.put(
                    endpoint,
                    json=mappings_payload,  # type: ignore[arg-type]
                    resource_type=type_label,
                    resource_id=bot_id,
                )

                await audit_logger.mark_success(
                    audit_id,
                    result={
                        "bot_id": str(bot_id),
                        "mapping_count": len(mappings_payload),
                        "previous_mapping_count": previous_count,
                    },
                )

                return {
                    "bot_id": str(bot_id),
                    "mapping_count": len(mappings_payload),
                    "previous_mapping_count": previous_count,
                    "audit_id": audit_id,
                }

            except BPAClientError as e:
                await audit_logger.mark_failed(audit_id, str(e))
                raise translate_error(e, resource_type=type_label)

    except ToolError:
        raise
    except BPAClientError as e:
        raise translate_error(e, resource_type=type_label)


# =============================================================================
# Public tools: Mapping List
# =============================================================================


@large_response_handler(
    threshold_bytes=50 * 1024,
    navigation={
        "list_all": "jq '.input_mappings'",
        "find_by_source": (
            "jq '.input_mappings[] | select(.source_field | contains(\"search\"))'"
        ),
        "find_by_target": (
            "jq '.input_mappings[] | select(.target_field | contains(\"search\"))'"
        ),
    },
)
async def bot_input_mapping_list(bot_id: str | int) -> dict[str, Any]:
    """List input mappings for a bot.

    Args:
        bot_id: Bot ID.

    Returns:
        dict with input_mappings, bot_id, total.
    """
    return await _mapping_list(bot_id, "input")


@large_response_handler(
    threshold_bytes=50 * 1024,
    navigation={
        "list_all": "jq '.output_mappings'",
        "find_by_source": (
            "jq '.output_mappings[] | select(.source_field | contains(\"search\"))'"
        ),
        "find_by_target": (
            "jq '.output_mappings[] | select(.target_field | contains(\"search\"))'"
        ),
    },
)
async def bot_output_mapping_list(bot_id: str | int) -> dict[str, Any]:
    """List output mappings for a bot.

    Args:
        bot_id: Bot ID.

    Returns:
        dict with output_mappings, bot_id, total.
    """
    return await _mapping_list(bot_id, "output")


# =============================================================================
# Public tools: Mapping Create
# =============================================================================


async def bot_input_mapping_create(
    bot_id: str | int,
    source_field: str,
    source_type: str,
    target_field: str,
    target_type: str | None = None,
    source_field_is_multiple: bool = False,
    target_field_is_multiple: bool = False,
    is_attribute: bool = False,
    format: str | None = None,
    input_param_type: str | None = None,
    json_determinant: str | None = None,
) -> dict[str, Any]:
    """Create an input mapping for a bot. Audited write operation.

    Maps a service form field (source) to an external GDB field (target).

    Args:
        bot_id: Bot ID to add mapping to.
        source_field: Service form field name.
        source_type: Source field data type.
        target_field: External service (GDB) field name.
        target_type: Target field data type (optional).
        source_field_is_multiple: Source is a collection (default: False).
        target_field_is_multiple: Target is a collection (default: False).
        is_attribute: Mark as attribute mapping (default: False).
        format: Data format, e.g. "JSON" (optional).
        input_param_type: Parameter type: HEADER, QUERY, BODY, PATH (optional).
        json_determinant: Condition logic JSON (optional).

    Returns:
        dict with id, source_field, source_type, target_field, target_type,
        bot_id, audit_id.
    """
    _validate_mapping_create_params(bot_id, source_field, source_type, target_field)
    payload = _build_create_payload(
        source_field=source_field,
        source_type=source_type,
        target_field=target_field,
        target_type=target_type,
        source_field_is_multiple=source_field_is_multiple,
        target_field_is_multiple=target_field_is_multiple,
        is_attribute=is_attribute,
        format=format,
        input_param_type=input_param_type,
        json_determinant=json_determinant,
    )
    return await _mapping_create(bot_id, "input", payload)


async def bot_output_mapping_create(
    bot_id: str | int,
    source_field: str,
    source_type: str,
    target_field: str,
    target_type: str | None = None,
    source_field_is_multiple: bool = False,
    target_field_is_multiple: bool = False,
    is_attribute: bool = False,
    format: str | None = None,
    json_determinant: str | None = None,
) -> dict[str, Any]:
    """Create an output mapping for a bot. Audited write operation.

    Maps an external GDB response field (source) to a service form field (target).

    Args:
        bot_id: Bot ID to add mapping to.
        source_field: External service (GDB) response field name.
        source_type: Source field data type.
        target_field: Service form field name to populate.
        target_type: Target field data type (optional).
        source_field_is_multiple: Source is a collection (default: False).
        target_field_is_multiple: Target is a collection (default: False).
        is_attribute: Mark as attribute mapping (default: False).
        format: Data format, e.g. "JSON" (optional).
        json_determinant: Condition logic JSON (optional).

    Returns:
        dict with id, source_field, source_type, target_field, target_type,
        bot_id, audit_id.
    """
    _validate_mapping_create_params(bot_id, source_field, source_type, target_field)
    payload = _build_create_payload(
        source_field=source_field,
        source_type=source_type,
        target_field=target_field,
        target_type=target_type,
        source_field_is_multiple=source_field_is_multiple,
        target_field_is_multiple=target_field_is_multiple,
        is_attribute=is_attribute,
        format=format,
        json_determinant=json_determinant,
    )
    return await _mapping_create(bot_id, "output", payload)


# =============================================================================
# Public tools: Mapping Update
# =============================================================================


async def bot_input_mapping_update(
    mapping_id: str | int,
    external_id: str | None = None,
    format: str | None = None,
    input_param_type: str | None = None,
    is_attribute: bool | None = None,
    is_cert: bool | None = None,
    json_determinant: str | None = None,
    json_determinant_filter: str | None = None,
    target_field_properties: str | None = None,
) -> dict[str, Any]:
    """Update an input mapping's properties. Audited write operation.

    Only metadata fields can be updated (not source/target). To change
    source/target fields, delete and recreate the mapping.

    Args:
        mapping_id: Input mapping ID.
        external_id: External system ID (optional).
        format: Data format (optional).
        input_param_type: HEADER, QUERY, BODY, PATH (optional).
        is_attribute: Attribute flag (optional).
        is_cert: Certificate flag (optional).
        json_determinant: Condition logic JSON (optional).
        json_determinant_filter: Filter logic JSON (optional).
        target_field_properties: Target field properties JSON (optional).

    Returns:
        dict with mapping_id, updated_fields, audit_id.
    """
    if not mapping_id:
        raise ToolError(
            "'mapping_id' is required. "
            "Use 'bot_input_mapping_list' to find mapping IDs."
        )
    payload = _build_update_payload(
        external_id=external_id,
        format=format,
        input_param_type=input_param_type,
        is_attribute=is_attribute,
        is_cert=is_cert,
        json_determinant=json_determinant,
        json_determinant_filter=json_determinant_filter,
        target_field_properties=target_field_properties,
    )
    return await _mapping_update(mapping_id, "input", payload)


async def bot_output_mapping_update(
    mapping_id: str | int,
    external_id: str | None = None,
    format: str | None = None,
    is_attribute: bool | None = None,
    is_cert: bool | None = None,
    json_determinant: str | None = None,
    json_determinant_filter: str | None = None,
    target_field_properties: str | None = None,
) -> dict[str, Any]:
    """Update an output mapping's properties. Audited write operation.

    Only metadata fields can be updated (not source/target). To change
    source/target fields, delete and recreate the mapping.

    Args:
        mapping_id: Output mapping ID.
        external_id: External system ID (optional).
        format: Data format (optional).
        is_attribute: Attribute flag (optional).
        is_cert: Certificate flag (optional).
        json_determinant: Condition logic JSON (optional).
        json_determinant_filter: Filter logic JSON (optional).
        target_field_properties: Target field properties JSON (optional).

    Returns:
        dict with mapping_id, updated_fields, audit_id.
    """
    if not mapping_id:
        raise ToolError(
            "'mapping_id' is required. "
            "Use 'bot_output_mapping_list' to find mapping IDs."
        )
    payload = _build_update_payload(
        external_id=external_id,
        format=format,
        is_attribute=is_attribute,
        is_cert=is_cert,
        json_determinant=json_determinant,
        json_determinant_filter=json_determinant_filter,
        target_field_properties=target_field_properties,
    )
    return await _mapping_update(mapping_id, "output", payload)


# =============================================================================
# Public tools: Mapping Delete
# =============================================================================


async def bot_input_mapping_delete(mapping_id: str | int) -> dict[str, Any]:
    """Delete an input mapping. Audited write operation.

    Args:
        mapping_id: Input mapping ID to delete.

    Returns:
        dict with deleted (bool), mapping_id, audit_id.
    """
    return await _mapping_delete(mapping_id, "input")


async def bot_output_mapping_delete(mapping_id: str | int) -> dict[str, Any]:
    """Delete an output mapping. Audited write operation.

    Args:
        mapping_id: Output mapping ID to delete.

    Returns:
        dict with deleted (bool), mapping_id, audit_id.
    """
    return await _mapping_delete(mapping_id, "output")


# =============================================================================
# Public tools: Bulk Save
# =============================================================================


async def bot_input_mapping_save_all(
    bot_id: str | int,
    mappings: list[dict[str, Any]],
) -> dict[str, Any]:
    """Replace ALL input mappings for a bot. Audited write operation.

    WARNING: This REPLACES all existing input mappings. Any mappings not
    included in the list will be deleted. Use bot_input_mapping_list first
    to get current mappings, then modify and pass the complete list.

    Args:
        bot_id: Bot ID.
        mappings: Complete list of input mappings. Each mapping needs
            source_field, source_type, target_field, target_type.

    Returns:
        dict with bot_id, mapping_count, previous_mapping_count, audit_id.
    """
    return await _mapping_save_all(bot_id, "input", mappings)


async def bot_output_mapping_save_all(
    bot_id: str | int,
    mappings: list[dict[str, Any]],
) -> dict[str, Any]:
    """Replace ALL output mappings for a bot. Audited write operation.

    WARNING: This REPLACES all existing output mappings. Any mappings not
    included in the list will be deleted. Use bot_output_mapping_list first
    to get current mappings, then modify and pass the complete list.

    Args:
        bot_id: Bot ID.
        mappings: Complete list of output mappings. Each mapping needs
            source_field, source_type, target_field, target_type.

    Returns:
        dict with bot_id, mapping_count, previous_mapping_count, audit_id.
    """
    return await _mapping_save_all(bot_id, "output", mappings)


# =============================================================================
# Public tools: Bot Clone
# =============================================================================


async def bot_clone(bot_id: str | int) -> dict[str, Any]:
    """Clone a bot with all mappings. Audited write operation.

    Creates a copy with auto-incremented name. All input and output
    mappings are duplicated.

    Args:
        bot_id: Bot ID to clone.

    Returns:
        dict with cloned_bot (full bot object), original_bot_id,
        input_mapping_count, output_mapping_count, audit_id.
    """
    if not bot_id:
        raise ToolError(
            "'bot_id' is required. Use 'bot_list' with service_id to find bot IDs."
        )

    try:
        user_email = get_current_user_email()
    except NotAuthenticatedError as e:
        raise ToolError(str(e))

    try:
        async with BPAClient() as client:
            # Pre-flight: verify bot exists
            try:
                await client.get(
                    "/bot/{bot_id}",
                    path_params={"bot_id": bot_id},
                    resource_type="bot",
                    resource_id=bot_id,
                )
            except BPANotFoundError:
                raise ToolError(
                    f"Bot '{bot_id}' not found. "
                    "Use 'bot_list' with service_id to see available bots."
                )

            audit_logger = AuditLogger()
            audit_id = await audit_logger.record_pending(
                user_email=user_email,
                operation_type="clone",
                object_type="bot",
                object_id=str(bot_id),
                params={"source_bot_id": str(bot_id)},
            )

            try:
                result = await client.post(
                    f"/bot/{bot_id}/clone",
                    resource_type="bot",
                )

                cloned_id = result.get("id")

                # Clone response doesn't include mappings in JSON,
                # so count them via separate GET calls
                cloned_inputs = await client.get(
                    f"/bot/{cloned_id}/input_mapping",
                    resource_type="input_mapping",
                )
                cloned_outputs = await client.get(
                    f"/bot/{cloned_id}/output_mapping",
                    resource_type="output_mapping",
                )
                input_count = (
                    len(cloned_inputs) if isinstance(cloned_inputs, list) else 0
                )
                output_count = (
                    len(cloned_outputs) if isinstance(cloned_outputs, list) else 0
                )

                await audit_logger.save_rollback_state(
                    audit_id=audit_id,
                    object_type="bot",
                    object_id=str(cloned_id),
                    previous_state={
                        "id": cloned_id,
                        "_operation": "clone",
                    },
                )

                await audit_logger.mark_success(
                    audit_id,
                    result={
                        "cloned_bot_id": cloned_id,
                        "original_bot_id": str(bot_id),
                    },
                )

                return {
                    "cloned_bot": _transform_bot_response(result),
                    "original_bot_id": str(bot_id),
                    "input_mapping_count": input_count,
                    "output_mapping_count": output_count,
                    "audit_id": audit_id,
                }

            except BPAClientError as e:
                await audit_logger.mark_failed(audit_id, str(e))
                raise translate_error(e, resource_type="bot")

    except ToolError:
        raise
    except BPAClientError as e:
        raise translate_error(e, resource_type="bot", resource_id=bot_id)


# =============================================================================
# Public tools: Bot History
# =============================================================================


@large_response_handler(
    threshold_bytes=50 * 1024,
    navigation={
        "list_all": "jq '.revisions'",
        "latest": "jq '.revisions[0]'",
    },
)
async def bot_history_list(
    bot_id: str | int,
    page: int = 0,
    page_size: int = 10,
) -> dict[str, Any]:
    """List bot revision history (paginated).

    Args:
        bot_id: Bot ID.
        page: Page number, zero-indexed (default: 0).
        page_size: Items per page (default: 10).

    Returns:
        dict with revisions, bot_id, page, page_size, total, total_pages.
    """
    if not bot_id:
        raise ToolError(
            "'bot_id' is required. Use 'bot_list' with service_id to find bot IDs."
        )

    try:
        async with BPAClient() as client:
            try:
                result = await client.get(
                    f"/bot/{bot_id}/pagedhistory",
                    params={"pageNo": page, "pageSize": page_size},
                    resource_type="bot_history",
                    resource_id=bot_id,
                )
            except BPANotFoundError:
                raise ToolError(
                    f"Bot '{bot_id}' not found. "
                    "Use 'bot_list' with service_id to see available bots."
                )
    except ToolError:
        raise
    except BPAClientError as e:
        raise translate_error(e, resource_type="bot_history", resource_id=bot_id)

    publish_list = result.get("publishList") or []
    revisions = [
        {
            "revision_number": item.get("revisionNumber"),
            "created_by": item.get("createdBy"),
            "created_when": item.get("createdWhen"),
            "last_changed_by": item.get("lastChangedBy"),
            "last_changed_when": item.get("lastChangedWhen"),
        }
        for item in publish_list
    ]

    return {
        "revisions": revisions,
        "bot_id": str(bot_id),
        "page": result.get("currentPage", page),
        "page_size": page_size,
        "total": result.get("totalItems", 0),
        "total_pages": result.get("totalPages", 0),
    }


async def bot_history_revert(
    bot_id: str | int,
    revision_number: int,
) -> dict[str, Any]:
    """Revert bot to a previous revision. Audited write operation.

    WARNING: Replaces ALL current bot configuration and mappings with the
    state from the specified revision. This is destructive and cannot be
    partially applied.

    Args:
        bot_id: Bot ID to revert.
        revision_number: Target revision number (from bot_history_list).

    Returns:
        dict with reverted (bool), bot_id, revision_number,
        restored_bot, audit_id.
    """
    if not bot_id:
        raise ToolError(
            "'bot_id' is required. Use 'bot_list' with service_id to find bot IDs."
        )
    if not isinstance(revision_number, int) or revision_number <= 0:
        raise ToolError(
            "'revision_number' must be a positive integer. "
            "Use 'bot_history_list' to see available revisions."
        )

    try:
        user_email = get_current_user_email()
    except NotAuthenticatedError as e:
        raise ToolError(str(e))

    try:
        async with BPAClient() as client:
            # Capture COMPLETE current state before revert (bot + all mappings)
            try:
                current_bot = await client.get(
                    "/bot/{bot_id}",
                    path_params={"bot_id": bot_id},
                    resource_type="bot",
                    resource_id=bot_id,
                )
            except BPANotFoundError:
                raise ToolError(
                    f"Bot '{bot_id}' not found. "
                    "Use 'bot_list' with service_id to see available bots."
                )

            current_input_mappings = current_bot.get("inputFieldsMapping") or []
            current_output_mappings = current_bot.get("outputFieldsMapping") or []

            audit_logger = AuditLogger()
            audit_id = await audit_logger.record_pending(
                user_email=user_email,
                operation_type="revert",
                object_type="bot",
                object_id=str(bot_id),
                params={"revision_number": revision_number},
            )

            # Save FULL rollback state (bot + all mappings)
            await audit_logger.save_rollback_state(
                audit_id=audit_id,
                object_type="bot",
                object_id=str(bot_id),
                previous_state={
                    "bot": current_bot,
                    "input_mappings": current_input_mappings,
                    "output_mappings": current_output_mappings,
                    "_operation": "revert",
                },
            )

            try:
                result = await client.put(
                    f"/bot/{bot_id}/history/{revision_number}",
                    resource_type="bot",
                    resource_id=bot_id,
                )

                await audit_logger.mark_success(
                    audit_id,
                    result={
                        "bot_id": str(bot_id),
                        "revision_number": revision_number,
                        "reverted": True,
                    },
                )

                return {
                    "reverted": True,
                    "bot_id": str(bot_id),
                    "revision_number": revision_number,
                    "restored_bot": _transform_bot_response(result),
                    "audit_id": audit_id,
                }

            except BPAClientError as e:
                await audit_logger.mark_failed(audit_id, str(e))
                raise translate_error(e, resource_type="bot", resource_id=bot_id)

    except ToolError:
        raise
    except BPAClientError as e:
        raise translate_error(e, resource_type="bot", resource_id=bot_id)


# =============================================================================
# Public tools: Field Visibility
# =============================================================================


async def _visibility_update(
    bot_id: str | int,
    visibility_type: Literal["input", "output"],
    visibility_config: list[dict[str, Any]],
) -> dict[str, Any]:
    """Shared visibility update logic."""
    type_label = f"bot_{visibility_type}_visibility"
    endpoint = f"/bot/{bot_id}/{visibility_type}_visibility"

    if not bot_id:
        raise ToolError(
            "'bot_id' is required. Use 'bot_list' with service_id to find bot IDs."
        )

    if not visibility_config:
        raise ToolError("'visibility_config' is required and cannot be empty.")

    try:
        user_email = get_current_user_email()
    except NotAuthenticatedError as e:
        raise ToolError(str(e))

    try:
        async with BPAClient() as client:
            # Pre-flight: verify bot exists and capture current state
            try:
                bot_data = await client.get(
                    "/bot/{bot_id}",
                    path_params={"bot_id": bot_id},
                    resource_type="bot",
                    resource_id=bot_id,
                )
            except BPANotFoundError:
                raise ToolError(
                    f"Bot '{bot_id}' not found. "
                    "Use 'bot_list' with service_id to see available bots."
                )

            audit_logger = AuditLogger()
            audit_id = await audit_logger.record_pending(
                user_email=user_email,
                operation_type="update",
                object_type=type_label,
                object_id=str(bot_id),
                params={"field_count": len(visibility_config)},
            )

            # Save previous field properties for rollback
            await audit_logger.save_rollback_state(
                audit_id=audit_id,
                object_type=type_label,
                object_id=str(bot_id),
                previous_state={
                    "field_properties": bot_data.get("fieldProperties"),
                    "_operation": "visibility_update",
                },
            )

            try:
                # Backend expects the raw JSON structure
                await client.put(
                    endpoint,
                    json=visibility_config,  # type: ignore[arg-type]
                    resource_type=type_label,
                    resource_id=bot_id,
                )

                await audit_logger.mark_success(
                    audit_id,
                    result={
                        "bot_id": str(bot_id),
                        "field_count": len(visibility_config),
                    },
                )

                return {
                    "bot_id": str(bot_id),
                    "field_count": len(visibility_config),
                    "audit_id": audit_id,
                }

            except BPAClientError as e:
                await audit_logger.mark_failed(audit_id, str(e))
                raise translate_error(e, resource_type=type_label)

    except ToolError:
        raise
    except BPAClientError as e:
        raise translate_error(e, resource_type=type_label)


async def bot_input_visibility_update(
    bot_id: str | int,
    visibility_config: list[dict[str, Any]],
) -> dict[str, Any]:
    """Update input field visibility for a bot. Audited write operation.

    Controls which fields are hidden from the bot's input mapping interface.

    Args:
        bot_id: Bot ID.
        visibility_config: List of field visibility items, each with
            key, form, parent_key (optional), input_hidden (bool).

    Returns:
        dict with bot_id, field_count, audit_id.
    """
    return await _visibility_update(bot_id, "input", visibility_config)


async def bot_output_visibility_update(
    bot_id: str | int,
    visibility_config: list[dict[str, Any]],
) -> dict[str, Any]:
    """Update output field visibility for a bot. Audited write operation.

    Controls which fields are hidden from the bot's output mapping interface.

    Args:
        bot_id: Bot ID.
        visibility_config: List of field visibility items, each with
            key, form, parent_key (optional), output_hidden (bool).

    Returns:
        dict with bot_id, field_count, audit_id.
    """
    return await _visibility_update(bot_id, "output", visibility_config)


# =============================================================================
# Registration
# =============================================================================


def register_bot_mapping_tools(mcp: Any) -> None:
    """Register bot mapping tools with the MCP server."""
    # Read operations
    mcp.tool()(bot_input_mapping_list)
    mcp.tool()(bot_output_mapping_list)
    mcp.tool()(bot_history_list)
    # Single-mapping CRUD
    mcp.tool()(bot_input_mapping_create)
    mcp.tool()(bot_input_mapping_update)
    mcp.tool()(bot_input_mapping_delete)
    mcp.tool()(bot_output_mapping_create)
    mcp.tool()(bot_output_mapping_update)
    mcp.tool()(bot_output_mapping_delete)
    # Bulk operations
    mcp.tool()(bot_input_mapping_save_all)
    mcp.tool()(bot_output_mapping_save_all)
    # Bot-level operations
    mcp.tool()(bot_clone)
    mcp.tool()(bot_history_revert)
    # Visibility
    mcp.tool()(bot_input_visibility_update)
    mcp.tool()(bot_output_visibility_update)
