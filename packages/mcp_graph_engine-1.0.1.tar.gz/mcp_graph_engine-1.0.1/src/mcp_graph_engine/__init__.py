"""MCP Graph Engine - A graph-based memory and reasoning tool for LLMs."""

__version__ = "0.1.0"
