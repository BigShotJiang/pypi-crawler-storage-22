# References & Inspiration

## Core Technology

| Technology | Link | Usage |
|-----------|------|-------|
| Model Context Protocol (MCP) | [modelcontextprotocol.io](https://modelcontextprotocol.io/) | The underlying protocol standard by Anthropic |
| FastMCP v2 | [github.com/jlowin/fastmcp](https://github.com/jlowin/fastmcp) | Python framework for building MCP servers |
| MCP Specification | [spec.modelcontextprotocol.io](https://spec.modelcontextprotocol.io/) | Protocol specification |
| JSON-RPC 2.0 | [jsonrpc.org](https://www.jsonrpc.org/specification) | Transport protocol used by MCP HTTP |

## Repositories Analyzed During Design

### [Accenture/mcp-bench](https://github.com/Accenture/mcp-bench)

MCP benchmarking framework for evaluating LLM tool-use.

**Studied:** STDIO and HTTP transport handling, multi-server lifecycle management, server configuration via `commands.json`, tool discovery and caching patterns.

**Key takeaway:** Solid connector patterns, but designed for benchmarking -- not runtime bridging.

### [mcp-use/mcp-use](https://github.com/mcp-use/mcp-use)

MCP client and agent framework (9k+ stars).

**Studied:** Meta-tools pattern (`search_tools`, `connect_to_mcp_server`, `list_servers`), dynamic server management, LangChain adapter.

**Key takeaway:** The meta-tool interface pattern is ideal for keeping agent context lean.

### [universal-mcp/universal-mcp](https://github.com/universal-mcp/universal-mcp)

MCP middleware for API applications.

**Studied:** Credential management (MemoryStore, EnvironmentStore, KeyringStore), app registry and dynamic tool loading, ToolManager and ToolRegistry patterns.

**Key takeaway:** Excellent credential store abstraction and app catalog design.

### [CognitionAI/metabase-mcp-server](https://github.com/CognitionAI/metabase-mcp-server)

Metabase analytics MCP server by Cognition AI.

**Studied:** Tool categorization (81+ tools), essential vs. all modes for tool exposure, CRUD patterns for complex API surfaces.

**Key takeaway:** Categorization and tiered tool exposure as a model for our catalog.

### [FastMCP v3 Architecture](https://github.com/jlowin/fastmcp)

FastMCP v3 release candidate.

**Studied:** Provider architecture, Transforms (namespacing, visibility, versioning), per-session visibility, Proxy support.

**Key takeaway:** v3's provider/transform system is the ideal long-term foundation. Built on v2 with v3-compatible architecture for future migration.

## Framework & Libraries

| Library | Version | Purpose |
|---------|---------|---------|
| Pydantic v2 | 2.x | Data validation and JSON schema generation |
| pydantic-settings | 2.x | Environment variable configuration |
| aiosqlite | 0.x | Async SQLite for metrics and registry |
| httpx | 0.27+ | Async HTTP client for OpenAPI executor |
| psutil | 5.x | Cross-platform system resource monitoring |
| Starlette | 0.x | Async HTTP framework for management API |
| websockets | 12.x | WebSocket client for enterprise platform |
| PyYAML | 6.x | YAML catalog file parsing |
