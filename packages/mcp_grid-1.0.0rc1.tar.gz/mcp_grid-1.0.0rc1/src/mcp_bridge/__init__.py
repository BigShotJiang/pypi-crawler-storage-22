"""MCP Bridge - A dynamic MCP server bridge for managing multiple MCP servers on demand."""

__version__ = "1.0.0-beta-rc"
