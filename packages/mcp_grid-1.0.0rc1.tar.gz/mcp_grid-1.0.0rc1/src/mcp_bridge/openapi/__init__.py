"""OpenAPI-to-MCP adapter: turn any REST API into MCP tools."""
