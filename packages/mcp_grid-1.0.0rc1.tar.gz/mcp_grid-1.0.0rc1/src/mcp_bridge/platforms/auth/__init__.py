"""Authentication providers for enterprise platforms.

Modules:
    token_manager -- In-memory token lifecycle management
    oauth2 -- OAuth2 Authorization Code + PKCE flows for Microsoft, GitHub, etc.
"""

from mcp_bridge.platforms.auth.oauth2 import (
    OAuth2Config,
    OAuth2Flow,
    generate_pkce_pair,
    github_oauth2_config,
    microsoft_ado_config,
    microsoft_oauth2_config,
    resolve_swagger_ui_spec_url,
    validate_github_pat,
)
from mcp_bridge.platforms.auth.token_manager import TokenManager

__all__ = [
    "OAuth2Config",
    "OAuth2Flow",
    "TokenManager",
    "generate_pkce_pair",
    "github_oauth2_config",
    "microsoft_ado_config",
    "microsoft_oauth2_config",
    "resolve_swagger_ui_spec_url",
    "validate_github_pat",
]
