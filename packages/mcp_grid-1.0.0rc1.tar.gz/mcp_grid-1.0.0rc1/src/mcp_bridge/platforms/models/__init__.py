"""Data models for enterprise platform integration."""
