"""Test server creation and tool registration."""

from __future__ import annotations

from mcp_bridge.server import create_server


class TestServerCreation:
    """Test that the MCP Bridge server is correctly configured."""

    def test_create_server(self):
        """Test server creation with all meta-tools registered."""
        mcp = create_server()
        assert mcp.name == "MCP Bridge"

    def test_server_has_instructions(self):
        """Test server has instructions for agents."""
        mcp = create_server()
        assert mcp.instructions is not None
        assert "discover_servers" in mcp.instructions

    def test_all_meta_tools_registered(self):
        """Test all 9 meta-tools are registered."""
        mcp = create_server()

        # Get registered tool names
        # FastMCP stores tools in _tool_manager
        tool_manager = mcp._tool_manager
        tool_names = set(tool_manager._tools.keys())

        expected_tools = {
            "discover_servers",
            "configure_server",
            "activate_server",
            "call_tool",
            "deactivate_server",
            "get_server_status",
            "list_active_tools",
            "parallel_call",
            "import_mcp_config",
        }

        assert expected_tools.issubset(tool_names), f"Missing tools: {expected_tools - tool_names}"
        print(f"Registered tools ({len(tool_names)}): {sorted(tool_names)}")
