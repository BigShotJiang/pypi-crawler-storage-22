"""Application layer - Use cases and event handlers."""
