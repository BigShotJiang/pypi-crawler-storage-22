"""Concrete event upcasters.

Register upcasters at startup (composition root) by importing modules from this package
and calling ``UpcasterChain.register(...)``.

This package is intentionally infrastructure-only.
"""
