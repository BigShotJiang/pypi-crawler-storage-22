#!/usr/bin/env bash
set -euo pipefail

# MCP Agent Mail — TL;DR installer
# - Installs uv (if missing)
# - Sets up Python 3.11+ venv with uv
# - Syncs dependencies
# - Runs auto-detect integration and starts the HTTP server on port 8765
#
# Usage examples:
#   ./scripts/install.sh --yes
#   ./scripts/install.sh --dir "$HOME/mcp_mail" --yes
#   curl -fsSL https://raw.githubusercontent.com/jleechanorg/mcp_mail/main/scripts/install.sh | bash -s -- --yes

REPO_URL="https://github.com/jleechanorg/mcp_mail"
REPO_NAME="mcp_mail"
BRANCH="main"
DEFAULT_CLONE_DIR="$PWD/${REPO_NAME}"
CLONE_DIR=""
YES=0
NO_START=0
START_ONLY=0
PROJECT_DIR=""
INTEGRATION_TOKEN="${INTEGRATION_BEARER_TOKEN:-}"
HTTP_PORT_OVERRIDE=""
SKIP_BEADS=0
BEADS_INSTALL_URL="https://raw.githubusercontent.com/steveyegge/beads/main/scripts/install.sh"
SUMMARY_LINES=()
LAST_BD_VERSION=""

usage() {
  cat <<EOF
MCP Agent Mail installer

Options:
  --dir DIR              Clone/use repo at DIR (default: ./mcp_mail)
  --branch NAME          Git branch to clone (default: main)
  --port PORT            HTTP server port (default: 8765); sets HTTP_PORT in .env
  --skip-beads           Do not install the Beads (bd) CLI automatically
  -y, --yes              Non-interactive; assume Yes where applicable
  --no-start             Do not run integration/start; just set up venv + deps
  --start-only           Skip clone/setup; run integration/start in current repo
  --project-dir PATH     Pass-through to integration (where to write client configs)
  --token HEX            Use/set INTEGRATION_BEARER_TOKEN for this run
  -h, --help             Show help

Examples:
  ./scripts/install.sh --yes
  ./scripts/install.sh --port 9000 --yes
  ./scripts/install.sh --dir "\$HOME/mcp_mail" --yes
  curl -fsSL https://raw.githubusercontent.com/jleechanorg/mcp_mail/main/scripts/install.sh | bash -s -- --yes
  curl -fsSL https://raw.githubusercontent.com/jleechanorg/mcp_mail/main/scripts/install.sh | bash -s -- --port 9000 --yes
EOF
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --dir) shift; CLONE_DIR="${1:-}" ;;
    --dir=*) CLONE_DIR="${1#*=}" ;;
    --branch) shift; BRANCH="${1:-}" ;;
    --branch=*) BRANCH="${1#*=}" ;;
    --port) shift; HTTP_PORT_OVERRIDE="${1:-}" ;;
    --port=*) HTTP_PORT_OVERRIDE="${1#*=}" ;;
    -y|--yes) YES=1 ;;
    --no-start) NO_START=1 ;;
    --start-only) START_ONLY=1 ;;
    --project-dir) shift; PROJECT_DIR="${1:-}" ;;
    --project-dir=*) PROJECT_DIR="${1#*=}" ;;
    --token) shift; INTEGRATION_TOKEN="${1:-}" ;;
    --token=*) INTEGRATION_TOKEN="${1#*=}" ;;
    --skip-beads) SKIP_BEADS=1 ;;
    -h|--help) usage; exit 0 ;;
    *) echo "Unknown option: $1" >&2; usage; exit 2 ;;
  esac
  shift || true
done

# Validate port if provided
if [[ -n "${HTTP_PORT_OVERRIDE}" ]]; then
  if ! [[ "${HTTP_PORT_OVERRIDE}" =~ ^[0-9]+$ ]]; then
    err "Port must be a number (got: ${HTTP_PORT_OVERRIDE})"
    exit 1
  fi
  if [[ "${HTTP_PORT_OVERRIDE}" -lt 1 || "${HTTP_PORT_OVERRIDE}" -gt 65535 ]]; then
    err "Port must be between 1 and 65535 (got: ${HTTP_PORT_OVERRIDE})"
    exit 1
  fi
fi

info() { printf "\033[1;36m[INFO]\033[0m %s\n" "$*"; }
ok()   { printf "\033[1;32m[ OK ]\033[0m %s\n" "$*"; }
warn() { printf "\033[1;33m[WARN]\033[0m %s\n" "$*"; }
err()  { printf "\033[1;31m[ERR ]\033[0m %s\n" "$*"; }

need_cmd() { command -v "$1" >/dev/null 2>&1 || return 1; }

record_summary() {
  SUMMARY_LINES+=("$1")
}

print_summary() {
  if [[ ${#SUMMARY_LINES[@]} -eq 0 ]]; then
    return 0
  fi
  echo
  info "Installation summary"
  local line
  for line in "${SUMMARY_LINES[@]}"; do
    echo "  - ${line}"
  done
}

find_bd_binary() {
  if command -v bd >/dev/null 2>&1; then
    command -v bd
    return 0
  fi

  local candidates=("${HOME}/.local/bin/bd" "${HOME}/bin/bd" "/usr/local/bin/bd")
  local candidate
  for candidate in "${candidates[@]}"; do
    if [[ -x "${candidate}" ]]; then
      printf '%s\n' "${candidate}"
      return 0
    fi
  done

  return 1
}

maybe_add_bd_path() {
  local binary_path="$1"
  local dir
  dir=$(dirname "${binary_path}")
  if [[ ":${PATH}:" != *":${dir}:"* ]]; then
    export PATH="${dir}:${PATH}"
    ok "Temporarily added ${dir} to PATH so this session can invoke 'bd' immediately"
  fi
}

append_path_snippet() {
  local dir="$1"
  local rc_file="$2"
  if [[ -z "${rc_file}" ]]; then
    return 1
  fi

  local marker="# >>> MCP Agent Mail bd path ${dir}"
  if [[ -f "${rc_file}" ]] && grep -Fq "${marker}" "${rc_file}"; then
    return 0
  fi

  if ! touch "${rc_file}" >/dev/null 2>&1; then
    return 1
  fi

  {
    printf '\n%s\n' "${marker}"
    printf 'if [[ ":$PATH:" != *":%s:"* ]]; then\n' "${dir}"
    printf '  export PATH="%s:$PATH"\n' "${dir}"
    printf 'fi\n'
    printf '# <<< MCP Agent Mail bd path\n'
  } >> "${rc_file}"

  ok "Added ${dir} to PATH via ${rc_file}"
  return 0
}

persist_bd_path() {
  local binary_path="$1"
  local dir
  dir=$(dirname "${binary_path}")

  local shell_name=""
  if [[ -n "${SHELL:-}" ]]; then
    shell_name=$(basename "${SHELL}")
  fi

  local -a rc_candidates=()
  if [[ "${shell_name}" == "zsh" ]]; then
    rc_candidates+=("~/.zshrc")
  elif [[ "${shell_name}" == "bash" ]]; then
    rc_candidates+=("~/.bashrc")
  fi
  rc_candidates+=("~/.bashrc" "~/.zshrc" "~/.profile")

  local appended=0
  local rc
  for rc in "${rc_candidates[@]}"; do
    [[ -n "${rc}" ]] || continue
    local rc_path
    rc_path="${rc/#~/${HOME}}"
    if [[ -z "${rc_path}" ]]; then
      continue
    fi
    if append_path_snippet "${dir}" "${rc_path}"; then
      appended=1
      break
    fi
  done

  if [[ "${appended}" -eq 0 ]]; then
    warn "Could not persist PATH update automatically; ensure ${dir} is in your PATH."
  fi
}

ensure_bd_path_ready() {
  local binary_path="$1"
  maybe_add_bd_path "${binary_path}"
  persist_bd_path "${binary_path}"
}

verify_bd_binary() {
  local binary_path="$1"
  if ! "${binary_path}" version >/dev/null 2>&1; then
    err "Beads CLI at ${binary_path} failed 'bd version'. You can retry or rerun the installer with --skip-beads to handle it yourself."
    return 1
  fi

  local version_line
  version_line=$("${binary_path}" version 2>/dev/null | head -n 1 || true)
  if [[ -z "${version_line}" ]]; then
    version_line="bd version command succeeded"
  fi
  LAST_BD_VERSION="${version_line}"
  ok "Beads CLI ready (${version_line})"
}

ensure_uv() {
  if need_cmd uv; then
    ok "uv is already installed"
    record_summary "uv: already installed"
    return 0
  fi
  info "Installing uv (Astral)"
  if ! need_cmd curl; then err "curl is required to install uv"; exit 1; fi
  curl -LsSf https://astral.sh/uv/install.sh | sh
  export PATH="${HOME}/.local/bin:${PATH}"
  if need_cmd uv; then ok "uv installed"; record_summary "uv: installed"; else err "uv install failed"; exit 1; fi
}

ensure_repo() {
  # Determine target directory
  if [[ -z "${CLONE_DIR}" ]]; then CLONE_DIR="${DEFAULT_CLONE_DIR}"; fi

  # If we're already in the repo (local run), use it
  if [[ -f "pyproject.toml" ]] && grep -q '^name\s*=\s*"mcp-agent-mail"' pyproject.toml 2>/dev/null; then
    REPO_DIR="$PWD"
    ok "Using existing repo at: ${REPO_DIR}"
    record_summary "Repo: existing at ${REPO_DIR}"
    return 0
  fi

  # If directory exists and looks like the repo, use it
  if [[ -d "${CLONE_DIR}" ]] && [[ -f "${CLONE_DIR}/pyproject.toml" ]] && grep -q '^name\s*=\s*"mcp-agent-mail"' "${CLONE_DIR}/pyproject.toml" 2>/dev/null; then
    REPO_DIR="${CLONE_DIR}"
    ok "Using existing repo at: ${REPO_DIR}"
    record_summary "Repo: existing at ${REPO_DIR}"
    return 0
  fi

  # Otherwise clone
  info "Cloning ${REPO_URL} (branch=${BRANCH}) to ${CLONE_DIR}"
  need_cmd git || { err "git is required to clone"; exit 1; }
  git clone --depth 1 --branch "${BRANCH}" "${REPO_URL}" "${CLONE_DIR}"
  REPO_DIR="${CLONE_DIR}"
  ok "Cloned repo"
  record_summary "Repo: cloned into ${REPO_DIR}"
}

ensure_python_and_venv() {
  info "Ensuring Python 3.11+ and project venv (.venv)"
  uv python install 3.11
  if [[ ! -d "${REPO_DIR}/.venv" ]]; then
    (cd "${REPO_DIR}" && uv venv -p 3.11)
    ok "Created venv at ${REPO_DIR}/.venv"
    record_summary "Venv: created at ${REPO_DIR}/.venv"
  else
    ok "Found existing venv at ${REPO_DIR}/.venv"
    record_summary "Venv: existing at ${REPO_DIR}/.venv"
  fi
}

sync_deps() {
  info "Syncing dependencies with uv"
  (
    cd "${REPO_DIR}"
    # shellcheck disable=SC1091
    source .venv/bin/activate
    uv sync
  )
  ok "Dependencies installed"
  record_summary "Dependencies: uv sync complete"
}

configure_port() {
  if [[ -z "${HTTP_PORT_OVERRIDE}" ]]; then
    return 0
  fi

  local env_file="${REPO_DIR}/.env"
  local tmp="${env_file}.tmp.$$"

  info "Configuring HTTP_PORT=${HTTP_PORT_OVERRIDE} in .env"

  # Set trap to cleanup temp file
  trap "rm -f \"${tmp}\" 2>/dev/null" EXIT INT TERM

  # Set secure umask for all file operations
  umask 077

  if [[ -f "${env_file}" ]]; then
    # File exists - update or append
    if grep -q '^HTTP_PORT=' "${env_file}"; then
      # Replace existing value
      if ! sed "s/^HTTP_PORT=.*/HTTP_PORT=${HTTP_PORT_OVERRIDE}/" "${env_file}" > "${tmp}"; then
        err "Failed to update HTTP_PORT in .env"
        rm -f "${tmp}" 2>/dev/null
        trap - EXIT INT TERM
        return 1
      fi
    else
      # Append new value
      if ! { cat "${env_file}"; echo "HTTP_PORT=${HTTP_PORT_OVERRIDE}"; } > "${tmp}"; then
        err "Failed to append HTTP_PORT to .env"
        rm -f "${tmp}" 2>/dev/null
        trap - EXIT INT TERM
        return 1
      fi
    fi

    # Atomic move
    if ! mv "${tmp}" "${env_file}"; then
      err "Failed to write .env file"
      rm -f "${tmp}" 2>/dev/null
      trap - EXIT INT TERM
      return 1
    fi
  else
    # Create new file
    if ! echo "HTTP_PORT=${HTTP_PORT_OVERRIDE}" > "${tmp}"; then
      err "Failed to create .env file"
      rm -f "${tmp}" 2>/dev/null
      trap - EXIT INT TERM
      return 1
    fi

    if ! mv "${tmp}" "${env_file}"; then
      err "Failed to write .env file"
      rm -f "${tmp}" 2>/dev/null
      trap - EXIT INT TERM
      return 1
    fi
  fi

  # Ensure secure permissions (in case file existed with wrong perms)
  chmod 600 "${env_file}" 2>/dev/null || warn "Could not set .env permissions to 600"

  trap - EXIT INT TERM
  ok "HTTP_PORT set to ${HTTP_PORT_OVERRIDE}"
  record_summary "HTTP port: ${HTTP_PORT_OVERRIDE}"
}

run_integration_and_start() {
  if [[ "${NO_START}" -eq 1 ]]; then
    warn "--no-start specified; skipping integration/start"
    return 0
  fi
  info "Running auto-detect integration and starting server"
  (
    cd "${REPO_DIR}"
    # shellcheck disable=SC1091
    source .venv/bin/activate
    export INTEGRATION_BEARER_TOKEN="${INTEGRATION_TOKEN}"
    args=()
    if [[ "${YES}" -eq 1 ]]; then args+=("--yes"); fi
    if [[ -n "${PROJECT_DIR}" ]]; then args+=("--project-dir" "${PROJECT_DIR}"); fi
    bash scripts/automatically_detect_all_installed_coding_agents_and_install_mcp_agent_mail_in_all.sh "${args[@]}"
  )
}

ensure_beads() {
  if [[ "${SKIP_BEADS}" -eq 1 ]]; then
    warn "--skip-beads specified; not installing Beads CLI"
    record_summary "Beads CLI: skipped (--skip-beads)"
    return 0
  fi

  local bd_path
  if bd_path=$(find_bd_binary); then
    verify_bd_binary "${bd_path}" || exit 1
    ensure_bd_path_ready "${bd_path}"
    record_summary "Beads CLI: ${LAST_BD_VERSION}"
    return 0
  fi

  info "Installing Beads (bd) CLI"
  if ! need_cmd curl; then
    err "curl is required to install Beads automatically"
    exit 1
  fi

  if ! curl -fsSL "${BEADS_INSTALL_URL}" | bash; then
    err "Failed to install Beads automatically. You can install manually via: curl -fsSL ${BEADS_INSTALL_URL} | bash"
    exit 1
  fi

  hash -r 2>/dev/null || true

  if bd_path=$(find_bd_binary); then
    verify_bd_binary "${bd_path}" || exit 1
    ensure_bd_path_ready "${bd_path}"
    record_summary "Beads CLI: ${LAST_BD_VERSION}"
    return 0
  fi

  err "Beads installer finished but 'bd' was not detected. Ensure its install directory is on PATH or rerun with --skip-beads to handle installation manually."
  exit 1
}

offer_doc_blurbs() {
  if [[ "${YES}" -eq 1 ]]; then
    info "Docs helper available anytime via: uv run python -m mcp_agent_mail.cli docs insert-blurbs"
    return 0
  fi

  echo
  echo "Would you like to automatically detect your code projects and insert the relevant blurbs for Agent Mail into your AGENTS.md and CLAUDE.md files?"
  echo "You will be able to confirm for each detected project if you want to do that. Otherwise, just skip that, but be sure to add the blurbs yourself manually for the system to work properly."
  read -r -p "[y/N] " doc_choice
  doc_choice=$(printf '%s' "${doc_choice}" | tr -d '[:space:]')
  case "${doc_choice}" in
    y|Y)
      (
        cd "${REPO_DIR}" && uv run python -m mcp_agent_mail.cli docs insert-blurbs
      ) || warn "Docs helper encountered an issue. You can rerun it later with: uv run python -m mcp_agent_mail.cli docs insert-blurbs"
      ;;
    *)
      info "Skipping automatic doc updates; remember to add the blurbs manually."
      ;;
  esac
}

main() {
  if [[ "${START_ONLY}" -eq 1 ]]; then
    info "--start-only specified: skipping clone/setup; starting integration"
    REPO_DIR="$PWD"
    record_summary "Repo: existing at ${REPO_DIR} (--start-only)"
    ensure_beads
    configure_port
    if ! run_integration_and_start; then
      err "Integration failed; aborting."
      exit 1
    fi
    record_summary "Integration: auto-detect + server start"
    print_summary
    offer_doc_blurbs
    exit 0
  fi

  ensure_uv
  ensure_beads
  ensure_repo
  ensure_python_and_venv
  sync_deps
  configure_port
  if ! run_integration_and_start; then
    err "Integration failed; aborting."
    exit 1
  fi
  record_summary "Integration: auto-detect + server start"
  print_summary
  offer_doc_blurbs

  echo
  ok "All set!"
  echo ""
  echo "Next runs:"
  echo "  cd \"${REPO_DIR}\""
  echo "  source .venv/bin/activate"
  echo "  bash scripts/run_server_with_token.sh"
  echo ""
  info "Slack Integration (optional):"
  echo ""
  echo "  For bidirectional Slack sync, run the interactive setup script:"
  echo ""
  echo "    bash scripts/setup_slack_bot.sh"
  echo ""
  echo "  This script will:"
  echo "    - Generate a one-click Slack app creation URL"
  echo "    - Guide you through OAuth & Event Subscriptions setup"
  echo "    - Securely save credentials to ~/.mcp_mail/credentials.json"
  echo "    - Test your Slack connection"
  echo ""
  echo "  Or configure manually in ~/.mcp_mail/credentials.json:"
  echo ""
  echo "    mkdir -p ~/.mcp_mail"
  echo "    cat > ~/.mcp_mail/credentials.json <<'EOF'"
  echo "    {"
  echo "      \"SLACK_ENABLED\": \"true\","
  echo "      \"SLACK_BOT_TOKEN\": \"xoxb-your-bot-token\","
  echo "      \"SLACK_SIGNING_SECRET\": \"your-signing-secret\","
  echo "      \"SLACK_DEFAULT_CHANNEL\": \"C0YOUR_CHANNEL_ID\","
  echo "      \"SLACK_SYNC_ENABLED\": \"true\""
  echo "    }"
  echo "    EOF"
  echo "    chmod 600 ~/.mcp_mail/credentials.json"
  echo ""
  echo "  For local development, expose your server with:"
  echo "    - Cloudflare Tunnel: cloudflared tunnel --url http://localhost:8765"
  echo "    - Or Tunnelmole: npm i -g tunnelmole && tmole 8765"
  echo ""
  echo "  Full docs: README.md (Slack Integration section) or SLACK_BIDIRECTIONAL_SYNC.md"
}

main "$@"
