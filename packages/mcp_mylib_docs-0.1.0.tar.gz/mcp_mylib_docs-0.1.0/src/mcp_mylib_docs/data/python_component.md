如何着手“写”一个参数化模型，就好像我们写议论文一样，要提出论点，给出论据最后总结归纳一样。写模型的时候也有相应的“结构”。<br />
一个完整的参数化组件的代码分为三部分。<br />
首先来看第一部分<br />
    <br />
<center><img src="/uploads/python/images/image11.png" alt="" width="800"><br /></center>
第一部分只包括第一行<br />

    from pyp3d import *

这一行的含义是引用“`pyp3d`”这个库。<br />
Python有很多“库”，不论是第一方还是第三方。库可以理解为工具箱，函数可以理解为工具。一开始引用库就是为了使用库（工具箱）中的各种函数（工具）<br />
第二部分从第二行开始，第二部分主要分为前半部分的参数定义和后半部分的模型造型。<br />
首先我们用class，类的方式来定义参数和模型造型。这里我们给我们要定义的模型（类）起个中文名叫立方体，后面的括弧和component不动。<br />
我们用细线红框给大家标注了出来第二部分里哪些是需要我们修改的，其他部分我们不要动，照抄就可以了。<br />
    <br />
<center><img src="/uploads/python/images/image12.png" alt="" width="800"><br /></center>

定义部分，从`def`开始，`def`这一行和它下面的一行不用动。案例中我们需要自己写的部分是第五行开始。案例中第五行到第七行，是在自定义参数名称和参数默认值。`self[‘’]`中的字符串就是参数名。`Attr`中的数值就是该参数的默认数值，`obvious`和`readonly`是两个Tag，分别表示该参数的显隐性和只读性。这两个tag的默认值都是false。<br />
`obvious = True` 参数可见，`obvious = False`或不输入该tag时，参数不可见。`readonly = True`时，参数只读，不可修改，`readonly = False`和不输入时，参数可修改。排列组合一下<br />
第八行，我们要把我们的模型也作为一个 “特殊参数” 定义一下。这里注意，参数不需要修改，保持`None`和`show = True`。这里的`None`相当于占了一个【空位】，这个空位是为我们的模型预留的。<br />
当`show = False`或不输入show这个tag时，将不显示该“特殊参数”所对应的模型<br />
第9-11的内容不动。<br />
从第11行`def replace(self)`开始是第二部分的后半部分。也就是造型模型的部分。<br />
注意，最终的模型必须要赋值给我们定义的那个“特殊参数”。也就是我们之前预先占了【空位】的那个参数<br />
    <br />
<center><img src="/uploads/python/images/image13.png" alt="" width="800"><br /></center>
第19行开始，是在实现模型的布置。

20行中的`Final Geometry`必须指向第二部分的class，这是对模型的一个修饰过程，为的是能够使旋转布置、两点布置等功能正常使用，因此不可省略。
第21行作用是布置模型。20、21行中的`FinalGeometry`可以换成任何一个未出现过的变量名，但须保持一致<br />
    <br />
<center><img src="/uploads/python/images/image14.png" alt="" width="800"><br /></center>
    <br />
    <br />参数化组件2.0中<br />
## 2.2 主要函数：Arc<br />
基本体包括点（`Point`）、线（`Line`）、截面（`Section`）、圆弧（`Arc`）、立方体（`Cube`）、放样（`Loft`）、扫掠（`Sweep`）、球（`Sphere`）（球暂不支持三轴放大）等<br />
旋转、平移、缩放以及放置<br />
线性排布等<br />
## 2.2.1 圆弧线：Arc<br />
函数： Arc（角度）<br />
#### 示例：<br />
```python
from pyp3d import *
# 定义参数化模型
class 弧(Component):
    # 定义各个参数及其默认值
    def __init__(self):
        Component.__init__(self)
        # obvious 属性的可见性 True时可见，False为不可见。默认为False
        # readonly 属性的只读性 True时不可调，为置灰状态，False为可调状态。默认为False
        self['a轴长度'] = Attr(1000.0, obvious=True, readonly = False)
        self['b轴长度'] = Attr(300.0, obvious=True)
        self['弧'] = Attr(None, show=True)
        self['旋转角度'] = Attr(0,obvious = True)
        self['X'] = Attr(300.0, obvious=True)
        self['Y'] = Attr(300.0, obvious=True)
        self['Z'] = Attr(300.0, obvious=True)
        self.replace()
    @export
    # 开始写模型
    def replace(self):
        # 在 def relpace(self)中，凡是self['']形式的变量，都会参与输出与绘制。
        # 因此，请不要随便使用self['']来作为变量名，尽量在最终输出模型时以该形式作为变量名
        # 设置变量，同时调用参数(简化书写过程)
        L = self['a轴长度']
        W = self['b轴长度']
        x = self['X']
        y = self['Y']
        z = self['Z']
        Angle = self['旋转角度']
        # 绘制模型
        self['弧'] = translate(x,y,z) * rotation(math.pi/180 * Angle) * scale(L,W) * Arc(math.pi*2)
# 输出模型
if __name__ == "__main__":
	FinalGeometry = 弧()
    place(FinalGeometry)

```
<center>
<p>
代码2.2-1 圆弧线示例
</p>
</center>

<center><img src="/uploads/python/images/image16.png" alt="" width="800"><br /></center>
    <br />
示例中所包含的函数：<br />


|Arc|圆弧线函数 |color|颜色参数|
|-----|-----|-----|-----|



<br />
示例中，第一行为引用pyp3d工具包，每个脚本的开头都应当引用所需使用的工具包。（后文中所有示例中默认首行已引用pyp3d）<br />
Arc创建的是单位圆弧（半径为单位1的圆弧）。Arc只需要填写角度，即可创建一个单位圆弧。如Arc(pi*2)，即为创建一个单位圆。示例中填写的角度值为1.5,则会创建一个半径为1的3/4个圆弧。<br />
Arc的默认绘制起点为X轴上，即圆心为（0，0，0），起点为（1，0，0），绘制方向为逆时针绘制，遵循右手定则。<br />

### 右手定则：<br />
右手食指到小指四指握拳，大拇指伸出（“点赞”造型）。大拇指指向为旋转轴指向，四指握拳方向为旋转的正方向。即当右手握拳放于桌面上是，大拇指朝上，此时拇指指向为Z轴正方向，桌面为XY平面，旋转方向为逆时针。<br />

### 三点画弧：<br />
Arc函数可以实现三点画弧功能。只需要将原有的角度值改为三个点即可。这三个点分别为弧线的起点，弧线中任意一点和弧线终点即可。<br />
#### 示例：<br />
```python
from pyp3d import *
# 圆弧线-三点画弧
# 函数名 Arc
# 参数：圆弧角度（弧度制） 
# 定义参数化模型
class 弧(Component):
    # 定义各个参数及其默认值
    def __init__(self):
        Component.__init__(self)
        self['弧'] = Attr(None, show=True)
        self.replace()
    @export
    # 开始写模型
    def replace(self):
        # 绘制模型
        self['弧'] = Arc(Vec3(0,0,0), Vec3(100,100,0), Vec3(0,200,0)).color(1,0,0,1)
# 输出模型
if __name__ == "__main__":
	FinalGeometry = 弧()
    place(FinalGeometry)
```
<center>
<p>
代码2.2-2
</p>
</center>


### color函数：<br />
`color`函数包括了颜色和不透明度。`color`中的四组数字分别代表R（红），G（绿），B（蓝）和不透明度。其中R，G，B的取值范围是0到1（对应0到255），不透明度的取值是0到1，数字越大，不透明度越高（透明度越低），当不透明度为0时，构件会在P3D的光照下呈白色和灰色。当不输入颜色时，输出默认颜色，为白色不透明。<br />

### place函数：<br />
place函数为放置纯几何体，即需要在BIMBase中手动使用鼠标左键选择布置位置。<br />
通常，非参数化建模过程中，只需要使用`create_geometry`和`place`中的一个即可，不需要同时使用这两个函数。<br />


## 2.2.2 立方体：Cube<br />
Cube中同样不需要填充任何参数，它本身是创建一个棱长为1的单位立方体。<br />
#### 示例：<br />
```python
from pyp3d import *
class 立方体(Component):
    def __init__(self):
        Component.__init__(self)
        self['长'] = Attr(1000.0, obvious=True)
        self['宽'] = Attr(1000.0, obvious=True)
        self['高'] = Attr(1000, obvious = True)
        self['立方体'] = Attr(None, show=True)
        self['旋转角度'] = Attr(0,obvious = True)
        self['X'] = Attr(0.0, obvious=True)
        self['Y'] = Attr(0.0, obvious=True)
        self['Z'] = Attr(0.0, obvious=True)
        self.replace()
	@export
    def replace(self):
        L = self['长']
        W = self['宽']
        H = self['高']
        x = self['X']
        y = self['Y']
        z = self['Z']
        Angle = self['旋转角度']
        TestCube = translate(x,y,z) * rotation(math.pi/180 * Angle) * scale(L,W,H) * Cube()
        self['立方体'] = TestCube
if __name__ == "__main__":
    FinalGeometry =立方体()
    place(FinalGeometry)
```
<center>
<p>
代码2.2-3 立方体示例
</p>
</center>


## 2.2.3 缩放函数：Scale<br />
如果想要创建一个非单位大小的圆弧、立方体等，可以利用`scale`函数来实现。<br />
`Scale`函数可以装填不同的参数。`Scale`和要被作用的几何体用乘号相连，乘号表示作用于。用法为`Scale * 变量名`<br />
#### 示例1：<br />
整体缩放：只装填一个数字a。此时会将被作用的变量（几何体）沿着x,y,z方向同时扩大为原来的a倍。适用全部几何体。<br />
```python
testArc = scale(100) * Arc(pi*1.5).color(1,0,0,1)
```
<center><img src="/uploads/python/images/image22.png" alt="" width="673"><br />
图2.1.2-1 放大100倍前后对比<br /></center>

#### 示例2：<br />
平面缩放：在scale中输入两个数值a、b，此时会将被作用的几何体沿X轴方向扩大为原来的a倍、沿Y轴方向扩大为原来的b倍。该方法适用于二维几何体，如Arc、Line等。<br />
```python
testArc = scale(100,50) * Arc(pi*1.5).color(1,0,0,1)
```
<center><img src="/uploads/python/images/image24.png" alt="" width="800"><br />
图2.1.3-1 放大（100，50）倍前后对比<br /></center>

#### 示例3：<br />
三轴缩放：输入三组数字a、b、c，此时会将被作用的几何体沿xyz轴分别扩大a、b、c倍。（注：球体暂不支持三轴不同数值缩放）<br />
```python
testcube = scale(500,200,400) * Cube()
```
<center><img src="/uploads/python/images/image26.png" alt="" width="566"><br />
图2.1.3-2<br /></center>
<br />

## 2.2.4 线：Line<br />
线，可以是纯二维平面的线，也可以是三维空间内的线。<br />
纯二维平面的线输入的坐标为Vec2，表示二维平面矢量（二维平面坐标），只需要输入XY值。<br />
三维的线输入的坐标为Vec3，表示三维空间矢量（三维坐标），需要输入XYZ的值。<br />
注意，`Vec3`和`Vec2`不能混用。<br />
#### 示例：<br />
```python
testLine3D = Line(Vec3(0,0,0),Vec3(100,0,25),Vec3(0,100,50),Vec3(100,100,75)).color(1,0,0,1)
testLine2D = Line(Vec2(0,0),Vec2(100,0),Vec2(0,100),Vec2(100,100)).color(0,0,1,1)
```

<center><img src="/uploads/python/images/image28.png" alt="" width="646"><br />
图2.1.4-1 图中蓝色为二维线，红色为三维线<br /></center>
同样，Line也支持缩放函数。<br />
```python
testLine3D = Line(Vec3(0,0,0),Vec3(100,0,25),Vec3(0,100,50),Vec3(100,100,75)).color(1,0,0,1)
testLine3D = scale(10,1,1)*testLine3D
```

<center><img src="/uploads/python/images/image30.png" alt="" width="800"><br />
图2.1.4-2<br /></center>
<br />

## 2.2.5 截面 Section<br />
`Section`可以装填`Vec2`（作为点）,`Line`,`Arc`等, 不可传入`Vec3`。会依次连接传入的点、线、弧等二维几何体。装填的`Line`中不得出现`Vec3`。<br />
注意，弧线会自动补全为所在平面变成弓形。<br />
#### 示例：<br />
```python
testsection = Section(Vec2(100, -100),scale(100) * Arc(0.5*pi),  Vec2(-100,100), Vec2(-100, -100))
```
<center><img src="/uploads/python/images/image32.png" alt="" width="574"><br />

图2.1.5-1<br /></center>
<br />

## 2.2.6 扫掠体 Sweep <br />
扫掠体函数<br />
#### 示例1：<br />
```python
# 描述截面
testsection = Section(Vec3(100,-100,0), scale(100) * Arc(0.5*pi), Vec3(-100,100,0), Vec3(-100,-100,0))
# 描述轨迹
testline = Line(Vec3(0,0,0), Vec3(500,500,500))
# 扫略
testsweep = Sweep(testsection, testline)
```
<center><img src="/uploads/python/images/image34.png" alt="" width="499"><br />
图2.1.6-1<br /></center>
`Sweep`中需要装填截面和截面路径两个参数<br />
其中，如上文所讲，截面可以装填点（`Vec3`），线（`Line`）和弧（`Arc`）。<br />
界面路径，也是扫掠轨迹，可以装填线（`Line`）和弧（`Arc`）。<br />

#### **示例2**：<br />
from pyp3d import *

class 圆角柱体(Component):
    def __init__(self):
        Component.__init__(self)
        self['半径'] = Attr(500.0, obvious=True, readonly=False)
        self['高度'] = Attr(2000.0, obvious=True, readonly=False)
        self['圆角半径'] = Attr(100.0, obvious=True, readonly=False)
        self['圆角柱体'] = Attr(None, show=True)
        self['旋转角度'] = Attr(0, obvious=True)
        self['X'] = Attr(0.0, obvious=True)
        self['Y'] = Attr(0.0, obvious=True)
        self['Z'] = Attr(0.0, obvious=True)
        self.replace()
    
    @export
    def replace(self):
        R = self['半径']
        H = self['高度']
        r = self['圆角半径']
        x = self['X']
        y = self['Y']
        z = self['Z']
        Angle = self['旋转角度']
        
        arc1 = translate(R-r, r, 0) * scale(r) * Arc(-0.5*math.pi)
        arc2 = translate(R-r, H-r, 0) * scale(r) * Arc(0.5*math.pi)
        
        section = Section(
            Vec2(0, 0),
            Vec2(R-r, 0),
            arc1,
            Vec2(R, r),
            Vec2(R, H-r),
            arc2,
            Vec2(R-r, H),
            Vec2(0, H)
        )
        
        section_rotated = rotate(Vec3(1, 0, 0), -0.5*math.pi) * section
        
        line_path = Line(Arc(2*pi))
        
        rounded_cylinder = Sweep(section_rotated, line_path)
        
        self['圆角柱体'] = translate(x, y, z) * rotation(math.pi/180 * Angle) * rounded_cylinder

if __name__ == "__main__":
    FinalGeometry = 圆角柱体()
    place(FinalGeometry)


<center><img src="/uploads/python/images/image36.png" alt="" width="796"><br />
图2.1.6-2<br /></center>
需要注意，`Sweep`中装填的`Line`，只能为一段圆弧和一个两点组成的直线段，不能装填多段线，不能装填线、弧结合的`Line`。<br />
同时，装填`Arc`时，仅表示截面的旋转角度，不表示截面运动的弧线轨迹。因此请先将截面根据半径移动后，再进行`Sweep`。<br />

<br />

## 2.2.7 放样体 Loft<br />
在放样体中，需要放入多个截面`Section`（至少放入两个），且截面需要保证线和弧线要在数量和位置上均保持对应关系。<br />

#### 示例1：<br />


		# 描述截面
		testarc = Section(scale(100,100)*Arc(2*pi))
		# 放样
		testloft_arc = Loft(testarc, scale(0.5)*translate(0,0,100) * testarc, 			rotation(0.5*pi)*translate(0,0,300)*scale(0.5) * testarc)


<center><img src="/uploads/python/images/image38.png" alt="" width="590"><br />
图2.1.7-1<br /></center>

#### 示例2：<br />

		# 描述截面
		section = Section(Vec2(100,-100), scale(100) * Arc(0.5*pi), Vec2(-100,100), Vec2(-100,-100))
		# 放样
		testloft = Loft(section, scale(0.5)*translate(0,0,100) * section, rotation(0.5*pi)*translate(40,0,300) * section)


<center><img src="/uploads/python/images/image40.png" alt="" width="611"><br />
图2.1.7-2<br /></center>
`Loft`函数中，可以装填多个截面，`Loft`会根据装填顺序依次将这多个截面连接扫掠，形成一个完整的几何体。<br />
再次强调，需要注意的是截面在装填时需要保持弧对弧，线对线，点对点。即如果有一个截面是有弧线的，那其他的截面也需要对应的有弧线。<br />
不可以出现平面A、B中线、点、弧的数量不一致的情况。<br />
不可出现平面A中有弧线，平面B中无弧线等类似情况。<br />
可以将平面A旋转、缩放、平移后得到平面B。<br />

<br />

## 2.2.8 球 Sphere<br />
球只能三轴同时放大，因此可以有两种缩放的装填形式。球暂时不支持三轴不等长放大。<br />
示例：<br />

		testsphere = scale(200,200,200) * Sphere()
		testsphere = scale(200) * Sphere()

<center><img src="/uploads/python/images/image42.png" alt="" width="417"><br />
图2.1.8-1<br /></center>

    
<br />

## 2.2.9  圆柱体 Cone<br />
函数：`Cone(centerA, centerB, radiusA, radiusB)`<br />
表2.3.2 圆锥/圆台函数的参数和含义<br />

|参数名称|参数含义|参数名称|参数含义|
|-----|-----|-----|-----|
|centerA|底面A的圆心坐标|centerB|底面B的圆心坐标|
|radiusA|底面A的半径|radiusB|底面B的半径|


#### 示例：<br />
		Testcone = Cone(Vec3(10000,0,0),Vec3(10000,0,2000),1000,1000).color(1,0,0,0.3)
其含义为创建一个圆锥/圆台，变量名为`Cone1`，且当底面A、B半径一致时，生成圆柱。该圆柱底面坐标原点为（0,0,0），顶面原点为（0,0,2000）。底面半径分别为1000mm，1000mm，高度则是由底面A、B原点z方向的高度差确定的2000mm。<br />

<center><img src="/uploads/python/images/image44.jpeg" alt="" width="460"><br /></center>
<center><img src="/uploads/python/images/image45.jpeg" alt="" width="481"><br /></center>
<br />
圆锥台的轴心是由底面A、B的坐标确定的，因此理论上可以生成任意方向上的圆锥台。<br />
    
<br />

## 2.2.10 四棱台 Box<br />
函数：`Box(baseOrigin, topOrigin, vectorX, vectorY, baseX, baseY, topX, topY)`<br />
四棱台函数的参数及含义<br />

|参数名称|参数含义|参数名称|参数含义|
|-----|-----|-----|-----|
|baseOrigin|底部原点|topOrigin|顶部原点|
|vectorX|局部坐标系基矢|vectorY|局部坐标系基矢|
|baseX|局部坐标系下底部x方向的长度|baseY|在局部坐标系下底部y方向的长度|
|topX|在局部坐标系下顶部x方向的长度|topY|在局部坐标系下顶部y方向的长度|
|color|颜色&不透明度。前三位为颜色，第四位为不透明度。|

#### 示例：<br />

		Textbox = Box(Vec3(0,0,0), Vec3(0,0,3000), Vec3(1,0,0), Vec3(0,1,0), 3000, 5000, 3000, 5000).color(1,1,0,0.5) 
该四棱台底面坐标原点为（0，0，0），顶面原点为（0，0，3000）。其局部坐标的基准平面是由向量（1，0，0）和向量（0，1，0）所组成的XY平面。底面长宽分别为3000mm，5000mm，顶面长宽分别为3000mm，5000mm，高度则是由顶面底面原点z方向的高度差确定的2000mm<br />

<center><img src="/uploads/python/images/image47.jpeg" alt="" width="651"><br /></center>
    
<br />

## 2.2.11 圆角管 FilletPipe<br />
函数： ` FilletPipe(points, filletRadius, pipeRadius):`<br />
表2.4.1 圆角管函数的参数及含义<br />

|参数名称|参数含义|参数名称|参数含义|
|-----|-----|-----|-----|
|points|控制点/拐点|filletRadius|弯折半径|
|pipeRadius|管半径|||

控制点（拐点）和弯折半径是两个列表，需要用方括号将拐点和弯折半径括起来。<br />
弯折半径的数量必须与控制点数量一致。弯折半径列表中的第一个和最后一个元素填写0。其他位置的弯折半径必须大于管半径，否则在布尔等操作时会无法正常进行。<br />
#### 示例：<br />

		a1 = FilletPipe([Vec3(0,0,0),Vec3(10000,0,0),Vec3(10000,0,5000),Vec3(20000,0,0)], [0,500,500,0], 200).color(1,1,0,1)
在本示例中，一共有四个控制点，管弯曲的时候，其曲率半径均为50mm（注意，起点和终点对应的管半径filletRadius直接填写为0）。管本身的半径为20mm。其实际模型如下图所示：<br />

<center><img src="/uploads/python/images/image49.png" alt="" width="800"><br /></center>

## 2.2.12 样条线 待更新<br />
    SplineCurve(ctrlPoints=[], discNum=0, orderK=2, splineType='quasi')<br />
控制点列表 离散数量 方程最高阶数 样条线类型<br />

<br />    



## 2.3.1 旋转 rotate<br />
`rotate`必须作用于某个几何体上，不能单独使用。<br />
`rotate`有两种参数装填形式。<br />

- 放入空间矢量`Vec3` 作为旋转轴轴向，再放入角度作为旋转角。<br />
- 直接输入角度，此时默认旋转轴轴向为Z轴正方向。<br />

旋转时，符合右手定则。即右手除大拇指外的四指握拳，大拇指向外伸出（点赞姿势）。此时让大拇指指向，与代表旋转轴轴向的空间矢量Vec3，保持一致，这时，四指弯曲的方向即为旋转的正方向。<br />
举例：俯视图下，如果旋转轴为（0，0，1），即z轴正方向，则此时旋转的正方向为逆时针。此时输入一个角度的正值，则会逆时针旋转；输入负值，则会顺时针旋转。<br />
#### 示例：<br />
```python
		testcube = scale(500,200,400) * Cube()
		rotatecube = rotate(pi/2) * scale(500,200,400) * Cube()
```
<img src="/uploads/python/images/image51.png" alt="" width="768"><br />
图2.2.1-1</center>
<br />

## 2.3.2 平移 translate<br />
`Translate`和`rotate`一样，必须作用与某个几何体上。<br />
#### 示例：<br />
```python
testcube = translate(Vec3(100,100,100)) * scale(500,200,400) * Cube()
testcube = translate(100,100,100) * scale(500,200,400) * Cube()
testcube = translate(100,100) * scale(500,200,400) * Cube()
```
`translate`有三种参数装填形式。<br />

- 放入空间矢量`Vec3`作为平移矢量<br />
- 直接输入三维空间数值，同样可以识别为平移矢量<br />
- 输入二维空间数值，可以识别为二维的平移矢量，此时被作用的几何体只会在XY平面上进行平移（即只会水平移动）<br />

## 2.3.3 旋转、平移的其他形式<br />
在使用BIMBase KIT 2022 R2.2及以上版本软件时，旋转、平移可以使用本节所讲解的各种函数<br />

### 绕X、Y、Z轴进行旋转<br />
当我们需要将一个几何体绕X、Y或Z轴进行旋转时，我们可以使用`rotx(theta)`,`roty(theta)`和`rotz(theta)`这三个函数。这三个函数所需要状态的数值`theta`是角度值（弧度制），即如果需要绕X轴正半轴，按照正方向旋转90°时，应当写为`rotx(pi/2)`<br />
#### 示例：<br />

		testcube = scale(500,200,400) * Cube()
		rotatecube = rotx(pi/2) * scale(500,200,400) * Cube()

### 平移函数的简略形式<br />
原本的平移函数为`translate`，名称较长，在使用新版软件时，可以将`translate`简写成`trans`。<br />
#### 示例：<br />

		testcube = trans (Vec3(100,100,100)) * scale(500,200,400) * Cube()
		testcube = trans (100,100,100) * scale(500,200,400) * Cube()
		testcube = trans (100,100) * scale(500,200,400) * Cube()

注意，章节2.3.3中所涉及的函数，需要在BIMBase KIT 2022 R2.2及之后版本中可使用，旧版程序不支持上述函数。<br />

## 2.3.4 就近原则<br />
当旋转和平移同时需要作用在同一个几何体上时，他们的作用效果是有先后顺序的。写代码时，哪个离几何体近，哪个就优先生效。由于几何体放置在当前代码行最右侧，因此最右侧的旋转平移会先生效，最左侧，也就是距离等号最近的旋转平移会最后生效。<br />
#### 示例：<br />
		# 先缩放，然后平移，最后旋转
		cube = rotate(Vec3(0,0,1), pi/2) * translate(100,100) * scale(500,200,400) * Cube()
		# 先缩放，然后旋转，最后平移
		cube = translate(100,100) * rotate(Vec3(0,0,1), pi/2) * scale(500,200,400) * Cube()

当缩放遇到旋转平移，请将缩放放到第一步，然后再进行旋转平移。<br />

## 2.3.5 镜像 mirror<br />
`Mirror`镜像操作，同上述两种方法一样，需作用于某个几何体上。镜像操作需要一个辅助的镜像平面，所以镜像的输入有所不同。<br />
镜像平面使用一个坐标系的坐标面来表示，所以镜像函数需要填入两个参数，一是自制临时的镜面坐标系，二是镜面坐标系的坐标平面名称。<br />
镜面坐标系，是通过平移旋转原坐标系而新建产生。输入对原坐标系的平移或旋转操作，而不后接星号不作用于任意模型，就可表示一个任意镜面坐标系（例：`trans(300,0,0) * rotz(pi)`表示了原坐标系按z轴旋转180°并沿X轴平移300的镜面坐标系，如图）。<br />
<center>
<img src="/uploads/python/images/image56.png" alt="" width="729"><br />
</center>
经过此操作而得的一个镜面坐标系的任意一个坐标面，都可以作为镜像平面进行镜像操作。默认以镜面坐标系的YOZ平面进行镜像。可以选取镜面坐标系三个坐标面的任意一个，仅需在`Mirror`函数内以字符串形式输入所需面的名称即可。（例：'XY'）<br />
镜面坐标系仅为辅助用，并不显示在窗口。如需显示，可使用函数`show_coordinate_system()`。该函数可将置入的坐标系可视化，方便建模及理解。需区分，有字母标识且无箭头的是软件显示界面的全局坐标系，无字母有箭头的为可视化的镜面坐标系。红轴为X，绿轴为Y,蓝轴为Z。坐标系显示尺寸可用`scale()`更改。<br />

#### 示例：

		Model = trans(400,0,0) * scale(500,200,400) * Cube()
		MirrorModel = mirror(trans(0,0,0) * rotz(pi/4)) * Model
		show_coordinate_system(scale(5) * trans(0,0,0) * rotz(pi/4))

<center>
<img src="/uploads/python/images/image58.png" alt="" width="565"><br />
</center>
以镜面坐标系XOY平面做镜像示例：<br />

		Model = trans(400,0,0) * scale(500,200,400) * Cube()
		MirrorModel = mirror(trans(0,0,0) * rotz(-pi/4),'XY') * Model
		show_coordinate_system(scale(5) * trans(0,0,0) * rotz(-pi/4))

<center>
<img src="/uploads/python/images/image60.png" alt="" width="529"><br />
</center>

## 2.4 线性排布 linspace<br />
函数：` Linspace(a,b,n)`<br />
`Linspace`需要装填三个参数。a、b可以同时为空间矢量，也可以同时为数值。<br />
当a、b是空间矢量（`Vec3`）时，表示为空间里线段的起点和终点。<br />
当a、b是数值（浮点型或整型）时，表示为单位1为半径的圆弧的起点和终点角度值（弧度制）。<br />
n则表示要将这段直线（或者半径为单位1的圆弧）分成n-1份。因此，会在a、b两点直接生成n个点（含a、b两点）。<br />
#### 示例1：<br />

		# 创建立方体
		test_cube = scale(50) * Cube()
		# 转为Array
		Test_Array = Array(test_cube)
		# 线性排布
		for i in linspace(Vec3(0,0,0),Vec3(1000,0,0),10):  # 生成11个点
		# 将Test_Array依次平移并添加到这十一个点上，并存于Test_Array中
		Test_Array.append(translate(i)) 

<center>
<img src="/uploads/python/images/image62.png" alt="" width="499"><br />
图2.3.1-1<br />
</center>

#### 示例2：<br />
		# 创建立方体
		test_cube = scale(50) * Cube()
		# 转为Array
		Test_Array = Array(test_cube)
		# 线性排布
		# 设置半径
		R = 200
		for i in linspace(0,pi*2 *11/12,12):  # 在0到330°之间，生成12个角度值
		# 这里将单位圆生成的12个点转化为了半径为R的圆上的12个点
		# 然后将Test_Array依次平移并添加到这12个点上，并存于Test_Array中。
		Test_Array.append(translate(Vec3(R*cos(i),R*sin(i),0)))
		# 布置线性排布后的Test_Array

<center>
<img src="/uploads/python/images/image64.png" alt="" width="282"><br />
图2.3.1-2<br />
</center>
可能有同学会好奇，为什么不是0°到360°上生成12个点、或者是0°到360°上生成13个点，这里可以自行思考并尝试一下，就会发现问题所在啦。<br />

## 2.5 布尔与组合
布尔主要包括两种操作，分别是`Fusion`（布尔并和布尔减）和`Intersectio`n（布尔交），在布尔时，参与布尔的几何体会被抹除原有的颜色信息。因此需要重新设置颜色。<br />
## 2.5.1 布尔并与布尔减<br />
在新版的参数化组件中，布尔并与布尔减可以用加号“+”和减号“-”来表示。<br />
注意，新版的布尔并与布尔减有新的规则，但对之前的方式仍然完全兼容。<br />
### 布尔并<br />
#### 示例：<br />

		# 融合（布尔并与布尔减）
		testa = translation(100,100,0) * scale(1000,300,500) * Cube().color(1,0,0,1)
		testb = translation(0,0,0) * scale(1000,300,500) * Cube().color(0,1,0,1)
		testFusion = testa+testb


<center>
<img src="/uploads/python/images/image66.png" alt="" width="462"><br />
图2.4.1-2<br />
</center>
<br />

### 布尔减<br />
#### 示例：<br />

		# 融合（布尔并与布尔减）
		testa = translation(100,100,0) * scale(1000,300,500) * Cube().color(1,0,0,1)
		testb = translation(0,0,0) * scale(1000,300,500) * Cube().color(0,1,0,1)
		testFusion = testa-testb

<center>
<img src="/uploads/python/images/image68.png" alt="" width="506"><br />
图2.4.1-3<br />
</center>
<br />

## 2.5.2 布尔交<br />
函数：`Intersect`<br />
`Intersect`中可以装填多个几何体，最终生成所有几何体的“交集”。<br />

		testa = translation(100,100,0) * scale(1000,300,500) * Cube().color(1,0,0,1)
		testb = translation(0,0,0) * scale(1000,300,500) * Cube().color(0,1,0,1)
		testFusion = Intersect(testa,testb)


<center>
<img src="/uploads/python/images/image70.png" alt="" width="444"><br />
图2.4.2-1<br />
</center>
<br />

## 2.5.3 组合 Combine<br />
组合不同于布尔，组合时并不会将两个几何体重叠的部分进行处理，同时，颜色信息也不会被抹除。如果对组合后的模型赋予颜色，那combine中的所有几何体都会变为该颜色。<br />
#### 示例：<br />

		testa = translation(100,100,0) * scale(1000,300,500) * Cube().color(1,0,0,1)
		testb = translation(0,0,0) * scale(1000,300,500) * Cube().color(0,1,0,1)
		TestCombine = combine(testa,testb)

<center>
<img src="/uploads/python/images/image72.png" alt="" width="366"><br />
图2.4.3-1<br />
</center>

## 2.6.1 二维文字 Text<br />
Text函数，包括文字内容、文字宽度、文字高度三个参数<br />
其形式为Text('输入文字内容', 10,10)，其中，文字内容需要以字符串的形式输入，即文字前后要用英文单引号引起来。<br />
#### 示例：<br />

		texttest = Text('参数化组件', 10,10).color(255/255,255/255,255/255,1)
		cubetest = translate(Vec3(-35,-75,-1)) * scale(150,150,-1) * Cube().color(255/255,0/255,5/255,1)
		test = combine(texttest,cubetest)

<center>
<img src="/uploads/python/images/image74.png" alt="" width="612"><br />
图2.5.1-1
<br />
</center>

## 2.6.2 三维文字 TextSweep<br />
三维文字实际上是对文字Text和扫掠体Sweep两者的结合使用，将文字视作截面并传入扫掠体Sweep中，进而形成三维文字。<br />
#### 示例：<br />

		text = Text('参数化组件2.0',100,100)
		TextHight = 20
		TextHightLine = Line(Vec3(0,0,0), Vec3(0,0,TextHight))
		ThreeDText = Sweep(text,TextHightLine).color(0,0,1,1)
## 2.7 贴图
目前，参数化组件有两种贴图方式。第一种方式是使用BIMBase自带的素材库功能，对已经布置在工程文件中的模型进行选中后贴图（也可修改模型颜色）。第二种方式则是在建模过程中，直接对某个几何体进行贴图。<br />
## 2.7.1 使用材质库进行贴图<br />
我们点开【编辑】栏，找到最右侧的【材质库】，点击【材质库】，可以看到如下图所示的材质编辑器。<br />
<center>
<img src="/uploads/python/images/image77.png" alt="" width="800"><br /></center>
我们点击【材质编辑器】左下角的【加号】来新建一个新的材质，并且输入新材质的名称。<br />
<center>
<img src="/uploads/python/images/image78.png" alt="" width="750"><br /></center>
新建材质后，我们可以选择材质的颜色、透明度、高光、自发光等。通过勾选或取消勾选“贴图设置”中的“纹理贴图”来切换当前材质使用的是颜色模式还是贴图模式<br />
如果勾选了下方的“贴图设置”中的“纹理贴图”，那么此时常规参数中的颜色、透明度、高光和自发光设置将自动置灰，并且需要点击“贴图设置”中的“设置”来选择图片，同时可以选择不同的“贴图映射方式”。<br />
<center>
<img src="/uploads/python/images/image79.png" alt="" width="750"><br /></center>
例如，我们勾选了纹理贴图后，点击【设置】，点击【选择纹理】，选择一张图片，并且在这里我们可以选择贴图的方式为尺寸贴图或者比例贴图，以及可以设置贴图的偏移量，我们可以根据实际需要选择合适的方式，点击【确定】完成纹理编辑。<br />
<center>
<img src="/uploads/python/images/image80.png" alt="" width="750"><br /></center>
选择映射方式，然后我们点击一个要赋予材质（贴图）的构件，然后点击应用，再点击确定。<br />
<center>
<img src="/uploads/python/images/image81.png" alt="" width="750"><br /></center>
我们以一个长方体为例，我们选择刚刚新建的“Test”材质，这时我们应保持材质编辑器打开，然后选择Test材质，然后选中要赋予材质的长方体模型，然后点击应用。<br />
<center>
<img src="/uploads/python/images/image82.png" alt="" width="800"><br /></center>
这时，我们点击模型旁边的空白处，可以看到，刚刚的长方体已经有了贴图<br />
<center>
<img src="/uploads/python/images/image83.png" alt="" width="800"><br /></center>


## 2.7.2 Python建模时贴图<br />
这里我们需要使用到贴图函数，我们先来看一下例子（Eg.2.7.2-1）<br />

```python
from pyp3d import *
# 定义参数化模型
class 长方体(Component):
    # 定义各个参数及其默认值
    def __init__(self):
        Component.__init__(self)
        self['长'] = Attr(1000, obvious = True, combo = [500,1000,2000,3000,4000])
        self['宽'] = Attr(300.0, obvious = True)
        self['高'] = Attr(500, obvious = True)
        self['长方体'] = Attr(None, show = True)
        self.replace()
    @export
    # 模型造型
    def replace(self): 
        # 设置变量，同时调用参数(简化书写过程)
        
        L = self['长']
        W = self['宽']
        H = self['高']
        # 绘制模型
        TestCube = scale(L,W,H) * Cube()
        self['长方体'] = TestCube
        self['长方体'].material('M8')
        
# 输出模型
if __name__ == "__main__":
    mt3 = create_material('M8', mapMode = 5, mapUnit = 0, uvScale = [1,1], wRotation = 0)
    mt3.mapFile = R'C:\Users\PKPM\Pictures\BIMBase图标.png'
    FinalGeometry = 长方体()
place(FinalGeometry)

```

可以看到，我们对要某个几何体进行贴图时，需要加上`material`这个成员方法，同时，括弧内的字符串表示这个贴图的名称（name），而这个贴图的名称则是在输出模型阶段进行定义的。而这个贴图的变量名是mt3，需要用到`create_material`这个函数，这个函数的具体用法，我们来一起看一下。<br />

### create_material函数<br />
`create_material`函数的含义是创建一个材质，可以是图片（贴图）也可以是颜色，在创建材质时，就可以填入各种默认参数。<br />
`create_material`函数参数与说明表<br />

|参数|含义|参数格式|
|-----|-----|-----|
|name|材质名称（必填）|str|
|mapFile|贴图路径（贴图时必填）|str|
|mapUnit|贴图单位3 按尺寸贴图0 按比例贴图|索引|
|mapMode|贴图模式0 参数几何投影2 平面投影4 立方体投影5 球形投影6 圆柱形投影|索引|
|uvScale|贴图缩放|[float,float]|
|uvOffset|贴图偏移|[float,float]|
|wRotation|贴图旋转角度（弧度制）|float|
|Color|颜色 RGB（取值范围为0-1）|[float,float,float]Eg. [0,245/255,1]|
|transparency|透明度（取值范围0-1）|float|
|specularColor|高光颜色RGB（取值范围0-1）|[float,float,float]Eg. [0,245/255,1]|
|specularFactor|高光系数（取值范围0-1）|Float|
|glowColor|自发光颜色RGB（取值范围0-1）|[float,float,float]Eg. [0,245/255,1]|
|glowFactor|自发光系数（取值范围0-100）|int|
|ambientFactor|环境光（取值范围0-1）|float|


需要注意，在`uvScale`（贴图缩放）中，以`uvScale=[m,n]`为例。当`mapUnit`（贴图模式）为3（按尺寸贴图）时，表示将原有图片缩放为(m*1000mm)×(n*1000mm)；当`mapUnit`为0（按比例贴图）时，[m,n]表示将原图片缩放为m×n倍<br />
注意，创建材质的过程放在了输出模型的部分，也就是模型代码结构中的第三部分,请不要在建模部分创建材质。（参考例子Eg.2.7.2-1）<br />

## 3.1旋转布置
<center>
<img src="/uploads/python/images/image76.png" alt="" width="800"><br />
图2.5.2-1<br />
</center>旋转布置只需要在原脚本中的末尾部分添加一行代码，即可实现旋转布置效果。<br />

旋转布置时，第一次点击鼠标左键为选择布置原点，此时移动鼠标，组件会跟随鼠标发生转动，再次点击鼠标左键时，组件会根据点击位置绕原点旋转相应角度布置。<br />
#### 示例：<br />

```python
from pyp3d import *
class 立方体(Component):
    def __init__(self):
        Component.__init__(self)
        self['长'] = Attr(1000.0, obvious=True)
        self['宽'] = Attr(300.0, obvious=True)
        self['高'] = Attr(500, obvious = True)
        self['立方体'] = Attr(None, show=True)
        self['旋转角度'] = Attr(0,obvious = True)
        self['X'] = Attr(0.0, obvious=True)
        self['Y'] = Attr(0.0, obvious=True)
        self['Z'] = Attr(0.0, obvious=True)
        self.replace()
    @export
    def replace(self):
        L = self['长']
        W = self['宽']
        H = self['高']
        x = self['X']
        y = self['Y']
        z = self['Z']
        Angle = self['旋转角度']
        TestCube = translate(x,y,z) * rotation(math.pi/180 * Angle) * scale(L,W,H) * Cube()
        self['立方体'] = TestCube
if __name__ == "__main__":
    # 只需加上下面两行即可实现旋转布置
    # 第一行 对【立方体】这个class进行装饰
    FinalGeometry = 立方体()
    # 第二行 实现旋转布置 注意最后Place时需要填入的是装饰后的立方体
    RotationPlace.RotationFunction(FinalGeometry)
    place(FinalGeometry)

```
<center>
<img src="/uploads/python/images/image86.png" alt="" width="475"><br />
图4.1-1<br /></center>
步骤1：第一次点击左键时，会选中布置位置。<br />
<center>
<img src="/uploads/python/images/image87.png" alt="" width="800"><br />
图4.1-2<br /></center>
步骤2：此时移动鼠标，模型会跟随鼠标进行转动，再次点击鼠标左键，即可完成旋转布置。<br />
<center>
<img src="/uploads/python/images/image88.png" alt="" width="800"><br />
图4.1-3<br /></center>
此时，可以继续选择下一个要布置模型的点（回到步骤1），即可以连续布置多个需要旋转布置的模型<br />

## 3.2 两点布置
两点布置中，需要选定一个变量作为线性变量，通常选择为长、高等。<br />
要点:线性布置的构件中，要进行线性变化的变量需要放在X轴上。放置在Y轴或Z轴时，需要对几何体进行旋转。<br />
我们以长度为线性变量的长方体两点布置为例。（案例为非参数化，可自行改为参数化模型脚本）<br />
#### 示例：<br />
```python
from pyp3d import *
class 立方体(Component):
    def __init__(self):
        Component.__init__(self)
        self['长'] = Attr(1000.0, obvious=True)
        self['宽'] = Attr(300.0, obvious=True)
        self['高'] = Attr(500, obvious = True)
        self['立方体'] = Attr(None, show=True)
        self['旋转角度'] = Attr(0,obvious = True)
        self['X'] = Attr(0.0, obvious=True)
        self['Y'] = Attr(0.0, obvious=True)
        self['Z'] = Attr(0.0, obvious=True)
        self.replace()
    @export
    def replace(self):
        L = self['长']
        W = self['宽']
        H = self['高']
        x = self['X']
        y = self['Y']
        z = self['Z']
        Angle = self['旋转角度']
        TestCube = translate(x,y,z) * rotation(math.pi/180 * Angle) * scale(L,W,H) * Cube()
        self['立方体'] = TestCube
if __name__ == "__main__":
    # 第一行 对【立方体】这个class进行装饰
    FinalGeometry = 立方体()
    # 第二行 实现两点布置
    TwoPointPlace.linearize(FinalGeometry,'长')
    place(FinalGeometry)

```
<center>
<img src="/uploads/python/images/image90.png" alt="" width="800"><br />
图4.2-1<br />
</center>

## 如何实现属性表下拉选项
有很多同学可能想要知道该如何实现属性表中的下拉选择，而不是完全由数值输入的形式来改变参数，毕竟有很多构件是有标准尺寸的，而标准尺寸是有多个固定的数值，并不允许随意更改。因此，下拉选择还是很有必要的<br />
想要实现下拉选择的效果实际上很简单，我们只需要在设置参数时，在Attr里面新增一个Tag就可以了。<br />

## 3.3.1 combo标签<br />
通常，我们在设置参数时，一般会在`Attr`中放置文字（`str`）或数值（`int`或`float`），以及`obvious`和`readonly`这两个tag。现在，我们有一个新的tag——`combo`<br />
注意，`obvious`、`readonly`、`combo`这三个tag全部都是纯小写字母，不要输入大写字母。<br />
`combo`标签的格式如下所示：<br />

		self['长'] = Attr(1000.0, obvious=True, combo = [500,1000,2000,3000,4000])

需要将一个`list`赋值给`combo`标签。要注意的是，`list`中装填的元素应当与`Attr`中给定的默认参数保持相同类型，并且应当有一个元素与默认参数相同。<br />
接下来，我们以长方体为例，将`combo`标签放入`Attr`中。<br />

```python
from pyp3d import *
class 立方体(Component):
    def __init__(self):
        Component.__init__(self)
        self['长'] = Attr(1000.0, obvious=True, combo = [500,1000,2000,3000,4000])
        self['宽'] = Attr(1000.0, obvious=True)
        self['高'] = Attr(1000, obvious = True)
        self['立方体'] = Attr(None, show=True)
        self.replace()
@export
    def replace(self):
        L = self['长']
        W = self['宽']
        H = self['高']
        TestCube = scale(L,W,H) * Cube()
        self['立方体'] = TestCube
if __name__ == "__main__":
	FinalGeometry =立方体()
    place(FinalGeometry)

```

此时，我们运行脚本并将长方体布置到工程文件中，并选中该长方体，可以看到，该长方体的参数“长”已经变成了下拉选单的形式。<br />

<center>
<img src="/uploads/python/images/image93.png" alt="" width="800"><br /></center>

注意，当使用了`combo`标签时，就不能再随意设置数值了。因此，一定要确认好是否需要任意修改参数的数值后，再决定是否使用`combo`标签。<br />

## 3.4.1 获取线中的三维点（离散）list列表<br />
当我们想对某根线进行离散时，我们可以使用对弧线离散或使用对多段线离散函数。<br />
### 对弧线离散函数形式：<br />

		get_discrete_points_from_arc (arc:Arc,disNum=0,withEnd=False,isEqual = False)

对弧线离散时，需要将弧线装入上述函数，同时，需要确认三个标签（tag）的输入值是否符合要求。<br />

#### Tag标签含义：<br />
`disNum`离散点数量：表示离散点的个数；默认`disNum`为0，表示按照20毫米基准为间距进行离散，会自动计算离散点个数。<br />
注意：由于离散后会取整，因此间距可能会略大于输入的数值；<br />
`withEnd`是否包含尾点：表示是否需要每一段的尾点，默认为False。False表示不包含尾点，即去掉每段最后一个点，避免重复。True表示包含每一段尾点<br />
isEqual是否等距：表示是否为等距离散。默认为False。False表示按照角度进行离散，True表示按照弧长进行等距离散。<br />

### 对多段线离散：<br />

		get_discrete_points_from_line (line:Line, disNum=0, onlyCurve=True)<br />

其中，line可以是直线段、多段线、含有弧线的多段线等，需要将line装入该函数，同事需要确认两个标签的输入值是否符合要求<br />

#### Tag标签含义：<br />
disNum离散点数量：表示离散点的个数；默认disNum为0，表示按照20毫米基准为间距进行离散，会自动计算离散点个数。<br />
注意：由于离散后会取整，因此间距可能会略大于输入的数值；<br />
onlyCurve是否只对圆弧离散：表示是否仅离散圆弧，默认值为True，表示只离散圆弧，直线部分不离散，False表示对直线和圆弧全部进行离散。<br />


## 3.4.2 获取section中的三维点（离散）list列表<br />
函数形式：<br />

		get_discrete_points_from_section(sec:Section,num:int=0,onlyCurve=True)

该函数有三个参数，分别为截面、离散点数量，是否只离散弧线<br />
#### 示例：<br />
如此一来，就得到了一个截面的一组离散点。<br />
```python
bottom_sec = Section(scale(3000, 4000)*Arc())
bottom_sec_points = get_discrete_points_from_section(bottom_sec, N, False)
```

## 3.5 放样体异面融合
放样体可以实现异面融合，比如圆面和矩形面生成一个“天圆地方”的几何体。放样体在进行异面融合放样时，有以下几个原则。<br />
(1) 当其中一个`Seciton`为单闭合线型时(比如一个Arc) ，两个`Section`起点终点分别对应，轮廓线等比例对应融合。<br />
(2) 当两个`Section`都不是单闭合线型时， 两个`Section`轮廓线从各自起点开始，按照轮廓线数目一一对应，当其中一个`Section`有轮廓线段剩余时，将对应到另一个`Section`的终点上。


## 4.1 参数化组件示例

### 工字钢立柱
from pyp3d import *
import math

#模型1：工字钢开孔 
class 工字钢开孔(Component):
    def __init__(self):
        Component.__init__(self)
        self['立柱长度'] = Attr(300.0)
        self['工字钢翼缘宽度'] = Attr(75.0)
        self['工字钢截面高度'] = Attr(120.0)
        self['最终实体'] = Attr(None, show=True)
        self['腹板厚度'] = Attr(5.0, obvious=None)
        self['翼缘厚度'] = Attr(8.0, obvious=None)
        
        # ========== 工字钢开孔-核心驱动点 (关键对接位) ==========
        self.setDrivenFeaturePoint('point1', SnapMode.EndPoint, '[定位点X]', '[定位点Y]', '[定位点Z]')          # 工字钢顶部中心定位点(主定位)
        self.setDrivenFeaturePoint('point2', SnapMode.EndPoint, '[定位点X]', '[定位点Y]', '[定位点Z]-[立柱长度]') # 工字钢底部中心定位点
        self.setDrivenFeaturePoint('point3', SnapMode.EndPoint, '[定位点X]+[工字钢截面高度]/2', '[定位点Y]', '[定位点Z]') # 工字钢右侧翼缘顶部端点
        self.setDrivenFeaturePoint('point4', SnapMode.EndPoint, '[定位点X]-[工字钢截面高度]/2', '[定位点Y]', '[定位点Z]') # 工字钢左侧翼缘顶部端点
        self.setDrivenFeaturePoint('point5', SnapMode.GeometricCenter, '[定位点X]', '[定位点Y]', '[定位点Z]-[立柱长度]/2') # 工字钢腹板中心(开孔区核心位)

    def replace(self):
        L = self['立柱长度']
        B = self['工字钢翼缘宽度']
        L1 = self['工字钢截面高度']
        腹板厚度 = self['腹板厚度']
        翼缘厚度 = self['翼缘厚度']
        
        steel_points = [
            Vec2(0, B/2), Vec2(0, -B/2),
            Vec2(翼缘厚度, -B/2), Vec2(翼缘厚度, -腹板厚度/2),
            Vec2(L1 - 翼缘厚度, -腹板厚度/2), Vec2(L1 - 翼缘厚度, -B/2),
            Vec2(L1, -B/2), Vec2(L1, B/2),
            Vec2(L1 - 翼缘厚度, B/2), Vec2(L1 - 翼缘厚度, 腹板厚度/2),
            Vec2(翼缘厚度, 腹板厚度/2), Vec2(翼缘厚度, B/2),Vec2(0, B/2)
        ]
        steel_section = Section(*steel_points)
        steel_body = Sweep(steel_section, Line(Vec3(0, 0, -L), Vec3(0, 0, 0)))

        Hol_rec = Section(
            Vec2(0,0),Vec2(1.5,3.5),Vec2(5,5),Vec2(20,5),Vec2(23.5,3.5),Vec2(25,0),
            Vec2(23.5,-3.5),Vec2(20,-5),Vec2(5,-5),Vec2(1.5,-3.5)
        )
        Hol_rec = rotx(-0.5 * math.pi) * Hol_rec
        hole_sweep = Sweep(Hol_rec, Line(Vec3(0, -腹板厚度/2, 0), Vec3(0, 腹板厚度/2, 0)))
        hole_len =25
        hole_sweep = transx(-hole_len/2)*hole_sweep

        holes = None
        z0 = -25
        i=0
        while True:
            z = z0 -i*50
            if z < -L:break
            hole_i = transx(L1/2)*transy(0)*transz(z)*hole_sweep
            holes = hole_i if holes is None else holes+hole_i
            i+=1
        if holes: steel_body = steel_body - holes
        self['最终实体'] = steel_body

#模型2孔：实心圆柱
class 实心圆柱(Component):
    def __init__(self, r=1.0, h=10.0):
        Component.__init__(self)
        self['圆柱'] = Attr(None, show=True)
        self.r = r
        self.h = h
        
        # ========== 实心圆柱-驱动点 ==========
        self.setDrivenFeaturePoint('point1', SnapMode.GeometricCenter, '[定位点X]', '[定位点Y]', '[定位点Z]') # 圆柱中心
        self.setDrivenFeaturePoint('point2', SnapMode.EndPoint, '[定位点X]', '[定位点Y]+self.h/2', '[定位点Z]') # 圆柱上端面中心
        self.setDrivenFeaturePoint('point3', SnapMode.EndPoint, '[定位点X]', '[定位点Y]-self.h/2', '[定位点Z]') # 圆柱下端面中心
        
        self.replace()

    @export
    def replace(self):
        r=self.r;h=self.h
        arc1 = Arc(Vec3(r,0,0),Vec3(0,0,r),Vec3(-r,0,0))
        arc2 = Arc(Vec3(-r,0,0),Vec3(0,0,-r),Vec3(r,0,0))
        section = Section(arc1, arc2)
        solid = Sweep(section, Line(Vec3(0,0,0),Vec3(0,h,0)))
        self['圆柱'] = solid

#模型2主体：长方体 长度联动L1-16
class 扫掠(Component):
    def __init__(self, gzg_section_h=120):
        Component.__init__(self)
        self['长'] = Attr(gzg_section_h - 16)
        self['宽'] = Attr(5.0)
        self['高'] = Attr(100.0)
        self['扫掠体'] = Attr(None, show=True)
        
        # ========== 长方体主体-驱动点 ==========
        self.setDrivenFeaturePoint('point1', SnapMode.EndPoint, '[定位点X]', '[定位点Y]', '[定位点Z]') # 长方体前端左上角
        self.setDrivenFeaturePoint('point2', SnapMode.EndPoint, '[定位点X]+[长]', '[定位点Y]', '[定位点Z]') # 长方体前端右上角
        self.setDrivenFeaturePoint('point3', SnapMode.GeometricCenter, '[定位点X]+[长]/2', '[定位点Y]+[宽]/2', '[定位点Z]+[高]/2') # 长方体几何中心(核心对接位)
        
        self.replace()
        
    @export
    def replace(self):
        rect_section = Section(
            Vec2(0,0),Vec2(self['长'],0),Vec2(self['长'],self['宽']),Vec2(0,self['宽'])
        )
        line_path = Line(Vec3(0,0,0),Vec3(0,0,self['高']))
        self['扫掠体'] = Sweep(rect_section, line_path)

#模型2：长方体开孔
class 长方体开孔(Component):
    def __init__(self, gzg_section_h=120):
        Component.__init__(self)
        self['长方体'] = Attr(扫掠(gzg_section_h), show=True)
        self['最终实体'] = Attr(None, show=True)
        
        # ========== 长方体开孔-核心驱动点 (与螺栓/托臂对接核心位) ==========
        self.setDrivenFeaturePoint('point1', SnapMode.GeometricCenter, '[定位点X]', '[定位点Y]', '[定位点Z]') # 长方体整体中心
        self.setDrivenFeaturePoint('point2', SnapMode.GeometricCenter, '[定位点X]+([长]-16)/2', '[定位点Y]', '[定位点Z]+25') # 上方开孔中心(螺栓安装位)
        self.setDrivenFeaturePoint('point3', SnapMode.GeometricCenter, '[定位点X]+([长]-16)/2', '[定位点Y]', '[定位点Z]+75') # 下方开孔中心(螺栓安装位)

    @export
    def replace(self):
        cuboid_component = self['长方体']
        cuboid = cuboid_component['扫掠体']
        
        L = cuboid_component['长']
        W = cuboid_component['宽']
        H = cuboid_component['高']

        r = 2.0
        h = W + 2
        hole1 = transx(L/2)*transz(H-25)*实心圆柱(r,h)['圆柱']
        hole2 = transx(L/2)*transz(25)*实心圆柱(r,h)['圆柱']
        self['最终实体'] = cuboid - (hole1 + hole2)

#模型3：八边形带Xoy孔体
class 八边形带Xoy孔体(Component):
    def __init__(self):
        Component.__init__(self)
        self['厚度t'] = Attr(6.0)
        self['八边形开孔实体'] = Attr(None, show=True)
        
        # ========== 八边形体-核心驱动点 (与工字钢/托臂连接核心位) ==========
        self.setDrivenFeaturePoint('point1', SnapMode.GeometricCenter, '[定位点X]', '[定位点Y]', '[定位点Z]') # 八边形几何中心(主定位)
        self.setDrivenFeaturePoint('point2', SnapMode.GeometricCenter, '[定位点X]+75', '[定位点Y]', '[定位点Z]') # 右侧开孔中心
        self.setDrivenFeaturePoint('point3', SnapMode.GeometricCenter, '[定位点X]-75', '[定位点Y]', '[定位点Z]') # 左侧开孔中心
        self.setDrivenFeaturePoint('point4', SnapMode.GeometricCenter, '[定位点X]', '[定位点Y]+30', '[定位点Z]') # 上侧开孔中心
        self.setDrivenFeaturePoint('point5', SnapMode.GeometricCenter, '[定位点X]', '[定位点Y]-30', '[定位点Z]') # 下侧开孔中心

    @export
    def replace(self):
        t = self['厚度t']
        correct_points = [
            Vec2(-110, 30), Vec2(-75, 60), Vec2(75, 60), Vec2(110, 30),
            Vec2(110, -30), Vec2(75, -60), Vec2(-75, -60), Vec2(-110, -30)
        ]
        oct_section = Section(*correct_points)
        oct_path = Line(Vec3(0,0,-t/2),Vec3(0,0,t/2))
        octagon_3d = Sweep(oct_section, oct_path)

        Hol_rec = Section(
            Vec2(0,0),Vec2(1.5,3.5),Vec2(5,5),Vec2(20,5),Vec2(23.5,3.5),Vec2(25,0),
            Vec2(23.5,-3.5),Vec2(20,-5),Vec2(5,-5),Vec2(1.5,-3.5)
        )
        hole_path = Line(Vec3(0,0,-t),Vec3(0,0,t))
        AEC_Hole = Sweep(Hol_rec, hole_path)
        AEC_Hole = transx(-12.5)*AEC_Hole

        hole_left = transx(-75) * transy(0) * AEC_Hole
        hole_right = transx(75) * transy(0) * AEC_Hole
        hole_up = transx(0) * transy(30) * AEC_Hole
        hole_down = transx(0) * transy(-30) * AEC_Hole
        hole_all = combine(hole_left, hole_right, hole_up, hole_down)

        self['八边形开孔实体'] = octagon_3d - hole_all

#三合一参数选择 (核心总装类，驱动点最全，重点！)
class 三合一(Component):
    def __init__(self):
        Component.__init__(self)
        self['组件名称'] = Attr('LQJ-LZ-01A型立柱', obvious=True)
        self['组件型号'] = Attr('LQJ-LZ-01A-3', obvious=True, combo=[
            'LQJ-LZ-01A-3', 'LQJ-LZ-01A-5', 'LQJ-LZ-01A-7', 'LQJ-LZ-01A-8', 'LQJ-LZ-01A-9',
            'LQJ-LZ-01A-10', 'LQJ-LZ-01A-13', 'LQJ-LZ-01A-15', 'LQJ-LZ-01A-18', 'LQJ-LZ-01A-20',
            'LQJ-LZ-01A-25', 'LQJ-LZ-01A-30', 'LQJ-LZ-01A-35', 'LQJ-LZ-01A-40', 'LQJ-LZ-01A-自定义'
        ])

        self['立柱长度L'] = Attr(300.0, obvious=True)
        self['工字钢翼缘宽度B'] = Attr(75.0, obvious=True)
        self['工字钢截面高度L1'] = Attr(120.0, obvious=True)
        self['八边形-厚度t'] = Attr(6.0, obvious=True)

        self['工字钢模型'] = Attr(工字钢开孔(), show=True)
        self['长方体模型'] = Attr(长方体开孔(self['工字钢截面高度L1']), show=True)
        self['八边形模型'] = Attr(八边形带Xoy孔体(), show=True)
        self['总装配实体'] = Attr(None, show=True)
        
        # ========== 【重中之重】三合一总装-全套核心驱动点 (和你的托臂模型对接的核心点位) ==========
        # 完全沿用你托臂的点位命名+语法规范，所有点位都是和LQJ_LB_01A型托臂对接的高频位
        self.setDrivenFeaturePoint('point1', SnapMode.EndPoint, '[定位点X]', '[定位点Y]', '[定位点Z]')            # 立柱顶部总定位点 (主对接位)
        self.setDrivenFeaturePoint('point2', SnapMode.EndPoint, '[定位点X]', '[定位点Y]', '[定位点Z]-[立柱长度L]') # 立柱底部总定位点
        self.setDrivenFeaturePoint('point3', SnapMode.GeometricCenter, '[定位点X]', '[定位点Y]-8', '[定位点Z]-98') # 长方体安装区中心 (托臂搭接位)
        self.setDrivenFeaturePoint('point4', SnapMode.GeometricCenter, '[定位点X]', '[定位点Y]', '[定位点Z]')      # 八边形中心 (横向连接件对接位)
        self.setDrivenFeaturePoint('point5', SnapMode.EndPoint, '[定位点X]+[工字钢截面高度L1]/2', '[定位点Y]', '[定位点Z]-[立柱长度L]/2') # 工字钢右侧中点(托臂支撑位)
        self.setDrivenFeaturePoint('point6', SnapMode.EndPoint, '[定位点X]-[工字钢截面高度L1]/2', '[定位点Y]', '[定位点Z]-[立柱长度L]/2') # 工字钢左侧中点(托臂支撑位)

    @export
    def replace(self):
        Typ = self['组件型号']
        if Typ == 'LQJ-LZ-01A-3':
            self['立柱长度L'] = 300.0
            self['八边形-厚度t'] = 6.0
            self['工字钢翼缘宽度B'] = 75.0
            self['工字钢截面高度L1'] = 120.0
        elif Typ == 'LQJ-LZ-01A-5':
            self['立柱长度L'] = 500.0
            self['八边形-厚度t'] = 6.0
            self['工字钢翼缘宽度B'] = 75.0
            self['工字钢截面高度L1'] = 120.0
        elif Typ == 'LQJ-LZ-01A-7':
            self['立柱长度L'] = 700.0
            self['八边形-厚度t'] = 6.0
            self['工字钢翼缘宽度B'] = 75.0
            self['工字钢截面高度L1'] = 120.0
        elif Typ == 'LQJ-LZ-01A-8':
            self['立柱长度L'] = 800.0
            self['八边形-厚度t'] = 6.0
            self['工字钢翼缘宽度B'] = 75.0
            self['工字钢截面高度L1'] = 120.0
        elif Typ == 'LQJ-LZ-01A-9':
            self['立柱长度L'] = 900.0
            self['八边形-厚度t'] = 6.0
            self['工字钢翼缘宽度B'] = 75.0
            self['工字钢截面高度L1'] = 120.0
        elif Typ == 'LQJ-LZ-01A-10':
            self['立柱长度L'] = 1000.0
            self['八边形-厚度t'] = 8.0
            self['工字钢翼缘宽度B'] = 75.0
            self['工字钢截面高度L1'] = 120.0
        elif Typ == 'LQJ-LZ-01A-13':
            self['立柱长度L'] = 1300.0
            self['八边形-厚度t'] = 8.0
            self['工字钢翼缘宽度B'] = 75.0
            self['工字钢截面高度L1'] = 120.0
        elif Typ == 'LQJ-LZ-01A-15':
            self['立柱长度L'] = 1500.0
            self['八边形-厚度t'] = 8.0
            self['工字钢翼缘宽度B'] = 75.0
            self['工字钢截面高度L1'] = 120.0
        elif Typ == 'LQJ-LZ-01A-18':
            self['立柱长度L'] = 1800.0
            self['八边形-厚度t'] = 8.0
            self['工字钢翼缘宽度B'] = 75.0
            self['工字钢截面高度L1'] = 120.0
        elif Typ == 'LQJ-LZ-01A-20':
            self['立柱长度L'] = 2000.0
            self['八边形-厚度t'] = 8.0
            self['工字钢翼缘宽度B'] = 75.0
            self['工字钢截面高度L1'] = 120.0
        elif Typ == 'LQJ-LZ-01A-25':
            self['立柱长度L'] = 2500.0
            self['八边形-厚度t'] = 8.0
            self['工字钢翼缘宽度B'] = 75.0
            self['工字钢截面高度L1'] = 120.0
        elif Typ == 'LQJ-LZ-01A-30':
            self['立柱长度L'] = 3000.0
            self['八边形-厚度t'] = 8.0
            self['工字钢翼缘宽度B'] = 75.0
            self['工字钢截面高度L1'] = 120.0
        elif Typ == 'LQJ-LZ-01A-35':
            self['立柱长度L'] = 3500.0
            self['八边形-厚度t'] = 8.0
            self['工字钢翼缘宽度B'] = 75.0
            self['工字钢截面高度L1'] = 120.0
        elif Typ == 'LQJ-LZ-01A-40':
            self['立柱长度L'] = 4000.0
            self['八边形-厚度t'] = 8.0
            self['工字钢翼缘宽度B'] = 75.0
            self['工字钢截面高度L1'] = 120.0
        
        elif Typ == 'LQJ-LZ-01A-自定义':
            pass
        
        L = self['立柱长度L']
        B = self['工字钢翼缘宽度B']
        L1 = self['工字钢截面高度L1']
        t = self['八边形-厚度t']

        gzg = self['工字钢模型']
        gzg['立柱长度'] = Attr(L)
        gzg['工字钢翼缘宽度'] = Attr(B)
        gzg['工字钢截面高度'] = Attr(L1)
        gzg.replace()

        self['长方体模型'] = Attr(长方体开孔(L1), show=True)
        self['长方体模型'].replace()

        octagon = self['八边形模型']
        octagon['厚度t'] = Attr(t)
        octagon.replace()

        工字钢实体 = transx(-L1/2) * gzg['最终实体']
        长方体实体 = self['长方体模型']['最终实体']
        八边形实体 = octagon['八边形开孔实体']

        cuboid_len = L1 - 16
        cuboid_height = 100.0
        #长方体放置
        长方体放置 = (
            transx(-L1/2)
            * transy(-8)
            * transx( (L1 - cuboid_len) / 2 )
            * transz(-cuboid_height + 2)
            * 长方体实体
        )

        #八边形放置
        八边形放置 = transy(0) * transz(0) * 八边形实体

        self['总装配实体'] = combine(工字钢实体, 长方体放置, 八边形放置)

if __name__ == "__main__":
    FinalGeometry = 三合一()
    FinalGeometry.replace()
    place(FinalGeometry)

### 安全阀-27型
import pyp3d as p3d
import math
def replace_operator(data:p3d.P3DData)->None:
    rg=data['半径']#公称半径   50
    l=data['总长度']
    h=data['阀门高度']
    r1=rg*2.5         #半径 1=公称半径 * 2.5
    r2=rg*1.2         #半径 2=公称半径 * 1.2
    r3=rg*0.6         #半径 3=公称半径 * 0.6
    h1=h*0.41         #高度 1=阀门高度 * 0.41
    rf=data['法兰半径']
    tf=data['法兰厚度']
    h2=h*0.75         #高度 2=阀门高度 * 0.75 
    h3=h*0.1          #高度 3=阀门高度 * 0.1
    h4=h*0.75         #高度 4=阀门高度 * 0.75 
    h5=h1*0.35        #高度 5=高度 1 * 0.35
    l1=l*0.19         #长度 1=总长度 * 0.19
    l2=l*0.1          #长度 2=总长度 * 0.1
    l3=l2*1.2         #长度 3=长度 2 * 1.2
    l4=l*0.08         #长度 4=总长度 * 0.08
    l5=l4*0.5         #长度 5=长度 4 * 0.5
    rm=data['密封面半径']
    tm=data['密封面厚度']
    l6=(h-h1)*0.28    #长度 6=(阀门高度 - 高度 1) * 0.28
    l7=l6/2           #长度 7=长度 6 / 2

    #长度 8 if(高度 1 < 长度 1, 高度 1 - 0.2 mm, 长度 1 - 0.2 mm)
    if h1<l1:
       l8=h1-0.2;
    else:
       l8=l1-0.2
    l9=l8*math.tan(30/180*p3d.pi)   #长度 9=长度 8 * tan(30°)
    l10=l9*0.6                      #长度 10=长度 9 * 0.6

    
    #主体
    c1 = p3d.Cone(p3d.Vec3(0,0,0),p3d.Vec3(-tm,0,0),rm).color(0.7,0.7,0.7,1)
    c2 = p3d.Cone(p3d.Vec3(0,0,0),p3d.Vec3(tf,0,0),rf).color(0.7,0.7,0.7,1)
    c3 = p3d.Cone(p3d.Vec3(0,0,0),p3d.Vec3(l8,0,0),r2).color(0.7,0.7,0.7,1)
    c4 = p3d.Cone(p3d.Vec3(l3,0,0),p3d.Vec3(h2-l7,0,0),l10).color(0.7,0.7,0.7,1) 
    c5 = p3d.Cone(p3d.Vec3(h2-l7,0,0),p3d.Vec3(h2,0,0),r1).color(0.7,0.7,0.7,1) 
    c6 = p3d.Cone(p3d.Vec3(h2,0,0),p3d.Vec3(h2+l7,0,0),r1).color(0.7,0.7,0.7,1)
    c7 = p3d.Cone(p3d.Vec3(h1,0,0),p3d.Vec3(h1,0,l1),r2).color(0.7,0.7,0.7,1)
    c8 = p3d.Cone(p3d.Vec3(h1,0,l1),p3d.Vec3(h1,0,l1+tm),rm).color(0.7,0.7,0.7,1)
    c9 = p3d.Cone(p3d.Vec3(h1,0,l1),p3d.Vec3(h1,0,l1-tf),rf).color(0.7,0.7,0.7,1)
    c10 = p3d.Cone(p3d.Vec3(h2+l7,0,l5),p3d.Vec3(h2+l7+l6-10,0,l5),r3).color(0.7,0.7,0.7,1)
    c11 = p3d.Cone(p3d.Vec3(h2+l7,0,-l5),p3d.Vec3(h,0,-l5),r3).color(0.7,0.7,0.7,1)
    c12 = p3d.Cone(p3d.Vec3(h2+l7+l6/2,0,l5),p3d.Vec3(h2+l7+l6/2,0,l1-l),5).color(0.7,0.7,0.7,1)
    e1= p3d.Extrusion(
    [
    p3d.Vec3(h,-10,l1-l+l2),
    p3d.Vec3(h,-10,l1-l+l2+2*l5),
    p3d.Vec3(h,10,l1-l+l2+2*l5),
    p3d.Vec3(h,10,l1-l+l2)
    ],
    p3d.Vec3(-h4,0,0)
    ).color(0.7,0.7,0.7,1)
    s1= p3d.Sphere(p3d.Vec3(h-50-l4,0,l1-l+l2+l5),l4).color(0.7,0.7,0.7,1)
    s2= p3d.Sphere(p3d.Vec3(h-h4,0,l1-l+l2+l5),l4).color(0.7,0.7,0.7,1)
    c13 = p3d.Cone(p3d.Vec3(h-50-l4,0,l1-l+l2+l5),p3d.Vec3(h-h4,0,l1-l+l2+l5),l4).color(0.7,0.7,0.7,1)
    c14=p3d.unite(s1,s2,c13).color(0.7,0.7,0.7,1)

    data['安全阀'] = [c1,c2,c3,c4,c5,c6,c7,c8,c9,c10,c11,c12,e1,c14]


if __name__ == "__main__":
    data = p3d.P3DData({
        '半径':50,
        '总长度':982,
        '阀门高度':439,
        '法兰半径':110,
        '法兰厚度':22,
        '密封面半径':78,
        '密封面厚度':2,
        '构件名称':'安全阀-A27型-单杆微启式-法兰式' 
        })
    
      
    data.set_view(-0.125*p3d.pi,-0.125*p3d.pi)
    data.setup('安全阀', show=True)
    data.setup('半径', obvious=True, group='主体属性', description='半径')
    data.setup('总长度', obvious=True, group='主体属性', description='总长度')
    data.setup('阀门高度', obvious=True, group='主体属性', description='阀门高度')
    data.setup('法兰半径', obvious=True, group='主体属性', description='法兰半径')
    data.setup('法兰厚度', obvious=True, group='主体属性', description='法兰厚度')
    data.setup('密封面半径', obvious=True, group='密封面属性', description='密封面半径')
    data.setup('密封面厚度', obvious=True, group='密封面属性', description='密封面厚度')
    data.setup('构件名称',obvious=True)

   
    data['replace'] = replace_operator
    replace_operator(data)
    
    p3d.launchData(data)

### 气动阀
import pyp3d as p3d

def test_qidongfa(data:p3d.P3DData)->None:
    if data['公称直径'] < 50:
        data['阀环半径'] = 15;
        data['管道半径'] = 20;
        data['管道长度'] = 165;
        data['法兰半径'] = 56;
        data['法兰厚度'] = 16;
        data['手轮半径'] = 109;
        data['腹部半径'] = 63;
        data['总高度'] = 300;
    elif 50 <= data['公称直径'] and data['公称直径']< 65:
        data['阀环半径'] = 30;
        data['管道半径'] = 51;
        data['管道长度'] = 165;
        data['法兰半径'] = 76;
        data['法兰厚度'] = 19;
        data['手轮半径'] = 111;
        data['腹部半径'] = 79;
        data['总高度'] = 350;
    elif 65 <= data['公称直径'] and data['公称直径']< 80:
        data['阀环半径'] = 33;
        data['管道半径'] = 54;
        data['管道长度'] = 172;
        data['法兰半径'] = 89;
        data['法兰厚度'] = 22;
        data['手轮半径'] = 113;
        data['腹部半径'] = 84;
        data['总高度'] = 420;
    elif 80 <= data['公称直径'] and data['公称直径']< 100:
        data['阀环半径'] = 37;
        data['管道半径'] = 60;
        data['管道长度'] = 194;
        data['法兰半径'] = 95;
        data['法兰厚度'] = 24;
        data['手轮半径'] = 114;
        data['腹部半径'] = 93;
        data['总高度'] = 440;
    elif 100 <= data['公称直径'] and data['公称直径']< 150:
        data['阀环半径'] = 44;
        data['管道半径'] = 73;
        data['管道长度'] = 245;
        data['法兰半径'] = 114;
        data['法兰厚度'] = 24;
        data['手轮半径'] = 140;
        data['腹部半径'] = 113;
        data['总高度'] = 500;
    elif 150 <= data['公称直径'] and data['公称直径']< 200:
        data['阀环半径'] = 61;
        data['管道半径'] = 102;
        data['管道长度'] = 356;
        data['法兰半径'] = 140;
        data['法兰厚度'] = 25;
        data['手轮半径'] = 165;
        data['腹部半径'] = 156;
        data['总高度'] = 550;
    elif 200 <= data['公称直径'] and data['公称直径']< 250:
        data['阀环半径'] = 75;
        data['管道半径'] = 124;
        data['管道长度'] = 438;
        data['法兰半径'] = 172;
        data['法兰厚度'] = 29;
        data['手轮半径'] = 191;
        data['腹部半径'] = 191;
        data['总高度'] = 600;
    elif 250 <= data['公称直径'] and data['公称直径']< 300:
        data['阀环半径'] = 94;
        data['管道半径'] = 156;
        data['管道长度'] = 562;
        data['法兰半径'] = 203;
        data['法兰厚度'] = 30;
        data['手轮半径'] = 218;
        data['腹部半径'] = 240;
        data['总高度'] = 700;
    elif 300 <= data['公称直径'] and data['公称直径']< 350:
        data['阀环半径'] = 105;
        data['管道半径'] = 175;
        data['管道长度'] = 635;
        data['法兰半径'] = 241;
        data['法兰厚度'] = 32;
        data['手轮半径'] = 321;
        data['腹部半径'] = 269;
        data['总高度'] = 800;
    elif 350 <= data['公称直径'] and data['公称直径']< 400:
        data['阀环半径'] = 118;
        data['管道半径'] = 197;
        data['管道长度'] = 718;
        data['法兰半径'] = 267;
        data['法兰厚度'] = 35;
        data['手轮半径'] = 321;
        data['腹部半径'] = 303;
        data['总高度'] = 1000;
    elif 400 <= data['公称直径'] and data['公称直径']< 450:
        data['阀环半径'] = 137;
        data['管道半径'] = 229;
        data['管道长度'] = 841;
        data['法兰半径'] = 299;
        data['法兰厚度'] = 37;
        data['手轮半径'] = 321;
        data['腹部半径'] = 352;
        data['总高度'] = 1200;
    # 腹部半径113
    data['腹部'] = p3d.Sphere(p3d.Vec3(0,0,0),data['腹部半径']).color(0.5,0.5,0.5,1)
    # 管道半径73
    data['管道'] = p3d.Cone(p3d.Vec3(0,0,0),p3d.Vec3(0,0,data['管道长度']/2),data['管道半径'],data['管道半径']).color(0.5,0.5,0.5,1)
    data['管道1'] = p3d.rotation(p3d.Vec3(0,1,0),p3d.pi*0.5) * data['管道']
    data['管道2'] = p3d.rotation(p3d.Vec3(0,1,0),p3d.pi*1.5) * data['管道']
    # 阀帽半径88
    data['阀帽'] = p3d.Cone(p3d.Vec3(0,0,0),p3d.Vec3(0,0,data['总高度']*0.3), data['阀环半径']*2, data['阀环半径']*2).color(0.5,0.5,0.5,1)
    # 半径1默认半径40
    data['半径1'] = p3d.Cone(p3d.Vec3(0,0,0),p3d.Vec3(0,0,data['总高度']-data['总高度']*0.3-data['总高度']*0.12-25),data['公称直径']/2.5,data['公称直径']/2.5).color(0.5,0.5,0.5,1)
    data['半径1'] = p3d.translation(p3d.Vec3(0,0,data['总高度']*0.3)) * data['半径1']
    # 阀环半径44
    data['阀环'] = p3d.Cone(p3d.Vec3(0,0,0),p3d.Vec3(0,0,data['总高度']*0.12), data['阀环半径'], data['阀环半径']).color(0.5,0.5,0.5,1)
    data['阀环'] = p3d.translation(p3d.Vec3(0,0,data['总高度']-data['总高度']*0.12-25)) * data['阀环']
    # 半径3默认半径50
    data['半径3'] = p3d.Cone(p3d.Vec3(0,0,0),p3d.Vec3(0,0, data['公称直径']*1.2),data['公称直径']/2,data['公称直径']/2).color(0.5,0.5,0.5,1)
    data['半径3'] = p3d.translation(p3d.Vec3(0,0,data['总高度']-25)) * data['半径3']
    # 半径4默认半径5
    data['半径4'] = p3d.Cone(p3d.Vec3(0,0,0),p3d.Vec3(0,0,data['公称直径']/5),data['公称直径']/20,data['公称直径']/20).color(0.5,0.5,0.5,1)
    data['半径4'] = p3d.translation(p3d.Vec3(0,0,data['总高度']-25+data['公称直径']*1.2)) * data['半径4']
    # 半径2默认半径40
    data['半径2'] = p3d.Cone(p3d.Vec3(0,0,0),p3d.Vec3(0,0,data['公称直径']/10),data['公称直径']/2.5,data['公称直径']/2.5).color(0.5,0.5,0.5,1)
    data['半径2'] = p3d.translation(p3d.Vec3(0,0,data['总高度']-25+data['公称直径']*1.2+data['公称直径']/5)) * data['半径2']
    # 法兰默认半径114
    data['法兰'] = p3d.Cone(p3d.Vec3(0,0,0),p3d.Vec3(0,0, data['法兰厚度']),data['法兰半径'],data['法兰半径']).color(0.5,0.5,0.5,1)
    data['法兰1'] = p3d.rotation(p3d.Vec3(0,1,0),p3d.pi*0.5) *  data['法兰']
    data['法兰2'] = p3d.rotation(p3d.Vec3(0,1,0),p3d.pi*1.5) *  data['法兰']
    data['法兰1'] = p3d.translation(p3d.Vec3(-data['法兰厚度']-data['管道长度']/2,0,0)) * data['法兰1']
    data['法兰2'] = p3d.translation(p3d.Vec3(data['法兰厚度']+data['管道长度']/2,0,0)) * data['法兰2']

if __name__ == "__main__":
    data = p3d.P3DData({
        '阀环半径' : 44,
        '管道半径' : 73,
        '管道长度' : 245,
        '法兰半径' : 114,
        '法兰厚度' : 24,
        '手轮半径' : 140,
        '腹部半径' : 113,
        '公称直径': 100,
        '总高度' : 500,
        '构件名称':'气动阀'
        })
    
    data.set_view(-0.125*p3d.pi,-0.125*p3d.pi)

     # 输出构件
    data.setup('腹部', show=True)
    data.setup('管道1', show=True)
    data.setup('管道2', show=True)
    data.setup('阀帽', show=True)
    data.setup('半径1', show=True)
    data.setup('阀环', show=True)
    data.setup('半径3', show=True)
    data.setup('半径4', show=True)
    data.setup('半径2', show=True)
    data.setup('法兰1', show=True)
    data.setup('法兰2', show=True)

    # 设置可调整属性
    data.setup('公称直径', obvious=True, group='尺寸标注', description='公称直径')
    data.setup('构件名称',obvious=True)

    # 设置replace算子
    data['replace'] = test_qidongfa
    test_qidongfa(data)
    # 发射数据到实例模板库
    p3d.launchData(data)

### 波纹管
from pyp3d import *
#import pyp3d_Archi
#import MepElement


def createMepElement(data:P3DData)->None:
  
    length=data['波纹管长']
    dn1=data['公称半径']
    dn2=data['法兰半径']
    dn3=data['壁厚']
    length1=data['法兰厚度']
    length2=1.5*dn3

  #法兰
    outer = Ellipse(Vec3(-0.5*length,0,0), Vec3(0,dn2,0), Vec3(0,0,dn2), 0, pi*2)
    inner = Ellipse(Vec3(-0.5*length,0,0), Vec3(0,dn1,0), Vec3(0,0,dn1), 0, pi*2)
    A1 = ContourLine([outer])
    A2 = ContourLine([inner])
    falanLeft = ExtrusionPlus([A1,-A2], Vec3(length1,0,0)).color(0.4,0.4,0.4,0.5)

    transData=Vec3(length-length1,0, 0)
    falanRight=translation(transData)*falanLeft

    outer = Ellipse(Vec3(-0.5*length,0,0), Vec3(0,dn1+dn3,0), Vec3(0,0,dn1+dn3), 0, pi*2)
    inner = Ellipse(Vec3(-0.5*length,0,0), Vec3(0,dn1,0), Vec3(0,0,dn1), 0, pi*2)
    A1 = ContourLine([outer])
    A2 = ContourLine([inner])
    falanMid = ExtrusionPlus([A1,-A2], Vec3(length,0,0)).color(0.4,0.4,0.4,0.5)

   #圆环
    num = int((length-2*length1-2*length2) / dn3)    #圆环个数
    length3=length-2*length1-num*dn3                 #法兰两边剩余总长度
    length2=length2+0.5*length3                          #法兰两边实际长度  
    startPoint=num*dn3*0.5
    num2=int(num / 2) 
    numLength=num-num2*2
    if numLength>0:                    #奇数
       startPoint=num*dn3*0.5
    else:
       startPoint=num*dn3*0.5-dn3*0.5  #圆环个数为偶数时开始点向右移动一个半径
    fronts1 = []
    for i in range(num):
        fronts1.append(TorusPipe(Vec3(-startPoint+dn3*i,0,0),Vec3(0,1,0),Vec3(0,0,1),dn1+dn3,dn3*0.5,pi*2).color(0.4,0.4,0.4,0.5))
  
    data['波纹管'] = combine(fronts1,falanLeft,falanRight,falanMid).color(0.7,0.7,0.7,1)

    
    data.view = rotation(Vec3(1,1,-1),0)
    # 输出构件
    data.setup('波纹管', show=True)

    #夹点相关
    #位置坐标点尽量与几何尺寸关联，这样在修改几何尺寸时则可联动修改夹点位置
    gripInit(data)      #夹点实现函数 此句必须要写
    # 一、移动夹点
    data['ctrlMoveGrip'] = Vec3(0,0,0)
    data.setup('ctrlMoveGrip', gripstyle = 'dots')

    # 二、旋转夹点
    #axis 旋转基准轴
    #angle 旋转角度 （弧度值）

    data['ctrlExpandGrip'] = Vec3(0,dn1*1.5, 0)
    data.setup('ctrlExpandGrip', gripstyle = 'spin', axis = Vec3(0, 0, 1), angle = pi / 4)

    # 三、设置引出命令夹点
    # command 启动命令  此处固定为PythonFaceGripPoint 必须添加
    # connectFace 关联的管口名称 例如face1 必须添加

    data['ctrlWidthGrip1'] = Vec3(-length*0.5,0,0)
    data.setup('ctrlWidthGrip1', gripstyle = 'cross', command = "PythonFaceGripPoint",connectFace = 'face1')

    data['ctrlWidthGrip2'] = Vec3(length*0.5,0,0)
    data.setup('ctrlWidthGrip2', gripstyle = 'cross', command = "PythonFaceGripPoint",connectFace = 'face2')

   #水管管口数据
    data['face1'] = data['ctrlWidthGrip1']   #位置坐标点
    data.setup('face1', vtNor = Vec3(-1, 0, 0),vtHeight = Vec3(0, 1, 0),width = dn1*2, height = dn1*2,systemType= "生活给水",faceType = 'Pipe',sectType='Circ')

    data['face2'] = data['ctrlWidthGrip2']
    data.setup('face2', vtNor = Vec3(1, 0, 0),vtHeight = Vec3(0, 1, 0),width = dn1*2, height = dn1*2,systemType= "生活给水",faceType = 'Pipe',sectType='Circ')


if __name__ == "__main__":

    obj = P3DData()
    obj['波纹管长']=300
    obj['公称半径']=100
    obj['法兰半径']=150
    obj['壁厚']=20
    obj['法兰厚度']=20
    obj['构件名称']='波纹管'
    obj.setup('波纹管长', obvious=True, group='几何属性', description='单位(mm)')
    obj.setup('公称半径', obvious=True, group='几何属性', description='单位(mm)')
    obj.setup('法兰半径', obvious=True, group='几何属性', description='单位(mm)')
    obj.setup('构件名称',obvious=True)
    #obj.setup('壁厚', obvious=True, group='几何属性', description='单位(mm)')

    obj['replace'] = createMepElement
    createMepElement(obj)
    
    launchData(obj)

### 消防水炮
import pyp3d as p3d
from math import sin
from math import cos
from math import sqrt
def mf(data:p3d.P3DData)->None:
    r = data['公称半径']
    d = r*2
    h = data['高度']
    l = data['长度']
    b1 = data['宽度1']
    r5 = data['半径5']
    r4 = data['半径4']
    h1 = data['高度1']
    r2 = 0.5*b1
    r3 = 0.7*r2
    l8 = r2-r3-6
    l1 = 0.35*b1
    l2 = r3-l8-10
    l3 = sqrt((r3-l8)*(r3-l8)-0.5*l1*0.5*l1)
    l4 = r3-l8
    l5 = l1*0.4
    l6 = l5*0.5
    l7 = 0.03*l
    r1 = 0.5*b1-15
    r6 = r5-4
    r7 = r2+4
    f1 = 0.8*r2
    f2 = sqrt(r2*r2-f1*f1)
    f3 = 0.7*r2
    f4 = sqrt(r2*r2-l3*l3)
    h2 = 0.1*h
    h3 = 0.45*h
    h4 = 0.3*h
    red = (1,0,0,1)
    top1 = p3d.Cone(p3d.Vec3(0,0,h1+h),p3d.Vec3(0,0,h-h2-h3),r,r)
    top2 = p3d.Cone(p3d.Vec3(0,0,-h2+h),p3d.Vec3(0,0,h),r2-r4,r2-r4).color(red)
    top3 = p3d.Cone(p3d.Vec3(0,0,h-h2),p3d.Vec3(0,0,h-h2-h3),r2,r2).color(red)
    top4 = p3d.Cone(p3d.Vec3(0,0,h-h2-h3-l6),p3d.Vec3(0,0,h-h2-h3),r2-6,r2-6).color(red)
    
    top5 = []
    num = 50
    rr1 = r2-6
    rr2 = r3-l8
    dh = (h-h3-h2-l6)/num
    for i in range(0,num):
        dr1 = (rr1+rr2)/2-(rr2-rr1)/2*sin(i/num*p3d.pi-p3d.pi/2)
        dr2 = (rr1+rr2)/2-(rr2-rr1)/2*sin((i+1)/num*p3d.pi-p3d.pi/2)
        a = p3d.Cone(p3d.Vec3(0,0,i*dh),p3d.Vec3(0,0,(i+1)*dh),dr1,dr2).color(red)
        top5.append(a)
    
    top = p3d.combine(top1,top2,top3,top4,top5)

    
    block3 = p3d.Box(p3d.Vec3(-l1/2,-r2,r4), p3d.Vec3(-l1/2,-r2,h-h3-h2-l6), \
        p3d.Vec3(1,0,0), p3d.Vec3(0,1,0), \
            l1, r2, l1, r2).color(red)
            
    block4 = p3d.Cone(p3d.Vec3(-l1/2,-r2+r4,r4),p3d.Vec3(l1/2,-r2+r4,r4),r4,r4).color(red)
    block5 = p3d.Box(p3d.Vec3(-l1/2,-r2+r4,r4), p3d.Vec3(-l1/2,-r2+r4,0), \
        p3d.Vec3(1,0,0), p3d.Vec3(0,1,0), \
            l1, r2-r4, l1, r2-r4).color(red)
    block = p3d.combine(block3,block4,block5)


    
    block_1 = p3d.Extrusion([p3d.Vec3(-l5/2,0,h-h3-h2-l1/2), p3d.Vec3(-l5/2,0,r4), \
        p3d.Vec3(l5/2,0,r4), p3d.Vec3(l5/2,0,h-h3-h2-l1/2)],p3d.Vec3(0,-1000,0))
    block_2 = p3d.Cone(p3d.Vec3(0,0,h-h3-h2-l1/2),p3d.Vec3(0,-1000,h-h3-h2-l1/2),l5/2,l5/2)
    block_ = p3d.combine(block_1,block_2)

    block = p3d.substract(block, block_).color(red)
    block1 = p3d.Cone(p3d.Vec3(0,-l7-r2-6,h2),p3d.Vec3(0,0,h2),r5-4,r5-4)
    block2 = p3d.Cone(p3d.Vec3(0,-l7-r2,h2),p3d.Vec3(0,0,h2),r5,r5)
    block = p3d.combine(block1,block2,block)
# 生成
    data['消防水炮']  = p3d.combine(top, block)

if __name__ == "__main__":
    data = p3d.P3DData({
        '公称半径': 20,
        '长度': 400,
        '高度': 450,
        '宽度1': 380,
        '半径5': 12,
        '半径4': 15,
        '高度1': 200,
        '构件名称':'消防水炮'
    })
    
    data.view = p3d.rotation(p3d.Vec3(0,0,1), 0)
    data.setup('消防水炮', show=True)
    data.setup('公称半径', obvious=True, group='尺寸', description='r')
    data.setup('长度', obvious=True, group='尺寸', description='l')
    data.setup('高度', obvious=True, group='尺寸', description='h')
    data.setup('宽度1', obvious=True, group='尺寸', description='b1')
    data.setup('半径5', obvious=True, group='尺寸', description='r5')
    data.setup('半径4', obvious=True, group='尺寸', description='r4')
    data.setup('高度1', obvious=True, group='尺寸', description='h1')
    data.setup('构件名称',obvious=True)
    data['replace'] = mf
    mf(data)
    p3d.launchData(data)

### 椭球体
from pyp3d import *
# 定义参数化模型
class 弧(Component):
    # 定义各个参数及其默认值
    def __init__(self):
        Component.__init__(self)
        self['a轴长度'] = Attr(1000.0, obvious=True, readonly = False)
        self['b轴长度'] = Attr(300.0, obvious=True)
        self['弧'] = Attr(None, show=True)
        self['路径'] = Attr(None, show=True)
        self['旋转角度'] = Attr(0,obvious = True, readonly = True)
        self['椭球'] = Attr(None, show=True)


        self.replace()
    @export
    # 开始写模型
    def replace(self):
        # 设置变量，同时调用参数(简化书写过程)
        L = self['a轴长度']
        W = self['b轴长度']
        sect = self['弧']
        path = self['路径']

        Angle = self['旋转角度']
        # 绘制模型
        sect = rotation(math.pi/180 * Angle) * scale(L,W) * Section(Arc(math.pi))
        #path = Line(Vec3(0,0,0), Vec3(500,500,500))
        path = Line(roty(pi*0.5)*scale(W,W)*Arc(pi*2))
        self['椭球'] = Sweep(sect, path)

        
# 输出模型
if __name__ == "__main__":
    FinalGeometry = 弧()
    place(FinalGeometry)


### 办公桌
import pyp3d as p3d # 导入pyp3d，可以直接使用pyp3d中的函数而无需前缀

def desk(data:p3d.P3DData)->None:
    H=data['桌子高度']
    L=data['桌子长度']
    W=data['桌子宽度']
    m=data['桌面不透明度']
    a=80 #桌腿宽度
    hc=40 #圆柱体高度
    hup=10 #上垫片高度
    hdown=30 #下垫片高度
    hglass=10 #桌面玻璃高度
    #桌腿=垫片+木桌腿+圆柱体+上垫片 以木桌腿左下角为原点
    aa=10 #下方垫片边长为a+aa
    ztbox1=p3d.Box(p3d.Vec3(-aa/2,-aa/2,0),p3d.Vec3(-aa/2,-aa/2,hdown),p3d.Vec3(1,0,0),p3d.Vec3(0,1,0),a+aa,a+aa,a+aa,a+aa).color(1,1,1,1)
    ztbox2=p3d.Box(p3d.Vec3(0,0,0),p3d.Vec3(0,0,H),p3d.Vec3(1,0,0),p3d.Vec3(0,1,0),a,a,a,a)
    ztcone1=p3d.Cone(p3d.Vec3(a/2,a/2,H),p3d.Vec3(a/2,a/2,H+hc),a/2,a/2)
    ztbox3=p3d.Box(p3d.Vec3(0,0,H+hc),p3d.Vec3(0,0,H+hc+hup),p3d.Vec3(1,0,0),p3d.Vec3(0,1,0),a,a,a,a)
    zt1=p3d.combine(ztbox1,ztbox2,ztcone1,ztbox3)
    zt2=p3d.translation(p3d.Vec3(L-a,0,0))*zt1
    zt3=p3d.translation(p3d.Vec3(0,W-a,0))*zt1
    zt4=p3d.translation(p3d.Vec3(L-a,W-a,0))*zt1
    zt=p3d.combine(zt1,zt2,zt3,zt4)

    ##桌面
    #顶面玻璃 先做一个厚30的玻璃，再布尔减掉中间一部分
    zmbox1=p3d.Box(p3d.Vec3(a/2,a/2,H+0.5*hc-30),p3d.Vec3(a/2,a/2,H+0.5*hc),p3d.Vec3(1,0,0),p3d.Vec3(0,1,0),L-a,W-a,L-a,W-a)
    #侧面玻璃 
    zmbox2=p3d.Box(p3d.Vec3(a/2+hglass,a/2+hglass,H+0.5*hc-30),p3d.Vec3(a/2+hglass,a/2+hglass,H+0.5*hc-hglass),p3d.Vec3(1,0,0),p3d.Vec3(0,1,0),L-a-2*hglass,W-a-2*hglass,L-a-2*hglass,W-a-2*hglass)
    zmbox=p3d.substract(zmbox1,zmbox2).color(0.5,0.5,0.5,m)
    #插座 给定插座边长cc 四角曲率半径cr 高度hcz
    cc=100
    cr=15
    hcz=45
    czbox1=p3d.Box(p3d.Vec3(cr,0,0),p3d.Vec3(cr,0,hcz),p3d.Vec3(1,0,0),p3d.Vec3(0,1,0),cc-2*cr,cc,cc-2*cr,cc)
    czbox2=p3d.Box(p3d.Vec3(0,cr,0),p3d.Vec3(0,cr,hcz),p3d.Vec3(1,0,0),p3d.Vec3(0,1,0),cc,cc-2*cr,cc,cc-2*cr)
    czcone1=p3d.Cone(p3d.Vec3(cr,cr,0),p3d.Vec3(cr,cr,hcz),cr,cr)
    czcone2=p3d.translation(p3d.Vec3(0,cc-2*cr,0))*czcone1
    czcone3=p3d.translation(p3d.Vec3(cc-2*cr,cc-2*cr,0))*czcone1
    czcone4=p3d.translation(p3d.Vec3(cc-2*cr,0,0))*czcone1
    czboxn=p3d.unite(czbox1,czbox2,czcone1,czcone2,czcone3,czcone4)
    #插孔
    czboxk1=p3d.Box(p3d.Vec3(37.5,16.5,hcz-10),p3d.Vec3(37.5,16.5,hcz),p3d.Vec3(1,0,0),p3d.Vec3(0,1,0),3,10,3,10)
    czboxk2=p3d.translation(p3d.Vec3(19,0,0))*czboxk1
    czboxk3=p3d.translation(p3d.Vec3(9.5,12,0))*czboxk1
    czboxk4=p3d.translation(p3d.Vec3(0,57,0))*czboxk1
    czboxk5=p3d.translation(p3d.Vec3(0,57,0))*czboxk2
    czk=p3d.combine(czboxk1,czboxk2,czboxk3,czboxk4,czboxk5)
    cz=p3d.translation(p3d.Vec3(100,W-a-100,H-50))*p3d.substract(czboxn,czk)

    #装饰品
    zscone1=p3d.Cone(p3d.Vec3(0,0,0),p3d.Vec3(250,0,0),45,45)
    zskcone1=p3d.Cone(p3d.Vec3(0,0,0),p3d.Vec3(250,0,0),42,42)
    zstem=p3d.substract(zscone1,zskcone1)
    zsbox=p3d.Box(p3d.Vec3(-60,60,-60),p3d.Vec3(-60,60,0),p3d.Vec3(1,0,0),p3d.Vec3(0,1,0),500,-500,500,-500)
    zs1=p3d.substract(zstem,zsbox)
    zscone2=p3d.Cone(p3d.Vec3(0,-60,24),p3d.Vec3(250,-60,25),25,25)
    zskcone2=p3d.Cone(p3d.Vec3(0,-60,24),p3d.Vec3(250,-60,25),22,22)
    zstem2=p3d.substract(zscone2,zskcone2)
    zsbox2=p3d.Box(p3d.Vec3(-30,30,24),p3d.Vec3(-30,30,60),p3d.Vec3(1,0,0),p3d.Vec3(0,1,0),300,-300,300,-300)
    zs2=p3d.substract(zstem2,zsbox2)
    
    zs=p3d.translation(p3d.Vec3(400,W-100,H+hglass))*p3d.unite(zs1,zs2)
    data['桌子'] =p3d.combine(zt,zmbox,cz,zs)
    # data['桌子'] =p3d.combine(zs)
   
if __name__ == "__main__":
    data = p3d.P3DData({
        '桌子高度':800,
        '桌子长度':1400,
        '桌子宽度': 600,
        '桌面不透明度':0.1,
        '构件名称':'办公桌'
        })
    data.set_view(-0.125*p3d.pi,-0.125*p3d.pi)
    data.setup('桌子', show=True)
    data.setup('桌子高度',obvious=True, group='办公桌', description='桌子高度')
    data.setup('桌子长度',obvious=True, group='办公桌', description='桌子长度')
    data.setup('桌子宽度',obvious=True, group='办公桌', description='桌子宽度')
    data.setup('桌面不透明度',obvious=True, group='办公桌', description='桌面不透明度')
    data.setup('构件名称',obvious=True)
    data['replace'] = desk
    desk(data)
    p3d.launchData(data)


### 弹簧
from pyp3d import *
# 扫掠体

class 弹簧(Component):
    def __init__(self):
        Component.__init__(self)
        self['弹簧'] = Attr(None, show=True)
        self['弹簧高度'] = Attr(100, obvious = True)
        self['步长'] = Attr(0.1, obvious=True,)
        self['弹簧螺旋半径'] = Attr(20, obvious=True,)
        self['弹簧半径'] = Attr(2, obvious=True, )
        self['弹簧间距'] = Attr(10, obvious = True)
        self.replace()
    @export
    def replace(self):
        r = self['弹簧半径']
        # 弹簧转过的总角度值（弧度制）
        t = self['弹簧高度'] *2*pi/ self['弹簧间距']
        R = self['弹簧螺旋半径']
        steplength = self['步长']
        space = self['弹簧间距']
        # 绘制弹簧截面
        section = rotate(Vec3(1,0,0), 0.5*pi) * (scale(r,r) * Section(Arc()))
        # 平移到旋转起点
        section = translate(Vec3(R,0,0)) * section 
        # 相邻截面的高度差（每步长截面上升的高度/单位步长截面上升的高度值）
        space_i = space/(2*pi)

        # 旋转截面、螺旋上升
        SectionArray = []
        # 使用linspace，得到总截面数
        for i in linspace(0, t, int(t//steplength)):
        # 旋转、平移截面到指定位置（即i对应的位置上）       
            SectionArray.append(translate(Vec3(0,0,space_i*i)) * (rotate(Vec3(0,0,1), i) * section))
        # 形成Loft几何体
        Test_Loft = Loft(*SectionArray)
        # 设置为光滑
        Test_Loft.smooth = True

        self['弹簧'] = Test_Loft

if __name__ == "__main__":
    place(弹簧())

### 环形弓件
from pyp3d import *
import math

def circularWorkpiece(data):
    R = data['环半径']
    r = data['管口半径']
    H = data['高度控制参数']
    alta = data['管口缩小参数']
    L = data['长度控制参数']

    contour = []
    contour_temp = []
    contours = []

    for i in range(L):
        for T in linspace(0, pi*2, 18):
            contour.append(Vec3((r-alta*i)*math.cos(T),0,(r-alta*i)*math.sin(T)))
        for c in contour:
            contour_temp.append(translation(Vec3(0,0,-H*i))
                * rotation(Vec3(0,0,1), i*pi/36)
                * translation(Vec3(R+(r-alta*i),0,0)) * c)
        contours.append(contour_temp)
        contour = []
        contour_temp = []
    
    circularWorkpiece = RuledSweepPlus(contours).color(0.5,0.5,0.5,1)
    data['环形工件'] = circularWorkpiece

if __name__ == "__main__":
    data = P3DData({
        '环半径': 1000,
        '管口半径': 200,
        '高度控制参数':2,
        '管口缩小参数':1.5,
        '长度控制参数':60,
        '构件名称':'环形工件'
    })
    data.set_view(0,0)
    data.setup('环形工件',  show=True)
    data.setup('环半径',  obvious=True, description='环半径')
    data.setup('管口半径',  obvious=True, description='管口半径')
    data.setup('高度控制参数',  obvious=True, description='高度控制参数')
    data.setup('管口缩小参数',  obvious=True, description='管口缩小参数')
    data.setup('长度控制参数',  obvious=True, description='长度控制参数')
    data.setup('构件名称',obvious=True)
    data['replace'] = circularWorkpiece
    circularWorkpiece(data)
    launchData(data)