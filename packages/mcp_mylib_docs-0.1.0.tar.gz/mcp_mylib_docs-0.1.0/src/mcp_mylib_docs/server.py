from mcp.server.fastmcp import FastMCP
import os
import re

# Initialize the MCP server
mcp = FastMCP("PythonComponentServer")

# Path to the documentation file
# Use relative path from this file's directory
DOC_FILE = os.path.join(os.path.dirname(__file__), "data", "python_component.md")

def read_full_docs() -> str:
    """Read the entire documentation file."""
    if not os.path.exists(DOC_FILE):
        return f"Error: Documentation file not found at {DOC_FILE}"
    try:
        with open(DOC_FILE, "r", encoding="utf-8") as f:
            return f.read()
    except Exception as e:
        return f"Error reading documentation: {str(e)}"

@mcp.resource("docs://python_component/full")
def get_full_documentation() -> str:
    """Get the full documentation for Python Component (pyp3d)."""
    return read_full_docs()

@mcp.resource("docs://python_component/metadata")
def get_doc_metadata() -> str:
    """Get metadata about the documentation file."""
    if not os.path.exists(DOC_FILE):
        return "Error: File not found"
    
    stat = os.stat(DOC_FILE)
    return f"File: {DOC_FILE}\nSize: {stat.st_size} bytes\nLast Modified: {stat.st_mtime}"

@mcp.tool()
def search_docs(query: str) -> str:
    """
    Search for a keyword or phrase in the documentation.
    Returns matching lines with context (line numbers).
    """
    content = read_full_docs()
    if content.startswith("Error"):
        return content
    
    lines = content.splitlines()
    matches = []
    for i, line in enumerate(lines):
        if query.lower() in line.lower():
            matches.append(f"Line {i+1}: {line.strip()}")
    
    if not matches:
        return f"No matches found for query: '{query}'"
    
    return "\n".join(matches)

@mcp.tool()
def read_section(section_header: str) -> str:
    """
    Read a specific section from the documentation based on its header.
    The section header search is case-insensitive and partial match.
    """
    content = read_full_docs()
    if content.startswith("Error"):
        return content
    
    lines = content.splitlines()
    section_content = []
    in_section = False
    
    # Simple markdown header parser
    # Looks for lines starting with #
    for line in lines:
        stripped = line.strip()
        if stripped.startswith("#"):
            # Check if this is the start of the section we want
            # Remove # characters and whitespace for comparison
            header_text = stripped.lstrip("#").strip()
            
            if section_header.lower() in header_text.lower():
                in_section = True
                section_content.append(line)
                continue
            elif in_section:
                # Stop at the next header
                break
        
        if in_section:
            section_content.append(line)
            
    if not section_content:
        return f"Section matching '{section_header}' not found."
        
    return "\n".join(section_content)

@mcp.prompt()
def explain_concept(concept: str) -> str:
    """
    Prompt template to ask the LLM to explain a concept based on the pyp3d documentation.
    """
    # Retrieve relevant context (naive search for now)
    context = search_docs(concept)
    
    return f"""Please explain the concept of '{concept}' in pyp3d based on the following documentation context:

{context}

If the context is insufficient, please state what is missing."""

def main():
    mcp.run()

if __name__ == "__main__":
    main()
