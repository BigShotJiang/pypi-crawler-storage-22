"""MCP Network JCD - MCP server for network device management."""

__version__ = "0.1.0"
__author__ = "MCP Network JCD Team"
