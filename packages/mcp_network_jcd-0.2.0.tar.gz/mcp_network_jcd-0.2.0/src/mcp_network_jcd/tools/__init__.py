"""MCP tools for network device management."""

from mcp_network_jcd.tools.paloalto import paloalto_query

__all__ = [
    "paloalto_query",
]
