"""MCP Network JCD tests."""
