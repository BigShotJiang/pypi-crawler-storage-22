import ClientNavbar from './ClientNavbar';

export default function Navbar() {
  return <ClientNavbar />;
}