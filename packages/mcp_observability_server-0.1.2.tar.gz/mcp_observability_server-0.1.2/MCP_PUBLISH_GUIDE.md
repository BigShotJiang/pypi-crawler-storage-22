# Manual Build and Publish to MCP Registry

This guide covers manually building the pip package and publishing it to both PyPI and the MCP registry.

## Overview

Publishing to the MCP registry is a two-step process:
1. **Publish to PyPI** - The Python package must be available on PyPI
2. **Submit to MCP Registry** - Submit your `server.json` to the MCP registry

## Part 1: Build the Pip Package

### Prerequisites

Install required build tools:

```bash
pip install --upgrade pip build twine
```

### Step 1: Pre-Build Checklist

Verify everything is ready:

```bash
# Run tests
pytest

# Check code quality
ruff check src tests
ruff format --check src tests

# Type checking (optional)
mypy src
```

### Step 2: Version Sync

Ensure versions match in both files:

**Check pyproject.toml:**
```bash
grep 'version =' pyproject.toml
```

**Check server.json:**
```bash
grep 'version' server.json
```

Both should show `0.1.1`. If not, update them to match.

### Step 3: Clean Previous Builds

Remove any existing build artifacts:

```bash
rm -rf dist/ build/ *.egg-info src/*.egg-info
find . -type d -name __pycache__ -exec rm -rf {} +
find . -type f -name "*.pyc" -delete
```

### Step 4: Build the Package

Build both source distribution and wheel:

```bash
python -m build
```

**Expected output:**
```
Successfully built mcp-observability-server-0.1.1.tar.gz and mcp_observability_server-0.1.1-py3-none-any.whl
```

**Files created in `dist/` directory:**
- `mcp-observability-server-0.1.1.tar.gz` (source distribution)
- `mcp_observability_server-0.1.1-py3-none-any.whl` (wheel)

### Step 5: Verify the Build

```bash
# Check for packaging errors
twine check dist/*

# Inspect the wheel contents
unzip -l dist/mcp_observability_server-0.1.1-py3-none-any.whl

# Inspect the source distribution
tar -tzf dist/mcp-observability-server-0.1.1.tar.gz | head -20
```

Expected: No errors from `twine check`

### Step 6: Test Installation Locally

```bash
# Create a test virtual environment
python -m venv test-env
source test-env/bin/activate  # On Windows: test-env\Scripts\activate

# Install from the wheel
pip install dist/mcp_observability_server-0.1.1-py3-none-any.whl

# Test the installation
mcp-observability --help
python -c "import mcp_observability; print('✓ Package imports successfully')"

# Cleanup
deactivate
rm -rf test-env
```

## Part 2: Publish to PyPI

### Option A: Test on TestPyPI First (Recommended)

**Step 1: Create TestPyPI Account**
- Visit: https://test.pypi.org/account/register/
- Enable 2FA

**Step 2: Generate API Token**
- Visit: https://test.pypi.org/manage/account/token/
- Create token named: `mcp-observability-server`

**Step 3: Upload to TestPyPI**

```bash
twine upload --repository testpypi dist/* \
    --username __token__ \
    --password pypi-YOUR_TEST_TOKEN_HERE
```

**Step 4: Test Installation from TestPyPI**

```bash
pip install --index-url https://test.pypi.org/simple/ \
    --extra-index-url https://pypi.org/simple/ \
    mcp-observability-server
```

### Option B: Publish to Production PyPI

**Step 1: Create PyPI Account**
- Visit: https://pypi.org/account/register/
- Enable 2FA (required)

**Step 2: Generate API Token**
- Visit: https://pypi.org/manage/account/token/
- Create token named: `mcp-observability-server`
- Copy the token (starts with `pypi-`)

**Step 3: Upload to PyPI**

```bash
twine upload dist/* \
    --username __token__ \
    --password pypi-YOUR_PRODUCTION_TOKEN_HERE
```

**Alternative: Using .pypirc**

Create `~/.pypirc`:

```ini
[distutils]
index-servers =
    pypi
    testpypi

[pypi]
username = __token__
password = pypi-YOUR_PRODUCTION_TOKEN

[testpypi]
repository = https://test.pypi.org/legacy/
username = __token__
password = pypi-YOUR_TEST_TOKEN
```

Set permissions:
```bash
chmod 600 ~/.pypirc
```

Then upload with:
```bash
twine upload dist/*
```

**Step 4: Verify Publication**

- Visit: https://pypi.org/project/mcp-observability-server/
- Test installation:

```bash
pip install mcp-observability-server
mcp-observability --help
```

## Part 3: Publish to MCP Registry

Once your package is on PyPI, submit it to the MCP registry.

### Step 1: Verify server.json

Your [server.json](server.json) should look like this:

```json
{
  "$schema": "https://static.modelcontextprotocol.io/schemas/2025-07-09/server.schema.json",
  "name": "io.github.gagandeeppra/mcp-observability-server",
  "description": "MCP server for querying logs from observability platforms with unified search and tracing",
  "repository": {
    "url": "https://github.com/gagandeeppra/mcp-observability-server",
    "source": "github"
  },
  "version": "0.1.1",
  "packages": [
    {
      "registryType": "pypi",
      "identifier": "mcp-observability-server",
      "version": "0.1.1",
      "transport": {
        "type": "stdio"
      }
    }
  ]
}
```

### Step 2: Submit to MCP Registry

There are multiple ways to submit to the MCP registry:

#### Method 1: Via GitHub (Anthropic's MCP Servers Repository)

1. **Fork the MCP servers repository:**
   ```bash
   # Visit: https://github.com/modelcontextprotocol/servers
   # Click "Fork"
   ```

2. **Clone your fork:**
   ```bash
   git clone https://github.com/YOUR_USERNAME/servers.git mcp-servers
   cd mcp-servers
   ```

3. **Add your server:**
   ```bash
   # Copy your server.json to the registry
   mkdir -p src/mcp-observability-server
   cp /path/to/your/server.json src/mcp-observability-server/
   
   # Or create a link to your repository
   # Add entry to the main registry index
   ```

4. **Create Pull Request:**
   ```bash
   git checkout -b add-mcp-observability-server
   git add .
   git commit -m "Add mcp-observability-server to registry"
   git push origin add-mcp-observability-server
   ```

5. **Submit PR:**
   - Go to https://github.com/modelcontextprotocol/servers
   - Create Pull Request from your fork
   - Fill in the PR template with:
     - Server description
     - Link to PyPI package
     - Link to GitHub repository
     - Brief explanation of functionality

#### Method 2: Using MCP CLI (if available)

If there's an official MCP CLI tool:

```bash
# Install MCP CLI
pip install mcp-cli  # (if it exists)

# Publish server
mcp publish --server-json server.json

# Or
mcp-cli register --file server.json
```

#### Method 3: Manual Registry Link

If the MCP registry automatically indexes PyPI packages with the `mcp` keyword:

1. **Ensure your [pyproject.toml](pyproject.toml#L17-L26) has MCP keywords:**
   ```toml
   keywords = [
       "mcp",
       "model-context-protocol",
       "observability",
       ...
   ]
   ```

2. **Ensure your README mentions MCP:**
   - Link to Model Context Protocol
   - Usage examples with Claude Desktop
   - MCP server configuration

3. **The registry may auto-discover your package**

### Step 3: Verify Registry Submission

Check if your server appears:

- **MCP Registry**: https://modelcontextprotocol.io/servers (or wherever the official registry is)
- **GitHub Registry**: https://github.com/modelcontextprotocol/servers
- **Search**: Look for "mcp-observability-server"

### Step 4: Update Documentation

Add a badge to your [README.md](README.md):

```markdown
[![MCP Server](https://img.shields.io/badge/MCP-Server-blue)](https://modelcontextprotocol.io/)
[![PyPI version](https://badge.fury.io/py/mcp-observability-server.svg)](https://pypi.org/project/mcp-observability-server/)
```

## Part 4: Post-Publication Checklist

- [ ] Package published to PyPI
- [ ] Package installs correctly: `pip install mcp-observability-server`
- [ ] Command works: `mcp-observability --help`
- [ ] server.json submitted to MCP registry
- [ ] GitHub release created and tagged
- [ ] Documentation updated with installation instructions
- [ ] Announcement made (optional)

## Git Tagging and Release

Create a GitHub release:

```bash
# Tag the release
git tag -a v0.1.1 -m "Release version 0.1.1 - Initial MCP registry publication"

# Push the tag
git push origin v0.1.1

# Create release on GitHub
# Visit: https://github.com/gagandeeppra/mcp-observability-server/releases/new
# - Select tag: v0.1.1
# - Title: "v0.1.1 - Initial Release"
# - Description: Copy from CHANGELOG.md
# - Attach dist/ files (optional)
```

## Troubleshooting

### PyPI Upload Fails

**Error: "File already exists"**
- You cannot re-upload the same version
- Bump version in `pyproject.toml` and `server.json`
- Rebuild and re-upload

**Error: "Invalid credentials"**
- Ensure username is `__token__`
- Verify token starts with `pypi-`
- Check token hasn't expired

**Error: "Invalid distribution"**
- Run: `twine check dist/*`
- Fix reported issues
- Rebuild package

### Installation Fails

**Error: "No module named 'mcp_observability'"**
- Check package structure
- Verify `src/mcp_observability/__init__.py` exists
- Check `pyproject.toml` has correct `packages` setting

**Error: "Command not found: mcp-observability"**
- Check `[project.scripts]` in `pyproject.toml`
- Reinstall: `pip install --force-reinstall mcp-observability-server`

### MCP Registry Submission

**Server not appearing in registry:**
- Verify server.json follows schema
- Check package is available on PyPI
- Ensure PR was merged (if using GitHub method)
- Allow time for indexing (may take hours/days)

## Version Update Workflow

When releasing a new version:

1. **Update version in both files:**
   ```bash
   # pyproject.toml
   version = "0.1.2"
   
   # server.json
   "version": "0.1.2"
   # and in packages array
   "version": "0.1.2"
   ```

2. **Update CHANGELOG.md**

3. **Commit changes:**
   ```bash
   git add pyproject.toml server.json CHANGELOG.md
   git commit -m "Bump version to 0.1.2"
   git push
   ```

4. **Repeat build and publish steps above**

## Automated Publishing

For future releases, consider setting up GitHub Actions (see [.github/workflows/publish.yml](.github/workflows/publish.yml)).

Then publishing becomes:
```bash
git tag v0.1.2
git push origin v0.1.2
# GitHub Actions automatically builds and publishes
```

## Resources

- **Model Context Protocol**: https://modelcontextprotocol.io/
- **MCP Servers Repository**: https://github.com/modelcontextprotocol/servers
- **PyPI**: https://pypi.org/
- **Python Packaging Guide**: https://packaging.python.org/
- **Twine Documentation**: https://twine.readthedocs.io/

## Quick Command Reference

```bash
# Build
python -m build

# Check
twine check dist/*

# Upload to TestPyPI
twine upload --repository testpypi dist/*

# Upload to PyPI
twine upload dist/*

# Test install
pip install mcp-observability-server

# Tag release
git tag -a v0.1.1 -m "Release v0.1.1"
git push origin v0.1.1
```
