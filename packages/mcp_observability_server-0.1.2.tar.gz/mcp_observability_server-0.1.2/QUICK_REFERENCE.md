# 📦 Quick Reference: Build & Publish

## TL;DR - Fastest Path to Publishing

### One-Command Publishing
```bash
# Linux/Mac
chmod +x build.sh
./build.sh --pypi

# Windows
build.bat --pypi
```

### Manual Commands
```bash
# 1. Clean & Build
rm -rf dist/ && python -m build

# 2. Upload to PyPI
twine upload dist/* --username __token__ --password pypi-YOUR_TOKEN

# 3. Verify
pip install mcp-observability-server
```

---

## 📋 Command Cheat Sheet

### Build Commands
```bash
# Install tools
pip install --upgrade pip build twine

# Clean previous builds
rm -rf dist/ build/ *.egg-info src/*.egg-info

# Build package
python -m build

# Verify package
twine check dist/*

# Test install locally
pip install dist/*.whl
```

### PyPI Publishing
```bash
# Test on TestPyPI
twine upload --repository testpypi dist/*

# Publish to production PyPI
twine upload dist/*

# With credentials inline
twine upload dist/* --username __token__ --password pypi-YOUR_TOKEN
```

### Git Tagging
```bash
# Tag release
git tag -a v0.1.1 -m "Release v0.1.1"

# Push tag
git push origin v0.1.1

# List tags
git tag -l
```

### Testing
```bash
# Run tests
pytest

# With coverage
pytest --cov=src/mcp_observability

# Lint
ruff check src tests

# Format
ruff format src tests

# Type check
mypy src
```

---

## 🎯 Build Script Options

### Linux/Mac (build.sh)
```bash
chmod +x build.sh

./build.sh              # Build only
./build.sh --test-pypi  # Build + upload to TestPyPI
./build.sh --pypi       # Build + upload to PyPI
```

### Windows (build.bat)
```cmd
build.bat               # Build only
build.bat --test-pypi   # Build + upload to TestPyPI
build.bat --pypi        # Build + upload to PyPI
```

---

## 📝 Pre-Publish Checklist

### Before Building
- [ ] Tests pass: `pytest`
- [ ] No lint errors: `ruff check src tests`
- [ ] Version updated in `pyproject.toml`
- [ ] Version updated in `server.json` (both places)
- [ ] `CHANGELOG.md` updated
- [ ] All changes committed

### Before Publishing to PyPI
- [ ] Package built: `python -m build`
- [ ] Package verified: `twine check dist/*`
- [ ] Tested locally: `pip install dist/*.whl`
- [ ] PyPI account created with 2FA enabled
- [ ] API token generated

### After Publishing to PyPI
- [ ] Package appears on PyPI
- [ ] Installation works: `pip install mcp-observability-server`
- [ ] Command works: `mcp-observability --help`
- [ ] Git tag created and pushed
- [ ] GitHub release created

### For MCP Registry
- [ ] Package published to PyPI (required first)
- [ ] `server.json` up to date
- [ ] Fork https://github.com/modelcontextprotocol/servers
- [ ] Submit Pull Request with your server
- [ ] Wait for PR merge

---

## 🔑 Setting Up PyPI Credentials

### Create .pypirc file
```bash
cat > ~/.pypirc << 'EOF'
[distutils]
index-servers =
    pypi
    testpypi

[pypi]
username = __token__
password = pypi-REPLACE_WITH_YOUR_TOKEN

[testpypi]
repository = https://test.pypi.org/legacy/
username = __token__
password = pypi-REPLACE_WITH_YOUR_TEST_TOKEN
EOF

chmod 600 ~/.pypirc
```

### Get API Tokens
- **PyPI**: https://pypi.org/manage/account/token/
- **TestPyPI**: https://test.pypi.org/manage/account/token/

---

## 🚨 Common Issues & Fixes

### "File already exists" error
**Problem**: Can't upload same version twice  
**Fix**: Bump version in `pyproject.toml` and `server.json`

### Command not found after install
**Problem**: Entry point not working  
**Fix**: Reinstall with `pip install --force-reinstall mcp-observability-server`

### Import error after install
**Problem**: Package structure issue  
**Fix**: Check `src/mcp_observability/__init__.py` exists

### Versions don't match
**Problem**: `pyproject.toml` and `server.json` have different versions  
**Fix**: Update both to same version:
```bash
# In pyproject.toml
version = "0.1.1"

# In server.json (two places)
"version": "0.1.1"
```

---

## 📂 Files Overview

| File | Purpose |
|------|---------|
| `pyproject.toml` | Python package configuration |
| `server.json` | MCP server metadata |
| `MANIFEST.in` | Include non-Python files in package |
| `build.sh` | Automated build script (Linux/Mac) |
| `build.bat` | Automated build script (Windows) |
| `MCP_PUBLISH_GUIDE.md` | Complete publishing guide |
| `CHANGELOG.md` | Version history |

---

## 🔗 Important Links

- **PyPI Package**: https://pypi.org/project/mcp-observability-server/
- **GitHub Repo**: https://github.com/gagandeeppra/mcp-observability-server
- **MCP Protocol**: https://modelcontextprotocol.io/
- **MCP Servers**: https://github.com/modelcontextprotocol/servers
- **Python Packaging**: https://packaging.python.org/

---

## 📚 Documentation Files

- **[MCP_PUBLISH_GUIDE.md](MCP_PUBLISH_GUIDE.md)** - Complete step-by-step guide
- **[BUILD_AND_PUBLISH.md](BUILD_AND_PUBLISH.md)** - PyPI publishing details
- **[QUICK_START_PUBLISH.md](QUICK_START_PUBLISH.md)** - FastTrack publishing
- **[QUICK_REFERENCE.md](QUICK_REFERENCE.md)** - This file
- **[CHANGELOG.md](CHANGELOG.md)** - Version history

---

## 💡 Pro Tips

1. **Always test on TestPyPI first** before publishing to production
2. **Use build scripts** (`build.sh`/`build.bat`) to avoid manual errors
3. **Keep versions synced** between `pyproject.toml` and `server.json`
4. **Tag your releases** in git for easy version tracking
5. **Update CHANGELOG.md** before each release
6. **Test installation** from PyPI before submitting to MCP registry

---

## 🎬 Complete Workflow Example

```bash
# 1. Make changes to code
vim src/mcp_observability/server.py

# 2. Update version
vim pyproject.toml  # Set version = "0.1.2"
vim server.json     # Set "version": "0.1.2" (in 2 places)

# 3. Update changelog
vim CHANGELOG.md

# 4. Run tests
pytest

# 5. Commit changes
git add .
git commit -m "Release v0.1.2: Add new feature"
git push

# 6. Build and publish
./build.sh --pypi

# 7. Tag release
git tag -a v0.1.2 -m "Release v0.1.2"
git push origin v0.1.2

# 8. Create GitHub release
# Visit: https://github.com/gagandeeppra/mcp-observability-server/releases/new

# 9. Submit to MCP registry
# Follow instructions in MCP_PUBLISH_GUIDE.md
```

---

**Need more details?** See [MCP_PUBLISH_GUIDE.md](MCP_PUBLISH_GUIDE.md) for complete documentation.
