# Logging Guide

## Overview

The MCP Observability Server includes comprehensive logging to help you debug issues, monitor operations, and understand what's happening under the hood.

## Configuration

### Setting Log Level

The log level is controlled by the `MCP_LOG_LEVEL` environment variable. If not set, it defaults to `INFO`.

**Option 1: Environment Variable**

```bash
export MCP_LOG_LEVEL=DEBUG
```

**Option 2: In .env File**

```bash
# Add to your .env file
MCP_LOG_LEVEL=DEBUG
```

**Option 3: Programmatically**

```python
from mcp_observability.logging_config import setup_logging

# Setup with specific level
setup_logging("DEBUG")
```

### Available Log Levels

| Level | Description | Use Case |
|-------|-------------|----------|
| `DEBUG` | Most verbose; includes query details, API calls, parameters | Development, troubleshooting |
| `INFO` | General operational messages | Default for production |
| `WARNING` | Potential issues that don't prevent operation | Production monitoring |
| `ERROR` | Errors that affect functionality | Production, alerts |
| `CRITICAL` | Severe errors that may stop the server | Production, critical alerts |

## What Gets Logged

### Server Initialization (`INFO`)
- Server startup
- Configuration file loading
- Provider initialization
- Tool registration

```
2026-02-13 10:30:15 - mcp_observability.server - INFO - Starting MCP Observability Server
2026-02-13 10:30:15 - mcp_observability.server - INFO - Initializing MCP Observability Server
2026-02-13 10:30:15 - mcp_observability.server - INFO - Server initialized with 1 active provider(s)
```

### Configuration Loading (`INFO`, `DEBUG`)
- Config file paths
- Provider configurations created
- Environment variable substitution

```
2026-02-13 10:30:15 - mcp_observability.utils - INFO - Loading config from: config.yaml
2026-02-13 10:30:15 - mcp_observability.utils - DEBUG - Config loaded successfully with 1 provider(s)
2026-02-13 10:30:15 - mcp_observability.utils - INFO - Creating configurations for 1 provider(s)
```

### Provider Operations (`INFO`, `DEBUG`)
- Provider initialization
- Health checks
- Credential validation
- Query execution and results

```
2026-02-13 10:30:15 - mcp_observability.providers.newrelic - INFO - New Relic provider initialized for region: US
2026-02-13 10:30:16 - mcp_observability.providers.newrelic - DEBUG - Validating New Relic credentials
2026-02-13 10:30:16 - mcp_observability.providers.newrelic - INFO - New Relic credentials validated successfully
```

### Tool Invocations (`INFO`, `DEBUG`)
- Tool calls with names
- Arguments passed
- Query parameters
- Results and timing

```
2026-02-13 10:30:20 - mcp_observability.server - INFO - Tool called: query_logs
2026-02-13 10:30:20 - mcp_observability.server - DEBUG - Tool arguments: {'start_time': '1h', 'query': 'error'}
2026-02-13 10:30:20 - mcp_observability.server - INFO - Querying 1 provider(s): ['newrelic']
2026-02-13 10:30:21 - mcp_observability.server - INFO - newrelic: Retrieved 42 log(s)
```

### Queries and API Calls (`DEBUG`)
- NRQL queries (New Relic)
- KQL queries (Azure)
- API endpoints called
- Request parameters

```
2026-02-13 10:30:20 - mcp_observability.providers.newrelic - DEBUG - Querying New Relic logs: query=error, severity=None, service=None
2026-02-13 10:30:20 - mcp_observability.providers.newrelic - DEBUG - NRQL query: SELECT * FROM Log WHERE message LIKE '%error%' SINCE 1707825620000 UNTIL 1707829220000 LIMIT 100
2026-02-13 10:30:21 - mcp_observability.providers.newrelic - INFO - New Relic query returned 42 log(s)
```

### Errors and Exceptions (`ERROR`, `CRITICAL`)
- API failures
- Authentication errors
- Query failures
- Stack traces (with DEBUG level)

```
2026-02-13 10:30:21 - mcp_observability.providers.newrelic - ERROR - HTTP error querying New Relic: 401 Unauthorized
2026-02-13 10:30:21 - mcp_observability.server - ERROR - newrelic: Query failed - 401 Unauthorized
```

## Common Logging Patterns

### Debugging Query Issues

Set to DEBUG level to see full query details:

```bash
export MCP_LOG_LEVEL=DEBUG
python -m mcp_observability.server config.yaml
```

Look for:
- The actual NRQL/KQL query being executed
- Time ranges being used
- Filters applied
- Results returned

### Monitoring Production

Use INFO level for production monitoring:

```bash
export MCP_LOG_LEVEL=INFO
```

You'll see:
- Server start/stop
- Tool invocations
- Result counts
- Provider health status

### Investigating Errors

When troubleshooting errors, use DEBUG level and look for:

1. **Provider initialization errors** - Check credentials and configuration
2. **Query failures** - Review the actual query being sent
3. **API errors** - Check HTTP status codes and error messages
4. **Health check failures** - Verify network connectivity and permissions

## Log Output Format

All logs follow this format:

```
TIMESTAMP - LOGGER_NAME - LEVEL - MESSAGE
```

Example:
```
2026-02-13 10:30:15 - mcp_observability.server - INFO - Starting MCP Observability Server
```

### Logger Names

- `mcp_observability.server` - Main server operations
- `mcp_observability.utils` - Configuration and utilities
- `mcp_observability.providers.base` - Base provider functionality
- `mcp_observability.providers.newrelic` - New Relic provider
- `mcp_observability.providers.azure` - Azure provider

## Redirecting Logs

Logs are written to `stderr` by default. You can redirect them to a file:

```bash
# Redirect logs to file
python -m mcp_observability.server config.yaml 2> server.log

# Redirect logs and also see them on console
python -m mcp_observability.server config.yaml 2>&1 | tee server.log
```

## Integration with Monitoring Tools

### Structured Logging

For JSON structured logging (useful for log aggregation tools), you can extend the logging configuration:

```python
import json
import logging
from mcp_observability.logging_config import get_logger

class JSONFormatter(logging.Formatter):
    def format(self, record):
        log_data = {
            "timestamp": self.formatTime(record),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }
        if record.exc_info:
            log_data["exception"] = self.formatException(record.exc_info)
        return json.dumps(log_data)

# Configure JSON logging
logger = get_logger("server")
handler = logging.StreamHandler()
handler.setFormatter(JSONFormatter())
logger.addHandler(handler)
```

### Log Aggregation

The logs can be sent to various log aggregation services:
- **Splunk** - Use Splunk forwarder
- **Elasticsearch** - Use filebeat or logstash

## Best Practices

1. **Use INFO for production** - Provides good visibility without noise
2. **Use DEBUG for development** - Shows detailed query information
3. **Don't log sensitive data** - Credentials are masked by default
4. **Monitor ERROR logs** - Set up alerts for errors in production
5. **Rotate log files** - Use logrotate or similar tools for file-based logging
6. **Include context** - Logs include provider names, query IDs, and timing

## Troubleshooting Logging

### Logs not appearing?

1. Check that stderr is not being suppressed
2. Verify MCP_LOG_LEVEL is set correctly
3. Ensure logging is initialized (automatic on server start)

### Too verbose?

Change log level to WARNING or ERROR:

```bash
export MCP_LOG_LEVEL=WARNING
```

### Need more details?

Use DEBUG level:

```bash
export MCP_LOG_LEVEL=DEBUG
```

## Example: Debugging a Query

Here's a full example of logs during a query operation (DEBUG level):

```
2026-02-13 10:30:20 - mcp_observability.server - INFO - Tool called: query_logs
2026-02-13 10:30:20 - mcp_observability.server - DEBUG - Tool arguments: {'start_time': '1h', 'end_time': 'now', 'query': 'error', 'severity': ['error', 'critical'], 'limit': 50}
2026-02-13 10:30:20 - mcp_observability.server - DEBUG - Time range: 2026-02-13 09:30:20 to 2026-02-13 10:30:20
2026-02-13 10:30:20 - mcp_observability.server - DEBUG - Filtering by severity: [LogSeverity.ERROR, LogSeverity.CRITICAL]
2026-02-13 10:30:20 - mcp_observability.server - INFO - Querying 1 provider(s): ['newrelic']
2026-02-13 10:30:20 - mcp_observability.providers.newrelic - DEBUG - Querying New Relic logs: query=error, severity=[LogSeverity.ERROR, LogSeverity.CRITICAL], service=None
2026-02-13 10:30:20 - mcp_observability.providers.newrelic - DEBUG - NRQL query: SELECT * FROM Log WHERE message LIKE '%error%' AND level IN ('ERROR', 'CRITICAL') SINCE 1707825620000 UNTIL 1707829220000 LIMIT 50
2026-02-13 10:30:21 - mcp_observability.providers.newrelic - INFO - New Relic query returned 12 log(s)
2026-02-13 10:30:21 - mcp_observability.server - INFO - newrelic: Retrieved 12 log(s)
2026-02-13 10:30:21 - mcp_observability.server - INFO - Total logs retrieved: 12
```

This shows the complete flow from tool invocation to results.
