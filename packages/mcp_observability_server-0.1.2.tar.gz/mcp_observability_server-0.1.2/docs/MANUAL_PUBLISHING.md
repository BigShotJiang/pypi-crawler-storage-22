# Manual Publishing Guide for MCP Registry

This guide covers the manual publishing process for the MCP Observability Server.

## Prerequisites

1. **Package must be on PyPI first** - The MCP registry requires the package to be available on PyPI
2. **MCP CLI installed**: `pip install "mcp[cli]>=1.26.0"`
3. **MCP Registry Token** - Get from https://modelcontextprotocol.io/

## Step 1: Validate server.json

Run the validation script to ensure server.json is correct:

```bash
python scripts/validate_server_json.py
```

This will check:
- Description length (max 100 chars)
- Required fields present
- Schema validation
- Package configuration

## Step 2: Build and Publish to PyPI

### Option A: Using trusted publishing (recommended for GitHub)

1. Configure trusted publishing on PyPI:
   - Go to https://pypi.org/manage/account/publishing/
   - Add GitHub as trusted publisher

2. Build the package:
   ```bash
   pip install build
   python -m build
   ```

3. Publish using GitHub Actions or manually with token

### Option B: Using API token

1. Build the package:
   ```bash
   pip install build
   python -m build
   ```

2. Publish to PyPI:
   ```bash
   pip install twine
   twine upload dist/*
   ```

3. Enter your PyPI credentials when prompted

## Step 3: Wait for PyPI to Index

After publishing to PyPI, wait 2-5 minutes for the package to be indexed and available.

Verify availability:
```bash
pip index versions mcp-observability-server
```

## Step 4: Set MCP Registry Token

Set your MCP registry token as an environment variable:

```bash
export MCP_REGISTRY_TOKEN="your-token-here"
```

Or create a `.env` file (don't commit this!):
```
MCP_REGISTRY_TOKEN=your-token-here
```

## Step 5: Publish to MCP Registry

Run the MCP publish command:

```bash
mcp publish
```

This will:
1. Read `server.json` in the current directory
2. Validate the configuration
3. Submit to the MCP registry
4. Return the submission status

## Troubleshooting

### Error: "registryType is not present"

The publish tool may be converting camelCase to snake_case. Check your MCP CLI version:

```bash
mcp --version
pip install --upgrade "mcp[cli]"
```

### Error: "Description exceeds 100 characters"

Edit [server.json](../server.json) and shorten the description:

```bash
# Current length
python -c "import json; print(len(json.load(open('server.json'))['description']))"
```

### Error: "Package not found on PyPI"

Ensure the package is published to PyPI first and wait a few minutes for indexing:

```bash
# Check if package exists
curl https://pypi.org/pypi/mcp-observability-server/json
```

### Error: "Invalid token"

1. Verify token is set: `echo $MCP_REGISTRY_TOKEN`
2. Get a new token from https://modelcontextprotocol.io/
3. Ensure no extra whitespace in token

## Quick Commands Reference

```bash
# Validate server.json
python scripts/validate_server_json.py

# Build package
python -m build

# Publish to PyPI (with token)
twine upload dist/*

# Publish to MCP Registry
export MCP_REGISTRY_TOKEN="your-token"
mcp publish

# Check package on PyPI
pip index versions mcp-observability-server

# Check MCP CLI version
mcp --version
```

## server.json Configuration

Current configuration:
- **Name**: `io.github.gagandeeppra/mcp-observability-server`
- **Package**: `mcp-observability-server`
- **Version**: `0.1.0`
- **Registry**: PyPI
- **Transport**: stdio

## Version Updates

When releasing a new version:

1. Update version in `pyproject.toml`
2. Update version in `server.json` (both root and package level)
3. Repeat Steps 2-5 above
4. Create a GitHub release (optional)

## Resources

- MCP Registry: https://modelcontextprotocol.io/
- PyPI: https://pypi.org/
- MCP Documentation: https://github.com/modelcontextprotocol/registry
