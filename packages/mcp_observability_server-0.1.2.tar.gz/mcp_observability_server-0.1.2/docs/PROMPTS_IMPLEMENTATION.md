# MCP Prompts Implementation

**Date:** February 16, 2026  
**Feature:** High-priority MCP prompts for guided observability workflows

## Summary

Implemented 5 high-priority MCP prompts that provide structured, guided workflows for common SRE and observability tasks. These prompts chain multiple tool calls together and provide comprehensive analysis frameworks.

## Prompts Implemented

### 1. `investigate-incident` ⭐ HIGH PRIORITY
**File:** `src/mcp_observability/prompts/incident.py`
- **Purpose:** Systematic incident investigation workflow
- **Use case:** Active production incidents requiring thorough investigation
- **Workflow:** 
  1. Get recent errors
  2. Identify patterns
  3. Investigate traces
  4. Check system health
  5. Analyze time ranges
  6. Generate summary with recommendations

### 2. `health-check-report` ⭐ HIGH PRIORITY
**File:** `src/mcp_observability/prompts/health.py`
- **Purpose:** Comprehensive health status report generation
- **Use case:** Daily monitoring, system status overviews
- **Workflow:**
  1. Check all provider health
  2. Analyze recent errors
  3. Calculate error statistics
  4. Check active traces
  5. Catalog services
  6. Generate formatted report

### 3. `post-deployment-check` ⭐ HIGH PRIORITY
**File:** `src/mcp_observability/prompts/deployment.py`
- **Purpose:** Deployment validation and verification
- **Use case:** CI/CD pipelines, post-deployment validation
- **Workflow:**
  1. Define baseline and current periods
  2. Get current errors
  3. Get baseline errors
  4. Compare error rates
  5. Identify new error types
  6. Analyze traces
  7. Generate deployment recommendation (PROCEED/MONITOR/ROLLBACK)

### 4. `trace-flow-analysis` ⭐ HIGH PRIORITY
**File:** `src/mcp_observability/prompts/trace_analysis.py`
- **Purpose:** Distributed trace execution flow analysis
- **Use case:** Debugging distributed systems, understanding request flow
- **Workflow:**
  1. Retrieve all trace logs
  2. Construct timeline
  3. Map service call chain
  4. Analyze timing and performance
  5. Detect errors
  6. Analyze spans and dependencies
  7. Generate flow analysis report

### 5. `root-cause-analysis`
**File:** `src/mcp_observability/prompts/incident.py`
- **Purpose:** Deep root cause investigation
- **Use case:** Complex failures, cascading issues
- **Workflow:**
  1. Gather initial evidence
  2. Build failure timeline
  3. Analyze trace flow
  4. Gather context
  5. Recognize patterns
  6. Formulate root cause with evidence
  7. Provide prevention recommendations

## Files Created

```
src/mcp_observability/prompts/
├── __init__.py                    # Module exports
├── incident.py                    # Incident investigation prompts
├── health.py                      # Health monitoring prompts
├── deployment.py                  # Deployment validation prompts
├── trace_analysis.py              # Trace flow analysis prompts
└── README.md                      # Comprehensive prompts documentation
```

## Files Modified

### `src/mcp_observability/server.py`
- Added import for `PromptMessage` type
- Added imports for all prompt creation functions
- Registered 5 prompts using `@mcp.prompt()` decorators:
  - `investigate_incident()`
  - `root_cause_analysis()`
  - `health_check_report()`
  - `post_deployment_check()`
  - `trace_flow_analysis()`

### `README.md`
- Added "Guided Workflows (Prompts)" section with examples
- Updated Features list to include guided workflows
- Updated Project Structure to show prompts folder
- Added link to detailed prompts documentation

## Key Features

### Structured Workflows
Each prompt provides:
- Clear objectives
- Step-by-step instructions
- Tool usage examples
- Analysis guidelines
- Report templates
- Decision criteria
- Actionable recommendations

### Flexibility
- Optional parameters for customization
- Can skip steps as needed
- Combine multiple prompts
- Adapt to specific use cases

### Quality Guidelines
All prompts include:
- Best practices for analysis
- Common patterns to identify
- Quality criteria for reports
- Visual formatting guidance
- Examples and templates

## Usage Examples

### In Claude Desktop

**Basic usage:**
```
Use the investigate-incident prompt
```

**With parameters:**
```
Use the post-deployment-check prompt for user-service that was deployed 15 minutes ago
```

**Customized workflow:**
```
Use the trace-flow-analysis prompt for trace ID abc123-def456
```

## Benefits

1. **Reduced MTTR** - Structured approaches lead to faster incident resolution
2. **Consistency** - Standard workflows across team
3. **Knowledge Transfer** - Best practices encoded in prompts
4. **Onboarding** - New team members learn by using prompts
5. **Quality** - Comprehensive analysis every time
6. **Documentation** - Prompts generate structured reports

## Testing

To test the prompts:

1. Start the MCP server:
```bash
python -m mcp_observability.server config.yaml
```

2. In Claude Desktop, invoke prompts:
```
Show me available prompts
Use the health-check-report prompt
```

3. Or use MCP Inspector:
```bash
npx @modelcontextprotocol/inspector \
  python -m mcp_observability.server config.yaml
```

## Future Enhancements

Potential additional prompts:
- `service-discovery` - Discover and catalog services
- `debug-timeout-issues` - Investigate timeout patterns
- `weekly-reliability-report` - Generate SLO reports
- `error-pattern-analysis` - Analyze error trends over time
- `capacity-planning` - Resource usage analysis
- `daily-sre-summary` - Morning standup report

## Documentation

- **Main README:** Updated with prompts overview and examples
- **Prompts README:** Comprehensive guide in `src/mcp_observability/prompts/README.md`
- **Inline docs:** All prompt functions have detailed docstrings
- **This file:** Implementation summary and changelog

## Notes

- All prompts follow consistent structure and formatting
- Prompts are designed to work with existing tools
- No breaking changes to existing functionality
- Fully backward compatible
- Ready for production use

## Related Issues

This implementation addresses the need for:
- Structured incident response workflows
- Consistent deployment validation
- Systematic root cause analysis
- Better onboarding for new team members
- Encoded SRE best practices

---

**Status:** ✅ Complete and ready for use
**Priority:** High - Core SRE functionality
**Impact:** Significantly improves workflow efficiency
