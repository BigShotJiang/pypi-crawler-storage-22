# MCP Resources Documentation

This document describes all the MCP resources exposed by the observability server. Resources provide read-only access to observability data across multiple platforms.

## Overview

Resources are accessed using URI patterns. The server supports the following resource types:

1. **Log Resources** - Access to logs from observability providers
2. **Health Resources** - Provider health and connectivity status
3. **Trace Resources** - Distributed tracing information
4. **File Resources** - Exported log files
5. **Configuration Resources** - Server configuration
6. **Catalog Resources** - Service discovery
7. **Statistics Resources** - Aggregated error statistics
8. **Active Traces** - Recently active distributed traces

---

## Resource Catalog

### 1. Recent Logs

**URI Pattern:** `log://{provider}/recent`

**Description:** Get recent logs (last hour) from a specific provider or all providers.

**URI Examples:**
- `log://all/recent` - Recent logs from all providers
- `log://newrelic/recent` - Recent logs from New Relic only
- `log://azure/recent` - Recent logs from Azure only

**Response Format:**
```json
{
  "provider": "all",
  "count": 150,
  "time_range": {
    "start": "2026-02-16T10:00:00Z",
    "end": "2026-02-16T11:00:00Z"
  },
  "logs": [
    {
      "timestamp": "2026-02-16T10:59:30Z",
      "severity": "error",
      "message": "Connection timeout",
      "source": "newrelic",
      "service_name": "api-gateway",
      "trace_id": "abc123",
      "span_id": "xyz789",
      "host": "prod-server-01",
      "environment": "production"
    }
  ]
}
```

---

### 2. Recent Errors

**URI Pattern:** `log://{provider}/errors`

**Description:** Get recent error and critical logs from a specific provider or all providers.

**URI Examples:**
- `log://all/errors` - Recent errors from all providers
- `log://newrelic/errors` - Recent errors from New Relic only

**Response Format:** Same as Recent Logs, filtered to error/critical severity.

---

### 3. Provider Health

**URI Pattern:** `health://{provider}`

**Description:** Get real-time health status of observability providers.

**URI Examples:**
- `health://all` - Health status of all providers
- `health://newrelic` - New Relic health status
- `health://azure` - Azure health status

**Response Format:**
```json
{
  "timestamp": "2026-02-16T11:00:00Z",
  "providers": {
    "newrelic": {
      "healthy": true,
      "enabled": true,
      "account_id": "12345",
      "region": "US"
    },
    "azure": {
      "healthy": false,
      "enabled": true,
      "error": "Authentication failed"
    }
  }
}
```

---

### 4. Trace Logs

**URI Pattern:** `trace://{trace_id}`

**Description:** Get all logs associated with a specific distributed trace ID.

**URI Examples:**
- `trace://abc123def456` - All logs for trace abc123def456
- `trace://xyz789` - All logs for trace xyz789

**Response Format:**
```json
{
  "trace_id": "abc123def456",
  "count": 42,
  "time_range": {
    "start": "2026-02-15T11:00:00Z",
    "end": "2026-02-16T11:00:00Z"
  },
  "logs": [
    {
      "timestamp": "2026-02-16T10:30:15Z",
      "severity": "info",
      "message": "Request started",
      "service_name": "api-gateway",
      "trace_id": "abc123def456",
      "span_id": "span001"
    },
    {
      "timestamp": "2026-02-16T10:30:16Z",
      "severity": "info",
      "message": "Database query executed",
      "service_name": "user-service",
      "trace_id": "abc123def456",
      "span_id": "span002"
    }
  ]
}
```

---

### 5. Exported Files List

**URI Pattern:** `file://exports`

**Description:** List all previously exported log files.

**Response Format:**
```json
{
  "directory": "exports",
  "count": 5,
  "files": [
    {
      "filename": "logs_export_20260216_103045.json",
      "uri": "file://exports/logs_export_20260216_103045.json",
      "size_bytes": 1048576,
      "modified": "2026-02-16T10:30:45Z"
    },
    {
      "filename": "logs_export_20260215_154020.json",
      "uri": "file://exports/logs_export_20260215_154020.json",
      "size_bytes": 524288,
      "modified": "2026-02-15T15:40:20Z"
    }
  ]
}
```

---

### 6. Exported File Content

**URI Pattern:** `file://exports/{filename}`

**Description:** Get the contents of a specific exported file.

**URI Examples:**
- `file://exports/logs_export_20260216_103045.json`

**Response Format:**
```json
{
  "filename": "logs_export_20260216_103045.json",
  "size_bytes": 1048576,
  "modified": "2026-02-16T10:30:45Z",
  "data": {
    "export_metadata": {
      "timestamp": "2026-02-16T10:30:45Z",
      "total_count": 500,
      "provider_counts": {
        "newrelic": 300,
        "azure": 200
      }
    },
    "logs": [ /* array of log entries */ ]
  }
}
```

---

### 7. Server Configuration

**URI Pattern:** `config://observability`

**Description:** Get server configuration with sensitive data masked.

**Response Format:**
```json
{
  "providers": {
    "newrelic": {
      "enabled": true,
      "timeout_seconds": 30,
      "max_results": 1000,
      "region": "US"
    },
    "azure": {
      "enabled": true,
      "timeout_seconds": 30,
      "max_results": 1000
    }
  },
  "total_providers": 2,
  "enabled_providers": 2
}
```

---

### 8. Service Catalog

**URI Pattern:** `catalog://services`

**Description:** Get a catalog of all services discovered in logs over the last 24 hours.

**Response Format:**
```json
{
  "timestamp": "2026-02-16T11:00:00Z",
  "time_range": {
    "start": "2026-02-15T11:00:00Z",
    "end": "2026-02-16T11:00:00Z"
  },
  "service_count": 8,
  "services": [
    {
      "name": "api-gateway",
      "log_count": 5420,
      "first_seen": "2026-02-15T11:05:00Z",
      "last_seen": "2026-02-16T10:58:30Z",
      "providers": ["newrelic", "azure"]
    },
    {
      "name": "user-service",
      "log_count": 3210,
      "first_seen": "2026-02-15T11:10:00Z",
      "last_seen": "2026-02-16T10:55:00Z",
      "providers": ["newrelic"]
    }
  ]
}
```

---

### 9. Error Statistics

**URI Pattern:** `stats://errors/{period}`

**Description:** Get error statistics and trends for a specific time period.

**Supported Periods:**
- `1h` - Last 1 hour
- `24h` - Last 24 hours
- `7d` - Last 7 days

**URI Examples:**
- `stats://errors/1h` - Last hour error stats
- `stats://errors/24h` - Last 24 hours error stats
- `stats://errors/7d` - Last 7 days error stats

**Response Format:**
```json
{
  "period": "24h",
  "time_range": {
    "start": "2026-02-15T11:00:00Z",
    "end": "2026-02-16T11:00:00Z"
  },
  "total_errors": 342,
  "by_severity": {
    "error": 280,
    "critical": 62
  },
  "by_provider": {
    "newrelic": 200,
    "azure": 142
  },
  "top_services": [
    {
      "service": "payment-service",
      "count": 85
    },
    {
      "service": "api-gateway",
      "count": 62
    }
  ],
  "hourly_distribution": [
    {
      "hour": "2026-02-16T10:00:00Z",
      "count": 15
    },
    {
      "hour": "2026-02-16T09:00:00Z",
      "count": 22
    }
  ]
}
```

---

### 10. Active Traces

**URI Pattern:** `traces://active`

**Description:** Get list of active trace IDs from recent logs (last 1 hour).

**URI Examples:**
- `traces://active` - Active traces from last hour

**Response Format:**
```json
{
  "timestamp": "2026-02-16T11:00:00Z",
  "time_range": {
    "start": "2026-02-16T10:00:00Z",
    "end": "2026-02-16T11:00:00Z"
  },
  "trace_count": 127,
  "traces": [
    {
      "trace_id": "abc123def456",
      "log_count": 42,
      "services": ["api-gateway", "user-service", "payment-service"],
      "first_seen": "2026-02-16T10:45:00Z",
      "last_seen": "2026-02-16T10:45:02Z",
      "duration_ms": 2000,
      "has_errors": false,
      "providers": ["newrelic"]
    },
    {
      "trace_id": "xyz789ghi012",
      "log_count": 18,
      "services": ["api-gateway", "payment-service"],
      "first_seen": "2026-02-16T10:30:00Z",
      "last_seen": "2026-02-16T10:30:05Z",
      "duration_ms": 5000,
      "has_errors": true,
      "providers": ["newrelic", "azure"]
    }
  ]
}
```

---

## Use Cases

### Incident Investigation

1. **Check provider health:** `health://all`
2. **Get recent errors:** `log://all/errors`
3. **Find service with most errors:** `stats://errors/1h`
4. **Get logs for specific service:** Use service name from catalog
5. **Follow distributed trace:** `trace://{trace_id}`

### Service Discovery

1. **List all services:** `catalog://services`
2. **Find active traces:** `traces://active?hours=24`
3. **Analyze error patterns:** `stats://errors/24h`

### Historical Analysis

1. **List exported reports:** `file://exports`
2. **Load specific export:** `file://exports/{filename}`
3. **Compare with current errors:** `log://all/errors`

### Monitoring

1. **Check provider connectivity:** `health://all`
2. **Monitor error rate:** `stats://errors/1h` (regularly)
3. **Track service activity:** `catalog://services`

---

## Implementation Details

### Resource Handler

All resources are implemented in `src/mcp_observability/resources/resource_handler.py` with the `ResourceHandlers` class (exported via `mcp_observability.resources`).

### Resource Registration

Resources are registered in `src/mcp_observability/server.py` using FastMCP's `@mcp.resource()` decorator.

### Data Sources

- **Logs:** Queried dynamically from configured observability providers
- **Exports:** Read from `exports/` directory
- **Configuration:** Loaded from `config.yaml`
- **Statistics:** Calculated on-demand from provider queries

### Caching

Currently, resources are not cached and are fetched on-demand. For production use, consider implementing caching for:
- Service catalog (TTL: 5-10 minutes)
- Error statistics (TTL: 1-5 minutes)
- Active traces (TTL: 1 minute)

---

## Error Handling

If a resource cannot be found or fails to load, the response will contain an error field:

```json
{
  "error": "Export file not found: invalid_file.json"
}
```

For provider failures during aggregation, the resource will return partial data with error information in the response.

---

## Future Enhancements

Potential additions:

1. **Query parameters** - Filter resources by service, severity, etc.
2. **Pagination** - For large result sets
3. **Resource templates** - Saved queries as resources
4. **Real-time subscriptions** - Subscribe to resource updates
5. **Cross-provider correlation** - Automatic correlation of logs across providers
6. **ML-based insights** - Anomaly detection, trend analysis
