# MCP Resources Quick Reference

## All Available Resources

| Resource Type | URI Pattern | Description |
|--------------|-------------|-------------|
| Recent Logs | `log://{provider}/recent` | Last hour of logs from provider(s) |
| Recent Errors | `log://{provider}/errors` | Recent error/critical logs |
| Provider Health | `health://{provider}` | Provider connectivity status |
| Trace Logs | `trace://{trace_id}` | All logs for a specific trace |
| Export List | `file://exports` | List of exported log files |
| Export File | `file://exports/{filename}` | Contents of exported file |
| Configuration | `config://observability` | Server configuration (masked) |
| Service Catalog | `catalog://services` | Discovered services (24h) |
| Error Statistics | `stats://errors/{period}` | Error trends and analysis |
| Active Traces | `traces://active` | Recent active traces |

## Quick Examples

```bash
# Get all recent logs
log://all/recent

# Check provider health
health://all

# Get trace details
trace://abc123def456

# View error statistics for last 24 hours
stats://errors/24h

# List all services
catalog://services

# Get active traces from last 6 hours
# Note: Currently fixed to 1 hour; use tool for custom periods
traces://active

# List exported files
file://exports

# View specific export
file://exports/logs_export_20260216_103045.json

# Check configuration
config://observability
```

## Provider Names

- `all` - All configured providers
- `newrelic` - New Relic
- `azure` - Azure Application Insights
- (More providers can be added)

## Time Periods

For `stats://errors/{period}`:
- `1h` - Last 1 hour
- `24h` - Last 24 hours
- `7d` - Last 7 days

## Common Workflows

### Debug an Error
1. `log://all/errors` - Find recent errors
2. `trace://{trace_id}` - Follow the trace
3. `catalog://services` - Identify affected services

### Monitor System Health
1. `health://all` - Check provider connectivity
2. `stats://errors/1h` - Current error rate
3. `traces://active` - Active request flows

### Analyze Historical Data
1. `file://exports` - List available exports
2. `file://exports/{filename}` - Load specific export
3. `stats://errors/7d` - Week-long trends
