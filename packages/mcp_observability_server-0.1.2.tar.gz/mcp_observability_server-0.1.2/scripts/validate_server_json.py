#!/usr/bin/env python3
"""Validate server.json against the MCP server schema."""

import json
import sys
from pathlib import Path

try:
    import jsonschema
    import requests
except ImportError:
    print("Installing required packages...")
    import subprocess
    subprocess.check_call([sys.executable, "-m", "pip", "install", "jsonschema", "requests"])
    import jsonschema
    import requests


def main():
    """Validate server.json."""
    server_json = Path("server.json")
    
    if not server_json.exists():
        print("❌ server.json not found")
        sys.exit(1)
    
    print("=" * 80)
    print("MCP Server.json Validator")
    print("=" * 80)
    
    # Load and parse
    with open(server_json) as f:
        data = json.load(f)
    
    print("\n📋 Current Configuration:")
    print(f"  Name: {data.get('name')}")
    print(f"  Description: {data.get('description')}")
    print(f"  Description length: {len(data.get('description', ''))} chars")
    print(f"  Version: {data.get('version')}")
    
    # Validate description length
    desc = data.get('description', '')
    if len(desc) > 100:
        print(f"\n❌ ERROR: Description is {len(desc)} chars (max 100)")
        print(f"   Current: {desc}")
        sys.exit(1)
    
    # Check packages
    packages = data.get('packages', [])
    print(f"\n📦 Packages ({len(packages)}):")
    for pkg in packages:
        print(f"  - {pkg.get('identifier')} v{pkg.get('version')}")
        print(f"    Registry Type: {pkg.get('registryType')}")
        print(f"    Transport: {pkg.get('transport', {}).get('type')}")
        
        if not pkg.get('registryType'):
            print("    ❌ Missing registryType")
            sys.exit(1)
    
    # Fetch and validate against schema
    schema_url = data.get('$schema')
    if schema_url:
        print(f"\n🔍 Validating against schema: {schema_url}")
        try:
            response = requests.get(schema_url, timeout=10)
            response.raise_for_status()
            schema = response.json()
            jsonschema.validate(instance=data, schema=schema)
            print("✅ Schema validation passed")
        except Exception as e:
            print(f"⚠️  Schema validation warning: {e}")
    
    print("\n" + "=" * 80)
    print("✅ Validation complete - server.json looks good!")
    print("=" * 80)


if __name__ == "__main__":
    main()
