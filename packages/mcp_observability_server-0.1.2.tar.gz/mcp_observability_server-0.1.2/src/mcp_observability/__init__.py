"""MCP Observability Server - Multi-platform log polling for SRE workflows."""

from .config import create_provider_configs, load_config_file
from .exceptions import (
    ConfigurationError,
    MCPObservabilityError,
    ProviderAuthenticationError,
    ProviderConnectionError,
    ProviderError,
    ProviderQueryError,
    TimeParseError,
    ValidationError,
)
from .formatters import (
    format_health_check_results,
    format_log_entry,
    format_logs_as_table,
    format_query_result,
)
from .health import test_all_providers
from .logging_config import get_logger, setup_logging
from .models import (
    LogEntry,
    LogProvider,
    LogQueryResult,
    LogSeverity,
    QueryParams,
)
from .resources import ResourceHandlers
from .utils.time_utils import format_duration, parse_time_string
from .tools.tool_handlers import ToolHandlers

__version__ = "0.1.0"

__all__ = [
    # Core models
    "LogEntry",
    "LogProvider",
    "LogSeverity",
    "LogQueryResult",
    "QueryParams",
    # Handlers
    "ToolHandlers",
    "ResourceHandlers",
    # Logging
    "get_logger",
    "setup_logging",
    # Configuration
    "load_config_file",
    "create_provider_configs",
    # Formatters
    "format_log_entry",
    "format_logs_as_table",
    "format_query_result",
    "format_health_check_results",
    # Health
    "test_all_providers",
    # Time utilities
    "parse_time_string",
    "format_duration",
    # Exceptions
    "MCPObservabilityError",
    "ConfigurationError",
    "ProviderError",
    "ProviderConnectionError",
    "ProviderAuthenticationError",
    "ProviderQueryError",
    "TimeParseError",
    "ValidationError",
]