"""Configuration loading and validation."""

import os
from pathlib import Path
from typing import Optional

import yaml
from dotenv import load_dotenv
from pydantic import ValidationError

from .exceptions import ConfigurationError
from .logging_config import get_logger
from .models import AzureConfig, NewRelicConfig

logger = get_logger("config")


def load_config_file(config_path: Optional[str] = None) -> dict:
    """Load configuration from YAML file.

    Args:
        config_path: Path to config file. If None, looks for config.yaml in current dir

    Returns:
        Dictionary of configuration

    Raises:
        ConfigurationError: If config file cannot be loaded
    """
    # Load environment variables from .env file
    load_dotenv()
    logger.debug("Loaded environment variables from .env file")
    
    if not config_path:
        config_path = "config.yaml"

    config_file = Path(config_path)

    if not config_file.exists():
        logger.warning(f"Config file not found: {config_path}")
        raise ConfigurationError("Unable to find config file")

    logger.info(f"Loading config from: {config_path}")
    try:
        with open(config_file) as f:
            config = yaml.safe_load(f)
    except Exception as e:
        raise ConfigurationError(f"Failed to load config file: {e}") from e

    # Perform environment variable substitution
    config = _substitute_env_vars(config)
    logger.debug(f"Config loaded successfully with {len(config.get('providers', {}))} provider(s)")

    return config


def _substitute_env_vars(config: dict | list | str) -> dict | list | str:
    """Recursively substitute environment variables in config.

    Replaces ${VAR_NAME} with the value of environment variable VAR_NAME.

    Args:
        config: Configuration value (can be dict, list, or string)

    Returns:
        Configuration with environment variables substituted
    """
    if isinstance(config, dict):
        return {k: _substitute_env_vars(v) for k, v in config.items()}
    elif isinstance(config, list):
        return [_substitute_env_vars(item) for item in config]
    elif isinstance(config, str) and config.startswith("${") and config.endswith("}"):
        var_name = config[2:-1]
        return os.getenv(var_name, config)
    else:
        return config


def create_provider_configs(config: dict) -> dict:
    """Create provider configuration objects from dict.

    Args:
        config: Raw configuration dictionary

    Returns:
        Dictionary mapping provider name to config object

    Raises:
        ConfigurationError: If provider configuration is invalid
    """
    providers = {}

    provider_configs = config.get("providers", {})
    logger.info(f"Creating configurations for {len(provider_configs)} provider(s)")

    # New Relic
    if "newrelic" in provider_configs:
        try:
            providers["newrelic"] = NewRelicConfig(**provider_configs["newrelic"])
            logger.info("New Relic configuration created successfully")
        except ValidationError as e:
            logger.error(f"Invalid New Relic config: {e}")
            raise ConfigurationError(f"Invalid New Relic configuration: {e}") from e

    # Azure
    if "azure" in provider_configs:
        try:
            providers["azure"] = AzureConfig(**provider_configs["azure"])
            logger.info("Azure configuration created successfully")
        except ValidationError as e:
            logger.error(f"Invalid Azure config: {e}")
            raise ConfigurationError(f"Invalid Azure configuration: {e}") from e

    return providers
