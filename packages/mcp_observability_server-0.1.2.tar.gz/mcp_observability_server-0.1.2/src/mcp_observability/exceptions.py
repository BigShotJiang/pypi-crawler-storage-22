"""Custom exceptions for MCP Observability Server."""


class MCPObservabilityError(Exception):
    """Base exception for all MCP Observability errors."""

    pass


class ConfigurationError(MCPObservabilityError):
    """Raised when there are configuration issues."""

    pass


class ProviderError(MCPObservabilityError):
    """Base exception for provider-related errors."""

    def __init__(self, provider_name: str, message: str):
        """Initialize provider error.

        Args:
            provider_name: Name of the provider that failed
            message: Error message
        """
        self.provider_name = provider_name
        super().__init__(f"{provider_name}: {message}")


class ProviderConnectionError(ProviderError):
    """Raised when a provider connection fails."""

    pass


class ProviderAuthenticationError(ProviderError):
    """Raised when provider authentication fails."""

    pass


class ProviderQueryError(ProviderError):
    """Raised when a provider query fails."""

    pass


class TimeParseError(MCPObservabilityError):
    """Raised when time string cannot be parsed."""

    pass


class ValidationError(MCPObservabilityError):
    """Raised when input validation fails."""

    pass
