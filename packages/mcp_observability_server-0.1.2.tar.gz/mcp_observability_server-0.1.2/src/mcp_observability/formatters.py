"""Formatting utilities for logs and query results."""

from typing import Optional

from .logging_config import get_logger
from .models import LogEntry, LogQueryResult

logger = get_logger("formatters")


def format_log_entry(log_entry: LogEntry) -> str:
    """Format a single log entry for human-readable display.

    Args:
        log_entry: LogEntry object to format

    Returns:
        Formatted string representation
    """
    lines = [
        f"[{log_entry.timestamp.isoformat()}] "
        f"[{log_entry.severity.value.upper()}] "
        f"[{log_entry.source.value}]",
    ]

    if log_entry.service_name:
        lines.append(f"Service: {log_entry.service_name}")

    if log_entry.trace_id:
        lines.append(f"Trace ID: {log_entry.trace_id}")

    lines.append(f"Message: {log_entry.message}")

    if log_entry.host:
        lines.append(f"Host: {log_entry.host}")

    return "\n".join(lines)


def format_logs_as_table(logs: list[LogEntry], max_message_length: int = 80) -> str:
    """Format multiple logs as a table.

    Args:
        logs: List of LogEntry objects
        max_message_length: Maximum length for message column

    Returns:
        Table-formatted string
    """
    if not logs:
        return "No logs found."

    rows = []
    for log in logs:
        message = log.message
        if len(message) > max_message_length:
            message = message[:max_message_length] + "..."

        rows.append(
            {
                "Timestamp": log.timestamp.strftime("%Y-%m-%d %H:%M:%S"),
                "Severity": log.severity.value.upper(),
                "Source": log.source.value,
                "Service": log.service_name or "-",
                "Message": message,
            }
        )

    # Simple table formatting
    headers = ["Timestamp", "Severity", "Source", "Service", "Message"]

    # Calculate column widths
    col_widths = {h: len(h) for h in headers}
    for row in rows:
        for h in headers:
            col_widths[h] = max(col_widths[h], len(str(row.get(h, ""))))

    # Build table
    separator = "+" + "+".join("-" * (col_widths[h] + 2) for h in headers) + "+"
    header_row = "|" + "|".join(f" {h:<{col_widths[h]}} " for h in headers) + "|"

    lines = [separator, header_row, separator]

    for row in rows:
        row_str = (
            "|" + "|".join(f" {str(row.get(h, '')):<{col_widths[h]}} " for h in headers) + "|"
        )
        lines.append(row_str)

    lines.append(separator)

    return "\n".join(lines)


def format_query_result(
    result: LogQueryResult, trace_view: bool = False, max_display: int = 50
) -> str:
    """Format query result for display.

    Args:
        result: LogQueryResult object
        trace_view: If True, shows chronological trace timeline
        max_display: Maximum number of logs to display in detail

    Returns:
        Formatted query result string
    """
    lines = []

    # Summary
    lines.append(f"Query Results: {result.total_count} logs found")
    lines.append(f"Query time: {result.query_duration_ms:.2f}ms")
    lines.append("")

    # Provider breakdown
    lines.append("Provider breakdown:")
    for provider, count in result.provider_counts.items():
        lines.append(f"  {provider}: {count} logs")
    lines.append("")

    # Errors
    if result.errors:
        lines.append("Errors:")
        for error in result.errors:
            lines.append(f"  {error}")
        lines.append("")

    # Logs
    if result.logs:
        if trace_view:
            lines.append("Trace Timeline (chronological order):")
        else:
            lines.append("Logs (most recent first):")
        lines.append("")
        lines.append(format_logs_as_table(result.logs[:max_display]))

        if len(result.logs) > max_display:
            lines.append(f"\n... and {len(result.logs) - max_display} more logs")
    else:
        lines.append("No logs found matching the criteria.")

    return "\n".join(lines)


def format_health_check_results(results: dict[str, dict]) -> str:
    """Format health check results for display.

    Args:
        results: Dictionary mapping provider name to health status

    Returns:
        Formatted health check string
    """
    lines = ["Provider Health Check Results:", ""]

    for provider_name, health in results.items():
        status = "✓ Healthy" if health["healthy"] else "✗ Unhealthy"
        enabled = "Enabled" if health["enabled"] else "Disabled"

        lines.append(f"{provider_name}: {status} ({enabled})")

        if "error" in health:
            lines.append(f"  Error: {health['error']}")

    return "\n".join(lines)
