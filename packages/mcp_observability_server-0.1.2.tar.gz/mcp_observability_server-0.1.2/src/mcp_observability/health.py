"""Health check utilities for providers."""

from typing import Any

from .logging_config import get_logger

logger = get_logger("health")


async def test_all_providers(providers: dict[str, Any]) -> dict[str, dict]:
    """Test connectivity to all configured providers.

    Args:
        providers: Dictionary of provider instances

    Returns:
        Dictionary of provider name to health status
    """
    logger.info(f"Testing {len(providers)} provider(s)")
    results = {}

    for name, provider in providers.items():
        logger.debug(f"Testing {name} provider")
        try:
            health = await provider.health_check()
            results[name] = health
            status = "healthy" if health["healthy"] else "unhealthy"
            logger.info(f"{name} provider is {status}")
        except Exception as e:
            logger.error(f"Health check failed for {name}: {e}")
            results[name] = {"healthy": False, "enabled": False, "error": str(e)}

    return results
