"""Data models for unified log representation across multiple providers."""

from datetime import datetime
from enum import Enum
from typing import Any, Optional

from pydantic import BaseModel, Field


class LogSeverity(str, Enum):
    """Standardized log severity levels."""
    
    DEBUG = "debug"
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"
    UNKNOWN = "unknown"


class LogProvider(str, Enum):
    """Supported log providers."""
    
    NEW_RELIC = "newrelic"
    AZURE = "azure"


class LogEntry(BaseModel):
    """Unified log entry model across all providers."""
    
    timestamp: datetime = Field(description="When the log was generated")
    severity: LogSeverity = Field(description="Log severity level")
    message: str = Field(description="Log message content")
    source: LogProvider = Field(description="Which provider this log came from")
    
    # Optional fields
    service_name: Optional[str] = Field(None, description="Name of the service/application")
    trace_id: Optional[str] = Field(None, description="Distributed trace ID")
    span_id: Optional[str] = Field(None, description="Span ID within a trace")
    user_id: Optional[str] = Field(None, description="User ID if available")
    host: Optional[str] = Field(None, description="Hostname or instance ID")
    environment: Optional[str] = Field(None, description="Environment (prod, staging, dev)")
    
    # Provider-specific metadata
    metadata: dict[str, Any] = Field(default_factory=dict, description="Additional metadata")
    raw_log: dict[str, Any] = Field(default_factory=dict, description="Original log data")
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat(),
        }


class QueryParams(BaseModel):
    """Parameters for querying logs."""
    
    start_time: datetime = Field(description="Start of time range")
    end_time: datetime = Field(description="End of time range")
    query: Optional[str] = Field(None, description="Search query/pattern")
    severity: Optional[list[LogSeverity]] = Field(None, description="Filter by severity levels")
    entity_name: Optional[str] = Field(None, description="Filter by entity name")
    limit: int = Field(default=100, ge=1, le=10000, description="Maximum number of results")
    providers: Optional[list[LogProvider]] = Field(None, description="Specific providers to query")


class LogQueryResult(BaseModel):
    """Result of a log query operation."""
    
    logs: list[LogEntry] = Field(description="List of log entries")
    total_count: int = Field(description="Total number of logs found")
    provider_counts: dict[str, int] = Field(
        default_factory=dict, 
        description="Count of logs per provider"
    )
    query_duration_ms: float = Field(description="Time taken to execute query")
    errors: list[str] = Field(default_factory=list, description="Any errors encountered")


class ProviderConfig(BaseModel):
    """Configuration for a single provider."""
    
    enabled: bool = Field(default=True, description="Whether this provider is enabled")
    timeout_seconds: int = Field(default=30, ge=1, le=300, description="Query timeout")
    max_results: int = Field(default=1000, ge=1, le=10000, description="Max results per query")


class NewRelicConfig(ProviderConfig):
    """New Relic specific configuration."""
    
    api_key: str = Field(description="New Relic API key")
    account_id: str = Field(description="New Relic account ID")
    region: str = Field(default="US", description="New Relic region (US or EU)")


class AzureConfig(ProviderConfig):
    """Azure Application Insights configuration."""
    
    workspace_id: str = Field(description="Log Analytics workspace ID")
    client_id: str = Field(description="Azure AD application client ID")
    client_secret: str = Field(description="Azure AD application client secret")
    tenant_id: str = Field(description="Azure AD tenant ID")