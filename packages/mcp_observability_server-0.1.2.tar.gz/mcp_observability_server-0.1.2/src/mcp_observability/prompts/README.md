# MCP Observability Prompts

This directory contains MCP prompt implementations that provide guided workflows for common observability and SRE tasks.

## Available Prompts

### High Priority Prompts

#### 1. `investigate-incident`
**Purpose:** Systematic incident investigation workflow

**Use when:**
- Production incident occurs
- Need structured approach to troubleshooting
- Want to ensure thorough investigation

**Parameters:**
- `service_name` (optional): Name of the service to investigate
- `time_period` (default: "1h"): Time period to investigate (e.g., "30m", "2h")
- `severity_threshold` (default: "error"): Minimum severity level

**Example usage in Claude:**
```
Use the investigate-incident prompt for the api-gateway service
```

**What it does:**
1. Retrieves recent errors
2. Identifies patterns and frequencies
3. Investigates traces
4. Checks system health
5. Generates incident summary with timeline and recommendations

---

#### 2. `health-check-report`
**Purpose:** Generate comprehensive system health report

**Use when:**
- Daily health check
- Morning stand-up preparation
- System status overview needed

**Parameters:**
- `time_period` (default: "24h"): Period for error statistics
- `include_metrics` (default: true): Include detailed metrics

**Example usage in Claude:**
```
Generate a health check report for the last 24 hours
```

**What it does:**
1. Checks all provider health status
2. Analyzes recent errors
3. Calculates error statistics
4. Identifies active traces
5. Catalogs all services
6. Provides recommendations

---

#### 3. `post-deployment-check`
**Purpose:** Validate deployment health

**Use when:**
- After deploying new code
- CI/CD pipeline validation
- Verifying deployment success

**Parameters:**
- `service_name` (required): Name of deployed service
- `deployment_time` (optional): When deployment occurred
- `lookback_minutes` (default: 30): Baseline comparison period

**Example usage in Claude:**
```
Run a post-deployment check for user-service deployed 15 minutes ago
```

**What it does:**
1. Compares error rates before/after deployment
2. Identifies new error types
3. Analyzes trace success rates
4. Provides deployment health recommendation (PROCEED/MONITOR/ROLLBACK)
5. Generates validation report

---

#### 4. `trace-flow-analysis`
**Purpose:** Analyze distributed trace execution flow

**Use when:**
- Debugging distributed system issues
- Understanding request flow
- Identifying bottlenecks

**Parameters:**
- `trace_id` (required): Trace ID to analyze
- `include_timing` (default: true): Include timing analysis

**Example usage in Claude:**
```
Analyze the trace flow for trace ID abc123-def456
```

**What it does:**
1. Retrieves all logs for the trace
2. Builds chronological timeline
3. Maps service call chain
4. Analyzes timing and bottlenecks
5. Identifies failures and root causes
6. Shows dependency relationships

---

#### 5. `root-cause-analysis`
**Purpose:** Deep root cause investigation

**Use when:**
- Need to find originating cause
- Multiple cascading failures
- Complex failure scenarios

**Parameters:**
- `trace_id` (optional): Specific trace to investigate
- `error_pattern` (optional): Known error pattern
- `time_window` (default: "1h"): Investigation time window

**Example usage in Claude:**
```
Perform root cause analysis for trace abc123
```

**What it does:**
1. Gathers initial evidence
2. Builds failure timeline
3. Analyzes trace flow
4. Gathers context around failures
5. Recognizes patterns
6. Formulates root cause with evidence
7. Provides prevention recommendations

---

## How Prompts Work

MCP prompts provide **guided workflows** that:
- Give Claude structured instructions for complex tasks
- Chain multiple tool calls together
- Provide analysis frameworks
- Generate formatted reports

When you use a prompt, Claude will:
1. Load the prompt workflow
2. Execute the steps using available tools
3. Analyze the results
4. Generate a comprehensive report

## Best Practices

### When to Use Prompts vs Tools

**Use Prompts when:**
- You need a multi-step workflow
- Investigation requires multiple data sources
- You want consistent analysis approach
- Generating reports or summaries

**Use Tools directly when:**
- Simple, single query needed
- You know exactly what data you need
- Quick spot checks
- Ad-hoc queries

### Combining Prompts

Prompts can be used sequentially:

1. **Start broad:** Use `health-check-report` to get overview
2. **Narrow down:** Use `investigate-incident` for specific service
3. **Deep dive:** Use `trace-flow-analysis` for specific traces
4. **Find root cause:** Use `root-cause-analysis` to identify origin

### Custom Workflows

You can ask Claude to:
- Modify prompt parameters for your use case
- Combine multiple prompts
- Skip steps you don't need
- Add custom analysis

**Example:**
```
Use the investigate-incident prompt for payment-service but focus only 
on critical errors and skip the health check step
```

## Prompt Development

### Adding New Prompts

To add a new prompt:

1. Create prompt function in appropriate file under `prompts/`
2. Return `list[PromptMessage]` with structured workflow
3. Export from `prompts/__init__.py`
4. Register in `server.py` with `@mcp.prompt()` decorator
5. Update this README

### Prompt Structure

Good prompts should:
- Have clear objectives
- Provide step-by-step instructions
- Include tool usage examples
- Specify what to analyze
- Format output consistently
- Give decision criteria
- Provide actionable recommendations

### Example Prompt Structure
```python
def create_my_prompt(param: str) -> list[PromptMessage]:
    return [PromptMessage(
        role="user",
        content=TextContent(
            type="text",
            text="""
# Workflow Title

## Objective
[Clear goal]

## Steps
### Step 1: [Action]
[Instructions and tool usage]

### Step 2: [Analysis]
[What to look for]

## Report Template
[Structured output format]
"""
        )
    )]
```

## Troubleshooting

**Prompt not showing in Claude:**
- Ensure it's registered in server.py
- Check server logs for errors
- Restart MCP server

**Prompt execution fails:**
- Verify parameters are correct
- Check that required tools are available
- Review tool handler errors

**Unexpected results:**
- Adjust prompt parameters
- Refine time windows
- Add more specific filters

## Future Prompt Ideas

Potential prompts to add:
- `service-discovery`: Discover and catalog services
- `debug-timeout-issues`: Investigate timeout patterns
- `weekly-reliability-report`: Generate SLO reports
- `error-pattern-analysis`: Analyze error trends
- `capacity-planning`: Resource usage analysis

## Contributing

When adding prompts:
1. Focus on common SRE workflows
2. Provide clear, actionable guidance
3. Include examples in documentation
4. Test with real scenarios
5. Get feedback from users

---

## Quick Reference

| Prompt | Best For | Key Output |
|--------|----------|------------|
| `investigate-incident` | Active incidents | Incident summary with timeline |
| `health-check-report` | Daily monitoring | System health status |
| `post-deployment-check` | CI/CD validation | Deployment recommendation |
| `trace-flow-analysis` | Distributed debugging | Service call chain |
| `root-cause-analysis` | Complex failures | Root cause with evidence |
