"""MCP prompts for guided observability workflows."""

from .incident import (
    create_investigate_incident_prompt,
    create_root_cause_analysis_prompt,
)
from .health import create_health_check_report_prompt
from .deployment import create_post_deployment_check_prompt
from .trace_analysis import create_trace_flow_analysis_prompt

__all__ = [
    "create_investigate_incident_prompt",
    "create_root_cause_analysis_prompt",
    "create_health_check_report_prompt",
    "create_post_deployment_check_prompt",
    "create_trace_flow_analysis_prompt",
]
