"""Deployment validation and verification prompts."""

from typing import Optional
from mcp.types import PromptMessage, TextContent


def create_post_deployment_check_prompt(
    service_name: str,
    deployment_time: Optional[str] = None,
    lookback_minutes: int = 30
) -> list[PromptMessage]:
    """Create a prompt for post-deployment validation.
    
    This prompt guides verification of deployment health by comparing
    metrics before and after deployment.
    
    Args:
        service_name: Name of the deployed service
        deployment_time: ISO timestamp or relative time of deployment (e.g., "10m")
        lookback_minutes: How many minutes before deployment to compare (default: 30)
        
    Returns:
        List of prompt messages for deployment validation workflow
    """
    deployment_context = f" at {deployment_time}" if deployment_time else ""
    
    system_message = PromptMessage(
        role="user",
        content=TextContent(
            type="text",
            text=f"""You are validating a deployment of '{service_name}' service{deployment_context}.

# Post-Deployment Validation Workflow

## Objective
Verify the deployment is healthy by comparing system behavior before and after deployment.

## Validation Steps

### Step 1: Define Time Windows
Establish baseline (pre-deployment) and current (post-deployment) periods:

- **Baseline Period:** {lookback_minutes} minutes BEFORE deployment
- **Current Period:** Time SINCE deployment (or last {lookback_minutes} minutes)
- **Deployment Time:** {deployment_time or "Now (use current time)"}

### Step 2: Get Current Errors
Check for errors since deployment:

```
Use get_recent_errors with:
- minutes: {lookback_minutes}
- entity_name: "{service_name}"
- limit: 200
```

Analyze:
- How many errors occurred?
- What types of errors?
- Are there NEW error messages not seen before?
- What is the error rate (errors per minute)?

### Step 3: Get Baseline Errors
Retrieve errors from the baseline period (before deployment):

```
Use query_logs with:
- start_time: <{lookback_minutes*2} minutes ago>
- end_time: <{lookback_minutes} minutes ago>
- severity: ["error", "critical"]
- entity_name: "{service_name}"
- limit: 200
```

Calculate baseline error rate for comparison.

### Step 4: Compare Error Rates

**Calculate:**
- Baseline error rate: [errors] / {lookback_minutes} min = [X errors/min]
- Current error rate: [errors] / [minutes since deploy] = [Y errors/min]
- Change: [(Y-X)/X * 100]%

**Status Decision:**
- ✅ **Healthy:** Current error rate ≤ baseline or minimal increase (<10%)
- ⚠️  **Warning:** Error rate increased 10-50%
- ❌ **Critical:** Error rate increased >50% or new critical errors

### Step 5: Identify New Error Types
Compare error messages between periods:

**New Errors (need investigation):**
- [Error message that didn't appear in baseline]

**Increased Errors:**
- [Error message with significantly higher frequency]

**Resolved Errors (good news):**
- [Error message that stopped appearing]

### Step 6: Trace Analysis
If errors are present, investigate traces:

```
Use search_by_trace_id for traces with errors
```

Check:
- Are errors isolated or widespread?
- Which downstream services are affected?
- Are there timeout patterns?

### Step 7: Search for Deployment Keywords
Look for deployment-related log entries:

```
Use query_logs with:
- start_time: <deployment time - 5 min>
- end_time: <deployment time + 5 min>
- query: "deploy OR start OR restart OR version"
- entity_name: "{service_name}"
```

Verify:
- Did the service restart successfully?
- Are there startup errors?
- Did initialization complete?

### Step 8: Generate Deployment Report

---
## Deployment Validation Report
**Service:** {service_name}
**Deployment Time:** {deployment_time or "[Current Time]"}
**Validation Period:** Last {lookback_minutes} minutes
**Report Generated:** [Current Timestamp]

### Overall Status
[✅ HEALTHY | ⚠️ WARNING | ❌ CRITICAL ISSUES]

### Error Rate Comparison
| Metric | Baseline | Current | Change |
|--------|----------|---------|--------|
| Error Count | [X] | [Y] | [+/- Z%] |
| Errors/Min | [X] | [Y] | [+/- Z%] |
| Critical Count | [X] | [Y] | [+/- Z%] |

### New Issues Detected
{_format_issues_section()}

### Trace Analysis
- **Total Traces:** [count]
- **Failed Traces:** [count]
- **Success Rate:** [percentage]

### Key Findings
1. [Finding 1]
2. [Finding 2]
3. ...

### Recommendation
**[PROCEED | MONITOR CLOSELY | ROLLBACK]**

**Justification:**
[Explain the recommendation based on the data]

**Action Items:**
- [ ] [Immediate action if needed]
- [ ] [Monitoring to set up]
- [ ] [Follow-up investigation]

---

## Validation Criteria

### ✅ Healthy Deployment
- Error rate within 10% of baseline
- No new critical errors
- Service started successfully
- No increase in failed traces

### ⚠️ Needs Monitoring
- Error rate increased 10-50%
- Minor new warnings (not critical)
- Some trace failures (isolated)
- → Continue monitoring closely for next hour

### ❌ Consider Rollback
- Error rate increased >50%
- New critical errors
- Service failing to start/restart
- Significant trace failure rate
- → Immediate investigation or rollback needed

## Next Steps
After validation:
1. If healthy: Continue monitoring for next 2-4 hours
2. If warning: Investigate specific error patterns
3. If critical: Engage on-call, prepare rollback plan

Use the tools to gather data systematically and complete the validation report.
"""
        )
    )
    
    return [system_message]


def _format_issues_section() -> str:
    """Format the issues section template."""
    return """
#### New Errors (Not in Baseline)
1. [Error message] - [count] occurrences
   - First seen: [timestamp]
   - Severity: [level]
   - Trace IDs: [examples]

#### Increased Errors
1. [Error message] - [count] occurrences (was [baseline count])
   - Change: [+X%]
   - Pattern: [description]

#### Resolved (Positive)
1. [Error message that stopped appearing]
"""
