"""Health check and monitoring prompts."""

from typing import Optional
from mcp.types import PromptMessage, TextContent


def create_health_check_report_prompt(
    time_period: str = "24h",
    include_metrics: bool = True
) -> list[PromptMessage]:
    """Create a prompt for comprehensive health check reporting.
    
    This prompt guides the generation of a complete health status report
    across all observability platforms and services.
    
    Args:
        time_period: Time period for error statistics (e.g., "24h", "1h")
        include_metrics: Whether to include detailed metrics
        
    Returns:
        List of prompt messages for health check workflow
    """
    metrics_section = """
## Step 3: Error Statistics
Get error statistics for the time period:

```
Use query_logs with:
- start_time: "{time_period}"
- severity: ["error", "critical"]
- limit: 500
```

Analyze and report:
- Total error count
- Errors per service
- Most frequent error messages (top 10)
- Error rate trend
""" if include_metrics else ""
    
    system_message = PromptMessage(
        role="user",
        content=TextContent(
            type="text",
            text=f"""You are an SRE generating a comprehensive health check report for production systems.

# Health Check Report Generation

Generate a complete health status report covering all observability platforms and services.

## Report Structure

### Step 1: Provider Health Status
First, check the health of all observability providers:

```
Use the health_check tool
```

Report for each provider:
- Status (healthy/unhealthy)
- Response time
- Any connection issues
- Data availability

### Step 2: Recent Errors Overview
Get recent errors from the last {time_period}:

```
Use get_recent_errors with:
- minutes: {_parse_time_to_minutes(time_period)}
- limit: 100
```

Summarize:
- Total error count
- Critical vs error breakdown
- Services with errors
- New error patterns (if any)
{metrics_section}
### Step 4: Active Traces
Check active traces to understand current activity:

```
Use query_logs to identify unique trace IDs from recent period
```

Report:
- Number of active traces
- Success vs failure rate (based on error presence)
- Services involved in traces

### Step 5: Service Catalog
Identify all services logging data:

```
Use query_logs with broad time range to identify unique service names
```

List all services and their logging activity.

## Health Report Template

Generate a report in this format:

---
# System Health Report
**Generated:** {_get_current_timestamp()}
**Report Period:** {time_period}

## Executive Summary
[2-3 sentence overview of system health]

## Provider Health
| Provider | Status | Response Time | Notes |
|----------|--------|---------------|-------|
| ... | ... | ... | ... |

## Error Analysis
**Total Errors:** [count]
**Critical Errors:** [count]
**Error Rate:** [errors per hour/minute]

### Top Error Messages
1. [Error message] - [count] occurrences
2. [Error message] - [count] occurrences
3. ...

### Affected Services
- **[Service Name]**: [error count], [severity distribution]
- ...

## Service Activity
**Active Services:** [count]
**Services with Errors:** [count]
**Services Healthy:** [count]

### Service Status
- ✅ [Service Name] - Healthy
- ⚠️  [Service Name] - Warnings detected
- ❌ [Service Name] - Errors detected

## Trace Analysis
**Active Traces:** [count]
**Failed Traces:** [count]
**Success Rate:** [percentage]

## Key Findings
1. [Important observation 1]
2. [Important observation 2]
3. ...

## Recommendations
1. [Action item 1]
2. [Action item 2]
3. ...

## Alerts & Action Items
- [ ] [Critical item requiring immediate attention]
- [ ] [Important item for follow-up]
- [ ] [Nice-to-have improvement]

---

## Report Quality Guidelines
- Be concise but comprehensive
- Highlight anomalies or concerns
- Use metrics to support observations
- Provide actionable recommendations
- Use visual indicators (✅ ⚠️ ❌) for quick scanning
- Include timestamps and specific values
- Compare to baselines when possible

Generate the complete health report now using the available tools.
"""
        )
    )
    
    return [system_message]


def _parse_time_to_minutes(time_str: str) -> int:
    """Parse time string to minutes.
    
    Args:
        time_str: Time string like "1h", "30m", "24h"
        
    Returns:
        Number of minutes
    """
    time_str = time_str.lower().strip()
    
    if time_str.endswith('h'):
        return int(time_str[:-1]) * 60
    elif time_str.endswith('m'):
        return int(time_str[:-1])
    elif time_str.endswith('d'):
        return int(time_str[:-1]) * 24 * 60
    else:
        return int(time_str)


def _get_current_timestamp() -> str:
    """Get current timestamp string."""
    from datetime import datetime, timezone
    return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
