"""Incident investigation and root cause analysis prompts."""

from typing import Optional
from mcp.types import PromptMessage, TextContent


def create_investigate_incident_prompt(
    service_name: Optional[str] = None,
    time_period: str = "1h",
    severity_threshold: str = "error"
) -> list[PromptMessage]:
    """Create a prompt for systematic incident investigation.
    
    This prompt guides the user through a structured approach to investigating
    incidents, including error analysis, trace investigation, and pattern detection.
    
    Args:
        service_name: Name of the service to investigate (optional)
        time_period: Time period to investigate (e.g., "1h", "30m", "2h")
        severity_threshold: Minimum severity level (e.g., "error", "warning")
        
    Returns:
        List of prompt messages for the incident investigation workflow
    """
    service_filter = f" for service '{service_name}'" if service_name else ""
    entity_param = f', entity_name="{service_name}"' if service_name else ""
    
    system_message = PromptMessage(
        role="user",
        content=TextContent(
            type="text",
            text=f"""You are an experienced SRE helping to investigate an incident{service_filter}.

# Incident Investigation Workflow

Follow this systematic approach to investigate the incident:

## Step 1: Get Recent Errors
First, retrieve recent error and critical logs from the last {time_period}:

```
Use the get_recent_errors tool with:
- minutes: {_parse_time_to_minutes(time_period)}
- limit: 100{entity_param}
```

Analyze the results:
- What are the most frequent error messages?
- Are there any critical errors?
- When did the errors start?
- Are errors increasing or stable?

## Step 2: Identify Patterns
Look for patterns in the error data:
- Group similar error messages
- Identify affected services/components
- Check if errors correlate with specific operations
- Note any trace IDs present in the errors

## Step 3: Trace Investigation
If trace IDs are present, investigate the distributed traces:

```
Use the search_by_trace_id tool for each significant trace ID
```

For each trace:
- What was the sequence of service calls?
- Where did the failure occur?
- What were the error messages at each step?
- Are there timing issues (timeouts, slow responses)?

## Step 4: Check System Health
Verify the health of all observability providers:

```
Use the health_check tool
```

Ensure all providers are responding correctly and data is flowing.

## Step 5: Analyze Time Range
If needed, expand the investigation to understand when the issue started:

```
Use the query_logs tool with:
- start_time: earlier time period (e.g., "2h", "6h", "24h")
- severity: ["error", "critical"]
- query: <key error patterns identified>{entity_param}
```

## Step 6: Generate Summary
Provide a structured incident summary:

**Incident Timeline:**
- When did errors start?
- What is the error frequency/rate?

**Affected Components:**
- Which services are impacted?
- Are there shared dependencies failing?

**Root Cause Hypothesis:**
- Based on the data, what is likely causing the issue?
- What evidence supports this hypothesis?

**Recommended Actions:**
- Immediate remediation steps
- Further investigation needed
- Monitoring to set up

## Example Questions to Ask:
- "Show me all errors from {service_name or 'all services'} in the last {time_period}"
- "What are the most common error messages?"
- "Find all logs for trace ID [xyz]"
- "Has the error rate increased compared to earlier?"

Remember: Be systematic, follow the data, and document your findings as you go.
"""
        )
    )
    
    return [system_message]


def create_root_cause_analysis_prompt(
    trace_id: Optional[str] = None,
    error_pattern: Optional[str] = None,
    time_window: str = "1h"
) -> list[PromptMessage]:
    """Create a prompt for deep root cause analysis.
    
    This prompt guides detailed investigation to identify the root cause of issues.
    
    Args:
        trace_id: Specific trace ID to investigate (optional)
        error_pattern: Known error pattern to analyze (optional)
        time_window: Time window to investigate
        
    Returns:
        List of prompt messages for root cause analysis workflow
    """
    trace_context = f"\n\n**Focus Trace ID:** {trace_id}" if trace_id else ""
    error_context = f"\n\n**Known Error Pattern:** {error_pattern}" if error_pattern else ""
    
    system_message = PromptMessage(
        role="user",
        content=TextContent(
            type="text",
            text=f"""You are performing a deep root cause analysis for a production issue.

# Root Cause Analysis Workflow{trace_context}{error_context}

## Objective
Identify the ROOT CAUSE, not just symptoms. Work backwards from the error to the original failure point.

## Investigation Steps

### 1. Gather Initial Evidence
{"If you have a trace ID, start there:" if trace_id else "Start by collecting error data:"}

```
{"Use search_by_trace_id with trace_id: " + trace_id if trace_id else "Use get_recent_errors to find trace IDs"}
```

### 2. Build the Timeline
Create a chronological timeline of events:
- When did the first error occur?
- What happened immediately before?
- Are there cascading failures?
- What is the sequence of service calls?

### 3. Analyze the Trace Flow
For distributed traces:

```
Use search_by_trace_id for each related trace
```

Answer these questions:
- What was the FIRST component to fail?
- Did the failure propagate from that component?
- Are there timeout patterns?
- Which service reported the initial error?

### 4. Context Gathering
Look for related logs around the failure time:

```
Use query_logs with:
- start_time: <5-10 minutes before first error>
- end_time: <time of first error>
- query: <related service names or operations>
- severity: ["warning", "error", "critical"]
```

### 5. Pattern Recognition
{"Search for occurrences of the error pattern:" if error_pattern else "Search for similar errors:"}

```
Use query_logs with:
- start_time: "{time_window}"
- query: "{error_pattern if error_pattern else '<error message pattern>'}"
```

Questions to answer:
- Is this a recurring issue?
- How frequently does it occur?
- Are there common conditions when it happens?

### 6. Dependency Analysis
Identify dependencies and their states:
- What external services are involved?
- Are there database/cache/queue connections?
- Were there any deployments before the issue?
- Are there resource constraints (memory, CPU, connections)?

### 7. Formulate Root Cause
Based on all evidence, determine:

**Root Cause Statement:**
[Clear, specific statement of what caused the issue]

**Supporting Evidence:**
- Evidence point 1 (with timestamps and trace IDs)
- Evidence point 2
- Evidence point 3

**Why this is the ROOT cause, not a symptom:**
[Explain why this is the originating issue]

**How the failure propagated:**
[Describe the cascade of failures from root cause to observed symptoms]

### 8. Verification
To verify this root cause:
- What additional data would confirm it?
- Are there experiments to run?
- What logs would show the fix working?

### 9. Prevention
Recommendations to prevent recurrence:
- Code changes needed
- Monitoring/alerting to add
- Architecture improvements
- Operational procedures

## Analysis Principles
- Focus on FIRST failure, not cascading effects
- Look for timing correlations
- Consider external factors (deployments, traffic spikes, dependencies)
- Verify hypotheses with data
- Be specific: "service X timed out" not "there was a timeout"

Use the tools systematically and let the data guide your analysis.
"""
        )
    )
    
    return [system_message]


def _parse_time_to_minutes(time_str: str) -> int:
    """Parse time string to minutes.
    
    Args:
        time_str: Time string like "1h", "30m", "2h"
        
    Returns:
        Number of minutes
    """
    time_str = time_str.lower().strip()
    
    if time_str.endswith('h'):
        return int(time_str[:-1]) * 60
    elif time_str.endswith('m'):
        return int(time_str[:-1])
    elif time_str.endswith('d'):
        return int(time_str[:-1]) * 24 * 60
    else:
        # Default to assuming minutes
        return int(time_str)
