"""Distributed trace analysis prompts."""

from typing import Optional
from mcp.types import PromptMessage, TextContent


def create_trace_flow_analysis_prompt(
    trace_id: str,
    include_timing: bool = True
) -> list[PromptMessage]:
    """Create a prompt for analyzing distributed trace execution flow.
    
    This prompt guides detailed analysis of how a request flowed through
    distributed services, including timing, failures, and dependencies.
    
    Args:
        trace_id: The distributed trace ID to analyze
        include_timing: Whether to include detailed timing analysis
        
    Returns:
        List of prompt messages for trace flow analysis workflow
    """
    timing_section = """
### Timing Analysis

Analyze the timing information:

**Service Duration Breakdown:**
| Service | Duration | % of Total | Status |
|---------|----------|------------|--------|
| [Service 1] | [Xms] | [Y%] | [OK/SLOW] |
| [Service 2] | [Xms] | [Y%] | [OK/SLOW] |
| ... | ... | ... | ... |

**Identify:**
- Slowest service(s)
- Services with >30% of total time
- Unexpected delays
- Sequential vs parallel operations

**Bottleneck Detection:**
- Which operation took the longest?
- Are there timeout warnings?
- Is there network latency?
""" if include_timing else ""
    
    system_message = PromptMessage(
        role="user",
        content=TextContent(
            type="text",
            text=f"""You are analyzing distributed trace '{trace_id}' to understand request flow and identify issues.

# Distributed Trace Flow Analysis

## Objective
Map the complete execution flow, identify failures, and understand the request journey through your distributed system.

## Analysis Steps

### Step 1: Retrieve All Trace Logs
Get all logs associated with this trace:

```
Use search_by_trace_id with:
- trace_id: "{trace_id}"
- start_time: (optional, use default 24h lookback)
```

This retrieves logs from all services involved in this trace.

### Step 2: Timeline Construction
Build a chronological timeline of events:

**Timeline Format:**
```
[HH:MM:SS.mmm] [Service] [Severity] [Message]
```

Sort all logs by timestamp to show the sequence of operations.

### Step 3: Service Chain Mapping
Identify the service call chain:

**Request Flow:**
```
[Entry Service]
  → [Service A]
    → [Service B]
      → [Service C]
    → [Service D]
  ← Response
```

For each service:
- When did it receive the request?
- What did it do?
- Which services did it call?
- When did it respond?
{timing_section}
### Step 4: Error Detection and Analysis
Identify any errors in the trace:

**Error Summary:**
| Timestamp | Service | Error Type | Message |
|-----------|---------|------------|---------|
| ... | ... | ... | ... |

For each error:
- Was this the FIRST error in the chain?
- Did it cause downstream failures?
- Is it a timeout, validation, or system error?
- What was the system state before the error?

### Step 5: Span Analysis
If span IDs are present, analyze the span hierarchy:

**Span Hierarchy:**
```
trace_id: {trace_id}
├─ span_id: xxx (root) - [Service A] [duration]
│  ├─ span_id: yyy - [Service B] [duration]
│  │  └─ span_id: zzz - [Service C] [duration]
│  └─ span_id: aaa - [Service D] [duration]
```

### Step 6: Data Flow Analysis
Track how data/context flowed:

**Key Observations:**
- What was the initial request payload/parameters?
- How was data transformed between services?
- Were there validation errors?
- Did all services have necessary context?

### Step 7: Dependency Analysis
Map service dependencies:

**Dependencies Identified:**
- [Service A] depends on [Service B, Service C]
- [Service B] depends on [Database/Cache/External API]
- ...

**Dependency Health:**
- Were all dependencies healthy?
- Any slow dependencies?
- Missing connections?

### Step 8: Generate Flow Analysis Report

---
## Trace Flow Analysis Report
**Trace ID:** {trace_id}
**Analysis Date:** [Current Timestamp]

### Executive Summary
[2-3 sentence overview: Was the trace successful? What was the main outcome?]

### Request Journey
**Entry Point:** [Service and endpoint]
**Exit Point:** [Final service and result]
**Total Duration:** [Total time]
**Services Involved:** [Count and list]
**Status:** [✅ Success | ⚠️ Partial Success | ❌ Failed]

### Service Call Chain
```
[Visual representation of the call flow]
```

### Timeline of Events
[Chronological list of key events with timestamps]

### Error Analysis
{_format_error_analysis_section()}

### Performance Analysis  
**Total Duration:** [Xms]
**Service Breakdown:**
- [Service 1]: [Xms] ([Y%])
- [Service 2]: [Xms] ([Y%])
- ...

**Bottlenecks:**
1. [Service/Operation] took [Xms] ([Y%] of total)
2. ...

### Key Findings
1. [Important observation about the trace]
2. [Issue or pattern identified]
3. [Dependency or timing issue]

### Root Cause (if failed)
**What Failed:**
[Specific service and operation]

**Why It Failed:**
[Analysis of the error and context]

**Impact:**
[What broke as a result]

### Recommendations
1. [Specific actionable recommendation]
2. [Performance improvement suggestion]
3. [Reliability enhancement]

---

## Analysis Quality Guidelines
- Be precise with timestamps (include milliseconds)
- Show causal relationships between events
- Distinguish between cause and effect
- Identify the FIRST failure point
- Calculate and present timing percentages
- Use visual flow diagrams for clarity
- Highlight anomalies or unexpected behavior
- Provide context for why something is concerning

## Common Patterns to Identify

### Success Cases
- Clean sequential flow
- All services responded
- Reasonable timing
- Proper error handling

### Failure Cases
- **Timeout Chain:** Service A times out → Service B fails → Service C fails
- **Cascade Failure:** One service down causes multiple failures
- **Slow Dependency:** External service slow → request timeout
- **Validation Error:** Early validation error → entire flow stops

### Performance Issues
- **Sequential Overhead:** Services called one-by-one instead of parallel
- **N+1 Problem:** Multiple calls to same dependency
- **Large Payload:** Excessive data transfer between services
- **Cold Start:** First call to service takes much longer

Use the tools to gather all trace data and complete the comprehensive flow analysis.
"""
        )
    )
    
    return [system_message]


def _format_error_analysis_section() -> str:
    """Format the error analysis section template."""
    return """
**Errors Detected:** [count]

#### Critical Errors
1. **[Error Message]**
   - Service: [service name]
   - Timestamp: [exact time]
   - Impact: [what failed as a result]
   - Root Cause: [yes/no - is this the root cause?]

#### Downstream Effects
- [Service X] failed because [Service Y] errored
- [Cascading impact description]

**Error Propagation:**
```
[Service A error] → [Service B timeout] → [Service C failed request]
```
"""
