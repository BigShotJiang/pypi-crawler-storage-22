"""Azure Application Insights log provider implementation."""

from datetime import datetime, timedelta
from typing import Optional

from azure.identity.aio import ClientSecretCredential
from azure.monitor.query.aio import LogsQueryClient
from azure.monitor.query import LogsQueryStatus

from ..models import LogEntry, LogProvider, LogSeverity, AzureConfig
from .base import BaseLogProvider


class AzureProvider(BaseLogProvider):
    """Azure Application Insights provider using Kusto Query Language."""
    
    def __init__(self, config: AzureConfig):
        """Initialize Azure provider.
        
        Args:
            config: Azure configuration
        """
        super().__init__(config)
        self.config: AzureConfig = config
        
        # Create credential
        self.credential = ClientSecretCredential(
            tenant_id=config.tenant_id,
            client_id=config.client_id,
            client_secret=config.client_secret,
        )
        
        # Create logs query client
        self.client = LogsQueryClient(self.credential)
    
    async def query_logs(
        self,
        start_time: datetime,
        end_time: datetime,
        query: Optional[str] = None,
        severity: Optional[list[LogSeverity]] = None,
        service_name: Optional[str] = None,
        limit: int = 100,
    ) -> list[LogEntry]:
        """Query logs from Azure using KQL."""
        
        # Build KQL query
        kql = "AppTraces | union AppExceptions"
        
        conditions = []
        
        # Add service name filter
        if service_name:
            conditions.append(f"AppRoleName == '{service_name}'")
        
        # Add text search
        if query:
            conditions.append(f"Message contains '{query}'")
        
        # Add severity filter
        if severity:
            severity_values = [self._map_severity_to_azure(s) for s in severity]
            severity_str = ", ".join(f"'{s}'" for s in severity_values)
            conditions.append(f"SeverityLevel in ({severity_str})")
        
        if conditions:
            kql += " | where " + " and ".join(conditions)
        
        # Add sorting and limit
        kql += f" | order by TimeGenerated desc | limit {min(limit, self.config.max_results)}"
        
        try:
            # Execute query with time range
            response = await self.client.query_workspace(
                workspace_id=self.config.workspace_id,
                query=kql,
                timespan=(start_time, end_time),
            )
            
            if response.status == LogsQueryStatus.SUCCESS:
                logs = []
                for table in response.tables:
                    for row in table.rows:
                        log = self._normalize_log(dict(zip(table.columns, row)))
                        logs.append(log)
                return logs
            else:
                # Partial or failed query
                return []
                
        except Exception as e:
            print(f"Azure query error: {e}")
            return []
    
    async def get_recent_errors(self, minutes: int = 60, limit: int = 100) -> list[LogEntry]:
        """Get recent error logs from Azure."""
        end_time = datetime.utcnow()
        start_time = end_time - timedelta(minutes=minutes)
        
        return await self.query_logs(
            start_time=start_time,
            end_time=end_time,
            severity=[LogSeverity.ERROR, LogSeverity.CRITICAL],
            limit=limit,
        )
    
    async def search_by_trace_id(
        self,
        trace_id: str,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None,
        entity_name: Optional[str] = None,
    ) -> list[LogEntry]:
        """Search logs by trace ID."""
        if not start_time:
            start_time = datetime.utcnow() - timedelta(hours=24)
        if not end_time:
            end_time = datetime.utcnow()
        
        # Build KQL query with optional entity_name filter
        entity_filter = f" and AppRoleName == '{entity_name}'" if entity_name else ""
        
        kql = f"""
        AppTraces | union AppExceptions
        | where OperationId == '{trace_id}'{entity_filter}
        | order by TimeGenerated desc
        | limit 1000
        """
        
        try:
            response = await self.client.query_workspace(
                workspace_id=self.config.workspace_id,
                query=kql,
                timespan=(start_time, end_time),
            )
            
            if response.status == LogsQueryStatus.SUCCESS:
                logs = []
                for table in response.tables:
                    for row in table.rows:
                        log = self._normalize_log(dict(zip(table.columns, row)))
                        logs.append(log)
                return logs
            return []
                
        except Exception as e:
            print(f"Azure trace search error: {e}")
            return []
    
    async def validate_credentials(self) -> bool:
        """Validate Azure credentials."""
        try:
            # Simple query to verify credentials
            kql = "AppTraces | limit 1"
            end_time = datetime.utcnow()
            start_time = end_time - timedelta(minutes=5)
            
            response = await self.client.query_workspace(
                workspace_id=self.config.workspace_id,
                query=kql,
                timespan=(start_time, end_time),
            )
            
            return response.status == LogsQueryStatus.SUCCESS
        except Exception:
            return False
    
    def normalize_severity(self, provider_severity: str) -> LogSeverity:
        """Normalize Azure severity to standard levels."""
        # Azure uses numeric severity levels 0-4
        severity_map = {
            "0": LogSeverity.DEBUG,      # Verbose
            "1": LogSeverity.INFO,       # Information
            "2": LogSeverity.WARNING,    # Warning
            "3": LogSeverity.ERROR,      # Error
            "4": LogSeverity.CRITICAL,   # Critical
        }
        
        return severity_map.get(str(provider_severity), LogSeverity.UNKNOWN)
    
    def _map_severity_to_azure(self, severity: LogSeverity) -> str:
        """Map standard severity to Azure severity levels."""
        severity_map = {
            LogSeverity.DEBUG: "0",
            LogSeverity.INFO: "1",
            LogSeverity.WARNING: "2",
            LogSeverity.ERROR: "3",
            LogSeverity.CRITICAL: "4",
        }
        return severity_map.get(severity, "1")
    
    def _normalize_log(self, raw_log: dict) -> LogEntry:
        """Normalize Azure log to standard format."""
        
        # Extract timestamp
        timestamp = raw_log.get("TimeGenerated", datetime.utcnow())
        if isinstance(timestamp, str):
            timestamp = datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
        
        # Extract severity
        severity_level = raw_log.get("SeverityLevel", "1")
        severity = self.normalize_severity(severity_level)
        
        # Extract message
        message = raw_log.get("Message", "")
        if not message:
            # For exceptions
            message = raw_log.get("ProblemId", "") + ": " + raw_log.get("OuterMessage", "")
        
        return LogEntry(
            timestamp=timestamp,
            severity=severity,
            message=message,
            source=LogProvider.AZURE,
            service_name=raw_log.get("AppRoleName"),
            trace_id=raw_log.get("OperationId"),
            span_id=raw_log.get("Id"),
            user_id=raw_log.get("UserId"),
            host=raw_log.get("AppRoleInstance"),
            environment=raw_log.get("Properties", {}).get("Environment"),
            metadata={
                "operation_name": raw_log.get("OperationName"),
                "cloud_role": raw_log.get("AppRoleName"),
                "sdkVersion": raw_log.get("SDKVersion"),
                "item_type": raw_log.get("ItemType"),
            },
            raw_log=raw_log,
        )
    
    async def __aenter__(self):
        """Async context manager entry."""
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit - cleanup resources."""
        await self.client.close()
        await self.credential.close()