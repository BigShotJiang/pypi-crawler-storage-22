"""Abstract base class for log providers."""

from abc import ABC, abstractmethod
from datetime import datetime
from typing import Optional

from ..logging_config import get_logger
from ..models import LogEntry, LogSeverity, ProviderConfig

logger = get_logger("providers.base")


class BaseLogProvider(ABC):
    """Abstract base class that all log providers must implement."""
    
    def __init__(self, config: ProviderConfig):
        """Initialize the provider with configuration.
        
        Args:
            config: Provider-specific configuration
        """
        self.config = config
        self.enabled = config.enabled
    
    @abstractmethod
    async def query_logs(
        self,
        start_time: datetime,
        end_time: datetime,
        query: Optional[str] = None,
        severity: Optional[list[LogSeverity]] = None,
        entity_name: Optional[str] = None,
        limit: int = 100,
    ) -> list[LogEntry]:
        """Query logs from the provider.
        
        Args:
            start_time: Start of the time range
            end_time: End of the time range
            query: Optional search query/pattern
            severity: Optional list of severity levels to filter
            entity_name: Optional entity name to filter
            limit: Maximum number of results to return
            
        Returns:
            List of normalized log entries
        """
        pass
    
    @abstractmethod
    async def get_recent_errors(
        self,
        minutes: int = 60,
        limit: int = 100,
    ) -> list[LogEntry]:
        """Get recent error logs.
        
        Args:
            minutes: Look back this many minutes
            limit: Maximum number of results
            
        Returns:
            List of error log entries
        """
        pass
    
    @abstractmethod
    async def search_by_trace_id(
        self,
        trace_id: str,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None,
        entity_name: Optional[str] = None,
    ) -> list[LogEntry]:
        """Search logs by trace ID for distributed tracing.
        
        Args:
            trace_id: The trace ID to search for
            start_time: Optional start time
            end_time: Optional end time
            entity_name: Optional entity name to filter results
            
        Returns:
            List of log entries matching the trace ID
        """
        pass
    
    @abstractmethod
    async def validate_credentials(self) -> bool:
        """Validate that credentials are correct and have necessary permissions.
        
        Returns:
            True if credentials are valid, False otherwise
        """
        pass
    
    @abstractmethod
    def normalize_severity(self, provider_severity: str) -> LogSeverity:
        """Normalize provider-specific severity to standard levels.
        
        Args:
            provider_severity: The provider's severity string
            
        Returns:
            Standardized LogSeverity enum value
        """
        pass
    
    def _build_severity_filter(self, severities: Optional[list[LogSeverity]]) -> str:
        """Helper to build provider-specific severity filter.
        
        Args:
            severities: List of severity levels to filter
            
        Returns:
            Provider-specific filter string
        """
        # Override in subclasses for provider-specific syntax
        return ""
    
    async def health_check(self) -> dict[str, any]:
        """Perform a health check on the provider.
        
        Returns:
            Dictionary with health status information
        """
        provider_name = self.__class__.__name__
        logger.debug(f"Performing health check for {provider_name}")
        
        try:
            is_valid = await self.validate_credentials()
            result = {
                "healthy": is_valid,
                "enabled": self.enabled,
                "provider": provider_name,
            }
            
            if is_valid:
                logger.debug(f"{provider_name} health check passed")
            else:
                logger.warning(f"{provider_name} health check failed: invalid credentials")
            
            return result
        except Exception as e:
            logger.error(f"{provider_name} health check error: {e}")
            return {
                "healthy": False,
                "enabled": self.enabled,
                "provider": provider_name,
                "error": str(e),
            }