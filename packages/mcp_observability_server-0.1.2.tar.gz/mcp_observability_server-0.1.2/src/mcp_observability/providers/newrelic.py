"""New Relic log provider implementation."""

import asyncio
from datetime import datetime, timedelta, timezone
from typing import Optional

import httpx

from ..logging_config import get_logger
from ..models import LogEntry, LogProvider, LogSeverity, NewRelicConfig
from .base import BaseLogProvider

logger = get_logger("providers.newrelic")


class NewRelicProvider(BaseLogProvider):
    """New Relic log provider using NRQL queries."""
    
    REGION_URLS = {
        "US": "https://api.newrelic.com",
        "EU": "https://api.eu.newrelic.com",
    }
    
    def __init__(self, config: NewRelicConfig):
        """Initialize New Relic provider.
        
        Args:
            config: New Relic configuration
        """
        super().__init__(config)
        self.config: NewRelicConfig = config
        self.base_url = self.REGION_URLS.get(config.region, self.REGION_URLS["US"])
        self.headers = {
            "API-Key": config.api_key,
            "Content-Type": "application/json",
        }
        logger.info(f"New Relic provider initialized for region: {config.region}")
        logger.debug(f"Using base URL: {self.base_url}")
    
    async def query_logs(
        self,
        start_time: datetime,
        end_time: datetime,
        query: Optional[str] = None,
        severity: Optional[list[LogSeverity]] = None,
        entity_name: Optional[str] = None,
        trace_id: Optional[str] = None,
        limit: int = 100,
    ) -> list[LogEntry]:
        """Query logs from New Relic using NRQL."""
        logger.debug(f"Querying New Relic logs: query={query}, severity={severity}, entity={entity_name}, trace_id={trace_id}")
        
        # Build NRQL query
        nrql = "SELECT * FROM Log"
        
        conditions = []
        
        # Add trace ID filter
        if trace_id:
            conditions.append(f"trace.id = '{trace_id}'")
        
        # Add entity name filter
        if entity_name:
            conditions.append(f"entity.name = '{entity_name}'")
        
        # Add text search
        if query:
            conditions.append(f"message LIKE '%{query}%'")
        
        # Add severity filter
        if severity:
            severity_values = [self._map_severity_to_newrelic(s) for s in severity]
            severity_str = ", ".join(f"'{s}'" for s in severity_values)
            conditions.append(f"level IN ({severity_str})")
        
        if conditions:
            nrql += " WHERE " + " AND ".join(conditions)
        
        # Add time range
        start_ms = int(start_time.timestamp() * 1000)
        end_ms = int(end_time.timestamp() * 1000)
        nrql += f" SINCE {start_ms} UNTIL {end_ms}"
        
        # Add limit
        nrql += f" LIMIT {min(limit, self.config.max_results)}"
        
        logger.debug(f"NRQL query: {nrql}")
        
        # Execute query
        try:
            async with httpx.AsyncClient(timeout=self.config.timeout_seconds) as client:
                url = f"{self.base_url}/graphql"
                
                graphql_query = {
                    "query": f"""
                    {{
                      actor {{
                        account(id: {self.config.account_id}) {{
                          nrql(query: "{nrql}") {{
                            results
                          }}
                        }}
                      }}
                    }}
                    """
                }
                
                logger.debug(f"URL: {url}")
                logger.debug(f"Headers: {{'Api-Key': '***', 'Content-Type': '{self.headers.get('Content-Type')}'}}")
                logger.debug(f"Account ID: {self.config.account_id}")
                logger.debug(f"Executing query log search with NRQL: {nrql}")
                response = await client.post(url, json=graphql_query, headers=self.headers)
                response.raise_for_status()
                
                data = response.json()
                results = data.get("data", {}).get("actor", {}).get("account", {}).get("nrql", {}).get("results", [])
                
                logs = [self._normalize_log(log) for log in results]
                logger.info(f"New Relic query returned {len(logs)} log(s)")
                return logs
        except httpx.HTTPError as e:
            logger.error(f"HTTP error querying New Relic: {e}")
            raise
        except Exception as e:
            logger.error(f"Error querying New Relic: {e}", exc_info=True)
            raise
    
    async def get_recent_errors(self, minutes: int = 60, limit: int = 100) -> list[LogEntry]:
        """Get recent error logs from New Relic."""
        logger.debug(f"Getting recent errors from last {minutes} minutes")
        end_time = datetime.now(timezone.utc)
        start_time = end_time - timedelta(minutes=minutes)
        
        return await self.query_logs(
            start_time=start_time,
            end_time=end_time,
            severity=[LogSeverity.ERROR, LogSeverity.CRITICAL],
            limit=limit,
        )
    
    async def search_by_trace_id(
        self,
        trace_id: str,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None,
        entity_name: Optional[str] = None,
    ) -> list[LogEntry]:
        """Search logs by trace ID."""
        logger.debug(f"Searching for trace_id: {trace_id}, entity_name: {entity_name}")
        
        if not start_time:
            start_time = datetime.now(timezone.utc) - timedelta(hours=24)
        if not end_time:
            end_time = datetime.now(timezone.utc)
        
        return await self.query_logs(
            start_time=start_time,
            end_time=end_time,
            trace_id=trace_id,
            entity_name=entity_name,
            limit=1000,
        )
    
    async def validate_credentials(self) -> bool:
        """Validate New Relic credentials."""
        logger.debug("Validating New Relic credentials")
        try:
            async with httpx.AsyncClient(timeout=10) as client:
                # Simple query to verify credentials
                url = f"{self.base_url}/graphql"
                query = {
                    "query": f"""
                    {{
                      actor {{
                        account(id: {self.config.account_id}) {{
                          name
                        }}
                      }}
                    }}
                    """
                }
                
                response = await client.post(url, json=query, headers=self.headers)
                is_valid = response.status_code == 200
                
                if is_valid:
                    logger.info("New Relic credentials validated successfully")
                else:
                    logger.warning(f"New Relic credential validation failed: status {response.status_code}")
                
                return is_valid
        except Exception as e:
            logger.error(f"Error validating New Relic credentials: {e}")
            return False
    
    def normalize_severity(self, provider_severity: str) -> LogSeverity:
        """Normalize New Relic severity to standard levels."""
        severity_map = {
            "DEBUG": LogSeverity.DEBUG,
            "INFO": LogSeverity.INFO,
            "WARN": LogSeverity.WARNING,
            "WARNING": LogSeverity.WARNING,
            "ERROR": LogSeverity.ERROR,
            "CRITICAL": LogSeverity.CRITICAL,
            "FATAL": LogSeverity.CRITICAL,
        }
        
        return severity_map.get(provider_severity.upper(), LogSeverity.UNKNOWN)
    
    def _map_severity_to_newrelic(self, severity: LogSeverity) -> str:
        """Map standard severity to New Relic severity."""
        severity_map = {
            LogSeverity.DEBUG: "DEBUG",
            LogSeverity.INFO: "INFO",
            LogSeverity.WARNING: "WARN",
            LogSeverity.ERROR: "ERROR",
            LogSeverity.CRITICAL: "CRITICAL",
        }
        return severity_map.get(severity, "INFO")
    
    def _normalize_log(self, raw_log: dict) -> LogEntry:
        """Normalize New Relic log to standard format."""
        
        # Extract timestamp
        timestamp_ms = raw_log.get("timestamp", datetime.now(timezone.utc).timestamp() * 1000)
        timestamp = datetime.fromtimestamp(timestamp_ms / 1000, tz=timezone.utc)
        
        # Extract severity
        level = raw_log.get("level", "INFO")
        severity = self.normalize_severity(level)
        
        # Extract message
        message = raw_log.get("message", "")
        
        return LogEntry(
            timestamp=timestamp,
            severity=severity,
            message=message,
            source=LogProvider.NEW_RELIC,
            service_name=raw_log.get("service.name"),
            trace_id=raw_log.get("trace.id"),
            span_id=raw_log.get("span.id"),
            host=raw_log.get("hostname") or raw_log.get("host"),
            environment=raw_log.get("environment"),
            metadata={
                "entity_name": raw_log.get("entity.name"),
                "entity_type": raw_log.get("entity.type"),
            },
            raw_log=raw_log,
        )