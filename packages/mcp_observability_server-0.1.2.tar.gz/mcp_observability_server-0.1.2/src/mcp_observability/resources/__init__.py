"""Resources package for MCP observability server."""

from mcp_observability.resources.resource_handler import ResourceHandlers

__all__ = ["ResourceHandlers"]
