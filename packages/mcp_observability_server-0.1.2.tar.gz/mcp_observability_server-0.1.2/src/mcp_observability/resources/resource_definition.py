"""Resource definitions and metadata for MCP observability server.

This module defines the resource URI patterns, metadata structures,
and constants used by the MCP observability resources.
"""

from enum import Enum
from typing import Any, TypedDict


# Resource URI Patterns
class ResourceURIPattern:
    """MCP resource URI patterns."""
    
    # Log resources
    LOG_RECENT = "log://{provider}/recent"
    LOG_ERRORS = "log://{provider}/errors"
    
    # Health resources
    HEALTH = "health://{provider}"
    
    # Trace resources
    TRACE = "trace://{trace_id}"
    TRACES_ACTIVE = "traces://active"
    
    # File resources
    FILE_EXPORTS = "file://exports"
    FILE_EXPORT = "file://exports/{filename}"
    
    # Configuration resources
    CONFIG_OBSERVABILITY = "config://observability"
    
    # Catalog resources
    CATALOG_SERVICES = "catalog://services"
    
    # Statistics resources
    STATS_ERRORS = "stats://errors/{period}"


class ResourceCategory(str, Enum):
    """Resource categories for grouping."""
    
    LOGS = "logs"
    HEALTH = "health"
    TRACES = "traces"
    FILES = "files"
    CONFIG = "config"
    CATALOG = "catalog"
    STATISTICS = "statistics"


class ResourceMetadata(TypedDict, total=False):
    """Metadata structure for resource responses."""
    
    timestamp: str
    provider: str
    count: int
    time_range: dict[str, str]


class ServiceCatalogEntry(TypedDict, total=False):
    """Service catalog entry structure."""
    
    name: str
    log_count: int
    first_seen: str
    last_seen: str
    providers: list[str]


class TraceEntry(TypedDict):
    """Trace entry structure."""
    
    trace_id: str
    log_count: int
    services: list[str]
    first_seen: str
    last_seen: str
    duration_ms: float
    has_errors: bool
    providers: list[str]


class ErrorStatistics(TypedDict):
    """Error statistics structure."""
    
    period: str
    time_range: dict[str, str]
    total_errors: int
    by_severity: dict[str, int]
    by_provider: dict[str, int]
    top_services: list[dict[str, Any]]
    hourly_distribution: list[dict[str, Any]]


class ExportedFileInfo(TypedDict):
    """Exported file information structure."""
    
    filename: str
    uri: str
    size_bytes: int
    modified: str


class HealthStatus(TypedDict):
    """Health status structure."""
    
    healthy: bool
    enabled: bool
    error: str | None


# Resource Constants
DEFAULT_QUERY_LIMIT = 100
DEFAULT_LOOKBACK_HOURS = 1
DEFAULT_CATALOG_LOOKBACK_HOURS = 24
DEFAULT_TRACE_LOOKBACK_HOURS = 24
DEFAULT_ERROR_PERIOD = "24h"
MAX_CATALOG_LOGS = 1000
MAX_ERROR_LOGS = 1000
MAX_TRACE_LOGS = 1000
TOP_SERVICES_LIMIT = 10

# Provider identifier
ALL_PROVIDERS = "all"
