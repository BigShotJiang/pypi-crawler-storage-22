"""Resource handlers for MCP observability server."""

import json
import os
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Optional

from mcp_observability.logging_config import get_logger
from mcp_observability.models import LogEntry, LogSeverity
from mcp_observability.resources.resource_definition import (
    ALL_PROVIDERS,
    DEFAULT_CATALOG_LOOKBACK_HOURS,
    DEFAULT_LOOKBACK_HOURS,
    DEFAULT_QUERY_LIMIT,
    DEFAULT_TRACE_LOOKBACK_HOURS,
    MAX_CATALOG_LOGS,
    MAX_ERROR_LOGS,
    MAX_TRACE_LOGS,
    TOP_SERVICES_LIMIT,
)

logger = get_logger("resource_handlers")


class ResourceHandlers:
    """Handlers for MCP resources."""
    
    def __init__(self, providers: dict):
        """Initialize resource handlers.
        
        Args:
            providers: Dictionary of provider instances
        """
        self.providers = providers
    
    async def get_recent_logs(
        self,
        provider_name: str = ALL_PROVIDERS,
        limit: int = DEFAULT_QUERY_LIMIT,
        severity: Optional[str] = None
    ) -> dict[str, Any]:
        """Get recent logs from a provider.
        
        Args:
            provider_name: Provider name or 'all' for all providers
            limit: Maximum number of logs to return
            severity: Optional severity filter
            
        Returns:
            Dictionary with logs and metadata
        """
        logger.info(f"Fetching recent logs from {provider_name}")
        
        end_time = datetime.now(timezone.utc)
        start_time = end_time - timedelta(hours=DEFAULT_LOOKBACK_HOURS)
        
        # Filter severity if provided
        severity_filter = None
        if severity:
            try:
                severity_filter = [LogSeverity(severity)]
            except ValueError:
                logger.warning(f"Invalid severity: {severity}")
        
        all_logs = []
        providers_to_query = []
        
        if provider_name == ALL_PROVIDERS:
            providers_to_query = [
                (name, p) for name, p in self.providers.items() if p.enabled
            ]
        elif provider_name in self.providers:
            provider = self.providers[provider_name]
            if provider.enabled:
                providers_to_query = [(provider_name, provider)]
        
        # Query providers
        for name, provider in providers_to_query:
            try:
                logs = await provider.query_logs(
                    start_time=start_time,
                    end_time=end_time,
                    severity=severity_filter,
                    limit=limit
                )
                all_logs.extend(logs)
                logger.debug(f"{name}: Retrieved {len(logs)} logs")
            except Exception as e:
                logger.error(f"{name}: Failed to fetch logs - {e}")
        
        # Sort by timestamp
        all_logs.sort(key=lambda x: x.timestamp, reverse=True)
        all_logs = all_logs[:limit]
        
        return {
            "provider": provider_name,
            "count": len(all_logs),
            "time_range": {
                "start": start_time.isoformat(),
                "end": end_time.isoformat()
            },
            "logs": [self._serialize_log(log) for log in all_logs]
        }
    
    async def get_provider_health(self, provider_name: str = ALL_PROVIDERS) -> dict[str, Any]:
        """Get health status of providers.
        
        Args:
            provider_name: Provider name or 'all' for all providers
            
        Returns:
            Health status information
        """
        logger.info(f"Checking health for {provider_name}")
        
        results = {}
        
        if provider_name == ALL_PROVIDERS:
            for name, provider in self.providers.items():
                try:
                    health = await provider.health_check()
                    results[name] = health
                except Exception as e:
                    results[name] = {
                        "healthy": False,
                        "enabled": provider.enabled,
                        "error": str(e)
                    }
        elif provider_name in self.providers:
            provider = self.providers[provider_name]
            try:
                health = await provider.health_check()
                results[provider_name] = health
            except Exception as e:
                results[provider_name] = {
                    "healthy": False,
                    "enabled": provider.enabled,
                    "error": str(e)
                }
        
        return {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "providers": results
        }
    
    async def get_trace_logs(self, trace_id: str) -> dict[str, Any]:
        """Get all logs for a specific trace ID.
        
        Args:
            trace_id: Trace ID to search for
            
        Returns:
            Trace logs and metadata
        """
        logger.info(f"Fetching logs for trace: {trace_id}")
        
        end_time = datetime.now(timezone.utc)
        start_time = end_time - timedelta(hours=DEFAULT_TRACE_LOOKBACK_HOURS)
        
        all_logs = []
        
        for name, provider in self.providers.items():
            if not provider.enabled:
                continue
                
            try:
                logs = await provider.search_by_trace_id(
                    trace_id=trace_id,
                    start_time=start_time,
                    end_time=end_time
                )
                all_logs.extend(logs)
                logger.debug(f"{name}: Found {len(logs)} logs for trace")
            except Exception as e:
                logger.error(f"{name}: Failed to search trace - {e}")
        
        # Sort chronologically
        all_logs.sort(key=lambda x: x.timestamp)
        
        return {
            "trace_id": trace_id,
            "count": len(all_logs),
            "time_range": {
                "start": start_time.isoformat(),
                "end": end_time.isoformat()
            },
            "logs": [self._serialize_log(log) for log in all_logs]
        }
    
    def list_exported_files(self) -> dict[str, Any]:
        """List all exported log files.
        
        Returns:
            List of exported files with metadata
        """
        export_dir = Path("exports")
        
        if not export_dir.exists():
            return {
                "count": 0,
                "files": []
            }
        
        files = []
        for file_path in export_dir.glob("*.json"):
            try:
                stat = file_path.stat()
                files.append({
                    "filename": file_path.name,
                    "uri": f"file://exports/{file_path.name}",
                    "size_bytes": stat.st_size,
                    "modified": datetime.fromtimestamp(stat.st_mtime, tz=timezone.utc).isoformat()
                })
            except Exception as e:
                logger.error(f"Failed to read file {file_path}: {e}")
        
        # Sort by modified time, newest first
        files.sort(key=lambda x: x["modified"], reverse=True)
        
        return {
            "directory": str(export_dir),
            "count": len(files),
            "files": files
        }
    
    def get_exported_file(self, filename: str) -> dict[str, Any]:
        """Get contents of an exported file.
        
        Args:
            filename: Name of the exported file
            
        Returns:
            File contents and metadata
        """
        file_path = Path("exports") / filename
        
        if not file_path.exists():
            raise FileNotFoundError(f"Export file not found: {filename}")
        
        if not file_path.is_file():
            raise ValueError(f"Not a file: {filename}")
        
        try:
            with open(file_path, 'r') as f:
                data = json.load(f)
            
            stat = file_path.stat()
            
            return {
                "filename": filename,
                "size_bytes": stat.st_size,
                "modified": datetime.fromtimestamp(stat.st_mtime, tz=timezone.utc).isoformat(),
                "data": data
            }
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON in file: {e}")
    
    def get_configuration(self) -> dict[str, Any]:
        """Get server configuration (with sensitive data masked).
        
        Returns:
            Configuration information
        """
        providers_info = {}
        
        for name, provider in self.providers.items():
            config = provider.config
            providers_info[name] = {
                "enabled": config.enabled,
                "timeout_seconds": config.timeout_seconds,
                "max_results": config.max_results,
            }
            
            # Add provider-specific non-sensitive config
            if hasattr(config, 'region'):
                providers_info[name]["region"] = config.region
        
        return {
            "providers": providers_info,
            "total_providers": len(self.providers),
            "enabled_providers": sum(1 for p in self.providers.values() if p.enabled)
        }
    
    async def get_service_catalog(self) -> dict[str, Any]:
        """Get catalog of all services discovered in logs.
        
        Returns:
            Service catalog with metadata
        """
        logger.info("Building service catalog")
        
        end_time = datetime.now(timezone.utc)
        start_time = end_time - timedelta(hours=DEFAULT_CATALOG_LOOKBACK_HOURS)
        
        services = defaultdict(lambda: {
            "count": 0,
            "first_seen": None,
            "last_seen": None,
            "providers": set()
        })
        
        # Query recent logs from all providers
        await self._aggregate_service_data(services, start_time, end_time)
        
        # Convert to serializable format
        catalog = self._build_service_catalog_entries(services)
        
        # Sort by log count
        catalog.sort(key=lambda x: x["log_count"], reverse=True)
        
        return {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "time_range": {
                "start": start_time.isoformat(),
                "end": end_time.isoformat()
            },
            "service_count": len(catalog),
            "services": catalog
        }
    
    async def _aggregate_service_data(
        self,
        services: dict,
        start_time: datetime,
        end_time: datetime
    ):
        """Aggregate service data from providers.
        
        Args:
            services: Dictionary to populate with service data
            start_time: Start time for queries
            end_time: End time for queries
        """
        for name, provider in self.providers.items():
            if not provider.enabled:
                continue
            
            try:
                logs = await provider.query_logs(
                    start_time=start_time,
                    end_time=end_time,
                    limit=MAX_CATALOG_LOGS
                )
                
                self._update_service_catalog(services, logs, name)
                
            except Exception as e:
                logger.error(f"{name}: Failed to fetch logs for catalog - {e}")
    
    @staticmethod
    def _update_service_catalog(services: dict, logs: list[LogEntry], provider_name: str):
        """Update service catalog with logs from a provider.
        
        Args:
            services: Dictionary to update
            logs: List of log entries
            provider_name: Name of the provider
        """
        for log in logs:
            if log.service_name:
                service = services[log.service_name]
                service["count"] += 1
                service["providers"].add(provider_name)
                
                if service["first_seen"] is None or log.timestamp < service["first_seen"]:
                    service["first_seen"] = log.timestamp
                if service["last_seen"] is None or log.timestamp > service["last_seen"]:
                    service["last_seen"] = log.timestamp
    
    async def get_error_statistics(self, period: str = "24h") -> dict[str, Any]:
        """Get error statistics for a time period.
        
        Args:
            period: Time period (e.g., '1h', '24h', '7d')
            
        Returns:
            Error statistics and trends
        """
        logger.info(f"Calculating error statistics for period: {period}")
        
        # Parse period
        end_time = datetime.now(timezone.utc)
        if period.endswith('h'):
            hours = int(period[:-1])
            start_time = end_time - timedelta(hours=hours)
        elif period.endswith('d'):
            days = int(period[:-1])
            start_time = end_time - timedelta(days=days)
        else:
            start_time = end_time - timedelta(hours=24)
        
        error_severities = [LogSeverity.ERROR, LogSeverity.CRITICAL]
        all_errors = []
        provider_counts = {}
        
        for name, provider in self.providers.items():
            if not provider.enabled:
                continue
            
            try:
                logs = await provider.query_logs(
                    start_time=start_time,
                    end_time=end_time,
                    severity=error_severities,
                    limit=MAX_ERROR_LOGS
                )
                all_errors.extend(logs)
                provider_counts[name] = len(logs)
                logger.debug(f"{name}: Found {len(logs)} errors")
            except Exception as e:
                logger.error(f"{name}: Failed to fetch errors - {e}")
                provider_counts[name] = 0
        
        # Calculate statistics
        severity_counts = defaultdict(int)
        service_counts = defaultdict(int)
        hourly_counts = defaultdict(int)
        
        for log in all_errors:
            severity_counts[log.severity.value] += 1
            if log.service_name:
                service_counts[log.service_name] += 1
            
            # Group by hour
            hour_key = log.timestamp.replace(minute=0, second=0, microsecond=0).isoformat()
            hourly_counts[hour_key] += 1
        
        # Top services by error count
        top_services = sorted(
            [{"service": k, "count": v} for k, v in service_counts.items()],
            key=lambda x: x["count"],
            reverse=True
        )[:TOP_SERVICES_LIMIT]
        
        # Hourly distribution
        hourly_distribution = [
            {"hour": k, "count": v} 
            for k, v in sorted(hourly_counts.items())
        ]
        
        return {
            "period": period,
            "time_range": {
                "start": start_time.isoformat(),
                "end": end_time.isoformat()
            },
            "total_errors": len(all_errors),
            "by_severity": dict(severity_counts),
            "by_provider": provider_counts,
            "top_services": top_services,
            "hourly_distribution": hourly_distribution
        }
    
    async def get_active_traces(self, hours: int = DEFAULT_LOOKBACK_HOURS) -> dict[str, Any]:
        """Get list of active trace IDs from recent logs.
        
        Args:
            hours: Number of hours to look back
            
        Returns:
            List of active traces
        """
        logger.info(f"Fetching active traces from last {hours} hour(s)")
        
        end_time = datetime.now(timezone.utc)
        start_time = end_time - timedelta(hours=hours)
        
        traces = {}  # trace_id -> metadata
        
        # Aggregate trace data from all providers
        await self._aggregate_trace_data(traces, start_time, end_time)
        
        # Convert to list and serialize
        trace_list = self._build_trace_list(traces)
        
        # Sort by most recent
        trace_list.sort(key=lambda x: x["last_seen"], reverse=True)
        
        return {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "time_range": {
                "start": start_time.isoformat(),
                "end": end_time.isoformat()
            },
            "trace_count": len(trace_list),
            "traces": trace_list
        }
    
    async def _aggregate_trace_data(
        self,
        traces: dict,
        start_time: datetime,
        end_time: datetime
    ):
        """Aggregate trace data from providers.
        
        Args:
            traces: Dictionary to populate with trace data
            start_time: Start time for queries
            end_time: End time for queries
        """
        for name, provider in self.providers.items():
            if not provider.enabled:
                continue
            
            try:
                logs = await provider.query_logs(
                    start_time=start_time,
                    end_time=end_time,
                    limit=MAX_TRACE_LOGS
                )
                
                self._update_trace_catalog(traces, logs, name)
                
            except Exception as e:
                logger.error(f"{name}: Failed to fetch traces - {e}")
    
    @staticmethod
    def _update_trace_catalog(traces: dict, logs: list[LogEntry], provider_name: str):
        """Update trace catalog with logs from a provider.
        
        Args:
            traces: Dictionary to update
            logs: List of log entries
            provider_name: Name of the provider
        """
        for log in logs:
            if not log.trace_id:
                continue
                
            if log.trace_id not in traces:
                traces[log.trace_id] = {
                    "trace_id": log.trace_id,
                    "log_count": 0,
                    "services": set(),
                    "first_seen": log.timestamp,
                    "last_seen": log.timestamp,
                    "has_errors": False,
                    "providers": set()
                }
            
            trace = traces[log.trace_id]
            trace["log_count"] += 1
            trace["providers"].add(provider_name)
            
            if log.service_name:
                trace["services"].add(log.service_name)
            
            if log.severity in [LogSeverity.ERROR, LogSeverity.CRITICAL]:
                trace["has_errors"] = True
            
            if log.timestamp < trace["first_seen"]:
                trace["first_seen"] = log.timestamp
            if log.timestamp > trace["last_seen"]:
                trace["last_seen"] = log.timestamp
    
    @staticmethod
    def _build_service_catalog_entries(services: dict) -> list[dict[str, Any]]:
        """Build service catalog entries from services dict.
        
        Args:
            services: Dictionary of service name to metadata
            
        Returns:
            List of service catalog entries
        """
        catalog = []
        for service_name, data in services.items():
            catalog.append({
                "name": service_name,
                "log_count": data["count"],
                "first_seen": data["first_seen"].isoformat() if data["first_seen"] else None,
                "last_seen": data["last_seen"].isoformat() if data["last_seen"] else None,
                "providers": sorted(data["providers"])
            })
        return catalog
    
    @staticmethod
    def _build_trace_list(traces: dict) -> list[dict[str, Any]]:
        """Build trace list from traces dict.
        
        Args:
            traces: Dictionary of trace_id to metadata
            
        Returns:
            List of trace entries
        """
        trace_list = []
        for trace_data in traces.values():
            trace_list.append({
                "trace_id": trace_data["trace_id"],
                "log_count": trace_data["log_count"],
                "services": sorted(trace_data["services"]),
                "first_seen": trace_data["first_seen"].isoformat(),
                "last_seen": trace_data["last_seen"].isoformat(),
                "duration_ms": (trace_data["last_seen"] - trace_data["first_seen"]).total_seconds() * 1000,
                "has_errors": trace_data["has_errors"],
                "providers": sorted(trace_data["providers"])
            })
        return trace_list
    
    @staticmethod
    def _serialize_log(log: LogEntry) -> dict[str, Any]:
        """Serialize a log entry to dictionary.
        
        Args:
            log: LogEntry to serialize
            
        Returns:
            Dictionary representation
        """
        return {
            "timestamp": log.timestamp.isoformat(),
            "severity": log.severity.value,
            "message": log.message,
            "source": log.source.value,
            "service_name": log.service_name,
            "trace_id": log.trace_id,
            "span_id": log.span_id,
            "user_id": log.user_id,
            "host": log.host,
            "environment": log.environment,
            "metadata": log.metadata
        }
