"""MCP server for querying logs from multiple observability platforms."""

import asyncio
import json
from typing import Any, Callable, Optional

from mcp.server.fastmcp import FastMCP
from mcp.types import PromptMessage, TextContent

from mcp_observability.config import create_provider_configs, load_config_file
from mcp_observability.logging_config import get_logger, setup_logging
from mcp_observability.prompts import (
    create_health_check_report_prompt,
    create_investigate_incident_prompt,
    create_post_deployment_check_prompt,
    create_root_cause_analysis_prompt,
    create_trace_flow_analysis_prompt,
)
from mcp_observability.providers import NewRelicProvider
from mcp_observability.resources import ResourceHandlers
from mcp_observability.tools.tool_handlers import ToolHandlers

logger = get_logger("server")

# Constants
EMPTY_RESULT = ""
DEFAULT_EXPORT_DIR = "exports"
DEFAULT_QUERY_LIMIT = 100
DEFAULT_ERROR_MINUTES = 60

# Global server instance for MCP
mcp = FastMCP("observability-logs")

# Global state for providers and handlers
_providers = {}
_tool_handlers = None
_resource_handlers = None


def _initialize_providers(config_path: Optional[str] = None):
    """Initialize providers from configuration.
    
    This function:
    1. Loads the configuration file
    2. Creates provider configs
    3. Initializes each configured provider
    4. Sets up the tool handlers
    
    Args:
        config_path: Path to configuration file. If None, uses default 'config.yaml'
        
    Raises:
        ConfigurationError: If configuration cannot be loaded
        Exception: If provider initialization fails critically
    """
    global _providers, _tool_handlers, _resource_handlers
    
    logger.info("Initializing MCP Observability Server")
    logger.debug(f"Config path: {config_path or 'config.yaml (default)'}")
    
    # Load configuration
    config = load_config_file(config_path)
    provider_configs = create_provider_configs(config)
    
    # Initialize providers
    logger.info(f"Initializing {len(provider_configs)} provider(s)")
    _initialize_provider_instances(provider_configs)
    
    # Initialize tool handlers with all providers
    _tool_handlers = ToolHandlers(_providers)
    
    # Initialize resource handlers with all providers
    _resource_handlers = ResourceHandlers(_providers)
    
    logger.info(f"Server initialized with {len(_providers)} active provider(s)")


def _initialize_provider_instances(provider_configs: dict):
    """Initialize individual provider instances.
    
    This function is separate to make it easier to add new providers.
    
    Args:
        provider_configs: Dictionary mapping provider names to their configs
    """
    # Provider registry - add new providers here
    provider_classes = {
        "newrelic": NewRelicProvider,
        # Future providers can be added here:
        # "azure": AzureProvider,
        # "datadog": DatadogProvider,
    }
    
    for provider_name, config in provider_configs.items():
        if provider_name not in provider_classes:
            logger.warning(f"Unknown provider '{provider_name}', skipping")
            continue
            
        provider_class = provider_classes[provider_name]
        logger.info(f"Initializing {provider_name} provider")
        
        try:
            _providers[provider_name] = provider_class(config)
            logger.info(f"{provider_name} provider initialized successfully")
        except Exception as e:
            logger.error(f"Failed to initialize {provider_name} provider: {e}", exc_info=True)
            # Continue with other providers instead of failing completely


async def _call_tool_handler(
    handler: Callable,
    arguments: dict[str, Any]
) -> str:
    """Call a tool handler and extract the text result.
    
    This helper reduces code duplication across tool implementations.
    
    Args:
        handler: The handler method to call
        arguments: Arguments to pass to the handler
        
    Returns:
        Text result from handler, or empty string if no result
    """
    try:
        result = await handler(arguments)
        return result[0].text if result and len(result) > 0 else EMPTY_RESULT
    except Exception as e:
        logger.error(f"Error in tool handler: {e}", exc_info=True)
        return f"Error: {str(e)}"


# Tool definitions using FastMCP decorators
@mcp.tool()
async def query_logs(
    start_time: str,
    end_time: Optional[str] = None,
    query: Optional[str] = None,
    severity: Optional[list[str]] = None,
    entity_name: Optional[str] = None,
    limit: int = DEFAULT_QUERY_LIMIT,
    providers: Optional[list[str]] = None,
    export: bool = False,
    output_dir: str = DEFAULT_EXPORT_DIR,
    filename: Optional[str] = None
) -> str:
    """Query logs from all configured observability platforms.
    
    Search across New Relic, Azure Application Insights.
    
    Args:
        start_time: Start time in ISO format (e.g., '2024-01-01T00:00:00Z') or relative like '1h' for 1 hour ago
        end_time: End time in ISO format. Defaults to now if not specified
        query: Search text to find in log messages
        severity: Filter by severity levels (debug, info, warning, error, critical)
        entity_name: Filter by entity name
        limit: Maximum number of results (default: 100)
        providers: Specific providers to query. If not specified, queries all enabled providers
        export: Export results to a JSON file instead of returning formatted text
        output_dir: Output directory for export (default: 'exports')
        filename: Output filename for export (default: auto-generated)
    
    Returns:
        Formatted query results or export confirmation
    """
    return await _call_tool_handler(
        _tool_handlers.handle_query_logs,
        {
            "start_time": start_time,
            "end_time": end_time,
            "query": query,
            "severity": severity,
            "entity_name": entity_name,
            "limit": limit,
            "providers": providers,
            "export": export,
            "output_dir": output_dir,
            "filename": filename,
        }
    )


@mcp.tool()
async def get_recent_errors(
    minutes: int = DEFAULT_ERROR_MINUTES,
    limit: int = DEFAULT_QUERY_LIMIT,
    entity_name: Optional[str] = None,
    export: bool = False,
    output_dir: str = DEFAULT_EXPORT_DIR,
    filename: Optional[str] = None
) -> str:
    """Get recent error and critical logs from all platforms.
    
    Useful for quick incident investigation.
    
    Args:
        minutes: Look back this many minutes (default: 60)
        limit: Maximum number of results per provider (default: 100)
        entity_name: Filter by entity name
        export: Export results to a JSON file instead of returning formatted text
        output_dir: Output directory for export (default: 'exports')
        filename: Output filename for export (default: auto-generated)
    
    Returns:
        Formatted error results or export confirmation
    """
    return await _call_tool_handler(
        _tool_handlers.handle_get_recent_errors,
        {
            "minutes": minutes,
            "limit": limit,
            "entity_name": entity_name,
            "export": export,
            "output_dir": output_dir,
            "filename": filename,
        }
    )


@mcp.tool()
async def search_by_trace_id(
    trace_id: str,
    start_time: Optional[str] = None,
    end_time: Optional[str] = None,
    entity_name: Optional[str] = None,
    export: bool = False,
    output_dir: str = DEFAULT_EXPORT_DIR,
    filename: Optional[str] = None
) -> str:
    """Search for all logs related to a distributed trace ID across all platforms.
    
    Useful for debugging distributed systems.
    
    Args:
        trace_id: The trace ID to search for
        start_time: Optional start time. Defaults to 24 hours ago
        end_time: Optional end time. Defaults to now
        entity_name: Optional entity name to filter results
        export: Export results to a JSON file instead of returning formatted text
        output_dir: Output directory for export (default: 'exports')
        filename: Output filename for export (default: auto-generated)
    
    Returns:
        Formatted trace results or export confirmation
    """
    return await _call_tool_handler(
        _tool_handlers.handle_search_by_trace_id,
        {
            "trace_id": trace_id,
            "start_time": start_time,
            "end_time": end_time,
            "entity_name": entity_name,
            "export": export,
            "output_dir": output_dir,
            "filename": filename,
        }
    )


@mcp.tool()
async def health_check() -> str:
    """Check the health and connectivity of all configured log providers.
    
    Returns:
        Health check results for providers
    """
    return await _call_tool_handler(
        _tool_handlers.handle_health_check,
        {}
    )


@mcp.tool()
async def export_logs(
    start_time: str,
    end_time: Optional[str] = None,
    query: Optional[str] = None,
    severity: Optional[list[str]] = None,
    entity_name: Optional[str] = None,
    limit: int = DEFAULT_QUERY_LIMIT,
    providers: Optional[list[str]] = None,
    output_dir: str = DEFAULT_EXPORT_DIR,
    filename: Optional[str] = None
) -> str:
    """Export logs to a JSON file.
    
    Query logs from observability platforms and save results to disk.
    
    Args:
        start_time: Start time in ISO format or relative like '1h' for 1 hour ago
        end_time: End time in ISO format. Defaults to now if not specified
        query: Search text to find in log messages
        severity: Filter by severity levels
        entity_name: Filter by entity name
        limit: Maximum number of results (default: 100)
        providers: Specific providers to query. If not specified, queries all enabled providers
        output_dir: Output directory path (default: 'exports')
        filename: Output filename (default: auto-generated based on timestamp)
    
    Returns:
        Export confirmation with file path
    """
    return await _call_tool_handler(
        _tool_handlers.handle_export_logs,
        {
            "start_time": start_time,
            "end_time": end_time,
            "query": query,
            "severity": severity,
            "entity_name": entity_name,
            "limit": limit,
            "providers": providers,
            "output_dir": output_dir,
            "filename": filename,
        }
    )


# Resource definitions using FastMCP decorators
@mcp.resource("log://{provider}/recent")
async def get_recent_logs_resource(provider: str) -> str:
    """Get recent logs from a provider.
    
    URI pattern: log://{provider}/recent
    - provider can be 'all', 'newrelic', 'azure', etc.
    
    Returns:
        JSON string with recent logs
    """
    result = await _resource_handlers.get_recent_logs(provider_name=provider)
    return json.dumps(result, indent=2)


@mcp.resource("log://{provider}/errors")
async def get_recent_errors_resource(provider: str) -> str:
    """Get recent error logs from a provider.
    
    URI pattern: log://{provider}/errors
    
    Returns:
        JSON string with recent error logs
    """
    result = await _resource_handlers.get_recent_logs(
        provider_name=provider,
        severity="error"
    )
    return json.dumps(result, indent=2)


@mcp.resource("health://{provider}")
async def get_health_resource(provider: str) -> str:
    """Get health status of a provider.
    
    URI pattern: health://{provider}
    - provider can be 'all', 'newrelic', 'azure', etc.
    
    Returns:
        JSON string with health status
    """
    result = await _resource_handlers.get_provider_health(provider_name=provider)
    return json.dumps(result, indent=2)


@mcp.resource("trace://{trace_id}")
async def get_trace_resource(trace_id: str) -> str:
    """Get all logs for a specific trace ID.
    
    URI pattern: trace://{trace_id}
    
    Returns:
        JSON string with trace logs
    """
    result = await _resource_handlers.get_trace_logs(trace_id=trace_id)
    return json.dumps(result, indent=2)


@mcp.resource("file://exports")
async def list_exports_resource() -> str:
    """List all exported log files.
    
    URI pattern: file://exports
    
    Returns:
        JSON string with list of exported files
    """
    result = _resource_handlers.list_exported_files()
    return json.dumps(result, indent=2)


@mcp.resource("file://exports/{filename}")
async def get_export_file_resource(filename: str) -> str:
    """Get contents of an exported file.
    
    URI pattern: file://exports/{filename}
    
    Returns:
        JSON string with file contents
    """
    try:
        result = _resource_handlers.get_exported_file(filename=filename)
        return json.dumps(result, indent=2)
    except (FileNotFoundError, ValueError) as e:
        return json.dumps({"error": str(e)}, indent=2)


@mcp.resource("config://observability")
async def get_config_resource() -> str:
    """Get server configuration (with sensitive data masked).
    
    URI pattern: config://observability
    
    Returns:
        JSON string with configuration
    """
    result = _resource_handlers.get_configuration()
    return json.dumps(result, indent=2)


@mcp.resource("catalog://services")
async def get_service_catalog_resource() -> str:
    """Get catalog of all services discovered in logs.
    
    URI pattern: catalog://services
    
    Returns:
        JSON string with service catalog
    """
    result = await _resource_handlers.get_service_catalog()
    return json.dumps(result, indent=2)


@mcp.resource("stats://errors/{period}")
async def get_error_stats_resource(period: str) -> str:
    """Get error statistics for a time period.
    
    URI pattern: stats://errors/{period}
    - period can be '1h', '24h', '7d', etc.
    
    Returns:
        JSON string with error statistics
    """
    result = await _resource_handlers.get_error_statistics(period=period)
    return json.dumps(result, indent=2)


@mcp.resource("traces://active")
async def get_active_traces_resource() -> str:
    """Get list of active trace IDs from recent logs.
    
    URI pattern: traces://active
    
    Returns:
        JSON string with active traces (last 1 hour)
    """
    result = await _resource_handlers.get_active_traces(hours=1)
    return json.dumps(result, indent=2)


# Prompt definitions using FastMCP decorators
@mcp.prompt()
def investigate_incident(
    service_name: Optional[str] = None,
    time_period: str = "1h",
    severity_threshold: str = "error"
) -> list[PromptMessage]:
    """Guide systematic incident investigation for a service.
    
    This prompt provides a structured workflow for investigating production incidents,
    including error analysis, trace investigation, and pattern detection.
    
    Args:
        service_name: Name of the service to investigate (optional, defaults to all services)
        time_period: Time period to investigate (e.g., "1h", "30m", "2h", default: "1h")
        severity_threshold: Minimum severity level to investigate (default: "error")
    
    Returns:
        Guided workflow for incident investigation
    """
    return create_investigate_incident_prompt(
        service_name=service_name,
        time_period=time_period,
        severity_threshold=severity_threshold
    )


@mcp.prompt()
def root_cause_analysis(
    trace_id: Optional[str] = None,
    error_pattern: Optional[str] = None,
    time_window: str = "1h"
) -> list[PromptMessage]:
    """Guide deep root cause analysis for production issues.
    
    This prompt provides a systematic approach to identifying root causes
    by working backwards from symptoms to the originating failure.
    
    Args:
        trace_id: Specific trace ID to investigate (optional)
        error_pattern: Known error pattern to analyze (optional)
        time_window: Time window to investigate (default: "1h")
    
    Returns:
        Guided workflow for root cause analysis
    """
    return create_root_cause_analysis_prompt(
        trace_id=trace_id,
        error_pattern=error_pattern,
        time_window=time_window
    )


@mcp.prompt()
def health_check_report(
    time_period: str = "24h",
    include_metrics: bool = True
) -> list[PromptMessage]:
    """Generate comprehensive health status report.
    
    This prompt guides the generation of a complete health report covering
    all observability platforms, services, and error statistics.
    
    Args:
        time_period: Time period for error statistics (default: "24h")
        include_metrics: Whether to include detailed metrics (default: True)
    
    Returns:
        Guided workflow for health check report generation
    """
    return create_health_check_report_prompt(
        time_period=time_period,
        include_metrics=include_metrics
    )


@mcp.prompt()
def post_deployment_check(
    service_name: str,
    deployment_time: Optional[str] = None,
    lookback_minutes: int = 30
) -> list[PromptMessage]:
    """Validate deployment health by comparing before/after metrics.
    
    This prompt guides post-deployment validation by analyzing error rates,
    identifying new issues, and providing a deployment health recommendation.
    
    Args:
        service_name: Name of the deployed service (required)
        deployment_time: ISO timestamp or relative time of deployment (optional)
        lookback_minutes: Minutes before deployment to use as baseline (default: 30)
    
    Returns:
        Guided workflow for deployment validation
    """
    return create_post_deployment_check_prompt(
        service_name=service_name,
        deployment_time=deployment_time,
        lookback_minutes=lookback_minutes
    )


@mcp.prompt()
def trace_flow_analysis(
    trace_id: str,
    include_timing: bool = True
) -> list[PromptMessage]:
    """Analyze distributed trace execution flow and timing.
    
    This prompt guides detailed analysis of how a request flowed through
    distributed services, including timing analysis, failure points, and dependencies.
    
    Args:
        trace_id: The distributed trace ID to analyze (required)
        include_timing: Whether to include detailed timing analysis (default: True)
    
    Returns:
        Guided workflow for trace flow analysis
    """
    return create_trace_flow_analysis_prompt(
        trace_id=trace_id,
        include_timing=include_timing
    )


def _get_config_path() -> Optional[str]:
    """Extract config path from command line arguments.
    
    Returns:
        Config file path from argv, or None to use default
    """
    import sys
    return sys.argv[1] if len(sys.argv) > 1 else None


def main():
    """Entry point for the MCP observability server.
    
    This is the main entry point that:
    1. Sets up logging
    2. Loads configuration
    3. Initializes providers
    4. Runs the FastMCP server (which manages its own event loop)
    
    Note: FastMCP's run() method handles the asyncio event loop internally,
    so we don't need to wrap it in asyncio.run().
    """
    # Setup logging first
    setup_logging()
    logger.info("Starting MCP Observability Server")
    
    try:
        # Get config path and initialize providers
        config_path = _get_config_path()
        _initialize_providers(config_path)
        
        logger.info("Server ready, starting FastMCP")
        # Run the FastMCP server - it handles the event loop internally
        mcp.run()
    except KeyboardInterrupt:
        logger.info("Server stopped by user (KeyboardInterrupt)")
    except Exception as e:
        logger.critical(f"Fatal error: {e}", exc_info=True)
        raise


if __name__ == "__main__":
    main()
