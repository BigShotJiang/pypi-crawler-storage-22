"""Tool definitions for the MCP observability server."""

from mcp.types import Tool

# Export parameter descriptions (reused across multiple tools)
_EXPORT_DESC = "Export results to a JSON file instead of returning formatted text"
_OUTPUT_DIR_DESC = "Output directory for export (default: 'exports')"
_FILENAME_DESC = "Output filename for export (default: auto-generated)"


def get_tool_definitions() -> list[Tool]:
    """Get all tool definitions for the MCP server.
    
    Returns:
        List of Tool objects with their schemas
    """
    return [
        Tool(
            name="query_logs",
            description="Query logs from all configured observability platforms. Search across New Relic, Azure Application Insights.",
            inputSchema={
                "type": "object",
                "properties": {
                    "start_time": {
                        "type": "string",
                        "description": "Start time in ISO format (e.g., '2024-01-01T00:00:00Z') or relative like '1h' for 1 hour ago",
                    },
                    "end_time": {
                        "type": "string",
                        "description": "End time in ISO format. Defaults to now if not specified.",
                    },
                    "query": {
                        "type": "string",
                        "description": "Search text to find in log messages",
                    },
                    "severity": {
                        "type": "array",
                        "items": {
                            "type": "string",
                            "enum": ["debug", "info", "warning", "error", "critical"],
                        },
                        "description": "Filter by severity levels",
                    },
                    "service_name": {
                        "type": "string",
                        "description": "Filter by service or application name",
                    },
                    "limit": {
                        "type": "integer",
                        "description": "Maximum number of results (default: 100)",
                        "default": 100,
                    },
                    "providers": {
                        "type": "array",
                        "items": {
                            "type": "string",
                            "enum": ["newrelic", "azure"],
                        },
                        "description": "Specific providers to query. If not specified, queries all enabled providers.",
                    },
                    "export": {
                        "type": "boolean",
                        "description": _EXPORT_DESC,
                        "default": False,
                    },
                    "output_dir": {
                        "type": "string",
                        "description": _OUTPUT_DIR_DESC,
                        "default": "exports",
                    },
                    "filename": {
                        "type": "string",
                        "description": _FILENAME_DESC,
                    },
                },
                "required": ["start_time"],
            },
        ),
        Tool(
            name="get_recent_errors",
            description="Get recent error and critical logs from all platforms. Useful for quick incident investigation.",
            inputSchema={
                "type": "object",
                "properties": {
                    "minutes": {
                        "type": "integer",
                        "description": "Look back this many minutes (default: 60)",
                        "default": 60,
                    },
                    "limit": {
                        "type": "integer",
                        "description": "Maximum number of results per provider (default: 100)",
                        "default": 100,
                    },
                    "service_name": {
                        "type": "string",
                        "description": "Filter by service name",
                    },
                    "export": {
                        "type": "boolean",
                        "description": _EXPORT_DESC,
                        "default": False,
                    },
                    "output_dir": {
                        "type": "string",
                        "description": _OUTPUT_DIR_DESC,
                        "default": "exports",
                    },
                    "filename": {
                        "type": "string",
                        "description": _FILENAME_DESC,
                    },
                },
            },
        ),
        Tool(
            name="search_by_trace_id",
            description="Search for all logs related to a distributed trace ID across all platforms. Useful for debugging distributed systems.",
            inputSchema={
                "type": "object",
                "properties": {
                    "trace_id": {
                        "type": "string",
                        "description": "The trace ID to search for",
                    },
                    "start_time": {
                        "type": "string",
                        "description": "Optional start time. Defaults to 24 hours ago.",
                    },
                    "end_time": {
                        "type": "string",
                        "description": "Optional end time. Defaults to now.",
                    },
                    "export": {
                        "type": "boolean",
                        "description": _EXPORT_DESC,
                        "default": False,
                    },
                    "output_dir": {
                        "type": "string",
                        "description": _OUTPUT_DIR_DESC,
                        "default": "exports",
                    },
                    "filename": {
                        "type": "string",
                        "description": _FILENAME_DESC,
                    },
                },
                "required": ["trace_id"],
            },
        ),
        Tool(
            name="health_check",
            description="Check the health and connectivity of all configured log providers.",
            inputSchema={
                "type": "object",
                "properties": {},
            },
        ),
        Tool(
            name="export_logs",
            description="Export logs to a JSON file. Query logs from observability platforms and save results to disk.",
            inputSchema={
                "type": "object",
                "properties": {
                    "start_time": {
                        "type": "string",
                        "description": "Start time in ISO format or relative like '1h' for 1 hour ago",
                    },
                    "end_time": {
                        "type": "string",
                        "description": "End time in ISO format. Defaults to now if not specified.",
                    },
                    "query": {
                        "type": "string",
                        "description": "Search text to find in log messages",
                    },
                    "severity": {
                        "type": "array",
                        "items": {
                            "type": "string",
                            "enum": ["debug", "info", "warning", "error", "critical"],
                        },
                        "description": "Filter by severity levels",
                    },
                    "service_name": {
                        "type": "string",
                        "description": "Filter by service or application name",
                    },
                    "limit": {
                        "type": "integer",
                        "description": "Maximum number of results (default: 100)",
                        "default": 100,
                    },
                    "providers": {
                        "type": "array",
                        "items": {
                            "type": "string",
                            "enum": ["newrelic", "azure"],
                        },
                        "description": "Specific providers to query. If not specified, queries all enabled providers.",
                    },
                    "output_dir": {
                        "type": "string",
                        "description": "Output directory path (default: 'exports')",
                        "default": "exports",
                    },
                    "filename": {
                        "type": "string",
                        "description": "Output filename (default: auto-generated based on timestamp)",
                    },
                },
                "required": ["start_time"],
            },
        ),
    ]
