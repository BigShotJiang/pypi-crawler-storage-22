"""Tool handlers for the MCP observability server."""

import aiofiles
import json
import os
import time
from datetime import datetime, timedelta, timezone
from typing import Any
from mcp.types import TextContent

from mcp_observability.formatters import format_health_check_results, format_query_result
from mcp_observability.health import test_all_providers
from mcp_observability.logging_config import get_logger
from mcp_observability.models import LogQueryResult, LogSeverity
from mcp_observability.utils.time_utils import parse_time_string

logger = get_logger("tool_handlers")


async def _query_providers_concurrently(
    providers: dict,
    provider_names: list[str],
    start_time,
    end_time,
    query: str = None,
    severity: list = None,
    entity_name: str = None,
    limit: int = 100,
) -> tuple[list, dict, list]:
    """Query multiple providers concurrently and aggregate results.
    
    Args:
        providers: Dictionary of provider instances
        provider_names: List of provider names to query
        start_time: Start time for query
        end_time: End time for query
        query: Optional search query
        severity: Optional list of severity levels
        entity_name: Optional entity name filter
        limit: Maximum number of results per provider
        
    Returns:
        Tuple of (all_logs, provider_counts, errors)
    """
    tasks = []
    
    for provider_name in provider_names:
        if provider_name in providers:
            provider = providers[provider_name]
            task = provider.query_logs(
                start_time=start_time,
                end_time=end_time,
                query=query,
                severity=severity,
                entity_name=entity_name,
                limit=limit,
            )
            tasks.append((provider_name, task))
    
    # Wait for all queries to complete
    all_logs = []
    errors = []
    provider_counts = {}
    
    for provider_name, task in tasks:
        try:
            logs = await task
            all_logs.extend(logs)
            provider_counts[provider_name] = len(logs)
            logger.info(f"{provider_name}: Retrieved {len(logs)} log(s)")
        except Exception as e:
            logger.error(f"{provider_name}: Query failed - {str(e)}")
            errors.append(f"{provider_name}: {str(e)}")
            provider_counts[provider_name] = 0
    
    return all_logs, provider_counts, errors


async def _write_export_file(filepath: str, export_data: dict) -> None:
    """Write export data to file asynchronously.
    
    Args:
        filepath: Path to output file
        export_data: Data to export
    """
    async with aiofiles.open(filepath, "w") as f:
        await f.write(json.dumps(export_data, indent=2))


def _prepare_export_data(all_logs: list, start_time, end_time, provider_counts: dict, duration_ms: float, errors: list) -> dict:
    """Prepare export data structure.
    
    Args:
        all_logs: List of log entries
        start_time: Start time of query
        end_time: End time of query
        provider_counts: Dictionary of provider counts
        duration_ms: Query duration in milliseconds
        errors: List of errors encountered
        
    Returns:
        Dictionary containing export data
    """
    return {
        "export_metadata": {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "start_time": start_time.isoformat(),
            "end_time": end_time.isoformat(),
            "total_count": len(all_logs),
            "provider_counts": provider_counts,
            "query_duration_ms": duration_ms,
            "errors": errors,
        },
        "logs": [
            {
                "timestamp": log.timestamp.isoformat(),
                "severity": log.severity.value if log.severity else None,
                "message": log.message,
                "service_name": log.service_name,
                "source": log.source.value,
                "trace_id": log.trace_id,
                "metadata": log.metadata,
            }
            for log in all_logs
        ],
    }


class ToolHandlers:
    """Handlers for MCP tools."""
    
    def __init__(self, providers: dict):
        """Initialize tool handlers.
        
        Args:
            providers: Dictionary of provider instances
        """
        self.providers = providers
    
    def _generate_export_filepath(self, arguments: dict) -> str:
        """Generate export filepath from arguments.
        
        Args:
            arguments: Tool arguments containing optional filename
            
        Returns:
            Full filepath for the export file in the exports folder
        """
        output_dir = "exports"
        os.makedirs(output_dir, exist_ok=True)
        
        if arguments.get("filename"):
            filename = arguments["filename"]
        else:
            timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
            filename = f"logs_export_{timestamp}.json"
        
        return os.path.join(output_dir, filename)
    
    async def _export_if_requested(
        self,
        arguments: dict,
        all_logs: list,
        start_time,
        end_time,
        provider_counts: dict,
        duration_ms: float,
        errors: list,
    ) -> tuple[bool, list[TextContent] | None]:
        """Export logs to file if export flag is set.
        
        Args:
            arguments: Tool arguments
            all_logs: List of log entries
            start_time: Query start time
            end_time: Query end time
            provider_counts: Dictionary of provider counts
            duration_ms: Query duration in milliseconds
            errors: List of errors encountered
            
        Returns:
            Tuple of (was_exported, response_or_none)
        """
        if not arguments.get("export", False):
            return False, None
        
        # Generate export filepath
        filepath = self._generate_export_filepath(arguments)
        
        # Prepare and write export data
        export_data = _prepare_export_data(all_logs, start_time, end_time, provider_counts, duration_ms, errors)
        
        try:
            await _write_export_file(filepath, export_data)
            logger.info(f"Logs exported to: {filepath}")
            
            return True, self._format_export_response(len(all_logs), duration_ms, filepath, provider_counts, errors)
            
        except Exception as e:
            logger.error(f"Failed to write export file: {e}")
            return True, [TextContent(type="text", text=f"Error exporting logs: {str(e)}")]
    
    async def handle_query_logs(self, arguments: dict) -> list[TextContent]:
        """Handle query_logs tool.
        
        Args:
            arguments: Tool arguments containing query parameters
            
        Returns:
            List of TextContent with formatted results
        """
        logger.info("Handling query_logs request")
        
        # Parse time parameters
        start_time = parse_time_string(arguments["start_time"])
        end_time = parse_time_string(arguments.get("end_time", "now"))
        logger.debug(f"Time range: {start_time} to {end_time}")
        
        # Parse severity
        severity = None
        if arguments.get("severity"):
            severity = [LogSeverity(s) for s in arguments["severity"]]
            logger.debug(f"Filtering by severity: {severity}")
        
        # Determine which providers to query
        provider_names = arguments.get("providers")
        if not provider_names:
            provider_names = [name for name, p in self.providers.items() if p.enabled]
        logger.info(f"Querying {len(provider_names)} provider(s): {provider_names}")
        
        # Query all providers concurrently
        start = time.time()
        all_logs, provider_counts, errors = await _query_providers_concurrently(
            self.providers,
            provider_names,
            start_time,
            end_time,
            arguments.get("query"),
            severity,
            arguments.get("service_name"),
            arguments.get("limit", 100),
        )
        
        # Sort logs by timestamp
        all_logs.sort(key=lambda x: x.timestamp, reverse=True)
        logger.info(f"Total logs retrieved: {len(all_logs)}")
        
        # Create result
        duration_ms = (time.time() - start) * 1000
        
        # Check if export is requested
        exported, export_response = await self._export_if_requested(
            arguments, all_logs, start_time, end_time, provider_counts, duration_ms, errors
        )
        if exported:
            return export_response
        
        result = LogQueryResult(
            logs=all_logs,
            total_count=len(all_logs),
            provider_counts=provider_counts,
            query_duration_ms=duration_ms,
            errors=errors,
        )
        
        # Format response
        response = format_query_result(result)
        
        return [TextContent(type="text", text=response)]
    
    async def handle_get_recent_errors(self, arguments: dict) -> list[TextContent]:
        """Handle get_recent_errors tool.
        
        Args:
            arguments: Tool arguments containing query parameters
            
        Returns:
            List of TextContent with formatted results
        """
        logger.info("Handling get_recent_errors request")
        
        minutes = arguments.get("minutes", 60)
        limit = arguments.get("limit", 100)
        entity_name = arguments.get("entity_name")
        logger.debug(f"Looking for errors from last {minutes} minutes, limit={limit}, entity={entity_name}")
        
        # Query all providers
        start = time.time()
        tasks = []
        
        for provider_name, provider in self.providers.items():
            if provider.enabled:
                task = provider.get_recent_errors(minutes=minutes, limit=limit)
                tasks.append((provider_name, task))
        
        # If service_name is provided, filter results
        all_logs = []
        errors = []
        provider_counts = {}
        
        for provider_name, task in tasks:
            try:
                logs = await task
                # Filter by entity name if provided
                if entity_name:
                    logs = [log for log in logs if log.metadata.get("entity_name") == entity_name]
                all_logs.extend(logs)
                provider_counts[provider_name] = len(logs)
            except Exception as e:
                errors.append(f"{provider_name}: {str(e)}")
                provider_counts[provider_name] = 0
        
        # Sort logs by timestamp
        all_logs.sort(key=lambda x: x.timestamp, reverse=True)
        
        duration_ms = (time.time() - start) * 1000
        
        # Determine time range for export metadata
        end_time = datetime.now(timezone.utc)
        start_time = end_time - timedelta(minutes=minutes)
        
        # Check if export is requested
        exported, export_response = await self._export_if_requested(
            arguments, all_logs, start_time, end_time, provider_counts, duration_ms, errors
        )
        if exported:
            return export_response
        
        result = LogQueryResult(
            logs=all_logs,
            total_count=len(all_logs),
            provider_counts=provider_counts,
            query_duration_ms=duration_ms,
            errors=errors,
        )
        
        response = format_query_result(result)
        return [TextContent(type="text", text=response)]
    
    async def handle_search_by_trace_id(self, arguments: dict) -> list[TextContent]:
        """Handle search_by_trace_id tool.
        
        Args:
            arguments: Tool arguments containing trace_id and time range
            
        Returns:
            List of TextContent with formatted results
        """
        logger.info("Handling search_by_trace_id request")
        
        trace_id = arguments["trace_id"]
        start_time = parse_time_string(arguments.get("start_time", "24h"))
        end_time = parse_time_string(arguments.get("end_time", "now"))
        entity_name = arguments.get("entity_name")
        logger.info(f"Searching for trace_id: {trace_id}, entity_name: {entity_name}")
        logger.debug(f"Time range: {start_time} to {end_time}")
        
        # Query all providers
        start = time.time()
        tasks = []
        
        for provider_name, provider in self.providers.items():
            if provider.enabled:
                task = provider.search_by_trace_id(
                    trace_id=trace_id,
                    start_time=start_time,
                    end_time=end_time,
                    entity_name=entity_name,
                )
                tasks.append((provider_name, task))
        
        all_logs = []
        errors = []
        provider_counts = {}
        
        for provider_name, task in tasks:
            try:
                logs = await task
                all_logs.extend(logs)
                provider_counts[provider_name] = len(logs)
            except Exception as e:
                errors.append(f"{provider_name}: {str(e)}")
                provider_counts[provider_name] = 0
        
        # Sort logs by timestamp
        all_logs.sort(key=lambda x: x.timestamp)
        
        duration_ms = (time.time() - start) * 1000
        
        # Check if export is requested
        exported, export_response = await self._export_if_requested(
            arguments, all_logs, start_time, end_time, provider_counts, duration_ms, errors
        )
        if exported:
            return export_response
        
        result = LogQueryResult(
            logs=all_logs,
            total_count=len(all_logs),
            provider_counts=provider_counts,
            query_duration_ms=duration_ms,
            errors=errors,
        )
        
        response = format_query_result(result, trace_view=True)
        return [TextContent(type="text", text=response)]
    
    async def handle_health_check(self, _arguments: dict) -> list[TextContent]:
        """Handle health_check tool.
        
        Args:
            _arguments: Unused arguments
            
        Returns:
            List of TextContent with health check results
        """
        logger.info("Performing health check on all providers")
        
        results = await test_all_providers(self.providers)
        logger.debug(f"Health check results: {results}")
        
        response = format_health_check_results(results)
        return [TextContent(type="text", text=response)]
    
    async def handle_export_logs(self, arguments: dict) -> list[TextContent]:
        """Handle export_logs tool.
        
        Args:
            arguments: Tool arguments containing query parameters and export options
            
        Returns:
            List of TextContent with export results
        """
        logger.info("Handling export_logs request")
        
        # Parse time parameters
        start_time = parse_time_string(arguments["start_time"])
        end_time = parse_time_string(arguments.get("end_time", "now"))
        logger.debug(f"Time range: {start_time} to {end_time}")
        
        # Parse severity
        severity = None
        if arguments.get("severity"):
            severity = [LogSeverity(s) for s in arguments["severity"]]
            logger.debug(f"Filtering by severity: {severity}")
        
        # Determine which providers to query
        provider_names = arguments.get("providers")
        if not provider_names:
            provider_names = [name for name, p in self.providers.items() if p.enabled]
        logger.info(f"Querying {len(provider_names)} provider(s): {provider_names}")
        
        # Query all providers concurrently
        start = time.time()
        all_logs, provider_counts, errors = await _query_providers_concurrently(
            self.providers,
            provider_names,
            start_time,
            end_time,
            arguments.get("query"),
            severity,
            arguments.get("entity_name"),
            arguments.get("limit", 100),
        )
        
        # Sort logs by timestamp
        all_logs.sort(key=lambda x: x.timestamp, reverse=True)
        logger.info(f"Total logs retrieved: {len(all_logs)}")
        
        duration_ms = (time.time() - start) * 1000
        
        # Generate export filepath
        filepath = self._generate_export_filepath(arguments)
        
        # Prepare and write export data
        export_data = _prepare_export_data(all_logs, start_time, end_time, provider_counts, duration_ms, errors)
        
        try:
            await _write_export_file(filepath, export_data)
            logger.info(f"Logs exported to: {filepath}")
            
            return self._format_export_response(len(all_logs), duration_ms, filepath, provider_counts, errors)
            
        except Exception as e:
            logger.error(f"Failed to write export file: {e}")
            return [TextContent(type="text", text=f"Error exporting logs: {str(e)}")]
    
    def _format_export_response(
        self, 
        total_logs: int, 
        duration_ms: float, 
        filepath: str, 
        provider_counts: dict, 
        errors: list
    ) -> list[TextContent]:
        """Format the export response message.
        
        Args:
            total_logs: Total number of exported logs
            duration_ms: Query duration in milliseconds
            filepath: Path to exported file
            provider_counts: Dictionary of provider counts
            errors: List of errors encountered
            
        Returns:
            List of TextContent with formatted response
        """
        response = f"""Successfully exported {total_logs} log(s) to {filepath}

Export Summary:
- Total logs: {total_logs}
- Query duration: {duration_ms:.2f}ms
- Output file: {filepath}

Provider breakdown:
"""
        for provider, count in provider_counts.items():
            response += f"  - {provider}: {count} log(s)\n"
        
        if errors:
            response += "\nErrors encountered:\n"
            for error in errors:
                response += f"  - {error}\n"
        
        return [TextContent(type="text", text=response)]
