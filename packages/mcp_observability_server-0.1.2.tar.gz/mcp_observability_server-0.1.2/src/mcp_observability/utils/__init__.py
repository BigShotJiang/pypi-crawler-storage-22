"""Utility functions for the MCP observability server.

DEPRECATED: Most functions have been moved to specific modules:
- config.py: Configuration loading
- formatters.py: Log formatting
- health.py: Health check utilities
- utils/time_utils.py: Time parsing

This module is kept for backward compatibility.
"""

# Re-export from new modules for backward compatibility
from ..config import create_provider_configs, load_config_file  # noqa: F401
from ..formatters import (  # noqa: F401
    format_log_entry,
    format_logs_as_table,
    format_query_result,
)
from ..health import test_all_providers  # noqa: F401
from .time_utils import parse_time_string  # noqa: F401

__all__ = [
    "load_config_file",
    "create_provider_configs",
    "format_log_entry",
    "format_logs_as_table",
    "format_query_result",
    "test_all_providers",
    "parse_time_string",
]
