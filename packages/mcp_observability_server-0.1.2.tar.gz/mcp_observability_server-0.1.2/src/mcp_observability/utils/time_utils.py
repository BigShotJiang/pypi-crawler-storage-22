"""Time parsing and manipulation utilities."""

from datetime import datetime, timedelta, timezone

from ..exceptions import TimeParseError
from ..logging_config import get_logger

logger = get_logger("time_utils")


def parse_time_string(time_str: str) -> datetime:
    """Parse time string to datetime.

    Supports:
    - ISO format: '2024-01-01T00:00:00Z'
    - Relative: '1h', '30m', '2d' (hours, minutes, days)
    - 'now'

    Args:
        time_str: Time string to parse

    Returns:
        Parsed datetime object (timezone-aware UTC)

    Raises:
        TimeParseError: If the time string cannot be parsed
    """
    # Handle None or empty string
    if not time_str:
        logger.error("Time string is None or empty, defaulting to 'now'")
        return datetime.now(timezone.utc)
    
    if time_str == "now":
        return datetime.now(timezone.utc)

    # Try relative time
    if time_str[-1] in ("h", "m", "d"):
        try:
            unit = time_str[-1]
            value = int(time_str[:-1])

            now = datetime.now(timezone.utc)

            if unit == "h":
                return now - timedelta(hours=value)
            elif unit == "m":
                return now - timedelta(minutes=value)
            elif unit == "d":
                return now - timedelta(days=value)
        except (ValueError, IndexError) as e:
            logger.error(f"Failed to parse relative time '{time_str}': {e}")
            raise TimeParseError(f"Invalid relative time format: {time_str}") from e

    # Try ISO format
    try:
        return datetime.fromisoformat(time_str.replace("Z", "+00:00"))
    except ValueError as e:
        logger.error(f"Failed to parse ISO time '{time_str}': {e}")
        # Default to now instead of raising
        logger.warning(f"Defaulting to current time for invalid time string: {time_str}")
        raise TimeParseError(f"Invalid relative time format: {time_str}") from e


def format_duration(duration_ms: float) -> str:
    """Format duration in milliseconds to human-readable string.

    Args:
        duration_ms: Duration in milliseconds

    Returns:
        Formatted duration string
    """
    if duration_ms < 1000:
        return f"{duration_ms:.2f}ms"
    elif duration_ms < 60000:
        return f"{duration_ms / 1000:.2f}s"
    else:
        return f"{duration_ms / 60000:.2f}m"
