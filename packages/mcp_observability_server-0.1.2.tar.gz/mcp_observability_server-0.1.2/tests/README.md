# Tests

This directory contains the test suite for the MCP Observability Server.

## Running Tests

### Install Development Dependencies

```bash
pip install -e ".[dev]"
```

### Run All Tests

```bash
pytest
```

### Run with Coverage

```bash
pytest --cov=src/mcp_observability --cov-report=html --cov-report=term
```

### Run Specific Test File

```bash
pytest tests/test_config.py
```

### Run Specific Test

```bash
pytest tests/test_config.py::TestLoadConfigFile::test_load_valid_config
```

### Run with Verbose Output

```bash
pytest -v
```

## Test Structure

- `conftest.py` - Shared fixtures and pytest configuration
- `test_config.py` - Tests for configuration loading
- `test_exceptions.py` - Tests for custom exceptions
- `test_formatters.py` - Tests for log formatting utilities
- `test_time_utils.py` - Tests for time parsing utilities

## Writing New Tests

When adding new tests:

1. Create test files with the naming pattern `test_*.py`
2. Use descriptive class names like `TestFunctionName`
3. Use descriptive test method names like `test_specific_behavior`
4. Add docstrings to test classes and methods
5. Use fixtures from `conftest.py` where applicable
6. Follow the Arrange-Act-Assert pattern

## Test Coverage

Current test modules cover:
- ✅ Configuration loading and validation
- ✅ Custom exceptions
- ✅ Log formatting
- ✅ Time parsing and manipulation
- ⏳ Health checks (coming soon)
- ⏳ Provider implementations (coming soon)
- ⏳ Server handlers (coming soon)
