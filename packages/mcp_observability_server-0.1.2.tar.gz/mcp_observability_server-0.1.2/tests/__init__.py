"""Tests for MCP Observability Server."""
