"""Pytest configuration and fixtures for tests."""

import pytest
from datetime import datetime, timezone

from mcp_observability.models import LogEntry, LogProvider, LogSeverity


@pytest.fixture
def sample_log_entry():
    """Provide a sample log entry for testing."""
    return LogEntry(
        timestamp=datetime(2024, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
        severity=LogSeverity.INFO,
        message="Test log message",
        source=LogProvider.NEW_RELIC,
        service_name="test-service",
        trace_id="test-trace-123",
    )


@pytest.fixture
def sample_error_log():
    """Provide a sample error log for testing."""
    return LogEntry(
        timestamp=datetime(2024, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
        severity=LogSeverity.ERROR,
        message="Error occurred in application",
        source=LogProvider.NEW_RELIC,
        service_name="api-service",
        host="server-01",
    )


@pytest.fixture
def sample_config():
    """Provide a sample configuration for testing."""
    return {
        "providers": {
            "newrelic": {
                "enabled": True,
                "api_key": "test_api_key",
                "account_id": "123456",
                "region": "US",
            }
        }
    }
