"""Tests for configuration module."""

import pytest
from pathlib import Path
import tempfile
import yaml

from mcp_observability.config import (
    load_config_file,
    create_provider_configs,
)
from mcp_observability.exceptions import ConfigurationError


class TestLoadConfigFile:
    """Tests for load_config_file function."""

    def test_load_valid_config(self):
        """Test loading a valid configuration file."""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
            yaml.dump({"providers": {"newrelic": {"enabled": True}}}, f)
            config_path = f.name

        try:
            config = load_config_file(config_path)
            assert "providers" in config
            assert "newrelic" in config["providers"]
        finally:
            Path(config_path).unlink()

    def test_load_missing_config(self):
        """Test loading non-existent config file."""
        config = load_config_file("/tmp/nonexistent_config.yaml")
        assert config == {}

    def test_env_var_substitution(self):
        """Test environment variable substitution."""
        import os

        os.environ["TEST_API_KEY"] = "secret123"

        with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
            yaml.dump({"api_key": "${TEST_API_KEY}"}, f)
            config_path = f.name

        try:
            config = load_config_file(config_path)
            assert config["api_key"] == "secret123"
        finally:
            Path(config_path).unlink()
            del os.environ["TEST_API_KEY"]


class TestCreateProviderConfigs:
    """Tests for create_provider_configs function."""

    def test_create_newrelic_config(self):
        """Test creating New Relic provider config."""
        config = {
            "providers": {
                "newrelic": {
                    "enabled": True,
                    "api_key": "test_key",
                    "account_id": "12345",
                    "region": "US",
                }
            }
        }
        providers = create_provider_configs(config)
        assert "newrelic" in providers
        assert providers["newrelic"].api_key == "test_key"
        assert providers["newrelic"].account_id == "12345"

    def test_create_multiple_provider_configs(self):
        """Test creating configs for multiple providers."""
        config = {
            "providers": {
                "newrelic": {
                    "enabled": True,
                    "api_key": "nr_key",
                    "account_id": "123",
                },
                "azure": {
                    "enabled": True,
                    "workspace_id": "ws_id",
                    "client_id": "client",
                    "client_secret": "secret",
                    "tenant_id": "tenant",
                },
            }
        }
        providers = create_provider_configs(config)
        assert len(providers) == 2
        assert "newrelic" in providers
        assert "azure" in providers

    def test_invalid_config_raises_error(self):
        """Test that invalid config raises ConfigurationError."""
        config = {
            "providers": {
                "newrelic": {
                    "enabled": True,
                    # Missing required fields
                }
            }
        }
        with pytest.raises(ConfigurationError):
            create_provider_configs(config)
