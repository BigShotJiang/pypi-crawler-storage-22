"""Tests for custom exceptions."""

import pytest
from mcp_observability.exceptions import (
    MCPObservabilityError,
    ConfigurationError,
    ProviderError,
    ProviderConnectionError,
    ProviderAuthenticationError,
    ProviderQueryError,
    TimeParseError,
    ValidationError,
)


class TestExceptions:
    """Tests for custom exception hierarchy."""

    def test_base_exception(self):
        """Test base exception."""
        with pytest.raises(MCPObservabilityError):
            raise MCPObservabilityError("test error")

    def test_configuration_error(self):
        """Test configuration error."""
        with pytest.raises(ConfigurationError):
            raise ConfigurationError("config error")

        # Should also be caught as base exception
        with pytest.raises(MCPObservabilityError):
            raise ConfigurationError("config error")

    def test_provider_error(self):
        """Test provider error."""
        error = ProviderError("newrelic", "connection failed")
        assert error.provider_name == "newrelic"
        assert "newrelic" in str(error)
        assert "connection failed" in str(error)

    def test_provider_connection_error(self):
        """Test provider connection error."""
        with pytest.raises(ProviderConnectionError):
            raise ProviderConnectionError("azure", "timeout")

    def test_time_parse_error(self):
        """Test time parse error."""
        with pytest.raises(TimeParseError):
            raise TimeParseError("invalid time format")

    def test_validation_error(self):
        """Test validation error."""
        with pytest.raises(ValidationError):
            raise ValidationError("invalid input")
