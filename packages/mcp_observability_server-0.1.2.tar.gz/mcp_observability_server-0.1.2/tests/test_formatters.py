"""Tests for formatters module."""

import pytest
from datetime import datetime, timezone

from mcp_observability.formatters import (
    format_log_entry,
    format_logs_as_table,
    format_query_result,
    format_health_check_results,
)
from mcp_observability.models import (
    LogEntry,
    LogProvider,
    LogSeverity,
    LogQueryResult,
)


class TestFormatLogEntry:
    """Tests for format_log_entry function."""

    def test_format_basic_log(self):
        """Test formatting a basic log entry."""
        log = LogEntry(
            timestamp=datetime(2024, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
            severity=LogSeverity.INFO,
            message="Test message",
            source=LogProvider.NEW_RELIC,
        )
        result = format_log_entry(log)
        assert "INFO" in result
        assert "Test message" in result
        assert "newrelic" in result

    def test_format_log_with_trace(self):
        """Test formatting log with trace ID."""
        log = LogEntry(
            timestamp=datetime(2024, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
            severity=LogSeverity.ERROR,
            message="Error occurred",
            source=LogProvider.NEW_RELIC,
            trace_id="abc123",
            service_name="test-service",
        )
        result = format_log_entry(log)
        assert "abc123" in result
        assert "test-service" in result


class TestFormatLogsAsTable:
    """Tests for format_logs_as_table function."""

    def test_format_empty_logs(self):
        """Test formatting empty log list."""
        result = format_logs_as_table([])
        assert "No logs found" in result

    def test_format_single_log(self):
        """Test formatting single log entry."""
        logs = [
            LogEntry(
                timestamp=datetime(2024, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
                severity=LogSeverity.INFO,
                message="Test",
                source=LogProvider.NEW_RELIC,
            )
        ]
        result = format_logs_as_table(logs)
        assert "Timestamp" in result
        assert "Severity" in result
        assert "Test" in result

    def test_format_truncates_long_messages(self):
        """Test that long messages are truncated."""
        logs = [
            LogEntry(
                timestamp=datetime(2024, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
                severity=LogSeverity.INFO,
                message="A" * 100,  # Long message
                source=LogProvider.NEW_RELIC,
            )
        ]
        result = format_logs_as_table(logs)
        assert "..." in result  # Should be truncated


class TestFormatQueryResult:
    """Tests for format_query_result function."""

    def test_format_result_with_logs(self):
        """Test formatting query result with logs."""
        logs = [
            LogEntry(
                timestamp=datetime(2024, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
                severity=LogSeverity.INFO,
                message="Test",
                source=LogProvider.NEW_RELIC,
            )
        ]
        result_obj = LogQueryResult(
            logs=logs,
            total_count=1,
            provider_counts={"newrelic": 1},
            query_duration_ms=150.5,
        )
        result = format_query_result(result_obj)
        assert "1 logs found" in result
        assert "150.50ms" in result
        assert "newrelic: 1" in result

    def test_format_result_with_errors(self):
        """Test formatting query result with errors."""
        result_obj = LogQueryResult(
            logs=[],
            total_count=0,
            provider_counts={},
            query_duration_ms=100.0,
            errors=["Provider A failed", "Provider B timeout"],
        )
        result = format_query_result(result_obj)
        assert "Errors:" in result
        assert "Provider A failed" in result
        assert "Provider B timeout" in result


class TestFormatHealthCheckResults:
    """Tests for format_health_check_results function."""

    def test_format_healthy_providers(self):
        """Test formatting results for healthy providers."""
        results = {
            "newrelic": {"healthy": True, "enabled": True},
            "azure": {"healthy": True, "enabled": True},
        }
        result = format_health_check_results(results)
        assert "✓ Healthy" in result
        assert "newrelic" in result
        assert "azure" in result

    def test_format_unhealthy_provider(self):
        """Test formatting results with unhealthy provider."""
        results = {
            "newrelic": {"healthy": False, "enabled": True, "error": "Connection failed"}
        }
        result = format_health_check_results(results)
        assert "✗ Unhealthy" in result
        assert "Connection failed" in result
