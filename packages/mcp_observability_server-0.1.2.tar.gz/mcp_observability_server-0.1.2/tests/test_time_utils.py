"""Tests for time utilities."""
from datetime import datetime, timezone, timedelta

from mcp_observability.utils.time_utils import parse_time_string, format_duration
from mcp_observability.exceptions import TimeParseError


class TestParseTimeString:
    """Tests for parse_time_string function."""

    def test_parse_now(self):
        """Test parsing 'now' returns current time."""
        result = parse_time_string("now")
        assert isinstance(result, datetime)
        assert result.tzinfo == timezone.utc
        # Check it's within last second
        now = datetime.now(timezone.utc)
        assert abs((now - result).total_seconds()) < 1

    def test_parse_relative_hours(self):
        """Test parsing relative time in hours."""
        result = parse_time_string("2h")
        expected = datetime.now(timezone.utc) - timedelta(hours=2)
        assert abs((expected - result).total_seconds()) < 1

    def test_parse_relative_minutes(self):
        """Test parsing relative time in minutes."""
        result = parse_time_string("30m")
        expected = datetime.now(timezone.utc) - timedelta(minutes=30)
        assert abs((expected - result).total_seconds()) < 1

    def test_parse_relative_days(self):
        """Test parsing relative time in days."""
        result = parse_time_string("7d")
        expected = datetime.now(timezone.utc) - timedelta(days=7)
        assert abs((expected - result).total_seconds()) < 1

    def test_parse_iso_format(self):
        """Test parsing ISO format timestamps."""
        iso_str = "2024-01-01T00:00:00Z"
        result = parse_time_string(iso_str)
        assert result.year == 2024
        assert result.month == 1
        assert result.day == 1

    def test_parse_iso_with_timezone(self):
        """Test parsing ISO format with explicit timezone."""
        iso_str = "2024-01-01T00:00:00+00:00"
        result = parse_time_string(iso_str)
        assert result.year == 2024
        assert result.tzinfo is not None

    def test_invalid_format_defaults_to_now(self):
        """Test that invalid formats default to current time."""
        result = parse_time_string("invalid")
        now = datetime.now(timezone.utc)
        assert abs((now - result).total_seconds()) < 1


class TestFormatDuration:
    """Tests for format_duration function."""

    def test_format_milliseconds(self):
        """Test formatting duration less than 1 second."""
        assert "ms" in format_duration(500)
        assert "500" in format_duration(500)

    def test_format_seconds(self):
        """Test formatting duration in seconds."""
        assert "s" in format_duration(5000)
        assert "5.00s" == format_duration(5000)

    def test_format_minutes(self):
        """Test formatting duration in minutes."""
        assert "m" in format_duration(120000)
        assert "2.00m" == format_duration(120000)
