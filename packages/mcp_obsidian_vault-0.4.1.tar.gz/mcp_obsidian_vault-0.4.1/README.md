# Obsidian MCP

**Give Claude Desktop access to your Obsidian vault. No plugins required.**

Install the extension, and Claude can read your notes, search them, and create new ones.

## Installation

### Option 1: mcpb bundle (recommended)
Download `obsidian-mcp.mcpb` from [releases](https://github.com/ldraney/obsidian-mcp/releases) and open it with Claude Desktop.

### Option 2: uvx
```bash
uvx mcp-obsidian-vault
```

### Option 3: Manual config
Add to `~/Library/Application Support/Claude/claude_desktop_config.json`:
```json
{
  "mcpServers": {
    "obsidian": {
      "command": "uvx",
      "args": ["mcp-obsidian-vault"]
    }
  }
}
```

## Tools

| Tool | Description |
|------|-------------|
| `list_vaults` | List all Obsidian vaults on your machine |
| `list_notes` | List all notes in a vault |
| `read_note` | Read note contents with parsed YAML frontmatter |
| `write_note` | Create or update a note |
| `search_notes` | Full-text search across notes |
| `open_in_obsidian` | Open a note directly in Obsidian app |

## How It Works

No plugins required — we use Obsidian's native interfaces:

| What | How |
|------|-----|
| Find vaults | Read `obsidian.json` (Obsidian stores vault paths here) |
| Read/write notes | Direct filesystem access (your vault is just markdown files) |
| Frontmatter | YAML parsing with structured JSON output |
| Search | Full-text search |
| Open in app | Native `obsidian://` URI scheme |

## Status

| Feature | Status |
|---------|--------|
| Vault discovery | ✅ |
| Read/write notes | ✅ |
| Search | ✅ |
| Frontmatter parsing | ✅ |
| Open in Obsidian | ✅ |
| PyPI release | ✅ |
| mcpb bundle | ✅ |

## Security

This MCP is designed with minimal access:

- **No network calls** — Nothing leaves your machine
- **No files outside vaults** — Only accesses your Obsidian notes
- **No credentials** — Never touches passwords or tokens
- **Open source** — Audit the code yourself

See [SECURITY.md](SECURITY.md) for full details, or visit the [Security page](https://ldraney.github.io/obsidian-mcp/security.html) on our website.

## Documentation

| Document | What's Inside |
|----------|---------------|
| [CLAUDE.md](CLAUDE.md) | Development approach, current status |
| [SECURITY.md](SECURITY.md) | Security model and what we access |
| [docs/](docs/) | Architecture diagrams, roadmap |

## Contributing

Check the [issues](https://github.com/ldraney/obsidian-mcp/issues) if you want to help.

## License

MIT
