"""Obsidian MCP - Claude Desktop integration for Obsidian."""

__version__ = "0.1.0"
