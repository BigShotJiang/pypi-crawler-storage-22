#!/usr/bin/env python3
"""Obsidian MCP Server - Claude Desktop integration for Obsidian vaults."""

import json
import os
import platform
import re
import subprocess
import tempfile
import urllib.parse
from collections import Counter
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional

import yaml

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent


# =============================================================================
# Data classes
# =============================================================================

@dataclass
class Vault:
    id: str
    name: str
    path: Path
    is_open: bool


@dataclass
class Note:
    name: str
    path: Path
    relative_path: str

    def read(self) -> str:
        return self.path.read_text(encoding="utf-8")


@dataclass
class SearchResult:
    note_path: str
    line_number: int
    snippet: str


# =============================================================================
# Vault Discovery
# =============================================================================

def get_obsidian_config_path() -> Path:
    """Get the obsidian.json path for the current platform."""
    system = platform.system()
    if system == "Linux":
        return Path.home() / ".config" / "obsidian" / "obsidian.json"
    elif system == "Darwin":
        return Path.home() / "Library" / "Application Support" / "obsidian" / "obsidian.json"
    elif system == "Windows":
        appdata = os.environ.get("APPDATA", "")
        return Path(appdata) / "obsidian" / "obsidian.json"
    else:
        raise OSError(f"Unsupported platform: {system}")


def discover_vaults() -> list[Vault]:
    """Discover all Obsidian vaults from obsidian.json."""
    config_path = get_obsidian_config_path()
    if not config_path.exists():
        return []

    with open(config_path) as f:
        data = json.load(f)

    vaults = []
    for vault_id, vault_data in data.get("vaults", {}).items():
        vault_path = Path(vault_data["path"])
        if vault_path.exists():
            vaults.append(Vault(
                id=vault_id,
                name=vault_path.name,
                path=vault_path,
                is_open=vault_data.get("open", False)
            ))
    return vaults


def get_vault_by_name(name: str) -> Optional[Vault]:
    """Get a vault by name (case-insensitive partial match)."""
    vaults = discover_vaults()
    name_lower = name.lower()
    for v in vaults:
        if name_lower in v.name.lower():
            return v
    return None


# =============================================================================
# URI Handler
# =============================================================================

def open_obsidian_uri(vault: str, file: str = "") -> None:
    """Open Obsidian via obsidian:// URI scheme.

    Args:
        vault: The vault name
        file: Optional file path within the vault (without .md extension)
    """
    params = {"vault": vault}
    if file:
        # Strip .md extension if present for cleaner URIs
        if file.endswith('.md'):
            file = file[:-3]
        params["file"] = file

    query = urllib.parse.urlencode(params)
    uri = f"obsidian://open?{query}"

    system = platform.system()
    if system == "Darwin":
        subprocess.run(["open", uri], check=True)
    elif system == "Linux":
        subprocess.run(["xdg-open", uri], check=True)
    elif system == "Windows":
        subprocess.run(["start", uri], shell=True, check=True)
    else:
        raise OSError(f"Unsupported platform: {system}")


# =============================================================================
# Notes Operations
# =============================================================================

def list_notes(vault_path: Path) -> list[Note]:
    """List all markdown notes in a vault."""
    notes = []
    for md_path in vault_path.glob("**/*.md"):
        if any(part.startswith('.') for part in md_path.relative_to(vault_path).parts):
            continue
        notes.append(Note(
            name=md_path.stem,
            path=md_path,
            relative_path=str(md_path.relative_to(vault_path))
        ))
    return sorted(notes, key=lambda n: n.relative_path)


def get_note(vault_path: Path, note_path: str) -> Optional[Note]:
    """Get a specific note by path."""
    if not note_path.endswith('.md'):
        note_path = note_path + '.md'
    full_path = (vault_path / note_path).resolve()

    # Security: ensure path stays within vault
    try:
        full_path.relative_to(vault_path.resolve())
    except ValueError:
        return None

    if not full_path.exists():
        return None

    return Note(
        name=full_path.stem,
        path=full_path,
        relative_path=note_path
    )


def write_note(vault_path: Path, note_path: str, content: str) -> Path:
    """Write a note (atomic write)."""
    if not note_path.endswith('.md'):
        note_path = note_path + '.md'

    full_path = (vault_path / note_path).resolve()

    # Security: ensure path stays within vault
    try:
        full_path.relative_to(vault_path.resolve())
    except ValueError:
        raise ValueError(f"Path escapes vault: {note_path}")

    full_path.parent.mkdir(parents=True, exist_ok=True)

    # Atomic write
    fd, temp_path = tempfile.mkstemp(dir=full_path.parent, prefix='.tmp_', suffix='.md')
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            f.write(content)
        os.replace(temp_path, full_path)
    except Exception:
        try:
            os.unlink(temp_path)
        except OSError:
            pass
        raise

    return full_path


# =============================================================================
# Search
# =============================================================================

def search_notes(vault_path: Path, query: str, max_results: int = 20) -> list[SearchResult]:
    """Search notes for a query string."""
    results = []
    query_lower = query.lower()

    for md_path in vault_path.glob("**/*.md"):
        if any(part.startswith('.') for part in md_path.relative_to(vault_path).parts):
            continue

        try:
            content = md_path.read_text(encoding="utf-8")
        except (UnicodeDecodeError, PermissionError):
            continue

        rel_path = str(md_path.relative_to(vault_path))

        for line_num, line in enumerate(content.splitlines(), 1):
            if query_lower in line.lower():
                # Create snippet
                idx = line.lower().find(query_lower)
                start = max(0, idx - 30)
                end = min(len(line), idx + len(query) + 30)
                snippet = line[start:end]
                if start > 0:
                    snippet = "..." + snippet
                if end < len(line):
                    snippet = snippet + "..."

                results.append(SearchResult(
                    note_path=rel_path,
                    line_number=line_num,
                    snippet=snippet
                ))

                if len(results) >= max_results:
                    return results

    return results


# =============================================================================
# Frontmatter Parsing
# =============================================================================

# Regex to match frontmatter block: ---\n<content>\n---
FRONTMATTER_PATTERN = re.compile(r'^---[ \t]*\n(.*?)\n?---[ \t]*\n?', re.DOTALL)


def parse_frontmatter(content: str) -> tuple[dict[str, Any], str]:
    """Parse YAML frontmatter from markdown content.

    Args:
        content: Full markdown file content

    Returns:
        Tuple of (frontmatter dict, content without frontmatter)
    """
    match = FRONTMATTER_PATTERN.match(content)

    if not match:
        return {}, content

    yaml_str = match.group(1)
    body = content[match.end():]

    try:
        frontmatter = yaml.safe_load(yaml_str) or {}
    except yaml.YAMLError:
        # Return empty dict on parse error, preserve original content
        return {}, content

    # Ensure frontmatter is a dict
    if not isinstance(frontmatter, dict):
        return {}, content

    return frontmatter, body


def detect_value_type(value: Any) -> str:
    """Detect the type of a frontmatter value."""
    if value is None:
        return "null"
    if isinstance(value, bool):
        return "boolean"
    if isinstance(value, int):
        return "integer"
    if isinstance(value, float):
        return "number"
    if isinstance(value, list):
        return "array"
    if isinstance(value, dict):
        return "object"
    if isinstance(value, str):
        # Check for date-like strings
        if re.match(r'^\d{4}-\d{2}-\d{2}', value):
            return "date"
        return "string"
    return "unknown"


def get_schema(vault_path: Path, max_sample_values: int = 10) -> dict[str, Any]:
    """Discover frontmatter schema across all notes in a vault.

    Args:
        vault_path: Path to the vault
        max_sample_values: Maximum sample values to return per key

    Returns:
        Schema dictionary with stats and field info
    """
    total_notes = 0
    notes_with_frontmatter = 0
    schema: dict[str, dict[str, Any]] = {}

    for md_path in vault_path.glob("**/*.md"):
        # Skip hidden directories
        if any(part.startswith('.') for part in md_path.relative_to(vault_path).parts):
            continue

        total_notes += 1

        try:
            content = md_path.read_text(encoding="utf-8")
        except (UnicodeDecodeError, PermissionError):
            continue

        frontmatter, _ = parse_frontmatter(content)
        if not frontmatter:
            continue

        notes_with_frontmatter += 1

        for key, value in frontmatter.items():
            if key not in schema:
                schema[key] = {
                    "count": 0,
                    "types": Counter(),
                    "values": Counter(),
                }

            schema[key]["count"] += 1
            value_type = detect_value_type(value)
            schema[key]["types"][value_type] += 1

            # Collect sample values
            if isinstance(value, list):
                # For arrays, collect individual items
                for item in value:
                    if isinstance(item, (str, int, float, bool)):
                        schema[key]["values"][str(item)] += 1
            elif isinstance(value, (str, int, float, bool)):
                schema[key]["values"][str(value)] += 1

    # Format output
    result = {
        "total_notes": total_notes,
        "notes_with_frontmatter": notes_with_frontmatter,
        "schema": {}
    }

    for key, data in sorted(schema.items()):
        # Get most common type
        most_common_type = data["types"].most_common(1)
        primary_type = most_common_type[0][0] if most_common_type else "unknown"

        # Get top sample values
        top_values = [v for v, _ in data["values"].most_common(max_sample_values)]

        result["schema"][key] = {
            "count": data["count"],
            "type": primary_type,
            "sample_values": top_values
        }

    return result


# =============================================================================
# MCP Server
# =============================================================================

app = Server("obsidian-mcp")


@app.list_tools()
async def list_tools() -> list[Tool]:
    return [
        Tool(
            name="list_vaults",
            description="List all Obsidian vaults on this machine",
            inputSchema={"type": "object", "properties": {}, "required": []}
        ),
        Tool(
            name="list_notes",
            description="List all notes in an Obsidian vault",
            inputSchema={
                "type": "object",
                "properties": {
                    "vault": {"type": "string", "description": "Vault name (partial match OK)"}
                },
                "required": ["vault"]
            }
        ),
        Tool(
            name="read_note",
            description="Read the contents of a note. Parses YAML frontmatter if present and returns it as structured JSON.",
            inputSchema={
                "type": "object",
                "properties": {
                    "vault": {"type": "string", "description": "Vault name"},
                    "note": {"type": "string", "description": "Note path (e.g., 'folder/note' or 'note.md')"}
                },
                "required": ["vault", "note"]
            }
        ),
        Tool(
            name="write_note",
            description="Create or update a note",
            inputSchema={
                "type": "object",
                "properties": {
                    "vault": {"type": "string", "description": "Vault name"},
                    "note": {"type": "string", "description": "Note path"},
                    "content": {"type": "string", "description": "Note content (markdown)"}
                },
                "required": ["vault", "note", "content"]
            }
        ),
        Tool(
            name="search_notes",
            description="Search for text across all notes in a vault",
            inputSchema={
                "type": "object",
                "properties": {
                    "vault": {"type": "string", "description": "Vault name"},
                    "query": {"type": "string", "description": "Search query"}
                },
                "required": ["vault", "query"]
            }
        ),
        Tool(
            name="open_in_obsidian",
            description="Open a note or vault in the Obsidian app",
            inputSchema={
                "type": "object",
                "properties": {
                    "vault": {"type": "string", "description": "Vault name"},
                    "note": {"type": "string", "description": "Note path (optional, opens vault root if not specified)"}
                },
                "required": ["vault"]
            }
        ),
        Tool(
            name="get_vault_schema",
            description="Discover all frontmatter keys and common values used across the vault. Useful for understanding metadata patterns before suggesting or updating frontmatter.",
            inputSchema={
                "type": "object",
                "properties": {
                    "vault": {"type": "string", "description": "Vault name"},
                    "sample_values": {
                        "type": "integer",
                        "description": "Max sample values per key (default: 10)",
                        "default": 10
                    }
                },
                "required": ["vault"]
            }
        ),
    ]


@app.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    if name == "list_vaults":
        vaults = discover_vaults()
        if not vaults:
            return [TextContent(type="text", text="No Obsidian vaults found. Is Obsidian installed?")]

        lines = [f"Found {len(vaults)} vault(s):"]
        for v in vaults:
            status = "OPEN" if v.is_open else "closed"
            lines.append(f"  - {v.name} [{status}]: {v.path}")
        return [TextContent(type="text", text="\n".join(lines))]

    elif name == "list_notes":
        vault = get_vault_by_name(arguments["vault"])
        if not vault:
            return [TextContent(type="text", text=f"Vault not found: {arguments['vault']}")]

        notes = list_notes(vault.path)
        if not notes:
            return [TextContent(type="text", text=f"No notes found in {vault.name}")]

        lines = [f"Found {len(notes)} note(s) in {vault.name}:"]
        for n in notes[:100]:  # Limit output
            lines.append(f"  - {n.relative_path}")
        if len(notes) > 100:
            lines.append(f"  ... and {len(notes) - 100} more")
        return [TextContent(type="text", text="\n".join(lines))]

    elif name == "read_note":
        vault = get_vault_by_name(arguments["vault"])
        if not vault:
            return [TextContent(type="text", text=f"Vault not found: {arguments['vault']}")]

        note = get_note(vault.path, arguments["note"])
        if not note:
            return [TextContent(type="text", text=f"Note not found: {arguments['note']}")]

        raw_content = note.read()
        frontmatter, body = parse_frontmatter(raw_content)

        # Format response with frontmatter as structured data
        if frontmatter:
            # Include frontmatter as JSON block for easy parsing
            fm_json = json.dumps(frontmatter, indent=2, default=str)
            result = f"--- FRONTMATTER ---\n{fm_json}\n--- CONTENT ---\n{body}"
        else:
            result = raw_content

        return [TextContent(type="text", text=result)]

    elif name == "write_note":
        vault = get_vault_by_name(arguments["vault"])
        if not vault:
            return [TextContent(type="text", text=f"Vault not found: {arguments['vault']}")]

        try:
            path = write_note(vault.path, arguments["note"], arguments["content"])
            return [TextContent(type="text", text=f"Note written: {path}")]
        except ValueError as e:
            return [TextContent(type="text", text=f"Error: {e}")]

    elif name == "search_notes":
        vault = get_vault_by_name(arguments["vault"])
        if not vault:
            return [TextContent(type="text", text=f"Vault not found: {arguments['vault']}")]

        results = search_notes(vault.path, arguments["query"])
        if not results:
            return [TextContent(type="text", text=f"No results for: {arguments['query']}")]

        lines = [f"Found {len(results)} result(s):"]
        for r in results:
            lines.append(f"  {r.note_path}:{r.line_number}: {r.snippet}")
        return [TextContent(type="text", text="\n".join(lines))]

    elif name == "open_in_obsidian":
        vault = get_vault_by_name(arguments["vault"])
        if not vault:
            return [TextContent(type="text", text=f"Vault not found: {arguments['vault']}")]

        note_path = arguments.get("note", "")
        try:
            open_obsidian_uri(vault.name, note_path)
            if note_path:
                return [TextContent(type="text", text=f"Opened in Obsidian: {vault.name}/{note_path}")]
            else:
                return [TextContent(type="text", text=f"Opened vault in Obsidian: {vault.name}")]
        except Exception as e:
            return [TextContent(type="text", text=f"Failed to open Obsidian: {e}")]

    elif name == "get_vault_schema":
        vault = get_vault_by_name(arguments["vault"])
        if not vault:
            return [TextContent(type="text", text=f"Vault not found: {arguments['vault']}")]

        max_samples = arguments.get("sample_values", 10)
        schema = get_schema(vault.path, max_sample_values=max_samples)

        # Format as JSON for easy parsing
        return [TextContent(type="text", text=json.dumps(schema, indent=2))]

    return [TextContent(type="text", text=f"Unknown tool: {name}")]


async def main():
    async with stdio_server() as (read_stream, write_stream):
        await app.run(read_stream, write_stream, app.create_initialization_options())


def run():
    """Entry point for uvx."""
    import asyncio
    asyncio.run(main())


if __name__ == "__main__":
    run()
