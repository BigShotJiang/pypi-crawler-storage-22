# MCP Proxy with OAuth DCR Support

Note that this was entirely AI generated and made to handle a specific use-case where closed-source clients do not support FastMCP DCR O-Auth properly. It has been tested with one specific MCP server and works within Kiro, however your milage may vary. As this is AI generated do not query me on its workings, this is a purely temporary tool that burned an ocean to exist.

A protocol translation service that enables Kiro to connect to HTTP streamable MCP servers through a stdio interface while providing OAuth Dynamic Client Registration authentication.

## Overview

The MCP Proxy acts as an intermediary that handles protocol conversion between stdio MCP (expected by Kiro) and HTTP streamable MCP (provided by backend servers), while managing OAuth DCR authentication flows with the backend's OAuth provider.

## Features

- **Protocol Translation**: Converts between stdio JSON-RPC and HTTP streamable MCP protocols
- **OAuth DCR Support**: Automatic client registration and token management using RFC 7591
- **Connection Resilience**: Automatic reconnection with exponential backoff
- **Secure Token Management**: In-memory credential storage with automatic refresh
- **Comprehensive Error Handling**: Graceful handling of network and authentication failures
- **Configurable**: Environment variable and configuration file support

## Installation

```bash
pip install mcp-proxy-oauth-dcr
```

For development:

```bash
pip install -e ".[dev]"
```

## Usage

### Command Line

```bash
mcp-proxy --mcp-server-url https://example.com/mcp --oauth-provider-url https://oauth.example.com
```

### Environment Variables

```bash
export MCP_SERVER_URL=https://example.com/mcp
export OAUTH_PROVIDER_URL=https://oauth.example.com
export CLIENT_NAME=my-mcp-client
mcp-proxy
```

### Configuration File

Create a `config.json` file:

```json
{
  "mcpServerUrl": "https://example.com/mcp",
  "oauthProviderUrl": "https://oauth.example.com",
  "clientName": "my-mcp-client",
  "scopes": ["mcp:read", "mcp:write"],
  "connectionTimeout": 30,
  "retryAttempts": 3,
  "logLevel": "info"
}
```

Then run:

```bash
mcp-proxy --config config.json
```

## Development

### Testing

```bash
# Run all tests
pytest

# Run unit tests only
pytest -m unit

# Run property-based tests
pytest -m property

# Run with coverage
pytest --cov=mcp_proxy --cov-report=html
```

### Code Quality

```bash
# Format code
black src tests
isort src tests

# Type checking
mypy src

# Linting
flake8 src tests
```

## Architecture

The proxy consists of several key components:

- **Stdio Interface**: Handles JSON-RPC communication with Kiro via stdin/stdout
- **Protocol Translator**: Converts between stdio and HTTP streamable MCP protocols
- **Authentication Manager**: Manages OAuth DCR flows and token lifecycle
- **HTTP Client**: Handles communication with backend HTTP MCP servers
- **Configuration Manager**: Manages configuration loading and validation

## License

MIT License - see LICENSE file for details.