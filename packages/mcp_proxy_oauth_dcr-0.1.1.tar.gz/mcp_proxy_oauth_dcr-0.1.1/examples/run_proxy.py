"""Example script demonstrating how to run the MCP Proxy.

This script shows how to:
1. Create a proxy instance with configuration
2. Start the proxy
3. Run until shutdown signal
4. Handle graceful shutdown

Usage:
    # Set environment variables
    export MCP_SERVER_URL="https://d3phcl5fqkzz01.cloudfront.net/mcp/"
    export OAUTH_PROVIDER_URL="https://your-oauth-provider.com"
    
    # Run the proxy
    python examples/run_proxy.py
"""

import asyncio
import os
import sys

# Add src to path for development
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from mcp_proxy import McpProxy, ProxyConfig
from mcp_proxy.logging_config import configure_logging


async def main():
    """Main entry point for the example."""
    # Configure logging
    configure_logging("info")
    
    # Option 1: Load configuration from environment variables
    # proxy = McpProxy()
    
    # Option 2: Provide configuration directly
    config = ProxyConfig(
        mcp_server_url=os.getenv(
            "MCP_SERVER_URL",
            "https://d3phcl5fqkzz01.cloudfront.net/mcp/"
        ),
        oauth_provider_url=os.getenv(
            "OAUTH_PROVIDER_URL",
            "https://your-oauth-provider.com"
        ),
        client_name="mcp-proxy-example",
        scopes=["mcp:read", "mcp:write"],
        connection_timeout=30,
        retry_attempts=3,
        log_level="info",
    )
    
    proxy = McpProxy(config=config)
    
    # Run the proxy (starts and waits for shutdown)
    try:
        print("Starting MCP Proxy...")
        print("Press Ctrl+C to stop")
        await proxy.run()
    except KeyboardInterrupt:
        print("\nShutdown requested")
    except Exception as e:
        print(f"Error: {e}")
        return 1
    
    return 0


if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)
