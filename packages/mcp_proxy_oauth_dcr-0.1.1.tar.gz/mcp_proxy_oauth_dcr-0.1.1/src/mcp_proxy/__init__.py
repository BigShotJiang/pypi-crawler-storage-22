"""MCP Proxy with OAuth DCR Support.

A protocol translation service that enables Kiro to connect to HTTP streamable MCP servers
through a stdio interface while providing OAuth Dynamic Client Registration authentication.
"""

__version__ = "0.1.0"
__author__ = "MCP Proxy Team"
__email__ = "team@mcpproxy.dev"

from .models import (
    AuthenticationState,
    ClientCredentials,
    HttpMcpRequest,
    HttpMcpResponse,
    JsonRpcError,
    JsonRpcMessage,
    MessageCorrelation,
    MessageStatus,
    OAuthTokenResponse,
    ProxyConfig,
    SessionState,
)
from .exceptions import (
    McpProxyError,
    ProtocolError,
    InvalidJsonRpcError,
    MessageCorrelationError,
    UnsupportedMethodError,
    AuthenticationError,
    DcrError,
    TokenError,
    TokenExpiredError,
    TokenRefreshError,
    InvalidCredentialsError,
    NetworkError,
    ConnectionError,
    ConnectionTimeoutError,
    StreamError,
    HttpError,
    ConfigurationError,
    InvalidConfigError,
    MissingConfigError,
)
from .logging_config import configure_logging, get_logger
from .proxy import McpProxy

__all__ = [
    "__version__",
    "__author__",
    "__email__",
    # Main proxy class
    "McpProxy",
    # Models
    "AuthenticationState",
    "ClientCredentials", 
    "HttpMcpRequest",
    "HttpMcpResponse",
    "JsonRpcError",
    "JsonRpcMessage",
    "MessageCorrelation",
    "MessageStatus",
    "OAuthTokenResponse",
    "ProxyConfig",
    "SessionState",
    # Exceptions
    "McpProxyError",
    "ProtocolError",
    "InvalidJsonRpcError",
    "MessageCorrelationError",
    "UnsupportedMethodError",
    "AuthenticationError",
    "DcrError",
    "TokenError",
    "TokenExpiredError",
    "TokenRefreshError",
    "InvalidCredentialsError",
    "NetworkError",
    "ConnectionError",
    "ConnectionTimeoutError",
    "StreamError",
    "HttpError",
    "ConfigurationError",
    "InvalidConfigError",
    "MissingConfigError",
    # Logging
    "configure_logging",
    "get_logger",
]