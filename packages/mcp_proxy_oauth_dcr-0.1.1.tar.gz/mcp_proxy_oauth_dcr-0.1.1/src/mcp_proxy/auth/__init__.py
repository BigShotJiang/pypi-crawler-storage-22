"""Authentication module for MCP Proxy.

This module handles OAuth DCR and token management.
"""

from .manager import AuthenticationManagerImpl

__all__ = ["AuthenticationManagerImpl"]
