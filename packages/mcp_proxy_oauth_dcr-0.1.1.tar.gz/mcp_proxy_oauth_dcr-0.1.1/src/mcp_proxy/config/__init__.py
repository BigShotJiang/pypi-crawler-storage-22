"""Configuration module for MCP Proxy.

This module handles configuration loading and validation.
"""

from .manager import ConfigurationManagerImpl

__all__ = ["ConfigurationManagerImpl"]
