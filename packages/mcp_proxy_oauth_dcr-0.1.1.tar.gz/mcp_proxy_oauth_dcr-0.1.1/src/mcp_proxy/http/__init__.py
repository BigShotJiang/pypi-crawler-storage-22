"""HTTP client module for MCP Proxy.

This module handles HTTP communication with backend MCP servers.
"""

from .client import HttpClientImpl
from .authenticated_client import AuthenticatedHttpClient

__all__ = ["HttpClientImpl", "AuthenticatedHttpClient"]
