"""Stdio interface module for MCP Proxy.

This module handles stdio communication with Kiro using JSON-RPC protocol.
"""

from .interface import StdioInterface, DEFAULT_QUEUE_SIZE, SHUTDOWN_TIMEOUT, DRAIN_TIMEOUT
from .jsonrpc import (
    JsonRpcParser,
    JsonRpcSerializer,
    MessageIdGenerator,
    MessageCorrelationTracker,
    create_request,
    create_response,
    create_notification,
    create_error_response,
)

__all__ = [
    "StdioInterface",
    "DEFAULT_QUEUE_SIZE",
    "SHUTDOWN_TIMEOUT",
    "DRAIN_TIMEOUT",
    "JsonRpcParser",
    "JsonRpcSerializer",
    "MessageIdGenerator",
    "MessageCorrelationTracker",
    "create_request",
    "create_response",
    "create_notification",
    "create_error_response",
]
