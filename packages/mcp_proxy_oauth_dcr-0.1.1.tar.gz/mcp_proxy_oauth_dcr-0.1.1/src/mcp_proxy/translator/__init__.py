"""Protocol translator module for MCP Proxy.

This module handles translation between stdio and HTTP MCP protocols.
"""

try:
    from .translator import ProtocolTranslatorImpl
    __all__ = ["ProtocolTranslatorImpl"]
except ImportError:
    # Module not yet implemented
    __all__ = []
