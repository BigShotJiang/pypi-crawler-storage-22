"""Tests for mcp-schema-server."""
