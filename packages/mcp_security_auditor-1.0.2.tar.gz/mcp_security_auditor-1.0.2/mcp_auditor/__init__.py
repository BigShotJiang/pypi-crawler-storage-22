"""
MCP Security Auditor - A comprehensive security evaluation tool for MCP servers.

This tool analyzes MCP (Model Context Protocol) servers for security vulnerabilities,
permission issues, and potential attack vectors before deployment in sensitive environments.
"""

__version__ = "1.0.2"
__author__ = "MCP Security Auditor"

from .core.scanner import MCPSecurityScanner
from .core.report import ReportGenerator

__all__ = ["MCPSecurityScanner", "ReportGenerator", "__version__"]
