"""
Analyzers module for MCP Security Auditor.

Contains all security analyzers for different aspects of MCP server security.
"""

from .static import StaticCodeAnalyzer, BaseAnalyzer
from .permissions import PermissionAnalyzer
from .network import NetworkAnalyzer
from .dependencies import DependencyAnalyzer
from .injection import InjectionPatternAnalyzer
from .config import ConfigurationAnalyzer
from .secrets import SecretsAnalyzer
from .readonly import ReadOnlyModeAnalyzer

__all__ = [
    "BaseAnalyzer",
    "StaticCodeAnalyzer",
    "PermissionAnalyzer",
    "NetworkAnalyzer",
    "DependencyAnalyzer",
    "InjectionPatternAnalyzer",
    "ConfigurationAnalyzer",
    "SecretsAnalyzer",
    "ReadOnlyModeAnalyzer",
]

# Analyzer registry for dynamic loading
ANALYZERS = {
    "static": StaticCodeAnalyzer,
    "permissions": PermissionAnalyzer,
    "network": NetworkAnalyzer,
    "dependencies": DependencyAnalyzer,
    "injection": InjectionPatternAnalyzer,
    "config": ConfigurationAnalyzer,
    "secrets": SecretsAnalyzer,
    "readonly": ReadOnlyModeAnalyzer,
}


def get_analyzer(name: str):
    """Get an analyzer class by name."""
    return ANALYZERS.get(name)


def list_analyzers():
    """List all available analyzer names."""
    return list(ANALYZERS.keys())
