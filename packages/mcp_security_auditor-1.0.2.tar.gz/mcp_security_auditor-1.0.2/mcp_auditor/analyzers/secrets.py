"""
Secrets Analyzer for MCP Security Auditor.

Detects exposed secrets, API keys, and credentials in source code.
"""

import re
from pathlib import Path
from typing import List, Set, Tuple

from ..core.config import AuditConfig
from ..core.models import (
    Finding, CodeLocation, Remediation, MCPServerInfo
)
from .static import BaseAnalyzer


class SecretsAnalyzer(BaseAnalyzer):
    """
    Analyzes code for exposed secrets and credentials.
    
    Checks for:
    - API keys and tokens
    - Passwords and credentials
    - Private keys
    - Connection strings
    - OAuth tokens
    """
    
    name = "secrets"
    
    # High-entropy string detection threshold
    ENTROPY_THRESHOLD = 4.0
    
    # File patterns to skip (binary, generated, etc.)
    SKIP_EXTENSIONS = {
        '.png', '.jpg', '.jpeg', '.gif', '.ico', '.svg',
        '.woff', '.woff2', '.ttf', '.eot',
        '.pdf', '.zip', '.tar', '.gz',
        '.lock', '.sum',
        '.min.js', '.min.css',
    }
    
    # Common false positive patterns (test data, examples)
    FALSE_POSITIVE_PATTERNS = [
        r'example',
        r'sample',
        r'test',
        r'dummy',
        r'fake',
        r'placeholder',
        r'your[_-]',
        r'xxx+',
        r'<[A-Z_]+>',
        r'\[.*\]',
        r'TODO',
        r'CHANGEME',
        r'REPLACE',
    ]
    
    async def analyze(self, path: str, server_info: MCPServerInfo) -> List[Finding]:
        """Analyze code for exposed secrets."""
        findings = []
        path = Path(path)
        seen_secrets: Set[str] = set()  # Deduplicate
        
        # Scan all text files
        for file_path in path.rglob("*"):
            if not file_path.is_file():
                continue
            
            if self._should_skip_file(file_path):
                continue
            
            if file_path.suffix.lower() in self.SKIP_EXTENSIONS:
                continue
            
            content = self._read_file_content(file_path)
            if not content:
                continue
            
            relative_path = str(file_path.relative_to(path))
            
            # Check configured secret patterns
            for secret_pattern in self.config.secret_patterns:
                file_findings = self._check_pattern(
                    file_path, content, relative_path,
                    secret_pattern.pattern,
                    secret_pattern.name,
                    secret_pattern.severity
                )
                
                for finding in file_findings:
                    # Deduplicate based on the secret value (first 8 chars)
                    if finding.location and finding.location.snippet:
                        snippet_hash = finding.location.snippet[:50]
                        if snippet_hash not in seen_secrets:
                            seen_secrets.add(snippet_hash)
                            findings.append(finding)
                    else:
                        findings.append(finding)
            
            # Check for high-entropy strings (potential secrets)
            findings.extend(self._check_high_entropy(file_path, content, relative_path))
        
        return findings
    
    def _check_pattern(
        self,
        file_path: Path,
        content: str,
        relative_path: str,
        pattern: str,
        secret_name: str,
        severity: str
    ) -> List[Finding]:
        """Check content for a specific secret pattern."""
        findings = []
        lines = content.split('\n')
        
        try:
            regex = re.compile(pattern, re.IGNORECASE | re.MULTILINE)
            
            for i, line in enumerate(lines, 1):
                # Skip comments
                stripped = line.strip()
                if stripped.startswith('#') or stripped.startswith('//') or stripped.startswith('*'):
                    continue
                
                matches = regex.findall(line)
                for match in matches:
                    match_str = match if isinstance(match, str) else match[0] if match else ""
                    
                    # Check for false positives
                    if self._is_false_positive(match_str, line):
                        continue
                    
                    # Mask the secret in the description
                    masked_secret = self._mask_secret(match_str)
                    
                    findings.append(Finding(
                        title=f"Exposed {secret_name}",
                        description=f"Potential {secret_name} found in {relative_path}. "
                                   f"Value: {masked_secret}",
                        severity=severity,
                        category="secrets",
                        analyzer=self.name,
                        location=CodeLocation(
                            file=relative_path,
                            line_start=i,
                            line_end=i,
                            snippet=self._get_code_snippet(file_path, i)
                        ),
                        remediation=Remediation(
                            description=f"Remove the {secret_name} from source code. "
                                       f"Use environment variables or a secrets manager instead.",
                            code_example=self._get_secret_remediation_example(secret_name),
                            references=[
                                "https://cwe.mitre.org/data/definitions/798.html",
                                "https://cwe.mitre.org/data/definitions/312.html"
                            ]
                        ),
                        cwe_id="CWE-798",
                        confidence="high" if severity == "critical" else "medium"
                    ))
                    break  # Only report first match per line
        
        except re.error:
            pass
        
        return findings
    
    def _check_high_entropy(self, file_path: Path, content: str, relative_path: str) -> List[Finding]:
        """Check for high-entropy strings that might be secrets."""
        findings = []
        lines = content.split('\n')
        
        # Pattern for quoted strings or assignments
        string_pattern = re.compile(r'["\']([A-Za-z0-9+/=_\-]{20,})["\']')
        
        for i, line in enumerate(lines, 1):
            # Skip comments
            stripped = line.strip()
            if stripped.startswith('#') or stripped.startswith('//'):
                continue
            
            for match in string_pattern.finditer(line):
                value = match.group(1)
                
                # Skip if it's a false positive
                if self._is_false_positive(value, line):
                    continue
                
                # Calculate entropy
                entropy = self._calculate_entropy(value)
                
                if entropy >= self.ENTROPY_THRESHOLD:
                    # Check if it looks like a key/token context
                    key_indicators = [
                        'key', 'token', 'secret', 'password', 'credential',
                        'auth', 'api', 'private', 'access', 'bearer'
                    ]
                    
                    has_indicator = any(ind in line.lower() for ind in key_indicators)
                    
                    if has_indicator:
                        findings.append(Finding(
                            title="Potential hardcoded secret (high entropy)",
                            description=f"High-entropy string found in potential credential context. "
                                       f"Entropy: {entropy:.2f}",
                            severity="medium",
                            category="secrets",
                            analyzer=self.name,
                            location=CodeLocation(
                                file=relative_path,
                                line_start=i,
                                line_end=i,
                                snippet=self._get_code_snippet(file_path, i)
                            ),
                            remediation=Remediation(
                                description="If this is a secret, move it to environment variables "
                                           "or a secrets manager."
                            ),
                            confidence="low"
                        ))
        
        return findings
    
    def _calculate_entropy(self, value: str) -> float:
        """Calculate Shannon entropy of a string."""
        import math
        
        if not value:
            return 0.0
        
        # Count character frequencies
        freq = {}
        for char in value:
            freq[char] = freq.get(char, 0) + 1
        
        # Calculate entropy
        entropy = 0.0
        length = len(value)
        
        for count in freq.values():
            probability = count / length
            entropy -= probability * math.log2(probability)
        
        return entropy
    
    def _is_false_positive(self, value: str, context: str) -> bool:
        """Check if a match is likely a false positive."""
        combined = f"{value} {context}".lower()
        
        # Check against false positive patterns
        for pattern in self.FALSE_POSITIVE_PATTERNS:
            if re.search(pattern, combined, re.IGNORECASE):
                return True
        
        # Check for common non-secret patterns
        if value.lower() in ['true', 'false', 'null', 'none', 'undefined']:
            return True
        
        # Check for all same character
        if len(set(value)) <= 2:
            return True
        
        # Check for sequential patterns (abc, 123, etc.)
        if self._is_sequential(value):
            return True
        
        return False
    
    def _is_sequential(self, value: str) -> bool:
        """Check if a string is a sequential pattern."""
        if len(value) < 4:
            return False
        
        # Check for repeating characters
        if len(set(value)) == 1:
            return True
        
        # Check for simple sequences
        sequences = ['0123456789', 'abcdefghijklmnopqrstuvwxyz', 'ABCDEFGHIJKLMNOPQRSTUVWXYZ']
        
        for seq in sequences:
            for i in range(len(seq) - len(value) + 1):
                if seq[i:i+len(value)] == value:
                    return True
                if seq[i:i+len(value)][::-1] == value:
                    return True
        
        return False
    
    def _mask_secret(self, value: str) -> str:
        """Mask a secret value for display."""
        if len(value) <= 8:
            return '*' * len(value)
        
        # Show first 4 and last 4 characters
        return f"{value[:4]}{'*' * (len(value) - 8)}{value[-4:]}"
    
    def _get_secret_remediation_example(self, secret_name: str) -> str:
        """Get a code example for secret remediation."""
        secret_lower = secret_name.lower()
        
        if 'aws' in secret_lower:
            return """# Instead of hardcoding AWS credentials:
import os
import boto3

# Use environment variables or AWS credential chain
session = boto3.Session()  # Uses default credential chain

# Or explicitly from environment:
access_key = os.environ.get('AWS_ACCESS_KEY_ID')
secret_key = os.environ.get('AWS_SECRET_ACCESS_KEY')
"""
        
        elif 'api' in secret_lower or 'key' in secret_lower:
            return """# Instead of hardcoding API keys:
import os

# Use environment variables
api_key = os.environ.get('API_KEY')

# Or use a config file (not committed to git)
# with python-dotenv:
from dotenv import load_dotenv
load_dotenv()
api_key = os.getenv('API_KEY')
"""
        
        elif 'database' in secret_lower or 'connection' in secret_lower:
            return """# Instead of hardcoding connection strings:
import os

# Use environment variables
database_url = os.environ.get('DATABASE_URL')

# For production, use a secrets manager:
# - AWS Secrets Manager
# - HashiCorp Vault
# - Azure Key Vault
"""
        
        elif 'private' in secret_lower and 'key' in secret_lower:
            return """# Instead of embedding private keys:
# 1. Store in a file outside the repository
# 2. Use environment variables for the path:

import os

key_path = os.environ.get('PRIVATE_KEY_PATH')
with open(key_path) as f:
    private_key = f.read()

# Or use a secrets manager for key storage
"""
        
        else:
            return """# Instead of hardcoding secrets:
import os

# Use environment variables:
secret = os.environ.get('SECRET_NAME')

# Or use a .env file (add to .gitignore):
# SECRET_NAME=your-secret-value

from dotenv import load_dotenv
load_dotenv()
secret = os.getenv('SECRET_NAME')
"""
