"""
Core module for MCP Security Auditor.

Contains the main scanner, models, configuration, and report generation.
"""

from .models import (
    Finding,
    CodeLocation,
    Remediation,
    ScanResult,
    MCPServerInfo,
    ToolDefinition,
    PermissionScope,
    NetworkEndpoint,
    Dependency,
    Severity,
    FindingCategory
)
from .config import AuditConfig
from .scanner import MCPSecurityScanner
from .report import ReportGenerator

__all__ = [
    "Finding",
    "CodeLocation", 
    "Remediation",
    "ScanResult",
    "MCPServerInfo",
    "ToolDefinition",
    "PermissionScope",
    "NetworkEndpoint",
    "Dependency",
    "Severity",
    "FindingCategory",
    "AuditConfig",
    "MCPSecurityScanner",
    "ReportGenerator"
]
