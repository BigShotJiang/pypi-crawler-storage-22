claude mcp remove bigquery --scope user
claude mcp add bigquery --scope user --transport stdio -- uv --directory $(pwd) run mcp-server-bigquery --project knowunity-data-prod --location europe-west3
