set -e

echo "Run query..."
claude -p "Run the query SELECT id FROM knowunity_backend_public.grade LIMIT 10 in BigQuery"

echo "Run failing query..."
claude -p "Run the query SELECT id FROM knowunity_backend_public.my_table in BigQuery"
