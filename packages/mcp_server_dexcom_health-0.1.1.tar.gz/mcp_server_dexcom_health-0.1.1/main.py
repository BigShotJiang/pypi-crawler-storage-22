def main():
    print("Hello from mcp-server-dexcom!")


if __name__ == "__main__":
    main()
