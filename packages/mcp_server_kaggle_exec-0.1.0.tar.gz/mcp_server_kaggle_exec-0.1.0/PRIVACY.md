# Privacy Policy

**mcp-server-kaggle-exec**
Last updated: February 15, 2026

## Overview

mcp-server-kaggle-exec is an open-source MCP server that executes Python code on Kaggle GPU runtimes. This policy explains what data the server handles and how.

## Data Collection

This server does **not** collect, store, or transmit any personal data to the developer or any third party. There is no analytics, telemetry, or tracking of any kind.

## Data Handling

### What the server processes

- **Python code** you submit for execution — sent to Kaggle's API over HTTPS
- **Execution results** (stdout, stderr, errors) — returned from Kaggle to your local machine
- **Generated artifacts** (images, files, models) — downloaded from Kaggle to a local directory you specify

### Where data goes

All code and data are transmitted directly between your local machine and Kaggle's API. The server acts as a local bridge and does not route data through any intermediary servers.

### Authentication tokens

- Kaggle API credentials are stored locally at `~/.kaggle/kaggle.json`
- Credentials are never transmitted anywhere other than to Kaggle's API endpoints
- You can revoke access at any time by deleting this file or regenerating your API token in your [Kaggle Settings](https://www.kaggle.com/settings)

### Data retention

- The server stores no data beyond the current session
- Kaggle API credentials are managed by the user (not by this server)
- No execution history, logs, or code is retained by the server
- Kernels created during execution are private and can be deleted

## Third-Party Services

This server connects to **Kaggle** (kaggle.com) to create and run GPU kernels. Your use of Kaggle is governed by [Kaggle's Terms of Service](https://www.kaggle.com/terms) and [Privacy Policy](https://www.kaggle.com/privacy).

## Security

- All communication with Kaggle uses HTTPS/TLS encryption
- API credentials use token-based authentication
- No secrets or credentials are hardcoded or transmitted to third parties
- Kernels are created as private (not publicly visible)

## Your Rights

Since no personal data is collected or stored by this server, there is no personal data to access, modify, or delete. You can:

- Delete your local Kaggle credentials at any time (`~/.kaggle/kaggle.json`)
- Regenerate your Kaggle API token from your Kaggle Settings
- Uninstall the server at any time (`pip uninstall mcp-server-kaggle-exec`)

## Open Source

This server is fully open source under the MIT License. You can audit the complete source code at:
https://github.com/pdwi2020/mcp-server-kaggle-exec

## Contact

For privacy questions or concerns, open an issue at:
https://github.com/pdwi2020/mcp-server-kaggle-exec/issues

Or email: paritoshdwi2019@gmail.com
