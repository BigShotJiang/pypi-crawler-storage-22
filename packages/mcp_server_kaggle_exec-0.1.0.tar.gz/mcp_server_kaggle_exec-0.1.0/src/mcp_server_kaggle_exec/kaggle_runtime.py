"""Kaggle GPU runtime engine — auth, kernel push, poll, output fetch, cleanup.

Provides a clean importable API for executing Python code on Kaggle GPU
kernels via the Kaggle API (batch execution model).
"""

import json
import os
import shutil
import sys
import tempfile
import time
import uuid

from kaggle.api.kaggle_api_extended import KaggleApi


# ── Auth ─────────────────────────────────────────────────────────────────────

def get_kaggle_api() -> KaggleApi:
    """Initialize and authenticate Kaggle API.

    Supports multiple auth methods (handled by KaggleApi.authenticate()):
    - KAGGLE_API_TOKEN env var (KGAT_* access tokens)
    - ~/.kaggle/kaggle.json (legacy API key)
    - Kaggle OAuth2

    Raises RuntimeError if no auth method succeeds.
    """
    api = KaggleApi()
    try:
        api.authenticate()
    except Exception as e:
        raise RuntimeError(
            "Kaggle authentication failed. Provide credentials via one of:\n"
            "  1. KAGGLE_API_TOKEN env var (KGAT_* access token)\n"
            "  2. ~/.kaggle/kaggle.json (legacy API key)\n"
            f"Original error: {e}"
        ) from e
    return api


def get_username(api: KaggleApi) -> str:
    """Get authenticated Kaggle username for kernel ID construction.

    Reads from in-memory config (works with KGAT_* tokens where
    _introspect_token() populates api.config_values), falling back
    to KAGGLE_USERNAME env var.
    """
    username = api.get_config_value(api.CONFIG_NAME_USER)
    if not username:
        username = os.environ.get("KAGGLE_USERNAME")
    if not username:
        raise RuntimeError(
            "Could not determine Kaggle username. "
            "Ensure your credentials are valid or set KAGGLE_USERNAME env var."
        )
    return username


# ── Kernel Execution ─────────────────────────────────────────────────────────

def run_on_kaggle(
    code: str,
    enable_gpu: bool = True,
    enable_internet: bool = True,
    timeout: int = 600,
    cleanup: bool = True,
) -> dict:
    """Execute Python code on a Kaggle kernel.

    Creates a temporary kernel, pushes code, polls for completion,
    fetches output, and optionally cleans up.

    Args:
        code: Python code to execute.
        enable_gpu: Whether to request GPU acceleration.
        enable_internet: Whether to enable internet in the kernel.
        timeout: Max wait time in seconds (default 600).
        cleanup: Whether to delete the kernel after fetching output.

    Returns:
        dict with keys: stdout, stderr, status, output_files, execution_time
    """
    api = get_kaggle_api()
    username = get_username(api)

    # Generate unique kernel slug
    short_id = uuid.uuid4().hex[:8]
    kernel_slug = f"mcp-kaggle-exec-{short_id}"
    kernel_id = f"{username}/{kernel_slug}"

    # Create temp directory with script and metadata
    temp_dir = tempfile.mkdtemp(prefix="kaggle_exec_")
    output_dir = tempfile.mkdtemp(prefix="kaggle_output_")

    try:
        # Write the script
        script_path = os.path.join(temp_dir, "script.py")
        with open(script_path, "w") as f:
            f.write(code)

        # Write kernel metadata
        metadata = {
            "id": kernel_id,
            "title": kernel_slug,
            "code_file": "script.py",
            "language": "python",
            "kernel_type": "script",
            "is_private": "true",
            "enable_gpu": str(enable_gpu).lower(),
            "enable_internet": str(enable_internet).lower(),
        }
        metadata_path = os.path.join(temp_dir, "kernel-metadata.json")
        with open(metadata_path, "w") as f:
            json.dump(metadata, f, indent=2)

        # Push kernel
        print(f"[kaggle-exec] Pushing kernel {kernel_id}...", file=sys.stderr)
        start_time = time.time()
        api.kernels_push(temp_dir)

        # Poll for completion
        print(f"[kaggle-exec] Polling status (timeout={timeout}s)...", file=sys.stderr)
        final_status = poll_status(api, kernel_id, timeout=timeout)
        execution_time = round(time.time() - start_time, 1)

        print(
            f"[kaggle-exec] Kernel finished with status: {final_status} ({execution_time}s)",
            file=sys.stderr,
        )

        # Fetch output
        result = fetch_output(api, kernel_id, output_dir)

        # Parse stdout/stderr from log
        log_content = result.get("log", "")
        stdout, stderr = _split_log(log_content)

        return {
            "stdout": stdout,
            "stderr": stderr,
            "status": final_status,
            "output_files": result.get("files", []),
            "execution_time": execution_time,
            "kernel_id": kernel_id,
        }

    finally:
        # Cleanup temp dirs
        shutil.rmtree(temp_dir, ignore_errors=True)
        shutil.rmtree(output_dir, ignore_errors=True)

        # Optionally delete the kernel from Kaggle
        if cleanup:
            try:
                _cleanup_kernel(api, kernel_id)
            except Exception as e:
                print(f"[kaggle-exec] Warning: cleanup failed: {e}", file=sys.stderr)


def run_on_kaggle_with_artifacts(
    code: str,
    local_output_dir: str,
    enable_gpu: bool = True,
    enable_internet: bool = True,
    timeout: int = 600,
    cleanup: bool = True,
) -> dict:
    """Execute code on Kaggle and download output files to a local directory.

    Args:
        code: Python code to execute.
        local_output_dir: Local directory to save output files.
        enable_gpu: Whether to request GPU acceleration.
        enable_internet: Whether to enable internet in the kernel.
        timeout: Max wait time in seconds.
        cleanup: Whether to delete the kernel after fetching output.

    Returns:
        dict with keys: stdout, stderr, status, output_files, execution_time, kernel_id
    """
    api = get_kaggle_api()
    username = get_username(api)

    short_id = uuid.uuid4().hex[:8]
    kernel_slug = f"mcp-kaggle-exec-{short_id}"
    kernel_id = f"{username}/{kernel_slug}"

    temp_dir = tempfile.mkdtemp(prefix="kaggle_exec_")
    output_dir = tempfile.mkdtemp(prefix="kaggle_output_")
    os.makedirs(local_output_dir, exist_ok=True)

    try:
        script_path = os.path.join(temp_dir, "script.py")
        with open(script_path, "w") as f:
            f.write(code)

        metadata = {
            "id": kernel_id,
            "title": kernel_slug,
            "code_file": "script.py",
            "language": "python",
            "kernel_type": "script",
            "is_private": "true",
            "enable_gpu": str(enable_gpu).lower(),
            "enable_internet": str(enable_internet).lower(),
        }
        metadata_path = os.path.join(temp_dir, "kernel-metadata.json")
        with open(metadata_path, "w") as f:
            json.dump(metadata, f, indent=2)

        print(f"[kaggle-exec] Pushing kernel {kernel_id}...", file=sys.stderr)
        start_time = time.time()
        api.kernels_push(temp_dir)

        print(f"[kaggle-exec] Polling status (timeout={timeout}s)...", file=sys.stderr)
        final_status = poll_status(api, kernel_id, timeout=timeout)
        execution_time = round(time.time() - start_time, 1)

        print(
            f"[kaggle-exec] Kernel finished with status: {final_status} ({execution_time}s)",
            file=sys.stderr,
        )

        # Fetch output to temp dir first
        result = fetch_output(api, kernel_id, output_dir)

        # Copy output files to user-specified directory
        saved_files = []
        for fpath in result.get("files", []):
            if os.path.isfile(fpath):
                dest = os.path.join(local_output_dir, os.path.basename(fpath))
                shutil.copy2(fpath, dest)
                saved_files.append(dest)

        log_content = result.get("log", "")
        stdout, stderr = _split_log(log_content)

        return {
            "stdout": stdout,
            "stderr": stderr,
            "status": final_status,
            "output_files": saved_files,
            "execution_time": execution_time,
            "kernel_id": kernel_id,
        }

    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)
        shutil.rmtree(output_dir, ignore_errors=True)

        if cleanup:
            try:
                _cleanup_kernel(api, kernel_id)
            except Exception as e:
                print(f"[kaggle-exec] Warning: cleanup failed: {e}", file=sys.stderr)


# ── Status Polling ───────────────────────────────────────────────────────────

def poll_status(
    api: KaggleApi, kernel_id: str, timeout: int = 600, interval: int = 15
) -> str:
    """Poll kernel status until complete, error, or timeout.

    Kaggle kernel statuses: queued, running, complete, error, cancelAcknowledged

    Args:
        api: Authenticated KaggleApi instance.
        kernel_id: Full kernel ID (username/kernel-slug).
        timeout: Max wait time in seconds.
        interval: Polling interval in seconds.

    Returns:
        Final status string.
    """
    deadline = time.time() + timeout
    last_status = "unknown"

    while time.time() < deadline:
        try:
            status_response = api.kernels_status(kernel_id)
            # kernels_status returns an object whose .status is a
            # KernelWorkerStatus enum — str() gives "KernelWorkerStatus.complete"
            if status_response and hasattr(status_response, "status"):
                raw = str(status_response.status).strip().lower()
                # Strip enum class prefix if present (e.g. "kernelworkerstatus.complete" → "complete")
                status = raw.split(".")[-1] if "." in raw else raw
            elif status_response:
                status = str(status_response).strip().lower()
            else:
                status = "unknown"

            if status != last_status:
                print(f"[kaggle-exec] Status: {status}", file=sys.stderr)
                last_status = status

            if status in ("complete", "error", "cancelacknowledged"):
                return status

        except Exception as e:
            print(f"[kaggle-exec] Status poll error: {e}", file=sys.stderr)

        remaining = int(deadline - time.time())
        if remaining <= 0:
            break

        time.sleep(min(interval, remaining))

    return "timeout"


# ── Output Retrieval ─────────────────────────────────────────────────────────

def fetch_output(api: KaggleApi, kernel_id: str, output_dir: str) -> dict:
    """Download kernel output (log + files) to output_dir.

    Args:
        api: Authenticated KaggleApi instance.
        kernel_id: Full kernel ID (username/kernel-slug).
        output_dir: Directory to save output files.

    Returns:
        dict with keys: log (str), files (list of file paths)
    """
    os.makedirs(output_dir, exist_ok=True)

    try:
        # Returns (file_list, token) — files are also written to output_dir
        api.kernels_output(kernel_id, path=output_dir)
    except Exception as e:
        print(f"[kaggle-exec] Warning: failed to fetch output: {e}", file=sys.stderr)
        return {"log": f"Error fetching output: {e}", "files": []}

    # Read log file
    log_content = ""
    kernel_slug = kernel_id.split("/")[-1]
    log_path = os.path.join(output_dir, f"{kernel_slug}.log")
    if os.path.exists(log_path):
        with open(log_path) as f:
            log_content = f.read()
    else:
        # Try finding any .log file in output_dir
        for fname in os.listdir(output_dir):
            if fname.endswith(".log"):
                with open(os.path.join(output_dir, fname)) as f:
                    log_content = f.read()
                break

    # Collect output files (exclude log)
    files = []
    for fname in os.listdir(output_dir):
        fpath = os.path.join(output_dir, fname)
        if os.path.isfile(fpath) and not fname.endswith(".log"):
            files.append(fpath)

    return {"log": log_content, "files": files}


# ── Log Parsing ──────────────────────────────────────────────────────────────

def _split_log(log_content: str) -> tuple[str, str]:
    """Split Kaggle kernel log into stdout and stderr.

    Kaggle logs can be in two formats:
    1. JSON lines: each line is a JSON object with stream_name and data fields
    2. Plain text: lines starting with error prefixes go to stderr

    Returns (stdout, stderr) as strings.
    """
    stdout_lines = []
    stderr_lines = []

    # Try JSON format first (Kaggle API v2 output)
    # Log is a JSON array written with one object per line:
    #   [{"stream_name":"stdout","time":0.9,"data":"hello\n"}
    #   ,{"stream_name":"stderr","time":3.8,"data":"warning\n"}
    #   ]
    json_parsed = False
    for raw_line in log_content.split("\n"):
        line = raw_line.strip()
        # Strip array brackets and leading commas
        if line.startswith("["):
            line = line[1:]
        if line.endswith("]"):
            line = line[:-1]
        line = line.strip().lstrip(",").strip()
        if not line:
            continue
        try:
            entry = json.loads(line)
            if isinstance(entry, dict) and "stream_name" in entry:
                json_parsed = True
                data = entry.get("data", "").rstrip("\n")
                if entry["stream_name"] == "stderr":
                    stderr_lines.append(data)
                else:
                    stdout_lines.append(data)
        except (json.JSONDecodeError, TypeError):
            if not json_parsed:
                break  # Not JSON format, fall through to plain text

    # Fallback: plain text heuristic parsing
    if not json_parsed:
        error_prefixes = ("Traceback", "Error", "Exception", "WARNING", "CRITICAL")
        in_traceback = False

        for line in log_content.split("\n"):
            if any(line.strip().startswith(p) for p in error_prefixes):
                in_traceback = True

            if in_traceback:
                stderr_lines.append(line)
                if line.strip() == "" and stderr_lines:
                    in_traceback = False
            else:
                stdout_lines.append(line)

    return "\n".join(stdout_lines).strip(), "\n".join(stderr_lines).strip()


# ── Cleanup ──────────────────────────────────────────────────────────────────

def _cleanup_kernel(api: KaggleApi, kernel_id: str) -> None:
    """Clean up after kernel execution.

    The Kaggle API does not support kernel deletion directly.
    Kernels are created as private, so they don't appear publicly.
    """
    print(
        f"[kaggle-exec] Kernel {kernel_id} is private; no cleanup needed.",
        file=sys.stderr,
    )
