"""MCP server for executing Python code on Kaggle GPU runtimes.

Exposes three tools via the FastMCP API:
- kaggle_execute: Run inline Python code on a Kaggle GPU kernel
- kaggle_execute_file: Run a local .py file on a Kaggle GPU kernel
- kaggle_execute_notebook: Run code and collect generated artifacts
"""

import json
import os

from mcp.server.fastmcp import FastMCP

from .kaggle_runtime import run_on_kaggle, run_on_kaggle_with_artifacts

mcp = FastMCP("kaggle-exec")


# ── Tools ────────────────────────────────────────────────────────────────────

@mcp.tool(
    annotations={
        "title": "Execute Python Code on Kaggle GPU",
        "readOnlyHint": False,
        "destructiveHint": False,
    }
)
def kaggle_execute(code: str, enable_gpu: bool = True, timeout: int = 600) -> str:
    """Execute Python code on a Kaggle GPU kernel.

    Pushes code as a private Kaggle kernel, waits for execution to complete,
    and returns the output. Kaggle provides free GPU access (T4 x2, P100)
    with ~30 hours/week quota.

    Note: This is batch execution — code runs to completion before results
    are returned. Expect 30-120s startup time plus execution time.

    Args:
        code: Python code to execute on the Kaggle GPU runtime.
        enable_gpu: Whether to request GPU acceleration (default True).
        timeout: Max wait time in seconds (default 600). Kaggle kernels can
                 take 30-120s just to start, so keep this generous.
    """
    try:
        result = run_on_kaggle(
            code=code,
            enable_gpu=enable_gpu,
            timeout=timeout,
        )
        return json.dumps(result, indent=2)
    except Exception as e:
        return json.dumps({"error": str(e), "status": "failed"}, indent=2)


@mcp.tool(
    annotations={
        "title": "Execute Python File on Kaggle GPU",
        "readOnlyHint": False,
        "destructiveHint": False,
    }
)
def kaggle_execute_file(
    file_path: str, enable_gpu: bool = True, timeout: int = 600
) -> str:
    """Execute a local Python file on a Kaggle GPU kernel.

    Reads the file contents and sends them for execution on a Kaggle GPU kernel.

    Args:
        file_path: Path to a local .py file to execute on Kaggle.
        enable_gpu: Whether to request GPU acceleration (default True).
        timeout: Max wait time in seconds (default 600).
    """
    file_path = os.path.expanduser(file_path)
    if not os.path.isfile(file_path):
        return json.dumps({"error": f"File not found: {file_path}"})

    with open(file_path) as f:
        code = f.read()

    try:
        result = run_on_kaggle(
            code=code,
            enable_gpu=enable_gpu,
            timeout=timeout,
        )
        return json.dumps(result, indent=2)
    except Exception as e:
        return json.dumps({"error": str(e), "status": "failed"}, indent=2)


@mcp.tool(
    annotations={
        "title": "Execute Code and Download Artifacts",
        "readOnlyHint": False,
        "destructiveHint": False,
    }
)
def kaggle_execute_notebook(
    code: str, output_dir: str, enable_gpu: bool = True, timeout: int = 600
) -> str:
    """Execute Python code on Kaggle GPU and download all output files.

    Runs the code, then downloads any files the kernel wrote to its output
    directory. Use this when your code generates artifacts (images, models,
    CSVs, etc.) that you want to retrieve locally.

    To save files for download, write them to the current directory in your
    code — Kaggle automatically collects files from the working directory
    as kernel output.

    Args:
        code: Python code to execute on the Kaggle GPU runtime.
        output_dir: Local directory to save downloaded output files.
        enable_gpu: Whether to request GPU acceleration (default True).
        timeout: Max wait time in seconds (default 600).
    """
    output_dir = os.path.expanduser(output_dir)

    try:
        result = run_on_kaggle_with_artifacts(
            code=code,
            local_output_dir=output_dir,
            enable_gpu=enable_gpu,
            timeout=timeout,
        )
        return json.dumps(result, indent=2)
    except Exception as e:
        return json.dumps({"error": str(e), "status": "failed"}, indent=2)


# ── Entry point ──────────────────────────────────────────────────────────────

def main():
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
