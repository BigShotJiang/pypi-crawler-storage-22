<div align="center">

# mcp-server-paystack

**Paystack MCP Server — accept payments, verify transactions, and manage customers through AI assistants.**

[![PyPI](https://img.shields.io/pypi/v/mcp-server-paystack?style=flat-square&color=blue)](https://pypi.org/project/mcp-server-paystack/)
[![Downloads](https://img.shields.io/pypi/dm/mcp-server-paystack?style=flat-square&color=green)](https://pypi.org/project/mcp-server-paystack/)
![Python](https://img.shields.io/badge/Python-3.10+-3776AB?style=flat-square&logo=python&logoColor=white)
![License](https://img.shields.io/badge/License-MIT-green?style=flat-square)

</div>

---

An [MCP](https://modelcontextprotocol.io/) server that connects AI assistants (Claude, Cursor, etc.) to the [Paystack](https://paystack.com) API. Initialize payments, verify transactions, manage customers, create payment links, check balances, and more — all through natural language.

> Stripe has an MCP server. Now Africa's biggest payment platform does too.

## Quick Start

### Install

```bash
pip install mcp-server-paystack
```

### Get Your API Key

1. Create a free account at [paystack.com](https://paystack.com)
2. Go to **Settings > API Keys & Webhooks**
3. Copy your **Test Secret Key** (`sk_test_...`)

Test mode is completely free — no real money is involved.

### Configure

#### Claude Desktop

Add to `~/Library/Application Support/Claude/claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "paystack": {
      "command": "mcp-server-paystack",
      "env": {
        "PAYSTACK_SECRET_KEY": "sk_test_your_key_here"
      }
    }
  }
}
```

#### Claude Code

```bash
claude mcp add paystack -e PAYSTACK_SECRET_KEY=sk_test_your_key_here -- mcp-server-paystack
```

#### Cursor

Add to `.cursor/mcp.json`:

```json
{
  "mcpServers": {
    "paystack": {
      "command": "mcp-server-paystack",
      "env": {
        "PAYSTACK_SECRET_KEY": "sk_test_your_key_here"
      }
    }
  }
}
```

## What You Can Do

```
You:    "Create a payment link for NGN 5,000 for my consultation fee"
Claude: Done! Payment link: https://paystack.com/pay/consultation-fee

You:    "Check my Paystack balance"
Claude: Your balance is NGN 125,000.00

You:    "Show me all successful transactions from last week"
Claude: Transactions (showing 8 of 8):
          ref_001  |  NGN 5,000.00  |  success  |  john@email.com  |  2026-02-10
          ref_002  |  NGN 12,500.00 |  success  |  jane@email.com  |  2026-02-11
          ...

You:    "Verify the payment with reference TXN_abc123"
Claude: Transaction: TXN_abc123
        Status: PAID
        Amount: NGN 10,000.00
        Channel: card
        Customer: customer@email.com

You:    "Resolve account number 0123456789 at Access Bank (code 044)"
Claude: Account verified!
        Account name: JOHN DOE
        Account number: 0123456789
```

## Available Tools

| Tool | Description |
|------|-------------|
| `paystack_initialize_transaction` | Create a payment and get a checkout URL |
| `paystack_verify_transaction` | Check if a payment was successful |
| `paystack_list_transactions` | List recent transactions with filters |
| `paystack_check_balance` | Check account balance |
| `paystack_create_customer` | Create a new customer |
| `paystack_list_customers` | List customers |
| `paystack_create_payment_page` | Create a reusable payment link |
| `paystack_list_banks` | List supported banks in a country |
| `paystack_resolve_account` | Verify a bank account number |
| `paystack_transaction_totals` | Get transaction summary statistics |

## Supported Currencies

| Currency | Country |
|----------|---------|
| NGN | Nigeria |
| GHS | Ghana |
| ZAR | South Africa |
| KES | Kenya |
| USD | International |

## Development

```bash
# Clone the repo
git clone https://github.com/TRINITY-21/mcp-server-paystack.git
cd mcp-server-paystack

# Install in development mode
pip install -e .

# Run tests
python -m pytest tests/ -v

# Run the server locally
PAYSTACK_SECRET_KEY=sk_test_xxx mcp-server-paystack
```

## How It Works

1. The MCP server runs as a local process, communicating via stdio
2. AI assistants discover the available Paystack tools through the MCP protocol
3. When you ask a payment-related question, the assistant calls the appropriate tool
4. The tool makes an authenticated request to the Paystack API and returns formatted results
5. All amounts are accepted in main currency units (e.g., 5000 for NGN 5,000) and converted internally

## Support

If this project is useful to you, consider supporting it.

<a href="https://buymeacoffee.com/trinity_21" target="_blank"><img src="https://cdn.buymeacoffee.com/buttons/v2/default-yellow.png" alt="Buy Me A Coffee" height="40"></a>

## License

MIT
