"""MCP server for Paystack — accept payments, verify transactions, manage customers."""

__version__ = "0.1.0"
