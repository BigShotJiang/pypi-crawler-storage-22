"""Paystack API client — async HTTP wrapper for the Paystack REST API."""

from __future__ import annotations

from typing import Any, Optional

import httpx

BASE_URL = "https://api.paystack.co"


class PaystackError(Exception):
    """Raised when a Paystack API call fails."""


class PaystackClient:
    """Async client for the Paystack API."""

    def __init__(self, secret_key: str) -> None:
        self._secret_key = secret_key
        self._client = httpx.AsyncClient(
            base_url=BASE_URL,
            headers={
                "Authorization": f"Bearer {secret_key}",
                "Content-Type": "application/json",
            },
            timeout=30.0,
        )

    async def close(self) -> None:
        await self._client.aclose()

    async def _request(
        self,
        method: str,
        path: str,
        json: Optional[dict] = None,
        params: Optional[dict] = None,
    ) -> dict[str, Any]:
        """Make an API request and return the parsed response."""
        resp = await self._client.request(method, path, json=json, params=params)
        data = resp.json()
        if resp.status_code >= 400 or not data.get("status"):
            msg = data.get("message", f"HTTP {resp.status_code}")
            raise PaystackError(msg)
        return data

    # --- Transactions ---

    async def initialize_transaction(
        self,
        email: str,
        amount_kobo: int,
        currency: str = "NGN",
        reference: Optional[str] = None,
        callback_url: Optional[str] = None,
    ) -> dict[str, Any]:
        """Initialize a transaction. Returns authorization URL and reference."""
        payload: dict[str, Any] = {
            "email": email,
            "amount": amount_kobo,
            "currency": currency,
        }
        if reference:
            payload["reference"] = reference
        if callback_url:
            payload["callback_url"] = callback_url
        return await self._request("POST", "/transaction/initialize", json=payload)

    async def verify_transaction(self, reference: str) -> dict[str, Any]:
        """Verify a transaction by its reference."""
        return await self._request("GET", f"/transaction/verify/{reference}")

    async def list_transactions(
        self,
        per_page: int = 20,
        page: int = 1,
        status: Optional[str] = None,
        from_date: Optional[str] = None,
        to_date: Optional[str] = None,
    ) -> dict[str, Any]:
        """List transactions with optional filters."""
        params: dict[str, Any] = {"perPage": per_page, "page": page}
        if status:
            params["status"] = status
        if from_date:
            params["from"] = from_date
        if to_date:
            params["to"] = to_date
        return await self._request("GET", "/transaction", params=params)

    async def transaction_totals(
        self,
        from_date: Optional[str] = None,
        to_date: Optional[str] = None,
    ) -> dict[str, Any]:
        """Get transaction totals and stats."""
        params: dict[str, Any] = {}
        if from_date:
            params["from"] = from_date
        if to_date:
            params["to"] = to_date
        return await self._request("GET", "/transaction/totals", params=params)

    # --- Balance ---

    async def check_balance(self) -> dict[str, Any]:
        """Check account balance."""
        return await self._request("GET", "/balance")

    # --- Customers ---

    async def create_customer(
        self,
        email: str,
        first_name: Optional[str] = None,
        last_name: Optional[str] = None,
        phone: Optional[str] = None,
    ) -> dict[str, Any]:
        """Create a new customer."""
        payload: dict[str, Any] = {"email": email}
        if first_name:
            payload["first_name"] = first_name
        if last_name:
            payload["last_name"] = last_name
        if phone:
            payload["phone"] = phone
        return await self._request("POST", "/customer", json=payload)

    async def list_customers(
        self,
        per_page: int = 20,
        page: int = 1,
    ) -> dict[str, Any]:
        """List customers."""
        params = {"perPage": per_page, "page": page}
        return await self._request("GET", "/customer", params=params)

    # --- Payment Pages ---

    async def create_payment_page(
        self,
        name: str,
        amount_kobo: Optional[int] = None,
        description: Optional[str] = None,
        slug: Optional[str] = None,
    ) -> dict[str, Any]:
        """Create a payment page (reusable payment link)."""
        payload: dict[str, Any] = {"name": name}
        if amount_kobo:
            payload["amount"] = amount_kobo
        if description:
            payload["description"] = description
        if slug:
            payload["slug"] = slug
        return await self._request("POST", "/page", json=payload)

    # --- Banks ---

    async def list_banks(
        self,
        country: str = "nigeria",
        currency: str = "NGN",
    ) -> dict[str, Any]:
        """List supported banks."""
        params = {"country": country, "currency": currency, "perPage": 100}
        return await self._request("GET", "/bank", params=params)

    async def resolve_account(
        self,
        account_number: str,
        bank_code: str,
    ) -> dict[str, Any]:
        """Resolve/verify a bank account number."""
        params = {"account_number": account_number, "bank_code": bank_code}
        return await self._request("GET", "/bank/resolve", params=params)
