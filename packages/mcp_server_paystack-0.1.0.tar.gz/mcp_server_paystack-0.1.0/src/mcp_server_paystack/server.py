"""MCP server for Paystack — tools for payments, customers, and more."""

from __future__ import annotations

import os
import sys
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from dataclasses import dataclass
from typing import Optional

from mcp.server.fastmcp import FastMCP

from mcp_server_paystack.paystack import PaystackClient, PaystackError


@dataclass
class AppContext:
    client: PaystackClient


@asynccontextmanager
async def app_lifespan(server: FastMCP) -> AsyncIterator[AppContext]:
    """Initialize and clean up the Paystack client."""
    secret_key = os.environ.get("PAYSTACK_SECRET_KEY", "")
    if not secret_key:
        print(
            "Error: PAYSTACK_SECRET_KEY environment variable is required.",
            file=sys.stderr,
        )
        print(
            "Get your test key at: https://dashboard.paystack.com/#/settings/developers",
            file=sys.stderr,
        )
        sys.exit(1)
    client = PaystackClient(secret_key)
    try:
        yield AppContext(client=client)
    finally:
        await client.close()


mcp = FastMCP("paystack", lifespan=app_lifespan)


def _get_client(ctx) -> PaystackClient:
    """Extract the Paystack client from MCP context."""
    return ctx.request_context.lifespan_context.client


def _format_amount(amount_kobo: int, currency: str = "NGN") -> str:
    """Format kobo amount as human-readable currency string."""
    return f"{currency} {amount_kobo / 100:,.2f}"


# --- Tool 1: Initialize Transaction ---


@mcp.tool()
async def paystack_initialize_transaction(
    ctx,
    email: str,
    amount: float,
    currency: str = "NGN",
    reference: str = "",
    callback_url: str = "",
) -> str:
    """Create a new payment transaction and get a checkout URL.

    Use this to accept a payment from a customer. Returns a Paystack checkout
    URL where the customer can complete the payment.

    Args:
        email: Customer's email address
        amount: Amount to charge in main currency units (e.g., 5000 for NGN 5,000)
        currency: Currency code — NGN, GHS, ZAR, USD, or KES (default: NGN)
        reference: Optional unique transaction reference
        callback_url: Optional URL to redirect to after payment
    """
    client = _get_client(ctx)
    amount_kobo = int(amount * 100)
    try:
        result = await client.initialize_transaction(
            email=email,
            amount_kobo=amount_kobo,
            currency=currency,
            reference=reference or None,
            callback_url=callback_url or None,
        )
        data = result["data"]
        return (
            f"Payment initialized successfully!\n\n"
            f"Amount: {_format_amount(amount_kobo, currency)}\n"
            f"Customer: {email}\n"
            f"Reference: {data['reference']}\n"
            f"Checkout URL: {data['authorization_url']}\n\n"
            f"Send this link to the customer to complete payment."
        )
    except PaystackError as e:
        return f"Failed to initialize transaction: {e}"


# --- Tool 2: Verify Transaction ---


@mcp.tool()
async def paystack_verify_transaction(ctx, reference: str) -> str:
    """Verify the status of a transaction by its reference.

    Use this to check if a payment was successful, failed, or is still pending.

    Args:
        reference: The unique transaction reference to verify
    """
    client = _get_client(ctx)
    try:
        result = await client.verify_transaction(reference)
        data = result["data"]
        status = data.get("status", "unknown")
        amount = data.get("amount", 0)
        currency = data.get("currency", "NGN")
        channel = data.get("channel", "unknown")
        paid_at = data.get("paid_at", "N/A")
        customer = data.get("customer", {})
        email = customer.get("email", "unknown")
        fees = data.get("fees", 0)

        status_emoji = {"success": "PAID", "failed": "FAILED", "abandoned": "ABANDONED"}.get(status, status.upper())

        return (
            f"Transaction: {reference}\n"
            f"Status: {status_emoji}\n"
            f"Amount: {_format_amount(amount, currency)}\n"
            f"Fees: {_format_amount(fees, currency)}\n"
            f"Channel: {channel}\n"
            f"Customer: {email}\n"
            f"Paid at: {paid_at}"
        )
    except PaystackError as e:
        return f"Failed to verify transaction: {e}"


# --- Tool 3: List Transactions ---


@mcp.tool()
async def paystack_list_transactions(
    ctx,
    limit: int = 10,
    page: int = 1,
    status: str = "",
    from_date: str = "",
    to_date: str = "",
) -> str:
    """List recent transactions on the Paystack account.

    Args:
        limit: Number of transactions to return (default: 10, max: 100)
        page: Page number for pagination (default: 1)
        status: Filter by status — "success", "failed", or "abandoned" (optional)
        from_date: Start date filter in ISO format, e.g. "2025-01-01" (optional)
        to_date: End date filter in ISO format, e.g. "2025-12-31" (optional)
    """
    client = _get_client(ctx)
    try:
        result = await client.list_transactions(
            per_page=min(limit, 100),
            page=page,
            status=status or None,
            from_date=from_date or None,
            to_date=to_date or None,
        )
        transactions = result.get("data", [])
        meta = result.get("meta", {})
        total = meta.get("total", 0)

        if not transactions:
            return "No transactions found."

        lines = [f"Transactions (showing {len(transactions)} of {total}):\n"]
        for txn in transactions:
            ref = txn.get("reference", "N/A")
            amt = txn.get("amount", 0)
            cur = txn.get("currency", "NGN")
            st = txn.get("status", "unknown")
            email = txn.get("customer", {}).get("email", "unknown")
            date = txn.get("paid_at") or txn.get("created_at", "N/A")
            if date and "T" in date:
                date = date.split("T")[0]
            lines.append(f"  {ref}  |  {_format_amount(amt, cur)}  |  {st}  |  {email}  |  {date}")

        return "\n".join(lines)
    except PaystackError as e:
        return f"Failed to list transactions: {e}"


# --- Tool 4: Check Balance ---


@mcp.tool()
async def paystack_check_balance(ctx) -> str:
    """Check the current Paystack account balance.

    Returns the available balance for each currency on the account.
    """
    client = _get_client(ctx)
    try:
        result = await client.check_balance()
        balances = result.get("data", [])
        if not balances:
            return "No balance information available."

        lines = ["Account Balance:\n"]
        for bal in balances:
            currency = bal.get("currency", "NGN")
            amount = bal.get("balance", 0)
            lines.append(f"  {_format_amount(amount, currency)}")
        return "\n".join(lines)
    except PaystackError as e:
        return f"Failed to check balance: {e}"


# --- Tool 5: Create Customer ---


@mcp.tool()
async def paystack_create_customer(
    ctx,
    email: str,
    first_name: str = "",
    last_name: str = "",
    phone: str = "",
) -> str:
    """Create a new customer on Paystack.

    Args:
        email: Customer's email address (required)
        first_name: Customer's first name (optional)
        last_name: Customer's last name (optional)
        phone: Customer's phone number (optional)
    """
    client = _get_client(ctx)
    try:
        result = await client.create_customer(
            email=email,
            first_name=first_name or None,
            last_name=last_name or None,
            phone=phone or None,
        )
        data = result["data"]
        code = data.get("customer_code", "N/A")
        name = f"{data.get('first_name', '')} {data.get('last_name', '')}".strip() or "N/A"
        return (
            f"Customer created successfully!\n\n"
            f"Email: {email}\n"
            f"Name: {name}\n"
            f"Customer code: {code}\n"
            f"ID: {data.get('id', 'N/A')}"
        )
    except PaystackError as e:
        return f"Failed to create customer: {e}"


# --- Tool 6: List Customers ---


@mcp.tool()
async def paystack_list_customers(
    ctx,
    limit: int = 10,
    page: int = 1,
) -> str:
    """List customers on the Paystack account.

    Args:
        limit: Number of customers to return (default: 10, max: 100)
        page: Page number for pagination (default: 1)
    """
    client = _get_client(ctx)
    try:
        result = await client.list_customers(per_page=min(limit, 100), page=page)
        customers = result.get("data", [])
        meta = result.get("meta", {})
        total = meta.get("total", 0)

        if not customers:
            return "No customers found."

        lines = [f"Customers (showing {len(customers)} of {total}):\n"]
        for cust in customers:
            email = cust.get("email", "N/A")
            code = cust.get("customer_code", "N/A")
            name = f"{cust.get('first_name', '')} {cust.get('last_name', '')}".strip() or "—"
            lines.append(f"  {email}  |  {name}  |  {code}")
        return "\n".join(lines)
    except PaystackError as e:
        return f"Failed to list customers: {e}"


# --- Tool 7: Create Payment Page ---


@mcp.tool()
async def paystack_create_payment_page(
    ctx,
    name: str,
    amount: float = 0,
    description: str = "",
    slug: str = "",
) -> str:
    """Create a reusable payment page (payment link).

    The payment page gets a permanent URL that can be shared with customers.
    If no amount is set, the customer can enter any amount.

    Args:
        name: Name of the payment page (e.g., "Premium Plan", "Donation")
        amount: Fixed amount in main currency units (e.g., 5000 for NGN 5,000). Set to 0 for flexible amount.
        description: Description shown on the payment page (optional)
        slug: Custom URL slug — page will be at paystack.com/pay/{slug} (optional)
    """
    client = _get_client(ctx)
    amount_kobo = int(amount * 100) if amount > 0 else None
    try:
        result = await client.create_payment_page(
            name=name,
            amount_kobo=amount_kobo,
            description=description or None,
            slug=slug or None,
        )
        data = result["data"]
        page_slug = data.get("slug", "")
        return (
            f"Payment page created!\n\n"
            f"Name: {name}\n"
            f"Amount: {_format_amount(amount_kobo, 'NGN') if amount_kobo else 'Flexible (customer chooses)'}\n"
            f"URL: https://paystack.com/pay/{page_slug}\n"
            f"Slug: {page_slug}"
        )
    except PaystackError as e:
        return f"Failed to create payment page: {e}"


# --- Tool 8: List Banks ---


@mcp.tool()
async def paystack_list_banks(
    ctx,
    country: str = "nigeria",
    currency: str = "NGN",
) -> str:
    """List banks supported by Paystack for a given country.

    Args:
        country: Country name — "nigeria", "ghana", "south-africa", "kenya" (default: nigeria)
        currency: Currency code — NGN, GHS, ZAR, KES (default: NGN)
    """
    client = _get_client(ctx)
    try:
        result = await client.list_banks(country=country, currency=currency)
        banks = result.get("data", [])

        if not banks:
            return f"No banks found for {country} ({currency})."

        lines = [f"Banks in {country.title()} ({len(banks)} found):\n"]
        for bank in banks[:50]:
            name = bank.get("name", "N/A")
            code = bank.get("code", "N/A")
            lines.append(f"  {name}  (code: {code})")

        if len(banks) > 50:
            lines.append(f"\n  ... and {len(banks) - 50} more")
        return "\n".join(lines)
    except PaystackError as e:
        return f"Failed to list banks: {e}"


# --- Tool 9: Resolve Account ---


@mcp.tool()
async def paystack_resolve_account(
    ctx,
    account_number: str,
    bank_code: str,
) -> str:
    """Verify a bank account number and get the account holder's name.

    Use this to confirm a bank account before making a transfer.

    Args:
        account_number: The bank account number to verify (e.g., "0123456789")
        bank_code: The bank's code (use paystack_list_banks to find codes)
    """
    client = _get_client(ctx)
    try:
        result = await client.resolve_account(
            account_number=account_number,
            bank_code=bank_code,
        )
        data = result["data"]
        return (
            f"Account verified!\n\n"
            f"Account number: {data.get('account_number', 'N/A')}\n"
            f"Account name: {data.get('account_name', 'N/A')}\n"
            f"Bank ID: {data.get('bank_id', 'N/A')}"
        )
    except PaystackError as e:
        return f"Failed to resolve account: {e}"


# --- Tool 10: Transaction Totals ---


@mcp.tool()
async def paystack_transaction_totals(
    ctx,
    from_date: str = "",
    to_date: str = "",
) -> str:
    """Get a summary of transaction statistics.

    Returns total volume, successful transactions count, and more.

    Args:
        from_date: Start date in ISO format, e.g. "2025-01-01" (optional)
        to_date: End date in ISO format, e.g. "2025-12-31" (optional)
    """
    client = _get_client(ctx)
    try:
        result = await client.transaction_totals(
            from_date=from_date or None,
            to_date=to_date or None,
        )
        data = result["data"]
        total_volume = data.get("total_volume", 0)
        total_txns = data.get("total_transactions", 0)
        pending = data.get("pending_transfers", 0)

        return (
            f"Transaction Summary:\n\n"
            f"Total volume: {_format_amount(total_volume)}\n"
            f"Total transactions: {total_txns:,}\n"
            f"Pending transfers: {pending:,}"
        )
    except PaystackError as e:
        return f"Failed to get transaction totals: {e}"


def main() -> None:
    """Entry point for the MCP server."""
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
