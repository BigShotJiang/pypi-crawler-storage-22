"""Tests for the Paystack API client."""

import pytest
import httpx
from unittest.mock import AsyncMock, patch

from mcp_server_paystack.paystack import PaystackClient, PaystackError


@pytest.fixture
def client():
    return PaystackClient("sk_test_fake_key")


# --- Helper to mock responses ---

def mock_response(data, status_code=200, api_status=True, message="Success"):
    resp = AsyncMock(spec=httpx.Response)
    resp.status_code = status_code
    resp.json.return_value = {"status": api_status, "message": message, "data": data}
    return resp


# --- Initialize Transaction ---

@pytest.mark.asyncio
async def test_initialize_transaction(client):
    mock = mock_response({
        "authorization_url": "https://checkout.paystack.com/abc123",
        "access_code": "abc123",
        "reference": "ref_001",
    })
    with patch.object(client._client, "request", return_value=mock):
        result = await client.initialize_transaction("test@email.com", 500000)
        assert result["data"]["authorization_url"] == "https://checkout.paystack.com/abc123"
        assert result["data"]["reference"] == "ref_001"


@pytest.mark.asyncio
async def test_initialize_transaction_with_options(client):
    mock = mock_response({
        "authorization_url": "https://checkout.paystack.com/xyz",
        "access_code": "xyz",
        "reference": "custom_ref",
    })
    with patch.object(client._client, "request", return_value=mock):
        result = await client.initialize_transaction(
            "test@email.com", 100000, currency="GHS", reference="custom_ref"
        )
        assert result["data"]["reference"] == "custom_ref"


# --- Verify Transaction ---

@pytest.mark.asyncio
async def test_verify_transaction(client):
    mock = mock_response({
        "status": "success",
        "amount": 500000,
        "currency": "NGN",
        "channel": "card",
        "customer": {"email": "test@email.com"},
        "paid_at": "2025-01-15T10:00:00.000Z",
        "fees": 7500,
    })
    with patch.object(client._client, "request", return_value=mock):
        result = await client.verify_transaction("ref_001")
        assert result["data"]["status"] == "success"
        assert result["data"]["amount"] == 500000


# --- List Transactions ---

@pytest.mark.asyncio
async def test_list_transactions(client):
    mock = mock_response([
        {"reference": "ref_001", "amount": 500000, "status": "success"},
        {"reference": "ref_002", "amount": 100000, "status": "failed"},
    ])
    mock.json.return_value["meta"] = {"total": 2, "perPage": 20, "page": 1}
    with patch.object(client._client, "request", return_value=mock):
        result = await client.list_transactions(per_page=10)
        assert len(result["data"]) == 2


@pytest.mark.asyncio
async def test_list_transactions_with_filters(client):
    mock = mock_response([])
    mock.json.return_value["meta"] = {"total": 0}
    with patch.object(client._client, "request", return_value=mock):
        result = await client.list_transactions(status="success", from_date="2025-01-01")
        assert result["data"] == []


# --- Transaction Totals ---

@pytest.mark.asyncio
async def test_transaction_totals(client):
    mock = mock_response({
        "total_volume": 5000000,
        "total_transactions": 150,
        "pending_transfers": 3,
    })
    with patch.object(client._client, "request", return_value=mock):
        result = await client.transaction_totals()
        assert result["data"]["total_transactions"] == 150


# --- Check Balance ---

@pytest.mark.asyncio
async def test_check_balance(client):
    mock = mock_response([{"currency": "NGN", "balance": 12500000}])
    with patch.object(client._client, "request", return_value=mock):
        result = await client.check_balance()
        assert result["data"][0]["balance"] == 12500000


# --- Create Customer ---

@pytest.mark.asyncio
async def test_create_customer(client):
    mock = mock_response({
        "email": "john@email.com",
        "customer_code": "CUS_abc123",
        "id": 12345,
        "first_name": "John",
        "last_name": "Doe",
    })
    with patch.object(client._client, "request", return_value=mock):
        result = await client.create_customer("john@email.com", first_name="John", last_name="Doe")
        assert result["data"]["customer_code"] == "CUS_abc123"


@pytest.mark.asyncio
async def test_create_customer_email_only(client):
    mock = mock_response({
        "email": "minimal@email.com",
        "customer_code": "CUS_min123",
        "id": 99,
    })
    with patch.object(client._client, "request", return_value=mock):
        result = await client.create_customer("minimal@email.com")
        assert result["data"]["email"] == "minimal@email.com"


# --- List Customers ---

@pytest.mark.asyncio
async def test_list_customers(client):
    mock = mock_response([
        {"email": "a@test.com", "customer_code": "CUS_a"},
        {"email": "b@test.com", "customer_code": "CUS_b"},
    ])
    mock.json.return_value["meta"] = {"total": 2}
    with patch.object(client._client, "request", return_value=mock):
        result = await client.list_customers()
        assert len(result["data"]) == 2


# --- Create Payment Page ---

@pytest.mark.asyncio
async def test_create_payment_page(client):
    mock = mock_response({
        "id": 1,
        "name": "Test Page",
        "slug": "test-page",
    })
    with patch.object(client._client, "request", return_value=mock):
        result = await client.create_payment_page("Test Page", amount_kobo=500000)
        assert result["data"]["slug"] == "test-page"


@pytest.mark.asyncio
async def test_create_payment_page_flexible(client):
    mock = mock_response({
        "id": 2,
        "name": "Donation",
        "slug": "donation",
    })
    with patch.object(client._client, "request", return_value=mock):
        result = await client.create_payment_page("Donation")
        assert result["data"]["name"] == "Donation"


# --- List Banks ---

@pytest.mark.asyncio
async def test_list_banks(client):
    mock = mock_response([
        {"name": "Access Bank", "code": "044"},
        {"name": "GTBank", "code": "058"},
    ])
    with patch.object(client._client, "request", return_value=mock):
        result = await client.list_banks()
        assert len(result["data"]) == 2
        assert result["data"][0]["name"] == "Access Bank"


# --- Resolve Account ---

@pytest.mark.asyncio
async def test_resolve_account(client):
    mock = mock_response({
        "account_number": "0123456789",
        "account_name": "JOHN DOE",
        "bank_id": 9,
    })
    with patch.object(client._client, "request", return_value=mock):
        result = await client.resolve_account("0123456789", "044")
        assert result["data"]["account_name"] == "JOHN DOE"


# --- Error Handling ---

@pytest.mark.asyncio
async def test_api_error(client):
    resp = AsyncMock(spec=httpx.Response)
    resp.status_code = 401
    resp.json.return_value = {"status": False, "message": "Invalid key"}
    with patch.object(client._client, "request", return_value=resp):
        with pytest.raises(PaystackError, match="Invalid key"):
            await client.check_balance()


@pytest.mark.asyncio
async def test_api_error_status_false(client):
    resp = AsyncMock(spec=httpx.Response)
    resp.status_code = 200
    resp.json.return_value = {"status": False, "message": "Duplicate reference"}
    with patch.object(client._client, "request", return_value=resp):
        with pytest.raises(PaystackError, match="Duplicate reference"):
            await client.initialize_transaction("test@email.com", 1000)


# --- Amount Conversion (Integration-level) ---

def test_amount_format():
    from mcp_server_paystack.server import _format_amount
    assert _format_amount(500000, "NGN") == "NGN 5,000.00"
    assert _format_amount(100, "NGN") == "NGN 1.00"
    assert _format_amount(0, "GHS") == "GHS 0.00"
    assert _format_amount(1234567, "USD") == "USD 12,345.67"
