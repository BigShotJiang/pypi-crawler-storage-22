"""
Entry point for mcp-sharepoint module
"""
import asyncio
from . import main

if __name__ == "__main__":
    asyncio.run(main())
