"""
SousChef Visual Migration Planning Interface.

This module provides a web-based interface for Chef to Ansible migration planning
and visualization using Streamlit.
"""

__version__ = "0.1.0"
