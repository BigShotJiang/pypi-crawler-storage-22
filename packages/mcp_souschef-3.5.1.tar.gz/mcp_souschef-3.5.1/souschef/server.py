"""SousChef MCP Server - Chef to Ansible conversion assistant."""

# codeql[py/unused-import]: Intentional re-exports for MCP tools and test compatibility

import ast
import json
import os
import re
from pathlib import Path
from typing import Any

import yaml
from mcp.server import FastMCP

# Import assessment functions with aliases to avoid name conflicts
from souschef.assessment import (
    analyse_cookbook_dependencies as _analyse_cookbook_dependencies,
)
from souschef.assessment import (
    assess_chef_migration_complexity as _assess_chef_migration_complexity,
)
from souschef.assessment import generate_migration_plan as _generate_migration_plan
from souschef.assessment import generate_migration_report as _generate_migration_report
from souschef.assessment import (
    parse_chef_migration_assessment as _parse_chef_migration_assessment,
)
from souschef.assessment import validate_conversion as _validate_conversion

# Import extracted modules
# Import private helper functions still used in server.py
from souschef.converters.habitat import (  # noqa: F401, codeql[py/unused-import]
    _add_service_build,
    _add_service_dependencies,
    _add_service_environment,
    _add_service_ports,
    _add_service_volumes,
    _build_compose_service,
    _extract_default_port,
    _map_habitat_deps_to_apt,
    _needs_data_volume,
    _validate_docker_image_name,
    _validate_docker_network_name,
)
from souschef.converters.habitat import (
    convert_habitat_to_dockerfile as _convert_habitat_to_dockerfile,
)
from souschef.converters.habitat import (
    generate_compose_from_habitat as _generate_compose_from_habitat,
)

# Import playbook converter functions
# Re-exports of playbook internal functions for backward compatibility (tests)
from souschef.converters.playbook import (  # noqa: F401, codeql[py/unused-import]
    _add_general_recommendations,
    _convert_chef_block_to_ansible,
    _convert_chef_condition_to_ansible,
    _convert_guards_to_when_conditions,
    _create_handler,
    _create_handler_with_timing,
    _determine_query_complexity,
    _extract_chef_guards,
    _extract_enhanced_notifications,
    _extract_guard_patterns,
    _extract_search_patterns_from_cookbook,
    _extract_search_patterns_from_file,
    _find_search_patterns_in_content,
    _generate_ansible_inventory_from_search,
    _generate_group_name_from_condition,
    _generate_inventory_script_content,
    _get_current_timestamp,
    _parse_chef_search_query,
    _parse_guard_array,
    _parse_search_condition,
    _process_subscribes,
)
from souschef.converters.playbook import (
    analyse_chef_search_patterns as _analyse_chef_search_patterns,
)
from souschef.converters.playbook import (
    convert_chef_search_to_inventory as _convert_chef_search_to_inventory,
)
from souschef.converters.playbook import (
    generate_dynamic_inventory_script as _generate_dynamic_inventory_script,
)
from souschef.converters.playbook import get_chef_nodes as _get_chef_nodes
from souschef.converters.resource import (  # noqa: F401, codeql[py/unused-import]
    _convert_chef_resource_to_ansible,
    _format_ansible_task,
    _get_file_params,
    _get_service_params,
)
from souschef.converters.resource import (
    convert_resource_to_task as _convert_resource_to_task,
)

# Re-exports for backward compatibility (used by tests) - DO NOT REMOVE
# These imports are intentionally exposed for external test access
from souschef.core.constants import (  # noqa: F401, codeql[py/unused-import]
    ACTION_TO_STATE,
    ANSIBLE_SERVICE_MODULE,
    ERROR_PREFIX,
    REGEX_RESOURCE_BRACKET,
    RESOURCE_MAPPINGS,
)

# Import core utilities
from souschef.core.errors import format_error_with_context
from souschef.core.logging import configure_logging
from souschef.core.path_utils import (  # noqa: F401, codeql[py/unused-import]
    _ensure_within_base_path,
    _normalize_path,
    _safe_join,
    _validated_candidate,
    safe_glob,
    safe_read_text,
    safe_write_text,
)

# Re-exports for backward compatibility (used by tests) - DO NOT REMOVE
# These imports are intentionally exposed for external test access
from souschef.core.ruby_utils import (
    _normalize_ruby_value,  # noqa: F401, codeql[py/unused-import]
)

# Re-exports for backward compatibility (used by tests) - DO NOT REMOVE
# These imports are intentionally exposed for external test access
from souschef.core.validation import (  # noqa: F401, codeql[py/unused-import]
    ValidationCategory,
    ValidationEngine,
    ValidationLevel,
    ValidationResult,
)

# Explicit re-exports for language servers and type checkers
# These names are intentionally available from souschef.server
__all__ = [
    "ValidationCategory",
    "ValidationEngine",
    "ValidationLevel",
    "ValidationResult",
]

# Re-exports for backward compatibility (used by tests)
# These are imported and re-exported intentionally
# Import validation framework
# Re-exports of deployment internal functions for backward compatibility (tests)
# Public re-exports of deployment functions for test backward compatibility
# Note: MCP tool wrappers exist for some of these, but tests import directly
# Import converters.template functions
from souschef.converters.template import (
    convert_template_with_ai as _convert_template_with_ai,
)
from souschef.deployment import (  # noqa: F401, codeql[py/unused-import]
    _analyse_cookbook_for_awx,
    _analyse_cookbooks_directory,
    _detect_deployment_patterns_in_recipe,
    _extract_cookbook_attributes,
    _extract_cookbook_dependencies,
    _format_chef_resources_analysis,
    _format_cookbook_analysis,
    _format_deployment_patterns,
    _generate_deployment_migration_recommendations,
    _generate_survey_fields_from_attributes,
    _parse_chef_runlist,
    _recommend_ansible_strategies,
    analyse_chef_application_patterns,
)
from souschef.deployment import (
    convert_chef_deployment_to_ansible_strategy as _convert_chef_deployment_to_ansible_strategy,
)
from souschef.deployment import (
    generate_awx_inventory_source_from_chef as _generate_awx_inventory_source_from_chef,
)
from souschef.deployment import (
    generate_awx_job_template_from_cookbook as _generate_awx_job_template_from_cookbook,
)
from souschef.deployment import (
    generate_awx_project_from_cookbooks as _generate_awx_project_from_cookbooks,
)
from souschef.deployment import (
    generate_awx_workflow_from_chef_runlist as _generate_awx_workflow_from_chef_runlist,
)
from souschef.deployment import (
    generate_blue_green_deployment_playbook as _generate_blue_green_deployment_playbook,
)
from souschef.deployment import (
    generate_canary_deployment_strategy as _generate_canary_deployment_strategy,
)

# Import filesystem operations
from souschef.filesystem import list_directory as _list_directory
from souschef.filesystem import read_file as _read_file

# Import parser functions
from souschef.parsers.attributes import (  # noqa: F401, codeql[py/unused-import]
    _extract_attributes,
    _format_attributes,
    _format_resolved_attributes,
    _get_precedence_level,
    _resolve_attribute_precedence,
)
from souschef.parsers.attributes import parse_attributes as _parse_attributes

# Import Habitat parser internal functions for backward compatibility
from souschef.parsers.habitat import (  # noqa: F401, codeql[py/unused-import]
    _extract_plan_array,
    _extract_plan_exports,
    _extract_plan_function,
    _extract_plan_var,
    _update_quote_state,
)
from souschef.parsers.habitat import parse_habitat_plan as _parse_habitat_plan

# Re-export InSpec internal functions for backward compatibility (tests)
from souschef.parsers.inspec import (  # noqa: F401, codeql[py/unused-import]
    _convert_inspec_to_ansible_assert,
    _convert_inspec_to_goss,
    _convert_inspec_to_serverspec,
    _convert_inspec_to_testinfra,
    _extract_inspec_describe_blocks,
    _generate_inspec_from_resource,
    _parse_inspec_control,
)
from souschef.parsers.inspec import convert_inspec_to_test as _convert_inspec_test
from souschef.parsers.inspec import parse_inspec_profile as _parse_inspec
from souschef.parsers.metadata import (
    _extract_metadata,  # noqa: F401, codeql[py/unused-import]
    _format_cookbook_structure,  # noqa: F401, codeql[py/unused-import]
    _format_metadata,  # noqa: F401, codeql[py/unused-import]
)
from souschef.parsers.metadata import (
    list_cookbook_structure as _list_cookbook_structure,
)
from souschef.parsers.metadata import (
    parse_cookbook_metadata as _parse_cookbook_metadata,
)
from souschef.parsers.metadata import read_cookbook_metadata as _read_cookbook_metadata
from souschef.parsers.recipe import (
    _extract_conditionals,  # noqa: F401, codeql[py/unused-import]
    _extract_resources,  # noqa: F401, codeql[py/unused-import]
    _format_resources,  # noqa: F401, codeql[py/unused-import]
)
from souschef.parsers.recipe import parse_recipe as _parse_recipe

# Re-exports for backward compatibility (used by tests) - DO NOT REMOVE
# These imports are intentionally exposed for external test access
from souschef.parsers.resource import (
    _extract_resource_actions,  # noqa: F401, codeql[py/unused-import]
    _extract_resource_properties,  # noqa: F401, codeql[py/unused-import]
)
from souschef.parsers.resource import parse_custom_resource as _parse_custom_resource

# Import internal functions for backward compatibility (used by tests)
from souschef.parsers.template import (  # noqa: F401, codeql[py/unused-import]
    _convert_erb_to_jinja2,
    _extract_code_block_variables,
    _extract_heredoc_strings,
    _extract_node_attribute_path,
    _extract_output_variables,
    _extract_template_variables,
    _strip_ruby_comments,
)
from souschef.parsers.template import parse_template as _parse_template

# Import UI helper functions for MCP exposure
from souschef.ui.pages.chef_server_settings import (
    _validate_chef_server_connection,
)

# Backward compatibility re-exports without underscore prefix (for tests)
# noinspection PyUnusedLocal
convert_chef_deployment_to_ansible_strategy = (  # noqa: F401
    _convert_chef_deployment_to_ansible_strategy
)
generate_awx_inventory_source_from_chef = (  # noqa: F401
    _generate_awx_inventory_source_from_chef
)
generate_awx_job_template_from_cookbook = (  # noqa: F401
    _generate_awx_job_template_from_cookbook
)
generate_awx_project_from_cookbooks = _generate_awx_project_from_cookbooks  # noqa: F401
generate_awx_workflow_from_chef_runlist = (  # noqa: F401
    _generate_awx_workflow_from_chef_runlist
)
generate_blue_green_deployment_playbook = (  # noqa: F401
    _generate_blue_green_deployment_playbook
)
generate_canary_deployment_strategy = (  # noqa: F401
    _generate_canary_deployment_strategy
)

# Create a new FastMCP server
mcp = FastMCP("souschef")

# File constants
METADATA_RB = "metadata.rb"

# File constants
METADATA_RB = "metadata.rb"

# Validation Framework Classes


@mcp.tool()
def parse_template(path: str) -> str:
    """
    Parse a Chef ERB template file and convert to Jinja2.

    Args:
        path: Path to the ERB template file.

    Returns:
        JSON string with extracted variables and Jinja2-converted template.

    """
    try:
        path = str(_normalize_path(path))
    except ValueError as e:
        return format_error_with_context(e, "validating template path", path)
    return _parse_template(path)


@mcp.tool()
def parse_custom_resource(path: str) -> str:
    """
    Parse a Chef custom resource or LWRP file.

    Args:
        path: Path to the custom resource (.rb) file.

    Returns:
        JSON string with extracted properties, actions, and metadata.

    """
    try:
        path = str(_normalize_path(path))
    except ValueError as e:
        return format_error_with_context(e, "validating resource path", path)
    return _parse_custom_resource(path)


@mcp.tool()
def list_directory(path: str) -> list[str] | str:
    """
    List the contents of a directory.

    Args:
        path: The path to the directory to list.

    Returns:
        A list of filenames in the directory, or an error message.

    """
    try:
        path = str(_normalize_path(path))
    except ValueError as e:
        return format_error_with_context(e, "validating directory path", path)
    result: list[str] | str = _list_directory(path)
    return result


@mcp.tool()
def read_file(path: str) -> str:
    """
    Read the contents of a file.

    Args:
        path: The path to the file to read.

    Returns:
        The contents of the file, or an error message.

    """
    try:
        path = str(_normalize_path(path))
    except ValueError as e:
        return format_error_with_context(e, "validating file path", path)
    result: str = _read_file(path)
    return result


@mcp.tool()
def read_cookbook_metadata(path: str) -> str:
    """
    Parse Chef cookbook metadata.rb file.

    Args:
        path: Path to the metadata.rb file.

    Returns:
        Formatted string with extracted metadata.

    """
    try:
        path = str(_normalize_path(path))
    except ValueError as e:
        return format_error_with_context(e, "validating metadata path", path)
    return _read_cookbook_metadata(path)


@mcp.tool()
def parse_cookbook_metadata(path: str) -> dict[str, str | list[str]]:
    """
    Parse Chef cookbook metadata.rb file and return as dictionary.

    Args:
        path: Path to the metadata.rb file.

    Returns:
        Dictionary containing extracted metadata fields.

    """
    try:
        path = str(_normalize_path(path))
    except ValueError as e:
        return {"error": str(e)}
    return _parse_cookbook_metadata(path)


@mcp.tool()
def parse_recipe(path: str) -> str:
    """
    Parse a Chef recipe file and extract resources.

    Args:
        path: Path to the recipe (.rb) file.

    Returns:
        Formatted string with extracted Chef resources and their properties.

    """
    try:
        path = str(_normalize_path(path))
    except ValueError as e:
        return format_error_with_context(e, "validating recipe path", path)
    return _parse_recipe(path)


@mcp.tool()
def parse_attributes(path: str, resolve_precedence: bool = True) -> str:
    """
    Parse a Chef attributes file and extract attribute definitions.

    Analyzes attributes file and extracts all attribute definitions with their
    precedence levels and values. By default, resolves precedence conflicts
    to show the winning value for each attribute path.

    Chef attribute precedence (lowest to highest):
    1. default - Normal default value
    2. force_default - Forced default, higher than regular default
    3. normal - Normal attribute set by cookbook
    4. override - Override values
    5. force_override - Forced override, cannot be overridden
    6. automatic - Automatically detected by Ohai (highest precedence)

    Args:
        path: Path to the attributes (.rb) file.
        resolve_precedence: If True (default), resolves precedence conflicts
            and shows only winning values. If False, shows all attributes.

    Returns:
        Formatted string with extracted attributes.

    """
    try:
        path = str(_normalize_path(path))
    except ValueError as e:
        return format_error_with_context(e, "validating attributes path", path)
    return _parse_attributes(path, resolve_precedence)


@mcp.tool()
def list_cookbook_structure(path: str) -> str:
    """
    List the structure of a Chef cookbook directory.

    Args:
        path: Path to the cookbook root directory.

    Returns:
        Formatted string showing the cookbook structure.

    """
    try:
        path = str(_normalize_path(path))
    except ValueError as e:
        return format_error_with_context(e, "validating cookbook path", path)
    return _list_cookbook_structure(path)


@mcp.tool()
def convert_resource_to_task(
    resource_type: str, resource_name: str, action: str = "create", properties: str = ""
) -> str:
    """
    Convert a Chef resource to an Ansible task.

    Args:
        resource_type: The Chef resource type (e.g., 'package', 'service').
        resource_name: The name of the resource.
        action: The Chef action (e.g., 'install', 'start', 'create').
        properties: Additional resource properties as a string representation.

    Returns:
        YAML representation of the equivalent Ansible task.

    """
    return _convert_resource_to_task(resource_type, resource_name, action, properties)


def _extract_resource_subscriptions(
    resource: dict[str, str], raw_content: str
) -> list[dict[str, str]]:
    """
    Extract subscription information with timing constraints for a resource.

    Args:
        resource: Resource dictionary.
        raw_content: Raw recipe content.

    Returns:
        List of subscription dictionaries with timing information.

    """
    subscriptions = []

    # Enhanced subscribes pattern that captures timing
    subscribes_pattern = re.compile(
        r'subscribes\s+:(\w+),\s*[\'"]([^\'"]+)[\'"](?:\s*,\s*:(\w+))?', re.IGNORECASE
    )

    # Find all subscribes declarations
    subscribes_matches = subscribes_pattern.findall(raw_content)

    for action, target, timing in subscribes_matches:
        # Parse target like 'service[nginx]' or 'template[/etc/nginx/nginx.conf]'
        target_match = re.match(REGEX_RESOURCE_BRACKET, target)
        if target_match:
            target_type = target_match.group(1)
            target_name = target_match.group(2)

            # Check if this resource is what the subscription refers to
            if resource["type"] == target_type and resource["name"] == target_name:
                subscriptions.append(
                    {
                        "action": action,
                        "resource_type": target_type,
                        "resource_name": target_name,
                        "timing": timing
                        or "delayed",  # Default to delayed if not specified
                    }
                )

    return subscriptions


def _parse_controls_from_directory(profile_path: Path) -> list[dict[str, Any]]:
    """
    Parse all control files from an InSpec profile directory.

    Args:
        profile_path: Path to the InSpec profile directory.

    Returns:
        List of parsed controls.

    Raises:
        FileNotFoundError: If controls directory doesn't exist.
        RuntimeError: If error reading control files.

    """
    controls_dir = _safe_join(profile_path, "controls")
    if not controls_dir.exists():
        raise FileNotFoundError(f"No controls directory found in {profile_path}")

    controls = []
    for control_file in safe_glob(controls_dir, "*.rb", profile_path):
        try:
            content = safe_read_text(control_file, profile_path)
            file_controls = _parse_inspec_control(content)
            for ctrl in file_controls:
                ctrl["file"] = str(control_file.relative_to(profile_path))
            controls.extend(file_controls)
        except Exception as e:
            raise RuntimeError(f"Error reading {control_file}: {e}") from e

    return controls


def _parse_controls_from_file(profile_path: Path) -> list[dict[str, Any]]:
    """
    Parse controls from a single InSpec control file.

    Args:
        profile_path: Path to the control file.

    Returns:
        List of parsed controls.

    Raises:
        RuntimeError: If error reading the file.

    """
    try:
        content = safe_read_text(profile_path, profile_path.parent)
        controls = _parse_inspec_control(content)
        for ctrl in controls:
            ctrl["file"] = profile_path.name
        return controls
    except Exception as e:
        raise RuntimeError(f"Error reading file: {e}") from e


@mcp.tool()
def parse_inspec_profile(path: str) -> str:
    """
    Parse an InSpec profile and extract controls.

    Args:
        path: Path to InSpec profile directory or control file (.rb).

    Returns:
        JSON string with parsed controls, or error message.

    """
    try:
        path = str(_normalize_path(path))
    except ValueError as e:
        return format_error_with_context(e, "validating InSpec path", path)
    return _parse_inspec(path)


@mcp.tool()
def convert_inspec_to_test(inspec_path: str, output_format: str = "testinfra") -> str:
    """
    Convert InSpec controls to test framework format.

    Args:
        inspec_path: Path to InSpec profile or control file.
        output_format: Output format ('testinfra', 'ansible_assert', 'serverspec', or 'goss').

    Returns:
        Converted test code or error message.

    """
    try:
        inspec_path = str(_normalize_path(inspec_path))
    except ValueError as e:
        return format_error_with_context(e, "validating InSpec path", inspec_path)
    return _convert_inspec_test(inspec_path, output_format)


def _extract_resources_from_parse_result(parse_result: str) -> list[dict[str, Any]]:
    """
    Extract resource data from recipe parse result.

    Args:
        parse_result: Output from parse_recipe function.

    Returns:
        List of resource dictionaries with type, name, and properties.

    """
    resources = []
    current_resource: dict[str, Any] = {}

    for line in parse_result.split("\n"):
        line = line.strip()

        if line.startswith("Resource"):
            if current_resource:
                resources.append(current_resource)
            current_resource = {}
        elif line.startswith("Type:"):
            current_resource["type"] = line.split(":", 1)[1].strip()
        elif line.startswith("Name:"):
            current_resource["name"] = line.split(":", 1)[1].strip()
        elif line.startswith("Properties:"):
            # Parse properties dict
            props_str = line.split(":", 1)[1].strip()
            try:
                current_resource["properties"] = ast.literal_eval(props_str)
            except Exception:
                current_resource["properties"] = {}

    if current_resource:
        resources.append(current_resource)

    return resources


@mcp.tool()
def generate_inspec_from_recipe(recipe_path: str) -> str:
    """
    Generate InSpec controls from a Chef recipe.

    Args:
        recipe_path: Path to Chef recipe file.

    Returns:
        InSpec control code or error message.

    """
    try:
        # Validate and normalize path
        recipe_path = str(_normalize_path(recipe_path))

        # First parse the recipe
        recipe_result: str = parse_recipe(recipe_path)

        if recipe_result.startswith(ERROR_PREFIX):
            return recipe_result

        # Extract resources from parsed output
        resources = _extract_resources_from_parse_result(recipe_result)

        if not resources:
            return "Error: No resources found in recipe"

        # Generate InSpec controls
        controls = [
            "# InSpec controls generated from Chef recipe",
            f"# Source: {recipe_path}",
            "",
        ]

        for resource in resources:
            if "type" in resource and "name" in resource:
                control_code: str = _generate_inspec_from_resource(
                    resource["type"],
                    resource["name"],
                    resource.get("properties", {}),
                )
                controls.append(control_code)

        return "\n".join(controls)

    except Exception as e:
        return format_error_with_context(
            e, "generating InSpec controls from recipe", recipe_path
        )


@mcp.tool()
def convert_chef_databag_to_vars(
    databag_content: str,
    databag_name: str,
    item_name: str = "default",
    is_encrypted: bool = False,
    target_scope: str = "group_vars",
) -> str:
    """
    Convert Chef data bag to Ansible variables format.

    Args:
        databag_content: JSON content of the Chef data bag
        databag_name: Name of the data bag
        item_name: Name of the data bag item (default: "default")
        is_encrypted: Whether the data bag is encrypted
        target_scope: Variable scope ("group_vars", "host_vars", or "playbook")

    Returns:
        Ansible variables YAML content or vault file structure

    """
    try:
        # Validate inputs
        if not databag_content or not databag_content.strip():
            return (
                "Error: Databag content cannot be empty\n\n"
                "Suggestion: Provide valid JSON content from a Chef data bag"
            )

        if not databag_name or not databag_name.strip():
            return (
                "Error: Databag name cannot be empty\n\n"
                "Suggestion: Provide a valid data bag name"
            )

        valid_scopes = ["group_vars", "host_vars", "playbook"]
        if target_scope not in valid_scopes:
            return (
                f"Error: Invalid target scope '{target_scope}'\n\n"
                f"Suggestion: Use one of {', '.join(valid_scopes)}"
            )

        # Parse the data bag content
        try:
            parsed_databag = json.loads(databag_content)
        except json.JSONDecodeError as e:
            return (
                f"Error: Invalid JSON format in data bag: {e}\n\n"
                "Suggestion: Ensure the databag content is valid JSON"
            )

        # Convert to Ansible variables format
        ansible_vars = _convert_databag_to_ansible_vars(
            parsed_databag, databag_name, item_name, is_encrypted
        )

        if is_encrypted:
            # Generate vault file structure
            vault_content = _generate_vault_content(ansible_vars, databag_name)
            return f"""# Encrypted data bag converted to Ansible Vault
# Original: data_bags/{databag_name}/{item_name}.json
# Usage: ansible-vault encrypt {target_scope}/{databag_name}_vault.yml

{vault_content}

---
# Instructions:
# 1. Save this content to {target_scope}/{databag_name}_vault.yml
# 2. Encrypt with: ansible-vault encrypt {target_scope}/{databag_name}_vault.yml
# 3. Reference in playbooks with: vars_files:
#    - "{target_scope}/{databag_name}_vault.yml"
"""
        else:
            # Generate regular YAML variables
            yaml_content = yaml.dump(ansible_vars, default_flow_style=False, indent=2)
            # yaml.dump adds a trailing newline, so we strip it and add back a single newline
            return f"""---
# Chef data bag converted to Ansible variables
# Original: data_bags/{databag_name}/{item_name}.json
# Target: {target_scope}/{databag_name}.yml

{yaml_content.rstrip()}
"""
    except Exception as e:
        return format_error_with_context(
            e, f"converting data bag '{databag_name}' to Ansible variables"
        )


@mcp.tool()
def _validate_databags_directory(
    databags_directory: str,
) -> tuple[Path | None, str | None]:
    """
    Validate databags directory input.

    Args:
        databags_directory: Path to the data bags directory.

    Returns:
        Tuple of (normalized_path, error_message).
        If validation succeeds: (Path, None)
        If validation fails: (None, error_message)

    """
    if not databags_directory or not databags_directory.strip():
        return None, (
            "Error: Databags directory path cannot be empty\n\n"
            "Suggestion: Provide the path to your Chef data_bags directory"
        )

    databags_path = _normalize_path(databags_directory)
    if not databags_path.exists():
        return None, (
            f"Error: Data bags directory not found: {databags_directory}\n\n"
            "Suggestion: Check that the path is correct and the directory exists"
        )

    if not databags_path.is_dir():
        return None, (
            f"Error: Path is not a directory: {databags_directory}\n\n"
            "Suggestion: Provide a path to the data_bags directory"
        )

    return databags_path, None


def _convert_databag_item(
    item_file, databag_name: str, output_directory: str, base_path: Path
) -> dict:
    """Convert a single databag item file to Ansible format."""
    item_name = item_file.stem

    try:
        content = safe_read_text(item_file, base_path)

        # Detect if encrypted
        is_encrypted = _detect_encrypted_databag(content)

        # Convert to Ansible format
        result = convert_chef_databag_to_vars(
            content, databag_name, item_name, is_encrypted, output_directory
        )

        vault_suffix = "_vault" if is_encrypted else ""
        target_file = f"{output_directory}/{databag_name}{vault_suffix}.yml"

        return {
            "databag": databag_name,
            "item": item_name,
            "encrypted": is_encrypted,
            "target_file": target_file,
            "content": result,
        }

    except Exception as e:
        return {"databag": databag_name, "item": item_name, "error": str(e)}


def _process_databag_directory(
    databag_dir, output_directory: str, base_path: Path
) -> list[dict]:
    """Process all items in a single databag directory."""
    results = []
    databag_name = databag_dir.name

    for item_file in safe_glob(databag_dir, "*.json", base_path):
        result = _convert_databag_item(
            item_file, databag_name, output_directory, base_path
        )
        results.append(result)

    return results


def generate_ansible_vault_from_databags(
    databags_directory: str,
    output_directory: str = "group_vars",
) -> str:
    """
    Generate Ansible Vault files from Chef data bags directory.

    Args:
        databags_directory: Path to Chef data_bags directory
        output_directory: Target directory for Ansible variables (group_vars/host_vars)

    Returns:
        Summary of converted data bags and instructions

    """
    try:
        # Validate inputs
        databags_path, error = _validate_databags_directory(databags_directory)
        if error:
            assert isinstance(error, str), "error must be string when present"
            return error

        assert databags_path is not None, (
            "databags_path must be non-None after successful validation"
        )

        conversion_results = []

        # Process each data bag directory
        for databag_dir in databags_path.iterdir():  # nosonar
            if not databag_dir.is_dir():
                continue

            results = _process_databag_directory(
                databag_dir, output_directory, databags_path
            )
            conversion_results.extend(results)

        # Generate summary and file structure
        return _generate_databag_conversion_summary(
            conversion_results, output_directory
        )

    except Exception as e:
        return format_error_with_context(
            e, "processing data bags directory", databags_directory
        )


@mcp.tool()
def analyse_chef_databag_usage(cookbook_path: str, databags_path: str = "") -> str:
    """
    Analyse Chef cookbook for data bag usage and provide migration recommendations.

    Args:
        cookbook_path: Path to Chef cookbook
        databags_path: Optional path to data_bags directory for cross-reference

    Returns:
        Analysis of data bag usage and migration recommendations

    """
    cookbook_path = str(_normalize_path(cookbook_path))
    if databags_path:
        databags_path = str(_normalize_path(databags_path))
    try:
        cookbook = _normalize_path(cookbook_path)
        if not cookbook.exists():
            return f"Error: Cookbook path not found: {cookbook_path}"

        # Find data bag usage patterns
        usage_patterns = _extract_databag_usage_from_cookbook(cookbook)

        # Analyze data bags structure if provided
        databag_structure = {}
        if databags_path:
            databags = _normalize_path(databags_path)
            if databags.exists():
                databag_structure = _analyse_databag_structure(databags)

        # Generate recommendations
        recommendations = _generate_databag_migration_recommendations(
            usage_patterns, databag_structure
        )

        return f"""# Chef Data Bag Usage Analysis

## Data Bag Usage Patterns Found:
{_format_usage_patterns(usage_patterns)}

## Data Bag Structure Analysis:
{_format_databag_structure(databag_structure)}

## Migration Recommendations:
{recommendations}

## Conversion Steps:
1. Use convert_chef_databag_to_vars for individual data bags
2. Use generate_ansible_vault_from_databags for bulk conversion
3. Update playbooks to reference new variable files
4. Encrypt sensitive data with ansible-vault
"""
    except Exception as e:
        return format_error_with_context(e, "analyzing data bag usage", cookbook_path)


@mcp.tool()
def convert_chef_environment_to_inventory_group(
    environment_content: str, environment_name: str, include_constraints: bool = True
) -> str:
    """
    Convert Chef environment to Ansible inventory group with variables.

    Args:
        environment_content: Ruby content of the Chef environment file
        environment_name: Name of the Chef environment
        include_constraints: Whether to include cookbook version constraints

    Returns:
        Ansible inventory group configuration with variables

    """
    try:
        # Parse Chef environment content
        env_data = _parse_chef_environment_content(environment_content)

        # Convert to Ansible inventory group format
        inventory_config = _generate_inventory_group_from_environment(
            env_data, environment_name, include_constraints
        )

        return f"""---
# Chef environment converted to Ansible inventory group
# Original: environments/{environment_name}.rb
# Target: inventory/group_vars/{environment_name}.yml

{inventory_config.rstrip()}


---
# Add to your Ansible inventory (hosts.yml or hosts.ini):
# [{environment_name}]
# # Add your hosts here
#
# [all:children]
# {environment_name}
"""
    except Exception as e:
        return format_error_with_context(
            e, "converting Chef environment to inventory group", environment_name
        )


@mcp.tool()
def generate_inventory_from_chef_environments(
    environments_directory: str, output_format: str = "yaml"
) -> str:
    """
    Generate complete Ansible inventory from Chef environments directory.

    Args:
        environments_directory: Path to Chef environments directory
        output_format: Output format ("yaml", "ini", or "both")

    Returns:
        Complete Ansible inventory structure with environment-based groups

    """
    try:
        env_path = _normalize_path(environments_directory)
        if not env_path.exists():
            return f"Error: Environments directory not found: {environments_directory}"

        # Process all environment files
        environments = {}
        processing_results = []

        for env_file in safe_glob(env_path, "*.rb", env_path):
            env_name = env_file.stem

            try:
                content = safe_read_text(env_file, env_path)

                env_data = _parse_chef_environment_content(content)
                environments[env_name] = env_data

                processing_results.append(
                    {
                        "environment": env_name,
                        "status": "success",
                        "attributes": len(env_data.get("default_attributes", {})),
                        "overrides": len(env_data.get("override_attributes", {})),
                        "constraints": len(env_data.get("cookbook_versions", {})),
                    }
                )

            except Exception as e:
                processing_results.append(
                    {"environment": env_name, "status": "error", "error": str(e)}
                )

        # Generate inventory structure
        return _generate_complete_inventory_from_environments(
            environments, processing_results, output_format
        )

    except Exception as e:
        return format_error_with_context(
            e, "generating inventory from Chef environments", environments_directory
        )


@mcp.tool()
def analyse_chef_environment_usage(
    cookbook_path: str, environments_path: str = ""
) -> str:
    """
    Analyse Chef cookbook for environment usage.

    Provides migration recommendations.

    Args:
        cookbook_path: Path to Chef cookbook
        environments_path: Optional path to environments directory for cross-reference

    Returns:
        Analysis of environment usage and migration recommendations

    """
    try:
        cookbook = _normalize_path(cookbook_path)
        if not cookbook.exists():
            return f"Error: Cookbook path not found: {cookbook_path}"

        # Find environment usage patterns
        usage_patterns = _extract_environment_usage_from_cookbook(cookbook)

        # Analyze environments structure if provided
        environment_structure = {}
        if environments_path:
            environments = _normalize_path(environments_path)
            if environments.exists():
                environment_structure = _analyse_environments_structure(environments)

        # Generate recommendations
        recommendations = _generate_environment_migration_recommendations(
            usage_patterns, environment_structure
        )

        return f"""# Chef Environment Usage Analysis

## Environment Usage Patterns Found:
{_format_environment_usage_patterns(usage_patterns)}

## Environment Structure Analysis:
{_format_environment_structure(environment_structure)}

## Migration Recommendations:
{recommendations}

## Conversion Steps:
1. Use convert_chef_environment_to_inventory_group for individual environments
2. Use generate_inventory_from_chef_environments for complete inventory
3. Update playbooks to use group_vars for environment-specific variables
4. Implement variable precedence hierarchy in Ansible
5. Test environment-specific deployments with new inventory structure
"""
    except Exception as e:
        return format_error_with_context(
            e, "analyzing Chef environment usage", cookbook_path
        )


def _parse_chef_environment_content(content: str) -> dict:
    """Parse Chef environment Ruby content into structured data."""
    env_data = {
        "name": "",
        "description": "",
        "default_attributes": {},
        "override_attributes": {},
        "cookbook_versions": {},
    }

    # Extract name
    name_match = re.search(r"name\s+['\"]([^'\"\n]{0,150})['\"]", content)
    if name_match:
        env_data["name"] = name_match.group(1)

    # Extract description
    desc_match = re.search(r"description\s+['\"]([^'\"\n]{0,300})['\"]", content)
    if desc_match:
        env_data["description"] = desc_match.group(1)

    # Extract default attributes
    default_attrs = _extract_attributes_block(content, "default_attributes")
    if default_attrs:
        env_data["default_attributes"] = default_attrs

    # Extract override attributes
    override_attrs = _extract_attributes_block(content, "override_attributes")
    if override_attrs:
        env_data["override_attributes"] = override_attrs

    # Extract cookbook version constraints
    constraints = _extract_cookbook_constraints(content)
    if constraints:
        env_data["cookbook_versions"] = constraints

    return env_data


def _convert_ruby_literal(value: str) -> Any:
    """
    Convert Ruby literal values to equivalent Python types.

    This function handles the conversion of Ruby's basic literal values
    to their Python equivalents during Chef environment parsing.

    Args:
        value: String representation of a Ruby literal value.

    Returns:
        The converted Python value:
        - "true" -> True (bool)
        - "false" -> False (bool)
        - "nil" -> None
        - Integer strings -> int (e.g., "42" -> 42)
        - Float strings -> float (e.g., "3.14" -> 3.14, "1e10" -> 10000000000.0)
        - Unrecognized values -> original string unchanged

    Examples:
        >>> _convert_ruby_literal("true")
        True
        >>> _convert_ruby_literal("42")
        42
        >>> _convert_ruby_literal("3.14")
        3.14
        >>> _convert_ruby_literal("nil")
        None
        >>> _convert_ruby_literal("some_string")
        'some_string'

    """
    # Handle boolean and nil values
    literal_map = {
        "true": True,
        "false": False,
        "nil": None,
    }

    if value in literal_map:
        return literal_map[value]

    # Handle numeric values
    try:
        # Try integer first
        if "." not in value and "e" not in value.lower():
            return int(value)
        else:
            return float(value)
    except ValueError:
        pass

    # Return as string if no conversion applies
    return value


def _parse_quoted_key(content: str, i: int) -> tuple[str, int]:
    """Parse a quoted key and return (key, new_index)."""
    if content[i] not in "'\"":
        raise ValueError("Expected quote at start of key")

    quote = content[i]
    i += 1
    key_start = i
    while i < len(content) and content[i] != quote:
        i += 1
    key = content[key_start:i]
    i += 1  # skip closing quote
    return key, i


def _parse_nested_hash(content: str, i: int) -> tuple[dict, int]:
    """Parse a nested hash and return (parsed_dict, new_index)."""
    if content[i] != "{":
        raise ValueError("Expected opening brace for nested hash")

    brace_count = 1
    start = i
    i += 1
    while i < len(content) and brace_count > 0:
        if content[i] == "{":
            brace_count += 1
        elif content[i] == "}":
            brace_count -= 1
        i += 1

    nested_content = content[start + 1 : i - 1]  # exclude braces
    return parse_ruby_hash(nested_content), i


def _parse_simple_value(content: str, i: int) -> tuple[str, int]:
    """Parse a simple value and return (value, new_index)."""
    value_start = i
    while i < len(content) and content[i] not in ",}":
        i += 1
    value = content[value_start:i].strip()
    # Remove quotes if present
    if (value.startswith("'") and value.endswith("'")) or (
        value.startswith('"') and value.endswith('"')
    ):
        value = value[1:-1]
    else:
        # Convert Ruby literals to Python types
        value = _convert_ruby_literal(value)
    return value, i


def _skip_to_next_item(content: str, i: int) -> int:
    """Skip to the next item, handling delimiters."""
    while i < len(content) and content[i] not in ",}":
        i += 1
    if i < len(content) and (content[i] == "," or content[i] == "}"):
        i += 1
    return i


def parse_ruby_hash(content: str) -> dict:
    """Parse Ruby hash syntax recursively."""
    result = {}

    # Simple recursive parser for Ruby hash syntax
    # This handles nested braces by counting them
    i = 0
    while i < len(content):
        # Skip whitespace
        i = _skip_whitespace(content, i)
        if i >= len(content):
            break

        # Parse key-value pair
        key, value, i = _parse_key_value_pair(content, i)
        if key is not None:
            result[key] = value

        # Skip to next item
        i = _skip_to_next_item(content, i)

    return result


def _skip_whitespace(content: str, i: int) -> int:
    """Skip whitespace characters and return new index."""
    while i < len(content) and content[i].isspace():
        i += 1
    return i


def _parse_key_value_pair(content: str, i: int) -> tuple[str | None, Any, int]:
    """Parse a single key => value pair and return (key, value, new_index)."""
    # Look for key => value patterns
    if content[i] in "'\"":
        # Parse quoted key
        key, i = _parse_quoted_key(content, i)

        # Skip whitespace and =>
        i = _skip_whitespace_and_arrows(content, i)

        value: Any
        if i < len(content) and content[i] == "{":
            # Nested hash
            value, i = _parse_nested_hash(content, i)
        else:
            # Simple value
            value, i = _parse_simple_value(content, i)

        return key, value, i

    return None, None, i


def _skip_whitespace_and_arrows(content: str, i: int) -> int:
    """Skip whitespace and => symbols."""
    while i < len(content) and (content[i].isspace() or content[i] in "=>"):
        i += 1
    return i


def _extract_attributes_block(content: str, block_type: str) -> dict:
    """Extract attribute blocks from Chef environment content."""
    # Find the block start
    pattern = rf"{block_type}\s*\((.{{0,2000}}?)\)"
    match = re.search(pattern, content, re.DOTALL)

    if not match:
        return {}

    block_content = match.group(1).strip()

    attributes = parse_ruby_hash(block_content)
    return attributes


def _extract_cookbook_constraints(content: str) -> dict:
    """Extract cookbook version constraints from Chef environment."""
    constraints = {}

    # Find cookbook version constraints
    cookbook_pattern = (
        r"cookbook\s+['\"]([^'\"\n]{0,100})['\"]\,\s*['\"]([^'\"\n]{0,50})['\"]"
    )
    for match in re.finditer(cookbook_pattern, content):
        cookbook = match.group(1)
        version = match.group(2)
        constraints[cookbook] = version

    return constraints


def _generate_inventory_group_from_environment(
    env_data: dict, env_name: str, include_constraints: bool
) -> str:
    """Generate Ansible inventory group configuration from environment data."""
    group_vars: dict[str, Any] = {}

    # Add environment metadata
    group_vars["environment_name"] = env_name
    group_vars["environment_description"] = env_data.get("description", "")

    # Convert default attributes to group variables
    default_attrs = env_data.get("default_attributes", {})
    if default_attrs:
        group_vars.update(default_attrs)

    # Add override attributes with higher precedence indication
    override_attrs = env_data.get("override_attributes", {})
    if override_attrs:
        group_vars["environment_overrides"] = override_attrs

    # Add cookbook constraints if requested
    if include_constraints:
        cookbook_versions = env_data.get("cookbook_versions", {})
        if cookbook_versions:
            group_vars["cookbook_version_constraints"] = cookbook_versions

    # Add Chef-to-Ansible mapping metadata
    group_vars["chef_migration_metadata"] = {
        "source_environment": env_name,
        "converted_by": "souschef",
        "variable_precedence": ("group_vars (equivalent to Chef default_attributes)"),
        "overrides_location": (
            "environment_overrides (requires extra_vars or host_vars)"
        ),
    }

    return str(yaml.dump(group_vars, default_flow_style=False, indent=2))


def _build_conversion_summary(results: list) -> str:
    """
    Build summary of environment conversion results.

    Args:
        results: List of conversion result dicts

    Returns:
        Formatted summary string

    """
    total = len(results)
    successful = len([r for r in results if r["status"] == "success"])
    failed = len([r for r in results if r["status"] == "error"])

    summary = f"""# Chef Environments to Ansible Inventory Conversion

## Processing Summary:
- Total environments processed: {total}
- Successfully converted: {successful}
- Failed conversions: {failed}

## Environment Details:
"""
    for result in results:
        if result["status"] == "success":
            summary += (
                f"✅ {result['environment']}: {result['attributes']} attributes, "
            )
            summary += (
                f"{result['overrides']} overrides, "
                f"{result['constraints']} constraints\n"
            )
        else:
            summary += f"❌ {result['environment']}: {result['error']}\n"

    return summary


def _generate_yaml_inventory(environments: dict) -> str:
    """
    Generate YAML format inventory from environments.

    Args:
        environments: Dict of environment name to data

    Returns:
        YAML inventory string

    """
    inventory: dict[str, Any] = {"all": {"children": {}}}

    for env_name, env_data in environments.items():
        inventory["all"]["children"][env_name] = {
            "hosts": {},  # Hosts to be added manually
            "vars": _flatten_environment_vars(env_data),
        }

    yaml_output = yaml.dump(inventory, default_flow_style=False, indent=2)
    return f"\n## YAML Inventory Structure:\n\n```yaml\n{yaml_output}```\n"


def _generate_ini_inventory(environments: dict) -> str:
    """
    Generate INI format inventory from environments.

    Args:
        environments: Dict of environment name to data

    Returns:
        INI inventory string

    """
    output = "\n## INI Inventory Structure:\n\n```ini\n"
    output += "[all:children]\n"
    for env_name in environments:
        output += f"{env_name}\n"

    output += "\n"
    for env_name in environments:
        output += f"[{env_name}]\n"
        output += "# Add your hosts here\n\n"

    output += "```\n"
    return output


def _generate_next_steps_guide(environments: dict) -> str:
    """
    Generate next steps and file structure guide.

    Args:
        environments: Dict of environment name to data

    Returns:
        Guide string

    """
    guide = """
## Next Steps:
1. Create group_vars directory structure
2. Add environment-specific variable files
3. Populate inventory with actual hosts
4. Update playbooks to reference environment groups
5. Test variable precedence and override behavior

## File Structure to Create:
"""
    for env_name in environments:
        guide += f"- inventory/group_vars/{env_name}.yml\n"

    return guide


def _generate_complete_inventory_from_environments(
    environments: dict, results: list, output_format: str
) -> str:
    """
    Generate complete Ansible inventory from multiple Chef environments.

    Orchestrates summary, YAML/INI generation, and guidance.

    Args:
        environments: Dict of environment name to data
        results: List of conversion results
        output_format: Output format ("yaml", "ini", or "both")

    Returns:
        Complete formatted inventory with summary and guidance

    """
    # Build conversion summary
    summary = _build_conversion_summary(results)

    # Generate requested inventory formats
    if output_format in ["yaml", "both"]:
        summary += _generate_yaml_inventory(environments)

    if output_format in ["ini", "both"]:
        summary += _generate_ini_inventory(environments)

    # Add next steps guide
    summary += _generate_next_steps_guide(environments)

    return summary


def _flatten_environment_vars(env_data: dict) -> dict:
    """Flatten environment data for inventory variables."""
    vars_dict = {}

    # Add basic metadata
    vars_dict["environment_name"] = env_data.get("name", "")
    vars_dict["environment_description"] = env_data.get("description", "")

    # Add default attributes
    default_attrs = env_data.get("default_attributes", {})
    vars_dict.update(default_attrs)

    # Add override attributes in a separate namespace
    override_attrs = env_data.get("override_attributes", {})
    if override_attrs:
        vars_dict["environment_overrides"] = override_attrs

    # Add cookbook constraints
    cookbook_versions = env_data.get("cookbook_versions", {})
    if cookbook_versions:
        vars_dict["cookbook_version_constraints"] = cookbook_versions

    return vars_dict


def _extract_environment_usage_from_cookbook(cookbook_path) -> list:
    """Extract environment usage patterns from Chef cookbook files."""
    patterns = []

    # Search for environment usage in Ruby files
    for ruby_file in cookbook_path.rglob("*.rb"):
        try:
            content = safe_read_text(ruby_file, cookbook_path)

            # Find environment usage patterns
            found_patterns = _find_environment_patterns_in_content(
                content, str(ruby_file)
            )
            patterns.extend(found_patterns)

        except Exception as e:
            patterns.append(
                {"file": str(ruby_file), "error": f"Could not read file: {e}"}
            )

    return patterns


def _find_environment_patterns_in_content(content: str, file_path: str) -> list:
    """Find environment usage patterns in file content."""
    patterns = []

    # Common Chef environment patterns
    environment_patterns = [
        (r"node\.chef_environment", "node.chef_environment"),
        (r"node\[['\"]environment['\"]\]", 'node["environment"]'),
        (r"environment\s+['\"]([^'\"\n]{0,100})['\"]", "environment declaration"),
        (
            r"if\s+node\.chef_environment\s*==\s*['\"]([^'\"\n]{0,100})['\"]",
            "environment conditional",
        ),
        (r"case\s+node\.chef_environment", "environment case statement"),
        (r"search\([^)]*environment[^)]*\)", "environment in search query"),
    ]

    for pattern, pattern_type in environment_patterns:
        matches = re.finditer(pattern, content, re.MULTILINE | re.IGNORECASE)
        for match in matches:
            line_num = content[: match.start()].count("\n") + 1

            patterns.append(
                {
                    "file": file_path,
                    "line": line_num,
                    "type": pattern_type,
                    "match": match.group(0),
                    "environment_name": match.group(1)
                    if match.groups() and match.group(1)
                    else None,
                }
            )

    return patterns


def _analyse_environments_structure(environments_path) -> dict:
    """Analyse the structure of Chef environments directory."""
    structure: dict[str, Any] = {"total_environments": 0, "environments": {}}

    for env_file in safe_glob(environments_path, "*.rb", environments_path):
        structure["total_environments"] += 1
        env_name = env_file.stem

        try:
            content = safe_read_text(env_file, environments_path)

            env_data = _parse_chef_environment_content(content)

            structure["environments"][env_name] = {
                "name": env_data.get("name", env_name),
                "description": env_data.get("description", ""),
                "default_attributes_count": len(env_data.get("default_attributes", {})),
                "override_attributes_count": len(
                    env_data.get("override_attributes", {})
                ),
                "cookbook_constraints_count": len(
                    env_data.get("cookbook_versions", {})
                ),
                "size": env_file.stat().st_size,
            }

        except Exception as e:
            structure["environments"][env_name] = {"error": str(e)}

    return structure


def _analyse_usage_pattern_recommendations(usage_patterns: list) -> list[str]:
    """Analyse usage patterns and generate recommendations."""
    if not usage_patterns:
        return []

    recommendations = []
    environment_refs = [p for p in usage_patterns if "environment" in p.get("type", "")]
    conditional_usage = [
        p
        for p in usage_patterns
        if "conditional" in p.get("type", "") or "case" in p.get("type", "")
    ]

    recommendations.append(
        f"• Found {len(usage_patterns)} environment references in cookbook"
    )

    if environment_refs:
        recommendations.append(
            f"• {len(environment_refs)} direct environment attribute "
            f"accesses need inventory group conversion"
        )

    if conditional_usage:
        recommendations.append(
            f"• {len(conditional_usage)} conditional environment logic "
            f"needs when/group_names conditions"
        )

    return recommendations


def _analyse_structure_recommendations(env_structure: dict) -> list[str]:
    """Analyse environment structure and generate recommendations."""
    if not env_structure:
        return []

    total_envs = env_structure.get("total_environments", 0)
    if total_envs == 0:
        return []

    recommendations = [
        f"• Convert {total_envs} Chef environments to Ansible inventory groups"
    ]

    # Find complex environments
    complex_envs = [
        env_name
        for env_name, env_info in env_structure.get("environments", {}).items()
        if "error" not in env_info
        and env_info.get("default_attributes_count", 0)
        + env_info.get("override_attributes_count", 0)
        > 10
    ]

    if complex_envs:
        recommendations.append(
            f"• {len(complex_envs)} environments have >10 attributes - "
            f"consider splitting into logical variable groups"
        )

    return recommendations


def _get_general_migration_recommendations() -> list[str]:
    """Get standard migration recommendations."""
    return [
        "• Use Ansible groups to replace Chef environment-based node targeting",
        "• Convert Chef default_attributes to group_vars",
        "• Handle Chef override_attributes with extra_vars or host_vars",
        "• Implement environment-specific playbook execution with --limit",
        "• Test variable precedence matches Chef behavior",
        "• Consider using Ansible environments/staging for deployment workflows",
    ]


def _generate_environment_migration_recommendations(
    usage_patterns: list, env_structure: dict
) -> str:
    """Generate migration recommendations based on environment usage analysis."""
    recommendations = []
    recommendations.extend(_analyse_usage_pattern_recommendations(usage_patterns))
    recommendations.extend(_analyse_structure_recommendations(env_structure))
    recommendations.extend(_get_general_migration_recommendations())

    return "\n".join(recommendations)


def _format_environment_usage_patterns(patterns: list) -> str:
    """Format environment usage patterns for display."""
    if not patterns:
        return "No environment usage patterns found."

    formatted = []
    for pattern in patterns[:15]:  # Limit to first 15 for readability
        if "error" in pattern:
            formatted.append(f"❌ {pattern['file']}: {pattern['error']}")
        else:
            env_info = (
                f" (env: {pattern['environment_name']})"
                if pattern.get("environment_name")
                else ""
            )
            formatted.append(
                f"• {pattern['type']} in {pattern['file']}:{pattern['line']}{env_info}"
            )

    if len(patterns) > 15:
        formatted.append(f"... and {len(patterns) - 15} more patterns")

    return "\n".join(formatted)


def _format_environment_structure(structure: dict) -> str:
    """Format environment structure analysis for display."""
    if not structure:
        return "No environment structure provided for analysis."

    formatted = [f"• Total environments: {structure['total_environments']}"]

    if structure["environments"]:
        formatted.append("\n### Environment Details:")
        for name, info in list(structure["environments"].items())[
            :8
        ]:  # Limit for readability
            if "error" in info:
                formatted.append(f"❌ {name}: {info['error']}")
            else:
                attrs = info.get("default_attributes_count", 0)
                overrides = info.get("override_attributes_count", 0)
                constraints = info.get("cookbook_constraints_count", 0)
                formatted.append(
                    f"• {name}: {attrs} attributes, {overrides} overrides, "
                    f"{constraints} constraints"
                )

        if len(structure["environments"]) > 8:
            formatted.append(
                f"... and {len(structure['environments']) - 8} more environments"
            )

    return "\n".join(formatted)


def _convert_databag_to_ansible_vars(
    data: dict, databag_name: str, item_name: str, is_encrypted: bool
) -> dict:
    """Convert Chef data bag structure to Ansible variables format."""
    # Remove Chef-specific metadata
    ansible_vars = {}

    for key, value in data.items():
        if key == "id":  # Skip Chef ID field
            continue

        # Convert key to Ansible-friendly format
        ansible_key = (
            f"{databag_name}_{key}" if not key.startswith(databag_name) else key
        )
        ansible_vars[ansible_key] = value

    # Add metadata for tracking
    ansible_vars[f"{databag_name}_metadata"] = {
        "source": f"data_bags/{databag_name}/{item_name}.json",
        "converted_by": "souschef",
        "encrypted": is_encrypted,
    }

    return ansible_vars


def _generate_vault_content(vars_dict: dict, databag_name: str) -> str:
    """Generate Ansible Vault YAML content from variables dictionary."""
    # Structure for vault file
    vault_vars = {f"{databag_name}_vault": vars_dict}

    return str(yaml.dump(vault_vars, default_flow_style=False, indent=2))


def _detect_encrypted_databag(content: str) -> bool:
    """Detect if a Chef data bag is encrypted based on content structure."""
    try:
        databag_json = json.loads(content)

        # Chef encrypted data bags have specific fields (encrypted_data, cipher, iv, version)
        # These aren't in plaintext bags, so their presence confirms encryption
        encrypted_indicators = ["encrypted_data", "cipher", "iv", "version"]

        # Check if any encrypted indicators are present
        for indicator in encrypted_indicators:
            if indicator in databag_json:
                return True

        # Check for encrypted field patterns
        for _key, value in databag_json.items():
            if isinstance(value, dict) and "encrypted_data" in value:
                return True

        return False

    except (json.JSONDecodeError, TypeError):
        return False


def _calculate_conversion_statistics(results: list) -> dict[str, int]:
    """
    Calculate statistics from conversion results.

    Args:
        results: List of conversion result dictionaries.

    Returns:
        Dictionary with 'total', 'successful', and 'encrypted' counts.

    """
    return {
        "total": len(results),
        "successful": len([r for r in results if "error" not in r]),
        "encrypted": len([r for r in results if r.get("encrypted", False)]),
    }


def _build_statistics_section(stats: dict[str, int]) -> str:
    """
    Build the statistics section of the summary.

    Args:
        stats: Dictionary with conversion statistics.

    Returns:
        Formatted statistics section as markdown.

    """
    return f"""# Data Bag Conversion Summary

## Statistics:
- Total data bags processed: {stats["total"]}
- Successfully converted: {stats["successful"]}
- Failed conversions: {stats["total"] - stats["successful"]}
- Encrypted data bags: {stats["encrypted"]}
"""


def _extract_generated_files(results: list) -> list[str]:
    """
    Extract unique generated file paths from results.

    Args:
        results: List of conversion result dictionaries.

    Returns:
        Sorted list of unique file paths.

    """
    files_created = set()
    for result in results:
        if "error" not in result:
            target_file = result["target_file"]
            files_created.add(target_file)
    return sorted(files_created)


def _build_files_section(files: list[str]) -> str:
    """
    Build the generated files section.

    Args:
        files: List of generated file paths.

    Returns:
        Formatted files section as markdown.

    """
    section = "\n## Generated Files:\n"
    for file in files:
        section += f"- {file}\n"
    return section


def _build_conversion_details_section(results: list) -> str:
    """
    Build the conversion details section.

    Args:
        results: List of conversion result dictionaries.

    Returns:
        Formatted conversion details section as markdown.

    """
    section = "\n## Conversion Details:\n"

    for result in results:
        if "error" in result:
            section += f"❌ {result['databag']}/{result['item']}: {result['error']}\n"
        else:
            status = "🔒 Encrypted" if result.get("encrypted", False) else "📄 Plain"
            databag_item = f"{result['databag']}/{result['item']}"
            target = result["target_file"]
            section += f"✅ {databag_item} → {target} ({status})\n"

    return section


def _build_next_steps_section(output_dir: str) -> str:
    """
    Build the next steps section.

    Args:
        output_dir: Output directory path.

    Returns:
        Formatted next steps section as markdown.

    """
    return f"""
## Next Steps:
1. Review generated variable files in {output_dir}/
2. Encrypt vault files: `ansible-vault encrypt {output_dir}/*_vault.yml`
3. Update playbooks to include vars_files references
4. Test variable access in playbooks
5. Remove original Chef data bags after validation
"""


def _generate_databag_conversion_summary(results: list, output_dir: str) -> str:
    """
    Generate summary of data bag conversion results.

    Args:
        results: List of conversion result dictionaries.
        output_dir: Output directory path.

    Returns:
        Complete formatted summary as markdown.

    """
    stats = _calculate_conversion_statistics(results)
    files = _extract_generated_files(results)

    return (
        _build_statistics_section(stats)
        + _build_files_section(files)
        + _build_conversion_details_section(results)
        + _build_next_steps_section(output_dir)
    )


def _extract_databag_usage_from_cookbook(cookbook_path) -> list:
    """Extract data bag usage patterns from Chef cookbook files."""
    patterns = []

    # Search for data bag usage in Ruby files
    for ruby_file in cookbook_path.rglob("*.rb"):
        try:
            content = safe_read_text(ruby_file, cookbook_path)

            # Find data bag usage patterns
            found_patterns = _find_databag_patterns_in_content(content, str(ruby_file))
            patterns.extend(found_patterns)

        except Exception as e:
            patterns.append(
                {"file": str(ruby_file), "error": f"Could not read file: {e}"}
            )

    return patterns


def _find_databag_patterns_in_content(content: str, file_path: str) -> list:
    """Find data bag usage patterns in file content."""
    patterns = []

    # Common Chef data bag patterns
    databag_patterns = [
        (r"data_bag\([\'\"]\s*([^\'\"]*)\s*[\'\"]\)", "data_bag()"),
        (
            r"data_bag_item\([\'\"]\s*([^\'\"]*)\s*[\'\"]\s*,\s*[\'\"]\s*([^\'\"]*)\s*[\'\"]\)",
            "data_bag_item()",
        ),
        (
            r"encrypted_data_bag_item\([\'\"]\s*([^\'\"]*)\s*[\'\"]\s*,\s*[\'\"]\s*([^\'\"]*)\s*[\'\"]\)",
            "encrypted_data_bag_item()",
        ),
        (r"search\(\s*:node.*data_bag.*\)", "search() with data_bag"),
    ]

    for pattern, pattern_type in databag_patterns:
        matches = re.finditer(pattern, content, re.MULTILINE | re.IGNORECASE)
        for match in matches:
            line_num = content[: match.start()].count("\n") + 1

            patterns.append(
                {
                    "file": file_path,
                    "line": line_num,
                    "type": pattern_type,
                    "match": match.group(0),
                    "databag_name": match.group(1) if match.groups() else None,
                    "item_name": match.group(2)
                    if len(match.groups()) >= 2 and match.group(2)
                    else None,
                }
            )

    return patterns


def _analyse_databag_structure(databags_path) -> dict:
    """Analyse the structure of Chef data bags directory."""
    structure: dict[str, Any] = {
        "total_databags": 0,
        "total_items": 0,
        "encrypted_items": 0,
        "databags": {},
    }

    for databag_dir in databags_path.iterdir():  # nosonar
        if not databag_dir.is_dir():
            continue

        databag_name = databag_dir.name
        structure["total_databags"] += 1

        items = []
        for item_file in safe_glob(databag_dir, "*.json", databags_path):
            structure["total_items"] += 1
            item_name = item_file.stem

            try:
                content = safe_read_text(item_file, databags_path)

                is_encrypted = _detect_encrypted_databag(content)
                if is_encrypted:
                    structure["encrypted_items"] += 1

                items.append(
                    {
                        "name": item_name,
                        "encrypted": is_encrypted,
                        "size": item_file.stat().st_size,
                    }
                )

            except Exception as e:
                items.append({"name": item_name, "error": str(e)})

        structure["databags"][databag_name] = {"items": items, "item_count": len(items)}

    return structure


def _analyse_usage_patterns(usage_patterns: list) -> list[str]:
    """
    Analyse databag usage patterns and generate recommendations.

    Args:
        usage_patterns: List of usage pattern dicts

    Returns:
        List of recommendation strings

    """
    recommendations: list[str] = []

    if not usage_patterns:
        return recommendations

    unique_databags = {
        p.get("databag_name") for p in usage_patterns if p.get("databag_name")
    }
    recommendations.append(
        f"• Found {len(usage_patterns)} data bag references "
        f"across {len(unique_databags)} different data bags"
    )

    # Check for encrypted usage
    encrypted_usage = [p for p in usage_patterns if "encrypted" in p.get("type", "")]
    if encrypted_usage:
        recommendations.append(
            f"• {len(encrypted_usage)} encrypted data bag references "
            f"- convert to Ansible Vault"
        )

    # Check for complex patterns
    search_patterns = [p for p in usage_patterns if "search" in p.get("type", "")]
    if search_patterns:
        recommendations.append(
            f"• {len(search_patterns)} search patterns involving data bags "
            f"- may need inventory integration"
        )

    return recommendations


def _analyse_databag_structure_recommendations(databag_structure: dict) -> list[str]:
    """
    Analyse databag structure and generate recommendations.

    Args:
        databag_structure: Dict with structure analysis

    Returns:
        List of recommendation strings

    """
    recommendations: list[str] = []

    if not databag_structure:
        return recommendations

    total_bags = databag_structure.get("total_databags", 0)
    encrypted_items = databag_structure.get("encrypted_items", 0)

    if total_bags > 0:
        recommendations.append(
            f"• Convert {total_bags} data bags to group_vars/host_vars structure"
        )

    if encrypted_items > 0:
        recommendations.append(
            f"• {encrypted_items} encrypted items need Ansible Vault conversion"
        )

    return recommendations


def _get_variable_scope_recommendations() -> list[str]:
    """
    Get standard variable scope recommendations.

    Returns:
        List of recommendation strings

    """
    return [
        "• Use group_vars/ for environment-specific data (production, staging)",
        "• Use host_vars/ for node-specific configurations",
        "• Consider splitting large data bags into logical variable files",
        "• Implement variable precedence hierarchy matching Chef environments",
    ]


def _generate_databag_migration_recommendations(
    usage_patterns: list, databag_structure: dict
) -> str:
    """
    Generate migration recommendations based on usage analysis.

    Combines usage pattern analysis, structure analysis, and best practices.

    Args:
        usage_patterns: List of databag usage patterns
        databag_structure: Dict with databag structure info

    Returns:
        Formatted recommendations string

    """
    recommendations = []

    # Analyze usage patterns
    recommendations.extend(_analyse_usage_patterns(usage_patterns))

    # Analyze structure
    recommendations.extend(
        _analyse_databag_structure_recommendations(databag_structure)
    )

    # Add variable scope best practices
    recommendations.extend(_get_variable_scope_recommendations())

    return "\n".join(recommendations)


def _format_usage_patterns(patterns: list) -> str:
    """Format data bag usage patterns for display."""
    if not patterns:
        return "No data bag usage patterns found."

    formatted = []
    for pattern in patterns[:10]:  # Limit to first 10 for readability
        if "error" in pattern:
            formatted.append(f"❌ {pattern['file']}: {pattern['error']}")
        else:
            formatted.append(
                f"• {pattern['type']} in {pattern['file']}:{pattern['line']} "
                f"(databag: {pattern.get('databag_name', 'unknown')})"
            )

    if len(patterns) > 10:
        formatted.append(f"... and {len(patterns) - 10} more patterns")

    return "\n".join(formatted)


def _format_databag_structure(structure: dict) -> str:
    """Format data bag structure analysis for display."""
    if not structure:
        return "No data bag structure provided for analysis."

    formatted = [
        f"• Total data bags: {structure['total_databags']}",
        f"• Total items: {structure['total_items']}",
        f"• Encrypted items: {structure['encrypted_items']}",
    ]

    if structure["databags"]:
        formatted.append("\n### Data Bag Details:")
        for name, info in list(structure["databags"].items())[
            :5
        ]:  # Limit for readability
            encrypted_count = sum(
                1 for item in info["items"] if item.get("encrypted", False)
            )
            formatted.append(
                f"• {name}: {info['item_count']} items ({encrypted_count} encrypted)"
            )

        if len(structure["databags"]) > 5:
            formatted.append(f"... and {len(structure['databags']) - 5} more data bags")

    return "\n".join(formatted)


# ============================================================================
# Deployment and AWX/AAP Integration Tools
# ============================================================================
# The following tools are imported from souschef.deployment module
# - generate_awx_job_template_from_cookbook
# - generate_awx_workflow_from_chef_runlist
# - generate_awx_project_from_cookbooks
# - generate_awx_inventory_source_from_chef
# - convert_chef_deployment_to_ansible_strategy
# - generate_blue_green_deployment_playbook
# - generate_canary_deployment_strategy
# - analyze_chef_application_patterns

# Register imported deployment tools with MCP server
mcp.tool()(_generate_awx_job_template_from_cookbook)
mcp.tool()(_generate_awx_workflow_from_chef_runlist)
mcp.tool()(_generate_awx_project_from_cookbooks)
mcp.tool()(_generate_awx_inventory_source_from_chef)
mcp.tool()(_convert_chef_deployment_to_ansible_strategy)
mcp.tool()(_generate_blue_green_deployment_playbook)
mcp.tool()(_generate_canary_deployment_strategy)
mcp.tool()(analyse_chef_application_patterns)


# ============================================================================
# Assessment and Migration Planning Tools
# ============================================================================
# Note: assess_chef_migration_complexity is defined later in this file


@mcp.tool()
def assess_chef_migration_complexity(
    cookbook_paths: str,
    migration_scope: str = "full",
    target_platform: str = "ansible_awx",
) -> str:
    """
    Assess the complexity of migrating Chef cookbooks to Ansible.

    Analyzes one or more Chef cookbooks to determine migration complexity,
    effort estimation, and potential challenges.

    Args:
        cookbook_paths: Comma-separated list of paths to Chef cookbook directories.
        migration_scope: Scope of migration (full/recipes_only/infrastructure_only).
        target_platform: Target platform (ansible_awx/ansible_core/ansible_tower).

    Returns:
        Detailed assessment report in markdown format.

    """
    # Sanitise and contain user-provided cookbook paths before processing
    sanitized = _sanitize_cookbook_paths_input(cookbook_paths)
    return _assess_chef_migration_complexity(
        sanitized, migration_scope, target_platform
    )


@mcp.tool()
def generate_migration_plan(
    cookbook_paths: str,
    migration_strategy: str = "phased",
    timeline_weeks: int = 12,
) -> str:
    """
    Generate a detailed migration plan for Chef to Ansible conversion.

    Creates a comprehensive migration plan with phases, timeline, resources,
    and risk mitigation strategies.

    Args:
        cookbook_paths: Comma-separated list of paths to Chef cookbook directories.
        migration_strategy: Migration approach (big_bang, phased, parallel).
        timeline_weeks: Target timeline in weeks.

    Returns:
        Detailed migration plan in markdown format.

    """
    # Sanitise and contain user-provided cookbook paths before processing
    sanitized = _sanitize_cookbook_paths_input(cookbook_paths)
    return _generate_migration_plan(sanitized, migration_strategy, timeline_weeks)


@mcp.tool()
def analyse_cookbook_dependencies(cookbook_paths: str) -> str:
    """
    Analyse dependencies between Chef cookbooks.

    Maps cookbook dependencies, identifies circular dependencies, and
    recommends migration order.

    Args:
        cookbook_paths: Comma-separated list of paths to Chef cookbook directories.

    Returns:
        Dependency analysis report in markdown format.

    """
    # Sanitise and contain user-provided cookbook paths before processing
    sanitized = _sanitize_cookbook_paths_input(cookbook_paths)
    return _analyse_cookbook_dependencies(sanitized)


@mcp.tool()
def generate_migration_report(
    cookbook_paths: str,
    report_format: str = "markdown",
    include_technical_details: str = "yes",
) -> str:
    """
    Generate a comprehensive migration report.

    Creates a detailed report covering assessment, planning, and recommendations
    for migrating Chef cookbooks to Ansible.

    Args:
        cookbook_paths: Comma-separated list of paths to Chef cookbook directories.
        report_format: Output format (markdown/html/json).
        include_technical_details: Include technical details (yes/no).

    Returns:
        Comprehensive migration report in markdown format.

    """
    # Sanitise and contain user-provided cookbook paths before processing
    sanitized = _sanitize_cookbook_paths_input(cookbook_paths)
    return _generate_migration_report(
        sanitized, report_format, include_technical_details
    )


def _sanitize_cookbook_paths_input(cookbook_paths: str) -> str:
    """
    Sanitise a comma-separated list of cookbook paths.

    Args:
        cookbook_paths: Comma-separated paths provided by the user.

    Returns:
        A comma-separated string of normalised paths.

    Raises:
        ValueError: If any path is invalid.

    """
    sanitized_paths: list[str] = []
    for raw in cookbook_paths.split(","):
        candidate = raw.strip()
        if not candidate:
            continue
        # Normalize the path (resolves ., .., symlinks)

        # prevents traversal attacks; file access is further contained by per-operation checks
        normalised = _normalize_path(candidate)

        # Validate it's an absolute path after normalization
        if not normalised.is_absolute():
            msg = f"Path must be absolute after normalization: {candidate}"
            raise ValueError(msg)

        # Use the normalized absolute path (temp dirs, workspace dirs all allowed)
        sanitized_paths.append(str(normalised))
    return ",".join(sanitized_paths)


@mcp.tool()
def validate_conversion(
    conversion_type: str,
    result_content: str,
    output_format: str = "text",
) -> str:
    """
    Validate converted Ansible content for correctness and best practices.

    Performs comprehensive validation of converted Ansible playbooks, roles,
    and task files to ensure they meet standards and best practices.

    Args:
        conversion_type: Type of conversion (cookbook/recipe/resource/attribute).
        result_content: The converted Ansible content to validate.
        output_format: Output format (text/json/summary).

    Returns:
        Validation report in the specified format.

    """
    return _validate_conversion(conversion_type, result_content, output_format)


# Chef Server Integration Tools


@mcp.tool()
def validate_chef_server_connection(
    server_url: str,
    node_name: str,
) -> str:
    """
    Validate Chef Server connectivity and configuration.

    Tests the Chef Server REST API connection to ensure the server is
    reachable and properly configured.

    Args:
        server_url: Base URL of the Chef Server (e.g., https://chef.example.com).
        node_name: Chef node name for authentication.

    Returns:
        Success/failure message indicating the connection status.

    """
    try:
        success, message = _validate_chef_server_connection(server_url, node_name)
        result = "✅ Success" if success else "❌ Failed"
        return f"{result}: {message}"
    except Exception as e:
        return f"❌ Error validating Chef Server connection: {e}"


@mcp.tool()
def get_chef_nodes(search_query: str = "*:*") -> str:
    """
    Query Chef Server for nodes matching search criteria.

    Retrieves nodes from Chef Server that match the provided search query,
    extracting role assignments, environment, platform, and IP address
    information for dynamic inventory generation.

    Args:
        search_query: Chef search query (default: '*:*' for all nodes).

    Returns:
        JSON string containing list of matching nodes with their attributes.

    """
    try:
        nodes = _get_chef_nodes(search_query)
        if not nodes:
            return json.dumps(
                {
                    "status": "no_nodes",
                    "message": "No nodes found matching the search query",
                    "nodes": [],
                }
            )
        return json.dumps(
            {
                "status": "success",
                "count": len(nodes),
                "nodes": nodes,
            }
        )
    except Exception as e:
        return json.dumps(
            {
                "status": "error",
                "message": f"Error querying Chef Server: {str(e)}",
                "nodes": [],
            }
        )


# Template Conversion Tools


@mcp.tool()
def convert_template_with_ai(
    erb_path: str,
    use_ai_enhancement: bool = True,
) -> str:
    """
    Convert an ERB template to Jinja2 with optional AI assistance.

    Converts Chef ERB templates to Ansible Jinja2 format with optional
    AI-based validation and improvement for complex Ruby logic that cannot
    be automatically converted.

    Args:
        erb_path: Path to the ERB template file.
        use_ai_enhancement: Whether to use AI for validation (default: True).

    Returns:
        JSON string with conversion results including success status,
        Jinja2 output, warnings, and conversion method used.

    """
    try:
        if use_ai_enhancement:
            result = _convert_template_with_ai(erb_path, ai_service=None)
        else:
            # Fall back to rule-based conversion
            from souschef.converters.template import convert_template_file

            result = convert_template_file(erb_path)
            result["conversion_method"] = "rule-based"
        return json.dumps(result, indent=2)
    except Exception as e:
        return json.dumps(
            {
                "success": False,
                "error": f"Error converting template: {str(e)}",
                "template": erb_path,
                "jinja2_output": "",
            }
        )


# Habitat Parsing Tool


@mcp.tool()
def parse_habitat_plan(plan_path: str) -> str:
    """
    Parse a Chef Habitat plan file (plan.sh) and extract package metadata.

    Analyzes Habitat plans to extract package information, dependencies,
    ports, services, and build callbacks for container conversion.

    Args:
        plan_path: Path to the plan.sh file

    Returns:
        JSON string with parsed plan metadata

    """
    plan_path = str(_normalize_path(plan_path))
    return _parse_habitat_plan(plan_path)


# Habitat conversion tools - re-export for backward compatibility
def convert_habitat_to_dockerfile(
    plan_path: str, base_image: str = "ubuntu:22.04"
) -> str:
    """
    Convert a Habitat plan to Dockerfile.

    Args:
        plan_path: Path to the Habitat plan.sh file.
        base_image: Base Docker image to use.

    Returns:
        Generated Dockerfile content.

    """
    return _convert_habitat_to_dockerfile(plan_path, base_image)


def generate_compose_from_habitat(
    plan_paths: str, network_name: str = "habitat_net"
) -> str:
    """
    Generate Docker Compose from Habitat plans.

    Args:
        plan_paths: Comma-separated paths to plan.sh files.
        network_name: Docker network name.

    Returns:
        Generated Docker Compose YAML content.

    """
    return _generate_compose_from_habitat(plan_paths, network_name)


# Playbook converter wrappers for backward compatibility
def generate_playbook_from_recipe(recipe_path: str) -> str:
    """
    Generate Ansible playbook from Chef recipe.

    Args:
        recipe_path: Path to the Chef recipe file.

    Returns:
        Generated Ansible playbook content.

    """
    from souschef.converters.playbook import (
        generate_playbook_from_recipe as _generate_playbook,
    )

    return _generate_playbook(recipe_path)


def convert_chef_search_to_inventory(search_query: str) -> str:
    """
    Convert Chef search query to Ansible inventory.

    Args:
        search_query: Chef search query.

    Returns:
        Ansible inventory configuration.

    """
    return _convert_chef_search_to_inventory(search_query)


def generate_dynamic_inventory_script(search_queries: str) -> str:
    """
    Generate dynamic inventory script from Chef search queries.

    Args:
        search_queries: Chef search queries (one per line).

    Returns:
        Python dynamic inventory script content.

    """
    return _generate_dynamic_inventory_script(search_queries)


@mcp.tool()
def analyse_chef_search_patterns(recipe_or_cookbook_path: str) -> str:
    """
    Analyse Chef search patterns in recipe or cookbook.

    Args:
        recipe_or_cookbook_path: Path to recipe or cookbook.

    Returns:
        Analysis of search patterns found.

    """
    recipe_or_cookbook_path = str(_normalize_path(recipe_or_cookbook_path))
    return _analyse_chef_search_patterns(recipe_or_cookbook_path)


@mcp.tool()
def profile_cookbook_performance(cookbook_path: str) -> str:
    """
    Profile cookbook parsing performance and generate optimization report.

    Analyzes the performance of parsing all cookbook components (recipes,
    attributes, resources, templates) and provides recommendations for
    optimization. Useful for large cookbooks or batch processing operations.

    Args:
        cookbook_path: Path to the Chef cookbook to profile.

    Returns:
        Formatted performance report with timing, memory usage, and recommendations.

    """
    from souschef.profiling import generate_cookbook_performance_report

    try:
        cookbook_path = str(_normalize_path(cookbook_path))
        report = generate_cookbook_performance_report(cookbook_path)
        return str(report)
    except Exception as e:
        return format_error_with_context(
            e, "profiling cookbook performance", cookbook_path
        )


@mcp.tool()
def profile_parsing_operation(
    operation: str, file_path: str, detailed: bool = False
) -> str:
    """
    Profile a single parsing operation with detailed performance metrics.

    Measures execution time, memory usage, and optionally provides detailed
    function call statistics for a specific parsing operation.

    Args:
        operation: Type of operation to profile ('recipe', 'attributes', 'resource', 'template').
        file_path: Path to the file to parse.
        detailed: If True, include detailed function call statistics.

    Returns:
        Performance metrics for the operation.

    """
    from souschef.profiling import detailed_profile_function, profile_function

    operation_map = {
        "recipe": parse_recipe,
        "attributes": parse_attributes,
        "resource": parse_custom_resource,
        "template": parse_template,
    }

    if operation not in operation_map:
        return (
            f"Error: Invalid operation '{operation}'\n\n"
            f"Supported operations: {', '.join(operation_map.keys())}"
        )

    func = operation_map[operation]

    try:
        file_path = str(_normalize_path(file_path))
        if detailed:
            _, profile_result = detailed_profile_function(func, file_path)
            result = str(profile_result)
            if profile_result.function_stats.get("top_functions"):
                result += "\n\nDetailed Function Statistics:\n"
                result += profile_result.function_stats["top_functions"]
            return result
        else:
            _, profile_result = profile_function(func, file_path)
            return str(profile_result)
    except Exception as e:
        return format_error_with_context(e, f"profiling {operation} parsing", file_path)


# CI/CD Pipeline Generation Tools


@mcp.tool()
def generate_jenkinsfile_from_chef(
    cookbook_path: str,
    pipeline_name: str = "chef-to-ansible-pipeline",
    pipeline_type: str = "declarative",
    enable_parallel: str = "yes",
) -> str:
    """
    Generate Jenkins pipeline from Chef cookbook CI/CD patterns.

    Analyzes Chef testing tools (Test Kitchen, ChefSpec, InSpec, Foodcritic)
    and generates equivalent Jenkins pipeline stages (Declarative or Scripted).

    Args:
        cookbook_path: Path to Chef cookbook directory.
        pipeline_name: Name for the Jenkins pipeline.
        pipeline_type: Pipeline type - 'declarative' (recommended) or 'scripted'.
        enable_parallel: Enable parallel test execution - 'yes' or 'no'.

    Returns:
        Jenkinsfile content (Groovy DSL) for Jenkins pipeline.

    """
    from souschef.ci.jenkins_pipeline import generate_jenkinsfile_from_chef_ci

    try:
        cookbook_path = str(_normalize_path(cookbook_path))
        # Convert string to boolean
        enable_parallel_bool = enable_parallel.lower() in ("yes", "true", "1")

        result = generate_jenkinsfile_from_chef_ci(
            cookbook_path=cookbook_path,
            pipeline_name=pipeline_name,
            pipeline_type=pipeline_type,
            enable_parallel=enable_parallel_bool,
        )
        return result
    except FileNotFoundError as e:
        return format_error_with_context(e, "generating Jenkinsfile", cookbook_path)
    except Exception as e:
        return format_error_with_context(e, "generating Jenkinsfile", cookbook_path)


@mcp.tool()
def generate_gitlab_ci_from_chef(
    cookbook_path: str,
    project_name: str = "chef-to-ansible",
    enable_cache: str = "yes",
    enable_artifacts: str = "yes",
) -> str:
    """
    Generate GitLab CI configuration from Chef cookbook CI/CD patterns.

    Analyzes Chef testing tools and generates equivalent GitLab CI stages
    with caching, artifacts, and parallel execution support.

    Args:
        cookbook_path: Path to Chef cookbook directory.
        project_name: GitLab project name.
        enable_cache: Enable caching for dependencies - 'yes' or 'no'.
        enable_artifacts: Enable artifacts for test results - 'yes' or 'no'.

    Returns:
        .gitlab-ci.yml content (YAML) for GitLab CI/CD.

    """
    from souschef.ci.gitlab_ci import generate_gitlab_ci_from_chef_ci

    try:
        cookbook_path = str(_normalize_path(cookbook_path))
        enable_cache_bool = enable_cache.lower() in ("yes", "true", "1")
        enable_artifacts_bool = enable_artifacts.lower() in ("yes", "true", "1")
        result = generate_gitlab_ci_from_chef_ci(
            cookbook_path=cookbook_path,
            project_name=project_name,
            enable_cache=enable_cache_bool,
            enable_artifacts=enable_artifacts_bool,
        )
        return result
    except FileNotFoundError as e:
        return format_error_with_context(
            e,
            "generating .gitlab-ci.yml",
            cookbook_path,
        )
    except Exception as e:
        return format_error_with_context(e, "generating .gitlab-ci.yml", cookbook_path)


@mcp.tool()
def generate_github_workflow_from_chef(
    cookbook_path: str,
    workflow_name: str = "Chef Cookbook CI",
    enable_cache: str = "yes",
    enable_artifacts: str = "yes",
) -> str:
    """
    Generate GitHub Actions workflow from Chef cookbook CI/CD patterns.

    Analyzes Chef testing tools and generates equivalent GitHub Actions workflow
    with caching, artifacts, and matrix strategy support.

    Args:
        cookbook_path: Path to Chef cookbook directory.
        workflow_name: GitHub Actions workflow name.
        enable_cache: Enable caching for dependencies - 'yes' or 'no'.
        enable_artifacts: Enable artifacts for test results - 'yes' or 'no'.

    Returns:
        GitHub Actions workflow YAML content (.github/workflows/*.yml).

    """
    from souschef.ci.github_actions import generate_github_workflow_from_chef_ci

    try:
        cookbook_path = str(_normalize_path(cookbook_path))
        enable_cache_bool = enable_cache.lower() in ("yes", "true", "1")
        enable_artifacts_bool = enable_artifacts.lower() in ("yes", "true", "1")
        result = generate_github_workflow_from_chef_ci(
            cookbook_path=cookbook_path,
            workflow_name=workflow_name,
            enable_cache=enable_cache_bool,
            enable_artifacts=enable_artifacts_bool,
        )
        return result
    except FileNotFoundError as e:
        return format_error_with_context(
            e,
            "generating GitHub Actions workflow",
            cookbook_path,
        )
    except Exception as e:
        return format_error_with_context(
            e, "generating GitHub Actions workflow", cookbook_path
        )


@mcp.tool()
def generate_ansible_repository(
    output_path: str,
    repo_type: str = "auto",
    cookbook_path: str = "",
    org_name: str = "myorg",
    init_git: str = "yes",
) -> str:
    """
    Generate a complete Ansible repository structure.

    Analyses converted Chef cookbooks and creates an appropriate Ansible
    repository structure with proper organisation, configuration files,
    and git initialisation.

    Repo Types:
    - auto: Auto-detect based on conversion analysis (recommended)
    - inventory_first: Classic inventory-first (best for infra management)
    - playbooks_roles: Simple playbooks + roles (best for small projects)
    - collection: Ansible Collection layout (best for reusable automation)
    - mono_repo: Multi-project mono-repo (best for platform teams)

    Args:
        output_path: Path where the repository should be created
        repo_type: Type of repository structure (auto/inventory_first/playbooks_roles/collection/mono_repo)
        cookbook_path: Optional path to Chef cookbook for analysis (used with repo_type='auto')
        org_name: Organisation name for the repository
        init_git: Whether to initialise a git repository ('yes' or 'no')

    Returns:
        JSON string with generation results including success status, files created, and git status

    """
    from souschef.generators.repo import (
        analyse_conversion_output,
    )
    from souschef.generators.repo import (
        generate_ansible_repository as gen_repo,
    )

    try:
        output_path = str(_normalize_path(output_path))
        init_git_bool = init_git.lower() in ("yes", "true", "1")

        # Determine repo type
        if repo_type == "auto":
            if not cookbook_path:
                return json.dumps(
                    {
                        "success": False,
                        "error": "cookbook_path required when repo_type='auto'",
                    }
                )

            cookbook_path = str(_normalize_path(cookbook_path))

            # Validate cookbook path exists
            if not Path(cookbook_path).exists():
                return json.dumps(
                    {
                        "success": False,
                        "error": f"Cookbook path does not exist: {cookbook_path}",
                    }
                )

            # Analyse the cookbook to determine best repo type
            # Count recipes
            recipes_dir = Path(cookbook_path) / "recipes"
            num_recipes = (
                len(list(recipes_dir.glob("*.rb"))) if recipes_dir.exists() else 0
            )

            # Basic heuristics for repo type selection
            has_multiple_apps = num_recipes > 5
            num_roles = max(1, num_recipes // 2)  # Estimate roles from recipes

            determined_type = analyse_conversion_output(
                cookbook_path=cookbook_path,
                num_recipes=num_recipes,
                num_roles=num_roles,
                has_multiple_apps=has_multiple_apps,
                needs_multi_env=True,
            )
            result = gen_repo(output_path, determined_type, org_name, init_git_bool)
        else:
            # Use specified repo type
            result = gen_repo(output_path, repo_type, org_name, init_git_bool)

        return json.dumps(result, indent=2)

    except Exception as e:
        return json.dumps(
            {
                "success": False,
                "error": f"Failed to generate repository: {e}",
            }
        )


@mcp.tool()
def parse_chef_migration_assessment(
    cookbook_paths: str,
    migration_scope: str = "full",
    target_platform: str = "ansible_awx",
) -> dict[str, Any]:
    """
    Parse Chef cookbook migration assessment and return as dictionary.

    Args:
        cookbook_paths: Comma-separated paths to Chef cookbooks or cookbook directory
        migration_scope: Scope of migration (full, recipes_only, infrastructure_only)
        target_platform: Target platform (ansible_awx, ansible_core, ansible_tower)

    Returns:
        Dictionary containing assessment data with complexity, recommendations, etc.

    """
    return _parse_chef_migration_assessment(
        cookbook_paths, migration_scope, target_platform
    )


@mcp.tool()
def convert_cookbook_comprehensive(
    cookbook_path: str,
    output_path: str,
    assessment_data: str = "",
    include_templates: bool = True,
    include_attributes: bool = True,
    include_recipes: bool = True,
    role_name: str = "",
) -> str:
    """
    Convert an entire Chef cookbook to a complete Ansible role.

    This function performs comprehensive conversion of a Chef cookbook to an Ansible role,
    including recipes, templates, attributes, and proper role structure. It can use
    assessment data to optimize the conversion process.

    Args:
        cookbook_path: Path to the Chef cookbook directory
        output_path: Directory where the Ansible role will be created
        assessment_data: Optional JSON string with assessment results for optimization
        include_templates: Whether to convert ERB templates to Jinja2 (default: True)
        include_attributes: Whether to convert attributes to Ansible variables (default: True)
        include_recipes: Whether to convert recipes to Ansible tasks (default: True)
        role_name: Name for the Ansible role (defaults to cookbook name)

    Returns:
        Summary of the conversion process and created files

    """
    try:
        from souschef.core.path_utils import _normalize_path

        cookbook_dir = _normalize_path(cookbook_path)
        output_dir = _normalize_path(output_path)

        if not cookbook_dir.exists():
            return f"Error: Cookbook path does not exist: {cookbook_path}"

        # Parse assessment data if provided
        assessment = {}
        if assessment_data:
            try:
                assessment = json.loads(assessment_data)
            except json.JSONDecodeError:
                return f"Error: Invalid assessment data JSON: {assessment_data}"

        # Get cookbook metadata and setup
        cookbook_name, role_name = _setup_conversion_metadata(cookbook_dir, role_name)

        # Create role directory structure
        role_dir = _create_role_structure(output_dir, role_name)

        # Initialize conversion summary
        conversion_summary = {
            "cookbook_name": cookbook_name,
            "role_name": role_name,
            "converted_files": [],
            "errors": [],
            "warnings": [],
        }

        # Convert components
        if include_recipes:
            _convert_recipes(cookbook_dir, role_dir, conversion_summary)

        if include_templates:
            _convert_templates(cookbook_dir, role_dir, conversion_summary)

        if include_attributes:
            _convert_attributes(cookbook_dir, role_dir, conversion_summary)

        # Create main task file and metadata
        _create_main_task_file(
            cookbook_dir, role_dir, conversion_summary, include_recipes
        )
        _create_role_metadata(
            role_dir, role_name, cookbook_name, assessment, conversion_summary
        )

        # Generate and return summary report
        return _generate_conversion_report(conversion_summary, role_dir)

    except Exception as e:
        return format_error_with_context(
            e, "converting cookbook comprehensively", cookbook_path
        )


def _setup_conversion_metadata(cookbook_dir: Path, role_name: str) -> tuple[str, str]:
    """Get cookbook metadata and determine role name."""
    metadata_file = cookbook_dir / METADATA_RB
    cookbook_name = cookbook_dir.name
    if metadata_file.exists():
        metadata = _parse_cookbook_metadata(str(metadata_file))
        name_from_metadata = metadata.get("name")
        if name_from_metadata is not None:
            cookbook_name = str(name_from_metadata)

    if not role_name:
        role_name = cookbook_name

    return cookbook_name, role_name


def _validate_role_name(role_name: str) -> None:
    """
    Validate that role_name is safe for filesystem operations.

    Args:
        role_name: The role name to validate.

    Raises:
        ValueError: If the role name contains unsafe characters.

    """
    if not role_name:
        raise ValueError("Role name cannot be empty")
    if ".." in role_name or "/" in role_name or "\\" in role_name:
        raise ValueError(f"Role name contains unsafe characters: {role_name}")


def _create_role_structure(output_dir: Path, role_name: str) -> Path:
    """Create the standard Ansible role directory structure."""
    # Validate role_name to ensure it's safe for filesystem operations
    _validate_role_name(role_name)

    base = os.path.realpath(str(output_dir))
    role_dir_str = os.path.realpath(os.path.join(base, role_name))  # noqa: PTH111, PTH118
    if os.path.commonpath([base, role_dir_str]) != base:
        raise RuntimeError("Unsafe role path outside output directory")
    role_dir = Path(role_dir_str)
    role_tasks_dir = role_dir / "tasks"
    role_templates_dir = role_dir / "templates"
    role_vars_dir = role_dir / "vars"
    role_defaults_dir = role_dir / "defaults"

    # All paths are validated via os.path.commonpath containment check above
    for directory in [
        role_tasks_dir,
        role_templates_dir,
        role_vars_dir,
        role_defaults_dir,
    ]:
        directory.mkdir(parents=True, exist_ok=True)  # nosonar: S2083

    return role_dir


def _convert_recipes(
    cookbook_dir: Path, role_dir: Path, conversion_summary: dict
) -> None:
    """Convert Chef recipes to Ansible tasks."""
    cookbook_base = os.path.realpath(str(cookbook_dir))
    recipes_dir_str = os.path.realpath(os.path.join(cookbook_base, "recipes"))  # noqa: PTH111, PTH118
    if os.path.commonpath([cookbook_base, recipes_dir_str]) != cookbook_base:
        raise RuntimeError("Unsafe recipes path outside cookbook directory")
    recipes_dir = Path(recipes_dir_str)
    if not recipes_dir.exists():
        conversion_summary["warnings"].append(
            f"No recipes directory found in {cookbook_dir.name}. "
            "Cookbook cannot be converted to Ansible tasks."
        )
        return

    from souschef.converters.playbook import generate_playbook_from_recipe

    recipe_files = safe_glob(recipes_dir, "*.rb", cookbook_dir)
    if not recipe_files:
        conversion_summary["warnings"].append(
            f"No recipe files (*.rb) found in {cookbook_dir.name}/recipes/. "
            "Cookbook has no recipes to convert."
        )
        return

    for recipe_file in recipe_files:
        try:
            validated_recipe = _validated_candidate(recipe_file, recipes_dir)
            recipe_name = validated_recipe.stem

            # Parse recipe to validate it can be processed
            parse_result = _parse_recipe(str(validated_recipe))
            if parse_result.startswith("Error:"):
                conversion_summary["errors"].append(
                    f"Failed to parse recipe {recipe_name}: {parse_result}"
                )
                continue

            # Convert to Ansible tasks
            playbook_yaml = generate_playbook_from_recipe(str(validated_recipe))

            # Write as task file; _safe_join already enforces containment within role_dir
            task_file = _safe_join(role_dir, "tasks", f"{recipe_name}.yml")
            try:
                task_file.parent.mkdir(parents=True, exist_ok=True)  # nosonar
                safe_write_text(task_file, role_dir, playbook_yaml)
            except OSError as write_err:
                conversion_summary["errors"].append(
                    f"Failed to write task file {task_file.name}: {write_err}"
                )
                continue

            conversion_summary["converted_files"].append(
                {
                    "type": "task",
                    "source": f"recipes/{recipe_name}.rb",
                    "target": f"{role_dir.name}/tasks/{recipe_name}.yml",
                }
            )

        except Exception as e:
            conversion_summary["errors"].append(
                f"Error converting recipe {recipe_file.name}: {str(e)}"
            )


def _convert_templates(
    cookbook_dir: Path, role_dir: Path, conversion_summary: dict
) -> None:
    """Convert ERB templates to Jinja2 templates."""
    templates_dir = _safe_join(cookbook_dir, "templates")

    if not templates_dir.exists():
        return

    for template_file in safe_glob(templates_dir, "**/*.erb", cookbook_dir):
        validated_template = template_file
        try:
            # Convert ERB to Jinja2
            validated_template = _validated_candidate(template_file, templates_dir)

            conversion_result = _parse_template(str(validated_template))
            if conversion_result.startswith("Error:"):
                conversion_summary["errors"].append(
                    f"Failed to convert template {validated_template.name}: {conversion_result}"
                )
                continue

            # Parse the JSON result
            try:
                template_data = json.loads(conversion_result)
                jinja2_content = template_data.get("jinja2_template", "")

                # Determine relative path for role templates using _safe_join

                rel_path = validated_template.relative_to(templates_dir)
                # Build target file path with inline containment guard
                target_file = _safe_join(
                    role_dir, "templates", str(rel_path.with_suffix(""))
                )
                target_file.parent.mkdir(parents=True, exist_ok=True)
                safe_write_text(target_file, role_dir, jinja2_content)

                conversion_summary["converted_files"].append(
                    {
                        "type": "template",
                        "source": f"templates/{rel_path}",
                        "target": f"{role_dir.name}/templates/{rel_path.with_suffix('')}",
                    }
                )

            except json.JSONDecodeError:
                conversion_summary["errors"].append(
                    f"Invalid JSON result for template {validated_template.name}"
                )

        except Exception as e:
            conversion_summary["errors"].append(
                f"Error converting template {validated_template.name}: {str(e)}"
            )


def _convert_attributes(
    cookbook_dir: Path, role_dir: Path, conversion_summary: dict
) -> None:
    """Convert Chef attributes to Ansible variables."""
    attributes_dir = _safe_join(cookbook_dir, "attributes")
    role_defaults_dir = _safe_join(role_dir, "defaults")

    if not attributes_dir.exists():
        return

    for attr_file in safe_glob(attributes_dir, "*.rb", cookbook_dir):
        validated_attr = attr_file
        try:
            validated_attr = _validated_candidate(attr_file, attributes_dir)
            # Read the file content
            content = safe_read_text(validated_attr, cookbook_dir)

            # Extract attributes (already imported at top of file)
            raw_attributes = _extract_attributes(content)

            if not raw_attributes:
                conversion_summary["warnings"].append(
                    f"No attributes found in {validated_attr.name}"
                )
                continue

            # Resolve precedence to get final values
            resolved_attributes = _resolve_attribute_precedence(raw_attributes)

            # Convert to Ansible variable format (flatten nested keys)
            ansible_vars = {}
            for attr_path, attr_info in resolved_attributes.items():
                # Convert Chef attribute paths to Ansible variable names
                # e.g., "nginx.port" becomes "nginx_port"
                ansible_key = attr_path.replace(".", "_")
                ansible_vars[ansible_key] = attr_info["value"]

            # Write as defaults using _safe_join to prevent path injection
            # All paths are validated via _safe_join to ensure containment within role_defaults_dir
            defaults_filename: str = f"{validated_attr.stem}.yml"
            defaults_file: Path = _safe_join(role_defaults_dir, defaults_filename)
            defaults_yaml = yaml.dump(ansible_vars, default_flow_style=False, indent=2)
            defaults_file.parent.mkdir(parents=True, exist_ok=True)
            safe_write_text(defaults_file, role_dir, defaults_yaml)

            conversion_summary["converted_files"].append(
                {
                    "type": "defaults",
                    "source": f"attributes/{validated_attr.name}",
                    "target": f"{role_dir.name}/defaults/{validated_attr.stem}.yml",
                }
            )

        except Exception as e:
            conversion_summary["errors"].append(
                f"Error converting attributes {validated_attr.name}: {str(e)}"
            )


def _create_main_task_file(
    cookbook_dir: Path, role_dir: Path, conversion_summary: dict, include_recipes: bool
) -> None:
    """Create main.yml task file from default recipe if it exists."""
    if not include_recipes:
        return

    # Build path to tasks directory safely
    tasks_dir: Path = _safe_join(role_dir, "tasks")
    # Build path to main.yml within tasks directory
    default_task_file: Path = _safe_join(tasks_dir, "main.yml")
    if default_task_file.exists():
        return  # Already exists

    # Build path to default recipe safely
    recipes_dir: Path = _safe_join(cookbook_dir, "recipes")
    default_recipe: Path = _safe_join(recipes_dir, "default.rb")
    if not default_recipe.exists():
        return

    try:
        from souschef.converters.playbook import generate_playbook_from_recipe

        playbook_yaml = generate_playbook_from_recipe(str(default_recipe))
        default_task_file.parent.mkdir(parents=True, exist_ok=True)
        safe_write_text(default_task_file, role_dir, playbook_yaml)
        conversion_summary["converted_files"].append(
            {
                "type": "task",
                "source": "recipes/default.rb",
                "target": f"{role_dir.name}/tasks/main.yml",
            }
        )
    except Exception as e:
        conversion_summary["warnings"].append(
            f"Could not create main.yml from default recipe: {str(e)}"
        )


def _create_role_metadata(
    role_dir: Path,
    role_name: str,
    cookbook_name: str,
    assessment: dict,
    conversion_summary: dict,
) -> None:
    """Create Ansible role metadata file."""
    # Use _safe_join to construct metadata file path

    meta_dir = _safe_join(role_dir, "meta")
    meta_dir.mkdir(parents=True, exist_ok=True)
    meta_file = _safe_join(meta_dir, "main.yml")

    meta_content: dict[str, Any] = {
        "galaxy_info": {
            "role_name": role_name,
            "author": "SousChef Migration",
            "description": f"Converted from Chef cookbook {cookbook_name}",
            "license": "MIT",
            "min_ansible_version": "2.9",
            "platforms": ["ubuntu", "centos", "redhat"],
            "galaxy_tags": ["chef", "migration", "converted"],
        },
        "dependencies": [],
    }

    # Add dependencies from assessment data if available
    if assessment and "dependencies" in assessment:
        deps = assessment["dependencies"]
        if isinstance(deps, list):
            meta_content["dependencies"] = [{"role": dep} for dep in deps]

    meta_yaml = yaml.dump(meta_content, default_flow_style=False, indent=2)
    safe_write_text(meta_file, role_dir, meta_yaml)

    conversion_summary["converted_files"].append(
        {
            "type": "meta",
            "source": METADATA_RB,
            "target": f"{role_name}/meta/main.yml",
        }
    )


def _generate_conversion_report(conversion_summary: dict, role_dir: Path) -> str:
    """Generate a comprehensive conversion report."""
    summary_lines = [
        f"# Cookbook Conversion Summary: {conversion_summary['cookbook_name']} → {conversion_summary['role_name']}",
        "",
        "## Files Converted:",
    ]

    for file_info in conversion_summary["converted_files"]:
        summary_lines.append(
            f"- {file_info['type'].title()}: {file_info['source']} → {file_info['target']}"
        )

    if conversion_summary["errors"]:
        summary_lines.append("")
        summary_lines.append("## Errors:")
        for error in conversion_summary["errors"]:
            summary_lines.append(f"- ERROR: {error}")

    if conversion_summary["warnings"]:
        summary_lines.append("")
        summary_lines.append("## Warnings:")
        for warning in conversion_summary["warnings"]:
            summary_lines.append(f"- WARNING: {warning}")

    summary_lines.append("")
    summary_lines.append(f"## Role Location: {role_dir}")
    summary_lines.append("")
    summary_lines.append("## Next Steps:")
    summary_lines.append("1. Review converted files for accuracy")
    summary_lines.append("2. Test the role with ansible-playbook --check")
    summary_lines.append("3. Update variable references and dependencies")
    summary_lines.append("4. Run integration tests")

    return "\n".join(summary_lines)


@mcp.tool()
def convert_all_cookbooks_comprehensive(
    cookbooks_path: str,
    output_path: str,
    assessment_data: str = "",
    include_templates: bool = True,
    include_attributes: bool = True,
    include_recipes: bool = True,
) -> str:
    """
    Convert all Chef cookbooks in a directory to complete Ansible roles.

    This function performs comprehensive conversion of all Chef cookbooks found in the
    specified directory to Ansible roles, including recipes, templates, attributes,
    and proper role structure. It can use assessment data to optimize the conversion process.

    Args:
        cookbooks_path: Path to the directory containing Chef cookbooks
        output_path: Directory where the Ansible roles will be created
        assessment_data: Optional JSON string with assessment results for optimization
        include_templates: Whether to convert ERB templates to Jinja2 (default: True)
        include_attributes: Whether to convert attributes to Ansible variables (default: True)
        include_recipes: Whether to convert recipes to Ansible tasks (default: True)

    Returns:
        Summary of the conversion process and created files for all cookbooks

    """
    try:
        cookbooks_dir, output_dir = _validate_conversion_paths(
            cookbooks_path, output_path
        )
        assessment = _parse_assessment_data(assessment_data)
        cookbook_dirs = _find_cookbook_directories(cookbooks_dir)

        if not cookbook_dirs:
            return f"Error: No Chef cookbooks found in {cookbooks_path}. Cookbooks must contain a {METADATA_RB} file."

        overall_summary = _initialize_conversion_summary(len(cookbook_dirs))
        _convert_all_cookbooks(
            cookbook_dirs,
            output_dir,
            assessment,
            include_templates,
            include_attributes,
            include_recipes,
            overall_summary,
        )

        return _generate_batch_conversion_report(overall_summary, output_dir)

    except Exception as e:
        return format_error_with_context(
            e, "converting all cookbooks comprehensively", cookbooks_path
        )


def _validate_conversion_paths(
    cookbooks_path: str, output_path: str
) -> tuple[Path, Path]:
    """Validate and return Path objects for conversion paths."""
    base_dir = Path.cwd().resolve()

    cookbooks_candidate = _normalize_path(cookbooks_path)
    try:
        cookbooks_dir = _ensure_within_base_path(cookbooks_candidate, base_dir)
    except ValueError as e:
        raise ValueError(f"Cookbooks path is invalid or outside workspace: {e}") from e

    from souschef.core.path_utils import safe_exists

    if not safe_exists(cookbooks_dir, base_dir):
        raise ValueError(f"Cookbooks path does not exist: {cookbooks_path}")

    output_candidate = _normalize_path(output_path)
    try:
        output_dir = _ensure_within_base_path(output_candidate, base_dir)
    except ValueError as e:
        raise ValueError(f"Output path is invalid or outside workspace: {e}") from e

    return cookbooks_dir, output_dir


def _parse_assessment_data(assessment_data: str) -> dict[Any, Any]:
    """Parse assessment data JSON if provided."""
    if not assessment_data:
        return {}

    try:
        parsed = json.loads(assessment_data)
        return parsed if isinstance(parsed, dict) else {}
    except json.JSONDecodeError as e:
        raise ValueError(f"Invalid assessment data JSON: {assessment_data}") from e


def _find_cookbook_directories(cookbooks_dir: Path) -> list[Path]:
    """Find all cookbook directories containing metadata.rb files."""
    return [
        item
        for item in cookbooks_dir.iterdir()
        if item.is_dir() and (item / METADATA_RB).exists()
    ]


def _initialize_conversion_summary(total_cookbooks: int) -> dict:
    """Initialize the overall conversion summary structure."""
    return {
        "total_cookbooks": total_cookbooks,
        "converted_cookbooks": [],
        "failed_cookbooks": [],
        "total_converted_files": 0,
        "total_errors": 0,
        "total_warnings": 0,
    }


def _convert_all_cookbooks(
    cookbook_dirs: list[Path],
    output_dir: Path,
    assessment: dict,
    include_templates: bool,
    include_attributes: bool,
    include_recipes: bool,
    overall_summary: dict,
) -> None:
    """Convert all cookbooks and update the overall summary."""
    for cookbook_dir in cookbook_dirs:
        try:
            _convert_single_cookbook_comprehensive(
                cookbook_dir,
                output_dir,
                assessment,
                include_templates,
                include_attributes,
                include_recipes,
                overall_summary,
            )
        except Exception as e:
            overall_summary["failed_cookbooks"].append(
                {
                    "cookbook_name": cookbook_dir.name,
                    "error": str(e),
                }
            )


def _convert_single_cookbook_comprehensive(
    cookbook_dir: Path,
    output_dir: Path,
    assessment: dict,
    include_templates: bool,
    include_attributes: bool,
    include_recipes: bool,
    overall_summary: dict,
) -> None:
    """Convert a single cookbook comprehensively."""
    cookbook_name = cookbook_dir.name

    # Get role name from metadata or directory name
    role_name = _get_role_name(cookbook_dir, cookbook_name)

    # Create role directory structure
    role_dir = _create_role_structure(output_dir, role_name)

    # Initialize conversion summary for this cookbook
    conversion_summary = {
        "cookbook_name": cookbook_name,
        "role_name": role_name,
        "converted_files": [],
        "errors": [],
        "warnings": [],
    }

    # Convert components
    if include_recipes:
        _convert_recipes(cookbook_dir, role_dir, conversion_summary)

    if include_templates:
        _convert_templates(cookbook_dir, role_dir, conversion_summary)

    if include_attributes:
        _convert_attributes(cookbook_dir, role_dir, conversion_summary)

    # Create main task file and metadata
    _create_main_task_file(cookbook_dir, role_dir, conversion_summary, include_recipes)
    _create_role_metadata(
        role_dir, role_name, cookbook_name, assessment, conversion_summary
    )

    # Add to overall summary
    overall_summary["converted_cookbooks"].append(
        {
            "cookbook_name": cookbook_name,
            "role_name": role_name,
            "role_path": str(role_dir),
            "converted_files": len(conversion_summary["converted_files"]),
            "errors": len(conversion_summary["errors"]),
            "warnings": len(conversion_summary["warnings"]),
        }
    )

    overall_summary["total_converted_files"] += len(
        conversion_summary["converted_files"]
    )
    overall_summary["total_errors"] += len(conversion_summary["errors"])
    overall_summary["total_warnings"] += len(conversion_summary["warnings"])


def _get_role_name(cookbook_dir: Path, default_name: str) -> str:
    """Get the role name from metadata or return default."""
    metadata_file = cookbook_dir / METADATA_RB
    if metadata_file.exists():
        metadata = _parse_cookbook_metadata(str(metadata_file))
        name = metadata.get("name")
        # Ensure we return a string, handling potential list values
        if name is None:
            return default_name
        if isinstance(name, list):
            return name[0] if name else default_name
        return str(name)
    return default_name


def _generate_batch_conversion_report(overall_summary: dict, output_dir: Path) -> str:
    """Generate a comprehensive batch conversion report."""
    summary_lines = [
        "# Batch Cookbook Conversion Summary",
        "",
        "## Overview:",
        f"- Total cookbooks found: {overall_summary['total_cookbooks']}",
        f"- Successfully converted: {len(overall_summary['converted_cookbooks'])}",
        f"- Failed conversions: {len(overall_summary['failed_cookbooks'])}",
        f"- Total files converted: {overall_summary['total_converted_files']}",
        f"- Total errors: {overall_summary['total_errors']}",
        f"- Total warnings: {overall_summary['total_warnings']}",
        "",
    ]

    if overall_summary["converted_cookbooks"]:
        summary_lines.append("## Successfully Converted Cookbooks:")
        for cookbook in overall_summary["converted_cookbooks"]:
            summary_lines.append(
                f"- **{cookbook['cookbook_name']}** → `{cookbook['role_name']}`"
            )
            summary_lines.append(f"  - Files converted: {cookbook['converted_files']}")
            summary_lines.append(f"  - Errors: {cookbook['errors']}")
            summary_lines.append(f"  - Warnings: {cookbook['warnings']}")
            summary_lines.append(f"  - Location: {cookbook['role_path']}")
            summary_lines.append("")

    if overall_summary["failed_cookbooks"]:
        summary_lines.append("## Failed Conversions:")
        for failed in overall_summary["failed_cookbooks"]:
            summary_lines.append(
                f"- ❌ **{failed['cookbook_name']}**: {failed['error']}"
            )
        summary_lines.append("")

    summary_lines.append(f"## Output Directory: {output_dir}")
    summary_lines.append("")
    summary_lines.append("## Next Steps:")
    summary_lines.append("1. Review converted roles for accuracy")
    summary_lines.append("2. Test roles with ansible-playbook --check")
    summary_lines.append("3. Update variable references and cross-role dependencies")
    summary_lines.append("4. Run integration tests across all converted roles")
    summary_lines.append("5. Consider using Ansible Galaxy for role distribution")

    return "\n".join(summary_lines)


# AWX/AAP deployment wrappers for backward compatibility
def main() -> None:
    """
    Run the SousChef MCP server.

    This is the main entry point for running the server.
    """
    configure_logging()
    mcp.run()


if __name__ == "__main__":
    main()
