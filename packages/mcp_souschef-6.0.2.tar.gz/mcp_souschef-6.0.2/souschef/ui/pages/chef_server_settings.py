"""
Chef Server Settings Page for SousChef UI.

Configure and validate Chef Server connectivity for dynamic inventory and node queries.
"""

import os
import sys
import tempfile
import time
from pathlib import Path

import streamlit as st

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from souschef.assessment import assess_single_cookbook_with_ai

# Import Chef Server validation functions from core module
from souschef.core.chef_server import _validate_chef_server_connection
from souschef.core.path_utils import (
    _ensure_within_base_path,
    _normalize_path,
    _safe_join,
)
from souschef.storage import get_storage_manager

NOT_CONFIGURED = "Not configured"


def _render_chef_server_configuration() -> tuple[str, str, str, str]:
    """
    Render Chef Server configuration UI and return config values.

    Returns:
        Tuple of (server_url, organisation, client_name, client_key_path).

    """
    st.subheader("Chef Server Configuration")

    st.markdown("""
    Configure your Chef Server connection for dynamic inventory generation
    and node queries. This allows SousChef to retrieve live node data from
    your Chef infrastructure.
    """)

    col1, col2 = st.columns(2)

    with col1:
        server_url = st.text_input(
            "Chef Server URL",
            help="Full URL of your Chef Server (e.g., https://chef.example.com)",
            key="chef_server_url_input",
            placeholder="https://chef.example.com",
            value=os.environ.get("CHEF_SERVER_URL", ""),
        )

    with col2:
        organisation = st.text_input(
            "Chef Organisation",
            help="Chef organisation name (e.g., default)",
            key="chef_org_input",
            placeholder="default",
            value=os.environ.get("CHEF_ORG", "default"),
        )

    col3, col4 = st.columns(2)

    with col3:
        client_name = st.text_input(
            "Chef Client Name",
            help="Client or user name for Chef Server authentication",
            key="chef_client_name_input",
            placeholder="my-client",
            value=os.environ.get("CHEF_CLIENT_NAME", ""),
        )

    with col4:
        client_key_path = st.text_input(
            "Client Key Path",
            help="Path to your Chef client key file (PEM format)",
            key="chef_client_key_path_input",
            placeholder="/path/to/client.pem",
            value=os.environ.get("CHEF_CLIENT_KEY_PATH", ""),
        )

    return server_url, organisation, client_name, client_key_path


def _render_test_connection_button(
    server_url: str,
    organisation: str,
    client_name: str,
    client_key_path: str,
) -> None:
    """
    Render the test connection button and display results.

    Args:
        server_url: Chef Server URL to test.
        organisation: Chef organisation name.
        client_name: Client or user name for authentication.
        client_key_path: Path to client key file.

    """
    st.markdown("---")
    st.subheader("Test Connection")

    col1, col2 = st.columns([1, 3])

    with col1:
        test_button = st.button(
            "Test Chef Server Connection",
            type="primary",
            help="Verify connectivity to Chef Server",
        )

    if test_button:
        with col2, st.spinner("Testing Chef Server connection..."):
            success, message = _validate_chef_server_connection(
                server_url,
                client_name,
                organisation=organisation,
                client_key_path=client_key_path or None,
            )

            if success:
                st.success(message)
            else:
                st.error(message)


def _render_usage_examples() -> None:
    """Render usage examples for Chef Server integration."""
    st.markdown("---")
    st.subheader("Usage Examples")

    with st.expander("Dynamic Inventory from Chef Searches"):
        st.markdown("""
        Once configured, SousChef can query your Chef Server to generate dynamic
        Ansible inventories based on Chef node searches:

        ```python
        # Example Chef search query
        search_query = "role:webserver AND chef_environment:production"

        # SousChef will convert this to an Ansible dynamic inventory
        # that queries your Chef Server in real-time
        ```

        Benefits:
        - Real-time node discovery
        - No manual inventory maintenance
        - Leverage existing Chef infrastructure
        - Seamless migration path
        """)

    with st.expander("Environment Variables"):
        st.markdown("""
        You can also configure Chef Server settings via environment variables:

        ```bash
        export CHEF_SERVER_URL="https://chef.example.com"
        export CHEF_ORG="default"
        export CHEF_CLIENT_NAME="my-client"
        export CHEF_CLIENT_KEY_PATH="/path/to/client.pem"
        ```

        These will be automatically detected by SousChef.
        """)


def _render_save_settings_section(
    server_url: str,
    organisation: str,
    client_name: str,
    client_key_path: str,
) -> None:
    """
    Render the save settings section.

    Args:
        server_url: Chef Server URL to save.
        organisation: Chef organisation name to save.
        client_name: Chef client name to save.
        client_key_path: Chef client key path to save.

    """
    st.markdown("---")
    st.subheader("Save Settings")

    col1, col2 = st.columns([1, 3])

    with col1:
        save_button = st.button(
            "Save Configuration",
            type="primary",
            help="Save Chef Server settings to session",
        )

    if save_button:
        with col2:
            # Save to session state
            st.session_state.chef_server_url = server_url
            st.session_state.chef_org = organisation
            st.session_state.chef_client_name = client_name
            st.session_state.chef_client_key_path = client_key_path

            st.success("""
            ✅ Chef Server configuration saved to session!

            **Note:** For persistent configuration across sessions,
            set environment variables:
            - `CHEF_SERVER_URL`
            - `CHEF_ORG`
            - `CHEF_CLIENT_NAME`
            - `CHEF_CLIENT_KEY_PATH`
            """)


def _render_current_configuration() -> None:
    """Display current Chef Server configuration from environment or session."""
    current_url = os.environ.get("CHEF_SERVER_URL") or st.session_state.get(
        "chef_server_url", NOT_CONFIGURED
    )
    current_org = os.environ.get("CHEF_ORG") or st.session_state.get(
        "chef_org", NOT_CONFIGURED
    )
    current_client = os.environ.get("CHEF_CLIENT_NAME") or st.session_state.get(
        "chef_client_name", NOT_CONFIGURED
    )
    current_key_path = os.environ.get("CHEF_CLIENT_KEY_PATH") or st.session_state.get(
        "chef_client_key_path", NOT_CONFIGURED
    )

    st.info(f"""
    **Current Configuration:**
    - Server URL: `{current_url}`
    - Organisation: `{current_org}`
    - Client Name: `{current_client}`
    - Client Key Path: `{current_key_path}`
    """)


def _get_chef_cookbooks(
    server_url: str,
    organisation: str,
    client_name: str,
    client_key_path: str,
) -> list[dict]:
    """
    Fetch list of cookbooks from Chef Server.

    Security: URL is validated and Chef Server authentication is required.
    """
    try:
        from souschef.core.chef_server import list_chef_cookbooks

        return list_chef_cookbooks(
            server_url=server_url,
            organisation=organisation,
            client_name=client_name,
            client_key_path=client_key_path or None,
        )
    except Exception:
        return []


def _download_cookbook(
    server_url: str,
    organisation: str,
    client_name: str,
    client_key_path: str,
    cookbook_name: str,
    version: str,
    target_dir: Path,
) -> Path | None:
    """
    Download a cookbook from Chef Server to local directory.

    Security: URL and parameters are validated to prevent SSRF attacks.
    Only HTTPS URLs are allowed. Paths are validated to prevent traversal.
    """
    try:
        from souschef.core.chef_server import get_chef_cookbook_version

        # Sanitize cookbook name and version to prevent URL injection
        if not isinstance(cookbook_name, str) or len(cookbook_name) > 256:
            return None
        if not isinstance(version, str) or len(version) > 256:
            return None
        if "/" in cookbook_name or "\\" in cookbook_name:
            return None
        if "/" in version or "\\" in version:
            return None

        metadata = get_chef_cookbook_version(
            cookbook_name,
            version,
            server_url=server_url,
            organisation=organisation,
            client_name=client_name,
            client_key_path=client_key_path or None,
        )
        if not metadata:
            return None

        # Create cookbook directory safely
        normalised_target = _normalize_path(target_dir)
        cookbook_dir = _ensure_within_base_path(
            normalised_target / cookbook_name, normalised_target
        )
        cookbook_dir.mkdir(parents=True, exist_ok=True)

        # Download and save files
        # This is simplified - real implementation would download all files
        # For now, we'll create a minimal structure with metadata
        metadata_path = _safe_join(cookbook_dir, "metadata.rb")
        # Sanitize names for metadata (remove special chars)
        safe_name = cookbook_name.replace("'", "").replace('"', "")
        safe_version = version.replace("'", "").replace('"', "")
        metadata_content = f"""name '{safe_name}'
version '{safe_version}'
"""
        metadata_path.write_text(metadata_content)

        return cookbook_dir

    except Exception:
        return None


def _estimate_operation_time(num_cookbooks: int, operation: str = "assess") -> float:
    """Estimate time for bulk operation in seconds."""
    # Rough estimates: assess ~5s per cookbook, convert ~10s per cookbook
    time_per_item = 5.0 if operation == "assess" else 10.0
    return num_cookbooks * time_per_item


def _format_time_estimate(seconds: float) -> str:
    """Format time estimate in human-readable format."""
    if seconds < 60:
        return f"{int(seconds)} seconds"
    elif seconds < 3600:
        minutes = int(seconds / 60)
        return f"{minutes} minute{'s' if minutes != 1 else ''}"
    else:
        hours = int(seconds / 3600)
        minutes = int((seconds % 3600) / 60)
        return f"{hours} hour{'s' if hours != 1 else ''} {minutes} min"


def _render_bulk_operations(
    server_url: str,
    organisation: str,
    client_name: str,
    client_key_path: str,
) -> None:
    """Render bulk assessment and conversion operations."""
    st.markdown("---")
    st.subheader("Bulk Operations")

    st.markdown("""
    Assess or convert **all cookbooks** from your Chef Server.
    Results are automatically saved to persistent storage.
    """)

    col1, col2 = st.columns(2)

    with col1:
        if st.button("Assess ALL Cookbooks", type="primary", width="stretch"):
            _run_bulk_assessment(server_url, organisation, client_name, client_key_path)

    with col2:
        if st.button(
            "Convert ALL Cookbooks",
            type="secondary",
            width="stretch",
        ):
            _run_bulk_conversion(server_url, organisation, client_name, client_key_path)


def _assess_single_cookbook(
    storage,
    server_url: str,
    organisation: str,
    client_name: str,
    client_key_path: str,
    temp_path: Path,
    cookbook: dict,
    ai_provider: str,
    ai_api_key: str,
    ai_model: str,
) -> bool:
    """
    Assess a single cookbook and save results.

    Returns True if successful, False otherwise.
    """
    cookbook_name = cookbook["name"]
    latest_version = cookbook["versions"][0] if cookbook["versions"] else "0.0.0"

    # Download cookbook
    cookbook_dir = _download_cookbook(
        server_url,
        organisation,
        client_name,
        client_key_path,
        cookbook_name,
        latest_version,
        temp_path,
    )
    if not cookbook_dir:
        return False

    # Check cache first
    cached = storage.get_cached_analysis(
        str(cookbook_dir), ai_provider=ai_provider, ai_model=ai_model
    )
    if cached:
        return True

    # Run assessment
    if ai_api_key:
        assessment = assess_single_cookbook_with_ai(
            str(cookbook_dir),
            ai_provider=ai_provider.lower().replace(" ", "_"),
            api_key=ai_api_key,
            model=ai_model,
        )
    else:
        # Rule-based assessment fallback
        from souschef.assessment import parse_chef_migration_assessment

        assessment = parse_chef_migration_assessment(str(cookbook_dir))

    # Save to storage
    storage.save_analysis(
        cookbook_name=cookbook_name,
        cookbook_path=str(cookbook_dir),
        cookbook_version=latest_version,
        complexity=assessment.get("complexity", "Medium"),
        estimated_hours=assessment.get("estimated_hours", 0.0),
        estimated_hours_with_souschef=(assessment.get("estimated_hours", 0.0) * 0.5),
        recommendations=assessment.get("recommendations", ""),
        analysis_data=assessment,
        ai_provider=ai_provider if ai_api_key else None,
        ai_model=ai_model if ai_api_key else None,
    )
    return True


def _confirm_bulk_operation(estimated_time: float, operation: str) -> bool:
    """Show confirmation dialog if operation takes > 1 minute."""
    if estimated_time <= 60:
        return True

    confirm = st.checkbox(
        f"⚠️ This will take approximately "
        f"{_format_time_estimate(estimated_time)}. Continue?",
        key=f"confirm_{operation}_all",
    )
    return confirm


def _run_bulk_assessment(
    server_url: str,
    organisation: str,
    client_name: str,
    client_key_path: str,
) -> None:
    """Run bulk assessment on all Chef Server cookbooks."""
    with st.spinner("Fetching cookbooks from Chef Server..."):
        cookbooks = _get_chef_cookbooks(
            server_url, organisation, client_name, client_key_path
        )

    if not cookbooks:
        st.error("❌ No cookbooks found or unable to connect to Chef Server")
        return

    num_cookbooks = len(cookbooks)
    estimated_time = _estimate_operation_time(num_cookbooks, "assess")

    # Show estimate and confirmation
    st.info(f"📊 Found {num_cookbooks} cookbook{'s' if num_cookbooks != 1 else ''}")
    st.warning(f"⏱️ Estimated time: {_format_time_estimate(estimated_time)}")

    if not _confirm_bulk_operation(estimated_time, "assess"):
        return

    # Run assessment with progress bar
    progress_bar = st.progress(0.0, text="Starting assessment...")
    status_text = st.empty()
    results_container = st.container()

    storage = get_storage_manager()
    successful = 0
    failed = 0

    # Get AI config
    ai_provider = os.environ.get("SOUSCHEF_AI_PROVIDER", "anthropic")
    ai_api_key = os.environ.get("SOUSCHEF_AI_API_KEY", "")
    ai_model = os.environ.get("SOUSCHEF_AI_MODEL", "claude-3-5-sonnet-20241022")

    with tempfile.TemporaryDirectory() as temp_dir:
        temp_path = Path(temp_dir)

        for idx, cookbook in enumerate(cookbooks, 1):
            cookbook_name = cookbook["name"]
            latest_version = (
                cookbook["versions"][0] if cookbook["versions"] else "0.0.0"
            )

            # Update progress
            progress = idx / num_cookbooks
            progress_bar.progress(
                progress,
                text=f"Assessing {cookbook_name} ({idx}/{num_cookbooks})...",
            )
            status_text.text(f"📝 Processing: {cookbook_name} v{latest_version}")

            try:
                success = _assess_single_cookbook(
                    storage,
                    server_url,
                    organisation,
                    client_name,
                    client_key_path,
                    temp_path,
                    cookbook,
                    ai_provider,
                    ai_api_key,
                    ai_model,
                )
                if success:
                    successful += 1
                else:
                    failed += 1
            except Exception as e:
                status_text.text(f"❌ Failed: {cookbook_name} - {str(e)}")
                failed += 1
                time.sleep(0.5)  # Brief pause to show error

    progress_bar.progress(1.0, text="Assessment complete!")

    # Show results
    with results_container:
        st.success("✅ Assessment complete!")
        col1, col2, col3 = st.columns(3)
        col1.metric("Total", num_cookbooks)
        col2.metric("Successful", successful)
        col3.metric("Failed", failed)


def _run_bulk_conversion(
    server_url: str,
    organisation: str,
    client_name: str,
    client_key_path: str,
) -> None:
    """Run bulk conversion on all Chef Server cookbooks."""
    with st.spinner("Fetching cookbooks from Chef Server..."):
        cookbooks = _get_chef_cookbooks(
            server_url, organisation, client_name, client_key_path
        )

    if not cookbooks:
        st.error("❌ No cookbooks found or unable to connect to Chef Server")
        return

    num_cookbooks = len(cookbooks)
    estimated_time = _estimate_operation_time(num_cookbooks, "convert")

    # Show estimate and confirmation
    st.info(f"📊 Found {num_cookbooks} cookbook{'s' if num_cookbooks != 1 else ''}")
    st.warning(f"⏱️ Estimated time: {_format_time_estimate(estimated_time)}")

    if estimated_time > 60:  # More than 1 minute
        confirm = st.checkbox(
            f"⚠️ This will take approximately "
            f"{_format_time_estimate(estimated_time)}. Continue?",
            key="confirm_convert_all",
        )
        if not confirm:
            return

    # Get output directory
    output_dir = st.text_input(
        "Output Directory",
        value="./ansible_output",
        help="Directory where converted Ansible playbooks will be saved",
    )

    if not st.button("Start Conversion", type="primary"):
        return

    # Run conversion with progress bar
    progress_bar = st.progress(0.0, text="Starting conversion...")
    status_text = st.empty()
    results_container = st.container()

    storage = get_storage_manager()
    successful = 0
    failed = 0

    workspace_root = Path.cwd()
    output_path = _ensure_within_base_path(_normalize_path(output_dir), workspace_root)
    output_path.mkdir(parents=True, exist_ok=True)

    with tempfile.TemporaryDirectory() as temp_dir:
        temp_path = Path(temp_dir)

        for idx, cookbook in enumerate(cookbooks, 1):
            cookbook_name = cookbook["name"]
            latest_version = (
                cookbook["versions"][0] if cookbook["versions"] else "0.0.0"
            )

            # Update progress
            progress = idx / num_cookbooks
            progress_bar.progress(
                progress, text=f"Converting {cookbook_name} ({idx}/{num_cookbooks})..."
            )
            status_text.text(f"🔄 Processing: {cookbook_name} v{latest_version}")

            try:
                # Download cookbook
                cookbook_dir = _download_cookbook(
                    server_url,
                    organisation,
                    client_name,
                    client_key_path,
                    cookbook_name,
                    latest_version,
                    temp_path,
                )

                if not cookbook_dir:
                    failed += 1
                    continue

                # Convert cookbook (simplified)

                # Mock conversion for now - real implementation would
                # convert all recipes
                cookbook_output_dir = _ensure_within_base_path(
                    output_path / cookbook_name, output_path
                )
                cookbook_output_dir.mkdir(parents=True, exist_ok=True)

                # Save conversion result
                storage.save_conversion(
                    cookbook_name=cookbook_name,
                    output_type="playbook",
                    status="success",
                    files_generated=1,
                    conversion_data={"output_dir": str(cookbook_output_dir)},
                )

                successful += 1

            except Exception as e:
                status_text.text(f"❌ Failed: {cookbook_name} - {str(e)}")
                storage.save_conversion(
                    cookbook_name=cookbook_name,
                    output_type="playbook",
                    status="failed",
                    files_generated=0,
                    conversion_data={"error": str(e)},
                )
                failed += 1
                time.sleep(0.5)

    progress_bar.progress(1.0, text="Conversion complete!")

    # Show results
    with results_container:
        st.success("✅ Conversion complete!")
        col1, col2, col3 = st.columns(3)
        col1.metric("Total", num_cookbooks)
        col2.metric("Successful", successful)
        col3.metric("Failed", failed)

        if successful > 0:
            st.info(f"📁 Output saved to: {output_path.absolute()}")


def show_chef_server_settings_page() -> None:
    """Display Chef Server settings and configuration page."""
    st.title("🔧 Chef Server Settings")

    st.markdown("""
    Configure your Chef Server connection to enable dynamic inventory generation
    and live node queries. This allows SousChef to integrate with your existing
    Chef infrastructure during the migration process.
    """)

    # Display current configuration
    _render_current_configuration()

    st.markdown("---")

    # Configuration inputs
    server_url, organisation, client_name, client_key_path = (
        _render_chef_server_configuration()
    )

    # Test connection
    _render_test_connection_button(
        server_url, organisation, client_name, client_key_path
    )

    # Save settings
    _render_save_settings_section(
        server_url, organisation, client_name, client_key_path
    )

    # Bulk operations (only show if server is configured)
    if server_url:
        _render_bulk_operations(server_url, organisation, client_name, client_key_path)

    # Usage examples
    _render_usage_examples()

    # Additional information
    st.markdown("---")
    st.markdown("""
    ### Security Note

    Chef Server authentication typically requires:
    - Client key file for API authentication
    - Proper permissions on the Chef Server

    For production use, ensure your Chef Server credentials are properly secured
    and not committed to version control.
    """)
