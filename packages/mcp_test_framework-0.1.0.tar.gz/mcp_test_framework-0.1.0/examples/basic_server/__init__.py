"""Basic calculator server example."""
