from pydantic_settings import BaseSettings
from pydantic import Field
from functools import lru_cache
from typing import Optional

class ERPSettings(BaseSettings):
    """Configuración para la conexión al ERP"""
    
    # Parámetros requeridos
    erp_ip: str = Field(..., validation_alias="ERP_IP")
    erp_port: int = Field(..., validation_alias="ERP_PORT")
    erp_user: str = Field(..., validation_alias="ERP_USER")
    erp_pswd: str = Field(..., validation_alias="ERP_PSWD")
    erp_emges: str = Field(..., validation_alias="ERP_EMGES")
    erp_apl: str = Field(..., validation_alias="ERP_APL")
    erp_emp: str = Field(..., validation_alias="ERP_EMP")

    erp_aplicacion: str = Field(..., validation_alias="ERP_APLICACION")

    # Opcionales con valores por defecto
    erp_timeout: int = Field(30, validation_alias="ERP_TIMEOUT")
    erp_ssl_verify: bool = Field(False, validation_alias="ERP_SSL_VERIFY")
    
    @property
    def base_url(self) -> str:
        """Construye la URL base del ERP"""
        #protocol = "https" if self.erp_port == 443 else "http"
        protocol = "https"
        return f"{protocol}://{self.erp_ip}:{self.erp_port}/api"
    
    @property
    def headers(self) -> dict:
        """Headers por defecto para las peticiones"""
        return {
            'APLICACION': self.erp_aplicacion,
            'USER': self.erp_user,
            'PSWD': self.erp_pswd,
            'EMGES': self.erp_emges,
            'APL': self.erp_apl,
            'EMP': self.erp_emp,
            "Content-Type": "application/json",
            "Accept": "application/json",
            "User-Agent": "ERP-MCP-Server/1.0"
        }
	
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = False

@lru_cache()
def get_settings() -> ERPSettings:
    """Singleton para la configuración"""
    return ERPSettings()