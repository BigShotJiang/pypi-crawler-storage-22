from pydantic_settings import BaseSettings
from pydantic import Field
from functools import lru_cache
from typing import Optional

class ERPSettings(BaseSettings):
    """Configuración para la conexión al ERP"""
    
    # Parámetros requeridos
    erp_ip: str = Field(..., validation_alias="ERP_IP")
    erp_port: int = Field(..., validation_alias="ERP_PORT")
    
    # Parámetros de autenticación (opcionales según el método)
    token: Optional[str] = Field(None, validation_alias="TOKEN")
    erp_user: Optional[str] = Field(None, validation_alias="ERP_USER")
    erp_pswd: Optional[str] = Field(None, validation_alias="ERP_PSWD")
    erp_emges: Optional[str] = Field(None, validation_alias="ERP_EMGES")
    erp_apl: Optional[str] = Field(None, validation_alias="ERP_APL")
    erp_emp: Optional[str] = Field(None, validation_alias="ERP_EMP")
    erp_aplicacion: str = Field("TESTAERP", validation_alias="ERP_APLICACION")

    # Opcionales con valores por defecto
    erp_timeout: int = Field(30, validation_alias="ERP_TIMEOUT")
    erp_ssl_verify: bool = Field(False, validation_alias="ERP_SSL_VERIFY")
    
    @property
    def base_url(self) -> str:
        """Construye la URL base del ERP"""
        #protocol = "https" if self.erp_port == 443 else "http"
        protocol = "https"
        return f"{protocol}://{self.erp_ip}:{self.erp_port}/mcp"
    
    @property
    def headers(self) -> dict:
        """Headers por defecto para las peticiones"""
        base_headers = {
            'APLICACION': self.erp_aplicacion,
            "Content-Type": "application/json",
            "Accept": "application/json",
            "User-Agent": "ERP-MCP-Server/0.1.3"
        }

        if self.token:
            # Autenticación por Token
            base_headers['API-KEY'] = self.token
        else:
            # Autenticación clásica por usuario/password
            base_headers.update({
                'USER': self.erp_user,
                'PSWD': self.erp_pswd,
                'EMGES': self.erp_emges,
                'APL': self.erp_apl,
                'EMP': self.erp_emp,
            })
            
        return base_headers
	
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = False

@lru_cache()
def get_settings() -> ERPSettings:
    """Singleton para la configuración"""
    return ERPSettings()