#!/usr/bin/env python3
import logging
import sys
from mcp.server.fastmcp import FastMCP
from .erp_client import ERPClient

VERSION = "0.1.3"

# Configurar logging para que se vea en stderr (visible en la terminal)
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    stream=sys.stderr  # Importante: enviar a stderr, no a stdout
)

logger = logging.getLogger("erp-mcp-server")
logger.info(f"🚀 Iniciando ERP MCP Server v{VERSION}")

# Crear instancia global
mcp = FastMCP("ERP MCP Server")
erp_client = ERPClient()

@mcp.tool()
async def buscar_cliente(nombre: str) -> str:
    """Busca un cliente por nombre"""
    logger.info(f"🔍 [v{VERSION}] Buscando cliente: {nombre}")
    
    try:
        # Forzar await y verificar tipo
        coro = erp_client.buscar_clientes(nombre)
        logger.debug(f"DEBUG: Tipo de coro: {type(coro)}")
        clientes = await coro
        logger.info(f"✅ Encontrados {len(clientes)} clientes (tipo={type(clientes)})")

        if not clientes:
            logger.warning(f"⚠️ No se encontraron clientes para '{nombre}'")
            return f"No se encontraron clientes con el nombre '{nombre}'"
        
        resultado = f"🔍 **Clientes encontrados para '{nombre}' (v{VERSION}):**\n\n"
        for i, cliente in enumerate(clientes, 1):
            resultado += f"{i}. **{cliente.nombre}**\n"
            resultado += f"   • Código: `{cliente.codigo}`\n"
            if cliente.email:
                resultado += f"   • Email: {cliente.email}\n"
            if cliente.telefono:
                resultado += f"   • Teléfono: {cliente.telefono}\n"
            resultado += "\n"
        
        return resultado
        
    except Exception as e:
        logger.error(f"❌ Error en buscar_cliente: {str(e)}", exc_info=True)
        return f"Error al buscar cliente (v{VERSION}): {str(e)}"

@mcp.tool()
async def buscar_proveedor(nombre: str) -> str:
    """Busca un proveedor por nombre"""
    logger.info(f"🔍 [v{VERSION}] Buscando proveedor: {nombre}")
    
    try:
        proveedores = await erp_client.buscar_proveedores(nombre)
        logger.info(f"✅ Encontrados {len(proveedores)} proveedores")
        
        if not proveedores:
            return f"No se encontraron proveedores con el nombre '{nombre}'"
        
        resultado = f"🔍 **Proveedores encontrados para '{nombre}':**\n\n"
        for i, prov in enumerate(proveedores, 1):
            resultado += f"{i}. **{prov.nombre}**\n"
            resultado += f"   • Código: `{prov.codigo}`\n"
            if prov.email:
                resultado += f"   • Email: {prov.email}\n"
            if prov.telefono:
                resultado += f"   • Teléfono: {prov.telefono}\n"
            resultado += "\n"
        
        return resultado
        
    except Exception as e:
        logger.error(f"❌ Error en buscar_proveedor: {str(e)}", exc_info=True)
        return f"Error al buscar proveedor (v{VERSION}): {str(e)}"

@mcp.tool()
async def buscar_documentos_cliente(
    identificador: str, 
    es_codigo: bool = False
) -> str:
    """Busca documentos de un cliente"""
    logger.info(f"📄 [v{VERSION}] Buscando documentos para cliente: {identificador}")
    
    try:
        codigo_cliente = identificador
        nombre_cliente = None
        
        if not es_codigo:
            clientes = await erp_client.buscar_clientes(identificador)
            if not clientes:
                return f"No se encontró ningún cliente con el nombre '{identificador}'"
            
            if len(clientes) > 1:
                resultado = [f"⚠️ **Múltiples clientes encontrados:**\n"]
                for cliente in clientes:
                    resultado.append(f"• {cliente.nombre} (Código: `{cliente.codigo}`)")
                resultado.append("\nUsa el código con `es_codigo=True`")
                return "\n".join(resultado)
            
            codigo_cliente = clientes[0].codigo
            nombre_cliente = clientes[0].nombre
        
        documentos = await erp_client.obtener_documentos_cliente(codigo_cliente)
        logger.info(f"✅ Encontrados {len(documentos)} documentos")
        
        if not documentos:
            if nombre_cliente:
                return f"El cliente **{nombre_cliente}** no tiene documentos"
            return f"El cliente con código `{codigo_cliente}` no tiene documentos"
        
        if nombre_cliente:
            resultado = [f"📄 **Documentos de {nombre_cliente}:**\n"]
        else:
            resultado = [f"📄 **Documentos del cliente** (código `{codigo_cliente}`):\n"]
        
        for i, doc in enumerate(documentos, 1):
            resultado.append(f"\n{i}. **{doc.tipo} {doc.numero}**")
            resultado.append(f"   • Fecha: {doc.fecha}")
            resultado.append(f"   • Importe: {doc.importe:,.2f} €")
            resultado.append(f"   • Estado: {doc.estado}")
        
        return "\n".join(resultado)
        
    except Exception as e:
        logger.error(f"❌ Error en buscar_documentos_cliente: {str(e)}", exc_info=True)
        return f"Error al buscar documentos (v{VERSION}): {str(e)}"

@mcp.tool()
async def buscar_documentos_proveedor(
    identificador: str, 
    es_codigo: bool = False
) -> str:
    """Busca documentos de un proveedor"""
    logger.info(f"📄 [v{VERSION}] Buscando documentos para proveedor: {identificador}")
    
    try:
        codigo_proveedor = identificador
        nombre_proveedor = None
        
        if not es_codigo:
            proveedores = await erp_client.buscar_proveedores(identificador)
            if not proveedores:
                return f"No se encontró ningún proveedor con el nombre '{identificador}'"
            
            if len(proveedores) > 1:
                resultado = [f"⚠️ **Múltiples proveedores encontrados:**\n"]
                for prov in proveedores:
                    resultado.append(f"• {prov.nombre} (Código: `{prov.codigo}`)")
                resultado.append("\nUsa el código con `es_codigo=True`")
                return "\n".join(resultado)
            
            codigo_proveedor = proveedores[0].codigo
            nombre_proveedor = proveedores[0].nombre
        
        documentos = await erp_client.obtener_documentos_proveedor(codigo_proveedor)
        logger.info(f"✅ Encontrados {len(documentos)} documentos")
        
        if not documentos:
            if nombre_proveedor:
                return f"El proveedor **{nombre_proveedor}** no tiene documentos"
            return f"El proveedor con código `{codigo_proveedor}` no tiene documentos"
        
        if nombre_proveedor:
            resultado = [f"📄 **Documentos de {nombre_proveedor}:**\n"]
        else:
            resultado = [f"📄 **Documentos del proveedor** (código `{codigo_proveedor}`):\n"]
        
        for i, doc in enumerate(documentos, 1):
            resultado.append(f"\n{i}. **{doc.tipo} {doc.numero}**")
            resultado.append(f"   • Fecha: {doc.fecha}")
            resultado.append(f"   • Importe: {doc.importe:,.2f} €")
            resultado.append(f"   • Estado: {doc.estado}")
        
        return "\n".join(resultado)
        
    except Exception as e:
        logger.error(f"❌ Error en buscar_documentos_proveedor: {str(e)}", exc_info=True)
        return f"Error al buscar documentos (v{VERSION}): {str(e)}"

if __name__ == "__main__":
    logger.info(f"🚀 Iniciando servidor MCP ERP v{VERSION}")
    mcp.run()