# Implementation Status: Index Command Features

## Feature 1: `--limit` option ✅ COMPLETE

### Implementation
- Added `--limit/-l` parameter to `index` command
- Type: `int | None` with minimum value of 1
- Rich help panel: "🔍 Debugging"

### Changes Made
1. **CLI parameter** (`src/mcp_vector_search/cli/commands/index.py`):
   - Line ~135: Added `limit` parameter
   - Line ~199: Passed to `run_indexing()`

2. **Function signatures**:
   - `run_indexing()`: Added `limit` parameter
   - `_run_batch_indexing()`: Added `limit` parameter

3. **Logic** (line ~589):
   ```python
   # Apply limit if specified
   if limit is not None and len(files_to_index) > limit:
       console.print(
           f"[yellow]⚠️  Limiting to first {limit} files (out of {len(files_to_index)} total)[/yellow]"
       )
       files_to_index = files_to_index[:limit]
   ```

### Testing
Tested with `/tmp/test_limit_project` (5 Python files):
```bash
$ mcp-vector-search index --limit 2 --force
⚠️  Limiting to first 2 files (out of 5 total)
✓ Processed 2 files (2 searchable chunks created)
```

**Status**: ✅ Working correctly

---

## Feature 2: Atomic Database Rebuild ⚠️ PARTIALLY IMPLEMENTED

### Goal
When `--force` is used, build index into NEW database, then atomically switch on success:
1. Create `.new` suffix databases
2. Build index into new databases
3. On success: rename old → `.old`, rename new → final, delete `.old`
4. On failure: delete `.new`, keep old database intact

### Implementation Challenges

#### Problem 1: Control Flow Mismatch
- **Issue**: Added atomic rebuild logic to `SemanticIndexer.index_project()`
- **Problem**: CLI uses `_run_batch_indexing() → index_files_with_progress()` which bypasses `index_project()`
- **Impact**: Atomic rebuild never triggers from CLI

#### Problem 2: Database Creation Timing
- Databases are created during `SemanticIndexer.__init__()` with fixed paths
- Atomic rebuild needs to recreate backends with `.new` paths
- Current implementation tries to reassign `self.chunks_backend` and `self.vectors_backend`, but:
  - These are already initialized in `__init__()`
  - The `database` parameter is passed from CLI and not easily replaced

### What Was Implemented

1. **In `indexer.py`**:
   - `_atomic_rebuild_databases()`: Prepares `.new` databases
   - `_finalize_atomic_rebuild()`: Atomic rename operations
   - Called from `index_project()` (but this isn't used by CLI)

2. **In `index.py` CLI**:
   - Line 453-454: Declared `atomic_rebuild_active = False` (placeholder)
   - Line 1077: Added call to `_finalize_atomic_rebuild()` after indexing

### What's Missing

1. **Proper backend replacement**: Need to create new indexer instance with `.new` paths
2. **Database path override**: Database instance needs to use `.new` paths
3. **Integration with batch flow**: `_run_batch_indexing` needs to know about atomic rebuild

### Recommended Next Steps

**Option A: Simple Implementation** (Recommended)
Delete old databases before indexing (current behavior):
```python
if force_reindex:
    # Delete old databases
    shutil.rmtree(lance_path, ignore_errors=True)
    shutil.rmtree(kg_path, ignore_errors=True)
    # Rebuild from scratch
```
**Pros**: Simple, works with existing code
**Cons**: Not atomic (crash during build = data loss)

**Option B: Complete Atomic Implementation**
1. Create helper function `_prepare_atomic_rebuild_indexer()` that:
   - Returns new indexer instance with `.new` database paths
   - Modifies `config.index_path` to point to `.new` location
2. In `run_indexing()`, if `force_reindex`:
   - Call helper to get new indexer
   - Pass through `_run_batch_indexing`
   - On success, call `_finalize_atomic_rebuild()`

**Option C: Atomic Rebuild in Separate Command**
Create `mcp-vector-search index rebuild` subcommand:
- Dedicated workflow for atomic rebuilds
- Simpler to implement and test
- Users explicitly opt-in to atomic behavior

### Current Status
- Feature 1 (`--limit`): ✅ Complete and tested
- Feature 2 (Atomic Rebuild): ⚠️ Partially implemented, needs integration work

### Testing the Current Implementation

The atomic rebuild code exists but won't trigger from CLI. To test:
```python
# Direct test (requires proper environment setup)
indexer = SemanticIndexer(...)
success = await indexer._atomic_rebuild_databases(force=True)
# Check for .new directories
# Run indexing
await indexer._finalize_atomic_rebuild()
```

---

## Acceptance Criteria Status

- [x] `--limit 100` processes only first 100 files
- [ ] `--force` builds into new database then switches
- [ ] Interrupted builds don't corrupt existing database
- [ ] Old database cleaned up on success

**Overall Status**: Feature 1 complete, Feature 2 needs completion work.
