import asyncio
from . import main

asyncio.run(main())
