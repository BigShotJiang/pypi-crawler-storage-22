# Community Guidelines

## Be Excellent to One Another

We treat each other with respect and professional courtesy.

## Focus on Code

We judge contributions exclusively on technical merit.

## Scope

We do not moderate or police conduct that occurs outside of this repository's communication channels.
