"""mcpbr - Model Context Protocol Benchmark Runner.

A benchmark runner for evaluating MCP servers against SWE-bench tasks.
"""

__version__ = "0.3.23"
