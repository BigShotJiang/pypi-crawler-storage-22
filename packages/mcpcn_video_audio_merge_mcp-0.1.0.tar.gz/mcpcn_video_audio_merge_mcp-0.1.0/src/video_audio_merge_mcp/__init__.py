"""Video Audio Merge MCP - Merge audio files with video files."""

__version__ = "0.1.0"
