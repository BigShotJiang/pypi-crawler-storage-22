"""
Search providers implementation.

Supports multiple search engines with automatic fallback:
- SerpAPI (Google, Bing, Baidu, Yahoo, Yandex, DuckDuckGo)
- Exa MCP (AI-powered search)
- DuckDuckGo Lite (free, no API key)
- Google News RSS (news-focused)
- Wikipedia OpenSearch (encyclopedia)
"""

from __future__ import annotations

import json
import os
import re
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from typing import Optional
from urllib.parse import parse_qs, quote_plus, unquote, urlparse

import requests
from bs4 import BeautifulSoup


@dataclass
class SearchResult:
    """A single search result."""

    title: str
    url: str
    snippet: str
    source: str

    def to_dict(self) -> dict:
        return {
            "title": self.title,
            "url": self.url,
            "snippet": self.snippet,
            "source": self.source,
        }


@dataclass
class SearchResponse:
    """Response from a search operation."""

    query: str
    results: list[SearchResult]
    source: str
    error: Optional[str] = None

    def to_dict(self) -> dict:
        return {
            "query": self.query,
            "results": [r.to_dict() for r in self.results],
            "source": self.source,
            "error": self.error,
        }

    def to_text(self) -> str:
        """Format results as human-readable text."""
        if self.error:
            return f"Search failed: {self.error}"

        if not self.results:
            return f"No results found for '{self.query}'"

        lines = [f"Search results for '{self.query}' (source: {self.source}):\n"]
        for i, r in enumerate(self.results, 1):
            lines.append(f"{i}. {r.title or r.url}")
            if r.url:
                lines.append(f"   URL: {r.url}")
            if r.snippet:
                lines.append(f"   Snippet: {r.snippet[:200]}")
            lines.append("")

        return "\n".join(lines).rstrip() + "\n"


def _is_cjk(text: str) -> bool:
    """Check if text contains CJK (Chinese/Japanese/Korean) characters."""
    return bool(re.search(r"[\u4e00-\u9fff\u3040-\u309f\u30a0-\u30ff\uac00-\ud7af]", text or ""))


def _clamp_max_results(max_results: int) -> int:
    """Clamp max_results to valid range [1, 20]."""
    try:
        n = int(max_results)
    except (TypeError, ValueError):
        n = 10
    return max(1, min(n, 20))


class SerpAPIProvider:
    """SerpAPI search provider (supports multiple engines)."""

    VALID_ENGINES = {"google", "bing", "baidu", "yahoo", "yandex", "duckduckgo", "google_news"}

    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key or os.environ.get("SERPAPI_API_KEY", "").strip()

    def search(
        self, query: str, max_results: int = 10, engine: str = "google"
    ) -> tuple[list[SearchResult], Optional[str]]:
        """
        Perform search using SerpAPI.

        Args:
            query: Search query
            max_results: Maximum number of results (1-20)
            engine: Search engine (google, bing, baidu, yahoo, yandex, duckduckgo, google_news)

        Returns:
            Tuple of (results, error_reason)
        """
        if not self.api_key:
            return [], "SERPAPI_API_KEY not set"

        engine = engine.lower().strip()
        if engine not in self.VALID_ENGINES:
            engine = "google"

        params = {
            "q": query,
            "api_key": self.api_key,
            "engine": engine,
            "num": min(max_results, 20),
        }

        try:
            resp = requests.get("https://serpapi.com/search", params=params, timeout=20)
            resp.raise_for_status()
            data = resp.json()
        except requests.RequestException as e:
            return [], f"SerpAPI request failed: {e}"
        except json.JSONDecodeError as e:
            return [], f"SerpAPI JSON parse failed: {e}"

        if data.get("error"):
            return [], f"SerpAPI error: {data['error']}"

        results: list[SearchResult] = []

        # Handle Google News specially
        if engine == "google_news":
            for item in data.get("news_results", [])[:max_results]:
                results.append(
                    SearchResult(
                        title=item.get("title", ""),
                        url=item.get("link", ""),
                        snippet=item.get("snippet", item.get("date", "")),
                        source=f"SerpAPI ({engine})",
                    )
                )
            return results, None

        # Standard organic results
        for item in data.get("organic_results", [])[:max_results]:
            results.append(
                SearchResult(
                    title=item.get("title", ""),
                    url=item.get("link", ""),
                    snippet=item.get("snippet", ""),
                    source=f"SerpAPI ({engine})",
                )
            )

        # Include Knowledge Graph if available
        kg = data.get("knowledge_graph")
        if kg and kg.get("title"):
            kg_url = ""
            if isinstance(kg.get("source"), dict):
                kg_url = kg["source"].get("link", "")
            results.insert(
                0,
                SearchResult(
                    title=kg.get("title", ""),
                    url=kg_url,
                    snippet=kg.get("description", ""),
                    source=f"SerpAPI ({engine}) - Knowledge Graph",
                ),
            )

        return results, None


class ExaMCPProvider:
    """Exa MCP search provider (AI-powered search)."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        endpoint: Optional[str] = None,
    ):
        self.api_key = (
            api_key or os.environ.get("EXA_API_KEY", "") or os.environ.get("AGENT_PRO_EXA_API_KEY", "")
        ).strip()
        self.endpoint = (endpoint or os.environ.get("EXA_MCP_URL", "") or "https://mcp.exa.ai/mcp").strip()

    def search(
        self,
        query: str,
        max_results: int = 10,
        search_type: str = "auto",
        livecrawl: str = "fallback",
        context_max_chars: int = 10000,
        timeout: int = 25,
    ) -> tuple[Optional[str], Optional[str]]:
        """
        Perform search using Exa MCP.

        Returns:
            Tuple of (content_text, error_reason)
            - content_text is None if unavailable/failed
        """
        search_type = search_type.lower()
        if search_type not in {"auto", "fast", "deep"}:
            search_type = "auto"

        livecrawl = livecrawl.lower()
        if livecrawl not in {"fallback", "preferred"}:
            livecrawl = "fallback"

        context_max_chars = max(1000, min(context_max_chars, 50000))
        timeout = max(3, min(timeout, 120))

        headers = {
            "accept": "application/json, text/event-stream",
            "content-type": "application/json",
        }
        if self.api_key:
            headers["authorization"] = f"Bearer {self.api_key}"

        payload = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "tools/call",
            "params": {
                "name": "web_search_exa",
                "arguments": {
                    "query": query,
                    "type": search_type,
                    "numResults": int(max_results),
                    "livecrawl": livecrawl,
                    "contextMaxCharacters": context_max_chars,
                },
            },
        }

        try:
            resp = requests.post(self.endpoint, headers=headers, json=payload, timeout=timeout)
        except requests.RequestException as e:
            return None, f"Request failed: {e}"

        if not resp.ok:
            return None, f"Search error ({resp.status_code}): {resp.text[:400]}"

        response_text = resp.text or ""

        # Parse SSE format (data: ...)
        best: Optional[str] = None
        for line in response_text.splitlines():
            line = line.strip()
            if not line.startswith("data: "):
                continue
            data_str = line[6:].strip()
            if not data_str or data_str == "[DONE]":
                continue
            try:
                obj = json.loads(data_str)
                content_arr = (obj.get("result") or {}).get("content") or []
                if isinstance(content_arr, list) and content_arr:
                    first = content_arr[0]
                    if isinstance(first, dict):
                        t = (first.get("text") or "").strip()
                        if t:
                            best = t
            except json.JSONDecodeError:
                continue

        if best:
            return best, None

        # Fallback: try direct JSON (non-SSE)
        try:
            obj = resp.json()
            content_arr = (obj.get("result") or {}).get("content") or []
            if isinstance(content_arr, list) and content_arr and isinstance(content_arr[0], dict):
                t = (content_arr[0].get("text") or "").strip()
                if t:
                    return t, None
        except (json.JSONDecodeError, KeyError):
            pass

        return None, "Failed to parse Exa response (format may have changed or rate limited)"


class DuckDuckGoLiteProvider:
    """DuckDuckGo Lite search provider (free, no API key)."""

    def search(self, query: str, max_results: int = 10) -> tuple[list[SearchResult], Optional[str]]:
        """
        Perform search using DuckDuckGo Lite.

        Returns:
            Tuple of (results, error_reason)
            - results is empty list if CAPTCHA triggered
        """
        url = f"https://lite.duckduckgo.com/lite/?q={quote_plus(query)}"
        headers = {
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Referer": "https://duckduckgo.com/",
            "Connection": "close",
        }

        try:
            resp = requests.get(url, headers=headers, timeout=15)
            resp.raise_for_status()
        except requests.RequestException as e:
            return [], f"Request failed: {e}"

        lower = resp.text.lower()
        if "bots use duckduckgo too" in lower or "please complete the following challenge" in lower:
            return [], "DuckDuckGo CAPTCHA triggered (IP may be rate limited)"

        soup = BeautifulSoup(resp.text, "html.parser")

        results: list[SearchResult] = []
        seen: set[str] = set()

        for a in soup.select("a.result-link"):
            if len(results) >= max_results:
                break

            title = a.get_text(" ", strip=True)
            href = (a.get("href") or "").strip()

            link = href
            if link.startswith("//"):
                link = "https:" + link
            if "uddg=" in link:
                parsed = urlparse(link)
                qs = parse_qs(parsed.query)
                if qs.get("uddg"):
                    link = unquote(qs["uddg"][0] or link)

            if link and link in seen:
                continue
            if link:
                seen.add(link)

            snippet = ""
            tr = a.find_parent("tr")
            if tr:
                for sib in tr.find_next_siblings("tr", limit=2):
                    sn = sib.select_one("td.result-snippet")
                    if sn:
                        snippet = sn.get_text(" ", strip=True)
                        break

            results.append(
                SearchResult(
                    title=title,
                    url=link,
                    snippet=snippet,
                    source="DuckDuckGo Lite",
                )
            )

        return results, None


class GoogleNewsRSSProvider:
    """Google News RSS search provider (news-focused)."""

    def search(self, query: str, max_results: int = 10) -> tuple[list[SearchResult], Optional[str]]:
        """
        Perform search using Google News RSS.

        Automatically detects language and adjusts region settings.
        """
        # Detect language for appropriate region settings
        if _is_cjk(query):
            hl, gl, ceid = "zh-CN", "CN", "CN:zh-Hans"
        else:
            hl, gl, ceid = "en-US", "US", "US:en"

        url = f"https://news.google.com/rss/search?q={quote_plus(query)}&hl={hl}&gl={gl}&ceid={ceid}"
        headers = {
            "User-Agent": "Mozilla/5.0",
            "Accept": "application/rss+xml,application/xml;q=0.9,*/*;q=0.8",
        }

        try:
            resp = requests.get(url, headers=headers, timeout=15)
            resp.raise_for_status()
        except requests.RequestException as e:
            return [], f"Request failed: {e}"

        try:
            root = ET.fromstring(resp.text)
        except ET.ParseError as e:
            return [], f"RSS parse failed: {e}"

        def _strip_html(s: str) -> str:
            s = s or ""
            s = re.sub(r"<[^>]+>", " ", s)
            s = re.sub(r"\s+", " ", s).strip()
            return s

        results: list[SearchResult] = []
        channel = root.find("channel")
        if channel is None:
            return [], None

        for item in channel.findall("item"):
            if len(results) >= max_results:
                break
            title = (item.findtext("title") or "").strip()
            link = (item.findtext("link") or "").strip()
            pub = (item.findtext("pubDate") or "").strip()
            desc = (item.findtext("description") or "").strip()
            snippet = _strip_html(desc)
            if pub:
                snippet = f"{pub} · {snippet}" if snippet else pub
            if not title and not link:
                continue
            results.append(
                SearchResult(
                    title=title,
                    url=link,
                    snippet=snippet,
                    source="Google News RSS",
                )
            )

        return results, None


class WikipediaProvider:
    """Wikipedia OpenSearch provider (encyclopedia/concept queries)."""

    def search(self, query: str, max_results: int = 10) -> tuple[list[SearchResult], Optional[str]]:
        """
        Perform search using Wikipedia OpenSearch.

        Automatically detects language and uses appropriate Wikipedia instance.
        """
        base = "https://zh.wikipedia.org" if _is_cjk(query) else "https://en.wikipedia.org"
        url = f"{base}/w/api.php?action=opensearch&search={quote_plus(query)}&limit={max_results}&namespace=0&format=json"
        headers = {"User-Agent": "Mozilla/5.0", "Accept": "application/json"}

        try:
            resp = requests.get(url, headers=headers, timeout=15)
            resp.raise_for_status()
            data = resp.json()
        except requests.RequestException as e:
            return [], f"Request failed: {e}"
        except json.JSONDecodeError as e:
            return [], f"JSON parse failed: {e}"

        try:
            titles = data[1] if len(data) > 1 else []
            snippets = data[2] if len(data) > 2 else []
            links = data[3] if len(data) > 3 else []
        except (IndexError, TypeError):
            return [], "Unexpected response format"

        results: list[SearchResult] = []
        for i in range(min(len(titles), len(links))):
            title = str(titles[i] or "").strip()
            link = str(links[i] or "").strip()
            snippet = str(snippets[i] or "").strip() if i < len(snippets) else ""
            if not title and not link:
                continue
            results.append(
                SearchResult(
                    title=title,
                    url=link,
                    snippet=snippet,
                    source="Wikipedia",
                )
            )

        return results, None


class MultiSourceSearcher:
    """
    Multi-source web searcher with automatic failover.

    Supports provider priority configuration via environment variables:
    - WEB_SEARCH_SOURCES: Comma-separated list of sources (e.g., "serpapi,ddg_lite,wikipedia")
    - WEB_SEARCH_PROVIDER: Single provider fallback
    """

    # Source name aliases
    SOURCE_ALIASES = {
        "serpapi": "serpapi",
        "serpapi_google": "serpapi_google",
        "serpapi_bing": "serpapi_bing",
        "serpapi_baidu": "serpapi_baidu",
        "serpapi_yahoo": "serpapi_yahoo",
        "exa": "exa_mcp",
        "exa_mcp": "exa_mcp",
        "exa-mcp": "exa_mcp",
        "ddg": "ddg_lite",
        "duckduckgo": "ddg_lite",
        "ddg_lite": "ddg_lite",
        "google_news": "google_news_rss",
        "google_news_rss": "google_news_rss",
        "news": "google_news_rss",
        "wikipedia": "wikipedia",
        "wiki": "wikipedia",
    }

    def __init__(self):
        self.serpapi = SerpAPIProvider()
        self.exa = ExaMCPProvider()
        self.ddg = DuckDuckGoLiteProvider()
        self.google_news = GoogleNewsRSSProvider()
        self.wikipedia = WikipediaProvider()

    def _get_source_priority(self) -> list[str]:
        """Get source priority from environment or use defaults."""
        sources_raw = os.environ.get("WEB_SEARCH_SOURCES", "").strip()
        if not sources_raw:
            sources_raw = os.environ.get("WEB_SEARCH_PROVIDER", "").strip()

        if sources_raw:
            sources = [s.strip().lower() for s in sources_raw.split(",") if s.strip()]
            # Normalize aliases
            return [self.SOURCE_ALIASES.get(s, s) for s in sources]

        # Default priority based on available API keys
        if os.environ.get("SERPAPI_API_KEY"):
            return ["serpapi", "ddg_lite", "google_news_rss"]
        elif os.environ.get("EXA_API_KEY"):
            return ["exa_mcp", "ddg_lite", "google_news_rss", "wikipedia"]
        else:
            return ["ddg_lite", "google_news_rss", "wikipedia"]

    def search(
        self,
        query: str,
        max_results: int = 10,
        sources: Optional[list[str]] = None,
        format: str = "text",
    ) -> SearchResponse:
        """
        Perform web search with automatic failover.

        Args:
            query: Search query
            max_results: Maximum number of results (1-20)
            sources: List of sources to try (uses default priority if not specified)
            format: Output format ("text" or "json")

        Returns:
            SearchResponse with results or error
        """
        max_results = _clamp_max_results(max_results)
        sources = sources or self._get_source_priority()

        errors: list[str] = []

        for src in sources:
            src = self.SOURCE_ALIASES.get(src, src)

            # SerpAPI
            if src.startswith("serpapi"):
                engine = "google"
                if "_" in src:
                    parts = src.split("_", 1)
                    if len(parts) > 1 and parts[1] in SerpAPIProvider.VALID_ENGINES:
                        engine = parts[1]
                results, reason = self.serpapi.search(query, max_results, engine)
                if results:
                    return SearchResponse(
                        query=query,
                        results=results,
                        source=f"SerpAPI ({engine})",
                    )
                if reason:
                    errors.append(f"SerpAPI: {reason}")
                continue

            # Exa MCP
            if src == "exa_mcp":
                content, reason = self.exa.search(query, max_results)
                if content:
                    # Exa returns formatted text, wrap in single result
                    return SearchResponse(
                        query=query,
                        results=[
                            SearchResult(
                                title=f"Exa Search: {query}",
                                url="",
                                snippet=content,
                                source="Exa MCP",
                            )
                        ],
                        source="Exa MCP",
                    )
                if reason:
                    errors.append(f"Exa: {reason}")
                continue

            # DuckDuckGo Lite
            if src == "ddg_lite":
                results, reason = self.ddg.search(query, max_results)
                if results:
                    return SearchResponse(
                        query=query,
                        results=results,
                        source="DuckDuckGo Lite",
                    )
                if reason:
                    errors.append(f"DuckDuckGo: {reason}")
                continue

            # Google News RSS
            if src == "google_news_rss":
                results, reason = self.google_news.search(query, max_results)
                if results:
                    return SearchResponse(
                        query=query,
                        results=results,
                        source="Google News RSS",
                    )
                if reason:
                    errors.append(f"GoogleNewsRSS: {reason}")
                continue

            # Wikipedia
            if src == "wikipedia":
                results, reason = self.wikipedia.search(query, max_results)
                if results:
                    return SearchResponse(
                        query=query,
                        results=results,
                        source="Wikipedia",
                    )
                if reason:
                    errors.append(f"Wikipedia: {reason}")
                continue

            errors.append(f"Unknown source: {src}")

        # All sources failed
        error_detail = "\n".join(f"- {e}" for e in errors) if errors else "No sources available"
        return SearchResponse(
            query=query,
            results=[],
            source="none",
            error=f"All search sources failed or returned no results.\n\nAttempted sources: {', '.join(sources)}\n\nErrors:\n{error_detail}",
        )
