"""
Web Search MCP Server

Exposes multi-source web search capabilities via the Model Context Protocol.

Tools:
    - web_search: Search the internet using multiple providers with automatic failover
    - fetch_webpage: Fetch and extract readable content from a URL

Environment Variables:
    - WEB_SEARCH_SOURCES: Comma-separated provider priority (e.g., "serpapi,ddg_lite,wikipedia")
    - WEB_SEARCH_PROVIDER: Single provider override
    - SERPAPI_API_KEY: API key for SerpAPI
    - EXA_API_KEY: API key for Exa search
    - EXA_MCP_URL: Exa MCP endpoint URL
"""

from __future__ import annotations

import json
import logging
from typing import Annotated, Optional

import requests
from bs4 import BeautifulSoup
from mcp.server.fastmcp import FastMCP
from pydantic import Field

from web_search_mcp.providers import MultiSourceSearcher, _clamp_max_results

logger = logging.getLogger(__name__)

mcp = FastMCP(
    "web-search",
    instructions="Multi-source web search with automatic failover (SerpAPI, DuckDuckGo, Google News, Wikipedia, Exa)",
)

searcher = MultiSourceSearcher()


@mcp.tool()
def web_search(
    query: Annotated[str, Field(description="The search query string")],
    max_results: Annotated[Optional[int], Field(description="Maximum number of results to return (1-20)", default=10)] = 10,
    format: Annotated[Optional[str], Field(description="Output format: 'text' for human-readable or 'json' for structured", default="text")] = "text",
    sources: Annotated[Optional[str], Field(description="Comma-separated sources: serpapi,ddg_lite,google_news_rss,wikipedia,exa_mcp", default="")] = "",
    engine: Annotated[Optional[str], Field(description="SerpAPI engine: google,bing,baidu,yahoo,yandex", default="")] = "",
) -> str:
    """
    Search the internet using multiple search providers with automatic failover.

    Default sources (no API key): DuckDuckGo -> Google News -> Wikipedia
    With SERPAPI_API_KEY: SerpAPI -> DuckDuckGo -> Google News
    """
    # Handle None values
    max_results = max_results if max_results is not None else 10
    format = format if format else "text"
    sources = sources if sources else ""
    engine = engine if engine else ""

    max_results_int = _clamp_max_results(max_results)

    source_list = None
    if sources:
        source_list = [s.strip().lower() for s in sources.split(",") if s.strip()]
        # If engine is specified, prepend serpapi with engine
        if engine and source_list and source_list[0].startswith("serpapi"):
            source_list[0] = f"serpapi_{engine}"

    response = searcher.search(
        query=query,
        max_results=max_results_int,
        sources=source_list,
    )

    # 如果搜索失败，抛出异常让 MCP 返回 isError: true
    if response.error:
        raise Exception(response.to_text())

    fmt = (format or "text").strip().lower()
    if fmt in {"json", "structured"}:
        return json.dumps(response.to_dict(), ensure_ascii=False, indent=2)

    return response.to_text()


@mcp.tool()
def fetch_webpage(
    url: Annotated[str, Field(description="The URL to fetch content from")],
    max_length: Annotated[Optional[int], Field(description="Maximum character length of returned content", default=8000)] = 8000,
) -> str:
    """
    Fetch and extract readable content from a webpage URL.

    Removes scripts, styles, navigation, and other non-content elements.
    Typically used after web_search to get full content from a result URL.
    """
    # Handle None or invalid max_length
    try:
        max_length = int(max_length) if max_length is not None else 8000
    except (TypeError, ValueError):
        max_length = 8000
    max_length = max(1000, min(max_length, 50000))

    try:
        headers = {
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        }
        response = requests.get(url, headers=headers, timeout=15)
        response.raise_for_status()

        soup = BeautifulSoup(response.text, "html.parser")

        # Remove non-content elements
        for tag in soup(["script", "style", "nav", "footer", "header", "aside", "noscript"]):
            tag.decompose()

        # Extract text
        text = soup.get_text(separator="\n", strip=True)

        # Clean up extra blank lines
        lines = [line.strip() for line in text.split("\n") if line.strip()]
        text = "\n".join(lines)

        if len(text) > max_length:
            text = text[:max_length] + "\n\n... (content truncated)"

        return f"Webpage content ({url}):\n\n{text}"

    except requests.RequestException as e:
        raise Exception(f"Failed to fetch webpage: {e}")
    except Exception as e:
        raise Exception(f"Failed to parse webpage: {e}")


def main():
    """Run the MCP server."""
    mcp.run()


if __name__ == "__main__":
    main()
