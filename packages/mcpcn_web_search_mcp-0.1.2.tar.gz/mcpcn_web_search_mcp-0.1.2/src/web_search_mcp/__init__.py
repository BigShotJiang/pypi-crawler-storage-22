"""
Web Search MCP Server

A multi-source web search MCP server with automatic failover support.
"""

__version__ = "0.1.0"
