"""
Search providers implementation.

Supports multiple free search engines with automatic fallback:
- DuckDuckGo Lite (free, no API key)
- Google News RSS (news-focused)
- Wikipedia OpenSearch (encyclopedia)
"""

from __future__ import annotations

import json
import re
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from typing import Optional
from urllib.parse import parse_qs, quote_plus, unquote, urlparse

import requests
from bs4 import BeautifulSoup


@dataclass
class SearchResult:
    """A single search result."""

    title: str
    url: str
    snippet: str
    source: str

    def to_dict(self) -> dict:
        return {
            "title": self.title,
            "url": self.url,
            "snippet": self.snippet,
            "source": self.source,
        }


@dataclass
class SearchResponse:
    """Response from a search operation."""

    query: str
    results: list[SearchResult]
    source: str
    error: Optional[str] = None

    def to_dict(self) -> dict:
        return {
            "query": self.query,
            "results": [r.to_dict() for r in self.results],
            "source": self.source,
            "error": self.error,
        }

    def to_text(self) -> str:
        """Format results as human-readable text."""
        if self.error:
            return f"Search failed: {self.error}"

        if not self.results:
            return f"No results found for '{self.query}'"

        lines = [f"Search results for '{self.query}' (source: {self.source}):\n"]
        for i, r in enumerate(self.results, 1):
            lines.append(f"{i}. {r.title or r.url}")
            if r.url:
                lines.append(f"   URL: {r.url}")
            if r.snippet:
                lines.append(f"   Snippet: {r.snippet[:200]}")
            lines.append("")

        return "\n".join(lines).rstrip() + "\n"


def _is_cjk(text: str) -> bool:
    """Check if text contains CJK (Chinese/Japanese/Korean) characters."""
    return bool(re.search(r"[\u4e00-\u9fff\u3040-\u309f\u30a0-\u30ff\uac00-\ud7af]", text or ""))


def _clamp_max_results(max_results: int) -> int:
    """Clamp max_results to valid range [1, 20]."""
    try:
        n = int(max_results)
    except (TypeError, ValueError):
        n = 10
    return max(1, min(n, 20))


class DuckDuckGoLiteProvider:
    """DuckDuckGo Lite search provider (free, no API key)."""

    def search(self, query: str, max_results: int = 10) -> tuple[list[SearchResult], Optional[str]]:
        """
        Perform search using DuckDuckGo Lite.

        Returns:
            Tuple of (results, error_reason)
            - results is empty list if CAPTCHA triggered
        """
        url = f"https://lite.duckduckgo.com/lite/?q={quote_plus(query)}"
        headers = {
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Referer": "https://duckduckgo.com/",
            "Connection": "close",
        }

        try:
            resp = requests.get(url, headers=headers, timeout=15)
            resp.raise_for_status()
        except requests.RequestException as e:
            return [], f"Request failed: {e}"

        lower = resp.text.lower()
        if "bots use duckduckgo too" in lower or "please complete the following challenge" in lower:
            return [], "DuckDuckGo CAPTCHA triggered (IP may be rate limited)"

        soup = BeautifulSoup(resp.text, "html.parser")

        results: list[SearchResult] = []
        seen: set[str] = set()

        for a in soup.select("a.result-link"):
            if len(results) >= max_results:
                break

            title = a.get_text(" ", strip=True)
            href = (a.get("href") or "").strip()

            link = href
            if link.startswith("//"):
                link = "https:" + link
            if "uddg=" in link:
                parsed = urlparse(link)
                qs = parse_qs(parsed.query)
                if qs.get("uddg"):
                    link = unquote(qs["uddg"][0] or link)

            if link and link in seen:
                continue
            if link:
                seen.add(link)

            snippet = ""
            tr = a.find_parent("tr")
            if tr:
                for sib in tr.find_next_siblings("tr", limit=2):
                    sn = sib.select_one("td.result-snippet")
                    if sn:
                        snippet = sn.get_text(" ", strip=True)
                        break

            results.append(
                SearchResult(
                    title=title,
                    url=link,
                    snippet=snippet,
                    source="DuckDuckGo Lite",
                )
            )

        return results, None


class GoogleNewsRSSProvider:
    """Google News RSS search provider (news-focused)."""

    def search(self, query: str, max_results: int = 10) -> tuple[list[SearchResult], Optional[str]]:
        """
        Perform search using Google News RSS.

        Automatically detects language and adjusts region settings.
        """
        # Detect language for appropriate region settings
        if _is_cjk(query):
            hl, gl, ceid = "zh-CN", "CN", "CN:zh-Hans"
        else:
            hl, gl, ceid = "en-US", "US", "US:en"

        url = f"https://news.google.com/rss/search?q={quote_plus(query)}&hl={hl}&gl={gl}&ceid={ceid}"
        headers = {
            "User-Agent": "Mozilla/5.0",
            "Accept": "application/rss+xml,application/xml;q=0.9,*/*;q=0.8",
        }

        try:
            resp = requests.get(url, headers=headers, timeout=15)
            resp.raise_for_status()
        except requests.RequestException as e:
            return [], f"Request failed: {e}"

        try:
            root = ET.fromstring(resp.text)
        except ET.ParseError as e:
            return [], f"RSS parse failed: {e}"

        def _strip_html(s: str) -> str:
            s = s or ""
            s = re.sub(r"<[^>]+>", " ", s)
            s = re.sub(r"\s+", " ", s).strip()
            return s

        results: list[SearchResult] = []
        channel = root.find("channel")
        if channel is None:
            return [], None

        for item in channel.findall("item"):
            if len(results) >= max_results:
                break
            title = (item.findtext("title") or "").strip()
            link = (item.findtext("link") or "").strip()
            pub = (item.findtext("pubDate") or "").strip()
            desc = (item.findtext("description") or "").strip()
            snippet = _strip_html(desc)
            if pub:
                snippet = f"{pub} · {snippet}" if snippet else pub
            if not title and not link:
                continue
            results.append(
                SearchResult(
                    title=title,
                    url=link,
                    snippet=snippet,
                    source="Google News RSS",
                )
            )

        return results, None


class WikipediaProvider:
    """Wikipedia OpenSearch provider (encyclopedia/concept queries)."""

    def search(self, query: str, max_results: int = 10) -> tuple[list[SearchResult], Optional[str]]:
        """
        Perform search using Wikipedia OpenSearch.

        Automatically detects language and uses appropriate Wikipedia instance.
        """
        base = "https://zh.wikipedia.org" if _is_cjk(query) else "https://en.wikipedia.org"
        url = f"{base}/w/api.php?action=opensearch&search={quote_plus(query)}&limit={max_results}&namespace=0&format=json"
        headers = {"User-Agent": "Mozilla/5.0", "Accept": "application/json"}

        try:
            resp = requests.get(url, headers=headers, timeout=15)
            resp.raise_for_status()
            data = resp.json()
        except requests.RequestException as e:
            return [], f"Request failed: {e}"
        except json.JSONDecodeError as e:
            return [], f"JSON parse failed: {e}"

        try:
            titles = data[1] if len(data) > 1 else []
            snippets = data[2] if len(data) > 2 else []
            links = data[3] if len(data) > 3 else []
        except (IndexError, TypeError):
            return [], "Unexpected response format"

        results: list[SearchResult] = []
        for i in range(min(len(titles), len(links))):
            title = str(titles[i] or "").strip()
            link = str(links[i] or "").strip()
            snippet = str(snippets[i] or "").strip() if i < len(snippets) else ""
            if not title and not link:
                continue
            results.append(
                SearchResult(
                    title=title,
                    url=link,
                    snippet=snippet,
                    source="Wikipedia",
                )
            )

        return results, None


class MultiSourceSearcher:
    """
    Multi-source web searcher with automatic failover.

    Default priority: DuckDuckGo -> Google News -> Wikipedia
    All sources are free and require no API keys.
    """

    # Source name aliases
    SOURCE_ALIASES = {
        "ddg": "ddg_lite",
        "duckduckgo": "ddg_lite",
        "ddg_lite": "ddg_lite",
        "google_news": "google_news_rss",
        "google_news_rss": "google_news_rss",
        "news": "google_news_rss",
        "wikipedia": "wikipedia",
        "wiki": "wikipedia",
    }

    def __init__(self):
        self.ddg = DuckDuckGoLiteProvider()
        self.google_news = GoogleNewsRSSProvider()
        self.wikipedia = WikipediaProvider()

    def _get_source_priority(self) -> list[str]:
        """Get default source priority (all free sources)."""
        return ["ddg_lite", "google_news_rss", "wikipedia"]

    def search(
        self,
        query: str,
        max_results: int = 10,
        sources: Optional[list[str]] = None,
        format: str = "text",
    ) -> SearchResponse:
        """
        Perform web search with automatic failover.

        Args:
            query: Search query
            max_results: Maximum number of results (1-20)
            sources: List of sources to try (uses default priority if not specified)
            format: Output format ("text" or "json")

        Returns:
            SearchResponse with results or error
        """
        max_results = _clamp_max_results(max_results)
        sources = sources or self._get_source_priority()

        errors: list[str] = []

        for src in sources:
            src = self.SOURCE_ALIASES.get(src, src)

            # DuckDuckGo Lite
            if src == "ddg_lite":
                results, reason = self.ddg.search(query, max_results)
                if results:
                    return SearchResponse(
                        query=query,
                        results=results,
                        source="DuckDuckGo Lite",
                    )
                if reason:
                    errors.append(f"DuckDuckGo: {reason}")
                continue

            # Google News RSS
            if src == "google_news_rss":
                results, reason = self.google_news.search(query, max_results)
                if results:
                    return SearchResponse(
                        query=query,
                        results=results,
                        source="Google News RSS",
                    )
                if reason:
                    errors.append(f"GoogleNewsRSS: {reason}")
                continue

            # Wikipedia
            if src == "wikipedia":
                results, reason = self.wikipedia.search(query, max_results)
                if results:
                    return SearchResponse(
                        query=query,
                        results=results,
                        source="Wikipedia",
                    )
                if reason:
                    errors.append(f"Wikipedia: {reason}")
                continue

            errors.append(f"Unknown source: {src}")

        # All sources failed
        error_detail = "\n".join(f"- {e}" for e in errors) if errors else "No sources available"
        return SearchResponse(
            query=query,
            results=[],
            source="none",
            error=f"All search sources failed or returned no results.\n\nAttempted sources: {', '.join(sources)}\n\nErrors:\n{error_detail}",
        )