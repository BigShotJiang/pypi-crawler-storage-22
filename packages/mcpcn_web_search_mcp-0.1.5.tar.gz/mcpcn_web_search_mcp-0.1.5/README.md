# Web Search MCP Server

多源网页搜索 MCP 服务器，支持自动故障转移。专为国内用户优化，无需 VPN 即可使用。

## 特性

- **VPN 自动检测**: 自动检测网络环境，开启 VPN 用国际源，未开启用国内源
- **多搜索源支持**: 国内源（必应中国、百度、搜狗、360）+ 国际源（DuckDuckGo、Google News、Wikipedia）
- **自动故障转移**: 如果一个源失败，自动尝试下一个
- **语言检测**: 自动为中日韩文查询调整搜索参数
- **灵活输出**: 文本（人类可读）或 JSON（结构化）格式
- **网页抓取**: 从 URL 提取可读内容
- **无需 API Key**: 所有搜索源均为免费

## 安装

```bash
# 从源码安装
pip install -e .

# 或使用 uv
uv pip install -e .
```

## 搜索源

| 源 | 描述 | 国内可用 |
|-----|------|---------|
| `bing_china` | 必应中国 (cn.bing.com) | ✅ |
| `baidu` | 百度搜索 | ✅ |
| `sogou` | 搜狗搜索 | ✅ |
| `so360` | 360搜索 (so.com) | ✅ |
| `ddg_lite` | DuckDuckGo Lite | ❌ 需VPN |
| `google_news_rss` | Google News RSS | ❌ 需VPN |
| `wikipedia` | Wikipedia OpenSearch | ❌ 需VPN |

### 默认优先级

**自动检测 VPN 状态：**

- **VPN 开启**: DuckDuckGo → Google News → Wikipedia → 必应中国 → 百度 → 搜狗 → 360
- **VPN 关闭**: 必应中国 → 百度 → 搜狗 → 360

首次搜索时会自动检测网络环境（尝试访问 Google），结果会缓存避免重复检测。

## 使用

### 运行服务器

```bash
# 直接执行
mcpcn-web-search-mcp

# 或通过 Python
python -m web_search_mcp.server
```

### Claude Desktop 配置

添加到 `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "web-search": {
      "command": "mcpcn-web-search-mcp"
    }
  }
}
```

或使用 `uv`:

```json
{
  "mcpServers": {
    "web-search": {
      "command": "uv",
      "args": [
        "--directory",
        "/path/to/web-search-mcp",
        "run",
        "mcpcn-web-search-mcp"
      ]
    }
  }
}
```

## 工具

### web_search

使用多个搜索源搜索互联网，支持自动故障转移。

**参数:**

| 名称 | 类型 | 默认值 | 描述 |
|------|------|--------|------|
| `query` | string | 必填 | 搜索查询词 |
| `max_results` | int | 10 | 最大结果数 (1-20) |
| `format` | string | "text" | 输出格式: "text" 或 "json" |
| `sources` | string | "" | 逗号分隔的源列表 |

**示例:**

```python
# 文本格式（默认）
web_search(query="Python 教程", max_results=5)

# JSON 格式
web_search(query="最新AI新闻", format="json")

# 指定搜索源
web_search(query="机器学习", sources="baidu,bing_china")

# 仅使用国际源
web_search(query="machine learning", sources="ddg_lite,wikipedia")
```

### fetch_webpage

从 URL 获取并提取可读内容。

**参数:**

| 名称 | 类型 | 默认值 | 描述 |
|------|------|--------|------|
| `url` | string | 必填 | 要获取的 URL |
| `max_length` | int | 8000 | 最大内容长度 |

**示例:**

```python
fetch_webpage(url="https://example.com/article")
```

## 架构

```
┌─────────────────────────────────────────────────────────────┐
│                    MCP Server (FastMCP)                      │
├─────────────────────────────────────────────────────────────┤
│  web_search()                    fetch_webpage()             │
│      │                                 │                     │
│      ▼                                 ▼                     │
│  MultiSourceSearcher              requests + BeautifulSoup   │
│      │                                                       │
│      ├──► BingChinaProvider (国内，免费)                     │
│      ├──► BaiduProvider (国内，免费)                         │
│      ├──► SogouProvider (国内，免费)                         │
│      ├──► So360Provider (国内，免费)                         │
│      ├──► DuckDuckGoLiteProvider (国际，免费)                │
│      ├──► GoogleNewsRSSProvider (国际，新闻)                 │
│      └──► WikipediaProvider (国际，百科)                     │
└─────────────────────────────────────────────────────────────┘
```

## 开发

```bash
# 安装开发依赖
pip install -e ".[dev]"

# 运行测试
pytest

# 代码检查
ruff check .
```

## License

MIT