"""
Web Search MCP Server

A multi-source web search MCP server with automatic failover support.
"""

__version__ = "0.1.4"

from web_search_mcp.providers import MultiSourceSearcher, SearchResponse, SearchResult

__all__ = ["MultiSourceSearcher", "SearchResponse", "SearchResult", "__version__"]
