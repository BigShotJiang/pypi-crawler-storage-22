"""
Search providers implementation.

Supports multiple free search engines with automatic fallback:

International (requires VPN in China):
- DuckDuckGo Lite (free, no API key)
- Google News RSS (news-focused)
- Wikipedia OpenSearch (encyclopedia)

Domestic China (no VPN needed):
- Bing China (cn.bing.com)
- Baidu (baidu.com)
- Sogou (sogou.com)
- 360 Search (so.com)
"""

from __future__ import annotations

import json
import logging
import re
import time
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from typing import Optional, Protocol, runtime_checkable
from urllib.parse import parse_qs, quote_plus, unquote, urlparse

import requests
from bs4 import BeautifulSoup

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Common constants
# ---------------------------------------------------------------------------

DEFAULT_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/120.0.0.0 Safari/537.36"
    ),
    "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
}

# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass
class SearchResult:
    """A single search result."""

    title: str
    url: str
    snippet: str
    source: str

    def to_dict(self) -> dict:
        return {
            "title": self.title,
            "url": self.url,
            "snippet": self.snippet,
            "source": self.source,
        }


@dataclass
class SearchResponse:
    """Response from a search operation."""

    query: str
    results: list[SearchResult]
    source: str
    error: Optional[str] = None

    def to_dict(self) -> dict:
        return {
            "query": self.query,
            "results": [r.to_dict() for r in self.results],
            "source": self.source,
            "error": self.error,
        }

    def to_text(self) -> str:
        """Format results as human-readable text."""
        if self.error:
            return f"Search failed: {self.error}"

        if not self.results:
            return f"No results found for '{self.query}'"

        lines = [f"Search results for '{self.query}' (source: {self.source}):\n"]
        for i, r in enumerate(self.results, 1):
            lines.append(f"{i}. {r.title or r.url}")
            if r.url:
                lines.append(f"   URL: {r.url}")
            if r.snippet:
                lines.append(f"   Snippet: {r.snippet[:200]}")
            lines.append("")

        return "\n".join(lines).rstrip() + "\n"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _is_cjk(text: str) -> bool:
    """Check if text contains CJK (Chinese/Japanese/Korean) characters."""
    return bool(re.search(r"[\u4e00-\u9fff\u3040-\u309f\u30a0-\u30ff\uac00-\ud7af]", text or ""))


def _clamp_max_results(max_results: int) -> int:
    """Clamp max_results to valid range [1, 20]."""
    try:
        n = int(max_results)
    except (TypeError, ValueError):
        n = 10
    return max(1, min(n, 20))


# ---------------------------------------------------------------------------
# Provider Protocol
# ---------------------------------------------------------------------------


@runtime_checkable
class SearchProvider(Protocol):
    """All search providers must implement this interface."""

    source_name: str

    def search(self, query: str, max_results: int = 10) -> tuple[list[SearchResult], Optional[str]]:
        """
        Perform search.

        Returns:
            Tuple of (results, error_reason).
            error_reason is None on success.
        """
        ...


# ---------------------------------------------------------------------------
# International providers
# ---------------------------------------------------------------------------


class DuckDuckGoLiteProvider:
    """DuckDuckGo Lite search provider (free, no API key)."""

    source_name = "DuckDuckGo Lite"

    def search(self, query: str, max_results: int = 10) -> tuple[list[SearchResult], Optional[str]]:
        url = f"https://lite.duckduckgo.com/lite/?q={quote_plus(query)}"
        headers = {
            **DEFAULT_HEADERS,
            "Referer": "https://duckduckgo.com/",
            "Connection": "close",
        }

        try:
            resp = requests.get(url, headers=headers, timeout=10)
            resp.raise_for_status()
        except requests.RequestException as e:
            return [], f"Request failed: {e}"

        lower = resp.text.lower()
        if "bots use duckduckgo too" in lower or "please complete the following challenge" in lower:
            return [], "DuckDuckGo CAPTCHA triggered (IP may be rate limited)"

        soup = BeautifulSoup(resp.text, "html.parser")

        results: list[SearchResult] = []
        seen: set[str] = set()

        for a in soup.select("a.result-link"):
            if len(results) >= max_results:
                break

            title = a.get_text(" ", strip=True)
            href = (a.get("href") or "").strip()

            link = href
            if link.startswith("//"):
                link = "https:" + link
            if "uddg=" in link:
                parsed = urlparse(link)
                qs = parse_qs(parsed.query)
                if qs.get("uddg"):
                    link = unquote(qs["uddg"][0] or link)

            if link and link in seen:
                continue
            if link:
                seen.add(link)

            snippet = ""
            tr = a.find_parent("tr")
            if tr:
                for sib in tr.find_next_siblings("tr", limit=2):
                    sn = sib.select_one("td.result-snippet")
                    if sn:
                        snippet = sn.get_text(" ", strip=True)
                        break

            results.append(
                SearchResult(
                    title=title,
                    url=link,
                    snippet=snippet,
                    source=self.source_name,
                )
            )

        if not results and resp.status_code == 200:
            logger.warning("DuckDuckGoLiteProvider: parsed 0 results, page structure may have changed")

        return results, None


class GoogleNewsRSSProvider:
    """Google News RSS search provider (news-focused)."""

    source_name = "Google News RSS"

    def search(self, query: str, max_results: int = 10) -> tuple[list[SearchResult], Optional[str]]:
        if _is_cjk(query):
            hl, gl, ceid = "zh-CN", "CN", "CN:zh-Hans"
        else:
            hl, gl, ceid = "en-US", "US", "US:en"

        url = f"https://news.google.com/rss/search?q={quote_plus(query)}&hl={hl}&gl={gl}&ceid={ceid}"
        headers = {
            "User-Agent": "Mozilla/5.0",
            "Accept": "application/rss+xml,application/xml;q=0.9,*/*;q=0.8",
        }

        try:
            resp = requests.get(url, headers=headers, timeout=10)
            resp.raise_for_status()
        except requests.RequestException as e:
            return [], f"Request failed: {e}"

        try:
            root = ET.fromstring(resp.text)
        except ET.ParseError as e:
            return [], f"RSS parse failed: {e}"

        def _strip_html(s: str) -> str:
            s = s or ""
            s = re.sub(r"<[^>]+>", " ", s)
            s = re.sub(r"\s+", " ", s).strip()
            return s

        results: list[SearchResult] = []
        channel = root.find("channel")
        if channel is None:
            return [], None

        for item in channel.findall("item"):
            if len(results) >= max_results:
                break
            title = (item.findtext("title") or "").strip()
            link = (item.findtext("link") or "").strip()
            pub = (item.findtext("pubDate") or "").strip()
            desc = (item.findtext("description") or "").strip()
            snippet = _strip_html(desc)
            if pub:
                snippet = f"{pub} · {snippet}" if snippet else pub
            if not title and not link:
                continue
            results.append(
                SearchResult(
                    title=title,
                    url=link,
                    snippet=snippet,
                    source=self.source_name,
                )
            )

        return results, None


class WikipediaProvider:
    """Wikipedia OpenSearch provider (encyclopedia/concept queries)."""

    source_name = "Wikipedia"

    def search(self, query: str, max_results: int = 10) -> tuple[list[SearchResult], Optional[str]]:
        base = "https://zh.wikipedia.org" if _is_cjk(query) else "https://en.wikipedia.org"
        url = f"{base}/w/api.php?action=opensearch&search={quote_plus(query)}&limit={max_results}&namespace=0&format=json"
        headers = {"User-Agent": "Mozilla/5.0", "Accept": "application/json"}

        try:
            resp = requests.get(url, headers=headers, timeout=10)
            resp.raise_for_status()
            data = resp.json()
        except requests.RequestException as e:
            return [], f"Request failed: {e}"
        except json.JSONDecodeError as e:
            return [], f"JSON parse failed: {e}"

        try:
            titles = data[1] if len(data) > 1 else []
            snippets = data[2] if len(data) > 2 else []
            links = data[3] if len(data) > 3 else []
        except (IndexError, TypeError):
            return [], "Unexpected response format"

        results: list[SearchResult] = []
        for i in range(min(len(titles), len(links))):
            title = str(titles[i] or "").strip()
            link = str(links[i] or "").strip()
            snippet = str(snippets[i] or "").strip() if i < len(snippets) else ""
            if not title and not link:
                continue
            results.append(
                SearchResult(
                    title=title,
                    url=link,
                    snippet=snippet,
                    source=self.source_name,
                )
            )

        return results, None


# ---------------------------------------------------------------------------
# Domestic China providers
# ---------------------------------------------------------------------------


class BingChinaProvider:
    """Bing China search provider (free, accessible in China)."""

    source_name = "Bing China"

    def search(self, query: str, max_results: int = 10) -> tuple[list[SearchResult], Optional[str]]:
        url = f"https://cn.bing.com/search?q={quote_plus(query)}&count={max_results}"

        try:
            resp = requests.get(url, headers=DEFAULT_HEADERS, timeout=10)
            resp.raise_for_status()
        except requests.RequestException as e:
            return [], f"Request failed: {e}"

        soup = BeautifulSoup(resp.text, "html.parser")
        results: list[SearchResult] = []
        seen: set[str] = set()

        for item in soup.select("li.b_algo"):
            if len(results) >= max_results:
                break

            h2 = item.select_one("h2")
            if not h2:
                continue
            a = h2.select_one("a")
            if not a:
                continue

            title = a.get_text(" ", strip=True)
            link = (a.get("href") or "").strip()

            if not link or link in seen:
                continue
            seen.add(link)

            snippet = ""
            p = item.select_one("p")
            if p:
                snippet = p.get_text(" ", strip=True)

            results.append(
                SearchResult(
                    title=title,
                    url=link,
                    snippet=snippet,
                    source=self.source_name,
                )
            )

        if not results and resp.status_code == 200:
            logger.warning("BingChinaProvider: parsed 0 results, page structure may have changed")

        return results, None


class BaiduProvider:
    """Baidu search provider (free, China's largest search engine)."""

    source_name = "Baidu"

    FILTERED_DOMAINS = [
        "smartapps.baidu.com",
        "baijiahao.baidu.com",
    ]

    def _is_valid_url(self, url: str) -> bool:
        """Check if URL is valid and useful."""
        if not url:
            return False
        if url.startswith("/"):
            return False
        for domain in self.FILTERED_DOMAINS:
            if domain in url:
                return False
        return True

    def _resolve_baidu_link(self, link: str) -> str:
        """Resolve Baidu redirect link to get real URL via HEAD request."""
        if not link.startswith("https://www.baidu.com/link") and not link.startswith("http://www.baidu.com/link"):
            return link
        try:
            resp = requests.head(link, headers=DEFAULT_HEADERS, timeout=3, allow_redirects=True)
            resolved = resp.url
            if resolved and resolved != link:
                logger.debug("Resolved Baidu link: %s -> %s", link, resolved)
                return resolved
        except requests.RequestException:
            logger.debug("Failed to resolve Baidu link: %s, using original", link)
        return link

    def search(self, query: str, max_results: int = 10) -> tuple[list[SearchResult], Optional[str]]:
        request_count = min(max_results + 5, 20)
        url = f"https://www.baidu.com/s?wd={quote_plus(query)}&rn={request_count}"
        headers = {
            **DEFAULT_HEADERS,
            "Cookie": "BAIDUID=0",
        }

        try:
            resp = requests.get(url, headers=headers, timeout=10)
            resp.raise_for_status()
        except requests.RequestException as e:
            return [], f"Request failed: {e}"

        soup = BeautifulSoup(resp.text, "html.parser")
        results: list[SearchResult] = []
        seen: set[str] = set()

        for item in soup.select("div.result, div.c-container"):
            if len(results) >= max_results:
                break

            h3 = item.select_one("h3")
            if not h3:
                continue
            a = h3.select_one("a")
            if not a:
                continue

            title = a.get_text(" ", strip=True)
            link = (a.get("href") or "").strip()

            link = self._resolve_baidu_link(link)

            if not self._is_valid_url(link):
                continue
            if link in seen:
                continue
            seen.add(link)

            snippet = ""
            for selector in ["div.c-abstract", "div.c-span-last", "div.c-row"]:
                elem = item.select_one(selector)
                if elem:
                    snippet = elem.get_text(" ", strip=True)
                    break

            results.append(
                SearchResult(
                    title=title,
                    url=link,
                    snippet=snippet,
                    source=self.source_name,
                )
            )

        if not results and resp.status_code == 200:
            logger.warning("BaiduProvider: parsed 0 results, page structure may have changed")

        return results, None


class SogouProvider:
    """Sogou search provider (free, accessible in China)."""

    source_name = "Sogou"

    def _resolve_sogou_link(self, link: str) -> str:
        """Resolve Sogou redirect link to get real URL via HEAD request."""
        if "sogou.com/link" not in link:
            return link
        try:
            resp = requests.head(link, headers=DEFAULT_HEADERS, timeout=3, allow_redirects=True)
            resolved = resp.url
            if resolved and resolved != link:
                logger.debug("Resolved Sogou link: %s -> %s", link, resolved)
                return resolved
        except requests.RequestException:
            logger.debug("Failed to resolve Sogou link: %s, using original", link)
        return link

    def search(self, query: str, max_results: int = 10) -> tuple[list[SearchResult], Optional[str]]:
        url = f"https://www.sogou.com/web?query={quote_plus(query)}"

        try:
            resp = requests.get(url, headers=DEFAULT_HEADERS, timeout=10)
            resp.raise_for_status()
        except requests.RequestException as e:
            return [], f"Request failed: {e}"

        soup = BeautifulSoup(resp.text, "html.parser")
        results: list[SearchResult] = []
        seen: set[str] = set()

        for item in soup.select("div.vrwrap, div.rb"):
            if len(results) >= max_results:
                break

            h3 = item.select_one("h3")
            if not h3:
                continue
            a = h3.select_one("a")
            if not a:
                continue

            title = a.get_text(" ", strip=True)
            link = (a.get("href") or "").strip()

            if link.startswith("/"):
                link = "https://www.sogou.com" + link

            link = self._resolve_sogou_link(link)

            if not link or link in seen:
                continue
            seen.add(link)

            snippet = ""
            p = item.select_one("p.str-info, div.str-info, p.str_info")
            if p:
                snippet = p.get_text(" ", strip=True)

            results.append(
                SearchResult(
                    title=title,
                    url=link,
                    snippet=snippet,
                    source=self.source_name,
                )
            )

        if not results and resp.status_code == 200:
            logger.warning("SogouProvider: parsed 0 results, page structure may have changed")

        return results, None


class So360Provider:
    """360 Search provider (free, accessible in China)."""

    source_name = "360 Search"

    def search(self, query: str, max_results: int = 10) -> tuple[list[SearchResult], Optional[str]]:
        url = f"https://www.so.com/s?q={quote_plus(query)}"

        try:
            resp = requests.get(url, headers=DEFAULT_HEADERS, timeout=10)
            resp.raise_for_status()
        except requests.RequestException as e:
            return [], f"Request failed: {e}"

        soup = BeautifulSoup(resp.text, "html.parser")
        results: list[SearchResult] = []
        seen: set[str] = set()

        for item in soup.select("li.res-list"):
            if len(results) >= max_results:
                break

            h3 = item.select_one("h3")
            if not h3:
                continue
            a = h3.select_one("a")
            if not a:
                continue

            title = a.get_text(" ", strip=True)
            link = (a.get("href") or "").strip()

            if not link or link in seen:
                continue
            seen.add(link)

            snippet = ""
            p = item.select_one("p.res-desc")
            if p:
                snippet = p.get_text(" ", strip=True)

            results.append(
                SearchResult(
                    title=title,
                    url=link,
                    snippet=snippet,
                    source=self.source_name,
                )
            )

        if not results and resp.status_code == 200:
            logger.warning("So360Provider: parsed 0 results, page structure may have changed")

        return results, None


# ---------------------------------------------------------------------------
# VPN detection (with TTL cache)
# ---------------------------------------------------------------------------

VPN_CACHE_TTL = 300  # 5 minutes

_vpn_cache: dict[str, object] = {"status": None, "checked_at": 0.0}


def _check_vpn_available() -> bool:
    """
    Check if VPN is available by trying to access Google.

    Returns True if international sites are accessible (VPN on),
    False otherwise (no VPN, use domestic sources).
    """
    try:
        resp = requests.head("https://www.google.com", timeout=3)
        return resp.status_code < 400
    except requests.RequestException:
        return False


def _get_vpn_status(force_check: bool = False) -> bool:
    """Get cached VPN status, re-checking if cache has expired."""
    now = time.time()
    cached_at = float(_vpn_cache.get("checked_at", 0))
    if force_check or _vpn_cache["status"] is None or (now - cached_at > VPN_CACHE_TTL):
        status = _check_vpn_available()
        _vpn_cache["status"] = status
        _vpn_cache["checked_at"] = now
        logger.info("VPN status checked: %s", "available" if status else "unavailable")
    return bool(_vpn_cache["status"])


# ---------------------------------------------------------------------------
# Multi-source searcher (registry-based)
# ---------------------------------------------------------------------------


class MultiSourceSearcher:
    """
    Multi-source web searcher with automatic failover.

    Automatically detects VPN status:
    - VPN on: DuckDuckGo -> Google News -> Wikipedia -> Bing China -> Baidu -> Sogou -> 360
    - VPN off: Bing China -> Baidu -> Sogou -> 360

    All sources are free and require no API keys.
    """

    SOURCE_ALIASES: dict[str, str] = {
        # International sources
        "ddg": "ddg_lite",
        "duckduckgo": "ddg_lite",
        "ddg_lite": "ddg_lite",
        "google_news": "google_news_rss",
        "google_news_rss": "google_news_rss",
        "news": "google_news_rss",
        "wikipedia": "wikipedia",
        "wiki": "wikipedia",
        # Domestic China sources
        "bing": "bing_china",
        "bing_cn": "bing_china",
        "bing_china": "bing_china",
        "baidu": "baidu",
        "sogou": "sogou",
        "360": "so360",
        "so": "so360",
        "so360": "so360",
    }

    # Source priority orders
    _VPN_PRIORITY = ["ddg_lite", "google_news_rss", "wikipedia", "bing_china", "baidu", "sogou", "so360"]
    _NO_VPN_PRIORITY = ["bing_china", "baidu", "sogou", "so360"]

    def __init__(self) -> None:
        # Provider registry: canonical name -> provider instance
        self._providers: dict[str, SearchProvider] = {
            "ddg_lite": DuckDuckGoLiteProvider(),
            "google_news_rss": GoogleNewsRSSProvider(),
            "wikipedia": WikipediaProvider(),
            "bing_china": BingChinaProvider(),
            "baidu": BaiduProvider(),
            "sogou": SogouProvider(),
            "so360": So360Provider(),
        }

    def _get_source_priority(self) -> list[str]:
        """Get source priority based on VPN availability."""
        return list(self._VPN_PRIORITY if _get_vpn_status() else self._NO_VPN_PRIORITY)

    def search(
        self,
        query: str,
        max_results: int = 10,
        sources: Optional[list[str]] = None,
    ) -> SearchResponse:
        """
        Perform web search with automatic failover.

        Args:
            query: Search query
            max_results: Maximum number of results (1-20)
            sources: List of sources to try (auto-detect if not specified)

        Returns:
            SearchResponse with results or error
        """
        max_results = _clamp_max_results(max_results)
        source_keys = sources or self._get_source_priority()
        errors: list[str] = []

        for raw_src in source_keys:
            src = self.SOURCE_ALIASES.get(raw_src, raw_src)
            provider = self._providers.get(src)

            if provider is None:
                errors.append(f"Unknown source: {raw_src}")
                continue

            logger.info("Searching '%s' via %s ...", query, provider.source_name)
            results, reason = provider.search(query, max_results)

            if results:
                logger.info("Search completed via %s, %d results", provider.source_name, len(results))
                return SearchResponse(
                    query=query,
                    results=results,
                    source=provider.source_name,
                )

            if reason:
                logger.warning("%s failed: %s, trying next source ...", provider.source_name, reason)
                errors.append(f"{provider.source_name}: {reason}")

        # All sources failed
        error_detail = "\n".join(f"- {e}" for e in errors) if errors else "No sources available"
        return SearchResponse(
            query=query,
            results=[],
            source="none",
            error=(
                f"All search sources failed or returned no results.\n\n"
                f"Attempted sources: {', '.join(source_keys)}\n\n"
                f"Errors:\n{error_detail}"
            ),
        )
