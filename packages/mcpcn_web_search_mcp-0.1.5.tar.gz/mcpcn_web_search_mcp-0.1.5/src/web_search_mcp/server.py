"""
Web Search MCP Server

Exposes multi-source web search capabilities via the Model Context Protocol.

Tools:
    - web_search: Search the internet using multiple free providers with automatic failover
    - fetch_webpage: Fetch and extract readable content from a URL

Supported Free Sources:
    Domestic China (no VPN needed):
    - bing_china: Bing China (cn.bing.com)
    - baidu: Baidu (baidu.com)
    - sogou: Sogou (sogou.com)
    - so360: 360 Search (so.com)

    International (requires VPN in China):
    - ddg_lite: DuckDuckGo Lite
    - google_news_rss: Google News RSS
    - wikipedia: Wikipedia OpenSearch
"""

from __future__ import annotations

import json
import logging
from typing import Annotated, Optional

import requests
from bs4 import BeautifulSoup
from mcp.server.fastmcp import FastMCP
from pydantic import Field

from web_search_mcp.providers import DEFAULT_HEADERS, MultiSourceSearcher, _clamp_max_results

logger = logging.getLogger(__name__)

mcp = FastMCP(
    "web-search",
    instructions=(
        "Free multi-source web search with automatic failover. "
        "Domestic China: Bing China, Baidu, Sogou, 360. "
        "International: DuckDuckGo, Google News, Wikipedia"
    ),
)

searcher = MultiSourceSearcher()


@mcp.tool()
def web_search(
    query: Annotated[str, Field(description="The search query string")],
    max_results: Annotated[
        Optional[int], Field(description="Maximum number of results to return (1-20)", default=10)
    ] = 10,
    format: Annotated[
        Optional[str],
        Field(description="Output format: 'text' for human-readable or 'json' for structured", default="text"),
    ] = "text",
    sources: Annotated[
        Optional[str],
        Field(
            description="Comma-separated sources: bing_china,baidu,sogou,so360,ddg_lite,google_news_rss,wikipedia",
            default="",
        ),
    ] = "",
) -> str:
    """
    Search the internet using multiple free search providers with automatic failover.

    Default sources (China): Bing China -> Baidu -> Sogou -> 360 -> DuckDuckGo -> Google News -> Wikipedia
    """
    # Handle None values
    max_results = max_results if max_results is not None else 10
    format = format if format else "text"
    sources = sources if sources else ""

    max_results_int = _clamp_max_results(max_results)

    source_list = None
    if sources:
        source_list = [s.strip().lower() for s in sources.split(",") if s.strip()]

    response = searcher.search(
        query=query,
        max_results=max_results_int,
        sources=source_list,
    )

    # 如果搜索失败，抛出异常让 MCP 返回 isError: true
    if response.error:
        raise Exception(response.to_text())

    fmt = (format or "text").strip().lower()
    if fmt in {"json", "structured"}:
        return json.dumps(response.to_dict(), ensure_ascii=False, indent=2)

    return response.to_text()


@mcp.tool()
def fetch_webpage(
    url: Annotated[str, Field(description="The URL to fetch content from")],
    max_length: Annotated[
        Optional[int], Field(description="Maximum character length of returned content", default=8000)
    ] = 8000,
) -> str:
    """
    Fetch and extract readable content from a webpage URL.

    Removes scripts, styles, navigation, and other non-content elements.
    Prioritizes <article>/<main> content for better extraction quality.
    Typically used after web_search to get full content from a result URL.
    """
    # Handle None or invalid max_length
    try:
        max_length = int(max_length) if max_length is not None else 8000
    except (TypeError, ValueError):
        max_length = 8000
    max_length = max(1000, min(max_length, 50000))

    try:
        response = requests.get(url, headers=DEFAULT_HEADERS, timeout=15)
        response.raise_for_status()

        # Fix encoding: check Content-Type header first, then fall back to apparent_encoding
        content_type = response.headers.get("Content-Type", "")
        if "charset=" in content_type:
            # Trust explicit charset from server
            pass
        elif response.encoding and response.encoding.lower() in ("iso-8859-1", "latin-1"):
            response.encoding = response.apparent_encoding

        soup = BeautifulSoup(response.text, "html.parser")

        # Remove non-content elements
        for tag in soup(["script", "style", "nav", "footer", "header", "aside", "noscript", "iframe", "svg"]):
            tag.decompose()

        # Prioritize semantic content containers for better extraction
        main_content = soup.select_one("article, main, [role='main'], .article-content, .post-content")
        if main_content:
            text = main_content.get_text(separator="\n", strip=True)
        else:
            text = soup.get_text(separator="\n", strip=True)

        # Clean up extra blank lines
        lines = [line.strip() for line in text.split("\n") if line.strip()]
        text = "\n".join(lines)

        if len(text) > max_length:
            text = text[:max_length] + "\n\n... (content truncated)"

        return f"Webpage content ({url}):\n\n{text}"

    except requests.RequestException as e:
        raise Exception(f"Failed to fetch webpage: {e}")
    except Exception as e:
        raise Exception(f"Failed to parse webpage: {e}")


def main():
    """Run the MCP server."""
    mcp.run()


if __name__ == "__main__":
    main()
