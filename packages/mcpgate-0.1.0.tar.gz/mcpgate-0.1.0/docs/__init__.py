"""Documentation for mcpgate."""
