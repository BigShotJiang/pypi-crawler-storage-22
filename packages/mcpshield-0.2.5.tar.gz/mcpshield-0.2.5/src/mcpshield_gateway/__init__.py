"""MCPShield Gateway - Secure access for AI agents."""

__version__ = "0.2.5"
__author__ = "MCPShield"
