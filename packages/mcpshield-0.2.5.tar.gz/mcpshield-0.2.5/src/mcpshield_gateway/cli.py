"""CLI for MCPShield Gateway."""

import sys
import logging
import argparse
from pathlib import Path

from . import __version__
from .config import GatewayConfig
from .server import MCPServer
from .policy import PolicyEngine
from .postgres import PostgresTools
from .events import EventEmitter


def setup_logging(level: str = "INFO"):
    """Setup logging configuration."""
    logging.basicConfig(
        level=getattr(logging, level.upper()),
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        stream=sys.stderr,  # Log to stderr to keep stdout clean for MCP
    )


def cmd_serve(args):
    """Run the MCP server."""
    try:
        config = GatewayConfig.load(
            config_path=args.config,
            env_file=args.env_file if hasattr(args, 'env_file') else None
        )
        setup_logging(config.log_level)

        logger = logging.getLogger(__name__)
        if args.config:
            logger.info(f"Configuration loaded from: {args.config}")
        else:
            logger.info("Configuration loaded from environment variables")

        server = MCPServer(config)
        server.run()

    except FileNotFoundError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    except ValueError as e:
        print(f"Configuration error: {e}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"Fatal error: {e}", file=sys.stderr)
        sys.exit(1)


def cmd_validate(args):
    """Validate configuration and policy files."""
    setup_logging("INFO")
    logger = logging.getLogger(__name__)

    errors = []
    warnings = []

    # Check config
    try:
        config = GatewayConfig.load(
            config_path=args.config,
            env_file=args.env_file if hasattr(args, 'env_file') else None
        )

        if args.config:
            logger.info(f"✓ Configuration file found: {args.config}")
        else:
            logger.info("✓ Configuration loaded from environment variables")

        logger.info("✓ Configuration loaded successfully")

        # Check policy based on source
        if config.policy_source == "local" and config.policy_file:
            policy_path = Path(config.policy_file).expanduser()
            if not policy_path.exists():
                errors.append(f"Policy file not found: {policy_path}")
            else:
                logger.info(f"✓ Policy file found: {policy_path}")

                try:
                    policy = PolicyEngine(policy_file=config.policy_file)
                    logger.info("✓ Policy loaded successfully")
                    logger.info(f"  - Default decision: {policy.default_decision.value}")
                    logger.info(f"  - Rules: {len(policy.rules)}")
                    logger.info(f"  - Max rows: {policy.max_rows}")
                    logger.info(f"  - Timeout: {policy.timeout_seconds}s")
                    logger.info(f"  - Redaction patterns: {len(policy.redaction_patterns)}")

                    if policy.allow_schemas:
                        logger.info(f"  - Allowed schemas: {', '.join(policy.allow_schemas)}")
                    if policy.allow_tables:
                        logger.info(f"  - Allowed tables: {', '.join(policy.allow_tables)}")

                except Exception as e:
                    errors.append(f"Policy validation error: {e}")
        else:
            logger.info(f"✓ Policy source: {config.policy_source} (will fetch from API)")

    except FileNotFoundError as e:
        errors.append(f"Configuration error: {e}")
    except ValueError as e:
        errors.append(f"Configuration validation error: {e}")
    except Exception as e:
        errors.append(f"Unexpected error: {e}")

    # Print summary
    print("\n" + "=" * 60)
    if errors:
        print("VALIDATION FAILED")
        print("=" * 60)
        for error in errors:
            print(f"✗ {error}")
        sys.exit(1)
    else:
        print("VALIDATION PASSED")
        print("=" * 60)
        if warnings:
            for warning in warnings:
                print(f"⚠ {warning}")
        print("\nYour configuration is ready to use!")
        if args.config:
            print(f"Run: mcpshield serve --config {args.config}")
        else:
            print("Run: mcpshield serve")


def cmd_init(args):
    """Initialize MCPShield Gateway configuration."""
    import json
    from pathlib import Path

    setup_logging("INFO")
    logger = logging.getLogger(__name__)

    print("MCPShield Gateway Setup")
    print("=" * 60)
    print("\nThis wizard will help you set up MCPShield Gateway.\n")

    # Get values from user
    print("1. PostgreSQL Configuration")
    print("-" * 60)
    pg_host = input("PostgreSQL host [localhost]: ").strip() or "localhost"
    pg_port = input("PostgreSQL port [5432]: ").strip() or "5432"
    pg_user = input("PostgreSQL username: ").strip()
    pg_pass = input("PostgreSQL password: ").strip()
    pg_db = input("PostgreSQL database: ").strip()

    if not all([pg_user, pg_pass, pg_db]):
        print("\n✗ PostgreSQL credentials are required!")
        sys.exit(1)

    pg_dsn = f"postgresql://{pg_user}:{pg_pass}@{pg_host}:{pg_port}/{pg_db}"

    print("\n2. MCPShield Configuration")
    print("-" * 60)
    print("Visit https://app.mcpshield.xyz to:")
    print("  1. Create a project")
    print("  2. Generate an API key")
    print("")

    project_id = input("Project ID: ").strip()
    api_key = input("API Key (mcps_...): ").strip()

    if not all([project_id, api_key]):
        print("\n✗ Project ID and API Key are required!")
        sys.exit(1)

    api_base_url = input("API Base URL [https://api.mcpshield.xyz]: ").strip() or "https://api.mcpshield.xyz"

    print("\n3. Installation Target")
    print("-" * 60)
    print("Where do you want to use MCPShield?")
    print("  1. Claude Code")
    print("  2. Cursor")
    print("  3. Both")
    print("  4. Just create .env file")
    choice = input("Choice [1]: ").strip() or "1"

    # Create .env file
    env_path = Path.home() / ".mcpshield" / ".env"
    env_path.parent.mkdir(parents=True, exist_ok=True)

    env_content = f"""# MCPShield Gateway Configuration
# Generated by mcpshield init

# PostgreSQL Connection
PG_DSN={pg_dsn}

# MCPShield API
MCPSHIELD_API_KEY={api_key}
PROJECT_ID={project_id}
API_BASE_URL={api_base_url}

# Policy Configuration
POLICY_SOURCE=remote
POLICY_REFRESH_SECONDS=60

# Logging
LOG_LEVEL=INFO
LOG_DECISIONS=true
"""

    with open(env_path, "w") as f:
        f.write(env_content)

    print(f"\n✓ Configuration saved to: {env_path}")

    # Create MCP server config
    mcp_config = {
        "command": "mcpshield",
        "args": ["serve", "--env-file", str(env_path)],
    }

    if choice in ["1", "3"]:  # Claude Code
        claude_config_path = Path.home() / ".claude" / "mcp.json"
        claude_config_path.parent.mkdir(parents=True, exist_ok=True)

        # Load existing config
        claude_config = {"mcpServers": {}}
        if claude_config_path.exists():
            try:
                with open(claude_config_path, "r") as f:
                    content = f.read().strip()
                    if content:  # Only parse if file has content
                        claude_config = json.loads(content)
                        if "mcpServers" not in claude_config:
                            claude_config["mcpServers"] = {}
            except json.JSONDecodeError:
                logger.warning(f"Invalid JSON in {claude_config_path}, will overwrite")
                claude_config = {"mcpServers": {}}

        # Add mcpshield server
        claude_config["mcpServers"]["mcpshield"] = mcp_config

        # Save
        with open(claude_config_path, "w") as f:
            json.dump(claude_config, f, indent=2)

        print(f"✓ Added to Claude Code: {claude_config_path}")

    if choice in ["2", "3"]:  # Cursor
        cursor_config_path = Path.home() / ".cursor" / "mcp.json"
        cursor_config_path.parent.mkdir(parents=True, exist_ok=True)

        # Load existing config
        cursor_config = {"mcpServers": {}}
        if cursor_config_path.exists():
            try:
                with open(cursor_config_path, "r") as f:
                    content = f.read().strip()
                    if content:  # Only parse if file has content
                        cursor_config = json.loads(content)
                        if "mcpServers" not in cursor_config:
                            cursor_config["mcpServers"] = {}
            except json.JSONDecodeError:
                logger.warning(f"Invalid JSON in {cursor_config_path}, will overwrite")
                cursor_config = {"mcpServers": {}}

        # Add mcpshield server
        cursor_config["mcpServers"]["mcpshield"] = mcp_config

        # Save
        with open(cursor_config_path, "w") as f:
            json.dump(cursor_config, f, indent=2)

        print(f"✓ Added to Cursor: {cursor_config_path}")

    print("\n" + "=" * 60)
    print("SETUP COMPLETE!")
    print("=" * 60)
    print("\nNext steps:")
    print("  1. Create a policy in MCPShield dashboard")
    print("     → https://app.mcpshield.xyz")
    print("  2. Restart your IDE (Claude Code or Cursor)")
    print("  3. Test the connection with: mcpshield doctor --env-file", str(env_path))
    print("\nYou're all set! 🎉")


def cmd_doctor(args):
    """Run diagnostics to check setup."""
    setup_logging("INFO")
    logger = logging.getLogger(__name__)

    print("MCPShield Gateway Doctor")
    print("=" * 60)
    print(f"Version: {__version__}\n")

    errors = []
    warnings = []

    # 1. Check configuration
    print("1. Configuration")
    print("-" * 60)
    try:
        config = GatewayConfig.load(
            config_path=args.config,
            env_file=args.env_file if hasattr(args, 'env_file') else None
        )

        if args.config:
            print(f"✓ Configuration loaded from: {args.config}")
        else:
            print("✓ Configuration loaded from environment variables")

        print(f"  - API Base URL: {config.api_base_url}")
        print(f"  - Project ID: {config.project_id}")
        print(f"  - Policy source: {config.policy_source}")
        if config.policy_file:
            print(f"  - Policy file: {config.policy_file}")
        print(f"  - Cache directory: {config.cache_dir}")
        print(f"  - Spool directory: {config.spool_dir}")
    except FileNotFoundError as e:
        errors.append(f"Configuration error: {e}")
        print(f"✗ {e}")
        sys.exit(1)
    except ValueError as e:
        errors.append(f"Configuration error: {e}")
        print(f"✗ {e}")
        sys.exit(1)

    # 2. Check policy
    print("\n2. Policy")
    print("-" * 60)
    try:
        from .policy_sync import PolicySync

        # Initialize policy sync
        policy_sync = PolicySync(
            api_base_url=config.api_base_url,
            api_key=config.api_key,
            project_id=config.project_id,
            cache_dir=config.get_cache_dir(),
            source=config.policy_source,
            local_file=config.policy_file,
            refresh_seconds=config.policy_refresh_seconds,
        )

        # Try to fetch policy
        policy_yaml, policy_hash = policy_sync.get_policy_yaml()

        # Load policy engine
        policy = PolicyEngine(policy_yaml=policy_yaml)

        print(f"✓ Policy loaded successfully")
        print(f"  - Source: {config.policy_source}")
        print(f"  - Hash: {policy_hash[:16]}...")
        print(f"  - Default: {policy.default_decision.value}")
        print(f"  - Rules: {len(policy.rules)}")

        policy_sync.close()

    except Exception as e:
        errors.append(f"Policy error: {e}")
        print(f"✗ {e}")

    # 3. Check database connectivity
    print("\n3. Database Connectivity")
    print("-" * 60)
    try:
        pg = PostgresTools(config.pg_dsn)
        pg.connect()
        print("✓ Connected to PostgreSQL")

        # Try a simple query
        result = pg.query("SELECT version()")
        print(f"  - Version: {result['rows'][0]['version'][:50]}...")
        pg.close()
    except Exception as e:
        errors.append(f"Database connection error: {e}")
        print(f"✗ {e}")

    # 4. Check API connectivity
    print("\n4. API Connectivity")
    print("-" * 60)
    try:
        import httpx
        client = httpx.Client(timeout=10.0)

        # Try health check first
        health_url = f"{config.api_base_url}/health"
        try:
            response = client.get(health_url)
            if response.status_code == 200:
                print(f"✓ API is reachable: {config.api_base_url}")
            else:
                warnings.append(f"API returned {response.status_code} for health check")
                print(f"⚠ API health check returned {response.status_code}")
        except Exception as e:
            errors.append(f"Cannot reach API: {e}")
            print(f"✗ Cannot reach API: {e}")

        # Test authentication by checking if policy fetch works
        # We already tested policy fetch in step 2, so just verify auth header works
        try:
            # Try to access a simple authenticated endpoint
            policy_url = f"{config.api_base_url}/projects/{config.project_id}/policy"
            response = client.get(
                policy_url,
                headers={"X-API-Key": config.api_key}
            )

            if response.status_code == 200:
                print("✓ API authentication successful")
            elif response.status_code == 401:
                errors.append("API authentication failed (401 - invalid API key)")
                print("✗ API authentication failed (401)")
            elif response.status_code == 403:
                errors.append("API authentication failed (403 - access denied)")
                print("✗ API authentication failed (403)")
            elif response.status_code == 404:
                warnings.append("Policy not found (404 - create policy in dashboard)")
                print("⚠ Policy not found (404)")
            else:
                # Auth likely worked if we get other status codes
                print("✓ API authentication successful")
                if response.status_code != 200:
                    warnings.append(f"Policy endpoint returned {response.status_code}")

        except Exception as e:
            warnings.append(f"API authentication test failed: {e}")
            print(f"⚠ API test failed: {e}")

        client.close()
    except Exception as e:
        errors.append(f"API check error: {e}")
        print(f"✗ {e}")

    # 5. Check spool directory
    print("\n5. Event Spooling")
    print("-" * 60)
    try:
        spool_dir = config.get_spool_dir()
        if not spool_dir.exists():
            spool_dir.mkdir(parents=True, exist_ok=True)
            print(f"✓ Created spool directory: {spool_dir}")
        else:
            print(f"✓ Spool directory exists: {spool_dir}")

        # Check for spooled events
        spool_files = list(spool_dir.glob("*.jsonl"))
        if spool_files:
            warnings.append(f"{len(spool_files)} spooled event files found")
            print(f"⚠ {len(spool_files)} spooled event files (will retry on next run)")
        else:
            print("  - No spooled events")

    except Exception as e:
        errors.append(f"Spool directory error: {e}")
        print(f"✗ {e}")

    # Summary
    print("\n" + "=" * 60)
    if errors:
        print("DIAGNOSTICS FAILED")
        print("=" * 60)
        print("\nErrors found:")
        for error in errors:
            print(f"  ✗ {error}")

        if warnings:
            print("\nWarnings:")
            for warning in warnings:
                print(f"  ⚠ {warning}")

        print("\nPlease fix the errors above before running the gateway.")
        sys.exit(1)
    else:
        print("DIAGNOSTICS PASSED")
        print("=" * 60)

        if warnings:
            print("\nWarnings:")
            for warning in warnings:
                print(f"  ⚠ {warning}")

        print("\n✓ Your gateway is ready to use!")
        print("\nNext steps:")
        print("  1. Add to Claude Code MCP configuration")
        if args.config:
            print(f"  2. Run: mcpshield serve --config {args.config}")
        else:
            print("  2. Run: mcpshield serve")
        print("  3. Test with a SELECT query")


def main():
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        prog="mcpshield",
        description="MCPShield Gateway - Secure PostgreSQL access for AI agents",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"mcpshield {__version__}",
    )

    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # serve command
    serve_parser = subparsers.add_parser(
        "serve",
        help="Run the MCP server",
    )
    serve_parser.add_argument(
        "--config",
        required=False,
        help="Path to configuration file (mcpshield.yaml). If not provided, uses environment variables.",
    )
    serve_parser.add_argument(
        "--env-file",
        dest="env_file",
        required=False,
        help="Path to .env file for loading environment variables (optional)",
    )
    serve_parser.set_defaults(func=cmd_serve)

    # validate command
    validate_parser = subparsers.add_parser(
        "validate",
        help="Validate configuration and policy files",
    )
    validate_parser.add_argument(
        "--config",
        required=False,
        help="Path to configuration file (mcpshield.yaml). If not provided, uses environment variables.",
    )
    validate_parser.add_argument(
        "--env-file",
        dest="env_file",
        required=False,
        help="Path to .env file for loading environment variables (optional)",
    )
    validate_parser.set_defaults(func=cmd_validate)

    # init command
    init_parser = subparsers.add_parser(
        "init",
        help="Initialize MCPShield Gateway configuration (interactive setup wizard)",
    )
    init_parser.set_defaults(func=cmd_init)

    # doctor command
    doctor_parser = subparsers.add_parser(
        "doctor",
        help="Run diagnostics to check setup",
    )
    doctor_parser.add_argument(
        "--config",
        required=False,
        help="Path to configuration file (mcpshield.yaml). If not provided, uses environment variables.",
    )
    doctor_parser.add_argument(
        "--env-file",
        dest="env_file",
        required=False,
        help="Path to .env file for loading environment variables (optional)",
    )
    doctor_parser.set_defaults(func=cmd_doctor)

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(1)

    args.func(args)


if __name__ == "__main__":
    main()
