"""Configuration handling for MCPShield Gateway."""

import os
import yaml
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Dict, Any


@dataclass
class GatewayConfig:
    """Gateway configuration."""

    # Database
    pg_dsn: str

    # MCPShield API
    api_base_url: str
    project_id: str
    api_key: str

    # Policy
    policy_source: str = "remote_with_fallback"  # remote, local, remote_with_fallback
    policy_file: Optional[str] = None
    policy_refresh_seconds: int = 60

    # Cache
    cache_dir: str = "~/.mcpshield/cache"

    # Spooling
    spool_dir: str = "~/.mcpshield/spool"

    # Logging
    log_level: str = "INFO"
    log_decisions: bool = True

    # Event batching
    batch_size: int = 10
    batch_timeout: int = 5

    @classmethod
    def from_yaml(cls, config_path: str) -> "GatewayConfig":
        """Load configuration from YAML file and environment variables."""
        config_path = Path(config_path).expanduser()

        if not config_path.exists():
            raise FileNotFoundError(f"Configuration file not found: {config_path}")

        with open(config_path, "r") as f:
            data = yaml.safe_load(f) or {}

        # Environment variables take precedence
        pg_dsn = os.getenv("PG_DSN") or os.getenv("DATABASE_URL") or data.get("database", {}).get("dsn")
        if not pg_dsn:
            raise ValueError("Database DSN not configured (set PG_DSN or DATABASE_URL)")

        api_base_url = os.getenv("API_BASE_URL") or data.get("api", {}).get("base_url")
        if not api_base_url:
            raise ValueError("API base URL not configured (set API_BASE_URL)")

        project_id = os.getenv("PROJECT_ID") or data.get("api", {}).get("project_id")
        if not project_id:
            raise ValueError("Project ID not configured (set PROJECT_ID)")

        api_key = os.getenv("MCPSHIELD_API_KEY") or data.get("api", {}).get("api_key")
        if not api_key:
            raise ValueError("API key not configured (set MCPSHIELD_API_KEY)")

        policy_source = data.get("policy", {}).get("source", "remote_with_fallback")
        policy_file = data.get("policy", {}).get("file")
        policy_refresh_seconds = data.get("policy", {}).get("refresh_seconds", 60)

        # Optional settings
        cache_dir = data.get("cache", {}).get("dir", "~/.mcpshield/cache")
        spool_dir = data.get("events", {}).get("spool_dir", "~/.mcpshield/spool")
        log_level = data.get("logging", {}).get("level", "INFO")
        log_decisions = data.get("logging", {}).get("log_decisions", True)
        batch_size = data.get("events", {}).get("batch_size", 10)
        batch_timeout = data.get("events", {}).get("batch_timeout_seconds", 5)

        return cls(
            pg_dsn=pg_dsn,
            api_base_url=api_base_url,
            project_id=project_id,
            api_key=api_key,
            policy_source=policy_source,
            policy_file=policy_file,
            policy_refresh_seconds=policy_refresh_seconds,
            cache_dir=cache_dir,
            spool_dir=spool_dir,
            log_level=log_level,
            log_decisions=log_decisions,
            batch_size=batch_size,
            batch_timeout=batch_timeout,
        )

    @classmethod
    def from_env(cls, env_file: Optional[str] = None) -> "GatewayConfig":
        """
        Load configuration from environment variables only.

        Args:
            env_file: Optional path to .env file to load first

        Required environment variables:
            - PROJECT_ID
            - MCPSHIELD_API_KEY
            - PG_DSN (or DATABASE_URL)

        Optional environment variables:
            - API_BASE_URL (default: https://api.mcpshield.xyz)
            - POLICY_SOURCE (default: remote)
            - POLICY_FILE (optional, for fallback)
            - POLICY_REFRESH_SECONDS (default: 60)
            - SPOOL_DIR (default: ~/.mcpshield/spool)
            - POLICY_CACHE_DIR (default: ~/.mcpshield/cache)
            - LOG_LEVEL (default: INFO)
            - LOG_DECISIONS (default: true)
            - BATCH_SIZE (default: 10)
            - BATCH_TIMEOUT (default: 5)
        """
        # Load .env file if provided
        if env_file:
            cls._load_env_file(env_file)

        # Required variables
        pg_dsn = os.getenv("PG_DSN") or os.getenv("DATABASE_URL")
        if not pg_dsn:
            raise ValueError(
                "Database DSN not configured. Set PG_DSN or DATABASE_URL environment variable.\n"
                "Example: export PG_DSN='postgresql://user:pass@localhost/db'"
            )

        project_id = os.getenv("PROJECT_ID")
        if not project_id:
            raise ValueError(
                "Project ID not configured. Set PROJECT_ID environment variable.\n"
                "Example: export PROJECT_ID='your-project-id'"
            )

        api_key = os.getenv("MCPSHIELD_API_KEY")
        if not api_key:
            raise ValueError(
                "API key not configured. Set MCPSHIELD_API_KEY environment variable.\n"
                "Example: export MCPSHIELD_API_KEY='your-api-key'"
            )

        # Optional variables with defaults
        api_base_url = os.getenv("API_BASE_URL", "https://api.mcpshield.xyz")
        policy_source = os.getenv("POLICY_SOURCE", "remote")
        policy_file = os.getenv("POLICY_FILE")

        try:
            policy_refresh_seconds = int(os.getenv("POLICY_REFRESH_SECONDS", "60"))
        except ValueError:
            policy_refresh_seconds = 60

        cache_dir = os.getenv("POLICY_CACHE_DIR", "~/.mcpshield/cache")
        spool_dir = os.getenv("SPOOL_DIR", "~/.mcpshield/spool")
        log_level = os.getenv("LOG_LEVEL", "INFO")

        log_decisions_str = os.getenv("LOG_DECISIONS", "true").lower()
        log_decisions = log_decisions_str in ("true", "1", "yes")

        try:
            batch_size = int(os.getenv("BATCH_SIZE", "10"))
        except ValueError:
            batch_size = 10

        try:
            batch_timeout = int(os.getenv("BATCH_TIMEOUT", "5"))
        except ValueError:
            batch_timeout = 5

        return cls(
            pg_dsn=pg_dsn,
            api_base_url=api_base_url,
            project_id=project_id,
            api_key=api_key,
            policy_source=policy_source,
            policy_file=policy_file,
            policy_refresh_seconds=policy_refresh_seconds,
            cache_dir=cache_dir,
            spool_dir=spool_dir,
            log_level=log_level,
            log_decisions=log_decisions,
            batch_size=batch_size,
            batch_timeout=batch_timeout,
        )

    @classmethod
    def load(cls, config_path: Optional[str] = None, env_file: Optional[str] = None) -> "GatewayConfig":
        """
        Load configuration with priority: env vars > YAML (if provided) > defaults.

        Args:
            config_path: Optional path to YAML config file
            env_file: Optional path to .env file

        Returns:
            GatewayConfig instance
        """
        if config_path:
            # Load from YAML (env vars still take precedence within from_yaml)
            return cls.from_yaml(config_path)
        else:
            # Load from env only
            return cls.from_env(env_file=env_file)

    @staticmethod
    def _load_env_file(env_file: str):
        """
        Load environment variables from .env file.

        Simple implementation that doesn't override existing env vars.
        """
        env_path = Path(env_file).expanduser()

        if not env_path.exists():
            raise FileNotFoundError(f".env file not found: {env_path}")

        with open(env_path, "r") as f:
            for line in f:
                line = line.strip()

                # Skip empty lines and comments
                if not line or line.startswith("#"):
                    continue

                # Parse KEY=VALUE
                if "=" in line:
                    key, value = line.split("=", 1)
                    key = key.strip()
                    value = value.strip()

                    # Remove quotes if present
                    if value.startswith('"') and value.endswith('"'):
                        value = value[1:-1]
                    elif value.startswith("'") and value.endswith("'"):
                        value = value[1:-1]

                    # Only set if not already in environment
                    if key not in os.environ:
                        os.environ[key] = value

    def get_cache_dir(self) -> Path:
        """Get expanded cache directory path."""
        return Path(self.cache_dir).expanduser()

    def get_spool_dir(self) -> Path:
        """Get expanded spool directory path."""
        return Path(self.spool_dir).expanduser()
