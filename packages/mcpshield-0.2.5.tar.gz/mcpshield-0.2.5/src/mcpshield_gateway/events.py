"""Event emission and spooling for MCPShield Gateway."""

import json
import time
import httpx
import logging
from pathlib import Path
from typing import Dict, Any, List
from datetime import datetime
from dataclasses import dataclass, asdict


logger = logging.getLogger(__name__)


@dataclass
class AuditEvent:
    """Audit event for policy decisions."""
    project_id: str
    timestamp: str
    tool_name: str
    decision: str
    reason: str
    matched_rule: str | None
    latency_ms: float
    policy_hash: str
    metadata: Dict[str, Any]


@dataclass
class UsageEvent:
    """Usage event for billing."""
    project_id: str
    timestamp: str
    event_type: str
    tool_name: str
    success: bool
    latency_ms: float
    count: int = 1  # Usage weight (e.g. dump=10, diagram=25)


class EventEmitter:
    """
    Event emitter with spooling and retry logic.

    Events are sent to MCPShield API. On failure, events are spooled
    to disk and retried with exponential backoff.
    """

    def __init__(self, api_base_url: str, api_key: str, project_id: str, spool_dir: Path):
        """Initialize event emitter."""
        self.api_base_url = api_base_url.rstrip("/")
        self.api_key = api_key
        self.project_id = project_id
        self.spool_dir = spool_dir
        self.client = httpx.Client(timeout=10.0)

        # Create spool directory
        self.spool_dir.mkdir(parents=True, exist_ok=True)

        # Retry configuration
        self.max_retries = 5
        self.base_delay = 1  # seconds
        self.max_delay = 60  # seconds

    def _normalize_decision(self, decision: str) -> str:
        """Normalize gateway decision format to API format.

        Gateway: "allow" / "deny"
        API: "allowed" / "blocked" / "redacted"
        """
        if decision == "allow":
            return "allowed"
        elif decision == "deny":
            return "blocked"
        else:
            return decision  # "redacted" passes through

    def check_limit(self) -> tuple[bool, str]:
        """Check if the organization has remaining usage quota.

        Returns:
            tuple: (allowed, message)
        """
        endpoint = f"{self.api_base_url}/events/limit-check"
        try:
            response = self.client.get(
                endpoint,
                headers={
                    "X-API-Key": self.api_key,
                    "Content-Type": "application/json",
                }
            )
            if response.status_code == 200:
                data = response.json()
                if not data.get("allowed", True):
                    return False, data.get("message", "Plan limit exceeded")
                return True, ""
            # On error, fail open to avoid blocking due to API issues
            logger.warning(f"Limit check failed: {response.status_code}")
            return True, ""
        except Exception as e:
            logger.warning(f"Limit check error: {e}")
            # Fail open on network errors
            return True, ""

    def emit_audit(self, event: AuditEvent):
        """Emit audit event."""
        # Transform gateway format to API format
        api_payload = {
            "tool": event.tool_name,  # API expects "tool" not "tool_name"
            "decision": self._normalize_decision(event.decision),  # "allow"/"deny" -> "allowed"/"blocked"
            "rule": event.matched_rule,
            "latency_ms": int(event.latency_ms) if event.latency_ms else None,
            "metadata": {
                "sql": event.metadata.get("arguments", {}).get("sql"),
                "client_name": event.metadata.get("client_name", "unknown"),
                "client_version": event.metadata.get("client_version", ""),
                "reason": event.reason,
                "policy_hash": event.policy_hash,
                "timestamp": event.timestamp,
            }
        }
        self._emit_event("audit", api_payload)

    def emit_usage(self, event: UsageEvent):
        """Emit usage event."""
        # Transform gateway format to API format
        api_payload = {
            "tool": event.tool_name,  # API expects "tool" not "tool_name"
            "count": event.count,
        }
        self._emit_event("usage", api_payload)

    def _emit_event(self, event_type: str, data: Dict[str, Any]):
        """
        Emit event to API.

        Try /events/audit or /events/usage first.
        If 404, fallback to /events/ingest with typed payload.
        On any failure, spool to disk.
        """
        # Try specific endpoint first
        endpoint = f"{self.api_base_url}/events/{event_type}"

        try:
            response = self.client.post(
                endpoint,
                json=data,
                headers={
                    "X-API-Key": self.api_key,
                    "Content-Type": "application/json",
                }
            )

            if response.status_code == 404:
                # Try fallback endpoint
                self._emit_to_ingest(event_type, data)
            elif response.status_code >= 400:
                logger.warning(f"Event emission failed: {response.status_code} {response.text}")
                self._spool_event(event_type, data)
            else:
                logger.debug(f"Event emitted successfully: {event_type}")

        except Exception as e:
            logger.warning(f"Event emission error: {e}")
            self._spool_event(event_type, data)

    def _emit_to_ingest(self, event_type: str, data: Dict[str, Any]):
        """Fallback: emit to /events/ingest with typed payload."""
        endpoint = f"{self.api_base_url}/events/ingest"
        payload = {
            "event_type": event_type,
            **data
        }

        try:
            response = self.client.post(
                endpoint,
                json=payload,
                headers={
                    "X-API-Key": self.api_key,
                    "Content-Type": "application/json",
                }
            )

            if response.status_code >= 400:
                logger.warning(f"Event ingest failed: {response.status_code} {response.text}")
                self._spool_event(event_type, data)
            else:
                logger.debug(f"Event ingested successfully: {event_type}")

        except Exception as e:
            logger.warning(f"Event ingest error: {e}")
            self._spool_event(event_type, data)

    def _spool_event(self, event_type: str, data: Dict[str, Any]):
        """Spool event to disk for later retry."""
        timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S_%f")
        filename = f"{event_type}_{timestamp}.jsonl"
        filepath = self.spool_dir / filename

        try:
            with open(filepath, "a") as f:
                f.write(json.dumps(data) + "\n")
            logger.info(f"Event spooled to {filepath}")
        except Exception as e:
            logger.error(f"Failed to spool event: {e}")

    def retry_spooled_events(self):
        """
        Retry sending spooled events.

        Called periodically to attempt sending failed events.
        """
        spool_files = sorted(self.spool_dir.glob("*.jsonl"))

        for filepath in spool_files:
            try:
                # Determine event type from filename
                event_type = filepath.stem.split("_")[0]

                with open(filepath, "r") as f:
                    events = [json.loads(line) for line in f if line.strip()]

                # Try to send each event
                failed_events = []
                for event_data in events:
                    try:
                        endpoint = f"{self.api_base_url}/events/{event_type}"
                        response = self.client.post(
                            endpoint,
                            json=event_data,
                            headers={
                                "X-API-Key": self.api_key,
                                "Content-Type": "application/json",
                            }
                        )

                        if response.status_code == 404:
                            # Try fallback
                            self._emit_to_ingest(event_type, event_data)
                        elif response.status_code >= 400:
                            failed_events.append(event_data)

                    except Exception as e:
                        logger.debug(f"Retry failed for event: {e}")
                        failed_events.append(event_data)

                # If all events sent successfully, delete spool file
                if not failed_events:
                    filepath.unlink()
                    logger.info(f"Successfully sent all events from {filepath}")
                else:
                    # Rewrite file with only failed events
                    with open(filepath, "w") as f:
                        for event_data in failed_events:
                            f.write(json.dumps(event_data) + "\n")

            except Exception as e:
                logger.error(f"Error processing spool file {filepath}: {e}")

    def close(self):
        """Close HTTP client."""
        self.client.close()
