"""Policy synchronization from MCPShield API."""

import hashlib
import logging
import httpx
import yaml
from pathlib import Path
from typing import Optional, Dict, Any
from datetime import datetime, timedelta


logger = logging.getLogger(__name__)


class PolicySync:
    """
    Synchronizes policy from MCPShield API.

    Implements fail-closed behavior:
    - If API and local file both unavailable, raises exception
    - If API fails, falls back to cached policy
    - Always computes and tracks policy_hash
    """

    def __init__(
        self,
        api_base_url: str,
        api_key: str,
        project_id: str,
        cache_dir: Path,
        source: str = "remote_with_fallback",
        local_file: Optional[str] = None,
        refresh_seconds: int = 60,
    ):
        """Initialize policy sync."""
        self.api_base_url = api_base_url.rstrip("/")
        self.api_key = api_key
        self.project_id = project_id
        self.cache_dir = cache_dir
        self.source = source
        self.local_file = local_file
        self.refresh_seconds = refresh_seconds

        # Ensure cache directory exists
        self.cache_dir.mkdir(parents=True, exist_ok=True)

        # Cache
        self._cached_policy: Optional[str] = None
        self._cached_hash: Optional[str] = None
        self._cache_time: Optional[datetime] = None

        self.client = httpx.Client(timeout=10.0)

    def get_policy_yaml(self) -> tuple[str, str]:
        """
        Get policy YAML and its hash.

        Returns:
            (policy_yaml, policy_hash)

        Raises:
            Exception if no policy available (fail-closed)
        """
        # Check cache first
        if self._is_cache_valid():
            logger.debug("Using cached policy")
            return self._cached_policy, self._cached_hash

        # Try to fetch new policy based on source
        if self.source in ("remote", "remote_with_fallback"):
            try:
                policy_yaml = self._fetch_from_api()
                policy_hash = self._compute_hash(policy_yaml)

                # Update cache
                self._update_cache(policy_yaml, policy_hash)

                # Save to disk cache
                self._save_to_cache_file(policy_yaml)

                logger.info(f"Policy fetched from API (hash: {policy_hash[:8]}...)")
                return policy_yaml, policy_hash

            except Exception as e:
                logger.warning(f"Failed to fetch policy from API: {e}")

                if self.source == "remote":
                    # Remote-only mode: fail if API unavailable
                    raise Exception("Policy fetch failed and source is 'remote' (no fallback)") from e

                # Try fallback
                logger.info("Attempting fallback to local/cached policy...")

        # Try cached file
        try:
            policy_yaml = self._load_from_cache_file()
            policy_hash = self._compute_hash(policy_yaml)
            self._update_cache(policy_yaml, policy_hash)
            logger.info(f"Using cached policy file (hash: {policy_hash[:8]}...)")
            return policy_yaml, policy_hash
        except Exception as e:
            logger.debug(f"Cache file not available: {e}")

        # Try local file
        if self.local_file:
            try:
                policy_yaml = self._load_from_local_file()
                policy_hash = self._compute_hash(policy_yaml)
                self._update_cache(policy_yaml, policy_hash)
                logger.info(f"Using local policy file (hash: {policy_hash[:8]}...)")
                return policy_yaml, policy_hash
            except Exception as e:
                logger.error(f"Local policy file not available: {e}")

        # FAIL CLOSED: No policy available
        raise Exception(
            "FAIL CLOSED: No policy available. "
            "API unreachable, no cached policy, and no local policy file. "
            "Cannot start gateway without policy."
        )

    def _fetch_from_api(self) -> str:
        """Fetch policy from MCPShield API."""
        url = f"{self.api_base_url}/projects/{self.project_id}/policy"

        response = self.client.get(
            url,
            headers={"X-API-Key": self.api_key}
        )

        if response.status_code == 404:
            raise Exception("Policy not found (404). Create policy in dashboard first.")

        if response.status_code == 401:
            raise Exception("Authentication failed (401). Check API key.")

        if response.status_code >= 400:
            raise Exception(f"API error: {response.status_code} {response.text}")

        data = response.json()

        # API should return policy_yaml field
        if "policy_yaml" not in data:
            raise Exception("API response missing 'policy_yaml' field")

        return data["policy_yaml"]

    def _load_from_cache_file(self) -> str:
        """Load policy from cache file."""
        cache_file = self.cache_dir / "policy.yaml"

        if not cache_file.exists():
            raise FileNotFoundError(f"Cache file not found: {cache_file}")

        with open(cache_file, "r") as f:
            return f.read()

    def _load_from_local_file(self) -> str:
        """Load policy from local file."""
        if not self.local_file:
            raise ValueError("No local file configured")

        local_path = Path(self.local_file).expanduser()

        if not local_path.exists():
            raise FileNotFoundError(f"Local policy file not found: {local_path}")

        with open(local_path, "r") as f:
            return f.read()

    def _save_to_cache_file(self, policy_yaml: str):
        """Save policy to cache file."""
        cache_file = self.cache_dir / "policy.yaml"

        try:
            with open(cache_file, "w") as f:
                f.write(policy_yaml)
            logger.debug(f"Policy saved to cache: {cache_file}")
        except Exception as e:
            logger.warning(f"Failed to save policy to cache: {e}")

    def _compute_hash(self, policy_yaml: str) -> str:
        """Compute SHA-256 hash of policy."""
        return hashlib.sha256(policy_yaml.encode()).hexdigest()

    def _update_cache(self, policy_yaml: str, policy_hash: str):
        """Update in-memory cache."""
        self._cached_policy = policy_yaml
        self._cached_hash = policy_hash
        self._cache_time = datetime.utcnow()

    def _is_cache_valid(self) -> bool:
        """Check if cache is still valid."""
        if not self._cached_policy or not self._cache_time:
            return False

        age = (datetime.utcnow() - self._cache_time).total_seconds()
        return age < self.refresh_seconds

    def refresh_in_background(self):
        """
        Refresh policy in background (best-effort).

        If refresh fails, keeps using current cached policy.
        """
        try:
            policy_yaml = self._fetch_from_api()
            policy_hash = self._compute_hash(policy_yaml)
            self._update_cache(policy_yaml, policy_hash)
            self._save_to_cache_file(policy_yaml)
            logger.info(f"Policy refreshed in background (hash: {policy_hash[:8]}...)")
        except Exception as e:
            logger.debug(f"Background policy refresh failed (continuing with cached): {e}")

    def get_current_hash(self) -> Optional[str]:
        """Get hash of currently loaded policy."""
        return self._cached_hash

    def close(self):
        """Close HTTP client."""
        self.client.close()
