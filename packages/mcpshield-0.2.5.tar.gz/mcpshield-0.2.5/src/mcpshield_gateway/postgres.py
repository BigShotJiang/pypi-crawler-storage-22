"""PostgreSQL tools for MCPShield Gateway."""

import psycopg
import logging
from typing import Dict, Any, List, Optional
from datetime import datetime
from decimal import Decimal
from uuid import UUID


logger = logging.getLogger(__name__)


# SQL types that return rows vs affected_rows
_RETURNING_TYPES = {"SELECT", "WITH", "UNKNOWN"}


class PostgresTools:
    """PostgreSQL tools with policy enforcement."""

    def __init__(self, dsn: str, timeout_seconds: int = 5, max_rows: int = 100):
        """Initialize PostgreSQL tools."""
        self.dsn = dsn
        self.timeout_seconds = timeout_seconds
        self.max_rows = max_rows
        self._conn: Optional[psycopg.Connection] = None

    def connect(self):
        """Establish database connection."""
        if self._conn is None or self._conn.closed:
            self._conn = psycopg.connect(
                self.dsn,
                connect_timeout=self.timeout_seconds,
                options=f"-c statement_timeout={self.timeout_seconds * 1000}",
                autocommit=True,
            )
            logger.info("Database connection established")

    def close(self):
        """Close database connection."""
        if self._conn and not self._conn.closed:
            self._conn.close()
            logger.info("Database connection closed")

    @staticmethod
    def _serialize_value(value: Any) -> Any:
        """Convert non-JSON-serializable types."""
        if isinstance(value, datetime):
            return value.isoformat()
        if isinstance(value, (bytes, bytearray)):
            return value.hex()
        if isinstance(value, Decimal):
            return float(value)
        if isinstance(value, UUID):
            return str(value)
        return value

    def query(self, sql: str, params: Optional[List] = None) -> Dict[str, Any]:
        """
        Execute a SQL query and return results.

        For SELECT-like queries: returns columns, rows, row_count.
        For write queries (INSERT/UPDATE/DELETE): returns affected_rows.
        """
        start_time = datetime.utcnow()

        try:
            self.connect()

            with self._conn.cursor() as cur:
                if params:
                    cur.execute(sql, params)
                else:
                    cur.execute(sql)

                # Check if this is a query that returns rows
                if cur.description:
                    rows = cur.fetchmany(self.max_rows + 1)
                    columns = [desc[0] for desc in cur.description]

                    hit_limit = len(rows) > self.max_rows
                    if hit_limit:
                        rows = rows[:self.max_rows]

                    results = []
                    for row in rows:
                        row_dict = {}
                        for col_name, value in zip(columns, row):
                            row_dict[col_name] = self._serialize_value(value)
                        results.append(row_dict)

                    latency_ms = (datetime.utcnow() - start_time).total_seconds() * 1000

                    return {
                        "columns": columns,
                        "rows": results,
                        "row_count": len(results),
                        "hit_limit": hit_limit,
                        "latency_ms": latency_ms,
                    }
                else:
                    # Write operation — no rows returned
                    affected = cur.rowcount if cur.rowcount >= 0 else 0
                    latency_ms = (datetime.utcnow() - start_time).total_seconds() * 1000

                    return {
                        "affected_rows": affected,
                        "latency_ms": latency_ms,
                    }

        except psycopg.Error as e:
            logger.error(f"Database error: {e}")
            raise Exception(f"Database error: {str(e)}") from e

        except Exception as e:
            logger.error(f"Query execution error: {e}")
            raise

    def describe(self, schema: Optional[str] = None) -> Dict[str, Any]:
        """
        Describe database schema (tables and columns).

        Args:
            schema: Optional schema name to filter by. If None, returns all schemas.

        Returns:
            Dict with schema information.
        """
        start_time = datetime.utcnow()

        try:
            self.connect()

            if schema:
                query = """
                    SELECT
                        table_schema,
                        table_name,
                        column_name,
                        data_type,
                        is_nullable
                    FROM information_schema.columns
                    WHERE table_schema = %s
                    ORDER BY table_schema, table_name, ordinal_position
                """
                params = [schema]
            else:
                query = """
                    SELECT
                        table_schema,
                        table_name,
                        column_name,
                        data_type,
                        is_nullable
                    FROM information_schema.columns
                    WHERE table_schema NOT IN ('pg_catalog', 'information_schema')
                    ORDER BY table_schema, table_name, ordinal_position
                """
                params = None

            with self._conn.cursor() as cur:
                if params:
                    cur.execute(query, params)
                else:
                    cur.execute(query)

                rows = cur.fetchall()

            schemas: Dict[str, Dict[str, List[Dict]]] = {}

            for row in rows:
                schema_name, table_name, column_name, data_type, is_nullable = row

                if schema_name not in schemas:
                    schemas[schema_name] = {}

                if table_name not in schemas[schema_name]:
                    schemas[schema_name][table_name] = []

                schemas[schema_name][table_name].append({
                    "name": column_name,
                    "type": data_type,
                    "nullable": is_nullable == "YES"
                })

            latency_ms = (datetime.utcnow() - start_time).total_seconds() * 1000

            return {
                "schemas": schemas,
                "latency_ms": latency_ms,
            }

        except psycopg.Error as e:
            logger.error(f"Database error: {e}")
            raise Exception(f"Database error: {str(e)}") from e

        except Exception as e:
            logger.error(f"Schema describe error: {e}")
            raise

    def dump(
        self,
        schema: Optional[str] = None,
        include_data: bool = False,
        tables: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """
        Generate a SQL dump by querying information_schema and pg_catalog.

        Args:
            schema: Optional schema filter (default: all non-system schemas).
            include_data: If True, include INSERT statements for table data.
            tables: Optional list of table names to include.

        Returns:
            Dict with 'sql', 'table_count', 'latency_ms'.
        """
        start_time = datetime.utcnow()

        try:
            self.connect()
            lines: List[str] = []
            lines.append("-- MCPShield SQL Dump")
            lines.append(f"-- Generated: {datetime.utcnow().isoformat()}")
            lines.append("")

            schema_filter = "table_schema = %s" if schema else "table_schema NOT IN ('pg_catalog', 'information_schema')"
            base_params: list = [schema] if schema else []

            with self._conn.cursor() as cur:
                # 1. Get tables
                table_query = f"""
                    SELECT table_schema, table_name
                    FROM information_schema.tables
                    WHERE table_type = 'BASE TABLE' AND {schema_filter}
                    ORDER BY table_schema, table_name
                """
                cur.execute(table_query, base_params or None)
                all_tables = cur.fetchall()

                if tables:
                    all_tables = [(s, t) for s, t in all_tables if t in tables or f"{s}.{t}" in tables]

                table_count = len(all_tables)

                for tbl_schema, tbl_name in all_tables:
                    qualified = f'"{tbl_schema}"."{tbl_name}"'

                    # 2. Get columns for CREATE TABLE
                    cur.execute("""
                        SELECT column_name, data_type, character_maximum_length,
                               column_default, is_nullable
                        FROM information_schema.columns
                        WHERE table_schema = %s AND table_name = %s
                        ORDER BY ordinal_position
                    """, [tbl_schema, tbl_name])
                    columns = cur.fetchall()

                    lines.append(f"CREATE TABLE {qualified} (")
                    col_defs = []
                    col_names = []
                    for col_name, data_type, max_len, col_default, is_nullable in columns:
                        col_names.append(col_name)
                        type_str = data_type.upper()
                        if max_len:
                            type_str += f"({max_len})"
                        parts = [f'    "{col_name}" {type_str}']
                        if col_default is not None:
                            parts.append(f"DEFAULT {col_default}")
                        if is_nullable == "NO":
                            parts.append("NOT NULL")
                        col_defs.append(" ".join(parts))

                    # 3. Get primary key
                    cur.execute("""
                        SELECT kcu.column_name
                        FROM information_schema.table_constraints tc
                        JOIN information_schema.key_column_usage kcu
                            ON tc.constraint_name = kcu.constraint_name
                            AND tc.table_schema = kcu.table_schema
                        WHERE tc.table_schema = %s AND tc.table_name = %s
                            AND tc.constraint_type = 'PRIMARY KEY'
                        ORDER BY kcu.ordinal_position
                    """, [tbl_schema, tbl_name])
                    pk_cols = [r[0] for r in cur.fetchall()]
                    if pk_cols:
                        col_defs.append(f'    PRIMARY KEY ({", ".join(f"{c}" for c in pk_cols)})')

                    lines.append(",\n".join(col_defs))
                    lines.append(");")
                    lines.append("")

                    # 4. Get indexes (non-primary)
                    cur.execute("""
                        SELECT indexname, indexdef
                        FROM pg_indexes
                        WHERE schemaname = %s AND tablename = %s
                            AND indexname NOT IN (
                                SELECT constraint_name FROM information_schema.table_constraints
                                WHERE table_schema = %s AND table_name = %s AND constraint_type = 'PRIMARY KEY'
                            )
                    """, [tbl_schema, tbl_name, tbl_schema, tbl_name])
                    for _, indexdef in cur.fetchall():
                        lines.append(f"{indexdef};")
                    lines.append("")

                    # 5. Optional: data dump
                    if include_data and col_names:
                        cur.execute(f'SELECT * FROM {qualified}')
                        data_rows = cur.fetchall()
                        for data_row in data_rows:
                            values = []
                            for v in data_row:
                                if v is None:
                                    values.append("NULL")
                                elif isinstance(v, str):
                                    values.append("'" + v.replace("'", "''") + "'")
                                elif isinstance(v, datetime):
                                    values.append(f"'{v.isoformat()}'")
                                elif isinstance(v, bool):
                                    values.append("TRUE" if v else "FALSE")
                                else:
                                    values.append(str(v))
                            col_list = ", ".join(f'"{c}"' for c in col_names)
                            lines.append(f'INSERT INTO {qualified} ({col_list}) VALUES ({", ".join(values)});')
                        lines.append("")

                # 6. Foreign keys (after all tables)
                for tbl_schema, tbl_name in all_tables:
                    cur.execute("""
                        SELECT
                            tc.constraint_name,
                            kcu.column_name,
                            ccu.table_schema AS ref_schema,
                            ccu.table_name AS ref_table,
                            ccu.column_name AS ref_column
                        FROM information_schema.table_constraints tc
                        JOIN information_schema.key_column_usage kcu
                            ON tc.constraint_name = kcu.constraint_name
                            AND tc.table_schema = kcu.table_schema
                        JOIN information_schema.constraint_column_usage ccu
                            ON tc.constraint_name = ccu.constraint_name
                            AND tc.table_schema = ccu.table_schema
                        WHERE tc.table_schema = %s AND tc.table_name = %s
                            AND tc.constraint_type = 'FOREIGN KEY'
                    """, [tbl_schema, tbl_name])
                    fks = cur.fetchall()
                    for constraint_name, col, ref_schema, ref_table, ref_col in fks:
                        qualified = f'"{tbl_schema}"."{tbl_name}"'
                        ref_qualified = f'"{ref_schema}"."{ref_table}"'
                        lines.append(
                            f'ALTER TABLE {qualified} ADD CONSTRAINT "{constraint_name}" '
                            f'FOREIGN KEY ("{col}") REFERENCES {ref_qualified} ("{ref_col}");'
                        )

            latency_ms = (datetime.utcnow() - start_time).total_seconds() * 1000

            return {
                "sql": "\n".join(lines),
                "table_count": table_count,
                "latency_ms": latency_ms,
            }

        except psycopg.Error as e:
            logger.error(f"Database error during dump: {e}")
            raise Exception(f"Database error: {str(e)}") from e

        except Exception as e:
            logger.error(f"Dump error: {e}")
            raise

    def diagram(
        self,
        schema: Optional[str] = None,
        format: str = "mermaid",
    ) -> Dict[str, Any]:
        """
        Generate an ER diagram in Mermaid format.

        Args:
            schema: Optional schema filter.
            format: Output format (currently only "mermaid").

        Returns:
            Dict with 'diagram', 'format', 'table_count', 'latency_ms'.
        """
        start_time = datetime.utcnow()

        try:
            self.connect()

            schema_filter = "c.table_schema = %s" if schema else "c.table_schema NOT IN ('pg_catalog', 'information_schema')"
            base_params: list = [schema] if schema else []

            with self._conn.cursor() as cur:
                # Get tables
                cur.execute(f"""
                    SELECT DISTINCT table_schema, table_name
                    FROM information_schema.tables
                    WHERE table_type = 'BASE TABLE'
                        AND {"table_schema = %s" if schema else "table_schema NOT IN ('pg_catalog', 'information_schema')"}
                    ORDER BY table_schema, table_name
                """, base_params or None)
                all_tables = cur.fetchall()
                table_count = len(all_tables)

                # Get columns with PK info
                cur.execute(f"""
                    SELECT
                        c.table_schema,
                        c.table_name,
                        c.column_name,
                        c.data_type,
                        c.is_nullable,
                        CASE WHEN pk.column_name IS NOT NULL THEN true ELSE false END AS is_pk
                    FROM information_schema.columns c
                    LEFT JOIN (
                        SELECT kcu.table_schema, kcu.table_name, kcu.column_name
                        FROM information_schema.table_constraints tc
                        JOIN information_schema.key_column_usage kcu
                            ON tc.constraint_name = kcu.constraint_name
                            AND tc.table_schema = kcu.table_schema
                        WHERE tc.constraint_type = 'PRIMARY KEY'
                    ) pk ON c.table_schema = pk.table_schema
                        AND c.table_name = pk.table_name
                        AND c.column_name = pk.column_name
                    WHERE {schema_filter}
                    ORDER BY c.table_schema, c.table_name, c.ordinal_position
                """, base_params or None)
                columns_rows = cur.fetchall()

                # Get foreign keys
                cur.execute(f"""
                    SELECT
                        kcu.table_schema,
                        kcu.table_name,
                        kcu.column_name,
                        ccu.table_schema AS ref_schema,
                        ccu.table_name AS ref_table,
                        ccu.column_name AS ref_column
                    FROM information_schema.table_constraints tc
                    JOIN information_schema.key_column_usage kcu
                        ON tc.constraint_name = kcu.constraint_name
                        AND tc.table_schema = kcu.table_schema
                    JOIN information_schema.constraint_column_usage ccu
                        ON tc.constraint_name = ccu.constraint_name
                        AND tc.table_schema = ccu.table_schema
                    WHERE tc.constraint_type = 'FOREIGN KEY'
                        AND {"kcu.table_schema = %s" if schema else "kcu.table_schema NOT IN ('pg_catalog', 'information_schema')"}
                """, base_params or None)
                fk_rows = cur.fetchall()

            # Build Mermaid ER diagram
            lines = ["erDiagram"]

            # Organize columns by table
            table_columns: Dict[str, List] = {}
            for tbl_schema, tbl_name, col_name, data_type, is_nullable, is_pk in columns_rows:
                key = tbl_name
                if key not in table_columns:
                    table_columns[key] = []
                table_columns[key].append((col_name, data_type, is_nullable, is_pk))

            # Entity definitions
            for tbl_schema, tbl_name in all_tables:
                cols = table_columns.get(tbl_name, [])
                lines.append(f"    {tbl_name} {{")
                for col_name, data_type, is_nullable, is_pk in cols:
                    mermaid_type = data_type.replace(" ", "_")
                    comment = ""
                    if is_pk:
                        comment = ' PK'
                    elif is_nullable == "NO":
                        comment = ''
                    lines.append(f"        {mermaid_type} {col_name}{comment}")
                lines.append("    }")

            # Relationships from foreign keys
            for tbl_schema, tbl_name, col_name, ref_schema, ref_table, ref_col in fk_rows:
                lines.append(f"    {tbl_name} }}o--|| {ref_table} : \"{col_name}\"")

            diagram_text = "\n".join(lines)
            latency_ms = (datetime.utcnow() - start_time).total_seconds() * 1000

            return {
                "diagram": diagram_text,
                "format": format,
                "table_count": table_count,
                "latency_ms": latency_ms,
            }

        except psycopg.Error as e:
            logger.error(f"Database error during diagram: {e}")
            raise Exception(f"Database error: {str(e)}") from e

        except Exception as e:
            logger.error(f"Diagram error: {e}")
            raise
