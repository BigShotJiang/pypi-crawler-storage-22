"""MCP server implementation for MCPShield Gateway."""

import sys
import json
import logging
from typing import Dict, Any, Optional
from datetime import datetime

from .config import GatewayConfig
from .policy import PolicyEngine, Decision
from .policy_sync import PolicySync
from .postgres import PostgresTools
from .events import EventEmitter, AuditEvent, UsageEvent


logger = logging.getLogger(__name__)


class MCPServer:
    """
    MCP server over stdio.

    Implements the Model Context Protocol for Claude Code integration.
    """

    # Usage cost per tool call (counts against monthly plan limit)
    TOOL_USAGE_COST = {
        "postgres_query": 1,
        "postgres_describe": 1,
        "postgres_dump": 10,
        "postgres_diagram": 25,
    }

    def __init__(self, config: GatewayConfig):
        """Initialize MCP server."""
        self.config = config

        # Initialize policy sync
        self.policy_sync = PolicySync(
            api_base_url=config.api_base_url,
            api_key=config.api_key,
            project_id=config.project_id,
            cache_dir=config.get_cache_dir(),
            source=config.policy_source,
            local_file=config.policy_file,
            refresh_seconds=config.policy_refresh_seconds,
        )

        # Load policy (will fetch from API or fallback)
        try:
            policy_yaml, policy_hash = self.policy_sync.get_policy_yaml()
            self.policy = PolicyEngine.from_yaml_string(policy_yaml)
            self.policy_hash = policy_hash
            logger.info(f"Policy loaded (hash: {policy_hash[:8]}..., source: {config.policy_source})")
        except Exception as e:
            logger.error(f"FAIL CLOSED: Cannot load policy: {e}")
            raise

        # Initialize PostgreSQL tools
        self.pg = PostgresTools(
            dsn=config.pg_dsn,
            timeout_seconds=self.policy.timeout_seconds,
            max_rows=self.policy.max_rows,
        )

        # Initialize event emitter
        self.emitter = EventEmitter(
            api_base_url=config.api_base_url,
            api_key=config.api_key,
            project_id=config.project_id,
            spool_dir=config.get_spool_dir(),
        )

        # MCP protocol state
        self.initialized = False
        self.client_info: Dict[str, Any] = {}

    def run(self):
        """Run the MCP server (stdio loop)."""
        logger.info("MCPShield Gateway starting...")
        logger.info(f"Project ID: {self.config.project_id}")
        logger.info(f"Policy: {self.config.policy_file}")

        try:
            # Read from stdin, write to stdout
            for line in sys.stdin:
                line = line.strip()
                if not line:
                    continue

                try:
                    request = json.loads(line)
                    response = self._handle_request(request)

                    if response:
                        # Write response to stdout
                        sys.stdout.write(json.dumps(response) + "\n")
                        sys.stdout.flush()

                except json.JSONDecodeError as e:
                    logger.error(f"Invalid JSON: {e}")
                    error_response = {
                        "jsonrpc": "2.0",
                        "id": None,
                        "error": {
                            "code": -32700,
                            "message": "Parse error",
                        }
                    }
                    sys.stdout.write(json.dumps(error_response) + "\n")
                    sys.stdout.flush()

                except Exception as e:
                    logger.error(f"Request handling error: {e}", exc_info=True)

        except KeyboardInterrupt:
            logger.info("Shutting down...")
        finally:
            self._cleanup()

    def _handle_request(self, request: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Handle an MCP request."""
        method = request.get("method")
        request_id = request.get("id")
        params = request.get("params", {})

        logger.debug(f"Request: {method} (id={request_id})")

        # Notifications have no "id" field — never respond to them
        if request_id is None:
            logger.debug(f"Notification received: {method} (no response needed)")
            return None

        # Handle different MCP methods
        if method == "initialize":
            return self._handle_initialize(request_id, params)

        elif method == "tools/list":
            return self._handle_tools_list(request_id)

        elif method == "tools/call":
            return self._handle_tool_call(request_id, params)

        elif method == "shutdown":
            return self._handle_shutdown(request_id)

        elif method == "ping":
            return {
                "jsonrpc": "2.0",
                "id": request_id,
                "result": {}
            }

        else:
            return {
                "jsonrpc": "2.0",
                "id": request_id,
                "error": {
                    "code": -32601,
                    "message": f"Method not found: {method}",
                }
            }

    def _handle_initialize(self, request_id: Any, params: Dict[str, Any]) -> Dict[str, Any]:
        """Handle initialize request."""
        self.initialized = True

        # Capture client info (e.g. Claude Code, Cursor, etc.)
        self.client_info = params.get("clientInfo", {})
        logger.info(f"Client connected: {self.client_info.get('name', 'unknown')} v{self.client_info.get('version', '?')}")

        return {
            "jsonrpc": "2.0",
            "id": request_id,
            "result": {
                "protocolVersion": "2024-11-05",
                "serverInfo": {
                    "name": "mcpshield",
                    "version": "0.2.5",
                },
                "capabilities": {
                    "tools": {},
                }
            }
        }

    def _handle_tools_list(self, request_id: Any) -> Dict[str, Any]:
        """Handle tools/list request."""
        tools = [
            {
                "name": "postgres_query",
                "description": "Execute SQL query against PostgreSQL database. Allowed statement types controlled by policy.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "sql": {
                            "type": "string",
                            "description": "SQL query to execute"
                        },
                        "params": {
                            "type": "array",
                            "description": "Optional query parameters",
                            "items": {
                                "type": "string"
                            }
                        }
                    },
                    "required": ["sql"]
                }
            },
            {
                "name": "postgres_describe",
                "description": "Describe database schema (tables and columns). Useful for understanding available data.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "schema": {
                            "type": "string",
                            "description": "Optional schema name to filter by. If not provided, returns all non-system schemas."
                        }
                    }
                }
            },
            {
                "name": "postgres_dump",
                "description": "Generate a SQL dump of database schema and optionally data. Produces CREATE TABLE, indexes, and constraints.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "schema": {
                            "type": "string",
                            "description": "Optional schema name to filter by."
                        },
                        "include_data": {
                            "type": "boolean",
                            "description": "Include INSERT statements for table data. Default false."
                        },
                        "tables": {
                            "type": "array",
                            "description": "Optional list of table names to include.",
                            "items": {
                                "type": "string"
                            }
                        }
                    }
                }
            },
            {
                "name": "postgres_diagram",
                "description": "Generate an ER (Entity-Relationship) diagram of the database schema in Mermaid format.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "schema": {
                            "type": "string",
                            "description": "Optional schema name to filter by."
                        },
                        "format": {
                            "type": "string",
                            "description": "Output format. Currently only 'mermaid' is supported.",
                            "enum": ["mermaid"]
                        }
                    }
                }
            }
        ]

        return {
            "jsonrpc": "2.0",
            "id": request_id,
            "result": {
                "tools": tools
            }
        }

    def _handle_tool_call(self, request_id: Any, params: Dict[str, Any]) -> Dict[str, Any]:
        """Handle tools/call request."""
        tool_name = params.get("name")
        arguments = params.get("arguments", {})

        start_time = datetime.utcnow()

        try:
            # Check usage limit BEFORE policy evaluation
            limit_allowed, limit_msg = self.emitter.check_limit()
            if not limit_allowed:
                logger.warning(f"Usage limit exceeded: {limit_msg}")
                return {
                    "jsonrpc": "2.0",
                    "id": request_id,
                    "error": {
                        "code": -32000,
                        "message": f"Usage limit exceeded: {limit_msg}",
                    }
                }

            # Evaluate policy
            decision = self.policy.evaluate_tool(tool_name, arguments)

            latency_ms = (datetime.utcnow() - start_time).total_seconds() * 1000

            # Emit audit event (include policy_hash and client info)
            audit_event = AuditEvent(
                project_id=self.config.project_id,
                timestamp=datetime.utcnow().isoformat(),
                tool_name=tool_name,
                decision=decision.decision.value,
                reason=decision.reason,
                matched_rule=decision.matched_rule,
                latency_ms=latency_ms,
                policy_hash=self.policy_hash,
                metadata={
                    "arguments": arguments,
                    "client_name": self.client_info.get("name", "unknown"),
                    "client_version": self.client_info.get("version", ""),
                }
            )
            self.emitter.emit_audit(audit_event)

            if self.config.log_decisions:
                logger.info(f"Policy decision: {decision.decision.value} - {decision.reason}")

            tool_cost = self.TOOL_USAGE_COST.get(tool_name, 1)

            # Check decision
            if decision.decision == Decision.DENY:
                # Emit usage event (blocked)
                usage_event = UsageEvent(
                    project_id=self.config.project_id,
                    timestamp=datetime.utcnow().isoformat(),
                    event_type="tool_call",
                    tool_name=tool_name,
                    success=False,
                    latency_ms=latency_ms,
                    count=tool_cost,
                )
                self.emitter.emit_usage(usage_event)

                return {
                    "jsonrpc": "2.0",
                    "id": request_id,
                    "error": {
                        "code": -32000,
                        "message": f"Policy denied: {decision.reason}",
                    }
                }

            # Execute tool
            if tool_name == "postgres_query":
                result = self._execute_postgres_query(arguments)
            elif tool_name == "postgres_describe":
                result = self._execute_postgres_describe(arguments)
            elif tool_name == "postgres_dump":
                result = self._execute_postgres_dump(arguments)
            elif tool_name == "postgres_diagram":
                result = self._execute_postgres_diagram(arguments)
            else:
                return {
                    "jsonrpc": "2.0",
                    "id": request_id,
                    "error": {
                        "code": -32601,
                        "message": f"Unknown tool: {tool_name}",
                    }
                }

            # Apply redactions
            result = self.policy.apply_redactions(result)

            # Emit usage event (success)
            total_latency_ms = (datetime.utcnow() - start_time).total_seconds() * 1000
            usage_event = UsageEvent(
                project_id=self.config.project_id,
                timestamp=datetime.utcnow().isoformat(),
                event_type="tool_call",
                tool_name=tool_name,
                success=True,
                latency_ms=total_latency_ms,
                count=tool_cost,
            )
            self.emitter.emit_usage(usage_event)

            return {
                "jsonrpc": "2.0",
                "id": request_id,
                "result": {
                    "content": [
                        {
                            "type": "text",
                            "text": json.dumps(result, indent=2)
                        }
                    ]
                }
            }

        except Exception as e:
            logger.error(f"Tool execution error: {e}", exc_info=True)

            # Emit usage event (error)
            latency_ms = (datetime.utcnow() - start_time).total_seconds() * 1000
            tool_cost = self.TOOL_USAGE_COST.get(tool_name, 1)
            usage_event = UsageEvent(
                project_id=self.config.project_id,
                timestamp=datetime.utcnow().isoformat(),
                event_type="tool_call",
                tool_name=tool_name,
                success=False,
                latency_ms=latency_ms,
                count=tool_cost,
            )
            self.emitter.emit_usage(usage_event)

            return {
                "jsonrpc": "2.0",
                "id": request_id,
                "error": {
                    "code": -32000,
                    "message": str(e),
                }
            }

    def _execute_postgres_query(self, arguments: Dict[str, Any]) -> Dict[str, Any]:
        """Execute postgres.query tool."""
        sql = arguments.get("sql")
        params = arguments.get("params")

        if not sql:
            raise ValueError("SQL query is required")

        result = self.pg.query(sql, params)
        return result

    def _execute_postgres_describe(self, arguments: Dict[str, Any]) -> Dict[str, Any]:
        """Execute postgres.describe tool."""
        schema = arguments.get("schema")
        result = self.pg.describe(schema)
        return result

    def _execute_postgres_dump(self, arguments: Dict[str, Any]) -> Dict[str, Any]:
        """Execute postgres.dump tool."""
        schema = arguments.get("schema")
        include_data = arguments.get("include_data", False)
        tables = arguments.get("tables")
        return self.pg.dump(schema=schema, include_data=include_data, tables=tables)

    def _execute_postgres_diagram(self, arguments: Dict[str, Any]) -> Dict[str, Any]:
        """Execute postgres.diagram tool."""
        schema = arguments.get("schema")
        fmt = arguments.get("format", "mermaid")
        return self.pg.diagram(schema=schema, format=fmt)

    def _handle_shutdown(self, request_id: Any) -> Dict[str, Any]:
        """Handle shutdown request."""
        logger.info("Shutdown requested")
        return {
            "jsonrpc": "2.0",
            "id": request_id,
            "result": {}
        }

    def _cleanup(self):
        """Cleanup resources."""
        logger.info("Cleaning up resources...")

        # Close database connection
        self.pg.close()

        # Close policy sync
        self.policy_sync.close()

        # Close event emitter
        self.emitter.close()

        # Try to send any remaining spooled events
        try:
            self.emitter.retry_spooled_events()
        except Exception as e:
            logger.error(f"Error retrying spooled events: {e}")
