"""MCPShield Gateway - Secure access for AI agents."""

__version__ = "0.2.6"
__author__ = "MCPShield"
