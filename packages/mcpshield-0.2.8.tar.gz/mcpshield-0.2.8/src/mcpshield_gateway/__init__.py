"""MCPShield Gateway - Secure access for AI agents."""

__version__ = "0.2.8"
__author__ = "MCPShield"
