"""MongoDB tools for MCPShield Gateway."""

import json
import logging
from typing import Dict, Any, List, Optional
from datetime import datetime

logger = logging.getLogger(__name__)

# Maximum number of documents to return per query
_DEFAULT_LIMIT = 100


class MongoDBTools:
    """MongoDB tools with policy enforcement."""

    def __init__(self, dsn: str, timeout_seconds: int = 5, max_rows: int = 100):
        """Initialize MongoDB tools.

        Args:
            dsn: MongoDB connection string (e.g. mongodb://user:pass@host:27017/db)
            timeout_seconds: Operation timeout in seconds.
            max_rows: Maximum documents to return per query.
        """
        self.dsn = dsn
        self.timeout_seconds = timeout_seconds
        self.max_rows = max_rows
        self._client = None
        self._db = None

    def connect(self):
        """Establish database connection."""
        if self._client is None:
            from pymongo import MongoClient
            from urllib.parse import urlparse

            self._client = MongoClient(
                self.dsn,
                serverSelectionTimeoutMS=self.timeout_seconds * 1000,
                connectTimeoutMS=self.timeout_seconds * 1000,
                socketTimeoutMS=self.timeout_seconds * 1000,
            )

            # Extract database name from DSN
            parsed = urlparse(self.dsn)
            db_name = parsed.path.lstrip("/").split("?")[0]
            if not db_name:
                raise ValueError("MongoDB DSN must include a database name (e.g. mongodb://host/mydb)")

            self._db = self._client[db_name]
            # Force connection test
            self._client.admin.command("ping")
            logger.info(f"MongoDB connection established: {db_name}")

    def close(self):
        """Close database connection."""
        if self._client is not None:
            self._client.close()
            self._client = None
            self._db = None
            logger.info("MongoDB connection closed")

    @staticmethod
    def _serialize_doc(doc: Any) -> Any:
        """Recursively serialize a MongoDB document to JSON-safe types."""
        from bson import ObjectId

        if isinstance(doc, dict):
            return {k: MongoDBTools._serialize_doc(v) for k, v in doc.items()}
        elif isinstance(doc, list):
            return [MongoDBTools._serialize_doc(item) for item in doc]
        elif isinstance(doc, ObjectId):
            return str(doc)
        elif isinstance(doc, datetime):
            return doc.isoformat()
        elif isinstance(doc, bytes):
            return doc.hex()
        return doc

    def query(
        self,
        collection: str,
        filter: Optional[Dict] = None,
        projection: Optional[Dict] = None,
        limit: Optional[int] = None,
        sort: Optional[List] = None,
    ) -> Dict[str, Any]:
        """Execute a find query on a collection."""
        start_time = datetime.utcnow()

        try:
            self.connect()

            coll = self._db[collection]
            effective_limit = min(limit or self.max_rows, self.max_rows)

            cursor = coll.find(
                filter=filter or {},
                projection=projection,
            )
            if sort:
                cursor = cursor.sort(sort)

            # Fetch one extra to detect limit hit
            docs = list(cursor.limit(effective_limit + 1))
            hit_limit = len(docs) > effective_limit
            if hit_limit:
                docs = docs[:effective_limit]

            results = [self._serialize_doc(doc) for doc in docs]

            latency_ms = (datetime.utcnow() - start_time).total_seconds() * 1000
            return {
                "documents": results,
                "count": len(results),
                "hit_limit": hit_limit,
                "latency_ms": latency_ms,
            }

        except Exception as e:
            logger.error(f"MongoDB query error: {e}")
            raise Exception(f"MongoDB error: {str(e)}") from e

    def aggregate(self, collection: str, pipeline: List[Dict]) -> Dict[str, Any]:
        """Execute an aggregation pipeline."""
        start_time = datetime.utcnow()

        try:
            self.connect()

            coll = self._db[collection]

            # Inject $limit stage if not present to enforce max_rows
            has_limit = any("$limit" in stage for stage in pipeline)
            if not has_limit:
                pipeline = pipeline + [{"$limit": self.max_rows}]

            cursor = coll.aggregate(pipeline)
            results = [self._serialize_doc(doc) for doc in cursor]

            latency_ms = (datetime.utcnow() - start_time).total_seconds() * 1000
            return {
                "documents": results,
                "count": len(results),
                "latency_ms": latency_ms,
            }

        except Exception as e:
            logger.error(f"MongoDB aggregate error: {e}")
            raise Exception(f"MongoDB error: {str(e)}") from e

    def describe(self) -> Dict[str, Any]:
        """List collections and sample document structure."""
        start_time = datetime.utcnow()

        try:
            self.connect()

            collection_names = self._db.list_collection_names()
            collections = {}

            for name in sorted(collection_names):
                coll = self._db[name]
                doc_count = coll.estimated_document_count()

                # Sample one document to infer structure
                sample = coll.find_one()
                fields = {}
                if sample:
                    for key, value in sample.items():
                        fields[key] = type(value).__name__

                collections[name] = {
                    "document_count": doc_count,
                    "fields": fields,
                }

            latency_ms = (datetime.utcnow() - start_time).total_seconds() * 1000
            return {
                "database": self._db.name,
                "collections": collections,
                "latency_ms": latency_ms,
            }

        except Exception as e:
            logger.error(f"MongoDB describe error: {e}")
            raise Exception(f"MongoDB error: {str(e)}") from e

    def insert(self, collection: str, documents: List[Dict]) -> Dict[str, Any]:
        """Insert one or many documents."""
        start_time = datetime.utcnow()

        try:
            self.connect()

            coll = self._db[collection]

            if len(documents) == 1:
                result = coll.insert_one(documents[0])
                ids = [str(result.inserted_id)]
            else:
                result = coll.insert_many(documents)
                ids = [str(id_) for id_ in result.inserted_ids]

            latency_ms = (datetime.utcnow() - start_time).total_seconds() * 1000
            return {
                "inserted_ids": ids,
                "inserted_count": len(ids),
                "latency_ms": latency_ms,
            }

        except Exception as e:
            logger.error(f"MongoDB insert error: {e}")
            raise Exception(f"MongoDB error: {str(e)}") from e

    def update(self, collection: str, filter: Dict, update: Dict) -> Dict[str, Any]:
        """Update documents matching filter."""
        start_time = datetime.utcnow()

        try:
            self.connect()

            coll = self._db[collection]
            result = coll.update_many(filter, update)

            latency_ms = (datetime.utcnow() - start_time).total_seconds() * 1000
            return {
                "matched_count": result.matched_count,
                "modified_count": result.modified_count,
                "latency_ms": latency_ms,
            }

        except Exception as e:
            logger.error(f"MongoDB update error: {e}")
            raise Exception(f"MongoDB error: {str(e)}") from e

    def delete(self, collection: str, filter: Dict) -> Dict[str, Any]:
        """Delete documents matching filter."""
        start_time = datetime.utcnow()

        try:
            self.connect()

            if not filter:
                raise ValueError("Empty filter not allowed for delete (would delete all documents)")

            coll = self._db[collection]
            result = coll.delete_many(filter)

            latency_ms = (datetime.utcnow() - start_time).total_seconds() * 1000
            return {
                "deleted_count": result.deleted_count,
                "latency_ms": latency_ms,
            }

        except Exception as e:
            logger.error(f"MongoDB delete error: {e}")
            raise Exception(f"MongoDB error: {str(e)}") from e
