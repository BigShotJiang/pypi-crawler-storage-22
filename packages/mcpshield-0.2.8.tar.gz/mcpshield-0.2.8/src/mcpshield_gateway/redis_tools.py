"""Redis tools for MCPShield Gateway."""

import logging
from typing import Dict, Any, List, Optional
from datetime import datetime

logger = logging.getLogger(__name__)

# Safety limit for KEYS pattern scanning
_MAX_KEYS_SCAN = 1000


class RedisTools:
    """Redis tools with policy enforcement."""

    def __init__(self, dsn: str, timeout_seconds: int = 5, max_rows: int = 100):
        """Initialize Redis tools.

        Args:
            dsn: Redis connection string (e.g. redis://localhost:6379/0)
            timeout_seconds: Connection timeout in seconds.
            max_rows: Maximum keys/results to return.
        """
        self.dsn = dsn
        self.timeout_seconds = timeout_seconds
        self.max_rows = max_rows
        self._client = None

    def connect(self):
        """Establish Redis connection."""
        if self._client is None:
            import redis

            self._client = redis.from_url(
                self.dsn,
                socket_connect_timeout=self.timeout_seconds,
                socket_timeout=self.timeout_seconds,
                decode_responses=True,
            )
            # Test connection
            self._client.ping()
            logger.info("Redis connection established")

    def close(self):
        """Close Redis connection."""
        if self._client is not None:
            self._client.close()
            self._client = None
            logger.info("Redis connection closed")

    def get(self, key: str) -> Dict[str, Any]:
        """Get value by key."""
        start_time = datetime.utcnow()

        try:
            self.connect()

            value = self._client.get(key)
            key_type = self._client.type(key) if value is not None else None
            ttl = self._client.ttl(key) if value is not None else None

            latency_ms = (datetime.utcnow() - start_time).total_seconds() * 1000
            return {
                "key": key,
                "value": value,
                "type": key_type,
                "ttl": ttl if ttl and ttl >= 0 else None,
                "exists": value is not None,
                "latency_ms": latency_ms,
            }

        except Exception as e:
            logger.error(f"Redis GET error: {e}")
            raise Exception(f"Redis error: {str(e)}") from e

    def set(self, key: str, value: str, ttl: Optional[int] = None) -> Dict[str, Any]:
        """Set a key-value pair with optional TTL."""
        start_time = datetime.utcnow()

        try:
            self.connect()

            if ttl and ttl > 0:
                self._client.setex(key, ttl, value)
            else:
                self._client.set(key, value)

            latency_ms = (datetime.utcnow() - start_time).total_seconds() * 1000
            return {
                "key": key,
                "success": True,
                "ttl": ttl,
                "latency_ms": latency_ms,
            }

        except Exception as e:
            logger.error(f"Redis SET error: {e}")
            raise Exception(f"Redis error: {str(e)}") from e

    def delete(self, keys: List[str]) -> Dict[str, Any]:
        """Delete one or more keys."""
        start_time = datetime.utcnow()

        try:
            self.connect()

            deleted_count = self._client.delete(*keys)

            latency_ms = (datetime.utcnow() - start_time).total_seconds() * 1000
            return {
                "deleted_count": deleted_count,
                "keys": keys,
                "latency_ms": latency_ms,
            }

        except Exception as e:
            logger.error(f"Redis DELETE error: {e}")
            raise Exception(f"Redis error: {str(e)}") from e

    def keys(self, pattern: str = "*") -> Dict[str, Any]:
        """List keys matching a pattern using SCAN (safe for production)."""
        start_time = datetime.utcnow()

        try:
            self.connect()

            matched_keys = []
            cursor = 0
            while True:
                cursor, batch = self._client.scan(cursor=cursor, match=pattern, count=100)
                matched_keys.extend(batch)
                if cursor == 0 or len(matched_keys) >= _MAX_KEYS_SCAN:
                    break

            hit_limit = len(matched_keys) >= _MAX_KEYS_SCAN
            matched_keys = matched_keys[:_MAX_KEYS_SCAN]

            latency_ms = (datetime.utcnow() - start_time).total_seconds() * 1000
            return {
                "keys": matched_keys,
                "count": len(matched_keys),
                "pattern": pattern,
                "hit_limit": hit_limit,
                "latency_ms": latency_ms,
            }

        except Exception as e:
            logger.error(f"Redis KEYS error: {e}")
            raise Exception(f"Redis error: {str(e)}") from e

    def info(self) -> Dict[str, Any]:
        """Get Redis server info and stats."""
        start_time = datetime.utcnow()

        try:
            self.connect()

            info = self._client.info()

            # Return a useful subset
            summary = {
                "redis_version": info.get("redis_version"),
                "uptime_in_seconds": info.get("uptime_in_seconds"),
                "connected_clients": info.get("connected_clients"),
                "used_memory_human": info.get("used_memory_human"),
                "used_memory_peak_human": info.get("used_memory_peak_human"),
                "total_connections_received": info.get("total_connections_received"),
                "total_commands_processed": info.get("total_commands_processed"),
                "db_size": self._client.dbsize(),
                "role": info.get("role"),
            }

            latency_ms = (datetime.utcnow() - start_time).total_seconds() * 1000
            return {
                "info": summary,
                "latency_ms": latency_ms,
            }

        except Exception as e:
            logger.error(f"Redis INFO error: {e}")
            raise Exception(f"Redis error: {str(e)}") from e
