"""MCP server implementation for MCPShield Gateway."""

import sys
import json
import logging
from typing import Dict, Any, Optional
from datetime import datetime

from .config import GatewayConfig
from .policy import PolicyEngine, Decision
from .policy_sync import PolicySync
from .events import EventEmitter, AuditEvent, UsageEvent


logger = logging.getLogger(__name__)


# ── Tool definitions per backend ────────────────────────────────────────────

POSTGRES_TOOLS = [
    {
        "name": "postgres_query",
        "description": "Execute SQL query against PostgreSQL database. Allowed statement types controlled by policy.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "sql": {"type": "string", "description": "SQL query to execute"},
                "params": {"type": "array", "description": "Optional query parameters", "items": {"type": "string"}},
            },
            "required": ["sql"],
        },
    },
    {
        "name": "postgres_describe",
        "description": "Describe database schema (tables and columns). Useful for understanding available data.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "schema": {"type": "string", "description": "Optional schema name to filter by. If not provided, returns all non-system schemas."},
            },
        },
    },
    {
        "name": "postgres_dump",
        "description": "Generate a SQL dump of database schema and optionally data. Produces CREATE TABLE, indexes, and constraints.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "schema": {"type": "string", "description": "Optional schema name to filter by."},
                "include_data": {"type": "boolean", "description": "Include INSERT statements for table data. Default false."},
                "tables": {"type": "array", "description": "Optional list of table names to include.", "items": {"type": "string"}},
            },
        },
    },
    {
        "name": "postgres_diagram",
        "description": "Generate an ER (Entity-Relationship) diagram of the database schema in Mermaid format.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "schema": {"type": "string", "description": "Optional schema name to filter by."},
                "format": {"type": "string", "description": "Output format. Currently only 'mermaid' is supported.", "enum": ["mermaid"]},
            },
        },
    },
]

MYSQL_TOOLS = [
    {
        "name": "mysql_query",
        "description": "Execute SQL query against MySQL database. Allowed statement types controlled by policy.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "sql": {"type": "string", "description": "SQL query to execute"},
                "params": {"type": "array", "description": "Optional query parameters", "items": {"type": "string"}},
            },
            "required": ["sql"],
        },
    },
    {
        "name": "mysql_describe",
        "description": "Describe database schema (tables and columns).",
        "inputSchema": {
            "type": "object",
            "properties": {
                "schema": {"type": "string", "description": "Optional schema name to filter by."},
            },
        },
    },
    {
        "name": "mysql_dump",
        "description": "Generate a SQL dump of database schema and optionally data.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "schema": {"type": "string", "description": "Optional schema name to filter by."},
                "include_data": {"type": "boolean", "description": "Include INSERT statements for table data. Default false."},
                "tables": {"type": "array", "description": "Optional list of table names to include.", "items": {"type": "string"}},
            },
        },
    },
    {
        "name": "mysql_diagram",
        "description": "Generate an ER diagram of the database schema in Mermaid format.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "schema": {"type": "string", "description": "Optional schema name to filter by."},
                "format": {"type": "string", "description": "Output format. Currently only 'mermaid' is supported.", "enum": ["mermaid"]},
            },
        },
    },
]

SQLITE_TOOLS = [
    {
        "name": "sqlite_query",
        "description": "Execute SQL query against SQLite database. Allowed statement types controlled by policy.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "sql": {"type": "string", "description": "SQL query to execute"},
                "params": {"type": "array", "description": "Optional query parameters", "items": {"type": "string"}},
            },
            "required": ["sql"],
        },
    },
    {
        "name": "sqlite_describe",
        "description": "Describe database schema (tables and columns).",
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "sqlite_dump",
        "description": "Generate a SQL dump of database schema and optionally data.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "include_data": {"type": "boolean", "description": "Include INSERT statements for table data. Default false."},
                "tables": {"type": "array", "description": "Optional list of table names to include.", "items": {"type": "string"}},
            },
        },
    },
    {
        "name": "sqlite_diagram",
        "description": "Generate an ER diagram of the database schema in Mermaid format.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "format": {"type": "string", "description": "Output format. Currently only 'mermaid' is supported.", "enum": ["mermaid"]},
            },
        },
    },
]

MONGODB_TOOLS = [
    {
        "name": "mongodb_query",
        "description": "Execute a find query on a MongoDB collection.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "collection": {"type": "string", "description": "Collection name"},
                "filter": {"type": "object", "description": "MongoDB query filter"},
                "projection": {"type": "object", "description": "Fields to include/exclude"},
                "limit": {"type": "integer", "description": "Maximum documents to return"},
                "sort": {"type": "array", "description": "Sort specification as [[field, direction]] pairs"},
            },
            "required": ["collection"],
        },
    },
    {
        "name": "mongodb_aggregate",
        "description": "Execute an aggregation pipeline on a MongoDB collection.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "collection": {"type": "string", "description": "Collection name"},
                "pipeline": {"type": "array", "description": "Aggregation pipeline stages"},
            },
            "required": ["collection", "pipeline"],
        },
    },
    {
        "name": "mongodb_describe",
        "description": "List collections and sample document structure.",
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "mongodb_insert",
        "description": "Insert one or many documents into a collection.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "collection": {"type": "string", "description": "Collection name"},
                "documents": {"type": "array", "description": "Documents to insert", "items": {"type": "object"}},
            },
            "required": ["collection", "documents"],
        },
    },
    {
        "name": "mongodb_update",
        "description": "Update documents in a collection.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "collection": {"type": "string", "description": "Collection name"},
                "filter": {"type": "object", "description": "Query filter to match documents"},
                "update": {"type": "object", "description": "Update operations (e.g. {$set: {field: value}})"},
            },
            "required": ["collection", "filter", "update"],
        },
    },
    {
        "name": "mongodb_delete",
        "description": "Delete documents from a collection.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "collection": {"type": "string", "description": "Collection name"},
                "filter": {"type": "object", "description": "Query filter to match documents to delete"},
            },
            "required": ["collection", "filter"],
        },
    },
]

REDIS_TOOLS = [
    {
        "name": "redis_get",
        "description": "Get value by key from Redis.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "key": {"type": "string", "description": "Key to retrieve"},
            },
            "required": ["key"],
        },
    },
    {
        "name": "redis_set",
        "description": "Set a key-value pair in Redis with optional TTL.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "key": {"type": "string", "description": "Key to set"},
                "value": {"type": "string", "description": "Value to store"},
                "ttl": {"type": "integer", "description": "Time to live in seconds (optional)"},
            },
            "required": ["key", "value"],
        },
    },
    {
        "name": "redis_delete",
        "description": "Delete one or more keys from Redis.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "keys": {"type": "array", "description": "Keys to delete", "items": {"type": "string"}},
            },
            "required": ["keys"],
        },
    },
    {
        "name": "redis_keys",
        "description": "List keys matching a pattern (uses SCAN, safe for production).",
        "inputSchema": {
            "type": "object",
            "properties": {
                "pattern": {"type": "string", "description": "Glob-style pattern (default: *)"},
            },
        },
    },
    {
        "name": "redis_info",
        "description": "Get Redis server info and stats.",
        "inputSchema": {"type": "object", "properties": {}},
    },
]

BACKEND_TOOLS = {
    "postgres": POSTGRES_TOOLS,
    "mysql": MYSQL_TOOLS,
    "sqlite": SQLITE_TOOLS,
    "mongodb": MONGODB_TOOLS,
    "redis": REDIS_TOOLS,
}


class MCPServer:
    """
    MCP server over stdio.

    Implements the Model Context Protocol for Claude Code integration.
    """

    # Usage cost per tool call (counts against monthly plan limit)
    TOOL_USAGE_COST = {
        # Postgres
        "postgres_query": 1,
        "postgres_describe": 1,
        "postgres_dump": 10,
        "postgres_diagram": 25,
        # MySQL
        "mysql_query": 1,
        "mysql_describe": 1,
        "mysql_dump": 10,
        "mysql_diagram": 25,
        # SQLite
        "sqlite_query": 1,
        "sqlite_describe": 1,
        "sqlite_dump": 10,
        "sqlite_diagram": 25,
        # MongoDB
        "mongodb_query": 1,
        "mongodb_aggregate": 5,
        "mongodb_describe": 1,
        "mongodb_insert": 1,
        "mongodb_update": 1,
        "mongodb_delete": 1,
        # Redis
        "redis_get": 1,
        "redis_set": 1,
        "redis_delete": 1,
        "redis_keys": 1,
        "redis_info": 1,
    }

    def __init__(self, config: GatewayConfig):
        """Initialize MCP server."""
        self.config = config

        # Initialize policy sync
        self.policy_sync = PolicySync(
            api_base_url=config.api_base_url,
            api_key=config.api_key,
            project_id=config.project_id,
            cache_dir=config.get_cache_dir(),
            source=config.policy_source,
            local_file=config.policy_file,
            refresh_seconds=config.policy_refresh_seconds,
        )

        # Load policy (will fetch from API or fallback)
        try:
            policy_yaml, policy_hash = self.policy_sync.get_policy_yaml()
            self.policy = PolicyEngine.from_yaml_string(policy_yaml)
            self.policy_hash = policy_hash
            logger.info(f"Policy loaded (hash: {policy_hash[:8]}..., source: {config.policy_source})")
        except Exception as e:
            logger.error(f"FAIL CLOSED: Cannot load policy: {e}")
            raise

        # Initialize backend tools (supports multiple infrastructure types)
        self.backend = config.backend  # Primary backend for backward compatibility
        self.infrastructure_types = config.infrastructure_types
        self.tools_map = self._create_backend_tools(config)  # Dict of {infra_type: tools}
        # Backward compatibility: self.tools points to primary backend tools
        self.tools = self.tools_map.get(config.backend) if isinstance(self.tools_map, dict) else self.tools_map

        # Initialize event emitter
        self.emitter = EventEmitter(
            api_base_url=config.api_base_url,
            api_key=config.api_key,
            project_id=config.project_id,
            spool_dir=config.get_spool_dir(),
        )

        # MCP protocol state
        self.initialized = False
        self.client_info: Dict[str, Any] = {}

    def _create_backend_tools(self, config: GatewayConfig):
        """Create backend tools for all configured infrastructure types."""
        timeout = self.policy.timeout_seconds
        max_rows = self.policy.max_rows
        tools_map = {}

        # Create tools for each infrastructure type
        for infra_type in config.infrastructure_types:
            dsn = config.get_dsn(infra_type)
            if not dsn:
                logger.warning(f"No DSN configured for {infra_type}, skipping")
                continue

            if infra_type == "postgres":
                from .postgres import PostgresTools
                tools_map[infra_type] = PostgresTools(dsn=dsn, timeout_seconds=timeout, max_rows=max_rows)
            elif infra_type == "mysql":
                from .mysql import MySQLTools
                tools_map[infra_type] = MySQLTools(dsn=dsn, timeout_seconds=timeout, max_rows=max_rows)
            elif infra_type == "sqlite":
                from .sqlite import SQLiteTools
                tools_map[infra_type] = SQLiteTools(dsn=dsn, timeout_seconds=timeout, max_rows=max_rows)
            elif infra_type == "mongodb":
                from .mongodb import MongoDBTools
                tools_map[infra_type] = MongoDBTools(dsn=dsn, timeout_seconds=timeout, max_rows=max_rows)
            elif infra_type == "redis":
                from .redis_tools import RedisTools
                tools_map[infra_type] = RedisTools(dsn=dsn, timeout_seconds=timeout, max_rows=max_rows)
            else:
                logger.warning(f"Unsupported infrastructure type: {infra_type}")

        if not tools_map:
            raise ValueError("No valid infrastructure tools configured")

        return tools_map

    def run(self):
        """Run the MCP server (stdio loop)."""
        logger.info("MCPShield Gateway starting...")
        logger.info(f"Infrastructure types: {', '.join(self.infrastructure_types)}")
        logger.info(f"Project ID: {self.config.project_id}")
        logger.info(f"Policy: {self.config.policy_file}")

        try:
            # Read from stdin, write to stdout
            for line in sys.stdin:
                line = line.strip()
                if not line:
                    continue

                try:
                    request = json.loads(line)
                    response = self._handle_request(request)

                    if response:
                        # Write response to stdout
                        sys.stdout.write(json.dumps(response) + "\n")
                        sys.stdout.flush()

                except json.JSONDecodeError as e:
                    logger.error(f"Invalid JSON: {e}")
                    error_response = {
                        "jsonrpc": "2.0",
                        "id": None,
                        "error": {
                            "code": -32700,
                            "message": "Parse error",
                        }
                    }
                    sys.stdout.write(json.dumps(error_response) + "\n")
                    sys.stdout.flush()

                except Exception as e:
                    logger.error(f"Request handling error: {e}", exc_info=True)

        except KeyboardInterrupt:
            logger.info("Shutting down...")
        finally:
            self._cleanup()

    def _handle_request(self, request: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Handle an MCP request."""
        method = request.get("method")
        request_id = request.get("id")
        params = request.get("params", {})

        logger.debug(f"Request: {method} (id={request_id})")

        # Notifications have no "id" field — never respond to them
        if request_id is None:
            logger.debug(f"Notification received: {method} (no response needed)")
            return None

        # Handle different MCP methods
        if method == "initialize":
            return self._handle_initialize(request_id, params)

        elif method == "tools/list":
            return self._handle_tools_list(request_id)

        elif method == "tools/call":
            return self._handle_tool_call(request_id, params)

        elif method == "shutdown":
            return self._handle_shutdown(request_id)

        elif method == "ping":
            return {
                "jsonrpc": "2.0",
                "id": request_id,
                "result": {}
            }

        else:
            return {
                "jsonrpc": "2.0",
                "id": request_id,
                "error": {
                    "code": -32601,
                    "message": f"Method not found: {method}",
                }
            }

    def _handle_initialize(self, request_id: Any, params: Dict[str, Any]) -> Dict[str, Any]:
        """Handle initialize request."""
        self.initialized = True

        # Capture client info (e.g. Claude Code, Cursor, etc.)
        self.client_info = params.get("clientInfo", {})
        logger.info(f"Client connected: {self.client_info.get('name', 'unknown')} v{self.client_info.get('version', '?')}")

        return {
            "jsonrpc": "2.0",
            "id": request_id,
            "result": {
                "protocolVersion": "2024-11-05",
                "serverInfo": {
                    "name": "mcpshield",
                    "version": "0.2.8",
                },
                "capabilities": {
                    "tools": {},
                }
            }
        }

    def _handle_tools_list(self, request_id: Any) -> Dict[str, Any]:
        """Handle tools/list request — returns tools for all configured infrastructure types."""
        # Collect tools from all configured infrastructure types
        all_tools = []
        for infra_type in self.infrastructure_types:
            backend_tools = BACKEND_TOOLS.get(infra_type, [])
            all_tools.extend(backend_tools)

        return {
            "jsonrpc": "2.0",
            "id": request_id,
            "result": {
                "tools": all_tools
            }
        }

    def _handle_tool_call(self, request_id: Any, params: Dict[str, Any]) -> Dict[str, Any]:
        """Handle tools/call request."""
        tool_name = params.get("name")
        arguments = params.get("arguments", {})

        start_time = datetime.utcnow()

        try:
            # Check usage limit BEFORE policy evaluation
            limit_allowed, limit_msg = self.emitter.check_limit()
            if not limit_allowed:
                logger.warning(f"Usage limit exceeded: {limit_msg}")
                return {
                    "jsonrpc": "2.0",
                    "id": request_id,
                    "error": {
                        "code": -32000,
                        "message": f"Usage limit exceeded: {limit_msg}",
                    }
                }

            # Evaluate policy
            decision = self.policy.evaluate_tool(tool_name, arguments)

            latency_ms = (datetime.utcnow() - start_time).total_seconds() * 1000

            # Emit audit event (include policy_hash and client info)
            audit_event = AuditEvent(
                project_id=self.config.project_id,
                timestamp=datetime.utcnow().isoformat(),
                tool_name=tool_name,
                decision=decision.decision.value,
                reason=decision.reason,
                matched_rule=decision.matched_rule,
                latency_ms=latency_ms,
                policy_hash=self.policy_hash,
                metadata={
                    "arguments": arguments,
                    "client_name": self.client_info.get("name", "unknown"),
                    "client_version": self.client_info.get("version", ""),
                }
            )
            self.emitter.emit_audit(audit_event)

            if self.config.log_decisions:
                logger.info(f"Policy decision: {decision.decision.value} - {decision.reason}")

            tool_cost = self.TOOL_USAGE_COST.get(tool_name, 1)

            # Check decision
            if decision.decision == Decision.DENY:
                # Emit usage event (blocked)
                usage_event = UsageEvent(
                    project_id=self.config.project_id,
                    timestamp=datetime.utcnow().isoformat(),
                    event_type="tool_call",
                    tool_name=tool_name,
                    success=False,
                    latency_ms=latency_ms,
                    count=tool_cost,
                )
                self.emitter.emit_usage(usage_event)

                return {
                    "jsonrpc": "2.0",
                    "id": request_id,
                    "error": {
                        "code": -32000,
                        "message": f"Policy denied: {decision.reason}",
                    }
                }

            # Execute tool via the active backend
            result = self._dispatch_tool(tool_name, arguments)

            # Apply redactions
            result = self.policy.apply_redactions(result)

            # Emit usage event (success)
            total_latency_ms = (datetime.utcnow() - start_time).total_seconds() * 1000
            usage_event = UsageEvent(
                project_id=self.config.project_id,
                timestamp=datetime.utcnow().isoformat(),
                event_type="tool_call",
                tool_name=tool_name,
                success=True,
                latency_ms=total_latency_ms,
                count=tool_cost,
            )
            self.emitter.emit_usage(usage_event)

            return {
                "jsonrpc": "2.0",
                "id": request_id,
                "result": {
                    "content": [
                        {
                            "type": "text",
                            "text": json.dumps(result, indent=2)
                        }
                    ]
                }
            }

        except Exception as e:
            logger.error(f"Tool execution error: {e}", exc_info=True)

            # Emit usage event (error)
            latency_ms = (datetime.utcnow() - start_time).total_seconds() * 1000
            tool_cost = self.TOOL_USAGE_COST.get(tool_name, 1)
            usage_event = UsageEvent(
                project_id=self.config.project_id,
                timestamp=datetime.utcnow().isoformat(),
                event_type="tool_call",
                tool_name=tool_name,
                success=False,
                latency_ms=latency_ms,
                count=tool_cost,
            )
            self.emitter.emit_usage(usage_event)

            return {
                "jsonrpc": "2.0",
                "id": request_id,
                "error": {
                    "code": -32000,
                    "message": str(e),
                }
            }

    def _dispatch_tool(self, tool_name: str, arguments: Dict[str, Any]) -> Dict[str, Any]:
        """Dispatch a tool call to the appropriate infrastructure backend."""
        # Extract infrastructure type from tool name (e.g., "postgres_query" -> "postgres")
        infra_type = tool_name.split('_')[0] if '_' in tool_name else None

        # Get the correct tools instance for this infrastructure type
        tools = self.tools_map.get(infra_type) if infra_type else self.tools
        if not tools:
            raise ValueError(f"No tools configured for infrastructure type: {infra_type}")

        # ── PostgreSQL ──
        if tool_name == "postgres_query":
            sql = arguments.get("sql")
            if not sql:
                raise ValueError("SQL query is required")
            return tools.query(sql, arguments.get("params"))
        elif tool_name == "postgres_describe":
            return tools.describe(arguments.get("schema"))
        elif tool_name == "postgres_dump":
            return tools.dump(schema=arguments.get("schema"), include_data=arguments.get("include_data", False), tables=arguments.get("tables"))
        elif tool_name == "postgres_diagram":
            return tools.diagram(schema=arguments.get("schema"), format=arguments.get("format", "mermaid"))

        # ── MySQL ──
        elif tool_name == "mysql_query":
            sql = arguments.get("sql")
            if not sql:
                raise ValueError("SQL query is required")
            return tools.query(sql, arguments.get("params"))
        elif tool_name == "mysql_describe":
            return tools.describe(arguments.get("schema"))
        elif tool_name == "mysql_dump":
            return tools.dump(schema=arguments.get("schema"), include_data=arguments.get("include_data", False), tables=arguments.get("tables"))
        elif tool_name == "mysql_diagram":
            return tools.diagram(schema=arguments.get("schema"), format=arguments.get("format", "mermaid"))

        # ── SQLite ──
        elif tool_name == "sqlite_query":
            sql = arguments.get("sql")
            if not sql:
                raise ValueError("SQL query is required")
            return tools.query(sql, arguments.get("params"))
        elif tool_name == "sqlite_describe":
            return tools.describe()
        elif tool_name == "sqlite_dump":
            return tools.dump(include_data=arguments.get("include_data", False), tables=arguments.get("tables"))
        elif tool_name == "sqlite_diagram":
            return tools.diagram(format=arguments.get("format", "mermaid"))

        # ── MongoDB ──
        elif tool_name == "mongodb_query":
            collection = arguments.get("collection")
            if not collection:
                raise ValueError("Collection name is required")
            return tools.query(
                collection=collection,
                filter=arguments.get("filter"),
                projection=arguments.get("projection"),
                limit=arguments.get("limit"),
                sort=arguments.get("sort"),
            )
        elif tool_name == "mongodb_aggregate":
            collection = arguments.get("collection")
            pipeline = arguments.get("pipeline")
            if not collection or pipeline is None:
                raise ValueError("Collection and pipeline are required")
            return tools.aggregate(collection=collection, pipeline=pipeline)
        elif tool_name == "mongodb_describe":
            return tools.describe()
        elif tool_name == "mongodb_insert":
            collection = arguments.get("collection")
            documents = arguments.get("documents")
            if not collection or not documents:
                raise ValueError("Collection and documents are required")
            return tools.insert(collection=collection, documents=documents)
        elif tool_name == "mongodb_update":
            collection = arguments.get("collection")
            filter_ = arguments.get("filter")
            update = arguments.get("update")
            if not collection or filter_ is None or update is None:
                raise ValueError("Collection, filter, and update are required")
            return tools.update(collection=collection, filter=filter_, update=update)
        elif tool_name == "mongodb_delete":
            collection = arguments.get("collection")
            filter_ = arguments.get("filter")
            if not collection or filter_ is None:
                raise ValueError("Collection and filter are required")
            return tools.delete(collection=collection, filter=filter_)

        # ── Redis ──
        elif tool_name == "redis_get":
            key = arguments.get("key")
            if not key:
                raise ValueError("Key is required")
            return tools.get(key)
        elif tool_name == "redis_set":
            key = arguments.get("key")
            value = arguments.get("value")
            if not key or value is None:
                raise ValueError("Key and value are required")
            return tools.set(key, value, ttl=arguments.get("ttl"))
        elif tool_name == "redis_delete":
            keys = arguments.get("keys")
            if not keys:
                raise ValueError("Keys list is required")
            return tools.delete(keys)
        elif tool_name == "redis_keys":
            return tools.keys(pattern=arguments.get("pattern", "*"))
        elif tool_name == "redis_info":
            return tools.info()

        else:
            raise ValueError(f"Unknown tool: {tool_name}")

    def _handle_shutdown(self, request_id: Any) -> Dict[str, Any]:
        """Handle shutdown request."""
        logger.info("Shutdown requested")
        return {
            "jsonrpc": "2.0",
            "id": request_id,
            "result": {}
        }

    def _cleanup(self):
        """Cleanup resources."""
        logger.info("Cleaning up resources...")

        # Close backend connection
        self.tools.close()

        # Close policy sync
        self.policy_sync.close()

        # Close event emitter
        self.emitter.close()

        # Try to send any remaining spooled events
        try:
            self.emitter.retry_spooled_events()
        except Exception as e:
            logger.error(f"Error retrying spooled events: {e}")
