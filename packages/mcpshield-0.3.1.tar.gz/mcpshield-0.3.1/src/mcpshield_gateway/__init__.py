"""MCPShield Gateway - Secure access for AI agents."""

__version__ = "0.3.1"
__author__ = "MCPShield"
