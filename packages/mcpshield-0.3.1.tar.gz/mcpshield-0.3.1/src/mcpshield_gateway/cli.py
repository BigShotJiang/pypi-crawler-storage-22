"""CLI for MCPShield Gateway."""

import sys
import logging
import argparse
from pathlib import Path

from . import __version__
from .config import GatewayConfig, SUPPORTED_BACKENDS
from .server import MCPServer
from .policy import PolicyEngine
from .events import EventEmitter


BACKEND_LABELS = {
    "postgres": "PostgreSQL",
    "postgresql": "PostgreSQL",  # API returns full name
    "mysql": "MySQL",
    "sqlite": "SQLite",
    "mongodb": "MongoDB",
    "redis": "Redis",
}


def setup_logging(level: str = "INFO"):
    """Setup logging configuration."""
    logging.basicConfig(
        level=getattr(logging, level.upper()),
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        stream=sys.stderr,  # Log to stderr to keep stdout clean for MCP
    )


def cmd_serve(args):
    """Run the MCP server."""
    try:
        config = GatewayConfig.load(
            config_path=args.config,
            env_file=args.env_file if hasattr(args, 'env_file') else None
        )
        setup_logging(config.log_level)

        logger = logging.getLogger(__name__)
        if args.config:
            logger.info(f"Configuration loaded from: {args.config}")
        else:
            logger.info("Configuration loaded from environment variables")

        logger.info(f"Backend: {config.backend}")

        server = MCPServer(config)
        server.run()

    except FileNotFoundError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    except ValueError as e:
        print(f"Configuration error: {e}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"Fatal error: {e}", file=sys.stderr)
        sys.exit(1)


def cmd_validate(args):
    """Validate configuration and policy files."""
    setup_logging("INFO")
    logger = logging.getLogger(__name__)

    errors = []
    warnings = []

    # Check config
    try:
        config = GatewayConfig.load(
            config_path=args.config,
            env_file=args.env_file if hasattr(args, 'env_file') else None
        )

        if args.config:
            logger.info(f"  Configuration file found: {args.config}")
        else:
            logger.info("  Configuration loaded from environment variables")

        logger.info("  Configuration loaded successfully")
        logger.info(f"  Backend: {BACKEND_LABELS.get(config.backend, config.backend)}")

        # Validate backend-specific DSN format
        if config.backend == "postgres" and not config.dsn.startswith(("postgresql://", "postgres://")):
            warnings.append("DSN doesn't look like a PostgreSQL connection string")
        elif config.backend == "mysql" and not config.dsn.startswith(("mysql://", "mysql+connector://")):
            warnings.append("DSN doesn't look like a MySQL connection string")
        elif config.backend == "sqlite" and not (config.dsn.startswith("sqlite://") or config.dsn == ":memory:" or Path(config.dsn).suffix in (".db", ".sqlite", ".sqlite3", "")):
            warnings.append("DSN doesn't look like a SQLite path")
        elif config.backend == "mongodb" and not config.dsn.startswith("mongodb://"):
            warnings.append("DSN doesn't look like a MongoDB connection string")
        elif config.backend == "redis" and not config.dsn.startswith("redis://"):
            warnings.append("DSN doesn't look like a Redis connection string")

        # Check policy based on source
        if config.policy_source == "local" and config.policy_file:
            policy_path = Path(config.policy_file).expanduser()
            if not policy_path.exists():
                errors.append(f"Policy file not found: {policy_path}")
            else:
                logger.info(f"  Policy file found: {policy_path}")

                try:
                    policy = PolicyEngine(policy_file=config.policy_file)
                    logger.info("  Policy loaded successfully")
                    logger.info(f"  - Default decision: {policy.default_decision.value}")
                    logger.info(f"  - Rules: {len(policy.rules)}")
                    logger.info(f"  - Max rows: {policy.max_rows}")
                    logger.info(f"  - Timeout: {policy.timeout_seconds}s")
                    logger.info(f"  - Redaction patterns: {len(policy.redaction_patterns)}")

                    if policy.allow_schemas:
                        logger.info(f"  - Allowed schemas: {', '.join(policy.allow_schemas)}")
                    if policy.allow_tables:
                        logger.info(f"  - Allowed tables: {', '.join(policy.allow_tables)}")
                    if policy.mongodb_allow_collections:
                        logger.info(f"  - Allowed collections: {', '.join(policy.mongodb_allow_collections)}")
                    if policy.redis_allow_commands:
                        logger.info(f"  - Allowed Redis commands: {', '.join(policy.redis_allow_commands)}")

                except Exception as e:
                    errors.append(f"Policy validation error: {e}")
        else:
            logger.info(f"  Policy source: {config.policy_source} (will fetch from API)")

    except FileNotFoundError as e:
        errors.append(f"Configuration error: {e}")
    except ValueError as e:
        errors.append(f"Configuration validation error: {e}")
    except Exception as e:
        errors.append(f"Unexpected error: {e}")

    # Print summary
    print("\n" + "=" * 60)
    if errors:
        print("VALIDATION FAILED")
        print("=" * 60)
        for error in errors:
            print(f"  {error}")
        sys.exit(1)
    else:
        print("VALIDATION PASSED")
        print("=" * 60)
        if warnings:
            for warning in warnings:
                print(f"  {warning}")
        print("\nYour configuration is ready to use!")
        if args.config:
            print(f"Run: mcpshield serve --config {args.config}")
        else:
            print("Run: mcpshield serve")


def cmd_init(args):
    """Initialize MCPShield Gateway configuration."""
    import json
    import shutil
    from pathlib import Path

    setup_logging("INFO")
    logger = logging.getLogger(__name__)

    # Check if configuration already exists
    env_path = Path.home() / ".mcpshield" / ".env"
    reconfigure = False

    if env_path.exists():
        print("\n⚠️  Existing MCPShield configuration found!")
        print(f"   Location: {env_path}")
        print("\nOptions:")
        print("  1. Reconfigure (update existing configuration)")
        print("  2. Create new configuration (backup existing)")
        print("  3. Cancel")
        choice = input("\nChoice [1]: ").strip() or "1"

        if choice == "3":
            print("\nSetup canceled.")
            sys.exit(0)
        elif choice == "2":
            backup_path = env_path.parent / f".env.backup.{int(Path.home().stat().st_mtime)}"
            shutil.copy(env_path, backup_path)
            print(f"\n  Existing configuration backed up to: {backup_path}")
        else:
            reconfigure = True
            print("\n  Will update existing configuration...")

    print("\nMCPShield Gateway Setup")
    print("=" * 60)
    print("\nMCPShield secures AI access to your infrastructure:")
    print("  • Databases (PostgreSQL, MySQL, SQLite, MongoDB, Redis)")
    print("  • APIs, Cloud platforms, File systems, and more")
    print("\nLet's configure your infrastructure access.\n")

    # 1. Get Project ID and API Key FIRST
    print("=" * 60)
    print("STEP 1: MCPShield Project")
    print("=" * 60)
    print("\nTo connect to your infrastructure:")
    print("  1. Visit https://app.mcpshield.xyz")
    print("  2. Create a project (if you haven't already)")
    print("  3. Select your infrastructure types in the project")
    print("  4. Generate an API key")
    print("")

    project_id = input("Project ID: ").strip()
    api_key = input("API Key (mcps_...): ").strip()

    if not all([project_id, api_key]):
        print("\nProject ID and API Key are required!")
        sys.exit(1)

    api_base_url = input("API Base URL [https://api.mcpshield.xyz]: ").strip() or "https://api.mcpshield.xyz"

    # Fetch project details from API
    print("\n  Fetching project details from API...")
    try:
        import httpx
        client = httpx.Client(timeout=10.0)
        response = client.get(
            f"{api_base_url}/projects/{project_id}",
            headers={"X-API-Key": api_key}
        )

        if response.status_code == 401:
            print("\n❌ Authentication failed - Invalid API key")
            sys.exit(1)
        elif response.status_code == 404:
            print("\n❌ Project not found - Check your Project ID")
            sys.exit(1)
        elif response.status_code != 200:
            print(f"\n❌ API error: {response.status_code}")
            sys.exit(1)

        project_data = response.json()
        client.close()

        infrastructure_types = project_data.get("database_types", ["postgresql"])
        project_name = project_data.get("name", "Unknown")

        print(f"\n✅ Project found: {project_name}")
        print(f"   Infrastructure types: {', '.join([BACKEND_LABELS.get(t, t) for t in infrastructure_types])}")

    except Exception as e:
        print(f"\n❌ Failed to fetch project details: {e}")
        print("\nWould you like to continue with manual setup? [y/N]: ", end="")
        if input().strip().lower() != 'y':
            sys.exit(1)
        # Fallback to manual selection
        print("\nSelect infrastructure type manually:")
        for i, (key, label) in enumerate(BACKEND_LABELS.items(), 1):
            print(f"  {i}. {label}")
        backend_choice = input("\nInfrastructure choice [1]: ").strip() or "1"
        backend_map = {str(i): k for i, k in enumerate(SUPPORTED_BACKENDS, 1)}
        infrastructure_types = [backend_map.get(backend_choice, "postgres")]
        print(f"\n✅ Selected: {BACKEND_LABELS[infrastructure_types[0]]}")

    # 2. Get credentials for each infrastructure type
    print("\n" + "=" * 60)
    print("STEP 2: Infrastructure Connection Details")
    print("=" * 60)
    print(f"\nConfiguring {len(infrastructure_types)} infrastructure type(s)...")

    dsn_map = {}  # Store DSN for each infrastructure type

    # Normalize API names to internal names (postgresql → postgres)
    name_mapping = {"postgresql": "postgres"}

    for idx, backend_raw in enumerate(infrastructure_types, 1):
        backend = name_mapping.get(backend_raw, backend_raw)  # Normalize
        print(f"\n[{idx}/{len(infrastructure_types)}] {BACKEND_LABELS[backend_raw]} Configuration")
        print("-" * 60)

        if backend == "postgres":
            pg_host = input("  PostgreSQL host [localhost]: ").strip() or "localhost"
            pg_port = input("  PostgreSQL port [5432]: ").strip() or "5432"
            pg_user = input("  PostgreSQL username: ").strip()
            pg_pass = input("  PostgreSQL password: ").strip()
            pg_db = input("  PostgreSQL database: ").strip()
            if not all([pg_user, pg_pass, pg_db]):
                print("\n  ❌ PostgreSQL credentials are required!")
                sys.exit(1)
            dsn_map["postgres"] = f"postgresql://{pg_user}:{pg_pass}@{pg_host}:{pg_port}/{pg_db}"
            print(f"  ✅ PostgreSQL configured")

        elif backend == "mysql":
            host = input("  MySQL host [localhost]: ").strip() or "localhost"
            port = input("  MySQL port [3306]: ").strip() or "3306"
            user = input("  MySQL username: ").strip()
            password = input("  MySQL password: ").strip()
            database = input("  MySQL database: ").strip()
            if not all([user, password, database]):
                print("\n  ❌ MySQL credentials are required!")
                sys.exit(1)
            dsn_map["mysql"] = f"mysql://{user}:{password}@{host}:{port}/{database}"
            print(f"  ✅ MySQL configured")

        elif backend == "sqlite":
            db_path = input("  SQLite database path: ").strip()
            if not db_path:
                print("\n  ❌ SQLite database path is required!")
                sys.exit(1)
            dsn_map["sqlite"] = f"sqlite:///{db_path}"
            print(f"  ✅ SQLite configured")

        elif backend == "mongodb":
            host = input("  MongoDB host [localhost]: ").strip() or "localhost"
            port = input("  MongoDB port [27017]: ").strip() or "27017"
            user = input("  MongoDB username (optional): ").strip()
            password = input("  MongoDB password (optional): ").strip()
            database = input("  MongoDB database: ").strip()
            if not database:
                print("\n  ❌ MongoDB database name is required!")
                sys.exit(1)
            if user and password:
                dsn_map["mongodb"] = f"mongodb://{user}:{password}@{host}:{port}/{database}"
            else:
                dsn_map["mongodb"] = f"mongodb://{host}:{port}/{database}"
            print(f"  ✅ MongoDB configured")

        elif backend == "redis":
            host = input("  Redis host [localhost]: ").strip() or "localhost"
            port = input("  Redis port [6379]: ").strip() or "6379"
            password = input("  Redis password (optional): ").strip()
            db = input("  Redis database number [0]: ").strip() or "0"
            if password:
                dsn_map["redis"] = f"redis://:{password}@{host}:{port}/{db}"
            else:
                dsn_map["redis"] = f"redis://{host}:{port}/{db}"
            print(f"  ✅ Redis configured")

    print("\n" + "=" * 60)
    print("STEP 3: AI Tool Integration")
    print("=" * 60)
    print("\nWhich AI tool will use this infrastructure?")
    print("  1. Claude Code (recommended)")
    print("  2. Cursor")
    print("  3. Both")
    print("  4. Manual setup (just create .env file)")
    choice = input("\nAI tool choice [1]: ").strip() or "1"

    # Create .env file
    env_path = Path.home() / ".mcpshield" / ".env"
    env_path.parent.mkdir(parents=True, exist_ok=True)

    # Build DSN environment variables for each infrastructure type
    dsn_env_vars = ""
    for infra_type, dsn_value in dsn_map.items():
        env_var_name = f"{infra_type.upper()}_DSN"
        dsn_env_vars += f"{env_var_name}={dsn_value}\n"

    # Legacy support: if only one infrastructure, also set DSN and MCPSHIELD_BACKEND
    legacy_vars = ""
    if len(dsn_map) == 1:
        legacy_backend = list(dsn_map.keys())[0]
        legacy_dsn = list(dsn_map.values())[0]
        legacy_vars = f"""# Legacy single-backend support
MCPSHIELD_BACKEND={legacy_backend}
DSN={legacy_dsn}

"""

    # Normalize infrastructure types for .env (use internal names)
    normalized_types = [name_mapping.get(t, t) for t in infrastructure_types]

    env_content = f"""# MCPShield Gateway Configuration
# Generated by mcpshield init

# Infrastructure Types (from project)
INFRASTRUCTURE_TYPES={','.join(normalized_types)}

# Infrastructure Connections
{dsn_env_vars}
{legacy_vars}# MCPShield API
MCPSHIELD_API_KEY={api_key}
PROJECT_ID={project_id}
API_BASE_URL={api_base_url}

# Policy Configuration
POLICY_SOURCE=remote
POLICY_REFRESH_SECONDS=60

# Logging
LOG_LEVEL=INFO
LOG_DECISIONS=true
"""

    with open(env_path, "w") as f:
        f.write(env_content)

    print(f"\n  Configuration saved to: {env_path}")

    # Detect Python environment and create appropriate MCP config
    mcpshield_path = shutil.which("mcpshield")

    if mcpshield_path and (".venv" in mcpshield_path or "venv" in mcpshield_path or "virtualenv" in mcpshield_path):
        # Virtual environment detected - use Python module approach
        # Extract venv path from mcpshield path (e.g., /path/to/.venv/bin/mcpshield -> /path/to/.venv)
        venv_path = str(Path(mcpshield_path).parent.parent)
        python_path = str(Path(venv_path) / "bin" / "python")

        logger.info(f"Virtual environment detected: {venv_path}")
        logger.info(f"Using Python: {python_path}")

        mcp_config = {
            "command": python_path,
            "args": ["-m", "mcpshield_gateway.cli", "serve", "--env-file", str(env_path)],
        }
    else:
        # System installation - use direct command
        mcp_config = {
            "command": "mcpshield",
            "args": ["serve", "--env-file", str(env_path)],
        }

    if choice in ["1", "3"]:  # Claude Code
        claude_config_path = Path.home() / ".claude" / "mcp.json"
        claude_config_path.parent.mkdir(parents=True, exist_ok=True)

        # Load existing config
        claude_config = {"mcpServers": {}}
        if claude_config_path.exists():
            try:
                with open(claude_config_path, "r") as f:
                    content = f.read().strip()
                    if content:  # Only parse if file has content
                        claude_config = json.loads(content)
                        if "mcpServers" not in claude_config:
                            claude_config["mcpServers"] = {}
            except json.JSONDecodeError:
                logger.warning(f"Invalid JSON in {claude_config_path}, will overwrite")
                claude_config = {"mcpServers": {}}

        # Add mcpshield server
        claude_config["mcpServers"]["mcpshield"] = mcp_config

        # Save
        with open(claude_config_path, "w") as f:
            json.dump(claude_config, f, indent=2)

        print(f"  Added to Claude Code: {claude_config_path}")

    if choice in ["2", "3"]:  # Cursor
        cursor_config_path = Path.home() / ".cursor" / "mcp.json"
        cursor_config_path.parent.mkdir(parents=True, exist_ok=True)

        # Load existing config
        cursor_config = {"mcpServers": {}}
        if cursor_config_path.exists():
            try:
                with open(cursor_config_path, "r") as f:
                    content = f.read().strip()
                    if content:  # Only parse if file has content
                        cursor_config = json.loads(content)
                        if "mcpServers" not in cursor_config:
                            cursor_config["mcpServers"] = {}
            except json.JSONDecodeError:
                logger.warning(f"Invalid JSON in {cursor_config_path}, will overwrite")
                cursor_config = {"mcpServers": {}}

        # Add mcpshield server
        cursor_config["mcpServers"]["mcpshield"] = mcp_config

        # Save
        with open(cursor_config_path, "w") as f:
            json.dump(cursor_config, f, indent=2)

        print(f"  Added to Cursor: {cursor_config_path}")

    print("\n" + "=" * 60)
    print("✅ SETUP COMPLETE!")
    print("=" * 60)
    print(f"\nProject: {project_name}")
    print(f"Infrastructure: {', '.join([BACKEND_LABELS.get(t, t) for t in infrastructure_types])}")
    print(f"Configuration: {env_path}")
    print("\nNext steps:")
    print("  1. Review/edit security policy in dashboard:")
    print("     → https://app.mcpshield.xyz")
    print("  2. Restart your IDE (Claude Code or Cursor)")
    print("  3. Test connection:")
    print(f"     → mcpshield doctor --env-file {env_path}")
    print("\n💡 MCP tools available:")
    for infra_type in normalized_types:
        if infra_type == "postgres":
            print("   • postgres.query, postgres.describe, postgres.dump, postgres.diagram")
        elif infra_type == "mysql":
            print("   • mysql.query, mysql.describe, mysql.dump, mysql.diagram")
        elif infra_type == "sqlite":
            print("   • sqlite.query, sqlite.describe, sqlite.dump, sqlite.diagram")
        elif infra_type == "mongodb":
            print("   • mongodb.query, mongodb.aggregate, mongodb.describe, mongodb.insert, mongodb.update, mongodb.delete")
        elif infra_type == "redis":
            print("   • redis.get, redis.set, redis.delete, redis.keys, redis.info")
    print("\n💡 To reconfigure for different infrastructure:")
    print("   → mcpshield init")
    print()


def cmd_doctor(args):
    """Run diagnostics to check setup."""
    setup_logging("INFO")
    logger = logging.getLogger(__name__)

    print("MCPShield Gateway Doctor")
    print("=" * 60)
    print(f"Version: {__version__}\n")

    errors = []
    warnings = []

    # 1. Check configuration
    print("1. Configuration")
    print("-" * 60)
    try:
        config = GatewayConfig.load(
            config_path=args.config,
            env_file=args.env_file if hasattr(args, 'env_file') else None
        )

        if args.config:
            print(f"  Configuration loaded from: {args.config}")
        else:
            print("  Configuration loaded from environment variables")

        print(f"  - Backend: {BACKEND_LABELS.get(config.backend, config.backend)}")
        print(f"  - API Base URL: {config.api_base_url}")
        print(f"  - Project ID: {config.project_id}")
        print(f"  - Policy source: {config.policy_source}")
        if config.policy_file:
            print(f"  - Policy file: {config.policy_file}")
        print(f"  - Cache directory: {config.cache_dir}")
        print(f"  - Spool directory: {config.spool_dir}")
    except FileNotFoundError as e:
        errors.append(f"Configuration error: {e}")
        print(f"  {e}")
        sys.exit(1)
    except ValueError as e:
        errors.append(f"Configuration error: {e}")
        print(f"  {e}")
        sys.exit(1)

    # 2. Check policy
    print("\n2. Policy")
    print("-" * 60)
    try:
        from .policy_sync import PolicySync

        # Initialize policy sync
        policy_sync = PolicySync(
            api_base_url=config.api_base_url,
            api_key=config.api_key,
            project_id=config.project_id,
            cache_dir=config.get_cache_dir(),
            source=config.policy_source,
            local_file=config.policy_file,
            refresh_seconds=config.policy_refresh_seconds,
        )

        # Try to fetch policy
        policy_yaml, policy_hash = policy_sync.get_policy_yaml()

        # Load policy engine
        policy = PolicyEngine(policy_yaml=policy_yaml)

        print(f"  Policy loaded successfully")
        print(f"  - Source: {config.policy_source}")
        print(f"  - Hash: {policy_hash[:16]}...")
        print(f"  - Default: {policy.default_decision.value}")
        print(f"  - Rules: {len(policy.rules)}")

        policy_sync.close()

    except Exception as e:
        errors.append(f"Policy error: {e}")
        print(f"  {e}")

    # 3. Check database connectivity
    print(f"\n3. Database Connectivity ({BACKEND_LABELS.get(config.backend, config.backend)})")
    print("-" * 60)
    try:
        if config.backend == "postgres":
            from .postgres import PostgresTools
            tools = PostgresTools(config.dsn)
            tools.connect()
            print("  Connected to PostgreSQL")
            result = tools.query("SELECT version()")
            print(f"  - Version: {result['rows'][0]['version'][:50]}...")
            tools.close()

        elif config.backend == "mysql":
            from .mysql import MySQLTools
            tools = MySQLTools(config.dsn)
            tools.connect()
            print("  Connected to MySQL")
            result = tools.query("SELECT version() AS version")
            print(f"  - Version: {result['rows'][0]['version']}")
            tools.close()

        elif config.backend == "sqlite":
            from .sqlite import SQLiteTools
            tools = SQLiteTools(config.dsn)
            tools.connect()
            print(f"  Connected to SQLite: {tools.db_path}")
            result = tools.query("SELECT sqlite_version() AS version")
            print(f"  - Version: {result['rows'][0]['version']}")
            tools.close()

        elif config.backend == "mongodb":
            from .mongodb import MongoDBTools
            tools = MongoDBTools(config.dsn)
            tools.connect()
            print("  Connected to MongoDB")
            desc = tools.describe()
            print(f"  - Database: {desc['database']}")
            print(f"  - Collections: {len(desc['collections'])}")
            tools.close()

        elif config.backend == "redis":
            from .redis_tools import RedisTools
            tools = RedisTools(config.dsn)
            tools.connect()
            print("  Connected to Redis")
            info = tools.info()
            print(f"  - Version: {info['info']['redis_version']}")
            print(f"  - DB size: {info['info']['db_size']} keys")
            tools.close()

    except Exception as e:
        errors.append(f"Database connection error: {e}")
        print(f"  {e}")

    # 4. Check API connectivity
    print("\n4. API Connectivity")
    print("-" * 60)
    try:
        import httpx
        client = httpx.Client(timeout=10.0)

        # Try health check first
        health_url = f"{config.api_base_url}/health"
        try:
            response = client.get(health_url)
            if response.status_code == 200:
                print(f"  API is reachable: {config.api_base_url}")
            else:
                warnings.append(f"API returned {response.status_code} for health check")
                print(f"  API health check returned {response.status_code}")
        except Exception as e:
            errors.append(f"Cannot reach API: {e}")
            print(f"  Cannot reach API: {e}")

        # Test authentication
        try:
            policy_url = f"{config.api_base_url}/projects/{config.project_id}/policy"
            response = client.get(
                policy_url,
                headers={"X-API-Key": config.api_key}
            )

            if response.status_code == 200:
                print("  API authentication successful")
            elif response.status_code == 401:
                errors.append("API authentication failed (401 - invalid API key)")
                print("  API authentication failed (401)")
            elif response.status_code == 403:
                errors.append("API authentication failed (403 - access denied)")
                print("  API authentication failed (403)")
            elif response.status_code == 404:
                warnings.append("Policy not found (404 - create policy in dashboard)")
                print("  Policy not found (404)")
            else:
                print("  API authentication successful")
                if response.status_code != 200:
                    warnings.append(f"Policy endpoint returned {response.status_code}")

        except Exception as e:
            warnings.append(f"API authentication test failed: {e}")
            print(f"  API test failed: {e}")

        client.close()
    except Exception as e:
        errors.append(f"API check error: {e}")
        print(f"  {e}")

    # 5. Check spool directory
    print("\n5. Event Spooling")
    print("-" * 60)
    try:
        spool_dir = config.get_spool_dir()
        if not spool_dir.exists():
            spool_dir.mkdir(parents=True, exist_ok=True)
            print(f"  Created spool directory: {spool_dir}")
        else:
            print(f"  Spool directory exists: {spool_dir}")

        # Check for spooled events
        spool_files = list(spool_dir.glob("*.jsonl"))
        if spool_files:
            warnings.append(f"{len(spool_files)} spooled event files found")
            print(f"  {len(spool_files)} spooled event files (will retry on next run)")
        else:
            print("  - No spooled events")

    except Exception as e:
        errors.append(f"Spool directory error: {e}")
        print(f"  {e}")

    # Summary
    print("\n" + "=" * 60)
    if errors:
        print("DIAGNOSTICS FAILED")
        print("=" * 60)
        print("\nErrors found:")
        for error in errors:
            print(f"    {error}")

        if warnings:
            print("\nWarnings:")
            for warning in warnings:
                print(f"    {warning}")

        print("\nPlease fix the errors above before running the gateway.")
        sys.exit(1)
    else:
        print("DIAGNOSTICS PASSED")
        print("=" * 60)

        if warnings:
            print("\nWarnings:")
            for warning in warnings:
                print(f"    {warning}")

        print("\n  Your gateway is ready to use!")
        print("\nNext steps:")
        print("  1. Add to Claude Code MCP configuration")
        if args.config:
            print(f"  2. Run: mcpshield serve --config {args.config}")
        else:
            print("  2. Run: mcpshield serve")
        print("  3. Test with a query")


def main():
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        prog="mcpshield",
        description="MCPShield Gateway - Secure infrastructure access for AI agents (databases, APIs, cloud, and more)",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"mcpshield {__version__}",
    )

    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # serve command
    serve_parser = subparsers.add_parser(
        "serve",
        help="Run the MCP server",
    )
    serve_parser.add_argument(
        "--config",
        required=False,
        help="Path to configuration file (mcpshield.yaml). If not provided, uses environment variables.",
    )
    serve_parser.add_argument(
        "--env-file",
        dest="env_file",
        required=False,
        help="Path to .env file for loading environment variables (optional)",
    )
    serve_parser.set_defaults(func=cmd_serve)

    # validate command
    validate_parser = subparsers.add_parser(
        "validate",
        help="Validate configuration and policy files",
    )
    validate_parser.add_argument(
        "--config",
        required=False,
        help="Path to configuration file (mcpshield.yaml). If not provided, uses environment variables.",
    )
    validate_parser.add_argument(
        "--env-file",
        dest="env_file",
        required=False,
        help="Path to .env file for loading environment variables (optional)",
    )
    validate_parser.set_defaults(func=cmd_validate)

    # init command
    init_parser = subparsers.add_parser(
        "init",
        help="Initialize MCPShield Gateway configuration (interactive setup wizard)",
    )
    init_parser.set_defaults(func=cmd_init)

    # doctor command
    doctor_parser = subparsers.add_parser(
        "doctor",
        help="Run diagnostics to check setup",
    )
    doctor_parser.add_argument(
        "--config",
        required=False,
        help="Path to configuration file (mcpshield.yaml). If not provided, uses environment variables.",
    )
    doctor_parser.add_argument(
        "--env-file",
        dest="env_file",
        required=False,
        help="Path to .env file for loading environment variables (optional)",
    )
    doctor_parser.set_defaults(func=cmd_doctor)

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(1)

    args.func(args)


if __name__ == "__main__":
    main()
