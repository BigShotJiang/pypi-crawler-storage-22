"""MongoDB tools for MCPShield Gateway."""

import json
import logging
from typing import Dict, Any, List, Optional
from datetime import datetime

logger = logging.getLogger(__name__)

# Maximum number of documents to return per query
_DEFAULT_LIMIT = 100


class MongoDBTools:
    """MongoDB tools with policy enforcement."""

    def __init__(self, dsn: str, timeout_seconds: int = 5, max_rows: int = 100):
        """Initialize MongoDB tools.

        Args:
            dsn: MongoDB connection string (e.g. mongodb://user:pass@host:27017/db)
            timeout_seconds: Operation timeout in seconds.
            max_rows: Maximum documents to return per query.
        """
        self.dsn = dsn
        self.timeout_seconds = timeout_seconds
        self.max_rows = max_rows
        self._client = None
        self._db = None

    def connect(self):
        """Establish database connection."""
        if self._client is None:
            from pymongo import MongoClient
            from urllib.parse import urlparse

            self._client = MongoClient(
                self.dsn,
                serverSelectionTimeoutMS=self.timeout_seconds * 1000,
                connectTimeoutMS=self.timeout_seconds * 1000,
                socketTimeoutMS=self.timeout_seconds * 1000,
            )

            # Extract database name from DSN
            parsed = urlparse(self.dsn)
            db_name = parsed.path.lstrip("/").split("?")[0]
            if not db_name:
                raise ValueError("MongoDB DSN must include a database name (e.g. mongodb://host/mydb)")

            self._db = self._client[db_name]
            # Force connection test
            self._client.admin.command("ping")
            logger.info(f"MongoDB connection established: {db_name}")

    def close(self):
        """Close database connection."""
        if self._client is not None:
            self._client.close()
            self._client = None
            self._db = None
            logger.info("MongoDB connection closed")

    @staticmethod
    def _serialize_doc(doc: Any) -> Any:
        """Recursively serialize a MongoDB document to JSON-safe types."""
        from bson import ObjectId

        if isinstance(doc, dict):
            return {k: MongoDBTools._serialize_doc(v) for k, v in doc.items()}
        elif isinstance(doc, list):
            return [MongoDBTools._serialize_doc(item) for item in doc]
        elif isinstance(doc, ObjectId):
            return str(doc)
        elif isinstance(doc, datetime):
            return doc.isoformat()
        elif isinstance(doc, bytes):
            return doc.hex()
        return doc

    def query(
        self,
        collection: str,
        filter: Optional[Dict] = None,
        projection: Optional[Dict] = None,
        limit: Optional[int] = None,
        sort: Optional[List] = None,
    ) -> Dict[str, Any]:
        """Execute a find query on a collection."""
        start_time = datetime.utcnow()

        try:
            self.connect()

            coll = self._db[collection]
            effective_limit = min(limit or self.max_rows, self.max_rows)

            cursor = coll.find(
                filter=filter or {},
                projection=projection,
            )
            if sort:
                cursor = cursor.sort(sort)

            # Fetch one extra to detect limit hit
            docs = list(cursor.limit(effective_limit + 1))
            hit_limit = len(docs) > effective_limit
            if hit_limit:
                docs = docs[:effective_limit]

            results = [self._serialize_doc(doc) for doc in docs]

            latency_ms = (datetime.utcnow() - start_time).total_seconds() * 1000
            return {
                "documents": results,
                "count": len(results),
                "hit_limit": hit_limit,
                "latency_ms": latency_ms,
            }

        except Exception as e:
            logger.error(f"MongoDB query error: {e}")
            raise Exception(f"MongoDB error: {str(e)}") from e

    def aggregate(self, collection: str, pipeline: List[Dict]) -> Dict[str, Any]:
        """Execute an aggregation pipeline."""
        start_time = datetime.utcnow()

        try:
            self.connect()

            coll = self._db[collection]

            # Inject $limit stage if not present to enforce max_rows
            has_limit = any("$limit" in stage for stage in pipeline)
            if not has_limit:
                pipeline = pipeline + [{"$limit": self.max_rows}]

            cursor = coll.aggregate(pipeline)
            results = [self._serialize_doc(doc) for doc in cursor]

            latency_ms = (datetime.utcnow() - start_time).total_seconds() * 1000
            return {
                "documents": results,
                "count": len(results),
                "latency_ms": latency_ms,
            }

        except Exception as e:
            logger.error(f"MongoDB aggregate error: {e}")
            raise Exception(f"MongoDB error: {str(e)}") from e

    def describe(self) -> Dict[str, Any]:
        """List collections and sample document structure."""
        start_time = datetime.utcnow()

        try:
            self.connect()

            collection_names = self._db.list_collection_names()
            collections = {}

            for name in sorted(collection_names):
                coll = self._db[name]
                doc_count = coll.estimated_document_count()

                # Sample one document to infer structure
                sample = coll.find_one()
                fields = {}
                if sample:
                    for key, value in sample.items():
                        fields[key] = type(value).__name__

                collections[name] = {
                    "document_count": doc_count,
                    "fields": fields,
                }

            latency_ms = (datetime.utcnow() - start_time).total_seconds() * 1000
            return {
                "database": self._db.name,
                "collections": collections,
                "latency_ms": latency_ms,
            }

        except Exception as e:
            logger.error(f"MongoDB describe error: {e}")
            raise Exception(f"MongoDB error: {str(e)}") from e

    def insert(self, collection: str, documents: List[Dict]) -> Dict[str, Any]:
        """Insert one or many documents."""
        start_time = datetime.utcnow()

        try:
            self.connect()

            coll = self._db[collection]

            if len(documents) == 1:
                result = coll.insert_one(documents[0])
                ids = [str(result.inserted_id)]
            else:
                result = coll.insert_many(documents)
                ids = [str(id_) for id_ in result.inserted_ids]

            latency_ms = (datetime.utcnow() - start_time).total_seconds() * 1000
            return {
                "inserted_ids": ids,
                "inserted_count": len(ids),
                "latency_ms": latency_ms,
            }

        except Exception as e:
            logger.error(f"MongoDB insert error: {e}")
            raise Exception(f"MongoDB error: {str(e)}") from e

    def update(self, collection: str, filter: Dict, update: Dict) -> Dict[str, Any]:
        """Update documents matching filter."""
        start_time = datetime.utcnow()

        try:
            self.connect()

            coll = self._db[collection]
            result = coll.update_many(filter, update)

            latency_ms = (datetime.utcnow() - start_time).total_seconds() * 1000
            return {
                "matched_count": result.matched_count,
                "modified_count": result.modified_count,
                "latency_ms": latency_ms,
            }

        except Exception as e:
            logger.error(f"MongoDB update error: {e}")
            raise Exception(f"MongoDB error: {str(e)}") from e

    def delete(self, collection: str, filter: Dict) -> Dict[str, Any]:
        """Delete documents matching filter."""
        start_time = datetime.utcnow()

        try:
            self.connect()

            if not filter:
                raise ValueError("Empty filter not allowed for delete (would delete all documents)")

            coll = self._db[collection]
            result = coll.delete_many(filter)

            latency_ms = (datetime.utcnow() - start_time).total_seconds() * 1000
            return {
                "deleted_count": result.deleted_count,
                "latency_ms": latency_ms,
            }

        except Exception as e:
            logger.error(f"MongoDB delete error: {e}")
            raise Exception(f"MongoDB error: {str(e)}") from e

    def dump(self, collections: Optional[List[str]] = None, include_data: bool = False) -> Dict[str, Any]:
        """Generate a MongoDB dump (JSON export of collections)."""
        start_time = datetime.utcnow()

        try:
            self.connect()

            collection_names = collections or self._db.list_collection_names()
            dump_data = {}

            for coll_name in sorted(collection_names):
                coll = self._db[coll_name]

                # Schema info
                sample = coll.find_one()
                fields = {}
                if sample:
                    for key, value in sample.items():
                        fields[key] = type(value).__name__

                dump_data[coll_name] = {
                    "collection": coll_name,
                    "document_count": coll.estimated_document_count(),
                    "fields": fields,
                }

                # Include data if requested
                if include_data:
                    cursor = coll.find().limit(self.max_rows)
                    docs = [self._serialize_doc(doc) for doc in cursor]
                    dump_data[coll_name]["documents"] = docs

            latency_ms = (datetime.utcnow() - start_time).total_seconds() * 1000
            return {
                "database": self._db.name,
                "collections": dump_data,
                "collection_count": len(dump_data),
                "latency_ms": latency_ms,
            }

        except Exception as e:
            logger.error(f"MongoDB dump error: {e}")
            raise Exception(f"MongoDB error: {str(e)}") from e

    def diagram(self, format: str = "mermaid") -> Dict[str, Any]:
        """Generate an ER diagram of MongoDB collections in Mermaid format."""
        start_time = datetime.utcnow()

        try:
            self.connect()

            collection_names = self._db.list_collection_names()
            lines = ["erDiagram"]

            for coll_name in sorted(collection_names):
                coll = self._db[coll_name]

                # Sample one document to infer structure
                sample = coll.find_one()
                if sample:
                    lines.append(f"    {coll_name} {{")
                    for key, value in sample.items():
                        field_type = type(value).__name__
                        # ObjectId is typically the PK
                        comment = " PK" if key == "_id" else ""
                        lines.append(f"        {field_type} {key}{comment}")
                    lines.append("    }")
                else:
                    # Empty collection
                    lines.append(f"    {coll_name} {{}}")

                # Detect potential references (fields ending with _id or containing 'ref')
                if sample:
                    for key, value in sample.items():
                        if key.endswith("_id") and key != "_id":
                            # Guess referenced collection
                            ref_collection = key[:-3]  # Remove _id suffix
                            if ref_collection in collection_names or f"{ref_collection}s" in collection_names:
                                ref_target = ref_collection if ref_collection in collection_names else f"{ref_collection}s"
                                lines.append(f'    {coll_name} }}o--|| {ref_target} : "{key}"')

            diagram_text = "\n".join(lines)
            latency_ms = (datetime.utcnow() - start_time).total_seconds() * 1000
            return {
                "diagram": diagram_text,
                "format": format,
                "collection_count": len(collection_names),
                "latency_ms": latency_ms,
            }

        except Exception as e:
            logger.error(f"MongoDB diagram error: {e}")
            raise Exception(f"MongoDB error: {str(e)}") from e
