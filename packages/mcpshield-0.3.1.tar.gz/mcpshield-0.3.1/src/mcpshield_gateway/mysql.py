"""MySQL tools for MCPShield Gateway."""

import logging
from typing import Dict, Any, List, Optional
from datetime import datetime, date
from decimal import Decimal

logger = logging.getLogger(__name__)


class MySQLTools:
    """MySQL tools with policy enforcement."""

    def __init__(self, dsn: str, timeout_seconds: int = 5, max_rows: int = 100):
        """Initialize MySQL tools.

        Args:
            dsn: MySQL connection string (e.g. mysql://user:pass@host:3306/db)
            timeout_seconds: Query timeout in seconds.
            max_rows: Maximum rows to return per query.
        """
        self.dsn = dsn
        self.timeout_seconds = timeout_seconds
        self.max_rows = max_rows
        self._conn = None

    def connect(self):
        """Establish database connection."""
        import mysql.connector

        if self._conn is None or not self._conn.is_connected():
            # Parse DSN into components
            params = self._parse_dsn(self.dsn)
            self._conn = mysql.connector.connect(
                host=params.get("host", "localhost"),
                port=int(params.get("port", 3306)),
                user=params.get("user", ""),
                password=params.get("password", ""),
                database=params.get("database", ""),
                connection_timeout=self.timeout_seconds,
                autocommit=True,
            )
            logger.info("MySQL connection established")

    def close(self):
        """Close database connection."""
        if self._conn and self._conn.is_connected():
            self._conn.close()
            logger.info("MySQL connection closed")

    @staticmethod
    def _parse_dsn(dsn: str) -> Dict[str, str]:
        """Parse a MySQL DSN into components."""
        from urllib.parse import urlparse

        # Support mysql:// and mysql+connector:// schemes
        parsed = urlparse(dsn)
        return {
            "host": parsed.hostname or "localhost",
            "port": str(parsed.port or 3306),
            "user": parsed.username or "",
            "password": parsed.password or "",
            "database": parsed.path.lstrip("/") if parsed.path else "",
        }

    @staticmethod
    def _serialize_value(value: Any) -> Any:
        """Convert non-JSON-serializable types."""
        if isinstance(value, datetime):
            return value.isoformat()
        if isinstance(value, date):
            return value.isoformat()
        if isinstance(value, (bytes, bytearray)):
            return value.hex()
        if isinstance(value, Decimal):
            return float(value)
        return value

    def query(self, sql: str, params: Optional[List] = None) -> Dict[str, Any]:
        """Execute a SQL query and return results."""
        start_time = datetime.utcnow()

        try:
            self.connect()

            cursor = self._conn.cursor()
            try:
                cursor.execute(f"SET SESSION wait_timeout = {self.timeout_seconds}")
                if params:
                    cursor.execute(sql, params)
                else:
                    cursor.execute(sql)

                if cursor.description:
                    rows = cursor.fetchmany(self.max_rows + 1)
                    columns = [desc[0] for desc in cursor.description]

                    hit_limit = len(rows) > self.max_rows
                    if hit_limit:
                        rows = rows[:self.max_rows]

                    results = []
                    for row in rows:
                        row_dict = {}
                        for col_name, value in zip(columns, row):
                            row_dict[col_name] = self._serialize_value(value)
                        results.append(row_dict)

                    latency_ms = (datetime.utcnow() - start_time).total_seconds() * 1000
                    return {
                        "columns": columns,
                        "rows": results,
                        "row_count": len(results),
                        "hit_limit": hit_limit,
                        "latency_ms": latency_ms,
                    }
                else:
                    affected = cursor.rowcount if cursor.rowcount >= 0 else 0
                    latency_ms = (datetime.utcnow() - start_time).total_seconds() * 1000
                    return {
                        "affected_rows": affected,
                        "latency_ms": latency_ms,
                    }
            finally:
                cursor.close()

        except Exception as e:
            logger.error(f"MySQL error: {e}")
            raise Exception(f"MySQL error: {str(e)}") from e

    def describe(self, schema: Optional[str] = None) -> Dict[str, Any]:
        """Describe database schema (tables and columns)."""
        start_time = datetime.utcnow()

        try:
            self.connect()

            cursor = self._conn.cursor()
            try:
                if schema:
                    query = """
                        SELECT table_schema, table_name, column_name, data_type, is_nullable
                        FROM information_schema.columns
                        WHERE table_schema = %s
                        ORDER BY table_schema, table_name, ordinal_position
                    """
                    cursor.execute(query, (schema,))
                else:
                    query = """
                        SELECT table_schema, table_name, column_name, data_type, is_nullable
                        FROM information_schema.columns
                        WHERE table_schema NOT IN ('information_schema', 'mysql', 'performance_schema', 'sys')
                        ORDER BY table_schema, table_name, ordinal_position
                    """
                    cursor.execute(query)

                rows = cursor.fetchall()
            finally:
                cursor.close()

            schemas: Dict[str, Dict[str, List[Dict]]] = {}
            for schema_name, table_name, column_name, data_type, is_nullable in rows:
                if schema_name not in schemas:
                    schemas[schema_name] = {}
                if table_name not in schemas[schema_name]:
                    schemas[schema_name][table_name] = []
                schemas[schema_name][table_name].append({
                    "name": column_name,
                    "type": data_type,
                    "nullable": is_nullable == "YES",
                })

            latency_ms = (datetime.utcnow() - start_time).total_seconds() * 1000
            return {"schemas": schemas, "latency_ms": latency_ms}

        except Exception as e:
            logger.error(f"MySQL describe error: {e}")
            raise Exception(f"MySQL error: {str(e)}") from e

    def dump(
        self,
        schema: Optional[str] = None,
        include_data: bool = False,
        tables: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """Generate a SQL dump by querying information_schema."""
        start_time = datetime.utcnow()

        try:
            self.connect()
            lines: List[str] = []
            lines.append("-- MCPShield SQL Dump (MySQL)")
            lines.append(f"-- Generated: {datetime.utcnow().isoformat()}")
            lines.append("")

            cursor = self._conn.cursor()
            try:
                # Get tables
                if schema:
                    cursor.execute(
                        "SELECT table_schema, table_name FROM information_schema.tables "
                        "WHERE table_type = 'BASE TABLE' AND table_schema = %s "
                        "ORDER BY table_schema, table_name",
                        (schema,),
                    )
                else:
                    cursor.execute(
                        "SELECT table_schema, table_name FROM information_schema.tables "
                        "WHERE table_type = 'BASE TABLE' "
                        "AND table_schema NOT IN ('information_schema','mysql','performance_schema','sys') "
                        "ORDER BY table_schema, table_name"
                    )

                all_tables = cursor.fetchall()
                if tables:
                    all_tables = [(s, t) for s, t in all_tables if t in tables or f"{s}.{t}" in tables]

                table_count = len(all_tables)

                for tbl_schema, tbl_name in all_tables:
                    cursor.execute(f"SHOW CREATE TABLE `{tbl_schema}`.`{tbl_name}`")
                    row = cursor.fetchone()
                    if row:
                        lines.append(row[1] + ";")
                        lines.append("")

                    if include_data:
                        cursor.execute(f"SELECT * FROM `{tbl_schema}`.`{tbl_name}`")
                        col_names = [desc[0] for desc in cursor.description]
                        data_rows = cursor.fetchall()
                        for data_row in data_rows:
                            values = []
                            for v in data_row:
                                if v is None:
                                    values.append("NULL")
                                elif isinstance(v, str):
                                    values.append("'" + v.replace("'", "''") + "'")
                                elif isinstance(v, (datetime, date)):
                                    values.append(f"'{v.isoformat()}'")
                                elif isinstance(v, bool):
                                    values.append("1" if v else "0")
                                else:
                                    values.append(str(v))
                            col_list = ", ".join(f"`{c}`" for c in col_names)
                            lines.append(f"INSERT INTO `{tbl_schema}`.`{tbl_name}` ({col_list}) VALUES ({', '.join(values)});")
                        lines.append("")
            finally:
                cursor.close()

            latency_ms = (datetime.utcnow() - start_time).total_seconds() * 1000
            return {"sql": "\n".join(lines), "table_count": table_count, "latency_ms": latency_ms}

        except Exception as e:
            logger.error(f"MySQL dump error: {e}")
            raise Exception(f"MySQL error: {str(e)}") from e

    def diagram(
        self,
        schema: Optional[str] = None,
        format: str = "mermaid",
    ) -> Dict[str, Any]:
        """Generate an ER diagram in Mermaid format."""
        start_time = datetime.utcnow()

        try:
            self.connect()
            cursor = self._conn.cursor()
            try:
                schema_filter = "c.table_schema = %s" if schema else "c.table_schema NOT IN ('information_schema','mysql','performance_schema','sys')"
                params = (schema,) if schema else ()

                # Tables
                cursor.execute(
                    f"SELECT DISTINCT table_schema, table_name FROM information_schema.tables "
                    f"WHERE table_type = 'BASE TABLE' AND "
                    f"{'table_schema = %s' if schema else \"table_schema NOT IN ('information_schema','mysql','performance_schema','sys')\"} "
                    f"ORDER BY table_schema, table_name",
                    params,
                )
                all_tables = cursor.fetchall()
                table_count = len(all_tables)

                # Columns with PK info
                cursor.execute(
                    f"SELECT c.table_schema, c.table_name, c.column_name, c.data_type, c.is_nullable, c.column_key "
                    f"FROM information_schema.columns c WHERE {schema_filter} "
                    f"ORDER BY c.table_schema, c.table_name, c.ordinal_position",
                    params,
                )
                columns_rows = cursor.fetchall()

                # Foreign keys
                cursor.execute(
                    f"SELECT k.table_schema, k.table_name, k.column_name, "
                    f"k.referenced_table_schema, k.referenced_table_name, k.referenced_column_name "
                    f"FROM information_schema.key_column_usage k "
                    f"WHERE k.referenced_table_name IS NOT NULL AND "
                    f"{'k.table_schema = %s' if schema else \"k.table_schema NOT IN ('information_schema','mysql','performance_schema','sys')\"} ",
                    params,
                )
                fk_rows = cursor.fetchall()
            finally:
                cursor.close()

            lines = ["erDiagram"]
            table_columns: Dict[str, List] = {}
            for tbl_schema, tbl_name, col_name, data_type, is_nullable, column_key in columns_rows:
                if tbl_name not in table_columns:
                    table_columns[tbl_name] = []
                table_columns[tbl_name].append((col_name, data_type, is_nullable, column_key == "PRI"))

            for tbl_schema, tbl_name in all_tables:
                cols = table_columns.get(tbl_name, [])
                lines.append(f"    {tbl_name} {{")
                for col_name, data_type, is_nullable, is_pk in cols:
                    mermaid_type = data_type.replace(" ", "_")
                    comment = " PK" if is_pk else ""
                    lines.append(f"        {mermaid_type} {col_name}{comment}")
                lines.append("    }")

            for tbl_schema, tbl_name, col_name, ref_schema, ref_table, ref_col in fk_rows:
                lines.append(f'    {tbl_name} }}o--|| {ref_table} : "{col_name}"')

            diagram_text = "\n".join(lines)
            latency_ms = (datetime.utcnow() - start_time).total_seconds() * 1000
            return {"diagram": diagram_text, "format": format, "table_count": table_count, "latency_ms": latency_ms}

        except Exception as e:
            logger.error(f"MySQL diagram error: {e}")
            raise Exception(f"MySQL error: {str(e)}") from e
