"""Policy engine for MCPShield Gateway."""

import re
import fnmatch
import logging
import yaml
import sqlparse
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional, Dict, Any
from enum import Enum


logger = logging.getLogger(__name__)


class Decision(Enum):
    """Policy decision."""
    ALLOW = "allow"
    DENY = "deny"


@dataclass
class PolicyDecision:
    """Result of policy evaluation."""
    decision: Decision
    reason: str
    matched_rule: Optional[str] = None
    redactions: List[str] = None


@dataclass
class PolicyRule:
    """Single policy rule."""
    name: str
    tool: str
    decision: Decision
    conditions: Dict[str, Any]


class PolicyEngine:
    """
    Deterministic policy engine with FAIL-CLOSED behavior.

    Default deny: all operations blocked unless explicitly allowed.

    Supports two policy YAML formats:

    Format 1 (rules-based, recommended for local files):
        default: deny
        limits: { max_rows: 100, timeout_seconds: 5 }
        restrictions: { allow_schemas: [...], allow_tables: [...] }
        redaction: [{ name: email, pattern: '...' }]
        rules:
          - name: allow_select
            tool: postgres_query
            decision: allow

    Format 2 (tools-based, used by MCPShield dashboard):
        tools:
          postgres.query:
            allow: true
            allow_statements: [SELECT]
            max_rows: 100
            deny_regex: [...]
            redact: [{ type: regex, pattern: '...', replace: '...' }]
    """

    # All recognized SQL statement types
    ALL_STATEMENT_TYPES = {
        "SELECT", "INSERT", "UPDATE", "DELETE", "CREATE", "ALTER",
        "DROP", "TRUNCATE", "GRANT", "REVOKE", "REPLACE", "COPY",
        "WITH",
    }

    # Map MCP tool names (underscore) to policy tool names (dot) and back
    TOOL_NAME_ALIASES = {
        # PostgreSQL
        "postgres_query": "postgres.query",
        "postgres_describe": "postgres.describe",
        "postgres_dump": "postgres.dump",
        "postgres_diagram": "postgres.diagram",
        "postgres.query": "postgres.query",
        "postgres.describe": "postgres.describe",
        "postgres.dump": "postgres.dump",
        "postgres.diagram": "postgres.diagram",
        # MySQL
        "mysql_query": "mysql.query",
        "mysql_describe": "mysql.describe",
        "mysql_dump": "mysql.dump",
        "mysql_diagram": "mysql.diagram",
        "mysql.query": "mysql.query",
        "mysql.describe": "mysql.describe",
        "mysql.dump": "mysql.dump",
        "mysql.diagram": "mysql.diagram",
        # SQLite
        "sqlite_query": "sqlite.query",
        "sqlite_describe": "sqlite.describe",
        "sqlite_dump": "sqlite.dump",
        "sqlite_diagram": "sqlite.diagram",
        "sqlite.query": "sqlite.query",
        "sqlite.describe": "sqlite.describe",
        "sqlite.dump": "sqlite.dump",
        "sqlite.diagram": "sqlite.diagram",
        # MongoDB
        "mongodb_query": "mongodb.query",
        "mongodb_aggregate": "mongodb.aggregate",
        "mongodb_describe": "mongodb.describe",
        "mongodb_insert": "mongodb.insert",
        "mongodb_update": "mongodb.update",
        "mongodb_delete": "mongodb.delete",
        "mongodb_dump": "mongodb.dump",
        "mongodb_diagram": "mongodb.diagram",
        "mongodb.query": "mongodb.query",
        "mongodb.aggregate": "mongodb.aggregate",
        "mongodb.describe": "mongodb.describe",
        "mongodb.insert": "mongodb.insert",
        "mongodb.update": "mongodb.update",
        "mongodb.delete": "mongodb.delete",
        "mongodb.dump": "mongodb.dump",
        "mongodb.diagram": "mongodb.diagram",
        # Redis
        "redis_get": "redis.get",
        "redis_set": "redis.set",
        "redis_delete": "redis.delete",
        "redis_keys": "redis.keys",
        "redis_info": "redis.info",
        "redis_describe": "redis.describe",
        "redis_backup": "redis.backup",
        "redis.get": "redis.get",
        "redis.set": "redis.set",
        "redis.delete": "redis.delete",
        "redis.keys": "redis.keys",
        "redis.info": "redis.info",
        "redis.describe": "redis.describe",
        "redis.backup": "redis.backup",
    }

    # SQL backends that share _evaluate_query logic
    _SQL_QUERY_TOOLS = {"postgres.query", "mysql.query", "sqlite.query"}

    # Sibling tool mapping: when the .query tool is allowed, auto-allow these too
    _SIBLING_TOOLS = {
        "postgres.query": ("postgres.describe", "postgres.dump", "postgres.diagram"),
        "mysql.query": ("mysql.describe", "mysql.dump", "mysql.diagram"),
        "sqlite.query": ("sqlite.describe", "sqlite.dump", "sqlite.diagram"),
        "mongodb.query": ("mongodb.describe", "mongodb.dump", "mongodb.diagram"),
        "redis.get": ("redis.info", "redis.describe", "redis.backup"),
    }

    def __init__(self, policy_file: Optional[str] = None, policy_yaml: Optional[str] = None):
        """Initialize policy engine from YAML file or string."""
        self.policy_file = Path(policy_file).expanduser() if policy_file else None
        self.rules: List[PolicyRule] = []
        self.default_decision = Decision.DENY
        self.max_rows = 100
        self.timeout_seconds = 5
        self.max_bytes = 1_048_576  # 1MB
        self.redaction_patterns: List[tuple[str, re.Pattern]] = []
        self.deny_regex_patterns: List[re.Pattern] = []
        self.allow_schemas: Optional[List[str]] = None
        self.allow_tables: Optional[List[str]] = None
        self.allow_statements: List[str] = ["SELECT"]  # Safe default

        # MongoDB-specific policy
        self.mongodb_allow_collections: Optional[List[str]] = None
        self.mongodb_allow_operations: Optional[List[str]] = None  # find, aggregate, insert, update, delete

        # Redis-specific policy
        self.redis_allow_commands: Optional[List[str]] = None  # get, set, delete, keys, info
        self.redis_allow_key_patterns: Optional[List[str]] = None  # glob patterns for allowed keys

        if policy_yaml:
            self._parse_policy(yaml.safe_load(policy_yaml) or {})
        elif policy_file:
            self._load_policy()
        else:
            raise ValueError("Must provide either policy_file or policy_yaml")

    @classmethod
    def from_yaml_string(cls, policy_yaml: str) -> "PolicyEngine":
        """Create policy engine from YAML string."""
        return cls(policy_yaml=policy_yaml)

    @staticmethod
    def _normalize_tool_name(name: str) -> str:
        """Normalize tool name to dot notation (policy canonical form)."""
        return PolicyEngine.TOOL_NAME_ALIASES.get(name, name)

    def _load_policy(self):
        """Load and parse policy from YAML file."""
        if not self.policy_file or not self.policy_file.exists():
            raise FileNotFoundError(f"Policy file not found: {self.policy_file}")

        with open(self.policy_file, "r") as f:
            data = yaml.safe_load(f) or {}

        self._parse_policy(data)

    def _parse_policy(self, data: Dict[str, Any]):
        """Parse policy from dictionary. Supports both rules-based and tools-based formats."""

        # Detect format: if "tools" key exists, use dashboard format
        if "tools" in data:
            self._parse_tools_format(data)
        else:
            self._parse_rules_format(data)

    def _parse_tools_format(self, data: Dict[str, Any]):
        """Parse dashboard tools-based policy format."""
        tools = data.get("tools", {})

        # Parse global settings from top level if present
        self.default_decision = Decision.DENY if data.get("default", "deny") == "deny" else Decision.ALLOW

        for tool_name, tool_config in tools.items():
            if not isinstance(tool_config, dict):
                continue

            canonical_name = self._normalize_tool_name(tool_name)

            # Extract limits from tool config
            if "max_rows" in tool_config:
                self.max_rows = tool_config["max_rows"]
            if "timeout_seconds" in tool_config:
                self.timeout_seconds = tool_config["timeout_seconds"]
            if "max_bytes" in tool_config:
                self.max_bytes = tool_config["max_bytes"]

            # Extract schema/table restrictions (SQL backends)
            if "allow_schemas" in tool_config:
                self.allow_schemas = tool_config["allow_schemas"]
            if "allow_tables" in tool_config:
                self.allow_tables = tool_config["allow_tables"]

            # Extract deny_regex patterns (SQL backends)
            for pattern_str in tool_config.get("deny_regex", []):
                try:
                    self.deny_regex_patterns.append(re.compile(pattern_str))
                except re.error as e:
                    logger.warning(f"Invalid deny_regex pattern '{pattern_str}': {e}")

            # Extract redaction rules
            for redact_rule in tool_config.get("redact", []):
                pattern = redact_rule.get("pattern")
                replace_text = redact_rule.get("replace", "[REDACTED]")
                if pattern:
                    try:
                        self.redaction_patterns.append((replace_text, re.compile(pattern)))
                    except re.error as e:
                        logger.warning(f"Invalid redaction pattern '{pattern}': {e}")

            # Extract allow_statements (SQL backends)
            if "allow_statements" in tool_config:
                stmts = tool_config["allow_statements"]
                if isinstance(stmts, list):
                    upper = [s.upper() for s in stmts]
                    if "ALL" in upper:
                        self.allow_statements = list(self.ALL_STATEMENT_TYPES)
                    else:
                        self.allow_statements = upper

            # MongoDB-specific config
            if "allow_collections" in tool_config:
                self.mongodb_allow_collections = tool_config["allow_collections"]
            if "allow_operations" in tool_config:
                self.mongodb_allow_operations = [op.lower() for op in tool_config["allow_operations"]]

            # Redis-specific config
            if "allow_commands" in tool_config:
                self.redis_allow_commands = [cmd.lower() for cmd in tool_config["allow_commands"]]
            if "allow_key_patterns" in tool_config:
                self.redis_allow_key_patterns = tool_config["allow_key_patterns"]

            # Create rule from tool config
            if tool_config.get("allow", False):
                self.rules.append(PolicyRule(
                    name=f"allow_{canonical_name}",
                    tool=canonical_name,
                    decision=Decision.ALLOW,
                    conditions={}
                ))

            # Auto-allow sibling tools when primary tool is allowed
            if tool_config.get("allow", False) and canonical_name in self._SIBLING_TOOLS:
                for sibling in self._SIBLING_TOOLS[canonical_name]:
                    self.rules.append(PolicyRule(
                        name=f"allow_{sibling}",
                        tool=sibling,
                        decision=Decision.ALLOW,
                        conditions={}
                    ))

    def _parse_rules_format(self, data: Dict[str, Any]):
        """Parse rules-based policy format (local files / docs format)."""

        # Parse global settings
        self.default_decision = Decision.DENY if data.get("default", "deny") == "deny" else Decision.ALLOW

        limits = data.get("limits", {})
        self.max_rows = limits.get("max_rows", 100)
        self.timeout_seconds = limits.get("timeout_seconds", 5)
        self.max_bytes = limits.get("max_bytes", 1_048_576)

        # Parse allow_statements
        if "allow_statements" in data:
            stmts = data["allow_statements"]
            if isinstance(stmts, list):
                upper = [s.upper() for s in stmts]
                if "ALL" in upper:
                    self.allow_statements = list(self.ALL_STATEMENT_TYPES)
                else:
                    self.allow_statements = upper

        # Parse schema/table restrictions
        restrictions = data.get("restrictions", {})
        self.allow_schemas = restrictions.get("allow_schemas")
        self.allow_tables = restrictions.get("allow_tables")

        # Parse MongoDB restrictions
        mongodb = data.get("mongodb", {})
        if mongodb:
            self.mongodb_allow_collections = mongodb.get("allow_collections")
            self.mongodb_allow_operations = [op.lower() for op in mongodb.get("allow_operations", [])] if mongodb.get("allow_operations") else None

        # Parse Redis restrictions
        redis_config = data.get("redis", {})
        if redis_config:
            self.redis_allow_commands = [cmd.lower() for cmd in redis_config.get("allow_commands", [])] if redis_config.get("allow_commands") else None
            self.redis_allow_key_patterns = redis_config.get("allow_key_patterns")

        # Parse redaction rules
        redaction_rules = data.get("redaction", [])
        for rule in redaction_rules:
            name = rule.get("name", "unknown")
            pattern = rule.get("pattern")
            if pattern:
                try:
                    self.redaction_patterns.append((name, re.compile(pattern)))
                except re.error as e:
                    logger.warning(f"Invalid redaction pattern '{pattern}': {e}")

        # Parse rules
        rules = data.get("rules", [])
        for rule_data in rules:
            name = rule_data.get("name", "unnamed")
            tool = rule_data.get("tool")
            decision_str = rule_data.get("decision", "deny")
            decision = Decision.ALLOW if decision_str == "allow" else Decision.DENY
            conditions = rule_data.get("conditions", {})

            if tool:
                # Normalize tool name to canonical form
                canonical_tool = self._normalize_tool_name(tool)
                self.rules.append(PolicyRule(
                    name=name,
                    tool=canonical_tool,
                    decision=decision,
                    conditions=conditions
                ))

    def evaluate_tool(self, tool_name: str, args: Dict[str, Any]) -> PolicyDecision:
        """Evaluate policy for a tool invocation."""
        # Normalize tool name to canonical form (e.g. postgres_query -> postgres.query)
        canonical_name = self._normalize_tool_name(tool_name)

        # SQL query tools get special SQL-aware evaluation
        if canonical_name in self._SQL_QUERY_TOOLS:
            return self._evaluate_query(args.get("sql", ""), args, canonical_name)

        # MongoDB tools
        if canonical_name.startswith("mongodb."):
            return self._evaluate_mongodb(canonical_name, args)

        # Redis tools
        if canonical_name.startswith("redis."):
            return self._evaluate_redis(canonical_name, args)

        # Check rules in order (first match wins)
        for rule in self.rules:
            if rule.tool == canonical_name or rule.tool == "*":
                # Check conditions
                if self._check_conditions(rule.conditions, args):
                    return PolicyDecision(
                        decision=rule.decision,
                        reason=f"Matched rule: {rule.name}",
                        matched_rule=rule.name
                    )

        # Default deny
        return PolicyDecision(
            decision=self.default_decision,
            reason="No matching rule found (default deny)"
        )

    def _evaluate_query(self, sql: str, args: Dict[str, Any], canonical_name: str = "postgres.query") -> PolicyDecision:
        """Evaluate a SQL query against policy. Works for PostgreSQL, MySQL, and SQLite."""

        if not sql or not sql.strip():
            return PolicyDecision(
                decision=Decision.DENY,
                reason="Empty SQL query"
            )

        sql_upper = sql.upper()

        # Check deny_regex patterns (from tools-based policy format)
        for pattern in self.deny_regex_patterns:
            if pattern.search(sql):
                return PolicyDecision(
                    decision=Decision.DENY,
                    reason=f"Blocked by deny_regex: {pattern.pattern}"
                )

        # Parse SQL to extract statement type and tables
        try:
            parsed = sqlparse.parse(sql)
            if not parsed:
                return PolicyDecision(
                    decision=Decision.DENY,
                    reason="Could not parse SQL statement"
                )

            stmt = parsed[0]
            stmt_type = stmt.get_type()

            # Resolve WITH ... SELECT as SELECT
            if stmt_type == "UNKNOWN" and sql_upper.strip().startswith("WITH") and "SELECT" in sql_upper:
                stmt_type = "SELECT"

            # Check statement type against allow_statements
            if stmt_type and stmt_type not in self.allow_statements:
                return PolicyDecision(
                    decision=Decision.DENY,
                    reason=f"Statement type not allowed: {stmt_type} (allowed: {', '.join(self.allow_statements)})"
                )

            # Extract tables
            tables = self._extract_tables(stmt)

            # Check schema restrictions
            if self.allow_schemas or self.allow_tables:
                if not tables:
                    # Could not determine tables - fail closed
                    return PolicyDecision(
                        decision=Decision.DENY,
                        reason="Could not determine tables from query (ambiguous)"
                    )

                for table in tables:
                    schema, table_name = self._parse_table_ref(table)

                    # Check schema allowlist
                    if self.allow_schemas and schema:
                        if schema not in self.allow_schemas:
                            return PolicyDecision(
                                decision=Decision.DENY,
                                reason=f"Schema not allowed: {schema}"
                            )

                    # Check table allowlist
                    if self.allow_tables:
                        full_name = f"{schema}.{table_name}" if schema else table_name
                        if full_name not in self.allow_tables and table_name not in self.allow_tables:
                            return PolicyDecision(
                                decision=Decision.DENY,
                                reason=f"Table not allowed: {full_name}"
                            )

        except Exception as e:
            # Parse error - fail closed
            return PolicyDecision(
                decision=Decision.DENY,
                reason=f"SQL parse error: {str(e)}"
            )

        # Check against rules
        for rule in self.rules:
            if rule.tool in (canonical_name, "*"):
                if self._check_conditions(rule.conditions, args):
                    return PolicyDecision(
                        decision=rule.decision,
                        reason=f"Matched rule: {rule.name}",
                        matched_rule=rule.name
                    )

        # Default deny
        return PolicyDecision(
            decision=self.default_decision,
            reason="No matching rule found (default deny)"
        )

    def _evaluate_mongodb(self, canonical_name: str, args: Dict[str, Any]) -> PolicyDecision:
        """Evaluate a MongoDB tool call against policy."""
        # Map tool name to operation
        op_map = {
            "mongodb.query": "find",
            "mongodb.aggregate": "aggregate",
            "mongodb.describe": "describe",
            "mongodb.insert": "insert",
            "mongodb.update": "update",
            "mongodb.delete": "delete",
            "mongodb.dump": "dump",
            "mongodb.diagram": "diagram",
        }
        operation = op_map.get(canonical_name, "unknown")

        # Check operation allowlist (describe, dump, diagram are inspection tools - always allowed)
        if self.mongodb_allow_operations is not None:
            if operation not in self.mongodb_allow_operations and operation not in ("describe", "dump", "diagram"):
                return PolicyDecision(
                    decision=Decision.DENY,
                    reason=f"MongoDB operation not allowed: {operation} (allowed: {', '.join(self.mongodb_allow_operations)})"
                )

        # Check collection allowlist
        collection = args.get("collection")
        if collection and self.mongodb_allow_collections is not None:
            if collection not in self.mongodb_allow_collections:
                return PolicyDecision(
                    decision=Decision.DENY,
                    reason=f"Collection not allowed: {collection}"
                )

        # Check rules
        for rule in self.rules:
            if rule.tool in (canonical_name, "*"):
                if self._check_conditions(rule.conditions, args):
                    return PolicyDecision(
                        decision=rule.decision,
                        reason=f"Matched rule: {rule.name}",
                        matched_rule=rule.name
                    )

        return PolicyDecision(
            decision=self.default_decision,
            reason="No matching rule found (default deny)"
        )

    def _evaluate_redis(self, canonical_name: str, args: Dict[str, Any]) -> PolicyDecision:
        """Evaluate a Redis tool call against policy."""
        # Map tool name to command
        cmd_map = {
            "redis.get": "get",
            "redis.set": "set",
            "redis.delete": "delete",
            "redis.keys": "keys",
            "redis.info": "info",
            "redis.describe": "describe",
            "redis.backup": "backup",
        }
        command = cmd_map.get(canonical_name, "unknown")

        # Check command allowlist (describe, backup are inspection tools - exempt from strict checking)
        if self.redis_allow_commands is not None:
            if command not in self.redis_allow_commands and command not in ("describe", "backup"):
                return PolicyDecision(
                    decision=Decision.DENY,
                    reason=f"Redis command not allowed: {command} (allowed: {', '.join(self.redis_allow_commands)})"
                )

        # Check key pattern restrictions
        if self.redis_allow_key_patterns is not None:
            # Extract the key(s) from arguments
            key = args.get("key")
            keys = args.get("keys", [])
            pattern = args.get("pattern")

            keys_to_check = []
            if key:
                keys_to_check.append(key)
            if keys:
                keys_to_check.extend(keys)
            # For KEYS/SCAN pattern, check if the pattern itself is allowed
            if pattern and pattern != "*":
                keys_to_check.append(pattern)

            for k in keys_to_check:
                if not any(fnmatch.fnmatch(k, p) for p in self.redis_allow_key_patterns):
                    return PolicyDecision(
                        decision=Decision.DENY,
                        reason=f"Key not allowed by pattern: {k}"
                    )

        # Check rules
        for rule in self.rules:
            if rule.tool in (canonical_name, "*"):
                if self._check_conditions(rule.conditions, args):
                    return PolicyDecision(
                        decision=rule.decision,
                        reason=f"Matched rule: {rule.name}",
                        matched_rule=rule.name
                    )

        return PolicyDecision(
            decision=self.default_decision,
            reason="No matching rule found (default deny)"
        )

    # Plain keywords (Token.Keyword) that introduce table references
    _TABLE_KEYWORDS = frozenset({
        "FROM", "INTO", "TABLE", "JOIN", "INNER JOIN", "LEFT JOIN", "RIGHT JOIN",
        "FULL JOIN", "CROSS JOIN", "LEFT OUTER JOIN", "RIGHT OUTER JOIN",
        "FULL OUTER JOIN", "NATURAL JOIN",
    })

    # DML/DDL keywords where the table name follows immediately
    _DML_TABLE_KEYWORDS = frozenset({"UPDATE", "TRUNCATE"})

    def _extract_tables(self, stmt) -> List[str]:
        """Extract table names from parsed SQL statement.

        Considers identifiers that follow FROM/JOIN/INTO/TABLE keywords
        and DML/DDL statements like UPDATE/TRUNCATE where the table
        follows the keyword directly.
        """
        tables = []
        from_seen = False

        for token in stmt.tokens:
            # Detect FROM / JOIN / INTO / TABLE keywords
            if token.ttype is sqlparse.tokens.Keyword and token.normalized in self._TABLE_KEYWORDS:
                from_seen = True
                continue

            # Detect UPDATE / TRUNCATE (DML/DDL tokens that precede a table name)
            if token.ttype in (sqlparse.tokens.Keyword.DML, sqlparse.tokens.Keyword.DDL) \
                    and token.normalized in self._DML_TABLE_KEYWORDS:
                from_seen = True
                continue

            if from_seen:
                if isinstance(token, (sqlparse.sql.Identifier, sqlparse.sql.Function)):
                    name = token.get_real_name()
                    if name:
                        tables.append(name)
                    from_seen = False
                elif isinstance(token, sqlparse.sql.IdentifierList):
                    for ident in token.get_identifiers():
                        if isinstance(ident, sqlparse.sql.Identifier):
                            name = ident.get_real_name()
                            if name:
                                tables.append(name)
                    from_seen = False
                elif token.ttype is not sqlparse.tokens.Whitespace:
                    from_seen = False

            # Recurse into parenthesized subqueries
            if isinstance(token, sqlparse.sql.Parenthesis):
                inner = sqlparse.parse(token.value.strip("()"))[0] if token.value else None
                if inner:
                    tables.extend(self._extract_tables(inner))

        return tables

    def _parse_table_ref(self, table_ref: str) -> tuple[Optional[str], str]:
        """Parse schema.table reference."""
        parts = table_ref.split(".")
        if len(parts) == 2:
            return parts[0].strip('"'), parts[1].strip('"')
        return None, parts[0].strip('"')

    def _check_conditions(self, conditions: Dict[str, Any], args: Dict[str, Any]) -> bool:
        """Check if conditions match arguments."""
        if not conditions:
            return True

        # Simple condition matching
        for key, value in conditions.items():
            if key not in args:
                return False
            if args[key] != value:
                return False

        return True

    def apply_redactions(self, data: Any) -> Any:
        """Apply redaction rules to query results."""
        if not self.redaction_patterns:
            return data

        if isinstance(data, str):
            for replace_text, pattern in self.redaction_patterns:
                data = pattern.sub(replace_text, data)
            return data
        elif isinstance(data, dict):
            return {k: self.apply_redactions(v) for k, v in data.items()}
        elif isinstance(data, list):
            return [self.apply_redactions(item) for item in data]
        else:
            return data
