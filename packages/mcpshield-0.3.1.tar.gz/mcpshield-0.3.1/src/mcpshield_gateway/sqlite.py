"""SQLite tools for MCPShield Gateway."""

import sqlite3
import logging
from typing import Dict, Any, List, Optional
from datetime import datetime
from decimal import Decimal

logger = logging.getLogger(__name__)


class SQLiteTools:
    """SQLite tools with policy enforcement."""

    def __init__(self, dsn: str, timeout_seconds: int = 5, max_rows: int = 100):
        """Initialize SQLite tools.

        Args:
            dsn: Path to SQLite database file (or :memory:).
            timeout_seconds: Query timeout in seconds.
            max_rows: Maximum rows to return per query.
        """
        # Strip sqlite:/// prefix if present
        self.db_path = dsn.replace("sqlite:///", "").replace("sqlite://", "")
        self.timeout_seconds = timeout_seconds
        self.max_rows = max_rows
        self._conn: Optional[sqlite3.Connection] = None

    def connect(self):
        """Establish database connection."""
        if self._conn is None:
            self._conn = sqlite3.connect(
                self.db_path,
                timeout=self.timeout_seconds,
            )
            self._conn.row_factory = None  # Use tuple rows for consistency
            logger.info(f"SQLite connection established: {self.db_path}")

    def close(self):
        """Close database connection."""
        if self._conn is not None:
            self._conn.close()
            self._conn = None
            logger.info("SQLite connection closed")

    @staticmethod
    def _serialize_value(value: Any) -> Any:
        """Convert non-JSON-serializable types."""
        if isinstance(value, datetime):
            return value.isoformat()
        if isinstance(value, (bytes, bytearray)):
            return value.hex()
        if isinstance(value, Decimal):
            return float(value)
        return value

    def query(self, sql: str, params: Optional[List] = None) -> Dict[str, Any]:
        """Execute a SQL query and return results."""
        start_time = datetime.utcnow()

        try:
            self.connect()

            cursor = self._conn.cursor()
            try:
                if params:
                    cursor.execute(sql, params)
                else:
                    cursor.execute(sql)

                if cursor.description:
                    rows = cursor.fetchmany(self.max_rows + 1)
                    columns = [desc[0] for desc in cursor.description]

                    hit_limit = len(rows) > self.max_rows
                    if hit_limit:
                        rows = rows[:self.max_rows]

                    results = []
                    for row in rows:
                        row_dict = {}
                        for col_name, value in zip(columns, row):
                            row_dict[col_name] = self._serialize_value(value)
                        results.append(row_dict)

                    latency_ms = (datetime.utcnow() - start_time).total_seconds() * 1000
                    return {
                        "columns": columns,
                        "rows": results,
                        "row_count": len(results),
                        "hit_limit": hit_limit,
                        "latency_ms": latency_ms,
                    }
                else:
                    affected = cursor.rowcount if cursor.rowcount >= 0 else 0
                    self._conn.commit()
                    latency_ms = (datetime.utcnow() - start_time).total_seconds() * 1000
                    return {
                        "affected_rows": affected,
                        "latency_ms": latency_ms,
                    }
            finally:
                cursor.close()

        except sqlite3.Error as e:
            logger.error(f"SQLite error: {e}")
            raise Exception(f"SQLite error: {str(e)}") from e

    def describe(self) -> Dict[str, Any]:
        """Describe database schema (tables and columns)."""
        start_time = datetime.utcnow()

        try:
            self.connect()

            cursor = self._conn.cursor()
            try:
                # Get all tables
                cursor.execute(
                    "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name"
                )
                table_names = [row[0] for row in cursor.fetchall()]

                tables: Dict[str, List[Dict]] = {}
                for table_name in table_names:
                    cursor.execute(f"PRAGMA table_info(\"{table_name}\")")
                    columns = []
                    for row in cursor.fetchall():
                        # row: (cid, name, type, notnull, dflt_value, pk)
                        columns.append({
                            "name": row[1],
                            "type": row[2],
                            "nullable": row[3] == 0,
                            "primary_key": row[5] > 0,
                        })
                    tables[table_name] = columns
            finally:
                cursor.close()

            latency_ms = (datetime.utcnow() - start_time).total_seconds() * 1000
            return {"tables": tables, "latency_ms": latency_ms}

        except sqlite3.Error as e:
            logger.error(f"SQLite describe error: {e}")
            raise Exception(f"SQLite error: {str(e)}") from e

    def dump(
        self,
        include_data: bool = False,
        tables: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """Generate a SQL dump."""
        start_time = datetime.utcnow()

        try:
            self.connect()
            lines: List[str] = []
            lines.append("-- MCPShield SQL Dump (SQLite)")
            lines.append(f"-- Generated: {datetime.utcnow().isoformat()}")
            lines.append("")

            cursor = self._conn.cursor()
            try:
                cursor.execute(
                    "SELECT name, sql FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name"
                )
                all_tables = cursor.fetchall()
                if tables:
                    all_tables = [(name, ddl) for name, ddl in all_tables if name in tables]

                table_count = len(all_tables)

                for table_name, create_sql in all_tables:
                    if create_sql:
                        lines.append(f"{create_sql};")
                        lines.append("")

                    # Indexes
                    cursor.execute(
                        "SELECT sql FROM sqlite_master WHERE type='index' AND tbl_name=? AND sql IS NOT NULL",
                        (table_name,),
                    )
                    for (idx_sql,) in cursor.fetchall():
                        lines.append(f"{idx_sql};")
                    lines.append("")

                    if include_data:
                        cursor.execute(f'SELECT * FROM "{table_name}"')
                        col_names = [desc[0] for desc in cursor.description]
                        data_rows = cursor.fetchall()
                        for data_row in data_rows:
                            values = []
                            for v in data_row:
                                if v is None:
                                    values.append("NULL")
                                elif isinstance(v, str):
                                    values.append("'" + v.replace("'", "''") + "'")
                                elif isinstance(v, bool):
                                    values.append("1" if v else "0")
                                else:
                                    values.append(str(v))
                            col_list = ", ".join(f'"{c}"' for c in col_names)
                            lines.append(f'INSERT INTO "{table_name}" ({col_list}) VALUES ({", ".join(values)});')
                        lines.append("")
            finally:
                cursor.close()

            latency_ms = (datetime.utcnow() - start_time).total_seconds() * 1000
            return {"sql": "\n".join(lines), "table_count": table_count, "latency_ms": latency_ms}

        except sqlite3.Error as e:
            logger.error(f"SQLite dump error: {e}")
            raise Exception(f"SQLite error: {str(e)}") from e

    def diagram(self, format: str = "mermaid") -> Dict[str, Any]:
        """Generate an ER diagram in Mermaid format."""
        start_time = datetime.utcnow()

        try:
            self.connect()

            cursor = self._conn.cursor()
            try:
                cursor.execute(
                    "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name"
                )
                table_names = [row[0] for row in cursor.fetchall()]
                table_count = len(table_names)

                lines = ["erDiagram"]

                # Collect FK info for relationships
                fk_relations = []

                for table_name in table_names:
                    # Columns
                    cursor.execute(f"PRAGMA table_info(\"{table_name}\")")
                    cols = cursor.fetchall()

                    lines.append(f"    {table_name} {{")
                    for row in cols:
                        col_name = row[1]
                        col_type = row[2].replace(" ", "_") if row[2] else "TEXT"
                        is_pk = row[5] > 0
                        comment = " PK" if is_pk else ""
                        lines.append(f"        {col_type} {col_name}{comment}")
                    lines.append("    }")

                    # Foreign keys
                    cursor.execute(f"PRAGMA foreign_key_list(\"{table_name}\")")
                    for fk_row in cursor.fetchall():
                        ref_table = fk_row[2]
                        from_col = fk_row[3]
                        fk_relations.append((table_name, ref_table, from_col))

                for tbl_name, ref_table, col_name in fk_relations:
                    lines.append(f'    {tbl_name} }}o--|| {ref_table} : "{col_name}"')
            finally:
                cursor.close()

            diagram_text = "\n".join(lines)
            latency_ms = (datetime.utcnow() - start_time).total_seconds() * 1000
            return {"diagram": diagram_text, "format": format, "table_count": table_count, "latency_ms": latency_ms}

        except sqlite3.Error as e:
            logger.error(f"SQLite diagram error: {e}")
            raise Exception(f"SQLite error: {str(e)}") from e
