"""MCPShield Gateway - Secure access for AI agents."""

__version__ = "0.3.3"
__author__ = "MCPShield"
