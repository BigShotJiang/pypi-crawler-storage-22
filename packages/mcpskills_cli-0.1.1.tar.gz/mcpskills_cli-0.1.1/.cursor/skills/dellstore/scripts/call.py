#!/usr/bin/env python3
"""Call MCP tool on server 'dellstore'."""
import configparser
import json
import os
import sys
import urllib.request

SERVER = "dellstore"
CREDS_FILE = os.path.expanduser("~/.mcps/credentials")


def load_credentials():
    cfg = configparser.ConfigParser()
    cfg.read(CREDS_FILE)
    if SERVER not in cfg:
        print(f"No section [{SERVER}] in {CREDS_FILE}", file=sys.stderr)
        sys.exit(1)
    return cfg[SERVER]["url"], cfg[SERVER]["token"]


def call_tool(tool_name: str, arguments: dict) -> dict:
    url, token = load_credentials()
    url = url.rstrip("/") + "/"
    body = json.dumps({
        "jsonrpc": "2.0",
        "method": "tools/call",
        "params": {"name": tool_name, "arguments": arguments},
        "id": 1,
    }).encode()
    req = urllib.request.Request(
        url, data=body, method="POST",
        headers={
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
            "Accept": "application/json, text/event-stream",
            "MCP-Protocol-Version": "2025-06-18",
        },
    )
    with urllib.request.urlopen(req, timeout=30) as resp:
        text = resp.read().decode()
    for line in text.strip().split("\n"):
        if line.startswith("data:"):
            line = line[5:].strip()
        if not line or line == "[DONE]":
            continue
        try:
            obj = json.loads(line)
            if "result" in obj or "error" in obj:
                return obj
        except json.JSONDecodeError:
            pass
    return json.loads(text)


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(f"Usage: {sys.argv[0]} <tool_name> [json_args]", file=sys.stderr)
        sys.exit(1)
    tool = sys.argv[1]
    args = json.loads(sys.argv[2]) if len(sys.argv) > 2 else {}
    result = call_tool(tool, args)
    print(json.dumps(result, indent=2))
