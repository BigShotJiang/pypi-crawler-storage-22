from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    model_config = {"env_file": ".env", "env_file_encoding": "utf-8"}

    scihub_mirrors: str = "sci-hub.se,sci-hub.st,sci-hub.ru"
    crossref_mailto: str = "ryan@supported.systems"
    openalex_mailto: str = "ryan@supported.systems"
    s2_api_key: str = ""
    cache_max_size: int = 1000
    cache_ttl: int = 3600
    http_timeout: int = 30
    pdf_save_dir: str = "/tmp/mcsci-hub-pdfs"
    max_pdf_size: int = 100 * 1024 * 1024  # 100 MB

    @property
    def mirror_list(self) -> list[str]:
        return [m.strip() for m in self.scihub_mirrors.split(",") if m.strip()]


settings = Settings()
