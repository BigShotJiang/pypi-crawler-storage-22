from pydantic import BaseModel, Field


class PaperResult(BaseModel):
    """Compact paper result for search listings."""

    doi: str = ""
    title: str = ""
    authors: list[str] = Field(default_factory=list)
    year: int | None = None
    journal: str = ""
    citation_count: int | None = None
    open_access: bool = False
    source: str = ""


class PaperMetadata(BaseModel):
    """Full paper details aggregated from multiple sources."""

    doi: str = ""
    title: str = ""
    authors: list[str] = Field(default_factory=list)
    year: int | None = None
    journal: str = ""
    volume: str = ""
    issue: str = ""
    pages: str = ""
    abstract: str = ""
    citation_count: int | None = None
    influential_citation_count: int | None = None
    open_access: bool = False
    open_access_url: str = ""
    fields_of_study: list[str] = Field(default_factory=list)
    pdf_available_on_scihub: bool = False
    sources: list[str] = Field(default_factory=list)


class CitationEntry(BaseModel):
    """A single citation (forward or backward)."""

    doi: str = ""
    title: str = ""
    authors: list[str] = Field(default_factory=list)
    year: int | None = None
    journal: str = ""
    citation_count: int | None = None
    is_influential: bool | None = None


class PDFResult(BaseModel):
    """Result of a PDF fetch operation."""

    status: str = "success"
    file_path: str = ""
    source: str = ""
    doi: str = ""
    hint: str = "Use mcp-pdf tools (extract_text, extract_tables, etc.) to parse this PDF"


class BibTeXResult(BaseModel):
    """BibTeX entry result."""

    doi: str = ""
    bibtex: str = ""
    source: str = ""
