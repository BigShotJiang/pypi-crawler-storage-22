from fastmcp import FastMCP

from mcsci_hub.tools.bibtex import register as register_bibtex
from mcsci_hub.tools.citations import register as register_citations
from mcsci_hub.tools.paper import register as register_paper
from mcsci_hub.tools.pdf import register as register_pdf
from mcsci_hub.tools.search import register as register_search


def register_all(mcp: FastMCP) -> None:
    register_search(mcp)
    register_paper(mcp)
    register_pdf(mcp)
    register_citations(mcp)
    register_bibtex(mcp)
