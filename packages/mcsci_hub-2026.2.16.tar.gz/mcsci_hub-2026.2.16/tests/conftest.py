import httpx
import pytest

from mcsci_hub.cache import TTLCache
from mcsci_hub.clients.crossref import CrossRefClient
from mcsci_hub.clients.openalex import OpenAlexClient
from mcsci_hub.clients.scihub import SciHubClient
from mcsci_hub.clients.semantic_scholar import SemanticScholarClient


@pytest.fixture
async def http_client():
    async with httpx.AsyncClient() as client:
        yield client


@pytest.fixture
def crossref_client(http_client):
    return CrossRefClient(http_client, mailto="test@example.com")


@pytest.fixture
def openalex_client(http_client):
    return OpenAlexClient(http_client, mailto="test@example.com")


@pytest.fixture
def s2_client(http_client):
    return SemanticScholarClient(http_client)


@pytest.fixture
def scihub_client(http_client):
    return SciHubClient(http_client, mirrors=["sci-hub.test"])


@pytest.fixture
def cache():
    return TTLCache(max_size=100, ttl=60)


# Sample API responses for mocking

SAMPLE_CROSSREF_WORK = {
    "DOI": "10.1038/nature12373",
    "title": ["Attention Is All You Need"],
    "author": [
        {"given": "Ashish", "family": "Vaswani"},
        {"given": "Noam", "family": "Shazeer"},
    ],
    "published": {"date-parts": [[2017]]},
    "container-title": ["Nature"],
    "is-referenced-by-count": 50000,
    "volume": "600",
    "issue": "1",
    "page": "1-10",
}

SAMPLE_CROSSREF_SEARCH = {
    "message": {
        "items": [SAMPLE_CROSSREF_WORK],
    }
}

SAMPLE_OPENALEX_WORK = {
    "doi": "https://doi.org/10.1038/nature12373",
    "title": "Attention Is All You Need",
    "authorships": [
        {"author": {"display_name": "Ashish Vaswani"}},
        {"author": {"display_name": "Noam Shazeer"}},
    ],
    "publication_year": 2017,
    "primary_location": {
        "source": {"display_name": "Nature"},
    },
    "cited_by_count": 51000,
    "open_access": {"is_oa": True, "oa_url": "https://arxiv.org/pdf/1706.03762"},
    "abstract_inverted_index": {
        "The": [0],
        "dominant": [1],
        "sequence": [2],
        "transduction": [3],
        "models": [4],
    },
}

SAMPLE_OPENALEX_SEARCH = {
    "results": [SAMPLE_OPENALEX_WORK],
}

SAMPLE_S2_PAPER = {
    "title": "Attention Is All You Need",
    "authors": [{"name": "Ashish Vaswani"}, {"name": "Noam Shazeer"}],
    "year": 2017,
    "venue": "NeurIPS",
    "abstract": "The dominant sequence transduction models...",
    "citationCount": 52000,
    "influentialCitationCount": 5000,
    "isOpenAccess": True,
    "openAccessPdf": {"url": "https://arxiv.org/pdf/1706.03762"},
    "fieldsOfStudy": ["Computer Science"],
    "citationStyles": {"bibtex": "@article{vaswani2017attention,...}"},
    "externalIds": {"DOI": "10.1038/nature12373"},
    "publicationTypes": ["JournalArticle"],
    "journal": {"name": "Nature"},
    "volume": "600",
}

SAMPLE_S2_CITATIONS = {
    "data": [
        {
            "citingPaper": {
                "title": "BERT: Pre-training of Deep Bidirectional Transformers",
                "authors": [{"name": "Jacob Devlin"}],
                "year": 2019,
                "venue": "NAACL",
                "citationCount": 40000,
                "externalIds": {"DOI": "10.18653/v1/N19-1423"},
            },
            "isInfluential": True,
        }
    ]
}

SAMPLE_S2_REFERENCES = {
    "data": [
        {
            "citedPaper": {
                "title": "Neural Machine Translation by Jointly Learning to Align and Translate",
                "authors": [{"name": "Dzmitry Bahdanau"}],
                "year": 2015,
                "venue": "ICLR",
                "citationCount": 20000,
                "externalIds": {"DOI": "10.48550/arXiv.1409.0473"},
            },
            "isInfluential": True,
        }
    ]
}

SAMPLE_SCIHUB_HTML = """
<html><body>
<iframe id="pdf" src="//sci-hub.test/downloads/2017/nature12373.pdf"></iframe>
</body></html>
"""
