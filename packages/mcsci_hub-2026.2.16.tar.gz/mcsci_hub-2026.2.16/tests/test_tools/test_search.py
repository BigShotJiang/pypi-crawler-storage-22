import json
from contextlib import asynccontextmanager

import httpx
import respx
from fastmcp import Client, FastMCP

from mcsci_hub.cache import TTLCache
from mcsci_hub.clients.crossref import CrossRefClient
from mcsci_hub.clients.openalex import OpenAlexClient
from mcsci_hub.clients.scihub import SciHubClient
from mcsci_hub.clients.semantic_scholar import SemanticScholarClient
from mcsci_hub.tools import register_all
from tests.conftest import SAMPLE_CROSSREF_SEARCH, SAMPLE_OPENALEX_SEARCH


def _make_server() -> FastMCP:
    @asynccontextmanager
    async def test_lifespan(server: FastMCP):
        async with httpx.AsyncClient() as http_client:
            yield {
                "crossref": CrossRefClient(http_client, mailto="test@test.com"),
                "openalex": OpenAlexClient(http_client, mailto="test@test.com"),
                "s2": SemanticScholarClient(http_client),
                "scihub": SciHubClient(http_client, mirrors=["sci-hub.test"]),
                "cache": TTLCache(max_size=100, ttl=60),
            }

    app = FastMCP("test-mcsci-hub", lifespan=test_lifespan)
    register_all(app)
    return app


@respx.mock
async def test_search_papers_openalex():
    respx.get("https://api.openalex.org/works").mock(
        return_value=httpx.Response(200, json=SAMPLE_OPENALEX_SEARCH)
    )

    async with Client(_make_server()) as client:
        result = await client.call_tool("search_papers", {"query": "attention"})
        data = json.loads(result.content[0].text)
        assert data["count"] == 1
        assert data["results"][0]["doi"] == "10.1038/nature12373"
        assert data["results"][0]["source"] == "openalex"


@respx.mock
async def test_search_papers_crossref_fallback():
    respx.get("https://api.openalex.org/works").mock(
        return_value=httpx.Response(200, json={"results": []})
    )
    respx.get("https://api.crossref.org/works").mock(
        return_value=httpx.Response(200, json=SAMPLE_CROSSREF_SEARCH)
    )

    async with Client(_make_server()) as client:
        result = await client.call_tool("search_papers", {"query": "attention"})
        data = json.loads(result.content[0].text)
        assert data["count"] == 1
        assert data["results"][0]["source"] == "crossref"


@respx.mock
async def test_search_papers_no_results():
    respx.get("https://api.openalex.org/works").mock(
        return_value=httpx.Response(200, json={"results": []})
    )
    respx.get("https://api.crossref.org/works").mock(
        return_value=httpx.Response(200, json={"message": {"items": []}})
    )

    async with Client(_make_server()) as client:
        result = await client.call_tool("search_papers", {"query": "zzzznothing"})
        data = json.loads(result.content[0].text)
        assert data["results"] == []
