"""File transfer tools: X/Y/ZMODEM send, receive, and batch."""

from __future__ import annotations

from typing import Literal

import serial

from mcserial._helpers import _validate_file_path
from mcserial._state import (
    _connections,
    mcp,
)


@mcp.tool()
def file_transfer_send(
    port: str,
    file_path: str,
    protocol: Literal["xmodem", "xmodem1k", "ymodem", "zmodem"] = "zmodem",
) -> dict:
    """Send a file over serial using X/Y/ZMODEM protocol.

    Works in both RS-232 and RS-485 modes.

    Protocols:
        - xmodem: 128-byte blocks, simple but compatible (1977)
        - xmodem1k: 1024-byte blocks, faster than basic XMODEM
        - ymodem: Batch mode, sends filename/size (1985)
        - zmodem: Streaming, auto-resume, most efficient (1986) [recommended]

    The receiver must be waiting in receive mode before calling this.
    For ZMODEM, the receiver typically auto-starts when it sees the init sequence.

    Args:
        port: Device path of the open serial port
        file_path: Path to the file to send
        protocol: Transfer protocol to use (default: zmodem)

    Returns:
        Transfer statistics including bytes sent and any errors
    """
    from pathlib import Path

    if port not in _connections:
        return {"error": f"Port {port} is not open", "success": False}

    # Validate file path before reading
    if path_error := _validate_file_path(file_path, "read"):
        return path_error

    filepath = Path(file_path)
    if not filepath.exists():
        return {"error": f"File not found: {file_path}", "success": False}

    conn = _connections[port].connection

    # Create read/write functions for the protocol handlers
    def read_func(n: int) -> bytes:
        return conn.read(n)

    def write_func(data: bytes) -> int:
        return conn.write(data)

    try:
        if protocol in ("xmodem", "xmodem1k"):
            from mcserial.xmodem import XModem

            xm = XModem(read_func, write_func, mode=protocol)
            with open(filepath, "rb") as f:
                result = xm.send(f)
            result["protocol"] = protocol
            result["file"] = str(filepath)
            return result

        elif protocol == "ymodem":
            from mcserial.ymodem import YModem

            ym = YModem(read_func, write_func)
            result = ym.send([filepath])
            result["protocol"] = "ymodem"
            return result

        elif protocol == "zmodem":
            from mcserial.zmodem import ZModem

            zm = ZModem(read_func, write_func)
            result = zm.send([filepath])
            result["protocol"] = "zmodem"
            return result

        else:
            return {"error": f"Unknown protocol: {protocol}", "success": False}

    except serial.SerialException as e:
        return {"error": f"Serial error: {e}", "success": False, "protocol": protocol}
    except OSError as e:
        return {"error": f"File error: {e}", "success": False, "protocol": protocol}
    except (ValueError, OverflowError) as e:
        return {"error": f"Protocol error: {e}", "success": False, "protocol": protocol}


@mcp.tool()
def file_transfer_receive(
    port: str,
    save_path: str,
    protocol: Literal["xmodem", "ymodem", "zmodem"] = "zmodem",
    overwrite: bool = False,
    resume: bool = True,
) -> dict:
    """Receive a file over serial using X/Y/ZMODEM protocol.

    Works in both RS-232 and RS-485 modes.

    Protocols:
        - xmodem: Must specify exact filename, no metadata from sender
        - ymodem: Receives filename from sender, batch capable
        - zmodem: Streaming, auto-resume capable [recommended]

    For XMODEM, save_path is the full file path.
    For YMODEM/ZMODEM, save_path is a directory where files will be saved.

    Args:
        port: Device path of the open serial port
        save_path: File path (xmodem) or directory (ymodem/zmodem)
        protocol: Transfer protocol to use (default: zmodem)
        overwrite: Whether to overwrite existing files
        resume: Resume interrupted ZMODEM transfers from where they left off.
                When True and a partial file exists, the sender is told to
                start from the existing file size. Only applies to ZMODEM.
                (default: True)

    Returns:
        Transfer statistics including bytes received and file paths
    """
    from pathlib import Path

    if port not in _connections:
        return {"error": f"Port {port} is not open", "success": False}

    # Validate save path before writing
    if path_error := _validate_file_path(save_path, "write"):
        return path_error

    conn = _connections[port].connection

    def read_func(n: int) -> bytes:
        return conn.read(n)

    def write_func(data: bytes) -> int:
        return conn.write(data)

    try:
        if protocol == "xmodem":
            from mcserial.xmodem import XModem

            filepath = Path(save_path)
            if filepath.exists() and not overwrite:
                return {"error": f"File exists: {save_path}", "success": False}

            filepath.parent.mkdir(parents=True, exist_ok=True)

            xm = XModem(read_func, write_func)
            with open(filepath, "wb") as f:
                result = xm.receive(f)
            result["protocol"] = "xmodem"
            result["file"] = str(filepath)
            return result

        elif protocol == "ymodem":
            from mcserial.ymodem import YModem

            directory = Path(save_path)
            directory.mkdir(parents=True, exist_ok=True)

            ym = YModem(read_func, write_func)
            result = ym.receive(directory, overwrite=overwrite)
            result["protocol"] = "ymodem"
            return result

        elif protocol == "zmodem":
            from mcserial.zmodem import ZModem

            directory = Path(save_path)
            directory.mkdir(parents=True, exist_ok=True)

            zm = ZModem(read_func, write_func)
            result = zm.receive(directory, overwrite=overwrite, resume=resume)
            result["protocol"] = "zmodem"
            return result

        else:
            return {"error": f"Unknown protocol: {protocol}", "success": False}

    except serial.SerialException as e:
        return {"error": f"Serial error: {e}", "success": False, "protocol": protocol}
    except OSError as e:
        return {"error": f"File error: {e}", "success": False, "protocol": protocol}
    except (ValueError, OverflowError) as e:
        return {"error": f"Protocol error: {e}", "success": False, "protocol": protocol}


@mcp.tool()
def file_transfer_send_batch(
    port: str,
    file_paths: list[str],
    protocol: Literal["ymodem", "zmodem"] = "zmodem",
) -> dict:
    """Send multiple files in a batch transfer.

    Only YMODEM and ZMODEM support batch transfers.

    Args:
        port: Device path of the open serial port
        file_paths: List of file paths to send
        protocol: Transfer protocol (ymodem or zmodem)

    Returns:
        Transfer statistics for all files
    """
    from pathlib import Path

    if port not in _connections:
        return {"error": f"Port {port} is not open", "success": False}

    if protocol not in ("ymodem", "zmodem"):
        return {"error": "Batch transfer requires ymodem or zmodem", "success": False}

    # Validate all file paths and existence
    paths = []
    for fp in file_paths:
        if path_error := _validate_file_path(fp, "read"):
            return path_error
        p = Path(fp)
        if not p.exists():
            return {"error": f"File not found: {fp}", "success": False}
        paths.append(p)

    conn = _connections[port].connection

    def read_func(n: int) -> bytes:
        return conn.read(n)

    def write_func(data: bytes) -> int:
        return conn.write(data)

    try:
        if protocol == "ymodem":
            from mcserial.ymodem import YModem
            ym = YModem(read_func, write_func)
            result = ym.send(paths)
        else:
            from mcserial.zmodem import ZModem
            zm = ZModem(read_func, write_func)
            result = zm.send(paths)

        result["protocol"] = protocol
        return result

    except serial.SerialException as e:
        return {"error": f"Serial error: {e}", "success": False, "protocol": protocol}
    except OSError as e:
        return {"error": f"File error: {e}", "success": False, "protocol": protocol}
    except (ValueError, OverflowError) as e:
        return {"error": f"Protocol error: {e}", "success": False, "protocol": protocol}
