"""Shared utility functions for file transfer protocols.

These functions provide security and robustness for file receive operations.
"""

from __future__ import annotations

import os
from pathlib import Path


def sanitize_filename(filename: str) -> str:
    """Remove path traversal attempts and dangerous characters from filename.

    Security: Prevents directory traversal attacks where malicious senders
    could write files outside the target directory using names like
    '../../../etc/passwd' or absolute paths like '/etc/cron.d/backdoor'.

    Args:
        filename: Raw filename from remote sender (untrusted input)

    Returns:
        Safe filename with path components and dangerous characters removed
    """
    # Get just the basename, removing any directory components
    name = Path(filename).name

    # Reject empty names
    if not name:
        name = "unnamed_file"

    # Prefix hidden files (starting with dot) to make them visible
    if name.startswith("."):
        name = "_" + name[1:]

    # Replace any remaining problematic characters
    name = name.replace("\x00", "_").replace("/", "_").replace("\\", "_")

    return name


def open_file_atomic(
    filepath: Path, overwrite: bool, resume: bool = False,
) -> tuple[object, str | None, int]:
    """Open file for writing with atomic creation to prevent TOCTOU races.

    Uses O_CREAT | O_EXCL to atomically fail if file exists (when overwrite=False
    and resume=False), preventing race conditions between existence check and
    file creation.

    Args:
        filepath: Path to the file to create/open
        overwrite: If True, overwrite existing files. If False, fail if exists.
        resume: If True and file exists, open for append and return existing size.
                Takes priority over overwrite=False (resume implies we want the file).

    Returns:
        Tuple of (file_object, None, resume_offset) on success,
        or (None, error_message, 0) on failure.
        resume_offset is the existing file size when resuming, 0 otherwise.
    """
    if resume and filepath.exists():
        existing_size = filepath.stat().st_size
        return open(filepath, "r+b"), None, existing_size

    if overwrite:
        return open(filepath, "wb"), None, 0

    try:
        fd = os.open(filepath, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o644)
        return os.fdopen(fd, "wb"), None, 0
    except FileExistsError:
        return None, "File exists", 0
    except OSError as e:
        return None, str(e), 0
