"""FastMCP Serial Port Server - Tools and Resources for serial communication.

All tools and resources are registered via module imports below.
Each import triggers @mcp.tool() / @mcp.resource() decorators in that module.
"""

# ruff: noqa: I001 — import order is intentional (matches original tool registration order)

from mcserial._state import mcp  # noqa: F401 — mcp instance (must be first)

# Import order matches original tool registration order in the monolithic server.py
import mcserial._ports  # noqa: F401 — list, open, close
import mcserial._io  # noqa: F401 — write, read, read_line, read_lines, read_until
import mcserial._config  # noqa: F401 — configure, logging, flow control, mode, latency
import mcserial._modem  # noqa: F401 — modem lines, pulse, break
import mcserial._transact  # noqa: F401 — transact
import mcserial._rs485  # noqa: F401 — RS-485/422 tools
import mcserial._detection  # noqa: F401 — detect_baud_rate
import mcserial._transfers  # noqa: F401 — file transfer send/receive/batch
import mcserial._resources  # noqa: F401 — all resource handlers


def main():
    """Run the MCP serial server."""
    import sys

    from mcserial._state import DEFAULT_BAUDRATE, MAX_CONNECTIONS

    try:
        from importlib.metadata import version
        package_version = version("mcserial")
    except Exception:
        package_version = "dev"

    print(f"🔌 MCP Serial Server v{package_version}", file=sys.stderr)
    print(f"   Default baudrate: {DEFAULT_BAUDRATE}", file=sys.stderr)
    print(f"   Max connections: {MAX_CONNECTIONS}", file=sys.stderr)
    mcp.run()


if __name__ == "__main__":
    main()
