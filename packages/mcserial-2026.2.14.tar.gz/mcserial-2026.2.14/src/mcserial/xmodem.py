"""XMODEM file transfer protocol implementation.

XMODEM is the simplest serial file transfer protocol:
- 128-byte blocks (XMODEM) or 1024-byte blocks (XMODEM-1K)
- Checksum or CRC-16 error detection
- Stop-and-wait: waits for ACK after each block

Protocol flow:
  Receiver sends NAK (checksum) or 'C' (CRC) to initiate
  Sender transmits: SOH + block# + ~block# + 128 bytes + check
  Receiver sends ACK or NAK
  Repeat until EOT
"""

from __future__ import annotations

import logging
import time
from collections.abc import Callable
from typing import BinaryIO

# Protocol constants
SOH = 0x01  # Start of 128-byte header
STX = 0x02  # Start of 1024-byte header (XMODEM-1K)
EOT = 0x04  # End of transmission
ACK = 0x06  # Acknowledge
NAK = 0x15  # Negative acknowledge
CAN = 0x18  # Cancel
CRC_MODE = 0x43  # 'C' - request CRC mode

# Default parameters
DEFAULT_RETRY_LIMIT = 16  # Max retries per block
DEFAULT_TIMEOUT = 60.0  # Total transfer timeout in seconds
READ_TIMEOUT_RETRIES = 30  # Retries when waiting for response byte
INIT_TIMEOUT_RETRIES = 10  # Retries when waiting for transfer initiation
DEFAULT_MAX_TRANSFER_SIZE = 100 * 1024 * 1024  # 100MB default limit

logger = logging.getLogger(__name__)


def _calc_checksum(data: bytes) -> int:
    """Calculate simple 8-bit checksum."""
    return sum(data) & 0xFF


def _calc_crc16(data: bytes) -> int:
    """Calculate CRC-16-CCITT (XMODEM variant)."""
    crc = 0
    for byte in data:
        crc ^= byte << 8
        for _ in range(8):
            if crc & 0x8000:
                crc = (crc << 1) ^ 0x1021
            else:
                crc <<= 1
            crc &= 0xFFFF
    return crc


class XModemError(Exception):
    """Base exception for XMODEM errors."""
    pass


class XModem:
    """XMODEM file transfer protocol handler.

    Args:
        read_func: Callable that reads n bytes from serial, returns bytes
        write_func: Callable that writes bytes to serial
        mode: "xmodem" (128-byte) or "xmodem1k" (1024-byte blocks)
        use_crc: Use CRC-16 instead of checksum (default True)
    """

    def __init__(
        self,
        read_func: Callable[[int], bytes],
        write_func: Callable[[bytes], int],
        mode: str = "xmodem",
        use_crc: bool = True,
    ):
        self.read = read_func
        self.write = write_func
        self.mode = mode
        self.use_crc = use_crc
        self.block_size = 1024 if mode == "xmodem1k" else 128

    def _read_byte(self, timeout_retries: int = INIT_TIMEOUT_RETRIES) -> int | None:
        """Read a single byte with retry.

        Args:
            timeout_retries: Number of read attempts before returning None

        Returns:
            Byte value (0-255) or None if no data available after retries
        """
        for _ in range(timeout_retries):
            data = self.read(1)
            if data:
                return data[0]
        return None

    def _make_block(self, block_num: int, data: bytes) -> bytes:
        """Create a complete XMODEM block with header, data, and checksum/CRC.

        Args:
            block_num: Block sequence number (0-255, wraps)
            data: Payload data (will be padded to block_size with SUB chars)

        Returns:
            Complete block bytes ready for transmission
        """
        # Pad data to block size with SUB (0x1A) - standard XMODEM padding
        if len(data) < self.block_size:
            data = data + bytes([0x1A] * (self.block_size - len(data)))

        header = STX if self.block_size == 1024 else SOH
        block = bytes([header, block_num & 0xFF, (255 - block_num) & 0xFF]) + data

        if self.use_crc:
            crc = _calc_crc16(data)
            block += bytes([crc >> 8, crc & 0xFF])
        else:
            block += bytes([_calc_checksum(data)])

        return block

    def _verify_block(self, data: bytes, check_bytes: bytes) -> bool:
        """Verify block integrity using checksum or CRC.

        Args:
            data: The block payload to verify
            check_bytes: Received checksum (1 byte) or CRC (2 bytes)

        Returns:
            True if verification passes, False otherwise
        """
        # Validate check_bytes length before accessing indices
        expected_len = 2 if self.use_crc else 1
        if len(check_bytes) < expected_len:
            return False

        if self.use_crc:
            expected = _calc_crc16(data)
            received = (check_bytes[0] << 8) | check_bytes[1]
            return expected == received
        else:
            expected = _calc_checksum(data)
            return expected == check_bytes[0]

    def send(
        self,
        stream: BinaryIO,
        callback: Callable[[int, int], None] | None = None,
        retry_limit: int = DEFAULT_RETRY_LIMIT,
        timeout: float = DEFAULT_TIMEOUT,
    ) -> dict:
        """Send a file via XMODEM.

        Args:
            stream: File-like object to read from
            callback: Progress callback(bytes_sent, total_bytes)
            retry_limit: Max retries per block
            timeout: Total timeout in seconds (enforced across entire transfer)

        Returns:
            Dict with transfer statistics
        """
        start_time = time.monotonic()

        # Get file size for progress
        stream.seek(0, 2)  # Seek to end
        total_size = stream.tell()
        stream.seek(0)  # Seek back to start

        bytes_sent = 0
        block_num = 1
        errors = 0

        # Wait for receiver to initiate
        logger.debug("Waiting for receiver initiation...")
        init_byte = None
        for _ in range(retry_limit * 10):
            if time.monotonic() - start_time > timeout:
                return {"success": False, "error": f"Timeout ({timeout}s) waiting for receiver initiation"}

            b = self._read_byte(timeout_retries=3)
            if b == CRC_MODE:
                self.use_crc = True
                init_byte = b
                logger.debug("Receiver requested CRC mode")
                break
            elif b == NAK:
                self.use_crc = False
                init_byte = b
                logger.debug("Receiver requested checksum mode")
                break
            elif b == CAN:
                return {"success": False, "error": "Transfer cancelled by receiver"}

        if init_byte is None:
            return {"success": False, "error": "Timeout waiting for receiver"}

        # Send blocks
        while True:
            # Check timeout
            if time.monotonic() - start_time > timeout:
                return {"success": False, "error": f"Timeout ({timeout}s) during transfer at block {block_num}"}

            data = stream.read(self.block_size)
            if not data:
                break

            block = self._make_block(block_num, data)
            retries = 0

            while retries < retry_limit:
                self.write(block)
                logger.debug(f"Sent block {block_num}, {len(data)} bytes")

                response = self._read_byte(timeout_retries=READ_TIMEOUT_RETRIES)

                if response == ACK:
                    bytes_sent += len(data)
                    if callback:
                        callback(bytes_sent, total_size)
                    block_num = (block_num + 1) & 0xFF
                    break
                elif response == NAK:
                    retries += 1
                    errors += 1
                    logger.debug(f"Block {block_num} NAK'd, retry {retries}")
                elif response == CAN:
                    return {"success": False, "error": "Transfer cancelled by receiver"}
                else:
                    retries += 1
                    errors += 1
                    logger.debug(f"Block {block_num} no response, retry {retries}")
            else:
                return {"success": False, "error": f"Max retries exceeded at block {block_num}"}

        # Send EOT
        for _ in range(retry_limit):
            self.write(bytes([EOT]))
            response = self._read_byte(timeout_retries=10)
            if response == ACK:
                break
            elif response == NAK:
                continue  # Resend EOT

        return {
            "success": True,
            "bytes_sent": bytes_sent,
            "blocks": block_num - 1,
            "errors": errors,
            "mode": "crc" if self.use_crc else "checksum",
        }

    def receive(
        self,
        stream: BinaryIO,
        callback: Callable[[int], None] | None = None,
        retry_limit: int = DEFAULT_RETRY_LIMIT,
        timeout: float = DEFAULT_TIMEOUT,
        max_transfer_size: int = DEFAULT_MAX_TRANSFER_SIZE,
    ) -> dict:
        """Receive a file via XMODEM.

        Note: XMODEM has no file metadata, so the exact file size is unknown.
        Blocks are padded with SUB (0x1A) characters. For binary files, you may
        need to know the expected size and truncate accordingly. For text files,
        trailing 0x1A bytes are traditionally stripped by the receiver.

        Args:
            stream: File-like object to write to
            callback: Progress callback(bytes_received)
            retry_limit: Max retries per block
            timeout: Total timeout in seconds (enforced across entire transfer)
            max_transfer_size: Maximum bytes to receive (default 100MB).
                               Set to 0 to disable limit. Prevents disk exhaustion.

        Returns:
            Dict with transfer statistics
        """
        start_time = time.monotonic()
        bytes_received = 0
        expected_block = 1
        errors = 0

        # Initiate transfer
        init_char = CRC_MODE if self.use_crc else NAK
        logger.debug(f"Initiating transfer with {'CRC' if self.use_crc else 'checksum'} mode")

        for attempt in range(retry_limit):
            if time.monotonic() - start_time > timeout:
                return {"success": False, "error": f"Timeout ({timeout}s) waiting for sender"}

            self.write(bytes([init_char]))

            # Wait for first byte
            header = self._read_byte(timeout_retries=READ_TIMEOUT_RETRIES)
            if header in (SOH, STX):
                break
            elif header == CAN:
                return {"success": False, "error": "Transfer cancelled by sender"}

            # Fallback to checksum if CRC not supported
            if attempt == 3 and self.use_crc:
                logger.debug("CRC mode not responding, trying checksum")
                self.use_crc = False
                init_char = NAK
        else:
            return {"success": False, "error": "Timeout waiting for sender"}

        # Receive blocks
        while True:
            # Check timeout
            if time.monotonic() - start_time > timeout:
                return {"success": False, "error": f"Timeout ({timeout}s) during receive at block {expected_block}"}

            if header == EOT:
                self.write(bytes([ACK]))
                break

            # Determine block size from header
            block_size = 1024 if header == STX else 128
            check_size = 2 if self.use_crc else 1

            # Read block number
            block_num = self._read_byte()
            block_num_comp = self._read_byte()

            if block_num is None or block_num_comp is None:
                errors += 1
                self.write(bytes([NAK]))
                header = self._read_byte(timeout_retries=READ_TIMEOUT_RETRIES)
                continue

            # Verify block number complement
            if (block_num + block_num_comp) & 0xFF != 0xFF:
                logger.debug(f"Block number mismatch: {block_num} vs {block_num_comp}")
                errors += 1
                self.write(bytes([NAK]))
                header = self._read_byte(timeout_retries=READ_TIMEOUT_RETRIES)
                continue

            # Read data
            data = self.read(block_size)
            if len(data) != block_size:
                logger.debug(f"Short block: {len(data)} bytes")
                errors += 1
                self.write(bytes([NAK]))
                header = self._read_byte(timeout_retries=READ_TIMEOUT_RETRIES)
                continue

            # Read and verify check bytes
            check_bytes = self.read(check_size)
            if len(check_bytes) != check_size:
                errors += 1
                self.write(bytes([NAK]))
                header = self._read_byte(timeout_retries=READ_TIMEOUT_RETRIES)
                continue

            if not self._verify_block(data, check_bytes):
                logger.debug(f"Block {block_num} checksum/CRC error")
                errors += 1
                self.write(bytes([NAK]))
                header = self._read_byte(timeout_retries=READ_TIMEOUT_RETRIES)
                continue

            # Check sequence
            if block_num == expected_block:
                stream.write(data)
                bytes_received += len(data)
                # Block numbers wrap at 256 (8-bit counter)
                expected_block = (expected_block + 1) & 0xFF

                # Check transfer size limit to prevent disk exhaustion
                if max_transfer_size > 0 and bytes_received > max_transfer_size:
                    logger.warning(
                        f"Transfer aborted: exceeded {max_transfer_size} byte limit "
                        f"(received {bytes_received} bytes)"
                    )
                    self.write(bytes([CAN, CAN]))
                    return {
                        "success": False,
                        "error": f"Transfer size exceeded {max_transfer_size} byte limit",
                        "bytes_received": bytes_received,
                    }

                if callback:
                    callback(bytes_received)
            elif block_num == (expected_block - 1) & 0xFF:
                # Duplicate block, already ACK'd
                logger.debug(f"Duplicate block {block_num}")
            else:
                logger.debug(f"Out of sequence: expected {expected_block}, got {block_num}")
                errors += 1
                self.write(bytes([NAK]))
                header = self._read_byte(timeout_retries=READ_TIMEOUT_RETRIES)
                continue

            self.write(bytes([ACK]))
            header = self._read_byte(timeout_retries=READ_TIMEOUT_RETRIES)

        return {
            "success": True,
            "bytes_received": bytes_received,
            "blocks": expected_block - 1,
            "errors": errors,
            "mode": "crc" if self.use_crc else "checksum",
        }


def send_xmodem(
    read_func: Callable[[int], bytes],
    write_func: Callable[[bytes], int],
    stream: BinaryIO,
    mode: str = "xmodem",
    callback: Callable[[int, int], None] | None = None,
) -> dict:
    """Convenience function to send a file via XMODEM."""
    xm = XModem(read_func, write_func, mode=mode)
    return xm.send(stream, callback)


def receive_xmodem(
    read_func: Callable[[int], bytes],
    write_func: Callable[[bytes], int],
    stream: BinaryIO,
    mode: str = "xmodem",
    callback: Callable[[int], None] | None = None,
) -> dict:
    """Convenience function to receive a file via XMODEM."""
    xm = XModem(read_func, write_func, mode=mode)
    return xm.receive(stream, callback)
