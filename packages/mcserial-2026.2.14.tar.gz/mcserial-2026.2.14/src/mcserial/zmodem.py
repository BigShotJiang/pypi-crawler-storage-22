"""ZMODEM file transfer protocol implementation.

ZMODEM is the most sophisticated serial file transfer protocol:
- Streaming with selective retransmission (no stop-and-wait)
- CRC-16 or CRC-32 error detection
- Crash recovery (resume interrupted transfers)
- Auto-start capability
- Escape sequence encoding for 8-bit transparency

Frame structure:
  ZPAD ZPAD ZDLE frame_type [4 bytes header data] [CRC]

Data subpacket:
  [escaped data] ZDLE frame_end_type [CRC]
"""

from __future__ import annotations

import contextlib
import logging
import os
import time
from collections.abc import Callable
from pathlib import Path

from mcserial._utils import open_file_atomic, sanitize_filename

logger = logging.getLogger(__name__)


# Protocol constants
ZPAD = 0x2A    # '*' - Padding character

# Transfer limits
DEFAULT_MAX_TRANSFER_SIZE = 100 * 1024 * 1024  # 100MB default limit per file
MAX_SUBPACKET_SIZE = 32768  # Per-packet size limit (32KB - matches common implementations)
DEFAULT_TIMEOUT = 60.0  # Total transfer timeout in seconds
MAX_HEADER_SEARCH_ITERATIONS = 1000  # Max iterations when searching for header sync
ZDLE = 0x18    # Data Link Escape
ZDLEE = 0x58   # Escaped ZDLE (ZDLE ^ 0x40)

# Frame types
ZBIN = 0x41    # 'A' - Binary header, CRC-16
ZHEX = 0x42    # 'B' - Hex header, CRC-16
ZBIN32 = 0x43  # 'C' - Binary header, CRC-32

# Header types
ZRQINIT = 0    # Request receive init
ZRINIT = 1     # Receive init
ZSINIT = 2     # Send init sequence
ZACK = 3       # ACK
ZFILE = 4      # File name/info
ZSKIP = 5      # Skip this file
ZNAK = 6       # Last packet was garbled
ZABORT = 7     # Abort batch transfers
ZFIN = 8       # Finish session
ZRPOS = 9      # Resume at position
ZDATA = 10     # Data packet follows
ZEOF = 11      # End of file
ZFERR = 12     # Fatal error
ZCRC = 13      # Request file CRC
ZCHALLENGE = 14  # Challenge
ZCOMPL = 15    # Request complete
ZCAN = 16      # Cancel (5 CANs)
ZFREECNT = 17  # Request free bytes
ZCOMMAND = 18  # Execute command
ZSTDERR = 19   # Output to stderr

# Data subpacket end types
ZCRCE = 0x68   # 'h' - CRC next, end, no ACK
ZCRCG = 0x69   # 'i' - CRC next, not end, no ACK
ZCRCQ = 0x6A   # 'j' - CRC next, not end, ACK requested
ZCRCW = 0x6B   # 'k' - CRC next, end, ACK requested

# Special characters to escape
ESCAPE_CHARS = {0x10, 0x11, 0x13, 0x90, 0x91, 0x93, ZDLE, 0x0D, 0x8D}

# CRC-32 lookup table - initialized at module load for thread-safety
def _build_crc32_table() -> list[int]:
    """Build CRC-32 lookup table (called once at module load)."""
    table = []
    for i in range(256):
        crc = i
        for _ in range(8):
            if crc & 1:
                crc = (crc >> 1) ^ 0xEDB88320
            else:
                crc >>= 1
        table.append(crc)
    return table


_CRC32_TABLE: list[int] = _build_crc32_table()


def _calc_crc16(data: bytes) -> int:
    """Calculate CRC-16-CCITT."""
    crc = 0
    for byte in data:
        crc ^= byte << 8
        for _ in range(8):
            if crc & 0x8000:
                crc = (crc << 1) ^ 0x1021
            else:
                crc <<= 1
            crc &= 0xFFFF
    return crc


def _calc_crc32(data: bytes) -> int:
    """Calculate CRC-32 using pre-computed lookup table."""
    crc = 0xFFFFFFFF
    for byte in data:
        crc = _CRC32_TABLE[(crc ^ byte) & 0xFF] ^ (crc >> 8)
    return crc ^ 0xFFFFFFFF


def _escape_byte(b: int) -> bytes:
    """Escape a byte if needed for ZMODEM transmission."""
    if b == ZDLE:
        return bytes([ZDLE, ZDLEE])
    elif b in ESCAPE_CHARS:
        return bytes([ZDLE, b ^ 0x40])
    else:
        return bytes([b])


def _escape_data(data: bytes) -> bytes:
    """Escape all bytes in data that need escaping."""
    result = bytearray()
    for b in data:
        result.extend(_escape_byte(b))
    return bytes(result)


def _to_hex(value: int, digits: int = 2) -> bytes:
    """Convert value to hex string bytes."""
    return f"{value:0{digits}x}".encode("ascii")


class ZModemError(Exception):
    """ZMODEM protocol error."""
    pass


class ZModem:
    """ZMODEM file transfer protocol handler.

    Args:
        read_func: Callable that reads n bytes from serial
        write_func: Callable that writes bytes to serial
        use_crc32: Use CRC-32 instead of CRC-16 (default True)
    """

    def __init__(
        self,
        read_func: Callable[[int], bytes],
        write_func: Callable[[bytes], int],
        use_crc32: bool = True,
    ):
        self.read = read_func
        self.write = write_func
        self.use_crc32 = use_crc32
        self.last_sync_pos = 0
        self.tx_buffer_size = 1024
        self.rx_buffer_size = 0

    def _read_byte(self, timeout_retries: int = 10) -> int | None:
        """Read a single byte with retry."""
        for _ in range(timeout_retries):
            data = self.read(1)
            if data:
                return data[0]
        return None

    def _read_zdle_byte(self) -> int | None:
        """Read a byte, handling ZDLE escaping."""
        b = self._read_byte(timeout_retries=30)
        if b is None:
            return None
        if b == ZDLE:
            b = self._read_byte(timeout_retries=30)
            if b is None:
                return None
            if b == ZDLEE:
                return ZDLE
            elif b in (ZCRCE, ZCRCG, ZCRCQ, ZCRCW):
                return b | 0x100  # Flag as frame end
            else:
                return b ^ 0x40
        return b

    def _send_cancel(self, retries: int = 3) -> None:
        """Send ZMODEM cancel sequence with retry for reliability.

        ZMODEM uses 8 CAN bytes followed by 8 backspaces to abort transfer.
        This is the proper way to cancel - just sending ZCAN header may not
        be recognized by all implementations.

        Note: CAN (Cancel) and ZDLE share the same byte value 0x18. In ZMODEM,
        ZDLE is the escape character, but when sent 5+ times consecutively
        outside of frame context, it signals abort (CAN sequence).

        Args:
            retries: Number of times to send cancel sequence for reliability
        """
        # CAN = 0x18 (same as ZDLE) - 8 consecutive cancels + 8 backspaces
        cancel_seq = bytes([0x18] * 8 + [0x08] * 8)
        for _ in range(retries):
            self.write(cancel_seq)
            # Brief delay between retries to ensure remote receives
            time.sleep(0.1)

    def _make_hex_header(self, frame_type: int, data: bytes = b"\x00\x00\x00\x00") -> bytes:
        """Create a hex-encoded ZMODEM header."""
        header = bytes([frame_type]) + data[:4].ljust(4, b"\x00")
        crc = _calc_crc16(header)

        result = bytearray([ZPAD, ZPAD, ZDLE, ZHEX])
        for b in header:
            result.extend(_to_hex(b))
        result.extend(_to_hex(crc >> 8))
        result.extend(_to_hex(crc & 0xFF))
        result.extend(b"\r\n")

        return bytes(result)

    def _make_bin_header(self, frame_type: int, data: bytes = b"\x00\x00\x00\x00") -> bytes:
        """Create a binary ZMODEM header."""
        header = bytes([frame_type]) + data[:4].ljust(4, b"\x00")

        if self.use_crc32:
            crc = _calc_crc32(header)
            result = bytearray([ZPAD, ZDLE, ZBIN32])
            result.extend(_escape_data(header))
            crc_bytes = crc.to_bytes(4, "little")
            result.extend(_escape_data(crc_bytes))
        else:
            crc = _calc_crc16(header)
            result = bytearray([ZPAD, ZDLE, ZBIN])
            result.extend(_escape_data(header))
            result.extend(_escape_data(bytes([crc >> 8, crc & 0xFF])))

        return bytes(result)

    def _make_data_subpacket(self, data: bytes, end_type: int) -> bytes:
        """Create a data subpacket with CRC."""
        result = bytearray(_escape_data(data))
        result.extend([ZDLE, end_type])

        if self.use_crc32:
            crc = _calc_crc32(data + bytes([end_type]))
            crc_bytes = crc.to_bytes(4, "little")
            result.extend(_escape_data(crc_bytes))
        else:
            crc = _calc_crc16(data + bytes([end_type]))
            result.extend(_escape_data(bytes([crc >> 8, crc & 0xFF])))

        return bytes(result)

    def _read_hex_header(self) -> tuple[int, bytes] | None:
        """Read and parse a hex-encoded header."""
        # Read hex digits: type(2) + data(8) + crc(4) = 14 hex chars
        hex_data = self.read(14)
        if len(hex_data) != 14:
            return None

        try:
            raw = bytes.fromhex(hex_data.decode("ascii"))
        except (ValueError, UnicodeDecodeError):
            return None

        frame_type = raw[0]
        data = raw[1:5]
        recv_crc = (raw[5] << 8) | raw[6]

        calc_crc = _calc_crc16(raw[:5])
        if calc_crc != recv_crc:
            logger.debug(f"Hex header CRC mismatch: {calc_crc:04x} vs {recv_crc:04x}")
            return None

        # Read trailing CR/LF
        self.read(2)

        return frame_type, data

    def _read_bin_header(self, use_crc32: bool) -> tuple[int, bytes] | None:
        """Read and parse a binary header."""
        # Read 5 bytes: type + 4 data bytes
        raw = bytearray()
        for _ in range(5):
            b = self._read_zdle_byte()
            if b is None:
                return None
            raw.append(b & 0xFF)

        frame_type = raw[0]
        data = bytes(raw[1:5])

        # Read CRC
        crc_len = 4 if use_crc32 else 2
        crc_bytes = bytearray()
        for _ in range(crc_len):
            b = self._read_zdle_byte()
            if b is None:
                return None
            crc_bytes.append(b & 0xFF)

        # Verify CRC
        if use_crc32:
            recv_crc = int.from_bytes(crc_bytes, "little")
            calc_crc = _calc_crc32(bytes(raw))
        else:
            recv_crc = (crc_bytes[0] << 8) | crc_bytes[1]
            calc_crc = _calc_crc16(bytes(raw))

        if calc_crc != recv_crc:
            logger.debug("Binary header CRC mismatch")
            return None

        return frame_type, data

    def _read_header(self) -> tuple[int, bytes] | None:
        """Wait for and read any ZMODEM header."""
        # Look for ZPAD ZPAD ZDLE or ZPAD ZDLE
        sync_count = 0

        for _ in range(MAX_HEADER_SEARCH_ITERATIONS):
            b = self._read_byte(timeout_retries=10)
            if b is None:
                continue

            if b == ZPAD:
                sync_count += 1
            elif b == ZDLE and sync_count >= 1:
                # Found sync, read frame type
                frame_marker = self._read_byte(timeout_retries=10)
                if frame_marker == ZHEX:
                    return self._read_hex_header()
                elif frame_marker == ZBIN:
                    return self._read_bin_header(use_crc32=False)
                elif frame_marker == ZBIN32:
                    return self._read_bin_header(use_crc32=True)
                sync_count = 0
            else:
                sync_count = 0

        return None

    def _read_data_subpacket(self) -> tuple[bytes, int] | None:
        """Read a data subpacket."""
        data = bytearray()

        while True:
            b = self._read_zdle_byte()
            if b is None:
                return None

            if b & 0x100:  # Frame end marker
                end_type = b & 0xFF
                break

            data.append(b)
            if len(data) > MAX_SUBPACKET_SIZE:
                logger.debug(f"Subpacket exceeded {MAX_SUBPACKET_SIZE} bytes limit")
                return None

        # Read and verify CRC
        crc_len = 4 if self.use_crc32 else 2
        crc_bytes = bytearray()
        for _ in range(crc_len):
            b = self._read_zdle_byte()
            if b is None:
                return None
            crc_bytes.append(b & 0xFF)

        # Verify CRC
        check_data = bytes(data) + bytes([end_type])
        if self.use_crc32:
            recv_crc = int.from_bytes(crc_bytes, "little")
            calc_crc = _calc_crc32(check_data)
        else:
            recv_crc = (crc_bytes[0] << 8) | crc_bytes[1]
            calc_crc = _calc_crc16(check_data)

        if calc_crc != recv_crc:
            logger.debug("Data subpacket CRC error")
            return None

        return bytes(data), end_type

    def _pos_to_bytes(self, pos: int) -> bytes:
        """Convert position to 4-byte little-endian.

        Raises:
            OverflowError: If position exceeds 4GB (ZMODEM protocol limit)
        """
        try:
            return pos.to_bytes(4, "little")
        except OverflowError:
            raise OverflowError(
                f"File position {pos} exceeds ZMODEM's 4GB limit (max 4,294,967,295 bytes). "
                "ZMODEM uses 32-bit position encoding and cannot handle files larger than 4GB."
            ) from None

    def _bytes_to_pos(self, data: bytes, max_valid: int | None = None) -> int:
        """Convert 4-byte little-endian to position.

        Args:
            data: At least 4 bytes of position data
            max_valid: Optional maximum valid position (e.g., filesize).
                       If provided and position exceeds this, returns max_valid.

        Returns:
            Position value, clamped to max_valid if specified
        """
        if len(data) < 4:
            return 0
        pos = int.from_bytes(data[:4], "little")
        # Validate against maximum if provided (prevents seeking past EOF)
        if max_valid is not None and pos > max_valid:
            logger.debug(f"Position {pos} exceeds max {max_valid}, clamping")
            return max_valid
        return pos

    def send(
        self,
        files: list[str | Path],
        callback: Callable[[str, int, int], None] | None = None,
        retry_limit: int = 10,
        timeout: float = DEFAULT_TIMEOUT,
    ) -> dict:
        """Send files via ZMODEM.

        Args:
            files: List of file paths to send
            callback: Progress callback(filename, bytes_sent, total_bytes)
            retry_limit: Max retries for errors
            timeout: Total timeout in seconds (enforced across entire transfer)

        Returns:
            Dict with transfer statistics
        """
        start_time = time.monotonic()
        results = []
        total_bytes = 0

        # Send ZRQINIT to request receiver init
        logger.debug("Sending ZRQINIT...")
        self.write(self._make_hex_header(ZRQINIT))

        # Wait for ZRINIT from receiver
        for _ in range(retry_limit * 3):
            if time.monotonic() - start_time > timeout:
                return {"success": False, "error": f"Timeout ({timeout}s) waiting for receiver", "files": results}
            header = self._read_header()
            if header is None:
                self.write(self._make_hex_header(ZRQINIT))
                continue

            frame_type, data = header
            if frame_type == ZRINIT:
                self.rx_buffer_size = self._bytes_to_pos(data)
                logger.debug(f"Received ZRINIT, buffer={self.rx_buffer_size}")
                break
            elif frame_type == ZCAN:
                return {"success": False, "error": "Cancelled by receiver", "files": results}
        else:
            return {"success": False, "error": "No response from receiver", "files": results}

        # Send each file
        for filepath in files:
            filepath = Path(filepath)
            if not filepath.exists():
                results.append({"file": str(filepath), "error": "File not found"})
                continue

            filesize = filepath.stat().st_size
            mtime = int(filepath.stat().st_mtime)

            # Send ZFILE with filename info
            file_info = f"{filepath.name}\x00{filesize} {mtime:o} 0 0 0 0\x00".encode("latin-1")

            self.write(self._make_bin_header(ZFILE))
            self.write(self._make_data_subpacket(file_info, ZCRCW))

            # Wait for ZRPOS or ZSKIP
            start_pos = 0
            for _ in range(retry_limit):
                header = self._read_header()
                if header is None:
                    continue

                frame_type, data = header
                if frame_type == ZRPOS:
                    start_pos = self._bytes_to_pos(data)
                    logger.debug(f"Receiver wants to start at {start_pos}")
                    break
                elif frame_type == ZSKIP:
                    logger.debug(f"Receiver skipping {filepath.name}")
                    results.append({"file": str(filepath), "skipped": True})
                    break
                elif frame_type == ZCAN:
                    return {"success": False, "error": "Cancelled", "files": results}
            else:
                results.append({"file": str(filepath), "error": "No ZRPOS received"})
                continue

            if frame_type == ZSKIP:
                continue

            # Send file data
            bytes_sent = start_pos
            errors = 0

            with open(filepath, "rb") as f:
                f.seek(start_pos)

                # Send ZDATA header with position
                self.write(self._make_bin_header(ZDATA, self._pos_to_bytes(bytes_sent)))

                while bytes_sent < filesize:
                    chunk = f.read(min(self.tx_buffer_size, filesize - bytes_sent))
                    if not chunk:
                        break

                    # ZCRCE = end of file, ZCRCG = more data coming
                    end_type = ZCRCE if bytes_sent + len(chunk) >= filesize else ZCRCG

                    self.write(self._make_data_subpacket(chunk, end_type))
                    bytes_sent += len(chunk)

                    if callback:
                        callback(filepath.name, bytes_sent, filesize)

                    # Check for ZACK or ZRPOS occasionally
                    if end_type == ZCRCE or bytes_sent % (self.tx_buffer_size * 10) == 0:
                        header = self._read_header()
                        if header:
                            htype, hdata = header
                            if htype == ZRPOS:
                                # Receiver wants us to resend from position
                                new_pos = self._bytes_to_pos(hdata)
                                logger.debug(f"ZRPOS received, resending from {new_pos}")
                                f.seek(new_pos)
                                bytes_sent = new_pos
                                errors += 1
                                self.write(self._make_bin_header(ZDATA, self._pos_to_bytes(bytes_sent)))
                            elif htype == ZCAN:
                                return {"success": False, "error": "Cancelled", "files": results}

            # Send ZEOF
            self.write(self._make_bin_header(ZEOF, self._pos_to_bytes(bytes_sent)))

            # Wait for ZRINIT (ready for next file)
            for _ in range(retry_limit):
                header = self._read_header()
                if header and header[0] == ZRINIT:
                    break

            results.append({
                "file": str(filepath),
                "bytes_sent": bytes_sent,
                "errors": errors,
                "success": True,
            })
            total_bytes += bytes_sent

        # Send ZFIN to end session
        self.write(self._make_hex_header(ZFIN))

        # Wait for ZFIN response
        for _ in range(retry_limit):
            header = self._read_header()
            if header and header[0] == ZFIN:
                # Send OO to complete
                self.write(b"OO")
                break

        return {
            "success": all(r.get("success", False) or r.get("skipped", False) for r in results),
            "files": results,
            "total_bytes": total_bytes,
        }

    def receive(
        self,
        directory: str | Path,
        callback: Callable[[str, int, int], None] | None = None,
        retry_limit: int = 10,
        overwrite: bool = False,
        resume: bool = True,
        max_transfer_size: int = DEFAULT_MAX_TRANSFER_SIZE,
        timeout: float = DEFAULT_TIMEOUT,
    ) -> dict:
        """Receive files via ZMODEM.

        Args:
            directory: Directory to save received files
            callback: Progress callback(filename, bytes_received, total_bytes)
            retry_limit: Max retries for errors
            overwrite: Overwrite existing files
            resume: Resume interrupted transfers. When True and a partial file
                    exists, tells the sender to start from where the previous
                    transfer left off (default: True).
            max_transfer_size: Maximum bytes to receive per file (default 100MB).
                               Set to 0 to disable limit. Prevents unbounded memory usage.
            timeout: Total timeout in seconds (enforced across entire transfer)

        Returns:
            Dict with transfer statistics
        """
        start_time = time.monotonic()
        directory = Path(directory)
        directory.mkdir(parents=True, exist_ok=True)

        results = []
        total_bytes = 0

        # Send ZRINIT to indicate ready
        buffer_size = 8192
        logger.debug("Sending ZRINIT...")
        self.write(self._make_hex_header(ZRINIT, self._pos_to_bytes(buffer_size)))

        while True:
            # Check timeout
            if time.monotonic() - start_time > timeout:
                return {"success": False, "error": f"Timeout ({timeout}s)", "files": results}

            # Wait for ZFILE or ZFIN
            header = None
            for _ in range(retry_limit * 3):
                if time.monotonic() - start_time > timeout:
                    return {"success": False, "error": f"Timeout ({timeout}s)", "files": results}
                header = self._read_header()
                if header:
                    break
                # Resend ZRINIT
                self.write(self._make_hex_header(ZRINIT, self._pos_to_bytes(buffer_size)))

            if header is None:
                return {"success": False, "error": "Timeout", "files": results}

            frame_type, data = header

            if frame_type == ZFIN:
                # Session complete
                self.write(self._make_hex_header(ZFIN))
                break
            elif frame_type == ZCAN:
                return {"success": False, "error": "Cancelled", "files": results}
            elif frame_type != ZFILE:
                continue

            # Read file info subpacket
            subpacket = self._read_data_subpacket()
            if subpacket is None:
                self.write(self._make_hex_header(ZNAK))
                continue

            file_data, _ = subpacket

            # Parse filename and metadata
            try:
                null_pos = file_data.index(0)
                filename = file_data[:null_pos].decode("latin-1")
                rest = file_data[null_pos + 1:].split(b" ")
                filesize = int(rest[0]) if rest[0] else 0
                mtime = int(rest[1], 8) if len(rest) > 1 and rest[1] else None
            except (ValueError, IndexError):
                filename = file_data.split(b"\x00")[0].decode("latin-1", errors="replace")
                filesize = 0
                mtime = None

            logger.debug(f"Receiving: {filename} ({filesize} bytes)")

            # Security: sanitize filename to prevent path traversal attacks
            safe_filename = sanitize_filename(filename)
            if safe_filename != filename:
                logger.warning(f"Sanitized filename: {filename!r} -> {safe_filename!r}")

            filepath = directory / safe_filename

            # Atomic file creation with optional crash recovery
            f, file_error, resume_offset = open_file_atomic(filepath, overwrite, resume=resume)
            if file_error:
                logger.warning(f"Cannot create file {filepath}: {file_error}")
                results.append({"file": filename, "error": file_error})
                self.write(self._make_hex_header(ZSKIP))
                continue

            # Resume from existing file size if we have a partial file
            start_pos = resume_offset
            if start_pos > 0:
                logger.debug(f"Resuming {filename} from byte {start_pos}")

            # Send ZRPOS to indicate where to start
            self.write(self._make_bin_header(ZRPOS, self._pos_to_bytes(start_pos)))

            # Receive data
            bytes_received = start_pos
            errors = 0
            transfer_aborted = False

            try:
                if start_pos > 0:
                    f.seek(start_pos)

                while not transfer_aborted:
                    # Wait for ZDATA header
                    header = self._read_header()
                    if header is None:
                        errors += 1
                        self.write(self._make_bin_header(ZRPOS, self._pos_to_bytes(bytes_received)))
                        continue

                    frame_type, data = header

                    if frame_type == ZEOF:
                        eof_pos = self._bytes_to_pos(data)
                        logger.debug(f"ZEOF at position {eof_pos}")
                        break
                    elif frame_type == ZCAN:
                        results.append({"file": filename, "error": "Cancelled"})
                        break
                    elif frame_type != ZDATA:
                        continue

                    data_pos = self._bytes_to_pos(data)
                    if data_pos != bytes_received:
                        logger.debug(f"Position mismatch: expected {bytes_received}, got {data_pos}")
                        self.write(self._make_bin_header(ZRPOS, self._pos_to_bytes(bytes_received)))
                        continue

                    # Read data subpackets
                    while True:
                        subpacket = self._read_data_subpacket()
                        if subpacket is None:
                            errors += 1
                            self.write(self._make_bin_header(ZRPOS, self._pos_to_bytes(bytes_received)))
                            break

                        chunk, end_type = subpacket
                        f.write(chunk)
                        bytes_received += len(chunk)

                        # Check transfer size limit to prevent unbounded memory usage
                        if max_transfer_size > 0 and bytes_received > max_transfer_size:
                            logger.warning(
                                f"Transfer aborted: {filename} exceeded {max_transfer_size} byte limit "
                                f"(received {bytes_received} bytes)"
                            )
                            self._send_cancel()
                            transfer_aborted = True
                            break

                        if callback:
                            callback(filename, bytes_received, filesize)

                        if end_type in (ZCRCE, ZCRCW):
                            # End of this ZDATA frame
                            if end_type == ZCRCW:
                                self.write(self._make_bin_header(ZACK, self._pos_to_bytes(bytes_received)))
                            break
            finally:
                f.close()

            if transfer_aborted:
                # Transfer was aborted due to size limit
                results.append({
                    "file": filename,
                    "path": str(filepath),
                    "error": f"Transfer size exceeded {max_transfer_size} byte limit",
                    "bytes_received": bytes_received,
                    "success": False,
                })
                # Try to clean up partial file
                with contextlib.suppress(OSError):
                    filepath.unlink()
                continue

            # Set modification time
            if mtime:
                os.utime(filepath, (time.time(), mtime))

            # Send ZRINIT for next file
            self.write(self._make_hex_header(ZRINIT, self._pos_to_bytes(buffer_size)))

            results.append({
                "file": filename,
                "path": str(filepath),
                "bytes_received": bytes_received,
                "errors": errors,
                "success": True,
            })
            total_bytes += bytes_received

        return {
            "success": all(r.get("success", False) for r in results),
            "files": results,
            "total_bytes": total_bytes,
        }


def send_zmodem(
    read_func: Callable[[int], bytes],
    write_func: Callable[[bytes], int],
    files: list[str | Path],
    callback: Callable[[str, int, int], None] | None = None,
) -> dict:
    """Convenience function to send files via ZMODEM."""
    zm = ZModem(read_func, write_func)
    return zm.send(files, callback)


def receive_zmodem(
    read_func: Callable[[int], bytes],
    write_func: Callable[[bytes], int],
    directory: str | Path,
    callback: Callable[[str, int, int], None] | None = None,
    overwrite: bool = False,
    resume: bool = True,
) -> dict:
    """Convenience function to receive files via ZMODEM."""
    zm = ZModem(read_func, write_func)
    return zm.receive(directory, callback, overwrite=overwrite, resume=resume)
