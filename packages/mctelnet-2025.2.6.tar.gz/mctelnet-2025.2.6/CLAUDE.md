# mctelnet telnet client/server for LLMS
