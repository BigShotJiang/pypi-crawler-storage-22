"""mctelnet - MCP server providing telnet client capabilities for LLMs."""

from mctelnet.server import main, mcp

__all__ = ["main", "mcp"]
