"""Tests for mctelnet server."""

import pytest

from mctelnet.server import _connections, _servers, _strip_ansi, mcp


def test_mcp_server_exists():
    """Verify MCP server is configured."""
    assert mcp.name == "mctelnet"


def test_client_tools_registered():
    """Verify all expected client tools are registered."""
    tool_manager = mcp._tool_manager
    tool_names = set(tool_manager._tools.keys())

    expected_tools = {
        "connect",
        "send",
        "send_key",
        "list_keys",
        "read",
        "expect",
        "expect_send",
        "run_script",
        "list_connections",
        "disconnect",
        "disconnect_all",
        "connection_info",
        "get_transcript",
    }

    assert expected_tools.issubset(tool_names), f"Missing tools: {expected_tools - tool_names}"


def test_server_tools_registered():
    """Verify all expected server tools are registered."""
    tool_manager = mcp._tool_manager
    tool_names = set(tool_manager._tools.keys())

    expected_tools = {
        "start_server",
        "stop_server",
        "list_servers",
        "server_info",
        "list_clients",
        "read_client",
        "send_client",
        "broadcast",
        "disconnect_client",
        "get_server_transcript",
    }

    assert expected_tools.issubset(tool_names), f"Missing tools: {expected_tools - tool_names}"


def test_connection_storage_initially_empty():
    """Verify no connections exist at startup."""
    _connections.clear()
    assert len(_connections) == 0


def test_server_storage_initially_empty():
    """Verify no servers exist at startup."""
    _servers.clear()
    assert len(_servers) == 0


class TestAnsiStripping:
    """Tests for ANSI escape sequence stripping."""

    def test_strip_simple_color(self):
        """Strip basic color codes."""
        text = "\x1b[32mgreen\x1b[0m text"
        assert _strip_ansi(text) == "green text"

    def test_strip_complex_sgr(self):
        """Strip multi-parameter SGR sequences."""
        text = "\x1b[1;31;40mBold red on black\x1b[0m"
        assert _strip_ansi(text) == "Bold red on black"

    def test_strip_cursor_movement(self):
        """Strip cursor movement sequences."""
        text = "\x1b[2J\x1b[H\x1b[5;10HHello"
        assert _strip_ansi(text) == "Hello"

    def test_strip_osc_title(self):
        """Strip OSC window title sequences (BEL terminated)."""
        text = "\x1b]0;Window Title\x07Some text"
        assert _strip_ansi(text) == "Some text"

    def test_strip_osc_st_terminated(self):
        """Strip OSC sequences terminated with ST."""
        text = "\x1b]0;Title\x1b\\Some text"
        assert _strip_ansi(text) == "Some text"

    def test_preserve_plain_text(self):
        """Plain text passes through unchanged."""
        text = "Hello, World! 123"
        assert _strip_ansi(text) == text

    def test_mixed_content(self):
        """Handle mixed plain text and ANSI codes."""
        text = "Start \x1b[1mBold\x1b[0m middle \x1b[4mUnderline\x1b[0m end"
        assert _strip_ansi(text) == "Start Bold middle Underline end"
