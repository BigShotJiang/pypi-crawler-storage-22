from git import Repo

g = Repo(".")


print(g.untracked_files)
