import argparse
import curses
import json
import os
import re
import socket
import ssl
import subprocess
import textwrap
import urllib.error
import urllib.request
from dataclasses import dataclass
from datetime import date, datetime
from pathlib import Path
from typing import List, Optional

try:
    import yaml
except Exception:  # pragma: no cover
    yaml = None

DEFAULT_OLLAMA_URL = "http://localhost:11434/api/generate"
DEFAULT_MODEL = "gpt-oss"
CONFIG_FILENAME = ".config.yaml"
PROCESS_FILENAME = "process.txt"
STATE_FILENAME = ".pm_state.json"
ROOT_MARKERS = [CONFIG_FILENAME, PROCESS_FILENAME, "notes.log", "toknows.md", "todos.md", "blogposts"]
NOTE_LINE_RE = re.compile(r"^(\d{2}/\d{2}/\d{2}):(\d{2} \d{2}):\s([^:]+):\s(.*)$")
OPEN_QUESTION_RE = re.compile(r"^\s*-\s*\[open\]\s*(.*)$", re.IGNORECASE)
OPEN_QUESTION_META_PREFIX_RE = re.compile(r"^\d{2}/\d{2}/\d{2}:\d{2}\s\d{2}:\s[^:]+:\s")

FLOW_TEXT = """PHASE A: RECON
1) Add context and findings to notes.log
2) Generate/open questions in toknows.md
3) Resolve questions via interviews/research and add findings back to notes.log
4) Repeat steps 2-3 until recon is complete

PHASE B: PLANNING
5) Generate tasks in todos.md using notes.log
6) Add new ambiguities/questions to toknows.md from notes.log + todos.md
7) Resolve those questions and add findings to notes.log
8) Repeat steps 6-7 until planning is complete

PHASE C: BUILDING
9) Execute todos
10) Create demo blogposts in blogposts/YYYY-MM-DD.md
11) Capture feedback in notes.log
12) Repeat steps 5-11 until building is complete
"""

DEFAULT_PROMPTS = {
    "toknow": """You are a senior project manager responsible for discovery quality.

Update the file `toknows.md` using the process and notes below.
Return ONLY markdown for the full file.
Keep unresolved useful questions, remove duplicates, and keep it concise.
Critically: remove questions that are already answered by the notes.

Required output shape:
# Things To Know

- [open] DD/MM/YY:HH MM: author: question

Rules:
- Use only [open] items.
- Ask specific, high-value clarification questions.
- No answers or commentary.
- If notes contain enough information to answer a question, that question must be removed.
- If partially answered, rewrite to only the remaining unknown.
- Keep at most 20 items.

Process:
{process}

Hint:
{hint}

Notes (metadata removed):
{notes}

Current toknows.md:
{existing_toknows}
""",
    "todo": """You are a senior project planner creating implementation-ready plans.

Update the file `todos.md` using process, notes, and open questions.
Return ONLY markdown for the full file.
Keep useful tasks, remove duplicates, and keep tasks concrete.

Required output shape:
# Todos

- [todo] DD/MM/YY:HH MM: author: task

Rules:
- Use only [todo] items.
- Tasks must be actionable and specific.
- No commentary.
- Keep at most 25 items.

Process:
{process}

Hint:
{hint}

Notes (metadata removed):
{notes}

Current toknows.md:
{toknows}

Current todos.md:
{existing_todos}
""",
    "assumptions": """You are a senior project manager preparing planning assumptions.

Generate the full contents of `assumptions.md` from process, notes, questions, and todos.
Return ONLY markdown.

Required output shape:
# Assumptions

- DD/MM/YY:HH MM: author: assumption

Rules:
- Include only assumptions relevant for planning.
- Keep statements testable where possible.
- No commentary.
- Keep at most 20 items.

Process:
{process}

Hint:
{hint}

Notes (metadata removed):
{notes}

Current toknows.md:
{toknows}

Current todos.md:
{todos}
""",
}


@dataclass(frozen=True)
class AICommand:
    name: str
    target_file: str
    description: str


AI_COMMANDS = {
    "toknow": AICommand("toknow", "toknows.md", "Generate/update open questions from notes."),
    "todo": AICommand("todo", "todos.md", "Generate/update actionable tasks from notes and open questions."),
}


@dataclass(frozen=True)
class NoteEvent:
    timestamp: datetime
    author: str
    message: str


def _run_git(args: List[str], cwd: Path) -> Optional[str]:
    try:
        result = subprocess.run(
            ["git"] + args,
            cwd=str(cwd),
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            check=True,
        )
        return result.stdout.strip() or None
    except Exception:
        return None


def _author(cwd: Path) -> str:
    name = _run_git(["config", "user.name"], cwd)
    if name:
        return name
    try:
        return os.getlogin()
    except Exception:
        return "unknown"


def _timestamp() -> str:
    return datetime.now().astimezone().strftime("%d/%m/%y:%H %M")


def _resolve_default_root(start: Path) -> Path:
    top = _run_git(["rev-parse", "--show-toplevel"], start)
    if top:
        return Path(top)
    return start


def _write_if_missing(path: Path, content: str) -> None:
    if not path.exists():
        path.write_text(content, encoding="utf-8")


def _ensure_gitignore_has_archives(root: Path) -> None:
    path = root / ".gitignore"
    if not path.exists():
        path.write_text("archives/\n", encoding="utf-8")
        return

    content = path.read_text(encoding="utf-8")
    lines = {line.strip() for line in content.splitlines()}
    if "archives/" not in lines:
        suffix = "" if content.endswith("\n") else "\n"
        path.write_text(content + suffix + "archives/\n", encoding="utf-8")


def _default_config() -> dict:
    return {
        "ollama_endpoint": DEFAULT_OLLAMA_URL,
        "ollama_model": DEFAULT_MODEL,
        "ollama_token": "REPLACE_ME",
        "ollama_insecure_tls": False,
        "ollama_timeout_sec": 180,
        "process_file": PROCESS_FILENAME,
        "prompts": DEFAULT_PROMPTS,
    }


def _init_layout(root: Path) -> None:
    root.mkdir(parents=True, exist_ok=True)
    _write_if_missing(root / "notes.log", "")
    _write_if_missing(root / "toknows.md", "# Things To Know\n\n")
    _write_if_missing(root / "todos.md", "# Todos\n\n")
    (root / "blogposts").mkdir(parents=True, exist_ok=True)
    (root / "archives").mkdir(parents=True, exist_ok=True)
    _write_if_missing(root / PROCESS_FILENAME, FLOW_TEXT.rstrip() + "\n")
    _write_if_missing(root / STATE_FILENAME, json.dumps({"phase": "recon"}, indent=2) + "\n")
    if not (root / CONFIG_FILENAME).exists():
        config = _default_config()
        if yaml is None:
            raise OSError("PyYAML is required to write .config.yaml")
        (root / CONFIG_FILENAME).write_text(yaml.safe_dump(config, sort_keys=False), encoding="utf-8")
    _ensure_gitignore_has_archives(root)


def _is_initialized(root: Path) -> bool:
    return all((root / marker).exists() for marker in ROOT_MARKERS)


def _find_initialized_root(start: Path) -> Optional[Path]:
    current = start
    while True:
        if _is_initialized(current):
            return current
        if current.parent == current:
            return None
        current = current.parent


def _safe_read(path: Path) -> str:
    if not path.exists():
        return ""
    return path.read_text(encoding="utf-8")


def _load_config(root: Path) -> dict:
    config = _default_config()
    if yaml is None:
        raise RuntimeError("PyYAML is required to read .config.yaml")
    path = root / CONFIG_FILENAME
    if not path.exists():
        return config

    raw = path.read_text(encoding="utf-8").strip()
    if not raw:
        return config

    try:
        parsed = yaml.safe_load(raw)
    except Exception as exc:
        raise RuntimeError(f"Invalid YAML in {CONFIG_FILENAME}: {exc}") from exc
    if not isinstance(parsed, dict):
        return config

    endpoint = parsed.get("ollama_endpoint")
    model = parsed.get("ollama_model")
    token = parsed.get("ollama_token")
    insecure_tls = parsed.get("ollama_insecure_tls")
    timeout_sec = parsed.get("ollama_timeout_sec")
    process_file = parsed.get("process_file")
    prompts = parsed.get("prompts")

    if isinstance(endpoint, str) and endpoint:
        config["ollama_endpoint"] = endpoint
    if isinstance(model, str) and model:
        config["ollama_model"] = model
    if isinstance(token, str):
        config["ollama_token"] = token
    if isinstance(insecure_tls, bool):
        config["ollama_insecure_tls"] = insecure_tls
    if isinstance(timeout_sec, int) and timeout_sec > 0:
        config["ollama_timeout_sec"] = timeout_sec
    if isinstance(process_file, str) and process_file:
        config["process_file"] = process_file
    if isinstance(prompts, dict):
        merged = dict(DEFAULT_PROMPTS)
        for key in ("toknow", "todo", "assumptions"):
            value = prompts.get(key)
            if isinstance(value, str) and value.strip():
                merged[key] = value
        config["prompts"] = merged

    return config


def _load_state(root: Path) -> dict:
    path = root / STATE_FILENAME
    if not path.exists():
        return {"phase": "recon"}
    raw = path.read_text(encoding="utf-8").strip()
    if not raw:
        return {"phase": "recon"}
    parsed = json.loads(raw)
    if isinstance(parsed, dict):
        return parsed
    return {"phase": "recon"}


def _save_state(root: Path, state: dict) -> None:
    (root / STATE_FILENAME).write_text(json.dumps(state, indent=2) + "\n", encoding="utf-8")


def _append_line(path: Path, line: str) -> None:
    with path.open("a", encoding="utf-8") as fh:
        if path.stat().st_size > 0:
            with path.open("rb") as rb:
                rb.seek(-1, os.SEEK_END)
                if rb.read(1) != b"\n":
                    fh.write("\n")
        fh.write(line + "\n")


def _strip_fenced_block(text: str) -> str:
    stripped = text.strip()
    if stripped.startswith("```") and stripped.endswith("```"):
        lines = stripped.splitlines()
        if len(lines) >= 2:
            return "\n".join(lines[1:-1]).strip()
    return stripped


def _resolve_ollama_token(cfg: dict) -> Optional[str]:
    token = cfg.get("ollama_token")
    if isinstance(token, str) and token:
        if token.strip() and token.strip() != "REPLACE_ME":
            return token.strip()
    return None


def _call_ollama(
    prompt: str,
    model: str,
    endpoint: str,
    timeout_sec: int = 90,
    token: Optional[str] = None,
    insecure_tls: bool = False,
) -> str:
    is_chat = endpoint.rstrip("/").endswith("/chat")
    if is_chat:
        payload = {
            "model": model,
            "messages": [{"role": "user", "content": prompt}],
            "stream": False,
        }
    else:
        payload = {"model": model, "prompt": prompt, "stream": False}
    headers = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    req = urllib.request.Request(
        endpoint,
        data=json.dumps(payload).encode("utf-8"),
        method="POST",
        headers=headers,
    )
    ssl_context = None
    if endpoint.startswith("https://") and insecure_tls:
        ssl_context = ssl._create_unverified_context()

    try:
        with urllib.request.urlopen(req, timeout=timeout_sec, context=ssl_context) as resp:
            body = resp.read().decode("utf-8")
    except TimeoutError as exc:
        raise RuntimeError(
            f"Ollama request timed out after {timeout_sec}s. "
            f"Check Ollama server/model health or increase timeout."
        ) from exc
    except socket.timeout as exc:
        raise RuntimeError(
            f"Ollama request timed out after {timeout_sec}s. "
            f"Check Ollama server/model health or increase timeout."
        ) from exc
    except urllib.error.URLError as exc:
        raise RuntimeError(f"Ollama request failed: {exc}") from exc

    try:
        parsed = json.loads(body)
    except json.JSONDecodeError as exc:
        raise RuntimeError("Ollama returned non-JSON output") from exc

    output = parsed.get("response", "")
    if not output:
        message = parsed.get("message")
        if isinstance(message, dict):
            content = message.get("content")
            if isinstance(content, str):
                output = content
    if not output:
        raise RuntimeError("Ollama returned empty response")
    return _strip_fenced_block(output)


def _parse_cutoff_date(value: Optional[str]) -> Optional[date]:
    if not value:
        return None
    try:
        return datetime.strptime(value, "%d/%m/%y").date()
    except ValueError as exc:
        raise RuntimeError("Invalid --date. Expected format DD/MM/YY") from exc


def _notes_messages_text(root: Path, cutoff: Optional[date]) -> str:
    path = root / "notes.log"
    if not path.exists():
        return ""

    messages: List[str] = []
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line:
            continue
        m = NOTE_LINE_RE.match(line)
        if not m:
            messages.append(line)
            continue

        d = datetime.strptime(m.group(1), "%d/%m/%y").date()
        if cutoff and d > cutoff:
            continue
        messages.append(m.group(4).strip())

    return "\n".join(f"- {msg}" for msg in messages)


def _load_note_events(root: Path, cutoff: Optional[date] = None) -> List[NoteEvent]:
    path = root / "notes.log"
    if not path.exists():
        return []

    events: List[NoteEvent] = []
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line:
            continue
        m = NOTE_LINE_RE.match(line)
        if not m:
            continue
        day_text = m.group(1)
        time_text = m.group(2)
        author = m.group(3).strip()
        message = m.group(4).strip()
        dt = datetime.strptime(f"{day_text}:{time_text}", "%d/%m/%y:%H %M")
        if cutoff and dt.date() > cutoff:
            continue
        events.append(NoteEvent(timestamp=dt, author=author, message=message))
    return events


def _gap_lines(prev: datetime, curr: datetime) -> List[str]:
    minutes = max(0.0, (curr - prev).total_seconds() / 60.0)
    if minutes < 30:
        return []
    if minutes < 6 * 60:
        return [""]
    if minutes < 24 * 60:
        return ["", "  .. gap ~hours ..", ""]
    days = int(minutes // (24 * 60))
    return ["", f"  .. gap ~{days}d ..", ""]


def _render_timeline_lines(events: List[NoteEvent], width: int = 100) -> List[str]:
    if not events:
        return ["No note events found in notes.log"]

    lines: List[str] = []
    prev: Optional[datetime] = None
    max_width = max(40, width)
    for ev in events:
        if prev is not None:
            lines.extend(_gap_lines(prev, ev.timestamp))
        prefix = f"{ev.timestamp.strftime('%d/%m/%y %H:%M')} | {ev.author} | "
        wrap_width = max(20, max_width - len(prefix))
        wrapped = textwrap.wrap(ev.message, width=wrap_width) or [""]
        lines.append(prefix + wrapped[0])
        continuation = " " * len(prefix)
        for part in wrapped[1:]:
            lines.append(continuation + part)
        prev = ev.timestamp
    return lines


def _timeline_tui(lines: List[str]) -> None:
    def _run(stdscr):
        curses.curs_set(0)
        stdscr.keypad(True)
        top = 0
        while True:
            stdscr.erase()
            height, width = stdscr.getmaxyx()
            body_height = max(1, height - 1)
            max_top = max(0, len(lines) - body_height)
            top = max(0, min(top, max_top))

            header = "pm notes  (j/k or arrows scroll, PgUp/PgDn, g/G, q quit)"
            stdscr.addnstr(0, 0, header, max(1, width - 1))
            for row in range(body_height):
                idx = top + row
                if idx >= len(lines):
                    break
                stdscr.addnstr(row + 1, 0, lines[idx], max(1, width - 1))
            stdscr.refresh()

            key = stdscr.getch()
            if key in (ord("q"), 27):
                break
            if key in (ord("j"), curses.KEY_DOWN):
                top = min(max_top, top + 1)
            elif key in (ord("k"), curses.KEY_UP):
                top = max(0, top - 1)
            elif key in (curses.KEY_NPAGE,):
                top = min(max_top, top + body_height)
            elif key in (curses.KEY_PPAGE,):
                top = max(0, top - body_height)
            elif key == ord("g"):
                top = 0
            elif key == ord("G"):
                top = max_top

    curses.wrapper(_run)


def _archive_before_replace(root: Path, filename: str) -> None:
    path = root / filename
    if not path.exists() or not path.read_text(encoding="utf-8").strip():
        return
    stamp = datetime.now().astimezone().strftime("%Y%m%d-%H%M%S")
    archive = root / "archives" / f"{filename}.{stamp}.bak"
    archive.write_text(path.read_text(encoding="utf-8"), encoding="utf-8")


def _render_prompt(template: str, context: dict) -> str:
    try:
        return template.format(**context)
    except KeyError as exc:
        raise RuntimeError(f"Prompt template missing placeholder: {exc}") from exc


def _rewrite_with_archive(root: Path, filename: str, content: str) -> None:
    _archive_before_replace(root, filename)
    (root / filename).write_text(content.rstrip() + "\n", encoding="utf-8")


def _extract_open_questions(toknows_text: str) -> List[str]:
    questions: List[str] = []
    for raw in toknows_text.splitlines():
        m = OPEN_QUESTION_RE.match(raw.strip())
        if not m:
            continue
        text = m.group(1).strip()
        if not text:
            continue
        text = OPEN_QUESTION_META_PREFIX_RE.sub("", text).strip()
        questions.append(text)
    return questions


def _show_next_open_question(root: Path) -> int:
    text = _safe_read(root / "toknows.md")
    questions = _extract_open_questions(text)
    if not questions:
        print("No [open] questions found in toknows.md")
        return 1
    print("Next open question:")
    print(questions[0])
    print("")
    print("After clarifying it, capture findings with:")
    print("  pm note \"...\"")
    return 0


def cmd_init(args: argparse.Namespace) -> int:
    base = Path(args.path).resolve() if args.path else _resolve_default_root(Path(".").resolve())
    try:
        _init_layout(base)
    except OSError as exc:
        print(f"Failed to initialize notes workspace: {exc}")
        return 1

    print(f"Initialized workflow files in {base}")
    return 0


def cmd_help(args: argparse.Namespace) -> int:
    print("Commands:")
    print("- pm init [path]")
    print("- pm flow")
    print("- pm note \"...\"")
    print("- pm toknow [hint] [--date DD/MM/YY] [--model MODEL] [--endpoint URL] [--timeout SEC]")
    print("- pm toknow next")
    print("- pm todo [hint] [--date DD/MM/YY] [--model MODEL] [--endpoint URL] [--timeout SEC]")
    print("- pm demo \"...\"")
    print("- pm notes [--date DD/MM/YY] [--plain]")
    print("- pm phase [recon|planning|building] [--hint ...] [--model MODEL] [--endpoint URL] [--timeout SEC]")
    return 0


def cmd_flow(args: argparse.Namespace) -> int:
    root = _find_initialized_root(Path(".").resolve())
    if root:
        cfg = _load_config(root)
        process_path = root / cfg.get("process_file", PROCESS_FILENAME)
        if process_path.exists():
            print(process_path.read_text(encoding="utf-8").strip())
            return 0
    print(FLOW_TEXT)
    return 0


def cmd_note(args: argparse.Namespace) -> int:
    if not args.text:
        print("note: Capture raw context, facts, and findings.")
        print("Format: DD/MM/YY:HH MM: author: message")
        print("Example: pm note \"Primary users are nurses and admin\"")
        return 0

    root = _find_initialized_root(Path(".").resolve())
    if not root:
        print("Workspace is not initialized. Run `pm init` first.")
        return 1

    try:
        _append_line(root / "notes.log", f"{_timestamp()}: {_author(root)}: {args.text}")
    except OSError as exc:
        print(f"Failed to write note: {exc}")
        return 1

    print(f"Added note in {root}")
    return 0


def cmd_demo(args: argparse.Namespace) -> int:
    if not args.text:
        print("demo: Add a demo/blogpost note for today's date.")
        print("Format: - DD/MM/YY:HH MM: author: demo note")
        print("Example: pm demo \"Demoed medication module\"")
        return 0

    root = _find_initialized_root(Path(".").resolve())
    if not root:
        print("Workspace is not initialized. Run `pm init` first.")
        return 1

    day = datetime.now().astimezone().strftime("%Y-%m-%d")
    path = root / "blogposts" / f"{day}.md"

    try:
        if not path.exists():
            path.write_text(f"# Demo Notes - {day}\n\n", encoding="utf-8")
        _append_line(path, f"- {_timestamp()}: {_author(root)}: {args.text}")
    except OSError as exc:
        print(f"Failed to write demo note: {exc}")
        return 1

    print(f"Added demo entry in {path}")
    return 0


def cmd_notes(args: argparse.Namespace) -> int:
    root = _find_initialized_root(Path(".").resolve())
    if not root:
        print("Workspace is not initialized. Run `pm init` first.")
        return 1

    try:
        cutoff = _parse_cutoff_date(args.date)
    except RuntimeError as exc:
        print(str(exc))
        return 1

    events = _load_note_events(root, cutoff=cutoff)
    lines = _render_timeline_lines(events)
    if args.plain:
        print("\n".join(lines))
        return 0

    if not os.isatty(0) or not os.isatty(1):
        print("\n".join(lines))
        return 0

    try:
        _timeline_tui(lines)
    except curses.error as exc:
        print(f"Timeline TUI failed: {exc}")
        print("\n".join(lines))
    return 0


def cmd_ai(args: argparse.Namespace) -> int:
    command = AI_COMMANDS[args.command_name]
    root = _find_initialized_root(Path(".").resolve())
    if not root:
        print("Workspace is not initialized. Run `pm init` first.")
        return 1

    if (
        command.name == "toknow"
        and args.hint == "next"
        and args.date is None
        and args.model is None
        and args.endpoint is None
        and args.timeout is None
    ):
        return _show_next_open_question(root)

    try:
        cutoff = _parse_cutoff_date(args.date)
        cfg = _load_config(root)
    except (RuntimeError, OSError) as exc:
        print(str(exc))
        return 1

    notes = _notes_messages_text(root, cutoff)
    process_text = _safe_read(root / cfg.get("process_file", PROCESS_FILENAME)) or FLOW_TEXT
    prompts = cfg.get("prompts", DEFAULT_PROMPTS)

    context = {
        "process": process_text,
        "hint": args.hint or "(none)",
        "notes": notes or "(no notes)",
        "existing_toknows": _safe_read(root / "toknows.md"),
        "toknows": _safe_read(root / "toknows.md"),
        "existing_todos": _safe_read(root / "todos.md"),
        "todos": _safe_read(root / "todos.md"),
    }

    template = prompts.get(command.name)
    if not isinstance(template, str) or not template.strip():
        print(f"Missing prompt template for {command.name} in {CONFIG_FILENAME}")
        return 1

    model = args.model or cfg.get("ollama_model", DEFAULT_MODEL)
    endpoint = args.endpoint or cfg.get("ollama_endpoint", DEFAULT_OLLAMA_URL)
    token = _resolve_ollama_token(cfg)
    if not token:
        print(f"Missing `ollama_token` in {CONFIG_FILENAME}.")
        return 1
    insecure_tls = bool(cfg.get("ollama_insecure_tls", False))
    timeout_sec = args.timeout if args.timeout is not None else int(cfg.get("ollama_timeout_sec", 180))

    try:
        prompt = _render_prompt(template, context)
        updated = _call_ollama(
            prompt=prompt,
            model=model,
            endpoint=endpoint,
            timeout_sec=timeout_sec,
            token=token,
            insecure_tls=insecure_tls,
        )
    except RuntimeError as exc:
        print(str(exc))
        return 1

    if not updated.strip():
        print("AI returned empty output; file not changed.")
        return 1

    try:
        _rewrite_with_archive(root, command.target_file, updated)
    except OSError as exc:
        print(f"Failed to update {root / command.target_file}: {exc}")
        return 1

    print(f"Updated {root / command.target_file}")
    return 0


def _generate_assumptions(
    root: Path,
    cfg: dict,
    hint: str,
    model_arg: Optional[str],
    endpoint_arg: Optional[str],
    timeout_arg: Optional[int],
) -> None:
    notes = _notes_messages_text(root, None)
    process_text = _safe_read(root / cfg.get("process_file", PROCESS_FILENAME)) or FLOW_TEXT
    prompts = cfg.get("prompts", DEFAULT_PROMPTS)
    template = prompts.get("assumptions")
    if not isinstance(template, str) or not template.strip():
        raise RuntimeError(f"Missing prompt template for assumptions in {CONFIG_FILENAME}")

    context = {
        "process": process_text,
        "hint": hint or "(none)",
        "notes": notes or "(no notes)",
        "toknows": _safe_read(root / "toknows.md"),
        "todos": _safe_read(root / "todos.md"),
    }

    model = model_arg or cfg.get("ollama_model", DEFAULT_MODEL)
    endpoint = endpoint_arg or cfg.get("ollama_endpoint", DEFAULT_OLLAMA_URL)
    token = _resolve_ollama_token(cfg)
    if not token:
        raise RuntimeError(f"Missing `ollama_token` in {CONFIG_FILENAME}.")
    insecure_tls = bool(cfg.get("ollama_insecure_tls", False))
    timeout_sec = timeout_arg if timeout_arg is not None else int(cfg.get("ollama_timeout_sec", 180))

    prompt = _render_prompt(template, context)
    updated = _call_ollama(
        prompt=prompt,
        model=model,
        endpoint=endpoint,
        timeout_sec=timeout_sec,
        token=token,
        insecure_tls=insecure_tls,
    )
    if not updated.strip():
        raise RuntimeError("AI returned empty assumptions output")

    _rewrite_with_archive(root, "assumptions.md", updated)


def cmd_phase(args: argparse.Namespace) -> int:
    root = _find_initialized_root(Path(".").resolve())
    if not root:
        print("Workspace is not initialized. Run `pm init` first.")
        return 1

    try:
        state = _load_state(root)
        cfg = _load_config(root)
    except (RuntimeError, json.JSONDecodeError, OSError) as exc:
        print(f"Failed to read state/config: {exc}")
        return 1

    current = state.get("phase", "recon")
    if not args.phase:
        print(f"Current phase: {current}")
        return 0

    if args.phase == current:
        print(f"Phase unchanged: {current}")
        return 0

    if current == "recon" and args.phase == "planning":
        try:
            _generate_assumptions(root, cfg, args.hint or "", args.model, args.endpoint, args.timeout)
        except (RuntimeError, OSError) as exc:
            print(f"Failed to generate assumptions.md: {exc}")
            return 1
        print(f"Generated {root / 'assumptions.md'}")

    state["phase"] = args.phase
    try:
        _save_state(root, state)
    except OSError as exc:
        print(f"Failed to save phase state: {exc}")
        return 1

    print(f"Phase set to {args.phase}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="pm", description="Project workflow CLI")
    subparsers = parser.add_subparsers(dest="command")

    init_p = subparsers.add_parser("init", help="Initialize notes.log/toknows.md/todos.md/blogposts")
    init_p.add_argument("path", nargs="?", help="Target path (defaults to git root or current directory)")
    init_p.set_defaults(func=cmd_init)

    help_p = subparsers.add_parser("help", help="Show command help")
    help_p.set_defaults(func=cmd_help)

    flow_p = subparsers.add_parser("flow", help="Show the three-phase process")
    flow_p.set_defaults(func=cmd_flow)

    note_p = subparsers.add_parser("note", help="Capture raw context/finding notes")
    note_p.add_argument("text", nargs="?", help="Note message")
    note_p.set_defaults(func=cmd_note)

    for name, cmd in AI_COMMANDS.items():
        p = subparsers.add_parser(name, help=cmd.description)
        p.add_argument("hint", nargs="?", help="Optional hint for the model")
        p.add_argument("--date", default=None, help="Include notes up to DD/MM/YY (default: all notes)")
        p.add_argument("--model", default=None, help=f"Ollama model (default from {CONFIG_FILENAME})")
        p.add_argument("--endpoint", default=None, help=f"Ollama endpoint (default from {CONFIG_FILENAME})")
        p.add_argument("--timeout", type=int, default=None, help=f"Request timeout seconds (default from {CONFIG_FILENAME})")
        p.set_defaults(func=cmd_ai, command_name=name)

    demo_p = subparsers.add_parser("demo", help="Add demo/blogpost note")
    demo_p.add_argument("text", nargs="?", help="Demo message")
    demo_p.set_defaults(func=cmd_demo)

    notes_p = subparsers.add_parser("notes", help="View notes.log as a compressed timeline")
    notes_p.add_argument("--date", default=None, help="Show entries up to DD/MM/YY (default: all)")
    notes_p.add_argument("--plain", action="store_true", help="Print non-interactive timeline")
    notes_p.set_defaults(func=cmd_notes)

    phase_p = subparsers.add_parser("phase", help="Show/set project phase")
    phase_p.add_argument("phase", nargs="?", choices=["recon", "planning", "building"], help="Target phase")
    phase_p.add_argument("--hint", default=None, help="Optional hint for assumptions generation")
    phase_p.add_argument("--model", default=None, help=f"Ollama model (default from {CONFIG_FILENAME})")
    phase_p.add_argument("--endpoint", default=None, help=f"Ollama endpoint (default from {CONFIG_FILENAME})")
    phase_p.add_argument("--timeout", type=int, default=None, help=f"Request timeout seconds (default from {CONFIG_FILENAME})")
    phase_p.set_defaults(func=cmd_phase)

    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    if not hasattr(args, "func"):
        parser.print_help()
        return 1
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
