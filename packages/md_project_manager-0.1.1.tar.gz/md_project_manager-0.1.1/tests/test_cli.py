import io
import json
import os
import tempfile
import unittest
from contextlib import redirect_stdout
from datetime import datetime
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

import sys

REPO_ROOT = Path(__file__).resolve().parents[1]
SRC_ROOT = REPO_ROOT / "src"
if str(SRC_ROOT) not in sys.path:
    sys.path.insert(0, str(SRC_ROOT))

from pm import cli  # noqa: E402


class PmCliTests(unittest.TestCase):
    @staticmethod
    def _set_test_token(root: Path):
        cfg = root / ".config.yaml"
        cfg.write_text(cfg.read_text(encoding="utf-8").replace("REPLACE_ME", "test-token"), encoding="utf-8")

    def test_init_creates_expected_files_and_gitignore_entry(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            rc = cli.cmd_init(SimpleNamespace(path=str(root)))
            self.assertEqual(rc, 0)

            self.assertTrue((root / ".config.yaml").exists())
            self.assertTrue((root / ".pm_state.json").exists())
            self.assertTrue((root / "process.txt").exists())
            self.assertTrue((root / "notes.log").exists())
            self.assertTrue((root / "toknows.md").exists())
            self.assertTrue((root / "todos.md").exists())
            self.assertTrue((root / "blogposts").is_dir())
            self.assertTrue((root / "archives").is_dir())

            gitignore = (root / ".gitignore").read_text(encoding="utf-8")
            self.assertIn("archives/", gitignore)

            config_text = (root / ".config.yaml").read_text(encoding="utf-8")
            self.assertIn("ollama_token:", config_text)
            self.assertIn("prompts:", config_text)
            self.assertIn("toknow:", config_text)
            self.assertIn("todo:", config_text)
            self.assertIn("assumptions:", config_text)

    def test_notes_messages_text_strips_metadata_and_filters_by_date(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "notes.log").write_text(
                "12/02/26:10 00: alice: older note\n"
                "13/02/26:11 00: bob: newer note\n"
                "line without metadata\n",
                encoding="utf-8",
            )
            cutoff = cli._parse_cutoff_date("12/02/26")
            text = cli._notes_messages_text(root, cutoff)
            self.assertIn("- older note", text)
            self.assertIn("- line without metadata", text)
            self.assertNotIn("newer note", text)
            self.assertNotIn("alice", text)
            self.assertNotIn("12/02/26", text)

    def test_todo_uses_date_filter_and_archives_previous_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            cli._init_layout(root)
            self._set_test_token(root)
            (root / "notes.log").write_text(
                "12/02/26:10 00: alice: include this\n"
                "13/02/26:10 00: alice: exclude this\n",
                encoding="utf-8",
            )
            (root / "todos.md").write_text("# Todos\n\n- [todo] existing\n", encoding="utf-8")

            captured_prompt = {"value": ""}

            def fake_call(
                prompt: str,
                model: str,
                endpoint: str,
                timeout_sec: int = 90,
                token=None,
                insecure_tls=False,
            ) -> str:
                captured_prompt["value"] = prompt
                return "# Todos\n\n- [todo] 13/02/26:12 00: ai: refreshed task\n"

            args = SimpleNamespace(
                command_name="todo",
                hint=None,
                date="12/02/26",
                model=None,
                endpoint=None,
                timeout=None,
            )

            cwd = Path.cwd()
            try:
                os.chdir(root)
                with patch("pm.cli._call_ollama", side_effect=fake_call):
                    rc = cli.cmd_ai(args)
            finally:
                os.chdir(cwd)

            self.assertEqual(rc, 0)
            written = (root / "todos.md").read_text(encoding="utf-8")
            self.assertIn("refreshed task", written)

            archives = list((root / "archives").glob("todos.md.*.bak"))
            self.assertTrue(archives, "Expected an archived backup of todos.md")
            self.assertIn("include this", captured_prompt["value"])
            self.assertNotIn("exclude this", captured_prompt["value"])
            self.assertNotIn("alice", captured_prompt["value"])

    def test_phase_transition_generates_assumptions_and_updates_state(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            cli._init_layout(root)
            self._set_test_token(root)
            (root / "notes.log").write_text("13/02/26:10 00: alice: assumption source\n", encoding="utf-8")

            args = SimpleNamespace(phase="planning", hint=None, model=None, endpoint=None, timeout=None)
            cwd = Path.cwd()
            try:
                os.chdir(root)
                with patch(
                    "pm.cli._call_ollama",
                    return_value="# Assumptions\n\n- 13/02/26:12 00: ai: network is reliable\n",
                ):
                    rc = cli.cmd_phase(args)
            finally:
                os.chdir(cwd)

            self.assertEqual(rc, 0)
            self.assertTrue((root / "assumptions.md").exists())
            state = json.loads((root / ".pm_state.json").read_text(encoding="utf-8"))
            self.assertEqual(state.get("phase"), "planning")

    def test_invalid_date_returns_error(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            cli._init_layout(root)
            args = SimpleNamespace(
                command_name="toknow",
                hint=None,
                date="2026-02-12",
                model=None,
                endpoint=None,
                timeout=None,
            )
            cwd = Path.cwd()
            try:
                os.chdir(root)
                out = io.StringIO()
                with redirect_stdout(out):
                    rc = cli.cmd_ai(args)
            finally:
                os.chdir(cwd)

            self.assertEqual(rc, 1)
            self.assertIn("Invalid --date", out.getvalue())

    def test_missing_token_in_config_returns_error(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            cli._init_layout(root)
            args = SimpleNamespace(
                command_name="toknow",
                hint=None,
                date=None,
                model=None,
                endpoint=None,
                timeout=None,
            )
            cwd = Path.cwd()
            try:
                os.chdir(root)
                out = io.StringIO()
                with redirect_stdout(out):
                    rc = cli.cmd_ai(args)
            finally:
                os.chdir(cwd)

            self.assertEqual(rc, 1)
            self.assertIn("Missing `ollama_token`", out.getvalue())

    def test_call_ollama_timeout_is_wrapped(self):
        with patch("pm.cli.urllib.request.urlopen", side_effect=TimeoutError("timed out")):
            with self.assertRaises(RuntimeError) as ctx:
                cli._call_ollama("p", "m", "http://localhost:11434/api/generate", timeout_sec=1)
        self.assertIn("timed out", str(ctx.exception))

    def test_call_ollama_chat_endpoint_uses_messages_and_parses_content(self):
        captured = {"body": "", "auth": ""}

        class _Resp:
            def __enter__(self):
                return self

            def __exit__(self, exc_type, exc, tb):
                return False

            def read(self):
                return b'{"message":{"role":"assistant","content":"ok from chat"}}'

        def fake_urlopen(req, timeout=0, context=None):
            captured["body"] = req.data.decode("utf-8")
            captured["auth"] = req.headers.get("Authorization", "")
            return _Resp()

        with patch("pm.cli.urllib.request.urlopen", side_effect=fake_urlopen):
            out = cli._call_ollama(
                "hello",
                "gpt-oss",
                "https://example.com/ollama/api/chat",
                token="secret-token",
            )

        self.assertEqual(out, "ok from chat")
        self.assertIn('"messages"', captured["body"])
        self.assertNotIn('"prompt"', captured["body"])
        self.assertEqual(captured["auth"], "Bearer secret-token")

    def test_call_ollama_insecure_tls_sets_ssl_context(self):
        captured = {"has_context": False}

        class _Resp:
            def __enter__(self):
                return self

            def __exit__(self, exc_type, exc, tb):
                return False

            def read(self):
                return b'{"response":"ok"}'

        def fake_urlopen(req, timeout=0, context=None):
            captured["has_context"] = context is not None
            return _Resp()

        with patch("pm.cli.urllib.request.urlopen", side_effect=fake_urlopen):
            out = cli._call_ollama(
                "hello",
                "gpt-oss",
                "https://example.com/ollama/api/generate",
                insecure_tls=True,
            )

        self.assertEqual(out, "ok")
        self.assertTrue(captured["has_context"])

    def test_render_timeline_lines_includes_gap_markers(self):
        events = [
            cli.NoteEvent(timestamp=datetime.strptime("12/02/26:10 00", "%d/%m/%y:%H %M"), author="alice", message="one"),
            cli.NoteEvent(timestamp=datetime.strptime("12/02/26:10 10", "%d/%m/%y:%H %M"), author="alice", message="two"),
            cli.NoteEvent(timestamp=datetime.strptime("13/02/26:10 10", "%d/%m/%y:%H %M"), author="alice", message="three"),
        ]
        lines = cli._render_timeline_lines(events, width=80)
        rendered = "\n".join(lines)
        self.assertIn("one", rendered)
        self.assertIn("two", rendered)
        self.assertIn("three", rendered)
        self.assertIn("gap", rendered)

    def test_notes_plain_outputs_rendered_notes(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            cli._init_layout(root)
            (root / "notes.log").write_text(
                "12/02/26:10 00: alice: first\n"
                "12/02/26:10 10: alice: second\n"
                "13/02/26:10 10: alice: third\n",
                encoding="utf-8",
            )
            args = SimpleNamespace(date=None, plain=True)
            cwd = Path.cwd()
            try:
                os.chdir(root)
                out = io.StringIO()
                with redirect_stdout(out):
                    rc = cli.cmd_notes(args)
            finally:
                os.chdir(cwd)

            self.assertEqual(rc, 0)
            text = out.getvalue()
            self.assertIn("alice", text)
            self.assertIn("first", text)
            self.assertIn("third", text)
            self.assertIn("gap", text)

    def test_extract_open_questions_strips_metadata_prefix(self):
        text = (
            "# Things To Know\n\n"
            "- [open] 13/02/26:12 00: alice: What are required resident data fields?\n"
            "- [open] Which module should be prioritized after MVP?\n"
        )
        questions = cli._extract_open_questions(text)
        self.assertEqual(
            questions,
            [
                "What are required resident data fields?",
                "Which module should be prioritized after MVP?",
            ],
        )

    def test_toknow_next_prints_first_open_question(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            cli._init_layout(root)
            (root / "toknows.md").write_text(
                "# Things To Know\n\n"
                "- [open] 13/02/26:12 00: alice: First question?\n"
                "- [open] 13/02/26:12 01: alice: Second question?\n",
                encoding="utf-8",
            )
            args = SimpleNamespace(
                command_name="toknow",
                hint="next",
                date=None,
                model=None,
                endpoint=None,
                timeout=None,
            )
            cwd = Path.cwd()
            try:
                os.chdir(root)
                out = io.StringIO()
                with redirect_stdout(out):
                    rc = cli.cmd_ai(args)
            finally:
                os.chdir(cwd)

            self.assertEqual(rc, 0)
            text = out.getvalue()
            self.assertIn("Next open question:", text)
            self.assertIn("First question?", text)


if __name__ == "__main__":
    unittest.main()
