# mdash

Unified browser-based explorer for PostgreSQL, Redis, and S3. Browse tables, keys, and buckets side-by-side in one tabbed interface.

## Install

```bash
uv sync --all-packages
```

## Usage

```bash
# Connect to all three backends at once
uv run mdash \
  --db "postgresql://memrun:memrun@localhost:5432/memrun" \
  --redis-url "redis://localhost:6379" \
  --s3-profile default

# Or start with no connections and connect via the UI
uv run mdash

# Multiple instances of the same type
uv run mdash \
  --db prod="postgresql://user:pass@prod:5432/app" \
  --db staging="postgresql://user:pass@staging:5432/app" \
  --redis-url cache="redis://localhost:6379" \
  --redis-url sessions="redis://localhost:6380" \
  --s3-profile default \
  --s3-profile rsm

# Labels are optional — auto-derived from the URL if omitted
uv run mdash --db "$DATABASE_URL" --redis-url "$REDIS_URL"

# S3 with explicit credentials
uv run mdash \
  --s3-endpoint "http://localhost:9000" \
  --s3-access-key AKIAIOSFODNN7EXAMPLE \
  --s3-secret-key wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY
```

## Options

| Flag | Env var | Description |
|------|---------|-------------|
| `--db` | `DATABASE_URL` | PostgreSQL connection (`label=url` or `url`). Repeatable. |
| `--redis-url` | `REDIS_URL` | Redis connection (`label=url` or `url`). Repeatable. |
| `--s3-endpoint` | `S3_ENDPOINT_URL` | S3-compatible endpoint URL |
| `--s3-access-key` | `AWS_ACCESS_KEY_ID` | AWS access key |
| `--s3-secret-key` | `AWS_SECRET_ACCESS_KEY` | AWS secret key |
| `--s3-region` | | AWS region (default: us-east-1) |
| `--s3-profile` | | AWS profile name. Repeatable. |
| `--port` | | Backend port (default: 8430) |
| `--page-size` | | Rows per page (default: 100) |
| `--no-open` | | Don't auto-open browser |

## Features

- **Mixed tabs** — Open a Postgres table, Redis keys, and an S3 bucket in the same view
- **Multi-instance** — Connect to multiple databases, Redis servers, or S3 profiles side-by-side
- **Color-coded tabs** — Purple (PG), Red (Redis), Orange (S3) badges for quick identification
- **Independent state** — Each tab maintains its own filters, pagination, and results
- **Connect at runtime** — Click "+" to connect new backends without restarting
- **Graceful startup** — If a backend is unreachable, the server starts anyway

### PostgreSQL tabs
- Include/exclude filters with column autocomplete
- Highlight matching rows
- Column selection
- SQL preview
- Pagination with configurable page size

### Redis tabs
- Glob pattern key scanning (`user:*`, `*config*`)
- Key type display (string, list, set, zset, hash, stream)
- Detail panel with TTL, memory size, and value preview

### S3 tabs
- Bucket selection
- Prefix-based server-side filtering
- Client-side key filter with regex support
- Detail panel with content type, metadata, and text preview

## Development

```bash
# Start the backend (auto-reloads)
cd packages/mdash
uv run mdash --no-open

# In another terminal, start the frontend dev server
cd packages/mdash/frontend
npm run dev
# Opens at http://localhost:5176 (proxies API to :8430)
```

To rebuild the frontend for production:

```bash
cd packages/mdash/frontend
npm run build
```
