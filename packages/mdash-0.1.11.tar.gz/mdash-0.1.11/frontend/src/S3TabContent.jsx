import React, { useState, useEffect, useRef, useCallback } from "react";
import ToggleButton from "./ToggleButton";
import { S3DetailPanel } from "./DetailPanel";
import { RefreshButton } from "./FilterBar";
import { s3QueryKeys, s3GetKeyDetail } from "./api";

function matchesHighlight(text, highlight, opts = {}) {
  if (!highlight) return true;
  const { caseSensitive, wholeWord, regex } = opts;
  const str = String(text);
  if (regex) {
    try {
      const flags = caseSensitive ? "" : "i";
      const pattern = wholeWord ? `\\b${highlight}\\b` : highlight;
      return new RegExp(pattern, flags).test(str);
    } catch { return false; }
  }
  if (wholeWord) {
    const flags = caseSensitive ? "" : "i";
    try {
      return new RegExp(`\\b${highlight.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\b`, flags).test(str);
    } catch { return false; }
  }
  if (caseSensitive) return str.includes(highlight);
  return str.toLowerCase().includes(highlight.toLowerCase());
}

function formatSize(bytes) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1048576) return `${(bytes / 1024).toFixed(1)} KB`;
  if (bytes < 1073741824) return `${(bytes / 1048576).toFixed(1)} MB`;
  return `${(bytes / 1073741824).toFixed(1)} GB`;
}

const btnStyle = (enabled) => ({
  background: "none",
  border: "1px solid var(--border)",
  borderRadius: 4,
  padding: "2px 8px",
  color: enabled ? "var(--text)" : "var(--text-dim)",
  cursor: enabled ? "pointer" : "default",
  fontFamily: "inherit",
  fontSize: 11,
  opacity: enabled ? 1 : 0.4,
});

export default function S3TabContent({ tab, updateTab, pageSize, setError, refreshKey, locked }) {
  const [selectedKey, setSelectedKey] = useState(null);
  const [detail, setDetail] = useState(null);
  const [detailLoading, setDetailLoading] = useState(false);
  const [highlight, setHighlight] = useState("");
  const [highlightOpts, setHighlightOpts] = useState({ caseSensitive: false, wholeWord: false, regex: false });
  const debounceRef = useRef(null);
  const pageSizeRef = useRef(pageSize);
  pageSizeRef.current = pageSize;
  const initialRefreshKey = useRef(refreshKey);

  // Auto-query on mount
  useEffect(() => {
    if (tab.results) return;
    runQuery(tab.filter || "", null);
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // Refresh All
  useEffect(() => {
    if (refreshKey === initialRefreshKey.current) return;
    runQuery(tab.filter || "", (tab.tokens || [null])[tab.page]);
  }, [refreshKey]); // eslint-disable-line react-hooks/exhaustive-deps

  const runQuery = useCallback((prefix, continuationToken) => {
    updateTab({ loading: true });
    setError(null);
    s3QueryKeys(tab.instanceId, {
      bucket: tab.bucket,
      prefix,
      continuationToken,
      limit: pageSizeRef.current,
    })
      .then((data) => {
        updateTab({
          results: data,
          loading: false,
          nextToken: data.next_token,
        });
      })
      .catch((e) => {
        setError(e.message);
        updateTab({ loading: false });
      });
  }, [tab.bucket, updateTab, setError]);

  const handleFilterChange = (value) => {
    updateTab({ filter: value });
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => {
      updateTab({ page: 0, tokens: [null] });
      runQuery(value, null);
    }, 300);
  };

  const handleNextPage = () => {
    if (!tab.results?.has_more) return;
    const newPage = tab.page + 1;
    const newTokens = [...(tab.tokens || [null])];
    if (newTokens.length <= newPage) {
      newTokens.push(tab.nextToken);
    }
    updateTab({ page: newPage, tokens: newTokens });
    runQuery(tab.filter || "", tab.nextToken);
  };

  const handlePrevPage = () => {
    if (tab.page <= 0) return;
    const newPage = tab.page - 1;
    updateTab({ page: newPage });
    runQuery(tab.filter || "", (tab.tokens || [null])[newPage]);
  };

  const handleSelectKey = (key) => {
    if (selectedKey === key) {
      setSelectedKey(null);
      setDetail(null);
      return;
    }
    setSelectedKey(key);
    setDetailLoading(true);
    setDetail(null);
    s3GetKeyDetail(tab.instanceId, tab.bucket, key)
      .then((data) => { setDetail(data); setDetailLoading(false); })
      .catch((e) => { setError(e.message); setDetailLoading(false); });
  };

  const rows = tab.results?.rows;
  const totalCount = tab.results?.total_count || 0;
  const hasMore = tab.results?.has_more || false;
  const columns = rows && rows.length > 0 ? Object.keys(rows[0]) : [];
  const filteredRows = rows && highlight
    ? rows.filter((row) => Object.values(row).some((v) => matchesHighlight(v, highlight, highlightOpts)))
    : rows;

  return (
    <div style={{ display: "flex", flex: 1, overflow: "hidden" }}>
      <div style={{ display: "flex", flexDirection: "column", flex: 1, overflow: "hidden" }}>
        {/* Filter bar */}
        {tab.filtersVisible !== false && (
          <div
            style={{
              display: "flex",
              gap: 12,
              padding: "12px 20px",
              background: "var(--panel)",
              borderBottom: "1px solid var(--border)",
              alignItems: "flex-end",
            }}
          >
            <div style={{ flex: 1, minWidth: 200 }}>
              <label
                style={{
                  display: "block",
                  fontSize: 10,
                  fontWeight: 600,
                  textTransform: "uppercase",
                  letterSpacing: "0.1em",
                  color: "var(--green)",
                  marginBottom: 4,
                }}
              >
                Prefix
              </label>
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  background: "var(--green-bg)",
                  border: "1px solid var(--green)33",
                  borderRadius: 6,
                }}
              >
                <input
                  type="text"
                  value={tab.filter || ""}
                  onChange={(e) => handleFilterChange(e.target.value)}
                  placeholder="e.g. logs/, data/2024-, config"
                  spellCheck={false}
                  style={{
                    flex: 1,
                    background: "transparent",
                    border: "none",
                    padding: "8px 12px",
                    color: "var(--text)",
                    fontFamily: "inherit",
                    fontSize: 13,
                    outline: "none",
                  }}
                  onFocus={(e) => { e.target.closest("div").style.borderColor = "var(--green)66"; }}
                  onBlur={(e) => { e.target.closest("div").style.borderColor = "var(--green)33"; }}
                />
              </div>
            </div>
            <div style={{ flex: 1, minWidth: 200 }}>
              <label
                style={{
                  display: "block",
                  fontSize: 10,
                  fontWeight: 600,
                  textTransform: "uppercase",
                  letterSpacing: "0.1em",
                  color: "var(--yellow)",
                  marginBottom: 4,
                }}
              >
                Filter
              </label>
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  background: "var(--yellow-bg)",
                  border: "1px solid var(--yellow)33",
                  borderRadius: 6,
                }}
              >
                <input
                  type="text"
                  value={highlight}
                  onChange={(e) => setHighlight(e.target.value)}
                  placeholder="filter returned keys..."
                  spellCheck={false}
                  style={{
                    flex: 1,
                    background: "transparent",
                    border: "none",
                    padding: "8px 12px",
                    color: "var(--text)",
                    fontFamily: "inherit",
                    fontSize: 13,
                    outline: "none",
                  }}
                  onFocus={(e) => { e.target.closest("div").style.borderColor = "var(--yellow)66"; }}
                  onBlur={(e) => { e.target.closest("div").style.borderColor = "var(--yellow)33"; }}
                />
                <div style={{ display: "flex", gap: 2, paddingRight: 6, flexShrink: 0 }}>
                  <ToggleButton label="Aa" active={highlightOpts.caseSensitive} onClick={() => setHighlightOpts(o => ({ ...o, caseSensitive: !o.caseSensitive }))} color="var(--yellow)" />
                  <ToggleButton label="ab" active={highlightOpts.wholeWord} onClick={() => setHighlightOpts(o => ({ ...o, wholeWord: !o.wholeWord }))} color="var(--yellow)" />
                  <ToggleButton label=".*" active={highlightOpts.regex} onClick={() => setHighlightOpts(o => ({ ...o, regex: !o.regex }))} color="var(--yellow)" />
                </div>
              </div>
            </div>
            <RefreshButton onClick={() => runQuery(tab.filter || "", (tab.tokens || [null])[tab.page])} />
          </div>
        )}

        {/* Results */}
        {rows !== null && rows !== undefined && (
          <div style={{ flex: 1, overflow: "auto", position: "relative" }}>
            <div
              style={{
                padding: "8px 20px",
                fontSize: 11,
                color: "var(--text-dim)",
                borderBottom: "1px solid var(--border)",
                background: "var(--panel)",
                position: "sticky",
                top: 0,
                zIndex: 10,
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
              }}
            >
              <span>
                {highlight ? `${filteredRows.length} of ${totalCount} objects` : `${totalCount} objects`}
                {tab.filter ? ` with prefix "${tab.filter}"` : ""}
              </span>
              <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              {locked && (
                <button
                  onClick={() => updateTab({ filtersVisible: tab.filtersVisible === false ? true : false })}
                  title={tab.filtersVisible !== false ? "Hide filters" : "Show filters"}
                  style={{
                    background: tab.filtersVisible !== false ? "rgba(255,255,255,0.04)" : "none",
                    border: "1px solid var(--border)",
                    borderRadius: 4,
                    color: tab.filtersVisible !== false ? "var(--text)" : "var(--text-dim)",
                    fontSize: 10,
                    padding: "1px 6px",
                    cursor: "pointer",
                    display: "flex",
                    alignItems: "center",
                    gap: 3,
                  }}
                  onMouseEnter={(e) => { e.currentTarget.style.borderColor = "var(--text-dim)"; }}
                  onMouseLeave={(e) => { e.currentTarget.style.borderColor = "var(--border)"; }}
                >
                  <span style={{ fontSize: 8 }}>{tab.filtersVisible !== false ? "\u25BE" : "\u25B8"}</span>
                  <span>filters</span>
                </button>
              )}
              {(hasMore || tab.page > 0) && (
                <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                  <button style={btnStyle(tab.page > 0)} disabled={tab.page <= 0} onClick={handlePrevPage}>Prev</button>
                  <span>Page {tab.page + 1}</span>
                  <button style={btnStyle(hasMore)} disabled={!hasMore} onClick={handleNextPage}>Next</button>
                </div>
              )}
              </div>
            </div>

            {filteredRows && filteredRows.length === 0 ? (
              <div style={{ padding: 40, textAlign: "center", color: "var(--text-dim)" }}>
                {highlight ? "No matching objects" : "No objects found"}
              </div>
            ) : filteredRows && (
              <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12 }}>
                <thead>
                  <tr>
                    {columns.map((col) => (
                      <th
                        key={col}
                        style={{
                          position: "sticky",
                          top: 33,
                          background: "var(--bg)",
                          padding: "8px 12px",
                          textAlign: "left",
                          fontWeight: 600,
                          fontSize: 11,
                          textTransform: "uppercase",
                          letterSpacing: "0.05em",
                          color: "var(--text-dim)",
                          borderBottom: "1px solid var(--border)",
                          whiteSpace: "nowrap",
                          zIndex: 5,
                        }}
                      >
                        {col}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {filteredRows.map((row, i) => {
                    const isSelected = selectedKey === row.key;
                    return (
                      <tr
                        key={row.key}
                        onClick={() => handleSelectKey(row.key)}
                        style={{
                          cursor: "pointer",
                          background: isSelected ? "var(--selected-row)" : i % 2 === 1 ? "var(--row-alt)" : "transparent",
                          borderLeft: isSelected ? "3px solid var(--purple)" : "3px solid transparent",
                        }}
                        onMouseEnter={(e) => { if (!isSelected) e.currentTarget.style.background = "var(--row-hover)"; }}
                        onMouseLeave={(e) => {
                          e.currentTarget.style.background = isSelected ? "var(--selected-row)" : i % 2 === 1 ? "var(--row-alt)" : "transparent";
                        }}
                      >
                        {columns.map((col) => (
                          <td
                            key={col}
                            style={{
                              padding: "6px 12px",
                              borderBottom: "1px solid var(--border)",
                              whiteSpace: "nowrap",
                              maxWidth: 500,
                              overflow: "hidden",
                              textOverflow: "ellipsis",
                            }}
                          >
                            {col === "size" ? formatSize(row[col]) : String(row[col])}
                          </td>
                        ))}
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            )}
          </div>
        )}
      </div>

      {selectedKey && (
        <S3DetailPanel
          detail={detail}
          loading={detailLoading}
          onClose={() => { setSelectedKey(null); setDetail(null); }}
        />
      )}
    </div>
  );
}
