# mdplab
A Python module for learning and experimenting with Markov Decision Processes.

Under construction. Emphasizes learning, experimentation and ease of use. 

