"""
mdplab: a minimal laboratory for Markov decision processes
"""

__version__ = "0.0.2"

__all__ = ["MDP"]
