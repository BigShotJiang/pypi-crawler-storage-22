class MDP:
    """
    Minimal representation of a Markov decision process.

    This is currently a stub used to validade the development workflow.
    """

    def __init__(self):
        pass
