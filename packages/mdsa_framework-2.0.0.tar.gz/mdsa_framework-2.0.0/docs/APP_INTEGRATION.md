# MDSA Framework - App Integration Guide

**Version:** 2.0.0
**Author:** VICKY (Vicky Vignesh) + Claude Opus 4.5
**Last Updated:** January 2026

---

## Overview

The MDSA (Multi-Domain Small Language Model Agentic) Framework is a **platform-agnostic orchestration system** that can integrate with ANY application built on ANY framework (FastAPI, Flask, Django, Express, etc.).

This guide documents the **API contract** that applications must implement to be compatible with MDSA.

---

## Quick Start

### 1. Install MDSA Framework

```bash
pip install mdsa-framework
```

### 2. Register Your App

```python
from mdsa.core.app_registry import register_current_app

# Call this during app startup
register_current_app(
    app_id="your_app_id",           # Unique identifier (lowercase, alphanumeric)
    app_name="Your App Name",        # Display name
    framework="fastapi",             # "fastapi", "flask", "django", "express"
    api_endpoint="http://localhost:8000"
)
```

### 3. Implement Required Endpoints

Your app must expose these REST API endpoints:

| Endpoint | Required | Purpose |
|----------|----------|---------|
| `GET /api/health` | **YES** | Health check |
| `GET /api/domains` | **YES** | List available domains |
| `GET /api/metrics` | **YES** | System metrics |
| `GET /api/tools` | Optional | List available tools |
| `GET /api/models` | Optional | List loaded models |

---

## Required Endpoints

### 1. Health Check - `GET /api/health`

**Purpose:** MDSA Dashboard uses this to check if your app is running.

**Response Format:**
```json
{
  "status": "healthy",
  "app_id": "your_app_id",
  "version": "1.0.0",
  "uptime_seconds": 3600
}
```

**Required Fields:**
- `status` (string): Must be `"healthy"` when app is operational

**Optional Fields:**
- `app_id` (string): Your app's unique identifier
- `version` (string): Your app's version
- `uptime_seconds` (integer): Seconds since startup

**Example Implementation (FastAPI):**
```python
from fastapi import FastAPI
from datetime import datetime

app = FastAPI()
startup_time = datetime.now()

@app.get("/api/health")
async def health_check():
    uptime = (datetime.now() - startup_time).total_seconds()
    return {
        "status": "healthy",
        "app_id": "my_app",
        "version": "1.0.0",
        "uptime_seconds": int(uptime)
    }
```

---

### 2. Domains List - `GET /api/domains`

**Purpose:** MDSA Dashboard aggregates domains from all registered apps.

**Response Format (LIST - Recommended):**
```json
{
  "domains": [
    {
      "domain_id": "investment_analysis",
      "name": "Investment Analysis",
      "description": "Analyzes investment opportunities",
      "model": "ollama://llama3.2:3b",
      "enabled": true
    },
    {
      "domain_id": "portfolio_management",
      "name": "Portfolio Management",
      "description": "Manages investment portfolios",
      "model": "ollama://mistral:7b",
      "enabled": true
    }
  ]
}
```

**Alternative Format (DICT - Also Supported):**
```json
{
  "domains": {
    "investment_analysis": {
      "name": "Investment Analysis",
      "model": "ollama://llama3.2:3b"
    },
    "portfolio_management": {
      "name": "Portfolio Management",
      "model": "ollama://mistral:7b"
    }
  }
}
```

**Required Fields per Domain:**
- `domain_id` (string): Unique identifier for the domain
- `name` (string): Human-readable display name
- `model` (string): Model identifier (e.g., `ollama://model:tag`)

**Optional Fields:**
- `description` (string): Domain description
- `enabled` (boolean): Whether domain is active
- `metadata` (object): Additional domain-specific data

**Example Implementation (FastAPI):**
```python
@app.get("/api/domains")
async def list_domains():
    return {
        "domains": [
            {
                "domain_id": "investment_analysis",
                "name": "Investment Analysis",
                "description": "AI-powered investment insights",
                "model": "ollama://llama3.2:3b",
                "enabled": True
            }
        ]
    }
```

---

### 3. Metrics - `GET /api/metrics`

**Purpose:** MDSA Dashboard displays aggregated metrics from all apps.

**Response Format:**
```json
{
  "timestamp": "2026-01-20T12:00:00Z",
  "domains": {
    "total": 3,
    "active": 2
  },
  "requests": {
    "total": 1500,
    "errors": 12,
    "average_latency_ms": 245
  },
  "rag": {
    "global_documents": 50,
    "local_documents": 125
  },
  "tools": {
    "count": 4,
    "active": 4
  }
}
```

**Required Fields:**
- `domains.total` (integer): Total number of domains

**Optional but Recommended:**
- `requests.total` (integer): Total requests processed
- `requests.errors` (integer): Total errors
- `rag.global_documents` (integer): Documents in global RAG
- `rag.local_documents` (integer): Documents in local RAG

**Example Implementation (FastAPI):**
```python
from datetime import datetime

# Track metrics in your app
metrics_store = {
    "requests_total": 0,
    "errors": 0,
    "domains_count": 3
}

@app.get("/api/metrics")
async def get_metrics():
    return {
        "timestamp": datetime.now().isoformat(),
        "domains": {
            "total": metrics_store["domains_count"],
            "active": metrics_store["domains_count"]
        },
        "requests": {
            "total": metrics_store["requests_total"],
            "errors": metrics_store["errors"]
        },
        "rag": {
            "global_documents": get_global_doc_count(),
            "local_documents": get_local_doc_count()
        }
    }
```

---

## Optional Endpoints

### 4. Tools - `GET /api/tools`

**Purpose:** MDSA Dashboard shows available tools from all apps.

**Response Format:**
```json
{
  "tools": [
    {
      "id": "market_data",
      "name": "Market Data Tool",
      "type": "api",
      "description": "Fetches real-time market data",
      "enabled": true
    },
    {
      "id": "portfolio_analyzer",
      "name": "Portfolio Analyzer",
      "type": "function",
      "description": "Analyzes portfolio performance",
      "enabled": true
    }
  ],
  "count": 2
}
```

**Required Fields per Tool:**
- `id` (string): Unique tool identifier
- `name` (string): Display name
- `type` (string): Tool type (`"api"`, `"function"`, `"agent"`)

**Optional Fields:**
- `description` (string): Tool description
- `enabled` (boolean): Whether tool is active
- `parameters` (object): Tool parameters schema

---

### 5. Models - `GET /api/models`

**Purpose:** MDSA Dashboard displays model configurations.

**Response Format:**
```json
{
  "models": [
    {
      "domain_name": "investment_analysis",
      "model_name": "ollama://llama3.2:3b",
      "status": "loaded"
    },
    {
      "domain_name": "portfolio_management",
      "model_name": "ollama://mistral:7b",
      "status": "loaded"
    }
  ]
}
```

---

## Complete Integration Example

Here's a complete example of a minimal MDSA-compatible FastAPI application:

```python
"""
Minimal MDSA-Compatible Application
"""
from fastapi import FastAPI
from datetime import datetime
from mdsa.core.app_registry import register_current_app

app = FastAPI(title="My MDSA App")

# Application state
startup_time = datetime.now()
metrics = {"requests": 0, "errors": 0}

# ============================================
# MDSA REQUIRED ENDPOINTS
# ============================================

@app.get("/api/health")
async def health():
    """Health check endpoint (REQUIRED)"""
    return {
        "status": "healthy",
        "app_id": "my_app",
        "version": "1.0.0",
        "uptime_seconds": int((datetime.now() - startup_time).total_seconds())
    }

@app.get("/api/domains")
async def domains():
    """List domains endpoint (REQUIRED)"""
    return {
        "domains": [
            {
                "domain_id": "general",
                "name": "General Assistant",
                "model": "ollama://llama3.2:3b",
                "enabled": True
            }
        ]
    }

@app.get("/api/metrics")
async def get_metrics():
    """Metrics endpoint (REQUIRED)"""
    return {
        "timestamp": datetime.now().isoformat(),
        "domains": {"total": 1, "active": 1},
        "requests": {"total": metrics["requests"], "errors": metrics["errors"]},
        "rag": {"global_documents": 0, "local_documents": 0}
    }

# ============================================
# MDSA OPTIONAL ENDPOINTS
# ============================================

@app.get("/api/tools")
async def tools():
    """List tools endpoint (OPTIONAL)"""
    return {"tools": [], "count": 0}

@app.get("/api/models")
async def models():
    """List models endpoint (OPTIONAL)"""
    return {
        "models": [
            {"domain_name": "general", "model_name": "ollama://llama3.2:3b"}
        ]
    }

# ============================================
# STARTUP: Register with MDSA
# ============================================

@app.on_event("startup")
async def register_with_mdsa():
    """Register this app with MDSA Dashboard"""
    try:
        register_current_app(
            app_id="my_app",
            app_name="My MDSA App",
            framework="fastapi",
            api_endpoint="http://localhost:8000"
        )
        print("✅ Registered with MDSA Dashboard")
    except Exception as e:
        print(f"⚠️ Could not register with MDSA: {e}")

# Run: uvicorn app:app --port 8000
```

---

## Validation

Use the MDSA validation tool to check if your app correctly implements the API contract:

```bash
python -m mdsa.tools.validate_app http://localhost:8000
```

**Expected Output:**
```
MDSA App Validation: http://localhost:8000
==================================================
✓ /api/health: PASS
✓ /api/domains: PASS
✓ /api/metrics: PASS
✓ /api/tools: PASS (optional)
✓ /api/models: PASS (optional)

Passed: 5, Failed: 0
```

---

## Troubleshooting

### App Not Appearing in Dashboard

1. **Check registration:**
   ```python
   from mdsa.core.app_registry import get_registry
   registry = get_registry()
   print(registry.list_apps())
   ```

2. **Check health endpoint:**
   ```bash
   curl http://localhost:8000/api/health
   ```

3. **Validate API contract:**
   ```bash
   python -m mdsa.tools.validate_app http://localhost:8000
   ```

### Domains Not Showing

1. Ensure `/api/domains` returns the correct format
2. Check that `domain_id` is unique across your app
3. Verify the response includes the `domains` key

### Metrics Showing Zero

1. Ensure `/api/metrics` returns the correct format
2. Include the `rag` key with `global_documents` and `local_documents`
3. Use integers, not strings, for numeric values

---

## Framework-Specific Examples

### Flask

```python
from flask import Flask, jsonify
from mdsa.core.app_registry import register_current_app

app = Flask(__name__)

@app.route('/api/health')
def health():
    return jsonify({"status": "healthy", "app_id": "flask_app"})

@app.route('/api/domains')
def domains():
    return jsonify({"domains": [{"domain_id": "general", "name": "General", "model": "ollama://llama3.2:3b"}]})

@app.route('/api/metrics')
def metrics():
    return jsonify({"domains": {"total": 1}, "requests": {"total": 0}, "rag": {"global_documents": 0, "local_documents": 0}})

if __name__ == '__main__':
    register_current_app("flask_app", "Flask App", "flask", "http://localhost:5001")
    app.run(port=5001)
```

### Django

```python
# views.py
from django.http import JsonResponse
from mdsa.core.app_registry import register_current_app

def health(request):
    return JsonResponse({"status": "healthy", "app_id": "django_app"})

def domains(request):
    return JsonResponse({"domains": [{"domain_id": "general", "name": "General", "model": "ollama://llama3.2:3b"}]})

def metrics(request):
    return JsonResponse({"domains": {"total": 1}, "requests": {"total": 0}, "rag": {"global_documents": 0, "local_documents": 0}})

# urls.py
urlpatterns = [
    path('api/health', views.health),
    path('api/domains', views.domains),
    path('api/metrics', views.metrics),
]

# Register on startup (apps.py)
register_current_app("django_app", "Django App", "django", "http://localhost:8001")
```

---

## Summary

| Endpoint | Required | Key Fields |
|----------|----------|------------|
| `GET /api/health` | YES | `status` |
| `GET /api/domains` | YES | `domains[]` with `domain_id`, `name`, `model` |
| `GET /api/metrics` | YES | `domains.total`, `rag.global_documents`, `rag.local_documents` |
| `GET /api/tools` | NO | `tools[]` with `id`, `name`, `type` |
| `GET /api/models` | NO | `models[]` with `domain_name`, `model_name` |

**Remember:** MDSA is framework-agnostic. Your app just needs to expose these REST endpoints, and MDSA will handle the rest!
