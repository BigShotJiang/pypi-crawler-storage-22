"""
MDSA Authentication Module

Provides authentication and authorization for MDSA Framework.

Legacy (jwt_auth):
- Basic JWT authentication (single admin user)
- For backward compatibility

Secure (secure_auth) - v2.0:
- bcrypt password hashing
- Database-backed user management
- Session tracking and revocation
- Secure secrets generation
"""

# Legacy authentication (backward compatible)
from .jwt_auth import (
    create_access_token,
    verify_token,
    authenticate_user,
    get_current_user_from_cookie,
    require_auth,
    require_admin,
    session_manager,
    hash_password,
    verify_password
)

# Secure authentication (v2.0)
from .secure_auth import (
    SecureSecrets,
    get_secrets,
    hash_password as secure_hash_password,
    verify_password as secure_verify_password,
    create_access_token as secure_create_token,
    verify_token as secure_verify_token,
    authenticate_user as secure_authenticate_user,
    create_user,
    change_password,
    create_session,
    revoke_session,
    is_session_valid,
    cleanup_expired_sessions,
    get_current_user
)

__all__ = [
    # Legacy (backward compatible)
    'create_access_token',
    'verify_token',
    'authenticate_user',
    'get_current_user_from_cookie',
    'require_auth',
    'require_admin',
    'session_manager',
    'hash_password',
    'verify_password',
    # Secure (v2.0)
    'SecureSecrets',
    'get_secrets',
    'secure_hash_password',
    'secure_verify_password',
    'secure_create_token',
    'secure_verify_token',
    'secure_authenticate_user',
    'create_user',
    'change_password',
    'create_session',
    'revoke_session',
    'is_session_valid',
    'cleanup_expired_sessions',
    'get_current_user'
]
