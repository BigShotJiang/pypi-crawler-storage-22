"""
MDSA Secure Authentication Module

Provides secure authentication with:
- bcrypt password hashing
- Database-backed user management
- JWT token generation with secure secrets
- Session tracking and revocation

Replaces the insecure plaintext password authentication.

Author: VICKY (Vicky Vignesh) + Claude Opus 4.5
Version: 2.0.0
"""

import os
import secrets
import hashlib
import logging
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, Tuple
from pathlib import Path
import json

try:
    import bcrypt
    BCRYPT_AVAILABLE = True
except ImportError:
    BCRYPT_AVAILABLE = False
    logging.warning("bcrypt not installed. Run: pip install bcrypt")

try:
    import jwt
    JWT_AVAILABLE = True
except ImportError:
    JWT_AVAILABLE = False
    logging.warning("PyJWT not installed. Run: pip install PyJWT")

from sqlalchemy.orm import Session

logger = logging.getLogger(__name__)


# ============================================
# SECURE SECRETS MANAGEMENT
# ============================================

class SecureSecrets:
    """
    Manages cryptographic secrets for MDSA.

    Secrets are generated once and stored in ~/.mdsa/secrets.json
    with secure file permissions.
    """

    def __init__(self, secrets_path: Optional[Path] = None):
        self.secrets_path = secrets_path or (Path.home() / ".mdsa" / "secrets.json")
        self._secrets: Dict[str, str] = {}
        self._load_or_generate()

    def _load_or_generate(self):
        """Load existing secrets or generate new ones"""
        if self.secrets_path.exists():
            try:
                with open(self.secrets_path, "r") as f:
                    self._secrets = json.load(f)
                logger.debug(f"Loaded secrets from {self.secrets_path}")
                return
            except (json.JSONDecodeError, IOError) as e:
                logger.warning(f"Could not load secrets: {e}")

        # Generate new secrets
        self._secrets = {
            "jwt_secret": secrets.token_hex(32),  # 64 characters
            "encryption_key": secrets.token_urlsafe(32),  # 32 bytes base64
            "api_key_salt": secrets.token_hex(16)  # 32 characters
        }

        # Save with secure permissions
        self.secrets_path.parent.mkdir(parents=True, exist_ok=True)
        with open(self.secrets_path, "w") as f:
            json.dump(self._secrets, f, indent=2)

        # Set file permissions (owner read/write only)
        try:
            os.chmod(self.secrets_path, 0o600)
        except OSError:
            pass  # Windows doesn't support chmod the same way

        logger.info(f"Generated new secrets at {self.secrets_path}")

    @property
    def jwt_secret(self) -> str:
        """Get JWT signing secret"""
        return self._secrets.get("jwt_secret", "")

    @property
    def encryption_key(self) -> str:
        """Get encryption key for API keys"""
        return self._secrets.get("encryption_key", "")

    @property
    def api_key_salt(self) -> str:
        """Get salt for API key hashing"""
        return self._secrets.get("api_key_salt", "")


# Global secrets instance
_secrets: Optional[SecureSecrets] = None


def get_secrets() -> SecureSecrets:
    """Get the global secrets instance"""
    global _secrets
    if _secrets is None:
        _secrets = SecureSecrets()
    return _secrets


# ============================================
# PASSWORD HASHING
# ============================================

def hash_password(password: str) -> str:
    """
    Hash a password using bcrypt.

    Args:
        password: Plain text password

    Returns:
        bcrypt hash string

    Raises:
        RuntimeError: If bcrypt is not available
    """
    if not BCRYPT_AVAILABLE:
        raise RuntimeError("bcrypt not installed. Run: pip install bcrypt")

    salt = bcrypt.gensalt(rounds=12)  # 12 rounds = ~250ms on modern hardware
    return bcrypt.hashpw(password.encode("utf-8"), salt).decode("utf-8")


def verify_password(password: str, password_hash: str) -> bool:
    """
    Verify a password against a bcrypt hash.

    Args:
        password: Plain text password to verify
        password_hash: bcrypt hash to check against

    Returns:
        True if password matches, False otherwise
    """
    if not BCRYPT_AVAILABLE:
        raise RuntimeError("bcrypt not installed. Run: pip install bcrypt")

    try:
        return bcrypt.checkpw(
            password.encode("utf-8"),
            password_hash.encode("utf-8")
        )
    except (ValueError, TypeError):
        return False


# ============================================
# JWT TOKEN MANAGEMENT
# ============================================

def create_access_token(
    user_id: int,
    username: str,
    role: str,
    expires_delta: Optional[timedelta] = None
) -> str:
    """
    Create a JWT access token.

    Args:
        user_id: User's database ID
        username: User's username
        role: User's role (admin, user, viewer)
        expires_delta: Token expiration time (default: 24 hours)

    Returns:
        Encoded JWT token string
    """
    if not JWT_AVAILABLE:
        raise RuntimeError("PyJWT not installed. Run: pip install PyJWT")

    if expires_delta is None:
        expires_delta = timedelta(hours=24)

    expire = datetime.utcnow() + expires_delta

    payload = {
        "sub": username,
        "user_id": user_id,
        "role": role,
        "exp": expire,
        "iat": datetime.utcnow(),
        "type": "access"
    }

    secret = get_secrets().jwt_secret
    return jwt.encode(payload, secret, algorithm="HS256")


def verify_token(token: str) -> Optional[Dict[str, Any]]:
    """
    Verify and decode a JWT token.

    Args:
        token: JWT token string

    Returns:
        Decoded payload dict if valid, None if invalid/expired
    """
    if not JWT_AVAILABLE:
        raise RuntimeError("PyJWT not installed. Run: pip install PyJWT")

    try:
        secret = get_secrets().jwt_secret
        payload = jwt.decode(token, secret, algorithms=["HS256"])
        return payload
    except jwt.ExpiredSignatureError:
        logger.debug("Token expired")
        return None
    except jwt.InvalidTokenError as e:
        logger.debug(f"Invalid token: {e}")
        return None


def get_token_hash(token: str) -> str:
    """
    Create a hash of a token for storage.

    Used for session tracking without storing the actual token.

    Args:
        token: JWT token string

    Returns:
        SHA256 hash of the token
    """
    return hashlib.sha256(token.encode()).hexdigest()


# ============================================
# USER AUTHENTICATION
# ============================================

def authenticate_user(
    username: str,
    password: str,
    db: Session
) -> Optional[Dict[str, Any]]:
    """
    Authenticate a user with username and password.

    Args:
        username: Username or email
        password: Plain text password
        db: Database session

    Returns:
        User dict if authenticated, None if failed
    """
    from mdsa.core.db.models import User

    # Find user by username or email
    user = db.query(User).filter(
        (User.username == username) | (User.email == username)
    ).first()

    if not user:
        logger.debug(f"User not found: {username}")
        return None

    if not user.is_active:
        logger.debug(f"User inactive: {username}")
        return None

    if not verify_password(password, user.password_hash):
        logger.debug(f"Invalid password for: {username}")
        return None

    # Update last login
    user.last_login = datetime.utcnow()
    db.commit()

    logger.info(f"User authenticated: {username}")
    return user.to_dict()


def create_user(
    username: str,
    email: str,
    password: str,
    role: str,
    db: Session
) -> Tuple[bool, str, Optional[Dict]]:
    """
    Create a new user.

    Args:
        username: Unique username
        email: Unique email address
        password: Plain text password (will be hashed)
        role: User role (admin, user, viewer)
        db: Database session

    Returns:
        Tuple of (success, message, user_dict)
    """
    from mdsa.core.db.models import User

    # Validate inputs
    if len(username) < 3:
        return False, "Username must be at least 3 characters", None

    if len(password) < 8:
        return False, "Password must be at least 8 characters", None

    if "@" not in email:
        return False, "Invalid email address", None

    # Check for existing user
    existing = db.query(User).filter(
        (User.username == username) | (User.email == email)
    ).first()

    if existing:
        if existing.username == username:
            return False, "Username already exists", None
        return False, "Email already registered", None

    # Create user
    user = User(
        username=username,
        email=email,
        password_hash=hash_password(password),
        role=role,
        is_active=True
    )

    db.add(user)
    db.commit()
    db.refresh(user)

    logger.info(f"User created: {username} ({role})")
    return True, "User created successfully", user.to_dict()


def change_password(
    user_id: int,
    old_password: str,
    new_password: str,
    db: Session
) -> Tuple[bool, str]:
    """
    Change a user's password.

    Args:
        user_id: User's database ID
        old_password: Current password
        new_password: New password
        db: Database session

    Returns:
        Tuple of (success, message)
    """
    from mdsa.core.db.models import User

    user = db.query(User).filter(User.id == user_id).first()

    if not user:
        return False, "User not found"

    if not verify_password(old_password, user.password_hash):
        return False, "Current password is incorrect"

    if len(new_password) < 8:
        return False, "New password must be at least 8 characters"

    user.password_hash = hash_password(new_password)
    user.updated_at = datetime.utcnow()
    db.commit()

    logger.info(f"Password changed for user: {user.username}")
    return True, "Password changed successfully"


# ============================================
# SESSION MANAGEMENT
# ============================================

def create_session(
    user_id: int,
    token: str,
    expires_at: datetime,
    ip_address: Optional[str],
    user_agent: Optional[str],
    db: Session
) -> int:
    """
    Create a new session record.

    Args:
        user_id: User's database ID
        token: JWT token (will be hashed)
        expires_at: Token expiration time
        ip_address: Client IP address
        user_agent: Client user agent
        db: Database session

    Returns:
        Session ID
    """
    from mdsa.core.db.models import Session as SessionModel

    session = SessionModel(
        user_id=user_id,
        token_hash=get_token_hash(token),
        expires_at=expires_at,
        ip_address=ip_address,
        user_agent=user_agent[:500] if user_agent else None
    )

    db.add(session)
    db.commit()
    db.refresh(session)

    return session.id


def revoke_session(token: str, db: Session) -> bool:
    """
    Revoke a session (logout).

    Args:
        token: JWT token to revoke
        db: Database session

    Returns:
        True if revoked, False if not found
    """
    from mdsa.core.db.models import Session as SessionModel

    token_hash = get_token_hash(token)
    session = db.query(SessionModel).filter(
        SessionModel.token_hash == token_hash
    ).first()

    if session:
        session.is_revoked = True
        db.commit()
        return True

    return False


def is_session_valid(token: str, db: Session) -> bool:
    """
    Check if a session is valid (not revoked).

    Args:
        token: JWT token to check
        db: Database session

    Returns:
        True if valid, False if revoked or not found
    """
    from mdsa.core.db.models import Session as SessionModel

    token_hash = get_token_hash(token)
    session = db.query(SessionModel).filter(
        SessionModel.token_hash == token_hash
    ).first()

    if session:
        return session.is_valid

    # If no session record, check token validity directly
    return verify_token(token) is not None


def cleanup_expired_sessions(db: Session) -> int:
    """
    Remove expired sessions from database.

    Args:
        db: Database session

    Returns:
        Number of sessions removed
    """
    from mdsa.core.db.models import Session as SessionModel

    result = db.query(SessionModel).filter(
        SessionModel.expires_at < datetime.utcnow()
    ).delete()

    db.commit()
    logger.info(f"Cleaned up {result} expired sessions")
    return result


# ============================================
# FASTAPI DEPENDENCIES
# ============================================

def get_current_user(
    token: str,
    db: Session
) -> Optional[Dict[str, Any]]:
    """
    Get the current user from a JWT token.

    For use as a FastAPI dependency.

    Args:
        token: JWT token from Authorization header
        db: Database session

    Returns:
        User dict if authenticated, None otherwise
    """
    from mdsa.core.db.models import User

    # Verify token
    payload = verify_token(token)
    if not payload:
        return None

    # Check session validity (if session tracking enabled)
    if not is_session_valid(token, db):
        return None

    # Get user
    user_id = payload.get("user_id")
    user = db.query(User).filter(User.id == user_id).first()

    if user and user.is_active:
        return user.to_dict()

    return None


def require_role(required_role: str):
    """
    Decorator factory to require a specific role.

    Usage:
        @app.get("/admin")
        @require_role("admin")
        def admin_only(user = Depends(get_current_user)):
            ...
    """
    def decorator(func):
        def wrapper(*args, **kwargs):
            user = kwargs.get("user")
            if not user or user.get("role") != required_role:
                from fastapi import HTTPException
                raise HTTPException(status_code=403, detail="Insufficient permissions")
            return func(*args, **kwargs)
        return wrapper
    return decorator
