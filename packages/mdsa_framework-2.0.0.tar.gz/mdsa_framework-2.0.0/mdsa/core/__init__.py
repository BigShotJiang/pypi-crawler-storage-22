"""
MDSA Core Orchestration Module

Contains the core orchestration engine, intent router, state machine,
message bus, configuration, exceptions, logging, rate limiting, and validation.

Version: 2.0.0
"""

from mdsa.core.orchestrator import TinyBERTOrchestrator
from mdsa.core.router import IntentRouter
from mdsa.core.state_machine import StateMachine, WorkflowState
from mdsa.core.communication_bus import MessageBus, Message, MessageType

# v2.0.0 modules
from mdsa.core.config import (
    MDSAConfig,
    get_config,
    reload_config,
    is_production,
    is_development,
    get_database_url,
    get_data_dir
)
from mdsa.core.exceptions import (
    MDSAError,
    AuthenticationError,
    AuthorizationError,
    AppError,
    AppNotFoundError,
    RAGError,
    ConfigurationError,
    RateLimitError
)
from mdsa.core.logging_config import (
    setup_logging,
    get_logger,
    LogContext,
    set_request_id
)
from mdsa.core.rate_limit import (
    RateLimiter,
    rate_limit_sync,
    rate_limit_async
)
from mdsa.core.validation import (
    LoginRequest,
    AppRegistration,
    QueryRequest,
    DocumentUpload
)

__all__ = [
    # Orchestration
    "TinyBERTOrchestrator",
    # Intent Routing
    "IntentRouter",
    # State Management
    "StateMachine",
    "WorkflowState",
    # Communication
    "MessageBus",
    "Message",
    "MessageType",
    # Configuration (v2.0)
    "MDSAConfig",
    "get_config",
    "reload_config",
    "is_production",
    "is_development",
    "get_database_url",
    "get_data_dir",
    # Exceptions (v2.0)
    "MDSAError",
    "AuthenticationError",
    "AuthorizationError",
    "AppError",
    "AppNotFoundError",
    "RAGError",
    "ConfigurationError",
    "RateLimitError",
    # Logging (v2.0)
    "setup_logging",
    "get_logger",
    "LogContext",
    "set_request_id",
    # Rate Limiting (v2.0)
    "RateLimiter",
    "rate_limit_sync",
    "rate_limit_async",
    # Validation (v2.0)
    "LoginRequest",
    "AppRegistration",
    "QueryRequest",
    "DocumentUpload",
]
