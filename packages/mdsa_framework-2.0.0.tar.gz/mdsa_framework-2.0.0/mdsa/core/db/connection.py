"""
MDSA Database Connection Management

Provides database engine, session management, and initialization.

Supports:
- PostgreSQL (production, with pgvector for embeddings)
- SQLite (development, single-file database)

Author: VICKY (Vicky Vignesh) + Claude Opus 4.5
Version: 2.0.0
"""

import os
import logging
from pathlib import Path
from typing import Generator, Optional
from contextlib import contextmanager

from sqlalchemy import create_engine, event, text
from sqlalchemy.orm import sessionmaker, Session as SQLAlchemySession
from sqlalchemy.pool import StaticPool

from mdsa.core.db.models import Base

logger = logging.getLogger(__name__)

# Global engine and session factory
_engine = None
_SessionLocal = None


def get_database_url() -> str:
    """
    Get database URL from environment or use default SQLite.

    Environment Variables:
        MDSA_DATABASE_URL: Full database URL
        MDSA_DATABASE_TYPE: 'postgresql' or 'sqlite' (default: sqlite)
        MDSA_DATABASE_HOST: PostgreSQL host (default: localhost)
        MDSA_DATABASE_PORT: PostgreSQL port (default: 5432)
        MDSA_DATABASE_NAME: Database name (default: mdsa)
        MDSA_DATABASE_USER: PostgreSQL user
        MDSA_DATABASE_PASSWORD: PostgreSQL password

    Returns:
        Database connection URL
    """
    # Check for explicit URL first
    explicit_url = os.getenv("MDSA_DATABASE_URL")
    if explicit_url:
        return explicit_url

    # Determine database type
    db_type = os.getenv("MDSA_DATABASE_TYPE", "sqlite").lower()

    if db_type == "postgresql":
        host = os.getenv("MDSA_DATABASE_HOST", "localhost")
        port = os.getenv("MDSA_DATABASE_PORT", "5432")
        name = os.getenv("MDSA_DATABASE_NAME", "mdsa")
        user = os.getenv("MDSA_DATABASE_USER", "postgres")
        password = os.getenv("MDSA_DATABASE_PASSWORD", "")

        if password:
            return f"postgresql://{user}:{password}@{host}:{port}/{name}"
        return f"postgresql://{user}@{host}:{port}/{name}"

    # Default: SQLite in user's MDSA directory
    mdsa_dir = Path.home() / ".mdsa"
    mdsa_dir.mkdir(parents=True, exist_ok=True)
    db_path = mdsa_dir / "mdsa.db"

    return f"sqlite:///{db_path}"


def get_engine(database_url: Optional[str] = None):
    """
    Get or create the database engine.

    Args:
        database_url: Optional explicit database URL

    Returns:
        SQLAlchemy Engine instance
    """
    global _engine

    if _engine is None:
        url = database_url or get_database_url()

        # Configure based on database type
        if url.startswith("sqlite"):
            # SQLite configuration
            _engine = create_engine(
                url,
                connect_args={"check_same_thread": False},
                poolclass=StaticPool,
                echo=os.getenv("MDSA_DATABASE_ECHO", "false").lower() == "true"
            )

            # Enable foreign keys for SQLite
            @event.listens_for(_engine, "connect")
            def set_sqlite_pragma(dbapi_connection, connection_record):
                cursor = dbapi_connection.cursor()
                cursor.execute("PRAGMA foreign_keys=ON")
                cursor.close()

            logger.info(f"SQLite database initialized: {url}")

        else:
            # PostgreSQL configuration
            _engine = create_engine(
                url,
                pool_size=5,
                max_overflow=10,
                pool_pre_ping=True,
                echo=os.getenv("MDSA_DATABASE_ECHO", "false").lower() == "true"
            )
            logger.info(f"PostgreSQL database connected: {url.split('@')[-1]}")

    return _engine


def get_session_factory():
    """
    Get or create the session factory.

    Returns:
        SQLAlchemy sessionmaker instance
    """
    global _SessionLocal

    if _SessionLocal is None:
        engine = get_engine()
        _SessionLocal = sessionmaker(
            autocommit=False,
            autoflush=False,
            bind=engine
        )

    return _SessionLocal


def get_session() -> SQLAlchemySession:
    """
    Create a new database session.

    Returns:
        New SQLAlchemy Session instance
    """
    SessionLocal = get_session_factory()
    return SessionLocal()


@contextmanager
def DatabaseSession() -> Generator[SQLAlchemySession, None, None]:
    """
    Context manager for database sessions.

    Automatically commits on success and rolls back on exception.

    Usage:
        with DatabaseSession() as db:
            user = db.query(User).first()
            db.add(new_user)
            # Commits automatically on exit

    Yields:
        SQLAlchemy Session instance
    """
    session = get_session()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()


def get_db() -> Generator[SQLAlchemySession, None, None]:
    """
    FastAPI dependency for database sessions.

    Usage:
        @app.get("/users")
        def list_users(db: Session = Depends(get_db)):
            return db.query(User).all()

    Yields:
        SQLAlchemy Session instance
    """
    db = get_session()
    try:
        yield db
    finally:
        db.close()


def init_db(drop_all: bool = False):
    """
    Initialize the database schema.

    Creates all tables defined in models.py.
    Optionally drops existing tables first (for testing).

    Args:
        drop_all: If True, drop all tables before creating (DANGER!)
    """
    engine = get_engine()

    if drop_all:
        logger.warning("Dropping all database tables!")
        Base.metadata.drop_all(bind=engine)

    Base.metadata.create_all(bind=engine)
    logger.info("Database schema initialized")

    # Check if PostgreSQL and pgvector extension needed
    if "postgresql" in str(engine.url):
        try:
            with engine.connect() as conn:
                conn.execute(text("CREATE EXTENSION IF NOT EXISTS vector"))
                conn.commit()
                logger.info("pgvector extension enabled")
        except Exception as e:
            logger.warning(f"Could not enable pgvector extension: {e}")


def check_database_connection() -> bool:
    """
    Check if database connection is working.

    Returns:
        True if connection successful, False otherwise
    """
    try:
        engine = get_engine()
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        return True
    except Exception as e:
        logger.error(f"Database connection failed: {e}")
        return False


def get_database_info() -> dict:
    """
    Get information about the current database connection.

    Returns:
        Dictionary with database info
    """
    engine = get_engine()
    url = str(engine.url)

    # Mask password in URL
    if "@" in url:
        parts = url.split("@")
        if ":" in parts[0]:
            protocol_user = parts[0].rsplit(":", 1)[0]
            url = f"{protocol_user}:****@{parts[1]}"

    return {
        "url": url,
        "dialect": engine.dialect.name,
        "driver": engine.dialect.driver,
        "connected": check_database_connection()
    }


# Convenience function to reset database (for testing)
def reset_database():
    """
    Reset the database by dropping and recreating all tables.

    WARNING: This deletes all data!
    """
    logger.warning("Resetting database - all data will be lost!")
    init_db(drop_all=True)


# Initialize default admin user if database is empty
def ensure_admin_user(
    username: str = "admin",
    email: str = "admin@mdsa.local",
    password: str = None
) -> bool:
    """
    Ensure an admin user exists in the database.

    Creates a default admin user if no users exist.
    Password should be changed after first login.

    Args:
        username: Admin username
        email: Admin email
        password: Admin password (generates random if not provided)

    Returns:
        True if admin created, False if already exists
    """
    from mdsa.core.db.models import User

    with DatabaseSession() as db:
        # Check if any users exist
        user_count = db.query(User).count()

        if user_count > 0:
            logger.debug("Users already exist, skipping admin creation")
            return False

        # Generate random password if not provided
        if password is None:
            import secrets
            password = secrets.token_urlsafe(16)
            logger.warning(f"Generated random admin password: {password}")
            logger.warning("Please change this password immediately!")

        # Hash password
        try:
            import bcrypt
            password_hash = bcrypt.hashpw(
                password.encode(),
                bcrypt.gensalt(rounds=12)
            ).decode()
        except ImportError:
            logger.error("bcrypt not installed. Run: pip install bcrypt")
            return False

        # Create admin user
        admin = User(
            username=username,
            email=email,
            password_hash=password_hash,
            role="admin",
            is_active=True
        )

        db.add(admin)
        logger.info(f"Created admin user: {username}")
        return True
