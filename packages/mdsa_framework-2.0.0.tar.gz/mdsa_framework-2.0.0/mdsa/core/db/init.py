"""Database initialization utilities for MDSA v2.0.0

This module provides utilities for initializing the database schema,
creating default users, and managing database sessions.
"""

import os
import logging
from pathlib import Path
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, Session
from typing import Generator

from mdsa.core.db.models import Base, User
from mdsa.auth.secure_auth import hash_password
from mdsa.core.config import get_config

logger = logging.getLogger(__name__)


def init_database():
    """Initialize database schema.

    Creates all tables defined in the ORM models.

    Returns:
        Engine: SQLAlchemy engine instance
    """
    config = get_config()
    db_url = config.database.get_url()

    # Create engine with appropriate settings
    if db_url.startswith('sqlite'):
        # SQLite specific settings
        engine = create_engine(
            db_url,
            echo=config.database.echo,
            connect_args={"check_same_thread": False}
        )
    else:
        # PostgreSQL settings
        engine = create_engine(
            db_url,
            echo=config.database.echo,
            pool_size=config.database.pool_size,
            max_overflow=config.database.max_overflow
        )

    # Create all tables
    Base.metadata.create_all(engine)

    logger.info(f"Database initialized: {db_url}")
    return engine


def create_default_admin(engine):
    """Create default admin user if none exists.

    Credentials are loaded from environment variables:
    - MDSA_ADMIN_USERNAME (default: 'admin')
    - MDSA_ADMIN_PASSWORD (required)

    Args:
        engine: SQLAlchemy engine instance

    Raises:
        RuntimeError: If MDSA_ADMIN_PASSWORD is not set
    """
    SessionLocal = sessionmaker(bind=engine)
    db = SessionLocal()

    try:
        # Check if admin exists
        admin = db.query(User).filter(User.role == 'admin').first()
        if admin:
            logger.info("Admin user already exists")
            return

        # Get credentials from environment
        username = os.getenv('MDSA_ADMIN_USERNAME', 'admin')
        password = os.getenv('MDSA_ADMIN_PASSWORD')

        if not password:
            raise RuntimeError(
                "MDSA_ADMIN_PASSWORD not set. Cannot create admin user. "
                "Please set MDSA_ADMIN_PASSWORD environment variable."
            )

        # Create admin user
        admin = User(
            username=username,
            email=f"{username}@mdsa.local",
            password_hash=hash_password(password),
            role='admin',
            is_active=True
        )

        db.add(admin)
        db.commit()
        logger.info(f"Admin user created: {username}")

    except Exception as e:
        db.rollback()
        logger.error(f"Failed to create admin user: {e}")
        raise
    finally:
        db.close()


def get_db_session() -> Generator[Session, None, None]:
    """FastAPI dependency for database sessions.

    Yields database session with automatic cleanup.

    Usage:
        @app.get("/endpoint")
        async def endpoint(db: Session = Depends(get_db_session)):
            # Use db session
            pass

    Yields:
        Session: SQLAlchemy session
    """
    from mdsa.core.db.connection import SessionLocal

    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def check_database_health(engine) -> bool:
    """Check if database connection is healthy.

    Args:
        engine: SQLAlchemy engine instance

    Returns:
        bool: True if database is accessible, False otherwise
    """
    try:
        with engine.connect() as conn:
            conn.execute("SELECT 1")
        return True
    except Exception as e:
        logger.error(f"Database health check failed: {e}")
        return False


def get_or_create_engine():
    """Get existing engine or create new one.

    Singleton pattern for database engine.

    Returns:
        Engine: SQLAlchemy engine instance
    """
    global _engine

    if '_engine' not in globals() or _engine is None:
        _engine = init_database()

    return _engine


# Global engine instance (initialized lazily)
_engine = None
