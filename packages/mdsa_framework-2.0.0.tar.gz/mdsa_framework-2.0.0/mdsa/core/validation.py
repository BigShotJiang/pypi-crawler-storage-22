"""
MDSA Input Validation Module

Pydantic models for validating API inputs.

Prevents:
- XSS attacks (HTML sanitization)
- SQL injection (via ORM, but validated here too)
- Invalid URLs (malformed app registrations)
- Invalid data types

Compatible with Pydantic v2.

Author: VICKY (Vicky Vignesh) + Claude Opus 4.5
Version: 2.0.0
"""

import re
import html
from typing import Optional, List, Dict, Any
from datetime import datetime
from enum import Enum

from pydantic import (
    BaseModel,
    Field,
    field_validator,
    model_validator,
    ConfigDict,
    HttpUrl,
    EmailStr,
)
from typing_extensions import Annotated
from pydantic.functional_validators import AfterValidator


# ============================================
# ENUMS
# ============================================

class UserRole(str, Enum):
    """Valid user roles"""
    ADMIN = "admin"
    USER = "user"
    VIEWER = "viewer"


class AppFramework(str, Enum):
    """Supported application frameworks"""
    FASTAPI = "fastapi"
    FLASK = "flask"
    DJANGO = "django"
    EXPRESS = "express"
    OTHER = "other"


class HealthStatus(str, Enum):
    """App health status values"""
    HEALTHY = "healthy"
    UNHEALTHY = "unhealthy"
    UNKNOWN = "unknown"


# ============================================
# VALIDATORS
# ============================================

def sanitize_html(value: str) -> str:
    """
    Sanitize string to prevent XSS attacks.

    Escapes HTML special characters.
    """
    if value is None:
        return value
    return html.escape(str(value))


def validate_app_id(value: str) -> str:
    """
    Validate app_id format.

    Must be lowercase alphanumeric with underscores/hyphens.
    """
    if not re.match(r'^[a-z0-9_-]+$', value):
        raise ValueError(
            'app_id must be lowercase alphanumeric with underscores/hyphens only'
        )
    if len(value) < 2 or len(value) > 50:
        raise ValueError('app_id must be 2-50 characters')
    return value


def validate_username(value: str) -> str:
    """
    Validate username format.

    Must be alphanumeric with underscores.
    """
    if not re.match(r'^[a-zA-Z0-9_]+$', value):
        raise ValueError(
            'username must be alphanumeric with underscores only'
        )
    if len(value) < 3 or len(value) > 50:
        raise ValueError('username must be 3-50 characters')
    return value


def validate_password_strength(value: str) -> str:
    """
    Validate password strength.

    Requirements:
    - At least 8 characters
    - Contains letter and number
    """
    if len(value) < 8:
        raise ValueError('password must be at least 8 characters')
    if not re.search(r'[a-zA-Z]', value):
        raise ValueError('password must contain at least one letter')
    if not re.search(r'[0-9]', value):
        raise ValueError('password must contain at least one number')
    return value


# ============================================
# AUTHENTICATION MODELS
# ============================================

class LoginRequest(BaseModel):
    """Login request validation"""
    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "username": "admin",
                "password": "secure_password_123"
            }
        }
    )

    username: str = Field(min_length=3, max_length=50)
    password: str = Field(min_length=8, max_length=128)

    @field_validator('username')
    @classmethod
    def validate_username_format(cls, v: str) -> str:
        return validate_username(v)


class RegisterRequest(BaseModel):
    """User registration request validation"""
    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "username": "newuser",
                "email": "user@example.com",
                "password": "secure_password_123",
                "role": "user"
            }
        }
    )

    username: str = Field(min_length=3, max_length=50)
    email: EmailStr
    password: str = Field(min_length=8, max_length=128)
    role: UserRole = UserRole.USER

    @field_validator('username')
    @classmethod
    def validate_username_format(cls, v: str) -> str:
        return validate_username(v)

    @field_validator('password')
    @classmethod
    def validate_password_format(cls, v: str) -> str:
        return validate_password_strength(v)


class ChangePasswordRequest(BaseModel):
    """Password change request validation"""
    old_password: str = Field(min_length=8, max_length=128)
    new_password: str = Field(min_length=8, max_length=128)

    @field_validator('new_password')
    @classmethod
    def validate_new_password(cls, v: str) -> str:
        return validate_password_strength(v)

    @model_validator(mode='after')
    def check_passwords_different(self):
        if self.old_password == self.new_password:
            raise ValueError('new password must be different from old password')
        return self


class TokenResponse(BaseModel):
    """Token response model"""
    access_token: str
    token_type: str = "bearer"
    expires_in: int = 86400  # 24 hours
    user: Dict[str, Any]


# ============================================
# APP REGISTRATION MODELS
# ============================================

class AppRegistration(BaseModel):
    """Application registration request validation"""
    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "app_id": "investment_platform",
                "app_name": "Investment Advisory Platform",
                "framework": "fastapi",
                "api_endpoint": "http://localhost:8000"
            }
        }
    )

    app_id: str = Field(min_length=2, max_length=50)
    app_name: str = Field(min_length=1, max_length=255)
    framework: AppFramework = AppFramework.OTHER
    api_endpoint: HttpUrl
    health_endpoint: Optional[HttpUrl] = None
    metrics_endpoint: Optional[HttpUrl] = None
    metadata: Optional[Dict[str, Any]] = None

    @field_validator('app_id')
    @classmethod
    def validate_app_id_format(cls, v: str) -> str:
        return validate_app_id(v)

    @field_validator('app_name')
    @classmethod
    def sanitize_app_name(cls, v: str) -> str:
        return sanitize_html(v)

    @model_validator(mode='after')
    def set_default_endpoints(self):
        """Set default health/metrics endpoints if not provided"""
        endpoint_str = str(self.api_endpoint).rstrip('/')
        if not self.health_endpoint:
            self.health_endpoint = f"{endpoint_str}/api/health"
        if not self.metrics_endpoint:
            self.metrics_endpoint = f"{endpoint_str}/api/metrics"
        return self


class AppUpdate(BaseModel):
    """Application update request validation"""
    app_name: Optional[str] = Field(default=None, min_length=1, max_length=255)
    api_endpoint: Optional[HttpUrl] = None
    health_endpoint: Optional[HttpUrl] = None
    metrics_endpoint: Optional[HttpUrl] = None
    is_active: Optional[bool] = None
    metadata: Optional[Dict[str, Any]] = None

    @field_validator('app_name')
    @classmethod
    def sanitize_app_name(cls, v: Optional[str]) -> Optional[str]:
        if v:
            return sanitize_html(v)
        return v


# ============================================
# DOMAIN MODELS
# ============================================

class DomainConfig(BaseModel):
    """Domain configuration validation"""
    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "domain_id": "investment_analysis",
                "name": "Investment Analysis",
                "model": "ollama://llama3.2:3b",
                "enabled": True
            }
        }
    )

    domain_id: str = Field(min_length=2, max_length=100)
    name: str = Field(min_length=1, max_length=255)
    description: Optional[str] = None
    model: str = Field(min_length=1, max_length=255)
    enabled: bool = True
    metadata: Optional[Dict[str, Any]] = None

    @field_validator('domain_id')
    @classmethod
    def validate_domain_id(cls, v: str) -> str:
        if not re.match(r'^[a-z0-9_-]+$', v):
            raise ValueError('domain_id must be lowercase alphanumeric')
        return v

    @field_validator('name', 'description')
    @classmethod
    def sanitize_text(cls, v: Optional[str]) -> Optional[str]:
        if v:
            return sanitize_html(v)
        return v


# ============================================
# QUERY MODELS
# ============================================

class QueryRequest(BaseModel):
    """Query request validation"""
    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "query": "What are the best investment strategies for 2026?",
                "domain": "investment_analysis",
                "max_tokens": 1024
            }
        }
    )

    query: str = Field(min_length=1, max_length=10000)
    domain: Optional[str] = None
    context: Optional[Dict[str, Any]] = None
    max_tokens: Optional[int] = Field(default=None, ge=1, le=4096)
    temperature: Optional[float] = Field(default=None, ge=0.0, le=2.0)

    @field_validator('query')
    @classmethod
    def sanitize_query(cls, v: str) -> str:
        # Don't fully sanitize queries as they may need special chars
        # But do prevent obvious attacks
        if '<script' in v.lower():
            raise ValueError('Invalid query content')
        return v.strip()


class QueryResponse(BaseModel):
    """Query response model"""
    response: str
    domain: Optional[str] = None
    model: Optional[str] = None
    tokens_used: Optional[int] = None
    latency_ms: Optional[int] = None
    sources: Optional[List[Dict[str, Any]]] = None
    timestamp: datetime = Field(default_factory=datetime.utcnow)


# ============================================
# RAG MODELS
# ============================================

class DocumentUpload(BaseModel):
    """Document upload validation"""
    title: Optional[str] = Field(default=None, max_length=500)
    domain: Optional[str] = Field(default=None, max_length=100)
    metadata: Optional[Dict[str, Any]] = None

    @field_validator('title')
    @classmethod
    def sanitize_title(cls, v: Optional[str]) -> Optional[str]:
        if v:
            return sanitize_html(v)
        return v


class DocumentResponse(BaseModel):
    """Document response model"""
    id: int
    title: Optional[str]
    domain: Optional[str]
    doc_type: Optional[str]
    created_at: datetime


class RAGQueryRequest(BaseModel):
    """RAG query request validation"""
    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "query": "What are the ICD-10 codes for diabetes?",
                "k": 5,
                "domain": "medical_coding"
            }
        }
    )

    query: str = Field(min_length=1, max_length=5000)
    k: int = Field(default=5, ge=1, le=20)
    domain: Optional[str] = None
    threshold: Optional[float] = Field(default=None, ge=0.0, le=1.0)


# ============================================
# METRICS MODELS
# ============================================

class MetricsResponse(BaseModel):
    """Metrics response model"""
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    domains: Dict[str, Any]
    requests: Dict[str, Any]
    rag: Dict[str, Any]
    tools: Optional[Dict[str, Any]] = None


class HealthResponse(BaseModel):
    """Health check response model"""
    status: HealthStatus
    app_id: Optional[str] = None
    version: Optional[str] = None
    uptime_seconds: Optional[int] = None
    timestamp: datetime = Field(default_factory=datetime.utcnow)


# ============================================
# ERROR MODELS
# ============================================

class ErrorResponse(BaseModel):
    """Standard error response model"""
    error: str
    message: str
    detail: Optional[Any] = None
    timestamp: datetime = Field(default_factory=datetime.utcnow)


class ValidationErrorResponse(BaseModel):
    """Validation error response model"""
    error: str = "validation_error"
    message: str = "Request validation failed"
    errors: List[Dict[str, Any]]
    timestamp: datetime = Field(default_factory=datetime.utcnow)


# ============================================
# UTILITY FUNCTIONS
# ============================================

def create_error_response(
    error: str,
    message: str,
    detail: Any = None
) -> Dict[str, Any]:
    """Create standardized error response"""
    return ErrorResponse(
        error=error,
        message=message,
        detail=detail
    ).model_dump()


def validate_request(model_class: type, data: Dict[str, Any]) -> BaseModel:
    """
    Validate request data against a Pydantic model.

    Args:
        model_class: Pydantic model class
        data: Request data dict

    Returns:
        Validated model instance

    Raises:
        ValueError: If validation fails
    """
    try:
        return model_class(**data)
    except Exception as e:
        raise ValueError(f"Validation error: {str(e)}")


# ============================================
# EXPORTS
# ============================================

__all__ = [
    # Enums
    "UserRole",
    "AppFramework",
    "HealthStatus",
    # Validators
    "sanitize_html",
    "validate_app_id",
    "validate_username",
    "validate_password_strength",
    # Auth models
    "LoginRequest",
    "RegisterRequest",
    "ChangePasswordRequest",
    "TokenResponse",
    # App models
    "AppRegistration",
    "AppUpdate",
    # Domain models
    "DomainConfig",
    # Query models
    "QueryRequest",
    "QueryResponse",
    # RAG models
    "DocumentUpload",
    "DocumentResponse",
    "RAGQueryRequest",
    # Metrics models
    "MetricsResponse",
    "HealthResponse",
    # Error models
    "ErrorResponse",
    "ValidationErrorResponse",
    # Utilities
    "create_error_response",
    "validate_request",
]
