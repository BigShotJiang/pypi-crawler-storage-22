"""
MDSA Unified RAG System

Replaces the broken Dual RAG with a single, unified system.

Features:
- Single vector store for ALL documents (dashboard + apps)
- Database persistence (documents survive restarts)
- FAISS index with disk persistence
- Supports both global and domain-specific retrieval

Fixes the critical bug where:
- Documents uploaded via dashboard were not searchable by orchestrator
- RAG metrics always showed 0

Author: VICKY (Vicky Vignesh) + Claude Opus 4.5
Version: 2.0.0
"""

import os
import logging
import hashlib
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple
from datetime import datetime

logger = logging.getLogger(__name__)

# Try to import required packages
try:
    from sentence_transformers import SentenceTransformer
    SENTENCE_TRANSFORMERS_AVAILABLE = True
except ImportError:
    SENTENCE_TRANSFORMERS_AVAILABLE = False
    logger.warning("sentence-transformers not installed")

try:
    import faiss
    import numpy as np
    FAISS_AVAILABLE = True
except ImportError:
    FAISS_AVAILABLE = False
    logger.warning("faiss not installed")


# ============================================
# CONFIGURATION
# ============================================

class RAGConfig:
    """RAG configuration from environment"""

    # Embedding model
    EMBEDDING_MODEL = os.getenv(
        "MDSA_RAG_EMBEDDING_MODEL",
        "sentence-transformers/all-MiniLM-L6-v2"
    )
    EMBEDDING_DIMENSION = int(os.getenv("MDSA_RAG_EMBEDDING_DIM", "384"))

    # Search defaults
    DEFAULT_K = int(os.getenv("MDSA_RAG_DEFAULT_K", "5"))
    DEFAULT_THRESHOLD = float(os.getenv("MDSA_RAG_THRESHOLD", "0.5"))

    # Storage paths
    INDEX_DIR = Path(os.getenv(
        "MDSA_RAG_INDEX_DIR",
        str(Path.home() / ".mdsa" / "rag")
    ))

    # Chunking
    CHUNK_SIZE = int(os.getenv("MDSA_RAG_CHUNK_SIZE", "1000"))
    CHUNK_OVERLAP = int(os.getenv("MDSA_RAG_CHUNK_OVERLAP", "200"))


# ============================================
# DOCUMENT CLASS
# ============================================

class RAGDocument:
    """Represents a document in the RAG system"""

    def __init__(
        self,
        content: str,
        metadata: Optional[Dict[str, Any]] = None,
        doc_id: Optional[int] = None,
        embedding: Optional[List[float]] = None
    ):
        self.content = content
        self.metadata = metadata or {}
        self.doc_id = doc_id
        self.embedding = embedding
        self.content_hash = hashlib.sha256(content.encode()).hexdigest()[:16]

    @property
    def domain(self) -> Optional[str]:
        return self.metadata.get("domain")

    @property
    def source(self) -> Optional[str]:
        return self.metadata.get("source")

    @property
    def title(self) -> Optional[str]:
        return self.metadata.get("title")

    def to_dict(self) -> Dict[str, Any]:
        return {
            "doc_id": self.doc_id,
            "content": self.content[:200] + "..." if len(self.content) > 200 else self.content,
            "metadata": self.metadata,
            "content_hash": self.content_hash
        }


# ============================================
# UNIFIED RAG CLASS
# ============================================

class UnifiedRAG:
    """
    Unified RAG system that replaces the broken Dual RAG.

    Key improvements:
    1. SINGLE vector store for all documents
    2. Database persistence via SQLAlchemy
    3. FAISS index saved to disk
    4. Domain filtering without separate stores
    """

    def __init__(
        self,
        db_session=None,
        embedding_model: str = None,
        index_path: Path = None
    ):
        """
        Initialize the Unified RAG system.

        Args:
            db_session: SQLAlchemy session (optional, for persistence)
            embedding_model: HuggingFace model name for embeddings
            index_path: Path to save/load FAISS index
        """
        self.db = db_session
        self.model_name = embedding_model or RAGConfig.EMBEDDING_MODEL
        self.index_path = index_path or RAGConfig.INDEX_DIR / "faiss_index"

        # Initialize embeddings model
        self._embeddings = None
        self._load_embeddings_model()

        # Initialize FAISS index
        self.index = None
        self.documents: List[RAGDocument] = []
        self._doc_id_map: Dict[int, int] = {}  # faiss_idx -> doc_id

        # Load existing index if available
        self._load_index()

        logger.info(f"UnifiedRAG initialized with {len(self.documents)} documents")

    def _load_embeddings_model(self):
        """Load the sentence transformer model"""
        if not SENTENCE_TRANSFORMERS_AVAILABLE:
            logger.warning("sentence-transformers not available, using mock embeddings")
            return

        try:
            self._embeddings = SentenceTransformer(self.model_name)
            logger.info(f"Loaded embedding model: {self.model_name}")
        except Exception as e:
            logger.error(f"Failed to load embedding model: {e}")

    def _get_embedding(self, text: str) -> List[float]:
        """Generate embedding for text"""
        if self._embeddings is None:
            # Return mock embedding if model not available
            return [0.0] * RAGConfig.EMBEDDING_DIMENSION

        try:
            embedding = self._embeddings.encode(text, convert_to_numpy=True)
            return embedding.tolist()
        except Exception as e:
            logger.error(f"Embedding generation failed: {e}")
            return [0.0] * RAGConfig.EMBEDDING_DIMENSION

    def _load_index(self):
        """Load FAISS index from disk"""
        if not FAISS_AVAILABLE:
            logger.warning("FAISS not available")
            return

        index_file = Path(f"{self.index_path}.faiss")
        docs_file = Path(f"{self.index_path}.docs")

        if index_file.exists() and docs_file.exists():
            try:
                self.index = faiss.read_index(str(index_file))

                import pickle
                with open(docs_file, 'rb') as f:
                    data = pickle.load(f)
                    self.documents = data.get('documents', [])
                    self._doc_id_map = data.get('doc_id_map', {})

                logger.info(f"Loaded {len(self.documents)} documents from disk")
            except Exception as e:
                logger.error(f"Failed to load index: {e}")
                self._create_empty_index()
        else:
            self._create_empty_index()

    def _create_empty_index(self):
        """Create an empty FAISS index"""
        if FAISS_AVAILABLE:
            self.index = faiss.IndexFlatIP(RAGConfig.EMBEDDING_DIMENSION)
            self.documents = []
            self._doc_id_map = {}

    def _save_index(self):
        """Save FAISS index to disk"""
        if not FAISS_AVAILABLE or self.index is None:
            return

        try:
            # Ensure directory exists
            self.index_path.parent.mkdir(parents=True, exist_ok=True)

            # Save FAISS index
            faiss.write_index(self.index, f"{self.index_path}.faiss")

            # Save documents and mapping
            import pickle
            with open(f"{self.index_path}.docs", 'wb') as f:
                pickle.dump({
                    'documents': self.documents,
                    'doc_id_map': self._doc_id_map
                }, f)

            logger.debug(f"Saved index with {len(self.documents)} documents")
        except Exception as e:
            logger.error(f"Failed to save index: {e}")

    def add_document(
        self,
        content: str,
        metadata: Optional[Dict[str, Any]] = None,
        user_id: Optional[int] = None,
        save: bool = True
    ) -> int:
        """
        Add a document to the RAG system.

        Args:
            content: Document text content
            metadata: Document metadata (title, domain, source, etc.)
            user_id: ID of user who uploaded
            save: Whether to save to disk immediately

        Returns:
            Document ID
        """
        metadata = metadata or {}

        # Generate embedding
        embedding = self._get_embedding(content)

        # Create document
        doc_id = len(self.documents) + 1
        doc = RAGDocument(
            content=content,
            metadata={
                **metadata,
                "uploaded_by": user_id,
                "uploaded_at": datetime.utcnow().isoformat()
            },
            doc_id=doc_id,
            embedding=embedding
        )

        # Add to FAISS index
        if FAISS_AVAILABLE and self.index is not None:
            embedding_array = np.array([embedding], dtype=np.float32)
            faiss.normalize_L2(embedding_array)  # Normalize for cosine similarity
            self.index.add(embedding_array)
            self._doc_id_map[self.index.ntotal - 1] = doc_id

        # Add to documents list
        self.documents.append(doc)

        # Save to database if available
        if self.db is not None:
            self._save_to_database(doc, user_id)

        # Save index to disk
        if save:
            self._save_index()

        logger.info(f"Added document {doc_id}: {metadata.get('title', 'untitled')}")
        return doc_id

    def _save_to_database(self, doc: RAGDocument, user_id: Optional[int]):
        """Save document to database"""
        try:
            from mdsa.core.db.models import Document as DBDocument

            db_doc = DBDocument(
                content=doc.content,
                content_hash=doc.content_hash,
                title=doc.metadata.get('title'),
                source=doc.metadata.get('source'),
                domain=doc.metadata.get('domain'),
                doc_type=doc.metadata.get('doc_type'),
                extra_data=doc.metadata,  # Changed from 'metadata' to 'extra_data'
                uploaded_by=user_id
            )
            self.db.add(db_doc)
            self.db.commit()
            logger.debug(f"Document saved to database: {doc.doc_id}")
        except Exception as e:
            logger.error(f"Failed to save document to database: {e}")

    def search(
        self,
        query: str,
        k: int = None,
        domain: Optional[str] = None,
        threshold: float = None
    ) -> List[Tuple[RAGDocument, float]]:
        """
        Search for relevant documents.

        Args:
            query: Search query
            k: Number of results to return
            domain: Filter by domain (optional)
            threshold: Minimum similarity score (optional)

        Returns:
            List of (document, score) tuples
        """
        k = k or RAGConfig.DEFAULT_K
        threshold = threshold if threshold is not None else RAGConfig.DEFAULT_THRESHOLD

        if not FAISS_AVAILABLE or self.index is None or self.index.ntotal == 0:
            logger.warning("FAISS index not available or empty")
            return []

        # Generate query embedding
        query_embedding = self._get_embedding(query)
        query_array = np.array([query_embedding], dtype=np.float32)
        faiss.normalize_L2(query_array)

        # Search - get more results if filtering by domain
        search_k = k * 3 if domain else k
        search_k = min(search_k, self.index.ntotal)

        scores, indices = self.index.search(query_array, search_k)

        results = []
        for score, idx in zip(scores[0], indices[0]):
            if idx < 0:  # FAISS returns -1 for missing results
                continue

            # Get document
            if idx < len(self.documents):
                doc = self.documents[idx]
            else:
                continue

            # Filter by domain if specified
            if domain and doc.domain != domain:
                continue

            # Filter by threshold
            if score < threshold:
                continue

            results.append((doc, float(score)))

            if len(results) >= k:
                break

        logger.debug(f"Search '{query[:50]}...' returned {len(results)} results")
        return results

    def delete_document(self, doc_id: int) -> bool:
        """
        Delete a document from the RAG system.

        Note: FAISS doesn't support deletion, so we rebuild the index.

        Args:
            doc_id: Document ID to delete

        Returns:
            True if deleted, False if not found
        """
        # Find document
        doc_idx = None
        for idx, doc in enumerate(self.documents):
            if doc.doc_id == doc_id:
                doc_idx = idx
                break

        if doc_idx is None:
            return False

        # Remove from documents
        self.documents.pop(doc_idx)

        # Rebuild FAISS index
        self._rebuild_index()

        # Delete from database
        if self.db is not None:
            try:
                from mdsa.core.db.models import Document as DBDocument
                self.db.query(DBDocument).filter(DBDocument.id == doc_id).delete()
                self.db.commit()
            except Exception as e:
                logger.error(f"Failed to delete from database: {e}")

        logger.info(f"Deleted document {doc_id}")
        return True

    def _rebuild_index(self):
        """Rebuild FAISS index from documents"""
        if not FAISS_AVAILABLE:
            return

        self._create_empty_index()

        for doc in self.documents:
            if doc.embedding:
                embedding_array = np.array([doc.embedding], dtype=np.float32)
                faiss.normalize_L2(embedding_array)
                self.index.add(embedding_array)
                self._doc_id_map[self.index.ntotal - 1] = doc.doc_id

        self._save_index()

    def get_stats(self) -> Dict[str, Any]:
        """
        Get RAG statistics.

        Returns:
            Dict with document counts and other stats
        """
        # Count by domain
        domain_counts = {}
        for doc in self.documents:
            domain = doc.domain or "global"
            domain_counts[domain] = domain_counts.get(domain, 0) + 1

        return {
            "total_documents": len(self.documents),
            "global_documents": domain_counts.get("global", 0),
            "local_documents": len(self.documents) - domain_counts.get("global", 0),
            "domains": domain_counts,
            "index_size": self.index.ntotal if self.index else 0,
            "embedding_model": self.model_name
        }

    def clear(self):
        """Clear all documents from RAG"""
        self._create_empty_index()
        self._save_index()
        logger.info("Cleared all RAG documents")

    def load_from_database(self):
        """Load documents from database on startup"""
        if self.db is None:
            return

        try:
            from mdsa.core.db.models import Document as DBDocument

            db_docs = self.db.query(DBDocument).all()

            for db_doc in db_docs:
                doc = RAGDocument(
                    content=db_doc.content,
                    metadata={
                        "title": db_doc.title,
                        "source": db_doc.source,
                        "domain": db_doc.domain,
                        "doc_type": db_doc.doc_type,
                        **(db_doc.metadata or {})
                    },
                    doc_id=db_doc.id
                )

                # Generate embedding
                doc.embedding = self._get_embedding(db_doc.content)

                # Add to index
                if FAISS_AVAILABLE and self.index is not None:
                    embedding_array = np.array([doc.embedding], dtype=np.float32)
                    faiss.normalize_L2(embedding_array)
                    self.index.add(embedding_array)
                    self._doc_id_map[self.index.ntotal - 1] = doc.doc_id

                self.documents.append(doc)

            self._save_index()
            logger.info(f"Loaded {len(db_docs)} documents from database")

        except Exception as e:
            logger.error(f"Failed to load from database: {e}")


# ============================================
# SINGLETON INSTANCE
# ============================================

_unified_rag: Optional[UnifiedRAG] = None


def get_unified_rag(db_session=None) -> UnifiedRAG:
    """Get or create the global UnifiedRAG instance"""
    global _unified_rag
    if _unified_rag is None:
        _unified_rag = UnifiedRAG(db_session=db_session)
    return _unified_rag


def reset_rag():
    """Reset the global RAG instance (for testing)"""
    global _unified_rag
    _unified_rag = None
