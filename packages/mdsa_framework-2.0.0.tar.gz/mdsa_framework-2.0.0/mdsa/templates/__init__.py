"""
MDSA Templates Package

Contains template files for MDSA app integration.

Templates:
- app_integration_example.py: Minimal MDSA-compatible FastAPI app
"""

__all__ = []
