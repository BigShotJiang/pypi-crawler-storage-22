"""
MDSA App Integration Template

A minimal example of an MDSA-compatible FastAPI application.
Copy this file as a starting point for your own MDSA-integrated app.

Usage:
    1. Copy this file to your project
    2. Modify the domain configuration
    3. Run: uvicorn app_integration_example:app --port 8000

Author: VICKY (Vicky Vignesh) + Claude Opus 4.5
Version: 2.0.0
"""

from fastapi import FastAPI, HTTPException
from datetime import datetime
from typing import Dict, List, Any
import logging

# Optional: Import MDSA registration (install with: pip install mdsa-framework)
try:
    from mdsa.core.app_registry import register_current_app
    MDSA_AVAILABLE = True
except ImportError:
    MDSA_AVAILABLE = False
    print("Warning: mdsa-framework not installed. App won't register with MDSA Dashboard.")

# ============================================
# APPLICATION CONFIGURATION
# ============================================

APP_CONFIG = {
    "app_id": "my_mdsa_app",
    "app_name": "My MDSA Application",
    "version": "1.0.0",
    "port": 8000,
    "framework": "fastapi"
}

# Define your domains here
DOMAINS = [
    {
        "domain_id": "general",
        "name": "General Assistant",
        "description": "General purpose AI assistant",
        "model": "ollama://llama3.2:3b",
        "enabled": True
    },
    # Add more domains as needed:
    # {
    #     "domain_id": "specialized",
    #     "name": "Specialized Domain",
    #     "description": "Domain-specific assistant",
    #     "model": "ollama://mistral:7b",
    #     "enabled": True
    # }
]

# Define your tools here
TOOLS = [
    # {
    #     "id": "my_tool",
    #     "name": "My Custom Tool",
    #     "type": "function",
    #     "description": "Does something useful",
    #     "enabled": True
    # }
]

# ============================================
# APPLICATION SETUP
# ============================================

app = FastAPI(
    title=APP_CONFIG["app_name"],
    version=APP_CONFIG["version"],
    description="An MDSA-compatible application"
)

# Application state
startup_time = datetime.now()
metrics: Dict[str, int] = {
    "requests_total": 0,
    "errors": 0
}

# Logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


# ============================================
# MDSA REQUIRED ENDPOINTS
# ============================================

@app.get("/api/health")
async def health_check() -> Dict[str, Any]:
    """
    Health check endpoint (REQUIRED by MDSA)

    Returns the app's health status. MDSA Dashboard polls this
    to check if the app is running.
    """
    uptime = (datetime.now() - startup_time).total_seconds()

    return {
        "status": "healthy",
        "app_id": APP_CONFIG["app_id"],
        "version": APP_CONFIG["version"],
        "uptime_seconds": int(uptime),
        "timestamp": datetime.now().isoformat()
    }


@app.get("/api/domains")
async def list_domains() -> Dict[str, List[Dict]]:
    """
    List available domains (REQUIRED by MDSA)

    Returns all domains this app can handle.
    MDSA Dashboard aggregates domains from all registered apps.
    """
    return {
        "domains": DOMAINS
    }


@app.get("/api/metrics")
async def get_metrics() -> Dict[str, Any]:
    """
    Get application metrics (REQUIRED by MDSA)

    Returns metrics about the app's operation.
    MDSA Dashboard displays these in the Monitor view.
    """
    active_domains = sum(1 for d in DOMAINS if d.get("enabled", True))

    return {
        "timestamp": datetime.now().isoformat(),
        "domains": {
            "total": len(DOMAINS),
            "active": active_domains
        },
        "requests": {
            "total": metrics["requests_total"],
            "errors": metrics["errors"]
        },
        "rag": {
            "global_documents": 0,  # Update with your RAG document count
            "local_documents": 0    # Update with your local RAG count
        },
        "tools": {
            "count": len(TOOLS),
            "active": sum(1 for t in TOOLS if t.get("enabled", True))
        }
    }


# ============================================
# MDSA OPTIONAL ENDPOINTS
# ============================================

@app.get("/api/tools")
async def list_tools() -> Dict[str, Any]:
    """
    List available tools (OPTIONAL for MDSA)

    Returns tools this app provides.
    MDSA Dashboard shows these in the Tools view.
    """
    return {
        "tools": TOOLS,
        "count": len(TOOLS)
    }


@app.get("/api/models")
async def list_models() -> Dict[str, List[Dict]]:
    """
    List loaded models (OPTIONAL for MDSA)

    Returns model configurations for each domain.
    MDSA Dashboard shows these in the Models view.
    """
    return {
        "models": [
            {
                "domain_name": d["domain_id"],
                "model_name": d["model"],
                "status": "loaded" if d.get("enabled", True) else "disabled"
            }
            for d in DOMAINS
        ]
    }


# ============================================
# YOUR APPLICATION ENDPOINTS
# ============================================

@app.post("/api/query")
async def process_query(query: Dict[str, Any]) -> Dict[str, Any]:
    """
    Process a user query (your application logic)

    This is where you implement your actual application logic.
    """
    metrics["requests_total"] += 1

    query_text = query.get("query", "")
    domain = query.get("domain", "general")

    # TODO: Implement your query processing logic here

    return {
        "response": f"Processed query: {query_text}",
        "domain": domain,
        "timestamp": datetime.now().isoformat()
    }


# ============================================
# STARTUP & SHUTDOWN EVENTS
# ============================================

@app.on_event("startup")
async def on_startup():
    """
    Application startup handler

    - Registers the app with MDSA Dashboard
    - Initialize your resources here
    """
    logger.info(f"Starting {APP_CONFIG['app_name']} v{APP_CONFIG['version']}")

    # Register with MDSA Dashboard
    if MDSA_AVAILABLE:
        try:
            register_current_app(
                app_id=APP_CONFIG["app_id"],
                app_name=APP_CONFIG["app_name"],
                framework=APP_CONFIG["framework"],
                api_endpoint=f"http://localhost:{APP_CONFIG['port']}"
            )
            logger.info("✅ Registered with MDSA Dashboard")
        except Exception as e:
            logger.warning(f"⚠️ Could not register with MDSA: {e}")

    # TODO: Initialize your resources (database, models, etc.)


@app.on_event("shutdown")
async def on_shutdown():
    """
    Application shutdown handler

    - Clean up resources here
    """
    logger.info(f"Shutting down {APP_CONFIG['app_name']}")

    # TODO: Clean up your resources


# ============================================
# MAIN ENTRY POINT
# ============================================

if __name__ == "__main__":
    import uvicorn

    print(f"""
    ╔════════════════════════════════════════════════════════════╗
    ║  {APP_CONFIG['app_name']:^54}  ║
    ║  Version: {APP_CONFIG['version']:^46}  ║
    ╠════════════════════════════════════════════════════════════╣
    ║  MDSA Integration: {'Enabled' if MDSA_AVAILABLE else 'Disabled':^38}  ║
    ║  Domains: {len(DOMAINS):^48}  ║
    ║  Tools: {len(TOOLS):^50}  ║
    ╠════════════════════════════════════════════════════════════╣
    ║  Starting on http://localhost:{APP_CONFIG['port']:^27}  ║
    ╚════════════════════════════════════════════════════════════╝
    """)

    uvicorn.run(
        "app_integration_example:app",
        host="0.0.0.0",
        port=APP_CONFIG["port"],
        reload=True
    )
