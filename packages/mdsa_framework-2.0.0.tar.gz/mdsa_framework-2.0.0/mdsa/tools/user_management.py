#!/usr/bin/env python3
"""
MDSA User Management CLI

Create, list, and manage users from the command line.

Usage:
    python -m mdsa.tools.user_management create-admin
    python -m mdsa.tools.user_management create-user --username john --email john@example.com
    python -m mdsa.tools.user_management list
    python -m mdsa.tools.user_management reset-password --username admin

Author: VICKY (Vicky Vignesh) + Claude Opus 4.5
Version: 2.0.0
"""

import sys
import argparse
import getpass
from typing import Optional


def get_db_session():
    """Get database session."""
    try:
        from mdsa.core.db.connection import get_session, init_db
        init_db()
        return get_session()
    except ImportError as e:
        print(f"Error: Database module not available: {e}")
        print("Install with: pip install sqlalchemy")
        sys.exit(1)


def get_auth_functions():
    """Get authentication functions."""
    try:
        from mdsa.auth.secure_auth import hash_password, verify_password
        return hash_password, verify_password
    except ImportError:
        # Fallback to jwt_auth
        try:
            from mdsa.auth.jwt_auth import hash_password, verify_password
            return hash_password, verify_password
        except ImportError as e:
            print(f"Error: Auth module not available: {e}")
            print("Install with: pip install bcrypt")
            sys.exit(1)


def create_user(
    username: str,
    email: str,
    password: str,
    role: str = "user",
    session=None
) -> bool:
    """
    Create a new user in the database.

    Args:
        username: Username (3-50 chars, alphanumeric + underscore)
        email: Email address
        password: Password (min 8 chars)
        role: User role (admin, user, viewer)
        session: Database session (optional)

    Returns:
        True if created successfully
    """
    from mdsa.core.db.models import User

    hash_password, _ = get_auth_functions()

    if session is None:
        session = get_db_session()

    # Check if user exists
    existing = session.query(User).filter(
        (User.username == username) | (User.email == email)
    ).first()

    if existing:
        if existing.username == username:
            print(f"Error: Username '{username}' already exists")
        else:
            print(f"Error: Email '{email}' already exists")
        return False

    # Validate password
    if len(password) < 8:
        print("Error: Password must be at least 8 characters")
        return False

    # Create user
    try:
        user = User(
            username=username,
            email=email,
            password_hash=hash_password(password),
            role=role,
            is_active=True
        )
        session.add(user)
        session.commit()

        print(f"User created successfully:")
        print(f"  Username: {username}")
        print(f"  Email: {email}")
        print(f"  Role: {role}")
        print(f"  ID: {user.id}")
        return True

    except Exception as e:
        session.rollback()
        print(f"Error creating user: {e}")
        return False


def create_admin_interactive():
    """Create admin user interactively."""
    print("=" * 50)
    print("MDSA Admin User Creation")
    print("=" * 50)
    print()

    # Get username
    username = input("Admin username [admin]: ").strip() or "admin"

    # Get email
    email = input("Admin email [admin@mdsa.local]: ").strip() or "admin@mdsa.local"

    # Get password
    while True:
        password = getpass.getpass("Admin password (min 8 chars): ")
        if len(password) < 8:
            print("Password must be at least 8 characters")
            continue

        confirm = getpass.getpass("Confirm password: ")
        if password != confirm:
            print("Passwords don't match")
            continue

        break

    print()
    print("Creating admin user...")

    if create_user(username, email, password, role="admin"):
        print()
        print("Admin user created! You can now login to the dashboard.")
        return True

    return False


def list_users():
    """List all users in the database."""
    from mdsa.core.db.models import User

    session = get_db_session()
    users = session.query(User).all()

    if not users:
        print("No users found in database.")
        print("Create an admin user with: python -m mdsa.tools.user_management create-admin")
        return

    print()
    print(f"{'ID':<6} {'Username':<20} {'Email':<30} {'Role':<10} {'Active':<8}")
    print("-" * 80)

    for user in users:
        active = "Yes" if user.is_active else "No"
        print(f"{user.id:<6} {user.username:<20} {user.email:<30} {user.role:<10} {active:<8}")

    print()
    print(f"Total: {len(users)} user(s)")


def reset_password(username: str):
    """Reset a user's password."""
    from mdsa.core.db.models import User

    hash_password, _ = get_auth_functions()
    session = get_db_session()

    user = session.query(User).filter(User.username == username).first()

    if not user:
        print(f"Error: User '{username}' not found")
        return False

    print(f"Resetting password for user: {username}")

    while True:
        password = getpass.getpass("New password (min 8 chars): ")
        if len(password) < 8:
            print("Password must be at least 8 characters")
            continue

        confirm = getpass.getpass("Confirm password: ")
        if password != confirm:
            print("Passwords don't match")
            continue

        break

    try:
        user.password_hash = hash_password(password)
        session.commit()
        print(f"Password reset successfully for '{username}'")
        return True
    except Exception as e:
        session.rollback()
        print(f"Error resetting password: {e}")
        return False


def deactivate_user(username: str):
    """Deactivate a user (soft delete)."""
    from mdsa.core.db.models import User

    session = get_db_session()
    user = session.query(User).filter(User.username == username).first()

    if not user:
        print(f"Error: User '{username}' not found")
        return False

    if not user.is_active:
        print(f"User '{username}' is already deactivated")
        return True

    try:
        user.is_active = False
        session.commit()
        print(f"User '{username}' has been deactivated")
        return True
    except Exception as e:
        session.rollback()
        print(f"Error deactivating user: {e}")
        return False


def activate_user(username: str):
    """Activate a user."""
    from mdsa.core.db.models import User

    session = get_db_session()
    user = session.query(User).filter(User.username == username).first()

    if not user:
        print(f"Error: User '{username}' not found")
        return False

    if user.is_active:
        print(f"User '{username}' is already active")
        return True

    try:
        user.is_active = True
        session.commit()
        print(f"User '{username}' has been activated")
        return True
    except Exception as e:
        session.rollback()
        print(f"Error activating user: {e}")
        return False


def main():
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        description="MDSA User Management CLI",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  Create admin user (interactive):
    python -m mdsa.tools.user_management create-admin

  Create regular user:
    python -m mdsa.tools.user_management create-user -u john -e john@example.com -p password123

  List all users:
    python -m mdsa.tools.user_management list

  Reset password:
    python -m mdsa.tools.user_management reset-password -u admin

  Deactivate user:
    python -m mdsa.tools.user_management deactivate -u john
        """
    )

    subparsers = parser.add_subparsers(dest="command", help="Command to run")

    # create-admin command
    create_admin_parser = subparsers.add_parser(
        "create-admin",
        help="Create admin user interactively"
    )

    # create-user command
    create_user_parser = subparsers.add_parser(
        "create-user",
        help="Create a new user"
    )
    create_user_parser.add_argument("-u", "--username", required=True, help="Username")
    create_user_parser.add_argument("-e", "--email", required=True, help="Email")
    create_user_parser.add_argument("-p", "--password", help="Password (prompted if not provided)")
    create_user_parser.add_argument("-r", "--role", default="user", choices=["admin", "user", "viewer"], help="Role")

    # list command
    list_parser = subparsers.add_parser("list", help="List all users")

    # reset-password command
    reset_parser = subparsers.add_parser("reset-password", help="Reset user password")
    reset_parser.add_argument("-u", "--username", required=True, help="Username")

    # deactivate command
    deactivate_parser = subparsers.add_parser("deactivate", help="Deactivate a user")
    deactivate_parser.add_argument("-u", "--username", required=True, help="Username")

    # activate command
    activate_parser = subparsers.add_parser("activate", help="Activate a user")
    activate_parser.add_argument("-u", "--username", required=True, help="Username")

    args = parser.parse_args()

    if args.command is None:
        parser.print_help()
        sys.exit(0)

    if args.command == "create-admin":
        success = create_admin_interactive()
        sys.exit(0 if success else 1)

    elif args.command == "create-user":
        password = args.password
        if not password:
            password = getpass.getpass("Password: ")

        success = create_user(args.username, args.email, password, args.role)
        sys.exit(0 if success else 1)

    elif args.command == "list":
        list_users()
        sys.exit(0)

    elif args.command == "reset-password":
        success = reset_password(args.username)
        sys.exit(0 if success else 1)

    elif args.command == "deactivate":
        success = deactivate_user(args.username)
        sys.exit(0 if success else 1)

    elif args.command == "activate":
        success = activate_user(args.username)
        sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
