"""
Pytest Configuration and Shared Fixtures for MDSA Test Suite

Provides reusable fixtures for testing MDSA framework components.
"""

import pytest
import pytest_asyncio
import asyncio
import logging
from typing import Dict, Any
from mdsa.models.config import ModelConfig, ModelTier, QuantizationType
from mdsa.domains.config import DomainConfig, get_predefined_domain
from mdsa.models.manager import ModelManager
from mdsa.domains.executor import DomainExecutor
from mdsa.async_.executor import AsyncExecutor
from mdsa.async_.manager import AsyncManager
from mdsa.utils.device_config import get_recommended_config

# Configure logging for tests
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)


# ============================================================================
# Hardware Configuration Fixtures
# ============================================================================

@pytest.fixture(scope="session")
def hardware_config() -> Dict[str, Any]:
    """Get hardware configuration for current system."""
    return get_recommended_config(prefer_gpu=True)


@pytest.fixture(scope="session")
def test_device(hardware_config) -> str:
    """Get device to use for testing (CPU or GPU)."""
    return hardware_config['device']


@pytest.fixture(scope="session")
def test_quantization(hardware_config) -> QuantizationType:
    """Get quantization type to use for testing."""
    return hardware_config['quantization']


# ============================================================================
# Model Configuration Fixtures
# ============================================================================

@pytest.fixture
def tiny_model_config(test_device, test_quantization) -> ModelConfig:
    """Create configuration for tiny test model (GPT-2)."""
    return ModelConfig(
        model_name="gpt2",
        tier=ModelTier.TIER1,
        device=test_device,
        quantization=test_quantization,
        max_length=50,
        temperature=0.7
    )


@pytest.fixture
def phi2_model_config(test_device, test_quantization) -> ModelConfig:
    """Create configuration for Phi-2 model."""
    return ModelConfig(
        model_name="microsoft/phi-2",
        tier=ModelTier.TIER2,
        device=test_device,
        quantization=test_quantization,
        max_length=128,
        temperature=0.3
    )


# ============================================================================
# Domain Configuration Fixtures
# ============================================================================

@pytest.fixture
def support_domain(test_device) -> DomainConfig:
    """Create support domain configuration."""
    return get_predefined_domain('support', force_device=test_device)


@pytest.fixture
def finance_domain(test_device) -> DomainConfig:
    """Create finance domain configuration."""
    return get_predefined_domain('finance', force_device=test_device)


@pytest.fixture
def medical_domain(test_device) -> DomainConfig:
    """Create medical domain configuration."""
    return get_predefined_domain('medical', force_device=test_device)


@pytest.fixture
def technical_domain(test_device) -> DomainConfig:
    """Create technical domain configuration."""
    return get_predefined_domain('technical', force_device=test_device)


@pytest.fixture
def all_domains(support_domain, finance_domain, medical_domain, technical_domain):
    """Get all predefined domains."""
    return [support_domain, finance_domain, medical_domain, technical_domain]


# ============================================================================
# Component Fixtures (Function Scope - Fresh for Each Test)
# ============================================================================

@pytest.fixture
def model_manager(hardware_config):
    """Create fresh ModelManager for each test."""
    return ModelManager(max_models=hardware_config['max_models'])


@pytest.fixture
def domain_executor(model_manager):
    """Create DomainExecutor with fresh ModelManager."""
    return DomainExecutor(model_manager)


@pytest_asyncio.fixture
async def async_executor(domain_executor, hardware_config):
    """Create AsyncExecutor with cleanup."""
    executor = AsyncExecutor(
        domain_executor,
        max_workers=hardware_config['max_workers']
    )
    yield executor
    # Cleanup
    await executor.shutdown_async()


@pytest_asyncio.fixture
async def async_manager(async_executor):
    """Create AsyncManager with cleanup."""
    manager = AsyncManager(async_executor, max_concurrent=5)
    yield manager
    # Cleanup
    await manager.shutdown()


# ============================================================================
# Test Data Fixtures
# ============================================================================

@pytest.fixture
def sample_queries():
    """Sample queries for testing."""
    return [
        "What is the weather today?",
        "How do I transfer money?",
        "What are the symptoms of flu?",
        "How do I fix my computer?",
        "Can you help me with my account?"
    ]


@pytest.fixture
def batch_queries():
    """Batch of queries for concurrent testing."""
    return [
        "Query 1: Test question",
        "Query 2: Another test",
        "Query 3: Third query",
        "Query 4: Fourth question",
        "Query 5: Fifth query",
    ]


# ============================================================================
# Markers and Configuration
# ============================================================================

def pytest_configure(config):
    """Configure pytest markers."""
    config.addinivalue_line(
        "markers", "unit: Unit tests (fast, isolated)"
    )
    config.addinivalue_line(
        "markers", "integration: Integration tests (slower, multiple components)"
    )
    config.addinivalue_line(
        "markers", "e2e: End-to-end tests (slowest, full system)"
    )
    config.addinivalue_line(
        "markers", "slow: Tests that take a long time to run"
    )
    config.addinivalue_line(
        "markers", "gpu: Tests that require GPU"
    )
    config.addinivalue_line(
        "markers", "memory: Tests that stress memory usage"
    )


# ============================================================================
# Event Loop Configuration (for async tests)
# ============================================================================

@pytest.fixture(scope="session")
def event_loop():
    """Create event loop for async tests."""
    loop = asyncio.get_event_loop_policy().new_event_loop()
    yield loop
    loop.close()


# ============================================================================
# Helper Functions
# ============================================================================

def assert_valid_result(result: Dict[str, Any]):
    """Assert that a result dictionary is valid."""
    assert result is not None, "Result should not be None"
    assert isinstance(result, dict), "Result should be a dictionary"
    assert 'status' in result, "Result should have 'status' key"
    assert 'response' in result, "Result should have 'response' key"
    assert 'latency_ms' in result, "Result should have 'latency_ms' key"
    assert 'domain' in result, "Result should have 'domain' key"
    assert 'model' in result, "Result should have 'model' key"


def assert_success_result(result: Dict[str, Any]):
    """Assert that a result indicates success."""
    assert_valid_result(result)
    assert result['status'] == 'success', f"Expected success, got {result['status']}: {result.get('error', '')}"
    assert result['response'], "Response should not be empty"
    assert result['latency_ms'] > 0, "Latency should be positive"


# Export helper functions
__all__ = ['assert_valid_result', 'assert_success_result']


# ============================================================================
# MDSA v2.0.0 Fixtures - Database, Auth, RAG, Validation
# ============================================================================

@pytest.fixture(scope="function")
def test_db():
    """
    Create an in-memory SQLite database for testing.

    Each test gets a fresh database that is destroyed after the test.
    """
    import os
    os.environ["MDSA_DATABASE_URL"] = "sqlite:///:memory:"

    # Reset global engine for fresh connection
    from mdsa.core.db import connection
    connection._engine = None
    connection._SessionLocal = None

    from mdsa.core.db import init_db, get_session
    init_db()

    session = get_session()
    yield session
    session.close()

    # Reset for next test
    connection._engine = None
    connection._SessionLocal = None


@pytest.fixture
def test_user(test_db):
    """Create a test user in the database."""
    from mdsa.core.db.models import User
    from mdsa.auth import secure_hash_password

    user = User(
        username="testuser",
        email="test@mdsa.local",
        password_hash=secure_hash_password("TestPass123!"),
        role="user",
        is_active=True
    )
    test_db.add(user)
    test_db.commit()
    test_db.refresh(user)
    return user


@pytest.fixture
def admin_user(test_db):
    """Create a test admin user in the database."""
    from mdsa.core.db.models import User
    from mdsa.auth import secure_hash_password

    admin = User(
        username="admin",
        email="admin@mdsa.local",
        password_hash=secure_hash_password("AdminPass123!"),
        role="admin",
        is_active=True
    )
    test_db.add(admin)
    test_db.commit()
    test_db.refresh(admin)
    return admin


@pytest.fixture
def test_token(test_user):
    """Create a valid JWT token for the test user."""
    from mdsa.auth import secure_create_token
    return secure_create_token(
        user_id=test_user.id,
        username=test_user.username,
        role=test_user.role
    )


@pytest.fixture
def admin_token(admin_user):
    """Create a valid JWT token for the admin user."""
    from mdsa.auth import secure_create_token
    return secure_create_token(
        user_id=admin_user.id,
        username=admin_user.username,
        role=admin_user.role
    )


@pytest.fixture
def unified_rag(test_db):
    """Create a UnifiedRAG instance for testing."""
    try:
        from mdsa.rag.unified_rag import UnifiedRAG
        rag = UnifiedRAG(db_session=test_db)
        yield rag
    except ImportError:
        pytest.skip("UnifiedRAG requires sentence-transformers and faiss")


@pytest.fixture
def sample_documents():
    """Sample documents for RAG testing."""
    return [
        {
            "content": "The MDSA Framework is a Multi-Domain Specialized Agent system.",
            "metadata": {"source": "docs", "domain": "technical"},
            "title": "MDSA Overview"
        },
        {
            "content": "Investment portfolio management requires diversification.",
            "metadata": {"source": "finance", "domain": "finance"},
            "title": "Investment Guide"
        },
        {
            "content": "Customer support should be responsive and helpful.",
            "metadata": {"source": "support", "domain": "support"},
            "title": "Support Guidelines"
        }
    ]


@pytest.fixture
def rate_limiter():
    """Create a rate limiter for testing."""
    from mdsa.core.rate_limit import RateLimiter
    return RateLimiter(requests_per_minute=60, burst_size=10)


@pytest.fixture
def validation_models():
    """Get validation Pydantic models for testing."""
    from mdsa.core.validation import (
        LoginRequest,
        AppRegistration,
        QueryRequest,
        DocumentUpload
    )
    return {
        "login": LoginRequest,
        "app_registration": AppRegistration,
        "query": QueryRequest,
        "document": DocumentUpload
    }


# ============================================================================
# Test App Fixtures
# ============================================================================

@pytest.fixture
def mock_app_endpoint():
    """Mock endpoint for testing app registration."""
    return "http://localhost:8000"


@pytest.fixture
def registered_app(test_db, mock_app_endpoint):
    """Create a registered test app in the database."""
    from mdsa.core.db.models import App

    app = App(
        app_id="test_app",
        app_name="Test Application",
        framework="fastapi",
        api_endpoint=mock_app_endpoint,
        health_endpoint=f"{mock_app_endpoint}/api/health",
        is_active=True,
        health_status="healthy"
    )
    test_db.add(app)
    test_db.commit()
    test_db.refresh(app)
    return app


# ============================================================================
# Exception Testing Helpers
# ============================================================================

def assert_mdsa_error(exc_type, code: str = None):
    """Context manager to assert MDSA exceptions."""
    from mdsa.core.exceptions import MDSAError
    import contextlib

    @contextlib.contextmanager
    def _assert():
        with pytest.raises(exc_type) as exc_info:
            yield
        if code:
            assert exc_info.value.code == code
        assert isinstance(exc_info.value, MDSAError)

    return _assert()


# Add to exports
__all__.extend([
    'test_db', 'test_user', 'admin_user', 'test_token', 'admin_token',
    'unified_rag', 'sample_documents', 'rate_limiter', 'validation_models',
    'mock_app_endpoint', 'registered_app', 'assert_mdsa_error'
])
