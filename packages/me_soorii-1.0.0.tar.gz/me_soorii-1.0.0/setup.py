from setuptools import setup, find_packages

setup(
    name="me-soorii",
    version="1.0.0",
    author="soorii",
    description="soorii v1",
    long_description="soorii v1",
    long_description_content_type="text/plain",
    url="https://github.com/yourusername/me-soorii",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6",
)
