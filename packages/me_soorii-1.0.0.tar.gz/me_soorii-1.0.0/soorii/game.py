import webbrowser
import tempfile
import os

def start():
    
    html_content = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>soorii</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background: linear-gradient(to bottom right, #FEEBF4, #D1C4E9, #B2EBF2);
            font-family: 'Courier New', monospace;
            overflow: hidden;
            position: relative;
        }
        
        .clouds-container {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            overflow: hidden;
            pointer-events: none;
            z-index: 0;
        }
        
        .cloud {
            position: absolute;
            background: rgba(255, 255, 255, 0.4);
            border-radius: 100px;
        }
        
        .cloud:before, .cloud:after {
            content: '';
            position: absolute;
            background: rgba(255, 255, 255, 0.4);
            border-radius: 50%;
        }
        
        .cloud-1 {
            width: 200px;
            height: 60px;
            top: 15%;
            animation: moveCloud1 120s linear infinite;
        }
        .cloud-1:before {
            width: 100px;
            height: 80px;
            top: -35px;
            left: 20px;
        }
        .cloud-1:after {
            width: 80px;
            height: 80px;
            top: -30px;
            right: 30px;
        }
        
        .cloud-2 {
            width: 150px;
            height: 50px;
            top: 35%;
            animation: moveCloud2 100s linear infinite;
        }
        .cloud-2:before {
            width: 90px;
            height: 70px;
            top: -30px;
            left: 15px;
        }
        .cloud-2:after {
            width: 70px;
            height: 70px;
            top: -25px;
            right: 20px;
        }
        
        .cloud-3 {
            width: 180px;
            height: 55px;
            bottom: 25%;
            animation: moveCloud3 140s linear infinite;
        }
        .cloud-3:before {
            width: 95px;
            height: 75px;
            top: -30px;
            left: 15px;
        }
        .cloud-3:after {
            width: 75px;
            height: 75px;
            top: -30px;
            right: 25px;
        }
        
        .cloud-4 {
            width: 120px;
            height: 40px;
            top: 25%;
            animation: moveCloud4 110s linear infinite;
        }
        .cloud-4:before {
            width: 60px;
            height: 60px;
            top: -25px;
            left: 10px;
        }
        .cloud-4:after {
            width: 50px;
            height: 50px;
            top: -20px;
            right: 15px;
        }
        
        .cloud-5 {
            width: 160px;
            height: 50px;
            bottom: 35%;
            animation: moveCloud5 130s linear infinite;
        }
        .cloud-5:before {
            width: 80px;
            height: 65px;
            top: -30px;
            left: 15px;
        }
        .cloud-5:after {
            width: 65px;
            height: 65px;
            top: -25px;
            right: 20px;
        }
        
        .cloud-6 {
            width: 140px;
            height: 45px;
            top: 60%;
            animation: moveCloud6 150s linear infinite;
        }
        .cloud-6:before {
            width: 70px;
            height: 60px;
            top: -25px;
            left: 12px;
        }
        .cloud-6:after {
            width: 60px;
            height: 60px;
            top: -22px;
            right: 18px;
        }
        
        @keyframes moveCloud1 {
            0% { left: -250px; }
            100% { left: 100%; }
        }
        @keyframes moveCloud2 {
            0% { right: -200px; }
            100% { right: 100%; }
        }
        @keyframes moveCloud3 {
            0% { left: -230px; }
            100% { left: 100%; }
        }
        @keyframes moveCloud4 {
            0% { left: 30%; }
            100% { left: 100%; }
        }
        @keyframes moveCloud5 {
            0% { right: -210px; }
            100% { right: 100%; }
        }
        @keyframes moveCloud6 {
            0% { left: -190px; }
            100% { left: 100%; }
        }
        
        #gameContainer {
            position: relative;
            z-index: 1;
        }
        
        canvas {
            border: none;
            display: block;
            border-radius: 10px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.15);
            background: rgba(255, 255, 255, 0.3);
        }
        
        #finalMessage {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: rgba(255, 255, 255, 0.95);
            border: 3px solid #D1C4E9;
            padding: 40px;
            text-align: center;
            display: none;
            z-index: 10;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
            border-radius: 15px;
        }
        
        #finalMessage h1 {
            margin: 0 0 20px 0;
            font-size: 32px;
            color: #7B68AA;
        }
        
        #finalMessage p {
            margin: 10px 0;
            font-size: 18px;
            color: #5A4A7A;
            line-height: 1.6;
        }
    </style>
</head>
<body>
    <div class="clouds-container">
        <div class="cloud cloud-1"></div>
        <div class="cloud cloud-2"></div>
        <div class="cloud cloud-3"></div>
        <div class="cloud cloud-4"></div>
        <div class="cloud cloud-5"></div>
        <div class="cloud cloud-6"></div>
    </div>
    
    <div id="gameContainer">
        <canvas id="canvas" width="800" height="200"></canvas>
        <div id="finalMessage"></div>
    </div>

    <script>
        const canvas = document.getElementById('canvas');
        const ctx = canvas.getContext('2d');

        let gameSpeed = 3;
        let gravity = 0.5;
        let score = 0;
        let highScore = 0;
        let jumpCount = 0;
        let gameOver = false;
        let gameStarted = false;
        let finalMessageShown = false;

        let jumpMessage = {
            text: '',
            opacity: 0,
            y: 50
        };

        const dino = {
            x: 50,
            y: 150,
            width: 40,
            height: 40,
            dy: 0,
            jumpPower: -11,
            grounded: false,
            jumping: false
        };

        let cacti = [];
        let cactusTimer = 0;
        let cactusInterval = 100;

        const ground = {
            x: 0,
            y: canvas.height - 10,
            width: canvas.width,
            height: 10
        };

        function drawDino() {
            ctx.fillStyle = '#7B68AA';
            
            ctx.fillRect(dino.x, dino.y, dino.width, dino.height);
            
            ctx.fillStyle = 'white';
            ctx.fillRect(dino.x + 25, dino.y + 8, 5, 5);
            
            ctx.fillStyle = '#7B68AA';
            if (Math.floor(score / 10) % 2 === 0) {
                ctx.fillRect(dino.x + 5, dino.y + 40, 8, 10);
                ctx.fillRect(dino.x + 25, dino.y + 40, 8, 10);
            } else {
                ctx.fillRect(dino.x + 10, dino.y + 40, 8, 10);
                ctx.fillRect(dino.x + 20, dino.y + 40, 8, 10);
            }
            
            ctx.fillRect(dino.x - 5, dino.y + 20, 8, 8);
        }

        function drawCactus(cactus) {
            ctx.fillStyle = '#6B8A7A';
            ctx.fillRect(cactus.x, cactus.y, cactus.width, cactus.height);
            
            ctx.fillRect(cactus.x - 5, cactus.y + 10, 5, 15);
            ctx.fillRect(cactus.x + cactus.width, cactus.y + 15, 5, 15);
        }

        function drawGround() {
            ctx.fillStyle = '#D1C4E9';
            ctx.fillRect(0, ground.y, ground.width, ground.height);
            
            ctx.strokeStyle = '#B2A5D1';
            ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.moveTo(0, ground.y);
            ctx.lineTo(ground.width, ground.y);
            ctx.stroke();
        }

        function spawnCactus() {
            const cactus = {
                x: canvas.width,
                y: ground.y - 40,
                width: 20,
                height: 40
            };
            cacti.push(cactus);
        }

        function updateDino() {
            dino.dy += gravity;
            dino.y += dino.dy;

            if (dino.y + dino.height >= ground.y) {
                dino.y = ground.y - dino.height;
                dino.grounded = true;
                dino.jumping = false;
                dino.dy = 0;
            }
        }

        function jump() {
            if (dino.grounded && !finalMessageShown) {
                dino.dy = dino.jumpPower;
                dino.grounded = false;
                dino.jumping = true;
                jumpCount++;
                
                jumpMessage.text = 'SORRY!';
                jumpMessage.opacity = 1;
                jumpMessage.y = 50;
                
                if (jumpCount === 10) {
                    showFinalMessage();
                }
            }
        }

        function updateCacti() {
            cactusTimer++;
            
            if (cactusTimer > cactusInterval) {
                spawnCactus();
                cactusTimer = 0;
                cactusInterval = Math.random() * 50 + 75;
            }

            cacti.forEach((cactus, index) => {
                cactus.x -= gameSpeed;

                if (cactus.x + cactus.width < 0) {
                    cacti.splice(index, 1);
                }

                if (
                    dino.x < cactus.x + cactus.width &&
                    dino.x + dino.width > cactus.x &&
                    dino.y < cactus.y + cactus.height &&
                    dino.y + dino.height > cactus.y
                ) {
                    if (!finalMessageShown) {
                        gameOver = true;
                    }
                }
            });
        }

        function updateScore() {
            if (!gameOver && gameStarted && !finalMessageShown) {
                score++;
                
                if (score % 100 === 0) {
                    gameSpeed += 0.2;
                }
            }
        }

        function updateJumpMessage() {
            if (jumpMessage.opacity > 0) {
                jumpMessage.opacity -= 0.02;
                jumpMessage.y -= 0.5;
            }
        }

        function showFinalMessage() {
            finalMessageShown = true;
            gameOver = true;
            
            const messageDiv = document.getElementById('finalMessage');
            messageDiv.innerHTML = `
                <h1>me sorry😭</h1>
                <p><strong>bhul ja yar uss bat ko😭😭😭😭</strong></p>
                <p><strong>maf karde plz😭😭😭😭</strong></p>
            `;
            messageDiv.style.display = 'block';
        }

        function drawScore() {
            ctx.fillStyle = '#7B68AA';
            ctx.font = 'bold 16px Courier New';
            ctx.textAlign = 'right';
            ctx.fillText('HI ' + String(highScore).padStart(5, '0'), canvas.width - 10, 30);
            ctx.fillText(String(Math.floor(score)).padStart(5, '0'), canvas.width - 10, 50);
            
            ctx.textAlign = 'left';
            ctx.fillText('JUMPS: ' + jumpCount + '/10', 10, 30);
        }

        function drawJumpMessage() {
            if (jumpMessage.opacity > 0) {
                ctx.globalAlpha = jumpMessage.opacity;
                ctx.fillStyle = '#7B68AA';
                ctx.font = 'bold 48px Courier New';
                ctx.textAlign = 'center';
                ctx.fillText(jumpMessage.text, canvas.width / 2, jumpMessage.y);
                ctx.globalAlpha = 1;
            }
        }

        function drawGameOver() {
            ctx.fillStyle = '#7B68AA';
            ctx.font = 'bold 24px Courier New';
            ctx.textAlign = 'center';
            ctx.fillText('G A M E  O V E R', canvas.width / 2, canvas.height / 2 - 20);
            
            ctx.font = '16px Courier New';
            ctx.fillText('Press SPACE to restart', canvas.width / 2, canvas.height / 2 + 10);
        }

        function drawStartScreen() {
            ctx.fillStyle = '#7B68AA';
            ctx.font = '20px Courier New';
            ctx.textAlign = 'center';
            ctx.fillText('Press SPACE to start', canvas.width / 2, canvas.height / 2);
        }

        function reset() {
            gameOver = false;
            gameStarted = true;
            finalMessageShown = false;
            score = 0;
            jumpCount = 0;
            gameSpeed = 3;
            cacti = [];
            cactusTimer = 0;
            dino.y = 150;
            dino.dy = 0;
            jumpMessage.opacity = 0;
            document.getElementById('finalMessage').style.display = 'none';
        }

        function gameLoop() {
            ctx.clearRect(0, 0, canvas.width, canvas.height);

            drawGround();
            drawDino();
            cacti.forEach(cactus => drawCactus(cactus));
            drawScore();
            drawJumpMessage();

            if (!gameStarted) {
                drawStartScreen();
            } else if (gameOver && !finalMessageShown) {
                drawGameOver();
            } else if (!gameOver && !finalMessageShown) {
                updateDino();
                updateCacti();
                updateScore();
                updateJumpMessage();
            }

            requestAnimationFrame(gameLoop);
        }

        document.addEventListener('keydown', (e) => {
            if (e.code === 'Space') {
                e.preventDefault();
                
                if (!gameStarted || gameOver) {
                    if (!finalMessageShown) {
                        reset();
                    }
                } else {
                    jump();
                }
            }
        });

        canvas.addEventListener('touchstart', (e) => {
            e.preventDefault();
            if (!gameStarted || gameOver) {
                if (!finalMessageShown) {
                    reset();
                }
            } else {
                jump();
            }
        });

        setInterval(() => {
            if (score > highScore) {
                highScore = score;
            }
        }, 100);

        gameLoop();
    </script>
</body>
</html>
"""
    
    temp_file = tempfile.NamedTemporaryFile(mode='w', suffix='.html', delete=False, encoding='utf-8')
    temp_file.write(html_content)
    temp_file.close()
    
    webbrowser.open('file://' + temp_file.name)
    print("browser khol")
