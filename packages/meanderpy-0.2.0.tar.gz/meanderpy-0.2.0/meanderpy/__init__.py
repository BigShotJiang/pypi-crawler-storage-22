name = "meanderpy"
__version__ = "0.2.0"
from .meanderpy import *