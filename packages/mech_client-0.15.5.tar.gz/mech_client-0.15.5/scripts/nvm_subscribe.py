import os
import sys
from dotenv import load_dotenv
from typing import Optional, Dict
from pathlib import Path
from aea_ledger_ethereum import EthereumCrypto
from mech_client.interact import PRIVATE_KEY_FILE_PATH
from web3 import Web3
from scripts.nvm_subscription.manager import NVMSubscriptionManager

BASE_ENV_PATH = Path(__file__).parent / "nvm_subscription" / "envs"

CHAIN_TO_ENVS: Dict[str, Path] = {
    "gnosis": BASE_ENV_PATH / "gnosis.env",
    "base": BASE_ENV_PATH / "base.env",
}


def main(
    agent_mode: bool,
    private_key_path: str,
    private_key_password: Optional[str],
    chain_config: str,
    safe_address: Optional[str] = None,
) -> None:

    chain_env = CHAIN_TO_ENVS.get(chain_config)
    if chain_env:
        load_dotenv(chain_env)
    else:
        print(f"{chain_config} network not supported")
        sys.exit(1)

    private_key_path = private_key_path or PRIVATE_KEY_FILE_PATH
    if not Path(private_key_path).exists():
        raise FileNotFoundError(
            f"Private key file `{private_key_path}` does not exist!"
        )

    crypto = EthereumCrypto(
        private_key_path=private_key_path,
        password=private_key_password,
    )
    WALLET_PVT_KEY = crypto.private_key
    PLAN_DID = os.environ["PLAN_DID"]
    NETWORK = os.environ["NETWORK_NAME"]
    CHAIN_ID = int(os.environ["CHAIN_ID"])
    # NVM Subscription has to be purchased for the safe and EOA pays for gas
    # so for agent mode, sender has to be safe
    EOA = Web3().eth.account.from_key(WALLET_PVT_KEY).address
    SENDER = safe_address or EOA

    print(f"Sender address: {SENDER}")

    manager = NVMSubscriptionManager(NETWORK, SENDER, agent_mode, safe_address)
    tx_receipt = manager.create_subscription(PLAN_DID, WALLET_PVT_KEY, CHAIN_ID)

    print("Subscription created successfully")
    print(tx_receipt)
