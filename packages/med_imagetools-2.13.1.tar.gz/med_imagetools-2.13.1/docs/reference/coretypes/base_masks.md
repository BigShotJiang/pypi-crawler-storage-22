::: imgtools.coretypes.base_masks
