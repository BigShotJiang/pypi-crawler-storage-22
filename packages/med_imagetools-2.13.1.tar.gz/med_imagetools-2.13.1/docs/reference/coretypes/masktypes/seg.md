::: imgtools.coretypes.masktypes.seg
