::: imgtools.coretypes.spatial_types.image_geometry
