::: imgtools.dicom.dicom_metadata.modality_utils.sr_utils
