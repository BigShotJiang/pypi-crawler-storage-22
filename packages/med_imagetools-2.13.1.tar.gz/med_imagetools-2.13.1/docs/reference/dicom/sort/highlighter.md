::: imgtools.dicom.sort.highlighter
