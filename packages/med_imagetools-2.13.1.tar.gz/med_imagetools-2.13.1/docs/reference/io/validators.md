::: imgtools.io.validators
