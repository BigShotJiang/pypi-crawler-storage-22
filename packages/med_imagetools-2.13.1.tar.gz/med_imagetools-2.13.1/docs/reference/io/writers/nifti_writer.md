::: imgtools.io.writers.nifti_writer
