::: imgtools.transforms.base_transform
