::: imgtools.utils.dictionaries
