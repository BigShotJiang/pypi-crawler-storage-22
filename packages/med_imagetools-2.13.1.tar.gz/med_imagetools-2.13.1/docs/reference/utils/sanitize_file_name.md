::: imgtools.utils.sanitize_file_name
