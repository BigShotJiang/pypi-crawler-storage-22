::: imgtools.utils.timer_utils
