
with open("medgemma.rb") as f:
    original = f.read()

with open("resources.rb") as f:
    resources = f.read()

# insert resources before "def install"
parts = original.split("  def install")
new_content = parts[0] + "\n" + resources + "\n  def install" + parts[1]

with open("medgemma.rb", "w") as f:
    f.write(new_content)
