# CLAUDE.md

## Project Overview

Image slideshow application (tkinter) with a Flask-based web media controller. The media controller is an installable package via `uv tool install`.

## Build & Install

```bash
uv sync          # install all dependencies
uv sync --dev    # include dev dependencies (pytest)
```

## Run Tests

```bash
uv run pytest tests/ -v
```

Tests mock GUI modules (tkinter, pynput) for headless execution. CI runs against Python 3.10, 3.11, 3.12.

## Project Structure

- `main.py` — Main tkinter slideshow app with Flask endpoint for filename serving
- `mediaController.py` — Standalone Flask media controller (legacy entry point)
- `src/media_controller/` — Installable package version of media controller
  - `app.py` — Flask app with `main()` entry point
  - `mediaweb/` — Bundled static web UI assets
- `web/` — Static files for slideshow web interface
- `tests/` — pytest test suite

## Key Commands

- `uv run python main.py` — Run slideshow (accepts `--names`, `--no-location`, `--root`)
- `uv run media-controller` — Run media controller server
- `uv tool install .` — Install media-controller CLI globally
- `uv build` — Build distributable package
- `uv publish` — Publish to PyPI

## Conventions

- Python >=3.10, dependency management via uv
- Build backend: hatchling with `src/` layout for the installable package
- No linter/formatter configured
- Tests use `conftest.py` to mock tkinter and pynput for headless CI
