$(document).ready(function () {
$("button").click(function(e) {
    e.preventDefault();
    $.ajax({
        type: "POST",
        url: "/execute",
        data: {
            id: $(this).val(), // < note use of 'this' here
            access_token: $("#access_token").val()
        },
        success: function(result) {
        },
        error: function (request, status, error) {
            alert(request.responseText+" "+status+" "+error);
        }
    });
});
});