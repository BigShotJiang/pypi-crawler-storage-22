:run
python mediaController.py
goto run
