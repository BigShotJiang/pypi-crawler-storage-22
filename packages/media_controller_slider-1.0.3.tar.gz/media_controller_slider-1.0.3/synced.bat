cd c:\temp
gphotos-sync.exe --album-regex "^(Frame|Rome|Vacation With kids)$" --progress --use-hardlinks --use-flat-path --skip-video --omit-album-date --albums-path C:\Users\eyal\Desktop\Frame\Albums .
cd c:\views\slider