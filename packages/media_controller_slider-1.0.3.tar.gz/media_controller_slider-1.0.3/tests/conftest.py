"""Shared test configuration - mock GUI modules that require a display server."""
import sys
from unittest.mock import MagicMock

# Mock tkinter before any imports that depend on it
tkinter_mock = MagicMock()
tkinter_mock.Tk = MagicMock
tkinter_mock.Label = MagicMock
sys.modules['tkinter'] = tkinter_mock

# Mock pynput modules before any imports that depend on them
pynput_mock = MagicMock()
pynput_keyboard_mock = MagicMock()
sys.modules['pynput'] = pynput_mock
sys.modules['pynput.keyboard'] = pynput_keyboard_mock
sys.modules['pynput._util'] = MagicMock()

# Set the keyboard attribute on the pynput mock
pynput_mock.keyboard = pynput_keyboard_mock
