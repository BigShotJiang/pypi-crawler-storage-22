"""
dat_utils.py - DAT file member data extraction utilities

Purpose:
- Extract member data from fixed-width DAT files for submission context queries
- Wrapper around existing MediLink_DataMgmt parsing functions
- Provides data in format needed for OPTUMAI member-based searches

Compatible with: Windows XP SP3, Python 3.4.4, ASCII-only
"""
import os

try:
    from MediLink import MediLink_DataMgmt
except ImportError:
    MediLink_DataMgmt = None

try:
    from MediCafe.core_utils import get_shared_config_loader
    MediLink_ConfigLoader = get_shared_config_loader()
except ImportError:
    MediLink_ConfigLoader = None


def extract_member_data_from_dat_file(dat_file_path, config):
    """
    Extract member data from a fixed-width DAT file.
    
    Uses existing MediLink_DataMgmt.read_fixed_width_data() and 
    parse_fixed_width_data() functions to parse DAT files.
    
    Args:
        dat_file_path: Path to DAT file
        config: Configuration dictionary
    
    Returns:
        list: List of patient records with member data, each containing:
            - patient_id (from CHART field)
            - patid (from PATID field)
            - member_id (from insurance segments)
            - first_name, last_name
            - dob (date of birth)
            - service_date
            - payer_id, insurance_name
    """
    if not MediLink_DataMgmt:
        return []
    
    if not os.path.exists(dat_file_path):
        return []
    
    patient_records = []
    
    try:
        # Read DAT file using existing functions
        data_generator = MediLink_DataMgmt.read_fixed_width_data(dat_file_path)
        if not data_generator:
            return []
        
        for personal_info, insurance_info, service_info, service_info_2, service_info_3 in data_generator:
            try:
                # Parse record using existing function
                parsed_data = MediLink_DataMgmt.parse_fixed_width_data(
                    personal_info, insurance_info, service_info, 
                    service_info_2, service_info_3, config
                )
                
                # Extract relevant fields
                record = {
                    'patient_id': parsed_data.get('CHART', ''),
                    'patid': parsed_data.get('PATID', ''),
                    'first_name': parsed_data.get('FIRST', ''),
                    'last_name': parsed_data.get('LAST', ''),
                    'dob': parsed_data.get('DOB', ''),
                    'service_date': parsed_data.get('DOS', ''),
                    'insurance_name': parsed_data.get('INAME', ''),
                    'payer_id': parsed_data.get('PAYERID', ''),
                    'member_id': parsed_data.get('MEMID', '') or parsed_data.get('PATID', ''),
                }
                
                patient_records.append(record)
                
            except Exception:
                continue
                
    except Exception as e:
        if MediLink_ConfigLoader:
            MediLink_ConfigLoader.log(
                "Error parsing DAT file {}: {}".format(dat_file_path, e),
                level="WARNING"
            )
    
    return patient_records


def get_dat_file_metadata(dat_file_path):
    """
    Get metadata for a DAT file.
    
    Args:
        dat_file_path: Path to DAT file
    
    Returns:
        dict: File metadata with:
            - file_path: Full path to file
            - file_name: Just the filename
            - created_at: File modification time (timestamp)
            - size: File size in bytes
    """
    metadata = {
        'file_path': dat_file_path,
        'file_name': os.path.basename(dat_file_path),
        'created_at': 0,
        'size': 0,
    }
    
    try:
        if os.path.exists(dat_file_path):
            metadata['created_at'] = os.path.getmtime(dat_file_path)
            metadata['size'] = os.path.getsize(dat_file_path)
    except Exception:
        pass
    
    return metadata


def parse_dat_file_for_submission_context(dat_file_path, config):
    """
    Parse DAT file and extract data needed for OPTUMAI member-based search.
    
    Returns the first patient record found in the DAT file, formatted for
    submission context queries.
    
    Args:
        dat_file_path: Path to DAT file
        config: Configuration dictionary
    
    Returns:
        dict: Submission context data with:
            - member_id: Member ID
            - member_first_name: First name
            - member_last_name: Last name
            - member_dob: Date of birth in MM/DD/YYYY format
            - service_start_date: Service date in MM/DD/YYYY format
            - service_end_date: Same as service_start_date
            - payer_id: Payer ID
    """
    patient_records = extract_member_data_from_dat_file(dat_file_path, config)
    
    if not patient_records:
        return None
    
    # Use first patient record
    record = patient_records[0]
    
    # Format dates for OPTUMAI (MM/DD/YYYY)
    dob_formatted = _format_date_for_optumai(record.get('dob', ''))
    service_date_formatted = _format_date_for_optumai(record.get('service_date', ''))
    
    context = {
        'member_id': record.get('member_id', ''),
        'member_first_name': record.get('first_name', ''),
        'member_last_name': record.get('last_name', ''),
        'member_dob': dob_formatted,
        'service_start_date': service_date_formatted,
        'service_end_date': service_date_formatted,
        'payer_id': record.get('payer_id', ''),
    }
    
    return context


def _format_date_for_optumai(date_str):
    """
    Format date string to MM/DD/YYYY format for OPTUMAI.
    
    Handles common input formats:
    - MM-DD-YY or MM-DD-YYYY
    - MM/DD/YY or MM/DD/YYYY
    - YYYYMMDD
    
    Args:
        date_str: Date string in various formats
    
    Returns:
        str: Date in MM/DD/YYYY format, or empty string if parsing fails
    """
    if not date_str:
        return ''
    
    date_str = str(date_str).strip()
    
    # Try to parse various formats
    try:
        # Handle YYYYMMDD format
        if len(date_str) == 8 and date_str.isdigit():
            year = date_str[0:4]
            month = date_str[4:6]
            day = date_str[6:8]
            return "{}/{}/{}".format(month, day, year)
        
        # Handle MM-DD-YY or MM-DD-YYYY format
        if '-' in date_str:
            parts = date_str.split('-')
            if len(parts) == 3:
                month, day, year = parts
                # Handle 2-digit year
                if len(year) == 2:
                    year_int = int(year)
                    if year_int > 50:
                        year = '19' + year
                    else:
                        year = '20' + year
                return "{}/{}/{}".format(month.zfill(2), day.zfill(2), year)
        
        # Handle MM/DD/YY or MM/DD/YYYY format (already in correct format)
        if '/' in date_str:
            parts = date_str.split('/')
            if len(parts) == 3:
                month, day, year = parts
                # Handle 2-digit year
                if len(year) == 2:
                    year_int = int(year)
                    if year_int > 50:
                        year = '19' + year
                    else:
                        year = '20' + year
                return "{}/{}/{}".format(month.zfill(2), day.zfill(2), year)
                
    except Exception:
        pass
    
    return ''
