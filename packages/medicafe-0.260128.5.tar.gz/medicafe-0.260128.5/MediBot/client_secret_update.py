#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Client Secret Update Tool
Guided tool for updating API client secrets from the Troubleshooting menu.
Compatible with Python 3.4.4 and Windows XP.
"""

import os
import sys
import time

# Add parent directory to path to find MediCafe modules
parent_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

# Import helper functions
try:
    from MediBot.config_editor_helpers import (
        load_config_safe, create_backup, save_config_atomic, clear_config_cache
    )
except ImportError:
    print("ERROR: Could not import config_editor_helpers")
    print("Please ensure config_editor_helpers.py is in the MediBot directory.")
    sys.exit(1)

# Validation constants
MIN_SECRET_LENGTH = 8
MAX_SECRET_LENGTH = 200
PLACEHOLDER_SECRETS = ['<your_client_secret>', 'changeme', 'replace_me', 'secret_here']


def clear_screen():
    """Clear the console screen (XP compatible)."""
    os.system('cls' if os.name == 'nt' else 'clear')


def print_header():
    """Print the updater header."""
    print("=" * 60)
    print("      MediCafe Client Secret Updater")
    print("=" * 60)
    print("")


def mask_secret(secret):
    """Mask a secret for display (show only last 4 chars)."""
    if not secret or len(secret) <= 4:
        return "****"
    return "****" + secret[-4:]


def validate_secret(secret):
    """
    Validate a client secret.
    Returns (is_valid, error_message)
    """
    if not secret:
        return False, "Secret cannot be empty"
    
    # Strip whitespace
    secret = secret.strip()
    if not secret:
        return False, "Secret cannot be empty or whitespace only"
    
    # Check for whitespace characters
    if any(c in secret for c in [' ', '\t', '\n', '\r']):
        return False, "Secret cannot contain whitespace characters"
    
    # Length check
    if len(secret) < MIN_SECRET_LENGTH:
        return False, "Secret must be at least {0} characters long".format(MIN_SECRET_LENGTH)
    
    if len(secret) > MAX_SECRET_LENGTH:
        return False, "Secret must be no more than {0} characters long".format(MAX_SECRET_LENGTH)
    
    # Check for placeholders
    secret_lower = secret.lower()
    for placeholder in PLACEHOLDER_SECRETS:
        if placeholder.lower() in secret_lower:
            return False, "Secret appears to be a placeholder value"
    
    return True, None


def discover_endpoints(config):
    """
    Discover available endpoints from config.
    Returns list of (endpoint_name, endpoint_config) tuples.
    """
    endpoints = []
    
    try:
        medi_config = config.get('MediLink_Config', {})
        endpoints_dict = medi_config.get('endpoints', {})
        
        if not endpoints_dict:
            return endpoints
        
        for endpoint_name, endpoint_config in endpoints_dict.items():
            if isinstance(endpoint_config, dict):
                endpoints.append((endpoint_name, endpoint_config))
        
    except Exception as e:
        print("ERROR: Failed to discover endpoints: {0}".format(str(e)))
    
    return endpoints


def display_endpoints(endpoints):
    """Display numbered list of endpoints with warnings for missing fields."""
    if not endpoints:
        print("No endpoints found in configuration.")
        return
    
    print("Available endpoints:")
    print("-" * 60)
    
    for i, (endpoint_name, endpoint_config) in enumerate(endpoints, 1):
        warnings = []
        
        if 'token_url' not in endpoint_config:
            warnings.append("token_url")
        if 'client_id' not in endpoint_config:
            warnings.append("client_id")
        
        warning_text = ""
        if warnings:
            warning_text = " [WARNING: Missing {0}]".format(", ".join(warnings))
        
        token_url = endpoint_config.get('token_url', '[MISSING]')
        client_id = endpoint_config.get('client_id', '[MISSING]')
        
        print("[{0}] {1}".format(i, endpoint_name))
        print("     token_url: {0}".format(token_url))
        print("     client_id: {0}{1}".format(client_id, warning_text))
        print("")
    
    print("[0] Cancel and exit")
    print("")


def select_endpoint(endpoints):
    """Prompt user to select an endpoint by number."""
    if not endpoints:
        return None, None
    
    while True:
        try:
            choice_str = input("Select endpoint (1-{0}, or 0 to cancel): ".format(len(endpoints))).strip()
            if not choice_str:
                print("Invalid choice. Please enter a number.")
                continue
            
            choice = int(choice_str)
            if choice == 0:
                return None, None
            elif 1 <= choice <= len(endpoints):
                endpoint_name, endpoint_config = endpoints[choice - 1]
                return endpoint_name, endpoint_config
            else:
                print("Invalid choice. Please enter a number between 1 and {0}, or 0 to cancel.".format(len(endpoints)))
        except ValueError:
            print("Invalid choice. Please enter a number.")
        except KeyboardInterrupt:
            print("\nOperation cancelled.")
            return None, None


def get_secret_input():
    """Prompt user for new client secret."""
    print("")
    print("Secret requirements:")
    print("  - Length: {0} to {1} characters".format(MIN_SECRET_LENGTH, MAX_SECRET_LENGTH))
    print("  - No whitespace characters")
    print("  - Cannot be a placeholder value")
    print("")
    
    while True:
        try:
            secret = input("Enter new client secret: ").strip()
            if secret:
                return secret
            print("Secret cannot be empty. Please try again.")
        except KeyboardInterrupt:
            print("\nOperation cancelled.")
            return None


def update_config_secret(config, endpoint_name, new_secret):
    """
    Update the client secret in config and add/update timestamp.
    Returns updated config dict.
    """
    try:
        medi_config = config.get('MediLink_Config', {})
        if 'endpoints' not in medi_config:
            medi_config['endpoints'] = {}
        
        endpoints = medi_config['endpoints']
        if endpoint_name not in endpoints:
            endpoints[endpoint_name] = {}
        
        endpoint_config = endpoints[endpoint_name]
        
        # Update secret
        endpoint_config['client_secret'] = new_secret
        
        # Add/update timestamp (ISO 8601 format)
        timestamp = time.strftime('%Y-%m-%dT%H:%M:%S')
        endpoint_config['client_secret_last_updated'] = timestamp
        
        return config
        
    except Exception as e:
        print("ERROR: Failed to update config: {0}".format(str(e)))
        return None


def test_token(endpoint_name):
    """
    Test the new secret by attempting to get an access token.
    The APIClient will load the secret from the saved config file.
    Returns (success, error_message)
    """
    try:
        # Import API client - create new instance to ensure fresh config load
        # (each instance has its own token cache and loads config from file)
        try:
            from MediCafe.core_utils import get_api_client
            api_client = get_api_client()
            if not api_client:
                # Fallback to factory-backed shared client
                try:
                    from MediCafe.api_factory import APIClient
                    api_client = APIClient()
                except ImportError:
                    # Final fallback to direct import if factory unavailable
                    from MediCafe.api_core import APIClient
                    api_client = APIClient()
        except Exception as e:
            return False, "Could not create API client: {0}".format(str(e))
        
        # Attempt to get access token (APIClient loads config from file)
        try:
            token = api_client.get_access_token(endpoint_name)
            if token:
                return True, None
            else:
                return False, "Token request returned None (check credentials and endpoint configuration)"
        except Exception as e:
            error_msg = str(e)
            # Don't expose secrets in error messages
            if 'client_secret' in error_msg.lower():
                error_msg = "Authentication failed (check client_id and client_secret)"
            return False, error_msg
            
    except Exception as e:
        return False, "Token test error: {0}".format(str(e))


def main():
    """Main updater flow."""
    if len(sys.argv) != 2:
        print("Usage: python client_secret_update.py <config_path>")
        sys.exit(1)
    
    config_path = sys.argv[1]
    
    clear_screen()
    print_header()
    
    # Load config safely
    print("Loading configuration...")
    config, error = load_config_safe(config_path)
    if error:
        print("ERROR: {0}".format(error))
        print("")
        print("Please ensure the configuration file exists and is valid JSON.")
        input("Press Enter to exit...")
        sys.exit(1)
    
    # Check for MediLink_Config
    if 'MediLink_Config' not in config:
        print("ERROR: Configuration does not contain 'MediLink_Config' section.")
        print("Please ensure the configuration file is properly structured.")
        input("Press Enter to exit...")
        sys.exit(1)
    
    # Discover endpoints
    print("Discovering endpoints...")
    endpoints = discover_endpoints(config)
    
    if not endpoints:
        print("ERROR: No endpoints found in configuration.")
        print("Please configure endpoints in the 'MediLink_Config.endpoints' section.")
        input("Press Enter to exit...")
        sys.exit(1)
    
    print("")
    
    # Display endpoints
    display_endpoints(endpoints)
    
    # Select endpoint
    endpoint_name, endpoint_config = select_endpoint(endpoints)
    if not endpoint_name:
        print("Operation cancelled.")
        input("Press Enter to exit...")
        sys.exit(0)
    
    print("")
    print("Selected endpoint: {0}".format(endpoint_name))
    
    # Warn about missing fields
    warnings = []
    if 'token_url' not in endpoint_config:
        warnings.append("token_url")
    if 'client_id' not in endpoint_config:
        warnings.append("client_id")
    
    if warnings:
        print("WARNING: Endpoint is missing: {0}".format(", ".join(warnings)))
        print("Self-test will be skipped if required fields are missing.")
        print("")
    
    # Get old secret for potential revert
    old_secret = endpoint_config.get('client_secret', '')
    
    # Main update loop (allows retry on test failure)
    while True:
        # Get new secret input
        new_secret = get_secret_input()
        if not new_secret:
            print("Operation cancelled.")
            input("Press Enter to exit...")
            sys.exit(0)
        
        # Validate secret
        is_valid, error_msg = validate_secret(new_secret)
        if not is_valid:
            print("ERROR: {0}".format(error_msg))
            retry = input("Would you like to try again? (Y/N): ").strip().upper()
            if retry not in ['Y', 'YES']:
                print("Operation cancelled.")
                input("Press Enter to exit...")
                sys.exit(0)
            continue
        
        # Confirm update
        print("")
        print("Ready to update client secret for: {0}".format(endpoint_name))
        print("Current secret: {0}".format(mask_secret(old_secret) if old_secret else "[not set]"))
        print("New secret: {0}".format(mask_secret(new_secret)))
        print("")
        
        confirm = input("Proceed with update? (Y/N): ").strip().upper()
        if confirm not in ['Y', 'YES']:
            print("Update cancelled.")
            input("Press Enter to exit...")
            sys.exit(0)
        
        # Create backup
        print("")
        print("Creating backup...")
        backup_path = create_backup(config_path)
        if backup_path:
            print("Backup created: {0}".format(os.path.basename(backup_path)))
        else:
            print("WARNING: Could not create backup")
            proceed = input("Continue without backup? (Y/N): ").strip().upper()
            if proceed not in ['Y', 'YES']:
                print("Update cancelled.")
                input("Press Enter to exit...")
                sys.exit(0)
        
        # Update config
        print("Updating configuration...")
        updated_config = update_config_secret(config, endpoint_name, new_secret)
        if not updated_config:
            print("ERROR: Failed to update configuration.")
            input("Press Enter to exit...")
            sys.exit(1)
        
        # Save config atomically
        print("Saving configuration...")
        success, error = save_config_atomic(config_path, updated_config)
        if not success:
            print("ERROR: {0}".format(error))
            print("Configuration was not saved. Original secret remains unchanged.")
            input("Press Enter to exit...")
            sys.exit(1)
        
        # Clear config cache
        cache_success, cache_error = clear_config_cache()
        if not cache_success:
            print("WARNING: {0}".format(cache_error))
        
        print("Configuration saved successfully!")
        print("")
        
        # Self-test (default ON if internet available and required fields present)
        # Skip test if required fields are missing (as warned earlier)
        if warnings:
            print("Skipping token self-test due to missing required fields: {0}".format(", ".join(warnings)))
            print("")
            print("Client secret update completed successfully.")
            print("Note: Please configure the missing fields and test the secret manually.")
            input("Press Enter to exit...")
            sys.exit(0)
        
        # Note: APIClient will load fresh config from file after cache clear
        try:
            from MediCafe.core_utils import check_internet_connection
            has_internet = check_internet_connection()
        except ImportError:
            # Module not available - assume no internet
            has_internet = False
        except Exception as e:
            # Log but don't fail - assume no internet for safety
            try:
                from MediCafe.MediLink_ConfigLoader import log as config_log
                config_log("Internet check failed: {0}, assuming offline".format(str(e)), level="DEBUG")
            except Exception:
                pass
            has_internet = False
        
        if has_internet:
            # Run test by default
            print("Internet connection detected. Running token self-test...")
            print("")
            
            # APIClient will load the new secret from the saved config file
            success, error_msg = test_token(endpoint_name)
            
            if success:
                print("Token test successful!")
                print("")
                print("Client secret update completed successfully.")
                input("Press Enter to exit...")
                sys.exit(0)
            else:
                print("Token test failed: {0}".format(error_msg))
                print("")
                
                # Offer retry or revert
                retry_choice = input("Would you like to re-enter the secret? (Y/N): ").strip().upper()
                if retry_choice in ['Y', 'YES']:
                    # Restore old secret in config before retry
                    # Reload config to ensure we have latest state
                    config, _ = load_config_safe(config_path)
                    if old_secret:
                        restore_config = update_config_secret(config, endpoint_name, old_secret)
                        if restore_config:
                            save_config_atomic(config_path, restore_config)
                            clear_config_cache()
                            # Update local config reference
                            config = restore_config
                    # Loop back to secret input
                    continue
                else:
                    # Offer revert
                    revert_choice = input("Would you like to revert to the previous secret? (Y/N): ").strip().upper()
                    if revert_choice in ['Y', 'YES']:
                        if old_secret:
                            print("Reverting to previous secret...")
                            # Reload config to ensure we have latest state
                            config, _ = load_config_safe(config_path)
                            revert_config = update_config_secret(config, endpoint_name, old_secret)
                            if revert_config:
                                save_success, save_error = save_config_atomic(config_path, revert_config)
                                if save_success:
                                    clear_config_cache()
                                    print("Reverted to previous secret successfully.")
                                else:
                                    print("ERROR: Failed to revert: {0}".format(save_error))
                            else:
                                print("ERROR: Failed to revert configuration.")
                        else:
                            print("No previous secret to revert to.")
                    print("")
                    print("Client secret update completed (test failed).")
                    input("Press Enter to exit...")
                    sys.exit(0)
        else:
            # No internet - skip test
            print("No internet connection detected. Skipping token self-test.")
            print("")
            print("Client secret update completed successfully.")
            print("Note: You may want to test the new secret manually when internet is available.")
            input("Press Enter to exit...")
            sys.exit(0)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\nOperation interrupted by user.")
        sys.exit(1)
    except Exception as e:
        print("\n\nERROR: Unexpected error: {0}".format(str(e)))
        import traceback
        traceback.print_exc()
        input("Press Enter to exit...")
        sys.exit(1)
