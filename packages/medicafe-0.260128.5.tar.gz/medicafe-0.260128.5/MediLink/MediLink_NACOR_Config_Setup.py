# MediLink_NACOR_Config_Setup.py
# Interactive Configuration Questionnaire for NACOR Export
# Guides users through setting up the nacor_export configuration section
#
# XP / Python 3.4.4 compatible
# ASCII-only UI with clear formatting

from __future__ import print_function

import os
import sys
import re

# Ensure MediCafe module path is available
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

# Import config editor helpers for safe config operations
try:
    from MediBot.config_editor_helpers import (
        load_config_safe,
        save_config_atomic,
        create_backup,
        resolve_config_path
    )
except Exception:
    load_config_safe = None
    save_config_atomic = None
    create_backup = None
    resolve_config_path = None

# Import core utils for config path resolution
try:
    from MediCafe.core_utils import get_shared_config_loader
    MediLink_ConfigLoader = get_shared_config_loader()
except Exception:
    MediLink_ConfigLoader = None


# Required fields for NACOR export configuration (DRY: single source of truth)
NACOR_REQUIRED_FIELDS = [
    'vendor_id', 'vendor_name', 'process_name',
    'submitter_name', 'submitter_email',
    'contact_name', 'contact_email',
    'schema_version', 'submission_type'
]


def _log(message, level="INFO"):
    """Log message using MediLink_ConfigLoader if available."""
    if MediLink_ConfigLoader and hasattr(MediLink_ConfigLoader, 'log'):
        MediLink_ConfigLoader.log(message, level=level)
    else:
        print("[{}] {}".format(level, message))


def _get_default_config_path():
    """Get the default config.json path."""
    default_path = os.path.join(parent_dir, 'json', 'config.json')
    if resolve_config_path:
        return resolve_config_path(default_path)
    return default_path


def _format_section_header(title):
    """Format a section header with consistent styling."""
    return "\n" + "="*60 + "\n" + title + "\n" + "="*60


def _format_field_prompt(field_name, description, example, default=None):
    """Format a field prompt with description and example."""
    lines = []
    lines.append("\n" + "-"*60)
    lines.append("Field: {}".format(field_name))
    lines.append("-"*60)
    lines.append("Description: {}".format(description))
    if example:
        lines.append("Example: {}".format(example))
    if default:
        # Sanitize default for display only (newlines/tabs break prompt layout)
        display_default = str(default).replace('\r', ' ').replace('\n', ' ').replace('\t', ' ')
        display_default = ' '.join(display_default.split()).strip()
        if len(display_default) > 60:
            display_default = display_default[:60] + "..."
        lines.append("Default: {} (press Enter to use)".format(display_default))
    lines.append("-"*60)
    return "\n".join(lines)


def _validate_email(email):
    """Validate email address format."""
    if not email:
        return False, "Email address cannot be empty"
    
    # Simple email regex (compatible with Python 3.4.4)
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    if re.match(pattern, email):
        return True, None
    else:
        return False, "Invalid email format. Please use format: user@example.com"


def _validate_submission_type(value):
    """Validate submission type is 1-4."""
    if not value:
        return False, "Submission type cannot be empty"
    
    try:
        num = int(value)
        if 1 <= num <= 4:
            return True, None
        else:
            return False, "Submission type must be 1, 2, 3, or 4"
    except ValueError:
        return False, "Submission type must be a number (1-4)"


def _prompt_field(field_name, description, example, default=None, validator=None, required=True):
    """
    Prompt user for a field value with validation.
    
    Args:
        field_name: Name of the field
        description: Description of what the field is for
        example: Example value to show
        default: Default value (None if no default)
        validator: Optional validation function that returns (is_valid, error_message)
        required: Whether field is required
    
    Returns:
        str: User input value or default, or None if cancelled
    """
    while True:
        # Display prompt
        prompt_text = _format_field_prompt(field_name, description, example, default)
        print(prompt_text)
        
        # Get input
        if default:
            prompt = "Enter value (or press Enter for default): "
        else:
            prompt = "Enter value: "
        
        user_input = input(prompt).strip()
        
        # Handle empty input
        if not user_input:
            if default:
                return default
            elif not required:
                return None
            else:
                print("Error: This field is required. Please enter a value.")
                continue
        
        # Validate if validator provided
        if validator:
            is_valid, error_msg = validator(user_input)
            if not is_valid:
                print("Error: {}".format(error_msg))
                continue
        
        return user_input


def _display_submission_type_help():
    """Display help text for submission type field."""
    print("\nSubmission Type Options:")
    print("  1 = Billing")
    print("  2 = Quality/Outcomes")
    print("  3 = AIMS only")
    print("  4 = EMR/EHR")


def _collect_nacor_fields_interactive(existing_config=None):
    """
    Collect all NACOR export configuration fields interactively.
    
    Args:
        existing_config: Optional existing config dict to use as defaults
    
    Returns:
        dict: Collected configuration, or None if user cancels
    """
    if existing_config is None:
        existing_config = {}
    
    print(_format_section_header("NACOR Export Configuration Setup"))
    print("\nThis questionnaire will help you configure the NACOR export settings.")
    print("These values will be used in the XML submission header.")
    print("\nYou can press Ctrl+C at any time to cancel.")
    
    try:
        config = {}
        
        # Vendor ID
        config['vendor_id'] = _prompt_field(
            "Vendor ID",
            "Your unique vendor identifier assigned by NACOR",
            "999ZZ99 (placeholder) or ABC12345 (real format)",
            default=existing_config.get('vendor_id'),
            required=True
        )
        
        # Vendor Name
        config['vendor_name'] = _prompt_field(
            "Vendor Name",
            "Your organization or vendor name as registered with NACOR",
            "AQI Sample Vendor or Medical Practice Name",
            default=existing_config.get('vendor_name'),
            required=True
        )
        
        # Process Name
        config['process_name'] = _prompt_field(
            "Process Name",
            "Name of the process/workflow for this submission",
            "AQITestProcess or ProductionSubmission2025",
            default=existing_config.get('process_name'),
            required=True
        )
        
        # Submitter Name
        config['submitter_name'] = _prompt_field(
            "Submitter Name",
            "Full name of the person submitting this data",
            "John Doe or Dr. Jane Smith",
            default=existing_config.get('submitter_name'),
            required=True
        )
        
        # Submitter Email
        config['submitter_email'] = _prompt_field(
            "Submitter Email",
            "Email address of the submitter",
            "j.doe@example.com",
            default=existing_config.get('submitter_email'),
            validator=_validate_email,
            required=True
        )
        
        # Contact Name
        config['contact_name'] = _prompt_field(
            "Contact Name",
            "Full name of the primary contact person",
            "Amanda Doe or Support Team Lead",
            default=existing_config.get('contact_name'),
            required=True
        )
        
        # Contact Email
        config['contact_email'] = _prompt_field(
            "Contact Email",
            "Email address of the contact person",
            "a.doe@example.com",
            default=existing_config.get('contact_email'),
            validator=_validate_email,
            required=True
        )
        
        # Schema Version
        config['schema_version'] = _prompt_field(
            "Schema Version",
            "NACOR XML schema version to use",
            "2025V1.0",
            default=existing_config.get('schema_version', '2025V1.0'),
            required=True
        )
        
        # Submission Type
        _display_submission_type_help()
        submission_type_raw = _prompt_field(
            "Submission Type",
            "Type of submission (1=Billing, 2=Quality/Outcomes, 3=AIMS only, 4=EMR/EHR)",
            "1 (for Billing)",
            default=existing_config.get('submission_type', '1'),
            validator=_validate_submission_type,
            required=True
        )
        # Ensure submission_type is stored as string (used as string in XML)
        config['submission_type'] = str(submission_type_raw) if submission_type_raw else '1'
        
        return config
        
    except KeyboardInterrupt:
        print("\n\nConfiguration setup cancelled by user.")
        return None
    except Exception as e:
        _log("Error during configuration collection: {}".format(e), level="ERROR")
        print("\nError: {}".format(e))
        return None


def _display_config_summary(config):
    """Display a summary of the collected configuration."""
    print(_format_section_header("Configuration Summary"))
    print("\nPlease review your configuration:")
    print("-"*60)
    for key, value in sorted(config.items()):
        # Handle None or empty values
        if not value:
            print("  {}: (empty)".format(key))
            continue
        
        # Convert to string for display
        value_str = str(value)
        
        # Mask email addresses partially for display
        if 'email' in key.lower() and '@' in value_str:
            parts = value_str.split('@')
            if len(parts) == 2 and len(parts[0]) > 2:
                masked = parts[0][:2] + '*' * (len(parts[0]) - 2) + '@' + parts[1]
            elif len(parts) == 2:
                masked = '*' * len(parts[0]) + '@' + parts[1]
            else:
                masked = value_str  # Fallback if split fails
            print("  {}: {}".format(key, masked))
        else:
            print("  {}: {}".format(key, value_str))
    print("-"*60)


def _save_nacor_config(config_dict, config_path=None):
    """
    Save NACOR configuration to config.json.
    
    Args:
        config_dict: Dictionary with nacor_export configuration
        config_path: Optional path to config.json (defaults to standard location)
    
    Returns:
        tuple: (success: bool, error_message: str or None)
    """
    if not save_config_atomic or not load_config_safe:
        return False, "Config editor helpers not available"
    
    if config_path is None:
        config_path = _get_default_config_path()
    
    # Load existing config
    existing_config, load_error = load_config_safe(config_path)
    if load_error and not os.path.exists(config_path):
        # File doesn't exist, create new structure
        existing_config = {}
    elif load_error:
        return False, "Error loading config: {}".format(load_error)
    
    # Ensure MediLink_Config section exists
    if 'MediLink_Config' not in existing_config:
        existing_config['MediLink_Config'] = {}
    
    # Update nacor_export section
    existing_config['MediLink_Config']['nacor_export'] = config_dict
    
    # Create backup
    if create_backup:
        backup_path = create_backup(config_path)
        if backup_path:
            _log("Backup created: {}".format(backup_path), level="INFO")
    
    # Save config
    success, error = save_config_atomic(config_path, existing_config)
    if success:
        _log("NACOR configuration saved successfully to {}".format(config_path), level="INFO")
        # Clear config cache if available
        try:
            from MediBot.config_editor_helpers import clear_config_cache
            if clear_config_cache:
                cache_success, cache_error = clear_config_cache()
                if cache_error:
                    _log("Warning: Could not clear config cache: {}".format(cache_error), level="WARNING")
        except Exception as e:
            _log("Warning: Could not clear config cache: {}".format(e), level="WARNING")
        return True, None
    else:
        return False, error


def collect_nacor_config_interactive(config_path=None):
    """
    Main entry point: Collect NACOR configuration interactively and save to config.json.
    
    Args:
        config_path: Optional path to config.json (defaults to standard location)
    
    Returns:
        dict: Saved configuration dict, or None if cancelled/failed
    """
    if config_path is None:
        config_path = _get_default_config_path()
    
    # Load existing config to use as defaults
    existing_nacor_config = {}
    if load_config_safe:
        existing_config, _ = load_config_safe(config_path)
        if existing_config:
            existing_nacor_config = existing_config.get('MediLink_Config', {}).get('nacor_export', {})
    
    # Collect configuration
    new_config = _collect_nacor_fields_interactive(existing_nacor_config)
    
    if not new_config:
        return None
    
    # Display summary
    _display_config_summary(new_config)
    
    # Confirm save
    print("\n")
    while True:
        confirm = input("Save this configuration? (Y/N): ").strip().upper()
        if confirm in ['Y', 'YES']:
            break
        elif confirm in ['N', 'NO']:
            print("Configuration not saved.")
            return None
        else:
            print("Please enter Y for Yes or N for No.")
    
    # Save configuration
    success, error = _save_nacor_config(new_config, config_path)
    
    if success:
        print("\n" + "="*60)
        print("Configuration saved successfully!")
        print("="*60)
        return new_config
    else:
        print("\n" + "="*60)
        print("Error saving configuration: {}".format(error))
        print("="*60)
        return None


def is_nacor_config_complete(nacor_config):
    """
    Check if nacor_export config has all required fields.
    
    Args:
        nacor_config: Dictionary with nacor_export configuration
    
    Returns:
        bool: True if all required fields are present and non-empty
    """
    if not nacor_config:
        return False
    
    # Check each required field exists and is non-empty
    # Explicitly handle None, empty strings, and other falsy values for clarity
    for field in NACOR_REQUIRED_FIELDS:
        value = nacor_config.get(field)
        
        # None or missing key
        if value is None:
            return False
        
        # Empty string (whitespace-only strings are also considered empty)
        if isinstance(value, str) and not value.strip():
            return False
        
        # Other falsy values (0, False, [], {}, etc.) are invalid
        # Note: All our required fields should have truthy, non-empty values
        if not value:
            return False
    
    return True
