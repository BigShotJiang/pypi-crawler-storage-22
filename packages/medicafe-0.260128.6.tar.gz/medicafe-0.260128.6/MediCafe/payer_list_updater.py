# MediCafe/payer_list_updater.py
"""
Payer List Auto-Update Module for OPTUMAI

Downloads and parses the Optum Real Payer List Excel file to automatically
update the OPTUMAI payer ID list in the crosswalk storage.

Compatible with Python 3.4.4 and Windows XP environments.
"""

import os
import sys
import hashlib
from datetime import datetime

# Set project directory
project_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if project_dir not in sys.path:
    sys.path.insert(0, project_dir)

# Import configuration loader
try:
    from MediCafe.core_utils import get_shared_config_loader
    MediLink_ConfigLoader = get_shared_config_loader()
except ImportError:
    try:
        from MediCafe.MediLink_ConfigLoader import MediLink_ConfigLoader
    except ImportError:
        # Fallback - create minimal logger
        class MinimalLogger:
            def log(self, msg, level="INFO", console_output=False):
                if console_output:
                    print("[{}] {}".format(level, msg))
        MediLink_ConfigLoader = MinimalLogger()

# Import crosswalk utilities
try:
    from MediBot.MediBot_Crosswalk_Utils import save_crosswalk, ensure_full_config_loaded
except ImportError:
    save_crosswalk = None
    ensure_full_config_loaded = None

# Import requests for HTTP downloads
try:
    import requests
    # Suppress InsecureRequestWarning for XP-compatible verify=False calls
    try:
        import warnings
        from requests.packages.urllib3.exceptions import InsecureRequestWarning
        warnings.simplefilter('ignore', InsecureRequestWarning)
    except Exception:
        pass
except ImportError:
    requests = None

# Import openpyxl for Excel parsing (Python 3.4.4 compatible version: 2.4.11)
try:
    from openpyxl import load_workbook
except ImportError:
    load_workbook = None

# Default configuration values
DEFAULT_EXCEL_URL = "https://dev.documents.real-payer-np.optum.com/Optum%20Real%20Payer%20List%20by%20API.xlsx"
DEFAULT_CADENCE_DAYS = 90
DEFAULT_CACHE_DIR = os.path.join(project_dir, "cache", "payer_lists")

# Required packages for payer list updates (used for warnings and upgrade-tool alignment)
PAYER_LIST_REQUIRED_DEPS = [
    ('requests', 'requests==2.21.0'),
    ('openpyxl', 'openpyxl==2.4.11'),
]


def check_payer_list_dependencies():
    """
    Check if required dependencies for payer list updates are available.
    Logs a WARNING with install guidance for each missing package.

    Returns:
        list: Pairs (package_name, pip_spec) for missing packages, e.g. [('openpyxl', 'openpyxl==2.4.11')].
    """
    missing = []
    if not requests:
        missing.append(PAYER_LIST_REQUIRED_DEPS[0])
    if not load_workbook:
        missing.append(PAYER_LIST_REQUIRED_DEPS[1])
    if missing:
        try:
            specs = [spec for _name, spec in missing]
            MediLink_ConfigLoader.log(
                "OPTUMAI payer list update requires missing package(s): {}. "
                "Install with: pip install {}".format(
                    ", ".join(name for name, _ in missing),
                    " ".join(specs),
                ),
                level="WARNING"
            )
        except Exception:
            pass
    return missing


def ensure_single_xlsx(cache_dir):
    """
    Keep at most one Optum_Payer_List_*.xlsx in cache_dir. If more than one
    exist, keep the newest (by mtime) and remove the rest.

    Returns:
        tuple: (files_removed: int, error: str or None)
    """
    try:
        if not os.path.exists(cache_dir):
            return 0, None

        excel_files = []
        for filename in os.listdir(cache_dir):
            if filename.endswith('.xlsx') and "Optum_Payer_List" in filename:
                path = os.path.join(cache_dir, filename)
                try:
                    excel_files.append((os.path.getmtime(path), path))
                except Exception:
                    continue

        if len(excel_files) <= 1:
            return 0, None

        excel_files.sort(reverse=True)  # newest first
        files_removed = 0
        for _mtime, path in excel_files[1:]:
            try:
                os.remove(path)
                files_removed += 1
            except Exception as e:
                MediLink_ConfigLoader.log(
                    "Failed to remove old Excel file {}: {}".format(path, str(e)),
                    level="WARNING"
                )
        if files_removed > 0:
            MediLink_ConfigLoader.log(
                "Cleaned up {} old Excel files from cache (kept newest only)".format(files_removed),
                level="INFO"
            )
        return files_removed, None
    except Exception as e:
        return 0, "Error ensuring single xlsx: {}".format(str(e))


def download_payer_list_excel(url, cache_dir, timeout=30):
    """
    Download Excel file from Optum URL with error handling.
    
    Args:
        url (str): Excel file URL
        cache_dir (str): Directory to cache downloaded files
        timeout (int): HTTP request timeout in seconds (default: 30)
    
    Returns:
        tuple: (success: bool, file_path: str or None, error: str or None)
    """
    if not requests:
        return False, None, "requests library not available"
    
    try:
        # Ensure cache directory exists
        if not os.path.exists(cache_dir):
            try:
                os.makedirs(cache_dir)
            except Exception as e:
                return False, None, "Failed to create cache directory: {}".format(str(e))
        
        # Generate filename with timestamp
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = "Optum_Payer_List_{}.xlsx".format(timestamp)
        file_path = os.path.join(cache_dir, filename)
        temp_path = file_path + ".tmp"
        
        # Download with verify=False for XP compatibility (matches existing pattern)
        try:
            response = requests.get(url, timeout=timeout, verify=False, stream=True)
            response.raise_for_status()
        except requests.exceptions.Timeout:
            return False, None, "Download timeout after {} seconds".format(timeout)
        except requests.exceptions.HTTPError as e:
            return False, None, "HTTP error {}: {}".format(e.response.status_code if hasattr(e, 'response') else 'unknown', str(e))
        except requests.exceptions.RequestException as e:
            return False, None, "Network error: {}".format(str(e))
        
        # Stream download to file (atomic write)
        try:
            with open(temp_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    if chunk:
                        f.write(chunk)
            # Atomic rename
            if os.path.exists(file_path):
                try:
                    os.remove(file_path)
                except Exception:
                    pass
            os.rename(temp_path, file_path)
            return True, file_path, None
        except IOError as e:
            # Clean up temp file on error
            try:
                if os.path.exists(temp_path):
                    os.remove(temp_path)
            except Exception:
                pass
            return False, None, "File write error: {}".format(str(e))
    except Exception as e:
        return False, None, "Unexpected error: {}".format(str(e))


def _normalize_yn(value):
    """Normalize Y/N cell value to bool. Y/y/Yes -> True, else False."""
    if value is None:
        return False
    s = str(value).strip().upper()
    if s in ('Y', 'YES'):
        return True
    return False


# Feature column header variants (case-insensitive match after strip)
# Feature-to-endpoint mapping:
# - eligibility -> OPTUMAI eligibility_optumai
# - submit_with_precheck -> OPTUMAI claim_actions (claim submission)
# - search_277ca -> OPTUMAI claims_inquiry (post-submission acknowledgement)
OPTUMAI_FEATURE_KEYS = (
    'eligibility',
    'submit_with_precheck',
    'search_277ca',
    'search_claim',
)
_FEATURE_HEADERS = {
    'eligibility': ['ELIGIBILITY'],
    'submit_with_precheck': ['SUBMIT W/PRE-CHECK', 'SUBMIT WITH PRE-CHECK'],
    'search_277ca': ['SEARCH 277CA', 'SEACH 277CA'],
    'search_claim': ['SEARCH CLAIM'],
}
for _key in OPTUMAI_FEATURE_KEYS:
    if _key not in _FEATURE_HEADERS:
        _FEATURE_HEADERS[_key] = []


def parse_payer_list_from_excel(file_path):
    """
    Parse Excel file and extract payer IDs plus per-payer feature flags.
    Detects columns: Payer ID, Eligibility, Submit w/Pre-Check, Search 277CA, Search Claim.

    Returns:
        tuple: (success: bool, payer_ids: list, payers_dict: dict, error: str or None)
        payers_dict maps payer_id -> {eligibility, submit_with_precheck, search_277ca, search_claim} (bools).
    """
    if not load_workbook:
        return False, [], {}, "openpyxl library not available"

    try:
        # read_only=False uses the regular Worksheet path and avoids get_squared_range
        # deprecation warnings from openpyxl 2.4.x read_only implementation.
        wb = load_workbook(file_path, read_only=False, data_only=True)
        sheet = wb.active
        payer_ids = []
        payers_dict = {}
        sheets_to_try = [sheet] + [wb[sheet_name] for sheet_name in wb.sheetnames if wb[sheet_name] != sheet]

        for current_sheet in sheets_to_try:
            try:
                header_row = None
                data_start_row = None
                payer_id_col = None
                feature_cols = {}  # feature_key -> col_idx

                for row_idx in range(1, min(11, current_sheet.max_row + 1)):
                    row = current_sheet[row_idx]
                    for col_idx, cell in enumerate(row, 1):
                        cell_value = str(cell.value).strip() if cell.value else ""
                        u = cell_value.upper()
                        if u in ["PAYER ID", "PAYERID", "PAYER_ID", "PAYER CODE", "PAYERCODE"]:
                            header_row = row_idx
                            payer_id_col = col_idx
                            data_start_row = row_idx + 1
                            break
                    if header_row is not None:
                        break

                if not header_row or not payer_id_col:
                    payer_id_col = 2
                    data_start_row = 3

                # Scan header row for feature columns
                header_row_cells = current_sheet[header_row]
                for col_idx, cell in enumerate(header_row_cells, 1):
                    h = (str(cell.value).strip() if cell.value else "").upper()
                    if not h:
                        continue
                    for feat_key, variants in _FEATURE_HEADERS.items():
                        if feat_key in feature_cols:
                            continue
                        if any(h == v for v in variants):
                            feature_cols[feat_key] = col_idx
                            break

                found_ids = set()
                payers_dict = {}

                for row_idx in range(data_start_row, current_sheet.max_row + 1):
                    cell = current_sheet.cell(row=row_idx, column=payer_id_col)
                    raw_value = cell.value
                    if raw_value is None:
                        cell_value = ""
                    elif isinstance(raw_value, (int, float)):
                        if isinstance(raw_value, float) and raw_value.is_integer():
                            raw_value = int(raw_value)
                        cell_value = str(raw_value).strip()
                    else:
                        cell_value = str(raw_value).strip()

                    if not cell_value or len(cell_value) < 3 or len(cell_value) > 10:
                        continue
                    if not (cell_value.isdigit() or (cell_value.isalnum() and len(cell_value) <= 6)):
                        continue

                    found_ids.add(cell_value)
                    entry = {}
                    for feat_key in OPTUMAI_FEATURE_KEYS:
                        if feat_key in feature_cols:
                            entry[feat_key] = _normalize_yn(
                                current_sheet.cell(row=row_idx, column=feature_cols[feat_key]).value
                            )
                        else:
                            entry[feat_key] = False
                    payers_dict[cell_value] = entry

                if found_ids:
                    payer_ids = sorted(list(found_ids))
                    MediLink_ConfigLoader.log(
                        "Parsed {} payer IDs and feature flags from sheet '{}'".format(len(payer_ids), current_sheet.title),
                        level="INFO"
                    )
                    break
            except Exception:
                continue

        if getattr(wb, "close", None) is not None:
            wb.close()

        if not payer_ids:
            return False, [], {}, "No valid payer IDs found in Excel file"

        return True, payer_ids, payers_dict, None
    except Exception as e:
        return False, [], {}, "Error parsing Excel file: {}".format(str(e))


def parse_payer_ids_from_excel(file_path):
    """
    Parse Excel file and extract payer IDs with auto-detection.
    Backward-compatible wrapper; use parse_payer_list_from_excel for feature flags.

    Returns:
        tuple: (success: bool, payer_ids: list, error: str or None)
    """
    ok, payer_ids, _payers, err = parse_payer_list_from_excel(file_path)
    if not ok:
        return False, [], err
    return True, payer_ids, None


def _parse_last_update_iso(last_update_str):
    """
    Parse last_update ISO string from optum_payer_list metadata.
    Returns datetime or None on missing/unparseable.
    """
    if not last_update_str or not isinstance(last_update_str, str):
        return None
    try:
        s = last_update_str.replace('Z', '').split('+')[0].split('.')[0]
        return datetime.strptime(s, '%Y-%m-%dT%H:%M:%S')
    except Exception:
        return None


def _persist_payer_list_error(crosswalk, client, config, error_message):
    """
    Persist optum_payer_list with last_error and last_update_attempt so downstream
    logic can detect "data unavailable" rather than treating missing payers as feature=N.
    """
    now_iso = datetime.now().isoformat() + 'Z'
    existing_opl = crosswalk.get('optum_payer_list') or {}
    existing_meta = existing_opl.get('metadata') or {}
    metadata = {
        'last_update': existing_meta.get('last_update'),
        'last_update_attempt': now_iso,
        'update_source': existing_meta.get('update_source'),
        'excel_file_hash': existing_meta.get('excel_file_hash'),
        'update_count': existing_meta.get('update_count', 0),
        'last_error': error_message,
    }
    crosswalk['optum_payer_list'] = {
        'payer_ids': existing_opl.get('payer_ids') or [],
        'metadata': metadata,
        'payers': existing_opl.get('payers') or {},
    }
    if save_crosswalk:
        try:
            save_crosswalk(client, config, crosswalk, skip_api_operations=True)
        except Exception as e:
            MediLink_ConfigLoader.log(
                "Failed to persist payer list error metadata: {}".format(str(e)),
                level="WARNING"
            )


def _should_update_from_optum_payer_list(crosswalk, cadence_days=90):
    """
    Determine if payer list update is needed from crosswalk['optum_payer_list'].

    Returns:
        tuple: (should_update: bool, days_since_update: int or None)
    """
    try:
        opl = crosswalk.get('optum_payer_list') or {}
        metadata = opl.get('metadata') or {}
        last_update_str = metadata.get('last_update')
        if not last_update_str:
            return True, None

        last_update = _parse_last_update_iso(last_update_str)
        if last_update is None:
            return True, None
        days_since = (datetime.now() - last_update).days
        return days_since >= cadence_days, days_since
    except Exception:
        return True, None


def get_optumai_payer_ids_from_crosswalk(crosswalk):
    """
    Helper to extract payer IDs from crosswalk['endpoint_payer_ids']['OPTUMAI'] (fallback).
    """
    try:
        endpoint_payer_ids = crosswalk.get('endpoint_payer_ids', {})
        payer_ids = endpoint_payer_ids.get('OPTUMAI')
        if payer_ids and isinstance(payer_ids, list) and len(payer_ids) > 0:
            return payer_ids
        return None
    except Exception:
        return None


def optumai_supports_feature(crosswalk, payer_id, feature):
    """
    Check whether a payer supports an OPTUMAI feature per optum_payer_list.payers.

    feature: one of OPTUMAI_FEATURE_KEYS.
    Returns False if crosswalk/payers missing, payer not in payers, or feature unknown.
    """
    try:
        if not crosswalk or not isinstance(crosswalk, dict) or not payer_id:
            return False
        opl = crosswalk.get('optum_payer_list') or {}
        payers = opl.get('payers')
        if not payers or not isinstance(payers, dict):
            return False
        entry = payers.get(str(payer_id).strip())
        if not entry or not isinstance(entry, dict):
            return False
        key = str(feature).strip()
        if key not in OPTUMAI_FEATURE_KEYS:
            return False
        return bool(entry.get(key, False))
    except Exception:
        return False


def get_optumai_payer_ids(crosswalk=None, config=None):
    """
    Resolve OPTUMAI payer IDs: optum_payer_list first, then endpoint_payer_ids, else None.
    Callers (e.g. api_core) fall back to hardcoded list when None.
    """
    if not crosswalk or not isinstance(crosswalk, dict):
        return None
    opl = crosswalk.get('optum_payer_list') or {}
    payer_ids = opl.get('payer_ids')
    if payer_ids and isinstance(payer_ids, list) and len(payer_ids) > 0:
        return payer_ids
    return get_optumai_payer_ids_from_crosswalk(crosswalk)


def update_optumai_payer_ids(client, config, crosswalk, force=False):
    """
    Main update function that orchestrates download, parse, and save.
    Persists to crosswalk['optum_payer_list'] only. Success only when save_crosswalk succeeds.
    """
    try:
        medi_config = config.get('MediLink_Config', {}) if isinstance(config, dict) else {}
        payer_list_config = medi_config.get('payer_list_updates', {}) or {}
        updates_enabled = payer_list_config.get('enabled', True)
        cadence_days = payer_list_config.get('cadence_days', DEFAULT_CADENCE_DAYS)
        excel_url = payer_list_config.get('excel_url') or payer_list_config.get('optumai_excel_url') or DEFAULT_EXCEL_URL
        cache_dir = payer_list_config.get('cache_dir', DEFAULT_CACHE_DIR)

        MediLink_ConfigLoader.log(
            "OPTUMAI payer list update check started (force={})".format(bool(force)),
            level="INFO"
        )

        check_payer_list_dependencies()

        if not updates_enabled:
            return False, 0, "Payer list updates disabled in configuration"

        if not os.path.exists(cache_dir):
            try:
                os.makedirs(cache_dir)
            except Exception as e:
                return False, 0, "Failed to create cache directory: {}".format(str(e))

        ensure_single_xlsx(cache_dir)

        if not force:
            should_update, days_since = _should_update_from_optum_payer_list(crosswalk, cadence_days)
            if not should_update:
                return False, 0, "Update not needed (last update {} days ago, cadence: {} days)".format(
                    days_since or 'unknown', cadence_days
                )
            opl = crosswalk.get('optum_payer_list') or {}
            meta = opl.get('metadata') or {}
            last_dt = _parse_last_update_iso(meta.get('last_update'))
            if last_dt is not None:
                secs = (datetime.now() - last_dt).total_seconds()
                if 0 <= secs < 60:
                    return False, 0, "Update completed recently ({} seconds ago, skipping to avoid duplicate)".format(
                        int(secs)
                    )

        success, file_path, error = download_payer_list_excel(excel_url, cache_dir)
        if not success:
            err_msg = "Download failed: {}".format(error)
            _persist_payer_list_error(crosswalk, client, config, err_msg)
            return False, 0, err_msg

        success, payer_ids, payers_dict, error = parse_payer_list_from_excel(file_path)
        if not success:
            err_msg = "Parse failed: {}".format(error)
            _persist_payer_list_error(crosswalk, client, config, err_msg)
            return False, 0, err_msg
        if not payer_ids or len(payer_ids) == 0:
            err_msg = "No valid payer IDs extracted from Excel"
            _persist_payer_list_error(crosswalk, client, config, err_msg)
            return False, 0, err_msg

        file_hash = None
        try:
            with open(file_path, 'rb') as f:
                file_hash = hashlib.sha256(f.read()).hexdigest()
        except Exception:
            pass

        now_iso = datetime.now().isoformat() + 'Z'
        existing_opl = crosswalk.get('optum_payer_list') or {}
        existing_meta = existing_opl.get('metadata') or {}
        update_count = existing_meta.get('update_count', 0) + 1

        metadata = {
            'last_update': now_iso,
            'last_update_attempt': now_iso,
            'update_source': 'excel_download',
            'excel_file_hash': file_hash,
            'update_count': update_count,
            'last_error': None,
        }
        # Only set optum_payer_list. Never touch payer_id, mapat_mapping, endpoint_payer_ids, etc.
        # save_crosswalk writes the full crosswalk; we merge into it, not replace it.
        crosswalk['optum_payer_list'] = {
            'payer_ids': payer_ids,
            'metadata': metadata,
            'payers': payers_dict if isinstance(payers_dict, dict) else {},
        }

        # Update crosswalk payer endpoints when OPTUMAI supports claim submission for the payer
        endpoint_updates = 0
        if isinstance(payers_dict, dict):
            payer_id_map = crosswalk.get('payer_id')
            if not isinstance(payer_id_map, dict):
                payer_id_map = {}
                crosswalk['payer_id'] = payer_id_map
            for pid, entry in payers_dict.items():
                try:
                    if not entry or not entry.get('submit_with_precheck'):
                        continue
                    payer_key = str(pid).strip()
                    if not payer_key:
                        continue
                    payer_entry = payer_id_map.get(payer_key)
                    if not isinstance(payer_entry, dict):
                        payer_entry = {}
                        payer_id_map[payer_key] = payer_entry
                    if payer_entry.get('endpoint') != 'OPTUMAI':
                        payer_entry['endpoint'] = 'OPTUMAI'
                        endpoint_updates += 1
                except Exception:
                    continue
        if endpoint_updates > 0:
            MediLink_ConfigLoader.log(
                "Updated {} payer endpoint(s) to OPTUMAI based on submit_with_precheck=Y.".format(endpoint_updates),
                level="INFO"
            )

        if not save_crosswalk:
            MediLink_ConfigLoader.log(
                "Warning: save_crosswalk not available; payer list update not persisted",
                level="WARNING"
            )
            return False, 0, "save_crosswalk not available"
        try:
            ok = save_crosswalk(client, config, crosswalk, skip_api_operations=True)
        except Exception as e:
            MediLink_ConfigLoader.log(
                "Warning: Failed to save crosswalk after payer list update: {}".format(str(e)),
                level="WARNING"
            )
            return False, 0, "Save failed: {}".format(str(e))
        if not ok:
            MediLink_ConfigLoader.log(
                "Warning: save_crosswalk returned False; payer list update not persisted",
                level="WARNING"
            )
            return False, 0, "Save failed: save_crosswalk returned False"

        MediLink_ConfigLoader.log(
            "Successfully updated OPTUMAI payer list: {} payers".format(len(payer_ids)),
            level="INFO"
        )
        ensure_single_xlsx(cache_dir)
        return True, len(payer_ids), None
    except Exception as e:
        return False, 0, "Unexpected error: {}".format(str(e))
