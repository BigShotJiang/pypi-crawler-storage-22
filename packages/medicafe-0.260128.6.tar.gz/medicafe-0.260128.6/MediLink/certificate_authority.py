"""
Lightweight Certificate Authority helper for MediLink Gmail HTTPS server.

Provides idempotent helpers for creating a local root CA, issuing managed
server certificates, and surfacing status metadata for diagnostics/UI layers.

Python 3.4.4 compatible – avoids pathlib/f-strings.
"""

from __future__ import print_function

import os
import shutil
import subprocess
import tempfile
import time

try:
    from MediCafe.core_utils import get_shared_config_loader
    _config_loader = get_shared_config_loader()
    if _config_loader:
        _central_log = _config_loader.log
    else:
        _central_log = None
except Exception:
    _central_log = None

try:
    from MediLink.gmail_http_utils import get_certificate_fingerprint as _get_fingerprint
except Exception:
    _get_fingerprint = None


class CertificateAuthorityError(Exception):
    """Raised when managed CA operations fail."""

_ROOT_INSTALL_ATTEMPTED = False
_ROOT_CLEANUP_ATTEMPTED = False


def _log(message, level="INFO", log_fn=None):
    fn = log_fn or _central_log
    if fn:
        try:
            fn(message, level=level)
            return
        except Exception:
            pass
    try:
        print("[{}] {}".format(level, message))
    except Exception:
        pass


def resolve_default_ca_dir(local_storage_path=None):
    """
    Resolve a writable directory for storing CA artifacts.

    Preference order:
        1. %APPDATA%/MediLink/ca
        2. %LOCALAPPDATA%/MediLink/ca
        3. <local_storage_path>/ca (if provided)
        4. Current working directory ./ca
        5. System temp directory /tmp/medilink_ca
    """
    candidates = []
    appdata = os.environ.get('APPDATA')
    if appdata:
        candidates.append(os.path.join(appdata, 'MediLink', 'ca'))
    local_appdata = os.environ.get('LOCALAPPDATA')
    if local_appdata:
        candidates.append(os.path.join(local_appdata, 'MediLink', 'ca'))
    if local_storage_path:
        candidates.append(os.path.join(local_storage_path, 'ca'))
    candidates.append(os.path.join(os.getcwd(), 'ca'))
    candidates.append(os.path.join(tempfile.gettempdir(), 'medilink_ca'))

    for path in candidates:
        if not path:
            continue
        try:
            if not os.path.exists(path):
                os.makedirs(path)
            return path
        except Exception:
            continue
    # Fallback – temp dir should always be available
    fallback = os.path.join(tempfile.gettempdir(), 'medilink_ca_fallback')
    if not os.path.exists(fallback):
        os.makedirs(fallback)
    return fallback


def create_profile(profile_name,
                   storage_root,
                   server_cert_path,
                   server_key_path,
                   openssl_config=None,
                   san_list=None,
                   root_subject=None,
                   server_subject=None,
                   csr_path=None):
    """Return a profile dict capturing all CA paths/settings."""
    profile_dir = os.path.join(storage_root, profile_name or 'default')
    san_values = list(san_list or ['127.0.0.1', 'localhost'])
    profile = {
        'name': profile_name or 'default',
        'storage_root': storage_root,
        'profile_dir': profile_dir,
        'root_key_path': os.path.join(profile_dir, 'myroot.key'),
        'root_cert_path': os.path.join(profile_dir, 'myroot.crt'),
        'serial_path': os.path.join(profile_dir, 'myroot.srl'),
        'server_cert_path': server_cert_path,
        'server_key_path': server_key_path,
        'server_csr_path': csr_path or (server_cert_path + '.csr'),
        'openssl_config': openssl_config,
        'san_list': san_values,
        'root_subject': root_subject or '/CN=MediLink Local Root CA',
        'server_subject': server_subject or '/CN=127.0.0.1',
        'root_valid_days': 3650,
        'root_key_bits': 2048,
        'server_key_bits': 2048,
        'server_valid_days': 365,
        'server_validity_margin_seconds': 86400,
        'openssl_bin': 'openssl',
    }
    return profile


def ensure_managed_certificate(profile, log=None, subprocess_module=subprocess):
    """
    Ensure root CA assets and the downstream server certificate are present/valid.

    Returns a status dict suitable for diagnostics payloads.
    """
    if not profile:
        raise CertificateAuthorityError("Profile is required for managed certificate flow")

    log_fn = lambda msg, level="INFO": _log(msg, level, log)

    ensure_root(profile, log=log_fn, subprocess_module=subprocess_module)
    issue_server_cert(profile, log=log_fn, subprocess_module=subprocess_module)

    root_cert_path = profile.get('root_cert_path')
    server_cert_path = profile.get('server_cert_path')
    openssl_bin = profile.get('openssl_bin') or 'openssl'
    if root_cert_path and server_cert_path and os.path.exists(root_cert_path) and os.path.exists(server_cert_path):
        if not _issuer_matches_root(server_cert_path, root_cert_path, openssl_bin, log_fn):
            log_fn("Managed server certificate issuer mismatch; forcing reissue.", level="WARNING")
            _safe_unlink(server_cert_path, log_fn)
            _safe_unlink(profile.get('server_key_path'), log_fn)
            _safe_unlink(profile.get('server_csr_path'), log_fn)
            issue_server_cert(profile, log=log_fn, subprocess_module=subprocess_module)
    _maybe_install_root_cert(profile, log_fn)
    return describe_status(profile, log=log_fn)


def repair_managed_certificate(profile, log=None, subprocess_module=subprocess, force_root=False):
    """
    Repair managed CA assets by reissuing the server certificate and re-installing the root.

    force_root: When True, regenerate the root CA (requires browser re-trust).
    """
    if not profile:
        raise CertificateAuthorityError("Profile is required for managed certificate repair")

    log_fn = lambda msg, level="INFO": _log(msg, level, log)

    # Allow cleanup/install to run again during a repair cycle.
    global _ROOT_INSTALL_ATTEMPTED
    global _ROOT_CLEANUP_ATTEMPTED
    _ROOT_INSTALL_ATTEMPTED = False
    _ROOT_CLEANUP_ATTEMPTED = False

    if force_root:
        _safe_unlink(profile.get('root_cert_path'), log_fn)
        _safe_unlink(profile.get('root_key_path'), log_fn)
        _safe_unlink(profile.get('serial_path'), log_fn)

    _safe_unlink(profile.get('server_cert_path'), log_fn)
    _safe_unlink(profile.get('server_key_path'), log_fn)
    _safe_unlink(profile.get('server_csr_path'), log_fn)

    ensure_root(profile, log=log_fn, subprocess_module=subprocess_module)
    issue_server_cert(profile, log=log_fn, subprocess_module=subprocess_module)
    _maybe_install_root_cert(profile, log_fn, force=True)
    return describe_status(profile, log=log_fn)


def ensure_root(profile, log=None, subprocess_module=subprocess):
    """Create root key/cert if missing or nearing expiry."""
    log_fn = lambda msg, level="INFO": _log(msg, level, log)
    _ensure_directory(profile.get('profile_dir'), log_fn)

    root_cert = profile.get('root_cert_path')
    root_key = profile.get('root_key_path')
    openssl_bin = profile.get('openssl_bin') or 'openssl'
    margin = profile.get('root_validity_margin_seconds', 604800)  # default 7 days

    if root_cert and os.path.exists(root_cert):
        if _is_cert_valid(root_cert, margin, subprocess_module, openssl_bin, log_fn):
            if _has_ca_extensions(root_cert, openssl_bin, log_fn):
                return
            log_fn("Root certificate missing CA extensions; regenerating.", level="WARNING")
        else:
            log_fn("Root certificate near expiry or invalid; regenerating.", level="WARNING")

    root_key_bits = profile.get('root_key_bits', 2048)
    root_days = profile.get('root_valid_days', 3650)
    root_subject = profile.get('root_subject') or '/CN=MediLink Local Root CA'

    # Ensure subject starts with at least one slash for OpenSSL
    if root_subject and not root_subject.startswith('/'):
        root_subject = '/' + root_subject

    if not root_key or not os.path.exists(root_key):
        _run_cmd(
            [openssl_bin, 'genrsa', '-out', root_key, str(root_key_bits)],
            subprocess_module,
            log_fn,
            "Generating CA root key"
        )

    # CRITICAL ISSUE: Root certificate must have CA:TRUE and keyCertSign extensions
    # Problem: `openssl req -x509` does NOT support the `-extfile` flag (only `openssl x509` does).
    # Attempted solution: Two-step process:
    #   1. Generate initial certificate with `req -x509` (without extensions)
    #   2. Use `x509` command to copy and add CA extensions via `-extfile`
    # 
    # CURRENT STATUS: This approach may still not work correctly. The `x509` command with `-extfile`
    # might not properly apply extensions when copying an existing certificate. The root cert
    # verification below may still show CA:FALSE even after this two-step process.
    #
    # FUTURE DEBUGGING: If root cert still shows CA:FALSE after generation:
    #   - Check if `openssl x509 -in <temp> -out <final> -extensions v3_ca -extfile <ext>` actually applies extensions
    #   - Consider using `openssl ca` command instead (requires more setup but more reliable)
    #   - Alternative: Generate cert with a custom openssl.cnf that has x509_extensions = v3_ca in [req] section
    #   - Verify OpenSSL version: older versions may have different behavior with extension handling
    #
    # INSTRUMENTATION POINT: Log the exact OpenSSL commands executed and their output.
    # Also log the verification results (has_ca_true, has_key_cert_sign) to confirm extensions were applied.
    generated = _generate_root_ca_with_config(
        root_key=root_key,
        root_cert=root_cert,
        root_days=root_days,
        root_subject=root_subject,
        openssl_bin=openssl_bin,
        log_fn=log_fn,
        subprocess_module=subprocess_module
    )
    if not generated:
        temp_cert = root_cert + '.tmp'
        cmd = [
            openssl_bin, 'req', '-x509', '-new', '-sha256',
            '-days', str(root_days),
            '-key', root_key,
            '-out', temp_cert,
            '-subj', root_subject
        ]

        openssl_cnf = profile.get('openssl_config')
        if openssl_cnf and os.path.exists(openssl_cnf):
            cmd.extend(['-config', openssl_cnf])
        else:
            possible_cnfs = [
                os.path.join(os.path.dirname(os.path.abspath(__file__)), 'openssl.cnf'),
                'C:\\OpenSSL-Win32\\bin\\openssl.cnf',
                'C:\\OpenSSL-Win64\\bin\\openssl.cnf',
                'C:\\Program Files\\OpenSSL-Win64\\bin\\openssl.cnf'
            ]
            for cnf in possible_cnfs:
                if os.path.exists(cnf):
                    cmd.extend(['-config', cnf])
                    break

        _run_cmd(cmd, subprocess_module, log_fn, "Generating initial root certificate")

        ext_file = None
        try:
            import tempfile
            ext_fd, ext_file = tempfile.mkstemp(suffix='.cnf', text=True)
            ext_content = '[ v3_ca ]\n'
            ext_content += 'basicConstraints = critical,CA:TRUE\n'
            ext_content += 'keyUsage = critical, keyCertSign, cRLSign\n'
            ext_content += 'subjectKeyIdentifier = hash\n'
            ext_content += 'authorityKeyIdentifier = keyid:always,issuer:always\n'
            with os.fdopen(ext_fd, 'w') as f:
                f.write(ext_content)
        except Exception as ext_err:
            log_fn("Failed to create root CA extension file: {}. Root cert may be invalid.".format(ext_err), level="WARNING")
            ext_file = None

        if ext_file:
            ext_cmd = [
                openssl_bin, 'x509', '-in', temp_cert,
                '-out', root_cert,
                '-extensions', 'v3_ca',
                '-extfile', ext_file
            ]
            _run_cmd(ext_cmd, subprocess_module, log_fn, "Adding CA extensions to root certificate")
            if os.path.exists(temp_cert):
                try:
                    os.unlink(temp_cert)
                except Exception:
                    pass
            if os.path.exists(ext_file):
                try:
                    os.unlink(ext_file)
                except Exception:
                    pass
        else:
            if os.path.exists(temp_cert):
                try:
                    if os.path.exists(root_cert):
                        os.unlink(root_cert)
                    os.rename(temp_cert, root_cert)
                except Exception as rename_err:
                    log_fn("Failed to rename temp cert: {}".format(rename_err), level="WARNING")
    
    # Verify the root certificate was created with correct extensions
    # INSTRUMENTATION POINT: This verification is critical - log the full OpenSSL output
    # and the boolean flags (has_ca_true, has_key_cert_sign) to confirm extensions were applied.
    # If verification fails, the root cert will be rejected by browsers even if installed.
    if root_cert and os.path.exists(root_cert):
        try:
            if not _has_ca_extensions(root_cert, openssl_bin, log_fn):
                log_fn("WARNING: Root certificate missing CA extensions after regeneration.", level="WARNING")
        except Exception as verify_err:
            log_fn("Could not verify root certificate extensions: {}".format(verify_err), level="WARNING")

def _read_cert_subject_issuer(cert_path, openssl_bin, log_fn):
    try:
        out = subprocess.check_output(
            [openssl_bin, 'x509', '-in', cert_path, '-noout', '-subject', '-issuer'],
            stderr=subprocess.STDOUT
        ).decode('utf-8', errors='ignore')
    except Exception as exc:
        log_fn("Failed to read certificate metadata for {}: {}".format(cert_path, exc), level="DEBUG")
        return None
    subject = None
    issuer = None
    for line in out.splitlines():
        line = line.strip()
        if line.startswith('subject='):
            subject = line.split('=', 1)[1].strip()
        elif line.startswith('issuer='):
            issuer = line.split('=', 1)[1].strip()
    return {'subject': subject, 'issuer': issuer}


def _normalize_dn(value):
    if value is None:
        return ''
    return ''.join(str(value).lower().split())


def _write_root_ca_config():
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix='.cnf')
    lines = [
        '[ req ]',
        'prompt = no',
        'distinguished_name = req_distinguished_name',
        'x509_extensions = v3_ca',
        '',
        '[ req_distinguished_name ]',
        'CN = MediLink Managed Root CA',
        '',
        '[ v3_ca ]',
        'basicConstraints = critical,CA:TRUE',
        'keyUsage = critical, keyCertSign, cRLSign',
        'subjectKeyIdentifier = hash',
        'authorityKeyIdentifier = keyid:always,issuer:always'
    ]
    tmp.write('\n'.join(lines).encode('utf-8'))
    tmp.close()
    return tmp.name


def _generate_root_ca_with_config(root_key, root_cert, root_days, root_subject,
                                  openssl_bin, log_fn, subprocess_module):
    cfg_path = None
    try:
        cfg_path = _write_root_ca_config()
        cmd = [
            openssl_bin, 'req', '-x509', '-new', '-sha256',
            '-days', str(root_days),
            '-key', root_key,
            '-out', root_cert,
            '-subj', root_subject,
            '-extensions', 'v3_ca',
            '-config', cfg_path
        ]
        _run_cmd(cmd, subprocess_module, log_fn, "Generating root certificate with CA extensions")
        return True
    except Exception as exc:
        log_fn("Failed to generate root CA with dedicated config: {}".format(exc), level="WARNING")
        return False
    finally:
        if cfg_path and os.path.exists(cfg_path):
            try:
                os.unlink(cfg_path)
            except Exception:
                pass


def _has_ca_extensions(cert_path, openssl_bin, log_fn):
    try:
        output = subprocess.check_output(
            [openssl_bin, 'x509', '-in', cert_path, '-text', '-noout'],
            stderr=subprocess.STDOUT
        ).decode('utf-8', errors='ignore')
    except Exception as exc:
        log_fn("Unable to read CA extensions for {}: {}".format(cert_path, exc), level="DEBUG")
        return False
    has_ca_true = 'CA:TRUE' in output
    has_key_cert_sign = 'keyCertSign' in output or 'Certificate Sign' in output
    return bool(has_ca_true and has_key_cert_sign)


def _extract_cn(subject_value):
    if not subject_value:
        return None
    value = subject_value
    if 'CN=' in value:
        parts = value.split('CN=')
        value = parts[-1]
    elif 'CN =' in value:
        parts = value.split('CN =')
        value = parts[-1]
    value = value.strip()
    if value.startswith('/'):
        value = value[1:]
    return value.strip() if value else None


def _root_in_store(root_cert, log_fn, user_store=True):
    openssl_bin = 'openssl'
    token = 'MediLink Managed Root CA'
    current_serial = None
    try:
        details = _collect_cert_details(root_cert, openssl_bin)
        subject = details.get('subject')
        current_serial = _normalize_serial(details.get('serial'))
        token = _extract_cn(subject) or token
    except Exception:
        pass
    cmd = ['certutil']
    if user_store:
        cmd.append('-user')
    cmd.extend(['-store', 'Root'])
    try:
        output = subprocess.check_output(cmd, stderr=subprocess.STDOUT).decode('utf-8', errors='ignore')
        entries = _parse_certutil_entries(output)
        for entry in entries:
            serial = _normalize_serial(entry.get('serial'))
            if current_serial and serial == current_serial:
                return True
            subject_line = entry.get('subject') or ''
            if token and token.lower() in subject_line.lower():
                return True
        return False
    except Exception:
        return False


def _normalize_serial(value):
    if not value:
        return ''
    hex_chars = '0123456789abcdef'
    cleaned = []
    for ch in str(value):
        if ch.lower() in hex_chars:
            cleaned.append(ch.lower())
    return ''.join(cleaned)


def _parse_certutil_entries(output_text):
    entries = []
    current = None
    for raw_line in output_text.splitlines():
        line = raw_line.strip()
        if not line:
            continue
        lower = line.lower()
        if lower.startswith('serial number:'):
            serial_raw = line.split(':', 1)[1].strip()
            serial_norm = _normalize_serial(serial_raw)
            current = {'serial': serial_norm, 'subject': None}
            entries.append(current)
        elif lower.startswith('subject:'):
            subject = line.split(':', 1)[1].strip()
            if current is None:
                current = {'serial': None, 'subject': subject}
                entries.append(current)
            else:
                current['subject'] = subject
    return entries


def _delete_root_by_serial(serial, user_store, log_fn):
    if not serial:
        return False
    cmd = ['certutil']
    if user_store:
        cmd.append('-user')
    cmd.extend(['-delstore', 'Root', serial])
    try:
        result = subprocess.call(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        if result == 0:
            log_fn("Removed stale root cert {} from {} store.".format(serial, 'user' if user_store else 'machine'), level="INFO")
            return True
        log_fn("certutil returned non-zero exit code {} when deleting root {} from {} store.".format(
            result, serial, 'user' if user_store else 'machine'), level="WARNING")
    except Exception as exc:
        log_fn("Failed to delete root {} from {} store: {}".format(
            serial, 'user' if user_store else 'machine', exc), level="WARNING")
    return False


def _cleanup_root_store(profile, log_fn, force=False):
    global _ROOT_CLEANUP_ATTEMPTED
    if _ROOT_CLEANUP_ATTEMPTED and not force:
        return
    auto_cleanup = profile.get('auto_cleanup_root_ca')
    if auto_cleanup is False and not force:
        return
    root_cert = profile.get('root_cert_path')
    if not root_cert or not os.path.exists(root_cert):
        return
    try:
        openssl_bin = profile.get('openssl_bin') or 'openssl'
        details = _collect_cert_details(root_cert, openssl_bin)
        current_serial = _normalize_serial(details.get('serial'))
        subject = details.get('subject')
        token = (_extract_cn(subject) or 'MediLink Managed Root CA').lower()
    except Exception:
        return
    if not current_serial:
        return
    _ROOT_CLEANUP_ATTEMPTED = True

    for user_store in (True, False):
        cmd = ['certutil']
        if user_store:
            cmd.append('-user')
        cmd.extend(['-store', 'Root'])
        try:
            output = subprocess.check_output(cmd, stderr=subprocess.STDOUT).decode('utf-8', errors='ignore')
        except Exception:
            continue
        entries = _parse_certutil_entries(output)
        for entry in entries:
            serial = _normalize_serial(entry.get('serial'))
            if not serial or serial == current_serial:
                continue
            subject_line = entry.get('subject') or ''
            if token in subject_line.lower():
                _delete_root_by_serial(serial, user_store, log_fn)


def _issuer_matches_root(server_cert, root_cert, openssl_bin, log_fn):
    server_info = _read_cert_subject_issuer(server_cert, openssl_bin, log_fn)
    root_info = _read_cert_subject_issuer(root_cert, openssl_bin, log_fn)
    if not server_info or not root_info:
        return False
    server_issuer = _normalize_dn(server_info.get('issuer'))
    root_subject = _normalize_dn(root_info.get('subject'))
    if not server_issuer or not root_subject:
        return False
    return server_issuer == root_subject


def _server_cert_has_aki(cert_path, openssl_bin, log_fn):
    try:
        output = subprocess.check_output(
            [openssl_bin, 'x509', '-in', cert_path, '-text', '-noout'],
            stderr=subprocess.STDOUT
        ).decode('utf-8', errors='ignore')
    except Exception as exc:
        log_fn("Unable to read server certificate AKI for {}: {}".format(cert_path, exc), level="DEBUG")
        return False
    return 'Authority Key Identifier' in output


def _server_cert_has_required_extensions(cert_path, openssl_bin, log_fn):
    try:
        output = subprocess.check_output(
            [openssl_bin, 'x509', '-in', cert_path, '-text', '-noout'],
            stderr=subprocess.STDOUT
        ).decode('utf-8', errors='ignore')
    except Exception as exc:
        log_fn("Unable to read server certificate extensions for {}: {}".format(cert_path, exc), level="DEBUG")
        return False
    lower = output.lower()
    has_san = 'subject alternative name' in lower and ('127.0.0.1' in lower or 'localhost' in lower)
    has_eku = 'extended key usage' in lower and ('server auth' in lower or 'web server authentication' in lower)
    has_key_usage = 'key usage' in lower and ('digital signature' in lower) and ('key encipherment' in lower)
    return bool(has_san and has_eku and has_key_usage)


def issue_server_cert(profile, log=None, san_list=None, subprocess_module=subprocess):
    """
    Issue or refresh the managed server certificate for the HTTPS listener.
    """
    log_fn = lambda msg, level="INFO": _log(msg, level, log)
    openssl_bin = profile.get('openssl_bin') or 'openssl'

    server_cert = profile.get('server_cert_path')
    server_key = profile.get('server_key_path')
    server_csr = profile.get('server_csr_path') or (server_cert + '.csr')
    server_days = profile.get('server_valid_days', 365)
    margin = profile.get('server_validity_margin_seconds', 86400)

    if server_cert and os.path.exists(server_cert):
        if _is_cert_valid(server_cert, margin, subprocess_module, openssl_bin, log_fn):
            root_cert_path = profile.get('root_cert_path')
            if root_cert_path and os.path.exists(root_cert_path):
                if _issuer_matches_root(server_cert, root_cert_path, openssl_bin, log_fn):
                    if _server_cert_has_aki(server_cert, openssl_bin, log_fn) and _server_cert_has_required_extensions(server_cert, openssl_bin, log_fn):
                        return
                    log_fn("Managed server certificate missing required extensions; reissuing.", level="WARNING")
                else:
                    log_fn("Managed server certificate not issued by managed root; reissuing.", level="WARNING")
            else:
                log_fn("Managed root certificate missing; reissuing server certificate.", level="WARNING")
        else:
            log_fn("Managed server certificate requires renewal.", level="INFO")

    _ensure_parent_directory(server_cert, log_fn)

    if not server_key or not os.path.exists(server_key):
        key_bits = profile.get('server_key_bits', 2048)
        _run_cmd(
            [openssl_bin, 'genrsa', '-out', server_key, str(key_bits)],
            subprocess_module,
            log_fn,
            "Generating server private key"
        )

    server_subject = profile.get('server_subject') or '/CN=127.0.0.1'
    # Ensure subject starts with at least one slash for OpenSSL
    if server_subject and not server_subject.startswith('/'):
        server_subject = '/' + server_subject

    cmd = [
        openssl_bin, 'req', '-new', '-sha256',
        '-key', server_key,
        '-out', server_csr,
        '-subj', server_subject
    ]
    openssl_cnf = profile.get('openssl_config')
    if openssl_cnf and os.path.exists(openssl_cnf):
        cmd.extend(['-config', openssl_cnf])
    else:
        possible_cnfs = [
            os.path.join(os.path.dirname(os.path.abspath(__file__)), 'openssl.cnf'),
            'C:\\OpenSSL-Win32\\bin\\openssl.cnf',
            'C:\\OpenSSL-Win64\\bin\\openssl.cnf',
            'C:\\Program Files\\OpenSSL-Win64\\bin\\openssl.cnf'
        ]
        for cnf in possible_cnfs:
            if os.path.exists(cnf):
                cmd.extend(['-config', cnf])
                break
    _run_cmd(cmd, subprocess_module, log_fn, "Creating server CSR")

    san_file = None
    san_values = san_list if san_list is not None else profile.get('san_list')
    try:
        ext_args = []
        if san_values:
            san_file = _write_san_extension_file(san_values)
            if san_file:
                ext_args = ['-extfile', san_file, '-extensions', 'v3_req']

        sign_cmd = [
            openssl_bin, 'x509', '-req',
            '-in', server_csr,
            '-CA', profile.get('root_cert_path'),
            '-CAkey', profile.get('root_key_path'),
            '-out', server_cert,
            '-days', str(server_days),
            '-sha256'
        ]

        serial_path = profile.get('serial_path')
        if serial_path:
            sign_cmd.extend(['-CAserial', serial_path])
            if not os.path.exists(serial_path):
                sign_cmd.append('-CAcreateserial')
        else:
            sign_cmd.append('-CAcreateserial')

        if ext_args:
            sign_cmd.extend(ext_args)

        _run_cmd(sign_cmd, subprocess_module, log_fn, "Signing server certificate with managed root")
    finally:
        if san_file and os.path.exists(san_file):
            try:
                os.unlink(san_file)
            except Exception:
                pass


def export_root(profile, destination_path, log=None):
    """Copy the root certificate to a destination path for Firefox import."""
    log_fn = lambda msg, level="INFO": _log(msg, level, log)
    root_cert = profile.get('root_cert_path')
    if not root_cert or not os.path.exists(root_cert):
        raise CertificateAuthorityError("Root certificate not found; run ensure_root first.")
    _ensure_parent_directory(destination_path, log_fn)
    shutil.copyfile(root_cert, destination_path)
    log_fn("Exported managed root certificate to {}".format(destination_path))


def describe_status(profile, log=None):
    """Return metadata about the managed CA and issued server cert."""
    openssl_bin = profile.get('openssl_bin') or 'openssl'
    status = {
        'profile': profile.get('name', 'default'),
        'storage': profile.get('profile_dir'),
        'root': _collect_cert_details(profile.get('root_cert_path'), openssl_bin),
        'server': _collect_cert_details(profile.get('server_cert_path'), openssl_bin),
        'san': profile.get('san_list') or [],
        'server_cert_path': profile.get('server_cert_path'),
        'root_cert_path': profile.get('root_cert_path'),
        'mode': 'managed_ca',
        'root_installed_user': _root_in_store(profile.get('root_cert_path'), log, user_store=True),
        'root_installed_machine': _root_in_store(profile.get('root_cert_path'), log, user_store=False)
    }
    if _get_fingerprint and profile.get('server_cert_path'):
        try:
            status['server'].update(_get_fingerprint(profile['server_cert_path']))
        except Exception:
            pass
    return status


def _ensure_directory(path, log_fn):
    if not path:
        raise CertificateAuthorityError("Profile directory not provided")
    if not os.path.exists(path):
        os.makedirs(path)
        log_fn("Created CA storage directory at {}".format(path))


def _ensure_parent_directory(path, log_fn):
    parent = os.path.dirname(os.path.abspath(path))
    if parent and not os.path.exists(parent):
        os.makedirs(parent)
        log_fn("Created directory {}".format(parent))


def _safe_unlink(path, log_fn):
    if not path:
        return
    try:
        if os.path.exists(path):
            os.unlink(path)
            log_fn("Deleted stale certificate artifact {}".format(path), level="DEBUG")
    except Exception as exc:
        log_fn("Unable to delete {}: {}".format(path, exc), level="WARNING")


def _maybe_install_root_cert(profile, log_fn, force=False):
    global _ROOT_INSTALL_ATTEMPTED
    if _ROOT_INSTALL_ATTEMPTED and not force:
        return
    try:
        import platform
        if platform.system() != 'Windows':
            return
    except Exception:
        return
    root_cert = profile.get('root_cert_path')
    if not root_cert or not os.path.exists(root_cert):
        return
    auto_install = profile.get('auto_install_root_ca')
    if auto_install is False and not force:
        return
    _cleanup_root_store(profile, log_fn, force=force)
    _ROOT_INSTALL_ATTEMPTED = True
    try:
        cmd = ['certutil', '-user', '-addstore', 'Root', root_cert]
        result = subprocess.call(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        if result == 0:
            log_fn("Installed managed root certificate into Windows user store.", level="INFO")
        else:
            log_fn("certutil returned non-zero exit code {} when installing root.".format(result), level="WARNING")
    except Exception as exc:
        log_fn("Unable to install managed root certificate automatically: {}".format(exc), level="WARNING")
        result = 1

    user_store_ok = _root_in_store(root_cert, log_fn, user_store=True)
    if force or not user_store_ok:
        if not user_store_ok:
            log_fn("Managed root not found in Windows user store after install; attempting machine store.", level="WARNING")
        else:
            log_fn("Attempting machine-store install of managed root (repair mode).", level="INFO")
        try:
            cmd = ['certutil', '-addstore', 'Root', root_cert]
            result = subprocess.call(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            if result == 0 and _root_in_store(root_cert, log_fn, user_store=False):
                log_fn("Installed managed root certificate into Windows machine store.", level="INFO")
            elif result != 0:
                log_fn("certutil returned non-zero exit code {} when installing root to machine store.".format(result), level="WARNING")
        except Exception as exc:
            log_fn("Unable to install managed root certificate into machine store: {}".format(exc), level="WARNING")


def _run_cmd(cmd, subprocess_module, log_fn, description):
    log_fn("{}: {}".format(description, ' '.join(cmd)), level="DEBUG")
    # INSTRUMENTATION POINT: Log all OpenSSL commands executed here to debug certificate generation issues.
    # Log the full command, exit code, and any stderr output to identify command failures.
    result = subprocess_module.call(cmd)
    if result != 0:
        raise CertificateAuthorityError("{} failed with exit code {}".format(description, result))


def _is_cert_valid(cert_path, threshold_seconds, subprocess_module, openssl_bin, log_fn):
    if not cert_path or not os.path.exists(cert_path):
        return False
    try:
        cmd = [openssl_bin, 'x509', '-in', cert_path, '-checkend', str(int(threshold_seconds)), '-noout']
        result = subprocess_module.call(cmd, stdout=subprocess_module.PIPE, stderr=subprocess_module.PIPE)
        return result == 0
    except Exception as exc:
        log_fn("Certificate validation check failed for {}: {}".format(cert_path, exc), level="DEBUG")
        return False


def _write_san_extension_file(san_entries):
    if not san_entries:
        return None
    formatted = []
    for entry in san_entries:
        value = (entry or '').strip()
        if not value:
            continue
        if _looks_like_ip(value):
            formatted.append('IP:{}'.format(value))
        else:
            formatted.append('DNS:{}'.format(value))
    if not formatted:
        return None
    lines = [
        '[v3_req]',
        'basicConstraints = CA:FALSE',
        'subjectAltName = {}'.format(', '.join(formatted)),
        'extendedKeyUsage = serverAuth, clientAuth',
        'keyUsage = digitalSignature, keyEncipherment',
        'subjectKeyIdentifier = hash',
        'authorityKeyIdentifier = keyid,issuer'
    ]
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix='.cnf')
    tmp.write('\n'.join(lines).encode('utf-8'))
    tmp.close()
    return tmp.name


def _looks_like_ip(value):
    if ':' in value:
        return True  # treat IPv6-ish as IP
    parts = value.split('.')
    if len(parts) != 4:
        return False
    for part in parts:
        if not part.isdigit():
            return False
        num = int(part)
        if num < 0 or num > 255:
            return False
    return True


def _collect_cert_details(cert_path, openssl_bin):
    info = {
        'present': bool(cert_path and os.path.exists(cert_path)),
        'subject': None,
        'issuer': None,
        'notBefore': None,
        'notAfter': None,
        'serial': None
    }
    if not info['present']:
        return info
    try:
        cmd = [openssl_bin, 'x509', '-in', cert_path, '-noout', '-subject', '-issuer', '-enddate', '-serial']
        output = subprocess.check_output(cmd, stderr=subprocess.STDOUT)
        data = output.decode('utf-8', errors='ignore').splitlines()
        for line in data:
            if line.startswith('subject='):
                info['subject'] = line.split('subject=', 1)[1].strip()
            elif line.startswith('issuer='):
                info['issuer'] = line.split('issuer=', 1)[1].strip()
            elif line.startswith('notAfter='):
                info['notAfter'] = line.split('notAfter=', 1)[1].strip()
            elif line.startswith('serial='):
                info['serial'] = line.split('serial=', 1)[1].strip()
        # Approximate notBefore via -dates if needed
        try:
            cmd_dates = [openssl_bin, 'x509', '-in', cert_path, '-noout', '-dates']
            dates_output = subprocess.check_output(cmd_dates, stderr=subprocess.STDOUT)
            for line in dates_output.decode('utf-8', errors='ignore').splitlines():
                if line.startswith('notBefore='):
                    info['notBefore'] = line.split('notBefore=', 1)[1].strip()
                elif line.startswith('notAfter=') and not info['notAfter']:
                    info['notAfter'] = line.split('notAfter=', 1)[1].strip()
        except Exception:
            pass
    except Exception:
        pass
    return info
