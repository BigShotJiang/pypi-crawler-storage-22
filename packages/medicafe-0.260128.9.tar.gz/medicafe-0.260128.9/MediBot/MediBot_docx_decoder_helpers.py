# MediBot_docx_decoder_helpers.py
import re

# Pre-compile regex patterns for better performance (XP/3.4.4 compatible)
_DAY_WEEK_PATTERN = re.compile(r"(MONDAY|TUESDAY|WEDNESDAY|THURSDAY|FRIDAY|SATURDAY|SUNDAY)")
_MONTH_DAY_PATTERN = re.compile(
    r"(JANUARY|FEBRUARY|MARCH|APRIL|MAY|JUNE|JULY|AUGUST|SEPTEMBER|OCTOBER|NOVEMBER|DECEMBER) \d{1,2}"
)
_YEAR_PATTERN = re.compile(r"\d{4}")
_YEAR_SPLIT_PATTERNS = [
    re.compile(r'(\d{3}) (\d{1})'),
    re.compile(r'(\d{1}) (\d{3})'),
    re.compile(r'(\d{2}) (\d{2})')
]
_DAY_SPLIT_REASSEMBLY_PATTERN = re.compile(
    r'((?:JANUARY|FEBRUARY|MARCH|APRIL|MAY|JUNE|JULY|AUGUST|SEPTEMBER|OCTOBER|NOVEMBER|DECEMBER))\s+(\d{1})\s+(\d{1})\b',
    re.IGNORECASE
)
_DIGIT_PARTS_PATTERN = re.compile(r'\b(\d{1,2})\b')
_COMMA_PATTERN = re.compile(r',')
_MONTH_NAMES = (
    'JANUARY', 'FEBRUARY', 'MARCH', 'APRIL', 'MAY', 'JUNE',
    'JULY', 'AUGUST', 'SEPTEMBER', 'OCTOBER', 'NOVEMBER', 'DECEMBER'
)

# Pre-compile abbreviation patterns for normalize_text optimization
_MONTH_ABBR_PATTERNS = {
    'JAN': re.compile(r'\bJAN\b', re.IGNORECASE),
    'FEB': re.compile(r'\bFEB\b', re.IGNORECASE),
    'MAR': re.compile(r'\bMAR\b', re.IGNORECASE),
    'APR': re.compile(r'\bAPR\b', re.IGNORECASE),
    'MAY': re.compile(r'\bMAY\b', re.IGNORECASE),
    'JUN': re.compile(r'\bJUN\b', re.IGNORECASE),
    'JUL': re.compile(r'\bJUL\b', re.IGNORECASE),
    'AUG': re.compile(r'\bAUG\b', re.IGNORECASE),
    'SEP': re.compile(r'\bSEP\b', re.IGNORECASE),
    'OCT': re.compile(r'\bOCT\b', re.IGNORECASE),
    'NOV': re.compile(r'\bNOV\b', re.IGNORECASE),
    'DEC': re.compile(r'\bDEC\b', re.IGNORECASE)
}

_DAY_ABBR_PATTERNS = {
    'MON': re.compile(r'\bMON\b', re.IGNORECASE),
    'TUE': re.compile(r'\bTUE\b', re.IGNORECASE),
    'WED': re.compile(r'\bWED\b', re.IGNORECASE),
    'THU': re.compile(r'\bTHU\b', re.IGNORECASE),
    'FRI': re.compile(r'\bFRI\b', re.IGNORECASE),
    'SAT': re.compile(r'\bSAT\b', re.IGNORECASE),
    'SUN': re.compile(r'\bSUN\b', re.IGNORECASE)
}

# Month and day mapping dictionaries
_MONTH_MAP = {
    'JAN': 'JANUARY', 'FEB': 'FEBRUARY', 'MAR': 'MARCH', 'APR': 'APRIL',
    'MAY': 'MAY', 'JUN': 'JUNE', 'JUL': 'JULY', 'AUG': 'AUGUST',
    'SEP': 'SEPTEMBER', 'OCT': 'OCTOBER', 'NOV': 'NOVEMBER', 'DEC': 'DECEMBER'
}
_DAY_MAP = {
    'MON': 'MONDAY', 'TUE': 'TUESDAY', 'WED': 'WEDNESDAY', 'THU': 'THURSDAY',
    'FRI': 'FRIDAY', 'SAT': 'SATURDAY', 'SUN': 'SUNDAY'
}


def reassemble_day(text):
    """
    Handles cases where the day of the month is split into two single digits,
    e.g., 'DECEMBER 1 1' -> 'DECEMBER 11'.
    Uses the pre-compiled _DAY_SPLIT_REASSEMBLY_PATTERN for performance.
    """
    return _DAY_SPLIT_REASSEMBLY_PATTERN.sub(r'\1 \2\3', text)


def normalize_text(text):
    # Optimized single-pass processing to avoid O(n2) complexity
    # Process all abbreviations in one pass instead of multiple regex calls
    for abbr, pattern in _MONTH_ABBR_PATTERNS.items():
        text = pattern.sub(_MONTH_MAP[abbr], text)
    for abbr, pattern in _DAY_ABBR_PATTERNS.items():
        text = pattern.sub(_DAY_MAP[abbr], text)

    return text


def reassemble_year(text):
    # Optimized year reassembly with early exit conditions
    # First, handle the most common cases with pre-compiled patterns
    for pattern in _YEAR_SPLIT_PATTERNS:
        text = pattern.sub(r'\1\2', text)

    # Handle the less common cases where the year might be split as (1,1,2) or (2,1,1) or (1,2,1)
    parts = _DIGIT_PARTS_PATTERN.findall(text)
    parts_len = len(parts)
    if parts_len >= 4:
        # PERFORMANCE FIX: Use direct indexing instead of range(len()) pattern
        max_index = parts_len - 3
        for i in range(max_index):
            candidate = ''.join(parts[i:i + 4])
            if len(candidate) == 4 and candidate.isdigit():
                # More efficient pattern construction
                pattern_parts = [r'\b' + part + r'\b' for part in parts[i:i + 4]]
                pattern = r'\s+'.join(pattern_parts)
                text = re.sub(pattern, candidate, text)
                break  # Early exit after first successful combination

    return text


def get_header_window(text, target, window_size=300):
    try:
        match = re.search(re.escape(target), text, re.IGNORECASE)
        if match:
            start = match.start()
            return text[start:start + window_size]
    except Exception:
        pass
    return text[:window_size]


def _levenshtein_with_max(a, b, max_dist):
    if a == b:
        return 0
    if not a or not b:
        return len(a) + len(b) if max_dist >= (len(a) + len(b)) else None
    if abs(len(a) - len(b)) > max_dist:
        return None

    # Standard DP with early exit if the row minimum exceeds max_dist.
    prev_row = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur_row = [i]
        row_min = i
        for j, cb in enumerate(b, 1):
            insert_cost = cur_row[j - 1] + 1
            delete_cost = prev_row[j] + 1
            replace_cost = prev_row[j - 1] + (0 if ca == cb else 1)
            cost = insert_cost if insert_cost < delete_cost else delete_cost
            if replace_cost < cost:
                cost = replace_cost
            cur_row.append(cost)
            if cost < row_min:
                row_min = cost
        if row_min > max_dist:
            return None
        prev_row = cur_row
    return prev_row[-1] if prev_row[-1] <= max_dist else None


def _resolve_month_token(token, max_dist=2):
    if not token:
        return None
    token = re.sub(r'[^A-Z]', '', token.upper())
    if not token:
        return None
    if token in _MONTH_MAP:
        return _MONTH_MAP[token]
    if token in _MONTH_NAMES:
        return token
    if token in _DAY_MAP.values():
        return None

    best_match = None
    best_dist = None
    for month in _MONTH_NAMES:
        dist = _levenshtein_with_max(token, month, max_dist)
        if dist is None:
            continue
        if best_dist is None or dist < best_dist:
            best_match = month
            best_dist = dist
    return best_match


def extract_fuzzy_month_day(text, log_prefix="", logger=None, max_dist=2):
    for match in re.finditer(r'\b([A-Z]{3,12})\s+(\d{1,2})\b', text, re.IGNORECASE):
        raw_token = match.group(1)
        day = match.group(2)
        month_name = _resolve_month_token(raw_token, max_dist=max_dist)
        if month_name:
            if logger and raw_token.upper() != month_name:
                logger.log(
                    "{}Fuzzy month match: '{}' -> '{}' (day {}).".format(log_prefix, raw_token, month_name, day),
                    level="DEBUG"
                )
            return month_name, day
    return None
