"""
x12_utils.py - X12 837p member data extraction utilities

Purpose:
- Extract member data from X12 837p files for submission context queries
- Parse X12 segments (NM1*IL, DMG, DTP*472, NM1*PR)
- Provides data in format needed for OPTUMAI member-based searches

Compatible with: Windows XP SP3, Python 3.4.4, ASCII-only
"""
import os

try:
    from MediCafe.core_utils import get_shared_config_loader
    MediLink_ConfigLoader = get_shared_config_loader()
except ImportError:
    MediLink_ConfigLoader = None


def extract_member_id_from_x12(x12_data):
    """
    Extract member ID from X12 837 data (NM1*IL segment).
    
    X12 format for insured/member:
    NM1*IL*1*LAST_NAME*FIRST_NAME*MIDDLE*SUFFIX*PREFIX*MI*MEMBER_ID
    
    Args:
        x12_data: X12 837 formatted claim data
    
    Returns:
        str: Member ID if found, empty string otherwise
    """
    if not x12_data:
        return ''
    
    try:
        segments = x12_data.split('~')
        for segment in segments:
            if segment.startswith('NM1*IL'):
                fields = segment.split('*')
                # NM1*IL*1*LAST*FIRST****MI*MEMBER_ID
                # Index: 0=NM1, 1=IL, 2=1, 3=last, 4=first, 5=middle, 6=suffix, 7=prefix, 8=MI, 9=member_id
                if len(fields) >= 10:
                    member_id = fields[9]
                    if member_id:
                        return member_id.strip()
    except Exception:
        pass
    
    return ''


def extract_member_name_from_x12(x12_data):
    """
    Extract member first and last name from X12 837 data (NM1*IL segment).
    
    Args:
        x12_data: X12 837 formatted claim data
    
    Returns:
        tuple: (first_name, last_name) if found, ('', '') otherwise
    """
    if not x12_data:
        return ('', '')
    
    try:
        segments = x12_data.split('~')
        for segment in segments:
            if segment.startswith('NM1*IL'):
                fields = segment.split('*')
                # NM1*IL*1*LAST*FIRST****MI*MEMBER_ID
                if len(fields) >= 5:
                    last_name = fields[3].strip() if len(fields) > 3 else ''
                    first_name = fields[4].strip() if len(fields) > 4 else ''
                    return (first_name, last_name)
    except Exception:
        pass
    
    return ('', '')


def extract_member_dob_from_x12(x12_data):
    """
    Extract member date of birth from X12 837 data (DMG segment).
    
    X12 format for demographics:
    DMG*D8*YYYYMMDD*GENDER
    
    Args:
        x12_data: X12 837 formatted claim data
    
    Returns:
        str: Date of birth in MM/DD/YYYY format if found, empty string otherwise
    """
    if not x12_data:
        return ''
    
    try:
        segments = x12_data.split('~')
        for segment in segments:
            if segment.startswith('DMG*'):
                fields = segment.split('*')
                # DMG*D8*YYYYMMDD*GENDER
                # Index: 0=DMG, 1=D8, 2=YYYYMMDD, 3=gender
                if len(fields) >= 3 and fields[1] == 'D8':
                    dob = fields[2]
                    # Convert YYYYMMDD to MM/DD/YYYY
                    if len(dob) == 8 and dob.isdigit():
                        year = dob[0:4]
                        month = dob[4:6]
                        day = dob[6:8]
                        return "{}/{}/{}".format(month, day, year)
    except Exception:
        pass
    
    return ''


def extract_service_dates_from_x12(x12_data):
    """
    Extract service dates from X12 837 data (DTP*472 segment).
    
    X12 format for service dates:
    DTP*472*D8*YYYYMMDD (single date)
    DTP*472*RD8*YYYYMMDD-YYYYMMDD (date range)
    
    Args:
        x12_data: X12 837 formatted claim data
    
    Returns:
        tuple: (service_start_date, service_end_date) in MM/DD/YYYY format
               Returns ('', '') if not found
    """
    if not x12_data:
        return ('', '')
    
    try:
        segments = x12_data.split('~')
        for segment in segments:
            if segment.startswith('DTP*472'):
                fields = segment.split('*')
                # DTP*472*D8*YYYYMMDD or DTP*472*RD8*YYYYMMDD-YYYYMMDD
                # Index: 0=DTP, 1=472, 2=qualifier, 3=date(s)
                if len(fields) >= 4:
                    qualifier = fields[2]
                    date_value = fields[3]
                    
                    if qualifier == 'D8':
                        # Single date
                        formatted_date = _format_x12_date(date_value)
                        return (formatted_date, formatted_date)
                    elif qualifier == 'RD8':
                        # Date range: YYYYMMDD-YYYYMMDD
                        if '-' in date_value:
                            dates = date_value.split('-')
                            if len(dates) == 2:
                                start_date = _format_x12_date(dates[0])
                                end_date = _format_x12_date(dates[1])
                                return (start_date, end_date)
    except Exception:
        pass
    
    return ('', '')


def extract_payer_id_from_x12(x12_data):
    """
    Extract payer ID from X12 837 data (NM1*PR segment).
    
    Reuses existing function from claim_actions_adapter.py pattern.
    
    Args:
        x12_data: X12 837 formatted claim data
    
    Returns:
        str: Payer ID if found, empty string otherwise
    """
    if not x12_data:
        return ''
    
    try:
        segments = x12_data.split('~')
        for segment in segments:
            if segment.startswith('NM1*PR'):
                # NM1*PR*2*PAYER NAME*****PI*PAYER_ID
                fields = segment.split('*')
                if len(fields) >= 10:
                    payer_id = fields[9]
                    if payer_id:
                        return payer_id.strip()
    except Exception:
        pass
    
    return ''


def extract_member_data_from_x12_file(file_path):
    """
    Extract all member data from an X12 837p file.
    
    Args:
        file_path: Path to X12 837p file
    
    Returns:
        dict: Member data with:
            - member_id: Member ID
            - member_first_name: First name
            - member_last_name: Last name
            - member_dob: Date of birth in MM/DD/YYYY format
            - service_start_date: Service start date in MM/DD/YYYY format
            - service_end_date: Service end date in MM/DD/YYYY format
            - payer_id: Payer ID
    """
    if not os.path.exists(file_path):
        return {}
    
    try:
        with open(file_path, 'r') as f:
            x12_data = f.read()
        
        member_id = extract_member_id_from_x12(x12_data)
        first_name, last_name = extract_member_name_from_x12(x12_data)
        dob = extract_member_dob_from_x12(x12_data)
        service_start, service_end = extract_service_dates_from_x12(x12_data)
        payer_id = extract_payer_id_from_x12(x12_data)
        
        return {
            'member_id': member_id,
            'member_first_name': first_name,
            'member_last_name': last_name,
            'member_dob': dob,
            'service_start_date': service_start,
            'service_end_date': service_end,
            'payer_id': payer_id,
        }
        
    except Exception as e:
        if MediLink_ConfigLoader:
            MediLink_ConfigLoader.log(
                "Error reading X12 file {}: {}".format(file_path, e),
                level="WARNING"
            )
        return {}


def _format_x12_date(x12_date):
    """
    Convert X12 date format (YYYYMMDD) to MM/DD/YYYY.
    
    Args:
        x12_date: Date string in YYYYMMDD format
    
    Returns:
        str: Date in MM/DD/YYYY format, or empty string if invalid
    """
    if not x12_date or len(x12_date) != 8 or not x12_date.isdigit():
        return ''
    
    try:
        year = x12_date[0:4]
        month = x12_date[4:6]
        day = x12_date[6:8]
        return "{}/{}/{}".format(month, day, year)
    except Exception:
        return ''
