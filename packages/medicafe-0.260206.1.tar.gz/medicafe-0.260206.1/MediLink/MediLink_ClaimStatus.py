# MediLink_ClaimStatus.py
from datetime import datetime, timedelta
import os
import sys
import time

# Import centralized logging configuration
try:
    from MediCafe.logging_config import DEBUG, PERFORMANCE_LOGGING
except ImportError:
    # Fallback to local flags if centralized config is not available
    DEBUG = False
    PERFORMANCE_LOGGING = False

# Set up project paths first
project_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if project_dir not in sys.path:
    sys.path.insert(0, project_dir)

# Use core utilities for standardized imports
try:
    from MediCafe.core_utils import (
        get_shared_config_loader,
        get_api_client,
        create_config_cache,
        extract_medilink_config
    )
    MediLink_ConfigLoader = get_shared_config_loader()
    # #region agent log
    try:
        import json
        _log_file = open(r'g:\My Drive\Codes\MediCafe\.cursor\debug.log', 'a')
        _log_data = {
            "sessionId": "debug-session",
            "runId": "run1",
            "hypothesisId": "D",
            "location": "MediLink_ClaimStatus.py:28",
            "message": "Imports successful",
            "data": {"config_loader_available": MediLink_ConfigLoader is not None},
            "timestamp": int(time.time() * 1000)
        }
        _log_file.write(json.dumps(_log_data) + "\n")
        _log_file.close()
    except Exception:
        pass
    # #endregion
except ImportError as import_err:
    # #region agent log
    try:
        import json
        _log_file = open(r'g:\My Drive\Codes\MediCafe\.cursor\debug.log', 'a')
        _log_data = {
            "sessionId": "debug-session",
            "runId": "run1",
            "hypothesisId": "D",
            "location": "MediLink_ClaimStatus.py:31",
            "message": "Import error - exiting",
            "data": {"error": str(import_err), "error_type": type(import_err).__name__},
            "timestamp": int(time.time() * 1000)
        }
        _log_file.write(json.dumps(_log_data) + "\n")
        _log_file.close()
    except Exception:
        pass
    # #endregion
    print("Error: Unable to import MediCafe.core_utils. Please ensure MediCafe package is properly installed.")
    sys.exit(1)

# Import api_core for claim operations
try:
    from MediCafe import api_core
except ImportError:
    api_core = None

try:
    from MediLink_RemittancePipeline import normalize_claims_inquiry_record, build_source_meta, write_jsonl
except ImportError:
    normalize_claims_inquiry_record = None
    build_source_meta = None
    write_jsonl = None

# Calculate start_date and end_date for the API: 
# Official API documentation parameter description requires "last date less than 31 days from the First Date"
# Note: There is a discrepancy in swagger - parameter says "< 31 days" but error code LCLM_PS_112 says "90 Days"
# We enforce 30 days (inclusive) to comply with the parameter requirement (< 31 days means max 30 days)
# Use a conservative 30-day range to stay within the 31-day limit
current_date = datetime.today()
end_date = current_date - timedelta(days=1)      # Yesterday (avoid future dates)
start_date = end_date - timedelta(days=29)       # 29 days before end date (30-day range total, inclusive)

# Validate date range according to official API documentation
def validate_date_range(start_date, end_date):
    """
    Validate date range according to official API documentation.
    
    Requirements:
    - Date range must not exceed 30 days (API parameter says "less than 31 days", meaning max 30 days inclusive)
    - Dates must be within last 24 months (per swagger LCLM_PS_107)
    - End date cannot be in the future
    - Start date must be before end date
    
    Note: Swagger discrepancy - parameter description says "< 31 days" but error code LCLM_PS_112 mentions "90 Days"
    We follow the parameter requirement which is more restrictive and clearly stated.
    """
    current_date = datetime.today()
    
    if end_date > current_date:
        raise ValueError("End date cannot be in the future")
    
    date_diff = (end_date - start_date).days
    # API parameter says "less than 31 days" which means maximum 30 days (inclusive)
    if date_diff > 30:
        raise ValueError("Date range must not exceed 30 days (API requires less than 31 days between first and last service date)")
    
    if date_diff < 0:
        raise ValueError("Start date must be before end date")
    
    # Check if dates are within reasonable range (last 24 months as per swagger LCLM_PS_107)
    max_start_date = current_date - timedelta(days=730)  # 24 months
    if start_date < max_start_date:
        raise ValueError("Start date must be within last 24 months")

# Validate the calculated date range
try:
    validate_date_range(start_date, end_date)
except ValueError as e:
    print("Date validation error: {}".format(e))
    # Fallback to a safe date range within 30 days
    end_date = current_date - timedelta(days=1)
    start_date = end_date - timedelta(days=15)  # 15-day range as fallback

end_date_str = end_date.strftime('%m/%d/%Y')
start_date_str = start_date.strftime('%m/%d/%Y')

# Inline commentary: The official API documentation parameter requires "last date less than 31 days 
# from the First Date", which means maximum 30 days inclusive. We use a 30-day range to comply.
# Note: Swagger has a discrepancy - parameter says "< 31 days" but error code LCLM_PS_112 mentions "90 Days".
# We follow the parameter requirement (30 days max) as it's the more restrictive and clearly stated limit.
if DEBUG:
    print("Using date range for API compliance (30-day range, up to yesterday)")
    print("  Start Date: {}".format(start_date_str))
    print("  End Date: {}".format(end_date_str))

# Use latest core_utils configuration cache for better performance
_get_config, (_config_cache, _crosswalk_cache) = create_config_cache()

# Load configuration using latest core_utils pattern
config, _ = _get_config()

# #region agent log
try:
    import json
    _log_file = open(r'g:\My Drive\Codes\MediCafe\.cursor\debug.log', 'a')
    _log_data = {
        "sessionId": "debug-session",
        "runId": "run1",
        "hypothesisId": "A",
        "location": "MediLink_ClaimStatus.py:112",
        "message": "Config loaded",
        "data": {
            "config_type": type(config).__name__,
            "config_is_none": config is None,
            "config_is_dict": isinstance(config, dict),
            "config_len": len(config) if isinstance(config, dict) else 0,
            "has_medilink_config": 'MediLink_Config' in config if isinstance(config, dict) else False,
            "medilink_config_type": type(config.get('MediLink_Config')).__name__ if isinstance(config, dict) else 'N/A'
        },
        "timestamp": int(time.time() * 1000)
    }
    _log_file.write(json.dumps(_log_data) + "\n")
    _log_file.close()
except Exception:
    pass
# #endregion

# Validate config availability (safety check)
if not config or not isinstance(config, dict) or not config.get('MediLink_Config'):
    # #region agent log
    try:
        _log_file = open(r'g:\My Drive\Codes\MediCafe\.cursor\debug.log', 'a')
        _log_data = {
            "sessionId": "debug-session",
            "runId": "run1",
            "hypothesisId": "A",
            "location": "MediLink_ClaimStatus.py:115",
            "message": "Config validation failed",
            "data": {
                "config_is_none": config is None,
                "config_is_dict": isinstance(config, dict),
                "has_medilink_config": config.get('MediLink_Config') if isinstance(config, dict) else None,
                "config_loader_available": MediLink_ConfigLoader is not None
            },
            "timestamp": int(time.time() * 1000)
        }
        _log_file.write(json.dumps(_log_data) + "\n")
        _log_file.close()
    except Exception:
        pass
    # #endregion
    error_msg = "Configuration unavailable or missing MediLink_Config section"
    try:
        MediLink_ConfigLoader.log(error_msg, level="CRITICAL")
    except Exception as log_err:
        # #region agent log
        try:
            _log_file = open(r'g:\My Drive\Codes\MediCafe\.cursor\debug.log', 'a')
            _log_data = {
                "sessionId": "debug-session",
                "runId": "run1",
                "hypothesisId": "C",
                "location": "MediLink_ClaimStatus.py:118",
                "message": "Logging failed",
                "data": {"error": str(log_err), "error_type": type(log_err).__name__},
                "timestamp": int(time.time() * 1000)
            }
            _log_file.write(json.dumps(_log_data) + "\n")
            _log_file.close()
        except Exception:
            pass
        # #endregion
        pass
    print("Error: {}".format(error_msg))
    print("Please ensure config.json exists and contains a valid MediLink_Config section.")
    sys.exit(1)

# Error reporting imports for automated crash reporting
try:
    from MediCafe.error_reporter import capture_unhandled_traceback, submit_support_bundle_email, collect_support_bundle
except ImportError:
    capture_unhandled_traceback = None
    submit_support_bundle_email = None
    collect_support_bundle = None

# Get billing provider TIN from configuration
billing_provider_tin = config.get('MediLink_Config', {}).get('billing_provider_tin')

# Define the list of payer_id's to iterate over
payer_ids = ['87726', '03432', '96385', '95467', '86050', '86047', '95378', '37602']
# Allowed payer id's for UHC 87726, 03432, 96385, 95467, 86050, 86047, 95378, 37602. This api does not support payerId 06111.

# Initialize the API client via factory
client = get_api_client()
if client is None:
    if DEBUG:
        print("Warning: API client not available via factory")
    # Fallback to factory-backed shared client
    try:
        from MediCafe.api_factory import APIClient
        client = APIClient()
    except ImportError:
        # Final fallback to direct instantiation if factory unavailable
        try:
            from MediCafe import api_core
            client = api_core.APIClient()
        except ImportError:
            print("Error: Unable to create API client")
            client = None

class ClaimCache:
    """In-memory cache for API responses"""
    def __init__(self):
        self.cache = {}  # {cache_key: {'data': response, 'payer_id': payer_id}}
    
    def get_cache_key(self, tin, start_date, end_date, payer_id):
        """Generate unique cache key for API call parameters"""
        return "{}_{}_{}_{}".format(tin, start_date, end_date, payer_id)
    
    def is_cached(self, cache_key):
        """Check if response is cached"""
        return cache_key in self.cache
    
    def get_cached_response(self, cache_key):
        """Retrieve cached response"""
        return self.cache[cache_key]['data']
    
    def cache_response(self, cache_key, response, payer_id):
        """Cache API response"""
        self.cache[cache_key] = {
            'data': response,
            'payer_id': payer_id
        }
    
    def clear_cache(self):
        """Clear all cached data"""
        self.cache.clear()

class ConsolidatedClaims:
    """Consolidated claims data structure"""
    def __init__(self):
        self.claims_by_number = {}  # {claim_number: {claim_data, payer_sources: [payer_ids]}}
        self.payer_ids_checked = set()
        self.duplicate_warnings = []
    
    def add_claim(self, claim_data, payer_id):
        """Add claim to consolidated data, tracking payer sources"""
        claim_number = claim_data.get('claim_number', '')
        
        if not claim_number:
            # Skip claims without claim number
            return
        
        if claim_number not in self.claims_by_number:
            self.claims_by_number[claim_number] = {
                'data': claim_data,
                'payer_sources': [payer_id]
            }
        else:
            # Check if this is a duplicate with different data BEFORE adding payer_id
            existing_data = self.claims_by_number[claim_number]['data']
            existing_payers_before = list(self.claims_by_number[claim_number]['payer_sources'])
            
            # Always add payer_id to payer_sources, even if data differs
            if payer_id not in self.claims_by_number[claim_number]['payer_sources']:
                self.claims_by_number[claim_number]['payer_sources'].append(payer_id)
            
            # Check if this is a duplicate with different data
            if not self._claims_equal(existing_data, claim_data):
                # Different data - create warning (use payer list before adding new payer)
                self.duplicate_warnings.append({
                    'claim_number': claim_number,
                    'existing_payers': existing_payers_before,
                    'new_payer': payer_id,
                    'existing_data': existing_data,
                    'new_data': claim_data
                })
        
        self.payer_ids_checked.add(payer_id)

        # TODO(remittance_pipeline): export normalized Claims Inquiry results to
        # remittance_parsed.jsonl via MediLink_RemittancePipeline.normalize_claims_inquiry_record.
        # This allows remittance UI to blend Claims Inquiry results when ERA is missing.
        try:
            if normalize_claims_inquiry_record and build_source_meta and write_jsonl:
                medi = extract_medilink_config(config)
                storage_root = medi.get('local_storage_path') if medi else None
                if storage_root:
                    parsed_path = os.path.join(storage_root, 'remittance_parsed.jsonl')
                    timestamp = int(time.time())
                    # Add payer_id to claim_data before normalization since it's available as parameter
                    claim_data_with_payer = dict(claim_data)
                    claim_data_with_payer['payer_id'] = payer_id
                    source_meta = build_source_meta(
                        source_file="claims_inquiry_{}_{}.json".format(payer_id, timestamp),
                        source_type="Claims Inquiry",
                        source_endpoint="ClaimsInquiry",
                        source_timestamp=timestamp,
                        data_source='claims_inquiry'
                    )
                    normalized_record = normalize_claims_inquiry_record(claim_data_with_payer, source_meta)
                    write_jsonl([normalized_record], parsed_path)
        except Exception as exc:
            if MediLink_ConfigLoader:
                MediLink_ConfigLoader.log(
                    "Failed to persist Claims Inquiry record {}: {}".format(
                        claim_data.get('claim_number', ''), exc),
                    level="WARNING",
                    console_output=False
                )
    
    def _claims_equal(self, claim1, claim2):
        """Compare two claim data structures for equality"""
        # Compare key fields that should be identical for the same claim
        key_fields = ['claim_status', 'patient_name', 'processed_date', 'first_service_date', 
                     'total_charged_amount', 'total_allowed_amount', 'total_paid_amount', 
                     'total_patient_responsibility_amount']
        
        for field in key_fields:
            if claim1.get(field) != claim2.get(field):
                return False
        return True

def extract_claim_data(claim):
    """Extract standardized claim data from API response with defensive checks"""
    try:
        # Use .get() with defaults to handle missing fields gracefully
        claim_number = claim.get('claimNumber', '')
        claim_status = claim.get('claimStatus', '')
        
        # Safely extract member info
        member_info = claim.get('memberInfo', {})
        patient_first_name = member_info.get('ptntFn', '')
        patient_last_name = member_info.get('ptntLn', '')
        
        # Safely extract claim summary
        claim_summary = claim.get('claimSummary', {})
        processed_date = claim_summary.get('processedDt', '')
        first_service_date = claim_summary.get('firstSrvcDt', '')
        total_charged_amount = claim_summary.get('totalChargedAmt', '0.00')
        total_allowed_amount = claim_summary.get('totalAllowdAmt', '0.00')
        total_paid_amount = claim_summary.get('totalPaidAmt', '0.00')
        total_patient_responsibility_amount = claim_summary.get('totalPtntRespAmt', '0.00')
        claim_xwalk_data = claim_summary.get('clmXWalkData', [])
        
        # Build patient name safely
        if patient_first_name or patient_last_name:
            patient_name = "{} {}".format(patient_first_name, patient_last_name).strip()
        else:
            patient_name = ''
        
        # Log warning if critical fields are missing
        if not claim_number:
            MediLink_ConfigLoader.log(
                "Warning: Claim data missing claimNumber field",
                level="WARNING",
                console_output=False
            )
        
        return {
            'claim_number': claim_number,
            'claim_status': claim_status,
            'patient_name': patient_name,
            'processed_date': processed_date,
            'first_service_date': first_service_date,
            'total_charged_amount': total_charged_amount,
            'total_allowed_amount': total_allowed_amount,
            'total_paid_amount': total_paid_amount,
            'total_patient_responsibility_amount': total_patient_responsibility_amount,
            'claim_xwalk_data': claim_xwalk_data
        }
    except Exception as e:
        # Log error and return minimal safe structure
        MediLink_ConfigLoader.log(
            "Error extracting claim data: {}".format(e),
            level="ERROR",
            console_output=False
        )
        # Return minimal structure to prevent downstream crashes
        return {
            'claim_number': claim.get('claimNumber', 'UNKNOWN'),
            'claim_status': '',
            'patient_name': '',
            'processed_date': '',
            'first_service_date': '',
            'total_charged_amount': '0.00',
            'total_allowed_amount': '0.00',
            'total_paid_amount': '0.00',
            'total_patient_responsibility_amount': '0.00',
            'claim_xwalk_data': []
        }

def handle_api_error(error, payer_id):
    """Handle specific API errors according to official documentation"""
    error_message = str(error)
    
    # Handle specific error codes from official documentation
    if "LCLM_PS_102" in error_message:
        return "Mandatory element missing in request (tin, firstServiceDt, lastServiceDt, or payerId)"
    elif "LCLM_PS_105" in error_message or "LCLM_PS_202" in error_message:
        return "Authorization error: Payer ID {} not allowed".format(payer_id)
    elif "LCLM_PS_106" in error_message:
        return "Invalid parameter combination: must use (firstServiceDt,lastServiceDt) or (transactionId)"
    elif "LCLM_PS_107" in error_message:
        return "Date range must be within last 24 months"
    elif "LCLM_PS_108" in error_message or "LCLM_PS_111" in error_message:
        return "Incorrect date format: use MM/dd/yyyy"
    elif "LCLM_PS_112" in error_message:
        # Note: Swagger parameter description says "less than 31 days" but error code LCLM_PS_112 says "90 Days"
        # We enforce 30 days to comply with the parameter requirement (< 31 days)
        return "Date range exceeds 30 days limit (API requires less than 31 days between first and last service date)"
    elif "LCLM_PS_113" in error_message:
        return "Incorrect Last Service Date format or value"
    elif "LCLM_PS_201" in error_message:
        return "No data found with given request parameters"
    elif "LCLM_PS_203" in error_message:
        return "No data found with given TransactionId - pagination token may be expired"
    elif "LCLM_PS_307" in error_message:
        return "Claim found but date of service does not match search criteria"
    elif "LCLM_PS_301" in error_message:
        return "Timeout exception from service - retry may be needed"
    elif "LCLM_PS_302" in error_message:
        return "Super user exception from service"
    elif "LCLM_PS_303" in error_message:
        return "System failure while fetching response"
    elif "LCLM_PS_304" in error_message:
        return "Error received from backend service"
    elif "LCLM_PA_500" in error_message:
        return "System failure while fetching response (PA endpoint)"
    elif "LCLM_PS_306" in error_message:
        # Critical error: search exceeds API limit
        return "Search exceeds 500 claims limit - narrow date range"
    elif "LCLM_PS_305" in error_message:
        # Critical error: system could not retrieve all claims
        return "System could not retrieve all claims - try pagination or narrower search"
    elif "LCLM_PS_500" in error_message:
        return "Server error: Exception from Claims 360 - try again later"
    elif "401" in error_message:
        return "Authentication error: check credentials"
    elif "403" in error_message:
        return "Authorization error: insufficient permissions"
    elif "500" in error_message:
        return "Server error: internal system failure"
    else:
        return "Unknown error: {}".format(error_message)

def process_claims_with_pagination(client, billing_provider_tin, start_date_str, end_date_str, payer_id):
    """
    Process all claims for a single payer ID with proper pagination handling
    """
    all_claims = []
    transaction_id = None
    page_count = 0
    total_claims_retrieved = 0
    
    # INFO: Log summary at start of function
    MediLink_ConfigLoader.log(
        "[OPTUMAI_CLAIMS_INQUIRY] PAGINATION: Starting claims retrieval for payerId={}, dateRange={} to {}, initialTransactionId={}".format(
            payer_id, start_date_str, end_date_str, transaction_id or 'None'
        ),
        level="INFO"
    )
    
    while True:
        page_count += 1
        if DEBUG:
            print("    Fetching page {} for Payer ID: {}".format(page_count, payer_id))
        
        try:
            # Import api_core locally to ensure it's available
            from MediCafe import api_core
            claim_summary = api_core.get_claim_summary_by_provider(
                client, billing_provider_tin, start_date_str, end_date_str, 
                payer_id=payer_id, transaction_id=transaction_id
            )
            # Validate response is a dictionary
            if not isinstance(claim_summary, dict):
                raise ValueError("Invalid API response: expected dict, got {}".format(type(claim_summary).__name__))
            
            # Informational notice if new OPTUM Real endpoint is being used
            try:
                if claim_summary.get('data_source') == 'OPTUMAI':
                    MediLink_ConfigLoader.log(
                        "Claims Inquiry via Optum Real endpoint (OPTUMAI) with legacy-compatible output.",
                        level="INFO"
                    )
                    if DEBUG:
                        print("[Info] Using Optum Real Claims Inquiry for payer {}".format(payer_id))
            except Exception:
                pass
            
            # Extract claims from this page
            claims = claim_summary.get('claims', [])
            page_claim_count = len(claims)
            all_claims.extend(claims)
            total_claims_retrieved += page_claim_count
            
            # Response monitoring: Check for pagination token
            new_transaction_id = claim_summary.get('transactionId')
            
            if new_transaction_id:
                MediLink_ConfigLoader.log(
                    "[OPTUMAI_CLAIMS_INQUIRY] PAGINATION: Payer {} page {} returned {} claims with transactionId: {}".format(
                        payer_id, page_count, page_claim_count, new_transaction_id
                    ),
                    level="INFO"
                )
                # Also keep the existing log for backward compatibility
                MediLink_ConfigLoader.log(
                    "PAGINATION DETECTED: Payer {} page {} returned {} claims with transactionId: {}".format(
                        payer_id, page_count, page_claim_count, new_transaction_id
                    ),
                    level="INFO"
                )
                transaction_id = new_transaction_id
            else:
                MediLink_ConfigLoader.log(
                    "[OPTUMAI_CLAIMS_INQUIRY] PAGINATION: Payer {} page {} returned {} claims (final page)".format(
                        payer_id, page_count, page_claim_count
                    ),
                    level="INFO"
                )
                # Also keep the existing log for backward compatibility
                MediLink_ConfigLoader.log(
                    "PAGINATION COMPLETE: Payer {} page {} returned {} claims (final page)".format(
                        payer_id, page_count, page_claim_count
                    ),
                    level="INFO"
                )
                break
            
            # Safety check to prevent infinite loops (API max is 500 claims)
            # Check claim count first (primary limit), then page count as secondary safety
            if total_claims_retrieved >= 500:
                MediLink_ConfigLoader.log(
                    "Reached maximum claim limit (500) for payer {}. Total claims retrieved: {} across {} pages".format(
                        payer_id, total_claims_retrieved, page_count
                    ),
                    level="WARNING"
                )
                break
            elif page_count >= 20:  # Secondary safety: max 20 pages (20 * 50 = 1000, well above API limit)
                MediLink_ConfigLoader.log(
                    "Reached maximum page limit (20) for payer {}. Total claims retrieved: {} across {} pages".format(
                        payer_id, total_claims_retrieved, page_count
                    ),
                    level="WARNING"
                )
                break
                
        except Exception as e:
            error_msg = handle_api_error(e, payer_id)
            error_str = str(e)
            
            # Standardized error handling pattern:
            # Critical errors (limits, retrieval failures): print + log with ERROR level
            # Other errors: log only with appropriate level
            if "LCLM_PS_306" in error_str or "exceeds 500 claims" in error_str:
                # Critical: search exceeds API limit
                print("  LIMIT ERROR for Payer ID {}: {}".format(payer_id, error_msg))
                MediLink_ConfigLoader.log(
                    "LIMIT ERROR for Payer ID {}: {}".format(payer_id, error_msg),
                    level="ERROR"
                )
            elif "LCLM_PS_305" in error_str or "could not retrieve all claims" in error_str:
                # Critical: system could not retrieve all claims
                print("  RETRIEVAL ERROR for Payer ID {}: {}".format(payer_id, error_msg))
                MediLink_ConfigLoader.log(
                    "RETRIEVAL ERROR for Payer ID {}: {}".format(payer_id, error_msg),
                    level="ERROR"
                )
            elif "LCLM_PS_201" in error_str or "LCLM_PS_203" in error_str:
                # Recoverable: no data found (may be expected)
                MediLink_ConfigLoader.log(
                    "No data found for Payer ID {}: {}".format(payer_id, error_msg),
                    level="WARNING",
                    console_output=False
                )
            else:
                # Other errors: print + log (inform user but not as critical as limit errors)
                print("  Error processing Payer ID {}: {}".format(payer_id, error_msg))
                MediLink_ConfigLoader.log(
                    "API Error for Payer ID {}: {}".format(payer_id, error_msg),
                    level="ERROR",
                    console_output=False
                )
            break
    
    # INFO: Log final summary
    MediLink_ConfigLoader.log(
        "[OPTUMAI_CLAIMS_INQUIRY] PAGINATION: Final summary - payerId={}, totalPages={}, totalClaimsRetrieved={}, dateRange={} to {}".format(
            payer_id, page_count, total_claims_retrieved, start_date_str, end_date_str
        ),
        level="INFO"
    )
    
    # WARNING: Log zero claims retrieved across all pages
    if total_claims_retrieved == 0:
        MediLink_ConfigLoader.log(
            "[OPTUMAI_CLAIMS_INQUIRY] NO_DATA: Zero claims across all pages - payerId={}, totalPages={}, dateRange={} to {}".format(
                payer_id, page_count, start_date_str, end_date_str
            ),
            level="WARNING"
        )
    
    if DEBUG:
        print("  Total claims retrieved for Payer ID {}: {} across {} pages".format(
            payer_id, total_claims_retrieved, page_count))
    
    return all_claims

def process_claims_with_payer_rotation(billing_provider_tin, start_date_str, end_date_str, 
                                     payer_ids, cache, consolidated_claims):
    """
    Process claims across multiple payer IDs with caching, consolidation, and pagination
    """
    from MediCafe.core_utils import get_api_client
    client = get_api_client()
    if client is None:
        if DEBUG:
            print("Warning: API client not available via factory")
        # Fallback to factory-backed shared client
        try:
            from MediCafe.api_factory import APIClient
            client = APIClient()
        except ImportError:
            # Final fallback to direct instantiation if factory unavailable
            try:
                from MediCafe import api_core
                client = api_core.APIClient()
            except ImportError:
                print("Error: Unable to create API client")
                return
    
    for payer_id in payer_ids:
        if DEBUG:
            print("Processing Payer ID: {}".format(payer_id))
        
        # Generate cache key (using base parameters, pagination handled separately)
        cache_key = cache.get_cache_key(billing_provider_tin, start_date_str, end_date_str, payer_id)
        
        # Check cache first
        if cache.is_cached(cache_key):
            if DEBUG:
                print("  Using cached response for Payer ID: {}".format(payer_id))
            # For cached responses, we assume all pages were already retrieved
            cached_response = cache.get_cached_response(cache_key)
            claims = cached_response.get('claims', [])
        else:
            if DEBUG:
                print("  Making API call(s) with pagination for Payer ID: {}".format(payer_id))
            
            # Process all pages for this payer ID
            claims = process_claims_with_pagination(
                client, billing_provider_tin, start_date_str, end_date_str, payer_id
            )
            
            # Cache the consolidated result (all pages combined)
            consolidated_response = {'claims': claims}
            cache.cache_response(cache_key, consolidated_response, payer_id)
        
        # Process all claims from this payer (all pages)
        for claim in claims:
            claim_data = extract_claim_data(claim)
            consolidated_claims.add_claim(claim_data, payer_id)

def display_consolidated_claims(consolidated_claims, output_file):
    """
    Display consolidated claims with payer ID header and duplicate warnings
    """
    # Display header with all payer IDs checked
    payer_ids_str = ", ".join(sorted(consolidated_claims.payer_ids_checked))
    header = "Payer IDs Checked: {} | Start Date: {} | End Date: {}".format(
        payer_ids_str, start_date_str, end_date_str)
    print(header)
    output_file.write(header + "\n")
    print("=" * len(header))
    output_file.write("=" * len(header) + "\n")
    
    # Table header
    table_header = "{:<10} | {:<10} | {:<20} | {:<6} | {:<6} | {:<7} | {:<7} | {:<7} | {:<7} | {:<15}".format(
        "Claim #", "Status", "Patient", "Proc.", "Serv.", "Allowed", "Paid", "Pt Resp", "Charged", "Payer Sources")
    print(table_header)
    output_file.write(table_header + "\n")
    print("-" * len(table_header))
    output_file.write("-" * len(table_header) + "\n")
    
    # Sort claims by first service date (handle missing dates gracefully)
    # Use '9999/99/99' as sort key for missing dates to put them at the end
    sorted_claims = sorted(
        consolidated_claims.claims_by_number.items(),
        key=lambda x: x[1]['data'].get('first_service_date', '') or '9999/99/99'
    )
    
    # Display each claim
    for claim_number, claim_info in sorted_claims:
        claim_data = claim_info['data']
        payer_sources = claim_info['payer_sources']
        
        # Format payer sources with truncation for long lists
        sorted_payers = sorted(payer_sources)
        max_payer_display_length = 15  # Match table column width
        if len(sorted_payers) == 0:
            payer_sources_str = ''
        elif len(sorted_payers) == 1:
            payer_sources_str = sorted_payers[0]
        else:
            payer_sources_str = ", ".join(sorted_payers)
            # If too long, show count or truncate
            if len(payer_sources_str) > max_payer_display_length:
                if len(sorted_payers) > 3:
                    # Show count if many payers
                    payer_sources_str = "{} payers".format(len(sorted_payers))
                else:
                    # Truncate with ellipsis
                    payer_sources_str = payer_sources_str[:max_payer_display_length-3] + "..."
        
        table_row = "{:<10} | {:<10} | {:<20} | {:<6} | {:<6} | {:<7} | {:<7} | {:<7} | {:<7} | {:<15}".format(
            claim_number, claim_data.get('claim_status', '')[:10], claim_data.get('patient_name', '')[:20],
            claim_data.get('processed_date', '')[:5], claim_data.get('first_service_date', '')[:5],
            claim_data.get('total_allowed_amount', '0.00'), claim_data.get('total_paid_amount', '0.00'),
            claim_data.get('total_patient_responsibility_amount', '0.00'), claim_data.get('total_charged_amount', '0.00'),
            payer_sources_str[:max_payer_display_length]
        )
        print(table_row)
        output_file.write(table_row + "\n")
        
        # Display crosswalk data for $0.00 claims
        if claim_data.get('total_paid_amount') == '0.00':
            claim_xwalk_data = claim_data.get('claim_xwalk_data', [])
            # Check if claim_xwalk_data exists and is iterable
            if isinstance(claim_xwalk_data, list):
                for xwalk in claim_xwalk_data:
                    if isinstance(xwalk, dict):
                        clm507Cd = xwalk.get('clm507Cd', '')
                        clm507CdDesc = xwalk.get('clm507CdDesc', '')
                        clm508Cd = xwalk.get('clm508Cd', '')
                        clm508CdDesc = xwalk.get('clm508CdDesc', '')
                        clmIcnSufxCd = xwalk.get('clmIcnSufxCd', '')
                        if DEBUG:
                            print("  507: {} ({}) | 508: {} ({}) | ICN Suffix: {}".format(
                                clm507Cd, clm507CdDesc, clm508Cd, clm508CdDesc, clmIcnSufxCd))
    
    # Display duplicate warnings (terminal, log, and output file)
    if consolidated_claims.duplicate_warnings:
        warnings_section = "\n" + "="*80 + "\n"
        warnings_section += "DUPLICATE CLAIM WARNINGS:\n"
        warnings_section += "="*80 + "\n"
        
        for warning in consolidated_claims.duplicate_warnings:
            claim_number = warning['claim_number']
            all_payers = warning['existing_payers']
            new_payer = warning['new_payer']
            existing_data = warning['existing_data']
            new_data = warning['new_data']
            
            # Build comprehensive warning message showing all payer sources
            warning_msg = (
                "Claim {} found in multiple payers with different data:\n"
                "  All payer sources: {}\n"
                "  New payer with different data: {}\n"
                "  Status difference: {} (existing) vs {} (new)\n"
                "  Paid amount difference: ${} (existing) vs ${} (new)\n"
                "  Allowed amount difference: ${} (existing) vs ${} (new)\n"
                "  Patient: {} (existing) vs {} (new)".format(
                    claim_number,
                    ", ".join(sorted(all_payers)),
                    new_payer,
                    existing_data.get('claim_status', ''),
                    new_data.get('claim_status', ''),
                    existing_data.get('total_paid_amount', '0.00'),
                    new_data.get('total_paid_amount', '0.00'),
                    existing_data.get('total_allowed_amount', '0.00'),
                    new_data.get('total_allowed_amount', '0.00'),
                    existing_data.get('patient_name', ''),
                    new_data.get('patient_name', '')
                )
            )
            
            warnings_section += warning_msg + "\n" + "-"*80 + "\n"
            
            if DEBUG:
                print(warning_msg)
            
            # Log the warning (file only, not console)
            MediLink_ConfigLoader.log(
                "Duplicate claim warning: {}".format(warning_msg),
                level="WARNING",
                console_output=False
            )
        
        # Write warnings to output file
        output_file.write(warnings_section)
        if DEBUG:
            print(warnings_section)


# -----------------------------------------------------------------------------
# Post-Submission Status Lookup Functions
# -----------------------------------------------------------------------------

def display_recent_submissions_menu(recent_submissions):
    """
    Display a numbered list of recent submissions for user selection.
    
    Args:
        recent_submissions: List of submission records from multi-source query
    
    Returns:
        None (displays to console)
    """
    if not recent_submissions:
        print("\nNo recent submissions found.")
        return
    
    print("\n" + "="*80)
    print("RECENT SUBMISSIONS (Last 30 days)")
    print("="*80)
    print("")
    
    # Table header
    header = "{:<4} {:<20} {:<12} {:<20} {:<12} {:<10} {:<15}".format(
        "#", "Patient", "DOS", "Submitted", "Payer", "Source", "Transaction ID"
    )
    print(header)
    print("-" * 95)
    
    # Table rows
    for idx, record in enumerate(recent_submissions, start=1):
        # Extract display fields
        patient_name = record.get('patient_name', '')
        if not patient_name:
            first = record.get('member_first_name', '')
            last = record.get('member_last_name', '')
            if first or last:
                patient_name = "{} {}".format(first, last).strip()
        if not patient_name:
            patient_name = (
                record.get('patient_id') or
                record.get('member_id') or
                record.get('memberId') or
                'Unknown'
            )
        
        dos = record.get('dos', 'Unknown')
        
        # Format submitted_at
        submitted_at = record.get('submitted_at', '')
        if isinstance(submitted_at, (int, float)):
            from datetime import datetime
            try:
                dt = datetime.fromtimestamp(submitted_at)
                submitted_str = dt.strftime("%Y-%m-%d %H:%M")
            except Exception:
                submitted_str = str(submitted_at)
        else:
            submitted_str = str(submitted_at)[:16] if submitted_at else 'Unknown'
        
        payer = record.get('payer_id', '') or record.get('primary_insurance', 'Unknown')
        source = record.get('source', 'Unknown')
        transaction_id = record.get('transactionId', '')
        if transaction_id:
            # Truncate long transaction IDs for display
            if len(transaction_id) > 13:
                transaction_id = transaction_id[:12] + "..."
        else:
            transaction_id = "N/A"
        
        # Truncate long names
        if len(patient_name) > 18:
            patient_name = patient_name[:17] + "."
        
        row = "{:<4} {:<20} {:<12} {:<20} {:<12} {:<10} {:<15}".format(
            str(idx), patient_name, dos, submitted_str, payer, source, transaction_id
        )
        print(row)
    
    print("")


def prompt_for_manual_lookup():
    """
    Prompt user for manual entry of lookup criteria.
    
    Validates field combinations per OPTUMAI spec requirements:
    - memberId + DOB
    - memberId + firstName + lastName
    - firstName + lastName + DOB
    
    Returns:
        dict: Lookup criteria with validated fields, or None if user cancels
    """
    print("\n" + "="*80)
    print("MANUAL CLAIM STATUS LOOKUP")
    print("="*80)
    print("\nEnter claim details for lookup. Press Enter to skip optional fields.")
    print("\nRequired field combinations:")
    print("  1. Transaction ID + Payer ID (for 277CA confirmation)")
    print("  2. Member ID + DOB + Payer ID")
    print("  3. Member ID + First Name + Last Name + Payer ID")
    print("  4. First Name + Last Name + DOB + Payer ID")
    print("\nNote: Some payers may require Service Start/End Dates when searching by member data.")
    print("      If you receive an error about missing required fields, try adding service dates.")
    print("")
    
    try:
        # Required fields
        payer_id = raw_input("Payer ID (required): ").strip() if sys.version_info[0] < 3 else input("Payer ID (required): ").strip()
        if not payer_id:
            print("Payer ID is required. Cancelling.")
            return None
        
        # Optional transaction ID for 277CA lookup
        transaction_id = raw_input("Transaction ID (optional, for 277CA): ").strip() if sys.version_info[0] < 3 else input("Transaction ID (optional, for 277CA): ").strip()
        
        # Member data fields
        member_id = raw_input("Member ID (optional): ").strip() if sys.version_info[0] < 3 else input("Member ID (optional): ").strip()
        member_first_name = raw_input("Member First Name (optional): ").strip() if sys.version_info[0] < 3 else input("Member First Name (optional): ").strip()
        member_last_name = raw_input("Member Last Name (optional): ").strip() if sys.version_info[0] < 3 else input("Member Last Name (optional): ").strip()
        member_dob = raw_input("Member DOB (MM/DD/YYYY, MM-DD-YYYY, or MM.DD.YYYY) (optional): ").strip() if sys.version_info[0] < 3 else input("Member DOB (MM/DD/YYYY, MM-DD-YYYY, or MM.DD.YYYY) (optional): ").strip()
        service_start = raw_input("Service Start Date (MM/DD/YYYY, MM-DD-YYYY, or MM.DD.YYYY) (optional): ").strip() if sys.version_info[0] < 3 else input("Service Start Date (MM/DD/YYYY, MM-DD-YYYY, or MM.DD.YYYY) (optional): ").strip()
        service_end = raw_input("Service End Date (MM/DD/YYYY, MM-DD-YYYY, or MM.DD.YYYY) (optional): ").strip() if sys.version_info[0] < 3 else input("Service End Date (MM/DD/YYYY, MM-DD-YYYY, or MM.DD.YYYY) (optional): ").strip()
        
        # Normalize and validate date formats (accepts MM/DD/YYYY, MM-DD-YYYY, MM.DD.YYYY)
        def normalize_and_validate_date(date_str, field_name):
            """
            Validate and normalize date input to MM/DD/YYYY format.
            
            Accepts multiple separators: /, -, or .
            Returns normalized date string (MM/DD/YYYY) or None if invalid.
            """
            if not date_str:
                return None  # Optional fields can be empty
            
            # Try different separators
            separators = ['/', '-', '.']
            parts = None
            used_separator = None
            
            for sep in separators:
                if sep in date_str:
                    test_parts = date_str.split(sep)
                    if len(test_parts) == 3:
                        parts = test_parts
                        used_separator = sep
                        break
            
            if not parts or len(parts) != 3:
                print("Error: {} is invalid. Please use MM/DD/YYYY, MM-DD-YYYY, or MM.DD.YYYY format (e.g., 02/13/1947)".format(field_name))
                return None
            
            try:
                month, day, year = parts
                month = month.strip()
                day = day.strip()
                year = year.strip()
                
                # Validate all parts are numeric
                month_int = int(month)
                day_int = int(day)
                year_int = int(year)
                
                # Validate month range
                if not (1 <= month_int <= 12):
                    print("Error: {} is invalid. Month must be between 01 and 12 (you entered: {})".format(field_name, month))
                    return None
                
                # Validate day range
                if not (1 <= day_int <= 31):
                    print("Error: {} is invalid. Day must be between 01 and 31 (you entered: {})".format(field_name, day))
                    return None
                
                # Validate year format
                if len(year) != 4:
                    print("Error: {} is invalid. Year must be 4 digits (YYYY format, you entered: {})".format(field_name, year))
                    return None
                
                # Normalize to MM/DD/YYYY format
                normalized = "{:02d}/{:02d}/{:04d}".format(month_int, day_int, year_int)
                return normalized
                
            except ValueError:
                print("Error: {} is invalid. Please enter only numbers in MM/DD/YYYY, MM-DD-YYYY, or MM.DD.YYYY format (e.g., 02/13/1947)".format(field_name))
                return None
        
        # Normalize and validate dates
        member_dob_normalized = normalize_and_validate_date(member_dob, "Member DOB")
        if member_dob and member_dob_normalized is None:
            return None
        
        service_start_normalized = normalize_and_validate_date(service_start, "Service Start Date")
        if service_start and service_start_normalized is None:
            return None
        
        service_end_normalized = normalize_and_validate_date(service_end, "Service End Date")
        if service_end and service_end_normalized is None:
            return None
        patient_account = raw_input("Patient Account Number (optional): ").strip() if sys.version_info[0] < 3 else input("Patient Account Number (optional): ").strip()
        
        # Build lookup criteria (use normalized dates)
        criteria = {
            'payerId': payer_id,
            'transactionId': transaction_id if transaction_id else None,
            'memberId': member_id if member_id else None,
            'memberFirstName': member_first_name if member_first_name else None,
            'memberLastName': member_last_name if member_last_name else None,
            'memberDateOfBirth': member_dob_normalized if member_dob_normalized else None,
            'serviceStartDate': service_start_normalized if service_start_normalized else None,
            'serviceEndDate': service_end_normalized if service_end_normalized else None,
            'patientAccountNumber': patient_account if patient_account else None,
        }
        
        # Validate we have either transactionId or valid member data combination
        has_transaction_id = bool(transaction_id)
        has_member_id = bool(member_id)
        has_first_name = bool(member_first_name)
        has_last_name = bool(member_last_name)
        has_dob = bool(member_dob_normalized)
        
        valid_combo = (
            has_transaction_id or
            (has_member_id and has_dob) or
            (has_member_id and has_first_name and has_last_name) or
            (has_first_name and has_last_name and has_dob)
        )
        
        if not valid_combo:
            print("\nInsufficient data for lookup. Required:")
            print("  - Transaction ID, OR")
            print("  - Member ID + DOB, OR")
            print("  - Member ID + First Name + Last Name, OR")
            print("  - First Name + Last Name + DOB")
            return None
        
        return criteria
        
    except KeyboardInterrupt:
        print("\nCancelled by user.")
        return None
    except Exception as e:
        print("Error during manual entry: {}".format(e))
        return None


def display_submission_context_results(result):
    """
    Display results from post-submission status lookup.
    
    Handles both 277CA and member-based claim status results.
    
    Args:
        result: Response dict from get_claim_status_by_submission_context()
    
    Returns:
        None (displays to console)
    """
    print("\n" + "="*80)
    print("POST-SUBMISSION STATUS LOOKUP RESULTS")
    print("="*80)
    
    lookup_type = result.get('lookup_type', 'unknown')
    
    # Display 277CA results if available
    ack_277ca = result.get('ack_277ca')
    if ack_277ca:
        print("\n--- 277CA CLAIM ACKNOWLEDGEMENT ---")
        print("Status Code: {}".format(ack_277ca.get('statuscode', 'Unknown')))
        print("Message: {}".format(ack_277ca.get('message', 'No message')))
        print("Response Type: {}".format(ack_277ca.get('responseType', 'Unknown')))
        
        # Display X12 response data if available
        x12_response = ack_277ca.get('x12ResponseData', '')
        if x12_response:
            print("\nX12 Response Data (truncated):")
            print(x12_response[:500] + "..." if len(x12_response) > 500 else x12_response)
        print("")
    
    # Display claim status results if available
    claim_status = result.get('claim_status')
    if claim_status:
        print("\n--- CLAIM STATUS INQUIRY ---")
        claims = claim_status.get('claims', [])
        
        if claims:
            print("Found {} claim(s):\n".format(len(claims)))
            
            for idx, claim in enumerate(claims, start=1):
                print("Claim #{}:".format(idx))
                print("  Claim Number: {}".format(claim.get('claimNumber', 'Unknown')))
                print("  Status: {}".format(claim.get('claimStatus', 'Unknown')))
                
                # Member info
                member_info = claim.get('memberInfo', {})
                if member_info:
                    first_name = member_info.get('ptntFn', '')
                    last_name = member_info.get('ptntLn', '')
                    if first_name or last_name:
                        print("  Patient: {} {}".format(first_name, last_name))
                
                # Claim summary
                claim_summary = claim.get('claimSummary', {})
                if claim_summary:
                    print("  Processed Date: {}".format(claim_summary.get('processedDt', 'Unknown')))
                    print("  Service Date: {}".format(claim_summary.get('firstSrvcDt', 'Unknown')))
                    print("  Total Charged: ${}".format(claim_summary.get('totalChargedAmt', '0.00')))
                    print("  Total Paid: ${}".format(claim_summary.get('totalPaidAmt', '0.00')))
                    print("  Patient Responsibility: ${}".format(claim_summary.get('totalPtntRespAmt', '0.00')))
                
                print("")
        else:
            print("No claims found matching the search criteria.")
            status_code = claim_status.get('statuscode', 'Unknown')
            message = claim_status.get('message', 'No message')
            print("Status: {}".format(status_code))
            print("Message: {}".format(message))
            
            # Check for specific error about missing required fields
            if status_code in ['500', '400'] and message:
                message_lower = message.lower()
                if 'missing_required_field' in message_lower or 'required for payer' in message_lower:
                    if 'service dates' in message_lower or 'service dates are required' in message_lower:
                        print("\n" + "-"*80)
                        print("SUGGESTION:")
                        print("-"*80)
                        print("This payer may require Service Start and End Dates when searching by member data.")
                        print("Please try again with service dates included (maximum 90 day range).")
                        print("-"*80)
    
    # Display overall status
    print("\n" + "="*80)
    overall_status = result.get('statuscode', 'Unknown')
    overall_message = result.get('message', 'No message')
    print("Overall Status: {}".format(overall_status))
    print("Message: {}".format(overall_message))
    
    # Check for specific error about missing required fields at overall level
    if overall_status in ['404', '500', '400'] and overall_message:
        message_lower = overall_message.lower()
        if 'missing_required_field' in message_lower or ('required for payer' in message_lower and 'service dates' in message_lower):
            print("\n" + "-"*80)
            print("SUGGESTION:")
            print("-"*80)
            print("This payer may require Service Start and End Dates when searching by member data.")
            print("Please try again with service dates included (maximum 90 day range).")
            print("-"*80)
    
    print("="*80)
    print("")


def run_recent_submissions_lookup(config):
    """
    Query recent submissions, let user pick one, and run post-submission lookup.

    Returns:
        bool: True if flow completed/returned to caller, False if interrupted
    """
    try:
        from MediCafe.submission_query import get_recent_submissions_from_all_sources

        print("\nQuerying recent submissions...")
        recent_submissions = get_recent_submissions_from_all_sources(config, days=30, limit=50)

        if not recent_submissions:
            print("\n" + "="*80)
            print("NO RECENT SUBMISSIONS FOUND")
            print("="*80)
            print("\nThis could mean:")
            print("  - No claims have been submitted in the last 30 days")
            print("  - Submission index is not yet populated")
            print("  - Receipt files have been moved or deleted")
            print("  - Configuration paths may be incorrect")
            print("\nYou can:")
            print("  - Use manual lookup to enter claim details directly")
            print("  - Check your configuration settings for submission paths")
            print("")
            try:
                raw_input("Press Enter to continue...") if sys.version_info[0] < 3 else input("Press Enter to continue...")
            except (KeyboardInterrupt, EOFError):
                return False
            return True

        display_recent_submissions_menu(recent_submissions)

        try:
            selection = raw_input("\nEnter submission number (or 'B' to go back): ").strip() if sys.version_info[0] < 3 else input("\nEnter submission number (or 'B' to go back): ").strip()
            if selection.upper() == 'B':
                return True

            idx = int(selection) - 1
            if idx < 0 or idx >= len(recent_submissions):
                print("\nInvalid selection. Please enter a number between 1 and {}.".format(len(recent_submissions)))
                try:
                    raw_input("Press Enter to continue...") if sys.version_info[0] < 3 else input("Press Enter to continue...")
                except (KeyboardInterrupt, EOFError):
                    return False
                return True

            selected = recent_submissions[idx]
            member_data = _extract_member_data_from_submission(selected, config)

            if not member_data:
                print("\n" + "="*80)
                print("ERROR: Could not extract member data from selected submission.")
                print("="*80)
                print("\nThis may happen if:")
                print("  - The submission file is missing or moved")
                print("  - The file format is not recognized")
                print("  - Required member data is not available in the file")
                print("\nTry using manual lookup to enter the data directly.")
                print("")
                try:
                    raw_input("Press Enter to continue...") if sys.version_info[0] < 3 else input("Press Enter to continue...")
                except (KeyboardInterrupt, EOFError):
                    return False
                return True

            print("\nPerforming status lookup...")
            result = _perform_submission_context_lookup(member_data)
            display_submission_context_results(result)

            try:
                raw_input("\nPress Enter to return to menu...") if sys.version_info[0] < 3 else input("\nPress Enter to return to menu...")
            except (KeyboardInterrupt, EOFError):
                return False
            return True

        except ValueError:
            print("Invalid number.")
            return True
        except Exception as e:
            print("Error processing selection: {}".format(e))
            if DEBUG:
                MediLink_ConfigLoader.log("Selection error: {}".format(e), level="ERROR")
            return True
    except Exception as e:
        print("Error querying submissions: {}".format(e))
        if DEBUG:
            MediLink_ConfigLoader.log("Query error: {}".format(e), level="ERROR")
        return True


def post_submission_status_menu(config):
    """
    Main menu for post-submission status lookups.
    
    Provides two options:
    1. Select from list of recent submissions
    2. Manual entry of lookup criteria
    
    Args:
        config: Configuration dictionary
    
    Returns:
        None (interactive menu)
    """
    while True:
        print("\n" + "="*80)
        print("POST-SUBMISSION STATUS LOOKUP")
        print("="*80)
        print("\n1. Select from recent submissions")
        print("2. Manual lookup")
        print("3. Back to main menu")
        print("")
        
        try:
            choice = raw_input("Enter choice (1-3): ").strip() if sys.version_info[0] < 3 else input("Enter choice (1-3): ").strip()
        except (KeyboardInterrupt, EOFError):
            break
        
        if choice == '1':
            if not run_recent_submissions_lookup(config):
                break

        elif choice == '2':
            # Manual lookup
            criteria = prompt_for_manual_lookup()
            
            if criteria:
                print("\nPerforming status lookup...")
                result = _perform_submission_context_lookup(criteria)
                
                # Display results
                display_submission_context_results(result)
                
                # Wait for user
                try:
                    raw_input("\nPress Enter to return to menu...") if sys.version_info[0] < 3 else input("\nPress Enter to return to menu...")
                except (KeyboardInterrupt, EOFError):
                    break
        
        elif choice == '3':
            break
        
        else:
            print("\nInvalid choice. Please enter 1, 2, or 3.")
            try:
                raw_input("Press Enter to continue...") if sys.version_info[0] < 3 else input("Press Enter to continue...")
            except (KeyboardInterrupt, EOFError):
                break


def _extract_member_data_from_submission(submission_record, config):
    """
    Extract member data from a submission record based on its source.
    
    Args:
        submission_record: Submission record from multi-source query
        config: Configuration dictionary
    
    Returns:
        dict: Member data for API lookup, or None if extraction fails
    """
    source = submission_record.get('source', '')

    def _clean_value(value):
        if value is None:
            return None
        if isinstance(value, str):
            value = value.strip()
            return value if value else None
        return value

    def _coalesce(record, keys):
        if not record:
            return None
        for key in keys:
            try:
                val = _clean_value(record.get(key))
            except Exception:
                val = None
            if val is not None:
                return val
        return None

    def _normalize_date_mmddyyyy(value):
        value = _clean_value(value)
        if not value:
            return ''
        # Prefer centralized date parsing helper when available (DRY).
        try:
            from MediCafe.deductible_utils import validate_and_format_date
        except Exception:
            validate_and_format_date = None

        if validate_and_format_date:
            try:
                normalized = validate_and_format_date(str(value).strip())
            except Exception:
                normalized = None
            if normalized:
                try:
                    return datetime.strptime(normalized, "%Y-%m-%d").strftime("%m/%d/%Y")
                except Exception:
                    pass

        # Fallback: try common formats locally
        try:
            patterns = [
                "%m/%d/%Y", "%m-%d-%Y", "%m.%d.%Y",
                "%Y-%m-%d", "%Y/%m/%d", "%Y.%m.%d",
                "%m/%d/%y", "%m-%d-%y", "%m.%d.%y"
            ]
            for pattern in patterns:
                try:
                    dt = datetime.strptime(str(value), pattern)
                    return dt.strftime("%m/%d/%Y")
                except Exception:
                    continue
        except Exception:
            pass

        return ''

    def _split_name(value):
        value = _clean_value(value)
        if not value:
            return ('', '')
        # Handle "Last, First" format
        if ',' in value:
            parts = [p.strip() for p in value.split(',', 1)]
            last = parts[0] if len(parts) > 0 else ''
            first = ''
            if len(parts) > 1 and parts[1]:
                first = parts[1].split()[0]
            return (first, last)
        parts = value.split()
        if len(parts) >= 2:
            return (parts[0], parts[-1])
        return ('', '')

    def _enrich_member_data(member_data, record):
        if not isinstance(member_data, dict):
            member_data = {}

        # Transaction ID
        if not member_data.get('transactionId'):
            member_data['transactionId'] = _coalesce(record, ['transactionId', 'transaction_id'])

        # Payer ID
        if not member_data.get('payer_id'):
            member_data['payer_id'] = _coalesce(record, ['payer_id', 'payerId'])

        # Member fields (prefer existing values)
        if not member_data.get('member_id'):
            member_data['member_id'] = _coalesce(record, ['member_id', 'memberId'])
        if not member_data.get('member_first_name'):
            member_data['member_first_name'] = _coalesce(record, ['member_first_name', 'memberFirstName', 'first_name', 'firstName'])
        if not member_data.get('member_last_name'):
            member_data['member_last_name'] = _coalesce(record, ['member_last_name', 'memberLastName', 'last_name', 'lastName'])
        if not member_data.get('member_dob'):
            dob_val = _coalesce(record, ['member_dob', 'memberDateOfBirth', 'dob', 'date_of_birth'])
            if dob_val:
                member_data['member_dob'] = _normalize_date_mmddyyyy(dob_val)

        # If names are still missing, try to derive from patient_name/name
        if not member_data.get('member_first_name') or not member_data.get('member_last_name'):
            name_val = _coalesce(record, ['patient_name', 'name'])
            if name_val:
                first, last = _split_name(name_val)
                if first and not member_data.get('member_first_name'):
                    member_data['member_first_name'] = first
                if last and not member_data.get('member_last_name'):
                    member_data['member_last_name'] = last

        # Service dates: prefer explicit start/end, fallback to DOS/service_date
        if not member_data.get('service_start_date'):
            start_val = _coalesce(record, ['service_start_date', 'serviceStartDate'])
            if not start_val:
                start_val = _coalesce(record, ['dos', 'service_date', 'serviceDate'])
            if start_val:
                member_data['service_start_date'] = _normalize_date_mmddyyyy(start_val)

        if not member_data.get('service_end_date'):
            end_val = _coalesce(record, ['service_end_date', 'serviceEndDate'])
            if not end_val:
                end_val = member_data.get('service_start_date')
            if end_val:
                member_data['service_end_date'] = _normalize_date_mmddyyyy(end_val)

        # Patient account number (optional, OPTUMAI only)
        if not member_data.get('patient_account_number'):
            member_data['patient_account_number'] = _coalesce(
                record, ['patient_account_number', 'patientAccountNumber']
            )

        return member_data

    try:
        # If source is index or receipt, read from 837p file
        if source in ['index', 'receipt']:
            receipt_file = submission_record.get('receipt_file', '')
            
            # Resolve relative paths to full paths
            if receipt_file and not os.path.isabs(receipt_file):
                # Try to resolve using receipts_root from config
                try:
                    from MediCafe.core_utils import extract_medilink_config
                    medi = extract_medilink_config(config)
                    receipts_root = medi.get('local_claims_path', '') if medi else ''
                    if receipts_root:
                        receipt_file = os.path.join(receipts_root, receipt_file)
                except Exception:
                    pass
            
            if receipt_file and os.path.exists(receipt_file):
                from MediCafe.x12_utils import extract_member_data_from_x12_file
                member_data = extract_member_data_from_x12_file(receipt_file)
                member_data = _enrich_member_data(member_data, submission_record)
                
                # Validate member data has required fields
                if not member_data or not (member_data.get('member_id') or member_data.get('member_first_name')):
                    return None
                
                return member_data
        
        # If source is dat, read from DAT file
        elif source == 'dat':
            dat_file = submission_record.get('dat_file', '')
            if dat_file and os.path.exists(dat_file):
                from MediCafe.dat_utils import parse_dat_file_for_submission_context
                member_data = parse_dat_file_for_submission_context(dat_file, config)
                member_data = _enrich_member_data(member_data, submission_record)
                # Validate member data has required fields (same as index/receipt path)
                if not member_data or not (member_data.get('member_id') or member_data.get('member_first_name')):
                    return None
                return member_data
        
        # Fallback: try to use data already in submission record
        if submission_record.get('member_id') or submission_record.get('member_first_name'):
            base = {
                'payer_id': submission_record.get('payer_id', ''),
                'transactionId': submission_record.get('transactionId'),
                'member_id': submission_record.get('member_id', ''),
                'member_first_name': submission_record.get('member_first_name', ''),
                'member_last_name': submission_record.get('member_last_name', ''),
                'member_dob': submission_record.get('member_dob', ''),
                'service_start_date': submission_record.get('service_start_date', ''),
                'service_end_date': submission_record.get('service_end_date', ''),
            }
            return _enrich_member_data(base, submission_record)
            
    except Exception as e:
        if DEBUG:
            MediLink_ConfigLoader.log(
                "Error extracting member data: {}".format(e),
                level="ERROR"
            )
    
    return None


def _perform_submission_context_lookup(criteria):
    """
    Perform the actual API lookup using the provided criteria.
    
    Args:
        criteria: Dict with lookup criteria (from manual entry or submission record)
    
    Returns:
        dict: Response from get_claim_status_by_submission_context()
    """
    try:
        from MediCafe.api_core import get_claim_status_by_submission_context
        
        # Determine lookup type (check both camelCase and snake_case keys)
        has_transaction = bool(
            criteria.get('transactionId') or criteria.get('transaction_id')
        )
        has_member_data = bool(
            criteria.get('memberId') or criteria.get('member_id') or
            criteria.get('memberFirstName') or criteria.get('member_first_name')
        )
        
        if has_transaction and has_member_data:
            lookup_type = 'both'
        elif has_transaction:
            lookup_type = '277ca'
        elif has_member_data:
            lookup_type = 'member_data'
        else:
            return {
                'lookup_type': 'none',
                'statuscode': '400',
                'message': 'Insufficient data for lookup',
                'ack_277ca': None,
                'claim_status': None,
            }
        
        # Get API client
        from MediCafe.core_utils import get_api_client
        client = get_api_client()
        
        if not client:
            return {
                'lookup_type': lookup_type,
                'statuscode': '500',
                'message': 'API client not available',
                'ack_277ca': None,
                'claim_status': None,
            }
        
        # Extract parameters (handle both camelCase and snake_case keys)
        transaction_id_param = criteria.get('transactionId') or criteria.get('transaction_id')
        payer_id_param = criteria.get('payerId') or criteria.get('payer_id')
        member_id_param = criteria.get('memberId') or criteria.get('member_id')
        member_first_name_param = criteria.get('memberFirstName') or criteria.get('member_first_name')
        member_last_name_param = criteria.get('memberLastName') or criteria.get('member_last_name')
        member_dob_param = criteria.get('memberDateOfBirth') or criteria.get('member_dob')
        service_start_date_param = criteria.get('serviceStartDate') or criteria.get('service_start_date')
        service_end_date_param = criteria.get('serviceEndDate') or criteria.get('service_end_date')
        patient_account_number_param = criteria.get('patientAccountNumber') or criteria.get('patient_account_number')
        
        # DEBUG: Log the parameters being sent (mask sensitive data)
        if DEBUG:
            MediLink_ConfigLoader.log(
                "[SUBMISSION_CONTEXT_LOOKUP] Parameters: payerId={}, memberId={}, memberDOB={}, serviceStart={}, serviceEnd={}, lookupType={}".format(
                    payer_id_param or 'None',
                    member_id_param[:5] + '***' if member_id_param and len(member_id_param) > 5 else (member_id_param or 'None'),
                    member_dob_param or 'None',
                    service_start_date_param or 'None',
                    service_end_date_param or 'None',
                    lookup_type
                ),
                level="DEBUG"
            )
        
        # Perform lookup
        result = get_claim_status_by_submission_context(
            client,
            transaction_id=transaction_id_param,
            payer_id=payer_id_param,
            member_id=member_id_param,
            member_first_name=member_first_name_param,
            member_last_name=member_last_name_param,
            member_dob=member_dob_param,
            service_start_date=service_start_date_param,
            service_end_date=service_end_date_param,
            patient_account_number=patient_account_number_param,
            lookup_type=lookup_type
        )
        
        return result
        
    except Exception as e:
        if DEBUG:
            MediLink_ConfigLoader.log(
                "Lookup error: {}".format(e),
                level="ERROR"
            )
        
        return {
            'lookup_type': 'error',
            'statuscode': '500',
            'message': 'Error performing lookup: {}'.format(str(e)),
            'ack_277ca': None,
            'claim_status': None,
        }


# Main execution with error reporting
if __name__ == "__main__":
    # Install unhandled exception hook to capture tracebacks
    try:
        if capture_unhandled_traceback is not None:
            sys.excepthook = capture_unhandled_traceback
    except Exception:
        pass

    # Main menu loop
    # #region agent log
    try:
        import json
        _log_file = open(r'g:\My Drive\Codes\MediCafe\.cursor\debug.log', 'a')
        _log_data = {
            "sessionId": "debug-session",
            "runId": "run1",
            "hypothesisId": "E",
            "location": "MediLink_ClaimStatus.py:743",
            "message": "Entering main menu loop",
            "data": {},
            "timestamp": int(time.time() * 1000)
        }
        _log_file.write(json.dumps(_log_data) + "\n")
        _log_file.close()
    except Exception:
        pass
    # #endregion
    recent_status_presented = False
    while True:
        try:
            # Main menu for Claims Status
            print("\n" + "="*80)
            print("UNITED CLAIMS STATUS CHECKER")
            print("="*80)

            if not recent_status_presented:
                print("\nLoading recent post-submission statuses first...")
                if not run_recent_submissions_lookup(config):
                    print("\nExiting...")
                    break
                recent_status_presented = True

            print("\nWhat would you like to do next?")
            print("1. Post-Submission Status Lookup")
            print("2. Bulk Provider Claims Report (all payers)")
            print("3. Exit")
            print("")
            
            try:
                menu_choice = raw_input("Enter choice (1-3): ").strip() if sys.version_info[0] < 3 else input("Enter choice (1-3): ").strip()
            except (KeyboardInterrupt, EOFError):
                print("\nExiting...")
                break
            
            if menu_choice == '1':
                # Post-submission status lookup
                post_submission_status_menu(config)

            elif menu_choice == '2':
                # Original bulk provider report
                # Initialize cache and consolidated claims
                cache = ClaimCache()
                consolidated_claims = ConsolidatedClaims()

                # Process claims with payer rotation
                process_claims_with_payer_rotation(
                    billing_provider_tin, start_date_str, end_date_str, payer_ids, cache, consolidated_claims
                )

                # Display consolidated results
                temp_dir = os.getenv('TEMP') or os.getenv('TMP') or '/tmp'  # Cross-platform temp directory
                output_file_path = os.path.join(temp_dir, 'claim_summary_report.txt')
                with open(output_file_path, 'w') as output_file:
                    display_consolidated_claims(consolidated_claims, output_file)

                # Clear cache after consolidated table is generated
                cache.clear_cache()

                # Open the generated file (cross-platform approach)
                try:
                    if os.name == 'nt':  # Windows
                        os.startfile(output_file_path)
                    elif os.name == 'posix':  # Unix/Linux/MacOS
                        import subprocess
                        subprocess.call(['xdg-open', output_file_path])
                    else:
                        if DEBUG:
                            print("File saved to: {}".format(output_file_path))
                except Exception as e:
                    if DEBUG:
                        print("File saved to: {}".format(output_file_path))
                        print("Could not open file automatically: {}".format(e))
                
                # Return to menu after completion
                try:
                    raw_input("\nPress Enter to return to main menu...") if sys.version_info[0] < 3 else input("\nPress Enter to return to main menu...")
                except (KeyboardInterrupt, EOFError):
                    break
            
            elif menu_choice == '3':
                print("Exiting...")
                break
            
            else:
                print("Invalid choice. Please enter 1, 2, or 3.")
                continue

        except Exception as e:
            # #region agent log
            try:
                import json
                import traceback
                _log_file = open(r'g:\My Drive\Codes\MediCafe\.cursor\debug.log', 'a')
                _log_data = {
                    "sessionId": "debug-session",
                    "runId": "run1",
                    "hypothesisId": "D",
                    "location": "MediLink_ClaimStatus.py:825",
                    "message": "Exception caught in main menu",
                    "data": {
                        "error": str(e),
                        "error_type": type(e).__name__,
                        "traceback": traceback.format_exc()
                    },
                    "timestamp": int(time.time() * 1000)
                }
                _log_file.write(json.dumps(_log_data) + "\n")
                _log_file.close()
            except Exception:
                pass
            # #endregion
            print("\n" + "="*60)
            print("CLAIM STATUS EXECUTION FAILURE")
            print("="*60)
            print("Error: {}".format(e))
            print("Error type: {}".format(type(e).__name__))
            print("="*60)

            # Collect and submit error report
            try:
                if submit_support_bundle_email is not None and collect_support_bundle is not None:
                    zip_path = collect_support_bundle(include_traceback=True)
                    if zip_path:
                        # Try to check internet connectivity
                        try:
                            from MediCafe.core_utils import check_internet_connection
                            online = check_internet_connection()
                        except ImportError:
                            # If we can't check connectivity during error reporting, assume offline
                            # to preserve the error bundle for later
                            online = False
                            print("Warning: Could not check internet connectivity - preserving error bundle.")

                        if online:
                            success = submit_support_bundle_email(zip_path)
                            if success:
                                # On success, remove the bundle
                                try:
                                    os.remove(zip_path)
                                except Exception:
                                    pass
                            else:
                                # Preserve bundle for manual retry
                                print("Error report send failed - bundle preserved at {} for retry.".format(zip_path))
                        else:
                            print("Offline - error bundle queued at {} for retry when online.".format(zip_path))
                    else:
                        print("Failed to create error report bundle.")
                else:
                    print("Error reporting not available - check MediCafe installation.")
            except Exception as report_e:
                print("Error report collection failed: {}".format(report_e))
            
            # Exit with error code 1 to indicate failure
            sys.exit(1)
