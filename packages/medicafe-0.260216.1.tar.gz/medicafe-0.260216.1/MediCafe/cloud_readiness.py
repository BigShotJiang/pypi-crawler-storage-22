#!/usr/bin/env python
"""
Cloud Readiness Pipeline service module.

Service-only: no UI. Launcher delegates phase actions here.
Returns (ok, message, data); no exceptions to caller.
Python 3.4 compatible.
"""
from __future__ import print_function

import json
import os
import subprocess
import sys
import time

try:
    from MediCafe.cloud_readiness_health import build_cloud_health_lines
except Exception:
    build_cloud_health_lines = None

try:
    from MediCafe.error_reporter import collect_support_bundle, submit_support_bundle_email
except Exception:
    collect_support_bundle = None
    submit_support_bundle_email = None

try:
    from subprocess import DEVNULL
except ImportError:
    DEVNULL = open(os.devnull, 'wb')


def resolve_lab_root(repo_root):
    """Resolve lab root: MEDICAFE_LAB_DIR > repo_root/lab."""
    env_lab = os.environ.get('MEDICAFE_LAB_DIR', '').strip()
    if env_lab:
        return os.path.abspath(env_lab)
    return os.path.join(repo_root, 'lab')


def is_pipeline_running(lab_root):
    """Check if shadow pipeline is running. Returns bool. Exception-safe."""
    try:
        from MediCafe.cloud_readiness_health import is_pipeline_running as _health_check
        return _health_check(lab_root)
    except Exception:
        return False


def check_pipeline_running_for_action(repo_root, action_name):
    """Returns (is_running, warning_msg). warning_msg set when is_running."""
    lab_root = resolve_lab_root(repo_root)
    running = is_pipeline_running(lab_root)
    msg = 'Note: Pipeline is running. {0} may reflect stale data.'.format(action_name) if running else None
    return (running, msg)


def run_pipeline(repo_root, python_exe, env, env_flag_fn):
    """
    When shadow_auto=1: spawn run_shadow_pipeline.py (non-blocking).
    When shadow_auto=0: Phase A blocks (subprocess.call), then B/C/D spawn via Popen.
    Env from os.environ.copy() + overlay MEDICAFE_LAB_DIR, target_folder, source_folder.
    """
    try:
        lab_root = resolve_lab_root(repo_root)
        proc_env = os.environ.copy()
        proc_env['MEDICAFE_LAB_DIR'] = lab_root
        proc_env['target_folder'] = env.get('target_folder', '')
        proc_env['source_folder'] = env.get('source_folder', '')

        if env_flag_fn('MEDICAFE_SHADOW_AUTO_PIPELINE', True):
            pipeline_script = os.path.join(repo_root, 'scripts', 'unified_model', 'run_shadow_pipeline.py')
            if not os.path.exists(pipeline_script):
                return (True, '', None)
            subprocess.Popen(
                [python_exe, pipeline_script],
                cwd=repo_root,
                env=proc_env,
                stdout=DEVNULL,
                stderr=DEVNULL,
            )
            return (True, '', None)
        else:
            # Phase A blocking
            if env_flag_fn('MEDICAFE_PHASE_A_AUTO_VALIDATE', True):
                bootstrap_script = os.path.join(repo_root, 'scripts', 'unified_model', 'bootstrap_lab.py')
                if os.path.exists(bootstrap_script):
                    rc = subprocess.call([python_exe, bootstrap_script], cwd=repo_root, env=proc_env)
                    if rc != 0:
                        return (False, 'Phase A bootstrap exited with code {0}'.format(rc), None)
            # Phase B/C/D non-blocking
            if env_flag_fn('MEDICAFE_PHASE_B_AUTO_DISCOVER', False):
                discover_script = os.path.join(repo_root, 'scripts', 'unified_model', 'discover_artifacts.py')
                if os.path.exists(discover_script):
                    try:
                        subprocess.Popen(
                            [python_exe, discover_script],
                            cwd=repo_root,
                            env=proc_env,
                            stdout=DEVNULL,
                            stderr=DEVNULL,
                        )
                    except Exception:
                        pass
            if env_flag_fn('MEDICAFE_PHASE_C_AUTO_INGEST', False):
                ingest_script = os.path.join(repo_root, 'scripts', 'unified_model', 'ingest_from_manifest.py')
                if os.path.exists(ingest_script):
                    try:
                        subprocess.Popen(
                            [python_exe, ingest_script],
                            cwd=repo_root,
                            env=proc_env,
                            stdout=DEVNULL,
                            stderr=DEVNULL,
                        )
                    except Exception:
                        pass
            if env_flag_fn('MEDICAFE_PHASE_D_AUTO_QA', False):
                qa_script = os.path.join(repo_root, 'scripts', 'unified_model', 'run_qa_canonical.py')
                if os.path.exists(qa_script):
                    try:
                        subprocess.Popen(
                            [python_exe, qa_script],
                            cwd=repo_root,
                            env=proc_env,
                            stdout=DEVNULL,
                            stderr=DEVNULL,
                        )
                    except Exception:
                        pass
            return (True, '', None)
    except Exception as e:
        return (False, str(e), None)


def _find_latest_run_id_by_prefix(reports_dir, prefix, suffix_choices):
    """
    Find latest file by prefix (mtime). Parse run_id from filename.
    Returns (run_id, path) or (None, None).
    Filename pattern: {prefix}{run_id}.{ext}
    """
    if not reports_dir or not os.path.exists(reports_dir):
        return (None, None)
    try:
        items = os.listdir(reports_dir)
    except (IOError, OSError):
        return (None, None)
    candidates = []
    prefix_len = len(prefix)
    for item in items:
        if not item.startswith(prefix):
            continue
        for suf in suffix_choices:
            if item.endswith(suf):
                path = os.path.join(reports_dir, item)
                if os.path.isfile(path):
                    rest = item[prefix_len:]
                    if '.' in rest:
                        run_id = rest.rsplit('.', 1)[0]
                    else:
                        run_id = rest
                    if run_id and len(run_id) >= 17 and '-' in run_id:
                        candidates.append((run_id, path))
                break
    if not candidates:
        return (None, None)
    try:
        return max(candidates, key=lambda x: os.path.getmtime(x[1]))
    except (IOError, OSError, ValueError):
        return (None, None)


def _reports_dir_access_error(lab_root):
    """Return readable error string when reports dir exists but is unreadable; else None."""
    reports_dir = os.path.join(lab_root, 'reports')
    if not reports_dir or not os.path.exists(reports_dir):
        return None
    try:
        os.listdir(reports_dir)
    except (IOError, OSError) as e:
        return 'Unable to read reports directory: {0}'.format(e)
    return None


def _select_latest_evidence_files(lab_root, prefix_specs):
    """
    Select latest coherent run's evidence files per prefix_specs.
    prefix_specs: [(prefix, suffix), ...] where suffix is None for (.txt, .json) or e.g. '.jsonl'.
    Returns [(basename, fullpath), ...].
    """
    reports_dir = os.path.join(lab_root, 'reports')
    if not reports_dir or not os.path.exists(reports_dir):
        return []
    if not prefix_specs:
        return []
    primary_prefix, primary_suffix = prefix_specs[0]
    suffix_choices = ('.txt', '.json') if primary_suffix is None else (primary_suffix,)
    run_id, _ = _find_latest_run_id_by_prefix(reports_dir, primary_prefix, suffix_choices)
    if not run_id:
        return []
    extra_files = []
    seen = set()
    for prefix, suffix in prefix_specs:
        if suffix is None:
            for ext in ('.json', '.txt'):
                basename = prefix + run_id + ext
                path = os.path.join(reports_dir, basename)
                if os.path.isfile(path) and basename not in seen:
                    extra_files.append((basename, path))
                    seen.add(basename)
        else:
            basename = prefix + run_id + suffix
            path = os.path.join(reports_dir, basename)
            if os.path.isfile(path) and basename not in seen:
                extra_files.append((basename, path))
                seen.add(basename)
    return extra_files


def _find_latest_by_prefix(reports_dir, prefix, suffix_choices):
    """Find latest file by prefix. Returns (path, None) or (None, message)."""
    if not reports_dir or not os.path.exists(reports_dir):
        return (None, 'No reports directory: {0}'.format(reports_dir))
    try:
        items = os.listdir(reports_dir)
    except (IOError, OSError) as e:
        return (None, 'Unable to read reports directory: {0}'.format(e))
    candidates = []
    for item in items:
        if item.startswith(prefix):
            for suf in suffix_choices:
                if item.endswith(suf):
                    path = os.path.join(reports_dir, item)
                    if os.path.isfile(path):
                        candidates.append(path)
                    break
    if not candidates:
        return (None, None)
    try:
        return (max(candidates, key=os.path.getmtime), None)
    except (IOError, OSError, ValueError):
        return (None, 'Unable to resolve latest report file.')


def open_phase_b_summary(repo_root):
    lab_root = resolve_lab_root(repo_root)
    reports_dir = os.path.join(lab_root, 'reports')
    path, msg = _find_latest_by_prefix(reports_dir, 'artifact_discovery_summary_', ('.txt', '.json'))
    if path:
        return (True, '', path)
    if msg:
        return (False, msg, None)
    return (False, 'No artifact discovery summaries found.', None)


def open_manifest_location(repo_root):
    """Return manifest file path for explorer /select. Launcher opens explorer, not viewer."""
    lab_root = resolve_lab_root(repo_root)
    cursor_path = os.path.join(lab_root, 'run_cursor.json')
    manifest_path = None
    if os.path.exists(cursor_path):
        try:
            with open(cursor_path, 'r', encoding='utf-8') as f:
                cursor = json.load(f)
            manifest_path = cursor.get('last_manifest_path')
        except (IOError, OSError, ValueError):
            pass
    if not manifest_path or not os.path.exists(manifest_path):
        reports_dir = os.path.join(lab_root, 'reports')
        if os.path.exists(reports_dir):
            try:
                report_items = os.listdir(reports_dir)
            except (IOError, OSError) as e:
                return (False, 'Unable to read reports directory: {0}'.format(e), None)
            manifests = [
                os.path.join(reports_dir, x) for x in report_items
                if x.startswith('artifact_manifest_') and x.endswith('.jsonl')
                and os.path.isfile(os.path.join(reports_dir, x))
            ]
            if manifests:
                try:
                    manifest_path = max(manifests, key=os.path.getmtime)
                except (IOError, OSError, ValueError):
                    return (False, 'Unable to resolve latest manifest file.', None)
    if manifest_path and os.path.exists(manifest_path):
        return (True, '', manifest_path)
    return (False, 'No manifest found. Run discovery from Cloud Readiness first.', None)


def run_phase_b_manual(repo_root, python_exe, env):
    script = os.path.join(repo_root, 'scripts', 'unified_model', 'discover_artifacts.py')
    if not os.path.exists(script):
        return (False, 'discover_artifacts.py not found.', None)
    try:
        lab_root = resolve_lab_root(repo_root)
        proc_env = os.environ.copy()
        proc_env['MEDICAFE_LAB_DIR'] = lab_root
        proc_env['target_folder'] = env.get('target_folder', '')
        proc_env['source_folder'] = env.get('source_folder', '')
        subprocess.Popen([python_exe, script], cwd=repo_root, env=proc_env)
        return (True, '', None)
    except Exception as e:
        return (False, str(e), None)


def _send_phase_evidence(lab_root, prefix_specs, extra_meta_key, no_attach_msg):
    """
    Send latest coherent run's evidence. prefix_specs: [(prefix, suffix), ...].
    Requires at least one phase artifact; context files are additive only.
    """
    if collect_support_bundle is None or submit_support_bundle_email is None:
        return (False, 'Support bundle tools unavailable.', None)
    reports_err = _reports_dir_access_error(lab_root)
    if reports_err:
        return (False, reports_err, None)
    phase_files = _select_latest_evidence_files(lab_root, prefix_specs)
    if not phase_files:
        return (False, no_attach_msg, None)
    extra_files = list(phase_files)
    for ctx_name in ('diagnostics_state.json', 'run_cursor.json'):
        ctx_path = os.path.join(lab_root, ctx_name)
        if os.path.isfile(ctx_path):
            extra_files.append((ctx_name, ctx_path))
    try:
        zip_path = collect_support_bundle(
            include_traceback=False,
            extra_meta={extra_meta_key: True, 'lab_root': lab_root},
            extra_files=extra_files,
        )
        if not zip_path:
            return (False, 'Failed to create support bundle.', None)
        ok = submit_support_bundle_email(zip_path, skip_interactive_reauth=True)
        return (ok, 'Report sent.' if ok else 'Report queued or failed.', None)
    except Exception as e:
        return (False, 'Error: {0}'.format(e), None)


def send_phase_b_evidence(repo_root):
    lab_root = resolve_lab_root(repo_root)
    return _send_phase_evidence(
        lab_root,
        [('artifact_discovery_summary_', None)],
        'phase_b_evidence',
        'No discovery summaries to attach.',
    )


def open_phase_c_summary(repo_root):
    lab_root = resolve_lab_root(repo_root)
    reports_dir = os.path.join(lab_root, 'reports')
    path, msg = _find_latest_by_prefix(reports_dir, 'ingest_write_summary_', ('.txt', '.json'))
    if path:
        return (True, '', path)
    if msg:
        return (False, msg, None)
    return (False, 'No Phase C ingest summaries found.', None)


def run_phase_c_manual(repo_root, python_exe, env):
    script = os.path.join(repo_root, 'scripts', 'unified_model', 'ingest_from_manifest.py')
    if not os.path.exists(script):
        return (False, 'ingest_from_manifest.py not found.', None)
    try:
        lab_root = resolve_lab_root(repo_root)
        proc_env = os.environ.copy()
        proc_env['MEDICAFE_LAB_DIR'] = lab_root
        subprocess.Popen([python_exe, script], cwd=repo_root, env=proc_env)
        return (True, '', None)
    except Exception as e:
        return (False, str(e), None)


def send_phase_c_evidence(repo_root):
    lab_root = resolve_lab_root(repo_root)
    return _send_phase_evidence(
        lab_root,
        [('ingest_write_summary_', None), ('ingest_write_anomalies_', '.jsonl')],
        'phase_c_evidence',
        'No Phase C summaries or anomalies to attach.',
    )


def open_phase_d_summary(repo_root):
    lab_root = resolve_lab_root(repo_root)
    reports_dir = os.path.join(lab_root, 'reports')
    path, msg = _find_latest_by_prefix(reports_dir, 'qa_canonical_summary_', ('.txt', '.json'))
    if path:
        return (True, '', path)
    if msg:
        return (False, msg, None)
    return (False, 'No Phase D summaries found.', None)


def open_phase_d_reject_sample(repo_root):
    lab_root = resolve_lab_root(repo_root)
    reports_dir = os.path.join(lab_root, 'reports')
    path, msg = _find_latest_by_prefix(reports_dir, 'qa_reject_samples_', ('.jsonl',))
    if path:
        return (True, '', path)
    if msg:
        return (False, msg, None)
    return (False, 'No Phase D reject sample files found.', None)


def run_phase_d_manual(repo_root, python_exe, env):
    script = os.path.join(repo_root, 'scripts', 'unified_model', 'run_qa_canonical.py')
    if not os.path.exists(script):
        return (False, 'run_qa_canonical.py not found.', None)
    try:
        lab_root = resolve_lab_root(repo_root)
        proc_env = os.environ.copy()
        proc_env['MEDICAFE_LAB_DIR'] = lab_root
        subprocess.Popen([python_exe, script], cwd=repo_root, env=proc_env)
        return (True, '', None)
    except Exception as e:
        return (False, str(e), None)


def send_phase_d_evidence(repo_root):
    lab_root = resolve_lab_root(repo_root)
    return _send_phase_evidence(
        lab_root,
        [('qa_canonical_summary_', None), ('qa_reject_samples_', '.jsonl')],
        'phase_d_evidence',
        'No Phase D summaries or reject samples to attach.',
    )


def open_phase_e_summary(repo_root):
    lab_root = resolve_lab_root(repo_root)
    reports_dir = os.path.join(lab_root, 'reports')
    path, msg = _find_latest_by_prefix(reports_dir, 'projection_parity_summary_', ('.txt', '.json'))
    if path:
        return (True, '', path)
    if msg:
        return (False, msg, None)
    return (False, 'No Phase E summaries found.', None)


def open_phase_e_deviation_samples(repo_root):
    lab_root = resolve_lab_root(repo_root)
    reports_dir = os.path.join(lab_root, 'reports')
    path, msg = _find_latest_by_prefix(reports_dir, 'projection_deviation_samples_', ('.jsonl',))
    if path:
        return (True, '', path)
    if msg:
        return (False, msg, None)
    return (False, 'No Phase E deviation sample files found.', None)


def run_phase_e_manual(repo_root, python_exe, env):
    script = os.path.join(repo_root, 'scripts', 'unified_model', 'run_projection_parity.py')
    if not os.path.exists(script):
        return (False, 'run_projection_parity.py not found.', None)
    try:
        lab_root = resolve_lab_root(repo_root)
        proc_env = os.environ.copy()
        proc_env['MEDICAFE_LAB_DIR'] = lab_root
        subprocess.Popen([python_exe, script], cwd=repo_root, env=proc_env)
        return (True, '', None)
    except Exception as e:
        return (False, str(e), None)


def send_phase_e_evidence(repo_root):
    lab_root = resolve_lab_root(repo_root)
    return _send_phase_evidence(
        lab_root,
        [('projection_parity_summary_', None), ('projection_deviation_samples_', '.jsonl')],
        'phase_e_evidence',
        'No Phase E summaries or deviation samples to attach.',
    )


def run_shadow_pipeline(repo_root, python_exe, env):
    script = os.path.join(repo_root, 'scripts', 'unified_model', 'run_shadow_pipeline.py')
    if not os.path.exists(script):
        return (True, '', None)
    try:
        lab_root = resolve_lab_root(repo_root)
        proc_env = os.environ.copy()
        proc_env['MEDICAFE_LAB_DIR'] = lab_root
        proc_env['target_folder'] = env.get('target_folder', '')
        proc_env['source_folder'] = env.get('source_folder', '')
        subprocess.Popen(
            [python_exe, script],
            cwd=repo_root,
            env=proc_env,
            stdout=DEVNULL,
            stderr=DEVNULL,
        )
        return (True, '', None)
    except Exception as e:
        return (False, str(e), None)


def open_phase_f_shadow_report(repo_root):
    lab_root = resolve_lab_root(repo_root)
    reports_dir = os.path.join(lab_root, 'reports')
    path, msg = _find_latest_by_prefix(reports_dir, 'shadow_run_report_', ('.txt', '.json'))
    if path:
        return (True, '', path)
    if msg:
        return (False, msg, None)
    return (False, 'No Shadow Health reports found yet.', None)


def open_phase_f_evidence_index(repo_root):
    lab_root = resolve_lab_root(repo_root)
    reports_dir = os.path.join(lab_root, 'reports')
    path, msg = _find_latest_by_prefix(reports_dir, 'shadow_evidence_index_', ('.json',))
    if path:
        return (True, '', path)
    if msg:
        return (False, msg, None)
    return (False, 'No Phase F evidence indexes found.', None)


def run_phase_f_manual(repo_root, python_exe, env, pipeline_running=None):
    """
    Rebuild Phase F (latest-at-execution). Does not pass --pipeline-run-id.
    Returns (ok, msg, pipeline_running).
    """
    script = os.path.join(repo_root, 'scripts', 'unified_model', 'package_shadow_run_report.py')
    if not os.path.exists(script):
        return (False, 'package_shadow_run_report.py not found.', None)
    try:
        lab_root = resolve_lab_root(repo_root)
        if pipeline_running is None:
            pipeline_running = is_pipeline_running(lab_root)
        proc_env = os.environ.copy()
        proc_env['MEDICAFE_LAB_DIR'] = lab_root
        cmd = [python_exe, script, '--auto-report', '0']
        subprocess.Popen(cmd, cwd=repo_root, env=proc_env, stdout=DEVNULL)
        return (True, '', pipeline_running)
    except Exception as e:
        return (False, str(e), None)


def run_phase_f_manual_for_run_id(repo_root, python_exe, env, run_id):
    """
    Rebuild Phase F for explicit run_id (strict). Always passes --pipeline-run-id.
    Does NOT read state. Returns (ok, msg, None).
    """
    script = os.path.join(repo_root, 'scripts', 'unified_model', 'package_shadow_run_report.py')
    if not os.path.exists(script):
        return (False, 'package_shadow_run_report.py not found.', None)
    run_id = (run_id or '').strip()
    if not run_id:
        return (False, 'run_id is required.', None)
    try:
        lab_root = resolve_lab_root(repo_root)
        proc_env = os.environ.copy()
        proc_env['MEDICAFE_LAB_DIR'] = lab_root
        cmd = [python_exe, script, '--pipeline-run-id', run_id, '--auto-report', '0']
        subprocess.Popen(cmd, cwd=repo_root, env=proc_env, stdout=DEVNULL)
        return (True, '', None)
    except Exception as e:
        return (False, str(e), None)


def send_phase_f_evidence(repo_root):
    lab_root = resolve_lab_root(repo_root)
    no_attach_msg = 'No Shadow Health report/evidence files found to attach.'
    if collect_support_bundle is None or submit_support_bundle_email is None:
        return (False, 'Support bundle tools unavailable.', None)
    reports_err = _reports_dir_access_error(lab_root)
    if reports_err:
        return (False, reports_err, None)
    phase_files = _select_latest_evidence_files(lab_root, [
        ('shadow_run_report_', None),
        ('shadow_evidence_index_', '.json'),
        ('phase_f_mismatch_', '.txt'),
    ])
    if not phase_files:
        reports_dir = os.path.join(lab_root, 'reports')
        mismatch_path, _ = _find_latest_by_prefix(reports_dir, 'phase_f_mismatch_', ('.txt',))
        if mismatch_path:
            basename = os.path.basename(mismatch_path)
            phase_files = [(basename, mismatch_path)]
    if not phase_files:
        return (False, no_attach_msg, None)
    extra_files = list(phase_files)
    for ctx_name in ('diagnostics_state.json', 'run_cursor.json'):
        ctx_path = os.path.join(lab_root, ctx_name)
        if os.path.isfile(ctx_path):
            extra_files.append((ctx_name, ctx_path))
    try:
        zip_path = collect_support_bundle(
            include_traceback=False,
            extra_meta={'phase_f_evidence': True, 'lab_root': lab_root},
            extra_files=extra_files,
        )
        if not zip_path:
            return (False, 'Failed to create support bundle.', None)
        ok = submit_support_bundle_email(zip_path, skip_interactive_reauth=True)
        return (ok, 'Report sent.' if ok else 'Report queued or failed.', None)
    except Exception as e:
        return (False, 'Error: {0}'.format(e), None)


def open_consolidated_health_report(repo_root, env_flag_fn):
    """
    Generate and return path to consolidated health report (all phases B-F).
    Writes Pipeline Health Snapshot to lab/reports/consolidated_health_snapshot.txt,
    appending latest shadow_run_report content if available.
    Returns (ok, message, path).
    """
    lab_root = resolve_lab_root(repo_root)
    lines = get_health_lines(lab_root, env_flag_fn)
    reports_dir = os.path.join(lab_root, 'reports')
    try:
        if reports_dir and not os.path.exists(reports_dir):
            os.makedirs(reports_dir, exist_ok=True)
        path = os.path.join(reports_dir, 'consolidated_health_snapshot.txt')
        content = '\n'.join(lines) + '\n'
        # Append latest shadow_run_report for full phase details
        shadow_path, _ = _find_latest_by_prefix(
            reports_dir, 'shadow_run_report_', ('.txt', '.json'))
        if shadow_path and shadow_path.endswith('.txt'):
            try:
                with open(shadow_path, 'r', encoding='utf-8') as f:
                    shadow_content = f.read()
                content += '\n--- Phase F detailed report ---\n'
                content += shadow_content
            except (IOError, OSError):
                pass
        with open(path, 'w', encoding='utf-8') as f:
            f.write(content)
        return (True, '', path)
    except Exception as e:
        return (False, str(e), None)


def get_health_lines(lab_root, env_flag_fn):
    """Return list of health lines. Uses build_cloud_health_lines or diagnostics_state fallback."""
    if build_cloud_health_lines:
        try:
            return build_cloud_health_lines(
                lab_root,
                auto_pipeline=env_flag_fn('MEDICAFE_SHADOW_AUTO_PIPELINE', True),
                auto_health=env_flag_fn('MEDICAFE_SHADOW_SEND_HEALTH', True),
            )
        except Exception:
            pass
    state_path = os.path.join(lab_root, 'diagnostics_state.json')
    if not os.path.exists(state_path):
        auto_pipeline = env_flag_fn('MEDICAFE_SHADOW_AUTO_PIPELINE', True)
        auto_health = env_flag_fn('MEDICAFE_SHADOW_SEND_HEALTH', True)
        return [
            'No diagnostics state found yet: {0}'.format(state_path),
            'Automation: pipeline_auto={0}, health_telemetry_auto={1}'.format(
                auto_pipeline, auto_health),
        ]
    try:
        with open(state_path, 'r', encoding='utf-8') as f:
            state = json.load(f)
        rid = state.get('last_shadow_pipeline_run_id', '')
        ok = state.get('last_shadow_pipeline_ok', False)
        failed = state.get('last_shadow_pipeline_failed_phase', '')
        parity = state.get('last_contract_parity_status', '')
        auto_pipeline = env_flag_fn('MEDICAFE_SHADOW_AUTO_PIPELINE', True)
        auto_health = env_flag_fn('MEDICAFE_SHADOW_SEND_HEALTH', True)
        return [
            'Last run: {0}, ok={1}, failed_phase={2}, parity={3}'.format(
                rid or '(none)', ok, failed or '-', parity or '-'),
            'Automation: pipeline_auto={0}, health_telemetry_auto={1}'.format(
                auto_pipeline, auto_health),
        ]
    except (IOError, OSError, ValueError):
        return []
