#!/usr/bin/env python
"""
Phase D Parse Provider layer: class-specific extraction wrappers returning
normalized envelope. Safe wrappers around legacy parsers. XP-compatible: Python 3.4.4.
"""
from __future__ import print_function

import csv
import io
import json
import os
import sys

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
if _SCRIPT_DIR not in sys.path:
    sys.path.insert(0, _SCRIPT_DIR)

from phase_d_common import (
    QA_FILE_READ_ERROR,
    QA_PARSE_ERROR,
    QA_UNKNOWN_ARTIFACT_CLASS,
)


def _safe_wrap_legacy(func, *args, **kwargs):
    """
    Wrap legacy function call. Catches SystemExit, KeyboardInterrupt, Exception.
    Redirects stdout/stderr during call to suppress legacy print output.
    Returns (ok, data, parser_warning_code). Never raises.
    """
    _saved_stdout = sys.stdout
    _saved_stderr = sys.stderr
    sys.stdout = io.StringIO()
    sys.stderr = io.StringIO()
    try:
        result = func(*args, **kwargs)
        return (True, result, None)
    except SystemExit:
        return (False, None, QA_PARSE_ERROR)
    except KeyboardInterrupt:
        return (False, None, QA_PARSE_ERROR)
    except Exception:
        return (False, None, QA_PARSE_ERROR)
    finally:
        sys.stdout = _saved_stdout
        sys.stderr = _saved_stderr


def _read_file_content(locator):
    """
    Fetch adapter: read file at locator (XP: filesystem path).
    Returns (ok, content_bytes, error_code). content_bytes is None on failure.
    """
    if not locator or not isinstance(locator, str) or not locator.strip():
        return (False, None, QA_FILE_READ_ERROR)
    path = locator.strip()
    if not os.path.exists(path) or not os.path.isfile(path):
        return (False, None, QA_FILE_READ_ERROR)
    try:
        with open(path, "rb") as f:
            content = f.read()
        return (True, content, None)
    except (IOError, OSError):
        return (False, None, QA_FILE_READ_ERROR)


def _normalize_csv_envelope(rows):
    """Convert CSV rows to normalized envelope for QA. Keys: rows, row_count, has_patient_id."""
    if not isinstance(rows, list):
        return None
    has_patient_id = False
    for row in rows:
        if isinstance(row, dict):
            pid = row.get("Patient ID") or row.get("patient_id") or ""
            if pid:
                has_patient_id = True
                break
    return {
        "rows": rows,
        "row_count": len(rows),
        "has_patient_id": has_patient_id,
    }


def parse_csv(locator, metadata=None):
    """
    Parse CSV artifact. Uses legacy load_csv_data via safe wrapper.
    Returns (ok, envelope, parser_warning_code).
    envelope: {rows, row_count, has_patient_id} or None.
    """
    metadata = metadata or {}
    try:
        from MediBot.MediBot_Preprocessor_lib import load_csv_data
    except ImportError:
        # Fallback: parse with stdlib csv only
        ok, content, err = _read_file_content(locator)
        if not ok:
            return (False, None, err or QA_FILE_READ_ERROR)
        try:
            text = content.decode("utf-8", errors="replace")
            reader = csv.DictReader(io.StringIO(text))
            rows = list(reader)
            envelope = _normalize_csv_envelope(rows)
            return (True, envelope, None)
        except Exception:
            return (False, None, QA_PARSE_ERROR)

    ok, data, err = _safe_wrap_legacy(load_csv_data, locator)
    if not ok:
        return (False, None, err or QA_PARSE_ERROR)
    envelope = _normalize_csv_envelope(data if isinstance(data, list) else [])
    return (True, envelope, None)


def parse_jsonl(locator, metadata=None):
    """
    Parse JSONL artifact. Returns (ok, envelope, parser_warning_code).
    envelope: {rows, row_count, has_claim_number}.
    """
    metadata = metadata or {}
    ok, content, err = _read_file_content(locator)
    if not ok:
        return (False, None, err or QA_FILE_READ_ERROR)
    try:
        text = content.decode("utf-8", errors="replace")
        rows = []
        for line in text.splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                rows.append(json.loads(line))
            except (ValueError, TypeError):
                pass
        has_claim = any(
            isinstance(r, dict) and (r.get("claim_number") or r.get("Claim #"))
            for r in rows
        )
        envelope = {
            "rows": rows,
            "row_count": len(rows),
            "has_claim_number": has_claim,
        }
        return (True, envelope, None)
    except Exception:
        return (False, None, QA_PARSE_ERROR)


def parse_x12(locator, metadata=None):
    """
    Parse 837 X12 artifact. Uses x12_utils extractors.
    Returns (ok, envelope, parser_warning_code).
    envelope: {member_id, member_first_name, member_last_name, member_dob, service_start_date, service_end_date, payer_id}.
    """
    metadata = metadata or {}
    ok, content, err = _read_file_content(locator)
    if not ok:
        return (False, None, err or QA_FILE_READ_ERROR)
    try:
        text = content.decode("utf-8", errors="replace")
        try:
            from MediCafe.x12_utils import (
                extract_member_id_from_x12,
                extract_member_name_from_x12,
                extract_member_dob_from_x12,
                extract_service_dates_from_x12,
                extract_payer_id_from_x12,
            )
        except ImportError:
            return (False, None, QA_PARSE_ERROR)
        member_id = extract_member_id_from_x12(text)
        first_name, last_name = extract_member_name_from_x12(text)
        dob = extract_member_dob_from_x12(text)
        service_start, service_end = extract_service_dates_from_x12(text)
        payer_id = extract_payer_id_from_x12(text)
        envelope = {
            "member_id": member_id,
            "member_first_name": first_name,
            "member_last_name": last_name,
            "member_dob": dob,
            "service_start_date": service_start,
            "service_end_date": service_end,
            "payer_id": payer_id,
        }
        return (True, envelope, None)
    except Exception:
        return (False, None, QA_PARSE_ERROR)


def parse_dat(locator, metadata=None):
    """
    Parse DAT/fixed-width artifact. Uses MediLink_DataMgmt readers.
    Normalizes tuple records to dicts via parse_fixed_width_data.
    Returns (ok, envelope, parser_warning_code).
    """
    metadata = metadata or {}
    try:
        from MediLink.MediLink_DataMgmt import read_fixed_width_data, parse_fixed_width_data
    except ImportError:
        return (False, None, QA_PARSE_ERROR)
    try:
        from MediCafe.core_utils import get_shared_config_loader
        config_loader = get_shared_config_loader()
        config, _ = config_loader.load_configuration()
    except Exception:
        return (False, None, QA_PARSE_ERROR)
    ok, data, err = _safe_wrap_legacy(read_fixed_width_data, locator)
    if not ok:
        return (False, None, err or QA_PARSE_ERROR)
    raw_records = list(data) if data is not None else []
    records = []
    for rec in raw_records:
        if isinstance(rec, dict):
            records.append(rec)
        elif isinstance(rec, (tuple, list)) and len(rec) >= 3:
            try:
                personal_info = rec[0] if len(rec) > 0 else ""
                insurance_info = rec[1] if len(rec) > 1 else ""
                service_info = rec[2] if len(rec) > 2 else ""
                service_info_2 = rec[3] if len(rec) > 3 else None
                service_info_3 = rec[4] if len(rec) > 4 else None
                parsed = parse_fixed_width_data(
                    personal_info, insurance_info, service_info,
                    service_info_2, service_info_3, config=config
                )
                if isinstance(parsed, dict):
                    records.append(parsed)
            except Exception:
                pass
    envelope = {
        "records": records,
        "record_count": len(records),
    }
    return (True, envelope, None)


def parse_docx(locator, metadata=None):
    """
    Parse DOCX artifact. Prefers index (artifact-scoped by source_file), fallback to parse_docx.
    Returns (ok, envelope, parser_warning_code).
    """
    metadata = metadata or {}
    current_filename = os.path.basename(locator) if locator else ""
    local_storage = metadata.get("local_storage_path") or (os.path.dirname(locator) if locator else "")
    try:
        from MediBot.MediBot_docx_index import load_docx_schedule_index
        index_data = load_docx_schedule_index(local_storage)
        if index_data and index_data.get("schedules") and current_filename:
            raw_schedules = index_data.get("schedules", {})
            scoped_schedules = {}
            for date_str, entry in raw_schedules.items():
                if not isinstance(entry, dict):
                    continue
                current = entry.get("current")
                if not isinstance(current, dict):
                    continue
                if current.get("source_file") != current_filename:
                    continue
                patients = current.get("patients") or {}
                if patients:
                    scoped_schedules[date_str] = patients
            if scoped_schedules:
                envelope = {"source": "index", "schedules": scoped_schedules}
                return (True, envelope, None)
    except ImportError:
        pass
    except Exception:
        pass
    try:
        from MediBot.MediBot_docx_decoder import parse_docx
    except ImportError:
        return (False, None, QA_PARSE_ERROR)
    ok, data, err = _safe_wrap_legacy(parse_docx, locator, None, capture_schedule_positions=False)
    if not ok:
        return (False, None, err or QA_PARSE_ERROR)
    envelope = {"source": "parse_docx", "patient_data": data if isinstance(data, dict) else {}}
    return (True, envelope, None)


def get_parse_provider(artifact_class):
    """
    Return parse provider function for artifact_class, or None if unsupported.
    """
    providers = {
        "csv": parse_csv,
        "jsonl": parse_jsonl,
        "837": parse_x12,
        "dat": parse_dat,
        "docx": parse_docx,
    }
    return providers.get(artifact_class)


def parse_artifact(locator, artifact_class, metadata=None):
    """
    Parse artifact by class. Returns (ok, envelope, parser_warning_code).
    If artifact_class unsupported, returns (False, None, QA_UNKNOWN_ARTIFACT_CLASS).
    """
    provider = get_parse_provider(artifact_class)
    if provider is None:
        return (False, None, QA_UNKNOWN_ARTIFACT_CLASS)
    return provider(locator, metadata)
