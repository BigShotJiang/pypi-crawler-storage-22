#!/usr/bin/env python
"""
Phase A autonomous failure report: builds bundle and submits via MediCafe error reporter.
Uses skip_interactive_reauth=True for unattended operation.
XP-compatible: Python 3.4.4, stdlib only where possible.
"""
from __future__ import print_function

import hashlib
import json
import os
import sys

# Ensure workspace root and script dir on path for imports
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_WORKSPACE_ROOT = os.path.abspath(os.path.join(_SCRIPT_DIR, "..", ".."))
if _WORKSPACE_ROOT not in sys.path:
    sys.path.insert(0, _WORKSPACE_ROOT)
if _SCRIPT_DIR not in sys.path:
    sys.path.insert(0, _SCRIPT_DIR)

from phase_a_common import iso_utc_now

DEDUP_WINDOW_SEC = 4 * 3600  # 4 hours


def submit_phase_a_failure_report(lab_root, failure_context):
    """
    Build Phase A failure bundle and submit via error reporter.
    Uses skip_interactive_reauth=True; no token => leave in queue.

    failure_context: dict with error_code, run_id, first_failed_check, schema_sql_sha256,
                     report_json_path, report_txt_path (optional, for pre-self-check failures).

    Returns True if report sent, False if queued or failed.
    """
    try:
        from MediCafe.error_reporter import (
            collect_support_bundle,
            submit_support_bundle_email,
            check_report_dedup,
        )
    except ImportError as e:
        try:
            import logging
            logging.getLogger(__name__).warning("Phase A report: error_reporter unavailable: {0}".format(e))
        except Exception:
            pass
        return False

    _lab_lock_module = None
    try:
        import lab_lock as _lab_lock_module
    except ImportError:
        pass

    error_code = failure_context.get("error_code", "PHASE_A_SELFCHECK_FAIL")
    first_failed_check = failure_context.get("first_failed_check", "unknown")
    schema_sql_sha256 = failure_context.get("schema_sql_sha256", "")
    run_id = failure_context.get("run_id", "")

    dedup_key = hashlib.sha256(
        ("phase_a" + error_code + first_failed_check + schema_sql_sha256).encode("utf-8")
    ).hexdigest()

    state_path = os.path.join(lab_root, "diagnostics_state.json")
    state_dir = os.path.dirname(state_path)
    if state_dir and not os.path.exists(state_dir):
        try:
            os.makedirs(state_dir, exist_ok=True)
        except (IOError, OSError):
            pass

    # Caller (bootstrap) holds shadow.lock; no acquire needed here.
    should_send, state = check_report_dedup(state_path, dedup_key, DEDUP_WINDOW_SEC)
    if not should_send:
        return False

    extra_meta = {
        "phase_a_failure": True,
        "error_code": error_code,
        "run_id": run_id,
        "first_failed_check": first_failed_check,
        "lab_root": lab_root,
        "error_summary": "Phase A bootstrap failed: {0} ({1})".format(error_code, first_failed_check),
    }

    extra_files = []
    report_json = failure_context.get("report_json_path")
    report_txt = failure_context.get("report_txt_path")
    if report_json and os.path.exists(report_json):
        extra_files.append(("phase_a_selfcheck.json", report_json))
    if report_txt and os.path.exists(report_txt):
        extra_files.append(("phase_a_selfcheck.txt", report_txt))
    summary = failure_context.get("diagnostics_summary")
    if isinstance(summary, dict):
        extra_files.append(("diagnostics_summary.json", summary))

    zip_path = collect_support_bundle(
        include_traceback=False,
        extra_meta=extra_meta,
        extra_files=extra_files if extra_files else None,
    )
    if not zip_path:
        return False

    success = submit_support_bundle_email(
        zip_path,
        skip_interactive_reauth=True,
        extra_meta=extra_meta,
        extra_files=extra_files if extra_files else None,
    )

    if success and state_path:
        state["last_report_sent_at_utc"] = iso_utc_now()
        state["last_report_dedup_key"] = dedup_key
        state["version"] = state.get("version", 1)
        if _lab_lock_module and hasattr(_lab_lock_module, "replace_safe_write"):
            try:
                _lab_lock_module.replace_safe_write(state_path, state)
            except (IOError, OSError):
                pass

    return success
