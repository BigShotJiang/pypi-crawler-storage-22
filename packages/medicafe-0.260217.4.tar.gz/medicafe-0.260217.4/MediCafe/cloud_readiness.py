#!/usr/bin/env python
"""
Cloud Readiness Pipeline service module.

Service-only: no UI. Launcher delegates phase actions here.
Returns (ok, message, data); no exceptions to caller.
Python 3.4 compatible.
"""
from __future__ import print_function

import json
import os
import re
import subprocess
import sys
import time

try:
    from MediCafe.MediLink_ConfigLoader import log as mc_log
except Exception:
    mc_log = None

try:
    from MediCafe.cloud_readiness_health import build_cloud_health_lines
except Exception:
    build_cloud_health_lines = None

try:
    from MediCafe.error_reporter import collect_support_bundle, submit_support_bundle_email
except Exception:
    collect_support_bundle = None
    submit_support_bundle_email = None

try:
    from subprocess import DEVNULL
except ImportError:
    DEVNULL = open(os.devnull, 'wb')


_HEALTH_TRACKER_FILENAME = 'cloud_health_tracker.json'
_HEALTH_ALERT_STATE_FILENAME = 'cloud_health_alert_state.json'
_WARN_ESCALATION_MIN_COUNT = 3
_WARN_ESCALATION_MIN_AGE_SEC = 120
_ALERT_DEDUP_WINDOW_SEC = 6 * 60 * 60
# Bootstrap-only warn codes: expected before any pipeline run; do not escalate to incident alerts.
_WARN_NON_ESCALATING_CODES = frozenset([
    'DIAGNOSTICS_STATE_MISSING',
    'PHASE_B_NOT_RUN', 'PHASE_C_NOT_RUN', 'PHASE_D_NOT_RUN',
    'PHASE_E_NOT_RUN', 'PHASE_F_NOT_RUN',
])


def _log_health(level, message):
    """Best-effort logger for cloud readiness diagnostics."""
    try:
        if mc_log is not None:
            mc_log(message, level=level)
            return
    except Exception:
        pass
    try:
        print('{0}: {1}'.format(level, message))
    except Exception:
        pass


def _load_json_dict(path):
    if not path or not os.path.exists(path):
        return {}
    try:
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        if isinstance(data, dict):
            return data
    except (IOError, OSError, ValueError):
        pass
    return {}


def _save_json_dict(path, data):
    try:
        parent = os.path.dirname(path)
        if parent and not os.path.exists(parent):
            os.makedirs(parent)
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, sort_keys=True)
        return True
    except Exception:
        return False


def _collect_health_diagnostics(lab_root, auto_resolve=True):
    """Collect cloud readiness diagnostics and small auto-resolve actions."""
    diagnostics = {
        'severity': 'ok',
        'issues': [],
        'auto_resolved': [],
    }

    def _add_issue(severity, code, message):
        diagnostics['issues'].append({
            'severity': severity,
            'code': code,
            'message': message,
        })
        if severity == 'fail':
            diagnostics['severity'] = 'fail'
        elif severity == 'warn' and diagnostics['severity'] == 'ok':
            diagnostics['severity'] = 'warn'

    if not lab_root:
        _add_issue('fail', 'LAB_ROOT_MISSING', 'Lab root is empty and cannot be evaluated.')
        return diagnostics
    if not os.path.isdir(lab_root):
        _add_issue('fail', 'LAB_ROOT_NOT_FOUND', _describe_lab_root_issue(lab_root))
        return diagnostics

    reports_dir = os.path.join(lab_root, 'reports')
    if not os.path.exists(reports_dir) and auto_resolve:
        try:
            os.makedirs(reports_dir)
            diagnostics['auto_resolved'].append('Created missing reports directory: {0}'.format(reports_dir))
        except (IOError, OSError) as e:
            _add_issue('warn', 'REPORTS_DIR_CREATE_FAILED', 'Failed to create reports directory: {0}'.format(e))

    lock_path = os.path.join(lab_root, 'shadow_pipeline.lock')
    if os.path.exists(lock_path):
        running = is_pipeline_running(lab_root)
        if not running and auto_resolve:
            try:
                os.remove(lock_path)
                diagnostics['auto_resolved'].append('Removed stale pipeline lock: {0}'.format(lock_path))
            except (IOError, OSError) as e:
                _add_issue('warn', 'STALE_LOCK_REMOVE_FAILED', 'Failed to remove stale lock: {0}'.format(e))

    state_path = os.path.join(lab_root, 'diagnostics_state.json')
    if not os.path.exists(state_path):
        _add_issue('warn', 'DIAGNOSTICS_STATE_MISSING', 'diagnostics_state.json was not found: {0}'.format(state_path))
        return diagnostics
    try:
        with open(state_path, 'r', encoding='utf-8') as f:
            state = json.load(f)
    except (IOError, OSError) as e:
        _add_issue('fail', 'DIAGNOSTICS_STATE_READ_FAILED', 'Could not read diagnostics_state.json: {0}'.format(e))
        return diagnostics
    except ValueError as e:
        _add_issue('fail', 'DIAGNOSTICS_STATE_INVALID_JSON', 'diagnostics_state.json has invalid JSON: {0}'.format(e))
        return diagnostics
    if not isinstance(state, dict):
        _add_issue('fail', 'DIAGNOSTICS_STATE_INVALID_TYPE', 'diagnostics_state.json root must be an object/dict.')
        return diagnostics

    phase_specs = [
        ('B', 'last_phase_b_run_id', 'last_discovery_ok', 'last_discovery_error_code'),
        ('C', 'last_phase_c_run_id', 'last_phase_c_ok', 'last_phase_c_error_code'),
        ('D', 'last_phase_d_run_id', 'last_phase_d_ok', 'last_phase_d_error_code'),
        ('E', 'last_phase_e_run_id', 'last_phase_e_ok', 'last_phase_e_error_code'),
        ('F', 'last_shadow_pipeline_run_id', 'last_shadow_pipeline_ok', 'last_shadow_pipeline_error_code'),
    ]
    for phase, run_key, ok_key, err_key in phase_specs:
        run_id = str(state.get(run_key, '') or '').strip()
        ok_value = state.get(ok_key, None)
        err_value = str(state.get(err_key, '') or '').strip()
        if not run_id and ok_value is None:
            _add_issue('warn', 'PHASE_{0}_NOT_RUN'.format(phase),
                       'Phase {0} has no run id and no completion state.'.format(phase))
        elif ok_value is False and not err_value:
            _add_issue('warn', 'PHASE_{0}_ERROR_CODE_MISSING'.format(phase),
                       'Phase {0} failed with no error code.'.format(phase))
    return diagnostics


def _update_health_issue_tracker(lab_root, diagnostics, now_epoch=None):
    """Track intermittent/repeated issues across checks and identify escalation candidates."""
    now_epoch = int(now_epoch or time.time())
    # TODO(agent-followup): Consider a bounded "recent history" ring-buffer per issue code
    # so we can include cadence details (e.g., bursty vs steady failures) in support bundles
    # without growing this tracker file indefinitely over long-lived installations.
    tracker_path = os.path.join(lab_root or '.', _HEALTH_TRACKER_FILENAME)
    tracker = _load_json_dict(tracker_path)
    issues = tracker.get('issues', {}) if isinstance(tracker.get('issues', {}), dict) else {}
    current_keys = []
    escalated_codes = []

    for issue in diagnostics.get('issues', []):
        code = str(issue.get('code', '') or '').strip()
        severity = str(issue.get('severity', 'warn') or 'warn').strip().lower()
        if not code:
            continue
        current_keys.append(code)
        rec = issues.get(code, {}) if isinstance(issues.get(code, {}), dict) else {}
        count = int(rec.get('count', 0) or 0) + 1
        first_seen = int(rec.get('first_seen_epoch', now_epoch) or now_epoch)
        rec.update({
            'severity': severity,
            'count': count,
            'first_seen_epoch': first_seen,
            'last_seen_epoch': now_epoch,
            'message': issue.get('message', ''),
        })
        issues[code] = rec
        age = now_epoch - first_seen
        if severity == 'fail':
            escalated_codes.append(code)
        elif (severity == 'warn' and code not in _WARN_NON_ESCALATING_CODES
              and count >= _WARN_ESCALATION_MIN_COUNT and age >= _WARN_ESCALATION_MIN_AGE_SEC):
            escalated_codes.append(code)

    resolved = []
    for code in list(issues.keys()):
        if code not in current_keys:
            rec = issues.get(code, {})
            if isinstance(rec, dict):
                resolved.append(code)
            issues.pop(code, None)

    tracker['issues'] = issues
    tracker['last_updated_epoch'] = now_epoch
    _save_json_dict(tracker_path, tracker)
    return {
        'tracker_path': tracker_path,
        'escalated_codes': sorted(set(escalated_codes)),
        'resolved_codes': sorted(set(resolved)),
    }


def _maybe_send_cloud_health_failure_report(lab_root, diagnostics, tracker_info):
    """Send deduplicated support bundle for fail or sustained warn diagnostics."""
    if collect_support_bundle is None or submit_support_bundle_email is None:
        return False
    # TODO(agent-followup): If lab_root is empty/invalid, skip persistence and surface an
    # explicit diagnostic for this pathing condition instead of falling back to cwd ('.').
    # That hardening would prevent accidental artifact writes outside expected lab scope.
    escalated_codes = tracker_info.get('escalated_codes', []) if isinstance(tracker_info, dict) else []
    if not escalated_codes:
        return False
    issues = diagnostics.get('issues', []) if isinstance(diagnostics, dict) else []
    issue_key = '|'.join(['{0}:{1}'.format(i.get('code', ''), i.get('message', '')) for i in issues if i.get('code') in escalated_codes])
    if not issue_key:
        return False

    alert_state_path = os.path.join(lab_root or '.', _HEALTH_ALERT_STATE_FILENAME)
    now_epoch = int(time.time())
    alert_state = _load_json_dict(alert_state_path)
    last_key = alert_state.get('last_issue_key')
    last_epoch = int(alert_state.get('last_sent_epoch', 0) or 0)
    if last_key == issue_key and (now_epoch - last_epoch) < _ALERT_DEDUP_WINDOW_SEC:
        return False

    try:
        extra_files = [('cloud_health_diagnostics.json', diagnostics)]
        for name in (_HEALTH_TRACKER_FILENAME, 'diagnostics_state.json', 'run_cursor.json'):
            p = os.path.join(lab_root, name)
            if os.path.isfile(p):
                extra_files.append((name, p))
        zip_path = collect_support_bundle(
            include_traceback=False,
            extra_meta={
                'cloud_health_failure': True,
                'escalated_codes': escalated_codes,
                'lab_root': lab_root,
            },
            extra_files=extra_files,
        )
        if not zip_path:
            return False
        submit_support_bundle_email(zip_path=zip_path, include_traceback=False, skip_interactive_reauth=True)
        _save_json_dict(alert_state_path, {'last_issue_key': issue_key, 'last_sent_epoch': now_epoch})
        return True
    except Exception as e:
        _log_health('ERROR', 'Cloud health report send failed: {0}'.format(e))
        return False


def resolve_lab_root(repo_root):
    """Resolve lab root: MEDICAFE_LAB_DIR > repo_root/lab."""
    env_lab = os.environ.get('MEDICAFE_LAB_DIR', '').strip()
    if env_lab:
        # Accept quoted values from .bat/.ini wrappers and expand shell vars.
        if len(env_lab) >= 2 and env_lab[0] == env_lab[-1] and env_lab[0] in ('"', "'"):
            env_lab = env_lab[1:-1]
        env_lab = os.path.expandvars(os.path.expanduser(env_lab))
        # Auto-heal malformed Windows bootstrap values like:
        #   "C: C:\\Python34\\Lib\\site-packages\\lab"
        # Keep only the real absolute drive path fragment.
        malformed_prefix = re.match(r'^([A-Za-z]:)\s+([A-Za-z]:[\\/].+)$', env_lab)
        if malformed_prefix:
            env_lab = malformed_prefix.group(2)

        # If a Windows absolute drive path is provided, do not run posix abspath
        # on it (would incorrectly prefix cwd when tests run on non-Windows hosts).
        if re.match(r'^[A-Za-z]:[\\/]', env_lab):
            return os.path.normpath(env_lab)

        # Re-check after unquoting/expansion: empty value must fall back to repo_root/lab
        # (os.path.abspath('') resolves to cwd, which would mask bad config and corrupt placement)
        if env_lab and env_lab.strip():
            return os.path.abspath(env_lab)
    return os.path.join(repo_root, 'lab')


def _describe_lab_root_issue(lab_root):
    """Return a richer LAB_ROOT_NOT_FOUND explanation to speed operator triage."""
    parts = ['Lab root does not exist: {0}'.format(lab_root)]
    env_raw = os.environ.get('MEDICAFE_LAB_DIR', '')
    if env_raw:
        parts.append('MEDICAFE_LAB_DIR(raw)={0!r}'.format(env_raw))
    try:
        normalized = os.path.abspath(os.path.expandvars(os.path.expanduser(str(lab_root))))
        if normalized != lab_root:
            parts.append('normalized={0}'.format(normalized))
    except Exception:
        pass
    try:
        parent = os.path.dirname(lab_root)
        if parent:
            parts.append('parent_exists={0}'.format(os.path.isdir(parent)))
            parts.append('parent_writable={0}'.format(os.access(parent, os.W_OK)))
    except Exception:
        pass
    return ' | '.join(parts)


def _lab_has_core_artifacts(lab_root):
    """True if lab has db and cursor (bootstrap completed successfully)."""
    if not lab_root:
        return False
    db = os.path.join(lab_root, 'unified_model_xp.db')
    cursor = os.path.join(lab_root, 'run_cursor.json')
    return os.path.isfile(db) and os.path.isfile(cursor)


def _write_bootstrap_diag(repo_root, lab_root, reason, extra=None):
    """Best-effort write of opportunistic bootstrap diagnostics for in-situ triage."""
    try:
        fallback_lab = os.path.join(repo_root, 'lab')
        base_lab = lab_root if lab_root and str(lab_root).strip() else fallback_lab
        reports_dir = os.path.join(base_lab, 'reports')
        if not os.path.isdir(reports_dir):
            os.makedirs(reports_dir)
        stamp = time.strftime('%Y%m%dT%H%M%SZ', time.gmtime())
        unique = '{0}-{1}-{2}'.format(stamp, os.getpid(), int((time.time() % 1) * 1000))
        path = os.path.join(reports_dir, 'bootstrap_autofix_diag_{0}.json'.format(unique))
        payload = {
            'reason': reason,
            'lab_root': lab_root,
            'repo_root': repo_root,
            'medicafe_lab_dir_raw': os.environ.get('MEDICAFE_LAB_DIR', ''),
            'timestamp_utc': stamp,
        }
        if isinstance(extra, dict):
            payload.update(extra)
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return path
    except Exception:
        return None


def _probe_lab_root(path):
    """Collect lightweight filesystem/pipeline facts for bootstrap diagnostics."""
    probe = {
        'path': path,
        'exists': False,
        'is_dir': False,
        'parent': None,
        'parent_exists': False,
        'parent_writable': False,
        'has_core_artifacts': False,
        'pipeline_running': False,
    }
    try:
        if not path:
            return probe
        probe['exists'] = os.path.exists(path)
        probe['is_dir'] = os.path.isdir(path)
        parent = os.path.dirname(path)
        probe['parent'] = parent
        if parent:
            probe['parent_exists'] = os.path.isdir(parent)
            probe['parent_writable'] = os.access(parent, os.W_OK)
        if probe['is_dir']:
            probe['has_core_artifacts'] = _lab_has_core_artifacts(path)
        probe['pipeline_running'] = is_pipeline_running(path)
    except Exception:
        pass
    return probe


def _bootstrap_fail_message(code, message, diag_path=None):
    """Standardized bootstrap failure message with code and optional diag path."""
    msg = '{0}: {1}'.format(code, message)
    if diag_path:
        msg = '{0} (diagnostics: {1})'.format(msg, diag_path)
    return msg


def ensure_lab_ready(repo_root, python_exe, env, env_flag_fn):
    """
    Gate before Cloud Readiness UI: ensure lab exists or run Phase A bootstrap.
    Returns (ok, message, None). Avoids concurrent Phase A (lock rejection) by
    checking pipeline running and respecting MEDICAFE_PHASE_A_AUTO_VALIDATE.
    """
    lab_root = resolve_lab_root(repo_root)
    if not lab_root or not str(lab_root).strip():
        diag_path = _write_bootstrap_diag(repo_root, lab_root, 'LAB_ROOT_EMPTY', {
            'flow_stage': 'resolve_lab_root',
        })
        return (False, _bootstrap_fail_message('LAB_ROOT_EMPTY', 'Lab root could not be resolved', diag_path), None)

    candidate_roots = [lab_root]
    default_lab = os.path.join(repo_root, 'lab')
    if default_lab not in candidate_roots:
        candidate_roots.append(default_lab)

    selected_root = None
    selected_from_fallback = False
    candidate_probes = []
    for idx, candidate in enumerate(candidate_roots):
        probe = _probe_lab_root(candidate)
        candidate_probes.append(probe)
        if probe.get('is_dir') and probe.get('has_core_artifacts'):
            return (True, '', None)
        if probe.get('pipeline_running'):
            return (True, 'Initialization in progress.', None)
        if probe.get('is_dir'):
            selected_root = candidate
            selected_from_fallback = (idx > 0)
            break

    if selected_root is None:
        selected_root = lab_root

    auto_validate_enabled = env_flag_fn('MEDICAFE_PHASE_A_AUTO_VALIDATE', True)
    if not auto_validate_enabled:
        return (True, 'Phase A auto disabled.', None)

    bootstrap_script = os.path.join(repo_root, 'scripts', 'unified_model', 'bootstrap_lab.py')
    if not os.path.exists(bootstrap_script):
        diag_path = _write_bootstrap_diag(repo_root, selected_root, 'BOOTSTRAP_SCRIPT_MISSING', {
            'flow_stage': 'bootstrap_script_check',
            'bootstrap_script': bootstrap_script,
            'candidate_roots': candidate_roots,
            'candidate_probes': candidate_probes,
            'selected_root': selected_root,
            'selected_from_fallback': selected_from_fallback,
            'auto_validate_enabled': auto_validate_enabled,
            'python_exe': python_exe,
        })
        return (False, _bootstrap_fail_message('BOOTSTRAP_SCRIPT_MISSING', 'bootstrap_lab.py not found', diag_path), None)
    try:
        proc_env = os.environ.copy()
        proc_env['MEDICAFE_LAB_DIR'] = selected_root
        proc_env['target_folder'] = env.get('target_folder', '')
        proc_env['source_folder'] = env.get('source_folder', '')
        rc = subprocess.call([python_exe, bootstrap_script], cwd=repo_root, env=proc_env)
        if rc != 0:
            if _lab_has_core_artifacts(selected_root) or is_pipeline_running(selected_root):
                return (True, '', None)
            diag_path = _write_bootstrap_diag(repo_root, selected_root, 'BOOTSTRAP_NONZERO_EXIT', {
                'flow_stage': 'bootstrap_execute',
                'exit_code': rc,
                'bootstrap_script': bootstrap_script,
                'candidate_roots': candidate_roots,
                'candidate_probes': candidate_probes,
                'selected_root': selected_root,
                'selected_from_fallback': selected_from_fallback,
                'auto_validate_enabled': auto_validate_enabled,
                'python_exe': python_exe,
                'target_folder': env.get('target_folder', ''),
                'source_folder': env.get('source_folder', ''),
            })
            return (False, _bootstrap_fail_message('BOOTSTRAP_NONZERO_EXIT', 'Phase A bootstrap exited with code {0}'.format(rc), diag_path), None)
        return (True, '', None)
    except Exception as e:
        if _lab_has_core_artifacts(selected_root) or is_pipeline_running(selected_root):
            return (True, '', None)
        diag_path = _write_bootstrap_diag(repo_root, selected_root, 'BOOTSTRAP_EXCEPTION', {
            'flow_stage': 'bootstrap_execute',
            'exception': str(e),
            'bootstrap_script': bootstrap_script,
            'candidate_roots': candidate_roots,
            'candidate_probes': candidate_probes,
            'selected_root': selected_root,
            'selected_from_fallback': selected_from_fallback,
            'auto_validate_enabled': auto_validate_enabled,
            'python_exe': python_exe,
            'target_folder': env.get('target_folder', ''),
            'source_folder': env.get('source_folder', ''),
        })
        return (False, _bootstrap_fail_message('BOOTSTRAP_EXCEPTION', str(e), diag_path), None)


def is_pipeline_running(lab_root):
    """Check if shadow pipeline is running. Returns bool. Exception-safe."""
    try:
        from MediCafe.cloud_readiness_health import is_pipeline_running as _health_check
        return _health_check(lab_root)
    except Exception:
        return False


def check_pipeline_running_for_action(repo_root, action_name):
    """Returns (is_running, warning_msg). warning_msg set when is_running."""
    lab_root = resolve_lab_root(repo_root)
    running = is_pipeline_running(lab_root)
    msg = 'Note: Pipeline is running. {0} may reflect stale data.'.format(action_name) if running else None
    return (running, msg)


def run_pipeline(repo_root, python_exe, env, env_flag_fn):
    """
    When shadow_auto=1: spawn run_shadow_pipeline.py (non-blocking).
    When shadow_auto=0: Phase A blocks (subprocess.call), then B/C/D spawn via Popen.
    Env from os.environ.copy() + overlay MEDICAFE_LAB_DIR, target_folder, source_folder.
    """
    try:
        lab_root = resolve_lab_root(repo_root)
        proc_env = os.environ.copy()
        proc_env['MEDICAFE_LAB_DIR'] = lab_root
        proc_env['target_folder'] = env.get('target_folder', '')
        proc_env['source_folder'] = env.get('source_folder', '')

        if env_flag_fn('MEDICAFE_SHADOW_AUTO_PIPELINE', True):
            pipeline_script = os.path.join(repo_root, 'scripts', 'unified_model', 'run_shadow_pipeline.py')
            if not os.path.exists(pipeline_script):
                return (True, '', None)
            subprocess.Popen(
                [python_exe, pipeline_script],
                cwd=repo_root,
                env=proc_env,
                stdout=DEVNULL,
                stderr=DEVNULL,
            )
            return (True, '', None)
        else:
            # Phase A blocking
            if env_flag_fn('MEDICAFE_PHASE_A_AUTO_VALIDATE', True):
                bootstrap_script = os.path.join(repo_root, 'scripts', 'unified_model', 'bootstrap_lab.py')
                if os.path.exists(bootstrap_script):
                    rc = subprocess.call([python_exe, bootstrap_script], cwd=repo_root, env=proc_env)
                    if rc != 0:
                        return (False, 'Phase A bootstrap exited with code {0}'.format(rc), None)
            # Phase B/C/D non-blocking
            if env_flag_fn('MEDICAFE_PHASE_B_AUTO_DISCOVER', False):
                discover_script = os.path.join(repo_root, 'scripts', 'unified_model', 'discover_artifacts.py')
                if os.path.exists(discover_script):
                    try:
                        subprocess.Popen(
                            [python_exe, discover_script],
                            cwd=repo_root,
                            env=proc_env,
                            stdout=DEVNULL,
                            stderr=DEVNULL,
                        )
                    except Exception:
                        pass
            if env_flag_fn('MEDICAFE_PHASE_C_AUTO_INGEST', False):
                ingest_script = os.path.join(repo_root, 'scripts', 'unified_model', 'ingest_from_manifest.py')
                if os.path.exists(ingest_script):
                    try:
                        subprocess.Popen(
                            [python_exe, ingest_script],
                            cwd=repo_root,
                            env=proc_env,
                            stdout=DEVNULL,
                            stderr=DEVNULL,
                        )
                    except Exception:
                        pass
            if env_flag_fn('MEDICAFE_PHASE_D_AUTO_QA', False):
                qa_script = os.path.join(repo_root, 'scripts', 'unified_model', 'run_qa_canonical.py')
                if os.path.exists(qa_script):
                    try:
                        subprocess.Popen(
                            [python_exe, qa_script],
                            cwd=repo_root,
                            env=proc_env,
                            stdout=DEVNULL,
                            stderr=DEVNULL,
                        )
                    except Exception:
                        pass
            return (True, '', None)
    except Exception as e:
        return (False, str(e), None)


def _find_latest_run_id_by_prefix(reports_dir, prefix, suffix_choices):
    """
    Find latest file by prefix (mtime). Parse run_id from filename.
    Returns (run_id, path) or (None, None).
    Filename pattern: {prefix}{run_id}.{ext}
    """
    if not reports_dir or not os.path.exists(reports_dir):
        return (None, None)
    try:
        items = os.listdir(reports_dir)
    except (IOError, OSError):
        return (None, None)
    candidates = []
    prefix_len = len(prefix)
    for item in items:
        if not item.startswith(prefix):
            continue
        for suf in suffix_choices:
            if item.endswith(suf):
                path = os.path.join(reports_dir, item)
                if os.path.isfile(path):
                    rest = item[prefix_len:]
                    if '.' in rest:
                        run_id = rest.rsplit('.', 1)[0]
                    else:
                        run_id = rest
                    if run_id and len(run_id) >= 17 and '-' in run_id:
                        candidates.append((run_id, path))
                break
    if not candidates:
        return (None, None)
    try:
        return max(candidates, key=lambda x: os.path.getmtime(x[1]))
    except (IOError, OSError, ValueError):
        return (None, None)


def _reports_dir_access_error(lab_root):
    """Return readable error string when reports dir exists but is unreadable; else None."""
    reports_dir = os.path.join(lab_root, 'reports')
    if not reports_dir or not os.path.exists(reports_dir):
        return None
    try:
        os.listdir(reports_dir)
    except (IOError, OSError) as e:
        return 'Unable to read reports directory: {0}'.format(e)
    return None


def _select_latest_evidence_files(lab_root, prefix_specs):
    """
    Select latest coherent run's evidence files per prefix_specs.
    prefix_specs: [(prefix, suffix), ...] where suffix is None for (.txt, .json) or e.g. '.jsonl'.
    Returns [(basename, fullpath), ...].
    """
    reports_dir = os.path.join(lab_root, 'reports')
    if not reports_dir or not os.path.exists(reports_dir):
        return []
    if not prefix_specs:
        return []
    primary_prefix, primary_suffix = prefix_specs[0]
    suffix_choices = ('.txt', '.json') if primary_suffix is None else (primary_suffix,)
    run_id, _ = _find_latest_run_id_by_prefix(reports_dir, primary_prefix, suffix_choices)
    if not run_id:
        return []
    extra_files = []
    seen = set()
    for prefix, suffix in prefix_specs:
        if suffix is None:
            for ext in ('.json', '.txt'):
                basename = prefix + run_id + ext
                path = os.path.join(reports_dir, basename)
                if os.path.isfile(path) and basename not in seen:
                    extra_files.append((basename, path))
                    seen.add(basename)
        else:
            basename = prefix + run_id + suffix
            path = os.path.join(reports_dir, basename)
            if os.path.isfile(path) and basename not in seen:
                extra_files.append((basename, path))
                seen.add(basename)
    return extra_files


def _find_latest_by_prefix(reports_dir, prefix, suffix_choices):
    """Find latest file by prefix. Returns (path, None) or (None, message)."""
    if not reports_dir or not os.path.exists(reports_dir):
        return (None, 'No reports directory: {0}'.format(reports_dir))
    try:
        items = os.listdir(reports_dir)
    except (IOError, OSError) as e:
        return (None, 'Unable to read reports directory: {0}'.format(e))
    candidates = []
    for item in items:
        if item.startswith(prefix):
            for suf in suffix_choices:
                if item.endswith(suf):
                    path = os.path.join(reports_dir, item)
                    if os.path.isfile(path):
                        candidates.append(path)
                    break
    if not candidates:
        return (None, None)
    try:
        return (max(candidates, key=os.path.getmtime), None)
    except (IOError, OSError, ValueError):
        return (None, 'Unable to resolve latest report file.')


def open_phase_b_summary(repo_root):
    lab_root = resolve_lab_root(repo_root)
    reports_dir = os.path.join(lab_root, 'reports')
    path, msg = _find_latest_by_prefix(reports_dir, 'artifact_discovery_summary_', ('.txt', '.json'))
    if path:
        return (True, '', path)
    if msg:
        return (False, msg, None)
    return (False, 'No artifact discovery summaries found.', None)


def open_manifest_location(repo_root):
    """Return manifest file path for explorer /select. Launcher opens explorer, not viewer."""
    lab_root = resolve_lab_root(repo_root)
    cursor_path = os.path.join(lab_root, 'run_cursor.json')
    manifest_path = None
    if os.path.exists(cursor_path):
        try:
            with open(cursor_path, 'r', encoding='utf-8') as f:
                cursor = json.load(f)
            manifest_path = cursor.get('last_manifest_path')
        except (IOError, OSError, ValueError):
            pass
    if not manifest_path or not os.path.exists(manifest_path):
        reports_dir = os.path.join(lab_root, 'reports')
        if os.path.exists(reports_dir):
            try:
                report_items = os.listdir(reports_dir)
            except (IOError, OSError) as e:
                return (False, 'Unable to read reports directory: {0}'.format(e), None)
            manifests = [
                os.path.join(reports_dir, x) for x in report_items
                if x.startswith('artifact_manifest_') and x.endswith('.jsonl')
                and os.path.isfile(os.path.join(reports_dir, x))
            ]
            if manifests:
                try:
                    manifest_path = max(manifests, key=os.path.getmtime)
                except (IOError, OSError, ValueError):
                    return (False, 'Unable to resolve latest manifest file.', None)
    if manifest_path and os.path.exists(manifest_path):
        return (True, '', manifest_path)
    return (False, 'No manifest found. Run discovery from Cloud Readiness first.', None)


def run_phase_b_manual(repo_root, python_exe, env):
    script = os.path.join(repo_root, 'scripts', 'unified_model', 'discover_artifacts.py')
    if not os.path.exists(script):
        return (False, 'discover_artifacts.py not found.', None)
    try:
        lab_root = resolve_lab_root(repo_root)
        proc_env = os.environ.copy()
        proc_env['MEDICAFE_LAB_DIR'] = lab_root
        proc_env['target_folder'] = env.get('target_folder', '')
        proc_env['source_folder'] = env.get('source_folder', '')
        subprocess.Popen([python_exe, script], cwd=repo_root, env=proc_env)
        return (True, '', None)
    except Exception as e:
        return (False, str(e), None)


def _send_phase_evidence(lab_root, prefix_specs, extra_meta_key, no_attach_msg):
    """
    Send latest coherent run's evidence. prefix_specs: [(prefix, suffix), ...].
    Requires at least one phase artifact; context files are additive only.
    """
    if collect_support_bundle is None or submit_support_bundle_email is None:
        return (False, 'Support bundle tools unavailable.', None)
    reports_err = _reports_dir_access_error(lab_root)
    if reports_err:
        return (False, reports_err, None)
    phase_files = _select_latest_evidence_files(lab_root, prefix_specs)
    if not phase_files:
        return (False, no_attach_msg, None)
    extra_files = list(phase_files)
    for ctx_name in ('diagnostics_state.json', 'run_cursor.json'):
        ctx_path = os.path.join(lab_root, ctx_name)
        if os.path.isfile(ctx_path):
            extra_files.append((ctx_name, ctx_path))
    try:
        zip_path = collect_support_bundle(
            include_traceback=False,
            extra_meta={extra_meta_key: True, 'lab_root': lab_root},
            extra_files=extra_files,
        )
        if not zip_path:
            return (False, 'Failed to create support bundle.', None)
        ok = submit_support_bundle_email(zip_path, skip_interactive_reauth=True)
        return (ok, 'Report sent.' if ok else 'Report queued or failed.', None)
    except Exception as e:
        return (False, 'Error: {0}'.format(e), None)


def send_phase_b_evidence(repo_root):
    lab_root = resolve_lab_root(repo_root)
    return _send_phase_evidence(
        lab_root,
        [('artifact_discovery_summary_', None)],
        'phase_b_evidence',
        'No discovery summaries to attach.',
    )


def open_phase_c_summary(repo_root):
    lab_root = resolve_lab_root(repo_root)
    reports_dir = os.path.join(lab_root, 'reports')
    path, msg = _find_latest_by_prefix(reports_dir, 'ingest_write_summary_', ('.txt', '.json'))
    if path:
        return (True, '', path)
    if msg:
        return (False, msg, None)
    return (False, 'No Phase C ingest summaries found.', None)


def run_phase_c_manual(repo_root, python_exe, env):
    script = os.path.join(repo_root, 'scripts', 'unified_model', 'ingest_from_manifest.py')
    if not os.path.exists(script):
        return (False, 'ingest_from_manifest.py not found.', None)
    try:
        lab_root = resolve_lab_root(repo_root)
        proc_env = os.environ.copy()
        proc_env['MEDICAFE_LAB_DIR'] = lab_root
        subprocess.Popen([python_exe, script], cwd=repo_root, env=proc_env)
        return (True, '', None)
    except Exception as e:
        return (False, str(e), None)


def send_phase_c_evidence(repo_root):
    lab_root = resolve_lab_root(repo_root)
    return _send_phase_evidence(
        lab_root,
        [('ingest_write_summary_', None), ('ingest_write_anomalies_', '.jsonl')],
        'phase_c_evidence',
        'No Phase C summaries or anomalies to attach.',
    )


def open_phase_d_summary(repo_root):
    lab_root = resolve_lab_root(repo_root)
    reports_dir = os.path.join(lab_root, 'reports')
    path, msg = _find_latest_by_prefix(reports_dir, 'qa_canonical_summary_', ('.txt', '.json'))
    if path:
        return (True, '', path)
    if msg:
        return (False, msg, None)
    return (False, 'No Phase D summaries found.', None)


def open_phase_d_reject_sample(repo_root):
    lab_root = resolve_lab_root(repo_root)
    reports_dir = os.path.join(lab_root, 'reports')
    path, msg = _find_latest_by_prefix(reports_dir, 'qa_reject_samples_', ('.jsonl',))
    if path:
        return (True, '', path)
    if msg:
        return (False, msg, None)
    return (False, 'No Phase D reject sample files found.', None)


def run_phase_d_manual(repo_root, python_exe, env):
    script = os.path.join(repo_root, 'scripts', 'unified_model', 'run_qa_canonical.py')
    if not os.path.exists(script):
        return (False, 'run_qa_canonical.py not found.', None)
    try:
        lab_root = resolve_lab_root(repo_root)
        proc_env = os.environ.copy()
        proc_env['MEDICAFE_LAB_DIR'] = lab_root
        subprocess.Popen([python_exe, script], cwd=repo_root, env=proc_env)
        return (True, '', None)
    except Exception as e:
        return (False, str(e), None)


def send_phase_d_evidence(repo_root):
    lab_root = resolve_lab_root(repo_root)
    return _send_phase_evidence(
        lab_root,
        [('qa_canonical_summary_', None), ('qa_reject_samples_', '.jsonl')],
        'phase_d_evidence',
        'No Phase D summaries or reject samples to attach.',
    )


def open_phase_e_summary(repo_root):
    lab_root = resolve_lab_root(repo_root)
    reports_dir = os.path.join(lab_root, 'reports')
    path, msg = _find_latest_by_prefix(reports_dir, 'projection_parity_summary_', ('.txt', '.json'))
    if path:
        return (True, '', path)
    if msg:
        return (False, msg, None)
    return (False, 'No Phase E summaries found.', None)


def open_phase_e_deviation_samples(repo_root):
    lab_root = resolve_lab_root(repo_root)
    reports_dir = os.path.join(lab_root, 'reports')
    path, msg = _find_latest_by_prefix(reports_dir, 'projection_deviation_samples_', ('.jsonl',))
    if path:
        return (True, '', path)
    if msg:
        return (False, msg, None)
    return (False, 'No Phase E deviation sample files found.', None)


def run_phase_e_manual(repo_root, python_exe, env):
    script = os.path.join(repo_root, 'scripts', 'unified_model', 'run_projection_parity.py')
    if not os.path.exists(script):
        return (False, 'run_projection_parity.py not found.', None)
    try:
        lab_root = resolve_lab_root(repo_root)
        proc_env = os.environ.copy()
        proc_env['MEDICAFE_LAB_DIR'] = lab_root
        subprocess.Popen([python_exe, script], cwd=repo_root, env=proc_env)
        return (True, '', None)
    except Exception as e:
        return (False, str(e), None)


def send_phase_e_evidence(repo_root):
    lab_root = resolve_lab_root(repo_root)
    return _send_phase_evidence(
        lab_root,
        [('projection_parity_summary_', None), ('projection_deviation_samples_', '.jsonl')],
        'phase_e_evidence',
        'No Phase E summaries or deviation samples to attach.',
    )


def run_shadow_pipeline(repo_root, python_exe, env):
    script = os.path.join(repo_root, 'scripts', 'unified_model', 'run_shadow_pipeline.py')
    if not os.path.exists(script):
        return (True, '', None)
    try:
        lab_root = resolve_lab_root(repo_root)
        proc_env = os.environ.copy()
        proc_env['MEDICAFE_LAB_DIR'] = lab_root
        proc_env['target_folder'] = env.get('target_folder', '')
        proc_env['source_folder'] = env.get('source_folder', '')
        subprocess.Popen(
            [python_exe, script],
            cwd=repo_root,
            env=proc_env,
            stdout=DEVNULL,
            stderr=DEVNULL,
        )
        return (True, '', None)
    except Exception as e:
        return (False, str(e), None)


def open_phase_f_shadow_report(repo_root):
    lab_root = resolve_lab_root(repo_root)
    reports_dir = os.path.join(lab_root, 'reports')
    path, msg = _find_latest_by_prefix(reports_dir, 'shadow_run_report_', ('.txt', '.json'))
    if path:
        return (True, '', path)
    if msg:
        return (False, msg, None)
    return (False, 'No Shadow Health reports found yet.', None)


def open_phase_f_evidence_index(repo_root):
    lab_root = resolve_lab_root(repo_root)
    reports_dir = os.path.join(lab_root, 'reports')
    path, msg = _find_latest_by_prefix(reports_dir, 'shadow_evidence_index_', ('.json',))
    if path:
        return (True, '', path)
    if msg:
        return (False, msg, None)
    return (False, 'No Phase F evidence indexes found.', None)


def run_phase_f_manual(repo_root, python_exe, env, pipeline_running=None):
    """
    Rebuild Phase F (latest-at-execution). Does not pass --pipeline-run-id.
    Returns (ok, msg, pipeline_running).
    """
    script = os.path.join(repo_root, 'scripts', 'unified_model', 'package_shadow_run_report.py')
    if not os.path.exists(script):
        return (False, 'package_shadow_run_report.py not found.', None)
    try:
        lab_root = resolve_lab_root(repo_root)
        if pipeline_running is None:
            pipeline_running = is_pipeline_running(lab_root)
        proc_env = os.environ.copy()
        proc_env['MEDICAFE_LAB_DIR'] = lab_root
        cmd = [python_exe, script, '--auto-report', '0']
        subprocess.Popen(cmd, cwd=repo_root, env=proc_env, stdout=DEVNULL)
        return (True, '', pipeline_running)
    except Exception as e:
        return (False, str(e), None)


def run_phase_f_manual_for_run_id(repo_root, python_exe, env, run_id):
    """
    Rebuild Phase F for explicit run_id (strict). Always passes --pipeline-run-id.
    Does NOT read state. Returns (ok, msg, None).
    """
    script = os.path.join(repo_root, 'scripts', 'unified_model', 'package_shadow_run_report.py')
    if not os.path.exists(script):
        return (False, 'package_shadow_run_report.py not found.', None)
    run_id = (run_id or '').strip()
    if not run_id:
        return (False, 'run_id is required.', None)
    try:
        lab_root = resolve_lab_root(repo_root)
        proc_env = os.environ.copy()
        proc_env['MEDICAFE_LAB_DIR'] = lab_root
        cmd = [python_exe, script, '--pipeline-run-id', run_id, '--auto-report', '0']
        subprocess.Popen(cmd, cwd=repo_root, env=proc_env, stdout=DEVNULL)
        return (True, '', None)
    except Exception as e:
        return (False, str(e), None)


def send_phase_f_evidence(repo_root):
    lab_root = resolve_lab_root(repo_root)
    no_attach_msg = 'No Shadow Health report/evidence files found to attach.'
    if collect_support_bundle is None or submit_support_bundle_email is None:
        return (False, 'Support bundle tools unavailable.', None)
    reports_err = _reports_dir_access_error(lab_root)
    if reports_err:
        return (False, reports_err, None)
    phase_files = _select_latest_evidence_files(lab_root, [
        ('shadow_run_report_', None),
        ('shadow_evidence_index_', '.json'),
        ('phase_f_mismatch_', '.txt'),
    ])
    if not phase_files:
        reports_dir = os.path.join(lab_root, 'reports')
        mismatch_path, _ = _find_latest_by_prefix(reports_dir, 'phase_f_mismatch_', ('.txt',))
        if mismatch_path:
            basename = os.path.basename(mismatch_path)
            phase_files = [(basename, mismatch_path)]
    if not phase_files:
        return (False, no_attach_msg, None)
    extra_files = list(phase_files)
    for ctx_name in ('diagnostics_state.json', 'run_cursor.json'):
        ctx_path = os.path.join(lab_root, ctx_name)
        if os.path.isfile(ctx_path):
            extra_files.append((ctx_name, ctx_path))
    try:
        zip_path = collect_support_bundle(
            include_traceback=False,
            extra_meta={'phase_f_evidence': True, 'lab_root': lab_root},
            extra_files=extra_files,
        )
        if not zip_path:
            return (False, 'Failed to create support bundle.', None)
        ok = submit_support_bundle_email(zip_path, skip_interactive_reauth=True)
        return (ok, 'Report sent.' if ok else 'Report queued or failed.', None)
    except Exception as e:
        return (False, 'Error: {0}'.format(e), None)


def open_consolidated_health_report(repo_root, env_flag_fn):
    """
    Generate and return path to consolidated health report (all phases B-F).
    Writes Pipeline Health Snapshot to lab/reports/consolidated_health_snapshot.txt,
    appending latest shadow_run_report content if available.
    Returns (ok, message, path).
    """
    lab_root = resolve_lab_root(repo_root)
    lines = get_health_lines(lab_root, env_flag_fn)
    reports_dir = os.path.join(lab_root, 'reports')
    try:
        if reports_dir and not os.path.exists(reports_dir):
            os.makedirs(reports_dir, exist_ok=True)
        path = os.path.join(reports_dir, 'consolidated_health_snapshot.txt')
        content = '\n'.join(lines) + '\n'
        # Append latest shadow_run_report for full phase details
        shadow_path, _ = _find_latest_by_prefix(
            reports_dir, 'shadow_run_report_', ('.txt', '.json'))
        if shadow_path and shadow_path.endswith('.txt'):
            try:
                with open(shadow_path, 'r', encoding='utf-8') as f:
                    shadow_content = f.read()
                content += '\n--- Phase F detailed report ---\n'
                content += shadow_content
            except (IOError, OSError):
                pass
        with open(path, 'w', encoding='utf-8') as f:
            f.write(content)
        return (True, '', path)
    except Exception as e:
        return (False, str(e), None)


def _has_invalid_lab_root(diagnostics):
    """True if diagnostics indicate lab root is missing or not found (read-only path)."""
    codes = {str(i.get('code', '') or '').strip() for i in diagnostics.get('issues', [])}
    return bool(codes & {'LAB_ROOT_MISSING', 'LAB_ROOT_NOT_FOUND'})


def get_health_lines(lab_root, env_flag_fn):
    """Return list of health lines. Uses build_cloud_health_lines or diagnostics_state fallback."""
    diagnostics = _collect_health_diagnostics(lab_root, auto_resolve=True)
    # TODO(agent-followup): Add lightweight log-throttling keyed by diagnostic signature so
    # repeated menu refreshes do not spam identical WARNING/ERROR lines in operator logs.
    if _has_invalid_lab_root(diagnostics):
        tracker_info = {'escalated_codes': [], 'resolved_codes': []}
    else:
        tracker_info = _update_health_issue_tracker(lab_root, diagnostics)

    for issue in diagnostics.get('issues', []):
        level = 'ERROR' if str(issue.get('severity', '')).lower() == 'fail' else 'WARNING'
        _log_health(level, 'Cloud readiness diagnostics [{0}] count-tracked: {1}'.format(
            issue.get('code', 'UNKNOWN_ISSUE'), issue.get('message', '')))
    for resolved_code in tracker_info.get('resolved_codes', []):
        _log_health('INFO', 'Cloud readiness diagnostics resolved: {0}'.format(resolved_code))
    for fix in diagnostics.get('auto_resolved', []):
        _log_health('INFO', 'Cloud readiness auto-resolve: {0}'.format(fix))

    if tracker_info.get('escalated_codes'):
        _log_health('WARNING', 'Cloud readiness escalation triggered for: {0}'.format(
            ', '.join(tracker_info.get('escalated_codes', []))))
        if _maybe_send_cloud_health_failure_report(lab_root, diagnostics, tracker_info):
            _log_health('WARNING', 'Cloud readiness escalation report submitted (or queued).')

    diagnostics_lines = []
    if diagnostics.get('issues'):
        diagnostics_lines.append('-' * 80)
        diagnostics_lines.append('Diagnostics Summary:')
        for issue in diagnostics.get('issues', []):
            diagnostics_lines.append(' - [{0}] {1}: {2}'.format(
                str(issue.get('severity', 'warn')).upper(),
                issue.get('code', 'UNKNOWN_ISSUE'),
                issue.get('message', ''),
            ))
    if diagnostics.get('auto_resolved'):
        diagnostics_lines.append('Auto-resolved:')
        for fix in diagnostics.get('auto_resolved', []):
            diagnostics_lines.append(' - {0}'.format(fix))
    if tracker_info.get('escalated_codes'):
        diagnostics_lines.append('Escalated diagnostics: {0}'.format(', '.join(tracker_info.get('escalated_codes', []))))

    if build_cloud_health_lines:
        try:
            lines = build_cloud_health_lines(
                lab_root,
                auto_pipeline=env_flag_fn('MEDICAFE_SHADOW_AUTO_PIPELINE', True),
                auto_health=env_flag_fn('MEDICAFE_SHADOW_SEND_HEALTH', True),
            )
            if diagnostics_lines:
                lines.extend(diagnostics_lines)
            return lines
        except Exception as e:
            _log_health('ERROR', 'build_cloud_health_lines failed; using fallback: {0}'.format(e))
    state_path = os.path.join(lab_root, 'diagnostics_state.json')
    if not os.path.exists(state_path):
        auto_pipeline = env_flag_fn('MEDICAFE_SHADOW_AUTO_PIPELINE', True)
        auto_health = env_flag_fn('MEDICAFE_SHADOW_SEND_HEALTH', True)
        lines = [
            'No diagnostics state found yet: {0}'.format(state_path),
            'Automation: pipeline_auto={0}, health_telemetry_auto={1}'.format(
                auto_pipeline, auto_health),
        ]
        if diagnostics_lines:
            lines.extend(diagnostics_lines)
        return lines
    try:
        with open(state_path, 'r', encoding='utf-8') as f:
            state = json.load(f)
        rid = state.get('last_shadow_pipeline_run_id', '')
        ok = state.get('last_shadow_pipeline_ok', False)
        failed = state.get('last_shadow_pipeline_failed_phase', '')
        parity = state.get('last_contract_parity_status', '')
        auto_pipeline = env_flag_fn('MEDICAFE_SHADOW_AUTO_PIPELINE', True)
        auto_health = env_flag_fn('MEDICAFE_SHADOW_SEND_HEALTH', True)
        lines = [
            'Last run: {0}, ok={1}, failed_phase={2}, parity={3}'.format(
                rid or '(none)', ok, failed or '-', parity or '-'),
            'Automation: pipeline_auto={0}, health_telemetry_auto={1}'.format(
                auto_pipeline, auto_health),
        ]
        if diagnostics_lines:
            lines.extend(diagnostics_lines)
        return lines
    except (IOError, OSError, ValueError) as e:
        _log_health('ERROR', 'Fallback diagnostics_state parse failed: {0}'.format(e))
        return diagnostics_lines
