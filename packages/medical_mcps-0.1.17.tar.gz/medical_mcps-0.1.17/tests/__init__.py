"""Tests for medical-mcps"""
