class RuidaCommandError(Exception):
    """
    Exception raised when an invalid Ruida command is received.
    """
