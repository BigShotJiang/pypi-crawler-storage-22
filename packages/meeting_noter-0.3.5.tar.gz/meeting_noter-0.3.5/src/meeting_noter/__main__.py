"""Entry point for python -m meeting_noter."""

from meeting_noter.cli import cli

if __name__ == "__main__":
    cli()
