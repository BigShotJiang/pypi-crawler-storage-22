"""Meeting Noter - Offline meeting transcription with virtual audio devices."""

__version__ = "0.1.0"
