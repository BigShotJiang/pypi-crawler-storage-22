"""Audio capture and processing modules."""
