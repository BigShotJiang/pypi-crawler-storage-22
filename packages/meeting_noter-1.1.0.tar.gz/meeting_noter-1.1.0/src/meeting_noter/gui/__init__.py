"""Desktop GUI for Meeting Noter."""

from meeting_noter.gui.app import run_gui

__all__ = ["run_gui"]
