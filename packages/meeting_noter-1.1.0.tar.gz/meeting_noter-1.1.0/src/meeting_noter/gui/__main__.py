"""Allow running gui as a module: python -m meeting_noter.gui"""

from meeting_noter.gui import run_gui

if __name__ == "__main__":
    run_gui()
