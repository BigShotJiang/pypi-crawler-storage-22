"""Resources package for Meeting Noter."""
