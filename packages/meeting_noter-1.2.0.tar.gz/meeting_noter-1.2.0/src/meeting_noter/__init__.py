"""Meeting Noter - Offline meeting transcription with virtual audio devices."""

__version__ = "1.2.0"
