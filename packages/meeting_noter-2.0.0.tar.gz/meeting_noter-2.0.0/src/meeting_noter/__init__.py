"""Meeting Noter - Offline meeting transcription with virtual audio devices."""

__version__ = "2.0.0"
