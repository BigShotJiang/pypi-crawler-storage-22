"""Transcript viewer screen for Meeting Noter."""

from __future__ import annotations

from datetime import datetime
from pathlib import Path

from textual.app import ComposeResult
from textual.containers import Container, Horizontal
from textual.screen import Screen
from textual.widgets import Button, Label, Static, TextArea

from meeting_noter.config import get_config


class ViewerScreen(Screen):
    """Transcript viewer screen."""

    BINDINGS = [
        ("f", "toggle_favorite", "Favorite"),
        ("escape", "go_back", "Back"),
    ]

    def __init__(self, transcript_path: Path, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.transcript_path = transcript_path

    def compose(self) -> ComposeResult:
        """Compose the viewer screen layout."""
        config = get_config()
        is_favorite = config.is_favorite(self.transcript_path.name)
        star = "★ " if is_favorite else ""

        yield Container(
            Static(
                f"[bold]{star}{self.transcript_path.name}[/bold]",
                classes="title",
            ),
            Label("", id="file-info"),
            Static("", classes="spacer"),
            TextArea(id="transcript-content", read_only=True),
            Static("", classes="spacer"),
            Horizontal(
                Button(
                    "★ Favorite" if not is_favorite else "☆ Unfavorite",
                    id="favorite-btn",
                    variant="warning" if is_favorite else "default",
                ),
                Button("Back", id="back-btn"),
                classes="button-row",
            ),
            id="viewer-container",
        )

    def on_mount(self) -> None:
        """Load transcript content on mount."""
        self._load_transcript()

    def _load_transcript(self) -> None:
        """Load the transcript content."""
        info_label = self.query_one("#file-info", Label)
        content_area = self.query_one("#transcript-content", TextArea)

        if not self.transcript_path.exists():
            info_label.update("[red]File not found[/red]")
            content_area.text = "Transcript file does not exist."
            return

        # Get file info
        stat = self.transcript_path.stat()
        mod_time = datetime.fromtimestamp(stat.st_mtime)
        date_str = mod_time.strftime("%Y-%m-%d %H:%M")
        size_kb = stat.st_size / 1024

        info_label.update(f"[dim]Modified: {date_str} | Size: {size_kb:.1f} KB[/dim]")

        # Load content
        try:
            content = self.transcript_path.read_text(encoding="utf-8")
            content_area.text = content
        except Exception as e:
            content_area.text = f"Error loading file: {e}"

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button presses."""
        if event.button.id == "favorite-btn":
            self.action_toggle_favorite()
        elif event.button.id == "back-btn":
            self.action_go_back()

    def action_toggle_favorite(self) -> None:
        """Toggle favorite status."""
        config = get_config()
        filename = self.transcript_path.name

        if config.is_favorite(filename):
            config.remove_favorite(filename)
            self.notify(f"Removed from favorites: {filename}")
        else:
            config.add_favorite(filename)
            self.notify(f"Added to favorites: {filename}")

        # Update the button
        btn = self.query_one("#favorite-btn", Button)
        is_favorite = config.is_favorite(filename)
        btn.label = "★ Favorite" if not is_favorite else "☆ Unfavorite"
        btn.variant = "warning" if is_favorite else "default"

        # Update title
        title = self.query_one(".title", Static)
        star = "★ " if is_favorite else ""
        title.update(f"[bold]{star}{filename}[/bold]")

    def action_go_back(self) -> None:
        """Go back to the previous screen."""
        self.app.pop_screen()
