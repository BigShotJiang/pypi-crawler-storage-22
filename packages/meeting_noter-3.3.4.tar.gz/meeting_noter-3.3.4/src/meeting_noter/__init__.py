"""Meeting Noter - Offline meeting transcription with virtual audio devices."""

__version__ = "3.3.4"
