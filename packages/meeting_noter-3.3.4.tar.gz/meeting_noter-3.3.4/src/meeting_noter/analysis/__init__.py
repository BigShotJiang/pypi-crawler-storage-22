"""AI-powered meeting analysis using local LLMs."""

from meeting_noter.analysis.analyzer import analyze_transcript, analyze_and_save
from meeting_noter.analysis.installer import (
    AINotInstalledError,
    install_ai,
    is_ai_installed,
    remove_ai,
    get_model_path,
    get_model_size,
    check_mlx_available,
)
from meeting_noter.analysis.llm import (
    is_mlx_available,
    generate_text,
    generate_chat,
    unload_model,
)
from meeting_noter.analysis.chat import TranscriptChat, quick_question

__all__ = [
    "analyze_transcript",
    "analyze_and_save",
    "AINotInstalledError",
    "install_ai",
    "is_ai_installed",
    "remove_ai",
    "get_model_path",
    "get_model_size",
    "check_mlx_available",
    "is_mlx_available",
    "generate_text",
    "generate_chat",
    "unload_model",
    "TranscriptChat",
    "quick_question",
]
