"""Meeting transcript analysis - summary and action items extraction."""

from __future__ import annotations

from pathlib import Path
from typing import Optional

from meeting_noter.analysis.llm import generate_text
from meeting_noter.analysis.installer import is_ai_installed, AINotInstalledError

# Prompt for meeting analysis
ANALYSIS_PROMPT = """Analyze this meeting transcript and provide:
1. A brief summary (2-3 sentences) of the key discussion points
2. Action items - tasks, to-dos, follow-ups, and deadlines mentioned

Transcript:
{transcript}

Format your response EXACTLY as:
## Summary
[Your 2-3 sentence summary here]

## Action Items
- [ ] [Action item 1]
- [ ] [Action item 2]
(If no action items found, write "No action items identified.")
"""

# Maximum characters of transcript to send (roughly 2000 tokens)
MAX_TRANSCRIPT_CHARS = 8000


def analyze_transcript(
    transcript_path: Path,
    max_tokens: int = 500,
) -> str:
    """Analyze a meeting transcript and generate summary + action items.

    Args:
        transcript_path: Path to the transcript .txt file
        max_tokens: Maximum tokens for the response

    Returns:
        Analysis text with summary and action items

    Raises:
        FileNotFoundError: If transcript doesn't exist
        AINotInstalledError: If AI is not installed
    """
    if not transcript_path.exists():
        raise FileNotFoundError(f"Transcript not found: {transcript_path}")

    if not is_ai_installed():
        raise AINotInstalledError()

    # Read transcript
    text = transcript_path.read_text()

    # Skip the header section (metadata lines)
    lines = text.split('\n')
    content_start = 0
    for i, line in enumerate(lines):
        if line.startswith('---'):
            content_start = i + 1
            break

    content = '\n'.join(lines[content_start:]) if content_start > 0 else text

    # Truncate if too long
    if len(content) > MAX_TRANSCRIPT_CHARS:
        content = content[:MAX_TRANSCRIPT_CHARS] + "\n\n[Transcript truncated...]"

    # Generate analysis
    prompt = ANALYSIS_PROMPT.format(transcript=content)
    result = generate_text(prompt, max_tokens=max_tokens, temperature=0.3)

    return result.strip()


def analyze_and_save(
    transcript_path: Path,
    force: bool = False,
) -> Optional[Path]:
    """Analyze a transcript and save the result.

    Args:
        transcript_path: Path to the transcript .txt file
        force: If True, overwrite existing analysis

    Returns:
        Path to the saved analysis file, or None if skipped

    Raises:
        FileNotFoundError: If transcript doesn't exist
        AINotInstalledError: If AI is not installed
    """
    summary_path = transcript_path.with_suffix('.summary.txt')

    if summary_path.exists() and not force:
        return None  # Already analyzed

    result = analyze_transcript(transcript_path)

    # Add header
    header = f"""Meeting Analysis
Source: {transcript_path.name}
----------------------------------------

"""
    summary_path.write_text(header + result)

    return summary_path


def get_summary_path(transcript_path: Path) -> Path:
    """Get the expected summary path for a transcript."""
    return transcript_path.with_suffix('.summary.txt')


def has_summary(transcript_path: Path) -> bool:
    """Check if a transcript has been analyzed."""
    return get_summary_path(transcript_path).exists()
