"""Chat functionality for meeting transcripts."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Optional

from meeting_noter.analysis.llm import generate_chat
from meeting_noter.analysis.installer import is_ai_installed, AINotInstalledError

# System prompt for transcript chat
CHAT_SYSTEM_PROMPT = """You are an AI assistant helping analyze a meeting transcript.
Answer questions based ONLY on the transcript content provided below.
If the answer is not in the transcript, clearly state that the information is not available in the transcript.
Be concise and helpful.

Meeting Transcript:
{transcript}
"""

# Maximum characters of transcript to include in context
MAX_TRANSCRIPT_CHARS = 8000


class TranscriptChat:
    """Interactive chat about a meeting transcript."""

    def __init__(self, transcript_path: Path):
        """Initialize chat with a transcript.

        Args:
            transcript_path: Path to the transcript .txt file

        Raises:
            FileNotFoundError: If transcript doesn't exist
            AINotInstalledError: If AI is not installed
        """
        if not transcript_path.exists():
            raise FileNotFoundError(f"Transcript not found: {transcript_path}")

        if not is_ai_installed():
            raise AINotInstalledError()

        self.transcript_path = transcript_path
        self.transcript_content = self._load_transcript()
        self.messages: list[dict[str, str]] = []

        # Chat history file path (same name as transcript but .chat.json)
        self._history_path = transcript_path.with_suffix('.chat.json')

        # Initialize with system prompt
        self._init_system_prompt()

        # Load existing history if available
        self._load_history()

    def _load_transcript(self) -> str:
        """Load and preprocess the transcript."""
        text = self.transcript_path.read_text()

        # Skip the header section (metadata lines)
        lines = text.split('\n')
        content_start = 0
        for i, line in enumerate(lines):
            if line.startswith('---'):
                content_start = i + 1
                break

        content = '\n'.join(lines[content_start:]) if content_start > 0 else text

        # Truncate if too long
        if len(content) > MAX_TRANSCRIPT_CHARS:
            content = content[:MAX_TRANSCRIPT_CHARS] + "\n\n[Transcript truncated...]"

        return content

    def _init_system_prompt(self) -> None:
        """Initialize the system prompt with transcript content."""
        system_message = CHAT_SYSTEM_PROMPT.format(transcript=self.transcript_content)
        self.messages = [{"role": "system", "content": system_message}]

    def _get_history_path(self) -> Path:
        """Get the path to the chat history file."""
        return self.transcript_path.with_suffix('.chat.json')

    def _load_history(self) -> None:
        """Load chat history from file if it exists."""
        history_path = self._get_history_path()
        if history_path.exists():
            try:
                with open(history_path, 'r') as f:
                    saved_history = json.load(f)
                # Append saved user/assistant messages to the current messages
                # (system prompt is already initialized)
                for msg in saved_history:
                    if msg.get("role") in ("user", "assistant"):
                        self.messages.append(msg)
            except (json.JSONDecodeError, IOError):
                # If history file is corrupted, start fresh
                pass

    def _save_history(self) -> None:
        """Save chat history to file."""
        history_path = self._get_history_path()
        # Only save user and assistant messages (not system prompt)
        history_to_save = [m for m in self.messages if m["role"] != "system"]
        try:
            with open(history_path, 'w') as f:
                json.dump(history_to_save, f, indent=2)
        except IOError:
            pass  # Silently fail if we can't save

    def ask(self, question: str, max_tokens: int = 500) -> str:
        """Ask a question about the transcript.

        Args:
            question: The question to ask
            max_tokens: Maximum tokens for the response

        Returns:
            AI response
        """
        # Add user message
        self.messages.append({"role": "user", "content": question})

        # Generate response
        response = generate_chat(self.messages, max_tokens=max_tokens, temperature=0.3)

        # Add assistant response to history
        self.messages.append({"role": "assistant", "content": response})

        # Save history to file
        self._save_history()

        return response

    def clear_history(self) -> None:
        """Clear chat history but keep the system prompt."""
        self._init_system_prompt()
        # Delete history file
        history_path = self._get_history_path()
        if history_path.exists():
            try:
                history_path.unlink()
            except IOError:
                pass

    def get_history(self) -> list[dict[str, str]]:
        """Get chat history (excluding system prompt).

        Returns:
            List of user and assistant messages.
        """
        return [m for m in self.messages if m["role"] != "system"]


def quick_question(transcript_path: Path, question: str, max_tokens: int = 500) -> str:
    """Ask a single question about a transcript without maintaining history.

    Args:
        transcript_path: Path to the transcript
        question: The question to ask
        max_tokens: Maximum tokens for the response

    Returns:
        AI response
    """
    chat = TranscriptChat(transcript_path)
    return chat.ask(question, max_tokens)
