"""AI model installation and management."""

from __future__ import annotations

import shutil
from pathlib import Path
from typing import Callable, Optional

MODEL_ID = "mlx-community/Qwen2.5-7B-Instruct-4bit"
MODEL_NAME = "qwen2.5-7b-instruct-4bit"


def get_default_model_dir() -> Path:
    """Get default model directory inside recordings_dir/.ai/."""
    from meeting_noter.config import get_config
    config = get_config()
    return config.recordings_dir / ".ai" / MODEL_NAME


def is_ai_installed() -> bool:
    """Check if AI model is installed and valid.

    Returns:
        True if model is installed and has required files, False otherwise.
    """
    from meeting_noter.config import get_config
    # Reload config in case it was modified by CLI while GUI is running
    config = get_config(reload=True)

    if not config.ai_installed:
        return False

    model_path = Path(config.ai_model_path)
    if not model_path.exists():
        return False

    # Check for required model files
    required_files = ["model.safetensors", "config.json", "tokenizer.json"]
    for f in required_files:
        if not (model_path / f).exists():
            # Some models split safetensors into multiple files
            if f == "model.safetensors":
                # Check for sharded model
                if not list(model_path.glob("model-*.safetensors")):
                    return False
            else:
                return False

    return True


def get_model_path() -> Optional[Path]:
    """Get path to installed model, or None if not installed.

    Returns:
        Path to model directory if installed, None otherwise.
    """
    if not is_ai_installed():
        return None

    from meeting_noter.config import get_config
    return Path(get_config().ai_model_path)


def get_model_size() -> Optional[int]:
    """Get the size of the installed model in bytes.

    Returns:
        Total size of model directory in bytes, or None if not installed.
    """
    model_path = get_model_path()
    if not model_path:
        return None

    total_size = 0
    for f in model_path.rglob("*"):
        if f.is_file():
            total_size += f.stat().st_size
    return total_size


def install_ai(progress_callback: Optional[Callable[[int, int], None]] = None) -> Path:
    """Download and install the AI model.

    Args:
        progress_callback: Optional callback(downloaded_bytes, total_bytes) for progress updates.

    Returns:
        Path to the installed model directory.

    Raises:
        ImportError: If huggingface_hub is not installed.
        Exception: If download fails.
    """
    try:
        from huggingface_hub import snapshot_download
    except ImportError:
        raise ImportError(
            "huggingface_hub is required to download AI models. "
            "Install with: pip install huggingface_hub"
        )

    from meeting_noter.config import get_config

    model_dir = get_default_model_dir()
    model_dir.parent.mkdir(parents=True, exist_ok=True)

    # Download the model
    snapshot_download(
        repo_id=MODEL_ID,
        local_dir=model_dir,
        ignore_patterns=["*.md", ".gitattributes", "*.txt"],
    )

    # Update config
    config = get_config()
    config.ai_installed = True
    config.ai_model_path = str(model_dir)
    config.save()

    return model_dir


def remove_ai() -> bool:
    """Remove the AI model to free disk space.

    Returns:
        True if model was removed, False if it wasn't installed.
    """
    from meeting_noter.config import get_config

    config = get_config()

    if not config.ai_installed and not config.ai_model_path:
        return False

    # Remove model directory
    if config.ai_model_path:
        model_path = Path(config.ai_model_path)
        if model_path.exists():
            shutil.rmtree(model_path, ignore_errors=True)

        # Also remove .ai directory if empty
        ai_dir = model_path.parent
        if ai_dir.exists() and not any(ai_dir.iterdir()):
            ai_dir.rmdir()

    # Update config
    config.ai_installed = False
    config.ai_model_path = ""
    config.save()

    return True


def check_mlx_available() -> tuple[bool, str]:
    """Check if MLX is available for running AI models.

    Returns:
        Tuple of (is_available, message).
    """
    import platform

    # Check if on macOS
    if platform.system() != "Darwin":
        return False, "MLX requires macOS"

    # Check if Apple Silicon
    if platform.machine() not in ("arm64", "arm64e"):
        return False, "MLX requires Apple Silicon (M1/M2/M3/M4)"

    # Check if mlx-lm is installed
    try:
        import mlx_lm
        return True, f"MLX available (mlx-lm {mlx_lm.__version__})"
    except ImportError:
        return False, "mlx-lm not installed. Install with: pip install meeting-noter[ai]"


class AINotInstalledError(Exception):
    """Raised when AI features are used but AI is not installed."""

    def __init__(self, message: str = "AI not installed. Run: meeting-noter install-ai"):
        super().__init__(message)
