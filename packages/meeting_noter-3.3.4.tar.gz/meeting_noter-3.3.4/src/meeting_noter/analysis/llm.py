"""Local LLM loading and inference using MLX."""

from __future__ import annotations

from pathlib import Path
from typing import Optional, Tuple, Any

from meeting_noter.analysis.installer import AINotInstalledError, is_ai_installed, get_model_path

# Lazy-loaded model cache
_model: Any = None
_tokenizer: Any = None


def is_mlx_available() -> bool:
    """Check if MLX and mlx-lm are available."""
    try:
        import mlx
        import mlx_lm
        return True
    except ImportError:
        return False


def get_llm() -> Tuple[Any, Any]:
    """Load the LLM model from the installed path.

    Returns:
        Tuple of (model, tokenizer)

    Raises:
        AINotInstalledError: If AI is not installed
        ImportError: If mlx-lm is not installed
    """
    global _model, _tokenizer

    if _model is not None:
        return _model, _tokenizer

    # Check if AI is installed
    if not is_ai_installed():
        raise AINotInstalledError()

    # Check for MLX
    try:
        from mlx_lm import load
    except ImportError:
        raise ImportError(
            "mlx-lm is required for AI features. "
            "Install with: pip install meeting-noter[ai]"
        )

    # Load from installed path
    model_path = get_model_path()
    if not model_path:
        raise AINotInstalledError("Model path not found. Run: meeting-noter install-ai")

    _model, _tokenizer = load(str(model_path))
    return _model, _tokenizer


def generate_text(
    prompt: str,
    max_tokens: int = 500,
    temperature: float = 0.7,
) -> str:
    """Generate text using the local LLM.

    Args:
        prompt: The input prompt
        max_tokens: Maximum tokens to generate
        temperature: Sampling temperature (0.0 = deterministic, 1.0 = creative)

    Returns:
        Generated text

    Raises:
        AINotInstalledError: If AI is not installed
        ImportError: If mlx-lm is not installed
    """
    from mlx_lm import generate

    model, tokenizer = get_llm()

    # Format as chat message for instruction-tuned models
    messages = [{"role": "user", "content": prompt}]
    formatted_prompt = tokenizer.apply_chat_template(
        messages, tokenize=False, add_generation_prompt=True
    )

    response = generate(
        model,
        tokenizer,
        prompt=formatted_prompt,
        max_tokens=max_tokens,
    )

    return response


def generate_chat(
    messages: list[dict[str, str]],
    max_tokens: int = 500,
    temperature: float = 0.7,
) -> str:
    """Generate a response for a multi-turn chat conversation.

    Args:
        messages: List of message dicts with 'role' and 'content' keys.
                  Roles can be 'system', 'user', or 'assistant'.
        max_tokens: Maximum tokens to generate
        temperature: Sampling temperature

    Returns:
        Generated response text

    Raises:
        AINotInstalledError: If AI is not installed
        ImportError: If mlx-lm is not installed
    """
    from mlx_lm import generate

    model, tokenizer = get_llm()

    # Format the full conversation
    formatted_prompt = tokenizer.apply_chat_template(
        messages, tokenize=False, add_generation_prompt=True
    )

    response = generate(
        model,
        tokenizer,
        prompt=formatted_prompt,
        max_tokens=max_tokens,
    )

    return response


def unload_model() -> None:
    """Unload the model from memory."""
    global _model, _tokenizer
    _model = None
    _tokenizer = None
