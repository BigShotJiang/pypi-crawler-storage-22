"""Configuration management for Meeting Noter."""

from __future__ import annotations

import functools
import json
import re
from datetime import datetime
from pathlib import Path
from typing import Any

import click


def generate_meeting_name() -> str:
    """Generate a default meeting name with current timestamp."""
    now = datetime.now()
    return now.strftime("%d_%b_%Y_%H%M")  # e.g., "29_Jan_2026_1430"


def is_default_meeting_name(name: str) -> bool:
    """Check if a name matches the default timestamp pattern."""
    # Pattern: DD_Mon_YYYY_HHMM (e.g., 29_Jan_2026_1430)
    return bool(re.match(r"^\d{2}_[A-Z][a-z]{2}_\d{4}_\d{4}$", name))


DEFAULT_CONFIG_DIR = Path.home() / ".config" / "meeting-noter"
DEFAULT_CONFIG_FILE = DEFAULT_CONFIG_DIR / "config.json"

DEFAULT_CONFIG = {
    "recordings_dir": str(Path.home() / "meetings"),
    "transcripts_dir": str(Path.home() / "meetings"),
    "whisper_model": "tiny.en",
    "auto_transcribe": True,
    "auto_analyze": False,  # Auto-analyze after transcription (requires AI)
    "ai_installed": False,  # Whether AI model is downloaded
    "ai_model_path": "",  # Path to downloaded AI model
    "auto_update": True,  # Auto-update when running --version
    "silence_timeout": 5,  # Minutes of silence before stopping recording
    "capture_system_audio": True,  # Capture other participants via ScreenCaptureKit
    "show_menubar": False,
    "setup_complete": False,
    "meetings_view_mode": "month",  # day, week, or month
    "chunk_transcription": True,  # Transcribe in chunks during recording
    "chunk_duration": 300,  # Chunk duration in seconds (5 minutes)
}


class Config:
    """Configuration manager for Meeting Noter."""

    def __init__(self, config_path: Path = DEFAULT_CONFIG_FILE):
        self.config_path = config_path
        self._data: dict[str, Any] = {}
        self.load()

    def load(self) -> None:
        """Load configuration from disk."""
        if self.config_path.exists():
            try:
                with open(self.config_path, "r") as f:
                    self._data = json.load(f)
            except (json.JSONDecodeError, IOError):
                self._data = {}
        else:
            self._data = {}

        # Fill in missing defaults
        for key, value in DEFAULT_CONFIG.items():
            if key not in self._data:
                self._data[key] = value

    def save(self) -> None:
        """Save configuration to disk."""
        self.config_path.parent.mkdir(parents=True, exist_ok=True)
        with open(self.config_path, "w") as f:
            json.dump(self._data, f, indent=4)

    @property
    def recordings_dir(self) -> Path:
        """Get recordings directory."""
        return Path(self._data["recordings_dir"]).expanduser()

    @recordings_dir.setter
    def recordings_dir(self, value: Path | str) -> None:
        """Set recordings directory."""
        self._data["recordings_dir"] = str(value)

    @property
    def transcripts_dir(self) -> Path:
        """Get transcripts directory."""
        return Path(self._data["transcripts_dir"]).expanduser()

    @transcripts_dir.setter
    def transcripts_dir(self, value: Path | str) -> None:
        """Set transcripts directory."""
        self._data["transcripts_dir"] = str(value)

    @property
    def whisper_model(self) -> str:
        """Get Whisper model name."""
        return self._data["whisper_model"]

    @whisper_model.setter
    def whisper_model(self, value: str) -> None:
        """Set Whisper model name."""
        self._data["whisper_model"] = value

    @property
    def auto_transcribe(self) -> bool:
        """Get auto-transcribe setting."""
        return self._data["auto_transcribe"]

    @auto_transcribe.setter
    def auto_transcribe(self, value: bool) -> None:
        """Set auto-transcribe setting."""
        self._data["auto_transcribe"] = value

    @property
    def auto_analyze(self) -> bool:
        """Get auto-analyze setting (AI summary after transcription)."""
        return self._data.get("auto_analyze", False)

    @auto_analyze.setter
    def auto_analyze(self, value: bool) -> None:
        """Set auto-analyze setting."""
        self._data["auto_analyze"] = value

    @property
    def ai_installed(self) -> bool:
        """Get whether AI model is installed."""
        return self._data.get("ai_installed", False)

    @ai_installed.setter
    def ai_installed(self, value: bool) -> None:
        """Set AI installed status."""
        self._data["ai_installed"] = value

    @property
    def ai_model_path(self) -> str:
        """Get path to the downloaded AI model."""
        return self._data.get("ai_model_path", "")

    @ai_model_path.setter
    def ai_model_path(self, value: str) -> None:
        """Set AI model path."""
        self._data["ai_model_path"] = value

    @property
    def silence_timeout(self) -> int:
        """Get silence timeout in minutes."""
        return self._data.get("silence_timeout", 5)

    @silence_timeout.setter
    def silence_timeout(self, value: int) -> None:
        """Set silence timeout in minutes."""
        self._data["silence_timeout"] = value

    @property
    def capture_system_audio(self) -> bool:
        """Get capture system audio setting."""
        return self._data.get("capture_system_audio", True)

    @capture_system_audio.setter
    def capture_system_audio(self, value: bool) -> None:
        """Set capture system audio setting."""
        self._data["capture_system_audio"] = value

    @property
    def show_menubar(self) -> bool:
        """Get show menubar setting."""
        return self._data.get("show_menubar", False)

    @show_menubar.setter
    def show_menubar(self, value: bool) -> None:
        """Set show menubar setting."""
        self._data["show_menubar"] = value

    @property
    def auto_update(self) -> bool:
        """Get auto-update setting."""
        return self._data.get("auto_update", True)

    @auto_update.setter
    def auto_update(self, value: bool) -> None:
        """Set auto-update setting."""
        self._data["auto_update"] = value

    @property
    def setup_complete(self) -> bool:
        """Check if setup has been completed."""
        return self._data.get("setup_complete", False)

    @setup_complete.setter
    def setup_complete(self, value: bool) -> None:
        """Set setup completion status."""
        self._data["setup_complete"] = value

    @property
    def meetings_view_mode(self) -> str:
        """Get meetings calendar view mode (day, week, or month)."""
        return self._data.get("meetings_view_mode", "month")

    @meetings_view_mode.setter
    def meetings_view_mode(self, value: str) -> None:
        """Set meetings calendar view mode."""
        if value in ("day", "week", "month"):
            self._data["meetings_view_mode"] = value

    @property
    def chunk_transcription(self) -> bool:
        """Get chunk transcription setting (transcribe during recording)."""
        return self._data.get("chunk_transcription", True)

    @chunk_transcription.setter
    def chunk_transcription(self, value: bool) -> None:
        """Set chunk transcription setting."""
        self._data["chunk_transcription"] = value

    @property
    def chunk_duration(self) -> int:
        """Get chunk duration in seconds for chunked transcription."""
        return self._data.get("chunk_duration", 300)

    @chunk_duration.setter
    def chunk_duration(self, value: int) -> None:
        """Set chunk duration in seconds."""
        self._data["chunk_duration"] = value

    @property
    def favorites(self) -> list[str]:
        """Get list of favorite transcript filenames."""
        return self._data.get("favorites", [])

    @favorites.setter
    def favorites(self, value: list[str]) -> None:
        """Set list of favorite transcript filenames."""
        self._data["favorites"] = value

    def add_favorite(self, filename: str) -> bool:
        """Add a transcript to favorites. Returns True if added, False if already exists."""
        favorites = self.favorites
        if filename not in favorites:
            favorites.append(filename)
            self.favorites = favorites
            self.save()
            return True
        return False

    def remove_favorite(self, filename: str) -> bool:
        """Remove a transcript from favorites. Returns True if removed, False if not found."""
        favorites = self.favorites
        if filename in favorites:
            favorites.remove(filename)
            self.favorites = favorites
            self.save()
            return True
        return False

    def is_favorite(self, filename: str) -> bool:
        """Check if a transcript is a favorite."""
        return filename in self.favorites

    @property
    def tags(self) -> dict[str, list[str]]:
        """Get tags dictionary mapping filename to list of tags."""
        if "tags" not in self._data:
            self._data["tags"] = {}
        return self._data["tags"]

    @tags.setter
    def tags(self, value: dict[str, list[str]]) -> None:
        """Set tags dictionary."""
        self._data["tags"] = value

    def add_tag(self, filename: str, tag: str) -> bool:
        """Add a tag to a recording. Returns True if added, False if already exists."""
        tags = self.tags  # Now returns the actual dict from _data
        if filename not in tags:
            tags[filename] = []
        tag = tag.strip()
        if tag and tag not in tags[filename]:
            tags[filename].append(tag)
            self.save()
            return True
        return False

    def remove_tag(self, filename: str, tag: str) -> bool:
        """Remove a tag from a recording. Returns True if removed, False if not found."""
        tags = self.tags  # Now returns the actual dict from _data
        if filename in tags and tag in tags[filename]:
            tags[filename].remove(tag)
            if not tags[filename]:
                del tags[filename]
            self.save()
            return True
        return False

    def get_tags(self, filename: str) -> list[str]:
        """Get tags for a recording."""
        return self.tags.get(filename, [])

    def get_all_tags(self) -> set[str]:
        """Get all unique tags across all recordings."""
        all_tags: set[str] = set()
        for tag_list in self.tags.values():
            all_tags.update(tag_list)
        return all_tags

    def get_files_by_tag(self, tag: str) -> list[str]:
        """Get all filenames that have a specific tag."""
        return [filename for filename, tag_list in self.tags.items() if tag in tag_list]

    def rename_file_tags(self, old_filename: str, new_filename: str) -> None:
        """Update tags when a file is renamed."""
        tags = self.tags
        if old_filename in tags:
            tags[new_filename] = tags.pop(old_filename)
            self.tags = tags
            self.save()

    def __getitem__(self, key: str) -> Any:
        """Get config value by key."""
        return self._data.get(key, DEFAULT_CONFIG.get(key))

    def __setitem__(self, key: str, value: Any) -> None:
        """Set config value by key."""
        self._data[key] = value


# Global config instance (lazy loaded)
_config: Config | None = None


def get_config(reload: bool = False) -> Config:
    """Get the global config instance.

    Args:
        reload: If True, reload config from disk. Useful when config
                may have been modified by another process (e.g., CLI
                while GUI is running).
    """
    global _config
    if _config is None:
        _config = Config()
    elif reload:
        _config.load()
    return _config


def is_setup_complete() -> bool:
    """Check if setup has been completed."""
    return get_config().setup_complete


def require_setup(f):
    """Decorator that ensures basic config exists.

    Now more lenient - just ensures config directories exist.
    Setup is optional since we can use any microphone.

    Usage:
        @cli.command()
        @require_setup
        def my_command():
            ...
    """
    @functools.wraps(f)
    def wrapper(*args, **kwargs):
        config = get_config()
        # Ensure directories exist
        config.recordings_dir.mkdir(parents=True, exist_ok=True)
        config.transcripts_dir.mkdir(parents=True, exist_ok=True)
        return f(*args, **kwargs)
    return wrapper
