"""Meeting Noter Desktop GUI - Modern PySide6 interface."""

from __future__ import annotations


def run_gui():
    """Launch the GUI application with system tray icon."""
    import sys
    from pathlib import Path

    from PySide6.QtCore import Qt
    from PySide6.QtGui import QIcon
    from PySide6.QtWidgets import QApplication

    from meeting_noter.gui.main_window import MainWindow
    from meeting_noter.gui.menubar import MenuBarIcon

    # Enable High DPI scaling
    QApplication.setHighDpiScaleFactorRoundingPolicy(
        Qt.HighDpiScaleFactorRoundingPolicy.PassThrough
    )

    app = QApplication(sys.argv)
    app.setApplicationName("Meeting Noter")
    app.setOrganizationName("Meeting Noter")

    # Set application icon (for dock)
    resources_dir = Path(__file__).parent.parent / "resources"
    icon_path = resources_dir / "icon.icns"
    if not icon_path.exists():
        icon_path = resources_dir / "icon.png"
    if icon_path.exists():
        app.setWindowIcon(QIcon(str(icon_path)))

    # Don't quit when last window closes (we have tray icon)
    app.setQuitOnLastWindowClosed(False)

    # Create main window
    window = MainWindow()

    # Create system tray icon
    tray_icon = MenuBarIcon(window)
    tray_icon.show()

    # Give window reference to tray icon
    window.set_tray_icon(tray_icon)

    # Show window
    window.show()

    sys.exit(app.exec())
