"""Main window for Meeting Noter GUI."""

from __future__ import annotations

import platform

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QApplication,
    QHBoxLayout,
    QMainWindow,
    QStackedWidget,
    QWidget,
)

# macOS dock visibility control
if platform.system() == "Darwin":
    try:
        from AppKit import NSApp, NSApplicationActivationPolicyAccessory, NSApplicationActivationPolicyRegular
        HAS_APPKIT = True
    except ImportError:
        HAS_APPKIT = False
else:
    HAS_APPKIT = False

from meeting_noter.gui.screens import (
    DashboardScreen,
    LogsScreen,
    MeetingsScreen,
    RecordingsScreen,
    SearchScreen,
    SettingsScreen,
    ViewerScreen,
)
from meeting_noter.gui.theme import apply_theme
from meeting_noter.gui.utils.signals import get_app_state
from meeting_noter.gui.utils.workers import StatusPollingWorker
from meeting_noter.gui.widgets import Sidebar


class MainWindow(QMainWindow):
    """Main application window with sidebar navigation."""

    def __init__(self, tray_icon=None):
        super().__init__()
        self.setWindowTitle("Meeting Noter")
        self.setMinimumSize(1000, 700)
        self.resize(1200, 800)

        self._tray_icon = tray_icon
        self._force_quit = False

        # Apply dark theme
        apply_theme(self.app())

        self._setup_ui()
        self._setup_workers()
        self._connect_signals()

        # Select dashboard initially
        self._show_screen("dashboard")

    def app(self):
        """Get the QApplication instance."""
        return QApplication.instance()

    def set_tray_icon(self, tray_icon):
        """Set the tray icon reference."""
        self._tray_icon = tray_icon

    def _setup_ui(self):
        """Set up the main UI."""
        # Central widget
        central = QWidget()
        self.setCentralWidget(central)

        # Main layout (horizontal: sidebar + content)
        layout = QHBoxLayout(central)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # Sidebar
        self._sidebar = Sidebar()
        self._sidebar.quit_requested.connect(self._quit_app)
        layout.addWidget(self._sidebar)

        # Content area (stacked widget)
        self._content = QStackedWidget()
        self._content.setObjectName("content-area")
        layout.addWidget(self._content, 1)  # Stretch factor 1

        # Create screens
        self._screens: dict[str, QWidget] = {}
        self._create_screens()

    def _create_screens(self):
        """Create all screen widgets."""
        # Dashboard
        self._screens["dashboard"] = DashboardScreen()
        self._content.addWidget(self._screens["dashboard"])

        # Meetings
        self._screens["meetings"] = MeetingsScreen()
        self._content.addWidget(self._screens["meetings"])

        # Recordings
        self._screens["recordings"] = RecordingsScreen()
        self._content.addWidget(self._screens["recordings"])

        # Search
        self._screens["search"] = SearchScreen()
        self._content.addWidget(self._screens["search"])

        # Settings
        self._screens["settings"] = SettingsScreen()
        self._content.addWidget(self._screens["settings"])

        # Logs
        self._screens["logs"] = LogsScreen()
        self._content.addWidget(self._screens["logs"])

        # Viewer (for transcripts)
        self._screens["viewer"] = ViewerScreen()
        self._content.addWidget(self._screens["viewer"])

    def _setup_workers(self):
        """Set up background workers."""
        # Status polling
        self._status_worker = StatusPollingWorker()
        self._status_worker.status_updated.connect(self._on_status_updated)
        self._status_worker.start()

    def _connect_signals(self):
        """Connect signals."""
        # Sidebar navigation
        self._sidebar.screen_selected.connect(self._show_screen)

        # App state signals
        app_state = get_app_state()
        app_state.navigate_to.connect(self._show_screen)
        app_state.open_transcript.connect(self._open_transcript)

    def _show_screen(self, screen_id: str):
        """Show a screen by ID."""
        if screen_id in self._screens:
            self._content.setCurrentWidget(self._screens[screen_id])
            self._sidebar.select_screen(screen_id)

            # Refresh screen if it has a refresh method
            screen = self._screens[screen_id]
            if hasattr(screen, "refresh"):
                screen.refresh()

    def _open_transcript(self, filepath: str):
        """Open a transcript in the viewer."""
        viewer = self._screens.get("viewer")
        if viewer and hasattr(viewer, "load_transcript"):
            viewer.load_transcript(filepath)
            self._show_screen("viewer")

    def _on_status_updated(self, watcher_running: bool, daemon_running: bool, meeting_name: str):
        """Handle status update from worker."""
        # Update sidebar status
        self._sidebar.update_status(daemon_running, meeting_name)

        # Update dashboard status indicator
        dashboard = self._screens.get("dashboard")
        if dashboard and hasattr(dashboard, "update_status"):
            dashboard.update_status(watcher_running, daemon_running, meeting_name)

        # Update tray icon
        if self._tray_icon:
            self._tray_icon.update_status(watcher_running, daemon_running, meeting_name)

        # Update app state
        app_state = get_app_state()
        app_state._is_recording = daemon_running
        app_state._current_meeting = meeting_name
        app_state._watcher_running = watcher_running

    def _quit_app(self):
        """Quit the application completely."""
        self._force_quit = True
        self._cleanup()
        QApplication.instance().quit()

    def _cleanup(self):
        """Clean up workers and resources."""
        # Stop workers
        if hasattr(self, "_status_worker"):
            self._status_worker.stop()

        # Stop screen workers
        for screen in self._screens.values():
            if hasattr(screen, "stop_workers"):
                screen.stop_workers()

    def closeEvent(self, event):
        """Handle window close - hide to tray instead of quitting."""
        if self._force_quit or self._tray_icon is None:
            # Actually quit
            self._cleanup()
            event.accept()
        else:
            # Hide to tray instead of closing
            event.ignore()
            self.hide()
            self._hide_from_dock()

    def show(self):
        """Show window and add to dock."""
        self.resize(1400, 800)  # Reasonable default size
        super().show()
        self._show_in_dock()

    def _hide_from_dock(self):
        """Hide app from macOS dock."""
        if HAS_APPKIT:
            NSApp.setActivationPolicy_(NSApplicationActivationPolicyAccessory)

    def _show_in_dock(self):
        """Show app in macOS dock."""
        if HAS_APPKIT:
            NSApp.setActivationPolicy_(NSApplicationActivationPolicyRegular)
            NSApp.activateIgnoringOtherApps_(True)
