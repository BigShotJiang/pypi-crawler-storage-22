"""Menu bar (system tray) integration for Meeting Noter GUI."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from PySide6.QtCore import QTimer
from PySide6.QtGui import QAction, QIcon, QPixmap, QPainter, QColor, QFont
from PySide6.QtWidgets import QMenu, QSystemTrayIcon

if TYPE_CHECKING:
    from meeting_noter.gui.main_window import MainWindow


class MenuBarIcon(QSystemTrayIcon):
    """System tray / menu bar icon for Meeting Noter."""

    # Status states
    STATUS_STOPPED = "stopped"
    STATUS_READY = "ready"
    STATUS_RECORDING = "recording"

    def __init__(self, main_window: "MainWindow"):
        super().__init__()
        self._main_window = main_window
        self._current_status = self.STATUS_STOPPED
        self._recording_name = ""

        self._setup_icons()
        self._setup_menu()
        self._setup_polling()

        # Set initial icon
        self._update_icon()

        # Connect signals
        self.activated.connect(self._on_activated)

    def _setup_icons(self):
        """Create status icons programmatically."""
        self._icons = {}

        # Create icons for each status
        for status, color in [
            (self.STATUS_STOPPED, "#5a5a5a"),  # Gray
            (self.STATUS_READY, "#4ec9b0"),     # Green/Cyan
            (self.STATUS_RECORDING, "#f14c4c"), # Red
        ]:
            self._icons[status] = self._create_icon(color)

    def _create_icon(self, color: str) -> QIcon:
        """Create a simple colored circle icon."""
        size = 22
        pixmap = QPixmap(size, size)
        pixmap.fill(QColor(0, 0, 0, 0))  # Transparent background

        painter = QPainter(pixmap)
        painter.setRenderHint(QPainter.Antialiasing)

        # Draw filled circle
        painter.setBrush(QColor(color))
        painter.setPen(QColor(color))
        margin = 3
        painter.drawEllipse(margin, margin, size - margin * 2, size - margin * 2)

        painter.end()
        return QIcon(pixmap)

    def _setup_menu(self):
        """Set up the context menu."""
        self._menu = QMenu()
        self._menu.setStyleSheet("""
            QMenu {
                background-color: #1a1a1a;
                border: 1px solid #2a2a2a;
                border-radius: 6px;
                padding: 5px;
            }
            QMenu::item {
                color: #d4d4d4;
                padding: 8px 20px;
                border-radius: 4px;
            }
            QMenu::item:selected {
                background-color: #2a2a2a;
            }
            QMenu::separator {
                height: 1px;
                background-color: #2a2a2a;
                margin: 5px 10px;
            }
        """)

        # Status label (non-clickable)
        self._status_action = QAction("● Stopped")
        self._status_action.setEnabled(False)
        self._menu.addAction(self._status_action)

        self._menu.addSeparator()

        # Open GUI
        self._open_action = QAction("Open Meeting Noter")
        self._open_action.triggered.connect(self._show_main_window)
        self._menu.addAction(self._open_action)

        self._menu.addSeparator()

        # Quit
        self._quit_action = QAction("Quit Meeting Noter")
        self._quit_action.triggered.connect(self._quit_app)
        self._menu.addAction(self._quit_action)

        self.setContextMenu(self._menu)

    def _setup_polling(self):
        """Set up status polling timer."""
        self._poll_timer = QTimer()
        self._poll_timer.timeout.connect(self._poll_status)
        self._poll_timer.start(2000)  # Poll every 2 seconds

    def _poll_status(self):
        """Poll for status updates."""
        import os
        from meeting_noter.daemon import is_process_running, read_pid_file

        DEFAULT_PID_FILE = Path.home() / ".meeting-noter.pid"
        WATCHER_PID_FILE = Path.home() / ".meeting-noter-watcher.pid"

        # Check watcher
        watcher_running = False
        if WATCHER_PID_FILE.exists():
            try:
                pid = int(WATCHER_PID_FILE.read_text().strip())
                os.kill(pid, 0)
                watcher_running = True
            except (ProcessLookupError, ValueError, FileNotFoundError, PermissionError):
                pass

        # Check daemon
        daemon_running = False
        daemon_pid = read_pid_file(DEFAULT_PID_FILE)
        if daemon_pid and is_process_running(daemon_pid):
            daemon_running = True

        # Determine status
        if daemon_running:
            new_status = self.STATUS_RECORDING
            # Get recording name
            recording_name = self._get_recording_name()
            self._recording_name = recording_name or "Recording..."
        elif watcher_running:
            new_status = self.STATUS_READY
            self._recording_name = ""
        else:
            new_status = self.STATUS_STOPPED
            self._recording_name = ""

        if new_status != self._current_status:
            self._current_status = new_status
            self._update_icon()
            self._update_status_text()

    def _get_recording_name(self) -> str:
        """Get the current recording name from logs."""
        log_path = Path.home() / ".meeting-noter.log"
        if not log_path.exists():
            return ""

        try:
            with open(log_path, "r") as f:
                lines = f.readlines()

            for line in reversed(lines[-50:]):
                if "Recording started:" in line:
                    parts = line.split("Recording started:")
                    if len(parts) > 1:
                        filename = parts[1].strip().replace(".mp3", "")
                        name_parts = filename.split("_", 2)
                        if len(name_parts) >= 3:
                            return name_parts[2]
                        return filename
                elif "Recording saved:" in line or "Recording discarded" in line:
                    break
            return ""
        except Exception:
            return ""

    def _update_icon(self):
        """Update the tray icon based on status."""
        self.setIcon(self._icons[self._current_status])

    def _update_status_text(self):
        """Update the status text in menu."""
        if self._current_status == self.STATUS_RECORDING:
            text = f"● Recording: {self._recording_name}"
        elif self._current_status == self.STATUS_READY:
            text = "● Ready"
        else:
            text = "● Stopped"

        self._status_action.setText(text)

        # Update tooltip
        self.setToolTip(f"Meeting Noter - {text}")

    def _on_activated(self, reason):
        """Handle tray icon activation."""
        if reason == QSystemTrayIcon.ActivationReason.Trigger:
            # Single click - toggle window visibility
            self._toggle_main_window()
        elif reason == QSystemTrayIcon.ActivationReason.DoubleClick:
            # Double click - show window
            self._show_main_window()

    def _toggle_main_window(self):
        """Toggle main window visibility."""
        if self._main_window.isVisible():
            self._main_window.hide()
        else:
            self._show_main_window()

    def _show_main_window(self):
        """Show and raise the main window."""
        self._main_window.show()  # This also shows in dock
        self._main_window.raise_()
        self._main_window.activateWindow()

    def _quit_app(self):
        """Quit the application completely."""
        self._poll_timer.stop()
        from PySide6.QtWidgets import QApplication
        QApplication.instance().quit()

    def update_status(self, watcher_running: bool, daemon_running: bool, meeting_name: str):
        """Update status from external source."""
        if daemon_running:
            self._current_status = self.STATUS_RECORDING
            self._recording_name = meeting_name or "Recording..."
        elif watcher_running:
            self._current_status = self.STATUS_READY
            self._recording_name = ""
        else:
            self._current_status = self.STATUS_STOPPED
            self._recording_name = ""

        self._update_icon()
        self._update_status_text()
