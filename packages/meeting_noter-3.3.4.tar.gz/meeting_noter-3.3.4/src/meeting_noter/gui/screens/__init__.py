"""Screen modules for Meeting Noter GUI."""

from meeting_noter.gui.screens.dashboard import DashboardScreen
from meeting_noter.gui.screens.logs import LogsScreen
from meeting_noter.gui.screens.meetings import MeetingsScreen
from meeting_noter.gui.screens.recordings import RecordingsScreen
from meeting_noter.gui.screens.search import SearchScreen
from meeting_noter.gui.screens.settings import SettingsScreen
from meeting_noter.gui.screens.viewer import ViewerScreen

__all__ = [
    "DashboardScreen",
    "MeetingsScreen",
    "RecordingsScreen",
    "SearchScreen",
    "ViewerScreen",
    "SettingsScreen",
    "LogsScreen",
]
