"""Dashboard screen for Meeting Noter GUI."""

from __future__ import annotations

import os
import signal
import subprocess
import sys
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtGui import QFont
from PySide6.QtWidgets import (
    QCheckBox,
    QFrame,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from meeting_noter.config import generate_meeting_name, get_config
from meeting_noter.daemon import is_process_running, read_pid_file
from meeting_noter.gui.utils.workers import LiveTranscriptWatcher
from meeting_noter.gui.widgets.status_indicator import StatusIndicator


DEFAULT_PID_FILE = Path.home() / ".meeting-noter.pid"
WATCHER_PID_FILE = Path.home() / ".meeting-noter-watcher.pid"


class DashboardScreen(QWidget):
    """Main dashboard screen with recording controls."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._setup_ui()
        self._setup_workers()
        self._connect_signals()

    def _setup_ui(self):
        """Set up the dashboard UI."""
        mono_font = QFont("Menlo, Monaco, Courier New, monospace")

        layout = QVBoxLayout(self)
        layout.setContentsMargins(30, 30, 30, 30)
        layout.setSpacing(20)

        # Title
        title = QLabel("Dashboard")
        title.setProperty("class", "heading")
        title_font = QFont("Menlo, Monaco, Courier New, monospace", 22)
        title_font.setBold(True)
        title.setFont(title_font)
        title.setStyleSheet("color: #ffffff;")
        layout.addWidget(title)

        # Status indicator
        self._status_indicator = StatusIndicator()
        layout.addWidget(self._status_indicator)

        # Recording controls panel
        controls_panel = QFrame()
        controls_panel.setProperty("class", "panel")
        controls_panel.setStyleSheet(
            "background-color: #0d0d0d; border: 1px solid #2a2a2a; border-radius: 8px; padding: 20px;"
        )
        controls_layout = QVBoxLayout(controls_panel)
        controls_layout.setSpacing(15)

        # Meeting name input
        name_row = QHBoxLayout()
        name_label = QLabel("Meeting name:")
        name_label.setFont(mono_font)
        name_label.setFixedWidth(140)
        self._name_input = QLineEdit()
        self._name_input.setPlaceholderText(generate_meeting_name())
        self._name_input.setFont(mono_font)
        name_row.addWidget(name_label)
        name_row.addWidget(self._name_input)
        controls_layout.addLayout(name_row)

        # Live transcription toggle
        toggle_row = QHBoxLayout()
        toggle_label = QLabel("Live transcription:")
        toggle_label.setFont(mono_font)
        toggle_label.setFixedWidth(140)
        self._live_toggle = QCheckBox("Show live transcript")
        self._live_toggle.setFont(mono_font)
        self._live_toggle.setChecked(True)
        toggle_row.addWidget(toggle_label)
        toggle_row.addWidget(self._live_toggle)
        toggle_row.addStretch()
        controls_layout.addLayout(toggle_row)

        # Buttons
        button_row = QHBoxLayout()
        button_row.setSpacing(12)

        self._start_btn = QPushButton("▶ Start Recording")
        self._start_btn.setProperty("class", "success")
        self._start_btn.setFont(mono_font)
        self._start_btn.setStyleSheet(
            "background-color: #4ec9b0; color: #0d0d0d; min-width: 160px; padding: 12px 24px; font-weight: 600;"
        )

        self._stop_btn = QPushButton("■ Stop")
        self._stop_btn.setProperty("class", "danger")
        self._stop_btn.setFont(mono_font)
        self._stop_btn.setStyleSheet(
            "background-color: #f14c4c; color: #ffffff; min-width: 100px; padding: 12px 24px; font-weight: 600;"
        )

        button_row.addWidget(self._start_btn)
        button_row.addWidget(self._stop_btn)
        button_row.addStretch()
        controls_layout.addLayout(button_row)

        layout.addWidget(controls_panel)

        # Live transcription display
        transcript_label = QLabel("LIVE TRANSCRIPTION")
        transcript_label.setFont(mono_font)
        transcript_label.setStyleSheet("font-size: 11px; font-weight: 600; color: #5a5a5a; letter-spacing: 2px;")
        layout.addWidget(transcript_label)

        self._transcript_display = QTextEdit()
        self._transcript_display.setReadOnly(True)
        self._transcript_display.setPlaceholderText("Waiting for transcription...")
        self._transcript_display.setMinimumHeight(200)
        self._transcript_display.setFont(mono_font)
        self._transcript_display.setStyleSheet(
            "background-color: #0d0d0d; border: 1px solid #2a2a2a; border-radius: 6px; "
            "color: #4ec9b0; padding: 12px; font-size: 13px;"
        )
        layout.addWidget(self._transcript_display, 1)  # Stretch factor

    def _setup_workers(self):
        """Set up background workers."""
        self._transcript_watcher = LiveTranscriptWatcher()
        self._transcript_watcher.new_content.connect(self._on_new_transcript)
        self._transcript_watcher.file_changed.connect(self._on_transcript_file_changed)
        self._transcript_watcher.recording_ended.connect(self._on_recording_ended)
        self._transcript_watcher.start()

    def _connect_signals(self):
        """Connect button signals."""
        self._start_btn.clicked.connect(self._start_recording)
        self._stop_btn.clicked.connect(self._stop_recording)
        self._live_toggle.toggled.connect(self._on_live_toggle)

    def _start_recording(self):
        """Start a new recording."""
        # Check if already recording
        daemon_pid = read_pid_file(DEFAULT_PID_FILE)
        if daemon_pid and is_process_running(daemon_pid):
            self._show_message("Already recording. Stop first.")
            return

        # Get meeting name
        meeting_name = self._name_input.text().strip() or generate_meeting_name()

        # Start recording daemon
        subprocess.Popen(
            [sys.executable, "-m", "meeting_noter.cli", "daemon", "--name", meeting_name],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

        # Clear input and transcript
        self._name_input.clear()
        self._name_input.setPlaceholderText(generate_meeting_name())
        self._transcript_display.clear()
        self._transcript_display.append(f"Starting recording: {meeting_name}\n")

    def _stop_recording(self):
        """Stop recording."""
        daemon_pid = read_pid_file(DEFAULT_PID_FILE)
        watcher_pid = None

        if WATCHER_PID_FILE.exists():
            try:
                watcher_pid = int(WATCHER_PID_FILE.read_text().strip())
            except (ValueError, FileNotFoundError):
                pass

        stopped = []

        # Stop daemon gracefully (wait for transcription to finish)
        if daemon_pid and is_process_running(daemon_pid):
            try:
                os.kill(daemon_pid, signal.SIGTERM)
                stopped.append("recording")
                # Wait for daemon to finish chunked transcription merge
                import time
                for i in range(120):  # Up to 60 seconds
                    time.sleep(0.5)
                    if not is_process_running(daemon_pid):
                        break
            except ProcessLookupError:
                pass

        # Stop watcher
        if watcher_pid:
            try:
                os.kill(watcher_pid, signal.SIGTERM)
                stopped.append("watcher")
            except ProcessLookupError:
                pass
            WATCHER_PID_FILE.unlink(missing_ok=True)

        if not stopped:
            self._show_message("Nothing running")
        else:
            self._show_message(f"Stopped: {', '.join(stopped)}")

    def _on_live_toggle(self, checked: bool):
        """Handle live transcription toggle."""
        if checked:
            self._transcript_watcher.start()
        else:
            self._transcript_watcher.stop()

    def _on_new_transcript(self, text: str):
        """Handle new transcript content."""
        if self._live_toggle.isChecked():
            # Format timestamps in cyan
            lines = text.splitlines()
            for line in lines:
                if line.strip() and line.startswith("["):
                    self._transcript_display.append(line)
            # Auto-scroll to bottom
            scrollbar = self._transcript_display.verticalScrollBar()
            scrollbar.setValue(scrollbar.maximum())

    def _on_transcript_file_changed(self, meeting_name: str):
        """Handle new transcript file."""
        self._transcript_display.clear()
        self._transcript_display.append(f"Transcribing: {meeting_name}\n")

    def _on_recording_ended(self):
        """Handle recording end."""
        self._transcript_display.append("\n--- Recording ended ---")

    def _show_message(self, message: str):
        """Show a message in the transcript area."""
        self._transcript_display.append(f"\n{message}")

    def update_status(self, watcher_running: bool, daemon_running: bool, meeting_name: str):
        """Update status indicator."""
        self._status_indicator.update_status(watcher_running, daemon_running, meeting_name)

        # Update button states
        self._start_btn.setEnabled(not daemon_running)
        self._stop_btn.setEnabled(daemon_running or watcher_running)

    def refresh(self):
        """Refresh the dashboard."""
        # Update placeholder with new timestamp
        self._name_input.setPlaceholderText(generate_meeting_name())

    def stop_workers(self):
        """Stop background workers."""
        if hasattr(self, "_transcript_watcher"):
            self._transcript_watcher.stop()
