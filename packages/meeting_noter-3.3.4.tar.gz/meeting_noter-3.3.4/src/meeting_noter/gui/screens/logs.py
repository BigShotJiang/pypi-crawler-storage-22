"""Logs viewer screen for Meeting Noter GUI."""

from __future__ import annotations

from pathlib import Path

from PySide6.QtGui import QColor, QTextCharFormat, QTextCursor
from PySide6.QtWidgets import (
    QCheckBox,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from meeting_noter.gui.utils.workers import LogWatcher


LOG_FILE = Path.home() / ".meeting-noter.log"


class LogsScreen(QWidget):
    """Screen for viewing application logs."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._setup_ui()
        self._setup_workers()
        self._connect_signals()

    def _setup_ui(self):
        """Set up the logs UI."""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(30, 30, 30, 30)
        layout.setSpacing(20)

        # Title
        title = QLabel("Logs")
        title.setStyleSheet("font-size: 24px; font-weight: 600; color: #ffffff;")
        layout.addWidget(title)

        # Log path
        path_label = QLabel(f"Log file: {LOG_FILE}")
        path_label.setStyleSheet("color: #858585;")
        layout.addWidget(path_label)

        # Log content
        self._log_view = QTextEdit()
        self._log_view.setReadOnly(True)
        self._log_view.setStyleSheet(
            "font-family: 'Menlo', 'Monaco', 'Courier New', monospace; font-size: 12px;"
        )
        layout.addWidget(self._log_view, 1)

        # Controls
        controls_row = QHBoxLayout()
        controls_row.setSpacing(10)

        self._follow_toggle = QCheckBox("Follow")
        self._follow_toggle.setChecked(True)
        controls_row.addWidget(self._follow_toggle)

        self._refresh_btn = QPushButton("Refresh")
        self._refresh_btn.setProperty("class", "secondary")
        self._refresh_btn.setStyleSheet("background-color: #3c3c3c;")
        controls_row.addWidget(self._refresh_btn)

        self._clear_btn = QPushButton("Clear")
        self._clear_btn.setProperty("class", "secondary")
        self._clear_btn.setStyleSheet("background-color: #3c3c3c;")
        controls_row.addWidget(self._clear_btn)

        controls_row.addStretch()
        layout.addLayout(controls_row)

    def _setup_workers(self):
        """Set up background workers."""
        self._log_watcher = LogWatcher()
        self._log_watcher.new_content.connect(self._on_new_content)

    def _connect_signals(self):
        """Connect button signals."""
        self._refresh_btn.clicked.connect(self._refresh_logs)
        self._clear_btn.clicked.connect(self._clear_logs)
        self._follow_toggle.toggled.connect(self._on_follow_toggled)

    def _on_follow_toggled(self, checked: bool):
        """Handle follow toggle."""
        if checked:
            self._log_watcher.start()
        else:
            self._log_watcher.stop()

    def _refresh_logs(self):
        """Refresh log content."""
        self._log_view.clear()
        self._load_logs()

        # Reset watcher position
        if self._follow_toggle.isChecked():
            self._log_watcher.reset()
            if not self._log_watcher.isRunning():
                self._log_watcher.start()

    def _clear_logs(self):
        """Clear the log display."""
        self._log_view.clear()

    def _load_logs(self):
        """Load the last 100 lines from the log file."""
        if not LOG_FILE.exists():
            self._log_view.setPlainText("No log file found.")
            return

        try:
            with open(LOG_FILE, "r") as f:
                lines = f.readlines()[-100:]

            for line in lines:
                self._append_colored_line(line.rstrip())

            # Scroll to bottom
            scrollbar = self._log_view.verticalScrollBar()
            scrollbar.setValue(scrollbar.maximum())

        except Exception as e:
            self._log_view.setPlainText(f"Error reading log file: {e}")

    def _on_new_content(self, content: str):
        """Handle new log content."""
        if not self._follow_toggle.isChecked():
            return

        for line in content.splitlines():
            if line.strip():
                self._append_colored_line(line)

        # Auto-scroll if following
        scrollbar = self._log_view.verticalScrollBar()
        scrollbar.setValue(scrollbar.maximum())

    def _append_colored_line(self, line: str):
        """Append a line with appropriate color."""
        cursor = self._log_view.textCursor()
        cursor.movePosition(QTextCursor.MoveOperation.End)

        fmt = QTextCharFormat()

        # Color based on content
        line_lower = line.lower()
        if "error" in line_lower:
            fmt.setForeground(QColor("#f14c4c"))  # Red
        elif "warning" in line_lower:
            fmt.setForeground(QColor("#dcdcaa"))  # Yellow
        elif "recording started" in line_lower:
            fmt.setForeground(QColor("#4ec9b0"))  # Green
        elif "recording saved" in line_lower or "transcription" in line_lower:
            fmt.setForeground(QColor("#9cdcfe"))  # Cyan
        else:
            fmt.setForeground(QColor("#cccccc"))  # Default gray

        cursor.insertText(line + "\n", fmt)

    def refresh(self):
        """Refresh the logs view."""
        self._refresh_logs()

    def stop_workers(self):
        """Stop background workers."""
        if hasattr(self, "_log_watcher"):
            self._log_watcher.stop()

    def showEvent(self, event):
        """Handle show event."""
        super().showEvent(event)
        self._refresh_logs()

    def hideEvent(self, event):
        """Handle hide event."""
        super().hideEvent(event)
        if hasattr(self, "_log_watcher") and self._log_watcher.isRunning():
            self._log_watcher.stop()
