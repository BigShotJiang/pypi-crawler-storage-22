"""Meetings calendar screen for Meeting Noter GUI."""

from __future__ import annotations

from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

from PySide6.QtCore import Qt, QDate, Signal
from PySide6.QtGui import QFont
from PySide6.QtWidgets import (
    QButtonGroup,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QVBoxLayout,
    QWidget,
)

from meeting_noter.config import get_config
from meeting_noter.gui.utils.signals import get_app_state


class MeetingEvent:
    """Represents a meeting event."""

    def __init__(
        self,
        title: str,
        start: datetime,
        end: Optional[datetime] = None,
        is_past: bool = True,
        filepath: Optional[Path] = None,
    ):
        self.title = title
        self.start = start
        self.end = end or (start + timedelta(hours=1))
        self.is_past = is_past  # Past = from recordings, Future = from calendar
        self.filepath = filepath  # Path to recording if past meeting


class ViewToggleButton(QPushButton):
    """Toggle button for view selection."""

    def __init__(self, text: str, parent=None):
        super().__init__(text, parent)
        self.setCheckable(True)
        self.setMinimumHeight(32)
        self.setMinimumWidth(80)
        self.setCursor(Qt.PointingHandCursor)


class DayCell(QFrame):
    """A cell representing a day in the calendar."""

    clicked = Signal(QDate)

    def __init__(self, date: QDate, is_current_month: bool = True, parent=None):
        super().__init__(parent)
        self.date = date
        self.is_current_month = is_current_month
        self._events: list[MeetingEvent] = []
        self._setup_ui()

    def _setup_ui(self):
        self.setMinimumHeight(100)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.setCursor(Qt.PointingHandCursor)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(5, 5, 5, 5)
        layout.setSpacing(2)

        # Day number
        day_num = self.date.day()
        is_today = self.date == QDate.currentDate()

        self._day_label = QLabel(str(day_num))
        self._day_label.setAlignment(Qt.AlignRight)

        if is_today:
            self._day_label.setStyleSheet(
                "background-color: #0e639c; color: white; border-radius: 12px; "
                "padding: 2px 6px; font-weight: bold;"
            )
        elif not self.is_current_month:
            self._day_label.setStyleSheet("color: #5a5a5a;")
        else:
            self._day_label.setStyleSheet("color: #cccccc; font-weight: 500;")

        layout.addWidget(self._day_label, alignment=Qt.AlignRight)

        # Events container
        self._events_container = QVBoxLayout()
        self._events_container.setSpacing(2)
        layout.addLayout(self._events_container)
        layout.addStretch()

        # Style
        if self.is_current_month:
            self.setStyleSheet(
                "DayCell { background-color: #2d2d2d; border: 1px solid #3c3c3c; }"
                "DayCell:hover { background-color: #363636; }"
            )
        else:
            self.setStyleSheet(
                "DayCell { background-color: #252525; border: 1px solid #333333; }"
            )

    def add_event(self, event: MeetingEvent):
        """Add an event to this day cell."""
        self._events.append(event)

        # Create event label
        event_label = QLabel(event.title[:20] + ("..." if len(event.title) > 20 else ""))
        event_label.setWordWrap(False)

        if event.is_past:
            # Past meeting (from recording) - green
            event_label.setStyleSheet(
                "background-color: #1e3a1e; color: #4ec9b0; border-radius: 3px; "
                "padding: 2px 4px; font-size: 10px;"
            )
        else:
            # Future meeting (from calendar) - blue
            event_label.setStyleSheet(
                "background-color: #1e3a5a; color: #6cb6ff; border-radius: 3px; "
                "padding: 2px 4px; font-size: 10px;"
            )

        self._events_container.addWidget(event_label)

    def mousePressEvent(self, event):
        self.clicked.emit(self.date)
        super().mousePressEvent(event)


class MeetingsScreen(QWidget):
    """Screen showing calendar view of meetings."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._current_date = QDate.currentDate()
        # Load saved view mode from config
        config = get_config()
        self._view_mode = config.meetings_view_mode
        self._events: list[MeetingEvent] = []
        self._setup_ui()
        self._load_events()
        self._apply_saved_view_mode()

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(30, 30, 30, 30)
        layout.setSpacing(20)

        # Header row
        header_layout = QHBoxLayout()

        # Title
        title = QLabel("Meetings")
        title.setStyleSheet("font-size: 24px; font-weight: 600; color: #ffffff;")
        header_layout.addWidget(title)

        header_layout.addStretch()

        # View toggle buttons
        self._view_group = QButtonGroup(self)
        self._view_group.setExclusive(True)

        self._day_btn = ViewToggleButton("Day")
        self._week_btn = ViewToggleButton("Week")
        self._month_btn = ViewToggleButton("Month")

        for btn in [self._day_btn, self._week_btn, self._month_btn]:
            btn.setStyleSheet("""
                QPushButton {
                    background-color: #3c3c3c;
                    border: none;
                    border-radius: 4px;
                    padding: 6px 16px;
                    color: #cccccc;
                }
                QPushButton:checked {
                    background-color: #0e639c;
                    color: white;
                }
                QPushButton:hover:!checked {
                    background-color: #4a4a4a;
                }
            """)
            self._view_group.addButton(btn)
            header_layout.addWidget(btn)

        self._month_btn.setChecked(True)

        layout.addLayout(header_layout)

        # Navigation row
        nav_layout = QHBoxLayout()

        self._prev_btn = QPushButton("◀")
        self._prev_btn.setFixedSize(36, 36)
        self._prev_btn.setCursor(Qt.PointingHandCursor)
        self._prev_btn.setStyleSheet("""
            QPushButton {
                background-color: #3c3c3c;
                border: none;
                border-radius: 4px;
                font-size: 14px;
                color: #cccccc;
            }
            QPushButton:hover { background-color: #4a4a4a; }
        """)
        nav_layout.addWidget(self._prev_btn)

        self._date_label = QLabel()
        self._date_label.setStyleSheet("font-size: 18px; font-weight: 500; color: #ffffff;")
        self._date_label.setAlignment(Qt.AlignCenter)
        nav_layout.addWidget(self._date_label, 1)

        self._next_btn = QPushButton("▶")
        self._next_btn.setFixedSize(36, 36)
        self._next_btn.setCursor(Qt.PointingHandCursor)
        self._next_btn.setStyleSheet(self._prev_btn.styleSheet())
        nav_layout.addWidget(self._next_btn)

        self._today_btn = QPushButton("Today")
        self._today_btn.setCursor(Qt.PointingHandCursor)
        self._today_btn.setStyleSheet("""
            QPushButton {
                background-color: #3c3c3c;
                border: none;
                border-radius: 4px;
                padding: 8px 16px;
                color: #cccccc;
            }
            QPushButton:hover { background-color: #4a4a4a; }
        """)
        nav_layout.addWidget(self._today_btn)

        layout.addLayout(nav_layout)

        # Calendar content area (scrollable)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet("QScrollArea { border: none; background-color: transparent; }")

        self._calendar_container = QWidget()
        self._calendar_layout = QVBoxLayout(self._calendar_container)
        self._calendar_layout.setContentsMargins(0, 0, 0, 0)
        scroll.setWidget(self._calendar_container)

        layout.addWidget(scroll, 1)

        # Connect signals
        self._prev_btn.clicked.connect(self._go_previous)
        self._next_btn.clicked.connect(self._go_next)
        self._today_btn.clicked.connect(self._go_today)
        self._day_btn.clicked.connect(lambda: self._set_view_mode("day"))
        self._week_btn.clicked.connect(lambda: self._set_view_mode("week"))
        self._month_btn.clicked.connect(lambda: self._set_view_mode("month"))

        # Initial render
        self._update_view()

    def _set_view_mode(self, mode: str):
        self._view_mode = mode
        # Save preference
        config = get_config()
        config.meetings_view_mode = mode
        config.save()
        self._update_view()

    def _apply_saved_view_mode(self):
        """Apply the saved view mode by checking the correct button."""
        if self._view_mode == "day":
            self._day_btn.setChecked(True)
        elif self._view_mode == "week":
            self._week_btn.setChecked(True)
        else:
            self._month_btn.setChecked(True)

    def _go_previous(self):
        if self._view_mode == "day":
            self._current_date = self._current_date.addDays(-1)
        elif self._view_mode == "week":
            self._current_date = self._current_date.addDays(-7)
        else:
            self._current_date = self._current_date.addMonths(-1)
        self._update_view()

    def _go_next(self):
        if self._view_mode == "day":
            self._current_date = self._current_date.addDays(1)
        elif self._view_mode == "week":
            self._current_date = self._current_date.addDays(7)
        else:
            self._current_date = self._current_date.addMonths(1)
        self._update_view()

    def _go_today(self):
        self._current_date = QDate.currentDate()
        self._update_view()

    def _update_view(self):
        """Update the calendar view based on current mode and date."""
        # Update date label
        if self._view_mode == "day":
            self._date_label.setText(self._current_date.toString("dddd, MMMM d, yyyy"))
        elif self._view_mode == "week":
            # Get start of week (Sunday)
            start = self._current_date.addDays(-(self._current_date.dayOfWeek() % 7))
            end = start.addDays(6)
            self._date_label.setText(f"{start.toString('MMM d')} - {end.toString('MMM d, yyyy')}")
        else:
            self._date_label.setText(self._current_date.toString("MMMM yyyy"))

        # Clear current calendar
        while self._calendar_layout.count():
            item = self._calendar_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        # Render appropriate view
        if self._view_mode == "day":
            self._render_day_view()
        elif self._view_mode == "week":
            self._render_week_view()
        else:
            self._render_month_view()

    def _render_month_view(self):
        """Render the month view calendar."""
        container = QWidget()
        layout = QVBoxLayout(container)
        layout.setSpacing(0)
        layout.setContentsMargins(0, 0, 0, 0)

        # Day headers
        header_layout = QHBoxLayout()
        header_layout.setSpacing(0)
        days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]
        for day in days:
            lbl = QLabel(day)
            lbl.setAlignment(Qt.AlignCenter)
            lbl.setStyleSheet(
                "background-color: #252525; color: #858585; padding: 10px; "
                "font-weight: 600; font-size: 12px;"
            )
            lbl.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
            header_layout.addWidget(lbl)
        layout.addLayout(header_layout)

        # Get first day of month and calculate grid
        first_of_month = QDate(self._current_date.year(), self._current_date.month(), 1)
        days_in_month = first_of_month.daysInMonth()
        start_day = first_of_month.dayOfWeek()  # 1=Mon, 7=Sun

        # Create grid
        grid = QGridLayout()
        grid.setSpacing(0)

        row = 0
        col = start_day % 7  # Adjust for Sunday start (Sun=0, Mon=1, ..., Sat=6)

        # Previous month days
        if col > 0:
            prev_month = first_of_month.addDays(-col)
            for i in range(col):
                date = prev_month.addDays(i)
                cell = DayCell(date, is_current_month=False)
                self._add_events_to_cell(cell, date)
                grid.addWidget(cell, row, i)

        # Current month days
        for day in range(1, days_in_month + 1):
            date = QDate(self._current_date.year(), self._current_date.month(), day)
            cell = DayCell(date, is_current_month=True)
            self._add_events_to_cell(cell, date)
            cell.clicked.connect(self._on_day_clicked)
            grid.addWidget(cell, row, col)

            col += 1
            if col > 6:
                col = 0
                row += 1

        # Next month days
        if col > 0:
            next_month = QDate(self._current_date.year(), self._current_date.month(), days_in_month).addDays(1)
            for i in range(7 - col):
                date = next_month.addDays(i)
                cell = DayCell(date, is_current_month=False)
                self._add_events_to_cell(cell, date)
                grid.addWidget(cell, row, col + i)

        layout.addLayout(grid)
        self._calendar_layout.addWidget(container)

    def _render_week_view(self):
        """Render the week view calendar with hourly time slots like Zoom."""
        container = QWidget()
        layout = QVBoxLayout(container)
        layout.setSpacing(0)
        layout.setContentsMargins(0, 0, 0, 0)

        # Get start of week (Sunday)
        start_of_week = self._current_date.addDays(-(self._current_date.dayOfWeek() % 7))

        # Day headers with dates
        header_layout = QHBoxLayout()
        header_layout.setSpacing(0)

        # Empty cell for time column
        time_header = QLabel("")
        time_header.setFixedWidth(60)
        time_header.setStyleSheet("background-color: #252525;")
        header_layout.addWidget(time_header)

        days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]
        for i, day in enumerate(days):
            date = start_of_week.addDays(i)
            is_today = date == QDate.currentDate()

            lbl = QLabel(f"{day}\n{date.day()}")
            lbl.setAlignment(Qt.AlignCenter)

            if is_today:
                lbl.setStyleSheet(
                    "background-color: #0e639c; color: white; padding: 10px; "
                    "font-weight: 600; font-size: 12px;"
                )
            else:
                lbl.setStyleSheet(
                    "background-color: #252525; color: #858585; padding: 10px; "
                    "font-weight: 600; font-size: 12px;"
                )
            lbl.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
            header_layout.addWidget(lbl)

        layout.addLayout(header_layout)

        # Constants for time grid
        HOUR_HEIGHT = 60  # pixels per hour
        START_HOUR = 6    # 6:00 AM
        END_HOUR = 23     # 11:00 PM

        # Time grid container with relative positioning
        grid_widget = QWidget()
        grid_layout = QHBoxLayout(grid_widget)
        grid_layout.setSpacing(0)
        grid_layout.setContentsMargins(0, 0, 0, 0)

        # Time labels column
        time_col = QWidget()
        time_col.setFixedWidth(60)
        time_col_layout = QVBoxLayout(time_col)
        time_col_layout.setSpacing(0)
        time_col_layout.setContentsMargins(0, 0, 0, 0)

        for hour in range(START_HOUR, END_HOUR + 1):
            time_lbl = QLabel(f"{hour:02d}:00")
            time_lbl.setFixedHeight(HOUR_HEIGHT)
            time_lbl.setAlignment(Qt.AlignRight | Qt.AlignTop)
            time_lbl.setStyleSheet(
                "color: #858585; font-size: 11px; padding-right: 8px; padding-top: 2px; "
                "background-color: #1e1e1e;"
            )
            time_col_layout.addWidget(time_lbl)

        grid_layout.addWidget(time_col)

        # Day columns
        for day_idx in range(7):
            date = start_of_week.addDays(day_idx)
            day_events = self._get_events_for_date(date)

            # Day column with stacked layout for positioning events
            day_col = QWidget()
            day_col.setStyleSheet("background-color: transparent; border-left: 1px solid #3c3c3c;")
            day_col.setMinimumHeight(HOUR_HEIGHT * (END_HOUR - START_HOUR + 1))

            # Draw hour lines
            for hour in range(START_HOUR, END_HOUR + 1):
                hour_line = QFrame(day_col)
                hour_line.setGeometry(0, (hour - START_HOUR) * HOUR_HEIGHT, 2000, 1)
                hour_line.setStyleSheet("background-color: #333333;")

            # Calculate columns for overlapping events
            event_columns = self._assign_event_columns(day_events, START_HOUR, END_HOUR)

            # Add events with proper positioning
            for event, col_idx, total_cols in event_columns:
                event_start_hour = event.start.hour + event.start.minute / 60.0
                event_end_hour = (event.end.hour + event.end.minute / 60.0) if event.end else event_start_hour + 0.5

                visible_start = max(event_start_hour, START_HOUR)
                visible_end = min(event_end_hour, END_HOUR + 1)

                top = int((visible_start - START_HOUR) * HOUR_HEIGHT)
                height = max(int((visible_end - visible_start) * HOUR_HEIGHT) - 2, 22)

                # Calculate width and left position based on column
                # Use percentage-based positioning (day_col width will be ~140px typically)
                col_width_pct = 100 // total_cols
                left_pct = col_idx * col_width_pct

                # Create event widget
                title_text = event.title[:15] + ("..." if len(event.title) > 15 else "")
                event_widget = QLabel(title_text, day_col)
                # Position with fixed pixel estimate (will be roughly correct)
                event_width = max(60, 140 // total_cols - 4)
                event_left = 2 + col_idx * (140 // total_cols)
                event_widget.setGeometry(event_left, top + 1, event_width, height)
                event_widget.setWordWrap(True)
                event_widget.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)

                has_transcript = self._get_transcript_path(event) is not None

                if event.is_past:
                    if has_transcript:
                        event_widget.setCursor(Qt.PointingHandCursor)
                        event_widget.setStyleSheet(
                            "QLabel { background-color: #234d23; border-left: 3px solid #4ec9b0; "
                            "border-radius: 2px; color: #4ec9b0; font-size: 10px; font-weight: 500; "
                            "padding-left: 4px; }"
                            "QLabel:hover { background-color: #2a5a2a; }"
                        )
                        event_widget.mousePressEvent = lambda e, ev=event: self._on_event_clicked(ev)
                    else:
                        event_widget.setStyleSheet(
                            "QLabel { background-color: #2a2a2a; border-left: 3px solid #666666; "
                            "border-radius: 2px; color: #858585; font-size: 10px; font-weight: 500; "
                            "padding-left: 4px; }"
                        )
                else:
                    event_widget.setStyleSheet(
                        "QLabel { background-color: #1e3a5a; border-left: 3px solid #6cb6ff; "
                        "border-radius: 2px; color: #6cb6ff; font-size: 10px; font-weight: 500; "
                        "padding-left: 4px; }"
                    )

            day_col.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
            grid_layout.addWidget(day_col)

        layout.addWidget(grid_widget)
        self._calendar_layout.addWidget(container)

    def _render_day_view(self):
        """Render the day view."""
        container = QWidget()
        layout = QVBoxLayout(container)
        layout.setSpacing(10)
        layout.setContentsMargins(0, 0, 0, 0)

        # Date header
        is_today = self._current_date == QDate.currentDate()
        date_str = self._current_date.toString("dddd, MMMM d, yyyy")
        if is_today:
            date_str += " (Today)"

        # Get events for this day
        events = self._get_events_for_date(self._current_date)

        if not events:
            no_events = QLabel("No meetings scheduled for this day")
            no_events.setStyleSheet("color: #858585; font-size: 14px; padding: 40px;")
            no_events.setAlignment(Qt.AlignCenter)
            layout.addWidget(no_events)
        else:
            for event in sorted(events, key=lambda e: e.start):
                has_transcript = self._get_transcript_path(event) is not None

                event_frame = QFrame()
                if has_transcript:
                    event_frame.setCursor(Qt.PointingHandCursor)
                    event_frame.setStyleSheet(
                        "QFrame { background-color: #2d2d2d; border: 1px solid #3c3c3c; "
                        "border-radius: 8px; }"
                        "QFrame:hover { background-color: #363636; border-color: #0e639c; }"
                    )
                else:
                    event_frame.setStyleSheet(
                        "QFrame { background-color: #2d2d2d; border: 1px solid #3c3c3c; "
                        "border-radius: 8px; }"
                    )

                event_layout = QHBoxLayout(event_frame)
                event_layout.setContentsMargins(15, 15, 15, 15)

                # Time
                time_str = event.start.strftime("%H:%M")
                if event.end:
                    time_str += f" - {event.end.strftime('%H:%M')}"

                time_label = QLabel(time_str)
                time_label.setStyleSheet("color: #858585; font-size: 13px; min-width: 100px;")
                event_layout.addWidget(time_label)

                # Title
                title_label = QLabel(event.title)
                title_label.setStyleSheet("color: #ffffff; font-size: 14px; font-weight: 500;")
                event_layout.addWidget(title_label, 1)

                # Type indicator and transcript status
                if event.is_past:
                    if has_transcript:
                        type_label = QLabel("● Transcript")
                        type_label.setStyleSheet("color: #4ec9b0; font-size: 11px;")
                    else:
                        type_label = QLabel("● Recording")
                        type_label.setStyleSheet("color: #858585; font-size: 11px;")
                else:
                    type_label = QLabel("● Scheduled")
                    type_label.setStyleSheet("color: #6cb6ff; font-size: 11px;")
                event_layout.addWidget(type_label)

                # Make the frame clickable if it has a transcript
                if has_transcript:
                    # Store event reference and connect click
                    event_frame.mousePressEvent = lambda e, ev=event: self._on_event_clicked(ev)

                layout.addWidget(event_frame)

        layout.addStretch()
        self._calendar_layout.addWidget(container)

    def _on_day_clicked(self, date: QDate):
        """Handle day cell click - switch to day view."""
        self._current_date = date
        self._view_mode = "day"
        self._day_btn.setChecked(True)
        self._update_view()

    def _get_transcript_path(self, event: MeetingEvent) -> Optional[Path]:
        """Get the transcript path for an event if it exists."""
        if not event.filepath:
            return None

        config = get_config()
        transcript_name = event.filepath.stem + ".txt"
        transcript_path = config.transcripts_dir / transcript_name

        if transcript_path.exists():
            return transcript_path
        return None

    def _on_event_clicked(self, event: MeetingEvent):
        """Handle event click - open transcript if available."""
        transcript_path = self._get_transcript_path(event)
        if transcript_path:
            app_state = get_app_state()
            app_state.open_transcript.emit(str(transcript_path))

    def _add_events_to_cell(self, cell: DayCell, date: QDate):
        """Add events to a day cell."""
        events = self._get_events_for_date(date)
        for event in events[:3]:  # Limit to 3 events per cell
            cell.add_event(event)
        if len(events) > 3:
            # Show "+N more" indicator
            pass

    def _get_events_for_date(self, date: QDate) -> list[MeetingEvent]:
        """Get events for a specific date."""
        target = datetime(date.year(), date.month(), date.day())
        return [
            e for e in self._events
            if e.start.year == target.year
            and e.start.month == target.month
            and e.start.day == target.day
        ]

    def _assign_event_columns(
        self, events: list[MeetingEvent], start_hour: int, end_hour: int
    ) -> list[tuple[MeetingEvent, int, int]]:
        """Assign columns to events for side-by-side display of overlapping events.

        Returns list of (event, column_index, total_columns) tuples.
        """
        if not events:
            return []

        # Filter to visible events and sort by start time
        visible_events = []
        for event in events:
            event_start = event.start.hour + event.start.minute / 60.0
            event_end = (event.end.hour + event.end.minute / 60.0) if event.end else event_start + 0.5
            if event_end >= start_hour and event_start <= end_hour:
                visible_events.append((event, event_start, event_end))

        if not visible_events:
            return []

        visible_events.sort(key=lambda x: (x[1], x[2]))  # Sort by start, then end

        # Assign columns - find first column where event doesn't overlap
        # columns[i] = end time of last event in column i
        columns: list[float] = []
        event_assignments: list[tuple[MeetingEvent, int, float, float]] = []

        for event, start, end in visible_events:
            # Find first column where this event fits (no overlap)
            assigned_col = -1
            for col_idx, col_end in enumerate(columns):
                if start >= col_end:  # No overlap
                    assigned_col = col_idx
                    columns[col_idx] = end
                    break

            if assigned_col == -1:
                # Need new column
                assigned_col = len(columns)
                columns.append(end)

            event_assignments.append((event, assigned_col, start, end))

        # Find groups of overlapping events and their max columns
        # For each event, find all events it overlaps with and get max column count
        result = []
        for event, col_idx, start, end in event_assignments:
            # Count how many columns are needed for this time range
            max_col = col_idx
            for other_event, other_col, other_start, other_end in event_assignments:
                # Check if they overlap
                if other_start < end and other_end > start:
                    max_col = max(max_col, other_col)
            total_cols = max_col + 1
            result.append((event, col_idx, total_cols))

        return result

    def _load_events(self):
        """Load events from recordings."""
        self._events = []
        self._load_past_meetings()

    def _load_past_meetings(self):
        """Load past meetings from recordings directory."""
        config = get_config()
        recordings_dir = config.recordings_dir

        if not recordings_dir.exists():
            return

        for mp3_file in recordings_dir.glob("*.mp3"):
            # Parse filename to get date and name
            # Format: YYYY-MM-DD_HHMMSS_Name.mp3 or DD_Mon_YYYY_HHMM.mp3
            name = mp3_file.stem
            parts = name.split("_", 2)

            try:
                if len(parts) >= 2 and "-" in parts[0]:
                    # Format: 2026-02-02_143000_Meeting_Name
                    date_str = parts[0]
                    time_str = parts[1]
                    meeting_name = parts[2].replace("_", " ") if len(parts) > 2 else "Meeting"

                    dt = datetime.strptime(f"{date_str}_{time_str}", "%Y-%m-%d_%H%M%S")
                else:
                    # Format: 02_Feb_2026_1430
                    dt = datetime.strptime(name[:15], "%d_%b_%Y_%H%M")
                    meeting_name = name

                # Get actual duration from MP3 file
                duration_minutes = self._get_mp3_duration(mp3_file)
                end_dt = dt + timedelta(minutes=duration_minutes)

                self._events.append(MeetingEvent(
                    title=meeting_name,
                    start=dt,
                    end=end_dt,
                    is_past=True,
                    filepath=mp3_file,
                ))
            except (ValueError, IndexError):
                # Couldn't parse filename, skip
                continue

    def _get_mp3_duration(self, filepath: Path) -> float:
        """Estimate MP3 duration in minutes from file size.

        Uses file size to estimate duration (assumes ~128kbps average bitrate).
        This is fast and good enough for calendar display purposes.
        """
        try:
            size_bytes = filepath.stat().st_size
            # 128kbps = 16KB/s = 960KB/min
            duration_minutes = size_bytes / (960 * 1024)
            return max(duration_minutes, 5)  # Minimum 5 minutes for visibility
        except Exception:
            return 30  # Default 30 minutes

    def refresh(self):
        """Refresh the meetings view."""
        self._load_events()
        self._update_view()
