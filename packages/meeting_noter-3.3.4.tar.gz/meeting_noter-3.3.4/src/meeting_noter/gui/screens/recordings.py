"""Recordings browser screen for Meeting Noter GUI."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Optional

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QAbstractItemView,
    QHBoxLayout,
    QHeaderView,
    QInputDialog,
    QLabel,
    QMessageBox,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from meeting_noter.config import get_config
from meeting_noter.gui.utils.signals import get_app_state
from meeting_noter.gui.utils.workers import TranscriptionWorker
from meeting_noter.output.writer import format_duration, format_size, get_audio_duration, extract_meeting_name


@dataclass
class RecordingInfo:
    """Information about a recording."""

    filepath: Path
    date: datetime
    duration: Optional[float]
    size: int
    has_transcript: bool
    is_favorite: bool
    tags: list[str]


class RecordingsScreen(QWidget):
    """Screen for browsing and managing recordings."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._recordings: list[RecordingInfo] = []
        self._transcribing: dict[Path, TranscriptionWorker] = {}
        self._setup_ui()
        self._connect_signals()

    def _setup_ui(self):
        """Set up the recordings UI."""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(30, 30, 30, 30)
        layout.setSpacing(20)

        # Title
        title = QLabel("Recordings")
        title.setStyleSheet("font-size: 24px; font-weight: 600; color: #ffffff;")
        layout.addWidget(title)

        # Table
        # Columns: ★, Name, Tags, Duration, Date
        self._table = QTableWidget()
        self._table.setColumnCount(5)
        self._table.setHorizontalHeaderLabels(
            ["\u2605", "Name", "Tags", "Duration", "Date"]
        )
        self._table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self._table.setSelectionMode(QAbstractItemView.SingleSelection)
        self._table.setAlternatingRowColors(False)  # We'll handle row colors manually
        self._table.setSortingEnabled(True)
        self._table.verticalHeader().setVisible(False)
        self._table.setEditTriggers(QAbstractItemView.NoEditTriggers)  # Disable built-in editing

        # Column widths - all auto-size except Tags which can stretch for remaining space
        header = self._table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.Fixed)  # ★
        header.resizeSection(0, 40)
        header.setSectionResizeMode(1, QHeaderView.ResizeToContents)  # Name
        header.setSectionResizeMode(2, QHeaderView.Stretch)  # Tags gets remaining space
        header.setSectionResizeMode(3, QHeaderView.ResizeToContents)  # Duration
        header.setSectionResizeMode(4, QHeaderView.ResizeToContents)  # Date

        self._table.doubleClicked.connect(self._on_cell_double_clicked)
        self._table.cellClicked.connect(self._on_cell_clicked)
        layout.addWidget(self._table, 1)

        # Action buttons (simplified - most actions are now inline)
        button_row = QHBoxLayout()
        button_row.setSpacing(10)

        self._view_btn = QPushButton("View Transcript")
        self._transcribe_btn = QPushButton("Transcribe")
        self._refresh_btn = QPushButton("Refresh")
        self._refresh_btn.setProperty("class", "secondary")
        self._refresh_btn.setStyleSheet("background-color: #3c3c3c;")

        button_row.addWidget(self._view_btn)
        button_row.addWidget(self._transcribe_btn)
        button_row.addStretch()

        # Hint label
        hint_label = QLabel("Click \u2605 to favorite | Double-click Name or Tags to edit | Red = no transcript")
        hint_label.setStyleSheet("color: #666666; font-size: 11px;")
        button_row.addWidget(hint_label)

        button_row.addWidget(self._refresh_btn)
        layout.addLayout(button_row)

        # Status label
        self._status_label = QLabel("")
        self._status_label.setStyleSheet("color: #858585;")
        layout.addWidget(self._status_label)

    def _connect_signals(self):
        """Connect button signals."""
        self._view_btn.clicked.connect(self._view_transcript)
        self._transcribe_btn.clicked.connect(self._transcribe_selected)
        self._refresh_btn.clicked.connect(self.refresh)

    def refresh(self):
        """Refresh the recordings list."""
        self._load_recordings()
        self._populate_table()

    def _load_recordings(self):
        """Load recordings from disk."""
        config = get_config()
        recordings_dir = config.recordings_dir

        if not recordings_dir.exists():
            self._recordings = []
            return

        recordings = []
        mp3_files = sorted(
            recordings_dir.glob("*.mp3"),
            key=lambda p: p.stat().st_mtime,
            reverse=True,
        )[:50]  # Limit to 50

        for mp3_path in mp3_files:
            try:
                stat = mp3_path.stat()
                size = stat.st_size

                # Parse date from filename (YYYY-MM-DD_HHMMSS_Name.mp3)
                # Fall back to modification time if parsing fails
                date = None
                name = mp3_path.stem
                parts = name.split("_", 2)
                if len(parts) >= 2 and "-" in parts[0]:
                    try:
                        date = datetime.strptime(f"{parts[0]}_{parts[1]}", "%Y-%m-%d_%H%M%S")
                    except ValueError:
                        pass
                if date is None:
                    date = datetime.fromtimestamp(stat.st_mtime)

                # Check for transcript
                transcript_name = mp3_path.stem + ".txt"
                transcript_path = config.transcripts_dir / transcript_name
                has_transcript = transcript_path.exists()

                # Get duration
                try:
                    duration = get_audio_duration(mp3_path)
                except Exception:
                    duration = None

                # Check favorite status
                is_favorite = config.is_favorite(mp3_path.name)

                # Get tags
                file_tags = config.get_tags(mp3_path.name)

                recordings.append(
                    RecordingInfo(
                        filepath=mp3_path,
                        date=date,
                        duration=duration,
                        size=size,
                        has_transcript=has_transcript,
                        is_favorite=is_favorite,
                        tags=file_tags,
                    )
                )
            except Exception:
                continue

        self._recordings = recordings

    def _populate_table(self):
        """Populate the table with recordings."""
        self._table.setRowCount(len(self._recordings))

        from PySide6.QtGui import QColor, QBrush

        for row, rec in enumerate(self._recordings):
            # Determine row background color based on transcript status
            if rec.filepath in self._transcribing:
                row_bg = QColor("#3d3d00")  # Yellow tint for processing
            elif not rec.has_transcript:
                row_bg = QColor("#2d2020")  # Red tint for no transcript
            else:
                row_bg = None  # Default background

            # Column 0: Favorite star (clickable)
            star_item = QTableWidgetItem("\u2605" if rec.is_favorite else "\u2606")
            star_item.setTextAlignment(Qt.AlignCenter)
            star_item.setData(Qt.UserRole, rec.filepath)
            if rec.is_favorite:
                star_item.setForeground(Qt.yellow)
            else:
                star_item.setForeground(Qt.gray)
            if row_bg:
                star_item.setBackground(QBrush(row_bg))
            self._table.setItem(row, 0, star_item)

            # Column 1: Name (double-click to rename)
            clean_name = extract_meeting_name(rec.filepath.name)
            name_item = QTableWidgetItem(clean_name)
            name_item.setToolTip(rec.filepath.name)  # Show full filename on hover
            if row_bg:
                name_item.setBackground(QBrush(row_bg))
            self._table.setItem(row, 1, name_item)

            # Column 2: Tags (double-click to edit)
            tags_str = ", ".join(rec.tags) if rec.tags else ""
            tags_item = QTableWidgetItem(tags_str)
            if rec.tags:
                tags_item.setForeground(Qt.cyan)
            else:
                tags_item.setForeground(Qt.gray)
            if row_bg:
                tags_item.setBackground(QBrush(row_bg))
            self._table.setItem(row, 2, tags_item)

            # Column 3: Duration
            if rec.duration:
                duration_str = format_duration(rec.duration)
            else:
                duration_str = "?"
            duration_item = QTableWidgetItem(duration_str)
            duration_item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            if row_bg:
                duration_item.setBackground(QBrush(row_bg))
            self._table.setItem(row, 3, duration_item)

            # Column 4: Date
            date_item = QTableWidgetItem(rec.date.strftime("%Y-%m-%d %H:%M"))
            date_item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            if row_bg:
                date_item.setBackground(QBrush(row_bg))
            self._table.setItem(row, 4, date_item)

        self._status_label.setText(f"{len(self._recordings)} recordings")

    def _get_selected_recording(self) -> Optional[RecordingInfo]:
        """Get the currently selected recording."""
        row = self._table.currentRow()
        if 0 <= row < len(self._recordings):
            return self._recordings[row]
        return None

    def _view_transcript(self):
        """View the transcript for the selected recording."""
        rec = self._get_selected_recording()
        if not rec:
            return

        if not rec.has_transcript:
            self._status_label.setText("No transcript available. Transcribe first.")
            return

        config = get_config()
        transcript_path = config.transcripts_dir / (rec.filepath.stem + ".txt")

        if transcript_path.exists():
            app_state = get_app_state()
            app_state.open_transcript.emit(str(transcript_path))

    def _on_cell_clicked(self, row: int, column: int):
        """Handle single click on a cell."""
        # Column 0 = Favorite star - toggle on single click
        if column == 0:
            self._toggle_favorite_for_row(row)

    def _on_cell_double_clicked(self, index):
        """Handle double-click on a cell."""
        row = index.row()
        column = index.column()

        if column == 1:
            # Name column - rename
            self._rename_for_row(row)
        elif column == 2:
            # Tags column - edit tags
            self._manage_tags_for_row(row)
        else:
            # Other columns - view transcript
            self._view_transcript()

    def _toggle_favorite_for_row(self, row: int):
        """Toggle favorite for a specific row."""
        if not (0 <= row < len(self._recordings)):
            return

        rec = self._recordings[row]
        config = get_config()

        if rec.is_favorite:
            config.remove_favorite(rec.filepath.name)
            self._status_label.setText(f"Removed from favorites")
        else:
            config.add_favorite(rec.filepath.name)
            self._status_label.setText(f"Added to favorites")

        self.refresh()

    def _rename_for_row(self, row: int):
        """Rename recording for a specific row."""
        if not (0 <= row < len(self._recordings)):
            return

        # Temporarily select this row
        self._table.selectRow(row)
        self._rename_selected()

    def _manage_tags_for_row(self, row: int):
        """Manage tags for a specific row."""
        if not (0 <= row < len(self._recordings)):
            return

        # Temporarily select this row
        self._table.selectRow(row)
        self._manage_tags()

    def _transcribe_selected(self):
        """Transcribe the selected recording."""
        rec = self._get_selected_recording()
        if not rec:
            return

        if rec.has_transcript:
            self._status_label.setText("Already transcribed.")
            return

        if rec.filepath in self._transcribing:
            self._status_label.setText("Transcription already in progress.")
            return

        config = get_config()
        worker = TranscriptionWorker(rec.filepath, model=config.whisper_model)
        worker.progress.connect(lambda msg: self._status_label.setText(msg))
        worker.finished.connect(lambda path, fp=rec.filepath: self._on_transcribe_finished(fp, path))
        worker.error.connect(lambda err, fp=rec.filepath: self._on_transcribe_error(fp, err))

        self._transcribing[rec.filepath] = worker
        self._populate_table()
        self._status_label.setText(f"Transcribing {rec.filepath.name}...")
        worker.start()

    def _on_transcribe_finished(self, filepath: Path, transcript_path: str):
        """Handle transcription completion."""
        self._transcribing.pop(filepath, None)
        self._status_label.setText(f"Transcription complete: {filepath.name}")
        self.refresh()

    def _on_transcribe_error(self, filepath: Path, error: str):
        """Handle transcription error."""
        self._transcribing.pop(filepath, None)
        self._status_label.setText(f"Transcription failed: {error}")
        self._populate_table()

    def _toggle_favorite(self):
        """Toggle favorite status for the selected recording."""
        rec = self._get_selected_recording()
        if not rec:
            return

        config = get_config()
        if rec.is_favorite:
            config.remove_favorite(rec.filepath.name)
            self._status_label.setText(f"Removed from favorites: {rec.filepath.name}")
        else:
            config.add_favorite(rec.filepath.name)
            self._status_label.setText(f"Added to favorites: {rec.filepath.name}")

        # Refresh to update star display
        self.refresh()

    def _rename_selected(self):
        """Rename the selected recording."""
        rec = self._get_selected_recording()
        if not rec:
            self._status_label.setText("No recording selected.")
            return

        # Get current name (without timestamp prefix and extension)
        from meeting_noter.output.writer import extract_timestamp_prefix

        stem = rec.filepath.stem
        timestamp = extract_timestamp_prefix(stem)
        if timestamp:
            # Extract the name part after the timestamp
            current_name = stem[len(timestamp) + 1:] if len(stem) > len(timestamp) else ""
        else:
            current_name = stem

        # Replace underscores with spaces for display
        current_name = current_name.replace("_", " ")

        # Show input dialog
        new_name, ok = QInputDialog.getText(
            self,
            "Rename Meeting",
            "Enter new meeting name:",
            text=current_name,
        )

        if not ok or not new_name.strip():
            return

        new_name = new_name.strip()

        # Perform the rename
        from meeting_noter.output.writer import rename_meeting

        config = get_config()
        try:
            new_path = rename_meeting(rec.filepath, new_name, config)
            self._status_label.setText(f"Renamed to: {new_path.name}")
            self.refresh()
        except FileExistsError:
            QMessageBox.warning(
                self,
                "Rename Failed",
                f"A file with that name already exists.",
            )
        except PermissionError:
            QMessageBox.warning(
                self,
                "Rename Failed",
                "Permission denied. Cannot rename files.",
            )
        except Exception as e:
            QMessageBox.warning(
                self,
                "Rename Failed",
                f"Error renaming file: {e}",
            )

    def _manage_tags(self):
        """Manage tags for the selected recording."""
        rec = self._get_selected_recording()
        if not rec:
            self._status_label.setText("No recording selected.")
            return

        config = get_config()
        current_tags = config.get_tags(rec.filepath.name)
        current_tags_str = ", ".join(current_tags) if current_tags else ""

        # Show input dialog with current tags
        new_tags_str, ok = QInputDialog.getText(
            self,
            "Manage Tags",
            "Enter tags (comma-separated):\n\nExample: Project X, Sprint Planning, Q1 Review",
            text=current_tags_str,
        )

        if not ok:
            return

        # Parse new tags
        new_tags = [tag.strip() for tag in new_tags_str.split(",") if tag.strip()]

        # Remove old tags that are no longer present
        for old_tag in current_tags:
            if old_tag not in new_tags:
                config.remove_tag(rec.filepath.name, old_tag)

        # Add new tags
        for new_tag in new_tags:
            if new_tag not in current_tags:
                config.add_tag(rec.filepath.name, new_tag)

        if new_tags:
            self._status_label.setText(f"Tags updated: {', '.join(new_tags)}")
        else:
            self._status_label.setText("Tags cleared")

        self.refresh()
