"""Search screen for Meeting Noter GUI."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QCheckBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from meeting_noter.config import get_config
from meeting_noter.gui.utils.signals import get_app_state


@dataclass
class SearchMatch:
    """A search match result."""

    filepath: Path
    line_number: int
    timestamp: str
    text: str


@dataclass
class FileSearchResult:
    """Search results for a single file."""

    filepath: Path
    matches: list[SearchMatch]


class SearchScreen(QWidget):
    """Screen for searching transcripts."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._results: list[FileSearchResult] = []
        self._setup_ui()
        self._connect_signals()

    def _setup_ui(self):
        """Set up the search UI."""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(30, 30, 30, 30)
        layout.setSpacing(20)

        # Title
        title = QLabel("Search Transcripts")
        title.setStyleSheet("font-size: 24px; font-weight: 600; color: #ffffff;")
        layout.addWidget(title)

        # Search row
        search_row = QHBoxLayout()
        search_row.setSpacing(10)

        self._search_input = QLineEdit()
        self._search_input.setPlaceholderText("Enter search query...")
        self._search_input.returnPressed.connect(self._do_search)

        self._search_btn = QPushButton("Search")
        self._search_btn.setFixedWidth(100)

        search_row.addWidget(self._search_input, 1)
        search_row.addWidget(self._search_btn)
        layout.addLayout(search_row)

        # Options row
        options_row = QHBoxLayout()
        self._case_sensitive = QCheckBox("Case sensitive")
        options_row.addWidget(self._case_sensitive)
        options_row.addStretch()
        layout.addLayout(options_row)

        # Results header
        self._results_header = QLabel("")
        self._results_header.setStyleSheet("color: #4ec9b0; font-weight: 500;")
        layout.addWidget(self._results_header)

        # Results list
        self._results_list = QListWidget()
        self._results_list.itemDoubleClicked.connect(self._on_result_clicked)
        layout.addWidget(self._results_list, 1)

        # Results footer
        self._results_footer = QLabel("")
        self._results_footer.setStyleSheet("color: #858585;")
        layout.addWidget(self._results_footer)

    def _connect_signals(self):
        """Connect button signals."""
        self._search_btn.clicked.connect(self._do_search)

    def _do_search(self):
        """Perform the search."""
        query = self._search_input.text().strip()
        if not query:
            return

        config = get_config()
        transcripts_dir = config.transcripts_dir

        if not transcripts_dir.exists():
            self._results_header.setText("No transcripts directory found")
            self._results_header.setStyleSheet("color: #f14c4c;")
            return

        case_sensitive = self._case_sensitive.isChecked()
        results = self._search_files(transcripts_dir, query, case_sensitive)

        self._results = results
        self._display_results(query)

    def _search_files(
        self, directory: Path, query: str, case_sensitive: bool
    ) -> list[FileSearchResult]:
        """Search all transcript files for the query."""
        results = []

        txt_files = sorted(
            directory.glob("*.txt"),
            key=lambda p: p.stat().st_mtime,
            reverse=True,
        )

        search_query = query if case_sensitive else query.lower()

        for filepath in txt_files:
            try:
                content = filepath.read_text()
                lines = content.splitlines()

                matches = []
                for i, line in enumerate(lines):
                    check_line = line if case_sensitive else line.lower()
                    if search_query in check_line:
                        # Extract timestamp if present
                        timestamp = ""
                        text = line
                        if line.startswith("[") and "]" in line:
                            bracket_end = line.index("]")
                            timestamp = line[1:bracket_end]
                            text = line[bracket_end + 1 :].strip()

                        matches.append(
                            SearchMatch(
                                filepath=filepath,
                                line_number=i + 1,
                                timestamp=timestamp,
                                text=text[:80] + "..." if len(text) > 80 else text,
                            )
                        )

                        if len(matches) >= 5:  # Limit matches per file
                            break

                if matches:
                    results.append(FileSearchResult(filepath=filepath, matches=matches))

            except Exception:
                continue

        # Sort by match count
        results.sort(key=lambda r: len(r.matches), reverse=True)
        return results[:50]  # Limit total results

    def _display_results(self, query: str):
        """Display search results."""
        self._results_list.clear()

        total_matches = sum(len(r.matches) for r in self._results)

        if not self._results:
            self._results_header.setText(f"No matches found for '{query}'")
            self._results_header.setStyleSheet("color: #dcdcaa;")
            self._results_footer.setText("")
            return

        self._results_header.setText(
            f"Found {total_matches} matches in {len(self._results)} transcripts"
        )
        self._results_header.setStyleSheet("color: #4ec9b0;")

        for result in self._results:
            # File header
            header_item = QListWidgetItem(
                f"\u25b6 {result.filepath.name} ({len(result.matches)} matches)"
            )
            header_item.setData(Qt.UserRole, str(result.filepath))
            header_item.setForeground(Qt.green)
            font = header_item.font()
            font.setBold(True)
            header_item.setFont(font)
            self._results_list.addItem(header_item)

            # Match items
            for match in result.matches:
                if match.timestamp:
                    text = f"    [{match.timestamp}] {match.text}"
                else:
                    text = f"    {match.text}"

                match_item = QListWidgetItem(text)
                match_item.setData(Qt.UserRole, str(result.filepath))
                self._results_list.addItem(match_item)

        self._results_footer.setText(f"Searched {len(self._results)} transcripts")

    def _on_result_clicked(self, item: QListWidgetItem):
        """Handle click on a result item."""
        filepath = item.data(Qt.UserRole)
        if filepath:
            app_state = get_app_state()
            app_state.open_transcript.emit(filepath)

    def refresh(self):
        """Refresh the search (focus the input)."""
        self._search_input.setFocus()
