"""Settings screen for Meeting Noter GUI."""

from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Qt, QThread, Signal
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QFileDialog,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QSpinBox,
    QVBoxLayout,
    QWidget,
)

from meeting_noter.config import get_config


class AIInstallWorker(QThread):
    """Worker thread for AI model installation."""

    finished = Signal(bool, str)  # success, message
    progress = Signal(str)  # status message

    def run(self):
        try:
            from meeting_noter.analysis.installer import install_ai
            self.progress.emit("Downloading AI model (~4GB)...")
            install_ai()
            self.finished.emit(True, "AI installed successfully!")
        except Exception as e:
            self.finished.emit(False, str(e))


WHISPER_MODELS = [
    ("tiny.en", "tiny.en (fastest)"),
    ("base.en", "base.en (balanced)"),
    ("small.en", "small.en (better)"),
    ("medium.en", "medium.en (high quality)"),
    ("large-v3", "large-v3 (best, multilingual)"),
    ("large-v3-turbo", "large-v3-turbo (fast + high quality)"),
    ("distil-large-v3", "distil-large-v3 (fast + high quality)"),
]


class SettingsScreen(QWidget):
    """Screen for configuring application settings."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._setup_ui()
        self._connect_signals()
        self._load_settings()

    def _setup_ui(self):
        """Set up the settings UI."""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(30, 30, 30, 30)
        layout.setSpacing(20)

        # Title
        title = QLabel("Settings")
        title.setStyleSheet("font-size: 24px; font-weight: 600; color: #ffffff;")
        layout.addWidget(title)

        # Directories section
        dirs_section = self._create_section("Directories")
        dirs_layout = QGridLayout()
        dirs_layout.setSpacing(10)

        # Recordings directory
        dirs_layout.addWidget(QLabel("Recordings:"), 0, 0)
        self._recordings_dir = QLineEdit()
        dirs_layout.addWidget(self._recordings_dir, 0, 1)
        recordings_browse = QPushButton("...")
        recordings_browse.setFixedWidth(40)
        recordings_browse.clicked.connect(lambda: self._browse_dir(self._recordings_dir))
        dirs_layout.addWidget(recordings_browse, 0, 2)

        # Transcripts directory
        dirs_layout.addWidget(QLabel("Transcripts:"), 1, 0)
        self._transcripts_dir = QLineEdit()
        dirs_layout.addWidget(self._transcripts_dir, 1, 1)
        transcripts_browse = QPushButton("...")
        transcripts_browse.setFixedWidth(40)
        transcripts_browse.clicked.connect(lambda: self._browse_dir(self._transcripts_dir))
        dirs_layout.addWidget(transcripts_browse, 1, 2)

        dirs_section.layout().addLayout(dirs_layout)
        layout.addWidget(dirs_section)

        # Transcription section
        trans_section = self._create_section("Transcription")
        trans_layout = QGridLayout()
        trans_layout.setSpacing(10)

        trans_layout.addWidget(QLabel("Whisper model:"), 0, 0)
        self._model_combo = QComboBox()
        for model_id, model_name in WHISPER_MODELS:
            self._model_combo.addItem(model_name, model_id)
        self._model_combo.setMinimumWidth(250)
        trans_layout.addWidget(self._model_combo, 0, 1)
        trans_layout.setColumnStretch(2, 1)

        trans_section.layout().addLayout(trans_layout)
        layout.addWidget(trans_section)

        # Options section
        options_section = self._create_section("Options")
        options_layout = QVBoxLayout()
        options_layout.setSpacing(10)

        self._auto_transcribe = QCheckBox("Auto-transcribe after recording")
        options_layout.addWidget(self._auto_transcribe)

        self._capture_system = QCheckBox("Capture system audio (meeting participants)")
        options_layout.addWidget(self._capture_system)

        self._auto_update = QCheckBox("Auto-update when new version available")
        options_layout.addWidget(self._auto_update)

        # Silence timeout
        timeout_row = QHBoxLayout()
        timeout_row.addWidget(QLabel("Silence timeout (minutes):"))
        self._silence_timeout = QSpinBox()
        self._silence_timeout.setRange(1, 60)
        self._silence_timeout.setFixedWidth(80)
        timeout_row.addWidget(self._silence_timeout)
        timeout_row.addStretch()
        options_layout.addLayout(timeout_row)

        options_section.layout().addLayout(options_layout)
        layout.addWidget(options_section)

        # AI Assistant section
        ai_section = self._create_section("AI Assistant")
        ai_layout = QVBoxLayout()
        ai_layout.setSpacing(12)

        # Status row with icon
        status_row = QHBoxLayout()
        status_label = QLabel("Status:")
        status_label.setStyleSheet("font-weight: 500;")
        status_row.addWidget(status_label)
        self._ai_status_icon = QLabel("⚪")
        self._ai_status_icon.setStyleSheet("font-size: 16px;")
        status_row.addWidget(self._ai_status_icon)
        self._ai_status = QLabel("Checking...")
        self._ai_status.setStyleSheet("font-weight: 600; font-size: 14px;")
        status_row.addWidget(self._ai_status)
        status_row.addStretch()
        ai_layout.addLayout(status_row)

        # Info card (shown when installed)
        self._ai_info_card = QFrame()
        self._ai_info_card.setStyleSheet(
            """
            QFrame {
                background-color: #1e3a1e;
                border: 1px solid #2d5a2d;
                border-radius: 6px;
                padding: 10px;
            }
            QLabel {
                background: transparent;
                border: none;
            }
            """
        )
        info_card_layout = QVBoxLayout(self._ai_info_card)
        info_card_layout.setContentsMargins(12, 10, 12, 10)
        info_card_layout.setSpacing(6)

        # Model name
        self._ai_model_name = QLabel("Qwen2.5-7B-Instruct")
        self._ai_model_name.setStyleSheet("font-weight: 600; color: #4ec9b0; font-size: 13px;")
        info_card_layout.addWidget(self._ai_model_name)

        # Model path
        self._ai_path = QLabel("")
        self._ai_path.setStyleSheet("color: #858585; font-size: 11px;")
        self._ai_path.setWordWrap(True)
        info_card_layout.addWidget(self._ai_path)

        # Model size
        self._ai_size = QLabel("")
        self._ai_size.setStyleSheet("color: #9cdcaa; font-size: 12px;")
        info_card_layout.addWidget(self._ai_size)

        ai_layout.addWidget(self._ai_info_card)

        # Progress bar (shown during install)
        self._ai_progress = QProgressBar()
        self._ai_progress.setRange(0, 0)  # Indeterminate
        self._ai_progress.setMinimumHeight(8)
        self._ai_progress.setStyleSheet(
            """
            QProgressBar {
                background-color: #3c3c3c;
                border-radius: 4px;
            }
            QProgressBar::chunk {
                background-color: #0e639c;
                border-radius: 4px;
            }
            """
        )
        self._ai_progress.setVisible(False)
        ai_layout.addWidget(self._ai_progress)

        # Progress label
        self._ai_progress_label = QLabel("")
        self._ai_progress_label.setStyleSheet("color: #4ec9b0; font-size: 12px;")
        self._ai_progress_label.setVisible(False)
        ai_layout.addWidget(self._ai_progress_label)

        # Auto-analyze checkbox
        self._auto_analyze = QCheckBox("Auto-analyze after transcription")
        self._auto_analyze.setStyleSheet("font-size: 13px;")
        ai_layout.addWidget(self._auto_analyze)

        # Install/Remove button row
        ai_btn_row = QHBoxLayout()
        ai_btn_row.setSpacing(10)

        self._ai_install_btn = QPushButton("⬇️ Install AI (~4 GB)")
        self._ai_install_btn.setMinimumHeight(36)
        self._ai_install_btn.setStyleSheet(
            """
            QPushButton {
                background-color: #0e639c;
                padding: 8px 20px;
                border-radius: 4px;
                font-weight: 600;
                font-size: 13px;
            }
            QPushButton:hover {
                background-color: #1177bb;
            }
            QPushButton:disabled {
                background-color: #3c3c3c;
                color: #858585;
            }
            """
        )
        self._ai_install_btn.clicked.connect(self._install_ai)

        self._ai_remove_btn = QPushButton("🗑️ Remove AI")
        self._ai_remove_btn.setMinimumHeight(36)
        self._ai_remove_btn.setStyleSheet(
            """
            QPushButton {
                background-color: #6e2020;
                padding: 8px 20px;
                border-radius: 4px;
                font-weight: 600;
                font-size: 13px;
            }
            QPushButton:hover {
                background-color: #8e3030;
            }
            """
        )
        self._ai_remove_btn.clicked.connect(self._remove_ai)

        ai_btn_row.addWidget(self._ai_install_btn)
        ai_btn_row.addWidget(self._ai_remove_btn)
        ai_btn_row.addStretch()
        ai_layout.addLayout(ai_btn_row)

        # MLX status
        self._mlx_status = QLabel("")
        self._mlx_status.setStyleSheet("color: #858585; font-size: 11px;")
        ai_layout.addWidget(self._mlx_status)

        ai_section.layout().addLayout(ai_layout)
        layout.addWidget(ai_section)

        # Buttons
        button_row = QHBoxLayout()
        button_row.setSpacing(10)

        self._save_btn = QPushButton("Save")
        self._save_btn.setProperty("class", "success")
        self._save_btn.setStyleSheet("background-color: #107c10;")

        self._reset_btn = QPushButton("Reset")
        self._reset_btn.setProperty("class", "secondary")
        self._reset_btn.setStyleSheet("background-color: #3c3c3c;")

        button_row.addWidget(self._save_btn)
        button_row.addWidget(self._reset_btn)
        button_row.addStretch()
        layout.addLayout(button_row)

        # Status label
        self._status_label = QLabel("")
        self._status_label.setStyleSheet("color: #4ec9b0;")
        layout.addWidget(self._status_label)

        # Spacer
        layout.addStretch()

    def _create_section(self, title: str) -> QFrame:
        """Create a section frame with title."""
        frame = QFrame()
        frame.setStyleSheet(
            "QFrame { background-color: #2d2d2d; border: 1px solid #3c3c3c; border-radius: 8px; }"
        )

        layout = QVBoxLayout(frame)
        layout.setContentsMargins(15, 15, 15, 15)
        layout.setSpacing(15)

        section_title = QLabel(title)
        section_title.setStyleSheet(
            "font-size: 12px; font-weight: 600; color: #858585; text-transform: uppercase;"
        )
        layout.addWidget(section_title)

        return frame

    def _connect_signals(self):
        """Connect button signals."""
        self._save_btn.clicked.connect(self._save_settings)
        self._reset_btn.clicked.connect(self._load_settings)

    def _browse_dir(self, line_edit: QLineEdit):
        """Open directory browser."""
        current = line_edit.text() or str(Path.home())
        directory = QFileDialog.getExistingDirectory(self, "Select Directory", current)
        if directory:
            line_edit.setText(directory)

    def _load_settings(self):
        """Load settings from config."""
        # Reload config in case it was modified by CLI
        config = get_config(reload=True)

        self._recordings_dir.setText(str(config.recordings_dir))
        self._transcripts_dir.setText(str(config.transcripts_dir))

        # Set model combo
        model = config.whisper_model
        for i in range(self._model_combo.count()):
            if self._model_combo.itemData(i) == model:
                self._model_combo.setCurrentIndex(i)
                break

        self._auto_transcribe.setChecked(config.auto_transcribe)
        self._capture_system.setChecked(config.capture_system_audio)
        self._auto_update.setChecked(config.auto_update)
        self._silence_timeout.setValue(config.silence_timeout)
        self._auto_analyze.setChecked(config.auto_analyze)

        self._status_label.setText("")

        # Load AI status
        self._update_ai_status()

    def _save_settings(self):
        """Save settings to config."""
        config = get_config()

        # Validate and create directories
        recordings_path = Path(self._recordings_dir.text()).expanduser()
        transcripts_path = Path(self._transcripts_dir.text()).expanduser()

        try:
            recordings_path.mkdir(parents=True, exist_ok=True)
            transcripts_path.mkdir(parents=True, exist_ok=True)
        except Exception as e:
            self._status_label.setText(f"Error creating directories: {e}")
            self._status_label.setStyleSheet("color: #f14c4c;")
            return

        config.recordings_dir = recordings_path
        config.transcripts_dir = transcripts_path
        config.whisper_model = self._model_combo.currentData()
        config.auto_transcribe = self._auto_transcribe.isChecked()
        config.capture_system_audio = self._capture_system.isChecked()
        config.auto_update = self._auto_update.isChecked()
        config.silence_timeout = self._silence_timeout.value()
        config.auto_analyze = self._auto_analyze.isChecked()

        config.save()

        self._status_label.setText("Settings saved successfully")
        self._status_label.setStyleSheet("color: #4ec9b0;")

    def refresh(self):
        """Refresh settings."""
        self._load_settings()

    def _update_ai_status(self):
        """Update AI installation status display."""
        from meeting_noter.analysis.installer import (
            is_ai_installed, get_model_path, get_model_size, check_mlx_available
        )

        installed = is_ai_installed()

        if installed:
            self._ai_status_icon.setText("✅")
            self._ai_status.setText("Installed")
            self._ai_status.setStyleSheet("font-weight: 600; font-size: 14px; color: #4ec9b0;")

            model_path = get_model_path()
            self._ai_path.setText(f"📁 {model_path}")

            size = get_model_size()
            if size:
                size_mb = size / (1024 * 1024)
                self._ai_size.setText(f"💾 {size_mb:.1f} MB")

            self._ai_info_card.setVisible(True)
            self._ai_info_card.setStyleSheet(
                """
                QFrame {
                    background-color: #1e3a1e;
                    border: 1px solid #2d5a2d;
                    border-radius: 6px;
                }
                QLabel {
                    background: transparent;
                    border: none;
                }
                """
            )

            self._ai_install_btn.setVisible(False)
            self._ai_remove_btn.setVisible(True)
            self._auto_analyze.setEnabled(True)
        else:
            self._ai_status_icon.setText("⚪")
            self._ai_status.setText("Not installed")
            self._ai_status.setStyleSheet("font-weight: 600; font-size: 14px; color: #858585;")

            self._ai_info_card.setVisible(False)

            self._ai_install_btn.setVisible(True)
            self._ai_remove_btn.setVisible(False)
            self._auto_analyze.setEnabled(False)
            self._auto_analyze.setChecked(False)

        # Check MLX status
        mlx_ok, mlx_msg = check_mlx_available()
        if mlx_ok:
            self._mlx_status.setText(f"✓ {mlx_msg}")
            self._mlx_status.setStyleSheet("color: #4ec9b0; font-size: 11px;")
            self._ai_install_btn.setEnabled(True)
        else:
            # Check if MLX can be auto-installed
            if "not installed" in mlx_msg.lower():
                self._mlx_status.setText(f"⚠️ {mlx_msg} (will be auto-installed)")
                self._mlx_status.setStyleSheet("color: #dcdcaa; font-size: 11px;")
                self._ai_install_btn.setEnabled(True)
            else:
                self._mlx_status.setText(f"❌ {mlx_msg}")
                self._mlx_status.setStyleSheet("color: #f14c4c; font-size: 11px;")
                self._ai_install_btn.setEnabled(False)

    def _install_ai(self):
        """Start AI installation."""
        from meeting_noter.analysis.installer import check_mlx_available

        # Check if MLX needs to be installed first
        mlx_ok, mlx_msg = check_mlx_available()
        if not mlx_ok and "not installed" in mlx_msg.lower():
            self._ai_progress.setVisible(True)
            self._ai_progress_label.setVisible(True)
            self._ai_progress_label.setText("Installing MLX dependencies...")
            self._ai_install_btn.setEnabled(False)

            # Install MLX first
            import subprocess
            import sys
            try:
                subprocess.check_call([
                    sys.executable, "-m", "pip", "install",
                    "mlx>=0.10", "mlx-lm>=0.10", "-q"
                ])
                self._ai_progress_label.setText("MLX installed! Downloading AI model...")
            except subprocess.CalledProcessError as e:
                self._ai_progress.setVisible(False)
                self._ai_progress_label.setText(f"Failed to install MLX: {e}")
                self._ai_progress_label.setStyleSheet("color: #f14c4c;")
                self._ai_install_btn.setEnabled(True)
                return

        # Show progress
        self._ai_progress.setVisible(True)
        self._ai_progress_label.setVisible(True)
        self._ai_progress_label.setText("Downloading AI model (~4GB)...")
        self._ai_install_btn.setEnabled(False)

        # Start worker thread
        self._install_worker = AIInstallWorker()
        self._install_worker.progress.connect(self._on_install_progress)
        self._install_worker.finished.connect(self._on_install_finished)
        self._install_worker.start()

    def _on_install_progress(self, message: str):
        """Handle installation progress."""
        self._ai_progress_label.setText(message)

    def _on_install_finished(self, success: bool, message: str):
        """Handle installation completion."""
        self._ai_progress.setVisible(False)
        self._ai_progress_label.setVisible(False)

        if success:
            self._status_label.setText(message)
            self._status_label.setStyleSheet("color: #4ec9b0;")
        else:
            self._status_label.setText(f"Installation failed: {message}")
            self._status_label.setStyleSheet("color: #f14c4c;")

        self._update_ai_status()

    def _remove_ai(self):
        """Remove AI model."""
        from meeting_noter.analysis.installer import get_model_size, remove_ai

        size = get_model_size()
        size_mb = size / (1024 * 1024) if size else 0

        reply = QMessageBox.question(
            self,
            "Remove AI",
            f"Remove AI model ({size_mb:.1f} MB)?\n\nYou can reinstall it later.",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No
        )

        if reply == QMessageBox.Yes:
            remove_ai()
            self._status_label.setText("AI model removed")
            self._status_label.setStyleSheet("color: #4ec9b0;")
            self._update_ai_status()

            # Also disable auto-analyze
            config = get_config()
            config.auto_analyze = False
            config.save()
            self._auto_analyze.setChecked(False)
