"""Transcript viewer screen for Meeting Noter GUI."""

from __future__ import annotations

from datetime import datetime
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtGui import QColor, QShortcut, QKeySequence, QTextCharFormat, QTextCursor
from PySide6.QtWidgets import (
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QSplitter,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from meeting_noter.config import get_config
from meeting_noter.gui.utils.signals import get_app_state
from meeting_noter.gui.widgets.chat_panel import ChatPanel
from meeting_noter.gui.widgets.media_player import MediaPlayerWidget
from meeting_noter.gui.widgets.transcript_view import TranscriptView
from meeting_noter.output.writer import format_size


class ViewerScreen(QWidget):
    """Screen for viewing transcripts with optional AI chat and media player."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._current_path: Path | None = None
        self._audio_path: Path | None = None
        self._setup_ui()
        self._connect_signals()

    def _setup_ui(self):
        """Set up the viewer UI."""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(30, 30, 30, 30)
        layout.setSpacing(15)

        # Title row
        title_row = QHBoxLayout()

        self._title = QLabel("Transcript Viewer")
        self._title.setStyleSheet("font-size: 24px; font-weight: 600; color: #ffffff;")
        title_row.addWidget(self._title)

        title_row.addStretch()

        # Chat toggle button
        self._chat_toggle = QPushButton("💬 AI Chat")
        self._chat_toggle.setCheckable(True)
        self._chat_toggle.setMinimumWidth(100)
        self._chat_toggle.setStyleSheet(
            """
            QPushButton {
                background-color: #3c3c3c;
                padding: 8px 16px;
                border-radius: 4px;
                font-weight: 600;
            }
            QPushButton:checked {
                background-color: #0e639c;
            }
            QPushButton:hover {
                background-color: #4c4c4c;
            }
            QPushButton:checked:hover {
                background-color: #1177bb;
            }
            """
        )
        self._chat_toggle.clicked.connect(self._toggle_chat)
        title_row.addWidget(self._chat_toggle)

        self._back_btn = QPushButton("Back")
        self._back_btn.setProperty("class", "secondary")
        self._back_btn.setStyleSheet("background-color: #3c3c3c;")
        title_row.addWidget(self._back_btn)

        layout.addLayout(title_row)

        # File info
        self._file_info = QLabel("")
        self._file_info.setStyleSheet("color: #858585;")
        layout.addWidget(self._file_info)

        # Search bar
        search_row = QHBoxLayout()
        search_row.setSpacing(8)

        self._search_input = QLineEdit()
        self._search_input.setPlaceholderText("Search transcript... (Enter=next, Shift+Enter=prev)")
        self._search_input.setStyleSheet(
            """
            QLineEdit {
                background-color: #2d2d2d;
                border: 1px solid #3c3c3c;
                border-radius: 4px;
                padding: 6px 12px;
                font-size: 13px;
                color: #ffffff;
            }
            QLineEdit:focus {
                border-color: #0e639c;
            }
            """
        )
        self._search_input.textChanged.connect(self._on_search_changed)
        self._search_input.returnPressed.connect(self._search_next)
        search_row.addWidget(self._search_input)

        self._search_info = QLabel("")
        self._search_info.setStyleSheet("color: #858585; min-width: 80px;")
        search_row.addWidget(self._search_info)

        layout.addLayout(search_row)

        # Ctrl+F shortcut to focus search
        shortcut = QShortcut(QKeySequence("Ctrl+F"), self)
        shortcut.activated.connect(self._focus_search)

        # Shift+Enter for previous match
        prev_shortcut = QShortcut(QKeySequence("Shift+Return"), self._search_input)
        prev_shortcut.activated.connect(self._search_prev)

        self._search_matches_count = 0
        self._search_current = 0

        # Main content area with splitter
        self._splitter = QSplitter(Qt.Horizontal)

        # Left: Transcript content (stacked: TranscriptView or QTextEdit fallback)
        content_widget = QWidget()
        content_layout = QVBoxLayout(content_widget)
        content_layout.setContentsMargins(0, 0, 0, 0)
        content_layout.setSpacing(0)

        # Transcript view with clickable segments (primary)
        self._transcript_view = TranscriptView()
        self._transcript_view.segment_clicked.connect(self._on_segment_clicked)
        content_layout.addWidget(self._transcript_view)

        # Fallback text view for transcripts without timestamps
        self._content = QTextEdit()
        self._content.setReadOnly(True)
        self._content.setStyleSheet(
            "font-family: 'Menlo', 'Monaco', 'Courier New', monospace; font-size: 13px;"
        )
        self._content.setVisible(False)  # Hidden by default
        content_layout.addWidget(self._content)

        self._splitter.addWidget(content_widget)

        # Right: Chat panel
        self._chat_panel = ChatPanel()
        self._splitter.addWidget(self._chat_panel)

        # Set initial sizes (70% transcript, 30% chat)
        self._splitter.setSizes([700, 300])

        # Initially hide chat panel
        self._chat_panel.setVisible(False)

        layout.addWidget(self._splitter, 1)

        # Media player at the bottom
        self._media_player = MediaPlayerWidget()
        self._media_player.position_changed.connect(self._on_playback_position_changed)
        self._media_player.setVisible(False)  # Hidden until audio is loaded
        layout.addWidget(self._media_player)

        # Action buttons
        button_row = QHBoxLayout()
        button_row.setSpacing(10)

        self._copy_btn = QPushButton("Copy")
        self._copy_btn.setMinimumWidth(80)
        self._copy_btn.setStyleSheet(
            """
            QPushButton {
                background-color: #3c3c3c;
                padding: 8px 16px;
                border-radius: 4px;
                font-weight: 600;
            }
            QPushButton:hover {
                background-color: #4c4c4c;
            }
            """
        )
        self._copy_btn.clicked.connect(self._copy_transcript)
        button_row.addWidget(self._copy_btn)

        self._favorite_btn = QPushButton("\u2b50 Favorite")
        self._favorite_btn.setMinimumWidth(100)
        self._favorite_btn.setStyleSheet(
            """
            QPushButton {
                background-color: #3c3c3c;
                padding: 8px 16px;
                border-radius: 4px;
                font-weight: 600;
            }
            QPushButton:hover {
                background-color: #4c4c4c;
            }
            """
        )
        button_row.addWidget(self._favorite_btn)

        self._analyze_btn = QPushButton("🔍 Analyze")
        self._analyze_btn.setMinimumWidth(100)
        self._analyze_btn.setStyleSheet(
            """
            QPushButton {
                background-color: #0e639c;
                padding: 8px 16px;
                border-radius: 4px;
                font-weight: 600;
            }
            QPushButton:hover {
                background-color: #1177bb;
            }
            """
        )
        self._analyze_btn.clicked.connect(self._analyze_transcript)
        button_row.addWidget(self._analyze_btn)

        # AI install hint (shown when AI is not installed)
        self._ai_install_hint = QLabel("💡 Install AI in Settings for chat & analysis")
        self._ai_install_hint.setStyleSheet(
            "color: #858585; font-size: 12px; font-style: italic; padding-left: 10px;"
        )
        button_row.addWidget(self._ai_install_hint)

        button_row.addStretch()

        layout.addLayout(button_row)

        # Update chat toggle visibility based on AI status
        self._update_ai_ui()

    def _connect_signals(self):
        """Connect button signals."""
        self._back_btn.clicked.connect(self._go_back)
        self._favorite_btn.clicked.connect(self._toggle_favorite)

        # Media player keyboard shortcuts
        play_shortcut = QShortcut(QKeySequence(Qt.Key_Space), self)
        play_shortcut.activated.connect(self._toggle_playback)

        # Seek shortcuts
        seek_back_shortcut = QShortcut(QKeySequence(Qt.Key_Left), self)
        seek_back_shortcut.activated.connect(lambda: self._seek_relative(-5000))

        seek_forward_shortcut = QShortcut(QKeySequence(Qt.Key_Right), self)
        seek_forward_shortcut.activated.connect(lambda: self._seek_relative(5000))

        seek_back_large_shortcut = QShortcut(QKeySequence("Shift+Left"), self)
        seek_back_large_shortcut.activated.connect(lambda: self._seek_relative(-15000))

        seek_forward_large_shortcut = QShortcut(QKeySequence("Shift+Right"), self)
        seek_forward_large_shortcut.activated.connect(lambda: self._seek_relative(15000))

    def _update_ai_ui(self):
        """Update AI-related UI based on installation status."""
        from meeting_noter.analysis.installer import is_ai_installed

        ai_installed = is_ai_installed()

        # Show/hide AI buttons based on installation status
        self._chat_toggle.setVisible(ai_installed)
        self._analyze_btn.setVisible(ai_installed)

        # Update install hint visibility
        if hasattr(self, '_ai_install_hint'):
            self._ai_install_hint.setVisible(not ai_installed)

        if not ai_installed:
            self._chat_panel.setVisible(False)
            self._chat_toggle.setChecked(False)

    def _toggle_chat(self):
        """Toggle the chat panel visibility."""
        show_chat = self._chat_toggle.isChecked()
        self._chat_panel.setVisible(show_chat)

        if show_chat and self._current_path:
            self._chat_panel.set_transcript(self._current_path)

    def load_transcript(self, filepath: str | Path):
        """Load and display a transcript."""
        self._current_path = Path(filepath)

        # Stop any current playback
        if hasattr(self, '_media_player'):
            self._media_player.stop()

        # Clear search state
        self._search_input.clear()
        self._search_info.setText("")
        self._search_matches_count = 0
        self._search_current = 0

        # Update AI UI
        self._update_ai_ui()

        if not self._current_path.exists():
            self._title.setText("File Not Found")
            self._file_info.setText("")
            self._content.setText(f"Could not find: {filepath}")
            self._content.setVisible(True)
            self._transcript_view.setVisible(False)
            self._media_player.setVisible(False)
            return

        # Update title
        config = get_config()
        is_favorite = config.is_favorite(self._current_path.name)
        star = "\u2605 " if is_favorite else ""
        self._title.setText(f"{star}{self._current_path.name}")

        # Update file info
        stat = self._current_path.stat()
        mtime = datetime.fromtimestamp(stat.st_mtime)
        size = format_size(stat.st_size)
        self._file_info.setText(f"Modified: {mtime.strftime('%Y-%m-%d %H:%M')} | Size: {size}")

        # Update favorite button
        if is_favorite:
            self._favorite_btn.setText("\u2606 Unfavorite")
            self._favorite_btn.setStyleSheet(
                """
                QPushButton {
                    background-color: #ca5010;
                    padding: 8px 16px;
                    border-radius: 4px;
                    font-weight: 600;
                }
                QPushButton:hover {
                    background-color: #da6020;
                }
                """
            )
        else:
            self._favorite_btn.setText("\u2b50 Favorite")
            self._favorite_btn.setStyleSheet(
                """
                QPushButton {
                    background-color: #3c3c3c;
                    padding: 8px 16px;
                    border-radius: 4px;
                    font-weight: 600;
                }
                QPushButton:hover {
                    background-color: #4c4c4c;
                }
                """
            )

        # Load content
        try:
            content = self._current_path.read_text()

            # Try to load in transcript view with segments
            self._transcript_view.load(content)

            if self._transcript_view.has_segments():
                # Use transcript view with clickable segments
                self._transcript_view.setVisible(True)
                self._content.setVisible(False)
            else:
                # Fallback to plain text view
                self._transcript_view.setVisible(False)
                self._content.setVisible(True)
                self._content.setText(content)

        except Exception as e:
            self._transcript_view.setVisible(False)
            self._content.setVisible(True)
            self._content.setText(f"Error reading file: {e}")

        # Try to find and load the corresponding audio file
        self._load_audio_for_transcript()

        # Load chat if visible
        if self._chat_panel.isVisible():
            self._chat_panel.set_transcript(self._current_path)

    def _load_audio_for_transcript(self):
        """Find and load the audio file for the current transcript."""
        if not self._current_path:
            self._media_player.setVisible(False)
            self._audio_path = None
            return

        config = get_config()
        audio_name = self._current_path.stem + ".mp3"
        audio_path = config.recordings_dir / audio_name

        if audio_path.exists():
            self._audio_path = audio_path
            self._media_player.load(audio_path)
            self._media_player.setVisible(True)
        else:
            self._audio_path = None
            self._media_player.setVisible(False)

    def _go_back(self):
        """Go back to recordings."""
        # Stop playback when leaving
        if hasattr(self, '_media_player'):
            self._media_player.stop()

        app_state = get_app_state()
        app_state.navigate_to.emit("recordings")

    def _copy_transcript(self):
        """Copy the full transcript to clipboard."""
        if not self._current_path or not self._current_path.exists():
            return

        try:
            from PySide6.QtWidgets import QApplication
            content = self._current_path.read_text()
            clipboard = QApplication.clipboard()
            clipboard.setText(content)

            # Show brief feedback
            original_text = self._copy_btn.text()
            self._copy_btn.setText("Copied!")
            self._copy_btn.setStyleSheet(
                """
                QPushButton {
                    background-color: #2d7d46;
                    padding: 8px 16px;
                    border-radius: 4px;
                    font-weight: 600;
                }
                """
            )

            # Reset after 1.5 seconds
            from PySide6.QtCore import QTimer
            QTimer.singleShot(1500, lambda: self._reset_copy_button(original_text))
        except Exception:
            pass

    def _reset_copy_button(self, text: str):
        """Reset copy button to original state."""
        self._copy_btn.setText(text)
        self._copy_btn.setStyleSheet(
            """
            QPushButton {
                background-color: #3c3c3c;
                padding: 8px 16px;
                border-radius: 4px;
                font-weight: 600;
            }
            QPushButton:hover {
                background-color: #4c4c4c;
            }
            """
        )

    def _toggle_favorite(self):
        """Toggle favorite status."""
        if not self._current_path:
            return

        config = get_config()
        if config.is_favorite(self._current_path.name):
            config.remove_favorite(self._current_path.name)
        else:
            config.add_favorite(self._current_path.name)

        # Reload to update display
        self.load_transcript(self._current_path)

    def _analyze_transcript(self):
        """Analyze the current transcript."""
        if not self._current_path:
            return

        from meeting_noter.analysis.installer import is_ai_installed

        if not is_ai_installed():
            return

        from meeting_noter.analysis.analyzer import analyze_and_save, has_summary

        if has_summary(self._current_path):
            # Load existing summary
            summary_path = self._current_path.with_suffix('.summary.txt')
            if summary_path.exists():
                self._show_summary(summary_path)
            return

        # TODO: Run analysis in background thread
        # For now, just show a message
        self._file_info.setText("Analyzing... (this may take a moment)")

    def _show_summary(self, summary_path: Path):
        """Show the summary in a popup or somewhere."""
        # For now, just append to transcript view
        try:
            summary = summary_path.read_text()
            current = self._content.toPlainText()
            self._content.setText(f"{current}\n\n{'=' * 50}\nSUMMARY\n{'=' * 50}\n\n{summary}")
        except Exception:
            pass

    def _focus_search(self):
        """Focus the search input."""
        self._search_input.setFocus()
        self._search_input.selectAll()

    def _on_search_changed(self, text: str):
        """Handle search text changes - highlight all matches."""
        self._clear_highlights()
        self._search_matches_count = 0
        self._search_current = 0

        if not text:
            self._search_info.setText("")
            return

        # Use transcript view search if visible, otherwise QTextEdit
        if self._transcript_view.isVisible():
            count = self._transcript_view.search(text)
            self._search_matches_count = count
            if count > 0:
                self._search_current = 1
                self._search_info.setText(f"1/{count}")
            else:
                self._search_info.setText("No matches")
        else:
            # Fallback: search in QTextEdit
            highlight_fmt = QTextCharFormat()
            highlight_fmt.setBackground(QColor("#665c00"))
            highlight_fmt.setForeground(QColor("#ffffff"))

            cursor = self._content.textCursor()
            cursor.movePosition(QTextCursor.Start)
            self._content.setTextCursor(cursor)

            count = 0
            while self._content.find(text):
                count += 1
                found_cursor = self._content.textCursor()
                found_cursor.mergeCharFormat(highlight_fmt)

            self._search_matches_count = count

            if count > 0:
                # Move back to the first match
                cursor = self._content.textCursor()
                cursor.movePosition(QTextCursor.Start)
                self._content.setTextCursor(cursor)
                self._content.find(text)
                self._search_current = 1
                self._search_info.setText(f"1/{count}")
            else:
                self._search_info.setText("No matches")

    def _search_next(self):
        """Find next match."""
        text = self._search_input.text()
        if not text:
            return

        # Use transcript view search if visible
        if self._transcript_view.isVisible():
            current = self._transcript_view.search_next()
            if current > 0:
                self._search_current = current
                self._search_info.setText(f"{current}/{self._search_matches_count}")
            return

        # Fallback: search in QTextEdit
        if not self._content.find(text):
            # Wrap around to start
            cursor = self._content.textCursor()
            cursor.movePosition(QTextCursor.Start)
            self._content.setTextCursor(cursor)
            if self._content.find(text):
                self._search_current = 1
            else:
                return
        else:
            self._search_current = (self._search_current % self._search_matches_count) + 1

        if self._search_matches_count > 0:
            self._search_info.setText(f"{self._search_current}/{self._search_matches_count}")

    def _search_prev(self):
        """Find previous match."""
        text = self._search_input.text()
        if not text:
            return

        # Use transcript view search if visible
        if self._transcript_view.isVisible():
            current = self._transcript_view.search_prev()
            if current > 0:
                self._search_current = current
                self._search_info.setText(f"{current}/{self._search_matches_count}")
            return

        # Fallback: search in QTextEdit
        from PySide6.QtGui import QTextDocument

        if not self._content.find(text, QTextDocument.FindBackward):
            # Wrap around to end
            cursor = self._content.textCursor()
            cursor.movePosition(QTextCursor.End)
            self._content.setTextCursor(cursor)
            if self._content.find(text, QTextDocument.FindBackward):
                self._search_current = self._search_matches_count
            else:
                return
        else:
            self._search_current = max(1, self._search_current - 1)

        if self._search_matches_count > 0:
            self._search_info.setText(f"{self._search_current}/{self._search_matches_count}")

    def _clear_highlights(self):
        """Remove all search highlights."""
        # Clear transcript view search
        if hasattr(self, '_transcript_view'):
            self._transcript_view.clear_search()

        # Clear QTextEdit highlights
        cursor = self._content.textCursor()
        cursor.select(QTextCursor.Document)
        plain_fmt = QTextCharFormat()
        cursor.setCharFormat(plain_fmt)
        cursor.clearSelection()
        self._content.setTextCursor(cursor)

    def _on_segment_clicked(self, timestamp_seconds: int):
        """Handle segment click - seek audio to that position."""
        if self._media_player.isVisible():
            self._media_player.seek_seconds(timestamp_seconds)
            self._media_player.play()

    def _on_playback_position_changed(self, position_ms: int):
        """Handle playback position changes - update transcript highlight."""
        self._transcript_view.set_current_position(position_ms)

    def _toggle_playback(self):
        """Toggle audio playback."""
        if self._media_player.isVisible():
            self._media_player.toggle()

    def _seek_relative(self, offset_ms: int):
        """Seek relative to current position."""
        if self._media_player.isVisible():
            current = self._media_player.get_position_ms()
            new_pos = max(0, current + offset_ms)
            self._media_player.seek(new_pos)

    def refresh(self):
        """Refresh the viewer."""
        self._update_ai_ui()
        if self._current_path:
            self.load_transcript(self._current_path)

    def hideEvent(self, event):
        """Stop playback when screen is hidden (navigating away)."""
        if hasattr(self, '_media_player'):
            self._media_player.stop()
        super().hideEvent(event)
