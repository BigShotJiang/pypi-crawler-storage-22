"""Theme package for Meeting Noter GUI."""

from meeting_noter.gui.theme.dark_theme import COLORS, apply_theme

__all__ = ["COLORS", "apply_theme"]
