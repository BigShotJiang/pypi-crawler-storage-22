"""Dark theme colors and styling for Meeting Noter GUI."""

from __future__ import annotations

from pathlib import Path

from PySide6.QtWidgets import QApplication

# Color palette (Discord/VS Code inspired)
COLORS = {
    # Background colors
    "bg_primary": "#1e1e1e",  # Main content background
    "bg_secondary": "#252526",  # Sidebar, panels
    "bg_tertiary": "#2d2d2d",  # Elevated panels, cards
    "bg_hover": "#3c3c3c",  # Hover states
    "bg_selected": "#094771",  # Selected items (blue tint)
    # Text colors
    "text_primary": "#cccccc",  # Primary text
    "text_secondary": "#858585",  # Muted/secondary text
    "text_disabled": "#5a5a5a",  # Disabled text
    "text_white": "#ffffff",  # White text
    # Accent colors
    "accent_primary": "#0078d4",  # Primary actions (blue)
    "accent_success": "#4ec9b0",  # Success states (green-cyan)
    "accent_warning": "#dcdcaa",  # Warnings (yellow)
    "accent_error": "#f14c4c",  # Errors (red)
    "accent_info": "#9cdcfe",  # Info (light blue)
    # Status colors
    "status_recording": "#f14c4c",  # Red dot when recording
    "status_ready": "#4ec9b0",  # Green dot when ready
    "status_idle": "#5a5a5a",  # Gray dot when stopped
    # Border colors
    "border_default": "#3c3c3c",
    "border_focus": "#007acc",
    # Sidebar
    "sidebar_bg": "#252526",
    "sidebar_item_hover": "#2a2d2e",
    "sidebar_item_selected": "#37373d",
}


def get_stylesheet() -> str:
    """Load the QSS stylesheet."""
    stylesheet_path = Path(__file__).parent / "styles.qss"
    if stylesheet_path.exists():
        return stylesheet_path.read_text()
    return ""


def apply_theme(app: QApplication) -> None:
    """Apply the dark theme to the application."""
    stylesheet = get_stylesheet()
    app.setStyleSheet(stylesheet)
