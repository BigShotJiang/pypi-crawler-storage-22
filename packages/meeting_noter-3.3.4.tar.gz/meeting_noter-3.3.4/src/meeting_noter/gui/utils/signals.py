"""Application state and signals for Meeting Noter GUI."""

from __future__ import annotations

from PySide6.QtCore import QObject, Signal


class AppState(QObject):
    """Central application state with Qt signals."""

    # Recording state signals
    recording_started = Signal(str)  # meeting_name
    recording_stopped = Signal(str)  # filepath
    recording_status_changed = Signal(bool, str)  # is_recording, meeting_name

    # Watcher state signals
    watcher_status_changed = Signal(bool)  # is_running

    # Live transcription signals
    live_transcript_updated = Signal(str)  # new_text

    # Config change signals
    config_changed = Signal()

    # Navigation signals
    navigate_to = Signal(str)  # screen_name
    open_transcript = Signal(str)  # filepath

    # Notification signals
    show_notification = Signal(str, str)  # title, message

    def __init__(self):
        super().__init__()
        self._is_recording = False
        self._current_meeting = ""
        self._watcher_running = False

    @property
    def is_recording(self) -> bool:
        """Get current recording state."""
        return self._is_recording

    @is_recording.setter
    def is_recording(self, value: bool) -> None:
        """Set recording state and emit signal."""
        if self._is_recording != value:
            self._is_recording = value
            self.recording_status_changed.emit(value, self._current_meeting)

    @property
    def current_meeting(self) -> str:
        """Get current meeting name."""
        return self._current_meeting

    @current_meeting.setter
    def current_meeting(self, value: str) -> None:
        """Set current meeting name."""
        self._current_meeting = value

    @property
    def watcher_running(self) -> bool:
        """Get watcher state."""
        return self._watcher_running

    @watcher_running.setter
    def watcher_running(self, value: bool) -> None:
        """Set watcher state and emit signal."""
        if self._watcher_running != value:
            self._watcher_running = value
            self.watcher_status_changed.emit(value)


# Global app state instance
_app_state: AppState | None = None


def get_app_state() -> AppState:
    """Get the global app state instance."""
    global _app_state
    if _app_state is None:
        _app_state = AppState()
    return _app_state
