"""Background worker threads for Meeting Noter GUI."""

from __future__ import annotations

import os
import time
from pathlib import Path
from typing import Optional

from PySide6.QtCore import QThread, Signal

from meeting_noter.config import get_config
from meeting_noter.daemon import is_process_running, read_pid_file


DEFAULT_PID_FILE = Path.home() / ".meeting-noter.pid"
WATCHER_PID_FILE = Path.home() / ".meeting-noter-watcher.pid"
LOG_FILE = Path.home() / ".meeting-noter.log"


class StatusPollingWorker(QThread):
    """Polls daemon/watcher status periodically."""

    status_updated = Signal(bool, bool, str)  # watcher_running, daemon_running, meeting_name

    def __init__(self, interval_ms: int = 2000):
        super().__init__()
        self._stop_flag = False
        self._interval = interval_ms

    def run(self):
        """Poll status until stopped."""
        while not self._stop_flag:
            watcher = self._check_watcher()
            daemon, name = self._check_daemon()
            self.status_updated.emit(watcher, daemon, name or "")
            self.msleep(self._interval)

    def stop(self):
        """Stop the worker."""
        self._stop_flag = True
        self.wait()

    def _check_watcher(self) -> bool:
        """Check if watcher is running."""
        if WATCHER_PID_FILE.exists():
            try:
                pid = int(WATCHER_PID_FILE.read_text().strip())
                os.kill(pid, 0)
                return True
            except (ProcessLookupError, ValueError, FileNotFoundError, PermissionError):
                pass
        return False

    def _check_daemon(self) -> tuple[bool, Optional[str]]:
        """Check if daemon is running and get recording name."""
        daemon_pid = read_pid_file(DEFAULT_PID_FILE)
        if daemon_pid and is_process_running(daemon_pid):
            recording_name = self._get_current_recording_name()
            return True, recording_name
        return False, None

    def _get_current_recording_name(self) -> Optional[str]:
        """Get the name of the current recording from the log file."""
        if not LOG_FILE.exists():
            return None

        try:
            with open(LOG_FILE, "r") as f:
                lines = f.readlines()

            for line in reversed(lines[-50:]):
                if "Recording started:" in line:
                    parts = line.split("Recording started:")
                    if len(parts) > 1:
                        filename = parts[1].strip().replace(".mp3", "")
                        name_parts = filename.split("_", 2)
                        if len(name_parts) >= 3:
                            return name_parts[2]
                        return filename
                elif "Recording saved:" in line or "Recording discarded" in line:
                    break
            return None
        except Exception:
            return None


class LiveTranscriptWatcher(QThread):
    """Watches live transcript file for changes."""

    new_content = Signal(str)  # new text content
    file_changed = Signal(str)  # new file name
    recording_ended = Signal()

    def __init__(self, interval_ms: int = 500):
        super().__init__()
        self._stop_flag = False
        self._interval = interval_ms
        self._current_file: Optional[Path] = None
        self._last_content = ""
        self._last_mtime = 0.0

    def run(self):
        """Watch for live transcript updates."""
        while not self._stop_flag:
            self._check_live_transcript()
            self.msleep(self._interval)

    def stop(self):
        """Stop the worker."""
        self._stop_flag = True
        self.wait()

    def _check_live_transcript(self) -> None:
        """Check for live transcript updates."""
        config = get_config()
        live_dir = config.recordings_dir / "live"

        if not live_dir.exists():
            return

        # Find the most recent live file
        try:
            live_files = sorted(
                live_dir.glob("*.live.txt"),
                key=lambda p: p.stat().st_mtime,
                reverse=True,
            )
        except Exception:
            return

        if not live_files:
            if self._current_file is not None:
                self.recording_ended.emit()
                self._current_file = None
                self._last_content = ""
            return

        live_file = live_files[0]

        # Check if file is recent (active within last 30 seconds)
        try:
            file_mtime = live_file.stat().st_mtime
            if time.time() - file_mtime > 30:
                if self._current_file is not None:
                    self.recording_ended.emit()
                    self._current_file = None
                    self._last_content = ""
                return
        except Exception:
            return

        # Detect new file (new recording started)
        if self._current_file != live_file:
            self._current_file = live_file
            self._last_content = ""
            self._last_mtime = file_mtime
            meeting_name = live_file.stem.replace(".live", "")
            self.file_changed.emit(meeting_name)

        # Read and emit new content
        try:
            content = live_file.read_text()
            if len(content) > len(self._last_content):
                new_content = content[len(self._last_content) :]
                self.new_content.emit(new_content)
                self._last_content = content
        except Exception:
            pass


class TranscriptionWorker(QThread):
    """Runs transcription in background."""

    progress = Signal(str)  # status message
    finished = Signal(str)  # transcript path
    error = Signal(str)  # error message

    def __init__(self, audio_path: Path, model: str = ""):
        super().__init__()
        self._audio_path = audio_path
        self._model = model

    def run(self):
        """Run transcription."""
        import subprocess
        import sys

        try:
            self.progress.emit("Starting transcription...")

            cmd = [sys.executable, "-m", "meeting_noter.cli", "transcribe", str(self._audio_path)]
            if self._model:
                cmd.extend(["--model", self._model])

            result = subprocess.run(cmd, capture_output=True, text=True)

            if result.returncode == 0:
                # Extract transcript path from output
                output = result.stdout
                for line in output.splitlines():
                    if "Transcript saved:" in line:
                        path = line.split("Transcript saved:")[-1].strip()
                        self.finished.emit(path)
                        return
                self.finished.emit("")
            else:
                self.error.emit(result.stderr or "Transcription failed")

        except Exception as e:
            self.error.emit(str(e))


class LogWatcher(QThread):
    """Watches log file for new content."""

    new_content = Signal(str)  # new log lines

    def __init__(self, interval_ms: int = 1000):
        super().__init__()
        self._stop_flag = False
        self._interval = interval_ms
        self._last_size = 0

    def run(self):
        """Watch log file for changes."""
        while not self._stop_flag:
            self._check_log_file()
            self.msleep(self._interval)

    def stop(self):
        """Stop the worker."""
        self._stop_flag = True
        self.wait()

    def _check_log_file(self) -> None:
        """Check for new log content."""
        if not LOG_FILE.exists():
            return

        try:
            current_size = LOG_FILE.stat().st_size
            if current_size > self._last_size:
                with open(LOG_FILE, "r") as f:
                    f.seek(self._last_size)
                    new_content = f.read()
                    if new_content:
                        self.new_content.emit(new_content)
                self._last_size = current_size
            elif current_size < self._last_size:
                # File was truncated, reset
                self._last_size = 0
        except Exception:
            pass

    def reset(self):
        """Reset the file position."""
        self._last_size = 0
