"""Reusable widgets for Meeting Noter GUI."""

from meeting_noter.gui.widgets.sidebar import Sidebar
from meeting_noter.gui.widgets.status_indicator import StatusIndicator
from meeting_noter.gui.widgets.chat_panel import ChatPanel
from meeting_noter.gui.widgets.media_player import MediaPlayerWidget
from meeting_noter.gui.widgets.transcript_view import TranscriptView

__all__ = ["Sidebar", "StatusIndicator", "ChatPanel", "MediaPlayerWidget", "TranscriptView"]
