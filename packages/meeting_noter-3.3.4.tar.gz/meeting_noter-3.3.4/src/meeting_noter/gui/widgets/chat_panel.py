"""Chat panel widget for transcript Q&A."""

from __future__ import annotations

from pathlib import Path
from typing import Optional

from PySide6.QtCore import Qt, QThread, Signal
from PySide6.QtWidgets import (
    QFrame,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QVBoxLayout,
    QWidget,
)


class ChatWorker(QThread):
    """Worker thread for AI chat responses."""

    finished = Signal(str)  # response
    error = Signal(str)  # error message

    def __init__(self, chat_session, question: str):
        super().__init__()
        self.chat_session = chat_session
        self.question = question

    def run(self):
        try:
            response = self.chat_session.ask(self.question)
            self.finished.emit(response)
        except Exception as e:
            self.error.emit(str(e))


class ChatMessage(QFrame):
    """A single chat message bubble."""

    def __init__(self, text: str, is_user: bool = True, parent=None):
        super().__init__(parent)

        self.setStyleSheet(
            f"""
            QFrame {{
                background-color: {'#0e639c' if is_user else '#2d2d2d'};
                border-radius: 8px;
                padding: 8px;
            }}
            """
        )

        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 8, 10, 8)

        # Role label
        role = QLabel("You" if is_user else "AI")
        role.setStyleSheet(
            f"font-size: 10px; font-weight: 600; color: {'#ffffff' if is_user else '#4ec9b0'};"
        )
        layout.addWidget(role)

        # Message text
        message = QLabel(text)
        message.setWordWrap(True)
        message.setStyleSheet("color: #ffffff; font-size: 13px;")
        message.setTextInteractionFlags(Qt.TextSelectableByMouse)
        layout.addWidget(message)


class ChatPanel(QWidget):
    """Chat panel for asking questions about a transcript."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._chat_session = None
        self._worker: Optional[ChatWorker] = None
        self._setup_ui()

    def _setup_ui(self):
        """Set up the chat panel UI."""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(10)

        # Header
        header = QFrame()
        header.setStyleSheet("background-color: #252526; border-bottom: 1px solid #3c3c3c;")
        header_layout = QHBoxLayout(header)
        header_layout.setContentsMargins(10, 8, 10, 8)

        title = QLabel("AI Chat")
        title.setStyleSheet("font-size: 14px; font-weight: 600; color: #ffffff;")
        header_layout.addWidget(title)

        header_layout.addStretch()

        self._clear_btn = QPushButton("🗑️ Clear")
        self._clear_btn.setStyleSheet(
            """
            QPushButton {
                background-color: #3c3c3c;
                color: #ffffff;
                font-size: 12px;
                padding: 4px 12px;
                border-radius: 4px;
            }
            QPushButton:hover {
                background-color: #4c4c4c;
            }
            """
        )
        self._clear_btn.clicked.connect(self._clear_chat)
        header_layout.addWidget(self._clear_btn)

        layout.addWidget(header)

        # Chat messages area
        self._scroll_area = QScrollArea()
        self._scroll_area.setWidgetResizable(True)
        self._scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self._scroll_area.setStyleSheet(
            "QScrollArea { background-color: #1e1e1e; border: none; }"
        )

        self._messages_widget = QWidget()
        self._messages_layout = QVBoxLayout(self._messages_widget)
        self._messages_layout.setContentsMargins(10, 10, 10, 10)
        self._messages_layout.setSpacing(10)
        self._messages_layout.addStretch()

        self._scroll_area.setWidget(self._messages_widget)
        layout.addWidget(self._scroll_area, 1)

        # Status label (for loading, etc.)
        self._status_label = QLabel("")
        self._status_label.setStyleSheet("color: #858585; font-size: 11px; padding: 5px;")
        self._status_label.setVisible(False)
        layout.addWidget(self._status_label)

        # Input area
        input_frame = QFrame()
        input_frame.setStyleSheet("background-color: #252526; border-top: 1px solid #3c3c3c;")
        input_layout = QHBoxLayout(input_frame)
        input_layout.setContentsMargins(10, 10, 10, 10)
        input_layout.setSpacing(8)

        self._input = QLineEdit()
        self._input.setPlaceholderText("Ask a question about the meeting...")
        self._input.setStyleSheet(
            """
            QLineEdit {
                background-color: #3c3c3c;
                border: 1px solid #4c4c4c;
                border-radius: 4px;
                padding: 8px;
                color: #ffffff;
            }
            QLineEdit:focus {
                border-color: #0e639c;
            }
            """
        )
        self._input.returnPressed.connect(self._send_message)
        input_layout.addWidget(self._input, 1)

        self._send_btn = QPushButton("Send")
        self._send_btn.setStyleSheet("background-color: #0e639c; padding: 8px 16px;")
        self._send_btn.clicked.connect(self._send_message)
        input_layout.addWidget(self._send_btn)

        layout.addWidget(input_frame)

        # Initial state
        self._set_enabled(False)

    def set_transcript(self, transcript_path: Path):
        """Set the transcript to chat about."""
        from meeting_noter.analysis.installer import is_ai_installed

        if not is_ai_installed():
            self._show_status("AI not installed. Go to Settings to install.")
            self._set_enabled(False)
            return

        try:
            from meeting_noter.analysis.chat import TranscriptChat
            self._chat_session = TranscriptChat(transcript_path)
            self._clear_messages()
            self._set_enabled(True)
            self._show_status("")

            # Restore chat history from the session
            history = self._chat_session.get_history()
            if history:
                # Restore previous messages
                for msg in history:
                    self._add_message(msg["content"], is_user=(msg["role"] == "user"))
            else:
                # No history - show welcome message
                self._add_message(
                    f"Ask me anything about: {transcript_path.stem}",
                    is_user=False
                )
        except Exception as e:
            self._show_status(f"Error loading transcript: {e}")
            self._set_enabled(False)

    def _set_enabled(self, enabled: bool):
        """Enable or disable the chat input."""
        self._input.setEnabled(enabled)
        self._send_btn.setEnabled(enabled)
        self._clear_btn.setEnabled(enabled)

    def _show_status(self, message: str):
        """Show a status message."""
        if message:
            self._status_label.setText(message)
            self._status_label.setVisible(True)
        else:
            self._status_label.setVisible(False)

    def _add_message(self, text: str, is_user: bool = True):
        """Add a message to the chat."""
        # Insert before the stretch
        message = ChatMessage(text, is_user)
        self._messages_layout.insertWidget(
            self._messages_layout.count() - 1, message
        )

        # Scroll to bottom
        self._scroll_area.verticalScrollBar().setValue(
            self._scroll_area.verticalScrollBar().maximum()
        )

    def _clear_messages(self):
        """Clear all messages."""
        # Remove all widgets except the stretch
        while self._messages_layout.count() > 1:
            item = self._messages_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

    def _clear_chat(self):
        """Clear the chat history."""
        if self._chat_session:
            self._chat_session.clear_history()
        self._clear_messages()
        if self._chat_session:
            self._add_message(
                f"Chat cleared. Ask me anything!",
                is_user=False
            )

    def _send_message(self):
        """Send a message to the AI."""
        question = self._input.text().strip()
        if not question or not self._chat_session:
            return

        # Add user message
        self._add_message(question, is_user=True)
        self._input.clear()

        # Disable input while processing
        self._set_enabled(False)
        self._show_status("Thinking...")

        # Start worker thread
        self._worker = ChatWorker(self._chat_session, question)
        self._worker.finished.connect(self._on_response)
        self._worker.error.connect(self._on_error)
        self._worker.start()

    def _on_response(self, response: str):
        """Handle AI response."""
        self._add_message(response, is_user=False)
        self._set_enabled(True)
        self._show_status("")

    def _on_error(self, error: str):
        """Handle error."""
        self._show_status(f"Error: {error}")
        self._set_enabled(True)
