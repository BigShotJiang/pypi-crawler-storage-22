"""Media player widget for Meeting Noter GUI."""

from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Qt, Signal, Slot
from PySide6.QtMultimedia import QAudioOutput, QMediaPlayer
from PySide6.QtWidgets import (
    QComboBox,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QSlider,
    QWidget,
)


def format_time(ms: int) -> str:
    """Format milliseconds as MM:SS or HH:MM:SS."""
    total_seconds = ms // 1000
    hours = total_seconds // 3600
    minutes = (total_seconds % 3600) // 60
    seconds = total_seconds % 60

    if hours > 0:
        return f"{hours}:{minutes:02d}:{seconds:02d}"
    return f"{minutes}:{seconds:02d}"


class MediaPlayerWidget(QWidget):
    """Audio player widget with playback controls."""

    position_changed = Signal(int)  # Position in milliseconds
    playback_state_changed = Signal(bool)  # True if playing

    def __init__(self, parent=None):
        super().__init__(parent)
        self._duration_ms = 0
        self._is_seeking = False
        self._setup_player()
        self._setup_ui()
        self._connect_signals()

    def _setup_player(self):
        """Initialize the media player."""
        self._player = QMediaPlayer()
        self._audio_output = QAudioOutput()
        self._player.setAudioOutput(self._audio_output)
        self._audio_output.setVolume(1.0)

    def _setup_ui(self):
        """Set up the player UI."""
        layout = QHBoxLayout(self)
        layout.setContentsMargins(15, 10, 15, 10)
        layout.setSpacing(12)

        # Skip back 15s button
        self._skip_back_btn = QPushButton("15")
        self._skip_back_btn.setToolTip("Skip back 15 seconds")
        self._skip_back_btn.setFixedSize(36, 36)
        self._skip_back_btn.setStyleSheet(
            """
            QPushButton {
                background-color: #3c3c3c;
                border-radius: 18px;
                font-size: 11px;
                font-weight: 600;
            }
            QPushButton:hover {
                background-color: #4c4c4c;
            }
            QPushButton:pressed {
                background-color: #2c2c2c;
            }
            """
        )
        layout.addWidget(self._skip_back_btn)

        # Play/Pause button
        self._play_btn = QPushButton("\u25B6")  # Play triangle
        self._play_btn.setToolTip("Play/Pause (Space)")
        self._play_btn.setFixedSize(44, 44)
        self._play_btn.setStyleSheet(
            """
            QPushButton {
                background-color: #0e639c;
                border-radius: 22px;
                font-size: 16px;
            }
            QPushButton:hover {
                background-color: #1177bb;
            }
            QPushButton:pressed {
                background-color: #0d5a8c;
            }
            """
        )
        layout.addWidget(self._play_btn)

        # Skip forward 15s button
        self._skip_forward_btn = QPushButton("15")
        self._skip_forward_btn.setToolTip("Skip forward 15 seconds")
        self._skip_forward_btn.setFixedSize(36, 36)
        self._skip_forward_btn.setStyleSheet(
            """
            QPushButton {
                background-color: #3c3c3c;
                border-radius: 18px;
                font-size: 11px;
                font-weight: 600;
            }
            QPushButton:hover {
                background-color: #4c4c4c;
            }
            QPushButton:pressed {
                background-color: #2c2c2c;
            }
            """
        )
        layout.addWidget(self._skip_forward_btn)

        # Playback speed
        self._speed_combo = QComboBox()
        self._speed_combo.addItems(["0.5x", "0.75x", "1x", "1.25x", "1.5x", "2x"])
        self._speed_combo.setCurrentText("1x")
        self._speed_combo.setFixedWidth(70)
        self._speed_combo.setStyleSheet(
            """
            QComboBox {
                background-color: #3c3c3c;
                border: none;
                border-radius: 4px;
                padding: 4px 8px;
                font-size: 12px;
            }
            QComboBox:hover {
                background-color: #4c4c4c;
            }
            QComboBox::drop-down {
                border: none;
                width: 20px;
            }
            QComboBox::down-arrow {
                image: none;
                border-left: 4px solid transparent;
                border-right: 4px solid transparent;
                border-top: 5px solid #ffffff;
                margin-right: 5px;
            }
            """
        )
        layout.addWidget(self._speed_combo)

        # Current time label
        self._current_time_label = QLabel("0:00")
        self._current_time_label.setFixedWidth(50)
        self._current_time_label.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self._current_time_label.setStyleSheet("color: #ffffff; font-size: 12px;")
        layout.addWidget(self._current_time_label)

        # Position slider
        self._slider = QSlider(Qt.Horizontal)
        self._slider.setMinimum(0)
        self._slider.setMaximum(1000)
        self._slider.setValue(0)
        self._slider.setStyleSheet(
            """
            QSlider::groove:horizontal {
                background: #3c3c3c;
                height: 6px;
                border-radius: 3px;
            }
            QSlider::handle:horizontal {
                background: #ffffff;
                width: 14px;
                height: 14px;
                margin: -4px 0;
                border-radius: 7px;
            }
            QSlider::handle:horizontal:hover {
                background: #e0e0e0;
            }
            QSlider::sub-page:horizontal {
                background: #0e639c;
                border-radius: 3px;
            }
            """
        )
        layout.addWidget(self._slider, 1)

        # Total time label
        self._total_time_label = QLabel("0:00")
        self._total_time_label.setFixedWidth(50)
        self._total_time_label.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        self._total_time_label.setStyleSheet("color: #858585; font-size: 12px;")
        layout.addWidget(self._total_time_label)

        # Set fixed height for the widget
        self.setFixedHeight(64)
        self.setStyleSheet(
            """
            MediaPlayerWidget {
                background-color: #252526;
                border-top: 1px solid #3c3c3c;
            }
            """
        )

    def _connect_signals(self):
        """Connect signals and slots."""
        # Player signals
        self._player.positionChanged.connect(self._on_position_changed)
        self._player.durationChanged.connect(self._on_duration_changed)
        self._player.playbackStateChanged.connect(self._on_playback_state_changed)

        # UI signals
        self._play_btn.clicked.connect(self.toggle)
        self._skip_back_btn.clicked.connect(self._skip_back)
        self._skip_forward_btn.clicked.connect(self._skip_forward)
        self._speed_combo.currentTextChanged.connect(self._on_speed_changed)

        # Slider signals
        self._slider.sliderPressed.connect(self._on_slider_pressed)
        self._slider.sliderReleased.connect(self._on_slider_released)
        self._slider.sliderMoved.connect(self._on_slider_moved)

    def load(self, path: Path):
        """Load an audio file."""
        from PySide6.QtCore import QUrl

        self._player.setSource(QUrl.fromLocalFile(str(path)))
        self._player.setPosition(0)

    def play(self):
        """Start playback."""
        self._player.play()

    def pause(self):
        """Pause playback."""
        self._player.pause()

    def toggle(self):
        """Toggle play/pause."""
        if self._player.playbackState() == QMediaPlayer.PlayingState:
            self.pause()
        else:
            self.play()

    def seek(self, position_ms: int):
        """Seek to a position in milliseconds."""
        self._player.setPosition(position_ms)

    def seek_seconds(self, seconds: int):
        """Seek to a position in seconds."""
        self.seek(seconds * 1000)

    def set_speed(self, rate: float):
        """Set playback speed."""
        self._player.setPlaybackRate(rate)
        # Update combo box if called programmatically
        speed_text = f"{rate}x"
        if self._speed_combo.currentText() != speed_text:
            self._speed_combo.setCurrentText(speed_text)

    def get_position_ms(self) -> int:
        """Get current position in milliseconds."""
        return self._player.position()

    def get_duration_ms(self) -> int:
        """Get total duration in milliseconds."""
        return self._duration_ms

    def is_playing(self) -> bool:
        """Check if currently playing."""
        return self._player.playbackState() == QMediaPlayer.PlayingState

    @Slot(int)
    def _on_position_changed(self, position: int):
        """Handle position changes from the player."""
        if not self._is_seeking:
            self._current_time_label.setText(format_time(position))
            if self._duration_ms > 0:
                slider_pos = int((position / self._duration_ms) * 1000)
                self._slider.setValue(slider_pos)

        self.position_changed.emit(position)

    @Slot(int)
    def _on_duration_changed(self, duration: int):
        """Handle duration changes from the player."""
        self._duration_ms = duration
        self._total_time_label.setText(format_time(duration))

    @Slot(QMediaPlayer.PlaybackState)
    def _on_playback_state_changed(self, state: QMediaPlayer.PlaybackState):
        """Handle playback state changes."""
        is_playing = state == QMediaPlayer.PlayingState
        self._play_btn.setText("\u23F8" if is_playing else "\u25B6")  # Pause or Play
        self.playback_state_changed.emit(is_playing)

    def _on_slider_pressed(self):
        """Handle slider press - start seeking."""
        self._is_seeking = True

    def _on_slider_released(self):
        """Handle slider release - commit seek."""
        self._is_seeking = False
        if self._duration_ms > 0:
            position = int((self._slider.value() / 1000) * self._duration_ms)
            self._player.setPosition(position)

    def _on_slider_moved(self, value: int):
        """Handle slider drag - update time display."""
        if self._duration_ms > 0:
            position = int((value / 1000) * self._duration_ms)
            self._current_time_label.setText(format_time(position))

    def _skip_back(self):
        """Skip back 15 seconds."""
        new_pos = max(0, self._player.position() - 15000)
        self._player.setPosition(new_pos)

    def _skip_forward(self):
        """Skip forward 15 seconds."""
        new_pos = min(self._duration_ms, self._player.position() + 15000)
        self._player.setPosition(new_pos)

    def _on_speed_changed(self, text: str):
        """Handle speed combo box changes."""
        rate = float(text.replace("x", ""))
        self._player.setPlaybackRate(rate)

    def stop(self):
        """Stop playback and reset position."""
        self._player.stop()
        self._player.setPosition(0)
