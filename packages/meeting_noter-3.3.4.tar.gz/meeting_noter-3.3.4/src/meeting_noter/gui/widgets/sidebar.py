"""Navigation sidebar widget for Meeting Noter GUI."""

from __future__ import annotations

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QFont
from PySide6.QtWidgets import (
    QButtonGroup,
    QFrame,
    QLabel,
    QPushButton,
    QSizePolicy,
    QSpacerItem,
    QVBoxLayout,
    QWidget,
)


class SidebarButton(QPushButton):
    """A navigation button for the sidebar."""

    def __init__(self, text: str, icon: str = "", parent=None):
        super().__init__(parent)
        display_text = f"  {icon}   {text}" if icon else f"  {text}"
        self.setText(display_text)
        self.setCheckable(True)
        self.setMinimumHeight(50)
        self.setCursor(Qt.PointingHandCursor)


class Sidebar(QWidget):
    """Navigation sidebar with icon buttons."""

    screen_selected = Signal(str)  # Emits screen name when clicked
    quit_requested = Signal()  # Emits when quit button clicked

    # Navigation items with better Unicode icons
    NAV_ITEMS = [
        ("dashboard", "Dashboard", "⌂"),  # Home
        ("meetings", "Meetings", "▦"),  # Calendar grid
        ("recordings", "Recordings", "◉"),  # Record
        ("search", "Search", "⌕"),  # Search
        ("settings", "Settings", "⚙"),  # Gear
        ("logs", "Logs", "☰"),  # Menu/logs
    ]

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("sidebar")
        self.setMinimumWidth(220)
        self.setMaximumWidth(220)

        self._setup_ui()
        self._connect_signals()

    def _setup_ui(self):
        """Set up the sidebar UI."""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # Title/Logo area
        title_frame = QFrame()
        title_frame.setObjectName("sidebar-title-frame")
        title_layout = QVBoxLayout(title_frame)
        title_layout.setContentsMargins(20, 20, 20, 20)

        title = QLabel("Meeting Noter")
        title.setObjectName("sidebar-title")
        title_font = QFont("Menlo, Monaco, Courier New, monospace", 18)
        title_font.setBold(True)
        title.setFont(title_font)
        title.setAlignment(Qt.AlignCenter)
        title_layout.addWidget(title)

        subtitle = QLabel("v2.0")
        subtitle.setObjectName("sidebar-subtitle")
        subtitle.setAlignment(Qt.AlignCenter)
        subtitle.setStyleSheet("color: #5a5a5a; font-size: 12px;")
        title_layout.addWidget(subtitle)

        layout.addWidget(title_frame)

        # Separator
        separator = QFrame()
        separator.setFrameShape(QFrame.HLine)
        separator.setStyleSheet("background-color: #3c3c3c; max-height: 1px;")
        layout.addWidget(separator)

        # Navigation section label
        nav_label = QLabel("  NAVIGATION")
        nav_label.setObjectName("sidebar-section-label")
        nav_label.setStyleSheet(
            "color: #5a5a5a; font-size: 11px; font-weight: 600; "
            "letter-spacing: 1px; padding: 15px 0 5px 15px;"
        )
        layout.addWidget(nav_label)

        # Navigation buttons
        self._button_group = QButtonGroup(self)
        self._button_group.setExclusive(True)
        self._buttons: dict[str, SidebarButton] = {}

        button_font = QFont("Menlo, Monaco, Courier New, monospace", 14)

        for screen_id, label, icon in self.NAV_ITEMS:
            btn = SidebarButton(label, icon)
            btn.setFont(button_font)
            btn.setProperty("screen_id", screen_id)
            self._buttons[screen_id] = btn
            self._button_group.addButton(btn)
            layout.addWidget(btn)

        # Spacer
        layout.addItem(QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding))

        # Status area at bottom
        separator2 = QFrame()
        separator2.setFrameShape(QFrame.HLine)
        separator2.setStyleSheet("background-color: #3c3c3c; max-height: 1px;")
        layout.addWidget(separator2)

        self._status_frame = QFrame()
        self._status_frame.setObjectName("sidebar-status")
        status_layout = QVBoxLayout(self._status_frame)
        status_layout.setContentsMargins(15, 15, 15, 15)

        status_label = QLabel("STATUS")
        status_label.setStyleSheet(
            "color: #5a5a5a; font-size: 11px; font-weight: 600; letter-spacing: 1px;"
        )
        status_layout.addWidget(status_label)

        self._status_text = QLabel("● Idle")
        self._status_text.setObjectName("sidebar-status-text")
        status_font = QFont("Menlo, Monaco, Courier New, monospace", 13)
        self._status_text.setFont(status_font)
        self._status_text.setStyleSheet("color: #5a5a5a; padding-top: 5px;")
        status_layout.addWidget(self._status_text)

        layout.addWidget(self._status_frame)

        # Quit button at bottom
        separator3 = QFrame()
        separator3.setFrameShape(QFrame.HLine)
        separator3.setStyleSheet("background-color: #3c3c3c; max-height: 1px;")
        layout.addWidget(separator3)

        self._quit_btn = QPushButton("  ⏻   Quit")
        self._quit_btn.setFont(button_font)
        self._quit_btn.setMinimumHeight(50)
        self._quit_btn.setCursor(Qt.PointingHandCursor)
        self._quit_btn.setStyleSheet("""
            QPushButton {
                background-color: transparent;
                border: none;
                border-radius: 6px;
                padding: 12px 15px;
                text-align: left;
                color: #808080;
                font-size: 14px;
                margin: 3px 10px;
            }
            QPushButton:hover {
                background-color: #2a1a1a;
                color: #f14c4c;
            }
        """)
        layout.addWidget(self._quit_btn)

        # Bottom padding
        layout.addSpacing(10)

        # Select dashboard by default
        self._buttons["dashboard"].setChecked(True)

    def _connect_signals(self):
        """Connect button signals."""
        for btn in self._buttons.values():
            btn.clicked.connect(self._on_button_clicked)
        self._quit_btn.clicked.connect(self._on_quit_clicked)

    def _on_button_clicked(self):
        """Handle navigation button click."""
        btn = self.sender()
        if btn:
            screen_id = btn.property("screen_id")
            self.screen_selected.emit(screen_id)

    def _on_quit_clicked(self):
        """Handle quit button click."""
        self.quit_requested.emit()

    def select_screen(self, screen_id: str):
        """Programmatically select a screen."""
        if screen_id in self._buttons:
            self._buttons[screen_id].setChecked(True)

    def update_status(self, is_recording: bool, meeting_name: str = ""):
        """Update the status display."""
        if is_recording:
            if meeting_name:
                display_name = meeting_name[:18] + "..." if len(meeting_name) > 18 else meeting_name
                status = f"● {display_name}"
            else:
                status = "● Recording..."
            self._status_text.setStyleSheet("color: #f14c4c; padding-top: 5px;")
        else:
            status = "● Idle"
            self._status_text.setStyleSheet("color: #5a5a5a; padding-top: 5px;")
        self._status_text.setText(status)
