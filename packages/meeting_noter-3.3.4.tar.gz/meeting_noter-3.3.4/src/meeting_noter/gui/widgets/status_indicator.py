"""Status indicator widget for Meeting Noter GUI."""

from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtGui import QFont
from PySide6.QtWidgets import QHBoxLayout, QLabel, QVBoxLayout, QWidget

from meeting_noter.gui.theme.dark_theme import COLORS


class StatusIndicator(QWidget):
    """Widget to display current recording status."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("status-indicator")
        self._setup_ui()
        self._set_idle_state()

    def _setup_ui(self):
        """Set up the status indicator UI."""
        self.setStyleSheet(
            "background-color: #0d0d0d; border: 1px solid #2a2a2a; border-radius: 8px;"
        )

        layout = QHBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(20)

        # Status dot
        self._dot = QLabel("●")
        self._dot.setObjectName("status-dot")
        self._dot.setAlignment(Qt.AlignCenter)
        dot_font = QFont("Menlo, Monaco, Courier New, monospace", 32)
        self._dot.setFont(dot_font)
        layout.addWidget(self._dot)

        # Status text container
        text_container = QWidget()
        text_container.setStyleSheet("background-color: transparent; border: none;")
        text_layout = QVBoxLayout(text_container)
        text_layout.setContentsMargins(0, 0, 0, 0)
        text_layout.setSpacing(4)

        self._status_text = QLabel("Stopped")
        self._status_text.setObjectName("status-text")
        status_font = QFont("Menlo, Monaco, Courier New, monospace", 18)
        status_font.setBold(True)
        self._status_text.setFont(status_font)
        text_layout.addWidget(self._status_text)

        self._details_text = QLabel("Watcher: stopped | Recorder: idle")
        self._details_text.setObjectName("status-details")
        details_font = QFont("Menlo, Monaco, Courier New, monospace", 12)
        self._details_text.setFont(details_font)
        self._details_text.setStyleSheet("color: #808080; background-color: transparent;")
        text_layout.addWidget(self._details_text)

        layout.addWidget(text_container)
        layout.addStretch()

    def _set_idle_state(self):
        """Set the idle/stopped state."""
        self._dot.setStyleSheet(f"color: #5a5a5a; background-color: transparent;")
        self._status_text.setText("Stopped")
        self._status_text.setStyleSheet("color: #808080; background-color: transparent;")
        self._details_text.setText("Watcher: stopped | Recorder: idle")

    def update_status(
        self, watcher_running: bool, daemon_running: bool, meeting_name: str = ""
    ):
        """Update the status display."""
        if daemon_running:
            # Recording state - red
            self._dot.setStyleSheet("color: #f14c4c; background-color: transparent;")
            self._status_text.setStyleSheet("color: #f14c4c; background-color: transparent;")
            if meeting_name:
                self._status_text.setText(f"Recording: {meeting_name}")
            else:
                self._status_text.setText("Recording...")
        elif watcher_running:
            # Ready state - green
            self._dot.setStyleSheet("color: #4ec9b0; background-color: transparent;")
            self._status_text.setStyleSheet("color: #4ec9b0; background-color: transparent;")
            self._status_text.setText("Ready (watcher active)")
        else:
            # Stopped state - gray
            self._dot.setStyleSheet("color: #5a5a5a; background-color: transparent;")
            self._status_text.setStyleSheet("color: #808080; background-color: transparent;")
            self._status_text.setText("Stopped")

        # Update details
        watcher_status = "running" if watcher_running else "stopped"
        recorder_status = "recording" if daemon_running else "idle"
        self._details_text.setText(f"Watcher: {watcher_status} | Recorder: {recorder_status}")

    def set_recording(self, meeting_name: str = ""):
        """Set recording state."""
        self.update_status(False, True, meeting_name)

    def set_ready(self):
        """Set ready (watcher active) state."""
        self.update_status(True, False)

    def set_stopped(self):
        """Set stopped state."""
        self.update_status(False, False)
