"""Transcript view widget with clickable segments for Meeting Noter GUI."""

from __future__ import annotations

import re
from dataclasses import dataclass

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QFrame,
    QHBoxLayout,
    QLabel,
    QScrollArea,
    QVBoxLayout,
    QWidget,
)


@dataclass
class TranscriptSegment:
    """A segment of the transcript with timestamp."""

    timestamp_seconds: int
    text: str


def parse_transcript(text: str) -> tuple[str, list[TranscriptSegment]]:
    """Parse transcript text into header and segments.

    Returns:
        Tuple of (header_text, list_of_segments)
    """
    # Pattern matches [MM:SS] or [HH:MM:SS] at the start of a line
    pattern = r"^\[(\d{1,2}):(\d{2})(?::(\d{2}))?\]\s*(.+)$"

    lines = text.split("\n")
    header_lines = []
    segments = []
    in_header = True

    for line in lines:
        match = re.match(pattern, line)
        if match:
            in_header = False
            groups = match.groups()
            # groups: (first_num, second_num, optional_third_num, text)
            if groups[2] is not None:
                # Format is [HH:MM:SS]
                hours = int(groups[0])
                mins = int(groups[1])
                secs = int(groups[2])
            else:
                # Format is [MM:SS]
                hours = 0
                mins = int(groups[0])
                secs = int(groups[1])

            total_seconds = hours * 3600 + mins * 60 + secs
            segments.append(TranscriptSegment(total_seconds, groups[3].strip()))
        elif in_header:
            header_lines.append(line)

    header = "\n".join(header_lines).strip()
    return header, segments


def format_timestamp(seconds: int) -> str:
    """Format seconds as MM:SS or HH:MM:SS."""
    hours = seconds // 3600
    mins = (seconds % 3600) // 60
    secs = seconds % 60

    if hours > 0:
        return f"{hours}:{mins:02d}:{secs:02d}"
    return f"{mins}:{secs:02d}"


class SegmentWidget(QFrame):
    """A clickable transcript segment widget."""

    clicked = Signal(int)  # Emits timestamp in seconds

    def __init__(self, segment: TranscriptSegment, parent=None):
        super().__init__(parent)
        self._segment = segment
        self._is_current = False
        self._is_search_match = False
        self._original_text = segment.text
        self._setup_ui()
        self._update_style()

    def _setup_ui(self):
        """Set up the segment UI."""
        layout = QHBoxLayout(self)
        layout.setContentsMargins(12, 8, 12, 8)
        layout.setSpacing(12)

        # Timestamp label
        self._timestamp_label = QLabel(format_timestamp(self._segment.timestamp_seconds))
        self._timestamp_label.setFixedWidth(50)
        self._timestamp_label.setAlignment(Qt.AlignRight | Qt.AlignTop)
        self._timestamp_label.setStyleSheet("color: #858585; font-size: 12px;")
        layout.addWidget(self._timestamp_label)

        # Text label
        self._text_label = QLabel(self._segment.text)
        self._text_label.setWordWrap(True)
        self._text_label.setTextFormat(Qt.RichText)
        self._text_label.setStyleSheet("color: #ffffff; font-size: 13px; line-height: 1.4;")
        layout.addWidget(self._text_label, 1)

        self.setCursor(Qt.PointingHandCursor)

    def _update_style(self):
        """Update the widget style based on current state."""
        if self._is_current:
            self.setStyleSheet(
                """
                SegmentWidget {
                    background-color: #264f78;
                    border-left: 3px solid #0e639c;
                    border-radius: 4px;
                }
                """
            )
        else:
            self.setStyleSheet(
                """
                SegmentWidget {
                    background-color: transparent;
                    border-left: 3px solid transparent;
                    border-radius: 4px;
                }
                SegmentWidget:hover {
                    background-color: #2a2d2e;
                }
                """
            )

    def set_current(self, is_current: bool):
        """Set whether this segment is the currently playing one."""
        if self._is_current != is_current:
            self._is_current = is_current
            self._update_style()

    def is_current(self) -> bool:
        """Check if this is the current segment."""
        return self._is_current

    @property
    def timestamp_seconds(self) -> int:
        """Get the segment's timestamp in seconds."""
        return self._segment.timestamp_seconds

    @property
    def text(self) -> str:
        """Get the segment's text."""
        return self._original_text

    def highlight_search(self, search_text: str, is_current_match: bool = False):
        """Highlight search matches in the segment text."""
        if not search_text:
            self._text_label.setText(self._original_text)
            self._is_search_match = False
            self._update_style()
            return False

        # Case-insensitive search
        text_lower = self._original_text.lower()
        search_lower = search_text.lower()

        if search_lower not in text_lower:
            self._text_label.setText(self._original_text)
            self._is_search_match = False
            self._update_style()
            return False

        # Highlight all occurrences
        self._is_search_match = True
        highlighted = self._original_text

        # Find and replace with highlighting (case-insensitive but preserve original case)
        idx = 0
        result = ""
        text_lower = self._original_text.lower()
        while idx < len(self._original_text):
            match_idx = text_lower.find(search_lower, idx)
            if match_idx == -1:
                result += self._original_text[idx:]
                break
            result += self._original_text[idx:match_idx]
            matched_text = self._original_text[match_idx:match_idx + len(search_text)]
            if is_current_match:
                result += f'<span style="background-color: #0e639c; color: #ffffff; padding: 1px 2px;">{matched_text}</span>'
            else:
                result += f'<span style="background-color: #665c00; color: #ffffff; padding: 1px 2px;">{matched_text}</span>'
            idx = match_idx + len(search_text)

        self._text_label.setText(result)
        self._update_style()
        return True

    def clear_highlight(self):
        """Clear search highlighting."""
        self._text_label.setText(self._original_text)
        self._is_search_match = False
        self._update_style()

    def mousePressEvent(self, event):
        """Handle mouse press to emit clicked signal."""
        if event.button() == Qt.LeftButton:
            self.clicked.emit(self._segment.timestamp_seconds)
        super().mousePressEvent(event)


class TranscriptView(QScrollArea):
    """Scrollable view of transcript segments."""

    segment_clicked = Signal(int)  # Emits timestamp in seconds

    def __init__(self, parent=None):
        super().__init__(parent)
        self._segments: list[SegmentWidget] = []
        self._current_index = -1
        self._header_text = ""
        self._setup_ui()

    def _setup_ui(self):
        """Set up the scroll area."""
        self.setWidgetResizable(True)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.setStyleSheet(
            """
            QScrollArea {
                background-color: #1e1e1e;
                border: none;
            }
            QScrollBar:vertical {
                background-color: #1e1e1e;
                width: 10px;
                margin: 0;
            }
            QScrollBar::handle:vertical {
                background-color: #424242;
                min-height: 30px;
                border-radius: 5px;
            }
            QScrollBar::handle:vertical:hover {
                background-color: #525252;
            }
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
                height: 0;
            }
            """
        )

        # Container widget
        self._container = QWidget()
        self._layout = QVBoxLayout(self._container)
        self._layout.setContentsMargins(10, 10, 10, 10)
        self._layout.setSpacing(4)
        self._layout.addStretch()

        self.setWidget(self._container)

    def load(self, transcript_text: str):
        """Load transcript text and create segment widgets."""
        # Clear existing segments
        self.clear()

        # Parse transcript
        self._header_text, segments = parse_transcript(transcript_text)

        # Add header if present
        if self._header_text:
            header_label = QLabel(self._header_text)
            header_label.setWordWrap(True)
            header_label.setStyleSheet(
                """
                color: #858585;
                font-size: 12px;
                padding: 10px;
                background-color: #252526;
                border-radius: 4px;
                """
            )
            self._layout.insertWidget(self._layout.count() - 1, header_label)

            # Add separator
            separator = QFrame()
            separator.setFixedHeight(1)
            separator.setStyleSheet("background-color: #3c3c3c;")
            self._layout.insertWidget(self._layout.count() - 1, separator)

        # Create segment widgets
        for segment in segments:
            widget = SegmentWidget(segment)
            widget.clicked.connect(self._on_segment_clicked)
            self._segments.append(widget)
            self._layout.insertWidget(self._layout.count() - 1, widget)

        self._current_index = -1

    def clear(self):
        """Clear all segments."""
        for segment in self._segments:
            segment.deleteLater()
        self._segments.clear()

        # Clear layout except stretch
        while self._layout.count() > 1:
            item = self._layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        self._current_index = -1
        self._header_text = ""

    def set_current_position(self, position_ms: int):
        """Update the current segment based on playback position."""
        position_sec = position_ms // 1000
        new_index = self._find_segment_for_position(position_sec)

        if new_index != self._current_index:
            # Update previous segment
            if 0 <= self._current_index < len(self._segments):
                self._segments[self._current_index].set_current(False)

            # Update new segment
            self._current_index = new_index
            if 0 <= new_index < len(self._segments):
                self._segments[new_index].set_current(True)
                self._scroll_to_segment(new_index)

    def _find_segment_for_position(self, position_sec: int) -> int:
        """Find the segment index for a given position in seconds."""
        if not self._segments:
            return -1

        for i, segment in enumerate(self._segments):
            if i + 1 < len(self._segments):
                next_timestamp = self._segments[i + 1].timestamp_seconds
                if segment.timestamp_seconds <= position_sec < next_timestamp:
                    return i
            else:
                # Last segment
                if position_sec >= segment.timestamp_seconds:
                    return i

        return 0 if self._segments else -1

    def _scroll_to_segment(self, index: int):
        """Scroll to make the segment visible."""
        if 0 <= index < len(self._segments):
            widget = self._segments[index]
            self.ensureWidgetVisible(widget, 50, 100)

    def _on_segment_clicked(self, timestamp_seconds: int):
        """Handle segment click."""
        self.segment_clicked.emit(timestamp_seconds)

    def get_segment_count(self) -> int:
        """Get the number of segments."""
        return len(self._segments)

    def has_segments(self) -> bool:
        """Check if there are any parsed segments."""
        return len(self._segments) > 0

    def get_header(self) -> str:
        """Get the transcript header text."""
        return self._header_text

    # Search functionality
    def search(self, text: str) -> int:
        """Search for text in all segments. Returns number of matches."""
        self._search_text = text
        self._search_matches: list[int] = []  # Indices of matching segments
        self._search_current_match = -1

        if not text:
            self.clear_search()
            return 0

        # Find all matching segments
        for i, segment in enumerate(self._segments):
            if segment.highlight_search(text, is_current_match=False):
                self._search_matches.append(i)

        if self._search_matches:
            # Highlight the first match as current
            self._search_current_match = 0
            self._segments[self._search_matches[0]].highlight_search(text, is_current_match=True)
            self._scroll_to_segment(self._search_matches[0])

        return len(self._search_matches)

    def search_next(self) -> int:
        """Go to next search match. Returns current match number (1-indexed) or 0 if none."""
        if not self._search_matches:
            return 0

        # Un-highlight current match
        if self._search_current_match >= 0:
            current_idx = self._search_matches[self._search_current_match]
            self._segments[current_idx].highlight_search(self._search_text, is_current_match=False)

        # Move to next match (wrap around)
        self._search_current_match = (self._search_current_match + 1) % len(self._search_matches)

        # Highlight new current match
        new_idx = self._search_matches[self._search_current_match]
        self._segments[new_idx].highlight_search(self._search_text, is_current_match=True)
        self._scroll_to_segment(new_idx)

        return self._search_current_match + 1

    def search_prev(self) -> int:
        """Go to previous search match. Returns current match number (1-indexed) or 0 if none."""
        if not self._search_matches:
            return 0

        # Un-highlight current match
        if self._search_current_match >= 0:
            current_idx = self._search_matches[self._search_current_match]
            self._segments[current_idx].highlight_search(self._search_text, is_current_match=False)

        # Move to previous match (wrap around)
        self._search_current_match = (self._search_current_match - 1) % len(self._search_matches)

        # Highlight new current match
        new_idx = self._search_matches[self._search_current_match]
        self._segments[new_idx].highlight_search(self._search_text, is_current_match=True)
        self._scroll_to_segment(new_idx)

        return self._search_current_match + 1

    def clear_search(self):
        """Clear all search highlighting."""
        self._search_text = ""
        self._search_matches = []
        self._search_current_match = -1

        for segment in self._segments:
            segment.clear_highlight()

    def get_search_match_count(self) -> int:
        """Get the number of search matches."""
        return len(getattr(self, '_search_matches', []))

    def get_current_search_match(self) -> int:
        """Get current match number (1-indexed) or 0 if none."""
        if not getattr(self, '_search_matches', []):
            return 0
        return getattr(self, '_search_current_match', -1) + 1
