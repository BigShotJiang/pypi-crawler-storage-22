"""Output handling for recordings and transcripts."""

from __future__ import annotations

import re
import click
from pathlib import Path
from datetime import datetime
from typing import Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from meeting_noter.config import Config


def format_duration(seconds: float) -> str:
    """Format duration as human-readable string."""
    if seconds < 60:
        return f"{seconds:.0f}s"
    elif seconds < 3600:
        minutes = int(seconds // 60)
        secs = int(seconds % 60)
        return f"{minutes}m {secs}s"
    else:
        hours = int(seconds // 3600)
        minutes = int((seconds % 3600) // 60)
        return f"{hours}h {minutes}m"


def format_size(bytes: int) -> str:
    """Format file size as human-readable string."""
    if bytes < 1024:
        return f"{bytes} B"
    elif bytes < 1024 * 1024:
        return f"{bytes / 1024:.1f} KB"
    else:
        return f"{bytes / (1024 * 1024):.1f} MB"


def get_audio_duration(filepath: Path) -> Optional[float]:
    """Get duration of an audio file in seconds.

    Uses a simple estimation based on file size and bitrate.
    """
    try:
        # Rough estimation: 128kbps MP3 = 16KB per second
        size = filepath.stat().st_size
        return size / (128 * 1000 / 8)  # 128kbps = 16000 bytes/sec
    except:
        return None


def list_recordings(output_dir: Path, limit: int = 10, config: Optional["Config"] = None):
    """List recent meeting recordings."""
    if not output_dir.exists():
        click.echo(click.style(f"Directory not found: {output_dir}", fg="red"))
        return

    # Find all MP3 files
    mp3_files = sorted(
        output_dir.glob("*.mp3"),
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )

    if not mp3_files:
        click.echo(click.style("No recordings found.", fg="yellow"))
        click.echo(f"\nRecordings directory: {output_dir}")
        click.echo("Run 'meeting-noter daemon' to start capturing audio.")
        return

    click.echo(f"\nRecent recordings in {output_dir}:\n")

    # Show header
    click.echo(f"  {'Date':<20} {'Duration':<12} {'Size':<10} {'Transcript':<12} File")
    click.echo("  " + "-" * 75)

    for mp3 in mp3_files[:limit]:
        # Get file info
        stat = mp3.stat()
        mod_time = datetime.fromtimestamp(stat.st_mtime)
        date_str = mod_time.strftime("%Y-%m-%d %H:%M")

        # Duration estimate
        duration = get_audio_duration(mp3)
        duration_str = format_duration(duration) if duration else "?"

        # File size
        size_str = format_size(stat.st_size)

        # Check for transcript in transcripts directory
        transcript_name = mp3.stem + ".txt"
        transcript_path = config.transcripts_dir / transcript_name if config else mp3.with_suffix(".txt")
        has_transcript = click.style("Yes", fg="green") if transcript_path.exists() else click.style("No", fg="yellow")

        click.echo(f"  {date_str:<20} {duration_str:<12} {size_str:<10} {has_transcript:<12} {mp3.name}")

        # Show tags if config is provided and file has tags
        if config:
            file_tags = config.get_tags(mp3.name)
            if file_tags:
                tags_str = ", ".join(file_tags)
                click.echo(click.style(f"    Tags: {tags_str}", fg="cyan"))

    if len(mp3_files) > limit:
        click.echo(f"\n  ... and {len(mp3_files) - limit} more recordings")

    click.echo(f"\nTotal: {len(mp3_files)} recordings")
    click.echo("\nTo transcribe: meeting-noter transcribe [filename]")


def sanitize_filename(name: str, max_length: int = 50) -> str:
    """Sanitize a string for use as a filename.

    Args:
        name: The name to sanitize
        max_length: Maximum length for the sanitized name

    Returns:
        A safe filename string with spaces replaced by underscores
    """
    # Replace spaces with underscores
    name = name.replace(" ", "_")
    # Remove any character that isn't alphanumeric, underscore, or hyphen
    name = re.sub(r"[^\w\-]", "", name)
    # Truncate to max length
    if len(name) > max_length:
        name = name[:max_length]
    # Remove trailing underscores/hyphens
    name = name.rstrip("_-")
    return name


def extract_timestamp_prefix(filename: str) -> Optional[str]:
    """Extract the timestamp prefix from a recording filename.

    Handles formats like:
    - 2025-01-29_143015_Meeting_Name.mp3 -> 2025-01-29_143015
    - 2025-01-29_143015.mp3 -> 2025-01-29_143015
    - 29_Jan_2026_1430_Meeting_Name.mp3 -> 29_Jan_2026_1430

    Returns:
        The timestamp prefix or None if not found
    """
    # Pattern 1: YYYY-MM-DD_HHMMSS format
    match = re.match(r"^(\d{4}-\d{2}-\d{2}_\d{6})", filename)
    if match:
        return match.group(1)

    # Pattern 2: DD_Mon_YYYY_HHMM format
    match = re.match(r"^(\d{2}_[A-Z][a-z]{2}_\d{4}_\d{4})", filename)
    if match:
        return match.group(1)

    return None


def extract_meeting_name(filename: str) -> str:
    """Extract a clean, human-readable meeting name from a recording filename.

    Handles formats like:
    - 2025-01-29_143015_Meeting_Name.mp3 -> Meeting Name
    - 04_Feb_2026_1606_Team_sync.mp3 -> Team Sync
    - 2026-02-02_143245_Core_Conversion_Internal.mp3 -> Core Conversion Internal
    - 04_Feb_2026_1534.mp3 -> Meeting (default when no name)
    - CamelCaseNames -> Camel Case Names

    Returns:
        A clean, title-cased meeting name
    """
    # Remove extension
    stem = filename
    if stem.endswith('.mp3'):
        stem = stem[:-4]
    if stem.endswith('.txt'):
        stem = stem[:-4]

    # Extract timestamp prefix
    timestamp = extract_timestamp_prefix(stem)

    if timestamp:
        # Remove timestamp prefix and leading underscore
        name = stem[len(timestamp):]
        if name.startswith('_'):
            name = name[1:]
    else:
        name = stem

    # If no name after timestamp, use default
    if not name:
        return "Meeting"

    # Split camelCase into separate words (e.g., "CoreConversion" -> "Core Conversion")
    # Insert space before uppercase letters that follow lowercase letters
    result = []
    for i, char in enumerate(name):
        if i > 0 and char.isupper() and name[i-1].islower():
            result.append(' ')
        result.append(char)
    name = ''.join(result)

    # Replace underscores and hyphens with spaces
    name = name.replace('_', ' ').replace('-', ' ')

    # Collapse multiple spaces
    while '  ' in name:
        name = name.replace('  ', ' ')

    # Title case (capitalize first letter of each word)
    name = name.strip().title()

    return name


def rename_meeting(
    old_path: Path,
    new_name: str,
    config: "Config",
) -> Path:
    """Rename a meeting recording and its associated transcript.

    Args:
        old_path: Path to the current MP3 file
        new_name: New meeting name (will be sanitized)
        config: Config object for updating favorites

    Returns:
        Path to the renamed MP3 file

    Raises:
        FileNotFoundError: If the recording doesn't exist
        FileExistsError: If the new filename already exists
        PermissionError: If unable to rename files
    """
    if not old_path.exists():
        raise FileNotFoundError(f"Recording not found: {old_path}")

    # Extract timestamp prefix from old filename
    old_stem = old_path.stem
    timestamp = extract_timestamp_prefix(old_stem)

    # Build new filename
    sanitized_name = sanitize_filename(new_name)
    if timestamp:
        new_stem = f"{timestamp}_{sanitized_name}"
    else:
        # No timestamp found, just use the sanitized name
        new_stem = sanitized_name

    new_mp3_path = old_path.parent / f"{new_stem}.mp3"

    # Check if target already exists
    if new_mp3_path.exists() and new_mp3_path != old_path:
        raise FileExistsError(f"File already exists: {new_mp3_path}")

    # Rename MP3 file
    old_path.rename(new_mp3_path)

    # Rename transcript if it exists (check both same dir and transcripts_dir)
    old_transcript = old_path.with_suffix(".txt")
    if old_transcript.exists():
        new_transcript = new_mp3_path.with_suffix(".txt")
        old_transcript.rename(new_transcript)

    # Also check transcripts_dir if different from recordings dir
    transcripts_dir = config.transcripts_dir
    if transcripts_dir != old_path.parent:
        old_transcript_in_dir = transcripts_dir / f"{old_stem}.txt"
        if old_transcript_in_dir.exists():
            new_transcript_in_dir = transcripts_dir / f"{new_stem}.txt"
            old_transcript_in_dir.rename(new_transcript_in_dir)

    # Rename live transcript if it exists
    live_dir = old_path.parent / "live"
    old_live = live_dir / f"{old_stem}.live.txt"
    if old_live.exists():
        new_live = live_dir / f"{new_stem}.live.txt"
        old_live.rename(new_live)

    # Update favorites if needed
    if config.is_favorite(old_path.name):
        config.remove_favorite(old_path.name)
        config.add_favorite(new_mp3_path.name)

    # Update tags if needed
    config.rename_file_tags(old_path.name, new_mp3_path.name)

    return new_mp3_path
