"""Transcription modules."""
