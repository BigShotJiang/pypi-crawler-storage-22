"""Chunked transcription - transcribe audio in chunks during recording."""

from __future__ import annotations

import json
import shutil
import threading
from concurrent.futures import Future, ThreadPoolExecutor, wait
from datetime import datetime
from pathlib import Path
from typing import Optional

import numpy as np

from meeting_noter.audio.encoder import MP3Encoder
from meeting_noter.transcription.engine import format_timestamp


# Thread-local storage for caching Whisper model per worker thread
_thread_local = threading.local()
_model_load_lock = threading.Lock()


def _get_or_load_model(model_size: str):
    """Get cached Whisper model for the current thread, or load it."""
    cached_size = getattr(_thread_local, "model_size", None)
    if cached_size == model_size:
        return _thread_local.model

    # Serialize model loading to avoid concurrent downloads/init
    with _model_load_lock:
        from faster_whisper import WhisperModel

        _thread_local.model = WhisperModel(model_size, device="cpu", compute_type="int8", local_files_only=True)
        _thread_local.model_size = model_size
    return _thread_local.model


def _transcribe_chunk(
    chunk_index: int,
    chunk_path: Path,
    time_offset: float,
    model_size: str,
) -> None:
    """Transcribe a single chunk and write result to disk as .json.

    Runs in a worker thread. Writes a JSON file next to the chunk MP3
    so results survive even if the process is killed.
    """
    model = _get_or_load_model(model_size)

    segments, _info = model.transcribe(
        str(chunk_path),
        beam_size=5,
        vad_filter=True,
        vad_parameters=dict(min_silence_duration_ms=500),
    )

    result = []
    for segment in segments:
        text = segment.text.strip()
        if text:
            result.append({
                "start": segment.start + time_offset,
                "end": segment.end + time_offset,
                "text": text,
            })

    # Write to disk immediately so results survive crashes
    output_path = chunk_path.with_suffix(".json")
    output_path.write_text(json.dumps(result))

    # Delete the chunk MP3 — no longer needed after transcription
    try:
        chunk_path.unlink()
    except OSError:
        pass


class ChunkedTranscriber:
    """Transcribes audio in chunks during recording.

    Splits the audio stream into fixed-duration MP3 chunks. Each completed
    chunk is submitted to a background thread pool for transcription.
    Results are written to disk as JSON files immediately when each chunk
    completes. When stop() is called, reads all available JSON files and
    merges them into the final transcript.
    """

    def __init__(
        self,
        output_dir: Path,
        meeting_name: str,
        sample_rate: int,
        channels: int,
        chunk_duration: int = 300,
        model_size: str = "tiny.en",
        max_workers: int = 1,
        transcripts_dir: Optional[Path] = None,
    ):
        self._output_dir = output_dir
        self._meeting_name = meeting_name
        self._sample_rate = sample_rate
        self._channels = channels
        self._chunk_duration = chunk_duration
        self._model_size = model_size
        self._transcripts_dir = transcripts_dir or output_dir

        self._chunks_dir: Optional[Path] = None
        self._chunk_index = 0
        self._current_encoder: Optional[MP3Encoder] = None
        self._samples_in_chunk = 0
        self._executor = ThreadPoolExecutor(max_workers=max_workers)
        self._futures: list[Future] = []
        self._started = False
        self._meeting_filename = ""

    def start(self, meeting_filename: str) -> None:
        """Start chunked transcription.

        Args:
            meeting_filename: The filename of the main recording
                (e.g., "2026-02-03_143853_Zoom.mp3").
                Used to derive chunk directory and final transcript name.
        """
        self._meeting_filename = meeting_filename
        stem = Path(meeting_filename).stem

        # Create hidden chunks directory
        self._chunks_dir = self._output_dir / ".chunks" / stem
        self._chunks_dir.mkdir(parents=True, exist_ok=True)

        # Write metadata for crash recovery
        meta = {
            "meeting_filename": meeting_filename,
            "chunk_duration": self._chunk_duration,
            "model_size": self._model_size,
            "transcripts_dir": str(self._transcripts_dir),
        }
        (self._chunks_dir / "meta.txt").write_text(json.dumps(meta))

        # Start first encoder
        self._chunk_index = 0
        self._start_new_encoder()
        self._started = True

    def write(self, audio: np.ndarray) -> None:
        """Write audio data, rotating chunks when duration is reached."""
        if not self._started or self._current_encoder is None:
            return

        self._current_encoder.encode_chunk(audio)
        self._samples_in_chunk += len(audio)

        # Check if chunk duration reached
        chunk_seconds = self._samples_in_chunk / self._sample_rate
        if chunk_seconds >= self._chunk_duration:
            self._rotate_chunk()

    def stop(self) -> Optional[Path]:
        """Stop chunked transcription, wait for results, and merge.

        Returns:
            Path to the merged transcript file, or None if nothing to merge.
        """
        if not self._started:
            return None

        self._started = False

        # Finalize current (last) chunk
        if self._current_encoder is not None:
            current_chunk = self._get_current_chunk_path()
            chunk_duration_secs = self._samples_in_chunk / self._sample_rate
            self._current_encoder.finalize()
            self._current_encoder = None

            # Only transcribe if chunk has enough audio (>2 seconds)
            if (
                chunk_duration_secs >= 2.0
                and current_chunk.exists()
                and current_chunk.stat().st_size > 0
            ):
                time_offset = self._chunk_index * self._chunk_duration
                future = self._executor.submit(
                    _transcribe_chunk,
                    self._chunk_index,
                    current_chunk,
                    time_offset,
                    self._model_size,
                )
                self._futures.append(future)

        # Wait for pending transcriptions (only the last chunk + any still running)
        if self._futures:
            done, not_done = wait(self._futures, timeout=120)
            for f in done:
                try:
                    f.result()  # Raise any exceptions
                except Exception as e:
                    print(f"Chunk transcription error: {e}")

        self._executor.shutdown(wait=False)

        # Merge all available JSON results from disk
        transcript_path = self._merge_transcripts_from_disk()

        # Clean up chunk files
        self._cleanup()

        return transcript_path

    def _start_new_encoder(self) -> None:
        """Start a new MP3 encoder for the current chunk."""
        chunk_path = self._get_current_chunk_path()
        self._current_encoder = MP3Encoder(
            output_path=chunk_path,
            sample_rate=self._sample_rate,
            channels=self._channels,
        )
        self._samples_in_chunk = 0

    def _get_current_chunk_path(self) -> Path:
        """Get the file path for the current chunk."""
        return self._chunks_dir / f"chunk_{self._chunk_index:03d}.mp3"

    def _rotate_chunk(self) -> None:
        """Finalize current chunk and start transcription + new chunk."""
        if self._current_encoder is None:
            return

        chunk_path = self._get_current_chunk_path()
        self._current_encoder.finalize()
        self._current_encoder = None

        if chunk_path.exists() and chunk_path.stat().st_size > 0:
            # Submit for background transcription
            time_offset = self._chunk_index * self._chunk_duration
            future = self._executor.submit(
                _transcribe_chunk,
                self._chunk_index,
                chunk_path,
                time_offset,
                self._model_size,
            )
            self._futures.append(future)
            print(f"Chunk {self._chunk_index} complete, transcribing in background...")

        # Start next chunk
        self._chunk_index += 1
        self._start_new_encoder()

    def _merge_transcripts_from_disk(self) -> Optional[Path]:
        """Merge all chunk transcript JSON files from disk into final transcript."""
        if not self._chunks_dir or not self._chunks_dir.exists():
            return None

        # Collect all available JSON results
        json_files = sorted(self._chunks_dir.glob("chunk_*.json"))
        if not json_files:
            return None

        all_segments = []
        for json_file in json_files:
            try:
                segments = json.loads(json_file.read_text())
                all_segments.extend(segments)
            except (json.JSONDecodeError, IOError):
                continue

        if not all_segments:
            return None

        stem = Path(self._meeting_filename).stem
        transcript_path = self._transcripts_dir / f"{stem}.txt"
        self._transcripts_dir.mkdir(parents=True, exist_ok=True)

        # Calculate total duration
        total_duration = max((s["end"] for s in all_segments), default=0.0)

        lines = []
        lines.append("Meeting Transcription")
        lines.append(f"File: {self._meeting_filename}")
        lines.append(f"Transcribed: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        lines.append(f"Duration: {total_duration:.1f} seconds")
        lines.append("-" * 40)
        lines.append("")

        for seg in all_segments:
            timestamp = format_timestamp(seg["start"])
            lines.append(f"{timestamp} {seg['text']}")

        transcript_path.write_text("\n".join(lines))
        return transcript_path

    def _cleanup(self) -> None:
        """Remove chunk files and directory."""
        if self._chunks_dir and self._chunks_dir.exists():
            try:
                shutil.rmtree(self._chunks_dir)
                # Remove parent .chunks dir if empty
                parent = self._chunks_dir.parent
                if parent.name == ".chunks" and not any(parent.iterdir()):
                    parent.rmdir()
            except Exception:
                pass
