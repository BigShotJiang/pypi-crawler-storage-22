"""Terminal User Interface for Meeting Noter."""

from meeting_noter.ui.app import MeetingNoterApp

__all__ = ["MeetingNoterApp"]
