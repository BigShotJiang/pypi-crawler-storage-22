"""Main Textual application for Meeting Noter."""

from __future__ import annotations

from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.widgets import Footer, Header

from meeting_noter.ui.screens.main import MainScreen
from meeting_noter.ui.screens.recordings import RecordingsScreen
from meeting_noter.ui.screens.search import SearchScreen
from meeting_noter.ui.screens.settings import SettingsScreen
from meeting_noter.ui.screens.logs import LogsScreen


class MeetingNoterApp(App):
    """Meeting Noter Terminal UI Application."""

    TITLE = "Meeting Noter"
    CSS_PATH = "styles/app.tcss"

    BINDINGS = [
        Binding("q", "quit", "Quit"),
        Binding("question_mark", "help", "Help", key_display="?"),
        Binding("1", "switch_screen('main')", "Dashboard", show=True),
        Binding("2", "switch_screen('recordings')", "Recordings", show=True),
        Binding("3", "switch_screen('search')", "Search", show=True),
        Binding("4", "switch_screen('settings')", "Settings", show=True),
        Binding("5", "switch_screen('logs')", "Logs", show=True),
        Binding("escape", "go_back", "Back", show=False),
    ]

    SCREENS = {
        "main": MainScreen,
        "recordings": RecordingsScreen,
        "search": SearchScreen,
        "settings": SettingsScreen,
        "logs": LogsScreen,
    }

    def compose(self) -> ComposeResult:
        """Compose the app layout."""
        yield Header()
        yield Footer()

    def on_mount(self) -> None:
        """Handle app mount - show the main screen."""
        self.push_screen("main")

    def action_switch_screen(self, screen_name: str) -> None:
        """Switch to a named screen."""
        # Pop all screens except the base and push the new one
        while len(self.screen_stack) > 1:
            self.pop_screen()
        self.push_screen(screen_name)

    def action_go_back(self) -> None:
        """Go back to the previous screen."""
        if len(self.screen_stack) > 1:
            self.pop_screen()

    def action_help(self) -> None:
        """Show help information."""
        self.notify(
            "Keys: 1-5 switch screens, q quit, ? help",
            title="Meeting Noter Help",
            timeout=5,
        )
