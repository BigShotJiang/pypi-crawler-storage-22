"""Logs viewer screen for Meeting Noter."""

from __future__ import annotations

from pathlib import Path

from textual.app import ComposeResult
from textual.containers import Container, Horizontal
from textual.screen import Screen
from textual.widgets import Button, Label, RichLog, Static, Switch


LOG_FILE = Path.home() / ".meeting-noter.log"


class LogsScreen(Screen):
    """Logs viewer screen."""

    BINDINGS = [
        ("l", "toggle_follow", "Follow"),
        ("c", "clear_display", "Clear"),
        ("r", "refresh", "Refresh"),
        ("escape", "go_back", "Back"),
    ]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._follow_mode = True
        self._last_size = 0

    def compose(self) -> ComposeResult:
        """Compose the logs screen layout."""
        yield Container(
            Static("[bold]Logs[/bold]", classes="title"),
            Label(f"[dim]{LOG_FILE}[/dim]", id="log-path"),
            Static("", classes="spacer"),
            RichLog(id="log-content", highlight=True, markup=True),
            Static("", classes="spacer"),
            Horizontal(
                Label("Follow: "),
                Switch(value=True, id="follow-switch"),
                Button("Refresh", id="refresh-btn"),
                Button("Clear", id="clear-btn"),
                Button("Back", id="back-btn"),
                classes="button-row",
            ),
            id="logs-container",
        )

    def on_mount(self) -> None:
        """Start log refresh on mount."""
        self._load_logs()
        self.set_interval(1.0, self._check_for_updates)

    def _load_logs(self, lines: int = 100) -> None:
        """Load the last N lines from the log file."""
        log_content = self.query_one("#log-content", RichLog)

        if not LOG_FILE.exists():
            log_content.write("[yellow]No log file found[/yellow]")
            return

        try:
            content = LOG_FILE.read_text()
            all_lines = content.splitlines()
            recent_lines = all_lines[-lines:] if len(all_lines) > lines else all_lines

            log_content.clear()
            for line in recent_lines:
                # Color-code different log levels
                if "Error" in line or "error" in line:
                    log_content.write(f"[red]{line}[/red]")
                elif "Warning" in line or "warning" in line:
                    log_content.write(f"[yellow]{line}[/yellow]")
                elif "Recording started" in line:
                    log_content.write(f"[green]{line}[/green]")
                elif "Recording saved" in line:
                    log_content.write(f"[cyan]{line}[/cyan]")
                else:
                    log_content.write(line)

            self._last_size = LOG_FILE.stat().st_size

        except Exception as e:
            log_content.write(f"[red]Error reading log: {e}[/red]")

    def _check_for_updates(self) -> None:
        """Check for new log content if in follow mode."""
        if not self._follow_mode:
            return

        follow_switch = self.query_one("#follow-switch", Switch)
        self._follow_mode = follow_switch.value

        if not self._follow_mode:
            return

        if not LOG_FILE.exists():
            return

        try:
            current_size = LOG_FILE.stat().st_size
            if current_size > self._last_size:
                # Read new content
                with open(LOG_FILE, "r") as f:
                    f.seek(self._last_size)
                    new_content = f.read()

                log_content = self.query_one("#log-content", RichLog)
                for line in new_content.splitlines():
                    if line.strip():
                        if "Error" in line or "error" in line:
                            log_content.write(f"[red]{line}[/red]")
                        elif "Warning" in line or "warning" in line:
                            log_content.write(f"[yellow]{line}[/yellow]")
                        elif "Recording started" in line:
                            log_content.write(f"[green]{line}[/green]")
                        elif "Recording saved" in line:
                            log_content.write(f"[cyan]{line}[/cyan]")
                        else:
                            log_content.write(line)

                self._last_size = current_size

        except Exception:
            pass

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button presses."""
        button_id = event.button.id

        if button_id == "refresh-btn":
            self.action_refresh()
        elif button_id == "clear-btn":
            self.action_clear_display()
        elif button_id == "back-btn":
            self.action_go_back()

    def on_switch_changed(self, event: Switch.Changed) -> None:
        """Handle follow switch changes."""
        if event.switch.id == "follow-switch":
            self._follow_mode = event.value
            if event.value:
                self.notify("Follow mode enabled")
            else:
                self.notify("Follow mode disabled")

    def action_toggle_follow(self) -> None:
        """Toggle follow mode."""
        switch = self.query_one("#follow-switch", Switch)
        switch.value = not switch.value

    def action_clear_display(self) -> None:
        """Clear the log display."""
        log_content = self.query_one("#log-content", RichLog)
        log_content.clear()
        self.notify("Display cleared")

    def action_refresh(self) -> None:
        """Refresh the log display."""
        self._load_logs()
        self.notify("Refreshed")

    def action_go_back(self) -> None:
        """Go back to the previous screen."""
        self.app.pop_screen()
