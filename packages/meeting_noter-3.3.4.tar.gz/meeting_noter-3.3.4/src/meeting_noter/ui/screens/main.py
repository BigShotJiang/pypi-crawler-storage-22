"""Main dashboard screen for Meeting Noter."""

from __future__ import annotations

import os
import signal
from pathlib import Path
from typing import Optional, Tuple

from textual.app import ComposeResult
from textual.containers import Container, Horizontal, Vertical, Center
from textual.screen import Screen
from textual.widgets import Button, Input, Label, RichLog, Static, Switch

from meeting_noter.config import get_config, generate_meeting_name
from meeting_noter.daemon import read_pid_file, is_process_running


# PID file paths
DEFAULT_PID_FILE = Path.home() / ".meeting-noter.pid"
WATCHER_PID_FILE = Path.home() / ".meeting-noter-watcher.pid"


class StatusDisplay(Static):
    """Widget to display current status."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._status = "Checking..."

    def on_mount(self) -> None:
        """Start status refresh timer."""
        self.set_interval(2.0, self.refresh_status)
        self.refresh_status()

    def refresh_status(self) -> None:
        """Refresh the status display."""
        watcher_running = self._check_watcher()
        daemon_running, recording_name = self._check_daemon()

        if daemon_running:
            status_icon = "[red]●[/red]"
            status_text = f"Recording: {recording_name or 'In progress'}"
        elif watcher_running:
            status_icon = "[green]●[/green]"
            status_text = "Ready (watcher active)"
        else:
            status_icon = "[dim]●[/dim]"
            status_text = "Stopped"

        self.update(
            f"{status_icon} {status_text}\n\n"
            f"[dim]Watcher:[/dim] {'running' if watcher_running else 'stopped'}\n"
            f"[dim]Recorder:[/dim] {'recording' if daemon_running else 'idle'}"
        )

        # Notify parent screen about recording state
        try:
            screen = self.screen
            if hasattr(screen, "_update_recording_state"):
                screen._update_recording_state(daemon_running)
        except Exception:
            pass

    def _check_watcher(self) -> bool:
        """Check if watcher is running."""
        if WATCHER_PID_FILE.exists():
            try:
                pid = int(WATCHER_PID_FILE.read_text().strip())
                os.kill(pid, 0)
                return True
            except (ProcessLookupError, ValueError, FileNotFoundError):
                pass
        return False

    def _check_daemon(self) -> Tuple[bool, Optional[str]]:
        """Check if daemon is running and get recording name."""
        daemon_pid = read_pid_file(DEFAULT_PID_FILE)
        if daemon_pid and is_process_running(daemon_pid):
            recording_name = self._get_current_recording_name()
            return True, recording_name
        return False, None

    def _get_current_recording_name(self) -> Optional[str]:
        """Get the name of the current recording from the log file."""
        log_path = Path.home() / ".meeting-noter.log"
        if not log_path.exists():
            return None

        try:
            with open(log_path, "r") as f:
                lines = f.readlines()

            for line in reversed(lines[-50:]):
                if "Recording started:" in line:
                    parts = line.split("Recording started:")
                    if len(parts) > 1:
                        filename = parts[1].strip().replace(".mp3", "")
                        name_parts = filename.split("_", 2)
                        if len(name_parts) >= 3:
                            return name_parts[2]
                        return filename
                elif "Recording saved:" in line or "Recording discarded" in line:
                    break
            return None
        except Exception:
            return None


class LiveTranscriptDisplay(RichLog):
    """Widget to display live transcription."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, highlight=True, markup=True, **kwargs)
        self._live_file: Optional[Path] = None
        self._last_content = ""
        self._is_recording = False

    def on_mount(self) -> None:
        """Start watching for live transcript updates."""
        self.set_interval(0.5, self._check_live_transcript)

    def set_recording(self, is_recording: bool) -> None:
        """Set the recording state."""
        self._is_recording = is_recording
        if not is_recording:
            self._live_file = None
            self._last_content = ""

    def _check_live_transcript(self) -> None:
        """Check for live transcript updates."""
        if not self._is_recording:
            return

        config = get_config()
        live_dir = config.recordings_dir / "live"

        if not live_dir.exists():
            return

        # Find the most recent live file
        live_files = sorted(
            live_dir.glob("*.live.txt"),
            key=lambda p: p.stat().st_mtime,
            reverse=True,
        )

        if not live_files:
            return

        live_file = live_files[0]

        # Read and display new content
        try:
            content = live_file.read_text()
            if len(content) > len(self._last_content):
                new_content = content[len(self._last_content):]
                for line in new_content.splitlines():
                    if line.strip() and line.startswith("["):
                        self.write(f"[cyan]{line}[/cyan]")
                self._last_content = content
        except Exception:
            pass


class MainScreen(Screen):
    """Main dashboard screen."""

    BINDINGS = [
        ("r", "toggle_recording", "Record"),
    ]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._is_recording = False

    def compose(self) -> ComposeResult:
        """Compose the main screen layout."""
        yield Container(
            Static("[bold]Meeting Noter[/bold]", classes="title"),
            Static("", classes="spacer"),
            StatusDisplay(id="status"),
            Static("", classes="spacer"),
            Center(
                Vertical(
                    Horizontal(
                        Label("Meeting name:", classes="input-label"),
                        Input(
                            placeholder=generate_meeting_name(),
                            id="meeting-name",
                            classes="meeting-input",
                        ),
                        classes="centered-input-row",
                    ),
                    Horizontal(
                        Label("Live transcription:", classes="input-label"),
                        Switch(value=True, id="live-transcription"),
                        classes="centered-switch-row",
                    ),
                    classes="input-section",
                ),
            ),
            Static("", classes="spacer"),
            Center(
                Horizontal(
                    Button("Start Recording", id="record-btn", variant="success"),
                    Button("Stop", id="stop-btn", variant="error"),
                    classes="centered-button-row",
                ),
            ),
            Static("", classes="spacer"),
            Static("[dim]Live Transcription[/dim]", id="live-header", classes="section-header"),
            LiveTranscriptDisplay(id="live-transcript"),
            Static("", classes="spacer"),
            Static("[dim]Quick Navigation[/dim]", classes="section-header"),
            Center(
                Horizontal(
                    Button("Recordings", id="nav-recordings"),
                    Button("Search", id="nav-search"),
                    Button("Settings", id="nav-settings"),
                    Button("Logs", id="nav-logs"),
                    classes="centered-button-row",
                ),
            ),
            id="main-container",
        )

    def _update_recording_state(self, is_recording: bool) -> None:
        """Update UI based on recording state."""
        if is_recording != self._is_recording:
            self._is_recording = is_recording
            live_display = self.query_one("#live-transcript", LiveTranscriptDisplay)
            live_switch = self.query_one("#live-transcription", Switch)

            if is_recording and live_switch.value:
                live_display.set_recording(True)
                live_display.clear()
                live_display.write("[dim]Waiting for transcription...[/dim]")
            else:
                live_display.set_recording(False)

    def action_toggle_recording(self) -> None:
        """Toggle recording state."""
        daemon_pid = read_pid_file(DEFAULT_PID_FILE)
        if daemon_pid and is_process_running(daemon_pid):
            self._on_stop_button()
        else:
            self._on_record_button()

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button presses."""
        button_id = event.button.id

        if button_id == "record-btn":
            self._on_record_button()
        elif button_id == "stop-btn":
            self._on_stop_button()
        elif button_id == "nav-recordings":
            self.app.action_switch_screen("recordings")
        elif button_id == "nav-search":
            self.app.action_switch_screen("search")
        elif button_id == "nav-settings":
            self.app.action_switch_screen("settings")
        elif button_id == "nav-logs":
            self.app.action_switch_screen("logs")

    def _on_record_button(self) -> None:
        """Handle record button press."""
        import subprocess
        import sys

        # Check if already recording
        daemon_pid = read_pid_file(DEFAULT_PID_FILE)
        if daemon_pid and is_process_running(daemon_pid):
            self.notify("Already recording. Stop first.", severity="warning")
            return

        # Get meeting name
        name_input = self.query_one("#meeting-name", Input)
        meeting_name = name_input.value.strip() or generate_meeting_name()

        # Clear live transcript display
        live_display = self.query_one("#live-transcript", LiveTranscriptDisplay)
        live_display.clear()
        live_display.write(f"[green]Starting recording: {meeting_name}[/green]")

        # Start recording
        subprocess.Popen(
            [sys.executable, "-m", "meeting_noter.cli", "daemon", "--name", meeting_name],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

        self.notify(f"Recording started: {meeting_name}", severity="information")

        # Clear the input
        name_input.value = ""

        # Refresh status
        self.query_one("#status", StatusDisplay).refresh_status()

    def _on_stop_button(self) -> None:
        """Handle stop button press - gracefully stop daemon."""
        # Get daemon PID and send SIGTERM for graceful shutdown
        daemon_pid = read_pid_file(DEFAULT_PID_FILE)
        watcher_pid = None

        if WATCHER_PID_FILE.exists():
            try:
                watcher_pid = int(WATCHER_PID_FILE.read_text().strip())
            except (ValueError, FileNotFoundError):
                pass

        stopped = []

        # Stop daemon gracefully (allows auto-transcribe to run)
        if daemon_pid and is_process_running(daemon_pid):
            try:
                os.kill(daemon_pid, signal.SIGTERM)
                stopped.append("recording")
                self.notify("Stopping recording (will auto-transcribe if enabled)...", severity="information")
            except ProcessLookupError:
                pass

        # Stop watcher
        if watcher_pid:
            try:
                os.kill(watcher_pid, signal.SIGTERM)
                stopped.append("watcher")
            except ProcessLookupError:
                pass
            WATCHER_PID_FILE.unlink(missing_ok=True)

        # Update live display
        live_display = self.query_one("#live-transcript", LiveTranscriptDisplay)
        live_display.set_recording(False)
        if stopped:
            live_display.write(f"\n[yellow]Stopped: {', '.join(stopped)}[/yellow]")

        if not stopped:
            self.notify("No processes running", severity="warning")
        else:
            self.notify(f"Stopped: {', '.join(stopped)}", severity="information")

        # Refresh status after a short delay
        self.set_timer(1.0, lambda: self.query_one("#status", StatusDisplay).refresh_status())
