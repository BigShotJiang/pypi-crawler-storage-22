"""Recordings browser screen for Meeting Noter."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Optional

from textual.app import ComposeResult
from textual.containers import Container, Horizontal
from textual.screen import Screen
from textual.widgets import Button, DataTable, Label, Static

from meeting_noter.config import get_config
from meeting_noter.output.writer import format_duration, format_size, get_audio_duration


@dataclass
class RecordingInfo:
    """Information about a recording."""

    filepath: Path
    date: datetime
    duration: Optional[float]
    size: int
    has_transcript: bool
    is_favorite: bool


def get_recordings_list(output_dir: Path, limit: int = 50) -> list[RecordingInfo]:
    """Get list of recordings with metadata."""
    config = get_config()

    if not output_dir.exists():
        return []

    mp3_files = sorted(
        output_dir.glob("*.mp3"),
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )

    # Get transcripts directory from config
    transcripts_dir = config.transcripts_dir

    recordings = []
    for mp3 in mp3_files[:limit]:
        stat = mp3.stat()
        transcript_name = mp3.stem + ".txt"

        # Check for transcript in transcripts directory
        transcript_path = transcripts_dir / transcript_name
        has_transcript = transcript_path.exists()

        recordings.append(
            RecordingInfo(
                filepath=mp3,
                date=datetime.fromtimestamp(stat.st_mtime),
                duration=get_audio_duration(mp3),
                size=stat.st_size,
                has_transcript=has_transcript,
                is_favorite=config.is_favorite(transcript_name),
            )
        )

    return recordings


class RecordingsScreen(Screen):
    """Recordings browser screen."""

    BINDINGS = [
        ("t", "transcribe", "Transcribe"),
        ("enter", "view", "View"),
        ("f", "toggle_favorite", "Favorite"),
        ("r", "refresh", "Refresh"),
    ]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._transcribing: dict[str, "subprocess.Popen"] = {}  # filepath key -> process

    def compose(self) -> ComposeResult:
        """Compose the recordings screen layout."""
        yield Container(
            Static("[bold]Recordings[/bold]", classes="title"),
            Static("", classes="spacer"),
            DataTable(id="recordings-table", cursor_type="row"),
            Static("", classes="spacer"),
            Horizontal(
                Button("View", id="view-btn"),
                Button("Transcribe", id="transcribe-btn", variant="primary"),
                Button("Toggle Favorite", id="favorite-btn"),
                Button("Refresh", id="refresh-btn"),
                classes="button-row",
            ),
            Label("", id="status-label"),
            id="recordings-container",
        )

    def on_mount(self) -> None:
        """Load recordings on mount."""
        self._setup_table()
        self._load_recordings()

    def _setup_table(self) -> None:
        """Set up the recordings table."""
        table = self.query_one("#recordings-table", DataTable)
        table.add_columns("★", "Date", "Duration", "Size", "Transcript", "File")

    def _load_recordings(self) -> None:
        """Load recordings into the table."""
        config = get_config()
        table = self.query_one("#recordings-table", DataTable)
        status = self.query_one("#status-label", Label)

        table.clear()

        recordings = get_recordings_list(config.recordings_dir)

        if not recordings:
            status.update("[yellow]No recordings found[/yellow]")
            return

        for rec in recordings:
            star = "★" if rec.is_favorite else ""
            date_str = rec.date.strftime("%Y-%m-%d %H:%M")
            duration_str = format_duration(rec.duration) if rec.duration else "?"
            size_str = format_size(rec.size)
            if str(rec.filepath) in self._transcribing:
                transcript_str = "Processing..."
            elif rec.has_transcript:
                transcript_str = "Yes"
            else:
                transcript_str = "No"

            table.add_row(
                star,
                date_str,
                duration_str,
                size_str,
                transcript_str,
                rec.filepath.name,
                key=str(rec.filepath),
            )

        status.update(f"[dim]{len(recordings)} recordings[/dim]")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button presses."""
        button_id = event.button.id

        if button_id == "view-btn":
            self.action_view()
        elif button_id == "transcribe-btn":
            self.action_transcribe()
        elif button_id == "favorite-btn":
            self.action_toggle_favorite()
        elif button_id == "refresh-btn":
            self.action_refresh()

    def _get_selected_filepath(self) -> Optional[Path]:
        """Get the filepath of the currently selected recording."""
        table = self.query_one("#recordings-table", DataTable)

        if table.row_count == 0:
            return None

        row_key = table.coordinate_to_cell_key(table.cursor_coordinate).row_key
        if row_key:
            return Path(row_key.value)
        return None

    def action_view(self) -> None:
        """View the selected transcript."""
        filepath = self._get_selected_filepath()
        if not filepath:
            self.notify("No recording selected", severity="warning")
            return

        config = get_config()
        transcript_name = filepath.stem + ".txt"
        transcript = config.transcripts_dir / transcript_name

        if not transcript.exists():
            self.notify("No transcript available. Transcribe first.", severity="warning")
            return

        # Push the viewer screen with the transcript path
        from meeting_noter.ui.screens.viewer import ViewerScreen

        self.app.push_screen(ViewerScreen(transcript))

    def action_transcribe(self) -> None:
        """Transcribe the selected recording."""
        import subprocess
        import sys

        filepath = self._get_selected_filepath()
        if not filepath:
            self.notify("No recording selected", severity="warning")
            return

        filepath_key = str(filepath)

        if filepath_key in self._transcribing:
            self.notify("Transcription already in progress", severity="warning")
            return

        config = get_config()
        transcript_name = filepath.stem + ".txt"
        transcript = config.transcripts_dir / transcript_name

        if transcript.exists():
            self.notify("Transcript already exists", severity="warning")
            return

        # Run transcription in background
        proc = subprocess.Popen(
            [
                sys.executable,
                "-m",
                "meeting_noter.cli",
                "transcribe",
                str(filepath),
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )

        self._transcribing[filepath_key] = proc
        self._load_recordings()
        self.notify(f"Transcribing: {filepath.name}", severity="information")

        # Poll for completion
        self._poll_transcription(filepath_key, filepath.name)

    def _poll_transcription(self, filepath_key: str, filename: str) -> None:
        """Poll a transcription process for completion."""

        def _check() -> None:
            proc = self._transcribing.get(filepath_key)
            if proc is None:
                return
            retcode = proc.poll()
            if retcode is None:
                # Still running, check again later
                self.set_timer(3.0, _check)
                return
            # Process finished
            self._transcribing.pop(filepath_key, None)
            if retcode == 0:
                self.notify(f"Transcription complete: {filename}")
            else:
                stderr = proc.stderr.read().decode() if proc.stderr else ""
                self.notify(f"Transcription failed: {stderr[:100]}", severity="error")
            self._load_recordings()

        self.set_timer(3.0, _check)

    def action_toggle_favorite(self) -> None:
        """Toggle favorite status for the selected recording."""
        filepath = self._get_selected_filepath()
        if not filepath:
            self.notify("No recording selected", severity="warning")
            return

        config = get_config()
        transcript_name = filepath.with_suffix(".txt").name

        if config.is_favorite(transcript_name):
            config.remove_favorite(transcript_name)
            self.notify(f"Removed from favorites: {transcript_name}")
        else:
            config.add_favorite(transcript_name)
            self.notify(f"Added to favorites: {transcript_name}")

        self._load_recordings()

    def action_refresh(self) -> None:
        """Refresh the recordings list."""
        self._load_recordings()
        self.notify("Refreshed")
