"""Search screen for Meeting Noter."""

from __future__ import annotations

from pathlib import Path
from typing import Optional

from textual.app import ComposeResult
from textual.containers import Container, Horizontal, Vertical
from textual.screen import Screen
from textual.widgets import Button, Checkbox, Input, Label, ListView, ListItem, Static

from meeting_noter.config import get_config
from meeting_noter.output.searcher import _search_file, FileSearchResult


class SearchResultItem(ListItem):
    """A search result list item."""

    def __init__(self, filepath: Path, match_text: str, timestamp: Optional[str] = None):
        super().__init__()
        self.filepath = filepath
        self.match_text = match_text
        self.timestamp = timestamp

    def compose(self) -> ComposeResult:
        """Compose the list item."""
        if self.timestamp:
            yield Static(f"[cyan][{self.timestamp}][/cyan] {self.match_text[:70]}...")
        else:
            yield Static(f"{self.match_text[:80]}...")


class SearchScreen(Screen):
    """Search screen."""

    BINDINGS = [
        ("slash", "focus_search", "Search"),
        ("enter", "view_selected", "View"),
    ]

    def compose(self) -> ComposeResult:
        """Compose the search screen layout."""
        yield Container(
            Static("[bold]Search Transcripts[/bold]", classes="title"),
            Static("", classes="spacer"),
            Horizontal(
                Input(placeholder="Enter search query...", id="search-input"),
                Button("Search", id="search-btn", variant="primary"),
                classes="search-row",
            ),
            Horizontal(
                Checkbox("Case sensitive", id="case-sensitive"),
                classes="options-row",
            ),
            Static("", classes="spacer"),
            Label("", id="results-header"),
            ListView(id="results-list"),
            Label("", id="results-footer"),
            id="search-container",
        )

    def on_mount(self) -> None:
        """Focus search input on mount."""
        self.query_one("#search-input", Input).focus()

    def action_focus_search(self) -> None:
        """Focus the search input."""
        self.query_one("#search-input", Input).focus()

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button presses."""
        if event.button.id == "search-btn":
            self._do_search()

    def on_input_submitted(self, event: Input.Submitted) -> None:
        """Handle Enter in search input."""
        if event.input.id == "search-input":
            self._do_search()

    def _do_search(self) -> None:
        """Perform the search."""
        config = get_config()
        query = self.query_one("#search-input", Input).value.strip()
        case_sensitive = self.query_one("#case-sensitive", Checkbox).value

        results_list = self.query_one("#results-list", ListView)
        results_header = self.query_one("#results-header", Label)
        results_footer = self.query_one("#results-footer", Label)

        results_list.clear()

        if not query:
            results_header.update("[yellow]Enter a search query[/yellow]")
            results_footer.update("")
            return

        transcripts_dir = config.transcripts_dir
        if not transcripts_dir.exists():
            results_header.update("[red]Transcripts directory not found[/red]")
            results_footer.update("")
            return

        # Find all transcript files
        txt_files = sorted(
            transcripts_dir.glob("*.txt"),
            key=lambda p: p.stat().st_mtime,
            reverse=True,
        )

        if not txt_files:
            results_header.update("[yellow]No transcripts found[/yellow]")
            results_footer.update("")
            return

        # Search all files
        results: list[FileSearchResult] = []
        for txt_file in txt_files:
            result = _search_file(txt_file, query, case_sensitive)
            if result:
                results.append(result)

        if not results:
            results_header.update(f"[yellow]No results for '{query}'[/yellow]")
            results_footer.update(f"[dim]Searched {len(txt_files)} transcripts[/dim]")
            return

        # Sort by match count
        results.sort(key=lambda r: r.match_count, reverse=True)

        # Count totals
        total_matches = sum(r.match_count for r in results)
        total_files = len(results)

        results_header.update(
            f"[green]Found {total_matches} matches in {total_files} transcripts[/green]"
        )

        # Add results to list (limit for performance)
        max_items = 50
        items_added = 0

        for result in results:
            if items_added >= max_items:
                break

            # Add file header
            results_list.append(
                ListItem(
                    Static(f"[bold green]{result.filepath.name}[/bold green] ({result.match_count} matches)")
                )
            )

            # Add matches (limit per file)
            for match in result.matches[:5]:
                results_list.append(
                    SearchResultItem(
                        result.filepath,
                        match.line.strip(),
                        match.timestamp,
                    )
                )
                items_added += 1
                if items_added >= max_items:
                    break

        if total_matches > max_items:
            results_footer.update(
                f"[dim]Showing {items_added} of {total_matches} matches. "
                f"Searched {len(txt_files)} transcripts.[/dim]"
            )
        else:
            results_footer.update(f"[dim]Searched {len(txt_files)} transcripts[/dim]")

    def on_list_view_selected(self, event: ListView.Selected) -> None:
        """Handle list item selection."""
        item = event.item
        if isinstance(item, SearchResultItem):
            from meeting_noter.ui.screens.viewer import ViewerScreen

            self.app.push_screen(ViewerScreen(item.filepath))

    def action_view_selected(self) -> None:
        """View the selected result's transcript."""
        results_list = self.query_one("#results-list", ListView)
        if results_list.highlighted_child:
            item = results_list.highlighted_child
            if isinstance(item, SearchResultItem):
                from meeting_noter.ui.screens.viewer import ViewerScreen

                self.app.push_screen(ViewerScreen(item.filepath))
