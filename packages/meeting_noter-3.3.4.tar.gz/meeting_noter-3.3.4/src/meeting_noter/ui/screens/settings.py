"""Settings screen for Meeting Noter."""

from __future__ import annotations

from textual.app import ComposeResult
from textual.containers import Container, Horizontal, Vertical
from textual.screen import Screen
from textual.widgets import Button, Input, Label, Select, Static, Switch

from meeting_noter.config import get_config


WHISPER_MODELS = [
    ("tiny.en (fastest)", "tiny.en"),
    ("base.en (balanced)", "base.en"),
    ("small.en (better)", "small.en"),
    ("medium.en (high quality)", "medium.en"),
    ("large-v3 (best, multilingual)", "large-v3"),
]


class SettingsScreen(Screen):
    """Settings configuration screen."""

    BINDINGS = [
        ("s", "save", "Save"),
        ("escape", "go_back", "Back"),
    ]

    def compose(self) -> ComposeResult:
        """Compose the settings screen layout."""
        config = get_config()

        yield Container(
            Static("[bold]Settings[/bold]", classes="title"),
            Static("", classes="spacer"),
            Vertical(
                # Directories
                Static("[dim]Directories[/dim]", classes="section-header"),
                Horizontal(
                    Label("Recordings: ", classes="setting-label"),
                    Input(
                        str(config.recordings_dir),
                        id="recordings-dir",
                        classes="setting-input",
                    ),
                    classes="setting-row",
                ),
                Horizontal(
                    Label("Transcripts: ", classes="setting-label"),
                    Input(
                        str(config.transcripts_dir),
                        id="transcripts-dir",
                        classes="setting-input",
                    ),
                    classes="setting-row",
                ),
                Static("", classes="spacer"),
                # Whisper model
                Static("[dim]Transcription[/dim]", classes="section-header"),
                Horizontal(
                    Label("Whisper model: ", classes="setting-label"),
                    Select(
                        WHISPER_MODELS,
                        value=config.whisper_model,
                        id="whisper-model",
                    ),
                    classes="setting-row",
                ),
                Static("", classes="spacer"),
                # Toggles
                Static("[dim]Options[/dim]", classes="section-header"),
                Horizontal(
                    Label("Auto-transcribe: ", classes="setting-label"),
                    Switch(value=config.auto_transcribe, id="auto-transcribe"),
                    classes="setting-row",
                ),
                Horizontal(
                    Label("Capture system audio: ", classes="setting-label"),
                    Switch(value=config.capture_system_audio, id="capture-system-audio"),
                    classes="setting-row",
                ),
                Horizontal(
                    Label("Auto-update: ", classes="setting-label"),
                    Switch(value=config.auto_update, id="auto-update"),
                    classes="setting-row",
                ),
                Static("", classes="spacer"),
                # Silence timeout
                Horizontal(
                    Label("Silence timeout (min): ", classes="setting-label"),
                    Input(
                        str(config.silence_timeout),
                        id="silence-timeout",
                        type="integer",
                    ),
                    classes="setting-row",
                ),
                classes="settings-form",
            ),
            Static("", classes="spacer"),
            Horizontal(
                Button("Save", id="save-btn", variant="success"),
                Button("Reset", id="reset-btn"),
                Button("Back", id="back-btn"),
                classes="button-row",
            ),
            Label("", id="status-label"),
            id="settings-container",
        )

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button presses."""
        button_id = event.button.id

        if button_id == "save-btn":
            self.action_save()
        elif button_id == "reset-btn":
            self._reset_to_current()
        elif button_id == "back-btn":
            self.action_go_back()

    def action_save(self) -> None:
        """Save settings."""
        from pathlib import Path

        config = get_config()

        try:
            # Get values from inputs
            recordings_dir = self.query_one("#recordings-dir", Input).value
            transcripts_dir = self.query_one("#transcripts-dir", Input).value
            whisper_model = self.query_one("#whisper-model", Select).value
            auto_transcribe = self.query_one("#auto-transcribe", Switch).value
            capture_system_audio = self.query_one("#capture-system-audio", Switch).value
            auto_update = self.query_one("#auto-update", Switch).value
            silence_timeout = self.query_one("#silence-timeout", Input).value

            # Validate and set
            recordings_path = Path(recordings_dir).expanduser()
            transcripts_path = Path(transcripts_dir).expanduser()

            # Create directories if they don't exist
            recordings_path.mkdir(parents=True, exist_ok=True)
            transcripts_path.mkdir(parents=True, exist_ok=True)

            # Update config
            config.recordings_dir = recordings_path
            config.transcripts_dir = transcripts_path
            config.whisper_model = whisper_model
            config.auto_transcribe = auto_transcribe
            config.capture_system_audio = capture_system_audio
            config.auto_update = auto_update
            config.silence_timeout = int(silence_timeout) if silence_timeout else 5

            config.save()

            self.notify("Settings saved", severity="information")
            self.query_one("#status-label", Label).update(
                "[green]Settings saved successfully[/green]"
            )

        except Exception as e:
            self.notify(f"Error saving settings: {e}", severity="error")
            self.query_one("#status-label", Label).update(f"[red]Error: {e}[/red]")

    def _reset_to_current(self) -> None:
        """Reset form to current config values."""
        config = get_config()
        config.load()  # Reload from disk

        self.query_one("#recordings-dir", Input).value = str(config.recordings_dir)
        self.query_one("#transcripts-dir", Input).value = str(config.transcripts_dir)
        self.query_one("#whisper-model", Select).value = config.whisper_model
        self.query_one("#auto-transcribe", Switch).value = config.auto_transcribe
        self.query_one("#capture-system-audio", Switch).value = config.capture_system_audio
        self.query_one("#auto-update", Switch).value = config.auto_update
        self.query_one("#silence-timeout", Input).value = str(config.silence_timeout)

        self.notify("Reset to saved values")

    def action_go_back(self) -> None:
        """Go back to the previous screen."""
        self.app.pop_screen()
