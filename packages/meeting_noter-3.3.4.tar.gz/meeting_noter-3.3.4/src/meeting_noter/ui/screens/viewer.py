"""Transcript viewer screen for Meeting Noter."""

from __future__ import annotations

from datetime import datetime
from pathlib import Path

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Container, Horizontal
from textual.events import Key
from textual.screen import Screen
from textual.widgets import Button, Input, Label, Static, TextArea
from textual.widgets.text_area import Selection

from meeting_noter.config import get_config


class ViewerScreen(Screen):
    """Transcript viewer screen."""

    BINDINGS = [
        Binding("f", "toggle_favorite", "Favorite"),
        Binding("escape", "escape_action", "Back", priority=True),
    ]

    def __init__(self, transcript_path: Path, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.transcript_path = transcript_path
        self._search_matches: list[tuple[int, int]] = []  # (line, col) pairs
        self._current_match: int = -1

    def compose(self) -> ComposeResult:
        """Compose the viewer screen layout."""
        config = get_config()
        is_favorite = config.is_favorite(self.transcript_path.name)
        star = "★ " if is_favorite else ""

        yield Container(
            Static(
                f"[bold]{star}{self.transcript_path.name}[/bold]",
                classes="title",
            ),
            Label("", id="file-info"),
            Horizontal(
                Input(placeholder="Search transcript...", id="search-input"),
                Label("", id="search-info"),
                id="search-bar",
            ),
            TextArea(id="transcript-content", read_only=True),
            Static("", classes="spacer"),
            Horizontal(
                Button(
                    "★ Favorite" if not is_favorite else "☆ Unfavorite",
                    id="favorite-btn",
                    variant="warning" if is_favorite else "default",
                ),
                Button("Back", id="back-btn"),
                classes="button-row",
            ),
            id="viewer-container",
        )

    def on_mount(self) -> None:
        """Load transcript content on mount."""
        self._load_transcript()

    def _load_transcript(self) -> None:
        """Load the transcript content."""
        info_label = self.query_one("#file-info", Label)
        content_area = self.query_one("#transcript-content", TextArea)

        if not self.transcript_path.exists():
            info_label.update("[red]File not found[/red]")
            content_area.text = "Transcript file does not exist."
            return

        # Get file info
        stat = self.transcript_path.stat()
        mod_time = datetime.fromtimestamp(stat.st_mtime)
        date_str = mod_time.strftime("%Y-%m-%d %H:%M")
        size_kb = stat.st_size / 1024

        info_label.update(f"[dim]Modified: {date_str} | Size: {size_kb:.1f} KB[/dim]")

        # Load content
        try:
            content = self.transcript_path.read_text(encoding="utf-8")
            content_area.text = content
        except Exception as e:
            content_area.text = f"Error loading file: {e}"

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button presses."""
        if event.button.id == "favorite-btn":
            self.action_toggle_favorite()
        elif event.button.id == "back-btn":
            self.action_go_back()

    def action_escape_action(self) -> None:
        """Go back."""
        self.action_go_back()

    def on_input_submitted(self, event: Input.Submitted) -> None:
        """Handle Enter in search input to jump to next match."""
        if event.input.id == "search-input":
            if self._search_matches:
                self._current_match = (self._current_match + 1) % len(self._search_matches)
                self._goto_current_match()
                self._update_match_label()

    def on_key(self, event: Key) -> None:
        """Handle Shift+Enter for previous match."""
        focused = self.app.focused
        if focused and focused.id == "search-input" and event.key == "shift+enter":
            event.prevent_default()
            event.stop()
            if self._search_matches:
                self._current_match = (self._current_match - 1) % len(self._search_matches)
                self._goto_current_match()
                self._update_match_label()

    def on_input_changed(self, event: Input.Changed) -> None:
        """Handle live search as user types."""
        if event.input.id == "search-input":
            self._perform_search(event.value)

    def _perform_search(self, query: str) -> None:
        """Search the transcript for the query."""
        self._search_matches = []
        self._current_match = -1
        info_label = self.query_one("#search-info", Label)

        if not query:
            info_label.update("")
            return

        content_area = self.query_one("#transcript-content", TextArea)
        text = content_area.text
        query_lower = query.lower()

        # Find all matches (line, col)
        for line_idx, line in enumerate(text.splitlines()):
            col = 0
            line_lower = line.lower()
            while True:
                pos = line_lower.find(query_lower, col)
                if pos == -1:
                    break
                self._search_matches.append((line_idx, pos))
                col = pos + 1

        if self._search_matches:
            self._current_match = 0
            self._goto_current_match()
            self._update_match_label()
        else:
            info_label.update("[yellow]No matches[/yellow]")

    def _goto_current_match(self) -> None:
        """Scroll to the current match."""
        if not self._search_matches or self._current_match < 0:
            return

        line, col = self._search_matches[self._current_match]
        content_area = self.query_one("#transcript-content", TextArea)

        # Move cursor to the match location
        content_area.selection = Selection.cursor((line, col))
        content_area.scroll_cursor_visible()

    def _update_match_label(self) -> None:
        """Update the match counter label."""
        info_label = self.query_one("#search-info", Label)
        info_label.update(
            f"[bold]{self._current_match + 1}/{len(self._search_matches)}[/bold]"
        )

    def action_toggle_favorite(self) -> None:
        """Toggle favorite status."""
        config = get_config()
        filename = self.transcript_path.name

        if config.is_favorite(filename):
            config.remove_favorite(filename)
            self.notify(f"Removed from favorites: {filename}")
        else:
            config.add_favorite(filename)
            self.notify(f"Added to favorites: {filename}")

        # Update the button
        btn = self.query_one("#favorite-btn", Button)
        is_favorite = config.is_favorite(filename)
        btn.label = "★ Favorite" if not is_favorite else "☆ Unfavorite"
        btn.variant = "warning" if is_favorite else "default"

        # Update title
        title = self.query_one(".title", Static)
        star = "★ " if is_favorite else ""
        title.update(f"[bold]{star}{filename}[/bold]")

    def action_go_back(self) -> None:
        """Go back to the previous screen."""
        self.app.pop_screen()
