"""UI Widgets for Meeting Noter."""
