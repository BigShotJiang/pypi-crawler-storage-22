"""Tests for the update checker module."""

from __future__ import annotations

import json
from unittest.mock import MagicMock, patch

import pytest

from meeting_noter.update_checker import (
    check_for_update,
    check_for_update_async,
    get_latest_version,
    parse_version,
)


class TestParseVersion:
    """Tests for parse_version function."""

    def test_parse_simple_version(self):
        """Should parse simple version string."""
        assert parse_version("1.2.3") == (1, 2, 3)

    def test_parse_two_part_version(self):
        """Should parse two-part version string."""
        assert parse_version("1.0") == (1, 0)

    def test_parse_single_part_version(self):
        """Should parse single-part version string."""
        assert parse_version("1") == (1,)

    def test_parse_invalid_version(self):
        """Should return (0, 0, 0) for invalid version."""
        assert parse_version("invalid") == (0, 0, 0)
        assert parse_version("1.2.invalid") == (0, 0, 0)
        assert parse_version("") == (0, 0, 0)

    def test_version_comparison(self):
        """Parsed versions should compare correctly."""
        v1 = parse_version("1.2.3")
        v2 = parse_version("1.2.4")
        v3 = parse_version("2.0.0")

        assert v1 < v2
        assert v2 < v3
        assert v1 < v3


class TestGetLatestVersion:
    """Tests for get_latest_version function."""

    def test_get_latest_version_success(self, mocker):
        """Should fetch latest version from PyPI."""
        mock_response = MagicMock()
        mock_response.read.return_value = json.dumps({
            "info": {"version": "2.0.0"}
        }).encode()
        mock_response.__enter__ = MagicMock(return_value=mock_response)
        mock_response.__exit__ = MagicMock(return_value=False)

        mocker.patch("urllib.request.urlopen", return_value=mock_response)

        result = get_latest_version()

        assert result == "2.0.0"

    def test_get_latest_version_network_error(self, mocker):
        """Should return None on network error."""
        mocker.patch("urllib.request.urlopen", side_effect=Exception("Network error"))

        result = get_latest_version()

        assert result is None

    def test_get_latest_version_invalid_json(self, mocker):
        """Should return None on invalid JSON."""
        mock_response = MagicMock()
        mock_response.read.return_value = b"not json"
        mock_response.__enter__ = MagicMock(return_value=mock_response)
        mock_response.__exit__ = MagicMock(return_value=False)

        mocker.patch("urllib.request.urlopen", return_value=mock_response)

        result = get_latest_version()

        assert result is None

    def test_get_latest_version_missing_version(self, mocker):
        """Should return None when version not in response."""
        mock_response = MagicMock()
        mock_response.read.return_value = json.dumps({
            "info": {}
        }).encode()
        mock_response.__enter__ = MagicMock(return_value=mock_response)
        mock_response.__exit__ = MagicMock(return_value=False)

        mocker.patch("urllib.request.urlopen", return_value=mock_response)

        result = get_latest_version()

        assert result is None


class TestCheckForUpdate:
    """Tests for check_for_update function."""

    def test_update_available(self, mocker):
        """Should return new version when update available."""
        mocker.patch(
            "meeting_noter.update_checker.get_latest_version",
            return_value="99.0.0",
        )

        result = check_for_update()

        assert result == "99.0.0"

    def test_no_update_available(self, mocker):
        """Should return None when already on latest."""
        mocker.patch(
            "meeting_noter.update_checker.get_latest_version",
            return_value="0.0.1",  # Older than any current version
        )

        result = check_for_update()

        assert result is None

    def test_no_version_available(self, mocker):
        """Should return None when can't fetch version."""
        mocker.patch(
            "meeting_noter.update_checker.get_latest_version",
            return_value=None,
        )

        result = check_for_update()

        assert result is None

    def test_same_version(self, mocker):
        """Should return None when on same version."""
        from meeting_noter import __version__
        mocker.patch(
            "meeting_noter.update_checker.get_latest_version",
            return_value=__version__,
        )

        result = check_for_update()

        assert result is None


class TestCheckForUpdateAsync:
    """Tests for check_for_update_async function."""

    def test_async_update_check_with_update(self, mocker):
        """Should call callback with new version when update available."""
        mocker.patch(
            "meeting_noter.update_checker.check_for_update",
            return_value="99.0.0",
        )

        callback = MagicMock()

        # Run synchronously for testing
        check_for_update_async(callback)

        # Wait for thread to finish
        import time
        time.sleep(0.1)

        callback.assert_called_once_with("99.0.0")

    def test_async_update_check_no_update(self, mocker):
        """Should not call callback when no update available."""
        mocker.patch(
            "meeting_noter.update_checker.check_for_update",
            return_value=None,
        )

        callback = MagicMock()

        check_for_update_async(callback)

        # Wait for thread to finish
        import time
        time.sleep(0.1)

        callback.assert_not_called()

    def test_async_uses_daemon_thread(self, mocker):
        """Should use a daemon thread."""
        mock_check = mocker.patch(
            "meeting_noter.update_checker.check_for_update",
            return_value=None,
        )
        mock_thread_class = mocker.patch("threading.Thread")
        mock_thread = MagicMock()
        mock_thread_class.return_value = mock_thread

        callback = MagicMock()
        check_for_update_async(callback)

        # Verify daemon=True was passed
        mock_thread_class.assert_called_once()
        call_kwargs = mock_thread_class.call_args[1]
        assert call_kwargs["daemon"] is True
