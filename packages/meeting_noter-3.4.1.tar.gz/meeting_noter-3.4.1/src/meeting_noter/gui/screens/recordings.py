"""Recordings browser screen for Meeting Noter GUI."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Optional

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QAbstractItemView,
    QHBoxLayout,
    QHeaderView,
    QInputDialog,
    QLabel,
    QLineEdit,
    QMenu,
    QMessageBox,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from meeting_noter.config import get_config
from meeting_noter.gui.utils.signals import get_app_state
from meeting_noter.gui.utils.workers import TranscriptionWorker
from meeting_noter.output.writer import format_duration, format_size, get_audio_duration, extract_meeting_name


@dataclass
class RecordingInfo:
    """Information about a recording (transcript-first model)."""

    filepath: Path  # Primary file (.txt transcript or .mp3 if no transcript)
    audio_path: Optional[Path]  # Path to audio file (may not exist)
    date: datetime
    duration: Optional[float]
    has_audio: bool  # True if MP3 exists
    has_transcript: bool  # True if transcript exists
    is_favorite: bool
    tags: list[str]


class RecordingsScreen(QWidget):
    """Screen for browsing and managing recordings."""

    BATCH_SIZE = 50  # Number of recordings to load per batch

    def __init__(self, parent=None):
        super().__init__(parent)
        self._recordings: list[RecordingInfo] = []  # Currently displayed (filtered + paginated)
        self._all_recordings: list[RecordingInfo] = []  # Full list from disk
        self._filtered_recordings: list[RecordingInfo] = []  # After search filter applied
        self._search_term: str = ""
        self._transcribing: dict[Path, TranscriptionWorker] = {}
        self._setup_ui()
        self._connect_signals()

    def _setup_ui(self):
        """Set up the recordings UI."""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(30, 30, 30, 30)
        layout.setSpacing(20)

        # Title row with search
        title_row = QHBoxLayout()

        title = QLabel("Recordings")
        title.setStyleSheet("font-size: 24px; font-weight: 600; color: #ffffff;")
        title_row.addWidget(title)

        title_row.addStretch()

        # Search box
        self._search_input = QLineEdit()
        self._search_input.setPlaceholderText("Search name or tags...")
        self._search_input.setFixedWidth(250)
        self._search_input.setStyleSheet(
            """
            QLineEdit {
                background-color: #2d2d2d;
                border: 1px solid #3c3c3c;
                border-radius: 4px;
                padding: 6px 12px;
                font-size: 13px;
                color: #ffffff;
            }
            QLineEdit:focus {
                border-color: #0e639c;
            }
            """
        )
        self._search_input.textChanged.connect(self._on_search_changed)
        title_row.addWidget(self._search_input)

        layout.addLayout(title_row)

        # Table
        # Columns: ★, Name, Tags, Duration, Date
        self._table = QTableWidget()
        self._table.setColumnCount(5)
        self._table.setHorizontalHeaderLabels(
            ["\u2605", "Name", "Tags", "Duration", "Date"]
        )
        self._table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self._table.setSelectionMode(QAbstractItemView.ExtendedSelection)  # Allow multi-select with Ctrl/Shift
        self._table.setAlternatingRowColors(False)  # We'll handle row colors manually
        self._table.setSortingEnabled(True)
        self._table.verticalHeader().setVisible(False)
        self._table.setEditTriggers(QAbstractItemView.NoEditTriggers)  # Disable built-in editing

        # Column widths - all auto-size except Tags which can stretch for remaining space
        header = self._table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.Fixed)  # ★
        header.resizeSection(0, 40)
        header.setSectionResizeMode(1, QHeaderView.ResizeToContents)  # Name
        header.setSectionResizeMode(2, QHeaderView.Stretch)  # Tags gets remaining space
        header.setSectionResizeMode(3, QHeaderView.ResizeToContents)  # Duration
        header.setSectionResizeMode(4, QHeaderView.ResizeToContents)  # Date

        self._table.doubleClicked.connect(self._on_cell_double_clicked)
        self._table.cellClicked.connect(self._on_cell_clicked)

        # Enable right-click context menu
        self._table.setContextMenuPolicy(Qt.CustomContextMenu)
        self._table.customContextMenuRequested.connect(self._show_context_menu)

        layout.addWidget(self._table, 1)

        # Bottom row (simplified - most actions are in context menu)
        button_row = QHBoxLayout()
        button_row.setSpacing(10)

        # Hint label
        hint_label = QLabel("Double-click to view | Right-click for actions | \U0001F50A audio | \U0001F4C4 transcript only")
        hint_label.setStyleSheet("color: #666666; font-size: 11px;")
        button_row.addWidget(hint_label)

        button_row.addStretch()

        self._load_more_btn = QPushButton("Load More")
        self._load_more_btn.setProperty("class", "secondary")
        self._load_more_btn.setStyleSheet("background-color: #3c3c3c;")
        self._load_more_btn.setVisible(False)  # Hidden until needed
        button_row.addWidget(self._load_more_btn)

        self._refresh_btn = QPushButton("Refresh")
        self._refresh_btn.setProperty("class", "secondary")
        self._refresh_btn.setStyleSheet("background-color: #3c3c3c;")
        button_row.addWidget(self._refresh_btn)

        layout.addLayout(button_row)

        # Status label
        self._status_label = QLabel("")
        self._status_label.setStyleSheet("color: #858585;")
        layout.addWidget(self._status_label)

    def _connect_signals(self):
        """Connect button signals."""
        self._refresh_btn.clicked.connect(self.refresh)
        self._load_more_btn.clicked.connect(self._load_more)

    def refresh(self):
        """Refresh the recordings list (reloads from disk)."""
        self._load_all_recordings()
        self._apply_filter()
        self._recordings = self._filtered_recordings[:self.BATCH_SIZE]
        self._update_load_more_button()
        self._populate_table()

    def _on_search_changed(self, text: str):
        """Handle search input changes."""
        self._search_term = text.strip().lower()
        self._apply_filter()
        self._recordings = self._filtered_recordings[:self.BATCH_SIZE]
        self._update_load_more_button()
        self._populate_table()

    def _apply_filter(self):
        """Apply search filter to all recordings."""
        if not self._search_term:
            self._filtered_recordings = self._all_recordings
            return

        filtered = []
        for rec in self._all_recordings:
            # Get clean meeting name for searching
            name = extract_meeting_name(rec.filepath.name).lower()
            # Get tags as lowercase string
            tags = " ".join(rec.tags).lower() if rec.tags else ""

            # Match if search term is in name or tags
            if self._search_term in name or self._search_term in tags:
                filtered.append(rec)

        self._filtered_recordings = filtered

    def _load_more(self):
        """Load more recordings."""
        current_count = len(self._recordings)
        new_count = min(current_count + self.BATCH_SIZE, len(self._filtered_recordings))
        self._recordings = self._filtered_recordings[:new_count]
        self._update_load_more_button()
        self._populate_table()

    def _update_load_more_button(self):
        """Update the Load More button visibility and text."""
        remaining = len(self._filtered_recordings) - len(self._recordings)
        if remaining > 0:
            self._load_more_btn.setText(f"Load More ({remaining} remaining)")
            self._load_more_btn.setVisible(True)
        else:
            self._load_more_btn.setVisible(False)

    def _load_all_recordings(self):
        """Load all recordings from disk (transcript-first approach)."""
        config = get_config()
        recordings_dir = config.recordings_dir
        transcripts_dir = config.transcripts_dir

        recordings = []
        seen_stems = set()  # Track which stems we've processed

        # PRIMARY: Scan transcript files first
        if transcripts_dir.exists():
            txt_files = sorted(
                transcripts_dir.glob("*.txt"),
                key=lambda p: p.stat().st_mtime,
                reverse=True,
            )

            for txt_path in txt_files:
                try:
                    # Skip summary files and live files
                    if txt_path.stem.endswith('.summary') or '.live' in txt_path.name:
                        continue

                    stem = txt_path.stem
                    seen_stems.add(stem)

                    # Check for corresponding audio
                    audio_path = recordings_dir / f"{stem}.mp3"
                    has_audio = audio_path.exists()

                    # Parse date from filename
                    date = self._parse_date_from_stem(stem)
                    if date is None:
                        date = datetime.fromtimestamp(txt_path.stat().st_mtime)

                    # Get duration from audio if available, else try transcript header
                    duration = None
                    if has_audio:
                        try:
                            duration = get_audio_duration(audio_path)
                        except Exception:
                            pass
                    if duration is None:
                        duration = self._parse_duration_from_transcript(txt_path)

                    # Check favorite/tags (try both .txt and .mp3 names for compatibility)
                    is_favorite = config.is_favorite(txt_path.name) or config.is_favorite(f"{stem}.mp3")
                    tags = config.get_tags(txt_path.name) or config.get_tags(f"{stem}.mp3")

                    recordings.append(
                        RecordingInfo(
                            filepath=txt_path,
                            audio_path=audio_path if has_audio else None,
                            date=date,
                            duration=duration,
                            has_audio=has_audio,
                            has_transcript=True,
                            is_favorite=is_favorite,
                            tags=tags,
                        )
                    )
                except Exception:
                    continue

        # SECONDARY: Find orphan MP3s (audio without transcript)
        if recordings_dir.exists():
            for mp3_path in recordings_dir.glob("*.mp3"):
                try:
                    stem = mp3_path.stem
                    if stem in seen_stems:
                        continue  # Already processed via transcript

                    # Parse date from filename
                    date = self._parse_date_from_stem(stem)
                    if date is None:
                        date = datetime.fromtimestamp(mp3_path.stat().st_mtime)

                    # Get duration
                    try:
                        duration = get_audio_duration(mp3_path)
                    except Exception:
                        duration = None

                    recordings.append(
                        RecordingInfo(
                            filepath=mp3_path,  # Use MP3 as primary for orphans
                            audio_path=mp3_path,
                            date=date,
                            duration=duration,
                            has_audio=True,
                            has_transcript=False,
                            is_favorite=config.is_favorite(mp3_path.name),
                            tags=config.get_tags(mp3_path.name),
                        )
                    )
                except Exception:
                    continue

        # Sort by date
        recordings.sort(key=lambda r: r.date, reverse=True)
        self._all_recordings = recordings

    def _parse_date_from_stem(self, stem: str) -> Optional[datetime]:
        """Parse date from filename stem."""
        parts = stem.split("_", 2)
        if len(parts) >= 2:
            # Try YYYY-MM-DD_HHMMSS format
            if "-" in parts[0]:
                try:
                    return datetime.strptime(f"{parts[0]}_{parts[1]}", "%Y-%m-%d_%H%M%S")
                except ValueError:
                    pass
            # Try DD_Mon_YYYY_HHMM format
            if len(parts) >= 4:
                try:
                    return datetime.strptime(f"{parts[0]}_{parts[1]}_{parts[2]}_{parts[3]}", "%d_%b_%Y_%H%M")
                except ValueError:
                    pass
        return None

    def _parse_duration_from_transcript(self, txt_path: Path) -> Optional[float]:
        """Try to parse duration from transcript header."""
        try:
            with open(txt_path, 'r') as f:
                for line in f:
                    if line.startswith("Duration:"):
                        # Format: "Duration: 123.4 seconds"
                        parts = line.split()
                        if len(parts) >= 2:
                            return float(parts[1])
                    if line.startswith("---"):  # End of header
                        break
        except Exception:
            pass
        return None

    def _populate_table(self):
        """Populate the table with recordings."""
        self._table.setRowCount(len(self._recordings))

        from PySide6.QtGui import QColor, QBrush

        for row, rec in enumerate(self._recordings):
            # Determine row background color based on status
            audio_key = rec.audio_path if rec.audio_path else rec.filepath
            if audio_key in self._transcribing:
                row_bg = QColor("#3d3d00")  # Yellow tint for processing
            elif not rec.has_transcript:
                row_bg = QColor("#2d2020")  # Red tint for no transcript
            else:
                row_bg = None  # Default background

            # Column 0: Favorite star (clickable)
            star_item = QTableWidgetItem("\u2605" if rec.is_favorite else "\u2606")
            star_item.setTextAlignment(Qt.AlignCenter)
            star_item.setData(Qt.UserRole, rec.filepath)
            if rec.is_favorite:
                star_item.setForeground(Qt.yellow)
            else:
                star_item.setForeground(Qt.gray)
            if row_bg:
                star_item.setBackground(QBrush(row_bg))
            self._table.setItem(row, 0, star_item)

            # Column 1: Name with audio status icon (double-click to rename)
            clean_name = extract_meeting_name(rec.filepath.name)
            if rec.has_audio:
                display_name = f"\U0001F50A {clean_name}"  # 🔊 speaker icon
            else:
                display_name = f"\U0001F4C4 {clean_name}"  # 📄 document icon
            name_item = QTableWidgetItem(display_name)
            name_item.setToolTip(f"{rec.filepath.name}\n{'Audio available' if rec.has_audio else 'Transcript only (audio deleted)'}")
            if row_bg:
                name_item.setBackground(QBrush(row_bg))
            self._table.setItem(row, 1, name_item)

            # Column 2: Tags (double-click to edit)
            tags_str = ", ".join(rec.tags) if rec.tags else ""
            tags_item = QTableWidgetItem(tags_str)
            if rec.tags:
                tags_item.setForeground(Qt.cyan)
            else:
                tags_item.setForeground(Qt.gray)
            if row_bg:
                tags_item.setBackground(QBrush(row_bg))
            self._table.setItem(row, 2, tags_item)

            # Column 3: Duration
            if rec.duration:
                duration_str = format_duration(rec.duration)
            else:
                duration_str = "?"
            duration_item = QTableWidgetItem(duration_str)
            duration_item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            if row_bg:
                duration_item.setBackground(QBrush(row_bg))
            self._table.setItem(row, 3, duration_item)

            # Column 4: Date
            date_item = QTableWidgetItem(rec.date.strftime("%Y-%m-%d %H:%M"))
            date_item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            if row_bg:
                date_item.setBackground(QBrush(row_bg))
            self._table.setItem(row, 4, date_item)

        total = len(self._all_recordings)
        filtered = len(self._filtered_recordings)
        showing = len(self._recordings)

        if self._search_term:
            # Searching
            if showing < filtered:
                self._status_label.setText(f"Showing {showing} of {filtered} matches (from {total} total)")
            else:
                self._status_label.setText(f"{filtered} matches (from {total} total)")
        else:
            # Not searching
            if showing < total:
                self._status_label.setText(f"Showing {showing} of {total} recordings")
            else:
                self._status_label.setText(f"{total} recordings")

    def _get_selected_recording(self) -> Optional[RecordingInfo]:
        """Get the currently selected recording (first if multiple)."""
        row = self._table.currentRow()
        if 0 <= row < len(self._recordings):
            return self._recordings[row]
        return None

    def _get_selected_recordings(self) -> list[RecordingInfo]:
        """Get all selected recordings."""
        selected_rows = set()
        for index in self._table.selectedIndexes():
            selected_rows.add(index.row())
        return [self._recordings[row] for row in sorted(selected_rows) if 0 <= row < len(self._recordings)]

    def _view_transcript(self):
        """View the transcript for the selected recording."""
        rec = self._get_selected_recording()
        if not rec:
            return

        if not rec.has_transcript:
            self._status_label.setText("No transcript available. Transcribe first.")
            return

        # In transcript-first model, filepath is the transcript if has_transcript
        if rec.filepath.suffix == '.txt':
            transcript_path = rec.filepath
        else:
            config = get_config()
            transcript_path = config.transcripts_dir / f"{rec.filepath.stem}.txt"

        if transcript_path.exists():
            app_state = get_app_state()
            app_state.open_transcript.emit(str(transcript_path))

    def _on_cell_clicked(self, row: int, column: int):
        """Handle single click on a cell."""
        # Column 0 = Favorite star - toggle on single click
        if column == 0:
            self._toggle_favorite_for_row(row)

    def _on_cell_double_clicked(self, index):
        """Handle double-click on a cell - opens transcript (except favorite column)."""
        column = index.column()

        # Column 0 (★) - ignore double-click, single click already toggles
        if column == 0:
            return

        # All other columns - view transcript
        self._view_transcript()

    def _show_context_menu(self, position):
        """Show right-click context menu."""
        row = self._table.rowAt(position.y())
        if row < 0 or row >= len(self._recordings):
            return

        # Check if clicked row is already in selection, if not, select only this row
        selected_rows = set(index.row() for index in self._table.selectedIndexes())
        if row not in selected_rows:
            self._table.selectRow(row)
            selected_rows = {row}

        selected_recordings = self._get_selected_recordings()
        menu = QMenu(self)

        # Multi-select: only show Delete option
        if len(selected_recordings) > 1:
            delete_action = menu.addAction(f"\u274C Delete {len(selected_recordings)} Recordings")
            delete_action.triggered.connect(self._delete_recordings)
            menu.exec_(self._table.viewport().mapToGlobal(position))
            return

        # Single selection: show full menu
        rec = selected_recordings[0] if selected_recordings else None
        if not rec:
            return

        # View Transcript (if has transcript)
        if rec.has_transcript:
            view_action = menu.addAction("\U0001F4D6 View Transcript")
            view_action.triggered.connect(self._view_transcript)

        # Transcribe (if has audio but no transcript)
        if rec.has_audio and not rec.has_transcript:
            transcribe_action = menu.addAction("\U0001F399 Transcribe")
            transcribe_action.triggered.connect(self._transcribe_selected)

        menu.addSeparator()

        # Rename
        rename_action = menu.addAction("\u270F Rename")
        rename_action.triggered.connect(self._rename_selected)

        # Tags
        tags_action = menu.addAction("\U0001F3F7 Edit Tags")
        tags_action.triggered.connect(self._manage_tags)

        menu.addSeparator()

        # Favorite toggle
        if rec.is_favorite:
            fav_action = menu.addAction("\u2606 Remove Favorite")
        else:
            fav_action = menu.addAction("\u2605 Add Favorite")
        fav_action.triggered.connect(self._toggle_favorite)

        menu.addSeparator()

        # Delete Audio (if has audio and has transcript)
        if rec.has_audio and rec.has_transcript:
            delete_audio_action = menu.addAction("\U0001F5D1 Delete Audio (keep transcript)")
            delete_audio_action.triggered.connect(self._delete_audio)

        # Delete All (always available)
        delete_all_action = menu.addAction("\u274C Delete Recording")
        delete_all_action.triggered.connect(self._delete_recordings)

        menu.exec_(self._table.viewport().mapToGlobal(position))

    def _delete_audio(self):
        """Delete audio file but keep transcript."""
        rec = self._get_selected_recording()
        if not rec or not rec.has_audio or not rec.audio_path:
            return

        clean_name = extract_meeting_name(rec.filepath.name)

        reply = QMessageBox.question(
            self,
            "Delete Audio",
            f"Delete audio for '{clean_name}'?\n\nThe transcript will be kept.",
            QMessageBox.Yes | QMessageBox.No
        )

        if reply == QMessageBox.Yes:
            try:
                rec.audio_path.unlink()
                self._status_label.setText(f"Audio deleted, transcript kept: {clean_name}")
                self.refresh()
            except Exception as e:
                QMessageBox.warning(self, "Error", f"Failed to delete audio: {e}")

    def _delete_recordings(self):
        """Delete both audio and transcript for selected recording(s)."""
        selected = self._get_selected_recordings()
        if not selected:
            return

        config = get_config()

        # Build confirmation message
        if len(selected) == 1:
            rec = selected[0]
            clean_name = extract_meeting_name(rec.filepath.name)
            files_to_delete = []
            if rec.has_audio and rec.audio_path:
                files_to_delete.append("audio file")
            if rec.has_transcript:
                files_to_delete.append("transcript")
            message = f"Delete '{clean_name}'?\n\nThis will delete: {', '.join(files_to_delete)}"
            title = "Delete Recording"
        else:
            message = f"Delete {len(selected)} recordings?\n\nThis will delete all audio files and transcripts for the selected items."
            title = "Delete Recordings"

        reply = QMessageBox.question(
            self,
            title,
            message,
            QMessageBox.Yes | QMessageBox.No
        )

        if reply == QMessageBox.Yes:
            deleted_count = 0
            errors = []

            for rec in selected:
                try:
                    # Delete audio if exists
                    if rec.has_audio and rec.audio_path and rec.audio_path.exists():
                        rec.audio_path.unlink()

                    # Delete transcript if exists
                    if rec.has_transcript:
                        transcript_path = rec.filepath if rec.filepath.suffix == '.txt' else config.transcripts_dir / f"{rec.filepath.stem}.txt"
                        if transcript_path.exists():
                            transcript_path.unlink()

                    deleted_count += 1
                except Exception as e:
                    errors.append(f"{rec.filepath.name}: {e}")

            if errors:
                QMessageBox.warning(self, "Errors", f"Some files failed to delete:\n" + "\n".join(errors))

            self._status_label.setText(f"Deleted {deleted_count} recording(s)")
            self.refresh()

    def _toggle_favorite_for_row(self, row: int):
        """Toggle favorite for a specific row."""
        if not (0 <= row < len(self._recordings)):
            return

        rec = self._recordings[row]
        config = get_config()

        # Use transcript filename as the key for favorites
        fav_key = rec.filepath.name

        if rec.is_favorite:
            config.remove_favorite(fav_key)
            # Also try to remove old mp3-based favorite for compatibility
            if rec.audio_path:
                config.remove_favorite(rec.audio_path.name)
            self._status_label.setText(f"Removed from favorites")
        else:
            config.add_favorite(fav_key)
            self._status_label.setText(f"Added to favorites")

        self.refresh()

    def _rename_for_row(self, row: int):
        """Rename recording for a specific row."""
        if not (0 <= row < len(self._recordings)):
            return

        # Temporarily select this row
        self._table.selectRow(row)
        self._rename_selected()

    def _manage_tags_for_row(self, row: int):
        """Manage tags for a specific row."""
        if not (0 <= row < len(self._recordings)):
            return

        # Temporarily select this row
        self._table.selectRow(row)
        self._manage_tags()

    def _transcribe_selected(self):
        """Transcribe the selected recording."""
        rec = self._get_selected_recording()
        if not rec:
            return

        if rec.has_transcript:
            self._status_label.setText("Already transcribed.")
            return

        if not rec.has_audio or not rec.audio_path:
            self._status_label.setText("No audio file available to transcribe.")
            return

        if rec.audio_path in self._transcribing:
            self._status_label.setText("Transcription already in progress.")
            return

        config = get_config()
        worker = TranscriptionWorker(rec.audio_path, model=config.whisper_model)
        worker.progress.connect(lambda msg: self._status_label.setText(msg))
        worker.finished.connect(lambda path, fp=rec.audio_path: self._on_transcribe_finished(fp, path))
        worker.error.connect(lambda err, fp=rec.audio_path: self._on_transcribe_error(fp, err))

        self._transcribing[rec.audio_path] = worker
        self._populate_table()
        self._status_label.setText(f"Transcribing {rec.audio_path.name}...")
        worker.start()

    def _on_transcribe_finished(self, filepath: Path, transcript_path: str):
        """Handle transcription completion."""
        self._transcribing.pop(filepath, None)
        self._status_label.setText(f"Transcription complete: {filepath.name}")
        self.refresh()

    def _on_transcribe_error(self, filepath: Path, error: str):
        """Handle transcription error."""
        self._transcribing.pop(filepath, None)
        self._status_label.setText(f"Transcription failed: {error}")
        self._populate_table()

    def _toggle_favorite(self):
        """Toggle favorite status for the selected recording."""
        rec = self._get_selected_recording()
        if not rec:
            return

        config = get_config()
        clean_name = extract_meeting_name(rec.filepath.name)
        fav_key = rec.filepath.name

        if rec.is_favorite:
            config.remove_favorite(fav_key)
            if rec.audio_path:
                config.remove_favorite(rec.audio_path.name)
            self._status_label.setText(f"Removed from favorites: {clean_name}")
        else:
            config.add_favorite(fav_key)
            self._status_label.setText(f"Added to favorites: {clean_name}")

        # Refresh to update star display
        self.refresh()

    def _rename_selected(self):
        """Rename the selected recording."""
        rec = self._get_selected_recording()
        if not rec:
            self._status_label.setText("No recording selected.")
            return

        # Get current name (without timestamp prefix and extension)
        from meeting_noter.output.writer import extract_timestamp_prefix

        stem = rec.filepath.stem
        timestamp = extract_timestamp_prefix(stem)
        if timestamp:
            # Extract the name part after the timestamp
            current_name = stem[len(timestamp) + 1:] if len(stem) > len(timestamp) else ""
        else:
            current_name = stem

        # Replace underscores with spaces for display
        current_name = current_name.replace("_", " ")

        # Show input dialog
        new_name, ok = QInputDialog.getText(
            self,
            "Rename Meeting",
            "Enter new meeting name:",
            text=current_name,
        )

        if not ok or not new_name.strip():
            return

        new_name = new_name.strip()

        # Perform the rename
        from meeting_noter.output.writer import rename_meeting

        config = get_config()
        try:
            new_path = rename_meeting(rec.filepath, new_name, config)
            self._status_label.setText(f"Renamed to: {new_path.name}")
            self.refresh()
        except FileExistsError:
            QMessageBox.warning(
                self,
                "Rename Failed",
                f"A file with that name already exists.",
            )
        except PermissionError:
            QMessageBox.warning(
                self,
                "Rename Failed",
                "Permission denied. Cannot rename files.",
            )
        except Exception as e:
            QMessageBox.warning(
                self,
                "Rename Failed",
                f"Error renaming file: {e}",
            )

    def _manage_tags(self):
        """Manage tags for the selected recording."""
        rec = self._get_selected_recording()
        if not rec:
            self._status_label.setText("No recording selected.")
            return

        config = get_config()

        # Use the stored tags from the recording (already resolved during load)
        current_tags = rec.tags or []
        current_tags_str = ", ".join(current_tags) if current_tags else ""

        # Determine the primary key for saving (prefer .txt for transcript-first)
        primary_key = rec.filepath.name
        # Also track the alternate key for migration
        stem = rec.filepath.stem
        alt_key = f"{stem}.mp3" if rec.filepath.suffix == ".txt" else f"{stem}.txt"

        # Show input dialog with current tags
        new_tags_str, ok = QInputDialog.getText(
            self,
            "Manage Tags",
            "Enter tags (comma-separated):\n\nExample: Project X, Sprint Planning, Q1 Review",
            text=current_tags_str,
        )

        if not ok:
            return

        # Parse new tags
        new_tags = [tag.strip() for tag in new_tags_str.split(",") if tag.strip()]

        # Clear tags from both keys to avoid duplicates
        for old_tag in current_tags:
            config.remove_tag(primary_key, old_tag)
            config.remove_tag(alt_key, old_tag)

        # Add new tags to primary key only
        for new_tag in new_tags:
            config.add_tag(primary_key, new_tag)

        if new_tags:
            self._status_label.setText(f"Tags updated: {', '.join(new_tags)}")
        else:
            self._status_label.setText("Tags cleared")

        self.refresh()
