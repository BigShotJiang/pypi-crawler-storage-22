"""Monitor microphone usage to detect when meetings start/end."""

from __future__ import annotations

import ctypes
from ctypes import c_uint32, c_int32, byref, POINTER, Structure
import re
import time
from typing import Optional
from dataclasses import dataclass


@dataclass
class MicStatus:
    """Status of microphone usage."""
    is_in_use: bool
    app_name: Optional[str] = None


@dataclass
class DetectedMeeting:
    """Information about a detected meeting (app-agnostic)."""
    app_name: str
    bundle_id: Optional[str]
    window_title: Optional[str]


# CoreAudio constants
_kAudioObjectSystemObject = 1
_kAudioHardwarePropertyDefaultInputDevice = 1682533920  # 'dIn '
_kAudioDevicePropertyDeviceIsRunningSomewhere = 1735356005  # 'gone'
_kAudioObjectPropertyScopeGlobal = 1735159650  # 'glob'
_kAudioObjectPropertyElementMain = 0


class _AudioObjectPropertyAddress(Structure):
    _fields_ = [
        ('mSelector', c_uint32),
        ('mScope', c_uint32),
        ('mElement', c_uint32),
    ]


# Load CoreAudio framework lazily
_core_audio = None
_AudioObjectGetPropertyDataSize = None
_AudioObjectGetPropertyData = None
_coreaudio_init_time = 0  # Track when CoreAudio was initialized


def _reset_coreaudio():
    """Reset CoreAudio framework (for reinitializing after long idle)."""
    global _core_audio, _AudioObjectGetPropertyDataSize, _AudioObjectGetPropertyData, _coreaudio_init_time
    _core_audio = None
    _AudioObjectGetPropertyDataSize = None
    _AudioObjectGetPropertyData = None
    _coreaudio_init_time = 0


def _init_coreaudio():
    """Initialize CoreAudio framework."""
    global _core_audio, _AudioObjectGetPropertyDataSize, _AudioObjectGetPropertyData, _coreaudio_init_time

    if _core_audio is not None:
        return True

    try:
        _core_audio = ctypes.CDLL('/System/Library/Frameworks/CoreAudio.framework/CoreAudio')

        _AudioObjectGetPropertyDataSize = _core_audio.AudioObjectGetPropertyDataSize
        _AudioObjectGetPropertyDataSize.argtypes = [
            c_uint32, POINTER(_AudioObjectPropertyAddress), c_uint32, ctypes.c_void_p, POINTER(c_uint32)
        ]
        _AudioObjectGetPropertyDataSize.restype = c_int32

        _AudioObjectGetPropertyData = _core_audio.AudioObjectGetPropertyData
        _AudioObjectGetPropertyData.argtypes = [
            c_uint32, POINTER(_AudioObjectPropertyAddress), c_uint32, ctypes.c_void_p, POINTER(c_uint32), ctypes.c_void_p
        ]
        _AudioObjectGetPropertyData.restype = c_int32

        _coreaudio_init_time = time.time()
        return True
    except Exception:
        return False


# Reinitialize CoreAudio every 30 minutes to prevent stale handles
_COREAUDIO_REFRESH_INTERVAL = 30 * 60


def _maybe_refresh_coreaudio():
    """Reinitialize CoreAudio if it's been too long since last init.

    This prevents stale CoreAudio handles after system sleep or long idle.
    """
    global _coreaudio_init_time
    if _core_audio is not None and time.time() - _coreaudio_init_time > _COREAUDIO_REFRESH_INTERVAL:
        _reset_coreaudio()


def is_mic_in_use_by_another_app() -> bool:
    """Check if the microphone is being used by another application.

    Uses CoreAudio's kAudioDevicePropertyDeviceIsRunningSomewhere property
    to detect if any app has an active audio input session.

    Returns:
        True if another app is using the microphone
    """
    # Refresh CoreAudio if it's been too long (prevents stale handles)
    _maybe_refresh_coreaudio()

    if not _init_coreaudio():
        return False

    try:
        # Get default input device
        addr = _AudioObjectPropertyAddress(
            _kAudioHardwarePropertyDefaultInputDevice,
            _kAudioObjectPropertyScopeGlobal,
            _kAudioObjectPropertyElementMain
        )

        size = c_uint32(4)
        device_id = c_uint32(0)

        err = _AudioObjectGetPropertyData(
            _kAudioObjectSystemObject, byref(addr), 0, None, byref(size), byref(device_id)
        )

        if err != 0 or device_id.value == 0:
            return False

        # Check if device is running somewhere (another app using it)
        addr_running = _AudioObjectPropertyAddress(
            _kAudioDevicePropertyDeviceIsRunningSomewhere,
            _kAudioObjectPropertyScopeGlobal,
            _kAudioObjectPropertyElementMain
        )

        is_running = c_uint32(0)
        size = c_uint32(4)

        err = _AudioObjectGetPropertyData(
            device_id.value, byref(addr_running), 0, None, byref(size), byref(is_running)
        )

        return err == 0 and is_running.value != 0

    except Exception:
        return False


# =============================================================================
# App-Agnostic Meeting Detection via TCC Database
# =============================================================================

def _get_apps_with_visible_windows() -> list[tuple[str, str, str]]:
    """Get running apps that have visible windows with meaningful titles.

    Returns list of (bundle_id, app_name, window_title) tuples.

    This is the app-agnostic approach - instead of relying on TCC database
    (which requires Full Disk Access), we look at visible windows and
    identify the app that's likely in a meeting based on window properties.
    """
    try:
        from AppKit import NSWorkspace
        import Quartz

        # Get all visible windows
        windows = Quartz.CGWindowListCopyWindowInfo(
            Quartz.kCGWindowListOptionOnScreenOnly | Quartz.kCGWindowListExcludeDesktopElements,
            Quartz.kCGNullWindowID
        )

        # Build a map of app name -> window info
        app_windows: dict[str, list[str]] = {}
        for window in windows:
            owner = window.get(Quartz.kCGWindowOwnerName, "")
            title = window.get(Quartz.kCGWindowName, "")
            layer = window.get(Quartz.kCGWindowLayer, 0)

            # Skip non-standard layers, empty titles, and auxiliary windows
            if not owner or not title or layer != 0:
                continue
            if _is_auxiliary_window_title(title):
                continue

            if owner not in app_windows:
                app_windows[owner] = []
            app_windows[owner].append(title)

        # Get bundle IDs for apps with visible windows
        workspace = NSWorkspace.sharedWorkspace()
        running_apps = {
            app.localizedName(): app.bundleIdentifier()
            for app in workspace.runningApplications()
            if app.localizedName() and app.bundleIdentifier()
        }

        result = []
        for app_name, titles in app_windows.items():
            bundle_id = running_apps.get(app_name, "")
            # Use the first (frontmost) window title
            if titles:
                result.append((bundle_id, app_name, titles[0]))

        return result
    except Exception:
        return []


def _is_auxiliary_window_title(title: str) -> bool:
    """Check if a window title indicates an auxiliary/UI window rather than the main content.

    This is app-agnostic - it uses generic patterns that apply to most apps:
    - Settings/preferences windows
    - Selection dialogs
    - Menu/notification windows
    - Empty or very generic titles

    Returns True if the title looks like an auxiliary window (should be skipped).
    """
    if not title or not title.strip():
        return True

    title_lower = title.lower().strip()

    # Very short titles are often auxiliary (but some meetings have short names, so be careful)
    # Skip only if it's a single common word
    single_word_auxiliary = {
        "menu", "login", "settings", "preferences", "options",
        "notifications", "chat", "participants", "transcript",
    }
    if title_lower in single_word_auxiliary:
        return True

    # Common auxiliary window patterns (works across apps)
    auxiliary_patterns = [
        "select ",          # "Select a window...", "Select file..."
        "choose ",          # "Choose application..."
        "settings",
        "preferences",
        "menu window",
        "notification",
        "healthcheck",
        "floating video",
        "media stream",
        "waiting room",
        "breakout room",
        " - not started",   # "Breakout rooms - Not started"
    ]

    for pattern in auxiliary_patterns:
        if pattern in title_lower:
            return True

    # Internal UI window prefixes (Zoom uses ZM_, others may have similar)
    if title.startswith(("ZM_", "zm_", "_")):
        return True

    return False


def detect_meeting_agnostic() -> Optional[DetectedMeeting]:
    """Detect active meeting without hardcoding app names.

    This is the app-agnostic approach:
    1. Check if microphone is in use
    2. Find apps with visible windows (excluding auxiliary windows)
    3. Identify the most likely meeting app based on window properties

    Works for ANY meeting app - Zoom, Teams, Meet, or any future app.
    """
    # First check if mic is even in use
    if not is_mic_in_use_by_another_app():
        return None

    # Get apps with visible windows
    visible_apps = _get_apps_with_visible_windows()
    if not visible_apps:
        return None

    # Filter out system apps and browsers (browsers need special handling)
    system_apps = {
        "finder", "system preferences", "system settings",
        "terminal", "iterm", "activity monitor", "console",
        "xcode", "visual studio code", "cursor", "pycharm",
    }
    browsers = {"chrome", "safari", "firefox", "edge", "brave", "arc"}

    # First pass: find dedicated meeting apps (not browsers or system apps)
    for bundle_id, app_name, window_title in visible_apps:
        app_lower = app_name.lower()
        if app_lower in system_apps:
            continue
        if any(b in app_lower for b in browsers):
            continue  # Handle browsers separately
        # This is likely the meeting app
        return DetectedMeeting(
            app_name=app_name,
            bundle_id=bundle_id,
            window_title=window_title,
        )

    # Second pass: check browsers for meeting indicators in window title
    for bundle_id, app_name, window_title in visible_apps:
        app_lower = app_name.lower()
        if any(b in app_lower for b in browsers):
            title_lower = window_title.lower()
            # Check for meeting-related titles
            if any(kw in title_lower for kw in ["meet", "meeting", "call", "conference", "huddle"]):
                return DetectedMeeting(
                    app_name=app_name,
                    bundle_id=bundle_id,
                    window_title=window_title,
                )

    return None


def get_meeting_window_title_agnostic() -> Optional[str]:
    """Get the meeting window title using app-agnostic detection.

    Returns the window title if found, or app name as fallback.
    """
    meeting = detect_meeting_agnostic()
    if not meeting:
        return None

    return meeting.window_title or meeting.app_name


# =============================================================================
# Legacy App-Specific Detection (kept for backwards compatibility)
# =============================================================================

def _is_zoom_meeting_window(title: str) -> bool:
    """Check if a Zoom window title indicates an active meeting.

    Zoom meeting windows have specific patterns:
    - "Zoom Meeting" (basic meeting)
    - "Zoom Meeting - <name>" or "<name> - Zoom Meeting"
    - "Zoom Webinar" variants
    - Custom meeting name without "Meeting" but NOT an auxiliary window

    Auxiliary windows have predictable patterns we can exclude efficiently.
    """
    if not title:
        return False

    title_lower = title.lower()

    # Positive match: explicit meeting/webinar indicators
    if "zoom meeting" in title_lower or "zoom webinar" in title_lower:
        return True

    # Quick exclusions for obviously non-meeting windows
    # Internal UI (ZM_ prefix), empty, or single-word app name
    if title.startswith("ZM_") or title.startswith("zm_"):
        return False
    if title_lower in ["zoom", "zoom.us", "zoom workplace"]:
        return False

    # Auxiliary window patterns - these are UI elements, not meetings
    # Key insight: meeting names are typically user-generated text,
    # while auxiliary windows have system-generated descriptive names
    auxiliary_patterns = [
        "select ",      # "Select a window...", "Select audio..."
        "participants", "breakout room", "transcript", "chat",
        "menu ", "login", "settings", "preferences",
        "healthcheck", "floating video", "media stream",
        "share screen", "recording", "waiting room",
    ]

    for pattern in auxiliary_patterns:
        if pattern in title_lower:
            return False

    # If we get here, it's a Zoom window that doesn't match auxiliary patterns
    # This is likely a meeting with a custom name
    return True


def is_meeting_app_active() -> Optional[str]:
    """Check if a meeting app has an ACTIVE MEETING window.

    Uses app-agnostic detection via TCC database first, then falls back
    to legacy app-specific detection for edge cases.

    Returns the app name only if there's an active call/meeting,
    not just because the app is open.
    """
    # Try app-agnostic detection first (works for any app)
    meeting = detect_meeting_agnostic()
    if meeting:
        return meeting.app_name

    # Fallback to legacy detection for edge cases (e.g., browser-based meetings
    # where the browser itself has mic permission, not the meeting site)
    return _is_meeting_app_active_legacy()


def _is_meeting_app_active_legacy() -> Optional[str]:
    """Legacy app-specific meeting detection.

    Kept for backwards compatibility and edge cases like browser-based meetings.
    """
    try:
        import Quartz

        # Get all on-screen windows
        windows = Quartz.CGWindowListCopyWindowInfo(
            Quartz.kCGWindowListOptionAll | Quartz.kCGWindowListExcludeDesktopElements,
            Quartz.kCGNullWindowID
        )

        # Check for browser-based meetings (Google Meet, etc.)
        # These need special handling because the browser has mic permission, not the site
        for win in windows:
            owner = win.get(Quartz.kCGWindowOwnerName, "")
            title = win.get(Quartz.kCGWindowName, "") or ""

            if not owner:
                continue

            owner_lower = owner.lower()
            title_lower = title.lower()

            # Browser-based meetings (Google Meet, etc.)
            if any(browser in owner_lower for browser in ["chrome", "safari", "firefox", "edge", "brave", "arc"]):
                # Skip video streaming sites
                if any(x in title_lower for x in ["youtube", "vimeo", "twitch", "netflix"]):
                    continue
                if title_lower.startswith("meet -") or "meet.google.com" in title_lower:
                    return "Google Meet"
                if " meeting" in title_lower and any(x in title_lower for x in ["zoom", "teams", "webex"]):
                    return "Browser Meeting"

        # Check for Slack/Discord huddles (secondary meeting apps)
        for win in windows:
            owner = win.get(Quartz.kCGWindowOwnerName, "")
            title = win.get(Quartz.kCGWindowName, "") or ""

            if not owner:
                continue

            owner_lower = owner.lower()
            title_lower = title.lower()

            # Slack: detect huddle/call windows only
            if "slack" in owner_lower:
                if any(x in title_lower for x in ["huddle", "call"]):
                    return "Slack"

            # Discord: detect voice channel
            if "discord" in owner_lower:
                if "voice connected" in title_lower:
                    return "Discord"

        return None
    except Exception:
        return None


def get_meeting_window_title() -> Optional[str]:
    """Get the window title of the active meeting app.

    Uses app-agnostic detection via TCC database first, then falls back
    to legacy detection for browser-based meetings.

    Returns the window title (meeting name) if found, or app name as fallback.
    """
    # Try app-agnostic detection first
    meeting = detect_meeting_agnostic()
    if meeting:
        title = meeting.window_title or meeting.app_name
        return _clean_meeting_title(title) if title else None

    # Fallback to legacy detection for browser-based meetings
    return _get_meeting_window_title_legacy()


def _get_meeting_window_title_legacy() -> Optional[str]:
    """Legacy window title detection for browser-based meetings."""
    try:
        import Quartz

        browsers = ["chrome", "safari", "firefox", "edge", "brave", "arc"]

        windows = Quartz.CGWindowListCopyWindowInfo(
            Quartz.kCGWindowListOptionAll | Quartz.kCGWindowListExcludeDesktopElements,
            Quartz.kCGNullWindowID
        )

        for win in windows:
            owner = win.get(Quartz.kCGWindowOwnerName, "")
            title = win.get(Quartz.kCGWindowName, "") or ""

            if not owner:
                continue

            owner_lower = owner.lower()
            title_lower = title.lower()

            # Check browser-based meetings (Google Meet)
            if any(browser in owner_lower for browser in browsers):
                if title_lower.startswith("meet -"):
                    return _clean_meeting_title(title)

        return None
    except Exception:
        return None


def _is_meaningful_title(title: str, app_name: str) -> bool:
    """Check if a window title is meaningful (contains the meeting name, not just app UI).

    Uses positive matching where possible - looking for meeting-like patterns
    rather than trying to enumerate all auxiliary windows.
    """
    if not title or not title.strip():
        return False

    title_lower = title.lower().strip()

    # Skip generic app-name-only titles
    generic_titles = [
        "zoom", "zoom.us", "zoom workplace",
        "microsoft teams", "teams",
        "slack", "discord", "facetime", "webex",
    ]
    if title_lower in generic_titles:
        return False

    # For Zoom, use the dedicated detection function
    if "zoom" in app_name.lower():
        return _is_zoom_meeting_window(title)

    # Skip internal UI windows (ZM_ prefix)
    if title.startswith("ZM_") or title.startswith("zm_"):
        return False

    return True


def _clean_meeting_title(title: str) -> str:
    """Clean up a meeting title for use as a filename."""
    import re

    # Remove common prefixes/suffixes
    title = title.strip()

    # Google Meet: "Meet - xyz-abc-123 🔊" -> "Meet_xyz-abc-123"
    if title.lower().startswith("meet - "):
        title = "Meet_" + title[7:]
        # Remove speaker emoji and other indicators
        title = re.sub(r'[🔊🔇📹]', '', title).strip()

    # Remove "Zoom Meeting - " prefix
    if title.lower().startswith("zoom meeting - "):
        title = title[15:]

    # Remove " - Zoom" suffix
    if title.lower().endswith(" - zoom"):
        title = title[:-7]

    # Remove " | Microsoft Teams" suffix
    if " | Microsoft Teams" in title:
        title = title.split(" | Microsoft Teams")[0]

    # Replace invalid filename characters
    title = re.sub(r'[<>:"/\\|?*]', '_', title)

    # Replace multiple spaces/underscores with single underscore
    title = re.sub(r'[\s_]+', '_', title)

    # Limit length
    if len(title) > 50:
        title = title[:50]

    return title.strip('_')


def get_app_using_mic() -> Optional[str]:
    """Get the name of the meeting app that might be using the microphone.

    Note: This returns any active meeting app, but doesn't guarantee
    that specific app is the one using the mic.
    """
    return is_meeting_app_active()


class MicrophoneMonitor:
    """Monitor microphone usage to detect meeting start/end.

    Start detection: Another app starts using the microphone
    Stop detection: The meeting app window is no longer visible

    This approach works because:
    - Start: CoreAudio tells us when mic is activated (before we start recording)
    - Stop: We can't rely on mic state (our recording uses it), so we check if meeting app is gone
    """

    def __init__(self):
        self._was_mic_in_use = False
        self._is_recording = False
        self._recording_app: Optional[str] = None  # Which app triggered recording
        self._last_check_time = 0
        self._on_count = 0   # Count consecutive "on" readings
        self._off_count = 0  # Count consecutive "off" readings
        self._on_threshold = 2   # Require 2 consecutive "on" readings to trigger start

    def set_recording(self, is_recording: bool, app_name: Optional[str] = None):
        """Tell the monitor whether we're currently recording."""
        self._is_recording = is_recording

        if is_recording:
            self._was_mic_in_use = True
            self._on_count = 0
            # Only set app_name if provided (don't overwrite on status updates)
            if app_name:
                self._recording_app = app_name
        else:
            self._recording_app = None

    def check(self) -> tuple[bool, bool, Optional[str]]:
        """Check for microphone usage changes.

        Returns:
            Tuple of (mic_started, mic_stopped, app_name)
            - mic_started: True if another app started using mic (should prompt to record)
            - mic_stopped: True if meeting app closed (should stop recording)
            - app_name: Name of meeting app (if detected)
        """
        now = time.time()

        # Debounce - check every 2 seconds
        if now - self._last_check_time < 2.0:
            return False, False, None
        self._last_check_time = now

        mic_started = False
        mic_stopped = False
        app_name = None

        if self._is_recording:
            # Stop detection is handled by the daemon itself via mic probe.
            # The watcher detects daemon exit via PID file check.
            # No stop signal from the watcher.
            pass
        else:
            # Not recording: check if mic is being used by another app
            mic_in_use = is_mic_in_use_by_another_app()

            if mic_in_use:
                self._off_count = 0
                # Get app name for display (optional, doesn't affect start decision)
                app_name = is_meeting_app_active()

                if not self._was_mic_in_use:
                    self._on_count += 1
                    # Require consecutive readings to avoid false positives
                    if self._on_count >= self._on_threshold:
                        mic_started = True
                        self._was_mic_in_use = True
                        self._on_count = 0
            else:
                self._on_count = 0
                self._was_mic_in_use = False

        return mic_started, mic_stopped, app_name

    def is_mic_active(self) -> bool:
        """Check if microphone is currently in use by another app."""
        return is_mic_in_use_by_another_app()
