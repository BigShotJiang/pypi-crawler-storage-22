import urllib

from meili_ros_lib.offline import OfflineAgent
from sentry_sdk import capture_exception, capture_message
import time

import http.client
import time
from urllib.parse import urlparse
import socket


class Connection:
    def __init__(
            self,
            agent_node,
            handlers,
            vehicle_list,
            mqtt_id=None,
            disconnection_buffer=3

    ):
        self.offline_flag = agent_node.offline_flag
        self.log_info = agent_node.log_info
        self.log_error = agent_node.log_error
        self.handlers = handlers
        self.vehicle_list = vehicle_list
        self.mqtt_id=mqtt_id
        self.connection_type= None
        self.connection_open = False

        
        

        self.client = None
        self.internet_down = 0
        self.offline_agent = OfflineAgent(vehicle_list, handlers, self.log_info, self.log_error)

        self.disconnection_buffer = disconnection_buffer

        self.log_info("[OfflineAgent] Initialized agent connection")

    def no_internet(self, connection_open):
          
        # The internet must be done disc_buffer (disc_buffer) times consecutive in a row
        # This avoids confusion with short internet disconnections
        try:
            if self.internet_down != self.disconnection_buffer:
                self.internet_down += 1
                self.log_info(
                    f"[OfflineAgent] Agent disconnected {self.internet_down}/{self.disconnection_buffer}")
            else:
                self.offline_agent.offline = True

                if connection_open:
                    self.close_connection()
                    connection_open = False


        except Exception as e:
            self.log_info(f"ERROR >> {e}")
        return connection_open
    
    def check_internet(self, timeout=1):
        try:
            socket.setdefaulttimeout(timeout)
            socket.socket(socket.AF_INET, socket.SOCK_STREAM).connect(("8.8.8.8", 53))
            return True
        except OSError:
            return False



    def check_internet_connection(self, mqtt_enabled):

        if self.check_internet():
            self.internet_down = 0
            if not self.connection_open:
                if mqtt_enabled:
                    self.log_info("[Connection] Opening MQTT")
                    self.connection_type = "MQTT"
                else:
                    self.log_info("[Connection] Opening WS")
                    self.connection_type = "WS"

                self.open_connection()

        else:
            self.log_info("Connection] No internet")
            self.connection_open = self.no_internet(self.connection_open)

        return self.connection_open

    
    def open_connection(self):
        self.log_info("[OfflineAgent] Internet Connected")

        try:
            self.client = self.handlers.sdk_setup()
            self.last_ws_open_time = time.time()

            for index in self.vehicle_list:
                try:
                    self.client.add_vehicle(index)
                except Exception as e:
                    if e == "Vehicle already exists":
                        continue
                        
            self.client.run_in_thread()

            #Mark connection as open
            self.connection_open = True

        except Exception as e:
            capture_exception(e)
            capture_message(f"[OfflineAgent] Error configuring connection: {e}")
            self.log_error(f"[OfflineAgent] Error configuring connection: {e}")


    def close_connection(self):

        self.log_info("[Agent] Closing connection from the Meili-agent")

        try:
            if self.connection_type == "WS":
                self.client.close_ws()
            else:
                self.client.close_mqtt()
        except Exception as e:
            self.log_error(f"Error closing connection: {e}")

        # Mark connection as close
        self.connection_open = False

        return False
