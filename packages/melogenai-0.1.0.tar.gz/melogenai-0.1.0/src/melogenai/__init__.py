"""Melogen AI Python SDK - AI-powered music tools."""

from melogenai.__version__ import __version__
from melogenai.client import AsyncMelogen, Melogen
from melogenai.exceptions import (
    AuthenticationError,
    InsufficientCreditsError,
    MelogenError,
    RateLimitError,
    TaskFailedError,
    TaskTimeoutError,
    ValidationError,
)

__all__ = [
    "__version__",
    "AsyncMelogen",
    "AuthenticationError",
    "InsufficientCreditsError",
    "Melogen",
    "MelogenError",
    "RateLimitError",
    "TaskFailedError",
    "TaskTimeoutError",
    "ValidationError",
]
