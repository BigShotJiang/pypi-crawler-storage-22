"""SDK configuration."""

from __future__ import annotations

import os
from dataclasses import dataclass, field


_DEFAULT_BASE_URL = "https://api.melogen.ai"
_DEFAULT_TIMEOUT = 30.0
_DEFAULT_POLL_INTERVAL = 2.0
_DEFAULT_POLL_TIMEOUT = 300.0


@dataclass(frozen=True)
class Config:
    """Immutable configuration for the Melogen client."""

    api_key: str
    base_url: str = field(default_factory=lambda: os.getenv("MELOGEN_BASE_URL", _DEFAULT_BASE_URL))
    timeout: float = _DEFAULT_TIMEOUT
    poll_interval: float = _DEFAULT_POLL_INTERVAL
    poll_timeout: float = _DEFAULT_POLL_TIMEOUT

    def __post_init__(self) -> None:
        if not self.api_key:
            raise ValueError(
                "API key is required. Pass api_key= or set MELOGEN_API_KEY env var."
            )

    @classmethod
    def from_env(cls) -> Config:
        api_key = os.getenv("MELOGEN_API_KEY", "")
        return cls(api_key=api_key)
