"""Exception hierarchy for the Melogen SDK."""

from __future__ import annotations


class MelogenError(Exception):
    """Base exception for all Melogen SDK errors."""

    def __init__(self, message: str, status_code: int | None = None):
        super().__init__(message)
        self.status_code = status_code


class AuthenticationError(MelogenError):
    """API key is invalid or expired."""

    def __init__(self, message: str = "Invalid or expired API key"):
        super().__init__(message, status_code=401)


class InsufficientCreditsError(MelogenError):
    """Account does not have enough credits."""

    def __init__(self, message: str = "Insufficient credits"):
        super().__init__(message, status_code=402)


class ValidationError(MelogenError):
    """Request parameters failed validation."""

    def __init__(self, message: str = "Validation error"):
        super().__init__(message, status_code=422)


class RateLimitError(MelogenError):
    """Too many requests."""

    def __init__(self, message: str = "Rate limit exceeded"):
        super().__init__(message, status_code=429)


class TaskTimeoutError(MelogenError):
    """Task polling exceeded the timeout."""

    def __init__(self, task_id: str, timeout: float):
        super().__init__(f"Task {task_id} timed out after {timeout}s")
        self.task_id = task_id
        self.timeout = timeout


class TaskFailedError(MelogenError):
    """Task completed with a failure status."""

    def __init__(self, task_id: str, error: str):
        super().__init__(f"Task {task_id} failed: {error}")
        self.task_id = task_id
        self.error = error
