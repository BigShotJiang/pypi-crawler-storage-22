"""Audio to MIDI conversion client."""

from __future__ import annotations

from typing import Any

from melogenai._http import AsyncHttpClient, HttpClient
from melogenai.types import TaskResult, TaskStatus


class Music2MidiClient:
    """Synchronous client for audio to MIDI conversion."""

    def __init__(self, http: HttpClient):
        self._http = http

    def convert(
        self,
        file_url: str,
        *,
        save_stems: bool = False,
        quantize: bool = False,
    ) -> TaskResult:
        """Submit an audio file for MIDI conversion.

        Args:
            file_url: URL of the audio file (MP3, WAV, FLAC, OGG, M4A).
            save_stems: Whether to save separated instrument stems.
            quantize: Whether to quantize MIDI output to nearest beat.

        Returns:
            TaskResult with task_id and initial status.
        """
        payload: dict[str, Any] = {
            "file_url": file_url,
            "save_stems": save_stems,
            "quantize": quantize,
        }
        data = self._http.post("/api/music2midi/convert", payload, timeout=60)
        return TaskResult(task_id=data["task_id"], status=data.get("status", "pending"))

    def get_task(self, task_id: str) -> TaskStatus:
        """Get the current status of a conversion task."""
        data = self._http.get(f"/api/music2midi/tasks/{task_id}")
        task = data.get("task", data)
        return TaskStatus(
            task_id=task_id,
            status=task.get("status", "unknown"),
            download_urls=data.get("download_urls", {}),
            error=task.get("error"),
            task=task,
        )

    def wait(
        self,
        task_id: str,
        *,
        poll_interval: float | None = None,
        timeout: float | None = None,
    ) -> TaskStatus:
        """Poll until the task completes and return the final status."""
        data = self._http.poll_task(
            f"/api/music2midi/tasks/{task_id}",
            task_id,
            interval=poll_interval,
            timeout=timeout or 600,  # Audio conversion can take longer
        )
        task = data.get("task", data)
        return TaskStatus(
            task_id=task_id,
            status=task.get("status", "completed"),
            download_urls=data.get("download_urls", {}),
            task=task,
        )


class AsyncMusic2MidiClient:
    """Asynchronous client for audio to MIDI conversion."""

    def __init__(self, http: AsyncHttpClient):
        self._http = http

    async def convert(
        self,
        file_url: str,
        *,
        save_stems: bool = False,
        quantize: bool = False,
    ) -> TaskResult:
        """Submit an audio file for MIDI conversion."""
        payload: dict[str, Any] = {
            "file_url": file_url,
            "save_stems": save_stems,
            "quantize": quantize,
        }
        data = await self._http.post("/api/music2midi/convert", payload, timeout=60)
        return TaskResult(task_id=data["task_id"], status=data.get("status", "pending"))

    async def get_task(self, task_id: str) -> TaskStatus:
        """Get the current status of a conversion task."""
        data = await self._http.get(f"/api/music2midi/tasks/{task_id}")
        task = data.get("task", data)
        return TaskStatus(
            task_id=task_id,
            status=task.get("status", "unknown"),
            download_urls=data.get("download_urls", {}),
            error=task.get("error"),
            task=task,
        )

    async def wait(
        self,
        task_id: str,
        *,
        poll_interval: float | None = None,
        timeout: float | None = None,
    ) -> TaskStatus:
        """Poll until the task completes and return the final status."""
        data = await self._http.poll_task(
            f"/api/music2midi/tasks/{task_id}",
            task_id,
            interval=poll_interval,
            timeout=timeout or 600,
        )
        task = data.get("task", data)
        return TaskStatus(
            task_id=task_id,
            status=task.get("status", "completed"),
            download_urls=data.get("download_urls", {}),
            task=task,
        )
