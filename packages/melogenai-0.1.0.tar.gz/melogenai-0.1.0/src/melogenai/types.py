"""Shared types for the Melogen SDK."""

from typing import Any, Dict, Optional

from pydantic import BaseModel, Field


class TaskResult(BaseModel):
    """Result of a conversion task submission."""

    task_id: str
    status: str = "pending"


class TaskStatus(BaseModel):
    """Full status of a task including download URLs."""

    task_id: str
    status: str
    download_urls: Dict[str, str] = Field(default_factory=dict)
    error: Optional[str] = None
    task: Dict[str, Any] = Field(default_factory=dict)


class AnalysisResult(BaseModel):
    """Result of a music analysis."""

    status: str
    analysis: str
    language: str


COMPLETED_STATUSES = frozenset({"completed", "done", "finished", "success"})
FAILED_STATUSES = frozenset({"failed", "error", "cancelled"})
