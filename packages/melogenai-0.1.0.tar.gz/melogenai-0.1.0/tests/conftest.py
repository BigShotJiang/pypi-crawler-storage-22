"""Shared test fixtures."""

from __future__ import annotations

import pytest
import respx

from melogenai.auth import AuthManager
from melogenai.config import Config


TEST_API_KEY = "melo_test_key_123"
TEST_BASE_URL = "https://api.test.melogen.ai"
TEST_JWT = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.test"


@pytest.fixture
def config() -> Config:
    return Config(api_key=TEST_API_KEY, base_url=TEST_BASE_URL)


@pytest.fixture
def auth_manager(config: Config) -> AuthManager:
    return AuthManager(config)


@pytest.fixture
def mock_api():
    """Provide a respx mock router scoped to the test base URL."""
    with respx.mock(base_url=TEST_BASE_URL) as router:
        # Always mock the auth endpoint
        router.post("/api/api-keys/verify", name="auth_verify").respond(
            json={
                "valid": True,
                "access_token": TEST_JWT,
                "user_id": "user_123",
                "scopes": ["sheet2midi", "music2midi", "analysis"],
            }
        )
        yield router
