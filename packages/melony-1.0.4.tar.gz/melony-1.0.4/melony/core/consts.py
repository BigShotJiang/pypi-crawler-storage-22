from typing import Final

__all__ = ()

REDIS_QUEUE_NAME: Final[str] = "melony_tasks"
REDIS_RESULT_BACKEND_KEY: Final[str] = "melony_result_backend:"