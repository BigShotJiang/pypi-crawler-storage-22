from __future__ import annotations  # noqa: D104

from .name_eq import NameEq
