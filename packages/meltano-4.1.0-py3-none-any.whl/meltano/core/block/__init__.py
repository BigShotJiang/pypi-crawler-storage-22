"""The block module implements and supports the Meltano 'block' architecture."""

from __future__ import annotations
