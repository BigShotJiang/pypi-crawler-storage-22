"""Init file for connectors module. This module contains connectors to various data sources and formats."""
