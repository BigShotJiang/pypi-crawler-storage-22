"""
Memorer SDK Configuration
"""

from __future__ import annotations

import os
from dataclasses import dataclass

# Internal constants
_DEFAULT_BASE_URL = "https://api.memorer.ai"
DEFAULT_TIMEOUT = 30.0
DEFAULT_MAX_RETRIES = 2


def _get_default_base_url() -> str:
    """Get base URL from environment or use default."""
    return os.getenv("MEMORER_BASE_URL", _DEFAULT_BASE_URL)


@dataclass
class ClientConfig:
    """
    Configuration for the Memorer client.

    Args:
        api_key: API key for authentication (required).
        base_url: API base URL. Defaults to MEMORER_BASE_URL env var
            or https://api.memorer.ai
        timeout: Request timeout in seconds. Defaults to 30.
        max_retries: Maximum number of retries for transient failures.
            Defaults to 2. Set to 0 to disable retries.
    """

    api_key: str
    base_url: str | None = None
    timeout: float = DEFAULT_TIMEOUT
    max_retries: int = DEFAULT_MAX_RETRIES

    def __post_init__(self) -> None:
        if self.base_url is None:
            self.base_url = _get_default_base_url()
