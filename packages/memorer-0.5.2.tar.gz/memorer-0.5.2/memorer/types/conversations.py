"""
Conversation and Message types for conversation support.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, Field

from memorer.types.common import TimingBreakdown
from memorer.types.knowledge import QueryResult


class Message(BaseModel):
    """A message in a conversation."""

    id: str
    conversation_id: str
    role: Literal["user", "assistant", "system"]
    content: str
    metadata: dict[str, Any] | None = None
    created_at: datetime
    extracted_entity_ids: list[str] | None = None


class MessageList(BaseModel):
    """Paginated list of messages."""

    count: int
    messages: list[Message]


class Conversation(BaseModel):
    """A conversation session."""

    id: str
    owner_id: str
    external_id: str | None = None
    title: str | None = None
    metadata: dict[str, Any] | None = None
    message_count: int = 0
    started_at: datetime
    last_message_at: datetime | None = None
    created_at: datetime


class ConversationList(BaseModel):
    """Paginated list of conversations."""

    count: int
    conversations: list[Conversation]


class ConversationContext(BaseModel):
    """Message in conversation context format (matches API MessageResponse)."""

    id: str | None = None
    conversation_id: str | None = None
    role: str
    content: str
    metadata: dict[str, Any] | None = None
    created_at: str | None = None
    extracted_entity_ids: list[str] | None = None
    # Keep timestamp as optional alias for backwards compat
    timestamp: str | None = None


class ConversationRecallResponse(BaseModel):
    """Response from recall with conversation context."""

    conversation_context: list[ConversationContext] = Field(default_factory=list)
    results: list[QueryResult] = Field(default_factory=list)
    context: str = ""
    timing: TimingBreakdown | None = None
