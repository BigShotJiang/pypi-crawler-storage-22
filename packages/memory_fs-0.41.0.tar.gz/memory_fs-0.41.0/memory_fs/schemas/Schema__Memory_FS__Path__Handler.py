from osbot_utils.type_safe.primitives.domains.identifiers.safe_str.Safe_Str__Id     import Safe_Str__Id
from osbot_utils.type_safe.Type_Safe import Type_Safe

class Schema__Memory_FS__Path__Handler(Type_Safe):
    name            : Safe_Str__Id
    enabled         : bool = True