# Changelog

All notable changes to the Memory Intelligence Python SDK will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.1] - 2026-02-07

### Fixed
- Corrected `ProvenanceError` in `__all__` exports list (final typo fix)

## [1.0.0] - 2026-02-07 [YANKED]

### Added
- **MemoryClient** with 6 core operations: process, search, match, explain, delete, verify_provenance
- **EdgeClient** for on-premises HIPAA-compliant deployments
- Privacy-first architecture with meaning-only retention (default)
- Structured semantic extraction (entities, topics, SVO triples, key phrases)
- Explainable search results with human + audit explanations
- Cryptographic provenance tracking with hash chain verification
- ULID-based identity firewall for cryptographic tenant isolation
- Scope-based access control (user, team, client, organization)
- PII detection and configurable handling (extract_and_redact, hash, reject)
- Type-safe API with Pydantic models
- Comprehensive error handling (7 exception types)
- 30+ unit and integration tests

### Known Limitations
- Pagination not yet implemented (coming in v1.1.0)
- Streaming search results not yet available
- Temporal intelligence parameter present but not fully validated in tests

### Fixed
- Corrected `ProvenanceError` exception name (was misspelled as `ProvenenaceError`)

## [Unreleased]

### Planned for v1.1.0
- Cursor-based pagination for search results
- Enhanced temporal intelligence validation
- Circuit breaker and retry logic
- Performance benchmarks published

### Planned for v2.0.0
- Streaming search results
- Batch processing operations
- GraphQL API support
- React hooks companion package (@memoryintelligence/react)

[1.0.0]: https://github.com/memoryintelligence/sdk-python/releases/tag/v1.0.0
[Unreleased]: https://github.com/memoryintelligence/sdk-python/compare/v1.0.0...HEAD
