# Memory Intelligence SDK

The official Python SDK for Memory Intelligence - Verifiable meaning infrastructure for AI.

[![PyPI](https://img.shields.io/pypi/v/memoryintelligence.svg)](https://pypi.org/project/memoryintelligence/)
[![License](https://img.shields.io/pypi/l/memoryintelligence.svg)](https://pypi.org/project/memoryintelligence/)

## Quick Start

```python
from memoryintelligence import MemoryClient

# Initialize client
mi = MemoryClient(api_key="mi_sk_...")

# Process content → meaning
umo = mi.process("Meeting notes from today", user_ulid="01ABC...")

# Search meaning
results = mi.search("What did we discuss?", user_ulid="01ABC...", explain=True)

# Match for recommendations
match = mi.match("01ABC...", "01XYZ...", explain=True)

# Delete for GDPR
mi.delete(user_ulid="01ABC...")
```

## Key Features

- **Meaning-First Architecture**: Raw content discarded after processing
- **Five Core Operations**: Process, Search, Match, Explain, Delete
- **Provenance Tracking**: Cryptographic verification of content lineage
- **GDPR Compliance**: One-call data deletion with audit proof
- **Built-in Telemetry**: Debug logs for content processing
- **Simplified API**: Only 12 essential exports

## Usage Guide

### Initialize the Client

```python
from memoryintelligence import MemoryClient

# For production (API key required)
mi = MemoryClient(api_key="mi_sk_prod_...")

# For development
mi = MemoryClient(api_key="mi_sk_dev_...")
```

### Process Content

Convert raw content to meaning (discards raw content by default):

```python
umo = mi.process(
    "Budget approved for Q3 initiatives",
    user_ulid="01ABC...",
    retention_policy="meaning_only"
)
```

### Search for Meaning

Find relevant memories with explanation:

```python
results = mi.search(
    "Q3 budget decisions",
    user_ulid="01ABC...",
    explain=True,
    limit=5
)
```

### Match for Recommendations

Compare two memories for relevance:

```python
match = mi.match(
    source_ulid="01ABC...",
    candidate_ulid="01XYZ...",
    explain=True
)
```

### Get Explanations

Understand why content is relevant:

```python
explanation = mi.explain(umo.umo_id)
print(explanation.human.summary)
```

### Delete Data

GDPR-compliant data removal:

```python
result = mi.delete(user_ulid="01ABC...")
print(f"Deleted {result.deleted_count} memories")
```

## Monitoring & Telemetry

The SDK provides built-in telemetry for operational visibility:

```python
import logging
logging.basicConfig(level=logging.DEBUG)
```

### Key Log Events:
- `DEBUG`: Content processing metrics (size, time)
- `INFO`: Operation completion with results
- `WARNING`: PII detection events
- `ERROR`: API and integration errors

### Dashboard Setup

1. Run the smoke test to generate sample telemetry:
   ```bash
   python sdk_smoke_test.py
   ```
2. Set up log collection with your monitoring system
3. Import the included Grafana dashboard template:
   ```bash
   grafana-cli dashboard import grafana_dashboard.json
   ```

## Documentation

Full documentation is available at:
- [API Reference](https://docs.memoryintelligence.dev)
- [Getting Started Guide](https://memoryintelligence.dev/docs/getting-started)

## Support

For SDK issues, please contact:
- support@memoryintelligence.dev
- GitHub Issues: [Create New Issue](https://github.com/memoryintelligence/sdk-python/issues/new)

## License

This SDK is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.