"""
Hooks for memrecall Memory System

These hooks integrate with Claude Code to capture session data
and trigger triage for memory extraction.

Components:
- state.py: Chunk state management
- user_prompt_submit.py: Hook for task start
- stop.py: Hook for task end (triggers triage)
- jsonl_parser.py: Parse Claude Code JSONL files

Note: triage.py has been moved to memrecall/
"""

from .state import ChunkState, find_jsonl_for_session, get_current_jsonl_path
from .user_prompt_submit import on_user_prompt_submit
from .stop import on_stop, on_stop_sync
from .jsonl_parser import (
    parse_jsonl,
    extract_chunk_after_timestamp,
    extract_chunks_by_user_prompts,
    chunk_to_transcript,
)

__all__ = [
    # State
    "ChunkState",
    "find_jsonl_for_session",
    "get_current_jsonl_path",
    # Hooks
    "on_user_prompt_submit",
    "on_stop",
    "on_stop_sync",
    # JSONL Parser
    "parse_jsonl",
    "extract_chunk_after_timestamp",
    "extract_chunks_by_user_prompts",
    "chunk_to_transcript",
]
