"""memrecall - Semantic memory management for Claude Code sessions.

memrecall captures learnings from coding sessions, stores them in a LanceDB
vector database with embeddings, and provides retrieval via semantic similarity
search. The system bridges persistent knowledge across coding sessions.

Usage:
    # Path utilities (always available)
    from memrecall import encode_project_path, get_project_dir
    encoded = encode_project_path("C:/Users/Sam/my-app")
    project_dir = get_project_dir("C:/Users/Sam/my-app")

    # Core classes (when running with full dependencies)
    from memrecall.memory_store import ContextStore
    from memrecall.client import MemoryClient

Note:
    Core classes (ContextStore, MemoryClient) require running from within
    the memrecall directory or having PYTHONPATH configured, as they
    use absolute imports for sibling modules.
"""

# Utility functions from cli_utils (no heavy dependencies)
from .cli_utils import (
    # Path encoding
    encode_project_path,
    decode_project_path,
    is_encoded_path,
    get_display_name,
    # Directory helpers
    get_project_dir,
    get_session_dir,
    get_vector_db_path,
    get_state_dir,
    get_logs_dir,
    get_summary_path,
    # Subprocess utilities
    get_subprocess_env,
    get_debug_mode,
    build_claude_cli_args,
    find_claude_cli,
    # Data migration
    ensure_data_migrated,
    # Path constants
    MEMRECALL_ROOT,
    CODECONTEXT_ROOT,  # Backward compatibility alias
    PROJECTS_DIR,
    GLOBAL_DIR,
    DEBUG_DIR,
    CONFIG_FILE,
)

__version__ = "1.0.0"

__all__ = [
    # Path encoding
    "encode_project_path",
    "decode_project_path",
    "is_encoded_path",
    "get_display_name",
    # Directory helpers
    "get_project_dir",
    "get_session_dir",
    "get_vector_db_path",
    "get_state_dir",
    "get_logs_dir",
    "get_summary_path",
    # Subprocess utilities
    "get_subprocess_env",
    "get_debug_mode",
    "build_claude_cli_args",
    "find_claude_cli",
    # Data migration
    "ensure_data_migrated",
    # Path constants
    "MEMRECALL_ROOT",
    "CODECONTEXT_ROOT",  # Backward compatibility alias
    "PROJECTS_DIR",
    "GLOBAL_DIR",
    "DEBUG_DIR",
    "CONFIG_FILE",
]
