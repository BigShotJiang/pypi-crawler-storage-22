"""
Allow running memrecall as a module: python -m memrecall
"""

from .cli import main

if __name__ == "__main__":
    main()
