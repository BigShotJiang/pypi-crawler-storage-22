"""
Consolidator module - Memory deduplication and clustering.

This package provides functionality for finding and consolidating
semantically similar memories:

- models: Data classes (Cluster, ConsolidationResult, ConsolidationReport)
- clustering: Union-Find algorithm and cluster detection
- auto_rules: Simple auto-consolidation rules
- prompting: LLM prompt building and response parsing
- claude_client: Claude Code CLI integration
- storage: Apply consolidation decisions to database
- logging: Audit trail logging
- orchestration: High-level consolidation workflow

Usage:
    from consolidator import find_clusters, run_consolidation, scan_clusters
    from consolidator.models import Cluster, ConsolidationResult
"""

from .models import (
    generate_cluster_id,
    Cluster,
    ConsolidationResult,
    ConsolidationReport
)
from .clustering import UnionFind, find_clusters, tier_clusters
from .auto_rules import auto_consolidate_simple
from .prompting import (
    build_consolidation_prompt,
    parse_consolidation_response
)
from .claude_client import spawn_claude_code, consolidate_with_claude
from .storage import apply_consolidation
from .logging import log_consolidation
from .orchestration import run_consolidation, scan_clusters

# Re-export MAX_BATCH_SIZE for backward compatibility
MAX_BATCH_SIZE = 10

__all__ = [
    # Models
    "generate_cluster_id",
    "Cluster",
    "ConsolidationResult",
    "ConsolidationReport",
    # Clustering
    "UnionFind",
    "find_clusters",
    "tier_clusters",
    # Auto rules
    "auto_consolidate_simple",
    # Prompting
    "build_consolidation_prompt",
    "parse_consolidation_response",
    # Claude client
    "spawn_claude_code",
    "consolidate_with_claude",
    # Storage
    "apply_consolidation",
    # Logging
    "log_consolidation",
    # Orchestration
    "run_consolidation",
    "scan_clusters",
    # Constants
    "MAX_BATCH_SIZE"
]
