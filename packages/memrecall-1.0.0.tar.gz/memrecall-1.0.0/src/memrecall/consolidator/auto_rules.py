"""
Auto Rules Module - Simple automatic consolidation rules.

Contains rules that can auto-resolve clusters without LLM involvement.
"""

from .models import Cluster, ConsolidationResult


def auto_consolidate_simple(cluster: Cluster) -> ConsolidationResult:
    """
    Auto-consolidate a simple cluster (2 entries, obvious winner).

    Selects the longer/more detailed entry, deletes the other.

    Args:
        cluster: A cluster of size 2 with obvious length difference

    Returns:
        ConsolidationResult with keep_one decision
    """
    if cluster.size != 2:
        raise ValueError("auto_consolidate_simple requires cluster of size 2")

    mem1, mem2 = cluster.memories[0], cluster.memories[1]
    fact1 = mem1.get("fact", "") or ""
    fact2 = mem2.get("fact", "") or ""

    # Select the longer one
    if len(fact1) >= len(fact2):
        winner, loser = mem1, mem2
    else:
        winner, loser = mem2, mem1

    return ConsolidationResult(
        cluster_id=cluster.id,
        decision="keep_one",
        kept_id=winner["id"],
        deleted_ids=[loser["id"]],
        reasoning=f"Auto-selected: kept memory with more detail ({len(winner.get('fact', ''))} chars vs {len(loser.get('fact', ''))} chars)"
    )
