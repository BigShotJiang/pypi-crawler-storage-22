"""
Semantic similarity thresholds for L2 distance.

L2 distance: Lower = more similar (0 = identical)

The all-MiniLM-L6-v2 model has known ambiguity in the 0.65+ range
for technical/code-related content, leading to false positives.

Usage:
    from constants import CONSOLIDATION_DEFAULT, DUPLICATE_THRESHOLD
"""

# ============== Distance Thresholds (L2 - lower = more similar) ==============
# These control duplicate detection, conflict flagging, and clustering behavior

# Consolidation clustering range (for slider)
CONSOLIDATION_MIN = 0.3       # Tightest useful clustering
CONSOLIDATION_MAX = 0.65      # Beyond this = false positives
CONSOLIDATION_DEFAULT = 0.5   # Sweet spot (middle of useful range)

# Conflict detection (on memory add) - fixed boundaries
DUPLICATE_THRESHOLD = 0.35    # Reject if distance below this (near-identical)
CONFLICT_CEILING = 0.65       # Add normally if distance above this (0.65+ is noise)

# ============== Confidence Calculation ==============
# Used in conflict_ops.py for determining auto/high/medium/low confidence levels

CONFIDENCE_DISTANCE_VERY_SIMILAR = 0.6   # Below this = high confidence
CONFIDENCE_DISTANCE_AMBIGUOUS = 0.65     # Above this = low confidence
CONFIDENCE_MIN_SUBSTANTIAL_LENGTH = 50   # Minimum fact length for "substantial"
CONFIDENCE_HIGH_DETAIL_LENGTH = 100      # Fact length for "much more detailed"
CONFIDENCE_LENGTH_RATIO_HIGH = 3.0       # Length ratio for high confidence

# ============== Timeouts (seconds) ==============
# HTTP client and operation timeouts

CLI_TIMEOUT_SHORT = 30        # Default CLI timeout for quick operations
CLI_TIMEOUT_LONG = 600        # 10 minutes for summary generation, etc.

# ============== Batch Sizes ==============
# Control batch processing for embeddings and other operations

EMBEDDING_BATCH_SIZE = 32     # Batch size for embedding encoding
