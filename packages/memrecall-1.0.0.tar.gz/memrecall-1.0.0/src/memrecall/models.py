"""
Pydantic models for CodeContext API requests and responses.
"""

from typing import List, Optional
from pydantic import BaseModel


# Default values (must match server.py constants)
DEFAULT_PROJECT = "default"


class QueryRequest(BaseModel):
    query: str
    top_k: int = 5
    project: str = DEFAULT_PROJECT


class BatchQueryRequest(BaseModel):
    queries: List[str]
    top_k: int = 5
    project: str = DEFAULT_PROJECT


class MemoryRequest(BaseModel):
    type: str
    title: str
    fact: str
    files: List[str] = []
    project: str = DEFAULT_PROJECT


class BatchMemoryRequest(BaseModel):
    memories: List[MemoryRequest]
    project: str = DEFAULT_PROJECT


class ConflictResolveRequest(BaseModel):
    resolution: str  # "keep_new" | "keep_existing" | "keep_both" | "merge"
    merged_fact: Optional[str] = None


class ApplyDecisionsRequest(BaseModel):
    """Request body for applying user-approved decisions."""
    decisions: List[dict]  # [{conflict_id, decision, merged_fact?}]


class ConsolidationRunRequest(BaseModel):
    """Request body for running consolidation."""
    threshold: float = 0.5  # Distance threshold for similarity
    max_clusters: int = 10  # Max clusters to process


class ConsolidationStreamRequest(BaseModel):
    """Request body for streaming consolidation."""
    threshold: float = 0.5
    max_clusters: int = 10


class ApplyConsolidationRequest(BaseModel):
    """Request body for applying consolidation decisions."""
    results: List[dict]  # List of ConsolidationResult dicts


# ============== CLI/MCP Support Models ==============

class QuickMemoryRequest(BaseModel):
    """Request for quick note capture with auto-classification."""
    learning: str
    files: List[str] = []
    project: str = DEFAULT_PROJECT


class FileSearchRequest(BaseModel):
    """Request to find memories by file paths."""
    files: List[str]
    match_mode: str = "contains"  # "exact" | "contains" | "fuzzy"
    project: str = DEFAULT_PROJECT
