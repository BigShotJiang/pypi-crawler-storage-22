"""
Route modules for CodeContext server.

All routes are organized by domain:
- ui: HTML page routes
- settings: Configuration endpoints
- memory: Memory CRUD operations
- summary: Summary generation
- archive: Archive operations
- conflicts: Conflict detection and resolution
- consolidation: Memory consolidation
"""

from fastapi import APIRouter

from .ui import router as ui_router
from .settings import router as settings_router
from .memory import router as memory_router
from .summary import router as summary_router
from .archive import router as archive_router
from .conflicts import router as conflicts_router
from .consolidation import router as consolidation_router


def include_all_routers(app):
    """Include all route modules in the FastAPI app."""
    app.include_router(ui_router)
    app.include_router(settings_router)
    app.include_router(memory_router)
    app.include_router(summary_router)
    app.include_router(archive_router)
    app.include_router(conflicts_router)
    app.include_router(consolidation_router)


__all__ = [
    "include_all_routers",
    "ui_router",
    "settings_router",
    "memory_router",
    "summary_router",
    "archive_router",
    "conflicts_router",
    "consolidation_router",
]
