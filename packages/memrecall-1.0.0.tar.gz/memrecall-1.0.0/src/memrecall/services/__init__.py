"""
Service layer for CodeContext server.
"""

from .store_manager import (
    get_store,
    list_projects,
    get_all_stores,
    stores,
    set_embedder,
    ALL_PROJECTS,
    DEFAULT_PROJECT,
)

from .background import (
    set_config,
    get_config,
    start_periodic_consolidation,
    stop_periodic_consolidation,
    start_auto_resolve_loop,
    stop_auto_resolve_loop,
    auto_resolve_and_log,
)

__all__ = [
    # Store manager
    "get_store",
    "list_projects",
    "get_all_stores",
    "stores",
    "set_embedder",
    "ALL_PROJECTS",
    "DEFAULT_PROJECT",
    # Background tasks
    "set_config",
    "get_config",
    "start_periodic_consolidation",
    "stop_periodic_consolidation",
    "start_auto_resolve_loop",
    "stop_auto_resolve_loop",
    "auto_resolve_and_log",
]
