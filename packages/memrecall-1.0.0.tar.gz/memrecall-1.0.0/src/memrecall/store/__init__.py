"""
Store module - Modular operations for ContextStore.

This package contains mixin classes that provide specialized functionality
for the ContextStore class, organized by domain:

- ConflictMixin: Conflict detection and resolution
- ArchiveMixin: Archive and restore operations
- SummaryMixin: Summary version management
- ConsolidationMixin: Consolidation helper methods

Usage:
    from store import ConflictMixin, ArchiveMixin, SummaryMixin, ConsolidationMixin
"""

from .conflict_ops import ConflictMixin
from .archive_ops import ArchiveMixin
from .summary_ops import SummaryMixin
from .consolidation_ops import ConsolidationMixin
from .utils import parse_files

__all__ = [
    "ConflictMixin",
    "ArchiveMixin",
    "SummaryMixin",
    "ConsolidationMixin",
    "parse_files"
]
