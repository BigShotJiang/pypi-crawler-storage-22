"""
Shared utilities for store module.

Contains helper functions used across multiple store operations.
"""

import json
from typing import List, Union


def parse_files(files_raw: Union[str, List, None]) -> List[str]:
    """
    Safely parse files field - handles both JSON string and list.

    Args:
        files_raw: Either a JSON string, list, or None

    Returns:
        List of file paths (empty list if parsing fails)
    """
    if files_raw is None:
        return []
    if isinstance(files_raw, str):
        try:
            return json.loads(files_raw)
        except (json.JSONDecodeError, TypeError):
            return []
    return files_raw if isinstance(files_raw, list) else []
