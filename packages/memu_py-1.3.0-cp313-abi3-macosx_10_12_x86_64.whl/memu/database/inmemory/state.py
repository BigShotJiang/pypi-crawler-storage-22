from __future__ import annotations

from memu.database.state import DatabaseState

InMemoryState = DatabaseState

__all__ = ["DatabaseState", "InMemoryState"]
