"""Utility modules for memU."""

from memu.utils.video import VideoFrameExtractor

__all__ = ["VideoFrameExtractor"]
