# MEO Tool

meo-tool is a developer-friendly Command Line Interface (CLI) designed for the MEO ecosystem. It streamlines the process of flashing firmware and managing device configurations (like WiFi and GPIO) for hardware like the Thingbot.

## Installation

Install the tool directly via pip:

```bash
pip install meo-tool
```

To verify the installation and see all available commands:
```bash
meo --help
```


## Usage Guide

The tool uses a logical, nested command structure: meo [GROUP] [COMMAND] [ARGS].

1. Flashing Firmware

Deploy binaries to your hardware with intelligent port detection.

### Flash the latest Thingbot-Telemetrix firmware with auto-port detection

```bash
meo flash thingbot-telemetrix --latest --auto-detect
```

2. Network Configuration

Update your IoT device's network credentials without re-compiling or re-flashing.

### Set WiFi SSID and Password
```bash
meo config wifi "Maker IoT" "12345678"
```

3. GPIO & Sensor Mapping

Configure pins and define sensor types (like DHT) directly via the CLI.

### Configure Pin 1 as an input with DHT sensor capabilities
```bash
meo config gpio 1 --input #or 
meo config gpio 1 --input --dht
```


Key Features
- Auto-Detection: Automatically identifies the correct Serial/COM port for your connected device.
- Rapid Flashing: Integration with esptool and avrdude for efficient firmware deployment.
- Live Config: Communicates over serial protocols to update parameters in real-time.
- Modular Design: Built on the Click framework for easy extensibility to new sensors and hardware.

## Development & Contribution

To set up a local development environment:

Clone the Repository:
```bash
git clone [https://github.com/yourusername/meo-tool.git](https://github.com/yourusername/meo-tool.git)
cd meo-tool


Install in Editable Mode:
This allows you to test your code changes immediately without re-installing the package.

pip install -e .


Run Tests:
(Optional: if using pytest)

pytest
```