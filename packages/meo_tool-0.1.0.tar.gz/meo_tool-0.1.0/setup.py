from setuptools import setup, find_packages

setup(
    name='meo-tool',
    version='0.1.0',
    packages=find_packages(),
    install_requires=[
        'click',
        'pyserial', # Likely needed for flashing
        'requests', # For GitHub API calls
        'esptool',  # For flashing ESP devices
    ],
    entry_points={
        'console_scripts': [
            'meo = meo.cli:cli',
        ],
    },
)