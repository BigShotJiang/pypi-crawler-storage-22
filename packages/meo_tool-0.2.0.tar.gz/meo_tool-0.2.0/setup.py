from setuptools import setup, find_packages

setup(
    name='meo-tool',
    version='0.2.0',
    packages=find_packages(),
    install_requires=[
        'click',
        'pyserial', # Likely needed for flashing
        'requests', # For GitHub API calls
        'esptool',  # For flashing ESP devices
    ],
    entry_points={
        'console_scripts': [
            'meo = meo.cli:cli',
        ],
    },
    author='MEO Team',
    description='A command-line tool for managing MEO devices, including flashing firmware and sending serial commands.',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
)