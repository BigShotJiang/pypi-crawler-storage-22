# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

`mail_connector` is a Python mail connector library. Proprietary license. Early stage (v0.1.0).

## Tech Stack

- **Python** >= 3.12 (pinned in `.python-version`)
- **uv** for package management and virtual environments
- **hatchling** as the build backend
- **src layout**: package code lives in `src/mail_connector/`
- PEP 561 typed package (`py.typed` marker present)

## Common Commands

```bash
# Setup / install dependencies
uv sync

# Build the package
uv build

# Run a script or module
uv run python -m mail_connector

# Add a dependency
uv add <package>

# Add a dev dependency
uv add --dev <package>
```

No test runner or linter is configured yet. When added, expect to run them via `uv run pytest` and `uv run ruff check .` respectively.

## Architecture

Single-package src layout:

- `src/mail_connector/__init__.py` — package root, exports `__version__`
- `src/mail_connector/py.typed` — PEP 561 marker for type checkers

## Conventions

- Version is declared in both `pyproject.toml` and `src/mail_connector/__init__.py` — keep them in sync.
- `uv.lock` is gitignored; not committed.
