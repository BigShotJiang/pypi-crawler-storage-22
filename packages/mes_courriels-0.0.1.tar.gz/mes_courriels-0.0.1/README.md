# mail_connector

A Python mail connector library.

## Installation

```bash
pipx install mes-courriels
```

## Development

### Requirements

- Python >= 3.12
- [uv](https://docs.astral.sh/uv/)

### Setup

```bash
uv sync
```
