"""mail_connector - A Python mail connector library."""

__version__ = "0.0.1"
