# CLAUDE.md

Full coding guidelines and project context are in [`.claude/CLAUDE.md`](.claude/CLAUDE.md).

This file provides a minimal summary for Claude Code.

## Project

`mail_connector` — Python Gmail read-only connector via OAuth2. Published as `mes-courriels`.

## Commands

```bash
uv sync                              # Install dependencies
uv build                             # Build the package
```

## Key Rules

- **Style**: PEP 8 + 120 char lines + Google-style docstrings + type hints.
- **Imports**: grouped (stdlib → third-party → local), absolute, sorted, no unused.
- **Simplicity**: minimum code, no speculative features, no over-engineering.
- **Logging**: use `logging` module.
- **Version sync**: `pyproject.toml` ↔ `src/mail_connector/__init__.py`.
- **Testing**: always via `uv run pytest`, no mocks — real unit/e2e tests only. Every new feature needs an E2E test passing before commit/push.
- **Commit/push frequently** — small, focused commits after each logical change.
