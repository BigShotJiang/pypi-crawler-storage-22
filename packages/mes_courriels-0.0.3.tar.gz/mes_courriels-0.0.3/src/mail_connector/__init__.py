"""mail_connector - A Python mail connector library."""

from mail_connector.gmail import GmailConnector

__version__ = "0.0.3"
__all__ = ["GmailConnector", "__version__"]
