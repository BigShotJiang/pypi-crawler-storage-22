# Meshgen v0.2.9

This is a small tool to extract meshes from finite element solvers.
In particular JCMsuite and COMSOL are supported.

## Usage

for example run as
```
meshgen test/helix.jcm test/helix.msh
```
the input file is passed as the first argument, the output as the second

help is available
```
meshgen -h
```

```
usage: meshgen [-h] [-m {a,w,x,ab,wb,xb}] [-s] [--version] input output

convert between comsol, jcmsuite, and gmsh meshes

positional arguments:
  input                 with extension jcm, mphtxt, or msh
  output                with extension jcm, mphtxt, or msh

options:
  -h, --help            show this help message and exit
  -m, --mode {a,w,x,ab,wb,xb}
                        writing mode (binary only possible for .jcm files)
  -s, --skip_1d         skip writing 1D elements in 2D COMSOL meshes
  --version             show program's version number and exit
```

alternatively the library can also be used from within python
``` python
from meshgen import Mesh
meshes = Mesh.read(args.input)
```
Since we support submeshes this returns a list of meshes. This behavior will likely change in future versions of `meshgen`

## Known limitations

Currently the following JCM features are not supported:
- curvilinear elements
    - when using a post process to generate a JCM-ASCII export of the grid the displacement field for the curvilinear elements is placed at the end of the file. `meshgen` is simply going to ignore the curvilinearity.
    - in binary files this doesn't seem to work
- in files that have subgrids we rely on comments in the mesh file to skip extraneous `Vertical Grid`s
    - these comments are not present in binary jcm files -> binary files with subgrids that have `Vertical Grid`s cannot be processed (the processing fails)
