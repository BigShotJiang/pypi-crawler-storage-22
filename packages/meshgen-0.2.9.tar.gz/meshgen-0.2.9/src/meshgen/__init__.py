"""meshgen v0.2.9
A small tool to parse different types of mesh files and convert them.

This tool provides utilities to parse mesh files. The mesh file can then be written to
a different format. The goal is to reproduce the content of the original mesh as
faithful as possible. However, an exact one to one correspondence is not always
possible. Currently, COMSOL files (.mphtxt), JCMsuite files (.jcm), and gmsh files
(.msh) are supported.
"""

from meshgen.version import __version__
from meshgen.mesh import Mesh
from meshgen.cli import cli

__all__ = ["Mesh", "cli", "__version__"]

if __name__ == "__main__":
    cli()
