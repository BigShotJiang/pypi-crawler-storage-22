from meshgen.util import iter_wo_comments


def gmsh_iter(fobj):
    """Iterator through gmsh file.

    Ignores all sections except for a list of known ones.

    Args:
        fobj (file object): file

    Yields:
        str
    """
    modes = [
        "$MeshFormat",
        "$PhysicalNames",
        "$Entities",
        "$Nodes",
        "$Elements",
    ]
    itr = iter_wo_comments(fobj, "//")
    mode = None
    for line in itr:
        if mode is None and line.startswith("$"):
            mode = line
        if mode in modes:
            yield line
        if mode is not None and line == "$End" + mode[1:]:
            mode = None
