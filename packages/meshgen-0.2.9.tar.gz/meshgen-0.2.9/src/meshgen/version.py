from importlib import metadata as _metadata

__version__ = _metadata.version("meshgen")
