"""Meshtastic Monitor CLI package."""
