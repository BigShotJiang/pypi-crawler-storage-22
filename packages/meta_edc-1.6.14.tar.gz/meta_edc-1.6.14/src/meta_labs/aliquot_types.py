from edc_lab import bc, fbc, pl, serum, wb

wb.add_derivatives(bc, pl, serum, fbc, wb)
