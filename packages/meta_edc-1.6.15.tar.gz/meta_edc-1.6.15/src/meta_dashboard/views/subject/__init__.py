from .dashboard import DashboardView
from .listboard import SubjectListboardView

__all__ = ["DashboardView", "SubjectListboardView"]
