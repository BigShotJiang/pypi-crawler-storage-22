HEMACUE = "hemocue"
ACCUCHEK = "accuchek"
