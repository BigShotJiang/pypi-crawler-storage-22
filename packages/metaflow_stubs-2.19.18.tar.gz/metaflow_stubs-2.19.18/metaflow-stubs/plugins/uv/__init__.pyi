######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.18                                                                                #
# Generated on 2026-02-05T18:18:14.330574                                                            #
######################################################################################################

from __future__ import annotations


from . import uv_environment as uv_environment

