NODE_STARTED_VAR = "torchrun_node_started"
TORCHRUN_SUFFIX = "mf.torchrun"