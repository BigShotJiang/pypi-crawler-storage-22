# Python

Currently, there is no buf validate package available for Python. So we also generate it in the metal-stack-api by calling `buf generate` with `--include-imports`.

This can be reverted once there is a python package that includes the validations.
