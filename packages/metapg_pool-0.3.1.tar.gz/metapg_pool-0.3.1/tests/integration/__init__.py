"""Integration tests for metapg.pool - requires database connection."""
