"""Unit tests for metapg.pool - no database connection required."""
