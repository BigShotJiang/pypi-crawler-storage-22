import asyncio
import json
from typing import Any, BinaryIO, Mapping, Optional, Sequence, TYPE_CHECKING


if TYPE_CHECKING:
    from metasdk import MetaApp
    from metasdk.transport import AsyncNativeApiTransport


class AsyncDbQueryService:
    """Асинхронный клиент для работы с БД."""

    def __init__(
        self,
        app: "MetaApp",
        options: Mapping[str, Any],
        transport: Optional["AsyncNativeApiTransport"] = None,
        owns_transport: bool = False,
    ) -> None:
        """
        Инициализирует асинхронный сервис работы с БД.

        :param app: Экземпляр MetaApp.
        :param options: Опции подключения (dbAlias, shardKey и др.).
        :param transport: Опциональный транспорт. Если не передан — берём у app.
        :param owns_transport: Закрывать ли транспорт при выходе из контекста.
        :return: None.
        """
        self.__app = app
        self.__options = options
        self.__transport = transport
        self.__owns_transport = owns_transport

    async def __aenter__(self) -> "AsyncDbQueryService":
        self._ensure_transport()
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        if self.__owns_transport and self.__transport:
            await self.__transport.aclose()
            self.__transport = None

    def _ensure_transport(self) -> "AsyncNativeApiTransport":
        if self.__transport:
            return self.__transport

        # Берём кешированный транспорт из MetaApp.
        if self.__app:
            self.__transport = self.__app.ensure_async_transport()
            return self.__transport

        raise ValueError("Async transport is not configured")

    async def schema_data(self, configuration: Mapping[str, Any]) -> dict:
        """
        Получает схему данных по конфигурации.

        :param configuration: Конфигурация запроса схемы.
        :return: Словарь с данными схемы.
        """
        params = {"configuration": json.dumps(configuration)}
        transport = self._ensure_transport()
        response = await transport.call("db", "schema-data", params, self.__options, multipart_form=True)
        return await self._json_response(response)

    async def upload_data(self, file_descriptor: BinaryIO, configuration: Mapping[str, Any]) -> dict:

        raise NotImplementedError("upload_data is temporarily disabled for async client")

    async def download_data(self, configuration: Mapping[str, Any], output_file: str) -> None:
        raise NotImplementedError("download_data is temporarily disabled for async client")

    async def batch_update(
        self,
        command: str,
        rows: Sequence[Mapping[str, Any]],
        labels: Optional[Mapping[str, Any]] = None,
    ) -> dict[str, Any]:
        """
        Массовая вставка/обновление записей (рекомендуется для 1-5к записей за вызов).

        :param command: SQL-команда INSERT или UPDATE.
        :param rows: Список словарей с данными строк.
        :param labels: job labels для BigQuery запросов. Если None при dbAlias=bigquery — пишется warning в лог.
        :return: Словарь с результатом операции.
        """
        self._warn_if_labels_missing(labels)

        batch_update: dict[str, Any] = {
            "command": command,
            "rows": rows,
            "shardKey": self.__options.get("shardKey"),
        }
        self._attach_labels(batch_update, labels)

        request = {
            "database": {
                "alias": self.__options["dbAlias"]
            },
            "batchUpdate": batch_update
        }
        transport = self._ensure_transport()
        response = await transport.call("db", "batch-update", request, self.__options, multipart_form=False)
        return await self._json_response(response)

    def _is_bigquery_database(self) -> bool:
        db_alias = self.__options.get("dbAlias") or self.__options.get("db_alias") or ""
        return str(db_alias).strip().lower() == "bigquery"

    def _warn_if_labels_missing(self, labels: Optional[Mapping[str, Any]]) -> None:
        if self._is_bigquery_database() and not labels:
            self.__app.log.warning(
                "BigQuery query executed without labels",
                {"dbAlias": self.__options.get("dbAlias"), "shardKey": self.__options.get("shardKey")},
            )

    @staticmethod
    def _attach_labels(payload: dict[str, Any], labels: Optional[Mapping[str, Any]]) -> None:
        if labels is not None:
            payload["labels"] = labels

    async def update(
        self,
        command: str,
        params: Optional[Mapping[str, Any]] = None,
        labels: Optional[Mapping[str, Any]] = None,
    ) -> dict[str, Any]:
        """
        Выполняет запросы INSERT, UPDATE, DELETE и пр., не возвращающие результата.
        Исключение — запросы с RETURNING для PostgreSQL.

        :param command: SQL-запрос.
        :param params: Параметры для prepared statements.
        :param labels: job labels для BigQuery запросов. Если None при dbAlias=bigquery — пишется warning в лог.
        :return: Словарь с результатом операции (DataResult).
        """
        self._warn_if_labels_missing(labels)

        db_query: dict[str, Any] = {
            "command": command,
            "parameters": params,
            "shardKey": self.__options.get("shardKey"),
        }
        self._attach_labels(db_query, labels)

        request = {
            "database": {
                "alias": self.__options["dbAlias"]
            },
            "dbQuery": db_query
        }
        transport = self._ensure_transport()
        response = await transport.call("db", "update", request, self.__options, multipart_form=False)
        return await self._json_response(response)

    async def query(
        self,
        command: str,
        params: Optional[Mapping[str, Any]] = None,
        max_rows: int = 0,
        labels: Optional[Mapping[str, Any]] = None,
    ) -> dict[str, Any]:
        """
        Выполняет запрос, который ОБЯЗАТЕЛЬНО должен вернуть результат.
        Для INSERT, UPDATE, DELETE используйте метод update
        или возвращайте результат через конструкцию RETURNING (недоступно в MySQL).

        Пример:
            await db.query('SELECT * FROM users WHERE id=:id', {"id": MY_USER_ID})

        :param command: SQL-запрос.
        :param params: Параметры для prepared statements.
        :param max_rows: Максимальное кол-во строк. Если запрос вернёт больше — ошибка.
                         При 0 действуют стандартные ограничения (50000).
        :param labels: job labels для BigQuery запросов. Если None при dbAlias=bigquery — пишется warning в лог.
        :return: Словарь с результатом (DataResult).
        """
        self._warn_if_labels_missing(labels)

        db_query: dict[str, Any] = {
            "maxRows": max_rows,
            "command": command,
            "parameters": params,
            "shardKey": self.__options.get("shardKey"),
        }
        self._attach_labels(db_query, labels)

        request = {
            "database": {
                "alias": self.__options["dbAlias"]
            },
            "dbQuery": db_query
        }
        transport = self._ensure_transport()
        response = await transport.call("db", "query", request, self.__options, multipart_form=False)
        return await self._json_response(response)

    async def one(
        self,
        command: str,
        params: Optional[Mapping[str, Any]] = None,
        labels: Optional[Mapping[str, Any]] = None,
    ) -> Optional[dict[str, Any]]:
        """
        Возвращает первую строку ответа, полученного через query.

        Пример:
            await db.one('SELECT * FROM users WHERE id=:id', {"id": MY_USER_ID})

        :param command: SQL-запрос.
        :param params: Параметры для prepared statements.
        :param labels: job labels для BigQuery запросов.
        :return: Словарь с данными первой строки или None, если результат пуст.
        """
        data = await self.query(command, params, labels=labels)
        rows = data.get("rows", [])
        return rows[0] if rows else None

    async def all(  # noqa: A003
        self,
        command: str,
        params: Optional[Mapping[str, Any]] = None,
        labels: Optional[Mapping[str, Any]] = None,
    ) -> list[dict[str, Any]]:  # noqa: A003
        """
        Возвращает все строки ответа, полученного через query.

        Пример:
            await db.all('SELECT * FROM users WHERE id=:id', {"id": MY_USER_ID})

        :param command: SQL-запрос.
        :param params: Параметры для prepared statements.
        :param labels: job labels для BigQuery запросов.
        :return: Список словарей с данными строк.
        """
        data = await self.query(command, params, labels=labels)
        return data.get("rows", [])

    async def _json_response(self, response) -> dict[str, Any]:
        """
        Читает тело ответа и декодирует JSON.

        :param response: HTTP-ответ (httpx.Response).
        :return: Словарь с декодированными данными.
        """
        try:
            body = await response.aread()
            text = body.decode(response.encoding or "utf-8")
            return json.loads(text)
        finally:
            await response.aclose()

    async def _write_stream_to_file(self, response, output_file: str) -> None:
        """
        Записывает потоковый ответ в файл.

        :param response: HTTP-ответ (httpx.Response) в режиме stream.
        :param output_file: Путь к файлу для записи.
        """
        loop = asyncio.get_running_loop()
        with open(output_file, "wb") as out_file:
            async for chunk in response.aiter_bytes():
                if not chunk:
                    continue
                await loop.run_in_executor(None, out_file.write, chunk)
