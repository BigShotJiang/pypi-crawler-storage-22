#!/usr/bin/env python3
"""
Example: Politico News Pipeline Workflow

This example demonstrates using the meter-sdk Workflow API to:
1. Scrape the Politico homepage to get article links
2. Follow each link to scrape article details

Usage:
    export METER_API_KEY=your_api_key
    python examples/politico_workflow.py
"""
import os
import sys
import time

# Add parent to path for local development
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from meter_sdk import MeterClient, Workflow, Filter

# Configuration
API_KEY = os.getenv("METER_API_KEY")
API_BASE = os.getenv("API_BASE", "http://localhost:8000")  # None = use client default (https://api.meter.sh)

# Strategy IDs
INDEX_STRATEGY_ID = "35f24dfd-cc3d-4673-9448-a6f30e465d70"  # Scrapes Politico index
DETAIL_STRATEGY_ID = "43383e8a-89eb-49ff-a086-802119e9d9ce"  # Scrapes article details

# URL field that connects index -> details
URL_FIELD = "link"

# Start URL
START_URL = "https://www.politico.com"


def main():
    if not API_KEY:
        print("Error: METER_API_KEY environment variable not set")
        print("Export it with: export METER_API_KEY=your_key_here")
        sys.exit(1)

    print("=" * 60)
    print("Politico News Pipeline Workflow")
    print("=" * 60)
    print(f"API Base: {API_BASE}")
    print(f"Index Strategy: {INDEX_STRATEGY_ID}")
    print(f"Detail Strategy: {DETAIL_STRATEGY_ID}")
    print(f"Start URL: {START_URL}")
    print(f"URL Field: {URL_FIELD}")

    client = MeterClient(api_key=API_KEY, base_url=API_BASE)

    try:
        # Build the workflow
        print("\n--- Building Workflow ---")
        workflow = Workflow("Politico News Pipeline", description="Scrapes Politico index -> article details")
        index = workflow.start("index", INDEX_STRATEGY_ID, urls=[START_URL])
        details = index.then("details", DETAIL_STRATEGY_ID, url_field=URL_FIELD,
                             filter=Filter.contains("link", "ice"))

        # Create the workflow
        print("\n--- Creating Workflow ---")
        created = client.create_workflow(workflow)
        workflow_id = created["id"]
        print(f"Created workflow: {workflow_id}")
        print(f"  Nodes: {len(created['nodes'])}")
        for node in created["nodes"]:
            print(f"    - {node['node_key']} ({node['input_type']})")
        print(f"  Edges: {len(created['edges'])}")
        for edge in created["edges"]:
            print(f"    - {edge['source_node_key']} -> {edge['target_node_key']}")

        # Run the workflow
        print("\n--- Running Workflow ---")
        run = client.run_workflow(workflow_id, force=True, wait=False)
        run_id = run["id"]
        print(f"Run ID: {run_id}")
        print(f"Status: {run['status']}")

        # Poll for completion
        print("\n--- Waiting for Completion ---")
        for i in range(24):  # Poll for up to 2 minutes
            time.sleep(5)
            run = client.get_workflow_run(workflow_id, run_id)
            elapsed = (i + 1) * 5
            print(f"[{elapsed}s] Status: {run['status']}")

            if run.get("node_executions"):
                for ex in run["node_executions"]:
                    key = ex.get("node_key", ex["node_id"][:8])
                    status = ex["status"]
                    if ex.get("results"):
                        status += f" ({len(ex['results'])} items)"
                    print(f"  - {key}: {status}")

            if run["status"] in ("completed", "failed", "partial"):
                break

        # Show results
        print("\n--- Results ---")
        if run["status"] == "completed":
            print("Workflow completed successfully!")
            if run.get("final_results"):
                print(f"Final results: {len(run['final_results'])} items")
                for item in run["final_results"][:3]:
                    print(f"  - {item}")
                if len(run["final_results"]) > 3:
                    print(f"  ... and {len(run['final_results']) - 3} more")
        else:
            print(f"Workflow ended with status: {run['status']}")
            if run.get("error"):
                print(f"Error: {run['error']}")

        print(f"\nWorkflow ID: {workflow_id}")
        print(f"Run ID: {run_id}")

    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)
    finally:
        client.close()


if __name__ == "__main__":
    main()
