#!/usr/bin/env python3
"""Test the workflow SDK with real Politico strategies.

This test creates a workflow that:
1. Scrapes Politico index page (index strategy)
2. Follows links to get article details (detail strategy)

Prerequisites:
- METER_API_KEY environment variable set
- Strategies already created (see strategy IDs below)
"""
import os
import sys

# Add parent to path for local development
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from meter_sdk import MeterClient, Workflow, MeterError

# Configuration
API_BASE = os.getenv("API_BASE", "http://localhost:8000")
API_KEY = os.getenv("METER_API_KEY")

# Politico strategy IDs
INDEX_STRATEGY_ID = "35f24dfd-cc3d-4673-9448-a6f30e465d70"  # Lists articles
DETAIL_STRATEGY_ID = "43383e8a-89eb-49ff-a086-802119e9d9ce"  # Gets article details

# URL field from start -> next
URL_FIELD = "link"

# Start URL
START_URL = "https://www.politico.com"


def test_api_create_and_run():
    """Test creating and running a workflow via API."""
    if not API_KEY:
        print("\n=== Test: API Create and Run (SKIPPED - no API key) ===")
        return None

    print("\n=== Test: API Create and Run Workflow ===")

    client = MeterClient(api_key=API_KEY, base_url=API_BASE)

    # Create workflow
    workflow = Workflow("SDK Test: Politico Pipeline", description="Created via SDK")
    index = workflow.start("index", INDEX_STRATEGY_ID, urls=[START_URL])
    details = index.then("details", DETAIL_STRATEGY_ID, url_field=URL_FIELD)

    print(f"  Workflow: {workflow.name}")
    print(f"  Start URL: {START_URL}")
    print(f"  URL Field: {URL_FIELD}")

    try:
        # Create workflow
        created = client.create_workflow(workflow)
        workflow_id = created['id']
        print(f"  Created workflow: {workflow_id}")
        print(f"  Nodes: {len(created['nodes'])}")
        print(f"  Edges: {len(created['edges'])}")

        # Run workflow (don't wait)
        run = client.run_workflow(workflow_id, force=True, wait=False)
        run_id = run['id']
        print(f"  Run ID: {run_id}")
        print(f"  Status: {run['status']}")

        # Poll for a bit
        import time
        for i in range(6):
            time.sleep(5)
            run = client.get_workflow_run(workflow_id, run_id)
            print(f"  [{i*5}s] Status: {run['status']}")
            if run.get('node_executions'):
                for exec in run['node_executions']:
                    print(f"    - {exec.get('node_key', exec['node_id'][:8])}: {exec['status']}")
            if run['status'] in ('completed', 'failed', 'partial'):
                break

        print("PASSED")
        return workflow_id

    except MeterError as e:
        print(f"  Error: {e}")
        print("FAILED")
        return None
    finally:
        client.close()


def test_api_list_workflows():
    """Test listing workflows via API."""
    if not API_KEY:
        print("\n=== Test: API List Workflows (SKIPPED - no API key) ===")
        return

    print("\n=== Test: API List Workflows ===")

    client = MeterClient(api_key=API_KEY, base_url=API_BASE)

    try:
        workflows = client.list_workflows()
        print(f"  Found {len(workflows)} workflows")
        for w in workflows[:5]:  # Show first 5
            print(f"    - {w['name']} (id={w['id'][:8]}..., nodes={w.get('node_count', '?')})")
        print("PASSED")
    except MeterError as e:
        print(f"  Error: {e}")
        print("FAILED")
    finally:
        client.close()


def test_api_delete_workflow(workflow_id: str):
    """Test deleting a workflow via API."""
    if not API_KEY or not workflow_id:
        print("\n=== Test: API Delete Workflow (SKIPPED) ===")
        return

    print("\n=== Test: API Delete Workflow ===")

    client = MeterClient(api_key=API_KEY, base_url=API_BASE)

    try:
        result = client.delete_workflow(workflow_id)
        print(f"  Result: {result}")
        print("PASSED")
    except MeterError as e:
        print(f"  Error: {e}")
        print("FAILED")
    finally:
        client.close()


def main():
    print("=" * 60)
    print("Workflow SDK Integration Tests")
    print("=" * 60)
    print(f"API Base: {API_BASE}")
    print(f"API Key: {'Set' if API_KEY else 'Not set (tests will be skipped)'}")
    print(f"Index Strategy: {INDEX_STRATEGY_ID}")
    print(f"Detail Strategy: {DETAIL_STRATEGY_ID}")
    print(f"Start URL: {START_URL}")
    print(f"URL Field: {URL_FIELD}")

    if not API_KEY:
        print("\nNo API key set. Set METER_API_KEY to run tests.")
        return

    # List existing workflows
    test_api_list_workflows()

    # Create and run workflow
    workflow_id = test_api_create_and_run()

    if workflow_id:
        # Ask before deleting
        print("\n" + "=" * 60)
        delete = input("Delete the test workflow? [y/N]: ").strip().lower()
        if delete == 'y':
            test_api_delete_workflow(workflow_id)
        else:
            print(f"Keeping workflow {workflow_id}")

    print("\n" + "=" * 60)
    print("Tests completed")
    print("=" * 60)


if __name__ == "__main__":
    main()
