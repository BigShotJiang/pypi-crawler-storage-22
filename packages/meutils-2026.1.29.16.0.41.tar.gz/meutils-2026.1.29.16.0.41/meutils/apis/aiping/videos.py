#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Project      : AI.  @by PyCharm
# @File         : videos
# @Time         : 2026/1/29 14:37
# @Author       : betterme
# @WeChat       : meutils
# @Software     : PyCharm
# @Description  : todo 基础 继承

from meutils.pipe import *
from meutils.schemas.video_types import SoraVideoRequest, Video

from openai import AsyncOpenAI

"""https://aiping.cn/docs/API/VideoAPI/KLING_VIDEO_API_DOC
	curl -X POST "https://aiping.cn/api/v1/videos" \
  -H "Authorization: Bearer <API_KEY>" \
  -H "Content-Type: application/json" \
  -d '{
        "model": "Kling-Video-O1",
        "prompt": "视频中女生用图片中人物的动作",
        "action_control": true,
        "seconds": 10,
        "mode": "pro",
        "aspect_ratio": "9:16",
        "character_orientation": "image",
        "image_url": "https://help-static-aliyun-doc.aliyuncs.com/file-manage-files/zh-CN/20250925/wpimhv/rap.png",
        "video_url": "https://v4-fdl.kechuangai.com/ksc2/WDy7TzddQesPc-yzgBHGLPC-DvJ1...ktWUeLDSA"
  }'
"""

BASE_URL = "https://aiping.cn/api/v1"


class Tasks(object):

    def __init__(self, base_url: Optional[str] = None, api_key: str = None):
        self.api_key = api_key
        self.client = AsyncOpenAI(api_key=self.api_key)

    async def create(self, request: SoraVideoRequest):  # todo 区分模型
        payload = {
            "model": request.model,
            "prompt": request.prompt,
            "action_control": True,
            "seconds": request.seconds,
            "mode": "std",  # std pro
            "aspect_ratio": request.aspect_ratio,
            "character_orientation": "image",
        }
        if urls := request.input_reference:
            payload['reference_images'] = urls

        if url := request.first_frame_image:
            payload['first_frame_url'] = url

        if url := request.last_frame_image:
            payload['last_frame_url'] = url

        response = self.client.post(path="/videos", body=payload, cast_to=object)
        logger.debug(response)

    async def get(self, task_id: str):
        logger.debug(task_id)

        return await get_task(task_id, self.api_key)
