"""Entry point for mfbt CLI."""

from __future__ import annotations

import argparse
from importlib.metadata import PackageNotFoundError, version

from rich.console import Console


def get_version() -> str:
    """Get the package version from installed metadata."""
    try:
        return version("mfbt-cli")
    except PackageNotFoundError:
        return "0.0.0-dev"


def build_parser() -> argparse.ArgumentParser:
    """Build the bootstrap argument parser."""
    epilog = """\
commands:
  (none)              Launch interactive TUI (default)
  auth                Authentication commands (login, status, refresh, logout)
  projects            Manage projects (list, show, create, switch, archive, delete)
  ralph               Auto-invoke coding agents to implement pending features
  tui                 Launch interactive TUI

Run 'mfbt <command> --help' for details on a specific command.
"""
    parser = argparse.ArgumentParser(
        prog="mfbt",
        description="CLI tool for the mfbt platform",
        epilog=epilog,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"mfbt {get_version()}",
    )
    parser.add_argument(
        "-v",
        "--verbose",
        action="count",
        default=0,
        help="Increase verbosity (-v, -vv, -vvv)",
    )
    return parser


def _has_subcommand(argv: list[str]) -> bool:
    """Check if argv contains a subcommand (a positional arg)."""
    return any(not arg.startswith("-") for arg in argv)


def main(args: list[str] | None = None) -> None:
    """Main entry point for mfbt CLI."""
    import sys

    argv = args if args is not None else sys.argv[1:]

    if _has_subcommand(argv):
        from mfbt._logging import setup_logging

        setup_logging(verbosity=argv.count("-v"))

        from mfbt.cli import app

        typer_args = [a for a in argv if a != "-v"]
        app(typer_args)
        return

    parser = build_parser()
    parsed = parser.parse_args(argv)

    from mfbt._logging import setup_logging

    setup_logging(verbosity=parsed.verbose)

    from mfbt.config import find_project_root, init_mfbt_dir, resolve_config

    console = Console()
    project_root = find_project_root()
    if project_root is None:
        console.print("[red]Error:[/red] No project root found.")
        console.print(
            "Run from within a project directory, or use [bold]mfbt --help[/bold]."
        )
        return

    init_mfbt_dir(project_root)
    config = resolve_config(project_root)

    from mfbt.tui import launch_tui

    launch_tui(project_root, config)


if __name__ == "__main__":
    main()
