"""Project management commands for mfbt CLI.

Provides list, show, create, switch, archive, and delete subcommands
for managing mfbt projects. Covers MCLI-058.
"""

from __future__ import annotations

import logging
from typing import Any, Optional

import typer
from rich.console import Console

from mfbt.error_handler import handle_errors
from mfbt.formatters import ColumnSpec, format_output, format_single_object

logger = logging.getLogger("mfbt.commands.projects")
console = Console()

projects_app = typer.Typer(
    name="projects",
    help="Manage mfbt projects",
    no_args_is_help=True,
)

# ---------------------------------------------------------------------------
# Column definitions
# ---------------------------------------------------------------------------

LIST_COLUMNS = [
    ColumnSpec(key="name", header="Name", max_width=30),
    ColumnSpec(key="type", header="Type", max_width=12),
    ColumnSpec(key="status", header="Status", max_width=20),
    ColumnSpec(key="key", header="Key", max_width=15),
    ColumnSpec(key="id", header="ID", max_width=36, truncate=False),
]

SHOW_FIELDS = [
    ColumnSpec(key="id", header="ID"),
    ColumnSpec(key="name", header="Name"),
    ColumnSpec(key="type", header="Type"),
    ColumnSpec(key="status", header="Status"),
    ColumnSpec(key="key", header="Key"),
    ColumnSpec(key="short_description", header="Description"),
    ColumnSpec(key="project_tech_stack", header="Tech Stack"),
    ColumnSpec(key="org_id", header="Org ID"),
    ColumnSpec(key="created_at", header="Created"),
    ColumnSpec(key="updated_at", header="Updated"),
]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _get_api_client(ctx: typer.Context) -> Any:
    """Build an APIClient from ctx.obj."""
    from mfbt.api_client import APIClient
    from mfbt.cache import ResponseCache
    from mfbt.token_manager import TokenManager

    obj = ctx.obj
    project_root = obj["project_root"]
    config = obj["config"]
    base_url = config.get("base_url", "https://app.mfbt.ai")

    tm = TokenManager(project_root, base_url)
    cache_dir = project_root / ".mfbt" / "cache"
    cache = ResponseCache(cache_dir)
    return APIClient(base_url, tm, cache=cache)


def _require_project_root(ctx: typer.Context) -> None:
    """Exit if no project root found."""
    if ctx.obj.get("project_root") is None:
        console.print(
            "[red]Error:[/red] Could not find a project root. "
            "Run this command from within a project directory."
        )
        raise typer.Exit(code=1)


def _resolve_project_id(ctx: typer.Context, identifier: str) -> str:
    """Resolve an identifier to a project UUID."""
    from mfbt.resolvers import IdentifierCache, ResourceResolver, is_uuid

    if is_uuid(identifier):
        return identifier

    obj = ctx.obj
    project_root = obj["project_root"]
    cache_dir = project_root / ".mfbt" / "cache"
    cache = IdentifierCache(cache_dir)
    client = _get_api_client(ctx)

    try:
        resolver = ResourceResolver(client, cache, console=console)
        resolved = resolver.resolve(identifier, resource_type="projects")
        return resolved.uuid
    finally:
        client.close()


def _resolve_org_id(ctx: typer.Context) -> str:
    """Derive org_id from the active project or the first available project."""
    config = ctx.obj["config"]

    # Try active project first
    active_id = config.get("project_id")
    if active_id:
        client = _get_api_client(ctx)
        try:
            resp = client.get(f"/api/v1/projects/{active_id}")
            org_id = resp.body.get("org_id")
            if org_id:
                return org_id
        finally:
            client.close()

    # Fall back to listing projects
    client = _get_api_client(ctx)
    try:
        resp = client.get("/api/v1/projects")
        projects = resp.body
        if isinstance(projects, list) and projects:
            org_id = projects[0].get("org_id")
            if org_id:
                return org_id
    finally:
        client.close()

    console.print(
        "[red]Error:[/red] Could not determine organization. "
        "Please set an active project first with: mfbt projects switch <id>"
    )
    raise typer.Exit(code=1)


def _populate_cache(ctx: typer.Context, projects: list[dict[str, Any]]) -> None:
    """Populate the identifier cache from a list of project dicts."""
    from mfbt.resolvers import IdentifierCache

    project_root = ctx.obj["project_root"]
    cache_dir = project_root / ".mfbt" / "cache"
    cache = IdentifierCache(cache_dir)
    cache.populate("projects", projects)


def _mark_active(
    projects: list[dict[str, Any]], active_id: str | None
) -> list[dict[str, Any]]:
    """Add an active indicator to the project matching active_id.

    Returns a new list with copies of matching dicts to avoid mutating input.
    """
    if not active_id:
        return projects
    result: list[dict[str, Any]] = []
    for p in projects:
        if p.get("id") == active_id:
            marked = dict(p)
            marked["name"] = f"> {p.get('name', '')}"
            result.append(marked)
        else:
            result.append(p)
    return result


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------


@projects_app.command("list")
def list_projects(
    ctx: typer.Context,
) -> None:
    """List all accessible projects."""
    _require_project_root(ctx)
    obj = ctx.obj
    verbose = obj.get("verbose", False)
    fmt = obj.get("format", "table")

    with handle_errors(console, verbose=verbose):
        client = _get_api_client(ctx)
        try:
            resp = client.get("/api/v1/projects")
            projects = resp.body if isinstance(resp.body, list) else []
        finally:
            client.close()

        _populate_cache(ctx, projects)
        active_id = obj["config"].get("project_id")
        projects = _mark_active(projects, active_id)
        format_output(projects, fmt, LIST_COLUMNS, title="Projects", console=console)


@projects_app.command("show")
def show_project(
    ctx: typer.Context,
    identifier: str = typer.Argument(help="Project ID, short ID, or name"),
) -> None:
    """Show details for a specific project."""
    _require_project_root(ctx)
    obj = ctx.obj
    verbose = obj.get("verbose", False)
    fmt = obj.get("format", "table")

    with handle_errors(console, verbose=verbose):
        project_id = _resolve_project_id(ctx, identifier)
        client = _get_api_client(ctx)
        try:
            resp = client.get(f"/api/v1/projects/{project_id}")
            project = resp.body
        finally:
            client.close()

        format_single_object(project, SHOW_FIELDS, fmt, console=console)


@projects_app.command("create")
def create_project(
    ctx: typer.Context,
    name: str = typer.Option(..., "--name", "-n", help="Project name"),
    project_type: str = typer.Option(
        "application",
        "--type",
        "-t",
        help="Project type: application, feature, bugfix",
    ),
    description: Optional[str] = typer.Option(
        None, "--description", "-d", help="Short description"
    ),
    key: Optional[str] = typer.Option(
        None, "--key", "-k", help="Project key/prefix"
    ),
    tech_stack: Optional[str] = typer.Option(
        None, "--tech-stack", help="Tech stack type"
    ),
) -> None:
    """Create a new project."""
    _require_project_root(ctx)
    obj = ctx.obj
    verbose = obj.get("verbose", False)
    fmt = obj.get("format", "table")

    with handle_errors(console, verbose=verbose):
        org_id = _resolve_org_id(ctx)
        body: dict[str, Any] = {
            "type": project_type,
            "name": name,
        }
        if description is not None:
            body["short_description"] = description
        if key is not None:
            body["key"] = key
        if tech_stack is not None:
            body["project_tech_stack"] = tech_stack

        client = _get_api_client(ctx)
        try:
            resp = client.post(f"/api/v1/orgs/{org_id}/projects", json_body=body)
            project = resp.body
        finally:
            client.close()

        # Auto-switch to the new project
        new_id = project.get("id")
        if new_id:
            from mfbt.config import save_config

            config = obj["config"]
            config["project_id"] = new_id
            save_config(obj["project_root"], config)
            console.print(f"[green]Switched to new project.[/green]")

        format_single_object(project, SHOW_FIELDS, fmt, console=console)


@projects_app.command("switch")
def switch_project(
    ctx: typer.Context,
    identifier: str = typer.Argument(help="Project ID, short ID, or name"),
) -> None:
    """Switch the active project."""
    _require_project_root(ctx)
    obj = ctx.obj
    verbose = obj.get("verbose", False)

    with handle_errors(console, verbose=verbose):
        project_id = _resolve_project_id(ctx, identifier)

        # Validate the project exists
        client = _get_api_client(ctx)
        try:
            resp = client.get(f"/api/v1/projects/{project_id}")
            project = resp.body
        finally:
            client.close()

        from mfbt.config import save_config

        config = obj["config"]
        config["project_id"] = project_id
        save_config(obj["project_root"], config)

        project_name = project.get("name", project_id)
        console.print(f"Switched to project: [bold]{project_name}[/bold]")


@projects_app.command("archive")
def archive_project(
    ctx: typer.Context,
    identifier: str = typer.Argument(help="Project ID, short ID, or name"),
) -> None:
    """Archive a project."""
    _require_project_root(ctx)
    obj = ctx.obj
    verbose = obj.get("verbose", False)
    fmt = obj.get("format", "table")

    with handle_errors(console, verbose=verbose):
        project_id = _resolve_project_id(ctx, identifier)
        client = _get_api_client(ctx)
        try:
            resp = client.post(f"/api/v1/projects/{project_id}/archive")
            project = resp.body
        finally:
            client.close()

        console.print(f"[green]Project archived.[/green]")
        format_single_object(project, SHOW_FIELDS, fmt, console=console)


@projects_app.command("delete")
def delete_project(
    ctx: typer.Context,
    identifier: str = typer.Argument(help="Project ID, short ID, or name"),
    force: bool = typer.Option(
        False, "--force", "-y", help="Skip confirmation prompt"
    ),
) -> None:
    """Delete a project."""
    _require_project_root(ctx)
    obj = ctx.obj
    verbose = obj.get("verbose", False)

    with handle_errors(console, verbose=verbose):
        project_id = _resolve_project_id(ctx, identifier)

        if not force:
            typer.confirm(
                f"Are you sure you want to delete project {project_id}?",
                abort=True,
            )

        client = _get_api_client(ctx)
        try:
            client.delete(f"/api/v1/projects/{project_id}")
        finally:
            client.close()

        # Clear active project if we just deleted it
        config = obj["config"]
        if config.get("project_id") == project_id:
            from mfbt.config import save_config

            config["project_id"] = None
            save_config(obj["project_root"], config)
            console.print("[yellow]Active project cleared.[/yellow]")

        console.print(f"[green]Project deleted.[/green]")
