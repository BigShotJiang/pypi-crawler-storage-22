"""Rich console output for ralph sessions."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from rich.console import Console
from rich.table import Table
from rich.text import Text

if TYPE_CHECKING:
    from mfbt.commands.ralph.types import (
        FeatureOutcome,
        FeatureResult,
        FeatureTask,
        RalphConfig,
        SessionSummary,
    )


class RalphDisplay:
    """Handles all ralph console output in default and quiet modes."""

    def __init__(
        self,
        console: Console,
        *,
        quiet: bool = False,
        stderr_console: Console | None = None,
    ) -> None:
        self._console = console
        self._stderr = stderr_console or Console(stderr=True)
        self._quiet = quiet

    # -- Session lifecycle ----------------------------------------------------

    def session_start(
        self,
        config: RalphConfig,
        phase_title: str,
        progress: dict,
    ) -> None:
        """Print the session banner with phase info and progress."""
        if self._quiet:
            return

        total = progress.get("total_features", 0)
        completed = progress.get("completed_features", 0)
        pending = progress.get("pending_features", 0)
        pct = progress.get("progress_percent", 0.0)

        self._console.print()
        self._console.print("[bold cyan]\\[ralph][/bold cyan] Starting session")
        self._console.print(f"  Phase: [bold]{phase_title}[/bold]")
        self._console.print(f"  Agent: [bold]{config.coding_agent.value}[/bold]")
        self._console.print(f"  Mode:  [bold]{config.mode.value}[/bold]")
        if config.max_turns is not None:
            self._console.print(f"  Max turns: [bold]{config.max_turns}[/bold]")
        self._console.print(
            f"  Progress: {completed}/{total} features ({pct:.0f}%), "
            f"{pending} pending"
        )
        self._console.print()

    def log_directory(self, path: Path) -> None:
        """Print the log directory path in the session banner."""
        if self._quiet:
            return
        self._console.print(f"  Logs:  [bold]{path}[/bold]")
        self._console.print()

    # -- Status summary -------------------------------------------------------

    def show_status(
        self,
        phase_title: str,
        progress: dict,
        config: RalphConfig,
    ) -> None:
        """Render a per-module progress table with next-feature info."""
        self._console.print()
        self._console.print(
            f"[bold cyan]\\[ralph][/bold cyan] Phase: [bold]{phase_title}[/bold]"
        )
        self._console.print(
            f"        Agent: [bold]{config.coding_agent.value}[/bold] "
            f"| Mode: [bold]{config.mode.value}[/bold]"
        )
        self._console.print()

        modules: list[dict] = progress.get("modules", [])

        table = Table(
            box=None,
            show_header=True,
            header_style="dim",
            padding=(0, 2),
        )
        table.add_column("Module", min_width=20)
        table.add_column("Done", justify="right")
        table.add_column("In Progress", justify="right")
        table.add_column("Pending", justify="right")
        table.add_column("Progress", justify="right")

        total_done = 0
        total_in_progress = 0
        total_pending = 0
        total_features = 0

        for m in modules:
            done = m.get("completed_features", 0)
            in_prog = m.get("in_progress_features", 0)
            pending = m.get("pending_features", 0)
            pct = m.get("progress_percent", 0.0)
            mod_total = m.get("total_features", 0)

            total_done += done
            total_in_progress += in_prog
            total_pending += pending
            total_features += mod_total

            key = m.get("module_key", "")
            title = m.get("title", "")
            label = f"{key} — {title}" if title else key
            if pct >= 100:
                label = f"[green]{label}[/green]"
            elif done > 0 or in_prog > 0:
                label = f"[yellow]{label}[/yellow]"
            else:
                label = f"[red]{label}[/red]"
            table.add_row(
                label,
                f"[green]{done}[/green]" if done else "[dim]0[/dim]",
                f"[yellow]{in_prog}[/yellow]" if in_prog else "[dim]0[/dim]",
                f"[dim]{pending}[/dim]",
                f"{pct:.0f}%",
            )

        if modules:
            table.add_section()
            overall_pct = progress.get("progress_percent", 0.0)
            table.add_row(
                "[bold]Total[/bold]",
                f"[bold green]{total_done}[/bold green]" if total_done else "[dim]0[/dim]",
                f"[bold yellow]{total_in_progress}[/bold yellow]" if total_in_progress else "[dim]0[/dim]",
                f"[dim]{total_pending}[/dim]",
                f"[bold]{overall_pct:.0f}%[/bold]",
            )

        self._console.print(table)

        next_feature = progress.get("next_feature")
        if next_feature:
            # Find which module the next feature belongs to
            next_module = ""
            for m in modules:
                if m.get("next_feature") == next_feature:
                    next_module = m.get("module_key", "")
                    break
            suffix = f" ({next_module})" if next_module else ""
            self._console.print()
            self._console.print(
                f"  Next: [bold]{next_feature}[/bold]{suffix}"
            )
        else:
            self._console.print()
            self._console.print("  [dim]All features completed.[/dim]")

        self._console.print()

    def populate_features(self, features: list[dict[str, str]]) -> None:
        """No-op for console display — features are announced as they start."""

    # -- Feature lifecycle ----------------------------------------------------

    def feature_start(
        self,
        feature: FeatureTask,
        attempt: int,
        feature_num: int,
        total: int,
    ) -> None:
        """Announce the start of a feature implementation."""
        if self._quiet:
            return

        counter = f"[{feature_num}/{total}]" if total > 0 else ""
        self._console.print(
            f"[bold cyan]\\[ralph][/bold cyan] {counter} "
            f"Implementing [bold]{feature.feature_key}[/bold] — {feature.title}"
        )
        if attempt > 1:
            self._console.print(
                f"  [yellow]Attempt {attempt}[/yellow]"
            )

    def agent_output(self, line: str) -> None:
        """Print a line of live agent stdout."""
        if self._quiet:
            return
        # Strip trailing newline for cleaner display
        text = line.rstrip("\n")
        if text:
            self._console.print(f"  [dim]{text}[/dim]")

    def feature_complete(self, result: FeatureResult) -> None:
        """Announce the outcome of a feature implementation."""
        from mfbt.commands.ralph.types import FeatureOutcome

        fk = result.feature.feature_key
        elapsed = f"{result.elapsed_seconds:.0f}s"

        if result.outcome == FeatureOutcome.SUCCESS:
            if not self._quiet:
                self._console.print(
                    f"[bold cyan]\\[ralph][/bold cyan] "
                    f"[green]✓[/green] {fk} completed ({elapsed})"
                )
        elif result.outcome == FeatureOutcome.FAILED:
            msg = result.error_message or "unknown error"
            self._stderr.print(
                f"[bold cyan]\\[ralph][/bold cyan] "
                f"[red]✗[/red] {fk} failed ({elapsed}): {msg}"
            )
        elif result.outcome == FeatureOutcome.SKIPPED:
            if not self._quiet:
                self._console.print(
                    f"[bold cyan]\\[ralph][/bold cyan] "
                    f"[yellow]–[/yellow] {fk} skipped: {result.error_message or ''}"
                )

    def feature_retry(
        self,
        feature: FeatureTask,
        attempt: int,
        max_attempts: int,
    ) -> None:
        """Announce a retry for a feature."""
        if self._quiet:
            return
        self._console.print(
            f"[bold cyan]\\[ralph][/bold cyan] "
            f"[yellow]Retrying {feature.feature_key} "
            f"(attempt {attempt}/{max_attempts})[/yellow]"
        )

    # -- Session summary ------------------------------------------------------

    def session_summary(self, summary: SessionSummary) -> None:
        """Print the end-of-session summary."""
        mins = summary.total_elapsed_seconds / 60

        self._console.print()
        self._console.print("[bold cyan]\\[ralph][/bold cyan] Session complete")
        self._console.print(
            f"  Features: {summary.succeeded} succeeded, "
            f"{summary.failed} failed, {summary.skipped} skipped "
            f"({summary.total} total)"
        )
        self._console.print(f"  Duration: {mins:.1f} minutes")

        # List failures if any
        from mfbt.commands.ralph.types import FeatureOutcome

        failures = [r for r in summary.results if r.outcome == FeatureOutcome.FAILED]
        if failures:
            self._console.print()
            self._console.print("[bold red]Failed features:[/bold red]")
            for r in failures:
                msg = r.error_message or "unknown error"
                self._console.print(f"  [red]✗[/red] {r.feature.feature_key}: {msg}")

    # -- Errors ---------------------------------------------------------------

    def error(self, message: str) -> None:
        """Print an error message (always shown, even in quiet mode)."""
        self._stderr.print(
            f"[bold cyan]\\[ralph][/bold cyan] [red]Error:[/red] {message}"
        )

    def warn(self, message: str) -> None:
        """Print a warning message."""
        if self._quiet:
            return
        self._console.print(
            f"[bold cyan]\\[ralph][/bold cyan] [yellow]{message}[/yellow]"
        )
