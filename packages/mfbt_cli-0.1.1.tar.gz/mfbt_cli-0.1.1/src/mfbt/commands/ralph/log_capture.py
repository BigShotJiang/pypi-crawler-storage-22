"""Log capture for ralph agent sessions.

Writes human-readable log files and machine-readable session.json
to `.mfbt/logs/ralph/<timestamp>/`.
"""

from __future__ import annotations

import json
import logging
import re
import shlex
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import IO, TYPE_CHECKING, Any

if TYPE_CHECKING:
    from mfbt.commands.ralph.types import (
        AgentResult,
        FeatureResult,
        FeatureTask,
        RalphConfig,
        SessionSummary,
    )

logger = logging.getLogger("mfbt.commands.ralph.log_capture")

_SANITIZE_RE = re.compile(r"[^a-zA-Z0-9\-_]")


def _sanitize_key(key: str) -> str:
    """Replace non-alphanumeric/dash/underscore chars with ``_``."""
    return _SANITIZE_RE.sub("_", key)


def _ts_dirname() -> str:
    """Return a timestamp string suitable for a directory name."""
    return datetime.now(timezone.utc).strftime("%Y-%m-%d_%H-%M-%S")


class RalphLogger:
    """Captures agent output and metadata to disk during a ralph session."""

    def __init__(self, log_base_dir: Path, agent_type: Any) -> None:
        self._log_base_dir = log_base_dir / "ralph"
        self._agent_type = agent_type
        self._session_dir: Path | None = None
        self._current_file: IO[str] | None = None
        self._write_failed = False
        self._session_data: dict[str, Any] = {}
        self._current_feature_key: str | None = None
        self._current_attempt: int = 0

    # -- Session lifecycle ---------------------------------------------------

    def start_session(
        self,
        config: RalphConfig,
        phase_title: str,
        progress: dict,
    ) -> Path:
        """Create session directory and write initial session.json."""
        self._session_dir = self._log_base_dir / _ts_dirname()
        self._session_dir.mkdir(parents=True, exist_ok=True)

        self._session_data = {
            "cli_command": shlex.join(sys.argv),
            "started_at": datetime.now(timezone.utc).isoformat(),
            "agent_type": config.coding_agent.value,
            "mode": config.mode.value,
            "project_id": config.project_id,
            "phase_id": config.phase_id,
            "phase_title": phase_title,
            "max_turns": config.max_turns,
            "progress_at_start": {
                "total_features": progress.get("total_features", 0),
                "completed_features": progress.get("completed_features", 0),
                "pending_features": progress.get("pending_features", 0),
                "progress_percent": progress.get("progress_percent", 0.0),
            },
            "features": [],
        }
        self._write_session_json()
        return self._session_dir

    # -- Feature lifecycle ---------------------------------------------------

    def start_feature(
        self,
        feature: FeatureTask,
        attempt: int,
        max_attempts: int,
        prompt: str,
        agent_command: list[str] | None = None,
    ) -> None:
        """Open a log file for a feature attempt and write the header."""
        if self._session_dir is None:
            return

        self._write_failed = False
        self._current_feature_key = feature.feature_key
        self._current_attempt = attempt

        safe_key = _sanitize_key(feature.feature_key)
        filename = f"{safe_key}_attempt-{attempt}.log"
        filepath = self._session_dir / filename

        try:
            self._current_file = open(filepath, "w", encoding="utf-8")  # noqa: SIM115
            started = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
            # Build a display-safe version of the command (prompt replaced
            # with placeholder since it's logged separately below).
            if agent_command:
                display_cmd = []
                skip_next = False
                for i, arg in enumerate(agent_command):
                    if skip_next:
                        skip_next = False
                        continue
                    if arg == "-p" and i + 1 < len(agent_command):
                        display_cmd.extend(["-p", "<prompt>"])
                        skip_next = True
                    else:
                        display_cmd.append(arg)
                cmd_str = shlex.join(display_cmd)
            else:
                cmd_str = None

            self._current_file.write(
                f"=== Ralph Agent Log ===\n"
                f"Feature: {feature.feature_key} — {feature.title}\n"
                f"Attempt: {attempt} of {max_attempts}\n"
                f"Agent: {self._agent_type.value}\n"
                f"Started: {started}\n"
            )
            if cmd_str:
                self._current_file.write(f"Command: {cmd_str}\n")
            self._current_file.write(
                f"\n"
                f"=== Prompt ===\n"
                f"{prompt}\n"
                f"\n"
                f"=== Output ===\n"
            )
            self._current_file.flush()
        except OSError:
            logger.warning("Failed to open log file %s", filepath, exc_info=True)
            self._write_failed = True
            self._current_file = None

    def log_output(self, line: str) -> None:
        """Append a line to the current log file. No-ops if no file open."""
        fh = self._current_file
        if fh is None or fh.closed or self._write_failed:
            return
        try:
            fh.write(line)
            fh.flush()
        except OSError:
            logger.warning("Log write failed; disabling writes for current feature")
            self._write_failed = True

    def end_feature(
        self,
        agent_result: AgentResult | None,
        feature_result: FeatureResult,
    ) -> None:
        """Write result section, close file, update session.json."""
        fh = self._current_file
        if fh is not None and not fh.closed:
            try:
                # Stderr section
                stderr = agent_result.stderr.strip() if agent_result else ""
                if stderr:
                    fh.write(f"\n=== Stderr ===\n{stderr}\n")

                # Result section
                exit_code = agent_result.exit_code if agent_result else None
                fh.write(
                    f"\n=== Result ===\n"
                    f"Exit code: {exit_code}\n"
                    f"Duration: {feature_result.elapsed_seconds:.1f}s\n"
                    f"Outcome: {feature_result.outcome.value}\n"
                )
                if feature_result.error_message:
                    fh.write(f"Error: {feature_result.error_message}\n")
            except OSError:
                logger.warning("Failed to write result section", exc_info=True)
            finally:
                fh.close()

        self._current_file = None

        # Update session.json with this feature's result
        if self._session_dir is not None:
            safe_key = _sanitize_key(feature_result.feature.feature_key)
            log_file = f"{safe_key}_attempt-{feature_result.attempts}.log"
            self._session_data.setdefault("features", []).append(
                {
                    "feature_key": feature_result.feature.feature_key,
                    "title": feature_result.feature.title,
                    "outcome": feature_result.outcome.value,
                    "attempts": feature_result.attempts,
                    "elapsed_seconds": round(feature_result.elapsed_seconds, 1),
                    "exit_code": (
                        agent_result.exit_code if agent_result else None
                    ),
                    "error_message": feature_result.error_message,
                    "log_file": log_file,
                }
            )
            self._write_session_json()

    def abort_feature(self) -> None:
        """Write interruption marker and close the log file."""
        fh = self._current_file
        if fh is not None and not fh.closed:
            try:
                fh.write("\n=== INTERRUPTED ===\n")
            except OSError:
                pass
            finally:
                fh.close()
        self._current_file = None

    # -- Session end ---------------------------------------------------------

    def end_session(self, summary: SessionSummary) -> None:
        """Finalize session.json with summary data."""
        if self._session_dir is None:
            return

        self._session_data["ended_at"] = datetime.now(timezone.utc).isoformat()
        self._session_data["summary"] = {
            "total": summary.total,
            "succeeded": summary.succeeded,
            "failed": summary.failed,
            "skipped": summary.skipped,
            "total_elapsed_seconds": round(summary.total_elapsed_seconds, 1),
        }
        self._write_session_json()

    # -- Properties ----------------------------------------------------------

    @property
    def session_dir(self) -> Path | None:
        return self._session_dir

    # -- Internal ------------------------------------------------------------

    def _write_session_json(self) -> None:
        """Write session.json to disk."""
        if self._session_dir is None:
            return
        try:
            path = self._session_dir / "session.json"
            path.write_text(
                json.dumps(self._session_data, indent=2) + "\n",
                encoding="utf-8",
            )
        except OSError:
            logger.warning("Failed to write session.json", exc_info=True)
