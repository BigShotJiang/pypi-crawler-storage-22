"""API integration for ralph feature discovery and progress tracking."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

from mfbt.commands.ralph.types import FeatureTask, OrchestrationMode

if TYPE_CHECKING:
    from mfbt.api_client import APIClient

logger = logging.getLogger("mfbt.commands.ralph.progress")


def resolve_phase_id(
    client: APIClient,
    project_id: str,
    phase_hint: str | None,
) -> tuple[str, str]:
    """Resolve to a single brainstorming phase ID and title.

    If *phase_hint* is provided, match by id, short_id, or url_identifier.
    Otherwise auto-select if exactly one non-archived phase exists.

    Returns:
        (phase_id, phase_title)

    Raises:
        SystemExit via typer.Exit on ambiguity or no match.
    """
    import typer

    resp = client.get(f"/api/v1/projects/{project_id}/brainstorming-phases")
    phases: list[dict[str, Any]] = resp.body if isinstance(resp.body, list) else []

    # Filter out archived phases
    active = [p for p in phases if p.get("archived_at") is None]

    if phase_hint is not None:
        for p in active:
            if phase_hint in (p.get("id"), p.get("short_id"), p.get("url_identifier")):
                return p["id"], p["title"]
        raise typer.Exit(code=1)

    if len(active) == 0:
        raise typer.Exit(code=1)

    if len(active) == 1:
        return active[0]["id"], active[0]["title"]

    # Multiple active phases — user must specify
    raise typer.Exit(code=1)


def get_phase_progress(client: APIClient, phase_id: str) -> dict[str, Any]:
    """Fetch implementation progress for a brainstorming phase."""
    resp = client.get(
        f"/api/v1/brainstorming-phases/{phase_id}/implementation-progress"
    )
    return resp.body if isinstance(resp.body, dict) else {}


def get_module_progress(client: APIClient, module_id: str) -> dict[str, Any]:
    """Fetch implementation progress for a single module."""
    resp = client.get(
        f"/api/v1/modules/{module_id}/implementation-progress"
    )
    return resp.body if isinstance(resp.body, dict) else {}


def _resolve_feature_by_key(
    client: APIClient,
    project_id: str,
    phase_id: str,
    feature_key: str,
    module_id: str | None = None,
) -> dict[str, Any] | None:
    """Find a feature by its key within a phase, optionally scoped to a module."""
    params: dict[str, Any] = {
        "brainstorming_phase_id": phase_id,
        "limit": 500,
    }
    if module_id is not None:
        params["module_id"] = module_id

    resp = client.get(f"/api/v1/projects/{project_id}/features", params=params)
    body = resp.body
    if isinstance(body, dict) and "items" in body:
        features = body["items"]
    elif isinstance(body, list):
        features = body
    else:
        features = []

    for f in features:
        if f.get("feature_key") == feature_key:
            return f
    return None


def _get_primary_implementation(
    client: APIClient,
    feature_id: str,
) -> dict[str, Any] | None:
    """Fetch the primary implementation for a feature."""
    resp = client.get(f"/api/v1/features/{feature_id}/implementations")
    body = resp.body
    if isinstance(body, dict) and "items" in body:
        impls = body["items"]
    elif isinstance(body, list):
        impls = body
    else:
        impls = []
    for impl in impls:
        if impl.get("is_primary", False):
            return impl
    # Fallback: return first if none marked primary
    return impls[0] if impls else None


def get_pending_feature_list(
    client: APIClient,
    project_id: str,
    phase_id: str,
    progress: dict[str, Any],
) -> list[dict[str, str]]:
    """Fetch all non-completed features for display in the TUI table.

    Returns a list of dicts with feature_key, title, module_key, priority.
    """
    # Build module_id -> module_key mapping from progress data
    module_map: dict[str, str] = {}
    for m in progress.get("modules", []):
        mid = m.get("module_id", "")
        mkey = m.get("module_key", "")
        if mid and mkey:
            module_map[mid] = mkey

    resp = client.get(
        f"/api/v1/projects/{project_id}/features",
        params={
            "brainstorming_phase_id": phase_id,
            "completion_status": ["pending", "in_progress"],
            "limit": 500,
        },
    )
    body = resp.body
    if isinstance(body, dict) and "items" in body:
        features = body["items"]
    elif isinstance(body, list):
        features = body
    else:
        features = []

    pending = []
    for f in features:
        # Only include implementation features with prompt plans (ready to build).
        # Conversation-type features and those without prompt plans aren't
        # tracked by the progress endpoint and aren't actionable.
        if f.get("feature_type") != "implementation":
            continue
        if not f.get("has_prompt_plan", False):
            continue
        pending.append(
            {
                "feature_key": f.get("feature_key", ""),
                "title": f.get("title", ""),
                "module_key": module_map.get(f.get("module_id", ""), ""),
                "priority": f.get("priority", ""),
            }
        )
    return pending


def _find_in_progress_feature(
    client: APIClient,
    project_id: str,
    phase_id: str,
    modules: list[dict[str, Any]],
) -> tuple[str | None, dict[str, Any] | None]:
    """Find an in_progress feature when next_feature is not set.

    Returns (feature_key, module_dict) or (None, None).
    """
    # Build module_id -> module dict for lookup
    module_by_id = {m["module_id"]: m for m in modules if "module_id" in m}

    resp = client.get(
        f"/api/v1/projects/{project_id}/features",
        params={
            "brainstorming_phase_id": phase_id,
            "completion_status": "in_progress",
            "limit": 1,
        },
    )
    body = resp.body
    if isinstance(body, dict) and "items" in body:
        items = body["items"]
    elif isinstance(body, list):
        items = body
    else:
        items = []

    if not items:
        return None, None

    feature = items[0]
    feature_key = feature.get("feature_key")
    module_id = feature.get("module_id", "")
    target_module = module_by_id.get(module_id)
    return feature_key, target_module


def get_next_feature_task(
    client: APIClient,
    project_id: str,
    phase_id: str,
    mode: OrchestrationMode,
) -> FeatureTask | None:
    """Discover the next pending feature to implement.

    For *feature-by-feature* mode, uses the phase-level ``next_feature`` key.
    For *module-by-module* mode, iterates modules in the progress response and
    picks the first module with a ``next_feature``.

    Returns ``None`` when no pending features remain.
    """
    progress = get_phase_progress(client, phase_id)
    modules: list[dict[str, Any]] = progress.get("modules", [])

    target_feature_key: str | None = None
    target_module: dict[str, Any] | None = None

    if mode == OrchestrationMode.FEATURE_BY_FEATURE:
        target_feature_key = progress.get("next_feature")
        if target_feature_key is not None:
            # Find which module this feature belongs to
            for m in modules:
                if m.get("next_feature") == target_feature_key:
                    target_module = m
                    break
    else:
        # Module-by-module: find first module with pending work
        for m in modules:
            nf = m.get("next_feature")
            if nf is not None:
                target_feature_key = nf
                target_module = m
                break

    # If next_feature is None but in_progress features exist, find them
    # directly. The progress API only sets next_feature for pending features,
    # so in_progress features (from a previous failed attempt) are missed.
    if target_feature_key is None:
        in_progress = progress.get("in_progress_features", 0)
        if in_progress > 0:
            target_feature_key, target_module = _find_in_progress_feature(
                client, project_id, phase_id, modules
            )

    if target_feature_key is None:
        return None

    # Resolve feature key to full feature details
    feature = _resolve_feature_by_key(
        client,
        project_id,
        phase_id,
        target_feature_key,
        module_id=target_module["module_id"] if target_module else None,
    )
    if feature is None:
        logger.warning("Could not resolve feature key %s", target_feature_key)
        return None

    # Get primary implementation details
    impl_list_item = _get_primary_implementation(client, feature["id"])
    if impl_list_item is None:
        logger.warning("No implementation found for feature %s", feature["id"])
        return None

    # Fetch full implementation to get spec_text / prompt_plan_text
    impl_resp = client.get(f"/api/v1/implementations/{impl_list_item['id']}")
    impl = impl_resp.body if isinstance(impl_resp.body, dict) else {}

    return FeatureTask(
        feature_id=feature["id"],
        feature_key=feature.get("feature_key", target_feature_key),
        title=feature.get("title", ""),
        module_key=target_module.get("module_key", "") if target_module else "",
        module_title=target_module.get("title", "") if target_module else "",
        priority=feature.get("priority", ""),
        implementation_id=impl_list_item["id"],
        spec_text=impl.get("spec_text") or feature.get("spec_text"),
        prompt_plan_text=impl.get("prompt_plan_text") or feature.get("prompt_plan_text"),
    )


def verify_feature_completed(client: APIClient, feature_id: str) -> bool:
    """Check if a feature's completion_status is 'completed'."""
    resp = client.get(f"/api/v1/features/{feature_id}")
    body = resp.body if isinstance(resp.body, dict) else {}
    return body.get("completion_status") == "completed"


def get_mcp_config(client: APIClient, project_id: str) -> dict[str, Any]:
    """Fetch MCP connection configuration for the project."""
    resp = client.get(f"/api/v1/projects/{project_id}/mcp-config")
    return resp.body if isinstance(resp.body, dict) else {}
