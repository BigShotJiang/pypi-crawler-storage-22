"""Textual TUI application for ralph orchestration."""

from __future__ import annotations

import time
from pathlib import Path
from typing import TYPE_CHECKING, Any

from rich.table import Table
from rich.text import Text
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Vertical
from textual.reactive import reactive
from textual.screen import ModalScreen
from textual.widget import Widget
from textual.widgets import DataTable, RichLog, Static

if TYPE_CHECKING:
    from mfbt.api_client import APIClient
    from mfbt.commands.ralph.types import RalphConfig

# Color cycle for shimmer/glisten effect (dim teal → white → dim teal)
_GLISTEN_COLORS = [
    "#4a9eaa",
    "#6ecede",
    "#98effa",
    "#d0faff",
    "#ffffff",
    "#d0faff",
    "#98effa",
    "#6ecede",
]


# ---------------------------------------------------------------------------
# Widgets
# ---------------------------------------------------------------------------


class StatusSummary(Static):
    """Pre-confirmation status screen showing phase progress summary."""

    def __init__(
        self,
        phase_title: str,
        progress: dict,
        config: RalphConfig,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self._phase_title = phase_title
        self._progress = progress
        self._config = config

    def _build_renderable(self) -> Any:
        """Build the status summary as Rich renderables for Textual."""
        from rich.console import Group

        parts: list[Any] = []

        parts.append(Text(""))
        parts.append(
            Text.from_markup(
                f"[bold cyan]\\[ralph][/bold cyan] Phase: [bold]{self._phase_title}[/bold]"
            )
        )
        parts.append(
            Text.from_markup(
                f"        Agent: [bold]{self._config.coding_agent.value}[/bold] "
                f"| Mode: [bold]{self._config.mode.value}[/bold]"
            )
        )
        parts.append(Text(""))

        modules: list[dict] = self._progress.get("modules", [])

        table = Table(
            box=None,
            show_header=True,
            header_style="dim",
            padding=(0, 2),
        )
        table.add_column("Module", min_width=20)
        table.add_column("Done", justify="right")
        table.add_column("In Progress", justify="right")
        table.add_column("Pending", justify="right")
        table.add_column("Progress", justify="right")

        total_done = 0
        total_in_progress = 0
        total_pending = 0
        total_features = 0

        for m in modules:
            done = m.get("completed_features", 0)
            in_prog = m.get("in_progress_features", 0)
            pending = m.get("pending_features", 0)
            pct = m.get("progress_percent", 0.0)
            mod_total = m.get("total_features", 0)

            total_done += done
            total_in_progress += in_prog
            total_pending += pending
            total_features += mod_total

            key = m.get("module_key", "")
            title = m.get("title", "")
            label = f"{key} — {title}" if title else key
            if pct >= 100:
                label = f"[green]{label}[/green]"
            elif done > 0 or in_prog > 0:
                label = f"[yellow]{label}[/yellow]"
            else:
                label = f"[red]{label}[/red]"
            table.add_row(
                label,
                f"[green]{done}[/green]" if done else "[dim]0[/dim]",
                f"[yellow]{in_prog}[/yellow]" if in_prog else "[dim]0[/dim]",
                f"[dim]{pending}[/dim]",
                f"{pct:.0f}%",
            )

        if modules:
            table.add_section()
            overall_pct = self._progress.get("progress_percent", 0.0)
            table.add_row(
                "[bold]Total[/bold]",
                f"[bold green]{total_done}[/bold green]" if total_done else "[dim]0[/dim]",
                f"[bold yellow]{total_in_progress}[/bold yellow]" if total_in_progress else "[dim]0[/dim]",
                f"[dim]{total_pending}[/dim]",
                f"[bold]{overall_pct:.0f}%[/bold]",
            )

        parts.append(table)

        next_feature = self._progress.get("next_feature")
        if next_feature:
            next_module = ""
            for m in modules:
                if m.get("next_feature") == next_feature:
                    next_module = m.get("module_key", "")
                    break
            suffix = f" ({next_module})" if next_module else ""
            parts.append(Text(""))
            parts.append(
                Text.from_markup(f"  Next: [bold]{next_feature}[/bold]{suffix}")
            )
        else:
            parts.append(Text(""))
            parts.append(Text.from_markup("  [dim]All features completed.[/dim]"))

        parts.append(Text(""))
        parts.append(
            Text.from_markup(
                "  Press [bold]c[/bold] to continue, [bold]q[/bold] to quit"
            )
        )

        return Group(*parts)

    def on_mount(self) -> None:
        self.update(self._build_renderable())


class RalphHeader(Widget):
    """Top header showing phase, agent, mode, and progress."""

    phase_title: reactive[str] = reactive("")
    agent_name: reactive[str] = reactive("")
    mode: reactive[str] = reactive("")
    total_features: reactive[int] = reactive(0)
    completed: reactive[int] = reactive(0)
    pending: reactive[int] = reactive(0)
    progress_pct: reactive[float] = reactive(0.0)
    session_state: reactive[str] = reactive("running")

    def render(self) -> str:
        state_icon = {
            "running": "[cyan]\u25b6[/cyan]",
            "complete": "[green]\u2713[/green]",
        }.get(self.session_state, "")

        line1 = (
            f" {state_icon} [bold]ralph[/bold]"
            f" \u2014 Phase: [bold]{self.phase_title}[/bold]"
            f" | Agent: [bold]{self.agent_name}[/bold]"
            f" | {self.mode}"
        )
        line2 = (
            f" Progress: {self.completed}/{self.total_features}"
            f" ({self.progress_pct:.0f}%)"
            f" | {self.pending} pending"
        )
        return f"{line1}\n{line2}"

    def _trigger_update(self) -> None:
        self.refresh()

    def watch_phase_title(self, value: str) -> None:
        self._trigger_update()

    def watch_agent_name(self, value: str) -> None:
        self._trigger_update()

    def watch_mode(self, value: str) -> None:
        self._trigger_update()

    def watch_total_features(self, value: int) -> None:
        self._trigger_update()

    def watch_completed(self, value: int) -> None:
        self._trigger_update()

    def watch_pending(self, value: int) -> None:
        self._trigger_update()

    def watch_progress_pct(self, value: float) -> None:
        self._trigger_update()

    def watch_session_state(self, value: str) -> None:
        self._trigger_update()


class FeatureProgressTable(DataTable):
    """Table showing per-feature progress with vim navigation."""

    BINDINGS = [
        Binding("j", "cursor_down", "Down", show=False),
        Binding("k", "cursor_up", "Up", show=False),
        Binding("g", "scroll_home", "Top", show=False),
        Binding("G", "scroll_end", "Bottom", show=False),
    ]

    _COLUMNS = [
        ("num", "#"),
        ("key", "KEY"),
        ("module", "MODULE"),
        ("title", "TITLE"),
        ("status", "STATUS"),
        ("time", "TIME"),
        ("attempts", "ATTEMPTS"),
    ]

    def on_mount(self) -> None:
        self.cursor_type = "row"
        self.zebra_stripes = True
        for col_key, col_label in self._COLUMNS:
            self.add_column(col_label, key=col_key)

    def add_feature(self, num: int, key: str, module_key: str, title: str) -> None:
        """Add a new feature row in pending state."""
        self.add_row(
            str(num),
            f"[dim]{key}[/dim]",
            f"[dim]{module_key}[/dim]",
            title,
            "[dim]\u00b7 pending[/dim]",
            "[dim]-[/dim]",
            "[dim]-[/dim]",
            key=key,
        )

    def update_feature(
        self,
        key: str,
        *,
        status: str | None = None,
        time_str: str | None = None,
        attempts: int | None = None,
    ) -> None:
        """Update an existing feature row."""
        try:
            row_key = self.get_row(key)
        except Exception:
            return

        if status is not None:
            self.update_cell(key, "status", Text.from_markup(status))
        if time_str is not None:
            self.update_cell(key, "time", time_str)
        if attempts is not None:
            self.update_cell(key, "attempts", str(attempts))

    def action_scroll_end(self) -> None:
        if self.row_count > 0:
            self.move_cursor(row=self.row_count - 1)

    def action_scroll_home(self) -> None:
        if self.row_count > 0:
            self.move_cursor(row=0)


class AgentOutputLog(RichLog):
    """Scrolling log of agent output with vim navigation."""

    BINDINGS = [
        Binding("j", "scroll_down", "Down", show=False),
        Binding("k", "scroll_up", "Up", show=False),
    ]

    def __init__(self, **kwargs: Any) -> None:
        super().__init__(auto_scroll=True, max_lines=5000, wrap=True, **kwargs)

    def clear_log(self) -> None:
        """Clear all log content."""
        self.clear()


class LogPaneHeader(Static):
    """Header above agent output log — shows 'Implementing <key>' with shimmer."""

    pass


class RalphStatusBar(Static):
    """Bottom status bar showing session counts and elapsed time."""

    succeeded: reactive[int] = reactive(0)
    failed: reactive[int] = reactive(0)
    pending: reactive[int] = reactive(0)
    elapsed_seconds: reactive[float] = reactive(0.0)

    def render(self) -> str:
        mins, secs = divmod(int(self.elapsed_seconds), 60)
        elapsed = f"{mins}:{secs:02d}"
        return (
            f" [green]\u2713 {self.succeeded}[/green]"
            f"  [red]\u2717 {self.failed}[/red]"
            f"  [dim]\u00b7 {self.pending}[/dim]"
            f"  | {elapsed} elapsed"
        )

    def _trigger_update(self) -> None:
        self.update(self.render())

    def watch_succeeded(self, value: int) -> None:
        self._trigger_update()

    def watch_failed(self, value: int) -> None:
        self._trigger_update()

    def watch_pending(self, value: int) -> None:
        self._trigger_update()

    def watch_elapsed_seconds(self, value: float) -> None:
        self._trigger_update()


class RalphCommandBar(Static):
    """Fixed command hint bar."""

    def render(self) -> str:
        return " [bold]<enter>[/bold] View logs  [bold]<q>[/bold] Quit"


# ---------------------------------------------------------------------------
# Log viewer modal
# ---------------------------------------------------------------------------


class _ModalLog(RichLog):
    """RichLog with vim-style scrolling for the log viewer modal."""

    BINDINGS = [
        Binding("j", "scroll_down", "Down", show=False),
        Binding("k", "scroll_up", "Up", show=False),
    ]

    def __init__(self, **kwargs: Any) -> None:
        super().__init__(auto_scroll=False, wrap=True, **kwargs)


class LogViewerModal(ModalScreen):
    """Modal screen showing log file contents for a feature."""

    BINDINGS = [
        Binding("escape", "dismiss", "Close", priority=True),
        Binding("q", "dismiss", "Close", show=False),
    ]

    def __init__(self, content: str, title: str, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self._content = content
        self._title = title

    def compose(self) -> ComposeResult:
        with Vertical(id="log-modal-container"):
            yield Static(self._title, id="log-modal-title")
            yield _ModalLog(id="log-modal-content")
            yield Static(
                " [bold]<esc>[/bold] Close  [bold]j/k[/bold] Scroll",
                id="log-modal-hint",
            )

    def on_mount(self) -> None:
        log = self.query_one("#log-modal-content", _ModalLog)
        for line in self._content.splitlines():
            log.write(Text(line))


# ---------------------------------------------------------------------------
# App
# ---------------------------------------------------------------------------


class RalphTUIApp(App):
    """Standalone Textual app for ralph orchestration progress."""

    CSS_PATH = "tui_app.tcss"
    TITLE = "ralph"

    BINDINGS = [
        Binding("q", "quit", "Quit", priority=True),
        Binding("escape", "quit", "Quit", show=False),
        Binding("c", "confirm", "Continue", show=False),
    ]

    def __init__(
        self,
        ralph_config: RalphConfig,
        client: APIClient,
        phase_title: str,
        log_dir: Path | None = None,
        progress: dict | None = None,
    ) -> None:
        super().__init__()
        self.ralph_config = ralph_config
        self.client = client
        self.phase_title = phase_title
        self.log_dir = log_dir
        self._progress = progress or {}
        self._orchestrator: Any = None
        self._session_start: float = 0.0
        self._confirmed: bool = False
        self.session_log_dir: Path | None = None
        self._running_feature_key: str | None = None
        self._glisten_frame: int = 0

    def compose(self) -> ComposeResult:
        yield StatusSummary(
            self.phase_title,
            self._progress,
            self.ralph_config,
            id="status-summary",
        )
        yield RalphHeader(id="ralph-header", classes="-hidden")
        yield FeatureProgressTable(id="feature-table", classes="-hidden")
        yield LogPaneHeader(id="log-pane-header", classes="-hidden")
        yield AgentOutputLog(id="agent-output", classes="-hidden")
        yield RalphCommandBar(id="ralph-command-bar", classes="-hidden")
        yield RalphStatusBar(id="ralph-status-bar", classes="-hidden")

    def on_mount(self) -> None:
        pass

    def action_confirm(self) -> None:
        """Handle 'c' key — transition from status screen to orchestration."""
        if self._confirmed:
            return
        self._confirmed = True

        self.query_one("#status-summary").add_class("-hidden")
        self.query_one("#ralph-header").remove_class("-hidden")
        self.query_one("#feature-table").remove_class("-hidden")
        self.query_one("#log-pane-header").remove_class("-hidden")
        self.query_one("#agent-output").remove_class("-hidden")
        self.query_one("#ralph-command-bar").remove_class("-hidden")
        self.query_one("#ralph-status-bar").remove_class("-hidden")

        self._session_start = time.monotonic()
        self.set_interval(1.0, self._tick_elapsed)
        self.set_interval(0.2, self._glisten_tick)
        self.run_worker(self._run_orchestrator, thread=True)

    def on_data_table_row_selected(self, event: DataTable.RowSelected) -> None:
        """Handle Enter on a feature row — show logs in a modal."""
        feature_key = str(event.row_key.value)
        self._show_log_modal(feature_key)

    def _show_log_modal(self, feature_key: str) -> None:
        """Find log files for a feature and display them in a modal."""
        if self.session_log_dir is None or not self.session_log_dir.exists():
            self.notify("No logs available yet", severity="warning")
            return

        from mfbt.commands.ralph.log_capture import _sanitize_key

        sanitized = _sanitize_key(feature_key)
        log_files = sorted(self.session_log_dir.glob(f"{sanitized}_attempt-*.log"))

        if not log_files:
            self.notify(f"No logs for {feature_key} yet", severity="warning")
            return

        content_parts = []
        for lf in log_files:
            try:
                content_parts.append(lf.read_text())
            except OSError:
                content_parts.append(f"(could not read {lf.name})")

        content = "\n\n".join(content_parts)
        self.push_screen(LogViewerModal(content, f" Logs: {feature_key}"))

    def _tick_elapsed(self) -> None:
        """Update elapsed time display every second."""
        try:
            status_bar = self.query_one("#ralph-status-bar", RalphStatusBar)
            status_bar.elapsed_seconds = time.monotonic() - self._session_start
        except Exception:
            pass

    def _glisten_tick(self) -> None:
        """Cycle the shimmer effect on the running feature status + log header."""
        key = self._running_feature_key
        if key is None:
            return
        self._glisten_frame = (self._glisten_frame + 1) % len(_GLISTEN_COLORS)
        color = _GLISTEN_COLORS[self._glisten_frame]
        try:
            table = self.query_one("#feature-table", FeatureProgressTable)
            table.update_cell(
                key, "status", Text.from_markup(f"[{color}]\u27f3 running[/{color}]")
            )
        except Exception:
            pass
        try:
            header = self.query_one("#log-pane-header", LogPaneHeader)
            header.update(
                Text.from_markup(
                    f" [{color}]\u27f3 Implementing {key}[/{color}]"
                )
            )
        except Exception:
            pass

    def _run_orchestrator(self) -> None:
        """Run the orchestrator in a worker thread."""
        from mfbt.commands.ralph.log_capture import RalphLogger
        from mfbt.commands.ralph.orchestrator import RalphOrchestrator
        from mfbt.commands.ralph.tui_display import RalphTUIDisplay

        display = RalphTUIDisplay(self)

        ralph_logger = None
        if self.log_dir is not None:
            ralph_logger = RalphLogger(
                self.log_dir, self.ralph_config.coding_agent
            )

        self._orchestrator = RalphOrchestrator(
            self.ralph_config, self.client, display, logger=ralph_logger
        )
        self._orchestrator.run()

    async def action_quit(self) -> None:
        if self._orchestrator is not None:
            try:
                self._orchestrator.stop()
            except Exception:
                pass
        await super().action_quit()


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def launch_ralph_tui(
    config: RalphConfig,
    client: APIClient,
    phase_title: str,
    log_dir: Path | None = None,
    progress: dict | None = None,
) -> None:
    """Create and run the ralph TUI app."""
    app = RalphTUIApp(config, client, phase_title, log_dir=log_dir, progress=progress)
    app.run()
