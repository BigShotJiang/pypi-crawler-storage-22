"""TUI display adapter for ralph — updates Textual widgets instead of printing."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from rich.text import Text

if TYPE_CHECKING:
    from mfbt.commands.ralph.tui_app import RalphTUIApp
    from mfbt.commands.ralph.types import (
        FeatureResult,
        FeatureTask,
        RalphConfig,
        SessionSummary,
    )


class RalphTUIDisplay:
    """Implements the same 8-method interface as RalphDisplay,
    but marshals updates to Textual widgets via app.call_from_thread().
    """

    def __init__(self, app: RalphTUIApp) -> None:
        self._app = app
        self._feature_num = 0
        self._phase_title = app.phase_title

    # -- Status summary (no-op in TUI — TUI auto-continues) ----------------

    def show_status(
        self,
        phase_title: str,
        progress: dict,
        config: "RalphConfig",
    ) -> None:
        """No-op: TUI path implicitly auto-continues."""

    # -- Session lifecycle ---------------------------------------------------

    def session_start(
        self,
        config: RalphConfig,
        phase_title: str,
        progress: dict,
    ) -> None:
        total = progress.get("total_features", 0)
        completed = progress.get("completed_features", 0)
        pending = progress.get("pending_features", 0)
        pct = progress.get("progress_percent", 0.0)

        def _update() -> None:
            from mfbt.commands.ralph.tui_app import RalphHeader, RalphStatusBar

            try:
                header = self._app.query_one("#ralph-header", RalphHeader)
                header.phase_title = self._phase_title
                header.agent_name = config.coding_agent.value
                header.mode = config.mode.value
                header.total_features = total
                header.completed = completed
                header.pending = pending
                header.progress_pct = pct
            except Exception:
                pass

            try:
                status_bar = self._app.query_one(
                    "#ralph-status-bar", RalphStatusBar
                )
                status_bar.pending = pending
            except Exception:
                pass

        self._app.call_from_thread(_update)

    def log_directory(self, path: Path) -> None:
        """Store the session log directory and write path to agent output log."""
        self._app.session_log_dir = path

        def _update() -> None:
            from mfbt.commands.ralph.tui_app import AgentOutputLog

            try:
                log = self._app.query_one("#agent-output", AgentOutputLog)
                log.write(Text.from_markup(f"[dim]Logs: {path}[/dim]"))
            except Exception:
                pass

        self._app.call_from_thread(_update)

    # -- Feature list ---------------------------------------------------------

    def populate_features(self, features: list[dict[str, str]]) -> None:
        """Pre-populate the feature table with all pending features."""

        def _update() -> None:
            from mfbt.commands.ralph.tui_app import FeatureProgressTable

            try:
                table = self._app.query_one(
                    "#feature-table", FeatureProgressTable
                )
                for i, f in enumerate(features, 1):
                    table.add_feature(
                        i, f["feature_key"], f["module_key"], f["title"]
                    )
            except Exception:
                pass

        self._app.call_from_thread(_update)

    # -- Feature lifecycle ---------------------------------------------------

    def feature_start(
        self,
        feature: FeatureTask,
        attempt: int,
        feature_num: int,
        total: int,
    ) -> None:
        self._feature_num = feature_num

        def _update() -> None:
            from mfbt.commands.ralph.tui_app import (
                AgentOutputLog,
                FeatureProgressTable,
            )

            # Tell the app which feature is running (drives glisten animation)
            self._app._running_feature_key = feature.feature_key
            self._app._glisten_frame = 0

            try:
                table = self._app.query_one(
                    "#feature-table", FeatureProgressTable
                )
                update_kwargs: dict = {
                    "status": "[cyan]\u27f3 running[/cyan]",
                }
                if attempt > 1:
                    update_kwargs["attempts"] = attempt
                table.update_feature(feature.feature_key, **update_kwargs)
            except Exception:
                pass

            try:
                log = self._app.query_one("#agent-output", AgentOutputLog)
                log.clear_log()
                log.write(
                    Text.from_markup(
                        f"[bold cyan]>>> {feature.feature_key}[/bold cyan]"
                        f" \u2014 {feature.title}"
                    )
                )
            except Exception:
                pass

        self._app.call_from_thread(_update)

    def agent_output(self, line: str) -> None:
        text = line.rstrip("\n")
        if not text:
            return

        def _update() -> None:
            from mfbt.commands.ralph.tui_app import AgentOutputLog

            try:
                log = self._app.query_one("#agent-output", AgentOutputLog)
                # Use Text() directly — do NOT parse agent output as markup,
                # since raw agent stdout can contain literal [/dim] etc.
                text_obj = Text(text)
                text_obj.stylize("dim")
                log.write(text_obj)
            except Exception:
                pass

        self._app.call_from_thread(_update)

    def feature_complete(self, result: FeatureResult) -> None:
        from mfbt.commands.ralph.types import FeatureOutcome

        fk = result.feature.feature_key
        elapsed = f"{result.elapsed_seconds:.0f}s"

        # Stop glisten animation
        self._app._running_feature_key = None

        if result.outcome == FeatureOutcome.SUCCESS:
            status_str = f"[green]\u2713 success[/green]"
        elif result.outcome == FeatureOutcome.FAILED:
            status_str = f"[red]\u2717 failed[/red]"
        else:
            status_str = f"[yellow]\u2013 skipped[/yellow]"

        def _update() -> None:
            from mfbt.commands.ralph.tui_app import (
                FeatureProgressTable,
                LogPaneHeader,
                RalphHeader,
                RalphStatusBar,
            )

            try:
                table = self._app.query_one(
                    "#feature-table", FeatureProgressTable
                )
                table.update_feature(
                    fk,
                    status=status_str,
                    time_str=elapsed,
                    attempts=result.attempts,
                )
            except Exception:
                pass

            # Clear log pane header
            try:
                lph = self._app.query_one("#log-pane-header", LogPaneHeader)
                lph.update("")
            except Exception:
                pass

            # Update status bar counts
            try:
                status_bar = self._app.query_one(
                    "#ralph-status-bar", RalphStatusBar
                )
                if result.outcome == FeatureOutcome.SUCCESS:
                    status_bar.succeeded += 1
                    status_bar.pending = max(0, status_bar.pending - 1)
                elif result.outcome == FeatureOutcome.FAILED:
                    status_bar.failed += 1
                    status_bar.pending = max(0, status_bar.pending - 1)
                else:
                    status_bar.pending = max(0, status_bar.pending - 1)
            except Exception:
                pass

            # Update header completed count
            try:
                header = self._app.query_one("#ralph-header", RalphHeader)
                if result.outcome == FeatureOutcome.SUCCESS:
                    header.completed += 1
                    header.pending = max(0, header.pending - 1)
                    if header.total_features > 0:
                        header.progress_pct = (
                            header.completed / header.total_features * 100
                        )
                else:
                    header.pending = max(0, header.pending - 1)
            except Exception:
                pass

        self._app.call_from_thread(_update)

    def feature_retry(
        self,
        feature: FeatureTask,
        attempt: int,
        max_attempts: int,
    ) -> None:
        def _update() -> None:
            from mfbt.commands.ralph.tui_app import (
                AgentOutputLog,
                FeatureProgressTable,
            )

            try:
                table = self._app.query_one(
                    "#feature-table", FeatureProgressTable
                )
                table.update_feature(
                    feature.feature_key,
                    status="[yellow]\u27f3 retry[/yellow]",
                    attempts=attempt,
                )
            except Exception:
                pass

            try:
                log = self._app.query_one("#agent-output", AgentOutputLog)
                log.write(
                    Text.from_markup(
                        f"[yellow]Retrying {feature.feature_key}"
                        f" (attempt {attempt}/{max_attempts})[/yellow]"
                    )
                )
            except Exception:
                pass

        self._app.call_from_thread(_update)

    # -- Session summary -----------------------------------------------------

    def session_summary(self, summary: SessionSummary) -> None:
        def _update() -> None:
            from mfbt.commands.ralph.tui_app import RalphHeader, RalphStatusBar

            try:
                header = self._app.query_one("#ralph-header", RalphHeader)
                header.session_state = "complete"
            except Exception:
                pass

            try:
                status_bar = self._app.query_one(
                    "#ralph-status-bar", RalphStatusBar
                )
                status_bar.succeeded = summary.succeeded
                status_bar.failed = summary.failed
                status_bar.pending = 0
                status_bar.elapsed_seconds = summary.total_elapsed_seconds
            except Exception:
                pass

        self._app.call_from_thread(_update)

    # -- Errors --------------------------------------------------------------

    def error(self, message: str) -> None:
        def _update() -> None:
            from mfbt.commands.ralph.tui_app import AgentOutputLog

            try:
                log = self._app.query_one("#agent-output", AgentOutputLog)
                log.write(Text.from_markup(f"[red]Error: {message}[/red]"))
            except Exception:
                pass

            try:
                self._app.notify(message, severity="error")
            except Exception:
                pass

        self._app.call_from_thread(_update)

    def warn(self, message: str) -> None:
        def _update() -> None:
            from mfbt.commands.ralph.tui_app import AgentOutputLog

            try:
                log = self._app.query_one("#agent-output", AgentOutputLog)
                log.write(Text.from_markup(f"[yellow]{message}[/yellow]"))
            except Exception:
                pass

        self._app.call_from_thread(_update)
