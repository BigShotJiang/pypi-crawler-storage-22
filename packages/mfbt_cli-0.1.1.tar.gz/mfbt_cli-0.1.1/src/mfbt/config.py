"""Configuration and .mfbt directory management.

Handles directory initialization, atomic persistence, configuration hierarchy
resolution, schema versioning with migrations, and corruption recovery.
"""

from __future__ import annotations

import json
import logging
import os
import shutil
import tempfile
from collections.abc import Callable
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from mfbt.platform import set_secure_dir_permissions, set_secure_file_permissions

logger = logging.getLogger("mfbt.config")

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

PROJECT_ROOT_MARKERS: tuple[str, ...] = (
    ".git",
    "pyproject.toml",
    "setup.py",
    "setup.cfg",
    ".mfbt",
    "Cargo.toml",
    "package.json",
    "go.mod",
)

MFBT_DIR = ".mfbt"
CURRENT_SCHEMA_VERSION = 1
VALID_FORMATS = frozenset({"table", "json", "plain"})

DEFAULT_CONFIG: dict[str, Any] = {
    "schema_version": CURRENT_SCHEMA_VERSION,
    "project_id": None,
    "base_url": "https://app.mfbt.ai",
    "default_format": "table",
    "page_size": 25,
    "cache_ttl": 300,
}

DEFAULT_AUTH: dict[str, Any] = {
    "access_token": None,
    "refresh_token": None,
    "token_type": "bearer",
    "expires_at": None,
    "issued_at": None,
}

# Environment variable -> config key mapping
ENV_VAR_MAP: dict[str, str] = {
    "MFBT_BASE_URL": "base_url",
    "MFBT_DEFAULT_FORMAT": "default_format",
    "MFBT_PAGE_SIZE": "page_size",
    "MFBT_PROJECT_ID": "project_id",
    "MFBT_CACHE_TTL": "cache_ttl",
}

# Config keys that need type conversion from env var strings
_ENV_VAR_TYPES: dict[str, type] = {
    "page_size": int,
    "cache_ttl": int,
}


# ---------------------------------------------------------------------------
# Migration registry
# ---------------------------------------------------------------------------


def _migrate_v0_to_v1(config: dict[str, Any]) -> dict[str, Any]:
    """Migrate from v0 (no schema_version) to v1.

    Adds schema_version, default_format, and page_size fields.
    """
    config["schema_version"] = 1
    config.setdefault("default_format", "table")
    config.setdefault("page_size", 25)
    config.setdefault("base_url", "https://app.mfbt.ai")
    config.setdefault("project_id", None)
    return config


# Source version -> migration function
MIGRATIONS: dict[int, Callable[[dict[str, Any]], dict[str, Any]]] = {
    0: _migrate_v0_to_v1,
}


def _run_migrations(config: dict[str, Any], from_version: int) -> dict[str, Any]:
    """Run sequential migrations from from_version to CURRENT_SCHEMA_VERSION."""
    current = from_version
    while current < CURRENT_SCHEMA_VERSION:
        migration_fn = MIGRATIONS.get(current)
        if migration_fn is None:
            logger.error("No migration path from v%d to v%d", current, current + 1)
            raise ValueError(
                f"No migration available from schema v{current} to v{current + 1}"
            )
        logger.info("Running config migration v%d -> v%d", current, current + 1)
        config = migration_fn(config)
        current += 1
    return config


# ---------------------------------------------------------------------------
# Backup management
# ---------------------------------------------------------------------------


def _create_migration_backup(
    mfbt_dir: Path, config: dict[str, Any], from_version: int
) -> Path:
    """Create a timestamped backup in .mfbt/backups/ before migration."""
    backup_dir = mfbt_dir / "backups"
    backup_dir.mkdir(exist_ok=True)
    set_secure_dir_permissions(backup_dir)

    timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    backup_name = f"config_v{from_version}_{timestamp}.json"
    backup_path = backup_dir / backup_name

    _atomic_write_json(backup_path, config)
    set_secure_file_permissions(backup_path)
    logger.info("Created migration backup: %s", backup_path)
    return backup_path


def _backup_corrupted_config(config_path: Path) -> Path | None:
    """Backup a corrupted config file before recreating it."""
    if not config_path.exists():
        return None
    backup_path = config_path.with_suffix(".json.backup")
    try:
        shutil.copy2(config_path, backup_path)
        set_secure_file_permissions(backup_path)
        logger.warning("Corrupted config backed up to %s", backup_path)
        return backup_path
    except OSError as exc:
        logger.error("Failed to backup corrupted config: %s", exc)
        return None


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------


def validate_config(config: dict[str, Any]) -> list[str]:
    """Validate configuration values. Returns list of warning messages."""
    errors: list[str] = []

    fmt = config.get("default_format")
    if fmt is not None and fmt not in VALID_FORMATS:
        errors.append(
            f"Invalid 'default_format' value '{fmt}'; "
            f"expected one of {sorted(VALID_FORMATS)}"
        )

    page_size = config.get("page_size")
    if page_size is not None and (not isinstance(page_size, int) or page_size < 1):
        errors.append(
            f"Invalid 'page_size' value '{page_size}'; " "expected a positive integer"
        )

    return errors


# ---------------------------------------------------------------------------
# Project root detection
# ---------------------------------------------------------------------------


def find_project_root(start: Path | None = None) -> Path | None:
    """Walk upward from start to find a project root directory.

    Args:
        start: Directory to start searching from. Defaults to cwd.

    Returns:
        The project root Path, or None if no markers found.
    """
    current = (start or Path.cwd()).resolve()
    for directory in [current, *current.parents]:
        for marker in PROJECT_ROOT_MARKERS:
            if (directory / marker).exists():
                return directory
    return None


# ---------------------------------------------------------------------------
# Directory initialization
# ---------------------------------------------------------------------------


def init_mfbt_dir(project_root: Path) -> Path:
    """Create and secure the .mfbt directory structure.

    Creates:
        .mfbt/
        .mfbt/cache/
        .mfbt/logs/
        .mfbt/backups/
        .mfbt/config.json  (with defaults if not present)
        .mfbt/auth.json    (with defaults if not present)

    Args:
        project_root: The project root to create .mfbt/ in.

    Returns:
        Path to the .mfbt directory.
    """
    mfbt_dir = project_root / MFBT_DIR

    mfbt_dir.mkdir(exist_ok=True)
    set_secure_dir_permissions(mfbt_dir)

    for subdir_name in ("cache", "logs", "backups"):
        subdir = mfbt_dir / subdir_name
        subdir.mkdir(exist_ok=True)
        set_secure_dir_permissions(subdir)

    config_path = mfbt_dir / "config.json"
    if not config_path.exists():
        _atomic_write_json(config_path, DEFAULT_CONFIG)
        set_secure_file_permissions(config_path)

    auth_path = mfbt_dir / "auth.json"
    if not auth_path.exists():
        _atomic_write_json(auth_path, DEFAULT_AUTH)
        set_secure_file_permissions(auth_path)

    logger.info("Initialized .mfbt directory at %s", mfbt_dir)
    return mfbt_dir


# ---------------------------------------------------------------------------
# Configuration loading with migration & corruption recovery
# ---------------------------------------------------------------------------


def load_config(project_root: Path) -> dict[str, Any]:
    """Load project configuration with automatic migration and validation.

    On first load, returns defaults. On corrupted files, backs up the
    corrupted file and recreates with defaults. On schema version mismatch,
    creates a timestamped backup and runs migrations.
    """
    config_path = project_root / MFBT_DIR / "config.json"
    return _load_config_with_migration(config_path)


def _load_config_with_migration(config_path: Path) -> dict[str, Any]:
    """Load config from path, handling corruption, migration, and validation."""
    # Step 1: Load raw JSON
    try:
        raw_text = config_path.read_text(encoding="utf-8")
        config: dict[str, Any] = json.loads(raw_text)
        if not isinstance(config, dict):
            raise ValueError("Config root must be a JSON object")
    except FileNotFoundError:
        logger.debug("Config not found at %s, using defaults", config_path)
        return dict(DEFAULT_CONFIG)
    except (json.JSONDecodeError, OSError, ValueError) as exc:
        logger.warning("Corrupted config at %s: %s", config_path, exc)
        _backup_corrupted_config(config_path)
        defaults = dict(DEFAULT_CONFIG)
        _atomic_write_json(config_path, defaults)
        set_secure_file_permissions(config_path)
        return defaults

    # Step 2: Migrate if schema version is outdated
    version = config.get("schema_version", 0)
    if not isinstance(version, int):
        version = 0

    if version > CURRENT_SCHEMA_VERSION:
        logger.warning(
            "Config schema v%d is newer than supported v%d; "
            "some settings may not be recognized",
            version,
            CURRENT_SCHEMA_VERSION,
        )
    elif version < CURRENT_SCHEMA_VERSION:
        mfbt_dir = config_path.parent
        _create_migration_backup(mfbt_dir, config, version)
        try:
            config = _run_migrations(config, version)
        except ValueError:
            logger.error("Migration failed; reverting to defaults")
            config = dict(DEFAULT_CONFIG)
        _atomic_write_json(config_path, config)
        set_secure_file_permissions(config_path)
        logger.info("Migrated config from v%d to v%d", version, CURRENT_SCHEMA_VERSION)

    # Step 3: Validate and warn
    for warning in validate_config(config):
        logger.warning("Config validation: %s", warning)

    return config


# ---------------------------------------------------------------------------
# Configuration hierarchy resolution
# ---------------------------------------------------------------------------


def _get_global_config_path() -> Path:
    """Get the path to the global user config file."""
    from mfbt.platform import get_platform_dirs

    return get_platform_dirs().config / "config.json"


def load_global_config() -> dict[str, Any]:
    """Load global user configuration from the platform config directory."""
    return _load_json(_get_global_config_path(), {})


def _resolve_env_overrides() -> dict[str, Any]:
    """Get configuration overrides from environment variables."""
    overrides: dict[str, Any] = {}
    for env_var, config_key in ENV_VAR_MAP.items():
        raw_value = os.environ.get(env_var)
        if raw_value is None:
            continue
        type_fn = _ENV_VAR_TYPES.get(config_key)
        if type_fn is not None:
            try:
                overrides[config_key] = type_fn(raw_value)
            except (ValueError, TypeError):
                logger.warning(
                    "Ignoring invalid %s value '%s' (expected %s)",
                    env_var,
                    raw_value,
                    type_fn.__name__,
                )
        else:
            overrides[config_key] = raw_value
    return overrides


def resolve_config(
    project_root: Path | None = None,
    cli_overrides: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Resolve configuration from all sources in priority order.

    Priority (highest to lowest):
        CLI flags > environment variables > project config > global config > defaults

    Each key is resolved independently through the hierarchy.
    """
    config = dict(DEFAULT_CONFIG)

    # Layer: global user config
    for key, value in load_global_config().items():
        if value is not None:
            config[key] = value

    # Layer: project-level config
    if project_root is not None:
        for key, value in load_config(project_root).items():
            if value is not None:
                config[key] = value

    # Layer: environment variables
    config.update(_resolve_env_overrides())

    # Layer: CLI flags (highest priority)
    if cli_overrides:
        for key, value in cli_overrides.items():
            if value is not None:
                config[key] = value

    return config


def get_config_value(
    key: str,
    project_root: Path | None = None,
    cli_overrides: dict[str, Any] | None = None,
) -> Any:
    """Get a single configuration value resolved through the hierarchy."""
    return resolve_config(project_root, cli_overrides).get(key, DEFAULT_CONFIG.get(key))


# ---------------------------------------------------------------------------
# Configuration saving
# ---------------------------------------------------------------------------


def save_config(project_root: Path, config: dict[str, Any]) -> None:
    """Save project configuration to .mfbt/config.json."""
    config.setdefault("schema_version", CURRENT_SCHEMA_VERSION)
    path = project_root / MFBT_DIR / "config.json"
    _atomic_write_json(path, config)
    set_secure_file_permissions(path)


# ---------------------------------------------------------------------------
# Auth management
# ---------------------------------------------------------------------------


def load_auth(project_root: Path) -> dict[str, Any]:
    """Load auth tokens from .mfbt/auth.json.

    Returns defaults if the file doesn't exist or is invalid.
    """
    return _load_json(project_root / MFBT_DIR / "auth.json", DEFAULT_AUTH)


def save_auth(project_root: Path, auth: dict[str, Any]) -> None:
    """Save auth tokens to .mfbt/auth.json."""
    path = project_root / MFBT_DIR / "auth.json"
    _atomic_write_json(path, auth)
    set_secure_file_permissions(path)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _load_json(path: Path, defaults: dict[str, Any]) -> dict[str, Any]:
    """Load JSON file, returning defaults on failure."""
    try:
        result: dict[str, Any] = json.loads(path.read_text(encoding="utf-8"))
        return result
    except (FileNotFoundError, json.JSONDecodeError, OSError) as exc:
        logger.debug("Could not load %s: %s. Using defaults.", path, exc)
        return dict(defaults)


def _atomic_write_json(path: Path, data: dict[str, Any]) -> None:
    """Write JSON atomically via temp file + rename."""
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_path_str = tempfile.mkstemp(dir=path.parent, prefix=".tmp_", suffix=".json")
    tmp_path = Path(tmp_path_str)
    try:
        with open(fd, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
            f.write("\n")
        tmp_path.replace(path)
    except BaseException:
        tmp_path.unlink(missing_ok=True)
        raise
