"""Error handling context manager for mfbt CLI commands.

Provides consistent error display and exit behavior across all commands.
Covers MCLI-060, MCLI-073 (structured resolution steps).
"""

from __future__ import annotations

import contextlib
import traceback
from collections.abc import Iterator, Sequence

import typer
from rich.console import Console

from mfbt.exceptions import (
    APIError,
    AuthenticationRequired,
    CircuitBreakerOpenError,
    NetworkError,
    NotFoundError,
    RateLimitExceeded,
    RetryExhaustedError,
    ServerError,
    TokenLimitExceeded,
    ValidationError,
)


def _print_structured_error(
    console: Console,
    what: str,
    why: str,
    resolution: Sequence[str],
) -> None:
    """Print a structured error with what happened, why, and how to fix it."""
    console.print(f"[red]Error:[/red] {what}")
    console.print(f"[yellow]Why:[/yellow] {why}")
    if resolution:
        console.print("[cyan]What to do:[/cyan]")
        for step in resolution:
            console.print(f"  - {step}")


@contextlib.contextmanager
def handle_errors(
    console: Console,
    *,
    verbose: bool = False,
) -> Iterator[None]:
    """Context manager that catches API/auth errors and prints user-friendly messages.

    Usage::

        with handle_errors(console, verbose=verbose):
            # command logic that may raise API exceptions
            ...
    """
    try:
        yield
    except AuthenticationRequired as exc:
        _print_structured_error(
            console,
            what=exc.user_message,
            why="Your credentials have expired or are missing.",
            resolution=["Run: [bold]mfbt auth login[/bold]"],
        )
        if verbose:
            _print_verbose(console, exc)
        raise typer.Exit(code=1) from exc
    except TokenLimitExceeded as exc:
        upgrade_url = "https://app.mfbt.ai/settings/billing"
        if isinstance(exc.response_body, dict):
            upgrade_url = exc.response_body.get("upgrade_url", upgrade_url)
        _print_structured_error(
            console,
            what=exc.user_message,
            why="Your plan's token allowance has been used up.",
            resolution=[
                f"Upgrade your plan at: [bold]{upgrade_url}[/bold]",
                "Use shorter prompts to reduce token usage",
                "Wait for your token limit to reset",
            ],
        )
        if verbose:
            _print_verbose(console, exc)
        raise typer.Exit(code=1) from exc
    except ValidationError as exc:
        console.print(f"[red]Error:[/red] {exc.user_message}")
        console.print("Run with [bold]--verbose[/bold] for details.")
        if verbose:
            _print_verbose(console, exc)
        raise typer.Exit(code=1) from exc
    except RateLimitExceeded as exc:
        wait_msg = "Wait a moment before retrying"
        if exc.retry_after is not None:
            wait_msg = f"Wait [bold]{exc.retry_after}[/bold] seconds before retrying"
        _print_structured_error(
            console,
            what=exc.user_message,
            why="Too many requests were sent in a short period.",
            resolution=[wait_msg],
        )
        if verbose:
            _print_verbose(console, exc)
        raise typer.Exit(code=1) from exc
    except ServerError as exc:
        _print_structured_error(
            console,
            what=exc.user_message,
            why="The server encountered an internal error.",
            resolution=[
                "Try again shortly",
                "If the problem persists, check server status",
            ],
        )
        if verbose:
            _print_verbose(console, exc)
        raise typer.Exit(code=1) from exc
    except NetworkError as exc:
        _print_structured_error(
            console,
            what=exc.user_message,
            why="The server could not be reached.",
            resolution=[
                "Check your internet connection",
                "Verify the server URL in your configuration",
                "Check proxy or firewall settings",
                "Try again later",
            ],
        )
        if verbose:
            _print_verbose(console, exc)
        raise typer.Exit(code=1) from exc
    except RetryExhaustedError as exc:
        console.print(f"[red]Error:[/red] {exc.user_message}")
        if exc.original is not None:
            console.print(f"Caused by: {exc.original}")
        _print_resolution(
            console,
            why="Multiple consecutive attempts have failed.",
            resolution=[
                "Check your internet connection",
                "Try again later",
            ],
        )
        if verbose:
            _print_verbose(console, exc)
        raise typer.Exit(code=1) from exc
    except CircuitBreakerOpenError as exc:
        _print_structured_error(
            console,
            what=exc.user_message,
            why="Multiple consecutive failures suggest the server may be down.",
            resolution=[
                "Wait a moment for the service to recover",
                "Check the server status",
            ],
        )
        if verbose:
            _print_verbose(console, exc)
        raise typer.Exit(code=1) from exc
    except NotFoundError as exc:
        _print_structured_error(
            console,
            what=exc.user_message,
            why="The resource may have been deleted or you may not have access.",
            resolution=[
                "Verify the resource ID or name",
                "Check your current project: [bold]mfbt status[/bold]",
            ],
        )
        if verbose:
            _print_verbose(console, exc)
        raise typer.Exit(code=1) from exc
    except APIError as exc:
        console.print(f"[red]Error:[/red] {exc.user_message}")
        console.print("Run with [bold]--verbose[/bold] for details.")
        if verbose:
            _print_verbose(console, exc)
        raise typer.Exit(code=1) from exc
    except Exception as exc:
        # Import here to avoid circular dependency
        from mfbt.auth import AuthError

        if isinstance(exc, AuthError):
            console.print(f"[red]Error:[/red] {exc}")
            raise typer.Exit(code=1) from exc
        raise


def _print_resolution(
    console: Console,
    why: str,
    resolution: Sequence[str],
) -> None:
    """Print why and resolution steps (used when Error: line is already printed)."""
    console.print(f"[yellow]Why:[/yellow] {why}")
    if resolution:
        console.print("[cyan]What to do:[/cyan]")
        for step in resolution:
            console.print(f"  - {step}")


def _print_verbose(console: Console, exc: APIError) -> None:
    """Print technical details in dim styling when verbose mode is enabled."""
    if exc.technical_details:
        console.print(f"[dim]Details: {exc.technical_details}[/dim]")
    if exc.response_body:
        console.print(f"[dim]Response: {exc.response_body}[/dim]")
    tb = "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))
    console.print(f"[dim]{tb}[/dim]")
