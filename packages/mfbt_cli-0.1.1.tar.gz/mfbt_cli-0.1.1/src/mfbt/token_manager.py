"""Token lifecycle management for mfbt CLI.

Provides TokenManager for expiration checking, automatic refresh with retry
logic, and user-friendly error handling. Covers features MCLI-044 (storage),
MCLI-045 (auto-refresh), MCLI-046 (failure handling), MCLI-047 (monitoring).
"""

from __future__ import annotations

import logging
import threading
import time
from collections.abc import Callable
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from mfbt.auth import (
    AuthError,
    TokenResponse,
)

logger = logging.getLogger("mfbt.token_manager")

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

REFRESH_BUFFER_MINUTES = 5
MAX_RETRIES = 3
INITIAL_RETRY_DELAY = 1.0
RETRY_BACKOFF_MULTIPLIER = 2.0

# User-facing error messages
MSG_SESSION_EXPIRED = "Your session has expired. Please run: mfbt auth login"
MSG_CREDENTIALS_INVALID = (
    "Authentication credentials are invalid. Please run: mfbt auth login"
)
MSG_NETWORK_ERROR = (
    "Unable to refresh authentication due to network issues. "
    "Please check your connection and try again."
)

# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------


class TokenError(AuthError):
    """Base exception for token management errors."""


class TokenExpiredError(TokenError):
    """Access token is expired and no refresh token is available."""

    def __init__(self, message: str = MSG_SESSION_EXPIRED) -> None:
        super().__init__(message)


class RefreshTokenExpiredError(TokenError):
    """Refresh token has expired or been revoked; must re-login."""

    def __init__(self, message: str = MSG_SESSION_EXPIRED) -> None:
        super().__init__(message)


class RefreshTokenInvalidError(TokenError):
    """Refresh token is invalid; must re-login."""

    def __init__(self, message: str = MSG_CREDENTIALS_INVALID) -> None:
        super().__init__(message)


class TokenRefreshNetworkError(TokenError):
    """Transient network failure during token refresh."""

    def __init__(self, message: str = MSG_NETWORK_ERROR) -> None:
        super().__init__(message)


# ---------------------------------------------------------------------------
# TokenManager
# ---------------------------------------------------------------------------


class TokenManager:
    """Manages OAuth token lifecycle: storage, expiry checks, and refresh."""

    def __init__(
        self,
        project_root: Path,
        base_url: str,
    ) -> None:
        self.project_root = project_root
        self.base_url = base_url

    def save_tokens(self, token_response: TokenResponse) -> None:
        """Save tokens to auth.json, preserving existing fields like client_id."""
        from mfbt.config import load_auth, save_auth

        # Load existing auth to preserve client_id and other fields
        auth_data = load_auth(self.project_root)
        auth_data["access_token"] = token_response.access_token
        auth_data["refresh_token"] = token_response.refresh_token
        auth_data["token_type"] = token_response.token_type
        auth_data["expires_at"] = token_response.expires_at
        auth_data["issued_at"] = (
            token_response.issued_at or datetime.now(timezone.utc).isoformat()
        )
        save_auth(self.project_root, auth_data)
        logger.info("Tokens saved via TokenManager")

    def load_tokens(self) -> dict[str, Any] | None:
        """Load tokens from auth.json. Returns None if no tokens stored."""
        from mfbt.config import load_auth

        auth = load_auth(self.project_root)
        if auth.get("access_token") is None:
            return None
        return auth

    def clear_tokens(self) -> None:
        """Clear stored tokens by resetting auth.json to defaults."""
        from mfbt.config import DEFAULT_AUTH, save_auth

        save_auth(self.project_root, dict(DEFAULT_AUTH))
        logger.info("Tokens cleared")

    def load_client_id(self) -> str | None:
        """Load the registered OAuth client_id from auth.json."""
        from mfbt.config import load_auth

        auth = load_auth(self.project_root)
        client_id = auth.get("client_id")
        return client_id if isinstance(client_id, str) and client_id else None

    def save_client_id(self, client_id: str) -> None:
        """Save the registered OAuth client_id to auth.json."""
        from mfbt.config import load_auth, save_auth

        auth = load_auth(self.project_root)
        auth["client_id"] = client_id
        save_auth(self.project_root, auth)
        logger.info("Client ID saved")

    def register_and_save_client(self, redirect_uris: list[str]) -> str:
        """Register a new OAuth client and cache the client_id.

        Args:
            redirect_uris: Redirect URIs including the actual callback port.

        Returns:
            The registered client_id.

        Raises:
            mfbt.auth.ClientRegistrationError: If registration fails.
        """
        from mfbt.auth import register_client

        registered = register_client(self.base_url, redirect_uris)
        self.save_client_id(registered.client_id)
        return registered.client_id

    def is_expired(self) -> bool:
        """Check if the access token has expired."""
        tokens = self.load_tokens()
        if tokens is None:
            return True
        expires_at = tokens.get("expires_at")
        if expires_at is None:
            return False
        try:
            expiry = datetime.fromisoformat(expires_at)
            return datetime.now(timezone.utc) >= expiry
        except (ValueError, TypeError):
            logger.warning("Invalid expires_at value: %s", expires_at)
            return True

    def needs_refresh(self) -> bool:
        """Check if the access token needs refreshing (< 5 min until expiry)."""
        tokens = self.load_tokens()
        if tokens is None:
            return True
        expires_at = tokens.get("expires_at")
        if expires_at is None:
            return False
        try:
            expiry = datetime.fromisoformat(expires_at)
            buffer = timedelta(minutes=REFRESH_BUFFER_MINUTES)
            return datetime.now(timezone.utc) >= (expiry - buffer)
        except (ValueError, TypeError):
            logger.warning("Invalid expires_at value: %s", expires_at)
            return True

    def refresh_tokens(self) -> TokenResponse:
        """Refresh the access token using the stored refresh token.

        Retries on transient network errors with exponential backoff.
        Raises immediately on permanent failures (HTTP 400/401).

        Returns:
            A new TokenResponse with fresh tokens.

        Raises:
            TokenExpiredError: No refresh token available.
            RefreshTokenExpiredError: Refresh token expired (HTTP 400 invalid_grant).
            RefreshTokenInvalidError: Refresh token invalid (HTTP 401).
            TokenRefreshNetworkError: Network errors after retries exhausted.
        """
        import httpx

        tokens = self.load_tokens()
        if tokens is None or not tokens.get("refresh_token"):
            raise TokenExpiredError()

        refresh_token = tokens["refresh_token"]
        client_id = self.load_client_id()
        if not client_id:
            raise TokenExpiredError(
                "No registered client ID found. Please run: mfbt auth login"
            )
        token_url = f"{self.base_url.rstrip('/')}/oauth/token"
        payload = {
            "grant_type": "refresh_token",
            "client_id": client_id,
            "refresh_token": refresh_token,
        }

        last_error: Exception | None = None
        delay = INITIAL_RETRY_DELAY

        for attempt in range(MAX_RETRIES):
            try:
                response = httpx.post(
                    token_url,
                    data=payload,
                    headers={"Content-Type": "application/x-www-form-urlencoded"},
                    timeout=30.0,
                )
            except httpx.HTTPError as exc:
                last_error = exc
                logger.warning(
                    "Token refresh network error (attempt %d/%d): %s",
                    attempt + 1,
                    MAX_RETRIES,
                    exc,
                )
                if attempt < MAX_RETRIES - 1:
                    time.sleep(delay)
                    delay *= RETRY_BACKOFF_MULTIPLIER
                continue

            # Permanent failure — don't retry
            if response.status_code == 400:
                try:
                    body = response.json()
                except Exception:
                    body = {}
                if body.get("error") == "invalid_grant":
                    raise RefreshTokenExpiredError()
                raise RefreshTokenExpiredError()

            if response.status_code == 401:
                raise RefreshTokenInvalidError()

            if response.status_code != 200:
                last_error = Exception(
                    f"Unexpected status {response.status_code}: {response.text}"
                )
                logger.warning(
                    "Token refresh unexpected status (attempt %d/%d): %d",
                    attempt + 1,
                    MAX_RETRIES,
                    response.status_code,
                )
                if attempt < MAX_RETRIES - 1:
                    time.sleep(delay)
                    delay *= RETRY_BACKOFF_MULTIPLIER
                continue

            # Success
            data = response.json()

            expires_at = data.get("expires_at")
            if expires_at is None and "expires_in" in data:
                expires_at = (
                    datetime.now(timezone.utc)
                    + timedelta(seconds=data["expires_in"])
                ).isoformat()

            issued_at = datetime.now(timezone.utc).isoformat()

            token_response = TokenResponse(
                access_token=data["access_token"],
                refresh_token=data.get("refresh_token", refresh_token),
                token_type=data.get("token_type", "bearer"),
                expires_at=expires_at,
                issued_at=issued_at,
            )
            self.save_tokens(token_response)
            logger.info("Tokens refreshed successfully")
            return token_response

        # All retries exhausted
        raise TokenRefreshNetworkError() from last_error

    def ensure_valid_token(self) -> str:
        """Ensure a valid access token is available, refreshing if needed.

        Returns:
            A valid access token string.

        Raises:
            TokenExpiredError: No tokens stored and no way to refresh.
            RefreshTokenExpiredError: Refresh token expired.
            RefreshTokenInvalidError: Refresh token invalid.
            TokenRefreshNetworkError: Network error during refresh.
        """
        tokens = self.load_tokens()
        if tokens is None:
            raise TokenExpiredError()

        if not self.needs_refresh():
            access_token: str = tokens["access_token"]
            return access_token

        # Token needs refresh
        token_response = self.refresh_tokens()
        return token_response.access_token

    def get_access_token(self) -> str:
        """Convenience alias for ensure_valid_token()."""
        return self.ensure_valid_token()


# ---------------------------------------------------------------------------
# BackgroundTokenMonitor (MCLI-072)
# ---------------------------------------------------------------------------

MONITOR_CHECK_INTERVAL = 60.0


class BackgroundTokenMonitor:
    """Daemon thread that periodically checks and refreshes tokens.

    Callbacks:
        on_refreshing: Called when a refresh attempt starts.
        on_refreshed: Called when tokens are successfully refreshed.
        on_refresh_failed: Called with the exception on permanent failure.
    """

    def __init__(
        self,
        token_manager: TokenManager,
        *,
        check_interval: float = MONITOR_CHECK_INTERVAL,
        on_refreshing: Callable[[], None] | None = None,
        on_refreshed: Callable[[], None] | None = None,
        on_refresh_failed: Callable[[Exception], None] | None = None,
    ) -> None:
        self._token_manager = token_manager
        self._check_interval = check_interval
        self._on_refreshing = on_refreshing
        self._on_refreshed = on_refreshed
        self._on_refresh_failed = on_refresh_failed
        self._stop_event = threading.Event()
        self._thread: threading.Thread | None = None

    @property
    def running(self) -> bool:
        return self._thread is not None and self._thread.is_alive()

    def start(self) -> None:
        """Start the background monitor. Idempotent — safe to call multiple times."""
        if self.running:
            return
        self._stop_event.clear()
        self._thread = threading.Thread(
            target=self._run,
            name="mfbt-token-monitor",
            daemon=True,
        )
        self._thread.start()
        logger.info("Background token monitor started")

    def stop(self) -> None:
        """Signal the monitor to stop and wait for it to finish."""
        self._stop_event.set()
        if self._thread is not None:
            self._thread.join(timeout=5.0)
            self._thread = None
        logger.info("Background token monitor stopped")

    def _run(self) -> None:
        """Monitor loop: check token freshness and refresh if needed."""
        while not self._stop_event.is_set():
            try:
                if self._token_manager.needs_refresh():
                    if self._on_refreshing is not None:
                        self._on_refreshing()
                    self._token_manager.refresh_tokens()
                    if self._on_refreshed is not None:
                        self._on_refreshed()
            except (RefreshTokenExpiredError, RefreshTokenInvalidError) as exc:
                # Permanent failure — notify and stop monitoring
                logger.warning("Token refresh permanent failure: %s", exc)
                if self._on_refresh_failed is not None:
                    self._on_refresh_failed(exc)
                return
            except TokenRefreshNetworkError:
                # Transient — log and keep monitoring
                logger.warning("Token refresh transient failure, will retry next cycle")
                if self._on_refreshed is not None:
                    self._on_refreshed()
            except Exception:
                logger.exception("Unexpected error in token monitor")
                if self._on_refreshed is not None:
                    self._on_refreshed()

            self._stop_event.wait(timeout=self._check_interval)
