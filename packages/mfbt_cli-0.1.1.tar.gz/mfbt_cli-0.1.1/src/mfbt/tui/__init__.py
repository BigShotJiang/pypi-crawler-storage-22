"""Interactive TUI for the mfbt CLI.

Provides launch_tui() as the entry point. Textual is only imported
when the TUI is actually launched, keeping the CLI startup fast.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

logger = logging.getLogger("mfbt.tui")


def _run_auth_flow(
    base_url: str,
    tm: Any,
    console: Any,
) -> bool:
    """Run the browser-based OAuth login flow.

    Returns True if authentication succeeded, False otherwise.
    """
    import webbrowser
    from urllib.parse import urlencode

    from mfbt.auth import (
        OAUTH_SCOPES,
        AuthError,
        AuthTimeoutError,
        ClientRegistrationError,
        TokenExchangeError,
        exchange_code_for_tokens,
        generate_pkce_params,
        start_callback_server,
        wait_for_callback,
    )

    pkce = generate_pkce_params()

    try:
        server, port = start_callback_server(pkce.state)
    except AuthError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        return False

    redirect_uri = f"http://127.0.0.1:{port}/callback"

    # Register OAuth client (RFC 7591 Dynamic Client Registration)
    console.print("Registering OAuth client...")
    try:
        client_id = tm.register_and_save_client([redirect_uri])
    except ClientRegistrationError as exc:
        server.server_close()
        console.print(f"[red]Error:[/red] {exc}")
        return False

    auth_params = {
        "client_id": client_id,
        "redirect_uri": redirect_uri,
        "code_challenge": pkce.code_challenge,
        "code_challenge_method": pkce.code_challenge_method,
        "response_type": "code",
        "state": pkce.state,
        "scope": OAUTH_SCOPES,
    }
    auth_url = f"{base_url.rstrip('/')}/oauth/authorize?{urlencode(auth_params)}"

    console.print("Opening browser for authentication...")
    webbrowser.open(auth_url)
    console.print(f"Waiting for callback (timeout: 120s)...\n")

    try:
        result = wait_for_callback(server, timeout=120)
    except AuthTimeoutError:
        console.print("[red]Error:[/red] Authentication timed out. Please try again.")
        return False
    except AuthError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        return False
    except KeyboardInterrupt:
        console.print("\nAuthentication cancelled.")
        return False
    finally:
        server.server_close()

    console.print("Exchanging authorization code for tokens...")
    try:
        token_response = exchange_code_for_tokens(
            base_url=base_url,
            code=result.code,
            code_verifier=pkce.code_verifier,
            redirect_uri=redirect_uri,
            client_id=client_id,
        )
    except TokenExchangeError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        return False

    tm.save_tokens(token_response)
    console.print("[green]Successfully authenticated![/green]\n")
    return True


def launch_tui(project_root: Path, config: dict[str, Any]) -> None:
    """Launch the interactive TUI application."""
    from mfbt.api_client import APIClient
    from mfbt.cache import ResponseCache
    from mfbt.token_manager import TokenManager
    from mfbt.tui.app import MFBTApp

    base_url = config.get("base_url", "https://app.mfbt.ai")
    tm = TokenManager(project_root, base_url)

    # Check if user is authenticated before starting the TUI
    if tm.load_tokens() is None:
        from rich.console import Console
        from rich.prompt import Confirm

        console = Console()
        console.print("\n[yellow]You are not authenticated.[/yellow]")
        console.print(
            "mfbt needs to open your browser to sign in.\n"
        )

        try:
            if not Confirm.ask("Open browser to authenticate?"):
                console.print(
                    "\nRun [bold]mfbt auth login[/bold] to authenticate later."
                )
                return
        except (KeyboardInterrupt, EOFError):
            console.print("\nExiting.")
            return

        console.print()
        if not _run_auth_flow(base_url, tm, console):
            return

    cache = ResponseCache(project_root / ".mfbt" / "cache")
    api_client = APIClient(base_url, tm, cache=cache)

    job_monitor = None
    try:
        from mfbt.job_monitor import JobMonitor

        job_monitor = JobMonitor(base_url, tm, api_client)
    except Exception:
        pass  # Graceful degradation if WebSocket deps unavailable

    app = MFBTApp(project_root, config, api_client, job_monitor)
    try:
        app.run()
    finally:
        if job_monitor:
            job_monitor.shutdown()
        api_client.close()
