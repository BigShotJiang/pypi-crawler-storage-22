"""Action registry for context-aware keybindings in the TUI.

Defines actions available at each navigation level and provides
a registry for querying which actions apply to the current context.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ActionDef:
    """A TUI action definition."""

    name: str
    shortcut: str
    description: str
    handler: str
    resource_types: frozenset[str] = frozenset()


class ActionRegistry:
    """Registry of actions, queryable by navigation level."""

    def __init__(self) -> None:
        self._global_actions: list[ActionDef] = []
        self._level_actions: dict[str, list[ActionDef]] = {}

    def register(self, action: ActionDef) -> None:
        """Register an action. Global if no resource_types, else per-level."""
        if not action.resource_types:
            self._global_actions.append(action)
        else:
            for rt in action.resource_types:
                self._level_actions.setdefault(rt, []).append(action)

    def get_global_actions(self) -> list[ActionDef]:
        """Return all global (level-independent) actions."""
        return list(self._global_actions)

    def get_actions(self, level: str) -> list[ActionDef]:
        """Return actions for a specific navigation level."""
        return list(self._level_actions.get(level, []))

    def get_all_actions(self, level: str) -> list[ActionDef]:
        """Return global actions plus level-specific actions."""
        return self.get_global_actions() + self.get_actions(level)


def _build_default_registry() -> ActionRegistry:
    """Build the default action registry with standard keybindings."""
    registry = ActionRegistry()

    # Global actions
    registry.register(
        ActionDef(
            name="quit",
            shortcut="q",
            description="Quit",
            handler="quit",
        )
    )
    registry.register(
        ActionDef(
            name="help",
            shortcut="?",
            description="Help",
            handler="show_help",
        )
    )
    registry.register(
        ActionDef(
            name="refresh",
            shortcut="r",
            description="Refresh",
            handler="refresh",
        )
    )

    # Project-level actions
    registry.register(
        ActionDef(
            name="open",
            shortcut="enter",
            description="Open project",
            handler="select_item",
            resource_types=frozenset({"projects"}),
        )
    )
    registry.register(
        ActionDef(
            name="describe",
            shortcut="d",
            description="Describe",
            handler="describe_item",
            resource_types=frozenset({"projects"}),
        )
    )

    # Module-level actions
    registry.register(
        ActionDef(
            name="open",
            shortcut="enter",
            description="Open features",
            handler="select_item",
            resource_types=frozenset({"modules"}),
        )
    )
    registry.register(
        ActionDef(
            name="describe",
            shortcut="d",
            description="Describe",
            handler="describe_item",
            resource_types=frozenset({"modules"}),
        )
    )

    # Feature-level actions
    registry.register(
        ActionDef(
            name="open_detail",
            shortcut="enter",
            description="Open detail",
            handler="open_detail",
            resource_types=frozenset({"features"}),
        )
    )
    registry.register(
        ActionDef(
            name="describe",
            shortcut="d",
            description="Describe",
            handler="describe_item",
            resource_types=frozenset({"features"}),
        )
    )

    return registry


DEFAULT_REGISTRY = _build_default_registry()
