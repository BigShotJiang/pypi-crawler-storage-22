"""Main Textual application for the mfbt TUI.

Uses a panel-swapping model: the chrome (K9sHeader, CommandBar,
StatusBar) stays mounted at all times. Content panels (project list, module
list, feature list) are swapped inside #main-content. Modal overlays (feature
detail, info modal, help) are pushed as ModalScreen on top.
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Any

from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Container

from mfbt.tui.data_provider import TUIDataProvider
from mfbt.tui.navigation import NavigationItem, NavigationLevel, NavigationState
from mfbt.tui.widgets.command_bar import CommandBar
from mfbt.tui.widgets.k9s_header import K9sHeader
from mfbt.tui.widgets.status_bar import StatusBar

if TYPE_CHECKING:
    from mfbt.api_client import APIClient
    from mfbt.job_monitor import JobMonitor
    from mfbt.websocket_types import TransportMode


# Hints per navigation level
_LEVEL_HINTS: dict[NavigationLevel, tuple[tuple[str, str], ...]] = {
    NavigationLevel.PROJECTS: (
        ("q", "Quit"),
        ("?", "Help"),
        ("r", "Refresh"),
        ("enter", "Open"),
        ("d", "Describe"),
    ),
    NavigationLevel.MODULES: (
        ("q", "Quit"),
        ("?", "Help"),
        ("r", "Refresh"),
        ("enter", "Open"),
        ("d", "Describe"),
        ("esc", "Back"),
    ),
    NavigationLevel.FEATURES: (
        ("q", "Quit"),
        ("?", "Help"),
        ("r", "Refresh"),
        ("enter", "Detail"),
        ("d", "Describe"),
        ("esc", "Back"),
    ),
}


class MFBTApp(App):
    """K9S-style interactive TUI for the mfbt platform."""

    CSS_PATH = "app.tcss"
    TITLE = "mfbt"

    BINDINGS = [
        Binding("q", "quit", "Quit", priority=True),
        Binding("question_mark", "show_help", "Help", show=False),
        Binding("escape", "go_back", "Back", show=False),
        Binding("backspace", "go_back", "Back", show=False),
        Binding("r", "refresh", "Refresh", show=False),
        Binding("d", "describe", "Describe", show=False),
    ]

    def __init__(
        self,
        project_root: Path,
        config: dict[str, Any],
        api_client: APIClient,
        job_monitor: JobMonitor | None = None,
    ) -> None:
        super().__init__()
        self.project_root = project_root
        self.config = config
        self.api_client = api_client
        self.job_monitor = job_monitor
        self.data_provider = TUIDataProvider(api_client)
        self.nav_state = NavigationState()
        self._token_monitor: Any = None

    def compose(self) -> ComposeResult:
        yield K9sHeader(id="k9s-header")
        yield Container(id="main-content")
        yield CommandBar(id="command-bar")
        yield StatusBar(id="status-bar")

    def on_mount(self) -> None:
        self._show_project_list()
        self._update_nav_display()

        # Wire up transport change callback
        if self.job_monitor is not None:
            original_cb = self.job_monitor._on_transport_change

            def _on_transport(mode: TransportMode) -> None:
                if original_cb is not None:
                    original_cb(mode)
                self.call_from_thread(self._update_transport, mode)

            self.job_monitor._on_transport_change = _on_transport

        # Start background token monitor
        self._start_token_monitor()

    # ---- Content panel swapping ----------------------------------------

    def _clear_main_content(self) -> None:
        """Remove all children from #main-content."""
        container = self.query_one("#main-content", Container)
        container.remove_children()

    def _show_project_list(self) -> None:
        """Mount the project list panel."""
        from mfbt.tui.screens.project_list import ProjectListPanel

        self._clear_main_content()
        container = self.query_one("#main-content", Container)
        container.mount(ProjectListPanel(self.data_provider))

    def _show_module_list(
        self,
        project_id: str,
        project_name: str,
        project_key: str,
        project_metadata: dict[str, Any],
    ) -> None:
        """Mount the module list panel for a project."""
        from mfbt.tui.screens.module_list import ModuleListPanel

        self._clear_main_content()
        container = self.query_one("#main-content", Container)
        container.mount(
            ModuleListPanel(
                data_provider=self.data_provider,
                project_id=project_id,
                project_name=project_name,
                project_key=project_key,
                project_metadata=project_metadata,
            )
        )

    def _show_feature_list(
        self,
        project_id: str,
        project_name: str,
        project_key: str,
        project_metadata: dict[str, Any],
        module_id: str,
        module_name: str,
        module_key: str,
        module_metadata: dict[str, Any],
    ) -> None:
        """Mount the feature list panel for a module."""
        from mfbt.tui.screens.feature_list import FeatureListPanel

        self._clear_main_content()
        container = self.query_one("#main-content", Container)
        container.mount(
            FeatureListPanel(
                data_provider=self.data_provider,
                project_id=project_id,
                project_name=project_name,
                module_id=module_id,
                module_name=module_name,
                module_key=module_key,
                module_metadata=module_metadata,
            )
        )

    # ---- Message handlers from content panels --------------------------

    def on_project_list_panel_project_selected(
        self, event: Any
    ) -> None:
        """Handle project selection: navigate to modules."""
        data = event.data
        project_id = data.get("id", "")
        project_name = data.get("name", "Unknown")
        project_key = data.get("key", data.get("short_url_id", ""))
        tech_stack = data.get("tech_stack", "")
        if isinstance(tech_stack, list):
            tech_stack = ", ".join(tech_stack[:3])

        project_metadata = {
            "tech_stack": tech_stack,
            "status": data.get("status", ""),
            "description": data.get("description", ""),
        }

        # Push nav state
        self.nav_state.drill_down(
            NavigationItem(
                id=project_id,
                name=project_name,
                level=NavigationLevel.PROJECTS,
                key=project_key,
                metadata=project_metadata,
            )
        )

        self._show_module_list(project_id, project_name, project_key, project_metadata)
        self._update_nav_display()

    def on_module_list_panel_module_selected(
        self, event: Any
    ) -> None:
        """Handle module selection: navigate to features."""
        data = event.data
        module_id = data.get("id", "")
        module_name = data.get("title", data.get("name", "Unknown"))
        module_key = data.get("module_key", data.get("key", ""))
        feature_count = data.get("feature_count", 0)

        module_metadata = {
            "feature_count": feature_count or 0,
        }

        # The project info is carried in the event
        project_id = event.project_id
        project_name = event.project_name
        project_key = event.project_key
        project_metadata = event.project_metadata

        # Push nav state
        self.nav_state.drill_down(
            NavigationItem(
                id=module_id,
                name=module_name,
                level=NavigationLevel.MODULES,
                key=module_key,
                metadata=module_metadata,
            )
        )

        self._show_feature_list(
            project_id=project_id,
            project_name=project_name,
            project_key=project_key,
            project_metadata=project_metadata,
            module_id=module_id,
            module_name=module_name,
            module_key=module_key,
            module_metadata=module_metadata,
        )
        self._update_nav_display()

    def on_feature_list_panel_feature_selected(
        self, event: Any
    ) -> None:
        """Handle feature selection: open detail modal."""
        from mfbt.tui.screens.feature_detail import FeatureDetailScreen

        feature_id = event.data.get("id", "")
        self.push_screen(
            FeatureDetailScreen(
                data_provider=self.data_provider,
                feature_id=feature_id,
                feature_data=event.data,
            )
        )

    # ---- Describe handlers from content panels -------------------------

    def _handle_describe(self, data: dict[str, Any] | None, resource_type: str) -> None:
        """Open info modal for the given resource."""
        if data:
            from mfbt.tui.screens.info_modal import InfoModal

            self.push_screen(InfoModal(data=data, resource_type=resource_type))

    # ---- Navigation actions -------------------------------------------

    def action_go_back(self) -> None:
        """Navigate back one level."""
        level = self.nav_state.level
        if level == NavigationLevel.PROJECTS:
            return  # Already at root, do nothing
        elif level == NavigationLevel.MODULES:
            self.nav_state.go_up()
            self._show_project_list()
        elif level == NavigationLevel.FEATURES:
            self.nav_state.go_up()
            # Restore module list
            if self.nav_state.stack:
                proj = self.nav_state.stack[0]
                self._show_module_list(
                    project_id=proj.id,
                    project_name=proj.name,
                    project_key=proj.key,
                    project_metadata=proj.metadata,
                )
        self._update_nav_display()

    def action_refresh(self) -> None:
        """Refresh the current content panel."""
        from mfbt.tui.screens.feature_list import FeatureListPanel
        from mfbt.tui.screens.module_list import ModuleListPanel
        from mfbt.tui.screens.project_list import ProjectListPanel

        container = self.query_one("#main-content", Container)
        for child in container.children:
            if isinstance(child, (ProjectListPanel, ModuleListPanel, FeatureListPanel)):
                child.refresh_data()
                break

    def action_describe(self) -> None:
        """Show info modal for the selected item."""
        from mfbt.tui.screens.feature_list import FeatureListPanel
        from mfbt.tui.screens.module_list import ModuleListPanel
        from mfbt.tui.screens.project_list import ProjectListPanel

        container = self.query_one("#main-content", Container)
        for child in container.children:
            if isinstance(child, ProjectListPanel):
                self._handle_describe(child.get_selected_data(), "project")
                return
            if isinstance(child, ModuleListPanel):
                self._handle_describe(child.get_selected_data(), "module")
                return
            if isinstance(child, FeatureListPanel):
                self._handle_describe(child.get_selected_data(), "feature")
                return

    # ---- Token monitor -------------------------------------------------

    def _start_token_monitor(self) -> None:
        """Start the background token refresh monitor."""
        from mfbt.token_manager import BackgroundTokenMonitor

        self._token_monitor = BackgroundTokenMonitor(
            self.api_client.token_manager,
            on_refreshing=lambda: self.call_from_thread(self._on_token_refreshing),
            on_refreshed=lambda: self.call_from_thread(self._on_token_refreshed),
            on_refresh_failed=lambda exc: self.call_from_thread(
                self._on_token_refresh_failed, exc
            ),
        )
        self._token_monitor.start()

    def _on_token_refreshing(self) -> None:
        try:
            status_bar = self.query_one("#status-bar", StatusBar)
            status_bar.refreshing = True
        except Exception:
            pass

    def _on_token_refreshed(self) -> None:
        try:
            status_bar = self.query_one("#status-bar", StatusBar)
            status_bar.refreshing = False
        except Exception:
            pass

    def _on_token_refresh_failed(self, exc: Exception) -> None:
        try:
            status_bar = self.query_one("#status-bar", StatusBar)
            status_bar.refreshing = False
        except Exception:
            pass
        self.notify(
            "Session expired. Please re-authenticate: mfbt auth login",
            severity="error",
        )

    def _update_transport(self, mode: TransportMode) -> None:
        try:
            status_bar = self.query_one("#status-bar", StatusBar)
            status_bar.transport = mode
        except Exception:
            pass

    # ---- Display updates -----------------------------------------------

    def on_resize(self) -> None:
        if self.size.width < 80:
            self.add_class("narrow")
        else:
            self.remove_class("narrow")

    async def action_quit(self) -> None:
        if self._token_monitor is not None:
            self._token_monitor.stop()
        await super().action_quit()

    def action_show_help(self) -> None:
        from mfbt.tui.screens.help_screen import HelpScreen

        self.push_screen(HelpScreen())

    def _update_nav_display(self) -> None:
        """Update breadcrumb, header, command bar, and status bar from nav state."""
        # Command bar hints
        try:
            command_bar = self.query_one("#command-bar", CommandBar)
            command_bar.hints = _LEVEL_HINTS.get(
                self.nav_state.level,
                _LEVEL_HINTS[NavigationLevel.PROJECTS],
            )
        except Exception:
            pass

        # K9s header context
        try:
            header = self.query_one("#k9s-header", K9sHeader)
            header.breadcrumb = self.nav_state.breadcrumb_path_rich
            level = self.nav_state.level
            header.context_level = level.value

            if level == NavigationLevel.PROJECTS:
                header.project_name = ""
                header.project_key = ""
            elif level == NavigationLevel.MODULES and self.nav_state.stack:
                item = self.nav_state.stack[0]
                header.project_name = item.name
                header.project_key = item.key
                header.tech_stack = item.metadata.get("tech_stack", "")
                header.status = item.metadata.get("status", "")
                header.phase_name = item.metadata.get("phase_name", "")
            elif level == NavigationLevel.FEATURES and len(self.nav_state.stack) >= 2:
                proj = self.nav_state.stack[0]
                mod = self.nav_state.stack[1]
                header.project_name = proj.name
                header.project_key = proj.key
                header.module_name = mod.name
                header.feature_count = mod.metadata.get("feature_count", 0)
                header.completion_pct = mod.metadata.get("completion_pct", 0.0)
        except Exception:
            pass

        # Status bar resource type
        try:
            status_bar = self.query_one("#status-bar", StatusBar)
            level = self.nav_state.level
            if level == NavigationLevel.PROJECTS:
                status_bar.resource_type = "Projects"
            elif level == NavigationLevel.MODULES:
                status_bar.resource_type = "Modules"
            elif level == NavigationLevel.FEATURES:
                status_bar.resource_type = "Features"
        except Exception:
            pass
