"""Help screen (modal overlay) for the TUI."""

from __future__ import annotations

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Container
from textual.screen import ModalScreen
from textual.widgets import Label, Static

from mfbt.tui.actions import DEFAULT_REGISTRY


class HelpScreen(ModalScreen):
    """Modal overlay showing keybinding reference."""

    BINDINGS = [
        Binding("escape", "dismiss", "Close", show=False),
        Binding("question_mark", "dismiss", "Close", show=False),
    ]

    def compose(self) -> ComposeResult:
        with Container(id="help-container"):
            yield Label("[bold #326CE5]Keyboard Shortcuts[/bold #326CE5]\n")
            yield Static(self._build_help_text())

    def _build_help_text(self) -> str:
        lines: list[str] = []

        lines.append("[bold]Global[/bold]")
        for action in DEFAULT_REGISTRY.get_global_actions():
            lines.append(
                f"  [bold #326CE5]{action.shortcut:>10}[/bold #326CE5]  "
                f"{action.description}"
            )

        for level in ("projects", "modules", "features"):
            actions = DEFAULT_REGISTRY.get_actions(level)
            if actions:
                lines.append(f"\n[bold]{level.title()}[/bold]")
                for action in actions:
                    lines.append(
                        f"  [bold #326CE5]{action.shortcut:>10}[/bold #326CE5]  "
                        f"{action.description}"
                    )

        lines.append("\n[bold]Navigation[/bold]")
        lines.append("  [bold #326CE5]     j / \u2193[/bold #326CE5]  Move down")
        lines.append("  [bold #326CE5]     k / \u2191[/bold #326CE5]  Move up")
        lines.append("  [bold #326CE5]     g / G[/bold #326CE5]  Top / Bottom")
        lines.append("  [bold #326CE5]     enter[/bold #326CE5]  Select / drill down")
        lines.append("  [bold #326CE5]       esc[/bold #326CE5]  Go back / close")

        lines.append("\n[bold]Detail Views[/bold]")
        lines.append("  [bold #326CE5]       1-5[/bold #326CE5]  Switch tabs")
        lines.append("  [bold #326CE5]         d[/bold #326CE5]  Describe (info)")

        return "\n".join(lines)
