"""Module list panel for the TUI.

A Widget that mounts inside #main-content, not a pushed Screen.
This keeps the chrome (header, breadcrumb, command bar, status bar) visible.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

from textual.app import ComposeResult
from textual.message import Message
from textual.widget import Widget
from textual.widgets import Label

from mfbt.tui.widgets.resource_table import ResourceTable

if TYPE_CHECKING:
    from mfbt.tui.data_provider import TUIDataProvider

logger = logging.getLogger("mfbt.tui.screens.module_list")

_COLUMNS: list[tuple[str, str]] = [
    ("key", "KEY"),
    ("name", "NAME"),
    ("features", "FEATURES"),
    ("type", "TYPE"),
    ("provenance", "PROVENANCE"),
    ("source_phase", "SOURCE PHASE"),
]


def _format_module_row(data: dict[str, Any]) -> tuple[str, ...]:
    """Format a module dict into table cells."""
    key = data.get("module_key", data.get("key", ""))
    name = data.get("title", data.get("name", "Unnamed"))
    feature_count = data.get("feature_count", "")
    mod_type = data.get("type", "")
    provenance = data.get("provenance", "")
    source_phase = data.get("source_phase_title", data.get("source_phase", ""))
    return (
        f"[dim]{key}[/dim]",
        f"[bold]{name}[/bold]",
        str(feature_count) if feature_count else "[dim]-[/dim]",
        str(mod_type) if mod_type else "[dim]-[/dim]",
        str(provenance) if provenance else "[dim]-[/dim]",
        str(source_phase) if source_phase else "[dim]-[/dim]",
    )


class ModuleListPanel(Widget):
    """Content panel showing modules for a selected project."""

    class ModuleSelected(Message):
        """Fired when a module is selected."""

        def __init__(
            self,
            data: dict[str, Any],
            project_id: str,
            project_name: str,
            project_key: str,
            project_metadata: dict[str, Any],
        ) -> None:
            super().__init__()
            self.data = data
            self.project_id = project_id
            self.project_name = project_name
            self.project_key = project_key
            self.project_metadata = project_metadata

    class DescribeRequested(Message):
        """Fired when describe is requested on a module."""

        def __init__(self, data: dict[str, Any]) -> None:
            super().__init__()
            self.data = data

    def __init__(
        self,
        data_provider: TUIDataProvider,
        project_id: str,
        project_name: str,
        project_key: str = "",
        project_metadata: dict[str, Any] | None = None,
    ) -> None:
        super().__init__()
        self._data_provider = data_provider
        self.project_id = project_id
        self.project_name = project_name
        self.project_key = project_key
        self.project_metadata = project_metadata or {}

    def compose(self) -> ComposeResult:
        yield Label(
            f" [bold #326CE5]Modules[/bold #326CE5] [dim]— {self.project_name}[/dim]",
            id="screen-title",
        )
        yield ResourceTable(id="resource-table")

    def on_mount(self) -> None:
        self._load_data()
        self.query_one("#resource-table", ResourceTable).focus()

    def _load_data(self) -> None:
        self.run_worker(self._fetch_and_display, thread=True)

    def _fetch_and_display(self) -> None:
        try:
            page = self._data_provider.fetch_modules(self.project_id)
            table = self.query_one("#resource-table", ResourceTable)
            self.app.call_from_thread(
                table.set_rows, page.items, _COLUMNS, _format_module_row
            )
            self.app.call_from_thread(setattr, table, "has_more", page.has_more)
            self._update_status_count(page.total)
        except Exception as exc:
            logger.exception("Failed to fetch modules")
            self.app.call_from_thread(
                self.app.notify,
                f"Failed to load modules: {exc}",
                severity="error",
            )

    def _update_status_count(self, count: int) -> None:
        try:
            from mfbt.tui.widgets.status_bar import StatusBar

            status_bar = self.app.query_one("#status-bar", StatusBar)
            self.app.call_from_thread(setattr, status_bar, "resource_count", count)
        except Exception:
            pass

    def on_resource_table_resource_selected(
        self, event: ResourceTable.ResourceSelected
    ) -> None:
        self.post_message(
            self.ModuleSelected(
                data=event.data,
                project_id=self.project_id,
                project_name=self.project_name,
                project_key=self.project_key,
                project_metadata=self.project_metadata,
            )
        )

    def refresh_data(self) -> None:
        """Reload data from the API."""
        self._load_data()

    def get_selected_data(self) -> dict[str, Any] | None:
        """Return the data for the currently highlighted row."""
        try:
            table = self.query_one("#resource-table", ResourceTable)
            return table.get_selected_data()
        except Exception:
            return None
