"""Status bar widget for the TUI.

Shows resource type/count, completion %, connection status, and timestamp.
Absorbs the functionality of the old ConnectionIndicator.
"""

from __future__ import annotations

from textual.reactive import reactive
from textual.widgets import Static

from mfbt.websocket_types import TransportMode


class StatusBar(Static):
    """Bottom status bar showing resource count and connection info."""

    resource_type: reactive[str] = reactive("Projects")
    resource_count: reactive[int] = reactive(0)
    completion_pct: reactive[float] = reactive(0.0)
    transport: reactive[TransportMode] = reactive(TransportMode.NONE)
    refreshing: reactive[bool] = reactive(False)

    def render(self) -> str:
        parts: list[str] = []

        # Resource info
        if self.resource_count > 0:
            parts.append(
                f"[bold]{self.resource_type}[/bold] ({self.resource_count})"
            )
        else:
            parts.append(f"[bold]{self.resource_type}[/bold]")

        # Completion percentage
        if self.completion_pct > 0:
            parts.append(f"[dim]{self.completion_pct:.0%} complete[/dim]")

        # Spacer
        left = "  ".join(parts)

        # Connection indicator (right-aligned)
        if self.refreshing:
            conn = "[cyan]\u21bb Refreshing...[/cyan]"
        elif self.transport == TransportMode.WEBSOCKET:
            conn = "[green]\u25cf Live[/green]"
        elif self.transport == TransportMode.POLLING:
            conn = "[yellow]\u25cf Polling[/yellow]"
        else:
            conn = "[dim]\u25cf Offline[/dim]"

        return f" {left}{'':>4}{conn}"

    def _trigger_update(self) -> None:
        self.update(self.render())

    def watch_resource_type(self, value: str) -> None:
        self._trigger_update()

    def watch_resource_count(self, value: int) -> None:
        self._trigger_update()

    def watch_completion_pct(self, value: float) -> None:
        self._trigger_update()

    def watch_transport(self, value: TransportMode) -> None:
        self._trigger_update()

    def watch_refreshing(self, value: bool) -> None:
        self._trigger_update()
