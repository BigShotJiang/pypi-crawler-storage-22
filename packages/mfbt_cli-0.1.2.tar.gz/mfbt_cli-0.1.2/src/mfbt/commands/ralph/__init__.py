"""Ralph subcommand — auto-invoke coding agents for feature implementation."""

from __future__ import annotations

import logging
from typing import Any, Optional

import typer
from rich.console import Console

from mfbt.error_handler import handle_errors

logger = logging.getLogger("mfbt.commands.ralph")
console = Console()

ralph_app = typer.Typer(
    name="ralph",
    help="Auto-invoke coding agents to implement pending features",
    invoke_without_command=True,
)


# ---------------------------------------------------------------------------
# Helpers (same pattern as projects.py)
# ---------------------------------------------------------------------------


def _get_api_client(ctx: typer.Context) -> Any:
    """Build an APIClient from ctx.obj."""
    from mfbt.api_client import APIClient
    from mfbt.token_manager import TokenManager

    obj = ctx.obj
    project_root = obj["project_root"]
    config = obj["config"]
    base_url = config.get("base_url", "https://app.mfbt.ai")

    tm = TokenManager(project_root, base_url)
    return APIClient(base_url, tm, cache=None)


def _require_project_root(ctx: typer.Context) -> None:
    """Exit if no project root found."""
    if ctx.obj.get("project_root") is None:
        console.print(
            "[red]Error:[/red] Could not find a project root. "
            "Run this command from within a project directory."
        )
        raise typer.Exit(code=1)


# ---------------------------------------------------------------------------
# Command
# ---------------------------------------------------------------------------

SUPPORTED_AGENTS = ("claude",)


@ralph_app.callback(invoke_without_command=True)
def ralph(
    ctx: typer.Context,
    coding_agent: str = typer.Option(
        ...,
        "--coding-agent",
        help="Coding agent to use (e.g. 'claude')",
    ),
    max_turns: Optional[int] = typer.Option(
        None,
        "--max-turns",
        help="Maximum agent conversation turns (passed through to agent CLI)",
    ),
    mode: str = typer.Option(
        "feature-by-feature",
        "--mode",
        help="Orchestration mode: 'feature-by-feature' or 'module-by-module'",
    ),
    phase: Optional[str] = typer.Option(
        None,
        "--phase",
        help="Phase ID, short_id, or url_identifier (auto-detected if only one exists)",
    ),
    quiet: bool = typer.Option(
        False,
        "--quiet",
        "-q",
        help="Suppress live output; only show errors and final summary",
    ),
    tui: bool = typer.Option(
        False,
        "--tui",
        help="Launch interactive TUI mode with real-time progress display",
    ),
    yes: bool = typer.Option(
        False,
        "--yes",
        "-y",
        help="Skip confirmation prompt and start immediately",
    ),
    status: bool = typer.Option(
        False,
        "--status",
        help="Show progress status and exit without implementing",
    ),
) -> None:
    """Auto-invoke coding agents to implement pending features."""
    from mfbt.commands.ralph.agent import AgentNotFoundError
    from mfbt.commands.ralph.display import RalphDisplay
    from mfbt.commands.ralph.orchestrator import RalphOrchestrator
    from mfbt.commands.ralph.progress import get_phase_progress, resolve_phase_id
    from mfbt.commands.ralph.types import AgentType, OrchestrationMode, RalphConfig

    if tui and quiet:
        console.print(
            "[red]Error:[/red] --tui and --quiet are mutually exclusive."
        )
        raise typer.Exit(code=1)

    if status and (tui or quiet or yes):
        console.print(
            "[red]Error:[/red] --status is mutually exclusive with --tui, --quiet, and --yes."
        )
        raise typer.Exit(code=1)

    _require_project_root(ctx)
    obj = ctx.obj
    verbose = obj.get("verbose", False)
    config = obj["config"]
    project_id = config.get("project_id")

    if project_id is None:
        console.print(
            "[red]Error:[/red] No project configured. "
            "Run [bold]mfbt projects switch <project>[/bold] first."
        )
        raise typer.Exit(code=1)

    # Validate coding agent
    if coding_agent not in SUPPORTED_AGENTS:
        console.print(
            f"[red]Error:[/red] Agent '{coding_agent}' is not yet supported. "
            f"Supported agents: {', '.join(SUPPORTED_AGENTS)}"
        )
        raise typer.Exit(code=1)
    agent_type = AgentType(coding_agent)

    # Validate orchestration mode
    try:
        orch_mode = OrchestrationMode(mode)
    except ValueError:
        console.print(
            f"[red]Error:[/red] Invalid mode '{mode}'. "
            f"Choose from: feature-by-feature, module-by-module"
        )
        raise typer.Exit(code=1)

    base_url = config.get("base_url", "https://app.mfbt.ai")

    display = RalphDisplay(console, quiet=quiet)

    with handle_errors(console, verbose=verbose):
        client = _get_api_client(ctx)
        try:
            # Resolve phase
            try:
                phase_id, phase_title = resolve_phase_id(client, project_id, phase)
            except (SystemExit, typer.Exit):
                if phase is not None:
                    display.error(
                        f"Phase '{phase}' not found. "
                        "Check the phase ID, short_id, or url_identifier."
                    )
                else:
                    # Could be zero or multiple phases
                    resp = client.get(
                        f"/api/v1/projects/{project_id}/brainstorming-phases"
                    )
                    phases = resp.body if isinstance(resp.body, list) else []
                    active = [p for p in phases if p.get("archived_at") is None]
                    if len(active) == 0:
                        display.error("No active brainstorming phases found.")
                    else:
                        display.error(
                            "Multiple active phases found. "
                            "Use --phase to specify which one:"
                        )
                        for p in active:
                            console.print(
                                f"  {p.get('short_id', '')} — {p.get('title', '')}"
                            )
                raise typer.Exit(code=1)

            ralph_config = RalphConfig(
                project_id=project_id,
                phase_id=phase_id,
                coding_agent=agent_type,
                mode=orch_mode,
                max_turns=max_turns,
                quiet=quiet,
                base_url=base_url,
            )

            # Fetch progress and show status summary
            progress = get_phase_progress(client, phase_id)

            if not tui:
                display.show_status(phase_title, progress, ralph_config)

            if status:
                raise typer.Exit(code=0)

            if not yes and not tui:
                typer.confirm("Continue?", abort=True)

            from mfbt.commands.ralph.log_capture import RalphLogger

            project_root = obj["project_root"]
            log_base_dir = project_root / ".mfbt" / "logs"
            ralph_logger = RalphLogger(log_base_dir, agent_type)

            if tui:
                from mfbt.commands.ralph.tui_app import launch_ralph_tui

                launch_ralph_tui(
                    ralph_config, client, phase_title, log_dir=log_base_dir, progress=progress
                )
                raise typer.Exit(code=0)

            orchestrator = RalphOrchestrator(
                ralph_config, client, display, logger=ralph_logger
            )

            try:
                summary = orchestrator.run()
            except AgentNotFoundError as exc:
                display.error(str(exc))
                raise typer.Exit(code=1) from exc

            exit_code = 1 if summary.failed > 0 else 0
            raise typer.Exit(code=exit_code)
        finally:
            client.close()
