"""Core orchestration loop for ralph."""

from __future__ import annotations

import logging
import threading
import time
from typing import TYPE_CHECKING

from mfbt.commands.ralph.agent import AgentRunner
from mfbt.commands.ralph.progress import (
    get_next_feature_task,
    get_pending_feature_list,
    get_phase_progress,
    verify_feature_completed,
)
from mfbt.commands.ralph.prompt import build_agent_prompt
from mfbt.commands.ralph.types import (
    FeatureOutcome,
    FeatureResult,
    FeatureTask,
    SessionSummary,
)

if TYPE_CHECKING:
    from collections.abc import Callable
    from typing import Any

    from mfbt.api_client import APIClient
    from mfbt.commands.ralph.log_capture import RalphLogger
    from mfbt.commands.ralph.types import RalphConfig

logger = logging.getLogger("mfbt.commands.ralph.orchestrator")

MAX_RETRY_ATTEMPTS = 3


class RalphOrchestrator:
    """Fetches pending features and dispatches them to a coding agent."""

    def __init__(
        self,
        config: RalphConfig,
        client: APIClient,
        display: Any,
        logger: RalphLogger | None = None,
    ) -> None:
        self._config = config
        self._client = client
        self._display = display
        self._logger = logger
        self._agent = AgentRunner(config.coding_agent, config.max_turns)
        self._results: list[FeatureResult] = []
        self._session_start: float = 0.0
        self._stop_event = threading.Event()

    def stop(self) -> None:
        """Signal the orchestrator to stop after the current feature.

        Thread-safe — can be called from any thread.  Also terminates the
        running agent subprocess so it doesn't linger.
        """
        self._stop_event.set()
        self._agent.terminate()

    @property
    def stop_requested(self) -> bool:
        return self._stop_event.is_set()

    def _build_output_callback(self) -> Callable[[str], None] | None:
        """Build a combined callback for display + logger with error isolation."""
        display_cb = self._display.agent_output if not self._config.quiet else None
        logger_cb = self._logger.log_output if self._logger is not None else None

        if display_cb is None and logger_cb is None:
            return None

        def _combined(line: str) -> None:
            if display_cb is not None:
                try:
                    display_cb(line)
                except Exception:
                    logger.debug("Display callback error", exc_info=True)
            if logger_cb is not None:
                try:
                    logger_cb(line)
                except Exception:
                    logger.debug("Logger callback error", exc_info=True)

        return _combined

    def run(self) -> SessionSummary:
        """Execute the main orchestration loop.

        Returns a SessionSummary when all features are processed or no
        pending features remain.
        """
        self._session_start = time.monotonic()

        phases = self._config.phases

        # Gather progress for all phases
        all_progress: dict[str, dict[str, Any]] = {
            phase.phase_id: get_phase_progress(self._client, phase.phase_id)
            for phase in phases
        }

        self._display.session_start(self._config, phases, all_progress)

        if self._logger is not None:
            log_dir = self._logger.start_session(self._config, phases, all_progress)
            self._display.log_directory(log_dir)

        # Pre-populate the feature table with all pending features across phases
        all_pending_features: list[dict[str, str]] = []
        for phase in phases:
            phase_progress = all_progress[phase.phase_id]
            pending = get_pending_feature_list(
                self._client, self._config.project_id, phase.phase_id,
                phase_progress, phase_title=phase.phase_title,
            )
            all_pending_features.extend(pending)
        all_pending_features.sort(key=lambda x: x["feature_key"])
        self._display.populate_features(all_pending_features)

        # Aggregate total pending across all phases
        total_pending = sum(
            p.get("pending_features", 0) + p.get("in_progress_features", 0)
            for p in all_progress.values()
        )
        feature_num = 0
        processed_keys: set[str] = set()

        try:
            for phase in phases:
                if self.stop_requested:
                    break
                while not self.stop_requested:
                    feature = get_next_feature_task(
                        self._client,
                        self._config.project_id,
                        phase.phase_id,
                        self._config.mode,
                        phase_title=phase.phase_title,
                    )
                    if feature is None:
                        break

                    # If the API returns a feature we already attempted in this
                    # session (e.g. it failed all retries but is still "pending"
                    # upstream), stop this phase — there is no new work available.
                    if feature.feature_key in processed_keys:
                        break

                    feature_num += 1
                    result = self._implement_feature(
                        feature, feature_num, total_pending
                    )
                    self._results.append(result)
                    processed_keys.add(feature.feature_key)

        except KeyboardInterrupt:
            self._display.warn("Interrupted — shutting down agent...")
            self._agent.terminate()
            if self._logger is not None:
                self._logger.abort_feature()

        elapsed = time.monotonic() - self._session_start
        summary = SessionSummary(
            results=list(self._results),
            total_elapsed_seconds=elapsed,
        )
        self._display.session_summary(summary)
        if self._logger is not None:
            self._logger.end_session(summary)
        return summary

    def _implement_feature(
        self,
        feature: FeatureTask,
        feature_num: int,
        total: int,
    ) -> FeatureResult:
        """Attempt to implement a single feature, with retry logic."""
        prompt = build_agent_prompt(feature, self._config)
        agent_command = self._agent.build_command(prompt)
        max_attempts = 1 if self._config.max_turns is not None else MAX_RETRY_ATTEMPTS
        start = time.monotonic()
        last_exit_code: int | None = None
        last_error: str | None = None
        output_callback = self._build_output_callback()

        for attempt in range(1, max_attempts + 1):
            if self.stop_requested:
                break

            self._display.feature_start(feature, attempt, feature_num, total)

            if self._logger is not None:
                self._logger.start_feature(
                    feature, attempt, max_attempts, prompt,
                    agent_command=agent_command,
                )

            agent_result = None
            try:
                agent_result = self._agent.run(prompt, on_output=output_callback)
                last_exit_code = agent_result.exit_code
            except Exception as exc:
                last_error = str(exc)
                logger.exception("Agent run failed for %s", feature.feature_key)
                elapsed = time.monotonic() - start
                result = FeatureResult(
                    feature=feature,
                    outcome=FeatureOutcome.FAILED,
                    attempts=attempt,
                    elapsed_seconds=elapsed,
                    agent_exit_code=None,
                    error_message=last_error,
                )
                if self._logger is not None:
                    self._logger.end_feature(None, result)
                self._display.feature_complete(result)
                return result

            # Check if the feature was marked complete via the API
            completed = verify_feature_completed(self._client, feature.feature_id)
            elapsed = time.monotonic() - start

            if completed:
                result = FeatureResult(
                    feature=feature,
                    outcome=FeatureOutcome.SUCCESS,
                    attempts=attempt,
                    elapsed_seconds=elapsed,
                    agent_exit_code=last_exit_code,
                    error_message=None,
                )
                if self._logger is not None:
                    self._logger.end_feature(agent_result, result)
                self._display.feature_complete(result)
                return result

            # Not completed — decide whether to retry
            if attempt < max_attempts:
                last_error = (
                    f"Agent exited (code {last_exit_code}) "
                    f"but feature not marked complete"
                )
                # End this attempt's log before retrying
                interim_result = FeatureResult(
                    feature=feature,
                    outcome=FeatureOutcome.FAILED,
                    attempts=attempt,
                    elapsed_seconds=elapsed,
                    agent_exit_code=last_exit_code,
                    error_message=last_error,
                )
                if self._logger is not None:
                    self._logger.end_feature(agent_result, interim_result)
                self._display.feature_retry(feature, attempt + 1, max_attempts)
            else:
                last_error = (
                    f"Agent exited (code {last_exit_code}) "
                    f"but feature not marked complete after {attempt} attempt(s)"
                )

        elapsed = time.monotonic() - start
        result = FeatureResult(
            feature=feature,
            outcome=FeatureOutcome.FAILED,
            attempts=max_attempts,
            elapsed_seconds=elapsed,
            agent_exit_code=last_exit_code,
            error_message=last_error,
        )
        if self._logger is not None:
            self._logger.end_feature(agent_result, result)
        self._display.feature_complete(result)
        return result
