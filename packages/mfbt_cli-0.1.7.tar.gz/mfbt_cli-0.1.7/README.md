# mfbt CLI

Command-line tool for the [mfbt](https://mfbt.ai) platform. Provides both an interactive TUI mode and traditional subcommands for managing mfbt projects.

## Features

- **Interactive TUI** -- K9S-style keyboard-driven interface for navigating projects, phases, modules, and features
- **Subcommands** -- Traditional CLI commands for scripting and automation (`auth`, `projects`, `ralph`, and more)
- **OAuth 2.1 Authentication** -- Secure browser-based login with PKCE and API key support
- **Real-time Updates** -- WebSocket-powered job monitoring and status tracking
- **Agent Orchestration** -- Auto-invoke coding agents to implement pending features with `mfbt ralph`

## Requirements

- Python 3.10+

## Installation

```bash
pip install mfbt-cli
```

## Quick Start

```bash
# Authenticate with the mfbt platform
mfbt auth login

# List your projects
mfbt projects list

# Launch the interactive TUI
mfbt

# Show version
mfbt --version
```

## Usage

```bash
# Run with verbose output
mfbt -v
mfbt -vv    # debug
mfbt -vvv   # trace

# Authentication commands
mfbt auth login
mfbt auth status
mfbt auth logout

# Project management
mfbt projects list
mfbt projects show
mfbt projects switch

# Auto-invoke coding agents
mfbt ralph
```

## Development Setup

```bash
# Clone the repository
git clone https://github.com/Zipstack/mfbt-cli.git
cd mfbt-cli

# Create a virtual environment
python -m venv .venv
source .venv/bin/activate  # Unix
# .venv\Scripts\activate   # Windows

# Install in editable mode with dev dependencies
pip install -e .
pip install -r requirements-dev.txt

# Run tests
pytest tests/ -v

# Code quality
black --check src/ tests/
ruff check src/ tests/
mypy src/
```

## License

MIT -- see [LICENSE](LICENSE) for details.
