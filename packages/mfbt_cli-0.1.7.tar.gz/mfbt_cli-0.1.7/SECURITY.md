# Security Policy

## Supported Versions

| Version | Supported |
| ------- | --------- |
| 0.1.x   | Yes       |

## Reporting a Vulnerability

If you discover a security vulnerability, please report it responsibly:

1. **Do not** open a public issue.
2. Email security details to the project maintainers.
3. Include steps to reproduce, impact assessment, and any suggested fixes.

We will acknowledge receipt within 48 hours and aim to provide a fix within 7 days for critical issues.

## Scope

- Authentication token storage and handling
- API key management
- File permission management for `.mfbt/` directory
- Any data transmission to/from the mfbt API
