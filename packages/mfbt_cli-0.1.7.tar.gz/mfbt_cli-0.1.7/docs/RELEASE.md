# Release Process

This document describes how to release a new version of `mfbt-cli` to PyPI.

## Overview

Releases are automated via GitHub Actions. When you create a GitHub Release:

- **Pre-release** (marked as pre-release in GitHub) → publishes to **TestPyPI**
- **Full release** → publishes to **PyPI**

Both use [trusted publishing](https://docs.pypi.org/trusted-publishers/) (no API tokens needed in CI).

## Prerequisites

### One-time PyPI setup

1. Create accounts on [PyPI](https://pypi.org) and [TestPyPI](https://test.pypi.org)
2. Create the `mfbt-cli` project on each (first upload does this automatically)
3. Configure trusted publishers on both:
   - Go to project settings → "Publishing" → "Add a new publisher"
   - Owner: `Zipstack`, Repository: `mfbt-cli`, Workflow: `release.yml`
   - For PyPI: environment name `pypi`
   - For TestPyPI: environment name `testpypi`

### GitHub repository setup

1. Create two environments in GitHub repo settings → Environments:
   - `pypi` — for production releases (consider adding required reviewers)
   - `testpypi` — for pre-release validation

### Local development setup

```bash
pip install build twine
```

## Release Checklist

### 1. Prepare the release

```bash
# Ensure you're on main with a clean working tree
git checkout main
git pull origin main
git status  # should be clean
```

### 2. Update the version

Edit `pyproject.toml` and update the `version` field:

```toml
[project]
version = "X.Y.Z"
```

Follow [semantic versioning](https://semver.org/):
- **MAJOR** (X): Breaking changes
- **MINOR** (Y): New features, backwards-compatible
- **PATCH** (Z): Bug fixes, backwards-compatible

### 3. Commit the version bump

```bash
git add pyproject.toml
git commit -m "Bump version to X.Y.Z"
git push origin main
```

### 4. Build and validate locally

```bash
# Clean old builds
rm -rf dist/ build/

# Build sdist and wheel
python -m build

# Verify package metadata
twine check dist/*

# (Optional) Test install in a fresh venv
python -m venv /tmp/mfbt-test
source /tmp/mfbt-test/bin/activate
pip install dist/mfbt_cli-*.whl
mfbt --version
mfbt --help
deactivate
rm -rf /tmp/mfbt-test
```

### 5. Test with TestPyPI (recommended for major releases)

Create a **pre-release** on GitHub:

1. Go to Releases → "Draft a new release"
2. Create tag `vX.Y.Z-rc1` (e.g., `v0.2.0-rc1`)
3. Check "Set as a pre-release"
4. Publish

This triggers the workflow to publish to TestPyPI. Verify:

```bash
pip install --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple/ mfbt-cli==X.Y.Z.rc1
mfbt --version
```

### 6. Publish to PyPI

Create a **full release** on GitHub:

1. Go to Releases → "Draft a new release"
2. Create tag `vX.Y.Z` (e.g., `v0.2.0`)
3. Write release notes (what changed, any migration steps)
4. Publish (do NOT check "pre-release")

This triggers the workflow to publish to PyPI. Verify:

```bash
pip install mfbt-cli==X.Y.Z
mfbt --version
```

### 7. Post-release verification

- [ ] Package appears at https://pypi.org/project/mfbt-cli/
- [ ] `pip install mfbt-cli` installs the new version in a fresh venv
- [ ] `mfbt --version` shows the correct version
- [ ] `mfbt --help` works
- [ ] README renders correctly on the PyPI project page

## Manual upload (fallback)

If the GitHub Actions workflow fails and you need to publish manually:

```bash
# Build
python -m build

# Upload to TestPyPI
twine upload --repository testpypi dist/*

# Upload to PyPI
twine upload dist/*
```

For manual uploads you'll need API tokens. See `.pypirc.template` for the config format, or use environment variables:

```bash
TWINE_USERNAME=__token__ TWINE_PASSWORD=pypi-XXXX twine upload dist/*
```

## Troubleshooting

### Authentication failures

- **Trusted publishing:** Ensure the GitHub environment name matches exactly (`pypi` or `testpypi`) and the workflow filename is `release.yml`
- **API tokens:** Ensure you're using `__token__` as the username and the full token (starting with `pypi-`) as the password

### "File already exists" error

PyPI does not allow re-uploading the same version. You must bump the version number. For fixes to a bad release, increment the patch version (e.g., `0.2.0` → `0.2.1`).

### README not rendering correctly

- Ensure `README.md` uses only standard Markdown (no GitHub-specific extensions like `<details>` tags)
- Validate locally: `twine check dist/*` reports rendering issues
- The `readme = "README.md"` field in `pyproject.toml` must point to the correct file

### Missing files in distribution

- Check `[tool.hatch.build.targets.sdist]` exclude list in `pyproject.toml`
- Verify wheel contents: `unzip -l dist/*.whl`
- Ensure `packages = ["src/mfbt"]` is set in `[tool.hatch.build.targets.wheel]`

### Version conflicts

- PyPI and TestPyPI are separate registries — a version on one doesn't affect the other
- Use pre-release suffixes (`rc1`, `rc2`) for TestPyPI testing to avoid burning version numbers

## Rollback procedure

If a critical issue is found after publication:

1. **Yank the release** (marks it as not recommended, existing installs unaffected):
   - PyPI: Go to project → Releases → select version → "Yank"
   - Or: `pip install pypi-yank && pypi-yank mfbt-cli X.Y.Z`

2. **Publish a hotfix:**
   ```bash
   # Fix the issue on main
   # Bump to next patch version (X.Y.Z+1)
   # Follow the release process above
   ```

3. **Update the GitHub Release** to note the issue and point to the fixed version.

Note: You **cannot delete** a version from PyPI or re-upload the same version number. Always increment the version for fixes.
