"""mfbt CLI — command-line tool for the mfbt platform."""

__all__: list[str] = []
