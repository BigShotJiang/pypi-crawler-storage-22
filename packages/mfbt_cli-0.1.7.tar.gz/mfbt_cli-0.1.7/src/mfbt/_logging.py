"""Logging configuration for mfbt CLI."""

from __future__ import annotations

import logging
import sys
from logging.handlers import RotatingFileHandler
from pathlib import Path

TRACE = 5
logging.addLevelName(TRACE, "TRACE")

VERBOSITY_MAP: dict[int, int] = {
    0: logging.WARNING,
    1: logging.INFO,
    2: logging.DEBUG,
    3: TRACE,
}

LOG_FORMAT = "%(asctime)s [%(levelname)-7s] %(name)s: %(message)s"
LOG_DATE_FORMAT = "%Y-%m-%d %H:%M:%S"


def setup_logging(
    verbosity: int = 0,
    log_dir: Path | None = None,
) -> logging.Logger:
    """Configure logging for the mfbt CLI.

    Args:
        verbosity: 0=WARNING, 1=INFO, 2=DEBUG, 3=TRACE.
        log_dir: Optional directory for rotating error log file.

    Returns:
        The root mfbt logger.
    """
    level = VERBOSITY_MAP.get(verbosity, TRACE)
    logger = logging.getLogger("mfbt")
    logger.setLevel(level)
    logger.handlers.clear()

    console = logging.StreamHandler(sys.stderr)
    console.setLevel(level)
    console.setFormatter(logging.Formatter(LOG_FORMAT, datefmt=LOG_DATE_FORMAT))
    logger.addHandler(console)

    if log_dir is not None:
        log_dir.mkdir(parents=True, exist_ok=True)
        file_handler = RotatingFileHandler(
            log_dir / "mfbt-error.log",
            maxBytes=5 * 1024 * 1024,
            backupCount=3,
        )
        file_handler.setLevel(logging.ERROR)
        file_handler.setFormatter(
            logging.Formatter(LOG_FORMAT, datefmt=LOG_DATE_FORMAT)
        )
        logger.addHandler(file_handler)

    return logger
