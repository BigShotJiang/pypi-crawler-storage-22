"""REST API client for mfbt CLI.

Provides APIClient with connection pooling, automatic auth token injection,
retry with exponential backoff, pagination, and optional response caching.
Covers MCLI-048 (core client), MCLI-049 (pagination), MCLI-050 (retry).
"""

from __future__ import annotations

import enum
import logging
import random
import threading
import time
from collections.abc import Callable, Iterator
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

import httpx

from mfbt.exceptions import (
    APIError,
    AuthenticationRequired,
    CircuitBreakerOpenError,
    NetworkError,
    NotFoundError,
    RateLimitExceeded,
    RetryExhaustedError,
    ServerError,
    TokenLimitExceeded,
    ValidationError,
)

if TYPE_CHECKING:
    from mfbt.cache import ResponseCache
    from mfbt.token_manager import TokenManager

logger = logging.getLogger("mfbt.api_client")

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

DEFAULT_TIMEOUT = 30.0
DEFAULT_MAX_RETRIES = 3
DEFAULT_BASE_DELAY = 1.0
DEFAULT_JITTER = 0.25
DEFAULT_PAGE_LIMIT = 25
DEFAULT_CB_FAILURE_THRESHOLD = 5
DEFAULT_CB_COOLDOWN = 30.0

_RETRYABLE_STATUSES = frozenset({429, 502, 503, 504})


# ---------------------------------------------------------------------------
# Circuit breaker (MCLI-069)
# ---------------------------------------------------------------------------


class CircuitState(enum.Enum):
    """States for the circuit breaker."""

    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"


class CircuitBreaker:
    """Thread-safe circuit breaker that trips after consecutive failures.

    States:
        CLOSED  — requests flow normally, failures are counted.
        OPEN    — requests are blocked with CircuitBreakerOpenError.
        HALF_OPEN — one test request is allowed after cooldown expires.
    """

    def __init__(
        self,
        failure_threshold: int = DEFAULT_CB_FAILURE_THRESHOLD,
        cooldown: float = DEFAULT_CB_COOLDOWN,
    ) -> None:
        self.failure_threshold = failure_threshold
        self.cooldown = cooldown
        self._state = CircuitState.CLOSED
        self._failure_count = 0
        self._opened_at: float = 0.0
        self._lock = threading.Lock()

    @property
    def state(self) -> CircuitState:
        with self._lock:
            return self._resolve_state()

    def check_state(self) -> None:
        """Raise CircuitBreakerOpenError if the circuit is OPEN."""
        with self._lock:
            current = self._resolve_state()
            if current == CircuitState.OPEN:
                raise CircuitBreakerOpenError(
                    technical_details=(
                        f"{self._failure_count} consecutive failures, "
                        f"cooldown {self.cooldown}s"
                    ),
                )
            # HALF_OPEN or CLOSED — allow the request through

    def record_success(self) -> None:
        """Record a successful request. Resets the circuit to CLOSED."""
        with self._lock:
            self._failure_count = 0
            self._state = CircuitState.CLOSED

    def record_failure(self) -> None:
        """Record a failed request. Opens the circuit at threshold."""
        with self._lock:
            self._failure_count += 1
            if self._failure_count >= self.failure_threshold:
                self._state = CircuitState.OPEN
                self._opened_at = time.monotonic()

    def _resolve_state(self) -> CircuitState:
        """Resolve the effective state, handling OPEN → HALF_OPEN transition.

        Must be called while holding self._lock.
        """
        if self._state == CircuitState.OPEN:
            elapsed = time.monotonic() - self._opened_at
            if elapsed >= self.cooldown:
                self._state = CircuitState.HALF_OPEN
        return self._state


# ---------------------------------------------------------------------------
# Response dataclass
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class APIResponse:
    """Parsed API response."""

    status_code: int
    headers: dict[str, str]
    body: Any
    raw_text: str


# ---------------------------------------------------------------------------
# Retry helpers (MCLI-050)
# ---------------------------------------------------------------------------


def _is_retryable_status(status_code: int) -> bool:
    """Return True if the HTTP status code is retryable."""
    return status_code in _RETRYABLE_STATUSES


def _is_retryable_exception(exc: Exception) -> bool:
    """Return True if the exception is a transient network failure."""
    return isinstance(exc, (httpx.TimeoutException, httpx.ConnectError, httpx.NetworkError))


def _calculate_backoff(
    attempt: int,
    base_delay: float = DEFAULT_BASE_DELAY,
    jitter: float = DEFAULT_JITTER,
) -> float:
    """Calculate exponential backoff delay with random jitter.

    Returns base_delay * 2^attempt * (1 +/- jitter).
    """
    delay = base_delay * (2 ** attempt)
    jitter_range = delay * jitter
    result: float = delay + random.uniform(-jitter_range, jitter_range)
    return result


# ---------------------------------------------------------------------------
# Pagination (MCLI-049)
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class PaginatedPage:
    """A single page from a paginated API response."""

    items: list[Any]
    total: int
    limit: int
    offset: int

    @property
    def has_more(self) -> bool:
        """Return True if there are more pages after this one."""
        return self.offset + self.limit < self.total


def _parse_paginated_response(body: Any) -> PaginatedPage:
    """Parse and validate a paginated API response body.

    Raises APIError if required pagination fields are missing.
    """
    if not isinstance(body, dict):
        raise APIError(
            "Invalid paginated response: expected JSON object",
            technical_details=f"Got {type(body).__name__}",
        )
    missing = [f for f in ("items", "total", "limit", "offset") if f not in body]
    if missing:
        raise APIError(
            "Invalid paginated response: missing required fields",
            technical_details=f"Missing: {', '.join(missing)}",
        )
    return PaginatedPage(
        items=body["items"],
        total=body["total"],
        limit=body["limit"],
        offset=body["offset"],
    )


class PaginatedIterator:
    """Lazily iterates over all items from a paginated API endpoint."""

    def __init__(
        self,
        client: APIClient,
        path: str,
        params: dict[str, Any] | None,
        limit: int,
    ) -> None:
        self._client = client
        self._path = path
        self._params = dict(params) if params else {}
        self._limit = limit

    def __iter__(self) -> Iterator[Any]:
        offset = 0
        while True:
            page_params = {**self._params, "limit": self._limit, "offset": offset}
            response = self._client.get(self._path, params=page_params)
            page = _parse_paginated_response(response.body)
            if not page.items:
                return
            yield from page.items
            if not page.has_more:
                return
            offset += self._limit


# ---------------------------------------------------------------------------
# APIClient (MCLI-048)
# ---------------------------------------------------------------------------


class APIClient:
    """Authenticated REST client for the mfbt API.

    Features:
    - Connection pooling via httpx.Client
    - Automatic auth token injection via TokenManager
    - Retry with exponential backoff for transient failures
    - Optional response caching for GET requests
    - Lazy paginated iteration
    """

    def __init__(
        self,
        base_url: str,
        token_manager: TokenManager,
        *,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
        cache: ResponseCache | None = None,
        on_auth_required: Callable[[], bool] | None = None,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.token_manager = token_manager
        self.max_retries = max_retries
        self.cache = cache
        self.on_auth_required = on_auth_required
        self._circuit_breaker = CircuitBreaker()
        self._client = httpx.Client(
            timeout=timeout,
            limits=httpx.Limits(
                max_connections=10,
                max_keepalive_connections=5,
            ),
        )

    def close(self) -> None:
        """Close the underlying HTTP connection pool."""
        self._client.close()

    def __enter__(self) -> APIClient:
        return self

    def __exit__(self, *exc: object) -> None:
        self.close()

    # ---- Public API ---------------------------------------------------------

    def get(
        self,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> APIResponse:
        """Send a GET request."""
        return self._request("GET", path, params=params, headers=headers)

    def post(
        self,
        path: str,
        *,
        json_body: Any = None,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> APIResponse:
        """Send a POST request. Invalidates cache for the path prefix."""
        response = self._request(
            "POST", path, json_body=json_body, params=params, headers=headers
        )
        self._invalidate_cache(path)
        return response

    def put(
        self,
        path: str,
        *,
        json_body: Any = None,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> APIResponse:
        """Send a PUT request. Invalidates cache for the path prefix."""
        response = self._request(
            "PUT", path, json_body=json_body, params=params, headers=headers
        )
        self._invalidate_cache(path)
        return response

    def delete(
        self,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> APIResponse:
        """Send a DELETE request. Invalidates cache for the path prefix."""
        response = self._request("DELETE", path, params=params, headers=headers)
        self._invalidate_cache(path)
        return response

    def get_paginated(
        self,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        limit: int = DEFAULT_PAGE_LIMIT,
    ) -> PaginatedIterator:
        """Return a lazy iterator over all items from a paginated endpoint."""
        return PaginatedIterator(self, path, params, limit)

    # ---- Internal -----------------------------------------------------------

    def _get_auth_headers(self) -> dict[str, str]:
        """Get authorization headers with a fresh access token."""
        token = self.token_manager.get_access_token()
        return {"Authorization": f"Bearer {token}"}

    def _request(
        self,
        method: str,
        path: str,
        *,
        json_body: Any = None,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> APIResponse:
        """Orchestrate cache lookup, retry, and error mapping."""
        url = f"{self.base_url}/{path.lstrip('/')}"

        # Check cache for GET requests
        if method == "GET" and self.cache is not None:
            cached = self.cache.get(url, params)
            if cached is not None:
                return APIResponse(
                    status_code=cached.status_code,
                    headers=cached.headers,
                    body=cached.body,
                    raw_text=cached.raw_text,
                )

        # Execute with retry
        response = self._execute_with_retry(
            method, url, json_body=json_body, params=params, headers=headers
        )

        # Map errors
        self._raise_for_status(response)

        # Parse response
        try:
            body = response.json()
        except Exception:
            body = None

        resp_headers = dict(response.headers)
        api_response = APIResponse(
            status_code=response.status_code,
            headers=resp_headers,
            body=body,
            raw_text=response.text,
        )

        # Store in cache for GET requests
        if method == "GET" and self.cache is not None:
            self.cache.put(url, params, api_response.status_code, resp_headers, body, response.text)

        return api_response

    def _obtain_auth_headers(
        self, headers: dict[str, str] | None
    ) -> dict[str, str]:
        """Get merged auth + caller headers, with auto-login fallback.

        If getting the access token raises a TokenError (e.g. refresh
        token expired), invoke the ``on_auth_required`` callback to let
        the user re-authenticate interactively, then retry once.
        """
        from mfbt.token_manager import TokenError

        try:
            auth_headers = self._get_auth_headers()
        except TokenError:
            if self.on_auth_required is None or not self.on_auth_required():
                raise
            # Callback succeeded — retry getting headers
            auth_headers = self._get_auth_headers()

        return {**auth_headers, **(headers or {})}

    def _execute_with_retry(
        self,
        method: str,
        url: str,
        *,
        json_body: Any = None,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> httpx.Response:
        """Execute an HTTP request with retry logic and circuit breaker."""
        self._circuit_breaker.check_state()

        merged_headers = self._obtain_auth_headers(headers)

        last_error: Exception | None = None

        for attempt in range(self.max_retries):
            try:
                response = self._client.request(
                    method,
                    url,
                    params=params,
                    json=json_body,
                    headers=merged_headers,
                )
            except Exception as exc:
                if _is_retryable_exception(exc):
                    last_error = exc
                    logger.warning(
                        "Request %s %s network error (attempt %d/%d): %s",
                        method, url, attempt + 1, self.max_retries, exc,
                    )
                    if attempt < self.max_retries - 1:
                        delay = _calculate_backoff(attempt)
                        time.sleep(delay)
                    continue
                # Non-retryable exception
                self._circuit_breaker.record_failure()
                raise NetworkError(
                    technical_details=str(exc),
                ) from exc

            # Handle 401 — try token refresh, then interactive auth
            if response.status_code == 401:
                logger.info("Received 401, attempting token refresh")
                merged_headers = self._handle_auth_failure(headers)
                if merged_headers is not None:
                    # Retry the request once with fresh headers
                    try:
                        response = self._client.request(
                            method,
                            url,
                            params=params,
                            json=json_body,
                            headers=merged_headers,
                        )
                    except Exception as exc:
                        self._circuit_breaker.record_failure()
                        raise NetworkError(
                            technical_details=str(exc),
                        ) from exc

                    if response.status_code != 401:
                        self._circuit_breaker.record_success()
                        return response

                # Still 401 after recovery attempts — fall through to
                # normal status handling (will raise AuthenticationRequired
                # in _raise_for_status)
                self._circuit_breaker.record_success()
                return response

            # Check for retryable HTTP status
            if _is_retryable_status(response.status_code):
                last_error = APIError(
                    f"HTTP {response.status_code}",
                    status_code=response.status_code,
                )
                logger.warning(
                    "Request %s %s returned %d (attempt %d/%d)",
                    method, url, response.status_code,
                    attempt + 1, self.max_retries,
                )
                if attempt < self.max_retries - 1:
                    # Use Retry-After header if present, otherwise backoff
                    retry_after = response.headers.get("retry-after")
                    if retry_after:
                        try:
                            delay = float(retry_after)
                        except ValueError:
                            delay = _calculate_backoff(attempt)
                    else:
                        delay = _calculate_backoff(attempt)
                    time.sleep(delay)
                continue

            # Non-retryable response — success path
            self._circuit_breaker.record_success()
            return response

        # All retries exhausted
        self._circuit_breaker.record_failure()
        raise RetryExhaustedError(
            technical_details=str(last_error),
            original=last_error,
        ) from last_error

    def _handle_auth_failure(
        self, original_headers: dict[str, str] | None
    ) -> dict[str, str] | None:
        """Attempt to recover from an authentication failure.

        1. Try refreshing the token via ``token_manager.refresh_tokens()``.
        2. If refresh fails and ``on_auth_required`` is set, invoke it
           to trigger interactive re-authentication.

        Returns merged headers on success, or None if recovery failed.
        """
        from mfbt.token_manager import TokenError

        # First try: refresh the token
        try:
            self.token_manager.refresh_tokens()
            return {**self._get_auth_headers(), **(original_headers or {})}
        except TokenError:
            logger.info("Token refresh failed, trying interactive auth")

        # Second try: interactive re-auth
        if self.on_auth_required is not None and self.on_auth_required():
            try:
                return {**self._get_auth_headers(), **(original_headers or {})}
            except TokenError:
                logger.warning("Auth headers still invalid after interactive login")

        return None

    def _raise_for_status(self, response: httpx.Response) -> None:
        """Map HTTP error status codes to specific exceptions."""
        status = response.status_code
        if 200 <= status < 300:
            return

        try:
            body = response.json()
        except Exception:
            body = None
        raw = response.text

        if status == 401:
            raise AuthenticationRequired(
                technical_details=raw,
                response_body=body,
            )
        if status == 402:
            raise TokenLimitExceeded(
                technical_details=raw,
                response_body=body,
            )
        if status == 404:
            raise NotFoundError(
                technical_details=raw,
                response_body=body,
            )
        if status == 422:
            detail = body.get("detail", []) if isinstance(body, dict) else []
            raise ValidationError(
                status_code=422,
                technical_details=raw,
                response_body=body,
                detail=detail,
            )
        if status == 429:
            retry_after: float | None = None
            retry_hdr = response.headers.get("retry-after")
            if retry_hdr:
                try:
                    retry_after = float(retry_hdr)
                except ValueError:
                    pass
            raise RateLimitExceeded(
                technical_details=raw,
                response_body=body,
                retry_after=retry_after,
            )
        if status >= 500:
            raise ServerError(
                status_code=status,
                technical_details=raw,
                response_body=body,
            )

        # Catch-all for other 4xx
        raise APIError(
            f"API request failed with status {status}",
            status_code=status,
            technical_details=raw,
            response_body=body,
        )

    def _invalidate_cache(self, path: str) -> None:
        """Invalidate cached responses matching the given path prefix."""
        if self.cache is not None:
            # Build the full URL prefix for segment-aware matching
            url_prefix = f"{self.base_url}/{path.lstrip('/')}"
            self.cache.invalidate(url_prefix)
