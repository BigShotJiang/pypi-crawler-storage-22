"""OAuth 2.1 PKCE authentication for mfbt CLI.

Handles PKCE code generation, local callback server for authorization code
capture, token exchange with the mfbt backend, and token storage.
"""

from __future__ import annotations

import base64
import hashlib
import logging
import os
import secrets
import string
import time
from dataclasses import dataclass
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urlparse

logger = logging.getLogger("mfbt.auth")

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

MFBT_CLI_CLIENT_NAME = "mfbt-cli"
OAUTH_SCOPES = "mcp:read mcp:write"
DEFAULT_TIMEOUT = 120

# RFC 7636 allowed characters for code_verifier
_PKCE_CHARSET = string.ascii_letters + string.digits + "-._~"

# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------


class AuthError(Exception):
    """Base exception for authentication errors."""


class AuthTimeoutError(AuthError):
    """Raised when waiting for the OAuth callback times out."""


class TokenExchangeError(AuthError):
    """Raised when the token exchange request fails."""


# ---------------------------------------------------------------------------
# PKCE Code Generation (MCLI-040)
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class PKCEParams:
    """PKCE parameters for an OAuth 2.1 authorization request."""

    code_verifier: str
    code_challenge: str
    code_challenge_method: str
    state: str


def generate_code_verifier(length: int = 128) -> str:
    """Generate a cryptographically random PKCE code verifier.

    Args:
        length: Length of the verifier (43-128 per RFC 7636).

    Returns:
        A random string from the unreserved character set.

    Raises:
        ValueError: If length is not between 43 and 128.
    """
    if not 43 <= length <= 128:
        raise ValueError(f"Code verifier length must be 43-128, got {length}")
    return "".join(secrets.choice(_PKCE_CHARSET) for _ in range(length))


def generate_code_challenge(verifier: str) -> str:
    """Generate an S256 code challenge from a code verifier.

    Computes: BASE64URL(SHA256(verifier))

    Args:
        verifier: The PKCE code verifier string.

    Returns:
        The base64url-encoded SHA-256 hash (no padding).
    """
    digest = hashlib.sha256(verifier.encode("ascii")).digest()
    return base64.urlsafe_b64encode(digest).rstrip(b"=").decode("ascii")


def generate_state() -> str:
    """Generate a cryptographically random state parameter."""
    return secrets.token_urlsafe(32)


def generate_pkce_params(verifier_length: int = 128) -> PKCEParams:
    """Generate a complete set of PKCE parameters.

    Args:
        verifier_length: Length of the code verifier.

    Returns:
        PKCEParams with verifier, challenge, method, and state.
    """
    verifier = generate_code_verifier(verifier_length)
    challenge = generate_code_challenge(verifier)
    state = generate_state()
    return PKCEParams(
        code_verifier=verifier,
        code_challenge=challenge,
        code_challenge_method="S256",
        state=state,
    )


# ---------------------------------------------------------------------------
# Local Callback Server (MCLI-041)
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class CallbackResult:
    """Result from the OAuth callback."""

    code: str
    state: str


_SUCCESS_HTML = """\
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>mfbt CLI - Authenticated</title>
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
    background: #0d1117;
    color: #e6edf3;
    display: flex;
    align-items: center;
    justify-content: center;
    min-height: 100vh;
  }
  .card {
    text-align: center;
    max-width: 440px;
    padding: 48px 40px;
  }
  .brand {
    font-size: 14px;
    font-weight: 600;
    letter-spacing: 0.08em;
    color: #58a6ff;
    margin-bottom: 28px;
  }
  .icon {
    width: 64px;
    height: 64px;
    border-radius: 50%;
    background: #1a3a2a;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 24px;
  }
  .icon svg { width: 32px; height: 32px; }
  h1 {
    font-size: 24px;
    font-weight: 600;
    margin-bottom: 12px;
  }
  p {
    font-size: 15px;
    color: #8b949e;
    line-height: 1.5;
  }
</style>
</head>
<body>
<div class="card">
  <div class="brand">mfbt</div>
  <div class="icon">
    <svg fill="none" viewBox="0 0 24 24" stroke="#3fb950" stroke-width="2.5">
      <path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/>
    </svg>
  </div>
  <h1>Authentication successful</h1>
  <p>You can close this tab and return to the terminal.</p>
</div>
</body>
</html>
"""

_ERROR_HTML = """\
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>mfbt CLI - Error</title>
<style>
  * {{ margin: 0; padding: 0; box-sizing: border-box; }}
  body {{
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
    background: #0d1117;
    color: #e6edf3;
    display: flex;
    align-items: center;
    justify-content: center;
    min-height: 100vh;
  }}
  .card {{
    text-align: center;
    max-width: 440px;
    padding: 48px 40px;
  }}
  .brand {{
    font-size: 14px;
    font-weight: 600;
    letter-spacing: 0.08em;
    color: #58a6ff;
    margin-bottom: 28px;
  }}
  .icon {{
    width: 64px;
    height: 64px;
    border-radius: 50%;
    background: #3a1a1a;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 24px;
  }}
  .icon svg {{ width: 32px; height: 32px; }}
  h1 {{
    font-size: 24px;
    font-weight: 600;
    margin-bottom: 12px;
  }}
  p {{
    font-size: 15px;
    color: #8b949e;
    line-height: 1.5;
  }}
  p + p {{ margin-top: 8px; }}
</style>
</head>
<body>
<div class="card">
  <div class="brand">mfbt</div>
  <div class="icon">
    <svg fill="none" viewBox="0 0 24 24" stroke="#f85149" stroke-width="2.5">
      <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/>
    </svg>
  </div>
  <h1>Authentication failed</h1>
  <p>{error}</p>
  <p>Please return to the terminal and try again.</p>
</div>
</body>
</html>
"""


class OAuthCallbackHandler(BaseHTTPRequestHandler):
    """HTTP request handler for the OAuth redirect callback."""

    server: OAuthCallbackServer  # type: ignore[assignment]

    def do_GET(self) -> None:  # noqa: N802
        """Handle the OAuth callback GET request."""
        parsed = urlparse(self.path)
        if parsed.path != "/callback":
            self._send_response(404, "Not Found")
            return

        params = parse_qs(parsed.query)

        # Check for error from authorization server
        if "error" in params:
            error_msg = params["error"][0]
            description = params.get("error_description", [""])[0]
            full_error = f"{error_msg}: {description}" if description else error_msg
            self.server.error = full_error
            self._send_response(400, _ERROR_HTML.format(error=full_error))
            return

        code = params.get("code", [None])[0]
        state = params.get("state", [None])[0]

        if not code or not state:
            self.server.error = "Missing code or state parameter"
            self._send_response(
                400, _ERROR_HTML.format(error="Missing code or state parameter")
            )
            return

        if state != self.server.expected_state:
            self.server.error = "State parameter mismatch (possible CSRF)"
            self._send_response(
                400, _ERROR_HTML.format(error="State parameter mismatch")
            )
            return

        self.server.result = CallbackResult(code=code, state=state)
        self._send_response(200, _SUCCESS_HTML)

    def _send_response(self, status: int, body: str) -> None:
        """Send an HTML response."""
        self.send_response(status)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.end_headers()
        self.wfile.write(body.encode("utf-8"))

    def log_message(self, format: str, *args: Any) -> None:
        """Suppress default stderr logging; use our logger instead."""
        logger.debug("OAuth callback server: %s", format % args)


class OAuthCallbackServer(HTTPServer):
    """HTTP server that captures the OAuth authorization code."""

    def __init__(
        self,
        server_address: tuple[str, int],
        expected_state: str,
    ) -> None:
        super().__init__(server_address, OAuthCallbackHandler)
        self.expected_state = expected_state
        self.result: CallbackResult | None = None
        self.error: str | None = None


def start_callback_server(
    expected_state: str,
    port_range: tuple[int, int] = (8000, 9000),
) -> tuple[OAuthCallbackServer, int]:
    """Start the OAuth callback server on an available port.

    Tries ports in the given range until one binds successfully.

    Args:
        expected_state: The state parameter to validate against.
        port_range: (start, end) range of ports to try.

    Returns:
        Tuple of (server, port).

    Raises:
        AuthError: If no port in the range is available.
    """
    start, end = port_range
    last_error: OSError | None = None
    for port in range(start, end):
        try:
            server = OAuthCallbackServer(("127.0.0.1", port), expected_state)
            logger.debug("OAuth callback server listening on port %d", port)
            return server, port
        except OSError as exc:
            last_error = exc
            continue

    raise AuthError(
        f"Could not bind to any port in range {start}-{end - 1}: {last_error}"
    )


def wait_for_callback(
    server: OAuthCallbackServer,
    timeout: int = DEFAULT_TIMEOUT,
) -> CallbackResult:
    """Wait for the OAuth callback, handling requests until timeout.

    Args:
        server: The callback server to wait on.
        timeout: Maximum seconds to wait.

    Returns:
        CallbackResult with authorization code and state.

    Raises:
        AuthTimeoutError: If no callback received within timeout.
        AuthError: If the callback contained an error.
    """
    server.timeout = 1.0
    deadline = time.monotonic() + timeout

    while time.monotonic() < deadline:
        server.handle_request()
        if server.result is not None:
            return server.result
        if server.error is not None:
            raise AuthError(f"OAuth callback error: {server.error}")

    raise AuthTimeoutError(f"No OAuth callback received within {timeout}s")


# ---------------------------------------------------------------------------
# Dynamic Client Registration (RFC 7591)
# ---------------------------------------------------------------------------


class ClientRegistrationError(AuthError):
    """Raised when dynamic client registration fails."""


@dataclass(frozen=True)
class RegisteredClient:
    """Result from dynamic client registration."""

    client_id: str
    client_name: str


def register_client(
    base_url: str,
    redirect_uris: list[str],
    client_name: str = MFBT_CLI_CLIENT_NAME,
) -> RegisteredClient:
    """Register the CLI as an OAuth client via RFC 7591.

    Args:
        base_url: The mfbt backend base URL.
        redirect_uris: Redirect URIs to register (must include the actual port).
        client_name: Human-readable client name.

    Returns:
        RegisteredClient with the server-assigned client_id.

    Raises:
        ClientRegistrationError: If registration fails.
    """
    import httpx

    register_url = f"{base_url.rstrip('/')}/oauth/register"
    payload = {
        "client_name": client_name,
        "redirect_uris": redirect_uris,
    }

    try:
        response = httpx.post(
            register_url,
            json=payload,
            timeout=30.0,
        )
    except httpx.HTTPError as exc:
        raise ClientRegistrationError(
            f"Network error during client registration: {exc}"
        ) from exc

    if response.status_code != 200 and response.status_code != 201:
        try:
            detail = response.json().get("detail", response.text)
        except Exception:
            detail = response.text
        raise ClientRegistrationError(
            f"Client registration failed (HTTP {response.status_code}): {detail}"
        )

    data = response.json()
    client_id = data.get("client_id")
    if not client_id:
        raise ClientRegistrationError(
            "Server returned no client_id in registration response"
        )

    return RegisteredClient(
        client_id=client_id,
        client_name=data.get("client_name", client_name),
    )


# ---------------------------------------------------------------------------
# Token Exchange & Storage (MCLI-042)
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class TokenResponse:
    """Parsed token response from the OAuth server."""

    access_token: str
    refresh_token: str | None
    token_type: str
    expires_at: str | None
    issued_at: str | None = None


def exchange_code_for_tokens(
    base_url: str,
    code: str,
    code_verifier: str,
    redirect_uri: str,
    client_id: str,
) -> TokenResponse:
    """Exchange an authorization code for tokens.

    Args:
        base_url: The mfbt backend base URL.
        code: The authorization code from the callback.
        code_verifier: The PKCE code verifier.
        redirect_uri: The redirect URI used in the authorization request.
        client_id: The OAuth client ID.

    Returns:
        TokenResponse with access and refresh tokens.

    Raises:
        TokenExchangeError: If the exchange request fails.
    """
    import httpx

    token_url = f"{base_url.rstrip('/')}/oauth/token"
    payload = {
        "grant_type": "authorization_code",
        "client_id": client_id,
        "code": code,
        "code_verifier": code_verifier,
        "redirect_uri": redirect_uri,
    }

    try:
        response = httpx.post(
            token_url,
            data=payload,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            timeout=30.0,
        )
    except httpx.HTTPError as exc:
        raise TokenExchangeError(f"HTTP error during token exchange: {exc}") from exc

    if response.status_code != 200:
        try:
            detail = response.json().get("detail", response.text)
        except Exception:
            detail = response.text
        raise TokenExchangeError(
            f"Token exchange failed (HTTP {response.status_code}): {detail}"
        )

    data = response.json()

    from datetime import datetime, timedelta, timezone

    # Compute expires_at from expires_in if present
    expires_at = data.get("expires_at")
    if expires_at is None and "expires_in" in data:
        expires_at = (
            datetime.now(timezone.utc) + timedelta(seconds=data["expires_in"])
        ).isoformat()

    issued_at = datetime.now(timezone.utc).isoformat()

    return TokenResponse(
        access_token=data["access_token"],
        refresh_token=data.get("refresh_token"),
        token_type=data.get("token_type", "bearer"),
        expires_at=expires_at,
        issued_at=issued_at,
    )


def store_tokens(token_response: TokenResponse) -> None:
    """Store OAuth tokens using the existing config system."""
    from mfbt.config import save_auth

    auth_data = {
        "access_token": token_response.access_token,
        "refresh_token": token_response.refresh_token,
        "token_type": token_response.token_type,
        "expires_at": token_response.expires_at,
        "issued_at": token_response.issued_at,
    }
    save_auth(auth_data)
    logger.info("Tokens stored in ~/.mfbt/auth.json")
