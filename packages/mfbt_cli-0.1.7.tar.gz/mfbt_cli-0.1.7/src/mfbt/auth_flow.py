"""Shared browser-based OAuth login flow.

Extracted from tui/__init__.py so both TUI and CLI commands can
trigger re-authentication when token refresh fails.
"""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger("mfbt.auth_flow")


def run_interactive_auth(
    base_url: str,
    token_manager: Any,
    console: Any,
) -> bool:
    """Run the browser-based OAuth login flow.

    Opens the user's browser for OAuth authentication with PKCE,
    waits for the callback, and saves the resulting tokens.

    Args:
        base_url: The mfbt API base URL.
        token_manager: A TokenManager instance for saving tokens.
        console: A Rich Console instance for user feedback.

    Returns:
        True if authentication succeeded, False otherwise.
    """
    import webbrowser
    from urllib.parse import urlencode

    from mfbt.auth import (
        OAUTH_SCOPES,
        AuthError,
        AuthTimeoutError,
        ClientRegistrationError,
        TokenExchangeError,
        exchange_code_for_tokens,
        generate_pkce_params,
        start_callback_server,
        wait_for_callback,
    )

    pkce = generate_pkce_params()

    try:
        server, port = start_callback_server(pkce.state)
    except AuthError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        return False

    redirect_uri = f"http://127.0.0.1:{port}/callback"

    # Register OAuth client (RFC 7591 Dynamic Client Registration)
    console.print("Registering OAuth client...")
    try:
        client_id = token_manager.register_and_save_client([redirect_uri])
    except ClientRegistrationError as exc:
        server.server_close()
        console.print(f"[red]Error:[/red] {exc}")
        return False

    auth_params = {
        "client_id": client_id,
        "redirect_uri": redirect_uri,
        "code_challenge": pkce.code_challenge,
        "code_challenge_method": pkce.code_challenge_method,
        "response_type": "code",
        "state": pkce.state,
        "scope": OAUTH_SCOPES,
    }
    auth_url = f"{base_url.rstrip('/')}/oauth/authorize?{urlencode(auth_params)}"

    console.print("Opening browser for authentication...")
    webbrowser.open(auth_url)
    console.print(f"Waiting for callback (timeout: 120s)...\n")

    try:
        result = wait_for_callback(server, timeout=120)
    except AuthTimeoutError:
        console.print("[red]Error:[/red] Authentication timed out. Please try again.")
        return False
    except AuthError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        return False
    except KeyboardInterrupt:
        console.print("\nAuthentication cancelled.")
        return False
    finally:
        server.server_close()

    console.print("Exchanging authorization code for tokens...")
    try:
        token_response = exchange_code_for_tokens(
            base_url=base_url,
            code=result.code,
            code_verifier=pkce.code_verifier,
            redirect_uri=redirect_uri,
            client_id=client_id,
        )
    except TokenExchangeError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        return False

    token_manager.save_tokens(token_response)
    console.print("[green]Successfully authenticated![/green]\n")
    return True
