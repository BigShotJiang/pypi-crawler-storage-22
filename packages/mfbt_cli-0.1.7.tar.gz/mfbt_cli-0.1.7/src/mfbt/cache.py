"""Response caching layer for mfbt CLI.

Provides file-based caching for GET responses with configurable TTL,
atomic writes, and path-prefix invalidation. Covers MCLI-051.
"""

from __future__ import annotations

import hashlib
import json
import logging
import tempfile
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from mfbt.platform import set_secure_dir_permissions, set_secure_file_permissions

logger = logging.getLogger("mfbt.cache")

# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------

DEFAULT_TTL = 300  # 5 minutes


@dataclass(frozen=True)
class CacheEntry:
    """A cached API response."""

    url: str
    status_code: int
    headers: dict[str, str]
    body: Any
    raw_text: str
    cached_at: float


@dataclass(frozen=True)
class CacheStats:
    """Cache usage statistics."""

    hits: int
    misses: int
    size: int  # number of entries on disk
    hit_rate: float


# ---------------------------------------------------------------------------
# Cache key helpers
# ---------------------------------------------------------------------------


def _make_cache_key(url: str, params: dict[str, Any] | None = None) -> str:
    """Generate a SHA-256 cache key from URL and sorted query params."""
    canonical = url
    if params:
        sorted_params = sorted(
            (str(k), str(v)) for k, v in params.items()
        )
        param_str = "&".join(f"{k}={v}" for k, v in sorted_params)
        canonical = f"{url}?{param_str}"
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


# ---------------------------------------------------------------------------
# ResponseCache
# ---------------------------------------------------------------------------


class ResponseCache:
    """File-based response cache with TTL expiration.

    Stores cached responses as JSON files in the given directory.
    Uses atomic writes and secure file permissions.
    """

    def __init__(self, cache_dir: Path, ttl: int = DEFAULT_TTL) -> None:
        self.cache_dir = cache_dir
        self.ttl = ttl
        self._hits = 0
        self._misses = 0
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        set_secure_dir_permissions(self.cache_dir)

    def get(self, url: str, params: dict[str, Any] | None = None) -> CacheEntry | None:
        """Look up a cached response. Returns None if not found or expired."""
        key = _make_cache_key(url, params)
        cache_path = self.cache_dir / f"{key}.json"

        if not cache_path.exists():
            self._misses += 1
            return None

        try:
            data = json.loads(cache_path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            self._misses += 1
            cache_path.unlink(missing_ok=True)
            return None

        cached_at = data.get("cached_at", 0)
        if time.time() - cached_at > self.ttl:
            self._misses += 1
            cache_path.unlink(missing_ok=True)
            return None

        self._hits += 1
        return CacheEntry(
            url=data["url"],
            status_code=data["status_code"],
            headers=data["headers"],
            body=data["body"],
            raw_text=data["raw_text"],
            cached_at=cached_at,
        )

    def put(
        self,
        url: str,
        params: dict[str, Any] | None,
        status_code: int,
        headers: dict[str, str],
        body: Any,
        raw_text: str,
    ) -> None:
        """Store a response in the cache using atomic writes."""
        key = _make_cache_key(url, params)
        cache_path = self.cache_dir / f"{key}.json"

        data = {
            "url": url,
            "params": params,
            "status_code": status_code,
            "headers": headers,
            "body": body,
            "raw_text": raw_text,
            "cached_at": time.time(),
        }

        # Atomic write: tempfile + rename
        fd, tmp_path_str = tempfile.mkstemp(
            dir=self.cache_dir, prefix=".tmp_", suffix=".json"
        )
        tmp_path = Path(tmp_path_str)
        try:
            with open(fd, "w", encoding="utf-8") as f:
                json.dump(data, f)
            tmp_path.replace(cache_path)
            set_secure_file_permissions(cache_path)
        except BaseException:
            tmp_path.unlink(missing_ok=True)
            raise

    def invalidate(self, path_prefix: str) -> int:
        """Invalidate cached entries whose stored URL matches a path prefix.

        Uses segment-aware matching: /api/v1/projects will not match
        /api/v1/projects-archive.

        Returns the number of entries removed.
        """
        removed = 0
        for cache_file in self.cache_dir.glob("*.json"):
            try:
                data = json.loads(cache_file.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError):
                cache_file.unlink(missing_ok=True)
                removed += 1
                continue
            stored_url = data.get("url", "")
            # Segment-aware: url must equal prefix or have / or ? after it
            if stored_url == path_prefix or stored_url.startswith(
                path_prefix + "/"
            ) or stored_url.startswith(path_prefix + "?"):
                cache_file.unlink(missing_ok=True)
                removed += 1
        return removed

    def clear(self) -> int:
        """Remove all cache entries. Returns the number removed."""
        removed = 0
        for cache_file in self.cache_dir.glob("*.json"):
            cache_file.unlink(missing_ok=True)
            removed += 1
        return removed

    def stats(self) -> CacheStats:
        """Return cache usage statistics."""
        size = sum(1 for _ in self.cache_dir.glob("*.json"))
        total = self._hits + self._misses
        hit_rate = self._hits / total if total > 0 else 0.0
        return CacheStats(
            hits=self._hits,
            misses=self._misses,
            size=size,
            hit_rate=hit_rate,
        )
