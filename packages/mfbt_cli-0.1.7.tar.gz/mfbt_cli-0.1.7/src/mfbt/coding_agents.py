"""Modular coding agent checker system.

Provides pre-flight checks to verify that a coding agent is installed
and properly configured (e.g. mfbt MCP server) before starting a Ralph
orchestration loop.
"""

from __future__ import annotations

import json
import shutil
from abc import ABC, abstractmethod
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class CheckResult:
    """Result of a single pre-flight check."""

    passed: bool
    label: str  # e.g. "Claude Code installed"
    detail: str  # e.g. "Found at /usr/local/bin/claude" or error explanation


class CodingAgentChecker(ABC):
    """Abstract base class for coding agent environment checks."""

    name: str  # e.g. "claude"
    display_name: str  # e.g. "Claude Code"

    @abstractmethod
    def check_installed(self) -> CheckResult:
        """Check whether the coding agent binary is available."""
        ...

    @abstractmethod
    def check_mcp_configured(self, project_dir: Path) -> CheckResult:
        """Check whether the mfbt MCP server is configured for the project."""
        ...

    def run_all_checks(self, project_dir: Path) -> list[CheckResult]:
        """Run all pre-flight checks and return results."""
        return [self.check_installed(), self.check_mcp_configured(project_dir)]


class ClaudeCodeChecker(CodingAgentChecker):
    """Pre-flight checker for Claude Code."""

    name = "claude"
    display_name = "Claude Code"

    def check_installed(self) -> CheckResult:
        path = shutil.which("claude")
        if path:
            return CheckResult(
                passed=True,
                label="Claude Code is installed",
                detail=f"Found at {path}",
            )
        return CheckResult(
            passed=False,
            label="Claude Code is not installed",
            detail="'claude' not found on PATH. Install from https://claude.ai/download",
        )

    def check_mcp_configured(self, project_dir: Path) -> CheckResult:
        # 1. Check {project_dir}/.mcp.json
        local_mcp = project_dir / ".mcp.json"
        if local_mcp.is_file():
            try:
                data = json.loads(local_mcp.read_text())
                servers = data.get("mcpServers", {})
                if "mfbt" in servers:
                    return CheckResult(
                        passed=True,
                        label="mfbt MCP server configured",
                        detail=f"Found in {local_mcp}",
                    )
            except (json.JSONDecodeError, OSError):
                pass

        # 2. Check ~/.claude.json for project-scoped config
        #    Structure: { "projects": { "/abs/path": { "mcpServers": { "mfbt": {...} } } } }
        home_claude = Path.home() / ".claude.json"
        if home_claude.is_file():
            try:
                data = json.loads(home_claude.read_text())
                resolved = str(project_dir.resolve())
                projects = data.get("projects", {})
                project_entry = projects.get(resolved, {})
                if isinstance(project_entry, dict):
                    servers = project_entry.get("mcpServers", {})
                    if "mfbt" in servers:
                        return CheckResult(
                            passed=True,
                            label="mfbt MCP server configured",
                            detail=f"Found in ~/.claude.json for {resolved}",
                        )
            except (json.JSONDecodeError, OSError):
                pass

        return CheckResult(
            passed=False,
            label="mfbt MCP server not configured",
            detail=(
                "No mfbt MCP found in .mcp.json or "
                "~/.claude.json for this project directory"
            ),
        )


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------

AGENT_CHECKERS: dict[str, CodingAgentChecker] = {
    "claude": ClaudeCodeChecker(),
}


def get_available_agents() -> list[CodingAgentChecker]:
    """Return all registered coding agent checkers."""
    return list(AGENT_CHECKERS.values())


def get_checker(agent_name: str) -> CodingAgentChecker | None:
    """Look up a checker by agent name."""
    return AGENT_CHECKERS.get(agent_name)
