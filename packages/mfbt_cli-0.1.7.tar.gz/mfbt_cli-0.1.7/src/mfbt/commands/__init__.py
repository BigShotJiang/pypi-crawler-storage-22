"""Command group registration for mfbt CLI."""

from __future__ import annotations

import typer


def register_commands(app: typer.Typer) -> None:
    """Register all command groups with the main app."""
    from mfbt.commands.projects import projects_app
    from mfbt.commands.ralph import ralph_app

    app.add_typer(projects_app, name="projects")
    app.add_typer(ralph_app, name="ralph")
