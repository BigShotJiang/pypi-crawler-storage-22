"""Ralph subcommand — auto-invoke coding agents for feature implementation."""

from __future__ import annotations

import logging
from typing import Any, Optional

import typer
from rich.console import Console

from mfbt.error_handler import handle_errors

logger = logging.getLogger("mfbt.commands.ralph")
console = Console()

ralph_app = typer.Typer(
    name="ralph",
    help="Auto-invoke coding agents to implement pending features",
    invoke_without_command=True,
)


# ---------------------------------------------------------------------------
# Helpers (same pattern as projects.py)
# ---------------------------------------------------------------------------


def _get_api_client(ctx: typer.Context) -> Any:
    """Build an APIClient from ctx.obj."""
    from mfbt.api_client import APIClient
    from mfbt.auth_flow import run_interactive_auth
    from mfbt.token_manager import TokenManager

    config = ctx.obj["config"]
    base_url = config.get("base_url", "https://app.mfbt.ai")

    tm = TokenManager(base_url)

    def _on_auth_required() -> bool:
        console.print("\n[yellow]Session expired. Re-authenticating...[/yellow]")
        return run_interactive_auth(base_url, tm, console)

    return APIClient(base_url, tm, cache=None, on_auth_required=_on_auth_required)


def _require_auth(ctx: typer.Context) -> None:
    """Exit if user is not authenticated."""
    from mfbt.config import is_authenticated

    if not is_authenticated():
        console.print(
            "[red]Error:[/red] Not authenticated. "
            "Run [bold]mfbt auth login[/bold] first."
        )
        raise typer.Exit(code=1)


def _resolve_project_identifier(ctx: typer.Context, identifier: str) -> str:
    """Resolve a project identifier (UUID, short ID, or name) to a UUID."""
    from mfbt.config import get_mfbt_dir
    from mfbt.resolvers import IdentifierCache, ResourceResolver, is_uuid

    if is_uuid(identifier):
        return identifier

    cache_dir = get_mfbt_dir() / "cache"
    cache = IdentifierCache(cache_dir)
    client = _get_api_client(ctx)

    try:
        resolver = ResourceResolver(client, cache, console=console)
        resolved = resolver.resolve(identifier, resource_type="projects")
        return resolved.uuid
    finally:
        client.close()


# ---------------------------------------------------------------------------
# Command
# ---------------------------------------------------------------------------

SUPPORTED_AGENTS = ("claude",)


@ralph_app.callback(invoke_without_command=True)
def ralph(
    ctx: typer.Context,
    coding_agent: str = typer.Option(
        ...,
        "--coding-agent",
        help="Coding agent to use (e.g. 'claude')",
    ),
    project: str = typer.Option(
        ...,
        "--project",
        "-p",
        help="Project ID, short ID, or name",
    ),
    max_turns: Optional[int] = typer.Option(
        None,
        "--max-turns",
        help="Maximum agent conversation turns (passed through to agent CLI)",
    ),
    mode: str = typer.Option(
        "feature-by-feature",
        "--mode",
        help="Orchestration mode: 'feature-by-feature' or 'module-by-module'",
    ),
    phase: Optional[str] = typer.Option(
        None,
        "--phase",
        help="Phase ID, short_id, or url_identifier (auto-detected if only one exists)",
    ),
    quiet: bool = typer.Option(
        False,
        "--quiet",
        "-q",
        help="Suppress live output; only show errors and final summary",
    ),
    yes: bool = typer.Option(
        False,
        "--yes",
        "-y",
        help="Skip confirmation prompt and start immediately",
    ),
    status: bool = typer.Option(
        False,
        "--status",
        help="Show progress status and exit without implementing",
    ),
) -> None:
    """Auto-invoke coding agents to implement pending features."""
    from mfbt.commands.ralph.agent import AgentNotFoundError
    from mfbt.commands.ralph.display import RalphDisplay
    from mfbt.commands.ralph.orchestrator import RalphOrchestrator
    from mfbt.commands.ralph.progress import (
        build_global_feature_list,
        get_phase_progress,
        resolve_phases,
    )
    from mfbt.commands.ralph.types import AgentType, OrchestrationMode, PhaseInfo, RalphConfig

    if status and (quiet or yes):
        console.print(
            "[red]Error:[/red] --status is mutually exclusive with --quiet and --yes."
        )
        raise typer.Exit(code=1)

    _require_auth(ctx)
    obj = ctx.obj
    verbose = obj.get("verbose", False)
    config = obj["config"]

    # Resolve project identifier to UUID
    project_id = _resolve_project_identifier(ctx, project)

    # Validate coding agent
    if coding_agent not in SUPPORTED_AGENTS:
        console.print(
            f"[red]Error:[/red] Agent '{coding_agent}' is not yet supported. "
            f"Supported agents: {', '.join(SUPPORTED_AGENTS)}"
        )
        raise typer.Exit(code=1)
    agent_type = AgentType(coding_agent)

    # Validate orchestration mode
    try:
        orch_mode = OrchestrationMode(mode)
    except ValueError:
        console.print(
            f"[red]Error:[/red] Invalid mode '{mode}'. "
            f"Choose from: feature-by-feature, module-by-module"
        )
        raise typer.Exit(code=1)

    base_url = config.get("base_url", "https://app.mfbt.ai")

    display = RalphDisplay(console, quiet=quiet)

    with handle_errors(console, verbose=verbose):
        client = _get_api_client(ctx)
        try:
            # Resolve phases
            try:
                phases = resolve_phases(client, project_id, phase)
            except (SystemExit, typer.Exit):
                if phase is not None:
                    display.error(
                        f"Phase '{phase}' not found. "
                        "Check the phase ID, short_id, or url_identifier."
                    )
                else:
                    display.error("No active brainstorming phases found.")
                raise typer.Exit(code=1)

            ralph_config = RalphConfig(
                project_id=project_id,
                phases=tuple(phases),
                coding_agent=agent_type,
                mode=orch_mode,
                max_turns=max_turns,
                quiet=quiet,
                base_url=base_url,
            )

            # Fetch progress for each phase
            phases_progress: dict[str, dict] = {
                p.phase_id: get_phase_progress(client, p.phase_id)
                for p in phases
            }

            all_features = build_global_feature_list(
                client, project_id, list(phases), phases_progress
            )
            display.show_status(
                tuple(phases), phases_progress, ralph_config,
                all_features=all_features,
            )

            if status:
                raise typer.Exit(code=0)

            if not yes:
                typer.confirm("Continue?", abort=True)

            from mfbt.commands.ralph.log_capture import RalphLogger
            from mfbt.config import get_mfbt_dir

            log_base_dir = get_mfbt_dir() / "logs"
            ralph_logger = RalphLogger(log_base_dir, agent_type)

            orchestrator = RalphOrchestrator(
                ralph_config, client, display, logger=ralph_logger
            )

            try:
                summary = orchestrator.run()
            except AgentNotFoundError as exc:
                display.error(str(exc))
                raise typer.Exit(code=1) from exc

            exit_code = 1 if summary.failed > 0 else 0
            raise typer.Exit(code=exit_code)
        finally:
            client.close()
