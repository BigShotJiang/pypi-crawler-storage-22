"""API integration for ralph feature discovery and progress tracking."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

from mfbt.commands.ralph.types import FeatureTask, PhaseInfo

if TYPE_CHECKING:
    from mfbt.api_client import APIClient

logger = logging.getLogger("mfbt.commands.ralph.progress")


def resolve_phases(
    client: APIClient,
    project_id: str,
    phase_hint: str | None,
) -> list[PhaseInfo]:
    """Resolve brainstorming phases.

    If *phase_hint* is provided, return a single-element list matching
    by id, short_id, or url_identifier.
    If *phase_hint* is None, return ALL active (non-archived) phases.

    Raises:
        SystemExit via typer.Exit if hint not found or zero active phases.
    """
    import typer

    resp = client.get(f"/api/v1/projects/{project_id}/brainstorming-phases")
    phases: list[dict[str, Any]] = resp.body if isinstance(resp.body, list) else []

    # Filter out archived phases
    active = [p for p in phases if p.get("archived_at") is None]

    if phase_hint is not None:
        for p in active:
            if phase_hint in (p.get("id"), p.get("short_id"), p.get("url_identifier")):
                return [PhaseInfo(p["id"], p["title"])]
        raise typer.Exit(code=1)

    if len(active) == 0:
        raise typer.Exit(code=1)

    return [PhaseInfo(p["id"], p["title"]) for p in active]


def resolve_phase_id(
    client: APIClient,
    project_id: str,
    phase_hint: str | None,
) -> tuple[str, str]:
    """Resolve to a single brainstorming phase ID and title.

    Thin wrapper around :func:`resolve_phases` for backward compatibility.
    Raises SystemExit when multiple phases exist and no hint is given.
    """
    import typer

    phases = resolve_phases(client, project_id, phase_hint)
    if len(phases) != 1 and phase_hint is None:
        raise typer.Exit(code=1)
    return phases[0].phase_id, phases[0].phase_title


def get_phase_progress(client: APIClient, phase_id: str) -> dict[str, Any]:
    """Fetch implementation progress for a brainstorming phase."""
    resp = client.get(
        f"/api/v1/brainstorming-phases/{phase_id}/implementation-progress"
    )
    return resp.body if isinstance(resp.body, dict) else {}


def get_module_progress(client: APIClient, module_id: str) -> dict[str, Any]:
    """Fetch implementation progress for a single module."""
    resp = client.get(
        f"/api/v1/modules/{module_id}/implementation-progress"
    )
    return resp.body if isinstance(resp.body, dict) else {}


def _get_primary_implementation(
    client: APIClient,
    feature_id: str,
) -> dict[str, Any] | None:
    """Fetch the primary implementation for a feature."""
    resp = client.get(f"/api/v1/features/{feature_id}/implementations")
    body = resp.body
    if isinstance(body, dict) and "items" in body:
        impls = body["items"]
    elif isinstance(body, list):
        impls = body
    else:
        impls = []
    for impl in impls:
        if impl.get("is_primary", False):
            return impl
    # Fallback: return first if none marked primary
    return impls[0] if impls else None


def get_all_feature_list(
    client: APIClient,
    project_id: str,
    phase_id: str,
    progress: dict[str, Any],
    phase_title: str = "",
) -> list[dict[str, str]]:
    """Fetch all features (including completed) for display in the TUI table.

    Returns a list of dicts with feature_key, title, module_key, priority,
    phase_title, completion_status, module_id, and phase_id.
    Sorted by feature_key ascending.
    """
    module_map: dict[str, str] = {}
    for m in progress.get("modules", []):
        mid = m.get("module_id", "")
        mkey = m.get("module_key", "")
        if mid and mkey:
            module_map[mid] = mkey

    resp = client.get(
        f"/api/v1/projects/{project_id}/features",
        params={
            "brainstorming_phase_id": phase_id,
            "limit": 500,
        },
    )
    body = resp.body
    if isinstance(body, dict) and "items" in body:
        features = body["items"]
    elif isinstance(body, list):
        features = body
    else:
        features = []

    result = []
    for f in features:
        if f.get("feature_type") != "implementation":
            continue
        feat_module_id = f.get("module_id", "")
        result.append(
            {
                "id": f.get("id", ""),
                "feature_key": f.get("feature_key", ""),
                "title": f.get("title", ""),
                "module_key": module_map.get(feat_module_id, ""),
                "module_id": feat_module_id,
                "priority": f.get("priority", ""),
                "phase_id": phase_id,
                "phase_title": phase_title,
                "completion_status": f.get("completion_status", "pending"),
                "has_spec": f.get("has_spec", False),
                "has_prompt_plan": f.get("has_prompt_plan", False),
                "has_notes": f.get("has_notes", False),
            }
        )
    result.sort(key=lambda x: x["feature_key"])
    return result


def get_orphan_module_features(
    client: APIClient,
    project_id: str,
    orphan_modules: list[dict[str, Any]],
) -> list[dict[str, str]]:
    """Fetch all features for orphan modules (modules not in any phase).

    Returns the same dict format as get_all_feature_list().
    """
    result = []
    for m in orphan_modules:
        mid = m.get("module_id", "")
        mkey = m.get("module_key", "")
        if not mid:
            continue

        resp = client.get(
            f"/api/v1/projects/{project_id}/features",
            params={
                "module_id": mid,
                "limit": 500,
            },
        )
        body = resp.body
        if isinstance(body, dict) and "items" in body:
            features = body["items"]
        elif isinstance(body, list):
            features = body
        else:
            features = []

        for f in features:
            if f.get("feature_type") != "implementation":
                continue
            result.append(
                {
                    "id": f.get("id", ""),
                    "feature_key": f.get("feature_key", ""),
                    "title": f.get("title", ""),
                    "module_key": mkey,
                    "module_id": mid,
                    "priority": f.get("priority", ""),
                    "phase_id": "",
                    "phase_title": "",
                    "completion_status": f.get("completion_status", "pending"),
                    "has_spec": f.get("has_spec", False),
                    "has_prompt_plan": f.get("has_prompt_plan", False),
                    "has_notes": f.get("has_notes", False),
                }
            )
    result.sort(key=lambda x: x["feature_key"])
    return result


def build_global_feature_list(
    client: APIClient,
    project_id: str,
    phases: list[PhaseInfo],
    phases_progress: dict[str, dict[str, Any]],
) -> list[dict[str, Any]]:
    """Build a single sorted list of all features across all phases and orphan modules.

    Fetches features from each phase via get_all_feature_list(), detects orphan
    modules (not associated with any phase), and fetches their features too.
    Returns the combined list sorted by feature_key ascending.
    """
    all_features: list[dict[str, Any]] = []

    # Fetch features from each phase
    for phase in phases:
        progress = phases_progress.get(phase.phase_id, {})
        phase_features = get_all_feature_list(
            client, project_id, phase.phase_id, progress,
            phase_title=phase.phase_title,
        )
        all_features.extend(phase_features)

    # Detect orphan modules
    try:
        resp = client.get(f"/api/v1/projects/{project_id}/modules")
        all_modules = resp.body if isinstance(resp.body, list) else []
        if isinstance(resp.body, dict) and "items" in resp.body:
            all_modules = resp.body["items"]

        phase_module_ids: set[str] = set()
        for progress in phases_progress.values():
            for m in progress.get("modules", []):
                mid = m.get("module_id", "")
                if mid:
                    phase_module_ids.add(mid)

        orphans = [
            {"module_id": m.get("id", ""), "module_key": m.get("module_key", m.get("key", ""))}
            for m in all_modules
            if not m.get("brainstorming_phase_id")
            and m.get("id", "") not in phase_module_ids
        ]

        if orphans:
            orphan_features = get_orphan_module_features(client, project_id, orphans)
            all_features.extend(orphan_features)
    except Exception:
        logger.debug("Failed to fetch orphan modules", exc_info=True)

    all_features.sort(key=lambda x: x.get("feature_key", ""))
    return all_features


def get_next_from_list(
    features: list[dict[str, Any]],
    processed_keys: set[str],
) -> dict[str, Any] | None:
    """Return the first actionable feature from the sorted global list.

    A feature is actionable when:
    - completion_status is not "completed"
    - has_spec and has_prompt_plan are both True
    - feature_key is not in processed_keys

    Returns None when no actionable features remain.
    """
    for f in features:
        key = f.get("feature_key", "")
        if key in processed_keys:
            continue
        if f.get("completion_status") == "completed":
            continue
        if not f.get("has_spec", False) or not f.get("has_prompt_plan", False):
            continue
        return f
    return None


def resolve_feature_task(
    client: APIClient,
    feature_info: dict[str, Any],
) -> FeatureTask | None:
    """Resolve a feature dict (from the global list) into a FeatureTask.

    Fetches the primary implementation and its full details (spec_text,
    prompt_plan_text).  Returns None if no implementation is found.
    """
    feature_id = feature_info.get("id", "")
    if not feature_id:
        return None

    impl_list_item = _get_primary_implementation(client, feature_id)
    if impl_list_item is None:
        logger.warning("No implementation found for feature %s", feature_id)
        return None

    # Fetch full implementation to get spec_text / prompt_plan_text
    impl_resp = client.get(f"/api/v1/implementations/{impl_list_item['id']}")
    impl = impl_resp.body if isinstance(impl_resp.body, dict) else {}

    return FeatureTask(
        feature_id=feature_id,
        feature_key=feature_info.get("feature_key", ""),
        title=feature_info.get("title", ""),
        module_key=feature_info.get("module_key", ""),
        module_title="",
        priority=feature_info.get("priority", ""),
        implementation_id=impl_list_item["id"],
        spec_text=impl.get("spec_text"),
        prompt_plan_text=impl.get("prompt_plan_text"),
        phase_id=feature_info.get("phase_id", ""),
        phase_title=feature_info.get("phase_title", ""),
    )


def verify_feature_completed(client: APIClient, feature_id: str) -> bool:
    """Check if a feature's completion_status is 'completed'."""
    resp = client.get(f"/api/v1/features/{feature_id}")
    body = resp.body if isinstance(resp.body, dict) else {}
    return body.get("completion_status") == "completed"


def get_mcp_config(client: APIClient, project_id: str) -> dict[str, Any]:
    """Fetch MCP connection configuration for the project."""
    resp = client.get(f"/api/v1/projects/{project_id}/mcp-config")
    return resp.body if isinstance(resp.body, dict) else {}
