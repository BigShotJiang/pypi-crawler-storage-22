"""Agent prompt template construction for ralph."""

from __future__ import annotations

from mfbt.commands.ralph.types import FeatureTask, RalphConfig


def build_agent_prompt(
    feature: FeatureTask,
    config: RalphConfig,
) -> str:
    """Build the prompt string passed to the coding agent CLI.

    The prompt includes feature details and MCP VFS instructions so the
    agent can locate specs, read prompt plans, and mark features complete.
    """
    sections: list[str] = []

    # --- Feature details ---
    detail_lines = [
        f"# Feature: {feature.feature_key} — {feature.title}",
        f"- Module: {feature.module_key} ({feature.module_title})",
    ]
    if feature.phase_title:
        detail_lines.append(f"- Phase: {feature.phase_title}")
    detail_lines.append(f"- Priority: {feature.priority}")
    sections.append("\n".join(detail_lines))

    # --- MCP VFS instructions ---
    sections.append(
        "## mfbt MCP Server\n\n"
        "The mfbt MCP server is already configured in your environment. "
        "Use it to read the full spec, prompt plan, and mark progress.\n\n"
        "### Locating the feature\n\n"
        "Use the `find` tool to locate the feature directory by key before "
        "using `cat` or `ls`:\n\n"
        f'- `find / -name "{feature.feature_key}"` to locate the feature directory\n'
        f'- `find / -name "{feature.module_key}"` to locate the module directory\n\n'
        "### Reading spec and prompt plan\n\n"
        "Once you have the feature path, read the spec and prompt plan:\n\n"
        "- `cat <feature-path>/implementations/<impl>/spec.md` for the feature spec\n"
        "- `cat <feature-path>/implementations/<impl>/prompt_plan.md` for the implementation plan\n\n"
        "### Updating progress\n\n"
        "- Mark the feature as in-progress: "
        "`setMetadataValueForKey` with key `in_progress` = `true` on the feature directory.\n"
        "- After implementation, write notes: "
        "`write` to the implementation's `notes.md`.\n"
        "- Mark implementation complete: "
        "`setMetadataValueForKey` with key `is_complete` = `true` on the implementation directory."
    )

    # --- Constraints ---
    sections.append(
        "## Constraints\n\n"
        f"Focus only on implementing feature {feature.feature_key}. "
        "Do not modify unrelated code or work on other features."
    )

    return "\n\n".join(sections)
