"""Reusable Textual widgets for ralph orchestration display."""

from __future__ import annotations

from enum import Enum
from typing import TYPE_CHECKING, Any

from rich.text import Text
from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Vertical
from textual.message import Message
from textual.reactive import reactive
from textual.screen import ModalScreen
from textual.widget import Widget
from textual.widgets import Button, DataTable, Label, RichLog, Static

from mfbt.tui.colors import priority_color
from mfbt.tui.widgets.resource_table import ResourceTable

if TYPE_CHECKING:
    from mfbt.commands.ralph.types import RalphConfig


class RalphStage(Enum):
    """Lifecycle stages for the Ralph panel."""

    LOADING = "loading"
    OVERVIEW = "overview"
    FEATURE_LIST = "feature_list"
    RUNNING = "running"
    PAUSED = "paused"

# Color cycle for shimmer/glisten effect (dim teal -> white -> dim teal)
_GLISTEN_COLORS = [
    "#4a9eaa",
    "#6ecede",
    "#98effa",
    "#d0faff",
    "#ffffff",
    "#d0faff",
    "#98effa",
    "#6ecede",
]


# ---------------------------------------------------------------------------
# Widgets
# ---------------------------------------------------------------------------


_STATUS_COLUMNS: list[tuple[str, str]] = [
    ("module", "MODULE"),
    ("done", "DONE"),
    ("in_progress", "IN PROGRESS"),
    ("pending", "PENDING"),
    ("progress", "PROGRESS"),
]

_STATUS_COLUMNS_MULTI: list[tuple[str, str]] = [
    ("phase", "PHASE"),
    ("module", "MODULE"),
    ("done", "DONE"),
    ("in_progress", "IN PROGRESS"),
    ("pending", "PENDING"),
    ("progress", "PROGRESS"),
]


def _format_status_module_row(data: dict[str, Any]) -> tuple[str, ...]:
    """Format a module progress dict into table cells for the status summary."""
    is_total = data.get("_is_total", False)
    is_orphan = data.get("_is_orphan", False)
    multi_phase = data.get("_multi_phase", False)

    done = data.get("completed_features", 0)
    in_prog = data.get("in_progress_features", 0)
    pending = data.get("pending_features", 0)
    pct = data.get("progress_percent", 0.0)

    if is_total:
        done_str = f"[bold green]{done}[/bold green]" if done else "[dim]0[/dim]"
        in_prog_str = f"[bold yellow]{in_prog}[/bold yellow]" if in_prog else "[dim]0[/dim]"
        pending_str = f"[dim]{pending}[/dim]"
        pct_str = f"[bold]{pct:.0f}%[/bold]"
        row: list[str] = []
        if multi_phase:
            row.append("")
        row.extend(["[bold]Total[/bold]", done_str, in_prog_str, pending_str, pct_str])
        return tuple(row)

    key = data.get("module_key", "")
    title = data.get("title", "")
    label = f"{key} \u2014 {title}" if title else key
    if pct >= 100:
        label = f"[green]{label}[/green]"
    elif done > 0 or in_prog > 0:
        label = f"[yellow]{label}[/yellow]"
    else:
        label = f"[red]{label}[/red]"

    if is_orphan:
        label = f"[italic]{label}[/italic]"

    done_str = f"[green]{done}[/green]" if done else "[dim]0[/dim]"
    in_prog_str = f"[yellow]{in_prog}[/yellow]" if in_prog else "[dim]0[/dim]"
    pending_str = f"[dim]{pending}[/dim]"
    pct_str = f"{pct:.0f}%"

    row = []
    if multi_phase:
        phase_title = data.get("_phase_title", "")
        if is_orphan:
            phase_title = "[dim italic]No Phase[/dim italic]"
        row.append(phase_title)
    row.extend([label, done_str, in_prog_str, pending_str, pct_str])
    return tuple(row)




def _format_spn(has_spec: bool, has_plan: bool, has_notes: bool, dim_all: bool = False) -> str:
    """Format the SPN (Spec/PromptPlan/Notes) indicator."""
    if dim_all:
        s = "[dim]\u2717[/dim]" if not has_spec else "[dim]\u2713[/dim]"
        p = "[dim]\u2717[/dim]" if not has_plan else "[dim]\u2713[/dim]"
        n = "[dim]\u2717[/dim]" if not has_notes else "[dim]\u2713[/dim]"
    else:
        s = "[green]\u2713[/green]" if has_spec else "[red]\u2717[/red]"
        p = "[green]\u2713[/green]" if has_plan else "[red]\u2717[/red]"
        n = "[green]\u2713[/green]" if has_notes else "[dim]\u2717[/dim]"
    return f"{s}{p}{n}"


def _format_unified_feature_row(data: dict[str, Any], multi_phase: bool = False) -> tuple[str, ...]:
    """Format a feature dict into table cells for the unified feature table.

    Includes SPN, PRIORITY, STATUS, TIME, and ATTEMPTS columns.
    TIME and ATTEMPTS default to "-" (populated live during orchestration).
    """
    from mfbt.tui.colors import status_color

    key = data.get("feature_key", "")
    module_key = data.get("module_key", "")
    title = data.get("title", "")
    priority_val = data.get("priority", "")
    completion = data.get("completion_status", "pending")
    has_spec = data.get("has_spec", False)
    has_plan = data.get("has_prompt_plan", False)
    has_notes = data.get("has_notes", False)
    is_completed = completion == "completed"
    # Features without both spec and prompt plan will be skipped
    will_skip = not (has_spec and has_plan) and not is_completed

    if is_completed or will_skip:
        key_str = f"[dim]{key}[/dim]"
        module_str = f"[dim]{module_key}[/dim]"
        title_str = f"[dim]{title}[/dim]"
        priority_str = f"[dim]{priority_val}[/dim]" if priority_val else "[dim]-[/dim]"
        spn_str = _format_spn(has_spec, has_plan, has_notes, dim_all=True)
    else:
        key_str = f"[dim]{key}[/dim]"
        module_str = f"[dim]{module_key}[/dim]"
        title_str = title
        priority_str = priority_color(priority_val) if priority_val else "[dim]-[/dim]"
        spn_str = _format_spn(has_spec, has_plan, has_notes)

    if will_skip:
        status_str = "[dim italic]skip[/dim italic]"
    else:
        status_str = status_color(completion)

    row: list[str] = [key_str]
    if multi_phase:
        phase_title = data.get("phase_title", "")
        if not phase_title:
            phase_title = "[italic]User Generated[/italic]"
        if is_completed or will_skip:
            phase_title = f"[dim]{phase_title}[/dim]"
        row.append(phase_title)
    row.extend([module_str, title_str, spn_str, priority_str, status_str, "[dim]-[/dim]", "[dim]-[/dim]"])
    return tuple(row)


class StatusSummary(Widget):
    """Pre-confirmation status screen showing phase progress summary."""

    def __init__(
        self,
        config: RalphConfig,
        phases_progress: dict[str, dict],
        orphan_modules: list[dict[str, Any]] | None = None,
        all_features: list[dict[str, Any]] | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self._config = config
        self._phases_progress = phases_progress
        self._orphan_modules = orphan_modules or []
        self._all_features = all_features or []

    def compose(self) -> ComposeResult:
        phases = self._config.phases
        multi_phase = len(phases) > 1

        if multi_phase:
            header_text = f"[bold cyan]\\[ralph][/bold cyan] Phases: [bold]{len(phases)} active[/bold]"
        else:
            header_text = f"[bold cyan]\\[ralph][/bold cyan] Phase: [bold]{phases[0].phase_title}[/bold]"

        yield Label(header_text, id="ralph-summary-header")
        yield Label(
            f"  Agent: [bold]{self._config.coding_agent.value}[/bold]"
            f" | Mode: [bold]{self._config.mode.value}[/bold]",
            id="ralph-summary-agent",
        )
        yield ResourceTable(id="ralph-summary-table")

        next_text = self._build_next_text()
        yield Label(next_text, id="ralph-summary-next")
        yield Label(
            "  Press [bold]c[/bold] to continue, [bold]esc[/bold] to go back",
            id="ralph-summary-hint",
        )

    def on_mount(self) -> None:
        table = self.query_one("#ralph-summary-table", ResourceTable)
        rows = self._build_table_data()
        multi_phase = len(self._config.phases) > 1
        columns = _STATUS_COLUMNS_MULTI if multi_phase else _STATUS_COLUMNS
        table.set_rows(rows, columns, _format_status_module_row)
        table.focus()

    def _build_table_data(self) -> list[dict[str, Any]]:
        """Build the list of row dicts for the status table."""
        phases = self._config.phases
        multi_phase = len(phases) > 1
        rows: list[dict[str, Any]] = []

        total_done = 0
        total_in_progress = 0
        total_pending = 0
        total_features = 0

        for phase in phases:
            progress = self._phases_progress.get(phase.phase_id, {})
            modules: list[dict] = progress.get("modules", [])

            for m in modules:
                row = dict(m)
                row["_multi_phase"] = multi_phase
                row["_phase_title"] = phase.phase_title
                rows.append(row)

                total_done += m.get("completed_features", 0)
                total_in_progress += m.get("in_progress_features", 0)
                total_pending += m.get("pending_features", 0)
                total_features += m.get("total_features", 0)

        # Orphan modules
        for m in self._orphan_modules:
            row = dict(m)
            row["_multi_phase"] = multi_phase
            row["_is_orphan"] = True
            rows.append(row)

            total_done += m.get("completed_features", 0)
            total_in_progress += m.get("in_progress_features", 0)
            total_pending += m.get("pending_features", 0)
            total_features += m.get("total_features", 0)

        # Total row
        if total_features > 0:
            overall_pct = (total_done / total_features * 100) if total_features > 0 else 0.0
            rows.append({
                "_is_total": True,
                "_multi_phase": multi_phase,
                "completed_features": total_done,
                "in_progress_features": total_in_progress,
                "pending_features": total_pending,
                "progress_percent": overall_pct,
            })

        return rows

    def _build_next_text(self) -> str:
        """Build the 'Next: <feature>' label text from the local feature list."""
        for f in self._all_features:
            if f.get("completion_status") == "completed":
                continue
            if not f.get("has_spec", False) or not f.get("has_prompt_plan", False):
                continue
            key = f.get("feature_key", "")
            module = f.get("module_key", "")
            suffix = f" ({module})" if module else ""
            return f"  Next: [bold]{key}[/bold]{suffix}"
        return "  [dim]All features completed.[/dim]"


class RalphHeader(Widget):
    """Top header showing phase, agent, mode, and progress."""

    phase_title: reactive[str] = reactive("")
    phase_count: reactive[int] = reactive(1)
    agent_name: reactive[str] = reactive("")
    mode: reactive[str] = reactive("")
    total_features: reactive[int] = reactive(0)
    completed: reactive[int] = reactive(0)
    pending: reactive[int] = reactive(0)
    progress_pct: reactive[float] = reactive(0.0)
    session_state: reactive[str] = reactive("running")

    def render(self) -> str:
        state_icon = {
            "running": "[cyan]\u25b6[/cyan]",
            "complete": "[green]\u2713[/green]",
        }.get(self.session_state, "")

        if self.phase_count > 1:
            phase_label = f"Phases: [bold]{self.phase_count} active[/bold]"
        else:
            phase_label = f"Phase: [bold]{self.phase_title}[/bold]"

        line1 = (
            f" {state_icon} [bold]ralph[/bold]"
            f" \u2014 {phase_label}"
            f" | Agent: [bold]{self.agent_name}[/bold]"
            f" | {self.mode}"
        )
        line2 = (
            f" Progress: {self.completed}/{self.total_features}"
            f" ({self.progress_pct:.0f}%)"
            f" | {self.pending} pending"
        )
        return f"{line1}\n{line2}"

    def _trigger_update(self) -> None:
        self.refresh()

    def watch_phase_title(self, value: str) -> None:
        self._trigger_update()

    def watch_phase_count(self, value: int) -> None:
        self._trigger_update()

    def watch_agent_name(self, value: str) -> None:
        self._trigger_update()

    def watch_mode(self, value: str) -> None:
        self._trigger_update()

    def watch_total_features(self, value: int) -> None:
        self._trigger_update()

    def watch_completed(self, value: int) -> None:
        self._trigger_update()

    def watch_pending(self, value: int) -> None:
        self._trigger_update()

    def watch_progress_pct(self, value: float) -> None:
        self._trigger_update()

    def watch_session_state(self, value: str) -> None:
        self._trigger_update()


class FeatureProgressTable(DataTable):
    """Unified table showing all features with SPN, priority, status, time, and attempts.

    Before a run: shows all features with SPN indicators, TIME/ATTEMPTS as "-".
    During a run: same table updates live with status/time/attempts.
    """

    class ShowLogs(Message):
        """Fired when user presses 'l' to view logs for the selected feature."""

        def __init__(self, feature_key: str) -> None:
            super().__init__()
            self.feature_key = feature_key

    BINDINGS = [
        Binding("j", "cursor_down", "Down", show=False),
        Binding("k", "cursor_up", "Up", show=False),
        Binding("g", "scroll_home", "Top", show=False),
        Binding("G", "scroll_end", "Bottom", show=False),
        Binding("l", "show_logs", "Logs", show=False),
    ]

    _COLUMNS_SINGLE = [
        ("key", "KEY"),
        ("module", "MODULE"),
        ("title", "TITLE"),
        ("spn", "SPN"),
        ("priority", "PRIORITY"),
        ("status", "STATUS"),
        ("time", "TIME"),
        ("attempts", "ATTEMPTS"),
    ]

    _COLUMNS_MULTI = [
        ("key", "KEY"),
        ("phase", "PHASE"),
        ("module", "MODULE"),
        ("title", "TITLE"),
        ("spn", "SPN"),
        ("priority", "PRIORITY"),
        ("status", "STATUS"),
        ("time", "TIME"),
        ("attempts", "ATTEMPTS"),
    ]

    def __init__(self, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self._multi_phase = False
        self._row_data: dict[str, dict] = {}
        self._first_pending_idx: int = 0

    def on_mount(self) -> None:
        self.cursor_type = "row"
        self.zebra_stripes = True

    def populate_all(self, features: list[dict[str, Any]], multi_phase: bool = False) -> None:
        """Populate the table with all features (completed + pending).

        Sets up columns and adds all rows with unified formatting.
        Tracks the index of the first non-completed feature for scroll_to_pending().
        """
        self._multi_phase = multi_phase
        self.clear(columns=True)
        self._row_data.clear()

        columns = self._COLUMNS_MULTI if multi_phase else self._COLUMNS_SINGLE
        for col_key, col_label in columns:
            self.add_column(col_label, key=col_key)

        first_pending = 0
        found_pending = False
        for f in features:
            cells = _format_unified_feature_row(f, multi_phase)
            feature_key = f.get("feature_key", "")
            self.add_row(*cells, key=feature_key)
            self._row_data[feature_key] = f
            if not found_pending and f.get("completion_status", "pending") != "completed":
                found_pending = True
            elif not found_pending:
                first_pending += 1
        self._first_pending_idx = first_pending

    def scroll_to_pending(self) -> None:
        """Move the table cursor to the first non-completed feature."""
        if self.row_count > 0 and self._first_pending_idx < self.row_count:
            self.move_cursor(row=self._first_pending_idx)

    def get_feature_data(self, feature_key: str) -> dict[str, Any] | None:
        """Return the feature data dict for a given feature key."""
        return self._row_data.get(feature_key)

    def update_feature(
        self,
        key: str,
        *,
        status: str | None = None,
        time_str: str | None = None,
        attempts: int | None = None,
    ) -> None:
        """Update an existing feature row."""
        try:
            row_key = self.get_row(key)
        except Exception:
            return

        if status is not None:
            self.update_cell(key, "status", Text.from_markup(status))
        if time_str is not None:
            self.update_cell(key, "time", time_str)
        if attempts is not None:
            self.update_cell(key, "attempts", str(attempts))

    def action_show_logs(self) -> None:
        """Post ShowLogs message for the currently selected feature."""
        if self.row_count == 0:
            return
        row_key = self.coordinate_to_cell_key(self.cursor_coordinate).row_key
        feature_key = str(row_key.value)
        if feature_key:
            self.post_message(self.ShowLogs(feature_key))

    def action_scroll_end(self) -> None:
        if self.row_count > 0:
            self.move_cursor(row=self.row_count - 1)

    def action_scroll_home(self) -> None:
        if self.row_count > 0:
            self.move_cursor(row=0)


class PauseModal(ModalScreen[str]):
    """Modal shown when user presses 'p' to pause orchestration.

    Returns "continue" or "stop" to the callback.
    """

    BINDINGS = [
        Binding("escape", "continue_run", "Continue", priority=True),
    ]

    def compose(self) -> ComposeResult:
        from textual.containers import Horizontal

        with Vertical(id="pause-modal-container"):
            yield Static(
                " [bold yellow]\u23f8 Paused[/bold yellow]",
                id="pause-modal-title",
            )
            yield Static(
                "\n  The current feature will finish.\n"
                "  Choose an action:\n",
                id="pause-modal-body",
            )
            with Horizontal(id="pause-modal-buttons"):
                yield Button("Continue", id="pause-continue", variant="success")
                yield Button("Stop", id="pause-stop", variant="error")
            yield Static(
                " [bold]<esc>[/bold] Continue  ",
                id="pause-modal-hint",
            )

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "pause-continue":
            self.dismiss("continue")
        elif event.button.id == "pause-stop":
            self.dismiss("stop")

    def action_continue_run(self) -> None:
        self.dismiss("continue")


class RalphHelpScreen(ModalScreen):
    """Modal overlay showing ralph-specific keybinding reference."""

    BINDINGS = [
        Binding("escape", "dismiss", "Close", show=False),
        Binding("question_mark", "dismiss", "Close", show=False),
    ]

    def __init__(self, stage: RalphStage, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self._stage = stage

    def compose(self) -> ComposeResult:
        with Vertical(id="help-container"):
            yield Label("[bold #326CE5]Ralph Keyboard Shortcuts[/bold #326CE5]\n")
            yield Static(self._build_help_text())

    def _build_help_text(self) -> str:
        lines: list[str] = []

        def _row(key: str, desc: str) -> str:
            return f"  [bold #326CE5]{key:>10}[/bold #326CE5]  {desc}"

        if self._stage == RalphStage.OVERVIEW:
            lines.append("[bold]Overview[/bold]")
            lines.append(_row("c", "Continue to feature list"))
            lines.append(_row("esc", "Exit ralph"))
        elif self._stage == RalphStage.FEATURE_LIST:
            lines.append("[bold]Feature List[/bold]")
            lines.append(_row("r", "Run orchestration"))
            lines.append(_row("enter", "View feature details"))
            lines.append(_row("esc", "Back to overview"))
        elif self._stage == RalphStage.RUNNING:
            lines.append("[bold]Running[/bold]")
            lines.append(_row("enter", "View feature details"))
            lines.append(_row("l", "View logs for feature"))
            lines.append(_row("p", "Pause orchestration"))
            lines.append(_row("k", "Kill running agent"))
        elif self._stage == RalphStage.PAUSED:
            lines.append("[bold]Stopped[/bold]")
            lines.append(_row("r", "Retry selected feature"))
            lines.append(_row("enter", "View feature details"))
            lines.append(_row("l", "View logs for feature"))

        lines.append("\n[bold]Navigation[/bold]")
        lines.append(_row("j / \u2193", "Move down"))
        lines.append(_row("k / \u2191", "Move up"))
        lines.append(_row("g / G", "Top / Bottom"))

        lines.append("\n[bold]Global[/bold]")
        lines.append(_row("?", "Show this help"))
        lines.append(_row("q", "Quit"))

        return "\n".join(lines)


class AgentOutputLog(RichLog):
    """Scrolling log of agent output with vim navigation."""

    BINDINGS = [
        Binding("j", "scroll_down", "Down", show=False),
        Binding("k", "scroll_up", "Up", show=False),
    ]

    def __init__(self, **kwargs: Any) -> None:
        super().__init__(auto_scroll=True, max_lines=5000, wrap=True, **kwargs)

    def clear_log(self) -> None:
        """Clear all log content."""
        self.clear()


class LogPaneHeader(Static):
    """Header above agent output log — shows 'Implementing <key>' with shimmer."""

    pass


class RalphStatusBar(Static):
    """Bottom status bar showing session counts and elapsed time."""

    succeeded: reactive[int] = reactive(0)
    failed: reactive[int] = reactive(0)
    pending: reactive[int] = reactive(0)
    elapsed_seconds: reactive[float] = reactive(0.0)
    feature_elapsed_seconds: reactive[float] = reactive(0.0)
    show_feature_timer: reactive[bool] = reactive(False)

    def render(self) -> str:
        mins, secs = divmod(int(self.elapsed_seconds), 60)
        elapsed = f"{mins}:{secs:02d}"
        parts = (
            f" [green]\u2713 {self.succeeded}[/green]"
            f"  [red]\u2717 {self.failed}[/red]"
            f"  [dim]\u00b7 {self.pending}[/dim]"
            f"  | [dim]Total:[/dim] {elapsed}"
        )
        if self.show_feature_timer:
            f_mins, f_secs = divmod(int(self.feature_elapsed_seconds), 60)
            f_elapsed = f"{f_mins}:{f_secs:02d}"
            parts += f"  [dim]Feature:[/dim] {f_elapsed}"
        return parts

    def _trigger_update(self) -> None:
        self.update(self.render())

    def watch_succeeded(self, value: int) -> None:
        self._trigger_update()

    def watch_failed(self, value: int) -> None:
        self._trigger_update()

    def watch_pending(self, value: int) -> None:
        self._trigger_update()

    def watch_elapsed_seconds(self, value: float) -> None:
        self._trigger_update()

    def watch_feature_elapsed_seconds(self, value: float) -> None:
        self._trigger_update()

    def watch_show_feature_timer(self, value: bool) -> None:
        self._trigger_update()


# ---------------------------------------------------------------------------
# Log viewer modal
# ---------------------------------------------------------------------------


class _ModalLog(RichLog):
    """RichLog with vim-style scrolling for the log viewer modal."""

    BINDINGS = [
        Binding("j", "scroll_down", "Down", show=False),
        Binding("k", "scroll_up", "Up", show=False),
    ]

    def __init__(self, **kwargs: Any) -> None:
        super().__init__(auto_scroll=False, wrap=True, **kwargs)


class LogViewerModal(ModalScreen):
    """Modal screen showing log file contents for a feature."""

    BINDINGS = [
        Binding("escape", "dismiss", "Close", priority=True),
        Binding("q", "dismiss", "Close", show=False),
    ]

    def __init__(self, content: str, title: str, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self._content = content
        self._title = title

    def compose(self) -> ComposeResult:
        with Vertical(id="log-modal-container"):
            yield Static(self._title, id="log-modal-title")
            yield _ModalLog(id="log-modal-content")
            yield Static(
                " [bold]<esc>[/bold] Close  [bold]j/k[/bold] Scroll",
                id="log-modal-hint",
            )

    def on_mount(self) -> None:
        log = self.query_one("#log-modal-content", _ModalLog)
        for line in self._content.splitlines():
            log.write(Text(line))
