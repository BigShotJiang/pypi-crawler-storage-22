"""TUI display adapter for ralph — updates Textual widgets instead of printing."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Any

from rich.text import Text

if TYPE_CHECKING:
    from mfbt.commands.ralph.types import (
        FeatureResult,
        FeatureTask,
        PhaseInfo,
        RalphConfig,
        SessionSummary,
    )


class RalphTUIDisplay:
    """Implements the same 8-method interface as RalphDisplay,
    but marshals updates to Textual widgets via app.call_from_thread().

    Accepts any widget container that has ralph sub-widgets mounted inside it.
    Uses container.app.call_from_thread() to schedule UI updates.
    """

    def __init__(self, container: Any) -> None:
        self._container = container
        self._feature_num = 0

    def _call_from_thread(self, callback: Any, *args: Any) -> None:
        """Schedule a callback on the main thread via the container's app."""
        self._container.app.call_from_thread(callback, *args)

    # -- Status summary (no-op in TUI — TUI auto-continues) ----------------

    def show_status(
        self,
        phases: "tuple[PhaseInfo, ...]",
        phases_progress: dict[str, dict],
        config: "RalphConfig",
    ) -> None:
        """No-op: TUI path implicitly auto-continues."""

    # -- Session lifecycle ---------------------------------------------------

    def session_start(
        self,
        config: RalphConfig,
        phases: "tuple[PhaseInfo, ...]",
        all_progress: dict[str, dict],
    ) -> None:
        total = sum(p.get("total_features", 0) for p in all_progress.values())
        completed = sum(p.get("completed_features", 0) for p in all_progress.values())
        pending = sum(p.get("pending_features", 0) for p in all_progress.values())
        pct = (completed / total * 100) if total > 0 else 0.0

        phase_count = len(phases)
        phase_title = phases[0].phase_title if phase_count == 1 else ""

        def _update() -> None:
            from mfbt.commands.ralph.ralph_widgets import RalphHeader, RalphStatusBar

            try:
                header = self._container.query_one("#ralph-header", RalphHeader)
                header.phase_title = phase_title
                header.phase_count = phase_count
                header.agent_name = config.coding_agent.value
                header.mode = config.mode.value
                header.total_features = total
                header.completed = completed
                header.pending = pending
                header.progress_pct = pct
            except Exception:
                pass

            try:
                status_bar = self._container.query_one(
                    "#ralph-status-bar", RalphStatusBar
                )
                status_bar.pending = pending
            except Exception:
                pass

        self._call_from_thread(_update)

    def log_directory(self, path: Path) -> None:
        """Store the session log directory and write path to agent output log."""
        self._container.session_log_dir = path

        def _update() -> None:
            from mfbt.commands.ralph.ralph_widgets import AgentOutputLog

            try:
                log = self._container.query_one("#agent-output", AgentOutputLog)
                log.write(Text.from_markup(f"[dim]Logs: {path}[/dim]"))
            except Exception:
                pass

        self._call_from_thread(_update)

    # -- Feature list ---------------------------------------------------------

    def populate_features(self, features: list[dict[str, str]]) -> None:
        """No-op: table is pre-populated by RalphPanel.populate_all()."""
        pass

    # -- Feature lifecycle ---------------------------------------------------

    def feature_start(
        self,
        feature: FeatureTask,
        attempt: int,
        feature_num: int,
        total: int,
    ) -> None:
        import time

        self._feature_num = feature_num
        # Record feature start time for per-feature timer
        self._container._feature_start = time.monotonic()
        self._container._feature_pause_snapshot = self._container._paused_accumulated

        def _update() -> None:
            from mfbt.commands.ralph.ralph_widgets import (
                AgentOutputLog,
                FeatureProgressTable,
                RalphHeader,
            )

            # Tell the container which feature is running (drives glisten animation)
            self._container._running_feature_key = feature.feature_key
            self._container._glisten_frame = 0

            try:
                header = self._container.query_one("#ralph-header", RalphHeader)
                header.session_state = "running"
            except Exception:
                pass

            try:
                table = self._container.query_one(
                    "#feature-table", FeatureProgressTable
                )
                update_kwargs: dict = {
                    "status": "[cyan]\u27f3 running[/cyan]",
                }
                if attempt > 1:
                    update_kwargs["attempts"] = attempt
                table.update_feature(feature.feature_key, **update_kwargs)
            except Exception:
                pass

            try:
                log = self._container.query_one("#agent-output", AgentOutputLog)
                log.clear_log()
                log.write(
                    Text.from_markup(
                        f"[bold cyan]>>> {feature.feature_key}[/bold cyan]"
                        f" \u2014 {feature.title}"
                    )
                )
            except Exception:
                pass

        self._call_from_thread(_update)

    def agent_output(self, line: str) -> None:
        text = line.rstrip("\n")
        if not text:
            return

        def _update() -> None:
            from mfbt.commands.ralph.ralph_widgets import AgentOutputLog

            try:
                log = self._container.query_one("#agent-output", AgentOutputLog)
                # Use Text() directly — do NOT parse agent output as markup,
                # since raw agent stdout can contain literal [/dim] etc.
                text_obj = Text(text)
                text_obj.stylize("dim")
                log.write(text_obj)
            except Exception:
                pass

        self._call_from_thread(_update)

    def feature_complete(self, result: FeatureResult) -> None:
        from mfbt.commands.ralph.types import FeatureOutcome

        fk = result.feature.feature_key
        elapsed = f"{result.elapsed_seconds:.0f}s"

        # Stop glisten animation and feature timer
        self._container._running_feature_key = None
        self._container._feature_start = 0.0

        if result.outcome == FeatureOutcome.SUCCESS:
            status_str = f"[green]\u2713 success[/green]"
        elif result.outcome == FeatureOutcome.FAILED:
            status_str = f"[red]\u2717 failed[/red]"
        else:
            status_str = f"[yellow]\u2013 skipped[/yellow]"

        def _update() -> None:
            from mfbt.commands.ralph.ralph_widgets import (
                FeatureProgressTable,
                LogPaneHeader,
                RalphHeader,
                RalphStatusBar,
            )

            try:
                table = self._container.query_one(
                    "#feature-table", FeatureProgressTable
                )
                table.update_feature(
                    fk,
                    status=status_str,
                    time_str=elapsed,
                    attempts=result.attempts,
                )
            except Exception:
                pass

            # Clear log pane header
            try:
                lph = self._container.query_one("#log-pane-header", LogPaneHeader)
                lph.update("")
            except Exception:
                pass

            # Update status bar counts
            try:
                status_bar = self._container.query_one(
                    "#ralph-status-bar", RalphStatusBar
                )
                if result.outcome == FeatureOutcome.SUCCESS:
                    status_bar.succeeded += 1
                    status_bar.pending = max(0, status_bar.pending - 1)
                elif result.outcome == FeatureOutcome.FAILED:
                    status_bar.failed += 1
                    status_bar.pending = max(0, status_bar.pending - 1)
                else:
                    status_bar.pending = max(0, status_bar.pending - 1)
            except Exception:
                pass

            # Update header completed count
            try:
                header = self._container.query_one("#ralph-header", RalphHeader)
                if result.outcome == FeatureOutcome.SUCCESS:
                    header.completed += 1
                    header.pending = max(0, header.pending - 1)
                    if header.total_features > 0:
                        header.progress_pct = (
                            header.completed / header.total_features * 100
                        )
                else:
                    header.pending = max(0, header.pending - 1)
            except Exception:
                pass

        self._call_from_thread(_update)

    def feature_retry(
        self,
        feature: FeatureTask,
        attempt: int,
        max_attempts: int,
    ) -> None:
        def _update() -> None:
            from mfbt.commands.ralph.ralph_widgets import (
                AgentOutputLog,
                FeatureProgressTable,
            )

            try:
                table = self._container.query_one(
                    "#feature-table", FeatureProgressTable
                )
                table.update_feature(
                    feature.feature_key,
                    status="[yellow]\u27f3 retry[/yellow]",
                    attempts=attempt,
                )
            except Exception:
                pass

            try:
                log = self._container.query_one("#agent-output", AgentOutputLog)
                log.write(
                    Text.from_markup(
                        f"[yellow]Retrying {feature.feature_key}"
                        f" (attempt {attempt}/{max_attempts})[/yellow]"
                    )
                )
            except Exception:
                pass

        self._call_from_thread(_update)

    # -- Session summary -----------------------------------------------------

    def session_summary(self, summary: SessionSummary) -> None:
        # Stop both timers
        self._container._session_stopped = True
        self._container._feature_start = 0.0

        def _update() -> None:
            from mfbt.commands.ralph.ralph_widgets import RalphHeader, RalphStatusBar, RalphStage

            try:
                header = self._container.query_one("#ralph-header", RalphHeader)
                header.session_state = "complete"
            except Exception:
                pass

            try:
                status_bar = self._container.query_one(
                    "#ralph-status-bar", RalphStatusBar
                )
                status_bar.succeeded = summary.succeeded
                status_bar.failed = summary.failed
                status_bar.pending = 0
                status_bar.elapsed_seconds = summary.total_elapsed_seconds
                status_bar.show_feature_timer = False
            except Exception:
                pass

            # Transition to PAUSED so user can retry individual features
            self._container._stage = RalphStage.PAUSED
            self._container._update_hints(
                ("r", "Retry"), ("enter", "Detail"), ("l", "Logs"),
                ("?", "Help"), ("q", "Quit"),
            )

        self._call_from_thread(_update)

    # -- Errors --------------------------------------------------------------

    def error(self, message: str) -> None:
        def _update() -> None:
            from mfbt.commands.ralph.ralph_widgets import AgentOutputLog

            try:
                log = self._container.query_one("#agent-output", AgentOutputLog)
                log.write(Text.from_markup(f"[red]Error: {message}[/red]"))
            except Exception:
                pass

            try:
                self._container.app.notify(message, severity="error")
            except Exception:
                pass

        self._call_from_thread(_update)

    def warn(self, message: str) -> None:
        def _update() -> None:
            from mfbt.commands.ralph.ralph_widgets import AgentOutputLog

            try:
                log = self._container.query_one("#agent-output", AgentOutputLog)
                log.write(Text.from_markup(f"[yellow]{message}[/yellow]"))
            except Exception:
                pass

        self._call_from_thread(_update)
