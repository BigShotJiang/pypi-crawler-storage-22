"""API exception hierarchy for mfbt CLI.

Provides structured exceptions for all API error conditions, with
user-friendly messages and technical details. Covers MCLI-052.
"""

from __future__ import annotations

from typing import Any

# ---------------------------------------------------------------------------
# User-facing error messages
# ---------------------------------------------------------------------------

MSG_AUTH_REQUIRED = "Authentication required. Please run: mfbt auth login"
MSG_TOKEN_LIMIT = (
    "Your plan's token limit has been reached. "
    "Please upgrade your plan or wait for the limit to reset."
)
MSG_NOT_FOUND = "The requested resource was not found."
MSG_VALIDATION_ERROR = "The request was invalid. Please check your input."
MSG_RATE_LIMITED = "Too many requests. Please wait and try again."
MSG_SERVER_ERROR = "The server encountered an error. Please try again later."
MSG_NETWORK_ERROR = (
    "Unable to reach the server. Please check your connection and try again."
)
MSG_RETRY_EXHAUSTED = "The request failed after multiple retries."
MSG_CIRCUIT_BREAKER_OPEN = (
    "Too many consecutive failures. Requests are temporarily blocked."
)
MSG_WEBSOCKET_CONNECTION_FAILED = (
    "Unable to establish a real-time connection. Falling back to polling."
)
MSG_WEBSOCKET_AUTH_FAILED = (
    "WebSocket authentication failed. Please re-authenticate: mfbt auth login"
)
MSG_WEBSOCKET_SUBSCRIPTION_FAILED = (
    "Unable to subscribe to job updates."
)


# ---------------------------------------------------------------------------
# Exception hierarchy
# ---------------------------------------------------------------------------


class APIError(Exception):
    """Base exception for all API errors.

    Parallel to AuthError — they do not share an inheritance chain.
    """

    def __init__(
        self,
        user_message: str,
        *,
        status_code: int | None = None,
        technical_details: str | None = None,
        response_body: Any = None,
    ) -> None:
        super().__init__(user_message)
        self.user_message = user_message
        self.status_code = status_code
        self.technical_details = technical_details
        self.response_body = response_body

    def __str__(self) -> str:
        return self.user_message


class AuthenticationRequired(APIError):
    """HTTP 401 — valid credentials not provided."""

    def __init__(
        self,
        user_message: str = MSG_AUTH_REQUIRED,
        *,
        status_code: int = 401,
        technical_details: str | None = None,
        response_body: Any = None,
    ) -> None:
        super().__init__(
            user_message,
            status_code=status_code,
            technical_details=technical_details,
            response_body=response_body,
        )


class TokenLimitExceeded(APIError):
    """HTTP 402 — plan token limit reached."""

    def __init__(
        self,
        user_message: str = MSG_TOKEN_LIMIT,
        *,
        status_code: int = 402,
        technical_details: str | None = None,
        response_body: Any = None,
    ) -> None:
        super().__init__(
            user_message,
            status_code=status_code,
            technical_details=technical_details,
            response_body=response_body,
        )


class NotFoundError(APIError):
    """HTTP 404 — resource not found (or unauthorized)."""

    def __init__(
        self,
        user_message: str = MSG_NOT_FOUND,
        *,
        status_code: int = 404,
        technical_details: str | None = None,
        response_body: Any = None,
    ) -> None:
        super().__init__(
            user_message,
            status_code=status_code,
            technical_details=technical_details,
            response_body=response_body,
        )


class ValidationError(APIError):
    """HTTP 422 — request validation failed.

    Parses FastAPI's detail array into a readable message.
    """

    def __init__(
        self,
        user_message: str = MSG_VALIDATION_ERROR,
        *,
        status_code: int = 422,
        technical_details: str | None = None,
        response_body: Any = None,
        detail: list[dict[str, Any]] | None = None,
    ) -> None:
        self.detail = detail or []
        if self.detail and user_message == MSG_VALIDATION_ERROR:
            parts: list[str] = []
            for err in self.detail:
                loc = err.get("loc", [])
                msg = err.get("msg", "unknown error")
                field = ".".join(str(p) for p in loc) if loc else "unknown"
                parts.append(f"{field}: {msg}")
            user_message = "Validation error: " + "; ".join(parts)
        super().__init__(
            user_message,
            status_code=status_code,
            technical_details=technical_details,
            response_body=response_body,
        )


class RateLimitExceeded(APIError):
    """HTTP 429 — too many requests."""

    def __init__(
        self,
        user_message: str = MSG_RATE_LIMITED,
        *,
        status_code: int = 429,
        technical_details: str | None = None,
        response_body: Any = None,
        retry_after: float | None = None,
    ) -> None:
        self.retry_after = retry_after
        super().__init__(
            user_message,
            status_code=status_code,
            technical_details=technical_details,
            response_body=response_body,
        )


class ServerError(APIError):
    """HTTP 5xx — server-side failure."""

    def __init__(
        self,
        user_message: str = MSG_SERVER_ERROR,
        *,
        status_code: int = 500,
        technical_details: str | None = None,
        response_body: Any = None,
    ) -> None:
        super().__init__(
            user_message,
            status_code=status_code,
            technical_details=technical_details,
            response_body=response_body,
        )


class NetworkError(APIError):
    """Connection or timeout failure — no HTTP response received."""

    def __init__(
        self,
        user_message: str = MSG_NETWORK_ERROR,
        *,
        status_code: int | None = None,
        technical_details: str | None = None,
        response_body: Any = None,
    ) -> None:
        super().__init__(
            user_message,
            status_code=status_code,
            technical_details=technical_details,
            response_body=response_body,
        )


class RetryExhaustedError(APIError):
    """All retry attempts failed."""

    def __init__(
        self,
        user_message: str = MSG_RETRY_EXHAUSTED,
        *,
        status_code: int | None = None,
        technical_details: str | None = None,
        response_body: Any = None,
        original: Exception | None = None,
    ) -> None:
        self.original = original
        super().__init__(
            user_message,
            status_code=status_code,
            technical_details=technical_details,
            response_body=response_body,
        )


class CircuitBreakerOpenError(APIError):
    """Circuit breaker is open — too many consecutive failures."""

    def __init__(
        self,
        user_message: str = MSG_CIRCUIT_BREAKER_OPEN,
        *,
        status_code: int | None = None,
        technical_details: str | None = None,
        response_body: Any = None,
    ) -> None:
        super().__init__(
            user_message,
            status_code=status_code,
            technical_details=technical_details,
            response_body=response_body,
        )


# ---------------------------------------------------------------------------
# WebSocket exceptions
# ---------------------------------------------------------------------------


class WebSocketError(APIError):
    """Base exception for WebSocket errors."""

    def __init__(
        self,
        user_message: str = MSG_WEBSOCKET_CONNECTION_FAILED,
        *,
        status_code: int | None = None,
        technical_details: str | None = None,
        response_body: Any = None,
    ) -> None:
        super().__init__(
            user_message,
            status_code=status_code,
            technical_details=technical_details,
            response_body=response_body,
        )


class WebSocketAuthError(WebSocketError):
    """WebSocket authentication failed — permanent, do not reconnect."""

    def __init__(
        self,
        user_message: str = MSG_WEBSOCKET_AUTH_FAILED,
        *,
        status_code: int | None = None,
        technical_details: str | None = None,
        response_body: Any = None,
    ) -> None:
        super().__init__(
            user_message,
            status_code=status_code,
            technical_details=technical_details,
            response_body=response_body,
        )


class WebSocketSubscriptionError(WebSocketError):
    """Failed to subscribe to a WebSocket channel."""

    def __init__(
        self,
        user_message: str = MSG_WEBSOCKET_SUBSCRIPTION_FAILED,
        *,
        status_code: int | None = None,
        technical_details: str | None = None,
        response_body: Any = None,
    ) -> None:
        super().__init__(
            user_message,
            status_code=status_code,
            technical_details=technical_details,
            response_body=response_body,
        )
