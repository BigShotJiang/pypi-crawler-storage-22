"""Output formatters for mfbt CLI.

Provides table, JSON, and plain-text formatting for command output,
plus format resolution logic. Covers MCLI-060.
"""

from __future__ import annotations

import json
import sys
from dataclasses import dataclass
from datetime import datetime
from typing import Any

from rich.console import Console
from rich.table import Table, box


# ---------------------------------------------------------------------------
# Column specification
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ColumnSpec:
    """Describes a column for table/plain output."""

    key: str
    header: str
    max_width: int | None = None
    truncate: bool = True


# ---------------------------------------------------------------------------
# Format resolution
# ---------------------------------------------------------------------------


def resolve_format(
    cli_format: str | None = None,
    config_format: str | None = None,
) -> str:
    """Determine the effective output format.

    Priority: CLI flag > config setting > TTY detection (table if tty, json if piped).
    """
    if cli_format is not None:
        return cli_format
    if config_format is not None:
        return config_format
    if sys.stdout.isatty():
        return "table"
    return "json"


# ---------------------------------------------------------------------------
# JSON serialization helper
# ---------------------------------------------------------------------------


def _json_serializer(obj: Any) -> str:
    """Serialize datetime objects to ISO 8601 for JSON output."""
    if isinstance(obj, datetime):
        return obj.isoformat()
    raise TypeError(f"Object of type {type(obj).__name__} is not JSON serializable")


# ---------------------------------------------------------------------------
# Plain-text sanitization
# ---------------------------------------------------------------------------


def _sanitize_plain(value: str) -> str:
    """Sanitize a string for TSV output.

    Replaces tabs with spaces, newlines with literal ``\\n``, and strips
    carriage returns so that each field stays on one TSV column/row.
    """
    return value.replace("\r", "").replace("\t", " ").replace("\n", "\\n")


# ---------------------------------------------------------------------------
# Formatters
# ---------------------------------------------------------------------------


def format_table(
    data: list[dict[str, Any]],
    columns: list[ColumnSpec],
    *,
    title: str | None = None,
    console: Console | None = None,
) -> None:
    """Render data as a Rich table to the console."""
    console = console or Console()

    if not data:
        console.print("No results found.")
        return

    table = Table(title=title, box=box.SIMPLE, show_edge=False)
    for col in columns:
        kwargs: dict[str, Any] = {}
        if col.max_width is not None:
            kwargs["max_width"] = col.max_width
        if not col.truncate:
            kwargs["no_wrap"] = True
        table.add_column(col.header, **kwargs)

    for row in data:
        cells: list[str] = []
        for col in columns:
            value = row.get(col.key, "")
            cells.append(str(value) if value is not None else "")
        table.add_row(*cells)

    console.print(table)


def format_json(
    data: list[dict[str, Any]] | dict[str, Any],
    *,
    single: bool = False,
) -> None:
    """Write data as JSON to stdout.

    If single=True and data is a list with one item, output just that item.
    """
    if single and isinstance(data, list) and len(data) == 1:
        output = data[0]
    else:
        output = data
    print(json.dumps(output, indent=2, default=_json_serializer))


def format_plain(
    data: list[dict[str, Any]],
    columns: list[ColumnSpec],
) -> None:
    """Write data as tab-separated values with a header row."""
    if not data:
        print("No results found.")
        return

    headers = [col.header for col in columns]
    print("\t".join(headers))

    for row in data:
        cells: list[str] = []
        for col in columns:
            value = row.get(col.key, "")
            raw = str(value) if value is not None else ""
            cells.append(_sanitize_plain(raw))
        print("\t".join(cells))


def format_output(
    data: list[dict[str, Any]],
    fmt: str,
    columns: list[ColumnSpec],
    *,
    title: str | None = None,
    console: Console | None = None,
) -> None:
    """Dispatch to the appropriate formatter based on format string."""
    if fmt == "json":
        format_json(data)
    elif fmt == "plain":
        format_plain(data, columns)
    else:
        format_table(data, columns, title=title, console=console)


def format_single_object(
    data: dict[str, Any],
    fields: list[ColumnSpec],
    fmt: str,
    *,
    console: Console | None = None,
) -> None:
    """Format a single object as key-value pairs.

    Table: two-column table (Field / Value).
    JSON: dict output.
    Plain: key\\tvalue lines.
    """
    if fmt == "json":
        format_json(data)
        return

    if fmt == "plain":
        for field in fields:
            value = data.get(field.key, "")
            raw = str(value) if value is not None else ""
            print(f"{field.header}\t{_sanitize_plain(raw)}")
        return

    # Table format: two-column key-value display
    console = console or Console()
    table = Table(box=box.SIMPLE, show_edge=False, show_header=False)
    table.add_column("Field", style="bold")
    table.add_column("Value")
    for field in fields:
        value = data.get(field.key, "")
        table.add_row(field.header, str(value) if value is not None else "")
    console.print(table)
