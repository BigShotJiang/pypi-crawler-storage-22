"""Unified job monitoring with WebSocket and polling fallback.

Provides JobMonitor as the main entry point for monitoring async jobs.
Prefers WebSocket for real-time updates, falls back to HTTP polling when
WebSocket is unavailable. Thread-safe callback layer for future TUI.
Covers MCLI-055 (polling fallback) and MCLI-056 (TUI integration).
"""

from __future__ import annotations

import logging
import threading
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

from mfbt.exceptions import WebSocketAuthError, WebSocketError
from mfbt.websocket_client import WebSocketClient
from mfbt.websocket_types import (
    ConnectionEvent,
    ConnectionEventType,
    JobStatus,
    JobStatusUpdate,
    TransportMode,
)

if TYPE_CHECKING:
    from mfbt.api_client import APIClient
    from mfbt.token_manager import TokenManager

logger = logging.getLogger("mfbt.job_monitor")

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

POLL_INITIAL_INTERVAL = 2.0
POLL_MAX_INTERVAL = 30.0
POLL_BACKOFF_FACTOR = 1.5
WS_RECOVERY_INTERVAL = 60.0
DEFAULT_JOB_TIMEOUT = 300.0


# ---------------------------------------------------------------------------
# Internal: watched job tracking
# ---------------------------------------------------------------------------


@dataclass
class _WatchedJob:
    """Internal state for a job being monitored."""

    job_id: str
    on_update: Callable[[JobStatusUpdate], None] | None = None
    last_status: JobStatus | None = None
    poll_interval: float = POLL_INITIAL_INTERVAL
    stop_event: threading.Event = field(default_factory=threading.Event)


# ---------------------------------------------------------------------------
# JobMonitor
# ---------------------------------------------------------------------------


class JobMonitor:
    """Unified job monitoring facade.

    Prefers WebSocket for real-time updates. Falls back to HTTP polling
    when WebSocket is unavailable. Provides a blocking wait_for_job() API
    for CLI use and per-job callbacks for future TUI integration.
    """

    def __init__(
        self,
        base_url: str,
        token_manager: TokenManager,
        api_client: APIClient,
        *,
        on_transport_change: Callable[[TransportMode], None] | None = None,
        on_event: Callable[[ConnectionEvent], None] | None = None,
        prefer_websocket: bool = True,
    ) -> None:
        self._base_url = base_url
        self._token_manager = token_manager
        self._api_client = api_client
        self._on_transport_change = on_transport_change
        self._on_event = on_event
        self._prefer_websocket = prefer_websocket

        self._transport = TransportMode.NONE
        self._transport_lock = threading.Lock()

        self._ws_client: WebSocketClient | None = None
        self._ws_auth_failed = False

        self._watched_jobs: dict[str, _WatchedJob] = {}
        self._jobs_lock = threading.Lock()

        self._poll_threads: dict[str, threading.Thread] = {}
        self._ws_recovery_thread: threading.Thread | None = None
        self._ws_recovery_stop = threading.Event()

        self._shutdown_event = threading.Event()

    # ---- Properties ---------------------------------------------------------

    @property
    def transport(self) -> TransportMode:
        with self._transport_lock:
            return self._transport

    @property
    def is_websocket_connected(self) -> bool:
        return self._ws_client is not None and self._ws_client.is_connected

    # ---- Public API ---------------------------------------------------------

    def watch_job(
        self,
        job_id: str,
        on_update: Callable[[JobStatusUpdate], None] | None = None,
    ) -> None:
        """Start monitoring a job. Connects WS on first call, falls back to polling."""
        watched = _WatchedJob(job_id=job_id, on_update=on_update)
        with self._jobs_lock:
            self._watched_jobs[job_id] = watched

        # Try WebSocket first
        if self._prefer_websocket and not self._ws_auth_failed:
            if self._ensure_ws_connected():
                assert self._ws_client is not None
                self._ws_client.subscribe(job_id)
                if on_update is not None:
                    self._ws_client.register_handler(job_id, on_update)
                return

        # Fall back to polling
        self._start_polling(watched)

    def stop_watching(self, job_id: str) -> None:
        """Stop monitoring a job."""
        with self._jobs_lock:
            watched = self._watched_jobs.pop(job_id, None)

        if watched is not None:
            watched.stop_event.set()

        if self._ws_client is not None:
            self._ws_client.unsubscribe(job_id)
            self._ws_client.unregister_handler(job_id)

        # Clean up poll thread reference
        self._poll_threads.pop(job_id, None)

    def wait_for_job(
        self,
        job_id: str,
        *,
        timeout: float = DEFAULT_JOB_TIMEOUT,
        on_update: Callable[[JobStatusUpdate], None] | None = None,
    ) -> JobStatusUpdate:
        """Block until a job reaches a terminal status.

        Returns the final JobStatusUpdate. Raises TimeoutError if timeout exceeded.
        """
        result_event = threading.Event()
        final_update: list[JobStatusUpdate] = []

        def _capture_update(update: JobStatusUpdate) -> None:
            if on_update is not None:
                on_update(update)
            if update.status.is_terminal:
                final_update.append(update)
                result_event.set()

        self.watch_job(job_id, on_update=_capture_update)
        try:
            if not result_event.wait(timeout=timeout):
                raise TimeoutError(
                    f"Job {job_id} did not complete within {timeout}s"
                )
            return final_update[0]
        finally:
            self.stop_watching(job_id)

    def shutdown(self) -> None:
        """Clean up all monitoring threads and connections."""
        self._shutdown_event.set()
        self._ws_recovery_stop.set()

        # Stop all watched jobs
        with self._jobs_lock:
            for watched in self._watched_jobs.values():
                watched.stop_event.set()

        # Disconnect WebSocket
        if self._ws_client is not None:
            self._ws_client.disconnect()
            self._ws_client = None

        # Wait for poll threads
        for thread in list(self._poll_threads.values()):
            if thread.is_alive():
                thread.join(timeout=5.0)
        self._poll_threads.clear()

        # Wait for recovery thread
        if self._ws_recovery_thread is not None and self._ws_recovery_thread.is_alive():
            self._ws_recovery_thread.join(timeout=5.0)
            self._ws_recovery_thread = None

        with self._jobs_lock:
            self._watched_jobs.clear()

        self._set_transport(TransportMode.NONE)

    # ---- Internal: WebSocket management -------------------------------------

    def _ensure_ws_connected(self) -> bool:
        """Try to establish a WebSocket connection. Returns True on success."""
        if self._ws_client is not None and self._ws_client.is_connected:
            return True

        if self._ws_auth_failed:
            return False

        try:
            self._ws_client = WebSocketClient(
                self._base_url,
                self._token_manager,
                on_message=None,
                on_event=self._handle_ws_event,
            )
            self._ws_client.connect()
            self._set_transport(TransportMode.WEBSOCKET)
            return True
        except WebSocketAuthError:
            self._ws_auth_failed = True
            logger.warning("WebSocket auth failed — using polling only")
            return False
        except WebSocketError as exc:
            logger.info("WebSocket unavailable (%s) — using polling", exc)
            return False

    def _handle_ws_event(self, event: ConnectionEvent) -> None:
        """Handle WebSocket lifecycle events."""
        if self._on_event is not None:
            try:
                self._on_event(event)
            except Exception:
                logger.debug("Error in on_event callback", exc_info=True)

        if event.event_type == ConnectionEventType.DISCONNECTED:
            # WebSocket lost — switch to polling for all watched jobs
            self._switch_to_polling()
        elif event.event_type == ConnectionEventType.AUTH_FAILED:
            self._ws_auth_failed = True
            self._switch_to_polling()

    def _switch_to_polling(self) -> None:
        """Switch all watched jobs from WebSocket to polling."""
        self._set_transport(TransportMode.POLLING)

        with self._jobs_lock:
            jobs_to_poll = list(self._watched_jobs.values())

        for watched in jobs_to_poll:
            if watched.job_id not in self._poll_threads:
                self._start_polling(watched)

        # Start WS recovery in background
        if not self._ws_auth_failed:
            self._start_ws_recovery()

    def _start_ws_recovery(self) -> None:
        """Periodically try to restore the WebSocket connection."""
        if (
            self._ws_recovery_thread is not None
            and self._ws_recovery_thread.is_alive()
        ):
            return

        self._ws_recovery_stop.clear()
        self._ws_recovery_thread = threading.Thread(
            target=self._ws_recovery_loop,
            name="mfbt-ws-recovery",
            daemon=True,
        )
        self._ws_recovery_thread.start()

    def _ws_recovery_loop(self) -> None:
        """Try to restore WebSocket connection periodically."""
        while not self._ws_recovery_stop.is_set() and not self._shutdown_event.is_set():
            if self._ws_recovery_stop.wait(timeout=WS_RECOVERY_INTERVAL):
                return

            if self._ensure_ws_connected():
                logger.info("WebSocket recovered — switching from polling")
                self._set_transport(TransportMode.WEBSOCKET)

                # Re-subscribe all watched jobs via WS and stop their pollers
                with self._jobs_lock:
                    jobs = list(self._watched_jobs.values())

                assert self._ws_client is not None
                for watched in jobs:
                    watched.stop_event.set()
                    self._ws_client.subscribe(watched.job_id)
                    if watched.on_update is not None:
                        self._ws_client.register_handler(
                            watched.job_id, watched.on_update
                        )
                return

    # ---- Internal: polling fallback (MCLI-055) ------------------------------

    def _start_polling(self, watched: _WatchedJob) -> None:
        """Start a polling thread for a single job."""
        if watched.job_id in self._poll_threads:
            return

        self._set_transport(TransportMode.POLLING)
        thread = threading.Thread(
            target=self._poll_loop,
            args=(watched,),
            name=f"mfbt-poll-{watched.job_id[:8]}",
            daemon=True,
        )
        self._poll_threads[watched.job_id] = thread
        thread.start()

    def _poll_loop(self, watched: _WatchedJob) -> None:
        """Poll the jobs API for status changes."""
        while (
            not watched.stop_event.is_set()
            and not self._shutdown_event.is_set()
        ):
            try:
                update = self._fetch_job_status(watched.job_id)
            except Exception as exc:
                logger.debug("Poll error for job %s: %s", watched.job_id, exc)
                if watched.stop_event.wait(timeout=watched.poll_interval):
                    return
                watched.poll_interval = min(
                    watched.poll_interval * POLL_BACKOFF_FACTOR, POLL_MAX_INTERVAL
                )
                continue

            if update is not None and update.status != watched.last_status:
                watched.last_status = update.status
                if watched.on_update is not None:
                    try:
                        watched.on_update(update)
                    except Exception:
                        logger.debug(
                            "Error in poll callback for %s",
                            watched.job_id,
                            exc_info=True,
                        )

                if update.status.is_terminal:
                    return

            if watched.stop_event.wait(timeout=watched.poll_interval):
                return
            watched.poll_interval = min(
                watched.poll_interval * POLL_BACKOFF_FACTOR, POLL_MAX_INTERVAL
            )

    def _fetch_job_status(self, job_id: str) -> JobStatusUpdate | None:
        """Fetch current job status via the REST API."""
        try:
            response = self._api_client.get(f"/api/v1/jobs/{job_id}")
        except Exception:
            raise

        body: dict[str, Any] = response.body
        if not isinstance(body, dict):
            return None

        status_str = body.get("status", "")
        try:
            status = JobStatus(status_str)
        except ValueError:
            logger.debug("Unknown job status from API: %s", status_str)
            return None

        return JobStatusUpdate(
            job_id=job_id,
            status=status,
            result=body.get("result"),
            error_message=body.get("error_message"),
            progress=body.get("progress"),
        )

    # ---- Internal: transport management -------------------------------------

    def _set_transport(self, mode: TransportMode) -> None:
        """Update the transport mode and fire the callback if changed."""
        with self._transport_lock:
            if self._transport == mode:
                return
            self._transport = mode

        if self._on_transport_change is not None:
            try:
                self._on_transport_change(mode)
            except Exception:
                logger.debug("Error in on_transport_change callback", exc_info=True)

        if self._on_event is not None:
            event = ConnectionEvent(
                event_type=ConnectionEventType.TRANSPORT_CHANGED,
                message=f"Transport changed to {mode.value}",
            )
            try:
                self._on_event(event)
            except Exception:
                logger.debug("Error in on_event callback", exc_info=True)
