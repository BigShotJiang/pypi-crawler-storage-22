"""Cross-platform compatibility layer for mfbt CLI."""

from __future__ import annotations

import logging
import os
import platform
import shutil
import stat
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path

import platformdirs

logger = logging.getLogger("mfbt.platform")


class OSType(Enum):
    """Supported operating systems."""

    WINDOWS = "windows"
    MACOS = "macos"
    LINUX = "linux"
    UNKNOWN = "unknown"


def detect_os() -> OSType:
    """Detect the current operating system."""
    match platform.system():
        case "Windows":
            return OSType.WINDOWS
        case "Darwin":
            return OSType.MACOS
        case "Linux":
            return OSType.LINUX
        case _:
            return OSType.UNKNOWN


@dataclass(frozen=True)
class TerminalCapabilities:
    """Terminal feature detection results."""

    ansi: bool = True
    unicode: bool = True
    color_depth: int = 0
    dimensions: tuple[int, int] = (80, 24)


def detect_terminal() -> TerminalCapabilities:
    """Detect terminal capabilities."""
    try:
        size = shutil.get_terminal_size(fallback=(80, 24))
        dimensions = (size.columns, size.lines)
    except Exception:
        dimensions = (80, 24)

    color_depth = 0
    colorterm = os.environ.get("COLORTERM", "").lower()
    if colorterm in ("truecolor", "24bit"):
        color_depth = 24
    elif colorterm == "256color" or "256color" in os.environ.get("TERM", ""):
        color_depth = 8
    elif os.environ.get("TERM") or os.environ.get("WT_SESSION"):
        color_depth = 4

    ansi = color_depth > 0 or bool(os.environ.get("TERM"))
    unicode_support = detect_os() != OSType.WINDOWS or bool(
        os.environ.get("WT_SESSION")
    )

    return TerminalCapabilities(
        ansi=ansi,
        unicode=unicode_support,
        color_depth=color_depth,
        dimensions=dimensions,
    )


@dataclass(frozen=True)
class PlatformDirs:
    """Platform-specific directory paths."""

    config: Path
    cache: Path
    data: Path


def get_platform_dirs() -> PlatformDirs:
    """Get platform-appropriate directories for mfbt data."""
    return PlatformDirs(
        config=Path(platformdirs.user_config_dir("mfbt")),
        cache=Path(platformdirs.user_cache_dir("mfbt")),
        data=Path(platformdirs.user_data_dir("mfbt")),
    )


@dataclass(frozen=True)
class PlatformInfo:
    """Combined platform information."""

    os_type: OSType
    terminal: TerminalCapabilities
    dirs: PlatformDirs
    python_version: str = field(default_factory=platform.python_version)


def get_platform_info() -> PlatformInfo:
    """Get comprehensive platform information."""
    return PlatformInfo(
        os_type=detect_os(),
        terminal=detect_terminal(),
        dirs=get_platform_dirs(),
    )


def set_secure_file_permissions(path: Path) -> None:
    """Set secure file permissions (owner read/write only).

    On Unix: chmod 0o600. On Windows: relies on NTFS default ACLs.
    """
    if detect_os() == OSType.WINDOWS:
        logger.debug("Skipping chmod on Windows for %s (using NTFS defaults)", path)
        return
    path.chmod(stat.S_IRUSR | stat.S_IWUSR)


def set_secure_dir_permissions(path: Path) -> None:
    """Set secure directory permissions (owner read/write/execute only).

    On Unix: chmod 0o700. On Windows: relies on NTFS default ACLs.
    """
    if detect_os() == OSType.WINDOWS:
        logger.debug("Skipping chmod on Windows for %s (using NTFS defaults)", path)
        return
    path.chmod(stat.S_IRWXU)
