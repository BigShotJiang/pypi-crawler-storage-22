"""Resource identifier resolution for mfbt CLI.

Resolves user-provided identifiers (UUIDs, short IDs, names, URL identifiers)
to canonical UUIDs via cache or API lookup. Covers MCLI-059.
"""

from __future__ import annotations

import json
import logging
import re
import sys
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any

from rich.console import Console

if TYPE_CHECKING:
    from mfbt.api_client import APIClient

logger = logging.getLogger("mfbt.resolvers")

# UUID v4 pattern
_UUID_RE = re.compile(
    r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$",
    re.IGNORECASE,
)

CACHE_TTL = 3600  # 1 hour


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


def is_uuid(identifier: str) -> bool:
    """Return True if identifier looks like a UUID v4."""
    return bool(_UUID_RE.match(identifier))


@dataclass(frozen=True)
class ResolvedIdentifier:
    """Result of resolving a user-provided identifier."""

    uuid: str
    name: str | None = None
    short_id: str | None = None
    url_identifier: str | None = None
    source: str = "api"  # "cache", "api", or "passthrough"


# ---------------------------------------------------------------------------
# Identifier cache
# ---------------------------------------------------------------------------


class IdentifierCache:
    """File-based cache for resolved identifiers.

    Structure: {"project": {"<uuid>": {"name": ..., "short_id": ..., "url_identifier": ..., "cached_at": ...}}}
    """

    def __init__(self, cache_dir: Path) -> None:
        self._path = cache_dir / "identifiers.json"
        self._data: dict[str, Any] | None = None

    def _load(self) -> dict[str, Any]:
        if self._data is not None:
            return self._data
        try:
            raw = self._path.read_text(encoding="utf-8")
            data = json.loads(raw)
            if not isinstance(data, dict):
                data = {}
        except (FileNotFoundError, json.JSONDecodeError, OSError):
            data = {}
        self._data = data
        return data

    def _save(self) -> None:
        if self._data is None:
            return
        self._path.parent.mkdir(parents=True, exist_ok=True)
        fd, tmp_path_str = tempfile.mkstemp(
            dir=self._path.parent, prefix=".tmp_", suffix=".json"
        )
        tmp_path = Path(tmp_path_str)
        try:
            with open(fd, "w", encoding="utf-8") as f:
                json.dump(self._data, f, indent=2)
                f.write("\n")
            tmp_path.replace(self._path)
        except BaseException:
            tmp_path.unlink(missing_ok=True)
            raise

    def get(
        self, resource_type: str, identifier: str
    ) -> ResolvedIdentifier | None:
        """Look up an identifier by exact match on uuid, name, short_id, or url_identifier."""
        data = self._load()
        entries = data.get(resource_type, {})
        now = time.time()

        for uuid_key, entry in entries.items():
            cached_at = entry.get("cached_at", 0)
            if now - cached_at > CACHE_TTL:
                continue
            if identifier == uuid_key:
                return self._entry_to_resolved(uuid_key, entry)
            for field in ("name", "short_id", "url_identifier"):
                if entry.get(field) == identifier:
                    return self._entry_to_resolved(uuid_key, entry)
        return None

    def prefix_match(
        self, resource_type: str, prefix: str
    ) -> list[ResolvedIdentifier]:
        """Find all entries whose name or short_id starts with prefix."""
        data = self._load()
        entries = data.get(resource_type, {})
        now = time.time()
        matches: list[ResolvedIdentifier] = []

        prefix_lower = prefix.lower()
        for uuid_key, entry in entries.items():
            cached_at = entry.get("cached_at", 0)
            if now - cached_at > CACHE_TTL:
                continue
            name = entry.get("name", "")
            short_id = entry.get("short_id", "")
            url_id = entry.get("url_identifier", "")
            if (
                (name and name.lower().startswith(prefix_lower))
                or (short_id and short_id.lower().startswith(prefix_lower))
                or (url_id and url_id.lower().startswith(prefix_lower))
            ):
                matches.append(self._entry_to_resolved(uuid_key, entry))
        return matches

    def populate(
        self,
        resource_type: str,
        items: list[dict[str, Any]],
    ) -> None:
        """Populate cache from a list of API response items."""
        data = self._load()
        if resource_type not in data:
            data[resource_type] = {}
        now = time.time()

        for item in items:
            uuid_key = item.get("id")
            if uuid_key is None:
                continue
            data[resource_type][uuid_key] = {
                "name": item.get("name"),
                "short_id": item.get("short_id"),
                "url_identifier": item.get("url_identifier"),
                "cached_at": now,
            }
        self._data = data
        self._save()

    def invalidate(self, resource_type: str | None = None) -> None:
        """Invalidate cache for a resource type, or all if None."""
        data = self._load()
        if resource_type is None:
            self._data = {}
        else:
            data.pop(resource_type, None)
            self._data = data
        self._save()

    @staticmethod
    def _entry_to_resolved(
        uuid_key: str, entry: dict[str, Any]
    ) -> ResolvedIdentifier:
        return ResolvedIdentifier(
            uuid=uuid_key,
            name=entry.get("name"),
            short_id=entry.get("short_id"),
            url_identifier=entry.get("url_identifier"),
            source="cache",
        )


# ---------------------------------------------------------------------------
# Resource resolver
# ---------------------------------------------------------------------------


class ResourceResolver:
    """Resolves user-provided identifiers to UUIDs.

    Resolution order:
    1. UUID pass-through
    2. Cache exact match
    3. API call (GET /api/v1/{resource_type}/{identifier})
    4. Cache prefix match with disambiguation
    """

    def __init__(
        self,
        api_client: APIClient,
        cache: IdentifierCache,
        console: Console | None = None,
    ) -> None:
        self._api = api_client
        self._cache = cache
        self._console = console or Console()

    def resolve(
        self, identifier: str, resource_type: str = "projects"
    ) -> ResolvedIdentifier:
        """Resolve an identifier to a ResolvedIdentifier."""
        # 1. UUID pass-through
        if is_uuid(identifier):
            return ResolvedIdentifier(
                uuid=identifier, source="passthrough"
            )

        # 2. Cache exact match
        cached = self._cache.get(resource_type, identifier)
        if cached is not None:
            return cached

        # 3. API call — the backend accepts short_id/url_identifier
        from mfbt.exceptions import NotFoundError

        try:
            response = self._api.get(f"/api/v1/{resource_type}/{identifier}")
            body = response.body
            if isinstance(body, dict) and "id" in body:
                # Cache the result
                self._cache.populate(resource_type, [body])
                return ResolvedIdentifier(
                    uuid=body["id"],
                    name=body.get("name"),
                    short_id=body.get("short_id"),
                    url_identifier=body.get("url_identifier"),
                    source="api",
                )
        except NotFoundError:
            pass

        # 4. Cache prefix match with disambiguation
        matches = self._cache.prefix_match(resource_type, identifier)
        if len(matches) == 1:
            return matches[0]
        if len(matches) > 1:
            return self._disambiguate(matches)

        # Nothing found
        from mfbt.exceptions import NotFoundError as NFE

        raise NFE(
            f"Could not resolve identifier: {identifier}",
            technical_details=f"No {resource_type} found matching '{identifier}'",
        )

    def _disambiguate(
        self, matches: list[ResolvedIdentifier]
    ) -> ResolvedIdentifier:
        """Prompt user to select from multiple matches."""
        self._console.print("\nMultiple matches found:")
        for i, match in enumerate(matches, 1):
            label = match.name or match.short_id or match.uuid
            self._console.print(f"  {i}. {label} ({match.uuid[:8]}...)")

        self._console.print()
        while True:
            try:
                raw = input("Select [1]: ").strip()
                if not raw:
                    return matches[0]
                idx = int(raw)
                if 1 <= idx <= len(matches):
                    return matches[idx - 1]
                self._console.print(
                    f"[red]Please enter a number between 1 and {len(matches)}[/red]"
                )
            except (ValueError, EOFError):
                return matches[0]
