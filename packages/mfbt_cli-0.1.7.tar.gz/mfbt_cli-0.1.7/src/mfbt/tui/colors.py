"""Color helpers for k9s-style TUI rendering.

Provides Rich markup functions for priority badges, status indicators,
boolean fields, and completion bars.
"""

from __future__ import annotations


def priority_color(priority: str) -> str:
    """Return Rich-markup colored priority string."""
    match priority.lower():
        case "must_have":
            return "[bold red]must_have[/bold red]"
        case "important":
            return "[bold yellow]important[/bold yellow]"
        case "optional":
            return "[dim]optional[/dim]"
        case _:
            return f"[dim]{priority}[/dim]"


def status_color(status: str) -> str:
    """Return Rich-markup colored status string."""
    match status.lower():
        case "completed":
            return "[bold green]completed[/bold green]"
        case "in_progress":
            return "[bold cyan]in_progress[/bold cyan]"
        case "pending":
            return "[dim]pending[/dim]"
        case "active":
            return "[bold green]active[/bold green]"
        case "archived":
            return "[dim]archived[/dim]"
        case "draft":
            return "[yellow]draft[/yellow]"
        case _:
            return f"[dim]{status}[/dim]"


def bool_indicator(value: bool) -> str:
    """Return a colored check/cross indicator."""
    if value:
        return "[green]\u2713[/green]"
    return "[dim]\u2717[/dim]"


def completion_bar(percent: float, width: int = 10) -> str:
    """Return a text-based completion bar with percentage.

    Args:
        percent: 0.0 to 1.0 (or 0 to 100).
        width: Character width of the bar.
    """
    if percent > 1.0:
        percent = percent / 100.0
    percent = max(0.0, min(1.0, percent))
    filled = int(percent * width)
    empty = width - filled
    pct_str = f"{percent:.0%}"

    if percent >= 1.0:
        color = "green"
    elif percent >= 0.5:
        color = "cyan"
    elif percent > 0.0:
        color = "yellow"
    else:
        color = "dim"

    bar = f"[{color}]{'█' * filled}{'░' * empty}[/{color}]"
    return f"{bar} {pct_str}"
