"""Data provider for the TUI layer.

Wraps APIClient to normalize responses into a consistent DataPage format.
All methods are synchronous — designed to be called from Textual workers
with ``thread=True``.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from mfbt.api_client import APIClient

logger = logging.getLogger("mfbt.tui.data_provider")


@dataclass(frozen=True)
class DataPage:
    """A normalized page of results from the API."""

    items: list[dict[str, Any]]
    total: int
    has_more: bool


class TUIDataProvider:
    """Provides data for the TUI by wrapping the APIClient.

    Normalizes both plain-array and paginated API responses into DataPage.
    """

    def __init__(self, api_client: APIClient) -> None:
        self._client = api_client

    def fetch_projects(self, limit: int = 50, offset: int = 0) -> DataPage:
        """Fetch accessible projects.

        GET /api/v1/projects returns a plain array.
        """
        response = self._client.get("/api/v1/projects")
        body = response.body
        items: list[dict[str, Any]] = body if isinstance(body, list) else []
        items = [p for p in items if not p.get("deleted_at")]
        # Apply client-side pagination on the plain array
        total = len(items)
        page = items[offset : offset + limit]
        has_more = (offset + limit) < total
        return DataPage(items=page, total=total, has_more=has_more)

    def fetch_modules(
        self, project_id: str, limit: int = 50, offset: int = 0
    ) -> DataPage:
        """Fetch modules for a project.

        GET /api/v1/projects/{id}/modules returns a plain array.
        """
        response = self._client.get(f"/api/v1/projects/{project_id}/modules")
        body = response.body
        items: list[dict[str, Any]] = body if isinstance(body, list) else []
        total = len(items)
        page = items[offset : offset + limit]
        has_more = (offset + limit) < total
        return DataPage(items=page, total=total, has_more=has_more)

    def fetch_features(
        self,
        project_id: str,
        module_id: str | None = None,
        limit: int = 25,
        offset: int = 0,
    ) -> DataPage:
        """Fetch features for a project, optionally filtered by module.

        GET /api/v1/projects/{id}/features returns a paginated response
        with {items, total, limit, offset, ...}.
        """
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if module_id is not None:
            params["module_id"] = module_id
        response = self._client.get(
            f"/api/v1/projects/{project_id}/features", params=params
        )
        body = response.body
        if isinstance(body, dict) and "items" in body:
            items = body["items"]
            total = body.get("total", len(items))
            has_more = (offset + limit) < total
            return DataPage(items=items, total=total, has_more=has_more)
        # Fallback: treat as plain array
        items = body if isinstance(body, list) else []
        return DataPage(items=items, total=len(items), has_more=False)

    def fetch_project_detail(self, project_id: str) -> dict[str, Any]:
        """Fetch a single project by ID.

        GET /api/v1/projects/{project_id}
        """
        response = self._client.get(f"/api/v1/projects/{project_id}")
        return response.body if isinstance(response.body, dict) else {}

    def fetch_module_detail(self, module_id: str) -> dict[str, Any]:
        """Fetch a single module by ID.

        GET /api/v1/modules/{module_id}
        """
        response = self._client.get(f"/api/v1/modules/{module_id}")
        return response.body if isinstance(response.body, dict) else {}

    def fetch_feature_detail(self, feature_id: str) -> dict[str, Any]:
        """Fetch a single feature by ID.

        GET /api/v1/features/{feature_id}
        """
        response = self._client.get(f"/api/v1/features/{feature_id}")
        return response.body if isinstance(response.body, dict) else {}

    def fetch_feature_sidebar(self, feature_id: str) -> dict[str, Any]:
        """Fetch sidebar data for a feature.

        GET /api/v1/features/{feature_id}/sidebar-data
        """
        response = self._client.get(
            f"/api/v1/features/{feature_id}/sidebar-data"
        )
        return response.body if isinstance(response.body, dict) else {}

    def fetch_implementations(
        self, feature_id: str, limit: int = 50, offset: int = 0
    ) -> DataPage:
        """Fetch implementations for a feature.

        GET /api/v1/features/{feature_id}/implementations
        """
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        response = self._client.get(
            f"/api/v1/features/{feature_id}/implementations", params=params
        )
        body = response.body
        if isinstance(body, dict) and "items" in body:
            items = body["items"]
            total = body.get("total", len(items))
            has_more = (offset + limit) < total
            return DataPage(items=items, total=total, has_more=has_more)
        items = body if isinstance(body, list) else []
        return DataPage(items=items, total=len(items), has_more=False)

    def fetch_implementation_detail(
        self, implementation_id: str
    ) -> dict[str, Any]:
        """Fetch a single implementation by ID.

        GET /api/v1/implementations/{implementation_id}
        """
        response = self._client.get(
            f"/api/v1/implementations/{implementation_id}"
        )
        return response.body if isinstance(response.body, dict) else {}

    def fetch_implementation_sidebar(
        self, implementation_id: str
    ) -> dict[str, Any]:
        """Fetch sidebar data for an implementation.

        GET /api/v1/implementations/{implementation_id}/sidebar-data
        """
        response = self._client.get(
            f"/api/v1/implementations/{implementation_id}/sidebar-data"
        )
        return response.body if isinstance(response.body, dict) else {}

    def fetch_conversation(self, conversation_id: str) -> dict[str, Any]:
        """Fetch a conversation by ID.

        GET /api/v1/conversations/{conversation_id}
        """
        response = self._client.get(
            f"/api/v1/conversations/{conversation_id}"
        )
        return response.body if isinstance(response.body, dict) else {}

    def fetch_brainstorming_phases(
        self, project_id: str
    ) -> list[dict[str, Any]]:
        """Fetch brainstorming phases for a project.

        GET /api/v1/projects/{project_id}/brainstorming-phases
        """
        response = self._client.get(
            f"/api/v1/projects/{project_id}/brainstorming-phases"
        )
        body = response.body
        if isinstance(body, list):
            return body
        if isinstance(body, dict) and "items" in body:
            return body["items"]
        return []

    def fetch_phase_progress(self, phase_id: str) -> dict[str, Any]:
        """Fetch implementation progress for a brainstorming phase.

        GET /api/v1/brainstorming-phases/{phase_id}/implementation-progress
        """
        response = self._client.get(
            f"/api/v1/brainstorming-phases/{phase_id}/implementation-progress"
        )
        return response.body if isinstance(response.body, dict) else {}

    def fetch_job_status(self, job_id: str) -> dict[str, Any]:
        """Fetch current status of a job.

        GET /api/v1/jobs/{job_id}
        """
        response = self._client.get(f"/api/v1/jobs/{job_id}")
        return response.body if isinstance(response.body, dict) else {}
