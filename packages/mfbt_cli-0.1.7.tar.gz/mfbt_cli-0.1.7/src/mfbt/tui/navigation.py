"""Navigation state management for the TUI.

Tracks hierarchical navigation through Projects > Phases > Modules > Features
using a stack-based model. Pure data — no UI dependencies.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class NavigationLevel(Enum):
    """Hierarchical navigation levels in the TUI."""

    PROJECTS = "projects"
    PHASES = "phases"
    MODULES = "modules"
    FEATURES = "features"


@dataclass
class NavigationItem:
    """A selected item in the navigation stack."""

    id: str
    name: str
    level: NavigationLevel
    key: str = ""
    metadata: dict = field(default_factory=dict)


@dataclass
class NavigationState:
    """Mutable navigation state tracking the drill-down stack.

    The stack records each selection: e.g. [project, phase, module].
    The current level is determined by the stack depth.
    """

    stack: list[NavigationItem] = field(default_factory=list)

    @property
    def level(self) -> NavigationLevel:
        """Current navigation level based on stack depth."""
        depth = len(self.stack)
        if depth == 0:
            return NavigationLevel.PROJECTS
        if depth == 1:
            return NavigationLevel.PHASES
        if depth == 2:
            return NavigationLevel.MODULES
        return NavigationLevel.FEATURES

    @property
    def breadcrumb_path(self) -> str:
        """Human-readable breadcrumb string."""
        parts = ["Projects"]
        for item in self.stack:
            parts.append(item.name)
        return " > ".join(parts)

    @property
    def breadcrumb_path_rich(self) -> str:
        """Rich-markup breadcrumb with colored separators and entity keys."""
        parts = ["[bold]Projects[/bold]"]
        sep = " [bold cyan]>[/bold cyan] "
        for item in self.stack:
            segment = f"[bold]{item.name}[/bold]"
            if item.key:
                segment += f" [dim]({item.key})[/dim]"
            parts.append(segment)
        return sep.join(parts)

    @property
    def current_project_id(self) -> str | None:
        """ID of the currently selected project, or None."""
        if len(self.stack) >= 1:
            return self.stack[0].id
        return None

    @property
    def current_phase_id(self) -> str | None:
        """ID of the currently selected phase, or None."""
        if len(self.stack) >= 2:
            return self.stack[1].id
        return None

    @property
    def current_module_id(self) -> str | None:
        """ID of the currently selected module, or None."""
        if len(self.stack) >= 3:
            return self.stack[2].id
        return None

    def drill_down(self, item: NavigationItem) -> None:
        """Push an item onto the navigation stack."""
        self.stack.append(item)

    def go_up(self) -> NavigationItem | None:
        """Pop the top item from the stack. Returns the popped item or None."""
        if self.stack:
            return self.stack.pop()
        return None

    def reset(self) -> None:
        """Clear the navigation stack, returning to the root level."""
        self.stack.clear()
