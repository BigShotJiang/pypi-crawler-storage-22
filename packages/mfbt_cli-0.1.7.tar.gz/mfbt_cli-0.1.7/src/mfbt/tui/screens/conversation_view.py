"""Conversation view modal screen for the TUI.

Renders conversation messages with author, timestamp, and markdown content.
Scrollable with j/k navigation.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Container, VerticalScroll
from textual.screen import ModalScreen
from textual.widgets import Label, Static

if TYPE_CHECKING:
    from mfbt.tui.data_provider import TUIDataProvider

logger = logging.getLogger("mfbt.tui.screens.conversation_view")

_AUTHOR_COLORS = {
    "system": "dim",
    "assistant": "cyan",
    "user": "green",
    "agent": "yellow",
}


class ConversationScreen(ModalScreen):
    """Modal overlay showing conversation messages."""

    BINDINGS = [
        Binding("escape", "dismiss", "Close", show=False),
        Binding("j", "scroll_down", "Down", show=False),
        Binding("k", "scroll_up", "Up", show=False),
    ]

    def __init__(
        self,
        data_provider: TUIDataProvider,
        conversation_id: str,
        title: str = "Conversation",
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self._data_provider = data_provider
        self._conversation_id = conversation_id
        self._title = title

    def compose(self) -> ComposeResult:
        with Container(classes="modal-container"):
            yield Label(
                f"[bold #326CE5]Conversation:[/bold #326CE5] "
                f"[bold]{self._title}[/bold]"
            )
            with VerticalScroll(id="conv-scroll"):
                yield Static(
                    "[dim]Loading messages...[/dim]", id="conv-messages"
                )
            yield Label(
                "[dim]Press [bold]j/k[/bold] to scroll, "
                "[bold]esc[/bold] to close[/dim]"
            )

    def on_mount(self) -> None:
        self.run_worker(self._load_messages, thread=True)

    def _load_messages(self) -> None:
        """Fetch and render conversation messages."""
        try:
            data = self._data_provider.fetch_conversation(self._conversation_id)
            messages = data.get("messages", data.get("items", []))

            if not messages:
                self.app.call_from_thread(
                    self._update_content, "[dim]No messages in this conversation[/dim]"
                )
                return

            lines: list[str] = []
            for msg in messages:
                author = msg.get("author", msg.get("role", "unknown"))
                color = _AUTHOR_COLORS.get(author, "white")
                timestamp = msg.get("created_at", "")
                if timestamp and len(timestamp) > 16:
                    timestamp = timestamp[:16]
                body = msg.get("body", msg.get("content", ""))

                lines.append(
                    f"[bold {color}]{author}[/bold {color}]"
                    + (f"  [dim]{timestamp}[/dim]" if timestamp else "")
                )
                lines.append(body)
                lines.append("")

            self.app.call_from_thread(self._update_content, "\n".join(lines))
        except Exception:
            logger.exception("Failed to load conversation")
            self.app.call_from_thread(
                self._update_content, "[red]Failed to load conversation[/red]"
            )

    def _update_content(self, text: str) -> None:
        try:
            content = self.query_one("#conv-messages", Static)
            content.update(text)
        except Exception:
            pass

    def action_scroll_down(self) -> None:
        try:
            scroll = self.query_one("#conv-scroll", VerticalScroll)
            scroll.scroll_down()
        except Exception:
            pass

    def action_scroll_up(self) -> None:
        try:
            scroll = self.query_one("#conv-scroll", VerticalScroll)
            scroll.scroll_up()
        except Exception:
            pass
