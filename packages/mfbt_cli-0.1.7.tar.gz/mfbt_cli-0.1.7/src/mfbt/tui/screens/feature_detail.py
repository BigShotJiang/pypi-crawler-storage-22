"""Feature detail modal screen for the TUI.

90% viewport overlay with tabbed content: Spec, Prompt Plan, Notes,
Implementations, Conversations. Number keys 1-5 switch tabs.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Container
from textual.screen import ModalScreen
from textual.widgets import DataTable, Label, Static

from mfbt.tui.colors import bool_indicator, priority_color, status_color
from mfbt.tui.widgets.markdown_viewer import MarkdownViewer
from mfbt.tui.widgets.metadata_panel import MetadataPanel

if TYPE_CHECKING:
    from mfbt.tui.data_provider import TUIDataProvider

logger = logging.getLogger("mfbt.tui.screens.feature_detail")

_TABS = [
    ("1", "Spec"),
    ("2", "Prompt Plan"),
    ("3", "Notes"),
    ("4", "Implementations"),
    ("5", "Conversations"),
]


class FeatureDetailScreen(ModalScreen):
    """Modal overlay showing feature details with tabbed content."""

    BINDINGS = [
        Binding("escape", "dismiss", "Close", show=False),
        Binding("1", "tab_1", "Spec", show=False),
        Binding("2", "tab_2", "Prompt Plan", show=False),
        Binding("3", "tab_3", "Notes", show=False),
        Binding("4", "tab_4", "Implementations", show=False),
        Binding("5", "tab_5", "Conversations", show=False),
        Binding("j", "scroll_down", "Down", show=False),
        Binding("k", "scroll_up", "Up", show=False),
    ]

    def __init__(
        self,
        data_provider: TUIDataProvider,
        feature_id: str,
        feature_data: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self._data_provider = data_provider
        self._feature_id = feature_id
        self._feature_data = feature_data or {}
        self._sidebar_data: dict[str, Any] = {}
        self._impl_data: dict[str, Any] = {}
        self._active_tab = 1
        self._loaded_tabs: set[int] = set()
        self._tab_content: dict[int, str] = {}

    def compose(self) -> ComposeResult:
        title = self._feature_data.get("title", "Feature Detail")
        key = self._feature_data.get("feature_key", self._feature_data.get("key", ""))

        meta_fields = {
            "title": title,
            "key": key,
            "priority": self._feature_data.get("priority", ""),
            "status": self._feature_data.get(
                "completion_status", self._feature_data.get("status", "")
            ),
            "category": self._feature_data.get("category", ""),
            "has_spec": self._feature_data.get("has_spec", False),
            "has_prompt_plan": self._feature_data.get("has_prompt_plan", False),
        }

        with Container(classes="modal-container"):
            yield MetadataPanel(
                {k: v for k, v in meta_fields.items() if v is not None and v != ""},
                id="feature-meta",
            )
            yield Static(self._render_tab_bar(), id="tab-bar", classes="tab-bar")
            yield MarkdownViewer(id="content-viewer")
            yield DataTable(id="impl-table")
            yield Static(id="conv-content")
            yield Label(
                "[dim]Press [bold]1-5[/bold] to switch tabs, "
                "[bold]j/k[/bold] to scroll, "
                "[bold]esc[/bold] to close[/dim]",
                id="detail-footer",
            )

    def on_mount(self) -> None:
        # Hide non-active content areas
        self.query_one("#impl-table", DataTable).display = False
        self.query_one("#conv-content", Static).display = False
        # Reserve tab 1 so _switch_tab won't start a separate content worker
        self._loaded_tabs.add(1)
        # Set visual tab state (tab bar highlight, show/hide widgets)
        self._switch_tab(1)
        # Load detail + sidebar data, then load initial tab content
        self.run_worker(self._load_detail, thread=True)

    def _render_tab_bar(self) -> str:
        parts: list[str] = []
        for num, label in _TABS:
            if int(num) == self._active_tab:
                parts.append(f"[bold #326CE5][{num}] {label}[/bold #326CE5]")
            else:
                parts.append(f"[dim][{num}] {label}[/dim]")
        return "  ".join(parts)

    def _switch_tab(self, tab: int) -> None:
        self._active_tab = tab
        try:
            tab_bar = self.query_one("#tab-bar", Static)
            tab_bar.update(self._render_tab_bar())
        except Exception:
            pass

        # Show/hide content areas
        viewer = self.query_one("#content-viewer", MarkdownViewer)
        impl_table = self.query_one("#impl-table", DataTable)
        conv_content = self.query_one("#conv-content", Static)

        viewer.display = tab in (1, 2, 3)
        impl_table.display = tab == 4
        conv_content.display = tab == 5

        # Tabs 1-3 share the MarkdownViewer, so re-apply cached content on switch
        if tab in (1, 2, 3) and tab in self._tab_content:
            viewer.content = self._tab_content[tab]
        elif tab not in self._loaded_tabs:
            self._loaded_tabs.add(tab)
            self.run_worker(lambda: self._load_tab_content(tab), thread=True)

    def _load_detail(self) -> None:
        """Fetch full feature detail, sidebar, and primary impl data."""
        try:
            detail = self._data_provider.fetch_feature_detail(self._feature_id)
            self._feature_data.update(detail)
            sidebar = self._data_provider.fetch_feature_sidebar(self._feature_id)
            self._sidebar_data = sidebar
        except Exception:
            logger.exception("Failed to load feature detail")

        # Spec/prompt plan may live on the primary implementation rather than
        # the feature itself.  Fetch it so tab content can fall back to it.
        try:
            page = self._data_provider.fetch_implementations(self._feature_id)
            primary = None
            for impl in page.items:
                if impl.get("is_primary", False):
                    primary = impl
                    break
            if primary is None and page.items:
                primary = page.items[0]
            if primary:
                impl_detail = self._data_provider.fetch_implementation_detail(
                    primary["id"]
                )
                self._impl_data = impl_detail
        except Exception:
            logger.exception("Failed to load primary implementation")

        self._load_tab_content(self._active_tab)

    def _load_tab_content(self, tab: int) -> None:
        """Load content for a specific tab."""
        try:
            viewer = self.query_one("#content-viewer", MarkdownViewer)

            if tab == 1:  # Spec
                self.app.call_from_thread(setattr, viewer, "is_loading", True)
                text = (
                    self._sidebar_data.get("spec_text")
                    or self._feature_data.get("spec_text")
                    or self._impl_data.get("spec_text")
                    or ""
                )
                content = text if text else "*No spec available*"
                self._tab_content[tab] = content
                self.app.call_from_thread(setattr, viewer, "content", content)

            elif tab == 2:  # Prompt Plan
                self.app.call_from_thread(setattr, viewer, "is_loading", True)
                text = (
                    self._sidebar_data.get("prompt_plan_text")
                    or self._feature_data.get("prompt_plan_text")
                    or self._impl_data.get("prompt_plan_text")
                    or ""
                )
                content = text if text else "*No prompt plan available*"
                self._tab_content[tab] = content
                self.app.call_from_thread(setattr, viewer, "content", content)

            elif tab == 3:  # Notes
                self.app.call_from_thread(setattr, viewer, "is_loading", True)
                text = (
                    self._sidebar_data.get("notes")
                    or self._feature_data.get("notes")
                    or self._feature_data.get("implementation_notes")
                    or self._impl_data.get("implementation_notes")
                    or ""
                )
                content = text if text else "*No notes available*"
                self._tab_content[tab] = content
                self.app.call_from_thread(setattr, viewer, "content", content)

            elif tab == 4:  # Implementations
                self._load_implementations()

            elif tab == 5:  # Conversations
                self._load_conversations()

        except Exception:
            logger.exception("Failed to load tab %d content", tab)
            try:
                viewer = self.query_one("#content-viewer", MarkdownViewer)
                self.app.call_from_thread(
                    viewer.set_error, "Failed to load content"
                )
            except Exception:
                pass

    def _load_implementations(self) -> None:
        """Load implementations into the DataTable."""
        try:
            page = self._data_provider.fetch_implementations(self._feature_id)
            impl_table = self.query_one("#impl-table", DataTable)

            def _setup_table() -> None:
                impl_table.clear(columns=True)
                impl_table.add_column("KEY", key="key")
                impl_table.add_column("TITLE", key="title")
                impl_table.add_column("STATUS", key="status")
                impl_table.add_column("COMPLETE", key="complete")

                for impl in page.items:
                    key = impl.get("key", impl.get("id", "")[:8])
                    title = impl.get("title", "Untitled")
                    st = impl.get("completion_status", impl.get("status", ""))
                    is_complete = impl.get("is_complete", False)
                    impl_table.add_row(
                        f"[dim]{key}[/dim]",
                        title,
                        status_color(st) if st else "[dim]-[/dim]",
                        bool_indicator(is_complete),
                    )

            self.app.call_from_thread(_setup_table)
        except Exception:
            logger.exception("Failed to load implementations")

    def _load_conversations(self) -> None:
        """Load conversation summary."""
        try:
            conv_content = self.query_one("#conv-content", Static)
            # Use sidebar data for conversation info
            convs = self._sidebar_data.get("conversations", [])
            if not convs:
                self.app.call_from_thread(
                    conv_content.update,
                    "[dim]No conversations available[/dim]",
                )
                return

            lines: list[str] = []
            for conv in convs:
                title = conv.get("title", "Untitled")
                msg_count = conv.get("message_count", 0)
                lines.append(
                    f"  [bold]{title}[/bold] "
                    f"[dim]({msg_count} messages)[/dim]"
                )
            self.app.call_from_thread(conv_content.update, "\n".join(lines))
        except Exception:
            logger.exception("Failed to load conversations")

    # Tab actions
    def action_tab_1(self) -> None:
        self._switch_tab(1)

    def action_tab_2(self) -> None:
        self._switch_tab(2)

    def action_tab_3(self) -> None:
        self._switch_tab(3)

    def action_tab_4(self) -> None:
        self._switch_tab(4)

    def action_tab_5(self) -> None:
        self._switch_tab(5)

    def action_scroll_down(self) -> None:
        try:
            viewer = self.query_one("#content-viewer", MarkdownViewer)
            if viewer.display:
                viewer.action_scroll_down()
        except Exception:
            pass

    def action_scroll_up(self) -> None:
        try:
            viewer = self.query_one("#content-viewer", MarkdownViewer)
            if viewer.display:
                viewer.action_scroll_up()
        except Exception:
            pass
