"""Feature list panel for the TUI.

A Widget that mounts inside #main-content, not a pushed Screen.
This keeps the chrome (header, breadcrumb, command bar, status bar) visible.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

from textual.app import ComposeResult
from textual.message import Message
from textual.widget import Widget
from textual.widgets import Label

from mfbt.tui.colors import bool_indicator, priority_color, status_color
from mfbt.tui.widgets.resource_table import ResourceTable

if TYPE_CHECKING:
    from mfbt.tui.data_provider import TUIDataProvider

logger = logging.getLogger("mfbt.tui.screens.feature_list")

PAGE_SIZE = 25

_COLUMNS: list[tuple[str, str]] = [
    ("key", "KEY"),
    ("name", "NAME"),
    ("priority", "PRIORITY"),
    ("status", "STATUS"),
    ("spec", "SPEC"),
    ("plan", "PLAN"),
    ("impls", "IMPLS"),
    ("category", "CATEGORY"),
]


def _format_feature_row(data: dict[str, Any]) -> tuple[str, ...]:
    """Format a feature dict into table cells."""
    key = data.get("feature_key", data.get("key", ""))
    name = data.get("title", data.get("name", "Unnamed"))
    priority = data.get("priority", "")
    status = data.get("completion_status", data.get("status", ""))
    has_spec = data.get("has_spec", False)
    has_plan = data.get("has_prompt_plan", False)
    impl_count = data.get("implementation_count", data.get("impl_count", ""))
    category = data.get("category", "")
    return (
        f"[dim]{key}[/dim]",
        f"[bold]{name}[/bold]",
        priority_color(priority) if priority else "[dim]-[/dim]",
        status_color(status) if status else "[dim]-[/dim]",
        bool_indicator(has_spec),
        bool_indicator(has_plan),
        str(impl_count) if impl_count else "[dim]0[/dim]",
        str(category) if category else "[dim]-[/dim]",
    )


class FeatureListPanel(Widget):
    """Content panel showing features for a selected module."""

    class FeatureSelected(Message):
        """Fired when a feature is selected (for detail modal)."""

        def __init__(self, data: dict[str, Any]) -> None:
            super().__init__()
            self.data = data

    class DescribeRequested(Message):
        """Fired when describe is requested on a feature."""

        def __init__(self, data: dict[str, Any]) -> None:
            super().__init__()
            self.data = data

    def __init__(
        self,
        data_provider: TUIDataProvider,
        project_id: str,
        project_name: str,
        module_id: str,
        module_name: str,
        module_key: str = "",
        module_metadata: dict[str, Any] | None = None,
    ) -> None:
        super().__init__()
        self._data_provider = data_provider
        self.project_id = project_id
        self.project_name = project_name
        self.module_id = module_id
        self.module_name = module_name
        self.module_key = module_key
        self.module_metadata = module_metadata or {}
        self._offset = 0
        self._has_more = False

    def compose(self) -> ComposeResult:
        yield Label(
            f" [bold #326CE5]Features[/bold #326CE5] [dim]— {self.module_name}[/dim]",
            id="screen-title",
        )
        yield ResourceTable(id="resource-table")

    def on_mount(self) -> None:
        self._offset = 0
        self._load_data()
        self.query_one("#resource-table", ResourceTable).focus()

    def _load_data(self) -> None:
        self.run_worker(self._fetch_and_display, thread=True)

    def _fetch_and_display(self) -> None:
        try:
            page = self._data_provider.fetch_features(
                self.project_id,
                module_id=self.module_id,
                limit=PAGE_SIZE,
                offset=self._offset,
            )
            table = self.query_one("#resource-table", ResourceTable)
            if self._offset == 0:
                self.app.call_from_thread(
                    table.set_rows, page.items, _COLUMNS, _format_feature_row
                )
            else:
                self.app.call_from_thread(
                    table.append_rows, page.items, _format_feature_row
                )
            self._has_more = page.has_more
            self.app.call_from_thread(setattr, table, "has_more", page.has_more)
            self._update_status_count(page.total)
        except Exception as exc:
            logger.exception("Failed to fetch features")
            self.app.call_from_thread(
                self.app.notify,
                f"Failed to load features: {exc}",
                severity="error",
            )

    def _update_status_count(self, count: int) -> None:
        try:
            from mfbt.tui.widgets.status_bar import StatusBar

            status_bar = self.app.query_one("#status-bar", StatusBar)
            self.app.call_from_thread(setattr, status_bar, "resource_count", count)
        except Exception:
            pass

    def on_resource_table_resource_selected(
        self, event: ResourceTable.ResourceSelected
    ) -> None:
        """Open feature detail modal."""
        self.post_message(self.FeatureSelected(event.data))

    def refresh_data(self) -> None:
        """Reload data from the API."""
        self._offset = 0
        self._load_data()

    def get_selected_data(self) -> dict[str, Any] | None:
        """Return the data for the currently highlighted row."""
        try:
            table = self.query_one("#resource-table", ResourceTable)
            return table.get_selected_data()
        except Exception:
            return None
