"""Implementation detail modal screen for the TUI.

Similar to feature detail but with implementation-specific tabs:
Spec, Prompt Plan, Notes, Completion Summary.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Container
from textual.screen import ModalScreen
from textual.widgets import Label, Static

from mfbt.tui.widgets.markdown_viewer import MarkdownViewer
from mfbt.tui.widgets.metadata_panel import MetadataPanel

if TYPE_CHECKING:
    from mfbt.tui.data_provider import TUIDataProvider

logger = logging.getLogger("mfbt.tui.screens.implementation_detail")

_TABS = [
    ("1", "Spec"),
    ("2", "Prompt Plan"),
    ("3", "Notes"),
    ("4", "Summary"),
]


class ImplementationDetailScreen(ModalScreen):
    """Modal overlay showing implementation details with tabbed content."""

    BINDINGS = [
        Binding("escape", "dismiss", "Close", show=False),
        Binding("1", "tab_1", "Spec", show=False),
        Binding("2", "tab_2", "Prompt Plan", show=False),
        Binding("3", "tab_3", "Notes", show=False),
        Binding("4", "tab_4", "Summary", show=False),
        Binding("j", "scroll_down", "Down", show=False),
        Binding("k", "scroll_up", "Up", show=False),
    ]

    def __init__(
        self,
        data_provider: TUIDataProvider,
        implementation_id: str,
        implementation_data: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self._data_provider = data_provider
        self._implementation_id = implementation_id
        self._impl_data = implementation_data or {}
        self._sidebar_data: dict[str, Any] = {}
        self._active_tab = 1
        self._loaded_tabs: set[int] = set()

    def compose(self) -> ComposeResult:
        title = self._impl_data.get("title", "Implementation Detail")
        key = self._impl_data.get("key", "")

        meta_fields = {
            "title": title,
            "key": key,
            "status": self._impl_data.get(
                "completion_status", self._impl_data.get("status", "")
            ),
            "is_complete": self._impl_data.get("is_complete", False),
        }

        with Container(classes="modal-container"):
            yield MetadataPanel(
                {k: v for k, v in meta_fields.items() if v is not None and v != ""},
                id="impl-meta",
            )
            yield Static(self._render_tab_bar(), id="tab-bar", classes="tab-bar")
            yield MarkdownViewer(id="content-viewer")
            yield Label(
                "[dim]Press [bold]1-4[/bold] to switch tabs, "
                "[bold]j/k[/bold] to scroll, "
                "[bold]esc[/bold] to close[/dim]",
                id="detail-footer",
            )

    def on_mount(self) -> None:
        # Reserve tab 1 so _switch_tab won't start a separate content worker
        self._loaded_tabs.add(1)
        # Set visual tab state (tab bar highlight)
        self._switch_tab(1)
        # Load detail + sidebar data, then load initial tab content
        self.run_worker(self._load_detail, thread=True)

    def _render_tab_bar(self) -> str:
        parts: list[str] = []
        for num, label in _TABS:
            if int(num) == self._active_tab:
                parts.append(f"[bold #326CE5][{num}] {label}[/bold #326CE5]")
            else:
                parts.append(f"[dim][{num}] {label}[/dim]")
        return "  ".join(parts)

    def _switch_tab(self, tab: int) -> None:
        self._active_tab = tab
        try:
            tab_bar = self.query_one("#tab-bar", Static)
            tab_bar.update(self._render_tab_bar())
        except Exception:
            pass

        if tab not in self._loaded_tabs:
            self._loaded_tabs.add(tab)
            self.run_worker(lambda: self._load_tab_content(tab), thread=True)

    def _load_detail(self) -> None:
        """Fetch full implementation detail and sidebar data, then load active tab."""
        try:
            detail = self._data_provider.fetch_implementation_detail(
                self._implementation_id
            )
            self._impl_data.update(detail)
            sidebar = self._data_provider.fetch_implementation_sidebar(
                self._implementation_id
            )
            self._sidebar_data = sidebar
        except Exception:
            logger.exception("Failed to load implementation detail")
        # Sidebar data is now available — load the active tab content
        self._load_tab_content(self._active_tab)

    def _load_tab_content(self, tab: int) -> None:
        """Load content for a specific tab."""
        try:
            viewer = self.query_one("#content-viewer", MarkdownViewer)
            self.app.call_from_thread(setattr, viewer, "is_loading", True)

            if tab == 1:  # Spec
                text = self._sidebar_data.get(
                    "spec_text", self._impl_data.get("spec_text", "")
                )
                content = text if text else "*No spec available*"

            elif tab == 2:  # Prompt Plan
                text = self._sidebar_data.get(
                    "prompt_plan_text",
                    self._impl_data.get("prompt_plan_text", ""),
                )
                content = text if text else "*No prompt plan available*"

            elif tab == 3:  # Notes
                text = self._sidebar_data.get(
                    "notes", self._impl_data.get("notes", "")
                )
                content = text if text else "*No notes available*"

            elif tab == 4:  # Completion Summary
                text = self._sidebar_data.get(
                    "completion_summary",
                    self._impl_data.get("completion_summary", ""),
                )
                content = text if text else "*No completion summary available*"
            else:
                content = ""

            self.app.call_from_thread(setattr, viewer, "content", content)
        except Exception:
            logger.exception("Failed to load tab %d content", tab)

    def action_tab_1(self) -> None:
        self._switch_tab(1)

    def action_tab_2(self) -> None:
        self._switch_tab(2)

    def action_tab_3(self) -> None:
        self._switch_tab(3)

    def action_tab_4(self) -> None:
        self._switch_tab(4)

    def action_scroll_down(self) -> None:
        try:
            viewer = self.query_one("#content-viewer", MarkdownViewer)
            viewer.action_scroll_down()
        except Exception:
            pass

    def action_scroll_up(self) -> None:
        try:
            viewer = self.query_one("#content-viewer", MarkdownViewer)
            viewer.action_scroll_up()
        except Exception:
            pass
