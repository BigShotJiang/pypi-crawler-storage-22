"""Info modal screen for the TUI.

Generic bordered modal showing entity metadata for projects, modules,
or features. Triggered by the `d` (describe) key.
"""

from __future__ import annotations

from typing import Any

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Container, VerticalScroll
from textual.screen import ModalScreen
from textual.widgets import Label

from mfbt.tui.widgets.metadata_panel import MetadataPanel


# Fields to display per resource type
_DISPLAY_FIELDS: dict[str, list[str]] = {
    "project": [
        "name",
        "key",
        "description",
        "status",
        "project_type",
        "tech_stack",
        "feature_count",
        "created_at",
        "updated_at",
    ],
    "module": [
        "title",
        "module_key",
        "description",
        "feature_count",
        "type",
        "provenance",
        "source_phase_title",
        "created_at",
    ],
    "phase": [
        "title",
        "description",
        "status",
        "_total_features",
        "_completed_features",
        "_pending_features",
        "_progress_percent",
        "created_at",
        "updated_at",
    ],
    "feature": [
        "title",
        "feature_key",
        "description",
        "priority",
        "completion_status",
        "category",
        "has_spec",
        "has_prompt_plan",
        "implementation_count",
        "created_at",
        "updated_at",
    ],
}


class InfoModal(ModalScreen):
    """Modal overlay showing entity metadata."""

    BINDINGS = [
        Binding("escape", "dismiss", "Close", show=False),
        Binding("d", "dismiss", "Close", show=False),
        Binding("q", "dismiss", "Close", show=False),
    ]

    def __init__(
        self,
        data: dict[str, Any],
        resource_type: str = "project",
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self._data = data
        self._resource_type = resource_type

    def compose(self) -> ComposeResult:
        title = self._data.get(
            "name", self._data.get("title", "Details")
        )
        fields = _DISPLAY_FIELDS.get(self._resource_type, [])
        filtered = {
            k: v for k, v in self._data.items() if k in fields and v is not None
        }

        with Container(classes="modal-container-small"):
            yield Label(
                f"[bold #326CE5]{self._resource_type.title()}:[/bold #326CE5] "
                f"[bold]{title}[/bold]"
            )
            yield Label("")
            with VerticalScroll():
                yield MetadataPanel(filtered)
            yield Label("")
            yield Label("[dim]Press [bold]esc[/bold] or [bold]d[/bold] to close[/dim]")
