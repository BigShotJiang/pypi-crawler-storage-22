"""Pre-flight check modal for Ralph orchestration.

Lets the user select a coding agent, runs environment checks
(agent installed + MCP configured), and reports pass/fail before
starting the orchestration loop.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Container, Horizontal
from textual.screen import ModalScreen
from textual.widgets import Button, Label, Select, Static

from mfbt.coding_agents import CheckResult, get_available_agents
from mfbt.commands.ralph.types import AgentType


class PreflightModal(ModalScreen[AgentType | None]):
    """Modal screen for pre-flight checks before starting Ralph."""

    BINDINGS = [
        Binding("escape", "cancel", "Cancel", show=False),
    ]

    def __init__(self, project_dir: Path, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self._project_dir = project_dir
        self._check_results: list[CheckResult] = []
        self._all_passed = False

    def compose(self) -> ComposeResult:
        agents = get_available_agents()
        options = [(agent.display_name, agent.name) for agent in agents]

        with Container(id="preflight-container"):
            yield Label(
                "[bold #326CE5]Ralph Pre-flight[/bold #326CE5]",
                id="preflight-title",
            )
            yield Label("")

            yield Label("[bold]Coding Agent[/bold]")
            yield Select(
                options,
                value=options[0][1] if options else Select.BLANK,
                id="agent-select",
                allow_blank=False,
            )
            yield Label("")

            yield Label("[bold]Project directory[/bold]")
            yield Static(
                f"[dim]{self._project_dir}[/dim]",
                id="preflight-project-dir",
            )
            yield Label("")

            yield Label("[bold]Pre-flight checks[/bold]")
            yield Static(
                "[dim]Running checks...[/dim]",
                id="preflight-checks",
            )
            yield Label("")

            with Horizontal(id="preflight-buttons"):
                yield Button("Start", id="preflight-start", variant="success", disabled=True)
                yield Button("Cancel", id="preflight-cancel")

    def on_mount(self) -> None:
        self._run_checks()

    def on_select_changed(self, event: Select.Changed) -> None:
        """Re-run checks when a different agent is selected."""
        self._run_checks()

    def _run_checks(self) -> None:
        """Run pre-flight checks for the currently selected agent."""
        try:
            select = self.query_one("#agent-select", Select)
            agent_name = select.value
        except Exception:
            return

        if agent_name is Select.BLANK:
            return

        from mfbt.coding_agents import get_checker

        checker = get_checker(str(agent_name))
        if checker is None:
            return

        results = checker.run_all_checks(self._project_dir)
        self._check_results = results
        self._all_passed = all(r.passed for r in results)

        # Render results
        lines: list[str] = []
        for r in results:
            if r.passed:
                lines.append(f"[green]\u2713[/green] {r.label}")
                lines.append(f"  [dim]{r.detail}[/dim]")
            else:
                lines.append(f"[red]\u2717[/red] {r.label}")
                lines.append(f"  [dim]{r.detail}[/dim]")

        try:
            checks_widget = self.query_one("#preflight-checks", Static)
            checks_widget.update("\n".join(lines))
        except Exception:
            pass

        try:
            start_btn = self.query_one("#preflight-start", Button)
            start_btn.disabled = not self._all_passed
        except Exception:
            pass

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "preflight-start" and self._all_passed:
            # Map agent name to AgentType
            try:
                select = self.query_one("#agent-select", Select)
                agent_name = str(select.value)
            except Exception:
                agent_name = "claude"

            agent_type = AgentType(agent_name)
            self.dismiss(agent_type)
        elif event.button.id == "preflight-cancel":
            self.dismiss(None)

    def action_cancel(self) -> None:
        self.dismiss(None)
