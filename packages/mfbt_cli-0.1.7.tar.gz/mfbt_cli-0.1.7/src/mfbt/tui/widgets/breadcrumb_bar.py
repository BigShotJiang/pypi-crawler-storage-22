"""Breadcrumb bar widget for the TUI.

Displays a colored breadcrumb path with entity keys, e.g.:
  Projects > MyApp (PRJ-abc) > Auth (AUTH-1)
"""

from __future__ import annotations

from textual.reactive import reactive
from textual.widgets import Static


class BreadcrumbBar(Static):
    """A breadcrumb bar with colored separators and entity keys."""

    path_rich: reactive[str] = reactive("[bold]Projects[/bold]")

    def render(self) -> str:
        return f" {self.path_rich}"

    def watch_path_rich(self, value: str) -> None:
        self.update(f" {value}")
