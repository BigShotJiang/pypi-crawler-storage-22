"""Breadcrumb header widget for the TUI.

Displays the current navigation path (e.g. "Projects > MyApp > Auth").
"""

from __future__ import annotations

from textual.reactive import reactive
from textual.widgets import Static


class BreadcrumbHeader(Static):
    """A header bar that shows the current navigation breadcrumb path."""

    path: reactive[str] = reactive("Projects")

    def render(self) -> str:
        return f" {self.path}"

    def watch_path(self, value: str) -> None:
        self.update(f" {value}")
