"""Command bar widget for the TUI.

Displays context-sensitive keybinding hints in the footer,
styled as k9s-style key/description pairs.
"""

from __future__ import annotations

from textual.reactive import reactive
from textual.widgets import Static


class CommandBar(Static):
    """Footer bar showing keybinding hints."""

    hints: reactive[tuple[tuple[str, str], ...]] = reactive(
        (("q", "Quit"), ("?", "Help"), ("r", "Refresh"))
    )

    def render(self) -> str:
        return self._render_hints()

    def watch_hints(self, value: tuple[tuple[str, str], ...]) -> None:
        self.update(self._render_hints())

    def _render_hints(self) -> str:
        parts: list[str] = []
        for key, desc in self.hints:
            parts.append(f"[bold #326CE5]<{key}>[/bold #326CE5] {desc}")
        return "  ".join(parts)
