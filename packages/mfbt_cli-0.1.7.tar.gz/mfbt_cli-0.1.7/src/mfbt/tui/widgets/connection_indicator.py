"""Connection status indicator widget for the TUI.

Displays the current transport mode (WebSocket, Polling, or Offline).
"""

from __future__ import annotations

from textual.reactive import reactive
from textual.widgets import Static

from mfbt.websocket_types import TransportMode


class ConnectionIndicator(Static):
    """Shows the current connection transport mode and token refresh status."""

    transport: reactive[TransportMode] = reactive(TransportMode.NONE)
    refreshing: reactive[bool] = reactive(False)

    def render(self) -> str:
        if self.refreshing:
            return "[cyan]↻ Refreshing...[/cyan]"
        return self._format_transport(self.transport)

    def watch_transport(self, value: TransportMode) -> None:
        if not self.refreshing:
            self.update(self.render())

    def watch_refreshing(self, value: bool) -> None:
        self.update(self.render())

    @staticmethod
    def _format_transport(mode: TransportMode) -> str:
        if mode == TransportMode.WEBSOCKET:
            return "[green]● Live[/green]"
        if mode == TransportMode.POLLING:
            return "[yellow]● Polling[/yellow]"
        return "[dim]● Offline[/dim]"
