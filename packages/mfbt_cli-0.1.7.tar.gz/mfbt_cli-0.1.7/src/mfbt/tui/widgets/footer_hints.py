"""Footer key-hints widget for the TUI.

Shows context-appropriate keyboard shortcuts at the bottom of the screen.
"""

from __future__ import annotations

from textual.app import ComposeResult
from textual.reactive import reactive
from textual.widget import Widget
from textual.widgets import Static


class FooterHints(Widget):
    """A footer bar displaying context-sensitive key hints."""

    hints: reactive[tuple[tuple[str, str], ...]] = reactive(
        (("q", "Quit"), ("?", "Help"), ("r", "Refresh"))
    )

    def compose(self) -> ComposeResult:
        yield Static(self._render_hints(), id="footer-text")

    def watch_hints(self, value: tuple[tuple[str, str], ...]) -> None:
        try:
            text_widget = self.query_one("#footer-text", Static)
            text_widget.update(self._render_hints())
        except Exception:
            pass

    def _render_hints(self) -> str:
        parts: list[str] = []
        for key, desc in self.hints:
            parts.append(f"[bold]{key}[/bold] {desc}")
        return "  ".join(parts)
