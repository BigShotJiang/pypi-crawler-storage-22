"""Job status panel widget for the TUI.

Displays real-time job status updates with color-coded badges.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from textual.app import ComposeResult
from textual.reactive import reactive
from textual.widget import Widget
from textual.widgets import Static

from mfbt.websocket_types import JobStatus, JobStatusUpdate

if TYPE_CHECKING:
    from mfbt.job_monitor import JobMonitor


_STATUS_STYLES: dict[JobStatus, str] = {
    JobStatus.QUEUED: "[dim]queued[/dim]",
    JobStatus.RUNNING: "[cyan]running[/cyan]",
    JobStatus.SUCCEEDED: "[green]succeeded[/green]",
    JobStatus.FAILED: "[red]failed[/red]",
    JobStatus.CANCELLED: "[yellow]cancelled[/yellow]",
}


class JobStatusPanel(Widget):
    """Displays a list of monitored job statuses."""

    jobs: reactive[tuple[JobStatusUpdate, ...]] = reactive(())

    def __init__(
        self,
        job_monitor: JobMonitor | None = None,
        **kwargs: object,
    ) -> None:
        super().__init__(**kwargs)
        self._job_monitor = job_monitor
        self._job_map: dict[str, JobStatusUpdate] = {}

    def compose(self) -> ComposeResult:
        yield Static("[dim]No active jobs[/dim]", id="job-content")

    def watch_jobs(self, value: tuple[JobStatusUpdate, ...]) -> None:
        try:
            content = self.query_one("#job-content", Static)
        except Exception:
            return
        if not value:
            content.update("[dim]No active jobs[/dim]")
            return
        lines: list[str] = []
        for update in value:
            short_id = update.job_id[:8]
            badge = _STATUS_STYLES.get(update.status, str(update.status.value))
            progress = ""
            if update.progress is not None:
                progress = f" {update.progress:.0%}"
            lines.append(f"  {short_id} {badge}{progress}")
        content.update("\n".join(lines))

    def handle_job_update(self, update: JobStatusUpdate) -> None:
        """Process a job status update (thread-safe via call_from_thread).

        Call this from ``app.call_from_thread()`` to marshal from
        daemon threads onto Textual's main thread.
        """
        self._job_map[update.job_id] = update
        # Remove terminal jobs after recording them
        if update.status.is_terminal:
            self._job_map.pop(update.job_id, None)
        self.jobs = tuple(self._job_map.values())

    def watch_job(self, job_id: str) -> None:
        """Start monitoring a job through the JobMonitor."""
        if self._job_monitor is None:
            return

        def _on_update(update: JobStatusUpdate) -> None:
            if self.app is not None:
                self.app.call_from_thread(self.handle_job_update, update)

        self._job_monitor.watch_job(job_id, on_update=_on_update)
