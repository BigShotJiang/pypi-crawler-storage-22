"""Markdown viewer widget for detail modals.

Wraps Textual's Markdown widget in a scrollable container
with vim j/k bindings and loading state support.
"""

from __future__ import annotations

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import VerticalScroll
from textual.reactive import reactive
from textual.widget import Widget
from textual.widgets import Markdown, Static


class MarkdownViewer(Widget):
    """A scrollable markdown viewer with vim navigation."""

    BINDINGS = [
        Binding("j", "scroll_down", "Down", show=False),
        Binding("k", "scroll_up", "Up", show=False),
    ]

    content: reactive[str] = reactive("")
    is_loading: reactive[bool] = reactive(False)

    def compose(self) -> ComposeResult:
        with VerticalScroll(id="md-scroll"):
            yield Static("[dim]Loading...[/dim]", id="md-loading")
            yield Markdown("", id="md-content")

    def watch_content(self, value: str) -> None:
        try:
            md = self.query_one("#md-content", Markdown)
            md.update(value)
            loading = self.query_one("#md-loading", Static)
            loading.display = False
            md.display = True
        except Exception:
            pass

    def watch_is_loading(self, value: bool) -> None:
        try:
            loading = self.query_one("#md-loading", Static)
            md = self.query_one("#md-content", Markdown)
            if value:
                loading.update("[dim]Loading...[/dim]")
                loading.display = True
                md.display = False
            else:
                loading.display = False
                md.display = True
        except Exception:
            pass

    def set_error(self, message: str) -> None:
        """Display an error message instead of content."""
        try:
            loading = self.query_one("#md-loading", Static)
            loading.update(f"[red]{message}[/red]")
            loading.display = True
            md = self.query_one("#md-content", Markdown)
            md.display = False
        except Exception:
            pass

    def action_scroll_down(self) -> None:
        try:
            scroll = self.query_one("#md-scroll", VerticalScroll)
            scroll.scroll_down()
        except Exception:
            pass

    def action_scroll_up(self) -> None:
        try:
            scroll = self.query_one("#md-scroll", VerticalScroll)
            scroll.scroll_up()
        except Exception:
            pass
