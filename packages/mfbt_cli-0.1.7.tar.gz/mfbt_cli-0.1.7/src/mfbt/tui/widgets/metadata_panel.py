"""Metadata panel widget for detail modals.

Renders a bordered panel of key-value pairs with color-coded values,
used at the top of all detail modal screens.
"""

from __future__ import annotations

from typing import Any

from textual.widgets import Static

from mfbt.tui.colors import bool_indicator, priority_color, status_color


_COLOR_KEYS = {"priority", "status", "completion_status"}
_BOOL_KEYS = {"has_spec", "has_prompt_plan", "is_complete"}


class MetadataPanel(Static):
    """A compact panel showing key-value metadata pairs."""

    def __init__(self, data: dict[str, Any], **kwargs: Any) -> None:
        self._data = data
        super().__init__(self._build_content(), **kwargs)

    def _build_content(self) -> str:
        lines: list[str] = []
        pairs = list(self._data.items())

        for key, value in pairs:
            label = key.replace("_", " ").title()
            formatted = self._format_value(key, value)
            lines.append(f"  [dim]{label}:[/dim] {formatted}")

        return "\n".join(lines) if lines else "[dim]No metadata[/dim]"

    @staticmethod
    def _format_value(key: str, value: Any) -> str:
        if value is None or value == "":
            return "[dim]-[/dim]"
        if key in _BOOL_KEYS:
            return bool_indicator(bool(value))
        if key == "priority":
            return priority_color(str(value))
        if key in _COLOR_KEYS:
            return status_color(str(value))
        if isinstance(value, list):
            return ", ".join(str(v) for v in value[:5])
        return str(value)
