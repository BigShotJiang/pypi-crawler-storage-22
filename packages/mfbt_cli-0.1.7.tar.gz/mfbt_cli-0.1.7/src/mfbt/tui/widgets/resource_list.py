"""Reusable resource list widget for the TUI.

A paginated, keyboard-navigable list that renders dicts as rows.
"""

from __future__ import annotations

from typing import Any

from textual import on
from textual.app import ComposeResult
from textual.binding import Binding
from textual.message import Message
from textual.reactive import reactive
from textual.widgets import Label, ListItem, ListView


class ResourceListItem(ListItem):
    """A single row in the resource list, holding a data dict."""

    def __init__(self, data: dict[str, Any], display_text: str) -> None:
        super().__init__()
        self.data = data
        self._display_text = display_text

    def compose(self) -> ComposeResult:
        yield Label(self._display_text)


class ResourceList(ListView):
    """A keyboard-navigable list of resources with loading/empty states.

    Binds j/k for vim-style navigation.
    """

    BINDINGS = [
        Binding("j", "cursor_down", "Down", show=False),
        Binding("k", "cursor_up", "Up", show=False),
    ]

    loading: reactive[bool] = reactive(False)
    has_more: reactive[bool] = reactive(False)

    class ResourceSelected(Message):
        """Fired when a resource is selected (Enter pressed)."""

        def __init__(self, data: dict[str, Any]) -> None:
            super().__init__()
            self.data = data

    class LoadMore(Message):
        """Fired when the user scrolls to the bottom and more items exist."""

    def set_items(self, items: list[dict[str, Any]], display_fn: Any) -> None:
        """Replace current items with new ones.

        Args:
            items: List of data dicts.
            display_fn: Callable(dict) -> str to generate display text.
        """
        self.clear()
        if not items:
            self.mount(ListItem(Label("[dim]No items found[/dim]")))
            return
        for item in items:
            text = display_fn(item)
            self.mount(ResourceListItem(data=item, display_text=text))

    def append_items(self, items: list[dict[str, Any]], display_fn: Any) -> None:
        """Append additional items (for pagination)."""
        for item in items:
            text = display_fn(item)
            self.mount(ResourceListItem(data=item, display_text=text))

    @on(ListView.Selected)
    def _on_selected(self, event: ListView.Selected) -> None:
        """Forward selection events with the associated data."""
        event.stop()
        item = event.item
        if isinstance(item, ResourceListItem):
            self.post_message(self.ResourceSelected(item.data))
