"""Reusable resource table widget for the TUI.

A DataTable-based widget replacing ResourceList, providing columnar display
with color-coded cells, vim navigation, and row selection messages.
"""

from __future__ import annotations

from typing import Any

from textual.binding import Binding
from textual.message import Message
from textual.widgets import DataTable


class ResourceTable(DataTable):
    """A keyboard-navigable table of resources with color-coded cells.

    Provides vim j/k navigation, row selection via Enter, and pagination
    support via LoadMore message.
    """

    BINDINGS = [
        Binding("j", "cursor_down", "Down", show=False),
        Binding("k", "cursor_up", "Up", show=False),
        Binding("g", "scroll_home", "Top", show=False),
        Binding("G", "scroll_end", "Bottom", show=False),
    ]

    class ResourceSelected(Message):
        """Fired when a resource row is selected (Enter pressed)."""

        def __init__(self, data: dict[str, Any]) -> None:
            super().__init__()
            self.data = data

    class LoadMore(Message):
        """Fired when the user scrolls past the last row and more items exist."""

    def __init__(self, **kwargs: Any) -> None:
        super().__init__(cursor_type="row", zebra_stripes=True, **kwargs)
        self._row_data: list[dict[str, Any]] = []
        self._has_more: bool = False

    @property
    def has_more(self) -> bool:
        return self._has_more

    @has_more.setter
    def has_more(self, value: bool) -> None:
        self._has_more = value

    def set_rows(
        self,
        items: list[dict[str, Any]],
        columns: list[tuple[str, str]],
        row_fn: Any,
    ) -> None:
        """Replace all rows with new data.

        Args:
            items: List of raw data dicts.
            columns: List of (key, label) tuples defining columns.
            row_fn: Callable(dict) -> tuple of Rich-markup cell strings.
        """
        self.clear(columns=True)
        self._row_data.clear()

        for key, label in columns:
            self.add_column(label, key=key)

        if not items:
            return

        for item in items:
            cells = row_fn(item)
            self.add_row(*cells)
            self._row_data.append(item)

    def append_rows(
        self,
        items: list[dict[str, Any]],
        row_fn: Any,
    ) -> None:
        """Append additional rows (for pagination).

        Args:
            items: List of raw data dicts.
            row_fn: Callable(dict) -> tuple of Rich-markup cell strings.
        """
        for item in items:
            cells = row_fn(item)
            self.add_row(*cells)
            self._row_data.append(item)

    def on_data_table_row_selected(self, event: DataTable.RowSelected) -> None:
        """Forward row selection as ResourceSelected with data dict."""
        event.stop()
        row_idx = event.cursor_row
        if 0 <= row_idx < len(self._row_data):
            self.post_message(self.ResourceSelected(self._row_data[row_idx]))

    def get_selected_data(self) -> dict[str, Any] | None:
        """Return the data dict for the currently highlighted row."""
        row_idx = self.cursor_row
        if 0 <= row_idx < len(self._row_data):
            return self._row_data[row_idx]
        return None

    def action_scroll_end(self) -> None:
        """Move cursor to the last row."""
        if self.row_count > 0:
            self.move_cursor(row=self.row_count - 1)

    def action_scroll_home(self) -> None:
        """Move cursor to the first row."""
        if self.row_count > 0:
            self.move_cursor(row=0)
