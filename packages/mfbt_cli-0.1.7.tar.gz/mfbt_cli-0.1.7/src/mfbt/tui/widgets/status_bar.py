"""Status bar widget for the TUI.

Shows resource type/count, completion %, connection status, and timestamp.
Absorbs the functionality of the old ConnectionIndicator.
"""

from __future__ import annotations

from textual.reactive import reactive
from textual.widgets import Static

from mfbt.websocket_types import TransportMode


class StatusBar(Static):
    """Bottom status bar showing resource count and connection info."""

    resource_type: reactive[str] = reactive("Projects")
    resource_count: reactive[int] = reactive(0)
    completion_pct: reactive[float] = reactive(0.0)
    transport: reactive[TransportMode] = reactive(TransportMode.NONE)
    refreshing: reactive[bool] = reactive(False)
    cwd: reactive[str] = reactive("")

    def render(self) -> str:
        parts: list[str] = []

        # Resource info
        if self.resource_count > 0:
            parts.append(
                f"[bold]{self.resource_type}[/bold] ({self.resource_count})"
            )
        else:
            parts.append(f"[bold]{self.resource_type}[/bold]")

        # Completion percentage
        if self.completion_pct > 0:
            parts.append(f"[dim]{self.completion_pct:.0%} complete[/dim]")

        left = "  ".join(parts)

        # Connection indicator (right side)
        if self.refreshing:
            conn = "[cyan]\u21bb Refreshing...[/cyan]"
        elif self.transport == TransportMode.WEBSOCKET:
            conn = "[green]\u25cf Live[/green]"
        elif self.transport == TransportMode.POLLING:
            conn = "[yellow]\u25cf Polling[/yellow]"
        else:
            conn = "[dim]\u25cf Offline[/dim]"

        # Current working directory (right-aligned, before connection indicator)
        if self.cwd:
            cwd_display = self.cwd
            # Truncate from the left if too long (keep last ~40 chars)
            max_cwd = 40
            if len(cwd_display) > max_cwd:
                cwd_display = "..." + cwd_display[-(max_cwd - 3) :]
            return f" {left}{'':>4}[dim]{cwd_display}[/dim]  {conn}"

        return f" {left}{'':>4}{conn}"

    def _trigger_update(self) -> None:
        self.update(self.render())

    def watch_resource_type(self, value: str) -> None:
        self._trigger_update()

    def watch_resource_count(self, value: int) -> None:
        self._trigger_update()

    def watch_completion_pct(self, value: float) -> None:
        self._trigger_update()

    def watch_transport(self, value: TransportMode) -> None:
        self._trigger_update()

    def watch_refreshing(self, value: bool) -> None:
        self._trigger_update()

    def watch_cwd(self, value: str) -> None:
        self._trigger_update()
