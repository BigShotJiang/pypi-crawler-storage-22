"""WebSocket client for real-time job status updates.

Provides WebSocketClient with automatic reconnection, subscription management,
and message routing. Runs a daemon listener thread — public API is synchronous.
Covers MCLI-053 (connection management) and MCLI-054 (reconnection).
"""

from __future__ import annotations

import json
import logging
import random
import threading
import time
from collections.abc import Callable
from typing import TYPE_CHECKING, Any
from urllib.parse import urlparse, urlunparse

from websockets.sync.client import connect as ws_connect

from mfbt.exceptions import WebSocketAuthError, WebSocketError
from mfbt.websocket_types import (
    ConnectionEvent,
    ConnectionEventType,
    ConnectionState,
    JobStatus,
    JobStatusUpdate,
    WebSocketMessage,
)

if TYPE_CHECKING:
    from websockets.sync.client import ClientConnection

    from mfbt.token_manager import TokenManager

logger = logging.getLogger("mfbt.websocket_client")

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

WS_BASE_DELAY = 1.0
WS_MAX_DELAY = 60.0
WS_JITTER = 0.25
WS_RECV_TIMEOUT = 30
WS_STABLE_CONNECTION_SECS = 30.0


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _build_ws_url(base_url: str, token: str) -> str:
    """Convert an HTTP(S) base URL to a WebSocket URL with token query param."""
    parsed = urlparse(base_url)
    if parsed.scheme == "https":
        scheme = "wss"
    elif parsed.scheme == "http":
        scheme = "ws"
    else:
        scheme = parsed.scheme
    ws_parsed = parsed._replace(scheme=scheme, path="/ws", query=f"token={token}")
    result: str = urlunparse(ws_parsed)
    return result


def _calculate_ws_backoff(attempt: int) -> float:
    """Calculate exponential backoff with jitter for WS reconnection.

    Returns WS_BASE_DELAY * 2^attempt * (1 +/- WS_JITTER), capped at WS_MAX_DELAY.
    """
    delay = WS_BASE_DELAY * (2 ** attempt)
    delay = min(delay, WS_MAX_DELAY)
    jitter_range = delay * WS_JITTER
    result: float = delay + random.uniform(-jitter_range, jitter_range)
    return result


# ---------------------------------------------------------------------------
# WebSocketClient
# ---------------------------------------------------------------------------


class WebSocketClient:
    """Manages a WebSocket connection for real-time job updates.

    Runs a daemon listener thread. All public methods are thread-safe.
    """

    def __init__(
        self,
        base_url: str,
        token_manager: TokenManager,
        *,
        max_reconnect_attempts: int | None = None,
        on_message: Callable[[WebSocketMessage], None] | None = None,
        on_event: Callable[[ConnectionEvent], None] | None = None,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._token_manager = token_manager
        self._max_reconnect_attempts = max_reconnect_attempts
        self._on_message = on_message
        self._on_event = on_event

        # Connection state
        self._state = ConnectionState.DISCONNECTED
        self._state_lock = threading.Lock()
        self._ws: ClientConnection | None = None

        # Threading
        self._listener_thread: threading.Thread | None = None
        self._stop_event = threading.Event()

        # Subscriptions and handlers
        self._subscriptions: set[str] = set()
        self._subscriptions_lock = threading.Lock()
        self._channel_handlers: dict[str, Callable[[JobStatusUpdate], None]] = {}
        self._handlers_lock = threading.Lock()

        # Reconnection
        self._reconnect_lock = threading.Lock()

    # ---- Properties ---------------------------------------------------------

    @property
    def state(self) -> ConnectionState:
        with self._state_lock:
            return self._state

    @property
    def is_connected(self) -> bool:
        return self.state == ConnectionState.CONNECTED

    @property
    def active_subscriptions(self) -> frozenset[str]:
        with self._subscriptions_lock:
            return frozenset(self._subscriptions)

    # ---- Public API ---------------------------------------------------------

    def connect(self) -> None:
        """Establish WebSocket connection and start the listener thread."""
        if self.state in (ConnectionState.CONNECTED, ConnectionState.CONNECTING):
            return

        self._stop_event.clear()
        self._set_state(ConnectionState.CONNECTING)

        try:
            self._open_connection()
        except WebSocketAuthError:
            self._set_state(ConnectionState.DISCONNECTED)
            raise
        except Exception as exc:
            self._set_state(ConnectionState.DISCONNECTED)
            raise WebSocketError(
                technical_details=str(exc),
            ) from exc

        self._set_state(ConnectionState.CONNECTED)
        self._emit_event(ConnectionEventType.CONNECTED, "WebSocket connected")

        # Start daemon listener thread
        self._listener_thread = threading.Thread(
            target=self._listener_loop,
            name="mfbt-ws-listener",
            daemon=True,
        )
        self._listener_thread.start()

    def disconnect(self) -> None:
        """Gracefully close the connection and stop the listener thread."""
        self._stop_event.set()
        self._close_connection()
        if self._listener_thread is not None and self._listener_thread.is_alive():
            self._listener_thread.join(timeout=5.0)
            self._listener_thread = None
        self._set_state(ConnectionState.DISCONNECTED)
        self._emit_event(ConnectionEventType.DISCONNECTED, "WebSocket disconnected")

    def subscribe(self, job_id: str) -> None:
        """Subscribe to status updates for a job."""
        channel = f"job:{job_id}:status"
        with self._subscriptions_lock:
            self._subscriptions.add(job_id)
        self._send_subscribe(channel)

    def unsubscribe(self, job_id: str) -> None:
        """Unsubscribe from status updates for a job."""
        channel = f"job:{job_id}:status"
        with self._subscriptions_lock:
            self._subscriptions.discard(job_id)
        self._send_unsubscribe(channel)

    def register_handler(
        self, job_id: str, callback: Callable[[JobStatusUpdate], None]
    ) -> None:
        """Register a per-job callback for status updates."""
        with self._handlers_lock:
            self._channel_handlers[job_id] = callback

    def unregister_handler(self, job_id: str) -> None:
        """Remove the per-job callback."""
        with self._handlers_lock:
            self._channel_handlers.pop(job_id, None)

    # ---- Internal: connection management ------------------------------------

    def _open_connection(self) -> None:
        """Open a new WebSocket connection."""
        token = self._token_manager.get_access_token()
        url = _build_ws_url(self._base_url, token)
        try:
            self._ws = ws_connect(url)
        except Exception as exc:
            error_str = str(exc).lower()
            if "401" in error_str or "403" in error_str or "auth" in error_str:
                raise WebSocketAuthError(
                    technical_details=str(exc),
                ) from exc
            raise

    def _close_connection(self) -> None:
        """Close the current WebSocket connection if open."""
        ws = self._ws
        self._ws = None
        if ws is not None:
            try:
                ws.close()
            except Exception:
                pass

    def _set_state(self, state: ConnectionState) -> None:
        with self._state_lock:
            self._state = state

    # ---- Internal: message sending ------------------------------------------

    def _send_json(self, data: dict[str, Any]) -> None:
        """Send a JSON message on the WebSocket. Silently fails if not connected."""
        ws = self._ws
        if ws is None:
            return
        try:
            ws.send(json.dumps(data))
        except Exception as exc:
            logger.debug("Failed to send WS message: %s", exc)

    def _send_subscribe(self, channel: str) -> None:
        self._send_json({"type": "subscribe", "channel": channel})

    def _send_unsubscribe(self, channel: str) -> None:
        self._send_json({"type": "unsubscribe", "channel": channel})

    def _restore_subscriptions(self) -> None:
        """Re-subscribe to all active channels after reconnect."""
        with self._subscriptions_lock:
            job_ids = list(self._subscriptions)
        for job_id in job_ids:
            self._send_subscribe(f"job:{job_id}:status")

    # ---- Internal: listener thread ------------------------------------------

    def _listener_loop(self) -> None:
        """Main loop for the daemon listener thread.

        Runs recv loop, then reconnects on failure unless stop was requested.
        """
        while not self._stop_event.is_set():
            try:
                self._recv_loop()
            except Exception as exc:
                if self._stop_event.is_set():
                    break
                logger.warning("WebSocket recv loop exited: %s", exc)

            if self._stop_event.is_set():
                break

            # Attempt reconnection
            if not self._reconnect():
                break

    def _recv_loop(self) -> None:
        """Receive messages until disconnected or stop requested."""
        connected_at = time.monotonic()
        while not self._stop_event.is_set():
            ws = self._ws
            if ws is None:
                return
            try:
                raw = ws.recv(timeout=WS_RECV_TIMEOUT)
            except TimeoutError:
                continue
            except Exception as exc:
                if not self._stop_event.is_set():
                    logger.debug("WebSocket recv error: %s", exc)
                raise

            # Reset backoff counter reference when connection has been stable
            elapsed = time.monotonic() - connected_at
            if elapsed >= WS_STABLE_CONNECTION_SECS:
                connected_at = time.monotonic()

            self._handle_raw_message(str(raw))

    def _handle_raw_message(self, raw: str) -> None:
        """Parse and route a raw WebSocket message."""
        try:
            data = json.loads(raw)
        except (json.JSONDecodeError, TypeError):
            logger.debug("Malformed WebSocket message: %s", raw[:200])
            return

        if not isinstance(data, dict):
            logger.debug("Unexpected WebSocket message format: %s", type(data).__name__)
            return

        msg = WebSocketMessage(
            type=data.get("type", "unknown"),
            payload=data.get("payload", {}),
            timestamp=data.get("timestamp", ""),
            raw=raw,
        )

        # Global callback
        if self._on_message is not None:
            try:
                self._on_message(msg)
            except Exception:
                logger.debug("Error in on_message callback", exc_info=True)

        # Route job_status messages to per-job handlers
        if msg.type == "job_status":
            self._route_job_status(msg.payload)

    def _route_job_status(self, payload: dict[str, Any]) -> None:
        """Route a job_status payload to the registered handler."""
        job_id = payload.get("job_id")
        if job_id is None:
            return

        status_str = payload.get("status", "")
        try:
            status = JobStatus(status_str)
        except ValueError:
            logger.debug("Unknown job status: %s", status_str)
            return

        update = JobStatusUpdate(
            job_id=job_id,
            status=status,
            result=payload.get("result"),
            error_message=payload.get("error_message"),
            progress=payload.get("progress"),
        )

        with self._handlers_lock:
            handler = self._channel_handlers.get(job_id)
        if handler is not None:
            try:
                handler(update)
            except Exception:
                logger.debug("Error in job handler for %s", job_id, exc_info=True)

    # ---- Internal: reconnection (MCLI-054) ----------------------------------

    def _reconnect(self) -> bool:
        """Attempt to reconnect with exponential backoff.

        Returns True if reconnection succeeded, False if it should give up.
        """
        if not self._reconnect_lock.acquire(blocking=False):
            # Another thread is already reconnecting
            return False

        try:
            self._set_state(ConnectionState.RECONNECTING)
            self._emit_event(
                ConnectionEventType.RECONNECTING, "Attempting reconnection"
            )
            self._close_connection()

            attempt = 0
            while not self._stop_event.is_set():
                if (
                    self._max_reconnect_attempts is not None
                    and attempt >= self._max_reconnect_attempts
                ):
                    logger.warning(
                        "Max reconnect attempts (%d) reached",
                        self._max_reconnect_attempts,
                    )
                    self._set_state(ConnectionState.DISCONNECTED)
                    self._emit_event(
                        ConnectionEventType.DISCONNECTED,
                        "Reconnection failed after max attempts",
                    )
                    return False

                delay = _calculate_ws_backoff(attempt)
                logger.info(
                    "Reconnect attempt %d, waiting %.1fs", attempt + 1, delay
                )
                if self._stop_event.wait(timeout=delay):
                    return False

                try:
                    self._open_connection()
                except WebSocketAuthError:
                    logger.error("Auth failed during reconnect — giving up")
                    self._set_state(ConnectionState.DISCONNECTED)
                    self._emit_event(
                        ConnectionEventType.AUTH_FAILED,
                        "Authentication failed during reconnection",
                    )
                    return False
                except Exception as exc:
                    logger.debug("Reconnect attempt %d failed: %s", attempt + 1, exc)
                    attempt += 1
                    continue

                # Reconnected successfully
                self._set_state(ConnectionState.CONNECTED)
                self._emit_event(
                    ConnectionEventType.RECONNECTED, "WebSocket reconnected"
                )
                self._restore_subscriptions()
                return True

            return False
        finally:
            self._reconnect_lock.release()

    # ---- Internal: events ---------------------------------------------------

    def _emit_event(self, event_type: ConnectionEventType, message: str) -> None:
        """Fire the on_event callback if registered."""
        if self._on_event is None:
            return
        event = ConnectionEvent(event_type=event_type, message=message)
        try:
            self._on_event(event)
        except Exception:
            logger.debug("Error in on_event callback", exc_info=True)
