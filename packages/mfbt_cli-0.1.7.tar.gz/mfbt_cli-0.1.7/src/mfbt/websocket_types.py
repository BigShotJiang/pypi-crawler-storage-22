"""Data types for WebSocket communication.

Provides enums and frozen dataclasses for connection state, transport mode,
job status tracking, and lifecycle events. Pure data — no I/O dependencies.
Covers MCLI-053 (types).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any

# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------


class ConnectionState(Enum):
    """WebSocket connection lifecycle states."""

    DISCONNECTED = "disconnected"
    CONNECTING = "connecting"
    CONNECTED = "connected"
    RECONNECTING = "reconnecting"


class TransportMode(Enum):
    """Active transport for job status updates."""

    WEBSOCKET = "websocket"
    POLLING = "polling"
    NONE = "none"


class JobStatus(Enum):
    """Job execution status values."""

    QUEUED = "queued"
    RUNNING = "running"
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    CANCELLED = "cancelled"

    @property
    def is_terminal(self) -> bool:
        """Return True if this status represents a final state."""
        return self in _TERMINAL_STATUSES


_TERMINAL_STATUSES = frozenset(
    {JobStatus.SUCCEEDED, JobStatus.FAILED, JobStatus.CANCELLED}
)


class ConnectionEventType(Enum):
    """Types of connection lifecycle events."""

    CONNECTED = "connected"
    DISCONNECTED = "disconnected"
    RECONNECTING = "reconnecting"
    RECONNECTED = "reconnected"
    AUTH_FAILED = "auth_failed"
    ERROR = "error"
    TRANSPORT_CHANGED = "transport_changed"


# ---------------------------------------------------------------------------
# Frozen dataclasses
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class WebSocketMessage:
    """A parsed WebSocket message."""

    type: str
    payload: dict[str, Any]
    timestamp: str
    raw: str


@dataclass(frozen=True)
class JobStatusUpdate:
    """A job status change notification."""

    job_id: str
    status: JobStatus
    result: Any = None
    error_message: str | None = None
    progress: float | None = None


@dataclass(frozen=True)
class ConnectionEvent:
    """A connection lifecycle event for callbacks."""

    event_type: ConnectionEventType
    message: str = ""
    timestamp: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )
