"""Typer CLI application for mfbt.

Provides subcommands like `auth login` for the mfbt CLI.
"""

from __future__ import annotations

import logging
import webbrowser
from typing import Optional
from urllib.parse import urlencode

import typer
from rich.console import Console

from mfbt.formatters import resolve_format

logger = logging.getLogger("mfbt.cli")
console = Console()

app = typer.Typer(
    name="mfbt",
    help="CLI tool for the mfbt platform",
    no_args_is_help=True,
)

auth_app = typer.Typer(
    name="auth",
    help="Authentication commands",
    no_args_is_help=True,
)
app.add_typer(auth_app, name="auth")


# ---------------------------------------------------------------------------
# Global callback: --format, --verbose
# ---------------------------------------------------------------------------


@app.callback()
def main_callback(
    ctx: typer.Context,
    fmt: Optional[str] = typer.Option(
        None,
        "--format",
        "-f",
        help="Output format: table, json, plain",
        metavar="FORMAT",
    ),
    verbose: bool = typer.Option(
        False,
        "--verbose",
        help="Show detailed error output",
    ),
) -> None:
    """CLI tool for the mfbt platform."""
    from mfbt.config import VALID_FORMATS, init_mfbt_dir, resolve_config

    ctx.ensure_object(dict)

    if fmt is not None and fmt not in VALID_FORMATS:
        console.print(
            f"[red]Error:[/red] Invalid format '{fmt}'. "
            f"Choose from: json, plain, table"
        )
        raise typer.Exit(code=1)

    init_mfbt_dir()
    config = resolve_config()

    ctx.obj["config"] = config
    ctx.obj["verbose"] = verbose
    ctx.obj["format"] = resolve_format(fmt, config.get("default_format"))


# ---------------------------------------------------------------------------
# Register command groups
# ---------------------------------------------------------------------------

from mfbt.commands import register_commands  # noqa: E402

register_commands(app)


@app.command()
def tui(ctx: typer.Context) -> None:
    """Launch the interactive TUI."""
    from mfbt.config import is_authenticated

    if not is_authenticated():
        console.print(
            "[red]Error:[/red] Not authenticated. "
            "Run [bold]mfbt auth login[/bold] first."
        )
        raise typer.Exit(code=1)
    from mfbt.tui import launch_tui

    launch_tui(ctx.obj["config"])


# ---------------------------------------------------------------------------
# Auth commands
# ---------------------------------------------------------------------------


@auth_app.command()
def login(
    base_url: str = typer.Option(
        None,
        "--base-url",
        help="mfbt backend URL (overrides config)",
    ),
    timeout: int = typer.Option(
        120,
        "--timeout",
        help="Seconds to wait for browser callback",
    ),
    no_browser: bool = typer.Option(
        False,
        "--no-browser",
        help="Print the auth URL instead of opening the browser",
    ),
) -> None:
    """Authenticate with the mfbt platform via browser-based OAuth."""
    from mfbt.auth import (
        AuthError,
        AuthTimeoutError,
        ClientRegistrationError,
        OAUTH_SCOPES,
        TokenExchangeError,
        exchange_code_for_tokens,
        generate_pkce_params,
        start_callback_server,
        wait_for_callback,
    )

    from mfbt.config import init_mfbt_dir, resolve_config

    init_mfbt_dir()
    config = resolve_config()

    effective_base_url = base_url or config.get("base_url", "https://app.mfbt.ai")

    from mfbt.token_manager import TokenManager

    tm = TokenManager(effective_base_url)

    # Generate PKCE parameters
    pkce = generate_pkce_params()

    # Start callback server first to get the port
    try:
        server, port = start_callback_server(pkce.state)
    except AuthError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(code=1) from exc

    redirect_uri = f"http://127.0.0.1:{port}/callback"

    # Register OAuth client (RFC 7591 Dynamic Client Registration).
    # Important: do NOT save the client_id yet — if the auth flow fails,
    # we must not overwrite the existing client_id that the current
    # refresh token is bound to.
    console.print("Registering OAuth client...")
    try:
        from mfbt.auth import register_client

        registered = register_client(effective_base_url, [redirect_uri])
        client_id = registered.client_id
    except ClientRegistrationError as exc:
        server.server_close()
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(code=1) from exc

    # Build authorization URL
    auth_params = {
        "client_id": client_id,
        "redirect_uri": redirect_uri,
        "code_challenge": pkce.code_challenge,
        "code_challenge_method": pkce.code_challenge_method,
        "response_type": "code",
        "state": pkce.state,
        "scope": OAUTH_SCOPES,
    }
    base = effective_base_url.rstrip("/")
    auth_url = f"{base}/oauth/authorize?{urlencode(auth_params)}"

    # Open browser or print URL
    if no_browser:
        console.print("\nOpen this URL in your browser to authenticate:\n")
        console.print(f"  {auth_url}\n")
    else:
        console.print("Opening browser for authentication...")
        webbrowser.open(auth_url)

    console.print(
        f"Waiting for callback on http://127.0.0.1:{port}/callback "
        f"(timeout: {timeout}s)..."
    )

    # Wait for callback
    try:
        result = wait_for_callback(server, timeout=timeout)
    except AuthTimeoutError:
        server.server_close()
        console.print(
            "[red]Error:[/red] Authentication timed out. Please try again."
        )
        raise typer.Exit(code=1)
    except AuthError as exc:
        server.server_close()
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(code=1) from exc
    finally:
        server.server_close()

    # Exchange code for tokens
    console.print("Exchanging authorization code for tokens...")
    try:
        token_response = exchange_code_for_tokens(
            base_url=effective_base_url,
            code=result.code,
            code_verifier=pkce.code_verifier,
            redirect_uri=redirect_uri,
            client_id=client_id,
        )
    except TokenExchangeError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(code=1) from exc

    # Only save client_id now that the full auth flow succeeded.
    tm.save_client_id(client_id)
    tm.save_tokens(token_response)
    console.print("[green]Successfully authenticated![/green]")


# ---------------------------------------------------------------------------
# Helper: ensure auth for auth subcommands
# ---------------------------------------------------------------------------


def _ensure_auth() -> dict:
    """Init ~/.mfbt dir and return config.

    Falls back gracefully — does not require existing auth tokens.
    """
    from mfbt.config import init_mfbt_dir, resolve_config

    init_mfbt_dir()
    return resolve_config()


@auth_app.command()
def status() -> None:
    """Show current authentication status."""
    from datetime import datetime, timezone

    from mfbt.token_manager import TokenManager

    config = _ensure_auth()
    base_url = config.get("base_url", "https://app.mfbt.ai")
    tm = TokenManager(base_url)

    tokens = tm.load_tokens()
    if tokens is None:
        console.print("[yellow]Not authenticated.[/yellow]")
        console.print("Run [bold]mfbt auth login[/bold] to authenticate.")
        return

    expires_at = tokens.get("expires_at")
    if expires_at is None:
        console.print("[green]Authenticated[/green] (no expiry set)")
        return

    try:
        expiry = datetime.fromisoformat(expires_at)
        now = datetime.now(timezone.utc)
        if now >= expiry:
            if tokens.get("refresh_token"):
                console.print(
                    "[yellow]Access token expired[/yellow] "
                    "(refresh token still valid — will auto-refresh on next command)."
                )
                console.print(
                    "Or run [bold]mfbt auth refresh[/bold] to refresh now."
                )
            else:
                console.print("[red]Token expired (no refresh token).[/red]")
                console.print(
                    "Run [bold]mfbt auth login[/bold] to re-authenticate."
                )
        else:
            remaining = expiry - now
            minutes = int(remaining.total_seconds() // 60)
            if minutes >= 60:
                hours = minutes // 60
                mins = minutes % 60
                time_str = f"{hours}h {mins}m"
            else:
                time_str = f"{minutes}m"
            console.print(f"[green]Authenticated[/green] (expires in {time_str})")
    except (ValueError, TypeError):
        console.print("[yellow]Authenticated[/yellow] (unable to parse expiry)")


@auth_app.command()
def refresh() -> None:
    """Manually refresh the access token."""
    from mfbt.token_manager import (
        RefreshTokenExpiredError,
        RefreshTokenInvalidError,
        TokenError,
        TokenManager,
        TokenRefreshNetworkError,
    )

    config = _ensure_auth()
    base_url = config.get("base_url", "https://app.mfbt.ai")
    tm = TokenManager(base_url)

    try:
        tm.refresh_tokens()
        console.print("[green]Token refreshed successfully.[/green]")
    except (RefreshTokenExpiredError, RefreshTokenInvalidError) as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(code=1) from exc
    except TokenRefreshNetworkError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(code=1) from exc
    except TokenError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(code=1) from exc


@auth_app.command()
def logout() -> None:
    """Clear stored authentication tokens."""
    from mfbt.token_manager import TokenManager

    config = _ensure_auth()
    base_url = config.get("base_url", "https://app.mfbt.ai")
    tm = TokenManager(base_url)

    tm.clear_tokens()
    console.print("Logged out successfully.")
