"""Subprocess spawning and monitoring for coding agents."""

from __future__ import annotations

import json as _json
import logging
import shutil
import subprocess
import threading
import time
from collections.abc import Callable

from mfbt.commands.ralph.types import AgentResult, AgentType

logger = logging.getLogger("mfbt.commands.ralph.agent")


class AgentNotFoundError(Exception):
    """Raised when the coding agent binary is not on PATH."""


# ---------------------------------------------------------------------------
# stream-json parsing helpers
# ---------------------------------------------------------------------------


def _summarize_tool_use(name: str, inp: dict) -> str:
    """One-line summary of a tool invocation."""
    if name in ("Read", "Glob"):
        path = inp.get("file_path") or inp.get("path") or inp.get("pattern", "")
        return f"→ {name}: {path}"
    if name == "Grep":
        pattern = inp.get("pattern", "")
        path = inp.get("path", "")
        return f"→ Grep: '{pattern}' in {path}" if path else f"→ Grep: '{pattern}'"
    if name in ("Edit", "Write"):
        path = inp.get("file_path", "")
        return f"→ {name}: {path}"
    if name == "Bash":
        cmd = inp.get("command", "")
        if len(cmd) > 100:
            cmd = cmd[:97] + "..."
        return f"→ Bash: {cmd}"
    if name == "Task":
        desc = inp.get("description", "")
        return f"→ Task: {desc}"
    return f"→ {name}"


def _extract_display_text(raw_line: str) -> str | None:
    """Parse a stream-json JSONL line and return human-readable text.

    Returns ``None`` for events that should not be displayed (tool results,
    system events, unrecognised types).
    """
    line = raw_line.strip()
    if not line:
        return None

    try:
        event = _json.loads(line)
    except (ValueError, _json.JSONDecodeError):
        # Not JSON — return as-is (shouldn't normally happen).
        return line

    if not isinstance(event, dict):
        return None

    event_type = event.get("type", "")

    if event_type == "assistant":
        message = event.get("message", {})
        content_blocks = message.get("content", [])
        if not isinstance(content_blocks, list):
            return None
        parts: list[str] = []
        for block in content_blocks:
            bt = block.get("type", "")
            if bt == "text":
                text = block.get("text", "").strip()
                if text:
                    parts.append(text)
            elif bt == "tool_use":
                name = block.get("name", "?")
                inp = block.get("input", {})
                parts.append(_summarize_tool_use(name, inp))
        return "\n".join(parts) if parts else None

    if event_type == "result":
        subtype = event.get("subtype", "")
        if subtype == "error":
            error_msg = event.get("error", "")
            return f"Error: {error_msg}" if error_msg else None
        # Success result text was already shown via assistant messages.
        return None

    # Skip system, tool_result, stream_event (partial tokens), etc.
    return None


class AgentRunner:
    """Spawns and monitors a coding agent subprocess."""

    # Instructions appended to the agent's system prompt to guide its
    # behaviour during autonomous feature implementation.
    _APPEND_SYSTEM_PROMPT = (
        "NEVER use the Plan agent or ExitPlanMode tool. Do your planning "
        "inline as part of your regular response, then proceed directly to "
        "implementation. Do not enter plan mode."
       "Do not ask the user any questions. You are running autonomously."
       "If a feature is complete as per the prompt plan, mark it as complete and add "
       "implementation notes for it in mfbt."
       "Very importantly, here's the sequence to follow with mfbt mcp: mark feature as "
       "in-progress, implement it, mark it as complete and add implementation notes for "
        "it in mfbt."
    )

    def __init__(
        self,
        agent_type: AgentType,
        max_turns: int | None = None,
        special_instructions: str | None = None,
    ) -> None:
        self._agent_type = agent_type
        self._max_turns = max_turns
        self._special_instructions = special_instructions
        self._process: subprocess.Popen | None = None

    def build_command(self, prompt: str) -> list[str]:
        """Build the CLI command list for the agent."""
        if self._agent_type == AgentType.CLAUDE:
            cmd = [
                "claude",
                "--dangerously-skip-permissions",
                "-p", prompt,
                "--output-format", "stream-json",
                "--verbose",
            ]
            if self._max_turns is not None:
                cmd.extend(["--max-turns", str(self._max_turns)])
            append_prompt = self._APPEND_SYSTEM_PROMPT
            if self._special_instructions:
                append_prompt += (
                    "\n\nAdditional instructions from the project owner:\n"
                    + self._special_instructions
                )
            cmd.extend(["--append-system-prompt", append_prompt])
            return cmd
        msg = f"Unsupported agent type: {self._agent_type}"
        raise ValueError(msg)

    def _validate_binary(self) -> None:
        """Check that the agent binary is available on PATH."""
        if self._agent_type == AgentType.CLAUDE:
            binary = "claude"
        else:
            msg = f"Unsupported agent type: {self._agent_type}"
            raise ValueError(msg)

        if shutil.which(binary) is None:
            raise AgentNotFoundError(
                f"'{binary}' not found on PATH. "
                f"Install it or ensure it is in your PATH."
            )

    def run(
        self,
        prompt: str,
        on_output: Callable[[str], None] | None = None,
    ) -> AgentResult:
        """Run the agent with *prompt* and wait for it to complete.

        *on_output* is called with human-readable display text extracted
        from the stream-json JSONL output.
        """
        self._validate_binary()
        cmd = self.build_command(prompt)
        logger.debug("Spawning agent: %s", " ".join(cmd[:3]) + " ...")

        start = time.monotonic()
        self._process = subprocess.Popen(
            cmd,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )

        stdout_lines: list[str] = []
        stderr_lines: list[str] = []

        def _read_stdout(
            stream,
            buf: list[str],
            callback: Callable[[str], None] | None,
        ) -> None:
            assert stream is not None
            for raw_line in iter(stream.readline, b""):
                line = raw_line.decode("utf-8", errors="replace")
                buf.append(line)
                if callback is not None:
                    display_text = _extract_display_text(line)
                    if display_text:
                        callback(display_text + "\n")
            stream.close()

        def _read_stderr(
            stream,
            buf: list[str],
        ) -> None:
            assert stream is not None
            for raw_line in iter(stream.readline, b""):
                buf.append(raw_line.decode("utf-8", errors="replace"))
            stream.close()

        stdout_thread = threading.Thread(
            target=_read_stdout,
            args=(self._process.stdout, stdout_lines, on_output),
            daemon=True,
        )
        stderr_thread = threading.Thread(
            target=_read_stderr,
            args=(self._process.stderr, stderr_lines),
            daemon=True,
        )
        stdout_thread.start()
        stderr_thread.start()

        self._process.wait()
        stdout_thread.join(timeout=5)
        stderr_thread.join(timeout=5)

        elapsed = time.monotonic() - start

        return AgentResult(
            exit_code=self._process.returncode,
            elapsed_seconds=elapsed,
            stdout="".join(stdout_lines),
            stderr="".join(stderr_lines),
        )

    def terminate(self) -> None:
        """Terminate the running agent subprocess (SIGTERM, then SIGKILL)."""
        proc = self._process
        if proc is None or proc.poll() is not None:
            return

        logger.info("Sending SIGTERM to agent (pid=%d)", proc.pid)
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            logger.warning("Agent did not exit after SIGTERM; sending SIGKILL")
            proc.kill()
            proc.wait(timeout=5)
