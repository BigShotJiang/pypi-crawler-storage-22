"""Data types for the ralph orchestration command."""

from __future__ import annotations

import enum
from dataclasses import dataclass, field


class AgentType(enum.Enum):
    """Supported coding agent types."""

    CLAUDE = "claude"


class OrchestrationMode(enum.Enum):
    """How ralph selects features to implement."""

    FEATURE_BY_FEATURE = "feature-by-feature"
    MODULE_BY_MODULE = "module-by-module"


class FeatureOutcome(enum.Enum):
    """Outcome of a single feature implementation attempt."""

    SUCCESS = "success"
    FAILED = "failed"
    SKIPPED = "skipped"


@dataclass(frozen=True)
class PhaseInfo:
    """Identifier and title for a brainstorming phase."""

    phase_id: str
    phase_title: str


@dataclass(frozen=True)
class RalphConfig:
    """Configuration for a ralph session."""

    project_id: str
    phases: tuple[PhaseInfo, ...]
    coding_agent: AgentType
    mode: OrchestrationMode
    max_turns: int | None
    quiet: bool
    base_url: str
    special_instructions: str | None = None

    @property
    def phase_ids(self) -> list[str]:
        return [p.phase_id for p in self.phases]

    @property
    def is_single_phase(self) -> bool:
        return len(self.phases) == 1


@dataclass(frozen=True)
class FeatureTask:
    """A single feature to be implemented by a coding agent."""

    feature_id: str
    feature_key: str
    title: str
    module_key: str
    module_title: str
    priority: str
    implementation_id: str
    spec_text: str | None
    prompt_plan_text: str | None
    phase_id: str = ""
    phase_title: str = ""


@dataclass(frozen=True)
class FeatureResult:
    """Result of attempting to implement a feature."""

    feature: FeatureTask
    outcome: FeatureOutcome
    attempts: int
    elapsed_seconds: float
    agent_exit_code: int | None
    error_message: str | None


@dataclass(frozen=True)
class AgentResult:
    """Result from a single agent subprocess run."""

    exit_code: int
    elapsed_seconds: float
    stdout: str
    stderr: str


@dataclass(frozen=True)
class SessionSummary:
    """Summary of a complete ralph session."""

    results: list[FeatureResult] = field(default_factory=list)
    total_elapsed_seconds: float = 0.0

    @property
    def succeeded(self) -> int:
        return sum(1 for r in self.results if r.outcome == FeatureOutcome.SUCCESS)

    @property
    def failed(self) -> int:
        return sum(1 for r in self.results if r.outcome == FeatureOutcome.FAILED)

    @property
    def skipped(self) -> int:
        return sum(1 for r in self.results if r.outcome == FeatureOutcome.SKIPPED)

    @property
    def total(self) -> int:
        return len(self.results)
