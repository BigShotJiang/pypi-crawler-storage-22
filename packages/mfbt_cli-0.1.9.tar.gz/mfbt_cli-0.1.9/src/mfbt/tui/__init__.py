"""Interactive TUI for the mfbt CLI.

Provides launch_tui() as the entry point. Textual is only imported
when the TUI is actually launched, keeping the CLI startup fast.
"""

from __future__ import annotations

import logging
from typing import Any

from mfbt.auth_flow import run_interactive_auth

logger = logging.getLogger("mfbt.tui")


def launch_tui(config: dict[str, Any]) -> None:
    """Launch the interactive TUI application."""
    from mfbt.api_client import APIClient
    from mfbt.cache import ResponseCache
    from mfbt.config import get_mfbt_dir
    from mfbt.token_manager import TokenManager
    from mfbt.tui.app import MFBTApp

    base_url = config.get("base_url", "https://app.mfbt.ai")
    tm = TokenManager(base_url)

    # Check if user is authenticated before starting the TUI
    if tm.load_tokens() is None:
        from rich.console import Console
        from rich.prompt import Confirm

        console = Console()
        console.print("\n[yellow]You are not authenticated.[/yellow]")
        console.print(
            "mfbt needs to open your browser to sign in.\n"
        )

        try:
            if not Confirm.ask("Open browser to authenticate?"):
                console.print(
                    "\nRun [bold]mfbt auth login[/bold] to authenticate later."
                )
                return
        except (KeyboardInterrupt, EOFError):
            console.print("\nExiting.")
            return

        console.print()
        if not run_interactive_auth(base_url, tm, console):
            return

    def _on_auth_required() -> bool:
        # Don't auto-open the browser — just signal failure so the
        # API client surfaces an auth error.  The TUI's token monitor
        # or notification will tell the user to run `mfbt auth login`.
        return False

    mfbt_dir = get_mfbt_dir()
    cache = ResponseCache(mfbt_dir / "cache")
    api_client = APIClient(base_url, tm, cache=cache, on_auth_required=_on_auth_required)

    job_monitor = None
    try:
        from mfbt.job_monitor import JobMonitor

        job_monitor = JobMonitor(base_url, tm, api_client)
    except Exception:
        pass  # Graceful degradation if WebSocket deps unavailable

    app = MFBTApp(config, api_client, job_monitor)
    try:
        app.run()
    finally:
        if job_monitor:
            job_monitor.shutdown()
        api_client.close()
