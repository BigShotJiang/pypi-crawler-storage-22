"""Main Textual application for the mfbt TUI.

Uses a panel-swapping model: the chrome (K9sHeader, CommandBar,
StatusBar) stays mounted at all times. Content panels (project list, phase
list, module list, feature list, ralph panel) are swapped inside
#main-content. Modal overlays (feature detail, info modal, help) are pushed
as ModalScreen on top.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Container

from mfbt.tui.data_provider import TUIDataProvider
from mfbt.tui.navigation import NavigationItem, NavigationLevel, NavigationState
from mfbt.tui.widgets.command_bar import CommandBar
from mfbt.tui.widgets.k9s_header import K9sHeader
from mfbt.tui.widgets.status_bar import StatusBar

if TYPE_CHECKING:
    from mfbt.api_client import APIClient
    from mfbt.job_monitor import JobMonitor
    from mfbt.websocket_types import TransportMode


# Hints per navigation level
_LEVEL_HINTS: dict[NavigationLevel, tuple[tuple[str, str], ...]] = {
    NavigationLevel.PROJECTS: (
        ("q", "Quit"),
        ("?", "Help"),
        ("ctrl+r", "Refresh"),
        ("r", "Ralph"),
        ("enter", "Open"),
        ("d", "Describe"),
    ),
    NavigationLevel.PHASES: (
        ("q", "Quit"),
        ("?", "Help"),
        ("ctrl+r", "Refresh"),
        ("r", "Ralph"),
        ("enter", "Open"),
        ("d", "Describe"),
        ("esc", "Back"),
    ),
    NavigationLevel.MODULES: (
        ("q", "Quit"),
        ("?", "Help"),
        ("ctrl+r", "Refresh"),
        ("r", "Ralph"),
        ("enter", "Open"),
        ("d", "Describe"),
        ("esc", "Back"),
    ),
    NavigationLevel.FEATURES: (
        ("q", "Quit"),
        ("?", "Help"),
        ("ctrl+r", "Refresh"),
        ("r", "Ralph"),
        ("enter", "Detail"),
        ("d", "Describe"),
        ("esc", "Back"),
    ),
}


class MFBTApp(App):
    """K9S-style interactive TUI for the mfbt platform."""

    CSS_PATH = "app.tcss"
    TITLE = "mfbt"

    BINDINGS = [
        Binding("q", "quit", "Quit", priority=True),
        Binding("question_mark", "show_help", "Help", show=False),
        Binding("escape", "go_back", "Back", show=False),
        Binding("backspace", "go_back", "Back", show=False),
        Binding("ctrl+r", "refresh", "Refresh", show=False),
        Binding("r", "launch_ralph", "Ralph", show=False),
        Binding("c", "ralph_confirm", "Confirm", show=False),
        Binding("d", "describe", "Describe", show=False),
        Binding("p", "ralph_pause", "Pause", show=False),
        Binding("k", "ralph_kill", "Kill", show=False),
        Binding("i", "ralph_instructions", "Instructions", show=False),
    ]

    def __init__(
        self,
        config: dict[str, Any],
        api_client: APIClient,
        job_monitor: JobMonitor | None = None,
    ) -> None:
        super().__init__()
        self.config = config
        self.api_client = api_client
        self.job_monitor = job_monitor
        self.data_provider = TUIDataProvider(api_client)
        self.nav_state = NavigationState()
        self._token_monitor: Any = None
        self._ralph_active: bool = False
        self._ralph_panel: Any = None

    def compose(self) -> ComposeResult:
        yield K9sHeader(id="k9s-header")
        yield Container(id="main-content")
        yield CommandBar(id="command-bar")
        yield StatusBar(id="status-bar")

    def on_mount(self) -> None:
        # Set the current working directory in the status bar
        import os

        try:
            status_bar = self.query_one("#status-bar", StatusBar)
            status_bar.cwd = os.getcwd()
        except Exception:
            pass

        self._show_project_list()
        self._update_nav_display()

        # Wire up transport change callback
        if self.job_monitor is not None:
            original_cb = self.job_monitor._on_transport_change

            def _on_transport(mode: TransportMode) -> None:
                if original_cb is not None:
                    original_cb(mode)
                self.call_from_thread(self._update_transport, mode)

            self.job_monitor._on_transport_change = _on_transport

        # Start background token monitor
        self._start_token_monitor()

    # ---- Content panel swapping ----------------------------------------

    def _clear_main_content(self) -> None:
        """Remove all children from #main-content."""
        container = self.query_one("#main-content", Container)
        container.remove_children()

    def _show_project_list(self) -> None:
        """Mount the project list panel."""
        from mfbt.tui.screens.project_list import ProjectListPanel

        self._clear_main_content()
        container = self.query_one("#main-content", Container)
        container.mount(ProjectListPanel(self.data_provider))

    def _show_phase_list(
        self,
        project_id: str,
        project_name: str,
        project_key: str,
        project_metadata: dict[str, Any],
    ) -> None:
        """Mount the phase list panel for a project."""
        from mfbt.tui.screens.phase_list import PhaseListPanel

        self._clear_main_content()
        container = self.query_one("#main-content", Container)
        container.mount(
            PhaseListPanel(
                data_provider=self.data_provider,
                project_id=project_id,
                project_name=project_name,
                project_key=project_key,
                project_metadata=project_metadata,
            )
        )

    def _show_module_list(
        self,
        project_id: str,
        project_name: str,
        project_key: str,
        project_metadata: dict[str, Any],
        phase_id: str = "",
        phase_title: str = "",
        phase_modules: list[dict[str, Any]] | None = None,
        orphan_modules: list[dict[str, Any]] | None = None,
    ) -> None:
        """Mount the module list panel for a project, optionally filtered by phase."""
        from mfbt.tui.screens.module_list import ModuleListPanel

        self._clear_main_content()
        container = self.query_one("#main-content", Container)
        container.mount(
            ModuleListPanel(
                data_provider=self.data_provider,
                project_id=project_id,
                project_name=project_name,
                project_key=project_key,
                project_metadata=project_metadata,
                phase_id=phase_id,
                phase_title=phase_title,
                phase_modules=phase_modules,
                orphan_modules=orphan_modules,
            )
        )

    def _show_feature_list(
        self,
        project_id: str,
        project_name: str,
        project_key: str,
        project_metadata: dict[str, Any],
        module_id: str,
        module_name: str,
        module_key: str,
        module_metadata: dict[str, Any],
    ) -> None:
        """Mount the feature list panel for a module."""
        from mfbt.tui.screens.feature_list import FeatureListPanel

        self._clear_main_content()
        container = self.query_one("#main-content", Container)
        container.mount(
            FeatureListPanel(
                data_provider=self.data_provider,
                project_id=project_id,
                project_name=project_name,
                module_id=module_id,
                module_name=module_name,
                module_key=module_key,
                module_metadata=module_metadata,
            )
        )

    # ---- Message handlers from content panels --------------------------

    def on_project_list_panel_project_selected(
        self, event: Any
    ) -> None:
        """Handle project selection: navigate to phases."""
        data = event.data
        project_id = data.get("id", "")
        project_name = data.get("name", "Unknown")
        project_key = data.get("key", data.get("short_url_id", ""))
        tech_stack = data.get("tech_stack", "")
        if isinstance(tech_stack, list):
            tech_stack = ", ".join(tech_stack[:3])

        project_metadata = {
            "tech_stack": tech_stack,
            "status": data.get("status", ""),
            "description": data.get("description", ""),
        }

        # Push nav state
        self.nav_state.drill_down(
            NavigationItem(
                id=project_id,
                name=project_name,
                level=NavigationLevel.PROJECTS,
                key=project_key,
                metadata=project_metadata,
            )
        )

        self._show_phase_list(project_id, project_name, project_key, project_metadata)
        self._update_nav_display()

    def on_phase_list_panel_phase_selected(
        self, event: Any
    ) -> None:
        """Handle phase selection: navigate to modules."""
        from mfbt.tui.screens.phase_list import _VIRTUAL_ORPHAN_PHASE_ID

        data = event.data
        phase_id = data.get("id", "")
        phase_title = data.get("title", "Unknown")
        phase_progress = event.phase_progress

        is_virtual = phase_progress.get("_is_virtual", False)

        phase_metadata = {
            "phase_progress": phase_progress,
            "total_features": data.get("_total_features", 0),
            "completed_features": data.get("_completed_features", 0),
            "_is_virtual": is_virtual,
        }

        # Push nav state
        self.nav_state.drill_down(
            NavigationItem(
                id=phase_id,
                name=phase_title,
                level=NavigationLevel.PHASES,
                metadata=phase_metadata,
            )
        )

        project_id = event.project_id
        project_name = event.project_name
        project_key = event.project_key
        project_metadata = event.project_metadata

        if is_virtual:
            # Virtual orphan phase — show orphan modules
            orphan_modules = phase_progress.get("orphan_modules", [])
            self._show_module_list(
                project_id=project_id,
                project_name=project_name,
                project_key=project_key,
                project_metadata=project_metadata,
                phase_id=_VIRTUAL_ORPHAN_PHASE_ID,
                phase_title=phase_title,
                orphan_modules=orphan_modules,
            )
        else:
            # Use module data from phase progress
            phase_modules = phase_progress.get("modules", [])
            self._show_module_list(
                project_id=project_id,
                project_name=project_name,
                project_key=project_key,
                project_metadata=project_metadata,
                phase_id=phase_id,
                phase_title=phase_title,
                phase_modules=phase_modules,
            )
        self._update_nav_display()

    def on_module_list_panel_module_selected(
        self, event: Any
    ) -> None:
        """Handle module selection: navigate to features."""
        data = event.data
        module_id = data.get("id", data.get("module_id", ""))
        module_name = data.get("title", data.get("name", "Unknown"))
        module_key = data.get("module_key", data.get("key", ""))
        feature_count = data.get("feature_count", data.get("total_features", 0))

        module_metadata = {
            "feature_count": feature_count or 0,
            "completion_pct": data.get("progress_percent", 0.0) / 100.0
            if data.get("progress_percent")
            else 0.0,
        }

        # The project info is carried in the event
        project_id = event.project_id
        project_name = event.project_name
        project_key = event.project_key
        project_metadata = event.project_metadata

        # Push nav state
        self.nav_state.drill_down(
            NavigationItem(
                id=module_id,
                name=module_name,
                level=NavigationLevel.MODULES,
                key=module_key,
                metadata=module_metadata,
            )
        )

        self._show_feature_list(
            project_id=project_id,
            project_name=project_name,
            project_key=project_key,
            project_metadata=project_metadata,
            module_id=module_id,
            module_name=module_name,
            module_key=module_key,
            module_metadata=module_metadata,
        )
        self._update_nav_display()

    def on_feature_list_panel_feature_selected(
        self, event: Any
    ) -> None:
        """Handle feature selection: open detail modal."""
        from mfbt.tui.screens.feature_detail import FeatureDetailScreen

        feature_id = event.data.get("id", "")
        self.push_screen(
            FeatureDetailScreen(
                data_provider=self.data_provider,
                feature_id=feature_id,
                feature_data=event.data,
            )
        )

    # ---- Describe handlers from content panels -------------------------

    def _handle_describe(self, data: dict[str, Any] | None, resource_type: str) -> None:
        """Open info modal for the given resource."""
        if data:
            from mfbt.tui.screens.info_modal import InfoModal

            self.push_screen(InfoModal(data=data, resource_type=resource_type))

    # ---- Navigation actions -------------------------------------------

    def action_go_back(self) -> None:
        """Navigate back one level."""
        # If ralph is active, try going back within ralph first
        if self._ralph_active:
            if self._ralph_panel is not None and self._ralph_panel.go_back():
                return  # Stayed within ralph (e.g. feature list → overview)
            self._stop_ralph()
            return

        level = self.nav_state.level
        if level == NavigationLevel.PROJECTS:
            return  # Already at root, do nothing
        elif level == NavigationLevel.PHASES:
            self.nav_state.go_up()
            self._show_project_list()
        elif level == NavigationLevel.MODULES:
            self.nav_state.go_up()
            # Restore phase list
            if self.nav_state.stack:
                proj = self.nav_state.stack[0]
                self._show_phase_list(
                    project_id=proj.id,
                    project_name=proj.name,
                    project_key=proj.key,
                    project_metadata=proj.metadata,
                )
        elif level == NavigationLevel.FEATURES:
            self.nav_state.go_up()
            # Restore module list
            if len(self.nav_state.stack) >= 2:
                proj = self.nav_state.stack[0]
                phase = self.nav_state.stack[1]
                if phase.metadata.get("_is_virtual"):
                    phase_progress = phase.metadata.get("phase_progress", {})
                    orphan_modules = phase_progress.get("orphan_modules", [])
                    self._show_module_list(
                        project_id=proj.id,
                        project_name=proj.name,
                        project_key=proj.key,
                        project_metadata=proj.metadata,
                        phase_id=phase.id,
                        phase_title=phase.name,
                        orphan_modules=orphan_modules,
                    )
                else:
                    phase_progress = phase.metadata.get("phase_progress", {})
                    phase_modules = phase_progress.get("modules", [])
                    self._show_module_list(
                        project_id=proj.id,
                        project_name=proj.name,
                        project_key=proj.key,
                        project_metadata=proj.metadata,
                        phase_id=phase.id,
                        phase_title=phase.name,
                        phase_modules=phase_modules,
                    )
        self._update_nav_display()

    def action_refresh(self) -> None:
        """Refresh the current content panel."""
        from mfbt.tui.screens.feature_list import FeatureListPanel
        from mfbt.tui.screens.module_list import ModuleListPanel
        from mfbt.tui.screens.phase_list import PhaseListPanel
        from mfbt.tui.screens.project_list import ProjectListPanel

        container = self.query_one("#main-content", Container)
        for child in container.children:
            if isinstance(child, (ProjectListPanel, PhaseListPanel, ModuleListPanel, FeatureListPanel)):
                child.refresh_data()
                self.notify("Refreshed", timeout=3)
                break

    def action_describe(self) -> None:
        """Show info modal for the selected item."""
        from mfbt.tui.screens.feature_list import FeatureListPanel
        from mfbt.tui.screens.module_list import ModuleListPanel
        from mfbt.tui.screens.phase_list import PhaseListPanel
        from mfbt.tui.screens.project_list import ProjectListPanel

        container = self.query_one("#main-content", Container)
        for child in container.children:
            if isinstance(child, ProjectListPanel):
                self._handle_describe(child.get_selected_data(), "project")
                return
            if isinstance(child, PhaseListPanel):
                self._handle_describe(child.get_selected_data(), "phase")
                return
            if isinstance(child, ModuleListPanel):
                self._handle_describe(child.get_selected_data(), "module")
                return
            if isinstance(child, FeatureListPanel):
                self._handle_describe(child.get_selected_data(), "feature")
                return

    # ---- Ralph integration -------------------------------------------

    def action_launch_ralph(self) -> None:
        """Launch Ralph orchestration view, or run if already on feature list."""
        if self._ralph_active:
            # Re-use 'r' to start the run from the feature list stage
            if self._ralph_panel is not None:
                self._ralph_panel.confirm_and_start()
            return

        from mfbt.tui.screens.ralph_panel import RalphPanel

        # Determine project scope
        project_id = self.nav_state.current_project_id
        if project_id is None:
            # At project list — need a highlighted project
            from mfbt.tui.screens.project_list import ProjectListPanel

            container = self.query_one("#main-content", Container)
            for child in container.children:
                if isinstance(child, ProjectListPanel):
                    data = child.get_selected_data()
                    if data:
                        project_id = data.get("id")
                    break
            if project_id is None:
                self.notify("Select a project first", severity="warning")
                return

        # Determine phase scope
        from mfbt.tui.screens.phase_list import _VIRTUAL_ORPHAN_PHASE_ID

        phase_id = self.nav_state.current_phase_id
        if phase_id == _VIRTUAL_ORPHAN_PHASE_ID:
            phase_id = None  # Virtual phase — run ralph at project scope

        from mfbt.config import get_mfbt_dir

        self._ralph_active = True
        panel = RalphPanel(
            api_client=self.api_client,
            project_id=project_id,
            mfbt_dir=get_mfbt_dir(),
            config=self.config,
            phase_id=phase_id,
        )
        self._ralph_panel = panel
        self._clear_main_content()
        container = self.query_one("#main-content", Container)
        container.mount(panel)

        # Update hints for ralph mode
        try:
            command_bar = self.query_one("#command-bar", CommandBar)
            command_bar.hints = (
                ("c", "Continue"),
                ("esc", "Back"),
                ("?", "Help"),
                ("q", "Quit"),
            )
        except Exception:
            pass

        try:
            header = self.query_one("#k9s-header", K9sHeader)
            header.hints = (
                ("c", "Continue"),
                ("esc", "Back"),
                ("?", "Help"),
                ("q", "Quit"),
            )
            header.ralph_active = True
            # Show project name in ralph header
            project_name = ""
            if self.nav_state.stack:
                project_name = self.nav_state.stack[0].name
            elif project_id:
                # At project list — try to get name from highlighted row
                from mfbt.tui.screens.project_list import ProjectListPanel

                container = self.query_one("#main-content", Container)
                for child in container.children:
                    if isinstance(child, ProjectListPanel):
                        data = child.get_selected_data()
                        if data:
                            project_name = data.get("name", data.get("title", ""))
                        break
            header.ralph_project_name = project_name
        except Exception:
            pass

    def action_ralph_confirm(self) -> None:
        """Delegate 'c' key to the RalphPanel."""
        if self._ralph_active and self._ralph_panel is not None:
            self._ralph_panel.confirm_and_start()

    def action_ralph_pause(self) -> None:
        """Delegate 'p' key to the RalphPanel."""
        if self._ralph_active and self._ralph_panel is not None:
            self._ralph_panel.pause_orchestrator()

    def action_ralph_kill(self) -> None:
        """Delegate 'k' key to the RalphPanel."""
        if self._ralph_active and self._ralph_panel is not None:
            self._ralph_panel.kill_agent()

    def action_ralph_instructions(self) -> None:
        """Open special instructions modal for the current project."""
        if not self._ralph_active or self._ralph_panel is None:
            return
        from mfbt.commands.ralph.ralph_widgets import RalphStage

        if self._ralph_panel.stage not in (RalphStage.OVERVIEW, RalphStage.FEATURE_LIST):
            return

        from mfbt.config import load_special_instructions, save_special_instructions
        from mfbt.tui.screens.instructions_modal import InstructionsModal

        project_id = self._ralph_panel._project_id
        current_text = load_special_instructions(project_id)

        def _on_result(result: str | None) -> None:
            if result is None:
                return  # Cancelled
            save_special_instructions(project_id, result if result else None)
            if self._ralph_panel is not None:
                self._ralph_panel.update_special_instructions(
                    result if result.strip() else None
                )

        self.push_screen(
            InstructionsModal(project_id=project_id, current_text=current_text),
            callback=_on_result,
        )

    def _stop_ralph(self) -> None:
        """Stop ralph orchestrator and restore the previous panel."""
        if self._ralph_panel is not None:
            self._ralph_panel.stop()
            self._ralph_panel = None
        self._ralph_active = False

        try:
            header = self.query_one("#k9s-header", K9sHeader)
            header.ralph_active = False
            header.ralph_project_name = ""
        except Exception:
            pass

        # Restore the panel for the current nav level
        level = self.nav_state.level
        if level == NavigationLevel.PROJECTS:
            self._show_project_list()
        elif level == NavigationLevel.PHASES and self.nav_state.stack:
            proj = self.nav_state.stack[0]
            self._show_phase_list(
                project_id=proj.id,
                project_name=proj.name,
                project_key=proj.key,
                project_metadata=proj.metadata,
            )
        elif level == NavigationLevel.MODULES and len(self.nav_state.stack) >= 2:
            proj = self.nav_state.stack[0]
            phase = self.nav_state.stack[1]
            if phase.metadata.get("_is_virtual"):
                phase_progress = phase.metadata.get("phase_progress", {})
                orphan_modules = phase_progress.get("orphan_modules", [])
                self._show_module_list(
                    project_id=proj.id,
                    project_name=proj.name,
                    project_key=proj.key,
                    project_metadata=proj.metadata,
                    phase_id=phase.id,
                    phase_title=phase.name,
                    orphan_modules=orphan_modules,
                )
            else:
                phase_progress = phase.metadata.get("phase_progress", {})
                phase_modules = phase_progress.get("modules", [])
                self._show_module_list(
                    project_id=proj.id,
                    project_name=proj.name,
                    project_key=proj.key,
                    project_metadata=proj.metadata,
                    phase_id=phase.id,
                    phase_title=phase.name,
                    phase_modules=phase_modules,
                )
        elif level == NavigationLevel.FEATURES and len(self.nav_state.stack) >= 3:
            proj = self.nav_state.stack[0]
            mod = self.nav_state.stack[2]
            self._show_feature_list(
                project_id=proj.id,
                project_name=proj.name,
                project_key=proj.key,
                project_metadata=proj.metadata,
                module_id=mod.id,
                module_name=mod.name,
                module_key=mod.key,
                module_metadata=mod.metadata,
            )
        self._update_nav_display()

    # ---- Auth required modal -------------------------------------------

    def show_auth_required_modal(self) -> None:
        """Push the auth-required modal and handle the result."""
        from mfbt.tui.screens.auth_modal import AuthRequiredModal

        def _on_result(authenticate: bool) -> None:
            if authenticate:
                self._do_interactive_auth()
            else:
                self.exit()

        self.push_screen(AuthRequiredModal(), callback=_on_result)

    def _do_interactive_auth(self) -> None:
        """Run interactive auth in a worker thread."""

        def _auth_worker() -> None:
            from rich.console import Console

            from mfbt.auth_flow import run_interactive_auth

            console = Console()
            success = run_interactive_auth(
                base_url=self.api_client.base_url,
                token_manager=self.api_client.token_manager,
                console=console,
            )
            self.call_from_thread(self._on_auth_complete, success)

        self.run_worker(_auth_worker, thread=True)

    def _on_auth_complete(self, success: bool) -> None:
        """Handle auth completion on the main thread."""
        if success:
            # Restart the token monitor and reload current view
            if self._token_monitor is not None:
                self._token_monitor.stop()
            self._start_token_monitor()
            self.action_refresh()
            self.notify("Re-authenticated successfully", timeout=3)
        else:
            self.notify("Authentication failed or cancelled", severity="error")

    # ---- Token monitor -------------------------------------------------

    def _start_token_monitor(self) -> None:
        """Start the background token refresh monitor."""
        from mfbt.token_manager import BackgroundTokenMonitor

        self._token_monitor = BackgroundTokenMonitor(
            self.api_client.token_manager,
            on_refreshing=lambda: self.call_from_thread(self._on_token_refreshing),
            on_refreshed=lambda: self.call_from_thread(self._on_token_refreshed),
            on_refresh_failed=lambda exc: self.call_from_thread(
                self._on_token_refresh_failed, exc
            ),
        )
        self._token_monitor.start()

    def _on_token_refreshing(self) -> None:
        try:
            status_bar = self.query_one("#status-bar", StatusBar)
            status_bar.refreshing = True
        except Exception:
            pass

    def _on_token_refreshed(self) -> None:
        try:
            status_bar = self.query_one("#status-bar", StatusBar)
            status_bar.refreshing = False
        except Exception:
            pass

    def _on_token_refresh_failed(self, exc: Exception) -> None:
        try:
            status_bar = self.query_one("#status-bar", StatusBar)
            status_bar.refreshing = False
        except Exception:
            pass

        from mfbt.token_manager import (
            RefreshTokenExpiredError,
            RefreshTokenInvalidError,
        )

        if isinstance(exc, RefreshTokenExpiredError):
            self.notify(
                "Refresh token expired. Please run: mfbt auth login",
                severity="error",
            )
        elif isinstance(exc, RefreshTokenInvalidError):
            self.notify(
                "Refresh token invalid. Please run: mfbt auth login",
                severity="error",
            )
        else:
            self.notify(
                "Token refresh failed. Will retry on next API call.",
                severity="warning",
            )

    def _update_transport(self, mode: TransportMode) -> None:
        try:
            status_bar = self.query_one("#status-bar", StatusBar)
            status_bar.transport = mode
        except Exception:
            pass

    # ---- Display updates -----------------------------------------------

    def on_resize(self) -> None:
        if self.size.width < 80:
            self.add_class("narrow")
        else:
            self.remove_class("narrow")

    async def action_quit(self) -> None:
        if self._ralph_active and self._ralph_panel is not None:
            self._ralph_panel.stop()
        if self._token_monitor is not None:
            self._token_monitor.stop()
        await super().action_quit()

    def action_show_help(self) -> None:
        if self._ralph_active and self._ralph_panel is not None:
            from mfbt.commands.ralph.ralph_widgets import RalphHelpScreen

            self.push_screen(RalphHelpScreen(self._ralph_panel.stage))
            return
        from mfbt.tui.screens.help_screen import HelpScreen

        self.push_screen(HelpScreen())

    def _update_nav_display(self) -> None:
        """Update breadcrumb, header, command bar, and status bar from nav state."""
        level_hints = _LEVEL_HINTS.get(
            self.nav_state.level,
            _LEVEL_HINTS[NavigationLevel.PROJECTS],
        )

        # Command bar hints
        try:
            command_bar = self.query_one("#command-bar", CommandBar)
            command_bar.hints = level_hints
        except Exception:
            pass

        # K9s header context
        try:
            header = self.query_one("#k9s-header", K9sHeader)
            header.breadcrumb = self.nav_state.breadcrumb_path_rich
            header.hints = level_hints
            level = self.nav_state.level
            header.context_level = level.value

            if level == NavigationLevel.PROJECTS:
                header.project_name = ""
                header.project_key = ""
            elif level == NavigationLevel.PHASES and self.nav_state.stack:
                item = self.nav_state.stack[0]
                header.project_name = item.name
                header.project_key = item.key
                header.tech_stack = item.metadata.get("tech_stack", "")
                header.status = item.metadata.get("status", "")
            elif level == NavigationLevel.MODULES and len(self.nav_state.stack) >= 2:
                proj = self.nav_state.stack[0]
                phase = self.nav_state.stack[1]
                header.project_name = proj.name
                header.project_key = proj.key
                header.phase_name = phase.name
            elif level == NavigationLevel.FEATURES and len(self.nav_state.stack) >= 3:
                proj = self.nav_state.stack[0]
                mod = self.nav_state.stack[2]
                header.project_name = proj.name
                header.project_key = proj.key
                header.module_name = mod.name
                header.feature_count = mod.metadata.get("feature_count", 0)
                header.completion_pct = mod.metadata.get("completion_pct", 0.0)
        except Exception:
            pass

        # Status bar resource type
        try:
            status_bar = self.query_one("#status-bar", StatusBar)
            level = self.nav_state.level
            if level == NavigationLevel.PROJECTS:
                status_bar.resource_type = "Projects"
            elif level == NavigationLevel.PHASES:
                status_bar.resource_type = "Phases"
            elif level == NavigationLevel.MODULES:
                status_bar.resource_type = "Modules"
            elif level == NavigationLevel.FEATURES:
                status_bar.resource_type = "Features"
        except Exception:
            pass
