"""Auth-required modal for the TUI.

Shown when an API call fails due to expired/invalid tokens.
Offers to re-authenticate via browser or quit.
"""

from __future__ import annotations

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Container, Horizontal
from textual.screen import ModalScreen
from textual.widgets import Button, Label, Static


class AuthRequiredModal(ModalScreen[bool]):
    """Modal prompting the user to re-authenticate or quit."""

    BINDINGS = [
        Binding("escape", "cancel", "Cancel", show=False),
    ]

    def compose(self) -> ComposeResult:
        with Container(id="auth-modal-container"):
            yield Label(
                "[bold #ff5555]Authentication Required[/bold #ff5555]",
                id="auth-modal-title",
            )
            yield Label("")
            yield Static(
                "Your session has expired or your credentials are invalid.\n"
                "Please re-authenticate to continue.",
            )
            yield Label("")
            yield Static(
                "[dim]You can also authenticate from the command line:\n"
                "  mfbt auth login[/dim]",
            )
            yield Label("")
            with Horizontal(id="auth-modal-buttons"):
                yield Button(
                    "Authenticate", id="auth-authenticate", variant="success"
                )
                yield Button("Cancel", id="auth-cancel")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "auth-authenticate":
            self.dismiss(True)
        elif event.button.id == "auth-cancel":
            self.dismiss(False)

    def action_cancel(self) -> None:
        self.dismiss(False)
