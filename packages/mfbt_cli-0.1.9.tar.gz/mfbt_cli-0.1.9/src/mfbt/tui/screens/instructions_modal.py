"""Special instructions modal for Ralph orchestration.

Lets the user enter per-project instructions that are appended to
the coding agent's system prompt during orchestration.
"""

from __future__ import annotations

from typing import Any

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Container, Horizontal
from textual.screen import ModalScreen
from textual.widgets import Button, Label, Static, TextArea


MAX_INSTRUCTIONS_LENGTH = 512


class InstructionsModal(ModalScreen[str | None]):
    """Modal screen for editing special instructions."""

    BINDINGS = [
        Binding("escape", "cancel", "Cancel", show=False),
    ]

    def __init__(
        self,
        project_id: str,
        current_text: str | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self._project_id = project_id
        self._current_text = current_text or ""

    def compose(self) -> ComposeResult:
        with Container(id="instructions-container"):
            yield Label(
                "[bold #326CE5]Special Instructions[/bold #326CE5]",
            )
            yield Label(
                "[dim]These instructions are appended to the coding agent's "
                "system prompt during Ralph orchestration.[/dim]",
            )
            yield Label("")
            yield TextArea(
                self._current_text,
                id="instructions-textarea",
            )
            count = len(self._current_text)
            color = "red" if count > MAX_INSTRUCTIONS_LENGTH else "dim"
            yield Static(
                f"[{color}]{count} / {MAX_INSTRUCTIONS_LENGTH}[/{color}]",
                id="instructions-counter",
            )
            yield Label("")
            with Horizontal(id="instructions-buttons"):
                yield Button(
                    "Save",
                    id="instructions-save",
                    variant="success",
                    disabled=count > MAX_INSTRUCTIONS_LENGTH,
                )
                yield Button("Clear", id="instructions-clear")
                yield Button("Cancel", id="instructions-cancel")

    def on_text_area_changed(self, event: TextArea.Changed) -> None:
        """Update the character counter and Save button state."""
        text = event.text_area.text
        count = len(text)
        over = count > MAX_INSTRUCTIONS_LENGTH
        color = "red" if over else "dim"
        try:
            counter = self.query_one("#instructions-counter", Static)
            counter.update(f"[{color}]{count} / {MAX_INSTRUCTIONS_LENGTH}[/{color}]")
        except Exception:
            pass
        try:
            save_btn = self.query_one("#instructions-save", Button)
            save_btn.disabled = over
        except Exception:
            pass

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "instructions-save":
            try:
                textarea = self.query_one("#instructions-textarea", TextArea)
                text = textarea.text
            except Exception:
                text = ""
            if len(text) <= MAX_INSTRUCTIONS_LENGTH:
                self.dismiss(text)
        elif event.button.id == "instructions-clear":
            self.dismiss("")
        elif event.button.id == "instructions-cancel":
            self.dismiss(None)

    def action_cancel(self) -> None:
        self.dismiss(None)
