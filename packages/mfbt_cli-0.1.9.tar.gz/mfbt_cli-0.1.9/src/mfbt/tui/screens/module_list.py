"""Module list panel for the TUI.

A Widget that mounts inside #main-content, not a pushed Screen.
This keeps the chrome (header, breadcrumb, command bar, status bar) visible.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

from textual.app import ComposeResult
from textual.message import Message
from textual.widget import Widget
from textual.widgets import Label

from mfbt.token_manager import TokenError
from mfbt.tui.widgets.resource_table import ResourceTable

if TYPE_CHECKING:
    from mfbt.tui.data_provider import TUIDataProvider

logger = logging.getLogger("mfbt.tui.screens.module_list")

_COLUMNS: list[tuple[str, str]] = [
    ("key", "KEY"),
    ("name", "NAME"),
    ("features", "FEATURES"),
    ("type", "TYPE"),
    ("provenance", "PROVENANCE"),
    ("source_phase", "SOURCE PHASE"),
]

_PHASE_COLUMNS: list[tuple[str, str]] = [
    ("key", "KEY"),
    ("name", "NAME"),
    ("features", "FEATURES"),
    ("done", "DONE"),
    ("pending", "PENDING"),
    ("progress", "PROGRESS"),
]


def _format_module_row(data: dict[str, Any]) -> tuple[str, ...]:
    """Format a module dict into table cells."""
    key = data.get("module_key", data.get("key", ""))
    name = data.get("title", data.get("name", "Unnamed"))
    feature_count = data.get("feature_count", "")
    mod_type = data.get("type", "")
    provenance = data.get("provenance", "")
    source_phase = data.get("source_phase_title", data.get("source_phase", ""))
    return (
        f"[dim]{key}[/dim]",
        f"[bold]{name}[/bold]",
        str(feature_count) if feature_count else "[dim]-[/dim]",
        str(mod_type) if mod_type else "[dim]-[/dim]",
        str(provenance) if provenance else "[dim]-[/dim]",
        str(source_phase) if source_phase else "[dim]-[/dim]",
    )


def _format_phase_module_row(data: dict[str, Any]) -> tuple[str, ...]:
    """Format a phase-progress module dict into table cells."""
    key = data.get("module_key", "")
    name = data.get("title", "Unnamed")
    total = data.get("total_features", 0)
    done = data.get("completed_features", 0)
    pending = data.get("pending_features", 0)
    pct = data.get("progress_percent", 0.0)
    return (
        f"[dim]{key}[/dim]",
        f"[bold]{name}[/bold]",
        str(total) if total else "[dim]0[/dim]",
        f"[green]{done}[/green]" if done else "[dim]0[/dim]",
        f"[dim]{pending}[/dim]",
        f"{pct:.0f}%",
    )


class ModuleListPanel(Widget):
    """Content panel showing modules for a selected project."""

    class ModuleSelected(Message):
        """Fired when a module is selected."""

        def __init__(
            self,
            data: dict[str, Any],
            project_id: str,
            project_name: str,
            project_key: str,
            project_metadata: dict[str, Any],
        ) -> None:
            super().__init__()
            self.data = data
            self.project_id = project_id
            self.project_name = project_name
            self.project_key = project_key
            self.project_metadata = project_metadata

    class DescribeRequested(Message):
        """Fired when describe is requested on a module."""

        def __init__(self, data: dict[str, Any]) -> None:
            super().__init__()
            self.data = data

    def __init__(
        self,
        data_provider: TUIDataProvider,
        project_id: str,
        project_name: str,
        project_key: str = "",
        project_metadata: dict[str, Any] | None = None,
        phase_id: str = "",
        phase_title: str = "",
        phase_modules: list[dict[str, Any]] | None = None,
        orphan_modules: list[dict[str, Any]] | None = None,
    ) -> None:
        super().__init__()
        self._data_provider = data_provider
        self.project_id = project_id
        self.project_name = project_name
        self.project_key = project_key
        self.project_metadata = project_metadata or {}
        self.phase_id = phase_id
        self.phase_title = phase_title
        self._phase_modules = phase_modules
        self._orphan_modules = orphan_modules

    def compose(self) -> ComposeResult:
        subtitle = self.phase_title or self.project_name
        yield Label(
            f" [bold #326CE5]Modules[/bold #326CE5] [dim]\u2014 {subtitle}[/dim]",
            id="screen-title",
        )
        yield ResourceTable(id="resource-table")

    def on_mount(self) -> None:
        self._load_data()
        self.query_one("#resource-table", ResourceTable).focus()

    def _load_data(self) -> None:
        if self._orphan_modules is not None:
            self._display_orphan_modules()
        elif self._phase_modules is not None:
            self._display_phase_modules()
        else:
            self.run_worker(self._fetch_and_display, thread=True)

    def _display_orphan_modules(self) -> None:
        """Display orphan modules (no associated phase) using standard columns."""
        table = self.query_one("#resource-table", ResourceTable)
        modules = self._orphan_modules or []
        table.set_rows(modules, _COLUMNS, _format_module_row)
        self._update_status_count_sync(len(modules))

    def _display_phase_modules(self) -> None:
        """Display modules from phase progress data (already available)."""
        table = self.query_one("#resource-table", ResourceTable)
        modules = self._phase_modules or []
        table.set_rows(modules, _PHASE_COLUMNS, _format_phase_module_row)
        self._update_status_count_sync(len(modules))

    def _update_status_count_sync(self, count: int) -> None:
        try:
            from mfbt.tui.widgets.status_bar import StatusBar

            status_bar = self.app.query_one("#status-bar", StatusBar)
            status_bar.resource_count = count
        except Exception:
            pass

    def _fetch_and_display(self) -> None:
        try:
            page = self._data_provider.fetch_modules(self.project_id)
            table = self.query_one("#resource-table", ResourceTable)
            self.app.call_from_thread(
                table.set_rows, page.items, _COLUMNS, _format_module_row
            )
            self.app.call_from_thread(setattr, table, "has_more", page.has_more)
            self._update_status_count(page.total)
        except TokenError:
            logger.warning("Authentication required while fetching modules")
            self.app.call_from_thread(self.app.show_auth_required_modal)
        except Exception as exc:
            logger.exception("Failed to fetch modules")
            self.app.call_from_thread(
                self.app.notify,
                f"Failed to load modules: {exc}",
                severity="error",
            )

    def _update_status_count(self, count: int) -> None:
        try:
            from mfbt.tui.widgets.status_bar import StatusBar

            status_bar = self.app.query_one("#status-bar", StatusBar)
            self.app.call_from_thread(setattr, status_bar, "resource_count", count)
        except Exception:
            pass

    def on_resource_table_resource_selected(
        self, event: ResourceTable.ResourceSelected
    ) -> None:
        self.post_message(
            self.ModuleSelected(
                data=event.data,
                project_id=self.project_id,
                project_name=self.project_name,
                project_key=self.project_key,
                project_metadata=self.project_metadata,
            )
        )

    def refresh_data(self) -> None:
        """Reload data from the API."""
        if self._orphan_modules is not None:
            # Re-fetch all modules and filter to orphans only
            self.run_worker(self._refresh_orphan_modules, thread=True)
        else:
            self._phase_modules = None  # Force API fetch on refresh
            self.run_worker(self._fetch_and_display, thread=True)

    def _refresh_orphan_modules(self) -> None:
        """Re-fetch modules and display only orphans."""
        try:
            page = self._data_provider.fetch_modules(self.project_id)
            orphans = [
                m for m in page.items
                if not m.get("brainstorming_phase_id")
            ]
            self._orphan_modules = orphans
            table = self.query_one("#resource-table", ResourceTable)
            self.app.call_from_thread(
                table.set_rows, orphans, _COLUMNS, _format_module_row
            )
            self._update_status_count(len(orphans))
        except Exception as exc:
            logger.exception("Failed to refresh orphan modules")
            self.app.call_from_thread(
                self.app.notify,
                f"Failed to refresh modules: {exc}",
                severity="error",
            )

    def get_selected_data(self) -> dict[str, Any] | None:
        """Return the data for the currently highlighted row."""
        try:
            table = self.query_one("#resource-table", ResourceTable)
            return table.get_selected_data()
        except Exception:
            return None
