"""Phase list panel for the TUI.

A Widget that mounts inside #main-content, not a pushed Screen.
This keeps the chrome (header, breadcrumb, command bar, status bar) visible.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

from textual.app import ComposeResult
from textual.message import Message
from textual.widget import Widget
from textual.widgets import Label

from mfbt.token_manager import TokenError
from mfbt.tui.widgets.resource_table import ResourceTable

if TYPE_CHECKING:
    from mfbt.tui.data_provider import TUIDataProvider

logger = logging.getLogger("mfbt.tui.screens.phase_list")

_VIRTUAL_ORPHAN_PHASE_ID = "__orphan_modules__"

_COLUMNS: list[tuple[str, str]] = [
    ("title", "PHASE"),
    ("features", "FEATURES"),
    ("done", "DONE"),
    ("pending", "PENDING"),
    ("progress", "PROGRESS"),
    ("status", "STATUS"),
]


def _format_phase_row(data: dict[str, Any]) -> tuple[str, ...]:
    """Format a phase dict into table cells."""
    if data.get("_is_virtual"):
        title = data.get("title", "")
        total = data.get("_total_features", 0)
        return (
            f"[italic dim]{title}[/italic dim]",
            str(total) if total else "[dim]0[/dim]",
            "[dim]-[/dim]",
            "[dim]-[/dim]",
            "[dim]-[/dim]",
            "[dim italic]virtual[/dim italic]",
        )

    title = data.get("title", "Unnamed")
    total = data.get("_total_features", 0)
    done = data.get("_completed_features", 0)
    pending = data.get("_pending_features", 0)
    pct = data.get("_progress_percent", 0.0)

    if pct >= 100:
        status_str = "[green]\u2713 complete[/green]"
    elif done > 0:
        status_str = "[yellow]\u25b6 in progress[/yellow]"
    else:
        status_str = "[dim]\u00b7 pending[/dim]"

    return (
        f"[bold]{title}[/bold]",
        str(total) if total else "[dim]0[/dim]",
        f"[green]{done}[/green]" if done else "[dim]0[/dim]",
        f"[dim]{pending}[/dim]",
        f"{pct:.0f}%",
        status_str,
    )


class PhaseListPanel(Widget):
    """Content panel showing brainstorming phases for a selected project."""

    class PhaseSelected(Message):
        """Fired when a phase is selected."""

        def __init__(
            self,
            data: dict[str, Any],
            project_id: str,
            project_name: str,
            project_key: str,
            project_metadata: dict[str, Any],
            phase_progress: dict[str, Any],
        ) -> None:
            super().__init__()
            self.data = data
            self.project_id = project_id
            self.project_name = project_name
            self.project_key = project_key
            self.project_metadata = project_metadata
            self.phase_progress = phase_progress

    class DescribeRequested(Message):
        """Fired when describe is requested on a phase."""

        def __init__(self, data: dict[str, Any]) -> None:
            super().__init__()
            self.data = data

    def __init__(
        self,
        data_provider: TUIDataProvider,
        project_id: str,
        project_name: str,
        project_key: str = "",
        project_metadata: dict[str, Any] | None = None,
    ) -> None:
        super().__init__()
        self._data_provider = data_provider
        self.project_id = project_id
        self.project_name = project_name
        self.project_key = project_key
        self.project_metadata = project_metadata or {}
        self._phase_progress_cache: dict[str, dict[str, Any]] = {}
        self._orphan_modules: list[dict[str, Any]] = []

    def compose(self) -> ComposeResult:
        yield Label(
            f" [bold #326CE5]Phases[/bold #326CE5] [dim]\u2014 {self.project_name}[/dim]",
            id="screen-title",
        )
        yield ResourceTable(id="resource-table")

    def on_mount(self) -> None:
        self._load_data()
        self.query_one("#resource-table", ResourceTable).focus()

    def _load_data(self) -> None:
        self.run_worker(self._fetch_and_display, thread=True)

    def _fetch_and_display(self) -> None:
        try:
            phases = self._data_provider.fetch_brainstorming_phases(self.project_id)
            # Filter out archived phases
            phases = [p for p in phases if not p.get("archived_at")]

            # Enrich each phase with progress data
            for phase in phases:
                phase_id = phase.get("id", "")
                if phase_id:
                    progress = self._data_provider.fetch_phase_progress(phase_id)
                    self._phase_progress_cache[phase_id] = progress
                    phase["_total_features"] = progress.get("total_features", 0)
                    phase["_completed_features"] = progress.get("completed_features", 0)
                    phase["_pending_features"] = progress.get("pending_features", 0)
                    phase["_progress_percent"] = progress.get("progress_percent", 0.0)

            # Fetch all modules to find orphans (no brainstorming_phase_id)
            all_modules_page = self._data_provider.fetch_modules(self.project_id)
            orphans = [
                m for m in all_modules_page.items
                if not m.get("brainstorming_phase_id")
            ]
            self._orphan_modules = orphans

            if orphans:
                total_features = sum(
                    m.get("feature_count", 0) for m in orphans
                )
                virtual_phase = {
                    "id": _VIRTUAL_ORPHAN_PHASE_ID,
                    "title": "Modules without associated Phases",
                    "_is_virtual": True,
                    "_total_features": total_features,
                }
                phases.append(virtual_phase)

            table = self.query_one("#resource-table", ResourceTable)
            self.app.call_from_thread(
                table.set_rows, phases, _COLUMNS, _format_phase_row
            )
            self._update_status_count(len(phases))
        except TokenError:
            logger.warning("Authentication required while fetching phases")
            self.app.call_from_thread(self.app.show_auth_required_modal)
        except Exception as exc:
            logger.exception("Failed to fetch phases")
            self.app.call_from_thread(
                self.app.notify,
                f"Failed to load phases: {exc}",
                severity="error",
            )

    def _update_status_count(self, count: int) -> None:
        try:
            from mfbt.tui.widgets.status_bar import StatusBar

            status_bar = self.app.query_one("#status-bar", StatusBar)
            self.app.call_from_thread(setattr, status_bar, "resource_count", count)
        except Exception:
            pass

    def on_resource_table_resource_selected(
        self, event: ResourceTable.ResourceSelected
    ) -> None:
        phase_id = event.data.get("id", "")

        if phase_id == _VIRTUAL_ORPHAN_PHASE_ID:
            # Virtual orphan entry — pass orphan modules instead of phase progress
            self.post_message(
                self.PhaseSelected(
                    data=event.data,
                    project_id=self.project_id,
                    project_name=self.project_name,
                    project_key=self.project_key,
                    project_metadata=self.project_metadata,
                    phase_progress={
                        "_is_virtual": True,
                        "orphan_modules": self._orphan_modules,
                    },
                )
            )
            return

        progress = self._phase_progress_cache.get(phase_id, {})
        self.post_message(
            self.PhaseSelected(
                data=event.data,
                project_id=self.project_id,
                project_name=self.project_name,
                project_key=self.project_key,
                project_metadata=self.project_metadata,
                phase_progress=progress,
            )
        )

    def refresh_data(self) -> None:
        """Reload data from the API."""
        self._load_data()

    def get_selected_data(self) -> dict[str, Any] | None:
        """Return the data for the currently highlighted row."""
        try:
            table = self.query_one("#resource-table", ResourceTable)
            return table.get_selected_data()
        except Exception:
            return None
