"""Project list panel for the TUI.

A Widget that mounts inside #main-content, not a pushed Screen.
This keeps the chrome (header, breadcrumb, command bar, status bar) visible.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

from textual.app import ComposeResult
from textual.message import Message
from textual.widget import Widget
from textual.widgets import Label

from mfbt.token_manager import TokenError
from mfbt.tui.colors import status_color
from mfbt.tui.widgets.resource_table import ResourceTable

if TYPE_CHECKING:
    from mfbt.tui.data_provider import TUIDataProvider

logger = logging.getLogger("mfbt.tui.screens.project_list")

_COLUMNS: list[tuple[str, str]] = [
    ("key", "KEY"),
    ("name", "NAME"),
    ("status", "STATUS"),
    ("type", "TYPE"),
    ("tech_stack", "TECH STACK"),
    ("features", "FEATURES"),
]


def _format_project_row(data: dict[str, Any]) -> tuple[str, ...]:
    """Format a project dict into table cells."""
    key = data.get("key", data.get("short_url_id", ""))
    name = data.get("name", "Unnamed")
    status = data.get("status", "")
    proj_type = data.get("project_type", data.get("type", ""))
    tech_stack = data.get("tech_stack", "")
    if isinstance(tech_stack, list):
        tech_stack = ", ".join(tech_stack[:3])
    feature_count = data.get("feature_count", "")
    return (
        f"[dim]{key}[/dim]",
        f"[bold]{name}[/bold]",
        status_color(status) if status else "[dim]-[/dim]",
        str(proj_type) if proj_type else "[dim]-[/dim]",
        str(tech_stack) if tech_stack else "[dim]-[/dim]",
        str(feature_count) if feature_count else "[dim]-[/dim]",
    )


class ProjectListPanel(Widget):
    """Content panel showing the list of accessible projects."""

    class ProjectSelected(Message):
        """Fired when a project is selected."""

        def __init__(self, data: dict[str, Any]) -> None:
            super().__init__()
            self.data = data

    class DescribeRequested(Message):
        """Fired when describe is requested on a project."""

        def __init__(self, data: dict[str, Any]) -> None:
            super().__init__()
            self.data = data

    def __init__(self, data_provider: TUIDataProvider) -> None:
        super().__init__()
        self._data_provider = data_provider

    def compose(self) -> ComposeResult:
        yield Label(" [bold #326CE5]Projects[/bold #326CE5]", id="screen-title")
        yield ResourceTable(id="resource-table")

    def on_mount(self) -> None:
        self._load_data()
        self.query_one("#resource-table", ResourceTable).focus()

    def _load_data(self) -> None:
        self.run_worker(self._fetch_and_display, thread=True)

    def _fetch_and_display(self) -> None:
        try:
            page = self._data_provider.fetch_projects()
            table = self.query_one("#resource-table", ResourceTable)
            self.app.call_from_thread(
                table.set_rows, page.items, _COLUMNS, _format_project_row
            )
            self.app.call_from_thread(setattr, table, "has_more", page.has_more)
            self._update_status_count(page.total)
        except TokenError:
            logger.warning("Authentication required while fetching projects")
            self.app.call_from_thread(self.app.show_auth_required_modal)
        except Exception as exc:
            logger.exception("Failed to fetch projects")
            self.app.call_from_thread(
                self.app.notify,
                f"Failed to load projects: {exc}",
                severity="error",
            )

    def _update_status_count(self, count: int) -> None:
        try:
            from mfbt.tui.widgets.status_bar import StatusBar

            status_bar = self.app.query_one("#status-bar", StatusBar)
            self.app.call_from_thread(setattr, status_bar, "resource_count", count)
        except Exception:
            pass

    def on_resource_table_resource_selected(
        self, event: ResourceTable.ResourceSelected
    ) -> None:
        self.post_message(self.ProjectSelected(event.data))

    def refresh_data(self) -> None:
        """Reload data from the API."""
        self._load_data()

    def get_selected_data(self) -> dict[str, Any] | None:
        """Return the data for the currently highlighted row."""
        try:
            table = self.query_one("#resource-table", ResourceTable)
            return table.get_selected_data()
        except Exception:
            return None
