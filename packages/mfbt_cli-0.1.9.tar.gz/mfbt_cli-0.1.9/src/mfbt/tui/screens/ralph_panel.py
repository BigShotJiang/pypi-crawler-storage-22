"""Ralph orchestration panel for the main TUI.

A Widget that mounts inside #main-content, containing all Ralph sub-widgets.
Manages the confirmation → running lifecycle within the main TUI chrome.
"""

from __future__ import annotations

import time
from pathlib import Path
from typing import TYPE_CHECKING, Any

from rich.text import Text
from textual.app import ComposeResult
from textual.widget import Widget
from textual.widgets import DataTable, Static

if TYPE_CHECKING:
    from mfbt.api_client import APIClient

from mfbt.commands.ralph.ralph_widgets import (
    AgentOutputLog,
    FeatureProgressTable,
    LogPaneHeader,
    LogViewerModal,
    RalphHeader,
    RalphStage,
    RalphStatusBar,
    StatusSummary,
    _GLISTEN_COLORS,
)


class RalphPanel(Widget):
    """Embedded Ralph orchestration view for the main TUI.

    Lifecycle:
    1. LOADING: resolves phases, fetches progress in a worker thread
    2. OVERVIEW: shows StatusSummary widget with module progress table
    3. FEATURE_LIST: shows unified FeatureProgressTable with all features
    4. RUNNING: hides pre-confirmation widgets, shows orchestration widgets
    """

    def __init__(
        self,
        api_client: APIClient,
        project_id: str,
        mfbt_dir: Path,
        config: dict[str, Any],
        phase_id: str | None = None,
    ) -> None:
        super().__init__()
        self._api_client = api_client
        self._project_id = project_id
        self._mfbt_dir = mfbt_dir
        self._config = config
        self._phase_id = phase_id
        self._orchestrator: Any = None
        self._orchestrator_client: APIClient | None = None
        self._ralph_config: Any = None
        self._phases_progress: dict[str, dict] = {}
        self._orphan_modules: list[dict[str, Any]] = []
        self._pending_features: list[dict[str, Any]] = []
        self._stage: RalphStage = RalphStage.LOADING
        self._session_start: float = 0.0
        self._paused_accumulated: float = 0.0
        self._pause_start: float = 0.0
        self._feature_start: float = 0.0
        self._feature_pause_snapshot: float = 0.0
        self._session_stopped: bool = False
        self.session_log_dir: Path | None = None
        self._running_feature_key: str | None = None
        self._glisten_frame: int = 0
        self._special_instructions: str | None = None

    @property
    def stage(self) -> RalphStage:
        return self._stage

    def _instructions_hint_label(self) -> str:
        """Return the hint label for the instructions key."""
        return "[green]\u2713[/green] Instr" if self._special_instructions else "Instr"

    def update_special_instructions(self, text: str | None) -> None:
        """Update cached instructions (called from app callback)."""
        self._special_instructions = text
        if self._ralph_config is not None:
            from dataclasses import replace

            self._ralph_config = replace(
                self._ralph_config, special_instructions=text
            )
        # Refresh hints to show/hide checkmark
        if self._stage == RalphStage.OVERVIEW:
            self._update_hints(
                ("c", "Continue"), ("i", self._instructions_hint_label()),
                ("esc", "Back"), ("?", "Help"), ("q", "Quit"),
            )
        elif self._stage == RalphStage.FEATURE_LIST:
            self._update_hints(
                ("r", "Run"), ("i", self._instructions_hint_label()),
                ("enter", "Detail"), ("esc", "Back"), ("?", "Help"), ("q", "Quit"),
            )

    def compose(self) -> ComposeResult:
        yield Static("[dim]Loading phase data...[/dim]", id="ralph-loading")

    def on_mount(self) -> None:
        self.run_worker(self._resolve_and_show_status, thread=True)

    def _resolve_and_show_status(self) -> None:
        """Resolve phases and fetch progress, then show the status summary."""
        from mfbt.commands.ralph.progress import (
            build_global_feature_list,
            get_module_progress,
            get_phase_progress,
            resolve_phases,
        )
        from mfbt.commands.ralph.types import AgentType, OrchestrationMode, RalphConfig
        from mfbt.config import load_special_instructions

        try:
            self._special_instructions = load_special_instructions(self._project_id)

            phases = resolve_phases(
                self._api_client, self._project_id, self._phase_id
            )

            self._phases_progress = {
                p.phase_id: get_phase_progress(self._api_client, p.phase_id)
                for p in phases
            }

            # Fetch orphan modules (modules not associated with any phase)
            try:
                resp = self._api_client.get(
                    f"/api/v1/projects/{self._project_id}/modules"
                )
                all_modules = resp.body if isinstance(resp.body, list) else []
                # If paginated response
                if isinstance(resp.body, dict) and "items" in resp.body:
                    all_modules = resp.body["items"]

                # Collect all module IDs from phase progress
                phase_module_ids: set[str] = set()
                for progress in self._phases_progress.values():
                    for m in progress.get("modules", []):
                        mid = m.get("module_id", "")
                        if mid:
                            phase_module_ids.add(mid)

                orphans = [
                    m for m in all_modules
                    if not m.get("brainstorming_phase_id")
                    and m.get("id", "") not in phase_module_ids
                ]

                # Fetch progress for each orphan module
                orphan_progress: list[dict[str, Any]] = []
                for m in orphans:
                    mid = m.get("id", "")
                    if mid:
                        prog = get_module_progress(self._api_client, mid)
                        orphan_row = {
                            "module_id": mid,
                            "module_key": m.get("module_key", m.get("key", "")),
                            "title": m.get("title", ""),
                            "completed_features": prog.get("completed_features", 0),
                            "in_progress_features": prog.get("in_progress_features", 0),
                            "pending_features": prog.get("pending_features", 0),
                            "total_features": prog.get("total_features", 0),
                            "progress_percent": prog.get("progress_percent", 0.0),
                        }
                        orphan_progress.append(orphan_row)
                self._orphan_modules = orphan_progress
            except Exception:
                self._orphan_modules = []

            # Build global feature list using shared function
            all_features = build_global_feature_list(
                self._api_client, self._project_id, list(phases), self._phases_progress
            )
            self._pending_features = all_features

            base_url = self._config.get("base_url", "https://app.mfbt.ai")
            self._ralph_config = RalphConfig(
                project_id=self._project_id,
                phases=tuple(phases),
                coding_agent=AgentType.CLAUDE,
                mode=OrchestrationMode.FEATURE_BY_FEATURE,
                max_turns=None,
                quiet=False,
                base_url=base_url,
                special_instructions=self._special_instructions,
            )

            multi_phase = len(phases) > 1

            def _show() -> None:
                try:
                    loading = self.query_one("#ralph-loading")
                    loading.remove()
                except Exception:
                    pass

                # Count actionable features for the title
                actionable = sum(
                    1 for f in self._pending_features
                    if f.get("completion_status", "pending") != "completed"
                    and f.get("has_spec", False)
                    and f.get("has_prompt_plan", False)
                )
                total = len(self._pending_features)

                self.mount(
                    StatusSummary(
                        self._ralph_config,
                        self._phases_progress,
                        orphan_modules=self._orphan_modules,
                        all_features=self._pending_features,
                        id="status-summary",
                    )
                )
                self.mount(Static(
                    f" [bold #326CE5]Features[/bold #326CE5]"
                    f" [dim]\u2014 {total} total, {actionable} to implement[/dim]",
                    id="feature-list-title",
                    classes="-hidden",
                ))
                self.mount(Static(
                    "  [dim]SPN = [bold]S[/bold]pec / [bold]P[/bold]rompt plan / [bold]N[/bold]otes"
                    " \u2014 features without spec and prompt plan will be skipped[/dim]",
                    id="feature-list-legend",
                    classes="-hidden",
                ))
                self.mount(RalphHeader(id="ralph-header", classes="-hidden"))
                table = FeatureProgressTable(id="feature-table", classes="-hidden")
                self.mount(table)
                table.populate_all(self._pending_features, multi_phase=multi_phase)
                self.mount(LogPaneHeader(id="log-pane-header", classes="-hidden"))
                self.mount(AgentOutputLog(id="agent-output", classes="-hidden"))
                self.mount(RalphStatusBar(id="ralph-status-bar", classes="-hidden"))
                self._stage = RalphStage.OVERVIEW
                self._update_hints(
                    ("c", "Continue"), ("i", self._instructions_hint_label()),
                    ("esc", "Back"), ("?", "Help"), ("q", "Quit"),
                )

            self.app.call_from_thread(_show)

        except Exception as exc:
            def _show_error() -> None:
                try:
                    loading = self.query_one("#ralph-loading")
                    loading.update(
                        f"[red]Failed to load Ralph data: {exc}[/red]\n"
                        "[dim]Press esc to go back[/dim]"
                    )
                except Exception:
                    pass

            self.app.call_from_thread(_show_error)

    def confirm_and_start(self) -> None:
        """Handle 'c' key — two-step flow: OVERVIEW → FEATURE_LIST → RUNNING."""
        if self._ralph_config is None:
            return

        if self._stage == RalphStage.OVERVIEW:
            # Step 1: show feature list (all features, scrolled to first pending)
            self._stage = RalphStage.FEATURE_LIST
            try:
                self.query_one("#status-summary").add_class("-hidden")
            except Exception:
                pass
            for widget_id in ("#feature-list-title", "#feature-list-legend", "#feature-table"):
                try:
                    self.query_one(widget_id).remove_class("-hidden")
                except Exception:
                    pass
            try:
                table = self.query_one("#feature-table", FeatureProgressTable)
                table.focus()
                table.scroll_to_pending()
            except Exception:
                pass
            # Update hints to show "Run" instead of "Continue"
            self._update_hints(
                ("r", "Run"), ("i", self._instructions_hint_label()),
                ("enter", "Detail"), ("esc", "Back"), ("?", "Help"), ("q", "Quit"),
            )
            return

        if self._stage == RalphStage.FEATURE_LIST:
            # Check if there are any actionable features to implement
            actionable = sum(
                1 for f in self._pending_features
                if f.get("completion_status", "pending") != "completed"
                and f.get("has_spec", False)
                and f.get("has_prompt_plan", False)
            )
            if actionable == 0:
                self.app.notify(
                    "All features have already been implemented.",
                    severity="information",
                    timeout=5,
                )
                return

            # Step 2: show preflight modal before starting
            from mfbt.tui.screens.preflight_modal import PreflightModal

            project_dir = Path.cwd()
            self.app.push_screen(
                PreflightModal(project_dir=project_dir),
                callback=self._on_preflight_complete,
            )
            return

        if self._stage == RalphStage.PAUSED:
            # Retry selected feature after stop/completion
            self.retry_feature()
            return

    def go_back(self) -> bool:
        """Handle back navigation within ralph stages.

        Returns True if we handled the back (stayed within ralph),
        False if the app should exit ralph entirely.
        """
        if self._stage == RalphStage.FEATURE_LIST:
            # Go back to overview
            self._stage = RalphStage.OVERVIEW
            for widget_id in ("#feature-list-title", "#feature-list-legend", "#feature-table"):
                try:
                    self.query_one(widget_id).add_class("-hidden")
                except Exception:
                    pass
            try:
                self.query_one("#status-summary").remove_class("-hidden")
            except Exception:
                pass
            try:
                from mfbt.tui.widgets.resource_table import ResourceTable
                self.query_one("#ralph-summary-table", ResourceTable).focus()
            except Exception:
                pass
            # Restore "Continue" hints
            self._update_hints(
                ("c", "Continue"), ("i", self._instructions_hint_label()),
                ("esc", "Back"), ("?", "Help"), ("q", "Quit"),
            )
            return True
        if self._stage in (RalphStage.RUNNING, RalphStage.PAUSED):
            # Swallow ESC during running/paused — use 'p' to pause or 'q' to quit
            return True
        return False

    def _on_preflight_complete(self, agent_type: Any) -> None:
        """Handle result from the preflight modal."""
        if agent_type is None:
            return  # User cancelled

        from dataclasses import replace

        from mfbt.commands.ralph.types import AgentType

        # Update ralph config with the selected agent
        if isinstance(agent_type, AgentType) and self._ralph_config is not None:
            self._ralph_config = replace(self._ralph_config, coding_agent=agent_type)

        self._start_running()

    def _start_running(self) -> None:
        """Transition from FEATURE_LIST to RUNNING stage."""
        self._stage = RalphStage.RUNNING

        # Hide title/legend (table stays visible from FEATURE_LIST stage)
        for widget_id in ("#feature-list-title", "#feature-list-legend"):
            try:
                self.query_one(widget_id).add_class("-hidden")
            except Exception:
                pass

        # Show running-stage widgets (feature-table is already visible)
        for widget_id in (
            "#ralph-header",
            "#feature-table",
            "#log-pane-header",
            "#agent-output",
            "#ralph-status-bar",
        ):
            try:
                self.query_one(widget_id).remove_class("-hidden")
            except Exception:
                pass

        self._session_start = time.monotonic()
        self._paused_accumulated = 0.0
        self._pause_start = 0.0
        self._feature_start = 0.0
        self._feature_pause_snapshot = 0.0
        self._session_stopped = False
        self.set_interval(1.0, self._tick_elapsed)
        self.set_interval(0.2, self._glisten_tick)
        self._update_hints(("p", "Pause"), ("enter", "Detail"), ("l", "Logs"), ("k", "Kill"), ("?", "Help"), ("q", "Quit"))
        self.run_worker(self._run_orchestrator, thread=True)

    def _update_hints(self, *hints: tuple[str, str]) -> None:
        """Update command bar and header hints."""
        from mfbt.tui.widgets.command_bar import CommandBar
        from mfbt.tui.widgets.k9s_header import K9sHeader

        try:
            command_bar = self.app.query_one("#command-bar", CommandBar)
            command_bar.hints = hints
        except Exception:
            pass
        try:
            header = self.app.query_one("#k9s-header", K9sHeader)
            header.hints = hints
        except Exception:
            pass

    def stop(self) -> None:
        """Stop the orchestrator if running."""
        if self._orchestrator is not None:
            try:
                self._orchestrator.stop()
            except Exception:
                pass
        if self._orchestrator_client is not None:
            try:
                self._orchestrator_client.close()
            except Exception:
                pass
            self._orchestrator_client = None

    def pause_orchestrator(self) -> None:
        """Show pause modal — lets user continue or stop the orchestration loop."""
        if self._stage != RalphStage.RUNNING:
            return

        from mfbt.commands.ralph.ralph_widgets import PauseModal

        self._stage = RalphStage.PAUSED
        self._pause_start = time.monotonic()

        def _on_pause_result(result: str | None) -> None:
            if result == "stop":
                # Signal orchestrator to stop after current feature
                if self._orchestrator is not None:
                    self._orchestrator.stop()
                # Accumulate pause time so far (timer stays frozen)
                if self._pause_start > 0:
                    self._paused_accumulated += time.monotonic() - self._pause_start
                    self._pause_start = 0.0
                self._update_hints(("r", "Retry"), ("enter", "Detail"), ("l", "Logs"), ("?", "Help"), ("q", "Quit"))
                try:
                    log = self.query_one("#agent-output", AgentOutputLog)
                    log.write(
                        Text.from_markup(
                            "[yellow]Paused — will stop after current feature. "
                            "Press [bold]r[/bold] to restart.[/yellow]"
                        )
                    )
                except Exception:
                    pass
                # Stay in PAUSED — user can press 'r' to restart
            else:
                # Continue running — accumulate pause duration
                if self._pause_start > 0:
                    self._paused_accumulated += time.monotonic() - self._pause_start
                    self._pause_start = 0.0
                self._stage = RalphStage.RUNNING
                self._update_hints(("p", "Pause"), ("enter", "Detail"), ("l", "Logs"), ("k", "Kill"), ("?", "Help"), ("q", "Quit"))

        self.app.push_screen(PauseModal(), callback=_on_pause_result)

    def kill_agent(self) -> None:
        """Kill the currently running coding agent subprocess immediately."""
        if self._stage not in (RalphStage.RUNNING, RalphStage.PAUSED):
            return
        if self._orchestrator is None:
            return
        try:
            self._orchestrator._agent.terminate()
        except Exception:
            pass
        try:
            log = self.query_one("#agent-output", AgentOutputLog)
            log.write(
                Text.from_markup("[red bold]Agent killed by user[/red bold]")
            )
        except Exception:
            pass
        self.app.notify("Agent process killed", severity="warning")

    def retry_feature(self) -> None:
        """Retry implementation for the currently selected feature."""
        if self._stage != RalphStage.PAUSED:
            return
        if self._orchestrator is None:
            return

        # Get selected feature key from table
        try:
            table = self.query_one("#feature-table", FeatureProgressTable)
            row_key = table.coordinate_to_cell_key(table.cursor_coordinate).row_key
            feature_key = str(row_key.value)
        except Exception:
            return

        if not feature_key:
            return

        # Find feature data in pending list
        feature_info = None
        for f in self._pending_features:
            if f.get("feature_key") == feature_key:
                feature_info = f
                break

        if feature_info is None:
            self.app.notify("Feature not found", severity="warning")
            return

        # Undo status bar counts from previous result for this feature
        from mfbt.commands.ralph.types import FeatureOutcome

        try:
            status_bar = self.query_one("#ralph-status-bar", RalphStatusBar)
            prev_results = [
                r for r in self._orchestrator._results
                if r.feature.feature_key == feature_key
            ]
            if prev_results:
                last = prev_results[-1]
                if last.outcome == FeatureOutcome.SUCCESS:
                    status_bar.succeeded = max(0, status_bar.succeeded - 1)
                elif last.outcome == FeatureOutcome.FAILED:
                    status_bar.failed = max(0, status_bar.failed - 1)
                status_bar.pending += 1
        except Exception:
            pass

        # Reset the feature row in the table
        table.update_feature(
            feature_key,
            status="[dim]pending[/dim]",
            time_str="-",
            attempts=0,
        )

        # Transition to RUNNING for the duration of the retry
        self._stage = RalphStage.RUNNING
        self._update_hints(
            ("p", "Pause"), ("enter", "Detail"), ("l", "Logs"),
            ("k", "Kill"), ("?", "Help"), ("q", "Quit"),
        )

        self.run_worker(
            lambda: self._run_single_retry(feature_info, feature_key),
            thread=True,
        )

    def _run_single_retry(
        self, feature_info: dict, feature_key: str
    ) -> None:
        """Retry a single feature implementation in a worker thread."""
        from mfbt.commands.ralph.progress import resolve_feature_task
        from mfbt.commands.ralph.types import FeatureOutcome

        feature = resolve_feature_task(self._orchestrator_client, feature_info)
        if feature is None:
            def _notify_error() -> None:
                self.app.notify(
                    f"Could not resolve {feature_key}", severity="error"
                )
                self._stage = RalphStage.PAUSED
                self._update_hints(
                    ("r", "Retry"), ("enter", "Detail"), ("l", "Logs"),
                    ("?", "Help"), ("q", "Quit"),
                )
            self.app.call_from_thread(_notify_error)
            return

        # Clear stop event so the orchestrator can run
        self._orchestrator._stop_event.clear()

        # Run the single feature
        result = self._orchestrator._implement_feature(feature, 0, 0)

        # Append result
        self._orchestrator._results.append(result)

        # Update local feature state
        if result.outcome == FeatureOutcome.SUCCESS:
            feature_info["completion_status"] = "completed"

        # Transition back to PAUSED for further retries
        def _back_to_paused() -> None:
            self._stage = RalphStage.PAUSED
            try:
                header = self.query_one("#ralph-header", RalphHeader)
                header.session_state = "complete"
            except Exception:
                pass
            self._update_hints(
                ("r", "Retry"), ("enter", "Detail"), ("l", "Logs"),
                ("?", "Help"), ("q", "Quit"),
            )
        self.app.call_from_thread(_back_to_paused)

    def on_data_table_row_selected(self, event: DataTable.RowSelected) -> None:
        """Handle Enter on a feature row — open feature detail modal."""
        if self._stage not in (RalphStage.FEATURE_LIST, RalphStage.RUNNING, RalphStage.PAUSED):
            return
        feature_key = str(event.row_key.value)
        try:
            table = self.query_one("#feature-table", FeatureProgressTable)
            data = table.get_feature_data(feature_key)
        except Exception:
            return
        if data and data.get("id"):
            from mfbt.tui.screens.feature_detail import FeatureDetailScreen

            self.app.push_screen(
                FeatureDetailScreen(
                    data_provider=self.app.data_provider,
                    feature_id=data["id"],
                    feature_data=data,
                )
            )

    def on_feature_progress_table_show_logs(
        self, event: FeatureProgressTable.ShowLogs
    ) -> None:
        """Handle 'l' key — show logs for the selected feature."""
        if self._stage not in (RalphStage.RUNNING, RalphStage.PAUSED):
            return
        self._show_log_modal(event.feature_key)

    def _show_log_modal(self, feature_key: str) -> None:
        """Find log files for a feature and display them in a modal."""
        if self.session_log_dir is None or not self.session_log_dir.exists():
            self.app.notify("No logs available yet", severity="warning")
            return

        from mfbt.commands.ralph.log_capture import _sanitize_key

        sanitized = _sanitize_key(feature_key)
        log_files = sorted(self.session_log_dir.glob(f"{sanitized}_attempt-*.log"))

        if not log_files:
            self.app.notify(f"No logs for {feature_key} yet", severity="warning")
            return

        content_parts = []
        for lf in log_files:
            try:
                content_parts.append(lf.read_text())
            except OSError:
                content_parts.append(f"(could not read {lf.name})")

        content = "\n\n".join(content_parts)
        self.app.push_screen(LogViewerModal(content, f" Logs: {feature_key}"))

    def _tick_elapsed(self) -> None:
        """Update elapsed time display every second."""
        try:
            status_bar = self.query_one("#ralph-status-bar", RalphStatusBar)
            now = time.monotonic()

            # Overall timer: only update while session is running
            if not self._session_stopped:
                paused = self._paused_accumulated
                # If currently paused, also subtract the ongoing pause duration
                if self._pause_start > 0:
                    paused += now - self._pause_start
                status_bar.elapsed_seconds = now - self._session_start - paused

            # Feature timer: always update if a feature is active (supports retry)
            if self._feature_start > 0:
                paused = self._paused_accumulated
                if self._pause_start > 0:
                    paused += now - self._pause_start
                feature_paused = paused - self._feature_pause_snapshot
                status_bar.feature_elapsed_seconds = now - self._feature_start - feature_paused
                status_bar.show_feature_timer = True
            else:
                status_bar.show_feature_timer = False
        except Exception:
            pass

    def _glisten_tick(self) -> None:
        """Cycle the shimmer effect on the running feature status + log header."""
        key = self._running_feature_key
        if key is None:
            return
        self._glisten_frame = (self._glisten_frame + 1) % len(_GLISTEN_COLORS)
        color = _GLISTEN_COLORS[self._glisten_frame]
        try:
            table = self.query_one("#feature-table", FeatureProgressTable)
            table.update_cell(
                key, "status", Text.from_markup(f"[{color}]\u27f3 running[/{color}]")
            )
        except Exception:
            pass
        try:
            header = self.query_one("#log-pane-header", LogPaneHeader)
            header.update(
                Text.from_markup(
                    f" [{color}]\u27f3 Implementing {key}[/{color}]"
                )
            )
        except Exception:
            pass

    def _build_uncached_client(self) -> APIClient:
        """Create an APIClient without response caching for the orchestrator.

        The orchestrator needs fresh API responses (especially for
        verify_feature_completed) because feature status is mutated
        externally by the coding agent via MCP.
        """
        from mfbt.api_client import APIClient
        from mfbt.token_manager import TokenManager

        base_url = self._config.get("base_url", "https://app.mfbt.ai")
        tm = TokenManager(base_url)

        def _on_auth_required() -> bool:
            return False

        return APIClient(base_url, tm, cache=None, on_auth_required=_on_auth_required)

    def _run_orchestrator(self) -> None:
        """Run the orchestrator in a worker thread."""
        from mfbt.commands.ralph.log_capture import RalphLogger
        from mfbt.commands.ralph.orchestrator import RalphOrchestrator
        from mfbt.commands.ralph.tui_display import RalphTUIDisplay

        display = RalphTUIDisplay(self)

        log_base_dir = self._mfbt_dir / "logs"
        ralph_logger = RalphLogger(
            log_base_dir, self._ralph_config.coding_agent
        )

        self._orchestrator_client = self._build_uncached_client()
        self._orchestrator = RalphOrchestrator(
            self._ralph_config, self._orchestrator_client, display, logger=ralph_logger
        )
        self._orchestrator.run()
