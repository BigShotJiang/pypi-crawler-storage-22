"""K9s-style header widget for the TUI.

Displays context information (project, phase, stats) on the left
and an ASCII mfbt logo on the right.
"""

from __future__ import annotations

from textual.app import ComposeResult
from textual.containers import Horizontal
from textual.reactive import reactive
from textual.widget import Widget
from textual.widgets import Static

_LOGO = (
    "              ______    __ \n"
    "   ____ ___  / __/ /_  / /_\n"
    "  / __ `__ \\/ /_/ __ \\/ __/\n"
    " / / / / / / __/ /_/ / /_  \n"
    "/_/ /_/ /_/_/ /_.___/\\__/  "
)


class K9sHeader(Widget):
    """K9s-style header with context info and ASCII logo."""

    breadcrumb: reactive[str] = reactive("[bold]Projects[/bold]")
    project_name: reactive[str] = reactive("")
    project_key: reactive[str] = reactive("")
    phase_name: reactive[str] = reactive("")
    tech_stack: reactive[str] = reactive("")
    status: reactive[str] = reactive("")
    feature_count: reactive[int] = reactive(0)
    completion_pct: reactive[float] = reactive(0.0)
    context_level: reactive[str] = reactive("projects")
    module_name: reactive[str] = reactive("")
    user_info: reactive[str] = reactive("")
    hints: reactive[tuple[tuple[str, str], ...]] = reactive(())
    ralph_active: reactive[bool] = reactive(False)
    ralph_project_name: reactive[str] = reactive("")

    def compose(self) -> ComposeResult:
        with Horizontal(id="header-row"):
            yield Static(self._render_context(), id="header-context")
            yield Static(
                f"[#326CE5]{_LOGO}[/#326CE5]",
                id="header-logo",
            )
        yield Static(self._render_hints(), id="header-hints")

    def _render_context(self) -> str:
        """Render the context info based on the current navigation level."""
        lines: list[str] = [self.breadcrumb]

        if self.ralph_active:
            ralph_line = "[bold cyan]\u25b6 ralph[/bold cyan] [dim]— orchestration mode[/dim]"
            if self.ralph_project_name:
                ralph_line += f"  [dim]|[/dim]  [bold]{self.ralph_project_name}[/bold]"
            lines.append(ralph_line)
        elif self.context_level == "projects":
            lines.append("[dim]Select a project to get started[/dim]")

        elif self.context_level == "phases":
            if self.tech_stack:
                lines.append(f"[dim]Stack:[/dim] {self.tech_stack}")
            if self.status:
                lines.append(f"[dim]Status:[/dim] {self.status}")

        elif self.context_level == "modules":
            if self.phase_name:
                lines.append(f"[dim]Phase:[/dim] {self.phase_name}")

        elif self.context_level == "features":
            stats_parts: list[str] = []
            if self.feature_count:
                stats_parts.append(f"{self.feature_count} features")
            if self.completion_pct > 0:
                stats_parts.append(f"{self.completion_pct:.0%} complete")
            if stats_parts:
                lines.append("[dim]" + " | ".join(stats_parts) + "[/dim]")

        return "\n".join(lines)

    def _render_hints(self) -> str:
        """Render the key hints row."""
        if not self.hints:
            return ""
        parts: list[str] = []
        for key, desc in self.hints:
            parts.append(f"[bold #326CE5]<{key}>[/bold #326CE5] {desc}")
        return " " + "  ".join(parts)

    def _update_display(self) -> None:
        try:
            ctx = self.query_one("#header-context", Static)
            ctx.update(self._render_context())
        except Exception:
            pass
        try:
            hints_widget = self.query_one("#header-hints", Static)
            hints_widget.update(self._render_hints())
        except Exception:
            pass

    def watch_breadcrumb(self, value: str) -> None:
        self._update_display()

    def watch_project_name(self, value: str) -> None:
        self._update_display()

    def watch_project_key(self, value: str) -> None:
        self._update_display()

    def watch_phase_name(self, value: str) -> None:
        self._update_display()

    def watch_tech_stack(self, value: str) -> None:
        self._update_display()

    def watch_status(self, value: str) -> None:
        self._update_display()

    def watch_feature_count(self, value: int) -> None:
        self._update_display()

    def watch_completion_pct(self, value: float) -> None:
        self._update_display()

    def watch_context_level(self, value: str) -> None:
        self._update_display()

    def watch_module_name(self, value: str) -> None:
        self._update_display()

    def watch_user_info(self, value: str) -> None:
        self._update_display()

    def watch_hints(self, value: tuple[tuple[str, str], ...]) -> None:
        self._update_display()

    def watch_ralph_active(self, value: bool) -> None:
        self._update_display()

    def watch_ralph_project_name(self, value: str) -> None:
        self._update_display()
