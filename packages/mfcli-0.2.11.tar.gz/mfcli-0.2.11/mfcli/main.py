from mfcli.cli.main import run_cli


def main():
    run_cli()
