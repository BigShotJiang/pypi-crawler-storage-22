from fastmcp import FastMCP

# Create the MCP instance that will be shared across modules
mcp = FastMCP(
    name="ChromaDB Engineering Docs"
)
