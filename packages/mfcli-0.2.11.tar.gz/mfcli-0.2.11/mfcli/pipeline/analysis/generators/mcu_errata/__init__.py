"""MCU Errata Cheat Sheet Generator for firmware-relevant silicon errata."""
