#! /usr/local/bin/python3
"""Initialize the mformat package."""

# Copyright (c) 2025 - 2026 Tom Björkholm
# MIT License
#
