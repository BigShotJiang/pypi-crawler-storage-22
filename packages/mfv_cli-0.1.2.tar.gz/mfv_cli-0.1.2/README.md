# MFV - Feedback Viewer

Interactive CLI tool to view project assignments and reject notes with a beautiful Rich UI.

## Features

- Loop menu - Select multiple projects without restarting
- Config management - Securely stores authentication tokens
- Rich UI - Beautiful tables and panels with color-coded status
- Complete view - Shows all tasks, not just rejected ones
- Detailed feedback - Full reject notes in readable panels
- Auto-export - Saves data to JSON files for analysis

## Installation

### From PyPI (recommended)

```bash
pip install mfv-cli
```

### From source

```bash
git clone https://github.com/yourusername/mfv.git
cd mfv
pip install -e .
```

## Quick Start

### First Time Setup

```bash
mfv
```

On first run, you'll be prompted to configure your API credentials:
- Bearer Token - JWT token from browser
- ID Token - ID token from browser

Configuration is saved to `~/.marlin_viewer_config.json`

### Getting Your Tokens

1. Open API Dashboard in your browser
2. Open Developer Tools (F12) -> Network tab
3. Refresh the page or perform any action
4. Click on any `/api/v1/` request in the Network tab
5. Find and copy these headers:
   - `authorization: Bearer <token>` -> This is your Bearer Token
   - `x-id-token: <token>` -> This is your ID Token

## Usage

### Interactive Mode (Recommended)

```bash
mfv
```

Menu options:
- 1-4 - Select project number to view
- config - Reconfigure authentication tokens
- q/exit/quit - Exit the application

The tool will loop, allowing you to view multiple projects without restarting.

### Direct Project View

```bash
mfv "Project-Name"
```

View a specific project directly without the menu.

## Configuration

### Config File Location

`~/.marlin_viewer_config.json`

### Config File Format

```json
{
  "bearer_token": "your-bearer-token-here",
  "id_token": "your-id-token-here",
  "projects": {
    "Project-Name-1": "<project-id>",
    "Project-Name-2": "<project-id>"
  }
}
```

### Adding Projects

Edit the config file to add your project IDs. Get project IDs from API or network inspector.

### Reconfiguring

Run the tool and type `config` at the main menu, or delete the config file:

```bash
rm ~/.marlin_viewer_config.json
mfv
```

## Output

### On-Screen Display

- Summary table - All assignments with status, dates, and reject note indicators
- Statistics panel - Total counts and status breakdown
- Reject notes - Detailed feedback in readable panels

### JSON Export

Each project view is automatically saved to:
```
<Project_Name>_<timestamp>.json
```

Contains:
- Project metadata
- All task details
- Reject notes
- Summary statistics
- Fetch timestamp

## Status Indicators

Tasks are color-coded by status:
- ACCEPTED - Green
- REJECTED - Red (with reject notes)
- SKIPPED - Yellow
- Other - Default

## Requirements

- Python 3.8+
- Internet connection (to access API)
- Valid API account

## Dependencies

- requests - HTTP client
- rich - Terminal UI formatting

## Security Note

Your authentication tokens are stored locally in `~/.marlin_viewer_config.json`. 

Important:
- Do not share this file
- Do not commit it to version control
- Tokens expire after some time (typically 24 hours)

## Troubleshooting

### Token Expired

If you see 401/403 errors:
```bash
mfv
# Type 'config' at menu to update tokens
```

### No Projects Shown

Ensure you have configured projects in your config file.

### API Errors

Check your internet connection and verify your tokens are current.

## License

MIT License - see LICENSE file for details

## Author

Bao Tran (tranlequybaotk12@gmail.com)

## Contributing

Contributions welcome! Please open an issue or submit a pull request.

## Changelog

### 0.1.0 (2024-02-08)

- Initial release
- Interactive project selection
- Rich UI with tables and panels
- Configuration management
- JSON export
- Loop menu support
