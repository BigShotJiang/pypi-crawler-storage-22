"""
MFV - Feedback Viewer - Interactive viewer for API Project project feedback
"""

__version__ = "0.1.2"
__author__ = "Bao Tran"
__email__ = "tranlequybaotk12@gmail.com"
