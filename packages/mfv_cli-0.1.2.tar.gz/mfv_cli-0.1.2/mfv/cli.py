#!/usr/bin/env python3
"""
MFV - Feedback Viewer - Interactive project selector with Rich UI
"""

import requests
import json
import os
from datetime import datetime
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.prompt import Prompt, Confirm
from rich import box
from pathlib import Path

console = Console()

# Configuration file path
CONFIG_FILE = Path.home() / ".project_viewer_config.json"

# API Configuration  
BASE_URL = "https://experts.snorkel-ai.com/api/v1"  # API endpoint

# Default projects (can be overridden by user config)
DEFAULT_PROJECTS = {
    "Project-Prompt-Review-V2": "268ad133-be4b-4757-aaee-8bb694763e1d",
    "Project-Expert_Assessment-2": "0d06d331-bf1f-45b8-bd80-1b2ffc892b52",
    "Project-Prompt-Preparation": "8cfeaaa1-f190-4254-a6df-3bbc13e1ee45",
    "Project-PR-Selection": "5dc8109d-e5b7-4e54-8cf7-f7ed5b7d6674"
}


def load_config():
    """Load configuration from file"""
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE, 'r') as f:
                return json.load(f)
        except:
            return None
    return None


def save_config(config):
    """Save configuration to file"""
    with open(CONFIG_FILE, 'w') as f:
        json.dump(config, f, indent=2)
    console.print(f"[green]Configuration saved to:[/green] {CONFIG_FILE}")


def setup_config():
    """Interactive configuration setup"""
    console.print()
    console.print(Panel.fit(
        "[bold cyan]CONFIGURATION SETUP[/bold cyan]\n[dim]Enter your API API credentials[/dim]",
        border_style="cyan"
    ))
    console.print()
    
    console.print("[yellow]You can find these tokens from your browser's network inspector:[/yellow]")
    console.print("  1. Open API Experts dashboard in browser")
    console.print("  2. Open Developer Tools (F12) > Network tab")
    console.print("  3. Make any API request (refresh page)")
    console.print("  4. Click on a request to /api/v1/")
    console.print("  5. Copy 'authorization' and 'x-id-token' headers")
    console.print()
    
    bearer_token = Prompt.ask("[cyan]Enter Bearer Token (long JWT string)[/cyan]")
    id_token = Prompt.ask("[cyan]Enter ID Token (long JWT string)[/cyan]")
    
    config = {
        "bearer_token": bearer_token,
        "id_token": id_token,
        "projects": DEFAULT_PROJECTS
    }
    
    save_config(config)
    return config


def get_config():
    """Get configuration (load or setup)"""
    config = load_config()
    
    if not config:
        console.print("[yellow]No configuration found. Let's set it up![/yellow]")
        config = setup_config()
    else:
        console.print("[green]Configuration loaded from:[/green]", CONFIG_FILE)
    
    return config


def make_request(endpoint, config, params=None):
    """Make API request"""
    headers = {
        "accept": "*/*",
        "accept-language": "en-US,en;q=0.9,vi;q=0.8",
        "authorization": f"Bearer {config['bearer_token']}",
        "x-id-token": config['id_token'],
        "priority": "u=1, i",
        "referer": "https://experts.snorkel-ai.com/dashboard",  # Dashboard URL
        "sec-ch-ua": '"Google Chrome";v="131", "Chromium";v="131", "Not_A Brand";v="24"',
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": '"Linux"',
        "sec-fetch-dest": "empty",
        "sec-fetch-mode": "cors",
        "sec-fetch-site": "same-origin",
        "user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
    }
    
    url = f"{BASE_URL}{endpoint}"
    response = requests.get(url, headers=headers, params=params)
    response.raise_for_status()
    return response.json() if response.text else None


def get_assignments(project_id, config, limit=100):
    """Get assignments for project"""
    params = {
        "project_id": project_id,
        "task_id": "",
        "limit": limit,
        "skip": 0,
        "remove_offered_assignments": "true"
    }
    return make_request("/assignments", config, params=params)


def display_project_feedbacks(project_name, project_id, config):
    """Display feedbacks for selected project"""
    
    # Header
    console.print()
    console.print(Panel(f"[bold cyan]{project_name}[/bold cyan]", 
                        title="Project", 
                        border_style="cyan"))
    
    # Get assignments
    try:
        with console.status("[bold green]Fetching assignments..."):
            data = get_assignments(project_id, config)
    except requests.exceptions.HTTPError as e:
        console.print(f"[red]API Error:[/red] {e}")
        if e.response.status_code == 401 or e.response.status_code == 403:
            console.print("[yellow]Your tokens may have expired. Please reconfigure.[/yellow]")
        return
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        return
    
    if not data or 'assignments' not in data:
        console.print("[red]No assignments found[/red]")
        return
    
    assignments = data['assignments']
    
    # Create main table
    table = Table(
        title=f"All Assignments ({len(assignments)} total)",
        box=box.ROUNDED,
        show_header=True,
        header_style="bold magenta",
        title_style="bold cyan"
    )
    
    table.add_column("#", style="dim", width=4, justify="right")
    table.add_column("Task ID", style="cyan", width=38)
    table.add_column("Status", width=15)
    table.add_column("Created", style="dim", width=12)
    table.add_column("Has Reject Notes", justify="center", width=18)
    
    # Collect data
    all_tasks = []
    reject_notes_tasks = []
    
    for i, assignment in enumerate(assignments, 1):
        task_id = assignment.get('task_id', '')
        status = assignment.get('status', '')
        created = assignment.get('created_at', '')
        reject_notes = assignment.get('reject_notes', '')
        
        if created and 'T' in created:
            created = created.split('T')[0]
        
        has_reject = "Yes" if reject_notes and reject_notes.strip() else "No"
        
        # Color code status
        if status == "ACCEPTED":
            status_display = f"[green]{status}[/green]"
        elif status == "REJECTED":
            status_display = f"[red]{status}[/red]"
        elif status == "SKIPPED":
            status_display = f"[yellow]{status}[/yellow]"
        else:
            status_display = status
        
        # Color code reject notes indicator
        has_reject_display = f"[red bold]{has_reject}[/red bold]" if has_reject == "Yes" else f"[dim]{has_reject}[/dim]"
        
        table.add_row(
            str(i),
            task_id[:36],
            status_display,
            created,
            has_reject_display
        )
        
        all_tasks.append({
            'num': i,
            'task_id': task_id,
            'status': status,
            'created_at': created,
            'reject_notes': reject_notes
        })
        
        if reject_notes and reject_notes.strip():
            reject_notes_tasks.append({
                'num': i,
                'task_id': task_id,
                'status': status,
                'created_at': created,
                'reject_notes': reject_notes
            })
    
    console.print()
    console.print(table)
    
    # Summary stats
    stats_table = Table(box=box.SIMPLE, show_header=False, padding=(0, 2))
    stats_table.add_column("Label", style="bold")
    stats_table.add_column("Count", justify="right")
    
    status_counts = {}
    for task in all_tasks:
        status = task['status']
        status_counts[status] = status_counts.get(status, 0) + 1
    
    stats_table.add_row("Total Assignments", f"[cyan]{len(all_tasks)}[/cyan]")
    stats_table.add_row("With Reject Notes", f"[red]{len(reject_notes_tasks)}[/red]")
    for status, count in sorted(status_counts.items()):
        stats_table.add_row(f"Status: {status}", str(count))
    
    console.print()
    console.print(Panel(stats_table, title="Summary", border_style="green"))
    
    # Display reject notes details
    if reject_notes_tasks:
        console.print()
        console.print(Panel("[bold yellow]Reject Notes Details[/bold yellow]", 
                          border_style="yellow"))
        
        for task in reject_notes_tasks:
            console.print()
            console.print(f"[bold cyan]Task #{task['num']}:[/bold cyan] {task['task_id'][:36]}")
            console.print(f"[dim]Status: {task['status']} | Date: {task['created_at']}[/dim]")
            console.print()
            
            # Wrap reject notes in panel
            notes_panel = Panel(
                task['reject_notes'],
                border_style="red",
                padding=(1, 2)
            )
            console.print(notes_panel)
    
    # Save to file in home directory
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"{project_name.replace(' ', '_').replace('-', '_')}_{timestamp}.json"
    filepath = Path.home() / filename
    
    save_data = {
        'project_name': project_name,
        'project_id': project_id,
        'total_assignments': len(all_tasks),
        'reject_notes_count': len(reject_notes_tasks),
        'fetched_at': datetime.now().isoformat(),
        'all_tasks': all_tasks
    }
    
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(save_data, f, indent=2, ensure_ascii=False)
    
    console.print()
    console.print(f"[green]Saved to:[/green] {filepath}")
    console.print()


def show_main_menu(config):
    """Show main menu and handle project selection loop"""
    
    while True:
        console.print()
        console.print(Panel.fit(
            "[bold cyan]MFV - FEEDBACK VIEWER[/bold cyan]\n[dim]Select a project to view assignments and reject notes[/dim]",
            border_style="cyan"
        ))
        console.print()
        
        projects = config.get('projects', DEFAULT_PROJECTS)
        
        # Show project menu
        console.print("[bold]Available projects:[/bold]")
        project_list = list(projects.keys())
        for i, name in enumerate(project_list, 1):
            console.print(f"  {i}. {name}")
        
        console.print()
        console.print("[dim]Commands: [bold]1-{0}[/bold] to select project, [bold]config[/bold] to reconfigure, [bold]q/exit[/bold] to quit[/dim]".format(len(project_list)))
        console.print()
        
        choice = Prompt.ask(
            "Select option",
            default="q"
        ).strip().lower()
        
        # Handle exit
        if choice in ['q', 'quit', 'exit']:
            console.print("[yellow]Goodbye![/yellow]")
            break
        
        # Handle reconfig
        if choice == 'config':
            config = setup_config()
            continue
        
        # Handle project selection
        project_name = None
        
        if choice.isdigit():
            idx = int(choice) - 1
            if 0 <= idx < len(project_list):
                project_name = project_list[idx]
        elif choice in projects:
            project_name = choice
        else:
            console.print(f"[red]Invalid choice:[/red] {choice}")
            continue
        
        if project_name:
            project_id = projects[project_name]
            display_project_feedbacks(project_name, project_id, config)
            
            # Ask if want to view another project
            console.print()
            if not Confirm.ask("[cyan]View another project?[/cyan]", default=True):
                console.print("[yellow]Goodbye![/yellow]")
                break


def main():
    """Main function"""
    import sys
    
    # Get or setup configuration
    config = get_config()
    
    # Check if project specified in command line
    if len(sys.argv) > 1:
        project_name = sys.argv[1]
        projects = config.get('projects', DEFAULT_PROJECTS)
        
        if project_name not in projects:
            console.print(f"[red]Unknown project:[/red] {project_name}")
            console.print("\n[bold]Available projects:[/bold]")
            for i, name in enumerate(projects.keys(), 1):
                console.print(f"  {i}. {name}")
            return
        
        project_id = projects[project_name]
        display_project_feedbacks(project_name, project_id, config)
    else:
        # Interactive mode
        show_main_menu(config)


if __name__ == "__main__":
    main()
