"""Basic tests for marlin_viewer"""

import pytest
from marlin_viewer import __version__


def test_version():
    """Test version is set"""
    assert __version__ == "0.1.0"


def test_import():
    """Test package can be imported"""
    import marlin_viewer
    assert marlin_viewer is not None
