"""MH1 Copilot - AI-Powered Marketing Operations CLI"""

__version__ = "0.6.0"
__author__ = "MarketerHire"
