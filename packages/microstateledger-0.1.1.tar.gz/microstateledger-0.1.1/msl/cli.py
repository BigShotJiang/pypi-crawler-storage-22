from __future__ import annotations

import json
import os
import io
import sqlite3
import math
import uuid
import shutil
import re
import subprocess
import sys
from contextlib import redirect_stdout
from pathlib import Path
from typing import Any, Dict, List, Optional

import typer
import yaml

from msl import ids
from msl import resources as msl_resources
from msl.config import find_default_config, load_config
from msl.db import (
    connect,
    finish_run,
    get_compound_by_hash,
    init_db,
    migrate_db,
    insert_artifact,
    insert_anomaly,
    insert_atom_map,
    insert_compound,
    insert_conformer,
    insert_decision,
    insert_edge,
    insert_external_ref,
    insert_microstate,
    insert_pose,
    insert_receptor,
    insert_run,
    insert_system,
)
from msl.utils import ensure_dir, read_json, run_cmd, sha256_file, write_json

app = typer.Typer(
    add_completion=False,
    pretty_exceptions_enable=False,
    pretty_exceptions_show_locals=False,
)


def _resolve_config_path(config: Optional[Path]) -> Path:
    if config is not None:
        return config
    try:
        return find_default_config()
    except FileNotFoundError as e:
        raise typer.BadParameter(
            "msl.toml not found in current directory; pass --config /path/to/msl.toml"
        ) from e


def _load_policy(path: Path) -> Dict[str, Any]:
    if not path.exists():
        path = msl_resources.get_resource_file("policies", path.name)
    with path.open("r", encoding="utf-8") as f:
        data = yaml.safe_load(f)
    _validate_policy(data)
    return data


def _require(d: Dict[str, Any], path: str, expected: Any) -> Any:
    cur = d
    parts = path.split(".")
    for p in parts[:-1]:
        if not isinstance(cur, dict) or p not in cur:
            raise typer.BadParameter(f"policy missing {path}")
        cur = cur[p]
    key = parts[-1]
    if not isinstance(cur, dict) or key not in cur:
        raise typer.BadParameter(f"policy missing {path}")
    val = cur[key]
    if expected and not isinstance(val, expected):
        raise typer.BadParameter(f"policy {path} must be {expected}")
    return val


def _validate_policy(policy: Dict[str, Any]) -> None:
    if not isinstance(policy, dict):
        raise typer.BadParameter("policy must be a mapping")
    _require(policy, "project", dict)
    _require(policy, "project.ph", dict)
    _require(policy, "project.ph.min", (int, float))
    _require(policy, "project.ph.max", (int, float))
    _require(policy, "project.max_microstates", int)
    _require(policy, "stages", dict)
    _require(policy, "stages.pre_docking_enum", dict)
    _require(policy, "stages.pre_docking_enum.protonation", dict)
    _require(policy, "stages.pre_docking_enum.protonation.method", str)
    _require(policy, "stages.pre_docking_enum.protonation.max_variants", int)
    _require(policy, "stages.pre_docking_enum.tautomer", dict)
    _require(policy, "stages.pre_docking_enum.tautomer.method", str)
    _require(policy, "stages.pre_docking_enum.tautomer.max_tautomers", int)
    _require(policy, "stages.pre_docking_enum.stereo", dict)
    _require(policy, "stages.pre_docking_enum.stereo.max_isomers", int)
    _require(policy, "stages.pre_docking_enum.select_microstates", dict)
    strategy = _require(policy, "stages.pre_docking_enum.select_microstates.strategy", str)
    if "keep_all_if_total<=" not in strategy and "topk" not in strategy:
        raise typer.BadParameter("policy select_microstates.strategy format invalid")
    if "stages" in policy and "conformer_generation" in policy["stages"]:
        cg = policy["stages"]["conformer_generation"]
        if "select_conformers" in cg:
            by_list = cg["select_conformers"].get("by", [])
            if by_list and not isinstance(by_list, list):
                raise typer.BadParameter("policy conformer_generation.select_conformers.by must be list")


def _capture_output(fn, *args, **kwargs) -> str:
    buf = io.StringIO()
    with redirect_stdout(buf):
        fn(*args, **kwargs)
    return buf.getvalue()


def _schema_path(cfg) -> Path:
    path = cfg.root / "schemas" / "ledger.sql"
    if path.exists():
        return path
    return msl_resources.get_resource_file("schemas", "ledger.sql")


def _env_path(cfg, name: str) -> Path:
    return cfg.envs_base / name


def _resolve_conda_executable(cfg) -> Optional[str]:
    conda_raw = str(cfg.conda)
    conda_path = Path(conda_raw)
    if conda_path.exists():
        return conda_raw
    return shutil.which(conda_raw)


def _resolve_user_bin(cmd: str) -> str:
    if Path(cmd).exists():
        return cmd
    resolved = shutil.which(cmd)
    if resolved:
        return resolved
    local_bin = Path.home() / ".local" / "bin" / cmd
    if local_bin.exists():
        return str(local_bin)
    return cmd


def _module_available(module_name: str) -> bool:
    probe = subprocess.run(
        [sys.executable, "-c", f"import {module_name}"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        check=False,
    )
    return probe.returncode == 0


def _short_error(exc: Exception) -> str:
    msg = str(exc).strip()
    if not msg:
        return exc.__class__.__name__
    if "STDERR:\n" in msg:
        stderr = msg.split("STDERR:\n", 1)[1].strip()
        if stderr:
            lines = [ln.strip() for ln in stderr.splitlines() if ln.strip()]
            for line in reversed(lines):
                if line.startswith("Traceback"):
                    continue
                if line.startswith("File "):
                    continue
                if len(line) > 220:
                    return line[:217] + "..."
                return line
            if lines:
                return lines[0][:220]
    line = msg.splitlines()[0]
    if len(line) > 220:
        return line[:217] + "..."
    return line


def _input_has_multiple_molecules(path: Path) -> bool:
    suffix = path.suffix.lower()
    if suffix not in {".sdf", ".smi", ".smiles", ".txt"}:
        return False
    try:
        with path.open("r", encoding="utf-8", errors="ignore") as f:
            if suffix == ".sdf":
                count = 0
                for line in f:
                    if line.strip() == "$$$$":
                        count += 1
                        if count > 1:
                            return True
                return False

            count = 0
            for line in f:
                if line.strip():
                    count += 1
                    if count > 1:
                        return True
            return False
    except Exception:
        return False


_ENV_CMD_PROBES = {
    "dimorphite": "dimorphite_dl",
    "meeko": "mk_prepare_ligand.py",
    "dvc": "dvc",
    "datalad": "datalad",
    "lwreg": "lwreg",
}

_ENV_MODULE_PROBES = {
    "rdkit": "rdkit",
    "openff": "openff.toolkit",
    "pype_resp": "pype_resp",
    "meeko": "meeko",
    "dimorphite": "dimorphite_dl",
}

_ENV_EXTRA_HINTS = {
    "rdkit": "cheminformatics",
    "dimorphite": "cheminformatics",
    "meeko": "docking",
    "openff": "md",
    "pype_resp": "charges",
    "dvc": "repro",
    "datalad": "repro",
    "lwreg": "repro",
}


def _install_hint_for_env(env_name: str) -> str:
    extra = _ENV_EXTRA_HINTS.get(env_name)
    if not extra:
        return ""
    return f" Try: pip install 'MicrostateLedger[{extra}]'."


def _cmd_timeout_seconds() -> Optional[float]:
    raw = os.environ.get("MSL_CMD_TIMEOUT_SEC", "").strip()
    if not raw:
        return None
    try:
        value = float(raw)
    except ValueError as e:
        raise typer.BadParameter("MSL_CMD_TIMEOUT_SEC must be a positive number") from e
    if value <= 0:
        raise typer.BadParameter("MSL_CMD_TIMEOUT_SEC must be > 0")
    return value


def _env_available(cfg, name: str) -> bool:
    env_path = _env_path(cfg, name)
    if env_path.exists():
        return True

    # If conda is available, absence of the requested env should be treated as unavailable.
    if _resolve_conda_executable(cfg):
        return False

    # No conda available: probe current runtime as a graceful fallback path.
    cmd_probe = _ENV_CMD_PROBES.get(name)
    if cmd_probe and Path(_resolve_user_bin(cmd_probe)).exists():
        return True
    module_probe = _ENV_MODULE_PROBES.get(name)
    if module_probe and _module_available(module_probe):
        return True
    if cmd_probe or module_probe:
        return False

    # Unknown env label: allow execution and let the command fail with a clear message if needed.
    return True


def _run_in_env(cfg, env_name: str, cmd: List[str], cwd: Optional[Path] = None) -> str:
    env_path = _env_path(cfg, env_name)
    conda_exec = _resolve_conda_executable(cfg)

    if not cmd:
        raise typer.BadParameter(f"empty command for env '{env_name}'")

    timeout_seconds = _cmd_timeout_seconds()

    def _run_direct_with_env(stage_cmd: List[str], env_root: Optional[Path]) -> str:
        direct_cmd = list(stage_cmd)
        env_vars = os.environ.copy()
        local_bin = str(Path.home() / ".local" / "bin")
        env_vars["PATH"] = local_bin + os.pathsep + env_vars.get("PATH", "")

        if env_root and env_root.exists():
            env_bin = env_root / "bin"
            env_vars["PATH"] = str(env_bin) + os.pathsep + env_vars.get("PATH", "")
            # Amber-style tools (py_resp.py/pyresp_gen.py/sqm) are expected under AMBERHOME/bin.
            if env_name == "pype_resp" and "AMBERHOME" not in env_vars:
                if (env_bin / "py_resp.py").exists() and (env_bin / "pyresp_gen.py").exists():
                    env_vars["AMBERHOME"] = str(env_root)

        if direct_cmd[0] in {"python", "python3"}:
            if env_root and (env_root / "bin" / "python").exists():
                direct_cmd[0] = str(env_root / "bin" / "python")
            else:
                direct_cmd[0] = sys.executable
        elif env_root and (env_root / "bin" / direct_cmd[0]).exists():
            direct_cmd[0] = str(env_root / "bin" / direct_cmd[0])
        else:
            direct_cmd[0] = _resolve_user_bin(direct_cmd[0])

        return run_cmd(direct_cmd, cwd=cwd, env=env_vars, timeout_seconds=timeout_seconds)

    if env_path.exists():
        try:
            return _run_direct_with_env(cmd, env_path)
        except RuntimeError as direct_err:
            # Fallback to conda run when direct invocation fails inside managed env.
            if conda_exec:
                try:
                    full_cmd = [conda_exec, "run", "-p", str(env_path)] + cmd
                    return run_cmd(full_cmd, cwd=cwd, timeout_seconds=timeout_seconds)
                except RuntimeError as conda_err:
                    raise typer.BadParameter(f"stage '{env_name}' failed: {_short_error(conda_err)}") from conda_err
            raise typer.BadParameter(f"stage '{env_name}' failed: {_short_error(direct_err)}") from direct_err
        except FileNotFoundError as e:
            missing = e.filename or cmd[0]
            raise typer.BadParameter(
                f"cannot execute stage '{env_name}': missing '{missing}'. "
                "Install dependency in current environment or configure [envs] conda/base_dir."
                + _install_hint_for_env(env_name)
            ) from e

    # Graceful fallback for deployments without conda-managed stage envs.
    try:
        return _run_direct_with_env(cmd, None)
    except FileNotFoundError as e:
        missing = e.filename or cmd[0]
        raise typer.BadParameter(
            f"cannot execute stage '{env_name}': missing '{missing}'. "
            "Install dependency in current environment or configure [envs] conda/base_dir."
            + _install_hint_for_env(env_name)
        ) from e
    except RuntimeError as e:
        raise typer.BadParameter(f"stage '{env_name}' failed: {_short_error(e)}") from e


def _scripts_path(cfg, name: str) -> Path:
    path = cfg.root / "scripts" / name
    if path.exists():
        return path
    return msl_resources.get_resource_file("scripts", name)


def _eval_enabled_if(expr: str, rot_bonds: int) -> bool:
    expr = expr.strip()
    m = re.match(r"^rot_bonds\s*(>=|<=|==|>|<)\s*(\d+)\s*$", expr)
    if not m:
        return False
    op, val = m.group(1), int(m.group(2))
    if op == ">=":
        return rot_bonds >= val
    if op == "<=":
        return rot_bonds <= val
    if op == ">":
        return rot_bonds > val
    if op == "<":
        return rot_bonds < val
    if op == "==":
        return rot_bonds == val
    return False


def _rotbond_count(cfg, sdf_path: Path) -> int:
    script = _scripts_path(cfg, "rdkit_rotbond_count.py")
    out = _run_in_env(cfg, "rdkit", ["python", str(script), "--input", str(sdf_path)])
    return int(str(out).strip())


@app.command()
def init(config: Optional[Path] = typer.Option(None, "--config")):
    """Initialize ledger database."""
    cfg_path = _resolve_config_path(config)
    cfg = load_config(cfg_path)
    ensure_dir(cfg.root)
    try:
        init_db(cfg.ledger_db, _schema_path(cfg))
    except (sqlite3.Error, OSError, RuntimeError) as e:
        raise typer.BadParameter(
            f"failed to initialize ledger database at '{cfg.ledger_db}': {_short_error(e)}"
        ) from e
    typer.echo(f"Initialized ledger at {cfg.ledger_db}")


@app.command()
def migrate(config: Optional[Path] = typer.Option(None, "--config")):
    """Migrate ledger schema to latest version."""
    cfg_path = _resolve_config_path(config)
    cfg = load_config(cfg_path)
    conn = connect(cfg.ledger_db)
    try:
        migrate_db(conn, _schema_path(cfg))
        conn.commit()
    except (RuntimeError, sqlite3.Error, OSError) as e:
        conn.rollback()
        raise typer.BadParameter(f"migrate failed: {_short_error(e)}") from e
    finally:
        conn.close()
    typer.echo("Schema migrated")


@app.command()
def ingest(
    input: str = typer.Argument(..., help="SMILES string or path to SDF/SMI"),
    name: str = typer.Option("", help="Compound name"),
    config: Optional[Path] = typer.Option(None, "--config"),
):
    """Ingest compound, standardize, and register compound ID."""
    cfg_path = _resolve_config_path(config)
    cfg = load_config(cfg_path)
    in_path = Path(input)
    if in_path.exists() and _input_has_multiple_molecules(in_path):
        raise typer.BadParameter(f"Input file contains multiple molecules: {input}. Use 'msl batch'.")

    policy = _load_policy(cfg.policy_path)
    ingest_cfg = policy.get("stages", {}).get("rdkit_ingest", {}) if isinstance(policy, dict) else {}
    keep_salts = bool(ingest_cfg.get("keep_salts", False))
    standardize = bool(ingest_cfg.get("standardize", True))
    ensure_dir(cfg.objects_dir / "compounds")
    run_id = uuid.uuid4().hex
    conn = connect(cfg.ledger_db)
    insert_run(
        conn,
        run_id,
        "rdkit_ingest",
        "rdkit",
        json.dumps({
            "input": input,
            "keep_salts": keep_salts,
            "standardize": standardize,
            "policy_path": str(cfg.policy_path),
            "policy_sha256": sha256_file(cfg.policy_path) if cfg.policy_path.exists() else "",
        }),
        "running",
        "",
    )
    conn.commit()
    conn.close()

    out_sdf = cfg.runs_dir / f"{run_id}_ingest.sdf"
    ensure_dir(out_sdf.parent)

    script = _scripts_path(cfg, "rdkit_ingest.py")
    cmd = ["python", str(script), "--input", input, "--output", str(out_sdf)]
    if keep_salts:
        cmd += ["--keep-salts"]
    if not standardize:
        cmd += ["--no-standardize"]
    try:
        out_json = _run_in_env(cfg, "rdkit", cmd)
        data = json.loads(out_json)
    except Exception as e:
        conn = connect(cfg.ledger_db)
        insert_anomaly(
            conn,
            "AN-" + uuid.uuid4().hex[:12],
            run_id,
            input,
            "ingest_failed",
            json.dumps({"error": str(e)}),
        )
        finish_run(conn, run_id, "failed")
        conn.commit()
        conn.close()
        raise typer.BadParameter(f"ingest failed for '{input}': {_short_error(e)}") from e

    reg_hash = data["reg_hash"]
    compound_id = ids.compound_id(reg_hash)

    conn = connect(cfg.ledger_db)
    existing = get_compound_by_hash(conn, reg_hash)
    if existing:
        finish_run(conn, run_id, "skipped")
        conn.commit()
        conn.close()
        typer.echo(existing)
        return

    final_dir = cfg.objects_dir / "compounds"
    ensure_dir(final_dir)
    final_sdf = final_dir / f"{compound_id}.sdf"
    if final_sdf.exists() and final_sdf.is_symlink():
        final_sdf.unlink()
    out_sdf.replace(final_sdf)

    try:
        insert_compound(conn, compound_id, name, reg_hash, data.get("inchikey", ""), str(final_sdf))
    except Exception as e:
        msg = str(e).lower()
        # Concurrent ingest may pass the hash check in parallel and collide on insert.
        if "unique constraint failed" in msg and "compounds.compound_id" in msg:
            finish_run(conn, run_id, "skipped")
            conn.commit()
            conn.close()
            typer.echo(compound_id)
            return
        raise

    artifact_hash = sha256_file(final_sdf)
    insert_artifact(conn, ids.artifact_id(final_sdf), "compound_sdf", str(final_sdf), artifact_hash, run_id)

    finish_run(conn, run_id, "ok")
    conn.commit()
    conn.close()
    typer.echo(compound_id)


@app.command()
def perceive(
    compound_id: str = typer.Argument(..., help="Compound ID"),
    config: Optional[Path] = typer.Option(None, "--config"),
):
    """Perception: estimate microstate explosion risk."""
    cfg_path = _resolve_config_path(config)
    cfg = load_config(cfg_path)
    policy = _load_policy(cfg.policy_path)
    ph_min = policy["project"]["ph"]["min"]
    ph_max = policy["project"]["ph"]["max"]
    max_variants = policy["stages"]["pre_docking_enum"]["protonation"]["max_variants"]
    max_tautomers = policy["stages"]["pre_docking_enum"]["tautomer"]["max_tautomers"]
    max_isomers = policy["stages"]["pre_docking_enum"]["stereo"]["max_isomers"]

    conn = connect(cfg.ledger_db)
    row = conn.execute("SELECT parent_sdf_path FROM compounds WHERE compound_id = ?", (compound_id,)).fetchone()
    if not row:
        raise typer.BadParameter(f"Compound {compound_id} not found")
    sdf_path = Path(row[0])

    run_id = uuid.uuid4().hex
    insert_run(conn, run_id, "perception", "dimorphite+rdkit", json.dumps({"compound_id": compound_id}), "running", "")
    if not _env_available(cfg, "dimorphite"):
        insert_decision(conn, "D-" + uuid.uuid4().hex[:12], run_id, compound_id, "skipped", "missing_env", json.dumps({"env": "dimorphite"}))
        finish_run(conn, run_id, "skipped")
        conn.commit()
        conn.close()
        typer.echo("Perception skipped: missing dimorphite env")
        return

    tmp_smi = cfg.runs_dir / f"{compound_id}_input.smi"
    tmp_smi.parent.mkdir(parents=True, exist_ok=True)
    script_smiles = _scripts_path(cfg, "rdkit_to_smiles.py")
    smiles = _run_in_env(cfg, "rdkit", ["python", str(script_smiles), "--input", str(sdf_path)])
    tmp_smi.write_text(smiles + "\n", encoding="utf-8")

    out_file = cfg.runs_dir / f"{compound_id}_dimorphite.smi"
    _run_in_env(
        cfg,
        "dimorphite",
        ["dimorphite_dl", str(tmp_smi), "--ph_min", str(ph_min), "--ph_max", str(ph_max), "--max_variants", str(max_variants), "--output_file", str(out_file)],
    )
    n_ion = len([l for l in out_file.read_text(encoding="utf-8").splitlines() if l.strip()])

    script_taut = _scripts_path(cfg, "rdkit_tautomer_count.py")
    n_taut = int(_run_in_env(cfg, "rdkit", ["python", str(script_taut), "--input", str(sdf_path), "--max_tautomers", str(max_tautomers)]))

    script_stereo = _scripts_path(cfg, "rdkit_stereo_count.py")
    n_stereo = int(_run_in_env(cfg, "rdkit", ["python", str(script_stereo), "--input", str(sdf_path), "--max_isomers", str(max_isomers)]))

    script_risk = _scripts_path(cfg, "rdkit_risk_flags.py")
    risk_flags = json.loads(_run_in_env(cfg, "rdkit", ["python", str(script_risk), "--input", str(sdf_path)]))

    n_total = max(1, n_ion) * max(1, n_taut) * max(1, n_stereo)
    risk_score = round(math.log10(n_total + 1), 3)
    cap_notice = ""
    try:
        max_microstates = int(policy["project"]["max_microstates"])
    except Exception:
        max_microstates = 0
    threshold = None
    strategy = str(policy.get("stages", {}).get("pre_docking_enum", {}).get("select_microstates", {}).get("strategy", ""))
    if "keep_all_if_total<=" in strategy:
        try:
            tail = strategy.split("keep_all_if_total<=")[1]
            threshold = int(tail.split("_else_topk")[0])
        except Exception:
            threshold = None
    if threshold is not None and n_total > threshold:
        cap_notice = "will_trigger_topk"
    elif max_microstates and n_total > max_microstates:
        cap_notice = "will_trigger_topk"

    warnings = []
    if risk_flags.get("has_undefined_chirality"):
        warnings.append("Undefined stereocenters detected")
    if risk_flags.get("has_undefined_ez"):
        warnings.append("Undefined E/Z stereochemistry detected")
    if risk_flags.get("has_coordination_risk"):
        warnings.append("Coordination/metal risk detected")
    if risk_score >= 2.0:
        risk_level = "high"
    elif risk_score >= 1.0:
        risk_level = "medium"
    else:
        risk_level = "low"

    report = {
        "compound_id": compound_id,
        "n_ionization_states_est": n_ion,
        "n_tautomers_est": n_taut,
        "n_stereoisomers_est": n_stereo,
        "n_total_microstates_est": n_total,
        "risk_score": risk_score,
        "risk_level": risk_level,
        "cap_notice": cap_notice,
        "danger_flags": risk_flags,
        "warnings": warnings,
    }

    report_dir = cfg.reports_dir / compound_id
    ensure_dir(report_dir)
    report_path = report_dir / "risk_report.json"
    if report_path.exists() and report_path.is_symlink():
        report_path = report_dir / f"risk_report_{run_id}.json"
    write_json(report_path, report)

    insert_artifact(conn, ids.artifact_id(report_path), "risk_report", str(report_path), sha256_file(report_path), run_id)
    finish_run(conn, run_id, "ok")
    conn.commit()
    conn.close()

    typer.echo(json.dumps(report, ensure_ascii=False, indent=2))


@app.command("enumerate")
def enumerate_microstates(
    compound_id: str = typer.Argument(..., help="Compound ID"),
    config: Optional[Path] = typer.Option(None, "--config"),
):
    """Enumerate microstates (protonation + tautomer + stereo)."""
    cfg_path = _resolve_config_path(config)
    cfg = load_config(cfg_path)
    policy = _load_policy(cfg.policy_path)

    ph_min = policy["project"]["ph"]["min"]
    ph_max = policy["project"]["ph"]["max"]
    max_variants = policy["stages"]["pre_docking_enum"]["protonation"]["max_variants"]
    max_tautomers = policy["stages"]["pre_docking_enum"]["tautomer"]["max_tautomers"]
    max_isomers = policy["stages"]["pre_docking_enum"]["stereo"]["max_isomers"]
    max_microstates = policy["project"]["max_microstates"]

    conn = connect(cfg.ledger_db)
    row = conn.execute("SELECT parent_sdf_path FROM compounds WHERE compound_id = ?", (compound_id,)).fetchone()
    if not row:
        raise typer.BadParameter(f"Compound {compound_id} not found")
    sdf_path = Path(row[0])

    run_id = uuid.uuid4().hex
    insert_run(conn, run_id, "pre_docking_enum", "dimorphite+rdkit", json.dumps({"compound_id": compound_id}), "running", "")
    if not _env_available(cfg, "dimorphite"):
        insert_decision(conn, "D-" + uuid.uuid4().hex[:12], run_id, compound_id, "skipped", "missing_env", json.dumps({"env": "dimorphite"}))
        finish_run(conn, run_id, "skipped")
        conn.commit()
        conn.close()
        typer.echo("Enumeration skipped: missing dimorphite env")
        return

    tmp_smi = cfg.runs_dir / f"{compound_id}_input.smi"
    tmp_smi.parent.mkdir(parents=True, exist_ok=True)
    script_smiles = _scripts_path(cfg, "rdkit_to_smiles.py")
    smiles = _run_in_env(cfg, "rdkit", ["python", str(script_smiles), "--input", str(sdf_path)])
    tmp_smi.write_text(smiles + "\n", encoding="utf-8")

    dimorphite_out = cfg.runs_dir / f"{compound_id}_dimorphite.smi"
    _run_in_env(
        cfg,
        "dimorphite",
        ["dimorphite_dl", str(tmp_smi), "--ph_min", str(ph_min), "--ph_max", str(ph_max), "--max_variants", str(max_variants), "--output_file", str(dimorphite_out)],
    )

    out_dir = cfg.objects_dir / "microstates" / compound_id
    ensure_dir(out_dir)

    script_enum = _scripts_path(cfg, "rdkit_enum_microstates.py")
    out_json = _run_in_env(
        cfg,
        "rdkit",
        [
            "python",
            str(script_enum),
            "--input-smiles-file",
            str(dimorphite_out),
            "--out-dir",
            str(out_dir),
            "--max-tautomers",
            str(max_tautomers),
            "--max-isomers",
            str(max_isomers),
        ],
    )
    data = json.loads(out_json)
    microstates = data.get("microstates", [])
    stats = data.get("stats", {}) if isinstance(data, dict) else {}
    try:
        n_ion = len([l for l in dimorphite_out.read_text(encoding="utf-8").splitlines() if l.strip()])
    except Exception:
        n_ion = 0
    if n_ion >= max_variants:
        insert_decision(
            conn,
            "D-" + uuid.uuid4().hex[:12],
            run_id,
            compound_id,
            "protonation_truncation",
            "max_variants",
            json.dumps({"n_variants": n_ion, "max_variants": max_variants}),
        )
    if stats.get("tautomer_truncated") or stats.get("stereo_truncated"):
        insert_decision(
            conn,
            "D-" + uuid.uuid4().hex[:12],
            run_id,
            compound_id,
            "enumeration_truncation",
            "max_limits",
            json.dumps(stats),
        )
    if stats.get("sanitize_failed"):
        insert_anomaly(
            conn,
            "AN-" + uuid.uuid4().hex[:12],
            run_id,
            compound_id,
            "sanitize_failed",
            json.dumps(stats),
        )

    selected = microstates
    decision = "keep_all"
    sel_cfg = policy.get("stages", {}).get("pre_docking_enum", {}).get("select_microstates", {})
    strategy = str(sel_cfg.get("strategy", "")).strip()
    k_cfg = int(sel_cfg.get("k", max_microstates)) if sel_cfg else max_microstates
    rank_features = sel_cfg.get("rank_features", []) if sel_cfg else []

    threshold = None
    if "keep_all_if_total<=" in strategy:
        try:
            tail = strategy.split("keep_all_if_total<=")[1]
            threshold = int(tail.split("_else_topk")[0])
        except Exception:
            threshold = None

    def rank_key(m: Dict[str, Any]) -> tuple:
        keys: List[float] = []
        for feat in rank_features:
            if feat == "formal_charge_distance_to_0":
                keys.append(abs(int(m.get("formal_charge", 0))))
            elif feat == "hbd_hba_balance":
                keys.append(abs(int(m.get("hbd", 0)) - int(m.get("hba", 0))))
            elif feat == "rdkit_score":
                keys.append(-float(m.get("rdkit_score", 0.0)))
        if not keys:
            keys.append(abs(int(m.get("formal_charge", 0))))
        return tuple(keys)

    if threshold is not None:
        if len(microstates) > threshold:
            k_eff = min(max_microstates, k_cfg) if k_cfg > 0 else max_microstates
            selected = sorted(microstates, key=rank_key)[:k_eff]
            decision = f"topk_by_rank_features:{k_eff}"
    elif len(microstates) > max_microstates:
        k_eff = min(max_microstates, k_cfg) if k_cfg > 0 else max_microstates
        selected = sorted(microstates, key=rank_key)[:k_eff]
        decision = f"topk_by_rank_features:{k_eff}"

        keep_ids = {m["microstate_id"] for m in selected}
        for m in microstates:
            if m["microstate_id"] not in keep_ids:
                mdir = out_dir / m["microstate_id"]
                if mdir.exists():
                    for p in mdir.rglob("*"):
                        if p.is_file():
                            p.unlink()
                    for p in sorted(mdir.rglob("*"), reverse=True):
                        if p.is_dir():
                            p.rmdir()


    dropped_ids = []
    if len(selected) < len(microstates):
        keep_ids = {m["microstate_id"] for m in selected}
        dropped_ids = [m["microstate_id"] for m in microstates if m["microstate_id"] not in keep_ids]

    protonation_groups: Dict[str, List[Dict[str, Any]]] = {}
    tautomer_groups: Dict[str, List[Dict[str, Any]]] = {}
    for m in selected:
        pkey = m.get("protonation_key", "")
        tkey = m.get("tautomer_key", "")
        if pkey:
            protonation_groups.setdefault(pkey, []).append(m)
        if tkey:
            tgroup = f"{tkey}|{int(m.get('formal_charge', 0))}"
            tautomer_groups.setdefault(tgroup, []).append(m)

    for m in selected:
        mid = m["microstate_id"]
        sdf_path_m = m["sdf_path"]
        insert_microstate(
            conn,
            mid,
            compound_id,
            m["fixedh_inchi"],
            int(m["formal_charge"]),
            m.get("stereo_tag", ""),
            m.get("coordination_sig", ""),
            sdf_path_m,
        )
        map_path = Path(m["atom_map_path"])
        insert_atom_map(conn, "MAP-" + mid, mid, json.dumps(read_json(map_path)))
        insert_edge(conn, "E-" + uuid.uuid4().hex[:12], compound_id, mid, "enumerated_from", run_id, "{}")

    for key, group in protonation_groups.items():
        if len(group) < 2:
            continue
        ids_in_group = sorted([m["microstate_id"] for m in group])
        for i in range(len(ids_in_group)):
            for j in range(i + 1, len(ids_in_group)):
                insert_edge(
                    conn,
                    "E-" + uuid.uuid4().hex[:12],
                    ids_in_group[i],
                    ids_in_group[j],
                    "protonation_of",
                    run_id,
                    json.dumps({"protonation_key": key}),
                )

    for key, group in tautomer_groups.items():
        if len(group) < 2:
            continue
        ids_in_group = sorted([m["microstate_id"] for m in group])
        for i in range(len(ids_in_group)):
            for j in range(i + 1, len(ids_in_group)):
                insert_edge(
                    conn,
                    "E-" + uuid.uuid4().hex[:12],
                    ids_in_group[i],
                    ids_in_group[j],
                    "tautomer_of",
                    run_id,
                    json.dumps({"tautomer_key": key}),
                )

    insert_decision(conn, "D-" + uuid.uuid4().hex[:12], run_id, compound_id, "select_microstates", decision, json.dumps({"kept": len(selected), "total": len(microstates), "strategy": strategy, "k": k_cfg, "rank_features": rank_features, "dropped_ids": dropped_ids}))

    finish_run(conn, run_id, "ok")
    conn.commit()
    conn.close()

    typer.echo(f"Generated {len(selected)} microstates (total {len(microstates)})")


@app.command()
def conformers(
    microstate_id: str = typer.Argument(..., help="Microstate ID"),
    method: str = typer.Option("rdkit", help="rdkit or peas"),
    n: int = typer.Option(50, help="Number of conformers"),
    prune_rmsd: float = typer.Option(0.5, help="RMSD pruning threshold"),
    topk: int = typer.Option(0, help="Select top-k conformers by energy (0 uses policy or keeps all)"),
    seed: int = typer.Option(-1, help="Random seed for ETKDG (-1 random)"),
    use_seer: bool = typer.Option(False, help="Run SEER scoring (PEAS mode only)"),
    seer_mode: str = typer.Option("pos", help="SEER mode: pos or neg"),
    use_ccsf: bool = typer.Option(False, help="Run CCSF focusing (PEAS mode only)"),
    ccsf_topk: int = typer.Option(0, help="Keep top-k by CCSF score (0 keeps all)"),
    experimental_ccs: float = typer.Option(0.0, help="Experimental CCS value (PEAS mode)"),
    config: Optional[Path] = typer.Option(None, "--config"),
):
    """Generate conformers for a microstate."""
    cfg_path = _resolve_config_path(config)
    cfg = load_config(cfg_path)
    policy = _load_policy(cfg.policy_path)

    if n <= 0:
        raise typer.BadParameter("--n must be > 0")
    max_n = 2000
    if n > max_n:
        raise typer.BadParameter(f"--n too large ({n}); max {max_n}. Use batch splitting for very large jobs.")
    if prune_rmsd < 0:
        raise typer.BadParameter("--prune-rmsd must be >= 0")
    if topk < 0:
        raise typer.BadParameter("--topk must be >= 0")
    if ccsf_topk < 0:
        raise typer.BadParameter("--ccsf-topk must be >= 0")

    conn = connect(cfg.ledger_db)
    row = conn.execute("SELECT sdf_path FROM microstates WHERE microstate_id = ?", (microstate_id,)).fetchone()
    if not row:
        raise typer.BadParameter(f"Microstate {microstate_id} not found")
    sdf_path = Path(row[0])

    # auto-enable PEAS based on policy enabled_if
    auto_decision = None
    if method == "rdkit":
        cg = policy.get("stages", {}).get("conformer_generation", {})
        methods = cg.get("method", [])
        peas_cfg = cg.get("peas", {}) if isinstance(cg, dict) else {}
        enabled_if = str(peas_cfg.get("enabled_if", "")).strip()
        if isinstance(methods, list) and "peas" in methods and enabled_if:
            rot_bonds = _rotbond_count(cfg, sdf_path)
            if _eval_enabled_if(enabled_if, rot_bonds):
                method = "peas"
                auto_decision = {
                    "enabled_if": enabled_if,
                    "rot_bonds": rot_bonds,
                    "selected": method,
                }

    run_id = uuid.uuid4().hex
    insert_run(conn, run_id, "conformer_generation", method, json.dumps({"microstate_id": microstate_id}), "running", "")
    if auto_decision:
        insert_decision(
            conn,
            "D-" + uuid.uuid4().hex[:12],
            run_id,
            microstate_id,
            "conformer_method",
            "enabled_if",
            json.dumps(auto_decision),
        )
    if method == "peas" and not _env_available(cfg, "peas"):
        insert_decision(conn, "D-" + uuid.uuid4().hex[:12], run_id, microstate_id, "skipped", "missing_env", json.dumps({"env": "peas"}))
        finish_run(conn, run_id, "skipped")
        conn.commit()
        conn.close()
        typer.echo("Conformer generation skipped: missing PEAS env")
        return

    out_dir = cfg.objects_dir / "conformers" / microstate_id
    ensure_dir(out_dir)

    cluster_used = False
    try:
        if method == "peas":
            script = _scripts_path(cfg, "peas_driver.py")
            out_json = _run_in_env(cfg, "peas", ["python", str(script), "--input", str(sdf_path), "--out-dir", str(out_dir), "--n", str(n), "--prune_rmsd", str(prune_rmsd), "--experimental-ccs", str(experimental_ccs)])
        else:
            script = _scripts_path(cfg, "rdkit_conformers.py")
            select_k = 0
            cluster_threshold = 0.0
            try:
                select_k = int(policy["stages"]["conformer_generation"]["select_conformers"]["k"])
            except Exception:
                select_k = 0
            try:
                by_list = policy["stages"]["conformer_generation"]["select_conformers"]["by"]
                if isinstance(by_list, list) and "diversity_cluster" in by_list:
                    cluster_threshold = float(prune_rmsd) if prune_rmsd > 0 else 0.5
                    cluster_used = True
            except Exception:
                pass
            cmd = ["python", str(script), "--input", str(sdf_path), "--out-dir", str(out_dir), "--n", str(n), "--prune_rmsd", str(prune_rmsd)]
            if select_k and select_k > 0:
                cmd += ["--select-k", str(select_k)]
            if cluster_threshold and cluster_threshold > 0:
                cmd += ["--cluster-threshold", str(cluster_threshold)]
            if seed is not None and seed >= 0:
                cmd += ["--seed", str(seed)]
            out_json = _run_in_env(cfg, "rdkit", cmd)

        data = json.loads(out_json)
        conformers = data.get("conformers", [])
        n_total = int(data.get("n_total", len(conformers)))
        n_selected = int(data.get("n_selected", len(conformers)))
        cluster_used = bool(data.get("cluster_used", cluster_used))
    except Exception as e:
        insert_anomaly(
            conn,
            "AN-" + uuid.uuid4().hex[:12],
            run_id,
            microstate_id,
            "conformer_generation_failed",
            json.dumps({"error": _short_error(e)}, ensure_ascii=False),
        )
        finish_run(conn, run_id, "failed")
        conn.commit()
        conn.close()
        raise typer.BadParameter(f"conformer generation failed: {_short_error(e)}") from e

    if topk <= 0:
        try:
            topk = int(policy["stages"]["conformer_generation"]["select_conformers"]["k"])
        except Exception:
            topk = 0

    if method == "rdkit" and topk and len(conformers) > topk:
        conformers = sorted(conformers, key=lambda c: float(c.get("energy", 0.0)))[:topk]
        n_selected = len(conformers)

    if method == "rdkit" and topk and n_total > n_selected:
        rationale = "topk_by_energy"
        if cluster_used:
            rationale = "topk_diversity_cluster"
        insert_decision(
            conn,
            "D-" + uuid.uuid4().hex[:12],
            run_id,
            microstate_id,
            "select_conformers",
            rationale,
            json.dumps({"topk": topk, "n_input": n_total, "n_selected": n_selected}),
        )

    if method == "peas" and use_seer:
        seer_path = cfg.runs_dir / f"{run_id}_seer.json"
        ensure_dir(seer_path.parent)
        script = _scripts_path(cfg, "seer_cli.py")
        _run_in_env(cfg, "seer", ["python", str(script), "--sdf", str(sdf_path), "--mode", seer_mode, "--out", str(seer_path)])
        insert_artifact(conn, ids.artifact_id(seer_path), "seer_report", str(seer_path), sha256_file(seer_path), run_id)

    if method == "peas" and use_ccsf and conformers:
        ccsf_path = cfg.runs_dir / f"{run_id}_ccsf.json"
        ensure_dir(ccsf_path.parent)
        ccsf_list = cfg.runs_dir / f"{run_id}_ccsf_list.txt"
        ccsf_list.write_text("\n".join([c["sdf_path"] for c in conformers]) + "\n", encoding="utf-8")
        script = _scripts_path(cfg, "ccsf_cli.py")
        _run_in_env(cfg, "ccsf", ["python", str(script), "--list", str(ccsf_list), "--out", str(ccsf_path)])
        ccsf_data = read_json(ccsf_path)
        scores = {row["sdf_path"]: row.get("ccs_pred") for row in ccsf_data.get("scores", [])}
        for c in conformers:
            c["ccsf_pred"] = scores.get(c["sdf_path"])
        insert_artifact(conn, ids.artifact_id(ccsf_path), "ccsf_scores", str(ccsf_path), sha256_file(ccsf_path), run_id)

        if ccsf_topk and ccsf_topk > 0:
            conformers = sorted(
                conformers,
                key=lambda c: (c.get("ccsf_pred") is None, float(c.get("ccsf_pred", 1e9))),
            )[:ccsf_topk]
            insert_decision(
                conn,
                "D-" + uuid.uuid4().hex[:12],
                run_id,
                microstate_id,
                "ccsf_select",
                "ccsf_topk",
                json.dumps({"topk": ccsf_topk, "n_input": len(scores), "n_selected": len(conformers)}),
            )

    for c in conformers:
        cid = ids.conformer_id(c["sdf_path"])
        insert_conformer(conn, cid, microstate_id, c["sdf_path"], float(c.get("energy", 0.0)))
        insert_edge(conn, "E-" + uuid.uuid4().hex[:12], microstate_id, cid, "conformer_of", run_id, "{}")

    finish_run(conn, run_id, "ok")
    conn.commit()
    conn.close()
    typer.echo(f"Generated {len(conformers)} conformers")


@app.command()
def dock_prep(
    microstate_id: str = typer.Argument(..., help="Microstate ID"),
    conformer_id: str = typer.Argument(..., help="Conformer ID"),
    config: Optional[Path] = typer.Option(None, "--config"),
):
    """Prepare docking PDBQT with Meeko and create atom mapping sidecar."""
    cfg_path = _resolve_config_path(config)
    cfg = load_config(cfg_path)
    conn = connect(cfg.ledger_db)
    row = conn.execute("SELECT sdf_path, microstate_id FROM conformers WHERE conformer_id = ?", (conformer_id,)).fetchone()
    if not row:
        raise typer.BadParameter(f"Conformer {conformer_id} not found")
    sdf_path = Path(row["sdf_path"])
    if str(row["microstate_id"]) != microstate_id:
        raise typer.BadParameter(f"Conformer {conformer_id} does not belong to microstate {microstate_id}")

    run_id = uuid.uuid4().hex
    insert_run(conn, run_id, "docking_prep", "meeko", json.dumps({"conformer_id": conformer_id}), "running", "")
    if not _env_available(cfg, "meeko"):
        insert_decision(conn, "D-" + uuid.uuid4().hex[:12], run_id, conformer_id, "skipped", "missing_env", json.dumps({"env": "meeko"}))
        finish_run(conn, run_id, "skipped")
        conn.commit()
        conn.close()
        typer.echo("Dock prep skipped: missing meeko env")
        return

    out_dir = cfg.objects_dir / "docking" / microstate_id / conformer_id
    ensure_dir(out_dir)
    pdbqt_path = out_dir / "ligand.pdbqt"

    _run_in_env(
        cfg,
        "meeko",
        ["mk_prepare_ligand.py", "-i", str(sdf_path), "-o", str(pdbqt_path)],
    )

    row_m = conn.execute("SELECT sdf_path FROM microstates WHERE microstate_id = ?", (microstate_id,)).fetchone()
    if not row_m:
        raise typer.BadParameter(f"Microstate {microstate_id} not found")
    map_path = Path(row_m[0]).parent / "atom_map.json"
    mapping = read_json(map_path)
    sidecar = None
    script = _scripts_path(cfg, "rdkit_map_pdbqt.py")
    try:
        out_json = _run_in_env(
            cfg,
            "rdkit",
            [
                "python",
                str(script),
                "--sdf",
                str(sdf_path),
                "--pdbqt",
                str(pdbqt_path),
                "--atom-map",
                str(map_path),
            ],
        )
        sidecar = json.loads(out_json)
        for entry in sidecar:
            entry.setdefault("atom_name", "")
            entry.setdefault("element", "")
            entry.setdefault("atom_type", "")
            entry.setdefault("match_distance", None)
            entry.setdefault("element_match", None)
    except Exception:
        sidecar = []
        heavy_entries = [e for e in mapping if str(e.get("symbol", "")).upper() != "H"]
        heavy_lookup = {e["atom_index"]: i + 1 for i, e in enumerate(heavy_entries)}
        for entry in mapping:
            pdbqt_idx = heavy_lookup.get(entry["atom_index"])
            sidecar.append(
                {
                    "canonical_atom_id": entry["canonical_atom_id"],
                    "atom_index": entry["atom_index"],
                    "symbol": entry.get("symbol", ""),
                    "pdbqt_atom_index": pdbqt_idx,
                    "present_in_pdbqt": pdbqt_idx is not None,
                }
            )
    sidecar_path = out_dir / "ligand.map.json"
    write_json(sidecar_path, sidecar)

    finish_run(conn, run_id, "ok")
    conn.commit()
    conn.close()
    typer.echo(str(pdbqt_path))


@app.command()
def dock_ingest(
    conformer_id: str = typer.Argument(..., help="Conformer ID"),
    pdbqt_path: str = typer.Argument(..., help="Docking pose PDBQT"),
    score: float = typer.Option(0.0, help="Docking score"),
    receptor_path: str = typer.Option("", help="Optional receptor structure file (PDB/PDBQT)"),
    receptor_name: str = typer.Option("", help="Optional receptor name"),
    tool: str = typer.Option("vina", help="Docking engine"),
    params_json: str = typer.Option("", help="Optional docking params JSON"),
    config: Optional[Path] = typer.Option(None, "--config"),
):
    """Ingest docking results and register pose."""
    cfg_path = _resolve_config_path(config)
    cfg = load_config(cfg_path)
    conn = connect(cfg.ledger_db)
    row = conn.execute("SELECT sdf_path, microstate_id FROM conformers WHERE conformer_id = ?", (conformer_id,)).fetchone()
    if not row:
        raise typer.BadParameter(f"Conformer {conformer_id} not found")

    pose_path = Path(pdbqt_path)
    if not pose_path.exists():
        raise typer.BadParameter(f"Pose file not found: {pdbqt_path}")
    if receptor_path and not Path(receptor_path).exists():
        raise typer.BadParameter(f"Receptor file not found: {receptor_path}")

    def _count_pose_atoms(path: Path) -> tuple[int, int]:
        total = 0
        heavy = 0
        saw_model = False
        in_model = False
        with path.open("r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                if line.startswith("MODEL"):
                    saw_model = True
                    in_model = True
                    continue
                if saw_model and line.startswith("ENDMDL"):
                    break
                if line.startswith(("ATOM", "HETATM")) and ((not saw_model) or in_model):
                    total += 1
                    parts = line.split()
                    atom_type = parts[-1].upper() if parts else ""
                    if not atom_type.startswith("H"):
                        heavy += 1
        return total, heavy

    expected_map = cfg.objects_dir / "docking" / str(row["microstate_id"]) / conformer_id / "ligand.map.json"
    if expected_map.exists():
        try:
            m = read_json(expected_map)
            expected_heavy = sum(
                1
                for e in m
                if bool(e.get("present_in_pdbqt", True)) and str(e.get("symbol", "")).upper() != "H"
            )
        except Exception:
            expected_heavy = 0
        pose_atoms_total, pose_atoms_heavy = _count_pose_atoms(pose_path)
        if expected_heavy and pose_atoms_heavy != expected_heavy:
            raise typer.BadParameter(
                f"Pose/conformer atom mismatch for {conformer_id}: expected {expected_heavy} heavy atoms from ligand map, got {pose_atoms_heavy} heavy atoms ({pose_atoms_total} total) in pose"
            )

    run_id = uuid.uuid4().hex
    run_params = {"conformer_id": conformer_id, "pdbqt": pdbqt_path, "score": score}
    if params_json:
        try:
            run_params["params"] = json.loads(params_json)
        except Exception:
            run_params["params_raw"] = params_json
    insert_run(conn, run_id, "docking", tool, json.dumps(run_params), "running", "")

    pose_id = ids.pose_id(pdbqt_path)
    insert_pose(conn, pose_id, conformer_id, pdbqt_path, float(score))
    edge_params = {"score": score}
    if params_json:
        edge_params.update(run_params.get("params", {}))
    insert_edge(conn, "E-" + uuid.uuid4().hex[:12], conformer_id, pose_id, "pose_of", run_id, json.dumps(edge_params))
    insert_artifact(conn, ids.artifact_id(pdbqt_path), "docking_pose", pdbqt_path, sha256_file(pdbqt_path), run_id)

    if receptor_path:
        rec_id = ids.receptor_id(receptor_path)
        insert_receptor(conn, rec_id, receptor_name, receptor_path)
        insert_artifact(conn, ids.artifact_id(receptor_path), "receptor", receptor_path, sha256_file(receptor_path), run_id)
        insert_edge(conn, "E-" + uuid.uuid4().hex[:12], pose_id, rec_id, "pose_in", run_id, "{}")

    finish_run(conn, run_id, "ok")
    conn.commit()
    conn.close()
    typer.echo(pose_id)


@app.command()
def receptor_add(
    receptor_path: str = typer.Argument(..., help="Receptor structure file"),
    name: str = typer.Option("", help="Receptor name"),
    config: Optional[Path] = typer.Option(None, "--config"),
):
    """Register receptor structure."""
    cfg_path = _resolve_config_path(config)
    cfg = load_config(cfg_path)
    receptor_file = Path(receptor_path)
    if not receptor_file.exists():
        raise typer.BadParameter(f"Receptor file not found: {receptor_path}")
    try:
        text = receptor_file.read_text(encoding="utf-8", errors="ignore")
    except Exception as e:
        raise typer.BadParameter(f"Cannot read receptor file: {receptor_path}") from e
    if not any(line.startswith(("ATOM", "HETATM", "REMARK")) for line in text.splitlines()[:200]):
        raise typer.BadParameter(
            f"Receptor format appears invalid (expected PDB/PDBQT ATOM/HETATM records): {receptor_path}"
        )

    conn = connect(cfg.ledger_db)
    run_id = uuid.uuid4().hex
    insert_run(conn, run_id, "receptor_register", "msl", json.dumps({"path": receptor_path, "name": name}), "running", "")
    rec_id = ids.receptor_id(receptor_path)
    insert_receptor(conn, rec_id, name, receptor_path)
    insert_artifact(conn, ids.artifact_id(receptor_path), "receptor", receptor_path, sha256_file(receptor_path), run_id)
    finish_run(conn, run_id, "ok")
    conn.commit()
    conn.close()
    typer.echo(rec_id)


@app.command()
def dock_select(
    microstate_id: str = typer.Argument(..., help="Microstate ID"),
    k: int = typer.Option(20, help="Top-k poses to keep by score"),
    by: str = typer.Option("", help="Comma-separated ranking features (score,strain_energy,charge_quality)"),
    config: Optional[Path] = typer.Option(None, "--config"),
):
    """Select top-k docking poses for a microstate and record decision."""
    cfg_path = _resolve_config_path(config)
    cfg = load_config(cfg_path)
    policy = _load_policy(cfg.policy_path)
    if k <= 0:
        raise typer.BadParameter("--k must be > 0")
    conn = connect(cfg.ledger_db)
    rows = conn.execute(
        """
        SELECT poses.pose_id, poses.score, poses.conformer_id
        FROM poses
        JOIN conformers ON poses.conformer_id = conformers.conformer_id
        WHERE conformers.microstate_id = ?
        """,
        (microstate_id,),
    ).fetchall()
    if not rows:
        raise typer.BadParameter(f"No poses found for microstate {microstate_id}")

    if by:
        rank_features = [b.strip() for b in by.split(",") if b.strip()]
    else:
        try:
            rank_features = policy["stages"]["docking"]["select_poses"]["by"]
        except Exception:
            rank_features = ["vina_score"]

    charge_quality = 2
    for row in conn.execute(
        "SELECT kind FROM artifacts WHERE path LIKE ?",
        (f"%/microstates/%/{microstate_id}/charges/%/charges.json",),
    ).fetchall():
        kind = row["kind"]
        if "pype_resp" in kind:
            charge_quality = 0
            break
        if "gasteiger" in kind:
            charge_quality = min(charge_quality, 1)

    conformer_energy = {}
    for row in conn.execute("SELECT conformer_id, energy FROM conformers WHERE microstate_id = ?", (microstate_id,)).fetchall():
        conformer_energy[row["conformer_id"]] = float(row["energy"] or 0.0)

    def rank_key(row):
        keys = []
        for feat in rank_features:
            if feat in ("vina_score", "dock_score", "score"):
                keys.append(float(row["score"] or 0.0))
            elif feat == "strain_energy":
                keys.append(float(conformer_energy.get(row["conformer_id"], 0.0)))
            elif feat == "charge_quality":
                keys.append(float(charge_quality))
        if not keys:
            keys.append(float(row["score"] or 0.0))
        return tuple(keys)

    rows_sorted = sorted(rows, key=lambda r: (*rank_key(r), str(r["pose_id"])))
    selected = [row["pose_id"] for row in rows_sorted[:k]]
    run_id = uuid.uuid4().hex
    insert_run(conn, run_id, "docking_select", "msl", json.dumps({"microstate_id": microstate_id, "k": k}), "running", "")
    insert_decision(
        conn,
        "D-" + uuid.uuid4().hex[:12],
        run_id,
        microstate_id,
        "select_poses",
        "topk_multi_metric",
        json.dumps({"k": k, "selected": selected, "n_total": len(rows), "by": rank_features}),
    )
    for pose_id in selected:
        insert_edge(conn, "E-" + uuid.uuid4().hex[:12], microstate_id, pose_id, "pose_selected", run_id, "{}")
    finish_run(conn, run_id, "ok")
    conn.commit()
    conn.close()
    typer.echo(json.dumps({"selected": selected}, ensure_ascii=False, indent=2))


@app.command()
def select_final(
    microstate_id: str = typer.Argument(..., help="Microstate ID"),
    pose_id: str = typer.Option("", help="Optional pose ID"),
    rationale: str = typer.Option("manual_select", help="Selection rationale"),
    config: Optional[Path] = typer.Option(None, "--config"),
):
    """Record final microstate selection for MD."""
    cfg_path = _resolve_config_path(config)
    cfg = load_config(cfg_path)
    conn = connect(cfg.ledger_db)
    row = conn.execute("SELECT microstate_id FROM microstates WHERE microstate_id = ?", (microstate_id,)).fetchone()
    if not row:
        raise typer.BadParameter(f"Microstate {microstate_id} not found")
    if pose_id:
        pose_row = conn.execute(
            """
            SELECT 1
            FROM poses
            JOIN conformers ON poses.conformer_id = conformers.conformer_id
            WHERE poses.pose_id = ? AND conformers.microstate_id = ?
            """,
            (pose_id, microstate_id),
        ).fetchone()
        if not pose_row:
            raise typer.BadParameter(f"Pose {pose_id} does not belong to microstate {microstate_id}")
    run_id = uuid.uuid4().hex
    insert_run(conn, run_id, "select_final", "msl", json.dumps({"microstate_id": microstate_id, "pose_id": pose_id}), "running", "")
    insert_decision(
        conn,
        "D-" + uuid.uuid4().hex[:12],
        run_id,
        microstate_id,
        "select_final",
        rationale,
        json.dumps({"pose_id": pose_id} if pose_id else {}),
    )
    finish_run(conn, run_id, "ok")
    conn.commit()
    conn.close()
    typer.echo(microstate_id)


@app.command()
def charge(
    microstate_id: str = typer.Argument(..., help="Microstate ID"),
    method: str = typer.Option("gasteiger", help="gasteiger|resp|pype_resp"),
    charges_json: str = typer.Option("", help="Charges JSON to import"),
    mol2: str = typer.Option("", help="Mol2 file with charges"),
    resp_input: str = typer.Option("", help="PyRESP input file"),
    espot: str = typer.Option("", help="ESP grid file for PyRESP"),
    qin: str = typer.Option("", help="Optional qin file for PyRESP"),
    polariz: str = typer.Option("", help="Optional polariz file for PyRESP"),
    auto_qm: bool = typer.Option(False, "--auto-qm", help="Run light QM (SQM) to generate ESP and RESP inputs"),
    qm_theory: str = typer.Option("PM6", help="SQM theory (PM6/PM3/etc.)"),
    qm_engine: str = typer.Option("sqm", help="QM engine for auto-qm (sqm|psi4|orca|auto)"),
    multiplicity: int = typer.Option(1, help="Spin multiplicity for QM"),
    points_per_atom: int = typer.Option(120, help="ESP grid points per atom"),
    probe: float = typer.Option(1.4, help="Probe radius for ESP surface"),
    conformer_id: str = typer.Option("", help="Optional conformer ID for QM geometry"),
    config: Optional[Path] = typer.Option(None, "--config"),
):
    """Generate or import per-atom charges and register artifact."""
    cfg_path = _resolve_config_path(config)
    cfg = load_config(cfg_path)
    method = method.strip().lower()
    if method == "resp":
        raise typer.BadParameter("--method resp is not supported; use --method pype_resp")
    if method not in {"gasteiger", "pype_resp"}:
        raise typer.BadParameter("--method must be one of: gasteiger, pype_resp")

    conn = connect(cfg.ledger_db)
    row = conn.execute("SELECT sdf_path FROM microstates WHERE microstate_id = ?", (microstate_id,)).fetchone()
    if not row:
        raise typer.BadParameter(f"Microstate {microstate_id} not found")
    sdf_path = Path(row[0])

    run_id = uuid.uuid4().hex
    insert_run(conn, run_id, "pre_md_charge", method, json.dumps({"microstate_id": microstate_id}), "running", "")
    if method == "pype_resp" and not _env_available(cfg, "pype_resp"):
        insert_decision(conn, "D-" + uuid.uuid4().hex[:12], run_id, microstate_id, "skipped", "missing_env", json.dumps({"env": "pype_resp"}))
        finish_run(conn, run_id, "skipped")
        conn.commit()
        conn.close()
        typer.echo("Charge skipped: missing pype_resp env")
        return

    if method == "gasteiger" and not charges_json and not mol2 and not _env_available(cfg, "rdkit"):
        insert_decision(conn, "D-" + uuid.uuid4().hex[:12], run_id, microstate_id, "skipped", "missing_env", json.dumps({"env": "rdkit"}))
        finish_run(conn, run_id, "skipped")
        conn.commit()
        conn.close()
        typer.echo("Charge skipped: missing rdkit env")
        return

    map_path = sdf_path.parent / "atom_map.json"
    out_dir = sdf_path.parent / "charges" / method
    ensure_dir(out_dir)
    out_charges = out_dir / "charges.json"

    if charges_json:
        data = read_json(charges_json)
        charges = data.get("charges", data) if isinstance(data, dict) else data
    elif mol2:
        script = _scripts_path(cfg, "mol2_to_charges.py")
        out_json = run_cmd(["python", str(script), "--mol2", mol2, "--atom-map", str(map_path)])
        charges = json.loads(out_json)
    elif method == "pype_resp" and auto_qm:
        row_charge = conn.execute("SELECT formal_charge FROM microstates WHERE microstate_id = ?", (microstate_id,)).fetchone()
        formal_charge = int(row_charge[0]) if row_charge else 0
        sdf_in = sdf_path
        if conformer_id:
            row_c = conn.execute("SELECT sdf_path FROM conformers WHERE conformer_id = ?", (conformer_id,)).fetchone()
            if not row_c:
                raise typer.BadParameter(f"Conformer {conformer_id} not found")
            sdf_in = Path(row_c[0])
        script = _scripts_path(cfg, "pype_resp_auto.py")
        qm_engine_eff = qm_engine.lower()
        qm_theory_eff = qm_theory.strip()
        # Keep auto mode neutral here; the helper script decides final engine and
        # can safely map theory after auto-detection.
        if qm_engine_eff in {"psi4", "orca"} and qm_theory_eff.upper() == "PM6":
            qm_theory_eff = "HF/6-31G*"
        cmd = [
            "python",
            str(script),
            "--sdf",
            str(sdf_in),
            "--out-dir",
            str(out_dir),
            "--atom-map",
            str(map_path),
            "--charge",
            str(formal_charge),
            "--qm-theory",
            qm_theory_eff,
            "--qm-engine",
            qm_engine_eff,
            "--multiplicity",
            str(multiplicity),
            "--points-per-atom",
            str(points_per_atom),
            "--probe",
            str(probe),
        ]
        out_json = _run_in_env(cfg, "pype_resp", cmd)
        charges = json.loads(out_json)
    elif method == "pype_resp":
        if not resp_input or not espot:
            raise typer.BadParameter("pype_resp requires --resp-input and --espot (or use --auto-qm)")
        script = _scripts_path(cfg, "pype_resp_run.py")
        cmd = ["python", str(script), "--resp-input", resp_input, "--espot", espot, "--out-dir", str(out_dir), "--atom-map", str(map_path)]
        if qin:
            cmd += ["--qin", qin]
        if polariz:
            cmd += ["--polariz", polariz]
        out_json = _run_in_env(cfg, "pype_resp", cmd)
        charges = json.loads(out_json)
    else:
        if method not in {"gasteiger"}:
            raise typer.BadParameter("charges_json or mol2 is required for method != gasteiger")
        script = _scripts_path(cfg, "rdkit_gasteiger.py")
        out_json = _run_in_env(cfg, "rdkit", ["python", str(script), "--sdf", str(sdf_path), "--atom-map", str(map_path)])
        charges = json.loads(out_json)

    write_json(out_charges, charges)
    insert_artifact(conn, ids.artifact_id(out_charges), f"charges_{method}", str(out_charges), sha256_file(out_charges), run_id)
    if method == "pype_resp":
        for pth, kind in [
            (out_dir / "resp.espot", "pype_resp_espot"),
            (out_dir / "resp1.in", "pype_resp_input1"),
            (out_dir / "resp1.out", "pype_resp_out1"),
            (out_dir / "resp1.chg", "pype_resp_qout1"),
            (out_dir / "resp2.in", "pype_resp_input2"),
            (out_dir / "resp2.out", "pype_resp_out2"),
            (out_dir / "resp2.chg", "pype_resp_qout2"),
            (out_dir / "sqm.in", "sqm_in"),
            (out_dir / "sqm.out", "sqm_out"),
            (out_dir / "psi4.out", "psi4_out"),
            (out_dir / "orca.inp", "orca_inp"),
            (out_dir / "orca.out", "orca_out"),
            (out_dir / "orca.gbw", "orca_gbw"),
            (out_dir / "orca_esp.txt", "orca_esp"),
            (out_dir / "esp_points.txt", "esp_points"),
        ]:
            if pth.exists():
                insert_artifact(conn, ids.artifact_id(pth), kind, str(pth), sha256_file(pth), run_id)
    insert_edge(conn, "E-" + uuid.uuid4().hex[:12], microstate_id, ids.artifact_id(out_charges), "charges_of", run_id, json.dumps({"method": method}))

    finish_run(conn, run_id, "ok")
    conn.commit()
    conn.close()
    typer.echo(str(out_charges))


@app.command()
def md_param(
    microstate_id: str = typer.Argument(..., help="Microstate ID"),
    forcefield: str = typer.Option("openff-2.1.0.offxml", help="OpenFF forcefield"),
    charges_json: str = typer.Option("", help="Optional charges JSON"),
    config: Optional[Path] = typer.Option(None, "--config"),
):
    """Parameterize MD system with OpenFF Interchange (base)."""
    cfg_path = _resolve_config_path(config)
    cfg = load_config(cfg_path)
    conn = connect(cfg.ledger_db)
    row = conn.execute("SELECT sdf_path FROM microstates WHERE microstate_id = ?", (microstate_id,)).fetchone()
    if not row:
        raise typer.BadParameter(f"Microstate {microstate_id} not found")
    sdf_path = Path(row[0])

    run_id = uuid.uuid4().hex
    insert_run(conn, run_id, "pre_md", "openff_interchange", json.dumps({"microstate_id": microstate_id}), "running", "")
    if not _env_available(cfg, "openff"):
        insert_decision(conn, "D-" + uuid.uuid4().hex[:12], run_id, microstate_id, "skipped", "missing_env", json.dumps({"env": "openff"}))
        finish_run(conn, run_id, "skipped")
        conn.commit()
        conn.close()
        typer.echo("MD param skipped: missing openff env")
        return

    script_map = _scripts_path(cfg, "rdkit_to_mapped_smiles.py")
    mapped_smiles = _run_in_env(cfg, "rdkit", ["python", str(script_map), "--input", str(sdf_path)])

    out_dir = cfg.objects_dir / "md" / microstate_id
    ensure_dir(out_dir)

    def _load_charge_map(path: Path) -> Dict[int, float]:
        data = read_json(path)
        if isinstance(data, dict):
            data = data.get("charges", data)
        if not isinstance(data, list):
            raise typer.BadParameter(f"Invalid charges JSON format: {path}")
        charge_map: Dict[int, float] = {}
        for idx, row in enumerate(data):
            if not isinstance(row, dict) or "canonical_atom_id" not in row or "charge" not in row:
                raise typer.BadParameter(f"Invalid charge row at index {idx} in {path}")
            cid = int(row["canonical_atom_id"])
            if cid in charge_map:
                raise typer.BadParameter(f"Duplicate canonical_atom_id {cid} in {path}")
            charge_map[cid] = float(row["charge"])
        return charge_map

    def _load_atom_ids(path: Path) -> set[int]:
        data = read_json(path)
        if not isinstance(data, list):
            raise typer.BadParameter(f"Invalid atom map format: {path}")
        ids_set: set[int] = set()
        for idx, row in enumerate(data):
            if not isinstance(row, dict) or "canonical_atom_id" not in row:
                raise typer.BadParameter(f"Invalid atom map row at index {idx} in {path}")
            cid = int(row["canonical_atom_id"])
            if cid in ids_set:
                raise typer.BadParameter(f"Duplicate canonical_atom_id {cid} in atom map {path}")
            ids_set.add(cid)
        return ids_set

    if not charges_json:
        mdir = sdf_path.parent
        candidates = [
            mdir / "charges" / "pype_resp" / "charges.json",
            mdir / "charges" / "RESP" / "charges.json",
            mdir / "charges" / "gasteiger" / "charges.json",
        ]
        for cand in candidates:
            if cand.exists():
                charges_json = str(cand)
                break

    if charges_json:
        charge_path = Path(charges_json)
        if not charge_path.exists():
            raise typer.BadParameter(f"Charges JSON not found: {charges_json}")
        atom_map_path = sdf_path.parent / "atom_map.json"
        if not atom_map_path.exists():
            raise typer.BadParameter(
                f"Atom map not found for microstate {microstate_id}: {atom_map_path}"
            )
        charge_ids = set(_load_charge_map(charge_path).keys())
        atom_ids = _load_atom_ids(atom_map_path)
        if charge_ids != atom_ids:
            only_charge = sorted(charge_ids - atom_ids)
            only_atom = sorted(atom_ids - charge_ids)
            raise typer.BadParameter(
                f"charges atom-id mismatch; only in charges: {only_charge[:10]} only in atom_map: {only_atom[:10]}"
            )
        charges_json = str(charge_path)

    script_openff = _scripts_path(cfg, "openff_interchange.py")
    cmd = ["python", str(script_openff), "--mapped-smiles", mapped_smiles, "--sdf", str(sdf_path), "--out-dir", str(out_dir), "--forcefield", forcefield]
    if charges_json:
        cmd += ["--charges", charges_json]
    out_json = _run_in_env(cfg, "openff", cmd)

    try:
        out_data = json.loads(out_json)
        system_xml = out_data.get("system_xml", "")
        if system_xml:
            system_id = "S-" + sha256_file(system_xml)[:12]
            insert_system(conn, system_id, microstate_id, "openmm", system_xml)
            insert_artifact(conn, ids.artifact_id(system_xml), "openmm_system", system_xml, sha256_file(system_xml), run_id)

        system_pdb = out_data.get("system_pdb", "")
        if system_pdb:
            insert_artifact(conn, ids.artifact_id(system_pdb), "system_pdb", system_pdb, sha256_file(system_pdb), run_id)

        atommap = out_data.get("atommap", "")
        if atommap:
            insert_artifact(conn, ids.artifact_id(atommap), "atommap", atommap, sha256_file(atommap), run_id)
        openmm_map = out_data.get("openmm_map", "")
        if openmm_map:
            insert_artifact(conn, ids.artifact_id(openmm_map), "openmm_map", openmm_map, sha256_file(openmm_map), run_id)
        gromacs_map = out_data.get("gromacs_map", "")
        if gromacs_map:
            insert_artifact(conn, ids.artifact_id(gromacs_map), "gromacs_map", gromacs_map, sha256_file(gromacs_map), run_id)
        amber_map = out_data.get("amber_map", "")
        if amber_map:
            insert_artifact(conn, ids.artifact_id(amber_map), "amber_map", amber_map, sha256_file(amber_map), run_id)

        gromacs_top = out_data.get("gromacs_top", "")
        gromacs_gro = out_data.get("gromacs_gro", "")
        if gromacs_top:
            system_id = "S-" + sha256_file(gromacs_top)[:12]
            insert_system(conn, system_id, microstate_id, "gromacs", gromacs_top)
            insert_artifact(conn, ids.artifact_id(gromacs_top), "gromacs_top", gromacs_top, sha256_file(gromacs_top), run_id)
        if gromacs_gro:
            insert_artifact(conn, ids.artifact_id(gromacs_gro), "gromacs_gro", gromacs_gro, sha256_file(gromacs_gro), run_id)

        amber_prmtop = out_data.get("amber_prmtop", "")
        amber_inpcrd = out_data.get("amber_inpcrd", "")
        if amber_prmtop:
            system_id = "S-" + sha256_file(amber_prmtop)[:12]
            insert_system(conn, system_id, microstate_id, "amber", amber_prmtop)
            insert_artifact(conn, ids.artifact_id(amber_prmtop), "amber_prmtop", amber_prmtop, sha256_file(amber_prmtop), run_id)
        if amber_inpcrd:
            insert_artifact(conn, ids.artifact_id(amber_inpcrd), "amber_inpcrd", amber_inpcrd, sha256_file(amber_inpcrd), run_id)
    except Exception:
        pass

    finish_run(conn, run_id, "ok")
    conn.commit()
    conn.close()
    typer.echo(out_json)


@app.command()
def md_feedback(
    microstate_id: str = typer.Argument(..., help="Microstate ID"),
    probe_sdf: str = typer.Argument(..., help="Probe SDF from MD snapshot"),
    map_json: str = typer.Option("", help="Optional atom map JSON from MD engine"),
    config: Optional[Path] = typer.Option(None, "--config"),
):
    """Check MD snapshot for chirality or stereo changes and register anomalies."""
    cfg_path = _resolve_config_path(config)
    cfg = load_config(cfg_path)
    if not Path(probe_sdf).exists():
        raise typer.BadParameter(f"Probe SDF not found: {probe_sdf}")
    if map_json and not Path(map_json).exists():
        raise typer.BadParameter(f"Map JSON not found: {map_json}")

    conn = connect(cfg.ledger_db)
    row = conn.execute("SELECT sdf_path FROM microstates WHERE microstate_id = ?", (microstate_id,)).fetchone()
    if not row:
        raise typer.BadParameter(f"Microstate {microstate_id} not found")
    ref_sdf = Path(row[0])

    run_id = uuid.uuid4().hex
    insert_run(conn, run_id, "md_feedback", "rdkit", json.dumps({"microstate_id": microstate_id, "probe": probe_sdf}), "running", "")

    script = _scripts_path(cfg, "md_feedback.py")
    cmd = ["python", str(script), "--ref", str(ref_sdf), "--probe", probe_sdf]
    if map_json:
        cmd += ["--map-json", map_json]
    out_json = _run_in_env(cfg, "rdkit", cmd)
    report = json.loads(out_json)

    report_dir = cfg.reports_dir / microstate_id
    ensure_dir(report_dir)
    report_path = report_dir / "md_feedback.json"
    write_json(report_path, report)

    insert_artifact(conn, ids.artifact_id(report_path), "md_feedback", str(report_path), sha256_file(report_path), run_id)

    chirality_changes = report.get("chirality_changes") or []
    double_bond_changes = report.get("double_bond_changes") or []
    formula_changed = bool((report.get("formula_change") or {}).get("changed")) if isinstance(report.get("formula_change"), dict) else False
    recommendations = report.get("recommendations") if isinstance(report.get("recommendations"), list) else []

    def _rec_for(rec_type: str) -> list[dict]:
        return [r for r in recommendations if isinstance(r, dict) and r.get("type") == rec_type]

    if chirality_changes:
        insert_anomaly(
            conn,
            "AN-" + uuid.uuid4().hex[:12],
            run_id,
            microstate_id,
            "chirality_change",
            json.dumps({
                "changes": chirality_changes,
                "recommendations": _rec_for("lock_chirality"),
            }),
        )
    if double_bond_changes:
        insert_anomaly(
            conn,
            "AN-" + uuid.uuid4().hex[:12],
            run_id,
            microstate_id,
            "double_bond_change",
            json.dumps({
                "changes": double_bond_changes,
                "recommendations": _rec_for("lock_double_bond"),
            }),
        )
    if formula_changed:
        insert_anomaly(
            conn,
            "AN-" + uuid.uuid4().hex[:12],
            run_id,
            microstate_id,
            "formula_change",
            json.dumps({
                "formula_change": report.get("formula_change"),
                "recommendations": _rec_for("formula_change"),
            }),
        )

    finish_run(conn, run_id, "ok")
    conn.commit()
    conn.close()
    typer.echo(str(report_path))


@app.command()
def md_transition(
    microstate_id: str = typer.Argument(..., help="Reference Microstate ID"),
    probe_sdf: str = typer.Argument(..., help="Probe SDF from MD snapshot"),
    config: Optional[Path] = typer.Option(None, "--config"),
):
    """Register observed microstate transition from MD snapshot."""
    cfg_path = _resolve_config_path(config)
    cfg = load_config(cfg_path)
    if not Path(probe_sdf).exists():
        raise typer.BadParameter(f"Probe SDF not found: {probe_sdf}")

    conn = connect(cfg.ledger_db)
    row = conn.execute("SELECT compound_id FROM microstates WHERE microstate_id = ?", (microstate_id,)).fetchone()
    if not row:
        raise typer.BadParameter(f"Microstate {microstate_id} not found")
    compound_id = row[0]

    run_id = uuid.uuid4().hex
    insert_run(conn, run_id, "md_transition", "rdkit", json.dumps({"microstate_id": microstate_id, "probe": probe_sdf}), "running", "")

    out_dir = cfg.objects_dir / "microstates" / compound_id / "probe_tmp"
    ensure_dir(out_dir)
    script = _scripts_path(cfg, "rdkit_probe_microstate.py")
    out_json = _run_in_env(cfg, "rdkit", ["python", str(script), "--probe", probe_sdf, "--out-dir", str(out_dir)])
    data = json.loads(out_json)

    new_mid = data["microstate_id"]
    if new_mid == microstate_id:
        try:
            for p in sorted(out_dir.rglob("*"), reverse=True):
                if p.is_file():
                    p.unlink()
            for p in sorted(out_dir.rglob("*"), reverse=True):
                if p.is_dir():
                    p.rmdir()
            if out_dir.exists():
                out_dir.rmdir()
        except Exception:
            pass
        insert_decision(
            conn,
            "D-" + uuid.uuid4().hex[:12],
            run_id,
            microstate_id,
            "md_transition",
            "no_transition",
            json.dumps({"probe": probe_sdf}),
        )
        finish_run(conn, run_id, "ok")
        conn.commit()
        conn.close()
        typer.echo(microstate_id)
        return

    final_dir = cfg.objects_dir / "microstates" / compound_id / new_mid
    ensure_dir(final_dir)
    # move generated files into final dir
    for name in ("microstate.sdf", "atom_map.json"):
        src = out_dir / name
        if src.exists():
            src.replace(final_dir / name)
    try:
        out_dir.rmdir()
    except Exception:
        pass

    insert_microstate(
        conn,
        new_mid,
        compound_id,
        data["fixedh_inchi"],
        int(data["formal_charge"]),
        data.get("stereo_tag", ""),
        data.get("coordination_sig", ""),
        str(final_dir / "microstate.sdf"),
    )
    insert_atom_map(conn, "MAP-" + new_mid, new_mid, json.dumps(read_json(final_dir / "atom_map.json")))

    insert_edge(conn, "E-" + uuid.uuid4().hex[:12], microstate_id, new_mid, "observed_transition", run_id, "{}")
    insert_artifact(conn, ids.artifact_id(probe_sdf), "md_probe", probe_sdf, sha256_file(probe_sdf), run_id)

    finish_run(conn, run_id, "ok")
    conn.commit()
    conn.close()
    typer.echo(new_mid)


@app.command()
def diff_microstate(
    microstate_a: str = typer.Argument(...),
    microstate_b: str = typer.Argument(...),
    config: Optional[Path] = typer.Option(None, "--config"),
):
    """Diff two microstates (chemistry-level)."""
    cfg_path = _resolve_config_path(config)
    cfg = load_config(cfg_path)
    conn = connect(cfg.ledger_db)
    row_a = conn.execute("SELECT sdf_path FROM microstates WHERE microstate_id = ?", (microstate_a,)).fetchone()
    row_b = conn.execute("SELECT sdf_path FROM microstates WHERE microstate_id = ?", (microstate_b,)).fetchone()
    if not row_a or not row_b:
        raise typer.BadParameter("Microstate not found")

    script = _scripts_path(cfg, "rdkit_diff.py")
    out = _run_in_env(cfg, "rdkit", ["python", str(script), "--a", str(row_a[0]), "--b", str(row_b[0])])
    typer.echo(out)


@app.command()
def diff_conformer(
    conformer_a: str = typer.Argument(...),
    conformer_b: str = typer.Argument(...),
    config: Optional[Path] = typer.Option(None, "--config"),
):
    """Diff two conformers (RMSD + torsions)."""
    cfg_path = _resolve_config_path(config)
    cfg = load_config(cfg_path)
    conn = connect(cfg.ledger_db)
    row_a = conn.execute("SELECT sdf_path FROM conformers WHERE conformer_id = ?", (conformer_a,)).fetchone()
    row_b = conn.execute("SELECT sdf_path FROM conformers WHERE conformer_id = ?", (conformer_b,)).fetchone()
    if not row_a or not row_b:
        raise typer.BadParameter("Conformer not found")

    script = _scripts_path(cfg, "rdkit_conf_diff.py")
    out = _run_in_env(cfg, "rdkit", ["python", str(script), "--a", str(row_a[0]), "--b", str(row_b[0])])
    typer.echo(out)


@app.command()
def diff_charge(
    charge_a: str = typer.Argument(..., help="Charges JSON A"),
    charge_b: str = typer.Argument(..., help="Charges JSON B"),
):
    """Diff two charge sets by canonical_atom_id."""

    def _load_charge_map(path: Path, label: str) -> Dict[int, float]:
        if not path.exists():
            raise typer.BadParameter(f"{label} file not found: {path}")
        data = read_json(path)
        if isinstance(data, dict):
            data = data.get("charges", data)
        if not isinstance(data, list):
            raise typer.BadParameter(f"{label} must be a list of charge records")
        charge_map: Dict[int, float] = {}
        for idx, row in enumerate(data):
            if not isinstance(row, dict) or "canonical_atom_id" not in row or "charge" not in row:
                raise typer.BadParameter(f"{label} invalid row at index {idx}")
            cid = int(row["canonical_atom_id"])
            if cid in charge_map:
                raise typer.BadParameter(f"{label} has duplicate canonical_atom_id {cid}")
            charge_map[cid] = float(row["charge"])
        return charge_map

    map_a = _load_charge_map(Path(charge_a), "charge_a")
    map_b = _load_charge_map(Path(charge_b), "charge_b")

    ids_a = set(map_a)
    ids_b = set(map_b)
    if ids_a != ids_b:
        only_a = sorted(ids_a - ids_b)
        only_b = sorted(ids_b - ids_a)
        raise typer.BadParameter(
            f"charge atom-id mismatch; only in A: {only_a[:10]} only in B: {only_b[:10]}"
        )

    rows = []
    for cid in sorted(ids_a):
        qa = map_a[cid]
        qb = map_b[cid]
        rows.append({"canonical_atom_id": cid, "charge_a": qa, "charge_b": qb, "delta": qb - qa})

    deltas = [r["delta"] for r in rows]
    summary = {
        "min": min(deltas) if deltas else 0.0,
        "max": max(deltas) if deltas else 0.0,
        "mean": (sum(deltas) / len(deltas)) if deltas else 0.0,
        "rms": ((sum(d * d for d in deltas) / len(deltas)) ** 0.5) if deltas else 0.0,
    }

    typer.echo(json.dumps({"summary": summary, "deltas": rows}, ensure_ascii=False, indent=2))


@app.command()
def diff_pipeline(
    run_a: str = typer.Argument(...),
    run_b: str = typer.Argument(...),
    config: Optional[Path] = typer.Option(None, "--config"),
):
    """Diff two pipeline runs (stage/tool/params)."""
    cfg_path = _resolve_config_path(config)
    cfg = load_config(cfg_path)
    conn = connect(cfg.ledger_db)
    row_a = conn.execute("SELECT stage, tool, params_json, status FROM runs WHERE run_id = ?", (run_a,)).fetchone()
    row_b = conn.execute("SELECT stage, tool, params_json, status FROM runs WHERE run_id = ?", (run_b,)).fetchone()
    if not row_a or not row_b:
        raise typer.BadParameter("Run not found")

    params_a = json.loads(row_a["params_json"] or "{}")
    params_b = json.loads(row_b["params_json"] or "{}")

    diff_keys = sorted(set(params_a) | set(params_b))
    param_diff = {}
    for k in diff_keys:
        if params_a.get(k) != params_b.get(k):
            param_diff[k] = {"a": params_a.get(k), "b": params_b.get(k)}

    out = {
        "stage": {"a": row_a["stage"], "b": row_b["stage"]},
        "tool": {"a": row_a["tool"], "b": row_b["tool"]},
        "status": {"a": row_a["status"], "b": row_b["status"]},
        "params_diff": param_diff,
    }
    typer.echo(json.dumps(out, ensure_ascii=False, indent=2))


@app.command()
def prov_export(
    output: Optional[Path] = typer.Option(None, "--output"),
    config: Optional[Path] = typer.Option(None, "--config"),
):
    """Export PROV-JSON for ledger provenance."""
    cfg_path = _resolve_config_path(config)
    cfg = load_config(cfg_path)
    conn = connect(cfg.ledger_db)

    prov = {"entity": {}, "activity": {}, "wasGeneratedBy": {}, "wasDerivedFrom": {}}
    missing_artifacts: List[str] = []

    def ent_id(raw: str) -> str:
        if raw.startswith("C-"):
            return f"compound:{raw}"
        if raw.startswith("M-"):
            return f"microstate:{raw}"
        if raw.startswith("X-"):
            return f"conformer:{raw}"
        if raw.startswith("P-"):
            return f"pose:{raw}"
        if raw.startswith("S-"):
            return f"system:{raw}"
        if raw.startswith("A-"):
            return f"artifact:{raw}"
        if raw.startswith("R-"):
            return f"receptor:{raw}"
        return raw

    # activities
    for row in conn.execute("SELECT run_id, started_at, finished_at, stage, tool, status FROM runs").fetchall():
        prov["activity"][f"run:{row['run_id']}"] = {
            "prov:type": "Activity",
            "msl:stage": row["stage"],
            "msl:tool": row["tool"],
            "msl:status": row["status"],
            "prov:startTime": row["started_at"],
            "prov:endTime": row["finished_at"],
        }

    # entities: compounds, microstates, conformers, poses, systems, artifacts
    for row in conn.execute("SELECT compound_id, name, reg_hash, inchikey, parent_sdf_path FROM compounds").fetchall():
        prov["entity"][f"compound:{row['compound_id']}"] = {
            "prov:type": "Entity",
            "msl:name": row["name"],
            "msl:reg_hash": row["reg_hash"],
            "msl:inchikey": row["inchikey"],
            "msl:path": row["parent_sdf_path"],
        }
    for row in conn.execute("SELECT microstate_id, compound_id, sdf_path, formal_charge FROM microstates").fetchall():
        prov["entity"][f"microstate:{row['microstate_id']}"] = {
            "prov:type": "Entity",
            "msl:compound": row["compound_id"],
            "msl:formal_charge": row["formal_charge"],
            "msl:path": row["sdf_path"],
        }
    for row in conn.execute("SELECT conformer_id, microstate_id, sdf_path, energy FROM conformers").fetchall():
        prov["entity"][f"conformer:{row['conformer_id']}"] = {
            "prov:type": "Entity",
            "msl:microstate": row["microstate_id"],
            "msl:energy": row["energy"],
            "msl:path": row["sdf_path"],
        }
    for row in conn.execute("SELECT pose_id, conformer_id, pdbqt_path, score FROM poses").fetchall():
        prov["entity"][f"pose:{row['pose_id']}"] = {
            "prov:type": "Entity",
            "msl:conformer": row["conformer_id"],
            "msl:score": row["score"],
            "msl:path": row["pdbqt_path"],
        }
    for row in conn.execute("SELECT system_id, microstate_id, engine, artifact_path FROM systems").fetchall():
        prov["entity"][f"system:{row['system_id']}"] = {
            "prov:type": "Entity",
            "msl:microstate": row["microstate_id"],
            "msl:engine": row["engine"],
            "msl:path": row["artifact_path"],
        }
    for row in conn.execute("SELECT receptor_id, name, path FROM receptors").fetchall():
        prov["entity"][f"receptor:{row['receptor_id']}"] = {
            "prov:type": "Entity",
            "msl:name": row["name"],
            "msl:path": row["path"],
        }
    for row in conn.execute("SELECT artifact_id, kind, path, sha256, run_id FROM artifacts").fetchall():
        exists = Path(row["path"]).exists()
        prov["entity"][f"artifact:{row['artifact_id']}"] = {
            "prov:type": "Entity",
            "msl:kind": row["kind"],
            "msl:path": row["path"],
            "msl:sha256": row["sha256"],
            "msl:exists": exists,
        }
        if not exists:
            missing_artifacts.append(row["path"])
        if row["run_id"]:
            prov["wasGeneratedBy"][f"gen:{row['artifact_id']}"] = {
                "prov:entity": f"artifact:{row['artifact_id']}",
                "prov:activity": f"run:{row['run_id']}",
            }

    for row in conn.execute("SELECT ref_id, entity_id, system, external_id FROM external_refs").fetchall():
        prov["entity"][f"external_ref:{row['ref_id']}"] = {
            "prov:type": "Entity",
            "msl:system": row["system"],
            "msl:external_id": row["external_id"],
        }
        prov["wasDerivedFrom"][f"ext:{row['ref_id']}"] = {
            "prov:generatedEntity": f"external_ref:{row['ref_id']}",
            "prov:usedEntity": ent_id(row["entity_id"]),
            "msl:relation": "external_ref",
        }

    # edges as derivations
    for row in conn.execute("SELECT src_id, dst_id, relation FROM edges").fetchall():
        prov["wasDerivedFrom"][f"edge:{row['src_id']}:{row['dst_id']}:{row['relation']}"] = {
            "prov:generatedEntity": ent_id(row["dst_id"]),
            "prov:usedEntity": ent_id(row["src_id"]),
            "msl:relation": row["relation"],
        }

    if missing_artifacts:
        prov["msl:missing_artifacts"] = sorted(set(missing_artifacts))

    out_path = output or (cfg.reports_dir / f"prov_{uuid.uuid4().hex[:8]}.json")
    ensure_dir(out_path.parent)
    write_json(out_path, prov)
    typer.echo(str(out_path))


@app.command()
def repair(
    check_only: bool = typer.Option(True, help="Only report issues without modifying ledger"),
    purge_missing_artifacts: bool = typer.Option(False, help="Delete ledger rows for missing artifact files"),
    config: Optional[Path] = typer.Option(None, "--config"),
):
    """Audit ledger consistency and optionally purge missing artifact rows."""
    cfg_path = _resolve_config_path(config)
    cfg = load_config(cfg_path)
    conn = connect(cfg.ledger_db)

    missing = []
    for row in conn.execute("SELECT artifact_id, kind, path, run_id FROM artifacts").fetchall():
        pth = Path(row["path"])
        if not pth.exists():
            missing.append(
                {
                    "artifact_id": row["artifact_id"],
                    "kind": row["kind"],
                    "path": row["path"],
                    "run_id": row["run_id"],
                }
            )

    orphans = {
        "edge_missing_src": int(conn.execute("SELECT COUNT(*) FROM edges e WHERE NOT EXISTS (SELECT 1 FROM compounds c WHERE c.compound_id=e.src_id) AND NOT EXISTS (SELECT 1 FROM microstates m WHERE m.microstate_id=e.src_id) AND NOT EXISTS (SELECT 1 FROM conformers x WHERE x.conformer_id=e.src_id) AND NOT EXISTS (SELECT 1 FROM poses p WHERE p.pose_id=e.src_id) AND NOT EXISTS (SELECT 1 FROM systems s WHERE s.system_id=e.src_id) AND NOT EXISTS (SELECT 1 FROM artifacts a WHERE a.artifact_id=e.src_id) AND NOT EXISTS (SELECT 1 FROM receptors r WHERE r.receptor_id=e.src_id)").fetchone()[0]),
        "edge_missing_dst": int(conn.execute("SELECT COUNT(*) FROM edges e WHERE NOT EXISTS (SELECT 1 FROM compounds c WHERE c.compound_id=e.dst_id) AND NOT EXISTS (SELECT 1 FROM microstates m WHERE m.microstate_id=e.dst_id) AND NOT EXISTS (SELECT 1 FROM conformers x WHERE x.conformer_id=e.dst_id) AND NOT EXISTS (SELECT 1 FROM poses p WHERE p.pose_id=e.dst_id) AND NOT EXISTS (SELECT 1 FROM systems s WHERE s.system_id=e.dst_id) AND NOT EXISTS (SELECT 1 FROM artifacts a WHERE a.artifact_id=e.dst_id) AND NOT EXISTS (SELECT 1 FROM receptors r WHERE r.receptor_id=e.dst_id)").fetchone()[0]),
        "artifact_missing_run": int(conn.execute("SELECT COUNT(*) FROM artifacts a WHERE a.run_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM runs r WHERE r.run_id=a.run_id)").fetchone()[0]),
    }

    purged = 0
    if purge_missing_artifacts and missing:
        miss_ids = [m["artifact_id"] for m in missing]
        q = ",".join(["?"] * len(miss_ids))
        conn.execute(f"DELETE FROM edges WHERE src_id IN ({q}) OR dst_id IN ({q})", miss_ids + miss_ids)
        conn.execute(f"DELETE FROM artifacts WHERE artifact_id IN ({q})", miss_ids)
        purged = len(miss_ids)
        conn.commit()

    report = {
        "check_only": check_only,
        "missing_artifact_count": len(missing),
        "missing_artifacts": missing[:50],
        "orphan_counts": orphans,
        "purged_missing_artifacts": purged,
    }
    conn.close()
    typer.echo(json.dumps(report, ensure_ascii=False, indent=2))


@app.command()
def clean_invalid_microstates(
    dry_run: bool = typer.Option(False, help="Only report invalid microstates"),
    limit: int = typer.Option(0, help="Limit number of deletions (0 = no limit)"),
    config: Optional[Path] = typer.Option(None, "--config"),
):
    """Remove invalid microstates that fail RDKit sanitization."""
    cfg_path = _resolve_config_path(config)
    cfg = load_config(cfg_path)
    conn = connect(cfg.ledger_db)
    run_id = uuid.uuid4().hex
    insert_run(conn, run_id, "clean_invalid_microstates", "rdkit", json.dumps({"dry_run": dry_run, "limit": limit}), "running", "")

    rows = conn.execute("SELECT microstate_id, sdf_path FROM microstates").fetchall()
    list_path = cfg.runs_dir / f"{run_id}_microstates.tsv"
    ensure_dir(list_path.parent)
    list_path.write_text("\n".join([f"{r['microstate_id']}\t{r['sdf_path']}" for r in rows]) + "\n", encoding="utf-8")

    script = _scripts_path(cfg, "rdkit_validate_microstates.py")
    out_json = _run_in_env(cfg, "rdkit", ["python", str(script), "--list", str(list_path)])
    report = json.loads(out_json)
    invalid = report.get("invalid", [])

    if limit and limit > 0:
        invalid = invalid[:limit]

    report_path = cfg.reports_dir / f"clean_invalid_{run_id}.json"
    ensure_dir(report_path.parent)
    write_json(report_path, report)
    insert_artifact(conn, ids.artifact_id(report_path), "clean_invalid_report", str(report_path), sha256_file(report_path), run_id)

    if dry_run or not invalid:
        finish_run(conn, run_id, "ok")
        conn.commit()
        conn.close()
        typer.echo(json.dumps({"invalid_count": len(invalid), "dry_run": True, "report": str(report_path)}, ensure_ascii=False, indent=2))
        return

    invalid_ids = [row["microstate_id"] for row in invalid]
    conformer_ids = set()
    pose_ids = set()
    artifact_ids = set()

    for mid in invalid_ids:
        mrow = conn.execute("SELECT sdf_path FROM microstates WHERE microstate_id = ?", (mid,)).fetchone()
        if not mrow:
            continue
        sdf_path = Path(mrow["sdf_path"])
        mdir = sdf_path.parent
        prefixes = [
            str(mdir),
            str(cfg.objects_dir / "conformers" / mid),
            str(cfg.objects_dir / "docking" / mid),
            str(cfg.objects_dir / "md" / mid),
        ]

        # collect conformers/poses
        for row in conn.execute("SELECT conformer_id FROM conformers WHERE microstate_id = ?", (mid,)).fetchall():
            conformer_ids.add(row["conformer_id"])
        for cid in list(conformer_ids):
            for prow in conn.execute("SELECT pose_id FROM poses WHERE conformer_id = ?", (cid,)).fetchall():
                pose_ids.add(prow["pose_id"])

        # collect artifacts by prefix
        for pref in prefixes:
            pref_clean = pref.rstrip("/") + "/"
            for arow in conn.execute("SELECT artifact_id FROM artifacts WHERE path LIKE ?", (pref_clean + "%",)).fetchall():
                artifact_ids.add(arow["artifact_id"])

        # remove files
        for pref in prefixes:
            p = Path(pref)
            if p.exists():
                shutil.rmtree(p, ignore_errors=True)

    # delete edges
    all_ids = set(invalid_ids) | conformer_ids | pose_ids | artifact_ids
    for _id in all_ids:
        conn.execute("DELETE FROM edges WHERE src_id = ? OR dst_id = ?", (_id, _id))

    # delete poses/conformers/systems/atom_maps/microstates/artifacts
    for pid in pose_ids:
        conn.execute("DELETE FROM poses WHERE pose_id = ?", (pid,))
    for cid in conformer_ids:
        conn.execute("DELETE FROM conformers WHERE conformer_id = ?", (cid,))
    for mid in invalid_ids:
        conn.execute("DELETE FROM systems WHERE microstate_id = ?", (mid,))
        conn.execute("DELETE FROM atom_maps WHERE microstate_id = ?", (mid,))
        conn.execute("DELETE FROM microstates WHERE microstate_id = ?", (mid,))
    for aid in artifact_ids:
        conn.execute("DELETE FROM artifacts WHERE artifact_id = ?", (aid,))

    insert_decision(
        conn,
        "D-" + uuid.uuid4().hex[:12],
        run_id,
        "ledger",
        "clean_invalid_microstates",
        "delete_invalid",
        json.dumps({"deleted": invalid_ids, "count": len(invalid_ids)}),
    )

    finish_run(conn, run_id, "ok")
    conn.commit()
    conn.close()
    typer.echo(json.dumps({"deleted": invalid_ids, "count": len(invalid_ids), "report": str(report_path)}, ensure_ascii=False, indent=2))



@app.command()
def inject(
    parent: str = typer.Option(..., "--parent", help="Parent Compound ID"),
    sdf: str = typer.Argument(..., help="Manual microstate SDF"),
    relation: str = typer.Option("manual_inject", help="Edge relation to parent"),
    config: Optional[Path] = typer.Option(None, "--config"),
):
    """Inject a manual microstate into the ledger."""
    cfg_path = _resolve_config_path(config)
    cfg = load_config(cfg_path)
    conn = connect(cfg.ledger_db)
    row = conn.execute("SELECT compound_id FROM compounds WHERE compound_id = ?", (parent,)).fetchone()
    if not row:
        raise typer.BadParameter(f"Compound {parent} not found")

    run_id = uuid.uuid4().hex
    insert_run(conn, run_id, "manual_inject", "rdkit", json.dumps({"parent": parent, "sdf": sdf}), "running", "")

    tmp_dir = cfg.objects_dir / "microstates" / parent / f"_inject_{run_id}"
    ensure_dir(tmp_dir)
    script = _scripts_path(cfg, "rdkit_inject_microstate.py")
    out_json = _run_in_env(cfg, "rdkit", ["python", str(script), "--input-sdf", sdf, "--out-dir", str(tmp_dir)])
    data = json.loads(out_json)

    mid = data["microstate_id"]
    final_dir = cfg.objects_dir / "microstates" / parent / mid
    ensure_dir(final_dir)
    for name in ("microstate.sdf", "atom_map.json"):
        src = tmp_dir / name
        if src.exists():
            dst = final_dir / name
            if dst.exists() and dst.is_symlink():
                dst.unlink()
            src.replace(dst)
    if tmp_dir.exists():
        for p in sorted(tmp_dir.rglob("*"), reverse=True):
            if p.is_file():
                p.unlink()
        for p in sorted(tmp_dir.rglob("*"), reverse=True):
            if p.is_dir():
                p.rmdir()

    sdf_path = str(final_dir / "microstate.sdf")
    map_path = final_dir / "atom_map.json"

    insert_microstate(
        conn,
        mid,
        parent,
        data["fixedh_inchi"],
        int(data["formal_charge"]),
        data.get("stereo_tag", ""),
        data.get("coordination_sig", ""),
        sdf_path,
    )
    insert_atom_map(conn, "MAP-" + mid, mid, json.dumps(read_json(map_path)))
    insert_edge(conn, "E-" + uuid.uuid4().hex[:12], parent, mid, relation, run_id, json.dumps({"source": "manual"}))

    insert_artifact(conn, ids.artifact_id(sdf_path), "microstate_sdf", sdf_path, sha256_file(sdf_path), run_id)
    insert_artifact(conn, ids.artifact_id(map_path), "atom_map", str(map_path), sha256_file(map_path), run_id)
    insert_decision(conn, "D-" + uuid.uuid4().hex[:12], run_id, mid, "manual_inject", "accepted", json.dumps({"parent": parent}))

    finish_run(conn, run_id, "ok")
    conn.commit()
    conn.close()
    typer.echo(mid)


@app.command()
def policy_snapshot(
    run_id: str = typer.Argument(..., help="Run ID to label the snapshot"),
    config: Optional[Path] = typer.Option(None, "--config"),
):
    """Snapshot current policy to reports/policies/<run_id>.yaml"""
    cfg_path = _resolve_config_path(config)
    cfg = load_config(cfg_path)
    policy_path = cfg.policy_path
    if not policy_path.exists():
        policy_path = msl_resources.get_resource_file("policies", policy_path.name)
    out_dir = cfg.reports_dir / "policies"
    ensure_dir(out_dir)
    out_path = out_dir / f"{run_id}.yaml"
    if out_path.exists() and out_path.is_symlink():
        out_path.unlink()
    shutil.copy2(policy_path, out_path)
    conn = connect(cfg.ledger_db)
    insert_artifact(conn, ids.artifact_id(out_path), "policy_snapshot", str(out_path), sha256_file(out_path), run_id)
    conn.commit()
    conn.close()
    typer.echo(str(out_path))


@app.command()
def checkout(
    run_id: str = typer.Argument(..., help="Run ID to restore policy snapshot"),
    policy_out: Optional[Path] = typer.Option(None, "--policy-out", help="Optional output policy path"),
    config: Optional[Path] = typer.Option(None, "--config"),
):
    """Restore policy snapshot for a run to current policy path (or --policy-out)."""
    cfg_path = _resolve_config_path(config)
    cfg = load_config(cfg_path)
    snap = cfg.reports_dir / "policies" / f"{run_id}.yaml"
    if not snap.exists():
        raise typer.BadParameter(f"Policy snapshot not found: {snap}")
    dest = policy_out or cfg.policy_path
    ensure_dir(Path(dest).parent)
    if Path(dest).exists() and Path(dest).is_symlink():
        Path(dest).unlink()
    shutil.copy2(snap, dest)
    typer.echo(str(dest))


@app.command()
def batch(
    input: str = typer.Argument(..., help="SMILES file (one per line)"),
    resume: bool = typer.Option(True, help="Resume from state file if present"),
    state: str = typer.Option("", help="State file path (json)"),
    limit: int = typer.Option(0, help="Limit number of entries (0 = all)"),
    config: Optional[Path] = typer.Option(None, "--config"),
):
    """Batch ingest + perceive + enumerate with resume support."""
    cfg_path = _resolve_config_path(config)
    cfg = load_config(cfg_path)
    in_path = Path(input)
    if not in_path.exists():
        raise typer.BadParameter(f"Input file not found: {input}")

    state_path = Path(state) if state else (cfg.runs_dir / f"batch_{in_path.stem}.json")
    ensure_dir(state_path.parent)

    completed = set()
    errors = []
    if resume and state_path.exists():
        data = read_json(state_path)
        completed = set(data.get("completed", []))
        errors = data.get("errors", [])

    lines = [l.strip() for l in in_path.read_text(encoding="utf-8").splitlines() if l.strip()]
    total = len(lines)
    processed = 0
    smiles_cache: Dict[str, str] = {}

    conn = connect(cfg.ledger_db)
    if resume:
        stale_rows = conn.execute(
            "SELECT run_id FROM runs WHERE stage = ? AND status = ?",
            ("batch", "running"),
        ).fetchall()
        for row in stale_rows:
            finish_run(conn, str(row["run_id"]), "aborted")
    run_id = uuid.uuid4().hex
    insert_run(conn, run_id, "batch", "msl", json.dumps({"input": str(in_path), "resume": resume}), "running", "")
    conn.commit()
    conn.close()

    for idx, line in enumerate(lines):
        if idx in completed:
            continue
        if limit and processed >= limit:
            break
        parts = line.split()
        smiles = parts[0]
        name = parts[1] if len(parts) > 1 else ""
        if smiles in smiles_cache:
            cid = smiles_cache[smiles]
        else:
            try:
                cid_out = _capture_output(ingest, input=smiles, name=name, config=cfg_path)
            except Exception as e:
                errors.append({"index": idx, "smiles": smiles, "error": str(e)})
                continue
            cid = ""
            for ln in cid_out.splitlines()[::-1]:
                if ln.strip():
                    cid = ln.strip()
                    break
            if not cid:
                errors.append({"index": idx, "smiles": smiles, "error": "ingest returned empty compound id"})
                continue
            smiles_cache[smiles] = cid

        try:
            conn = connect(cfg.ledger_db)
            row = conn.execute("SELECT COUNT(*) FROM microstates WHERE compound_id = ?", (cid,)).fetchone()
            conn.close()
            if row and row[0] > 0:
                completed.add(idx)
                processed += 1
                continue
            perceive(cid, config=cfg_path)
            enumerate_microstates(cid, config=cfg_path)
        except Exception as e:
            errors.append({"index": idx, "compound_id": cid, "error": str(e)})
            continue

        completed.add(idx)
        processed += 1
        write_json(state_path, {"completed": sorted(completed), "errors": errors, "total": total})

    write_json(state_path, {"completed": sorted(completed), "errors": errors, "total": total})
    conn = connect(cfg.ledger_db)
    finish_run(conn, run_id, "ok")
    conn.commit()
    conn.close()
    typer.echo(json.dumps({"completed": len(completed), "total": total, "errors": errors}, ensure_ascii=False, indent=2))

@app.command()
def dvc_track(
    path: List[str] = typer.Option(["objects", "reports"], "--path", help="Paths to track with DVC"),
    config: Optional[Path] = typer.Option(None, "--config"),
):
    """Track data artifacts with DVC (adds .dvc files)."""
    cfg_path = _resolve_config_path(config)
    cfg = load_config(cfg_path)
    run_id = uuid.uuid4().hex
    conn = connect(cfg.ledger_db)
    insert_run(conn, run_id, "dvc_track", "dvc", json.dumps({"paths": path}), "running", "")
    if not (cfg.root / ".dvc").exists():
        init_cmd = ["dvc", "init", "-q"]
        if not (cfg.root / ".git").exists():
            init_cmd.append("--no-scm")
        _run_in_env(cfg, "dvc", init_cmd, cwd=cfg.root)
    for p in path:
        _run_in_env(cfg, "dvc", ["dvc", "add", p], cwd=cfg.root)
    finish_run(conn, run_id, "ok")
    conn.commit()
    conn.close()
    typer.echo("DVC tracking updated")


@app.command()
def datalad_init(
    path: str = typer.Option(".", help="Dataset path"),
    force: bool = typer.Option(False, help="Force creation in non-empty directory"),
    no_annex: bool = typer.Option(False, "--no-annex", help="Create plain Git repo without git-annex"),
    config: Optional[Path] = typer.Option(None, "--config"),
):
    """Initialize a DataLad dataset."""
    cfg_path = _resolve_config_path(config)
    cfg = load_config(cfg_path)
    home_dir = cfg.root / ".datalad_home"
    ensure_dir(home_dir)
    env_bits = [
        "env",
        f"HOME={home_dir}",
        "GIT_AUTHOR_NAME=msl",
        "GIT_AUTHOR_EMAIL=msl@example.com",
        "GIT_COMMITTER_NAME=msl",
        "GIT_COMMITTER_EMAIL=msl@example.com",
    ]
    cmd = env_bits + ["datalad", "create"]
    if no_annex:
        cmd.append("--no-annex")
    if force:
        cmd.append("--force")
    cmd.append(path)
    try:
        _run_in_env(cfg, "datalad", cmd, cwd=cfg.root)
        typer.echo("DataLad dataset created")
    except typer.BadParameter as e:
        msg = str(e)
        if (not no_annex) and ("No working git-annex" in msg):
            fallback = env_bits + ["datalad", "create", "--no-annex"]
            if force:
                fallback.append("--force")
            fallback.append(path)
            _run_in_env(cfg, "datalad", fallback, cwd=cfg.root)
            typer.echo("DataLad dataset created (no-annex fallback)")
            return
        raise


@app.command()
def datalad_save(
    message: str = typer.Option("msl save", help="Save message"),
    path: List[str] = typer.Option(["objects", "reports"], "--path", help="Paths to save"),
    config: Optional[Path] = typer.Option(None, "--config"),
):
    """Save changes to DataLad dataset."""
    cfg_path = _resolve_config_path(config)
    cfg = load_config(cfg_path)
    home_dir = cfg.root / ".datalad_home"
    ensure_dir(home_dir)
    env_bits = [
        "env",
        f"HOME={home_dir}",
        "GIT_AUTHOR_NAME=msl",
        "GIT_AUTHOR_EMAIL=msl@example.com",
        "GIT_COMMITTER_NAME=msl",
        "GIT_COMMITTER_EMAIL=msl@example.com",
    ]
    cmd = env_bits + ["datalad", "save", "-m", message] + path
    _run_in_env(cfg, "datalad", cmd, cwd=cfg.root)
    typer.echo("DataLad saved")


@app.command()
def lwreg_init(
    config_path: str = typer.Option("lwreg_config.json", help="lwreg config path"),
    db_path: str = typer.Option("lwreg.sqlite", help="lwreg sqlite db path"),
    config: Optional[Path] = typer.Option(None, "--config"),
):
    """Initialize lwreg database and config."""
    cfg_path = _resolve_config_path(config)
    cfg = load_config(cfg_path)
    cfg_path = cfg.root / config_path
    db_file = cfg.root / db_path
    if not cfg_path.exists():
        cfg_path.write_text(json.dumps({"dbname": str(db_file), "dbtype": "sqlite3"}, indent=2), encoding="utf-8")
    _run_in_env(cfg, "lwreg", ["lwreg", "--config", str(cfg_path), "initdb", "--confirm", "yes"], cwd=cfg.root)
    typer.echo(str(cfg_path))


@app.command()
def lwreg_register(
    compound_id: str = typer.Argument(..., help="Compound ID"),
    config_path: str = typer.Option("lwreg_config.json", help="lwreg config path"),
    config: Optional[Path] = typer.Option(None, "--config"),
):
    """Register a compound in lwreg and store external reference."""
    cfg_path = _resolve_config_path(config)
    cfg = load_config(cfg_path)
    conn = connect(cfg.ledger_db)
    row = conn.execute("SELECT parent_sdf_path FROM compounds WHERE compound_id = ?", (compound_id,)).fetchone()
    if not row:
        raise typer.BadParameter(f"Compound {compound_id} not found")
    sdf_path = row[0]
    script_smiles = _scripts_path(cfg, "rdkit_to_smiles.py")
    smiles = _run_in_env(cfg, "rdkit", ["python", str(script_smiles), "--input", str(sdf_path)])

    cfg_path = cfg.root / config_path
    if not cfg_path.exists():
        raise typer.BadParameter(f"lwreg config not found: {cfg_path}")

    out = _run_in_env(cfg, "lwreg", ["lwreg", "--config", str(cfg_path), "register", "--smiles", smiles], cwd=cfg.root)
    lwreg_id = out.strip().splitlines()[-1] if out.strip() else ""
    if not lwreg_id:
        raise RuntimeError("lwreg registration failed")

    ref_id = "EXT-" + uuid.uuid4().hex[:12]
    insert_external_ref(conn, ref_id, compound_id, "lwreg", lwreg_id)
    conn.commit()
    conn.close()
    typer.echo(lwreg_id)


@app.command()
def dvc_init(config: Optional[Path] = typer.Option(None, "--config")):
    """Initialize DVC in project root."""
    cfg_path = _resolve_config_path(config)
    cfg = load_config(cfg_path)
    init_cmd = ["dvc", "init", "-q"]
    if not (cfg.root / ".git").exists():
        init_cmd.append("--no-scm")
    _run_in_env(cfg, "dvc", init_cmd, cwd=cfg.root)
    typer.echo("DVC initialized")


@app.command()
def demo(
    smiles: str = typer.Argument("CCO", help="SMILES string"),
    name: str = typer.Option("demo", help="Compound name"),
    out_dir: Optional[Path] = typer.Option(None, "--out-dir", help="Output directory for demo run"),
    conda: Optional[Path] = typer.Option(None, "--conda", help="Conda executable path"),
    envs_base: Optional[Path] = typer.Option(None, "--envs-base", help="Base directory for tool envs"),
    config: Optional[Path] = typer.Option(None, "--config", help="Use env settings from existing config"),
):
    """Run a full demo pipeline from SMILES to MD using embedded resources."""
    stamp = str(uuid.uuid4())[:8]
    if out_dir is None:
        out_dir = Path.cwd() / "demo_runs" / stamp
    out_dir = out_dir.expanduser().resolve()
    ensure_dir(out_dir)

    conda_path = None
    envs_path = None
    if config:
        cfg_base = load_config(config)
        conda_path = cfg_base.conda
        envs_path = cfg_base.envs_base
    else:
        cfg_guess = None
        try:
            cfg_guess = load_config(find_default_config())
        except Exception:
            cfg_guess = None
        if cfg_guess:
            conda_path = cfg_guess.conda
            envs_path = cfg_guess.envs_base

    # Explicit CLI options must override inferred defaults.
    if conda is not None:
        conda_path = Path(conda)
    if envs_base is not None:
        envs_path = Path(envs_base)

    if conda_path is None:
        conda_path = Path(os.environ.get("MSL_CONDA", conda or "conda"))
    if envs_path is None:
        envs_env = os.environ.get("MSL_ENVS_BASE")
        if envs_env:
            envs_path = Path(envs_env)
        else:
            local_envs = Path.cwd() / "envs"
            home_envs = Path.home() / ".microstateledger" / "envs"
            if local_envs.exists():
                envs_path = local_envs
            elif home_envs.exists():
                envs_path = home_envs
            else:
                envs_path = Path(envs_base or (Path.cwd() / "envs"))

    # Validate envs base and conda
    if not Path(str(conda_path)).exists() and str(conda_path) != "conda":
        raise typer.BadParameter(f"Conda not found: {conda_path}. Set --conda or MSL_CONDA.")
    if not Path(envs_path).exists():
        raise typer.BadParameter(f"Envs base not found: {envs_path}. Set --envs-base or MSL_ENVS_BASE.")

    policy_path = msl_resources.get_resource_file("policies", "default.yaml")

    cfg_path = out_dir / "msl_demo.toml"
    cfg_text = f"""[project]
name = \"MicrostateLedgerDemo\"
root = \"{out_dir}\"
objects_dir = \"objects\"
runs_dir = \"runs\"
reports_dir = \"reports\"
policy = \"{policy_path}\"
ledger_db = \"ledger.sqlite\"

[envs]
conda = \"{conda_path}\"
base_dir = \"{envs_path}\"

[logging]
level = \"INFO\"
log_dir = \"logs\"\n"""
    cfg_path.write_text(cfg_text, encoding="utf-8")

    _capture_output(init, config=cfg_path)
    cid_out = _capture_output(ingest, input=smiles, name=name, config=cfg_path)
    cid = [line for line in cid_out.splitlines() if line.strip()][-1]
    perceive(cid, config=cfg_path)
    enumerate_microstates(cid, config=cfg_path)

    conn = connect(out_dir / "ledger.sqlite")
    row = conn.execute("SELECT microstate_id FROM microstates ORDER BY created_at DESC LIMIT 1").fetchone()
    if not row:
        conn.close()
        raise typer.BadParameter("No microstate found")
    mid = row[0]
    conn.close()

    conformers(mid, method="rdkit", n=30, prune_rmsd=0.5, topk=0, seed=-1, use_seer=False, seer_mode="pos", use_ccsf=False, ccsf_topk=0, experimental_ccs=0.0, config=cfg_path)

    conn = connect(out_dir / "ledger.sqlite")
    row = conn.execute("SELECT conformer_id FROM conformers WHERE microstate_id = ? ORDER BY created_at DESC LIMIT 1", (mid,)).fetchone()
    if not row:
        conn.close()
        raise typer.BadParameter("No conformer found")
    xid = row[0]
    conn.close()

    dock_prep(mid, xid, config=cfg_path)
    rec_dir = out_dir / "objects" / "receptors"
    ensure_dir(rec_dir)
    rec_path = rec_dir / "demo_receptor.pdb"
    rec_path.write_text("RECEPTOR\n", encoding="utf-8")
    dock_ingest(xid, str(out_dir / "objects" / "docking" / mid / xid / "ligand.pdbqt"), score=-7.5, receptor_path=str(rec_path), receptor_name="demo_rec", tool="vina", params_json="", config=cfg_path)
    dock_select(mid, k=1, by="", config=cfg_path)

    charge(mid, method="pype_resp", charges_json="", mol2="", resp_input="", espot="", qin="", polariz="", auto_qm=True, qm_theory="HF/6-31G*", qm_engine="auto", multiplicity=1, points_per_atom=60, probe=1.4, conformer_id=xid, config=cfg_path)
    md_param(mid, forcefield="openff-2.1.0.offxml", charges_json="", config=cfg_path)
    ms_sdf = out_dir / "objects" / "microstates" / cid / mid / "microstate.sdf"
    md_feedback(mid, str(ms_sdf), map_json="", config=cfg_path)
    md_transition(mid, str(ms_sdf), config=cfg_path)
    prov_export(output=out_dir / "reports" / "prov_demo.json", config=cfg_path)

    typer.echo(f"Demo finished. Root: {out_dir} Compound: {cid} Microstate: {mid} Conformer: {xid}")


if __name__ == "__main__":
    app()

