from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict

try:
    import tomllib as tomli
except ModuleNotFoundError:
    import tomli


@dataclass
class MSLConfig:
    root: Path
    objects_dir: Path
    runs_dir: Path
    reports_dir: Path
    policy_path: Path
    ledger_db: Path
    conda: Path
    envs_base: Path
    log_dir: Path


def load_config(path: str | Path) -> MSLConfig:
    path = Path(path)
    with path.open("rb") as f:
        data: Dict[str, Any] = tomli.load(f)

    project = data.get("project", {})
    envs = data.get("envs", {})
    logging = data.get("logging", {})

    root = Path(project.get("root", path.parent)).expanduser().resolve()
    objects_dir = root / project.get("objects_dir", "objects")
    runs_dir = root / project.get("runs_dir", "runs")
    reports_dir = root / project.get("reports_dir", "reports")
    policy_path = root / project.get("policy", "policies/default.yaml")
    ledger_db = root / project.get("ledger_db", "ledger.sqlite")

    conda = Path(envs.get("conda", "conda")).expanduser()
    envs_base = root / envs.get("base_dir", "envs")

    log_dir = root / logging.get("log_dir", "logs")

    return MSLConfig(
        root=root,
        objects_dir=objects_dir,
        runs_dir=runs_dir,
        reports_dir=reports_dir,
        policy_path=policy_path,
        ledger_db=ledger_db,
        conda=conda,
        envs_base=envs_base,
        log_dir=log_dir,
    )


def find_default_config() -> Path:
    cwd = Path(os.getcwd())
    candidate = cwd / "msl.toml"
    if candidate.exists():
        return candidate
    raise FileNotFoundError("msl.toml not found in current directory")
