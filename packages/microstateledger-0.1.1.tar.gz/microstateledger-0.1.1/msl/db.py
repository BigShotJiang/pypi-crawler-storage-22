from __future__ import annotations

import sqlite3
from pathlib import Path
from typing import Any, Dict, Optional

from msl.utils import now_iso

SCHEMA_VERSION = 1


def _get_user_version(conn: sqlite3.Connection) -> int:
    row = conn.execute("PRAGMA user_version").fetchone()
    return int(row[0]) if row else 0


def _set_user_version(conn: sqlite3.Connection, version: int) -> None:
    conn.execute(f"PRAGMA user_version = {int(version)}")


def _has_table(conn: sqlite3.Connection, name: str) -> bool:
    row = conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name = ?", (name,)).fetchone()
    return row is not None


def connect(db_path: str | Path) -> sqlite3.Connection:
    conn = sqlite3.connect(str(db_path), timeout=30)
    conn.row_factory = sqlite3.Row
    try:
        conn.execute("PRAGMA busy_timeout = 30000")
        conn.execute("PRAGMA foreign_keys = ON")
    except Exception:
        pass
    return conn


def migrate_db(conn: sqlite3.Connection, schema_path: str | Path) -> None:
    version = _get_user_version(conn)
    if version > SCHEMA_VERSION:
        raise RuntimeError(
            f"Ledger schema version {version} is newer than supported {SCHEMA_VERSION}. "
            "Downgrade is not supported; use a matching/newer MicrostateLedger version."
        )

    # Always apply schema DDL (IF NOT EXISTS) so partially migrated/legacy DBs
    # recover missing tables/indexes safely.
    with open(schema_path, "r", encoding="utf-8") as f:
        schema_sql = f.read()

    conn.executescript(schema_sql)

    if version < SCHEMA_VERSION:
        _set_user_version(conn, SCHEMA_VERSION)


def init_db(db_path: str | Path, schema_path: str | Path) -> None:
    conn = connect(db_path)
    migrate_db(conn, schema_path)
    conn.commit()
    conn.close()


def insert_run(conn: sqlite3.Connection, run_id: str, stage: str, tool: str, params_json: str, status: str, log_path: str) -> None:
    conn.execute(
        "INSERT INTO runs (run_id, started_at, stage, tool, params_json, status, log_path) VALUES (?, ?, ?, ?, ?, ?, ?)",
        (run_id, now_iso(), stage, tool, params_json, status, log_path),
    )


def finish_run(conn: sqlite3.Connection, run_id: str, status: str) -> None:
    conn.execute(
        "UPDATE runs SET finished_at = ?, status = ? WHERE run_id = ?",
        (now_iso(), status, run_id),
    )


def get_compound_by_hash(conn: sqlite3.Connection, reg_hash: str) -> Optional[str]:
    row = conn.execute("SELECT compound_id FROM compounds WHERE reg_hash = ?", (reg_hash,)).fetchone()
    return row[0] if row else None


def insert_compound(conn: sqlite3.Connection, compound_id: str, name: str, reg_hash: str, inchikey: str, parent_sdf_path: str) -> None:
    conn.execute(
        "INSERT INTO compounds (compound_id, name, reg_hash, inchikey, created_at, parent_sdf_path) VALUES (?, ?, ?, ?, ?, ?)",
        (compound_id, name, reg_hash, inchikey, now_iso(), parent_sdf_path),
    )


def insert_microstate(conn: sqlite3.Connection, microstate_id: str, compound_id: str, fixedh_inchi: str, formal_charge: int, stereo_tag: str, coordination_sig: str, sdf_path: str) -> None:
    conn.execute(
        "INSERT OR IGNORE INTO microstates (microstate_id, compound_id, fixedh_inchi, formal_charge, stereo_tag, coordination_sig, created_at, sdf_path) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        (microstate_id, compound_id, fixedh_inchi, formal_charge, stereo_tag, coordination_sig, now_iso(), sdf_path),
    )


def insert_conformer(conn: sqlite3.Connection, conformer_id: str, microstate_id: str, sdf_path: str, energy: float) -> None:
    conn.execute(
        "INSERT OR IGNORE INTO conformers (conformer_id, microstate_id, created_at, sdf_path, energy) VALUES (?, ?, ?, ?, ?)",
        (conformer_id, microstate_id, now_iso(), sdf_path, energy),
    )


def insert_pose(conn: sqlite3.Connection, pose_id: str, conformer_id: str, pdbqt_path: str, score: float) -> None:
    conn.execute(
        "INSERT OR IGNORE INTO poses (pose_id, conformer_id, created_at, pdbqt_path, score) VALUES (?, ?, ?, ?, ?)",
        (pose_id, conformer_id, now_iso(), pdbqt_path, score),
    )


def insert_receptor(conn: sqlite3.Connection, receptor_id: str, name: str, path: str) -> None:
    conn.execute(
        "INSERT OR IGNORE INTO receptors (receptor_id, name, created_at, path) VALUES (?, ?, ?, ?)",
        (receptor_id, name, now_iso(), path),
    )


def insert_external_ref(conn: sqlite3.Connection, ref_id: str, entity_id: str, system: str, external_id: str) -> None:
    conn.execute(
        "INSERT OR IGNORE INTO external_refs (ref_id, entity_id, system, external_id, created_at) VALUES (?, ?, ?, ?, ?)",
        (ref_id, entity_id, system, external_id, now_iso()),
    )


def insert_system(conn: sqlite3.Connection, system_id: str, microstate_id: str, engine: str, artifact_path: str) -> None:
    conn.execute(
        "INSERT OR IGNORE INTO systems (system_id, microstate_id, created_at, engine, artifact_path) VALUES (?, ?, ?, ?, ?)",
        (system_id, microstate_id, now_iso(), engine, artifact_path),
    )


def insert_artifact(conn: sqlite3.Connection, artifact_id: str, kind: str, path: str, sha256: str, run_id: str) -> None:
    conn.execute(
        "INSERT OR IGNORE INTO artifacts (artifact_id, kind, path, sha256, created_at, run_id) VALUES (?, ?, ?, ?, ?, ?)",
        (artifact_id, kind, path, sha256, now_iso(), run_id),
    )


def insert_edge(conn: sqlite3.Connection, edge_id: str, src_id: str, dst_id: str, relation: str, run_id: str, params_json: str) -> None:
    conn.execute(
        "INSERT OR IGNORE INTO edges (edge_id, src_id, dst_id, relation, created_at, run_id, params_json) VALUES (?, ?, ?, ?, ?, ?, ?)",
        (edge_id, src_id, dst_id, relation, now_iso(), run_id, params_json),
    )


def insert_decision(conn: sqlite3.Connection, decision_id: str, run_id: str, target_id: str, decision_type: str, rationale: str, params_json: str) -> None:
    conn.execute(
        "INSERT INTO decisions (decision_id, run_id, target_id, decision_type, rationale, params_json, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
        (decision_id, run_id, target_id, decision_type, rationale, params_json, now_iso()),
    )


def insert_anomaly(conn: sqlite3.Connection, anomaly_id: str, run_id: str, target_id: str, anomaly_type: str, details_json: str) -> None:
    conn.execute(
        "INSERT INTO anomalies (anomaly_id, run_id, target_id, anomaly_type, details_json, created_at) VALUES (?, ?, ?, ?, ?, ?)",
        (anomaly_id, run_id, target_id, anomaly_type, details_json, now_iso()),
    )


def insert_atom_map(conn: sqlite3.Connection, map_id: str, microstate_id: str, mapping_json: str) -> None:
    conn.execute(
        "INSERT OR IGNORE INTO atom_maps (map_id, microstate_id, mapping_json, created_at) VALUES (?, ?, ?, ?)",
        (map_id, microstate_id, mapping_json, now_iso()),
    )
