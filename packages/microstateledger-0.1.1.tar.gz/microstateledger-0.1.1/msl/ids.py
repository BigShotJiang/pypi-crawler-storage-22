from __future__ import annotations

import hashlib
from pathlib import Path


def compound_id(reg_hash: str) -> str:
    return "C-" + reg_hash[:12]


def microstate_id(fixedh_inchi: str, formal_charge: int, stereo_tag: str, coordination_sig: str = "") -> str:
    payload = f"{fixedh_inchi}|{formal_charge}|{stereo_tag}|{coordination_sig}"
    return "M-" + hashlib.sha256(payload.encode("utf-8")).hexdigest()[:12]


def conformer_id(file_path: str | Path) -> str:
    import msl.utils as utils
    return "X-" + utils.sha256_file(file_path)[:12]


def pose_id(file_path: str | Path) -> str:
    import msl.utils as utils
    return "P-" + utils.sha256_file(file_path)[:12]


def artifact_id(file_path: str | Path) -> str:
    import msl.utils as utils
    return "A-" + utils.sha256_file(file_path)[:12]


def receptor_id(file_path: str | Path) -> str:
    import msl.utils as utils
    return "R-" + utils.sha256_file(file_path)[:12]
