from __future__ import annotations

import os
import shutil
from pathlib import Path
from importlib import resources

from msl import __version__

_RESOURCE_SUBDIRS = {"scripts", "policies", "schemas"}


def resource_root() -> Path:
    return resources.files("msl") / "resources"


def ensure_resource_dir(subdir: str) -> Path:
    if subdir not in _RESOURCE_SUBDIRS:
        raise ValueError(f"Unknown resource subdir: {subdir}")
    cache_base = Path(
        os.environ.get(
            "MSL_RESOURCE_CACHE",
            Path.home() / ".microstateledger" / "resources",
        )
    )
    target = cache_base / __version__ / subdir
    src = resource_root() / subdir
    target.parent.mkdir(parents=True, exist_ok=True)
    with resources.as_file(src) as src_path:
        if src_path.is_dir():
            target.mkdir(parents=True, exist_ok=True)
            shutil.copytree(src_path, target, dirs_exist_ok=True)
        else:
            target.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src_path, target)
    return target


def get_resource_file(subdir: str, name: str) -> Path:
    base = ensure_resource_dir(subdir)
    return base / name
