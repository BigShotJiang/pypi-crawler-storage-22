-- MicrostateLedger SQLite schema (core)
PRAGMA foreign_keys = ON;
PRAGMA user_version = 1;

CREATE TABLE IF NOT EXISTS runs (
  run_id TEXT PRIMARY KEY,
  started_at TEXT NOT NULL,
  finished_at TEXT,
  stage TEXT NOT NULL,
  tool TEXT,
  params_json TEXT,
  status TEXT NOT NULL,
  log_path TEXT
);

CREATE TABLE IF NOT EXISTS compounds (
  compound_id TEXT PRIMARY KEY,
  name TEXT,
  reg_hash TEXT NOT NULL,
  inchikey TEXT,
  created_at TEXT NOT NULL,
  parent_sdf_path TEXT
);

CREATE TABLE IF NOT EXISTS microstates (
  microstate_id TEXT PRIMARY KEY,
  compound_id TEXT NOT NULL,
  fixedh_inchi TEXT NOT NULL,
  formal_charge INTEGER NOT NULL,
  stereo_tag TEXT,
  coordination_sig TEXT,
  created_at TEXT NOT NULL,
  sdf_path TEXT,
  FOREIGN KEY (compound_id) REFERENCES compounds(compound_id)
);

CREATE TABLE IF NOT EXISTS conformers (
  conformer_id TEXT PRIMARY KEY,
  microstate_id TEXT NOT NULL,
  created_at TEXT NOT NULL,
  sdf_path TEXT NOT NULL,
  energy REAL,
  FOREIGN KEY (microstate_id) REFERENCES microstates(microstate_id)
);

CREATE TABLE IF NOT EXISTS poses (
  pose_id TEXT PRIMARY KEY,
  conformer_id TEXT NOT NULL,
  created_at TEXT NOT NULL,
  pdbqt_path TEXT NOT NULL,
  score REAL,
  FOREIGN KEY (conformer_id) REFERENCES conformers(conformer_id)
);

CREATE TABLE IF NOT EXISTS receptors (
  receptor_id TEXT PRIMARY KEY,
  name TEXT,
  created_at TEXT NOT NULL,
  path TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS external_refs (
  ref_id TEXT PRIMARY KEY,
  entity_id TEXT NOT NULL,
  system TEXT NOT NULL,
  external_id TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS systems (
  system_id TEXT PRIMARY KEY,
  microstate_id TEXT NOT NULL,
  created_at TEXT NOT NULL,
  engine TEXT NOT NULL,
  artifact_path TEXT NOT NULL,
  FOREIGN KEY (microstate_id) REFERENCES microstates(microstate_id)
);

CREATE TABLE IF NOT EXISTS artifacts (
  artifact_id TEXT PRIMARY KEY,
  kind TEXT NOT NULL,
  path TEXT NOT NULL,
  sha256 TEXT NOT NULL,
  created_at TEXT NOT NULL,
  run_id TEXT,
  FOREIGN KEY (run_id) REFERENCES runs(run_id)
);

CREATE TABLE IF NOT EXISTS edges (
  edge_id TEXT PRIMARY KEY,
  src_id TEXT NOT NULL,
  dst_id TEXT NOT NULL,
  relation TEXT NOT NULL,
  created_at TEXT NOT NULL,
  run_id TEXT,
  params_json TEXT,
  FOREIGN KEY (run_id) REFERENCES runs(run_id)
);

CREATE TABLE IF NOT EXISTS decisions (
  decision_id TEXT PRIMARY KEY,
  run_id TEXT NOT NULL,
  target_id TEXT NOT NULL,
  decision_type TEXT NOT NULL,
  rationale TEXT NOT NULL,
  params_json TEXT,
  created_at TEXT NOT NULL,
  FOREIGN KEY (run_id) REFERENCES runs(run_id)
);

CREATE TABLE IF NOT EXISTS anomalies (
  anomaly_id TEXT PRIMARY KEY,
  run_id TEXT NOT NULL,
  target_id TEXT NOT NULL,
  anomaly_type TEXT NOT NULL,
  details_json TEXT,
  created_at TEXT NOT NULL,
  FOREIGN KEY (run_id) REFERENCES runs(run_id)
);

CREATE TABLE IF NOT EXISTS atom_maps (
  map_id TEXT PRIMARY KEY,
  microstate_id TEXT NOT NULL,
  mapping_json TEXT NOT NULL,
  created_at TEXT NOT NULL,
  FOREIGN KEY (microstate_id) REFERENCES microstates(microstate_id)
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_compounds_reg_hash ON compounds(reg_hash);
CREATE INDEX IF NOT EXISTS idx_microstates_compound ON microstates(compound_id);
CREATE INDEX IF NOT EXISTS idx_conformers_microstate ON conformers(microstate_id);
CREATE INDEX IF NOT EXISTS idx_poses_conformer ON poses(conformer_id);
CREATE INDEX IF NOT EXISTS idx_edges_src ON edges(src_id);
CREATE INDEX IF NOT EXISTS idx_edges_dst ON edges(dst_id);

CREATE TRIGGER IF NOT EXISTS trg_edges_src_exists
BEFORE INSERT ON edges
BEGIN
  SELECT CASE WHEN
    NOT EXISTS (SELECT 1 FROM compounds WHERE compound_id = NEW.src_id)
    AND NOT EXISTS (SELECT 1 FROM microstates WHERE microstate_id = NEW.src_id)
    AND NOT EXISTS (SELECT 1 FROM conformers WHERE conformer_id = NEW.src_id)
    AND NOT EXISTS (SELECT 1 FROM poses WHERE pose_id = NEW.src_id)
    AND NOT EXISTS (SELECT 1 FROM systems WHERE system_id = NEW.src_id)
    AND NOT EXISTS (SELECT 1 FROM artifacts WHERE artifact_id = NEW.src_id)
    AND NOT EXISTS (SELECT 1 FROM receptors WHERE receptor_id = NEW.src_id)
  THEN RAISE(ABORT, 'edge src_id does not reference any known entity') END;
END;

CREATE TRIGGER IF NOT EXISTS trg_edges_dst_exists
BEFORE INSERT ON edges
BEGIN
  SELECT CASE WHEN
    NOT EXISTS (SELECT 1 FROM compounds WHERE compound_id = NEW.dst_id)
    AND NOT EXISTS (SELECT 1 FROM microstates WHERE microstate_id = NEW.dst_id)
    AND NOT EXISTS (SELECT 1 FROM conformers WHERE conformer_id = NEW.dst_id)
    AND NOT EXISTS (SELECT 1 FROM poses WHERE pose_id = NEW.dst_id)
    AND NOT EXISTS (SELECT 1 FROM systems WHERE system_id = NEW.dst_id)
    AND NOT EXISTS (SELECT 1 FROM artifacts WHERE artifact_id = NEW.dst_id)
    AND NOT EXISTS (SELECT 1 FROM receptors WHERE receptor_id = NEW.dst_id)
  THEN RAISE(ABORT, 'edge dst_id does not reference any known entity') END;
END;
