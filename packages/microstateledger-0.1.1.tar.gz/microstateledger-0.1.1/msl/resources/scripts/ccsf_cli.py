from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
from typing import List, Tuple

import numpy as np
from rdkit import Chem
from rdkit.Chem import AllChem, Descriptors, rdMolDescriptors

# Keras 3 needs backend set before import
os.environ.setdefault("KERAS_BACKEND", "tensorflow")
import keras  # noqa: E402


def ensure_3d(mol: Chem.Mol) -> Chem.Mol:
    mol = Chem.AddHs(mol, addCoords=True)
    if mol.GetNumConformers() == 0 or not mol.GetConformer().Is3D():
        params = AllChem.ETKDGv3()
        AllChem.EmbedMolecule(mol, params)
        try:
            AllChem.MMFFOptimizeMolecule(mol)
        except Exception:
            AllChem.UFFOptimizeMolecule(mol)
    return mol


def max_distance(mol: Chem.Mol) -> float:
    conf = mol.GetConformer()
    coords = []
    for atom in mol.GetAtoms():
        if atom.GetAtomicNum() == 1:
            continue
        pos = conf.GetAtomPosition(atom.GetIdx())
        coords.append([pos.x, pos.y, pos.z])
    if len(coords) < 2:
        return 0.0
    arr = np.asarray(coords, dtype=np.float32)
    diff = arr[:, None, :] - arr[None, :, :]
    dist = np.sqrt((diff * diff).sum(axis=-1))
    return float(dist.max())


def featurize(mol: Chem.Mol) -> List[float]:
    mw = float(Descriptors.MolWt(mol))
    rg = float(rdMolDescriptors.CalcRadiusOfGyration(mol))
    md = max_distance(mol)
    asa = float(rdMolDescriptors.CalcLabuteASA(mol))
    charge = float(Chem.GetFormalCharge(mol))
    return [mw, rg, md, asa, charge]


def load_mols(path: Path) -> List[Tuple[str, Chem.Mol]]:
    records: List[Tuple[str, Chem.Mol]] = []
    if path.is_dir():
        for sdf in sorted(path.glob("*.sdf")):
            mol = Chem.SDMolSupplier(str(sdf), removeHs=False)[0]
            if mol is None:
                continue
            records.append((str(sdf), mol))
    else:
        suppl = Chem.SDMolSupplier(str(path), removeHs=False)
        for i, mol in enumerate(suppl):
            if mol is None:
                continue
            records.append((f"{path}#{i}", mol))
    return records


def load_mols_from_list(list_path: Path) -> List[Tuple[str, Chem.Mol]]:
    records: List[Tuple[str, Chem.Mol]] = []
    for line in list_path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        sdf = Path(line)
        if not sdf.exists():
            continue
        mol = Chem.SDMolSupplier(str(sdf), removeHs=False)[0]
        if mol is None:
            continue
        records.append((str(sdf), mol))
    return records


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", default="", help="SDF file or directory")
    ap.add_argument("--list", default="", help="Text file with SDF paths")
    ap.add_argument("--model", default="", help="Path to ML_ccs.keras")
    ap.add_argument("--out", default="", help="Output JSON path")
    args = ap.parse_args()

    root = Path(__file__).resolve().parents[1]
    model_path = Path(args.model) if args.model else root / "tools" / "CCS_Focusing" / "models" / "ML_ccs.keras"

    if args.list:
        records = load_mols_from_list(Path(args.list))
    else:
        if not args.input:
            raise SystemExit("--input or --list required")
        records = load_mols(Path(args.input))
    if not records:
        raise SystemExit("no conformers found")

    feats = []
    paths = []
    for path, mol in records:
        mol = ensure_3d(mol)
        feats.append(featurize(mol))
        paths.append(path)

    feats_arr = np.asarray(feats, dtype=np.float32)

    model_loaded = True
    try:
        model = keras.models.load_model(model_path)
        preds = model.predict(feats_arr, verbose=0)
        preds = preds.reshape(-1)
    except Exception as exc:
        model_loaded = False
        # lightweight fallback: simple weighted sum for ranking
        weights = np.array([0.3, 8.0, 6.0, 0.05, 5.0], dtype=np.float32)
        preds = feats_arr @ weights
        preds = preds.reshape(-1)
        err = str(exc)
    else:
        err = ""

    result = []
    for path, feat, pred in zip(paths, feats, preds):
        result.append({
            "sdf_path": path,
            "ccs_pred": float(pred),
            "features": feat,
        })

    out = {
        "model_loaded": model_loaded,
        "model_path": str(model_path),
        "error": err,
        "scores": result,
    }

    out_json = json.dumps(out, ensure_ascii=False, indent=2)
    if args.out:
        Path(args.out).write_text(out_json, encoding="utf-8")
    else:
        print(out_json)


if __name__ == "__main__":
    main()
