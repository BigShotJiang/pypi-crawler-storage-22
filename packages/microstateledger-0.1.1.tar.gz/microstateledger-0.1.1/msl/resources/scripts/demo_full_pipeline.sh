#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

SMILES="${1:-CCO}"
NAME="${2:-demo}"

STAMP="$(date +%Y%m%d_%H%M%S)"
DEMO_DIR="$ROOT/demo_runs/$STAMP"
mkdir -p "$DEMO_DIR"

# Link shared resources into demo root.
ln -s "$ROOT/scripts" "$DEMO_DIR/scripts"
ln -s "$ROOT/schemas" "$DEMO_DIR/schemas"
ln -s "$ROOT/policies" "$DEMO_DIR/policies"

CFG="$DEMO_DIR/msl_demo.toml"
cat > "$CFG" <<EOF
[project]
name = "MicrostateLedgerDemo"
root = "$DEMO_DIR"
objects_dir = "objects"
runs_dir = "runs"
reports_dir = "reports"
policy = "$ROOT/policies/default.yaml"
ledger_db = "ledger.sqlite"

[envs]
conda = "/data/workplace/miniconda/bin/conda"
base_dir = "/data/workplace/wyx/MicrostateLedger/envs"

[logging]
level = "INFO"
log_dir = "logs"
EOF

./bin/msl init --config "$CFG"

CID="$(./bin/msl ingest "$SMILES" --name "$NAME" --config "$CFG")"
./bin/msl perceive "$CID" --config "$CFG"
./bin/msl enumerate "$CID" --config "$CFG"

export DEMO_DB="$DEMO_DIR/ledger.sqlite"

MID="$(python - <<'PY'
import os, sqlite3
conn = sqlite3.connect(os.environ["DEMO_DB"])
row = conn.execute("SELECT microstate_id FROM microstates ORDER BY created_at DESC LIMIT 1").fetchone()
print(row[0] if row else "")
PY
)"
if [[ -z "$MID" ]]; then
  echo "No microstate found" >&2
  exit 1
fi
export DEMO_MID="$MID"

./bin/msl conformers "$MID" --method rdkit --n 30 --config "$CFG"

XID="$(python - <<'PY'
import os, sqlite3
conn = sqlite3.connect(os.environ["DEMO_DB"])
row = conn.execute("SELECT conformer_id FROM conformers WHERE microstate_id = ? ORDER BY created_at DESC LIMIT 1", (os.environ["DEMO_MID"],)).fetchone()
print(row[0] if row else "")
PY
)"
if [[ -z "$XID" ]]; then
  echo "No conformer found" >&2
  exit 1
fi

./bin/msl dock-prep "$MID" "$XID" --config "$CFG"

mkdir -p "$DEMO_DIR/objects/receptors"
echo "RECEPTOR" > "$DEMO_DIR/objects/receptors/demo_receptor.pdb"

./bin/msl dock-ingest "$XID" "$DEMO_DIR/objects/docking/$MID/$XID/ligand.pdbqt" --score -7.5 --receptor-path "$DEMO_DIR/objects/receptors/demo_receptor.pdb" --receptor-name demo_rec --config "$CFG"
./bin/msl dock-select "$MID" --k 1 --config "$CFG"

./bin/msl charge "$MID" --method pype_resp --auto-qm --qm-engine auto --qm-theory "HF/6-31G*" --points-per-atom 60 --probe 1.4 --conformer-id "$XID" --config "$CFG"

./bin/msl md-param "$MID" --config "$CFG"
./bin/msl md-feedback "$MID" "$DEMO_DIR/objects/microstates/$CID/$MID/microstate.sdf" --config "$CFG"
./bin/msl md-transition "$MID" "$DEMO_DIR/objects/microstates/$CID/$MID/microstate.sdf" --config "$CFG"
./bin/msl prov-export --output "$DEMO_DIR/reports/prov_demo.json" --config "$CFG"

echo "Demo finished. Root: $DEMO_DIR Compound: $CID Microstate: $MID Conformer: $XID"
