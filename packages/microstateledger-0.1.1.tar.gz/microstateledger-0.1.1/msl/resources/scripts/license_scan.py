#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import re
import sys
from importlib import metadata
from pathlib import Path
from typing import Dict, Iterable, List, Set

try:
    import tomllib  # py3.11+
except ModuleNotFoundError:  # pragma: no cover
    import tomli as tomllib


def _normalize(name: str) -> str:
    return name.lower().replace("-", "_")


def _parse_req_name(req: str) -> str:
    # Rough parsing: take leading name before any version/extras markers
    m = re.split(r"[<>=!~\[]", req, maxsplit=1)
    return _normalize(m[0].strip())


def _load_project_deps(pyproject: Path, extras: Iterable[str]) -> Set[str]:
    data = tomllib.loads(pyproject.read_text(encoding="utf-8"))
    project = data.get("project", {})
    deps = project.get("dependencies", []) or []
    names = {_parse_req_name(d) for d in deps}
    opt = project.get("optional-dependencies", {}) or {}
    for extra in extras:
        for dep in opt.get(extra, []) or []:
            names.add(_parse_req_name(dep))
    return names


def _license_from_metadata(dist: metadata.Distribution) -> str:
    meta = dist.metadata
    lic = (meta.get("License") or "").strip()
    if lic and lic.lower() != "unknown":
        return lic
    classifiers = meta.get_all("Classifier") or []
    lic_classes = [c for c in classifiers if c.startswith("License ::")]
    if lic_classes:
        return "; ".join(lic_classes)
    return "UNKNOWN"


def _load_allowlist(path: Path) -> Dict[str, List[str]]:
    if not path.exists():
        return {"allow_missing": [], "allow_licenses": []}
    data = json.loads(path.read_text(encoding="utf-8"))
    return {
        "allow_missing": [
            _normalize(x) for x in data.get("allow_missing", []) if isinstance(x, str)
        ],
        "allow_licenses": [
            x for x in data.get("allow_licenses", []) if isinstance(x, str)
        ],
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Scan installed packages and licenses.")
    parser.add_argument("--output", required=True, help="Output file path (json/csv).")
    parser.add_argument(
        "--format",
        choices=["json", "csv"],
        default="json",
        help="Output format.",
    )
    parser.add_argument(
        "--project",
        type=Path,
        default=None,
        help="Optional pyproject.toml to filter to project deps.",
    )
    parser.add_argument(
        "--include-extras",
        default="",
        help="Comma-separated extras to include when filtering.",
    )
    parser.add_argument(
        "--allowlist",
        type=Path,
        default=None,
        help="Optional allowlist JSON with allow_missing/allow_licenses.",
    )
    parser.add_argument(
        "--strict",
        action="store_true",
        help="Fail if any license is UNKNOWN (unless allowlisted).",
    )
    args = parser.parse_args()

    include_extras = [e.strip() for e in args.include_extras.split(",") if e.strip()]
    filter_names: Set[str] = set()
    if args.project:
        filter_names = _load_project_deps(args.project, include_extras)

    allow_missing: Set[str] = set()
    allow_licenses: Set[str] = set()
    if args.allowlist:
        allow = _load_allowlist(args.allowlist)
        allow_missing = set(allow["allow_missing"])
        allow_licenses = set(allow["allow_licenses"])

    rows = []
    unknown = []
    for dist in metadata.distributions():
        name = dist.metadata.get("Name") or dist.metadata.get("Summary") or dist.name
        if not name:
            continue
        norm = _normalize(name)
        if filter_names and norm not in filter_names:
            continue
        lic = _license_from_metadata(dist)
        row = {
            "name": name,
            "version": dist.version,
            "license": lic,
            "summary": dist.metadata.get("Summary", ""),
        }
        rows.append(row)
        if lic == "UNKNOWN" and norm not in allow_missing:
            unknown.append(name)
        if allow_licenses and lic not in allow_licenses and lic != "UNKNOWN":
            unknown.append(name)

    rows.sort(key=lambda r: r["name"].lower())
    out_path = Path(args.output)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    if args.format == "json":
        out_path.write_text(json.dumps({"packages": rows}, indent=2), encoding="utf-8")
    else:
        with out_path.open("w", encoding="utf-8", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=["name", "version", "license", "summary"])
            writer.writeheader()
            writer.writerows(rows)

    if args.strict and unknown:
        sys.stderr.write("Unknown or disallowed licenses: " + ", ".join(sorted(set(unknown))) + "\n")
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
