from __future__ import annotations

import argparse
import json
from pathlib import Path

from rdkit import Chem
from rdkit.Chem import rdMolDescriptors


def _load_sdf(path: str) -> Chem.Mol:
    mol = Chem.SDMolSupplier(path, removeHs=False)[0]
    if mol is None:
        raise SystemExit(f"failed to read {path}")
    return mol


def _canonical_map(mol: Chem.Mol) -> dict[int, int]:
    mapping = {}
    for atom in mol.GetAtoms():
        cid = atom.GetAtomMapNum() or (atom.GetIdx() + 1)
        mapping[int(cid)] = atom.GetIdx()
    return mapping


def _chiral_map(mol: Chem.Mol, canon_map: dict[int, int]) -> dict[int, str]:
    centers = {}
    for idx, tag in Chem.FindMolChiralCenters(mol, includeUnassigned=True):
        cid = None
        for k, v in canon_map.items():
            if v == idx:
                cid = k
                break
        if cid is not None:
            centers[cid] = tag
    return centers


def _double_bond_stereo(mol: Chem.Mol, canon_map: dict[int, int]) -> dict[tuple[int, int], str]:
    stereo = {}
    for bond in mol.GetBonds():
        st = bond.GetStereo()
        if st == Chem.rdchem.BondStereo.STEREONONE:
            continue
        a = bond.GetBeginAtomIdx()
        b = bond.GetEndAtomIdx()
        cid_a = next((k for k, v in canon_map.items() if v == a), None)
        cid_b = next((k for k, v in canon_map.items() if v == b), None)
        if cid_a is None or cid_b is None:
            continue
        key = tuple(sorted((cid_a, cid_b)))
        stereo[key] = str(st)
    return stereo


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--ref", required=True)
    ap.add_argument("--probe", required=True)
    ap.add_argument("--map-json", default="")
    args = ap.parse_args()

    ref = _load_sdf(args.ref)
    probe = _load_sdf(args.probe)

    if args.map_json:
        mapping = json.loads(Path(args.map_json).read_text(encoding="utf-8"))
        canon_map = {int(m["canonical_atom_id"]): int(m["openmm_atom_index"]) for m in mapping}
    else:
        canon_map = _canonical_map(ref)

    ref_chiral = _chiral_map(ref, _canonical_map(ref))
    probe_chiral = _chiral_map(probe, canon_map)

    ref_db = _double_bond_stereo(ref, _canonical_map(ref))
    probe_db = _double_bond_stereo(probe, canon_map)

    chirality_changes = []
    for cid in sorted(set(ref_chiral) | set(probe_chiral)):
        if ref_chiral.get(cid) != probe_chiral.get(cid):
            chirality_changes.append(
                {
                    "canonical_atom_id": cid,
                    "ref": ref_chiral.get(cid),
                    "probe": probe_chiral.get(cid),
                }
            )

    double_bond_changes = []
    for key in sorted(set(ref_db) | set(probe_db)):
        if ref_db.get(key) != probe_db.get(key):
            double_bond_changes.append(
                {
                    "bond": key,
                    "ref": ref_db.get(key),
                    "probe": probe_db.get(key),
                }
            )

    ref_formula = rdMolDescriptors.CalcMolFormula(ref)
    probe_formula = rdMolDescriptors.CalcMolFormula(probe)
    formula_change = {
        "changed": ref_formula != probe_formula,
        "ref": ref_formula,
        "probe": probe_formula,
    }

    recommendations = []
    if chirality_changes:
        recommendations.append(
            {
                "action": "lock",
                "type": "lock_chirality",
                "message": "Detected chirality change. Consider adding improper restraints and re-parameterizing if needed.",
            }
        )
    if double_bond_changes:
        recommendations.append(
            {
                "action": "lock",
                "type": "lock_double_bond",
                "message": "Detected E/Z change. Consider enforcing bond stereo restraints or re-parameterizing.",
            }
        )
    if formula_change["changed"]:
        recommendations.append(
            {
                "action": "re-enumerate",
                "type": "formula_change",
                "message": "Detected formula/protonation change. Re-enumerate microstates and mark this branch unstable if persistent.",
            }
        )

    out = {
        "chirality_changes": chirality_changes,
        "double_bond_changes": double_bond_changes,
        "formula_change": formula_change,
        "recommendations": recommendations,
    }
    print(json.dumps(out, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
