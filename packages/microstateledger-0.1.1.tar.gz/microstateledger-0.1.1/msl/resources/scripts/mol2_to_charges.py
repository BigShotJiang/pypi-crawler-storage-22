from __future__ import annotations

import argparse
import json
from pathlib import Path


def parse_mol2_charges(path: Path) -> dict[int, float]:
    charges = {}
    in_atoms = False
    for line in path.read_text(encoding="utf-8").splitlines():
        if line.startswith("@<TRIPOS>ATOM"):
            in_atoms = True
            continue
        if line.startswith("@<TRIPOS>"):
            in_atoms = False
            continue
        if in_atoms and line.strip():
            parts = line.split()
            if len(parts) < 9:
                continue
            idx = int(parts[0])
            charge = float(parts[-1])
            charges[idx] = charge
    return charges


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--mol2", required=True)
    ap.add_argument("--atom-map", required=True)
    args = ap.parse_args()

    mol2_path = Path(args.mol2)
    charges_by_index = parse_mol2_charges(mol2_path)

    mapping = json.loads(Path(args.atom_map).read_text(encoding="utf-8"))
    charges = []
    for entry in mapping:
        atom_index = int(entry["atom_index"]) + 1
        charge = charges_by_index.get(atom_index, 0.0)
        charges.append({
            "canonical_atom_id": int(entry["canonical_atom_id"]),
            "charge": float(charge),
        })

    print(json.dumps(charges, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
