from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
from rdkit import Chem
from rdkit.Chem import AllChem
from openff.toolkit.topology import Molecule
from openff.toolkit.typing.engines.smirnoff import ForceField
from openff.interchange import Interchange
from openmm import XmlSerializer
from openff.units import unit


def _rdkit_from_mapped_smiles(mapped_smiles: str) -> Chem.Mol:
    mol = Chem.MolFromSmiles(mapped_smiles)
    if mol is None:
        raise SystemExit("failed to parse mapped smiles")
    return mol


def _rdkit_from_sdf(sdf_path: Path) -> Chem.Mol:
    suppl = Chem.SDMolSupplier(str(sdf_path), removeHs=False)
    mol = next((m for m in suppl if m is not None), None)
    if mol is None:
        raise SystemExit("failed to parse sdf")
    return mol


def _unlink_if_symlink(path: Path) -> None:
    try:
        if path.exists() and path.is_symlink():
            path.unlink()
    except Exception:
        pass


def _ensure_3d(rdmol: Chem.Mol) -> None:
    if rdmol.GetNumConformers() == 0:
        status = AllChem.EmbedMolecule(rdmol, randomSeed=0xC0FFEE)
        if status != 0:
            raise SystemExit("failed to embed 3D conformer")
        AllChem.UFFOptimizeMolecule(rdmol)
        return
    conf = rdmol.GetConformer()
    if not conf.Is3D():
        status = AllChem.EmbedMolecule(rdmol, randomSeed=0xC0FFEE)
        if status != 0:
            raise SystemExit("failed to embed 3D conformer")
        AllChem.UFFOptimizeMolecule(rdmol)
        return
    coords = np.asarray(conf.GetPositions(), dtype=float)
    if np.allclose(coords, 0.0):
        status = AllChem.EmbedMolecule(rdmol, randomSeed=0xC0FFEE)
        if status != 0:
            raise SystemExit("failed to embed 3D conformer")
        AllChem.UFFOptimizeMolecule(rdmol)


def _nonempty(path: Path) -> bool:
    return path.exists() and path.stat().st_size > 0


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--mapped-smiles", required=True)
    ap.add_argument("--sdf", default="")
    ap.add_argument("--out-dir", required=True)
    ap.add_argument("--forcefield", default="openff-2.1.0.offxml")
    ap.add_argument("--charges", default="")
    ap.add_argument("--box-size", type=float, default=40.0, help="Cubic box size (angstrom)")
    args = ap.parse_args()

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    if args.sdf:
        rdmol = _rdkit_from_sdf(Path(args.sdf))
    else:
        rdmol = _rdkit_from_mapped_smiles(args.mapped_smiles)
    formal_charge = Chem.GetFormalCharge(rdmol)
    map_nums = []
    for atom in rdmol.GetAtoms():
        map_num = atom.GetAtomMapNum() or (atom.GetIdx() + 1)
        map_nums.append(int(map_num))

    _ensure_3d(rdmol)

    # Build OFF molecule from RDKit to avoid explicit-H constraints in
    # from_mapped_smiles for this toolkit version.
    mol = Molecule.from_rdkit(
        rdmol,
        allow_undefined_stereo=True,
        hydrogens_are_explicit=False,
    )
    rdkit_map_nums = [int(a.GetAtomMapNum() or 0) for a in rdmol.GetAtoms()]
    atom_map_available = False
    try:
        for i, atom in enumerate(mol.atoms):
            if i < len(rdkit_map_nums):
                atom.atom_map = rdkit_map_nums[i]
                atom_map_available = True
    except Exception:
        atom_map_available = False
    if rdmol.GetNumConformers() > 0 and mol.n_conformers == 0:
        coords = rdmol.GetConformer().GetPositions()
        mol.add_conformer(unit.Quantity(coords, unit.angstrom))

    if args.charges:
        charges = json.loads(Path(args.charges).read_text(encoding="utf-8"))
        charge_map = {int(c["canonical_atom_id"]): float(c["charge"]) for c in charges if "canonical_atom_id" in c}
        per_atom = [0.0 for _ in range(mol.n_atoms)]
        if atom_map_available:
            for i, atom in enumerate(mol.atoms):
                cid = int(getattr(atom, "atom_map", 0) or 0)
                if cid in charge_map:
                    per_atom[i] = charge_map[cid]
        else:
            for i, cid in enumerate(map_nums):
                if i < len(per_atom):
                    per_atom[i] = charge_map.get(cid, 0.0)
        residual = float(formal_charge) - sum(per_atom)
        if abs(residual) > 1e-6:
            if mol.n_atoms > len(map_nums):
                n_h = mol.n_atoms - len(map_nums)
                corr = residual / n_h
                for i in range(len(map_nums), mol.n_atoms):
                    per_atom[i] += corr
            else:
                corr = residual / mol.n_atoms
                for i in range(mol.n_atoms):
                    per_atom[i] += corr
            print(f"WARN: charge residual {residual:.6f} distributed across atoms", file=sys.stderr)
        mol.partial_charges = unit.Quantity(per_atom, unit.elementary_charge)

    ff = ForceField(args.forcefield)
    if args.charges:
        interchange = Interchange.from_smirnoff(
            ff,
            mol.to_topology(),
            charge_from_molecules=[mol],
            allow_nonintegral_charges=True,
        )
    else:
        interchange = Interchange.from_smirnoff(ff, mol.to_topology())
    if mol.n_conformers > 0:
        interchange.positions = mol.conformers[0]

    if args.box_size and args.box_size > 0:
        size = float(args.box_size)
        interchange.box = unit.Quantity(np.eye(3) * size, unit.angstrom)

    system = interchange.to_openmm()
    system_xml = XmlSerializer.serialize(system)
    sys_xml_path = out_dir / "system.xml"
    _unlink_if_symlink(sys_xml_path)
    sys_xml_path.write_text(system_xml, encoding="utf-8")

    system_pdb = ""
    if mol.n_conformers > 0:
        system_pdb = str(out_dir / "system.pdb")
        _unlink_if_symlink(out_dir / "system.pdb")
        mol.to_file(system_pdb, file_format="PDB")

    gmx_top = ""
    gmx_gro = ""
    amber_prmtop = ""
    amber_inpcrd = ""
    try:
        gmx_prefix = out_dir / "system"
        interchange.to_gromacs(str(gmx_prefix))
        if _nonempty(out_dir / "system.top"):
            gmx_top = str(out_dir / "system.top")
        if _nonempty(out_dir / "system.gro"):
            gmx_gro = str(out_dir / "system.gro")
    except Exception:
        pass

    try:
        _unlink_if_symlink(out_dir / "system.prmtop")
        _unlink_if_symlink(out_dir / "system.inpcrd")
        amb_prefix = out_dir / "system"
        interchange.to_amber(str(amb_prefix))
        if _nonempty(out_dir / "system.prmtop"):
            amber_prmtop = str(out_dir / "system.prmtop")
        if _nonempty(out_dir / "system.inpcrd"):
            amber_inpcrd = str(out_dir / "system.inpcrd")
    except Exception:
        pass

    # post-check existing outputs
    if not gmx_top and _nonempty(out_dir / "system.top"):
        gmx_top = str(out_dir / "system.top")
    if not gmx_gro and _nonempty(out_dir / "system.gro"):
        gmx_gro = str(out_dir / "system.gro")
    if not amber_prmtop and _nonempty(out_dir / "system.prmtop"):
        amber_prmtop = str(out_dir / "system.prmtop")
    if not amber_inpcrd and _nonempty(out_dir / "system.inpcrd"):
        amber_inpcrd = str(out_dir / "system.inpcrd")

    mapping = []
    if atom_map_available:
        for i, atom in enumerate(mol.atoms):
            cid = int(getattr(atom, "atom_map", 0) or 0)
            if cid:
                mapping.append({"canonical_atom_id": int(cid), "openmm_atom_index": i})
    else:
        for i, cid in enumerate(map_nums):
            mapping.append({"canonical_atom_id": int(cid), "openmm_atom_index": i})
    atommap_path = out_dir / "atommap.json"
    _unlink_if_symlink(atommap_path)
    atommap_path.write_text(json.dumps(mapping, indent=2), encoding="utf-8")

    openmm_map = out_dir / "openmm.map.json"
    gromacs_map = out_dir / "gromacs.map.json"
    amber_map = out_dir / "amber.map.json"
    _unlink_if_symlink(openmm_map)
    openmm_map.write_text(json.dumps(mapping, indent=2), encoding="utf-8")
    if gmx_top or gmx_gro:
        gmx_mapping = []
        for m in mapping:
            gmx_entry = dict(m)
            gmx_entry["gromacs_atom_index"] = int(m["openmm_atom_index"]) + 1
            gmx_mapping.append(gmx_entry)
        _unlink_if_symlink(gromacs_map)
        gromacs_map.write_text(json.dumps(gmx_mapping, indent=2), encoding="utf-8")
    if amber_prmtop or amber_inpcrd:
        amber_mapping = []
        for m in mapping:
            amb_entry = dict(m)
            amb_entry["amber_atom_index"] = int(m["openmm_atom_index"]) + 1
            amber_mapping.append(amb_entry)
        _unlink_if_symlink(amber_map)
        amber_map.write_text(json.dumps(amber_mapping, indent=2), encoding="utf-8")

    print(json.dumps({
        "system_xml": str(out_dir / "system.xml"),
        "system_pdb": system_pdb,
        "atommap": str(atommap_path),
        "openmm_map": str(openmm_map),
        "gromacs_map": str(gromacs_map) if gromacs_map.exists() else "",
        "amber_map": str(amber_map) if amber_map.exists() else "",
        "gromacs_top": gmx_top,
        "gromacs_gro": gmx_gro,
        "amber_prmtop": amber_prmtop,
        "amber_inpcrd": amber_inpcrd,
    }))


if __name__ == "__main__":
    main()
