from __future__ import annotations

import argparse
import json
import subprocess
from pathlib import Path
import os

conda_prefix = os.environ.get("CONDA_PREFIX", "")
if conda_prefix:
    lib_path = str(Path(conda_prefix) / "lib")
    ld_path = os.environ.get("LD_LIBRARY_PATH", "")
    if lib_path not in ld_path.split(":"):
        os.environ["LD_LIBRARY_PATH"] = lib_path + (":" + ld_path if ld_path else "")
    try:
        import ctypes
        libstdcpp = Path(conda_prefix) / "lib" / "libstdc++.so.6"
        if libstdcpp.exists():
            ctypes.CDLL(str(libstdcpp), mode=ctypes.RTLD_GLOBAL)
    except Exception:
        pass

from rdkit import Chem
from rdkit.Chem import AllChem


def read_mol(sdf_path: Path) -> Chem.Mol:
    suppl = Chem.SDMolSupplier(str(sdf_path), removeHs=False, sanitize=False)
    mol = next((m for m in suppl if m is not None), None)
    if mol is None:
        raise SystemExit("failed to read mol")
    try:
        Chem.SanitizeMol(mol)
    except Exception:
        # keep unsanitized molecule; still try to proceed with SMILES
        pass
    return mol


def mol_to_smiles(sdf_path: Path) -> str:
    mol = read_mol(sdf_path)
    try:
        return Chem.MolToSmiles(mol)
    except Exception:
        return Chem.MolToSmiles(mol, canonical=True, isomericSmiles=True)


def infer_charge_mode(mol: Chem.Mol) -> str:
    try:
        charge = Chem.GetFormalCharge(mol)
    except Exception:
        charge = 0
    if charge < 0:
        return "[M-H]-"
    return "[M+H]+"


def convert_xyz_to_sdf(xyz_path: Path, sdf_path: Path) -> None:
    cmd = ["obabel", str(xyz_path), "-O", str(sdf_path)]
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        raise RuntimeError(f"obabel failed: {result.stderr}")




def has_clash(mol: Chem.Mol, min_dist: float = 0.7) -> bool:
    if mol.GetNumConformers() == 0:
        return False
    conf = mol.GetConformer()
    bonded = set()
    for bond in mol.GetBonds():
        a = bond.GetBeginAtomIdx()
        b = bond.GetEndAtomIdx()
        if a > b:
            a, b = b, a
        bonded.add((a, b))
    heavy = [a.GetIdx() for a in mol.GetAtoms() if a.GetAtomicNum() > 1]
    for i, ai in enumerate(heavy):
        pos_i = conf.GetAtomPosition(ai)
        for aj in heavy[i+1:]:
            a, b = (ai, aj) if ai < aj else (aj, ai)
            if (a, b) in bonded:
                continue
            pos_j = conf.GetAtomPosition(aj)
            dx = pos_i.x - pos_j.x
            dy = pos_i.y - pos_j.y
            dz = pos_i.z - pos_j.z
            if dx*dx + dy*dy + dz*dz < min_dist*min_dist:
                return True
    return False


def uff_energy(mol: Chem.Mol) -> float:
    try:
        ff = AllChem.UFFGetMoleculeForceField(mol)
        if ff is None:
            return 0.0
        return float(ff.CalcEnergy())
    except Exception:
        return 0.0


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    ap.add_argument("--out-dir", required=True)
    ap.add_argument("--n", type=int, default=50)
    ap.add_argument("--prune_rmsd", type=float, default=0.5)
    ap.add_argument("--experimental-ccs", default="0")
    args = ap.parse_args()

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    sdf_path = Path(args.input)
    mol = read_mol(sdf_path)

    smiles = Chem.MolToSmiles(mol)
    charge_mode = infer_charge_mode(mol)

    work_dir = out_dir / "_peas_work"
    work_dir.mkdir(parents=True, exist_ok=True)
    summary_path = work_dir / "peas_summary.json"

    script = Path(__file__).resolve().parent / "peas_full.py"
    cmd = [
        "python",
        str(script),
        "--name",
        sdf_path.stem,
        "--smiles",
        smiles,
        "--charge-mode",
        charge_mode,
        "--work-dir",
        str(work_dir),
        "--experimental-ccs",
        str(args.experimental_ccs),
        "--nconf",
        str(max(args.n, 1)),
        "--summary",
        str(summary_path),
    ]

    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        raise RuntimeError(f"PEAS failed:\nSTDOUT:\n{result.stdout}\nSTDERR:\n{result.stderr}")

    if not summary_path.exists():
        raise RuntimeError("PEAS summary not found")

    summary = json.loads(summary_path.read_text(encoding="utf-8"))
    selected_xyz = summary.get("selected_xyz", [])

    if not selected_xyz:
        # fallback: grab any xyz under work_dir/Completed_Job
        selected_xyz = [str(p) for p in work_dir.rglob("*.xyz")]

    conformers = []
    clash_filtered = 0
    for i, xyz in enumerate(selected_xyz[: args.n]):
        sdf_out = out_dir / f"peas_conf_{i}.sdf"
        convert_xyz_to_sdf(Path(xyz), sdf_out)
        mol_conf = read_mol(sdf_out)
        if has_clash(mol_conf):
            clash_filtered += 1
            continue
        energy = uff_energy(mol_conf)
        conformers.append({"sdf_path": str(sdf_out), "energy": energy})

    if not conformers and selected_xyz:
        sdf_out = out_dir / "peas_conf_0.sdf"
        convert_xyz_to_sdf(Path(selected_xyz[0]), sdf_out)
        conformers.append({"sdf_path": str(sdf_out), "energy": 0.0})

    print(json.dumps({"conformers": conformers, "note": "PEAS full pipeline", "clash_filtered": clash_filtered}))


if __name__ == "__main__":
    main()
