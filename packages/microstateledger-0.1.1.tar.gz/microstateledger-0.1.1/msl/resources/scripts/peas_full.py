from __future__ import annotations

import argparse
import os
import shutil
from pathlib import Path


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--name', required=True, help='Molecule name')
    ap.add_argument('--smiles', default='', help='SMILES string')
    ap.add_argument('--xyz', default='', help='Input XYZ file path')
    ap.add_argument('--charge-mode', default='[M+H]+', choices=['[M+H]+','[M-H]-'])
    ap.add_argument('--work-dir', default='.', help='Working directory')
    ap.add_argument('--experimental-ccs', default='0', help='Experimental CCS value (float)')
    ap.add_argument('--nconf', default='1000', help='Number of conformers for OpenBabel')
    ap.add_argument('--summary', default='', help='Write summary JSON path')
    args = ap.parse_args()

    work_dir = Path(args.work_dir).resolve()
    work_dir.mkdir(parents=True, exist_ok=True)
    os.chdir(work_dir)

    conda_prefix = os.environ.get("CONDA_PREFIX", "")
    if conda_prefix:
        lib_path = str(Path(conda_prefix) / "lib")
        ld_path = os.environ.get("LD_LIBRARY_PATH", "")
        if lib_path not in ld_path.split(":"):
            os.environ["LD_LIBRARY_PATH"] = lib_path + (":" + ld_path if ld_path else "")
        try:
            import ctypes
            libstdcpp = Path(conda_prefix) / "lib" / "libstdc++.so.6"
            if libstdcpp.exists():
                ctypes.CDLL(str(libstdcpp), mode=ctypes.RTLD_GLOBAL)
        except Exception:
            pass

    molecule_name = args.name
    molecule_name = molecule_name.replace(' ', '')
    smile = args.smiles
    charge_mode = args.charge_mode
    Experimental_CCS = float(args.experimental_ccs)
    nconf = int(args.nconf)

    # resource staging
    env_root = os.environ.get("MSL_TOOLS_ROOT", "").strip()
    root = Path(env_root).resolve() if env_root else Path(__file__).resolve().parents[1]
    if not (root / "tools").exists():
        for cand in [Path.cwd(), *Path.cwd().parents]:
            if (cand / "tools").exists():
                root = cand
                break
    seer_models = root / 'tools' / 'SEER' / 'models'
    seer_data = root / 'tools' / 'SEER' / 'data'
    ccsf_root = root / 'tools' / 'CCS_Focusing'

    def ensure_file(src: Path, dst: Path):
        if not dst.exists():
            shutil.copy(src, dst)

    ensure_file(seer_models / 'seer_pos_model.zip', work_dir / 'seer_pos_model.zip')
    ensure_file(seer_models / 'seer_neg_model.zip', work_dir / 'seer_neg_model.zip')
    ensure_file(seer_data / 'pos_chargedatasetX2.csv', work_dir / 'pos_chargedatasetX2.csv')
    ensure_file(seer_data / 'neg_chargedatasetX2.csv', work_dir / 'neg_chargedatasetX2.csv')
    ensure_file(ccsf_root / 'models' / 'ML_ccs.keras', work_dir / 'ML_ccs.keras')
    ensure_file(ccsf_root / 'error.csv', work_dir / 'error.csv')

    # fall through to notebook logic

    
    
    from chemml.chem import Molecule
    from chemml.datasets import load_organic_density
    
    
    try:
    
      import ydf
    except:
      pass
    
    import ydf
    
    
    
    
    
    
    
    import pandas as pd
    import py3Dmol
    from tensorflow import keras
    from numpy.core.arrayprint import printoptions
    import tensorflow as tf
    import numpy as np
    try:
      np.set_printoptions(precision=3, suppress=True)
    except:
      pass
    try:
      import pymol
    except:
      pass
    
    
    
    folder_name = molecule_name + '_folder'
    file_name = folder_name
    
    import rdkit
    import chemml
    import tensorflow as tf
    try:
      np.set_printoptions(precision=3, suppress=True)
    except:
      pass
    from chemml.chem import Molecule
    import pandas as pd
    import py3Dmol
    from tensorflow import keras
    import tensorflow as tf
    import numpy as np
    from chemml.chem import Molecule
    from chemml.datasets import load_organic_density
    from openbabel import pybel
    # import os
    import pymol
    import ydf
    # import os
    import ase
    from numpy.core.arrayprint import printoptions
    import pymol
    import pandas as pd
    import numpy as np
    from ase import io
    from ase.io import read, write
    # import os
    # import shutil
    import __main__
    __main__.pymol_argv = ['pymol','-qc']
    import pymol
    from pymol import cmd, stored
    pymol.finish_launching(['pymol','-qc'])
    from datetime import date
    from datetime import datetime
    from timeit import default_timer as timer
    import time
    import pytz
    import glob
    import zipfile
    
    
    mol_file = "{}.xyz".format(molecule_name)
    # Input handling
    xyz_input = args.xyz
    if xyz_input:
        xyz_path = Path(xyz_input)
        if not xyz_path.exists():
            raise SystemExit(f'XYZ not found: {xyz_path}')
        shutil.copy(xyz_path, mol_file)
    else:
        if not smile:
            raise SystemExit('Either --smiles or --xyz is required')
    
        mol = pybel.readstring("smi", smile)
        mol.addh()
        if charge_mode == "[M+H]+":
          mol.make3D(forcefield='MMFF94')
          mol.localopt(forcefield='GAFF', steps=1000)
        if charge_mode == "[M-H]-" and "P" in smile.upper():
          step = int(len(mol.atoms)*1000)
          mol.make3D(forcefield='MMFF94', steps=step)
          mol.localopt(forcefield='MMFF94', steps=step)
        if charge_mode == "[M-H]-" and "P" not in smile.upper():
          step = int(len(mol.atoms)*1000)
          mol.make3D(forcefield='GAFF', steps=step)
          mol.localopt(forcefield='GAFF', steps=step)
        
        try:
          mol.write("xyz", mol_file)
        except:
          print("File of molecule already exist")
          pass
        
    chk_file = open(mol_file)
    corr_file = open("{}_.xyz".format(molecule_name),"w")
    for c in chk_file:
      try:
        if c.split()[0]!="":
          print(c.strip(),file=corr_file)
      except:
        print(molecule_name, file=corr_file)
    corr_file.close()
    
    try:
        os.remove(mol_file)
        os.rename("{}_.xyz".format(molecule_name),"{}.xyz".format(molecule_name))
    except:
      pass
    
    
    try:
      with zipfile.ZipFile('seer_pos_model.zip', 'r') as zip_:
        zip_.extractall('seer_pos_model')
    except:
      pass
    try:
      with zipfile.ZipFile('seer_neg_model.zip', 'r') as zip_:
        zip_.extractall('seer_neg_model')
    except:
      pass
    
    
    if charge_mode == "[M+H]+":
      model5 = ydf.load_model("seer_pos_model")
      train_file = "pos_chargedatasetX2.csv"
    if charge_mode == "[M-H]-":
      model5 = ydf.load_model("seer_neg_model")
      train_file = "neg_chargedatasetX2.csv"
    
    
    
    
    try:
      os.makedirs(folder_name)
    except FileExistsError:
      pass
    
    try:
      shutil.move("predict/{}".format(data_files[0]),
                  "run_hist/{}".format(folder_name,rename_ ))
    except:
      pass
    
    shutil.rmtree
    try:
      shutil.rmtree("test_data")
    except:
      pass
    
    try:
      shutil.rmtree("predict")
    except:
      pass
    
    try:
      if molecule_name+".xyz" in os.listdir(str(work_dir)):
        shutil.move(molecule_name+".xyz", folder_name)
      else:
        if glob.glob("*.xyz")[0] in (os.listdir(str(work_dir))):
          shutil.move(glob.glob("*.xyz")[0], folder_name)
    except:
      try:
        if glob.glob("*.xyz")[0] in (os.listdir(str(work_dir))):
          shutil.move(glob.glob("*.xyz")[0], folder_name)
      except:
        pass
    
    start = timer()
    time_initiated = datetime.now(pytz.timezone('America/Los_Angeles')).strftime("%H:%M:%S     %d-%b-%Y")
    
    
    import re
    import math
    import csv
    # import os
    start = timer()
    time_initiated = datetime.now(pytz.timezone('America/Los_Angeles')).strftime("%H:%M:%S     %d-%b-%Y")
    
    
    
    Name = file_name
    d = len(os.listdir("{}/".format(Name)))
    id = os.listdir("{}/".format(Name))
    
    
    COM_list,mass_list,conf_num,surface_area= ([],[],
                                               [],[])
    
    for i in range(d):
      try:
        if id[i][-3:].lower()!="csv":
    
          cartesian_file= "{}/{}".format(Name,id[i])
          mol = ase.io.read(cartesian_file)
    
          COM = mol.get_center_of_mass(scaled=False)
          COM_list.append(COM)
    
          mol_mass = mol.get_masses()
          mass_list.append(sum(mol_mass))
          cmd.load("{}/{}".format(Name, id[i]))
          cmd.set('dot_solvent', 0)
          cmd.set('dot_density',2)
          new_id=re.sub("[^0-9]", "", id[i])
          conf_num.append(new_id)
    
          sa=cmd.get_area('all')
          total_atom=cmd.count_atoms()
          surface_area.append(sa)
    
      except OSError:
        pass
      cmd.reinitialize()
    
    COM_List=[]
    for co in COM_list:
      COM_List.append((co[0],co[1],co[2]))
    
    
    
    
    import statistics
    from statistics import mode
    Name=file_name
    id3 = os.listdir("{}/".format(Name))
    id2 = [i for i in id3 if i != '.ipynb_checkpoints']
    
    
    def EN_moments(a):
      M_x=0
      M_y=0
      M_z=0
      total_EN=0
      for i in range(len(a)):
        M_x +=float(atomic_EN[xyz_list[i][0]])*float(xyz_list[i][1])
        M_y +=float(atomic_EN[xyz_list[i][0]])*float(xyz_list[i][2])
        M_z +=float(atomic_EN[xyz_list[i][0]])*float(xyz_list[i][3])
        total_EN += atomic_EN[xyz_list[i][0]]
      return M_x, M_y, M_z, total_EN
    
    def center_of_EN(M_x, M_y, M_z, total_EN):
      EN_COM=[]
      for i in range(len(xyz_list)):
        X_EN = M_x/total_EN
        Y_EN = M_y/total_EN
        Z_EN = M_z/total_EN
      return X_EN,Y_EN,Z_EN
    
    
    molecule_dict,proton_coord,dub_list,H_distance=([],[],
                                                    [],[])
    
    fi_name,conf_nu,conf_list,bond_count=([],[],
                                          [],[])
    
    for I in id2:
    
      if I[-3:].lower()=="xyz":
        try:
          confn= I.split(".")[0]
          coord = open("{}/{}".format(Name,I))
          conf_list.append(I)
          at_coord = []
          for line in coord:
              line = line.split()
    
              if len(line) > 2:
                  at_coord.append(line)
        except:
          pass
    
        candidate_O_lis,charge_site,index_min =([],[],[])
        index_min2,bond_count,bond_count_O=([],[],[])
    
        for i in range(len(at_coord)):
          hetero_list=[]
          index_carb=[]
          count_O=0
          if at_coord[i][0] == "O" :
            for i2 in range(len(at_coord)):
              C=0
              H=0
              C2=0
              if at_coord[i2][0] !="O":
                try:
                  x = float(at_coord[i][1]) - float(at_coord[i2][1])
                  y = float(at_coord[i][2]) - float(at_coord[i2][2])
                  z = float(at_coord[i][3]) - float(at_coord[i2][3])
                  distance = (x**2 + y**2 + z**2)**0.5
                except:
                  pass
                if distance <1.2 and count_O==0 and charge_mode =="[M-H]-":
                  count_O+=1
                  index_carb.append((i,distance))
                  index_min.append((distance,at_coord[i]))
                if distance <1.6 and count_O==0 and charge_mode =="[M+H]+":
                  count_O+=1
                  index_carb.append((i,distance))
                  index_min.append((distance,at_coord[i]))
    
            hetero_list.append(at_coord[i2])
    
          count_N=0
    
          if at_coord[i][0] == "N" :
            conf_nu.append(I)
            hetero_list.append(at_coord[i])
            for i3 in range(len(at_coord)):
              if at_coord[i3][0] != "N" :
                try:
                  x = float(at_coord[i][1]) - float(at_coord[i3][1])
                  y = float(at_coord[i][2]) - float(at_coord[i3][2])
                  z = float(at_coord[i][3]) - float(at_coord[i3][3])
                  distance2 = (x**2 + y**2 + z**2)**0.5
                except:
                  pass
                if distance2 <1.2 and count_N==0 and charge_mode =="[M-H]-":
                  count_N+=1
                  index_min2.append((distance2,at_coord[i]))
                  bond_count.append(count_N)
                if distance2 <1.6 and count_N==0 and charge_mode =="[M+H]+":
                  count_N+=1
                  index_min2.append((distance2,at_coord[i]))
                  bond_count.append(count_N)
    
    
      charge_count=0
    
      for i4 in range(len(index_min2)):
        proton_coord.append((index_min2[i4][1]))
        fi_name.append(I)
        molecule_dict.append((I,index_min2[i4][1]))
    
      for i in range(len(index_min)):
        fi_name.append(I)
        proton_coord.append((index_min[i][1]))
        molecule_dict.append((I,index_min[i][1]))
    
    atomic_radi= ({"C":1.70, "O":1.52, "H": 1.20, "N":1.55, "F":1.35,"Cl":1.75,
              "Br":1.83, "I":1.98, "S":1.80, "P":1.80, "Se":1.90})
    atomic_mass = ({"C":12.011, "O":15.999, "H":1.0080, "N":14.007, "F":18.99840316,
              "Cl":35.45,"Br":79.9 ,"I":126.9045,"S":32.07,"P":30.97, "Se": 78.97})
    atomic_EN = ({"C":2.55, "O":3.44, "H":2.20, "N":3.04, "F":3.98,"Cl":3.16,
              "Br":2.96 , "I":2.66 ,"S":2.58,"P":3.15, "Se":2.55})
    atomic_pol = {"O":5.3, "N":7.4, "S":19.4, "P":25, "Se":29}
    
    
    Name = file_name
    
    Halogen_list=["F","Cl","Br","I"]
    othergen_list=["S","P","Se"]
    d = len(os.listdir("{}/".format(Name)))
    id = os.listdir("{}/".format(Name))
    
    
    COM_list1= []
    try:
      id.remove('.ipynb_checkpoints')
    except ValueError:
      pass
    
    action_dist1,action_dist2,total_C,total_O=([],[],[],[])
    total_N,total_H,total_Halogen,total_othergen=([],[],[],[])
    C,O,N,H,Halo,other,COE_list=(0,0,0,0,0,0,[])
    
    
    for e in range(len(id)):
      H_atom,C_atom,O_atom=([],[],[])
      N_atom,Halo_atom,other_atom=([],[],[])
      if id[e][-3:].lower()!="csv":
        xyz_file = open("{}/{}".format(Name, id[e]))
        xyz_list=[]
        tru_list=[]
        for x in xyz_file:
          X = x.split()
          try:
            if X[0].isalpha() and not X[2].isalpha():
              xyz_list.append(X)
          except IndexError:
            next
    
        for a in xyz_list:
          if a[0] =="H":
            H=+1
            H_atom.append(H)
          if a[0] =="C":
            C=+1
            C_atom.append(C)
          if a[0] =="O":
            O=+1
            O_atom.append(O)
          if a[0] =="N":
            N=+1
            N_atom.append(N)
          if a[0] in Halogen_list:
            Halo=+1
            Halo_atom.append(Halo)
          if a[0] in othergen_list:
            other=+1
            other_atom.append(other)
    
        M_x, M_y, M_z, total_EN = EN_moments(a)
        EN_COM = center_of_EN(M_x, M_y, M_z, total_EN)
    
        COE_list.append(EN_COM)
        total_C.append(sum(C_atom))
        total_O.append(sum(O_atom))
        total_N.append(sum(N_atom))
        total_H.append(sum(H_atom))
        total_Halogen.append(sum(Halo_atom))
        total_othergen.append(sum(other_atom))
    
        percen_C= (sum(C_atom)/(len(xyz_list)))
        percen_O= (sum(O_atom)/(len(xyz_list)))
        percen_C= (sum(C_atom)/(len(xyz_list)))
        percen_H= (sum(H_atom)/(len(xyz_list)))
    
        dist_list =[]
        dist_list2=[]
        for n in range(len(xyz_list)):
    
          for n2 in range(len(xyz_list)):
    
            dist = ((((float(xyz_list[n][1])-float(xyz_list[n2][1]))**2)+
             ((float(xyz_list[n][2])-float(xyz_list[n2][2]))**2)+
              ((float(xyz_list[n][3])-float(xyz_list[n2][3]))**2))**(1/2))
            dist_list.append((dist,n,n2,))
            dist_list2.append(dist)
    
        far_coor1, far_coor2=xyz_list[max(dist_list)[1]],xyz_list[max(dist_list)[2]]
    
    center_of_dict={}
    for E in range(len(id)):
      center_of_dict[id[E]]=COM_List[E],COE_list[E]
    
    
    
    
    import math
    
    def find_angle(molecule_dict,center_of_dict):
      angle_list=[]
      for i in range(len(molecule_dict)):
        COM_List=center_of_dict[molecule_dict[i][0]][0]
        COE_list=center_of_dict[molecule_dict[i][0]][1]
        proton_coord=molecule_dict[i][1]
        AB_=float(COE_list[0])-float(proton_coord[1]),float(COE_list[1])-float(proton_coord[2]),float(COE_list[2])-float(proton_coord[3])
        BC_=float(proton_coord[1])-COM_List[0],float(proton_coord[2])-COM_List[1],float(proton_coord[3])-COM_List[2]
        AB__BC=AB_[0]*BC_[0]+AB_[1]*BC_[1]+AB_[2]*BC_[2]
        AB=(AB_[0]**2+AB_[1]**2+AB_[2]**2)**0.5
        BC=(BC_[0]**2+BC_[1]**2+BC_[2]**2)**0.5
        AB_BC=math.acos((AB__BC)/(AB*BC))*(180/math.pi)
        angle_list.append(AB_BC)
      return angle_list
    
    def distances(molecule_dict,center_of_dict):
      distance1=[]
      distance2=[]
      distance3=[]
      for i in range(len(molecule_dict)):
        COM_List=center_of_dict[molecule_dict[i][0]][0]
        COE_list=center_of_dict[molecule_dict[i][0]][1]
        proton_coord=molecule_dict[i][1]
        distance_1= (((COE_list[0]-float(proton_coord[1]))**2)+((COE_list[1]-float(proton_coord[2]))**2)+((COE_list[2]-float(proton_coord[3]))**2))
        distance_2= (((COM_List[0]-float(proton_coord[1]))**2)+((COM_List[1]-float(proton_coord[2]))**2)+((COM_List[2]-float(proton_coord[3]))**2))
        distance_3= (((COE_list[0]-COM_List[0])**2)+((COE_list[1]-COM_List[1])**2)+((COE_list[2]-COM_List[2])**2))
        distance1.append(distance_1)
        distance2.append(distance_2)
        distance3.append(distance_3)
      return distance1,distance2,distance3
    
    
    angle_list = find_angle(molecule_dict,center_of_dict)
    distance1,distance2,distance3 = distances(molecule_dict,center_of_dict)
    
    COE_dist_list = distance1
    COM_dist_list = distance2
    COM_COE_distance = distance3
    
    mol_feats={}
    for s in range(len(id)):
      mol_feats[id[s].split(".")[0]]=(surface_area[s],total_O[s],total_N[s],
                                      total_Halogen[s],total_othergen[s])
    
    # training_file = "Test_charge" # @param {type:"string"}
    try:
      os.mkdir("test_data")
    except:
      pass
    try:
      os.rmdir("test_data/.ipynb_checkpoints")
    except:
      pass
    
    for n in range(len(fi_name)):
      mol_name=fi_name[n].split(".")[0]
      testfile_name='test_data/{}.csv'.format(mol_name)
      f = open(testfile_name, 'a')
      print("{},{},{},{},{},{},{},{},{},{}".format(atomic_pol[proton_coord[n][0]],
           COM_dist_list[n], COE_dist_list[n],COM_COE_distance[n],angle_list[n],
           mol_feats[mol_name][0],mol_feats[mol_name][1],mol_feats[mol_name][2],
           mol_feats[mol_name][3], mol_feats[mol_name][4]),file=f)
      f.close()
    
    import ydf
    import pandas as pd
    
    def weight_option(charge_mode):
      if charge_mode =="[M+H]+":
        weights= "COM_Dist"
      else:
        weights="COM_Dist"
      return weights
    
    def learn_depth(charge_mode):
      if charge_mode =="[M+H]+":
        max_depth= 8
      if charge_mode =="[M+H]+" and (sum(total_othergen)>0 or sum(total_Halogen)>0):
        max_depth= 10
      if charge_mode =="[M-H]-":
        max_depth= 10
      if charge_mode =="[M-H]-" and (sum(total_othergen)>0 or sum(total_Halogen)>0):
        max_depth= 12
      return max_depth
    
    
    column_names = (['Atomic_pol','COM_Dist','COE_Dist','COM2COE_Dist','Interaction_Angle',
    'MSA','Total_O','Total_N','Total_Halogen','Total_Othergen','CCS','Rel_Energy'])
    reg_data = pd.read_csv("{}".format(train_file), names=column_names)
    
    reg_data.pop('CCS')
    reg_data1 = reg_data.copy()
    reg_test = reg_data1.pop('Rel_Energy')
    train_data = reg_data
    test_data = reg_data
    
    model5 = ydf.GradientBoostedTreesLearner(label='Rel_Energy',
                                    task=ydf.Task.REGRESSION, num_trees=300,
        growing_strategy="BEST_FIRST_GLOBAL",
        max_depth=learn_depth(charge_mode),
        sampling_method="RANDOM",
        weights=weight_option(charge_mode),
        split_axis="SPARSE_OBLIQUE",
        categorical_algorithm="RANDOM",).train(train_data)
    
    assert model5.task() == ydf.Task.REGRESSION
    
    evaluation = model5.evaluate(test_data)
    
    rmse=[]
    rmse.append(evaluation)
    rms=[]
    
    fi =open("rms", "w")
    for r in rmse:
      print(r, file=fi)
    fi.close()
    
    rm =open("rms")
    for r in rm:
      if r.split(":")[0]=="RMSE":
        rms.append(r.split(":")[1])
    
    rmse_=rms[0].replace("\n","")
    
    
    
    def ML_predict(data_files):
      column_names2=(['Atomic_pol','COM_Dist','COE_Dist','COM2COE_Dist',
      'Interaction_Angle','MSA','Total_O','Total_N','Total_Halogen', 'Total_Othergen'])
      test_data1 =pd.read_csv("test_data/{}".format(data_files), names=column_names2)
      test_results={}
      reg_pred = model5.predict(test_data1)
      test_data1['Predicted_Energy']=reg_pred/float(rmse_)
      modified_pred = list(reg_pred/float(rmse_))
      return test_data1, modified_pred
    
    def get_test_results(modified_pred_dict,molecule_dict, id):
      test_results={}
      molecule_dict
      posit_count=0
      for t in range(len(molecule_dict)):
        if molecule_dict[t][0]==id:
          try:
            test_results[modified_pred_dict[id][posit_count]]=molecule_dict[t]
            posit_count+=1
          except:
            posit_count-=1
            pass
        else:
          posit_count=0
      return test_results
    
    def get_min_score(pred_file,rmse_):
      test_data1 =pd.read_csv("predict/{}".format(pred_file))
      denom = (test_data1['Predicted_Energy'].var()+test_data1['Predicted_Energy'].std())
      try:
        denom_val = float(denom)
      except Exception:
        denom_val = 0.0
      if denom_val == 0.0 or denom_val != denom_val:
        denom_val = 1.0
      min_confidence_score =(int(round((min(test_data1['Predicted_Energy'])/
      denom_val+
      (float(rmse_)/3)),0))+0)
      if min_confidence_score == 0 :
        return 1
      else:
        return min_confidence_score
    
    try:
      os.mkdir("predict")
    except:
      pass
    
    try:
      os.rmdir("predict/.ipynb_checkpoints")
    except:
      pass
    
    modified_pred_list=[]
    data_files=os.listdir("test_data")
    modified_pred_dict={}
    for d in range(len(data_files)):
      test_data1, modified_pred= ML_predict(data_files[d])
      modified_pred_dict[data_files[d].replace("csv",'xyz')]=modified_pred
      modified_pred_list.append(modified_pred)
      test_data1.to_csv("predict/{}".format(data_files[d]), index=False)
    
    
    test_results_lis=[]
    for d in range(len(id)):
      test_results = get_test_results(modified_pred_dict,molecule_dict,id[d])
      test_results_lis.append(test_results)
      pred_file=os.listdir("predict")
    
    
    thresh_list=[]
    for t in range(len(pred_file)):
      thresh_1 = get_min_score(pred_file[t],rmse_)
      thresh_list.append(thresh_1)
    
    sorted_PE_list=[]
    for t in range(len(test_results_lis)):
      sorted_PE_list.append(sorted(test_results_lis[t].items(), key=lambda item: item[0]))
    
    
    RE_valu_list={}
    no_site = False
    for s in range(len(sorted_PE_list)):
      val_count=0
      RE_valu=[]
      for k,v in sorted_PE_list[s]:
        if val_count < thresh_list[s]:
          val_count+=1
          RE_valu.append(k)
      try:
        RE_valu_list[sorted_PE_list[s][1][1][0]]= RE_valu
      except:
        print("No viable site found. Run end.")
        no_site = True
        pass
    
    if no_site:
      if args.summary:
        import json
        summary_path = Path(args.summary)
        summary = {"completed_job_dir": "", "focus_dirs": [], "reduce_list": [], "selected_xyz": []}
        summary_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
      return
    
    import py3Dmol
    
    def get_candidate_coord(RE_valu_list,test_results_lis):
      charge_sites=[]
      for t in range(len(test_results_lis)):
        for k,v in test_results_lis[t].items():
          for t in RE_valu_list:
            if k in RE_valu_list[t]:
              charge_sites.append((k,v))
      return charge_sites
    
    def find_distance(sites,coord):
      try:
        x = float(coord[1]) - float(sites[1])
        y = float(coord[2]) - float(sites[2])
        z = float(coord[3]) - float(sites[3])
        distance4 = (x**2 + y**2 + z**2)**0.5
        return distance4
      except:
        x = float(coord[0]) - float(sites[1])
        y = float(coord[1]) - float(sites[2])
        z = float(coord[2]) - float(sites[3])
        distance4 = (x**2 + y**2 + z**2)**0.5
        return distance4
    
    def bonded_distance(s):
      at_coord2 = open(file_name +"/"+s[0])
      bonded =[]
      for aa in at_coord2:
        if len(aa.split())>3:
          a=aa.split()
          dist = find_distance(s[1],a)
          if 0.7<float(dist) <1.8:
            bonded.append((s,a))
      return bonded
    
    def nonbonded_distance(bonded_atom,new_H_coor):
      atom_B = bonded_atom[0][1]
      atom_C = new_H_coor
      distance = ((((float(atom_B[1])-float(atom_C[0]))**2)+((float(atom_B[2])-
      float(atom_C[1]))**2)+((float(atom_B[3])-float(atom_C[2]))**2))**(1/2))
      return distance
    
    def H_C_N_distance(new_H_coor):
      H_dist_list=[]
      C_dist_list=[]
      N_dist_list=[]
      Hot_dist_list=[]
      at_coord2 = open(file_name +"/"+s[0])
      for aa in at_coord2:
        if len(aa.split())>3:
          a=aa.split()
          if a[0] =="H":
            dist_H = find_distance(a,new_H_coor)
            H_dist_list.append(dist_H)
          if a[0] =="C":
            dist_C = find_distance(a,new_H_coor)
            C_dist_list.append(dist_C)
          if a[0] =="N":
            dist_N = find_distance(a,new_H_coor)
            N_dist_list.append(dist_N)
          try:
            if a[0] ==[o for o in othergen_list if a[0] in o][0]:
              dist_Hot = find_distance(a,new_H_coor)
              Hot_dist_list.append(dist_Hot)
            else:
              Hot_dist_list.append(10)
          except:
            pass
      return H_dist_list,C_dist_list,N_dist_list,Hot_dist_list
    
    def bonded_angle(bonded_atom,new_H_coor):
      atom_A = bonded_atom[0][0][1]
      atom_B = bonded_atom[0][1]
      atom_C = new_H_coor
      AB_=(float(atom_A[1])-float(atom_B[1]),float(atom_A[2])-float(atom_B[2]),
           float(atom_A[3])-float(atom_B[3]))
      BC_=(float(atom_B[1])-float( atom_C [0]),float(atom_B[2])-float( atom_C [1]),
           float(atom_B[3])-float( atom_C [2]))
      AB__BC=AB_[0]*BC_[0]+AB_[1]*BC_[1]+AB_[2]*BC_[2]
      AB=(AB_[0]**2+AB_[1]**2+AB_[2]**2)**0.5
      BC=(BC_[0]**2+BC_[1]**2+BC_[2]**2)**0.5
      AB_BC=math.acos((AB__BC)/(AB*BC))*(180/math.pi)
      bond_angle = AB_BC
      return bond_angle
    
    def new_proton_coord(molec_lib, angle_increment,act):
      x_vertex=float(molec_lib[1])
      y_vertex=float(molec_lib[2])
      z_vertex=float(molec_lib[3])
      if molec_lib[0] == "O":
        r=0.95
      if molec_lib[0] == "N":
        r=1.0
      x,y,z,r=0,0,0,r
      theta = math.acos(0)
      phi = math.atan(0)
      deg = 70 + angle_increment
      rad = deg * (math.pi/180)
      theta = rad+theta
      if act == 0:
        phi = 0.10 - math.sin(theta/(angle_increment*0.01+.01))
      else:
        phi = 0.10 + math.cos(theta/act)
      x_= r*math.sin(theta)*math.cos(phi)
      y_= r*math.sin(theta)*math.sin(phi)
      z_= r*math.cos(theta)
      x_new=float(x_)+x_vertex
      y_new=float(y_)+y_vertex
      z_new=float(z_)+z_vertex
      return x_new,y_new,z_new
    
    
    if no_site:
      if args.summary:
        import json
        summary_path = Path(args.summary)
        summary = {"completed_job_dir": "", "focus_dirs": [], "reduce_list": [], "selected_xyz": []}
        summary_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
      return
    charge_sites= get_candidate_coord(RE_valu_list,test_results_lis)
    
    sorted_charge_sites=[]
    for c in sorted(charge_sites):
      sorted_charge_sites.append(c[1])
    
    
    de_proton_coord =[]
    if charge_mode == "[M-H]-":
      for s in sorted_charge_sites:
        bond_dist = bonded_distance(s)
        countH=0
        for b in bond_dist:
          if b[1][0] =="H" and countH<1:
            de_proton_coord.append((b[0][0],b[1]))
            countH+=1
    tot_bond=[]
    if charge_mode == "[M+H]+":
      for s2 in sorted_charge_sites:
        bond_dist = bonded_distance(s2)
        countH=0
        for b in bond_dist:
          if b[1][0] !="N" :
            countH+=1
        tot_bond.append(countH)
    
    
    molec_lib={}
    angle_increment = 0
    count_chk = 0
    protonated_sites_list =[]
    reduntant_list=[]
    if charge_mode == "[M+H]+":
      for s in sorted_charge_sites:
    
        if sorted_charge_sites[count_chk][1][0] =="N" and tot_bond[count_chk]>3:
          count_chk+=1
          pass
        else:
          act=0
          angle_increment = 0
          molec_lib = s[1]
    
          x_new,y_new,z_new= new_proton_coord(molec_lib, angle_increment,act)
          new_H_coor = [x_new,y_new,z_new]
          bonded_atom = bonded_distance(s)
          bond_angle = bonded_angle(bonded_atom,new_H_coor)
          bond_dist2 = find_distance(s[1],new_H_coor)
          tot_iteration = []
          count_iter=0
          while 0 < bond_angle <=360:
            angle_increment+=1
            x_new,y_new,z_new= new_proton_coord(molec_lib, angle_increment,act)
            new_H_coor = [x_new,y_new,z_new]
            bonded_atom = bonded_distance(s)
            bond_angle = bonded_angle(bonded_atom,new_H_coor)
            nb_dist = nonbonded_distance(bonded_atom,new_H_coor)
            H_dist_list,C_dist_list,N_dist_list,Hot_dist_list = H_C_N_distance(new_H_coor)
            try:
              test_empty=min(Hot_dist_list)
            except:
              Hot_dist_list.append(10)
    
            count_iter=+1
            chk1,chk2,chk3,chk4,chk5=0,0,0,0,0
            tot_iteration .append(count_iter)
            if sum(tot_iteration ) < 2000:
              try:
                if (90 < bond_angle < 160 and nb_dist > 1.8 and
                  min(Hot_dist_list) > 1.5 and min(C_dist_list) > 1.75 and min(N_dist_list) > 0.95 ):
                  count_iter=0
                  break
              except:
                (90 < bond_angle < 160 and nb_dist > 1.8 and
                min(Hot_dist_list) > 1.5 and min(C_dist_list) > 1.75 )
                break
            if 3000 > sum(tot_iteration ) > 2000:
              act += 1
              try:
                if (100 < bond_angle < 160  and nb_dist > 1.8 and min(H_dist_list) > 1.5 and
                  min(Hot_dist_list)>1.5 and min(C_dist_list) > 1.75 and min(N_dist_list) > 0.95 ):
                  count_iter=0
                  break
              except:
                if (100 < bond_angle < 160  and nb_dist > 1.8 and min(H_dist_list) > 1.5 and
                  min(Hot_dist_list)>1.5 and min(C_dist_list) > 1.75):
                  break
            if 4000 > sum(tot_iteration ) > 3000:
              act+=1
              if (90 < bond_angle < 160  and nb_dist > 1.8 and min(Hot_dist_list)>1.5
                  and min(H_dist_list) > 1.5 and min(C_dist_list) > 1.6 ):
                count_iter=0
                break
            if 5000 > sum(tot_iteration ) > 4000:
              if (90 < bond_angle < 160 and min(H_dist_list) > 1.5 and min(Hot_dist_list)>1.5
                  and min(C_dist_list) > 1.6 and nb_dist > 1.4):
                count_iter=0
                break
            if 6000 > sum(tot_iteration ) > 5000:
              act=0
              if (90 < bond_angle < 180 and min(H_dist_list) > 1.4
                  and min(C_dist_list) > 1.6 and min(Hot_dist_list)>1.4):
                count_iter=0
                break
            if 7000 > sum(tot_iteration ) > 6000 :
              act += 1
              try:
                if (90 < bond_angle < 160 and min(H_dist_list) > 1.5 and min(Hot_dist_list)>1.5
                    and min(C_dist_list) > 1.6 and min(N_dist_list) > 0.95):
                  count_iter=0
                  break
              except:
                if (90 < bond_angle < 160 and min(H_dist_list) > 1.5 and min(Hot_dist_list)>1.5
                    and min(C_dist_list) > 1.6):
                  break
    
            if sum(tot_iteration ) > 7000:
              act=0
              if (90 < bond_angle < 200 and min(H_dist_list)>1.4
                  and min(C_dist_list) > 1.4 and min(Hot_dist_list)>1.4):
                count_iter=0
                chk1=1
                break
              act+=1/2
              if (80 < bond_angle < 180 and min(H_dist_list)>1.3
                  and min(C_dist_list) > 1.5 and min(Hot_dist_list)>1.5 and chk1==0):
                count_iter=0
                chk2=1
                break
              act+=1
              if (70 < bond_angle < 180 and min(H_dist_list) > 1.3
                  and min(C_dist_list) > 1.5 and min(Hot_dist_list)>1.5 and chk2==0):
                count_iter=0
                act=0
                chk3=1
                break
              act-=1/2
              if (70 < bond_angle < 180 and min(H_dist_list) > 1.3
                  and min(C_dist_list) > 1.6 and min(Hot_dist_list)>1.5 and chk3==0):
                count_iter=0
                chk4=1
                break
              act+=1/3
              if (70 < bond_angle < 180 and min(H_dist_list) > 1.2
                  and min(C_dist_list) > 1.5 and min(Hot_dist_list)>1.5 and chk4==0):
                count_iter=0
                chk5=1
                break
              act+=math.log(angle_increment)
              if (70 < bond_angle < 200 and min(H_dist_list) > 1.2
                  and min(C_dist_list) > 1.5 and min(Hot_dist_list)>1.5 and chk5==0):
                count_iter=0
                break
    
          count_chk+=1
          protonated_sites_list.append((s,new_H_coor))
    
    
    
    # import os
    
    
    if charge_mode == "[M-H]-":
      rename_ =de_proton_coord[0][0].replace(".xyz","").replace("_","-")
    if charge_mode == "[M+H]+":
      rename_ =protonated_sites_list[0][0][0].replace(".xyz","").replace("_","-")
    
    try:
      folder_name = "Completed_Job"
      os.mkdir(folder_name)
    except:
      folder_name = "Completed_Job"
    try:
      os.mkdir("{}/{}".format(folder_name,rename_ ))
    except:
      try:
        os.remove("{}/{}".format(folder_name,rename_ ))
      except:
        try:
          os.mkdir("{}/{}".format(folder_name,rename_ ))
        except:
          pass
    
    unsupported_atoms = ["Br", "I", "P", "Se"]
    switch_atom_lib={}
    rank = 0
    if charge_mode == "[M-H]-":
      for p in range(len(de_proton_coord)):
        rank+=1
        fi_nam = open(file_name+"/{}".format(de_proton_coord[p][0]))
        fo_name = open("{}/{}/{}_rank{}_model.xyz".format(folder_name,
                      rename_,rename_,rank ),'a')
        for f in fi_nam:
          if f.split()[0].isnumeric():
            tot_atom = f.split()[0]
            update_tot = int(tot_atom)-1
            print(update_tot,file=fo_name)
            print(rename_+"_rank{}".format(rank),file=fo_name)
          if len(f.split())>3:
            if f.split()==de_proton_coord[p][1]:
              pass
            else:
              if f.split()[0] not in unsupported_atoms:
                print(f.strip(),file=fo_name)
              if f.split()[0] !="S" and (f.split()[0] == "P" or f.split()[0] == "Se"):
                switch_atom_lib["S"]=f.split()[0]
                print(f.strip().replace(f.split()[0],"S"),file=fo_name)
              if f.split()[0] not in ["F","Cl"] and (f.split()[0] == "Br" or f.split()[0] =="I"):
                switch_atom_lib["Cl"]=f.split()[0]
                print(f.strip().replace(f.split()[0],"Cl"),file=fo_name)
        fo_name.close()
    
    
    if charge_mode == "[M+H]+":
      for p in range(len(protonated_sites_list)):
        rank+=1
        x_up, y_up, z_up = (float(protonated_sites_list[p][1][0]),
        float(protonated_sites_list[p][1][1]),float(protonated_sites_list[p][1][2]))
        fi_nam = open(file_name+"/{}".format(protonated_sites_list[p][0][0]))
        fo_name = open("{}/{}/{}_rank{}_model.xyz".format(folder_name,
                      rename_,rename_,rank),'a')
        for f in fi_nam:
          if f.split()[0].isnumeric():
            tot_atom = f.split()[0]
            update_tot = int(tot_atom)+1
            print(update_tot,file=fo_name)
            print(rename_+"_rank{}".format(rank),file=fo_name)
          if len(f.split())>3:
            if f.split()[0] not in unsupported_atoms:
              print(f.strip(),file=fo_name)
            if f.split()[0] !="S" and (f.split()[0] == "P" or f.split()[0] == "Se"):
              switch_atom_lib["S"]=f.split()[0]
              print(f.strip().replace(f.split()[0],"S"),file=fo_name)
            if f.split()[0] not in ["F","Cl"] and (f.split()[0] == "Br" or f.split()[0] =="I"):
              switch_atom_lib["Cl"]=f.split()[0]
              print(f.strip().replace(f.split()[0],"Cl"),file=fo_name)
            if f.split()==protonated_sites_list[p][0][1]:
              print("{:<1}{:17.5f}{:^22.5f}{:^4.5f}".format("H",
                    x_up, y_up, z_up), file=fo_name)
        fo_name.close()
    
    
    import mlatom as ml
    import ase
    import sys
    # import os
    
    
    
    try:
      os.remove(testfile_name)
    except:
      pass
    
    Name_in = folder_name+"/"+rename_
    d = len(os.listdir(Name_in+"/" ))
    id = os.listdir(Name_in+"/" )
    spe={}
    try:
      id.remove('.ipynb_checkpoints')
      d = len(id)
    except:
      pass
    for i in range(d):
      if id[i][-3:].lower()!="csv":
        try:
          supported ="yes"
          mole_id =("{}/{}".format(Name_in,id[i]))
          method_="ANI-2x"
          ani = ml.models.methods(method=method_,)
          in_mol = ml.data.molecule.from_xyz_file('{}'.format(mole_id))
          cut_link = mole_id.split("/")
          opt_name='opt-{}*$'.format(cut_link[2])
          OPT_fi = cut_link[0]+"/"+cut_link[1]+"/"+opt_name
          OPT_mol = (ml.optimize_geometry(model=ani, initial_molecule=in_mol,
                  program="ASE", maximum_number_of_steps=50).optimized_molecule)
          OPT_mol.xyz_coordinates
    
          OPT_mol.get_xyz_string()
          OPT_mol.write_file_with_xyz_coordinates(filename=OPT_fi)
    
        except:
          supported ="no"
          pass
    
      try:
        spe[id[i]] = OPT_mol.energy
      except:
        pass
    if supported !="yes":
      pass
    else:
      for I in id:
        if 'opt' not in I:
          os.remove("{}/{}".format(Name_in,I))
    
    
    def revert_to_save(revert_,switch_atom_lib,file_link ):
      new_file_name = open(file_link.replace("*$",""), "w")
      for r in revert_:
        atom_ = r.split()[0]
        if len(r.split())==1 and "rank" in r.split()[0]:
          try:
            print(r.strip().replace(r.split()[0],
                  "model_energy_{}".format(spe[r.split()[0]+"_model.xyz"])),
                  file=new_file_name)
          except:
            pass
        if len(r.split())>3 and (atom_ in Halogen_list or atom_ in othergen_list):
          try:
            print(r.strip().replace(atom_,switch_atom_lib[atom_]),
                  file=new_file_name)
          except:
            print(r.strip(), file=new_file_name)
        else:
          if "rank" not in r.split()[0]:
            print(r.strip(), file=new_file_name)
      new_file_name.close()
    
    
    if supported !="yes":
      pass
    else:
      SPE= sorted(spe.items(), key=lambda x: x[1])
      rank_lib = {}
      for i in range(len(SPE)):
        rank_lib[SPE[i][0].split("_")[1]]="Rank{}".format(i+1)
      rank_lib
      xyz_name = os.listdir(Name_in)
      xyz_name = sorted(xyz_name)
      try:
        xyz_name.remove('.ipynb_checkpoints')
      except:
        pass
      for x in xyz_name:
        try:
          keyy = x.split("_")[1]
          old_ranking = x
          new_ranking = x.replace((keyy), rank_lib[keyy])
          os.rename("{}/{}".format(Name_in,old_ranking),
                    "{}/{}".format(Name_in,new_ranking) )
        except:
          pass
    
    revert_file = os.listdir(Name_in)
    try:
        revert_file.remove('.ipynb_checkpoints')
    except:
      pass
    for r in revert_file:
      file_link = "{}/{}".format(Name_in, r)
      revert_ =open(file_link)
      save = revert_to_save(revert_,switch_atom_lib,file_link )
      try:
        if "*$" in file_link:
          os.remove(file_link)
        else:
          pass
      except:
        pass
    
    end = timer()
    time_complete = datetime.now(pytz.timezone('America/Los_Angeles')).strftime("%H:%M:%S     %d-%b-%Y")
    
    
    
    from datetime import date
    from datetime import datetime
    from datetime import datetime
    
    
    
    def get_mol_fract(rel_E, m, mm):
      for m2 in mm:
        mol_fract = m2/sum(m)
        return mol_fract
    
    def get_runtime(end,start):
      time_elapse = (end-start)/60
      time_elapse=str(time_elapse)
      min_,sec_ = (int((time_elapse.split("."))[0]),
                   int((time_elapse.split("."))[1]))
      return min_,sec_
    
    
    min_,sec_ = get_runtime(end,start)
    
    bbe = open(Name_in+"/results_sum.log", "w")
    print("__________________________________________________\n", file=bbe)
    print("  .::∈∈∈∈∈     .:∈∈∈∈∈∈     .:∈∈∈∈∈∈   ||∈∈∈∈∈∈:.", file=bbe)
    print(" '''          ''           ''          |||    '''", file=bbe)
    print(" '::         '''          '''          |||    '''", file=bbe)
    print("  ':|||::.   ||||||||||   ||||||||||   ||| ..::'", file=bbe)
    print("       '''   '''          '''          |||  \\ \ ", file=bbe)
    print("       '''    ''.          ''.         |||   \\ \ ", file=bbe)
    print(" ∈∈∈∈∈::'      ':∈∈∈∈∈∈     ':∈∈∈∈∈∈   |||    \\ \ \n", file=bbe)
    
    print("   State      Ensemble       Energy    Recognition\n__________________________________________________",
          file=bbe)
    print("==================================================\nS∈∈R:           Model MK1.0            09-Sep-2024\n==================================================",
          file=bbe)
    print("Documentation website:\nhttps://github.com/mitkeng/SEER", file=bbe)
    print("\n\nTo cite this work use:\nS∈∈R Version 1.0,\nM. Keng and K. M., Jr. Merz, 2024\n",
          file=bbe)
    print("Code and interface:\nM. Keng \n\n", file=bbe)
    print("\nStart time:{:>38}".format(time_initiated), file=bbe)
    print("Completed time:{:>34}".format(time_complete), file=bbe)
    print("Runtime:{:>20}{:02d}:{}".format("",min_,str(sec_)[:2].split()[0]), file=bbe)
    print("\n\n\nTest system: {}\nCharge mode: {}\nOptimization method: {}\n\n**************** Results Summary ****************\n\n  Test ID         Energy       Rel. E      Mole".format(id[0].split("_")[0],
          charge_mode, method_) ,file=bbe)
    print("{:>25}{:>14}{:>9}\n-------------------------------------------------".format("(hartree)",
         "(kcal/mol)","Frac."),file=bbe)
    
    spe = dict(sorted(spe.items(), key = lambda item: item[1]))
    
    test_id_list =[]
    hart_E=[]
    m = []
    mm = []
    rel_E=[]
    for k,v in spe.items():
      RE= (-min(spe.values())+spe[k])*627.5
      rel_E.append(RE)
      a = RE/(0.001986*298)
      b = math.exp(-1*a)
      mm.append(b)
      m.append(b)
      test_id_list.append(rank_lib[k.split("_")[1]])
      hart_E.append(round(v,4))
    
    
    mol_fract=[]
    for m2 in mm:
      mol_fract.append(m2/sum(m))
    
    for E in range(len(hart_E)):
       (print("{:<10}{:^19}{:^10}{:^11}".format("Model "+test_id_list[E],hart_E[E],
        round(rel_E[E],2),round(mol_fract[E],2)), file=bbe))
    
    
    bbe.close()
    
    
    # import os
    import pandas as pd
    import matplotlib.pyplot as plt
    from rdkit import Chem
    from rdkit.Chem import AllChem
    from openbabel import pybel
    from rdkit.Chem import rdMolDescriptors
    
    
    
    def xyz_to_smiles(xyz_file):
      try:
        mol = next(pybel.readfile("xyz", xyz_file))
        return mol.write("smi").split()[0].strip()
      except:
        return "None"
    
    
    def rotatable_bonds(smiles):
      try:
        mol = Chem.MolFromSmiles(smiles)
        if mol is None:
            return "None"
    
    
        return rdMolDescriptors.CalcNumRotatableBonds(mol)
      except:
        pass
    
    
    ss= os.listdir(Name_in)
    try:
      ss.remove(".ipynb_checkpoints")
    except:
      pass
    
    for s in ss:
      if s.split(".")[-1]=="xyz" and "Rank1" in s.split("_"):
        count=0
        xyz = open(Name_in+"/{}".format(s)).read()
        xyzview = py3Dmol.view(width=800,height=300)
        xyzview.addModel(xyz,'xyz',{'vibrate': {'frames':1000,'amplitude':1}})
        xyzview.setStyle({'stick':{}})
        xyzview.setBackgroundColor('white')
        xyzview
        xyzview.show()
      else:
        pass
    
    Z_folder = str(Path("Completed_Job") / molecule_name / "conformer" / "charge_model")
    try:
      os.mkdir(Z_folder)
    except:
      pass
    
    
    
    Z_folder = str(Path("Completed_Job") / molecule_name / "charge_model")
    try:
      os.mkdir(Z_folder)
    except:
      pass
    Z_files = str(Path("Completed_Job") / molecule_name)
    for d in os.listdir(Z_files):
    
      if ".xyz" in d:
        try:
          Z_link = Z_files+"/"+d
          shutil.copy(Z_link, Z_folder)
    
        except:
          pass
    
    
    smi_file= open(Z_folder+"/smile_list.csv","a")
    print("Rank,SMILE", file=smi_file)
    for s in os.listdir(Z_folder):
    
      smiles = xyz_to_smiles(Z_folder +"/"+s)
      smi_file = open(Z_folder+"/smile_list.csv","a")
      if smiles !="None":
    
        print(s.split("_")[-2][4:],",",smiles, file=smi_file)
        smi_file.close()
    
    
    
    num_rotbond = rotatable_bonds(smiles)
    if num_rotbond =="None":
      num_rotbond = rotatable_bonds(smile)
    
    # if charge_model_download == True:
    #   shutil.make_archive(Z_folder, 'zip', Z_folder)
    
    
    def conf_gen(ss,Name_in):
      for s in ss:
        if s.split(".")[-1]=="xyz":
          B=nconf
          file = Name_in+"/{}".format(s)
          conf_folder= Name_in+"/conformer/"
          conf_file = Name_in+"/conformer/{}".format(s)
      return conf_folder
    
    def partition_xyz(conf_folder):
      file_lis = os.listdir(conf_folder)
      fi_count=0
      for fi in file_lis:
        try:
          ff = open(conf_folder+"{}".format(fi))
          conf_dir = conf_folder+"{}".format(fi.replace("_model.xyz","_conformer"))
        except:
          pass
        try:
          os.mkdir(conf_dir)
        except:
          pass
        num_count=0
        for f in ff:
          fi_count=0
          if f.split()[0].isnumeric():
            num_count+=1
            fi_count+=1
            c_fi = open(conf_dir+"/{}.xyz".format(num_count),'a')
          if fi_count <=1:
            print(f.strip(),file=c_fi)
        c_fi.close()
        try:
          shutil.rmtree(conf_folder+"{}".format(fi))
        except:
          pass
    
    
    
    generate=conf_gen(ss,Name_in)
    partition_conf =  partition_xyz(generate)
    
    
    import tensorflow as tf
    import re
    import statistics as st
    # import shutil
    import warnings
    import matplotlib.pyplot as plt
    import re
    
    
    
    
    dnn_model = tf.keras.models.load_model('ML_ccs.keras')
    
    Name = generate
    system_conf = os.listdir(generate)
    
    reduce_list = []
    
    for Co in system_conf:
      if 'conformer' not in Co:
        try:
          os.remove("{}{}".format(Name,Co))
        except:
          pass
      try:
        if 'conformer' in Co:
          d = len(os.listdir("{}{}".format(Name,Co)))
          id = os.listdir("{}{}".format(Name,Co))
          COM_list= []
          mass_list=[]
          conf_num=[]
          surface_area=[]
          for i in range(d):
            mol = ase.io.read("{}{}/{}".format(Name,Co,id[i]))
            COM = mol.get_center_of_mass(scaled=False)
            COM_list.append(COM)
            mol_mass = mol.get_masses()
            mass_list.append(sum(mol_mass))
            cmd.load("{}{}/{}".format(Name,Co,id[i]))  # use the name of your pdb file
            cmd.set('dot_solvent', 0)
            cmd.set('dot_density',2)
            new_id=re.sub("[^0-9]", "", id[i])
            conf_num.append(new_id)
            sa=cmd.get_area('all')
            surface_area.append(sa)
            cmd.reinitialize()
          cmd.reinitialize()
    
          COM_List=[]
          for co in COM_list:
            COM_List.append((co[0],co[1],co[2]))
    
          electro_neg=  ({"C":2.55, "O":3.44, "H":2.20, "N":3.04, "F":3.98,"Cl":3.16,
                "Br":2.96 , "I":2.66 ,"S":2.58,"P":3.15, "Se":2.55})
    
          d = len(os.listdir("{}".format(Name)))
          id = os.listdir("{}".format(Name))
    
          for c in id:
            if c[-3:].lower()=="csv":
              csv_name = c
    
          COM_list1= []
          try:
            id.remove('.ipynb_checkpoints')
          except ValueError:
            pass
          action_dist1=[]
          action_dist2=[]
          total_hetero=[]
          for e in range(len(conf_num)):
    
              xyz_file = open("{}{}/{}.xyz".format(Name,Co,conf_num[e]))
              xyz_list=[]
              tru_list=[]
              for x in xyz_file:
                X = x.split()
                try:
                  if X[0].isalpha() and not X[2].isalpha():
                    xyz_list.append(X)
    
                except IndexError:
                  next
              dist_list =[]
              dist_list2=[]
              hetero_list=[]
              hetero_atom=0
              for n in range(len(COM_List)):
                for n2 in range(len(xyz_list)):
                  dist = (((float(xyz_list[n2][1])-float(COM_List[n][0]))**2)+((float(xyz_list[n2][2])-float(COM_List[n][1]))**2)+((float(xyz_list[n2][3])-float(COM_List[n][2]))**2))**(1/2)
                  dist_list.append((dist,n,n2,xyz_list[n2][0]))
                  if xyz_list[n2][0]!="H" and xyz_list[n2][0]!="C":
                    dist2 = (((float(xyz_list[n2][1])-float(COM_List[n][0]))**2)+((float(xyz_list[n2][2])-float(COM_List[n][1]))**2)+((float(xyz_list[n2][3])-float(COM_List[n][2]))**2))**(1/2)
                    hetero_atom=+1
                    dist_list2.append(dist2)
                    hetero_list.append(hetero_atom)
    
              total_hetero.append(int(sum(hetero_list)/len(COM_List)))
    
              action_dist1.append(max(dist_list2))
              action_dist2.append(max(dist_list)[0])
    
          testfile_name='{}{}.csv'.format(Name,Co)
          f2 = open(testfile_name, 'a')
    
          for n in range(len(conf_num)):
            try:
              print("{},{},{},{},{},{}".format(mass_list[n], action_dist1[n],action_dist2[n],surface_area[n],total_hetero[n], conf_num[n]), file=f2)
            except KeyError:
              n=+1
          f2.close()
          file_name2='{}'.format(testfile_name)
          google_drive=False
    
          column_names = ['mz', 'COM1', 'COM2', 'SA', 'Hetero_atom','conf#']
    
          raw_dataset2 = pd.read_csv(file_name2,names=column_names,
                                    na_values='?', comment='\t',
                                    index_col= False,
                                    skipinitialspace=True)
    
    
          dataset2 = raw_dataset2.copy()
    
          total_dataset= dataset2
    
          try:
            test_conf_num = total_dataset.pop('conf#')
          except:
            KeyError
          g=dnn_model.predict(total_dataset)
    
          graph_data = []
          conf_ccs_dic={}
          for gg in range(len(g)):
            conf_ccs_dic[test_conf_num[gg]]=round(float(g[gg]),3)
            graph_data.append(conf_ccs_dic[test_conf_num[gg]])
          try:
            error = abs(test_predictions - test_labels)/test_labels*100
            plt.hist(error, bins=100)
            plt.xlabel('\nPrediction %Error [gpCCS]')
            _ = plt.ylabel('\nCount (total test:{})\n'.format(len(test_predictions)))
            sns.displot(error,kind="kde")
          except:
            pass
    
          dataframe=pd.DataFrame(g, columns=['predicted ccs'])
    
          warnings.filterwarnings('ignore')
    
          conf_ccs_dic={}
          for gg in range(len(g)):
            conf_ccs_dic[test_conf_num[gg]]=round(float(g[gg]),3)
    
          try:
            STD = st.stdev(error)/100
          except:
            error_load=pd.read_csv("error.csv")
            error = error_load["gpCCS"]
    
          STD = st.stdev(error)/100
    
          conf_file = testfile_name.replace(".csv","")
          focus_file = conf_file
          Focus_folder=focus_file.replace("_conformer","_focus")
    
          upper_limit = Experimental_CCS +(Experimental_CCS*STD)
          lower_limit = Experimental_CCS -(Experimental_CCS*STD)
    
          if google_drive ==True:
            new_DIR="{}_CCS_{}".format(drive_link,Experimental_CCS)
            try:
              os.mkdir(new_DIR)
            except FileExistsError:
              print("\n\nWork file already exist: conformation focusing has already been processed for the entered reference CCS of {}.".format(Experimental_CCS))
              next
    
          if google_drive ==False:
            new_DIR="{}_CCS_{}".format(Focus_folder,Experimental_CCS)
            drive_link =Focus_folder
            try:
              os.mkdir(new_DIR)
            except FileExistsError:
              print("\n\nWork file already exist: conformation focusing has already been processed for the entered reference CCS of {}.".format(Experimental_CCS))
              next
    
          print("\n\nUpper limit CCS value: {:.3f}".format(upper_limit))
          print("Lower limit CCS value: {:.3f}".format(lower_limit))
    
          print("\n\nML Prediction Statistics:\n----------------------")
          dataframe=pd.DataFrame(g, columns=['CCS Values'])
          df = dataframe
          print(df.describe(),"\n\n")
    
    
          conf_id =(os.listdir("{}/".format(conf_file )))
          total=[]
          count =0
          print("\n\nCompleted run remark:\n---------------------")
          for id in conf_id:
            try:
              id_num=re.sub("[^0-9]", "", id)
              if lower_limit<= conf_ccs_dic[int(id_num)] <=upper_limit:
                count=+1
                total.append(count)
                shutil.copy("{}/{}".format(conf_file, id), "{}/{}".format(new_DIR,id))
            except NameError:
              next
    
          print("¶Captured {} conformers out of a total {} conformers".format(sum(total), len(g)))
          print("¶Captured conformers have been siphoned off to {}".format(new_DIR))
    
          print("\n\n")
    
          if 50 > sum(total) > 0:
            up_DIR = new_DIR.split("focus")[0]+"final"
            shutil.make_archive(new_DIR, 'zip', new_DIR)
          if len(os.listdir(conf_file)) <50:
            up2_DIR = conf_file.split("_conformer")[0]+"_final"
            shutil.make_archive(conf_file, 'zip', conf_file)
            print("yes")
          if (sum(total)== 0 and len(os.listdir(conf_file))>50) or sum(total)>50:
            reduce_list.append(conf_file)
    
    
    
          n_bins = 40
          fig, axs = plt.subplots(tight_layout=True)
          axs.hist(df, bins=n_bins)
          plt.title("Predicted CCS Distribution", size=12)
          plt.xlabel('\nCCS (Å$^2$)\n\n', size='10')
          plt.ylabel('\nOccurrence\n',  size="10")
          plt.plot(Experimental_CCS,1,'*',mec='black',markerfacecolor='r', markersize=11)
          plt.legend(labels=['Experiment'])
          plt.savefig("{}/{}".format(new_DIR,molecule_name))
      except NotADirectoryError:
        pass
    
    import numpy as np
    
    def calculate_rmsd(coords1, coords2):
      coords1 = np.array(coords1)
      coords2 = np.array(coords2)
      return np.sqrt(np.mean(np.sum((coords1 - coords2)**2, axis=1)))
    
    def average_rmsd(conformations):
      n_conformations = len(conformations)
      total_rmsd = 0
      num_pairs = 0
      for i in range(n_conformations):
        for j in range(i + 1, n_conformations):
          total_rmsd += calculate_rmsd(conformations[i], conformations[j])
          num_pairs += 1
      return total_rmsd / num_pairs
    
    def positive_normal(mu, sigma, size=1):
        samples = []
        while len(samples) < size:
            x = np.random.normal(mu, sigma)
            if x > 0:
                samples.append(x)
        return np.array(samples)
    
    
    walk_lib ={}
    for r in range(len(reduce_list)):
      rl = os.listdir(reduce_list[r])
      conformations=[]
      for cu in range(len(rl)):
        try:
          B_list = []
          if "xyz" in rl[cu]:
            try:
              b = open(reduce_list[r] +"/"+ rl[cu])
            except:
              pass
    
            for B in b:
              if len(B.split()) >2:
                B_list.append((float(B.split()[1]), float(B.split()[2]), float(B.split()[3])))
          conformations.append(np.array(B_list))
    
          stde = np.std(B_list)
        except:
          pass
    
      ave_rmsd = average_rmsd(conformations)
      walk_steps = 20*num_rotbond
      normal_walk = positive_normal(ave_rmsd, stde, size=walk_steps)
      walk_lib[reduce_list[r]]= min(normal_walk), (max(normal_walk)-min(normal_walk))/(walk_steps), max(normal_walk)
    
    # import os
    import numpy as np
    # import shutil
    from openbabel import pybel
    from rdkit import Chem
    from rdkit.Chem import AllChem
    from rdkit import Chem
    from rdkit.Chem import rdMolDescriptors
    
    
    def calculate_similarity(xyz1, xyz2):
        centroid1 = np.mean(xyz1, axis=0)
        centroid2 = np.mean(xyz2, axis=0)
        xyz1_centered = xyz1 - centroid1
        xyz2_centered = xyz2 - centroid2
        cov = np.dot(xyz1_centered.T, xyz2_centered)
        U, S, V = np.linalg.svd(cov)
        rotation_matrix = np.dot(V.T, U.T)
        aligned_xyz2 = np.dot(xyz2_centered, rotation_matrix) + centroid1
        rmsd = np.sqrt(np.mean(np.sum((aligned_xyz2 - xyz1)**2, axis=1)))
        return rmsd
    
    def count_rotatable_bonds(smiles):
      mole = Chem.MolFromSmiles(smiles)
      if mole is None:
        raise ValueError("Invalid SMILES string")
      return rdMolDescriptors.CalcNumRotatableBonds(mole)
    
    def reduce_name(r):
      B = r.split("/")[-1]
      for b in range(len(B.split("_"))):
        if "Rank" in B.split("_")[b]:
          rank_name = B.split("_")[b]
          return rank_name
    
    
    
    
    for r in range(len(reduce_list)):
      rl = os.listdir(reduce_list[r])
      step=0
      reset_1=1
      reset_2=1
      max_rmsd = 0
      for cu in range(len(rl)):
        try:
          if "xyz" in rl[cu]:
            try:
              b = open(reduce_list[r] +"/"+ rl[cu])
            except:
              pass
            B_list = []
    
            for B in b:
              if len(B.split()) >2:
                B_list.append((float(B.split()[1]), float(B.split()[2]), float(B.split()[3])))
            for cu2 in range(len(rl)):
              try:
                if rl[cu] != rl[cu2]:
                  c = open(reduce_list[r]+"/"+ rl[cu])
                  C_list = []
                  for C in c:
                    if len(C.split()) >2:
                      C_list.append((float(C.split()[1]), float(C.split()[2]), float(C.split()[3])))
                try:
                  molecule1_xyz = np.array(B_list)
                  molecule2_xyz = np.array(C_list)
                  similarity_score = calculate_similarity(molecule1_xyz, molecule2_xyz)
                  num_rot = count_rotatable_bonds(smile)
    
                  if float(similarity_score) < (reset_1*walk_lib[reduce_list[r]][0]+step*reset_2)+max_rmsd :
                    step = walk_lib[reduce_list[r]][1] + step
    
                    if step > walk_lib[reduce_list[r]][2]:
                      max_rmsd = walk_lib[reduce_list[r]][2]
                      reset_1 = 0
                      reset_2 = 0
                    rank_name = reduce_name(reduce_list[r])
                    link_new ="/".join(reduce_list[r].split("/")[:-1])
                    system_name = (reduce_list[r].split("/")[1])
                    rxr_dir = link_new +"/"+system_name+"_" +rank_name +"_rxr"
                    old_dir =reduce_list[r] +"/"+ rl[cu]
                    try:
                      os.mkdir(rxr_dir)
                    except:
                      pass
                    try:
                      shutil.move(old_dir, rxr_dir)
                      rl = os.listdir(reduce_list[r])
                    except:
                      pass
                except:
                  pass
              except:
                pass
        except:
          pass
    
    
    for e in reduce_list:
      # if "_conformer" in e:
    
      shutil.make_archive(e, 'zip', e)
      # else:
      #   if "focus" in e:
      #     final_file = new_DIR.split("focus")[0]+"final"
      #     shutil.make_archive(final_file, 'zip', final_file)
    
    
    # import shutil
    try:
      shutil.rmtree(user_folder)
    except:
      pass

    if args.summary:
      import json
      summary_path = Path(args.summary)
      base = Path("Completed_Job")
      focus_dirs = []
      selected_xyz = []
      if base.exists():
        for p in base.rglob("*_focus_CCS_*"):
          if p.is_dir():
            focus_dirs.append(str(p))
            selected_xyz.extend([str(x) for x in p.glob("*.xyz")])
        if not selected_xyz:
          for p in base.rglob("*_conformer"):
            if p.is_dir():
              selected_xyz.extend([str(x) for x in p.glob("*.xyz")])
      summary = {
        "completed_job_dir": str(base) if base.exists() else "",
        "focus_dirs": focus_dirs,
        "reduce_list": [str(p) for p in (locals().get("reduce_list", []) or [])],
        "selected_xyz": selected_xyz,
      }
      summary_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")

if __name__ == '__main__':
    main()
