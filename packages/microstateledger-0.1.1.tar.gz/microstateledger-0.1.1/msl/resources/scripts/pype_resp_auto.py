from __future__ import annotations

import argparse
import json
import math
import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import List, Tuple

from rdkit import Chem
from rdkit.Chem import AllChem, rdPartialCharges
import numpy as np

BOHR = 0.52917721092

VDW_RADII = {
    1: 1.20,
    6: 1.70,
    7: 1.55,
    8: 1.52,
    9: 1.47,
    15: 1.80,
    16: 1.80,
    17: 1.75,
    35: 1.85,
    53: 1.98,
}


def _default_qm_theory(engine: str, qm_theory: str) -> str:
    theory = qm_theory.strip()
    if engine in {"psi4", "orca"} and theory.upper() == "PM6":
        return "HF/6-31G*"
    # SQM supports semi-empirical keywords; map HF/basis-like input to PM6.
    if engine == "sqm" and (not theory or "/" in theory):
        return "PM6"
    return theory


def _parse_qm_theory(qm_theory: str) -> tuple[str, str]:
    if "/" in qm_theory:
        method, basis = qm_theory.split("/", 1)
        return method.strip(), basis.strip()
    return qm_theory.strip(), ""


def _infer_multiplicity(mol: Chem.Mol, fallback: int) -> int:
    radicals = sum(int(a.GetNumRadicalElectrons() or 0) for a in mol.GetAtoms())
    if radicals > 0:
        return radicals + 1
    return max(1, fallback)


def fibonacci_sphere(samples: int) -> List[tuple[float, float, float]]:
    points = []
    if samples <= 0:
        return points
    phi = math.pi * (3.0 - math.sqrt(5.0))
    for i in range(samples):
        y = 1 - (i / float(samples - 1)) * 2 if samples > 1 else 0.0
        radius = math.sqrt(max(0.0, 1 - y * y))
        theta = phi * i
        x = math.cos(theta) * radius
        z = math.sin(theta) * radius
        points.append((x, y, z))
    return points


def generate_surface_points(
    mol: Chem.Mol, points_per_atom: int, probe: float
) -> Tuple[List[tuple[float, float, float]], List[int], List[str], List[tuple[float, float, float]]]:
    conf = mol.GetConformer()
    coords = []
    elems = []
    symbols = []
    for atom in mol.GetAtoms():
        pos = conf.GetAtomPosition(atom.GetIdx())
        coords.append((pos.x, pos.y, pos.z))
        elems.append(atom.GetAtomicNum())
        symbols.append(atom.GetSymbol())

    points: List[tuple[float, float, float]] = []
    unit_points = fibonacci_sphere(points_per_atom)
    for i, (x, y, z) in enumerate(coords):
        znum = elems[i]
        r = VDW_RADII.get(znum, 1.6) * probe
        for vx, vy, vz in unit_points:
            px = x + r * vx
            py = y + r * vy
            pz = z + r * vz
            ok = True
            for j, (ax, ay, az) in enumerate(coords):
                rmin = VDW_RADII.get(elems[j], 1.6) * probe
                dx = px - ax
                dy = py - ay
                dz = pz - az
                if dx * dx + dy * dy + dz * dz < rmin * rmin:
                    ok = False
                    break
            if ok:
                points.append((px, py, pz))

    return coords, elems, symbols, points


def write_espot(
    coords: List[tuple[float, float, float]],
    elems: List[int],
    symbols: List[str],
    points: List[tuple[float, float, float]],
    potentials: List[float],
    out_path: Path,
) -> None:
    natom = len(coords)
    nesp = len(points)
    lines = []
    lines.append(f"{natom:5d}{nesp:5d}    0 MOL        {natom:5d}{nesp:6d}")
    for i, (x, y, z) in enumerate(coords):
        xb, yb, zb = x / BOHR, y / BOHR, z / BOHR
        znum = elems[i]
        sym = symbols[i].lower()
        name = f"{symbols[i]}{i+1}"
        lines.append(" " * 16 + f"{xb:15.7E}{yb:15.7E}{zb:15.7E}{znum:4d} {sym:2s} {name:4s}")

    for (v, (x, y, z)) in zip(potentials, points):
        xb, yb, zb = x / BOHR, y / BOHR, z / BOHR
        lines.append(f"{v:15.7E}{xb:15.7E}{yb:15.7E}{zb:15.7E}")

    out_path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def ensure_3d(mol: Chem.Mol) -> Chem.Mol:
    mol = Chem.AddHs(mol, addCoords=True)
    if mol.GetNumConformers() == 0 or not mol.GetConformer().Is3D():
        params = AllChem.ETKDGv3()
        AllChem.EmbedMolecule(mol, params)
        try:
            AllChem.MMFFOptimizeMolecule(mol)
        except Exception:
            AllChem.UFFOptimizeMolecule(mol)
    return mol


def write_sqm_input(mol: Chem.Mol, out_path: Path, qm_theory: str, charge: int) -> None:
    conf = mol.GetConformer()
    lines: List[str] = []
    lines.append("SQM single point")
    lines.append(" &qmmm")
    lines.append(f"    qm_theory    = \"{qm_theory}\",")
    lines.append(f"    qmcharge     = {int(charge)},")
    lines.append("    scfconv      = 1.0d-10,")
    lines.append("    errconv      = 1.d-06,")
    lines.append("    maxcyc       = 0,")
    lines.append("    verbosity    = 0,")
    lines.append(" /")
    for atom in mol.GetAtoms():
        z = atom.GetAtomicNum()
        sym = atom.GetSymbol()
        pos = conf.GetAtomPosition(atom.GetIdx())
        lines.append(f" {z:2d} {sym:2s} {pos.x:12.6f} {pos.y:12.6f} {pos.z:12.6f}")
    out_path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def run_sqm(out_dir: Path, amberhome: Path) -> Path:
    sqm_in = out_dir / "sqm.in"
    sqm_out = out_dir / "sqm.out"
    env = os.environ.copy()
    env["AMBERHOME"] = str(amberhome)
    cmd = [str(amberhome / "bin" / "sqm"), "-O", "-i", "sqm.in", "-o", "sqm.out"]
    result = subprocess.run(cmd, cwd=str(out_dir), env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if result.returncode != 0:
        raise SystemExit(f"sqm failed\nSTDOUT:\n{result.stdout}\nSTDERR:\n{result.stderr}")
    if not sqm_out.exists():
        raise SystemExit("sqm.out not generated")
    return sqm_out


def parse_mulliken_charges(sqm_out: Path, natom: int) -> List[float]:
    charges: List[float] = []
    in_block = False
    for line in sqm_out.read_text(encoding="utf-8").splitlines():
        if "Atomic Charges for Step" in line:
            in_block = True
            continue
        if in_block:
            if line.strip().startswith("Atom"):
                continue
            if line.strip().startswith("Total"):
                break
            if not line.strip():
                continue
            parts = line.split()
            if len(parts) >= 4:
                charges.append(float(parts[-1]))
    if len(charges) != natom:
        return []
    return charges


def psi4_mulliken_charges(mol: Chem.Mol, qm_theory: str, charge: int) -> List[float]:
    try:
        import psi4  # type: ignore
    except Exception:
        return []
    try:
        psi4.core.set_output_file("psi4.out", False)
    except Exception:
        pass
    conf = mol.GetConformer()
    coords = []
    for atom in mol.GetAtoms():
        pos = conf.GetAtomPosition(atom.GetIdx())
        coords.append(f"{atom.GetSymbol()} {pos.x:.6f} {pos.y:.6f} {pos.z:.6f}")
    geo = f"{int(charge)} 1\n" + "\n".join(coords) + "\n"
    try:
        pmol = psi4.geometry(geo)
        energy, wfn = psi4.energy(qm_theory, molecule=pmol, return_wfn=True)
        psi4.oeprop(wfn, "MULLIKEN_CHARGES")
    except Exception:
        return []
    charges = []
    try:
        vec = wfn.atomic_point_charges()
        try:
            charges = list(vec.to_array())
        except Exception:
            charges = list(vec)
    except Exception:
        charges = []
    if len(charges) != mol.GetNumAtoms():
        return []
    return [float(q) for q in charges]


def psi4_compute_esp(
    mol: Chem.Mol,
    points: List[tuple[float, float, float]],
    qm_theory: str,
    charge: int,
    multiplicity: int,
    out_dir: Path,
) -> List[float]:
    try:
        import psi4  # type: ignore
    except Exception:
        return []
    try:
        psi4.core.set_output_file(str(out_dir / "psi4.out"), False)
    except Exception:
        pass

    method, basis = _parse_qm_theory(qm_theory)
    if basis:
        psi4.set_options({"basis": basis})
    psi4.set_options({"scf_type": "pk"})

    conf = mol.GetConformer()
    coords = []
    for atom in mol.GetAtoms():
        pos = conf.GetAtomPosition(atom.GetIdx())
        coords.append(f"{atom.GetSymbol()} {pos.x:.6f} {pos.y:.6f} {pos.z:.6f}")
    geo = f"{int(charge)} {int(multiplicity)}\n" + "\n".join(coords) + "\n"

    try:
        pmol = psi4.geometry(geo)
        _, wfn = psi4.energy(method, molecule=pmol, return_wfn=True)
        mat = psi4.core.Matrix.from_array(np.array([[x / BOHR, y / BOHR, z / BOHR] for x, y, z in points]))
        esp = psi4.core.ESPPropCalc(wfn)
        vec = esp.compute_esp_over_grid_in_memory(mat)
        return [float(v) for v in vec.np.flatten().tolist()]
    except Exception:
        return []


def orca_compute_esp(
    mol: Chem.Mol,
    points: List[tuple[float, float, float]],
    qm_theory: str,
    charge: int,
    multiplicity: int,
    out_dir: Path,
) -> List[float]:
    orca = shutil.which("orca")
    orca_esp = shutil.which("orca_esp")
    if not orca or not orca_esp:
        return []

    method, basis = _parse_qm_theory(qm_theory)
    if not basis:
        basis = "6-31G*"

    conf = mol.GetConformer()
    coords = []
    for atom in mol.GetAtoms():
        pos = conf.GetAtomPosition(atom.GetIdx())
        coords.append(f"  {atom.GetSymbol():2s} {pos.x:12.6f} {pos.y:12.6f} {pos.z:12.6f}")

    inp = out_dir / "orca.inp"
    inp.write_text(
        "\n".join(
            [
                f"! {method} {basis} TightSCF",
                "%output",
                "  Print[P_Basis] 2",
                "end",
                f"* xyz {int(charge)} {int(multiplicity)}",
                *coords,
                "*",
            ]
        )
        + "\n",
        encoding="utf-8",
    )

    result = subprocess.run([orca, str(inp)], cwd=str(out_dir), stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if result.returncode != 0:
        return []

    # ORCA ESP requires orca_esp, which consumes point list in Bohr.
    pts_path = out_dir / "esp_points.txt"
    pts_path.write_text("\n".join([f"{x/BOHR:15.8f} {y/BOHR:15.8f} {z/BOHR:15.8f}" for x, y, z in points]) + "\n")
    esp_out = out_dir / "orca_esp.txt"
    result = subprocess.run(
        [orca_esp, str(out_dir / "orca.gbw"), str(pts_path), str(esp_out)],
        cwd=str(out_dir),
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
    if result.returncode != 0 or not esp_out.exists():
        return []

    potentials = []
    for line in esp_out.read_text(encoding="utf-8").splitlines():
        parts = line.split()
        if len(parts) >= 4:
            potentials.append(float(parts[3]))
    if len(potentials) != len(points):
        return []
    return potentials


def gasteiger_charges(mol: Chem.Mol) -> List[float]:
    rdPartialCharges.ComputeGasteigerCharges(mol)
    charges = []
    for atom in mol.GetAtoms():
        charges.append(float(atom.GetProp("_GasteigerCharge")))
    return charges


def parse_qout_charges(path: Path) -> List[float]:
    lines = path.read_text(encoding="utf-8").splitlines()
    charges: List[float] = []
    in_block = False
    for line in lines:
        if line.startswith("%FLAG ATOM CHRG"):
            in_block = True
            continue
        if in_block:
            if line.startswith("%FLAG"):
                break
            if line.strip().startswith("atm.no"):
                continue
            if not line.strip():
                continue
            parts = line.split()
            if len(parts) >= 4:
                charges.append(float(parts[-1]))
    return charges


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--sdf", required=True)
    ap.add_argument("--out-dir", required=True)
    ap.add_argument("--atom-map", required=True)
    ap.add_argument("--charge", type=int, default=0)
    ap.add_argument("--qm-theory", default="PM6")
    ap.add_argument("--qm-engine", default="sqm", help="sqm|psi4|orca|auto")
    ap.add_argument("--multiplicity", type=int, default=1)
    ap.add_argument("--points-per-atom", type=int, default=120)
    ap.add_argument("--probe", type=float, default=1.4)
    args = ap.parse_args()

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    mol = Chem.SDMolSupplier(args.sdf, removeHs=False)[0]
    if mol is None:
        raise SystemExit("failed to read mol")
    mol = ensure_3d(mol)

    engine = args.qm_engine.lower()
    auto_mode = engine == "auto"
    if auto_mode:
        try:
            import psi4  # type: ignore
            engine = "psi4"
        except Exception:
            if shutil.which("orca") and shutil.which("orca_esp"):
                engine = "orca"
            else:
                engine = "sqm"

    qm_theory = _default_qm_theory(engine, args.qm_theory)
    multiplicity = _infer_multiplicity(mol, args.multiplicity)

    coords, elems, symbols, points = generate_surface_points(mol, args.points_per_atom, args.probe)

    potentials: List[float] = []
    if engine == "psi4":
        potentials = psi4_compute_esp(mol, points, qm_theory, args.charge, multiplicity, out_dir)
        if not potentials:
            if auto_mode:
                engine = "sqm"
            else:
                raise SystemExit("psi4 ESP failed (check psi4 install / convergence)")
    elif engine == "orca":
        potentials = orca_compute_esp(mol, points, qm_theory, args.charge, multiplicity, out_dir)
        if not potentials:
            if auto_mode:
                engine = "sqm"
            else:
                raise SystemExit("ORCA ESP failed (requires orca + orca_esp in PATH)")

    if not potentials:
        # Fallback: compute ESP from approximate charges.
        charges: List[float] = []
        charges = psi4_mulliken_charges(mol, qm_theory, args.charge)
        if not charges:
            sqm_in = out_dir / "sqm.in"
            write_sqm_input(mol, sqm_in, qm_theory, args.charge)

            amberhome = Path(os.environ.get("AMBERHOME", "/opt/amber/amber22"))
            sqm_out = run_sqm(out_dir, amberhome)

            charges = parse_mulliken_charges(sqm_out, mol.GetNumAtoms())

        if not charges:
            charges = gasteiger_charges(mol)

        # Coulombic ESP from approximate charges
        for (x, y, z) in points:
            v = 0.0
            for q, (ax, ay, az) in zip(charges, coords):
                dx = (x - ax) / BOHR
                dy = (y - ay) / BOHR
                dz = (z - az) / BOHR
                r = math.sqrt(dx * dx + dy * dy + dz * dz)
                if r > 1e-6:
                    v += q / r
            potentials.append(v)

    espot = out_dir / "resp.espot"
    write_espot(coords, elems, symbols, points, potentials, espot)

    resp1 = out_dir / "resp1.in"
    resp2 = out_dir / "resp2.in"
    amberhome = Path(os.environ.get("AMBERHOME", "/opt/amber/amber22"))
    pyresp_gen = amberhome / "bin" / "pyresp_gen.py"
    env = os.environ.copy()
    env["AMBERHOME"] = str(amberhome)
    cmd_gen = [str(pyresp_gen), "-i", str(espot), "-p", "chg", "-f1", str(resp1), "-f2", str(resp2), "-q", str(args.charge)]
    result = subprocess.run(cmd_gen, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if result.returncode != 0:
        raise SystemExit(f"pyresp_gen failed\nSTDOUT:\n{result.stdout}\nSTDERR:\n{result.stderr}")

    py_resp = amberhome / "bin" / "py_resp.py"
    resp1_out = out_dir / "resp1.out"
    resp1_chg = out_dir / "resp1.chg"
    resp1_esp = out_dir / "resp1.esp"
    cmd1 = [str(py_resp), "-O", "-i", str(resp1), "-o", str(resp1_out), "-t", str(resp1_chg), "-e", str(espot), "-s", str(resp1_esp)]
    result = subprocess.run(cmd1, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if result.returncode != 0:
        raise SystemExit(f"py_resp stage1 failed\nSTDOUT:\n{result.stdout}\nSTDERR:\n{result.stderr}")

    resp2_out = out_dir / "resp2.out"
    resp2_chg = out_dir / "resp2.chg"
    resp2_esp = out_dir / "resp2.esp"
    cmd2 = [str(py_resp), "-O", "-i", str(resp2), "-o", str(resp2_out), "-t", str(resp2_chg), "-e", str(espot), "-q", str(resp1_chg), "-s", str(resp2_esp)]
    result = subprocess.run(cmd2, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if result.returncode != 0:
        raise SystemExit(f"py_resp stage2 failed\nSTDOUT:\n{result.stdout}\nSTDERR:\n{result.stderr}")

    charges2 = parse_qout_charges(resp2_chg)
    if len(charges2) != mol.GetNumAtoms():
        raise SystemExit(f"RESP charge count mismatch: {len(charges2)} vs {mol.GetNumAtoms()}")

    mapping = json.loads(Path(args.atom_map).read_text(encoding="utf-8"))
    mapping_sorted = sorted(mapping, key=lambda x: int(x["atom_index"]))

    out_charges = []
    for i, entry in enumerate(mapping_sorted):
        out_charges.append({
            "canonical_atom_id": int(entry["canonical_atom_id"]),
            "charge": float(charges2[i]),
        })

    if out_charges:
        total = sum(c["charge"] for c in out_charges)
        residual = float(args.charge) - total
        if abs(residual) > 1e-6:
            correction = residual / len(out_charges)
            for c in out_charges:
                c["charge"] = float(c["charge"] + correction)
            print(f"WARN: charge residual {residual:.6f} corrected by {correction:.6f} per atom", file=sys.stderr)

    print(json.dumps(out_charges, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
