from __future__ import annotations

import argparse
import json
import shutil
import subprocess
from pathlib import Path


def parse_qout_charges(path: Path) -> list[float]:
    lines = path.read_text(encoding="utf-8").splitlines()
    charges = []
    in_block = False
    for line in lines:
        if line.startswith("%FLAG ATOM CHRG"):
            in_block = True
            continue
        if in_block:
            if line.startswith("%FLAG"):
                break
            if line.strip().startswith("atm.no"):
                continue
            if not line.strip():
                continue
            parts = line.split()
            if len(parts) < 4:
                continue
            charges.append(float(parts[-1]))
    return charges


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--resp-input", required=True)
    ap.add_argument("--espot", required=True)
    ap.add_argument("--out-dir", required=True)
    ap.add_argument("--atom-map", required=True)
    ap.add_argument("--qin", default="")
    ap.add_argument("--polariz", default="")
    args = ap.parse_args()

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    in_path = Path(args.resp_input)
    esp_path = Path(args.espot)
    if not in_path.exists() or not esp_path.exists():
        raise SystemExit("resp input or espot file not found")

    resp_in = out_dir / "resp.in"
    resp_esp = out_dir / "resp.espot"
    shutil.copy2(in_path, resp_in)
    shutil.copy2(esp_path, resp_esp)

    resp_out = out_dir / "resp.out"
    resp_qout = out_dir / "resp.qout"

    cmd = [
        "py_resp.py",
        "-i",
        str(resp_in),
        "-o",
        str(resp_out),
        "-t",
        str(resp_qout),
        "-e",
        str(resp_esp),
    ]
    if args.qin:
        cmd += ["-q", args.qin]
    if args.polariz:
        cmd += ["-ip", args.polariz]

    result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if result.returncode != 0:
        raise SystemExit(f"py_resp.py failed\nSTDOUT:\n{result.stdout}\nSTDERR:\n{result.stderr}")

    charges = parse_qout_charges(resp_qout)
    mapping = json.loads(Path(args.atom_map).read_text(encoding="utf-8"))
    mapping_sorted = sorted(mapping, key=lambda x: int(x["atom_index"]))

    if len(charges) != len(mapping_sorted):
        raise SystemExit(f"charge count mismatch: {len(charges)} vs {len(mapping_sorted)}")

    out_charges = []
    for i, entry in enumerate(mapping_sorted):
        out_charges.append({
            "canonical_atom_id": int(entry["canonical_atom_id"]),
            "charge": float(charges[i]),
        })

    print(json.dumps(out_charges, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
