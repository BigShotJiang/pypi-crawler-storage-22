from __future__ import annotations

import argparse
import json
from typing import List, Tuple

from rdkit import Chem
from rdkit.Chem import rdMolAlign, rdMolTransforms


def _read_mol(path: str) -> Chem.Mol:
    mol = Chem.SDMolSupplier(path, removeHs=False)[0]
    if mol is None:
        raise SystemExit(f"failed to read {path}")
    return mol


def _rotatable_bonds(mol: Chem.Mol) -> List[Tuple[int, int]]:
    smarts = Chem.MolFromSmarts("[!$(*#*)&!D1]-!@[!$(*#*)&!D1]")
    matches = mol.GetSubstructMatches(smarts)
    return [(a, b) for a, b in matches]


def _pick_dihedral_atoms(mol: Chem.Mol, a: int, b: int) -> Tuple[int, int, int, int] | None:
    # pick one neighbor on each side not the bond partner
    na = [n.GetIdx() for n in mol.GetAtomWithIdx(a).GetNeighbors() if n.GetIdx() != b]
    nb = [n.GetIdx() for n in mol.GetAtomWithIdx(b).GetNeighbors() if n.GetIdx() != a]
    if not na or not nb:
        return None
    return (na[0], a, b, nb[0])


def _dihedral(mol: Chem.Mol, idxs: Tuple[int, int, int, int]) -> float:
    conf = mol.GetConformer()
    if hasattr(rdMolAlign, "GetDihedralDeg"):
        return rdMolAlign.GetDihedralDeg(conf, *idxs)
    return rdMolTransforms.GetDihedralDeg(conf, *idxs)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--a", required=True)
    ap.add_argument("--b", required=True)
    args = ap.parse_args()

    mol_a = _read_mol(args.a)
    mol_b = _read_mol(args.b)

    mol_a_h = Chem.RemoveHs(mol_a)
    mol_b_h = Chem.RemoveHs(mol_b)

    if mol_a_h.GetNumAtoms() != mol_b_h.GetNumAtoms():
        print(
            json.dumps(
                {
                    "alignable": False,
                    "reason": "atom_count_mismatch",
                    "atoms_a": int(mol_a_h.GetNumAtoms()),
                    "atoms_b": int(mol_b_h.GetNumAtoms()),
                },
                ensure_ascii=False,
                indent=2,
            )
        )
        return

    try:
        rmsd = rdMolAlign.GetBestRMS(mol_a_h, mol_b_h)
    except Exception as e:
        print(
            json.dumps(
                {
                    "alignable": False,
                    "reason": "alignment_failed",
                    "error": str(e),
                },
                ensure_ascii=False,
                indent=2,
            )
        )
        return

    torsions = []
    for a, b in _rotatable_bonds(mol_a_h):
        idxs = _pick_dihedral_atoms(mol_a_h, a, b)
        if idxs is None:
            continue
        d1 = _dihedral(mol_a_h, idxs)
        d2 = _dihedral(mol_b_h, idxs)
        delta = d2 - d1
        while delta > 180:
            delta -= 360
        while delta < -180:
            delta += 360
        torsions.append({
            "bond": [int(a), int(b)],
            "dihedral_a": float(d1),
            "dihedral_b": float(d2),
            "delta": float(delta),
        })

    print(json.dumps({"alignable": True, "rmsd": float(rmsd), "torsions": torsions}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
