from __future__ import annotations

import argparse
import json
from pathlib import Path

from rdkit import Chem


def _load(path: str) -> Chem.Mol:
    suppl = Chem.SDMolSupplier(str(path), removeHs=False)
    mol = next((m for m in suppl if m is not None), None)
    if mol is None:
        raise ValueError(f"Failed to read {path}")
    return mol


def _bond_map(mol: Chem.Mol):
    m = {}
    for b in mol.GetBonds():
        a = b.GetBeginAtomIdx()
        c = b.GetEndAtomIdx()
        key = tuple(sorted((a, c)))
        m[key] = str(b.GetBondType())
    return m


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--a", required=True)
    ap.add_argument("--b", required=True)
    args = ap.parse_args()

    mol_a = _load(args.a)
    mol_b = _load(args.b)

    diff = {
        "smiles_a": Chem.MolToSmiles(mol_a, isomericSmiles=True),
        "smiles_b": Chem.MolToSmiles(mol_b, isomericSmiles=True),
        "formal_charge_a": Chem.GetFormalCharge(mol_a),
        "formal_charge_b": Chem.GetFormalCharge(mol_b),
        "chiral_centers_a": Chem.FindMolChiralCenters(mol_a, includeUnassigned=True),
        "chiral_centers_b": Chem.FindMolChiralCenters(mol_b, includeUnassigned=True),
        "bond_order_changes": [],
    }

    bonds_a = _bond_map(mol_a)
    bonds_b = _bond_map(mol_b)
    all_keys = set(bonds_a) | set(bonds_b)
    for k in sorted(all_keys):
        if bonds_a.get(k) != bonds_b.get(k):
            diff["bond_order_changes"].append({"bond": k, "a": bonds_a.get(k), "b": bonds_b.get(k)})

    print(json.dumps(diff, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
