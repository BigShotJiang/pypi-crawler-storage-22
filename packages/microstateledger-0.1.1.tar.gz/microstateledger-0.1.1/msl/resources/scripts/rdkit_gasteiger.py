from __future__ import annotations

import argparse
import json
from pathlib import Path

from rdkit import Chem
from rdkit.Chem import rdPartialCharges


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--sdf", required=True)
    ap.add_argument("--atom-map", required=True)
    args = ap.parse_args()

    mol = Chem.SDMolSupplier(args.sdf, removeHs=False)[0]
    if mol is None:
        raise SystemExit("failed to read mol")

    rdPartialCharges.ComputeGasteigerCharges(mol)

    mapping = json.loads(Path(args.atom_map).read_text(encoding="utf-8"))
    charges = []
    for entry in mapping:
        atom = mol.GetAtomWithIdx(int(entry["atom_index"]))
        q = float(atom.GetProp("_GasteigerCharge"))
        charges.append({
            "canonical_atom_id": int(entry["canonical_atom_id"]),
            "charge": q,
        })

    print(json.dumps(charges, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
