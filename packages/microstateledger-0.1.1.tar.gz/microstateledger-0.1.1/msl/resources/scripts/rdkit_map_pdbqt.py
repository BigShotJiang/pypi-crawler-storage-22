#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path

from rdkit import Chem


def _parse_pdbqt(path: Path):
    atoms = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if not (line.startswith("ATOM") or line.startswith("HETATM")):
            continue
        try:
            x = float(line[30:38])
            y = float(line[38:46])
            z = float(line[46:54])
        except Exception:
            parts = line.split()
            if len(parts) < 9:
                continue
            try:
                x = float(parts[6])
                y = float(parts[7])
                z = float(parts[8])
            except Exception:
                continue
        atom_name = line[12:16].strip()
        element = line[76:78].strip()
        parts = line.split()
        atom_type = parts[-1] if parts else ""
        if not element:
            if atom_type:
                element = "".join([c for c in atom_type if c.isalpha()])[:2]
            if not element:
                element = "".join([c for c in atom_name if c.isalpha()])[:2]
        element = element.capitalize()
        atoms.append(
            {
                "atom_name": atom_name,
                "element": element,
                "atom_type": atom_type,
                "x": x,
                "y": y,
                "z": z,
            }
        )
    return atoms


def _dist(a, b) -> float:
    return math.sqrt((a["x"] - b["x"]) ** 2 + (a["y"] - b["y"]) ** 2 + (a["z"] - b["z"]) ** 2)


def main() -> int:
    ap = argparse.ArgumentParser(description="Map canonical atom IDs to PDBQT atom indices via coordinates.")
    ap.add_argument("--sdf", required=True, help="Input SDF with coordinates")
    ap.add_argument("--pdbqt", required=True, help="Meeko PDBQT output")
    ap.add_argument("--atom-map", required=True, help="atom_map.json with canonical_atom_id and atom_index")
    ap.add_argument("--out", default="", help="Optional output JSON path")
    ap.add_argument("--distance-cutoff", type=float, default=1.5, help="Warn if mapping distance exceeds cutoff")
    args = ap.parse_args()

    sdf_path = Path(args.sdf)
    pdbqt_path = Path(args.pdbqt)
    map_path = Path(args.atom_map)

    mols = Chem.SDMolSupplier(str(sdf_path), removeHs=False)
    mol = mols[0] if mols else None
    if mol is None:
        print("ERROR: failed to read SDF", file=sys.stderr)
        return 2
    conf = mol.GetConformer()

    mapping = json.loads(map_path.read_text(encoding="utf-8"))
    by_index = {int(row["atom_index"]): row for row in mapping}

    heavy_atoms = []
    for atom in mol.GetAtoms():
        if atom.GetSymbol() == "H":
            continue
        idx = atom.GetIdx()
        pos = conf.GetAtomPosition(idx)
        heavy_atoms.append(
            {
                "atom_index": idx,
                "symbol": atom.GetSymbol(),
                "x": pos.x,
                "y": pos.y,
                "z": pos.z,
            }
        )

    pdbqt_atoms = _parse_pdbqt(pdbqt_path)
    if not pdbqt_atoms:
        print("ERROR: no atoms parsed from PDBQT", file=sys.stderr)
        return 3

    unused = set(range(len(heavy_atoms)))
    assignments = {}
    warnings = []
    for pdbqt_idx, patom in enumerate(pdbqt_atoms, start=1):
        matches = [i for i in unused if heavy_atoms[i]["symbol"].upper() == patom["element"].upper()]
        if not matches:
            matches = list(unused)
        if not matches:
            warnings.append(f"unmapped_pdbqt_atom_{pdbqt_idx}")
            continue
        best = min(matches, key=lambda i: _dist(patom, heavy_atoms[i]))
        d = _dist(patom, heavy_atoms[best])
        element_match = heavy_atoms[best]["symbol"].upper() == patom["element"].upper()
        if d > args.distance_cutoff:
            warnings.append(f"large_distance:{pdbqt_idx}:{d:.3f}")
        assignments[heavy_atoms[best]["atom_index"]] = {
            "pdbqt_atom_index": pdbqt_idx,
            "match_distance": d,
            "element_match": element_match,
            "atom_name": patom["atom_name"],
            "element": patom["element"],
            "atom_type": patom["atom_type"],
        }
        unused.remove(best)

    sidecar = []
    for entry in mapping:
        atom_index = int(entry["atom_index"])
        symbol = entry.get("symbol")
        if not symbol and atom_index in by_index:
            symbol = by_index[atom_index].get("symbol", "")
        payload = {
            "canonical_atom_id": entry["canonical_atom_id"],
            "atom_index": atom_index,
            "symbol": symbol or "",
        }
        assigned = assignments.get(atom_index)
        if assigned:
            payload.update(
                {
                    "pdbqt_atom_index": assigned["pdbqt_atom_index"],
                    "present_in_pdbqt": True,
                    "atom_name": assigned["atom_name"],
                    "element": assigned["element"],
                    "atom_type": assigned["atom_type"],
                    "match_distance": assigned["match_distance"],
                    "element_match": assigned["element_match"],
                }
            )
        else:
            payload.update({"pdbqt_atom_index": None, "present_in_pdbqt": False})
        sidecar.append(payload)

    if warnings:
        print("WARN:" + ";".join(warnings), file=sys.stderr)

    if args.out:
        Path(args.out).write_text(json.dumps(sidecar, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    else:
        print(json.dumps(sidecar, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
