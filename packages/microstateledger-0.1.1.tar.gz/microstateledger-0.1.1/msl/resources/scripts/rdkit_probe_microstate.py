from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

from rdkit import Chem
from rdkit.Chem import Lipinski, QED
from rdkit.Chem.MolStandardize import rdMolStandardize


def microstate_id(fixedh_inchi: str, formal_charge: int, stereo_tag: str, coordination_sig: str = "") -> str:
    payload = f"{fixedh_inchi}|{formal_charge}|{stereo_tag}|{coordination_sig}"
    return "M-" + hashlib.sha256(payload.encode("utf-8")).hexdigest()[:12]


METAL_ATOMIC_NUMS = set([
    3, 4, 11, 12, 13, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30,
    31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47,
    48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64,
    65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81,
    82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94,
])

COORDINATION_MOTIFS = [
    ("carboxylate", Chem.MolFromSmarts("[CX3](=O)[O-]")),
    ("carboxylic_acid", Chem.MolFromSmarts("[CX3](=O)[OH]")),
    ("hydroxamate", Chem.MolFromSmarts("[CX3](=O)N[O-]")),
    ("catechol", Chem.MolFromSmarts("c1ccc(O)c(O)cc1")),
    ("beta_diketonate", Chem.MolFromSmarts("O=C-C(=O)")),
    ("pyridine", Chem.MolFromSmarts("n1ccccc1")),
    ("imidazole", Chem.MolFromSmarts("n1cncc1")),
    ("bipyridine", Chem.MolFromSmarts("n1ccccn1")),
    ("phenanthroline", Chem.MolFromSmarts("n1ccc2ncccc2c1")),
    ("thiol", Chem.MolFromSmarts("[SX2H]")),
    ("thioether", Chem.MolFromSmarts("[SX2]([#6])[#6]")),
    ("phosphine", Chem.MolFromSmarts("[PX3]")),
]


def coordination_signature(mol: Chem.Mol) -> str:
    metals = []
    donors = []
    for atom in mol.GetAtoms():
        z = atom.GetAtomicNum()
        if z in METAL_ATOMIC_NUMS:
            metals.append(atom.GetSymbol())
        if atom.GetSymbol() in ("N", "O", "S", "P") and atom.GetFormalCharge() <= 0:
            donors.append(atom.GetSymbol())

    motifs = []
    for name, smarts in COORDINATION_MOTIFS:
        if smarts is None:
            continue
        if mol.HasSubstructMatch(smarts):
            motifs.append(name)

    if not metals and not donors and not motifs:
        return ""
    metals_str = ",".join(sorted(set(metals))) if metals else "none"
    donors_str = ",".join(sorted(set(donors))) if donors else "none"
    donor_count = len(donors)
    motifs_str = ",".join(sorted(set(motifs))) if motifs else "none"
    return f"metals:{metals_str};donors:{donors_str};donor_count:{donor_count};motifs:{motifs_str}"


def apply_atom_map(mol: Chem.Mol) -> list[dict]:
    ranks = list(Chem.CanonicalRankAtoms(mol))
    order = sorted(range(len(ranks)), key=lambda i: (ranks[i], i))
    mapping = []
    for new_id, atom_idx in enumerate(order, start=1):
        mol.GetAtomWithIdx(atom_idx).SetAtomMapNum(new_id)
        mapping.append({
            "canonical_atom_id": new_id,
            "atom_index": atom_idx,
            "symbol": mol.GetAtomWithIdx(atom_idx).GetSymbol(),
        })
    return mapping


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--probe", required=True)
    ap.add_argument("--out-dir", required=True)
    args = ap.parse_args()

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    suppl = Chem.SDMolSupplier(args.probe, removeHs=False, sanitize=False)
    mol = next((m for m in suppl if m is not None), None)
    if mol is None:
        raise SystemExit("failed to read probe")
    try:
        Chem.SanitizeMol(mol)
    except Exception as exc:
        raise SystemExit(f"sanitize failed: {exc}")

    mol_nomap = Chem.Mol(mol)
    for atom in mol_nomap.GetAtoms():
        atom.SetAtomMapNum(0)

    fixedh = Chem.MolToInchi(Chem.AddHs(mol_nomap, addCoords=False), options="/FixedH")
    stereo_tag = Chem.MolToSmiles(mol_nomap, isomericSmiles=True)
    charge = Chem.GetFormalCharge(mol_nomap)
    coord_sig = coordination_signature(mol_nomap)
    mid = microstate_id(fixedh, charge, stereo_tag, coord_sig)

    mapping = apply_atom_map(mol)
    sdf_path = out_dir / "microstate.sdf"
    w = Chem.SDWriter(str(sdf_path))
    w.write(mol)
    w.close()

    map_path = out_dir / "atom_map.json"
    map_path.write_text(json.dumps(mapping, ensure_ascii=False, indent=2), encoding="utf-8")

    try:
        hbd = int(Lipinski.NumHDonors(mol))
        hba = int(Lipinski.NumHAcceptors(mol))
        rdkit_score = float(QED.qed(mol))
    except Exception:
        hbd, hba, rdkit_score = 0, 0, 0.0

    print(json.dumps({
        "microstate_id": mid,
        "fixedh_inchi": fixedh,
        "formal_charge": charge,
        "stereo_tag": stereo_tag,
        "coordination_sig": coord_sig,
        "sdf_path": str(sdf_path),
        "atom_map_path": str(map_path),
        "hbd": hbd,
        "hba": hba,
        "rdkit_score": rdkit_score,
    }))


if __name__ == "__main__":
    main()
