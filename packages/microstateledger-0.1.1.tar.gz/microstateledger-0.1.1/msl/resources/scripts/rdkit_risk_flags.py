from __future__ import annotations

import argparse
import json
from pathlib import Path

from rdkit import Chem


METAL_ATOMIC_NUMS = set([
    3, 4, 11, 12, 13, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30,
    31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47,
    48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64,
    65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81,
    82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94,
])

COORDINATION_MOTIFS = [
    ("carboxylate", Chem.MolFromSmarts("[CX3](=O)[O-]")),
    ("carboxylic_acid", Chem.MolFromSmarts("[CX3](=O)[OH]")),
    ("hydroxamate", Chem.MolFromSmarts("[CX3](=O)N[O-]")),
    ("catechol", Chem.MolFromSmarts("c1ccc(O)c(O)cc1")),
    ("beta_diketonate", Chem.MolFromSmarts("O=C-C(=O)")),
    ("pyridine", Chem.MolFromSmarts("n1ccccc1")),
    ("imidazole", Chem.MolFromSmarts("n1cncc1")),
    ("bipyridine", Chem.MolFromSmarts("n1ccccn1")),
    ("phenanthroline", Chem.MolFromSmarts("n1ccc2ncccc2c1")),
    ("thiol", Chem.MolFromSmarts("[SX2H]")),
    ("thioether", Chem.MolFromSmarts("[SX2]([#6])[#6]")),
    ("phosphine", Chem.MolFromSmarts("[PX3]")),
]


def _read(input_path: str) -> Chem.Mol:
    p = Path(input_path)
    if p.exists():
        if p.suffix.lower() in {".sdf", ".mol"}:
            suppl = Chem.SDMolSupplier(str(p), removeHs=False)
            mol = next((m for m in suppl if m is not None), None)
        else:
            smi = p.read_text(encoding="utf-8").strip().splitlines()[0].split()[0]
            mol = Chem.MolFromSmiles(smi)
    else:
        mol = Chem.MolFromSmiles(input_path)
    if mol is None:
        raise ValueError("Failed to read molecule")
    return mol


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    args = ap.parse_args()

    mol = _read(args.input)

    has_metal = any(a.GetAtomicNum() in METAL_ATOMIC_NUMS for a in mol.GetAtoms())

    chiral = Chem.FindMolChiralCenters(mol, includeUnassigned=True)
    has_undefined_chiral = any(flag == "?" for _, flag in chiral)

    has_undefined_ez = False
    for bond in mol.GetBonds():
        if bond.GetBondType() == Chem.BondType.DOUBLE:
            if bond.GetStereo() in (Chem.BondStereo.STEREONONE, Chem.BondStereo.STEREOANY):
                a1 = bond.GetBeginAtom()
                a2 = bond.GetEndAtom()
                if a1.GetDegree() > 1 and a2.GetDegree() > 1:
                    has_undefined_ez = True
                    break

    donors = [a for a in mol.GetAtoms() if a.GetSymbol() in ("N", "O", "S", "P") and a.GetFormalCharge() <= 0]
    motifs = []
    for name, smarts in COORDINATION_MOTIFS:
        if smarts is None:
            continue
        if mol.HasSubstructMatch(smarts):
            motifs.append(name)

    flags = {
        "has_metal": has_metal,
        "has_undefined_chirality": has_undefined_chiral,
        "has_undefined_ez": has_undefined_ez,
        "has_coordination_risk": bool(has_metal or motifs or len(donors) >= 2),
        "coordination_motifs": sorted(set(motifs)),
    }
    print(json.dumps(flags))


if __name__ == "__main__":
    main()
