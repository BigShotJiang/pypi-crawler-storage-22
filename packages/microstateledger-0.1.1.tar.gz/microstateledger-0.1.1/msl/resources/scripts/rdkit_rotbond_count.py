from __future__ import annotations

import argparse
from rdkit import Chem
from rdkit.Chem import Lipinski


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True, help="SDF input")
    args = ap.parse_args()

    suppl = Chem.SDMolSupplier(args.input, removeHs=False)
    mol = next((m for m in suppl if m is not None), None)
    if mol is None:
        raise SystemExit("failed to read mol")
    count = int(Lipinski.NumRotatableBonds(mol))
    print(count)


if __name__ == "__main__":
    main()
