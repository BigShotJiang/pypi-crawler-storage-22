from __future__ import annotations

import argparse
from pathlib import Path

from rdkit import Chem
from rdkit.Chem.EnumerateStereoisomers import EnumerateStereoisomers, StereoEnumerationOptions


def _read(input_path: str) -> Chem.Mol:
    p = Path(input_path)
    if p.exists():
        if p.suffix.lower() in {".sdf", ".mol"}:
            suppl = Chem.SDMolSupplier(str(p), removeHs=False)
            mol = next((m for m in suppl if m is not None), None)
        else:
            smi = p.read_text(encoding="utf-8").strip().splitlines()[0].split()[0]
            mol = Chem.MolFromSmiles(smi)
    else:
        mol = Chem.MolFromSmiles(input_path)
    if mol is None:
        raise ValueError("Failed to read molecule")
    return mol


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    ap.add_argument("--max_isomers", type=int, default=128)
    args = ap.parse_args()

    mol = _read(args.input)
    opts = StereoEnumerationOptions(tryEmbedding=False, unique=True, onlyUnassigned=True)
    isomers = list(EnumerateStereoisomers(mol, options=opts))
    if len(isomers) == 0:
        print(1)
    else:
        print(min(len(isomers), args.max_isomers))


if __name__ == "__main__":
    main()
