from __future__ import annotations

import argparse
from rdkit import Chem


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    args = ap.parse_args()

    suppl = Chem.SDMolSupplier(args.input, removeHs=False)
    mol = next((m for m in suppl if m is not None), None)
    if mol is None:
        raise SystemExit("failed to read mol")

    for i, atom in enumerate(mol.GetAtoms(), start=1):
        if atom.GetAtomMapNum() == 0:
            atom.SetAtomMapNum(i)

    smi = Chem.MolToSmiles(mol, isomericSmiles=True, allHsExplicit=True)
    print(smi)


if __name__ == "__main__":
    main()
