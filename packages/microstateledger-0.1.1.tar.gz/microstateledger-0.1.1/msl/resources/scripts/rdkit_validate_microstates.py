from __future__ import annotations

import argparse
import json
from pathlib import Path

from rdkit import Chem


def _validate_sdf(path: str) -> tuple[bool, str]:
    suppl = Chem.SDMolSupplier(path, removeHs=False, sanitize=False)
    mol = next((m for m in suppl if m is not None), None)
    if mol is None:
        return False, "read_failed"
    try:
        Chem.SanitizeMol(mol)
    except Exception as exc:
        return False, f"sanitize_failed:{exc}"
    return True, "ok"


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--list", required=True, help="TSV with microstate_id\tpath")
    args = ap.parse_args()

    invalid = []
    valid_count = 0
    for line in Path(args.list).read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        parts = line.split("\t")
        if len(parts) < 2:
            continue
        mid, path = parts[0], parts[1]
        ok, reason = _validate_sdf(path)
        if ok:
            valid_count += 1
        else:
            invalid.append({"microstate_id": mid, "sdf_path": path, "reason": reason})

    print(json.dumps({"valid": valid_count, "invalid": invalid, "invalid_count": len(invalid)}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
