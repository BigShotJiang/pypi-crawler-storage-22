from __future__ import annotations

import argparse
import json
import zipfile
from pathlib import Path
from typing import List

import numpy as np
import pandas as pd
from rdkit import Chem
from rdkit.Chem import AllChem, rdMolDescriptors
import ydf

POLARIZABILITY = {
    1: 0.667,
    6: 1.76,
    7: 1.10,
    8: 0.802,
    9: 0.557,
    15: 3.63,
    16: 2.90,
    17: 2.18,
    35: 3.05,
    53: 5.35,
}

HALOGENS = {9, 17, 35, 53}


def ensure_3d(mol: Chem.Mol) -> Chem.Mol:
    mol = Chem.AddHs(mol, addCoords=True)
    if mol.GetNumConformers() == 0 or not mol.GetConformer().Is3D():
        params = AllChem.ETKDGv3()
        AllChem.EmbedMolecule(mol, params)
        try:
            AllChem.MMFFOptimizeMolecule(mol)
        except Exception:
            AllChem.UFFOptimizeMolecule(mol)
    return mol


def center_of_mass(mol: Chem.Mol) -> np.ndarray:
    conf = mol.GetConformer()
    masses = np.array([atom.GetMass() for atom in mol.GetAtoms()])
    coords = np.array([list(conf.GetAtomPosition(i)) for i in range(mol.GetNumAtoms())])
    total = masses.sum()
    return (coords.T @ masses / total).T


def build_features(mol: Chem.Mol, atom_idx: int) -> dict:
    conf = mol.GetConformer()
    com = center_of_mass(mol)
    pos = np.array(conf.GetAtomPosition(atom_idx))
    com_dist = float(np.linalg.norm(pos - com))

    total_o = sum(1 for a in mol.GetAtoms() if a.GetAtomicNum() == 8)
    total_n = sum(1 for a in mol.GetAtoms() if a.GetAtomicNum() == 7)
    total_halogen = sum(1 for a in mol.GetAtoms() if a.GetAtomicNum() in HALOGENS)
    total_other = sum(1 for a in mol.GetAtoms() if a.GetAtomicNum() not in {1, 6, 7, 8} and a.GetAtomicNum() not in HALOGENS)

    asa = rdMolDescriptors.CalcLabuteASA(mol)

    znum = mol.GetAtomWithIdx(atom_idx).GetAtomicNum()
    pol = POLARIZABILITY.get(znum, float(znum) / 10.0)

    return {
        "Atomic_pol": pol,
        "COM_Dist": com_dist,
        "COE_Dist": com_dist,
        "COM2COE_Dist": 0.0,
        "Interaction_Angle": 0.0,
        "MSA": float(asa),
        "Total_O": total_o,
        "Total_N": total_n,
        "Total_Halogen": total_halogen,
        "Total_Othergen": total_other,
    }


def load_model(root: Path, mode: str):
    model_dir = root / "tools" / "SEER" / "models"
    if mode == "pos":
        zip_path = model_dir / "seer_pos_model.zip"
        out_dir = model_dir / "seer_pos_model"
    else:
        zip_path = model_dir / "seer_neg_model.zip"
        out_dir = model_dir / "seer_neg_model"
    if not out_dir.exists():
        with zipfile.ZipFile(zip_path, "r") as zf:
            zf.extractall(out_dir)
    return ydf.load_model(str(out_dir))


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--sdf", required=True)
    ap.add_argument("--mode", choices=["pos", "neg"], default="pos")
    ap.add_argument("--out", default="")
    args = ap.parse_args()

    root = Path(__file__).resolve().parents[1]

    mol = Chem.SDMolSupplier(args.sdf, removeHs=False)[0]
    if mol is None:
        raise SystemExit("failed to read mol")
    mol = ensure_3d(mol)

    candidates: List[int] = [a.GetIdx() for a in mol.GetAtoms() if a.GetAtomicNum() in {7, 8}]
    if not candidates:
        candidates = [a.GetIdx() for a in mol.GetAtoms()]

    rows = []
    for idx in candidates:
        feat = build_features(mol, idx)
        rows.append(feat)

    df = pd.DataFrame(rows)
    model = load_model(root, args.mode)
    preds = model.predict(df)

    result = []
    for idx, pred in zip(candidates, preds):
        atom = mol.GetAtomWithIdx(idx)
        result.append({
            "atom_index": idx,
            "symbol": atom.GetSymbol(),
            "score": float(pred),
        })

    result = sorted(result, key=lambda x: x["score"])
    out_json = json.dumps({"mode": args.mode, "results": result}, ensure_ascii=False, indent=2)

    if args.out:
        Path(args.out).write_text(out_json, encoding="utf-8")
    else:
        print(out_json)


if __name__ == "__main__":
    main()
