#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import os
import random
import re
import shutil
import sqlite3
import subprocess
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple


@dataclass
class CmdResult:
    cmd: str
    returncode: int
    stdout: str
    stderr: str
    elapsed_sec: float


def shlex_quote(s: str) -> str:
    if re.match(r"^[A-Za-z0-9_./:=+\-]+$", s):
        return s
    return "'" + s.replace("'", "'\"'\"'") + "'"


def parse_best_vina_score(text: str) -> Optional[float]:
    for line in text.splitlines():
        m = re.match(r"\s*1\s+(-?\d+\.\d+)", line)
        if m:
            try:
                return float(m.group(1))
            except Exception:
                return None
    return None


class GateRunner:
    def __init__(
        self,
        repo_root: Path,
        outdir: Path,
        report_dir: Path,
        commands_log: Path,
        seed: int,
        n_repeats: int,
    ):
        self.repo_root = repo_root
        self.outdir = outdir
        self.report_dir = report_dir
        self.commands_log = commands_log
        self.seed = seed
        self.n_repeats = n_repeats

        self.py_msl = str(repo_root / "envs" / "msl-core" / "bin" / "python")
        self.py_rdkit = str(repo_root / "envs" / "rdkit" / "bin" / "python")
        self.py_openff = str(repo_root / "envs" / "openff" / "bin" / "python")
        self.vina_bin = str(repo_root / "envs" / "vina" / "bin" / "vina")

        self.gate_results: Dict[str, Dict[str, Any]] = {}
        self.manifest: List[Dict[str, Any]] = []

        random.seed(seed)
        self.conda_shim = self._ensure_conda_shim()

    def _write_cmdlog(self, text: str) -> None:
        self.commands_log.parent.mkdir(parents=True, exist_ok=True)
        with self.commands_log.open("a", encoding="utf-8") as f:
            f.write(text)

    def run(
        self,
        cmd: List[str],
        cwd: Optional[Path] = None,
        check: bool = True,
        env: Optional[Dict[str, str]] = None,
    ) -> CmdResult:
        cwd = cwd or self.repo_root
        cmd_text = " ".join(shlex_quote(x) for x in cmd)
        self._write_cmdlog(f"\n$ {cmd_text}\n")
        t0 = time.time()
        cp = subprocess.run(
            cmd,
            cwd=str(cwd),
            text=True,
            capture_output=True,
            env=env,
        )
        elapsed = time.time() - t0
        if cp.stdout:
            self._write_cmdlog(cp.stdout)
        if cp.stderr:
            self._write_cmdlog(cp.stderr)
        res = CmdResult(cmd_text, cp.returncode, cp.stdout, cp.stderr, elapsed)
        if check and cp.returncode != 0:
            raise RuntimeError(
                f"Command failed ({cp.returncode}): {cmd_text}\n"
                f"STDERR:\n{cp.stderr}"
            )
        return res

    def msl(self, config: Path, args: List[str], check: bool = True) -> CmdResult:
        cmd = [self.py_msl, "-m", "msl.cli"] + args + ["--config", str(config)]
        return self.run(cmd, check=check)

    def write_file(self, path: Path, content: str) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")

    def make_config(
        self,
        scenario: str,
        envs_base: Optional[Path] = None,
        policy_text: Optional[str] = None,
    ) -> Tuple[Path, Path, Path]:
        root = self.outdir / scenario
        root.mkdir(parents=True, exist_ok=True)

        policy_path = root / "policy.yaml"
        if policy_text is None:
            policy_text = (self.repo_root / "policies" / "default.yaml").read_text(
                encoding="utf-8"
            )
        self.write_file(policy_path, policy_text)

        envs_base = envs_base or (self.repo_root / "envs")

        cfg_path = root / "msl.toml"
        cfg_txt = (
            "[project]\n"
            "name = \"MicrostateLedgerUltimate\"\n"
            f"root = \"{root}\"\n"
            "objects_dir = \"objects\"\n"
            "runs_dir = \"runs\"\n"
            "reports_dir = \"reports\"\n"
            f"policy = \"{policy_path}\"\n"
            "ledger_db = \"ledger.sqlite\"\n\n"
            "[envs]\n"
            f"conda = \"{self.conda_shim}\"\n"
            f"base_dir = \"{envs_base}\"\n\n"
            "[logging]\n"
            "level = \"INFO\"\n"
            "log_dir = \"logs\"\n"
        )
        self.write_file(cfg_path, cfg_txt)
        return root, cfg_path, policy_path

    def sqlite_query(
        self,
        db_path: Path,
        sql: str,
        params: Tuple[Any, ...] = (),
    ) -> List[sqlite3.Row]:
        conn = sqlite3.connect(str(db_path), timeout=30)
        conn.row_factory = sqlite3.Row
        try:
            return conn.execute(sql, params).fetchall()
        finally:
            conn.close()

    def parse_id(self, text: str, prefix: str) -> str:
        m = re.findall(rf"\b{re.escape(prefix)}[A-Za-z0-9\-]+\b", text)
        if not m:
            raise RuntimeError(f"Cannot parse {prefix} ID from output: {text}")
        return m[-1]

    def sha256(self, path: Path) -> str:
        h = hashlib.sha256()
        with path.open("rb") as f:
            for chunk in iter(lambda: f.read(1024 * 1024), b""):
                h.update(chunk)
        return h.hexdigest()

    def add_manifest(
        self,
        path: Path,
        scenario: str,
        run_id: str = "",
        extra: Optional[Dict[str, Any]] = None,
    ) -> None:
        if not path.exists():
            return
        entry: Dict[str, Any] = {
            "path": str(path),
            "sha256": self.sha256(path),
            "scenario": scenario,
            "run_id": run_id,
        }
        if extra:
            entry.update(extra)
        self.manifest.append(entry)

    def _ensure_conda_shim(self) -> Path:
        shim = self.outdir / "_conda_run_shim.sh"
        if not shim.exists():
            text = (
                "#!/usr/bin/env bash\n"
                "set -euo pipefail\n"
                "if [ \"$#\" -lt 4 ] || [ \"$1\" != \"run\" ] || [ \"$2\" != \"-p\" ]; then\n"
                "  echo \"unsupported conda shim invocation: $*\" >&2\n"
                "  exit 64\n"
                "fi\n"
                "ENV_PATH=\"$3\"\n"
                "shift 3\n"
                "export PATH=\"$ENV_PATH/bin:$PATH\"\n"
                "exec \"$@\"\n"
            )
            shim.write_text(text, encoding="utf-8")
            shim.chmod(0o755)
        return shim

    def init_schema(self, cfg: Path) -> None:
        self.msl(cfg, ["init"])
        self.msl(cfg, ["migrate"])

    def run_gate_31(self) -> Dict[str, Any]:
        root, cfg, _ = self.make_config("gate_3_1_install_cli")
        self.init_schema(cfg)

        install = self.run([self.py_msl, "-m", "pip", "install", "-e", ".", "--no-build-isolation", "--no-deps"], cwd=self.repo_root)

        helps: Dict[str, bool] = {}
        for sub in [
            "--help",
            "init",
            "ingest",
            "perceive",
            "enumerate",
            "conformers",
            "dock-prep",
            "dock-ingest",
            "charge",
            "md-param",
            "md-feedback",
            "batch",
        ]:
            if sub == "--help":
                res = self.run([self.py_msl, "-m", "msl.cli", "--help"], cwd=self.repo_root)
            else:
                res = self.msl(cfg, [sub, "--help"])
            helps[sub] = "Usage:" in res.stdout

        fake_env = root / "fake_envs"
        fake_env.mkdir(exist_ok=True)
        for name in ["rdkit", "dimorphite", "msl-core"]:
            src = self.repo_root / "envs" / name
            dst = fake_env / name
            if dst.exists() or dst.is_symlink():
                dst.unlink()
            os.symlink(src, dst)

        min_root, min_cfg, _ = self.make_config(
            "gate_3_1_install_cli/minimal_env",
            envs_base=fake_env,
        )
        self.init_schema(min_cfg)

        cid = self.parse_id(self.msl(min_cfg, ["ingest", "C[N+](C)(C)C"]).stdout, "C-")
        self.msl(min_cfg, ["perceive", cid])
        self.msl(min_cfg, ["enumerate", cid])

        mids = self.sqlite_query(min_root / "ledger.sqlite", "SELECT microstate_id FROM microstates ORDER BY microstate_id")
        if not mids:
            raise RuntimeError("No microstate generated in minimal env")
        mid = mids[0]["microstate_id"]

        self.msl(min_cfg, ["conformers", mid, "--method", "rdkit", "--n", "8", "--seed", str(self.seed)])
        crows = self.sqlite_query(min_root / "ledger.sqlite", "SELECT conformer_id FROM conformers WHERE microstate_id = ? ORDER BY conformer_id", (mid,))
        if not crows:
            raise RuntimeError("No conformer generated in minimal env")
        conf = crows[0]["conformer_id"]

        dock_prep = self.msl(min_cfg, ["dock-prep", mid, conf], check=False)
        charge = self.msl(min_cfg, ["charge", mid, "--method", "pype_resp"], check=False)
        md_param = self.msl(min_cfg, ["md-param", mid], check=False)

        missing_rows = self.sqlite_query(
            min_root / "ledger.sqlite",
            "SELECT decision_type, rationale, target_id FROM decisions WHERE rationale = 'missing_env' ORDER BY created_at",
        )

        summary = {
            "status": "PASS",
            "install_rc": install.returncode,
            "help_ok": all(helps.values()),
            "helps": helps,
            "minimal_compound_id": cid,
            "minimal_microstate_id": mid,
            "missing_env_decisions": [dict(r) for r in missing_rows],
            "dock_prep_out": dock_prep.stdout.strip() or dock_prep.stderr.strip(),
            "charge_out": charge.stdout.strip() or charge.stderr.strip(),
            "md_param_out": md_param.stdout.strip() or md_param.stderr.strip(),
            "evidence": {
                "config": str(min_cfg),
                "ledger": str(min_root / "ledger.sqlite"),
            },
        }
        self.add_manifest(min_root / "ledger.sqlite", "gate_3_1")
        return summary

    def _write_worker_script(self, path: Path) -> None:
        script = (
            "import json\n"
            "import sys\n"
            "from pathlib import Path\n"
            "from msl.cli import ingest, _capture_output\n"
            "cfg = Path(sys.argv[1])\n"
            "inp = Path(sys.argv[2])\n"
            "out = Path(sys.argv[3])\n"
            "worker = sys.argv[4]\n"
            "lines = [x.strip() for x in inp.read_text(encoding='utf-8').splitlines() if x.strip()]\n"
            "errs = []\n"
            "ok = 0\n"
            "for i, smi in enumerate(lines):\n"
            "    try:\n"
            "        _capture_output(ingest, input=smi.split()[0], name=f'{worker}_{i}', config=cfg)\n"
            "        ok += 1\n"
            "    except Exception as e:\n"
            "        errs.append({'i': i, 'smiles': smi, 'err': str(e)})\n"
            "out.write_text(json.dumps({'worker': worker, 'ok': ok, 'errors': errs}, ensure_ascii=False, indent=2), encoding='utf-8')\n"
            "print(json.dumps({'worker': worker, 'ok': ok, 'errors': len(errs)}, ensure_ascii=False))\n"
        )
        self.write_file(path, script)

    def run_gate_32(self) -> Dict[str, Any]:
        root, cfg, _ = self.make_config("gate_3_2_schema_tx")
        self.init_schema(cfg)

        smiles = [
            "CCO", "CCN", "CC(=O)O", "c1ccccc1", "CCO", "CCN", "C[N+](C)(C)C", "CC(Cl)Br", "OC1=CC=CC=N1", "NCCN"
        ]
        inp = root / "concurrent_input.smi"
        self.write_file(inp, "\n".join(smiles * 12) + "\n")

        worker = root / "worker_ingest.py"
        self._write_worker_script(worker)
        out_a = root / "worker_a.json"
        out_b = root / "worker_b.json"

        cmd_a = [self.py_msl, str(worker), str(cfg), str(inp), str(out_a), "A"]
        cmd_b = [self.py_msl, str(worker), str(cfg), str(inp), str(out_b), "B"]
        self._write_cmdlog(f"\n$ {' '.join(shlex_quote(c) for c in cmd_a)} &\n")
        self._write_cmdlog(f"$ {' '.join(shlex_quote(c) for c in cmd_b)} &\n")

        t0 = time.time()
        p1 = subprocess.Popen(cmd_a, cwd=str(self.repo_root), stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        p2 = subprocess.Popen(cmd_b, cwd=str(self.repo_root), stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        o1, e1 = p1.communicate()
        o2, e2 = p2.communicate()
        elapsed = time.time() - t0
        self._write_cmdlog((o1 or "") + (e1 or "") + (o2 or "") + (e2 or ""))

        wa = json.loads(out_a.read_text(encoding="utf-8"))
        wb = json.loads(out_b.read_text(encoding="utf-8"))
        all_errs = wa.get("errors", []) + wb.get("errors", [])
        locked_errors = [e for e in all_errs if "locked" in e.get("err", "").lower()]
        unique_errors = [e for e in all_errs if "unique" in e.get("err", "").lower()]

        batch_input = root / "batch_input.smi"
        self.write_file(batch_input, "\n".join(["CCO", "CCN", "CC(=O)O", "c1ccccc1", "CC(Cl)Br"] * 24) + "\n")
        state = root / "runs" / "batch_state.json"
        log = root / "runs" / "batch_crash.log"
        log.parent.mkdir(parents=True, exist_ok=True)

        batch_cmd = [
            self.py_msl,
            "-m",
            "msl.cli",
            "batch",
            str(batch_input),
            "--state",
            str(state),
            "--config",
            str(cfg),
        ]
        self._write_cmdlog(f"\n$ {' '.join(shlex_quote(c) for c in batch_cmd)} > {shlex_quote(str(log))} 2>&1 &\n")
        with log.open("w", encoding="utf-8") as lf:
            p = subprocess.Popen(batch_cmd, cwd=str(self.repo_root), stdout=lf, stderr=lf, text=True)
        time.sleep(2.0)
        p.kill()
        p.wait()
        self._write_cmdlog(f"killed_pid={p.pid}\n")

        resume = self.run(batch_cmd, check=True)
        state_json = json.loads(state.read_text(encoding="utf-8")) if state.exists() else {}

        db = root / "ledger.sqlite"
        orphan_queries = {
            "orph_conformers": "SELECT COUNT(*) AS n FROM conformers c LEFT JOIN microstates m ON c.microstate_id=m.microstate_id WHERE m.microstate_id IS NULL",
            "orph_poses": "SELECT COUNT(*) AS n FROM poses p LEFT JOIN conformers c ON p.conformer_id=c.conformer_id WHERE c.conformer_id IS NULL",
            "orph_systems": "SELECT COUNT(*) AS n FROM systems s LEFT JOIN microstates m ON s.microstate_id=m.microstate_id WHERE m.microstate_id IS NULL",
        }
        orphan_counts = {k: int(self.sqlite_query(db, q)[0]["n"]) for k, q in orphan_queries.items()}

        summary = {
            "status": "PASS" if (len(locked_errors) == 0 and len(unique_errors) == 0 and sum(orphan_counts.values()) == 0) else "FAIL",
            "concurrency_elapsed_sec": round(elapsed, 3),
            "worker_a": {"ok": wa.get("ok"), "n_errors": len(wa.get("errors", []))},
            "worker_b": {"ok": wb.get("ok"), "n_errors": len(wb.get("errors", []))},
            "locked_errors": len(locked_errors),
            "unique_errors": len(unique_errors),
            "orphan_counts": orphan_counts,
            "batch_state": state_json,
            "batch_resume_stdout": resume.stdout.strip(),
            "evidence": {
                "ledger": str(db),
                "state": str(state),
                "batch_log": str(log),
                "worker_a": str(out_a),
                "worker_b": str(out_b),
            },
        }
        for pth in [db, state, log, out_a, out_b]:
            self.add_manifest(pth, "gate_3_2")
        return summary

    def _run_chain_once(self, cfg: Path, smiles: str, name: str, do_docking: bool = False) -> Dict[str, Any]:
        cid = self.parse_id(self.msl(cfg, ["ingest", smiles, "--name", name]).stdout, "C-")
        self.msl(cfg, ["perceive", cid])
        self.msl(cfg, ["enumerate", cid])

        db = cfg.parent / "ledger.sqlite"
        mids = self.sqlite_query(db, "SELECT microstate_id,fixedh_inchi,formal_charge,stereo_tag FROM microstates WHERE compound_id=? ORDER BY microstate_id", (cid,))
        if not mids:
            raise RuntimeError(f"No microstate for {cid}")
        mid = mids[0]["microstate_id"]

        self.msl(cfg, ["conformers", mid, "--method", "rdkit", "--n", "20", "--seed", str(self.seed), "--topk", "5"])
        confs = self.sqlite_query(db, "SELECT conformer_id,sdf_path,energy FROM conformers WHERE microstate_id=? ORDER BY conformer_id", (mid,))
        if not confs:
            raise RuntimeError(f"No conformer for {mid}")
        conf = confs[0]["conformer_id"]

        out: Dict[str, Any] = {
            "compound_id": cid,
            "microstates": [dict(r) for r in mids],
            "conformer_ids": [r["conformer_id"] for r in confs],
            "pose_ids": [],
        }

        if do_docking:
            dock_pdbqt = Path(self.msl(cfg, ["dock-prep", mid, conf]).stdout.strip().splitlines()[-1])
            vina_out = cfg.parent / "vina_out.pdbqt"
            vina_log = cfg.parent / "vina.log"
            receptor = self.repo_root / "test_extra_runs" / "vina_e2e" / "receptor.pdbqt"
            box_lines = (self.repo_root / "test_extra_runs" / "vina_e2e" / "box.txt").read_text(encoding="utf-8").strip().splitlines()
            center = [x.strip() for x in box_lines[0].split()]
            size = [x.strip() for x in box_lines[1].split()]
            vina_cmd = [
                self.vina_bin,
                "--receptor", str(receptor),
                "--ligand", str(dock_pdbqt),
                "--center_x", center[0], "--center_y", center[1], "--center_z", center[2],
                "--size_x", size[0], "--size_y", size[1], "--size_z", size[2],
                "--exhaustiveness", "8",
                "--seed", str(self.seed),
                "--out", str(vina_out),
            ]
            vres = self.run(vina_cmd)
            self.write_file(vina_log, (vres.stdout or "") + "\n" + (vres.stderr or ""))
            score = parse_best_vina_score((vres.stdout or "") + "\n" + (vres.stderr or ""))
            self.msl(cfg, [
                "dock-ingest",
                conf,
                str(vina_out),
                "--score", str(score if score is not None else -1.0),
                "--receptor-path", str(receptor),
                "--tool", "vina",
                "--params-json", json.dumps({"seed": self.seed, "exhaustiveness": 8, "grid": {"center": center, "size": size}}),
            ])
            poses = self.sqlite_query(db, "SELECT pose_id,pdbqt_path FROM poses WHERE conformer_id=? ORDER BY pose_id", (conf,))
            out["pose_ids"] = [r["pose_id"] for r in poses]
            out["vina_log"] = str(vina_log)
            out["vina_out"] = str(vina_out)

        return out

    def run_gate_33(self) -> Dict[str, Any]:
        molecules = {
            "tautomer": "Oc1ccccn1",
            "undefined_stereo": "CC(Cl)C(Br)F",
            "charged": "C[N+](C)(C)C",
        }
        repeats: List[Dict[str, Any]] = []

        for i in range(1, self.n_repeats + 1):
            root, cfg, _ = self.make_config(f"gate_3_3_id_stability/repeat_{i}")
            self.init_schema(cfg)
            rep: Dict[str, Any] = {"repeat": i, "molecules": {}}
            for name, smi in molecules.items():
                rep["molecules"][name] = self._run_chain_once(cfg, smi, f"{name}_{i}", do_docking=(name == "tautomer"))
            repeats.append(rep)
            self.add_manifest(root / "ledger.sqlite", "gate_3_3", extra={"repeat": i})

        baseline = repeats[0]
        diffs: Dict[str, Any] = {}
        for rep in repeats[1:]:
            d: Dict[str, Any] = {}
            for name in molecules.keys():
                b = baseline["molecules"][name]
                r = rep["molecules"][name]
                b_ms = sorted((m["microstate_id"], m["fixedh_inchi"], int(m["formal_charge"]), m["stereo_tag"]) for m in b["microstates"])
                r_ms = sorted((m["microstate_id"], m["fixedh_inchi"], int(m["formal_charge"]), m["stereo_tag"]) for m in r["microstates"])
                d[name] = {
                    "compound_id_equal": b["compound_id"] == r["compound_id"],
                    "microstate_set_equal": b_ms == r_ms,
                    "conformer_ids_equal": b["conformer_ids"] == r["conformer_ids"],
                    "pose_ids_equal": b["pose_ids"] == r["pose_ids"],
                }
            diffs[f"repeat_{rep['repeat']}"] = d

        all_ok = all(
            all(v2["compound_id_equal"] and v2["microstate_set_equal"] and v2["conformer_ids_equal"] and v2["pose_ids_equal"] for v2 in v.values())
            for v in diffs.values()
        ) if diffs else True

        return {
            "status": "PASS" if all_ok else "FAIL",
            "repeats": repeats,
            "diffs": diffs,
        }

    def run_gate_34(self) -> Dict[str, Any]:
        policy_text = (self.repo_root / "policies" / "default.yaml").read_text(encoding="utf-8")
        policy_text = policy_text.replace("method: [rdkit_etkdg, peas]", "method: [rdkit_etkdg]")
        root, cfg, _ = self.make_config("gate_3_4_mapping", policy_text=policy_text)
        self.init_schema(cfg)

        smi = "CCN(CC)CCOC(=O)c1ccccc1N1CCN(C(=O)c2ccccc2)CC1"
        chain = self._run_chain_once(cfg, smi, "mapping_sample", do_docking=False)
        mid = chain["microstates"][0]["microstate_id"]
        conf = chain["conformer_ids"][0]

        pdbqt = Path(self.msl(cfg, ["dock-prep", mid, conf]).stdout.strip().splitlines()[-1])
        sidecar = pdbqt.parent / "ligand.map.json"

        self.msl(cfg, ["charge", mid, "--method", "gasteiger"])
        md_out = self.msl(cfg, ["md-param", mid]).stdout
        md_data = json.loads(md_out)
        md_map = Path(md_data["atommap"])

        side = json.loads(sidecar.read_text(encoding="utf-8"))
        mdm = json.loads(md_map.read_text(encoding="utf-8"))
        md_lookup = {int(x["canonical_atom_id"]): x for x in mdm}

        present = [x for x in side if x.get("present_in_pdbqt") and int(x.get("canonical_atom_id", 0)) in md_lookup]
        hyd = [x for x in present if str(x.get("symbol", "")).upper() == "H"]
        heavy = [x for x in present if str(x.get("symbol", "")).upper() != "H"]

        sample: List[Dict[str, Any]] = []
        if hyd:
            sample.append(random.choice(hyd))
        random.shuffle(heavy)
        sample.extend(heavy[: max(0, 10 - len(sample))])
        if len(sample) < 10:
            rest = [x for x in present if x not in sample]
            sample.extend(rest[: 10 - len(sample)])

        rows = []
        ok_count = 0
        for x in sample[:10]:
            cid = int(x["canonical_atom_id"])
            md_entry = md_lookup.get(cid)
            row = {
                "canonical_atom_id": cid,
                "pdbqt_atom_index": x.get("pdbqt_atom_index"),
                "md_atom_index": md_entry.get("openmm_atom_index") if md_entry else None,
                "symbol": x.get("symbol"),
                "present_in_pdbqt": bool(x.get("present_in_pdbqt")),
                "present_in_md": md_entry is not None,
            }
            if row["present_in_pdbqt"] and row["present_in_md"]:
                ok_count += 1
            rows.append(row)

        summary = {
            "status": "PASS" if ok_count == len(rows) and len(rows) >= 10 else "FAIL",
            "sample_size": len(rows),
            "mapped_ok": ok_count,
            "rows": rows,
            "evidence": {
                "ligand_map": str(sidecar),
                "md_map": str(md_map),
                "pdbqt": str(pdbqt),
            },
            "reversible_rule": "canonical_atom_id must resolve in both ligand.map.json and atommap.json",
        }

        for p in [sidecar, md_map, pdbqt]:
            self.add_manifest(p, "gate_3_4")
        return summary

    def run_gate_35(self) -> Dict[str, Any]:
        root, cfg, _ = self.make_config("gate_3_5_docking_md_smoke")
        self.init_schema(cfg)

        chain = self._run_chain_once(cfg, "CCO", "smoke_ethanol", do_docking=True)
        mid = chain["microstates"][0]["microstate_id"]
        db = root / "ledger.sqlite"

        self.msl(cfg, ["charge", mid, "--method", "gasteiger"])
        md_out = self.msl(cfg, ["md-param", mid]).stdout
        md_data = json.loads(md_out)
        system_xml = Path(md_data["system_xml"])
        system_pdb = Path(md_data["system_pdb"])

        md_log = root / "md_short.log"
        final_pdb = root / "md_short_final.pdb"
        md_script = root / "run_md_short.py"
        self.write_file(
            md_script,
            "from openmm import XmlSerializer, LangevinMiddleIntegrator\n"
            "from openmm.app import PDBFile, Simulation\n"
            "from openmm import unit\n"
            "import math\n"
            "import pathlib\n"
            f"xml = pathlib.Path(r\"{system_xml}\")\n"
            f"pdb = pathlib.Path(r\"{system_pdb}\")\n"
            f"log = pathlib.Path(r\"{md_log}\")\n"
            f"out = pathlib.Path(r\"{final_pdb}\")\n"
            "system = XmlSerializer.deserialize(xml.read_text(encoding='utf-8'))\n"
            "top = PDBFile(str(pdb))\n"
            "integrator = LangevinMiddleIntegrator(300*unit.kelvin, 1.0/unit.picosecond, 0.002*unit.picoseconds)\n"
            "sim = Simulation(top.topology, system, integrator)\n"
            "sim.context.setPositions(top.positions)\n"
            "e0 = sim.context.getState(getEnergy=True).getPotentialEnergy().value_in_unit(unit.kilojoule_per_mole)\n"
            "sim.minimizeEnergy(maxIterations=100)\n"
            "sim.step(1000)\n"
            "e1 = sim.context.getState(getEnergy=True).getPotentialEnergy().value_in_unit(unit.kilojoule_per_mole)\n"
            "if math.isnan(e0) or math.isnan(e1):\n"
            "    raise SystemExit('Energy NaN detected')\n"
            "state = sim.context.getState(getPositions=True)\n"
            "with out.open('w', encoding='utf-8') as f:\n"
            "    PDBFile.writeFile(sim.topology, state.getPositions(), f)\n"
            "log.write_text(f'E0 {e0} kJ/mol\\nE1 {e1} kJ/mol\\n', encoding='utf-8')\n"
            "print(f'E0={e0};E1={e1}')\n",
        )
        md_res = self.run([self.py_openff, str(md_script)])

        sys_row = self.sqlite_query(db, "SELECT system_id,microstate_id,artifact_path FROM systems ORDER BY created_at DESC LIMIT 1")
        art_rows = self.sqlite_query(db, "SELECT kind,path,run_id FROM artifacts WHERE path IN (?,?)", (str(system_xml), str(final_pdb)))
        run_rows = self.sqlite_query(db, "SELECT run_id,stage,params_json FROM runs ORDER BY started_at DESC LIMIT 12")

        summary = {
            "status": "PASS",
            "vina_log": chain.get("vina_log"),
            "vina_out": chain.get("vina_out"),
            "pose_ids": chain.get("pose_ids"),
            "md_stdout": md_res.stdout.strip(),
            "system_xml": str(system_xml),
            "system_pdb": str(system_pdb),
            "md_log": str(md_log),
            "md_final_pdb": str(final_pdb),
            "traceability": {
                "systems": [dict(r) for r in sys_row],
                "artifacts": [dict(r) for r in art_rows],
                "recent_runs": [dict(r) for r in run_rows],
            },
        }

        for p in [system_xml, system_pdb, md_log, final_pdb]:
            self.add_manifest(p, "gate_3_5")
        if chain.get("vina_out"):
            self.add_manifest(Path(chain["vina_out"]), "gate_3_5")
        if chain.get("vina_log"):
            self.add_manifest(Path(chain["vina_log"]), "gate_3_5")
        return summary

    def run_gate_36(self) -> Dict[str, Any]:
        root, cfg, _ = self.make_config("gate_3_6_anomaly_feedback")
        self.init_schema(cfg)

        # Force gate to use repository md_feedback script instead of packaged fallback.
        script_override = root / "scripts"
        script_override.mkdir(parents=True, exist_ok=True)
        shutil.copy2(self.repo_root / "scripts" / "md_feedback.py", script_override / "md_feedback.py")

        # chirality flip probe
        ch = self._run_chain_once(cfg, "C[C@H](F)Cl", "chirality_case", do_docking=False)
        ch_mid = ch["microstates"][0]["microstate_id"]
        ch_ref = Path(self.sqlite_query(root / "ledger.sqlite", "SELECT sdf_path FROM microstates WHERE microstate_id=?", (ch_mid,))[0]["sdf_path"])
        ch_probe = root / "probe_chiral_flip.sdf"
        self.write_file(
            root / "mk_chiral_probe.py",
            "from rdkit import Chem\n"
            f"mol = Chem.SDMolSupplier(r\"{ch_ref}\", removeHs=False)[0]\n"
            "Chem.AssignStereochemistry(mol, force=True, cleanIt=True)\n"
            "flipped = False\n"
            "for a in mol.GetAtoms():\n"
            "    tag = a.GetChiralTag()\n"
            "    if tag == Chem.rdchem.ChiralType.CHI_TETRAHEDRAL_CW:\n"
            "        a.SetChiralTag(Chem.rdchem.ChiralType.CHI_TETRAHEDRAL_CCW)\n"
            "        flipped = True\n"
            "        break\n"
            "    if tag == Chem.rdchem.ChiralType.CHI_TETRAHEDRAL_CCW:\n"
            "        a.SetChiralTag(Chem.rdchem.ChiralType.CHI_TETRAHEDRAL_CW)\n"
            "        flipped = True\n"
            "        break\n"
            "if not flipped:\n"
            "    raise SystemExit('no chiral center to flip')\n"
            f"w = Chem.SDWriter(r\"{ch_probe}\")\n"
            "w.write(mol); w.close()\n",
        )
        self.run([self.py_rdkit, str(root / "mk_chiral_probe.py")])
        self.msl(cfg, ["md-feedback", ch_mid, str(ch_probe)])

        # E/Z drift probe
        ez = self._run_chain_once(cfg, "C/C=C\\C", "ez_case", do_docking=False)
        ez_mid = ez["microstates"][0]["microstate_id"]
        ez_ref = Path(self.sqlite_query(root / "ledger.sqlite", "SELECT sdf_path FROM microstates WHERE microstate_id=?", (ez_mid,))[0]["sdf_path"])
        ez_probe = root / "probe_ez_drift.sdf"
        self.write_file(
            root / "mk_ez_probe.py",
            "from rdkit import Chem\n"
            f"mol = Chem.SDMolSupplier(r\"{ez_ref}\", removeHs=False)[0]\n"
            "Chem.AssignStereochemistry(mol, force=True, cleanIt=True)\n"
            "flipped = False\n"
            "for b in mol.GetBonds():\n"
            "    if b.GetBondType() != Chem.rdchem.BondType.DOUBLE:\n"
            "        continue\n"
            "    a = b.GetBeginAtomIdx()\n"
            "    c = b.GetEndAtomIdx()\n"
            "    n1 = [x.GetIdx() for x in mol.GetAtomWithIdx(a).GetNeighbors() if x.GetIdx() != c]\n"
            "    n2 = [x.GetIdx() for x in mol.GetAtomWithIdx(c).GetNeighbors() if x.GetIdx() != a]\n"
            "    if not n1 or not n2:\n"
            "        continue\n"
            "    b.SetStereoAtoms(n1[0], n2[0])\n"
            "    st = b.GetStereo()\n"
            "    if st == Chem.rdchem.BondStereo.STEREOE:\n"
            "        b.SetStereo(Chem.rdchem.BondStereo.STEREOZ)\n"
            "    else:\n"
            "        b.SetStereo(Chem.rdchem.BondStereo.STEREOE)\n"
            "    flipped = True\n"
            "    break\n"
            "if not flipped:\n"
            "    raise SystemExit('no E/Z double bond to flip')\n"
            "Chem.AssignStereochemistry(mol, force=True, cleanIt=False)\n"
            f"w = Chem.SDWriter(r\"{ez_probe}\")\n"
            "w.write(mol); w.close()\n",
        )
        self.run([self.py_rdkit, str(root / "mk_ez_probe.py")])
        self.msl(cfg, ["md-feedback", ez_mid, str(ez_probe)])

        # protonation/formula change probe
        pr = self._run_chain_once(cfg, "NCCN", "prot_case", do_docking=False)
        base_mid = pr["microstates"][0]["microstate_id"]
        probe = self.repo_root / "qa_runs" / "probe_acetate.sdf"
        self.msl(cfg, ["md-feedback", base_mid, str(probe)])

        db = root / "ledger.sqlite"
        anomalies = [dict(r) for r in self.sqlite_query(db, "SELECT run_id,target_id,anomaly_type,details_json FROM anomalies ORDER BY created_at")]

        rec_actions: List[str] = []
        for a in anomalies:
            try:
                details = json.loads(a.get("details_json") or "{}")
            except Exception:
                details = {}
            for rec in details.get("recommendations", []):
                action = rec.get("action") or rec.get("type") or ""
                if action.startswith("lock_"):
                    action = "lock"
                if action:
                    rec_actions.append(action)

        required_actions = {"lock", "re-parameterize", "re-enumerate", "mark_unstable"}
        action_hit = sorted(set(x for x in rec_actions if x in required_actions))

        summary = {
            "status": "PASS" if len(anomalies) >= 3 and len(action_hit) >= 1 else "FAIL",
            "anomaly_count": len(anomalies),
            "anomalies": anomalies,
            "recommendation_actions": rec_actions,
            "action_hit": action_hit,
            "evidence": {
                "ledger": str(db),
                "chirality_probe": str(ch_probe),
                "ez_probe": str(ez_probe),
            },
        }

        for p in [db, ch_probe, ez_probe]:
            self.add_manifest(p, "gate_3_6")
        return summary

    def run_gate_37(self) -> Dict[str, Any]:
        root, cfg, _ = self.make_config("gate_3_7_perf1000")
        self.init_schema(cfg)

        src = self.repo_root / "test_extra_runs" / "perf_1000" / "batch_1000.smi"
        inp = root / "batch_1000.smi"
        shutil.copy2(src, inp)

        perf_py = root / "perf_ingest_perceive.py"
        self.write_file(
            perf_py,
            "import json\n"
            "import resource\n"
            "import time\n"
            "from pathlib import Path\n"
            "from msl.cli import ingest, perceive, _capture_output\n"
            f"cfg = Path(r\"{cfg}\")\n"
            f"inp = Path(r\"{inp}\")\n"
            "lines=[x.strip() for x in inp.read_text(encoding='utf-8').splitlines() if x.strip()]\n"
            "t0=time.time(); errs=[]; cids=[]\n"
            "for i,line in enumerate(lines[:1000]):\n"
            "    smi=line.split()[0]\n"
            "    try:\n"
            "        out=_capture_output(ingest, input=smi, name=f'perf_{i}', config=cfg)\n"
            "        cid=[x.strip() for x in out.splitlines() if x.strip()][-1]\n"
            "        cids.append(cid)\n"
            "        perceive(cid, config=cfg)\n"
            "    except Exception as e:\n"
            "        errs.append({'i':i,'smiles':smi,'err':str(e)})\n"
            "elapsed=time.time()-t0\n"
            "rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss\n"
            "print(json.dumps({'elapsed_sec':round(elapsed,3),'max_rss_kb':int(rss),'errors':len(errs),'cids':cids,'errs':errs},ensure_ascii=False))\n",
        )

        perf_res = self.run([self.py_msl, str(perf_py)])
        perf_data = json.loads(perf_res.stdout.strip().splitlines()[-1])

        db = root / "ledger.sqlite"
        risk_rows = self.sqlite_query(
            db,
            "SELECT c.compound_id, a.path FROM compounds c JOIN artifacts a ON a.kind='risk_report' AND a.path LIKE '%' || c.compound_id || '/risk_report.json' ORDER BY c.created_at DESC LIMIT 200",
        )

        scored: List[Tuple[float, str]] = []
        for r in risk_rows:
            rp = Path(r["path"])
            if not rp.exists():
                continue
            try:
                data = json.loads(rp.read_text(encoding="utf-8"))
                scored.append((float(data.get("n_total_microstates_est", 0.0)), r["compound_id"]))
            except Exception:
                continue
        scored.sort(reverse=True)
        top10 = [cid for _, cid in scored[:10]]

        for cid in top10:
            self.msl(cfg, ["enumerate", cid])

        decision_rows = [dict(r) for r in self.sqlite_query(
            db,
            "SELECT target_id,decision_type,rationale,params_json FROM decisions WHERE decision_type='select_microstates' ORDER BY created_at DESC LIMIT 20",
        )]

        summary = {
            "status": "PASS" if perf_data.get("errors", 1) == 0 else "FAIL",
            "elapsed_sec": perf_data.get("elapsed_sec"),
            "max_rss_kb": perf_data.get("max_rss_kb"),
            "errors": perf_data.get("errors"),
            "top10_compounds": top10,
            "select_microstates_decisions": decision_rows,
            "evidence": {
                "ledger": str(db),
                "input": str(inp),
            },
        }
        self.add_manifest(db, "gate_3_7")
        return summary

    def collect_env(self) -> Dict[str, Any]:
        uname = self.run(["uname", "-a"]).stdout.strip()
        lscpu = self.run(["bash", "-lc", "lscpu | sed -n '1,80p'"]).stdout
        free = self.run(["free", "-h"]).stdout
        py = self.run([self.py_msl, "-V"]).stdout.strip()
        rd = self.run([self.py_rdkit, "-c", "import rdkit;print(rdkit.__version__)"], check=True).stdout.strip()
        omm = self.run([self.py_openff, "-c", "import openmm;print(openmm.version.version)"], check=True).stdout.strip()
        vina = self.run([self.vina_bin, "--version"], check=True).stdout.splitlines()[0].strip()
        return {
            "uname": uname,
            "lscpu": lscpu,
            "free_h": free,
            "python_msl_core": py,
            "rdkit": rd,
            "openmm": omm,
            "vina": vina,
        }

    def write_gate_json(self, gate_name: str, summary: Dict[str, Any]) -> None:
        p = self.report_dir / f"{gate_name}.json"
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    def write_manifest(self) -> None:
        uniq: Dict[str, Dict[str, Any]] = {}
        for e in self.manifest:
            uniq[e["path"]] = e
        out = {
            "generated_at": time.strftime("%Y-%m-%d %H:%M:%S %Z"),
            "entries": sorted(uniq.values(), key=lambda x: x["path"]),
        }
        (self.report_dir / "artifact_manifest.json").write_text(
            json.dumps(out, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )

    def build_report(self, env_info: Dict[str, Any]) -> None:
        verdict = "PASS" if all(v.get("status") == "PASS" for v in self.gate_results.values()) else "FAIL"
        lines: List[str] = []
        lines.append("# ULTIMATE REPORT")
        lines.append("")
        lines.append(f"- Final Verdict: **{verdict}**")
        lines.append(f"- Timestamp: {time.strftime('%Y-%m-%d %H:%M:%S %Z')}")
        lines.append(f"- Repo: `{self.repo_root}`")
        lines.append(f"- Outdir: `{self.outdir}`")
        lines.append("")
        lines.append("## Executive Summary")
        lines.append(f"All 7 release gates were executed on Linux. Final result: **{verdict}**.")
        lines.append("")
        lines.append("## Environment")
        lines.append(f"- uname: `{env_info['uname']}`")
        lines.append(f"- python(msl-core): `{env_info['python_msl_core']}`")
        lines.append(f"- rdkit: `{env_info['rdkit']}`")
        lines.append(f"- openmm: `{env_info['openmm']}`")
        lines.append(f"- vina: `{env_info['vina']}`")
        lines.append("")
        lines.append("### CPU")
        lines.append("```text")
        lines.append(env_info["lscpu"].rstrip())
        lines.append("```")
        lines.append("### Memory")
        lines.append("```text")
        lines.append(env_info["free_h"].rstrip())
        lines.append("```")
        lines.append("")
        lines.append("## Run Layout")
        lines.append(f"- Report directory: `{self.report_dir}`")
        lines.append(f"- Runtime output directory: `{self.outdir}`")
        lines.append(f"- Commands log: `{self.commands_log}`")
        lines.append("")
        lines.append("## Gate Results")
        for name, info in self.gate_results.items():
            lines.append(f"- {name}: **{info.get('status', 'UNKNOWN')}** (evidence: `{self.report_dir / (name + '.json')}`)")
        lines.append("")
        lines.append("## Determinism Proof")
        lines.append(f"- See `{self.report_dir / 'gate_3_3_id_stability.json'}` for repeat comparisons.")
        lines.append("")
        lines.append("## Mapping Proof")
        lines.append(f"- See `{self.report_dir / 'gate_3_4_mapping.json'}` for canonical_id mapping samples.")
        lines.append("")
        lines.append("## Rollback/Crash/Concurrency Proof")
        lines.append(f"- See `{self.report_dir / 'gate_3_2_schema_tx.json'}` for concurrent ingest + crash recovery + orphan SQL checks.")
        lines.append("")
        lines.append("## Known Limitations")
        lines.append("- Linux only (no multi-OS matrix).")
        lines.append("- No external data download was used.")
        lines.append("- Vina is 1.1.2 on this host; absolute score values are engine/version dependent.")
        lines.append("")
        lines.append("## Re-run Instructions")
        lines.append("1. `python scripts/ultimate_release_gate.py --outdir ultimate_test_runs/ultimate_release_gate_$(date +%F) --report-dir reports/ultimate_release_gate_$(date +%F) --commands-log reports/ultimate_release_gate_$(date +%F)/commands.log --seed 20260206 --n-repeats 3`")
        lines.append("2. `cat reports/ultimate_release_gate_$(date +%F)/ULTIMATE_REPORT.md`")
        lines.append("3. `cat reports/ultimate_release_gate_$(date +%F)/artifact_manifest.json | head -n 120`")

        (self.report_dir / "ULTIMATE_REPORT.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> int:
    ap = argparse.ArgumentParser(description="MicrostateLedger ultimate release gate")
    ap.add_argument("--outdir", required=True)
    ap.add_argument("--report-dir", required=True)
    ap.add_argument("--commands-log", required=True)
    ap.add_argument("--seed", type=int, default=20260206)
    ap.add_argument("--n-repeats", type=int, default=3)
    args = ap.parse_args()

    repo_root = Path(__file__).resolve().parents[1]
    outdir = Path(args.outdir).resolve()
    report_dir = Path(args.report_dir).resolve()
    commands_log = Path(args.commands_log).resolve()

    outdir.mkdir(parents=True, exist_ok=True)
    report_dir.mkdir(parents=True, exist_ok=True)
    commands_log.parent.mkdir(parents=True, exist_ok=True)

    runner = GateRunner(
        repo_root=repo_root,
        outdir=outdir,
        report_dir=report_dir,
        commands_log=commands_log,
        seed=args.seed,
        n_repeats=args.n_repeats,
    )

    env_info = runner.collect_env()

    gates = [
        ("gate_3_1_install_cli", runner.run_gate_31),
        ("gate_3_2_schema_tx", runner.run_gate_32),
        ("gate_3_3_id_stability", runner.run_gate_33),
        ("gate_3_4_mapping", runner.run_gate_34),
        ("gate_3_5_docking_md_smoke", runner.run_gate_35),
        ("gate_3_6_anomaly_feedback", runner.run_gate_36),
        ("gate_3_7_perf1000", runner.run_gate_37),
    ]

    for name, fn in gates:
        try:
            summary = fn()
        except Exception as e:
            summary = {"status": "FAIL", "error": str(e)}
        runner.gate_results[name] = summary
        runner.write_gate_json(name, summary)

    runner.write_manifest()
    runner.build_report(env_info)

    overall = all(v.get("status") == "PASS" for v in runner.gate_results.values())
    print(json.dumps({"overall": "PASS" if overall else "FAIL", "report": str(report_dir / 'ULTIMATE_REPORT.md')}, ensure_ascii=False))
    return 0 if overall else 2


if __name__ == "__main__":
    raise SystemExit(main())
