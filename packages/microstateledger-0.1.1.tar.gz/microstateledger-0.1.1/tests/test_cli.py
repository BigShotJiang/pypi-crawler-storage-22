import subprocess
import sys
from pathlib import Path


def test_cli_help():
    cmd = [sys.executable, "-m", "msl.cli", "--help"]
    result = subprocess.run(cmd, capture_output=True, text=True)
    assert result.returncode == 0
    assert "Commands" in result.stdout


def test_cli_init_help():
    cmd = [sys.executable, "-m", "msl.cli", "init", "--help"]
    result = subprocess.run(cmd, capture_output=True, text=True)
    assert result.returncode == 0
    assert "Initialize ledger" in result.stdout


def test_cli_demo_help():
    cmd = [sys.executable, "-m", "msl.cli", "demo", "--help"]
    result = subprocess.run(cmd, capture_output=True, text=True)
    assert result.returncode == 0
    assert "demo" in result.stdout

