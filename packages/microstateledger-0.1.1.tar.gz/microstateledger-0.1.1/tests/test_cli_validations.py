import json
import subprocess
import sys
from pathlib import Path

from typer.testing import CliRunner

from msl import cli
from msl.db import connect, init_db, insert_compound, insert_conformer, insert_microstate


def _run_cli(args, cwd: Path) -> subprocess.CompletedProcess:
    cmd = [sys.executable, "-m", "msl.cli", *args]
    return subprocess.run(cmd, cwd=str(cwd), capture_output=True, text=True)


def _write_basic_config(tmp_path: Path) -> Path:
    cfg_path = tmp_path / "msl.toml"
    cfg_path.write_text(
        """
[project]
name = "TestProject"
root = "{root}"
objects_dir = "objects"
runs_dir = "runs"
reports_dir = "reports"
policy = "policies/default.yaml"
ledger_db = "ledger.sqlite"

[envs]
conda = "conda"
base_dir = "envs"

[logging]
level = "INFO"
log_dir = "logs"
""".strip().format(root=str(tmp_path)),
        encoding="utf-8",
    )
    return cfg_path



def test_init_missing_default_config_is_clean_error(monkeypatch):
    def _raise_missing():
        raise FileNotFoundError("msl.toml not found in current directory")

    monkeypatch.setattr(cli, "find_default_config", _raise_missing)
    runner = CliRunner()
    result = runner.invoke(cli.app, ["init"])

    assert result.exit_code != 0
    assert "msl.toml not found in current directory" in result.output


def test_ingest_rejects_multi_molecule_input_file(tmp_path: Path):
    cfg_path = _write_basic_config(tmp_path)
    multi_sdf = tmp_path / "multi.sdf"
    multi_sdf.write_text("mol1\n$$$$\nmol2\n$$$$\n", encoding="utf-8")

    runner = CliRunner()
    result = runner.invoke(
        cli.app,
        [
            "ingest",
            str(multi_sdf),
            "--config",
            str(cfg_path),
        ],
    )

    assert result.exit_code != 0
    assert "Input file contains multiple molecules" in result.output

def test_diff_charge_mismatch_fails(tmp_path: Path):
    charge_a = tmp_path / "a.json"
    charge_b = tmp_path / "b.json"
    charge_a.write_text(json.dumps([{"canonical_atom_id": 1, "charge": 0.1}]), encoding="utf-8")
    charge_b.write_text(
        json.dumps(
            [
                {"canonical_atom_id": 1, "charge": 0.2},
                {"canonical_atom_id": 2, "charge": -0.2},
            ]
        ),
        encoding="utf-8",
    )

    result = _run_cli(["diff-charge", str(charge_a), str(charge_b)], cwd=Path(__file__).resolve().parents[1])

    assert result.returncode != 0
    assert "charge atom-id mismatch" in result.stderr


def test_diff_charge_success(tmp_path: Path):
    charge_a = tmp_path / "a.json"
    charge_b = tmp_path / "b.json"
    charge_a.write_text(
        json.dumps(
            [
                {"canonical_atom_id": 1, "charge": 0.1},
                {"canonical_atom_id": 2, "charge": -0.1},
            ]
        ),
        encoding="utf-8",
    )
    charge_b.write_text(
        json.dumps(
            [
                {"canonical_atom_id": 1, "charge": 0.2},
                {"canonical_atom_id": 2, "charge": -0.2},
            ]
        ),
        encoding="utf-8",
    )

    result = _run_cli(["diff-charge", str(charge_a), str(charge_b)], cwd=Path(__file__).resolve().parents[1])

    assert result.returncode == 0
    payload = json.loads(result.stdout)
    assert "summary" in payload
    assert len(payload["deltas"]) == 2


def test_receptor_add_missing_file_is_clean_error(tmp_path: Path):
    repo_root = Path(__file__).resolve().parents[1]
    cfg_path = _write_basic_config(tmp_path)

    init_result = _run_cli(["init", "--config", str(cfg_path)], cwd=repo_root)
    assert init_result.returncode == 0

    result = _run_cli(["receptor-add", "missing_receptor.pdb", "--config", str(cfg_path)], cwd=repo_root)

    assert result.returncode != 0
    assert "Receptor file not found" in result.stderr


def _seed_charge_case(tmp_path: Path) -> tuple[Path, str, str]:
    for name in ("objects", "runs", "reports", "logs", "policies", "envs"):
        (tmp_path / name).mkdir(parents=True, exist_ok=True)

    cfg_path = _write_basic_config(tmp_path)
    db_path = tmp_path / "ledger.sqlite"
    schema_path = Path(__file__).resolve().parents[1] / "schemas" / "ledger.sql"
    init_db(db_path, schema_path)

    compound_id = "C-test"
    microstate_id = "M-test"
    conformer_id = "X-test"

    ms_dir = tmp_path / "objects" / "microstates" / compound_id / microstate_id
    ms_dir.mkdir(parents=True, exist_ok=True)
    sdf_path = ms_dir / "microstate.sdf"
    sdf_path.write_text("dummy\n", encoding="utf-8")
    atom_map_path = ms_dir / "atom_map.json"
    atom_map_path.write_text(
        json.dumps([{"atom_index": 0, "canonical_atom_id": 1}], ensure_ascii=False),
        encoding="utf-8",
    )

    conf_dir = tmp_path / "objects" / "conformers" / microstate_id
    conf_dir.mkdir(parents=True, exist_ok=True)
    conf_path = conf_dir / "conf_0.sdf"
    conf_path.write_text("dummy\n", encoding="utf-8")

    conn = connect(db_path)
    insert_compound(conn, compound_id, "cmpd", "hash", "ikey", str(sdf_path))
    insert_microstate(conn, microstate_id, compound_id, "inchi", 0, "none", "", str(sdf_path))
    insert_conformer(conn, conformer_id, microstate_id, str(conf_path), 0.0)
    conn.commit()
    conn.close()

    return cfg_path, microstate_id, conformer_id


def test_charge_auto_qm_keeps_pm6_when_engine_auto(tmp_path: Path, monkeypatch):
    cfg_path, microstate_id, conformer_id = _seed_charge_case(tmp_path)
    captured: dict[str, list[str]] = {}

    monkeypatch.setattr(cli, "_env_available", lambda cfg, name: True)
    monkeypatch.setattr(cli, "_scripts_path", lambda cfg, name: tmp_path / name)

    def fake_run_in_env(cfg, env_name, cmd, cwd=None):
        captured["cmd"] = cmd
        return json.dumps([{"canonical_atom_id": 1, "charge": 0.0}], ensure_ascii=False)

    monkeypatch.setattr(cli, "_run_in_env", fake_run_in_env)

    runner = CliRunner()
    result = runner.invoke(
        cli.app,
        [
            "charge",
            microstate_id,
            "--method",
            "pype_resp",
            "--auto-qm",
            "--conformer-id",
            conformer_id,
            "--qm-engine",
            "auto",
            "--qm-theory",
            "PM6",
            "--config",
            str(cfg_path),
        ],
    )

    assert result.exit_code == 0, result.output
    cmd = captured["cmd"]
    idx = cmd.index("--qm-theory")
    assert cmd[idx + 1] == "PM6"


def test_charge_auto_qm_maps_pm6_to_hf_for_psi4(tmp_path: Path, monkeypatch):
    cfg_path, microstate_id, conformer_id = _seed_charge_case(tmp_path)
    captured: dict[str, list[str]] = {}

    monkeypatch.setattr(cli, "_env_available", lambda cfg, name: True)
    monkeypatch.setattr(cli, "_scripts_path", lambda cfg, name: tmp_path / name)

    def fake_run_in_env(cfg, env_name, cmd, cwd=None):
        captured["cmd"] = cmd
        return json.dumps([{"canonical_atom_id": 1, "charge": 0.0}], ensure_ascii=False)

    monkeypatch.setattr(cli, "_run_in_env", fake_run_in_env)

    runner = CliRunner()
    result = runner.invoke(
        cli.app,
        [
            "charge",
            microstate_id,
            "--method",
            "pype_resp",
            "--auto-qm",
            "--conformer-id",
            conformer_id,
            "--qm-engine",
            "psi4",
            "--qm-theory",
            "PM6",
            "--config",
            str(cfg_path),
        ],
    )

    assert result.exit_code == 0, result.output
    cmd = captured["cmd"]
    idx = cmd.index("--qm-theory")
    assert cmd[idx + 1] == "HF/6-31G*"


def test_md_param_rejects_missing_charges_json(tmp_path: Path, monkeypatch):
    cfg_path, microstate_id, _ = _seed_charge_case(tmp_path)

    monkeypatch.setattr(cli, "_env_available", lambda cfg, name: True)
    monkeypatch.setattr(cli, "_scripts_path", lambda cfg, name: tmp_path / name)

    def fake_run_in_env(cfg, env_name, cmd, cwd=None):
        if env_name == "rdkit":
            return "[CH3:1][OH:2]"
        return "{}"

    monkeypatch.setattr(cli, "_run_in_env", fake_run_in_env)

    runner = CliRunner()
    missing = tmp_path / "no_such_charges.json"
    result = runner.invoke(
        cli.app,
        [
            "md-param",
            microstate_id,
            "--charges-json",
            str(missing),
            "--config",
            str(cfg_path),
        ],
    )

    assert result.exit_code != 0
    assert "Charges JSON not found" in result.output


def test_md_param_rejects_charge_atom_id_mismatch(tmp_path: Path, monkeypatch):
    cfg_path, microstate_id, _ = _seed_charge_case(tmp_path)

    bad_charges = tmp_path / "bad_charges.json"
    bad_charges.write_text(
        json.dumps([{"canonical_atom_id": 999, "charge": 0.1}], ensure_ascii=False),
        encoding="utf-8",
    )

    monkeypatch.setattr(cli, "_env_available", lambda cfg, name: True)
    monkeypatch.setattr(cli, "_scripts_path", lambda cfg, name: tmp_path / name)

    def fake_run_in_env(cfg, env_name, cmd, cwd=None):
        if env_name == "rdkit":
            return "[CH3:1][OH:2]"
        return "{}"

    monkeypatch.setattr(cli, "_run_in_env", fake_run_in_env)

    runner = CliRunner()
    result = runner.invoke(
        cli.app,
        [
            "md-param",
            microstate_id,
            "--charges-json",
            str(bad_charges),
            "--config",
            str(cfg_path),
        ],
    )

    assert result.exit_code != 0
    assert "charges atom-id mismatch" in result.output
