import json
import subprocess
import sys
from pathlib import Path


def test_license_scan(tmp_path: Path):
    output = tmp_path / "license_scan.json"
    cmd = [
        sys.executable,
        str(Path("scripts") / "license_scan.py"),
        "--output",
        str(output),
        "--project",
        str(Path("pyproject.toml")),
        "--include-extras",
        "dev",
    ]
    result = subprocess.run(cmd, capture_output=True, text=True)
    assert result.returncode == 0, result.stderr
    data = json.loads(output.read_text(encoding="utf-8"))
    assert "packages" in data
    assert isinstance(data["packages"], list)
