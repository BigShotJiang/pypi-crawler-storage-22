import json
from pathlib import Path

from typer.testing import CliRunner

from msl import cli
from msl.db import connect, init_db, insert_compound, insert_microstate


def _write_config(root: Path) -> Path:
    cfg = root / 'msl.toml'
    cfg.write_text(
        '\n'.join(
            [
                '[project]',
                f"root = \"{root.as_posix()}\"",
                'objects_dir = "objects"',
                'runs_dir = "runs"',
                'reports_dir = "reports"',
                'policy = "policies/default.yaml"',
                'ledger_db = "ledger.sqlite"',
                '',
                '[envs]',
                'conda = "conda"',
                'base_dir = "envs"',
                '',
                '[logging]',
                'log_dir = "logs"',
                '',
            ]
        ),
        encoding='utf-8',
    )
    return cfg


def test_md_feedback_records_anomaly_on_formula_change(tmp_path, monkeypatch):
    root = tmp_path
    for name in ('objects', 'runs', 'reports', 'logs', 'policies', 'envs'):
        (root / name).mkdir(parents=True, exist_ok=True)

    config_path = _write_config(root)
    db_path = root / 'ledger.sqlite'
    schema_path = Path(__file__).resolve().parents[1] / 'schemas' / 'ledger.sql'
    init_db(db_path, schema_path)

    ref_sdf = root / 'objects' / 'ref.sdf'
    ref_sdf.write_text('dummy', encoding='utf-8')
    probe_sdf = root / 'objects' / 'probe.sdf'
    probe_sdf.write_text('dummy', encoding='utf-8')

    conn = connect(db_path)
    compound_id = 'C-test'
    microstate_id = 'M-test'
    insert_compound(conn, compound_id, 'cmpd', 'hash', 'ikey', str(ref_sdf))
    insert_microstate(conn, microstate_id, compound_id, 'inchi', 0, 'none', '', str(ref_sdf))
    conn.commit()
    conn.close()

    report = {
        'chirality_changes': [],
        'double_bond_changes': [],
        'formula_change': {'changed': True, 'ref': 'C10H10', 'probe': 'C10H11'},
        'recommendations': [
            {
                'action': 're-enumerate',
                'type': 'formula_change',
                'message': 'formula changed',
            }
        ],
    }

    monkeypatch.setattr(cli, '_run_in_env', lambda cfg, env_name, cmd, cwd=None: json.dumps(report))
    monkeypatch.setattr(cli, '_scripts_path', lambda cfg, name: root / f'{name}')

    runner = CliRunner()
    result = runner.invoke(cli.app, ['md-feedback', microstate_id, str(probe_sdf), '--config', str(config_path)])
    assert result.exit_code == 0, result.output

    conn = connect(db_path)
    row = conn.execute('SELECT COUNT(*) FROM anomalies WHERE target_id = ?', (microstate_id,)).fetchone()
    assert row is not None
    assert row[0] == 1

    details = conn.execute('SELECT details_json FROM anomalies WHERE target_id = ?', (microstate_id,)).fetchone()
    assert details is not None
    data = json.loads(details[0])
    assert data['formula_change']['changed'] is True
    conn.close()
