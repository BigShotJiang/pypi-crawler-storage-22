from msl import __version__, resources


def test_resource_policy_exists():
    path = resources.get_resource_file("policies", "default.yaml")
    assert path.exists()
    assert "stages" in path.read_text(encoding="utf-8")


def test_resource_schema_exists():
    path = resources.get_resource_file("schemas", "ledger.sql")
    assert path.exists()
    assert "CREATE TABLE" in path.read_text(encoding="utf-8").upper()


def test_resource_script_exists():
    path = resources.get_resource_file("scripts", "rdkit_ingest.py")
    assert path.exists()


def test_resource_cache_refreshes_existing_dir(tmp_path, monkeypatch):
    monkeypatch.setenv("MSL_RESOURCE_CACHE", str(tmp_path))
    scripts_dir = tmp_path / __version__ / "scripts"
    scripts_dir.mkdir(parents=True, exist_ok=True)

    path = resources.get_resource_file("scripts", "rdkit_ingest.py")

    assert path.exists()
