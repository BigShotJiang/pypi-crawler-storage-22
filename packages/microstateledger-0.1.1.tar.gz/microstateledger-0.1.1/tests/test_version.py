from importlib import metadata

import msl


def test_version_matches_package():
    try:
        pkg_version = metadata.version("microstateledger")
    except metadata.PackageNotFoundError:
        pkg_version = msl.__version__
    assert msl.__version__ == pkg_version
