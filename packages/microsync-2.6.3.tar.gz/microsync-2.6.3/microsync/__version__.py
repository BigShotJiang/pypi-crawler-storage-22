"""
__version__.py
~~~~~~~~~~~~~~
Information about the current version of package
"""

__title__ = "microsync"
__description__ = (
    "Python driver for 32-bit microscope synchronization device."
)
__version__ = "2.6.3"  # Set by CI from tag
__author__ = "Roman Kiselev"
__author_email__ = "roman.kiselev@stjude.org"
__license__ = "Apache 2.0"
__url__ = "https://github.com/stjude-smc/microsync"