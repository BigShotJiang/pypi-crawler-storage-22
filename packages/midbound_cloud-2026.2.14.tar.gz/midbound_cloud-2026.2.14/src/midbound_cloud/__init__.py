"""
Midbound Cloud SDK for Python.

Official SDK for interacting with the Midbound Cloud API.
"""

from .client import Midbound
from . import webhooks

__all__ = ["Midbound", "webhooks"]
__version__ = "0.0.0.dev0"
