"""
Midbound Cloud SDK client.
"""

from typing import Optional
import httpx


class EnrichAPI:
    """Enrichment API for person and company data."""

    def __init__(self, client: httpx.Client):
        self._client = client

    def person(
        self,
        linkedin_url: Optional[str] = None,
        email: Optional[str] = None,
        webhook_url: Optional[str] = None,
        webhook_secret: Optional[str] = None,
    ) -> dict:
        """
        Enrich a person by LinkedIn URL or email.

        Args:
            linkedin_url: LinkedIn profile URL
            email: Email address
            webhook_url: Optional webhook URL for async results
            webhook_secret: Optional webhook signing secret

        Returns:
            Enrichment result dictionary
        """
        payload = {}
        if linkedin_url:
            payload["linkedinUrl"] = linkedin_url
        if email:
            payload["email"] = email
        if webhook_url:
            payload["webhookUrl"] = webhook_url
        if webhook_secret:
            payload["webhookSecret"] = webhook_secret

        response = self._client.post("/v1/enrich/person", json=payload)
        response.raise_for_status()
        return response.json()


class Midbound:
    """
    Midbound Cloud SDK client.

    Example:
        >>> from midbound_cloud import Midbound
        >>> client = Midbound(api_key="your-api-key")
        >>> result = client.enrich.person(linkedin_url="https://linkedin.com/in/example")
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://api.midbound.cloud",
        timeout: float = 30.0,
    ):
        """
        Initialize the Midbound client.

        Args:
            api_key: Your Midbound API key
            base_url: Base URL for the API (default: production)
            timeout: Request timeout in seconds
        """
        self._client = httpx.Client(
            base_url=base_url,
            headers={
                "x-api-key": api_key,
                "Content-Type": "application/json",
            },
            timeout=timeout,
        )
        self.enrich = EnrichAPI(self._client)

    def close(self) -> None:
        """Close the HTTP client."""
        self._client.close()

    def __enter__(self) -> "Midbound":
        return self

    def __exit__(self, *args) -> None:
        self.close()
