"""
Webhook signature verification utilities.

Verify webhook payloads from Midbound to ensure they are authentic
and haven't been tampered with.
"""

import hmac
import hashlib
import json
import re
import time
from typing import Any, Dict, TypeVar, Type, Union

T = TypeVar("T")


def verify_signature(
    payload: str,
    signature: str,
    secret: str,
    max_age_seconds: int = 300,
) -> bool:
    """
    Verify a webhook signature.

    Validates that the webhook payload was signed by Midbound using your
    webhook signing secret. Also checks that the signature hasn't expired.

    Args:
        payload: The raw JSON payload string from the request body
        signature: The signature header value (x-midbound-signature)
        secret: Your webhook signing secret
        max_age_seconds: Maximum age of signature in seconds (default: 300 = 5 minutes)

    Returns:
        True if signature is valid and not expired

    Example:
        >>> from midbound_cloud import webhooks
        >>>
        >>> is_valid = webhooks.verify_signature(
        ...     payload=request.body,
        ...     signature=request.headers["x-midbound-signature"],
        ...     secret=os.environ["WEBHOOK_SECRET"]
        ... )
    """
    match = re.match(r"t=(\d+),v1=([a-f0-9]+)", signature)
    if not match:
        return False

    timestamp_str, received_sig = match.groups()
    timestamp = int(timestamp_str)

    # Check expiry
    if time.time() - timestamp > max_age_seconds:
        return False

    # Verify signature
    signed_payload = f"{timestamp}.{payload}"
    expected_sig = hmac.new(
        secret.encode(),
        signed_payload.encode(),
        hashlib.sha256,
    ).hexdigest()

    # Use timing-safe comparison to prevent timing attacks
    return hmac.compare_digest(expected_sig, received_sig)


def construct_event(
    payload: str,
    signature: str,
    secret: str,
    event_class: Type[T] = dict,  # type: ignore
) -> Union[T, Dict[str, Any]]:
    """
    Verify signature and construct a webhook event.

    Combines signature verification with JSON parsing. Raises ValueError
    if the signature is invalid.

    Args:
        payload: The raw JSON payload string from the request body
        signature: The signature header value (x-midbound-signature)
        secret: Your webhook signing secret
        event_class: Optional class to instantiate with event data

    Returns:
        The parsed webhook event (dict or event_class instance)

    Raises:
        ValueError: If signature is invalid

    Example:
        >>> from midbound_cloud import webhooks
        >>>
        >>> try:
        ...     event = webhooks.construct_event(
        ...         payload=request.body,
        ...         signature=request.headers["x-midbound-signature"],
        ...         secret=os.environ["WEBHOOK_SECRET"]
        ...     )
        ...     print(event["type"])  # e.g., "identity.resolved"
        ... except ValueError:
        ...     print("Invalid webhook signature")
    """
    if not verify_signature(payload, signature, secret):
        raise ValueError("Invalid webhook signature")

    data = json.loads(payload)

    if event_class is dict:
        return data
    return event_class(**data)


# Event type constants
EVENT_TYPES = (
    "identity.resolved",
    "identity.qualified",
    "identity.enriched",
    "identity.validated",
    "identity.session.finalized",
)
