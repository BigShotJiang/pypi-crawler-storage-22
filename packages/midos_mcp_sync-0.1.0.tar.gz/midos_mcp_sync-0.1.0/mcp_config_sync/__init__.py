"""mcp-config-sync: Cross-platform MCP config management CLI."""
__version__ = "0.1.0"
