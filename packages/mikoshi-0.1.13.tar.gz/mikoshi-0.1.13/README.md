```bash
curl -fsSL https://raw.githubusercontent.com/NEETlabs/Mikoshi/main/scripts/install.sh | bash
```

✨ Mikoshi — private local code search + MCP

## Install (macOS)
```bash
brew install pipx
pipx ensurepath
pipx install mikoshi

Use

mikoshi index ~/project
mikoshi search ~/project "query"

MCP

mikoshi-mcp

Codex MCP config (config.toml)

[mcp_servers.mikoshi]
command = "mikoshi-mcp"
args = []
enabled = true

[projects."~/project"]
trust_level = "trusted"

If running Mikoshi from source (dev only), use:
command = “bash”
args = [”-lc”, “cd /path/to/Mikoshi && source .venv/bin/activate && mikoshi-mcp”]

Developer

make install
make test
mikoshi doctor

Note: First run may download the local embedding model once.
```
