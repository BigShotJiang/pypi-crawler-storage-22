from __future__ import annotations

from dataclasses import dataclass


DEFAULT_PLAN = "free"
DEFAULT_FEATURES = ("local_index", "mcp")


class UpgradeRequired(RuntimeError):
    pass


@dataclass(frozen=True)
class Entitlements:
    plan: str
    features: frozenset[str]

    def has(self, feature: str) -> bool:
        return feature in self.features

    def require(self, feature: str) -> None:
        if not self.has(feature):
            raise UpgradeRequired(f"Available with Mikoshi Pro: {feature}")


def from_plan_features(plan: str | None, features: list[str] | None) -> Entitlements:
    normalized_plan = (plan or DEFAULT_PLAN).strip().lower()
    normalized_features = frozenset(
        {item.strip() for item in (features or list(DEFAULT_FEATURES)) if item}
    )
    return Entitlements(plan=normalized_plan, features=normalized_features)
