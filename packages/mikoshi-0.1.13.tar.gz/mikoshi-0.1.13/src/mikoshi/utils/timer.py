from __future__ import annotations

from time import perf_counter


class Timer:
    def __enter__(self) -> "Timer":
        self._start = perf_counter()
        self._end = None
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self._end = perf_counter()

    @property
    def ms(self) -> int:
        end = self._end if self._end is not None else perf_counter()
        return int((end - self._start) * 1000)
