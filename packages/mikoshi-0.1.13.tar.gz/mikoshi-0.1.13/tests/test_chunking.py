from mikoshi.chunking import chunk_text


def test_chunking_overlap() -> None:
    text = "\n".join([f"line {i}" for i in range(1, 11)])
    chunks = chunk_text(text, max_lines=4, overlap=1)

    assert len(chunks) == 3
    assert chunks[0].start_line == 1
    assert chunks[0].end_line == 4
    assert chunks[1].start_line == 4
    assert chunks[1].end_line == 7
    assert chunks[2].start_line == 7
    assert chunks[2].end_line == 10
