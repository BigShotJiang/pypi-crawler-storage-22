from mikoshi.config import load_config


def test_default_quiet_external_libs(monkeypatch) -> None:
    monkeypatch.delenv("MIKOSHI_QUIET_EXTERNAL_LIBS", raising=False)
    config = load_config()
    assert config.quiet_external_libs is True


def test_quiet_external_libs_env_false(monkeypatch) -> None:
    monkeypatch.setenv("MIKOSHI_QUIET_EXTERNAL_LIBS", "0")
    config = load_config()
    assert config.quiet_external_libs is False
