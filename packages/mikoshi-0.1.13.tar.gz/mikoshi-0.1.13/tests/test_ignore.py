from pathlib import Path

from mikoshi.ignore import IgnoreMatcher


def test_gitignore_and_common_ignores(tmp_path: Path) -> None:
    repo = tmp_path / "repo"
    repo.mkdir()

    (repo / ".gitignore").write_text("ignored.txt\nbuild/\n", encoding="utf-8")

    (repo / "ignored.txt").write_text("x", encoding="utf-8")
    (repo / "keep.txt").write_text("x", encoding="utf-8")

    build_dir = repo / "build"
    build_dir.mkdir()
    (build_dir / "artifact.txt").write_text("x", encoding="utf-8")

    node_dir = repo / "node_modules"
    node_dir.mkdir()
    (node_dir / "lib.js").write_text("x", encoding="utf-8")

    matcher = IgnoreMatcher(repo)

    assert matcher.is_ignored(repo / "ignored.txt")
    assert matcher.is_ignored(build_dir / "artifact.txt")
    assert matcher.is_ignored(node_dir / "lib.js")
    assert not matcher.is_ignored(repo / "keep.txt")
