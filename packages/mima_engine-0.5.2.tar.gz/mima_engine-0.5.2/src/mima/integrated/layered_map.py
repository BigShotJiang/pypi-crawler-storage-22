import math

from pygame import Vector2
from typing_extensions import Generic, Protocol

from mima.integrated.entity import Entity, Nature, TEntity
from mima.integrated.lighting import LightingManager
from mima.layered.shape import ShapeCollection
from mima.standalone.geometry import Rect, shape_from_str
from mima.standalone.light import Light
from mima.standalone.spatial import SpatialGrid
from mima.standalone.tiled_map import TiledObject, TiledTile, TiledTilemap, vfloor
from mima.standalone.transformed_view import TileTransformedView

VOFF = Vector2(0.1, 0.1)
GRAVITY = 9.8 * 4  # Units per second²


class Drawable(Protocol):
    def draw(self, ttv: TileTransformedView, cache: bool = False) -> None: ...

    def get_pos(self) -> Vector2: ...


class Renderable:
    def __init__(
        self,
        drawable: Drawable,
        layer: int,
        elevation: int,
        render_layer: int | None = None,
    ) -> None:
        self.drawable = drawable
        self.layer = layer
        self.elevation = elevation
        self.render_layer = layer if render_layer is None else render_layer

    def draw(self, ttv: TileTransformedView, cache: bool = False) -> None:
        self.drawable.draw(ttv, cache)

    def get_bottom(self) -> float:
        return self.drawable.get_pos().y


class ObjectLoader(Generic[TEntity]):
    def load_objects(self, obj: TiledObject) -> list[tuple[TEntity, int]]: ...


class LayeredMap(Generic[TEntity]):
    def __init__(
        self,
        tilemap: TiledTilemap,
        loader: ObjectLoader[TEntity] | None = None,
        world_to_pixel: int = 16,
    ) -> None:
        self._tilemap: TiledTilemap = tilemap
        self._world_size: Vector2 = self._tilemap.world_size
        self._cell_size: int = 8
        self._map_objects: list[tuple[TEntity, int]] = []

        self._background_layer: SpatialGrid[TEntity] = SpatialGrid[TEntity](
            self._world_size, self._cell_size
        )
        self._collision_layer: SpatialGrid[TEntity] = SpatialGrid[TEntity](
            self._world_size, self._cell_size
        )
        self._foreground_layer: SpatialGrid[TEntity] = SpatialGrid[TEntity](
            self._world_size, self._cell_size
        )
        self._lighting_layer: SpatialGrid[Light] = SpatialGrid[Light](
            self._world_size, self._cell_size
        )
        self._effect_layer: list[TEntity] = []
        self._ui_layer: list[TEntity] = []
        self._large_objects: list[TEntity] = []

        self._lighting_color: tuple[int, int, int] | None = (
            None
            if self._tilemap.lighting_color == (255, 255, 255, 255)
            else self._tilemap.lighting_color[:3]
        )

        self._loader: ObjectLoader | None = loader

        self._visible_objects: set[TEntity] = set()
        self._collisions: set[frozenset[TEntity]] = set()
        self._prev_interactions: set[tuple[TEntity, TEntity]] = set()
        self._curr_interactions: set[tuple[TEntity, TEntity]] = set()

        self._tilemap.prerender_layers()
        self.draw_grid: bool = False
        self._world_to_pixel: int = world_to_pixel

    def start_new_frame(self) -> None:
        for layer, grid in enumerate(
            [self._background_layer, self._collision_layer, self._foreground_layer]
        ):
            objects = grid.get_all_objects()
            redundants = [obj for obj in objects if obj.is_redundant]

            for obj in redundants:
                # TODO: query quests
                obj.on_death()
                self.remove_from_layer(obj, layer)
                # grid.remove(obj)

        self._tilemap.start_new_frame()

    def update_global(self, elapsed_time: float) -> bool:
        self._tilemap.update(elapsed_time)
        all_layers = [
            self._background_layer,
            self._collision_layer,
            self._foreground_layer,
        ]
        for grid in all_layers:
            for obj in grid.get_all_objects():
                obj.update_global(elapsed_time)

                # Lighting
                if (light := obj.get_light()).is_enabled() and obj.is_shining():
                    self._lighting_layer.insert(
                        light, light.get_pos(), light.get_area()
                    )
                else:
                    self._lighting_layer.remove(light)

                # Horizontal (x, y) movement
                obj.old_pos = obj.get_pos()
                new_pos = (
                    obj.old_pos + obj.vel * obj.speed * elapsed_time
                    # + obj.fall_dir * elapsed_time
                )
                obj.set_pos(new_pos)
                self.relocate_object(grid, obj, new_pos)

                if not obj.gravity_applies:
                    continue

                # Vertical (z) physics
                obj.old_pz = obj.pz
                if obj.z_state != "GROUNDED":
                    obj.vz -= GRAVITY * elapsed_time
                    obj.pz += obj.vz * elapsed_time
                    obj.visual_pz += obj.vz * elapsed_time

                    # Fallback if no floor at zero present (e.g., pit)
                    if obj.pz < -1:
                        obj.pz = 0
                        obj.vz = 0
                        obj.visual_pz = 0
                        obj.z_state = "GROUNDED"

                # if obj.pz < -1:
                #     obj.pz = 0
                #     obj.vz = 0
                #     obj.z_state = "GROUNDED"
                #     obj.collides_with_map = True
                # obj.pz = max(obj.pz, -1)
                # if obj.z_state == "AIRBORNE":
                #     horiz = obj.vel
                #     if horiz.length_squared() > 1e-4:
                #         obj.fall_dir = horiz.normalize()
                # else:
                #     obj.fall_dir = Vector2()

                # Floor snapping
                hitbox = obj.get_hitbox()
                tl = vfloor(hitbox.get_tl_pos() - VOFF)
                br = vfloor(hitbox.get_br_pos() + VOFF)
                obj_center = (
                    hitbox.get_tl_pos()
                    + (hitbox.get_br_pos() - hitbox.get_tl_pos()) / 2
                )
                tiles_below: list[tuple[float, float, float, TiledTile]] = []

                # floors_below: list[tuple[float, TiledTile]] = []
                # resting: list[tuple[float, tuple[int, int], TiledTile]] = []
                for y in range(int(tl.y), int(br.y) + 1):
                    for x in range(int(tl.x), int(br.x) + 1):
                        for floor_z, tile in self._tilemap.get_tiles(x, y):
                            tcenter = (
                                Vector2(x, y)
                                + Vector2(tile.size) / self._world_to_pixel / 2
                            )
                            tiles_below.append(
                                (
                                    floor_z,
                                    floor_z + tile.z_height,
                                    (tcenter - obj_center).length_squared(),
                                    tile,
                                )
                            )
                            # if obj.old_pz > floor_z >= obj.pz:
                            #     floors_below.append((floor_z, tile))
                            # elif obj.z_state == "AIRBORNE" and obj.pz <0:
                            #     floors_below.append((floor_z, tile))
                            # else:  #if abs(obj.pz - floor_z) <= 0.01:
                            #     resting.append((floor_z, (x, y), tile))
                if obj.z_state == "AIRBORNE" and obj.old_pz > obj.pz:
                    # Falling
                    tiles_below.sort(key=lambda t: (-t[1], t[2]))
                    for z_base, z_height, _, tile in tiles_below:
                        if obj.old_pz > z_height >= obj.pz:
                            if tile.walkable:
                                # snap to floor
                                obj.pz = z_height
                                obj.set_z_offset(z_height * 0.707)
                                obj.visual_pz = 0
                                obj.vz = 0.0
                                obj.z_state = "GROUNDED"
                                break
                elif obj.z_state == "GROUNDED":
                    tiles_below.sort(key=lambda t: (-t[1], t[2]))

                    print() 
                # if floors_below:
                #     print(floors_below)
                #     floor_z, tile = max(floors_below, key=lambda t: t[0])

                #     if tile.walkable:
                #         # Snap to floor
                #         obj.pz = floor_z
                #         obj.vz = 0.0
                #         obj.z_state = "GROUNDED"
                #         obj.collides_with_map = True
                #     else:
                #         obj.fall_dir = tile.fall_dir
                #         obj.collides_with_map = False
                #         # obj.set_pos(obj.get_pos() + obj.fall_dir)
                #         obj.z_state = "AIRBORNE"
                # elif obj.z_state == "GROUNDED" and abs(obj.vz) < 0.0001 and resting:
                #     if all(tile[2].walkable for tile in resting):
                #         floor_z, _, tile = max(resting, key=lambda t: t[0])
                #         obj.pz = floor_z
                #         obj.vz = 0.0
                #         obj.fall_dir = Vector2()
                #         obj.z_state = "GROUNDED"
                #         obj.collides_with_map = True
                #     else:
                #         obj_center = (
                #             hitbox.get_tl_pos()
                #             + (hitbox.get_br_pos() - hitbox.get_tl_pos()) / 2
                #         )
                #         dist: list[tuple[float, float, TiledTile]] = []
                #         for floor_z, pos, tile in resting:
                #             tcenter = (
                #                 Vector2(pos)
                #                 + Vector2(tile.size) / self._world_to_pixel / 2
                #             )
                #             dist.append(
                #                 ((tcenter - obj_center).length_squared(), floor_z, tile)
                #             )
                #         _, floor_z, tile = max(dist, key=lambda t: (t[1], -t[0]))
                #         if tile.walkable:
                #             obj.pz = floor_z
                #             obj.vz = 0.0
                #             obj.fall_dir = Vector2()
                #             obj.z_state = "GROUNDED"
                #             obj.collides_with_map = True
                #         else:
                #             obj.z_state = "AIRBORNE"
                #             obj.fall_dir = tile.fall_dir
                #         obj.collides_with_map = False
                #             # obj.set_pos(obj.get_pos() + tile.fall_dir * 0.25)
                # else:
                #     obj.z_state = "AIRBORNE"

        # Update lights
        lights = self._lighting_layer.get_all_objects()
        for light in lights:
            light.update(elapsed_time)
            self._lighting_layer.relocate(light, light.get_pos(), light.get_area())

        # Update UI objects
        for obj in self._ui_layer:
            obj.update_global(elapsed_time)
        return False

    def update_visible(self, elapsed_time: float, ttv: TileTransformedView) -> bool:
        view = Rect(
            ttv.get_tl_tile() - Vector2(0.5, 0.5),
            ttv.get_br_tile() - ttv.get_tl_tile() + Vector2(1.5, 1.5),
        )

        self._curr_interactions.clear()
        self._collisions.clear()

        visible_objects = self._collision_layer.get_objects_in_region(
            view.pos, view.size
        )

        for obj in visible_objects:
            obj.update_visible(elapsed_time, ttv)

            if not obj.is_collider:
                continue

            hitbox = obj.get_hitbox()

            # Horizontal map collisions (x, y)
            tl = vfloor(hitbox.get_tl_pos() - VOFF)
            br = vfloor(hitbox.get_br_pos() + VOFF)

            if obj.collides_with_map:
                # Collision with map
                for y in range(int(tl.y), int(br.y) + 1):
                    for x in range(int(tl.x), int(br.x) + 1):
                        tiles = self._tilemap.get_blocking_tiles(
                            x, y, obj.pz, obj.pz + obj.z_height
                        )
                        new_pos = collide_with_tiles(hitbox, tiles, Vector2(x, y))
                        self.relocate_object(self._collision_layer, obj, new_pos)

            # Object-to-object collisions
            tl = hitbox.get_tl_pos() - (VOFF * 2)
            br = hitbox.get_br_pos() + (VOFF * 2)
            obj_view = Rect(tl, br - tl)
            close_objects = self._collision_layer.get_objects_in_region(
                obj_view.pos, obj_view.size
            )

            # Collision with other objects
            for other in close_objects:
                if obj == other:
                    continue
                # TODO: implement overlaps/resolve_collision for hitboxes
                if obj.get_hitbox().overlaps(other.get_hitbox().bounding_box):
                    self._collisions.add(frozenset({obj, other}))

        for obj1, obj2 in self._collisions:
            collider = obj1
            target = obj2

            move_both = obj1.is_collider and obj2.is_collider
            if not move_both and obj2.is_collider:
                collider, target = obj2, obj1
            elif move_both and id(obj1) > id(obj2):
                collider, target = obj2, obj1

            if obj1.collides_with_dyn and obj2.collides_with_dyn:
                new_pos1, new_pos2 = collider.get_hitbox().resolve_collision(
                    target.get_hitbox().bounding_box, move_both
                )
                self.relocate_object(self._collision_layer, collider, new_pos1)
                self.relocate_object(self._collision_layer, target, new_pos2)

            self._curr_interactions.add((obj1, obj2))
            self._curr_interactions.add((obj2, obj1))

        entered = self._curr_interactions - self._prev_interactions
        stayed = self._curr_interactions & self._prev_interactions
        exited = self._prev_interactions - self._curr_interactions
        for collider, target in entered:
            target.on_interaction(collider, Nature.ENTER)
            # elif obj.is_player:  # implicitly: obj.collides_with_dyn==True
            #     # Check quests (somehow; they are not available here)
            #     # self.on_interaction(other, Nature.WALK)
        for collider, target in stayed:
            target.on_interaction(collider, Nature.WALK)
        for collider, target in exited:
            target.on_interaction(collider, Nature.EXIT)
        self._prev_interactions = self._curr_interactions.copy()
        return False

    def draw(self, ttv: TileTransformedView) -> None:
        view = Rect(
            ttv.get_tl_tile() - Vector2(0.5, 0.5),
            ttv.get_br_tile() - ttv.get_tl_tile() + Vector2(1.5, 1.5),
        )
        renderables: list[Renderable] = []

        for layer in self._tilemap.get_rendered_layers():
            renderables.append(Renderable(layer, layer.layer, layer.elevation))

        for layer, objects in enumerate(
            [
                self._background_layer.get_objects_in_region(view.pos, view.size),
                self._collision_layer.get_objects_in_region(view.pos, view.size),
                self._foreground_layer.get_objects_in_region(view.pos, view.size),
            ]
        ):
            for obj in objects:
                renderables.append(
                    Renderable(obj, layer, math.floor(obj.elevation), obj.render_layer)
                )

        draw_sorted(renderables, ttv)
        if self._lighting_color is not None:
            ttv.begin_lighting(self._lighting_color)
            for light in self._lighting_layer.get_objects_in_region(
                view.pos, view.size
            ):
                ttv.draw_light(light)
            ttv.end_lighting()
        # TODO: add function to draw directly, only scale to pixel coordinates
        # but dont compute offset.
        # ttv.enable_screen_to_world(False)
        for obj in self._effect_layer:
            obj.draw(ttv)

        ttv.apply_fading()

        for obj in self._ui_layer:
            obj.draw(ttv)
        # ttv.enable_screen_to_world(True)

        if self.draw_grid:
            # cells = self._collision_layer.get_cells_in_region(
            #     self.view.pos, self.view.size
            # )
            # visible_cells = len(cells)
            world_size = self._collision_layer._world_size  # type: ignore[reportPrivateUsage]
            cell_size = self._collision_layer._cell_size  # type: ignore[reportPrivateUsage]
            for i in range(0, int(world_size.x), cell_size):
                ttv.draw_line(Vector2(i, 0), Vector2(i, world_size.y), (0, 255, 255))
            for i in range(0, int(world_size.y), cell_size):
                ttv.draw_line(Vector2(0, i), Vector2(world_size.x, i))

        return

    def relocate_object(
        self, grid: SpatialGrid[TEntity], obj: TEntity, new_pos: Vector2
    ) -> None:
        obj.old_pos = obj.get_pos()
        obj.set_pos(new_pos)
        grid.relocate(obj, new_pos, obj.get_hitbox_size())

    def add_to_layer(self, obj: TEntity, layer: int = 1) -> None:
        if layer == 0:
            self._background_layer.insert(
                obj, obj.get_pos(), obj.get_hitbox().get_bounding_size()
            )
        elif layer == 2:
            self._foreground_layer.insert(
                obj, obj.get_pos(), obj.get_hitbox().get_bounding_size()
            )
        elif layer == 3:
            self._effect_layer.append(obj)
        elif layer == 4:
            self._ui_layer.append(obj)
        else:
            self._collision_layer.insert(
                obj, obj.get_pos(), obj.get_hitbox().get_bounding_size()
            )

        if self._tilemap.get("objects_shining", False) and obj.get_light().is_enabled():
            obj.enable_shining(True)
        else:
            obj.enable_shining(False)

    def remove_from_layer(self, obj: TEntity, layer: int = 1) -> None:
        if layer == 0:
            self._background_layer.remove(obj)
        elif layer == 2:
            self._foreground_layer.remove(obj)
        elif layer == 3 and obj in self._effect_layer:
            self._effect_layer.remove(obj)
        elif layer == 4 and obj in self._ui_layer:
            self._ui_layer.remove(obj)
        else:
            self._collision_layer.remove(obj)

        if (light := obj.get_light()).is_enabled() and obj.is_shining():
            self._lighting_layer.remove(light)

    def add_light(self, light: Light) -> None:
        self._lighting_layer.insert(
            light,
            light.get_pos(),
            Vector2(light.get_radius() * 2, light.get_radius() * 2),
        )

    def remove_light(self, light: Light) -> None:
        self._lighting_layer.remove(light)

    def enable_lighting(
        self, enable: bool = True, color: tuple[int, int, int] | None = None
    ) -> None:
        if enable and color is not None:
            self._lighting_color = color
        else:
            self._lighting_color = None

    def populate_dynamics(self) -> None:
        self._background_layer.clear()
        self._collision_layer.clear()
        self._foreground_layer.clear()

        if self._map_objects:
            for dyn, layer in self._map_objects:
                dyn.on_interaction(dyn, Nature.RESUME)
                self.add_to_layer(dyn, layer)
        elif self._loader is not None:
            for obj in self._tilemap.get_objects():
                dyns = self._loader.load_objects(obj)
                for dyn, layer in dyns:
                    self.add_to_layer(dyn, layer)
                    self._map_objects.append((dyn, layer))

    def is_tile_free(
        self, pos: Vector2, size: Vector2 | None = None, elevation: int = 0
    ) -> bool:
        size = Vector2(1, 1) if size is None else size

        tiles = self._tilemap.get_tiles_in_area(pos, size, elevation)

        free = True
        for tile in tiles:
            if tile.get_collision_boxes():
                return False

        # TODO: Check existing objects
        return free

    @property
    def name(self) -> str:
        return self._tilemap.name

    @property
    def tl(self) -> Vector2:
        return self._tilemap.tl

    @property
    def br(self) -> Vector2:
        return self._tilemap.br

    @property
    def n_objects(self) -> int:
        return (
            self._background_layer.n_objects
            + self._collision_layer.n_objects
            + self._foreground_layer.n_objects
            + len(self._ui_layer)
        )

    def set_loader(self, loader: ObjectLoader[TEntity]) -> None:
        self._loader = loader

    def get_world_size(self) -> Vector2:
        return self._tilemap.world_size


def collide_with_tiles(
    obj: ShapeCollection, tiles: list[TiledTile], tile_offset: Vector2
) -> Vector2:
    obj_origin = obj.pos

    for tile in tiles:
        hitboxes = tile.get_collision_boxes()

        if not hitboxes:
            continue

        for hitbox in hitboxes:
            shape = shape_from_str(
                hitbox.shape, hitbox.pos + tile_offset, hitbox.size, hitbox.radius
            )

            if obj.overlaps(shape):
                res = obj.resolve_collision(shape)
                obj.pos = res[0]
    new_pos = obj.pos
    obj.pos = obj_origin
    return new_pos


def draw_sorted(renderables: list[Renderable], ttv: TileTransformedView) -> None:
    renderables.sort(key=lambda r: (r.render_layer, r.elevation, r.get_bottom()))

    for r in renderables:
        r.draw(ttv, cache=True)
