from enum import Enum

from pygame import Vector2
from typing_extensions import Tuple

from mima.layered.shaped_sprite import SpriteWithShape
from mima.standalone.tiled_map import TiledObject, TiledTileset


class GraphicState(Enum):
    STANDING = 0
    WALKING = 1
    ATTACKING = 2
    DAMAGED = 3
    CELEBRATING = 4
    DEAD = 5
    DEFEATED = 6
    PUSHING = 7
    OPEN = 8
    CLOSED = 9
    LOCKED = 10
    OFF = 11
    ON = 12
    ICON = 13


class Direction4(Enum):
    SOUTH = 0
    WEST = 1
    NORTH = 2
    EAST = 3


Direction = Direction4


class Direction8(Enum):
    SOUTH = 0
    SOUTHWEST = 1
    WEST = 2
    NORTH_WEST = 3
    NORTH = 4
    NORTH_EAST = 5
    EAST = 6
    SOUTH_EAST = 7


def sprite_from_tileset(
    tileset: TiledTileset, sprite_name: str
) -> SpriteWithShape[GraphicState, Direction]:
    sprite = SpriteWithShape[GraphicState, Direction]()

    for tile in tileset.tiles.values():
        if tile.get("sprite_name", "") != sprite_name:
            continue

        gs = GraphicState[tile.get("graphic_state", "standing").upper()]
        d = Direction[tile.get("facing_direction", "south").upper()]
        if tile.animated:
            for frame in tile.frames:
                sprite.add_frame(gs, d, frame.as_dict())
        else:
            sprite.add_frame(gs, d, tile.get_frame().as_dict())

    return sprite


def sprite_from_tileset_gid(
    tileset: TiledTileset, gid: int
) -> SpriteWithShape[GraphicState, Direction]:
    sprite = SpriteWithShape[GraphicState, Direction]()

    tile = tileset.tiles[gid]
    gs = GraphicState[tile.get("graphic_state", "standing").upper()]
    d = Direction[tile.get("facing_direction", "south").upper()]

    if tile.animated:
        for frame in tile.frames:
            sprite.add_frame(gs, d, frame.as_dict())
    else:
        sprite.add_frame(gs, d, tile.get_frame().as_dict())

    return sprite


def vel_to_dir(v: Vector2):
    direction = None
    if abs(v.x) >= abs(v.y):
        if v.x > 0:
            direction = Direction.EAST
        elif v.x < 0:
            direction = Direction.WEST
        else:
            # TODO: Check for up and down
            pass
    elif abs(v.x) < abs(v.y):
        if v.y > 0:
            direction = Direction.SOUTH
        elif v.y < 0:
            direction = Direction.NORTH
        else:
            # TODO: Check for left and right
            pass
    return direction


def dir_to_vel(direction: Direction) -> Tuple[int, int]:
    vx = vy = 0

    if direction == Direction.SOUTH:
        vy = 1
    elif direction == Direction.EAST:
        vx = 1
    elif direction == Direction.NORTH:
        vy = -1
    elif direction == Direction.WEST:
        vx = -1
    return vx, vy


class Anchor(Enum):
    TOP_LEFT = 0
    TOP_RIGHT = 1
    BOTTOM_LEFT = 2
    BOTTOM_RIGHT = 3
    CENTER = 4
    TOP_CENTER = 5
    RIGHT_CENTER = 6
    BOTTOM_CENTER = 7
    LEFT_CENTER = 8


def anchor_offset(anchor: Anchor) -> Vector2:
    if anchor == Anchor.TOP_RIGHT:
        return Vector2(-1, 0)
    elif anchor == Anchor.BOTTOM_LEFT:
        return Vector2(0, -1)
    elif anchor == Anchor.BOTTOM_RIGHT:
        return Vector2(-1, -1)
    elif anchor == Anchor.CENTER:
        return Vector2(-0.5, -0.5)
    elif anchor == Anchor.TOP_CENTER:
        return Vector2(-0.5, 0)
    elif anchor == Anchor.RIGHT_CENTER:
        return Vector2(-1, -0.5)
    elif anchor == Anchor.BOTTOM_CENTER:
        return Vector2(-0.5, -1.0)
    elif anchor == Anchor.LEFT_CENTER:
        return Vector2(0, -0.5)
    else:
        return Vector2()


class Until(Enum):
    UNLOCK = 0
    NEXT_UPDATE = 1
