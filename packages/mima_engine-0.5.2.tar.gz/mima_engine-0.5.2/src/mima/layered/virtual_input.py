import logging
import time
from dataclasses import dataclass

import pygame
from typing_extensions import Iterable, Protocol, TypeAlias

from mima.standalone.user_input import Input, InputManager, Player

LOG = logging.getLogger(__name__)


class InputResolver(Protocol):
    def resolve(self, im: InputManager, player: Player): ...


@dataclass(frozen=True)
class AnalogDirectionSource:
    x: Input | None
    y: Input | None


@dataclass(frozen=True)
class DigitalDirectionSource:
    left: Input
    right: Input
    up: Input
    down: Input


DirectionSource: TypeAlias = AnalogDirectionSource | DigitalDirectionSource


class DirectionResolver:
    """Resolves directional intent as a Vector2.

    Resolution order is significant, first non-zero source wins.
    """

    def __init__(
        self,
        sources: Iterable[DirectionSource],
        deadzone: float = 0.5,
        normalize: bool = True,
    ) -> None:
        self.sources = tuple(sources)
        self.deadzone = deadzone
        self.normalize = normalize

    def resolve(self, im: InputManager, player: Player = Player.P1) -> pygame.Vector2:
        for src in self.sources:
            if isinstance(src, AnalogDirectionSource):
                vec = self._resolve_analog(im, player, src)
            else:
                vec = self._resolve_digital(im, player, src)

            if vec.length_squared() > 0:
                if self.normalize and vec.length_squared() > 1:
                    vec = vec.normalize()
                return vec

        return pygame.Vector2()

    def _resolve_analog(
        self, im: InputManager, player: Player, src: AnalogDirectionSource
    ) -> pygame.Vector2:
        x = im.value(src.x, player) if src.x else 0.0
        y = im.value(src.y, player) if src.y else 0.0

        if abs(x) < self.deadzone:
            x = 0.0
        if abs(y) < self.deadzone:
            y = 0.0

        return pygame.Vector2(x, y)

    def _resolve_digital(
        self, im: InputManager, player: Player, src: DigitalDirectionSource
    ) -> pygame.Vector2:
        x = (1 if im.held(src.right, player) else 0) - (
            1 if im.held(src.left, player) else 0
        )
        y = (1 if im.held(src.down, player) else 0) - (
            1 if im.held(src.up, player) else 0
        )
        return pygame.Vector2(x, y)


class ButtonGroupResolver:
    """Resolves a logical button as active if ANY source is active."""

    def __init__(self, *inputs: Input) -> None:
        self.inputs = inputs

    def pressed(self, im: InputManager, player: Player = Player.P1) -> bool:
        return any(im.pressed(i, player) for i in self.inputs)

    def held(self, im: InputManager, player: Player = Player.P1) -> bool:
        return any(im.held(i, player) for i in self.inputs)

    def released(self, im: InputManager, player: Player = Player.P1) -> bool:
        return any(im.released(i, player) for i in self.inputs)


class AxisSnapResolver:
    """Converts an axis into digital directions.

    The AxisSnapResolver allows analog sticks to behave like digital buttons, making
    them suitable for menus, grids, and UI navigation while preserving unified input
    semantics across keyboard, D-Pad, and controller.

    """

    def __init__(
        self, axis: Input, negative: Input, positive: Input, deadzone: float = 0.5
    ) -> None:
        self.axis = axis
        self.negative = negative
        self.positive = positive
        self.deadzone = deadzone
        self._last_value: float = 0.0

    def resolve(self, im: InputManager, player: Player = Player.P1) -> set[Input]:
        value = im.value(self.axis, player)
        result: set[Input] = set()

        if value <= -self.deadzone and self._last_value > -self.deadzone:
            result.add(self.negative)
        elif value >= self.deadzone and self._last_value < self.deadzone:
            result.add(self.positive)

        self._last_value = value

        return result


# def load_direction_resolver(data: dict) -> DirectionResolver:
#     """TODO:"""
#     sources = [
#         AnalogDirectionSource(
#             Input[src["x"]] if src.get("x") else None,
#             Input[src["y"]] if src.get("y") else None,
#         )
#         for src in data["sources"]
#     ]

#     return DirectionResolver(
#         sources=sources,
#         deadzone=data.get("deadzone", 0.5),
#         normalize=data.get("normalize", True),
#     )


MOVE_DIRECTION = DirectionResolver(
    sources=[
        AnalogDirectionSource(Input.LEFT_STICK_X, Input.LEFT_STICK_Y),
        DigitalDirectionSource(
            left=Input.DPAD_LEFT,
            right=Input.DPAD_RIGHT,
            up=Input.DPAD_UP,
            down=Input.DPAD_DOWN,
        ),
        DigitalDirectionSource(
            left=Input.LEFT, right=Input.RIGHT, up=Input.UP, down=Input.DOWN
        ),
    ]
)

KEYBOARD_MOVE = DirectionResolver(
    sources=[
        DigitalDirectionSource(
            left=Input.LEFT, right=Input.RIGHT, up=Input.UP, down=Input.DOWN
        )
    ]
)

CONTROLLER_MOVE = DirectionResolver(
    sources=[
        AnalogDirectionSource(Input.LEFT_STICK_X, Input.LEFT_STICK_Y),
        DigitalDirectionSource(
            left=Input.DPAD_LEFT,
            right=Input.DPAD_RIGHT,
            up=Input.DPAD_UP,
            down=Input.DPAD_DOWN,
        ),
    ]
)

MENU_MOVE_X = AxisSnapResolver(
    axis=Input.LEFT_STICK_X, negative=Input.LEFT, positive=Input.RIGHT, deadzone=0.25
)

MENU_MOVE_Y = AxisSnapResolver(
    axis=Input.LEFT_STICK_Y, negative=Input.UP, positive=Input.DOWN, deadzone=0.25
)


def resolve_menu_directions(im: InputManager, player: Player = Player.P1) -> set[Input]:
    directions: set[Input] = set()

    # Analog stick -> digital
    directions |= MENU_MOVE_X.resolve(im, player)
    directions |= MENU_MOVE_Y.resolve(im, player)

    # D-Pad and keyboard
    if im.pressed(Input.DPAD_UP, player) or im.pressed(Input.UP):
        directions.add(Input.UP)
    if im.pressed(Input.DPAD_DOWN, player) or im.pressed(Input.DOWN):
        directions.add(Input.DOWN)
    if im.pressed(Input.DPAD_LEFT, player) or im.pressed(Input.LEFT):
        directions.add(Input.LEFT)
    if im.pressed(Input.DPAD_RIGHT, player) or im.pressed(Input.RIGHT):
        directions.add(Input.RIGHT)

    return directions


@dataclass
class MenuNavConfig:
    initial_delay: float = 0.4
    repeat_interval: float = 0.1
    axis_threshold: float = 0.6


class MenuNavigationResolver:
    """Resolves menu navigation intent from keyboard, d-pad, and stick."""

    def __init__(self, config: MenuNavConfig | None = None) -> None:
        self.config = config or MenuNavConfig()

        # Per-player, per-direction state
        self._held_since: dict[tuple[Player, Input], float] = {}
        self._last_emit: dict[tuple[Player, Input], float] = {}

    def resolve(self, im: InputManager, player: Player = Player.P1) -> set[Input]:
        now = time.monotonic()
        result: set[Input] = set()

        # Collect raw directional state
        active = self._collect_active_directions(im, player)

        # Resolve edge and repeat
        for direction in active:
            key = (player, direction)

            if key not in self._held_since:
                # Fresh press
                self._held_since[key] = now
                self._last_emit[key] = now
                result.add(direction)
                continue

            held_time = now - self._held_since[key]
            since_last = now - self._last_emit[key]

            if held_time >= self.config.initial_delay:
                if since_last >= self.config.repeat_interval:
                    self._last_emit[key] = now
                    result.add(direction)

        # Clear released directions
        released = set(self._held_since.keys()) - {(player, d) for d in active}
        for key in released:
            self._held_since.pop(key, None)
            self._last_emit.pop(key, None)

        return result

    def _collect_active_directions(
        self, im: InputManager, player: Player
    ) -> set[Input]:
        result: set[Input] = set()

        # D-Pad and keyboard
        if im.held(Input.DPAD_UP, player) or im.held(Input.UP):
            result.add(Input.UP)
        if im.held(Input.DPAD_DOWN, player) or im.held(Input.DOWN):
            result.add(Input.DOWN)
        if im.held(Input.DPAD_LEFT, player) or im.held(Input.LEFT):
            result.add(Input.LEFT)
        if im.held(Input.DPAD_RIGHT, player) or im.held(Input.RIGHT):
            result.add(Input.RIGHT)

        # Stick (snapped)
        x = im.value(Input.LEFT_STICK_X, player)
        y = im.value(Input.LEFT_STICK_Y, player)

        if x <= -self.config.axis_threshold:
            result.add(Input.LEFT)
        elif x >= self.config.axis_threshold:
            result.add(Input.RIGHT)
        if y <= -self.config.axis_threshold:
            result.add(Input.UP)
        elif y >= self.config.axis_threshold:
            result.add(Input.DOWN)

        return result


MENU_NAV = MenuNavigationResolver(
    MenuNavConfig(initial_delay=0.35, repeat_interval=0.08, axis_threshold=0.65)
)
