from dataclasses import dataclass


@dataclass
class TileAnimation:
    frame_id: int
    duration: float
