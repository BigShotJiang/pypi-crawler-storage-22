import math
import random

from pygame import Vector2
from pygame.math import clamp


class LightPreset:
    def __init__(self, **kwargs):
        self.__dict__.update(kwargs)


class Light:
    intensity_levels: int = 16

    def __init__(
        self,
        pos: Vector2,
        radius: float,
        intensity: int = 16,
        preset: LightPreset | None = None,
    ) -> None:
        preset = LightPreset() if preset is None else preset

        self._pos: Vector2 = pos
        self._base_radius: float = radius
        intensity = preset.__dict__.get("intensity", intensity)
        self._base_intensity: int = max(0, min(intensity, self.intensity_levels))
        self._radius: float = self._base_radius
        self._intensity: int = self._base_intensity
        self._enabled: bool = True

        # Shared parameters

        self._color: tuple[int, int, int] = preset.__dict__.get(
            "color", (255, 255, 255)
        )
        self._discrete: bool = preset.__dict__.get("discrete", False)

        # Falloff parameters
        self._levels: int | None = preset.__dict__.get("levels", None)
        self._gamma: float = preset.__dict__.get("gamma", 1.0)

        # Continuous parameters
        self._flicker_phase = random.random() * 2 * math.pi
        self._flicker_strength: float = preset.__dict__.get("flicker_strength", 0.08)
        self._flicker_speed: float = preset.__dict__.get("flicker_speed", 8.0)

        # Discrete parameters
        self._flicker_frequency: float = preset.__dict__.get("flicker_frequency", 0.25)
        self._flicker_timer: float = self._flicker_frequency
        self._radius_offsets: list[float] = preset.__dict__.get(
            "radius_offsets", [-0.08, -0.03, 0.0, 0.04]
        )
        self._radius_random: bool = preset.__dict__.get("radius_random", False)
        self._radius_index: int = 0

    def enabled(self, enable: bool = True) -> None:
        self._enabled = enable

    def is_enabled(self) -> bool:
        return self._enabled

    def update(self, elapsed_time: float) -> bool:
        if self._discrete:
            self._flicker_timer -= elapsed_time
            if self._flicker_timer <= 0.0:
                self._flicker_timer += self._flicker_frequency
                if self._radius_random:
                    offset = random.choice(self._radius_offsets)
                else:
                    self._radius_index += 1
                    self._radius_index %= len(self._radius_offsets)
                    offset = self._radius_offsets[self._radius_index]
                self._radius = self._base_radius * (1 + offset)

                return True
        else:
            self._flicker_phase += elapsed_time * self._flicker_speed

            noise = math.sin(self._flicker_phase)
            scale = 1.0 + noise * self._flicker_strength

            self._radius = self._base_radius * scale
            self._radius = clamp(
                self._radius, self._base_radius * 0.9, self._base_radius * 1.1
            )
            self._intensity = round(self._base_intensity * (1 + noise * 0.1))
            return True
        return False

    def set_pos(self, pos: Vector2) -> None:
        self._pos = pos

    def get_pos(self) -> Vector2:
        return self._pos

    def get_area(self) -> Vector2:
        return Vector2(self._radius * 2, self._radius * 2)

    def get_rgb(self) -> tuple[int, int, int]:
        return (
            int(
                clamp(self._color[0] * self._intensity / self.intensity_levels, 0, 255)
            ),
            int(
                clamp(self._color[1] * self._intensity / self.intensity_levels, 0, 255)
            ),
            int(
                clamp(self._color[2] * self._intensity / self.intensity_levels, 0, 255)
            ),
        )

    def get_color(self) -> tuple[int, int, int]:
        return self._color

    def get_radius(self) -> float:
        return self._radius

    def get_intensity(self) -> int:
        return max(0, min(self._intensity, self.intensity_levels))

    def get_gamma(self) -> float:
        return self._gamma

    def get_levels(self) -> int | None:
        return self._levels


TORCH = LightPreset(
    gamma=1.4,
    levels=3,
    discrete=False,
    flicker_strength=0.10,
    flicker_speed=7.0,
    intensity=14,
    color=(255, 180, 9),
)

LANTERN = LightPreset(
    gamma=1.5,
    levels=3,
    discrete=True,
    flicker_frequency=0.35,
    radius_offsets=[-0.03, 0.0, 0.03, 0.0],
    intensity=13,
    color=(255, 200, 120),
)

MAGIC_LAMP = LightPreset(
    intensity=15,
    color=(120, 180, 255),
    flicker_strength=0.06,
    flicker_speed=2.0,
    levels=None,
    gamma=1.7,
)

CRYSTAL_RUNE = LightPreset(intensity=16, color=(180, 120, 255), levels=None, gamma=1.8)
