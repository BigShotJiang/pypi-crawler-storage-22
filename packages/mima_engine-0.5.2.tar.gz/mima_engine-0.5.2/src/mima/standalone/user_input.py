from __future__ import annotations

import logging
from dataclasses import dataclass
from enum import Enum

import pygame
from typing_extensions import Callable, Iterable, Protocol, TypeAlias, TypeVar

LOG = logging.getLogger(__name__)


class Input(Enum):
    """Logical input identifiers independent of physical devices."""

    UP = 0
    DOWN = 1
    LEFT = 2
    RIGHT = 3
    A = 4
    B = 5
    X = 6
    Y = 7
    START = 8
    SELECT = 9
    L1 = 10
    R1 = 11
    L2 = 12
    R2 = 13
    L3 = 14
    R3 = 15
    DPAD_UP = 16
    DPAD_DOWN = 17
    DPAD_LEFT = 18
    DPAD_RIGHT = 19
    LEFT_STICK_X = 20  # left x-axis
    LEFT_STICK_Y = 21  # left y-axis
    RIGHT_STICK_X = 22  # left x-axis
    RIGHT_STICK_Y = 23  # left y-axis


class Player(Enum):
    NP = 0  # No player
    P1 = 1  # Player 1
    P2 = 2  # Player 2
    P3 = 3  # Player 3
    P4 = 4  # Player 4
    RP = 5  # Remote player


LOCAL_PLAYERS = [Player.P1, Player.P2, Player.P3, Player.P4]


@dataclass(frozen=True)
class InputEvent:
    button: Input
    player: Player
    value: float  # 1 set, 0 unset, -1 and everything between for axes


class PlayerAssignment:
    """Manages controller to player assignment.

    Policy:
    - First connect controller gets P1
    - Next gets p2, ect.
    - Released on disconnect
    """

    def __init__(self) -> None:
        self._joy_to_player: dict[int, Player] = {}
        self._player_to_joy: dict[Player, int] = {}

    def assign(self, instance_id: int) -> Player | None:
        if instance_id in self._joy_to_player:
            return self._joy_to_player[instance_id]

        for player in LOCAL_PLAYERS:
            if player not in self._player_to_joy:
                self._joy_to_player[instance_id] = player
                self._player_to_joy[player] = instance_id
                return player

        return None

    def release(self, instance_id: int) -> Player | None:
        player = self._joy_to_player.pop(instance_id, None)
        if player is not None:
            self._player_to_joy.pop(player, None)
        return player

    def get_player(self, instance_id: int) -> Player | None:
        return self._joy_to_player.get(instance_id)

    def force_assign(self, instance_id: int, player: Player) -> None:
        self._joy_to_player[instance_id] = player

    def mapping(self) -> dict[int, Player]:
        """Return read-only copy."""
        return dict(self._joy_to_player)


class InputScheme(Protocol):
    """Translate pygame events into logical input events."""

    def handle(self, event: pygame.event.Event) -> list[InputEvent]: ...

    def poll(self) -> list[InputEvent]: ...


Proto = TypeVar("Proto", bound=InputScheme)


class InputManager:
    """A class that manages keyboards, gamepad, and touch events."""

    def __init__(self) -> None:
        pygame.joystick.init()

        self._players = PlayerAssignment()

        self._previous: dict[Player, dict[Input, float]] = {
            p: {i: 0.0 for i in Input} for p in Player
        }
        self._current: dict[Player, dict[Input, float]] = {
            p: {i: 0.0 for i in Input} for p in Player
        }
        self._schemes: list[InputScheme] = []
        self._joysticks: dict[int, pygame.joystick.JoystickType] = {}

        self._discover_joysticks()

    def add_input_scheme(self, scheme: InputScheme) -> None:
        """Add an input scheme to this manager."""
        scheme.im = self  # type: ignore[reportAttributeAccessIssue]
        self._schemes.append(scheme)

    def process_events(
        self, events: list[pygame.event.Event] | None = None
    ) -> list[pygame.event.Event]:
        """Query and process all pygame events that are relevant for input.

        Events may be provided or queried directly from pygame. Processing of
        events is delegated to the input schemes.

        Args:
            events: List of pygame events or None. When None is passed, the
            inputs will be queried with ``pygame.event.get()``.

        Returns:
            A list with all pygame events.
        """
        if events is None or not events:
            events = list(pygame.event.get())

        # Snapshot previous state
        self._previous = {p: state.copy() for p, state in self._current.items()}

        logical_events: list[InputEvent] = []

        # Event-driven input
        for event in events:
            self._handle_device_events(event)

            for scheme in self._schemes:
                logical_events.extend(scheme.handle(event))

        # Polled input (axes, continuous values)
        for scheme in self._schemes:
            logical_events.extend(scheme.poll())

        # Apply results
        self._apply_input_events(logical_events)

        return events

    def pressed(self, button: Input, player: Player = Player.P1) -> bool:
        """Return True when the requested input has been newly pressed."""
        return (
            self._current[player][button] != 0.0
            and self._previous[player][button] == 0.0
        )

    def held(self, button: Input, player: Player = Player.P1) -> bool:
        """Return True when the requested input has been held."""
        return self._current[player][button] != 0.0

    def released(self, button: Input, player: Player = Player.P1) -> bool:
        """Return True when the requested input is no longer held."""
        return (
            self._previous[player][button] != 0.0
            and self._current[player][button] == 0.0
        )

    def value(self, button: Input, player: Player = Player.P1) -> float:
        """Return the value of the requested input."""
        return self._current[player][button]

    def get_joysticks(self):
        return dict(self._joysticks)

    def get_player_assignments(self) -> dict[int, Player]:
        return self._players.mapping()

    def get_player_for_joystick(self, instance_id: int) -> Player | None:
        return self._players.mapping().get(instance_id)

    def force_assign_controller(self, instance_id: int, player: Player) -> None:
        self._players.force_assign(instance_id, player)

    def set_value(
        self, value: float, button: Input, player: Player = Player.P1
    ) -> None:
        """Set the value for the requested input."""
        self._current[player][button] = value

    def _apply_input_events(self, events: Iterable[InputEvent]) -> None:
        for event in events:
            self._current[event.player][event.button] = event.value

    def _discover_joysticks(self) -> None:
        for index in range(pygame.joystick.get_count()):
            js = pygame.joystick.Joystick(index)
            jid = js.get_instance_id()

            self._joysticks[jid] = js
            self._players.assign(jid)

            LOG.info("Detected gamepad #%d: %s", jid, js.get_name())

    def _handle_device_events(self, event: pygame.event.Event) -> None:
        if event.type == pygame.JOYDEVICEADDED:
            js = pygame.joystick.Joystick(event.device_index)
            jid = js.get_instance_id()

            self._joysticks[jid] = js
            self._players.assign(jid)
            LOG.info("New device detected: #%d %s", jid, js.get_name())

        elif event.type == pygame.JOYDEVICEREMOVED:
            self._joysticks.pop(event.instance_id, None)
            self._players.release(event.instance_id)
            LOG.info("Device removed: #%d", event.instance_id)


class KeyboardMapping:
    def __init__(self, mapping: dict[Player, dict[Input, list[str]]]) -> None:
        self.im: InputManager | None = None
        self._mapping: dict[Player, dict[Input, list[str]]] = {}
        self._reverse_mapping: dict[int, tuple[Input, Player]] = {}
        for p, m in mapping.items():
            self._mapping.setdefault(p, {})
            for i, k in m.items():
                self._mapping[p][i] = []
                for val in k:
                    if len(val) > 1:
                        # text is uppercase, letters are lowercase
                        val = val.upper()
                    elif len(val) == 0:
                        val = val.lower()
                    key = getattr(pygame, f"K_{val}")
                    self._mapping[p][i].append(key)
                    self._reverse_mapping[key] = (i, p)

    def handle(self, event: pygame.event.Event) -> list[InputEvent]:
        actions = []

        if event.type == pygame.KEYDOWN:
            ip = self._reverse_mapping.get(event.key, ())
            if ip and len(ip) == 2:
                actions.append(InputEvent(button=ip[0], player=ip[1], value=1.0))
        if event.type == pygame.KEYUP:
            ip = self._reverse_mapping.get(event.key, ())
            if ip and len(ip) == 2:
                actions.append(InputEvent(button=ip[0], player=ip[1], value=0.0))
        return actions

    def poll(self) -> list[InputEvent]:
        return []


@dataclass(frozen=True)
class JoyButton:
    index: int


@dataclass(frozen=True)
class JoyAxis:
    index: int
    deadzone: float = 0.25
    invert: bool = False


@dataclass(frozen=True)
class JoyHat:
    hat: int  # usually 0
    axis: int  # 0 = x, 1 = y
    direction: int  # -1 or +1


PhysicalInput: TypeAlias = JoyButton | JoyAxis | JoyHat
ControllerMapping: TypeAlias = dict[Input, list[PhysicalInput]]


@dataclass(frozen=True)
class ControllerProfile:
    name: str
    check: Callable[[pygame.joystick.JoystickType], bool]
    mapping: ControllerMapping


class _ResolveMapping:
    def __init__(self, mapping: ControllerMapping) -> None:
        self._button_map: dict[int, list[Input]] = {}
        self._hat_map: list[tuple[JoyHat, Input]] = []
        self._axis_map: list[tuple[JoyAxis, Input]] = []

        for logical, inputs in mapping.items():
            for phys in inputs:
                if isinstance(phys, JoyButton):
                    self._button_map.setdefault(phys.index, []).append(logical)
                elif isinstance(phys, JoyHat):
                    self._hat_map.append((phys, logical))
                elif isinstance(phys, JoyAxis):
                    self._axis_map.append((phys, logical))


class GamepadMapping:
    """Translatest joystick input into logical InputEvents."""

    def __init__(self, profiles: list[ControllerProfile] | None = None) -> None:
        self.im: InputManager | None = None

        profiles = profiles or [
            RETROID5_PROFILE,
            XBOX_PROFILE,
            PLAYSTATION_PROFILE,
            GENERIC_PROFILE,
        ]

        self._profiles: list[ControllerProfile] = profiles

        # Per-joystick resolved mapping
        self._resolved: dict[int, _ResolveMapping] = {}

    def handle(self, event: pygame.event.Event) -> list[InputEvent]:
        actions: list[InputEvent] = []

        if not hasattr(event, "instance_id") or self.im is None:
            return actions

        jid = event.instance_id
        player = self.im.get_player_for_joystick(jid)
        if player is None:
            return actions

        mapping = self._get_mapping(jid)
        if not mapping:
            return actions

        if event.type == pygame.JOYBUTTONDOWN:
            for logical in mapping._button_map.get(event.button, []):
                actions.append(InputEvent(logical, player, 1.0))
                LOG.debug(
                    "Joy #%d button=%d, logical=%s player=%s",
                    event.instance_id,
                    event.button,
                    logical,
                    player,
                )

        if event.type == pygame.JOYBUTTONUP:
            for logical in mapping._button_map.get(event.button, []):
                actions.append(InputEvent(logical, player, 0.0))

        if event.type == pygame.JOYHATMOTION:
            for phys, logical in mapping._hat_map:
                x, y = event.value
                val = x if phys.axis == 0 else y
                actions.append(
                    InputEvent(logical, player, 1.0 if val == phys.direction else 0.0)
                )
                LOG.debug(
                    "Joy #%d hat=%d, axis=%d, val=%d, logical=%s player=%s",
                    event.instance_id,
                    event.hat,
                    phys.axis,
                    val,
                    logical,
                    player,
                )

        return actions

    def poll(self) -> list[InputEvent]:
        actions: list[InputEvent] = []
        if self.im is None:
            return actions

        for jid, js in self.im.get_joysticks().items():
            player = self.im.get_player_for_joystick(jid)
            if player is None:
                continue

            mapping = self._get_mapping(jid)
            if not mapping:
                continue

            for phys, logical in mapping._axis_map:
                try:
                    raw = js.get_axis(phys.index)
                except Exception:
                    LOG.exception(
                        "Error querying axis %d for joysting #%d %s",
                        phys.index,
                        js.get_instance_id(),
                        js.get_name(),
                    )
                    continue

                value = normalize_axis(raw, phys.deadzone, phys.invert)
                actions.append(InputEvent(logical, player, value))
        return actions

    def _get_mapping(self, jid: int) -> _ResolveMapping | None:
        if jid in self._resolved:
            return self._resolved[jid]

        if self.im is None:
            return None
        js = self.im.get_joysticks().get(jid)
        if js is None:
            return None

        for profile in self._profiles:
            if profile.check(js):
                resolved = _ResolveMapping(profile.mapping)
                self._resolved[jid] = resolved
                return resolved
        return None


def normalize_axis(value: float, deadzone: float, invert: bool) -> float:
    if abs(value) < deadzone:
        return 0.0
    return -value if invert else value


class TouchMapping:
    def handle(self, event: pygame.event.Event) -> list[InputEvent]:
        return []


GENERIC_PROFILE = ControllerProfile(
    name="Generic Gamepad",
    check=lambda js: True,  # Fallback
    mapping={
        Input.A: [JoyButton(0)],
        Input.B: [JoyButton(1)],
        Input.X: [JoyButton(2)],
        Input.Y: [JoyButton(3)],
        Input.L1: [JoyButton(4)],
        Input.R1: [JoyButton(5)],
        Input.SELECT: [JoyButton(6)],
        Input.START: [JoyButton(7)],
        Input.L3: [JoyButton(8)],
        Input.R3: [JoyButton(9)],
        Input.LEFT_STICK_X: [JoyAxis(0)],
        Input.LEFT_STICK_Y: [JoyAxis(1)],
        Input.RIGHT_STICK_X: [JoyAxis(2)],
        Input.RIGHT_STICK_Y: [JoyAxis(3)],
        Input.L2: [JoyAxis(4)],
        Input.R2: [JoyAxis(5)],
        Input.DPAD_LEFT: [JoyHat(0, 0, -1)],
        Input.DPAD_RIGHT: [JoyHat(0, 0, 1)],
        Input.DPAD_UP: [JoyHat(0, 1, 1)],
        Input.DPAD_DOWN: [JoyHat(0, 1, -1)],
    },
)

XBOX_PROFILE = ControllerProfile(
    name="Xbox Controller",
    check=lambda js: "xbox" in js.get_name().lower(),
    mapping={
        Input.A: [JoyButton(0)],
        Input.B: [JoyButton(1)],
        Input.X: [JoyButton(2)],
        Input.Y: [JoyButton(3)],
        Input.L1: [JoyButton(4)],
        Input.R1: [JoyButton(5)],
        Input.SELECT: [JoyButton(6)],
        Input.START: [JoyButton(7)],
        Input.L3: [JoyButton(8)],
        Input.R3: [JoyButton(9)],
        Input.LEFT_STICK_X: [JoyAxis(0)],
        Input.LEFT_STICK_Y: [JoyAxis(1)],
        Input.RIGHT_STICK_X: [JoyAxis(4)],
        Input.RIGHT_STICK_Y: [JoyAxis(3)],
        Input.L2: [JoyAxis(2)],
        Input.R2: [JoyAxis(5)],
        Input.DPAD_LEFT: [JoyHat(0, 0, -1)],
        Input.DPAD_RIGHT: [JoyHat(0, 0, 1)],
        Input.DPAD_UP: [JoyHat(0, 1, 1)],
        Input.DPAD_DOWN: [JoyHat(0, 1, -1)],
    },
)

PLAYSTATION_PROFILE = ControllerProfile(
    name="PlayStation Controller",
    check=lambda js: any(
        k in js.get_name().lower()
        for k in ("playstation", "dualshock", "dualsense", "ps4", "ps5")
    ),
    mapping={
        Input.A: [JoyButton(1)],  # Cross
        Input.B: [JoyButton(2)],  # Circle
        Input.X: [JoyButton(0)],  # Square
        Input.Y: [JoyButton(3)],  # Triangle
        Input.L1: [JoyButton(4)],
        Input.R1: [JoyButton(5)],
        Input.SELECT: [JoyButton(8)],
        Input.START: [JoyButton(9)],
        Input.L3: [JoyButton(10)],
        Input.R3: [JoyButton(11)],
        Input.LEFT_STICK_X: [JoyAxis(0)],
        Input.LEFT_STICK_Y: [JoyAxis(1)],
        Input.RIGHT_STICK_X: [JoyAxis(2)],
        Input.RIGHT_STICK_Y: [JoyAxis(5)],
        Input.L2: [JoyAxis(3)],
        Input.R2: [JoyAxis(4)],
        Input.DPAD_LEFT: [JoyHat(0, 0, -1)],
        Input.DPAD_RIGHT: [JoyHat(0, 0, 1)],
        Input.DPAD_UP: [JoyHat(0, 1, 1)],
        Input.DPAD_DOWN: [JoyHat(0, 1, -1)],
    },
)

RETROID5_PROFILE = ControllerProfile(
    name="Retroid Pocket Controller",
    check=lambda js: "retroid" in js.get_name().lower(),
    mapping={
        Input.A: [JoyButton(0)],
        Input.B: [JoyButton(1)],
        Input.X: [JoyButton(2)],
        Input.Y: [JoyButton(3)],
        Input.L1: [JoyButton(9)],
        Input.R1: [JoyButton(10)],
        Input.SELECT: [JoyButton(4)],
        Input.START: [JoyButton(6)],
        Input.L3: [JoyButton(7)],
        Input.R3: [JoyButton(8)],
        Input.LEFT_STICK_X: [JoyAxis(0)],
        Input.LEFT_STICK_Y: [JoyAxis(1)],
        Input.RIGHT_STICK_X: [JoyAxis(4)],
        Input.RIGHT_STICK_Y: [JoyAxis(3)],
        Input.L2: [JoyButton(15)],
        Input.R2: [JoyButton(16)],
        Input.DPAD_LEFT: [JoyButton(13)],
        Input.DPAD_RIGHT: [JoyButton(14)],
        Input.DPAD_UP: [JoyButton(11)],
        Input.DPAD_DOWN: [JoyButton(12)],
    },
)
