from enum import Enum


class Player(Enum):
    P0 = 0
    P1 = 1
    P2 = 2
    P3 = 3
    P4 = 4
