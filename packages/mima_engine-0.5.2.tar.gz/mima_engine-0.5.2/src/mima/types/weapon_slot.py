from enum import Enum


class WeaponSlot(Enum):
    FIRST_HAND = 0
    SECOND_HAND = 1
