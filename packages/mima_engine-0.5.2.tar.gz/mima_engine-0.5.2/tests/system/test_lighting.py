import logging

import pygame

from mima.standalone.light import CRYSTAL_RUNE, LANTERN, MAGIC_LAMP, TORCH, Light
from mima.standalone.spatial import SpatialGrid
from mima.standalone.transformed_view import TileTransformedView

FORMAT = (
    '{"time": "%(asctime)s", "level":"%(levelname)s", "message"="%(message)s"'
    '"logger":"%(name)s", "lineno":"%(lineno)s"'
)
logging.basicConfig(filename="mima.log", level=logging.DEBUG, format=FORMAT)

SIZE = 1920, 1080

# Pygame stuff
pygame.init()
pygame.font.init()
my_font = pygame.font.SysFont("Nimbus Sans", 20)
screen = pygame.display.set_mode(SIZE)
clock = pygame.time.Clock()

# Game specific stuff
tv = TileTransformedView(screen, pygame.Vector2(800, 800), pygame.Vector2(16, 16))
# tv.set_pos(pygame.Vector2(400, 100))
lights = SpatialGrid[Light](pygame.Vector2(30, 30), 3)

torch_light = Light(pygame.Vector2(10.0, 10.0), 1.0, preset=TORCH)
torch_light2 = Light(pygame.Vector2(15.0, 5.0), 3.0, preset=TORCH)
torch_light3 = Light(pygame.Vector2(5.0, 15.0), 2.0, preset=TORCH)
lantern1 = Light(pygame.Vector2(5.0, 5.0), 2.0, preset=LANTERN)
magic_lamp=Light(pygame.Vector2(15.0,15.0), 6.0, preset=MAGIC_LAMP)
crystal=Light(pygame.Vector2(20.0,25.0), 6.0, preset=CRYSTAL_RUNE)
lights.insert(torch_light, torch_light.get_pos(), torch_light.get_area())
lights.insert(torch_light2, torch_light2.get_pos(), torch_light2.get_area())
lights.insert(torch_light3, torch_light3.get_pos(), torch_light3.get_area())
lights.insert(lantern1, lantern1.get_pos(), lantern1.get_area())
lights.insert(magic_lamp, magic_lamp.get_pos(), magic_lamp.get_area())
lights.insert(crystal, crystal.get_pos(), crystal.get_area())

# Game loop stuff
running = True
frame_ctr = 0
frame_time = 0.0
fps = 1
while running:
    elapsed_time = clock.tick() / 1000.0

    events = []
    for e in pygame.event.get():
        if e.type == pygame.QUIT:
            running = False
        else:
            events.append(e)
        if e.type == pygame.KEYDOWN:
            if e.key == pygame.K_ESCAPE:
                running = False

    for obj in lights.get_all_objects():
        obj.update(elapsed_time)

    screen.fill((255, 255, 255))
    tv.begin_lighting((40, 40, 40))

    for obj in lights.get_all_objects():
        tv.draw_light(obj)
    tv.end_lighting()

    pygame.display.flip()

    frame_ctr += 1
    frame_time += elapsed_time
    if frame_time >= 1.0:
        fps = frame_ctr
        frame_ctr = 0
        frame_time -= 1.0
        pygame.display.set_caption(f"FPS: {fps}")

pygame.font.quit()
pygame.quit()
