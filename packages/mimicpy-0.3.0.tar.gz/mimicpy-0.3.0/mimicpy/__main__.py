#!/usr/bin/env python

#
#    MiMiCPy: Python Based Tools for MiMiC
#    Copyright (C) 2020-2023 Bharath Raghavan,
#                            Florian Schackert
#                            Sachin Shivakumar
#
#    This file is part of MiMiCPy.
#
#    MiMiCPy is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Lesser General Public License as
#    published by the Free Software Foundation, either version 3 of
#    the License, or (at your option) any later version.
#
#    MiMiCPy is distributed in the hope that it will be useful, but
#    WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#    GNU Lesser General Public License for more details.
#
#    You should have received a copy of the GNU Lesser General Public License
#    along with this program. If not, see <http://www.gnu.org/licenses/>.
#

import sys
from os.path import isfile
import time
import argparse
import readline
import warnings
import itertools
import threading
import pandas as pd
import mimicpy
from mimicpy.force_matching import (
    get_configurations,
    get_optimize_ff_parameters,
    get_configurations_optff,
    opt_dresp,
    compute_sd,
    QMRegion
)
from mimicpy.scripts.fmdata import FMDataset
from mimicpy.scripts.fm_input import FMInput
from mimicpy.force_matching.opt_ff import (
    unified_optimization_ff,
    compare_optimization_methods
)
from mimicpy.force_matching.compare_top import compare_qm_parameters
from pathlib import Path
import logging
from datetime import datetime
import subprocess
import shutil
from os import environ
import copy
import numpy as np

warnings.simplefilter(action='ignore', category=FutureWarning)  # Supress pandas warnings


class Loader:

    def __init__(self, message):

        self.done = False
        self.message = message
        t = threading.Thread(target=self.__animate)
        t.start()

    def __animate(self):
        for c in itertools.cycle(['|', '/', '-', '\\']):
            if self.done:
                break
            sys.stdout.write('\r{}  '.format(self.message) + c)
            sys.stdout.flush()
            time.sleep(0.1)

    def close(self, halt=False):
        self.done = True
        if not halt:
            print('Done')

# TODO: Unify the three helper functions
def __str2bool(string):
    if isinstance(string, bool):
        return string
    if string.lower() in ('yes', 'true', 't', 'y', '1'):
        return True
    if string.lower() in ('no', 'false', 'f', 'n', '0'):
        return False
    else:
        print('Error! boolean value expected for argument\n')
        sys.exit(1)

def __str2float(v):
    if v is not None:
        try:
            return float(v)
        except:
            print('Error! float value expected for argument\n')
            sys.exit(1)
    else:
        return 0.0

def __str2int(v):
    try:
        return int(v)
    except:
        print('Error! integer value expected for argument\n')
        sys.exit(1)

def prepqm(args):

    def selection_help():
        print("\nvalid subcommands:\n\n"
              "    o add       <selection>    add selected atoms to QM region\n"
              "    o add-bound  <selection>    add selected atoms to QM region as boundary atoms\n"
              "    o delete    <selection>    delete selected atoms from QM region\n"
              "    o clear                    clear all atoms from QM region\n"
              "    o view      <file-name>    print current QM region to console or file\n"
              "    o quit                     create CPMD input and GROMACS index files and quit\n"
              "    o help                     show this help message\n\n"
              "For more information on the selection language please refer to the docs.\n")

    def view(file_name=None):
        if prep.qm_atoms.empty:
            print("No QM atoms have been selected")
        else:
            # display whole dataframe
            with pd.option_context('display.max_rows', None, 'display.max_columns', None):
                qmatoms_str = str(prep.qm_atoms)

            if file_name:
                mimicpy.utils.file_handler.write(qmatoms_str, file_name)
                print("Wrote list of QM atoms to {}".format(file_name))
            else:
                print(qmatoms_str)

    mpt = get_nsa_mpt(args)

    print('')
    loader = Loader('**Reading coordinates**')

    try:
        selector = mimicpy.DefaultSelector(mpt, args.coords, buffer=args.bufc)
        prep = mimicpy.Preparation(selector)
    except FileNotFoundError as e:
        print('\n\nError: Cannot find file {}! Exiting..\n'.format(e.filename))
        loader.close(halt=True)
        sys.exit(1)
    except (mimicpy.utils.errors.ParserError, mimicpy.utils.errors.MiMiCPyError) as e:
        print(e)
        loader.close(halt=True)
        sys.exit(1)
    except KeyboardInterrupt:
        print("Reading halted\n")
        loader.close(halt=True)
        sys.exit(1)

    loader.close()

    readline.parse_and_bind('set editing-mode vi') # handle command history

    dispatch = {'add':prep.add,
                'add-bound': lambda selection: prep.add(selection, True),
                'delete':prep.delete,
                'clear': prep.clear,
                'view':view,
                'help':selection_help}

    def check_user_input(user_input):
        user_input = user_input.split()
        try:
            command = user_input[0].lower()
        except IndexError: # handle empty commands
            return False

        selection = ' '.join(user_input[1:])
        try:
            dispatch[command](selection)
        except mimicpy.utils.errors.SelectionError as e:  # Selection errors
            print(e)
        except TypeError:  # include functions without argument
            dispatch[command]()
        except KeyError: # invalid commands
            print("{} is an invalid command! Please try again. Type 'help' for more information.".format(command))

    def do_prep():
        try:
            if not prep.qm_atoms.empty:
                if args.bound:
                    prep.find_bound_atoms()

                prep.get_mimic_input(args.inp, args.ndx, args.out,
                                     args.pad, args.abs, args.qma,
                                     args.path, args.q, args.pp)

                if args.mdp:
                    print("Checking that {} is consistent with a MiMiC run".format(args.mdp))
                    new_mdp = "fixed_{}".format(args.mdp)
                    prepmm(mdp=args.mdp, qma=args.qma, out=new_mdp)

                    if isfile(new_mdp):
                        mdp = new_mdp
                    else:
                        mdp = args.mdp

                    print("\nGenerating GROMACS TPR file using {} grompp\n".format(args.gmx))
                    import subprocess
                    subprocess.Popen("{} grompp -f {} -c {} -p {} -n {} -o {} -quiet".format(args.gmx, mdp,
                                                                                                            args.coords, args.top,
                                                                                                            args.ndx, args.tpr),
                                                                                                            stdout=subprocess.PIPE, shell=True).stdout.read()
                else:
                    print("MDP file not passed! Skipping generation of GROMACS TPR file")
        except (mimicpy.utils.errors.SelectionError, mimicpy.utils.errors.MiMiCPyError) as error:
            print(error)
            sys.exit()

    if args.sele:
        print("Reading selection from {}".format(args.sele))

        if not isfile(args.sele):
            print("Error: Cannot find file {}! Exiting..\n".format(args.sele))
            sys.exit(1)
        else:
            sele_txt =  mimicpy.utils.file_handler.read(args.sele)

        for line in sele_txt.splitlines():
            if check_user_input(line) == False:
                continue

        do_prep()
    else:
        print("\nPlease enter selection below. For more information type 'help'")

    while not args.sele:
        try:
            user_input = input('> ')
        except KeyboardInterrupt:
            print("Exiting without writing\n")
            sys.exit()

        if user_input.strip() in ['quit', 'q']:
            do_prep()
            break

        if check_user_input(user_input) == False:
            continue

def prepmm(mdp, qma, out):
    try:
        mimicpy.Preparation.get_gmx_input(mdp, qma, out)
    except FileNotFoundError as e:
        print('\n\nError: Cannot find file {}! Exiting..\n'.format(e.filename))
        sys.exit(1)
    except mimicpy.utils.errors.ScriptError as e:
        print(e)
        sys.exit(1)
        
def get_nsa_mpt(args, only_nsa=False):
    nsa_dct = {}
    if args.nsa:
        if args.top.split('.')[-1] == 'mpt':
            print("Non-standard atomtype file ignored as .mpt file was passed")
        else:
            print("\n**Reading non-standard atomtypes file**\n")

            if not isfile(args.nsa):
                print("Error: Cannot find file {}! Exiting..\n".format(args.nsa))
                sys.exit(1)
            else:
                nsa_txt =  mimicpy.utils.file_handler.read(args.nsa)
                for i, line in enumerate(nsa_txt.splitlines()):
                    splt = line.split()
                    if len(splt) < 2:
                        print("Line {} in {} is not in 2-column format!\n".format(i+1, args.nsa))
                        sys.exit(1)
                    elif len(splt) > 2:
                        print("Line {} in {} has more than 2-columns. \
                              Using first two values only.\n".format(i+1, args.nsa))

                    nsa_dct[splt[0]] = splt[1]

    if nsa_dct != {}:
        print("The following atomypes were read from {}:\n".format(args.nsa))
        mimicpy.utils.strings.print_dict(nsa_dct, "Atom Type", "Element", print)

    if only_nsa:
        return nsa_dct

    print("\n**Reading topology**\n")
    try:
        return mimicpy.Mpt.from_file(args.top, mode='r', nonstandard_atomtypes=nsa_dct,
                                buffer=args.buf, gmxdata=args.ff, guess_elements=args.guess)
    except FileNotFoundError as e:
        print('\n\nError: Cannot find file {}! Exiting..\n'.format(e.filename))
        sys.exit(1)
    except mimicpy.utils.errors.ParserError as e:
        print(e)
        sys.exit(1)

def getmpt(args):
    get_nsa_mpt(args).write(args.mpt)

def cpmdid(args):
    
    def print_idx(data, printer=print):
        if args.print == 'table':
            mimicpy.utils.strings.print_table(data, printer, new_line=(False if printer==print else True))
            return
        elif args.print == 'list':
            col_len = 5
            space_len = 6
            indices = data['CPMD ID']
            max_len = len(str(max(indices))) + 1
            spaces = space_len if max_len <= space_len else max_len
            txt = "No. of atoms: {}\n".format(len(indices))
            for i, idx in enumerate(indices):
                if i%col_len == 0:
                    txt += '\n'
                txt += "{:{}}".format(idx, spaces)
        elif args.print == 'range':
            indices = [int(i) for i in data['CPMD ID']]
            indices.sort()
            txt = ''
            for i, j in itertools.groupby(enumerate(indices), lambda x: x[1] - x[0]): 
                j = list(j)
                if j[0][0] != 0: txt += '\n'
                txt += "{} to {}".format(j[0][1], j[-1][1]) if j[0][1]!=j[-1][1] else str(j[0][1])
        printer(txt)
    
    args.print = args.print.lower()
    if args.print not in ['table', 'list', 'range']:
        print('\nError: Invalid option for -print. Only table, list, range accepted! Exiting..\n')
        sys.exit(1)
    
    try:
        cpmd = mimicpy.CpmdScript.from_file(args.inp)
        print("\n**Reading topology**\n")
        top = mimicpy.Top(args.top, buffer=args.buf, gmxdata=args.ff)
        id_conversion_dict = cpmd.gmx_to_cpmd_idx(top)
        mpt = mimicpy.Mpt.from_top(top)
    except mimicpy.utils.errors.ParserError as e:
        print(e)
        sys.exit(1)
    except FileNotFoundError as e:
        print('\n\nError: Cannot find file {}! Exiting..\n'.format(e.filename))
        sys.exit(1)
        
    readline.parse_and_bind('set editing-mode vi') # handle command history
    
    if args.sele:
        print("Reading selection from {}".format(args.sele))

        if not isfile(args.sele):
            print("Error: Cannot find file {}! Exiting..\n".format(args.sele))
            sys.exit(1)
        else:
            sele_txt =  mimicpy.utils.file_handler.read(args.sele)

    else:
        print("\nPlease enter selection below. Type q or quit to exit.")
    
        sele_txt = ''
    
        while not args.sele:
            try:
                user_input = input('> ')
            except KeyboardInterrupt:
                print("Exiting\n")
                sys.exit()
                
            user_input = user_input.strip()
            
            if user_input in ['quit', 'q']: break
            
            try:
                mpt.select(user_input)
            except (mimicpy.utils.errors.SelectionError, mimicpy.utils.errors.MiMiCPyError) as error:
                print(error)
                continue
                
            sele_txt += user_input + '\n'
    
    data = {'Atom': [], 'Residue': [], 'CPMD ID': []}
    
    for line in sele_txt.splitlines():
        try:
            sele = mpt.select(line)
        except (mimicpy.utils.errors.SelectionError, mimicpy.utils.errors.MiMiCPyError) as error:
            print(error)
            return None
            
        cpmd_idx = []
        for i in sele.index:
            cpmd_idx.append(str(id_conversion_dict[i]))
        
        mini_data = {'Atom': ["{} {}".format(a,b) for a,b in zip(sele.index, sele['name'])],\
                'Residue': ["{} {}".format(a,b) for a,b in zip(sele['resid'], sele['resname'])], 'CPMD ID': cpmd_idx}
        
        data['Atom'] += mini_data['Atom']
        data['Residue'] += mini_data['Residue']
        data['CPMD ID'] += mini_data['CPMD ID']
    
    if not args.out:
        print("\nThe CPMD IDs for the selected atoms are:\n")
        print_idx(data)
    elif args.out and data:
        print("\n**Writing table of selected atoms**\n")
        try:
            with open(args.out, 'w') as f:
                print_idx(data, f.write)
        except FileNotFoundError as e:
            print('\n\nError: Cannot find file {}! Exiting..\n'.format(e.filename))
            sys.exit(1)
        except FileExistsError as e:
            print(e)
            sys.exit(1)

def cpmd2coords(args):
    mpt = get_nsa_mpt(args)
    try:
        cpmd = mimicpy.CpmdScript.from_file(args.inp)
    except mimicpy.utils.errors.ParserError as e:
        print(e)
        sys.exit(1)
    except FileNotFoundError as e:
        print('\n\nError: Cannot find file {}! Exiting..\n'.format(e.filename))
        sys.exit(1)

    print('')
    loader = Loader('**Writing coordinates**')

    try:
        cpmd.to_coords(mpt, args.coords, title='Coordinates from {}'.format(args.inp))
    except mimicpy.utils.errors.MiMiCPyError as e:
        print(e)
        loader.close(halt=True)
        sys.exit(1)

    loader.close()
    
def geom2coords(args):
    try:
        cpmd = mimicpy.CpmdScript.from_file(args.inp)
        print("\n**Reading topology**\n")
        top = mimicpy.Top(args.top, buffer=args.buf, gmxdata=args.ff)
        id_conversion_dict = cpmd.gmx_to_cpmd_idx(top)
        mpt = mimicpy.Mpt.from_top(top)
    except mimicpy.utils.errors.ParserError as e:
        print(e)
        sys.exit(1)
    except FileNotFoundError as e:
        print('\n\nError: Cannot find file {}! Exiting..\n'.format(e.filename))
        sys.exit(1)
    
    ext = 'cpmd geo'
    if args.geom.split()[-1].lower() == 'xyz':
        ext = 'xyz'
    
    print('')
    loader = Loader('**Reading CPMD Geometry**')
    
    try:
        geom = mimicpy.CoordsIO(args.geom, ext=ext, cpmd=cpmd, top=top)
    except mimicpy.utils.errors.MiMiCPyError as e:
        print(e)
        loader.close(halt=True)
        sys.exit(1)
        
    loader.close()
    
    print('')
    loader = Loader('**Writing coordinates**')
    
    try:
        mimicpy.CoordsIO(args.coords, mode='w').write(mpt.select('all'), geom.coords)
    except mimicpy.utils.errors.MiMiCPyError as e:
        print(e)
        loader.close(halt=True)
        sys.exit(1)

    loader.close()

def json2h5(args):
    """
    Convert large JSON Force Matching data files to HDF5 format using FMDataset functionality.
    
    Args:
        args: Command line arguments containing input/output file paths
    """
    from pathlib import Path
    import os
    
    input_file = Path(args.i)
    output_file = Path(args.o) if args.o else input_file.with_suffix('.h5')
    
    if not input_file.exists():
        print(f'\n\nError: Cannot find file {input_file}! Exiting..\n')
        sys.exit(1)
    
    print('')
    loader = Loader('**Converting JSON to HDF5**')
    
    try:
        # Use the existing FMDataset functionality to convert JSON to HDF5
        fm_dataset = FMDataset(input_file, output_file)
        
        loader.close()
           
    except Exception as e:
        loader.close(halt=True)
        print(f'\n\nError during conversion: {e}')
        sys.exit(1)
    # Calculate file sizes for comparison
    input_size = input_file.stat().st_size / (1024 * 1024)  # MB
    output_size = output_file.stat().st_size / (1024 * 1024)  # MB
    compression_ratio = (1 - output_size / input_size) * 100 if input_size > 0 else 0
    
    
    print(f'\nConversion completed successfully!')
    print(f'Input file:  {input_file} ({input_size:.2f} MB)')
    print(f'Output file: {output_file} ({output_size:.2f} MB)')
    print(f'Compression: {compression_ratio:.1f}% reduction')
    print(f'Configurations: {len(fm_dataset)}')

def h5info(args):
    """
    Display information about HDF5 Force Matching data files.
    
    Args:
        args: Command line arguments containing input file path
    """
    import h5py
    import numpy as np
    from pathlib import Path
    
    input_file = Path(args.i)
    
    if not input_file.exists():
        print(f'\n\nError: Cannot find file {input_file}! Exiting..\n')
        sys.exit(1)
    
    print('')
    loader = Loader('**Reading HDF5 file**')
    
    try:
        # Read the HDF5 file
        with h5py.File(input_file, 'r') as f:
            config_keys = [key for key in f.keys() if key.startswith('config_')]
            config_keys.sort(key=lambda x: int(x.split('_')[1]))  # Sort by configuration number
            
            if not config_keys:
                print('\n\nError: No configuration data found in HDF5 file! Exiting..\n')
                sys.exit(1)
            
            loader.close()
            
            # Get file size
            file_size = input_file.stat().st_size / (1024 * 1024)  # MB
            
            print(f'\nHDF5 File Information:')
            print(f'File: {input_file}')
            print(f'Size: {file_size:.2f} MB')
            print(f'Configurations: {len(config_keys)}')
            
            # Show details for first few configurations
            print(f'\nConfiguration Details:')
            for i, config_key in enumerate(config_keys[:min(5, len(config_keys))]):
                config_group = f[config_key]
                atoms_data = config_group['atoms']
                n_atoms = len(atoms_data)
                
                # Get some statistics
                regions = atoms_data['region'][:]
                qm_atoms = np.sum(regions == 1)
                mm_atoms = np.sum(regions != 1)
                
                print(f'  {config_key}: {n_atoms} atoms ({qm_atoms} QM, {mm_atoms} MM)')
            
            if len(config_keys) > 5:
                print(f'  ... and {len(config_keys) - 5} more configurations')
            
            # Show dataset structure
            print(f'\nDataset Structure:')
            first_config = f[config_keys[0]]
            atoms_data = first_config['atoms']
            
            print(f'  Atom data fields:')
            for field in atoms_data.dtype.names:
                field_dtype = atoms_data.dtype[field]
                print(f'    - {field}: {field_dtype}')
            
            # Show compression info if available
            if hasattr(atoms_data, 'compression') and atoms_data.compression:
                print(f'\nCompression: {atoms_data.compression}')
            else:
                print(f'\nCompression: None')
        
    except Exception as e:
        loader.close(halt=True)
        print(f'\n\nError reading HDF5 file: {e}')
        sys.exit(1)

def fixtop(args):
    nsa_dct = get_nsa_mpt(args, True)
    print("\n**Reading topology**\n")
    try:
        top = mimicpy.Top(args.top, buffer=args.buf, nonstandard_atomtypes=nsa_dct,
                        gmxdata=args.ff, guess_elements=args.guess)
    except FileNotFoundError as e:
        print('\n\nError: Cannot find file {}! Exiting..\n'.format(e.filename))
        sys.exit(1)
    except mimicpy.utils.errors.ParserError as e:
        print(e)
        sys.exit(1)
    print("\n**Writing fixed [ atomtypes ] section**\n")

    try:
        top.write_atomtypes(args.out, delete_atomtypes=args.cls)
    except FileNotFoundError as e:
        print('\n\nError: Cannot find file {}! Exiting..\n'.format(e.filename))
        sys.exit(1)
    except FileExistsError as e:
        print(e)
        sys.exit(1)
    return top

def compare_top(args):
    """Command-line interface for comparing QM parameters between topologies"""
    compare_qm_parameters(args.top1, args.top2, args.top3, args.coords, Path(args.sele))

def qminfo(args):
    """Print information about QM atoms in the QM region"""
    print('')
    loader = Loader('**Reading topology and coordinates**')
    
    try:
        # Initialize QMRegion
        qm_region = QMRegion(args.top, args.coords, gmxdata=args.ff, 
                            buffer=args.buf, guess_elements=args.guess,
                            nonstandard_atomtypes=get_nsa_mpt(args, only_nsa=True) if args.nsa else None)
        
        # Setup QM region with selection file and solvent names
        qm_region.setup_qm_region(Path(args.sele))
        
        loader.close()

        # Get output file if specified
        output_file = getattr(args, 'out', None)
        
        # Format output
        output_lines = []
        output_lines.append("=" * 80)
        output_lines.append("QM Region Information")
        output_lines.append("=" * 80)
        output_lines.append(f"\nTotal number of QM atoms: {len(qm_region.qm_atoms)}")
        output_lines.append(f"QM total charge: {qm_region.qm_total_charge:.6f}")
        
        # Count boundary atoms if present
        if not qm_region.boundary_atoms.empty:
            output_lines.append(f"Number of boundary atoms: {len(qm_region.boundary_atoms)}")
            output_lines.append(f"Number of core QM atoms: {len(qm_region.qm_atoms) - len(qm_region.boundary_atoms)}")
        
        # Count by molecule type
        if 'mol' in qm_region.qm_atoms.columns:
            mol_counts = qm_region.qm_atoms.groupby('mol').size()
            output_lines.append(f"Number of molecule types: {len(mol_counts)}")
            output_lines.append("\nAtoms per molecule type:")
            for mol, count in mol_counts.items():
                output_lines.append(f"  {mol}: {count} atoms")
        
        # Print detailed atom table
        output_lines.append("\n" + "=" * 80)
        output_lines.append("Detailed QM Atom Information")
        output_lines.append("=" * 80)
        
        # Create formatted table
        with pd.option_context('display.max_rows', None, 'display.max_columns', None, 
                              'display.width', None, 'display.max_colwidth', None):
            # Select columns to display (only include columns that exist)
            display_cols = ['type', 'resid', 'resname', 'name', 'charge', 'mass']
            available_cols = qm_region.qm_atoms.columns.tolist()
            if 'element' in available_cols:
                display_cols.insert(1, 'element')
            if 'mol' in available_cols:
                display_cols.append('mol')
            if 'is_bound' in available_cols:
                display_cols.append('is_bound')
            
            # Filter to only include columns that actually exist
            display_cols = [col for col in display_cols if col in available_cols]
            
            # Create display dataframe with index as first column
            display_df = qm_region.qm_atoms[display_cols].copy()
            display_df.insert(0, 'atom_id', display_df.index)
            
            # Format the table
            table_str = str(display_df)
            output_lines.append("\n" + table_str)
        
        # Print boundary atoms separately if present
        if not qm_region.boundary_atoms.empty:
            output_lines.append("\n" + "=" * 80)
            output_lines.append("Boundary Atoms")
            output_lines.append("=" * 80)
            # Filter display_cols to only include columns that exist in boundary_atoms
            boundary_display_cols = [col for col in display_cols if col in qm_region.boundary_atoms.columns]
            boundary_display = qm_region.boundary_atoms[boundary_display_cols].copy()
            boundary_display.insert(0, 'atom_id', boundary_display.index)
            with pd.option_context('display.max_rows', None, 'display.max_columns', None):
                output_lines.append("\n" + str(boundary_display))
        
        # Print interactions summary if available
        if hasattr(qm_region, 'qm_interactions') and qm_region.qm_interactions:
            output_lines.append("\n" + "=" * 80)
            output_lines.append("QM Interactions Summary")
            output_lines.append("=" * 80)
            output_lines.append(f"Bonds: {len(qm_region.qm_interactions.get('bonds', []))}")
            output_lines.append(f"Angles: {len(qm_region.qm_interactions.get('angles', []))}")
            output_lines.append(f"Dihedrals: {len(qm_region.qm_interactions.get('dihedrals', []))}")
        
        # Write or print output
        output_text = '\n'.join(output_lines)
        
        if output_file:
            try:
                with open(output_file, 'w') as f:
                    f.write(output_text)
                print(f"\nQM region information written to {output_file}")
            except Exception as e:
                print(f"\nError writing to file {output_file}: {e}")
                print(output_text)
        else:
            print(output_text)
            
    except FileNotFoundError as e:
        print(f'\n\nError: Cannot find file {e.filename}! Exiting..\n')
        loader.close(halt=True)
        sys.exit(1)
    except (mimicpy.utils.errors.ParserError, mimicpy.utils.errors.MiMiCPyError, mimicpy.utils.errors.SelectionError) as e:
        print(f'\n\nError: {e}\n')
        loader.close(halt=True)
        sys.exit(1)
    except KeyboardInterrupt:
        print("\nReading halted\n")
        loader.close(halt=True)
        sys.exit(1)


def fm(args):
    """
    Execute the force matching workflow.
    
    Args:
        args: Command line arguments containing force matching parameters
    """
    log_file = 'fm.log'
    file_handler = logging.FileHandler(log_file)
    file_handler.setLevel(logging.DEBUG)
    logging.getLogger().addHandler(file_handler)

    start_time = datetime.now()
    logging.info(f'Running Force matching in MiMiCPy {datetime.now()}')
   
    # Read the FM data
    fm_file = Path(args.fmdata)
    if not fm_file.exists():
        raise FileNotFoundError(f'FM file {fm_file} not found.')
    
    flag = 'dresp' if args.dresp else 'opt_ff' if args.opt_ff else 'fm'

    
    logging.info(f'Loading FM data from {fm_file}')
    fmdata = FMDataset(fm_file)
    logging.debug('FM data loaded successfully.')
    
    # Read the fm input using the new FMInput class
    fm_input = FMInput.from_file(args.fi)
    
    # Get solvent names from fm_input
    solvent_names = {'resnames': fm_input.solvent_resnames, 'molecules': fm_input.solvent_molecules}
    
    # Initialize QMRegion
    qm_region = QMRegion(args.top, args.coords, gmxdata=args.ff)
    qm_region.setup_qm_region(Path(args.sele), solvent_names)
    
    # Parse ITP file and get equivalent mapping
    if fm_input.eq_atoms == 'use_atomtypes':
        eq_map = qm_region.get_equivalent_map(use_atomtypes=True)
    else:
        eq_map = qm_region.get_equivalent_map(fm_input.eq_atoms)
    
    logging.info(f'Stride: {fm_input.stride}')
    logging.info(f'Equivalent atoms in gmx index: {fm_input.eq_atoms}')
    logging.info(f'Reference charges: {fm_input.reference_charges}')
    logging.info(f'Number of snapshots used for fitting: {len(range(fm_input.stride[0], fm_input.stride[1], fm_input.stride[2]))}')
    
    if fm_input.skip_solvent_optimization:
        logging.info('Skipping solvent optimization')
        fixed_charge_indices = set(qm_region.solvent_atom_indices)
    else:
        fixed_charge_indices = None
    
    charge_group_constraints = None
    if fm_input.charge_group_constraints:
        logging.info('Creating charge group constraints')
        charge_group_constraints = qm_region.create_charge_group_constraints(group_by='mol')
        for group_key, (atom_indices, target_charge) in charge_group_constraints.items():
            logging.info(f'Charge group {group_key} with {len(atom_indices)} atoms: target charge = {target_charge:.6f}')
        # charge_group_constraints = list(charge_group_constraints.values())
    
    check_dresp = False
    # DRESP fitting
    if flag in ['fm', 'dresp']:
        if flag == 'dresp':
            logging.info('Selected only DRESP optimization')
        configurations = get_configurations(fmdata, fm_input.stride[0], fm_input.stride[1], fm_input.stride[2], qm_region)
        ff_charges = qm_region.qm_charges
        if fm_input.qm_total_charge is not None and fm_input.qm_total_charge != qm_region.qm_total_charge:
            logging.warning(f'QM total charge mismatch: {qm_region.qm_total_charge} != {fm_input.qm_total_charge}')
            logging.warning(f'Using user-defined total charge: {fm_input.qm_total_charge}')
            qm_region.qm_total_charge = fm_input.qm_total_charge
        logging.info(f'QM total charge: {qm_region.qm_total_charge}')
        ff_charges = np.array(list(map(float, ff_charges)))
        
        if fm_input.reference_charges == 'ff_charges':
            for config, index in zip(configurations, range(fm_input.stride[0], fm_input.stride[1], fm_input.stride[2])): 
                config['reference_charge'] = ff_charges

        # DRESP optimization
        logging.info('Running DRESP optimization')
        wv = fm_input.wv
        we = fm_input.we
        wh = fm_input.wh
        wq = fm_input.wq

        if args.grid_search:
            # Grid search mode
            wv_list = wv if isinstance(wv, list) else [wv]
            we_list = we if isinstance(we, list) else [we]
            wh_list = wh if isinstance(wh, list) else [wh]

            best_sdv = float('inf')
            best_params = None
            best_charges = None
            best_sd = None
            grid_results = []  # Store all results for output

            import itertools
            for wv_val, we_val, wh_val in itertools.product(wv_list, we_list, wh_list):
                logging.info(f"Trying DRESP with wv={wv_val}, we={we_val}, wh={wh_val}")
                charges = opt_dresp(configurations, wv_val, we_val, wh_val, wq, 
                                        qm_region.qm_total_charge, eq_map, args.n_processes,
                                        fixed_charge_indices, list(charge_group_constraints.values()), fm_input.weights_to_fix_charges)
                charges = qm_region.redistribute_charges_after_dresp(charges, fm_input.num_bonds_away, 
                                                            fixed_charge_indices, charge_group_constraints)
                sd = compute_sd(charges, configurations, args.n_processes)
                sdv = sd[0] + sd[1]
                logging.info(f"SDV for wv={wv_val}, we={we_val}, wh={wh_val}: {sdv}")
                grid_results.append({'wv': wv_val, 'we': we_val, 'wh': wh_val, 'sd_potential': sd[0], 'sd_field': sd[1], 'sdv': sdv, 'charges': charges})
                if sdv < best_sdv:
                    best_sdv = sdv
                    best_params = (wv_val, we_val, wh_val)
                    best_charges = charges
                    best_sd = sd

            # Output all grid search results to CSV for plotting
            import csv
            with open('dresp_grid_search_results.csv', 'w', newline='') as csvfile:
                fieldnames = ['wv', 'we', 'wh', 'sd_potential', 'sd_field', 'sdv', 'charges']
                writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
                writer.writeheader()
                for row in grid_results:
                    writer.writerow(row)

            # Use best parameters and charges for updating and writing topology
            wv, we, wh = best_params
            full_optimize_charges = best_charges
            sd = best_sd
            logging.info(f"Best DRESP parameters: wv={wv}, we={we}, wh={wh} with SDV={best_sdv}")
        else:
            # Single DRESP calculation (no grid search)
            wv_val = wv[0] if isinstance(wv, list) else wv
            we_val = we[0] if isinstance(we, list) else we
            wh_val = wh[0] if isinstance(wh, list) else wh
            charges = opt_dresp(configurations, wv_val, we_val, wh_val, wq, 
                                qm_region.qm_total_charge, eq_map, args.n_processes,
                                fixed_charge_indices, list(charge_group_constraints.values()), fm_input.weights_to_fix_charges)
            charges = qm_region.redistribute_charges_after_dresp(charges, fm_input.num_bonds_away, 
                                                        fixed_charge_indices, charge_group_constraints)
            sd = compute_sd(charges, configurations, args.n_processes)
            wv, we, wh = wv_val, we_val, wh_val
            full_optimize_charges = charges
            logging.info(f"Single DRESP run: wv={wv}, we={we}, wh={wh}")

        logging.info(f'DRESP optimized charges:')
        for i, charge in enumerate(full_optimize_charges):
            logging.info(f'{charge:10.6f}')
        logging.info(f'# Sum of the charges: {np.sum(full_optimize_charges):10.6f}')
        logging.info(f'# Standard deviations of potential: {sd[0]}')
        logging.info(f'# Standard deviations of electric field: {sd[1]}')

        qm_region.update_qm_charges(full_optimize_charges)

        logging.info(f'DRESP optimization completed.')

        if flag == 'dresp':
            try:
                logging.info(f'Writing DRESP topology.')
                qm_region.write_topology(prefix='resp_')
                logging.info(f'MiMiCPy Force matching workflow completed {datetime.now()}.')
                logging.info(f'wall time: {datetime.now() - start_time}')
            except Exception as e:
                logging.error(f'Failed to write DRESP topology: {str(e)}')
            return
        

        logging.info(f'Starting Non-bonded force calculation.\n')
        # Write non-bonded ITP file with prefixed name
        try:
            logging.info(f'Writing non-bonded topology.')
            qm_region.write_non_bonded_itp(prefix='non_bonded_')
        except Exception as e:
            logging.error(f'Failed to write non-bonded topology: {str(e)}')

    if not check_dresp:
        logging.info(f'Starting Non-bonded force calculation.\n')
        try:
            logging.info(f'Writing non-bonded topology.')
            qm_region.write_non_bonded_itp(prefix='non_bonded_')
            logging.info(f'Non-bonded topology written.')
        except Exception as e:
            logging.error(f'Failed to write non-bonded topology: {str(e)}')

    # Take the topology and prefix the name rerun
    rerun_top_file = Path(args.top).with_name('rerun_' + Path(args.top).name)
    shutil.copy(args.top, rerun_top_file)
    
    # Get the list of written .itp files from QMRegion
    written_itp_files = qm_region.written_files
    
    # Read the topology file content
    with open(rerun_top_file, 'r') as f:
        content = f.read()
    
    # Replace each .itp file reference with its non-bonded version
    for itp_file in written_itp_files:
        # Get the original name by removing the 'non_bonded_' prefix
        non_bonded_name = Path(itp_file).name
        original_name = non_bonded_name.replace('non_bonded_', '')
        # Replace both quoted and unquoted references
        content = content.replace(f'#include "{original_name}"', f'#include "{non_bonded_name}"')
        content = content.replace(f"#include '{original_name}'", f"#include '{non_bonded_name}'")
        content = content.replace(f"#include {original_name}", f"#include {non_bonded_name}")
    
    # Write the updated content back to the rerun topology file
    with open(rerun_top_file, 'w') as f:
        f.write(content)
    logging.info(f'Non-bonded topology written.')

    
    tpr_file = 'rerun_nonb.tpr'
    trr_file = 'rerun_nonb.trr'
    
    logging.info(f'Running Non-bonded force calculation.\n')
    # Generate tpr file
    try:
        cmd = f"{args.gmx} grompp -f {args.mdp} -c {args.coords} -p {rerun_top_file} -n {args.ndx} -o {tpr_file} -maxwarn 1 -quiet"
        logging.info(f"Running command: {cmd}")
        subprocess.run(cmd, shell=True, check=True)
        
        # Rerun the GROMACS trajectory
        nthreads = environ.get('OMP_NUM_THREADS', 1)

        cmd = f"{args.gmx} mdrun -s {tpr_file} -rerun {args.trr} -o {trr_file} -e rerun_nonb.edr -g rerun_nonb.log -ntomp {nthreads} -quiet"
        logging.info(f"Running command: {cmd}")
        subprocess.run(cmd, shell=True, check=True)

    except subprocess.CalledProcessError as e:
        print(f"Error running GROMACS command: {e}")
        sys.exit(1)
    
    logging.info(f'Non-bonded force calculation Completed.\n')
    logging.info(f'Running force field parameter optimization.')
    
    ff_optimize, bond2params, regularization = get_optimize_ff_parameters(
        qm_region, 
        eq_map,
        fm_input
    )
    
    configurations = get_configurations_optff(fmdata, tpr_file, trr_file, fm_input.stride[0], fm_input.stride[1], 
                                              fm_input.stride[2], qm_region)
    
    # Check if hierarchical optimization is requested
    if hasattr(args, 'compare_methods') and args.compare_methods:
        logging.info('Comparing all optimization methods...')
        results = compare_optimization_methods(
            qm_region, ff_optimize, configurations, bond2params, 
            'optimization_comparison', regularization, fm_input, args.n_processes
        )
        
        # Use the best method based on final cost
        best_method = None
        best_cost = float('inf')
        for method, result in results.items():
            if 'error' not in result and result['final_cost'] < best_cost:
                best_cost = result['final_cost']
                best_method = method
                ff_optimize = result['optimized_params']
        
        if best_method:
            logging.info(f'Best method: {best_method} with cost: {best_cost:.6f}')
        else:
            logging.error('All optimization methods failed')
            sys.exit(1)
            
    else:
        # Use the optimization method specified in fm_input
        logging.info(f'Using optimization method: {getattr(fm_input, "optimization_method", "hierarchical")}')
        
        # Pass n_processes to the optimization function
        logging.info(f'Using {args.n_processes} processes for parallel computation')
        
        # Optimize force field parameters using unified interface
        ff_optimize, res = unified_optimization_ff(
            qm_region, ff_optimize, configurations, bond2params, 
            'optimization_results.txt', regularization, fm_input, args.n_processes
        )
        
        if res:
            logging.info(f'Output from optimization: ')
            logging.info(f'        status: {getattr(res, "status", "N/A")} ')
            logging.info(f'        message: {getattr(res, "message", "N/A")} ')
            logging.info(f'        success: {getattr(res, "success", True)} ')
        else:
            logging.info('Optimization completed successfully')
    
    logging.info(f'Force field parameter optimization completed.')

    logging.info('Writing optimized force parameters to file.')
    qm_region.update_topology(ff_optimize, bond2params)
    qm_region.write_topology(prefix='opt_')
    logging.info(f'MiMiCPy Force matching workflow completed {datetime.now()}.')
    logging.info(f'wall time: {datetime.now() - start_time}')

def main():
    print('\n \t                ***** MiMiCPy *****                  ')
    print('\n \t                Running version {}\n\tFor more information type mimicpy [subcommand] --help \n'.format(mimicpy.__version__))

    parser = argparse.ArgumentParser(prog='mimicpy')
    subparsers = parser.add_subparsers(title='valid subcommands',
                                       metavar='')  # Turns off list of subcommands

    #####
    parser_prepqm = subparsers.add_parser('prepqm',
                                          help='create CPMD/MiMiC input and GROMACS index files')
    prepqm_input = parser_prepqm.add_argument_group('options to specify input')
    prepqm_input.add_argument('-top',
                              required=True,
                              help='topology file',
                              metavar='[.top]')
    prepqm_input.add_argument('-coords',
                              required=True,
                              help='coordinate file',
                              metavar='[.gro/.pdb]')
    prepqm_input.add_argument('-mdp',
                              required=False,
                              help='MDP script to generate GROMACS TPR file',
                              metavar='[.mdp]')
    prepqm_output = parser_prepqm.add_argument_group('options to specify output')
    prepqm_output.add_argument('-out',
                               default='cpmd.inp',
                               help='CPMD script for MiMiC run',
                               metavar='[.inp] (cpmd.inp)')
    prepqm_output.add_argument('-ndx',
                               default='index.ndx',
                               help='Gromacs index file',
                               metavar='[.ndx] (index.ndx)')
    prepqm_output.add_argument('-tpr',
                              required=False,
                              default='mimic.tpr',
                              help='Output GROMACS TPR filename',
                              metavar='[.tpr] (mimic.tpr)')
    prepqm_others = parser_prepqm.add_argument_group('other options')
    prepqm_others.add_argument('-guess',
                              required=False,
                              default=True,
                              type=__str2bool,
                              help='toggle guessing atomic elements',
                              metavar='(True)')
    prepqm_others.add_argument('-sele',
                              required=False,
                              help='file containing selection',
                              metavar='[.txt/.dat]')
    prepqm_others.add_argument('-pp',
                               required=False,
                               help='file containing pseudopotential information',
                               metavar='[.dat]')
    prepqm_others.add_argument('-bound',
                              required=False,
                              default=False,
                              type=__str2bool,
                              help='toggle guessing boundary atoms',
                              metavar='(False)')
    prepqm_others.add_argument('-nsa',
                              required=False,
                              help='file containing non-standard atomtypes in 2-column format',
                              metavar='[.txt/.dat]')
    prepqm_others.add_argument('-ff',
                              required=False,
                              help='path to force field data directory',
                              metavar='')
    prepqm_others.add_argument('-inp',
                              required=False,
                              help='CPMD template input script',
                              metavar='[.inp]')
    prepqm_others.add_argument('-gmx',
                              required=False,
                              default='gmx',
                              help='GROMACS executable to automatically generate TPR file',
                              metavar='(gmx)')
    prepqm_others.add_argument('-pad',
                              required=False,
                              type=__str2float,
                              default=0.0,
                              help='extra distance between qm atoms and wall in nm',
                              metavar='(0)')
    prepqm_others.add_argument('-abs',
                              required=False,
                              default=False,
                              type=__str2bool,
                              help='return QM cell size as absolute',
                              metavar='(False)')
    prepqm_others.add_argument('-qma',
                              required=False,
                              default='QMatoms',
                              help='name of QM atoms group in index file',
                              metavar='(QMatoms)')
    prepqm_others.add_argument('-path',
                              required=False,
                              help='path in the MIMIC section, overrides template',
                              metavar='')
    prepqm_others.add_argument('-q',
                              required=False,
                              type=__str2float,
                              help='charge of QM region, overrides default charge calculation',
                              metavar='')
    prepqm_others.add_argument('-buf',
                              required=False,
                              default=1000,
                              type=__str2int,
                              help='buffer size for reading input topology',
                              metavar='(1000)')
    prepqm_others.add_argument('-bufc',
                              required=False,
                              default=1000,
                              type=__str2int,
                              help='buffer size for reading input coordinates',
                              metavar='(1000)')
    parser_prepqm.set_defaults(func=prepqm)
    ##
    #####
    parser_cpmd2coords = subparsers.add_parser('cpmd2coords',
                                          help='convert CPMD/MiMiC input to coordinates')
    cpmd2coords_input = parser_cpmd2coords.add_argument_group('options to specify input')
    cpmd2coords_input.add_argument('-top',
                              required=True,
                              help='topology file',
                              metavar='[.top]')
    cpmd2coords_input.add_argument('-inp',
                              required=True,
                              help='CPMD input script with MIMIC/ATOMS sections',
                              metavar='[.inp]')
    cpmd2coords_output = parser_cpmd2coords.add_argument_group('options to specify output')
    cpmd2coords_output.add_argument('-coords',
                               default='mimic.gro',
                               help='coordinate file from CPMD/MIMIC script',
                               metavar='[.gro/.pdb] (mimic.gro)')
    cpmd2coords_others = parser_cpmd2coords.add_argument_group('other options')
    cpmd2coords_others.add_argument('-guess',
                              required=False,
                              default=True,
                              type=__str2bool,
                              help='toggle guessing atomic elements',
                              metavar='(True)')
    cpmd2coords_others.add_argument('-nsa',
                              required=False,
                              help='file containing list of non-standard atomtypes',
                              metavar='[.txt/.dat]')
    cpmd2coords_others.add_argument('-ff',
                              required=False,
                              help='path to force field data directory',
                              metavar='')
    cpmd2coords_others.add_argument('-buf',
                              required=False,
                              default=1000,
                              type=__str2int,
                              help='buffer size for reading input topology',
                              metavar='(1000)')
    parser_cpmd2coords.set_defaults(func=cpmd2coords)
    ##
    #####
    parser_fixtop = subparsers.add_parser('fixtop',
                                          help='fix [ atomtypes ] section of GROMACS topology')
    fixtop_input = parser_fixtop.add_argument_group('options to specify input files')
    fixtop_input.add_argument('-top',
                              required=True,
                              help='GROMACS topology file',
                              metavar='[.top]')
    fixtop_output = parser_fixtop.add_argument_group('options to specify output files')
    fixtop_output.add_argument('-out',
                               default='atomtypes.itp',
                               help='fixed .itp file',
                               metavar='[.itp] (atomtypes.itp)')
    fixtop_others = parser_fixtop.add_argument_group('other options')
    fixtop_others.add_argument('-guess',
                              required=False,
                              default=True,
                              help='toggle guessing atomic elements',
                              metavar='(True)')
    fixtop_others.add_argument('-nsa',
                              required=False,
                              help='file containing list of non-standard atomtypes',
                              metavar='[.txt/.dat]')
    fixtop_others.add_argument('-ff',
                              required=False,
                              help='path to force field data directory',
                              metavar='')
    fixtop_others.add_argument('-cls',
                              required=False,
                              default=None,
                              type=__str2bool,
                              help='toggle clear [ atomtypes ] sections from files',
                              metavar='(False)')
    fixtop_others.add_argument('-buf',
                              required=False,
                              default=1000,
                              type=__str2int,
                              help='buffer size for reading input topology',
                              metavar='(1000)')
    parser_fixtop.set_defaults(func=fixtop)
    ##
    #####
    parser_cpmdid = subparsers.add_parser('cpmdid',
                                          help='find the CPMD ID of a selection of atoms')
    cpmdid_input = parser_cpmdid.add_argument_group('options to specify input files')
    cpmdid_input.add_argument('-top',
                              required=True,
                              help='GROMACS topology file',
                              metavar='[.top]')
    cpmdid_input.add_argument('-inp',
                              required=False,
                              help='CPMD input script',
                              metavar='[.inp]')
    cpmdid_others = parser_cpmdid.add_argument_group('options to specify output files')
    cpmdid_others.add_argument('-sele',
                              required=False,
                              help='file containing selection',
                              metavar='[.txt/.dat]')
    cpmdid_others.add_argument('-print',
                              required=False,
                              default='table',
                              help='print CPMD IDs as table, list or range',
                              metavar='table/list/range')
    cpmdid_others.add_argument('-ff',
                              required=False,
                              help='path to force field data directory',
                              metavar='')
    cpmdid_others.add_argument('-buf',
                              required=False,
                              default=1000,
                              type=__str2int,
                              help='buffer size for reading input topology',
                              metavar='(1000)')
    cpmdid_output = parser_cpmdid.add_argument_group('options to specify output')
    cpmdid_output.add_argument('-out',
                               required=False,
                               help='file to write to output containing CPMD IDs',
                               metavar='[.txt]')
    parser_cpmdid.set_defaults(func=cpmdid)
    ##
    #####
    parser_geom2coords = subparsers.add_parser('geom2coords',
                                          help='convert a CPMD GEOMETRY (or a GEOMETRY.xyz) file to coordinates')
    geom2coords_input = parser_geom2coords.add_argument_group('options to specify input files')
    geom2coords_input.add_argument('-geom',
                              required=False,
                              help='CPMD GEOMETRY',
                              metavar='[GEOMETRY/GEOMETRY.xyz]')
    geom2coords_input.add_argument('-top',
                              required=True,
                              help='GROMACS topology file',
                              metavar='[.top]')
    geom2coords_input.add_argument('-inp',
                              required=False,
                              help='CPMD input script',
                              metavar='[.inp]')
    geom2coords_others = parser_geom2coords.add_argument_group('options to specify output files')
    geom2coords_others.add_argument('-ff',
                              required=False,
                              help='path to force field data directory',
                              metavar='')
    geom2coords_others.add_argument('-buf',
                              required=False,
                              default=1000,
                              type=__str2int,
                              help='buffer size for reading input topology',
                              metavar='(1000)')
    geom2coords_output = parser_geom2coords.add_argument_group('options to specify output')
    geom2coords_output.add_argument('-coords',
                               default='GEOMETRY.gro',
                               help='coordinate file from CPMD GEOMETRY',
                               metavar='[.gro/.pdb] (GEOMETRY.gro)')
    parser_geom2coords.set_defaults(func=geom2coords)
    ##
    #####
    parser_json2h5 = subparsers.add_parser('json2h5',
                                          help='convert large JSON Force Matching data files to HDF5 format')
    json2h5_input = parser_json2h5.add_argument_group('options to specify input files')
    json2h5_input.add_argument('-i',
                              required=True,
                              help='input JSON file containing Force Matching data',
                              metavar='[.json]')
    json2h5_output = parser_json2h5.add_argument_group('options to specify output files')
    json2h5_output.add_argument('-o',
                               required=False,
                               help='output HDF5 file (default: input file with .h5 extension)',
                               metavar='[.h5]')
    parser_json2h5.set_defaults(func=json2h5)
    ##
    #####
    parser_h5info = subparsers.add_parser('h5info',
                                         help='display information about HDF5 Force Matching data files')
    h5info_input = parser_h5info.add_argument_group('options to specify input files')
    h5info_input.add_argument('-i',
                             required=True,
                             help='input HDF5 file containing Force Matching data',
                             metavar='[.h5]')
    parser_h5info.set_defaults(func=h5info)
    ##
    #####
    # Add compare-top command
    parser_compare = subparsers.add_parser('compare-top',
                                          help='compare QM parameters between two topologies')
    compare_input = parser_compare.add_argument_group('options to specify inputs')
    compare_input.add_argument('-top1',
                             required=True,
                             help='First topology file',
                             metavar='[.top]')
    compare_input.add_argument('-top2',
                             required=True,
                             help='Second topology file',
                             metavar='[.top]')
    compare_input.add_argument('-top3',
                             required=False,
                             help='Third topology file',
                             metavar='[.top]')
    compare_input.add_argument('-coords',
                                required=True,
                                help='Coordinate file (gro/pdb)',
                                metavar='[.gro/.pdb]')
    compare_input.add_argument('-sele',
                         required=True,
                         help='qm selection',
                         metavar='[.txt/.dat]')
    parser_compare.set_defaults(func=compare_top)
    ##
    #####
    parser_qminfo = subparsers.add_parser('qminfo',
                                         help='print information about QM atoms in the QM region')
    qminfo_input = parser_qminfo.add_argument_group('options to specify input files')
    qminfo_input.add_argument('-top',
                             required=True,
                             help='GROMACS topology file',
                             metavar='[.top]')
    qminfo_input.add_argument('-coords',
                             required=True,
                             help='GROMACS coordinate file',
                             metavar='[.gro/.pdb]')
    qminfo_input.add_argument('-sele',
                             required=True,
                             help='QM selection file',
                             metavar='[.txt/.dat]')
    qminfo_output = parser_qminfo.add_argument_group('options to specify output files')
    qminfo_output.add_argument('-out',
                              required=False,
                              help='output file to write QM information (default: print to console)',
                              metavar='[.txt]')
    qminfo_others = parser_qminfo.add_argument_group('other options')
    qminfo_others.add_argument('-ff',
                             required=False,
                             help='path to force field data directory',
                             metavar='')
    qminfo_others.add_argument('-guess',
                              required=False,
                              default=True,
                              type=__str2bool,
                              help='toggle guessing atomic elements',
                              metavar='(True)')
    qminfo_others.add_argument('-nsa',
                             required=False,
                             help='file containing non-standard atomtypes in 2-column format',
                             metavar='[.txt/.dat]')
    qminfo_others.add_argument('-buf',
                             required=False,
                             default=1000,
                             type=__str2int,
                             help='buffer size for reading input topology',
                             metavar='(1000)')
    parser_qminfo.set_defaults(func=qminfo)
    ##
    #####
    parser_fm = subparsers.add_parser('fm',
                                     help='run force matching workflow')
    fm_input = parser_fm.add_argument_group('options to specify input files')
    fm_input.add_argument('-top',
                         required=True,
                         help='GROMACS topology file',
                         metavar='[.top]')
    fm_input.add_argument('-sele',
                         required=True,
                         help='qm selection',
                         metavar='[.txt/.dat]')
    fm_input.add_argument('-fmdata',
                         required=True,
                         help='Force matching data file',
                         metavar='[.json]')
    fm_input.add_argument('-fi',
                         required=True,
                         help='Force matching input file',
                         metavar='[.inp]')
    fm_input.add_argument('-trr',
                         required=True,
                         help='GROMACS trajectory file',
                         metavar='[.trr]')
    fm_input.add_argument('-mdp',
                         required=False,
                         help='GROMACS MDP file',
                         metavar='[.mdp]')
    fm_input.add_argument('-ndx',
                         required=True,
                         help='GROMACS index file',
                         metavar='[.ndx]')
    fm_input.add_argument('-coords',
                         required=True,
                         help='GROMACS coordinate file',
                         metavar='[.gro/.pdb]')
    fm_others = parser_fm.add_argument_group('other options')
    fm_others.add_argument('-ff',
                          required=False,
                          help='path to force field data directory',
                          metavar='')
    fm_others.add_argument('-gmx',
                          default='gmx',
                          help='GROMACS executable',
                          metavar='(gmx)')
    fm_others.add_argument('-dresp',
                          action='store_true',
                          help='run only DRESP optimization')
    fm_others.add_argument('-opt_ff',
                          action='store_true',
                          help='run only force field optimization')
    fm_others.add_argument('-grid_search',
                          action='store_true',
                          help='perform grid search over wv, we, wh and output CSV')
    fm_others.add_argument('-compare_methods',
                          action='store_true',
                          help='compare all optimization methods and use the best one')
    fm_others.add_argument('-n_processes',
                          type=int,
                          default=None,
                          help='number of processes for parallel force computation (default: auto-detect)')
    parser_fm.set_defaults(func=fm)
    ##

    args = parser.parse_args()
    if vars(args) == {}:
        sys.exit()
    subcommand = args.func.__name__
    print('=====> Running {} <=====\n'.format(subcommand))
    args.func(args)
    print('\n=====> Done <=====\n')

if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        sys.exit(1)
