"""
Force matching module for MiMiCPy.

This module provides functionality for force matching in molecular dynamics simulations.
"""

from .qm_region import QMRegion

from .dresp import opt_dresp, compute_sd, get_configurations
from .opt_ff import (
    ParameterOptimizer,
    get_optimize_ff_parameters,
    get_configurations_optff,
    optimization_ff,
    check_bond_equivalence,
    check_angle_equivalence,
    check_dihedral_equivalence
)

__all__ = [
    # Classes
    'ParameterOptimizer',
    'QMRegion',
    # Functions
    'get_configurations',
    'get_optimize_ff_parameters',
    'get_configurations_optff',
    'optimization_ff',
    'opt_dresp',
    'compute_sd',
    'check_bond_equivalence',
    'check_angle_equivalence',
    'check_dihedral_equivalence'
] 