import matplotlib.pyplot as plt
import numpy as np
from .qm_region import QMRegion
from ..utils.constants import au_to_nm, kb_au2gmx, au_kjm


def compare_qm_parameters(top1_file, top2_file, top3_file=None, coord_file=None, qm_selection=None, dir='.', labels=['Original FF', 'Force-matched FF', ' QM/MM']):
    """
    Compare charges and bonded parameters of QM atoms between two or three topologies
    
    Args:
        top1_file (str): Path to first topology file
        top2_file (str): Path to second topology file
        top3_file (str, optional): Path to third topology file (for bond lengths and angles only)
        coord_file (str): Path to coordinate file (gro/pdb)
        qm_selection (str): Selection string for QM atoms
        dir (str): Directory to save plots
        labels (list, optional): List of labels for the topologies (default: ['Original FF', 'Force-matched FF', 'QM/MM'])
    """
    if labels is None:
        labels = ['Topology 1', 'Topology 2', 'Topology 3']
    if len(labels) < 2:
        raise ValueError('labels must be a list of at least two strings')
    if top3_file is not None and len(labels) < 3:
        labels.append('Topology 3')
    
    # Create QM regions for topologies
    qm1 = QMRegion(top1_file, coord_file)
    qm2 = QMRegion(top2_file, coord_file)
    
    # Get QM atoms from both topologies
    qm1.setup_qm_region(qm_selection)  # Add all QM atoms
    qm2.setup_qm_region(qm_selection)  # Add all QM atoms
    
    # Get QM atoms dataframes
    qm_atoms1 = qm1.qm_atoms
    qm_atoms2 = qm2.qm_atoms
    
    # Initialize third topology if provided
    qm3 = None
    qm_atoms3 = None
    qm_interactions3 = None
    if top3_file is not None:
        qm3 = QMRegion(top3_file, coord_file)
        qm3.setup_qm_region(qm_selection)
        qm_atoms3 = qm3.qm_atoms
        qm_interactions3 = qm3.extract_qm_interactions()
    
    # Compare charges
    print("\nComparing QM atom charges:")
    print("-" * 50)
    
    # Create atom labels with residue information
    atom_labels = [f"{row['name']}" 
                  for _, row in qm_atoms1.iterrows()]
    
    num_atoms = len(atom_labels)
    


    # For large numbers, use subplot-based bar plots for charges
    # Calculate subplot layout - stack vertically
    atoms_per_plot = 20  # Number of atoms per subplot
    num_plots = (num_atoms + atoms_per_plot - 1) // atoms_per_plot  # Ceiling division
    
    # Stack plots vertically (1 column, multiple rows)
    cols = 1  # Single column
    rows = num_plots
    
    # Create figure for charge comparison
    fig1, axes1 = plt.subplots(rows, cols, figsize=(12, 4*rows))
    fig1.suptitle('Charge Comparison Between Topologies', fontsize=16, y=0.98)
    
    # Flatten axes if needed
    if rows == 1:
        axes1 = [axes1] if cols == 1 else axes1
    else:
        axes1 = axes1.flatten()
    
    # Plot charges in subplots
    for plot_idx in range(num_plots):
        start_idx = plot_idx * atoms_per_plot
        end_idx = min(start_idx + atoms_per_plot, num_atoms)
        
        ax = axes1[plot_idx]
        x = np.arange(end_idx - start_idx)
        width = 0.35
        
        # Get data for this subplot
        charge1_subset = qm_atoms1['charge'].iloc[start_idx:end_idx]
        charge2_subset = qm_atoms2['charge'].iloc[start_idx:end_idx]
        atom_labels_subset = atom_labels[start_idx:end_idx]
        
        # Create bars
        ax.bar(x - width/2, charge1_subset, width, label=labels[0], alpha=0.7, color='blue')
        ax.bar(x + width/2, charge2_subset, width, label=labels[1], alpha=0.7, color='red')
        
        ax.set_xlabel('Atoms')
        ax.set_ylabel('Charge')
        ax.set_title(f'Atoms {start_idx+1}-{end_idx}')
        ax.set_xticks(x)
        # Use actual atom labels
        ax.set_xticklabels(atom_labels_subset, rotation=45, ha='right', fontsize=8)
        ax.legend(fontsize=8)
        ax.grid(True, alpha=0.3)
    
    # Hide unused subplots
    for i in range(num_plots, len(axes1)):
        axes1[i].set_visible(False)
    
    plt.tight_layout()
    plt.subplots_adjust(top=0.95)  # Adjust for suptitle
    plt.savefig(f'{dir}/charge_comparison_subplots.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    # Create figure for charge differences
    fig2, axes2 = plt.subplots(rows, cols, figsize=(12, 4*rows))
    fig2.suptitle('Charge Differences Between Topologies', fontsize=16, y=0.98)
    
    # Flatten axes if needed
    if rows == 1:
        axes2 = [axes2] if cols == 1 else axes2
    else:
        axes2 = axes2.flatten()
    
    # Plot charge differences in subplots
    for plot_idx in range(num_plots):
        start_idx = plot_idx * atoms_per_plot
        end_idx = min(start_idx + atoms_per_plot, num_atoms)
        
        ax = axes2[plot_idx]
        x = np.arange(end_idx - start_idx)
        width = 0.7
        
        # Get data for this subplot
        charge1_subset = qm_atoms1['charge'].iloc[start_idx:end_idx]
        charge2_subset = qm_atoms2['charge'].iloc[start_idx:end_idx]
        atom_labels_subset = atom_labels[start_idx:end_idx]
        
        # Calculate charge differences
        charge_diff_subset = ((charge1_subset - charge2_subset) / charge1_subset) * 100
        
        # Create bars
        ax.bar(x, charge_diff_subset, width, color='red', alpha=0.7)
        
        # Add horizontal line at y=0
        ax.axhline(y=0, color='black', linestyle='-', alpha=0.3)
        
        ax.set_xlabel('Atoms')
        ax.set_ylabel('Charge Difference (%)')
        ax.set_title(f'Atoms {start_idx+1}-{end_idx}')
        ax.set_xticks(x)
        # Use actual atom labels
        ax.set_xticklabels(atom_labels_subset, rotation=45, ha='right', fontsize=8)
        ax.grid(True, alpha=0.3)
    
    # Hide unused subplots
    for i in range(num_plots, len(axes2)):
        axes2[i].set_visible(False)
    
    plt.tight_layout()
    plt.subplots_adjust(top=0.95)  # Adjust for suptitle
    plt.savefig(f'{dir}/charge_differences_subplots.png', dpi=300, bbox_inches='tight')
    plt.close()
    

    # Compare bonded parameters
    print("\nComparing QM atom bonded parameters:")
    print("-" * 50)
    
    # Extract QM interactions
    qm_interactions1 = qm1.extract_qm_interactions()
    qm_interactions2 = qm2.extract_qm_interactions()
    
    # Helper function to get atom labels for interactions
    def get_interaction_label(atoms, qm_atoms):
        labels_ = []
        for atom_idx in atoms:
            atom = qm_atoms.iloc[atom_idx]  # Convert to 1-based index
            labels_.append(f"{atom['name']}")
        return " - ".join(labels_)
    
    # Compare bonds
    # Create bond labels and parameters
    bond_labels = []
    r1_values = []
    r2_values = []
    r3_values = []
    k1_values = []
    k2_values = []
    
    for bond1 in qm_interactions1['bonds']:
        if bond1['involves_mm']:
            continue
        atoms = tuple(sorted(bond1['atoms']))
        # Find matching bond in topology 2
        for bond2 in qm_interactions2['bonds']:
            if bond2['involves_mm']:
                continue
            if tuple(sorted(bond2['atoms'])) == atoms:
                bond_labels.append(get_interaction_label(atoms, qm_atoms1))
                # Convert atomic units to GROMACS units
                r1_values.append(bond1['parameters'][0] * au_to_nm)  # Convert from au to nm
                r2_values.append(bond2['parameters'][0] * au_to_nm)  # Convert from au to nm
                k1_values.append(bond1['parameters'][1] * kb_au2gmx)  # Convert from au to kJ/mol/nm^2
                k2_values.append(bond2['parameters'][1] * kb_au2gmx)  # Convert from au to kJ/mol/nm^2
                
                # Add third topology bond length if available
                if qm_interactions3 is not None:
                    r3_found = False
                    for bond3 in qm_interactions3['bonds']:
                        if tuple(sorted(bond3['atoms'])) == atoms:
                            r3_values.append(bond3['parameters'][0] * au_to_nm)  # Convert from au to nm
                            r3_found = True
                            break
                    if not r3_found:
                        r3_values.append(None)  # No matching bond found
                else:
                    r3_values.append(None)
                break
    
    # Plot bond parameters with summary statistics for large numbers
    num_bonds = len(bond_labels)
    if num_bonds > 0:
    
        # For large numbers, use subplot-based bar plots
        # Calculate subplot layout - stack vertically
        bonds_per_plot = 20  # Number of bonds per subplot
        num_plots = (num_bonds + bonds_per_plot - 1) // bonds_per_plot  # Ceiling division
        
        # Stack plots vertically (1 column, multiple rows)
        cols = 1  # Single column
        rows = num_plots
        
        # Create figure for bond length comparison
        fig1, axes1 = plt.subplots(rows, cols, figsize=(12, 4*rows))
        fig1.suptitle('Bond Length Comparison', fontsize=16, y=0.98)
        
        # Flatten axes if needed
        if rows == 1:
            axes1 = [axes1] if cols == 1 else axes1
        else:
            axes1 = axes1.flatten()
        
        # Plot bond lengths in subplots
        for plot_idx in range(num_plots):
            start_idx = plot_idx * bonds_per_plot
            end_idx = min(start_idx + bonds_per_plot, num_bonds)
            
            ax = axes1[plot_idx]
            x = np.arange(end_idx - start_idx)
            width = 0.35
            
            # Get data for this subplot
            r1_subset = r1_values[start_idx:end_idx]
            r2_subset = r2_values[start_idx:end_idx]
            bond_labels_subset = bond_labels[start_idx:end_idx]
            
            # Create bars
            bar_width = 0.25 if qm_interactions3 is not None else 0.35
            ax.bar(x - bar_width, r1_subset, bar_width, label=labels[0], alpha=0.7, color='blue')
            ax.bar(x, r2_subset, bar_width, label=labels[1], alpha=0.7, color='red')
            
            if qm_interactions3 is not None:
                # Filter out None values for third topology
                r3_subset = [r3_values[i] for i in range(start_idx, end_idx) if r3_values[i] is not None]
                if len(r3_subset) > 0:
                    # Only plot if we have valid third topology data
                    valid_indices = [i for i in range(start_idx, end_idx) if r3_values[i] is not None]
                    valid_x = [x[i - start_idx] for i in valid_indices]
                    ax.bar(valid_x + bar_width, r3_subset, bar_width, label=labels[2], alpha=0.7, color='green')
            
            ax.set_xlabel('Bonds')
            ax.set_ylabel('Bond Length (nm)')
            ax.set_title(f'Bonds {start_idx+1}-{end_idx}')
            ax.set_xticks(x)
            # Use actual atom labels for bonds
            ax.set_xticklabels(bond_labels_subset, rotation=45, ha='right', fontsize=8)
            ax.legend(fontsize=8)
            ax.grid(True, alpha=0.3)
        
        # Hide unused subplots
        for i in range(num_plots, len(axes1)):
            axes1[i].set_visible(False)
        
        plt.tight_layout()
        plt.subplots_adjust(top=0.95)  # Adjust for suptitle
        plt.savefig(f'{dir}/bond_length_subplots.png', dpi=300, bbox_inches='tight')
        plt.close()
        
        # Create figure for bond force constant comparison
        fig2, axes2 = plt.subplots(rows, cols, figsize=(12, 4*rows))
        fig2.suptitle('Bond Force Constant Comparison', fontsize=16, y=0.98)
        
        # Flatten axes if needed
        if rows == 1:
            axes2 = [axes2] if cols == 1 else axes2
        else:
            axes2 = axes2.flatten()
        
        # Plot force constants in subplots
        for plot_idx in range(num_plots):
            start_idx = plot_idx * bonds_per_plot
            end_idx = min(start_idx + bonds_per_plot, num_bonds)
            
            ax = axes2[plot_idx]
            x = np.arange(end_idx - start_idx)
            width = 0.35
            
            # Get data for this subplot
            k1_subset = k1_values[start_idx:end_idx]
            k2_subset = k2_values[start_idx:end_idx]
            bond_labels_subset = bond_labels[start_idx:end_idx]
            
            # Create bars
            ax.bar(x - width/2, k1_subset, width, label=labels[0], alpha=0.7, color='blue')
            ax.bar(x + width/2, k2_subset, width, label=labels[1], alpha=0.7, color='red')
            
            ax.set_xlabel('Bonds')
            ax.set_ylabel('Force Constant (kJ/mol/nm²)')
            ax.set_title(f'Bonds {start_idx+1}-{end_idx}')
            ax.set_xticks(x)
            # Use actual atom labels for bonds
            ax.set_xticklabels(bond_labels_subset, rotation=45, ha='right', fontsize=8)
            ax.legend(fontsize=8)
            ax.grid(True, alpha=0.3)
        
        # Hide unused subplots
        for i in range(num_plots, len(axes2)):
            axes2[i].set_visible(False)
        
        plt.tight_layout()
        plt.subplots_adjust(top=0.95)  # Adjust for suptitle
        plt.savefig(f'{dir}/bond_force_subplots.png', dpi=300, bbox_inches='tight')
        plt.close()
        

    # Compare angles
    # Create angle labels and parameters
    angle_labels = []
    theta1_values = []
    theta2_values = []
    theta3_values = []
    k1_values = []
    k2_values = []
    
    for angle1 in qm_interactions1['angles']:
        if angle1['involves_mm']:
            continue
        atoms = tuple(sorted(angle1['atoms']))
        # Find matching angle in topology 2
        for angle2 in qm_interactions2['angles']:
            if angle2['involves_mm']:
                continue
            if tuple(sorted(angle2['atoms'])) == atoms:
                angle_labels.append(get_interaction_label(atoms, qm_atoms1))
                # Convert atomic units to GROMACS units
                theta1_values.append(np.rad2deg(angle1['parameters'][0]))  # theta in degrees (already converted)
                theta2_values.append(np.rad2deg(angle2['parameters'][0]))  # theta in degrees (already converted)
                k1_values.append(angle1['parameters'][1] * au_kjm)  # Convert from au to kJ/mol/rad^2
                k2_values.append(angle2['parameters'][1] * au_kjm)  # Convert from au to kJ/mol/rad^2
                
                # Add third topology angle value if available
                if qm_interactions3 is not None:
                    theta3_found = False
                    for angle3 in qm_interactions3['angles']:
                        if tuple(sorted(angle3['atoms'])) == atoms:
                            theta3_values.append(np.rad2deg(angle3['parameters'][0]))  # theta in degrees
                            theta3_found = True
                            break
                    if not theta3_found:
                        theta3_values.append(None)  # No matching angle found
                else:
                    theta3_values.append(None)
                break
    
    # Plot angle parameters with summary statistics for large numbers
    num_angles = len(angle_labels)
    if num_angles > 0:
    
        # For large numbers, use subplot-based bar plots for angles
        # Calculate subplot layout - stack vertically
        angles_per_plot = 20  # Number of angles per subplot
        num_plots = (num_angles + angles_per_plot - 1) // angles_per_plot  # Ceiling division
        
        # Stack plots vertically (1 column, multiple rows)
        cols = 1  # Single column
        rows = num_plots
        
        # Create figure for angle value comparison
        fig1, axes1 = plt.subplots(rows, cols, figsize=(12, 4*rows))
        fig1.suptitle('Angle Value Comparison', fontsize=16, y=0.98)
        
        # Flatten axes if needed
        if rows == 1:
            axes1 = [axes1] if cols == 1 else axes1
        else:
            axes1 = axes1.flatten()
        
        # Plot angle values in subplots
        for plot_idx in range(num_plots):
            start_idx = plot_idx * angles_per_plot
            end_idx = min(start_idx + angles_per_plot, num_angles)
            
            ax = axes1[plot_idx]
            x = np.arange(end_idx - start_idx)
            width = 0.35
            
            # Get data for this subplot
            theta1_subset = theta1_values[start_idx:end_idx]
            theta2_subset = theta2_values[start_idx:end_idx]
            angle_labels_subset = angle_labels[start_idx:end_idx]
            
            # Create bars
            bar_width = 0.25 if qm_interactions3 is not None else 0.35
            ax.bar(x - bar_width, theta1_subset, bar_width, label=labels[0], alpha=0.7, color='blue')
            ax.bar(x, theta2_subset, bar_width, label=labels[1], alpha=0.7, color='red')
            
            if qm_interactions3 is not None:
                # Filter out None values for third topology
                theta3_subset = [theta3_values[i] for i in range(start_idx, end_idx) if theta3_values[i] is not None]
                if len(theta3_subset) > 0:
                    # Only plot if we have valid third topology data
                    valid_indices = [i for i in range(start_idx, end_idx) if theta3_values[i] is not None]
                    valid_x = [x[i - start_idx] for i in valid_indices]
                    ax.bar(valid_x + bar_width, theta3_subset, bar_width, label=labels[2], alpha=0.7, color='green')
            
            ax.set_xlabel('Angles')
            ax.set_ylabel('Angle (degrees)')
            ax.set_title(f'Angles {start_idx+1}-{end_idx}')
            ax.set_xticks(x)
            # Use actual atom labels for angles
            ax.set_xticklabels(angle_labels_subset, rotation=45, ha='right', fontsize=8)
            ax.legend(fontsize=8)
            ax.grid(True, alpha=0.3)
        
        # Hide unused subplots
        for i in range(num_plots, len(axes1)):
            axes1[i].set_visible(False)
        
        plt.tight_layout()
        plt.subplots_adjust(top=0.95)  # Adjust for suptitle
        plt.savefig(f'{dir}/angle_value_subplots.png', dpi=300, bbox_inches='tight')
        plt.close()
        
        # Create figure for angle force constant comparison
        fig2, axes2 = plt.subplots(rows, cols, figsize=(12, 4*rows))
        fig2.suptitle('Angle Force Constant Comparison', fontsize=16, y=0.98)
        
        # Flatten axes if needed
        if rows == 1:
            axes2 = [axes2] if cols == 1 else axes2
        else:
            axes2 = axes2.flatten()
        
        # Plot force constants in subplots
        for plot_idx in range(num_plots):
            start_idx = plot_idx * angles_per_plot
            end_idx = min(start_idx + angles_per_plot, num_angles)
            
            ax = axes2[plot_idx]
            x = np.arange(end_idx - start_idx)
            width = 0.35
            
            # Get data for this subplot
            k1_subset = k1_values[start_idx:end_idx]
            k2_subset = k2_values[start_idx:end_idx]
            angle_labels_subset = angle_labels[start_idx:end_idx]
            
            # Create bars
            ax.bar(x - width/2, k1_subset, width, label=labels[0], alpha=0.7, color='blue')
            ax.bar(x + width/2, k2_subset, width, label=labels[1], alpha=0.7, color='red')
            
            ax.set_xlabel('Angles')
            ax.set_ylabel('Force Constant (kJ/mol/rad²)')
            ax.set_title(f'Angles {start_idx+1}-{end_idx}')
            ax.set_xticks(x)
            # Use actual atom labels for angles
            ax.set_xticklabels(angle_labels_subset, rotation=45, ha='right', fontsize=8)
            ax.legend(fontsize=8)
            ax.grid(True, alpha=0.3)
        
        # Hide unused subplots
        for i in range(num_plots, len(axes2)):
            axes2[i].set_visible(False)
        
        plt.tight_layout()
        plt.subplots_adjust(top=0.95)  # Adjust for suptitle
        plt.savefig(f'{dir}/angle_force_subplots.png', dpi=300, bbox_inches='tight')
        plt.close()

    # Compare dihedrals
    # Create separate figures for each dihedral function type
    dihedral_labels = []
    dihedral_params1 = []
    dihedral_params2 = []
    dihedral_funcs = []
    
    for dihedral1 in qm_interactions1['dihedrals']:
        if dihedral1['involves_mm']:
            continue
        atoms = tuple(dihedral1['atoms'])
        for dihedral2 in qm_interactions2['dihedrals']:
            if dihedral2['involves_mm']:
                continue
            if tuple(dihedral2['atoms']) == atoms:
                
                dihedral_labels.append(get_interaction_label(atoms, qm_atoms1))
                dihedral_funcs.append(dihedral1['function'])
                
                # Store parameters based on function type with unit conversion
                if dihedral1['function'] in [1, 4, 9]:  # Format 1
                    if dihedral1['parameters'][2] == dihedral2['parameters'][2]:
                        params1 = {
                                'phi0': np.rad2deg(dihedral1['parameters'][0]),  # phi0 in degrees
                                'k': dihedral1['parameters'][1] * au_kjm,  # Convert from au to kJ/mol
                                'n': dihedral1['parameters'][2]  # multiplicity
                            }
                        params2 = {
                            'phi0': np.rad2deg(dihedral2['parameters'][0]),
                            'k': dihedral2['parameters'][1] * au_kjm,
                            'n': dihedral2['parameters'][2]
                        } 
                    else:
                        dihedral_labels.pop()
                        dihedral_funcs.pop()
                        break
                        
                elif dihedral1['function'] == 2:  # Format 2
                    params1 = {
                        'xi': dihedral1['parameters'][0],  # xi (dimensionless)
                        'k': dihedral1['parameters'][1] * au_kjm  # Convert from au to kJ/mol
                    }
                    params2 = {
                        'xi': dihedral2['parameters'][0],
                        'k': dihedral2['parameters'][1] * au_kjm
                    }
                elif dihedral1['function'] == 3:  # Format 3
                    params1 = {
                        'C0': dihedral1['parameters'][0] * au_kjm,  # C0-C5 in kJ/mol
                        'C1': dihedral1['parameters'][1] * au_kjm,
                        'C2': dihedral1['parameters'][2] * au_kjm,
                        'C3': dihedral1['parameters'][3] * au_kjm,
                        'C4': dihedral1['parameters'][4] * au_kjm,
                        'C5': dihedral1['parameters'][5] * au_kjm
                    }
                    params2 = {
                        'C0': dihedral2['parameters'][0] * au_kjm,
                        'C1': dihedral2['parameters'][1] * au_kjm,
                        'C2': dihedral2['parameters'][2] * au_kjm,
                        'C3': dihedral2['parameters'][3] * au_kjm,
                        'C4': dihedral2['parameters'][4] * au_kjm,
                        'C5': dihedral2['parameters'][5] * au_kjm
                    }
                
                dihedral_params1.append(params1)
                dihedral_params2.append(params2)
                break
    
    # Plot dihedral parameters based on function type
    num_dihedrals = len(dihedral_labels)
    if num_dihedrals > 0:
        # Plot dihedral parameters based on function type
        for func in set(dihedral_funcs):
            func_dihedrals = [(i, label, p1, p2) for i, (label, f, p1, p2) in enumerate(zip(dihedral_labels, dihedral_funcs, dihedral_params1, dihedral_params2)) if f == func]
            
            
            # For large numbers, use subplot-based bar plots for dihedrals
            # Calculate subplot layout - stack vertically
            dihedrals_per_plot = 20  # Number of dihedrals per subplot
            num_plots = (len(func_dihedrals) + dihedrals_per_plot - 1) // dihedrals_per_plot  # Ceiling division
            
            # Stack plots vertically (1 column, multiple rows)
            cols = 1  # Single column
            rows = num_plots
            
            if func in [1, 4, 9]:  # Format 1
                # Create figure for phase angle comparison
                fig1, axes1 = plt.subplots(rows, cols, figsize=(12, 4*rows))
                fig1.suptitle(f'Dihedral Phase Angle Comparison (Function {func})', fontsize=16, y=0.98)
                
                # Flatten axes if needed
                if rows == 1:
                    axes1 = [axes1] if cols == 1 else axes1
                else:
                    axes1 = axes1.flatten()
                
                # Plot phase angles in subplots
                for plot_idx in range(num_plots):
                    start_idx = plot_idx * dihedrals_per_plot
                    end_idx = min(start_idx + dihedrals_per_plot, len(func_dihedrals))
                    
                    ax = axes1[plot_idx]
                    x = np.arange(end_idx - start_idx)
                    width = 0.35
                    
                    # Get data for this subplot
                    phi0_1_subset = [p1['phi0'] for _, _, p1, _ in func_dihedrals[start_idx:end_idx]]
                    phi0_2_subset = [p2['phi0'] for _, _, _, p2 in func_dihedrals[start_idx:end_idx]]
                    dihedral_labels_subset = [label for _, label, _, _ in func_dihedrals[start_idx:end_idx]]
                    
                    # Create bars
                    ax.bar(x - width/2, phi0_1_subset, width, label=labels[0], alpha=0.7, color='blue')
                    ax.bar(x + width/2, phi0_2_subset, width, label=labels[1], alpha=0.7, color='red')
                    
                    ax.set_xlabel('Dihedrals')
                    ax.set_ylabel('Phase Angle (degrees)')
                    ax.set_title(f'Dihedrals {start_idx+1}-{end_idx}')
                    ax.set_xticks(x)
                    # Use actual atom labels for dihedrals
                    ax.set_xticklabels(dihedral_labels_subset, rotation=45, ha='right', fontsize=8)
                    ax.legend(fontsize=8)
                    ax.grid(True, alpha=0.3)
                
                # Hide unused subplots
                for i in range(num_plots, len(axes1)):
                    axes1[i].set_visible(False)
                
                plt.tight_layout()
                plt.subplots_adjust(top=0.95)  # Adjust for suptitle
                plt.savefig(f'{dir}/dihedral_phase_subplots_func{func}.png', dpi=300, bbox_inches='tight')
                plt.close()
                
                # Create figure for force constant comparison
                fig2, axes2 = plt.subplots(rows, cols, figsize=(12, 4*rows))
                fig2.suptitle(f'Dihedral Force Constant Comparison (Function {func})', fontsize=16, y=0.98)
                
                # Flatten axes if needed
                if rows == 1:
                    axes2 = [axes2] if cols == 1 else axes2
                else:
                    axes2 = axes2.flatten()
                
                # Plot force constants in subplots
                for plot_idx in range(num_plots):
                    start_idx = plot_idx * dihedrals_per_plot
                    end_idx = min(start_idx + dihedrals_per_plot, len(func_dihedrals))
                    
                    ax = axes2[plot_idx]
                    x = np.arange(end_idx - start_idx)
                    width = 0.35
                    
                    # Get data for this subplot
                    k_1_subset = [p1['k'] for _, _, p1, _ in func_dihedrals[start_idx:end_idx]]
                    k_2_subset = [p2['k'] for _, _, _, p2 in func_dihedrals[start_idx:end_idx]]
                    dihedral_labels_subset = [label for _, label, _, _ in func_dihedrals[start_idx:end_idx]]
                    
                    # Create bars
                    ax.bar(x - width/2, k_1_subset, width, label=labels[0], alpha=0.7, color='blue')
                    ax.bar(x + width/2, k_2_subset, width, label=labels[1], alpha=0.7, color='red')
                    
                    ax.set_xlabel('Dihedrals')
                    ax.set_ylabel('Force Constant (kJ/mol)')
                    ax.set_title(f'Dihedrals {start_idx+1}-{end_idx}')
                    ax.set_xticks(x)
                    # Use actual atom labels for dihedrals
                    ax.set_xticklabels(dihedral_labels_subset, rotation=45, ha='right', fontsize=8)
                    ax.legend(fontsize=8)
                    ax.grid(True, alpha=0.3)
                
                # Hide unused subplots
                for i in range(num_plots, len(axes2)):
                    axes2[i].set_visible(False)
                
                plt.tight_layout()
                plt.subplots_adjust(top=0.95)  # Adjust for suptitle
                plt.savefig(f'{dir}/dihedral_force_subplots_func{func}.png', dpi=300, bbox_inches='tight')
                plt.close()
                
            elif func == 2:  # Format 2
                # Create figure for xi comparison
                fig1, axes1 = plt.subplots(rows, cols, figsize=(12, 4*rows))
                fig1.suptitle('Improper Dihedral Xi Comparison', fontsize=16, y=0.98)
                
                # Flatten axes if needed
                if rows == 1:
                    axes1 = [axes1] if cols == 1 else axes1
                else:
                    axes1 = axes1.flatten()
                
                # Plot xi values in subplots
                for plot_idx in range(num_plots):
                    start_idx = plot_idx * dihedrals_per_plot
                    end_idx = min(start_idx + dihedrals_per_plot, len(func_dihedrals))
                    
                    ax = axes1[plot_idx]
                    x = np.arange(end_idx - start_idx)
                    width = 0.35
                    
                    # Get data for this subplot
                    xi_1_subset = [p1['xi'] for _, _, p1, _ in func_dihedrals[start_idx:end_idx]]
                    xi_2_subset = [p2['xi'] for _, _, _, p2 in func_dihedrals[start_idx:end_idx]]
                    dihedral_labels_subset = [label for _, label, _, _ in func_dihedrals[start_idx:end_idx]]
                    
                    # Create bars
                    ax.bar(x - width/2, xi_1_subset, width, label=labels[0], alpha=0.7, color='blue')
                    ax.bar(x + width/2, xi_2_subset, width, label=labels[1], alpha=0.7, color='red')
                    
                    ax.set_xlabel('Dihedrals')
                    ax.set_ylabel('Xi')
                    ax.set_title(f'Dihedrals {start_idx+1}-{end_idx}')
                    ax.set_xticks(x)
                    # Use actual atom labels for dihedrals
                    ax.set_xticklabels(dihedral_labels_subset, rotation=45, ha='right', fontsize=8)
                    ax.legend(fontsize=8)
                    ax.grid(True, alpha=0.3)
                
                # Hide unused subplots
                for i in range(num_plots, len(axes1)):
                    axes1[i].set_visible(False)
                
                plt.tight_layout()
                plt.subplots_adjust(top=0.95)  # Adjust for suptitle
                plt.savefig(f'{dir}/dihedral_xi_subplots.png', dpi=300, bbox_inches='tight')
                plt.close()
                
                # Create figure for force constant comparison
                fig2, axes2 = plt.subplots(rows, cols, figsize=(12, 4*rows))
                fig2.suptitle('Improper Dihedral Force Constant Comparison', fontsize=16, y=0.98)
                
                # Flatten axes if needed
                if rows == 1:
                    axes2 = [axes2] if cols == 1 else axes2
                else:
                    axes2 = axes2.flatten()
                
                # Plot force constants in subplots
                for plot_idx in range(num_plots):
                    start_idx = plot_idx * dihedrals_per_plot
                    end_idx = min(start_idx + dihedrals_per_plot, len(func_dihedrals))
                    
                    ax = axes2[plot_idx]
                    x = np.arange(end_idx - start_idx)
                    width = 0.35
                    
                    # Get data for this subplot
                    k_1_subset = [p1['k'] for _, _, p1, _ in func_dihedrals[start_idx:end_idx]]
                    k_2_subset = [p2['k'] for _, _, _, p2 in func_dihedrals[start_idx:end_idx]]
                    dihedral_labels_subset = [label for _, label, _, _ in func_dihedrals[start_idx:end_idx]]
                    
                    # Create bars
                    ax.bar(x - width/2, k_1_subset, width, label=labels[0], alpha=0.7, color='blue')
                    ax.bar(x + width/2, k_2_subset, width, label=labels[1], alpha=0.7, color='red')
                    
                    ax.set_xlabel('Dihedrals')
                    ax.set_ylabel('Force Constant (kJ/mol)')
                    ax.set_title(f'Dihedrals {start_idx+1}-{end_idx}')
                    ax.set_xticks(x)
                    # Use actual atom labels for dihedrals
                    ax.set_xticklabels(dihedral_labels_subset, rotation=45, ha='right', fontsize=8)
                    ax.legend(fontsize=8)
                    ax.grid(True, alpha=0.3)
                
                # Hide unused subplots
                for i in range(num_plots, len(axes2)):
                    axes2[i].set_visible(False)
                
                plt.tight_layout()
                plt.subplots_adjust(top=0.95)  # Adjust for suptitle
                plt.savefig(f'{dir}/dihedral_force_improper_subplots.png', dpi=300, bbox_inches='tight')
                plt.close()
                
            elif func == 3:  # Format 3
                # Create subplots for each coefficient
                for i in range(6):
                    fig, axes = plt.subplots(rows, cols, figsize=(12, 4*rows))
                    fig.suptitle(f'Ryckaert-Bellemans Coefficient C{i} Comparison', fontsize=16, y=0.98)
                    
                    # Flatten axes if needed
                    if rows == 1:
                        axes = [axes] if cols == 1 else axes
                    else:
                        axes = axes.flatten()
                    
                    # Plot coefficient in subplots
                    for plot_idx in range(num_plots):
                        start_idx = plot_idx * dihedrals_per_plot
                        end_idx = min(start_idx + dihedrals_per_plot, len(func_dihedrals))
                        
                        ax = axes[plot_idx]
                        x = np.arange(end_idx - start_idx)
                        width = 0.35
                        
                        # Get data for this subplot
                        c_1_subset = [p1[f'C{i}'] for _, _, p1, _ in func_dihedrals[start_idx:end_idx]]
                        c_2_subset = [p2[f'C{i}'] for _, _, _, p2 in func_dihedrals[start_idx:end_idx]]
                        dihedral_labels_subset = [label for _, label, _, _ in func_dihedrals[start_idx:end_idx]]
                        
                        # Create bars
                        ax.bar(x - width/2, c_1_subset, width, label=labels[0], alpha=0.7, color='blue')
                        ax.bar(x + width/2, c_2_subset, width, label=labels[1], alpha=0.7, color='red')
                        
                        ax.set_xlabel('Dihedrals')
                        ax.set_ylabel(f'Coefficient C{i} (kJ/mol)')
                        ax.set_title(f'Dihedrals {start_idx+1}-{end_idx}')
                        ax.set_xticks(x)
                        # Use actual atom labels for dihedrals
                        ax.set_xticklabels(dihedral_labels_subset, rotation=45, ha='right', fontsize=8)
                        ax.legend(fontsize=8)
                        ax.grid(True, alpha=0.3)
                    
                    # Hide unused subplots
                    for j in range(num_plots, len(axes)):
                        axes[j].set_visible(False)
                    
                    plt.tight_layout()
                    plt.subplots_adjust(top=0.95)  # Adjust for suptitle
                    plt.savefig(f'{dir}/dihedral_c{i}_subplots.png', dpi=300, bbox_inches='tight')
                    plt.close()