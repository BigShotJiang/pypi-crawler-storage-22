import numpy as np
from ..utils.constants import kjmolnm_to_au, nm_to_au

def get_qm_gmx_forces(mda, idx_frame, qm_atoms):
    """
    Get GROMACS forces and positions for QM atoms
    
    Args:
        mda: MDAnalysis Universe object
        idx_frame (int): Frame index
        qm_atoms: Set or list of GROMACS atom indices (1-based) including QM atoms
        
    Returns:
        tuple: (forces, positions) where forces and positions are numpy arrays
    """
    # mda.trajectory[0]
    # if mda.trajectory[0].time == 0.0:
    #     idx_frame += 1
    mda.trajectory[idx_frame]
    forces = [] 
    positions = []
    
    # Convert qm_atoms to set for efficient lookup
    if not isinstance(qm_atoms, set):
        qm_atoms = set(qm_atoms)
    
    for atom in mda.atoms:
        if atom.id+1 in qm_atoms:
            forces.append(atom.force*10*kjmolnm_to_au)
            positions.append(atom.position * 0.1 * nm_to_au)

    return np.array(forces), np.array(positions)