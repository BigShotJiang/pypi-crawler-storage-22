import logging
import pandas as pd
from pathlib import Path
from datetime import datetime
from ..topology.top import Top
from ..topology.mpt import Mpt
from ..core.prepare import Preparation
from ..utils.errors import MiMiCPyError, SelectionError
from ..utils.file_handler import read
from ..utils.constants import nm_to_au, kb_gmx2au, au_to_nm, kjm_au, au_kjm, kb_au2gmx
import copy
import numpy as np
from math import isclose

def read_qm_selection(selection_file: Path, prep: Preparation):
    """Read QM atom selections from a file and update the Preparation object
    
    Args:
        selection_file (Path): Path to selection file
        prep (Preparation): Preparation object to update
        
    Returns:
        Preparation: Updated Preparation object with QM atoms selected
    """
    if not selection_file.exists():
        raise FileNotFoundError(f'Selection file not found: {selection_file}')
        
    selection_text = read(selection_file)
    logging.info(f'Reading selections from {selection_file}')
    
    for line in selection_text.splitlines():
        if not line.strip():
            continue
            
        parts = line.split()
        if not parts:
            continue
            
        command = parts[0].lower()
        selection = ' '.join(parts[1:]) if len(parts) > 1 else None
        try:   
            if command == 'add':
                prep.add(selection, False)
                logging.info(f'Added atoms to QM region using selection: {selection}')
            elif command == 'add-bound':
                prep.add(selection, True)
                logging.info(f'Added boundary atoms to QM region using selection: {selection}')
            elif command == 'delete':
                prep.delete(selection)
                logging.info(f'Deleted atoms from QM region using selection: {selection}')
            elif command == 'clear':
                prep.clear()
                logging.info('Cleared all atoms from QM region')
            else:
                raise MiMiCPyError(f'Invalid command: {command}')
                
        except Exception as e:
            logging.error(f'Failed to process selection command: {str(e)}')
            continue
            
    return prep

class QMRegion:
    """Class to handle QM region topology formation and extraction"""
    
    def __init__(self, top_file, coords_file, gmxdata=None, buffer=1000, 
                 guess_elements=True, nonstandard_atomtypes=None):
        """Initialize QMRegion with topology and coordinate files
        
        Args:
            top_file (str): Path to topology file
            coords_file (str): Path to coordinate file
            gmxdata (str, optional): Path to GROMACS data directory
            buffer (int, optional): Buffer size for reading files
            guess_elements (bool, optional): Whether to guess atomic elements
            nonstandard_atomtypes (dict, optional): Dictionary of non-standard atom types
        """
        self.top_file = top_file
        self.coords_file = coords_file
        self.gmxdata = gmxdata
        self.buffer = buffer
        self.guess_elements = guess_elements
        self.nonstandard_atomtypes = nonstandard_atomtypes
        
        # Initialize topology and preparation objects
        self.top = None
        self.mpt = None
        self.prep = None
        self.qm_atoms = None
        self.gmx_to_cpmd_map = None
        self.cpmd_to_gmx_map = None
        self.qm_interactions = None
        self.boundary_atoms = None
        self.extended_qm_atoms = None
        self.gmx_to_seq_map = None
        self.qm_total_charge = None
        # Initialize selector
        self.selector = None
        self.solvent_atom_indices = None
        self.load_topology()

        
    def load_topology(self):
        """Load the topology file""" 
        # Load topology using Top class
        self.top = Top(self.top_file, mode='r', buffer=self.buffer,
                      gmxdata=self.gmxdata, guess_elements=self.guess_elements,
                      nonstandard_atomtypes=self.nonstandard_atomtypes)
        logging.info(f'Successfully loaded topology from {self.top_file}')
        
       
        # Create Mpt object from Top
        self.mpt = Mpt.from_top(self.top)
        
        # Initialize selector with Mpt object
        from ..core.selector import DefaultSelector
        self.selector = DefaultSelector(self.mpt, self.coords_file, buffer=self.buffer)
        self.prep = Preparation(self.selector)
            
    def setup_qm_region(self, selection_file: Path, solvent_names:dict=None):
        """Set up QM region using selection file
        
        Args:
            selection_file (Path): Path to selection file
        """
        if not self.top:
            raise MiMiCPyError('Topology not loaded. Call load_topology() first.')
            
        try:
            self.prep = read_qm_selection(selection_file, self.prep)
            self.qm_atoms = self.prep.qm_atoms
            self.gmx_to_cpmd_map = self.gmx_to_cpmd_idx()
            self.cpmd_to_gmx_map = {v: k for k, v in self.gmx_to_cpmd_map.items()}
            self.boundary_atoms = self.qm_atoms[self.qm_atoms['is_bound'] == 1]
            self.qm_interactions = self.extract_qm_interactions()
            self.solvent_atom_indices = self.identify_solvent_atoms(solvent_names)
            self.qm_total_charge = self.qm_atoms['charge'].sum()
        except Exception as e:
            logging.error(f'Failed to setup QM region: {str(e)}')
            raise MiMiCPyError(f'Failed to setup QM region: {str(e)}')

    @property
    def qm_charges(self):
        """Get QM atom charges"""
        if not self.qm_atoms is not None:
            raise MiMiCPyError('No QM atoms defined')
        
        return self.qm_atoms['charge']
    
    def find_boundary_atoms(self):
        """Find and mark boundary atoms in QM region"""
        if not self.prep:
            raise MiMiCPyError('QM region not setup. Call setup_qm_region() first.')
            
        try:
            self.prep.find_bound_atoms()
            self.qm_atoms = self.prep.qm_atoms
            logging.info('Successfully identified boundary atoms')
            return True
        except Exception as e:
            logging.error(f'Failed to find boundary atoms: {str(e)}')
            return False
            
        
    def write_topology(self, topol_dict=None, directory='.', prefix=''):
        """Write .itp files only for molecules containing QM atoms
        
        Args:
            topol_dict (dict): Dictionary of topology data
            directory (str): Path to output directory for .itp files
            prefix (str): Prefix for the output .itp files
        """
        if not self.qm_atoms is not None:
            raise MiMiCPyError('No QM atoms defined')
        
        
        if topol_dict is None:
            topol_dict = self.top.topol_dict
        
        # Get QM atom indices (1-based)
        qm_indices = set(self.qm_atoms.index)
        
        # Create output directory if it doesn't exist
        output_dir = Path(directory)
        output_dir.mkdir(parents=True, exist_ok=True)
        
        # Write molecule types and their interactions to separate .itp files
        # Only for molecules containing QM atoms
        self.written_files = []
        
        # First pass: calculate total atoms up to each molecule type
        mol_offsets = {}
        total_atoms = 0
        for mol, n_mols in self.top.molecules:
            mol_offsets[mol] = total_atoms
            total_atoms += len(topol_dict[mol]) * n_mols
        
       
        # Second pass: check for QM atoms and write .itp files
        for mol, n_mols in self.top.molecules:
            mol_size = len(topol_dict[mol])
            mol_has_qm = False
            
            # Check each instance of this molecule type
            for i in range(n_mols):
                # Convert to 1-based indexing for comparison with qm_indices
                mol_start = mol_offsets[mol] + (i * mol_size) + 1
                mol_end = mol_start + mol_size
                
                
                # Check if any QM atoms are in this molecule instance
                mol_qm_atoms = [idx for idx in qm_indices if mol_start <= idx < mol_end]
                if mol_qm_atoms:
                    mol_has_qm = True
                    break
            
           
            if not mol_has_qm:
                continue
                
            # Create .itp file for this molecule
            source_file = self.top.topol_dict.get_source_file(mol)
            if source_file:
                # Use the original filename from the source file
                itp_file = output_dir / (prefix + Path(source_file).name)
            else:
                # Fallback to molecule name if source file not found
                itp_file = output_dir / prefix + f"{mol}.itp"
            
            # Get nrexcl value for this molecule
            nrexcl = self.top.topol_dict.get_nrexcl_value(mol)
                
            itp_str = f"; Created by mimicpy {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n[ moleculetype ]\n; Name            nrexcl\n{mol:16s} {nrexcl}\n\n"
            
            # Write atoms section
            itp_str += "[ atoms ]\n"
            itp_str += ";   nr    type   resnr  residu    atom    cgnr        charge          mass\n"
            atoms_df = topol_dict[mol]
            for idx, row in atoms_df.iterrows():
                itp_str += f"{idx:6d} {row['type']:8s} {row['resid']:6d} {row['resname']:8s} {row['name']:8s} {row['cgnr']:6d}  {row['charge']:8.6f} {row['mass']:12.5f}\n"
            itp_str += "\n"
            
            # Get interactions for this molecule
            mol_bonds = topol_dict.get_bonds(mol)
            mol_angles = topol_dict.get_angles(mol)
            mol_dihedrals = topol_dict.get_dihedrals(mol)
            mol_pairs = topol_dict.get_pairs(mol)
            # Write bonds
            if mol_bonds:
                itp_str += "[ bonds ]\n"
                itp_str += ";  ai    aj funct    r    k\n"
                for j in range(len(mol_bonds[0])):
                    i_idx = mol_bonds[0][j]
                    j_idx = mol_bonds[1][j]
                    func = mol_bonds[2][j]
                    p1 = mol_bonds[3][j]
                    p2 = mol_bonds[4][j]
                    # Handle None values - only write parameters if they are not None
                    if p1 is not None and p2 is not None:
                        p1_str = f"{p1:10.5E}"
                        p2_str = f"{p2:10.5E}"
                        itp_str += f"{i_idx:6d} {j_idx:6d} {func:6d} {p1_str} {p2_str}\n"
                    else:
                        itp_str += f"{i_idx:6d} {j_idx:6d} {func:6d}\n"
                itp_str += "\n"
            
            # Write pairs
            if mol_pairs:
                itp_str += "[ pairs ]\n"
                itp_str += ";  ai    aj funct\n"
                for j in range(len(mol_pairs[0])):
                    i_idx = mol_pairs[0][j]
                    j_idx = mol_pairs[1][j]
                    func = mol_pairs[2][j]
                    itp_str += f"{i_idx:6d} {j_idx:6d} {func:6d}\n"
                itp_str += "\n"
            
            # Write angles
            if mol_angles:
                itp_str += "[ angles ]\n"
                itp_str += ";  ai    aj    ak funct    theta    cth\n"
                for j in range(len(mol_angles[0])):
                    i_idx = mol_angles[0][j]
                    j_idx = mol_angles[1][j]
                    k_idx = mol_angles[2][j]
                    func = mol_angles[3][j]
                    p1 = mol_angles[4][j]
                    p2 = mol_angles[5][j]
                    # Handle None values - only write parameters if they are not None
                    if p1 is not None and p2 is not None:
                        p1_str = f"{p1:8.3f}"
                        p2_str = f"{p2:10.5E}"
                        itp_str += f"{i_idx:6d} {j_idx:6d} {k_idx:6d} {func:6d} {p1_str} {p2_str}\n"
                    else:
                        itp_str += f"{i_idx:6d} {j_idx:6d} {k_idx:6d} {func:6d}\n"
                itp_str += "\n"
            
            # Write dihedrals
            if mol_dihedrals:
                # Group dihedrals by function type
                dihedrals_by_func = {}
                for j in range(len(mol_dihedrals[0])):
                    func = mol_dihedrals[4][j]
                    if func not in dihedrals_by_func:
                        dihedrals_by_func[func] = []
                    dihedrals_by_func[func].append(j)
                
                # Write each function type in a separate section
                for func, indices in dihedrals_by_func.items():
                    itp_str += "[ dihedrals ]\n"
                    # Write header based on function type
                    if func in [1, 4, 9]:  # Format 1
                        itp_str += ";  ai    aj    ak    al funct    phi0       cp     mult\n"
                    elif func == 2:  # Format 2
                        itp_str += ";  ai    aj    ak    al funct    param1    param2\n"
                    elif func == 3:  # Format 3
                        itp_str += ";  ai    aj    ak    al funct    C0       C1       C2       C3       C4       C5\n"
                    
                    for j in indices:
                        i_idx = mol_dihedrals[0][j]
                        j_idx = mol_dihedrals[1][j]
                        k_idx = mol_dihedrals[2][j]
                        l_idx = mol_dihedrals[3][j]
                        
                        if func in [1, 4, 9]:  # Format 1
                            phi0 = mol_dihedrals[5][j]
                            cp = mol_dihedrals[6][j]
                            mult = mol_dihedrals[7][j]
                            # Handle None values - only write parameters if they are not None
                            if phi0 is not None and cp is not None and mult is not None:
                                phi0_str = f"{phi0:8.1f}"
                                cp_str = f"{cp:8.5f}"
                                mult_str = f"{mult:6d}"
                                itp_str += f"{i_idx:6d} {j_idx:6d} {k_idx:6d} {l_idx:6d} {func:6d} {phi0_str} {cp_str} {mult_str}\n"
                            else:
                                itp_str += f"{i_idx:6d} {j_idx:6d} {k_idx:6d} {l_idx:6d} {func:6d}\n"
                        elif func == 2:  # Format 2
                            p1 = mol_dihedrals[8][j]
                            p2 = mol_dihedrals[9][j]
                            # Handle None values - only write parameters if they are not None
                            if p1 is not None and p2 is not None:
                                p1_str = f"{p1:8.3f}"
                                p2_str = f"{p2:10.5E}"
                                itp_str += f"{i_idx:6d} {j_idx:6d} {k_idx:6d} {l_idx:6d} {func:6d} {p1_str} {p2_str}\n"
                            else:
                                itp_str += f"{i_idx:6d} {j_idx:6d} {k_idx:6d} {l_idx:6d} {func:6d}\n"
                        elif func == 3:  # Format 3
                            c0, c1, c2, c3, c4, c5 = [mol_dihedrals[k][j] for k in range(10, 16)]
                            # Handle None values - only write parameters if they are not None
                            if all(x is not None for x in [c0, c1, c2, c3, c4, c5]):
                                c0_str = f"{c0:8.5f}"
                                c1_str = f"{c1:8.5f}"
                                c2_str = f"{c2:8.5f}"
                                c3_str = f"{c3:8.5f}"
                                c4_str = f"{c4:8.5f}"
                                c5_str = f"{c5:8.5f}"
                                itp_str += f"{i_idx:6d} {j_idx:6d} {k_idx:6d} {l_idx:6d} {func:6d} {c0_str} {c1_str} {c2_str} {c3_str} {c4_str} {c5_str}\n"
                            else:
                                itp_str += f"{i_idx:6d} {j_idx:6d} {k_idx:6d} {l_idx:6d} {func:6d}\n"
                    itp_str += "\n"
            
            # Write the .itp file
            if itp_file in self.written_files:
                with open(itp_file, 'a') as f:
                    f.write(itp_str)
            else:
                with open(itp_file, 'w') as f:
                    f.write(itp_str)
                self.written_files.append(itp_file)
        
        if self.written_files:
            logging.info(f'Successfully wrote .itp files for molecules containing QM atoms: {", ".join(str(f) for f in self.written_files)}')
        else:
            logging.warning('No molecules containing QM atoms found')
            
    def _fill_missing_parameters_from_force_field(self):
        """Fill missing parameters in QM interactions using force field parameters
        
        This method looks up missing parameters for bonds, angles, and dihedrals
        that have None parameters by using atom types to find matching force field parameters.
        """
        if not self.qm_interactions:
            return
        
        # Get available force fields
        available_force_fields = self.top.topol_dict.list_force_fields()
        if not available_force_fields:
            logging.debug('No force field parameters available for filling missing parameters')
            return
        
        # Get atom types for QM atoms - use the qm_atoms dataframe directly
        if self.boundary_atoms.empty:
            qm_atoms = self.qm_atoms
        else:
            qm_atoms = self.extended_qm_atoms
        qm_atom_types = {}
        for seq_idx in range(len(qm_atoms)):
            qm_atom_types[seq_idx] = qm_atoms.iloc[seq_idx]['type']
        
        # Fill missing bond parameters
        for bond in self.qm_interactions['bonds']:
            if None in bond['parameters']:
                atom1, atom2 = bond['atoms']
                type1 = qm_atom_types.get(atom1)
                type2 = qm_atom_types.get(atom2)
                
                if type1 and type2:
                    # Try both orderings of atom types
                    key1 = f"{type1}-{type2}"
                    key2 = f"{type2}-{type1}"
                    
                    bond_params = None
                    for ff_name in available_force_fields:
                        ff_bondtypes = self.top.topol_dict.get_force_field_bondtypes(ff_name)
                        if key1 in ff_bondtypes:
                            bond_params = ff_bondtypes[key1]
                            break
                        elif key2 in ff_bondtypes:
                            bond_params = ff_bondtypes[key2]
                            break
                    
                    if bond_params:
                        bond['parameters'] = [bond_params['length'] * nm_to_au, bond_params['force_constant'] * kb_gmx2au]
                        bond['source'] = f'force_field_{ff_name}'
                        logging.debug(f'Filled missing bond parameters for atoms {atom1}-{atom2} from force field')
        
        # Fill missing angle parameters
        for angle in self.qm_interactions['angles']:
            if None in angle['parameters']:
                atom1, atom2, atom3 = angle['atoms']
                type1 = qm_atom_types.get(atom1)
                type2 = qm_atom_types.get(atom2)
                type3 = qm_atom_types.get(atom3)
                
                if type1 and type2 and type3:
                    # Try different orderings of atom types
                    keys = [
                        f"{type1}-{type2}-{type3}",
                        f"{type3}-{type2}-{type1}"
                    ]
                    
                    angle_params = None
                    for ff_name in available_force_fields:
                        ff_angletypes = self.top.topol_dict.get_force_field_angletypes(ff_name)
                        for key in keys:
                            if key in ff_angletypes:
                                angle_params = ff_angletypes[key]
                                break
                        if angle_params:
                            break
                    
                    if angle_params:
                        angle['parameters'] = [np.deg2rad(angle_params['angle']), angle_params['force_constant'] * kjm_au]
                        angle['source'] = f'force_field_{ff_name}'
                        logging.debug(f'Filled missing angle parameters for atoms {atom1}-{atom2}-{atom3} from force field')
        
        # Fill missing dihedral parameters
        for dihedral in self.qm_interactions['dihedrals']:
            if None in dihedral['parameters']:
                atom1, atom2, atom3, atom4 = dihedral['atoms']
                type1 = qm_atom_types.get(atom1)
                type2 = qm_atom_types.get(atom2)
                type3 = qm_atom_types.get(atom3)
                type4 = qm_atom_types.get(atom4)
                
                if type1 and type2 and type3 and type4:
                    # Try different orderings of atom types for dihedrals
                    keys = [
                        f"{type1}-{type2}-{type3}-{type4}",
                        f"{type4}-{type3}-{type2}-{type1}"
                    ]
                    
                    dihedral_params = None
                    for ff_name in available_force_fields:
                        ff_dihedraltypes = self.top.topol_dict.get_force_field_dihedraltypes(ff_name)
                        
                        # First try exact matches
                        for key in keys:
                            if key in ff_dihedraltypes:
                                dihedral_params = ff_dihedraltypes[key]
                                break
                        
                        # If no exact match, try wildcard matches
                        if not dihedral_params:
                            dihedral_params = self._find_wildcard_dihedral_params(
                                type1, type2, type3, type4, ff_dihedraltypes
                            )
                        
                        if dihedral_params:
                            break
                    
                    if dihedral_params:
                        func = dihedral['function']
                        if func in [1, 4, 9]:  # Format 1
                            dihedral['parameters'] = [
                                np.deg2rad(dihedral_params['phi0']), 
                                dihedral_params['cp'] * kjm_au, 
                                dihedral_params['mult']
                            ]
                        elif func == 2:  # Format 2
                            dihedral['parameters'] = [
                                dihedral_params['param1'], 
                                dihedral_params['param2'] * kjm_au
                            ]
                        elif func == 3:  # Format 3
                            # For format 3, the parameters are stored as a list
                            params = dihedral_params['params']
                            dihedral['parameters'] = [p * kjm_au for p in params]
                        dihedral['source'] = f'force_field_{ff_name}'
                        logging.debug(f'Filled missing dihedral parameters for atoms {atom1}-{atom2}-{atom3}-{atom4} (types: {type1}-{type2}-{type3}-{type4}) from force field')
                    else:
                        # Add debugging information for unfilled dihedrals
                        logging.debug(f'Could not find dihedral parameters for atoms {atom1}-{atom2}-{atom3}-{atom4} (types: {type1}-{type2}-{type3}-{type4}) in any force field')
                    
                    # If not found in dihedraltypes, try to resolve named parameters
                    if not dihedral_params:
                        parameter_definitions = self.top.topol_dict.get_parameter_definitions()
                        if parameter_definitions:
                            # Try to resolve named parameters by matching residue and atom names
                            # Get residue and atom information for the dihedral atoms
                            resolved_params = self._resolve_named_dihedral_parameters(
                                atom1, atom2, atom3, atom4, 
                                dihedral['function'], 
                                parameter_definitions
                            )
                            if resolved_params:
                                dihedral['parameters'] = resolved_params
                                dihedral['source'] = 'named_parameters'
                                logging.debug(f'Filled missing dihedral parameters for atoms {atom1}-{atom2}-{atom3}-{atom4} from named parameters')

    def _resolve_named_dihedral_parameters(self, atom1_idx, atom2_idx, atom3_idx, atom4_idx, func, parameter_definitions):
        """Resolve named dihedral parameters by matching residue and atom names
        
        Args:
            atom1_idx, atom2_idx, atom3_idx, atom4_idx: Sequential QM atom indices
            func: Dihedral function type
            parameter_definitions: Dictionary of parameter definitions
            
        Returns:
            list: Resolved parameters or None if not found
        """
        # Convert sequential indices back to GROMACS indices
        gmx_idx1 = self.qm_atoms.index[atom1_idx]
        gmx_idx2 = self.qm_atoms.index[atom2_idx]
        gmx_idx3 = self.qm_atoms.index[atom3_idx]
        gmx_idx4 = self.qm_atoms.index[atom4_idx]
        
        # Get residue and atom information for each atom
        atom_info = []
        for gmx_idx in [gmx_idx1, gmx_idx2, gmx_idx3, gmx_idx4]:
            # Find which molecule this atom belongs to
            for mol, n_mols in self.top.molecules:
                mol_size = len(self.top.topol_dict[mol])
                mol_offset = 0
                for mol_idx in range(n_mols):
                    mol_start = mol_offset + 1
                    mol_end = mol_offset + mol_size
                    if mol_start <= gmx_idx <= mol_end:
                        # Found the molecule, get atom info
                        local_idx = gmx_idx - mol_start + 1
                        atom_row = self.top.topol_dict[mol].loc[local_idx]
                        atom_info.append({
                            'resname': atom_row['resname'],
                            'name': atom_row['name']
                        })
                        break
                    mol_offset += mol_size
                if len(atom_info) == len([gmx_idx1, gmx_idx2, gmx_idx3, gmx_idx4]):
                    break
            if len(atom_info) == len([gmx_idx1, gmx_idx2, gmx_idx3, gmx_idx4]):
                break
        
        if len(atom_info) != 4:
            return None
        
        # Try to match with parameter definitions
        # Format: torsion_RES_ATOM1_ATOM2_ATOM3_ATOM4_multN
        resname = atom_info[0]['resname']  # Use first atom's residue
        atom_names = [info['name'] for info in atom_info]
        
        # Try different combinations of atom names
        # For dihedrals, we need to try both forward and reverse orderings
        name_combinations = [
            f"torsion_{resname}_{atom_names[0]}_{atom_names[1]}_{atom_names[2]}_{atom_names[3]}",
            f"torsion_{resname}_{atom_names[3]}_{atom_names[2]}_{atom_names[1]}_{atom_names[0]}"
        ]
        
        # Look for matching parameter definitions
        for base_name in name_combinations:
            # Try different multiplicities (mult1, mult2, mult3, etc.)
            for mult in range(1, 7):  # Usually up to mult6
                param_name = f"{base_name}_mult{mult}"
                if param_name in parameter_definitions:
                    param_values = parameter_definitions[param_name]
                    if len(param_values) >= 3:
                        # Parse the parameter values
                        try:
                            phi0 = float(param_values[0])
                            force_constant = float(param_values[1])
                            multiplicity = int(param_values[2])
                            
                            # Convert to appropriate units based on function type
                            if func in [1, 4, 9]:  # Format 1
                                return [
                                    np.deg2rad(phi0),  # Convert to radians
                                    force_constant * kjm_au,  # Convert to atomic units
                                    multiplicity
                                ]
                            elif func == 2:  # Format 2
                                return [
                                    phi0,  # Keep as is
                                    force_constant * kjm_au  # Convert to atomic units
                                ]
                            elif func == 3:  # Format 3
                                # For format 3, we might need to expand the parameters
                                # This is more complex and depends on the specific force field
                                logging.debug(f'Format 3 dihedral with named parameters not fully implemented for {param_name}')
                                return None
                        except (ValueError, IndexError) as e:
                            logging.debug(f'Error parsing parameter values for {param_name}: {e}')
                            continue
        
        return None

    def _find_wildcard_dihedral_params(self, type1, type2, type3, type4, ff_dihedraltypes):
        """Find dihedral parameters using hierarchical wildcard matching
        
        This function implements a hierarchy of specificity for dihedral parameter matching:
        1. Exact match (most specific)
        2. Single wildcard replacements (X or *)
        3. Double wildcard replacements
        4. Triple wildcard replacements
        5. All wildcards (least specific)
        
        For peptide bonds and similar cases, this ensures that more specific parameters
        (like X-C-N-X for peptide bonds) are used instead of generic ones.
        
        Args:
            type1, type2, type3, type4: Atom types
            ff_dihedraltypes: Dictionary of dihedral types from force field
            
        Returns:
            dict: Dihedral parameters or None if not found
        """
        # Try forward and reverse orderings
        type_combinations = [
            [type1, type2, type3, type4],
            [type4, type3, type2, type1]
        ]
        
        best_match = None
        best_specificity = -1  # Higher number = more specific
        
        for types in type_combinations:
            # 1. Try exact match (specificity = 4)
            key = f"{types[0]}-{types[1]}-{types[2]}-{types[3]}"
            if key in ff_dihedraltypes:
                logging.debug(f'Found exact match for dihedral {key}')
                return ff_dihedraltypes[key]  # Most specific, return immediately
            
            # 2. Try single wildcard replacements (specificity = 3)
            for i in range(4):
                for wildcard in ['X', '*']:
                    wildcard_types = types.copy()
                    wildcard_types[i] = wildcard
                    key = f"{wildcard_types[0]}-{wildcard_types[1]}-{wildcard_types[2]}-{wildcard_types[3]}"
                    if key in ff_dihedraltypes:
                        if best_specificity < 3:
                            best_match = ff_dihedraltypes[key]
                            best_specificity = 3
                            logging.debug(f'Found single wildcard match for dihedral {key} (specificity=3)')
            
            # 3. Try double wildcard replacements (specificity = 2)
            for i in range(4):
                for j in range(i+1, 4):
                    for wildcard in ['X', '*']:
                        wildcard_types = types.copy()
                        wildcard_types[i] = wildcard
                        wildcard_types[j] = wildcard
                        key = f"{wildcard_types[0]}-{wildcard_types[1]}-{wildcard_types[2]}-{wildcard_types[3]}"
                        if key in ff_dihedraltypes:
                            if best_specificity < 2:
                                best_match = ff_dihedraltypes[key]
                                best_specificity = 2
                                logging.debug(f'Found double wildcard match for dihedral {key} (specificity=2)')
            
            # 4. Try triple wildcard replacements (specificity = 1)
            for i in range(4):
                for j in range(i+1, 4):
                    for k in range(j+1, 4):
                        for wildcard in ['X', '*']:
                            wildcard_types = types.copy()
                            wildcard_types[i] = wildcard
                            wildcard_types[j] = wildcard
                            wildcard_types[k] = wildcard
                            key = f"{wildcard_types[0]}-{wildcard_types[1]}-{wildcard_types[2]}-{wildcard_types[3]}"
                            if key in ff_dihedraltypes:
                                if best_specificity < 1:
                                    best_match = ff_dihedraltypes[key]
                                    best_specificity = 1
                                    logging.debug(f'Found triple wildcard match for dihedral {key} (specificity=1)')
            
            # 5. Try all wildcards (specificity = 0)
            for wildcard in ['X', '*']:
                key = f"{wildcard}-{wildcard}-{wildcard}-{wildcard}"
                if key in ff_dihedraltypes:
                    if best_specificity < 0:
                        best_match = ff_dihedraltypes[key]
                        best_specificity = 0
                        logging.debug(f'Found all wildcard match for dihedral {key} (specificity=0)')
        
        return best_match

    

    def extract_qm_interactions(self):
        """Extract all bonded interactions involving QM atoms from the topology
        
        This function handles both molecule-specific interactions (defined in .itp files)
        and force field interactions (defined in force field files and stored in topol_dict).
        It includes interactions where at least one atom is in the QM region.
        
        Returns:
            dict: Dictionary containing bonds, angles, and dihedrals involving QM atoms
        """
        if not self.qm_atoms is not None:
            raise MiMiCPyError('No QM atoms defined')
        
       
        
        # Get QM atom indices for checking if atoms are QM
        qm_indices = set(self.qm_atoms.index)
        
        # Get boundary atoms if needed
        boundary_indices = set()
        if not self.boundary_atoms.empty:
            boundary_indices = set(self.boundary_atoms.index)
        
            # Get extended QM atoms DataFrame (includes both QM and MM atoms)
            self.extended_qm_atoms = self.get_extended_qm_atoms_dataframe()
        
            # Create mapping from GROMACS atom indices to sequential indices in extended DataFrame
            # This maps GROMACS indices to sequential indices (0, 1, 2, ...) in the extended array
            self.gmx_to_seq_map = {}
            for seq_idx, gmx_idx in enumerate(self.extended_qm_atoms.index):
                self.gmx_to_seq_map[gmx_idx] = seq_idx
           
        else:
            self.gmx_to_seq_map = {gmx_idx: idx for idx, gmx_idx in enumerate(self.qm_atoms.index)}
    
        qm_interactions = {
            'bonds': [],
            'angles': [],
            'dihedrals': []
        }
        
        bonded_count = 0
        prev_natoms = 0
        for mol, n_mols in self.top.molecules:
            # Get interactions for this molecule
            mol_bonds = self.top.topol_dict.get_bonds(mol)
            mol_angles = self.top.topol_dict.get_angles(mol)
            mol_dihedrals = self.top.topol_dict.get_dihedrals(mol)
            
            # Get atom types for this molecule
            mol_atoms = self.top.topol_dict[mol]
            
            # Process bonds
            if mol_bonds:
                for j in range(len(mol_bonds[0])):
                    i_idx = mol_bonds[0][j] + prev_natoms
                    j_idx = mol_bonds[1][j] + prev_natoms
                    # Include bonds where at least one atom is in QM region
                    if i_idx in qm_indices or j_idx in qm_indices:
                        # Convert GROMACS indices to sequential indices in extended array
                        seq_i = self.gmx_to_seq_map[i_idx]
                        seq_j = self.gmx_to_seq_map[j_idx]
                        
                        # Check if bond involves boundary atoms
                        involves_boundary = (i_idx in boundary_indices or j_idx in boundary_indices) if not self.boundary_atoms.empty else False
                        
                        # Handle None parameters (bonds without explicit parameters)
                        param1 = mol_bonds[3][j]
                        param2 = mol_bonds[4][j]
                        
                        if param1 is not None and param2 is not None:
                            parameters = [param1 * nm_to_au, param2 * kb_gmx2au]
                        else:
                            # Parameters not available, will be filled from force field later
                            parameters = [None, None]
                        
                
                        qm_interactions['bonds'].append({
                            'atoms': [seq_i, seq_j],  # Use sequential indices
                            'function': mol_bonds[2][j],
                            'parameters': parameters,
                            'index': bonded_count,
                            'optimize': not involves_boundary,  # Don't optimize if involves boundary
                            'involves_boundary': involves_boundary,
                            'involves_mm': (i_idx not in qm_indices or j_idx not in qm_indices),
                            'molecule': mol
                        })
                        bonded_count += 1
            
            # Process angles
            if mol_angles:
                for j in range(len(mol_angles[0])):
                    i_idx = mol_angles[0][j] + prev_natoms
                    j_idx = mol_angles[1][j] + prev_natoms
                    k_idx = mol_angles[2][j] + prev_natoms
                    # Include angles where at least one atom is in QM region
                    if i_idx in qm_indices or j_idx in qm_indices or k_idx in qm_indices:
                        # Convert GROMACS indices to sequential indices in extended array
                        seq_i = self.gmx_to_seq_map[i_idx]
                        seq_j = self.gmx_to_seq_map[j_idx]
                        seq_k = self.gmx_to_seq_map[k_idx]
                        
                        # Check if angle involves boundary atoms
                        involves_boundary = (i_idx in boundary_indices or j_idx in boundary_indices or k_idx in boundary_indices) if not self.boundary_atoms.empty else False
                        
                        # Handle None parameters (angles without explicit parameters)
                        param1 = mol_angles[4][j]
                        param2 = mol_angles[5][j]
                        
                        if param1 is not None and param2 is not None:
                            parameters = [np.deg2rad(param1), param2 * kjm_au]
                        else:
                            # Parameters not available, will be filled from force field later
                            parameters = [None, None]
                        
                        qm_interactions['angles'].append({
                            'atoms': [seq_i, seq_j, seq_k],  # Use sequential indices
                            'function': mol_angles[3][j],
                            'parameters': parameters,
                            'index': bonded_count,
                            'optimize': not involves_boundary,  # Don't optimize if involves boundary
                            'involves_boundary': involves_boundary,
                            'involves_mm': (i_idx not in qm_indices or j_idx not in qm_indices or k_idx not in qm_indices),
                            'molecule': mol
                        })
                        bonded_count += 1
            
            # Process dihedrals
            if mol_dihedrals:
                for j in range(len(mol_dihedrals[0])):
                    i_idx = mol_dihedrals[0][j] + prev_natoms
                    j_idx = mol_dihedrals[1][j] + prev_natoms
                    k_idx = mol_dihedrals[2][j] + prev_natoms
                    l_idx = mol_dihedrals[3][j] + prev_natoms
                    # Include dihedrals where at least one atom is in QM region
                    if i_idx in qm_indices or j_idx in qm_indices or k_idx in qm_indices or l_idx in qm_indices:
                        # Convert GROMACS indices to sequential indices in extended array
                        seq_i = self.gmx_to_seq_map[i_idx]
                        seq_j = self.gmx_to_seq_map[j_idx]
                        seq_k = self.gmx_to_seq_map[k_idx]
                        seq_l = self.gmx_to_seq_map[l_idx]
                        
                        # Check if dihedral involves boundary atoms
                        involves_boundary = (i_idx in boundary_indices or j_idx in boundary_indices or k_idx in boundary_indices or l_idx in boundary_indices) if not self.boundary_atoms.empty else False
                        
                        func = mol_dihedrals[4][j]
                        if func in [1, 4, 9]:  # Format 1
                            # Handle None parameters for dihedrals
                            phi0 = mol_dihedrals[5][j]
                            cp = mol_dihedrals[6][j]
                            mult = mol_dihedrals[7][j]
                            
                            if phi0 is not None and cp is not None and mult is not None:
                                parameters = [np.deg2rad(phi0), cp * kjm_au, mult]
                            else:
                                parameters = [None, None, None]
                            
                            qm_interactions['dihedrals'].append({
                                'atoms': [seq_i, seq_j, seq_k, seq_l],  # Use sequential indices
                                'function': func,
                                'parameters': parameters,
                                'index': bonded_count,
                                'optimize': not involves_boundary,  # Don't optimize if involves boundary
                                'involves_boundary': involves_boundary,
                                'involves_mm': (i_idx not in qm_indices or j_idx not in qm_indices or k_idx not in qm_indices or l_idx not in qm_indices),
                                'molecule': mol
                            })
                        elif func == 2:  # Format 2
                            # Handle None parameters for dihedrals
                            p1 = mol_dihedrals[8][j]
                            p2 = mol_dihedrals[9][j]
                            
                            if p1 is not None and p2 is not None:
                                parameters = [p1, p2 * kjm_au]
                            else:
                                parameters = [None, None]
                            
                            qm_interactions['dihedrals'].append({
                                'atoms': [seq_i, seq_j, seq_k, seq_l],  # Use sequential indices
                                'function': func,
                                'parameters': parameters,
                                'index': bonded_count,
                                'optimize': not involves_boundary,  # Don't optimize if involves boundary
                                'involves_boundary': involves_boundary,
                                'involves_mm': (i_idx not in qm_indices or j_idx not in qm_indices or k_idx not in qm_indices or l_idx not in qm_indices),
                                'molecule': mol
                            })
                        elif func == 3:  # Format 3
                            # Handle None parameters for dihedrals
                            c_params = [mol_dihedrals[10+k][j] for k in range(6)]
                            if all(p is not None for p in c_params):
                                parameters = [p * kjm_au for p in c_params]
                            else:
                                parameters = [None] * 6
                            
                            qm_interactions['dihedrals'].append({
                                'atoms': [seq_i, seq_j, seq_k, seq_l],  # Use sequential indices
                                'function': func,
                                'parameters': parameters,
                                'index': bonded_count,
                                'optimize': not involves_boundary,  # Don't optimize if involves boundary
                                'involves_boundary': involves_boundary,
                                'involves_mm': (i_idx not in qm_indices or j_idx not in qm_indices or k_idx not in qm_indices or l_idx not in qm_indices),
                                'molecule': mol
                            })
                        bonded_count += 1
            
            prev_natoms += len(self.top.topol_dict[mol]) * n_mols
        
        self.qm_interactions = qm_interactions
        
        # Log statistics
        total_bonds = len(qm_interactions["bonds"])
        total_angles = len(qm_interactions["angles"])
        total_dihedrals = len(qm_interactions["dihedrals"])
        
        if not self.boundary_atoms.empty:
            boundary_bonds = sum(1 for bond in qm_interactions["bonds"] if bond['involves_boundary'])
            boundary_angles = sum(1 for angle in qm_interactions["angles"] if angle['involves_boundary'])
            boundary_dihedrals = sum(1 for dihedral in qm_interactions["dihedrals"] if dihedral['involves_boundary'])
            
            logging.info(f'Extracted QM interactions: {total_bonds} bonds ({boundary_bonds} boundary), '
                        f'{total_angles} angles ({boundary_angles} boundary), '
                        f'{total_dihedrals} dihedrals ({boundary_dihedrals} boundary)')
        else:
            logging.info(f'Extracted QM interactions: {total_bonds} bonds, '
                        f'{total_angles} angles, '
                        f'{total_dihedrals} dihedrals')
        
        # Fill missing parameters from force field
        self._fill_missing_parameters_from_force_field()
        
        return self.qm_interactions

    def gmx_to_cpmd_idx(self):
        """Convert GROMACS atom indices to CPMD indices for all atoms (QM and MM),
        using the same logic as CpmdScript.gmx_to_cpmd_idx.
        
        Returns:
            dict: Dictionary mapping GROMACS atom indices to CPMD indices
        """
        if not self.qm_atoms is not None:
            raise MiMiCPyError('No QM atoms defined')
        
        # Get topology data from Mpt object
        topol = self.mpt.select('all')
        typelist = topol['type'].unique()  # get list of types used in order
        
        # Get atomtypes section from GROMACS topology
        atomtypes = self.top.atom_types_df.set_index(['type']).loc[typelist]
        
        # Convert atomtypes to type ID
        type_id = {}
        count = 0
        for i, rowi in atomtypes.iterrows():
            for j, rowj in atomtypes.iterrows():
                if i == j:
                    type_id[i] = count
                    count += 1
                    break
                if (rowi['X'] == rowj['X']) and isclose(rowi['sigma'], rowj['sigma']) and isclose(rowi['epsilon'], rowj['epsilon']):
                    type_id[i] = type_id[j]
                    break
        
        topol.insert(2, "type_id", [type_id[i] for i in topol['type']], True)
        
        # get Gromacs IDs to QM atoms & push their type_ids first
        overlaps = []
        if hasattr(self, 'prep') and self.prep is not None:
            # Try to get overlaps from the same logic as CPMD input
            sorted_qm_atoms = self.qm_atoms.sort_values(by=['is_bound', 'element']).reset_index()
            natms = len(sorted_qm_atoms)
            for i, row in sorted_qm_atoms.iterrows():
                idx = row['id']
                topol.at[idx, 'type_id'] = -natms + i
        
        # sort topol by type_id and gromacs id and get a dict of Gromacs IDs to CPMD IDs
        topol = topol.reset_index()
        topol.sort_values(by=['type_id', 'id'], inplace=True)
        cpmd_idx = list(range(1, self.mpt.number_of_atoms + 1))
        gmx_idx = topol['id'].to_list()
        return dict(zip(gmx_idx, cpmd_idx))

    def update_topology(self, ff_optimize, bond2params):
        """Update the system's topology with optimized parameters from force matching
        
        Args:
            ff_optimize (numpy.ndarray): Array of optimized force field parameters
            bond2params (dict): Mapping of interaction indices to parameter indices in ff_optimize
            
        Returns:
            bool: True if update was successful, False otherwise
        """
        if not hasattr(self, 'qm_interactions'):
            raise MiMiCPyError('No QM interactions defined. Call extract_qm_interactions() first.')
            
        try:
            # Get QM interactions
            qm_interactions = self.qm_interactions
            
            # Update bonds
            for bond in qm_interactions['bonds']:
                params_idx = bond2params.get(bond['index'])
                if params_idx is not None:
                    if params_idx[0] is not None:  # Length parameter
                        bond['parameters'][0] = ff_optimize[params_idx[0]] * au_to_nm
                    else:
                        bond['parameters'][0] = bond['parameters'][0] * au_to_nm  # Convert non-optimized parameter
                    if params_idx[1] is not None:  # Force constant
                        bond['parameters'][1] = ff_optimize[params_idx[1]] * kb_au2gmx
                    else:
                        bond['parameters'][1] = bond['parameters'][1] * kb_au2gmx  # Convert non-optimized parameter
            
            # Update angles
            for angle in qm_interactions['angles']:
                params_idx = bond2params.get(angle['index'])
                if params_idx is not None:
                    if params_idx[0] is not None:  # Angle parameter
                        angle['parameters'][0] = np.rad2deg(np.arccos(np.cos(ff_optimize[params_idx[0]])))
                    else:
                        angle['parameters'][0] = np.rad2deg(np.arccos(np.cos(angle['parameters'][0])))  # Convert non-optimized parameter
                    if params_idx[1] is not None:  # Force constant
                        angle['parameters'][1] = ff_optimize[params_idx[1]] * au_kjm
                    else:
                        angle['parameters'][1] = angle['parameters'][1] * au_kjm  # Convert non-optimized parameter
            
            # Update dihedrals
            for dihedral in qm_interactions['dihedrals']:
                params_idx = bond2params.get(dihedral['index'])
                if params_idx is not None:
                    if dihedral['function'] in [1, 4, 9]:  # Format 1
                        if params_idx[0] is not None:  # phi0
                            dihedral['parameters'][0] = np.rad2deg(ff_optimize[params_idx[0]])
                        else:
                            dihedral['parameters'][0] = np.rad2deg(dihedral['parameters'][0])  # Convert non-optimized parameter
                        if params_idx[1] is not None:  # cp (force constant)
                            dihedral['parameters'][1] = ff_optimize[params_idx[1]] * au_kjm
                        else:
                            dihedral['parameters'][1] = dihedral['parameters'][1] * au_kjm  # Convert non-optimized parameter
                        if params_idx[2] is not None:  # mult
                            dihedral['parameters'][2] = ff_optimize[params_idx[2]]
                    elif dihedral['function'] == 2:  # Format 2
                        if params_idx[0] is not None:  # param1
                            dihedral['parameters'][0] = ff_optimize[params_idx[0]]
                        if params_idx[1] is not None:  # param2 (force constant)
                            dihedral['parameters'][1] = ff_optimize[params_idx[1]]
                    elif dihedral['function'] == 3:  # Format 3
                        for i in range(6):
                            if params_idx[i] is not None:
                                dihedral['parameters'][i] = ff_optimize[params_idx[i]] * au_kjm
                            else:
                                dihedral['parameters'][i] = dihedral['parameters'][i] * au_kjm  # Convert non-optimized parameter
            # Update the topology dictionary with new parameters
            prev_natoms = 0
            
            # Create reverse mapping from sequential indices back to GROMACS indices
            if self.boundary_atoms.empty:
                seq_to_gmx_map = {}
                for seq_idx, gmx_idx in enumerate(self.qm_atoms.index):
                    seq_to_gmx_map[seq_idx] = gmx_idx
            else:
                seq_to_gmx_map = {}
                for seq_idx, gmx_idx in enumerate(self.extended_qm_atoms.index):
                    seq_to_gmx_map[seq_idx] = gmx_idx
            
            for mol, n_mols in self.top.molecules:
                # Update bonds
                mol_bonds = self.top.topol_dict.get_bonds(mol)
                if mol_bonds:
                    for j in range(len(mol_bonds[0])):
                        i_idx = mol_bonds[0][j] + prev_natoms
                        j_idx = mol_bonds[1][j] + prev_natoms
                        # Find matching bond in qm_interactions
                        for bond in qm_interactions['bonds']:
                            # Convert sequential indices back to GROMACS indices for comparison
                            bond_i_gmx = seq_to_gmx_map.get(bond['atoms'][0], bond['atoms'][0] + 1)
                            bond_j_gmx = seq_to_gmx_map.get(bond['atoms'][1], bond['atoms'][1] + 1)
                            
                            if (bond_i_gmx == i_idx and bond_j_gmx == j_idx) or \
                               (bond_i_gmx == j_idx and bond_j_gmx == i_idx):
                                mol_bonds[3][j] = bond['parameters'][0]  # param1
                                mol_bonds[4][j] = bond['parameters'][1]  # param2
                                break
                
                # Update angles
                mol_angles = self.top.topol_dict.get_angles(mol)
                if mol_angles:
                    for j in range(len(mol_angles[0])):
                        i_idx = mol_angles[0][j] + prev_natoms
                        j_idx = mol_angles[1][j] + prev_natoms
                        k_idx = mol_angles[2][j] + prev_natoms
                        # Find matching angle in qm_interactions
                        for angle in qm_interactions['angles']:
                            # Convert sequential indices back to GROMACS indices for comparison
                            angle_i_gmx = seq_to_gmx_map.get(angle['atoms'][0], angle['atoms'][0] + 1)
                            angle_j_gmx = seq_to_gmx_map.get(angle['atoms'][1], angle['atoms'][1] + 1)
                            angle_k_gmx = seq_to_gmx_map.get(angle['atoms'][2], angle['atoms'][2] + 1)
                            
                            if (angle_i_gmx == i_idx and 
                                angle_j_gmx == j_idx and 
                                angle_k_gmx == k_idx):
                                mol_angles[4][j] = angle['parameters'][0]  # param1
                                mol_angles[5][j] = angle['parameters'][1]  # param2
                                break
                
                # Update dihedrals
                mol_dihedrals = self.top.topol_dict.get_dihedrals(mol)
                if mol_dihedrals:
                    for j in range(len(mol_dihedrals[0])):
                        i_idx = mol_dihedrals[0][j] + prev_natoms
                        j_idx = mol_dihedrals[1][j] + prev_natoms
                        k_idx = mol_dihedrals[2][j] + prev_natoms
                        l_idx = mol_dihedrals[3][j] + prev_natoms
                        # Find matching dihedral in qm_interactions
                        for dihedral in qm_interactions['dihedrals']:
                            # Convert sequential indices back to GROMACS indices for comparison
                            dihedral_i_gmx = seq_to_gmx_map.get(dihedral['atoms'][0], dihedral['atoms'][0] + 1)
                            dihedral_j_gmx = seq_to_gmx_map.get(dihedral['atoms'][1], dihedral['atoms'][1] + 1)
                            dihedral_k_gmx = seq_to_gmx_map.get(dihedral['atoms'][2], dihedral['atoms'][2] + 1)
                            dihedral_l_gmx = seq_to_gmx_map.get(dihedral['atoms'][3], dihedral['atoms'][3] + 1)
                            
                            if (dihedral_i_gmx == i_idx and 
                                dihedral_j_gmx == j_idx and 
                                dihedral_k_gmx == k_idx and 
                                dihedral_l_gmx == l_idx):
                                func = dihedral['function']
                                if func in [1, 4, 9]:  # Format 1
                                    mol_dihedrals[5][j] = dihedral['parameters'][0]  # phi0
                                    mol_dihedrals[6][j] = dihedral['parameters'][1]  # cp
                                    mol_dihedrals[7][j] = dihedral['parameters'][2]  # mult
                                elif func == 2:  # Format 2
                                    mol_dihedrals[8][j] = dihedral['parameters'][0]  # param1
                                    mol_dihedrals[9][j] = dihedral['parameters'][1]  # param2
                                elif func == 3:  # Format 3
                                    for k in range(6):
                                        mol_dihedrals[10+k][j] = dihedral['parameters'][k]  # C0-C5
                                break
                
                prev_natoms += len(self.top.topol_dict[mol]) * n_mols
            
            logging.info('Successfully updated topology with optimized QM interaction parameters')
            return True
            
        except Exception as e:
            logging.error(f'Failed to update topology: {str(e)}')
            return False

    
    def update_qm_charges(self, new_charges):
        """Update the topology with new charges for QM atoms
        
        Args:
            new_charges (dict or pandas.Series or np.ndarray or list): New charges for QM atoms.
                If dict, keys should be QM atom indices and values should be charges.
                If Series, index should be QM atom indices and values should be charges.
                If array or list, it should be in the same order as self.qm_atoms.index.
        
        Returns:
            bool: True if update was successful, False otherwise
        """
        if not self.qm_atoms is not None:
            raise MiMiCPyError('No QM atoms defined')
        
        # Convert input to pandas Series if it's a dict, numpy array, or list
        if isinstance(new_charges, dict):
            new_charges = pd.Series(new_charges)
        elif isinstance(new_charges, (list, np.ndarray)):
            new_charges = pd.Series(new_charges, index=self.qm_atoms.index)
        # Verify all QM atoms have new charges
        missing_atoms = set(self.qm_atoms.index) - set(new_charges.index)
        if missing_atoms:
            raise MiMiCPyError(f'Missing charges for QM atoms: {missing_atoms}')
        
        # For each QM atom, find which molecule and which instance it belongs to, and update the charge
        
        
        for idx in self.qm_atoms.index:
            # Find which molecule instance this atom belongs to
            for mol, mol_offset in self.top.mol_offsets:
                mol_len = len(self.top.topol_dict[mol])
                if mol_offset + 1 <= idx <= mol_offset + mol_len:
                    # DataFrame is indexed by GROMACS atom numbers (1-based)
                    local_idx = idx - mol_offset
                    self.top.topol_dict[mol].loc[local_idx, 'charge'] = new_charges[idx]
                    break
        
        
    def write_non_bonded_itp(self, directory='.', prefix='non_bonded'):
        """Write a non-bonded interaction table to a GROMACS .itp file.
        This function modifies only the bonded parameters of QM atoms.
        
        Args:
            directory (str): Directory to write the output .itp file
            prefix (str): Prefix for the output .itp file
            
        Returns:
            bool: True if successful, False otherwise
        """
        if not self.qm_atoms is not None:
            raise MiMiCPyError('No QM atoms defined')
            
    
        # Get QM atom indices
        qm_indices = set(self.qm_atoms.index)
        
        # Create a copy of the topology dictionary
        nonbonded_top = copy.deepcopy(self.top.topol_dict)
        
        # Modify bonded parameters for QM atoms
        prev_natoms = 0
        for mol, n_mols in self.top.molecules:
            # Get interactions for this molecule
            mol_bonds = nonbonded_top.get_bonds(mol)
            mol_angles = nonbonded_top.get_angles(mol)
            mol_dihedrals = nonbonded_top.get_dihedrals(mol)
            
            # Process bonds
            if mol_bonds:
                for j in range(len(mol_bonds[0])):
                    i_idx = mol_bonds[0][j] + prev_natoms
                    j_idx = mol_bonds[1][j] + prev_natoms
                    if i_idx in qm_indices or j_idx in qm_indices:
                        mol_bonds[4][j] = 0.0  # Set force constant to 0
            
            # Process angles
            if mol_angles:
                for j in range(len(mol_angles[0])):
                    i_idx = mol_angles[0][j] + prev_natoms
                    j_idx = mol_angles[1][j] + prev_natoms
                    k_idx = mol_angles[2][j] + prev_natoms
                    if any(idx in qm_indices for idx in [i_idx, j_idx, k_idx]):
                        mol_angles[5][j] = 0.0  # Set force constant to 0
            
        
            # Process dihedrals
            if mol_dihedrals:
                for j in range(len(mol_dihedrals[0])):
                    i_idx = mol_dihedrals[0][j] + prev_natoms
                    j_idx = mol_dihedrals[1][j] + prev_natoms
                    k_idx = mol_dihedrals[2][j] + prev_natoms
                    l_idx = mol_dihedrals[3][j] + prev_natoms
                    if any(idx in qm_indices for idx in [i_idx, j_idx, k_idx, l_idx]):
                        func = mol_dihedrals[4][j]
                        if func == 3:  # Format 3
                            # Set all coefficients C0-C5 to 0
                            for k in range(10, 16):
                                mol_dihedrals[k][j] = 0.0
                        elif func in [1, 4, 9, 2]:  # Format 1, 4, or 9
                            mol_dihedrals[6][j] = 0.0  # Set force constant (cp) to 0
                        
            
            prev_natoms += len(nonbonded_top[mol]) * n_mols
        # Write the modified topology to file
        self.write_topology(directory=directory, prefix=prefix, topol_dict=nonbonded_top)
        

    def get_equivalent_map(self, equivalent_atoms=None, use_atomtypes=False):
        """Create a mapping of equivalent atoms for QM region
        
        Args:
            equivalent_atoms (dict, optional): Dictionary containing equivalent atoms in either global or local format.
                For global format: {'global': [(1,2), (3,4), ...]}
                For local format: {'local': {'mol1': [(1,2), (3,4)], 'mol2': [(1,2)]}}
            use_atomtypes (bool, optional): If True, automatically generate equivalent atom mappings based on atom types.
                This will map atoms with the same atom type to be equivalent.
                
        Returns:
            dict: Mapping of equivalent atoms in contiguous QM indices (0-based)
        """
        if not self.qm_atoms is not None:
            raise MiMiCPyError('No QM atoms defined')
        
        # Create a mapping from global GROMACS indices to contiguous QM indices
        global_to_qm_idx = {global_idx: qm_idx for qm_idx, global_idx in enumerate(self.qm_atoms.index)}
        
        # Initialize mapping with identity mapping for all QM atoms (using contiguous indices)
        eq_mapping = {qm_idx: qm_idx for qm_idx in range(len(self.qm_atoms))}
        
        if use_atomtypes:
            # Group atoms by their atom type using the type column from qm_atoms
            atomtype_groups = {}
            for qm_idx, (global_idx, row) in enumerate(self.qm_atoms.iterrows()):
                atom_type = row['type']
                if atom_type not in atomtype_groups:
                    atomtype_groups[atom_type] = []
                atomtype_groups[atom_type].append(qm_idx)
            
            # For each atom type group, map all atoms to the first atom in the group
            for atom_type, atoms in atomtype_groups.items():
                if len(atoms) > 1:  # Only create mappings if there are multiple atoms of this type
                    reference_atom = atoms[0]
                    for atom in atoms[1:]:
                        eq_mapping[atom] = reference_atom
            
            logging.info(f'Generated equivalent atom mappings for {len(atomtype_groups)} atom types')
            return eq_mapping
        
        if not equivalent_atoms:
            return eq_mapping

        # Handle global format
        if 'global' in equivalent_atoms:
            for atom1, atom2 in equivalent_atoms['global']:
                if atom1 in global_to_qm_idx and atom2 in global_to_qm_idx:
                    qm_idx1 = global_to_qm_idx[atom1]
                    qm_idx2 = global_to_qm_idx[atom2]
                    eq_mapping[qm_idx2] = qm_idx1
        
        # Handle local format
        elif 'local' in equivalent_atoms:
            # Get all QM atom indices
            qm_indices = list(self.qm_atoms.index)
            
            for mol_name, mol_eq_atoms in equivalent_atoms['local'].items():
                # Find atoms in this molecule that are in QM region
                mol_atoms = []
                
                # Calculate the starting atom number for each molecule type
                prev_natoms = 0
                for mol, n_mols in self.top.molecules:
                    if mol == mol_name:
                        mol_len = len(self.top.topol_dict[mol])
                        for i in range(n_mols):
                            mol_start = prev_natoms + (i * mol_len) + 1  # 1-based indexing
                            mol_end = mol_start + mol_len - 1
                            
                            # Find QM atoms in this molecule instance
                            for idx in qm_indices:
                                if mol_start <= idx <= mol_end:
                                    # Adjust index to be molecule-local (1-based)
                                    local_idx = idx - mol_start + 1
                                    mol_atoms.append((local_idx, idx))
                        break  # Found the molecule, no need to continue
                    
                    # Update prev_natoms for next molecule type
                    prev_natoms += len(self.top.topol_dict[mol]) * n_mols
            
                if not mol_atoms:
                    logging.warning(f"No QM atoms found in molecule {mol_name}")
                    continue
            
                # Create mapping from local to global indices
                local_to_global = {local: global_idx for local, global_idx in mol_atoms}
                for atom1, atom2 in mol_eq_atoms:
                    if atom1 not in local_to_global or atom2 not in local_to_global:
                        logging.warning(f"Atom indices {atom1} or {atom2} not found in QM region for molecule {mol_name}")
                        continue
                        
                    global_atom1 = local_to_global[atom1]
                    global_atom2 = local_to_global[atom2]
                    
                    # Convert to contiguous QM indices
                    if global_atom1 in global_to_qm_idx and global_atom2 in global_to_qm_idx:
                        qm_idx1 = global_to_qm_idx[global_atom1]
                        qm_idx2 = global_to_qm_idx[global_atom2]
                        eq_mapping[qm_idx2] = qm_idx1
        
        logging.info(f'Successfully created equivalent atom mapping for {len(eq_mapping)} QM atoms')
        return eq_mapping 

    def redistribute_charges_after_dresp(self, optimized_charges, num_bonds_away=2, 
                                       fixed_charge_indices=None, charge_group_constraints=None):
        """Redistribute charges after DRESP optimization to maintain QM region neutrality and charge group constraints.
        
        This function:
        1. Identifies QM atoms that are a specified number of bonds away from boundary atoms
        2. Replaces their optimized charges with original values
        3. Calculates the charge difference for each charge group
        4. Redistributes charge differences within each group to maintain group constraints
        5. Maintains total system charge conservation
        
        Args:
            optimized_charges (numpy.ndarray or list): Optimized charges from DRESP
            num_bonds_away (int): Number of bonds away from boundary atoms to restore charges
            fixed_charge_indices (set, optional): Set of atom indices whose charges should be kept at original values
            charge_group_constraints (list, optional): List of tuples (atom_indices, target_charge) for charge groups
        
        Returns:
            numpy.ndarray: Redistributed charges that maintain QM region charge conservation and group constraints
        """
        if not self.qm_atoms is not None:
            raise MiMiCPyError('No QM atoms defined')
        
        if len(optimized_charges) != len(self.qm_atoms):
            raise MiMiCPyError(f'Optimized charges length ({len(optimized_charges)}) does not match number of QM atoms ({len(self.qm_atoms)})')
        
        # Get boundary atoms
        if self.boundary_atoms.empty:
            return np.array(optimized_charges)
        
        # Get original charges
        original_charges = self.qm_atoms['charge'].values
        original_charges = np.array(original_charges)
        
        # Create mapping from QM atom index to position in optimized_charges array
        qm_atom_to_array_idx = {atom_idx: array_idx for array_idx, atom_idx in enumerate(self.qm_atoms.index)}
        
        bonds = self.qm_interactions['bonds']
        
        # Create adjacency list for bond connectivity
        adjacency_list = {}
        for bond in bonds:
            if bond['involves_mm']:
                continue
            atom1, atom2 = bond['atoms']
            if atom1 not in adjacency_list:
                adjacency_list[atom1] = []
            if atom2 not in adjacency_list:
                adjacency_list[atom2] = []
            adjacency_list[atom1].append(atom2)
            adjacency_list[atom2].append(atom1)
        
        # Find boundary atom indices in the sequential QM indexing
        boundary_indices = set()
        for boundary_idx in self.boundary_atoms.index:
            array_idx = qm_atom_to_array_idx[boundary_idx]
            boundary_indices.add(array_idx)
        
        # Find atoms that are within num_bonds_away from boundary atoms (inclusive)
        atoms_to_restore = set()
        
        # First, add boundary atoms themselves to be restored
        atoms_to_restore.update(boundary_indices)
        if fixed_charge_indices:
            atoms_to_restore.update(fixed_charge_indices)
            
        for boundary_idx in boundary_indices:
            # Use breadth-first search to find atoms within the specified bond distance
            visited = set()
            queue = [(boundary_idx, 0)]  # (atom_index, bond_distance)
            
            while queue:
                current_atom, bond_distance = queue.pop(0)
                
                if current_atom in visited:
                    continue
                
                visited.add(current_atom)
                
                if bond_distance <= num_bonds_away and bond_distance > 0:
                    # This atom is within num_bonds_away from boundary (but not the boundary itself)
                    atoms_to_restore.add(current_atom)
                
                if bond_distance < num_bonds_away:
                    # Continue searching for more distant atoms
                    if current_atom in adjacency_list:
                        for neighbor in adjacency_list[current_atom]:
                            if neighbor not in visited:
                                queue.append((neighbor, bond_distance + 1))
        
        if len(atoms_to_restore) == 0:
            logging.warning(f'No atoms found within {num_bonds_away} bond(s) from boundary atoms. Returning optimized charges unchanged.')
            return optimized_charges
        
        # Initialize result charges with optimized charges
        redistributed_charges = optimized_charges.copy()
        
        # Process charge group constraints if provided
        if charge_group_constraints:
            # Create a mapping from atom index to group info
            atom_to_group = {}
            for group_key, (atom_indices, target_charge) in charge_group_constraints.items():
                for atom_idx in atom_indices:
                    atom_to_group[atom_idx] = (group_key, target_charge)
            
            # Process each charge group separately
            for group_key, (atom_indices, target_charge) in charge_group_constraints.items():
                # Find atoms in this group that need to be restored
                group_atoms_to_restore = atoms_to_restore.intersection(atom_indices)
                group_atoms_to_optimize = atom_indices - atoms_to_restore
                
                if len(group_atoms_to_restore) == 0:
                    # No atoms in this group need restoration, skip
                    continue
                
                # Calculate charge difference for this group
                group_charge_diff = 0.0
                for atom_idx in group_atoms_to_restore:
                    original_charge = original_charges[atom_idx]
                    optimized_charge = optimized_charges[atom_idx]
                    
                    # Restore original charge
                    redistributed_charges[atom_idx] = original_charge
                    
                    # Add to group charge difference
                    charge_diff = optimized_charge - original_charge
                    group_charge_diff += charge_diff
                    
                    # Log the restoration
                    actual_atom_idx = list(self.qm_atoms.index)[atom_idx]
                    logging.debug(f'Group {group_key}: Restored charge for atom {actual_atom_idx}: '
                                f'{optimized_charge:.6f} -> {original_charge:.6f} (diff: {charge_diff:.6f})')
                
                # If there are atoms to optimize in this group, redistribute the charge difference
                if len(group_atoms_to_optimize) > 0 and abs(group_charge_diff) > 1e-10:
                    # Calculate weights for redistribution within the group
                    weights = np.zeros(len(self.qm_atoms))
                    for atom_idx in group_atoms_to_optimize:
                        weights[atom_idx] = abs(optimized_charges[atom_idx])
                    
                    # Normalize weights
                    total_weight = np.sum(weights)
                    if total_weight > 0:
                        weights = weights / total_weight
                    else:
                        # If all weights are zero, distribute equally
                        weights = np.ones(len(self.qm_atoms)) / len(group_atoms_to_optimize)
                        # Set weights to zero for atoms not in this group
                        for i in range(len(self.qm_atoms)):
                            if i not in group_atoms_to_optimize:
                                weights[i] = 0.0
                    
                    # Redistribute charge difference within the group
                    charge_per_atom = group_charge_diff * weights
                    redistributed_charges += charge_per_atom
                    
                    logging.debug(f'Group {group_key}: Redistributed {group_charge_diff:.6f} charge among {len(group_atoms_to_optimize)} atoms')
                
                # Verify group constraint is maintained
                group_total = sum(redistributed_charges[atom_idx] for atom_idx in atom_indices)
                if abs(group_total - target_charge) > 1e-6:
                    logging.warning(f'Group {group_key} constraint violated: target={target_charge:.6f}, actual={group_total:.6f}')
        
        else:
            # Original behavior: global redistribution without group constraints
            total_charge_diff = 0.0
            
            # Restore original charges for atoms at specified bond distance
            for atom_idx in atoms_to_restore:
                original_charge = original_charges[atom_idx]
                optimized_charge = optimized_charges[atom_idx]
                
                # Restore original charge
                redistributed_charges[atom_idx] = original_charge
                
                # Add to total charge difference
                charge_diff = optimized_charge - original_charge
                total_charge_diff += charge_diff
                
                # Get the actual atom index for logging
                actual_atom_idx = list(self.qm_atoms.index)[atom_idx]
                if atom_idx in boundary_indices:
                    logging.debug(f'Restored charge for boundary atom {actual_atom_idx}: '
                                f'{optimized_charge:.6f} -> {original_charge:.6f} (diff: {charge_diff:.6f})')
                else:
                    logging.debug(f'Restored charge for atom {actual_atom_idx} (within {num_bonds_away} bond(s) from boundary): '
                                f'{optimized_charge:.6f} -> {original_charge:.6f} (diff: {charge_diff:.6f})')
            
            # If no charge difference, return as is
            if abs(total_charge_diff) < 1e-10:
                logging.info('No charge difference to redistribute')
                return redistributed_charges
            
            # Calculate weightage for redistribution based on atom charges
            weights = np.zeros(len(self.qm_atoms))
            
            for i in range(len(self.qm_atoms)):
                if i in atoms_to_restore:
                    # Atoms that are being restored to original charges get zero weight
                    weights[i] = 0.0
                    continue
                
                # Use the absolute value of the atom's charge as weightage
                weights[i] = abs(optimized_charges[i])
            
            # Normalize weights
            total_weight = np.sum(weights)
            if total_weight > 0:
                weights = weights / total_weight
            else:
                # If all weights are zero, distribute equally among non-boundary atoms
                non_boundary_count = len(self.qm_atoms) - len(boundary_indices)
                if non_boundary_count > 0:
                    weights = np.ones(len(self.qm_atoms)) / non_boundary_count
                    # Set boundary atom weights to zero
                    for boundary_idx in boundary_indices:
                        weights[boundary_idx] = 0.0
                else:
                    weights = np.ones(len(self.qm_atoms)) / len(self.qm_atoms)
            
            # Redistribute charge difference based on weights
            charge_per_atom = total_charge_diff * weights
            redistributed_charges += charge_per_atom
        
        # Verify total charge conservation
        original_total = np.sum(original_charges)
        optimized_total = np.sum(optimized_charges)
        redistributed_total = np.sum(redistributed_charges)
        
        logging.info(f'Charge redistribution summary:')
        logging.info(f'  Original total charge: {original_total:.6f}')
        logging.info(f'  Optimized total charge: {optimized_total:.6f}')
        logging.info(f'  Redistributed total charge: {redistributed_total:.6f}')
        logging.info(f'  Number of boundary atoms: {len(self.boundary_atoms)}')
        logging.info(f'  Bonds away from boundary (inclusive): {num_bonds_away}')
        logging.info(f'  Number of atoms restored: {len(atoms_to_restore)}')
        
        if charge_group_constraints:
            logging.info(f'  Number of charge groups: {len(charge_group_constraints)}')
            for group_key, (atom_indices, target_charge) in charge_group_constraints.items():
                group_total = sum(redistributed_charges[atom_idx] for atom_idx in atom_indices)
                logging.info(f'    Group {group_key}: target={target_charge:.6f}, actual={group_total:.6f}')
        
        # Check if total charge is conserved
        if abs(redistributed_total - optimized_total) > 1e-6:
            logging.warning(f'Total charge not conserved: difference = {redistributed_total - optimized_total:.6f}')
        
        return redistributed_charges

    def find_mm_atoms_bonded_to_qm(self):
        """Find MM atoms that participate in interactions with QM atoms
        
        This method identifies MM atoms that participate in any bonded interactions
        with QM atoms (bonds, angles, dihedrals). It uses bond connectivity for
        efficiency but also checks for MM atoms in angles and dihedrals with QM atoms.
        
        Returns:
            pandas.DataFrame: DataFrame similar to qm_atoms containing MM atoms in QM interactions
        """
        if not self.qm_atoms is not None:
            raise MiMiCPyError('No QM atoms defined')
        
        # Get QM atom indices (1-based GROMACS indices)
        qm_indices = set(self.qm_atoms.index)
        
        # Get boundary atom indices to exclude them
        boundary_indices = set()
        if not self.boundary_atoms.empty:
            boundary_indices = set(self.boundary_atoms.index)
        
        # Dictionary to store MM atoms and their molecule info
        mm_atoms_info = {}  # gmx_idx -> (mol, local_idx)
        
        # Build bond connectivity graph for the entire system
        adjacency_list = {}
        
        prev_natoms = 0
        for mol, n_mols in self.top.molecules:
            mol_bonds = self.top.topol_dict.get_bonds(mol)
            
            if mol_bonds:
                for j in range(len(mol_bonds[0])):
                    i_idx = mol_bonds[0][j] + prev_natoms
                    j_idx = mol_bonds[1][j] + prev_natoms
                    
                    # Add to adjacency list
                    if i_idx not in adjacency_list:
                        adjacency_list[i_idx] = []
                    if j_idx not in adjacency_list:
                        adjacency_list[j_idx] = []
                    adjacency_list[i_idx].append(j_idx)
                    adjacency_list[j_idx].append(i_idx)
            
            prev_natoms += len(self.top.topol_dict[mol]) * n_mols
        
        # Find MM atoms that participate in interactions with QM atoms
        mm_atoms_in_interactions = set()
        
        # First, find MM atoms directly bonded to QM atoms
        for qm_idx in qm_indices:
            if qm_idx in adjacency_list:
                for neighbor_idx in adjacency_list[qm_idx]:
                    # If neighbor is not in QM and not a boundary atom, it's an MM atom
                    if neighbor_idx not in qm_indices and neighbor_idx not in boundary_indices:
                        mm_atoms_in_interactions.add(neighbor_idx)
        
        # Now check for MM atoms in angles and dihedrals with QM atoms
        prev_natoms = 0
        for mol, n_mols in self.top.molecules:
            mol_angles = self.top.topol_dict.get_angles(mol)
            mol_dihedrals = self.top.topol_dict.get_dihedrals(mol)
            
            # Check angles
            if mol_angles:
                for j in range(len(mol_angles[0])):
                    i_idx = mol_angles[0][j] + prev_natoms
                    j_idx = mol_angles[1][j] + prev_natoms
                    k_idx = mol_angles[2][j] + prev_natoms
                    
                    # Check if any atom is in QM and others are in MM
                    qm_count = sum(1 for idx in [i_idx, j_idx, k_idx] if idx in qm_indices)
                    if qm_count > 0 and qm_count < 3:  # Mixed QM-MM interaction
                        for idx in [i_idx, j_idx, k_idx]:
                            if idx not in qm_indices and idx not in boundary_indices:
                                mm_atoms_in_interactions.add(idx)
            
            # Check dihedrals
            if mol_dihedrals:
                for j in range(len(mol_dihedrals[0])):
                    i_idx = mol_dihedrals[0][j] + prev_natoms
                    j_idx = mol_dihedrals[1][j] + prev_natoms
                    k_idx = mol_dihedrals[2][j] + prev_natoms
                    l_idx = mol_dihedrals[3][j] + prev_natoms
                    
                    # Check if any atom is in QM and others are in MM
                    qm_count = sum(1 for idx in [i_idx, j_idx, k_idx, l_idx] if idx in qm_indices)
                    if qm_count > 0 and qm_count < 4:  # Mixed QM-MM interaction
                        for idx in [i_idx, j_idx, k_idx, l_idx]:
                            if idx not in qm_indices and idx not in boundary_indices:
                                mm_atoms_in_interactions.add(idx)
            
            prev_natoms += len(self.top.topol_dict[mol]) * n_mols
        
        # Now get molecule information for the MM atoms
        prev_natoms = 0
        for mol, n_mols in self.top.molecules:
            mol_size = len(self.top.topol_dict[mol])
            
            for mol_idx in range(n_mols):
                mol_start = prev_natoms + (mol_idx * mol_size) + 1
                mol_end = mol_start + mol_size - 1
                
                # Check if any MM atoms are in this molecule instance
                for gmx_idx in mm_atoms_in_interactions:
                    if mol_start <= gmx_idx <= mol_end:
                        # Calculate local index
                        local_idx = gmx_idx - mol_start + 1
                        mm_atoms_info[gmx_idx] = (mol, local_idx)
            
            prev_natoms += mol_size * n_mols
        
        # Create DataFrame similar to qm_atoms
        mm_atoms_data = []
        
        for gmx_idx in sorted(mm_atoms_info.keys()):
            mol, local_idx = mm_atoms_info[gmx_idx]
            atom_row = self.top.topol_dict[mol].loc[local_idx]
            
            mm_atoms_data.append({
                'id': gmx_idx,
                'type': atom_row['type'],
                'resid': atom_row['resid'],
                'resname': atom_row['resname'],
                'name': atom_row['name'],
                'cgnr': atom_row['cgnr'],
                'charge': atom_row['charge'],
                'element': atom_row.get('element', ''),
                'mass': atom_row['mass'],
                'mol': mol,
                'is_bound': 0,  # MM atoms are not boundary atoms
                'is_qm': 0      # MM atoms are not QM atoms
            })
        
        # Create DataFrame
        mm_atoms_df = pd.DataFrame(mm_atoms_data)
        if not mm_atoms_df.empty:
            mm_atoms_df.set_index('id', inplace=True)
        
        logging.info(f'Found {len(mm_atoms_df)} MM atoms in QM interactions')
        return mm_atoms_df

    def get_extended_qm_atoms_dataframe(self):
        """Get extended QM atom DataFrame including MM atoms bonded to QM atoms
        
        This method returns a combined DataFrame containing both QM atoms and MM atoms
        bonded to QM atoms, with proper flags to distinguish between them.
        
        Returns:
            pandas.DataFrame: Combined DataFrame of QM and MM atoms with columns:
                - All standard atom properties (type, resid, resname, name, cgnr, charge, mass, element)
                - is_bound: 1 for boundary atoms, 0 for others
                - is_qm: 1 for QM atoms, 0 for MM atoms
        """
        if not self.qm_atoms is not None:
            raise MiMiCPyError('No QM atoms defined')
        
        # Get MM atoms DataFrame
        mm_atoms_df = self.find_mm_atoms_bonded_to_qm()
        
        # Create a copy of QM atoms DataFrame
        qm_atoms_copy = self.qm_atoms.copy()
        
        # Add is_qm column to QM atoms (all QM atoms have is_qm=1)
        qm_atoms_copy['is_qm'] = 1
        
        # Add is_qm column to MM atoms (all MM atoms have is_qm=0)
        if not mm_atoms_df.empty:
            mm_atoms_df['is_qm'] = 0
        
        # Combine the DataFrames
        if not mm_atoms_df.empty:
            extended_df = pd.concat([qm_atoms_copy, mm_atoms_df])
        else:
            extended_df = qm_atoms_copy
        
        logging.info(f'Extended QM atom DataFrame: {len(qm_atoms_copy)} QM atoms + {len(mm_atoms_df)} MM atoms = {len(extended_df)} total')
        return extended_df

    def identify_solvent_atoms(self, solvent_names:dict=None):
        """Identify solvent atoms in the QM region based on residue names and molecule names.
        
        This method identifies which atoms in the QM region belong to solvent molecules
        based on their residue names and the molecule types they belong to.
        
        Args:
            solvent_names (dict, optional): Dictionary containing 'resnames' and 'molecules' keys.
                Default: {'resnames': ['SOL', 'WAT', 'HOH', 'TIP3', 'TIP3P', 'TP3', 'H2O'],
                          'molecules': ['tip3p', 'spc', 'spce', 'spc/e', 'SOL', 'water', 'tip4p']}
                
        Returns:
            set: Set of sequential indices (0-based) of solvent atoms
        """
        if not self.qm_atoms is not None:
            raise MiMiCPyError('No QM atoms defined')
        
        # Set default solvent detection parameters
        if solvent_names is None:
            solvent_names = {'resnames': ['SOL', 'WAT', 'HOH', 'TIP3', 'TIP3P', 'TP3', 'H2O'],
                             'molecules': ['tip3p', 'spc', 'spce', 'spc/e', 'SOL', 'water', 'tip4p']}
        
        # Initialize results
        solvent_atom_indices = set()  # Sequential indices (0-based)
        solvent_gmx_indices = set()   # GROMACS indices (1-based)
        
        
        # Get QM atoms DataFrame to work with
        qm_atoms_df = self.qm_atoms
        
        # Create mapping from GROMACS indices to sequential indices
        gmx_to_seq_map = {}
        for seq_idx, gmx_idx in enumerate(qm_atoms_df.index):
            gmx_to_seq_map[gmx_idx] = seq_idx
        
        # Check each QM atom
        for gmx_idx in qm_atoms_df.index:
            is_solvent = False
            
            # Check by residue name
            if solvent_names['resnames'] is not None:
                resname = str(qm_atoms_df.loc[gmx_idx, 'resname']).strip()
                if resname in solvent_names['resnames']:
                    is_solvent = True
                    
            # Check by molecule name if not already identified as solvent
            if not is_solvent:
                if solvent_names['molecules'] is not None:
                    mol_name = str(qm_atoms_df.loc[gmx_idx, 'mol']).strip()
                    if mol_name in solvent_names['molecules']:
                        is_solvent = True
                        
            
            # Add to solvent sets if identified as solvent
            if is_solvent:
                solvent_gmx_indices.add(gmx_idx)
                solvent_atom_indices.add(gmx_to_seq_map[gmx_idx])
      
        return solvent_atom_indices

    def is_solvent_interaction(self, interaction):
        """Check if an interaction involves solvent atoms.
        
        This method checks if any of the atoms in the given interaction belong to solvent molecules.
        
        Args:
            interaction (dict): Interaction dictionary containing 'atoms' key with atom indices
            solvent_resnames (list, optional): List of solvent residue names to identify
            solvent_molecules (list, optional): List of solvent molecule names to identify
                
        Returns:
            bool: True if the interaction involves solvent atoms, False otherwise
        """
        if not self.qm_atoms is not None:
            raise MiMiCPyError('No QM atoms defined')
        
        # Check if any atoms in the interaction are solvent atoms
        atom_indices = interaction.get('atoms', [])
        return any(atom_idx in self.solvent_atom_indices for atom_idx in atom_indices)

    def create_charge_group_constraints(self, group_by='mol', target_charges=None, 
                                       exclude_solvent=True, solvent_names=None):
        """
        Create charge group constraints based on information from qm_atoms dataframe.
        
        This method groups QM atoms by specified criteria and creates charge constraints
        for each group. It can group atoms by residue name, molecule name, or atom type.
        
        Args:
            group_by (str): Criteria to group atoms by. Options:
                - 'resname': Group by residue name
                - 'mol': Group by molecule name  
                - 'type': Group by atom type
                - 'resid': Group by residue ID
            target_charges (dict, optional): Dictionary mapping group identifiers to target charges.
                If None, uses sum of original charges from qm_atoms for each group.
                Example: {'ALA': 0.0, 'GLY': 0.0, 'SOL': 0.0}
            exclude_solvent (bool): Whether to exclude solvent atoms from grouping
            solvent_names (dict, optional): Dictionary for solvent identification.
                If None, uses default solvent names.
                
        Returns:
            list: List of tuples (atom_indices, target_charge) for use in opt_dresp
        """
        if not self.qm_atoms is not None:
            raise MiMiCPyError('No QM atoms defined')
        
        # Identify solvent atoms if needed
        solvent_atom_indices = set()
        if exclude_solvent:
            solvent_atom_indices = self.identify_solvent_atoms(solvent_names)
        
        # Group atoms by the specified criteria
        groups = {}
        group_charges = {}
        
        for seq_idx, (gmx_idx, row) in enumerate(self.qm_atoms.iterrows()):
            # Skip solvent atoms if exclude_solvent is True
            if exclude_solvent and seq_idx in solvent_atom_indices:
                continue
            
            # Get the grouping key based on group_by parameter
            if group_by == 'resname':
                group_key = str(row['resname']).strip()
            elif group_by == 'mol':
                group_key = str(row['mol']).strip()
            elif group_by == 'type':
                group_key = str(row['type']).strip()
            elif group_by == 'resid':
                group_key = str(row['resid'])
            else:
                raise ValueError(f"Invalid group_by parameter: {group_by}. "
                               f"Must be one of: 'resname', 'mol', 'type', 'resid'")
            
            # Add atom to its group
            if group_key not in groups:
                groups[group_key] = set()
                group_charges[group_key] = 0.0
            groups[group_key].add(seq_idx)
            group_charges[group_key] += row['charge']
        
        # Create constraints
        constraints = {}
        
        for group_key, atom_indices in groups.items():
            # Determine target charge for this group
            if target_charges is not None and group_key in target_charges:
                target_charge = target_charges[group_key]
            else:
                # Use sum of original charges if no specific target is provided
                target_charge = group_charges[group_key]
            
            # Only add constraint if group has more than one atom or if target charge is not 0
            if len(atom_indices) > 1:
                constraints[group_key] = (atom_indices, target_charge)
        
        return constraints