"""Module for force matching input files"""

from .script import Script
import json

class FMInput(Script):
    """Formats force matching input files"""
    
    def __init__(self, **kwargs):
        super().__init__()
        if 'title' not in kwargs:
            kwargs['title'] = 'Force matching input'
        
        # Default values
        self.eq_atoms = None  # Can be either global or local format
        self.stride = None
        self.wv = None
        self.we = None
        self.wh = None
        self.wq = None
        self.qm_total_charge = None
        self.reference_charges = None
        self.num_bonds_away = 2
        self.skip_solvent_optimization = True
        self.solvent_resnames = None
        self.solvent_molecules = None
        self.fixed_charge_indices = None
        self.charge_group_constraints = True # Whether to use charge group constraints
        self.weights_to_fix_charges = 100000.0 # Weight to fix charges
        # New parameters for bonded optimization control
        self.optimize_bond_length = True  # Whether to optimize bond lengths
        self.optimize_bond_force = True   # Whether to optimize bond force constants
        self.optimize_angle_value = True  # Whether to optimize angle values
        self.optimize_angle_force = True  # Whether to optimize angle force constants
        self.optimize_dihedral_force = True  # Whether to optimize dihedral force constants
        
        # New parameters for excluded interactions (using atom indices)
        self.exclude_bonds = None  # List of atom pairs [(atom1, atom2), ...] to exclude from fitting
        self.exclude_angles = None  # List of atom triplets [(atom1, atom2, atom3), ...] to exclude from fitting
        self.exclude_dihedrals = None  # List of atom quartets [(atom1, atom2, atom3, atom4), ...] to exclude from fitting
        # Fine-grained hydrogen exclusion controls
        self.exclude_hydrogen_bonds = False
        self.exclude_hydrogen_angles = False
        self.exclude_hydrogen_dihedrals = False
        
        # Regularization parameters
        self.regularization = True
        self.regularization_alpha = 0.1  # L2 regularization strength (α)
        self.regularization_prior_widths = None  # Prior widths for regularization (auto-generated if None)
        self.regularization_bond_length_width = None  # Prior width for bond lengths
        self.regularization_bond_force_width = None   # Prior width for bond force constants
        self.regularization_angle_value_width = None  # Prior width for angle values
        self.regularization_angle_force_width = None  # Prior width for angle force constants
        self.regularization_dihedral_force_width = None  # Prior width for dihedral force constants
        
        # Optimization method selection
        self.optimization_method = 'hierarchical'  # 'hierarchical', 'simultaneous'
        
        # Energy-weighted optimization parameters
        self.bond_energy_weight = 1.0      # Weight for bond contributions
        self.angle_energy_weight = 0.1     # Weight for angle contributions  
        self.dihedral_energy_weight = 0.01 # Weight for dihedral contributions
        
        # Adaptive regularization parameters
        self.adaptive_base_alpha = 0.1           # Base regularization strength for adaptive method
        self.energy_hierarchy_scale = 10.0       # Scale factor for energy hierarchy in adaptive method
        
        # Update with provided kwargs
        for key, value in kwargs.items():
            setattr(self, key, value)
    
    def __str__(self):
        """Convert the input parameters to a string format"""
        fm_input = f"; Force matching input parameters for {self.title}\n"
        
        # Add each parameter if it's not None
        for param in ['stride', 'wv', 'we', 'wh', 'wq', 'qm_total_charge', 'regularization',
                     'reference_charges', 'num_bonds_away', 'skip_solvent_optimization', 'solvent_resnames', 'solvent_molecules',
                     'fixed_charge_indices', 'charge_group_constraints', 'weights_to_fix_charges',
                     'optimize_bond_length', 'optimize_bond_force',
                     'optimize_angle_value', 'optimize_angle_force',
                     'optimize_dihedral_force',
                     'regularization_alpha',
                     'exclude_hydrogen_bonds', 'exclude_hydrogen_angles', 'exclude_hydrogen_dihedrals']:
            value = getattr(self, param)
            if value is not None:
                value_str = str(value)
                fm_input += f"{param}: {value_str}\n"
        
        # Add regularization prior widths if specified
        for param in ['regularization_bond_length_width', 'regularization_bond_force_width',
                     'regularization_angle_value_width', 'regularization_angle_force_width',
                     'regularization_dihedral_force_width']:
            value = getattr(self, param)
            if value is not None:
                fm_input += f"{param}: {value}\n"
        
        # Add excluded interactions if specified
        for param in ['exclude_bonds', 'exclude_angles', 'exclude_dihedrals']:
            value = getattr(self, param)
            if value is not None:
                # Convert list of tuples to string representation
                value_str = str(value).replace('[', '(').replace(']', ')')
                fm_input += f"{param}: {value_str}\n"
        
        # Special handling for eq_atoms
        if self.eq_atoms is not None:
            if isinstance(self.eq_atoms, dict):
                # Handle either global or local format
                for key, value in self.eq_atoms.items():
                    if key in ['global', 'local']:
                        # Convert list of tuples to string representation
                        value_str = str(value).replace('[', '(').replace(']', ')')
                        fm_input += f"eq_atoms_{key}: {value_str}\n"
            else:
                # Backward compatibility for old format
                value_str = str(self.eq_atoms).replace('[', '(').replace(']', ')')
                fm_input += f"eq_atoms: {value_str}\n"
        
        return fm_input
    
    @classmethod
    def from_file(cls, filename):
        """Create an FMInput instance from a file"""
        with open(filename, 'r') as f:
            return cls.from_string(f.read())
    
    @classmethod
    def from_string(cls, string):
        """Create an FMInput instance from a string"""
        kwargs = {}
        eq_atoms = {}
        
        for line in string.splitlines():
            line = line.strip()
            if line.startswith(('!', '#')) or not line:
                continue
            
            if ':' in line:
                line = line.split('#')[0]  # Remove comments
                # Split on first colon only
                key, val = line.split(':', 1)
                key = key.strip()
                val = val.strip()
                
                # Handle special cases
                if key == 'eq_atoms':
                    if val == 'use_atomtypes':
                        eq_atoms = val
                elif key == 'eq_atoms_global':
                    if 'local' in eq_atoms:
                        raise ValueError("Cannot specify both global and local equivalent atoms")
                    eq_atoms['global'] = json.loads(val.replace(')', ']').replace('(', '['))
                elif key == 'eq_atoms_local':
                    if 'global' in eq_atoms:
                        raise ValueError("Cannot specify both global and local equivalent atoms")
                    # Parse local format: "mol_name: [atom_ids]"
                    mol_name, atom_ids = val.split(':', 1)
                    mol_name = mol_name.strip()
                    atom_ids = json.loads(atom_ids.replace(')', ']').replace('(', '['))
                    eq_atoms['local'] = {mol_name: atom_ids}
                elif key == 'stride':
                    val = json.loads(val)
                elif key in ['wv', 'we', 'wh', 'wq', 'qm_total_charge', 'regularization_alpha', 'num_bonds_away', 'fixed_charge_indices', 'weights_to_fix_charges']:
                    # Allow lists for wv, we, wh
                    if val.startswith('[') or val.startswith('('):
                        val = json.loads(val.replace('(', '[').replace(')', ']'))
                    else:
                        val = float(val) if '.' in val else int(val)
                elif key == 'reference_charges':
                    if val == 'ff_charges':
                        val = 'ff_charges'
                    else:
                        val = float(val)
                # Handle boolean parameters for optimization control
                elif key in ['optimize_bond_length', 'optimize_bond_force',
                           'optimize_angle_value', 'optimize_angle_force', 'charge_group_constraints', 'regularization',
                           'optimize_dihedral_force', 'skip_solvent_optimization',
                           'exclude_hydrogen_bonds', 'exclude_hydrogen_angles', 'exclude_hydrogen_dihedrals']:
                    val = val.lower()
                    if val in ('true', 'yes', '1', 't', 'y'):
                        val = True
                    elif val in ('false', 'no', '0', 'f', 'n'):
                        val = False
                    else:
                        raise ValueError(f"Invalid boolean value '{val}' for parameter {key}")
                # Handle regularization prior widths
                elif key in ['regularization_bond_length_width', 'regularization_bond_force_width',
                           'regularization_angle_value_width', 'regularization_angle_force_width',
                           'regularization_dihedral_force_width']:
                    val = float(val)
                # Handle excluded interactions (using atom indices)
                elif key in ['exclude_bonds', 'exclude_angles', 'exclude_dihedrals']:
                    # Parse list of tuples of atom indices
                    val = json.loads(val.replace('(', '[').replace(')', ']'))
                    # Convert to list of tuples
                    val = [tuple(x) for x in val]
                elif key in ['optimization_method', 'solvent_resnames', 'solvent_molecules']:
                    # Keep as string, validation will be done later
                    val = val.strip()
                elif key in ['bond_energy_weight', 'angle_energy_weight', 'dihedral_energy_weight',
                           'adaptive_base_alpha', 'energy_hierarchy_scale']:
                    val = float(val)
                
                if key not in ['eq_atoms', 'eq_atoms_global', 'eq_atoms_local']:
                    kwargs[key] = val
        
        # Add eq_atoms to kwargs if any were found
        if eq_atoms:
            kwargs['eq_atoms'] = eq_atoms
        
        return cls(**kwargs)
    
    def to_dict(self):
        """Convert the input parameters to a dictionary"""
        return {
            'eq_atoms': self.eq_atoms,
            'stride': self.stride,
            'wv': self.wv,
            'we': self.we,
            'wh': self.wh,
            'wq': self.wq,
            'qm_total_charge': self.qm_total_charge,
            'reference_charges': self.reference_charges,
            'num_bonds_away': self.num_bonds_away,
            'skip_solvent_optimization': self.skip_solvent_optimization,
            'solvent_resnames': self.solvent_resnames,
            'solvent_molecules': self.solvent_molecules,
            'fixed_charge_indices': self.fixed_charge_indices,
            'charge_group_constraints': self.charge_group_constraints,
            'weights_to_fix_charges': self.weights_to_fix_charges,
            'optimize_bond_length': self.optimize_bond_length,
            'optimize_bond_force': self.optimize_bond_force,
            'optimize_angle_value': self.optimize_angle_value,
            'optimize_angle_force': self.optimize_angle_force,
            'optimize_dihedral_force': self.optimize_dihedral_force,
            'exclude_bonds': self.exclude_bonds,
            'exclude_angles': self.exclude_angles,
            'exclude_dihedrals': self.exclude_dihedrals,
            'regularization': self.regularization,
            'regularization_alpha': self.regularization_alpha,
            'regularization_prior_widths': self.regularization_prior_widths,
            'regularization_bond_length_width': self.regularization_bond_length_width,
            'regularization_bond_force_width': self.regularization_bond_force_width,
            'regularization_angle_value_width': self.regularization_angle_value_width,
            'regularization_angle_force_width': self.regularization_angle_force_width,
            'regularization_dihedral_force_width': self.regularization_dihedral_force_width,
            'exclude_hydrogen_bonds': self.exclude_hydrogen_bonds,
            'exclude_hydrogen_angles': self.exclude_hydrogen_angles,
            'exclude_hydrogen_dihedrals': self.exclude_hydrogen_dihedrals,
            'optimization_method': getattr(self, 'optimization_method', 'hierarchical'),
            'bond_energy_weight': getattr(self, 'bond_energy_weight', 1.0),
            'angle_energy_weight': getattr(self, 'angle_energy_weight', 0.1),
            'dihedral_energy_weight': getattr(self, 'dihedral_energy_weight', 0.01),
            'adaptive_base_alpha': getattr(self, 'adaptive_base_alpha', 0.1),
            'energy_hierarchy_scale': getattr(self, 'energy_hierarchy_scale', 10.0)
        }
    
    def copy(self):
        """Create a copy of the FMInput object"""
        return FMInput(**self.to_dict())
    
    def __deepcopy__(self, memo):
        """Implement deep copy for FMInput objects"""
        return self.copy() 