import numpy as np
import json
import h5py
from pathlib import Path
from .script import Script

class FMDataset(Script): 

    def __init__(self, data_file, h5_file=None) -> None:
        super().__init__()
        self.data_file = Path(data_file)
        self.h5_file = Path(h5_file) if h5_file else self.data_file.with_suffix('.h5')
        
        if self.h5_file.exists():
            self._load_h5()
        else:
            self._convert_json_to_h5()
    
    def _convert_json_to_h5(self):
        """Convert JSON data to HDF5 format"""
        self.fm_data = []
        
        with open(self.data_file) as dt:
            json_str = dt.read()

        # Parse JSON data
        bracecount = 0
        jsonobj = ''
        for jsonstr in json_str:
            bracecount += jsonstr.count('{')
            bracecount -= jsonstr.count('}')
            jsonobj += jsonstr
            if (bracecount==0 and jsonobj.strip()):
                config_dict = json.loads(jsonobj)
                self.fm_data.append(config_dict)
                jsonobj = ''
        
        # Convert to HDF5
        with h5py.File(self.h5_file, 'w') as f:
            # Create groups for each configuration
            for i, config in enumerate(self.fm_data):
                grp = f.create_group(f'config_{i}')
                
                # Store atom data as structured arrays
                atoms = config['atoms']
                dtype = [
                    ('id', 'i4'),  # Add atom ID field
                    ('region', 'i4'),
                    ('coordinate', 'f8', (3,)),
                    ('electric_potential', 'f8'),
                    ('electric_field', 'f8', (3,)),
                    ('hirshfeld_charge', 'f8'),
                    ('force', 'f8', (3,))
                ]
                
                data = np.zeros(len(atoms), dtype=dtype)
                for j, atom in enumerate(atoms):
                    # Convert coordinates to numpy array if they aren't already
                    coords = np.array(atom['coordinate'], dtype=np.float64)
                    efield = np.array(atom['electric_field'], dtype=np.float64)
                    force = np.array(atom.get('force', [0.0, 0.0, 0.0]), dtype=np.float64)
                    
                    # Handle electric_potential which might be a list
                    epot = atom['electric_potential']
                    if isinstance(epot, list):
                        epot = epot[0] if epot else 0.0

                    data[j] = (
                        int(atom['id']),  # Add atom ID
                        int(atom['region']),
                        coords,
                        float(epot),
                        efield,
                        float(atom['hirshfeld_charge']),
                        force
                    )
                
                grp.create_dataset('atoms', data=data, compression='gzip')
        
        # Clear the JSON data from memory
        self.fm_data = None
    
    def _load_h5(self):
        """Load data from HDF5 file"""
        self.fm_data = None  # We don't need to keep the data in memory
    
    def get_configuration_properties(self, idx, property, region='all'):
        """Get properties for a specific configuration"""
        with h5py.File(self.h5_file, 'r') as f:
            config = f[f'config_{idx}']['atoms']
            
            if region == 'all':
                return config[property][:]
            elif region == 'mm':
                mask = config['region'][:] != 1
                return config[property][mask]
            elif region == 'qm':
                mask = config['region'][:] == 1
                return config[property][mask]
            else:
                raise ValueError(f"Invalid region: {region}")
    
    def get_atom_properties(self, idx, atom_id, property):
        """Get properties for a specific atom"""
        with h5py.File(self.h5_file, 'r') as f:
            return f[f'config_{idx}']['atoms'][property][atom_id]
    
    def __len__(self):
        """Return the number of configurations in the dataset"""
        with h5py.File(self.h5_file, 'r') as f:
            config_keys = [key for key in f.keys() if key.startswith('config_')]
            return len(config_keys)
    
    def __str__(self):
        n_configs = len(self)
        return f"FMDataset with {n_configs} configurations from {self.data_file}"

    @classmethod
    def from_string(cls, string):
        raise NotImplementedError("FMDataset does not support creation from string")
