#
#    MiMiCPy: Python Based Tools for MiMiC
#    Copyright (C) 2020-2023 Bharath Raghavan,
#                            Florian Schackert
#
#    This file is part of MiMiCPy.
#
#    MiMiCPy is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Lesser General Public License as
#    published by the Free Software Foundation, either version 3 of
#    the License, or (at your option) any later version.
#
#    MiMiCPy is distributed in the hope that it will be useful, but
#    WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Lesser General Public License for more details.
#
#    You should have received a copy of the GNU Lesser General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#

"""Module for itp files"""

from os.path import dirname, isfile, join
import re
import logging
import pandas as pd
from ..utils.file_handler import Parser
from ..utils.strings import clean
from ..utils.elements import ELEMENTS
from ..utils.errors import MiMiCPyError, ParserError

class Itp:
    """reads itp files"""

    columns = ['number', 'type', 'resid', 'resname', 'name', 'cgnr', 'charge', 'element', 'mass']

    def __init__(self,
                 file,
                 requested_molecules=None,
                 atom_types=None,
                 buffer=1000,
                 mode='r',
                 guess_elements=True,
                 gmxdata='',
                 parameter_definitions=None):

        self.file = file
        self.requested_molecules = requested_molecules
        self.atom_types_dict = atom_types
        self.buffer = buffer
        self.mode = mode
        self.guess_elements = guess_elements
        self.gmxdata = gmxdata
        self.external_parameter_definitions = parameter_definitions
        self._topol = None
        self._bonds = None
        self._angles = None
        self._dihedrals = None
        self._pairs = None
        self._topology_files = None
        self._molecules = None
        self._molecule_types = None
        self.guessed_elems_history = {}

        if mode == 'r':
            self.__read()
        elif mode == 't':
            self.__read_as_topol()
        elif mode == 'w':
            pass
        else:
            raise MiMiCPyError('{} is not a mode. Only r, t, or w can be used'.format(mode))

    @property
    def topol(self):
        if self.mode == 'r':
            return self._topol
        self.mode = 'r'
        self.__read()
        return self._topol

    @property
    def molecules(self):
        if self.mode == 't':
            return self._molecules
        self.mode = 't'
        self.__read_as_topol()
        return self._molecules

    @property
    def molecule_types(self):
        if self.mode == 't':
            return self._molecule_types
        self.mode = 't'
        self.__read_as_topol()
        return self._molecule_types

    @property
    def topology_files(self):
        if self.mode == 't':
            return self._topology_files
        self.mode = 't'
        self.__read_as_topol()
        return self._topology_files

    @property
    def atom_types(self):
        return self.__read_atomtypes()

    @property
    def bonds(self):
        if self.mode == 'r':
            return self._bonds
        self.mode = 'r'
        self.__read()
        return self._bonds

    @property
    def angles(self):
        if self.mode == 'r':
            return self._angles
        self.mode = 'r'
        self.__read()
        return self._angles

    @property
    def dihedrals(self):
        if self.mode == 'r':
            return self._dihedrals
        self.mode = 'r'
        self.__read()
        return self._dihedrals

    @property
    def pairs(self):
        if self.mode == 'r':
            return self._pairs
        self.mode = 'r'
        self.__read()

    @property
    def nrexcl_values(self):
        """Get nrexcl values for molecules in this ITP file"""
        if self.mode == 'r':
            return getattr(self, '_nrexcl_values', {})
        self.mode = 'r'
        self.__read()
        return getattr(self, '_nrexcl_values', {})

    @property
    def bondtypes(self):
        """Get bond types from force field sections"""
        if self.mode == 'r':
            return getattr(self, '_bondtypes', {})
        self.mode = 'r'
        self.__read()
        return getattr(self, '_bondtypes', {})

    @property
    def angletypes(self):
        """Get angle types from force field sections"""
        if self.mode == 'r':
            return getattr(self, '_angletypes', {})
        self.mode = 'r'
        self.__read()
        return getattr(self, '_angletypes', {})

    @property
    def dihedraltypes(self):
        """Get dihedral types from force field sections"""
        if self.mode == 'r':
            return getattr(self, '_dihedraltypes', {})
        self.mode = 'r'
        self.__read()
        return getattr(self, '_dihedraltypes', {})

    @property
    def parameter_definitions(self):
        """Get parameter definitions (#define statements) from force field sections"""
        if self.mode == 'r':
            return getattr(self, '_parameter_definitions', {})
        self.mode = 'r'
        self.__read()
        return getattr(self, '_parameter_definitions', {})

    @staticmethod
    def __get_molecules(topology):
        molecules = []
        for line in topology.splitlines()[::-1]:
            if Itp.__section_is_in_string('molecules', line):
                break
            if line.strip() == '' or line.startswith(';'):
                continue
            molecule_name, number_of_molecules = line.split()
            molecules += [(molecule_name, int(number_of_molecules))]
        return molecules[::-1]

    @staticmethod
    def __section_is_in_string(section, string):
        return bool('[' in string and ']' in string and section in string)

    @staticmethod
    def __get_section(section, string):
        # Find all sections of the given type
        # Use re.escape to handle special characters like '+' in section names
        # Use a flexible regex to handle comments and empty lines
        section_regex = re.compile(
            r"\[\s*" + re.escape(str(section)) + r"\s*\]\s*\n((?:.*?)(?=\n\s*\[|\Z))",
            re.DOTALL | re.MULTILINE
        )
        section_list = section_regex.findall(string)
        
        # Filter out lines that are directives or not part of the section content
        filtered_sections = []
        for section_content in section_list:
            # Split into lines and filter out directives and empty lines
            lines = section_content.split('\n')
            filtered_lines = []
            for line in lines:
                line = line.strip()
                # Skip empty lines, comments, and directives
                if (line and 
                    not line.startswith(';') and 
                    not line.startswith('#') and
                    not line.startswith('#include')):
                    filtered_lines.append(line)
            if filtered_lines:
                filtered_sections.append('\n'.join(filtered_lines))
        
        return filtered_sections

    @staticmethod
    def __parse_block_till_section(itp, *sections):

        def get_section_headers(string):
            section_header_regex = re.compile(r"\[\s*(.*?)\s*\]", re.MULTILINE)
            section_headers = section_header_regex.findall(string)
            return section_headers

        part_of_itp = ''
        read_sections = []
        for chunk in itp:
            part_of_itp += chunk
            sections_in_chunk = get_section_headers(chunk)
            read_sections += sections_in_chunk
            # All wanted section headers have been passed and last section has been read completely
            if set(sections).issubset(read_sections) and read_sections[-1] != sections[-1]:
                break
        return part_of_itp

    def __get_included_topology_files(self, string, comments=';'):
        string = clean(string, comments)
        include_file_regex = re.compile(r"#include\s+[\"\'](.+)\s*[\"\']", re.MULTILINE)
        included_itps = include_file_regex.findall(string)

        if self.gmxdata is None:
            included_itps = [join(dirname(self.file), itp) for itp in included_itps]
        else:
            included_itps = [join(dirname(self.file), itp) if isfile(join(dirname(self.file), itp)) \
                         else join(self.gmxdata, itp) for itp in included_itps]
        return included_itps

    def __get_all_atomtypes_sections(self):
        itp_file = Parser(self.file, self.buffer)
        itp_text = Itp.__parse_block_till_section(itp_file, 'atomtypes')
        clean_itp_text = clean(itp_text,  comments=';')
        atomtypes_section = "\n".join(Itp.__get_section('atomtypes', clean_itp_text))
        if atomtypes_section == "":
            included_itps = self.__get_included_topology_files(clean_itp_text)
            for included_itp in included_itps:
                try:
                    itp = Itp(included_itp, mode='w')
                    atom_types = itp.__get_all_atomtypes_sections()
                    if atom_types is not None:
                        atomtypes_section += atom_types
                except OSError:
                    pass # do not print warning, it will be caught by top.py
            return atomtypes_section
        return atomtypes_section

    def __read_atomtypes(self):
        atomtypes_section = clean(self.__get_all_atomtypes_sections(), comments='#') # clean directives within atomtypes section
        cols = ['type', 'X', 'mass', 'charge', 'ptype', 'sigma', 'epsilon']
        float_cols = [cols[i] for i in range(7) if i in [2,3,5,6]]
        atm_types_section_dct = {k:[] for k in cols}
        for line in atomtypes_section.splitlines():
            line_split = line.split()
            if len(line_split) not in [6, 7, 8]:
                raise ParserError(self.file, 'GROMACS topology',
                        details='following line in [ atomtypes ] section not formatted properly: {}'.format(line))
            
            if len(line_split) == 8:
                # assume line is of format: name  bond_type  atom_no  mass    charge   ptype          sigma      epsilon
                line_split = line_split[:1] + line_split[2:] # second value is bond type, ignore it
                    
            if len(line_split) == 6:
                line_split.insert(1, 'X')

            for i, col in enumerate(cols):
                atm_types_section_dct[col].append(float(line_split[i]) if col in float_cols else line_split[i])
        
        self.atom_types_df = pd.DataFrame(atm_types_section_dct)
        df = self.atom_types_df.copy()

        convert_elem = lambda x: ELEMENTS[int(x)] if x.isnumeric() and int(x) > 0 else None
        elem_col = cols[1]
        df[elem_col] = df[elem_col].apply(convert_elem)
        df = df[df[elem_col].notnull()]
        df = df.set_index(cols[0])
        return df[elem_col].to_dict()
    
    def __read_as_topol(self):
        top_parser = Parser(self.file)
        topology = ''.join(top_parser)
        self._molecules = Itp.__get_molecules(topology)
        self._molecule_types = [m[0] for m in self._molecules]
        self._topology_files = self.__get_included_topology_files(topology)
        self._topology_files.append(self.file)
        self.requested_molecules = self._molecule_types
        
    #### Read moleculaes, atoms, bonds
    #
    def __load_molecules_and_atoms(self):
        itp_file = Parser(self.file, self.buffer)
        itp_text = ''
        while not itp_file.is_closed:
            chunk = next(itp_file, '')
            if chunk == '':
                break
            itp_text += chunk
        return itp_text

    def __guess_element_from(self, mass, name, atom_type):
        mass_int = int(round(mass))

        if mass_int == 1:  # Guess H from mass
            element = 'H'
        elif mass_int < 36 and mass_int > 1:  # Guess He to Cl from mass
            element = ELEMENTS[mass_int//2]
        elif name.title() in ELEMENTS.values():  # Guess from atom name
            element = name.title()
        elif atom_type.title() in ELEMENTS.values():  # Guess from atom type
            element = atom_type.title()
        elif name[0] in ELEMENTS.values():
            element = name[0]
        elif atom_type[0] in ELEMENTS.values():
            element = atom_type[0]
        else:
            element = 'H'
            logging.error('Atomic number for atom with type {} and name {} cannot'
                          ' be guessed. A default value of H was assigned'.format(atom_type, name))
        self.guessed_elems_history[atom_type] = element
        return element
    
    def __read_atoms(self, atom_section):
        cols = self.columns
        atom_info = {k:[] for k in cols}
        number_of_bad_lines = 0
        for i, line in enumerate(atom_section.splitlines()):
            line = line.split(';', 1)[0].strip()  # Remove comments
            if not line:
                continue
            line = line.split()
            if len(line) == 8 or len(line) == 11: # Full format with cgnr; len 11 for perturbed molecule in a free energy perturbation calculation (see issue 57)
                number, atom_type, resid, resname, name, cgnr, charge, mass = line[:8]
            elif len(line) == 7:
                # Check if the last field looks like a mass (numeric) or charge (numeric)
                # If both charge and mass are numeric, assume mass is included
                try:
                    # If both are numeric, assume format: number, type, resid, resname, name, charge, mass
                    number, atom_type, resid, resname, name, charge, mass = line[:7]
                    cgnr = number  # Use atom number as cgnr if not provided
                except ValueError:
                    # If mass is not numeric, assume format: number, type, resid, resname, name, charge, _
                    number, atom_type, resid, resname, name, charge, _ = line[:7]
                    mass = 0.0
                    cgnr = number  # Use atom number as cgnr if not provided
            else:
                if number_of_bad_lines > 5:
                    raise ParserError(self.file, 'GROMACS topology',
                                      details='Too many bad lines in [ atoms ] section.')
                logging.error('Atom %s in [ atoms ] section is not formatted properly. Skipping.', i)
                number_of_bad_lines += 1
                continue
            number = int(number)
            resid = int(resid)
            cgnr = int(cgnr)
            charge = float(charge)
            mass = float(mass)
            if self.atom_types_dict is not None and atom_type in self.atom_types_dict:
                element = self.atom_types_dict[atom_type]
            elif self.guess_elements:
                element = self.__guess_element_from(mass, name, atom_type)
            else:
                raise ParserError(self.file, 'GROMACS topology', details=('No atomic number information'
                                 ' for atom with name {} and type {} in residue {}'.format(name, atom_type, resname)))
            atom_info[cols[0]].append(number)
            atom_info[cols[1]].append(atom_type)
            atom_info[cols[2]].append(resid)
            atom_info[cols[3]].append(resname)
            atom_info[cols[4]].append(name)
            atom_info[cols[5]].append(cgnr)
            atom_info[cols[6]].append(charge)
            atom_info[cols[7]].append(element)
            atom_info[cols[8]].append(mass)
        atoms = pd.DataFrame(atom_info).set_index(cols[0])
        return atoms
    
    @staticmethod
    def __read_bonds(bonds_section):
        cols = ['atom_i', 'atom_j', 'func', 'param1', 'param2']
        bonds_section_dct = {k:[] for k in cols}
        for line in bonds_section.splitlines():
            line_split = line.split()
            if line_split != []:
                # First 3 columns are always present (2 indices + func)
                for i in range(3):
                    bonds_section_dct[cols[i]].append(int(line_split[i]))
                
                # Handle parameters
                for i in range(3, len(cols)):
                    bonds_section_dct[cols[i]].append(float(line_split[i]) if i < len(line_split) else None)
        
        return (bonds_section_dct[cols[0]], bonds_section_dct[cols[1]], 
                bonds_section_dct[cols[2]], bonds_section_dct[cols[3]], bonds_section_dct[cols[4]])
    

    @staticmethod
    def __read_angles(angles_section):
        cols = ['atom_i', 'atom_j', 'atom_k', 'func', 'param1', 'param2']
        angles_section_dct = {k:[] for k in cols}
        for line in angles_section.splitlines():
            line_split = line.split()
            if line_split != []:
                # First 4 columns are always present (3 indices + func)
                for i in range(4):
                    angles_section_dct[cols[i]].append(int(line_split[i]))
                
                # Handle parameters
                for i in range(4, len(cols)):
                    angles_section_dct[cols[i]].append(float(line_split[i]) if i < len(line_split) else None)
        
        return (angles_section_dct[cols[0]], angles_section_dct[cols[1]], angles_section_dct[cols[2]],
                angles_section_dct[cols[3]], angles_section_dct[cols[4]], angles_section_dct[cols[5]])

    @staticmethod
    def __read_dihedrals(dihedrals_section, parameter_definitions=None):
        """Read dihedrals from a section, handling parameter references
        
        Args:
            dihedrals_section (str): Content of [ dihedrals ] section
            parameter_definitions (dict, optional): Dictionary of #define statements
            
        Returns:
            tuple: Dihedral data in the same format as before
        """
        # Handle all three dihedral formats:
        # Format 1: ai aj ak al func phi0 cp mult (func can be 1, 4, or 9)
        # Format 2: ai aj ak al func param1 param2
        # Format 3: ai aj ak al func C0 C1 C2 C3 C4 C5
        cols = ['atom_i', 'atom_j', 'atom_k', 'atom_l', 'func']
        dihedrals_section_dct = {k:[] for k in cols}
        
        # Initialize parameter lists
        phi0 = []  # Format 1, 4, 9
        cp = []    # Format 1, 4, 9
        mult = []  # Format 1, 4, 9
        param1 = []  # Format 2
        param2 = []  # Format 2
        C0 = []    # Format 3
        C1 = []    # Format 3
        C2 = []    # Format 3
        C3 = []    # Format 3
        C4 = []    # Format 3
        C5 = []    # Format 3
        
        def add_none_params():
            """Helper function to add None for all parameters"""
            phi0.append(None)
            cp.append(None)
            mult.append(None)
            param1.append(None)
            param2.append(None)
            C0.append(None)
            C1.append(None)
            C2.append(None)
            C3.append(None)
            C4.append(None)
            C5.append(None)
        
        for line in dihedrals_section.splitlines():
            line = line.strip()
            if line and not line.startswith(';'):
                parts = line.split()
                if len(parts) >= 5:
                    # First 5 columns are always present (4 indices + func)
                    for i in range(5):
                        dihedrals_section_dct[cols[i]].append(int(parts[i]) if i < len(parts) else None)
                    
                    func_type = int(parts[4])
                    
                    # Handle parameters
                    if len(parts) > 5:
                        # Check if the 6th part is a parameter reference (contains letters)
                        is_parameter_reference = (parameter_definitions and 
                                                len(parts) >= 6 and 
                                                any(c.isalpha() for c in parts[5]))
                        
                        if is_parameter_reference:
                            # Handle parameter reference
                            param_ref = parts[5]
                            if param_ref in parameter_definitions:
                                param_values = parameter_definitions[param_ref].split()
                                if len(param_values) >= 3:
                                    # Format: phi0 cp mult
                                    phi0.append(float(param_values[0]))
                                    cp.append(float(param_values[1]))
                                    mult.append(int(param_values[2]))
                                    # Add None for other parameters
                                    param1.append(None)
                                    param2.append(None)
                                    C0.extend([None] * 6)
                                    C1.extend([None] * 6)
                                    C2.extend([None] * 6)
                                    C3.extend([None] * 6)
                                    C4.extend([None] * 6)
                                    C5.extend([None] * 6)
                                else:
                                    add_none_params()
                            else:
                                add_none_params()
                        else:
                            # Standard format handling
                            if func_type in [1, 4, 9]:  # Format 1
                                phi0.append(float(parts[5]) if len(parts) > 5 else None)
                                cp.append(float(parts[6]) if len(parts) > 6 else None)
                                mult.append(int(parts[7]) if len(parts) > 7 else None)
                                param1.append(None)
                                param2.append(None)
                                C0.extend([None] * 6)
                                C1.extend([None] * 6)
                                C2.extend([None] * 6)
                                C3.extend([None] * 6)
                                C4.extend([None] * 6)
                                C5.extend([None] * 6)
                            elif func_type == 2:  # Format 2
                                param1.append(float(parts[5]) if len(parts) > 5 else None)
                                param2.append(float(parts[6]) if len(parts) > 6 else None)
                                phi0.append(None)
                                cp.append(None)
                                mult.append(None)
                                C0.extend([None] * 6)
                                C1.extend([None] * 6)
                                C2.extend([None] * 6)
                                C3.extend([None] * 6)
                                C4.extend([None] * 6)
                                C5.extend([None] * 6)
                            elif func_type == 3:  # Format 3
                                C0.append(float(parts[5]) if len(parts) > 5 else None)
                                C1.append(float(parts[6]) if len(parts) > 6 else None)
                                C2.append(float(parts[7]) if len(parts) > 7 else None)
                                C3.append(float(parts[8]) if len(parts) > 8 else None)
                                C4.append(float(parts[9]) if len(parts) > 9 else None)
                                C5.append(float(parts[10]) if len(parts) > 10 else None)
                                phi0.append(None)
                                cp.append(None)
                                mult.append(None)
                                param1.append(None)
                                param2.append(None)
                    else:
                        # No parameters provided
                        add_none_params()
        
        # Return all parameters in a structured way
        return (dihedrals_section_dct[cols[0]], dihedrals_section_dct[cols[1]], 
                dihedrals_section_dct[cols[2]], dihedrals_section_dct[cols[3]],
                dihedrals_section_dct[cols[4]],  # func
                phi0,  # Format 1
                cp,
                mult,
                param1,  # Format 2
                param2,
                C0,  # Format 3
                C1,
                C2,
                C3,
                C4,
                C5)
    
    @staticmethod
    def __get_molecules_with_interaction_section(string, interaction_type):
        # Find all moleculetype sections and their following interaction sections
        section_regex = re.compile(r"\[\s*moleculetype\s*\]\s*\n((?:.+\n)+?)\s*\[\s*" + interaction_type + r"\s*\]", re.MULTILINE)
        section_list = section_regex.findall(string)
        
        # If no sections found, try to find just the interaction sections
        if not section_list:
            section_regex = re.compile(r"\[\s*" + interaction_type + r"\s*\]", re.MULTILINE)
            section_list = section_regex.findall(string)
            
        return section_list

    @staticmethod
    def __read_pairs(pairs_section):
        cols = ['atom_i', 'atom_j', 'func']
        pairs_section_dct = {k:[] for k in cols}
        for line in pairs_section.splitlines():
            line_split = line.split()
            if line_split != []:
                # First 3 columns are always present (2 indices + func)
                for i in range(3):
                    pairs_section_dct[cols[i]].append(int(line_split[i]))
        
        return (pairs_section_dct[cols[0]], pairs_section_dct[cols[1]], 
                pairs_section_dct[cols[2]])

    @staticmethod
    def __read_bondtypes(bondtypes_section):
        """Read bond types from force field section
        
        Args:
            bondtypes_section (str): Content of [ bondtypes ] section
            
        Returns:
            dict: Dictionary of bond type parameters keyed by atom type pairs
        """
        bondtypes = {}
        for line in bondtypes_section.splitlines():
            line = line.strip()
            if line and not line.startswith(';'):
                parts = line.split()
                if len(parts) >= 5:
                    atom1, atom2 = parts[0], parts[1]
                    func = int(parts[2])
                    param1 = float(parts[3])  # bond length
                    param2 = float(parts[4])  # force constant
                    key = f"{atom1}-{atom2}"
                    bondtypes[key] = {
                        'function': func,
                        'length': param1,
                        'force_constant': param2
                    }
        return bondtypes

    @staticmethod
    def __read_angletypes(angletypes_section):
        """Read angle types from force field section
        
        Args:
            angletypes_section (str): Content of [ angletypes ] section
            
        Returns:
            dict: Dictionary of angle type parameters keyed by atom type triplets
        """
        angletypes = {}
        for line in angletypes_section.splitlines():
            line = line.strip()
            if line and not line.startswith(';'):
                parts = line.split()
                if len(parts) >= 6:
                    atom1, atom2, atom3 = parts[0], parts[1], parts[2]
                    func = int(parts[3])
                    param1 = float(parts[4])  # angle value
                    param2 = float(parts[5])  # force constant
                    key = f"{atom1}-{atom2}-{atom3}"
                    angletypes[key] = {
                        'function': func,
                        'angle': param1,
                        'force_constant': param2
                    }
        return angletypes

    @staticmethod
    def __read_dihedraltypes(dihedraltypes_section):
        """Read dihedral types from force field section
        
        Args:
            dihedraltypes_section (str): Content of [ dihedraltypes ] section
            
        Returns:
            dict: Dictionary of dihedral type parameters keyed by atom type quartets
        """
        dihedraltypes = {}
        for line in dihedraltypes_section.splitlines():
            line = line.strip()
            if line and not line.startswith(';'):
                parts = line.split()
                if len(parts) >= 5:
                    atom1, atom2, atom3, atom4 = parts[0], parts[1], parts[2], parts[3]
                    func = int(parts[4])
                    key = f"{atom1}-{atom2}-{atom3}-{atom4}"
                    
                    if func in [1, 4, 9]:  # Format 1
                        if len(parts) >= 8:
                            param1 = float(parts[5])  # phi0
                            param2 = float(parts[6])  # cp (force constant)
                            param3 = int(parts[7])    # mult
                            dihedraltypes[key] = {
                                'function': func,
                                'phi0': param1,
                                'cp': param2,
                                'mult': param3
                            }
                    elif func == 2:  # Format 2
                        if len(parts) >= 7:
                            param1 = float(parts[5])  # param1
                            param2 = float(parts[6])  # param2 (force constant)
                            dihedraltypes[key] = {
                                'function': func,
                                'param1': param1,
                                'param2': param2
                            }
                    elif func == 3:  # Format 3
                        if len(parts) >= 11:
                            params = [float(parts[i]) for i in range(5, 11)]  # C0-C5
                            dihedraltypes[key] = {
                                'function': func,
                                'params': params
                            }
        return dihedraltypes

    @staticmethod
    def __read_parameter_definitions(string):
        """Read #define statements from a string.
        
        Args:
            string (str): The string to search for #define statements.
            
        Returns:
            dict: A dictionary of #define statements keyed by their name.
        """
        define_regex = re.compile(r"#define\s+([a-zA-Z_][a-zA-Z0-9_]*)\s+(.*)", re.MULTILINE)
        definitions = {}
        for match in define_regex.finditer(string):
            name = match.group(1)
            value = match.group(2)
            definitions[name] = value
        return definitions

    def __read(self):
        itp_text = self.__load_molecules_and_atoms()
        clean_itp_text = clean(itp_text,  comments=[';', '#'])
        molecule_section = Itp.__get_section('moleculetype', clean_itp_text)
        atom_section = Itp.__get_section('atoms', clean_itp_text)
        
        # Read force field sections from current file
        bondtypes_section = Itp.__get_section('bondtypes', clean_itp_text)
        angletypes_section = Itp.__get_section('angletypes', clean_itp_text)
        dihedraltypes_section = Itp.__get_section('dihedraltypes', clean_itp_text)
        
        # Store force field data
        self._bondtypes = {}
        self._angletypes = {}
        self._dihedraltypes = {}
        self._parameter_definitions = {}  # Store #define statements
        
        # Read force field sections from current file
        if bondtypes_section:
            for section in bondtypes_section:
                self._bondtypes.update(Itp.__read_bondtypes(section))
        
        if angletypes_section:
            for section in angletypes_section:
                self._angletypes.update(Itp.__read_angletypes(section))
        
        if dihedraltypes_section:
            for section in dihedraltypes_section:
                self._dihedraltypes.update(Itp.__read_dihedraltypes(section))
        
        # Read parameter definitions (#define statements) from current file and included files
        # First, read from the original file content before cleaning
        original_content = self.__load_molecules_and_atoms()
        self._parameter_definitions = Itp.__read_parameter_definitions(original_content)
        
        # Also read force field sections from included files
        included_itps = self.__get_included_topology_files(original_content)
        for included_itp in included_itps:
            try:
                # Read the included file content
                with open(included_itp, 'r') as f:
                    included_content = f.read()
                
                # Clean the included file content
                clean_included_content = clean(included_content, comments=[';', '#'])
                
                # Read force field sections from included file
                included_bondtypes = Itp.__get_section('bondtypes', clean_included_content)
                included_angletypes = Itp.__get_section('angletypes', clean_included_content)
                included_dihedraltypes = Itp.__get_section('dihedraltypes', clean_included_content)
                
                # Add force field data from included file
                if included_bondtypes:
                    for section in included_bondtypes:
                        self._bondtypes.update(Itp.__read_bondtypes(section))
                
                if included_angletypes:
                    for section in included_angletypes:
                        self._angletypes.update(Itp.__read_angletypes(section))
                
                if included_dihedraltypes:
                    for section in included_dihedraltypes:
                        self._dihedraltypes.update(Itp.__read_dihedraltypes(section))
                        
            except OSError:
                pass  # Skip if file not found
        
        # Also read parameter definitions from included files
        included_itps = self.__get_included_topology_files(original_content)
        for included_itp in included_itps:
            try:
                # Read the included file content
                with open(included_itp, 'r') as f:
                    included_content = f.read()
                # Extract parameter definitions from included file
                included_definitions = Itp.__read_parameter_definitions(included_content)
                self._parameter_definitions.update(included_definitions)
            except OSError:
                pass  # Skip if file not found
        
        # If external parameter definitions are provided, merge them
        if self.external_parameter_definitions:
            self._parameter_definitions.update(self.external_parameter_definitions)
        
        if molecule_section == [] and atom_section == []:
            return None
        molecules = []
        atom_infos = []
        nrexcl_values = {}  # Store nrexcl values for each molecule
        for molecule, atoms in zip(molecule_section, atom_section):
            mol = molecule.split()[0]
            if self.requested_molecules is not None and mol not in self.requested_molecules:
                continue
            molecules.append(mol)
            atom_infos.append(self.__read_atoms(atoms))
            
            # Extract nrexcl value from moleculetype section
            parts = molecule.split()
            if len(parts) >= 2:
                try:
                    nrexcl_values[mol] = int(parts[1])
                except ValueError:
                    nrexcl_values[mol] = 3  # Default value if parsing fails
                    logging.warning(f'Could not parse nrexcl value for molecule {mol}, using default value 3')
        self._topol = dict(zip(molecules, atom_infos))
        self._nrexcl_values = nrexcl_values  # Store nrexcl values
        
        # Read bonds
        molecule_section = Itp.__get_molecules_with_interaction_section(clean_itp_text, 'bonds')
        bond_section = Itp.__get_section('bonds', clean_itp_text)
        bond_infos = []
        for molecule, bonds in zip(molecule_section, bond_section):
            mol = molecule.split()[0]
            if self.requested_molecules is not None and mol not in self.requested_molecules:
                continue
            bond_infos.append(Itp.__read_bonds(bonds))
        self._bonds = dict(zip(molecules, bond_infos))

        # Read angles
        molecule_section = Itp.__get_molecules_with_interaction_section(clean_itp_text, 'angles')
        angle_section = Itp.__get_section('angles', clean_itp_text)
        angle_infos = []
        for molecule, angles in zip(molecule_section, angle_section):
            mol = molecule.split()[0]
            if self.requested_molecules is not None and mol not in self.requested_molecules:
                continue
            angle_infos.append(Itp.__read_angles(angles))
        self._angles = dict(zip(molecules, angle_infos))

        # Read dihedrals - correctly handle multiple molecules with multiple dihedral sections
        dihedral_infos = []
        for mol in molecules:
            if self.requested_molecules is not None and mol not in self.requested_molecules:
                continue
            
            # Get all dihedral sections from the file
            all_dihedral_sections = Itp.__get_section('dihedrals', clean_itp_text)
            
            # For now, use a simple approach: assign dihedral sections based on their order
            # This assumes that dihedral sections appear in the same order as molecules
            mol_index = molecules.index(mol)
            
            # Each molecule typically has 2 dihedral sections (propers and impropers)
            # So we need to get sections 2*mol_index and 2*mol_index + 1
            mol_dihedral_sections = []
            start_idx = 2 * mol_index
            end_idx = start_idx + 2
            
            for i in range(start_idx, min(end_idx, len(all_dihedral_sections))):
                mol_dihedral_sections.append(all_dihedral_sections[i])
            
            # Combine all dihedral sections for this molecule
            if mol_dihedral_sections:
                combined_dihedrals = '\n'.join(mol_dihedral_sections)
                dihedral_infos.append(Itp.__read_dihedrals(combined_dihedrals, self._parameter_definitions))
            else:
                dihedral_infos.append(None)
        
        self._dihedrals = dict(zip(molecules, dihedral_infos))
        # Read pairs
        molecule_section = Itp.__get_molecules_with_interaction_section(clean_itp_text, 'pairs')
        pairs_section = Itp.__get_section('pairs', clean_itp_text)
        pairs_infos = []
        for molecule, pairs in zip(molecule_section, pairs_section):
            mol = molecule.split()[0]
            if self.requested_molecules is not None and mol not in self.requested_molecules:
                continue
            pairs_infos.append(Itp.__read_pairs(pairs))
        self._pairs = dict(zip(molecules, pairs_infos))

        # Store source file information for each molecule
        if hasattr(self, '_topol') and self._topol is not None:
            for mol in molecules:
                self._topol[mol].source_file = self.file
