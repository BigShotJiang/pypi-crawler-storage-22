#
#    MiMiCPy: Python Based Tools for MiMiC
#    Copyright (C) 2020-2023 Bharath Raghavan,
#                            Florian Schackert
#
#    This file is part of MiMiCPy.
#
#    MiMiCPy is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Lesser General Public License as
#    published by the Free Software Foundation, either version 3 of
#    the License, or (at your option) any later version.
#
#    MiMiCPy is distributed in the hope that it will be useful, but
#    WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#    GNU Lesser General Public License for more details.
#
#    You should have received a copy of the GNU Lesser General Public License
#    along with this program. If not, see <http://www.gnu.org/licenses/>.
#

"""Module for top files"""

import logging
from os import environ
from os.path import basename, join, isfile
from pathlib import Path
import pandas as pd
from .itp import Itp
from .topol_dict import TopolDict
from ..utils.errors import MiMiCPyError, ParserError
from ..utils.strings import print_dict
from ..utils.atomic_numbers import atomic_numbers
from ..utils.file_handler import read, write


class Top:
    """reads top files"""

    def __init__(self,
                 file, mode='r',
                 buffer=1000,
                 nonstandard_atomtypes=None,
                 guess_elements=True,
                 gmxdata=None):

        self.file = file
        self.mode = mode
        self.buffer = buffer
        self.nonstandard_atomtypes = nonstandard_atomtypes
        self.guess_elements = guess_elements

        if gmxdata is None:
            if 'GMXDATA' in environ:
                gmxdata = join(environ['GMXDATA'], 'top')
            elif 'GMXLIB' in environ:
                gmxdata = join(environ['GMXLIB'], 'top')

        self.gmxdata = gmxdata

        if self.gmxdata:
            logging.debug('Using {} as path to GROMACS installation'.format(self.gmxdata))
        else:
            self.gmxdata = ''
            logging.warning('Cannot find path to GROMACS installation')

        self.molecules = None
        self.bonds = None
        self.topol_dict = None
        self.mol_offsets = None
        self.nrexcl_values = {}  # Store nrexcl values for all molecules
        if mode == 'r':
            self.__read()
        elif mode == 'w':
            self.__read(True)
        else:
            raise MiMiCPyError('{} is not a mode. Only r or w can be used'.format(mode))

    def __read(self, get_only_atomtypes=False):
        """Read molecule and atom information"""

        top = Itp(self.file, mode='t', gmxdata=self.gmxdata)
        atom_types = top.atom_types
        self.atomtypes = top.atom_types_df
        if get_only_atomtypes: return
        molecule_types = top.molecule_types
        if self.nonstandard_atomtypes is not None:
            atom_types.update(self.nonstandard_atomtypes)
        
        self.atom_types_df = pd.DataFrame()
        atoms = {}
        bonds = {}
        angles = {}
        dihedrals = {}
        pairs = {}
        guessed_elems_history = {}
        source_files = {}  # Store source file information in a dictionary
        nrexcl_values = {}  # Store nrexcl values from all ITP files
        force_fields = {}  # Store force field data
        parameter_definitions = {}  # Store parameter definitions (#define statements)

        for itp_file in top.topology_files:
            itp_file_name = basename(itp_file)
            try:
                itp = Itp(itp_file,
                          molecule_types,
                          atom_types,
                          self.buffer,
                          'r',
                          self.guess_elements,
                          self.gmxdata,
                          parameter_definitions)
                _ = itp.atom_types
                if not itp.atom_types_df.empty:
                    self.atom_types_df = pd.concat([self.atom_types_df,itp.atom_types_df], axis=0, ignore_index=True)
                
                # Collect parameter definitions from all files (not just force field files)
                if itp.parameter_definitions:
                    parameter_definitions.update(itp.parameter_definitions)
                    logging.debug('Read parameter definitions from %s.', itp_file_name)
                
                # Check if this is a force field file (contains force field sections)
                if itp.bondtypes or itp.angletypes or itp.dihedraltypes:
                    # Extract force field name from filename
                    force_field_name = Path(itp_file_name).stem
                    if force_field_name not in force_fields:
                        force_fields[force_field_name] = {
                            'bondtypes': {},
                            'angletypes': {},
                            'dihedraltypes': {}
                        }
                    force_fields[force_field_name]['bondtypes'].update(itp.bondtypes)
                    force_fields[force_field_name]['angletypes'].update(itp.angletypes)
                    force_fields[force_field_name]['dihedraltypes'].update(itp.dihedraltypes)
                    logging.debug('Read force field parameters from %s.', itp_file_name)
                
                if itp.topol is not None:
                    atoms.update(itp.topol)
                    bonds.update(itp.bonds)
                    angles.update(itp.angles)
                    dihedrals.update(itp.dihedrals)
                    pairs.update(itp.pairs)
                    guessed_elems_history.update(itp.guessed_elems_history)
                    # Store source file information in dictionary
                    for mol in itp.topol:
                        if hasattr(itp.topol[mol], 'source_file'):
                            source_files[mol] = itp.topol[mol].source_file
                    # Store nrexcl values
                    nrexcl_values.update(itp.nrexcl_values)
                    logging.debug('Read atoms from %s.', itp_file_name)
                else:
                    logging.debug('No atoms found in %s.', itp_file_name)
            except OSError:
                logging.warning('Could not find %s in local or GROMACS data directory. Skipping.', itp_file_name)
                
        self.molecules = top.molecules
        
        # Create TopolDict with all collected data
        self.topol_dict = TopolDict.from_dict(atoms, bonds, angles, dihedrals, pairs)
        # Add source file information to TopolDict
        for mol, source_file in source_files.items():
            self.topol_dict.add_source_file(mol, source_file)
        # Add nrexcl values to TopolDict
        for mol, nrexcl in nrexcl_values.items():
            self.topol_dict.add_nrexcl_value(mol, nrexcl)
        # Add force field data to TopolDict
        for force_field_name, ff_data in force_fields.items():
            self.topol_dict.add_force_field(
                force_field_name,
                bondtypes=ff_data['bondtypes'],
                angletypes=ff_data['angletypes'],
                dihedraltypes=ff_data['dihedraltypes']
            )
        # Add parameter definitions to TopolDict
        self.topol_dict.add_parameter_definitions(parameter_definitions)
        # Store nrexcl values
        self.nrexcl_values = nrexcl_values
        self.bonds = self.__get_bonds(bonds)

        mol_offsets = []
        offset = 0
        for mol, n_mols in self.molecules:
            mol_len = len(self.topol_dict[mol])
            for i in range(n_mols):
                mol_offsets.append((mol, offset))
                offset += mol_len
        self.mol_offsets = mol_offsets

        mols_not_in = self.topol_dict.check_mols(self.molecules)

        if mols_not_in:
            raise ParserError(file=self.file, file_type='GROMACS topology',
                            details="{} defined in the [ molecules ] section did not have corresponding [ atoms ] definition(s)".format(
                                ", ".join(mols_not_in)))
        if guessed_elems_history:
            logging.warning('\nSome atom types had no atom number information.\nThey were guessed as follows:\n')
            print_dict(guessed_elems_history, "Atom Type", "Element", logging.warning)
    
    def __get_bonds(self, bonds):
        prev_natoms = 0

        cols = ['atom_i', 'atom_j']
        bonds_section_dct = {k:[] for k in cols}

        for mol, n_mols in self.molecules:
            for i in range(n_mols):    
                if mol in bonds:
                    bonds_section_dct['atom_i'] += [i+prev_natoms for i in bonds[mol][0]]
                    bonds_section_dct['atom_j'] += [i+prev_natoms for i in bonds[mol][1]]
                prev_natoms += len(self.topol_dict[mol])
        
        return pd.DataFrame(bonds_section_dct)
        
    
    def write_atomtypes(self, file=None, delete_atomtypes=None):
        """Write atomtypes to a file with support for modifying multiple files
        
        Args:
            file (str, optional): Target file to write atomtypes to. If None, uses self.file
            delete_atomtypes (list, optional): List of files to delete atomtypes sections from
        """
        if file is None:
            file = self.file

        if self.mode != 'w':
            self.mode = 'w'
            self.__read(True)

        # Get elements from topology dictionary
        elements = {}
        for k, df in self.topol_dict.todict().items():
            elements.update(dict(zip(df['type'], df['element'])))
        elements = {k:atomic_numbers[v] for k,v in elements.items()}

        # Create atomtypes string
        itp_str = "; Created by mimicpy fixtop\n[ atomtypes ]\n"
        itp_str += ";  {:^11}{:^6}{:^10}{:^10}{:^6}     {}     {}\n".format(
            'name', 'at.num', 'mass', 'charge', 'ptype', 'sigma', 'epsilon')
        
        for i, row in self.atomtypes.iterrows():
            lst = [row[c] for c in self.atomtypes.columns]
            if lst[0] in elements:
                lst[1] = elements[lst[0]]
            else:
                lst[1] = int(lst[1])
            itp_str += "{:>11}{:6d}{:11.4f}{:11.4f}{:>6}     {:e}     {:e}\n".format(*lst)

        # Handle deletion of atomtypes sections from other files
        if delete_atomtypes is not None:
            import re
            r = re.compile(r"(\[\s*atomtypes\s*\]\n(?:.+\n)+?)\s*(?:$|\[|#)", re.MULTILINE)
            for i in delete_atomtypes:
                txt = read(i)
                atm_typs = r.findall(txt)
                for j in atm_typs:
                    txt = txt.replace(j, '')
                write(txt, i)
            logging.info('Deleted atomtypes sections from %s', ', '.join(delete_atomtypes))

        # Write to target file
        if isfile(file):
            txt = read(file)
            atm_typs = r.findall(txt)
            if atm_typs != []:
                write(txt.replace(atm_typs[0], itp_str), file)
                logging.info('Fixed and replaced [ atomtypes ] section in %s', file)
            else:
                raise FileExistsError('%s exists and has no [ atomtypes ] section to replace', file)
        else:
            write(itp_str, file)
            logging.info('Fixed [ atomtypes ] section and wrote to %s', file)

    def write_topology(self, output_file):
        """Write complete topology to file including all interactions
        
        Args:
            output_file (str): Path to output file
        """
            
        # Write system name
        top_str = "; Created by mimicpy\n"
        top_str += "[ system ]\n"
        top_str += "; Name\n"
        top_str += "System\n\n"
        
        # Write molecules section
        top_str += "[ molecules ]\n"
        top_str += "; Compound        #mols\n"
        for mol, n_mols in self.molecules:
            top_str += f"{mol:16s} {n_mols:6d}\n"
        top_str += "\n"
        
        # Write atomtypes section
        top_str += "[ atomtypes ]\n"
        top_str += ";  {:^11}{:^6}{:^10}{:^10}{:^6}     {}     {}\n".format(
            'name', 'at.num', 'mass', 'charge', 'ptype', 'sigma', 'epsilon')
        
        # Get unique atom types from topology
        atom_types = set()
        for mol in self.topol_dict.keys():
            atom_types.update(self.topol_dict[mol]['type'].unique())

        for atom_type in sorted(atom_types):
            row = self.atom_types_df.loc[atom_type]
            top_str += "{:>11}{:6d}{:11.4f}{:11.4f}{:>6}     {:e}     {:e}\n".format(
                row['type'], row['X'], row['mass'], row['charge'],
                row['ptype'], row['sigma'], row['epsilon'])
        top_str += "\n"
        
        # Write molecule types and their interactions to separate .itp files
        for mol, n_mols in self.molecules:
            # Create .itp file for this molecule
            itp_file = f"{mol}.itp"
            
            # Get nrexcl value for this molecule
            nrexcl = self.topol_dict.get_nrexcl_value(mol)
            
            itp_str = f"; Created by mimicpy\n[ moleculetype ]\n; Name            nrexcl\n{mol:16s} {nrexcl}\n\n"
            
            # Write atoms section
            itp_str += "[ atoms ]\n"
            itp_str += ";   nr    type   resnr  residu    atom    cgnr        charge          mass\n"
            atoms_df = self.topol_dict[mol]
            for idx, row in atoms_df.iterrows():
                itp_str += f"{idx:6d} {row['type']:8s} {row['resid']:6d} {row['resname']:8s} {row['name']:8s} {row['charge']:8.4f} {row['mass']:12.4f}\n"
            itp_str += "\n"
            
            # Get interactions for this molecule
            mol_bonds = self.topol_dict.get_bonds(mol)
            mol_angles = self.topol_dict.get_angles(mol)
            mol_dihedrals = self.topol_dict.get_dihedrals(mol)
            mol_pairs = self.topol_dict.get_pairs(mol)
            # Write bonds
            if mol_bonds:
                itp_str += "[ bonds ]\n"
                itp_str += ";  ai    aj funct    param1    param2\n"
                for j in range(len(mol_bonds[0])):
                    i_idx = mol_bonds[0][j]
                    j_idx = mol_bonds[1][j]
                    func = mol_bonds[2][j]
                    p1 = mol_bonds[3][j]
                    p2 = mol_bonds[4][j]
                    itp_str += f"{i_idx:6d} {j_idx:6d} {func:6d} {p1:10.5E} {p2:10.5E}\n"
                itp_str += "\n"
            
            # Write pairs
            if mol_pairs:
                itp_str += "[ pairs ]\n"
                itp_str += ";  ai    aj funct\n"
                for j in range(len(mol_pairs[0])):
                    i_idx = mol_pairs[0][j]
                    j_idx = mol_pairs[1][j]
                    func = mol_pairs[2][j]
                    itp_str += f"{i_idx:6d} {j_idx:6d} {func:6d}\n"
                itp_str += "\n"
            # Write angles
            if mol_angles:
                itp_str += "[ angles ]\n"
                itp_str += ";  ai    aj    ak funct    param1    param2\n"
                for j in range(len(mol_angles[0])):
                    i_idx = mol_angles[0][j]
                    j_idx = mol_angles[1][j]
                    k_idx = mol_angles[2][j]
                    func = mol_angles[3][j]
                    p1 = mol_angles[4][j]
                    p2 = mol_angles[5][j]
                    itp_str += f"{i_idx:6d} {j_idx:6d} {k_idx:6d} {func:6d} {p1:10.5E} {p2:10.5E}\n"
                itp_str += "\n"
            
            # Write dihedrals
            if mol_dihedrals:
                # Group dihedrals by function type
                dihedrals_by_func = {}
                for j in range(len(mol_dihedrals[0])):
                    func = mol_dihedrals[4][j]
                    if func not in dihedrals_by_func:
                        dihedrals_by_func[func] = []
                    dihedrals_by_func[func].append(j)
                
                # Write each function type in a separate section
                for func, indices in dihedrals_by_func.items():
                    itp_str += "[ dihedrals ]\n"
                    # Write header based on function type
                    if func in [1, 4, 9]:  # Format 1
                        itp_str += ";  ai    aj    ak    al funct    phi0       cp     mult\n"
                    elif func == 2:  # Format 2
                        itp_str += ";  ai    aj    ak    al funct    param1    param2\n"
                    elif func == 3:  # Format 3
                        itp_str += ";  ai    aj    ak    al funct    C0       C1       C2       C3       C4       C5\n"
                    
                    for j in indices:
                        i_idx = mol_dihedrals[0][j]
                        j_idx = mol_dihedrals[1][j]
                        k_idx = mol_dihedrals[2][j]
                        l_idx = mol_dihedrals[3][j]
                        
                        if func in [1, 4, 9]:  # Format 1
                            phi0 = mol_dihedrals[5][j]
                            cp = mol_dihedrals[6][j]
                            mult = mol_dihedrals[7][j]
                            itp_str += f"{i_idx:6d} {j_idx:6d} {k_idx:6d} {l_idx:6d} {func:6d} {phi0:8.1f} {cp:8.2f} {mult:6d}\n"
                        elif func == 2:  # Format 2
                            p1 = mol_dihedrals[8][j]
                            p2 = mol_dihedrals[9][j]
                            itp_str += f"{i_idx:6d} {j_idx:6d} {k_idx:6d} {l_idx:6d} {func:6d} {p1:8.3f} {p2:10.5E}\n"
                        elif func == 3:  # Format 3
                            c0, c1, c2, c3, c4, c5 = [mol_dihedrals[k][j] for k in range(10, 16)]
                            itp_str += f"{i_idx:6d} {j_idx:6d} {k_idx:6d} {l_idx:6d} {func:6d} {c0:8.5f} {c1:8.5f} {c2:8.5f} {c3:8.5f} {c4:8.5f} {c5:8.5f}\n"
                    itp_str += "\n"
            
            # Write the .itp file
            with open(itp_file, 'w') as f:
                f.write(itp_str)
            
            # Include the .itp file in the main topology
            top_str += f'#include "{itp_file}"\n'
        
        # Write the main topology file
        with open(output_file, 'w') as f:
            f.write(top_str)
        
        logging.info(f'Successfully wrote topology to {output_file}')
        return True
        
        