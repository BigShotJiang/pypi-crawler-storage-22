#
#    MiMiCPy: Python Based Tools for MiMiC
#    Copyright (C) 2020-2023 Bharath Raghavan,
#                            Florian Schackert
#
#    This file is part of MiMiCPy.
#
#    MiMiCPy is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Lesser General Public License as
#    published by the Free Software Foundation, either version 3 of
#    the License, or (at your option) any later version.
#
#    MiMiCPy is distributed in the hope that it will be useful, but
#    WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#    GNU Lesser General Public License for more details.
#
#    You should have received a copy of the GNU Lesser General Public License
#    along with this program. If not, see <http://www.gnu.org/licenses/>.
#

"""Module for MiMiCPy-specific molecule:topology dictionary"""

import logging


class TopolDict:
    """provides a dictionary with non-repeating topology information"""

    @classmethod
    def from_dict(cls, dict_df, bonds=None, angles=None, dihedrals=None, pairs=None):
        keys = list(dict_df.keys())
        repeating = {}
        repeating_bonds = {}
        repeating_angles = {}
        repeating_dihedrals = {}
        repeating_pairs = {}
        
        i = 0
        while i < len(keys):
            key_i = keys[i]
            for j in range(i+1, len(keys)):
                key_j = keys[j]
                if dict_df[key_i].equals(dict_df[key_j]):
                    repeating[key_j] = key_i
                    if bonds and key_j in bonds:
                        repeating_bonds[key_j] = key_i
                    if angles and key_j in angles:
                        repeating_angles[key_j] = key_i
                    if dihedrals and key_j in dihedrals:
                        repeating_dihedrals[key_j] = key_i
                    if pairs and key_j in pairs:
                        repeating_pairs[key_j] = key_i
                    del dict_df[key_j]
            i += 1
            keys = list(dict_df.keys())
        return cls(dict_df, repeating, bonds, angles, dihedrals, pairs,
                  repeating_bonds, repeating_angles, repeating_dihedrals, repeating_pairs)

    def __init__(self, dict_df, repeating, bonds=None, angles=None, dihedrals=None, pairs=None,
                 repeating_bonds=None, repeating_angles=None, repeating_dihedrals=None, repeating_pairs=None):
        self.dict_df = dict_df
        self.repeating = repeating
        self.bonds = bonds or {}
        self.angles = angles or {}
        self.dihedrals = dihedrals or {}
        self.pairs = pairs or {}
        self.repeating_bonds = repeating_bonds or {}
        self.repeating_angles = repeating_angles or {}
        self.repeating_dihedrals = repeating_dihedrals or {}
        self.repeating_pairs = repeating_pairs or {}
        # Add source file tracking
        self.source_files = {}
        self.nrexcl_values = {}  # Store nrexcl values for molecules
        self.mol_num_atoms = {mol: len(self.dict_df[mol]) for mol in self.dict_df}
        # Add force field storage
        self.force_fields = {}  # Store force field parameters by force field name
        self.parameter_definitions = {}  # Store parameter definitions (#define statements)

    def add_source_file(self, mol_name, source_file):
        """Add source file information for a molecule
        
        Args:
            mol_name (str): Name of the molecule
            source_file (str): Path to the source file
        """
        self.source_files[mol_name] = source_file

    def get_source_file(self, mol_name):
        """Get source file for a molecule
        
        Args:
            mol_name (str): Name of the molecule
            
        Returns:
            str: Path to the source file, or None if not found
        """
        if mol_name in self.source_files:
            return self.source_files[mol_name]
        if mol_name in self.repeating:
            return self.source_files.get(self.repeating[mol_name])
        return None

    def add_nrexcl_value(self, mol_name, nrexcl):
        """Add nrexcl value for a molecule
        
        Args:
            mol_name (str): Name of the molecule
            nrexcl (int): nrexcl value for the molecule
        """
        self.nrexcl_values[mol_name] = nrexcl

    def get_nrexcl_value(self, mol_name):
        """Get nrexcl value for a molecule
        
        Args:
            mol_name (str): Name of the molecule
            
        Returns:
            int: nrexcl value for the molecule, or 3 if not found (default)
        """
        if mol_name in self.nrexcl_values:
            return self.nrexcl_values[mol_name]
        if mol_name in self.repeating:
            return self.nrexcl_values.get(self.repeating[mol_name], 3)
        return 3  # Default value

    def add_force_field(self, force_field_name, bondtypes=None, angletypes=None, dihedraltypes=None):
        """Add force field parameters to the topology dictionary
        
        Args:
            force_field_name (str): Name of the force field
            bondtypes (dict): Bond type parameters
            angletypes (dict): Angle type parameters  
            dihedraltypes (dict): Dihedral type parameters
        """
        self.force_fields[force_field_name] = {
            'bondtypes': bondtypes or {},
            'angletypes': angletypes or {},
            'dihedraltypes': dihedraltypes or {}
        }

    def get_force_field(self, force_field_name):
        """Get force field parameters by name
        
        Args:
            force_field_name (str): Name of the force field
            
        Returns:
            dict: Force field parameters or None if not found
        """
        return self.force_fields.get(force_field_name)

    def get_force_field_bondtypes(self, force_field_name):
        """Get bond types for a specific force field
        
        Args:
            force_field_name (str): Name of the force field
            
        Returns:
            dict: Bond type parameters or empty dict if not found
        """
        ff = self.get_force_field(force_field_name)
        return ff.get('bondtypes', {}) if ff else {}

    def get_force_field_angletypes(self, force_field_name):
        """Get angle types for a specific force field
        
        Args:
            force_field_name (str): Name of the force field
            
        Returns:
            dict: Angle type parameters or empty dict if not found
        """
        ff = self.get_force_field(force_field_name)
        return ff.get('angletypes', {}) if ff else {}

    def get_force_field_dihedraltypes(self, force_field_name):
        """Get dihedral types for a specific force field
        
        Args:
            force_field_name (str): Name of the force field
            
        Returns:
            dict: Dihedral type parameters or empty dict if not found
        """
        ff = self.get_force_field(force_field_name)
        return ff.get('dihedraltypes', {}) if ff else {}

    def list_force_fields(self):
        """Get list of available force fields
        
        Returns:
            list: List of force field names
        """
        return list(self.force_fields.keys())

    def add_parameter_definitions(self, parameter_definitions):
        """Add parameter definitions (#define statements) to the topology dictionary
        
        Args:
            parameter_definitions (dict): Dictionary of parameter definitions
        """
        self.parameter_definitions.update(parameter_definitions)

    def get_parameter_definitions(self):
        """Get all parameter definitions
        
        Returns:
            dict: Dictionary of parameter definitions
        """
        return self.parameter_definitions

    def resolve_parameter_reference(self, param_ref):
        """Resolve a parameter reference to its actual values
        
        Args:
            param_ref (str): Parameter reference name (e.g., 'torsion_ASN_CA_CB_CG_ND2_mult1')
            
        Returns:
            list: List of parameter values or None if not found
        """
        if param_ref in self.parameter_definitions:
            param_str = self.parameter_definitions[param_ref]
            try:
                # Remove comments and parse the parameter values (e.g., "0.0 -4.376464 1")
                # Split by semicolon and take only the first part
                clean_param_str = param_str.split(';')[0].strip()
                values = [float(x) for x in clean_param_str.split()]
                return values
            except ValueError:
                logging.warning(f'Could not parse parameter definition for {param_ref}: {param_str}')
                return None
        return None

    def get_num_atoms(self, mol_name):
        """Get the number of atoms in a molecule
        
        Args:
            mol_name (str): Name of the molecule
            
        Returns:
            int: Number of atoms in the molecule
        """
        if mol_name not in self.mol_num_atoms:
            raise KeyError('Molecule {} is not in topology'.format(mol_name))
        return self.mol_num_atoms[mol_name]
    
    def __getitem__(self, key):
        if key in self.dict_df:
            return self.dict_df[key]
        if key in self.repeating:
            return self.dict_df[self.repeating[key]]
        raise KeyError('Molecule {} is not in topology'.format(key))

    def get_bonds(self, key):
        if key in self.bonds:
            return self.bonds[key]
        if key in self.repeating_bonds:
            return self.bonds[self.repeating_bonds[key]]
        return None

    def get_angles(self, key):
        if key in self.angles:
            return self.angles[key]
        if key in self.repeating_angles:
            return self.angles[self.repeating_angles[key]]
        return None

    def get_dihedrals(self, key):
        if key in self.dihedrals:
            return self.dihedrals[key]
        if key in self.repeating_dihedrals:
            return self.dihedrals[self.repeating_dihedrals[key]]
        return None

    def get_pairs(self, key):
        if key in self.pairs:
            return self.pairs[key]
        if key in self.repeating_pairs:
            return self.pairs[self.repeating_pairs[key]]
        return None

    def __contains__(self, key):
        return key in self.dict_df or key in self.repeating

    def todict(self):
        extras = self.dict_df.copy()
        for i in self.repeating:
            extras[i] = self.__getitem__(i)
        return extras

    def __str__(self):
        return str(self.todict())

    def __repr__(self):
        return repr(self.todict())

    def keys(self):
        """Handle keys of a TopolDict like keys of a regular dict"""
        combined_dict = self.dict_df.copy()
        combined_dict.update(self.repeating)
        all_keys = combined_dict.keys()
        return all_keys

    def check_mols(self, mols):
        return list(set([mol[0] for mol in mols if mol[0] not in self]))
