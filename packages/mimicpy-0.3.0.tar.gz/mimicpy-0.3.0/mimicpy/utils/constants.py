#
#    MiMiCPy: Python Based Tools for MiMiC
#    Copyright (C) 2020-2023 Bharath Raghavan,
#                            Florian Schackert
#
#    This file is part of MiMiCPy.
#
#    MiMiCPy is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Lesser General Public License as
#    published by the Free Software Foundation, either version 3 of
#    the License, or (at your option) any later version.
#
#    MiMiCPy is distributed in the hope that it will be useful, but
#    WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Lesser General Public License for more details.
#
#    You should have received a copy of the GNU Lesser General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#


BOHR_RADIUS = 5.29177210859e-02  # in nm
ATOMIC_TIME_UNIT = 2.4188843265864E-5  # in ps

au_kjm=2.62549962505e+3
kjm_au = 1 / au_kjm

au_to_nm = BOHR_RADIUS
nm_to_au = 1 / au_to_nm
au_to_kjmolnm = au_kjm / au_to_nm
kjmolnm_to_au = 1 / au_to_kjmolnm
kb_gmx2au = kjm_au / nm_to_au**2
kb_au2gmx = 1/ kb_gmx2au
kb_g962au = kjm_au / nm_to_au**4
kb_au2g96 = 1/ kb_g962au
electric_conversion_factor = 138.935458