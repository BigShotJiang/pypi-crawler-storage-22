#!/bin/bash
# Test runner
pytest tests/
