# Inference engine
def run_inference(prompt: str):
    pass
