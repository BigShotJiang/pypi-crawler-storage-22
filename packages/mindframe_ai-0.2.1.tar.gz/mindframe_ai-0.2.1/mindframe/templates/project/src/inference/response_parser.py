# Output formatting
def parse_response(response: str):
    pass
