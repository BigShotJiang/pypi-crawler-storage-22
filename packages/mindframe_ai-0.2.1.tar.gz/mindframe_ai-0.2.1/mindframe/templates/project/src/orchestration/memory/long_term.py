class LongTermMemory:
    def save(self, key, value):
        pass
    def load(self, key):
        pass
