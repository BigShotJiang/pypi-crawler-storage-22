# Text splitting
def chunk_text(text: str):
    pass
