# Data cleaning
def clean_text(text: str):
    pass
