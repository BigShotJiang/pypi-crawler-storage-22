# Tokenization utilities
def count_tokens(text: str):
    pass
