# Prompt templates
DEFAULT_QA_PROMPT = "Context: {context}\nQuestion: {question}"
