# Text to vector conversion
def get_embedding(text: str):
    pass
