# Document indexing
def index_documents(docs: list):
    pass
