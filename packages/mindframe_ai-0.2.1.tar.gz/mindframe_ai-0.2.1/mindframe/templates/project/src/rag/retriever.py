# Document search
def retrieve(query: str):
    pass
