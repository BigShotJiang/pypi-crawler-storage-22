# Vector DB wrapper
class VectorStore:
    pass
