# Tests LLM clients
def test_gpt_client():
    pass
