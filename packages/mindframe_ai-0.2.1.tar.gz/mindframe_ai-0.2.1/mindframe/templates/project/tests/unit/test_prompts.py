# Tests prompts
def test_prompt_template():
    pass
