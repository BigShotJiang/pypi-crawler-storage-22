from abc import ABC,abstractmethod
import torch
import torch.nn as nn

class Encoder(ABC,nn.Module):
    def __init__(self):
        super().__init__()

    @abstractmethod
    def forward(self,input):
        """Return dict of feature maps
        {
            "stage1": torch.Tensor,
            "stage2": torch.Tensor,
            "stage3": torch.Tensor,
            "stage4": torch.Tensor,
            "bottleneck": torch.Tensor
        }
        """
        pass

    @property
    @abstractmethod
    def out_channels(self):
        """List of channel dimensions for [stage1, stage2, stage3, stage4, bottleneck]."""
        pass