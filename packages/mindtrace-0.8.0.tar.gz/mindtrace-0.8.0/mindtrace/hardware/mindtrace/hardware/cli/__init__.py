"""Mindtrace Hardware CLI - Command-line interface for hardware management."""

__version__ = "0.1.0"
