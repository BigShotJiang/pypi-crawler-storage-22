"""
MineConnect - Minecraft Server Connection Bridge

Simple API for bridging Minecraft Java and Bedrock connections through 
WebSocket to Cloudflare tunnels.

Server Usage:
    from mineconnect import mcs
    
    session = mcs.config(tcp_port=25565, udp_port=19132, single_tunnel=False)
    session.start()

Client Usage:
    from mineconnect.client import MineConnectClient
    
    client = MineConnectClient(domain="ideadev.me")
    client.connect_both()
"""


from .server import MineConnectServer

__version__ = "1.1.0"
__all__ = ["MineConnectServer", "mcs"]


class _MCS:
    """Simple configuration wrapper for MineConnect server."""
    
    @staticmethod
    def config(tcp_port=25565, udp_port=19132, single_tunnel=False):
        """
        Configure a MineConnect server session.
        
        Args:
            tcp_port (int): Minecraft Java Edition server port (default: 25565)
            udp_port (int): Geyser/Bedrock server port (default: 19132)
            single_tunnel (bool): Use single tunnel with two ingress rules (default: False)
            
        Returns:
            MineConnectServer: Configured server instance
        """
        return MineConnectServer(
            tcp_port=tcp_port,
            udp_port=udp_port,
            single_tunnel=single_tunnel
        )


# Export the main server API
mcs = _MCS()
