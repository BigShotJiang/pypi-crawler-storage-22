"""
TCP <-> WebSocket Bridge for Minecraft Java Edition

Runs a WebSocket server. The client keeps a persistent WebSocket and
sends framed messages with session multiplexing:
  0x01 + [4B session_id] + data = new TCP session to MC (+ first chunk)
  0x02 + [4B session_id] + data = data for session
  0x03 + [4B session_id]        = close session

The bridge opens/closes TCP connections to the MC server accordingly,
supporting multiple concurrent Minecraft players per WebSocket.

Flow:
  MC Java Client -> [Client Tunnel] -> persistent WS -> [This Bridge] -> TCP -> MC Server
"""

import asyncio
import struct
import logging
import argparse

try:
    import websockets
except ImportError:
    raise SystemExit("Install websockets: pip install websockets")

logger = logging.getLogger("tcp-ws-bridge")

MSG_NEW   = b'\x01'
MSG_DATA  = b'\x02'
MSG_CLOSE = b'\x03'

_SESSION_ID_FMT = ">I"  # 4-byte big-endian unsigned int
_SESSION_ID_LEN = 4


async def handle_connection(websocket, mc_host: str, mc_port: int):
    """Handle persistent WS from client tunnel, manage multiplexed TCP sessions to MC."""
    peer = websocket.remote_address
    logger.info("Client tunnel connected: %s", peer)

    # session_id -> (reader, writer, tcp_read_task)
    sessions: dict[int, tuple[asyncio.StreamReader, asyncio.StreamWriter, asyncio.Task]] = {}

    async def _close_session(session_id: int):
        entry = sessions.pop(session_id, None)
        if entry is None:
            return
        _reader, _writer, _task = entry
        if _task and not _task.done():
            _task.cancel()
        if _writer:
            try:
                _writer.close()
            except OSError:
                pass
        logger.info("Closed TCP session %d for %s", session_id, peer)

    async def _close_all():
        for sid in list(sessions.keys()):
            await _close_session(sid)

    async def _tcp_reader(session_id: int, reader: asyncio.StreamReader):
        """Read from MC server TCP and send back over WS with session ID."""
        sid_bytes = struct.pack(_SESSION_ID_FMT, session_id)
        try:
            while True:
                data = await reader.read(65536)
                if not data:
                    break
                await websocket.send(MSG_DATA + sid_bytes + data)
        except (ConnectionResetError, asyncio.CancelledError, OSError):
            pass
        except websockets.ConnectionClosed:
            pass
        finally:
            # Server-side TCP closed — notify client
            try:
                await websocket.send(MSG_CLOSE + sid_bytes)
            except Exception:
                pass
            # Clean up our entry (if still there)
            entry = sessions.get(session_id)
            if entry and entry[0] is reader:
                sessions.pop(session_id, None)
                try:
                    entry[1].close()
                except OSError:
                    pass

    try:
        async for message in websocket:
            if isinstance(message, str):
                message = message.encode("utf-8")
            if not message or len(message) < 1 + _SESSION_ID_LEN:
                continue

            msg_type = message[0:1]
            session_id = struct.unpack(_SESSION_ID_FMT, message[1:1 + _SESSION_ID_LEN])[0]
            payload = message[1 + _SESSION_ID_LEN:]

            if msg_type == MSG_NEW:
                # Close any existing session with same ID (shouldn't happen, but be safe)
                await _close_session(session_id)

                # Open new TCP to MC server
                try:
                    reader, writer = await asyncio.open_connection(mc_host, mc_port)
                    logger.info("New TCP session %d to %s:%s for %s", session_id, mc_host, mc_port, peer)
                except (ConnectionRefusedError, OSError) as exc:
                    logger.error("Cannot reach MC for session %d: %s", session_id, exc)
                    sid_bytes = struct.pack(_SESSION_ID_FMT, session_id)
                    await websocket.send(MSG_CLOSE + sid_bytes)
                    continue

                # Start reading TCP responses
                task = asyncio.ensure_future(_tcp_reader(session_id, reader))
                sessions[session_id] = (reader, writer, task)

                # Forward the first chunk
                if payload:
                    writer.write(payload)
                    await writer.drain()

            elif msg_type == MSG_DATA:
                entry = sessions.get(session_id)
                if entry:
                    _, writer, _ = entry
                    try:
                        writer.write(payload)
                        await writer.drain()
                    except (ConnectionResetError, OSError):
                        await _close_session(session_id)
                        sid_bytes = struct.pack(_SESSION_ID_FMT, session_id)
                        await websocket.send(MSG_CLOSE + sid_bytes)

            elif msg_type == MSG_CLOSE:
                logger.info("Client closed TCP session %d for %s", session_id, peer)
                await _close_session(session_id)

    except websockets.ConnectionClosed:
        logger.info("Client tunnel disconnected: %s", peer)
    except Exception as exc:
        logger.error("Bridge error for %s: %s", peer, exc)
    finally:
        await _close_all()
        logger.info("All sessions ended for %s", peer)


async def run_bridge(ws_host: str, ws_port: int, mc_host: str, mc_port: int):
    """Main bridge coroutine."""
    logger.info(
        "TCP<->WS Bridge: ws://%s:%s <-> tcp://%s:%s",
        ws_host, ws_port, mc_host, mc_port,
    )

    async with websockets.serve(
        lambda ws: handle_connection(ws, mc_host, mc_port),
        ws_host,
        ws_port,
        max_size=None,
        ping_interval=20,
        ping_timeout=30,
    ):
        logger.info("Bridge ready \u2013 waiting for connections\u2026")
        await asyncio.Future()  # run forever


def main():
    """CLI entry point."""
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s",
    )
    
    parser = argparse.ArgumentParser(description="TCP<->WS Bridge for MC Java")
    parser.add_argument("--ws-host", default="127.0.0.1")
    parser.add_argument("--ws-port", type=int, default=8764)
    parser.add_argument("--mc-host", default="127.0.0.1")
    parser.add_argument("--mc-port", type=int, default=25565)
    args = parser.parse_args()

    try:
        asyncio.run(run_bridge(args.ws_host, args.ws_port, args.mc_host, args.mc_port))
    except KeyboardInterrupt:
        logger.info("Shutting down\u2026")


if __name__ == "__main__":
    main()
