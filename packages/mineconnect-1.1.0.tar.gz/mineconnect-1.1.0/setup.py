"""
MineConnect - Minecraft TCP/UDP to WebSocket Bridge with Cloudflare Tunnels
"""

from setuptools import setup, find_packages
import os

# Read README for long description
readme_path = os.path.join(os.path.dirname(__file__), "README.md")
with open(readme_path, "r", encoding="utf-8") as f:
    long_description = f.read()

# Read requirements
with open("requirements.txt", "r", encoding="utf-8") as f:
    requirements = [line.strip() for line in f if line.strip() and not line.startswith("#")]

setup(
    name="mineconnect",
    version="1.1.0",
    description="Minecraft TCP/UDP to WebSocket bridge with Cloudflare tunnel support",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Priyadarshan Mahankuda (httperry)",
    author_email="contact@ideadev.me",
    url="https://github.com/httperry/MineConnect",
    project_urls={
        "Bug Tracker": "https://github.com/httperry/MineConnect/issues",
        "Source Code": "https://github.com/httperry/MineConnect",
        "Documentation": "https://github.com/httperry/MineConnect#readme",
    },
    license="MIT",
    packages=find_packages(),
    install_requires=requirements,
    python_requires=">=3.8",
    entry_points={
        "console_scripts": [
            "mineconnect-client=mineconnect.client.cli:main",
        ],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: System Administrators",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Games/Entertainment",
        "Topic :: Internet :: Proxy Servers",
        "Topic :: System :: Networking",
    ],
    keywords=[
        "minecraft",
        "tunnel",
        "websocket",
        "cloudflare",
        "proxy",
        "tcp",
        "udp",
        "bedrock",
        "java-edition",
    ],
    package_data={
        "mineconnect": ["*.yml", "creds/*.json"],
    },
    include_package_data=True,
)
