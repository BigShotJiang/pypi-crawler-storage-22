import requests
import time

class Bedrock:
    def __init__(self, ip, port=19132, ttl = 10):
        self.ip = ip
        self.port = port
        self._data = None
        self._last_fetch = 0
        self.ttl = ttl

    def _fetch(self):
        now = time.time()

        if self._data is None or (now - self._last_fetch) > self.ttl:   # only fetch once
            try:
                res = requests.get(
                    f"https://api.mcstatus.io/v2/status/bedrock/{self.ip}:{self.port}",
                    timeout=5
                )
                self._data = res.json()
                self._last_fetch = now
            except Exception as e:
                # if request fails, keep old data instead of crashing
                if self._data is None:
                    self._data = {"online": False, "error": str(e)}

        return self._data

    def status(self):
        return self._fetch()["online"] or None

    def ip_address(self):
        return self._fetch()["ip_address"] or None

    def port_number(self):
        return self._fetch()["port"] or None
    
    def expires_at(self):
        return self._fetch()["expires_at"] or None
    
    def server_minecraft_version(self):
        return self._fetch()["version"] or None
    
    def players(self):
        return self._fetch()["players"] or None
    
    def gameMode(self):
        return self._fetch()["gamemode"] or None
    
    def server_id(self):
        return self._fetch()["server_id"] or None
    
    def edition(self):
        return self._fetch()["edition"] or None
    
    def software(self):
        return self._fetch()["software"] or None
    
    def plugins(self):
        return self._fetch()["plugins"] or []

    def raw(self):
        return self._fetch()