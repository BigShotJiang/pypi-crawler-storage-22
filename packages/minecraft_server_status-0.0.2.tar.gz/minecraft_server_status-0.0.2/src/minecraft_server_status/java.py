import requests
import time

class Java:
    def __init__(self, ip, port=25565, ttl = 10):
        self.ip = ip
        self.port = port
        self._data = None
        self._last_fetch = 0
        self.ttl = ttl

    def _fetchJ(self):
        now  = time.time()

        if self._data is None or (now - self._last_fetch)>self.ttl:
            try:
                data = requests.get(f"https://api.mcstatus.io/v2/status/java/{self.ip}:{self.port}", timeout=5)
                self._data = data.json()
                self._last_fetch = now

            except Exception as e:
                # if request fails, keep old data instead of crashing
                if self._data is None:
                    self._data = {"online": False, "error": str(e)}

        return self._data
    
    def status(self):
        return self._fetchJ()["online"] or None
    
    def ip(self):
        return self._fetchJ()["ip_address"] or None
    
    def expires_at(self):
        return self._fetchJ()["expires_at"] or None
    
    def srv_record(self):
        return self._fetchJ()["srv_record"] or None
    
    def java_minecraft_version(self):
        return self._fetchJ()["version"] or None
    
    def players(self):
        return self._fetchJ()["players"] or None
    
    def message_of_the_day(self):
        return self._fetchJ()["motd"] or None
    
    def icon(self):
        return self._fetchJ()["icon"] or None
    
    def mods(self):
        return self._fetchJ()["mods"] or None
    
    def software(self):
        return self._fetchJ()["software"] or None
    
    def plugins(self):
        return self._fetchJ()["plugins"] or []
    
    def raw(self):
        return self._fetchJ()
    