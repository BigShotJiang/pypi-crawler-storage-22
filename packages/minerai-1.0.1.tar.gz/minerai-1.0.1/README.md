# MinerAI

Google Drive integration package for AI inference tasks.

## Installation

```bash
pip install minerai