"""
MinerAI - Google Drive integration for AI inference
"""

from .drive import drive, MinerAIDrive
from .auth import get_drive

__version__ = "1.0.0"
__all__ = ["drive", "MinerAIDrive", "get_drive"]