import os
import pickle
import sys
import time
from google.auth.transport.requests import Request
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from .config import SCOPES, CREDENTIALS_FILE, TOKEN_FILE

def log_with_flush(message):
    """Internal logging function"""
    print(message)
    sys.stdout.flush()
    sys.stderr.flush()
    time.sleep(0.01)

def get_drive_service():
    """Get OAuth authenticated Drive service (internal use)"""
    creds = None
    
    # Check if credentials exist
    if not CREDENTIALS_FILE.exists() or not TOKEN_FILE.exists():
        log_with_flush("❌ OAuth credentials not found in package")
        log_with_flush("💡 Please ensure oauth_credentials.json and token.pickle are in the minerai/data/ directory")
        return None
    
    # Token file exists, load it
    if TOKEN_FILE.exists():
        try:
            with open(TOKEN_FILE, 'rb') as token:
                creds = pickle.load(token)
            log_with_flush("✅ Loaded OAuth token from package")
        except Exception as e:
            log_with_flush(f"⚠️ Failed to load token: {e}")
            return None
    
    # If we have credentials, check if they're valid
    if creds:
        if creds.expired and creds.refresh_token:
            try:
                creds.refresh(Request())
                log_with_flush("✅ Refreshed OAuth token")
                # Save the refreshed token back to package
                with open(TOKEN_FILE, 'wb') as token:
                    pickle.dump(creds, token)
            except Exception as e:
                log_with_flush(f"⚠️ Token refresh failed: {e}")
                return None
    else:
        log_with_flush("❌ No valid OAuth token found")
        return None
    
    try:
        service = build('drive', 'v3', credentials=creds)
        log_with_flush("✅ Google Drive service initialized")
        return service
    except Exception as e:
        log_with_flush(f"⚠️ Failed to build Drive service: {e}")
        return None

# Initialize drive service once
_drive_service = None
if CREDENTIALS_FILE.exists() and TOKEN_FILE.exists():
    _drive_service = get_drive_service()

def get_drive():
    """Public function to get the drive service"""
    global _drive_service
    if _drive_service is None:
        _drive_service = get_drive_service()
    return _drive_service