import os
from pathlib import Path

# Package data directory
PACKAGE_DIR = Path(__file__).parent
DATA_DIR = PACKAGE_DIR / "data"

# Google Drive OAuth setup
SCOPES = ['https://www.googleapis.com/auth/drive']
CREDENTIALS_FILE = DATA_DIR / "oauth_credentials.json"
TOKEN_FILE = DATA_DIR / "token.pickle"

# Google Drive Folder IDs (YOUR FIXED FOLDERS)
BASE_INPUT_DIR_ID = "1xM3cxDAh3BZK019hDroKA_sZwG5pYja-"  # ai/user_processing/upload_images
BASE_OUTPUT_DIR_ID = "1DNGeN3t442644d_CNL9-KgteljD2HFtl"  # ai/user_processing/upload_masks

# Ensure data directory exists
DATA_DIR.mkdir(exist_ok=True)