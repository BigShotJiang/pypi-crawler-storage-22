import os
import tempfile
import sys
import time
from pathlib import Path
from googleapiclient.http import MediaFileUpload, MediaIoBaseDownload
from .auth import get_drive, log_with_flush
from .config import BASE_INPUT_DIR_ID, BASE_OUTPUT_DIR_ID

class MinerAIDrive:
    """Main class for Google Drive operations"""
    
    def __init__(self):
        """Initialize the Drive service"""
        self.service = get_drive()
        if self.service is None:
            log_with_flush("⚠️ Google Drive service not available")
    
    def is_available(self):
        """Check if Drive service is available"""
        return self.service is not None
    
    def find_or_create_user_folder(self, user_id, folder_type="input"):
        """
        Find or create user-specific folder in Google Drive
        
        Args:
            user_id: The user's ID
            folder_type: Either "input" or "output"
            
        Returns:
            Folder ID or None if failed
        """
        if self.service is None:
            return None
        
        parent_folder_id = BASE_INPUT_DIR_ID if folder_type == "input" else BASE_OUTPUT_DIR_ID
        folder_name = f"{folder_type} folder"
        
        try:
            # Search for existing folder
            query = f"'{parent_folder_id}' in parents and name='{user_id}' and mimeType='application/vnd.google-apps.folder' and trashed=false"
            results = self.service.files().list(q=query, fields="files(id, name)").execute()
            folders = results.get('files', [])
            
            if folders:
                log_with_flush(f"📁 Found existing {folder_name} for user {user_id}")
                return folders[0]['id']
            else:
                # Create new folder
                folder_metadata = {
                    'name': user_id,
                    'mimeType': 'application/vnd.google-apps.folder',
                    'parents': [parent_folder_id]
                }
                folder = self.service.files().create(body=folder_metadata, fields='id').execute()
                log_with_flush(f"✅ Created new {folder_name} for user {user_id}")
                return folder['id']
        except Exception as e:
            log_with_flush(f"⚠️ Error with {folder_name} for user {user_id}: {e}")
            return None
    
    def clean_user_output_folder(self, user_output_folder_id):
        """
        Delete all existing files in user's output folder before new inference
        
        Args:
            user_output_folder_id: The folder ID to clean
            
        Returns:
            Boolean indicating success
        """
        if self.service is None or user_output_folder_id is None:
            log_with_flush("⚠️ Cannot clean output folder - Drive service not available")
            return False
        
        try:
            # Query for all files in the user's output folder
            query = f"'{user_output_folder_id}' in parents and trashed=false"
            results = self.service.files().list(q=query, fields="files(id, name, mimeType)").execute()
            files = results.get('files', [])
            
            if not files:
                log_with_flush("📭 Output folder is already empty")
                return True
            
            log_with_flush(f"🧹 Cleaning {len(files)} existing files from output folder...")
            
            deleted_count = 0
            for file in files:
                try:
                    self.service.files().delete(fileId=file['id']).execute()
                    log_with_flush(f"🗑️ Deleted: {file['name']}")
                    deleted_count += 1
                except Exception as e:
                    log_with_flush(f"⚠️ Failed to delete {file['name']}: {e}")
            
            log_with_flush(f"✅ Successfully cleaned {deleted_count} files from output folder")
            return True
            
        except Exception as e:
            log_with_flush(f"❌ Error cleaning output folder: {e}")
            return False
    
    def download_user_images(self, user_input_folder_id, local_dir=None):
        """
        Download all images from user's Google Drive input folder
        
        Args:
            user_input_folder_id: The folder ID to download from
            local_dir: Optional local directory (creates temp if None)
            
        Returns:
            List of downloaded file paths
        """
        if self.service is None or user_input_folder_id is None:
            return []
        
        # Create temp directory if none provided
        if local_dir is None:
            local_dir = tempfile.mkdtemp()
        else:
            os.makedirs(local_dir, exist_ok=True)
        
        try:
            # Query for image files
            query = f"'{user_input_folder_id}' in parents and (mimeType contains 'image/' or name contains '.jpg' or name contains '.jpeg' or name contains '.png') and trashed=false"
            results = self.service.files().list(q=query, fields="files(id, name, mimeType)").execute()
            files = results.get('files', [])
            
            downloaded_files = []
            for file in files:
                try:
                    file_id = file['id']
                    filename = file['name']
                    local_path = os.path.join(local_dir, filename)
                    
                    # Download file
                    request = self.service.files().get_media(fileId=file_id)
                    with open(local_path, 'wb') as f:
                        downloader = MediaIoBaseDownload(f, request)
                        done = False
                        while not done:
                            status, done = downloader.next_chunk()
                    
                    downloaded_files.append(local_path)
                    log_with_flush(f"⬇️ Downloaded: {filename}")
                    
                except Exception as e:
                    log_with_flush(f"⚠️ Failed to download {file['name']}: {e}")
            
            return downloaded_files
            
        except Exception as e:
            log_with_flush(f"⚠️ Error downloading user images: {e}")
            return []
    
    def upload_mask(self, mask_image, filename, user_output_folder_id):
        """
        Upload mask image to user's output folder in Google Drive
        
        Args:
            mask_image: PIL Image object
            filename: Name for the uploaded file
            user_output_folder_id: Destination folder ID
            
        Returns:
            Boolean indicating success
        """
        if self.service is None or user_output_folder_id is None:
            return False
        
        try:
            # Save mask to temporary file
            with tempfile.NamedTemporaryFile(suffix='.png', delete=False) as tmp_file:
                mask_path = tmp_file.name
                mask_image.save(mask_path)
            
            # Upload to Google Drive
            file_metadata = {
                'name': filename,
                'parents': [user_output_folder_id]
            }
            media = MediaFileUpload(mask_path, mimetype='image/png', resumable=True)
            file = self.service.files().create(body=file_metadata, media_body=media, fields='id').execute()
            
            # Clean up temp file
            os.unlink(mask_path)
            
            log_with_flush(f"⬆️ Uploaded mask: {filename}")
            return True
            
        except Exception as e:
            log_with_flush(f"⚠️ Failed to upload mask {filename}: {e}")
            return False
    
    def setup_user_folders(self, user_id):
        """
        Convenience method to setup both input and output folders for a user
        
        Args:
            user_id: The user's ID
            
        Returns:
            Tuple of (input_folder_id, output_folder_id) or (None, None) if failed
        """
        input_id = self.find_or_create_user_folder(user_id, "input")
        output_id = self.find_or_create_user_folder(user_id, "output")
        return input_id, output_id

# Create a singleton instance
drive = MinerAIDrive()