import tempfile
import os
from .drive import drive

def get_user_images(user_id):
    """
    Quick function to get all images for a user
    
    Args:
        user_id: The user's ID
        
    Returns:
        Tuple of (temp_dir, image_paths, output_folder_id)
    """
    if not drive.is_available():
        return None, [], None
    
    # Setup folders
    input_id, output_id = drive.setup_user_folders(user_id)
    if not input_id or not output_id:
        return None, [], None
    
    # Clean output folder
    drive.clean_user_output_folder(output_id)
    
    # Download images
    temp_dir = tempfile.mkdtemp()
    images = drive.download_user_images(input_id, temp_dir)
    
    return temp_dir, images, output_id

def cleanup_temp_dir(temp_dir):
    """Clean up temporary directory"""
    import shutil
    if temp_dir and os.path.exists(temp_dir):
        shutil.rmtree(temp_dir)