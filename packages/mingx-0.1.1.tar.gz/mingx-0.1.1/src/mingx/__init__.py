"""
mingx: OpenTelemetry trace Python SDK with GenAI semantic conventions.

- configure_tracer_provider / get_tracer: Tracer setup
- traced: Method-level @traced decorator
- OpenTelemetryCallbackHandler / get_langchain_callback: LangChain/LangGraph callbacks
- span_input / span_output: 手动向 Span 添加输入或输出，支持自定义属性/Event（原生 OTEL 风格）
- genai: GenAI span names and attributes (OTEL compliant)
- 默认属性: mingx.workspace_id, mingx.span_type, mingx.user.id（支持 Baggage 传递）
"""

from mingx._trace import configure_tracer_provider, get_tracer, OTLPProtocol, AuthScheme
from mingx.decorator import traced
from mingx.adapters.langchain import (
    OpenTelemetryCallbackHandler,
    get_langchain_callback,
)
from mingx.genai.io import span_input, span_output
from mingx._default_attributes import (
    MINGX_WORKSPACE_ID,
    MINGX_SPAN_TYPE,
    MINGX_USER_ID,
    SPAN_TYPE_AGENT,
    SPAN_TYPE_CHAIN,
    SPAN_TYPE_CUSTOM,
    SPAN_TYPE_MODEL,
    SPAN_TYPE_RETRIEVER,
    SPAN_TYPE_TOOL,
)

__all__ = [
    "configure_tracer_provider",
    "get_tracer",
    "OTLPProtocol",
    "AuthScheme",
    "traced",
    "OpenTelemetryCallbackHandler",
    "get_langchain_callback",
    "span_input",
    "span_output",
    "MINGX_WORKSPACE_ID",
    "MINGX_SPAN_TYPE",
    "MINGX_USER_ID",
    "SPAN_TYPE_AGENT",
    "SPAN_TYPE_CHAIN",
    "SPAN_TYPE_CUSTOM",
    "SPAN_TYPE_MODEL",
    "SPAN_TYPE_RETRIEVER",
    "SPAN_TYPE_TOOL",
]
