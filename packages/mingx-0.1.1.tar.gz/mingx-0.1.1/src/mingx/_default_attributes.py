"""
默认 Span 属性及 Baggage 支持。

通过 SpanProcessor 为每个 Span 添加 mingx.workspace_id、mingx.user.id（来自配置或 Baggage）；
mingx.span_type 由调用方设置：@traced(span_type=...) 或适配器根据回调类型（model/tool/retriever/chain）自动设置。
"""

from __future__ import annotations

from typing import Any, Dict, Optional

from opentelemetry import context
from opentelemetry.baggage import get_all as get_baggage_all
from opentelemetry.sdk.trace import ReadableSpan, Span, SpanProcessor

# 默认属性键名
MINGX_WORKSPACE_ID = "mingx.workspace_id"
MINGX_SPAN_TYPE = "mingx.span_type"
MINGX_USER_ID = "mingx.user.id"

# span_type 可选值（可扩展，由装饰器或适配器设置）
SPAN_TYPE_MODEL = "model"
SPAN_TYPE_RETRIEVER = "retriever"
SPAN_TYPE_TOOL = "tool"
SPAN_TYPE_CHAIN = "chain"
SPAN_TYPE_AGENT = "agent"
SPAN_TYPE_CUSTOM = "custom"  # 适配器方式下 span_type 为空时的默认值，表示自定义类型


class DefaultAttributesSpanProcessor(SpanProcessor):
    """
    为每个 Span 添加默认属性：workspace_id、user_id 来自配置或 Baggage。
    span_type 不由此处设置，由 @traced(span_type=...) 或适配器按调用类型设置。
    """

    def __init__(
        self,
        workspace_id: Optional[str] = None,
        user_id: Optional[str] = None,
        extra_attributes: Optional[Dict[str, Any]] = None,
        use_baggage: bool = True,
    ) -> None:
        self._defaults: Dict[str, Any] = {}
        if workspace_id is not None:
            self._defaults[MINGX_WORKSPACE_ID] = workspace_id
        if user_id is not None:
            self._defaults[MINGX_USER_ID] = user_id
        if extra_attributes:
            self._defaults.update(extra_attributes)
        self._use_baggage = use_baggage

    def on_start(
        self,
        span: Span,
        parent_context: Optional[context.Context] = None,
    ) -> None:
        attrs: Dict[str, Any] = dict(self._defaults)
        if self._use_baggage and parent_context is not None:
            baggage = get_baggage_all(parent_context)
            if baggage:
                for key in (MINGX_WORKSPACE_ID, MINGX_SPAN_TYPE, MINGX_USER_ID):
                    val = baggage.get(key)
                    if val is not None:
                        attrs[key] = str(val) if not isinstance(val, str) else val
        for k, v in attrs.items():
            if v is not None:
                span.set_attribute(k, v)

    def on_end(self, span: ReadableSpan) -> None:
        pass

    def shutdown(self) -> None:
        pass

    def force_flush(self, timeout_millis: int = 30000) -> bool:
        return True
