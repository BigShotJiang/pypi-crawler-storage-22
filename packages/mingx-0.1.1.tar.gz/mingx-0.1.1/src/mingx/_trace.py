"""
Tracer and TracerProvider configuration for mingx.

Uses the global TracerProvider when set; provides optional one-shot
configure_tracer_provider for applications that do not configure OTel themselves.
"""

from __future__ import annotations

from typing import Any, Dict, Literal, Optional

from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor, SimpleSpanProcessor, SpanExporter
from opentelemetry.trace import Tracer

from mingx._default_attributes import DefaultAttributesSpanProcessor

OTLPProtocol = Literal["grpc", "http"]
AuthScheme = Literal["bearer", "basic"]

# Package version for get_tracer; keep in sync with pyproject.toml or use importlib.metadata
__all__ = ["get_tracer", "configure_tracer_provider", "OTLPProtocol", "AuthScheme"]

_PACKAGE_NAME = "mingx"
_PACKAGE_VERSION = "0.1.0"


def get_tracer(
    name: str = _PACKAGE_NAME,
    version: Optional[str] = None,
) -> Tracer:
    """
    Return a Tracer from the global TracerProvider.

    Uses opentelemetry.trace.get_tracer() so that whatever Provider is
    set globally (by the app or by configure_tracer_provider) is used.
    """
    return trace.get_tracer(name or _PACKAGE_NAME, version or _PACKAGE_VERSION)


def configure_tracer_provider(
    service_name: str,
    otlp_endpoint: Optional[str] = None,
    exporter: Optional[SpanExporter] = None,
    protocol: OTLPProtocol = "grpc",
    api_key: Optional[str] = None,
    auth_scheme: AuthScheme = "bearer",
    workspace_id: Optional[str] = None,
    user_id: Optional[str] = None,
    extra_attributes: Optional[Dict[str, Any]] = None,
    use_baggage: bool = True,
    use_batch_processor: bool = True,
) -> TracerProvider:
    """
    Create and set the global TracerProvider with BatchSpanProcessor and OTLP export.

    Args:
        service_name: Used as service.name in the resource.
        otlp_endpoint: OTLP endpoint URL.
            - For gRPC: e.g. http://localhost:4317 (default port 4317).
            - For HTTP: e.g. http://localhost:4318 (default port 4318).
            If None, uses env OTEL_EXPORTER_OTLP_ENDPOINT.
        exporter: Optional pre-built SpanExporter. If provided, otlp_endpoint,
            protocol and api_key are ignored.
        protocol: "grpc" (OTLP over gRPC, protobuf) or "http" (OTLP over HTTP, protobuf).
            Default "grpc".
        api_key: Optional API key/token for collector auth; sent in Authorization header.
            If value already starts with "Bearer " or "Basic ", used as-is; otherwise
            prefixed according to auth_scheme.
        auth_scheme: "bearer" (default) or "basic". Used only when api_key does not
            already start with Bearer/Basic. Basic 常用于用户名:密码的 base64 编码。
        workspace_id: Default mingx.workspace_id (工作空间) on every span.
        user_id: Default mingx.user.id (用户 id) on every span.
        extra_attributes: Optional dict of extra default attributes on every span.
        use_baggage: If True (default), read mingx.workspace_id, mingx.span_type,
            mingx.user.id from Baggage and overlay on span (Baggage overrides defaults).
            span_type 不在初始化时设置，由 @traced(span_type=...) 或适配器按调用类型设置。
        use_batch_processor: If True (default), use BatchSpanProcessor，span 在 trace 结束或缓冲区满时批量上送；
            If False, use SimpleSpanProcessor，每个 span 结束时立即上送，便于按节点完成顺序在服务端看到顺序。

    Returns:
        The TracerProvider that is now set as global.
    """
    from opentelemetry.sdk.resources import Resource

    resource = Resource.create({"service.name": service_name})
    provider = TracerProvider(resource=resource)

    # Default attributes (and optional Baggage); span_type 由装饰器/适配器设置
    default_processor = DefaultAttributesSpanProcessor(
        workspace_id=workspace_id,
        user_id=user_id,
        extra_attributes=extra_attributes,
        use_baggage=use_baggage,
    )
    provider.add_span_processor(default_processor)

    if exporter is None:
        exporter = _create_otlp_exporter(
            protocol=protocol,
            endpoint=otlp_endpoint,
            api_key=api_key,
            auth_scheme=auth_scheme,
        )

    if use_batch_processor:
        provider.add_span_processor(BatchSpanProcessor(exporter))
    else:
        provider.add_span_processor(SimpleSpanProcessor(exporter))
    trace.set_tracer_provider(provider)
    return provider


def _create_otlp_exporter(
    protocol: OTLPProtocol = "grpc",
    endpoint: Optional[str] = None,
    api_key: Optional[str] = None,
    auth_scheme: AuthScheme = "bearer",
) -> SpanExporter:
    """Create OTLP span exporter by protocol (grpc or http/protobuf)."""
    headers = None
    if api_key:
        token = api_key.strip()
        lower = token.lower()
        if not (lower.startswith("bearer ") or lower.startswith("basic ")):
            if auth_scheme == "basic":
                token = f"Basic {token}"
            else:
                token = f"Bearer {token}"
        headers = [("authorization", token)]

    if protocol == "http":
        from opentelemetry.exporter.otlp.proto.http.trace_exporter import (
            OTLPSpanExporter as OTLPSpanExporterHttp,
        )
        kwargs: Dict[str, Any] = {}
        if endpoint:
            kwargs["endpoint"] = endpoint
        if headers:
            kwargs["headers"] = dict(headers)
        return OTLPSpanExporterHttp(**kwargs)
    # gRPC (default)
    from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import (
        OTLPSpanExporter as OTLPSpanExporterGrpc,
    )
    kwargs = {}
    if endpoint:
        kwargs["endpoint"] = endpoint
        kwargs["insecure"] = True
    if headers:
        kwargs["headers"] = headers
    return OTLPSpanExporterGrpc(**kwargs)
