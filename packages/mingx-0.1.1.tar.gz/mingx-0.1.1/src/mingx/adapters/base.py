"""
Framework trace adapter abstraction.

Adapters translate framework-specific events (e.g. LangChain on_llm_start,
CrewAI task start) into GenAI semantic layer calls (span names, attributes).
New frameworks (CrewAI, Google ADK) implement this protocol and register;
no changes to core or other adapters.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Dict, Optional, Protocol, runtime_checkable


@runtime_checkable
class FrameworkTraceAdapter(Protocol):
    """
    Protocol for framework trace adapters.

    Implementations start/end spans and set GenAI attributes via mingx.genai
    (spans / attributes), not by writing gen_ai.* strings directly.
    """

    def start_span(self, name: str, attributes: Optional[Dict[str, Any]] = None) -> Any:
        """
        Start a span with the given name and attributes.

        Returns a handle (e.g. context token or span) that is passed to end_span.
        """
        ...

    def end_span(self, handle: Any, *, status: Optional[Any] = None) -> None:
        """End the span identified by handle. Optionally set status (e.g. error)."""
        ...

    def set_attributes(self, handle: Any, attributes: Dict[str, Any]) -> None:
        """Set additional attributes on the span (e.g. on_*_end data)."""
        ...

    def record_exception(self, handle: Any, exception: BaseException) -> None:
        """Record an exception on the span and set error status."""
        ...


class BaseFrameworkTraceAdapter(ABC):
    """
    Abstract base for framework adapters.

    Adapters that cannot use a simple Protocol (e.g. need to hold tracer or
    run_id -> span mapping) can subclass this and implement the same contract.
    """

    @abstractmethod
    def start_span(self, name: str, attributes: Optional[Dict[str, Any]] = None) -> Any:
        """Start a span; return handle for end_span / set_attributes."""
        ...

    @abstractmethod
    def end_span(self, handle: Any, *, status: Optional[Any] = None) -> None:
        """End the span."""
        ...

    @abstractmethod
    def set_attributes(self, handle: Any, attributes: Dict[str, Any]) -> None:
        """Set attributes on the span."""
        ...

    @abstractmethod
    def record_exception(self, handle: Any, exception: BaseException) -> None:
        """Record exception on the span."""
        ...


# Optional: registry for "supported frameworks" for docs
SUPPORTED_FRAMEWORKS = ["langchain"]
PLANNED_FRAMEWORKS = ["crewai", "google_adk"]
