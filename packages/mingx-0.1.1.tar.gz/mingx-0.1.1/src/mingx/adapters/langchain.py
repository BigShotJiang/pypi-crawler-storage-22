"""
LangChain & LangGraph OpenTelemetry callback adapter.

Maps on_*_start / on_*_end / on_*_error to GenAI semantic layer spans.
Use with: config={"callbacks": [OpenTelemetryCallbackHandler()]}
"""

from __future__ import annotations

import threading
from typing import Any, Dict, List, Literal, Optional, Tuple
from uuid import UUID

from langchain_core.callbacks.base import BaseCallbackHandler
from langchain_core.outputs import LLMResult
from opentelemetry.trace import SpanKind, Status, StatusCode

from mingx._default_attributes import (
    MINGX_SPAN_TYPE,
    SPAN_TYPE_CUSTOM,
)
from mingx._trace import get_tracer
from mingx.genai import attributes as attrs
from mingx.genai.io import (
    build_input_messages_from_langchain_messages,
    build_input_messages_from_prompts,
    build_output_messages_from_llm_result,
    record_llm_input_output,
    record_span_input_output,
)
from mingx.genai.span_attributes import (
    ChainSpanAttributes,
    InferenceInputOutput,
    InferenceResponseAttributes,
    InferenceSpanAttributes,
    RetrieverSpanAttributes,
    TokenUsage,
    ToolSpanAttributes,
)

def _get_float(d: Dict[str, Any], key: str) -> Optional[float]:
    v = d.get(key)
    if v is None:
        return None
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def _get_int(d: Dict[str, Any], key: str) -> Optional[int]:
    v = d.get(key)
    if v is None:
        return None
    try:
        return int(v)
    except (TypeError, ValueError):
        return None


def _normalize_stop_sequences(stop: Any) -> Optional[List[str]]:
    """将 LangChain stop（str 或 list）转为 gen_ai.request.stop_sequences 的 list[str]。"""
    if stop is None:
        return None
    if isinstance(stop, str):
        return [stop] if stop.strip() else None
    if isinstance(stop, (list, tuple)):
        out = [str(s).strip() for s in stop if s is not None and str(s).strip()]
        return out if out else None
    return None


def _token_usage_from_llm_result(response: LLMResult) -> TokenUsage:
    """从 LangChain LLMResult 解析 token 使用情况。"""
    input_tokens: Optional[int] = None
    output_tokens: Optional[int] = None
    if response.llm_output and len(response.llm_output) > 0:
        out = response.llm_output
        if isinstance(out, dict):
            usage = out.get("token_usage") or out.get("usage") or {}
            input_tokens = _get_int(usage, "input_tokens") or _get_int(usage, "prompt_tokens")
            output_tokens = _get_int(usage, "output_tokens") or _get_int(usage, "completion_tokens")
    return TokenUsage(input_tokens=input_tokens, output_tokens=output_tokens)


def _response_attrs_from_llm_result(response: LLMResult) -> InferenceResponseAttributes:
    """从 LangChain LLMResult 解析响应元数据（response_model、finish_reasons）。"""
    response_model: Optional[str] = None
    finish_reasons: Optional[List[str]] = None
    generations = response.generations
    if generations and len(generations) > 0 and len(generations[0]) > 0:
        gen = generations[0][0]
        if hasattr(gen, "message") and gen.message and hasattr(gen.message, "response_metadata"):
            meta = getattr(gen.message, "response_metadata") or {}
            if isinstance(meta, dict):
                if "model_name" in meta:
                    response_model = str(meta["model_name"])
                if "finish_reason" in meta:
                    finish_reasons = [str(meta["finish_reason"])]
    return InferenceResponseAttributes(
        response_model=response_model,
        finish_reasons=finish_reasons,
    )


# run_id -> (context_manager, optional before_exit callable to run inside context)
_span_contexts: Dict[UUID, Tuple[Any, Optional[Any]]] = {}
# run_id -> 输入数据（trace_content 时用于 on_*_end 记录输入/输出）
_llm_prompts_store: Dict[UUID, List[str]] = {}
_llm_messages_store: Dict[UUID, List[Any]] = {}  # Chat 模型 on_chat_model_start 存的 messages
_chain_io_store: Dict[UUID, Dict[str, Any]] = {}
_tool_io_store: Dict[UUID, str] = {}
_retriever_io_store: Dict[UUID, str] = {}
_lock = threading.Lock()


def _start_span(name: str, kind: SpanKind, attributes: Optional[Dict[str, Any]] = None) -> Any:
    tracer = get_tracer()
    ctx = tracer.start_as_current_span(name, kind=kind, attributes=attributes or {})
    ctx.__enter__()
    return ctx


def _end_span(
    run_id: UUID,
    before_exit: Optional[Any] = None,
) -> bool:
    with _lock:
        entry = _span_contexts.pop(run_id, None)
    if not entry:
        return False
    ctx, _ = entry
    if before_exit is not None:
        try:
            before_exit()
        except Exception:
            pass
    try:
        ctx.__exit__(None, None, None)
    except Exception:
        pass
    return True


def _record_error_span(run_id: UUID, exception: BaseException) -> bool:
    with _lock:
        entry = _span_contexts.pop(run_id, None)
    if not entry:
        return False
    ctx, _ = entry
    try:
        from opentelemetry import trace
        span = trace.get_current_span()
        if span.is_recording():
            span.set_status(Status(StatusCode.ERROR, str(exception)))
            span.record_exception(exception)
            span.set_attribute(attrs.ERROR_TYPE, type(exception).__name__)
    except Exception:
        pass
    try:
        ctx.__exit__(type(exception), exception, exception.__traceback__)
    except Exception:
        pass
    return True


def _store(run_id: UUID, ctx: Any, before_exit: Optional[Any] = None) -> None:
    with _lock:
        _span_contexts[run_id] = (ctx, before_exit)


RecordInputOutputAs = Literal["events", "attributes", "none"]


class OpenTelemetryCallbackHandler(BaseCallbackHandler):
    """
    LangChain/LangGraph callback handler that creates OpenTelemetry spans
    following GenAI semantic conventions.
    """

    trace_content: bool = True  # 默认记录所有节点的入参（输入）与返回值（输出），无返回值记空
    record_input_output_as: RecordInputOutputAs = "events"  # 推荐 events，与 Traceloop 等一致
    max_content_length: Optional[int] = None  # 可选，单条 content 截断长度（字符）
    root_span_name: Optional[str] = None  # 可选，指定根 Span 名称（仅对无 parent_run_id 的 chain 生效）

    def __init__(
        self,
        *,
        trace_content: bool = True,
        record_input_output_as: RecordInputOutputAs = "events",
        max_content_length: Optional[int] = None,
        root_span_name: Optional[str] = None,
    ) -> None:
        super().__init__()
        self.trace_content = trace_content
        self.record_input_output_as = record_input_output_as
        self.max_content_length = max_content_length
        self.root_span_name = root_span_name

    def _start_span(
        self,
        name: str,
        kind: SpanKind,
        attributes: Optional[Dict[str, Any]] = None,
        run_id: Optional[UUID] = None,
    ) -> None:
        if not run_id:
            return
        attrs = dict(attributes or {})
        # 适配器方式下 span_type 为空时默认使用 custom 表示自定义类型
        if not (attrs.get(MINGX_SPAN_TYPE) or "").strip():
            attrs[MINGX_SPAN_TYPE] = SPAN_TYPE_CUSTOM
        ctx = _start_span(name, kind, attrs)
        _store(run_id, ctx, None)

    def on_llm_start(
        self,
        serialized: Dict[str, Any],
        prompts: List[str],
        *,
        run_id: UUID,
        **kwargs: Any,
    ) -> None:
        serialized = serialized or {}
        lc_kwargs = serialized.get("kwargs") or {}
        model = lc_kwargs.get("model_name") or (serialized.get("id", [])[-1] if serialized.get("id") else "llm")
        provider = self._infer_provider(serialized)
        model_str = str(model) if model else "unknown"
        # span 名称：仅用 name 或模型 id，不拼接
        name = serialized.get("name") or kwargs.get("name") or model_str
        if not isinstance(name, str):
            name = str(name)
        # 从 LangChain LLM kwargs 提取 gen_ai.request.* 参数（与语义规范一致）
        temperature = _get_float(lc_kwargs, "temperature")
        max_tokens = _get_int(lc_kwargs, "max_tokens") or _get_int(lc_kwargs, "max_tokens_limit")
        top_p = _get_float(lc_kwargs, "top_p")
        top_k = _get_int(lc_kwargs, "top_k")
        frequency_penalty = _get_float(lc_kwargs, "frequency_penalty")
        presence_penalty = _get_float(lc_kwargs, "presence_penalty")
        model_kwargs = lc_kwargs.get("model_kwargs") or {}
        if top_p is None:
            top_p = _get_float(model_kwargs, "top_p")
        if top_k is None:
            top_k = _get_int(model_kwargs, "top_k")
        if frequency_penalty is None:
            frequency_penalty = _get_float(model_kwargs, "frequency_penalty")
        if presence_penalty is None:
            presence_penalty = _get_float(model_kwargs, "presence_penalty")
        stop_raw = lc_kwargs.get("stop") or model_kwargs.get("stop")
        stop_sequences = _normalize_stop_sequences(stop_raw)
        span_attrs = InferenceSpanAttributes(
            operation_name=attrs.OPERATION_CHAT,
            provider_name=provider,
            run_id=str(run_id),
            model=model_str,
            temperature=temperature,
            max_tokens=max_tokens,
            top_p=top_p,
            top_k=top_k,
            frequency_penalty=frequency_penalty,
            presence_penalty=presence_penalty,
            stop_sequences=stop_sequences,
        )
        self._start_span(name, SpanKind.CLIENT, span_attrs.to_attributes(), run_id)
        if self.trace_content and prompts:
            with _lock:
                _llm_prompts_store[run_id] = list(prompts)

    def on_chat_model_start(
        self,
        serialized: Dict[str, Any],
        messages: List[List[Any]],
        *,
        run_id: UUID,
        **kwargs: Any,
    ) -> None:
        """Chat 模型入口：收到真实 Message 列表，存起来供 on_llm_end 生成 JSON 输入/输出事件。"""
        serialized = serialized or {}
        lc_kwargs = serialized.get("kwargs") or {}
        model = lc_kwargs.get("model_name") or (serialized.get("id", [])[-1] if serialized.get("id") else "llm")
        provider = self._infer_provider(serialized)
        model_str = str(model) if model else "unknown"
        name = serialized.get("name") or kwargs.get("name") or model_str
        if not isinstance(name, str):
            name = str(name)
        temperature = _get_float(lc_kwargs, "temperature")
        max_tokens = _get_int(lc_kwargs, "max_tokens") or _get_int(lc_kwargs, "max_tokens_limit")
        top_p = _get_float(lc_kwargs, "top_p")
        top_k = _get_int(lc_kwargs, "top_k")
        frequency_penalty = _get_float(lc_kwargs, "frequency_penalty")
        presence_penalty = _get_float(lc_kwargs, "presence_penalty")
        model_kwargs = lc_kwargs.get("model_kwargs") or {}
        if top_p is None:
            top_p = _get_float(model_kwargs, "top_p")
        if top_k is None:
            top_k = _get_int(model_kwargs, "top_k")
        if frequency_penalty is None:
            frequency_penalty = _get_float(model_kwargs, "frequency_penalty")
        if presence_penalty is None:
            presence_penalty = _get_float(model_kwargs, "presence_penalty")
        stop_raw = lc_kwargs.get("stop") or model_kwargs.get("stop")
        stop_sequences = _normalize_stop_sequences(stop_raw)
        span_attrs = InferenceSpanAttributes(
            operation_name=attrs.OPERATION_CHAT,
            provider_name=provider,
            run_id=str(run_id),
            model=model_str,
            temperature=temperature,
            max_tokens=max_tokens,
            top_p=top_p,
            top_k=top_k,
            frequency_penalty=frequency_penalty,
            presence_penalty=presence_penalty,
            stop_sequences=stop_sequences,
        )
        self._start_span(name, SpanKind.CLIENT, span_attrs.to_attributes(), run_id)
        if self.trace_content and messages:
            with _lock:
                # LangChain 可能传 list[list[BaseMessage]]（batch）或 list[BaseMessage]；统一取第一批
                first_batch = messages[0] if messages else []
                if isinstance(first_batch, (list, tuple)):
                    _llm_messages_store[run_id] = list(first_batch)
                else:
                    _llm_messages_store[run_id] = list(messages)

    def _infer_provider(self, serialized: Dict[str, Any]) -> str:
        serialized = serialized or {}
        id_list = serialized.get("id") or []
        if isinstance(id_list, list):
            last = id_list[-1] if id_list else ""
            if "openai" in str(last).lower():
                return attrs.PROVIDER_OPENAI
            if "anthropic" in str(last).lower():
                return attrs.PROVIDER_ANTHROPIC
            if "vertex" in str(last).lower() or "gemini" in str(last).lower():
                return attrs.PROVIDER_GCP_VERTEX_AI
            if "bedrock" in str(last).lower():
                return attrs.PROVIDER_AWS_BEDROCK
        return "langchain"

    def on_llm_end(self, response: LLMResult, *, run_id: UUID, **kwargs: Any) -> None:
        usage = _token_usage_from_llm_result(response)
        response_attrs = _response_attrs_from_llm_result(response)

        def set_llm_response_attrs():
            from opentelemetry import trace
            span = trace.get_current_span()
            if not span.is_recording():
                return
            span.set_status(Status(StatusCode.OK))
            try:
                usage.apply_to_span(span)
                response_attrs.apply_to_span(span)
                if self.trace_content and self.record_input_output_as != "none":
                    with _lock:
                        stored_messages = _llm_messages_store.pop(run_id, None)
                        prompts = _llm_prompts_store.pop(run_id, None) if stored_messages is None else None
                    output_messages = build_output_messages_from_llm_result(response)
                    if stored_messages is not None:
                        input_messages = build_input_messages_from_langchain_messages(
                            stored_messages, max_length=self.max_content_length
                        )
                    elif prompts is not None:
                        input_messages = build_input_messages_from_prompts(prompts)
                    else:
                        input_messages = []
                    iio = InferenceInputOutput(
                        input_messages=input_messages,
                        output_messages=output_messages,
                    )
                    record_llm_input_output(
                        span,
                        iio.input_messages,
                        iio.output_messages,
                        record_as=self.record_input_output_as,
                        max_length=self.max_content_length,
                    )
            except Exception:
                pass

        _end_span(run_id, before_exit=set_llm_response_attrs)

    def on_llm_error(self, error: BaseException, *, run_id: UUID, **kwargs: Any) -> None:
        stored_messages = None
        prompts = None
        with _lock:
            stored_messages = _llm_messages_store.pop(run_id, None)
            if stored_messages is None:
                prompts = _llm_prompts_store.pop(run_id, None)
        if (stored_messages is not None or prompts is not None) and self.trace_content and self.record_input_output_as != "none":
            try:
                from opentelemetry import trace
                span = trace.get_current_span()
                if span.is_recording():
                    if stored_messages is not None:
                        input_messages = build_input_messages_from_langchain_messages(
                            stored_messages, max_length=self.max_content_length
                        )
                    else:
                        input_messages = build_input_messages_from_prompts(prompts or [])
                    record_llm_input_output(
                        span,
                        input_messages,
                        [{"role": "assistant", "content": f"[Error] {type(error).__name__}: {error!s}"}],
                        record_as=self.record_input_output_as,
                        max_length=self.max_content_length,
                    )
            except Exception:
                pass
        _record_error_span(run_id, error)

    def on_chain_start(
        self,
        serialized: Dict[str, Any],
        inputs: Dict[str, Any],
        *,
        run_id: UUID,
        **kwargs: Any,
    ) -> None:
        serialized = serialized or {}
        # 实测：部分 runnable（RunnableSequence、RunnableLambda、StrOutputParser）serialized 为 None，
        # 名称在 kwargs["name"]；有 serialized 时用 id[-1] 或 serialized["name"]
        name = "chain"
        if serialized:
            id_list = serialized.get("id")
            if isinstance(id_list, list) and len(id_list) > 0:
                name = id_list[-1]
            elif serialized.get("name"):
                name = serialized.get("name")
        if name == "chain" and kwargs:
            kw_name = kwargs.get("name")
            if kw_name is not None and str(kw_name).strip():
                name = kw_name
        # Root span 名称：无 parent_run_id 视为根 run 时，使用创建 handler 时指定的 root_span_name
        parent_run_id = kwargs.get("parent_run_id")
        if parent_run_id is None and self.root_span_name and str(self.root_span_name).strip():
            name = str(self.root_span_name).strip()
        if not isinstance(name, str):
            name = str(name)
        span_attrs = ChainSpanAttributes(run_id=str(run_id))
        self._start_span(name, SpanKind.INTERNAL, span_attrs.to_attributes(), run_id)
        if self.trace_content and inputs is not None:
            with _lock:
                try:
                    _chain_io_store[run_id] = dict(inputs) if isinstance(inputs, dict) else {"inputs": inputs}
                except (TypeError, ValueError):
                    _chain_io_store[run_id] = {"inputs": inputs}

    def on_chain_end(self, outputs: Dict[str, Any], *, run_id: UUID, **kwargs: Any) -> None:
        def set_chain_io():
            from opentelemetry import trace
            span = trace.get_current_span()
            if not span.is_recording():
                return
            span.set_status(Status(StatusCode.OK))
            if not self.trace_content or self.record_input_output_as == "none":
                return
            try:
                with _lock:
                    stored_inputs = _chain_io_store.pop(run_id, None)
                if stored_inputs is not None:
                    record_span_input_output(
                        span,
                        stored_inputs,
                        outputs if outputs is not None else {},
                        record_as=self.record_input_output_as,
                        max_length=self.max_content_length,
                    )
            except Exception:
                pass

        _end_span(run_id, before_exit=set_chain_io)

    def on_chain_error(self, error: BaseException, *, run_id: UUID, **kwargs: Any) -> None:
        stored_inputs = None
        with _lock:
            stored_inputs = _chain_io_store.pop(run_id, None)
        if stored_inputs is not None and self.trace_content and self.record_input_output_as != "none":
            try:
                from opentelemetry import trace
                span = trace.get_current_span()
                if span.is_recording():
                    record_span_input_output(
                        span,
                        stored_inputs,
                        {"error": str(error), "error_type": type(error).__name__},
                        record_as=self.record_input_output_as,
                        max_length=self.max_content_length,
                    )
            except Exception:
                pass
        _record_error_span(run_id, error)

    def on_tool_start(
        self,
        serialized: Dict[str, Any],
        input_str: str,
        *,
        run_id: UUID,
        **kwargs: Any,
    ) -> None:
        serialized = serialized or {}
        # span 名称：仅用 name（或 id 最后一节）
        name = serialized.get("name") or (serialized.get("id", [])[-1] if serialized.get("id") else "tool")
        if not isinstance(name, str):
            name = str(name)
        span_attrs = ToolSpanAttributes(tool_name=name, run_id=str(run_id))
        self._start_span(name, SpanKind.INTERNAL, span_attrs.to_attributes(), run_id)
        if self.trace_content:
            with _lock:
                _tool_io_store[run_id] = input_str

    def on_tool_end(self, output: Any, *, run_id: UUID, **kwargs: Any) -> None:
        def set_tool_io():
            from opentelemetry import trace
            span = trace.get_current_span()
            if not span.is_recording():
                return
            span.set_status(Status(StatusCode.OK))
            if not self.trace_content or self.record_input_output_as == "none":
                return
            try:
                with _lock:
                    stored_input = _tool_io_store.pop(run_id, None)
                if stored_input is not None:
                    record_span_input_output(
                        span,
                        {"input": stored_input},
                        {"output": output} if output is not None else {},
                        record_as=self.record_input_output_as,
                        max_length=self.max_content_length,
                    )
            except Exception:
                pass

        _end_span(run_id, before_exit=set_tool_io)

    def on_tool_error(self, error: BaseException, *, run_id: UUID, **kwargs: Any) -> None:
        stored_input = None
        with _lock:
            stored_input = _tool_io_store.pop(run_id, None)
        if stored_input is not None and self.trace_content and self.record_input_output_as != "none":
            try:
                from opentelemetry import trace
                span = trace.get_current_span()
                if span.is_recording():
                    record_span_input_output(
                        span,
                        {"input": stored_input},
                        {"error": str(error), "error_type": type(error).__name__},
                        record_as=self.record_input_output_as,
                        max_length=self.max_content_length,
                    )
            except Exception:
                pass
        _record_error_span(run_id, error)

    def on_retriever_start(
        self,
        serialized: Dict[str, Any],
        query: str,
        *,
        run_id: UUID,
        **kwargs: Any,
    ) -> None:
        serialized = serialized or {}
        # span 名称：仅用 name（或 id 最后一节）
        name = serialized.get("name") or (serialized.get("id", [])[-1] if serialized.get("id") else None) or kwargs.get("name") or "retriever"
        if not isinstance(name, str):
            name = str(name)
        span_attrs = RetrieverSpanAttributes(run_id=str(run_id))
        self._start_span(name, SpanKind.INTERNAL, span_attrs.to_attributes(), run_id)
        if self.trace_content:
            with _lock:
                _retriever_io_store[run_id] = query

    def on_retriever_end(self, documents: Any, *, run_id: UUID, **kwargs: Any) -> None:
        def set_retriever_io():
            from opentelemetry import trace
            span = trace.get_current_span()
            if not span.is_recording():
                return
            span.set_status(Status(StatusCode.OK))
            if not self.trace_content or self.record_input_output_as == "none":
                return
            try:
                with _lock:
                    stored_query = _retriever_io_store.pop(run_id, None)
                if stored_query is not None:
                    docs_ser = _documents_to_serializable(documents)
                    record_span_input_output(
                        span,
                        {"query": stored_query},
                        {"documents": docs_ser},
                        record_as=self.record_input_output_as,
                        max_length=self.max_content_length,
                    )
            except Exception:
                pass

        _end_span(run_id, before_exit=set_retriever_io)

    def on_retriever_error(self, error: BaseException, *, run_id: UUID, **kwargs: Any) -> None:
        stored_query = None
        with _lock:
            stored_query = _retriever_io_store.pop(run_id, None)
        if stored_query is not None and self.trace_content and self.record_input_output_as != "none":
            try:
                from opentelemetry import trace
                span = trace.get_current_span()
                if span.is_recording():
                    record_span_input_output(
                        span,
                        {"query": stored_query},
                        {"error": str(error), "error_type": type(error).__name__},
                        record_as=self.record_input_output_as,
                        max_length=self.max_content_length,
                    )
            except Exception:
                pass
        _record_error_span(run_id, error)


def _documents_to_serializable(documents: Any) -> List[Dict[str, Any]]:
    """将 LangChain Document 列表转为可 JSON 序列化的 list of dict。"""
    if documents is None:
        return []
    out: List[Dict[str, Any]] = []
    try:
        for d in documents:
            if hasattr(d, "page_content") and hasattr(d, "metadata"):
                out.append({
                    "page_content": getattr(d, "page_content", "") or "",
                    "metadata": dict(getattr(d, "metadata", None) or {}),
                })
            else:
                out.append({"raw": str(d)})
    except Exception:
        out = [{"raw": str(documents)}]
    return out


def get_langchain_callback(
    trace_content: bool = True,
    record_input_output_as: RecordInputOutputAs = "events",
    max_content_length: Optional[int] = None,
    root_span_name: Optional[str] = None,
) -> OpenTelemetryCallbackHandler:
    """Return a default OpenTelemetryCallbackHandler for LangChain/LangGraph. 默认记录所有节点入参与返回值。"""
    return OpenTelemetryCallbackHandler(
        trace_content=trace_content,
        record_input_output_as=record_input_output_as,
        max_content_length=max_content_length,
        root_span_name=root_span_name,
    )
