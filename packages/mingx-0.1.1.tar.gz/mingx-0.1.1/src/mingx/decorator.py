"""
Method-level automatic tracing via @traced decorator.

Supports sync and async; uses mingx._trace.get_tracer() for consistency
with global TracerProvider. 默认记录函数入参（输入）与返回值（输出）到当前 Span。
"""

from __future__ import annotations

import functools
import inspect
from typing import Any, Callable, Dict, List, Optional, TypeVar

from opentelemetry.trace import Status, StatusCode

from mingx._default_attributes import MINGX_SPAN_TYPE
from mingx._trace import get_tracer
from mingx.genai.io import record_span_input, record_span_output

F = TypeVar("F", bound=Callable[..., Any])


def traced(
    func: Optional[F] = None,
    *,
    name: Optional[str] = None,
    span_type: Optional[str] = None,
    attributes: Optional[Dict[str, Any]] = None,
    record_io: bool = True,
    record_io_as: str = "events",
    max_content_length: Optional[int] = None,
) -> Any:
    """
    Decorator that creates an OpenTelemetry span for each call.

    Usage:
        @traced
        def my_func(): ...

        @traced(name="custom_span", span_type="model", attributes={"key": "value"})
        def other(): ...

        # 指定 root span 名称：入口函数用 name= 即可，该 span 即为 trace 的 root
        @traced(name="my_agent")
        def entry():
            ...

    name: Span 名称；不传时使用「模块.函数名」或「函数名」。作为入口调用时，该 name 即为 root span name。
    span_type: 设置 mingx.span_type，如 "model", "retriever", "tool", "chain", "agent" 等（可扩展）。
    record_io: 是否记录函数入参（输入）与返回值（输出），默认 True，与适配器行为一致。
    record_io_as: "events"（默认）| "attributes" | "none"。
    max_content_length: 可选，单条 content 截断长度。
    Supports sync and async; on exception sets span status to ERROR and
    record_exception, then re-raises.
    """
    attrs = dict(attributes or {})
    if span_type is not None:
        attrs[MINGX_SPAN_TYPE] = span_type

    def decorator(f: F) -> F:
        span_name = name or _default_span_name(f)

        if inspect.iscoroutinefunction(f):
            return _wrap_async(f, span_name, attrs, record_io, record_io_as, max_content_length)  # type: ignore[return-value]
        return _wrap_sync(f, span_name, attrs, record_io, record_io_as, max_content_length)  # type: ignore[return-value]

    if func is not None:
        return decorator(func)
    return decorator


def _default_span_name(func: Callable[..., Any]) -> str:
    """Default span name: module.funcname or funcname."""
    module = getattr(func, "__module__", "") or ""
    qualname = getattr(func, "__qualname__", func.__name__)
    if module:
        return f"{module}.{qualname}"
    return qualname


def _args_to_input(args: tuple, kwargs: Dict[str, Any]) -> Dict[str, Any]:
    """将 *args, **kwargs 转为可序列化的 input 结构（与适配器“入参作为输入”一致）。"""
    return {"args": list(args), "kwargs": dict(kwargs)}


def _wrap_sync(
    func: F,
    span_name: str,
    attrs: Dict[str, Any],
    record_io: bool,
    record_io_as: str,
    max_content_length: Optional[int],
) -> F:
    @functools.wraps(func)
    def _inner(*args: Any, **kwargs: Any) -> Any:
        tracer = get_tracer()
        with tracer.start_as_current_span(span_name, attributes=attrs) as span:
            if record_io and record_io_as != "none":
                try:
                    record_span_input(
                        span,
                        _args_to_input(args, kwargs),
                        record_as=record_io_as,
                        max_length=max_content_length,
                    )
                except Exception:
                    pass
            try:
                result = func(*args, **kwargs)
                if record_io and record_io_as != "none":
                    try:
                        record_span_output(
                            span,
                            result,
                            record_as=record_io_as,
                            max_length=max_content_length,
                        )
                    except Exception:
                        pass
                span.set_status(Status(StatusCode.OK))
                return result
            except Exception as e:
                if record_io and record_io_as != "none":
                    try:
                        record_span_output(
                            span,
                            {"error": str(e), "error_type": type(e).__name__},
                            record_as=record_io_as,
                            max_length=max_content_length,
                        )
                    except Exception:
                        pass
                span.set_status(Status(StatusCode.ERROR, str(e)))
                span.record_exception(e)
                raise

    return _inner  # type: ignore[return-value]


def _wrap_async(
    func: F,
    span_name: str,
    attrs: Dict[str, Any],
    record_io: bool,
    record_io_as: str,
    max_content_length: Optional[int],
) -> F:
    @functools.wraps(func)
    async def _inner(*args: Any, **kwargs: Any) -> Any:
        tracer = get_tracer()
        with tracer.start_as_current_span(span_name, attributes=attrs) as span:
            if record_io and record_io_as != "none":
                try:
                    record_span_input(
                        span,
                        _args_to_input(args, kwargs),
                        record_as=record_io_as,
                        max_length=max_content_length,
                    )
                except Exception:
                    pass
            try:
                result = await func(*args, **kwargs)
                if record_io and record_io_as != "none":
                    try:
                        record_span_output(
                            span,
                            result,
                            record_as=record_io_as,
                            max_length=max_content_length,
                        )
                    except Exception:
                        pass
                span.set_status(Status(StatusCode.OK))
                return result
            except Exception as e:
                if record_io and record_io_as != "none":
                    try:
                        record_span_output(
                            span,
                            {"error": str(e), "error_type": type(e).__name__},
                            record_as=record_io_as,
                            max_length=max_content_length,
                        )
                    except Exception:
                        pass
                span.set_status(Status(StatusCode.ERROR, str(e)))
                span.record_exception(e)
                raise

    return _inner  # type: ignore[return-value]
