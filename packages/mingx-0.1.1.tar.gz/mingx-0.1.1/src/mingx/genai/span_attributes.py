"""
各类型 Span 上送属性的数据模型。

将 LLM/Chain/Tool/Retriever 等不同语义的 Span 属性拆成独立模型，
通过 to_attributes() 统一输出为 OpenTelemetry 所需的 Dict[str, Any]，保证设计清晰、易扩展。
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from mingx._default_attributes import (
    MINGX_SPAN_TYPE,
    SPAN_TYPE_CHAIN,
    SPAN_TYPE_MODEL,
    SPAN_TYPE_RETRIEVER,
    SPAN_TYPE_TOOL,
)

from . import attributes as genai_attrs

# 适配器层常用键（如 LangChain run_id）
LC_RUN_ID = "lc.run_id"


@dataclass(frozen=True)
class InferenceSpanAttributes:
    """推理/LLM Span 上送属性（gen_ai.request.* 等）。"""

    operation_name: str
    provider_name: str
    run_id: str
    span_type: str = SPAN_TYPE_MODEL
    model: Optional[str] = None
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None
    top_p: Optional[float] = None
    top_k: Optional[int] = None
    frequency_penalty: Optional[float] = None
    presence_penalty: Optional[float] = None
    stop_sequences: Optional[List[str]] = None

    def to_attributes(self) -> Dict[str, Any]:
        d = genai_attrs.inference_attributes(
            self.operation_name,
            self.provider_name,
            model=self.model,
            temperature=self.temperature,
            max_tokens=self.max_tokens,
            top_p=self.top_p,
            top_k=self.top_k,
            frequency_penalty=self.frequency_penalty,
            presence_penalty=self.presence_penalty,
            stop_sequences=self.stop_sequences,
        )
        d[LC_RUN_ID] = self.run_id
        d[MINGX_SPAN_TYPE] = self.span_type
        return d


@dataclass(frozen=True)
class ChainSpanAttributes:
    """Chain Span 上送属性。"""

    run_id: str
    operation_name: str = genai_attrs.OPERATION_INVOKE_AGENT
    span_type: str = SPAN_TYPE_CHAIN
    extra: Dict[str, Any] = field(default_factory=dict)

    def to_attributes(self) -> Dict[str, Any]:
        d: Dict[str, Any] = {
            LC_RUN_ID: self.run_id,
            genai_attrs.GEN_AI_OPERATION_NAME: self.operation_name,
            MINGX_SPAN_TYPE: self.span_type,
        }
        d.update(self.extra)
        return d


@dataclass(frozen=True)
class ToolSpanAttributes:
    """Execute Tool Span 上送属性。"""

    tool_name: str
    run_id: str
    span_type: str = SPAN_TYPE_TOOL
    tool_description: Optional[str] = None
    tool_call_id: Optional[str] = None
    tool_type: Optional[str] = None
    extra: Dict[str, Any] = field(default_factory=dict)

    def to_attributes(self) -> Dict[str, Any]:
        d = genai_attrs.execute_tool_attributes(
            self.tool_name,
            tool_description=self.tool_description,
            tool_call_id=self.tool_call_id,
            tool_type=self.tool_type,
        )
        d[LC_RUN_ID] = self.run_id
        d[MINGX_SPAN_TYPE] = self.span_type
        d.update(self.extra)
        return d


@dataclass(frozen=True)
class RetrieverSpanAttributes:
    """Retriever Span 上送属性。"""

    run_id: str
    operation_name: str = "retriever"
    span_type: str = SPAN_TYPE_RETRIEVER
    extra: Dict[str, Any] = field(default_factory=dict)

    def to_attributes(self) -> Dict[str, Any]:
        d: Dict[str, Any] = {
            LC_RUN_ID: self.run_id,
            genai_attrs.GEN_AI_OPERATION_NAME: self.operation_name,
            MINGX_SPAN_TYPE: self.span_type,
        }
        d.update(self.extra)
        return d


# ---------------------------------------------------------------------------
# 大模型调用结束时的上送数据：Token 使用、响应元数据、输入/输出消息
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class TokenUsage:
    """Token 使用情况（gen_ai.usage.*），用于推理/Embeddings 等 Span 结束时的属性。"""

    input_tokens: Optional[int] = None
    output_tokens: Optional[int] = None

    def apply_to_span(self, span: Any) -> None:
        """将 usage 写入当前 Span 的 gen_ai.usage.* 属性。"""
        if not getattr(span, "is_recording", lambda: False)():
            return
        if self.input_tokens is not None:
            span.set_attribute(genai_attrs.GEN_AI_USAGE_INPUT_TOKENS, self.input_tokens)
        if self.output_tokens is not None:
            span.set_attribute(genai_attrs.GEN_AI_USAGE_OUTPUT_TOKENS, self.output_tokens)


@dataclass(frozen=True)
class InferenceResponseAttributes:
    """大模型调用响应元数据（gen_ai.response.*），在 Span 结束时上送。"""

    response_model: Optional[str] = None
    finish_reasons: Optional[List[str]] = None
    response_id: Optional[str] = None

    def apply_to_span(self, span: Any) -> None:
        """将响应元数据写入当前 Span 的 gen_ai.response.* 属性。"""
        if not getattr(span, "is_recording", lambda: False)():
            return
        if self.response_model is not None:
            span.set_attribute(genai_attrs.GEN_AI_RESPONSE_MODEL, self.response_model)
        if self.finish_reasons is not None:
            span.set_attribute(genai_attrs.GEN_AI_RESPONSE_FINISH_REASONS, self.finish_reasons)
        if self.response_id is not None:
            span.set_attribute(genai_attrs.GEN_AI_RESPONSE_ID, self.response_id)


@dataclass(frozen=True)
class InferenceInputOutput:
    """大模型调用的输入/输出消息体，用于 Span 的 Event 或属性记录（由 io.record_llm_input_output 写入）。"""

    input_messages: List[Dict[str, Any]] = field(default_factory=list)
    output_messages: List[Dict[str, Any]] = field(default_factory=list)
