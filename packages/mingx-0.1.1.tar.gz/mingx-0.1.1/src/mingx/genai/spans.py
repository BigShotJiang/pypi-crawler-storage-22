"""
OpenTelemetry GenAI span factories and context managers.

Creates spans that follow GenAI semantic conventions (span names, attributes, SpanKind).
Uses mingx._trace.get_tracer() for consistency with global TracerProvider.
"""

from __future__ import annotations

from contextlib import contextmanager
from typing import Any, Dict, Iterator, Optional

from opentelemetry.trace import SpanKind, Status, StatusCode

from mingx._trace import get_tracer

from . import attributes as attrs


@contextmanager
def inference_span(
    operation_name: str,
    provider_name: str,
    *,
    model: Optional[str] = None,
    temperature: Optional[float] = None,
    max_tokens: Optional[int] = None,
    **extra_attributes: Any,
) -> Iterator[Any]:
    """
    Context manager for an inference (chat/completion) span.

    Span name: {operation_name} {model}. SpanKind CLIENT.
    """
    tracer = get_tracer()
    name = attrs.inference_span_name(operation_name, model)
    base = attrs.inference_attributes(
        operation_name,
        provider_name,
        model=model,
        temperature=temperature,
        max_tokens=max_tokens,
    )
    base.update(extra_attributes)
    with tracer.start_as_current_span(name, kind=SpanKind.CLIENT, attributes=base) as span:
        try:
            yield span
        except Exception as e:
            span.set_status(Status(StatusCode.ERROR, str(e)))
            span.record_exception(e)
            span.set_attribute(attrs.ERROR_TYPE, type(e).__name__)
            raise


@contextmanager
def embeddings_span(
    provider_name: str,
    *,
    model: Optional[str] = None,
    **extra_attributes: Any,
) -> Iterator[Any]:
    """Context manager for an embeddings span. SpanKind CLIENT."""
    tracer = get_tracer()
    name = attrs.embeddings_span_name(model)
    base = attrs.embeddings_attributes(provider_name, model=model)
    base.update(extra_attributes)
    with tracer.start_as_current_span(name, kind=SpanKind.CLIENT, attributes=base) as span:
        try:
            yield span
        except Exception as e:
            span.set_status(Status(StatusCode.ERROR, str(e)))
            span.record_exception(e)
            span.set_attribute(attrs.ERROR_TYPE, type(e).__name__)
            raise


@contextmanager
def execute_tool_span(
    tool_name: str,
    *,
    tool_description: Optional[str] = None,
    tool_call_id: Optional[str] = None,
    tool_type: Optional[str] = None,
    **extra_attributes: Any,
) -> Iterator[Any]:
    """
    Context manager for an execute_tool span.

    Span name: execute_tool {tool_name}. SpanKind INTERNAL.
    """
    tracer = get_tracer()
    name = attrs.execute_tool_span_name(tool_name)
    base = attrs.execute_tool_attributes(
        tool_name,
        tool_description=tool_description,
        tool_call_id=tool_call_id,
        tool_type=tool_type,
    )
    base.update(extra_attributes)
    with tracer.start_as_current_span(name, kind=SpanKind.INTERNAL, attributes=base) as span:
        try:
            yield span
        except Exception as e:
            span.set_status(Status(StatusCode.ERROR, str(e)))
            span.record_exception(e)
            span.set_attribute(attrs.ERROR_TYPE, type(e).__name__)
            raise


def build_inference_span_args(
    operation_name: str,
    provider_name: str,
    *,
    model: Optional[str] = None,
    temperature: Optional[float] = None,
    max_tokens: Optional[int] = None,
    top_p: Optional[float] = None,
    top_k: Optional[int] = None,
    frequency_penalty: Optional[float] = None,
    presence_penalty: Optional[float] = None,
    stop_sequences: Optional[list[str]] = None,
    **extra: Any,
) -> tuple[str, Dict[str, Any]]:
    """
    Return (span_name, attributes) for an inference span.
    Adapters can call tracer.start_as_current_span(name, attributes=attrs) with this.
    """
    name = attrs.inference_span_name(operation_name, model)
    base = attrs.inference_attributes(
        operation_name,
        provider_name,
        model=model,
        temperature=temperature,
        max_tokens=max_tokens,
        top_p=top_p,
        top_k=top_k,
        frequency_penalty=frequency_penalty,
        presence_penalty=presence_penalty,
        stop_sequences=stop_sequences,
    )
    base.update(extra)
    return name, base


def build_execute_tool_span_args(
    tool_name: str,
    *,
    tool_description: Optional[str] = None,
    tool_call_id: Optional[str] = None,
    tool_type: Optional[str] = None,
    **extra: Any,
) -> tuple[str, Dict[str, Any]]:
    """Return (span_name, attributes) for an execute_tool span."""
    name = attrs.execute_tool_span_name(tool_name)
    base = attrs.execute_tool_attributes(
        tool_name,
        tool_description=tool_description,
        tool_call_id=tool_call_id,
        tool_type=tool_type,
    )
    base.update(extra)
    return name, base


def build_embeddings_span_args(
    provider_name: str,
    *,
    model: Optional[str] = None,
    **extra: Any,
) -> tuple[str, Dict[str, Any]]:
    """Return (span_name, attributes) for an embeddings span."""
    name = attrs.embeddings_span_name(model)
    base = attrs.embeddings_attributes(provider_name, model=model)
    base.update(extra)
    return name, base
