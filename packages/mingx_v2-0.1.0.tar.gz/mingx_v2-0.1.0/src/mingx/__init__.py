"""Mingx tracing SDK - OpenTelemetry-based tracing for any OTLP backend."""

from mingx._client import (
    MingxClient,
    MingxEvent,
    MingxGeneration,
    MingxSpan,
    get_client,
    observe,
)
from mingx.version import __version__

# Alias for Langfuse-style usage
Mingx = MingxClient

__all__ = [
    "Mingx",
    "MingxClient",
    "get_client",
    "observe",
    "MingxSpan",
    "MingxGeneration",
    "MingxEvent",
    "__version__",
]
