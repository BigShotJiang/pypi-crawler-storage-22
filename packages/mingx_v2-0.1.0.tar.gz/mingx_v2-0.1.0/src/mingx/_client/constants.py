"""Constants for Mingx OpenTelemetry integration."""

from typing import Literal, Union, get_args

from typing_extensions import TypeAlias

MINGX_TRACER_NAME = "mingx-sdk"

ObservationTypeLiteral: TypeAlias = Literal["span", "generation", "event"]

ObservationTypeLiteralNoEvent: TypeAlias = Literal["span", "generation"]


def get_observation_types_list() -> list[str]:
    """Return list of valid observation type strings."""
    return list(get_args(ObservationTypeLiteral))
