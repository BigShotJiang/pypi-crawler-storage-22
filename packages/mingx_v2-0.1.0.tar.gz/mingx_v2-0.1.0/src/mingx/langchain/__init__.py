"""LangChain integration: callback handler for tracing LC runs with Mingx."""

from mingx.langchain.callback import MingxCallbackHandler

CallbackHandler = MingxCallbackHandler

__all__ = ["CallbackHandler", "MingxCallbackHandler"]
