"""CosyVoice2 subpackage for StepAudio2."""
