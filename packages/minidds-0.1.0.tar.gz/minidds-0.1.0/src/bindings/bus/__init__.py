"""
Minidds Python Wrapper

Easy-to-use Python bindings for the Rust minidds library, providing:
- DDS (Data Distribution Service) message bus
- Publish/subscribe messaging
- Support for keyed and non-keyed topics
"""

__version__ = "0.1.0"
__author__ = "minidds contributors"

# Re-export main classes for convenience
try:
    from minidds import PyDataBus, PyTopic
    
    __all__ = [
        "PyDataBus",
        "PyTopic",
    ]
except ImportError:
    # When not running as compiled extension
    pass
