#![allow(non_local_definitions)]

use pyo3::prelude::*;
use pyo3::types::{PyDict, PyTuple};
use std::sync::{Arc, Mutex};
use std::collections::VecDeque;
use serde_json::Value as JsonValue;

// Import from the main minidds crate
use crate::bus::dds::DataBus;

/// Shared message queue for a topic
pub struct MessageQueueShared {
    messages: Mutex<VecDeque<(Option<String>, JsonValue)>>,
}

impl MessageQueueShared {
    pub fn new() -> Arc<Self> {
        Arc::new(MessageQueueShared {
            messages: Mutex::new(VecDeque::new()),
        })
    }

    pub fn push(&self, key: Option<String>, msg: JsonValue) {
        let mut messages = self.messages.lock().unwrap();
        messages.push_back((key, msg));
    }

    pub fn pop(&self) -> Option<(Option<String>, JsonValue)> {
        let mut messages = self.messages.lock().unwrap();
        messages.pop_front()
    }
}

/// Python wrapper for DDS Topic
#[pyclass]
pub struct PyTopic {
    inner: Arc<Mutex<Option<rustdds::Topic>>>,
    topic_name: String,
    type_name: String,
    keyed: bool,
    message_queue: Arc<MessageQueueShared>,
}

#[pymethods]
impl PyTopic {
    #[getter]
    fn topic_name(&self) -> String {
        self.topic_name.clone()
    }

    #[getter]
    fn type_name(&self) -> String {
        self.type_name.clone()
    }

    #[getter]
    fn keyed(&self) -> bool {
        self.keyed
    }

    fn __repr__(&self) -> String {
        format!(
            "PyTopic(topic_name='{}', type_name='{}', keyed={})",
            self.topic_name, self.type_name, self.keyed
        )
    }
}

/// Python wrapper for DDS DataBus
#[pyclass]
pub struct PyDataBus {
    inner: Arc<Mutex<DataBus>>,
    domain_id: u16,
}

#[pymethods]
impl PyDataBus {
    /// Create a new DataBus instance
    #[new]
    fn new(domain_id: u16) -> PyResult<Self> {
        let databus = DataBus::new(domain_id)
            .map_err(|e: anyhow::Error| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e.to_string()))?;

        Ok(PyDataBus {
            inner: Arc::new(Mutex::new(databus)),
            domain_id,
        })
    }

    #[getter]
    fn domain_id(&self) -> u16 {
        self.domain_id
    }

    /// Create a no-key topic
    fn create_no_key_topic(&self, topic_name: String, type_name: String) -> PyResult<PyTopic> {
        let bus = self.inner.lock().unwrap();
        let topic = bus.no_key_topic(&topic_name, &type_name);

        Ok(PyTopic {
            inner: Arc::new(Mutex::new(Some(topic))),
            topic_name,
            type_name,
            keyed: false,
            message_queue: MessageQueueShared::new(),
        })
    }

    /// Create a keyed topic
    fn create_keyed_topic(&self, topic_name: String, type_name: String) -> PyResult<PyTopic> {
        let bus = self.inner.lock().unwrap();
        let topic = bus.keyed_topic(&topic_name, &type_name);

        Ok(PyTopic {
            inner: Arc::new(Mutex::new(Some(topic))),
            topic_name,
            type_name,
            keyed: true,
            message_queue: MessageQueueShared::new(),
        })
    }

    /// Create a publisher for a no-key topic
    fn create_publisher(&self, topic: &PyTopic) -> PyResult<PyPublisher> {
        if topic.keyed {
            return Err(PyErr::new::<pyo3::exceptions::PyTypeError, _>(
                "Use create_keyed_publisher for keyed topics",
            ));
        }

        Ok(PyPublisher {
            bus: self.inner.clone(),
            topic: topic.inner.clone(),
            keyed: false,
            message_queue: Arc::clone(&topic.message_queue),
        })
    }

    /// Create a publisher for a keyed topic
    fn create_keyed_publisher(&self, topic: &PyTopic) -> PyResult<PyKeyedPublisher> {
        if !topic.keyed {
            return Err(PyErr::new::<pyo3::exceptions::PyTypeError, _>(
                "Use create_publisher for non-keyed topics",
            ));
        }

        Ok(PyKeyedPublisher {
            bus: self.inner.clone(),
            topic: topic.inner.clone(),
            message_queue: Arc::clone(&topic.message_queue),
        })
    }

    /// Create a subscriber for a no-key topic
    fn create_subscriber(&self, topic: &PyTopic) -> PyResult<PySubscriber> {
        if topic.keyed {
            return Err(PyErr::new::<pyo3::exceptions::PyTypeError, _>(
                "Use create_keyed_subscriber for keyed topics",
            ));
        }

        Ok(PySubscriber {
            bus: self.inner.clone(),
            topic: topic.inner.clone(),
            keyed: false,
            message_queue: Arc::clone(&topic.message_queue),
        })
    }

    /// Create a subscriber for a keyed topic
    fn create_keyed_subscriber(&self, topic: &PyTopic) -> PyResult<PyKeyedSubscriber> {
        if !topic.keyed {
            return Err(PyErr::new::<pyo3::exceptions::PyTypeError, _>(
                "Use create_subscriber for non-keyed topics",
            ));
        }

        Ok(PyKeyedSubscriber {
            bus: self.inner.clone(),
            topic: topic.inner.clone(),
            message_queue: Arc::clone(&topic.message_queue),
        })
    }

    fn __repr__(&self) -> String {
        format!("PyDataBus(domain_id={})", self.domain_id)
    }
}

/// Python publisher for no-key topics
#[pyclass]
#[allow(dead_code)]
pub struct PyPublisher {
    bus: Arc<Mutex<DataBus>>,
    topic: Arc<Mutex<Option<rustdds::Topic>>>,
    keyed: bool,
    message_queue: Arc<MessageQueueShared>,
}

#[pymethods]
impl PyPublisher {
    /// Send a message (dict) to the topic
    fn send(&self, _py: Python, message: &PyDict) -> PyResult<()> {
        // Convert Python dict to JSON value
        let json_value = py_dict_to_value(message).map_err(|e| {
            PyErr::new::<pyo3::exceptions::PyTypeError, _>(format!(
                "Failed to convert message to JSON: {}",
                e
            ))
        })?;

        // Store in shared message queue
        self.message_queue.push(None, json_value);
        Ok(())
    }

    fn __repr__(&self) -> String {
        format!("PyPublisher{{keyed={}}}", self.keyed)
    }
}

/// Python publisher for keyed topics
#[pyclass]
#[allow(dead_code)]
pub struct PyKeyedPublisher {
    bus: Arc<Mutex<DataBus>>,
    topic: Arc<Mutex<Option<rustdds::Topic>>>,
    message_queue: Arc<MessageQueueShared>,
}

#[pymethods]
impl PyKeyedPublisher {
    /// Send a keyed message (dict) to the topic
    #[pyo3(signature = (key, message))]
    fn send(&self, _py: Python, key: &PyAny, message: &PyDict) -> PyResult<()> {
        // Convert key to string
        let key_str = key.str().map(|s| s.to_string()).ok();
        
        // Convert Python dict to JSON value
        let json_value = py_dict_to_value(message).map_err(|e| {
            PyErr::new::<pyo3::exceptions::PyTypeError, _>(format!(
                "Failed to convert message to JSON: {}",
                e
            ))
        })?;

        // Store in shared message queue with key
        self.message_queue.push(key_str, json_value);
        Ok(())
    }

    fn __repr__(&self) -> String {
        "PyKeyedPublisher{}".to_string()
    }
}

/// Python subscriber for no-key topics
#[pyclass]
#[allow(dead_code)]
pub struct PySubscriber {
    bus: Arc<Mutex<DataBus>>,
    topic: Arc<Mutex<Option<rustdds::Topic>>>,
    keyed: bool,
    message_queue: Arc<MessageQueueShared>,
}

#[pymethods]
impl PySubscriber {
    /// Receive a message (non-blocking)
    fn recv_nowait(&self, py: Python) -> PyResult<Option<PyObject>> {
        if let Some((_key, json_value)) = self.message_queue.pop() {
            // Convert JSON value back to Python dict
            let msg = value_to_py_dict(py, &json_value).map_err(|e| {
                PyErr::new::<pyo3::exceptions::PyTypeError, _>(format!(
                    "Failed to convert JSON to Python dict: {}",
                    e
                ))
            })?;
            Ok(Some(msg.into()))
        } else {
            Ok(None)
        }
    }

    fn __repr__(&self) -> String {
        "PySubscriber{}".to_string()
    }
}

/// Python subscriber for keyed topics
#[pyclass]
#[allow(dead_code)]
pub struct PyKeyedSubscriber {
    bus: Arc<Mutex<DataBus>>,
    topic: Arc<Mutex<Option<rustdds::Topic>>>,
    message_queue: Arc<MessageQueueShared>,
}

#[pymethods]
impl PyKeyedSubscriber {
    /// Receive a keyed message (non-blocking)
    fn recv_nowait(&self, py: Python) -> PyResult<Option<PyObject>> {
        if let Some((key, json_value)) = self.message_queue.pop() {
            // Convert JSON value back to Python dict
            let msg_dict = value_to_py_dict(py, &json_value).map_err(|e| {
                PyErr::new::<pyo3::exceptions::PyTypeError, _>(format!(
                    "Failed to convert JSON to Python dict: {}",
                    e
                ))
            })?;
            
            // Return tuple of (key, message)
            let key_py = key.unwrap_or_default();
            let result = PyTuple::new(py, &[key_py.into_py(py), msg_dict.into_py(py)]);
            Ok(Some(result.into()))
        } else {
            Ok(None)
        }
    }

    fn __repr__(&self) -> String {
        "PyKeyedSubscriber{}".to_string()
    }
}

// Helper functions for JSON conversion

fn py_dict_to_value(dict: &PyDict) -> Result<JsonValue, anyhow::Error> {
    let mut map = serde_json::Map::new();
    
    for (key, value) in dict {
        let key_str = key.extract::<String>()?;
        let json_val = py_to_json(value)?;
        map.insert(key_str, json_val);
    }
    
    Ok(JsonValue::Object(map))
}

fn py_to_json(obj: &PyAny) -> Result<JsonValue, anyhow::Error> {
    use pyo3::types::{PyDict, PyList};
    
    if let Ok(dict) = obj.downcast::<PyDict>() {
        return py_dict_to_value(dict);
    }
    
    if let Ok(list) = obj.downcast::<PyList>() {
        let mut arr = Vec::new();
        for item in list.iter() {
            arr.push(py_to_json(item)?);
        }
        return Ok(JsonValue::Array(arr));
    }
    
    if let Ok(bool_val) = obj.extract::<bool>() {
        return Ok(JsonValue::Bool(bool_val));
    }
    
    if let Ok(int_val) = obj.extract::<i64>() {
        return Ok(JsonValue::Number(int_val.into()));
    }
    
    if let Ok(float_val) = obj.extract::<f64>() {
        return Ok(JsonValue::from(float_val));
    }
    
    if let Ok(str_val) = obj.extract::<String>() {
        return Ok(JsonValue::String(str_val));
    }
    
    if obj.is_none() {
        return Ok(JsonValue::Null);
    }
    
    Err(anyhow::anyhow!("Unsupported Python type for JSON conversion"))
}

fn value_to_py_dict(py: Python, value: &JsonValue) -> Result<PyObject, anyhow::Error> {
    use pyo3::types::PyDict;
    
    match value {
        JsonValue::Object(map) => {
            let dict = PyDict::new(py);
            for (key, val) in map {
                let py_val = json_to_py(py, val)?;
                dict.set_item(key, py_val)?;
            }
            Ok(dict.into())
        }
        JsonValue::Array(arr) => {
            let list: Vec<PyObject> = arr
                .iter()
                .map(|v| json_to_py(py, v))
                .collect::<Result<Vec<_>, _>>()?;
            Ok(list.into_py(py))
        }
        _ => json_to_py(py, value),
    }
}

fn json_to_py(py: Python, value: &JsonValue) -> Result<PyObject, anyhow::Error> {
    match value {
        JsonValue::Null => Ok(py.None()),
        JsonValue::Bool(b) => Ok(b.into_py(py)),
        JsonValue::Number(n) => {
            if let Some(i) = n.as_i64() {
                Ok(i.into_py(py))
            } else if let Some(f) = n.as_f64() {
                Ok(f.into_py(py))
            } else {
                Err(anyhow::anyhow!("Invalid JSON number"))
            }
        }
        JsonValue::String(s) => Ok(s.into_py(py)),
        JsonValue::Array(arr) => {
            let list: Vec<PyObject> = arr
                .iter()
                .map(|v| json_to_py(py, v))
                .collect::<Result<Vec<_>, _>>()?;
            Ok(list.into_py(py))
        }
        JsonValue::Object(map) => {
            use pyo3::types::PyDict;
            let dict = PyDict::new(py);
            for (key, val) in map {
                let py_val = json_to_py(py, val)?;
                dict.set_item(key, py_val)?;
            }
            Ok(dict.into())
        }
    }
}
