"""
Minidds DDS Python Wrapper - Usage Examples

This module demonstrates how to use the Rust DDS bus from Python.
"""

from minidds import PyDataBus, PyTopic

# Example 1: Basic publish/subscribe with no-key topics
def example_no_key_pubsub():
    """Simple publish/subscribe without keyed messages"""
    
    # Create a DataBus with domain ID 0
    bus = PyDataBus(domain_id=0)
    
    # Create a no-key topic for string messages
    topic = bus.create_no_key_topic(
        topic_name="messages",
        type_name="string_message"
    )
    
    # Create publisher and subscriber
    publisher = bus.create_publisher(topic)
    subscriber = bus.create_subscriber(topic)
    
    # Publish a message (as dict)
    message = {
        "text": "Hello from Python!",
        "timestamp": "2024-01-01T00:00:00",
        "source": "python-example"
    }
    
    publisher.send(message)
    
    # Subscribe and receive
    result = subscriber.recv_nowait()
    if result:
        print(f"Received: {result}")


# Example 2: Keyed topic with multiple keys
def example_keyed_pubsub():
    """Publish/subscribe with keyed messages"""
    
    bus = PyDataBus(domain_id=0)
    
    # Create a keyed topic
    topic = bus.create_keyed_topic(
        topic_name="user_events",
        type_name="user_event"
    )
    
    # Create keyed publisher and subscriber
    publisher = bus.create_keyed_publisher(topic)
    subscriber = bus.create_keyed_subscriber(topic)
    
    # Publish messages with different keys
    for user_id in range(1, 4):
        message = {
            "user_id": user_id,
            "action": "login",
            "timestamp": "2024-01-01T00:00:00"
        }
        publisher.send(key=user_id, message=message)
    
    # Receive messages with keys
    print("Receiving keyed messages:")
    for _ in range(3):
        result = subscriber.recv_nowait()
        if result:
            key, message = result
            print(f"  Key: {key}, Message: {message}")


# Example 3: Multiple domains
def example_multi_domain():
    """Using multiple DDS domains"""
    
    # Create buses in different domains
    bus_domain_0 = PyDataBus(domain_id=0)
    bus_domain_1 = PyDataBus(domain_id=1)
    
    # Each bus is independent
    topic_0 = bus_domain_0.create_no_key_topic("topic_d0", "data")
    topic_1 = bus_domain_1.create_no_key_topic("topic_d1", "data")
    
    # Create publishers and subscribers
    pub_0 = bus_domain_0.create_publisher(topic_0)
    sub_0 = bus_domain_0.create_subscriber(topic_0)
    
    pub_1 = bus_domain_1.create_publisher(topic_1)
    sub_1 = bus_domain_1.create_subscriber(topic_1)
    
    # Publish to domain 0
    pub_0.send({"domain": 0, "message": "Hello from domain 0"})
    
    # Publish to domain 1
    pub_1.send({"domain": 1, "message": "Hello from domain 1"})
    
    # Receive from both domains - messages are isolated
    print("Receiving from domain 0:")
    result_0 = sub_0.recv_nowait()
    if result_0:
        print(f"  {result_0}")
    
    print("Receiving from domain 1:")
    result_1 = sub_1.recv_nowait()
    if result_1:
        print(f"  {result_1}")


# Example 4: Data types
def example_supported_types():
    """
    Supported data types in messages:
    
    - str: strings
    - int: integers
    - float: floating point numbers
    - bool: booleans
    - None: null values
    - list: arrays
    - dict: nested objects
    
    All messages are serialized as JSON internally.
    """
    
    message = {
        "id": 123,
        "name": "example",
        "value": 45.67,
        "active": True,
        "tags": ["tag1", "tag2"],
        "metadata": {
            "version": "1.0",
            "author": "user"
        },
        "nullable_field": None
    }
    return message


# Example 5: Send multiple messages and receive in loop
def example_batch_messages():
    """Send multiple messages and receive them until queue is empty"""
    
    bus = PyDataBus(domain_id=0)
    topic = bus.create_no_key_topic("batch_messages", "message")
    
    publisher = bus.create_publisher(topic)
    subscriber = bus.create_subscriber(topic)
    
    # Send multiple messages
    print("Sending 5 messages:")
    for i in range(1, 6):
        message = {
            "id": i,
            "content": f"Message number {i}",
            "timestamp": "2024-01-01T00:00:00"
        }
        publisher.send(message)
        print(f"  Sent: {message}")
    
    # Receive all messages in a loop until queue is empty
    print("Receiving all messages:")
    count = 0
    while True:
        result = subscriber.recv_nowait()
        if result is None:
            break
        count += 1
        print(f"  [{count}] {result}")
    
    print(f"Total received: {count} messages")


# Example 6: Error handling
def example_error_handling():
    """Demonstrate error handling when Rust side has errors"""
    
    print("Example A: Type mismatch error - wrong topic type for publisher")
    try:
        bus = PyDataBus(domain_id=0)
        # Create a keyed topic
        keyed_topic = bus.create_keyed_topic("error_test", "data")
        
        # Try to use it as a no-key topic (wrong type)
        pub = bus.create_publisher(keyed_topic)  # This should fail
    except TypeError as e:
        print(f"  ✓ Caught TypeError: {e}")
    except Exception as e:
        print(f"  Got exception: {type(e).__name__}: {e}")
    
    print("\nExample B: Type mismatch error - wrong topic type for subscriber")
    try:
        bus = PyDataBus(domain_id=0)
        # Create a no-key topic
        no_key_topic = bus.create_no_key_topic("error_test2", "data")
        
        # Try to use it as a keyed topic (wrong type)
        sub = bus.create_keyed_subscriber(no_key_topic)  # This should fail
    except TypeError as e:
        print(f"  ✓ Caught TypeError: {e}")
    except Exception as e:
        print(f"  Got exception: {type(e).__name__}: {e}")
    
    print("\nExample C: Invalid message data (non-dict)")
    try:
        bus = PyDataBus(domain_id=0)
        topic = bus.create_no_key_topic("error_test3", "data")
        pub = bus.create_publisher(topic)
        
        # Try to send non-dict (should fail)
        pub.send("not a dict")  # type: ignore
    except TypeError as e:
        print(f"  ✓ Caught TypeError: {e}")
    except Exception as e:
        print(f"  Got exception: {type(e).__name__}: {e}")
    
    print("\nExample D: Successful operation (no error)")
    try:
        bus = PyDataBus(domain_id=0)
        topic = bus.create_no_key_topic("success_test", "data")
        pub = bus.create_publisher(topic)
        sub = bus.create_subscriber(topic)
        
        # Send valid message
        pub.send({"data": "success"})
        result = sub.recv_nowait()
        
        if result:
            print(f"  ✓ Success: received {result}")
        else:
            print("  ✗ No message received")
    except Exception as e:
        print(f"  ✗ Error: {type(e).__name__}: {e}")


if __name__ == "__main__":
    # Run examples
    print("Running example 1: No-key topic publish/subscribe")
    example_no_key_pubsub()
    
    print("\nRunning example 2: Keyed topic publish/subscribe")
    example_keyed_pubsub()
    
    print("\nRunning example 3: Multiple domains")
    example_multi_domain()
    
    print("\nRunning example 5: Batch messages - send multiple and recv in loop")
    example_batch_messages()
    
    print("\nRunning example 6: Error handling - what happens on Rust errors")
    example_error_handling()
    
    print("\nAll examples completed!")
