#[cfg(feature = "python-extension")]
pub mod dds;

#[cfg(feature = "python-extension")]
use pyo3::prelude::*;

#[cfg(feature = "python-extension")]
pub fn init_python_module(py: Python, m: &PyModule) -> PyResult<()> {
    // Add classes directly to main module for convenience
    m.add_class::<dds::PyDataBus>()?;
    m.add_class::<dds::PyTopic>()?;
    m.add_class::<dds::PyPublisher>()?;
    m.add_class::<dds::PyKeyedPublisher>()?;
    m.add_class::<dds::PySubscriber>()?;
    m.add_class::<dds::PyKeyedSubscriber>()?;
    
    // Create bus submodule
    let bus_module = PyModule::new(py, "minidds.bus")?;
    bus_module.add_class::<dds::PyDataBus>()?;
    bus_module.add_class::<dds::PyTopic>()?;
    bus_module.add_class::<dds::PyPublisher>()?;
    bus_module.add_class::<dds::PyKeyedPublisher>()?;
    bus_module.add_class::<dds::PySubscriber>()?;
    bus_module.add_class::<dds::PyKeyedSubscriber>()?;
    
    // Register in sys.modules for proper import support
    py.import("sys")?
        .getattr("modules")?
        .set_item("minidds.bus", bus_module)?;
    
    m.add_submodule(bus_module)?;
    Ok(())
}
