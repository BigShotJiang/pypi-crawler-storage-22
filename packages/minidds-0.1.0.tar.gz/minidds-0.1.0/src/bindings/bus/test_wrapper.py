"""
Unit tests for minidds Python wrapper
"""

import unittest
from minidds import PyDataBus, PyTopic


class TestDataBusBasics(unittest.TestCase):
    """Test basic DataBus functionality"""
    
    def setUp(self):
        """Setup test fixtures"""
        self.bus = PyDataBus(domain_id=0)
    
    def test_databus_creation(self):
        """Test DataBus instantiation"""
        self.assertIsNotNone(self.bus)
        self.assertEqual(self.bus.domain_id, 0)
    
    def test_different_domain_ids(self):
        """Test DataBus with different domain IDs"""
        bus_0 = PyDataBus(domain_id=0)
        bus_1 = PyDataBus(domain_id=1)
        
        self.assertEqual(bus_0.domain_id, 0)
        self.assertEqual(bus_1.domain_id, 1)
    
    def test_topic_creation_no_key(self):
        """Test creating a no-key topic"""
        topic = self.bus.create_no_key_topic(
            topic_name="test_topic",
            type_name="test_type"
        )
        
        self.assertIsNotNone(topic)
        self.assertEqual(topic.topic_name, "test_topic")
        self.assertEqual(topic.type_name, "test_type")
        self.assertFalse(topic.keyed)
    
    def test_topic_creation_keyed(self):
        """Test creating a keyed topic"""
        topic = self.bus.create_keyed_topic(
            topic_name="test_keyed",
            type_name="keyed_type"
        )
        
        self.assertIsNotNone(topic)
        self.assertEqual(topic.topic_name, "test_keyed")
        self.assertTrue(topic.keyed)


class TestPublisherSubscriber(unittest.TestCase):
    """Test Publisher/Subscriber functionality"""
    
    def setUp(self):
        """Setup test fixtures"""
        self.bus = PyDataBus(domain_id=0)
    
    def test_publisher_creation_no_key(self):
        """Test creating a publisher for no-key topic"""
        topic = self.bus.create_no_key_topic("pub_test", "test")
        pub = self.bus.create_publisher(topic)
        
        self.assertIsNotNone(pub)
    
    def test_publisher_creation_keyed(self):
        """Test creating a publisher for keyed topic"""
        topic = self.bus.create_keyed_topic("pub_keyed", "test")
        pub = self.bus.create_keyed_publisher(topic)
        
        self.assertIsNotNone(pub)
    
    def test_publisher_wrong_topic_type(self):
        """Test that publisher rejects wrong topic type"""
        # Create keyed topic but try to use no-key publisher
        topic = self.bus.create_keyed_topic("wrong", "test")
        
        with self.assertRaises(TypeError):
            self.bus.create_publisher(topic)
    
    def test_keyed_publisher_wrong_topic_type(self):
        """Test that keyed publisher rejects wrong topic type"""
        # Create no-key topic but try to use keyed publisher
        topic = self.bus.create_no_key_topic("wrong", "test")
        
        with self.assertRaises(TypeError):
            self.bus.create_keyed_publisher(topic)
    
    def test_subscriber_creation_no_key(self):
        """Test creating a subscriber for no-key topic"""
        topic = self.bus.create_no_key_topic("sub_test", "test")
        sub = self.bus.create_subscriber(topic)
        
        self.assertIsNotNone(sub)
    
    def test_subscriber_creation_keyed(self):
        """Test creating a subscriber for keyed topic"""
        topic = self.bus.create_keyed_topic("sub_keyed", "test")
        sub = self.bus.create_keyed_subscriber(topic)
        
        self.assertIsNotNone(sub)
    
    def test_subscriber_wrong_topic_type(self):
        """Test that subscriber rejects wrong topic type"""
        topic = self.bus.create_keyed_topic("wrong", "test")
        
        with self.assertRaises(TypeError):
            self.bus.create_subscriber(topic)
    
    def test_keyed_subscriber_wrong_topic_type(self):
        """Test that keyed subscriber rejects wrong topic type"""
        topic = self.bus.create_no_key_topic("wrong", "test")
        
        with self.assertRaises(TypeError):
            self.bus.create_keyed_subscriber(topic)


class TestPublisherSend(unittest.TestCase):
    """Test publisher send functionality"""
    
    def setUp(self):
        """Setup test fixtures"""
        self.bus = PyDataBus(domain_id=0)
        self.topic = self.bus.create_no_key_topic("send_test", "test")
        self.pub = self.bus.create_publisher(self.topic)
    
    def test_send_simple_message(self):
        """Test sending a simple message"""
        message = {"text": "hello"}
        # Should not raise
        self.pub.send(message)
    
    def test_send_complex_message(self):
        """Test sending a complex nested message"""
        message = {
            "id": 123,
            "name": "test",
            "value": 3.14,
            "active": True,
            "tags": ["tag1", "tag2"],
            "nested": {
                "inner": "value",
                "count": 42
            }
        }
        self.pub.send(message)
    
    def test_send_with_null(self):
        """Test sending message with null values"""
        message = {
            "data": None,
            "value": 42
        }
        self.pub.send(message)
    
    def test_send_empty_dict(self):
        """Test sending empty dict"""
        message = {}
        self.pub.send(message)
    
    def test_send_with_array(self):
        """Test sending array"""
        message = {
            "items": [1, 2, 3, 4, 5],
            "strings": ["a", "b", "c"],
            "mixed": [1, "two", 3.0, True, None]
        }
        self.pub.send(message)


class TestKeyedPublisherSend(unittest.TestCase):
    """Test keyed publisher send functionality"""
    
    def setUp(self):
        """Setup test fixtures"""
        self.bus = PyDataBus(domain_id=0)
        self.topic = self.bus.create_keyed_topic("keyed_send", "test")
        self.pub = self.bus.create_keyed_publisher(self.topic)
    
    def test_send_with_string_key(self):
        """Test sending with string key"""
        message = {"data": "value"}
        self.pub.send(key="key123", message=message)
    
    def test_send_with_int_key(self):
        """Test sending with integer key"""
        message = {"data": "value"}
        self.pub.send(key=42, message=message)
    
    def test_send_with_different_keys(self):
        """Test sending multiple messages with different keys"""
        for i in range(5):
            message = {"index": i, "data": f"value_{i}"}
            self.pub.send(key=i, message=message)


class TestSubscriberRecv(unittest.TestCase):
    """Test subscriber receive functionality"""
    
    def setUp(self):
        """Setup test fixtures"""
        self.bus = PyDataBus(domain_id=0)
        self.topic = self.bus.create_no_key_topic("recv_test", "test")
        self.sub = self.bus.create_subscriber(self.topic)
    
    def test_recv_nowait_empty(self):
        """Test recv_nowait when no message available"""
        result = self.sub.recv_nowait()
        # Should return None when no message
        self.assertIsNone(result)
    
    def test_send_and_recv(self):
        """Test sending and receiving a message"""
        # Create separate topic for clean test
        topic = self.bus.create_no_key_topic("send_recv_test", "test")
        pub = self.bus.create_publisher(topic)
        sub = self.bus.create_subscriber(topic)
        
        # Send message
        test_msg = {"data": "test", "value": 42}
        pub.send(test_msg)
        
        # Receive it
        result = sub.recv_nowait()
        self.assertIsNotNone(result)
        self.assertEqual(result["data"], "test")
        self.assertEqual(result["value"], 42)


class TestDataTypes(unittest.TestCase):
    """Test various data type support"""
    
    def setUp(self):
        """Setup test fixtures"""
        self.bus = PyDataBus(domain_id=0)
        self.topic = self.bus.create_no_key_topic("types_test", "test")
        self.pub = self.bus.create_publisher(self.topic)
    
    def test_string_type(self):
        """Test string data type"""
        self.pub.send({"value": "hello world"})
    
    def test_int_type(self):
        """Test integer data type"""
        self.pub.send({"value": 42})
        self.pub.send({"value": -100})
        self.pub.send({"value": 0})
    
    def test_float_type(self):
        """Test float data type"""
        self.pub.send({"value": 3.14})
        self.pub.send({"value": -2.5})
        self.pub.send({"value": 0.0})
    
    def test_bool_type(self):
        """Test boolean data type"""
        self.pub.send({"value": True})
        self.pub.send({"value": False})
    
    def test_null_type(self):
        """Test null/None data type"""
        self.pub.send({"value": None})
    
    def test_nested_dict(self):
        """Test nested dictionary"""
        self.pub.send({
            "level1": {
                "level2": {
                    "level3": {
                        "value": "deep"
                    }
                }
            }
        })
    
    def test_array_types(self):
        """Test array with mixed types"""
        self.pub.send({
            "mixed": [1, "two", 3.0, True, None, {"nested": "dict"}]
        })


class TestTopicRepresentation(unittest.TestCase):
    """Test string representation of objects"""
    
    def setUp(self):
        """Setup test fixtures"""
        self.bus = PyDataBus(domain_id=0)
    
    def test_databus_repr(self):
        """Test DataBus __repr__"""
        repr_str = repr(self.bus)
        self.assertIn("PyDataBus", repr_str)
        self.assertIn("domain_id=0", repr_str)
    
    def test_topic_repr(self):
        """Test PyTopic __repr__"""
        topic = self.bus.create_no_key_topic("test", "type_name")
        repr_str = repr(topic)
        self.assertIn("PyTopic", repr_str)
        self.assertIn("test", repr_str)
    
    def test_publisher_repr(self):
        """Test PyPublisher __repr__"""
        topic = self.bus.create_no_key_topic("test", "type")
        pub = self.bus.create_publisher(topic)
        repr_str = repr(pub)
        self.assertIn("PyPublisher", repr_str)


if __name__ == "__main__":
    unittest.main()
