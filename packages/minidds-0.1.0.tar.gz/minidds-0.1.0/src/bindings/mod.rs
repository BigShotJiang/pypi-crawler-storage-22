#[cfg(feature = "python-extension")]
pub mod bus;

#[cfg(feature = "python-extension")]
use pyo3::prelude::*;

#[cfg(feature = "python-extension")]
#[pymodule]
#[pyo3(name = "minidds")]
pub fn minidds_py(py: Python, m: &PyModule) -> PyResult<()> {
    bus::init_python_module(py, m)?;
    Ok(())
}