use serde::{Deserialize, Serialize};
use std::time::Duration;

use rustdds::{
    DomainParticipant, DomainParticipantBuilder, Keyed, QosPolicies, QosPolicyBuilder, Topic, TopicKind, no_key::{DataSample as NoKeyDataSample}, policy::Reliability, serialization::{CDRDeserializerAdapter, CDRSerializerAdapter}
};

/// DDS 数据总线，提供发布/订阅功能
#[derive(Clone)]
pub struct DataBus {
    domain_participant: DomainParticipant,
    subscriber: rustdds::Subscriber,
    publisher: rustdds::Publisher,
    qos_profile: QosPolicies,
}

/// 消息订阅器，用于接收特定类型的数据
pub struct NoKeyMessageReceiver<T>
where
    T: Serialize + for<'de> Deserialize<'de> + 'static
{
    reader: rustdds::no_key::DataReader<T>,
}

impl<T> NoKeyMessageReceiver<T>
where
    T: Serialize + for<'de> Deserialize<'de> + 'static
{
    /// 创建新的消息接收器
    fn new(reader: rustdds::no_key::DataReader<T>) -> Self {
        Self { reader }
    }

    /// 尝试接收消息（非阻塞）
    pub async  fn try_recv(&mut self) -> Result<Option<NoKeyDataSample<T>>, anyhow::Error> {
        match self.reader.take_next_sample() {
            Ok(Some(value)) => Ok(Some(value)),
            Ok(None) => Ok(None), // No data available
            Err(e) => Err(anyhow::anyhow!("Failed to read data sample: {:?}", e)),
        }
    }

    pub async fn recv_timeout(&mut self, timeout: Duration) -> Result<Option<NoKeyDataSample<T>>, anyhow::Error> {
        let start = tokio::time::Instant::now();
        loop {
            match self.reader.take_next_sample() {
                Ok(Some(value)) => return Ok(Some(value)),
                Ok(None) => {
                    if start.elapsed() >= timeout {
                        return Ok(None); // Timeout reached
                    }
                    // No data yet, wait a bit before trying again
                    tokio::time::sleep(Duration::from_millis(10)).await;
                }
                Err(e) => return Err(anyhow::anyhow!("Failed to read data sample: {:?}", e)),
            }
        }
    }

    /// 异步接收消息
    pub async fn recv(&mut self) -> Result<Option<NoKeyDataSample<T>>, anyhow::Error> {
        loop {
            match self.reader.take_next_sample() {
                Ok(Some(value)) => return Ok(Some(value)),
                Ok(None) => {
                    // No data yet, wait a bit before trying again
                    tokio::time::sleep(Duration::from_millis(10)).await;
                }
                Err(e) => return Err(anyhow::anyhow!("Failed to read data sample: {:?}", e)),
            }
        }
    }
}


pub struct KeyedMessageReceiver<T>
where
    T: Keyed + Serialize + for<'de> Deserialize<'de> + 'static,
    <T as Keyed>::K: for<'de> serde::Deserialize<'de>,
{
    reader: rustdds::with_key::DataReader<T>,
}

impl<T> KeyedMessageReceiver<T>
where
    T: Keyed + Serialize + for<'de> Deserialize<'de> + 'static,
    <T as Keyed>::K: for<'de> serde::Deserialize<'de>,
{
    /// 创建新的消息接收器
    fn new(reader: rustdds::with_key::DataReader<T>) -> Self {
        Self { reader }
    }

    /// 尝试接收消息（非阻塞）
    pub async  fn try_recv(&mut self) -> Result<Option<rustdds::with_key::DataSample<T>>, anyhow::Error> {
        match self.reader.take_next_sample() {
            Ok(Some(value)) => Ok(Some(value)),
            Ok(None) => Ok(None), // No data available
            Err(e) => Err(anyhow::anyhow!("Failed to read data sample: {:?}", e)),
        }
    }

    pub async fn recv_timeout(&mut self, timeout: Duration) -> Result<Option<rustdds::with_key::DataSample<T>>, anyhow::Error> {
        let start = tokio::time::Instant::now();
        loop {
            match self.reader.take_next_sample() {
                Ok(Some(value)) => return Ok(Some(value)),
                Ok(None) => {
                    if start.elapsed() >= timeout {
                        return Ok(None); // Timeout reached
                    }
                    // No data yet, wait a bit before trying again
                    tokio::time::sleep(Duration::from_millis(10)).await;
                }
                Err(e) => return Err(anyhow::anyhow!("Failed to read data sample: {:?}", e)),
            }
        }
    }

    /// 异步接收消息
    pub async fn recv(&mut self) -> Result<Option<rustdds::with_key::DataSample<T>>, anyhow::Error> {
        loop {
            match self.reader.take_next_sample() {
                Ok(Some(value)) => return Ok(Some(value)),
                Ok(None) => {
                    // No data yet, wait a bit before trying again
                    tokio::time::sleep(Duration::from_millis(10)).await;
                }
                Err(e) => return Err(anyhow::anyhow!("Failed to read data sample: {:?}", e)),
            }
        }
    }
}

pub struct NoKeyMessageSender<T>
where
    T: Serialize + for<'de> Deserialize<'de> + 'static
{
    writer: rustdds::no_key::DataWriter<T>,
}

impl<T> NoKeyMessageSender<T>
where
    T: Serialize + for<'de> Deserialize<'de> + 'static
{
    fn new(writer: rustdds::no_key::DataWriter<T>) -> Self {
        Self { writer }
    }

    pub async fn send(&mut self, data: T) -> Result<(), anyhow::Error> {
        self.writer.write(data, None).map_err(|_| anyhow::anyhow!("Failed to write data"))?;
        Ok(())
    }
}

pub struct KeyedMessageSender<T>
where
    T: Keyed + Serialize + for<'de> Deserialize<'de> + 'static,
{
    writer: rustdds::with_key::DataWriter<T>,
}

impl<T> KeyedMessageSender<T>
where
    T: Keyed +Serialize + for<'de> Deserialize<'de> + 'static
{
    fn new(writer: rustdds::with_key::DataWriter<T>) -> Self {
        Self { writer }
    }

    pub async fn send(&mut self, data: T) -> Result<(), anyhow::Error> {
        self.writer.write(data, None).map_err(|_| anyhow::anyhow!("Failed to write data"))?;
        Ok(())
    }
}


impl DataBus {
    /// 创建新的 DataBus 实例
    pub fn new(domain_id: u16) -> Result<Self, anyhow::Error> {
        let domain_participant = DomainParticipantBuilder::new(domain_id)
            .build()
            .map_err(|e| anyhow::anyhow!("Failed to create domain participant: {:?}", e))?;

        let qos_profile = QosPolicyBuilder::new()
            .reliability(Reliability::Reliable { max_blocking_time: rustdds::Duration::ZERO })
            .build();

        let subscriber = domain_participant
            .create_subscriber(&qos_profile)
            .map_err(|e| anyhow::anyhow!("Failed to create subscriber: {:?}", e))?;

        let publisher = domain_participant
            .create_publisher(&qos_profile)
            .map_err(|e| anyhow::anyhow!("Failed to create publisher: {:?}", e))?;

        Ok(DataBus {
            domain_participant,
            subscriber,
            publisher,
            qos_profile
        })
    }

    pub fn no_key_topic(&self,topic_name: &str, type_name: &str) -> Topic {
        let topic = self.domain_participant
            .create_topic(
            topic_name.to_string(),  // topic name
            type_name.to_string(), // type name
            &self.qos_profile,
            TopicKind::NoKey,
            )
            .unwrap_or_else(|e| panic!("create_topic failed: {e:?}"));

        topic
    }

    pub fn keyed_topic(&self,topic_name: &str, type_name: &str) -> Topic {
        let topic = self.domain_participant
            .create_topic(
            topic_name.to_string(),  // topic name
            type_name.to_string(), // type name
            &self.qos_profile,
            TopicKind::WithKey,
            )
            .unwrap_or_else(|e| panic!("create_topic failed: {e:?}"));

        topic
    }

    /// 订阅指定主题的消息
    pub fn create_no_key_subscriber<T>(&self, topic: &Topic) -> Result<NoKeyMessageReceiver<T>, anyhow::Error>
    where
        T: Serialize + for<'de> Deserialize<'de>
    {
        let reader = self.subscriber
        .create_datareader_no_key::<T, CDRDeserializerAdapter<T>>(
            topic,
            None);

        let reader = reader.map_err(|e| anyhow::anyhow!("Failed to create data reader: {:?}", e))?;

        Ok(NoKeyMessageReceiver::new(reader))
    }


    pub fn create_keyed_subscriber<T>(&self, topic: &Topic) -> Result<KeyedMessageReceiver<T>, anyhow::Error>
    where
        T: Keyed + Serialize + for<'de> Deserialize<'de>,
        <T as Keyed>::K: for<'de> serde::Deserialize<'de>,
    {
        let reader = self.subscriber
        .create_datareader_cdr::<T>(
            topic,
            None);

        let reader = reader.map_err(|e| anyhow::anyhow!("Failed to create data reader: {:?}", e))?;

        Ok(KeyedMessageReceiver::new(reader))
    }


    /// 发布消息到指定主题
    pub fn create_no_key_publisher<T>(&self,topic: &Topic) -> Result<NoKeyMessageSender<T>, anyhow::Error>
    where
        T: Serialize + for<'de> Deserialize<'de>
    {

        let writer = self.publisher
            .create_datawriter_no_key::<T, CDRSerializerAdapter<T>>(
                topic,
                None)
            .unwrap();
        
        Ok(NoKeyMessageSender::new(writer))
    }

        /// 发布消息到指定主题
    pub fn create_keyed_publisher<T>(&self,topic: &Topic) -> Result<KeyedMessageSender<T>, anyhow::Error>
    where
        T: Serialize + for<'de> Deserialize<'de>,
        T: Keyed
    {

        let writer = self.publisher
            .create_datawriter_cdr::<T>(
                topic,
                None)
            .unwrap();
        
        Ok(KeyedMessageSender::new(writer))
    }
}

#[cfg(test)]
mod test {
    use super::*;

    #[tokio::test]
    async fn test_databus_keyed() {
        let databus = DataBus::new(0).expect("Failed to create DataBus");

        #[derive(Serialize, Deserialize, Clone, Debug)]
        struct TestMessage {
            id: u32,
            content: String,
        }

        impl Keyed for TestMessage {
            type K = u32;

            fn key(&self) -> Self::K {
                self.id
            }
        }

        let topic = databus.keyed_topic("test_topic", "TestMessage");
        let mut receiver = databus
            .create_keyed_subscriber::<TestMessage>(&topic)
            .expect("Failed to subscribe to topic");

        let mut sender = databus.create_keyed_publisher::<TestMessage>(&topic).expect("Failed to create publisher");

        let message = TestMessage {
            id: 1,
            content: "Hello, Keyed DDS!".to_string(),
        };
        
        sender
            .send(message.clone())
            .await.expect("Failed to send message");

        // Give DDS time to propagate the message and discover each other
        // tokio::time::sleep(Duration::from_millis(500)).await;

        let received_sample = receiver
            .recv()
            .await
            .expect("Failed to receive message")
            .expect("No message received");

        println!("Received message: {:?}", received_sample.value());
    }


    #[tokio::test]
    async fn test_databus_no_key() {
        let databus = DataBus::new(0).expect("Failed to create DataBus");

        #[derive(Serialize, Deserialize, Clone, Debug)]
        struct TestMessage {
            id: u32,
            content: String,
        }

        let topic = databus.no_key_topic("test_topic", "TestMessage");

        let mut receiver = databus
            .create_no_key_subscriber::<TestMessage>(&topic)
            .expect("Failed to subscribe to topic");

        let mut sender = databus.create_no_key_publisher::<TestMessage>(&topic).expect("Failed to create publisher");


        let message = TestMessage {
            id: 1,
            content: "Hello, DDS!".to_string(),
        };

        sender
            .send(message.clone())
            .await.expect("Failed to send message");

        // Give DDS time to propagate the message and discover each other
        // tokio::time::sleep(Duration::from_millis(500)).await;

        let received_sample = receiver
            .recv()
            .await
            .expect("Failed to receive message")
            .expect("No message received");

        println!("Received message: {:?}", received_sample.value());
    }


    #[tokio::test]
    async fn test_publish_subscribe() {
        // DomainParticipant is always necessary
        let domain_participant = DomainParticipant::new(0).unwrap();

        let qos = QosPolicyBuilder::new()
            .reliability(Reliability::Reliable { max_blocking_time: rustdds::Duration::ZERO })
            .build();

        // DDS Subscriber, only one is necessary for each thread (slight difference to
        // DDS specification)
        let subscriber = domain_participant.create_subscriber(&qos).unwrap();

        // DDS Publisher, only one is necessary for each thread (slight difference to
        // DDS specification)
        let publisher = domain_participant.create_publisher(&qos).unwrap();

        // Some DDS Topic that we can write and read from (basically only binds readers
        // and writers together)
        let some_topic = domain_participant.create_topic("some_topic".to_string(), "SomeType".to_string(), &qos, TopicKind::NoKey).unwrap();

        // Used type needs Serialize for writers and Deserialize for readers
        #[derive(Serialize, Deserialize, Debug)]
        struct SomeType {
             a: i32
        }

        // Creating DataReader requires type and deserializer adapter (which is recommended to be CDR).
        // Reader needs to be mutable if any operations are used.
        let mut reader = subscriber
        .create_datareader_no_key::<SomeType, CDRDeserializerAdapter<SomeType>>(
            &some_topic,
            None)
        .unwrap();

        // Creating DataWriter required type and serializer adapter (which is recommended to be CDR).
        let writer = publisher
            .create_datawriter_no_key::<SomeType, CDRSerializerAdapter<SomeType>>(
                &some_topic,
                None)
            .unwrap();

        // Readers implement mio Evented trait and thus function the same way as
        // std::sync::mpcs and can be handled the same way for reading the data

        let some_data = SomeType { a: 1234 };

        // This should send the data to all who listen "some_topic" topic.
        writer.write(some_data, None).unwrap();

        // // ... Some data has arrived at some point for the reader
        // let data_sample = if let Ok(Some(value)) = reader.take_next_sample() {
        //       value
        //     } else {
        //       panic!("Failed to read data sample")
        //     };
        let data_sample = loop {
            match reader.take_next_sample() {
                Ok(Some(value)) => break value,
                Ok(None) => {
                    // No data yet, wait a bit before trying again
                    tokio::time::sleep(Duration::from_millis(10)).await;
                }
                Err(e) => panic!("Failed to read data sample: {:?}", e),
            }
        };

        // Getting reference to actual data from the data sample
        let actual_data = data_sample.value();
        println!("Received data: {:?}", actual_data);

    }

    #[test]
    fn test_mio_basics() {
        use mio_08::{Poll, Events, Interest, Token};
        use std::net::SocketAddr;
        use std::str::FromStr;
        use std::io::{Write, Read};

        // Demonstrates how mio works with TCP sockets
        // mio provides non-blocking I/O with event notification

        // Create a listening socket
        let listener_addr: SocketAddr = SocketAddr::from_str("127.0.0.1:0").unwrap();
        let mut listener = mio_08::net::TcpListener::bind(listener_addr).unwrap();
        let listener_addr = listener.local_addr().unwrap();

        println!("Test: mio listener bound to {}", listener_addr);

        // Create a Poll instance to manage I/O events
        let mut poll = Poll::new().expect("Failed to create Poll");
        let mut events = Events::with_capacity(8);

        // Register the listener for READABLE events
        const LISTENER_TOKEN: Token = Token(0);
        poll.registry()
            .register(&mut listener, LISTENER_TOKEN, Interest::READABLE)
            .expect("Failed to register listener");

        println!("Test: Listener registered with mio Poll");

        // Spawn a client thread to connect
        let listener_addr_clone = listener_addr;
        let client_thread = std::thread::spawn(move || {
            std::thread::sleep(std::time::Duration::from_millis(100));
            if let Ok(mut stream) = std::net::TcpStream::connect(&listener_addr_clone) {
                println!("Test: Client connected");
                let _ = stream.write_all(b"mio_test_data");
            }
        });

        // Poll for events with a timeout
        match poll.poll(&mut events, Some(std::time::Duration::from_secs(2))) {
            Ok(_) => {
                println!("Test: Poll returned with {} event(s)", events.iter().count());

                // Process incoming events
                for event in events.iter() {
                    if event.token() == LISTENER_TOKEN && event.is_readable() {
                        println!("Test: Listener is accepting connections");

                        if let Ok((mut stream, peer_addr)) = listener.accept() {
                            println!("Test: Accepted connection from {}", peer_addr);

                            // Read data from the client
                            let mut buffer = [0u8; 64];
                            if let Ok(n) = stream.read(&mut buffer) {
                                if n > 0 {
                                    let data_str = String::from_utf8_lossy(&buffer[..n]);
                                    println!("Test: Received data: {}", data_str);
                                    assert_eq!(data_str, "mio_test_data");
                                }
                            }
                        }
                    }
                }
            }
            Err(e) => panic!("Poll error: {}", e),
        }

        // Wait for client thread to finish
        client_thread.join().expect("Client thread panicked");
        println!("Test: mio test completed successfully");
    }

    #[test]
    fn test_mio_verify_logic() {
        use mio_08::{Poll, Events, Interest, Token};
        use std::net::SocketAddr;
        use std::str::FromStr;
        use std::io::Write;

        println!("\n=== POINT 1: Setup Phase Verification ===");
        
        // Point 1.1: Listener is created
        let listener_addr: SocketAddr = SocketAddr::from_str("127.0.0.1:0").unwrap();
        let mut listener = mio_08::net::TcpListener::bind(listener_addr).unwrap();
        let bound_addr = listener.local_addr().unwrap();
        println!("✓ Point 1.1: mio listener created and bound to {}", bound_addr);

        // Point 1.2: Poll instance is created
        let mut poll = Poll::new().expect("Failed to create Poll");
        println!("✓ Point 1.2: Poll instance created successfully");

        // Point 1.3: Listener is registered with Poll
        const LISTENER_TOKEN: Token = Token(0);
        poll.registry()
            .register(&mut listener, LISTENER_TOKEN, Interest::READABLE)
            .expect("Failed to register listener");
        println!("✓ Point 1.3: Listener registered with unique token: {:?}", LISTENER_TOKEN);

        println!("\n=== POINT 3: Readability Condition Verification ===");

        // Point 3.1: Before any connection, poll should timeout (no readable events)
        let mut events_before = Events::with_capacity(8);
        println!("  Testing: Poll with 100ms timeout before client connects...");
        match poll.poll(&mut events_before, Some(std::time::Duration::from_millis(100))) {
            Ok(_) => {
                // Count readable events for our listener
                let listener_events = events_before.iter()
                    .filter(|e| e.token() == LISTENER_TOKEN && e.is_readable())
                    .count();
                println!("✓ Point 3.1: Before connection - {} readable events for listener", listener_events);
                assert_eq!(listener_events, 0, "Listener should NOT be readable before any connection");
            }
            Err(e) => println!("Poll error: {}", e),
        }

        // Point 3.2: When client connects, listener becomes readable
        let bound_addr_clone = bound_addr;
        let client_thread = std::thread::spawn(move || {
            std::thread::sleep(std::time::Duration::from_millis(100));
            if let Ok(mut stream) = std::net::TcpStream::connect(&bound_addr_clone) {
                println!("  Client: Connected to listener");
                let _ = stream.write_all(b"test");
            }
        });

        println!("  Testing: Poll with 2s timeout after spawning client...");
        let mut events_after = Events::with_capacity(8);
        match poll.poll(&mut events_after, Some(std::time::Duration::from_secs(2))) {
            Ok(_) => {
                let listener_events: Vec<_> = events_after.iter()
                    .filter(|e| e.token() == LISTENER_TOKEN && e.is_readable())
                    .collect();
                
                println!("✓ Point 3.2: After connection - {} readable events for listener", listener_events.len());
                assert_eq!(listener_events.len(), 1, "Listener MUST be readable when client connects");
                println!("✓ Point 3.2 (VERIFIED): Listener becomes READABLE only when connection pending");

                // Point 3.3: Confirm conditional is correct
                if let Ok((_, peer_addr)) = listener.accept() {
                    println!("✓ Point 3.3: Successfully accepted connection from {}", peer_addr);
                }
            }
            Err(e) => panic!("Poll error: {}", e),
        }

        client_thread.join().expect("Client thread panicked");
        println!("\n=== VERIFICATION COMPLETE ===");
        println!("✓ Point 1 (Setup): Listener creation, Poll creation, and registration - ALL CORRECT");
        println!("✓ Point 3 (Readability): Listener becomes readable ONLY when connection pending - ALL CORRECT");
    }
}
