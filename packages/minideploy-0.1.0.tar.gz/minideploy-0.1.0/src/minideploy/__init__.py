"""minideploy - Simple deployment tool for your VPS."""

__version__ = "0.1.0"
