"""Main CLI entry point for minideploy."""

import sys
from pathlib import Path
from typing import Optional

import click
import yaml
from pydantic import ValidationError

from minideploy.config import Config
from minideploy.core.builder import Builder
from minideploy.core.deployer import Deployer
from minideploy.core.server_setup import ServerSetup
from minideploy.core.uploader import Uploader
from minideploy.logger import create_logger
from minideploy.services import create_service_manager
from minideploy.ssh import SSHClient, SSHConfig

# Default config file name
CONFIG_FILE = "deploy.yml"


def load_config(config_path: Path) -> Config:
    """Load and validate configuration from YAML file."""
    if not config_path.exists():
        raise click.UsageError(f"Configuration file not found: {config_path}")

    try:
        with open(config_path, "r") as f:
            data = yaml.safe_load(f)

        return Config(**data)
    except ValidationError as e:
        click.echo("Configuration validation error:", err=True)
        for error in e.errors():
            click.echo(
                f"  - {' -> '.join(str(x) for x in error['loc'])}: {error['msg']}",
                err=True,
            )
        sys.exit(1)
    except yaml.YAMLError as e:
        raise click.UsageError(f"Invalid YAML in config file: {e}")


def create_clients(config: Config, verbose: bool = False, dry_run: bool = False):
    """Create SSH client and service manager."""
    logger = create_logger(verbose=verbose, dry_run=dry_run)

    ssh_config = SSHConfig(
        host=config.server.host,
        user=config.server.user,
        port=config.server.port,
        key=config.server.ssh_key,
    )

    ssh = SSHClient(ssh_config, logger)
    service_manager = create_service_manager(config, ssh, logger)

    return logger, ssh, service_manager


@click.group()
@click.option(
    "--config",
    "-c",
    "config_path",
    type=click.Path(),
    help="Path to configuration file (default: deploy.yml)",
)
@click.option("--verbose", "-v", is_flag=True, help="Enable verbose output")
@click.option(
    "--dry-run", is_flag=True, help="Show what would be done without executing"
)
@click.pass_context
def cli(ctx, config_path: Optional[str], verbose: bool, dry_run: bool):
    """minideploy - Simple deployment tool for your VPS."""
    # Ensure context object exists
    if ctx.obj is None:
        ctx.obj = {}

    # Load configuration
    if config_path:
        config_file = Path(config_path)
    else:
        config_file = Path.cwd() / CONFIG_FILE

    try:
        ctx.obj["config"] = load_config(config_file)
    except click.UsageError:
        if ctx.invoked_subcommand != "init":
            raise
        ctx.obj["config"] = None

    ctx.obj["verbose"] = verbose
    ctx.obj["dry_run"] = dry_run
    ctx.obj["project_dir"] = config_file.parent


@cli.command()
@click.option(
    "--regenerate",
    is_flag=True,
    help="Regenerate service configuration (removes existing and recreates)",
)
@click.pass_context
def setup(ctx, regenerate: bool):
    """Setup server for deployment (run once)."""
    config = ctx.obj["config"]
    if not config:
        raise click.UsageError(
            "No configuration file found. Run 'minideploy init' first."
        )

    logger, ssh, service_manager = create_clients(
        config, ctx.obj["verbose"], ctx.obj["dry_run"]
    )

    try:
        setup = ServerSetup(config, ssh, logger, service_manager)
        setup.setup(regenerate=regenerate)
    finally:
        ssh.close()


@cli.command()
@click.option("--force", is_flag=True, help="Force destroy without confirmation")
@click.pass_context
def destroy(ctx, force: bool):
    """Remove all server setup (services and directories)."""
    config = ctx.obj["config"]
    if not config:
        raise click.UsageError("No configuration file found.")

    if not force:
        click.echo("This will permanently remove:")
        click.echo(f"  - Service: {config.app.name}")
        click.echo(f"  - Directory: {config.server.deploy_dir}")
        click.echo("")
        if not click.confirm("Are you sure you want to destroy this deployment?"):
            click.echo("Cancelled.")
            return

    logger, ssh, service_manager = create_clients(
        config, ctx.obj["verbose"], ctx.obj["dry_run"]
    )

    try:
        setup = ServerSetup(config, ssh, logger, service_manager)
        setup.destroy()
    finally:
        ssh.close()


@cli.command()
@click.option("--skip-clean", is_flag=True, help="Skip cleaning previous build")
@click.pass_context
def build(ctx, skip_clean: bool):
    """Build the application locally."""
    config = ctx.obj["config"]
    if not config:
        raise click.UsageError(
            "No configuration file found. Run 'minideploy init' first."
        )

    logger = create_logger(ctx.obj["verbose"], ctx.obj["dry_run"])
    builder = Builder(config, logger, ctx.obj["project_dir"])

    if not skip_clean:
        builder.clean()

    builder.build()


@cli.command()
@click.pass_context
def upload(ctx):
    """Upload build to server."""
    config = ctx.obj["config"]
    if not config:
        raise click.UsageError(
            "No configuration file found. Run 'minideploy init' first."
        )

    logger, ssh, _ = create_clients(config, ctx.obj["verbose"], ctx.obj["dry_run"])

    try:
        build_dir = ctx.obj["project_dir"] / config.build.output_dir
        if not build_dir.exists():
            raise click.UsageError(
                f"Build directory not found: {build_dir}\nRun 'minideploy build' first."
            )

        uploader = Uploader(config, ssh, logger)
        uploader.upload_build(build_dir)

        # Upload env file if specified
        uploader.upload_env_file(ctx.obj["project_dir"])
    finally:
        ssh.close()


@cli.command()
@click.option("--skip-build", is_flag=True, help="Skip build step")
@click.option("--skip-upload", is_flag=True, help="Skip upload step")
@click.option("--release-name", help="Custom release name")
@click.pass_context
def deploy(ctx, skip_build: bool, skip_upload: bool, release_name: Optional[str]):
    """Full deployment (build + upload + deploy)."""
    config = ctx.obj["config"]
    if not config:
        raise click.UsageError(
            "No configuration file found. Run 'minideploy init' first."
        )

    project_dir = ctx.obj["project_dir"]
    logger, ssh, service_manager = create_clients(
        config, ctx.obj["verbose"], ctx.obj["dry_run"]
    )

    try:
        # Build
        if not skip_build:
            builder = Builder(config, logger, project_dir)
            builder.build()

        # Upload
        if not skip_upload:
            build_dir = project_dir / config.build.output_dir
            if not build_dir.exists():
                raise click.UsageError(
                    f"Build directory not found: {build_dir}\n"
                    "Run 'minideploy build' first or use --skip-build."
                )

            uploader = Uploader(config, ssh, logger)
            uploader.upload_build(build_dir)
            uploader.upload_env_file(project_dir)

        # Deploy
        deployer = Deployer(config, ssh, logger, service_manager)

        if not release_name:
            release_name = deployer.generate_release_name()

        deployer.deploy(release_name)

        logger.success(f"Deployment complete! Release: {release_name}")
    finally:
        ssh.close()


@cli.command()
@click.option("--to", "target_release", help="Specific release to rollback to")
@click.pass_context
def rollback(ctx, target_release: Optional[str]):
    """Rollback to previous release."""
    config = ctx.obj["config"]
    if not config:
        raise click.UsageError("No configuration file found.")

    logger, ssh, service_manager = create_clients(
        config, ctx.obj["verbose"], ctx.obj["dry_run"]
    )

    try:
        deployer = Deployer(config, ssh, logger, service_manager)
        deployer.rollback(target_release)
    finally:
        ssh.close()


@cli.command()
@click.pass_context
def status(ctx):
    """Show deployment status."""
    config = ctx.obj["config"]
    if not config:
        raise click.UsageError("No configuration file found.")

    logger, ssh, service_manager = create_clients(
        config, ctx.obj["verbose"], ctx.obj["dry_run"]
    )

    try:
        deployer = Deployer(config, ssh, logger, service_manager)
        deployer.show_status()
    finally:
        ssh.close()


@cli.command()
@click.pass_context
def releases(ctx):
    """List all releases."""
    config = ctx.obj["config"]
    if not config:
        raise click.UsageError("No configuration file found.")

    logger, ssh, service_manager = create_clients(
        config, ctx.obj["verbose"], ctx.obj["dry_run"]
    )

    try:
        deployer = Deployer(config, ssh, logger, service_manager)
        deployer.list_releases_table()
    finally:
        ssh.close()


@cli.command()
@click.pass_context
def cleanup(ctx):
    """Clean up old releases."""
    config = ctx.obj["config"]
    if not config:
        raise click.UsageError("No configuration file found.")

    logger, ssh, service_manager = create_clients(
        config, ctx.obj["verbose"], ctx.obj["dry_run"]
    )

    try:
        deployer = Deployer(config, ssh, logger, service_manager)
        deployer.cleanup_old_releases()
    finally:
        ssh.close()


@cli.command()
@click.option("--instance", "-i", default="1", help="Instance ID")
@click.option("--follow", "-f", is_flag=True, help="Follow log output")
@click.option("--lines", "-n", default=50, help="Number of lines to show")
@click.pass_context
def logs(ctx, instance: str, follow: bool, lines: int):
    """View service logs."""
    config = ctx.obj["config"]
    if not config:
        raise click.UsageError("No configuration file found.")

    logger, ssh, service_manager = create_clients(
        config, ctx.obj["verbose"], ctx.obj["dry_run"]
    )

    try:
        # Find instance config
        instance_config = None
        for inst in config.service.instances:
            if inst.id == instance:
                instance_config = inst
                break

        if not instance_config:
            raise click.UsageError(f"Instance not found: {instance}")

        service_manager.logs(instance_config, follow=follow, lines=lines)
    finally:
        ssh.close()


@cli.command()
@click.option("--instance", "-i", default="1", help="Instance ID")
@click.pass_context
def health(ctx, instance: str):
    """Run health check on an instance."""
    config = ctx.obj["config"]
    if not config:
        raise click.UsageError("No configuration file found.")

    logger, ssh, service_manager = create_clients(
        config, ctx.obj["verbose"], ctx.obj["dry_run"]
    )

    try:
        # Find instance config
        instance_config = None
        for inst in config.service.instances:
            if inst.id == instance:
                instance_config = inst
                break

        if not instance_config:
            raise click.UsageError(f"Instance not found: {instance}")

        deployer = Deployer(config, ssh, logger, service_manager)
        if deployer.health_check(instance_config):
            logger.success("Health check passed")
        else:
            logger.error("Health check failed")
            sys.exit(1)
    finally:
        ssh.close()


@cli.command()
@click.argument("action", type=click.Choice(["start", "stop", "restart", "status"]))
@click.option("--instance", "-i", help="Instance ID (default: all)")
@click.pass_context
def service(ctx, action: str, instance: Optional[str]):
    """Manage services (start, stop, restart, status)."""
    config = ctx.obj["config"]
    if not config:
        raise click.UsageError("No configuration file found.")

    logger, ssh, service_manager = create_clients(
        config, ctx.obj["verbose"], ctx.obj["dry_run"]
    )

    try:
        # Get instances to manage
        if instance:
            instances = [
                inst for inst in config.service.instances if inst.id == instance
            ]
            if not instances:
                raise click.UsageError(f"Instance not found: {instance}")
        else:
            instances = config.service.instances

        # Perform action
        for inst in instances:
            if action == "start":
                service_manager.start(inst)
            elif action == "stop":
                service_manager.stop(inst)
            elif action == "restart":
                service_manager.restart(inst)
            elif action == "status":
                status = service_manager.status(inst)
                logger.info(f"{config.app.name}@{inst.id}: {status}")
    finally:
        ssh.close()


@cli.command()
@click.pass_context
def init(ctx):
    """Initialize a new deploy.yml configuration file."""
    config_path = Path.cwd() / CONFIG_FILE

    if config_path.exists():
        if not click.confirm(f"{CONFIG_FILE} already exists. Overwrite?"):
            return

    sample_config = """# yaml-language-server: $schema=https://raw.githubusercontent.com/yourusername/minideploy/main/schema.json
# minideploy configuration file
# Documentation: https://github.com/yourusername/minideploy

app:
  name: "myapp"
  type: "web"

build:
  type: "custom"
  command: "echo 'Replace with your build command'"
  output_dir: "dist"

server:
  host: "your-server.com"
  user: "deploy"
  deploy_dir: "/opt/myapp"

service:
  type: "systemd"
  instances:
    - id: "1"
      port: 8080
      health_endpoint: "/health"
  systemd_options:
    user: "deploy"
    restart: "always"
    working_directory: "/opt/myapp/current"
    exec_start: "/opt/myapp/current/myapp"
    # Optional: Set environment variables directly
    # environment:
    #   NODE_ENV: "production"
    #   PORT: "8080"
    # Optional: Use an environment file
    # environment_file: "/opt/myapp/.env"

deploy:
  strategy: "rolling"
  keep_releases: 3
  health_check:
    timeout: 30
    retries: 3
    wait_between_instances: 5
"""

    config_path.write_text(sample_config)
    click.echo(f"Created {CONFIG_FILE}")
    click.echo("")
    click.echo("Next steps:")
    click.echo("  1. Edit deploy.yml with your configuration")
    click.echo("  2. Run: minideploy setup")
    click.echo("  3. Run: minideploy deploy")


@cli.command()
@click.pass_context
def ssh(ctx):
    """Open SSH session to server."""
    config = ctx.obj["config"]
    if not config:
        raise click.UsageError("No configuration file found.")

    logger, ssh_client, _ = create_clients(
        config, ctx.obj["verbose"], ctx.obj["dry_run"]
    )

    # For interactive SSH, we still use the system ssh command
    click.echo(f"Connecting to {config.server.host}...")

    import subprocess

    cmd = ["ssh"]
    cmd.extend(["-p", str(config.server.port)])

    if config.server.ssh_key:
        cmd.extend(["-i", str(Path(config.server.ssh_key).expanduser())])

    cmd.append(f"{config.server.user}@{config.server.host}")

    subprocess.run(cmd)


@cli.command()
@click.argument("shell", type=click.Choice(["bash", "zsh", "fish"]))
@click.option("--install", is_flag=True, help="Install completions to shell config")
def completion(shell: str, install: bool):
    """Generate shell completion script for bash, zsh, or fish."""
    import os

    from click.shell_completion import BashComplete, FishComplete, ZshComplete

    # Map shell to completion class and install info
    shell_configs = {
        "bash": {
            "class": BashComplete,
            "install_path": os.path.expanduser("~/.bashrc"),
            "install_cmd": 'eval "$(_MINIDEPLOY_COMPLETE=bash_source minideploy)"',
        },
        "zsh": {
            "class": ZshComplete,
            "install_path": os.path.expanduser("~/.zshrc"),
            "install_cmd": 'eval "$(_MINIDEPLOY_COMPLETE=zsh_source minideploy)"',
        },
        "fish": {
            "class": FishComplete,
            "install_path": os.path.expanduser(
                "~/.config/fish/completions/minideploy.fish"
            ),
            "install_cmd": None,
        },
    }

    config = shell_configs[shell]
    comp = config["class"](cli, {}, "minideploy", "")
    install_path = config["install_path"]
    install_cmd = config["install_cmd"]

    # Generate completion script using Click's API
    completion_script = comp.source()

    if install:
        if shell == "fish":
            # Create directory if needed
            os.makedirs(os.path.dirname(install_path), exist_ok=True)
            Path(install_path).write_text(completion_script)
            click.echo(f"Installed fish completions to: {install_path}")
        else:
            # Append to shell config
            with open(install_path, "a") as f:
                f.write("\n# minideploy completions\n")
                f.write(f"{install_cmd}\n")
            click.echo(f"Added completions to: {install_path}")
            click.echo(f"Run: source {install_path}")
    else:
        # Print completion script
        click.echo(completion_script)


if __name__ == "__main__":
    cli()
