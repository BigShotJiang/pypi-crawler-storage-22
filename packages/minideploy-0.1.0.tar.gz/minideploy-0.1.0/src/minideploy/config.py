"""Configuration models for minideploy."""

from typing import Literal, Optional

from pydantic import BaseModel, Field


class InstanceConfig(BaseModel):
    """Configuration for a service instance."""

    id: str = Field(..., description="Instance identifier")
    port: int = Field(..., description="Port number for health checks")
    health_endpoint: str = Field("/health", description="Health check endpoint")


class SystemdOptions(BaseModel):
    """Systemd-specific options."""

    user: str = Field("deploy", description="User to run service as")
    group: Optional[str] = Field(None, description="Group to run service as")
    restart: str = Field("always", description="Restart policy")
    working_directory: Optional[str] = Field(None, description="Working directory")
    exec_start: str = Field(..., description="Command to execute (use %i for instance)")
    environment_file: Optional[str] = Field(
        None, description="Path to environment file"
    )
    environment: Optional[dict[str, str]] = Field(
        None, description="Environment variables as key-value pairs"
    )
    additional_options: Optional[str] = Field(
        None, description="Additional [Service] options"
    )


class ServiceConfig(BaseModel):
    """Service management configuration."""

    type: Literal["systemd", "docker-compose", "pm2"] = Field(
        "systemd", description="Service manager type"
    )
    instances: list[InstanceConfig] = Field(
        ..., description="List of service instances"
    )
    template: Optional[str] = Field(None, description="Custom template file path")

    # Systemd specific
    systemd_options: Optional[SystemdOptions] = Field(
        None, description="Systemd-specific options"
    )

    # Docker Compose specific
    docker_compose_file: Optional[str] = Field(
        "docker-compose.yml", description="Docker Compose file"
    )

    # PM2 specific
    pm2_config: Optional[str] = Field(
        "ecosystem.config.js", description="PM2 config file"
    )


class BuildConfig(BaseModel):
    """Build configuration."""

    type: Literal["dotnet", "npm", "custom", "docker", "python", "go", "rust"] = Field(
        "custom", description="Build type"
    )
    command: str = Field(..., description="Build command")
    output_dir: str = Field("dist", description="Build output directory")
    env_file: Optional[str] = Field(None, description="Environment file to upload")
    pre_build: Optional[str] = Field(None, description="Pre-build command")
    post_build: Optional[str] = Field(None, description="Post-build command")


class HealthCheckConfig(BaseModel):
    """Health check configuration."""

    timeout: int = Field(30, description="Timeout in seconds")
    retries: int = Field(3, description="Number of retries")
    interval: int = Field(5, description="Interval between retries")
    wait_between_instances: int = Field(
        5, description="Wait time between instance deployments"
    )


class ServerConfig(BaseModel):
    """Server configuration."""

    host: str = Field(..., description="Server hostname or IP")
    user: str = Field("deploy", description="SSH user")
    ssh_key: Optional[str] = Field(None, description="Path to SSH private key")
    port: int = Field(22, description="SSH port")
    deploy_dir: str = Field(..., description="Deployment directory on server")


class DeployConfig(BaseModel):
    """Deployment configuration."""

    strategy: Literal["rolling", "blue-green"] = Field(
        "rolling", description="Deployment strategy"
    )
    health_check: HealthCheckConfig = Field(default_factory=lambda: HealthCheckConfig())
    keep_releases: int = Field(3, description="Number of releases to keep")
    dry_run: bool = Field(
        False, description="Show what would be done without executing"
    )


class AppConfig(BaseModel):
    """Application configuration."""

    name: str = Field(..., description="Application name")
    type: str = Field("custom", description="Application type")


class Config(BaseModel):
    """Main configuration model."""

    app: AppConfig
    build: BuildConfig
    server: ServerConfig
    service: ServiceConfig
    deploy: DeployConfig = Field(default_factory=lambda: DeployConfig())

    @property
    def releases_dir(self) -> str:
        return f"{self.server.deploy_dir}/releases"

    @property
    def uploads_dir(self) -> str:
        return f"{self.server.deploy_dir}/uploads"

    @property
    def current_link(self) -> str:
        return f"{self.server.deploy_dir}/current"
