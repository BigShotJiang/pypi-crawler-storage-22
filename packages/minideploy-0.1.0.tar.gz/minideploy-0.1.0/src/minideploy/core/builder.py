"""Local build operations."""

import subprocess
from pathlib import Path
from minideploy.config import Config
from minideploy.logger import Logger


class Builder:
    """Handles local build operations."""

    def __init__(self, config: Config, logger: Logger, project_dir: Path):
        self.config = config
        self.logger = logger
        self.project_dir = project_dir
        self.build_dir = project_dir / config.build.output_dir

    def _run_command(self, command: str, description: str) -> None:
        """Run a shell command."""
        self.logger.command(command, description)

        try:
            subprocess.run(command, shell=True, check=True, cwd=self.project_dir)
        except subprocess.CalledProcessError as e:
            self.logger.error(f"Command failed: {e}")
            raise

    def clean(self) -> None:
        """Clean previous build directory."""
        if self.build_dir.exists():
            self.logger.info(f"Cleaning build directory: {self.build_dir}")
            import shutil

            shutil.rmtree(self.build_dir)

    def build(self) -> None:
        """Build the application."""
        self.logger.section("Building Application")

        # Run pre-build command if specified
        if self.config.build.pre_build:
            self._run_command(self.config.build.pre_build, "Running pre-build command")

        # Clean previous build
        self.clean()

        # Run build command
        self._run_command(
            self.config.build.command, f"Building {self.config.app.type} application"
        )

        # Verify build output
        if not self.build_dir.exists():
            raise RuntimeError(
                f"Build failed: output directory not found at {self.build_dir}"
            )

        if not any(self.build_dir.iterdir()):
            raise RuntimeError("Build failed: output directory is empty")

        # Get build size

        total_size = sum(
            f.stat().st_size for f in self.build_dir.rglob("*") if f.is_file()
        )
        size_mb = total_size / (1024 * 1024)

        self.logger.success(f"Build completed: {size_mb:.2f} MB")

        # Run post-build command if specified
        if self.config.build.post_build:
            self._run_command(
                self.config.build.post_build, "Running post-build command"
            )

    def get_build_path(self) -> Path:
        """Get the path to the build directory."""
        return self.build_dir
