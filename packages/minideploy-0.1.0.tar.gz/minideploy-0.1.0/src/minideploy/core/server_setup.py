"""Server setup operations."""

from minideploy.config import Config
from minideploy.logger import Logger
from minideploy.services.base import ServiceManager
from minideploy.ssh import SSHClient


class ServerSetup:
    """Handles initial server setup."""

    def __init__(
        self,
        config: Config,
        ssh: SSHClient,
        logger: Logger,
        service_manager: ServiceManager,
    ):
        self.config = config
        self.ssh = ssh
        self.logger = logger
        self.service_manager = service_manager

    def setup(self, regenerate: bool = False) -> None:
        """Run complete server setup.

        Args:
            regenerate: If True, remove existing service and recreate it
        """
        self.logger.section("Server Setup")

        # Test connection
        self.logger.info("Testing SSH connection...")
        if not self.ssh.test_connection():
            raise RuntimeError(f"Cannot connect to {self.config.server.host}")
        self.logger.success("SSH connection successful")

        # Create directory structure
        self.create_directories()

        # If regenerate is True, destroy existing service first
        if regenerate:
            self.logger.warning("Regenerating service configuration...")
            self.service_manager.destroy()

        # Setup service manager
        self.service_manager.setup()

        self.logger.success("Server setup complete!")
        self.logger.info("")
        self.logger.info("Next steps:")
        self.logger.info("  1. Run: minideploy deploy")

    def create_directories(self) -> None:
        """Create deployment directory structure."""
        self.logger.info("Creating directory structure...")

        dirs = [
            self.config.server.deploy_dir,
            self.config.releases_dir,
            self.config.uploads_dir,
        ]

        for dir_path in dirs:
            self.ssh.mkdir(dir_path, parents=True, has_sudo=True)
            self.logger.debug(f"  Created: {dir_path}")

        # Set ownership if specified
        user = self.config.server.user
        self.ssh.run(f"sudo chown -R {user}:{user} {self.config.server.deploy_dir}")

        self.logger.success("Directory structure created")

    def destroy(self) -> None:
        """Remove all server setup (services and directories)."""
        self.logger.section("Destroying Server Setup")

        # Test connection
        self.logger.info("Testing SSH connection...")
        if not self.ssh.test_connection():
            raise RuntimeError(f"Cannot connect to {self.config.server.host}")
        self.logger.success("SSH connection successful")

        # Destroy service manager
        try:
            self.service_manager.destroy()
        except Exception as e:
            self.logger.warning(f"Error destroying services: {e}")

        # Remove deployment directory
        self.logger.info(
            f"Removing deployment directory: {self.config.server.deploy_dir}"
        )
        try:
            self.ssh.run(f"sudo rm -rf {self.config.server.deploy_dir}")
            self.logger.success("Deployment directory removed")
        except Exception as e:
            self.logger.error(f"Failed to remove deployment directory: {e}")
            raise

        self.logger.success("Server setup destroyed successfully!")
        self.logger.info("")
        self.logger.info(
            "All project files and services have been removed from the server."
        )
