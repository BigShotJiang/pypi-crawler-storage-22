"""File upload operations."""

from pathlib import Path
from minideploy.config import Config
from minideploy.ssh import SSHClient
from minideploy.logger import Logger


class Uploader:
    """Handles file uploads to the server."""

    def __init__(self, config: Config, ssh: SSHClient, logger: Logger):
        self.config = config
        self.ssh = ssh
        self.logger = logger

    def upload_build(self, local_build_dir: Path) -> None:
        """Upload build files to the server."""
        self.logger.section("Uploading to Server")

        # Ensure upload directory exists
        self.ssh.mkdir(self.config.uploads_dir, parents=True)

        # Upload via rsync
        self.ssh.upload(str(local_build_dir), self.config.uploads_dir, delete=True)

        # Verify upload
        remote_files = self.ssh.list_dir(self.config.uploads_dir)
        if not remote_files:
            raise RuntimeError("Upload verification failed: no files found on server")

        self.logger.success(f"Upload complete: {len(remote_files)} items uploaded")

    def upload_env_file(self, local_path: Path) -> None:
        """Upload environment file if specified."""
        if not self.config.build.env_file:
            return

        env_path = local_path / self.config.build.env_file
        if not env_path.exists():
            self.logger.warning(f"Environment file not found: {env_path}")
            return

        self.logger.info(f"Uploading environment file: {self.config.build.env_file}")

        # Upload to deploy directory root
        remote_env_path = (
            f"{self.config.server.deploy_dir}/{self.config.build.env_file}"
        )
        self.ssh.upload(str(env_path), remote_env_path, delete=False)

        self.logger.success("Environment file uploaded")
