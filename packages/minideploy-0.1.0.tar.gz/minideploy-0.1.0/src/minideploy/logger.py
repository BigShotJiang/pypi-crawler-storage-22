"""Logging utilities with Rich console output."""

from typing import Optional
from rich.console import Console
from rich.panel import Panel
from rich.text import Text
from rich.progress import Progress, SpinnerColumn, TextColumn

console = Console()


class Logger:
    """Rich-based logger for deployment output."""

    def __init__(self, verbose: bool = False, dry_run: bool = False):
        self.verbose = verbose
        self.dry_run = dry_run

    def info(self, message: str):
        """Log info message."""
        prefix = "[blue][DRY-RUN]" if self.dry_run else "[blue][INFO]"
        console.print(f"{prefix}[/blue] {message}")

    def success(self, message: str):
        """Log success message."""
        console.print(f"[green][SUCCESS][/green] {message}")

    def warning(self, message: str):
        """Log warning message."""
        console.print(f"[yellow][WARNING][/yellow] {message}")

    def error(self, message: str):
        """Log error message."""
        console.print(f"[red][ERROR][/red] {message}")

    def debug(self, message: str):
        """Log debug message (only in verbose mode)."""
        if self.verbose:
            console.print(f"[dim][DEBUG] {message}[/dim]")

    def command(self, cmd: str, description: Optional[str] = None):
        """Log a command that will be executed."""
        if description:
            self.info(description)
        if self.verbose or self.dry_run:
            console.print(f"[dim]  → {cmd}[/dim]")

    def section(self, title: str):
        """Print a section header."""
        console.print()
        console.print(Panel(Text(title, style="bold cyan"), border_style="cyan"))

    def progress(self, description: str):
        """Create a progress context manager."""
        return Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
            transient=True,
        )


def create_logger(verbose: bool = False, dry_run: bool = False) -> Logger:
    """Factory function to create a logger instance."""
    return Logger(verbose=verbose, dry_run=dry_run)
