"""Service manager factory."""

from minideploy.config import Config
from minideploy.ssh import SSHClient
from minideploy.logger import Logger
from minideploy.services.base import ServiceManager
from minideploy.services.systemd import SystemdManager
from minideploy.services.docker_compose import DockerComposeManager
from minideploy.services.pm2 import PM2Manager


def create_service_manager(
    config: Config, ssh: SSHClient, logger: Logger
) -> ServiceManager:
    """Create the appropriate service manager based on configuration."""
    service_type = config.service.type

    if service_type == "systemd":
        return SystemdManager(config, ssh, logger)
    elif service_type == "docker-compose":
        return DockerComposeManager(config, ssh, logger)
    elif service_type == "pm2":
        return PM2Manager(config, ssh, logger)
    else:
        raise ValueError(f"Unknown service type: {service_type}")
