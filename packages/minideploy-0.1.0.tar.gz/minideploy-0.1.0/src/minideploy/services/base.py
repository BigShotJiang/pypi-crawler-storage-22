"""Base service manager interface."""

from abc import ABC, abstractmethod
from minideploy.config import Config, InstanceConfig
from minideploy.ssh import SSHClient
from minideploy.logger import Logger


class ServiceManager(ABC):
    """Abstract base class for service managers."""

    def __init__(self, config: Config, ssh: SSHClient, logger: Logger):
        self.config = config
        self.ssh = ssh
        self.logger = logger

    @abstractmethod
    def setup(self) -> None:
        """Setup service manager on the server (install templates, enable services)."""
        pass

    @abstractmethod
    def start(self, instance: InstanceConfig) -> bool:
        """Start a service instance."""
        pass

    @abstractmethod
    def stop(self, instance: InstanceConfig) -> bool:
        """Stop a service instance."""
        pass

    @abstractmethod
    def restart(self, instance: InstanceConfig) -> bool:
        """Restart a service instance."""
        pass

    @abstractmethod
    def status(self, instance: InstanceConfig) -> str:
        """Get status of a service instance."""
        pass

    @abstractmethod
    def is_active(self, instance: InstanceConfig) -> bool:
        """Check if a service instance is active."""
        pass

    @abstractmethod
    def logs(
        self, instance: InstanceConfig, follow: bool = False, lines: int = 50
    ) -> None:
        """View logs for a service instance."""
        pass

    @abstractmethod
    def generate_config(self) -> str:
        """Generate service configuration file content."""
        pass

    @abstractmethod
    def destroy(self) -> None:
        """Remove service configuration from the server."""
        pass
