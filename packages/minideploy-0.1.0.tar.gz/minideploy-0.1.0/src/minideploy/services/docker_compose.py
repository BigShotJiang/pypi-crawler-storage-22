"""Docker Compose service manager implementation."""

from minideploy.services.base import ServiceManager
from minideploy.config import Config, InstanceConfig
from minideploy.ssh import SSHClient
from minideploy.logger import Logger


class DockerComposeManager(ServiceManager):
    """Docker Compose service manager."""

    def __init__(self, config: Config, ssh: SSHClient, logger: Logger):
        super().__init__(config, ssh, logger)
        self.compose_file = config.service.docker_compose_file or "docker-compose.yml"

    def _get_compose_cmd(self) -> str:
        """Get docker compose command."""
        return f"docker compose -f {self.config.server.deploy_dir}/{self.compose_file}"

    def generate_config(self) -> str:
        """Generate docker-compose.yml content."""
        # TODO: Implement docker-compose.yml generation
        raise NotImplementedError(
            "Docker Compose config generation not yet implemented"
        )

    def setup(self) -> None:
        """Setup Docker Compose on the server."""
        self.logger.section("Setting up Docker Compose")

        # Check if docker is installed
        try:
            self.ssh.run("docker --version", capture=True)
        except:
            self.logger.error("Docker is not installed on the server")
            raise

        # TODO: Generate and upload docker-compose.yml
        self.logger.warning("Docker Compose setup not fully implemented yet")

    def start(self, instance: InstanceConfig) -> bool:
        """Start a service instance."""
        # In docker-compose, we typically start all services together
        # or use profiles/instance names
        self.logger.info("Starting Docker Compose services")

        try:
            self.ssh.run(
                f"cd {self.config.server.deploy_dir} && {self._get_compose_cmd()} up -d"
            )
            return True
        except:
            return False

    def stop(self, instance: InstanceConfig) -> bool:
        """Stop a service instance."""
        try:
            self.ssh.run(
                f"cd {self.config.server.deploy_dir} && {self._get_compose_cmd()} stop"
            )
            return True
        except:
            return False

    def restart(self, instance: InstanceConfig) -> bool:
        """Restart a service instance."""
        try:
            self.ssh.run(
                f"cd {self.config.server.deploy_dir} && {self._get_compose_cmd()} restart"
            )
            return True
        except:
            return False

    def status(self, instance: InstanceConfig) -> str:
        """Get status of a service instance."""
        try:
            result = self.ssh.run(
                f"cd {self.config.server.deploy_dir} && {self._get_compose_cmd()} ps",
                capture=True,
            )
            return "running" if "Up" in result.stdout else "stopped"
        except:
            return "unknown"

    def is_active(self, instance: InstanceConfig) -> bool:
        """Check if a service instance is active."""
        return self.status(instance) == "running"

    def logs(
        self, instance: InstanceConfig, follow: bool = False, lines: int = 50
    ) -> None:
        """View logs for a service instance."""
        cmd = f"cd {self.config.server.deploy_dir} && {self._get_compose_cmd()} logs"

        if follow:
            cmd += " -f"

        cmd += f" --tail={lines}"

        self.ssh.run(cmd, check=False)

    def destroy(self) -> None:
        """Remove Docker Compose services."""
        self.logger.section("Removing Docker Compose Services")

        # Stop and remove containers
        try:
            self.ssh.run(
                f"cd {self.config.server.deploy_dir} && {self._get_compose_cmd()} down"
            )
            self.logger.success("Docker Compose services stopped and removed")
        except Exception as e:
            self.logger.debug(f"Error stopping docker-compose: {e}")

        # Remove docker-compose.yml if it exists
        compose_path = f"{self.config.server.deploy_dir}/{self.compose_file}"
        if self.ssh.exists(compose_path):
            try:
                self.ssh.run(f"rm {compose_path}")
                self.logger.success(f"Removed {self.compose_file}")
            except Exception as e:
                self.logger.error(f"Failed to remove {self.compose_file}: {e}")
