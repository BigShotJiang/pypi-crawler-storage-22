"""PM2 service manager implementation."""

from minideploy.services.base import ServiceManager
from minideploy.config import Config, InstanceConfig
from minideploy.ssh import SSHClient
from minideploy.logger import Logger


class PM2Manager(ServiceManager):
    """PM2 service manager."""

    def __init__(self, config: Config, ssh: SSHClient, logger: Logger):
        super().__init__(config, ssh, logger)
        self.pm2_config = config.service.pm2_config or "ecosystem.config.js"

    def generate_config(self) -> str:
        """Generate PM2 ecosystem config content."""
        # TODO: Implement ecosystem.config.js generation
        raise NotImplementedError("PM2 config generation not yet implemented")

    def setup(self) -> None:
        """Setup PM2 on the server."""
        self.logger.section("Setting up PM2")

        # Check if PM2 is installed
        try:
            self.ssh.run("pm2 --version", capture=True)
        except:
            self.logger.error("PM2 is not installed on the server")
            self.logger.info("Install with: npm install -g pm2")
            raise

        # TODO: Generate and upload ecosystem.config.js
        self.logger.warning("PM2 setup not fully implemented yet")

    def _get_app_name(self, instance: InstanceConfig) -> str:
        """Get PM2 app name for an instance."""
        return f"{self.config.app.name}-{instance.id}"

    def start(self, instance: InstanceConfig) -> bool:
        """Start a service instance."""
        app_name = self._get_app_name(instance)
        self.logger.info(f"Starting PM2 app: {app_name}")

        try:
            self.ssh.run(
                f"cd {self.config.server.deploy_dir} && pm2 start {self.pm2_config} --only {app_name}"
            )
            return True
        except:
            return False

    def stop(self, instance: InstanceConfig) -> bool:
        """Stop a service instance."""
        app_name = self._get_app_name(instance)
        self.logger.info(f"Stopping PM2 app: {app_name}")

        try:
            self.ssh.run(f"pm2 stop {app_name}")
            return True
        except:
            return False

    def restart(self, instance: InstanceConfig) -> bool:
        """Restart a service instance."""
        app_name = self._get_app_name(instance)
        self.logger.info(f"Restarting PM2 app: {app_name}")

        try:
            self.ssh.run(f"pm2 restart {app_name}")
            return True
        except:
            return False

    def status(self, instance: InstanceConfig) -> str:
        """Get status of a service instance."""
        app_name = self._get_app_name(instance)

        try:
            result = self.ssh.run(f"pm2 describe {app_name}", capture=True)
            # Parse PM2 status from output
            if "online" in result.stdout:
                return "active"
            elif "stopped" in result.stdout:
                return "inactive"
            else:
                return "unknown"
        except:
            return "unknown"

    def is_active(self, instance: InstanceConfig) -> bool:
        """Check if a service instance is active."""
        return self.status(instance) == "active"

    def logs(
        self, instance: InstanceConfig, follow: bool = False, lines: int = 50
    ) -> None:
        """View logs for a service instance."""
        app_name = self._get_app_name(instance)
        cmd = f"pm2 logs {app_name} --lines {lines}"

        if follow:
            # PM2 logs command with follow doesn't exit, so we just run it
            pass

        self.ssh.run(cmd, check=False)

    def destroy(self) -> None:
        """Remove PM2 services."""
        self.logger.section("Removing PM2 Services")

        # Stop and delete all app instances
        for instance in self.config.service.instances:
            app_name = self._get_app_name(instance)
            try:
                # Stop the app
                self.ssh.run(f"pm2 stop {app_name}", check=False)
                self.logger.info(f"Stopped PM2 app: {app_name}")

                # Delete the app from PM2
                self.ssh.run(f"pm2 delete {app_name}", check=False)
                self.logger.info(f"Deleted PM2 app: {app_name}")
            except Exception as e:
                self.logger.debug(f"Error stopping/deleting {app_name}: {e}")

        # Save PM2 config
        self.ssh.run("pm2 save", check=False)

        # Remove ecosystem.config.js if it exists
        config_path = f"{self.config.server.deploy_dir}/{self.pm2_config}"
        if self.ssh.exists(config_path):
            try:
                self.ssh.run(f"rm {config_path}")
                self.logger.success(f"Removed {self.pm2_config}")
            except Exception as e:
                self.logger.error(f"Failed to remove {self.pm2_config}: {e}")

        self.logger.success("PM2 services removed successfully")
