"""Systemd service manager implementation."""

from pathlib import Path

from jinja2 import Template

from minideploy.config import Config, InstanceConfig
from minideploy.logger import Logger
from minideploy.services.base import ServiceManager
from minideploy.ssh import SSHClient

DEFAULT_SYSTEMD_TEMPLATE = """[Unit]
Description={{ app_name }} Instance %i
After=network.target

[Service]
Type=simple
User={{ user }}{% if group %}
Group={{ group }}{% endif %}
WorkingDirectory={{ working_directory }}
{% if environment_file %}EnvironmentFile={{ environment_file }}
{% endif %}
{% if environment %}{% for key, value in environment.items() %}Environment="{{ key }}={{ value }}"
{% endfor %}{% endif %}
ExecStart={{ exec_start }}
Restart={{ restart }}
RestartSec=5
{% if additional_options %}{{ additional_options }}
{% endif %}
[Install]
WantedBy=multi-user.target
"""


class SystemdManager(ServiceManager):
    """Systemd service manager."""

    def __init__(self, config: Config, ssh: SSHClient, logger: Logger):
        super().__init__(config, ssh, logger)
        self.service_name = config.app.name
        self.systemd_dir = "/etc/systemd/system"

    def _get_service_file_name(self) -> str:
        """Get the systemd service file name."""
        return f"{self.service_name}@.service"

    def _get_service_file_path(self) -> str:
        """Get the full path to the systemd service file."""
        return f"{self.systemd_dir}/{self._get_service_file_name()}"

    def _get_service_instance_name(self, instance: InstanceConfig) -> str:
        """Get the full service name for an instance."""
        return f"{self.service_name}@{instance.id}"

    def generate_config(self) -> str:
        """Generate systemd service file content."""
        # Load custom template if specified
        if self.config.service.template:
            template_path = Path(self.config.service.template)
            if template_path.exists():
                template_content = template_path.read_text()
            else:
                self.logger.warning(
                    f"Custom template not found: {template_path}, using default"
                )
                template_content = DEFAULT_SYSTEMD_TEMPLATE
        else:
            template_content = DEFAULT_SYSTEMD_TEMPLATE

        template = Template(template_content)

        # Get systemd options
        opts = self.config.service.systemd_options
        if not opts:
            raise ValueError("systemd_options is required for systemd service type")

        # Render template
        context = {
            "app_name": self.config.app.name,
            "user": opts.user,
            "group": opts.group,
            "working_directory": opts.working_directory or self.config.current_link,
            "exec_start": opts.exec_start,
            "restart": opts.restart,
            "environment_file": opts.environment_file,
            "environment": opts.environment,
            "additional_options": opts.additional_options or "",
        }

        return template.render(**context)

    def setup(self) -> None:
        """Setup systemd service on the server."""
        self.logger.section("Setting up Systemd Service")

        # Generate service file content
        service_content = self.generate_config()

        # Write service file to temp location
        temp_file = f"/tmp/{self._get_service_file_name()}"
        self.ssh.write_file(temp_file, service_content)

        # Move to systemd directory with sudo
        self.ssh.run(f"sudo mv {temp_file} {self._get_service_file_path()}")
        self.ssh.run(f"sudo chmod 644 {self._get_service_file_path()}")

        # Reload systemd
        self.ssh.run("sudo systemctl daemon-reload")

        # Enable services for all instances
        for instance in self.config.service.instances:
            service_instance = self._get_service_instance_name(instance)
            self.ssh.run(f"sudo systemctl enable {service_instance}")
            self.logger.success(f"Enabled service: {service_instance}")

        self.logger.success("Systemd service setup complete")

    def start(self, instance: InstanceConfig) -> bool:
        """Start a service instance."""
        service_name = self._get_service_instance_name(instance)
        self.logger.info(f"Starting service: {service_name}")

        try:
            self.ssh.run(f"sudo systemctl start {service_name}")
            return True
        except Exception:
            return False

    def stop(self, instance: InstanceConfig) -> bool:
        """Stop a service instance."""
        service_name = self._get_service_instance_name(instance)
        self.logger.info(f"Stopping service: {service_name}")

        try:
            self.ssh.run(f"sudo systemctl stop {service_name}")
            return True
        except Exception:
            return False

    def restart(self, instance: InstanceConfig) -> bool:
        """Restart a service instance."""
        service_name = self._get_service_instance_name(instance)
        self.logger.info(f"Restarting service: {service_name}")

        try:
            self.ssh.run(f"sudo systemctl restart {service_name}")
            return True
        except Exception:
            return False

    def status(self, instance: InstanceConfig) -> str:
        """Get status of a service instance."""
        service_name = self._get_service_instance_name(instance)

        try:
            result = self.ssh.run(
                f"systemctl is-active {service_name}", capture=True, check=False
            )
            return result.stdout.strip()
        except Exception:
            return "unknown"

    def is_active(self, instance: InstanceConfig) -> bool:
        """Check if a service instance is active."""
        return self.status(instance) == "active"

    def logs(
        self, instance: InstanceConfig, follow: bool = False, lines: int = 50
    ) -> None:
        """View logs for a service instance."""
        service_name = self._get_service_instance_name(instance)
        cmd = f"journalctl -u {service_name} -n {lines}"

        if follow:
            cmd += " -f"

        self.ssh.run(cmd, check=False)

    def destroy(self) -> None:
        """Remove systemd service from the server."""
        self.logger.section("Removing Systemd Service")

        service_file_path = self._get_service_file_path()

        # Check if service file exists
        if not self.ssh.exists(service_file_path):
            self.logger.warning(f"Service file not found: {service_file_path}")
            return

        # Stop and disable all service instances
        for instance in self.config.service.instances:
            service_instance = self._get_service_instance_name(instance)
            try:
                # Stop the service
                self.ssh.run(f"sudo systemctl stop {service_instance}", check=False)
                self.logger.info(f"Stopped service: {service_instance}")

                # Disable the service
                self.ssh.run(f"sudo systemctl disable {service_instance}", check=False)
                self.logger.info(f"Disabled service: {service_instance}")
            except Exception as e:
                self.logger.debug(f"Error stopping/disabling {service_instance}: {e}")

        # Remove service file
        try:
            self.ssh.run(f"sudo rm {service_file_path}")
            self.logger.success(f"Removed service file: {service_file_path}")
        except Exception as e:
            self.logger.error(f"Failed to remove service file: {e}")
            raise

        # Reload systemd
        self.ssh.run("sudo systemctl daemon-reload")
        self.logger.success("Systemd service removed successfully")
