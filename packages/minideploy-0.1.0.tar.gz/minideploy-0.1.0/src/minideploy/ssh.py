"""SSH utilities for remote command execution using Paramiko."""

import shlex
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional

import paramiko
from paramiko import SSHClient as ParamikoSSHClient
from paramiko.ssh_exception import AuthenticationException, SSHException

from minideploy.logger import Logger


@dataclass
class SSHConfig:
    """SSH configuration."""

    host: str
    user: str
    port: int = 22
    key: Optional[str] = None


class SSHClient:
    """SSH client with persistent connections using Paramiko."""

    def __init__(self, config: SSHConfig, logger: Logger):
        self.config = config
        self.logger = logger
        self._client: Optional[ParamikoSSHClient] = None
        self._sftp: Optional[paramiko.SFTPClient] = None
        self._ssh_config: Optional[paramiko.SSHConfig] = None
        self._load_ssh_config()

    def _load_ssh_config(self):
        """Load SSH config from ~/.ssh/config if it exists."""
        ssh_config_path = Path.home() / ".ssh" / "config"
        if ssh_config_path.exists():
            try:
                self._ssh_config = paramiko.SSHConfig()
                with open(ssh_config_path) as f:
                    self._ssh_config.parse(f)
                self.logger.debug(f"Loaded SSH config from {ssh_config_path}")
            except Exception as e:
                self.logger.debug(f"Failed to load SSH config: {e}")
                self._ssh_config = None
        else:
            self._ssh_config = None

    def _resolve_host_config(self) -> dict:
        """Resolve host configuration from SSH config."""
        if self._ssh_config is None:
            return {}

        # Look up the host in SSH config
        host_config = self._ssh_config.lookup(self.config.host)
        return host_config

    def _connect(self) -> ParamikoSSHClient:
        """Establish SSH connection (reuses existing if available)."""
        if self._client is not None:
            # Test if connection is still alive
            try:
                transport = self._client.get_transport()
                if transport and transport.is_active():
                    return self._client
            except Exception:
                pass
            # Connection is dead, close it
            self.close()

        # Resolve host configuration from SSH config
        host_config = self._resolve_host_config()

        # Use values from SSH config if available, otherwise use provided config
        hostname = host_config.get("hostname", self.config.host)
        port = int(host_config.get("port", self.config.port))
        username = host_config.get("user", self.config.user)

        self.logger.debug(f"Connecting to {username}@{hostname}:{port}")

        client = ParamikoSSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

        connect_kwargs = {
            "hostname": hostname,
            "port": port,
            "username": username,
            "timeout": 10,
            "allow_agent": True,
            "look_for_keys": True,
        }

        # Add key if specified in config or SSH config
        key_file = self.config.key
        if not key_file and "identityfile" in host_config:
            # Use first identity file from SSH config
            identity_files = host_config["identityfile"]
            if identity_files:
                key_file = identity_files[0]

        if key_file:
            key_path = Path(key_file).expanduser()
            if key_path.exists():
                connect_kwargs["key_filename"] = str(key_path)
                self.logger.debug(f"Using SSH key: {key_path}")

        try:
            client.connect(**connect_kwargs)
            self._client = client
            return client
        except AuthenticationException:
            self.logger.error(f"Authentication failed for {hostname}")
            raise
        except SSHException as e:
            self.logger.error(f"SSH connection failed: {e}")
            raise

    def _get_sftp(self) -> paramiko.SFTPClient:
        """Get or create SFTP client."""
        if self._sftp is None:
            client = self._connect()
            self._sftp = client.open_sftp()
        return self._sftp

    def close(self):
        """Close SSH and SFTP connections."""
        if self._sftp:
            try:
                self._sftp.close()
            except Exception as e:
                self.logger.debug(f"Failed to close SFTP client: {e}")
            self._sftp = None

        if self._client:
            try:
                self._client.close()
            except Exception as e:
                self.logger.debug(f"Failed to close SSH client: {e}")
            self._client = None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    class CommandResult:
        """Result of a command execution."""

        def __init__(self, returncode: int, stdout: str = "", stderr: str = ""):
            self.returncode = returncode
            self.stdout = stdout
            self.stderr = stderr

    def run(
        self, command: str, check: bool = True, capture: bool = False
    ) -> "SSHClient.CommandResult":
        """Run a command on the remote server."""
        client = self._connect()

        self.logger.debug(f"SSH: {command}")

        try:
            stdin, stdout, stderr = client.exec_command(command)

            if capture:
                # Read output
                stdout_data = stdout.read().decode("utf-8", errors="replace")
                stderr_data = stderr.read().decode("utf-8", errors="replace")
                returncode = stdout.channel.recv_exit_status()

                result = self.CommandResult(returncode, stdout_data, stderr_data)
            else:
                # Stream output in real-time
                import sys

                stdout_data = ""
                stderr_data = ""

                while not stdout.channel.exit_status_ready():
                    # Check for data on stdout
                    if stdout.channel.recv_ready():
                        data = stdout.channel.recv(1024).decode(
                            "utf-8", errors="replace"
                        )
                        stdout_data += data
                        sys.stdout.write(data)
                        sys.stdout.flush()

                    # Check for data on stderr
                    if stdout.channel.recv_stderr_ready():
                        data = stdout.channel.recv_stderr(1024).decode(
                            "utf-8", errors="replace"
                        )
                        stderr_data += data
                        sys.stderr.write(data)
                        sys.stderr.flush()

                # Get final exit status
                returncode = stdout.channel.recv_exit_status()
                result = self.CommandResult(returncode, stdout_data, stderr_data)

            if check and result.returncode != 0:
                raise subprocess.CalledProcessError(
                    result.returncode,
                    command,
                    output=result.stdout,
                    stderr=result.stderr,
                )

            return result

        except SSHException as e:
            self.logger.error(f"SSH command failed: {command}")
            raise subprocess.CalledProcessError(1, command, stderr=str(e))

    def test_connection(self) -> bool:
        """Test SSH connection to server."""
        try:
            result = self.run(
                "echo 'Connection test successful'", check=False, capture=True
            )
            return result.returncode == 0
        except Exception:
            return False

    def upload(self, local_path: str, remote_path: str, delete: bool = True) -> None:
        """Upload files using rsync (uses subprocess for efficiency)."""
        # Resolve hostname from SSH config for rsync
        host_config = self._resolve_host_config()
        hostname = host_config.get("hostname", self.config.host)
        port = int(host_config.get("port", self.config.port))

        cmd = ["rsync", "-avz", "--progress"]

        if delete:
            cmd.append("--delete")

        # Add SSH options to rsync
        ssh_opts = f"-o StrictHostKeyChecking=no -o ConnectTimeout=10 -p {port}"

        # Add key if specified
        key_file = self.config.key
        if not key_file and "identityfile" in host_config:
            identity_files = host_config["identityfile"]
            if identity_files:
                key_file = identity_files[0]

        if key_file:
            key_path = Path(key_file).expanduser()
            if key_path.exists():
                ssh_opts += f" -i {key_path}"

        cmd.extend(["-e", f"ssh {ssh_opts}"])

        # Ensure trailing slash for directory sync
        local = str(Path(local_path).expanduser())
        if Path(local).is_dir() and not local.endswith("/"):
            local += "/"

        target = f"{self.config.user}@{hostname}:{remote_path}"

        cmd.extend([local, target])

        self.logger.command(" ".join(cmd), f"Uploading to {remote_path}")

        try:
            subprocess.run(cmd, check=True)
        except subprocess.CalledProcessError as e:
            self.logger.error(f"Upload failed: {e}")
            raise

    def download(self, remote_path: str, local_path: str) -> None:
        """Download files using rsync (uses subprocess for efficiency)."""
        # Resolve hostname from SSH config for rsync
        host_config = self._resolve_host_config()
        hostname = host_config.get("hostname", self.config.host)
        port = int(host_config.get("port", self.config.port))

        cmd = ["rsync", "-avz", "--progress"]

        # Add SSH options to rsync
        ssh_opts = f"-o StrictHostKeyChecking=no -o ConnectTimeout=10 -p {port}"

        # Add key if specified
        key_file = self.config.key
        if not key_file and "identityfile" in host_config:
            identity_files = host_config["identityfile"]
            if identity_files:
                key_file = identity_files[0]

        if key_file:
            key_path = Path(key_file).expanduser()
            if key_path.exists():
                ssh_opts += f" -i {key_path}"

        cmd.extend(["-e", f"ssh {ssh_opts}"])

        source = f"{self.config.user}@{hostname}:{remote_path}"
        target = str(Path(local_path).expanduser())

        cmd.extend([source, target])

        self.logger.command(" ".join(cmd), f"Downloading from {remote_path}")

        try:
            subprocess.run(cmd, check=True)
        except subprocess.CalledProcessError as e:
            self.logger.error(f"Download failed: {e}")
            raise

    def mkdir(self, path: str, parents: bool = True, has_sudo: bool = False) -> None:
        """Create directory on remote server."""
        flags = "-p" if parents else ""
        sudo = "sudo " if has_sudo else ""
        self.run(f"{sudo}mkdir {flags} {shlex.quote(path)}")

    def exists(self, path: str) -> bool:
        """Check if path exists on remote server."""
        try:
            result = self.run(f"test -e {shlex.quote(path)}", check=False, capture=True)
            return result.returncode == 0
        except Exception:
            return False

    def is_dir(self, path: str) -> bool:
        """Check if path is a directory on remote server."""
        try:
            result = self.run(f"test -d {shlex.quote(path)}", check=False, capture=True)
            return result.returncode == 0
        except Exception:
            return False

    def read_file(self, path: str) -> str:
        """Read file contents from remote server."""
        result = self.run(f"cat {shlex.quote(path)}", capture=True)
        return result.stdout

    def write_file(self, path: str, content: str, sudo: bool = False) -> None:
        """Write file to remote server using SFTP or command."""
        if sudo:
            # For sudo, we need to use a command
            escaped_content = shlex.quote(content)
            self.run(
                f"sudo tee {shlex.quote(path)} > /dev/null << 'EOF'\n{escaped_content}\nEOF"
            )
        else:
            # Use SFTP for better performance
            try:
                sftp = self._get_sftp()
                # Create parent directories if needed
                parent = Path(path).parent
                if str(parent) != "." and str(parent) != "/":
                    try:
                        sftp.stat(str(parent))
                    except FileNotFoundError:
                        self.mkdir(str(parent), parents=True)

                # Write file
                with sftp.file(path, "w") as f:
                    f.write(content)
            except Exception as e:
                self.logger.debug(f"SFTP write failed, falling back to command: {e}")
                # Fallback to command method
                escaped_content = shlex.quote(content)
                self.run(
                    f"tee {shlex.quote(path)} > /dev/null << 'EOF'\n{escaped_content}\nEOF"
                )

    def symlink(self, target: str, link: str, force: bool = False) -> None:
        """Create symlink on remote server."""
        flags = "-sf" if force else "-s"
        self.run(f"ln {flags} {shlex.quote(target)} {shlex.quote(link)}")

    def list_dir(self, path: str) -> List[str]:
        """List directory contents on remote server."""
        result = self.run(f"ls -1 {shlex.quote(path)}", capture=True)
        return [line.strip() for line in result.stdout.split("\n") if line.strip()]

    def remove(self, path: str, recursive: bool = False) -> None:
        """Remove file or directory on remote server."""
        flags = "-r" if recursive else ""
        self.run(f"rm {flags} {shlex.quote(path)}")

    def copy(self, source: str, dest: str, recursive: bool = True) -> None:
        """Copy file or directory on remote server."""
        flags = "-r" if recursive else ""
        self.run(f"cp {flags} {shlex.quote(source)} {shlex.quote(dest)}")
