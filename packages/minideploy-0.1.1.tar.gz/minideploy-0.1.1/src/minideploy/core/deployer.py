"""Deployment operations including release management and health checks."""

import time
from datetime import datetime
from typing import Optional

from minideploy.config import Config, InstanceConfig
from minideploy.logger import Logger
from minideploy.services.base import ServiceManager
from minideploy.ssh import SSHClient


class Deployer:
    """Handles deployment operations."""

    def __init__(
        self,
        config: Config,
        ssh: SSHClient,
        logger: Logger,
        service_manager: ServiceManager,
    ):
        self.config = config
        self.ssh = ssh
        self.logger = logger
        self.service_manager = service_manager

    def generate_release_name(self) -> str:
        """Generate a release name based on timestamp."""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        return f"release_{timestamp}"

    def create_release(self, release_name: str) -> str:
        """Create a new release from uploaded files."""
        self.logger.section(f"Creating Release: {release_name}")

        release_path = f"{self.config.releases_dir}/{release_name}"

        # Ensure releases directory exists
        self.ssh.mkdir(self.config.releases_dir, parents=True)

        # Check if release already exists
        if self.ssh.exists(release_path):
            self.logger.warning(f"Release {release_name} already exists, removing...")
            self.ssh.remove(release_path, recursive=True)

        # Copy uploaded files to release directory
        self.ssh.copy(self.config.uploads_dir, release_path, recursive=True)

        self.logger.success(f"Release created at: {release_path}")
        return release_path

    def get_current_release(self) -> Optional[str]:
        """Get the name of the currently active release."""
        if not self.ssh.exists(self.config.current_link):
            return None

        try:
            result = self.ssh.run(f"readlink {self.config.current_link}", capture=True)
            current_path = result.stdout.strip()
            return current_path.split("/")[-1]
        except Exception:
            return None

    def get_previous_release(self) -> Optional[str]:
        """Get the name of the previous release (before current)."""
        try:
            releases = self.list_releases()
            current = self.get_current_release()

            if not current or len(releases) < 2:
                return None

            # Find current release index
            try:
                current_idx = releases.index(current)
                if current_idx + 1 < len(releases):
                    return releases[current_idx + 1]
            except ValueError:
                pass

            return None
        except Exception:
            return None

    def list_releases(self) -> list[str]:
        """List all releases sorted by date (newest first)."""
        if not self.ssh.exists(self.config.releases_dir):
            return []

        try:
            # List directories and sort by modification time
            result = self.ssh.run(
                f"/bin/ls -t {self.config.releases_dir}", capture=True
            )
            releases = [
                r.strip() for r in result.stdout.strip().split("\n") if r.strip()
            ]
            return releases
        except Exception:
            return []

    def switch_release(self, release_name: str) -> None:
        """Switch current symlink to point to a release."""
        release_path = f"{self.config.releases_dir}/{release_name}"

        if not self.ssh.exists(release_path):
            raise RuntimeError(f"Release not found: {release_name}")

        self.logger.info(f"Switching to release: {release_name}")
        self.ssh.symlink(release_path, self.config.current_link, force=True)
        self.logger.success("Release activated")

    def health_check(self, instance: InstanceConfig) -> bool:
        """Perform health check on an instance."""
        url = f"http://localhost:{instance.port}{instance.health_endpoint}"

        self.logger.info(f"Health check on port {instance.port}")

        retries = self.config.deploy.health_check.retries
        timeout = self.config.deploy.health_check.timeout

        for attempt in range(retries + 1):
            try:
                # Run curl via SSH on the server
                cmd = f"curl -s -w '%{{http_code}}' -o /dev/null --max-time {timeout} {url}"
                result = self.ssh.run(cmd, capture=True)
                status_code = int(result.stdout.strip())

                if status_code == 200:
                    self.logger.success(f"Health check passed on port {instance.port}")
                    return True
                else:
                    self.logger.error(
                        f"Health check failed on port {instance.port}: HTTP {status_code}"
                    )
                    if attempt < retries:
                        time.sleep(1)
                        continue
                    return False
            except (ValueError, Exception) as e:
                if attempt < retries:
                    time.sleep(1)
                    continue
                self.logger.error(f"Health check failed on port {instance.port}: {e}")
                return False

        return False

    def deploy_instance(self, instance: InstanceConfig, release_name: str) -> bool:
        """Deploy to a single instance with health check."""
        instance_id = instance.id

        self.logger.info(f"Deploying to instance {instance_id}")

        # Restart service
        if not self.service_manager.restart(instance):
            self.logger.error(f"Failed to restart instance {instance_id}")
            return False

        # Wait for service to start
        wait_time = self.config.deploy.health_check.wait_between_instances
        self.logger.info(f"Waiting {wait_time}s for service to start...")
        time.sleep(wait_time)

        # Health check
        if not self.health_check(instance):
            self.logger.error(f"Health check failed for instance {instance_id}")
            return False

        self.logger.success(f"Instance {instance_id} deployed successfully")
        return True

    def deploy(self, release_name: str) -> None:
        """Execute full deployment."""
        self.logger.section("Deploying Application")

        # Get current release for potential rollback
        previous_release = self.get_current_release()
        if previous_release:
            self.logger.info(f"Previous release: {previous_release}")

        # Create new release
        self.create_release(release_name)

        # Switch current symlink
        self.switch_release(release_name)

        # Deploy instances one by one
        for i, instance in enumerate(self.config.service.instances):
            if not self.deploy_instance(instance, release_name):
                # Deployment failed, attempt rollback
                self.logger.error(f"Deployment failed on instance {instance.id}")

                if previous_release:
                    self.logger.warning("Attempting rollback...")
                    self.rollback(previous_release)

                raise RuntimeError(f"Deployment failed on instance {instance.id}")

            # Wait before deploying next instance (except for the last one)
            if i < len(self.config.service.instances) - 1:
                wait_time = self.config.deploy.health_check.wait_between_instances
                self.logger.info(f"Waiting {wait_time}s before next instance...")
                time.sleep(wait_time)

        self.logger.success("All instances deployed successfully")

        # Cleanup old releases
        self.cleanup_old_releases()

    def rollback(self, target_release: Optional[str] = None) -> None:
        """Rollback to a previous release."""
        self.logger.section("Rolling Back Deployment")

        if not target_release:
            target_release = self.get_previous_release()

        if not target_release:
            raise RuntimeError("No previous release found for rollback")

        current = self.get_current_release()
        self.logger.info(f"Rolling back from: {current}")
        self.logger.info(f"Rolling back to: {target_release}")

        # Switch symlink
        self.switch_release(target_release)

        # Restart all instances
        for instance in self.config.service.instances:
            if not self.service_manager.restart(instance):
                raise RuntimeError(
                    f"Failed to restart instance {instance.id} during rollback"
                )

            time.sleep(self.config.deploy.health_check.wait_between_instances)

        # Verify rollback with health checks
        for instance in self.config.service.instances:
            if not self.health_check(instance):
                raise RuntimeError("Health check failed after rollback")

        self.logger.success(f"Rollback to {target_release} completed successfully")

    def cleanup_old_releases(self) -> None:
        """Remove old releases, keeping only the most recent ones."""
        keep = self.config.deploy.keep_releases

        releases = self.list_releases()

        if len(releases) <= keep:
            self.logger.debug("No old releases to clean up")
            return

        self.logger.info(f"Cleaning up old releases (keeping {keep})...")

        # Keep the most recent releases
        releases_to_remove = releases[keep:]

        for release in releases_to_remove:
            release_path = f"{self.config.releases_dir}/{release}"
            self.ssh.remove(release_path, recursive=True)
            self.logger.info(f"  Removed: {release}")

        self.logger.success(f"Cleaned up {len(releases_to_remove)} old releases")

    def show_status(self) -> None:
        """Show current deployment status."""
        self.logger.section("Deployment Status")

        current = self.get_current_release()
        previous = self.get_previous_release()

        if current:
            self.logger.info(f"Current release: {current}")
        else:
            self.logger.warning("No active deployment")

        if previous:
            self.logger.info(f"Previous release: {previous} (available for rollback)")

        self.logger.info("")
        self.logger.info("Service status:")

        for instance in self.config.service.instances:
            status = self.service_manager.status(instance)

            if status == "active":
                self.logger.success(f"  {self.config.app.name}@{instance.id}: {status}")
            elif status == "inactive":
                self.logger.warning(f"  {self.config.app.name}@{instance.id}: {status}")
            else:
                self.logger.error(f"  {self.config.app.name}@{instance.id}: {status}")

    def list_releases_table(self) -> None:
        """Display releases in a table format."""
        from rich.table import Table

        self.logger.section("Available Releases")

        releases = self.list_releases()
        current = self.get_current_release()

        if not releases:
            self.logger.warning("No releases found")
            return

        table = Table(show_header=True, header_style="bold magenta")
        table.add_column("Release")
        table.add_column("Date")
        table.add_column("Status")

        for release in releases:
            # Get release date from directory modification time
            try:
                result = self.ssh.run(
                    f"stat -c %y {self.config.releases_dir}/{release}", capture=True
                )
                date_str = result.stdout.strip()[:19]  # Get YYYY-MM-DD HH:MM:SS
            except Exception:
                date_str = "unknown"

            status = "[green]current[/green]" if release == current else ""
            table.add_row(release, date_str, status)

        from minideploy.logger import console

        console.print(table)
