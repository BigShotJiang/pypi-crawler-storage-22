#pragma once
#include <libremidi/config.hpp>

namespace libremidi
{

struct winuwp_input_configuration
{
};

struct winuwp_output_configuration
{
};

struct winuwp_observer_configuration
{
};

}
