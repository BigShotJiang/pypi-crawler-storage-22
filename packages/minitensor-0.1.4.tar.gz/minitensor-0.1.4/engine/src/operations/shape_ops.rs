// Copyright (c) 2026 Soumyadip Sarkar.
// All rights reserved.
//
// This source code is licensed under the Apache-style license found in the
// LICENSE file in the root directory of this source tree.

include!("shape_ops/reshape.rs");
include!("shape_ops/indexing.rs");
