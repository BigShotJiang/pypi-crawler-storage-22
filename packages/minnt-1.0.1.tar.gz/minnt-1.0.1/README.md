# Minnt

<img src="https://minnt.org/images/leaf-green-noborder.svg" alt="" align="right" width="150">

**Minnt** is <s>**Mi**lan's</s> **Mi**nimalistic **N**eural **N**etwork **T**rainer for PyTorch inspired by Keras.

Read the [documentation](https://minnt.org/).

See the [examples](https://minnt.org/examples/).

Install using:
```
pip install minnt --extra-index-url=https://download.pytorch.org/whl/cu128 torch torchvision
```
