# Multi-prompt Instruction Proposal Optimizer

Automated prompt optimization for language models.

Under active development. See [github.com/synth-laboratories/mipro](https://github.com/synth-laboratories/mipro).
