
def suma(x, y):
  resultado = x + y
  return resultado

def resta(x,y):
  resultado = x - y
  return resultado
