
from mis_operaciones.calculadora import suma, resta

def test_suma():
  resultado = suma(2,3)
  assert resultado == 5

def test_resta():
  resultado = resta(3,2)
  assert resultado == 1
