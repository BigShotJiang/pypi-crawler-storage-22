import enum
import typing as t


class PreserveCaseStrEnum(enum.StrEnum):
    """
    StrEnum with auto-values: member name copy.

    class StatusEnum(PreserveCaseStrEnum):
         ok = auto()       # StatusEnum.ok.value == "ok"
         FAILED = auto( )  # StatusEnum.FAILED.value == "FAILED"
         Unknown = auto()  # StatusEnum.Unknown.value == "Unknown"
    """

    @staticmethod
    def _generate_next_value_(
        name: str,
        start: int,
        count: int,
        last_values: list[t.Any],
    ) -> str:
        return name


class LowerCaseStrEnum(enum.StrEnum):
    """
    StrEnum with auto-values: member name after lowercase().

    class StatusEnum(LowerCaseStrEnum):
         ok = auto()       # StatusEnum.ok.value == "ok"
         FAILED = auto( )  # StatusEnum.FAILED.value == "failed"
         Unknown = auto()  # StatusEnum.Unknown.value == "unknown"
    """

    @staticmethod
    def _generate_next_value_(
        name: str,
        start: int,
        count: int,
        last_values: list[t.Any],
    ) -> str:
        return name.lower()


class UpperCaseStrEnum(enum.StrEnum):
    """
    StrEnum with auto-values: member name after lowercase().

    class StatusEnum(UpperCaseStrEnum):
         ok = auto()       # StatusEnum.ok.value == "OK"
         FAILED = auto( )  # StatusEnum.FAILED.value == "FAILED"
         Unknown = auto()  # StatusEnum.Unknown.value == "UNKNOWN"
    """

    @staticmethod
    def _generate_next_value_(
        name: str,
        start: int,
        count: int,
        last_values: list[t.Any],
    ) -> str:
        return name.upper()
