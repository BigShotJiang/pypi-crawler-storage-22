import typing as t

from miska import strings


class MISSING:
    __LABELED = {}

    def __new__(cls, label: str | None = None) -> t.Self:
        key = (cls, label)
        inst = cls.__LABELED.get(key)
        if inst is None:
            inst = super().__new__(cls)
            cls.__LABELED[key] = inst
        return inst

    def __init__(self, label: str | None = None) -> None:
        if label is None:
            pass
        elif not label:
            raise ValueError(f"label must be non-empty string: {label!r}")
        self.label = label

    def __repr__(self):
        return strings.to_repr(self, args=repr(self.label))

    def __str__(self):
        cls_name = strings.clsqualname(self)
        if self.label:
            return f"{cls_name}[{self.label}]"
        return cls_name

    def __bool__(self) -> bool:
        return False


def is_missing(obj: t.Any, label: str | None = None) -> bool:
    if label:
        return isinstance(obj, MISSING) and obj.label == label

    if isinstance(obj, type):
        return issubclass(obj, MISSING)

    return isinstance(obj, MISSING)
