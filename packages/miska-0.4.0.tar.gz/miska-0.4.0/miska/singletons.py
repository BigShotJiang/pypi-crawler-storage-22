import abc
import typing as t


class Singleton(type):
    __instances = {}

    def __call__(cls, *args, **kwargs) -> t.Self:
        if cls not in cls.__instances:
            cls.__instances[cls] = super().__call__(*args, **kwargs)
        return cls.__instances[cls]


class SingletonForAbstract(Singleton, abc.ABCMeta):
    pass
