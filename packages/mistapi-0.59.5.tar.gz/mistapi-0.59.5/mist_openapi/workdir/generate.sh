#!/bin/sh
ts=`date "+%s"`
echo "backuping src"
cp ./openapi.yaml ./openapi.yaml.$ts.bak

# echo "removing spotlight entries"
# python3 ./a0_remove_xtags.py
# sleep 1

echo "processing files"
python3 ./a1_process.py
#mv ./openapi_reordered.yaml ./openapi.yaml
sleep 1

echo "yaml to postman conversion"
rm ../mist.postman.*
openapi2postmanv2 -s ../mist.openapi.yaml -o ../mist.postman.json -p -O enableOptionalParameters=false,includeAuthInfoInExample=false
sleep 1

echo "Postman post-process"
python3 ./a2_postman_postprocess.py
sleep 1

echo "Adding custom tags"
python3 ./a3_doc_xtags.py
sleep 1

echo "Checking Response Accept Header"
python3 ./a6_check_response_header.py
sleep 1

echo "Setting missing Additional Properties attributes"
python3 ./a7_additionalProperties.py
sleep 1

# This must be done at the end because the openapi-generator tool
# is not able to handle the size of the OAS when using YAML format, 
# so the validation is done on the JSON version of the OAS.
echo "Validating OAS"
openapi-generator validate -i ../mist.openapi.json