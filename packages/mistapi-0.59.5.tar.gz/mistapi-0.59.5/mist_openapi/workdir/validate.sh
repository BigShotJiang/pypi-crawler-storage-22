openapi-generator validate -i ./openapi.yaml

