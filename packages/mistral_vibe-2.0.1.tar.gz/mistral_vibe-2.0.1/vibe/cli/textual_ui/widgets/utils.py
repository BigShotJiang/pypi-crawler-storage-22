from __future__ import annotations

TOOL_SHORTCUTS = {"todo": "ctrl+t"}
DEFAULT_TOOL_SHORTCUT = "ctrl+o"
