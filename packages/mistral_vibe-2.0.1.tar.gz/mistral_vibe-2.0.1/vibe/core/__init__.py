from __future__ import annotations

__all__ = ["run_programmatic"]

from vibe.core.programmatic import run_programmatic
