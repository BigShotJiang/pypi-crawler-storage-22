import os
import platform
import shutil
import stat
from pathlib import Path
import urllib.request
import zipfile
import subprocess
from migate.config import (
    console
)

SYSTEM = platform.system()

def make_executable(path):
    if SYSTEM in ["Linux", "Darwin"]:
        try:
            st = os.stat(path)
            os.chmod(path, st.st_mode | stat.S_IEXEC)
        except Exception as e:
            console.print(f"\n[orange]Warning: Could not make {path} executable: {e}[/orange]\n")


def config_termux():
    try:
        config_file = Path.home() / '.termux' / 'termux.properties'
        config_file.parent.mkdir(parents=True, exist_ok=True)
        
        existing_content = ""
        if config_file.exists():
            existing_content = config_file.read_text(encoding='utf-8')
        
        if "allow-external-apps = true" not in existing_content:
            with open(config_file, 'a', encoding='utf-8') as f:
                f.write("\nallow-external-apps = true\n")
            subprocess.run(['termux-reload-settings'], check=False)
        
        result = subprocess.run(
            ["cmd", "package", "list", "packages", "--user", "0", "com.termux.api"],
            capture_output=True,
            text=True
        )
        
        if "package:com.termux.api" not in result.stdout:
            return {"error": "com.termux.api app is not installed! Download it from https://github.com/termux/termux-api/releases/latest first and run miunlock again after installation"}
        
        PREFIX = os.environ.get('PREFIX', '/data/data/com.termux/files/usr')
        fastboot_path = f"{PREFIX}/bin/termux-fastboot"
        
        if not os.path.isfile(fastboot_path):
            return {"error": "Platform-tools (without root) is not installed! Please install it frist from the repo: https://github.com/nohajc/termux-adb."}
        else:
            make_executable(fastboot_path)
            return {"path": fastboot_path}
        
    except Exception as e:
        return {"error": f"Termux configuration error: {str(e)}"}


def download_platform_tools():
    system_map = {
        "Linux": "linux",
        "Darwin": "darwin",
        "Windows": "windows"
    }
    
    os_name = system_map.get(SYSTEM)
    if not os_name:
        return {"error": f"Unsupported operating system: {SYSTEM}"}
    
    url = f"https://dl.google.com/android/repository/platform-tools-latest-{os_name}.zip"
    tools_dir = Path.home() / "platform-tools"
    zip_path = tools_dir.parent / "platform-tools.zip"
    
    console.print(f"\n[white]Downloading platform-tools for {os_name} from {url} ...[/white]\n")
    
    try:
        tools_dir.parent.mkdir(parents=True, exist_ok=True)
        urllib.request.urlretrieve(url, str(zip_path))
        
        console.print(f"\n[white]Extracting platform-tools...[/white]\n")
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(str(tools_dir.parent))
        
        zip_path.unlink()
        
        fastboot_path = tools_dir / "fastboot"
        if SYSTEM == "Windows":
            fastboot_path = tools_dir / "fastboot.exe"
        
        if not fastboot_path.exists():
            return {"error": "Fastboot binary not found after extraction"}
        
        make_executable(str(fastboot_path))
        return {"path": str(fastboot_path)}
        
    except urllib.error.URLError as e:
        return {"error": f"Download failed: {str(e)}"}
    except zipfile.BadZipFile:
        return {"error": "Downloaded file is corrupted"}
    except Exception as e:
        return {"error": f"Failed to download platform-tools: {str(e)}"}


def config_s():
    try:
        if SYSTEM == "Linux" and os.path.exists("/data/data/com.termux"):
            return config_termux()
        
        cmd = shutil.which("fastboot")
        if cmd is not None:
            make_executable(cmd)
            return {"path": cmd}
        
        tools_dir = Path.home() / "platform-tools"
        fastboot_path = tools_dir / "fastboot"
        
        if SYSTEM == "Windows":
            fastboot_path = tools_dir / "fastboot.exe"
        
        if fastboot_path.exists():
            make_executable(str(fastboot_path))
            return {"path": str(fastboot_path)}
        
        console.print(f'\n[orange]fastboot is not installed![/orange]\n')
        return download_platform_tools()
        
    except Exception as e:
        return {"error": f"Error checking fastboot: {str(e)}"}