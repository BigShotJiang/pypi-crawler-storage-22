# Changelog

## [0.1.3](https://github.com/MiViA-GmbH/MiViA-API-py/compare/mivia-v0.1.2...mivia-v0.1.3) (2026-01-29)


### Features

* add proxy support via MIVIA_PROXY env var and --proxy CLI option ([898760d](https://github.com/MiViA-GmbH/MiViA-API-py/commit/898760d3fbecef6dbf6e850824f1c07457ddf45c))
* initial commit ([362d736](https://github.com/MiViA-GmbH/MiViA-API-py/commit/362d7366937bd7464dfa5696018631f03df546ef))


### Bug Fixes

* resolve ruff lint and format issues in CLI ([dc54cd5](https://github.com/MiViA-GmbH/MiViA-API-py/commit/dc54cd5510dfb02259b5f8910748d46b4ffe862c))

## Changelog
