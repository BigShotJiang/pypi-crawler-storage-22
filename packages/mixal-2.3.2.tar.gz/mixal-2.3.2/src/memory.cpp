#include <stdexcept>
#include <string>
#include <iostream>
#include "memory.h"
#include "unicode_char.h"

namespace mixal {

uint16_t CHAR_CODES[] = {
    ' ', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I',
    0xb4, 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R',
    0x2da, 0x2dd, 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z',
    '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
    '.', ',', '(', ')', '+', '-', '*', '/', '=', '$',
    '<', '>', '@', ';', ':', 0x201a
};

bool ComputerWord::operator==(const ComputerWord& word) const {
    return negative == word.negative && byte1 == word.byte1 &&
           byte2 == word.byte2 && byte3 == word.byte3 &&
           byte4 == word.byte4 && byte5 == word.byte5;
}

std::ostream& operator<<(std::ostream& out, const ComputerWord& word) {
    out << (word.negative ? '-' : '+');
    for (int i = 1; i <= 5; ++i) {
        out << ' ' << static_cast<int>(word[i]);
    }
    return out;
}

ComputerWord::ComputerWord() : negative(), byte1(), byte2(), byte3(), byte4(), byte5() {
}

ComputerWord::ComputerWord(const int32_t value) : negative(), byte1(), byte2(), byte3(), byte4(), byte5() {
    set(value);
}

ComputerWord::ComputerWord(const std::string& chars) : negative(), byte1(), byte2(), byte3(), byte4(), byte5() {
    set(chars);
}

ComputerWord::ComputerWord(const bool _negative,
    const uint8_t _byte1, const uint8_t _byte2, const uint8_t _byte3, const uint8_t _byte4, const uint8_t _byte5) :
    negative(_negative), byte1(_byte1), byte2(_byte2), byte3(_byte3), byte4(_byte4), byte5(_byte5) {
}

ComputerWord::ComputerWord(const char sign, const uint8_t _byte1, const uint8_t _byte2, const uint8_t _byte3, const uint8_t _byte4, const uint8_t _byte5) :
    negative(sign == '-'), byte1(_byte1), byte2(_byte2), byte3(_byte3), byte4(_byte4), byte5(_byte5) {
    if (sign != '+' && sign != '-') {
        throw std::runtime_error("Invalid sign: " + std::string(1, sign));
    }
}

ComputerWord::ComputerWord(const bool _negative, const uint16_t bytes12, const uint8_t _byte3, const uint8_t _byte4, const uint8_t _byte5) :
    negative(_negative), byte1(bytes12 / 64), byte2(bytes12 % 64), byte3(_byte3), byte4(_byte4), byte5(_byte5) {
}

ComputerWord::ComputerWord(const char sign, const uint16_t bytes12, const uint8_t _byte3, const uint8_t _byte4, const uint8_t _byte5) :
    negative(sign == '-'), byte1(bytes12 / 64), byte2(bytes12 % 64), byte3(_byte3), byte4(_byte4), byte5(_byte5) {
    if (sign != '+' && sign != '-') {
        throw std::runtime_error("Invalid sign: " + std::string(1, sign));
    }
}

void ComputerWord::reset() {
    negative = false;
    byte1 = byte2 = byte3 = byte4 = byte5 = 0;
}

std::string ComputerWord::getBytesString() const {
    std::string result;
    result += negative ? '-' : '+';
    for (int i = 1; i <= 5; ++i) {
        result += ' ';
        if ((*this)[i] < 10) {
            result += ' ';
        }
        result += std::to_string((*this)[i]);
    }
    return result;
}

uint8_t ComputerWord::operator[](const int index) const {
    if (index <= 0 || index > 5) {
        throw std::runtime_error("Invalid index for a word: " + std::to_string(index));
    }
    switch (index) {
    case 1: return byte1;
    case 2: return byte2;
    case 3: return byte3;
    case 4: return byte4;
    default: return byte5;
    }
}

uint8_t& ComputerWord::operator[](const int index) {
    if (index <= 0 || index > 5) {
        throw std::runtime_error("Invalid index for a word: " + std::to_string(index));
    }
    switch (index) {
    case 1: return byte1;
    case 2: return byte2;
    case 3: return byte3;
    case 4: return byte4;
    default: return byte5;
    }
}

uint16_t ComputerWord::bytes2(const int index1, const int index2) const {
    const int16_t high = (*this)[index1];
    const int16_t low = (*this)[index2];
    return high * 64 + low;
}

uint16_t ComputerWord::bytes12() const {
    return bytes2(1, 2);
}

uint16_t ComputerWord::bytes23() const {
    return bytes2(2, 3);
}

uint16_t ComputerWord::bytes34() const {
    return bytes2(3, 4);
}

uint16_t ComputerWord::bytes45() const {
    return bytes2(4, 5);
}

int32_t ComputerWord::value() const {
    const int32_t value = (byte1 << 24) | (byte2 << 18) | (byte3 << 12) | (byte4 << 6) | static_cast<int32_t>(byte5);
    return negative ? -value : value;
}

double ComputerWord::floatValue() const {
    const int32_t exp = byte1;
    const uint32_t fraction = (static_cast<uint32_t>(byte2) << 18) |
                              (static_cast<uint32_t>(byte3) << 12) |
                              (static_cast<uint32_t>(byte4) << 6) |
                              static_cast<uint32_t>(byte5);
    if (fraction == 0) {
        return 0.0;
    }
    const double value = static_cast<double>(fraction) * std::pow(64.0, exp - ComputerWord::MIX_FLOAT_BIAS - 4);
    return negative ? -value : value;
}

int16_t ComputerWord::addressValue() const {
    auto value = static_cast<int16_t>(this->bytes12());
    if (negative) {
        value = -value;
    }
    return value;
}

void ComputerWord::setAddress(int16_t address) {
    negative = false;
    if (address < 0) {
        negative = true;
        address = -address;
    }
    byte1 = static_cast<uint8_t>(address / 64);
    byte2 = static_cast<uint8_t>(address % 64);
}

void ComputerWord::setAddress(const bool _negative, const uint16_t address) {
    this->negative = _negative;
    byte1 = static_cast<uint8_t>(address / 64);
    byte2 = static_cast<uint8_t>(address % 64);
}

std::string ComputerWord::getCharacters() const {
    std::string chars;
    for (int i = 1; i <= 5; ++i) {
        if (getAt(i) < CHAR_CODES_NUM) {
            const uint16_t code = CHAR_CODES[getAt(i)];
            chars += unicode::toUTF8(code);
        } else {
            chars += ' ';
        }
    }
    return chars;
}

void ComputerWord::set(int32_t value) {
    if (value > 0) {
        negative = false;
    } else if (value < 0) {
        negative = true;
        value = -value;
    }
    for (int i = 5; i >= 1; --i) {
        set(i, static_cast<uint8_t>(value & ((1 << 6) - 1)));
        value >>= 6;
    }
}

bool ComputerWord::set(double value) {
    bool overflow = false;
    reset();
    if (value == 0.0) {
        return overflow;
    }
    if (value < 0.0) {
        negative = true;
        value = -value;
    }
    int32_t exp = MIX_FLOAT_BIAS;
    constexpr double MIN_FRAC = 64.0 * 64.0 * 64.0;
    constexpr double MAX_FRAC = 64.0 * 64.0 * 64.0 * 64.0;
    double fraction = value * MAX_FRAC;
    while (fraction >= MAX_FRAC && exp < 63) {
        fraction /= 64;
        ++exp;
    }
    while (fraction < MIN_FRAC && exp > 0) {
        fraction *= 64;
        --exp;
    }
    if (fraction >= MAX_FRAC) {
        exp = 63;
        fraction = MAX_FRAC - 1;
        overflow = true;
    }
    if (fraction < 1.0) {
        fraction = 0.0;
        overflow = true;
    }
    const auto frac = static_cast<uint32_t>(std::round(fraction));
    byte1 = static_cast<uint8_t>(exp);
    byte2 = static_cast<uint8_t>((frac >> 18) & 0b00111111);
    byte3 = static_cast<uint8_t>((frac >> 12) & 0b00111111);
    byte4 = static_cast<uint8_t>((frac >> 6) & 0b00111111);
    byte5 = static_cast<uint8_t>(frac & 0b00111111);
    return overflow;
}

void ComputerWord::set(const std::string& chars) {
    const auto codes = unicode::fromUTF8(chars);
    if (codes.size() != 5) {
        throw std::runtime_error("Invalid length of characters for a word: " + chars);
    }
    negative = false;
    for (int i = 0; i < 5; ++i) {
        (*this)[i + 1] = 0;
        for (int j = 0; j < CHAR_CODES_NUM; ++j) {
            if (static_cast<uint16_t>(codes[i]) == CHAR_CODES[j]) {
                (*this)[i + 1] = j;
                break;
            }
        }
    }
}

void ComputerWord::set(const int index, const uint8_t val) {
    if (index <= 0 || index > 5) {
        throw std::runtime_error("Invalid index for a word: " + std::to_string(index));
    }
    switch (index) {
    case 1: byte1 = val; break;
    case 2: byte2 = val; break;
    case 3: byte3 = val; break;
    case 4: byte4 = val; break;
    default: byte5 = val;
    }
}

void ComputerWord::set(const bool _negative, const uint8_t _byte1, const uint8_t _byte2, const uint8_t _byte3, const uint8_t _byte4, const uint8_t _byte5) {
    this->negative = _negative;
    this->byte1 = _byte1;
    this->byte2 = _byte2;
    this->byte3 = _byte3;
    this->byte4 = _byte4;
    this->byte5 = _byte5;
}

void ComputerWord::set(const char sign, const uint8_t _byte1, const uint8_t _byte2, const uint8_t _byte3, const uint8_t _byte4, const uint8_t _byte5) {
    if (sign != '+' && sign != '-') {
        throw std::runtime_error("Invalid sign: " + std::string(1, sign));
    }
    this->negative = sign == '-';
    this->byte1 = _byte1;
    this->byte2 = _byte2;
    this->byte3 = _byte3;
    this->byte4 = _byte4;
    this->byte5 = _byte5;
}

void ComputerWord::set(const bool _negative, const uint16_t bytes12, const uint8_t _byte3, const uint8_t _byte4, const uint8_t _byte5) {
    this->negative = _negative;
    this->byte1 = static_cast<uint8_t>(bytes12 / 64);
    this->byte2 = static_cast<uint8_t>(bytes12 % 64);
    this->byte3 = _byte3;
    this->byte4 = _byte4;
    this->byte5 = _byte5;
}

void ComputerWord::set(const char sign, const uint16_t bytes12, const uint8_t _byte3, const uint8_t _byte4, const uint8_t _byte5) {
    if (sign != '+' && sign != '-') {
        throw std::runtime_error("Invalid sign: " + std::string(1, sign));
    }
    this->negative = sign == '-';
    this->byte1 = static_cast<uint8_t>(bytes12 / 64);
    this->byte2 = static_cast<uint8_t>(bytes12 % 64);
    this->byte3 = _byte3;
    this->byte4 = _byte4;
    this->byte5 = _byte5;
}

}  // namespace mixal
