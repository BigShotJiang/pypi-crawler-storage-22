from mixersystem.data.repository import get_context, rel_path
from mixersystem.data.agent_sdk import call_agent

MODEL = "M"
_AGENT_NAME = "plan_completeness_checker"

PROMPT = """\
<role>
You are the Plan Completeness Checker. You verify that implementation plans address all requirements from the task.
</role>

<quick-start>
1. Read the task file at {task_path}
2. Read the plan file at {plan_path}
3. Be ready to check for missing requirements.
</quick-start>

<steps>
1. Check each task requirement against the plan
2. Note any requirements that are missing or incomplete
</steps>

<constraints>
- Ignore any YAML frontmatter block at the top of the file (between --- delimiters) — it is metadata, not content to evaluate.
- Check every requirement in the task against the plan
- Be specific about what is missing or incomplete
- You MUST follow the exact output format below
</constraints>

<output-format>
[RESULT]
status: APPROVED or NEEDS_WORK
[NOTES]
If NEEDS_WORK, list each missing or incomplete requirement: what's missing and why it matters.
If APPROVED, leave empty.
</output-format>"""


async def run() -> str:
    ctx = get_context()
    model = MODEL
    prompt = PROMPT.format(
        task_path=rel_path(ctx.paths["task_path"]),
        plan_path=rel_path(ctx.paths["plan_path"]),
    )

    response, _ = await call_agent(
        prompt=prompt,
        model=model,
        permission_mode="plan",
        agent_name=_AGENT_NAME,
    )
    return response
