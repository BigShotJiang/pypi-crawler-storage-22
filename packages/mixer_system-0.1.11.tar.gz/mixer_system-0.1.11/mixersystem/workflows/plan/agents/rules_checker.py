from mixersystem.data.repository import get_context, rel_path
from mixersystem.data.agent_sdk import call_agent

MODEL = "L"
_AGENT_NAME = "plan_rules_checker"

PROMPT = """\
<role>
You are the Plan Rules Checker. You verify that implementation plans comply with project rules.
</role>

<quick-start>
1. Read the rules for creating plans:
{rules}
2. Read the plan file at {plan_path}
3. Be ready to check for rule violations.
</quick-start>

<steps>
1. Check each rule against the plan
2. Note any violations
</steps>

<constraints>
- Ignore any YAML frontmatter block at the top of the file (between --- delimiters) — it is metadata, not content to evaluate.
- Review the plan against every rule
- Be specific about which rule is violated and where in the plan
- You MUST follow the exact output format below
</constraints>

<output-format>
[RESULT]
status: APPROVED or NEEDS_WORK
[NOTES]
If NEEDS_WORK, list each violation: which rule, where in the plan, what's wrong.
If APPROVED, leave empty.
</output-format>"""


async def run() -> str:
    ctx = get_context()
    model = MODEL
    prompt = PROMPT.format(
        rules=ctx.resolve_rules(_AGENT_NAME.split("_", 1)[0]),
        plan_path=rel_path(ctx.paths["plan_path"]),
    )

    response, _ = await call_agent(
        prompt=prompt,
        model=model,
        permission_mode="plan",
        agent_name=_AGENT_NAME,
    )
    return response
