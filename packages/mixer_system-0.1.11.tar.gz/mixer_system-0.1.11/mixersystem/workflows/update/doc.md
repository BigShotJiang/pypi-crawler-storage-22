---
name: update
---
# Update Workflow

The update workflow reads `work.md` and the project's existing `doc.md` files, then produces `update.md` — concrete suggestions for what documentation should change based on the completed work.

## Inputs

- `work_folder` (required) — must contain `work.md`.
- `instructions` — optional free-text guidance injected into the builder's prompt.

## Orchestration

The orchestrator (`create_update.py`) is straightforward — it calls the builder once. No loops or sub-agents.

## Agents

**Builder** (`builder.py`, model L) — analyzes what changed in the work report, compares against existing `doc.md` files, and suggests specific updates. Each suggestion references a concrete `doc.md` path, explains what to change, and includes the suggested markdown content. Only suggests changes that reflect actual completed work — no invented additions.
