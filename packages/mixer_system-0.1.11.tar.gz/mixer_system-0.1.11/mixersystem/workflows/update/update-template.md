# Documentation Updates

## Summary

[1-2 sentences. What changed and which docs need updating.]

## Updates

### `[path/to/doc.md]`

**What to change:** [Description of what to add, remove, or modify and why.]

```markdown
[Suggested new/updated content for this section]
```

---

[Repeat for each doc.md that needs updating]
