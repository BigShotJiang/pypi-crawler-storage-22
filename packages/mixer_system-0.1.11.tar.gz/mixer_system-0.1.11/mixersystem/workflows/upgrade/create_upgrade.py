from pathlib import Path

from mixersystem.data.repository import context_scope, get_context, update_frontmatter
from mixersystem.workflows.upgrade import builder


async def run(work_folder: str, test_mode: bool = False,
              depth: int | None = None,
              instructions: str | None = None) -> None:
    """Analyze agent logs and suggest rule upgrades."""
    with context_scope(
        work_folder=str(Path(work_folder).resolve()),
        test_mode=test_mode,
        depth=depth,
    ):
        await builder.run(instructions=instructions)

        ctx = get_context()
        update_frontmatter(ctx.paths["upgrade_path"], test_mode=ctx.test_mode)


if __name__ == "__main__":
    from mixersystem.data.repository import run_cli
    run_cli(run)
