---
name: upgrade
---
# Upgrade Workflow

The upgrade workflow reads all logs from the work folder and the project's existing rules, then produces `upgrade.md` — suggestions for rule improvements based on generalizable patterns found in the logs.

## Inputs

- `work_folder` (required) — must contain `logs/` with agent log files.
- `instructions` — optional free-text guidance injected into the builder's prompt.

## Orchestration

The orchestrator (`create_upgrade.py`) is straightforward — it calls the builder once. No loops or sub-agents.

## Agents

**Builder** (`builder.py`, model L) — reads all log files (`agent_trace.log`, `agent_raw.log`, `conversation.log`) and mines them for generalizable lessons across four categories:

- **Corrections** — errors that were fixed ("should have done X instead").
- **Warnings** — things to avoid ("be careful with", "watch out for").
- **Patterns** — reusable instructions ("always do X", "never do Y").
- **Discoveries** — insights learned ("it turns out that", "the fix is").

Each suggestion maps to a specific rule file path (`.mixer/rules/<action>/<module>.md`), includes the log source quote that drove it, and provides concrete rule text. The builder checks existing rules to avoid duplication and filters out task-specific details — only general lessons make it through.
