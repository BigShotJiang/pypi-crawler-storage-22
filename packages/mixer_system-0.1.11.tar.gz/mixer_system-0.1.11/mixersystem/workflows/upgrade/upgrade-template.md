# Rules Upgrade Suggestions

## Summary

[1-2 sentences. What lessons were analyzed and which rule files are affected.]

## Upgrades

### `.mixer/rules/[action]/[module].md`

**Log source:** [Which log entry/entries drove this suggestion — quote the relevant text]

**What to change:** [Description of what rule to add, modify, or remove and why.]

```markdown
[Suggested rule content]
```

---

[Repeat for each rules file that needs upgrading]
