import sys
import unittest
from pathlib import Path
from unittest.mock import patch

from mixersystem.data.repository import get_context, run_cli


class RepositoryCLITest(unittest.TestCase):
    def test_depth_is_ignored_for_workflow_with_work_folder_param(self) -> None:
        captured = {"work_folder": None, "test_mode": None}

        async def dummy_run(work_folder: str, test_mode: bool = False):
            captured["work_folder"] = work_folder
            captured["test_mode"] = test_mode
            return None

        argv = [
            "prog",
            "--work_folder=./tasks/test-depth-strip",
            "--depth=7",
            "--test_mode=true",
        ]
        with patch.object(sys, "argv", argv):
            run_cli(dummy_run)

        self.assertIsNotNone(captured["work_folder"])
        self.assertTrue(str(captured["work_folder"]).endswith("tasks/test-depth-strip"))
        self.assertEqual(captured["test_mode"], True)

    def test_depth_is_ignored_for_internal_context_scope_branch(self) -> None:
        captured = {"depth": None, "work_folder": None}

        async def dummy_run_no_work_folder():
            ctx = get_context()
            captured["depth"] = ctx.depth
            captured["work_folder"] = ctx.work_folder
            return None

        argv = [
            "prog",
            "--work_folder=./tasks/test-depth-internal",
            "--depth=99",
        ]
        with patch.object(sys, "argv", argv):
            run_cli(dummy_run_no_work_folder)

        self.assertEqual(captured["depth"], 0)
        self.assertIsNotNone(captured["work_folder"])
        self.assertTrue(Path(captured["work_folder"]).name == "test-depth-internal")


if __name__ == "__main__":
    unittest.main()
