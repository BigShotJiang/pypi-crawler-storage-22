import json
import unittest
from pathlib import Path
from tempfile import TemporaryDirectory

from mixersystem.sync import PACKAGE_DIR, sync


def _write_doc(path: Path, name: str, content: str = "") -> None:
    """Create a doc.md with name frontmatter."""
    path.parent.mkdir(parents=True, exist_ok=True)
    body = content or f"# {name}\n"
    path.write_text(f"---\nname: {name}\n---\n{body}")


class SyncSettingsTest(unittest.TestCase):
    def test_sync_creates_linear_block_defaults(self) -> None:
        with TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            _write_doc(root / "app" / "doc.md", "app")

            sync(project_root=tmpdir)

            settings = json.loads((root / ".mixer" / "settings.json").read_text())
            self.assertIn("modules", settings)
            self.assertIn("app", settings["modules"])
            self.assertEqual(settings["modules"]["app"]["doc"], "./app/doc.md")
            self.assertIn("children", settings["modules"]["app"])
            self.assertEqual(settings["linear"]["team_prefix"], "")
            self.assertEqual(settings["linear"]["team_id"], "")

    def test_sync_preserves_existing_linear_values(self) -> None:
        with TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            _write_doc(root / "app" / "doc.md", "app")
            (root / ".mixer").mkdir(parents=True, exist_ok=True)

            existing = {
                "modules": {},
                "linear": {
                    "team_prefix": "ENG",
                    "team_id": "team_123",
                    "extra": "keep-me",
                },
                "custom": {"x": 1},
            }
            (root / ".mixer" / "settings.json").write_text(json.dumps(existing, indent=2) + "\n")

            sync(project_root=tmpdir)

            settings = json.loads((root / ".mixer" / "settings.json").read_text())
            self.assertEqual(settings["linear"]["team_prefix"], "ENG")
            self.assertEqual(settings["linear"]["team_id"], "team_123")
            self.assertEqual(settings["linear"]["extra"], "keep-me")
            self.assertEqual(settings["custom"]["x"], 1)
            self.assertIn("app", settings["modules"])

    def test_sync_builds_hierarchical_tree(self) -> None:
        with TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            _write_doc(root / "app" / "doc.md", "app")
            _write_doc(root / "app" / "cli" / "doc.md", "cli")
            _write_doc(root / "app" / "generator" / "doc.md", "generator")

            sync(project_root=tmpdir)

            settings = json.loads((root / ".mixer" / "settings.json").read_text())
            app = settings["modules"]["app"]
            self.assertEqual(app["doc"], "./app/doc.md")
            self.assertIn("cli", app["children"])
            self.assertIn("generator", app["children"])
            self.assertEqual(app["children"]["cli"]["doc"], "./app/cli/doc.md")
            self.assertEqual(app["children"]["generator"]["doc"], "./app/generator/doc.md")

    def test_sync_nodes_have_only_doc_and_children(self) -> None:
        with TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            _write_doc(root / "app" / "doc.md", "app")

            sync(project_root=tmpdir)

            settings = json.loads((root / ".mixer" / "settings.json").read_text())
            app = settings["modules"]["app"]
            self.assertEqual(set(app.keys()), {"doc", "children"})

    def test_sync_raises_on_duplicate_names(self) -> None:
        with TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            _write_doc(root / "app" / "doc.md", "mymod")
            _write_doc(root / "lib" / "doc.md", "mymod")

            with self.assertRaises(ValueError) as ctx:
                sync(project_root=tmpdir)
            self.assertIn("Duplicate module name", str(ctx.exception))

    def test_sync_skips_doc_without_name(self) -> None:
        with TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            # doc.md with name
            _write_doc(root / "app" / "doc.md", "app")
            # doc.md without frontmatter
            (root / "lib").mkdir(parents=True, exist_ok=True)
            (root / "lib" / "doc.md").write_text("# No frontmatter\n")

            sync(project_root=tmpdir)

            settings = json.loads((root / ".mixer" / "settings.json").read_text())
            self.assertIn("app", settings["modules"])
            self.assertNotIn("lib", settings["modules"])

    def test_sync_raises_when_no_modules_found(self) -> None:
        with TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            (root / "app").mkdir(parents=True, exist_ok=True)
            (root / "app" / "doc.md").write_text("# No frontmatter\n")

            with self.assertRaises(FileNotFoundError):
                sync(project_root=tmpdir)


    def test_sync_preserves_user_added_module_keys(self) -> None:
        """User-added keys on module entries must survive re-sync."""
        with TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            _write_doc(root / "app" / "doc.md", "app")
            _write_doc(root / "app" / "cli" / "doc.md", "cli")
            (root / ".mixer").mkdir(parents=True, exist_ok=True)

            existing = {
                "modules": {
                    "app": {
                        "doc": "./app/doc.md",
                        "children": {
                            "cli": {
                                "doc": "./app/cli/doc.md",
                                "children": {},
                                "user_note": "keep me",
                            }
                        },
                        "custom_flag": True,
                    }
                },
                "linear": {"team_prefix": "ENG", "team_id": "t1"},
            }
            (root / ".mixer" / "settings.json").write_text(
                json.dumps(existing, indent=2) + "\n"
            )

            sync(project_root=tmpdir)

            settings = json.loads((root / ".mixer" / "settings.json").read_text())
            app = settings["modules"]["app"]
            self.assertTrue(app["custom_flag"])
            self.assertEqual(app["children"]["cli"]["user_note"], "keep me")

    def test_sync_does_not_remove_modules_missing_from_scan(self) -> None:
        """Modules in settings.json that are no longer on disk should be kept."""
        with TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            _write_doc(root / "app" / "doc.md", "app")
            (root / ".mixer").mkdir(parents=True, exist_ok=True)

            existing = {
                "modules": {
                    "app": {"doc": "./app/doc.md", "children": {}},
                    "old_module": {"doc": "./old/doc.md", "children": {}},
                },
                "linear": {"team_prefix": "", "team_id": ""},
            }
            (root / ".mixer" / "settings.json").write_text(
                json.dumps(existing, indent=2) + "\n"
            )

            sync(project_root=tmpdir)

            settings = json.loads((root / ".mixer" / "settings.json").read_text())
            self.assertIn("app", settings["modules"])
            self.assertIn("old_module", settings["modules"])


if __name__ == "__main__":
    unittest.main()
