import asyncio
import random
import shutil
from pathlib import Path

from mixersystem.data.repository import context_scope, get_context, parse_result, update_frontmatter
from mixersystem.workflows.plan import plan_builder as builder
from mixersystem.workflows.plan.agents import plan_merger as merger
from mixersystem.workflows.plan.agents import plan_formatter as formatter
from mixersystem.workflows.plan.agents import plan_rules_checker as rules_checker
from mixersystem.workflows.plan.agents import plan_completeness_checker as completeness_checker

MAX_REVISIONS = 2
_CONCRETE_PROVIDERS = ["claude", "gemini", "codex"]
_SUPPORTED_PROVIDERS = {*_CONCRETE_PROVIDERS, "random"}


def _resolve_provider(provider: str) -> str:
    """Resolve provider name, picking randomly if 'random'."""
    if provider == "random":
        return random.choice(_CONCRETE_PROVIDERS)
    return provider


def _alpha_suffix(index: int) -> str:
    if 0 <= index < 26:
        return chr(ord("a") + index)
    return f"{index + 1:02d}"


def _prepare_branches(work_folder: str, branch_count: int) -> list[str]:
    """Create branch work folders and copy root task.md into each."""
    root = Path(work_folder)
    task_path = root / "task.md"
    if not task_path.is_file():
        raise FileNotFoundError(f"Missing task file: {task_path}")
    if branch_count < 2:
        raise ValueError("branch_count must be >= 2 when preparing branches")

    branches_root = root / "branches"
    branch_folders = []
    for i in range(branch_count):
        branch = branches_root / f"plan_{_alpha_suffix(i)}"
        branch.mkdir(parents=True, exist_ok=True)
        shutil.copy2(task_path, branch / "task.md")
        plan_path = branch / "plan.md"
        if plan_path.exists():
            plan_path.unlink()
        branch_folders.append(str(branch.resolve()))
    return branch_folders


async def _build_branch(branch_work_folder: str, provider: str,
                        instructions: str | None = None) -> str:
    """Run plan builder in a branch work folder and return branch plan path."""
    with context_scope(work_folder=branch_work_folder):
        await builder.run(provider=provider, instructions=instructions)
        return str(Path(branch_work_folder) / "plan.md")


def _stamp_plan_frontmatter(*, provider: str, branch_count: int,
                             max_revisions: int) -> None:
    """Stamp YAML frontmatter on plan.md with workflow parameters."""
    ctx = get_context()
    update_frontmatter(
        ctx.paths["plan_path"],
        mock=ctx.mock,
        plan_builder_provider=provider,
        branch_count=branch_count,
        max_revisions=max_revisions,
    )


async def _review() -> str:
    """Review a plan. Runs all checkers concurrently and aggregates results."""
    ctx = get_context()
    has_task = Path(ctx.paths["task_path"]).is_file()

    coros = [rules_checker.run()]
    check_names = ["rules"]
    if has_task:
        coros.append(completeness_checker.run())
        check_names.append("completeness")

    results = await asyncio.gather(*coros)

    checks = list(zip(check_names, results))

    issues = []
    for name, raw in checks:
        result = parse_result(raw)
        if result.passed:
            continue
        detail = (result.notes or raw).strip() or "No details provided."
        issues.append(f"[{name}] {detail}")

    if issues:
        notes = "\n\n".join(issues)
        return f"[RESULT]\nstatus: NEEDS_WORK\n[NOTES]\n{notes}"

    return "[RESULT]\nstatus: APPROVED\n[NOTES]\n"


# --- Orchestration ---

async def run(work_folder: str, mock: bool = False,
              depth: int | None = None,
              plan_builder_provider: str = "claude",
              branch_count: int = 1,
              max_revisions: int = MAX_REVISIONS,
              instructions: str | None = None) -> None:
    """Build a plan, run review/revision cycles, and format the final output."""
    if branch_count < 1:
        raise ValueError("branch_count must be >= 1")
    if max_revisions < 0:
        raise ValueError("max_revisions must be >= 0")
    if plan_builder_provider not in _SUPPORTED_PROVIDERS:
        allowed = ", ".join(sorted(_SUPPORTED_PROVIDERS))
        raise ValueError(
            f"Unsupported plan_builder_provider: {plan_builder_provider}. "
            f"Supported providers: {allowed}."
        )

    resolved_provider = _resolve_provider(plan_builder_provider)

    wf = Path(work_folder)
    wf.mkdir(parents=True, exist_ok=True)

    with context_scope(
        work_folder=str(wf.resolve()),
        mock=mock,
        depth=depth,
    ):
        # Build (single branch) or build branches + merger feedback + builder
        if branch_count == 1:
            session_id = await builder.run(provider=resolved_provider,
                                           instructions=instructions)
        else:
            branch_folders = _prepare_branches(get_context().work_folder, branch_count)
            # When original input is "random", each branch picks independently.
            if plan_builder_provider == "random":
                branch_providers = [_resolve_provider("random") for _ in branch_folders]
            else:
                branch_providers = [resolved_provider] * len(branch_folders)
            branch_plan_paths = await asyncio.gather(
                *(_build_branch(folder, bp, instructions=instructions)
                  for folder, bp in zip(branch_folders, branch_providers))
            )
            merger_response = await merger.run(
                branch_plan_paths=branch_plan_paths,
            )
            merger_feedback = parse_result(merger_response).notes or merger_response
            session_id = await builder.run(
                provider=resolved_provider,
                merger_feedback=merger_feedback,
                instructions=instructions,
            )

        _stamp_plan_frontmatter(
            provider=resolved_provider,
            branch_count=branch_count,
            max_revisions=max_revisions,
        )

        # Review loop: each NEEDS_WORK triggers a revision. After max cycles, accept final draft.
        for _ in range(max_revisions):
            review_result = await _review()
            result = parse_result(review_result)

            if result.passed:
                break

            feedback = result.notes or review_result
            session_id = await builder.run_resume(
                feedback=feedback,
                session_id=session_id,
                provider=resolved_provider,
            )

            _stamp_plan_frontmatter(
                provider=resolved_provider,
                branch_count=branch_count,
                max_revisions=max_revisions,
            )

        await formatter.run()

        _stamp_plan_frontmatter(
            provider=resolved_provider,
            branch_count=branch_count,
            max_revisions=max_revisions,
        )


if __name__ == "__main__":
    from mixersystem.data.repository import run_cli
    run_cli(run)
