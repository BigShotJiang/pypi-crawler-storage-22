---
name: <max-4-word-kebab>
modules: all
---

# <Title>

<What needs to be done. Just write it.>

<!-- appendix -->
<ignore>

<!-- Brainstorming questions, context gathering notes, open questions explored during task creation -->

</ignore>
