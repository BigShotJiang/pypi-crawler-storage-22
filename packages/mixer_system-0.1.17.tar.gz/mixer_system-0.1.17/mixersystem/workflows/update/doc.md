---
name: update
---
# Update Workflow

The update workflow reads `work.md` and the project's existing `doc.md` files, applies documentation updates directly, and produces `update.md` — a report of what was changed.

## Inputs

- `work_folder` (required) — should typically contain `work.md`.
- `instructions` — optional free-text guidance injected into the builder's prompt.

## Orchestration

The orchestrator (`create_update.py`) is straightforward — it calls the builder once. No loops or sub-agents.

## Agents

**Builder** (`update_builder.py`, model L) — analyzes what changed in the work report, compares against existing `doc.md` files, and edits them directly to reflect the completed work. Writes `update.md` as a report listing every `doc.md` file changed and why. Only applies changes that reflect actual completed work — no invented additions.
