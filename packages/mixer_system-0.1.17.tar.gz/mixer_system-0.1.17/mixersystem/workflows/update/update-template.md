# Documentation Updates

## What Changed

- `[path/to/doc.md]` — [what changed and why, one line]

<!-- appendix -->
<ignore>

<!-- Doc coverage analysis, review notes -->

</ignore>
