from pathlib import Path

from mixersystem.data.repository import context_scope, get_context, update_frontmatter
from mixersystem.workflows.upgrade import upgrade_builder as builder


async def run(work_folder: str, mock: bool = False,
              depth: int | None = None,
              instructions: str | None = None) -> None:
    """Analyze agent logs and apply rule upgrades."""
    wf = Path(work_folder)
    wf.mkdir(parents=True, exist_ok=True)

    with context_scope(
        work_folder=str(wf.resolve()),
        mock=mock,
        depth=depth,
    ):
        await builder.run(instructions=instructions)

        ctx = get_context()
        update_frontmatter(ctx.paths["upgrade_path"], mock=ctx.mock)


if __name__ == "__main__":
    from mixersystem.data.repository import run_cli
    run_cli(run)
