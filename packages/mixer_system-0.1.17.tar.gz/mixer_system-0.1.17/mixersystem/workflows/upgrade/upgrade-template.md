# Rules Upgrade

## What Changed

- `.mixer/rules/[action]/[module].md` — [what changed and why, one line]

<!-- appendix -->
<ignore>

<!-- Log analysis notes, pattern candidates considered but rejected -->

</ignore>
