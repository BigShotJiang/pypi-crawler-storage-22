# Work: [Task Title]

## What Changed

- `[path/to/file]` — [what changed and why, one line]
- `[path/to/file]` — [what changed and why, one line]

## Revision History

### Run [N/M]

- **Changes**: [what was done in this run]
- **Checks**: [internal checks ran and outcome]
- **Issues**: [any deviation or issue discovered and what was done about it]

<!-- appendix -->
<ignore>

<!-- Implementation notes, debugging logs, internal discoveries -->

</ignore>
