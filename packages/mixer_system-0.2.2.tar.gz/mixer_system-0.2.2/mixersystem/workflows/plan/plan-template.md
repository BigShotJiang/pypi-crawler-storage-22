# Plan: [Task Title]

## Summary

[2-3 sentences. What we're doing, how, what approach.]

## Decisions

- **[Decision]** — [Why. What's non-obvious. What alternative was rejected.]
- **[Decision]** — [...]

## Files

- `[path/to/file]` — [what and why, one line]
- `[path/to/file]` — [what and why, one line]

## Implementation Order

1. `[path/to/file]` — [why first]
2. `[path/to/file]` — [depends on #1]

## Verification

1. [Step or command]
2. [Expected behavior]
