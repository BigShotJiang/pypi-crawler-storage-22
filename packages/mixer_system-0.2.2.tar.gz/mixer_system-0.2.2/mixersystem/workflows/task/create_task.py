from pathlib import Path

from mixersystem.data.repository import context_scope, init_session, update_session_run
from mixersystem.workflows.task import task_builder as builder


async def run(session_folder: str, lite: bool = False,
              depth: int | None = None,
              instructions: str | None = None) -> None:
    """Create task.md from instructions."""
    wf = Path(session_folder)
    wf.mkdir(parents=True, exist_ok=True)
    init_session(str(wf.resolve()))

    with context_scope(
        session_folder=str(wf.resolve()),
        lite=lite,
        depth=depth,
    ):
        update_session_run(str(wf.resolve()), "task", lite=lite)
        await builder.run(instructions=instructions)


if __name__ == "__main__":
    from mixersystem.data.repository import run_cli
    run_cli(run)
