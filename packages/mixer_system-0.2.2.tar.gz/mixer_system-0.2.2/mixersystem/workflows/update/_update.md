# Update Workflow

The update workflow reads `work.md` and the project's existing module doc files (`_name.md`), applies documentation updates directly, and produces `update.md` — a report of what was changed.

## Inputs

- `session_folder` (required) — should typically contain `work.md`.
- `instructions` — optional free-text guidance injected into the builder's prompt.

## Orchestration

The orchestrator (`create_update.py`) is straightforward — it calls the builder once. No loops or sub-agents.

## Agents

**Builder** (`update_builder.py`, model L) — analyzes what changed in the work report, compares against existing module doc files (`_name.md`), and edits them directly to reflect the completed work. Writes `update.md` as a report listing every module doc file changed and why. Only applies changes that reflect actual completed work — no invented additions.
