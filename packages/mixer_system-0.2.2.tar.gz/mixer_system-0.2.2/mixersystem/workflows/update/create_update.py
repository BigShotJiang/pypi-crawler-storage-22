from pathlib import Path

from mixersystem.data.repository import context_scope, get_context, update_session_run
from mixersystem.workflows.update import update_builder as builder


async def run(session_folder: str, lite: bool = False,
              depth: int | None = None,
              instructions: str | None = None) -> None:
    """Analyze work.md and apply documentation updates."""
    wf = Path(session_folder)
    wf.mkdir(parents=True, exist_ok=True)

    with context_scope(
        session_folder=str(wf.resolve()),
        lite=lite,
        depth=depth,
    ):
        update_session_run(str(wf.resolve()), "update", lite=lite)
        await builder.run(instructions=instructions)


if __name__ == "__main__":
    from mixersystem.data.repository import run_cli
    run_cli(run)
