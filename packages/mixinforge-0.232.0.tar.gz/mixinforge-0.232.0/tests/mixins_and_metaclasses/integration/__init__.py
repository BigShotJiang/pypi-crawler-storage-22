"""Integration tests for mixin composition.

This package contains tests that verify multiple mixins work correctly
when combined in a single class hierarchy.
"""
