Compare Module
==============

.. automodule:: mixref.compare
   :members:
   :undoc-members:
   :show-inheritance:
