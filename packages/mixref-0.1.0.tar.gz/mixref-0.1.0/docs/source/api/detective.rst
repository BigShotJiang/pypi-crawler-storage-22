Detective Module
================

.. automodule:: mixref.detective
   :members:
   :undoc-members:
   :show-inheritance:
