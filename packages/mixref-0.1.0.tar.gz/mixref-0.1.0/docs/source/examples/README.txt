mixref Examples Gallery
=======================

Welcome to the mixref examples gallery! These examples show real-world
usage patterns for music producers.

All examples use synthetic audio - no real tracks needed to run them.
