"""mixref - CLI Audio Analyzer for Music Producers."""

__version__ = "0.1.0"
