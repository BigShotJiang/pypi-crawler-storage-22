Audio Module
============

Main audio module for loading and validating audio files.

.. currentmodule:: mixref.audio

Functions
---------

.. autofunction:: load_audio

Submodules
----------

.. toctree::
   :maxdepth: 1

   loader
   validation
