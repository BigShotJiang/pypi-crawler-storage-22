"""
Audio Loading
=============

Examples of loading and handling audio files.
"""
