"""mixref - CLI Audio Analyzer for Music Producers."""

__version__ = "0.2.0"
