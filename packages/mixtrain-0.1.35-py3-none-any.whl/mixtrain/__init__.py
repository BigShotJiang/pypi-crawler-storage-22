"""Mixtrain SDK - ML Platform Client and Workflow Framework."""

import importlib.metadata
from typing import Literal, TypedDict

__version__ = importlib.metadata.version("mixtrain")

# GPU types supported by the platform
GpuType = Literal[
    "T4", "L4", "A10", "A100", "A100-80GB", "L40S", "H100", "H200", "B200"
]
CloudProvider = Literal["gcp", "aws"]


class Sandbox(TypedDict, total=False):
    """Sandbox configuration for model/workflow runs.

    Must match backend SandboxConfig schema.
    """

    image: str  # Docker image URL
    gpu: GpuType  # GPU type
    cpu: int  # CPU cores
    memory: int  # Memory in MB
    timeout: int  # Max execution time in seconds
    idle_timeout: int  # Idle timeout in seconds
    cloud: CloudProvider  # Cloud provider
    region: str  # Cloud region
    ephemeral_disk: int  # Ephemeral disk in GB
    block_network: bool  # Block network access
    num_nodes: int  # Nodes for distributed training
    mixtrain_version: str  # SDK version


from .client import MixClient, MixFlow, MixModel, sandbox
from .datasets import Dataset, get_dataset, list_datasets
from .evaluations import Eval, get_eval, list_evals
from .files import FileInfo, Files, UploadDirResult, UploadError

# Utilities for workflows
from .helpers import (
    generate_name,
    validate_resource_name,
)

# Proxy classes for resources (lazy API access)
from .models import Model, get_model, list_models
from .result import BatchResult, ModelResult, RunStatus
from .routers import Router, get_router, list_routers

# Media and text types (explicit wrappers for outputs)
from .types import (
    JSON,
    Audio,
    Embedding,
    File,
    Image,
    MCAP,
    Markdown,
    MixType,
    Model3D,
    Rerun,
    Text,
    Video,
    deserialize_output,
    extract_output_schema,
    serialize_output,
)
from .workflows import Workflow, get_workflow, list_workflows

__all__ = [
    # Version
    "__version__",
    # Types
    "GpuType",
    "CloudProvider",
    "Sandbox",
    # Client and workflow
    "MixClient",
    "MixFlow",
    "MixModel",
    "sandbox",
    # Proxy classes (for accessing and creating resources)
    "Model",
    "ModelResult",
    "BatchResult",
    "RunStatus",
    "get_model",
    "list_models",
    "Eval",
    "get_eval",
    "list_evals",
    "Dataset",
    "get_dataset",
    "list_datasets",
    "Workflow",
    "get_workflow",
    "list_workflows",
    "Router",
    "get_router",
    "list_routers",
    # Files
    "Files",
    "FileInfo",
    "UploadDirResult",
    "UploadError",
    # Media and text types (explicit wrappers)
    "MixType",
    "File",
    "Image",
    "Video",
    "Audio",
    "Model3D",
    "MCAP",
    "Rerun",
    "Text",
    "Markdown",
    "JSON",
    "Embedding",
    # Serialization
    "serialize_output",
    "deserialize_output",
    "extract_output_schema",
    # Utilities
    "generate_name",
    "validate_resource_name",
]
