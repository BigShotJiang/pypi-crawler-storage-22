"""Shared CLI utilities for consistent output formatting."""

import glob as glob_module
import json
import os
import time
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING

import typer
from rich import print as rprint
from rich.console import Console
from rich.status import Status

from mixtrain import GpuType, Sandbox, sandbox as make_sandbox

MAX_UPLOAD_FILES = 100


def parse_json_input(value: str | None) -> dict:
    """Parse JSON input from string or file path.

    Args:
        value: JSON string, file path (starting with @ or file that exists), or None

    Returns:
        Parsed dict, empty dict if value is None

    Raises:
        typer.BadParameter: If the JSON is invalid or the file cannot be read
    """
    if not value:
        return {}
    if os.path.isfile(value):
        try:
            with open(value) as f:
                return json.load(f)
        except json.JSONDecodeError as e:
            raise typer.BadParameter(f"Invalid JSON in file '{value}': {e}")
        except OSError as e:
            raise typer.BadParameter(f"Cannot read file '{value}': {e}")
    try:
        return json.loads(value)
    except json.JSONDecodeError as e:
        raise typer.BadParameter(f"Invalid JSON input: {e}")


def build_sandbox_from_flags(
    gpu: str | None,
    gpu_per_node: int | None,
    cpu: int | None,
    memory: int | None,
    timeout: int | None,
    image: str | None,
) -> Sandbox | None:
    """Build a Sandbox from individual CLI flags.

    Returns:
        Sandbox if any flags are set, None otherwise

    Raises:
        typer.BadParameter: If gpu is not a valid GPU type, or gpu_per_node is set without gpu
    """
    if gpu:
        gpu = gpu.upper()
        valid_gpus = set(GpuType.__args__)
        if gpu not in valid_gpus:
            raise typer.BadParameter(
                f"Invalid GPU type '{gpu}'. Valid types: {', '.join(sorted(valid_gpus))}"
            )

    if gpu_per_node is not None:
        if not gpu:
            raise typer.BadParameter("--gpu-per-node requires --gpu to be specified")
        if gpu_per_node < 1 or gpu_per_node > 8:
            raise typer.BadParameter("--gpu-per-node must be between 1 and 8")

    result = make_sandbox(
        gpu=gpu, gpu_per_node=gpu_per_node, cpu=cpu, memory=memory, timeout=timeout, image=image
    )
    return result or None


if TYPE_CHECKING:
    from mixtrain import MixClient

# Shared console for status updates
_console = Console()


def expand_file_args(args: list[str]) -> list[str]:
    """Expand directories and glob patterns to file paths.

    Args:
        args: List of file paths, directories, or glob patterns

    Returns:
        Deduplicated list of file paths

    Raises:
        ValueError: If expanded files exceed MAX_UPLOAD_FILES limit
    """
    files = []
    for arg in args:
        path = Path(arg)
        if path.is_dir():
            # Recursively include all files in directory
            files.extend(str(f) for f in path.rglob("*") if f.is_file())
        elif any(c in arg for c in "*?["):
            # Glob pattern
            files.extend(glob_module.glob(arg, recursive=True))
        else:
            files.append(arg)

    # Dedupe preserving order
    files = list(dict.fromkeys(files))

    if len(files) > MAX_UPLOAD_FILES:
        raise ValueError(
            f"Too many files ({len(files)}). Maximum is {MAX_UPLOAD_FILES}. "
            "Use more specific patterns or split into multiple uploads."
        )

    return files


def print_error(message: str, suggestion: str | None = None):
    """Print consistent error message."""
    rprint(f"[red]Error:[/red] {message}")
    if suggestion:
        rprint(f"[dim]Tip: {suggestion}[/dim]")


def print_empty_state(resource_type: str, suggestion: str | None = None):
    """Print consistent empty state message."""
    rprint(f"[yellow]No {resource_type} found.[/yellow]")
    if suggestion:
        rprint(f"[dim]{suggestion}[/dim]")


def truncate(text: str | None, max_len: int = 50) -> str:
    """Truncate text for table display."""
    if not text:
        return ""
    return text[:max_len] + "..." if len(text) > max_len else text


def format_datetime(iso_string: str | None) -> str:
    """Format ISO datetime string to local time."""
    if not iso_string:
        return ""
    try:
        dt = datetime.fromisoformat(iso_string.replace("Z", "+00:00"))
        return dt.astimezone().strftime("%Y-%m-%d %H:%M")
    except (ValueError, AttributeError):
        return iso_string


def stream_logs(
    client: "MixClient",
    resource_type: str,
    resource_name: str,
    run_number: int,
) -> str:
    """Stream logs from a workflow or model run via SSE.

    Shows a spinner status that gets replaced when logs start streaming.

    Args:
        client: MixClient instance for authentication
        resource_type: Either "workflow" or "model"
        resource_name: Name of the workflow or model
        run_number: Run number

    Returns:
        Final status of the run (completed, failed, cancelled, etc.)
    """
    if resource_type == "workflow":
        get_run_fn = lambda: client.get_workflow_run(resource_name, run_number)
    else:
        get_run_fn = lambda: client.get_model_run(resource_name, run_number)

    # Use Status context manager for spinner that gets replaced
    with Status(
        "[dim]Waiting for run to start...[/dim]", console=_console, spinner="dots"
    ) as status:
        # Wait for run to start
        # No timeout - multi-node jobs can take a long time to provision
        # User can Ctrl+C if needed
        while True:
            try:
                run_data = get_run_fn()
            except Exception:
                time.sleep(2)
                continue

            run = run_data.get("data", run_data)
            run_status = run.get("status")

            # If run already completed, fetch static logs and return
            if run_status in ("completed", "failed", "cancelled"):
                status.stop()
                _print_static_logs(client, resource_type, resource_name, run_number)
                return run_status

            # If running, start streaming logs
            if run_status == "running":
                break

            time.sleep(2)

        # Update status before streaming
        status.update("[dim]Streaming logs...[/dim]")

        # Stream logs via client method
        log_count = 0
        stream_error = None
        first_log = True

        try:
            for data in client.stream_run_logs(
                resource_type, resource_name, run_number
            ):
                # Stop status spinner on first log output
                if first_log:
                    status.stop()
                    first_log = False

                # Check for error response
                if data.get("_error"):
                    stream_error = f"HTTP {data['status_code']}: {data['body']}"
                    break

                # Handle batched logs format: {"logs": [{"data": "...", ...}, ...]}
                if "logs" in data:
                    for log_entry in data["logs"]:
                        log_text = log_entry.get("data", "")
                        if log_text:
                            log_count += 1
                            print(log_text, end="", flush=True)
                # Fallback for single log format
                elif "data" in data:
                    log_text = data.get("data", "")
                    if log_text:
                        log_count += 1
                        print(log_text, end="", flush=True)

            # Ensure status is stopped
            if first_log:
                status.stop()

            if log_count == 0 and not stream_error:
                _print_static_logs(client, resource_type, resource_name, run_number)

        except KeyboardInterrupt:
            status.stop()
            run_data = get_run_fn()
            run = run_data.get("data", run_data)
            return run.get("status", "unknown")
        except Exception:
            status.stop()
            _print_static_logs(client, resource_type, resource_name, run_number)

    # Get final run status
    run_data = get_run_fn()
    run = run_data.get("data", run_data)
    return run.get("status", "unknown")


def _print_static_logs(
    client: "MixClient",
    resource_type: str,
    resource_name: str,
    run_number: int,
) -> None:
    """Fetch and print static logs using client methods."""
    try:
        if resource_type == "workflow":
            logs = client.get_workflow_run_logs(resource_name, run_number)
        else:
            logs = client.get_model_run_logs(resource_name, run_number)
        if logs:
            print(logs, flush=True)
    except Exception as e:
        rprint(f"[yellow]Error fetching logs: {e}[/yellow]")


def fetch_logs(
    client: "MixClient",
    resource_type: str,
    resource_name: str,
    run_number: int,
    follow: bool = False,
) -> None:
    """Fetch and print logs for a workflow or model run.

    Args:
        client: MixClient instance
        resource_type: Either "workflow" or "model"
        resource_name: Name of the workflow or model
        run_number: Run number
        follow: If True, stream logs until run completes. If False, print current logs and exit.
    """
    if resource_type == "workflow":
        get_run_fn = lambda: client.get_workflow_run(resource_name, run_number)
    else:
        get_run_fn = lambda: client.get_model_run(resource_name, run_number)

    # Check run status
    run_data = get_run_fn()
    run = run_data.get("data", run_data)
    status = run.get("status")

    # For completed/failed/cancelled runs, use static logs
    if status in ("completed", "failed", "cancelled"):
        _print_static_logs(client, resource_type, resource_name, run_number)
        return

    # For active runs: stream continuously if following, otherwise catch up and exit
    if follow:
        stream_logs(client, resource_type, resource_name, run_number)
    else:
        _stream_and_exit(client, resource_type, resource_name, run_number)


def _stream_and_exit(
    client: "MixClient",
    resource_type: str,
    resource_name: str,
    run_number: int,
    read_timeout: float = 2.0,
) -> None:
    """Stream logs from an active run and exit after catching up.

    Connects to the log stream and reads until no new logs arrive for read_timeout seconds.

    Args:
        client: MixClient instance
        resource_type: Either "workflow" or "model"
        resource_name: Name of the workflow or model
        run_number: Run number
        read_timeout: Seconds of no new logs before considering caught up and exiting
    """
    try:
        for data in client.stream_run_logs(
            resource_type, resource_name, run_number, read_timeout=read_timeout
        ):
            # Check for error response
            if data.get("_error"):
                rprint(
                    f"[yellow]Error fetching logs: HTTP {data.get('status_code')}: {data.get('body')}[/yellow]"
                )
                break

            # Handle batched logs format: {"logs": [{"data": "...", ...}, ...]}
            if "logs" in data:
                for log_entry in data["logs"]:
                    log_text = log_entry.get("data", "")
                    if log_text:
                        print(log_text, end="", flush=True)
            # Fallback for single log format
            elif "data" in data:
                log_text = data.get("data", "")
                if log_text:
                    print(log_text, end="", flush=True)

    except Exception:
        # On any error, try static logs as fallback
        _print_static_logs(client, resource_type, resource_name, run_number)


def _poll_for_completion(
    get_run_fn, poll_interval: int = 5, max_polls: int = 360
) -> str:
    """Poll for run completion when streaming is not available.

    Args:
        get_run_fn: Function to get current run status
        poll_interval: Seconds between polls (default: 5)
        max_polls: Maximum number of polls before giving up (default: 360 = 30 min)
    """
    polls = 0
    try:
        while polls < max_polls:
            run_data = get_run_fn()
            run = run_data.get("data", run_data)
            status = run.get("status")

            if status in ("completed", "failed", "cancelled"):
                return status

            polls += 1
            time.sleep(poll_interval)

        return "unknown"
    except KeyboardInterrupt:
        run_data = get_run_fn()
        run = run_data.get("data", run_data)
        return run.get("status", "unknown")
