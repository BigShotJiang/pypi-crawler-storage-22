from .plugin import AdvancedSEOPlugin

__all__ = ["AdvancedSEOPlugin"]
