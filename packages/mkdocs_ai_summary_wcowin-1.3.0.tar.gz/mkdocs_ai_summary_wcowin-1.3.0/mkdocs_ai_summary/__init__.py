"""MkDocs AI Summary Plugin

A plugin for MkDocs that automatically generates AI-powered summaries for documentation pages.
"""

__version__ = "1.3.0"
__author__ = "MkDocs AI Summary Team"
__email__ = "support@mkdocs-ai-summary.com"

from .plugin import AISummaryPlugin

__all__ = ["AISummaryPlugin"]