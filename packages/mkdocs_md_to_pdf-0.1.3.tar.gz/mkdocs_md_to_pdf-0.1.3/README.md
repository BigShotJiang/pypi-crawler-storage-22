# mkdocs-md-to-pdf

Convert Markdown files to styled PDFs using [MkDocs Material](https://squidfunk.github.io/mkdocs-material/) theme and [Playwright](https://playwright.dev/).

## Features

- Material Design styling via MkDocs Material theme
- Syntax highlighting for code blocks
- Mermaid diagram support
- PlantUML diagram support (requires Java)
- Admonitions and callouts
- Automatic handling of linked images and files

## Installation

```bash
# Using uv
uv add mkdocs-md-to-pdf

# Using pip
pip install mkdocs-md-to-pdf
```

After installation, install the Chromium browser for Playwright:

```bash
playwright install chromium
```

### PlantUML Setup

#### macOS
1. Download PlantUML JAR from [GitHub releases](https://github.com/plantuml/plantuml/releases/latest)
2. Place JAR: `mv plantuml-mit-1.2025.8.jar ~/.local/bin/plantuml.jar`
3. Make executable: `chmod +x ~/.local/bin/plantuml.jar`
4. Add to shell profile (.bashrc/.zshrc):
```bash
export PATH="$PATH:~/.local/bin"
export PATH="/opt/homebrew/opt/openjdk/bin:$PATH"
```

#### Ubuntu/Debian
```bash
sudo apt install default-jdk plantuml
```

## Usage

### Command Line

```bash
# Output to stdout (pipe to file)
md-to-pdf document.md > output.pdf

# Output to specific file
md-to-pdf document.md -o output.pdf
```

### Python API

```python
from mkdocs_md_to_pdf import convert

# Get PDF as bytes
pdf_bytes = convert("document.md")

# Write directly to file
convert("document.md", output_file="output.pdf")
```

## Supported Markdown Features

- Standard Markdown syntax
- Fenced code blocks with syntax highlighting
- Tables
- Admonitions (`!!! note`, `!!! warning`, etc.)
- Callouts (`> [!NOTE]`, `> [!WARNING]`)
- Mermaid diagrams
- PlantUML diagrams
- Linked images (relative paths)

## License

MIT
