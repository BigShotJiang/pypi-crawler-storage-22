"""Convert Markdown files to PDF using MkDocs Material theme and Playwright."""

__version__ = "0.1.0"

from mkdocs_md_to_pdf.converter import convert

__all__ = ["convert", "__version__"]
