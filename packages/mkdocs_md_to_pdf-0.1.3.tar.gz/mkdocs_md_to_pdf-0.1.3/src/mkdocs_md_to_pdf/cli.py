"""Command-line interface for md-to-pdf."""

import argparse
import sys

from mkdocs_md_to_pdf.converter import convert


def main() -> None:
    """CLI entry point for md-to-pdf."""
    parser = argparse.ArgumentParser(
        prog="md-to-pdf",
        description="Convert a markdown file to PDF using MkDocs and Playwright.",
    )
    parser.add_argument("input_file", help="Path to the markdown file to convert")
    parser.add_argument(
        "-o",
        "--output",
        help="Output PDF file path (default: write to stdout)",
    )
    args = parser.parse_args()

    try:
        pdf_bytes = convert(args.input_file, args.output)
        if not args.output:
            sys.stdout.buffer.write(pdf_bytes)
            sys.stdout.flush()
    except FileNotFoundError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
