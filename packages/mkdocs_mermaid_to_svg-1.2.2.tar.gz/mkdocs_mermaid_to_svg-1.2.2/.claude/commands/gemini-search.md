## Gemini Search

`gemini` is Google Gemini CLI. You can use it for web search.

Run web search via Task Tool with `gemini --yolo -p 'WebSearch: ...'`.

```bash
gemini --yolo -p "WebSearch: ..."
```
