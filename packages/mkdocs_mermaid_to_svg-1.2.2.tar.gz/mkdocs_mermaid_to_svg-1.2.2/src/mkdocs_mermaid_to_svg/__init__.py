"""パッケージ公開情報（バージョン・作者・説明）をまとめて公開するモジュール"""

__version__ = "1.0.0"

__author__ = "Claude Code Assistant"

__description__ = "MkDocs plugin to preprocess Mermaid diagrams"
