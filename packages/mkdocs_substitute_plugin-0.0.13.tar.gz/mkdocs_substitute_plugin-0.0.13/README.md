# mkdocs SUBSTITUTE

For more information about this package please visit
[this homepage](https://www.code-is-poetry.de/substitute_eng/)

To force an update please enter

pip install --upgrade --force-reinstall mkdocs-substitute-plugin  

Current Version: 0.13, Jan 31st, 2026  

New: Mastodon Badge has been added
New: Date/Time functions have been added  

