"""
Regression models for mlbench-lite.

This module provides a comprehensive set of regression models for benchmarking.
"""

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import warnings
import numpy as np

# Suppress warnings for cleaner output
warnings.filterwarnings('ignore')

# Import all available regression models
try:
    from sklearn.linear_model import (
        LinearRegression, Ridge, Lasso, ElasticNet, BayesianRidge,
        HuberRegressor, QuantileRegressor
    )
    from sklearn.ensemble import (
        RandomForestRegressor, ExtraTreesRegressor, GradientBoostingRegressor,
        AdaBoostRegressor, BaggingRegressor
    )
    from sklearn.svm import SVR
    from sklearn.neighbors import KNeighborsRegressor
    from sklearn.tree import DecisionTreeRegressor
    from sklearn.neural_network import MLPRegressor
    from sklearn.gaussian_process import GaussianProcessRegressor
    SKLEARN_AVAILABLE = True
except ImportError:
    SKLEARN_AVAILABLE = False

try:
    import xgboost as xgb
    XGBOOST_AVAILABLE = True
except ImportError:
    XGBOOST_AVAILABLE = False

try:
    import lightgbm as lgb
    LIGHTGBM_AVAILABLE = True
except ImportError:
    LIGHTGBM_AVAILABLE = False

try:
    import catboost as cb
    CATBOOST_AVAILABLE = True
except ImportError:
    CATBOOST_AVAILABLE = False


def get_available_regressors():
    """
    Get all available regression models with their categories.
    
    Returns
    -------
    dict
        Dictionary with model categories as keys and lists of (name, model_class) tuples as values
    """
    models = {}
    
    if SKLEARN_AVAILABLE:
        models['Linear Regression'] = [
            ('Linear Regression', LinearRegression()),
            ('Ridge Regression', Ridge(random_state=42)),
            ('Lasso Regression', Lasso(random_state=42)),
            ('ElasticNet Regression', ElasticNet(random_state=42)),
            ('Bayesian Ridge', BayesianRidge()),
            ('Huber Regressor', HuberRegressor()),
            ('Quantile Regressor', QuantileRegressor(solver='highs', alpha=0.01)),
        ]
        
        models['Tree-based Regression'] = [
            ('Decision Tree Regressor', DecisionTreeRegressor(random_state=42)),
            ('Random Forest Regressor', RandomForestRegressor(random_state=42)),
            ('Extra Trees Regressor', ExtraTreesRegressor(random_state=42)),
            ('Gradient Boosting Regressor', GradientBoostingRegressor(random_state=42)),
            ('AdaBoost Regressor', AdaBoostRegressor(random_state=42)),
            ('Bagging Regressor', BaggingRegressor(random_state=42)),
        ]
        
        models['SVM Regression'] = [
            ('SVR (RBF)', SVR(kernel='rbf')),
            ('SVR (Linear)', SVR(kernel='linear')),
        ]
        
        models['Neighbors'] = [
            ('K-Neighbors Regressor', KNeighborsRegressor()),
        ]
        
        models['Neural Networks'] = [
            ('MLP Regressor', MLPRegressor(random_state=42, max_iter=1000)),
        ]
        
        models['Gaussian Process'] = [
            ('Gaussian Process Regressor', GaussianProcessRegressor(random_state=42)),
        ]
    
    if XGBOOST_AVAILABLE:
        models['XGBoost'] = [
            ('XGBoost Regressor', xgb.XGBRegressor(random_state=42, eval_metric='rmse')),
        ]
    
    if LIGHTGBM_AVAILABLE:
        models['LightGBM'] = [
            ('LightGBM Regressor', lgb.LGBMRegressor(random_state=42, verbose=-1)),
        ]
    
    if CATBOOST_AVAILABLE:
        models['CatBoost'] = [
            ('CatBoost Regressor', cb.CatBoostRegressor(random_state=42, verbose=False)),
        ]
    
    return models


def benchmark_regression(X, y, test_size=0.2, random_state=42, models=None, 
                         model_categories=None, exclude_models=None):
    """
    Benchmark multiple regression models on a dataset.
    
    Parameters
    ----------
    X : array-like of shape (n_samples, n_features)
        Training vectors, where n_samples is the number of samples
        and n_features is the number of features.
    y : array-like of shape (n_samples,)
        Target values (continuous).
    test_size : float, default=0.2
        Proportion of the dataset to include in the test split.
    random_state : int, default=42
        Controls the shuffling applied to the data before applying the split.
    models : list of str, optional
        Specific models to use. If None, uses all available models.
        Examples: ['Linear Regression', 'Random Forest Regressor', 'XGBoost Regressor']
    model_categories : list of str, optional
        Categories of models to use. If None, uses all categories.
        Examples: ['Linear Regression', 'Tree-based Regression', 'XGBoost']
    exclude_models : list of str, optional
        Models to exclude from benchmarking.
        Examples: ['SVR (RBF)', 'Gaussian Process Regressor']
        
    Returns
    -------
    pandas.DataFrame
        A DataFrame containing the performance metrics for each model:
        - Model: Name of the model
        - Category: Category of the model
        - R2: R-squared score
        - MAE: Mean Absolute Error
        - RMSE: Root Mean Squared Error
        - MSE: Mean Squared Error
    """
    
    # Split the data
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=random_state
    )
    
    # Get available models
    available_models = get_available_regressors()
    
    # Filter models based on user selection
    selected_models = {}
    
    if models is not None:
        # User specified specific models
        for category, model_list in available_models.items():
            for name, model in model_list:
                if name in models:
                    if category not in selected_models:
                        selected_models[category] = []
                    selected_models[category].append((name, model))
    elif model_categories is not None:
        # User specified categories
        for category in model_categories:
            if category in available_models:
                selected_models[category] = available_models[category]
    else:
        # Use all available models
        selected_models = available_models.copy()
    
    # Remove excluded models
    if exclude_models is not None:
        for category in list(selected_models.keys()):
            selected_models[category] = [
                (name, model) for name, model in selected_models[category]
                if name not in exclude_models
            ]
            if not selected_models[category]:
                del selected_models[category]
    
    # Store results
    results = []
    
    for category, model_list in selected_models.items():
        for model_name, model in model_list:
            try:
                # Train the model
                model.fit(X_train, y_train)
                
                # Make predictions
                y_pred = model.predict(X_test)
                
                # Calculate metrics
                r2 = r2_score(y_test, y_pred)
                mae = mean_absolute_error(y_test, y_pred)
                mse = mean_squared_error(y_test, y_pred)
                rmse = np.sqrt(mse)
                
                results.append({
                    'Model': model_name,
                    'Category': category,
                    'R2': round(r2, 4),
                    'MAE': round(mae, 4),
                    'RMSE': round(rmse, 4),
                    'MSE': round(mse, 4)
                })
                
            except Exception as e:
                # If a model fails, add it with error values
                results.append({
                    'Model': model_name,
                    'Category': category,
                    'R2': 0.0,
                    'MAE': 0.0,
                    'RMSE': 0.0,
                    'MSE': 0.0
                })
                print(f"Warning: {model_name} failed with error: {str(e)}")
    
    # Convert to DataFrame
    results_df = pd.DataFrame(results)
    
    if results_df.empty:
        print("No models were successfully trained. Please check your data and model selection.")
        return results_df
    
    # Sort by R2 (descending)
    results_df = results_df.sort_values('R2', ascending=False).reset_index(drop=True)
    
    return results_df


def list_available_regressors():
    """
    List all available regression models and their categories.
    
    Returns
    -------
    dict
        Dictionary with model categories as keys and lists of model names as values
    """
    available_models = get_available_regressors()
    model_list = {}
    
    for category, models in available_models.items():
        model_list[category] = [name for name, _ in models]
    
    return model_list


def get_regressor_info():
    """
    Get detailed information about available regression models.
    
    Returns
    -------
    pandas.DataFrame
        DataFrame with model information including category, name, and description
    """
    model_info = []
    
    model_info.append({
        'Category': 'Linear Regression',
        'Model': 'Linear Regression',
        'Description': 'Simple linear regression model'
    })
    model_info.append({
        'Category': 'Linear Regression',
        'Model': 'Ridge Regression',
        'Description': 'Linear regression with L2 regularization'
    })
    model_info.append({
        'Category': 'Linear Regression',
        'Model': 'Lasso Regression',
        'Description': 'Linear regression with L1 regularization'
    })
    model_info.append({
        'Category': 'Linear Regression',
        'Model': 'ElasticNet Regression',
        'Description': 'Linear regression with L1 and L2 regularization'
    })
    model_info.append({
        'Category': 'Linear Regression',
        'Model': 'Bayesian Ridge',
        'Description': 'Bayesian linear regression with automatic relevance determination'
    })
    model_info.append({
        'Category': 'Linear Regression',
        'Model': 'Huber Regressor',
        'Description': 'Linear regression robust to outliers using Huber loss'
    })
    model_info.append({
        'Category': 'Linear Regression',
        'Model': 'Quantile Regressor',
        'Description': 'Linear regression for quantile predictions'
    })
    
    model_info.append({
        'Category': 'Tree-based Regression',
        'Model': 'Decision Tree Regressor',
        'Description': 'Non-parametric tree-based regression'
    })
    model_info.append({
        'Category': 'Tree-based Regression',
        'Model': 'Random Forest Regressor',
        'Description': 'Ensemble of decision trees with bagging'
    })
    model_info.append({
        'Category': 'Tree-based Regression',
        'Model': 'Extra Trees Regressor',
        'Description': 'Extremely randomized trees ensemble for regression'
    })
    model_info.append({
        'Category': 'Tree-based Regression',
        'Model': 'Gradient Boosting Regressor',
        'Description': 'Boosting ensemble method using gradient descent for regression'
    })
    model_info.append({
        'Category': 'Tree-based Regression',
        'Model': 'AdaBoost Regressor',
        'Description': 'Adaptive boosting ensemble for regression'
    })
    model_info.append({
        'Category': 'Tree-based Regression',
        'Model': 'Bagging Regressor',
        'Description': 'Bootstrap aggregating ensemble for regression'
    })
    
    model_info.append({
        'Category': 'SVM Regression',
        'Model': 'SVR (RBF)',
        'Description': 'Support Vector Regression with RBF kernel'
    })
    model_info.append({
        'Category': 'SVM Regression',
        'Model': 'SVR (Linear)',
        'Description': 'Support Vector Regression with linear kernel'
    })
    
    model_info.append({
        'Category': 'Neighbors',
        'Model': 'K-Neighbors Regressor',
        'Description': 'Instance-based regression using k-nearest neighbors'
    })
    
    model_info.append({
        'Category': 'Neural Networks',
        'Model': 'MLP Regressor',
        'Description': 'Multi-layer perceptron neural network for regression'
    })
    
    model_info.append({
        'Category': 'Gaussian Process',
        'Model': 'Gaussian Process Regressor',
        'Description': 'Probabilistic regression using Gaussian processes'
    })
    
    if XGBOOST_AVAILABLE:
        model_info.append({
            'Category': 'XGBoost',
            'Model': 'XGBoost Regressor',
            'Description': 'Extreme gradient boosting framework for regression'
        })
    
    if LIGHTGBM_AVAILABLE:
        model_info.append({
            'Category': 'LightGBM',
            'Model': 'LightGBM Regressor',
            'Description': 'Light gradient boosting machine for regression'
        })
    
    if CATBOOST_AVAILABLE:
        model_info.append({
            'Category': 'CatBoost',
            'Model': 'CatBoost Regressor',
            'Description': 'Categorical boosting framework for regression'
        })
    
    return pd.DataFrame(model_info)
