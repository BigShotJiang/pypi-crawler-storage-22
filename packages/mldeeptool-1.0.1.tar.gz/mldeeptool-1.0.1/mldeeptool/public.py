import numpy as np

    
def get_train_test_sample(X:np.ndarray, Y:np.ndarray, test_rate: float=0.2, is_stratify=False, **sklearn_kwargs)-> tuple[np.ndarray,np.ndarray,np.ndarray,np.ndarray]:
    """
    生成训练集和测试集  
    X_train, X_test, y_train, y_test
    """
    try:
        from sklearn.model_selection import train_test_split
    except ModuleNotFoundError:
        raise ModuleNotFoundError('pip install scikit-learn')
    return train_test_split(X, Y,   
                            test_size=test_rate,# 测试集占比
                            stratify=Y if is_stratify else None, # 分层采样保持类别比例, 仅适用于分类数据集
                            **sklearn_kwargs
                            )

def huber_mean(data, delta=1.345):
    """
    均值计算（中位数优点+平均数优点）  
    delta越大越接近平均值, 越小越接近中位数
    """
    try:
        from scipy.optimize import minimize_scalar
    except ModuleNotFoundError:
        raise ModuleNotFoundError('pip install scipy')
    def huber_objective(center):
        residuals = data - center
        abs_residuals = np.abs(residuals)
        huber_loss = np.where(
            abs_residuals <= delta,
            0.5 * residuals**2,
            delta * abs_residuals - 0.5 * delta**2
        )
        return np.sum(huber_loss)
    
    result = minimize_scalar(huber_objective)
    return result.x

def exponential_smoothing(data, alpha=0.3):
    """
    指数平滑  
    alpha越小抗噪性越大
    """
    result = [data[0]]
    for i in range(1, len(data)):
        result.append(alpha * data[i] + (1 - alpha) * result[i-1])
    return np.array(result)
    
def double_exponential_smoothing(data, alpha=0.3, beta=0.3):
    """
    指数平滑  
    alpha越小抗噪性越大, 同时平滑水平和趋势  
    """
    n = len(data)
    if n < 2: return data
    # 初始化
    level = [data[0]]
    trend = [data[1] - data[0]]
    result = [data[0]]
    for i in range(1, n):
        # 水平分量
        new_level = alpha * data[i] + (1 - alpha) * (level[i-1] + trend[i-1])
        # 趋势分量
        new_trend = beta * (new_level - level[i-1]) + (1 - beta) * trend[i-1]
        level.append(new_level)
        trend.append(new_trend)
        result.append(new_level)
    return np.array(result)