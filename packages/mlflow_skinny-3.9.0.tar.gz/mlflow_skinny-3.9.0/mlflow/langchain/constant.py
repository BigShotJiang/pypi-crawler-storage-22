FLAVOR_NAME = "langchain"
