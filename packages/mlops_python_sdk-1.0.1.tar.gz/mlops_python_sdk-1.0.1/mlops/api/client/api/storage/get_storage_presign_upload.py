from http import HTTPStatus
from typing import Any, Optional, Union

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.error_response import ErrorResponse
from ...models.get_storage_presign_upload_response_200 import GetStoragePresignUploadResponse200
from ...types import UNSET, Response


def _get_kwargs(
    *,
    filename: str,
) -> dict[str, Any]:
    params: dict[str, Any] = {}

    params["filename"] = filename

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/storage/presign_upload",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Optional[Union[ErrorResponse, GetStoragePresignUploadResponse200]]:
    if response.status_code == 200:
        response_200 = GetStoragePresignUploadResponse200.from_dict(response.json())

        return response_200
    if response.status_code == 400:
        response_400 = ErrorResponse.from_dict(response.json())

        return response_400
    if response.status_code == 500:
        response_500 = ErrorResponse.from_dict(response.json())

        return response_500
    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Response[Union[ErrorResponse, GetStoragePresignUploadResponse200]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    filename: str,
) -> Response[Union[ErrorResponse, GetStoragePresignUploadResponse200]]:
    """Get presigned URL for file upload

     Generates a presigned URL for uploading a file to S3.

    Args:
        filename (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[ErrorResponse, GetStoragePresignUploadResponse200]]
    """

    kwargs = _get_kwargs(
        filename=filename,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    filename: str,
) -> Optional[Union[ErrorResponse, GetStoragePresignUploadResponse200]]:
    """Get presigned URL for file upload

     Generates a presigned URL for uploading a file to S3.

    Args:
        filename (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[ErrorResponse, GetStoragePresignUploadResponse200]
    """

    return sync_detailed(
        client=client,
        filename=filename,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    filename: str,
) -> Response[Union[ErrorResponse, GetStoragePresignUploadResponse200]]:
    """Get presigned URL for file upload

     Generates a presigned URL for uploading a file to S3.

    Args:
        filename (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[ErrorResponse, GetStoragePresignUploadResponse200]]
    """

    kwargs = _get_kwargs(
        filename=filename,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    filename: str,
) -> Optional[Union[ErrorResponse, GetStoragePresignUploadResponse200]]:
    """Get presigned URL for file upload

     Generates a presigned URL for uploading a file to S3.

    Args:
        filename (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[ErrorResponse, GetStoragePresignUploadResponse200]
    """

    return (
        await asyncio_detailed(
            client=client,
            filename=filename,
        )
    ).parsed
