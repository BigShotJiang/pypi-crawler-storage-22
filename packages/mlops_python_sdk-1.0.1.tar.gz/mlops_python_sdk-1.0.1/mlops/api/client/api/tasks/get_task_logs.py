from http import HTTPStatus
from typing import Any, Optional, Union

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.error_response import ErrorResponse
from ...models.get_task_logs_direction import GetTaskLogsDirection
from ...models.get_task_logs_log_type import GetTaskLogsLogType
from ...models.task_logs_response import TaskLogsResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    id: int,
    *,
    cluster_name: str,
    log_type: Union[Unset, GetTaskLogsLogType] = GetTaskLogsLogType.ALL,
    start: Union[Unset, str] = UNSET,
    end: Union[Unset, str] = UNSET,
    limit: Union[Unset, int] = 1000,
    direction: Union[Unset, GetTaskLogsDirection] = GetTaskLogsDirection.BACKWARD,
    cursor: Union[Unset, str] = UNSET,
) -> dict[str, Any]:
    params: dict[str, Any] = {}

    params["cluster_name"] = cluster_name

    json_log_type: Union[Unset, str] = UNSET
    if not isinstance(log_type, Unset):
        json_log_type = log_type.value

    params["log_type"] = json_log_type

    params["start"] = start

    params["end"] = end

    params["limit"] = limit

    json_direction: Union[Unset, str] = UNSET
    if not isinstance(direction, Unset):
        json_direction = direction.value

    params["direction"] = json_direction

    params["cursor"] = cursor

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": f"/tasks/{id}/logs",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Optional[Union[ErrorResponse, TaskLogsResponse]]:
    if response.status_code == 200:
        response_200 = TaskLogsResponse.from_dict(response.json())

        return response_200
    if response.status_code == 401:
        response_401 = ErrorResponse.from_dict(response.json())

        return response_401
    if response.status_code == 403:
        response_403 = ErrorResponse.from_dict(response.json())

        return response_403
    if response.status_code == 404:
        response_404 = ErrorResponse.from_dict(response.json())

        return response_404
    if response.status_code == 500:
        response_500 = ErrorResponse.from_dict(response.json())

        return response_500
    if response.status_code == 503:
        response_503 = ErrorResponse.from_dict(response.json())

        return response_503
    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Response[Union[ErrorResponse, TaskLogsResponse]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    id: int,
    *,
    client: AuthenticatedClient,
    cluster_name: str,
    log_type: Union[Unset, GetTaskLogsLogType] = GetTaskLogsLogType.ALL,
    start: Union[Unset, str] = UNSET,
    end: Union[Unset, str] = UNSET,
    limit: Union[Unset, int] = 1000,
    direction: Union[Unset, GetTaskLogsDirection] = GetTaskLogsDirection.BACKWARD,
    cursor: Union[Unset, str] = UNSET,
) -> Response[Union[ErrorResponse, TaskLogsResponse]]:
    """Get task logs

     Get stdout/stderr logs for a task from Loki. Supports pagination via cursor-based navigation.

    Args:
        id (int):
        cluster_name (str):
        log_type (Union[Unset, GetTaskLogsLogType]):  Default: GetTaskLogsLogType.ALL.
        start (Union[Unset, str]):
        end (Union[Unset, str]):
        limit (Union[Unset, int]):  Default: 1000.
        direction (Union[Unset, GetTaskLogsDirection]):  Default: GetTaskLogsDirection.BACKWARD.
        cursor (Union[Unset, str]):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[ErrorResponse, TaskLogsResponse]]
    """

    kwargs = _get_kwargs(
        id=id,
        cluster_name=cluster_name,
        log_type=log_type,
        start=start,
        end=end,
        limit=limit,
        direction=direction,
        cursor=cursor,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    id: int,
    *,
    client: AuthenticatedClient,
    cluster_name: str,
    log_type: Union[Unset, GetTaskLogsLogType] = GetTaskLogsLogType.ALL,
    start: Union[Unset, str] = UNSET,
    end: Union[Unset, str] = UNSET,
    limit: Union[Unset, int] = 1000,
    direction: Union[Unset, GetTaskLogsDirection] = GetTaskLogsDirection.BACKWARD,
    cursor: Union[Unset, str] = UNSET,
) -> Optional[Union[ErrorResponse, TaskLogsResponse]]:
    """Get task logs

     Get stdout/stderr logs for a task from Loki. Supports pagination via cursor-based navigation.

    Args:
        id (int):
        cluster_name (str):
        log_type (Union[Unset, GetTaskLogsLogType]):  Default: GetTaskLogsLogType.ALL.
        start (Union[Unset, str]):
        end (Union[Unset, str]):
        limit (Union[Unset, int]):  Default: 1000.
        direction (Union[Unset, GetTaskLogsDirection]):  Default: GetTaskLogsDirection.BACKWARD.
        cursor (Union[Unset, str]):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[ErrorResponse, TaskLogsResponse]
    """

    return sync_detailed(
        id=id,
        client=client,
        cluster_name=cluster_name,
        log_type=log_type,
        start=start,
        end=end,
        limit=limit,
        direction=direction,
        cursor=cursor,
    ).parsed


async def asyncio_detailed(
    id: int,
    *,
    client: AuthenticatedClient,
    cluster_name: str,
    log_type: Union[Unset, GetTaskLogsLogType] = GetTaskLogsLogType.ALL,
    start: Union[Unset, str] = UNSET,
    end: Union[Unset, str] = UNSET,
    limit: Union[Unset, int] = 1000,
    direction: Union[Unset, GetTaskLogsDirection] = GetTaskLogsDirection.BACKWARD,
    cursor: Union[Unset, str] = UNSET,
) -> Response[Union[ErrorResponse, TaskLogsResponse]]:
    """Get task logs

     Get stdout/stderr logs for a task from Loki. Supports pagination via cursor-based navigation.

    Args:
        id (int):
        cluster_name (str):
        log_type (Union[Unset, GetTaskLogsLogType]):  Default: GetTaskLogsLogType.ALL.
        start (Union[Unset, str]):
        end (Union[Unset, str]):
        limit (Union[Unset, int]):  Default: 1000.
        direction (Union[Unset, GetTaskLogsDirection]):  Default: GetTaskLogsDirection.BACKWARD.
        cursor (Union[Unset, str]):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[ErrorResponse, TaskLogsResponse]]
    """

    kwargs = _get_kwargs(
        id=id,
        cluster_name=cluster_name,
        log_type=log_type,
        start=start,
        end=end,
        limit=limit,
        direction=direction,
        cursor=cursor,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    id: int,
    *,
    client: AuthenticatedClient,
    cluster_name: str,
    log_type: Union[Unset, GetTaskLogsLogType] = GetTaskLogsLogType.ALL,
    start: Union[Unset, str] = UNSET,
    end: Union[Unset, str] = UNSET,
    limit: Union[Unset, int] = 1000,
    direction: Union[Unset, GetTaskLogsDirection] = GetTaskLogsDirection.BACKWARD,
    cursor: Union[Unset, str] = UNSET,
) -> Optional[Union[ErrorResponse, TaskLogsResponse]]:
    """Get task logs

     Get stdout/stderr logs for a task from Loki. Supports pagination via cursor-based navigation.

    Args:
        id (int):
        cluster_name (str):
        log_type (Union[Unset, GetTaskLogsLogType]):  Default: GetTaskLogsLogType.ALL.
        start (Union[Unset, str]):
        end (Union[Unset, str]):
        limit (Union[Unset, int]):  Default: 1000.
        direction (Union[Unset, GetTaskLogsDirection]):  Default: GetTaskLogsDirection.BACKWARD.
        cursor (Union[Unset, str]):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[ErrorResponse, TaskLogsResponse]
    """

    return (
        await asyncio_detailed(
            id=id,
            client=client,
            cluster_name=cluster_name,
            log_type=log_type,
            start=start,
            end=end,
            limit=limit,
            direction=direction,
            cursor=cursor,
        )
    ).parsed
