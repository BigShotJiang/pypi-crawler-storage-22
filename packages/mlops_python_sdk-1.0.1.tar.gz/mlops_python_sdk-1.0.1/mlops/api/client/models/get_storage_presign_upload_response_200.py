from collections.abc import Mapping
from typing import Any, TypeVar, Union

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="GetStoragePresignUploadResponse200")


@_attrs_define
class GetStoragePresignUploadResponse200:
    """
    Attributes:
        key (Union[Unset, str]): Object key Example: uploads/20230101/123000_1234_test.zip.
        s3_url (Union[Unset, str]): S3 URL (s3://bucket/key) in S3 Example: s3://my-
            bucket/uploads/20230101/123000_1234_test.zip.
        url (Union[Unset, str]): The presigned URL for uploading the file Example:
            https://s3.example.com/bucket/uploads/20230101/123000_1234_test.zip?signature=....
    """

    key: Union[Unset, str] = UNSET
    s3_url: Union[Unset, str] = UNSET
    url: Union[Unset, str] = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        key = self.key

        s3_url = self.s3_url

        url = self.url

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if key is not UNSET:
            field_dict["key"] = key
        if s3_url is not UNSET:
            field_dict["s3_url"] = s3_url
        if url is not UNSET:
            field_dict["url"] = url

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        key = d.pop("key", UNSET)

        s3_url = d.pop("s3_url", UNSET)

        url = d.pop("url", UNSET)

        get_storage_presign_upload_response_200 = cls(
            key=key,
            s3_url=s3_url,
            url=url,
        )

        get_storage_presign_upload_response_200.additional_properties = d
        return get_storage_presign_upload_response_200

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
