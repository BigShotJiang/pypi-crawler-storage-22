from enum import Enum


class GetTaskLogsLogType(str, Enum):
    ALL = "all"
    STDERR = "stderr"
    STDOUT = "stdout"

    def __str__(self) -> str:
        return str(self.value)
