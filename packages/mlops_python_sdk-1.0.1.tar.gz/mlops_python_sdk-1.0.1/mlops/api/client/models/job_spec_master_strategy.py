from enum import Enum


class JobSpecMasterStrategy(str, Enum):
    FIRST_NODE = "first_node"

    def __str__(self) -> str:
        return str(self.value)
