from collections.abc import Mapping
from typing import Any, TypeVar, Union, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="LogPagination")


@_attrs_define
class LogPagination:
    """Pagination information for logs

    Attributes:
        has_more (Union[Unset, bool]): Whether there are more logs available Example: True.
        next_cursor (Union[None, Unset, str]): Cursor for the next page (timestamp in nanoseconds) Example:
            1706612400123456789.
        total_fetched (Union[Unset, int]): Number of log entries fetched in this request Example: 1000.
    """

    has_more: Union[Unset, bool] = UNSET
    next_cursor: Union[None, Unset, str] = UNSET
    total_fetched: Union[Unset, int] = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        has_more = self.has_more

        next_cursor: Union[None, Unset, str]
        if isinstance(self.next_cursor, Unset):
            next_cursor = UNSET
        else:
            next_cursor = self.next_cursor

        total_fetched = self.total_fetched

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if has_more is not UNSET:
            field_dict["has_more"] = has_more
        if next_cursor is not UNSET:
            field_dict["next_cursor"] = next_cursor
        if total_fetched is not UNSET:
            field_dict["total_fetched"] = total_fetched

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        has_more = d.pop("has_more", UNSET)

        def _parse_next_cursor(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        next_cursor = _parse_next_cursor(d.pop("next_cursor", UNSET))

        total_fetched = d.pop("total_fetched", UNSET)

        log_pagination = cls(
            has_more=has_more,
            next_cursor=next_cursor,
            total_fetched=total_fetched,
        )

        log_pagination.additional_properties = d
        return log_pagination

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
