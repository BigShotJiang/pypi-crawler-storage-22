import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, Union

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.task_log_entry_log_type import TaskLogEntryLogType
from ..types import UNSET, Unset

T = TypeVar("T", bound="TaskLogEntry")


@_attrs_define
class TaskLogEntry:
    """A single log entry

    Attributes:
        content (Union[Unset, str]): Log line content Example: Training epoch 1/100....
        log_type (Union[Unset, TaskLogEntryLogType]): Log type (stdout or stderr) Example: stdout.
        node (Union[Unset, str]): Node hostname where the log was generated Example: compute-node-01.
        timestamp (Union[Unset, datetime.datetime]): Log timestamp in RFC3339 format Example:
            2024-01-30T10:30:00.123456789Z.
    """

    content: Union[Unset, str] = UNSET
    log_type: Union[Unset, TaskLogEntryLogType] = UNSET
    node: Union[Unset, str] = UNSET
    timestamp: Union[Unset, datetime.datetime] = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        content = self.content

        log_type: Union[Unset, str] = UNSET
        if not isinstance(self.log_type, Unset):
            log_type = self.log_type.value

        node = self.node

        timestamp: Union[Unset, str] = UNSET
        if not isinstance(self.timestamp, Unset):
            timestamp = self.timestamp.isoformat()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if content is not UNSET:
            field_dict["content"] = content
        if log_type is not UNSET:
            field_dict["log_type"] = log_type
        if node is not UNSET:
            field_dict["node"] = node
        if timestamp is not UNSET:
            field_dict["timestamp"] = timestamp

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        content = d.pop("content", UNSET)

        _log_type = d.pop("log_type", UNSET)
        log_type: Union[Unset, TaskLogEntryLogType]
        if isinstance(_log_type, Unset):
            log_type = UNSET
        else:
            log_type = TaskLogEntryLogType(_log_type)

        node = d.pop("node", UNSET)

        _timestamp = d.pop("timestamp", UNSET)
        timestamp: Union[Unset, datetime.datetime]
        if isinstance(_timestamp, Unset):
            timestamp = UNSET
        else:
            timestamp = isoparse(_timestamp)

        task_log_entry = cls(
            content=content,
            log_type=log_type,
            node=node,
            timestamp=timestamp,
        )

        task_log_entry.additional_properties = d
        return task_log_entry

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
