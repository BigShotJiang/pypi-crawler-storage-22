from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, Union

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.log_pagination import LogPagination
    from ..models.task_log_entry import TaskLogEntry


T = TypeVar("T", bound="TaskLogsResponse")


@_attrs_define
class TaskLogsResponse:
    """Task logs response with pagination support

    Attributes:
        cluster_id (Union[Unset, int]): Cluster ID Example: 1.
        job_id (Union[Unset, int]): Slurm Job ID Example: 12345.
        logs (Union[Unset, list['TaskLogEntry']]): List of log entries
        pagination (Union[Unset, LogPagination]): Pagination information for logs
    """

    cluster_id: Union[Unset, int] = UNSET
    job_id: Union[Unset, int] = UNSET
    logs: Union[Unset, list["TaskLogEntry"]] = UNSET
    pagination: Union[Unset, "LogPagination"] = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        cluster_id = self.cluster_id

        job_id = self.job_id

        logs: Union[Unset, list[dict[str, Any]]] = UNSET
        if not isinstance(self.logs, Unset):
            logs = []
            for logs_item_data in self.logs:
                logs_item = logs_item_data.to_dict()
                logs.append(logs_item)

        pagination: Union[Unset, dict[str, Any]] = UNSET
        if not isinstance(self.pagination, Unset):
            pagination = self.pagination.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if cluster_id is not UNSET:
            field_dict["cluster_id"] = cluster_id
        if job_id is not UNSET:
            field_dict["job_id"] = job_id
        if logs is not UNSET:
            field_dict["logs"] = logs
        if pagination is not UNSET:
            field_dict["pagination"] = pagination

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.log_pagination import LogPagination
        from ..models.task_log_entry import TaskLogEntry

        d = dict(src_dict)
        cluster_id = d.pop("cluster_id", UNSET)

        job_id = d.pop("job_id", UNSET)

        logs = []
        _logs = d.pop("logs", UNSET)
        for logs_item_data in _logs or []:
            logs_item = TaskLogEntry.from_dict(logs_item_data)

            logs.append(logs_item)

        _pagination = d.pop("pagination", UNSET)
        pagination: Union[Unset, LogPagination]
        if isinstance(_pagination, Unset):
            pagination = UNSET
        else:
            pagination = LogPagination.from_dict(_pagination)

        task_logs_response = cls(
            cluster_id=cluster_id,
            job_id=job_id,
            logs=logs,
            pagination=pagination,
        )

        task_logs_response.additional_properties = d
        return task_logs_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
