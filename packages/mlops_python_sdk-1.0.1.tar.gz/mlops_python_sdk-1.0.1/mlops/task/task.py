"""
High-level Task SDK interface for MLOps.

This module provides a convenient interface for managing tasks through the MLOps API.
""" 

import json
import os
from http import HTTPStatus
from pathlib import Path
from typing import Optional

import httpx

from ..api.client.api.tasks import (
    submit_task,
    get_task,
    list_tasks,
    cancel_task,
    delete_task,
)
from ..api.client.api.storage import (
    get_storage_presign_upload,
    get_storage_presign_download,
)
from ..api.client.models.task import Task as TaskModel
from ..api.client.models.task_submit_request import TaskSubmitRequest
from ..api.client.models.task_submit_request_environment_type_0 import (
    TaskSubmitRequestEnvironmentType0,
)
from ..api.client.models.task_submit_response import TaskSubmitResponse
from ..api.client.models.task_list_response import TaskListResponse
from ..api.client.models.task_status import TaskStatus
from ..api.client.models.error_response import ErrorResponse
from ..api.client.types import Response, UNSET, UNSET
from ..connection_config import ConnectionConfig
from ..exceptions import (
    NotFoundException,
    APIException,
)
from .client import TaskClient, handle_api_exception


def _validate_archive_file_path(file_path: str) -> Path:
    p = Path(os.path.expanduser(file_path)).resolve()
    if not p.exists():
        raise APIException(f"File not found: {p}")
    if not p.is_file():
        raise APIException(f"file_path must be a file: {p}")

    lower = p.name.lower()
    if not (lower.endswith(".zip") or lower.endswith(".tar.gz") or lower.endswith(".tgz")):
        raise APIException(f"file_path must be one of .zip, .tar.gz, .tgz: {p}")
    return p


def _upload_file_to_presigned_url(url: str, file_path: Path, timeout: Optional[float]) -> None:
    size = file_path.stat().st_size
    # Use a dedicated client for S3 presigned upload (avoid leaking API auth headers).
    with httpx.Client(timeout=timeout) as client:
        with file_path.open("rb") as f:
            resp = client.put(
                url,
                content=f,
                headers={
                    "Content-Length": str(size),
                    "Content-Type": "application/octet-stream",
                },
            )
    if resp.status_code < 200 or resp.status_code >= 300:
        body = (resp.text or "")[:2048]
        raise APIException(
            f"Failed to upload file to presigned url: HTTP {resp.status_code}: {body}"
        )


class Task:
    """
    High-level interface for managing tasks.
    
    Example:
        ```python
        from mlops import Task, ConnectionConfig
        
        config = ConnectionConfig(api_key="your_api_key")
        task = Task(config=config)
        
        # Submit a task with script
        result = task.submit(
            name="my-task",
            cluster_name="slurm-cn",
            script="#!/bin/bash\\necho 'Hello World'"
        )
        
        # Or submit with command
        result = task.submit(
            name="my-task",
            cluster_name="slurm-cn",
            command="echo 'Hello World'"
        )
        
        # Get task details
        task_info = task.get(task_id=result.job_id, cluster_name="slurm-cn")
        
        # List tasks
        tasks = task.list(status=TaskStatus.RUNNING)
        
        # Cancel a task
        task.cancel(task_id=result.job_id, cluster_name="slurm-cn")

        # Delete a task
        task.delete(task_id=result.job_id, cluster_name="slurm-cn")
        ```
    """

    def __init__(
        self,
        config: Optional["ConnectionConfig"] = None,
        api_key: Optional[str] = None,
        domain: Optional[str] = None,
        debug: Optional[bool] = None,
        request_timeout: Optional[float] = None,
    ):
        """
        Initialize the Task client.

        Args:
            config: ConnectionConfig instance. If not provided, a new one will be created.
            api_key: API key for authentication. Overrides config.api_key.
            domain: API domain. Overrides config.domain.
            debug: Enable debug mode. Overrides config.debug.
            request_timeout: Request timeout in seconds. Overrides config.request_timeout.
        """

        if config is None:
            config = ConnectionConfig()

        # Override config values if provided
        if api_key is not None:
            config.api_key = api_key
        if domain is not None:
            config.domain = domain
        if debug is not None:
            config.debug = debug
        if request_timeout is not None:
            config.request_timeout = request_timeout

        self._config = config
        self._client = TaskClient(config=config)
    def submit(
        self,
        name: str,
        cluster_name: str,
        script: Optional[str] = None,
        command: Optional[str] = None,
        resources: Optional[dict] = None,
        team_id: Optional[int] = None,
        file_path: Optional[str] = None,
    ) -> TaskSubmitResponse:
        """
        Submit a new task.

        Args:
            name: Task name
            cluster_name: Cluster name to submit the task to
            script: Task script content (optional, but at least one of script or command is required)
            command: Command to execute (optional, but at least one of script or command is required)
            resources: Resource requirements dict (optional)
            team_id: Team ID (optional)

        Returns:
            TaskSubmitResponse containing the submitted task information

        Raises:
            APIException: If the API returns an error
            AuthenticationException: If authentication fails
        """
        # At least one of script or command must be provided
        if not script and not command:
            raise APIException("At least one of 'script' or 'command' must be provided")
        
        # Map resources dict to individual fields
        # resources dict can contain: cpu, cpus_per_task, memory, nodes, gres, time, partition, etc.

        request_kwargs = {
            "name": name,
            "cluster_name": cluster_name,
        }
        
        # Handle script and command (at least one is required)
        # script is Union[Unset, str], so we need to set it or leave as UNSET
        if script:
            request_kwargs["script"] = script
        # command is Union[None, Unset, str], so we can set it or leave as UNSET
        if command:
            request_kwargs["command"] = command
        
        # team_id is Union[None, Unset, int]
        if team_id is not None:
            request_kwargs["team_id"] = team_id
        
        # Map resources dict to TaskSubmitRequest fields
        if resources:
            if "cpu" in resources or "cpus_per_task" in resources:
                request_kwargs["cpus_per_task"] = resources.get("cpus_per_task") or resources.get("cpu")
            if "memory" in resources:
                request_kwargs["memory"] = resources.get("memory")
            if "nodes" in resources:
                request_kwargs["nodes"] = resources.get("nodes")
            if "gres" in resources:
                request_kwargs["gres"] = resources.get("gres")
            if "time" in resources:
                request_kwargs["time"] = resources.get("time")
            if "partition" in resources:
                request_kwargs["partition"] = resources.get("partition")
            if "tres" in resources:
                request_kwargs["tres"] = resources.get("tres")

        if file_path:
            local_path = _validate_archive_file_path(file_path)
            timeout = self._config.get_request_timeout()

            # 1) Get presigned upload URL
            presign_upload_obj = get_storage_presign_upload.sync_detailed(
                client=self._client,
                filename=local_path.name,
            )
            presign_upload = presign_upload_obj.parsed
            if isinstance(presign_upload, ErrorResponse):
                status_code = (
                    presign_upload.code
                    if presign_upload.code != UNSET and presign_upload.code != 0
                    else presign_upload_obj.status_code.value
                )
                exception = handle_api_exception(
                    Response(
                        status_code=HTTPStatus(status_code),
                        content=presign_upload_obj.content,
                        headers=presign_upload_obj.headers,
                        parsed=None,
                    )
                )
                raise exception

            if (
                presign_upload is None
                or presign_upload.url in (UNSET, None)
                or presign_upload.key in (UNSET, None)
            ):
                raise APIException("Failed to get presigned upload url: empty response")

            # 2) Upload file to S3 (presigned URL)
            _upload_file_to_presigned_url(
                url=str(presign_upload.url),
                file_path=local_path,
                timeout=timeout,
            )

            # 3) Get presigned download URL
            presign_download_obj = get_storage_presign_download.sync_detailed(
                client=self._client,
                key=str(presign_upload.key),
            )
            presign_download = presign_download_obj.parsed
            if isinstance(presign_download, ErrorResponse):
                status_code = (
                    presign_download.code
                    if presign_download.code != UNSET and presign_download.code != 0
                    else presign_download_obj.status_code.value
                )
                exception = handle_api_exception(
                    Response(
                        status_code=HTTPStatus(status_code),
                        content=presign_download_obj.content,
                        headers=presign_download_obj.headers,
                        parsed=None,
                    )
                )
                raise exception

            if presign_download is None or presign_download.url in (UNSET, None):
                raise APIException(
                    "Failed to get presigned download url: empty response"
                )

            # 4) Set env var (merge if user already provided environment)
            env: dict[str, str] = {}
            existing_env = request_kwargs.get("environment")
            if isinstance(existing_env, TaskSubmitRequestEnvironmentType0):
                env.update(existing_env.additional_properties)
            elif isinstance(existing_env, dict):
                env.update(existing_env)

            env["SYSTEM_DOWNLOAD_ARCHIVE_URL"] = str(presign_download.url)
            request_kwargs["environment"] = TaskSubmitRequestEnvironmentType0.from_dict(
                env
            )

        request = TaskSubmitRequest(**request_kwargs)

        # Use sync_detailed to get full response information
        response_obj = submit_task.sync_detailed(client=self._client, body=request)
        response = response_obj.parsed

        if isinstance(response, ErrorResponse):
            # Check status code to determine exception type
            status_code = response.code if response.code != UNSET and response.code != 0 else response_obj.status_code.value
            
            # Extract error message from ErrorResponse
            error_msg = "Unknown error"
            if response.error and response.error != UNSET:
                error_msg = response.error
            elif response_obj.content:
                try:
                    error_data = json.loads(response_obj.content.decode())
                    error_msg = error_data.get("error", "Unknown error")
                except (json.JSONDecodeError, UnicodeDecodeError):
                    error_msg = response_obj.content.decode(errors="replace")
            
            # Raise appropriate exception based on status code
            if status_code == 404:
                raise NotFoundException(error_msg)
            
            # Use handle_api_exception which returns an exception object
            exception = handle_api_exception(
                Response(
                    status_code=HTTPStatus(status_code),
                    content=response_obj.content,
                    headers=response_obj.headers,
                    parsed=None,
                )
            )
            raise exception

        if response is None:
            # If response is None, try to extract error from raw response
            error_msg = "No response from server"
            if response_obj.content:
                try:
                    error_data = json.loads(response_obj.content.decode())
                    error_msg = error_data.get("error", f"HTTP {response_obj.status_code.value}: {response_obj.content.decode()}")
                except (json.JSONDecodeError, UnicodeDecodeError):
                    error_msg = f"HTTP {response_obj.status_code.value}: {response_obj.content.decode(errors='replace')}"
            raise APIException(f"Failed to submit task: {error_msg}")

        return response

    def get(
        self,
        task_id: int,
        cluster_name: str,
    ) -> TaskModel:
        """
        Get task details by task ID.

        Args:
            task_id: Task ID
            cluster_name: Cluster name

        Returns:
            Task model with task details

        Raises:
            NotFoundException: If the task is not found
            APIException: If the API returns an error
        """
        # Use sync_detailed to get full response information
        response_obj = get_task.sync_detailed(
            id=task_id,
            client=self._client,
            cluster_name=cluster_name,
        )
        response = response_obj.parsed

        if isinstance(response, ErrorResponse):
            # Extract error message from ErrorResponse
            error_msg = f"Task {task_id} not found"
            if response.error and response.error != UNSET:
                error_msg = response.error
            elif response_obj.content:
                try:
                    error_data = json.loads(response_obj.content.decode())
                    error_msg = error_data.get("error", error_msg)
                except (json.JSONDecodeError, UnicodeDecodeError):
                    error_msg = response_obj.content.decode(errors="replace")
            
            # Check status code to determine exception type
            status_code = response.code if response.code != UNSET and response.code != 0 else response_obj.status_code.value
            if status_code == 404:
                raise NotFoundException(error_msg)
            
            # Use handle_api_exception which returns an exception object
            exception = handle_api_exception(
                Response(
                    status_code=HTTPStatus(status_code),
                    content=response_obj.content,
                    headers=response_obj.headers,
                    parsed=None,
                )
            )
            raise exception

        if response is None:
            # If response is None, try to extract error from raw response
            error_msg = f"Task {task_id} not found"
            if response_obj.content:
                try:
                    error_data = json.loads(response_obj.content.decode())
                    error_msg = error_data.get("error", f"HTTP {response_obj.status_code.value}: {response_obj.content.decode()}")
                except (json.JSONDecodeError, UnicodeDecodeError):
                    error_msg = f"HTTP {response_obj.status_code.value}: {response_obj.content.decode(errors='replace')}"
            raise NotFoundException(error_msg)

        return response

    def list(
        self,
        page: int = 1,
        page_size: int = 20,
        status: Optional[TaskStatus] = None,
        user_id: Optional[int] = None,
        team_id: Optional[int] = None,
        cluster_name: Optional[str] = None,
    ) -> TaskListResponse:
        """
        List tasks with optional filtering.

        Args:
            page: Page number (default: 1)
            page_size: Number of items per page (default: 20)
            status: Filter by task status (optional)
            user_id: Filter by user ID (optional)
            team_id: Filter by team ID (optional)
            cluster_name: Filter by cluster name (optional)

        Returns:
            TaskListResponse containing the list of tasks

        Raises:
            APIException: If the API returns an error
        """
        # Use sync_detailed to get full response information
        response_obj = list_tasks.sync_detailed(
            client=self._client,
            page=page,
            page_size=page_size,
            status=status if status is not None else UNSET,
            user_id=user_id if user_id is not None else UNSET,
            team_id=team_id if team_id is not None else UNSET,
            cluster_name=cluster_name if cluster_name is not None else UNSET,
        )
        response = response_obj.parsed

        if isinstance(response, ErrorResponse):
            # Extract error message from ErrorResponse
            error_msg = "Unknown error"
            if response.error and response.error != UNSET:
                error_msg = response.error
            elif response_obj.content:
                try:
                    error_data = json.loads(response_obj.content.decode())
                    error_msg = error_data.get("error", "Unknown error")
                except (json.JSONDecodeError, UnicodeDecodeError):
                    error_msg = response_obj.content.decode(errors="replace")
            
            # Check status code to determine exception type
            status_code = response.code if response.code != UNSET and response.code != 0 else response_obj.status_code.value
            if status_code == 404:
                raise NotFoundException(error_msg)
            
            # Use handle_api_exception which returns an exception object
            exception = handle_api_exception(
                Response(
                    status_code=HTTPStatus(status_code),
                    content=response_obj.content,
                    headers=response_obj.headers,
                    parsed=None,
                )
            )
            raise exception

        if response is None:
            # If response is None, try to extract error from raw response
            error_msg = "No response from server"
            if response_obj.content:
                try:
                    error_data = json.loads(response_obj.content.decode())
                    error_msg = error_data.get("error", f"HTTP {response_obj.status_code.value}: {response_obj.content.decode()}")
                except (json.JSONDecodeError, UnicodeDecodeError):
                    error_msg = f"HTTP {response_obj.status_code.value}: {response_obj.content.decode(errors='replace')}"
            raise APIException(f"Failed to list tasks: {error_msg}")

        return response

    def cancel(
        self,
        task_id: int,
        cluster_name: str,
    ) -> bool:
        """
        Cancel a task.

        Args:
            task_id: Task ID to cancel
            cluster_name: Cluster name where the task is running

        Returns:
            True if the task was cancelled successfully

        Raises:
            NotFoundException: If the task is not found
            APIException: If the API returns an error
        """
        # Use sync_detailed to get full response information
        response_obj = cancel_task.sync_detailed(
            id=task_id,
            client=self._client,
            cluster_name=cluster_name,
        )
        response = response_obj.parsed

        if isinstance(response, ErrorResponse):
            # Extract error message from ErrorResponse
            error_msg = f"Task {task_id} not found"
            if response.error and response.error != UNSET:
                error_msg = response.error
            elif response_obj.content:
                try:
                    error_data = json.loads(response_obj.content.decode())
                    error_msg = error_data.get("error", error_msg)
                except (json.JSONDecodeError, UnicodeDecodeError):
                    error_msg = response_obj.content.decode(errors="replace")
            
            # Check status code to determine exception type
            status_code = response.code if response.code != UNSET and response.code != 0 else response_obj.status_code.value
            if status_code == 404:
                raise NotFoundException(error_msg)
            
            # Use handle_api_exception which returns an exception object
            exception = handle_api_exception(
                Response(
                    status_code=HTTPStatus(status_code),
                    content=response_obj.content,
                    headers=response_obj.headers,
                    parsed=None,
                )
            )
            raise exception

        return response is not None

    def delete(
        self,
        task_id: int,
        cluster_name: str,
    ) -> bool:
        """
        Delete a task.

        Args:
            task_id: Task ID to delete
            cluster_name: Cluster name where the task is running

        Returns:
            True if the task was deleted successfully

        Raises:
            NotFoundException: If the task is not found
            APIException: If the API returns an error
        """
        # Use sync_detailed to get full response information
        response_obj = delete_task.sync_detailed(
            id=task_id,
            client=self._client,
            cluster_name=cluster_name,
        )
        response = response_obj.parsed

        if isinstance(response, ErrorResponse):
            # Extract error message from ErrorResponse
            error_msg = f"Task {task_id} not found"
            if response.error and response.error != UNSET:
                error_msg = response.error
            elif response_obj.content:
                try:
                    error_data = json.loads(response_obj.content.decode())
                    error_msg = error_data.get("error", error_msg)
                except (json.JSONDecodeError, UnicodeDecodeError):
                    error_msg = response_obj.content.decode(errors="replace")
            
            # Check status code to determine exception type
            status_code = response.code if response.code != UNSET and response.code != 0 else response_obj.status_code.value
            if status_code == 404:
                raise NotFoundException(error_msg)
            
            # Use handle_api_exception which returns an exception object
            exception = handle_api_exception(
                Response(
                    status_code=HTTPStatus(response.code if response.code != 0 else 400),
                    content=json.dumps({"error": response.error}).encode() if response.error else b"",
                    headers={},
                    parsed=None,
                )
            )
            raise exception

        if response is None:
            raise APIException("Failed to delete task: No response from server")

        return response is not None