"""
High-level Task SDK interface for MLOps.

This module provides a convenient interface for managing tasks through the MLOps API.
""" 

import json
import os
import shutil
import sys
import threading
import tempfile
import time
import zipfile
from http import HTTPStatus
from pathlib import Path
from typing import Callable, Optional

import httpx

from ..api.client.api.tasks import (
    submit_task,
    get_task,
    list_tasks,
    cancel_task,
    delete_task,
)
from ..api.client.api.storage import (
    get_storage_presign_upload,
    get_storage_presign_download,
)
from ..api.client.models.task import Task as TaskModel
from ..api.client.models.task_submit_request import TaskSubmitRequest
from ..api.client.models.task_submit_request_environment_type_0 import (
    TaskSubmitRequestEnvironmentType0,
)
from ..api.client.models.task_submit_response import TaskSubmitResponse
from ..api.client.models.task_list_response import TaskListResponse
from ..api.client.models.task_status import TaskStatus
from ..api.client.models.error_response import ErrorResponse
from ..api.client.types import Response, UNSET, UNSET
from ..connection_config import ConnectionConfig
from ..exceptions import (
    NotFoundException,
    APIException,
)
from .client import TaskClient, handle_api_exception


def _validate_archive_file_path(file_path: str) -> Path:
    p = Path(os.path.expanduser(file_path)).resolve()
    if not p.exists():
        raise APIException(f"File not found: {p}")
    if not p.is_file():
        raise APIException(f"file_path must be a file: {p}")

    lower = p.name.lower()
    if not (lower.endswith(".zip") or lower.endswith(".tar.gz") or lower.endswith(".tgz")):
        raise APIException(f"file_path must be one of .zip, .tar.gz, .tgz: {p}")
    return p

def _is_archive_path(p: Path) -> bool:
    lower = p.name.lower()
    return lower.endswith(".zip") or lower.endswith(".tar.gz") or lower.endswith(".tgz")


def _zip_directory(src_dir: Path, dst_zip: Path) -> None:
    src_dir = src_dir.resolve()
    root_name = src_dir.name
    with zipfile.ZipFile(dst_zip, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for p in src_dir.rglob("*"):
            if p.is_dir():
                continue
            rel = p.relative_to(src_dir).as_posix()
            if rel in ("", "."):
                continue
            zf.write(p, arcname=f"{root_name}/{rel}")


def _zip_file(src_file: Path, dst_zip: Path) -> None:
    src_file = src_file.resolve()
    with zipfile.ZipFile(dst_zip, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        zf.write(src_file, arcname=src_file.name)


def _path_to_archive_path(task_name: str, file_path: str) -> tuple[Path, Callable[[], None]]:
    """
    Mirror cli-go `pathToArchivePath` behavior:
    - directory: zip it
    - file: if already an archive (.zip/.tar.gz/.tgz) return as-is; otherwise zip it
    Returns (archive_path, cleanup_callable).
    """
    p = Path(os.path.expanduser(file_path)).resolve()
    if not p.exists():
        raise APIException(f"File not found: {p}")

    if p.is_dir():
        tmp_dir = (
            Path(tempfile.gettempdir())
            / "xservice-cli"
            / task_name
            / time.strftime("%Y%m%d%H%M%S")
        )
        tmp_dir.mkdir(parents=True, exist_ok=True)
        archive_path = tmp_dir / f"{p.name}.zip"
        try:
            _zip_directory(p, archive_path)
        except Exception as e:
            shutil.rmtree(tmp_dir, ignore_errors=True)
            raise APIException(f"failed to compress directory: {e}") from e
        return archive_path, lambda: shutil.rmtree(tmp_dir, ignore_errors=True)

    if not p.is_file():
        raise APIException(f"file_path must be a file or directory: {p}")

    if _is_archive_path(p):
        return _validate_archive_file_path(str(p)), lambda: None

    tmp_dir = (
        Path(tempfile.gettempdir())
        / "xservice-cli"
        / task_name
        / time.strftime("%Y%m%d%H%M%S")
    )
    tmp_dir.mkdir(parents=True, exist_ok=True)
    archive_path = tmp_dir / f"{p.name}.zip"
    try:
        _zip_file(p, archive_path)
    except Exception as e:
        shutil.rmtree(tmp_dir, ignore_errors=True)
        raise APIException(f"failed to compress file: {e}") from e
    return archive_path, lambda: shutil.rmtree(tmp_dir, ignore_errors=True)


def _upload_file_to_presigned_url(url: str, file_path: Path, timeout: Optional[float]) -> None:
    def _format_bytes_iec(n: int) -> str:
        if n < 1024:
            return f"{n}B"
        unit = 1024.0
        suffixes = ["KiB", "MiB", "GiB", "TiB", "PiB"]
        v = float(n)
        i = -1
        while v >= unit and i < len(suffixes) - 1:
            v /= unit
            i += 1
        return f"{v:.1f}{suffixes[i]}"

    def _render_bar(done: int, total: int, width: int = 28) -> str:
        if total <= 0 or width <= 1:
            return ">"
        done = max(0, min(done, total))
        filled = int(width * (done / total))
        if filled >= width:
            return "=" * width
        if filled <= 0:
            return ">" + (" " * (width - 1))
        return ("=" * filled) + ">" + (" " * (width - filled - 1))

    def _format_elapsed_seconds(start: float) -> str:
        sec = int(max(0.0, time.monotonic() - start))
        return f"{sec}s"

    class _ProgressIterable:
        def __init__(self, f, total: int, name: str, chunk_size: int = 64 * 1024):
            self._f = f  # file-like object
            self._total = max(0, int(total))
            self._name = name
            self._chunk_size = max(1, int(chunk_size))
            self._read = 0
            self._start = time.monotonic()
            self._completed = False
            self._out = sys.stdout
            try:
                self._is_tty = bool(self._out.isatty())
            except Exception:
                self._is_tty = False

        def _render_line(self, display_read: int) -> str:
            display_read = max(0, min(int(display_read), self._total))
            pct = (display_read / self._total) * 100.0 if self._total > 0 else 0.0
            bar = _render_bar(display_read, self._total, width=28)
            elapsed = _format_elapsed_seconds(self._start)
            return (
                f"uploading {self._name} [{bar}] {pct:6.2f}% "
                f"({_format_bytes_iec(display_read)}/{_format_bytes_iec(self._total)}) "
                f"elapsed {elapsed}"
            )

        def _print_line(self, line: str, final: bool = False) -> None:
            if self._is_tty:
                # Refresh same line in terminal.
                print("\r" + line, end="" if not final else "\n", file=self._out, flush=True)
            else:
                # Always visible in non-TTY environments.
                print(line, file=self._out, flush=True)

        def __iter__(self):
            stop_event = threading.Event()

            def ticker() -> None:
                last_sec = -1
                # Print immediately so users see something right away.
                self._print_line(self._render_line(self._read))
                while not stop_event.is_set():
                    sec = int(max(0.0, time.monotonic() - self._start))
                    if sec != last_sec:
                        last_sec = sec
                        self._print_line(self._render_line(self._read))
                    # check frequently to avoid skipping seconds
                    stop_event.wait(0.05)

            t = threading.Thread(target=ticker, name="mlops-upload-progress", daemon=True)
            t.start()
            try:
                while True:
                    chunk = self._f.read(self._chunk_size)
                    if not chunk:
                        break
                    self._read += len(chunk)
                    yield chunk
            finally:
                # Ensure a final 100% line and stop ticker.
                self._read = self._total
                self._completed = True
                stop_event.set()
                t.join(timeout=0.2)
                self._print_line(self._render_line(self._read), final=True)

    size = file_path.stat().st_size
    # Use a dedicated client for S3 presigned upload (avoid leaking API auth headers).
    with httpx.Client(timeout=timeout) as client:
        with file_path.open("rb") as f:
            content = f
            if size > 0:
                content = _ProgressIterable(f, total=size, name=file_path.name)
            resp = client.put(
                url,
                content=content,
                headers={
                    "Content-Length": str(size),
                    "Content-Type": "application/octet-stream",
                },
            )
    if resp.status_code < 200 or resp.status_code >= 300:
        body = (resp.text or "")[:2048]
        raise APIException(
            f"Failed to upload file to presigned url: HTTP {resp.status_code}: {body}"
        )


class Task:
    """
    High-level interface for managing tasks.
    
    Example:
        ```python
        from mlops import Task, ConnectionConfig
        
        config = ConnectionConfig(api_key="your_api_key")
        task = Task(config=config)
        
        # Submit a task with gpu type
        result = task.submit(
            name="gpu-task-from-sdk",
            cluster_name="slurm-cn",
            image="/mnt/minio/images/01ai-registry.cn-shanghai.cr.aliyuncs.com+public+llamafactory+0.9.3.sqsh",
            entry_command="llamafactory-cli train /workspace/config/test_lora.yaml",
            resources={
                "partition": "gpu",
                "nodes": 2,
                "ntasks": 2,
                "cpus_per_task": 2,
                "memory": "4G",
                "time": "01:00:00",
                "gres": "gpu:nvidia_a10:1",
                "qos": "qos_xcloud",
                "job_type": "batch",
            },
            team_id=1,
            file_path="your file path",
        )
        
        # Get task details
        task_info = task.get(task_id=result.job_id, cluster_name="slurm-cn")
        
        # List tasks
        tasks = task.list(status=TaskStatus.RUNNING)
        
        # Cancel a task
        task.cancel(task_id=result.job_id, cluster_name="slurm-cn")

        # Delete a task
        task.delete(task_id=result.job_id, cluster_name="slurm-cn")
        ```
    """

    def __init__(
        self,
        config: Optional["ConnectionConfig"] = None,
        api_key: Optional[str] = None,
        domain: Optional[str] = None,
        debug: Optional[bool] = None,
        request_timeout: Optional[float] = None,
    ):
        """
        Initialize the Task client.

        Args:
            config: ConnectionConfig instance. If not provided, a new one will be created.
            api_key: API key for authentication. Overrides config.api_key.
            domain: API domain. Overrides config.domain.
            debug: Enable debug mode. Overrides config.debug.
            request_timeout: Request timeout in seconds. Overrides config.request_timeout.
        """

        if config is None:
            config = ConnectionConfig()

        # Override config values if provided
        if api_key is not None:
            config.api_key = api_key
        if domain is not None:
            config.domain = domain
            config.build_api_url()
        if debug is not None:
            config.debug = debug
        if request_timeout is not None:
            config.request_timeout = request_timeout

        self._config = config
        self._client = TaskClient(config=config)
    def submit(
        self,
        name: str,
        cluster_name: str,
        image: str,
        entry_command: str,
        resources: Optional[dict] = None,
        team_id: Optional[int] = None,
        file_path: Optional[str] = None,
    ) -> TaskSubmitResponse:
        """
        Submit a new task.

        Args:
            name: Task name
            cluster_name: Cluster name to submit the task to
            image: Container image reference
            entry_command: Container entry command/script
            resources: Resource requirements dict (optional)
            team_id: Team ID (optional)
            file_path: Local file path to upload (optional, support for .zip, .tar.gz, .tgz)
        Returns:
            TaskSubmitResponse containing the submitted task information

        Raises:
            APIException: If the API returns an error
            AuthenticationException: If authentication fails
        """
        request_kwargs = {
            "name": name,
            "cluster_name": cluster_name,
            "image": image,
            "entry_command": entry_command,
        }
        # Map resources dict to individual fields
        # resources dict can contain: cpu, cpus_per_task, memory, nodes, gres, time, partition, etc.
        
        # team_id is Union[None, Unset, int]
        if team_id is not None:
            request_kwargs["team_id"] = team_id
        
        # Map resources dict to TaskSubmitRequest fields
        if resources:
            if "cpu" in resources or "cpus_per_task" in resources:
                request_kwargs["cpus_per_task"] = resources.get("cpus_per_task") or resources.get("cpu")
            else:
                request_kwargs["cpus_per_task"] = 1
            if "memory" in resources:
                request_kwargs["memory"] = resources.get("memory")
            else: 
                request_kwargs["memory"] = "1G"
            if "nodes" in resources:
                request_kwargs["nodes"] = resources.get("nodes")
            else:
                request_kwargs["nodes"] = 1
            if "gres" in resources:
                request_kwargs["gres"] = resources.get("gres")
            if "time" in resources:
                request_kwargs["time"] = resources.get("time")
            else:
                request_kwargs["time"] = "01:00:00"
            if "partition" in resources:
                request_kwargs["partition"] = resources.get("partition")
            else:
                request_kwargs["partition"] = "debug"
            if "qos" in resources:
                request_kwargs["qos"] = resources.get("qos")
            else:
                request_kwargs["qos"] = "qos_xcloud"
            if "ntasks" in resources:
                request_kwargs["ntasks"] = resources.get("ntasks")
            else:
                request_kwargs["ntasks"] = 1

        if file_path:
            local_path, cleanup = _path_to_archive_path(name, file_path)
            timeout = self._config.get_request_timeout()
            try:
                # 1) Get presigned upload URL
                presign_upload_obj = get_storage_presign_upload.sync_detailed(
                    client=self._client,
                    filename=local_path.name,
                )
                presign_upload = presign_upload_obj.parsed
                if isinstance(presign_upload, ErrorResponse):
                    status_code = (
                        presign_upload.code
                        if presign_upload.code != UNSET and presign_upload.code != 0
                        else presign_upload_obj.status_code.value
                    )
                    exception = handle_api_exception(
                        Response(
                            status_code=HTTPStatus(status_code),
                            content=presign_upload_obj.content,
                            headers=presign_upload_obj.headers,
                            parsed=None,
                        )
                    )
                    raise exception

                if (
                    presign_upload is None
                    or presign_upload.url in (UNSET, None)
                    or presign_upload.key in (UNSET, None)
                ):
                    raise APIException("Failed to get presigned upload url: empty response")

                # 2) Upload file to S3 (presigned URL)
                _upload_file_to_presigned_url(
                    url=str(presign_upload.url),
                    file_path=local_path,
                    timeout=timeout,
                )

                # 3) Get presigned download URL
                presign_download_obj = get_storage_presign_download.sync_detailed(
                    client=self._client,
                    key=str(presign_upload.key),
                )
                presign_download = presign_download_obj.parsed
                if isinstance(presign_download, ErrorResponse):
                    status_code = (
                        presign_download.code
                        if presign_download.code != UNSET and presign_download.code != 0
                        else presign_download_obj.status_code.value
                    )
                    exception = handle_api_exception(
                        Response(
                            status_code=HTTPStatus(status_code),
                            content=presign_download_obj.content,
                            headers=presign_download_obj.headers,
                            parsed=None,
                        )
                    )
                    raise exception

                if presign_download is None or presign_download.url in (UNSET, None):
                    raise APIException("Failed to get presigned download url: empty response")

                # 4) Set env var (merge if user already provided environment)
                env: dict[str, str] = {}
                existing_env = request_kwargs.get("environment")
                if isinstance(existing_env, TaskSubmitRequestEnvironmentType0):
                    env.update(existing_env.additional_properties)
                elif isinstance(existing_env, dict):
                    env.update(existing_env)

                env["SYSTEM_DOWNLOAD_ARCHIVE_URL"] = str(presign_download.url)
                request_kwargs["environment"] = TaskSubmitRequestEnvironmentType0.from_dict(env)
            finally:
                cleanup()

        request = TaskSubmitRequest(**request_kwargs)

        # Use sync_detailed to get full response information
        response_obj = submit_task.sync_detailed(client=self._client, body=request)
        response = response_obj.parsed

        if isinstance(response, ErrorResponse):
            # Check status code to determine exception type
            status_code = response.code if response.code != UNSET and response.code != 0 else response_obj.status_code.value
            
            # Extract error message from ErrorResponse
            error_msg = "Unknown error"
            if response.error and response.error != UNSET:
                error_msg = response.error
            elif response_obj.content:
                try:
                    error_data = json.loads(response_obj.content.decode())
                    error_msg = error_data.get("error", "Unknown error")
                except (json.JSONDecodeError, UnicodeDecodeError):
                    error_msg = response_obj.content.decode(errors="replace")
            
            # Raise appropriate exception based on status code
            if status_code == 404:
                raise NotFoundException(error_msg)
            
            # Use handle_api_exception which returns an exception object
            exception = handle_api_exception(
                Response(
                    status_code=HTTPStatus(status_code),
                    content=response_obj.content,
                    headers=response_obj.headers,
                    parsed=None,
                )
            )
            raise exception

        if response is None:
            # If response is None, try to extract error from raw response
            error_msg = "No response from server"
            if response_obj.content:
                try:
                    error_data = json.loads(response_obj.content.decode())
                    error_msg = error_data.get("error", f"HTTP {response_obj.status_code.value}: {response_obj.content.decode()}")
                except (json.JSONDecodeError, UnicodeDecodeError):
                    error_msg = f"HTTP {response_obj.status_code.value}: {response_obj.content.decode(errors='replace')}"
            raise APIException(f"Failed to submit task: {error_msg}")

        return response

    def get(
        self,
        task_id: int,
        cluster_name: str,
    ) -> TaskModel:
        """
        Get task details by task ID.

        Args:
            task_id: Task ID
            cluster_name: Cluster name

        Returns:
            Task model with task details

        Raises:
            NotFoundException: If the task is not found
            APIException: If the API returns an error
        """
        # Use sync_detailed to get full response information
        response_obj = get_task.sync_detailed(
            id=task_id,
            client=self._client,
            cluster_name=cluster_name,
        )
        response = response_obj.parsed

        if isinstance(response, ErrorResponse):
            # Extract error message from ErrorResponse
            error_msg = f"Task {task_id} not found"
            if response.error and response.error != UNSET:
                error_msg = response.error
            elif response_obj.content:
                try:
                    error_data = json.loads(response_obj.content.decode())
                    error_msg = error_data.get("error", error_msg)
                except (json.JSONDecodeError, UnicodeDecodeError):
                    error_msg = response_obj.content.decode(errors="replace")
            
            # Check status code to determine exception type
            status_code = response.code if response.code != UNSET and response.code != 0 else response_obj.status_code.value
            if status_code == 404:
                raise NotFoundException(error_msg)
            
            # Use handle_api_exception which returns an exception object
            exception = handle_api_exception(
                Response(
                    status_code=HTTPStatus(status_code),
                    content=response_obj.content,
                    headers=response_obj.headers,
                    parsed=None,
                )
            )
            raise exception

        if response is None:
            # If response is None, try to extract error from raw response
            error_msg = f"Task {task_id} not found"
            if response_obj.content:
                try:
                    error_data = json.loads(response_obj.content.decode())
                    error_msg = error_data.get("error", f"HTTP {response_obj.status_code.value}: {response_obj.content.decode()}")
                except (json.JSONDecodeError, UnicodeDecodeError):
                    error_msg = f"HTTP {response_obj.status_code.value}: {response_obj.content.decode(errors='replace')}"
            raise NotFoundException(error_msg)

        return response

    def list(
        self,
        page: int = 1,
        page_size: int = 20,
        status: Optional[TaskStatus] = None,
        user_id: Optional[int] = None,
        team_id: Optional[int] = None,
        cluster_name: Optional[str] = None,
    ) -> TaskListResponse:
        """
        List tasks with optional filtering.

        Args:
            page: Page number (default: 1)
            page_size: Number of items per page (default: 20)
            status: Filter by task status (optional)
            user_id: Filter by user ID (optional)
            team_id: Filter by team ID (optional)
            cluster_name: Filter by cluster name (optional)

        Returns:
            TaskListResponse containing the list of tasks

        Raises:
            APIException: If the API returns an error
        """
        # Use sync_detailed to get full response information
        response_obj = list_tasks.sync_detailed(
            client=self._client,
            page=page,
            page_size=page_size,
            status=status if status is not None else UNSET,
            user_id=user_id if user_id is not None else UNSET,
            team_id=team_id if team_id is not None else UNSET,
            cluster_name=cluster_name if cluster_name is not None else UNSET,
        )
        response = response_obj.parsed

        if isinstance(response, ErrorResponse):
            # Extract error message from ErrorResponse
            error_msg = "Unknown error"
            if response.error and response.error != UNSET:
                error_msg = response.error
            elif response_obj.content:
                try:
                    error_data = json.loads(response_obj.content.decode())
                    error_msg = error_data.get("error", "Unknown error")
                except (json.JSONDecodeError, UnicodeDecodeError):
                    error_msg = response_obj.content.decode(errors="replace")
            
            # Check status code to determine exception type
            status_code = response.code if response.code != UNSET and response.code != 0 else response_obj.status_code.value
            if status_code == 404:
                raise NotFoundException(error_msg)
            
            # Use handle_api_exception which returns an exception object
            exception = handle_api_exception(
                Response(
                    status_code=HTTPStatus(status_code),
                    content=response_obj.content,
                    headers=response_obj.headers,
                    parsed=None,
                )
            )
            raise exception

        if response is None:
            # If response is None, try to extract error from raw response
            error_msg = "No response from server"
            if response_obj.content:
                try:
                    error_data = json.loads(response_obj.content.decode())
                    error_msg = error_data.get("error", f"HTTP {response_obj.status_code.value}: {response_obj.content.decode()}")
                except (json.JSONDecodeError, UnicodeDecodeError):
                    error_msg = f"HTTP {response_obj.status_code.value}: {response_obj.content.decode(errors='replace')}"
            raise APIException(f"Failed to list tasks: {error_msg}")

        return response

    def cancel(
        self,
        task_id: int,
        cluster_name: str,
    ) -> bool:
        """
        Cancel a task.

        Args:
            task_id: Task ID to cancel
            cluster_name: Cluster name where the task is running

        Returns:
            True if the task was cancelled successfully

        Raises:
            NotFoundException: If the task is not found
            APIException: If the API returns an error
        """
        # Use sync_detailed to get full response information
        response_obj = cancel_task.sync_detailed(
            id=task_id,
            client=self._client,
            cluster_name=cluster_name,
        )
        response = response_obj.parsed

        if isinstance(response, ErrorResponse):
            # Extract error message from ErrorResponse
            error_msg = f"Task {task_id} not found"
            if response.error and response.error != UNSET:
                error_msg = response.error
            elif response_obj.content:
                try:
                    error_data = json.loads(response_obj.content.decode())
                    error_msg = error_data.get("error", error_msg)
                except (json.JSONDecodeError, UnicodeDecodeError):
                    error_msg = response_obj.content.decode(errors="replace")
            
            # Check status code to determine exception type
            status_code = response.code if response.code != UNSET and response.code != 0 else response_obj.status_code.value
            if status_code == 404:
                raise NotFoundException(error_msg)
            
            # Use handle_api_exception which returns an exception object
            exception = handle_api_exception(
                Response(
                    status_code=HTTPStatus(status_code),
                    content=response_obj.content,
                    headers=response_obj.headers,
                    parsed=None,
                )
            )
            raise exception

        return response is not None

    def delete(
        self,
        task_id: int,
        cluster_name: str,
    ) -> bool:
        """
        Delete a task.

        Args:
            task_id: Task ID to delete
            cluster_name: Cluster name where the task is running

        Returns:
            True if the task was deleted successfully

        Raises:
            NotFoundException: If the task is not found
            APIException: If the API returns an error
        """
        # Use sync_detailed to get full response information
        response_obj = delete_task.sync_detailed(
            id=task_id,
            client=self._client,
            cluster_name=cluster_name,
        )
        response = response_obj.parsed

        if isinstance(response, ErrorResponse):
            # Extract error message from ErrorResponse
            error_msg = f"Task {task_id} not found"
            if response.error and response.error != UNSET:
                error_msg = response.error
            elif response_obj.content:
                try:
                    error_data = json.loads(response_obj.content.decode())
                    error_msg = error_data.get("error", error_msg)
                except (json.JSONDecodeError, UnicodeDecodeError):
                    error_msg = response_obj.content.decode(errors="replace")
            
            # Check status code to determine exception type
            status_code = response.code if response.code != UNSET and response.code != 0 else response_obj.status_code.value
            if status_code == 404:
                raise NotFoundException(error_msg)
            
            # Use handle_api_exception which returns an exception object
            exception = handle_api_exception(
                Response(
                    status_code=HTTPStatus(response.code if response.code != 0 else 400),
                    content=json.dumps({"error": response.error}).encode() if response.error else b"",
                    headers={},
                    parsed=None,
                )
            )
            raise exception

        if response is None:
            raise APIException("Failed to delete task: No response from server")

        return response is not None