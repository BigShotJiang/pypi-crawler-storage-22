"""Implementation of relational database system catalog store."""

from __future__ import annotations

import typing
from typing import Any

from sqlalchemy.orm import DeclarativeBase, Session

import mlte.store.error as errors
from mlte.catalog.model import CatalogEntry
from mlte.store.catalog.store import CatalogStore
from mlte.store.catalog.store_session import (
    CatalogEntryMapper,
    CatalogStoreSession,
)
from mlte.store.catalog.underlying.rdbs.metadata import DBBase
from mlte.store.catalog.underlying.rdbs.reader import DBReader
from mlte.store.common.rdbs_storage import RDBStorage
from mlte.store.validators.cross_validator import CompositeValidator

# -----------------------------------------------------------------------------
# RelationalDBCatalogStore
# -----------------------------------------------------------------------------


class RelationalDBCatalogStore(CatalogStore):
    """A DB implementation of the MLTE user store."""

    def __init__(self, uri, **kwargs):
        super().__init__(uri=uri)

        self.storage = RDBStorage(
            uri,
            base_class=typing.cast(DeclarativeBase, DBBase),
            **kwargs,
        )
        """The relational DB storage."""

    def session(self) -> RelationalDBCatalogStoreSession:
        """
        Return a session handle for the store instance.
        :return: The session handle
        """
        return RelationalDBCatalogStoreSession(
            storage=self.storage,
            validators=self.validators,
            read_only=self.read_only,
        )


# -----------------------------------------------------------------------------
# RelationalDBCatalogStoreSession
# -----------------------------------------------------------------------------


class RelationalDBCatalogStoreSession(CatalogStoreSession):
    """A relational DB implementation of the MLTE user store session."""

    def __init__(
        self,
        storage: RDBStorage,
        validators: CompositeValidator,
        read_only: bool = False,
    ) -> None:
        self.storage = storage
        """RDB storage."""

        self.read_only = read_only
        """Whether this is read only or not."""

        self.entry_mapper = RDBEntryMapper(storage, validators=validators)
        """The mapper to user CRUD."""

    def close(self) -> None:
        """Close the session."""
        self.storage.close()


# -----------------------------------------------------------------------------
# RDBEntryMapper
# -----------------------------------------------------------------------------


class RDBEntryMapper(CatalogEntryMapper):
    """RDB mapper for a catalog entry resource."""

    def __init__(
        self, storage: RDBStorage, validators: CompositeValidator
    ) -> None:
        super().__init__(validators=validators)

        self.storage = storage
        """A reference to underlying storage."""

    def create(self, entry: CatalogEntry, context: Any = None) -> CatalogEntry:
        with Session(self.storage.engine) as session:
            try:
                _, _ = DBReader.get_entry(entry.header.identifier, session)
                raise errors.ErrorAlreadyExists(
                    f"Entry with id {entry.header.identifier} already exists."
                )
            except errors.ErrorNotFound:
                # If it was not found, it means we can create it.
                self.validators.validate_all(entry)
                entry_orm = DBReader._build_entry_orm(entry, session)
                session.add(entry_orm)
                session.commit()

                stored_entry, _ = DBReader.get_entry(
                    entry.header.identifier, session
                )
                return stored_entry

    def edit(self, entry: CatalogEntry, context: Any = None) -> CatalogEntry:
        self.validators.validate_all(entry)
        with Session(self.storage.engine) as session:
            _, entry_orm = DBReader.get_entry(entry.header.identifier, session)

            # Update existing user.
            entry_orm = DBReader._build_entry_orm(entry, session, entry_orm)
            session.commit()

            stored_entry, _ = DBReader.get_entry(
                entry.header.identifier, session
            )
            return stored_entry

    def read(self, entry_id: str, context: Any = None) -> CatalogEntry:
        with Session(self.storage.engine) as session:
            catalog_entry, _ = DBReader.get_entry(entry_id, session)
            return catalog_entry

    def list(self, context: Any = None) -> list[str]:
        with Session(self.storage.engine) as session:
            entries, _ = DBReader.get_entries(session)
            return [entry.header.identifier for entry in entries]

    def delete(self, entry_id: str, context: Any = None) -> CatalogEntry:
        with Session(self.storage.engine) as session:
            catalog_entry, entry_orm = DBReader.get_entry(entry_id, session)
            session.delete(entry_orm)
            session.commit()
            return catalog_entry
