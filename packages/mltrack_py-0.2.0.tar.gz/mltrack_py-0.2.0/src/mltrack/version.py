"""Version information for mltrack."""

__version__ = "0.1.0"