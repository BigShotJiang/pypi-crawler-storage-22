import inspect
from dataclasses import dataclass
from typing import Optional

from ..base import BaseModelConfig


@dataclass
class TextConfig(BaseModelConfig):
    model_type: str = "phi"
    hidden_size: int = 2048
    num_hidden_layers: int = 24
    intermediate_size: int = 8192
    num_attention_heads: int = 32
    num_key_value_heads: int = 32
    vocab_size: int = 51200
    max_position_embeddings: int = 2048
    rope_theta: float = 10000.0
    layer_norm_eps: float = 1e-5
    # Moondream uses partial RoPE - only first 32 dims (head_dim // 2)
    partial_rotary_factor: float = 0.5
    # Prefix attention length: BOS (1) + image patches (729) = 730
    prefix_attn_len: int = 730


@dataclass
class VisionConfig(BaseModelConfig):
    model_type: str = "moondream_vision"
    hidden_size: int = 1152  # enc_dim
    num_hidden_layers: int = 27  # enc_n_layers
    intermediate_size: int = 4304  # enc_ff_dim
    num_attention_heads: int = 16  # enc_n_heads
    image_size: int = 378  # crop_size
    patch_size: int = 14  # enc_patch_size
    num_channels: int = 3  # in_channels
    layer_norm_eps: float = 1e-5
    # Multi-crop settings (for future full implementation)
    max_crops: int = 12
    overlap_margin: int = 4


@dataclass
class ModelConfig(BaseModelConfig):
    text_config: TextConfig = None
    vision_config: VisionConfig = None
    model_type: str = "moondream1"
    # Projection MLP inner dimension
    proj_inner_dim: int = 8192
    # Image features are prepended after BOS token
    image_token_index: int = -200
    vocab_size: int = 51200
    # Prefix attention length: BOS (1) + image patches (729) = 730
    prefix_attn_len: int = 730
    # Token IDs (EOS and BOS are the same for moondream)
    eos_token_id: int = 0
    bos_token_id: int = 0

    def __post_init__(self):
        if self.text_config is None:
            self.text_config = TextConfig()
        if self.vision_config is None:
            self.vision_config = VisionConfig()

    @classmethod
    def from_dict(cls, params):
        # Extract nested configs
        text_config_dict = params.get("text_config", {})
        vision_config_dict = params.get("vision_config", {})

        # If text_config is empty, try to get from root level
        if not text_config_dict:
            text_config_dict = {
                k: v
                for k, v in params.items()
                if k in inspect.signature(TextConfig).parameters
            }

        # Create nested config objects
        text_config = TextConfig.from_dict(text_config_dict)
        vision_config = VisionConfig.from_dict(vision_config_dict)

        # Build the main config
        return cls(
            text_config=text_config,
            vision_config=vision_config,
            **{
                k: v
                for k, v in params.items()
                if k in inspect.signature(cls).parameters
                and k not in ("text_config", "vision_config")
            },
        )
