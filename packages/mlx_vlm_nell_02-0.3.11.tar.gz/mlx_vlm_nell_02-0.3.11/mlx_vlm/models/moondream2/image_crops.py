"""
Multi-crop image processing utilities for Moondream2.

Reference implementation: moondream2/image_crops.py
"""

import math
from typing import Tuple

import mlx.core as mx
import numpy as np
from PIL import Image


def select_tiling(
    height: int, width: int, crop_size: int, max_crops: int
) -> Tuple[int, int]:
    """
    Determine the optimal number of tiles to cover an image with overlapping crops.

    Ported from HF reference: moondream2/image_crops.py:17-50
    """
    if height <= crop_size or width <= crop_size:
        return (1, 1)

    # Minimum required tiles in each dimension
    min_h = math.ceil(height / crop_size)
    min_w = math.ceil(width / crop_size)

    # If minimum required tiles exceed max_crops, return proportional distribution
    if min_h * min_w > max_crops:
        ratio = math.sqrt(max_crops / (min_h * min_w))
        return (max(1, math.floor(min_h * ratio)), max(1, math.floor(min_w * ratio)))

    # Perfect aspect-ratio tiles that satisfy max_crops
    h_tiles = math.floor(math.sqrt(max_crops * height / width))
    w_tiles = math.floor(math.sqrt(max_crops * width / height))

    # Ensure we meet minimum tile requirements
    h_tiles = max(h_tiles, min_h)
    w_tiles = max(w_tiles, min_w)

    # If we exceeded max_crops, scale down the larger dimension
    if h_tiles * w_tiles > max_crops:
        if w_tiles > h_tiles:
            w_tiles = math.floor(max_crops / h_tiles)
        else:
            h_tiles = math.floor(max_crops / w_tiles)

    return (max(1, h_tiles), max(1, w_tiles))


def overlap_crop_image(
    image: np.ndarray,
    max_crops: int = 12,
    overlap_margin: int = 4,
    base_size: Tuple[int, int] = (378, 378),
    patch_size: int = 14,
) -> Tuple[np.ndarray, Tuple[int, int]]:
    """
    Create overlapping crops from an image for multi-scale processing.

    Ported from HF reference: moondream2/image_crops.py:58-167

    Args:
        image: Input image as numpy array [H, W, C] in range [0, 255]
        max_crops: Maximum number of local crops allowed (default 12)
        overlap_margin: Number of patches to overlap between adjacent crops (default 4)
        base_size: Size of each crop (default (378, 378))
        patch_size: Size of each patch for the vision encoder (default 14)

    Returns:
        crops: numpy array [n_crops, H, W, C] - crops[0] is global, rest are local
        tiling: (h_tiles, w_tiles) tuple describing the local crop layout
    """
    original_h, original_w = image.shape[:2]

    # Convert margin from patch units to pixels
    margin_pixels = patch_size * overlap_margin
    total_margin_pixels = margin_pixels * 2  # Both sides

    # Calculate crop parameters
    crop_patches = base_size[0] // patch_size  # patches per crop dimension
    crop_window_patches = crop_patches - (2 * overlap_margin)  # usable patches
    crop_window_size = crop_window_patches * patch_size  # usable size in pixels

    # Determine tiling using margin-adjusted dimensions and effective crop size
    tiling = select_tiling(
        original_h - total_margin_pixels,
        original_w - total_margin_pixels,
        crop_window_size,
        max_crops,
    )

    # Pre-allocate crops
    n_crops = tiling[0] * tiling[1] + 1  # +1 for global crop
    crops = np.zeros(
        (n_crops, base_size[0], base_size[1], image.shape[2]), dtype=np.uint8
    )

    # Resize image to fit tiling
    target_size = (
        tiling[0] * crop_window_size + total_margin_pixels,
        tiling[1] * crop_window_size + total_margin_pixels,
    )

    pil_image = Image.fromarray(image.astype(np.uint8))

    # Resize for local crops
    resized = pil_image.resize(
        (int(target_size[1]), int(target_size[0])),
        resample=Image.Resampling.LANCZOS,
    )
    image = np.asarray(resized)

    # Create global crop
    global_crop = pil_image.resize(
        (int(base_size[1]), int(base_size[0])),
        resample=Image.Resampling.LANCZOS,
    )
    crops[0] = np.asarray(global_crop)

    # Extract local crops
    for i in range(tiling[0]):
        for j in range(tiling[1]):
            y0 = i * crop_window_size
            x0 = j * crop_window_size

            y_end = min(y0 + base_size[0], image.shape[0])
            x_end = min(x0 + base_size[1], image.shape[1])

            crop_region = image[y0:y_end, x0:x_end]
            crops[
                1 + i * tiling[1] + j, : crop_region.shape[0], : crop_region.shape[1]
            ] = crop_region

    return crops, tiling


def reconstruct_from_crops(
    local_features: mx.array,
    tiling: Tuple[int, int],
    overlap_margin: int = 4,
) -> mx.array:
    """
    Reconstruct a unified feature map from local crop features.

    This function stitches together the features from local crops,
    handling the overlap regions by trimming interior margins.

    Args:
        local_features: [n_local, 27, 27, 1152] features from local crops
                       (27x27 patches per crop, each with 1152-dim features)
        tiling: (h_tiles, w_tiles) describing the crop layout
        overlap_margin: Number of patches that overlap between adjacent crops (default 4)

    Returns:
        Reconstructed feature map [H, W, 1152] where:
        H = h_tiles * (27 - 2*overlap_margin) + 2*overlap_margin
        W = w_tiles * (27 - 2*overlap_margin) + 2*overlap_margin
    """
    h_tiles, w_tiles = tiling
    n_local = h_tiles * w_tiles
    patches_per_side = 27  # 378 / 14 = 27 patches per crop side
    hidden_size = local_features.shape[-1]  # 1152

    # Effective patches per crop after removing interior overlaps
    effective_patches = patches_per_side - 2 * overlap_margin  # 27 - 8 = 19

    # Output feature map size
    out_h = h_tiles * effective_patches + 2 * overlap_margin
    out_w = w_tiles * effective_patches + 2 * overlap_margin

    # Initialize output
    # Use numpy for easier slicing, convert to mx at the end
    local_np = np.array(local_features)
    output = np.zeros((out_h, out_w, hidden_size), dtype=local_np.dtype)

    crop_idx = 0
    for i in range(h_tiles):
        for j in range(w_tiles):
            crop_features = local_np[crop_idx]  # [27, 27, 1152]

            # Determine which margins to keep based on position
            top_margin = overlap_margin if i == 0 else 0
            bottom_margin = overlap_margin if i == h_tiles - 1 else 0
            left_margin = overlap_margin if j == 0 else 0
            right_margin = overlap_margin if j == w_tiles - 1 else 0

            # Trim interior margins
            start_y = 0 if i == 0 else overlap_margin
            end_y = patches_per_side if i == h_tiles - 1 else patches_per_side - overlap_margin
            start_x = 0 if j == 0 else overlap_margin
            end_x = patches_per_side if j == w_tiles - 1 else patches_per_side - overlap_margin

            trimmed = crop_features[start_y:end_y, start_x:end_x]

            # Calculate output position
            out_y = 0 if i == 0 else (patches_per_side - overlap_margin) + (i - 1) * effective_patches
            out_x = 0 if j == 0 else (patches_per_side - overlap_margin) + (j - 1) * effective_patches

            out_h_slice = end_y - start_y
            out_w_slice = end_x - start_x

            output[out_y : out_y + out_h_slice, out_x : out_x + out_w_slice] = trimmed

            crop_idx += 1

    return mx.array(output)


def adaptive_avg_pool2d(
    x: mx.array,
    output_size: Tuple[int, int],
) -> mx.array:
    """
    Adaptive average pooling that pools input to a fixed output size.

    Args:
        x: Input tensor [H, W, C] or [C, H, W]
        output_size: Target (H_out, W_out)

    Returns:
        Pooled tensor with spatial dimensions matching output_size
    """
    # Assume input is [H, W, C] (channel last)
    H, W, C = x.shape
    out_h, out_w = output_size

    if H == out_h and W == out_w:
        return x

    # Calculate kernel and stride sizes for adaptive pooling
    # Kernel size = ceil(input_size / output_size)
    # Stride = floor(input_size / output_size)
    kernel_h = (H + out_h - 1) // out_h
    kernel_w = (W + out_w - 1) // out_w
    stride_h = H // out_h
    stride_w = W // out_w

    # Pad if necessary to ensure we can cover the output size
    pad_h = max(0, (out_h - 1) * stride_h + kernel_h - H)
    pad_w = max(0, (out_w - 1) * stride_w + kernel_w - W)

    if pad_h > 0 or pad_w > 0:
        # Pad with zeros
        x = mx.pad(x, [(0, pad_h), (0, pad_w), (0, 0)])

    # Perform pooling using a simple averaging approach
    # Convert to [1, H, W, C] for batch processing
    x = x[None, :, :, :]  # [1, H, W, C]

    # Use reshape and mean for pooling
    result = np.zeros((out_h, out_w, C), dtype=np.float32)
    x_np = np.array(x[0])  # [H, W, C]

    for i in range(out_h):
        for j in range(out_w):
            # Calculate the input region for this output pixel
            h_start = i * stride_h
            h_end = min(h_start + kernel_h, x_np.shape[0])
            w_start = j * stride_w
            w_end = min(w_start + kernel_w, x_np.shape[1])

            # Average pool
            region = x_np[h_start:h_end, w_start:w_end, :]
            result[i, j, :] = region.mean(axis=(0, 1))

    return mx.array(result)
