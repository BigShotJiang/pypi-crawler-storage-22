"""
Moondream2 processor for mlx-vlm.
"""

from typing import List, Optional, Union

from PIL import Image
from transformers import AutoTokenizer
from transformers.processing_utils import ProcessorMixin


class MoondreamProcessor(ProcessorMixin):
    """
    Processor for Moondream2 model.

    Wraps the tokenizer and provides compatibility with mlx-vlm's generation flow.
    Image processing is handled separately by the model's ImageProcessor class.
    """

    tokenizer_class = "AutoTokenizer"
    attributes = ["tokenizer"]

    def __init__(self, tokenizer, chat_template: Optional[str] = None, **kwargs):
        self.tokenizer = tokenizer

        # Set up chat template for moondream
        if chat_template is None:
            # Moondream uses a simple format: <image>\n\nQuestion: {question}\n\nAnswer:
            chat_template = (
                "{% for message in messages %}"
                "{% if message['role'] == 'user' %}"
                "{{ message['content'] }}\n\n"
                "{% elif message['role'] == 'assistant' %}"
                "{{ message['content'] }}"
                "{% endif %}"
                "{% endfor %}"
                "{% if add_generation_prompt %}Answer: {% endif %}"
            )

        self.chat_template = chat_template
        tokenizer.chat_template = chat_template
        super().__init__(tokenizer, **kwargs)

    @classmethod
    def from_pretrained(cls, pretrained_model_name_or_path, **kwargs):
        """Load processor from pretrained model path."""
        # Convert Path to string if needed
        if hasattr(pretrained_model_name_or_path, "__fspath__"):
            pretrained_model_name_or_path = str(pretrained_model_name_or_path)

        # Pop kwargs that are not valid for AutoTokenizer
        trust_remote_code = kwargs.pop("trust_remote_code", True)

        # Moondream2 uses a custom tokenizer (starmie-v1), not the GPT-2
        # tokenizer files shipped in the model repo.
        tokenizer = AutoTokenizer.from_pretrained(
            "moondream/starmie-v1",
            trust_remote_code=trust_remote_code,
        )

        # starmie-v1 doesn't define special token roles; set them to
        # <|endoftext|> (ID 0) which moondream uses as BOS/EOS/PAD.
        tokenizer.eos_token = "<|endoftext|>"
        tokenizer.bos_token = "<|endoftext|>"
        tokenizer.pad_token = "<|endoftext|>"

        return cls(tokenizer=tokenizer)

    def __call__(
        self,
        text: Optional[Union[str, List[str]]] = None,
        images: Optional[Union[Image.Image, List[Image.Image]]] = None,
        **kwargs,
    ):
        """
        Process text and images for the model.

        Note: Image processing is handled by the model's ImageProcessor,
        this processor mainly handles tokenization.
        """
        if text is None:
            raise ValueError("Text input is required")

        # Tokenize text
        encoding = self.tokenizer(text, **kwargs)

        return encoding

    def batch_decode(self, *args, **kwargs):
        """Decode token ids to text."""
        return self.tokenizer.batch_decode(*args, **kwargs)

    def decode(self, *args, **kwargs):
        """Decode token ids to text."""
        return self.tokenizer.decode(*args, **kwargs)

    def apply_chat_template(self, messages, add_generation_prompt=True, **kwargs):
        """Apply chat template to messages."""
        return self.tokenizer.apply_chat_template(
            messages,
            chat_template=self.chat_template,
            add_generation_prompt=add_generation_prompt,
            tokenize=kwargs.get("tokenize", False),
            **{k: v for k, v in kwargs.items() if k != "tokenize"}
        )

    # Token properties delegated to tokenizer
    @property
    def pad_token(self):
        return self.tokenizer.pad_token

    @pad_token.setter
    def pad_token(self, value):
        self.tokenizer.pad_token = value

    @property
    def pad_token_id(self):
        return self.tokenizer.pad_token_id

    @pad_token_id.setter
    def pad_token_id(self, value):
        self.tokenizer.pad_token_id = value

    @property
    def eos_token(self):
        return self.tokenizer.eos_token

    @property
    def eos_token_id(self):
        return self.tokenizer.eos_token_id

    @property
    def bos_token(self):
        return self.tokenizer.bos_token

    @property
    def bos_token_id(self):
        return self.tokenizer.bos_token_id


# Install the AutoProcessor patch for moondream1 model type
from ..base import install_auto_processor_patch

install_auto_processor_patch("moondream1", MoondreamProcessor)
