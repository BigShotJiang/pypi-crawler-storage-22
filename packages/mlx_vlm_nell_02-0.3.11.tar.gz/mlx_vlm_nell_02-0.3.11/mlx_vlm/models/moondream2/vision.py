from typing import Optional, Tuple

import mlx.core as mx
import mlx.nn as nn
import numpy as np
from PIL import Image

from .config import VisionConfig


def create_patches(pixel_values: mx.array, patch_size: int) -> mx.array:
    """
    Convert [B, C, H, W] images to [B, num_patches, patch_dim] patch sequences.
    
    This matches the PyTorch reference implementation exactly.
    """
    B, C, H, W = pixel_values.shape
    P = patch_size
    
    # Reshape to [B, C, H/P, P, W/P, P]
    x = pixel_values.reshape(B, C, H // P, P, W // P, P)
    
    # Permute to [B, H/P, W/P, C, P, P]
    x = x.transpose(0, 2, 4, 1, 3, 5)
    
    # Flatten to [B, (H/P)*(W/P), C*P*P]
    num_patches = (H // P) * (W // P)
    patch_dim = C * P * P
    x = x.reshape(B, num_patches, patch_dim)
    
    return x


class Attention(nn.Module):
    """Multi-head attention with combined QKV projection."""

    def __init__(self, config: VisionConfig):
        super().__init__()
        self.hidden_size = config.hidden_size
        self.num_heads = config.num_attention_heads
        self.head_dim = self.hidden_size // self.num_heads
        self.scale = self.head_dim**-0.5

        # Combined QKV projection (like original moondream)
        self.qkv = nn.Linear(self.hidden_size, 3 * self.hidden_size, bias=True)
        self.proj = nn.Linear(self.hidden_size, self.hidden_size, bias=True)

    def __call__(self, x: mx.array, mask: Optional[mx.array] = None) -> mx.array:
        B, L, _ = x.shape

        # Combined QKV projection then split
        qkv = self.qkv(x)
        q, k, v = mx.split(qkv, 3, axis=-1)

        # Reshape for multi-head attention
        q = q.reshape(B, L, self.num_heads, self.head_dim).transpose(0, 2, 1, 3)
        k = k.reshape(B, L, self.num_heads, self.head_dim).transpose(0, 2, 1, 3)
        v = v.reshape(B, L, self.num_heads, self.head_dim).transpose(0, 2, 1, 3)

        # Scaled dot-product attention
        output = mx.fast.scaled_dot_product_attention(
            q, k, v, scale=self.scale, mask=mask
        )
        output = output.transpose(0, 2, 1, 3).reshape(B, L, -1)

        return self.proj(output)


class MLP(nn.Module):
    """Feed-forward network with GELU activation."""

    def __init__(self, config: VisionConfig):
        super().__init__()
        self.fc1 = nn.Linear(config.hidden_size, config.intermediate_size, bias=True)
        self.fc2 = nn.Linear(config.intermediate_size, config.hidden_size, bias=True)
        self.activation = nn.GELU(approx="precise")

    def __call__(self, x: mx.array) -> mx.array:
        x = self.activation(self.fc1(x))
        x = self.fc2(x)
        return x


class EncoderLayer(nn.Module):
    """
    Single transformer encoder layer with POST-NORM architecture.
    
    Key difference from standard: residual addition happens BEFORE normalization.
    Pattern: x = x + attn(ln(x))
    """

    def __init__(self, config: VisionConfig):
        super().__init__()
        self.ln1 = nn.LayerNorm(config.hidden_size, eps=config.layer_norm_eps)
        self.attn = Attention(config)
        self.ln2 = nn.LayerNorm(config.hidden_size, eps=config.layer_norm_eps)
        self.mlp = MLP(config)

    def __call__(self, x: mx.array, mask: Optional[mx.array] = None) -> mx.array:
        # Post-norm: x = x + sublayer(norm(x))
        x = x + self.attn(self.ln1(x), mask)
        x = x + self.mlp(self.ln2(x))
        return x


class VisionEncoder(nn.Module):
    """Vision encoder with transformer layers."""

    def __init__(self, config: VisionConfig):
        super().__init__()
        self.layers = [EncoderLayer(config) for _ in range(config.num_hidden_layers)]

    def __call__(
        self,
        x: mx.array,
        mask: Optional[mx.array] = None,
        output_hidden_states: bool = False,
    ):
        encoder_states = (x,) if output_hidden_states else None

        for layer in self.layers:
            x = layer(x, mask)
            if output_hidden_states:
                encoder_states = encoder_states + (x,)

        return x, encoder_states


class VisionModel(nn.Module):
    """
    Moondream2 vision encoder.
    
    Architecture:
    1. Linear patch embedding (not Conv2d): 588 (14×14×3) -> 1152
    2. Add learnable positional embeddings
    3. 27 transformer layers with post-norm
    4. Final layer norm
    
    Reference: moondream2/vision.py (PyTorch)
    """

    def __init__(self, config: VisionConfig):
        super().__init__()
        self.config = config
        
        # Patch embedding: linear projection of flattened patches
        patch_dim = config.patch_size * config.patch_size * config.num_channels  # 588
        self.patch_emb = nn.Linear(patch_dim, config.hidden_size, bias=True)
        
        # Transformer encoder
        self.encoder = VisionEncoder(config)
        
        # Post layer norm
        self.post_layernorm = nn.LayerNorm(config.hidden_size, eps=config.layer_norm_eps)

        # Positional embedding: [1, num_patches, hidden_size]
        # This will be loaded from weights
        num_patches = (config.image_size // config.patch_size) ** 2  # 729
        self.position_embedding = mx.zeros((1, num_patches, config.hidden_size))

    def __call__(
        self,
        pixel_values: mx.array,
        output_hidden_states: bool = False,
    ) -> mx.array:
        """
        Args:
            pixel_values: [B, C, H, W] input images (normalized to [-1, 1])
        Returns:
            [B, num_patches, hidden_size] vision features
        """
        # Create patches: [B, C, H, W] -> [B, num_patches, patch_dim]
        x = create_patches(pixel_values, self.config.patch_size)
        
        # Linear projection: [B, num_patches, patch_dim] -> [B, num_patches, hidden_size]
        x = self.patch_emb(x)

        # Add positional embedding
        x = x + self.position_embedding

        # Encode through transformer layers
        x, encoder_states = self.encoder(x, output_hidden_states=output_hidden_states)

        # Final layer norm
        x = self.post_layernorm(x)

        if output_hidden_states:
            return x, encoder_states
        return x

    def sanitize(self, weights):
        """Sanitize vision encoder weights."""
        sanitized_weights = {}
        for k, v in weights.items():
            if "position_ids" in k:
                # Skip position_ids
                continue
            else:
                sanitized_weights[k] = v
        return sanitized_weights
