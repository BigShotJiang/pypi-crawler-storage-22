"""Aptos blockchain utilities."""
