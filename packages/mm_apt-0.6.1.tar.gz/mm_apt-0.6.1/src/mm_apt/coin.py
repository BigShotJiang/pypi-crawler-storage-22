"""Aptos coin type and metadata constants."""

APTOS_COIN_TYPE = "0x1::aptos_coin::AptosCoin"
APTOS_COIN_DECIMALS = 8

USDT_METADATA = "0x357b0b74bc833e95a115ad22604854d6b0fca151cecd94111770e5d6ffc9dc2b"
USDT_DECIMALS = 6
