"""Tests for mm_apt package."""
