"""Tests for Aptos account address validation."""

from mm_apt.account import is_valid_address


def _full_hex(ch: str) -> str:
    """Generate a full 64-char hex string with a given repeat char."""
    return ch * 64


class TestIsValidAddress:
    """Validate Aptos account address parsing and range checks."""

    def test_valid_full_length_addresses(self):
        """Verify accepted valid addresses with various prefixes."""
        assert is_valid_address("0x" + _full_hex("0")) is True
        assert is_valid_address("0x" + "0" * 63 + "1") is True
        assert is_valid_address("0x" + _full_hex("f")) is True
        assert is_valid_address("0X" + _full_hex("A")) is True
        assert is_valid_address(_full_hex("1")) is True

    def test_invalid_full_length_addresses(self):
        """Reject addresses with wrong length or invalid characters."""
        assert is_valid_address("0x" + "1" * 63) is False
        assert is_valid_address("0x" + "f" * 65) is False
        assert is_valid_address("0x" + "g" + "0" * 63) is False
        assert is_valid_address(123) is False  # pyright: ignore[reportArgumentType]

    def test_address_out_of_range(self):
        """Reject addresses outside the valid 256-bit range."""
        # Exactly 2**256 is out of range -> 1 followed by 64 zeros in hex is too large (65 hex digits)
        assert is_valid_address("0x1" + "0" * 64) is False
        # Highest valid: 2**256 - 1 -> 64 hex 'f'
        assert is_valid_address("0x" + _full_hex("f")) is True

    def test_missing_prefix_short_address(self):
        """Reject short addresses without the 0x prefix."""
        assert is_valid_address("1" * 1) is False
        assert is_valid_address("a" * 10) is False
