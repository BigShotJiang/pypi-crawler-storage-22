"""Tests for Aptos balance queries."""

from mm_apt.balance import get_balance
from mm_apt.coin import APTOS_COIN_TYPE, USDT_METADATA


class TestGetBalance:
    """Query coin and fungible asset balances."""

    async def test_aptos_coin(self, mainnet_rpc_url, okx_address):
        """Fetch APT coin balance for a known funded address."""
        res = await get_balance(mainnet_rpc_url, okx_address, APTOS_COIN_TYPE)
        assert res.unwrap() > 1000

    async def test_usdt(self, mainnet_rpc_url, okx_address):
        """Fetch USDT fungible asset balance for a known funded address."""
        res = await get_balance(mainnet_rpc_url, okx_address, USDT_METADATA)
        assert res.unwrap() > 0
