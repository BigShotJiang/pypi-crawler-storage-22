"""Application configuration: settings and state definitions."""

from datetime import datetime
from decimal import Decimal
from typing import Annotated

from mm_std import utc_now

from mm_base6 import BaseSettings, BaseState, Config, setting_field, state_field

# Required fields (app_name, database_url, etc.) are loaded from env vars by pydantic-settings
config = Config(openapi_tags=["data", "misc"], ui_menu={"/data": "data", "/misc": "misc"})  # ty: ignore[missing-argument]
"""App-wide configuration: OpenAPI tags and UI menu items."""


class Settings(BaseSettings):
    """User-configurable settings persisted to database."""

    proxies_url: Annotated[str, setting_field("http://localhost:8000", "proxies url, each proxy on new line")]
    telegram_token: Annotated[str, setting_field("", "telegram bot token", hide=True)]
    telegram_chat_id: Annotated[int, setting_field(0, "telegram chat id")]
    telegram_bot_allowed_users: Annotated[
        str, setting_field("", "list of telegram bot allowed users, for example: 123456789,987654321")
    ]
    telegram_bot_auto_start: Annotated[bool, setting_field(False)]
    price: Annotated[
        Decimal, setting_field(Decimal("1.23"), "long long long long long long long long long long long long long long long long")
    ]
    secret_password: Annotated[str, setting_field("abc", hide=True)]
    long_cfg_1: Annotated[str, setting_field("many lines\n" * 5)]


class State(BaseState):
    """Runtime state variables, some persisted to database."""

    proxies: Annotated[list[str], state_field([], "List of proxy URLs")]
    proxies_updated_at: Annotated[datetime | None, state_field(None, "Last proxy update timestamp")]
    tmp1: Annotated[str, state_field("bla", "Temporary value 1")]
    tmp2: Annotated[str, state_field("bla", "Temporary value 2")]
    processed_block: Annotated[int, state_field(111, "bla bla about processed_block")]
    last_checked_at: Annotated[datetime, state_field(utc_now(), "bla bla about last_checked_at", persistent=False)]
