"""mm-base6: Web framework with MongoDB integration and unified core access.

Public API exports for building applications with mm-base6.
"""

from .config import Config as Config
from .core.builtin_services.settings import BaseSettings as BaseSettings
from .core.builtin_services.settings import setting_field as setting_field
from .core.builtin_services.state import BaseState as BaseState
from .core.builtin_services.state import state_field as state_field
from .core.core import Core as Core
from .core.core import CoreProtocol as CoreProtocol
from .core.db import BaseDb as BaseDb
from .core.errors import UserError as UserError
from .core.service import Service as Service
from .server.cbv import cbv as cbv
from .server.deps import View as View
from .server.jinja import JinjaConfig as JinjaConfig
from .server.utils import redirect as redirect

# must be last due to circular imports
# isort: split
from .run import run as run
