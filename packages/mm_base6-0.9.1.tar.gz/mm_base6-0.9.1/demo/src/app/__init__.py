"""Development application for testing the mm_base6 framework."""
