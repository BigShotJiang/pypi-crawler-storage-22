"""Miscellaneous utility services."""

import threading

from app.core.types import AppCore
from mm_base6 import Service


class ThreadSafeCounter:
    """Thread-safe integer counter."""

    def __init__(self) -> None:
        """Initialize counter to zero."""
        self.value: int = 0
        self._lock: threading.Lock = threading.Lock()

    def increment(self) -> None:
        """Increment counter by one."""
        with self._lock:
            self.value += 1

    def get(self) -> int:
        """Return current counter value."""
        with self._lock:
            return self.value


class MiscService(Service[AppCore]):
    """Utility service for counters and state updates."""

    def __init__(self) -> None:
        """Initialize with a new counter instance."""
        self.counter: ThreadSafeCounter = ThreadSafeCounter()

    def increment_counter(self) -> int:
        """Increment counter and return new value."""
        self.counter.increment()
        return self.counter.get()

    async def update_state_value(self) -> int:
        """Increment processed_block state and return new value."""
        self.core.state.processed_block = self.core.state.processed_block + 1
        return self.core.state.processed_block
