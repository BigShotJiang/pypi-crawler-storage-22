"""Server module with routers and Jinja configuration."""
