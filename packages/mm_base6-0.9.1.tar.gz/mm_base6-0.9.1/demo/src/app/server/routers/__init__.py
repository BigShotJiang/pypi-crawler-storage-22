"""FastAPI routers for the development application."""
