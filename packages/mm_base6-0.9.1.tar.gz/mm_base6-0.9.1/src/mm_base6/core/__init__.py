"""Core framework components: configuration, services, and database."""
