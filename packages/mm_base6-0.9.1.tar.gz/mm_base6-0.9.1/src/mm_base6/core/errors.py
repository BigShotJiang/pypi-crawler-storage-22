"""Custom exception types for the framework."""


class UserError(Exception):
    """Error caused by invalid user action, not a system error."""

    def __init__(self, message: str) -> None:
        """Initialize with error message."""
        super().__init__(message)


class UnregisteredSettingError(Exception):
    """Raised when accessing a setting that is not registered in Settings class."""

    def __init__(self, message: str) -> None:
        """Initialize with error message."""
        super().__init__(message)


class UnregisteredStateError(Exception):
    """Raised when accessing a state field that is not registered in State class."""

    def __init__(self, message: str) -> None:
        """Initialize with error message."""
        super().__init__(message)
