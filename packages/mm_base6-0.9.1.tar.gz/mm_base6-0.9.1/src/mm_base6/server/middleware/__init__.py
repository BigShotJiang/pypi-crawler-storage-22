"""HTTP middleware components for authentication and request logging."""
