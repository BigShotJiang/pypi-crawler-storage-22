"""Tests for the mm_base6 framework."""
