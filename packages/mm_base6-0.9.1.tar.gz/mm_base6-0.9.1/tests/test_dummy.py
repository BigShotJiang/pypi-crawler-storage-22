"""Placeholder test to ensure test infrastructure works."""


def test_dummy() -> None:
    """Verify basic test execution."""
    assert True
