"""Tests for mutex module."""
