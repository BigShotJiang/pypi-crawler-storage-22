"""
coding:utf-8
@Software: PyCharm
@Time: 2026/2/4
@Author: xingyun
@Desc: GitLab分支分析模块
"""

from minimax_qa_mcp.src.gitlab_branch_analyzer.gitlab_branch_service import GitlabBranchService

__all__ = ['GitlabBranchService']
