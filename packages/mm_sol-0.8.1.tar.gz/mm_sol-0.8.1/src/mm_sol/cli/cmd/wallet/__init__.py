"""Wallet-related CLI commands."""
