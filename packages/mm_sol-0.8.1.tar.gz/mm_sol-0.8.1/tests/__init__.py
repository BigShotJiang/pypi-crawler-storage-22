"""Tests for mm-sol."""
