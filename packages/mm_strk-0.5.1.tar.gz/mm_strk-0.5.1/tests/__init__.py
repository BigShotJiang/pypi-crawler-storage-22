"""Tests for mm-strk."""
