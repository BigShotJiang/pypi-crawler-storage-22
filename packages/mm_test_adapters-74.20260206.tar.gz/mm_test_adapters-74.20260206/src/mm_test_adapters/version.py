__version__ = "74.20260206"
GIT_REF = "d3bbdd1"
URL = "https://github.com/micro-manager/mmCoreAndDevices/tree/d3bbdd1"