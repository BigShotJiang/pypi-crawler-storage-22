__version__ = "74.20260209"
GIT_REF = "05365af"
URL = "https://github.com/micro-manager/mmCoreAndDevices/tree/05365af"