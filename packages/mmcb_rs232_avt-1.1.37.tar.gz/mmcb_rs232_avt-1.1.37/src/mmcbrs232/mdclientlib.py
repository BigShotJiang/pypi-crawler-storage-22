#!/usr/bin/env python3
"""
Client library to help integrate the ZeroMQ serial port server into the PID
test scripts.
"""

import contextlib
import logging
import platform

try:
    from importlib import metadata
except (ImportError, ModuleNotFoundError):
    try:
        import importlib_metadata as metadata
    except (ImportError, ModuleNotFoundError):
        py_version = platform.python_version()
        if py_version < '3.8':
            logging.warning(
                'Cannot import importlib, version information will NOT be available.'
            )
            logging.warning(
                'Unsupported Python version (%s), upgrade to Python 3.8 or newer.',
                py_version,
            )
        else:
            logging.error('Cannot import importlib')

from mmcbrs232 import mdcliapi
from mmcbrs232 import common
from mmcbrs232 import psuset
from mmcbrs232 import psustat

# read the package version number as originally specified in setup.py
try:
    __version__ = metadata.version('mmcb-rs232-avt')
except NameError:
    # end-user is probably using a Python version < 3.8
    __version__ = 'unknown'


###############################################################################
# support
###############################################################################


def default():
    """
    ---------------------------------------------------------------------------
    args : none
    ---------------------------------------------------------------------------
    returns : dict
    ---------------------------------------------------------------------------
    """
    return {
        'alias': None,
        'channel': None,
        'current_limit': None,
        'debug': None,
        'decimal_places': 2,
        'forwardbias': False,
        'immediate': False,
        'manufacturer': None,
        'model': None,
        'on': None,
        'peltier': False,
        'port': None,
        'quiet': False,
        'rear': None,
        'reset': False,
        'serial': None,
        'settlingtime': 0.5,
        'verbose': None,
        'voltage': None,
        'voltspersecond': 10
    }


###############################################################################
# data structures
#
# model command lines from the PID scripts
###############################################################################


class Rs232:
    """
    Handle serial port interactions
    """

    # read hardware configuration
    psus = common.cache_read(['hvpsu', 'lvpsu', 'chiller'])
    settings = default()
    channels = common.ports_to_channels(settings, psus)
    ports = sorted(psus)

    # create client
    client = mdcliapi.MajorDomoClient('tcp://localhost:5556', verbose=False)

    ############################################################################
    # support
    ############################################################################

    def _get_serial_port_name(self, command):
        """
        get serial port name from command (psuset, psustat, ult80)
        """
        local_psus = self.psus.copy()
        local_channels = self.channels.copy()

        cli = command.split(' ')[0].strip()

        if cli == 'ult80':
            # obtain from device cache since there are no channels for the ULT80
            rval = [
                serial_port_name
                for serial_port_name, details in self.psus.items()
                if details[1] == 'chiller'
            ][0]

        elif cli == 'psuset':
            settings = default()
            psuset.check_arguments(settings, command)
            single = common.unique(settings, local_psus, local_channels)

            rval = next(iter(local_psus)) if single else None

        elif cli == 'psustat':
            settings = {
                'alias': None,
                'channel': None,
                'manufacturer': None,
                'model': None,
                'port': None,
                'serial': None,
                'time': None,
            }
            psustat.check_arguments(settings, command)
            single = common.unique(settings, local_psus, local_channels)

            if settings['filter'] and not single:
                rval = None
            else:
                rval = next(iter(local_psus))
        else:
            rval = None

        return rval

    def _issue_serial_command(self, command):
        """
        """
        serial_port_name = self._get_serial_port_name(command)
        reply = None
        if serial_port_name is None:
            return reply

        request = bytes(command, encoding='utf-8')

        with contextlib.suppress(KeyboardInterrupt):
            reply = self.client.send(
                bytes(serial_port_name, encoding='utf-8'), request
            )

        return reply

    @staticmethod
    def _reply_value(reply):
        """
        Extract value from returned string; discard latency figure.

        ------------------------------------------------------------------------
        args
            reply : list of str
                e.g. [b'ult80 -i : None (1.008616 s)']
        ------------------------------------------------------------------------
        returns : float, bool or None
        ------------------------------------------------------------------------
        """
        value_str, *_ = reply[0].decode().partition(':')[-1].partition('(')

        try:
            value = float(value_str)
        except ValueError:
            value = {'True': True, 'False': False}.get(value_str.strip())

        return value


    ############################################################################
    # obtain readings
    ############################################################################

    def get_ult80_temps(self):
        """
        ------------------------------------------------------------------------
        args : none
        ------------------------------------------------------------------------
        returns : float, float
            (internal_temperature, set point)
        ------------------------------------------------------------------------
        """
        return (
            self._reply_value(self._issue_serial_command('ult80 -r')),
            self._reply_value(self._issue_serial_command('ult80 -i')),
        )

    def get_pt_v(self, psu_id, channel):
        """
        HMP4040 set voltage
        """
        return self._reply_value(
            self._issue_serial_command(
                f'psustat --model hmp4040 --channel {channel} --serial {psu_id} --sv'
            )
        )

    def get_pt_i(self, psu_id, channel):
        """
        HMP4040 measured current
        """
        return self._reply_value(
            self._issue_serial_command(
                f'psustat --model hmp4040 --channel {channel} --serial {psu_id} --mi'
            )
        )

    def get_pt_sv_fast(self, psu_id, channel):
        """
        HMP4040 get channel set voltage, tailored for ZeroMQ serial port server.
        """
        return self._reply_value(
            self._issue_serial_command(
                f'psustat --model hmp4040 --channel {channel} --serial {psu_id} --sv --zserv'
            )
        )

    def get_pt_mi_fast(self, psu_id, channel):
        """
        HMP4040 get channel measured current, tailored for ZeroMQ serial port server.
        """
        return self._reply_value(
            self._issue_serial_command(
                f'psustat --model hmp4040 --channel {channel} --serial {psu_id} --mi --zserv'
            )
        )

    def psu_set(self, psu_id, channel, voltage, current):
        """
        channel on
        """
        return self._reply_value(
            self._issue_serial_command(
                f'psuset {voltage} --limit {current} --on --channel {channel} --serial {psu_id}'
            )
        )

    def psu_unset(self, psu_id, channel, voltage, current):
        """
        channel off
        """
        return self._reply_value(
            self._issue_serial_command(
                f'psuset {voltage} --limit {current} --off --channel {channel} --serial {psu_id}'
            )
        )
