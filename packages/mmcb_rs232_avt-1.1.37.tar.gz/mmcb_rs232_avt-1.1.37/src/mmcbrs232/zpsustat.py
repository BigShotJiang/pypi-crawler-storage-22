#!/usr/bin/env python3
"""
Instantaneous snapshot of a single power supply channel from a device
connected by a FTDI USB to RS232 adaptors. The value is obtained from the
ZeroMQ serial port server running on atldaq1.

E.g.

zpsustat --serial 103877 --channel 3 --sv

Use "zpsustat -h" for help

All power supplies supported by detect.py are usable by this script.
"""

import itertools
import sys
import types

from mmcbrs232 import mdclientlib
from mmcbrs232.psustat import check_arguments


##############################################################################
# main
##############################################################################

def main():
    """
    Instantaneous snapshot of a single power supply channel from a device
    connected by a FTDI USB to RS232 adaptors. The value is obtained from the
    ZeroMQ serial port server running on atldaq1.
    """
    status = types.SimpleNamespace(success=0, unreserved_error_code=3)

    settings = {
        'alias': None,
        'channel': None,
        'manufacturer': None,
        'model': None,
        'port': None,
        'serial': None,
        'time': None,
        }
    check_arguments(settings)

    # handle ./ prefix, though this should not be present when this script is packaged
    options = sys.argv[1:]
    if not options:
        print('please specify options sufficient to identify a single channel')
        return status.unreserved_error_code

    command = ' '.join(itertools.chain(['psustat'], options))

    mdc = mdclientlib.Rs232()
    try:
        response = mdc._reply_value(mdc._issue_serial_command(command))
    except TypeError:
        print('No response')
        return status.unreserved_error_code

    if response is None:
        print('No response')
        return status.unreserved_error_code

    print(response)
    return status.success


##############################################################################
if __name__ == '__main__':
    sys.exit(main())
