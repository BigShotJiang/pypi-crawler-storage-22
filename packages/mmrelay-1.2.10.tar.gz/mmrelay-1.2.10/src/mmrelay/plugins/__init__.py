"""
Plugin system for Meshtastic Matrix Relay.
"""
