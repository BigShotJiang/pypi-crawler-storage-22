"""Package data for mnemograph."""
