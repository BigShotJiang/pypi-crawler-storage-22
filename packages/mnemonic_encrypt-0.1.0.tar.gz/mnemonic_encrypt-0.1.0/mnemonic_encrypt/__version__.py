"""Version information for mnemonic-encrypt."""

__version__ = "0.1.0"
