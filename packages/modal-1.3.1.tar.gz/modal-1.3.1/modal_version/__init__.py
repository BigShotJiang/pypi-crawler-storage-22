# Copyright Modal Labs 2026
"""Supplies the current version of the modal client library."""

__version__ = "1.3.1"
