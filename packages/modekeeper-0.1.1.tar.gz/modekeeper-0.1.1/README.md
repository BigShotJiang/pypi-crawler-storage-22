# ModeKeeper
<!-- modekeeper:product-intro:start -->

## Для кого и зачем

**ModeKeeper** — инструмент для платформенных команд (**SRE / MLOps / FinOps**), которые запускают обучение/инференс в **Kubernetes** и хотят **снижать стоимость и нестабильность** без риска и без “ручного тюнинга”.

Что делает (в двух словах):
- **наблюдает** метрики/состояние ворклоада и собирает контекст;
- строит **план изменений** (**plan-only**, ничего не применяет);
- умеет **проверить применимость** плана (**verify**, тоже без изменений);
- в **платном режиме** может **применить** план (**apply**) внутри ModeKeeper — только при активной лицензии и после успешного verify.

Режимы:
- **Free:** observe + closed-loop dry-run + k8s render/verify (**ничего не меняет**)
- **Paid:** one-shot `mk closed-loop run --apply` под `MODEKEEPER_PAID=1`; детали — `docs/WORKFLOW.md`.

См. подробное продуктовое описание: `docs/product.md`.
См. технический snapshot для продолжения: `docs/SNAPSHOT.md`.
См. workflow (plan-only + verify + paid apply skeleton): `docs/WORKFLOW.md`.

<!-- modekeeper:product-intro:end -->


ModeKeeper — self-serve слой контроля для ML-систем. Сначала работает в режиме **OBSERVE_ONLY** (бесплатная неделя): собирает телеметрию и формирует отчет «теряете ли вы деньги». Затем, по желанию, включается режим **CLOSED_LOOP** для безопасного автотюнинга с guardrails и откатами.

## Возможности
- Два режима: `OBSERVE_ONLY` и `CLOSED_LOOP`.
- Модульная архитектура: core, telemetry, actuators, policy, safety, adapters.
- Explain-log везде: каждое решение, ограничение и действие фиксируется.
- Локальные демо-сценарии без внешних сервисов.

## Установка
```bash
python -m venv .venv
. .venv/bin/activate
pip install -e .
```

## Быстрый старт
```bash
mk observe --duration 250ms --out report/_observe_quick
mk demo run --scenario drift
mk closed-loop run --scenario drift --dry-run --out report/_golden_dryrun
```
Canonical paid e2e (kind) + scripts: `docs/WORKFLOW.md`.

## Quickstart
Observe-only quickstart + RBAC verify-only replay:
`docs/QUICKSTART.md`

## E2E (kind)
Canonical workflow: `docs/WORKFLOW.md` (paid path is one-shot `closed-loop run --apply`).
Continuation snapshot: `docs/SNAPSHOT.md`.

Canonical scripts:
- `./scripts/e2e-smoke-kind.sh` (safe: kill switch blocks apply)
- `./scripts/e2e-apply-kind.sh` (REAL kubectl patches)

Warning: `./scripts/e2e-apply-kind.sh` performs real `kubectl` patches in the kind cluster.

Observe параметры:
- `--source` synthetic|file (default: synthetic)
- `--path` обязателен для `--source file`
- `--duration` принимает `1.5s`, `250ms`, `10m`; без суффикса = секунды
- формат входа: `jsonl`/`csv` с полями `ts`, `step_time_ms`, `loss` (optional)

## Демо
```bash
mk demo run --scenario straggler
mk demo run --scenario burst
```

Выходные данные (контракт v0):
- `report/` содержит JSON-отчеты и `explain.jsonl` (JSONL, `ensure_ascii=False`).
- `observe_latest.json`, `demo_latest.json`, `closed_loop_latest.json` — копии последних отчетов.
- Подробности k8s утилит/полей — см. `docs/WORKFLOW.md` и `docs/SNAPSHOT.md`.
- Все отчеты имеют поля верхнего уровня: `schema_version`, `started_at`, `finished_at`, `duration_s`, `out_dir`.
- В `OBSERVE_ONLY` добавляется `summary`:
  - `money_leak_risk` (low|medium|high)
  - `top_symptoms`
  - `recommendations`
- В `CLOSED_LOOP` дополнительно создаётся `summary.md` (короткий человекочитаемый итог прогона).
- В `CLOSED_LOOP` также пишутся plan-only артефакты: `k8s_plan.json` и `k8s_plan.kubectl.sh` (в dry-run kubectl **не выполняется**).
- В `CLOSED_LOOP` добавляются поля:
  - `decision_summary` (RU)
  - `proposed` (предлагаемые действия)
  - `applied` (результаты применения/блокировки)
  - `status` (например, `"ok"`)
  - `kill_switch_active` (true/false)
  - `blocked_reasons` (агрегация причин блокировок)
  - `applied_reasons` (агрегация причин применений)
  - `k8s_plan_path` (путь к `k8s_plan.json`)
  - `k8s_plan_items` (кол-во items в плане)
  - `k8s_kubectl_plan_path` (путь к `k8s_plan.kubectl.sh`)
  - `k8s_namespace` (целевой namespace для скрипта/плана)
  - `k8s_deployment` (целевой deployment для скрипта/плана)

## Примечания
- `closed-loop` по умолчанию работает в dry-run; для paid-apply используйте one-shot `closed-loop run --apply` (см. `docs/WORKFLOW.md`).
- В dry-run `closed-loop` **не выполняет** kubectl: он только генерирует `k8s_plan.kubectl.sh`.
- Для принудительной блокировки `--apply` используйте `MODEKEEPER_KILL_SWITCH=1` (в отчёте `blocked_reasons` будет `kill_switch`).
- Все safety-ограничения локальные, настраиваемые и аудируемые.
