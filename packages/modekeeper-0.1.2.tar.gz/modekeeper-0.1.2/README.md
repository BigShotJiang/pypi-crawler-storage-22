# ModeKeeper

## Install (recommended)

This installs ModeKeeper into a dedicated user venv and exposes `mk` via `~/.local/bin/mk`.

```bash
python3 -m venv ~/.modekeeper/venv
~/.modekeeper/venv/bin/python -m pip install -U pip
~/.modekeeper/venv/bin/python -m pip install -U modekeeper
mkdir -p ~/.local/bin && ln -sfn ~/.modekeeper/venv/bin/mk ~/.local/bin/mk
~/.local/bin/mk doctor
~/.local/bin/mk --help
```
Modekeeper помогает безопасно проверять и отлаживать поведение сценариев в управляемом цикле.

<!-- modekeeper:product-intro:start -->
ModeKeeper для SRE, MLOps и FinOps-команд, которые ведут Kubernetes-кластеры с ML-нагрузками.
Сначала даёт eval/observe в read-only режиме, чтобы видеть отклонения и риски без изменений в среде.
Дальше запускает closed-loop dry-run: строит plan-only шаги и выполняет verify перед любым воздействием.
Режим apply доступен как платная операция и проходит через явные safety-gates.
Модель безопасности verify-first: сначала проверка инвариантов и сигналов, затем разрешённое действие.
Глобальный kill-switch мгновенно блокирует применение, а license gate отделяет наблюдение от изменения.
<!-- modekeeper:product-intro:end -->

## Установка

```bash
python -m pip install -U modekeeper
```

## Быстрый старт

```bash
mk --help
```

```bash
mk doctor
```

```bash
mk observe --duration 30s --source synthetic --out report/_observe_quick
```

```bash
mk closed-loop run --scenario drift --dry-run --out report/_dryrun
```

```bash
MODEKEEPER_KILL_SWITCH=1 mk closed-loop run --scenario drift --apply --out report/_apply_blocked
```
