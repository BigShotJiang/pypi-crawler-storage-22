import json
import os
import subprocess
from pathlib import Path


def _write_fake_kubectl(path: Path, log_path: Path, *, verify_ok: bool = True, apply_ok: bool = True) -> None:
    script = f"""#!/usr/bin/env bash
set -Eeuo pipefail

echo "$*" >> "{log_path}"

if [[ $# -ge 2 && "$1" == "config" && "$2" == "current-context" ]]; then
  echo "test-context"
  exit 0
fi

if [[ $# -ge 4 && "$1" == "get" && "$2" == "namespace/ns1" && "$3" == "-o" && "$4" == "name" ]]; then
  echo "namespace/ns1"
  exit 0
fi

if [[ $# -ge 6 && "$1" == "-n" && "$2" == "ns1" && "$3" == "get" && "$4" == "deployment/dep1" && "$5" == "-o" && "$6" == "name" ]]; then
  echo "deployment.apps/dep1"
  exit 0
fi

if [[ "$*" == *"--patch"* ]]; then
  if [[ "{'1' if apply_ok else '0'}" == "1" ]]; then
    echo "patched"
    exit 0
  else
    echo "apply failed" >&2
    exit 1
  fi
fi

if [[ "$*" == *"--dry-run=server"* || "$*" == *"--dry-run=client"* ]]; then
  if [[ "{'1' if verify_ok else '0'}" == "1" ]]; then
    echo '{{"kind":"Deployment","metadata":{{"name":"dep1"}}}}'
    exit 0
  else
    echo "dry-run failed" >&2
    exit 1
  fi
fi

echo "unexpected args: $*" >&2
exit 1
"""
    path.write_text(script, encoding="utf-8")
    path.chmod(0o755)


def test_closed_loop_report_artifacts_with_kill_switch(tmp_path: Path, mk_path: Path) -> None:
    out_dir = tmp_path / "closed_loop_out"
    kubectl_log = tmp_path / "kubectl.log"
    kubectl = tmp_path / "kubectl"
    _write_fake_kubectl(kubectl, kubectl_log, verify_ok=True, apply_ok=True)
    mk = mk_path
    env = {
        **os.environ,
        "MODEKEEPER_KILL_SWITCH": "1",
        "MODEKEEPER_PAID": "1",
        "MODEKEEPER_INTERNAL_OVERRIDE": "1",
        "KUBECTL": str(kubectl),
        "HOME": str(tmp_path),
        "KUBECONFIG": str(tmp_path / "kubeconfig"),
    }
    cp = subprocess.run(
        [
            str(mk),
            "closed-loop",
            "run",
            "--apply",
            "--k8s-namespace",
            "ns1",
            "--k8s-deployment",
            "dep1",
            "--out",
            str(out_dir),
        ],
        check=False,
        capture_output=True,
        text=True,
        env=env,
    )
    assert cp.returncode == 2
    assert cp.stderr.strip() == "ERROR: MODEKEEPER_KILL_SWITCH=1 blocks apply/mutate operations"

    latest = json.loads((out_dir / "closed_loop_latest.json").read_text(encoding="utf-8"))
    assert latest.get("kill_switch_active") is True
    assert latest.get("apply_requested") is True
    assert latest.get("dry_run") is False
    assert latest.get("status") == "ok"
    assert latest.get("apply_blocked_reason") == "kill_switch"
    assert latest.get("apply_attempted") is False
    assert latest.get("apply_ok") is None
    assert latest.get("k8s_verify_report_path")
    assert latest.get("k8s_apply_report_path")
    apply_latest = json.loads((out_dir / "k8s_apply_latest.json").read_text(encoding="utf-8"))
    assert apply_latest.get("blocked") is True
    assert apply_latest.get("verify_blocker") == "kill_switch"
    assert apply_latest.get("reason") == "kill_switch"

    log_text = kubectl_log.read_text(encoding="utf-8")
    assert "--patch" not in log_text

    summary_path = out_dir / "summary.md"
    assert summary_path.exists()
    assert summary_path.read_text(encoding="utf-8").strip()


def test_closed_loop_report_artifacts_apply_reasons(tmp_path: Path, mk_path: Path) -> None:
    out_dir = tmp_path / "closed_loop_out"
    kubectl_log = tmp_path / "kubectl.log"
    kubectl = tmp_path / "kubectl"
    _write_fake_kubectl(kubectl, kubectl_log, verify_ok=True, apply_ok=True)
    mk = mk_path
    env = {
        **os.environ,
        "MODEKEEPER_KILL_SWITCH": "0",
        "MODEKEEPER_PAID": "1",
        "MODEKEEPER_INTERNAL_OVERRIDE": "1",
        "KUBECTL": str(kubectl),
        "HOME": str(tmp_path),
        "KUBECONFIG": str(tmp_path / "kubeconfig"),
    }
    subprocess.run(
        [
            str(mk),
            "closed-loop",
            "run",
            "--apply",
            "--k8s-namespace",
            "ns1",
            "--k8s-deployment",
            "dep1",
            "--out",
            str(out_dir),
        ],
        check=True,
        capture_output=True,
        text=True,
        env=env,
    )

    latest = json.loads((out_dir / "closed_loop_latest.json").read_text(encoding="utf-8"))
    assert latest.get("dry_run") is False
    assert latest.get("apply_requested") is True
    assert latest.get("apply_decision_summary") == "apply executed: ok"
    assert latest.get("k8s_verify_report_path")
    assert latest.get("k8s_apply_report_path")

    log_text = kubectl_log.read_text(encoding="utf-8")
    assert "--patch" in log_text


def test_closed_loop_writes_k8s_plan(tmp_path: Path, mk_path: Path) -> None:
    out_dir = tmp_path / "closed_loop_out"
    mk = mk_path
    subprocess.run(
        [
            str(mk),
            "closed-loop",
            "run",
            "--scenario",
            "drift",
            "--k8s-namespace",
            "ns1",
            "--k8s-deployment",
            "dep1",
            "--out",
            str(out_dir),
        ],
        check=True,
        capture_output=True,
        text=True,
    )

    plan_path = out_dir / "k8s_plan.json"
    assert plan_path.exists()
    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    assert isinstance(plan, list)
    assert len(plan) >= 1

    annotation_keys: set[str] = set()
    template_annotation_keys: set[str] = set()
    for item in plan:
        assert item.get("namespace") == "ns1"
        assert item.get("name") == "dep1"
        annotations = (
            item.get("patch", {})
            .get("metadata", {})
            .get("annotations", {})
        )
        if isinstance(annotations, dict):
            annotation_keys.update(annotations.keys())
        template_annotations = (
            item.get("patch", {})
            .get("spec", {})
            .get("template", {})
            .get("metadata", {})
            .get("annotations", {})
        )
        if isinstance(template_annotations, dict):
            template_annotation_keys.update(template_annotations.keys())
    assert "modekeeper/knob.grad_accum_steps" in annotation_keys
    assert "modekeeper/knob.microbatch_size" in annotation_keys
    assert "modekeeper/knob.grad_accum_steps" in template_annotation_keys
    assert "modekeeper/knob.microbatch_size" in template_annotation_keys

    explain_path = out_dir / "explain.jsonl"
    assert explain_path.exists()
    explain_events = [
        json.loads(line).get("event")
        for line in explain_path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    assert "k8s_plan_written" in explain_events
    assert "k8s_kubectl_plan_written" in explain_events

    latest = json.loads((out_dir / "closed_loop_latest.json").read_text(encoding="utf-8"))
    latest_path = latest.get("k8s_plan_path")
    assert latest_path
    kubectl_plan_path = latest.get("k8s_kubectl_plan_path")
    assert kubectl_plan_path
    assert latest.get("k8s_plan_items", 0) >= 1
    assert latest.get("k8s_namespace") == "ns1"
    assert latest.get("k8s_deployment") == "dep1"
    assert Path(latest_path).exists()
    kubectl_path = Path(kubectl_plan_path)
    assert kubectl_path.exists()
    script_text = kubectl_path.read_text(encoding="utf-8")
    assert script_text.startswith("#!/usr/bin/env bash")
    assert "kubectl -n ns1 patch deployment/dep1 --type merge -p" in script_text
    assert "kubectl config current-context" in script_text
    assert "Target: namespace=ns1 deployment=dep1" in script_text
    assert os.access(kubectl_path, os.X_OK)
