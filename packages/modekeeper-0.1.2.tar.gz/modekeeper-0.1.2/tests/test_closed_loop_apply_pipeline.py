import json
import os
import subprocess
from pathlib import Path


def _write_fake_kubectl(path: Path, log_path: Path, *, verify_ok: bool = True, apply_ok: bool = True) -> None:
    script = f"""#!/usr/bin/env bash
set -Eeuo pipefail

echo "$*" >> "{log_path}"

if [[ $# -ge 2 && "$1" == "config" && "$2" == "current-context" ]]; then
  echo "test-context"
  exit 0
fi

if [[ $# -ge 4 && "$1" == "get" && "$2" == "namespace/ns1" && "$3" == "-o" && "$4" == "name" ]]; then
  echo "namespace/ns1"
  exit 0
fi

if [[ $# -ge 6 && "$1" == "-n" && "$2" == "ns1" && "$3" == "get" && "$4" == "deployment/dep1" && "$5" == "-o" && "$6" == "name" ]]; then
  echo "deployment.apps/dep1"
  exit 0
fi

if [[ "$*" == *"--patch"* ]]; then
  if [[ "{'1' if apply_ok else '0'}" == "1" ]]; then
    echo "patched"
    exit 0
  else
    echo "apply failed" >&2
    exit 1
  fi
fi

if [[ "$*" == *"--dry-run=server"* || "$*" == *"--dry-run=client"* ]]; then
  if [[ "{'1' if verify_ok else '0'}" == "1" ]]; then
    echo '{{"kind":"Deployment","metadata":{{"name":"dep1"}}}}'
    exit 0
  else
    echo "dry-run failed" >&2
    exit 1
  fi
fi

echo "unexpected args: $*" >&2
exit 1
"""
    path.write_text(script, encoding="utf-8")
    path.chmod(0o755)


def _run_closed_loop(mk: Path, out_dir: Path, env: dict) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [
            str(mk),
            "closed-loop",
            "run",
            "--apply",
            "--k8s-namespace",
            "ns1",
            "--k8s-deployment",
            "dep1",
            "--out",
            str(out_dir),
        ],
        check=True,
        capture_output=True,
        text=True,
        env=env,
    )


def _read_summary(out_dir: Path) -> str:
    return (out_dir / "summary.md").read_text(encoding="utf-8")


def _assert_summary_contains(summary: str, *lines: str) -> None:
    for line in lines:
        assert line in summary


def _write_observe_jsonl(path: Path) -> None:
    rows = [
        '{"ts":"2026-01-01T00:00:00Z","step_time_ms":100,"loss":1.0}',
        '{"ts":"2026-01-01T00:00:01Z","step_time_ms":100,"loss":1.0}',
        '{"ts":"2026-01-01T00:00:02Z","step_time_ms":100,"loss":1.0}',
        '{"ts":"2026-01-01T00:00:03Z","step_time_ms":100,"loss":1.0}',
    ]
    path.write_text("\n".join(rows) + "\n", encoding="utf-8")


def test_closed_loop_apply_skips_when_no_proposals(tmp_path: Path, mk_path: Path) -> None:
    out_dir = tmp_path / "closed_loop_out"
    observe_path = tmp_path / "observe.jsonl"
    _write_observe_jsonl(observe_path)

    env = {
        **os.environ,
        "MODEKEEPER_KILL_SWITCH": "0",
        "MODEKEEPER_PAID": "1",
        "MODEKEEPER_INTERNAL_OVERRIDE": "1",
    }

    subprocess.run(
        [
            str(mk_path),
            "closed-loop",
            "run",
            "--apply",
            "--observe-source",
            "file",
            "--observe-path",
            str(observe_path),
            "--k8s-namespace",
            "ns1",
            "--k8s-deployment",
            "dep1",
            "--out",
            str(out_dir),
        ],
        check=True,
        capture_output=True,
        text=True,
        env=env,
    )

    latest = json.loads((out_dir / "closed_loop_latest.json").read_text(encoding="utf-8"))
    assert latest.get("proposed") == []
    assert latest.get("apply_attempted") is False
    assert latest.get("verify_ok") is None
    assert latest.get("apply_ok") is None
    assert latest.get("apply_blocked_reason") is None
    assert latest.get("k8s_verify_report_path") is None
    assert latest.get("k8s_apply_report_path") is None
    assert not list(out_dir.glob("k8s_verify_*"))
    assert not list(out_dir.glob("k8s_apply_*"))


def test_closed_loop_run_dry_run_unaffected_by_verify_gate(tmp_path: Path, mk_path: Path) -> None:
    out_dir = tmp_path / "closed_loop_out"
    cp = subprocess.run(
        [
            str(mk_path),
            "closed-loop",
            "run",
            "--dry-run",
            "--out",
            str(out_dir),
        ],
        check=False,
        capture_output=True,
        text=True,
    )
    assert cp.returncode == 0

    latest = json.loads((out_dir / "closed_loop_latest.json").read_text(encoding="utf-8"))
    assert latest.get("apply_requested") is False
    assert latest.get("dry_run") is True
    assert latest.get("k8s_verify_report_path") is None
    assert latest.get("k8s_apply_report_path") is None


def test_closed_loop_apply_blocks_when_unpaid(tmp_path: Path, mk_path: Path) -> None:
    out_dir = tmp_path / "closed_loop_out"
    kubectl_log = tmp_path / "kubectl.log"
    kubectl = tmp_path / "kubectl"
    _write_fake_kubectl(kubectl, kubectl_log, verify_ok=True, apply_ok=True)

    env = {
        **os.environ,
        "MODEKEEPER_KILL_SWITCH": "0",
        "MODEKEEPER_PAID": "0",
        "KUBECTL": str(kubectl),
        "HOME": str(tmp_path),
        "KUBECONFIG": str(tmp_path / "kubeconfig"),
    }

    _run_closed_loop(mk_path, out_dir, env)

    latest = json.loads((out_dir / "closed_loop_latest.json").read_text(encoding="utf-8"))
    assert latest.get("apply_blocked_reason") == "license_missing"
    assert latest.get("k8s_verify_report_path")
    assert latest.get("k8s_apply_report_path")
    assert len(latest.get("results", [])) == len(latest.get("proposed", []))
    assert latest.get("blocked_reasons", {}).get("license_missing") == len(latest.get("proposed", []))

    log_text = kubectl_log.read_text(encoding="utf-8")
    assert "--patch" not in log_text
    summary = _read_summary(out_dir)
    _assert_summary_contains(
        summary,
        "apply_attempted: False",
        "apply_ok: n/a",
        "results_eq_proposed: True",
        "apply_blocked_reason: license_missing",
    )


def test_closed_loop_apply_blocks_when_verify_fails(tmp_path: Path, mk_path: Path) -> None:
    out_dir = tmp_path / "closed_loop_out"
    kubectl_log = tmp_path / "kubectl.log"
    kubectl = tmp_path / "kubectl"
    _write_fake_kubectl(kubectl, kubectl_log, verify_ok=False, apply_ok=True)

    env = {
        **os.environ,
        "MODEKEEPER_KILL_SWITCH": "0",
        "MODEKEEPER_PAID": "1",
        "MODEKEEPER_INTERNAL_OVERRIDE": "1",
        "KUBECTL": str(kubectl),
        "HOME": str(tmp_path),
        "KUBECONFIG": str(tmp_path / "kubeconfig"),
    }

    cp = subprocess.run(
        [
            str(mk_path),
            "closed-loop",
            "run",
            "--apply",
            "--k8s-namespace",
            "ns1",
            "--k8s-deployment",
            "dep1",
            "--out",
            str(out_dir),
        ],
        check=False,
        capture_output=True,
        text=True,
        env=env,
    )
    assert cp.returncode == 2
    assert cp.stderr.strip() == "ERROR: verify_ok=true is required for apply/mutate operations"

    latest = json.loads((out_dir / "closed_loop_latest.json").read_text(encoding="utf-8"))
    assert latest.get("apply_blocked_reason") == "verify_failed"
    assert latest.get("apply_attempted") is False
    assert latest.get("apply_ok") is None
    assert latest.get("k8s_apply_rc") == 2
    assert latest.get("k8s_verify_report_path")
    assert latest.get("k8s_apply_report_path")
    apply_latest = json.loads((out_dir / "k8s_apply_latest.json").read_text(encoding="utf-8"))
    assert apply_latest.get("block_reason") == "verify_failed"
    assert apply_latest.get("reason") == "verify_failed"

    log_text = kubectl_log.read_text(encoding="utf-8")
    assert "--patch" not in log_text
    summary = _read_summary(out_dir)
    _assert_summary_contains(
        summary,
        "apply_attempted: False",
        "apply_ok: n/a",
        "apply_blocked_reason: verify_failed",
        "results_eq_proposed: True",
    )


def test_closed_loop_apply_success_writes_apply_report(tmp_path: Path, mk_path: Path) -> None:
    out_dir = tmp_path / "closed_loop_out"
    kubectl_log = tmp_path / "kubectl.log"
    kubectl = tmp_path / "kubectl"
    _write_fake_kubectl(kubectl, kubectl_log, verify_ok=True, apply_ok=True)

    env = {
        **os.environ,
        "MODEKEEPER_KILL_SWITCH": "0",
        "MODEKEEPER_PAID": "1",
        "MODEKEEPER_INTERNAL_OVERRIDE": "1",
        "KUBECTL": str(kubectl),
        "HOME": str(tmp_path),
        "KUBECONFIG": str(tmp_path / "kubeconfig"),
    }

    _run_closed_loop(mk_path, out_dir, env)

    latest = json.loads((out_dir / "closed_loop_latest.json").read_text(encoding="utf-8"))
    assert latest.get("apply_attempted") is True
    assert latest.get("apply_ok") is True
    apply_path = latest.get("k8s_apply_report_path")
    assert apply_path
    assert Path(apply_path).exists()
    assert len(latest.get("results", [])) == len(latest.get("proposed", []))
    summary = _read_summary(out_dir)
    _assert_summary_contains(
        summary,
        "apply_attempted: True",
        "apply_ok: True",
        "results_eq_proposed: True",
    )


def test_closed_loop_apply_kill_switch_blocks_even_with_internal_override(tmp_path: Path, mk_path: Path) -> None:
    out_dir = tmp_path / "closed_loop_out"
    kubectl_log = tmp_path / "kubectl.log"
    kubectl = tmp_path / "kubectl"
    _write_fake_kubectl(kubectl, kubectl_log, verify_ok=True, apply_ok=True)

    env = {
        **os.environ,
        "MODEKEEPER_KILL_SWITCH": "1",
        "MODEKEEPER_PAID": "1",
        "MODEKEEPER_INTERNAL_OVERRIDE": "1",
        "KUBECTL": str(kubectl),
        "HOME": str(tmp_path),
        "KUBECONFIG": str(tmp_path / "kubeconfig"),
    }

    cp = subprocess.run(
        [
            str(mk_path),
            "closed-loop",
            "run",
            "--apply",
            "--k8s-namespace",
            "ns1",
            "--k8s-deployment",
            "dep1",
            "--out",
            str(out_dir),
        ],
        check=False,
        capture_output=True,
        text=True,
        env=env,
    )
    assert cp.returncode == 2
    assert cp.stderr.strip() == "ERROR: MODEKEEPER_KILL_SWITCH=1 blocks apply/mutate operations"

    latest = json.loads((out_dir / "closed_loop_latest.json").read_text(encoding="utf-8"))
    assert latest.get("apply_blocked_reason") == "kill_switch"
    assert latest.get("apply_attempted") is False
    assert latest.get("apply_ok") is None
    assert latest.get("k8s_verify_report_path")
    assert latest.get("k8s_apply_report_path")

    log_text = kubectl_log.read_text(encoding="utf-8")
    assert "--patch" not in log_text
    summary = _read_summary(out_dir)
    _assert_summary_contains(
        summary,
        "apply_attempted: False",
        "apply_ok: n/a",
        "apply_blocked_reason: kill_switch",
        "results_eq_proposed: True",
    )
