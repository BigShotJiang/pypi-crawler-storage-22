import json
import os
import subprocess
from pathlib import Path


def test_closed_loop_watch_dry_run(tmp_path: Path, mk_path: Path) -> None:
    out_dir = tmp_path / "watch_out"
    observe_path = tmp_path / "observe.jsonl"
    _write_observe_jsonl(observe_path)
    cp = subprocess.run(
        [
            str(mk_path),
            "closed-loop",
            "watch",
            "--scenario",
            "drift",
            "--dry-run",
            "--observe-source",
            "file",
            "--observe-path",
            str(observe_path),
            "--out",
            str(out_dir),
            "--max-iterations",
            "2",
            "--interval",
            "0s",
        ],
        text=True,
        capture_output=True,
    )
    assert cp.returncode == 0

    iter_1 = out_dir / "iter_0001"
    iter_2 = out_dir / "iter_0002"
    assert iter_1.exists()
    assert iter_2.exists()
    assert (iter_1 / "closed_loop_latest.json").exists()
    assert (iter_1 / "summary.md").exists()
    assert (iter_2 / "closed_loop_latest.json").exists()
    assert (iter_2 / "summary.md").exists()

    watch_path = out_dir / "watch_latest.json"
    assert watch_path.exists()
    watch = json.loads(watch_path.read_text(encoding="utf-8"))
    assert watch.get("schema_version") == "v0"
    assert watch.get("iterations_done") == 2
    assert watch.get("last_iteration_out_dir") == str(iter_2)

    rep1 = json.loads((iter_1 / "closed_loop_latest.json").read_text(encoding="utf-8"))
    rep2 = json.loads((iter_2 / "closed_loop_latest.json").read_text(encoding="utf-8"))
    assert rep1.get("apply_requested") is False
    assert rep2.get("apply_requested") is False
    assert rep1.get("dry_run") is True
    assert rep2.get("dry_run") is True
    assert len(rep1.get("proposed", [])) == 0
    assert len(rep2.get("proposed", [])) == 0
    proposed_total = len(rep1.get("proposed", [])) + len(rep2.get("proposed", []))
    assert watch.get("proposed_total") == proposed_total
    assert watch.get("dry_run_total") == 2
    for iter_dir in (iter_1, iter_2):
        script_text = (iter_dir / "k8s_plan.kubectl.sh").read_text(encoding="utf-8")
        assert "kubectl" not in script_text
    summary_path = out_dir / "watch_summary.md"
    assert summary_path.exists()
    summary_lines = summary_path.read_text(encoding="utf-8").splitlines()
    assert "dry_run_total: 2" in summary_lines


def _write_observe_jsonl(path: Path) -> None:
    rows = [
        '{"ts":"2026-01-01T00:00:00Z","step_time_ms":100,"loss":1.0}',
        '{"ts":"2026-01-01T00:00:01Z","step_time_ms":100,"loss":1.0}',
        '{"ts":"2026-01-01T00:00:02Z","step_time_ms":100,"loss":1.0}',
        '{"ts":"2026-01-01T00:00:03Z","step_time_ms":100,"loss":1.0}',
    ]
    path.write_text("\n".join(rows) + "\n", encoding="utf-8")


def _explain_has_apply_skipped(path: Path) -> bool:
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        record = json.loads(line)
        if record.get("event") == "closed_loop_apply_skipped":
            return True
    return False


def _apply_result_dry_run(path: Path) -> bool | None:
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        record = json.loads(line)
        if record.get("event") == "closed_loop_apply_result":
            payload = record.get("payload") or {}
            return payload.get("dry_run")
    return None


def test_closed_loop_watch_apply_no_proposals(tmp_path: Path, mk_path: Path) -> None:
    out_dir = tmp_path / "watch_out"
    observe_path = tmp_path / "observe.jsonl"
    _write_observe_jsonl(observe_path)

    env = {
        **os.environ,
        "MODEKEEPER_PAID": "1",
        "MODEKEEPER_INTERNAL_OVERRIDE": "1",
        "MODEKEEPER_KILL_SWITCH": "0",
    }
    cp = subprocess.run(
        [
            str(mk_path),
            "closed-loop",
            "watch",
            "--scenario",
            "drift",
            "--apply",
            "--observe-source",
            "file",
            "--observe-path",
            str(observe_path),
            "--out",
            str(out_dir),
            "--max-iterations",
            "2",
            "--interval",
            "0s",
        ],
        text=True,
        capture_output=True,
        env=env,
    )
    assert cp.returncode == 0

    watch_path = out_dir / "watch_latest.json"
    watch = json.loads(watch_path.read_text(encoding="utf-8"))
    assert watch.get("iterations_done") == 2
    assert watch.get("apply_attempted_total") == 0

    iter_1 = out_dir / "iter_0001"
    iter_2 = out_dir / "iter_0002"
    for iter_dir in (iter_1, iter_2):
        assert not list(iter_dir.glob("k8s_verify_*"))
        assert not list(iter_dir.glob("k8s_apply_*"))
        explain_path = iter_dir / "explain.jsonl"
        assert explain_path.exists()
        assert _explain_has_apply_skipped(explain_path)
        assert _apply_result_dry_run(explain_path) is False
        report = json.loads((iter_dir / "closed_loop_latest.json").read_text(encoding="utf-8"))
        assert report.get("apply_requested") is True
        assert report.get("dry_run") is False
        assert len(report.get("proposed", [])) == 0
        script_text = (iter_dir / "k8s_plan.kubectl.sh").read_text(encoding="utf-8")
        assert "kubectl" not in script_text

    summary_path = out_dir / "watch_summary.md"
    assert summary_path.exists()
    summary_lines = summary_path.read_text(encoding="utf-8").splitlines()
    assert "apply_attempted_total: 0" in summary_lines
    assert "dry_run_total: 0" in summary_lines
