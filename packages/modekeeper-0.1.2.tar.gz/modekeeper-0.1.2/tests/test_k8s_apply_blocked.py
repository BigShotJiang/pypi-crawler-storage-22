import json
import subprocess
from pathlib import Path


def _run(mk: Path, args: list[str], env: dict | None = None) -> subprocess.CompletedProcess[str]:
    e = None
    if env is not None:
        import os
        e = os.environ.copy()
        e.update(env)
    return subprocess.run([str(mk), *args], text=True, capture_output=True, env=e)


def _read_jsonl(path: Path) -> list[dict]:
    return [
        json.loads(line)
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]


def _write_plan(plan_path: Path) -> None:
    plan_path.write_text(
        json.dumps(
            [
                {"namespace": "ns1", "name": "dep1", "patch": {"spec": {"replicas": 2}}},
            ]
        ),
        encoding="utf-8",
    )


def _write_verify(plan_dir: Path, *, ok: bool) -> None:
    verify_path = plan_dir / "k8s_verify_latest.json"
    verify_path.write_text(json.dumps({"ok": ok}), encoding="utf-8")


def _get_last_blocked_reason(explain_path: Path) -> str:
    events = _read_jsonl(explain_path)
    blocked = [e for e in events if e.get("event") == "k8s_apply_blocked"]
    assert blocked
    payload = blocked[-1].get("payload") or {}
    return str(payload.get("reason"))


def test_k8s_apply_blocked_license_required(tmp_path: Path, mk_path: Path) -> None:
    plan = tmp_path / "plan.json"
    _write_plan(plan)
    _write_verify(plan.parent, ok=True)
    out_dir = tmp_path / "out"

    cp = _run(mk_path, ["k8s", "apply", "--plan", str(plan), "--out", str(out_dir)])
    assert cp.returncode == 2

    latest = out_dir / "k8s_apply_latest.json"
    assert latest.exists()
    report = json.loads(latest.read_text(encoding="utf-8"))
    assert report.get("would_apply") is False
    assert report.get("paid_enabled") is False

    reason = _get_last_blocked_reason(out_dir / "explain.jsonl")
    assert reason == "license_missing"


def test_k8s_apply_blocked_verify_required(tmp_path: Path, mk_path: Path) -> None:
    plan = tmp_path / "plan.json"
    _write_plan(plan)
    out_dir = tmp_path / "out"

    cp = _run(
        mk_path,
        ["k8s", "apply", "--plan", str(plan), "--out", str(out_dir)],
        env={"MODEKEEPER_PAID": "1", "MODEKEEPER_INTERNAL_OVERRIDE": "1"},
    )
    assert cp.returncode == 2
    assert cp.stderr.strip() == "ERROR: verify_ok=true is required for apply/mutate operations"

    latest = out_dir / "k8s_apply_latest.json"
    assert latest.exists()
    report = json.loads(latest.read_text(encoding="utf-8"))
    assert report.get("would_apply") is False
    assert report.get("paid_enabled") is True
    assert report.get("block_reason") == "verify_missing"
    assert report.get("reason") == "verify_missing"

    reason = _get_last_blocked_reason(out_dir / "explain.jsonl")
    assert reason == "verify_missing"


def test_k8s_apply_blocked_when_verify_ok_false(tmp_path: Path, mk_path: Path) -> None:
    plan = tmp_path / "plan.json"
    _write_plan(plan)
    _write_verify(plan.parent, ok=False)
    out_dir = tmp_path / "out"

    cp = _run(
        mk_path,
        ["k8s", "apply", "--plan", str(plan), "--out", str(out_dir)],
        env={"MODEKEEPER_PAID": "1", "MODEKEEPER_INTERNAL_OVERRIDE": "1"},
    )
    assert cp.returncode == 2
    assert cp.stderr.strip() == "ERROR: verify_ok=true is required for apply/mutate operations"

    latest = out_dir / "k8s_apply_latest.json"
    report = json.loads(latest.read_text(encoding="utf-8"))
    assert report.get("would_apply") is False
    assert report.get("block_reason") == "verify_failed"
    assert report.get("reason") == "verify_failed"

    reason = _get_last_blocked_reason(out_dir / "explain.jsonl")
    assert reason == "verify_failed"
