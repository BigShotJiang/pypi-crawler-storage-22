import json
import subprocess
from pathlib import Path


def _run(mk: Path, args: list[str], env: dict | None = None) -> subprocess.CompletedProcess[str]:
    e = None
    if env is not None:
        import os
        e = os.environ.copy()
        e.update(env)
    return subprocess.run([str(mk), *args], text=True, capture_output=True, env=e)


def _write_plan(plan_path: Path) -> None:
    plan_path.write_text(
        json.dumps(
            [
                {"namespace": "ns1", "name": "dep1", "patch": {"spec": {"replicas": 2}}},
                {"namespace": "ns1", "name": "dep2", "patch": {"spec": {"replicas": 3}}},
            ]
        ),
        encoding="utf-8",
    )


def _write_verify_ok(plan_dir: Path) -> None:
    (plan_dir / "k8s_verify_latest.json").write_text(json.dumps({"ok": True}), encoding="utf-8")


def _write_fake_kubectl(path: Path, *, patch_rc: int = 0, patch_stderr: str = "") -> None:
    stderr_line = f"  echo {json.dumps(patch_stderr)} >&2\n" if patch_stderr else ""
    path.write_text(
        f"""#!/usr/bin/env bash
set -Eeuo pipefail

if [[ $# -ge 2 && \"$1\" == \"config\" && \"$2\" == \"current-context\" ]]; then
  echo \"fake-context\"
  exit 0
fi

if [[ $# -ge 5 && \"$1\" == \"-n\" && \"$3\" == \"patch\" ]]; then
{stderr_line}  echo \"patched\"
  exit {patch_rc}
fi

exit 1
""",
        encoding="utf-8",
    )
    path.chmod(0o755)


def test_k8s_apply_real_ok(tmp_path: Path, mk_path: Path) -> None:
    plan = tmp_path / "plan.json"
    _write_plan(plan)
    _write_verify_ok(plan.parent)

    kubectl = tmp_path / "kubectl"
    _write_fake_kubectl(kubectl, patch_rc=0)

    out_dir = tmp_path / "out_ok"
    cp = _run(
        mk_path,
        ["k8s", "apply", "--plan", str(plan), "--out", str(out_dir)],
        env={"MODEKEEPER_PAID": "1", "MODEKEEPER_INTERNAL_OVERRIDE": "1", "KUBECTL": str(kubectl)},
    )
    assert cp.returncode == 0

    latest = out_dir / "k8s_apply_latest.json"
    assert latest.exists()
    report = json.loads(latest.read_text(encoding="utf-8"))
    assert report.get("schema_version") == "v0"
    assert isinstance(report.get("duration_s"), int)
    assert report.get("paid_enabled") is True
    assert report.get("would_apply") is True
    assert report.get("ok") is True
    assert report.get("kubectl_context") == "fake-context"
    assert report.get("checks", {}).get("kubectl_present") is True
    checks_items = report.get("checks", {}).get("items")
    items = report.get("items")
    assert isinstance(checks_items, list)
    assert isinstance(items, list)
    assert len(checks_items) == 2
    assert len(items) == 2
    assert [it.get("ok") for it in items] == [it.get("ok") for it in checks_items]


def test_k8s_apply_real_fail(tmp_path: Path, mk_path: Path) -> None:
    plan = tmp_path / "plan.json"
    _write_plan(plan)
    _write_verify_ok(plan.parent)

    kubectl = tmp_path / "kubectl"
    _write_fake_kubectl(kubectl, patch_rc=1)

    out_dir = tmp_path / "out_fail"
    cp = _run(
        mk_path,
        ["k8s", "apply", "--plan", str(plan), "--out", str(out_dir)],
        env={"MODEKEEPER_PAID": "1", "MODEKEEPER_INTERNAL_OVERRIDE": "1", "KUBECTL": str(kubectl)},
    )
    assert cp.returncode == 1

    latest = out_dir / "k8s_apply_latest.json"
    assert latest.exists()
    report = json.loads(latest.read_text(encoding="utf-8"))
    assert report.get("ok") is False
    assert report.get("would_apply") is True
    checks_items = report.get("checks", {}).get("items")
    items = report.get("items")
    assert isinstance(checks_items, list)
    assert isinstance(items, list)
    assert len(checks_items) == 1
    assert len(items) == 1
    assert [it.get("ok") for it in items] == [it.get("ok") for it in checks_items]


def test_k8s_apply_forbidden_attaches_rbac_details(tmp_path: Path, mk_path: Path) -> None:
    plan = tmp_path / "plan.json"
    _write_plan(plan)
    _write_verify_ok(plan.parent)

    forbidden = (
        'Error from server (Forbidden): deployments.apps "dep1" is forbidden: '
        'User "system:serviceaccount:ns1:sa" cannot patch resource "deployments" '
        'in API group "apps" in the namespace "ns1"'
    )
    kubectl = tmp_path / "kubectl"
    _write_fake_kubectl(kubectl, patch_rc=1, patch_stderr=forbidden)

    out_dir = tmp_path / "out_forbidden"
    cp = _run(
        mk_path,
        ["k8s", "apply", "--plan", str(plan), "--out", str(out_dir)],
        env={"MODEKEEPER_PAID": "1", "MODEKEEPER_INTERNAL_OVERRIDE": "1", "KUBECTL": str(kubectl)},
    )
    assert cp.returncode == 1

    report = json.loads((out_dir / "k8s_apply_latest.json").read_text(encoding="utf-8"))
    rbac = report.get("details", {}).get("rbac")
    assert isinstance(rbac, dict)
    assert rbac["user"] == "system:serviceaccount:ns1:sa"
    assert rbac["verb"] == "patch"
    assert rbac["resource"] == "deployments"
    assert rbac["api_group"] == "apps"
    assert rbac["namespace"] == "ns1"
    assert isinstance(rbac.get("hint"), str) and rbac["hint"]
