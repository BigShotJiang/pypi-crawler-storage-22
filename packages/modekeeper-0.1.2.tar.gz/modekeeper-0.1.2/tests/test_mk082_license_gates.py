import base64
import json
import subprocess
from pathlib import Path

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from modekeeper.license.canonical import canonical_json_bytes


def _run(mk: Path, args: list[str], env: dict | None = None) -> subprocess.CompletedProcess[str]:
    merged_env = None
    if env is not None:
        import os

        merged_env = os.environ.copy()
        merged_env.update(env)
    return subprocess.run([str(mk), *args], text=True, capture_output=True, env=merged_env)


def _write_plan(path: Path) -> None:
    path.write_text(
        json.dumps([{"namespace": "ns1", "name": "dep1", "patch": {"spec": {"replicas": 2}}}]) + "\n",
        encoding="utf-8",
    )


def _write_verify_ok(plan_dir: Path) -> None:
    (plan_dir / "k8s_verify_latest.json").write_text(json.dumps({"ok": True}), encoding="utf-8")


def _write_fake_kubectl(path: Path) -> None:
    path.write_text(
        """#!/usr/bin/env bash
set -Eeuo pipefail

if [[ $# -ge 2 && "$1" == "config" && "$2" == "current-context" ]]; then
  echo "fake-context"
  exit 0
fi

if [[ "$*" == *"--patch"* ]]; then
  echo "patched"
  exit 0
fi

echo "unexpected args: $*" >&2
exit 1
""",
        encoding="utf-8",
    )
    path.chmod(0o755)


def _sign(payload: dict) -> str:
    key = Ed25519PrivateKey.from_private_bytes(bytes(range(32)))
    return base64.b64encode(key.sign(canonical_json_bytes(payload))).decode("ascii")


def _write_license(
    path: Path,
    *,
    issued_at: int,
    expires_at: int,
    entitlements: list[str],
    kube_context: str | None = None,
    kid: str | None = None,
    tamper: bool = False,
) -> None:
    payload = {
        "schema_version": "license.v1",
        "org": "Acme",
        "issued_at": issued_at,
        "expires_at": expires_at,
        "entitlements": entitlements,
    }
    if kube_context is not None:
        payload["bindings"] = {"kube_context": kube_context}
    if kid is not None:
        payload["kid"] = kid
    license_data = {**payload, "signature": _sign(payload)}
    if tamper:
        license_data["org"] = "Tampered"
    path.write_text(
        json.dumps(license_data, indent=2, sort_keys=True, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )


def _block_reason(out_dir: Path) -> str | None:
    latest = out_dir / "k8s_apply_latest.json"
    if not latest.exists():
        return None
    report = json.loads(latest.read_text(encoding="utf-8"))
    reason = report.get("block_reason")
    return str(reason) if isinstance(reason, str) else None


def test_apply_gate_blocks_when_license_missing(tmp_path: Path, mk_path: Path) -> None:
    plan = tmp_path / "plan.json"
    _write_plan(plan)
    _write_verify_ok(plan.parent)
    kubectl = tmp_path / "kubectl"
    _write_fake_kubectl(kubectl)

    out_dir = tmp_path / "out_missing"
    cp = _run(
        mk_path,
        ["k8s", "apply", "--plan", str(plan), "--out", str(out_dir)],
        env={"KUBECTL": str(kubectl), "MODEKEEPER_INTERNAL_OVERRIDE": "0"},
    )
    assert cp.returncode == 2
    assert _block_reason(out_dir) == "license_missing"


def test_apply_gate_allows_valid_license_with_apply_entitlement(tmp_path: Path, mk_path: Path) -> None:
    plan = tmp_path / "plan.json"
    _write_plan(plan)
    _write_verify_ok(plan.parent)
    kubectl = tmp_path / "kubectl"
    _write_fake_kubectl(kubectl)

    license_path = tmp_path / "license_ok.json"
    _write_license(
        license_path,
        issued_at=1700000000,
        expires_at=4102444800,
        entitlements=["apply", "observe"],
        kube_context="fake-context",
    )

    out_dir = tmp_path / "out_ok"
    cp = _run(
        mk_path,
        ["k8s", "apply", "--plan", str(plan), "--out", str(out_dir)],
        env={"KUBECTL": str(kubectl), "MODEKEEPER_LICENSE_PATH": str(license_path)},
    )
    assert cp.returncode == 0

    report = json.loads((out_dir / "k8s_apply_latest.json").read_text(encoding="utf-8"))
    assert report.get("would_apply") is True
    assert report.get("ok") is True
    assert report.get("block_reason") is None


def test_apply_gate_blocks_expired_license(tmp_path: Path, mk_path: Path) -> None:
    plan = tmp_path / "plan.json"
    _write_plan(plan)
    _write_verify_ok(plan.parent)
    kubectl = tmp_path / "kubectl"
    _write_fake_kubectl(kubectl)

    license_path = tmp_path / "license_expired.json"
    _write_license(
        license_path,
        issued_at=1500000000,
        expires_at=1500000100,
        entitlements=["apply"],
    )

    out_dir = tmp_path / "out_expired"
    cp = _run(
        mk_path,
        ["k8s", "apply", "--plan", str(plan), "--out", str(out_dir)],
        env={"KUBECTL": str(kubectl), "MODEKEEPER_LICENSE_PATH": str(license_path)},
    )
    assert cp.returncode == 2
    assert _block_reason(out_dir) == "license_expired"


def test_apply_gate_blocks_invalid_signature(tmp_path: Path, mk_path: Path) -> None:
    plan = tmp_path / "plan.json"
    _write_plan(plan)
    _write_verify_ok(plan.parent)
    kubectl = tmp_path / "kubectl"
    _write_fake_kubectl(kubectl)

    license_path = tmp_path / "license_invalid_sig.json"
    _write_license(
        license_path,
        issued_at=1700000000,
        expires_at=4102444800,
        entitlements=["apply"],
        tamper=True,
    )

    out_dir = tmp_path / "out_invalid_sig"
    cp = _run(
        mk_path,
        ["k8s", "apply", "--plan", str(plan), "--out", str(out_dir)],
        env={"KUBECTL": str(kubectl), "MODEKEEPER_LICENSE_PATH": str(license_path)},
    )
    assert cp.returncode == 2
    assert _block_reason(out_dir) == "license_invalid"


def test_apply_gate_blocks_entitlement_missing(tmp_path: Path, mk_path: Path) -> None:
    plan = tmp_path / "plan.json"
    _write_plan(plan)
    _write_verify_ok(plan.parent)
    kubectl = tmp_path / "kubectl"
    _write_fake_kubectl(kubectl)

    license_path = tmp_path / "license_no_apply.json"
    _write_license(
        license_path,
        issued_at=1700000000,
        expires_at=4102444800,
        entitlements=["observe"],
    )

    out_dir = tmp_path / "out_no_apply"
    cp = _run(
        mk_path,
        ["k8s", "apply", "--plan", str(plan), "--out", str(out_dir)],
        env={"KUBECTL": str(kubectl), "MODEKEEPER_LICENSE_PATH": str(license_path)},
    )
    assert cp.returncode == 2
    assert _block_reason(out_dir) == "entitlement_missing"


def test_apply_gate_blocks_binding_mismatch(tmp_path: Path, mk_path: Path) -> None:
    plan = tmp_path / "plan.json"
    _write_plan(plan)
    _write_verify_ok(plan.parent)
    kubectl = tmp_path / "kubectl"
    _write_fake_kubectl(kubectl)

    license_path = tmp_path / "license_binding_mismatch.json"
    _write_license(
        license_path,
        issued_at=1700000000,
        expires_at=4102444800,
        entitlements=["apply"],
        kube_context="other-context",
    )

    out_dir = tmp_path / "out_binding_mismatch"
    cp = _run(
        mk_path,
        ["k8s", "apply", "--plan", str(plan), "--out", str(out_dir)],
        env={"KUBECTL": str(kubectl), "MODEKEEPER_LICENSE_PATH": str(license_path)},
    )
    assert cp.returncode == 2
    assert _block_reason(out_dir) == "binding_mismatch"


def test_apply_gate_kill_switch_wins_even_with_valid_license(tmp_path: Path, mk_path: Path) -> None:
    plan = tmp_path / "plan.json"
    _write_plan(plan)
    _write_verify_ok(plan.parent)
    kubectl = tmp_path / "kubectl"
    _write_fake_kubectl(kubectl)

    license_path = tmp_path / "license_ok.json"
    _write_license(
        license_path,
        issued_at=1700000000,
        expires_at=4102444800,
        entitlements=["apply", "observe"],
        kube_context="fake-context",
    )

    out_dir = tmp_path / "out_kill_switch"
    cp = _run(
        mk_path,
        ["k8s", "apply", "--plan", str(plan), "--out", str(out_dir)],
        env={
            "KUBECTL": str(kubectl),
            "MODEKEEPER_LICENSE_PATH": str(license_path),
            "MODEKEEPER_KILL_SWITCH": "1",
        },
    )
    assert cp.returncode == 2
    assert _block_reason(out_dir) == "kill_switch"


def test_apply_gate_unknown_kid_blocks_as_license_invalid(tmp_path: Path, mk_path: Path) -> None:
    plan = tmp_path / "plan.json"
    _write_plan(plan)
    _write_verify_ok(plan.parent)
    kubectl = tmp_path / "kubectl"
    _write_fake_kubectl(kubectl)

    license_path = tmp_path / "license_unknown_kid.json"
    _write_license(
        license_path,
        issued_at=1700000000,
        expires_at=4102444800,
        entitlements=["apply"],
        kid="mk-dev-unknown",
    )

    out_dir = tmp_path / "out_unknown_kid"
    cp = _run(
        mk_path,
        ["k8s", "apply", "--plan", str(plan), "--out", str(out_dir)],
        env={"KUBECTL": str(kubectl), "MODEKEEPER_LICENSE_PATH": str(license_path)},
    )
    assert cp.returncode == 2
    assert _block_reason(out_dir) == "license_invalid"
