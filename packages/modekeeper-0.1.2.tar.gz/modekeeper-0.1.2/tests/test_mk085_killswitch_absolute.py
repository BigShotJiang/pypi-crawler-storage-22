import json
import os
import subprocess
from pathlib import Path


def _write_fake_kubectl(path: Path, log_path: Path) -> None:
    path.write_text(
        f"""#!/usr/bin/env bash
set -Eeuo pipefail

echo "$*" >> "{log_path}"

if [[ $# -ge 2 && "$1" == "config" && "$2" == "current-context" ]]; then
  echo "test-context"
  exit 0
fi

if [[ $# -ge 4 && "$1" == "get" && "$2" == "namespace/ns1" && "$3" == "-o" && "$4" == "name" ]]; then
  echo "namespace/ns1"
  exit 0
fi

if [[ $# -ge 6 && "$1" == "-n" && "$2" == "ns1" && "$3" == "get" && "$4" == "deployment/dep1" && "$5" == "-o" && "$6" == "name" ]]; then
  echo "deployment.apps/dep1"
  exit 0
fi

if [[ "$*" == *"--dry-run=server"* || "$*" == *"--dry-run=client"* ]]; then
  echo '{{"kind":"Deployment","metadata":{{"name":"dep1"}}}}'
  exit 0
fi

if [[ "$*" == *"--patch"* ]]; then
  echo "patched"
  exit 0
fi

echo "unexpected args: $*" >&2
exit 1
""",
        encoding="utf-8",
    )
    path.chmod(0o755)


def _write_plan(path: Path) -> None:
    path.write_text(
        json.dumps([{"namespace": "ns1", "name": "dep1", "patch": {"spec": {"replicas": 2}}}]),
        encoding="utf-8",
    )


def _write_verify(path: Path) -> None:
    path.write_text(json.dumps({"ok": True}), encoding="utf-8")


def _run(mk: Path, args: list[str], env: dict) -> subprocess.CompletedProcess[str]:
    return subprocess.run([str(mk), *args], text=True, capture_output=True, env=env)


def test_k8s_apply_kill_switch_blocks_with_internal_override(tmp_path: Path, mk_path: Path) -> None:
    plan = tmp_path / "plan.json"
    _write_plan(plan)
    _write_verify(tmp_path / "k8s_verify_latest.json")
    out_dir = tmp_path / "out"
    kubectl_log = tmp_path / "kubectl.log"
    kubectl = tmp_path / "kubectl"
    _write_fake_kubectl(kubectl, kubectl_log)

    env = {
        **os.environ,
        "MODEKEEPER_KILL_SWITCH": "1",
        "MODEKEEPER_PAID": "1",
        "MODEKEEPER_INTERNAL_OVERRIDE": "1",
        "KUBECTL": str(kubectl),
    }

    cp = _run(mk_path, ["k8s", "apply", "--plan", str(plan), "--out", str(out_dir)], env)
    assert cp.returncode == 2
    assert cp.stderr.strip() == "ERROR: MODEKEEPER_KILL_SWITCH=1 blocks apply/mutate operations"
    report = json.loads((out_dir / "k8s_apply_latest.json").read_text(encoding="utf-8"))
    assert report.get("block_reason") == "kill_switch"
    assert report.get("blocked") is True
    assert report.get("verify_blocker") == "kill_switch"
    assert report.get("reason") == "kill_switch"
    assert report.get("would_apply") is False
    if kubectl_log.exists():
        assert "--patch" not in kubectl_log.read_text(encoding="utf-8")


def test_k8s_apply_kill_switch_blocks_without_internal_override(tmp_path: Path, mk_path: Path) -> None:
    plan = tmp_path / "plan.json"
    _write_plan(plan)
    _write_verify(tmp_path / "k8s_verify_latest.json")
    out_dir = tmp_path / "out"
    kubectl_log = tmp_path / "kubectl.log"
    kubectl = tmp_path / "kubectl"
    _write_fake_kubectl(kubectl, kubectl_log)

    env = {
        **os.environ,
        "MODEKEEPER_KILL_SWITCH": "1",
        "KUBECTL": str(kubectl),
    }

    cp = _run(mk_path, ["k8s", "apply", "--plan", str(plan), "--out", str(out_dir)], env)
    assert cp.returncode == 2
    assert cp.stderr.strip() == "ERROR: MODEKEEPER_KILL_SWITCH=1 blocks apply/mutate operations"
    report = json.loads((out_dir / "k8s_apply_latest.json").read_text(encoding="utf-8"))
    assert report.get("block_reason") == "kill_switch"
    assert report.get("blocked") is True
    assert report.get("verify_blocker") == "kill_switch"
    assert report.get("reason") == "kill_switch"
    assert report.get("would_apply") is False
    if kubectl_log.exists():
        assert "--patch" not in kubectl_log.read_text(encoding="utf-8")


def test_k8s_apply_kill_switch_blocks_even_with_force_flag(tmp_path: Path, mk_path: Path) -> None:
    plan = tmp_path / "plan.json"
    _write_plan(plan)
    _write_verify(tmp_path / "k8s_verify_latest.json")
    out_dir = tmp_path / "out"
    kubectl_log = tmp_path / "kubectl.log"
    kubectl = tmp_path / "kubectl"
    _write_fake_kubectl(kubectl, kubectl_log)

    env = {
        **os.environ,
        "MODEKEEPER_KILL_SWITCH": "1",
        "MODEKEEPER_PAID": "1",
        "MODEKEEPER_INTERNAL_OVERRIDE": "1",
        "KUBECTL": str(kubectl),
    }

    cp = _run(
        mk_path,
        ["k8s", "apply", "--plan", str(plan), "--out", str(out_dir), "--force"],
        env,
    )
    assert cp.returncode == 2
    assert cp.stderr.strip() == "ERROR: MODEKEEPER_KILL_SWITCH=1 blocks apply/mutate operations"
    report = json.loads((out_dir / "k8s_apply_latest.json").read_text(encoding="utf-8"))
    assert report.get("block_reason") == "kill_switch"
    assert report.get("blocked") is True
    assert report.get("verify_blocker") == "kill_switch"
    assert report.get("reason") == "kill_switch"
    assert report.get("would_apply") is False
    if kubectl_log.exists():
        assert "--patch" not in kubectl_log.read_text(encoding="utf-8")


def test_closed_loop_apply_kill_switch_blocks_with_internal_override(tmp_path: Path, mk_path: Path) -> None:
    out_dir = tmp_path / "out"
    kubectl_log = tmp_path / "kubectl.log"
    kubectl = tmp_path / "kubectl"
    _write_fake_kubectl(kubectl, kubectl_log)

    env = {
        **os.environ,
        "MODEKEEPER_KILL_SWITCH": "1",
        "MODEKEEPER_PAID": "1",
        "MODEKEEPER_INTERNAL_OVERRIDE": "1",
        "KUBECTL": str(kubectl),
        "HOME": str(tmp_path),
        "KUBECONFIG": str(tmp_path / "kubeconfig"),
    }
    cp = _run(
        mk_path,
        [
            "closed-loop",
            "run",
            "--apply",
            "--k8s-namespace",
            "ns1",
            "--k8s-deployment",
            "dep1",
            "--out",
            str(out_dir),
        ],
        env,
    )
    assert cp.returncode == 2
    assert cp.stderr.strip() == "ERROR: MODEKEEPER_KILL_SWITCH=1 blocks apply/mutate operations"

    latest = json.loads((out_dir / "closed_loop_latest.json").read_text(encoding="utf-8"))
    assert latest.get("apply_blocked_reason") == "kill_switch"
    assert latest.get("apply_attempted") is False
    assert latest.get("apply_ok") is None
    assert latest.get("k8s_apply_rc") == 2
    apply_latest_path = out_dir / "k8s_apply_latest.json"
    assert apply_latest_path.exists()
    apply_latest = json.loads(apply_latest_path.read_text(encoding="utf-8"))
    assert apply_latest.get("blocked") is True
    assert apply_latest.get("verify_blocker") == "kill_switch"
    assert apply_latest.get("reason") == "kill_switch"
    assert "--patch" not in kubectl_log.read_text(encoding="utf-8")


def test_closed_loop_apply_kill_switch_blocks_without_internal_override(tmp_path: Path, mk_path: Path) -> None:
    out_dir = tmp_path / "out"
    kubectl_log = tmp_path / "kubectl.log"
    kubectl = tmp_path / "kubectl"
    _write_fake_kubectl(kubectl, kubectl_log)

    env = {
        **os.environ,
        "MODEKEEPER_KILL_SWITCH": "1",
        "KUBECTL": str(kubectl),
        "HOME": str(tmp_path),
        "KUBECONFIG": str(tmp_path / "kubeconfig"),
    }
    cp = _run(
        mk_path,
        [
            "closed-loop",
            "run",
            "--apply",
            "--k8s-namespace",
            "ns1",
            "--k8s-deployment",
            "dep1",
            "--out",
            str(out_dir),
        ],
        env,
    )
    assert cp.returncode == 2
    assert cp.stderr.strip() == "ERROR: MODEKEEPER_KILL_SWITCH=1 blocks apply/mutate operations"

    latest = json.loads((out_dir / "closed_loop_latest.json").read_text(encoding="utf-8"))
    assert latest.get("apply_blocked_reason") == "kill_switch"
    assert latest.get("apply_attempted") is False
    assert latest.get("apply_ok") is None
    assert latest.get("k8s_apply_rc") == 2
    apply_latest_path = out_dir / "k8s_apply_latest.json"
    assert apply_latest_path.exists()
    apply_latest = json.loads(apply_latest_path.read_text(encoding="utf-8"))
    assert apply_latest.get("blocked") is True
    assert apply_latest.get("verify_blocker") == "kill_switch"
    assert apply_latest.get("reason") == "kill_switch"
    assert "--patch" not in kubectl_log.read_text(encoding="utf-8")


def test_closed_loop_watch_apply_kill_switch_blocks_at_entrypoint(
    tmp_path: Path, mk_path: Path
) -> None:
    out_dir = tmp_path / "watch_out"
    observe_path = tmp_path / "observe.jsonl"
    observe_path.write_text(
        "\n".join(
            [
                '{"ts":"2026-01-01T00:00:00Z","step_time_ms":100,"loss":1.0}',
                '{"ts":"2026-01-01T00:00:01Z","step_time_ms":100,"loss":1.0}',
            ]
        )
        + "\n",
        encoding="utf-8",
    )

    env = {
        **os.environ,
        "MODEKEEPER_KILL_SWITCH": "1",
        "MODEKEEPER_PAID": "1",
        "MODEKEEPER_INTERNAL_OVERRIDE": "1",
    }
    cp = _run(
        mk_path,
        [
            "closed-loop",
            "watch",
            "--scenario",
            "drift",
            "--apply",
            "--observe-source",
            "file",
            "--observe-path",
            str(observe_path),
            "--out",
            str(out_dir),
            "--max-iterations",
            "1",
            "--interval",
            "0s",
        ],
        env,
    )
    assert cp.returncode == 2
    assert cp.stderr.strip() == "ERROR: MODEKEEPER_KILL_SWITCH=1 blocks apply/mutate operations"
    assert not (out_dir / "iter_0001").exists()


def test_closed_loop_watch_dry_run_works_with_kill_switch(tmp_path: Path, mk_path: Path) -> None:
    out_dir = tmp_path / "watch_out"
    observe_path = tmp_path / "observe.jsonl"
    observe_path.write_text(
        "\n".join(
            [
                '{"ts":"2026-01-01T00:00:00Z","step_time_ms":100,"loss":1.0}',
                '{"ts":"2026-01-01T00:00:01Z","step_time_ms":100,"loss":1.0}',
            ]
        )
        + "\n",
        encoding="utf-8",
    )

    env = {
        **os.environ,
        "MODEKEEPER_KILL_SWITCH": "1",
    }
    cp = _run(
        mk_path,
        [
            "closed-loop",
            "watch",
            "--scenario",
            "drift",
            "--dry-run",
            "--observe-source",
            "file",
            "--observe-path",
            str(observe_path),
            "--out",
            str(out_dir),
            "--max-iterations",
            "1",
            "--interval",
            "0s",
        ],
        env,
    )
    assert cp.returncode == 0
    assert (out_dir / "iter_0001" / "closed_loop_latest.json").exists()
    latest = json.loads((out_dir / "iter_0001" / "closed_loop_latest.json").read_text(encoding="utf-8"))
    assert latest.get("apply_requested") is False
