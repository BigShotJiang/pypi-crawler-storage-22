import os
import subprocess
from pathlib import Path


def _repo_root() -> Path:
    return Path(__file__).resolve().parents[1]


def _ensure_wheel(tmp_path: Path) -> Path:
    repo = _repo_root()
    dist_dir = repo / "dist"
    wheels = sorted(dist_dir.glob("modekeeper-*.whl"))
    if wheels:
        return wheels[-1]

    out_dir = tmp_path / "dist"
    out_dir.mkdir(parents=True, exist_ok=True)
    cp = subprocess.run(
        ["python", "-m", "build", "--wheel", "--outdir", str(out_dir)],
        cwd=repo,
        check=False,
        capture_output=True,
        text=True,
    )
    assert cp.returncode == 0, cp.stderr or cp.stdout

    built = sorted(out_dir.glob("modekeeper-*.whl"))
    assert built, "expected a modekeeper wheel"
    return built[-1]


def test_mk_install_bootstraps_user_install(tmp_path: Path) -> None:
    repo = _repo_root()
    wheel = _ensure_wheel(tmp_path)

    home_dir = tmp_path
    env = {
        **os.environ,
        "HOME": str(home_dir),
        "MODEKEEPER_WHEEL": str(wheel),
    }

    install = subprocess.run(
        [str(repo / "bin" / "mk-install")],
        cwd=repo,
        check=False,
        capture_output=True,
        text=True,
        env=env,
    )
    assert install.returncode == 0, install.stderr or install.stdout

    mk_bin = home_dir / ".modekeeper" / "venv" / "bin" / "mk"
    mk_link = home_dir / ".local" / "bin" / "mk"
    assert mk_bin.exists()
    assert mk_link.exists()
    assert mk_link.is_symlink()

    kubectl = tmp_path / "kubectl"
    kubectl.write_text("#!/usr/bin/env bash\nexit 0\n", encoding="utf-8")
    kubectl.chmod(0o755)
    kubeconfig = tmp_path / "kubeconfig"
    kubeconfig.write_text("apiVersion: v1\n", encoding="utf-8")

    run_env = {
        **env,
        "KUBECTL": str(kubectl),
        "KUBECONFIG": str(kubeconfig),
    }

    doctor = subprocess.run(
        [str(mk_link), "doctor"],
        check=False,
        capture_output=True,
        text=True,
        env=run_env,
    )
    assert doctor.returncode == 0
    assert "Doctor result: PASS" in doctor.stdout

    help_cp = subprocess.run(
        [str(mk_link), "--help"],
        check=False,
        capture_output=True,
        text=True,
        env=run_env,
    )
    assert help_cp.returncode == 0
