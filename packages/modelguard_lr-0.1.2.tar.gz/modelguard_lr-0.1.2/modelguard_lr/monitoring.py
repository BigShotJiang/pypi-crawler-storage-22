from scipy.stats import ks_2samp, norm, chi2, sem
import numpy as np
import sklearn
from sklearn.metrics import (roc_curve, auc)
import pandas as pd
import seaborn as sns
from matplotlib import pyplot as plt
from pandas.api.types import CategoricalDtype
from sklearn.metrics import confusion_matrix
import math
from matplotlib.colors import LinearSegmentedColormap
from sklearn.metrics import r2_score

from .utils import threshold



class  ClassificationMetrics:


    @staticmethod
    def Gini_model(target, pred, target_value=1, gini_dev=None, conf_inter_alpha=None, conf_inter_stdev='base'):


        '''
        #########################################################################################

        data = pd.DataFrame({
            "target": [0, 0, 1, 0, 1, 0, 1, 1, 0, 1],
            "pd":     [0.05, 0.10, 0.85, 0.20, 0.90, 0.15, 0.75, 0.60, 0.30, 0.95]
        })
        Gini_model(data['target'], data['pd'])

        ##########################################################################################

        Parameters
        ----------
        target: TYPE: pandas Series
            DESCRIPTION: Actual values of target variable

        pred: TYPE: pandas Series
            DESCRIPTION: Model predictions

        target_value:
            DESCRIPTION: Parameter should be defined when events and non-events are not labeled as 1 and 0.
            This parameter should be assigned as a value in 'target' which corresponds to an event (for example, default event or customer is churn).

        gini_dev: TYPE: int64, float64
            DESCRIPTION: The value of Gini for the development sample is needed to calculate the validation zone

        conf_inter_alpha: TYPE: float64
            DESCRIPTION: The critical value to calculate the width of confidence interval (usually 0.05 or 0.01)

        conf_inter_stdev: TYPE: str
            DESCRIPTION: Can be either 'base' or 'complex', this will specify which formula will be used to calculate
            standard deviation for confidence interval

        '''

        if target_value != 1:
            target = np.where(target==target_value,1,0)

        if target.nunique() == 1:
            return None, None

        fpr, tpr, thresholds = roc_curve(target, pred)
        roc_auc = auc(fpr, tpr)
        GINI = (2 * roc_auc) - 1

        if gini_dev is None:

            red_cond, green_cond = threshold('Gini_model_abs')

            if eval(str(abs(GINI))+red_cond):
                zone = 'red zone'
            elif eval(str(abs(GINI))+green_cond):
                zone = 'green zone'
            else:
                zone = 'amber zone'

            if conf_inter_alpha is not None:
                if conf_inter_stdev == 'base':
                    stdev = np.sqrt((GINI+1)**2*(1-GINI)/sum(target)/(3+GINI))
                elif conf_inter_stdev == 'complex':
                    stdev = np.sqrt((1-GINI**2+(sum(target)-1)*(4*(GINI+1)/(3-GINI)-(GINI+1)**2)+(GINI-1)*(4*(GINI+1)**2/(3+GINI)-(GINI+1)**2))/sum(target)/(len(target)-sum(target)))

                print(GINI, zone,'\n',
                    'Confidence interval: ', GINI-norm.ppf(1-conf_inter_alpha/2)*stdev, ' <= GINI <= ',
                    GINI+norm.ppf(1-conf_inter_alpha/2)*stdev)

        

        else:
            red_cond, green_cond = threshold('Gini_model_rel')

            if eval(str(gini_dev - GINI)+red_cond):
                zone = 'red zone'
            elif eval(str(gini_dev - GINI)+green_cond):
                zone = 'green zone'
            else:
                zone = 'amber zone'

            print('Gini on validation sample: ', GINI, '\n',
                'Gini on development sample: ', gini_dev, '\n',
                'Difference: ', gini_dev-GINI, '\n',
                zone)
        return GINI, zone




    @staticmethod
    def KS_statistic(target, pred, target_value=1):

        '''

        Parameters
        ----------
        target: TYPE: pandas Series
            DESCRIPTION: Actual values of target variable

        pred: TYPE: pandas Series
            DESCRIPTION: Model predictions

        target_value:
            DESCRIPTION: Parameter should be defined when events and non-events are not labeled as 1 and 0.
            This parameter should be assigned as a value in 'target' which corresponds to an event (for example, default event or customer is churn).

        '''

        if target_value != 1:
            target = np.where(target==target_value,1,0)

        df = pd.concat([target, pred], axis=1)
        stat, pvalue = ks_2samp(df[df[target.name] == 1][pred.name], df[df[target.name] == 0][pred.name])

        red_cond, green_cond = threshold('KS_statistic')

        if eval(str(pvalue)+red_cond):
            zone = 'red zone'
        elif eval(str(pvalue)+green_cond):
            zone = 'green zone'
        else:
            zone = 'amber zone'

        return round(stat, 3), round(pvalue, 3), zone





    @staticmethod
    def KS_graph(target, pred, need_binning=True, n_bins=10, categories=None, target_value=1):

        '''
        ###############################################################################
        
        data = pd.DataFrame({
            "target": [0, 0, 1, 0, 1, 0, 1, 1, 0, 1],
            "pd":     [0.05, 0.10, 0.85, 0.20, 0.90, 0.15, 0.75, 0.60, 0.30, 0.95]
        })
        KS_graph(data['target'], data['pd'])

        ###############################################################################

        Parameters
        ----------
        target: TYPE: pandas Series
            DESCRIPTION: Actual values of target variable

        pred: TYPE: pandas Series
            DESCRIPTION: Model predictions

        need_binning: TYPE: bool
            DESCRIPTION: Whether to bin the values of model predictions, not needed if values are already binned

        n_bins: TYPE: int64
            DESCRIPTION: Desiderable number of bins to split values of model predictions

        categories: TYPE: list
            DESCRIPTION: If bins_col is present, this parameter may be used to establish the order of ratings/categories
            by which grouped data will be sorted. If the 'categories' parameter is absent,
            the groupped data will be sorted in ascending order.

        target_value:
            DESCRIPTION: Parameter should be defined when events and non-events are not labeled as 1 and 0.
            This parameter should be assigned as a value in 'target' which corresponds to an event (for example, default event or customer is churn).

        '''

        if target_value != 1:
            target = np.where(target==target_value,1,0)

        KS_stat = KS_statistic(target, pred)[0]

        df = pd.concat([target, pred], axis=1)
        df = df.sort_values(pred.name).reset_index(drop=True)
        df['num_obs'] = 1
        df[pred.name] = round(df[pred.name], 3)

        if (need_binning) & (pred.nunique() > n_bins):
            min_ = min(df[pred.name])
            max_ = max(df[pred.name])
            bins = np.append(np.arange(min_, max_, (max_ - min_) / n_bins), max_)
            df[pred.name] = pd.cut(df[pred.name], bins, include_lowest=True)
            df = df.groupby(pred.name, as_index=False).agg({target.name: 'sum', 'num_obs': 'count'})
            df[pred.name] = df[pred.name].apply(lambda x: pd.Interval(left=round(x.left, 3), right=round(x.right, 3)))

        else:
            if categories is not None:
                cat_rating_order = CategoricalDtype(categories, ordered=True)
                df[pred.name] = data[pred.name].astype(cat_rating_order)
            df = df.groupby(pred.name, as_index=False).agg({target.name: 'sum', 'num_obs': 'count'})

        df['non-target'] = df['num_obs'] - df[target.name]
        df['target_cumshare'] = np.cumsum(df[target.name]) / sum(df[target.name])
        df['non-target_cumshare'] = np.cumsum(df['non-target']) / sum(df['non-target'])
        df['KS'] = abs(df['target_cumshare'] - df['non-target_cumshare'])
        max_ks = df[df['KS'] == max(df['KS'])]

        plt.figure(figsize=(10, 6))
        plt.plot(df['target_cumshare'], label='target distribution', color='red')
        plt.plot(df['non-target_cumshare'], label='non-target distribution', color='green')
        plt.xticks(df.index, df[pred.name], rotation=50)
        plt.vlines(max_ks.index, max_ks['target_cumshare'].values,
                max_ks['non-target_cumshare'].values, color='grey', linestyles='dashed',
                label='KS stat = %0.2f' % KS_stat)
        plt.xlabel(pred.name, size=12)
        plt.legend(loc="upper left", prop={'size': 12})
        plt.title('KS test for ' + pred.name)






    @staticmethod
    def confusion_matrix_graph(target, predicted_label, target_label=None):
        
        '''

        Parameters
        ----------
        target: TYPE: pandas Series 
            DESCRIPTION: Actual values of target variable, should be binary
            
        predicted_label: TYPE: pandas Series 
            DESCRIPTION: Model predictions, should be binary

        target_label: TYPE: str
            DESCRIPTION: Name of the label you are trying to predict
            
        '''     
        
        cm = confusion_matrix(target, predicted_label)
        
    #     cm[0][0] - tn
    #     cm[0][1] - fp
    #     cm[1][0] - fn
    #     cm[1][1] - tp
        
        sensitivity = round(cm[1][1] / (cm[1][1] + cm[1][0]),3)
        specificity = round(cm[0][0] / (cm[0][0] + cm[0][1]),3)
        precision = round(cm[1][1] / (cm[1][1] + cm[0][1]),3)
        FN_rate = round(cm[1][0] / (cm[1][0] + cm[1][1]),3)
        FP_rate = round(cm[0][1] / (cm[0][1] + cm[0][0]),3)
        accuracy = round((cm[0][0] + cm[1][1])/ (cm.sum()),3)
        f1_score = round(2*precision*sensitivity/(precision+sensitivity),3)
        
        metrics = [accuracy,f1_score,sensitivity,specificity,precision,FP_rate,FN_rate]
        thresholds = ['Accuracy','F1 Score','Sensitivity / Recall / True Positive rate','Specificity / True Negative rate','Precision','False Positive Rate','False Negative Rate']
        
        m=[]
        s=[]
        z=[]
        for i in range(len(metrics)):
            red_cond, green_cond = threshold(thresholds[i])
            metric = metrics[i]
            if eval(str(metric)+green_cond):
                zone = 'green zone'
            else:
                zone = 'red zone'
            #print(thresholds[i], ' = ', metric, ',', zone)
            m.append(thresholds[i])
            s.append(metric)
            z.append(zone)
        acc= pd.DataFrame({"Metric":m,"Score":s,'Zone':z})

        for i in range(len(metrics)):
            red_cond, green_cond = threshold(thresholds[i])
            metric = metrics[i]
            if eval(str(metric)+green_cond):
                zone = 'green zone'
            else:
                zone = 'red zone'
            print(thresholds[i], ' = ', metric, ',', zone)

        group_names = ['TN','FP','FN','TP']
        group_counts = ['{0:0.0f}'.format(value) for value in cm.flatten()]
        group_percentages = ['{0:.2%}'.format(value) for value in cm.flatten()/np.sum(cm)]

        labels = [f'{v1}\n{v2}\n{v3}' for v1, v2, v3 in zip(group_names,group_counts,group_percentages)]
        labels = np.asarray(labels).reshape(2,2)

        ax = plt.subplot()
        sns.heatmap(cm, annot=labels, fmt='', cmap='Greens', ax=ax)

        ax.set_xlabel('Predicted_label')
        ax.set_ylabel('Target')
        ax.set_title('Confusion Matrix')
        
        if target_label is not None:
            ax.xaxis.set_ticklabels(['not ' + target_label, target_label])
            ax.yaxis.set_ticklabels(['not ' + target_label, target_label])
        else:
            ax.xaxis.set_ticklabels(['0', '1'])
            ax.yaxis.set_ticklabels(['0', '1'])
        return acc    




    @staticmethod
    def Hosmer_Lemeshow(target,pred,obs_col='num_obs',need_binning=True,n_bins=10,bins_col=None,categories=None,
                                                                                                    target_value=1):
        '''

        Parameters
        ----------
        target: TYPE: pandas Series
            DESCRIPTION: Actual values of target variable

        pred: TYPE: pandas Series
            DESCRIPTION: Model predictions

        obs_col: TYPE: string
            DESCRIPTION: Name of column which contains number of observations in each bin (used when data table is already grouped by categories/ ratings)

        need_binning: TYPE: bool
            DESCRIPTION: Whether to bin the values of a model prediction, not needed if model prediction values are already binned

        n_bins: TYPE: int64
            DESCRIPTION: Desiderable number of bins to split values of model prediction

        bins_col: TYPE: pandas Series
            DESCRIPTION: Should be defined in case need_binning=False.
                        Means a column with ratings/categories by which the data will be grouped for performing the Hosmer Lemeshow test

        categories: TYPE: list
            DESCRIPTION: If bins_col is present, this parameter may be used to establish the order of ratings/categories
            by which grouped data will be sorted. If the 'categories' parameter is absent,
            the groupped data will be sorted in ascending order.

        target_value:
            DESCRIPTION: Parameter should be defined when events and non-events are not labeled as 1 and 0.
            This parameter should be assigned as a value in 'target' which corresponds to an event (for example, default event or customer is churn).

        '''

        if target_value != 1:
            target = np.where(target==target_value,1,0)

        df = pd.concat([target, pred,bins_col], axis=1)
        df['num_obs'] = 1

        if (need_binning) & (pred.nunique() > n_bins):
            min_ = min(pred)
            max_ = max(pred)
            bins = np.append(np.arange(min_, max_, (max_-min_)/n_bins), max_)
            df[pred.name + '_binned'] = pd.cut(pred, bins, include_lowest=True)
            df = df.groupby(pred.name + '_binned', as_index=False).agg({target.name:'sum','num_obs':'count',
                                                                                                    pred.name:'mean'})

        else:
            df = df.groupby(bins_col.name, as_index=False).agg({target.name:'sum','num_obs':'count',pred.name:'mean'})
            if categories is not None:
                cat_rating_order = CategoricalDtype(categories, ordered=True)
                df[bins_col.name] = df[bins_col.name].astype(cat_rating_order)
                df = df.sort_values(bins_col.name).reset_index(drop=True)

        df['exp_events'] = df[obs_col]*df[pred.name]
        tt = sum((df['exp_events']-df[target.name])**2/(df['exp_events']*(1-df[pred.name])))
        chi = chi2.cdf(tt,len(df)-2)
        pvalue=1-chi

        red_cond, green_cond = threshold('Hosmer_Lemeshow')

        if eval(str(pvalue)+red_cond):
            zone = 'red zone'
        elif eval(str(pvalue)+green_cond):
            zone = 'green zone'
        else:
            zone = 'amber zone'

        print('Chi2: ', round(chi,2), 'pvalue: ', round(pvalue,2), '\n', zone)
        return zone,round(pvalue,2),round(chi,2),df   






    
    @staticmethod
    def PSI(feature1, feature2, df1_name, df2_name, need_binning = True, n_bins = 10, categories = None):

        '''

        Parameters
        ----------
        feature1 and feature2: TYPE: pandas Series
            DESCRIPTION: The data on a feature from two samples between which the distribution will be compared

        df1_name and df2_name : TYPE: string
            DESCRIPTION: Names of the samples with two variables for which distributions are compared
            (e.g. 'Development sample' and 'Validation sample'), they are used for labelling the graph

        need_binning: TYPE: bool
            DESCRIPTION: Whether to bin the values of a feature, not needed if feature values are already binned

        n_bins: TYPE: int64
            DESCRIPTION: Desiderable number of bins to split values of a feature

        categories: TYPE: list
            DESCRIPTION: If bins_col is present, this parameter may be used to establish the order of ratings/categories
            by which grouped data will be sorted. If the 'categories' parameter is absent,
            the groupped data will be sorted in ascending order.

        '''

        df_full = pd.concat([feature1,feature2])

        if (need_binning) & (df_full.nunique() > n_bins):
            min_ = min(df_full)
            max_ = max(df_full)
            bins = np.append(np.arange(min_, max_, (max_-min_)/n_bins), max_)
            df1 = pd.cut(feature1, bins, include_lowest=True).value_counts(sort=False, normalize=True)
            df2 = pd.cut(feature2, bins, include_lowest=True).value_counts(sort=False, normalize=True)
            axis_labels = ['({}:{})'.format(i.left, i.right) for i in list(df1.index)]

        else:
            bins = df_full.value_counts().sort_index().index.values
            if categories is not None:
                cat_rating_order = CategoricalDtype(categories, ordered=True)
                df1 = feature1.astype(cat_rating_order).value_counts(sort=False, normalize=True)
                df2 = feature2.astype(cat_rating_order).value_counts(sort=False, normalize=True)
                axis_labels = categories
            else:
                cat_rating_order = CategoricalDtype(bins, ordered=True)
                df1 = feature1.astype(cat_rating_order).value_counts(sort=False, normalize=True)
                df2 = feature2.astype(cat_rating_order).value_counts(sort=False, normalize=True)
                axis_labels = bins
            n_bins = len(bins)


        df1.replace(0, 0.000001, inplace=True)
        df2.replace(0, 0.000001, inplace=True)

        PSI_value = sum(((df1 - df2)*np.log(df1 / df2)).replace([np.inf, -np.inf], 0))

        red_cond, green_cond = threshold('PSI')

        if eval(str(PSI_value)+red_cond):
            zone = 'red zone'
        elif eval(str(PSI_value)+green_cond):
            zone = 'green zone'
        else:
            zone = 'amber zone'

        print('PSI:', round(PSI_value,4), '\n', zone)
        
        plt.figure(figsize=(10,6))
        plt.bar(np.arange(n_bins) - .15, df1.values, width=0.3, label=df1_name, color='red')
        plt.bar(np.arange(n_bins) + .15, df2.values, width=0.3, label=df2_name, color='green')
        plt.xticks(np.arange(n_bins), axis_labels, rotation=45)
        if feature1.name == feature2.name:
            plt.title('PSI for {}'.format(feature1.name))
        else:
            plt.title('PSI for {}'.format(feature1.name) + ' and {}'.format(feature2.name))
        plt.legend()
        return [round(PSI_value,4),zone]






   
    @staticmethod
    def override_ratio(data, override_col):
        """

        Metric Description
        Override Ratio Test is used to capture the size of the overriding, i.e., the number of overrides in relation to the portfolio size. It is usually used in conjunction to the Override matrix (see below).  
        Data/input required
        The data requirements for the calculation of the Override ratio test are:
        •	The override indicator which tells whether the model output was overridden
        •	An indicator of the direction of the override, i.e., a downward flag in case of downgrading/rejection and an upward flag in case of upgrading/acceptance despite the model suggestion.

        Calculates override ratio.
        
        Parameters:
        - data: pd.DataFrame
        - override_col: str
            Binary column indicating override
            (1 = overridden, 0 = not overridden)
        
        Returns:
        - ratio: float
            Override ratio (between 0 and 1)
        - percent: float
            Override ratio in percentage
            

        data = pd.DataFrame({"customer_id" : [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20], 
            'override' : [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0]})

        override_ratio(data, 'override')

        """

        if override_col not in data.columns:
            raise ValueError(f"{override_col} not found in dataframe.")

        ratio = data[override_col].mean()

        if ratio > 0.1:
            color = "red"
        elif 0.01 <= ratio <= 0.2:
            color = "amber"
        else:
            color = "green"


    
        return ratio, color



class RegressionMetrics:


    @staticmethod
    def ratio_avg_estimated_to_observed(data, estimated_col, observed_col) -> float:
        """
        estimated column - predicted values,
        observed column - actual values

        example usage:
        dataa = pd.DataFrame({"col1":[1,2,3,4], "col2":[1,5,6,7]})
        ratio_avg_estimated_to_observed(dataa, 'col1', 'col2')

        """
        
        avg_estimated = np.nanmean(data[estimated_col])
        avg_observed = np.nanmean(data[observed_col])
        if avg_estimated == 0 or avg_observed == 0:
            print("average estimated or observed value is zero!")
            value = "No ratio"
        else:
            value = 1 - (avg_estimated / avg_observed)
            
            # ASSIGN COLOR
            if value > 0.1:
                color = "red"
            elif 0.05 <= value <= 0.1:
                color = "amber"
            else:
                color = "green"
            
        return value, color




    @staticmethod
    def rmse(data, estimated_col, observed_col, model_rmse, validation_type = ['periodic', 'monitoring', 'initial']):
        """
        model_rmse model qurulan zaman hesablanan rmse deyeridir
        eyni proses r(med)se ucun de hesablanir

        example:

        dataa = pd.DataFrame({"col1":[1,2,3,4,10], "col2":[1,5,6,7,2]})
        rmse(dataa ,'col1','col2', 4, 'periodic')
        
        """

        # RMSE calculation
        mse = np.nanmean((data[estimated_col] - data[observed_col]) ** 2)
        rmse_value = np.sqrt(mse)


        err_rate_rmse = mse/np.nanmean(data[observed_col])

        
        epsilon = 1e-10

        for_periodic_val = abs(rmse_value - model_rmse) / max(model_rmse, epsilon)
        

        if validation_type == 'periodic' or 'monitoring':
            
            if for_periodic_val > 0.2:
                color = "red"
            elif 0.1 <= for_periodic_val <= 0.2:
                color = "amber"
            else:
                color = "green"
        else:
        
            if err_rate_rmse > 0.5:
                color = "red"
            elif 0.2 <= err_rate_rmse <= 0.5:
                color = "amber"
            else:
                color = "green"

        
        return for_periodic_val, rmse_value, color
    



    
    @staticmethod
    def rmedse(data, estimated_col, observed_col, model_rmedse, validation_type = ['periodic', 'monitoring', 'initial']):
        """
        model_rmedse model qurulan zaman hesablanan R(Med)SE deyeridir
        dataa = pd.DataFrame({"col1":[1,2,3,4,10], "col2":[1,5,6,7,2]})
        rmse(dataa ,'col1','col2', 4, 'periodic')
        
        """

        # R(Med)SE calculation
        medse = np.nanmedian((data[estimated_col] - data[observed_col]) ** 2)
        rmedse_value = np.sqrt(medse)

        err_rate_rmse = medse/np.nanmean(data[observed_col])
        

        epsilon = 1e-10

        for_periodic_val = abs(rmedse_value - model_rmedse) / max(model_rmedse, epsilon)

        if validation_type == 'periodic' or 'monitoring':
            
            if for_periodic_val > 0.2:
                color = "red"
            elif 0.1 <= for_periodic_val <= 0.2:
                color = "amber"
            else:
                color = "green"
        else:
        
            if err_rate_rmse > 0.5:
                color = "red"
            elif 0.2 <= err_rate_rmse <= 0.5:
                color = "amber"
            else:
                color = "green"

        
        return for_periodic_val, rmedse_value, color
    



    @staticmethod
    def corr_matrix(features, show_graph=True, show_table=False, method='pearson'):
        
        '''

        Example usage
        dataa = pd.DataFrame({"col1":[1,2,3,4], "col2":[1,5,6,7]})
        corr_matrix(dataa)

        
        Parameters
        ----------
        features: TYPE: pandas DataFrame
            DESCRIPTION: Table which contains values of a features for which pairwise correlation shall be calculated
            
        show_graph: TYPE: bool
            DESCRIPTION: Whether to show a correlation matrix
            
        show_table: TYPE: bool
            DESCRIPTION: Whether to show a table with correlation values
            
        method: TYPE: category
            DESCRIPTION: Whether to calculate 'pearson' or 'spearman' correlations
            
        ''' 

        if method == 'pearson':
            corr_df = features.corr()
        elif method == 'spearman':
            corr_df = features.corr(method='spearman')
        
        if show_graph:
            colors_cmap = ['#ff6d6d', '#ff6d6d', '#ffd966', '#79bd5e', '#ffd966', '#ff6d6d', '#ff6d6d']
            my_cmap = LinearSegmentedColormap.from_list('mycmap', colors_cmap)

            mask = np.triu(corr_df,1)

            fig, ax = plt.subplots(1,1,figsize=(12,8))
            sns.heatmap(corr_df, cmap=my_cmap, annot=True, mask=mask, vmin=-1,vmax=1, annot_kws={'fontsize':13})

            ax.set_xticks(range(len(features.columns)))
            ax.set_xticklabels(features.columns,  fontsize = 13, ha = 'center')
            ax.set_yticks(range(len(features.columns)))
            ax.set_yticklabels(features.columns, fontsize = 13, va = 'top')
        if show_table:
    #corr_df = corr_df.where(~(np.triu(np.ones(corr_df.shape)).astype(np.bool)))
            
            red_cond, green_cond = threshold('corr_matrix')
            
            def color(x):
                if math.isnan(x):
                    return 'color:white;background-color:white;'
                elif eval(str(x)+red_cond):
                    return 'color:white;background-color:red;opacity: 80%;'
                elif eval(str(x)+green_cond):
                    return 'color:white;background-color:green;opacity: 70%;'
                return 'color:white;background-color:orange;opacity: 50%;'
            
            corr_df = corr_df.style.applymap(color).format(precision=3, na_rep='')\
            .set_properties(**{'text-align':'center','font-weight':'bold','font-size':'1em'})\
            .set_sticky(axis="index").set_sticky(axis="columns")

            return corr_df    
        



    
    @staticmethod
    def PSI(feature1, feature2, df1_name, df2_name, need_binning = True, n_bins = 10, categories = None):

        '''

        Parameters
        ----------
        feature1 and feature2: TYPE: pandas Series
            DESCRIPTION: The data on a feature from two samples between which the distribution will be compared

        df1_name and df2_name : TYPE: string
            DESCRIPTION: Names of the samples with two variables for which distributions are compared
            (e.g. 'Development sample' and 'Validation sample'), they are used for labelling the graph

        need_binning: TYPE: bool
            DESCRIPTION: Whether to bin the values of a feature, not needed if feature values are already binned

        n_bins: TYPE: int64
            DESCRIPTION: Desiderable number of bins to split values of a feature

        categories: TYPE: list
            DESCRIPTION: If bins_col is present, this parameter may be used to establish the order of ratings/categories
            by which grouped data will be sorted. If the 'categories' parameter is absent,
            the groupped data will be sorted in ascending order.

        '''

        df_full = pd.concat([feature1,feature2])

        if (need_binning) & (df_full.nunique() > n_bins):
            min_ = min(df_full)
            max_ = max(df_full)
            bins = np.append(np.arange(min_, max_, (max_-min_)/n_bins), max_)
            df1 = pd.cut(feature1, bins, include_lowest=True).value_counts(sort=False, normalize=True)
            df2 = pd.cut(feature2, bins, include_lowest=True).value_counts(sort=False, normalize=True)
            axis_labels = ['({}:{})'.format(i.left, i.right) for i in list(df1.index)]

        else:
            bins = df_full.value_counts().sort_index().index.values
            if categories is not None:
                cat_rating_order = CategoricalDtype(categories, ordered=True)
                df1 = feature1.astype(cat_rating_order).value_counts(sort=False, normalize=True)
                df2 = feature2.astype(cat_rating_order).value_counts(sort=False, normalize=True)
                axis_labels = categories
            else:
                cat_rating_order = CategoricalDtype(bins, ordered=True)
                df1 = feature1.astype(cat_rating_order).value_counts(sort=False, normalize=True)
                df2 = feature2.astype(cat_rating_order).value_counts(sort=False, normalize=True)
                axis_labels = bins
            n_bins = len(bins)


        df1.replace(0, 0.000001, inplace=True)
        df2.replace(0, 0.000001, inplace=True)

        PSI_value = sum(((df1 - df2)*np.log(df1 / df2)).replace([np.inf, -np.inf], 0))

        red_cond, green_cond = threshold('PSI')

        if eval(str(PSI_value)+red_cond):
            zone = 'red zone'
        elif eval(str(PSI_value)+green_cond):
            zone = 'green zone'
        else:
            zone = 'amber zone'

        print('PSI:', round(PSI_value,4), '\n', zone)
        
        plt.figure(figsize=(10,6))
        plt.bar(np.arange(n_bins) - .15, df1.values, width=0.3, label=df1_name, color='red')
        plt.bar(np.arange(n_bins) + .15, df2.values, width=0.3, label=df2_name, color='green')
        plt.xticks(np.arange(n_bins), axis_labels, rotation=45)
        if feature1.name == feature2.name:
            plt.title('PSI for {}'.format(feature1.name))
        else:
            plt.title('PSI for {}'.format(feature1.name) + ' and {}'.format(feature2.name))
        plt.legend()
        return [round(PSI_value,4),zone]
    



    @staticmethod
    def r_squared_score(data, estimated_col, observed_col, model_r2, validation_type = ['periodic', 'monitoring', 'initial']):
        """
        dataa = pd.DataFrame({"col1":[1,2,3,4,10], "col2":[1,5,6,7,2]})
        r_squared_score(dataa, 'col1', 'col2', model_r2 = 0.7, validation_type='periodic')



        return values: 1. relative difference between model r and recent r 
                    2. recent r score 
                    3. color of relative difference zone
                    4. color of recent r squared itself
        """

        
        r2_value = r2_score(data[observed_col], data[estimated_col])
        if r2_value < 0:
            r2_value = 0 
        
        epsilon = 1e-10
        relative_diff = abs(r2_value - model_r2) / max(abs(model_r2), epsilon)


        if validation_type in ['periodic', 'monitoring']:
            if relative_diff > 0.1:
                color = "red"
            elif 0.05 <= relative_diff <= 0.1:
                color = "amber"
            else:
                color = "green"

            #########################################################

            if r2_value < 0.4:
                color_r = "red"
            elif 0.4 <= r2_value <= 0.6:
                color_r = "amber"
            elif r2_value >= 0.9:
                color_r  = 'amber'
            else:
                color_r = "green"

        else:
        
            if r2_value < 0.4:
                color = "red"
            elif 0.4 <= r2_value <= 0.6:
                color = "amber"
            elif r2_value >= 0.9:
                color = 'amber'
            else:
                color = "green"
                
            color_r = color

        return relative_diff, r2_value, color, color_r




    @staticmethod
    def override_ratio(data, override_col):
        """

        Metric Description
        Override Ratio Test is used to capture the size of the overriding, i.e., the number of overrides in relation to the portfolio size. It is usually used in conjunction to the Override matrix (see below).  
        Data/input required
        The data requirements for the calculation of the Override ratio test are:
        •	The override indicator which tells whether the model output was overridden
        •	An indicator of the direction of the override, i.e., a downward flag in case of downgrading/rejection and an upward flag in case of upgrading/acceptance despite the model suggestion.

        Calculates override ratio.
        
        Parameters:
        - data: pd.DataFrame
        - override_col: str
            Binary column indicating override
            (1 = overridden, 0 = not overridden)
        
        Returns:
        - ratio: float
            Override ratio (between 0 and 1)
        - percent: float
            Override ratio in percentage
            

        data = pd.DataFrame({"customer_id" : [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20], 
            'override' : [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0]})

        override_ratio(data, 'override')

        """

        if override_col not in data.columns:
            raise ValueError(f"{override_col} not found in dataframe.")

        ratio = data[override_col].mean()

        if ratio > 0.1:
            color = "red"
        elif 0.01 <= ratio <= 0.2:
            color = "amber"
        else:
            color = "green"


    
        return ratio, color


