# setup.py
from setuptools import setup, find_packages

setup(
    name="modelguard-lr",
    version="0.1.2",
    packages=find_packages(),
    install_requires=[
        "numpy",
        "pandas",
        "scikit-learn",
        "scipy",
        "matplotlib",
        "seaborn"
    ],
    python_requires=">=3.10",
)
