from typing import Any

from pydantic import BaseModel, Field


class EstimateBreakdown(BaseModel):
    unit: str
    branch: str
    qty: int
    rate: float
    subtotal: float


class EstimateBreakdownGroup(BaseModel):
    input: EstimateBreakdown
    output: EstimateBreakdown


class EstimateResponse(BaseModel):
    total: float
    breakdown: EstimateBreakdownGroup
    model: str
    traceId: dict[str, Any] | None = Field(default=None)
