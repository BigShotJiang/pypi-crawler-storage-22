from modelq.app.middleware.base import Middleware

__all__ = ["Middleware"]
