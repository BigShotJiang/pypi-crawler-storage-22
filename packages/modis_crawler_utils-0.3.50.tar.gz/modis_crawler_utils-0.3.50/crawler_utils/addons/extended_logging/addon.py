import logging
from scrapy.settings import Settings
from crawler_utils.addons.extended_logging.utils import update_logger_context



logger = logging.getLogger(__name__)


class ExtendedLoggingAddon:
    def update_settings(self, settings: Settings):
        if not (logger_names := settings.getlist("EXTENDED_LOGGER_NAMES")):
            logger.warning("Not found loggers for extended logging addon. Add list setting EXTENDED_LOGGER_NAMES, to specify what loggers should be extended. ")
            return
        for logger_name in logger_names:
            update_logger_context(logging.getLogger(logger_name))
        logger.info(f"Extended the following loggers: {logger_names}")
        self._update_middlewares(settings)
        logger.info("Updated downloaded middlewares")

    def _update_middlewares(self, settings: Settings):
        self.add_request_response_middlewares(settings)
        self.change_proxy_middleware(settings)

    @staticmethod
    def add_request_response_middlewares(settings: Settings):
        middlewares = settings.getdict("DOWNLOADER_MIDDLEWARES")
        max_priority = max(middlewares.values())
        min_priority = min(middlewares.values())
        middlewares.update({
            "crawler_utils.addons.extended_logging.middleware.ExtendedLoggingMiddlewareRequest": min_priority - 1,
            "crawler_utils.addons.extended_logging.middleware.ExtendedLoggingMiddlewareResponse": max_priority + 1
        })
        settings.set("DOWNLOADER_MIDDLEWARES", middlewares)

    @staticmethod
    def change_proxy_middleware(settings: Settings):
        middlewares = settings.getdict("DOWNLOADER_MIDDLEWARES")
        if pr := middlewares.pop("crawler_utils.talisman_proxy.TalismanProxyChainDownloaderMiddleware", None):
            middlewares["crawler_utils.addons.extended_logging.middleware.proxychain.TalismanProxyChainDownloaderMiddleware"] = pr
            settings.set("DOWNLOADER_MIDDLEWARES", middlewares)
        else:
            logger.warning("TalismanProxyChainDownloaderMiddleware does not enabled. Proxy id will not be logged.")
