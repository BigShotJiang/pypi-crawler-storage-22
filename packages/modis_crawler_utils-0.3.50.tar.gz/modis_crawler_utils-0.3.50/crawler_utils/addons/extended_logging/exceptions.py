from typing import Iterable

class ContextNotFoundError(KeyError):
    def __init__(self, name: str, ctx_names: Iterable[str]) -> None:
        super().__init__(name)
        self.name: str = name
        self.ctx_names: tuple[str, ...] = tuple(ctx_names)