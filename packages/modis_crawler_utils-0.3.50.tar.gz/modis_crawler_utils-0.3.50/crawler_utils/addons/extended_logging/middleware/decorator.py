import logging
from functools import wraps
from typing import Callable, Concatenate, ParamSpec, TypeVar
from scrapy.http.request import Request
from ..utils import _set_context, set_request_ctx
from ..exceptions import ContextNotFoundError


logger = logging.getLogger(__name__)


class ExtendedLoggingMiddlewareResponse:
    def process_response(self, request, response, spider):
        set_request_ctx(request)
        return response


class ExtendedLoggingMiddlewareRequest:
    def process_request(self, request, spider):
        set_request_ctx(request)
        return None


A = TypeVar("A")
T = TypeVar("T")
P = ParamSpec("P")

def context_middleware(cls_attr2context: dict[str, str]) -> Callable[[type[A]], type[A]]:
    """
    Class decoratror for scrapy middlewares which wraps process_request and process_response methods.
    Methods process_request and proecess_response wraps to feed contextvars specified by its names in cls_attr2context mapping by middleware attributes.
    Keys in cls_attr2context should correspond names of decorated class attributes, and values is ContextVar.name's.

    Usage:
    @context_middleware({"active_credential": "credential_ctx"})
    class YourMidleware:
        ...

    make your YourMiddleware is equvalent to the following:

    class WrappedMiddleware(YourMiddleware):
        def process_request(...):
            credential_ctx.set(self.active_credentials)
            return super().process_request(...)

        and the same for process_response(...)

    :param cls_attr2context: mappping between wrapped class attribute and context var name
    :type cls_attr2context: dict[str, str]
    :return: wrapped class
    :rtype: Callable[[type[A]], Callable[..., A]]
    """

    def middleware_method_decorator(method: Callable[Concatenate[A, Request, P], T]) -> Callable[Concatenate[A, Request, P], T]:
        @wraps(method)
        def wrapper(self: A, request: Request, *args: P.args, **kwargs: P.kwargs) -> T:
                _extract_attribute2ctx(self, request, cls_attr2context)
                res = method(self, request, *args, **kwargs)
                _extract_attribute2ctx(self, request, cls_attr2context)
                return res


        return wrapper

    def decorator(cls: type[A]) -> type[A]:
        process_request = getattr(cls, "process_request")
        process_response = getattr(cls, "process_response")
        if not process_request or not process_response:
            raise NotImplementedError(
                f"""
                Methods process_request and process_response should be implemented in {cls.__name__} or its ansestors. 
                See https://docs.scrapy.org/en/latest/topics/downloader-middleware.html for additional information."""
            )

        wrapped_process_request = middleware_method_decorator(process_request)
        wrapped_process_response = middleware_method_decorator(process_response)
        setattr(cls, "process_response", wrapped_process_response)
        setattr(cls, "process_request", wrapped_process_request)

        return cls

    return decorator


def _extract_attribute2ctx(instance: object, request: Request, cls_attr2context: dict[str, str]):
    try:
        for attr_name, ctx_name in cls_attr2context.items():
            attr_value = getattr(instance, attr_name)
            _set_context(ctx_name, attr_value)
            if ctx_name != "request_ctx":
                if "request_ctx" not in cls_attr2context.values():
                    request.meta[f"_{ctx_name}"] = attr_value
                else:
                    request_attr_name = list([_attr_name for _attr_name, _ctx_name in cls_attr2context.items() if _ctx_name == "request_ctx"])[0]
                    request_attr = getattr(instance, request_attr_name)
                    request_attr.meta[f"_{ctx_name}"] = attr_value
        if "request_ctx" not in cls_attr2context.values():
            _set_context("request_ctx", request)
    except AttributeError as err:
        msg = f"Name {err.name} specified in cls_attr2context should be valid attribute in {instance}"
        logger.exception(msg)
        raise AttributeError(msg) from err
    except ContextNotFoundError as err:
        msg = f"ContextVar {err.name} not found in context {err.ctx_names}. cls_attr2context variable should map to valid context."
        logger.exception(msg)
        raise KeyError(msg) from err
