from .decorator import context_middleware
from crawler_utils.talisman_proxy import TalismanProxyChainDownloaderMiddleware as BaseMiddleware
from crawler_utils.talisman_proxy import request_talisman_proxy_id, PartialProxyConfig


@context_middleware({"_proxy_id": "proxy_id_ctx"})
class TalismanProxyChainDownloaderMiddleware(BaseMiddleware):
    """
    This wrapper class try to extract proxy_id to the proxy_id_ctx.

    Disclaimer:
    I'm not sure that the value I was copy to the __proxy_id is the same proxy_id which will use for proxy. Need more in-deep research to make sure of this.
    """
    __proxy_id: str | None = None
    @property
    def _proxy_id(self) -> str:
        if not self.__proxy_id:
            self.proxy_config.id = request_talisman_proxy_id(self.proxy_config)
            self.__proxy_id = self.proxy_config.id
        return str(self.__proxy_id)

    def rotate_session(self, session_key: str):
        super().rotate_session(session_key)
        self.__proxy_id = self.proxy_config.id if self.proxy_config.id else self.__proxy_id

    def create_session(self, session_key: str | None = None, config: PartialProxyConfig | None = None) -> str:
        session_key = super().create_session(session_key, config)
        if not (session_config := self.get_session_config(session_key)):
            return session_key
        self.__proxy_id = session_config.id if session_config.id else self.__proxy_id
        return session_key


