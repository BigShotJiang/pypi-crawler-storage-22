from copy import copy
import logging
from contextvars import ContextVar
from typing import Any, Callable
from scrapy.http import Request
from scrapy.utils.log import get_scrapy_root_handler
from crawler_utils.credentials import Credential
from .exceptions import ContextNotFoundError


proxy_id_ctx: ContextVar[str] = ContextVar("proxy_id_ctx", default="none")
credential_ctx: ContextVar[Credential | str] = ContextVar("credential_ctx", default="none")
request_ctx: ContextVar[Request | str] = ContextVar("request_ctx", default="none")

# Maybe it isn't the best way to transfer contextvars across the module, it's better to use contextvars.Context
# But i need research how can i do this. For now i decide to use this crutch
context: dict[str, ContextVar] = {
    ctx_var.name: ctx_var for ctx_var in (proxy_id_ctx, credential_ctx, request_ctx)
}


DEFAULT_LOG_FORMAT = "%(asctime)s [%(name)s] %(levelname)s: %(message)s"
FULL_LOG_FORMAT = "%(asctime)s [%(name)s] (Proxy id: %(proxy_id)s, Account: %(credential)s) %(levelname)s: %(message)s \n Request: %(request)s"


def _set_context(ctx_name: str, val: Any) -> None:
    try:
        ctx_var = context[ctx_name]
    except KeyError as err:
        raise ContextNotFoundError(str(err), context.keys()) from err
    if ctx_var.get() == val:
        return
    ctx_var.set(val if val else "none")


def set_proxy_id_ctx(val: str | None = None) -> None:
    """
    Setter for proxy_id context var.

    :param val: Optional value. If None, proxy_id <= "none"
    :type val: str | None
    """
    _set_context("proxy_id_ctx", val)


def set_credential_ctx(val: Credential | str | None = None) -> None:
    """
    Setter for credential context var.

    :param val: Optional value. If None, credential <= "none"
    :type val: str | None
    """
    _set_context("credential_ctx", val)


def set_request_ctx(val: Request | str | None = None) -> None:
    """
    Setter for request context var.

    :param val: Optional value. If None, request <= "none"
    :type val: str | None
    """
    _set_context("request_ctx", val)


def update_logger_context(logger: logging.Logger):
    """
    Add to the logger two handlers: one for error message and one for normal message.
    The error one, has filter ContextFilter which incorporate context information into the LogRecord instance.
    After applying update_logger_context logger.propagate is set to False

    :param logger: logger to update
    :type logger: logging.Logger
    """
    normal_handler = get_scrapy_root_handler()
    assert normal_handler
    normal_handler = (
        copy(normal_handler) if logger is not logging.root else normal_handler
    )
    error_handler = copy(normal_handler)
    error_handler.filters = []  # because we need to decouple filters of normal, error and root handlers
    normal_handler.filters = []

    normal_handler.addFilter(lambda record: record.levelno < logging.WARNING)
    error_handler.addFilter(ContextFilter())
    error_handler.setLevel(logging.WARNING)
    error_handler.setFormatter(logging.Formatter(FULL_LOG_FORMAT))

    logger.addHandler(error_handler)
    if logger is not logging.root:
        # root handler have been added to logger already by scrapy log configuration if logger is root logger
        # see scrapy.utils.log configure_logging()
        logger.addHandler(normal_handler)
        logger.propagate = False


def pretty_serialize_request(req: Request) -> str:
    return (
        f"{req.method} {req.url}\n Headers:\n\t"
        + "\t".join(f"{k.decode()}: {v[0].decode()}\n" for k, v in req.headers.items())
        + (f" Body: {req.body}" if req.body else "Body: <empty>")
    )


class ContextFilter(logging.Filter):
    context_processor: dict[type, Callable] = {
        str: str,
        Credential: str,
        Request: pretty_serialize_request,
    }

    def filter(self, record: logging.LogRecord) -> bool | logging.LogRecord:
        global context
        request = context["request_ctx"].get()
        request: Request | None = request if isinstance(request, Request) else None
        for context_name, context_val in context.items():
            val = request.meta.get(f"_{context_name}", context_val.get()) if request else context_val.get()
            val_type = [
                key_type
                for key_type in self.context_processor
                if isinstance(val, key_type)
            ]
            assert val_type
            proc = self.context_processor.get(val_type[0])
            assert proc
            setattr(record, context_name.removesuffix("_ctx"), proc(val))
        return record
