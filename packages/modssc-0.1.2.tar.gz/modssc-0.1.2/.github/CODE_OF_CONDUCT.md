# Code of Conduct

We follow the Contributor Covenant Code of Conduct (version 2.1).

By participating in this project, you agree to uphold this code.

Enforcement
For reporting unacceptable behavior, contact the project maintainers (see CODEOWNERS).
