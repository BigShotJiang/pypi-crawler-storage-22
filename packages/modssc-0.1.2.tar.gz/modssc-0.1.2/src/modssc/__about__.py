# SPDX-FileCopyrightText: 2024-present ModSSC contributors
#
# SPDX-License-Identifier: MIT
__version__ = "0.1.2"
