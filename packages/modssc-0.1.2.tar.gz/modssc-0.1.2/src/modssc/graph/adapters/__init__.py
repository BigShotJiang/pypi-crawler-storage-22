"""Optional adapters to external graph libraries."""
