"""Graph construction subpackage."""

from __future__ import annotations

from .api import build_graph

__all__ = ["build_graph"]
