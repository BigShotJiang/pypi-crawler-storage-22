"""Backend implementations for supervised baselines."""

from __future__ import annotations
