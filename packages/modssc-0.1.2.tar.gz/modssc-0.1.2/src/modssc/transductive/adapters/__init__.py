"""Optional adapters for transductive methods."""
