"""Graph operators used by transductive methods."""
