"""Solvers used by transductive methods."""
