from __future__ import annotations


class DummyMethod:
    info = "not-method-info"
