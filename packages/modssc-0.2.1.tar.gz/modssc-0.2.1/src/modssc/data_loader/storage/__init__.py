from modssc.data_loader.storage.files import FileStorage

__all__ = ["FileStorage"]
