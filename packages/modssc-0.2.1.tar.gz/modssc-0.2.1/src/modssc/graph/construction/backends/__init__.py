"""Construction backends.

Backends are selected via GraphBuilderSpec.backend.
"""
