"""Graph featurization subpackage."""

from __future__ import annotations

from .api import graph_to_views

__all__ = ["graph_to_views"]
