"""Backend utilities for inductive methods."""

from . import torch_backend

__all__ = ["torch_backend"]
