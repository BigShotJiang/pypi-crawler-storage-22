"""Backend implementations for pretrained encoders.

This package is intentionally imported lazily by the model registry.
"""
