"""Preprocessing steps (lazy-loaded via the step registry)."""
