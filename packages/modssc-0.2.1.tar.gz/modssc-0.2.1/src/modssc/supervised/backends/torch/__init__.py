"""Torch backends for supervised classifiers."""
