from django.contrib import admin
from django.urls import path, include

from . import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.test_page, name='test_page'),
    path('retour/', include('retour_client.urls')),
]
