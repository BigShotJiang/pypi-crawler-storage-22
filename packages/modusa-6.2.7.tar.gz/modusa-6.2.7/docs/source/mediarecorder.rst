Media Recorder
==============

.. automethod:: modusa.record.mic