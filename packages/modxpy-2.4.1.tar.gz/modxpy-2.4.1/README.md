### **🌟 ModXPy — The Python Module Universe at Your Fingertips**



Welcome to ModXPy, the ultimate playground for Python’s modules.  
With ModXPy you can instantly import, explore, and experiment with the entire Python standard library — plus any installed third-party modules — all from one simple interface.



#### UPDATE 2.4.1



###### MAINTENANCE \& QOL UPDATE!



Expanded vcompat()'s version checking range from 2.0 - 3.12 to 2.0 - 3.14

Better error message to help users understand WHY a module isn't found.



#### 🚀 Installation and Importing



IMPORTANT: Before you install ModX, you MUST first (if not already) run "pip install packaging" inside of powershell/terminal. ModX will NOT work without the packaging module.

Install directly from terminal.

Type: "pip install modxpy"



In Python, import as import modx (not modxpy)



#### Functions:



🔹 dependencies(module)

Shows what other modules a specific module depends on without importing it.



🔹 importall(show\_imported=False)

Imports about every standard library module at once.



🔹 importexternal(show\_imported=False)

Attempts to import every third-party module you currently have installed.



🔹 importletter(letter, show\_imported=False)

Imports all standard library modules whose names start with the given letter (case-insensitive).



🔹 importlog(include\_deps=False)

Shows every module imported since ModX loaded in CHRONOLOGICAL order.



include\_deps=True: Includes ModX's dependencies in the list.



🔹 importrandom(n, strict\_mode=False, show\_imported=False)

Imports n random stdlib modules.



strict\_mode=False: May import less than n due to dependencies.

strict\_mode=True: Forces import until EXACTLY n NEW modules.



🔹 importscreen(show\_imported=False)

Imports every module that uses a screen/GUI (like pygame or turtle).



🔹 info(module\_name)

Shows basic info about a module: file path, built-in status, docstring snippet.



🔹 isimported(module)

Checks if a module is currently imported into the Python shell (not just sys.modules).



🔹 listimportall()

Returns a list of modules that import\_all() would import.



🔹 modbench(module)

Shows how much time and memory a module takes to import.

Note: The typed module DOES get imported.



🔹 modclasses(module)

Shows how many and what classes a module has WITHOUT importing it.



🔹 modfunctions(module)

Shows how many and what functions a module has WITHOUT importing it.



🔹 modglobals(module, show\_private=False, export=None)

Shows a module's global names (not functions/classes/modules).



show\_private=True: Includes names starting with '\_'.

export=filename.md: Exports results as Markdown.



🔹 modorigin(module)

Shows where a module came from (e.g., built-in, standard library, or pip-installed).



🔹 modsloaded()

Shows how many modules are currently loaded in your Python session.



🔹 modxhelp(export=None, compact=False, banner=True)

Shows ModX's built-in help dialogue.



export=filename.md: Exports help as Markdown.

compact=True: Shows single-line summaries only.

banner=False: Hides the ASCII banner.



🔹 modximported()

Lists modules that were ONLY imported by ModX — NOT including user imports or dependencies.



🔹 nonimported()

Returns a list of STANDARD LIBRARY modules that have NOT been imported yet.



🔹 preloaded(show\_builtins=True, show\_internal=False, show\_submodules=False)

Shows modules pre-loaded by Python before ModX started.



show\_builtins=False: Hides built-in modules.

show\_internal=True: Shows modules starting with '\_'.

show\_submodules=True: Includes submodules (names with '.').



🔹 revdeps(module)

Shows what modules import the given module WITHOUT importing it.



🔹 searchmodules(keyword)

Searches for modules whose names contain the keyword.



🔹 vcompat(module\_name, python\_version=None)

Checks if a module is compatible with a given Python version.

If no version is given, sweeps ALL Python versions 2.0–3.14.



🔹 whyloaded(module)

Returns a comma-separated string explaining why a module is in memory.

Tags: not\_loaded, preloaded, user, referenced, modx, modx\_dep, dependency or unknown

Rule: user swallows referenced.



Note: For functions who have a show\_imported parameter, if it is True, 

then it will show what this function imported, otherwise it won't.



#### 💡 Why Use ModX?



1.) Explore the Python standard library in seconds
2.) Stress-test your environment by bulk importing modules
3.) See hidden dependencies that load behind the scenes
4.) Experiment with random imports for fun or testing
5.) Discover new modules you didn’t know existed



ModXPy turns Python’s module system into a playground —
perfect for learning, testing, or just satisfying your curiosity.
Install it today with pip install modxpy, import it with import modx,
and start discovering how many modules Python already has waiting for you!

