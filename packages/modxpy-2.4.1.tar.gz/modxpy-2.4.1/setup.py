from setuptools import setup

setup(
    name="modxpy",
    version="2.4.1",
    description='ModX — The Python Module Universe at Your Fingertips',
    long_description=open('README.md', encoding='utf-8').read(),
    long_description_content_type='text/markdown',
    author='Austin Wang',
    author_email='austinw87654@gmail.com',
    packages=["modx"],
    include_package_data=True,
    python_requires=">=3.7",
)
