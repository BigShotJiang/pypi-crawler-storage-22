#modx.py: A module whose functions have to do with other modules.
#For example: importall(), a function used to import every single module
#in Python that is supported on most devices without printing an
#error message, does not print out dialog nor pop up a link when
#imported, and not required to be downloaded
#separately with Python (such as Pygame, downloaded in Terminal).
#
#Modules ios_support, pty, this, sre_compile, sre_parse,
#sre_constants, tty, idle and antigravity are left out of import_all().
#Reasons: ios_support not supporting computers,
#pty and tty importing a nonexistent module (termios),
#sre_compile, sre_constants and sre_parse printing warnings,
#"this" printing out "The Zen of Python" poem, idle
#opening up Python Shell window, and
#antigravity popping out a web browser link
#(There are more modules left out but the full list is way too long).
#
#Permission to use this module is granted to anyone wanting to use it,
#under the following conditions: 1.) Any copies of this module must be clearly
#marked as so. 2.) The original of this module must not be misrepresented;
#you cannot claim this module is yours.

'''Notes: vcompat() checks for most issues for Python versions 2.0 - 3.14 and not all.
If every issue were to be included, the rules alone would be about 1500 lines
and the rest of the function would be 200 lines-ish. Most of the major issues
are included in vcompat(). Only less common, very rare problems are left out.

modglobals(): returns basically anything, that modcallses, functions,
or dependencies doesn't cover (e.g. ints, strs, methods, etc.).

Created by: Austin Wang. Created on: September 19, 2025. Last updated:
Feburary 13, 2026'''

_version_= "2.5.0"

import sys, importlib, pkgutil, random, builtins, ast, importlib.util, os, tokenize, io
import time, tracemalloc, inspect, textwrap, math, threading
from pathlib import Path
from packaging import version
import datetime

_modx_start_time = time.time()
_modx_start_datetime = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
_import_timestamps = {}

_initial_modules = set()
for m in sys.modules.keys():
    if m == '__main__':
        continue
    if m.startswith('modx'):  
        continue
    _initial_modules.add(m)

_import_order = []

_why_dependency = set()
_why_modx_dep = set()
_why_unknown = set()

_import_tracking = {
    "preloaded": set(_initial_modules),
    "user_direct": set(),
    "user_reference": set(),
    "modx_direct": set(),
    "modx_dep": set(),
    "dependency": set(),
    "unknown": set()
}

_modx_importing = False

_modx_dependencies = {
    'sys', 'importlib', 'pkgutil', 'random', 'builtins', 'ast', 'importlib.util',
    'os', 'tokenize', 'io', 'time', 'tracemalloc', 'inspect', 'textwrap',
    'math', 'threading', 'pathlib', 'packaging', 'version', 'datetime'
}

_original_import = builtins.__import__

_original_import = builtins.__import__
_import_lock = threading.Lock()
_import_context_stack = []

_modx_importing = False

def _tracking_import(name, globals=None, locals=None, fromlist=(), level=0):
    '''Internal function. Not for public use.'''
    top_name = name.partition('.')[0]
    already = top_name in sys.modules
    mod = _original_import(name, globals, locals, fromlist, level)

    if top_name.isidentifier() and not top_name.startswith('_'):
        try:
            is_user = False
            is_modx = False
            frame = inspect.currentframe()
            while frame:
                filename = frame.f_code.co_filename
                if filename and not _modx_importing and ('__main__' in filename or '<stdin>' in filename or '<string>' in filename or filename.startswith('<')):
                    is_user = True
                    break
                if filename and filename == __file__:
                    is_modx = True
                frame = frame.f_back

            if already:
                if is_user:
                    _import_tracking["user_reference"].add(top_name)
            else:
                if is_user:
                    _import_tracking["user_direct"].add(top_name)
                elif is_modx or _modx_importing:
                    if top_name in _modx_dependencies:
                        _import_tracking["modx_dep"].add(top_name)
                    else:
                        _import_tracking["modx_direct"].add(top_name)
                else:
                    _import_tracking["dependency"].add(top_name)
            
            if not already:
                _import_timestamps[top_name] = time.time()
                
        except:
            if top_name not in _import_tracking["preloaded"]:
                _import_tracking["unknown"].add(top_name)

    return mod

builtins.__import__ = _tracking_import
importlib.import_module = _tracking_import

modx_imports_list = ['sys', 'importlib', 'pkgutil', 'random', 'builtins', 'ast', 'importlib.util',
                     'os', 'tokenize', 'io', 'time', 'tracemalloc', 'inspect', 'textwrap',
                     'math', 'threading', 'pathlib', 'packaging', 'version', 'datetime']

for mod in modx_imports_list:
    top = mod.split('.')[0]
    if top in sys.modules:
        _why_modx_dep.add(top)

for mod in _initial_modules:
    top = mod.split('.', 1)[0]
    _import_tracking["modx_dep"].discard(top)
    _import_tracking["user_direct"].discard(top)
    _import_tracking["user_reference"].discard(top)

for mod in _modx_dependencies:
    top = mod.split('.')[0]
    if top in sys.modules:
        _import_tracking["modx_dep"].add(top)
        _import_tracking["dependency"].add(top)
        
_imported_by_modx = set()

modules = [
        'collections', 'sys', 'asyncio', 'concurrent', 'ctypes', 'dbm', 'email',
        'encodings', 'ensurepip', 'html', 'http', 'idlelib', 'importlib', 'json', 'logging',
        'multiprocessing', 'pathlib', 'pydoc_data', 're', 'sqlite3',
        'sysconfig', 'test', 'tkinter', 'tomllib', 'turtledemo', 'unittest', 'urllib',
        'venv', 'wsgiref', 'xml', 'xmlrpc', 'zipfile', 'zoneinfo',
        '_pyrepl', '_collections_abc', '_colorize',
        '_compat_pickle', '_compression', '_markupbase', '_opcode_metadata',
        '_py_abc', '_pydatetime', '_pydecimal', '_pyio', '_pylong', '_sitebuiltins', '_strptime',
        '_threading_local', '_weakrefset', 'abc', 'argparse', 'ast', 'base64', 'bdb',
        'bisect', 'bz2', 'calendar', 'cmd', 'codecs', 'codeop', 'colorsys', 'compileall', 'configparser',
        'contextlib', 'contextvars', 'copy', 'copyreg', 'cProfile', 'csv', 'dataclasses', 'datetime',
        'decimal', 'difflib', 'dis', 'doctest', 'enum', 'filecmp', 'fileinput', 'fnmatch', 'fractions',
        'ftplib', 'functools', 'genericpath', 'getopt', 'getpass', 'gettext', 'glob', 'graphlib',
        'gzip', 'hashlib', 'heapq', 'hmac', 'imaplib', 'inspect', 'io', 'ipaddress', 'keyword', 'linecache',
        'locale', 'lzma', 'math', 'mailbox', 'mimetypes', 'modulefinder', 'netrc',
        'opcode', 'optparse', 'os', 'pdb', 'pickle', 'pickletools', 'pkgutil',
        'platform', 'plistlib', 'poplib', 'pprint', 'profile', 'pstats', 'py_compile',
        'pyclbr', 'pydoc', 'queue', 'quopri', 'random', 'reprlib', 'runpy', 'sched', 'secrets',
        'selectors', 'shelve', 'shlex', 'shutil', 'signal', 'site', 'smtplib', 'socket', 'socketserver',
        'ssl', 'stat', 'statistics', 'string', 'stringprep',
        'struct', 'subprocess', 'symtable', 'tabnanny', 'tarfile', 'tempfile', 'textwrap',
        'threading', 'timeit', 'token', 'tokenize', 'trace', 'traceback', 'tracemalloc', 'turtle',
        'types', 'typing', 'uuid', 'warnings', 'wave', 'weakref', 'webbrowser', 'zipapp', 'zipimport',
        "atexit", "mmap",
        'autocomplete','autocomplete_w','autoexpand','browser','build',
        'calltip','calltip_w','codecontext','colorizer',
        'config','config_key','configdialog','debugger','debugger_r',
        'debugobj','debugobj_r','delegator','direct','dynoption','editor',
        'filelist','format','grep','help','help_about','history','hyperparser',
        'id','idle_test','iomenu','keyring','mainmenu','more_itertools',
        'multicall','outwin','parenmatch','pathbrowser','percolator','pyparse',
        'pyshell','query','redirector','replace','rpc','run',
        'runscript','screeninfo','scrolledlist','search','searchbase','searchengine',
        'sidebar','squeezer','stackviewer','statusbar','textview','tooltip',
        'tree','undo','util','window','zoomheight','zzdummy', 'builtins', 'itertools',
        'operator', 'collections.abc', 'errno', 'msvcrt', 'array', 'marshal',
        'rlcompleter', 'urllib.request', 'urllib.response', 'urllib.parse', 'urllib.error', 
        'urllib.robotparser', 'http.client', 'http.server',
        'xml.etree.ElementTree', 'xml.parsers.expat',
        '_thread', '_weakref', '_collections', '_ast', '_bisect',
        '_heapq', '_io', '_functools', '_operator', '_signal', '_socket', '_ssl',
        '_stat', '_struct', '_datetime', '_random', '_hashlib', '_md5', '_sha1',
        '_blake2', '_pickle', '_json', '_zoneinfo', '_opcode', 'cmath', 'numbers',
        '_codecs_cn', '_codecs_hk', '_codecs_iso2022', '_codecs_jp', '_codecs_kr',
        '_codecs_tw', '_interpchannels', '_interpqueues', '_interpreters',
        '_multibytecodec', '_sha2', '_sha3', '_suggestions', 'faulthandler',
        'xxsubtype','time']

def importall(show_imported=False, as_data=False):
    global _modx_importing
    _modx_importing = True
    try:
        caller_globals = globals()
        success = []
        failed = []
        for m in modules:
            try:
                module_obj = importlib.import_module(m)
                caller_globals[m] = module_obj
                _imported_by_modx.add(m)
                success.append(m)
            except Exception as e:
                failed.append((m, str(e)))
        
        if show_imported and not as_data:
            print(f"Successfully imported {len(success)} modules")
            if success:
                print("Imported modules:")
                for mod in sorted(success):
                    print(f"  - {mod}")
        
            if failed:
                print(f"{len(failed)} modules failed to import:")
                for mod, error in failed:
                    print(f"   {mod}: {error}")
        
        if as_data and show_imported:
            return success, failed
        
    finally:
        _modx_importing = False

def importrandom(n, strict_mode=False, show_imported=False, as_data=False):
    global _modx_importing
    _modx_importing = True
    try:
        caller_globals = globals()
        success = []
        failed = []

        if not strict_mode:
            chosen = random.sample(modules, min(n, len(modules)))

            for m in chosen:
                before = set(sys.modules.keys())
                try:
                    module_obj = importlib.import_module(m)
                    caller_globals[m] = module_obj
                    _imported_by_modx.add(m)
                    after = set(sys.modules.keys())

                    if m not in before:      
                        success.append(m)

                except Exception as e:
                    failed.append((m, str(e)))

            if show_imported and not as_data:
                print(f"[NORMAL MODE] Imported {len(success)} NEW modules:")
                for mod in sorted(success):
                    print(f"  - {mod}")

            if failed and show_imported and not as_data:
                print(f"{len(failed)} failed:")
                for mod, err in failed:
                    print(f"   {mod}: {err}")

            if as_data and show_imported:
                return success, failed
            return

        new_count = 0
        seen = set()

        while new_count < n:
            if len(seen) == len(modules):
                if show_imported and not as_data:
                    print("[STRICT MODE] Warning: no new modules left!")
                break

            m = random.choice(modules)
            seen.add(m)
            before = set(sys.modules.keys())

            try:
                module_obj = importlib.import_module(m)
                caller_globals[m] = module_obj
                _imported_by_modx.add(m)

                if m not in before:
                    new_count += 1
                    success.append(m)

            except Exception as e:
                failed.append((m, str(e)))

        if show_imported and not as_data:
            print(f"[STRICT MODE] Imported EXACTLY {len(success)} NEW modules:")
            for mod in sorted(success):
                print(f"  - {mod}")

        if failed and show_imported and not as_data:
            print(f"{len(failed)} failed:")
            for mod, err in failed:
                print(f"   {mod}: {err}")

        if as_data and show_imported:
            return success, failed

    finally:
        _modx_importing = False

def importexternal(show_imported=False, as_data=False):
    global _modx_importing
    _modx_importing = True
    try:
        caller_globals = globals()
        stdlib_set = set(modules) | set(sys.builtin_module_names)
        success = []
        failed = []
        
        third_party_modules = set()
        
        for finder, name, ispkg in pkgutil.iter_modules():
            if name not in stdlib_set and name not in ['__main__']:
                third_party_modules.add(name)
        
        for path in sys.path:
            if any(keyword in path for keyword in ['site-packages', 'dist-packages', 'Python\\Lib', 'Python/Lib']):
                if os.path.exists(path):
                    try:
                        for item in os.listdir(path):
                            item_path = os.path.join(path, item)
                            if item.endswith('.py') and not item.startswith('__'):
                                mod_name = item.replace('.py', '')
                                if (mod_name not in stdlib_set and 
                                    mod_name not in third_party_modules and
                                    mod_name.isidentifier()):
                                    third_party_modules.add(mod_name)
                            elif os.path.isdir(item_path) and not item.startswith('__'):
                                if (item not in stdlib_set and 
                                    item not in third_party_modules and
                                    item.isidentifier()):
                                    init_file = os.path.join(item_path, '__init__.py')
                                    if os.path.exists(init_file):
                                        third_party_modules.add(item)
                    except (PermissionError, OSError):
                        continue
        
        try:
            import subprocess
            result = subprocess.run([sys.executable, '-m', 'pip', 'list', '--format=freeze'], 
                                  capture_output=True, text=True, timeout=30)
            if result.returncode == 0:
                for line in result.stdout.splitlines():
                    if '==' in line:
                        mod_name = line.split('==')[0].strip()
                        if (mod_name not in stdlib_set and 
                            mod_name not in third_party_modules and
                            mod_name.isidentifier()):
                            third_party_modules.add(mod_name)
        except:
            pass  
        
        for name in sorted(third_party_modules):
            try:
                module_obj = importlib.import_module(name)
                caller_globals[name] = module_obj
                _imported_by_modx.add(name.partition('.')[0])
                success.append(name)
            except Exception as e:
                failed.append((name, str(e)))
        
        if show_imported and not as_data:
            print(f"Successfully imported {len(success)} third-party modules")
            if success:
                print("Imported modules:")
                for mod in sorted(success):
                    print(f"  - {mod}")
        
        if failed and show_imported and not as_data:
            print(f"{len(failed)} modules failed to import:")
            for mod, error in failed:
                print(f"   {mod}: {error}")
        
        if as_data and show_imported:
            return success, failed
        
    finally:
        _modx_importing = False

def importscreen(show_imported=False, as_data=False):
    global _modx_importing
    _modx_importing = True
    try:
        caller_globals = globals()
        screen_modules = ['pygame', 'pyglet', 'arcade', 'tkinter', 'turtle']
        success = []
        failed = []
        for m in screen_modules:
            try:
                module_obj = importlib.import_module(m)
                caller_globals[m] = module_obj
                _imported_by_modx.add(m)
                success.append(m)
            except Exception as e:
                failed.append((m, str(e)))
        
        if show_imported and not as_data:
            print(f"Successfully imported {len(success)} screen/GUI modules")
            if success:
                print("Imported modules:")
                for mod in sorted(success):  
                    print(f"  - {mod}")
        
        if failed and show_imported and not as_data:
            print(f"{len(failed)} modules failed to import:")
            for mod, error in failed:
                print(f"   {mod}: {error}")
        
        if as_data and show_imported:
            return success, failed
        
    finally:
        _modx_importing = False

def importletter(letter, show_imported=False, as_data=False):
    global _modx_importing
    _modx_importing = True
    try:
        caller_globals = globals()
        letter = letter.lower()
        success = []
        failed = []
        for m in modules:
            if m.lower().startswith(letter):
                try:
                    module_obj = importlib.import_module(m)
                    caller_globals[m] = module_obj
                    _imported_by_modx.add(m)
                    success.append(m)
                except Exception as e:
                    failed.append((m, str(e)))
        
        if show_imported and not as_data:
            print(f"Successfully imported {len(success)} modules starting with '{letter}'")
            if success:
                print("Imported modules:")
                for mod in sorted(success):
                    print(f"  - {mod}")
        
        if failed and show_imported and not as_data:
            print(f"{len(failed)} modules failed to import:")
            for mod, error in failed:
                print(f"   {mod}: {error}")
        
        if as_data and show_imported:
            return success, failed
            
    finally:
        _modx_importing = False
    
def modfunctions(module_name, as_data=False):
    try:
        spec = importlib.util.find_spec(module_name)
        if not spec:
            if as_data:
                return []
            print(f"Module '{module_name}' not found.")
            return
        
        if not spec.origin or not spec.origin.endswith('.py'):
            if as_data:
                return []
            print(f"Module '{module_name}' is built-in or compiled (no source for analysis).")
            return
        
        if not as_data:
            print(f"Module: {module_name}")
            print(f"Source: {spec.origin}")
            print("=" * 50)
        
        with open(spec.origin, 'r', encoding='utf-8') as f:
            source_code = f.read()
        
        functions = []
        try:
            tree = ast.parse(source_code)
            for node in ast.walk(tree):
                if isinstance(node, ast.FunctionDef):
                    # Skip private functions and those in HIDE_FROM_HELP
                    if (not node.name.startswith('_') and 
                        node.name not in ['easter_egg'] and
                        node.name not in HIDE_FROM_HELP and  # ← ADD THIS
                        not node.name.startswith('_tracking')):
                        
                        args = []
                        if node.args.args:
                            for arg in node.args.args:
                                args.append(arg.arg)
                        if node.args.vararg:
                            args.append(f"*{node.args.vararg.arg}")
                        if node.args.kwarg:
                            args.append(f"**{node.args.kwarg.arg}")
                        
                        functions.append({'name': node.name})
                        functions.append({'args': args})
        except SyntaxError:
            if as_data:
                return []
            print("Could not parse module source code.")
            return
        
        if as_data:
            return functions
        
        # Count only name entries (every other item)
        function_count = len([f for f in functions if 'name' in f])
        print(f"Total public functions: {function_count}")
        print("\nFunctions found:")
        for i in range(0, len(functions), 2):
            name_dict = functions[i]
            args_dict = functions[i+1]
            args_str = ', '.join(args_dict['args'])
            print(f"  {i//2 + 1}. {name_dict['name']}({args_str})")
            
    except Exception as e:
        if as_data:
            return []
        print(f"Error: {e}")
        
def modclasses(module_name, as_data=False):
    """Show how many and what classes a module has without importing it."""
    try:
        spec = importlib.util.find_spec(module_name)
        if not spec:
            if as_data:
                return None
            print(f"Module '{module_name}' not found.")
            return
        
        if not spec.origin or not spec.origin.endswith('.py'):
            if as_data:
                return None
            print(f"Module '{module_name}' is built-in or compiled (no source for analysis).")
            return
        
        if not as_data:
            print(f"Module: {module_name}")
            print(f"Source: {spec.origin}")
            print("=" * 50)
        
        with open(spec.origin, 'r', encoding='utf-8') as f:
            source_code = f.read()
        
        classes = []
        try:
            tree = ast.parse(source_code)
            for node in ast.walk(tree):
                if isinstance(node, ast.ClassDef):
                    if not node.name.startswith('_'):
                        classes.append(node.name)
        except SyntaxError:
            if as_data:
                return None
            print("Could not parse module source code.")
            return
        
        classes.sort()
        
        if as_data:
            return classes
        
        print(f"Total public classes: {len(classes)}")
        if classes:
            print("\nClasses found:")
            for i, class_name in enumerate(classes, 1):
                print(f"  {i}. {class_name}")
        else:
            print("\nNo public classes found in this module.")
            
    except (FileNotFoundError, PermissionError, UnicodeDecodeError) as e:
        if as_data:
            return None
        print(f"Could not read module source: {e}")
    except Exception as e:
        if as_data:
            return None
        print(f"Error analyzing module: {e}")

def listimportall(as_data=False):
    """Return the list of modules that import_all() would import."""
    if as_data:
        return modules
    
    print("Modules that import_all() would import:")
    for name in sorted(modules):
        print("-", name)
    print(f"\nTotal modules in importall list: {len(modules)}")

def modsloaded():
    """Show how many modules are currently loaded in sys.modules."""
    return len(sys.modules)

def modximported(as_data=False):
    """Show ONLY the modules directly imported via ModX functions."""
    shown = sorted(_imported_by_modx)
    
    if as_data:
        return shown
    
    print("Modules imported directly via ModX (excluding dependencies):")
    for name in shown:
        print("-", name)
    print(f"\nTotal modules imported via ModX: {len(shown)}")
    
def nonimported(as_data=False):
    """Returns a list of STANDARD LIBRARY
modules that have NOT been imported yet."""
    all_stdlib_modules = set(modules)
    all_stdlib_modules.update(sys.builtin_module_names)
    
    unimported = []
    for module_name in all_stdlib_modules:
        if module_name not in sys.modules:
            unimported.append(module_name)
    
    unimported = sorted(unimported)
    
    if as_data:
        return unimported
    
    print("Standard library modules NOT yet imported:")
    for name in unimported:
        print("-", name)
    print(f"\nTotal non-imported modules: {len(unimported)}")

def dependencies(module_name, as_data=False):
    """Show what other modules a specific module depends on without importing it."""
    import re
    import ast
    
    dependencies = set()
    
    try:
        spec = importlib.util.find_spec(module_name)
        if not spec:
            if as_data:
                return set()
            print(f"Module '{module_name}' not found")
            return
        
        if spec.origin and spec.origin.endswith('.py'):
            try:
                with open(spec.origin, 'r', encoding='utf-8') as f:
                    source_code = f.read()
                
                try:
                    tree = ast.parse(source_code)
                    for node in ast.walk(tree):
                        if isinstance(node, ast.Import):
                            for alias in node.names:
                                dependencies.add(alias.name.split('.')[0])
                        elif isinstance(node, ast.ImportFrom):
                            if node.module:  
                                dependencies.add(node.module.split('.')[0])
                except SyntaxError:
                    imports = re.findall(r'^(?:import|from)\s+([\w\.]+)', source_code, re.MULTILINE)
                    for import_name in imports:
                        dependencies.add(import_name.split('.')[0])
                        
            except (UnicodeDecodeError, FileNotFoundError, IOError):
                if as_data:
                    return set()
                print("   (Source not readable)")
        
        dependencies.discard(module_name.split('.')[0])
        dependencies.discard('_future_')
        dependencies.discard('builtins')
        
        if as_data:
            return sorted(dependencies)
        
        print(f"Dependency analysis for: {module_name}")
        print("=" * 40)
        if spec.origin and spec.origin.endswith('.py'):
            print(f"File: {spec.origin}")
        elif spec.origin:
            print(f"File: {spec.origin} (compiled module)")
        else:
            print("   (Built-in module)")
        
        if dependencies:
            print("Dependencies found:")
            for dep in sorted(dependencies):
                dep_spec = importlib.util.find_spec(dep)
                status = "[AVAILABLE]" if dep_spec else "[NOT FOUND]"
                print(f"   {dep}")
        else:
            print("No external dependencies found")
            
    except Exception as e:
        if as_data:
            return set()
        print(f"Error analyzing module: {e}")

def searchmodules(keyword, as_data=False):
    """Search for modules whose names contain the keyword."""
    keyword = keyword.lower()
    results = [m for m in modules if keyword in m.lower()]
    
    if as_data:
        return results
    
    print(f"Modules containing '{keyword}':")
    for name in sorted(results):
        print(f"  - {name}")
    print(f"\nTotal matches: {len(results)}")

def info(module_name, as_data=False):
    """Show basic info about a module: file path, built-in status, docstring."""
    import inspect
    try:
        mod = sys.modules[module_name] if module_name in sys.modules else importlib.import_module(module_name)
    except ImportError:
        if as_data:
            return None
        print(f"Module '{module_name}' not found.")
        return
    
    path = getattr(mod, '__file__', '(built-in)')
    doc = inspect.getdoc(mod)
    
    if as_data:
        return {
            'module': module_name,
            'path': path,
            'docstring': doc
        }
    
    print(f"Module: {module_name}")
    print(f"Path: {path}")
    print("Docstring:")
    if doc:
        print(doc)
    else:
        print("  No docstring available.")

def isimported(module_name: str):
    '''Check if a module is imported in the caller's globals.
True: currently imported in shell globals
False: exists but not imported yet'''
    import importlib.util, inspect
    frame = inspect.currentframe().f_back
    caller_globals = frame.f_globals
    if module_name in caller_globals:
        return True
    spec = importlib.util.find_spec(module_name)
    if spec:
        return False
    return f"Module {module_name} doesn't exist."

def vcompat(module_name, python_version=None, as_data=False):
    """Python module compatibility checker for Python versions.
If python_version not given: sweeps ALL Python versions 2.0 to 3.14,
    """
    COMPAT_RULES = {
        # ============ PYTHON 2.x ============
        "generators": {"added_in": "2.2", "note": "Generators and yield added"},
        "enumerate": {"added_in": "2.3", "note": "enumerate() function added"},
        "boolean": {"added_in": "2.3", "note": "bool type added"},
        "decorators": {"added_in": "2.4", "note": "Function decorators @ added"},
        "generator_expressions": {"added_in": "2.4", "note": "Generator expressions added"},
        "with_statement": {"added_in": "2.5", "note": "with statement added"},
        "conditional_expressions": {"added_in": "2.5", "note": "x if condition else y syntax added"},
        "str.format": {"added_in": "2.6", "note": "str.format() method added"},
        "class_decorators": {"added_in": "2.6", "note": "Class decorators added"},
        "dict_comprehensions": {"added_in": "2.7", "note": "Dictionary comprehensions added"},
        "set_literals": {"added_in": "2.7", "note": "Set literals {1,2,3} added"},

        # ============ PYTHON 2.x -> 3.0 REMOVED ============
        "print": {"removed_in": "3.0", "note": "Python 2 print statement - use print() function"},
        "print>>": {"removed_in": "3.0", "note": "Print chevron syntax removed - use file= parameter"},
        "xrange": {"removed_in": "3.0", "note": "Use range() in Python 3"},
        "raw_input": {"removed_in": "3.0", "note": "Use input() in Python 3"},
        "unicode": {"removed_in": "3.0", "note": "Use str in Python 3"},
        "long": {"removed_in": "3.0", "note": "long type merged into int"},
        "basestring": {"removed_in": "3.0", "note": "basestring removed - use str"},
        "apply": {"removed_in": "3.0", "note": "apply() removed - call function directly"},
        "execfile": {"removed_in": "3.0", "note": "execfile() removed - use exec()"},
        "reload": {"removed_in": "3.0", "note": "reload() moved to importlib.reload()"},
        "coerce": {"removed_in": "3.0", "note": "coerce() removed"},
        "file": {"removed_in": "3.0", "note": "file type removed - use open()"},
        "raise Exception,": {"removed_in": "3.0", "note": "Old raise syntax removed - use raise Exception()"},
        "except Exception,": {"removed_in": "3.0", "note": "Old except syntax removed - use except Exception as e"},
        "backticks": {"removed_in": "3.0", "note": "Backticks for repr() removed - use repr()"},
        "<>": {"removed_in": "3.0", "note": "<> operator removed - use !="},
        "thread": {"removed_in": "3.0", "note": "thread module renamed to _thread"},
        "dummy_thread": {"removed_in": "3.0", "note": "dummy_thread module removed"},
        "anydbm": {"removed_in": "3.0", "note": "anydbm module removed - use dbm"},
        "dbhash": {"removed_in": "3.0", "note": "dbhash module removed"},
        "dumbdbm": {"removed_in": "3.0", "note": "dumbdbm module removed"},
        "gdbm": {"removed_in": "3.0", "note": "gdbm module interface changed"},
        "whichdb": {"removed_in": "3.0", "note": "whichdb module removed"},
        "bsddb": {"removed_in": "3.0", "note": "bsddb module removed"},
        "md5": {"removed_in": "3.0", "note": "md5 module removed - use hashlib.md5()"},
        "sha": {"removed_in": "3.0", "note": "sha module removed - use hashlib"},
        "crypt": {"removed_in": "3.0", "note": "crypt module moved to third-party"},
        "popen2": {"removed_in": "3.0", "note": "popen2 module removed - use subprocess"},
        "commands": {"removed_in": "3.0", "note": "commands module removed - use subprocess"},

        # ============ PYTHON 3.0 CHANGES ============
        "exec": {"changed_in": "3.0", "note": "exec is a function, not a statement"},
        "print_function": {"changed_in": "3.0", "note": "print is a function, not a statement"},
        "ConfigParser": {"removed_in": "3.0", "note": "Renamed to configparser"},
        "cPickle": {"removed_in": "3.0", "note": "Renamed to pickle"},
        "StringIO": {"removed_in": "3.0", "note": "Use io.StringIO"},
        "Queue": {"removed_in": "3.0", "note": "Renamed to queue"},
        "SocketServer": {"removed_in": "3.0", "note": "Renamed to socketserver"},
        "Tkinter": {"removed_in": "3.0", "note": "Renamed to tkinter"},
        "urllib2": {"removed_in": "3.0", "note": "Renamed to urllib"},

        # ============ PYTHON 3.1 - 3.2 ============
        "importlib": {"added_in": "3.1", "note": "importlib module added"},
        "ordered_dict": {"added_in": "3.1", "note": "collections.OrderedDict added"},
        "concurrent.futures": {"added_in": "3.2", "note": "concurrent.futures module added"},
        "argparse": {"added_in": "3.2", "note": "argparse added to stdlib"},

        # ============ PYTHON 3.3 ============
        "yield from": {"added_in": "3.3", "note": "yield from syntax added"},
        "venv": {"added_in": "3.3", "note": "venv module added"},
        "faulthandler": {"added_in": "3.3", "note": "faulthandler module added"},
        "ipaddress": {"added_in": "3.3", "note": "ipaddress module added"},

        # ============ PYTHON 3.4 ============
        "asyncio": {"added_in": "3.4", "note": "asyncio module added"},
        "enum": {"added_in": "3.4", "note": "enum module added"},
        "pathlib": {"added_in": "3.4", "note": "pathlib module added"},

        # ============ PYTHON 3.5 ============
        "async": {"changed_in": "3.5", "note": "'async' became a reserved keyword"},
        "await": {"changed_in": "3.5", "note": "'await' became a reserved keyword"},
        "typing": {"added_in": "3.5", "note": "typing module added"},
        "@ operator": {"added_in": "3.5", "note": "Matrix multiplication operator @ added"},

        # ============ PYTHON 3.6 ============
        "fstrings": {"added_in": "3.6", "note": "f-string syntax added"},
        "secrets": {"added_in": "3.6", "note": "secrets module for cryptographic randomness"},
        "underscore_literals": {"added_in": "3.6", "note": "1_000_000 numeric literal syntax"},

        # ============ PYTHON 3.7 ============
        "async/await": {"changed_in": "3.7", "note": "async/await became proper keywords"},
        "dataclasses": {"added_in": "3.7", "note": "dataclasses module added"},
        "contextvars": {"added_in": "3.7", "note": "contextvars module added"},

        # ============ PYTHON 3.8 ============
        "walrus": {"added_in": "3.8", "note": "Walrus operator := added"},
        "positional_only": {"added_in": "3.8", "note": "Positional-only parameters / syntax added"},
        "fstring=": {"added_in": "3.8", "note": "f-string = debugging syntax added"},

        # ============ PYTHON 3.9 ============
        "dict_union": {"added_in": "3.9", "note": "Dict union | operator added"},
        "str_removeprefix": {"added_in": "3.9", "note": "str.removeprefix/removesuffix methods added"},
        "zoneinfo": {"added_in": "3.9", "note": "zoneinfo module for timezone support"},

        # ============ PYTHON 3.10 ============
        "match": {"added_in": "3.10", "note": "Structural pattern matching match/case added"},
        "union_operator": {"added_in": "3.10", "note": "X | Y union type syntax for isinstance()"},

        # ============ PYTHON 3.11 ============
        "exception_groups": {"added_in": "3.11", "note": "ExceptionGroups and except* added"},
        "tomllib": {"added_in": "3.11", "note": "tomllib module for TOML parsing"},

        # ============ PYTHON 3.12 ============
        "fstring_debug": {"added_in": "3.12", "note": "Enhanced f-string debugging"},
        "type_parameter_syntax": {"added_in": "3.12", "note": "New type parameter syntax (PEP 695)"},

        # ============ PYTHON 3.13 ============
        "randbytes": {"added_in": "3.13", "note": "random.randbytes() for cryptographic random bytes"},
        "sys._base_executable": {"added_in": "3.13", "note": "Path to the base Python executable"},
        "copy.replace": {"added_in": "3.13", "note": "copy.replace() for replacing object attributes"},
        "ast.walk": {"added_in": "3.13", "note": "ast.walk() generator for AST nodes"},
        "importlib.resources.abc": {"added_in": "3.13", "note": "ABCs for importlib.resources"},
        "tomllib.TOMLDecodeError": {"added_in": "3.13", "note": "TOML decoder exception class"},
        "typing.ReadOnly": {"added_in": "3.13", "note": "ReadOnly type qualifier for TypedDict"},
        "warnings.deprecated": {"added_in": "3.13", "note": "@deprecated decorator for deprecation warnings"},
        "ssl.create_default_context": {"changed_in": "3.13", "note": "Updated security defaults"},
        "unittest.IsolatedAsyncioTestCase": {"added_in": "3.13", "note": "Async test case class"},

        # ============ PYTHON 3.13 REMOVALS ============
        "cgi": {"deprecated_in": "3.11", "removed_in": "3.13", "note": "cgi module removed - use third-party alternatives"},
        "cgitb": {"deprecated_in": "3.11", "removed_in": "3.13", "note": "cgitb module removed"},
        "telnetlib": {"deprecated_in": "3.11", "removed_in": "3.13", "note": "telnetlib module removed"},
        "aifc": {"deprecated_in": "3.11", "removed_in": "3.13", "note": "aifc module removed"},
        "chunk": {"deprecated_in": "3.11", "removed_in": "3.13", "note": "chunk module removed"},
        "msilib": {"deprecated_in": "3.11", "removed_in": "3.13", "note": "msilib module removed"},
        "nis": {"deprecated_in": "3.11", "removed_in": "3.13", "note": "nis module removed"},
        "ossaudiodev": {"deprecated_in": "3.11", "removed_in": "3.13", "note": "ossaudiodev module removed"},
        "spwd": {"deprecated_in": "3.11", "removed_in": "3.13", "note": "spwd module removed"},
        "sunau": {"deprecated_in": "3.11", "removed_in": "3.13", "note": "sunau module removed"},
        "uu": {"deprecated_in": "3.11", "removed_in": "3.13", "note": "uu module removed"},
        "xdrlib": {"deprecated_in": "3.11", "removed_in": "3.13", "note": "xdrlib module removed"},

        # ============ PYTHON 3.14 ============
        "global_interpreter_lock": {"changed_in": "3.14", "note": "GIL can now be disabled at runtime (experimental)"},
        "namedtuple._asdict": {"changed_in": "3.14", "note": "Returns regular dict, not OrderedDict"},
        "zipfile._path": {"added_in": "3.14", "note": "Path-like interface for zipfile contents"},
        "email.utils.localtime": {"added_in": "3.14", "note": "localtime() function with timezone support"},
        "heapq.merge": {"changed_in": "3.14", "note": "Now preserves input types"},
        "json.dump": {"changed_in": "3.14", "note": "Optimized serialization for dataclasses"},
        "math.sumprod": {"added_in": "3.14", "note": "Sum of products function"},
        "pathlib.Path.walk": {"added_in": "3.14", "note": "Directory tree generator"},
        "re.Pattern.search_all": {"added_in": "3.14", "note": "Returns iterator of all non-overlapping matches"},
        "statistics.geometric_mean": {"added_in": "3.14", "note": "Geometric mean calculation"},
        "sys._debugmallocstats": {"changed_in": "3.14", "note": "Enhanced memory debugging output"},
        "tempfile.NamedTemporaryFile": {"changed_in": "3.14", "note": "Supports delete_on_close parameter"},
        "threading.Barrier": {"added_in": "3.14", "note": "Barrier synchronization primitive"},
        "traceback.StackSummary.format": {"changed_in": "3.14", "note": "Improved traceback formatting"},
        "zipfile.ZipFile": {"changed_in": "3.14", "note": "Supports 'xz' compression by default"},

        # ============ PYTHON 3.14 DEPRECATIONS ============
        "array.typecodes": {"deprecated_in": "3.14", "note": "Use array.typecodes property directly"},
        "email.base64mime": {"deprecated_in": "3.14", "note": "Use base64 module directly"},
        "email.quoprimime": {"deprecated_in": "3.14", "note": "Use quopri module directly"},
        "http.cookies": {"deprecated_in": "3.14", "note": "Use http.cookies.SimpleCookie directly"},
        "importlib.metadata.distribution": {"deprecated_in": "3.14", "note": "Use importlib.metadata.distributions()"},
        "inspect.ismethoddescriptor": {"deprecated_in": "3.14", "note": "Use inspect.isdatadescriptor"},
        "sqlite3.enable_callback_tracebacks": {"deprecated_in": "3.14", "note": "Use db.set_trace_callback"},
        "unittest.mock.Mock.assert_called": {"deprecated_in": "3.14", "note": "Use assert_called_once"},
        "urllib.parse.SplitResult": {"deprecated_in": "3.14", "note": "Use urllib.parse.urlsplit"},

        # ============ LEGACY DEPRECATIONS (KEPT FOR REFERENCE) ============
        "distutils": {"deprecated_in": "3.10", "removed_in": "3.12", "note": "distutils removed - use setuptools"},
        "imp": {"deprecated_in": "3.4", "removed_in": "3.12", "note": "imp removed - use importlib"},
        "asyncore": {"deprecated_in": "3.6", "note": "asyncore module deprecated"},
        "asynchat": {"deprecated_in": "3.6", "note": "asynchat module deprecated"},
}

    if python_version:
        targets = [version.parse(str(python_version))]
        if targets[0] > version.parse("3.14"):
            targets[0] = version.parse("3.14")
    else:
        targets = [version.parse(f"{major}.{minor}")
                   for major in (2, 3)
                   for minor in range(0, (8 if major == 2 else 15))]

    spec = importlib.util.find_spec(module_name)
    if not spec or not spec.origin or not spec.origin.endswith(".py"):
        if as_data:
            return {}
        print(f"Module {module_name} is either not a module, not a source-based module or not available in this Python version (may have been removed).")
        return

    with open(spec.origin, "r", encoding="utf-8", errors="ignore") as f:
        content = f.read()

    warnings = {}

    tokens = list(tokenize.generate_tokens(io.StringIO(content).readline))
    
    comment_string_positions = set()
    current_line = 1
    current_col = 0
    
    for tok in tokens:
        if tok.type in (tokenize.COMMENT, tokenize.STRING):
            start_line, start_col = tok.start
            end_line, end_col = tok.end
            
            if start_line == end_line:
                for col in range(start_col, end_col):
                    comment_string_positions.add((start_line, col))
            else:
                for col in range(start_col, 1000):  
                    comment_string_positions.add((start_line, col))
                for line in range(start_line + 1, end_line):
                    for col in range(0, 1000):
                        comment_string_positions.add((line, col))
                for col in range(0, end_col):
                    comment_string_positions.add((end_line, col))
    
    def _is_in_comment_or_string(line, col):
        return (line, col) in comment_string_positions

    def _add_warning(key, rule, label):
        if key not in warnings:
            warnings[key] = label

    def _check_if_problematic(rule, targets):
        if "removed_in" in rule:
            removed_ver = version.parse(rule["removed_in"])
            return any(target >= removed_ver for target in targets)
        elif "added_in" in rule:
            added_ver = version.parse(rule["added_in"])
            return any(target < added_ver for target in targets)
        return False

    for key, rule in COMPAT_RULES.items():
        if key in ["print_stmt", "exec_stmt", "async_kw", "await_kw", "walrus", "match"]:
            continue  
        
        if any(key in token.string for token in tokens if token.type == tokenize.NAME):
            valid_occurrence = False
            
            for token in tokens:
                if token.type == tokenize.NAME and token.string == key:
                    line, col = token.start
                    if not _is_in_comment_or_string(line, col):
                        valid_occurrence = True
                        break
            
            if not valid_occurrence:
                continue  

            if key == "print" and "print " in content:
                lines = content.split('\n')
                for i, line in enumerate(lines, 1):
                    if "print " in line and not line.strip().startswith('#'):
                        pos = line.find("print ")
                        if not _is_in_comment_or_string(i, pos):
                            problematic_for_any = _check_if_problematic(rule, targets)
                            if problematic_for_any:
                                _add_warning(key, rule, ("3.0", f"REMOVED → {rule['note']}"))
                            break
            
            elif key == "xrange" and "xrange(" in content:
                lines = content.split('\n')
                for i, line in enumerate(lines, 1):
                    if "xrange(" in line and not line.strip().startswith('#'):
                        pos = line.find("xrange(")
                        if not _is_in_comment_or_string(i, pos):
                            problematic_for_any = _check_if_problematic(rule, targets)
                            if problematic_for_any:
                                _add_warning(key, rule, ("3.0", f"REMOVED → {rule['note']}"))
                            break
            
            elif key == "raw_input" and "raw_input(" in content:
                lines = content.split('\n')
                for i, line in enumerate(lines, 1):
                    if "raw_input(" in line and not line.strip().startswith('#'):
                        pos = line.find("raw_input(")
                        if not _is_in_comment_or_string(i, pos):
                            problematic_for_any = _check_if_problematic(rule, targets)
                            if problematic_for_any:
                                _add_warning(key, rule, ("3.0", f"REMOVED → {rule['note']}"))
                            break

            elif key == "unicode" and "unicode(" in content:
                lines = content.split('\n')
                for i, line in enumerate(lines, 1):
                    if "unicode(" in line and not line.strip().startswith('#'):
                        pos = line.find("unicode(")
                        if not _is_in_comment_or_string(i, pos):
                            problematic_for_any = _check_if_problematic(rule, targets)
                            if problematic_for_any:
                                _add_warning(key, rule, ("3.0", f"REMOVED → {rule['note']}"))
                            break

            elif key == "long" and "long(" in content:
                lines = content.split('\n')
                for i, line in enumerate(lines, 1):
                    if "long(" in line and not line.strip().startswith('#'):
                        pos = line.find("long(")
                        if not _is_in_comment_or_string(i, pos):
                            problematic_for_any = _check_if_problematic(rule, targets)
                            if problematic_for_any:
                                _add_warning(key, rule, ("3.0", f"REMOVED → {rule['note']}"))
                            break
        
            elif key == "basestring" and "basestring(" in content:
                lines = content.split('\n')
                for i, line in enumerate(lines, 1):
                    if "basestring(" in line and not line.strip().startswith('#'):
                        pos = line.find("basestring(")
                        if not _is_in_comment_or_string(i, pos):
                            problematic_for_any = _check_if_problematic(rule, targets)
                            if problematic_for_any:
                                _add_warning(key, rule, ("3.0", f"REMOVED → {rule['note']}"))
                            break
            
            elif key == "StringIO" and "StringIO" in content:
                lines = content.split('\n')
                for i, line in enumerate(lines, 1):
                    if "StringIO" in line and not line.strip().startswith('#'):
                        if "io.StringIO" not in line:
                            pos = line.find("StringIO")
                            if not _is_in_comment_or_string(i, pos):
                                problematic_for_any = _check_if_problematic(rule, targets)
                                if problematic_for_any:
                                    _add_warning(key, rule, ("3.0", f"REMOVED → {rule['note']}"))
                                break
            
            elif key not in ["print", "xrange", "raw_input", "unicode", "long", "basestring", "StringIO"]:
                problematic_for_any = _check_if_problematic(rule, targets)
                if problematic_for_any:
                    if "removed_in" in rule:
                        _add_warning(key, rule, (rule["removed_in"], f"REMOVED → {rule['note']}"))
                    elif "added_in" in rule:
                        _add_warning(key, rule, (rule["added_in"], f"NOT AVAILABLE before {rule['added_in']} → {rule['note']}"))

    tree = None
    try:
        tree = ast.parse(content)
    except Exception:
        pass
    
    if tree:
        for node in ast.walk(tree):
            if hasattr(ast, "Print") and isinstance(node, ast.Print):
                problematic = any(target >= version.parse("3.0") for target in targets)
                if problematic:
                    _add_warning("print_stmt", COMPAT_RULES["print"],
                                ("3.0", f"REMOVED → {COMPAT_RULES['print']['note']}"))

            if hasattr(ast, "Exec") and isinstance(node, ast.Exec):
                problematic = any(target >= version.parse("3.0") for target in targets)
                if problematic:
                    _add_warning("exec_stmt", COMPAT_RULES["exec"],
                                ("3.0", f"CHANGED → {COMPAT_RULES['exec']['note']}"))

            if isinstance(node, ast.NamedExpr):
                problematic = any(target < version.parse("3.8") for target in targets)
                if problematic:
                    _add_warning("walrus", COMPAT_RULES["walrus"],
                                ("3.8", f"NOT AVAILABLE before 3.8 → {COMPAT_RULES['walrus']['note']}"))

            if hasattr(ast, "Match") and isinstance(node, ast.Match):
                problematic = any(target < version.parse("3.10") for target in targets)
                if problematic:
                    _add_warning("match", COMPAT_RULES["match"],
                                ("3.10", f"NOT AVAILABLE before 3.10 → {COMPAT_RULES['match']['note']}"))

            if isinstance(node, ast.AsyncFunctionDef):
                problematic = any(target < version.parse("3.5") for target in targets)
                if problematic:
                    _add_warning("async_kw", COMPAT_RULES["async"],
                                ("3.5", f"CHANGED since 3.5 → {COMPAT_RULES['async']['note']}"))

            if isinstance(node, ast.Await):
                problematic = any(target < version.parse("3.5") for target in targets)
                if problematic:
                    _add_warning("await_kw", COMPAT_RULES["await"],
                                ("3.5", f"CHANGED since 3.5 → {COMPAT_RULES['await']['note']}"))

            if isinstance(node, ast.JoinedStr):
                problematic = any(target < version.parse("3.6") for target in targets)
                if problematic:
                    _add_warning("fstrings", COMPAT_RULES["fstrings"],
                                ("3.6", f"NOT AVAILABLE before 3.6 → {COMPAT_RULES['fstrings']['note']}"))

    if as_data:
        return warnings
    
    print(f"Compatibility Report for {module_name}")
    print(f"Target Python Version: {python_version if python_version else 'All versions 2.0-3.14'}")
    print("=" * 50)
    if not warnings:
        print("No compatibility issues detected.")
    else:
        print(f"{'Feature':<10} | {'Version':<7} | Warning")
        print("-" * 80)
        for feat, (ver, note) in warnings.items():
            print(f"{feat:<10} | {ver:<7} | {note}")

def modbench(module_name, as_data=False):
    """Measures time and memory usage for a module import.
First import will be slower due to .pyc compilation.
Returns module name, seconds, and memory_kb.
    """
    import importlib
    
    if module_name in sys.modules:
        del sys.modules[module_name]
    
    start_time = time.perf_counter()
    tracemalloc.start()
    try:
        importlib.import_module(module_name)
    except Exception as e:
        tracemalloc.stop()
        if as_data:
            return {'module': module_name, 'error': str(e), 'seconds': 0, 'memory_kb': 0}
        print(f"Failed to import {module_name}: {e}")
        return
    
    current, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    elapsed = time.perf_counter() - start_time
    
    result = {
        "module": module_name,
        "seconds": round(elapsed, 4),
        "memory_kb": round(peak / 1024, 2)
    }
    
    if as_data:
        return result
    
    print(f"Module: {module_name}")
    print(f"Import time: {result['seconds']} seconds")
    print(f"Peak memory: {result['memory_kb']} KB")

def modorigin(module_name, as_data=False):
    import importlib.util, sys, os, pkgutil

    spec = importlib.util.find_spec(module_name)
    if spec is None:
        result = {
            "module": module_name,
            "origin_class": "unknown",
            "path": None,
            "details": "Module not found"
        }
        if as_data:
            return result
        print(f"Module '{module_name}' not found.")
        return

    origin = spec.origin
    submodule_paths = spec.submodule_search_locations

    def _is_builtin():
        return origin == "built-in"

    def _is_frozen():
        return origin and origin.startswith("<frozen")

    def _is_namespace_package():
        return submodule_paths is not None and origin is None

    def _is_c_extension():
        return origin and origin.endswith((".pyd", ".so", ".dll"))

    def _is_zip():
        return origin and (".zip" in origin or ".pyz" in origin)

    def _is_editable_install():
        try:
            if origin and '.egg-link' in origin:
                return True
            for path in sys.path:
                if 'site-packages' in path or 'dist-packages' in path:
                    egg_link_path = os.path.join(path, f"{module_name}.egg-link")
                    if os.path.exists(egg_link_path):
                        return True
            return False
        except Exception:
            return False

    def _is_wheel_based():
        return origin and ".dist-info" in origin

    def _is_pip_install():
        if _is_editable_install():
            return True
        if _is_wheel_based():
            return True
        pip_keywords = ["site-packages", "dist-packages", ".dist-info", ".egg-info", "pipx", "venv"]
        return origin and any(key in origin.replace("\\", "/") for key in pip_keywords)

    def _stdlib_root():
        return os.path.dirname(os.__file__).replace("\\", "/")

    def _is_stdlib():
        if _is_builtin():
            return False
        if not origin or not os.path.isfile(origin):
            return False
        return origin.replace("\\", "/").startswith(_stdlib_root())

    def _is_user_module():
        return (not _is_builtin() and not _is_frozen() and not _is_stdlib() 
                and not _is_pip_install() and not _is_namespace_package())

    if _is_builtin():
        result = {
            "module": module_name,
            "origin_class": "builtin",
            "path": None,
            "details": "Compiled into Python interpreter"
        }
    elif _is_frozen():
        result = {
            "module": module_name,
            "origin_class": "frozen",
            "path": origin,
            "details": "Frozen module (PyInstaller/Nuitka)"
        }
    elif _is_namespace_package():
        result = {
            "module": module_name,
            "origin_class": "namespace-package",
            "path": list(submodule_paths) if submodule_paths else [],
            "details": "Module has no physical file; namespace package"
        }
    elif _is_c_extension():
        result = {
            "module": module_name,
            "origin_class": "c-extension",
            "path": origin,
            "details": "Compiled C extension (.pyd / .so)"
        }
    elif _is_zip():
        result = {
            "module": module_name,
            "origin_class": "zipimport",
            "path": origin,
            "details": "Loaded from .pyz/.zip archive"
        }
    elif _is_editable_install():
        result = {
            "module": module_name,
            "origin_class": "editable-pip-install",
            "path": origin,
            "details": "Editable pip install (egg-link)"
        }
    elif _is_wheel_based():
        result = {
            "module": module_name,
            "origin_class": "wheel-installed",
            "path": origin,
            "details": "Module installed from a wheel distribution"
        }
    elif _is_pip_install():
        result = {
            "module": module_name,
            "origin_class": "pip-installed",
            "path": origin,
            "details": "Installed via pip (site-packages/dist-packages)"
        }
    elif _is_stdlib():
        result = {
            "module": module_name,
            "origin_class": "stdlib",
            "path": origin,
            "details": "Part of Python standard library"
        }
    elif _is_user_module():
        result = {
            "module": module_name,
            "origin_class": "user-module",
            "path": origin,
            "details": "User-created module from local project directory"
        }
    else:
        result = {
            "module": module_name,
            "origin_class": "unknown",
            "path": origin,
            "details": "Unable to classify module origin"
        }

    if as_data:
        return result
    
    print(f"Module: {result['module']}")
    print(f"Origin: {result['origin_class']}")
    print(f"Path: {result['path'] or 'N/A'}")
    print(f"Details: {result['details']}")
    
def easter_egg(xrghzqxrghzq=None):
    "??????????"
    a= '''╔═══════════════════════════════════════╗
║ ███╗   ███╗ ██████╗ ██████╗ ██╗  ██╗  ║
║ ████╗ ████║██╔═══██╗██╔══██╗╚██╗██╔╝  ║
║ ██╔████╔██║██║   ██║██║  ██║ ╚███╔╝   ║
║ ██║╚██╔╝██║██║   ██║██║  ██║ ██╔██╗   ║
║ ██║ ╚═╝ ██║╚██████╔╝██████╔╝██╔╝ ██╗  ║
║ ╚═╝     ╚═╝ ╚═════╝ ╚═════╝ ╚═╝  ╚═╝  ║
║              M  O  D  X               ║
╚═══════════════════════════════════════╝
'''
    if xrghzqxrghzq == "abc":
        print(a)
    else:
        raise ValueError("^&*()^*&%^#$@$#^(*&%#^$%&*^$%$$!$#@$&(")
        sys.exit("!)@(#$&*%^&#R&#$)!!%$@&)#@*)^!$#&!%*^)!$@#)%!$")
        quit()

def revdeps(module_name, as_data=False):
    import builtins
    import ast
    
    spec = importlib.util.find_spec(module_name)
    if not spec:
        if as_data:
            return []
        print(f"Module '{module_name}' not found.")
        return
    
    found_modules = []
    
    def _has_import_of_target(source_code, target_module):
        try:
            tree = ast.parse(source_code)
            for node in ast.walk(tree):
                if isinstance(node, ast.Import):
                    for alias in node.names:
                        if alias.name == target_module:
                            return True
                elif isinstance(node, ast.ImportFrom):
                    if node.module == target_module:
                        return True
            return False
        except SyntaxError:
            import re
            patterns = [
                rf'^import\s+{re.escape(target_module)}\s*($|#|as)',
                rf'^from\s+{re.escape(target_module)}\s+import',
            ]
            for pattern in patterns:
                if re.search(pattern, source_code, re.MULTILINE):
                    return True
            return False
    
    builtins.__import__ = _original_import
    try:
        for mod in modules:
            try:
                spec = importlib.util.find_spec(mod)
                if spec and spec.origin and os.path.exists(spec.origin) and spec.origin.endswith('.py'):
                    with open(spec.origin, 'r', encoding='utf-8', errors='ignore') as f:
                        content = f.read()
                    if _has_import_of_target(content, module_name):
                        found_modules.append(f"stdlib: {mod}")
            except:
                continue
    finally:
        builtins.__import__ = _tracking_import
    
    builtins.__import__ = _original_import
    try:
        for finder, name, ispkg in pkgutil.iter_modules():
            if (name not in modules and 
                name not in sys.builtin_module_names and
                name != '__main__' and
                not name.startswith('__') and
                name.isidentifier()):
                try:
                    spec = importlib.util.find_spec(name)
                    if (spec and spec.origin and 
                        os.path.exists(spec.origin) and 
                        spec.origin.endswith('.py')):
                        with open(spec.origin, 'r', encoding='utf-8', errors='ignore') as f:
                            content = f.read()
                        if _has_import_of_target(content, module_name):
                            found_modules.append(f"third-party: {name}")
                except:
                    continue
    finally:
        builtins.__import__ = _tracking_import
    
    if as_data:
        return found_modules
    
    print(f"REVERSE DEPENDENCY SCAN: {module_name}")
    print("=" * 50)
    print(f"Scanning standard library and third-party packages...")
    if found_modules:
        print(f"\nMODULES THAT IMPORT '{module_name}':")
        print("-" * 40)
        for module in found_modules:
            print(f"  • {module}")
    else:
        print(f"\nNo modules found that import '{module_name}'")
        
HIDE_FROM_HELP = {"easter_egg", "test"}

def modxhelp(export=None, compact=False, banner=True):
    """Auto-generate help text for ModX functions.
export: if filename given, export Markdown help.
compact: if True, show single-line summaries only.
banner: if False, don't print the ASCII banner.
Hides internal functions.
    """
    import inspect, time

    if banner:
        print("ModX — Auto Help System 2.0")
        print("=" * 32)

    frame_globals = globals()
    funcs = []
    for name, obj in sorted(frame_globals.items()):
        if name.startswith("_") or name in HIDE_FROM_HELP:
            continue
        if inspect.isfunction(obj) and getattr(obj, "__module__", None) == __name__:
            try:
                sig = str(inspect.signature(obj))
            except Exception:
                sig = "(...)"
            doc = (obj.__doc__ or "").strip().splitlines()
            short = doc[0].strip() if doc else "(no short description)"
            longdoc = "\n".join(doc[1:]).strip() if len(doc) > 1 else ""
            funcs.append({"name": name, "sig": sig, "short": short, "long": longdoc})

    lines = []
    for item in funcs:
        if compact:
            lines.append(f"{item['name']}{item['sig']} — {item['short']}")
        else:
            lines.append(f"{item['name']}{item['sig']}")
            lines.append(f"  {item['short']}")
            if item["long"]:
                for l in item["long"].splitlines():
                    lines.append("    " + l)
            lines.append("")

    text = "\n".join(lines).rstrip("\n")
    print(text)

    if export:
        try:
            md_lines = [f"# ModX - Auto Help (generated) - {time.strftime('%Y-%m-%d')}\n"]
            for item in funcs:
                md_lines.append(f"## {item['name']}{item['sig']}\n")
                md_lines.append(f"{item['short']}\n")
                if item["long"]:
                    md_lines.append(item["long"] + "\n")
            md_text = "\n".join(md_lines)
            with open(export, "w", encoding="utf-8") as fh:
                fh.write(md_text)
            print(f"modx_help: exported Markdown to {export}")
        except Exception as e:
            print(f"modx_help: failed to export '{export}': {e}")

def modglobals(module_name, show_private=False, export=None, as_data=False):
    try:
        mod = importlib.import_module(module_name)
    except Exception as e:
        if as_data:
            return {}
        print(f"Failed to import '{module_name}': {e}")
        return

    _globals = {}
    for name, val in vars(mod).items():
        if not show_private and name.startswith("_"):
            continue
        if (inspect.isfunction(val) or 
            inspect.isclass(val) or 
            inspect.ismodule(val)):
            continue
        _globals[name] = type(val).__name__

    if as_data:
        return dict(sorted(_globals.items()))

    print(f"Globals in module '{module_name}':")
    for name, typ in sorted(_globals.items()):
        print(f"  • {name} : {typ}")

    if export:
        try:
            md_lines = [f"# {module_name} - Globals Report - {time.strftime('%Y-%m-%d')}\n"]
            for name, typ in sorted(_globals.items()):
                md_lines.append(f"- `{name}` : `{typ}`")
            md_text = "\n".join(md_lines)
            with open(export, "w", encoding="utf-8") as fh:
                fh.write(md_text)
            print(f"modglobals: exported Markdown to {export}")
        except Exception as e:
            print(f"modglobals: failed to export '{export}': {e}")

def importlog(include_deps=False, as_data=False):
    modx_imports_list = ['sys', 'importlib', 'pkgutil', 'random', 'builtins', 'ast', 'importlib.util',
                         'os', 'tokenize', 'io', 'time', 'tracemalloc', 'inspect', 'textwrap',
                         'math', 'threading', 'pathlib', 'packaging', 'datetime']
    
    current_modules = list(sys.modules.keys())
    chronological_order = current_modules
    
    if include_deps:
        all_modules_in_order = []
        
        for modx_dep in modx_imports_list:
            if modx_dep in current_modules and modx_dep not in all_modules_in_order:
                all_modules_in_order.append(modx_dep)
        
        for module in chronological_order:
            if module in all_modules_in_order:
                continue
            if module not in _initial_modules and module != '__main__':
                all_modules_in_order.append(module)
                
        modules_to_show = all_modules_in_order
                
    else:
        modules_to_show = [
            m for m in chronological_order 
            if m not in _initial_modules and 
            m not in modx_imports_list and
            m != '__main__'
        ]
    
    if as_data:
        return modules_to_show
    
    print(f"Modules imported since ModX load (in chronological order):")
    if include_deps:
        print("(including ModX dependencies)")
    print(f"Total modules: {len(modules_to_show)}")
    print("=" * 50)
    
    if modules_to_show:
        for i, module_name in enumerate(modules_to_show, 1):
            print(f"{i:3d}. {module_name}")
    else:
        print("No modules to display.")

def preloaded(show_builtins=True, show_internal=False, show_submodules=False, as_data=False):
    filtered = []
    
    for m in sorted(_initial_modules):
        if not show_builtins and m in sys.builtin_module_names:
            continue
        if not show_internal and m.startswith('_'):
            continue
        if not show_submodules and '.' in m:
            continue
        if m.startswith('test.'):
            continue
        if m == '__main__':
            continue
        filtered.append(m)
    
    if as_data:
        return filtered
    
    print("Modules pre-loaded by Python before ModX started:")
    if not show_builtins:
        print("(built-in modules hidden)")
    if show_internal:
        print("(internal modules shown)")
    if show_submodules:
        print("(submodules shown)")
    
    for i, name in enumerate(filtered, 1):
        print(f"{i:3d}. {name}")

def whyloaded(module_name, as_data=False):
    '''Returns a comma-separated string explaining why a module is in memory.
Possible tags: not_loaded, preloaded, user, referenced, modx, modx_dep, dependency or unknown.
Note: "User" tag swallows "Referenced" tag.'''
    if module_name not in sys.modules:
        if as_data:
            return ['not_loaded']
        print(f"Load reasons for '{module_name}':")
        print(f"  • not_loaded  (This module is either not loaded or not a module!)")
        return
    
    top = module_name.split('.', 1)[0]
    reasons = []
    
    if top in _import_tracking["preloaded"]:
        reasons.append('preloaded')
    if top in _import_tracking["user_direct"]:
        reasons.append('user')
    elif top in _import_tracking["user_reference"]:
        reasons.append('referenced')
    if top in _import_tracking["modx_direct"] or top in _import_tracking["modx_dep"]:
        if top in _modx_dependencies:  
            reasons.append('modx_dep')
        else:
            reasons.append('modx')
    if top in _import_tracking["dependency"]:
        reasons.append('dependency')
    if top in _import_tracking["unknown"]:
        reasons.append('unknown')
    if not reasons:
        if top in _initial_modules:
            reasons.append('preloaded')
        else:
            reasons.append('unknown')
    
    if as_data:
        return reasons
    
    tag_explanations = {
        'preloaded': 'Started with Python',
        'user': 'Direct import by you',
        'referenced': 'Already in memory when used',
        'modx': 'Imported by ModX',
        'modx_dep': 'Required by ModX itself',
        'dependency': 'Pulled in by another module',
        'unknown': 'Could not determine reason'
    }
    
    if len(reasons) == 1:
        tag = reasons[0]
        explanation = tag_explanations.get(tag, '')
        print(f"Load reasons for '{module_name}':")
        print(f"  • {tag}  ({explanation})")
        return
    
    print(f"Load reasons for '{module_name}':")
    for tag in reasons:
        explanation = tag_explanations.get(tag, '')
        print(f"  • {tag}  ({explanation})")

def timesince(module_name, as_data=False):
    """Show when a module was imported relative to ModX startup."""
    if module_name not in sys.modules:
        if as_data:
            return {'module': module_name, 'loaded': False}
        print(f"Module '{module_name}' not loaded.")
        return
    
    top = module_name.split('.')[0]
    
    if top in _import_timestamps:
        import_time = _import_timestamps[top]
        seconds_after = round(import_time - _modx_start_time, 3)
        dt = datetime.datetime.fromtimestamp(import_time).strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
        
        if as_data:
            return {
                'module': module_name,
                'loaded': True,
                'preloaded': False,
                'timestamp': dt,
                'seconds_after_modx': seconds_after
            }
        
        print(f"Module: {module_name}")
        print(f"Imported at {dt}")
        print(f"{seconds_after} seconds after ModX started.")
        return
    
    else:
        is_dependency = top in _modx_dependencies
        
        if as_data:
            result = {
                'module': module_name,
                'loaded': True,
                'preloaded': True,
                'modx_start_time': _modx_start_datetime
            }
            if is_dependency:
                result['modx_dependency'] = True
            return result
        
        print(f"Module: {module_name}")
        if is_dependency:
            print(f"(ModX dependency - loaded at startup)")
        else:
            print(f"(Preloaded module)")
        print(f"Imported at {_modx_start_datetime}")
        print(f"0.0 seconds after ModX started.")
        return
    
if __name__ == "__main__":
    def test(comprehensive=False):
        """Test all ModX functions with module random.
comprehensive=False: Run quick tests only
comprehensive=True: Run all tests including time-consuming ones
        """
        global _modx_importing
        _modx_importing = False
        import time
        start_time = time.time()
        
        if comprehensive:
            print("ModX Comprehensive Test Suite")
        else:
            print("ModX Test Suite")
        print("=" * 50)
        
        results = {
            "passed": 0,
            "failed": 0,
            "skipped": 0
        }
        
        def _run_test(test_name, test_func, required=True):
            print(f"Testing {test_name}...", end=" ")
            try:
                result = test_func()
                print("PASSED")
                results["passed"] += 1
                return result
            except Exception as e:
                if required:
                    print(f"FAILED: {e}")
                    results["failed"] += 1
                else:
                    print(f"SKIPPED: {e}")
                    results["skipped"] += 1
                return None
        
        print("\nPHASE 1: Module Analysis")
        print("-" * 30)
        
        _run_test("List available modules", lambda: print(f"Available modules: {len(listimportall(as_data = True))}"))
        _run_test("Search modules", lambda: print(f"Found {len(searchmodules('xml', as_data = True))} XML modules"))
        _run_test("Show current module count", lambda: print(f"Currently loaded: {modsloaded()} modules"))
        
        test_module = "random"
        
        _run_test(f"Analyze {test_module} functions", lambda: modfunctions(test_module))
        _run_test(f"Analyze {test_module} classes", lambda: modclasses(test_module))
        _run_test(f"Check {test_module} dependencies", lambda: dependencies(test_module))
        _run_test(f"Get {test_module} info", lambda: info(test_module))
        _run_test(f"Check {test_module} origin", lambda: print(modorigin(test_module)))
        
        print("\nPHASE 2: Selective Imports")
        print("-" * 30)
        
        _run_test("Import by letter 's'", lambda: importletter('s'))
        _run_test("Import 3 random modules", lambda: importrandom(3))
        
        _run_test("Show ModX-imported modules", modximported)

        print("\nPHASE 3: whyloaded() - Why Modules Loaded")
        print("-" * 30)

        _run_test("whyloaded - nonexistent module", 
                 lambda: whyloaded('nonexistent_module_abc123', as_data=True) == ['not_loaded'])

        _run_test("whyloaded - preloaded (sys)", 
                 lambda: 'preloaded' in whyloaded('sys', as_data=True))

        import colorsys
        _run_test("whyloaded - user import", 
                 lambda: whyloaded('colorsys', as_data=True) == ['user'])

        import sys
        _run_test("whyloaded - referenced", 
                 lambda: 'referenced' not in whyloaded('sys', as_data=True))

        importall(show_imported=False)
        _run_test("whyloaded - modx direct", 
                 lambda: ('modx' in whyloaded('base64', as_data=True) and 
                          'modx_dep' not in whyloaded('base64', as_data=True)))

        _run_test("whyloaded - modx dependency", 
                 lambda: 'modx_dep' in whyloaded('math', as_data=True))

        sys.modules['fake_test'] = type(sys)('fake_test')
        _why_unknown.add('fake_test')
        _run_test("whyloaded - unknown/dependency fallback", 
                 lambda: 'unknown' in whyloaded('fake_test', as_data=True))
        del sys.modules['fake_test']
        _why_unknown.discard('fake_test')

        _run_test("whyloaded - docstring", 
                 lambda: whyloaded.__doc__ is not None and len(whyloaded.__doc__) > 50)
        
        print("\nPHASE 4: Advanced Features")
        print("-" * 30)
        
        _run_test(f"Check {test_module} compatibility", lambda: vcompat(test_module, "3.8"))
        _run_test(f"Benchmark {test_module}", lambda: print(modbench(test_module)))
        
        _run_test("Check import status", lambda: print(f"random imported: {isimported('random')}"))
        _run_test("Check non-imported status", lambda: print(f"nonexistent: {isimported('nonexistent_module_xyz')}"))
        
        print("\nPHASE 5: Help and Utilities")
        print("-" * 30)
        
        _run_test("Show compact help", lambda: modxhelp(compact=True, banner=False))
        _run_test("Show module globals", lambda: modglobals('random', show_private=False))
        
        _run_test("Import log (without dependencies)", lambda: importlog(include_deps=False))
        _run_test("Show pre-loaded modules", lambda: preloaded())
        
        _run_test("Check reverse dependencies", lambda: revdeps('random'), required=False)
        
        non_imported = nonimported(as_data = True)
        _run_test("List non-imported modules", lambda: print(f"Non-imported modules: {len(non_imported)}"))
        
        if comprehensive:
            print("\nPHASE 5: Comprehensive Tests")
            print("-" * 30)
            
            test_modules = ["sys", "json", "random"]
            for module in test_modules:
                _run_test(f"Analyze {module}", lambda m=module: modfunctions(m), required=False)
            
            _run_test("Import by letter 't'", lambda: importletter('t'))
            _run_test("Import 5 random modules", lambda: importrandom(5))
            
            _run_test("Import log (with dependencies)", lambda: importlog(include_deps=True))
            _run_test("Show all pre-loaded modules", lambda: preloaded(show_internal=True, show_submodules=True))
            
            _run_test("Import external modules", importexternal, required=False)
            
            _run_test("Import screen modules", importscreen, required=False)
            
            _run_test("Full compatibility sweep", lambda: vcompat('random'))
            _run_test("Multiple benchmarks", lambda: [print(modbench(m)) for m in ['sys', 'json', 'random']])
            
            _run_test("Full help system", lambda: modxhelp(banner=False))
        print("\nPHASE 6: timesince() - When Modules Loaded")
        print("-" * 30)
        _modx_importing = False
        
        _run_test("timesince - nonexistent module", 
                 lambda: timesince('nonexistent_module_abc123', as_data=True) == 
                         {'module': 'nonexistent_module_abc123', 'loaded': False})
        
        _run_test("timesince - preloaded module (abc)", 
                 lambda: (timesince('abc', as_data=True).get('preloaded') == True and
                          timesince('abc', as_data=True).get('modx_dependency') != True))
        
        _run_test("timesince - ModX dependency (sys)", 
                 lambda: (timesince('sys', as_data=True).get('preloaded') == True and
                          timesince('sys', as_data=True).get('modx_dependency') == True))
        
        import colorsys
        _run_test("timesince - user imported module", 
                 lambda: (timesince('colorsys', as_data=True).get('preloaded') == False and
                          timesince('colorsys', as_data=True).get('seconds_after_modx', 0) > 0))
        
        _run_test("timesince - as_data False doesn't crash", 
                 lambda: timesince('sys') is None)  # Returns None after printing
        
        _run_test("timesince - docstring exists", 
                 lambda: timesince.__doc__ is not None and len(timesince.__doc__) > 50)
        
        print("\n" + "=" * 50)
        if comprehensive:
            print("COMPREHENSIVE TEST RESULTS")
        else:
            print("TEST RESULTS SUMMARY")
        print(f"Total tests: {sum(results.values())}")
        print(f"Passed: {results['passed']}")
        print(f"Failed: {results['failed']}")
        print(f"Skipped: {results['skipped']}")
        
        elapsed_time = time.time() - start_time
        print(f"Total time: {elapsed_time:.2f} seconds")
        
        return results['failed'] == 0
    
    test()
