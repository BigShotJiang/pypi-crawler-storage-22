### **🌟 ModXPy — The Python Module Universe at Your Fingertips**



Welcome to ModXPy, the ultimate playground for Python’s modules.  
With ModXPy you can instantly import, explore, and experiment with the entire Python standard library — plus any installed third-party modules — all from one simple interface.



#### UPDATE 2.5.2



###### MAINTENANCE \& QOL UPDATE!



Even better test suite is now 99% automatic!

New function parameter automatic generating!



Bonus: The test suite now completely isolates itself, minimizing corruption!



And a whole bunch of other module / code polishes too!



#### 🚀 Installation and Importing



IMPORTANT: Before you install ModX, you MUST first (if not already) run "pip install packaging" inside of powershell/terminal. ModX will NOT work without the packaging module.

Install directly from terminal.

Type: "pip install modxpy"



In Python, import as import modx (not modxpy)



#### Functions:



🔹 dependencies(module, as\_data=False)

Shows what other modules a specific module depends on without importing it.



🔹 importall(show\_imported=False, as\_data=False)

Imports about every standard library module at once.



🔹 importexternal(show\_imported=False, as\_data=False)

Attempts to import every third-party module you currently have installed.



🔹 importletter(letter, show\_imported=False, as\_data=False)

Imports all standard library modules whose names start with the given letter (case-insensitive).



🔹 importlog(include\_deps=False, as\_data=False)

Shows every module imported since ModX loaded in CHRONOLOGICAL order.

include\_deps=True: Includes ModX's dependencies in the list.



🔹 importrandom(n, strict\_mode=False, show\_imported=False, as\_data=False)

Imports n random stdlib modules.

strict\_mode=False: May import less than n due to dependencies.

strict\_mode=True: Forces import until EXACTLY n NEW modules.



🔹 importscreen(show\_imported=False, as\_data=False)

Imports every module that uses a screen/GUI (like pygame or turtle).



🔹 info(module\_name, as\_data=False)

Shows basic info about a module: file path, built-in status, full docstring.



🔹 isimported(module)

Checks if a module is currently imported into the Python shell (not just sys.modules).



🔹 listimportall(as\_data=False)

Returns a list of modules that import\_all() would import.



🔹 modbench(module, as\_data=False)

Shows how much time and memory a module takes to import.

Note: The module IS imported, and cache is cleared before each benchmark.



🔹 modclasses(module, as\_data=False)

Shows how many and what classes a module has WITHOUT importing it.



🔹 modfunctions(module, as\_data=False)

Shows how many and what functions a module has WITHOUT importing it.



🔹 modglobals(module, show\_private=False, export=None, as\_data=False)

Shows a module's global names (not functions/classes/modules).

show\_private=True: Includes names starting with '\_'.

export=filename.md: Exports results as Markdown.



🔹 modorigin(module, as\_data=False)

Shows where a module came from (e.g., built-in, standard library, or pip-installed).



🔹 modsloaded()

Shows how many modules are currently loaded in your Python session.



🔹 modxhelp(export=None, compact=False, banner=True)

Shows ModX's built-in help dialogue.

export=filename.md: Exports help as Markdown.

compact=True: Shows single-line summaries only.

banner=False: Hides the ASCII banner.



🔹 modximported(as\_data=False)

Lists modules that were ONLY imported by ModX — NOT including user imports or dependencies.



🔹 nonimported(as\_data=False)

Returns a list of STANDARD LIBRARY modules that have NOT been imported yet.



🔹 preloaded(show\_builtins=True, show\_internal=False, show\_submodules=False, as\_data=False)

Shows modules pre-loaded by Python before ModX started.

show\_builtins=False: Hides built-in modules.

show\_internal=True: Shows modules starting with '\_'.

show\_submodules=True: Includes submodules (names with '.').



🔹 revdeps(module, as\_data=False)

Shows what modules import the given module WITHOUT importing it.



🔹 searchmodules(keyword, as\_data=False)

Searches for modules whose names contain the keyword.



🔹 timesince(module, as\_data = False)

Shows WHEN a module was loaded in relative to when ModX loaded.



🔹 vcompat(module\_name, python\_version=None, as\_data=False)

Checks if a module is compatible with a given Python version.

If no version is given, sweeps ALL Python versions 2.0–3.14.



🔹 whyloaded(module, as\_data=False)

Returns a comma-separated string explaining why a module is in memory.

Tags: not\_loaded, preloaded, user, referenced, modx, modx\_dep, dependency or unknown

Rule: user swallows referenced.



#### 💡 Why Use ModX?



1.) Understand your imports

    Know why a module was loaded (whyloaded()), when it appeared (timesince()), and where             it came from (modorigin()).



2.) Get real data, not just printed tables

    Every function has as\_data mode — return clean Python lists/dicts for your own code.



3.) Stress-test your environment

    Bulk-import hundreds of modules at once with importall() and see what breaks.



4.) Discover hidden dependencies

    See what your imports actually depend on with dependencies() and revdeps().



5.) Experiment and learn

    Random imports, compatibility checking, performance benchmarking — turn Python into a playground.



6.) Track everything

    Chronological import logs, preloaded module lists, timestamp tracking — nothing stays hidden.



ModXPy turns Python’s module system into a playground —
perfect for learning, testing, or just satisfying your curiosity.
Install it today with pip install modxpy, import it with import modx,
and start discovering how many modules Python already has waiting for you!

