﻿<p align="center">
  <img src="https://raw.githubusercontent.com/aethryva/MOISSCode/main/assets/moisscode_logo.png" alt="MOISSCode" width="360" />
  <br/>
  <strong>Multi Organ Intervention State Space Code</strong>
  <br/>
  <a href="https://github.com/aethryva/MOISSCode/actions/workflows/tests.yml"><img src="https://github.com/aethryva/MOISSCode/actions/workflows/tests.yml/badge.svg?branch=main" alt="Tests" /></a>
  <img src="https://img.shields.io/badge/python-3.10%2B-blue?logo=python&logoColor=white" alt="Python 3.10+" />
  <img src="https://img.shields.io/badge/license-BSL%201.1-green" alt="BSL 1.1" />
  <img src="https://img.shields.io/badge/version-3.0.1-red" alt="v3.0.1" />

  <p align="center">A domain-specific language for clinical decision support and biotech workflow automation.</p>
  <p align="center">
    <a href="#installation">Install</a> · <a href="#quick-start">Quick Start</a> · <a href="#library-reference">Library</a> · <a href="#cli">CLI</a> · <a href="docs/MOISSCode_Manual.md">Full Manual</a>
  </p>
</p>

> **⚠️ RESEARCH USE ONLY** <br> MOISSCode is a research prototype. It is **NOT** approved by FDA, CDSCO, or any regulatory body for clinical decision-making. Do not use MOISSCode output to make real patient care decisions. Aethryva Deeptech accepts no liability for clinical outcomes.

---

## What is MOISSCode?

MOISSCode is a **domain-specific language** designed for medical professionals and biotech engineers. Write clinical protocols in English-like syntax and let the engine handle scoring, drug classification, billing, lab interpretation, FHIR interoperability, and more.

```
protocol SepsisScreen {
    input: Patient p;

    let score = med.scores.qsofa(p);
    track p.lactate using KAE;

    if score >= 2 {
        administer Norepinephrine dose: 0.1 mcg/kg/min;
        alert "Sepsis detected!" severity: critical;
    }

    assess p for sepsis;
}
```

## Installation

**Requires:** Python 3.10+

```bash
git clone https://github.com/aethryva/MOISSCode.git
cd MOISSCode
```

**Windows (PowerShell):**
```powershell
py -m pip install -e .
```

**macOS / Linux:**
```bash
pip install -e .
```

## Quick Start

### Run a protocol file

```bash
moiss run examples/sepsis_workup.moiss -v
```

### Validate syntax without executing

```bash
moiss validate examples/sepsis_workup.moiss
```

### Interactive REPL

```bash
moiss repl
```

### Embed in Python

```python
from moisscode import MOISSCodeLexer, MOISSCodeParser, MOISSCodeInterpreter, Patient

code = """
protocol QuickCheck {
    input: Patient p;
    let score = med.scores.qsofa(p);
    if score >= 2 {
        alert "High risk" severity: critical;
    }
}
"""

lexer = MOISSCodeLexer()
tokens = lexer.tokenize(code)
parser = MOISSCodeParser(tokens)
program = parser.parse_program()

interp = MOISSCodeInterpreter()
interp.scope['p'] = {
    'type': 'Patient',
    'value': Patient(bp=85, hr=110, rr=24, temp=38.5, spo2=94,
                     weight=70, age=55, gcs=14, lactate=3.2, sex='M')
}

events = interp.execute(program)
for e in events:
    print(e)
```

## Library Reference

MOISSCode ships with **20 built-in modules**, all accessible via the `med.` prefix:

| Module | Description |
|---|---|
| `med.scores` | 12 validated clinical scores (qSOFA, SOFA, NEWS2, MELD-Na, CHA2DS2-VASc, HEART, Framingham, Child-Pugh, CURB-65, Wells PE, Glasgow-Blatchford, KDIGO AKI) |
| `med.pk` | Pharmacokinetic engine (100+ drugs, dosing, interactions, TDM, renal/hepatic adjustment) |
| `med.lab` | Lab panels (80+ tests, 15 panels, reference ranges, eGFR via CKD-EPI 2021) |
| `med.micro` | Microbiology (30 organisms, MIC breakpoints, 15 empiric therapy protocols) |
| `med.genomics` | Pharmacogenomics (8 CYP450 genes, 20 CPIC/DPWG guidelines) |
| `med.biochem` | Enzyme kinetics (25 enzymes), 8 metabolic pathways |
| `med.epi` | Epidemiology (SIR/SEIR models, R0, herd immunity) |
| `med.nutrition` | Clinical nutrition (BMI, BEE, TPN, IV fluids) |
| `med.fhir` | FHIR R4 bridge (Patient, Bundle, MedicationRequest) |
| `med.db` | SQLite persistence (patients, audit trail, alerts) |
| `med.io` | Device management (infusion pumps, monitors, ventilators, waveforms, alarms) |
| `med.finance` | CPT billing (38 codes) and cost tracking |
| `med.research` | De-identification, consent, randomization, sample size, stratification |
| `med.glucose` | Diabetes management (HbA1c, CGM analytics, insulin dosing, DKA, hypoglycemia) |
| `med.chem` | Medicinal chemistry (40 compounds, Lipinski, BCS, ADMET, toxicity screening) |
| `med.signal` | Biosignal processing (ECG peaks, HRV, SpO2, rhythm classification) |
| `med.icd` | Medical coding (94 ICD-10-CM codes, 25 DRG groups, SNOMED CT mapping) |
| `med.papers` | Scientific paper generation (LaTeX/PDF in IEEE, medRxiv, bioRxiv, JAMA, Nature, Lancet, PLOS) |
| `med.kae` | Kalman-Autoencoder state estimator for real-time vital sign tracking |
| `med.moiss` | MOISS intervention timing classifier (prophylactic to too-late) |

## CLI

```
moiss run <file.moiss> [-v]    Execute a protocol
moiss validate <file.moiss>    Parse-only validation
moiss repl                     Interactive shell
moiss version                  Print version
```

## Language Features

- **Protocols** - `protocol Name { ... }`
- **Patient input** - `input: Patient p;`
- **Variables** - `let x = expression;`
- **Conditionals** - `if condition { ... } else { ... }`
- **Loops** - `while condition { ... }` and `for item in list { ... }`
- **Custom types** - `type Bacteria { name: str; mic: float; }`
- **Functions** - `function calc(a, b) { return a + b; }`
- **Lists** - `let drugs = ["A", "B", "C"];`
- **Alerts** - `alert "message" severity: critical;`
- **Assessments** - `assess p for sepsis;`
- **Drug admin** - `administer Drug dose: 0.1 mcg/kg/min;`
- **Tracking** - `track p.lactate using KAE;`

## Project Structure

```
moisscode/
├── __init__.py       # Public API
├── cli.py            # CLI tool
├── lexer.py          # Tokenizer
├── parser.py         # AST parser
├── ast_nodes.py      # AST definitions
├── interpreter.py    # Runtime engine
├── typesystem.py     # Type checking + Patient
├── stdlib.py         # 20-module library
└── modules/          # Domain modules (med.*)
```

## API Server

MOISSCode includes a REST API service for remote protocol execution.

**Windows (PowerShell):**
```powershell
py -m pip install -e ".[api]"
py -m uvicorn moisscode.api.server:app --reload
```

**macOS / Linux:**
```bash
pip install -e ".[api]"
uvicorn moisscode.api.server:app --reload
```

See the `moisscode/api/` directory for full API documentation and configuration.

## Citation

If you use MOISSCode in research, please cite:

**MOISS Framework:**
> Kunche, N. (2026). *Multi-Organ Intervention State Space (MOISS): A Collision Geometry Framework for Quantifying Therapeutic Windows Across 10 Organ Systems in 301,470 ICU Patients.* medRxiv.
> [https://www.medrxiv.org/content/10.64898/2026.02.08.26345873v1](https://www.medrxiv.org/content/10.64898/2026.02.08.26345873v1)

**KAE Algorithm:**
> Kunche, N. (2025). *The Kunche Adaptive Estimator: A Reliability-Adaptive Kalman Filtering Framework for Autonomous Multi-Biomarker State Estimation in Critical Care Monitoring.* Authorea.
> [https://doi.org/10.22541/au.176313985.55971071/v1](https://doi.org/10.22541/au.176313985.55971071/v1)

## Contact

- **Email:** [dev@aethryva.com](mailto:dev@aethryva.com)
- **Feature requests and bugs:** [GitHub Issues](https://github.com/aethryva/MOISSCode/issues)
- **Creator:** [Nikhil Kunche](https://www.linkedin.com/in/nikhilkunche/)
- **Documentation:** [moisscode.com](https://moisscode.com)

## License

BSL 1.1 - See [LICENSE](LICENSE) for details.
