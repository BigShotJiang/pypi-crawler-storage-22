# Mojito

A simple CLI tool that prints a wine emoji 🍷.

## Installation

You can install `mojito` from PyPI:

```bash
pip install mojito-cli
```

## Usage

Once installed, simply run:

```bash
mojito
```

And it will print:

```
🍷
```

## Development

To install locally for development:

```bash
pip install -e .
```
