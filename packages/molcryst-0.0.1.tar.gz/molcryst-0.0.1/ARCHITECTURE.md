# Architecture (initial)

This is an initial, v0.1-aligned package layout. The goal is to keep the public
API small and stable while allowing internal refactors during 0.0.x.

Proposed layout (to be finalized before heavy implementation):

- `molcryst.types`
  - Small scalar/value types (FracQ, SymOp, SymTag, Cell, etc.)
- `molcryst.records`
  - Raw imported records (atoms, bonds, etc.) and parsing reports
- `molcryst.entities`
  - Canonical reference-cell entities and canonicalization policies
- `molcryst.instances`
  - Lightweight wrappers providing (entity, symtag) views
- `molcryst.symmetry`
  - SymOp parsing, dedup policies, SymmetryIndex (image table)
- `molcryst.graph`
  - Derived graphs, orbit/unique-edge policies, pbcgraph interop boundary
- `molcryst.bonds`
  - Bond reconstruction helpers and chemistry/radii data
- `molcryst.render`
  - Label rendering and user-facing display helpers (view layer)

For 0.0.1 we only ship packaging + docs + planning artifacts.
