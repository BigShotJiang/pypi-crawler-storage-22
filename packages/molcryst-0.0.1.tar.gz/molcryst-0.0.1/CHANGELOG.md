# Changelog

All notable changes to this project will be documented in this file.

The format is based on Keep a Changelog, and this project adheres to Semantic Versioning.

## 0.0.1 - 01-February-2026

- Initial repository scaffold (src-layout packaging, project metadata, and version-from-code).
- Documentation skeleton (MkDocs config with placeholders for API and developer docs).
- Testing template (pytest baseline) and CI workflows for linting, tests, and docs builds.
- Optional GitHub Pages deployment workflow (deploy gated by DOCS_DEPLOY repository variable).
- Added initial project notices and development planning documents.
