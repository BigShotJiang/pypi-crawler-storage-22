# Development plan for v0.1

This plan translates `docs/dev/specs/molcryst_specs_v0.1.md` into a concrete,
incremental implementation order. Each step is intended to be small, testable,
and reviewable (roughly "one PR == one milestone").

Guiding constraints:

- Simplicity is almost as important as correctness.
- v0.1 uses explicit, narrow contracts (hard-fail on contract violations).
- Prefer exact / rational-friendly handling where required by specs (FracQ, SymOp).
- No "smart guessing" about impossible or underspecified scenarios.

Implementation conventions:

- Keep the public API minimal in v0.x; expose only what is required for tests and
  for downstream use by molcryst itself.
- Put heavy logic behind small, well-named pure functions wherever possible.
- Prefer deterministic iteration order everywhere (sorting, stable tie-breaks).

---

## Milestone 0: Repo baseline and CI

Goal: ensure every later PR is automatically validated.

Deliverables:

- GitHub Actions:
  - tests: `pytest`
  - lint: `flake8`
  - docs: `mkdocs build --strict`
- Packaging metadata:
  - ensure `LICENSE` and `COPYING` are included in sdists
  - add minimal `[project.urls]` (at least a stable homepage)

Tests:

- Keep `tests/test_smoke.py` (import + version) as a sanity check.

---

## Milestone 1: Core scalar types (FracQ)

Spec refs: 2, 6.1

Goal: define all integer primitives used everywhere else.

Deliverables:

- `molcryst/types/fracq.py`
  - integer helpers: `floor_div`, `mod_q`, `round_half_away_from_zero`
  - `round_div`, `min_image` (per specs)
  - type aliases / small containers:
    - `Int3` (3-tuple of ints)
    - `FracQ` (int coordinates in units of 1/Q)
    - `FracQI` (int coordinates in units of 1/Q with a Z-shift)
- `molcryst/types/__init__.py` (internal exports only)

Tests:

- Negative handling and tie-breaking rules.
- `mod_q` range invariants (always in `[0, Q)`).
- `min_image` invariants and idempotence.

---

## Milestone 2: Unit cell object and frac<->cart conversions

Spec refs: 2.1, 6.1, 7.5

Goal: robust metric and coordinate conversion layer.

Deliverables:

- `molcryst/types/cell.py`
  - `Cell.from_params(a, b, c, alpha, beta, gamma)`
  - `frac_to_cart`, `cart_to_frac`
  - cached matrices and volume (minimal set)

Dependencies:

- Add `numpy` (needed for stable matrix ops).

Tests:

- Roundtrip conversion (frac -> cart -> frac) for simple cells.
- Known orthorhombic sanity cases.

---

## Milestone 3: SymOp (exact affine operator) and XYZ parsing

Spec refs: 3.2, 3.3, 6.2

Goal: represent symmetry operators as exact affine transforms in fractional space.

Deliverables:

- `molcryst/symmetry/symop.py`
  - `SymOp(R, t_q, source_str=None, file_id=None)`
  - `apply_q(...)`, `compose(...)`, `inv(...)`
  - `as_xyz(...)` (canonical string form for debugging and reports)
- `molcryst/symmetry/parse_xyz.py`
  - strict grammar per specs:
    - 3 comma-separated expressions
    - variables only `x,y,z`
    - coefficients restricted to `{-1,0,1}`
    - constant translation term as integer or `p/q`
    - no parentheses
    - parse failure is a hard error
- `molcryst/symmetry/__init__.py` (internal exports only)

Tests:

- Parsing extracts correct `R` and `t_q`.
- `compose` and `inv` are consistent (op * inv(op) == identity).
- `as_xyz` stability for equivalent forms.

---

## Milestone 4: SymOp deduplication and canonical IDs

Spec refs: 1.3, 3.3

Goal: stable mapping between file symops and canonical unique symops.

Deliverables:

- `molcryst/symmetry/dedup.py`
  - `dedup_symops(...)` that returns:
    - `symops_all` (file order)
    - `symops_unique` (deduped canonical list)
    - `file_id_to_canon_id`
    - `preferred_file_id` for each canon op (default: first seen)
  - dedup key uses `(R, t mod Q)` (exact)
- Documented policy hook (future): alternative canonical ordering; v0.1 keeps
  "preserve file order" for round-trip stability.

Tests:

- Dedup stability under repeated operators.
- Identity-only P1 edge case.

---

## Milestone 5: Structure settings and Q derivation

Spec refs: 2.2

Goal: derive Q deterministically from symops and coordinate strings.

Deliverables:

- `molcryst/settings.py`
  - `StructureSettings(...)` with:
    - `fracq_Q` (optional override)
    - `dedup_tol_cart` (for Cartesian dedup)
    - `Q_max` (guardrail)
  - `derive_Q(...)` per specs:
    - `Q % D_sym == 0`
    - ensure `Q_tol` implied by tolerance in Cartesian space
    - hard-fail if derived Q exceeds guardrail

Tests:

- Derived `Q` respects `D_sym`.
- `Q` behavior for common denominators in symops and coordinates.

---

## Milestone 6: Records layer and load report

Spec refs: 0.1, 4.1

Goal: represent raw input rows separately from canonical entities.

Deliverables:

- `molcryst/records/atom.py` (`AtomRecord`)
- `molcryst/records/bond.py` (`BondRecord`)
- `molcryst/records/report.py`
  - `ParseReport` and issue types
  - strict/default policy behavior

Tests:

- Hard requirements missing -> fail (strict).
- Soft requirements missing -> generate defaults (default mode).

---

## Milestone 7: Atom entities (reference cell) via candidate generation and clustering

Spec refs: 4.2, 5

Goal: build canonical reference-cell atoms (P1, wrapped to `[0,1)^3`).

Deliverables:

- `molcryst/entities/atom.py`
  - `Atom` entity object
  - provenance container for candidate origin
- `molcryst/entities/cluster.py`
  - candidate generation:
    - for each `AtomRecord` x each `SymOpUnique` -> `(y_ref_q, symtag_ref, provenance)`
  - clustering:
    - pre-partition by stable key (element/disorder/occupancy policy)
    - merge by Cartesian min-image distance <= `dedup_tol_cart`
- Add spatial acceleration if needed (later): `scipy.spatial.cKDTree`

Tests:

- Deterministic clustering (independent of record order).
- Special-position behavior: multiple symops may land on same atom.

---

## Milestone 8: Atom instances and SymTag normalization

Spec refs: 3.4, 6.2, 6.3

Goal: define infinite-crystal addressing and instance coordinates.

Deliverables:

- `molcryst/instances/atom.py` (`AtomInstance`)
- `molcryst/symmetry/symtag.py`
  - `SymTag(canon_id, shift)`
  - normalization rules
- `AtomInstance.frac_qi` computed as:
  - `R * x_q + t_q + shift * Q` (exact integer arithmetic)

Tests:

- SymTag normalization is idempotent.
- Exact consistency with the spec formula.

---

## Milestone 9: SymmetryIndex / AtomImageTable

Spec refs: 7

Goal: fast, deterministic mapping of images and relative operators.

Deliverables:

- `molcryst/symmetry/index.py`
  - mapping `(atom_id, symtag) -> (atom_id', symtag')`
  - caching keyed by settings / structure id
  - minimal API used by orbits and graph conversion

Tests:

- Small synthetic groups: closure and inverse behavior.
- Applying op then inverse returns identity mapping.

---

## Milestone 10: Graph boundary and pbcgraph interop

Spec refs: 8

Goal: formalize conversion to periodic graphs (translation-labeled edges).

Deliverables:

- `molcryst/graph/interop_pbcgraph.py`
  - convert entity/instance bonds into periodic edges with integer `tvec`
  - keep the boundary narrow and explicit

Tests:

- Deterministic conversion for toy structures.
- Undirected semantics policy is consistent.

---

## Milestone 11: Bond reconstruction (v0.1)

Spec refs: 7.5, 9 (as applicable)

Goal: infer bonds when missing, using radii + neighbor search.

Deliverables:

- `molcryst/bonds/radii.py` (lookup table)
- `molcryst/bonds/reconstruct.py`
  - neighbor search (KDTree or grid)
  - bond typing policy hooks (minimal in v0.1)

Tests:

- Cross-boundary bonds (unit cell edges).
- Deterministic results given same settings.

---

## Milestone 12: Symmetry orbits of bonds / unique edges

Spec refs: 8.4, 10

Goal: compute orbits under symmetry action and pick representatives.

Deliverables:

- `molcryst/graph/orbits.py`
  - orbit partitioning using `SymmetryIndex`
  - representative selection policy (deterministic)

Tests:

- Orbit multiplicities on toy examples.
- Representative stability under input ordering.
