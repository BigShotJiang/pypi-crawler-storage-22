# molcryst

molcryst is a Python library for working with molecular crystal structures and
periodic-compound representations (v0.1 pre-alpha series).

Copyright (c) 2026 Ivan Chernyshov
License: LGPL-3.0-or-later (see LICENSE and COPYING)

## Third-party software

molcryst may use the following third-party dependencies:

- gemmi — dual-licensed MPL-2.0 or LGPL-3.0-or-later (we choose LGPL-3.0-or-later)
- pbcgraph — LGPL-3.0-or-later
- pyvoro2 — MIT (includes a copy of Voro++ and its license text in the pyvoro2 source distribution)

### Redistribution note

When installed via pip, these dependencies are typically obtained and distributed
separately from molcryst.

If molcryst is redistributed together with third-party dependencies (for example,
as an offline bundle of multiple source distributions or wheels), the license
texts for those dependencies remain part of their respective distributions.

If molcryst is redistributed in a way that bundles or vendors third-party code or
binaries into a single combined distribution, the corresponding license texts and
notices will be included with that distribution.
