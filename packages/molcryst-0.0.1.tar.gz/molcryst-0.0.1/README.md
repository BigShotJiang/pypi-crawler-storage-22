# molcryst

[![PyPI](https://img.shields.io/pypi/v/molcryst.svg)](https://pypi.org/project/molcryst/)
[![Python versions](https://img.shields.io/pypi/pyversions/molcryst.svg)](https://pypi.org/project/molcryst/)
[![License: LGPL v3](https://img.shields.io/badge/license-LGPLv3-blue.svg)](https://www.gnu.org/licenses/lgpl-3.0)

molcryst is a Python package for representing and analyzing molecular crystals,
with an emphasis on a clear crystal object model (COM) and exact, reproducible
symmetry handling.

This repository currently contains a **0.0.1 pre-alpha scaffold**:
packaging, docs skeleton, and a development plan that translates the v0.1 specs
into an implementation order.

## Status

- Development status: pre-alpha (0.0.x)
- Target: 0.1.0 implements the v0.1 spec subset

## Install (editable, for development)

```bash
python -m pip install -U pip
pip install -e ".[test,docs,dev]"
```

## Run tests

```bash
pytest
```

## Build docs locally

```bash
mkdocs serve
```
