{%
  include-markdown "../../ARCHITECTURE.md"
%}
