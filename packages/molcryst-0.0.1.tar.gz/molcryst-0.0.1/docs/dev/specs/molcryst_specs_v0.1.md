# molcryst COM + Symmetry Specs (Draft v0.1)

This document captures the current Crystal Object Model (COM) and symmetry conventions
agreed in discussion. It is intentionally implementation-neutral: **no code**, only
contracts, invariants, and policies.

## 0. Goals and scope

Primary goals:

- Represent periodic crystal structures with a clear separation of:
  - **raw input** (CIF/import rows),
  - **canonical reference-cell entities** (P1, wrapped to `[0,1)^3`),
  - **instances** (placed occurrences in the infinite crystal).
- Provide deterministic, inspectable symmetry addressing:
  - **SymOp**: exact affine operators in fractional space,
  - **SymTag**: `(canon_id, integer_shift)` addressing of instances.
- Make labeling and CIF-like operator codes a **view layer**:
  - labels never define identity; they are derived from records + SymTags.

Non-goals (v0):

- Full disorder model (altloc, partial occupancy) beyond minimal bookkeeping.
- Full symmetry-element analysis (axes/planes classification). Operators are returned,
  and element interpretation can be added later.
- Fully standardized "canonical symmetry op order" matching a specific ecosystem
  (CCDC/Mercury/Gemmi/etc.). We preserve file order for round-trip and optionally
  provide an element-based canonicalization policy.

## 0.1 Input contract (CIF/import)

### Hard requirements (load must fail if missing)

- Unit cell parameters sufficient to build the metric (a, b, c, alpha, beta, gamma).
- Atomic site fractional coordinates (x, y, z) for each atom record.
- Symmetry operations **must** be provided (explicit symop loop), unless the space
  group is P1 (identity-only allowed).

Rationale: inferring symmetry operators from space-group metadata can be ambiguous
(settings/origin choices). v0 avoids this by requiring explicit symops unless P1.

### Soft requirements (best effort; never hard fail in default mode)

- Atom labels: if missing/blank, generate deterministic labels (see 4.1).
- Element/type symbol: if missing or invalid, keep the atom with `element=None` and
  warn (see 4.1); chemistry-based builders may skip unknown elements.
- Bonds/contacts loops: parsed as **records** when present; connectivity is built by
  an explicit policy (v0 can be "from_records", later "infer_by_radii", etc.).

### Parse report and strict mode

Parsing produces a `ParseReport` with issues:

- ERROR: hard requirement violations (stop).
- WARN: unresolved references, invalid element symbols, duplicate labels, etc.
- INFO: unsupported fields/loops ignored.

`strict=True` may upgrade selected WARN to ERROR (useful for curated datasets/tests).

---

## 1. Terminology

### 1.1 Records vs entities vs instances

- **Record**: raw input row from CIF/import. May be redundant or inconsistent.
- **Entity**: canonical object in the **reference unit cell** (P1), used by algorithms
  and graphs.
- **Instance**: a placed occurrence of an entity in the infinite crystal, addressed
  by a SymTag.

### 1.2 Reference cell

The **reference cell** is the fractional cube `[0,1)^3`. Entity coordinates are
wrapped into this cell.

### 1.3 Symmetry tag

- **SymTag**: `(canon_id: int, shift: Int3)`
  - `canon_id` indexes `Structure.symops_unique` (the value-deduplicated canonical symop list).
  - `shift` is an integer lattice translation applied **after** the symmetry op.

Notes:

- `file_id` ordering is preserved separately for round-trip and rendering:
  - `preferred_file_id[canon_id] -> int | None` (None if the symop was inserted implicitly, e.g. identity).
- All symmetry computations (relative ops, SymmetryIndex, orbit action) use `canon_id` symops.


---

## 2. Core scalar types

- `Int3`: tuple[int, int, int]
- `Tvec`: same as `Int3`, used as translation label on periodic edges.

### 2.1 Fractional coordinate keys (FracQ)

molcryst uses an integer fixed-point grid for all **discrete** symmetry logic.

- `FracQI`: tuple[int, int, int], integer fractional coordinates in units of `1/Q`, **not reduced**.
  - May lie outside the reference cell range.
  - Used during SymOp application and intermediate computations.

- `FracQ`: tuple[int, int, int], **reference-cell reduced** fractional coordinate key on the same grid.
  - Each component is stored in `[0, Q)`.
  - Used for hashing/indexing, coordinate->AtomId mapping, and SymmetryIndex tables.

- `Frac3`: tuple[float, float, float], a **float view** of a `FracQ` / `FracQI` coordinate.
  - Used only for geometric computations (cell transforms, KDTree neighbor searches, distances).
  - Never used directly for discrete `floor`/`round`, equality, hashing, or orbit mapping.

- `Cart3`: tuple[float, float, float] (Angstrom)

Discrete logic contract:

- All wrap/floor/round, hashing, equality, and symmetry-orbit mapping are performed in integer
  `FracQ/FracQI` space.

Integer primitives (v0.1 required; exact semantics):

- `floor_div(n, Q)`: integer floor division `⌊n / Q⌋` for `n: int`, `Q > 0`.
  - In Python terms, this is `n // Q` (floor toward `-∞`), including for negative `n`.
- `mod_q(n, Q)`: reference-cell reduction `n - Q * floor_div(n, Q)`, yielding a value in `[0, Q)`.
- `round_half_away_from_zero(x)`: deterministic tie rule for real `x`:
  - returns `sign(x) * floor(|x| + 0.5)`.
  - ties at exactly `.5` go to larger magnitude (e.g., `0.5 -> 1`, `-0.5 -> -1`).
- `round_div(n, Q)`: integer rounding of `n / Q` using the same tie rule:
  - `round_div(n, Q) = round_half_away_from_zero(n / Q)`.
- `min_image(n, Q)`: minimum-image reduction used for distance computations in `FracQ` space:
  - `n_mi = n - Q * round_div(n, Q)` so that `n_mi` lies in `(-Q/2, Q/2]` under the half-away-from-zero tie rule.

These primitives are used instead of language/library defaults (`round`, `%` on floats, etc.) to keep
negative handling and tie-breaking fully deterministic.

### 2.2 Choosing the FracQ modulus Q (required policy)

`Q` is a settings-level value (`StructureSettings.fracq_Q`). v0.1 requires a deterministic default
derivation rule, because `Q` must be compatible with exact SymOp translations and sufficiently fine
to make quantizationtion error negligible relative to `dedup_tol_cart`.

Important principle (v0.1):

- Decimal coordinate strings in CIF are treated as *rounded measurements*, not exact structure facts.
  The default `Q` derivation ignores decimal-string denominators and is driven by symmetry and tolerance.

Definitions:

- `D_sym`: least common multiple (LCM) of denominators appearing in all SymOp translation components
  as parsed from CIF (typical denominators: 2, 3, 4, 6).
- `D_frac`: LCM of denominators from atom-site coordinate strings that are explicit fractions `p/q`
  (optional; decimals do not contribute).
- `L_cell`: `max_i ||A @ e_i||` for `i=0,1,2` (maximum length of fractional basis vectors in Cartesian space).
- `c_grid`: safety factor linking the grid step to clustering tolerance (v0.1 default `c_grid = 10`).

v0.1 defaults:

- `Q_max = 10^10` (guardrail for auto-derivation only; user may set larger `Q` explicitly)
- `c_grid = 10`

Quantization policy:

- CIF fractional coordinate strings are parsed deterministically (e.g., via `Decimal` / fraction parser)
  to a real number `x` and mapped to `FracQI` by `x_qi = round_half_away_from_zero(x * Q)`.
- Entity keys use `FracQ = x_qi mod Q`.
- SymOp translations `t` are represented on the same grid (`t_q`) so SymOp application in `FracQ/FracQI`
  space is exact integer arithmetic.

#### 2.2.1 User-specified Q (validation)

Given an explicit `fracq_Q = Q`:

1. SymOp compatibility (hard): require `Q % D_sym == 0`.
   - if violated: raise `ValueError` in `strict=True`; otherwise auto-adjust to `lcm(Q, D_sym)` and warn.
2. Geometry resolution sanity (recommended): compute `step_max = max(||A @ (e_i / Q)||)` over `i=0,1,2`.
   - if `step_max >= dedup_tol_cart / c_grid`, warn that quantizationtion may affect clustering and may disable
     symmetry-derived outputs if coordinate collisions occur.

Users may choose `Q > Q_max` intentionally; this is allowed but may slow down hashing/debug output.

#### 2.2.2 Auto-derived Q (deterministic algorithm; tolerance-driven)

If `fracq_Q` is not provided, derive `Q` as follows:

1. Compute `D_sym` from SymOp translations.
2. Compute `D_frac` from atom-site coordinate strings that are explicit fractions `p/q` (ignore decimals).
3. Compute a tolerance-driven grid modulus:

   - `Q_tol = ceil(c_grid * L_cell / dedup_tol_cart)`
   - enforce `Q_tol >= 1`

4. Set `Q = lcm(D_sym, D_frac, Q_tol)` (by construction, `Q % D_sym == 0`).

5. Guardrail (auto-derivation only; simplicity-first):

   - If `Q <= Q_max`, accept `Q`.
   - If `Q > Q_max`:
     - `strict=True`: raise `ValueError` ("explicit Q required; auto-derived Q exceeds Q_max").
     - `strict=False`: accept this `Q` and warn about large integer keys / potential performance costs.

Notes:

- `Q_max` is a guardrail for auto-derivation, not a hard mathematical limit. Users may provide an explicit
  `fracq_Q > Q_max` intentionally.
- The tolerance-driven default makes `step_max` approximately `<= dedup_tol_cart / c_grid` for accepted `Q`.
- If users want exact behavior for specific rational coordinates, they can provide an explicit `fracq_Q`
  (and/or supply atom-site coordinates as `p/q` in the input).



## 3. Cell and symmetry

### 3.1 Cell (value object)

**Cell** stores a lattice matrix `A` mapping fractional -> Cartesian.

- Fields:
  - `A: float[3, 3]`
- Derived/cached:
  - `A_inv`, `volume`, metric tensor, etc.
- Methods:
  - `frac_to_cart(frac: Frac3) -> Cart3`
  - `cart_to_frac(cart: Cart3) -> Frac3`

### 3.2 SymOp (exact affine operator)
SymOp is an exact affine operator on fractional coordinates:

`x -> R x + t`

v0.1 uses an integer fixed-point representation compatible with `FracQ`.

- Fields (exact):
  - `R: int[3, 3]` (integer rotation matrix)
  - `t_q: Int3` translation on the `FracQ` grid, stored modulo `Q` in `[0, Q)` per component

- Identifiers:
  - `file_id: int`  (input order; for rendering/round-trip)
  - `canon_id: int` (canonical operator index used internally; assigned after deduplication by value)
  - `source_str: str | None` (original CIF string, if available)

- Methods:
  - `apply_q(frac_q: FracQ | FracQI) -> FracQI` (integer affine application; may be outside `[0,Q)` until wrapped)
  - `compose(other) -> SymOp` (exact, modulo `Q` on translation)
  - `inv() -> SymOp`
  - `as_xyz() -> str` (canonical printing, molcryst-defined)

SymOp string parsing contract (v0.1; supported CIF grammar):

molcryst supports a minimal, deterministic parser for common CIF operator strings in `x,y,z` form.
This parser is **required** to compute `D_sym` and to build exact `R` and `t`.

Accepted input shape:

- A SymOp string is three coordinate expressions separated by commas, e.g.:
  - `'x,y,z'`
  - `'-x, y+1/2, z'`
  - `'-y, x-y+1/3, z+1'`

Whitespace is ignored. Parentheses are **not** supported in v0.1.

Each coordinate expression is parsed as:

- A linear combination of variables `x`, `y`, `z` with integer coefficients in `{-1, 0, 1}`:
  - examples: `x`, `-y`, `x-y`, `-y+z`, `x+y-z`
  - coefficients outside `{-1,0,1}` are parse errors in v0.1.
- Plus an optional constant translation term:
  - integers: `+1`, `-2`
  - rationals: `+1/2`, `-2/3`
  - the constant may appear anywhere in the expression but must be a standalone `p/q` or integer token.

Examples (v0.1):

- OK:
  - `x+1/2-y` (tokens: `x`, `+1/2`, `-y`)
  - `-x-y+z+1` (tokens: `-x`, `-y`, `+z`, `+1`)
  - `x-y-2/3` (tokens: `x`, `-y`, `-2/3`)
- NOT OK:
  - `x+(1/2)-y` (parentheses not supported)
  - `x+0.5-y` (decimal constants not supported; use `1/2`)
  - `x+1/2y` (constant must be a standalone token)
  - `2x,y,z` (coefficients not in `{-1,0,1}`)


Parsing produces:

- `R: int[3,3]` with entries in `{-1,0,1}`.
- `t` as an exact rational per component; later represented on the `FracQ` grid as `t_q`.

Unsupported/operator-dialect cases (v0.1):

- parentheses, functions, non-linear forms, coefficients not in `{-1,0,1}`, or variables other than `x,y,z`.

Failure behavior:

- SymOp parse failure is a **hard load failure** (regardless of `strict`), because symmetry operations are
  required to build the COM in v0.1 (except P1 identity-only inputs).

Normalization and equivalence:

- Translations are always reduced modulo 1 on the `FracQ` grid: `t_q := t_q mod Q`.
- Two SymOps are considered equal for computation if `(R, t_q)` are equal.

Deduplication contract (required):

- CIFs may contain duplicate symops or symops that differ only by an integer translation.
- molcryst constructs `symops_unique` by deduplicating on `(R, t_q)`:
  - `canon_id` is assigned in **first-appearance** order among unique values.
  - The first-appearance rule applies only to SymOps present in the input; an implicit identity (if inserted) receives a new `canon_id` after all present unique ops.
  - If identity is absent from the input, it is inserted implicitly (no file appearance) and appended to the unique list.
  - A mapping `canon_id -> preferred file_id` is retained for rendering.
- All symmetry computations (SymTags, SymmetryIndex, orbit action) use `canon_id` operators, never raw `file_id`.

### 3.3 SymOp ordering policies (intention; v0.1 default uses file order)

molcryst distinguishes two independent operator indices:

- **file order** (`file_id`): preserve symops in the order they appeared in the input.
  - This is the v0.1 default (CSD-first workflows and CIF round-trip).
- **canonical order** (`canon_id`): an internally defined deterministic ordering used only
  for canonical decisions if desired. File order is always preserved separately.

v0.1 policy:

- `symop_ordering='file'` (default): keep input order; identity is discovered by value
  (`R = I`, `t = 0`) rather than assumed to be the first entry.

Sketch of an optional canonical policy (intention only; not required in v0.1):

- `symop_ordering='element'`: sort by a symmetry-element-inspired key to obtain an order
  that "looks like" it was generated from symmetry elements rather than by tuple ordering.

  Intended key construction:

  1. **Classify point operation** from `R`:
     - identity (`R = I`)
     - inversion (`R = -I`)
     - proper rotations (`det(R) = +1`, order n > 1)
     - mirrors/glides (reflection type, typically `det(R) = -1` with one `-1` eigenvalue)
     - improper rotations / rotoinversions (remaining `det(R) = -1` cases)
  2. **Extract element direction**:
     - for proper rotations/screws: axis direction from the integer primitive vector
       spanning `nullspace(R - I)`.
     - for mirrors/glides: plane normal from the integer primitive vector spanning
       the `-1` eigenspace (e.g., `nullspace(R + I)` for reflections).
     - fix the sign deterministically (e.g., first nonzero component is positive).
  3. **Translation character**:
     - normalize `t` into `[0,1)`.
     - (optional) decompose translation along the axis (screw component) or in-plane
       (glide component), and rank "simpler" translations first (smaller denominators,
       fewer nonzero components).
  4. **Hierarchy and tie-break**:
     - rank by a declared element-class hierarchy (identity, centring translations, inversion,
       mirror/glide, 2/3/4/6-fold rotations/screws, then improper rotations),
     - then by direction preference (setting-dependent),
     - then by translation simplicity,
     - tie-break by canonical `as_xyz()`.

molcryst does **not** claim this matches any external tool exactly. Its only purpose is
to provide a deterministic, element-motivated internal order when desired.


### 3.4 SymTag semantics
A SymTag identifies how an AtomRecord/Instance relates to an entity Atom in the reference cell.

Definition (v0.1):

- `SymTag = (canon_id: int, shift: Int3)` where:
  - `canon_id` indexes `symops_unique` (deduped by `(R, t_q)`).
  - `shift` is an integer translation in `Z^3` (unit cell shifts), used to place the image in the reference cell.

Semantics:

Given an entity fractional coordinate `x_q` (in `[0, Q)`) and SymTag `(g, s)`:

- Apply SymOp in `FracQ` space: `y_q = R_g * x_q + t_q_g`
- Then place into a specific image cell: `x_instance = y + s` (in integer cell units).

Normalization rules for SymTag are defined in Section 6.

String formatting (required):

- SymOp is printed using canonical CIF-style `as_xyz()` (molcryst-defined).
- SymTag is printed as: `"<as_xyz> @ [sx,sy,sz]"`.

Example:
- `-y,x-y,z+1/3 @ [0,0,0]`

## 4. Data model objects

### 4.1 Records

#### AtomRecord (raw input atom row)

Represents one input atom row/entry (CIF/import).

Minimal required fields:

- `record_id: int` (input order)
- `frac_raw: Frac3` (raw fractional coordinates as parsed)

Label fields:

- `label: str | None` (raw label if present; may be missing)
- `label_is_generated: bool` (True if label was generated by molcryst)

Element/type fields:

- `element: str | None`
  - If missing/invalid and `strict=False`, keep `None` and WARN.
  - If `strict=True`, invalid element may be an ERROR (policy choice).

Optional fields (reserved; subject to later refinement):

- occupancy, ADPs, disorder group/altloc, charge, etc.
- `extras: dict[str, Any]` for unmodeled CIF columns

#### BondRecord (raw input bond/contact row)

Parsed only if input explicitly provides bonds/contacts.

Minimal fields:

- `record_id: int`
- raw endpoints (labels and/or record ids if available)
- optional symmetry code / operator for partner if present
- optional raw distance

Bond/contact records are **evidence**. Connectivity is built by a policy:
- v0 may support `connectivity_policy='from_records'` (take records as-is).
- Later policies may infer connectivity geometrically.

### 4.2 Entities (canonical reference-cell objects)

#### Atom (canonical P1 atom)

Represents one deduplicated atom in the reference cell `[0,1)^3`.

Required fields:

- `atom_id: int`
- `element: str | None`
- `frac: Frac3` (wrapped to `[0,1)`; canonical)
- `label: str` (representative label; derived from records by policy)
- `rep_record_id: int`
- `record_ids: tuple[int, ...]` (all merged AtomRecord ids)

Symmetry metadata (explicitly split):

- `provenance_tags: tuple[AtomProvenance, ...]`
  - includes at least `(record_id, symtag)`; see 5.2 and 7.1.
- `stabilizer_tags: tuple[SymTag, ...]`
  - SymTags that map this atom onto itself (special positions). May be computed lazily.
- `primary_symtag: SymTag`
  - Deterministic representative tag (policy in 7.2).

Disorder slot:

- `disorder_tag: str | None` (default None; policy deferred)

#### Bond (canonical periodic edge)

Represents a periodic edge between **Atom entities**.

Required fields:

- `bond_id: int`
- `u: int` (atom_id)
- `v: int` (atom_id)
- `tvec: Tvec`
- `bond_type: str` (recommended vocabulary in docs; user-extensible)
- `is_directed: bool` (default False)

Provenance (split as agreed):

- `bond_source: str | None`
  - origin of **existence**: 'cif'|'reconstructed'|'user'|'imported'|'inferred'|None
- `bond_type_source: str | None`
  - origin of **typing**: 'user'|'rule'|'classifier'|'imported'|'cif'|None

Optional derived/cache fields:

- `distance: float | None` (Angstrom)
- `delta_cart: Cart3 | None`
- `attrs: dict[str, Any]`

#### Component (canonical connected entity in reference cell)

A **Component** is a canonical connected entity derived from the covalent graph over
Atom entities. It is the base concept for:

- `Molecule`: 0D components (finite)
- `Network`: 1D/2D/3D periodic components (infinite under translations)

Common required fields:

- `comp_id: int`
- `atom_ids: tuple[int, ...]`
- `rep_atom_id: int` (deterministic representative atom in the component)
- `rep_symtag: SymTag` (typically `Atom.primary_symtag` of `rep_atom_id`)

##### Molecule (0D component)

A `Molecule` represents a finite connected component.

##### Network (1D/2D/3D periodic component)

A `Network` represents a periodic connected component with:

- `periodic_dim: int` in {1,2,3} (derived from periodic connectivity invariants)

### 4.3 Instances (lightweight wrappers)

Instances are lightweight: they reference entities + SymTag.

- `AtomInstance(atom_id: int, symtag: SymTag)`
- `ComponentInstance(comp_id: int, symtag: SymTag)`
  - specialized aliases:
    - `MoleculeInstance`
    - `NetworkInstance`
- `BondInstance(bond_id: int, symtag: SymTag)` (optional convenience)

Instances provide derived coordinates and symmetry queries (relative ops).

Instance coordinate derivation (v0.1):

- `AtomInstance` is a lightweight pair `(atom_id, symtag)`.
- Its unreduced fixed-point coordinate is derived deterministically as:

  - Let `x_q = Atom[atom_id].frac_q` (a `FracQ` key in `[0,Q)`).
  - Let `symtag = (canon_id, shift)` and `g = symops_unique[canon_id] = (R, t_q)`.
  - Define `AtomInstance.frac_qi = R * x_q + t_q + shift * Q` (a `FracQI`).

This definition must be used consistently by relative-op computations and any instance-space geometry.


---

## 5. Provenance vs stabilizers

### 5.1 Why the split exists

- **Provenance tags** answer: which input records and symmetry placements produced/merged into this atom?
- **Stabilizer tags** answer: which symmetry operations fix this position (special positions)?

These sets are different and must not be conflated.

### 5.2 AtomProvenance

AtomProvenance minimally includes:

- `record_id: int` (required for deterministic "first wins" and traceability)
- `symtag: SymTag` (normalized; see 6)

The record_id is required to:
- enforce representative label selection,
- provide auditability/debuggability,
- enable paper-style reporting referencing original input ordering/labels.

### 5.3 Candidate generation and reference-cell clustering (v0)
Entity construction is defined as **clustering** symmetry-generated candidates into
equivalence classes, not "picking a winner" and discarding the rest.

Candidate generation uses **FracQ** to avoid nondeterministic `floor`/`round` behavior.

Rationale for using `FracQI` (unreduced) at input:

- Applying SymOps to unreduced coordinates differs from applying them to reduced coordinates only by an
  integer lattice shift; that shift is tracked explicitly by the wrapping shift `k`, so behavior is identical
  but easier to reason about when CIF coordinates lie outside `[0,1)`.

For each AtomRecord `r` (in record_id / CIF order) and each canonical SymOp `g` in `symops_unique`:

1. parse or store the record coordinate as `x_qi` (FracQI; may be outside `[0,Q)` if CIF gives values outside 0..1)
   - if a reference-cell key is needed, reduce with `x_q = x_qi mod Q` to obtain a `FracQ` in `[0,Q)`.
2. apply symop in integer arithmetic: `y_q = R_g * x_qi + t_q_g`
3. compute the reference-cell shift `k` to wrap into `[0, Q)`:
   - `k = -floor_div(y_q, Q)` componentwise
4. define `y_ref_q = y_q + k*Q` (now in `[0, Q)`)
5. define `symtag_ref = (g.canon_id, k)` (normalized placement into reference cell)

Each candidate contributes:
- a provenance tag `(r.record_id, symtag_ref)`
- a reference-cell coordinate `y_ref_q` (FracQ)

Candidates are clustered into Atom entities by:
- position equivalence in the reference cell (minimum-image Cartesian distance <= `dedup_tol_cart`; Section 7.5)
- and a discriminator key (safety rail; v0.1 required):

  `cluster_key = (elem_key, disorder_key, occ_bucket, unk_guard)`

  where:
  - `elem_key` is the normalized element symbol, or sentinel `'<UNK>'` if missing/unknown.
  - `disorder_key` is the disorder/altloc group if present, else `None`.
  - `occ_bucket` is a coarse occupancy bucket:
    - `None` if missing,
    - `'full'` if `occ >= 0.999`,
    - `'partial'` otherwise.
  - `unk_guard` is `record_id` **only when** `elem_key == '<UNK>'`, else `None`.

Default safety policy:

- Different known elements never merge.
- Unknown elements do not merge across different records by default (via `unk_guard`).
- Disorder groups (when present) block merging across mutually exclusive positions.

The cluster retains:
- `provenance_records`: all member record_ids,
- `provenance_symtags`: all member SymTags (optional but recommended for debug),
- `primary_record_id` / `primary_symtag` and entity coordinate anchor (Section 7.2).

## 6. Canonicalization rules

### 6.1 Fractional wrapping and snapping
All discrete operations on fractional coordinates are performed in `FracQ` space.

Wrapping:

- A `FracQ` coordinate is wrapped into the reference cell `[0, Q)` componentwise by integer modulo:
  - `wrap_q(q) = q mod Q`.

Because coordinates are quantized on input, explicit floating-point "boundary snaps" are not used for
discrete logic in v0.1.

Rounding / integer shifts:

- Any required rounding to the nearest integer cell shift is performed via explicit integer rules
  (no Python `round()`):
  - `round_div(n, Q)` with v0.1 tie-break: **round-half-away-from-zero**.

Float views (`Frac3`) exist only for geometry and tolerance-based comparisons (Section 7.5).

### 6.2 SymTag normalization (FracQ-native; placement into reference cell)

A SymTag is `(canon_id, shift)` where `shift` is an integer cell translation in `Z^3`.

Given an entity coordinate `x_q` in `FracQ` (reference cell, `[0,Q)`), and a raw placement `(g, s)`
with `g = (R, t_q)` and `s: Int3`:

1. Compute the unreduced image in `FracQI`:
   - `y_q = R * x_q + t_q + s * Q`
2. Compute the wrap shift to the reference cell:
   - `k = -floor_div(y_q, Q)` componentwise (integer division)
3. Reduce coordinate and normalize the shift:
   - `y_ref_q = y_q + k * Q`  (now in `[0,Q)`, a `FracQ`)
   - `s_norm = s + k`
4. The normalized SymTag is `(g.canon_id, s_norm)` and the normalized position is `y_ref_q`.

This normalization is used for candidate generation and provenance tags. No float floor/round or
boundary snapping is used for discrete decisions in v0.1.


### 6.3 SymTag ordering (v0.1)

SymTags store only `(canon_id, shift)`, but molcryst supports two deterministic orderings:

- **Algorithm order** (`symtag_ordering='canon'`, default for computations):
  - primary: `canon_id`
  - secondary: `shift_key(shift)`
  - tie-break: lexicographic `(sx, sy, sz)`

- **View/render order** (`symtag_ordering='file'`, default for string rendering):
  - primary: `preferred_file_id[canon_id]` (from SymOp dedup map in 3.2; `None` sorts last)
  - secondary: `shift_key(shift)`
  - tie-break: lexicographic `(sx, sy, sz)`

Shift key (common):

- `shift_key(s) = (Linf, L1, abs(sx), abs(sy), abs(sz))`
- `Linf = max(|sx|,|sy|,|sz|)`, `L1 = |sx|+|sy|+|sz|`

Notes:

- Internal canonical decisions (primary_symtag selection, canonical relative op) use
  `symtag_ordering='canon'`.
- Rendering and CIF round-trip convenience may use `symtag_ordering='file'` without affecting
  correctness.


---

## 7. Primary tags and relative operations

### 7.1 Building provenance tags

During candidate generation (5.3), each candidate contributes `(record_id, SymTag)`
which must already be normalized into the reference cell (6.2).

### 7.2 Representative selection policy (labels and primary SymTag)
Representative selection is **label/provenance-driven**, never coordinate-driven.

For each Atom entity cluster:

1. Primary record:
   - `Atom.primary_record_id = min(provenance_records)` (CIF/record order)

2. Primary SymTag:
   - among provenance SymTags that originate from `primary_record_id`, choose the minimal SymTag
     under:
       a) smallest `canon_id` (first-appearance among unique symops),
       b) then shift ordering (Section 6.3).

3. Entity coordinate anchor:
   - `Atom.frac_q` is set to the `y_ref_q` coordinate of the selected primary provenance member.
   - `Atom.frac` is a float view `Atom.frac_q / Q`.

Labels:

- `Atom.label` is taken from the primary AtomRecord when present; otherwise a label is generated
  deterministically from element + primary_record_id.

Provenance retained (recommended):

- `Atom.provenance_records: set[int]`
- `Atom.provenance_symtags: set[SymTag]` (useful for debug and later label schemes)

### 7.3 Relative operation between instances (atoms; FracQ-native)

Expose both:
- `relative_ops(mode='all')` -> set[SymTag]
- `relative_op(mode='canonical')` -> SymTag | None

Goal: find all SymTags `(g, s)` such that applying them to AtomInstance `A` yields AtomInstance `B`.

Atom-level algorithm (v0.1, integer-based):

Given AtomInstances `A` and `B` with unreduced integer fractional coordinates `xA_q: FracQI` and
`xB_q: FracQI`, enumerate all SymOps `g = (R, t_q)`:

1. Compute `y_q = R * xA_q + t_q` (in `FracQI`).
2. Let `d_q = xB_q - y_q`.
3. `d_q` defines a valid integer cell shift iff it is divisible by `Q` componentwise:
   - require `d_q[i] % Q == 0` for i=0..2
   - then `s = (d_q[0]//Q, d_q[1]//Q, d_q[2]//Q)`
4. If valid, include SymTag `(g.canon_id, s)` in the set.

Optional diagnostic verification (not part of the discrete decision; controlled by `StructureSettings.enable_sym_diagnostics`):

- Convert `y_q + s*Q` and `xB_q` to Cartesian floats and verify the distance is below
  `sym_tol_cart`. This is useful for debugging inconsistent inputs, but correctness is defined by
  integer divisibility in v0.1.

Canonical result is `min(set, key=SymTagOrder)`.

If stabilizers exist (special positions), multiple valid relatives will appear in the returned set;
canonical selection is deterministic.


### 7.4 Relative operations between ComponentInstances (molecules/networks)

Goal: return the full set of valid relative ops between two instances and a single
canonical "best" representative. This is stabilizer-correct without explicitly
constructing stabilizer groups.

Algorithm (v0):

1. Choose deterministic anchor `atom_id` in the component entity (e.g. smallest).
2. Locate anchor AtomInstances `A0` and `B0` inside ComponentInstances `A` and `B`.
3. Generate anchor candidates:
   - `C = relative_ops(A0, B0, mode='all')`
4. Verify each `σ in C` by applying it to all atoms in `A` and matching the
   corresponding atoms in `B` (same `atom_id`) within tolerance.
5. Collect verified ops as `R`.

Return:
- `relative_ops(A, B, mode='all') = R`
- `relative_op(A, B, mode='canonical') = min(R, key=SymTagOrder)`

This enumerates the correct set of mappings (effectively a stabilizer-quotiented
choice) because anchor enumeration already includes stabilizer-related multiplicity,
and full verification filters to true component mappings.

### 7.5 Tolerances
Tolerances are used only for geometric comparisons and clustering; they must not affect discrete symmetry logic.

- `dedup_tol_cart = 1e-3 Å` (entity clustering; minimum-image Cartesian distance)
- `sym_tol_cart = 1e-4 Å` (optional: "near symmetry" diagnostics; not used for mapping)

Minimum-image Cartesian distance:

Given two reference-cell candidates with `FracQ` coordinates `a_q`, `b_q`:

1. Compute integer delta: `d_q = b_q - a_q`.
2. Reduce to minimum image deterministically:
   - `d_mi_q = d_q - Q * round_div(d_q, Q)` componentwise.
3. Convert to fractional float delta: `d_mi = d_mi_q / Q`.
4. Convert to Cartesian: `dr = A @ d_mi` using the cell matrix `A`.
5. Distance: `||dr||`.

Candidates are considered position-equivalent if `||dr|| <= dedup_tol_cart`.

Note: the minimum-image vector is computed from integer `FracQ/FracQI` deltas (`d_mi_q / Q`), so
clustering operates on **quantized** positions. The `Q` selection policy (Section 2.2) requires
quantizationtion error to be negligible relative to `dedup_tol_cart`.



### 7.6 SymmetryIndex / AtomImageTable (required; correctness backbone)

Note: `symmetry_index_valid=False` is expected for disorder/altloc-heavy inputs or coarse `Q`.
In v0.1, orbit/unique-edge/multiplicity features are disabled when the SymmetryIndex is invalid.

Symmetry action on atoms and edges is defined via a precomputed mapping table built after entity atoms
and `symops_unique` are available.

Define:

- `atom_image[atom_id, canon_id] -> (atom_id_mapped, shift_to_ref: Int3)`

Construction (in `FracQ` space):

1. Build `coord_to_atom_id = { Atom.frac_q : atom_id }` for all entity atoms (must be one-to-one).
- If two entity atoms share the same `FracQ` coordinate, SymmetryIndex construction is ambiguous.
  v0.1 behavior:
    - `strict=True`: raise `SymmetryIndexError`.
    - `strict=False`: set `symmetry_index_valid=False` and disable symmetry-derived outputs.

2. Ensure identity SymOp exists by value `(R = I, t_q = 0)`:
   - identity is detected by value, not by position in the CIF list.
   - if missing from input, create an implicit identity SymOp and append it to `symops_unique`
     (preferred `file_id=None`). This preserves input order for existing symops and keeps `canon_id`
     assignment deterministic (first appearance in file among unique values; identity comes last if
     inserted).
   - store `identity_canon_id` explicitly for later use; do not assume it is 0.

3. For each `(u, g)`:
   - `y_q = R_g * x_q + t_q_g` where `x_q = Atom[u].frac_q`
   - `s = -floor_div(y_q, Q)` componentwise
   - `y_ref_q = y_q + s*Q` in `[0,Q)`
   - lookup `u_mapped = coord_to_atom_id[y_ref_q]`
   - store `atom_image[u, g] = (u_mapped, s)`

Failure modes and strictness:

- In `strict=True` mode (recommended default for symmetry-derived reporting):
  - if any `y_ref_q` is not found in `coord_to_atom_id`, raise `SymmetryIndexError` and disable
    symmetry-derived outputs (orbits, unique edges).
- In `strict=False` mode:
  - record a diagnostic report and mark `symmetry_index_valid=False`;
  - symmetry-dependent features (orbit partition, unique edges, multiplicities) are disabled;
  - non-symmetry features (bond inference, pbcgraph component analysis) may still proceed.

Diagnostics (minimum required in the error/report):

- one witness `(atom_id, canon_id)` failing, including `x_q`, `y_q`, `y_ref_q`, and a few nearest
  entity coordinates by `FracQ` L-infinity distance computed with componentwise `min_image` deltas in q-space (i.e., modulo `Q`).

No nearest-neighbor guessing:

- v0.1 must not "snap" an unmapped image to a nearest entity atom for action mapping.

Additional notes:

- Common causes of `FracQ` coordinate collisions include duplicated sites in the input,
  substitutional disorder modeled as multiple elements on the same site,
  disorder/altloc positions that collapse under quantizationtion, or an explicitly chosen coarse `Q`.
- Symmetry-derived outputs (SymTags beyond primary provenance, edge orbit partition, unique edges,
  multiplicities) require a valid SymmetryIndex. If `symmetry_index_valid=False`, these features
  are disabled in v0.1 and the user should adjust settings or input.

Public API behavior when `symmetry_index_valid=False` (v0.1; decide-now contract):

- Loading/parsing may still succeed (especially in `strict=False`), and non-symmetry features remain usable.
- Any method that *requires* SymmetryIndex (edge orbits, unique edges, orbit multiplicities/incidence)
  raises `SymmetryDisabledError` when called.
  - This avoids silently returning misleading empty results.
  - Users can guard by checking `structure.symmetry_index_valid` (or equivalent property) before calling.
- Atom-level `relative_ops` / `relative_op` remain available because they do not require SymmetryIndex
  (they are defined purely by integer divisibility in `FracQI` space; Section 7.3).

#### Tests (v0.1; required)

At minimum, include tests covering:

- valid SymmetryIndex construction on a clean ordered structure (all mapped coordinates found, one-to-one keys);
- invalid due to `FracQ` coordinate collision (two atoms share the same `FracQ`):
  - `strict=True` raises `SymmetryIndexError`;
  - `strict=False` sets `symmetry_index_valid=False` and disables symmetry-derived outputs;
- invalid due to missing mapped coordinate during table build (a SymOp image coordinate is not found in `coord_to_atom_id`):
  - `strict=True` raises `SymmetryIndexError`;
  - `strict=False` sets `symmetry_index_valid=False`.



## 8. Graph policy and pbcgraph integration

### 8.1 Storage vs views

- Store covalent/contact edges as entity lists (Bond entities).
- Build periodic graph objects as derived views when needed.

### 8.2 Undirected by default

Core datasets are undirected by default:

- atomic covalent graph: undirected
- molecular noncovalent graph: undirected
- atomic noncovalent internal graph: undirected (if stored)

Directed interactions are generated on demand via methods producing directed datasets/views.

### 8.3 Graphs (derived)

- `Structure.covalent_graph()` returns `pbcgraph.PeriodicGraph` (undirected) over Atom entities.
- `Structure.molecular_contact_graph()` returns `pbcgraph.PeriodicMultiGraph` over Molecule/Component entities (policy-defined),
  with helper to merge parallel edges into one edge with `contacts=[...]`.

### 8.4 Label rendering (view layer; summary)

Label strings are produced by a renderer scheme, independent of identity:

- `unique`: uses entity labels + SymTag when needed.
- `record_if_possible`: uses record labels when provenance supports it, else falls back to `unique`.
- `csd_like` / `element_ordered`: optional future schemes.

Label rendering must not affect COM identity or symmetry algorithms.

---

SymTag string format (v0.1): `"<as_xyz> @ [sx,sy,sz]"`.


## 9. Components (molecules vs networks)

Component dimensionality is derived from periodic connectivity (via pbcgraph invariants).

Policy:

- Base concept: Component.
- For initial implementation:
  - Molecule represents 0D components.
  - Network represents 1D/2D/3D components, with `periodic_dim` attribute.

Subclassing beyond this is optional and only justified if behavior differs substantially.

---

## 10. Geometry caching policy

Initial implementation:

- distances/deltas are computed on demand.
- no invalidation machinery is required if Structure is treated as immutable.

Caching may be introduced later after profiling.

---


## 11. Bond reconstruction (v0.1)

molcryst treats bond records as evidence and bonds as a constructed model.

### 11.1 Default policy names

User-facing bond policies:

- `bond_policy='auto'` (default): use resolvable CIF bond records, then infer missing bonds.
- `bond_policy='records'`: use only CIF bond records (resolvable ones).
- `bond_policy='infer'`: infer bonds purely from geometry (covalent radii cutoff).

Internally these correspond to the earlier discussed strategies.

### 11.2 Bond entity representation

A bond is stored as a periodic quotient edge:

- `Bond(u: AtomId, v: AtomId, tvec: Int3)` meaning `u@000` is bonded to `v@tvec`.

Canonicalization (undirected):

- `(u, v, tvec) ≡ (v, u, -tvec)`; store the canonical representative.
- self-loop periodic edges (`u == v`, `tvec != 0`) are valid.

Each bond stores:

- `source`: `'record'|'inferred'|'record_plus_inferred'`
- `order`: optional (pass-through from record if provided)
- `evidence`: lightweight list of record/inferred evidence entries.

### 11.3 Radii data and chemistry helpers

v0.1 ships with a packaged radii table (CSV) and a small `chem` helper layer.

- Primary values: Alvarez radii when available.
- Fallback policy: fill missing Alvarez entries with CSD/CCDC-derived radii values.

The API is intentionally small:

- element normalization (symbol <-> Z)
- radii lookup: `get(symbol, kind='covalent'|'vdw', policy='alvarez_then_csd') -> float | None`

This design is explicitly chosen to support later research updates (new sources, QC-derived radii,
and correlation-based filling) without refactoring the bond/contact machinery.

### 11.4 Geometry inference by covalent radii

A covalent bond between atoms i and j is inferred if:

- `d_cart(i, j) <= scale * (r_cov(i) + r_cov(j))`

Defaults:

- `scale = 1.10` (conservative)
- unknown-element pairs are skipped in inference (records may still introduce bonds).

No valence pruning is performed in v0.1.

### 11.5 Periodic neighbor search (SciPy cKDTree)

Neighbor search uses `scipy.spatial.cKDTree` over a translated image set ("supercell cloud").

For a chosen global search radius `R_max`:

1. Compute a safe integer translation bounding box `[-Na..Na] x [-Nb..Nb] x [-Nc..Nc]`
   using reciprocal-basis norms (conceptually: `Na = ceil(R_max * ||a*||)` etc.).
2. Generate translation vectors within that range and optionally prune by real-space length
   (`||A @ tvec|| <= R_max + buffer`) to reduce work.
3. Build Cartesian positions for all translated images and create a KDTree.
4. Query candidate pairs and accept as bonds if they satisfy the radii cutoff rule.
5. Convert each accepted neighbor hit into a quotient bond `(u, v, tvec)`.

#### 11.5.1 Duplicate suppression during inference (required)

KDTree queries over image clouds naturally produce duplicate detections of the same quotient bond
(e.g., discovered from multiple image pairings) and also self-pairs.

v0.1 requires a deterministic suppression rule based on a canonical undirected bond key.

Define a bond key:

- `BondKey = (u: AtomId, v: AtomId, tvec: Int3)` in canonical undirected form, where
  `(u, v, tvec) ≡ (v, u, -tvec)`.

Suppression rules:

- Ignore the trivial self-pair: `(u == v and tvec == (0, 0, 0))`.
- Keep periodic self-loops: `(u == v and tvec != (0, 0, 0))` (valid crystallographic pattern).
- Store `BondKey` in a set during inference; only emit a `Bond` the first time a key is observed.

This rule is applied identically regardless of whether the bond originates from inferred geometry
or from records merged with inferred bonds.

Caching:

- A `NeighborIndex` may be cached on the immutable `Structure`, keyed by `R_max` and relevant
  options, and reused for future contact searches with larger cutoffs.

### 11.6 Hydrogen / deuterium / occupancy / disorder

- Deuterium (`D`) is treated as hydrogen (`H`) for radii lookup and inference.
- Missing hydrogens are not added in v0.1.
- Partial occupancies:
  - atoms with `occ > 0` are kept by default;
  - `min_occupancy_for_inference` can optionally exclude low-occupancy atoms from inference;
  - evidence may include endpoint occupancies for audit.
- Disorder groups (when present):
  - inference should avoid creating bonds between mutually exclusive alternate positions by
    requiring compatible disorder grouping (simple compatibility rule; no global disorder solving).

---

## 12. ASU views (record-based)

ASU is treated as an input-record concept, independent of reference-cell entity normalization.

Definitions:

- **ASU records**: the atom-site rows accepted as input (after resolving any rare symmetric duplicates
  by the "first record wins" rule).
- **ASU atoms (entities)**: entity atoms whose `primary_record_id` is an ASU record.
- **ASU components**: components that contain at least one ASU atom.

Notes:

- ASU atom coordinates are not required to lie in `[0,1)^3`.
- Identity symop is detected by value; ASU is not defined as "identity-applied positions".

---

## 13. Unique edges via symmetry orbits (bonds and contacts)

molcryst supports output-oriented reduction of P1 edges into symmetry-unique edges with explicit
multiplicities and back-mapping.

Requirements:

- A valid SymmetryIndex is required (`structure.symmetry_index_valid=True`).
- v0.1 provides no approximate/heuristic fallback orbit partition when SymmetryIndex is invalid.
  Calls that request orbits/unique edges must raise `SymmetryDisabledError` (see 7.6).

### 13.1 Edge orbit partition

For each edge layer (`bonds`, later `contacts`), compute an orbit partition under the space group:

- `edge_to_orbit`: mapping from each P1 edge index to an `orbit_id`.
- `orbits`: list of orbit records (representative + members/count).

For bonds in v0.1, storing `member_edge_ids` is acceptable and helpful for debugging/tests.

### 13.2 Space-group action on a quotient edge

An edge is a quotient edge `e = (u, v, tvec)` representing `u@000 -- v@tvec`.

The canonical v0.1 implementation uses the precomputed atom mapping table (SymmetryIndex / AtomImageTable):

- `atom_image[u, canon_id] -> (u_mapped, shift_to_ref)`

For symmetry operator `g = (R, t)`:

1. Let `(u', su) = atom_image[u, g]` and `(v', sv) = atom_image[v, g]`.
2. Transform the translation: `tvec' = R * tvec + (sv - su)`.
3. Return the canonical undirected edge `canonicalize(u', v', tvec')`.

This defines symmetry equivalence of edges without label- or heuristic-based matching.

### 13.3 Orbit representative selection (default)

Two deterministic representative policies are supported:

- `rep_policy='asu_prefer'` (default):
  1) prefer edges whose endpoints' primary records are ASU records,
  2) tie-break by canonical edge key `(u, v, tvec)` (with integer-shift ordering).
- `rep_policy='canonical'`: choose the minimal edge under canonical edge ordering.

### 13.4 Multiplicity outputs

For each orbit:

- `multiplicity_per_cell = number_of member edges in the orbit`.

Incidence per molecule is computed lazily after components exist:

- for each member edge `(u,v,tvec)` increment incidences of `molecule(u)` and `molecule(v)`.

### 13.5 Optional optimization (deferred)

An atom action table may be used to accelerate repeated computations, but in v0.1 it is treated
as the correctness backbone (SymmetryIndex). Additional performance-only optimizations may be
added later.

---

## 14. pbcgraph interop (v0.1)

molcryst integrates with the `pbcgraph` engine via a dedicated interop module.

### 14.1 Interop boundary

- Only `molcryst/interop/pbcgraph.py` imports `pbcgraph`.
- molcryst core calls `Structure.get_components(...)` and related methods; it does not depend
  on pbcgraph APIs directly.

### 14.2 Graph type and conversion

For covalent bonds, use `pbcgraph.PeriodicGraph` (undirected semantics via paired directed edges).

Conversion:

- Nodes: `AtomId` integers.
- For each molcryst bond `(u, v, tvec)`:
  - add directed edge `u -> v` with translation `tvec`
  - add directed edge `v -> u` with translation `-tvec`
  - attach reserved edge metadata (e.g., `__molcryst__`) including:
    - `bond_id` (molcryst bond index)
    - `dir` (0 for forward, 1 for backward)

pbcgraph's internal keying handles periodic self-loops and multigraph safety where needed; molcryst
does not invent a separate keying scheme in v0.1.

### 14.3 Component analysis contract

Interop returns a list of component summaries:

- `atom_ids`: set of AtomIds in the periodic component
- `bond_ids`: set of molcryst bond indices in the component (recovered from edge attrs)
- `rank`: translation subgroup rank (0..3)

Mapping:

- `rank == 0` -> `Molecule`
- `rank in {1,2,3}` -> `Network(periodic_dim=rank)`

### 14.4 Helper functions vs public methods

Two helpers are specified for the interop module:

- `bond_graph_to_pbcgraph(...)`
- `analyze_components_via_pbcgraph(...)`

They are used internally by a more general public method such as:

- `Structure.get_components(layer='bonds', engine='pbcgraph')`

---

## 15. Output-facing API and caching (v0.1)

Structure is treated as immutable after construction. Derived objects are computed lazily and cached.

### 15.0 StructureSettings (required for stable caching)

molcryst treats `Structure` as an immutable value with lazily cached derived objects. To keep caching
correct and simple, all behavior-relevant knobs must be captured in an immutable settings object
stored on the `Structure`.

Define an internal (and optionally user-visible) value object:

- `StructureSettings`

It includes (at minimum):

- Symmetry/SymTag:
  - `fracq_Q` (FracQ modulus)
  - `symop_ordering` (e.g., `'file'`; canonical ids are always computed by value)
  - `dedup_tol_cart`
  - `enable_sym_diagnostics` (bool; default False)
  - clustering discriminator policy toggles (unknown element merge policy, occupancy/disorder keys)
- Bond reconstruction:
  - `bond_policy` (`'auto'|'records'|'infer'`)
  - radii policy (e.g., `'alvarez_then_csd'`)
  - inference parameters (`scale`, occupancy thresholds, disorder compatibility rule)
  - neighbor search parameters (`R_max` derivation knobs, pruning buffer if any)

Caching contract:

- Derived caches on `Structure` are either:
  - unambiguous because they depend only on `StructureSettings`, or
  - keyed explicitly by a settings-derived key (e.g., `rep_policy` for edge orbits).

If a user requests a materially different policy set (e.g., a different `bond_policy`), the
recommended v0.1 behavior is to create a new `Structure` (or a new derived object) with a distinct
`StructureSettings`, rather than mutating an existing instance.

### 15.1 Construction

- `Structure.from_cif(..., strict=False, symop_ordering='file', bond_policy='auto', bond_params=...)`

### 15.2 Core accessors

- `structure.atoms` -> list of Atom (entities)
- `structure.bonds` -> list of Bond (constructed)
- `structure.components` -> list of Molecule/Network (constructed via pbcgraph)

### 15.3 Unique edges / orbit outputs

- `structure.get_edge_orbits(layer='bonds', rep_policy='asu_prefer') -> EdgeOrbitPartition`
- `structure.get_unique_edges(layer='bonds', rep_policy='asu_prefer') -> list[Bond]` (orbit reps)
- `structure.get_edge_orbit_id(layer='bonds') -> list[int]` (edge index -> orbit id)

Notes:

- These methods require a valid SymmetryIndex; if `symmetry_index_valid=False`, they raise `SymmetryDisabledError`.

### 15.4 Multiplicity and incidence

- `structure.get_orbit_multiplicity_per_cell(layer='bonds') -> dict[orbit_id, int]`
- `structure.get_orbit_incidence(layer='bonds', level='molecule') -> dict[orbit_id, dict[molecule_id, int]]`

For v0.1, incidence is defined for Molecules (0D components). Support for Network incidence is
optional and may be added later.

Notes:

- These methods require a valid SymmetryIndex; if `symmetry_index_valid=False`, they raise `SymmetryDisabledError`.

---

## 16. Explicitly deferred beyond v0.1

- Contact reconstruction (vdW-based, user cutoffs) and large-contact orbit storage optimizations.
- Symmetry-element interpretation layer for operators (axis/plane extraction to user-facing descriptors).
- Full implementation and documentation of `symop_ordering='element'` (beyond sketch in 3.3).
- ASU-optimized bond inference and other performance-only optimizations.
- Hydrogen addition / valence-based completion.
- Global disorder configuration solving.

