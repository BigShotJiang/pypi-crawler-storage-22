{%
  include-markdown "../../NOTICE.md"
%}
