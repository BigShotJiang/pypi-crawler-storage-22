# molcryst

molcryst is a Python package for representing and analyzing molecular crystals,
focused on a crystal object model (COM) and exact, reproducible symmetry handling.

This documentation is currently a scaffold. The **Dev** section contains the
evolving architecture notes, implementation plan, and the v0.1 specs.
