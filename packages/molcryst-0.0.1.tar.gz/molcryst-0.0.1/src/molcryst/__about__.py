"""Package metadata.

The project uses a dynamic version read from here (see pyproject.toml).
"""

__version__ = '0.0.1'
