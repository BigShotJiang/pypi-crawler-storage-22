"""molcryst: crystal object model and symmetry conventions.

This package is in early development. Public API is not stable yet.
"""

from molcryst.__about__ import __version__

__all__ = ['__version__']
