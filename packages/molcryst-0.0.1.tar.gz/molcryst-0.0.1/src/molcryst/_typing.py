"""Internal typing helpers (placeholder)."""
