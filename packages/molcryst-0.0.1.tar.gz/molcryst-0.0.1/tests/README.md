# Tests

Policy:

- Keep tests close to the code structure:
  - `tests/types/`
  - `tests/symmetry/`
  - `tests/records/`
  - `tests/entities/`
  - etc.

- Prefer small, deterministic fixtures.
- For symmetry/FracQ logic, always include:
  - round-trip tests
  - invariants (idempotence, associativity where applicable)
  - ordering determinism tests
