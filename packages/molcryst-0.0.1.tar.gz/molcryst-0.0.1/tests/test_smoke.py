def test_import_and_version():
    import molcryst

    assert isinstance(molcryst.__version__, str)
    assert molcryst.__version__
