::: momapy.coloring
