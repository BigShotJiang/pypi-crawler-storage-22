import sys
from .modules import actions
from .systeme import actions as sys_act

def main():
    # Ton message de remerciement
    print("========================================")
    print("   MERCI D'AVOIR TELECHARGE MON OUTIL ! ")
    print("========================================")
    print("Lancement des composants en cours...")
    print("========================================\n")

    # On lance tes scripts open source
    # Assure-toi que tes fichiers actions.py ont une fonction "run()"
    try:
        # Lance le code du dossier modules
        actions.run() 
        
        # Lance le code du dossier systeme
        sys_act.run()
        
    except AttributeError:
        print("[ERREUR] : La fonction 'run()' est introuvable dans tes fichiers actions.py.")
        print("Verifie que tu as bien ecrit 'def run():' au debut de tes scripts.")
    except Exception as e:
        print(f"[ERREUR SYSTEME] : {e}")

if __name__ == "__main__":
    main()