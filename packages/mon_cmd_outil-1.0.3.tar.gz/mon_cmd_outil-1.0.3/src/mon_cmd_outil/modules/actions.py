import os
import time
import json
import socket
import threading
import webbrowser
import msvcrt
import glob
from colorama import Fore, Style
from ..utils import get_path

# --- CONFIGURATION DES CHEMINS ---
CONFIG_FILE = get_path("config.json")
MEMO_FILE = get_path("memos.txt")
PASS_FILE = get_path("passwords.txt")
LOG_FILE = get_path("history.log")

def write_log(action):
    timestamp = time.strftime('%Y-%m-%d %H:%M:%S')
    try:
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(f"[{timestamp}] {action}\n")
    except:
        pass

def load_config():
    if not os.path.exists(CONFIG_FILE):
        return {"pin": "0000", "aliases": {}, "shortcuts": {}}
    try:
        with open(CONFIG_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except:
        return {"pin": "0000", "aliases": {}, "shortcuts": {}}

def save_config(data):
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4)

def get_masked_input(prompt):
    print(prompt, end="", flush=True)
    buf = ""
    while True:
        ch = msvcrt.getch()
        if ch == b'\r':
            print()
            return buf
        elif ch == b'\x08':
            if len(buf) > 0:
                buf = buf[:-1]
                print('\b \b', end="", flush=True)
        else:
            buf += ch.decode('utf-8')
            print('*', end="", flush=True)

def show_help():
    print(Fore.CYAN + "\n--- AIDE ---")
    print(Fore.YELLOW + " /start [nom] [url] " + Fore.RESET + ": Lancer un favori")
    print(Fore.YELLOW + " /ghost             " + Fore.RESET + ": Mode discret (minimise tout)")
    print(Fore.YELLOW + " memo [texte]       " + Fore.RESET + ": Gérer les mémos")
    print(Fore.YELLOW + " mdp                " + Fore.RESET + ": Gestionnaire de mots de passe")
    print(Fore.YELLOW + " /code              " + Fore.RESET + ": Bloc-notes rapide")
    print(Fore.YELLOW + " /timer [sec]       " + Fore.RESET + ": Minuteur")
    print(Fore.CYAN + "----------------\n")

def exec_memo(args):
    if not args:
        if os.path.exists(MEMO_FILE):
            print(Fore.CYAN + "\n--- MEMOS ---" + Fore.RESET)
            with open(MEMO_FILE, "r", encoding="utf-8") as f:
                print(f.read())
            print(Fore.CYAN + "-------------\n" + Fore.RESET)
    else:
        content = " ".join(args)
        timestamp = time.strftime('%Y-%m-%d %H:%M:%S')
        with open(MEMO_FILE, "a", encoding="utf-8") as f:
            f.write(f"[{timestamp}] {content}\n")
        print(Fore.GREEN + "Mémo ajouté." + Fore.RESET)

def exec_mdp():
    conf = load_config()
    pin = get_masked_input("PIN: ")
    if pin != conf.get("pin", "0000"):
        print(Fore.RED + "Accès refusé." + Fore.RESET)
        return
    while True:
        print("\n1. Voir | 2. Ajouter | 3. Quitter")
        c = input("Choix > ")
        if c == "1":
            if os.path.exists(PASS_FILE):
                with open(PASS_FILE, "r", encoding="utf-8") as f:
                    print(f.read())
        elif c == "2":
            site = input("Site : ")
            pwd = input("Mdp : ")
            with open(PASS_FILE, "a", encoding="utf-8") as f:
                f.write(f"[{site}] : {pwd}\n")
        elif c == "3": break

def exec_run(args):
    if args: os.system(" ".join(args))

def exec_start(args):
    if not args: return
    t = args[0]
    if t.startswith("http"): webbrowser.open(t)
    else: os.system(f"start {t}")

def exec_ghost():
    os.system("powershell -command \"(New-Object -ComObject Shell.Application).MinimizeAll()\"")

def exec_alias(args):
    if len(args) < 2: return
    config = load_config()
    config["aliases"][args[1]] = args[0]
    save_config(config)

def exec_code_file():
    path = get_path(f"dev_{int(time.time())}.txt")
    with open(path, "w") as f: f.write("")
    os.system(f"notepad {path}")

def exec_timer(args):
    if not args: return
    try:
        sec = int(args[0])
        time.sleep(sec)
        print("\a" + Fore.RED + "BIP BIP ! FIN !" + Fore.RESET)
    except: pass