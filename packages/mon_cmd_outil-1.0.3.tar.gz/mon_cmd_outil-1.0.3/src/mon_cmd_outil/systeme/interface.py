import os
import sys
import msvcrt
import cmd
from colorama import init, Fore, Style
from ..modules import actions

init(autoreset=True)

# LISTE MISE À JOUR (SANS P2P)
BASE_CMDS = [
    "memo", "mdp", "/hlp", "/run", "/cnf", "/start", "/ghost", 
    "/alias", "/shortcut", "/cmd", "/exit", "/code", "/timer", "/cls"
]

def print_banner():
    os.system('cls' if os.name == 'nt' else 'clear')
    print(Fore.GREEN + r"""
  __  __       _______          _     
 |  \/  |     |__   __|        | |    
 | \  / |_   _   | | ___   ___ | |___ 
 | |\/| | | | |  | |/ _ \ / _ \| / __|
 | |  | | |_| |  | | (_) | (_) | \__ \
 |_|  |_|\__, |  |_|\___/ \___/|_|___/
          __/ |                       
         |___/                        
    """)
    print(Fore.RED + "_"*50 + "\n")

def get_input_ghost(prompt):
    print(prompt, end="", flush=True)
    user_input = ""
    config = actions.load_config()
    pool = BASE_CMDS + list(config.get("aliases", {}).keys())
    while True:
        ch = msvcrt.getch()
        if ch == b'\r':
            print()
            return user_input
        elif ch == b'\x08':
            if len(user_input) > 0:
                user_input = user_input[:-1]
                print('\b \b', end="", flush=True)
        elif ch == b'\t':
            matches = [c for c in pool if c.startswith(user_input)]
            if matches:
                suggestion = matches[0][len(user_input):]
                user_input += suggestion
                print(suggestion, end="", flush=True)
        else:
            try:
                char = ch.decode('utf-8')
                user_input += char
                print(char, end="", flush=True)
            except: pass

def start():
    print_banner()
    actions.write_log("Session démarrée")
    while True:
        try:
            cmd_in = get_input_ghost(Fore.GREEN + "(CMD) > " + Fore.RESET)
            if not cmd_in.strip(): continue
            actions.write_log(f"CMD: {cmd_in}")
            parts = cmd_in.split()
            cmd = parts[0].lower()
            args = parts[1:]
            config = actions.load_config()
            if cmd in config.get("aliases", {}): cmd = config["aliases"][cmd]
            
            if cmd == "/exit": break
            elif cmd == "/cls": print_banner()
            elif cmd == "/hlp": actions.show_help()
            elif cmd == "memo": actions.exec_memo(args)
            elif cmd == "mdp": actions.exec_mdp()
            elif cmd == "/run": actions.exec_run(args)
            elif cmd == "/start": actions.exec_start(args)
            elif cmd == "/ghost": actions.exec_ghost()
            elif cmd == "/alias": actions.exec_alias(args)
            elif cmd == "/code": actions.exec_code_file()
            elif cmd == "/timer": actions.exec_timer(args)
            else: print(Fore.RED + "Inconnu. Tapez /hlp." + Fore.RESET)
        except KeyboardInterrupt: break