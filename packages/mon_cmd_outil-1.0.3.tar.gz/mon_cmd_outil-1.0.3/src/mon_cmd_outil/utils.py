import os
import platform

def get_path(filename):
    """
    Cette fonction permet de sauvegarder tes données (memos, passwords)
    dans le dossier utilisateur (AppData sur Windows) au lieu du dossier
    système. C'est obligatoire pour un package Pip.
    """
    # On détermine le dossier de base selon le système (Windows ou Mac/Linux)
    if platform.system() == "Windows":
        base_dir = os.getenv('APPDATA')
    else:
        base_dir = os.path.expanduser('~')
    
    # On crée un dossier dédié à ton outil
    data_dir = os.path.join(base_dir, "mon_cmd_outil_data")
    
    # Si le dossier n'existe pas encore sur l'ordi, on le crée
    if not os.path.exists(data_dir):
        os.makedirs(data_dir)
        
    # On retourne le chemin complet vers ton fichier
    return os.path.join(data_dir, filename)