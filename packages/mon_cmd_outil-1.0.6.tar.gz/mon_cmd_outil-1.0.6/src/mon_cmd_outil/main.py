import sys
# On importe 'interface' et non 'actions' car ton fichier s'appelle interface.py
from .modules import actions
from .systeme import interface 

def main():
    print("========================================")
    print("   LANCEMENT DE MY TOOLS                ")
    print("========================================\n")

    try:
        # On appelle 'start()' car c'est le nom dans ton fichier interface.py
        interface.start()
    except Exception as e:
        print(f"\n[ERREUR] : {e}")

if __name__ == "__main__":
    main()