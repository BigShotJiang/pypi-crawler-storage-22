# Mon Package Python

[![Tests](https://github.com/username/mon-package-python/actions/workflows/tests.yaml/badge.svg)](https://github.com/username/mon-package-python/actions/workflows/tests.yaml)
[![Documentation](https://github.com/username/mon-package-python/actions/workflows/sphinx_doc.yaml/badge.svg)](https://username.github.io/mon-package-python/)
[![PyPI version](https://badge.fury.io/py/mon-package-python.svg)](https://badge.fury.io/py/mon-package-python)
[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)

Un package Python professionnel avec toutes les meilleures pratiques de développement.

## 🚀 Installation

```bash
pip install mon-package-python
```

Ou pour un environnement de développement :

```bash
git clone https://github.com/username/mon-package-python.git
cd mon-package-python
poetry install
```

## 📖 Utilisation

```python
from mon_package_python.string_ops import reverse_string, count_vowels

# Inverser une chaîne
result = reverse_string("Hello World")
print(result)  # "dlroW olleH"

# Compter les voyelles
vowels = count_vowels("Hello World")
print(vowels)  # 3
```

## 🛠️ Fonctionnalités

- ✅ Manipulation de chaînes de caractères
- ✅ Opérations mathématiques
- ✅ Utilitaires de données
- ✅ Documentation complète
- ✅ Tests unitaires avec >80% de couverture

## 📚 Documentation

La documentation complète est disponible sur [GitHub Pages](https://username.github.io/mon-package-python/).

## 🧪 Tests

Pour exécuter les tests :

```bash
poetry run pytest
```

Avec couverture de code :

```bash
poetry run pytest --cov
```

## 🔧 Développement

### Pré-requis

- Python 3.10+
- Poetry

### Installation de l'environnement de développement

```bash
# Installer les dépendances
poetry install

# Activer l'environnement virtuel
poetry shell

# Installer les pre-commit hooks
pre-commit install
```

### Workflow de développement

1. Créer une branche pour votre fonctionnalité
   ```bash
   git checkout -b feature/ma-nouvelle-fonctionnalite
   ```

2. Faire vos modifications avec des commits atomiques

3. Exécuter les tests
   ```bash
   poetry run pytest
   ```

4. Vérifier la qualité du code
   ```bash
   ruff check --fix .
   ```

5. Créer une Pull Request

## 📦 Structure du Projet

```
mon-package-python/
├── .github/
│   └── workflows/          # GitHub Actions CI/CD
├── docs/                   # Documentation Sphinx
├── src/
│   └── mon_package_python/ # Code source
│       ├── __init__.py
│       ├── string_ops.py
│       └── math_ops.py
├── tests/                  # Tests unitaires
│   ├── __init__.py
│   ├── test_string_ops.py
│   └── test_math_ops.py
├── .gitignore
├── .pre-commit-config.yaml
├── pyproject.toml
├── README.md
└── LICENSE
```



