"""
Mon Package Python
==================

Un package Python professionnel avec toutes les meilleures pratiques.

Modules disponibles:
- string_ops: Opérations sur les chaînes de caractères
- math_ops: Opérations mathématiques utiles
"""

__version__ = "0.1.0"
__author__ = "Votre Nom"
__email__ = "votre.email@example.com"

from mon_package_python.string_ops import (
    capitalize_words,
    count_vowels,
    reverse_string,
)

__all__ = [
    "reverse_string",
    "count_vowels",
    "capitalize_words",
]
