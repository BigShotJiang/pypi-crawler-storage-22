"""
Module pour les opérations mathématiques.

Ce module fournit des fonctions mathématiques utilitaires.
"""

from typing import List, Union


def factorial(n: int) -> int:
    """
    Calcule la factorielle d'un nombre.

    Args:
        n (int): Le nombre dont on veut calculer la factorielle (n >= 0).

    Returns:
        int: La factorielle de n.

    Examples:
        >>> factorial(5)
        120
        >>> factorial(0)
        1
        >>> factorial(3)
        6

    Raises:
        ValueError: Si n est négatif.
        TypeError: Si n n'est pas un entier.
    """
    if not isinstance(n, int):
        raise TypeError(f"Expected int, got {type(n).__name__}")
    if n < 0:
        raise ValueError("Factorial is not defined for negative numbers")
    if n == 0 or n == 1:
        return 1
    return n * factorial(n - 1)


def is_prime(n: int) -> bool:
    """
    Vérifie si un nombre est premier.

    Args:
        n (int): Le nombre à vérifier.

    Returns:
        bool: True si le nombre est premier, False sinon.

    Examples:
        >>> is_prime(7)
        True
        >>> is_prime(10)
        False
        >>> is_prime(2)
        True

    Raises:
        TypeError: Si n n'est pas un entier.
    """
    if not isinstance(n, int):
        raise TypeError(f"Expected int, got {type(n).__name__}")
    if n < 2:
        return False
    if n == 2:
        return True
    if n % 2 == 0:
        return False

    # Vérifier les diviseurs impairs jusqu'à sqrt(n)
    i = 3
    while i * i <= n:
        if n % i == 0:
            return False
        i += 2
    return True


def fibonacci(n: int) -> List[int]:
    """
    Génère la suite de Fibonacci jusqu'au n-ième terme.

    Args:
        n (int): Le nombre de termes à générer (n >= 0).

    Returns:
        List[int]: La liste des n premiers termes de Fibonacci.

    Examples:
        >>> fibonacci(5)
        [0, 1, 1, 2, 3]
        >>> fibonacci(8)
        [0, 1, 1, 2, 3, 5, 8, 13]
        >>> fibonacci(1)
        [0]

    Raises:
        ValueError: Si n est négatif.
        TypeError: Si n n'est pas un entier.
    """
    if not isinstance(n, int):
        raise TypeError(f"Expected int, got {type(n).__name__}")
    if n < 0:
        raise ValueError("n must be non-negative")
    if n == 0:
        return []
    if n == 1:
        return [0]

    fib = [0, 1]
    for _ in range(2, n):
        fib.append(fib[-1] + fib[-2])
    return fib


def mean(numbers: List[Union[int, float]]) -> float:
    """
    Calcule la moyenne d'une liste de nombres.

    Args:
        numbers (List[Union[int, float]]): Liste de nombres.

    Returns:
        float: La moyenne des nombres.

    Examples:
        >>> mean([1, 2, 3, 4, 5])
        3.0
        >>> mean([10, 20, 30])
        20.0

    Raises:
        ValueError: Si la liste est vide.
        TypeError: Si la liste contient des éléments non numériques.
    """
    if not numbers:
        raise ValueError("Cannot calculate mean of empty list")
    if not all(isinstance(x, (int, float)) for x in numbers):
        raise TypeError("All elements must be numbers")

    return sum(numbers) / len(numbers)


def median(numbers: List[Union[int, float]]) -> float:
    """
    Calcule la médiane d'une liste de nombres.

    Args:
        numbers (List[Union[int, float]]): Liste de nombres.

    Returns:
        float: La médiane des nombres.

    Examples:
        >>> median([1, 2, 3, 4, 5])
        3.0
        >>> median([1, 2, 3, 4])
        2.5

    Raises:
        ValueError: Si la liste est vide.
        TypeError: Si la liste contient des éléments non numériques.
    """
    if not numbers:
        raise ValueError("Cannot calculate median of empty list")
    if not all(isinstance(x, (int, float)) for x in numbers):
        raise TypeError("All elements must be numbers")

    sorted_numbers = sorted(numbers)
    n = len(sorted_numbers)

    if n % 2 == 1:
        return float(sorted_numbers[n // 2])
    else:
        mid1, mid2 = sorted_numbers[n // 2 - 1], sorted_numbers[n // 2]
        return (mid1 + mid2) / 2.0


def gcd(a: int, b: int) -> int:
    """
    Calcule le plus grand commun diviseur (PGCD) de deux nombres.

    Utilise l'algorithme d'Euclide.

    Args:
        a (int): Premier nombre.
        b (int): Deuxième nombre.

    Returns:
        int: Le PGCD de a et b.

    Examples:
        >>> gcd(48, 18)
        6
        >>> gcd(100, 50)
        50
        >>> gcd(17, 13)
        1

    Raises:
        TypeError: Si a ou b ne sont pas des entiers.
    """
    if not isinstance(a, int) or not isinstance(b, int):
        raise TypeError("Both arguments must be integers")

    a, b = abs(a), abs(b)
    while b:
        a, b = b, a % b
    return a
