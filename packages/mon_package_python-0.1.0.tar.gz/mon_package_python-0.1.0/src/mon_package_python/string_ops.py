"""
Module pour les opérations sur les chaînes de caractères.

Ce module fournit des fonctions utilitaires pour manipuler
les chaînes de caractères de manière efficace.
"""


def reverse_string(s: str) -> str:
    """
    Inverse l'ordre des caractères d'une chaîne.

    Args:
        s (str): La chaîne à inverser.

    Returns:
        str: La chaîne inversée.

    Examples:
        >>> reverse_string("Hello")
        'olleH'
        >>> reverse_string("Python")
        'nohtyP'

    Raises:
        TypeError: Si l'argument n'est pas une chaîne.
    """
    if not isinstance(s, str):
        raise TypeError(f"Expected str, got {type(s).__name__}")
    return s[::-1]


def count_vowels(s: str) -> int:
    """
    Compte le nombre de voyelles dans une chaîne.

    Les voyelles prises en compte sont: a, e, i, o, u (minuscules et majuscules).

    Args:
        s (str): La chaîne dans laquelle compter les voyelles.

    Returns:
        int: Le nombre de voyelles trouvées.

    Examples:
        >>> count_vowels("Hello World")
        3
        >>> count_vowels("AEIOU")
        5
        >>> count_vowels("xyz")
        0

    Raises:
        TypeError: Si l'argument n'est pas une chaîne.
    """
    if not isinstance(s, str):
        raise TypeError(f"Expected str, got {type(s).__name__}")

    vowels: str = "aeiouAEIOU"
    return sum(1 for char in s if char in vowels)


def capitalize_words(s: str) -> str:
    """
    Met en majuscule la première lettre de chaque mot.

    Args:
        s (str): La chaîne à modifier.

    Returns:
        str: Une nouvelle chaîne avec chaque mot capitalisé.

    Examples:
        >>> capitalize_words("hello world")
        'Hello World'
        >>> capitalize_words("python programming")
        'Python Programming'
        >>> capitalize_words("the quick brown fox")
        'The Quick Brown Fox'

    Raises:
        TypeError: Si l'argument n'est pas une chaîne.
    """
    if not isinstance(s, str):
        raise TypeError(f"Expected str, got {type(s).__name__}")

    return " ".join(word.capitalize() for word in s.split())


def remove_whitespace(s: str) -> str:
    """
    Supprime tous les espaces blancs d'une chaîne.

    Args:
        s (str): La chaîne à traiter.

    Returns:
        str: La chaîne sans espaces.

    Examples:
        >>> remove_whitespace("Hello World")
        'HelloWorld'
        >>> remove_whitespace("  Python   Programming  ")
        'PythonProgramming'

    Raises:
        TypeError: Si l'argument n'est pas une chaîne.
    """
    if not isinstance(s, str):
        raise TypeError(f"Expected str, got {type(s).__name__}")

    return "".join(s.split())


def is_palindrome(s: str) -> bool:
    """
    Vérifie si une chaîne est un palindrome.

    Un palindrome est un mot qui se lit de la même façon dans les deux sens.
    La fonction ignore les espaces et la casse.

    Args:
        s (str): La chaîne à vérifier.

    Returns:
        bool: True si c'est un palindrome, False sinon.

    Examples:
        >>> is_palindrome("radar")
        True
        >>> is_palindrome("A man a plan a canal Panama")
        True
        >>> is_palindrome("hello")
        False

    Raises:
        TypeError: Si l'argument n'est pas une chaîne.
    """
    if not isinstance(s, str):
        raise TypeError(f"Expected str, got {type(s).__name__}")

    # Normaliser: enlever les espaces et mettre en minuscules
    normalized = "".join(s.split()).lower()
    return normalized == normalized[::-1]
