"""Pipeline module for mono-cbp."""

from .pipeline import MonoCBPPipeline

__all__ = ["MonoCBPPipeline"]
