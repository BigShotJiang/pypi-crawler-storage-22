"""
Tests for Mono-Kickstart
"""
