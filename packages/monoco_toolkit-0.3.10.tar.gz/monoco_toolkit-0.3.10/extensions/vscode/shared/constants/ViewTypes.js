/**
 * View type identifiers
 */
export const VIEW_TYPES = {
  KANBAN: 'monoco-kanban',
  EXECUTIONS: 'monoco-executions',
}
