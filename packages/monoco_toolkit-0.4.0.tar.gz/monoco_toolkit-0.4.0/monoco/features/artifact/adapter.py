from pathlib import Path
from typing import Dict
from monoco.core.loader import FeatureModule, FeatureMetadata
from monoco.core.feature import IntegrationData


class ArtifactFeature(FeatureModule):
    """Artifact management feature module."""

    @property
    def metadata(self) -> FeatureMetadata:
        return FeatureMetadata(
            name="artifact",
            version="1.0.0",
            description="Artifact management system for Monoco",
            dependencies=["core"],
            priority=20,
        )

    def integrate(self, root: Path, config: Dict) -> IntegrationData:
        """Provide integration data for agent environment."""
        lang = config.get("i18n", {}).get("source_lang", "zh")
        base_dir = Path(__file__).parent / "resources"
        prompt_file = base_dir / lang / "AGENTS.md"
        
        if not prompt_file.exists():
            prompt_file = base_dir / "en" / "AGENTS.md"

        content = ""
        if prompt_file.exists():
            content = prompt_file.read_text(encoding="utf-8").strip()

        return IntegrationData(system_prompts={"Artifacts & Mailroom": content})
