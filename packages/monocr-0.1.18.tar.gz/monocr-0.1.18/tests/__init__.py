# Tests for monocr package
