def test_import_monte_carlo_sensitivity():
    import monte_carlo_sensitivity
