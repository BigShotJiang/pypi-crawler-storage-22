# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from datetime import datetime
from typing_extensions import Literal

from .._models import BaseModel
from .shared.pointer import Pointer

__all__ = ["ActivityInboxMessageSent"]


class ActivityInboxMessageSent(BaseModel):
    """Represents an event that occurs when a message is sent from an `Inbox`."""

    id: str
    """Unique identifier for the object."""

    message: Optional[Pointer] = None
    """A lightweight reference to another resource."""

    occurred_at: datetime
    """The time at which the event occurred, as an ISO 8601 timestamp in UTC."""

    type: Literal["activity/inbox_message_sent"]
    """The type of activity. Always `activity/inbox_message_sent`."""
