# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing_extensions import Literal

from .._models import BaseModel

__all__ = ["BooleanValue"]


class BooleanValue(BaseModel):
    """True or false value"""

    data: bool

    type: Literal["value/boolean"]
