"""MCP server for spawning AI coding agents."""

from __future__ import annotations

__version__ = "0.12.0"

from .server import main, run, server

__all__ = ["__version__", "main", "run", "server"]
