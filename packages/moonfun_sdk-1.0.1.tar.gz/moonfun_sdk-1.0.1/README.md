# MoonfunSDK - Python

Unified SDK for Meme Platform with triple-lock security.

## Installation

```bash
pip install -r requirements.txt
```

Or install from source:

```bash
python setup.py install
```

## Quick Start

```python
from moonfun_sdk import MoonfunSDK
import os

# Initialize SDK
sdk = MoonfunSDK(
    private_key=os.getenv('PRIVATE_KEY'),
    image_api_url="https://your-api-url.com"
)

# Create Meme token
result = sdk.create_meme(prompt="A funny cat")
print(f"Token created: {result['token_address']}")

# Buy tokens
sdk.buy_token(token_address="0x...", bnb_amount=0.1)

# Sell tokens
balance = sdk.get_token_balance("0x...")
sdk.sell_token(token_address="0x...", amount=balance)
```

## Features

- **One-Click Meme Creation**: `create_meme()` handles entire flow
- **Triple-Lock Security**: Signature + Timestamp + Balance verification
- **Token Trading**: Buy and sell tokens with slippage protection
- **Comprehensive Error Handling**: Custom exceptions for all error cases
- **Type Hints**: Full type annotations for better IDE support

## Examples

See `examples/` directory:
- `example_create_meme.py` - Create a Meme token
- `example_trading.py` - Buy and sell tokens

## Documentation

- [Security Architecture](../../docs/SECURITY_ARCHITECTURE.md)
- [API Specification](../../docs/API_SPECIFICATION.md)
- [SDK Design](../../docs/SDK_DESIGN.md)

## License

MIT
