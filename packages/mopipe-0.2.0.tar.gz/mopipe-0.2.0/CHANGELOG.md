# Mopipe Changelog

## 0.2.0

- Added examples
    - Basic pipeline
    - RQA
- Added joblib caching to speed up subsequent runs
