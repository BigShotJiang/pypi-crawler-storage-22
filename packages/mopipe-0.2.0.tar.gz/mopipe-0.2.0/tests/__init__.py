# SPDX-FileCopyrightText: 2023-present zeyus <zeyus@zeyus.com>
#
# SPDX-License-Identifier: MIT
import logging

logging.basicConfig(level=logging.DEBUG)
