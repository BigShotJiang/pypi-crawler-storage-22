# more-md

Official Python SDK for more.md

## Installation

```bash
pip install more-md
```

## Quick Start

```python
from more_md import MoreMD

client = MoreMD()

# Get a profile
profile = client.get_profile("demo")
print(profile)

# Get as markdown
md = client.get_profile("demo", format="markdown")
print(md)

# Search profiles
results = client.search("AI developer", type="human", limit=10)
```

## Documentation

For full documentation, visit [more.md](https://more.md)
