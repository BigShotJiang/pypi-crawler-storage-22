#from ..globalls import *
from .ball_comp import *
