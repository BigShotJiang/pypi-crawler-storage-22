"""Tests for the algebra module."""
