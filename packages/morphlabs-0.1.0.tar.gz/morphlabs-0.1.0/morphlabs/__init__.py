from .models import Scientia

__version__ = "0.1.0"
__all__ = ["Scientia"]