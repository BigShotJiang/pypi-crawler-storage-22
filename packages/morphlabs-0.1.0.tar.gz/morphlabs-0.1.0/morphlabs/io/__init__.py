from .loading import EEGData

__all__ = ['EEGData']