import numpy as np
import pandas as pd
import mne
from pathlib import Path
from typing import Optional


class EEGData:
    def __init__(self, file_path: str):
        self.file_path = file_path
        self._data = None
        self._channels = None
        self._pad_amount = None

        if file_path is not None:
            if not self.load_data():
                raise ValueError(f"Failed to load data from {file_path}")
        
    def get_data(self) -> Optional[list[np.ndarray]]:
        return self._data

    def get_channels(self) -> Optional[int]:
        return self._channels

    def get_pad_amount(self) -> Optional[int]:
        return self._pad_amount

    def load_data(self) -> bool:
        self._validate_file_path(self.file_path)
        match Path(self.file_path).suffix:
            case '.csv':
                self.load_data_from_csv(self.file_path)
                return True
            case '.edf':
                self.load_data_from_edf(self.file_path)
                return True
            case '.bdf':
                self.load_data_from_bdf(self.file_path)
                return True
            case _:
                raise ValueError(f"Unsupported file type: {str(self.file_path).split('.')[-1]}, please use .csv, .edf, or .bdf files.") 
    
    def load_data_from_csv(self, file_path: str):
        try:
            data = pd.read_csv(file_path)
            if data.empty:
                raise ValueError(f"File is empty: '{file_path}'. Please provide a file with EEG data.")
            self._channels = len(data.columns)
            self._data, self._pad_amount = self.segment_data(data.values.T.astype(np.float32))
            self.verify_montage()
        except UnicodeDecodeError as e:
            raise ValueError(f"Failed to load CSV file '{file_path}': File contains invalid characters. Details: {e}")
        except pd.errors.ParserError as e:
            raise ValueError(f"Failed to parse CSV file '{file_path}': File may be corrupted or incorrectly formatted. Details: {e}")
        except pd.errors.EmptyDataError:
            raise ValueError(f"File is empty: '{file_path}'. Please provide a file with EEG data.")
        except ValueError:
            raise
        except Exception as e:
            raise ValueError(f"Failed to load CSV file '{file_path}': {type(e).__name__}: {e}")

    def load_data_from_edf(self, file_path: str):
        try:
            raw = mne.io.read_raw_edf(file_path, preload=True, verbose=False)
            self._channels = len(raw.ch_names)
            self._data, self._pad_amount = self.segment_data(raw.get_data().astype(np.float32))
            self.verify_montage()
        except ValueError:
            raise
        except Exception as e:
            raise ValueError(f"Failed to load EDF file '{file_path}': File may be corrupted or not a valid EDF format. Details: {type(e).__name__}: {e}")

    def load_data_from_bdf(self, file_path: str):
        try:
            raw = mne.io.read_raw_bdf(file_path, preload=True, verbose=False)
            self._channels = len(raw.ch_names)
            self._data, self._pad_amount = self.segment_data(raw.get_data().astype(np.float32))
            self.verify_montage()
        except ValueError:
            raise
        except Exception as e:
            raise ValueError(f"Failed to load BDF file '{file_path}': File may be corrupted or not a valid BDF format. Details: {type(e).__name__}: {e}")

    def _validate_file_path(self, file_path: str) -> None:
        path = Path(file_path)

        if not path.exists():
            raise ValueError(f"File not found: '{file_path}'. Please check the file path exists.")
        if not path.is_file():
            raise ValueError(f"Path is not a file: '{file_path}'. Please provide a path to a file, not a directory.")
        if path.stat().st_size == 0:
            raise ValueError(f"File is empty: '{file_path}'. Please provide a file with EEG data.")

    def segment_data(self, data: np.ndarray) -> tuple[list[np.ndarray], int]:
        n_samples = data.shape[1]
        window_size = 1000  
        segments = []
        pad_amount = 0

        for i in range(0, n_samples, window_size):
            segment = data[:, i:i+window_size]
            if segment.shape[1] != window_size:
                pad_amount = window_size - segment.shape[1]
                pad_width = ((0, 0), (0, pad_amount))
                segment = np.pad(segment, pad_width, 'constant')
            segments.append(segment)
        return segments, pad_amount


    def verify_montage(self) -> None:
        if self._channels != 19:
            raise ValueError(f"Unsupported number of channels: {self._channels}, Scientia currently only supports the 19 channels in the 10-20 system.")