import pytest
import numpy as np
from pathlib import Path

from morphlabs.io import EEGData


@pytest.fixture
def test_data_path():
    return Path(__file__).parent / "test_data"


@pytest.fixture
def valid_edf_2500_samples(test_data_path):
    return EEGData(test_data_path / "valid_19ch_2500samples.edf")


@pytest.fixture
def valid_csv_1000_samples(test_data_path):
    return EEGData(test_data_path / "valid_19ch_1000samples.csv")


@pytest.fixture
def valid_csv_2500_samples(test_data_path):
    return EEGData(test_data_path / "valid_19ch_2500samples.csv")


@pytest.fixture
def valid_bdf_2500_samples(test_data_path):
    return EEGData(test_data_path / "valid_19ch_2500samples.bdf")


@pytest.fixture
def valid_csv_500_samples(test_data_path):
    return EEGData(test_data_path / "valid_19ch_500samples.csv")



@pytest.mark.parametrize("fixture_name", [
    "valid_edf_2500_samples",
    "valid_csv_1000_samples",
    "valid_bdf_2500_samples",
])
def test_load_file_success(fixture_name, request):
    data = request.getfixturevalue(fixture_name)
    assert data.get_data() is not None
    assert data.get_channels() == 19
    assert isinstance(data.get_data()[0], np.ndarray)


def test_load_none_success():
    data = EEGData(None)
    assert data.get_data() is None
    assert data.get_channels() is None
    assert data.get_pad_amount() is None



def test_getter_dtype(valid_csv_1000_samples, valid_edf_2500_samples):
    assert valid_edf_2500_samples.get_data()[0][0].dtype == np.float32
    assert valid_csv_1000_samples.get_data()[0][0].dtype == np.float32


def test_getter_pad_amount_no_padding(valid_csv_1000_samples):
    assert valid_csv_1000_samples.get_pad_amount() == 0


def test_getter_pad_amount_with_padding(valid_csv_500_samples):
    assert valid_csv_500_samples.get_pad_amount() == 500


def test_getter_pad_amount_range(valid_edf_2500_samples):
    assert 0 <= valid_edf_2500_samples.get_pad_amount() <= 1000


@pytest.mark.parametrize("fixture_name", [
    "valid_edf_2500_samples",
    "valid_csv_2500_samples",
    "valid_bdf_2500_samples",
])
def test_segment_data_success(fixture_name, request):
    eeg_data = request.getfixturevalue(fixture_name)
    data = eeg_data.get_data()

    assert len(data) == 3
    for segment in data:
        assert segment.shape == (19, 1000)
        assert segment[0][0].dtype == np.float32

    assert data[-1].shape[1] == 1000
    assert 0 <= eeg_data.get_pad_amount() <= 1000


def test_file_not_found(test_data_path):
    with pytest.raises(ValueError) as e:
        EEGData(test_data_path / "nonexistent_file.csv")
    assert "File not found" in str(e.value)


def test_path_is_directory(test_data_path):
    with pytest.raises(ValueError) as e:
        EEGData(test_data_path)
    assert "Path is not a file" in str(e.value)


def test_empty_file(test_data_path):
    with pytest.raises(ValueError) as e:
        EEGData(test_data_path / "empty_file.csv")
    assert "File is empty" in str(e.value)


def test_no_content_file(test_data_path):
    with pytest.raises(ValueError) as e:
        EEGData(test_data_path / "no_content.csv")
    assert "File is empty" in str(e.value)



def test_unsupported_file_type(test_data_path):
    with pytest.raises(ValueError) as e:
        EEGData(test_data_path / "invalid_file_format.txt")
    assert "Unsupported file type" in str(e.value)


@pytest.mark.parametrize("filename,channel_count", [
    ("invalid_10ch.csv", 10),
    ("invalid_32ch.csv", 32),
])
def test_unsupported_channel_count(test_data_path, filename, channel_count):
    with pytest.raises(ValueError) as e:
        EEGData(test_data_path / filename)
    assert "Unsupported number of channels" in str(e.value)



def test_corrupted_csv(test_data_path):
    with pytest.raises(ValueError) as e:
        EEGData(test_data_path / "corrupted.csv")
    assert "Failed to" in str(e.value)


def test_malformed_csv(test_data_path):
    with pytest.raises(ValueError) as e:
        EEGData(test_data_path / "malformed.csv")
    assert "Failed to parse CSV file" in str(e.value)


def test_corrupted_edf(test_data_path):
    with pytest.raises(ValueError) as e:
        EEGData(test_data_path / "corrupted.edf")
    assert "Bad EDF file provided" in str(e.value)


def test_corrupted_bdf(test_data_path):
    with pytest.raises(ValueError) as e:
        EEGData(test_data_path / "corrupted.bdf")
    assert "Bad BDF file provided" in str(e.value)


def test_invalid_encoding_csv(test_data_path):
    with pytest.raises(ValueError) as e:
        EEGData(test_data_path / "invalid_encoding.csv")
    assert "File contains invalid characters" in str(e.value)
