# morphllm

Modular AI subagents for document processing. Built for use with OpenAI-compatible APIs.

## How It Works

Subagents follow the **"Agents as Tools"** pattern—specialized secondary agents that your main agent delegates to for domain-specific tasks:

```
                              ┌─────────────────────┐
                              │     MAIN AGENT      │
                              │                     │
                              │  • Orchestrates     │
                              │  • Plans            │
                              │  • Delegates        │
                              └──────────┬──────────┘
                                         │
            ┌────────────────────────────┼────────────────────────────┐
            │                            │                            │
            ▼                            ▼                            ▼
   ┌─────────────────┐          ┌─────────────────┐          ┌─────────────────┐
   │   DOCX AGENT    │          │   PDF AGENT     │          │   YOUR AGENT    │
   │                 │          │                 │          │                 │
   │  "Review this   │          │  "Fill out      │          │  Domain-specific│
   │   contract"     │          │   this form"    │          │  capabilities   │
   └────────┬────────┘          └────────┬────────┘          └────────┬────────┘
            │                            │                            │
            ▼                            ▼                            ▼
   ┌─────────────────┐          ┌─────────────────┐          ┌─────────────────┐
   │  Track changes  │          │  Form filling   │          │  Custom tools   │
   │  Comments       │          │  Annotations    │          │  & APIs         │
   │  Document edits │          │  (Coming soon)  │          │                 │
   └─────────────────┘          └─────────────────┘          └─────────────────┘
```

## Installation

```bash
pip install morphllm
```

With OpenAI support:

```bash
pip install morphllm[openai]
```

## Available Subagents

| Subagent | Description | Status |
|----------|-------------|--------|
| **DOCX** | Track changes, comments, and document editing | Available |
| **PDF** | Form filling and annotations | Coming Soon |

## Quick Start

### DOCX Client (Direct API Access)

```python
from subagents.docx import DocxClient

client = DocxClient()

# Upload a document
doc_id = client.upload("contract.docx", user_id="user1", chat_id="chat1")

# Read content
content = client.read(doc_id)

# Add comments and track changes
client.edit(doc_id, "add_comment", para_text="Introduction", comment="Needs citation")
client.edit(doc_id, "insert_text", para_text="Introduction", after=".", new_text=" [1]")

# Download the edited document
client.download(doc_id, "contract_edited.docx")
```

### DOCX Agent (AI-Powered)

```python
from subagents.docx import DocxAgent

agent = DocxAgent(api_key="sk-...")
agent.set_document("userId/chatId/docId")

# Simple completion
response = agent.complete("Review this contract and flag any issues")
print(response)

# Full chat with history
result = agent.chat([
    {"role": "user", "content": "Add comments to unclear sections"},
])
print(result["choices"][0]["message"]["content"])

# Streaming
for chunk in agent.chat_stream([
    {"role": "user", "content": "Summarize the document"},
]):
    delta = chunk.get("choices", [{}])[0].get("delta", {})
    if "content" in delta:
        print(delta["content"], end="", flush=True)
```

### With OpenAI SDK

```python
from openai import OpenAI
from subagents.docx import DocxAgent

agent = DocxAgent()
openai = OpenAI(**agent.openai_config())

response = openai.chat.completions.create(
    model="morph-docx",
    messages=[{"role": "user", "content": "Hello!"}],
)
```

## Building Custom Subagents

Extend the base classes:

```python
from subagents.core import BaseClient, BaseAgent

class MyClient(BaseClient):
    def _default_api_url(self) -> str:
        return "https://my-api.example.com"

    def my_method(self):
        return self._get("/my-endpoint")

class MyAgent(BaseAgent):
    def _default_model(self) -> str:
        return "gpt-4"

    def _default_instructions(self) -> str:
        return "You are a helpful assistant."

    def _get_tools(self) -> list:
        return [...]

    def _execute_tool(self, name: str, args: dict) -> str:
        ...
```

## Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `DOCX_API_URL` | DOCX service URL | `https://api.subagents.com/v1/morph-docx` |
| `MORPH_API_URL` | Chat completions base URL | `https://api.subagents.com/v1` |
| `MORPH_API_KEY` | API key (optional) | |

## License

MIT
