"""
subagents - Modular AI subagents for document processing.

Available subagents:
- DOCX: Document editing with track changes and comments
- PDF: Form filling (coming soon)

Usage:
    from subagents.docx import DocxClient, DocxAgent

    # Direct API access
    client = DocxClient()
    doc_id = client.upload("contract.docx")
    content = client.read(doc_id)

    # AI-powered agent
    agent = DocxAgent(api_key="sk-...")
    response = agent.complete("Review this contract")
"""

from subagents.core import BaseClient, BaseAgent
from subagents.docx import DocxClient, DocxAgent

__version__ = "0.1.0"
__all__ = [
    "BaseClient",
    "BaseAgent",
    "DocxClient",
    "DocxAgent",
]
