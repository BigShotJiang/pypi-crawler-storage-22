"""Core base classes for subagents."""

from subagents.core.base_client import BaseClient
from subagents.core.base_agent import BaseAgent

__all__ = ["BaseClient", "BaseAgent"]
