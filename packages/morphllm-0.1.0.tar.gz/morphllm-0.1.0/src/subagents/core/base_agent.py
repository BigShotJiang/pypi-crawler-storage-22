"""BaseAgent - Abstract base class for AI subagents."""

from __future__ import annotations

import json
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Generator


@dataclass
class ToolCall:
    """Tracks a single tool invocation."""

    id: str
    name: str
    arguments: dict[str, Any]
    result: str | None = None
    error: str | None = None
    status: str = "pending"  # pending | running | completed | error


@dataclass
class AgentRunResult:
    """Result of a full agent run."""

    response: str
    tool_calls: list[ToolCall] = field(default_factory=list)


class BaseAgent(ABC):
    """Abstract agent with tool-calling loop. Requires an OpenAI-compatible client."""

    def __init__(
        self,
        openai: Any = None,
        model: str | None = None,
        instructions: str | None = None,
    ) -> None:
        self._openai = openai
        self._model = model or self._default_model()
        self._instructions = instructions or self._default_instructions()

    @abstractmethod
    def _default_model(self) -> str: ...

    @abstractmethod
    def _default_instructions(self) -> str: ...

    @abstractmethod
    def _get_tools(self) -> list[dict[str, Any]]: ...

    @abstractmethod
    def _execute_tool(self, name: str, args: dict[str, Any]) -> str: ...

    def run(
        self,
        user_message: str,
        conversation_history: list[dict[str, Any]] | None = None,
    ) -> AgentRunResult:
        """Run the agent loop until the model stops calling tools."""
        if self._openai is None:
            raise RuntimeError("OpenAI client required. Pass openai= in constructor.")

        messages: list[dict[str, Any]] = [
            {"role": "system", "content": self._instructions},
            *(conversation_history or []),
            {"role": "user", "content": user_message},
        ]
        tool_calls: list[ToolCall] = []
        tools = self._get_tools()

        while True:
            completion = self._openai.chat.completions.create(
                model=self._model,
                messages=messages,
                tools=tools,
                tool_choice="auto",
            )
            msg = completion.choices[0].message

            if msg.tool_calls:
                messages.append(msg.model_dump())
                for tc in msg.tool_calls:
                    args = json.loads(tc.function.arguments)
                    tool_call = ToolCall(
                        id=tc.id,
                        name=tc.function.name,
                        arguments=args,
                        status="running",
                    )
                    tool_calls.append(tool_call)

                    result = self._execute_tool(tc.function.name, args)

                    if result.startswith("Error:"):
                        tool_call.error = result
                        tool_call.status = "error"
                    else:
                        tool_call.result = result
                        tool_call.status = "completed"

                    messages.append(
                        {
                            "role": "tool",
                            "content": result,
                            "tool_call_id": tc.id,
                        }
                    )
            else:
                return AgentRunResult(
                    response=msg.content or "",
                    tool_calls=tool_calls,
                )

    def run_stream(
        self,
        user_message: str,
        conversation_history: list[dict[str, Any]] | None = None,
    ) -> Generator[dict[str, Any], None, None]:
        """Streaming agent loop. Yields event dicts for real-time UI."""
        if self._openai is None:
            raise RuntimeError("OpenAI client required. Pass openai= in constructor.")

        messages: list[dict[str, Any]] = [
            {"role": "system", "content": self._instructions},
            *(conversation_history or []),
            {"role": "user", "content": user_message},
        ]
        tools = self._get_tools()

        while True:
            yield {"type": "message_start", "message": {"role": "assistant"}}

            stream = self._openai.chat.completions.create(
                model=self._model,
                messages=messages,
                tools=tools,
                tool_choice="auto",
                stream=True,
            )

            content_buffer = ""
            tc_buffers: dict[int, dict[str, str]] = {}

            for chunk in stream:
                delta = chunk.choices[0].delta if chunk.choices else None
                if delta is None:
                    continue

                if delta.content:
                    content_buffer += delta.content
                    yield {"type": "content_delta", "delta": {"text": delta.content}}

                if delta.tool_calls:
                    for tc in delta.tool_calls:
                        idx = tc.index
                        buf = tc_buffers.setdefault(idx, {"id": "", "name": "", "arguments": ""})
                        if tc.id:
                            buf["id"] = tc.id
                        if tc.function and tc.function.name:
                            buf["name"] = tc.function.name
                        if tc.function and tc.function.arguments:
                            buf["arguments"] += tc.function.arguments

            if tc_buffers:
                messages.append({"role": "assistant", "content": content_buffer})
                for buf in tc_buffers.values():
                    args = json.loads(buf["arguments"])
                    yield {"type": "tool_start", "tool": {"id": buf["id"], "name": buf["name"], "arguments": args}}

                    result = self._execute_tool(buf["name"], args)

                    if result.startswith("Error:"):
                        yield {"type": "tool_end", "tool": {"id": buf["id"], "error": result}}
                    else:
                        yield {"type": "tool_end", "tool": {"id": buf["id"], "result": result}}

                    messages.append({"role": "tool", "content": result, "tool_call_id": buf["id"]})
            else:
                yield {"type": "message_end"}
                break
