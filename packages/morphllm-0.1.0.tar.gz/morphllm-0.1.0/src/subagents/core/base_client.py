"""BaseClient - Abstract HTTP client for subagent APIs."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

import httpx


class BaseClient(ABC):
    """Abstract base HTTP client. Subclass and implement `_default_api_url`."""

    def __init__(
        self,
        api_url: str | None = None,
        timeout: float = 60.0,
    ) -> None:
        self._api_url = api_url or self._default_api_url()
        self._http = httpx.Client(base_url=self._api_url, timeout=timeout)

    @abstractmethod
    def _default_api_url(self) -> str:
        """Return the default API URL for this client."""

    def _get(self, path: str) -> Any:
        response = self._http.get(path)
        response.raise_for_status()
        return response.json()

    def _post(self, path: str, json: Any = None, **kwargs: Any) -> Any:
        response = self._http.post(path, json=json, **kwargs)
        response.raise_for_status()
        return response.json()

    def _delete(self, path: str) -> None:
        response = self._http.delete(path)
        response.raise_for_status()

    def _download(self, path: str) -> bytes:
        response = self._http.get(path)
        response.raise_for_status()
        return response.content

    def health(self) -> dict[str, str]:
        """Health check."""
        return self._get("/health")

    def close(self) -> None:
        """Close the HTTP client."""
        self._http.close()

    def __enter__(self) -> BaseClient:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()
