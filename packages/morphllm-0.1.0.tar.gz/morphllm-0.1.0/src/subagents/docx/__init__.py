"""DOCX document editing subagent - track changes, comments, and more."""

from subagents.docx.client import DocxClient
from subagents.docx.agent import DocxAgent

__all__ = ["DocxClient", "DocxAgent"]
