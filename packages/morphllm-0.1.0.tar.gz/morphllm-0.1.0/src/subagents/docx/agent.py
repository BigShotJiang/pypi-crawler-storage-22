"""DocxAgent - AI agent for DOCX document editing via api.subagents.com."""

from __future__ import annotations

import json
import os
from typing import Any, AsyncGenerator, Generator

import httpx

_DEFAULT_BASE_URL = "https://api.subagents.com/v1"


class DocxAgent:
    """
    AI-powered DOCX agent that talks to api.subagents.com/v1/chat/completions.

    The server runs the full agent loop (tool calling, document edits) and
    returns the final response. This is an OpenAI-compatible chat client
    tuned for the ``morph-docx`` model.

    Usage::

        from subagents.docx import DocxAgent

        agent = DocxAgent(api_key="sk-...")
        agent.set_document("userId/chatId/uuid")
        response = agent.complete("Review this contract and add comments")
        print(response)

    With OpenAI SDK::

        from openai import OpenAI
        from subagents.docx import DocxAgent

        agent = DocxAgent()
        openai = OpenAI(**agent.openai_config())

        resp = openai.chat.completions.create(
            model="morph-docx",
            messages=[{"role": "user", "content": "Hello!"}],
        )
    """

    def __init__(
        self,
        base_url: str | None = None,
        api_key: str | None = None,
        document_id: str | None = None,
        user_id: str | None = None,
        chat_id: str | None = None,
    ) -> None:
        self._base_url = base_url or os.environ.get("MORPH_API_URL", _DEFAULT_BASE_URL)
        self._api_key = api_key or os.environ.get("MORPH_API_KEY", "")
        self._document_id = document_id
        self._user_id = user_id
        self._chat_id = chat_id
        self._http = httpx.Client(timeout=120.0)

    def set_document(self, doc_id: str) -> None:
        """Set the active document ID."""
        self._document_id = doc_id

    @property
    def document_id(self) -> str | None:
        return self._document_id

    def set_context(self, user_id: str, chat_id: str) -> None:
        """Set user/chat context for document isolation."""
        self._user_id = user_id
        self._chat_id = chat_id

    def _auth_headers(self) -> dict[str, str]:
        headers: dict[str, str] = {"Content-Type": "application/json"}
        if self._api_key:
            headers["Authorization"] = f"Bearer {self._api_key}"
        return headers

    def _inject_doc_context(self, messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Prepend document ID to the last user message if set."""
        if not self._document_id:
            return messages
        out = list(messages)
        for i in range(len(out) - 1, -1, -1):
            if out[i].get("role") == "user":
                out[i] = {**out[i], "content": f"[Document ID: {self._document_id}]\n\n{out[i]['content']}"}
                break
        return out

    def chat(self, messages: list[dict[str, Any]], stream: bool = False) -> dict[str, Any]:
        """
        Send a chat completion request (non-streaming).

        Returns the full OpenAI-compatible response dict.
        """
        payload: dict[str, Any] = {
            "model": "morph-docx",
            "messages": self._inject_doc_context(messages),
            "stream": False,
        }
        if self._user_id:
            payload["user_id"] = self._user_id
        if self._chat_id:
            payload["chat_id"] = self._chat_id
        if self._document_id:
            payload["document_id"] = self._document_id

        response = self._http.post(
            f"{self._base_url}/chat/completions",
            headers=self._auth_headers(),
            json=payload,
        )
        response.raise_for_status()
        return response.json()

    def chat_stream(self, messages: list[dict[str, Any]]) -> Generator[dict[str, Any], None, None]:
        """
        Streaming chat completion. Yields parsed SSE chunks.
        """
        payload: dict[str, Any] = {
            "model": "morph-docx",
            "messages": self._inject_doc_context(messages),
            "stream": True,
        }
        if self._user_id:
            payload["user_id"] = self._user_id
        if self._chat_id:
            payload["chat_id"] = self._chat_id
        if self._document_id:
            payload["document_id"] = self._document_id

        with self._http.stream(
            "POST",
            f"{self._base_url}/chat/completions",
            headers=self._auth_headers(),
            json=payload,
        ) as response:
            response.raise_for_status()
            buffer = ""
            for text in response.iter_text():
                buffer += text
                while "\n" in buffer:
                    line, buffer = buffer.split("\n", 1)
                    line = line.strip()
                    if not line.startswith("data: "):
                        continue
                    data = line[6:].strip()
                    if data == "[DONE]":
                        return
                    try:
                        yield json.loads(data)
                    except json.JSONDecodeError:
                        pass

    def complete(self, user_message: str) -> str:
        """Simple helper: send a message, get the response text."""
        result = self.chat([{"role": "user", "content": user_message}])
        choices = result.get("choices", [])
        if choices:
            return choices[0].get("message", {}).get("content", "")
        return ""

    def openai_config(self) -> dict[str, str]:
        """
        Return kwargs for ``openai.OpenAI(...)`` that point at this API.

        Usage::

            from openai import OpenAI
            openai = OpenAI(**agent.openai_config())
        """
        return {
            "base_url": self._base_url,
            "api_key": self._api_key or "not-required",
        }

    def close(self) -> None:
        self._http.close()

    def __enter__(self) -> DocxAgent:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()
