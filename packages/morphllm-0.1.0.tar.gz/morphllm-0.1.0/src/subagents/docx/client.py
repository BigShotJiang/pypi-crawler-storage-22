"""DocxClient - HTTP client for the DOCX document API."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

from subagents.core.base_client import BaseClient

_DEFAULT_API_URL = "https://api.subagents.com/v1/morph-docx"


class DocxClient(BaseClient):
    """
    HTTP client for the DOCX API at api.subagents.com.

    Handles upload, download, read, edit, build, and validate operations.

    Usage::

        from subagents.docx import DocxClient

        client = DocxClient()
        doc_id = client.upload("contract.docx", user_id="u1", chat_id="c1")
        content = client.read(doc_id)
        client.edit(doc_id, "add_comment", para_text="Introduction", comment="Needs citation")
        client.download(doc_id, "edited.docx")
    """

    def __init__(
        self,
        api_url: str | None = None,
        timeout: float = 60.0,
        user_id: str | None = None,
        chat_id: str | None = None,
    ) -> None:
        super().__init__(api_url=api_url, timeout=timeout)
        self._user_id = user_id
        self._chat_id = chat_id

    def _default_api_url(self) -> str:
        return os.environ.get("DOCX_API_URL", _DEFAULT_API_URL)

    def set_context(self, user_id: str, chat_id: str) -> None:
        """Set user/chat context for document isolation."""
        self._user_id = user_id
        self._chat_id = chat_id

    def _context_headers(self) -> dict[str, str]:
        headers: dict[str, str] = {}
        if self._user_id:
            headers["X-User-Id"] = self._user_id
        if self._chat_id:
            headers["X-Chat-Id"] = self._chat_id
        return headers

    # --- Core Operations ---

    def upload(self, file_path: str, user_id: str | None = None, chat_id: str | None = None) -> str:
        """
        Upload a DOCX file.

        Returns:
            Composite document ID (userId/chatId/uuid).
        """
        path = Path(file_path)
        if not path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")

        headers = {}
        if user_id or self._user_id:
            headers["X-User-Id"] = user_id or self._user_id  # type: ignore[assignment]
        if chat_id or self._chat_id:
            headers["X-Chat-Id"] = chat_id or self._chat_id  # type: ignore[assignment]

        with open(path, "rb") as f:
            response = self._http.post(
                "/documents/upload",
                headers=headers,
                files={"file": (path.name, f, "application/vnd.openxmlformats-officedocument.wordprocessingml.document")},
            )
        response.raise_for_status()
        return response.json()["doc_id"]

    def download(self, doc_id: str, output_path: str, version: int | None = None) -> None:
        """Download a document to a local file."""
        url = f"/documents/{doc_id}/download"
        if version is not None:
            url += f"?version={version}"
        data = self._download(url)
        Path(output_path).write_bytes(data)

    def read(self, doc_id: str) -> str:
        """Read document content as plain text."""
        result = self._post(f"/documents/{doc_id}/read")
        return result["content"]

    def edit(self, doc_id: str, op_type: str, **kwargs: Any) -> str:
        """
        Execute an edit operation (track changes, comments).

        Args:
            doc_id: Document ID.
            op_type: One of add_comment, reply_comment, resolve_comment,
                     delete_comment, insert_text, insert_paragraph,
                     propose_deletion, reject_insertion, restore_deletion,
                     enable_track_changes.
            **kwargs: Operation-specific parameters.
        """
        params = {k: v for k, v in kwargs.items() if v is not None}
        result = self._post(f"/documents/{doc_id}/edit", json={"operations": [{"type": op_type, **params}]})
        results = result["results"]
        return results[0] if results else "success"

    def validate(self, doc_id: str) -> dict[str, Any]:
        """Validate document structure. Returns dict with valid, result, output, errors."""
        return self._post(f"/documents/{doc_id}/validate")

    def delete(self, doc_id: str) -> None:
        """Delete a document from storage."""
        self._delete(f"/documents/{doc_id}/delete")

    # --- Creation Operations ---

    def create(self, title: str | None = None, user_id: str | None = None, chat_id: str | None = None) -> str:
        """Create a new empty DOCX document. Returns doc_id."""
        headers: dict[str, str] = {}
        uid = user_id or self._user_id or "default"
        cid = chat_id or self._chat_id or "default"
        headers["X-User-Id"] = uid
        headers["X-Chat-Id"] = cid

        response = self._http.post(
            "/documents/create",
            headers=headers,
            json={"title": title},
        )
        response.raise_for_status()
        return response.json()["doc_id"]

    def build(self, doc_id: str, op_type: str, **kwargs: Any) -> str:
        """
        Execute a build operation (add content to document).

        Args:
            doc_id: Document ID.
            op_type: One of add_heading, add_paragraph, add_table, add_image,
                     add_list_item, add_hyperlink, add_page_break, add_section_break,
                     add_header, add_footer, add_page_numbers, setup_styles,
                     add_signature_line, add_pie_chart, add_bar_chart, add_line_chart,
                     add_table_of_contents, add_footnote, add_bookmark, add_cross_reference,
                     configure_section, set_columns, etc.
            **kwargs: Operation-specific parameters.
        """
        params = {k: v for k, v in kwargs.items() if v is not None}
        result = self._post(f"/documents/{doc_id}/build", json={"operations": [{"type": op_type, **params}]})
        results = result["results"]
        return results[0] if results else "success"

    def get_info(self, doc_id: str) -> dict[str, Any]:
        """Get document info (paragraphs, tables, sections, title, etc.)."""
        return self._get(f"/documents/{doc_id}/info")

    # --- Convenience Methods ---

    def add_heading(self, doc_id: str, text: str, level: int = 1) -> str:
        """Add a heading."""
        return self.build(doc_id, "add_heading", text=text, level=level)

    def add_paragraph(self, doc_id: str, text: str, **kwargs: Any) -> str:
        """Add a paragraph."""
        return self.build(doc_id, "add_paragraph", text=text, **kwargs)

    def add_table(self, doc_id: str, headers: list[str], rows: list[list[str]]) -> str:
        """Add a table."""
        return self.build(doc_id, "add_table", headers=headers, rows=rows)

    def add_page_numbers(self, doc_id: str, format_string: str = "Page {PAGE} of {NUMPAGES}") -> str:
        """Add page numbers."""
        return self.build(doc_id, "add_page_numbers", format_string=format_string)

    def add_signature_line(
        self,
        doc_id: str,
        signer_name: str | None = None,
        signer_title: str | None = None,
        signer_email: str | None = None,
    ) -> str:
        """Add a Microsoft Word signature line."""
        return self.build(
            doc_id,
            "add_signature_line",
            signer_name=signer_name,
            signer_title=signer_title,
            signer_email=signer_email,
        )

    # --- Version Management ---

    def list_versions(self, doc_id: str) -> dict[str, Any]:
        """List all versions of a document."""
        return self._get(f"/documents/{doc_id}/versions")

    def rollback(self, doc_id: str, version: int) -> dict[str, Any]:
        """Rollback to a specific version."""
        return self._post(f"/documents/{doc_id}/rollback", json={"version": version})
