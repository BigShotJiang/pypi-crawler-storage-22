__all__ = ['GlobalConfig']

class GlobalConfig:
	uses_scaled_arctap: bool = False
	allows_kr_langcode: bool = False
	min_rating_with_plus: int = 8