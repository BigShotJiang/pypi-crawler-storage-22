from .colors_utils import *
from .df_utils import *
from .doc_utils import *
from .excel_utils import *
from .pdf_utils import *
from .ppt_utils import *
from .py_utils import *
from .shapes_utils import *