"""Tests for core matching."""
