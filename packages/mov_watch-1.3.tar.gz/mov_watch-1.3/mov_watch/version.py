# Version info for mov-watch
# THIS IS THE SINGLE SOURCE OF TRUTH FOR VERSION
# All other files (pyproject.toml, workflows, etc.) read from here

__version__ = "1.3"

APP_VERSION = f"v{__version__}"
APP_NAME = "mov-watch"
GITHUB_REPO = "leoallday/mov-watch"
RELEASES_URL = f"https://github.com/{GITHUB_REPO}/releases"
API_RELEASES_URL = f"https://api.github.com/repos/{GITHUB_REPO}/releases/latest"
