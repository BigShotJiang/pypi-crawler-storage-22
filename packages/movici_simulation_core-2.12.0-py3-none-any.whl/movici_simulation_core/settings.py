from __future__ import annotations

import tempfile
import typing as t
from pathlib import Path

from pydantic import DirectoryPath, Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

from movici_simulation_core.core.moment import TimelineInfo
from movici_simulation_core.utils.lifecycle import deprecation_warning


class Settings(BaseSettings):
    data_dir: DirectoryPath = Path(".")
    log_level: str = Field(default="INFO", validation_alias="loglevel")
    log_format: str = Field(
        default="[{asctime}] [{levelname:8s}] {name:17s}: {message}", validation_alias="logformat"
    )
    name: str = ""
    storage: t.Literal["api", "file", "sqlite"] = "file"
    storage_dir: t.Optional[Path] = None
    temp_dir: DirectoryPath = Path(tempfile.gettempdir())

    reference: float = 0
    time_scale: float = 1
    start_time: int = 0
    duration: int = 0

    datasets: t.List[dict] = Field(default_factory=list)
    model_names: t.List[str] = Field(default_factory=list)
    models: t.List[dict] = Field(default_factory=list)
    service_types: t.List[str] = Field(default_factory=list)
    scenario_config: t.Optional[dict] = Field(default=None)
    service_discovery: t.Dict[str, str] = Field(default_factory=dict)

    # pydantic settings. the "model_" here has nothing to do with movici models, but with pydantic
    model_config = SettingsConfigDict(env_prefix="movici_")

    def apply_scenario_config(self, config: dict):
        self.scenario_config = config
        if simulation_info := config.get("simulation_info"):
            if simulation_info.pop("mode", "time_oriented") == "time_oriented":
                self.start_time = simulation_info["start_time"]
                self.time_scale = simulation_info["time_scale"]
                self.reference = simulation_info["reference_time"]
                self.duration = simulation_info["duration"]
        self.models = config.get("models", [])
        self.model_names = [model["name"] for model in self.models]
        self.service_types = config.get("services", [])
        self.datasets = config.get("datasets", [])

    # Dataclasses in pydantic Models don't pickle properly
    # (https://github.com/samuelcolvin/pydantic/issues/3453). This is fine in Linux as we use
    # forked processes (which bypasses the issues), but in Windows that is not available. So
    # instead, as a workaround, we use a property to pack and unpack the TimelineInfo dataclass
    # into its fields.
    #

    @property
    def timeline_info(self):
        return TimelineInfo(
            start_time=self.start_time,
            time_scale=self.time_scale,
            reference=self.reference,
            duration=self.duration,
        )

    @timeline_info.setter
    def timeline_info(self, timeline_info: TimelineInfo):
        self.start_time = timeline_info.start_time
        self.time_scale = timeline_info.time_scale
        self.reference = timeline_info.reference
        self.duration = timeline_info.duration

    @field_validator("storage", mode="before")
    @classmethod
    def check_deprecated_storage(cls, value: str):
        if value == "disk":
            deprecation_warning("'disk' storage is deprecated, use 'file' instead")
            value = "file"
        return value
