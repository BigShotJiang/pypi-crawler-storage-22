from .condition import Condition


class Prop:
    __slots__ = ("k",)

    def __init__(self, k: str):
        self.k = k

    def __eq__(self, v):
        return Condition(self.k, "=", v)

    def __gt__(self, v):
        return Condition(self.k, ">", v)

    def __lt__(self, v):
        return Condition(self.k, "<", v)

    def __ge__(self, v):
        return Condition(self.k, ">=", v)

    def __le__(self, v):
        return Condition(self.k, "<=", v)

    def _is(self, v):
        return Condition(self.k, "=", v)

    def contains(self, v):
        return Condition(self.k, "~", v)

    def not_contains(self, v):
        return Condition(self.k, "!~", v)

    def startswith(self, v):
        return Condition(self.k, "~=", v)

    def endswith(self, v):
        return Condition(self.k, "=~", v)

    def empty(self):
        return Condition(self.k, "=", None)
