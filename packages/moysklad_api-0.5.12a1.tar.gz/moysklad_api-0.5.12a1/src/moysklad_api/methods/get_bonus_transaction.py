from collections.abc import Sequence

from pydantic import Field

from ..filters.condition import Condition
from ..methods import MSMethod
from ..types import BonusTransaction


class GetBonusTransaction(MSMethod):
    __return__ = BonusTransaction
    __api_method__ = "entity/bonustransaction"

    id: str = Field(..., alias="bonustransaction_id")
    limit: int | None = None
    offset: int | None = None
    expand: Sequence[str] | str | None = None
    filters: Condition | Sequence[Condition] | None = None
