from collections.abc import Sequence

from ..filters.condition import Condition
from ..methods import MSMethod
from ..types import Counterparty, MetaArray


class GetCounterparties(MSMethod):
    __return__ = MetaArray[Counterparty]
    __api_method__ = "entity/counterparty"

    limit: int | None = None
    offset: int | None = None
    expand: Sequence[str] | str | None = None
    filters: Condition | Sequence[Condition] | None = None
