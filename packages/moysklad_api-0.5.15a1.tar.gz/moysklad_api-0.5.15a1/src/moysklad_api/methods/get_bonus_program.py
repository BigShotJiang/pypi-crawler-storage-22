from collections.abc import Sequence

from pydantic import Field

from ..filters.condition import Condition
from ..methods import MSMethod
from ..types import BonusProgram


class GetBonusProgram(MSMethod):
    __return__ = BonusProgram
    __api_method__ = "entity/bonusprogram"

    id: str = Field(..., alias="bonusprogram_id")
    limit: int | None = None
    offset: int | None = None
    expand: Sequence[str] | str | None = None
    filters: Condition | Sequence[Condition] | None = None
