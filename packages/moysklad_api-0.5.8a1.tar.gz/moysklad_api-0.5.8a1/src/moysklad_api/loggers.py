import logging


session = logging.getLogger("moysklad_api.session")
api = logging.getLogger("moysklad_api")
