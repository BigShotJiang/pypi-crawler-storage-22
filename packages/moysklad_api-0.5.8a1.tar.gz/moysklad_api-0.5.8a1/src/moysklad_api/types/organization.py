from .entity import Entity


class Organization(Entity):
    pass
