from .entity import Entity


class SalesChannel(Entity):
    pass
