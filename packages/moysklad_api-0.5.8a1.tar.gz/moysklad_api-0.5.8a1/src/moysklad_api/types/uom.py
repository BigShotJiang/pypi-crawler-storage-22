from .entity import Entity


class Uom(Entity):
    pass
