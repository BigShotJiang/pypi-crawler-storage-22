from typing import List

from pydantic import BaseModel

from mpets.models.BaseResponse import BaseResponse


class GoldChestReward(BaseModel):
    pet_id: int
    name: str
    reward: str


class GoldChestResponse(BaseResponse):
    status: bool
    amount_keys: int
    rewards: List[GoldChestReward]
