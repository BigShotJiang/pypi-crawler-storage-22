# Agent Guide for mpl-plot-report

This repo is a small Python package intended to export Matplotlib plot reports
as JSON + Markdown sidecars. The guidance here is for agentic coding tools.

## Quick Start

- Python version: 3.13 (see `.python-version`).
- Dependencies are tracked in `pyproject.toml` and `uv.lock`.
- If you use `uv`, prefer `uv sync` or `uv run ...`.
- If you use `pip`, create a venv and install from `pyproject.toml`.

## Build / Lint / Test

The project is currently very small and uses `pytest` and `black`.

### Install / Sync

- `uv sync`
- `python -m venv .venv && . .venv/bin/activate && pip install -e .[dev]`

### Tests

- Run all tests: `uv run pytest` or `python -m pytest`
- Run a single file: `uv run pytest tests/test_module.py`
- Run a single test: `uv run pytest tests/test_module.py::TestClass::test_name`
- Run by keyword: `uv run pytest -k "keyword"`

### Lint / Format

- Format: `uv run black .` or `python -m black .`
- Check formatting: `uv run black --check .`

### Build / Packaging

This repository is not yet wired with a build tool, but common options are:

- `uv build` (if using uv)
- `python -m build` (requires `build` dependency)

If you need to add a build step, update this file with the exact command.

## Cursor / Copilot Rules

No Cursor rules found in `.cursor/rules/` or `.cursorrules`.
No Copilot instructions found in `.github/copilot-instructions.md`.

## Code Style Guidelines

This repo is early-stage; prefer simple, explicit Python with a focus on
determinism and readability. Use the following conventions unless a file
explicitly establishes something else.

### Formatting

- Use Black defaults (4-space indents, line length per Black).
- Keep imports sorted in logical groups (stdlib, third-party, local).
- Avoid trailing whitespace and excessive blank lines.
- Prefer short, descriptive lines over dense one-liners.

### Imports

- Group imports with a blank line between groups.
- Favor module imports over wildcard imports.
- Keep Matplotlib usage explicit: `import matplotlib.pyplot as plt`.
- Keep NumPy usage explicit: `import numpy as np`.

### Types

- Add type hints for public APIs and data structures.
- Use `typing` module constructs where helpful (e.g., `Sequence`, `Mapping`).
- Prefer `dict[str, Any]` or `Mapping[str, Any]` for free-form context.
- Use `dataclasses` for schema-like objects when appropriate.

### Naming

- Functions and variables: `snake_case`.
- Classes and dataclasses: `PascalCase`.
- Constants: `UPPER_SNAKE_CASE`.
- Keep rule/diagnostic identifiers stable and deterministic.

### Error Handling

- Fail fast on invariant violations when appropriate.
- Use exceptions for programmer errors; return structured warnings for data
  issues that should not crash the exporter.
- Report non-fatal issues in the report `warnings[]` field.
- Prefer explicit error messages over silent fallbacks.

### Determinism and Reproducibility

- Stable ordering: axes by `fig.axes`, series by `ax.lines`.
- Stable IDs: derive from axis index + series index + label.
- Numeric rounding must be controlled by a single `float_precision` parameter.
- Use a deterministic decimation strategy when `n > max_points`.

### JSON + Markdown Outputs

- Always emit `<stem>.plot.json` and `<stem>.plot.md` sidecars.
- Keep the schema version pinned and documented.
- Prefer predictable key ordering when serializing.

### Matplotlib / Headless

- Use the Agg backend for test figures and headless runs.
- PNGs are secondary; JSON is the source of truth for agents.

### Diagnostics and Invariants

- Diagnostics are numeric and data-driven, not visual.
- Invariants encode expectations, not observations.
- Domain-specific rules must remain in consumer projects.
- Report FAIL invariants first; WARN invariants must include rationale.

### Tests and Fixtures

- Tests should be deterministic and fast.
- Prefer small synthetic fixtures for core engine tests.
- Keep fixtures in `tests/fixtures/` (synthetic, expected, curated).
- Avoid brittle golden-value assertions until the schema stabilizes.

## Agent Workflow Requirements (from `agent.md`)

Use this as the default workflow when adding or modifying behavior.

1) Generate 2-3 minimal figures for smoke/regression:
   - Happy path line plot (strictly increasing x, smooth y)
   - Pathology with NaNs/inf and non-monotonic x
   - Pathology with wiggles/jumps/outliers
2) Export sidecars for each figure:
   - PNG
   - `.plot.json`
   - `.plot.md`
3) Inspect JSON before PNGs:
   - FAIL invariants first
   - WARN invariants next
   - Diagnostics for rationale
4) Propose fixes, re-run, compare reports.

CI / regression intent:

- Store `.plot.json` fixtures for the 2-3 minimal figures.
- CI should assert zero FAILs on happy path.
- CI should assert expected FAIL/WARN signatures on pathology cases.
- Use JSON diffs for regression review.

Escalation policy:

- FAIL invariants: stop and propose fix.
- WARN invariants: justify or refine rule.
- Clean report: accept plot without image review.

## Preferred Structure (from docs)

The implementation plan proposes this layout (once implemented):

- `mpl_plot_report/api.py`: `dump_report()` and `build_report()`
- `mpl_plot_report/extract.py`: figure/axes/line extraction
- `mpl_plot_report/diagnostics.py`: numeric metrics
- `mpl_plot_report/rules.py`: `Rule`, `RuleResult`, `RuleSet`
- `mpl_plot_report/schema.py`: dataclasses + schema version
- `mpl_plot_report/render_md.py`: Markdown renderer
- `mpl_plot_report/util.py`: hashing/rounding/decimation

If you add these files, follow the conventions above.

## README Expectations (future)

Once core API and tests are stable, update `README.md` with:

- Installation (uv/pip)
- Minimal usage snippet calling `dump_report`
- Expected output files (`.png`, `.plot.json`, `.plot.md`)
- How to supply a consumer `ruleset`
- How to run tests and where fixtures live

## Notes for Agents

- Favor clear, minimal diffs; avoid large refactors unless required.
- Keep the engine domain-neutral; do not encode project-specific rules.
- Prefer small, composable helpers over monolithic functions.
- When in doubt, document the reasoning in the report output.
