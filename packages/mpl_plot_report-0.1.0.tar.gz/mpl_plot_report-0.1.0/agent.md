## Agent Workflow — Plot Report Sidecars

### Objective
Enable blind-friendly, deterministic critique of plots by agents using structured plot reports instead of rendered images.

---

### Minimal Test Figures (agent-generated)
The agent should generate 2–3 figures as a smoke/regression harness for the plot-report engine:

1) **Happy path line plot**
- x strictly increasing
- smooth y
- should produce zero FAILs and minimal WARNs

2) **Pathology: NaNs / inf / ordering**
- inject NaNs or inf in y
- optionally shuffle a segment of x (non-monotonic)
- should surface non-finite warnings and ordering/dx invariants

3) **Pathology: wiggles / jumps / outliers**
- piecewise y with a step/jump + high-frequency wiggle region
- should trigger outlier metrics and wiggle/curvature diagnostics

These plots must be generated headlessly (Agg) and exported to:
- PNG
- `.plot.json`
- `.plot.md`

---

### Standard Debugging Loop

1. **Run** plotting code to generate figures
2. **Export** sidecar reports:
   - `<stem>.plot.json`
   - `<stem>.plot.md`
3. **Agent inspects JSON**:
   - invariant failures (FAIL first)
   - warnings (NaN, decimation, ordering issues)
   - suspicious diagnostics (wiggles, slope variance, outliers)
4. **Agent proposes changes**:
   - data corrections (ordering, NaN handling)
   - plotting fixes (scale, limits, labels, units)
   - invariant refinements (domain rules, if any)
5. **Re-run and compare** reports

---

### What the Agent Should Rely On

- JSON report as the primary truth
- Invariant results as correctness signals
- Diagnostics to explain *why* something failed

PNG viewing is secondary and optional.

---

### What the Agent Must Avoid

- Judging correctness from PNGs alone
- Guessing intent without reading invariants
- Adding domain rules to the generic engine

---

### CI / Regression Strategy

- Store `.plot.json` fixtures for the 2–3 test figures above
- CI asserts:
  - zero FAIL invariants for the happy-path figure
  - expected FAIL/WARN signatures for pathology figures
- JSON diffs used for regression review

---

### Escalation Policy

- FAIL invariants → stop and propose fix
- WARN invariants → justify or refine rule
- Clean report → accept plot without image review

---

### After Green Tests

Once the package implementation is complete and tests pass:
- Draft a practical `README.md` for the standalone repo covering:
  - installation (uv/pip)
  - minimal Python usage (one small snippet calling `dump_report`)
  - expected output files (`.png`, `.plot.json`, `.plot.md`)
  - how to supply a `ruleset` from a consumer project
  - how to run tests and where fixtures live

