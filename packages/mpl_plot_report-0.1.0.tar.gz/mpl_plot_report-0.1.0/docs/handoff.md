# Handoff — Make `.plot.md` verbose, explicit, and agent-friendly

## Objective
Upgrade `mpl_plot_report` so the generated Markdown sidecar (`<stem>.plot.md`) is **useful on its own** for both humans and agents.

Current behavior is too minimal when there are no warnings/invariants; it often prints only counts and headings.

Target behavior:
- `.plot.json` remains the source of truth
- `.plot.md` becomes a structured, readable projection of the JSON
- Do **not** dump full point arrays; include summaries and optional small samples
- Include a link/embed reference to the PNG so a human can open it quickly

---

## Required `.plot.md` content (v1)

### 0) Header
Include:
- Title: `<stem>`
- Timestamp / run_id (from `context`)
- git_hash (from `context`, if present)
- inputs + key parameters (from `context`)
- style identity: style name + rcParams hash (from `context.style`)

### 1) PNG reference
Add a prominent section near the top:
- If PNG is in the same folder: include markdown image reference `![](<stem>.png)`
  - This works on GitHub-rendered markdown and many viewers.
- Also include a plain path line for non-rendering environments.

### 2) Warnings
- Always print a `Warnings` section.
- If empty, explicitly print `None`.

### 3) Invariants / Rules
- Always print an `Invariant Results` section.
- Show FAIL first, then WARN, then PASS (if present).
- For each result:
  - rule_id
  - severity
  - passed
  - message
  - where (axis index, series id/label, index ranges)

### 4) Axes details (per axis)
For each axis, print:
- title
- xlabel / ylabel
- xscale / yscale
- xlim / ylim
- legend entries (or `None`)

### 5) Series details (per series)
For each series (v1: `Line2D`):
- series id
- label
- kind

**Stats**
- n
- x_min/x_max, y_min/y_max
- first point / last point

**Diagnostics** (print all fields in a stable order)
- Non-finite: count + indices/ranges if available
- dx sanity: min/median/non-positive count
- dy outliers: max |dy|, robust z max, outlier count
- slope stats: mean/median/std + quantiles if present
- wiggles: sign-change count, wiggle score
- curvature: std, max abs, sign changes

**Data sample (optional but recommended)**
- If `include_data=True`, do not dump full arrays.
- Print:
  - decimation info (original_n, max_points, method)
  - first 5 (x,y) pairs
  - last 5 (x,y) pairs

### 6) JSON echo (optional)
If you want “expose all JSON data” without full points:
- Add a final section `Raw JSON (minus points)`
- Print a pretty JSON block where `series[].data.x` and `series[].data.y` are replaced with:
  - `{"omitted": true, "n": <n>, "sample": {"head": [...], "tail": [...]}}`

This makes MD self-contained while avoiding megabytes of data.

---

## API changes (allowed)
Keep existing API stable. If you add knobs, make them optional:

- `md_mode: Literal["summary","full"] = "full"` (default to full to satisfy this spec)
- `md_data_sample: int = 5` (head/tail sample size)
- `md_include_png_embed: bool = True`

No breaking changes.

---

## Implementation notes

### Where to implement
- `mpl_plot_report/render_md.py`
  - Add a `render_report_full(report: dict, *, stem: str | None = None, md_data_sample: int = 5, md_include_png_embed: bool = True) -> str`
  - Keep the existing renderer as `summary` or remove if unused.

### Stable ordering
Make the Markdown diff-friendly:
- Use deterministic ordering for:
  - axes
  - series
  - diagnostic keys (define an explicit list)

### Avoid point dumps
Even if JSON contains decimated points, MD should only show head/tail samples.

---

## Tests to add

1) `test_md_full_has_required_sections`
- Generate the happy-path synthetic figure
- Assert `.plot.md` includes:
  - PNG embed line
  - Context header fields
  - Warnings section
  - Invariant Results section
  - Axes and Series sections

2) `test_md_reports_nonfinite_and_ordering`
- Generate pathology figure (NaN + non-monotonic x)
- Assert `.plot.md` contains:
  - non-finite count > 0
  - dx_non_positive_count > 0 (or equivalent)
  - warning(s)

3) `test_md_does_not_dump_full_arrays`
- Generate a long series (n >> max_points)
- Assert `.plot.md` length stays under a reasonable bound or that it contains `head`/`tail` samples and does not contain thousands of comma-separated floats.

---

## Definition of done
- `.plot.md` is substantially informative even when warnings/invariants are empty.
- PNG is referenced at top.
- All diagnostics visible (not hidden in JSON only).
- Point arrays not dumped; only samples.
- Tests pass headlessly.

---

## After this task
Once the MD verbosity upgrade is complete and tests pass:
- Draft `README.md` for the repo:
  - installation (uv/pip)
  - minimal usage example calling `dump_report`
  - explain the 3 artifacts (`.png`, `.plot.json`, `.plot.md`)
  - how to inject a `ruleset` from consumer projects
  - how to run tests + fixtures layout

