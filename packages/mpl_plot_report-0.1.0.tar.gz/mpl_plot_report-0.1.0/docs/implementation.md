## Plot Report Engine — Implementation Plan

### Package Boundaries

**Generic (reusable):** `mpl_plot_report`
- Figure / axes / artist extraction
- Numeric diagnostics
- Invariant rule engine
- JSON + Markdown renderers

**Project‑specific (external / plugins):**
- Domain invariants (e.g. frequency bounds, damping bounds, decay expectations)
- Rule sets live outside this package and are injected at runtime

---

### Suggested File Layout

**Generic package:**
```
mpl_plot_report/
  __init__.py
  api.py           # dump_report(), build_report()
  extract.py       # figure / axes / line extraction
  diagnostics.py   # numeric metrics
  rules.py         # Rule, RuleResult, RuleSet
  schema.py        # dataclasses + schema version
  render_md.py     # Markdown rendering
  util.py          # hashing, rounding, decimation, stable IDs
```

**External usage example (not part of this repo):**
```
<consumer_project>/
  plot_rules/
    common.py      # domain bounds
    kinds/
      frf.py
      decay.py
      energy.py
```
```

Notes:
- The **plot report engine** stays fully standalone in `mpl_plot_report`.
- Domain rules are provided by the consumer project as a `ruleset` object or small rules module.
```

---

### Minimal Public API (v1)

```python
dump_report(
    fig,
    out_dir,
    stem,
    *,
    context: dict,
    ruleset=None,
    include_data=True,
    max_points=2000,
    float_precision=6,
) -> dict
```

Optional wrapper:
```python
FigureReport(fig, context=..., ruleset=...).save(out_dir, stem)
```

---

### JSON Schema v1 (Outline)

Top‑level keys:
- `schema_version: "1.0"`
- `context`:
  - run_id, timestamp, git_hash
  - inputs[]
  - parameters{}
  - style { name, rcparams_hash }
- `figure`:
  - dpi, size_inches, backend
- `axes[]`:
  - title, xlabel, ylabel
  - xscale, yscale, xlim, ylim
  - legend[]
  - `series[]`:
    - id (stable)
    - label
    - kind (v1: line2d only)
    - data (optional): x[], y[]
    - stats: n, min, max, endpoints
    - diagnostics{}
- `invariants[]`:
  - rule_id
  - severity (warn / fail)
  - passed
  - message
  - where (axis / series / indices)
- `warnings[]` (export‑time warnings)

---

### Determinism Rules

- Axes order: `fig.axes`
- Series order: `ax.lines`
- Stable IDs based on (axis index, series index, label)
- Numeric rounding controlled by `float_precision`

---

### Data Decimation

- If `n > max_points`:
  - preserve endpoints
  - uniform subsample
  - record original n + decimation method

---

### v1 Scope (Strict)

- Support `Line2D` only
- Numeric diagnostics only (no visuals)
- JSON + MD output

Future versions may add scatter, bars, images, and richer layout analysis.

---

### Test Strategy

**Goal:** keep `mpl_plot_report` domain-neutral while still exercising realistic workloads.

**Tier 1 — Package tests (required, fast, deterministic)**
- Location: `tests/`
- Data: *agent-generated synthetic figures* (no external CSV required)
- Assertions:
  - report generation does not crash (headless/Agg)
  - schema keys exist and are correctly typed
  - exporter warnings/invariants behave as expected on pathology cases
- Artifacts:
  - optionally store small golden JSON in `tests/fixtures/expected/` once the schema stabilizes

**Tier 2 — Consumer integration tests (optional, in consumer repos)**
- Domain projects may keep curated datasets (CSV/WAV-derived) under their own `tests/fixtures/…`
- Those tests should assert **qualitative** properties (fields exist, warnings present) rather than brittle numeric equality.

**Fixtures naming/location convention**
- Prefer: `tests/fixtures/synthetic/` for small, deterministic data used by this package
- Prefer: `tests/fixtures/expected/` for golden `.plot.json` snapshots (introduced after v1 stabilizes)

---

### Release Checklist (v1)

- [ ] `pytest` passes locally and in CI (headless)
- [ ] Export produces: `.png`, `.plot.json`, `.plot.md`
- [ ] Schema version pinned and documented
- [ ] Add a helpful `README.md` (usage, installation, minimal examples)
  - Document Python API (`dump_report`) and expected output files
  - Show the 2–3 synthetic test plots as examples
  - Mention how consumer projects inject domain rules via `ruleset`

---

### Testing Strategy (Locked)

**Test types:**

1) **Engine sanity tests (required)**
- Use existing curated CSV fixtures from the consumer project during early development
- Assert:
  - report generation does not crash
  - JSON schema keys exist
  - diagnostics fields are populated
  - expected qualitative signals appear (wiggles, NaNs, ordering issues)
- Avoid golden-value assertions at this stage

2) **Synthetic fixtures (future hardening)**
- Introduce 2–3 tiny synthetic datasets only once diagnostics stabilize
- Use them to generate golden `.plot.json` outputs
- Enable strict CI regression checks at that point

**Fixtures location convention:**
```
tests/
  fixtures/
    curated/      # realistic datasets (integration stress tests)
    synthetic/    # small, deterministic datasets (later)
```

---

### Agent Handoff Requirement

Once:
- core API is stable
- tests pass reliably
- diagnostics are minimally validated

An agent should generate a **README.md** that includes:
- package purpose and philosophy
- installation instructions
- minimal usage examples
- explanation of sidecar artifacts
- guidance for injecting domain-specific rules

The README must target both human users and agent-based workflows.

