## Plot Report Sidecar Export

> Packaging: This spec is for a standalone package repo (working name: `mpl_plot_report`). Domain rules belong to consumer projects and are injected at runtime.

### Problem
Agents cannot reliably critique plot correctness from rendered images (PNGs). Images are not stable, machine-testable artifacts.

### Solution
For every Matplotlib figure, export a *sidecar plot report* (JSON + Markdown) that captures:
- figure / axes / series metadata
- numeric diagnostics computed from series data
- invariant checks (rules) with pass / fail + locations

This enables agentic, blind-friendly debugging loops and CI regression checks.

---

### Required Artifacts (per plot)

```
plots/<run_id>/
  <stem>.png
  <stem>.plot.json
  <stem>.plot.md
```

---

### Inputs
- Matplotlib `Figure`
- Optional `PlotPayload` used to construct the figure
- `context` metadata:
  - run_id, timestamp
  - git hash / version
  - input dataset identities (CSV, WAV, etc.)
  - parameters used to generate the plot
  - style identity

---

### Outputs
- `<stem>.plot.json` — machine-readable, schema-versioned report
- `<stem>.plot.md` — human-readable summary highlighting warnings and failures

---

### Diagnostics (Generic, Reusable)
Diagnostics operate on numeric data, not visuals:

- x ordering (strictly increasing / expected ordering)
- NaN / inf detection and locations
- dx sanity: min, median, non-positive dx count
- first-difference outliers on dy (max |dy|, robust z-score)
- slope statistics on dy/dx: mean, median, std, quantiles
- wiggles: sign changes in slope after light smoothing / downsampling
- curvature proxy: second difference stats (std, max abs, sign changes)

---

### Invariant Checks
- Invariants encode *expectations*, not observations
- Each invariant returns:
  - pass / fail
  - severity (warn / fail)
  - reason
  - affected axis / series / index ranges

**Separation of concerns:**
- Generic engine supports invariant evaluation
- Domain-specific invariants live in consumer projects

---

### Styling Identity
Reports must record:
- style name (if using `.mplstyle`)
- rcParams fingerprint / hash
- backend (optional)

---

### Non-Goals
- No OCR or image analysis
- No monkey-patching Matplotlib
- No pyplot wrapper as the main API surface

---

### Portability & Determinism
- Pure Python + matplotlib + numpy
- Headless compatible (Agg backend)
- Stable ordering of axes and series
- Controlled float precision and optional data decimation
- Schema version pinned (v1.x)

