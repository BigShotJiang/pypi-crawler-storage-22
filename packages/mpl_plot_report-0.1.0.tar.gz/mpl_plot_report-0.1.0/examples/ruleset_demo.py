from __future__ import annotations

from mpl_plot_report.rules import Rule, RuleSet


def always_ok(report):
    return True, "ok", None


RULESET = RuleSet([Rule("demo.always_ok", "warn", always_ok)])
