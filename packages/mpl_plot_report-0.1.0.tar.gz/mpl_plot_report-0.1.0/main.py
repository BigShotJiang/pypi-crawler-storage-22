def main():
    print("Hello from mpl-plot-report!")


if __name__ == "__main__":
    main()
