"""Public API for mpl_plot_report."""

from mpl_plot_report.api import build_report, dump_report

__all__ = ["build_report", "dump_report"]
