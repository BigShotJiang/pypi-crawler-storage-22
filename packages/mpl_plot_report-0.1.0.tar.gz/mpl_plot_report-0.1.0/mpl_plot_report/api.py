from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Mapping

import matplotlib

from mpl_plot_report.extract import extract_figure
from mpl_plot_report.render_md import render_report_full
from mpl_plot_report.rules import RuleResult, coerce_ruleset
from mpl_plot_report.schema import SCHEMA_VERSION
from mpl_plot_report.util import hash_rcparams, round_floats


def build_report(
    fig,
    *,
    context: Mapping[str, Any] | None = None,
    ruleset=None,
    include_data: bool = True,
    max_points: int = 2000,
    float_precision: int = 6,
) -> dict[str, Any]:
    context_payload = dict(context or {})
    rcparams_hash = hash_rcparams(matplotlib.rcParams)
    context_payload.setdefault(
        "style",
        {
            "name": context_payload.get("style_name"),
            "rcparams_hash": rcparams_hash,
        },
    )

    axes_payload, warnings = extract_figure(
        fig,
        include_data=include_data,
        max_points=max_points,
    )

    report: dict[str, Any] = {
        "schema_version": SCHEMA_VERSION,
        "context": context_payload,
        "figure": {
            "dpi": float(fig.dpi),
            "size_inches": [float(v) for v in fig.get_size_inches()],
            "backend": matplotlib.get_backend(),
        },
        "axes": axes_payload,
        "invariants": [],
        "warnings": warnings,
    }

    rules = coerce_ruleset(ruleset)
    if rules:
        invariants: list[RuleResult] = rules.evaluate(report)
        report["invariants"] = [inv.__dict__ for inv in invariants]

    return round_floats(report, float_precision)


def dump_report(
    fig,
    out_dir: str | Path,
    stem: str,
    *,
    context: Mapping[str, Any] | None = None,
    ruleset=None,
    include_data: bool = True,
    max_points: int = 2000,
    float_precision: int = 6,
    md_mode: str = "full",
    md_data_sample: int = 5,
    md_include_png_embed: bool = True,
) -> dict[str, Any]:
    report = build_report(
        fig,
        context=context,
        ruleset=ruleset,
        include_data=include_data,
        max_points=max_points,
        float_precision=float_precision,
    )

    out_path = Path(out_dir)
    out_path.mkdir(parents=True, exist_ok=True)

    png_path = out_path / f"{stem}.png"
    json_path = out_path / f"{stem}.plot.json"
    md_path = out_path / f"{stem}.plot.md"

    fig.savefig(png_path)

    json_path.write_text(json.dumps(report, indent=2, sort_keys=True), encoding="utf-8")
    if md_mode == "summary":
        md_content = render_report_full(
            report,
            stem=stem,
            md_data_sample=md_data_sample,
            md_include_png_embed=md_include_png_embed,
        )
    else:
        md_content = render_report_full(
            report,
            stem=stem,
            md_data_sample=md_data_sample,
            md_include_png_embed=md_include_png_embed,
        )
    md_path.write_text(md_content, encoding="utf-8")

    return report
