from __future__ import annotations

import argparse
import json
import sys
from importlib import import_module
from typing import Any, Callable

import matplotlib

from mpl_plot_report.api import dump_report


def _load_callable(module_path: str, callable_name: str) -> Callable[..., Any]:
    module = import_module(module_path)
    try:
        target = getattr(module, callable_name)
    except AttributeError as exc:
        raise SystemExit(
            f"Callable '{callable_name}' not found in module '{module_path}'."
        ) from exc
    if not callable(target):
        raise SystemExit(f"{module_path}.{callable_name} is not callable.")
    return target


def _parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Export Matplotlib plot reports.")
    parser.add_argument(
        "--module",
        required=True,
        help="Module path containing a callable that returns a Figure.",
    )
    parser.add_argument(
        "--callable",
        default="make_figure",
        help="Callable name that returns a Matplotlib Figure.",
    )
    parser.add_argument("--out-dir", help="Output directory.")
    parser.add_argument("--stem", required=True, help="Output file stem.")
    parser.add_argument(
        "--run-id",
        help="Run identifier; uses plots/<run_id> when --out-dir is omitted.",
    )
    parser.add_argument(
        "--context",
        default="{}",
        help="JSON string for context metadata.",
    )
    parser.add_argument(
        "--max-points",
        type=int,
        default=2000,
        help="Maximum number of points per series.",
    )
    parser.add_argument(
        "--float-precision",
        type=int,
        default=6,
        help="Float rounding precision for report output.",
    )
    parser.add_argument(
        "--no-data",
        action="store_true",
        help="Exclude raw series data from JSON output.",
    )
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = _parse_args(argv or sys.argv[1:])
    matplotlib.use("Agg")

    if args.out_dir is None and not args.run_id:
        raise SystemExit("Provide --out-dir or --run-id.")
    out_dir = args.out_dir or f"plots/{args.run_id}"

    try:
        context = json.loads(args.context)
    except json.JSONDecodeError as exc:
        raise SystemExit("--context must be valid JSON.") from exc

    figure_factory = _load_callable(args.module, args.callable)
    fig = figure_factory()

    dump_report(
        fig,
        out_dir,
        args.stem,
        context=context,
        include_data=not args.no_data,
        max_points=args.max_points,
        float_precision=args.float_precision,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
