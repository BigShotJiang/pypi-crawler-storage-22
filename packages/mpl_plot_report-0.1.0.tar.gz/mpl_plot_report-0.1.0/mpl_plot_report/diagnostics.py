from __future__ import annotations

from typing import Any

import numpy as np


def _safe_stat(values: np.ndarray, func) -> float | None:
    if values.size == 0:
        return None
    return float(func(values))


def _robust_z_stats(values: np.ndarray) -> tuple[float | None, int]:
    if values.size == 0:
        return None, 0
    median = float(np.median(values))
    mad = float(np.median(np.abs(values - median)))
    if mad == 0.0:
        return 0.0, 0
    z = 0.6745 * (values - median) / mad
    max_abs = float(np.max(np.abs(z)))
    outliers = int(np.sum(np.abs(z) > 3.5))
    return max_abs, outliers


def compute_diagnostics(x: np.ndarray, y: np.ndarray) -> dict[str, Any]:
    diagnostics: dict[str, Any] = {}

    n = int(len(x))
    finite_mask = np.isfinite(x) & np.isfinite(y)
    diagnostics["n"] = n
    diagnostics["non_finite_count"] = int(n - np.count_nonzero(finite_mask))

    x_finite = x[np.isfinite(x)]
    dx = np.diff(x_finite) if x_finite.size > 1 else np.array([])
    diagnostics["dx_min"] = _safe_stat(dx, np.min)
    diagnostics["dx_median"] = _safe_stat(dx, np.median)
    diagnostics["dx_non_positive_count"] = int(np.sum(dx <= 0)) if dx.size else 0

    y_finite = y[finite_mask]
    x_for_slope = x[finite_mask]
    dy = np.diff(y_finite) if y_finite.size > 1 else np.array([])
    diagnostics["dy_max_abs"] = _safe_stat(np.abs(dy), np.max)
    robust_z, outlier_count = _robust_z_stats(dy)
    diagnostics["dy_robust_z_max"] = robust_z
    diagnostics["dy_outlier_count"] = outlier_count

    slope = np.array([])
    if x_for_slope.size > 1:
        dx_slope = np.diff(x_for_slope)
        dy_slope = np.diff(y_finite)
        valid = dx_slope != 0
        if np.any(valid):
            slope = dy_slope[valid] / dx_slope[valid]

    diagnostics["slope_mean"] = _safe_stat(slope, np.mean)
    diagnostics["slope_median"] = _safe_stat(slope, np.median)
    diagnostics["slope_std"] = _safe_stat(slope, np.std)
    diagnostics["slope_p10"] = _safe_stat(slope, lambda v: np.quantile(v, 0.1))
    diagnostics["slope_p90"] = _safe_stat(slope, lambda v: np.quantile(v, 0.9))

    slope_signs = np.sign(slope)
    slope_signs = slope_signs[slope_signs != 0]
    diagnostics["wiggle_sign_changes"] = (
        int(np.sum(slope_signs[1:] != slope_signs[:-1])) if slope_signs.size > 1 else 0
    )

    curvature = np.diff(y_finite, n=2) if y_finite.size > 2 else np.array([])
    diagnostics["curvature_std"] = _safe_stat(curvature, np.std)
    diagnostics["curvature_max_abs"] = _safe_stat(np.abs(curvature), np.max)
    curvature_signs = np.sign(curvature)
    curvature_signs = curvature_signs[curvature_signs != 0]
    diagnostics["curvature_sign_changes"] = (
        int(np.sum(curvature_signs[1:] != curvature_signs[:-1]))
        if curvature_signs.size > 1
        else 0
    )

    return diagnostics
