from __future__ import annotations

from typing import Any

import numpy as np
from matplotlib.lines import Line2D

from mpl_plot_report.diagnostics import compute_diagnostics
from mpl_plot_report.util import decimate_series, make_stable_id


def _safe_min(values: np.ndarray) -> float | None:
    if values.size == 0:
        return None
    finite = values[np.isfinite(values)]
    if finite.size == 0:
        return None
    return float(np.min(finite))


def _safe_max(values: np.ndarray) -> float | None:
    if values.size == 0:
        return None
    finite = values[np.isfinite(values)]
    if finite.size == 0:
        return None
    return float(np.max(finite))


def _series_stats(x: np.ndarray, y: np.ndarray) -> dict[str, Any]:
    stats: dict[str, Any] = {
        "n": int(len(x)),
        "x_min": _safe_min(x),
        "x_max": _safe_max(x),
        "y_min": _safe_min(y),
        "y_max": _safe_max(y),
        "x_endpoints": [float(x[0]), float(x[-1])] if len(x) else None,
        "y_endpoints": [float(y[0]), float(y[-1])] if len(y) else None,
    }
    return stats


def extract_figure(
    fig,
    *,
    include_data: bool,
    max_points: int,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    axes_payload: list[dict[str, Any]] = []
    warnings: list[dict[str, Any]] = []

    for axis_index, ax in enumerate(fig.axes):
        legend_labels = []
        if ax.get_legend() is not None:
            _, labels = ax.get_legend_handles_labels()
            legend_labels = [label for label in labels if label]

        axis_payload: dict[str, Any] = {
            "index": axis_index,
            "title": ax.get_title(),
            "xlabel": ax.get_xlabel(),
            "ylabel": ax.get_ylabel(),
            "xscale": ax.get_xscale(),
            "yscale": ax.get_yscale(),
            "xlim": list(ax.get_xlim()),
            "ylim": list(ax.get_ylim()),
            "legend": legend_labels,
            "series": [],
        }

        for series_index, line in enumerate(ax.lines):
            if not isinstance(line, Line2D):
                continue
            x = np.asarray(line.get_xdata(), dtype=float)
            y = np.asarray(line.get_ydata(), dtype=float)

            if x.size != y.size:
                min_len = min(x.size, y.size)
                warnings.append(
                    {
                        "code": "length_mismatch",
                        "message": "Line2D x/y lengths do not match; truncating.",
                        "where": {
                            "axis_index": axis_index,
                            "series_index": series_index,
                        },
                    }
                )
                x = x[:min_len]
                y = y[:min_len]

            label = line.get_label() or ""
            if not label or label.startswith("_"):
                label = f"series_{series_index}"

            series_id = make_stable_id(axis_index, series_index, label)
            diagnostics = compute_diagnostics(x, y)
            stats = _series_stats(x, y)

            if diagnostics.get("non_finite_count", 0) > 0:
                warnings.append(
                    {
                        "code": "non_finite",
                        "message": "Series contains non-finite values.",
                        "where": {
                            "axis_index": axis_index,
                            "series_index": series_index,
                        },
                    }
                )

            data_payload = None
            if include_data:
                x_use, y_use, decimation = decimate_series(x, y, max_points)
                data_payload = {
                    "x": x_use.tolist(),
                    "y": y_use.tolist(),
                    "decimation": decimation,
                }

            axis_payload["series"].append(
                {
                    "id": series_id,
                    "label": label,
                    "kind": "line2d",
                    "data": data_payload,
                    "stats": stats,
                    "diagnostics": diagnostics,
                }
            )

        axes_payload.append(axis_payload)

    return axes_payload, warnings
