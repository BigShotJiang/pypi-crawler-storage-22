from __future__ import annotations

from typing import Any
import json

_DIAGNOSTIC_KEYS = [
    "n",
    "non_finite_count",
    "dx_min",
    "dx_median",
    "dx_non_positive_count",
    "dy_max_abs",
    "dy_robust_z_max",
    "dy_outlier_count",
    "slope_mean",
    "slope_median",
    "slope_std",
    "slope_p10",
    "slope_p90",
    "wiggle_sign_changes",
    "curvature_std",
    "curvature_max_abs",
    "curvature_sign_changes",
]


def _format_value(value: Any) -> str:
    if value is None:
        return "None"
    if isinstance(value, float):
        return f"{value}"
    return str(value)


def _sample_pairs(x: list[float], y: list[float], sample: int) -> dict[str, list]:
    if sample <= 0 or not x or not y:
        return {"head": [], "tail": []}
    n = min(len(x), len(y))
    head_count = min(sample, n)
    tail_count = min(sample, n)
    head = list(zip(x[:head_count], y[:head_count]))
    tail = list(zip(x[-tail_count:], y[-tail_count:]))
    return {"head": head, "tail": tail}


def _scrub_points(report: dict[str, Any], sample: int) -> dict[str, Any]:
    clone = json.loads(json.dumps(report))
    for axis in clone.get("axes", []):
        for series in axis.get("series", []):
            data = series.get("data")
            if not data:
                continue
            x = data.get("x") or []
            y = data.get("y") or []
            series["data"] = {
                "omitted": True,
                "n": len(x),
                "sample": _sample_pairs(x, y, sample),
                "decimation": data.get("decimation"),
            }
    return clone


def render_report_full(
    report: dict[str, Any],
    *,
    stem: str | None = None,
    md_data_sample: int = 5,
    md_include_png_embed: bool = True,
) -> str:
    lines: list[str] = []
    title = stem or "plot"
    lines.append(f"# Plot Report: {title}")
    lines.append("")

    context = report.get("context", {})
    style = context.get("style") or {}
    inputs = context.get("inputs")
    parameters = context.get("parameters")

    lines.append("## Context")
    lines.append(f"- schema_version: {report.get('schema_version')}")
    lines.append(f"- run_id: {_format_value(context.get('run_id'))}")
    lines.append(f"- timestamp: {_format_value(context.get('timestamp'))}")
    lines.append(f"- git_hash: {_format_value(context.get('git_hash'))}")
    lines.append(f"- inputs: {_format_value(inputs)}")
    lines.append(f"- parameters: {_format_value(parameters)}")
    lines.append(
        "- style: name={name} rcparams_hash={hash}".format(
            name=_format_value(style.get("name")),
            hash=_format_value(style.get("rcparams_hash")),
        )
    )

    lines.append("")
    lines.append("## PNG")
    png_name = f"{title}.png"
    if md_include_png_embed:
        lines.append(f"![]({png_name})")
    lines.append(f"- png_path: {png_name}")

    warnings = report.get("warnings", [])
    lines.append("")
    lines.append("## Warnings")
    if warnings:
        for warning in warnings:
            code = warning.get("code", "warning")
            message = warning.get("message", "")
            where = warning.get("where")
            where_text = f" where={where}" if where else ""
            lines.append(f"- {code}: {message}{where_text}")
    else:
        lines.append("- None")

    invariants = report.get("invariants", [])
    lines.append("")
    lines.append("## Invariant Results")
    if invariants:
        fails = [inv for inv in invariants if not inv.get("passed")]
        warns = [
            inv
            for inv in invariants
            if inv.get("passed") and inv.get("severity") == "warn"
        ]
        passes = [
            inv
            for inv in invariants
            if inv.get("passed") and inv.get("severity") not in {"warn", "fail"}
        ]

        for group_name, group in (
            ("FAIL", fails),
            ("WARN", warns),
            ("PASS", passes),
        ):
            if not group:
                continue
            lines.append(f"- {group_name}:")
            for inv in group:
                where = inv.get("where")
                where_text = f" where={where}" if where else ""
                lines.append(
                    "  - {rule_id} severity={severity} passed={passed} message={message}{where}".format(
                        rule_id=inv.get("rule_id"),
                        severity=inv.get("severity"),
                        passed=inv.get("passed"),
                        message=inv.get("message"),
                        where=where_text,
                    )
                )
    else:
        lines.append("- None")

    axes = report.get("axes", [])
    lines.append("")
    lines.append("## Axes")
    if not axes:
        lines.append("- None")

    for axis in axes:
        lines.append("")
        lines.append(f"### Axis {axis.get('index')}")
        lines.append(f"- title: {_format_value(axis.get('title'))}")
        lines.append(f"- xlabel: {_format_value(axis.get('xlabel'))}")
        lines.append(f"- ylabel: {_format_value(axis.get('ylabel'))}")
        lines.append(f"- xscale: {_format_value(axis.get('xscale'))}")
        lines.append(f"- yscale: {_format_value(axis.get('yscale'))}")
        lines.append(f"- xlim: {_format_value(axis.get('xlim'))}")
        lines.append(f"- ylim: {_format_value(axis.get('ylim'))}")
        legend = axis.get("legend") or []
        legend_text = legend if legend else "None"
        lines.append(f"- legend: {_format_value(legend_text)}")

        series_list = axis.get("series", [])
        if not series_list:
            lines.append("- series: None")
            continue

        lines.append("- series:")
        for series in series_list:
            lines.append("")
            lines.append(f"#### Series {series.get('id')}")
            lines.append(f"- label: {_format_value(series.get('label'))}")
            lines.append(f"- kind: {_format_value(series.get('kind'))}")

            stats = series.get("stats", {})
            lines.append("- stats:")
            lines.append(f"  - n: {_format_value(stats.get('n'))}")
            lines.append(
                "  - x_min/x_max: {xmin} / {xmax}".format(
                    xmin=_format_value(stats.get("x_min")),
                    xmax=_format_value(stats.get("x_max")),
                )
            )
            lines.append(
                "  - y_min/y_max: {ymin} / {ymax}".format(
                    ymin=_format_value(stats.get("y_min")),
                    ymax=_format_value(stats.get("y_max")),
                )
            )
            lines.append(
                "  - first/last: {first} / {last}".format(
                    first=_format_value(stats.get("x_endpoints")),
                    last=_format_value(stats.get("y_endpoints")),
                )
            )

            diagnostics = series.get("diagnostics", {})
            lines.append("- diagnostics:")
            for key in _DIAGNOSTIC_KEYS:
                if key in diagnostics:
                    lines.append(f"  - {key}: {_format_value(diagnostics.get(key))}")

            data = series.get("data")
            if data:
                decimation = data.get("decimation", {})
                x = data.get("x") or []
                y = data.get("y") or []
                samples = _sample_pairs(x, y, md_data_sample)
                lines.append("- data_sample:")
                lines.append(
                    "  - decimation: original_n={n_original} max_points={max_points} method={method} decimated={decimated}".format(
                        n_original=decimation.get("n_original"),
                        max_points=decimation.get("max_points"),
                        method=decimation.get("method"),
                        decimated=decimation.get("decimated"),
                    )
                )
                lines.append(f"  - head: {samples['head']}")
                lines.append(f"  - tail: {samples['tail']}")

    lines.append("")
    lines.append("## Raw JSON (minus points)")
    stripped = _scrub_points(report, md_data_sample)
    lines.append("```json")
    lines.append(json.dumps(stripped, indent=2, sort_keys=True))
    lines.append("```")
    lines.append("")

    return "\n".join(lines)


def render_report(report: dict[str, Any]) -> str:
    return render_report_full(report)
