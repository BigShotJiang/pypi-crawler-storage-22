from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Iterable, Sequence


@dataclass(frozen=True)
class RuleResult:
    rule_id: str
    severity: str
    passed: bool
    message: str
    where: dict[str, Any] | None = None


@dataclass(frozen=True)
class Rule:
    rule_id: str
    severity: str
    evaluator: Callable[[dict[str, Any]], tuple[bool, str, dict[str, Any] | None]]

    def evaluate(self, report: dict[str, Any]) -> RuleResult:
        passed, message, where = self.evaluator(report)
        return RuleResult(
            rule_id=self.rule_id,
            severity=self.severity,
            passed=passed,
            message=message,
            where=where,
        )


@dataclass
class RuleSet:
    rules: Sequence[Rule]

    def evaluate(self, report: dict[str, Any]) -> list[RuleResult]:
        return [rule.evaluate(report) for rule in self.rules]


def coerce_ruleset(ruleset: RuleSet | Iterable[Rule] | None) -> RuleSet | None:
    if ruleset is None:
        return None
    if isinstance(ruleset, RuleSet):
        return ruleset
    return RuleSet(list(ruleset))
