from __future__ import annotations

import hashlib
import json
from typing import Any, Mapping

import numpy as np


def make_stable_id(axis_index: int, series_index: int, label: str) -> str:
    safe = "".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in label.strip())
    safe = safe or "series"
    return f"ax{axis_index}_s{series_index}_{safe}"


def hash_rcparams(rcparams: Mapping[str, Any]) -> str:
    payload = json.dumps(rcparams, sort_keys=True, default=repr)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def round_floats(value: Any, precision: int) -> Any:
    if isinstance(value, float):
        return round(value, precision)
    if isinstance(value, list):
        return [round_floats(item, precision) for item in value]
    if isinstance(value, tuple):
        return [round_floats(item, precision) for item in value]
    if isinstance(value, dict):
        return {key: round_floats(item, precision) for key, item in value.items()}
    return value


def decimate_series(
    x: np.ndarray, y: np.ndarray, max_points: int
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    n = len(x)
    if max_points <= 0:
        max_points = 1
    if n <= max_points:
        return (
            x,
            y,
            {
                "decimated": False,
                "method": None,
                "n_original": n,
                "max_points": max_points,
            },
        )

    target = max(max_points, 2)
    idx = np.linspace(0, n - 1, target, dtype=int)
    idx = np.unique(idx)
    return (
        x[idx],
        y[idx],
        {
            "decimated": True,
            "method": "uniform",
            "n_original": n,
            "max_points": max_points,
        },
    )
