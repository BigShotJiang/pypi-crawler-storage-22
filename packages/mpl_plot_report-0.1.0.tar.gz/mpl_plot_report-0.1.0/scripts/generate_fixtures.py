from __future__ import annotations

from pathlib import Path
import sys

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.figure import Figure
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from mpl_plot_report.api import dump_report


def make_happy_path() -> Figure:
    x = np.linspace(0, 10, 200)
    y = np.sin(x) * 0.5 + 0.5
    fig, ax = plt.subplots()
    ax.plot(x, y, label="happy")
    ax.set_title("Happy Path")
    return fig


def make_nan_ordering() -> Figure:
    x = np.array([0, 1, 2, 1.5, 3, 4, 5], dtype=float)
    y = np.array([0, 1, np.nan, 2, np.inf, 3, 4], dtype=float)
    fig, ax = plt.subplots()
    ax.plot(x, y, label="nan_ordering")
    ax.set_title("NaN + Ordering")
    return fig


def make_wiggles_outliers() -> Figure:
    x = np.linspace(0, 6, 400)
    y = np.sin(12 * x) * 0.2
    y[200:] += 1.0
    y[300] += 3.0
    fig, ax = plt.subplots()
    ax.plot(x, y, label="wiggles")
    ax.set_title("Wiggles + Outlier")
    return fig


def main() -> None:
    out_dir = Path("tests/fixtures/expected")
    out_dir.mkdir(parents=True, exist_ok=True)

    figures = {
        "happy_path": make_happy_path,
        "nan_ordering": make_nan_ordering,
        "wiggles_outliers": make_wiggles_outliers,
    }

    for stem, factory in figures.items():
        fig = factory()
        dump_report(
            fig,
            out_dir,
            stem,
            context={"run_id": "fixtures", "style_name": "default"},
            include_data=True,
            max_points=2000,
        )


if __name__ == "__main__":
    main()
