# Plot Report: happy_path

## Context
- schema_version: 1.0
- run_id: fixtures
- timestamp: None
- git_hash: None
- inputs: None
- parameters: None
- style: name=default rcparams_hash=66132a6156c9be7c48dfc67d2c148a68a2c1e5d4887205007c121326c2ecd51e

## PNG
![](happy_path.png)
- png_path: happy_path.png

## Warnings
- None

## Invariant Results
- None

## Axes

### Axis 0
- title: Happy Path
- xlabel: 
- ylabel: 
- xscale: linear
- yscale: linear
- xlim: [np.float64(-0.5), np.float64(10.5)]
- ylim: [np.float64(-0.049965), np.float64(1.049954)]
- legend: None
- series:

#### Series ax0_s0_happy
- label: happy
- kind: line2d
- stats:
  - n: 200
  - x_min/x_max: 0.0 / 10.0
  - y_min/y_max: 3.2e-05 / 0.999958
  - first/last: [0.0, 10.0] / [0.5, 0.227989]
- diagnostics:
  - n: 200
  - non_finite_count: 0
  - dx_min: 0.050251
  - dx_median: 0.050251
  - dx_non_positive_count: 0
  - dy_max_abs: 0.025123
  - dy_robust_z_max: 1.013353
  - dy_outlier_count: 0
  - slope_mean: -0.027201
  - slope_median: -0.055302
  - slope_std: 0.360473
  - slope_p10: -0.484183
  - slope_p90: 0.473285
  - wiggle_sign_changes: 3
  - curvature_std: 0.000841
  - curvature_max_abs: 0.001262
  - curvature_sign_changes: 3
- data_sample:
  - decimation: original_n=200 max_points=2000 method=None decimated=False
  - head: [(0.0, 0.5), (0.050251, 0.525115), (0.100503, 0.550167), (0.150754, 0.575092), (0.201005, 0.599827)]
  - tail: [(9.798995, 0.317228), (9.849246, 0.294082), (9.899497, 0.271455), (9.949749, 0.249406), (10.0, 0.227989)]

## Raw JSON (minus points)
```json
{
  "axes": [
    {
      "index": 0,
      "legend": [],
      "series": [
        {
          "data": {
            "decimation": {
              "decimated": false,
              "max_points": 2000,
              "method": null,
              "n_original": 200
            },
            "n": 200,
            "omitted": true,
            "sample": {
              "head": [
                [
                  0.0,
                  0.5
                ],
                [
                  0.050251,
                  0.525115
                ],
                [
                  0.100503,
                  0.550167
                ],
                [
                  0.150754,
                  0.575092
                ],
                [
                  0.201005,
                  0.599827
                ]
              ],
              "tail": [
                [
                  9.798995,
                  0.317228
                ],
                [
                  9.849246,
                  0.294082
                ],
                [
                  9.899497,
                  0.271455
                ],
                [
                  9.949749,
                  0.249406
                ],
                [
                  10.0,
                  0.227989
                ]
              ]
            }
          },
          "diagnostics": {
            "curvature_max_abs": 0.001262,
            "curvature_sign_changes": 3,
            "curvature_std": 0.000841,
            "dx_median": 0.050251,
            "dx_min": 0.050251,
            "dx_non_positive_count": 0,
            "dy_max_abs": 0.025123,
            "dy_outlier_count": 0,
            "dy_robust_z_max": 1.013353,
            "n": 200,
            "non_finite_count": 0,
            "slope_mean": -0.027201,
            "slope_median": -0.055302,
            "slope_p10": -0.484183,
            "slope_p90": 0.473285,
            "slope_std": 0.360473,
            "wiggle_sign_changes": 3
          },
          "id": "ax0_s0_happy",
          "kind": "line2d",
          "label": "happy",
          "stats": {
            "n": 200,
            "x_endpoints": [
              0.0,
              10.0
            ],
            "x_max": 10.0,
            "x_min": 0.0,
            "y_endpoints": [
              0.5,
              0.227989
            ],
            "y_max": 0.999958,
            "y_min": 3.2e-05
          }
        }
      ],
      "title": "Happy Path",
      "xlabel": "",
      "xlim": [
        -0.5,
        10.5
      ],
      "xscale": "linear",
      "ylabel": "",
      "ylim": [
        -0.049965,
        1.049954
      ],
      "yscale": "linear"
    }
  ],
  "context": {
    "run_id": "fixtures",
    "style": {
      "name": "default",
      "rcparams_hash": "66132a6156c9be7c48dfc67d2c148a68a2c1e5d4887205007c121326c2ecd51e"
    },
    "style_name": "default"
  },
  "figure": {
    "backend": "Agg",
    "dpi": 100.0,
    "size_inches": [
      6.4,
      4.8
    ]
  },
  "invariants": [],
  "schema_version": "1.0",
  "warnings": []
}
```
