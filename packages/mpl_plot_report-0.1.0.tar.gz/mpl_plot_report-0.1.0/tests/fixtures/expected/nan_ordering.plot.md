# Plot Report: nan_ordering

## Context
- schema_version: 1.0
- run_id: fixtures
- timestamp: None
- git_hash: None
- inputs: None
- parameters: None
- style: name=default rcparams_hash=66132a6156c9be7c48dfc67d2c148a68a2c1e5d4887205007c121326c2ecd51e

## PNG
![](nan_ordering.png)
- png_path: nan_ordering.png

## Warnings
- non_finite: Series contains non-finite values. where={'axis_index': 0, 'series_index': 0}

## Invariant Results
- None

## Axes

### Axis 0
- title: NaN + Ordering
- xlabel: 
- ylabel: 
- xscale: linear
- yscale: linear
- xlim: [np.float64(-0.25), np.float64(5.25)]
- ylim: [np.float64(-0.2), np.float64(4.2)]
- legend: None
- series:

#### Series ax0_s0_nan_ordering
- label: nan_ordering
- kind: line2d
- stats:
  - n: 7
  - x_min/x_max: 0.0 / 5.0
  - y_min/y_max: 0.0 / 4.0
  - first/last: [0.0, 5.0] / [0.0, 4.0]
- diagnostics:
  - n: 7
  - non_finite_count: 2
  - dx_min: -0.5
  - dx_median: 1.0
  - dx_non_positive_count: 1
  - dy_max_abs: 1.0
  - dy_robust_z_max: 0.0
  - dy_outlier_count: 0
  - slope_mean: 1.1
  - slope_median: 1.0
  - slope_std: 0.574456
  - slope_p10: 0.58
  - slope_p90: 1.7
  - wiggle_sign_changes: 0
  - curvature_std: 0.0
  - curvature_max_abs: 0.0
  - curvature_sign_changes: 0
- data_sample:
  - decimation: original_n=7 max_points=2000 method=None decimated=False
  - head: [(0.0, 0.0), (1.0, 1.0), (2.0, nan), (1.5, 2.0), (3.0, inf)]
  - tail: [(2.0, nan), (1.5, 2.0), (3.0, inf), (4.0, 3.0), (5.0, 4.0)]

## Raw JSON (minus points)
```json
{
  "axes": [
    {
      "index": 0,
      "legend": [],
      "series": [
        {
          "data": {
            "decimation": {
              "decimated": false,
              "max_points": 2000,
              "method": null,
              "n_original": 7
            },
            "n": 7,
            "omitted": true,
            "sample": {
              "head": [
                [
                  0.0,
                  0.0
                ],
                [
                  1.0,
                  1.0
                ],
                [
                  2.0,
                  NaN
                ],
                [
                  1.5,
                  2.0
                ],
                [
                  3.0,
                  Infinity
                ]
              ],
              "tail": [
                [
                  2.0,
                  NaN
                ],
                [
                  1.5,
                  2.0
                ],
                [
                  3.0,
                  Infinity
                ],
                [
                  4.0,
                  3.0
                ],
                [
                  5.0,
                  4.0
                ]
              ]
            }
          },
          "diagnostics": {
            "curvature_max_abs": 0.0,
            "curvature_sign_changes": 0,
            "curvature_std": 0.0,
            "dx_median": 1.0,
            "dx_min": -0.5,
            "dx_non_positive_count": 1,
            "dy_max_abs": 1.0,
            "dy_outlier_count": 0,
            "dy_robust_z_max": 0.0,
            "n": 7,
            "non_finite_count": 2,
            "slope_mean": 1.1,
            "slope_median": 1.0,
            "slope_p10": 0.58,
            "slope_p90": 1.7,
            "slope_std": 0.574456,
            "wiggle_sign_changes": 0
          },
          "id": "ax0_s0_nan_ordering",
          "kind": "line2d",
          "label": "nan_ordering",
          "stats": {
            "n": 7,
            "x_endpoints": [
              0.0,
              5.0
            ],
            "x_max": 5.0,
            "x_min": 0.0,
            "y_endpoints": [
              0.0,
              4.0
            ],
            "y_max": 4.0,
            "y_min": 0.0
          }
        }
      ],
      "title": "NaN + Ordering",
      "xlabel": "",
      "xlim": [
        -0.25,
        5.25
      ],
      "xscale": "linear",
      "ylabel": "",
      "ylim": [
        -0.2,
        4.2
      ],
      "yscale": "linear"
    }
  ],
  "context": {
    "run_id": "fixtures",
    "style": {
      "name": "default",
      "rcparams_hash": "66132a6156c9be7c48dfc67d2c148a68a2c1e5d4887205007c121326c2ecd51e"
    },
    "style_name": "default"
  },
  "figure": {
    "backend": "Agg",
    "dpi": 100.0,
    "size_inches": [
      6.4,
      4.8
    ]
  },
  "invariants": [],
  "schema_version": "1.0",
  "warnings": [
    {
      "code": "non_finite",
      "message": "Series contains non-finite values.",
      "where": {
        "axis_index": 0,
        "series_index": 0
      }
    }
  ]
}
```
