# Plot Report: wiggles_outliers

## Context
- schema_version: 1.0
- run_id: fixtures
- timestamp: None
- git_hash: None
- inputs: None
- parameters: None
- style: name=default rcparams_hash=66132a6156c9be7c48dfc67d2c148a68a2c1e5d4887205007c121326c2ecd51e

## PNG
![](wiggles_outliers.png)
- png_path: wiggles_outliers.png

## Warnings
- None

## Invariant Results
- None

## Axes

### Axis 0
- title: Wiggles + Outlier
- xlabel: 
- ylabel: 
- xscale: linear
- yscale: linear
- xlim: [np.float64(-0.3), np.float64(6.3)]
- ylim: [np.float64(-0.403329), np.float64(4.070229)]
- legend: None
- series:

#### Series ax0_s0_wiggles
- label: wiggles
- kind: line2d
- stats:
  - n: 400
  - x_min/x_max: 0.0 / 6.0
  - y_min/y_max: -0.199986 / 3.866885
  - first/last: [0.0, 6.0] / [0.0, 1.050765]
- diagnostics:
  - n: 400
  - non_finite_count: 0
  - dx_min: 0.015038
  - dx_median: 0.015038
  - dx_non_positive_count: 0
  - dy_max_abs: 3.024628
  - dy_robust_z_max: 79.514536
  - dy_outlier_count: 3
  - slope_mean: 0.175127
  - slope_median: 0.052216
  - slope_std: 14.595387
  - slope_p10: -2.271896
  - slope_p90: 2.289481
  - wiggle_sign_changes: 25
  - curvature_std: 0.375129
  - curvature_max_abs: 5.995677
  - curvature_sign_changes: 26
- data_sample:
  - decimation: original_n=400 max_points=2000 method=None decimated=False
  - head: [(0.0, 0.0), (0.015038, 0.035895), (0.030075, 0.070624), (0.045113, 0.103059), (0.06015, 0.132148)]
  - tail: [(5.93985, 1.165925), (5.954887, 1.14319), (5.969925, 1.115805), (5.984962, 1.08466), (6.0, 1.050765)]

## Raw JSON (minus points)
```json
{
  "axes": [
    {
      "index": 0,
      "legend": [],
      "series": [
        {
          "data": {
            "decimation": {
              "decimated": false,
              "max_points": 2000,
              "method": null,
              "n_original": 400
            },
            "n": 400,
            "omitted": true,
            "sample": {
              "head": [
                [
                  0.0,
                  0.0
                ],
                [
                  0.015038,
                  0.035895
                ],
                [
                  0.030075,
                  0.070624
                ],
                [
                  0.045113,
                  0.103059
                ],
                [
                  0.06015,
                  0.132148
                ]
              ],
              "tail": [
                [
                  5.93985,
                  1.165925
                ],
                [
                  5.954887,
                  1.14319
                ],
                [
                  5.969925,
                  1.115805
                ],
                [
                  5.984962,
                  1.08466
                ],
                [
                  6.0,
                  1.050765
                ]
              ]
            }
          },
          "diagnostics": {
            "curvature_max_abs": 5.995677,
            "curvature_sign_changes": 26,
            "curvature_std": 0.375129,
            "dx_median": 0.015038,
            "dx_min": 0.015038,
            "dx_non_positive_count": 0,
            "dy_max_abs": 3.024628,
            "dy_outlier_count": 3,
            "dy_robust_z_max": 79.514536,
            "n": 400,
            "non_finite_count": 0,
            "slope_mean": 0.175127,
            "slope_median": 0.052216,
            "slope_p10": -2.271896,
            "slope_p90": 2.289481,
            "slope_std": 14.595387,
            "wiggle_sign_changes": 25
          },
          "id": "ax0_s0_wiggles",
          "kind": "line2d",
          "label": "wiggles",
          "stats": {
            "n": 400,
            "x_endpoints": [
              0.0,
              6.0
            ],
            "x_max": 6.0,
            "x_min": 0.0,
            "y_endpoints": [
              0.0,
              1.050765
            ],
            "y_max": 3.866885,
            "y_min": -0.199986
          }
        }
      ],
      "title": "Wiggles + Outlier",
      "xlabel": "",
      "xlim": [
        -0.3,
        6.3
      ],
      "xscale": "linear",
      "ylabel": "",
      "ylim": [
        -0.403329,
        4.070229
      ],
      "yscale": "linear"
    }
  ],
  "context": {
    "run_id": "fixtures",
    "style": {
      "name": "default",
      "rcparams_hash": "66132a6156c9be7c48dfc67d2c148a68a2c1e5d4887205007c121326c2ecd51e"
    },
    "style_name": "default"
  },
  "figure": {
    "backend": "Agg",
    "dpi": 100.0,
    "size_inches": [
      6.4,
      4.8
    ]
  },
  "invariants": [],
  "schema_version": "1.0",
  "warnings": []
}
```
