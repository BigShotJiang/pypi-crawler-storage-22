import numpy as np
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

from mpl_plot_report.api import build_report, dump_report


def test_dump_report_creates_sidecars(tmp_path):
    x = np.linspace(0, 1, 50)
    y = x**2
    fig, ax = plt.subplots()
    ax.plot(x, y, label="quad")

    report = dump_report(
        fig,
        tmp_path,
        "happy",
        context={"run_id": "test"},
        include_data=True,
    )

    assert (tmp_path / "happy.png").exists()
    assert (tmp_path / "happy.plot.json").exists()
    assert (tmp_path / "happy.plot.md").exists()
    assert report["schema_version"] == "1.0"
    assert len(report["axes"]) == 1
    assert len(report["axes"][0]["series"]) == 1


def test_pathology_diagnostics_and_warnings():
    x = np.array([0, 1, 2, 1, 3, 4], dtype=float)
    y = np.array([0, 1, np.nan, 2, np.inf, 3], dtype=float)
    fig, ax = plt.subplots()
    ax.plot(x, y, label="pathology")

    report = build_report(fig, include_data=False)
    diagnostics = report["axes"][0]["series"][0]["diagnostics"]

    assert diagnostics["non_finite_count"] > 0
    assert diagnostics["dx_non_positive_count"] > 0
    assert any(warning["code"] == "non_finite" for warning in report["warnings"])


def test_decimation_metadata():
    x = np.arange(0, 5000, dtype=float)
    y = np.sin(x)
    fig, ax = plt.subplots()
    ax.plot(x, y, label="long")

    report = build_report(fig, include_data=True, max_points=200)
    data = report["axes"][0]["series"][0]["data"]

    assert len(data["x"]) <= 200
    assert data["decimation"]["decimated"] is True
    assert data["decimation"]["n_original"] == 5000


def test_md_full_has_required_sections(tmp_path):
    x = np.linspace(0, 1, 50)
    y = x**2
    fig, ax = plt.subplots()
    ax.plot(x, y, label="quad")

    dump_report(
        fig,
        tmp_path,
        "happy",
        context={
            "run_id": "run_001",
            "timestamp": "2026-02-02T00:00:00Z",
            "git_hash": "abc123",
            "inputs": ["input_a.csv"],
            "parameters": {"alpha": 1},
            "style": {"name": "default", "rcparams_hash": "hash"},
        },
    )

    md = (tmp_path / "happy.plot.md").read_text(encoding="utf-8")
    assert "# Plot Report: happy" in md
    assert "- run_id: run_001" in md
    assert "- git_hash: abc123" in md
    assert "## PNG" in md
    assert "![](happy.png)" in md
    assert "## Warnings" in md
    assert "## Invariant Results" in md
    assert "## Axes" in md
    assert "#### Series" in md


def test_md_reports_nonfinite_and_ordering(tmp_path):
    x = np.array([0, 1, 2, 1, 3, 4], dtype=float)
    y = np.array([0, 1, np.nan, 2, np.inf, 3], dtype=float)
    fig, ax = plt.subplots()
    ax.plot(x, y, label="pathology")

    dump_report(fig, tmp_path, "pathology")
    md = (tmp_path / "pathology.plot.md").read_text(encoding="utf-8")
    assert "non_finite_count" in md
    assert "dx_non_positive_count" in md
    assert "non_finite" in md


def test_md_does_not_dump_full_arrays(tmp_path):
    x = np.arange(0, 5000, dtype=float)
    y = np.sin(x)
    fig, ax = plt.subplots()
    ax.plot(x, y, label="long")

    dump_report(fig, tmp_path, "long", max_points=200)
    md = (tmp_path / "long.plot.md").read_text(encoding="utf-8")
    assert "data_sample" in md
    assert len(md) < 20000
