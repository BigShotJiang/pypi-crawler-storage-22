from cli.core.handlers.excel_file_handler import ExcelFileHandler
from cli.core.price_lists.constants import (
    PRICELIST_ITEMS_ACTION,
    PRICELIST_ITEMS_FIELDS,
    TAB_PRICE_ITEMS,
)
from cli.core.price_lists.handlers import PriceListItemExcelFileManager
from cli.core.price_lists.models import ItemData


def test_class_properties(mocker, price_list_data_from_dict):
    result = PriceListItemExcelFileManager("fake_file.xlsx")

    assert result._data_model == ItemData  # noqa: SLF001
    assert result._fields == PRICELIST_ITEMS_FIELDS
    assert result._sheet_name == TAB_PRICE_ITEMS  # noqa: SLF001
    assert result._data_validation_map[PRICELIST_ITEMS_ACTION].formula1 == '"-,update"'  # noqa: SLF001


def test_read_data(mocker, item_data_from_dict):
    mock_data = {"fake_field1": {"field"}}
    get_data_from_horizontal_sheet_mock = mocker.patch.object(
        ExcelFileHandler, "get_data_from_horizontal_sheet", return_value=iter([mock_data])
    )
    handler = PriceListItemExcelFileManager("fake_file.xlsx")

    result = list(handler._read_data())  # noqa: SLF001

    assert result == [mock_data]
    get_data_from_horizontal_sheet_mock.assert_called_once_with(
        TAB_PRICE_ITEMS, PRICELIST_ITEMS_FIELDS
    )
