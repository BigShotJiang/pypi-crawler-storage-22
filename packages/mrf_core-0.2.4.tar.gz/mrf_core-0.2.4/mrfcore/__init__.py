"""
MRF-Core
--------

A lightweight, modular, deterministic reasoning engine designed for
LLM autonomy, safety layers, and constraint-based reasoning.

This package exposes the full public API:
  - MRFCoreEngine (operator execution engine)
  - ReasoningPipeline (high-level reasoning wrapper)
  - Pipeline (low-level operator runner)
  - ReasoningState (stateful reasoning container)
  - Diagnostics utilities
  - Exceptions
  - Presets
  - Operators (for custom extensions)
"""

# Core engine + pipeline API
from .engine import MRFCoreEngine
from .pipeline import ReasoningPipeline

# Reasoning state + diagnostics
from .state import ReasoningState
from .diagnostics import MRFDiagnostics

# Exceptions
from .exceptions import (
    MRFError,
    OperatorNotFound,
    OperatorExecutionError,
    InvalidPipelineConfig,
    DiagnosticsWarning,
)

# Presets
from .presets import get_preset

# Operators (so users can import and extend them)
from . import operators


__all__ = [
    "MRFCoreEngine",
    "Pipeline",
    "ReasoningPipeline",
    "ReasoningState",
    "MRFDiagnostics",
    "MRFError",
    "OperatorNotFound",
    "OperatorExecutionError",
    "InvalidPipelineConfig",
    "DiagnosticsWarning",
    "get_preset",
    "operators",
]

