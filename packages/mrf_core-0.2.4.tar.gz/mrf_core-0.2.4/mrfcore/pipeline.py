from .engine import MRFCoreEngine


class ReasoningPipeline:
    """
    High-level wrapper for running a sequence of operators through
    the MRFCoreEngine in a clean, user-friendly API.
    """
    def __init__(self, operators=None, verbose=False):
        self.operators = operators or []
        self.verbose = verbose

    def run(self, text: str):
        engine = MRFCoreEngine(enforce_phases=False, verbose=self.verbose)
        return engine.run_chain(self.operators, text)

