"""
MRF-Core: Deterministic operator-based reasoning engine.
"""
__version__ = "0.2.8"

from .engine import MRFCoreEngine
from .pipeline import ReasoningPipeline
from .state import ReasoningState
from .diagnostics import MRFDiagnostics
from .exceptions import (
    MRFError,
    OperatorNotFound,
    OperatorExecutionError,
    InvalidPipelineConfig,
)
from .presets import get_preset
from . import operators

__all__ = [
    "MRFCoreEngine",
    "ReasoningPipeline",
    "ReasoningState",
    "MRFDiagnostics",
    "MRFError",
    "OperatorNotFound",
    "OperatorExecutionError",
    "InvalidPipelineConfig",
    "get_preset",
    "operators",
]

# Expose version string safely
from importlib.metadata import version as _version
try:
    __version__ = _version("mrf-core")
except Exception:
    __version__ = "unknown"

