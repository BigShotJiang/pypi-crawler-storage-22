class MRFError(Exception):
    pass


class OperatorNotFound(MRFError):
    pass


class OperatorExecutionError(MRFError):
    pass


class InvalidPipelineConfig(MRFError):
    pass
