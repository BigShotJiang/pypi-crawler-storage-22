from .engine import MRFCoreEngine

class ReasoningPipeline:
    def __init__(self, operators=None):
        self.operators = operators or []

    def run(self, text: str):
        engine = MRFCoreEngine(enforce_phases=False)
        return engine.run_chain(self.operators, text)
