# 🌤️ MriduManda

**MriduManda** is a lightweight Python application that fetches real-time weather data for any city using the OpenWeatherMap API. Designed with simplicity and clean structure in mind, the app offers a minimal but effective interface for accessing weather insights from the command line or future integrations.

---

## 🚀 Features

- 🔍 Fetch current weather by city name
- 🌡️ Displays temperature and condition
- 🌆 Automatic City detection

---

## 📦 Tech Stack

- Python 3.10+
- [Requests](https://pypi.org/project/requests/) for HTTP communication
- JSON for data handling
- Poetry for dependency management
- [Rich](https://pypi.org/project/rich/) for Beautiful Weather Disclosure

---

## 🛠️ Usage

For automatic city detection

```
poetry run mrdmnd
```
For manual city enter
```
poetry run mrdmnd -m
```

## 🎑 Presentation 

- => Default

![Default weather presentation](assets/default.png)
- => OneLiner

![OneLiner weather presentation](assets/oneliner.png)

## 📝 Changelog

# Version 1.0.1 (Latest release)
- Added rich support
- Added one new weather report where weather information will be showcased using colours. 

The complete [changelog](https://github.com/padm3-sh/mridumanda/blob/main/LOG.md) can be found here.

## 📍 Note

This project is a rewritten version of the original MriduManda, which was developed under another GitHub account of mine in [this](https://github.com/shvedt/mridu-manda.git) repo. That account is no longer accessible, and as a result, the project is being completely rebuilt here from scratch — keeping its original purpose, but with improved clarity, structure, and maintainability.