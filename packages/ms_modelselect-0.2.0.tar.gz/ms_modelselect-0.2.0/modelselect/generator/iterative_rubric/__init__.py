# -*- coding: utf-8 -*-
# Service for Auto Rubric
