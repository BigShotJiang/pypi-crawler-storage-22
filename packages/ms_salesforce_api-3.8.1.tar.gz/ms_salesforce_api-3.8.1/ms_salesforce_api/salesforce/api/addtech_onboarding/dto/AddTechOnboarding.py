from ms_salesforce_api.salesforce.helpers.string import normalize_value


class AddTechOnboardingDTO(object):
    """
    Data Transfer Object for AddTech Onboarding records from Salesforce.

    Maps Salesforce Yangtse__c object fields to a structured Python object.
    """

    def __init__(
        self,
        id,
        opportunity_name,
        project_code,
        frm_account_name,
        frm_product_name,
        currency_iso_code,
        opportunity_account_manager_name,
        txt_platform_acc_name,
        pck_transfer_new,
        client_type,
        url_transfer_template,
        adex_fee,
        non_adex_fee,
        dcm_impression_fee,
        dcm_clicktracker_fee,
        studio_in_page_fee,
        studio_video_fee,
        per_markup,
        fee,
        email_of_the_account_responsible,
        yangts_service_accounts_have_access,
        partner_id,
        advertiser_id,
        txt_manager_id,
        account_id,
        txt_gmp_org_id,
        txt_entity_id,
        opportunity,
        opportunity_account_id,
    ):
        self.id = id
        self.opportunity_name = opportunity_name
        self.project_code = project_code
        self.frm_account_name = frm_account_name
        self.frm_product_name = frm_product_name
        self.currency_iso_code = currency_iso_code
        self.opportunity_account_manager_name = (
            opportunity_account_manager_name
        )
        self.txt_platform_acc_name = txt_platform_acc_name
        self.pck_transfer_new = pck_transfer_new
        self.client_type = client_type
        self.url_transfer_template = url_transfer_template
        self.adex_fee = adex_fee
        self.non_adex_fee = non_adex_fee
        self.dcm_impression_fee = dcm_impression_fee
        self.dcm_clicktracker_fee = dcm_clicktracker_fee
        self.studio_in_page_fee = studio_in_page_fee
        self.studio_video_fee = studio_video_fee
        self.per_markup = per_markup
        self.fee = fee
        self.email_of_the_account_responsible = (
            email_of_the_account_responsible
        )
        self.yangts_service_accounts_have_access = (
            yangts_service_accounts_have_access
        )
        self.partner_id = partner_id
        self.advertiser_id = advertiser_id
        self.txt_manager_id = txt_manager_id
        self.account_id = account_id
        self.txt_gmp_org_id = txt_gmp_org_id
        self.txt_entity_id = txt_entity_id
        self.opportunity = opportunity
        self.opportunity_account_id = opportunity_account_id

    @staticmethod
    def from_salesforce_record(record: dict):
        """
        Creates an AddTechOnboardingDTO instance from a Salesforce record.

        Args:
            record (dict): A dictionary containing Salesforce record data.

        Returns:
            AddTechOnboardingDTO: An instance of AddTechOnboardingDTO.
        """

        def _get_opportunity_name():
            try:
                return normalize_value(record["Opportunity__r"]["Name"])
            except (KeyError, TypeError):
                return None

        def _get_opportunity_account_manager_name():
            try:
                return normalize_value(
                    record["Opportunity__r"]["LKP_AccountManager__r"]["Name"]
                )
            except (KeyError, TypeError):
                return None

        def _get_opportunity_account_id():
            try:
                return record["Opportunity__r"]["AccountId"]
            except (KeyError, TypeError):
                return None

        return AddTechOnboardingDTO(
            id=record["Id"],
            opportunity_name=_get_opportunity_name(),
            project_code=record.get("ProjectCode__c"),
            frm_account_name=normalize_value(record.get("FRM_AccountName__c")),
            frm_product_name=normalize_value(record.get("FRM_ProductName__c")),
            currency_iso_code=record.get("CurrencyIsoCode"),
            opportunity_account_manager_name=_get_opportunity_account_manager_name(),  # noqa: E501
            txt_platform_acc_name=normalize_value(
                record.get("TXT_PlatformAccName__c")
            ),
            pck_transfer_new=record.get("PCK_TransferNew__c"),
            client_type=record.get("Client_type__c"),
            url_transfer_template=record.get("URL_TransferTemplate__c"),
            adex_fee=record.get("AdEx_Fee__c"),
            non_adex_fee=record.get("Non_AdEx_Fee__c"),
            dcm_impression_fee=record.get("DCM_Impression_Fee__c"),
            dcm_clicktracker_fee=record.get("DCM_Clicktracker_Fee__c"),
            studio_in_page_fee=record.get("Studio_In_Page_Fee__c"),
            studio_video_fee=record.get("Studio_Video_Fee__c"),
            per_markup=record.get("PER_MarkUp__c"),
            fee=record.get("Fee__c"),
            email_of_the_account_responsible=record.get(
                "Email_of_the_Account_Responsible__c"
            ),
            yangts_service_accounts_have_access=record.get(
                "Yangts_service_accounts_have_access__c"
            ),
            partner_id=record.get("Partner_Id__c"),
            advertiser_id=record.get("Advertiser_Id__c"),
            txt_manager_id=record.get("TXT_ManagerId__c"),
            account_id=record.get("Account_Id__c"),
            txt_gmp_org_id=record.get("TXT_GMPOrgID__c"),
            txt_entity_id=record.get("TXT_EntityID__c"),
            opportunity=record["Opportunity__c"],
            opportunity_account_id=_get_opportunity_account_id(),
        )

    def to_dict(self):
        """
        Converts the DTO instance to a dictionary.

        Returns:
            dict: A dictionary representation of the DTO.
        """
        return {
            "id": self.id,
            "opportunity_name": self.opportunity_name,
            "project_code": self.project_code,
            "frm_account_name": self.frm_account_name,
            "frm_product_name": self.frm_product_name,
            "currency_iso_code": self.currency_iso_code,
            "opportunity_account_manager_name": (
                self.opportunity_account_manager_name
            ),
            "txt_platform_acc_name": self.txt_platform_acc_name,
            "pck_transfer_new": self.pck_transfer_new,
            "client_type": self.client_type,
            "url_transfer_template": self.url_transfer_template,
            "adex_fee": self.adex_fee,
            "non_adex_fee": self.non_adex_fee,
            "dcm_impression_fee": self.dcm_impression_fee,
            "dcm_clicktracker_fee": self.dcm_clicktracker_fee,
            "studio_in_page_fee": self.studio_in_page_fee,
            "studio_video_fee": self.studio_video_fee,
            "per_markup": self.per_markup,
            "fee": self.fee,
            "email_of_the_account_responsible": (
                self.email_of_the_account_responsible
            ),
            "yangts_service_accounts_have_access": (
                self.yangts_service_accounts_have_access
            ),
            "partner_id": self.partner_id,
            "advertiser_id": self.advertiser_id,
            "txt_manager_id": self.txt_manager_id,
            "account_id": self.account_id,
            "txt_gmp_org_id": self.txt_gmp_org_id,
            "txt_entity_id": self.txt_entity_id,
            "opportunity": self.opportunity,
            "opportunity_account_id": self.opportunity_account_id,
        }
