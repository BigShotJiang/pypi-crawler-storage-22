import sourcedefender

from mscore.version import (
    __version__,
)
from mscore.ram_models import MScore
from mscore.utilities.authentication import AuthorizeLicense

__all__ = ["MScore", "AuthorizeLicense", "__version__"]
