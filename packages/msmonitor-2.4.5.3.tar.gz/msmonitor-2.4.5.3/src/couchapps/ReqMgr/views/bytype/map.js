function(doc) {
    emit(doc.RequestType, null);
}
