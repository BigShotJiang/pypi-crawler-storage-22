from __future__ import annotations

import os
import re
from dataclasses import dataclass

from msp_copilot.errors import ValidationFailure

_GUID_RE = re.compile(
    r"^[0-9a-fA-F]{8}-"
    r"[0-9a-fA-F]{4}-"
    r"[0-9a-fA-F]{4}-"
    r"[0-9a-fA-F]{4}-"
    r"[0-9a-fA-F]{12}$"
)

_TRUE_VALUES = {"1", "true", "yes", "on"}


@dataclass(frozen=True)
class RuntimeSettings:
    execution_enabled: bool
    operator_email: str

    @staticmethod
    def from_env() -> "RuntimeSettings":
        value = os.getenv("MSP_EXECUTION_ENABLED", "false").strip().lower()
        operator = os.getenv("MSP_OPERATOR_EMAIL", "system").strip() or "system"
        return RuntimeSettings(
            execution_enabled=value in _TRUE_VALUES,
            operator_email=operator,
        )

    @staticmethod
    def is_guid(value: str) -> bool:
        return bool(_GUID_RE.fullmatch((value or "").strip()))

    @staticmethod
    def resolve_tenant_guid(tenant_id: str) -> str:
        normalized = (tenant_id or "").strip()
        if RuntimeSettings.is_guid(normalized):
            return normalized

        env_key = f"MSP_TENANT_ALIAS_{normalized}"
        mapped = os.getenv(env_key, "").strip()
        if not mapped:
            env_key_fallback = f"MSP_TENANT_ALIAS_{normalized.replace('-', '_')}"
            mapped = os.getenv(env_key_fallback, "").strip()

        if not mapped:
            raise ValidationFailure(
                f"unknown tenant alias '{normalized}' (expected env '{env_key}')"
            )
        if not RuntimeSettings.is_guid(mapped):
            raise ValidationFailure(
                f"alias '{normalized}' resolved to non-GUID '{mapped}'"
            )
        return mapped
