from pathlib import Path
from typing import Mapping

import msal  # type: ignore[import-untyped]

AUTHORITY_TEMPLATE = "https://login.microsoftonline.com/{tenant_id}"
SCOPES = ["https://graph.microsoft.com/.default"]


class DeviceCodeAuth:
    def __init__(self, client_id: str, tenant_id: str):
        self.client_id = client_id
        self.tenant_id = tenant_id
        self.cache_path = Path("data/token_cache.json")
        self.cache_path.parent.mkdir(parents=True, exist_ok=True)
        self.token_cache = msal.SerializableTokenCache()
        if self.cache_path.exists():
            self.token_cache.deserialize(self.cache_path.read_text(encoding="utf-8"))
        self.app = msal.PublicClientApplication(
            client_id,
            authority=AUTHORITY_TEMPLATE.format(tenant_id=tenant_id),
            token_cache=self.token_cache,
        )

    def _persist_cache(self) -> None:
        if self.token_cache.has_state_changed:
            self.cache_path.write_text(self.token_cache.serialize(), encoding="utf-8")

    @staticmethod
    def _access_token(result: Mapping[str, object] | None) -> str | None:
        if not result:
            return None
        token = result.get("access_token")
        return token if isinstance(token, str) else None

    def acquire_token(self) -> str:
        accounts = self.app.get_accounts()
        if accounts:
            result = self.app.acquire_token_silent(scopes=SCOPES, account=accounts[0])
            access_token = self._access_token(result)
            if access_token is not None:
                self._persist_cache()
                return access_token

        flow = self.app.initiate_device_flow(scopes=SCOPES)
        if "user_code" not in flow:
            raise Exception("Failed to create device flow")

        print(flow["message"])
        print("Waiting up to 10 minutes for device login approval...")
        result = self.app.acquire_token_by_device_flow(flow)
        self._persist_cache()

        access_token = self._access_token(result)
        if access_token is None:
            raise Exception(f"Auth failed: {result}")

        return access_token
