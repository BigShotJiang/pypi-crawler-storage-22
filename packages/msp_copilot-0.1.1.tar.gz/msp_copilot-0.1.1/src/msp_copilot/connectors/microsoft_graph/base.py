from __future__ import annotations

from typing import Any, Protocol

Evidence = dict[str, Any]


class GraphOperations(Protocol):
    def find_user(self, email: str) -> tuple[str | None, Evidence]:
        ...

    def get_user_profile(self, user_id: str) -> tuple[dict[str, Any] | None, Evidence]:
        ...

    def get_organization_tenant_id(self) -> tuple[str | None, Evidence]:
        ...

    def get_user_account_enabled(self, user_id: str) -> tuple[bool | None, Evidence]:
        ...

    def disable_sign_in(self, user_id: str) -> tuple[bool, Evidence]:
        ...

    def revoke_sessions(self, user_id: str) -> tuple[bool, Evidence]:
        ...

    def remove_admin_roles(self, user_id: str) -> bool:
        ...

    def get_user_license_details(self, user_id: str) -> tuple[list[dict[str, Any]], Evidence]:
        ...

    def assign_licenses(
        self,
        user_id: str,
        add_license_ids: list[str],
        remove_license_ids: list[str],
    ) -> tuple[bool, Evidence]:
        ...

    def list_user_directory_roles(self, user_id: str) -> tuple[list[dict[str, Any]], Evidence]:
        ...

    def remove_directory_role_member(self, role_id: str, user_id: str) -> tuple[bool, Evidence]:
        ...

    def enable_sign_in(self, user_id: str) -> tuple[bool, Evidence]:
        ...

    def get_user_usage_location(self, user_id: str) -> tuple[str | None, Evidence]:
        ...

    def set_user_usage_location(self, user_id: str, usage_location: str) -> tuple[bool, Evidence]:
        ...

    def list_user_group_ids(self, user_id: str) -> tuple[list[str], Evidence]:
        ...

    def add_user_to_group(self, user_id: str, group_id: str) -> tuple[bool, Evidence]:
        ...

    def remove_user_from_group(self, user_id: str, group_id: str) -> tuple[bool, Evidence]:
        ...

    def get_user_force_password_reset(self, user_id: str) -> tuple[bool | None, Evidence]:
        ...

    def set_user_force_password_reset(self, user_id: str, required: bool) -> tuple[bool, Evidence]:
        ...
