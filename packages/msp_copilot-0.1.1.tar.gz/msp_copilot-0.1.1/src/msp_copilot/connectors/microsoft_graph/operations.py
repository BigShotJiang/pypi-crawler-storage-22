"""Mock Microsoft Graph operations for testing and development."""

from __future__ import annotations

import time
import uuid
from typing import Any


class MockGraphOperations:
    """Mock Graph API operations that return fake but realistic data."""

    def __init__(self, sleep_seconds: float = 0.05) -> None:
        self._disabled_users: set[str] = set()
        self._licenses_by_user: dict[str, list[dict[str, str]]] = {}
        self._roles_by_user: dict[str, list[dict[str, str]]] = {}
        self._group_ids_by_user: dict[str, set[str]] = {}
        self._usage_location_by_user: dict[str, str] = {}
        self._force_password_reset_by_user: dict[str, bool] = {}
        self.sleep_seconds = sleep_seconds

    def _sleep(self) -> None:
        if self.sleep_seconds > 0:
            time.sleep(self.sleep_seconds)

    def find_user(self, email: str) -> tuple[str | None, dict[str, Any]]:
        if not email:
            return None, {"http_status": 400, "error_type": "VALIDATION_ERROR", "retryable": False}
        normalized = email.strip()
        if "@" not in normalized:
            return None, {"http_status": 400, "error_type": "VALIDATION_ERROR", "retryable": False}
        self._sleep()
        fake_id = str(uuid.uuid5(uuid.NAMESPACE_DNS, normalized))
        self._licenses_by_user.setdefault(
            fake_id,
            [
                {"skuId": "11111111-1111-1111-1111-111111111111", "skuPartNumber": "M365_BUSINESS_STANDARD"},
                {"skuId": "22222222-2222-2222-2222-222222222222", "skuPartNumber": "POWER_BI_PRO"},
            ],
        )
        self._roles_by_user.setdefault(
            fake_id,
            [
                {"id": "role-1", "displayName": "Global Administrator"},
                {"id": "role-2", "displayName": "User Administrator"},
            ],
        )
        self._group_ids_by_user.setdefault(fake_id, set())
        self._usage_location_by_user.setdefault(fake_id, "US")
        self._force_password_reset_by_user.setdefault(fake_id, False)
        print(f"    [MOCK] find_user({normalized}) -> {fake_id}")
        return fake_id, {"http_status": 200, "user_id": fake_id, "userPrincipalName": normalized}

    def get_user_profile(self, user_id: str) -> tuple[dict[str, Any] | None, dict[str, Any]]:
        if not user_id:
            return None, {"http_status": 400, "error_type": "VALIDATION_ERROR", "retryable": False}
        return {
            "id": user_id,
            "userPrincipalName": "john.doe@cryingman121212outlook882.onmicrosoft.com",
        }, {"http_status": 200}

    def get_organization_tenant_id(self) -> tuple[str | None, dict[str, Any]]:
        return "demo-tenant", {"http_status": 200}

    def get_user_account_enabled(self, user_id: str) -> tuple[bool | None, dict[str, Any]]:
        if not user_id:
            return None, {"http_status": 400, "error_type": "VALIDATION_ERROR", "retryable": False}
        is_enabled = user_id not in self._disabled_users
        return is_enabled, {
            "http_status": 200,
            "accountEnabled": is_enabled,
            "userPrincipalName": "mock.user@example.com",
        }

    def disable_sign_in(self, user_id: str) -> tuple[bool, dict[str, Any]]:
        if not user_id:
            print("    [MOCK] disable_sign_in: invalid user_id")
            return False, {"http_status": 400, "error_type": "VALIDATION_ERROR", "retryable": False}
        self._sleep()
        self._disabled_users.add(user_id)
        print(f"    [MOCK] disable_sign_in({user_id}) -> success")
        return True, {"http_status": 204}

    def revoke_sessions(self, user_id: str) -> tuple[bool, dict[str, Any]]:
        if not user_id:
            print("    [MOCK] revoke_sessions: invalid user_id")
            return False, {"http_status": 400, "error_type": "VALIDATION_ERROR", "retryable": False}
        self._sleep()
        print(f"    [MOCK] revoke_sessions({user_id}) -> success")
        return True, {"http_status": 204}

    def remove_from_groups(self, user_id: str) -> bool:
        if not user_id:
            print("    [MOCK] remove_from_groups: invalid user_id")
            return False
        self._sleep()
        print(f"    [MOCK] remove_from_groups({user_id}) -> success")
        return True

    def delete_mailbox(self, user_id: str) -> bool:
        if not user_id:
            print("    [MOCK] delete_mailbox: invalid user_id")
            return False
        self._sleep()
        print(f"    [MOCK] delete_mailbox({user_id}) -> success")
        return True

    def remove_admin_roles(self, user_id: str) -> bool:
        if not user_id:
            print("    [MOCK] remove_admin_roles: invalid user_id")
            return False
        self._sleep()
        self._roles_by_user[user_id] = []
        print(f"    [MOCK] remove_admin_roles({user_id}) -> success")
        return True

    def get_user_license_details(self, user_id: str) -> tuple[list[dict[str, Any]], dict[str, Any]]:
        if not user_id:
            return [], {"http_status": 400, "error_type": "VALIDATION_ERROR", "retryable": False}
        licenses = self._licenses_by_user.get(user_id, [])
        return list(licenses), {"http_status": 200, "count": len(licenses)}

    def assign_licenses(
        self,
        user_id: str,
        add_license_ids: list[str],
        remove_license_ids: list[str],
    ) -> tuple[bool, dict[str, Any]]:
        if not user_id:
            return False, {"http_status": 400, "error_type": "VALIDATION_ERROR", "retryable": False}
        licenses = self._licenses_by_user.get(user_id, [])
        remove_set = set(remove_license_ids)
        kept = [item for item in licenses if str(item.get("skuId")) not in remove_set]
        for add_id in add_license_ids:
            kept.append({"skuId": add_id, "skuPartNumber": add_id})
        self._licenses_by_user[user_id] = kept
        return True, {"http_status": 200, "removed_count": len(remove_license_ids), "added_count": len(add_license_ids)}

    def list_user_directory_roles(self, user_id: str) -> tuple[list[dict[str, Any]], dict[str, Any]]:
        if not user_id:
            return [], {"http_status": 400, "error_type": "VALIDATION_ERROR", "retryable": False}
        roles = self._roles_by_user.get(user_id, [])
        return list(roles), {"http_status": 200, "count": len(roles)}

    def remove_directory_role_member(self, role_id: str, user_id: str) -> tuple[bool, dict[str, Any]]:
        if not role_id or not user_id:
            return False, {"http_status": 400, "error_type": "VALIDATION_ERROR", "retryable": False}
        roles = self._roles_by_user.get(user_id, [])
        self._roles_by_user[user_id] = [role for role in roles if str(role.get("id")) != role_id]
        return True, {"http_status": 204, "role_id": role_id}

    def enable_sign_in(self, user_id: str) -> tuple[bool, dict[str, Any]]:
        if not user_id:
            return False, {"http_status": 400, "error_type": "VALIDATION_ERROR", "retryable": False}
        self._disabled_users.discard(user_id)
        return True, {"http_status": 204}

    def get_user_usage_location(self, user_id: str) -> tuple[str | None, dict[str, Any]]:
        if not user_id:
            return None, {"http_status": 400, "error_type": "VALIDATION_ERROR", "retryable": False}
        return self._usage_location_by_user.get(user_id), {"http_status": 200}

    def set_user_usage_location(self, user_id: str, usage_location: str) -> tuple[bool, dict[str, Any]]:
        if not user_id or not usage_location:
            return False, {"http_status": 400, "error_type": "VALIDATION_ERROR", "retryable": False}
        self._usage_location_by_user[user_id] = usage_location
        return True, {"http_status": 204, "usageLocation": usage_location}

    def list_user_group_ids(self, user_id: str) -> tuple[list[str], dict[str, Any]]:
        if not user_id:
            return [], {"http_status": 400, "error_type": "VALIDATION_ERROR", "retryable": False}
        groups = sorted(list(self._group_ids_by_user.get(user_id, set())))
        return groups, {"http_status": 200, "count": len(groups)}

    def add_user_to_group(self, user_id: str, group_id: str) -> tuple[bool, dict[str, Any]]:
        if not user_id or not group_id:
            return False, {"http_status": 400, "error_type": "VALIDATION_ERROR", "retryable": False}
        groups = self._group_ids_by_user.setdefault(user_id, set())
        groups.add(group_id)
        return True, {"http_status": 204, "group_id": group_id}

    def remove_user_from_group(self, user_id: str, group_id: str) -> tuple[bool, dict[str, Any]]:
        if not user_id or not group_id:
            return False, {"http_status": 400, "error_type": "VALIDATION_ERROR", "retryable": False}
        groups = self._group_ids_by_user.setdefault(user_id, set())
        groups.discard(group_id)
        return True, {"http_status": 204, "group_id": group_id}

    def get_user_force_password_reset(self, user_id: str) -> tuple[bool | None, dict[str, Any]]:
        if not user_id:
            return None, {"http_status": 400, "error_type": "VALIDATION_ERROR", "retryable": False}
        return self._force_password_reset_by_user.get(user_id), {"http_status": 200}

    def set_user_force_password_reset(self, user_id: str, required: bool) -> tuple[bool, dict[str, Any]]:
        if not user_id:
            return False, {"http_status": 400, "error_type": "VALIDATION_ERROR", "retryable": False}
        self._force_password_reset_by_user[user_id] = required
        return True, {"http_status": 204, "forceChangePasswordNextSignIn": required}
