from __future__ import annotations

import random
import time
from typing import Any, Callable

import requests


class RealGraphOperations:
    RETRYABLE_STATUSES = {429, 502, 503, 504}
    MAX_RETRIES = 3
    TIMEOUT_SECONDS = 30

    def __init__(
        self,
        access_token: str,
        request_fn: Callable[..., requests.Response] | None = None,
        sleep_fn: Callable[[float], None] | None = None,
        rng_fn: Callable[[float, float], float] | None = None,
    ) -> None:
        self.base_url = "https://graph.microsoft.com/v1.0"
        self.headers = {
            "Authorization": f"Bearer {access_token}",
            "Content-Type": "application/json",
        }
        self._request_fn = request_fn
        self._sleep_fn = sleep_fn
        self._rng_fn = rng_fn or random.uniform

    def _parse_retry_after(self, value: str | None) -> float | None:
        if not value:
            return None
        try:
            seconds = float(value)
            return max(0.0, seconds)
        except ValueError:
            return None

    def _classify_status(self, status_code: int) -> tuple[str, bool]:
        if status_code == 401:
            return "AUTH_ERROR", False
        if status_code == 403:
            return "PERMISSION_ERROR", False
        if status_code == 404:
            return "NOT_FOUND", False
        if status_code == 429:
            return "RATE_LIMIT", True
        if status_code in (502, 503, 504):
            return "TRANSIENT", True
        if status_code >= 500:
            return "TRANSIENT", True
        if status_code == 400:
            return "VALIDATION_ERROR", False
        return "GRAPH_ERROR", False

    def _safe_error_body(self, resp: requests.Response) -> str:
        try:
            body = resp.text or ""
        except Exception:
            body = ""
        return body[:300]

    def _evidence(self, resp: requests.Response | None = None) -> dict[str, Any]:
        if resp is None:
            return {}
        error_type, retryable = self._classify_status(resp.status_code)
        return {
            "http_status": resp.status_code,
            "request_id": resp.headers.get("request-id") or resp.headers.get("x-ms-request-id"),
            "client_request_id": resp.headers.get("client-request-id"),
            "error_type": error_type,
            "retryable": retryable,
        }

    def _request(
        self, method: str, url: str, json: dict[str, Any] | None = None
    ) -> tuple[requests.Response | None, dict[str, Any]]:
        attempts = 0
        while True:
            attempts += 1
            try:
                request_fn = self._request_fn or requests.request
                resp = request_fn(
                    method=method,
                    url=url,
                    headers=self.headers,
                    json=json,
                    timeout=self.TIMEOUT_SECONDS,
                )
                ev = self._evidence(resp)
                ev["attempts"] = attempts

                should_retry = (
                    resp.status_code in self.RETRYABLE_STATUSES and attempts <= self.MAX_RETRIES
                )
                if should_retry:
                    retry_after = self._parse_retry_after(resp.headers.get("Retry-After"))
                    if retry_after is None:
                        base = 2 ** (attempts - 1)
                        retry_after = base + self._rng_fn(0, 0.25 * base)
                    sleep_fn = self._sleep_fn or time.sleep
                    sleep_fn(retry_after)
                    continue

                if resp.status_code >= 400:
                    ev["error_body"] = self._safe_error_body(resp)
                return resp, ev

            except (requests.Timeout, requests.ConnectionError) as exc:
                ev = {
                    "error_type": "TRANSIENT",
                    "retryable": True,
                    "attempts": attempts,
                    "exception": str(exc)[:300],
                }
                if attempts <= self.MAX_RETRIES:
                    base = 2 ** (attempts - 1)
                    delay = base + self._rng_fn(0, 0.25 * base)
                    sleep_fn = self._sleep_fn or time.sleep
                    sleep_fn(delay)
                    continue
                return None, ev
            except requests.RequestException as exc:
                return None, {
                    "error_type": "GRAPH_ERROR",
                    "retryable": False,
                    "attempts": attempts,
                    "exception": str(exc)[:300],
                }

    def find_user(self, email: str) -> tuple[str | None, dict]:
        url = f"{self.base_url}/users/{email}"
        resp, ev = self._request("GET", url)
        if resp is not None and resp.status_code == 200:
            data = resp.json()
            ev["user_id"] = data.get("id")
            ev["userPrincipalName"] = data.get("userPrincipalName")
            return data.get("id"), ev
        return None, ev

    def get_user_profile(self, user_id: str) -> tuple[dict[str, Any] | None, dict[str, Any]]:
        url = f"{self.base_url}/users/{user_id}?$select=id,userPrincipalName"
        resp, ev = self._request("GET", url)
        if resp is not None and resp.status_code == 200:
            data = resp.json()
            return {
                "id": data.get("id"),
                "userPrincipalName": data.get("userPrincipalName"),
            }, ev
        return None, ev

    def get_organization_tenant_id(self) -> tuple[str | None, dict]:
        url = f"{self.base_url}/organization?$select=id"
        resp, ev = self._request("GET", url)
        if resp is not None and resp.status_code == 200:
            data = resp.json()
            value = data.get("value", [])
            if value and isinstance(value, list):
                org_id = value[0].get("id")
                ev["tenant_id"] = org_id
                return org_id, ev
        return None, ev

    def get_user_account_enabled(self, user_id: str) -> tuple[bool | None, dict]:
        url = f"{self.base_url}/users/{user_id}?$select=id,accountEnabled,userPrincipalName"
        resp, ev = self._request("GET", url)
        if resp is not None and resp.status_code == 200:
            data = resp.json()
            ev["accountEnabled"] = data.get("accountEnabled")
            ev["userPrincipalName"] = data.get("userPrincipalName")
            return data.get("accountEnabled"), ev
        return None, ev

    def disable_sign_in(self, user_id: str) -> tuple[bool, dict]:
        url = f"{self.base_url}/users/{user_id}"
        payload = {"accountEnabled": False}
        resp, ev = self._request("PATCH", url, json=payload)
        if resp is not None and resp.status_code in (200, 204):
            ev["patched_accountEnabled"] = False
            return True, ev
        return False, ev

    def revoke_sessions(self, user_id: str) -> tuple[bool, dict]:
        url = f"{self.base_url}/users/{user_id}/revokeSignInSessions"
        resp, ev = self._request("POST", url)
        if resp is not None and resp.status_code in (200, 204):
            return True, ev
        return False, ev

    def remove_from_groups(self, user_id: str) -> bool:
        # Leave as mock for now.
        return True

    def delete_mailbox(self, user_id: str) -> bool:
        # Leave as mock for now.
        return True

    def remove_admin_roles(self, user_id: str) -> bool:
        roles, _ = self.list_user_directory_roles(user_id)
        for role in roles:
            role_id = str(role.get("id") or "")
            if not role_id:
                continue
            ok, _ = self.remove_directory_role_member(role_id, user_id)
            if not ok:
                return False
        return True

    def get_user_license_details(self, user_id: str) -> tuple[list[dict[str, Any]], dict[str, Any]]:
        url = f"{self.base_url}/users/{user_id}/licenseDetails"
        resp, ev = self._request("GET", url)
        if resp is not None and resp.status_code == 200:
            data = resp.json()
            raw_items = data.get("value", [])
            licenses: list[dict[str, Any]] = []
            if isinstance(raw_items, list):
                for item in raw_items:
                    if not isinstance(item, dict):
                        continue
                    licenses.append(
                        {
                            "skuId": item.get("skuId"),
                            "skuPartNumber": item.get("skuPartNumber"),
                        }
                    )
            ev["count"] = len(licenses)
            return licenses, ev
        return [], ev

    def assign_licenses(
        self,
        user_id: str,
        add_license_ids: list[str],
        remove_license_ids: list[str],
    ) -> tuple[bool, dict[str, Any]]:
        url = f"{self.base_url}/users/{user_id}/assignLicense"
        payload = {
            "addLicenses": [{"skuId": sku_id} for sku_id in add_license_ids],
            "removeLicenses": remove_license_ids,
        }
        resp, ev = self._request("POST", url, json=payload)
        if resp is not None and resp.status_code in (200, 204):
            ev["removed_count"] = len(remove_license_ids)
            ev["added_count"] = len(add_license_ids)
            return True, ev
        return False, ev

    def list_user_directory_roles(self, user_id: str) -> tuple[list[dict[str, Any]], dict[str, Any]]:
        url = f"{self.base_url}/users/{user_id}/memberOf?$select=id,displayName"
        resp, ev = self._request("GET", url)
        if resp is not None and resp.status_code == 200:
            data = resp.json()
            raw_items = data.get("value", [])
            roles: list[dict[str, Any]] = []
            if isinstance(raw_items, list):
                for item in raw_items:
                    if not isinstance(item, dict):
                        continue
                    odata_type = str(item.get("@odata.type") or "")
                    if "directoryRole" not in odata_type:
                        continue
                    roles.append({"id": item.get("id"), "displayName": item.get("displayName")})
            ev["count"] = len(roles)
            return roles, ev
        return [], ev

    def remove_directory_role_member(self, role_id: str, user_id: str) -> tuple[bool, dict[str, Any]]:
        url = f"{self.base_url}/directoryRoles/{role_id}/members/{user_id}/$ref"
        resp, ev = self._request("DELETE", url)
        if resp is not None and resp.status_code in (200, 204):
            return True, ev
        return False, ev

    def enable_sign_in(self, user_id: str) -> tuple[bool, dict[str, Any]]:  # pragma: no cover
        url = f"{self.base_url}/users/{user_id}"
        payload = {"accountEnabled": True}
        resp, ev = self._request("PATCH", url, json=payload)
        if resp is not None and resp.status_code in (200, 204):
            ev["patched_accountEnabled"] = True
            return True, ev
        return False, ev

    def get_user_usage_location(self, user_id: str) -> tuple[str | None, dict[str, Any]]:  # pragma: no cover
        url = f"{self.base_url}/users/{user_id}?$select=id,usageLocation"
        resp, ev = self._request("GET", url)
        if resp is not None and resp.status_code == 200:
            data = resp.json()
            usage_location = data.get("usageLocation")
            if isinstance(usage_location, str):
                ev["usageLocation"] = usage_location
                return usage_location, ev
            return None, ev
        return None, ev

    def set_user_usage_location(self, user_id: str, usage_location: str) -> tuple[bool, dict[str, Any]]:  # pragma: no cover
        url = f"{self.base_url}/users/{user_id}"
        payload = {"usageLocation": usage_location}
        resp, ev = self._request("PATCH", url, json=payload)
        if resp is not None and resp.status_code in (200, 204):
            ev["usageLocation"] = usage_location
            return True, ev
        return False, ev

    def list_user_group_ids(self, user_id: str) -> tuple[list[str], dict[str, Any]]:  # pragma: no cover
        url = f"{self.base_url}/users/{user_id}/memberOf?$select=id"
        resp, ev = self._request("GET", url)
        if resp is not None and resp.status_code == 200:
            data = resp.json()
            raw_items = data.get("value", [])
            groups: list[str] = []
            if isinstance(raw_items, list):
                for item in raw_items:
                    if not isinstance(item, dict):
                        continue
                    odata_type = str(item.get("@odata.type") or "")
                    if "group" not in odata_type:
                        continue
                    group_id = str(item.get("id") or "")
                    if group_id:
                        groups.append(group_id)
            ev["count"] = len(groups)
            return groups, ev
        return [], ev

    def add_user_to_group(self, user_id: str, group_id: str) -> tuple[bool, dict[str, Any]]:  # pragma: no cover
        url = f"{self.base_url}/groups/{group_id}/members/$ref"
        payload = {
            "@odata.id": f"{self.base_url}/directoryObjects/{user_id}",
        }
        resp, ev = self._request("POST", url, json=payload)
        if resp is not None and resp.status_code in (200, 204):
            ev["group_id"] = group_id
            return True, ev
        return False, ev

    def remove_user_from_group(self, user_id: str, group_id: str) -> tuple[bool, dict[str, Any]]:  # pragma: no cover
        url = f"{self.base_url}/groups/{group_id}/members/{user_id}/$ref"
        resp, ev = self._request("DELETE", url)
        if resp is not None and resp.status_code in (200, 204):
            ev["group_id"] = group_id
            return True, ev
        return False, ev

    def get_user_force_password_reset(self, user_id: str) -> tuple[bool | None, dict[str, Any]]:  # pragma: no cover
        url = f"{self.base_url}/users/{user_id}?$select=id,passwordProfile"
        resp, ev = self._request("GET", url)
        if resp is not None and resp.status_code == 200:
            data = resp.json()
            profile = data.get("passwordProfile")
            if isinstance(profile, dict):
                value = profile.get("forceChangePasswordNextSignIn")
                if isinstance(value, bool):
                    ev["forceChangePasswordNextSignIn"] = value
                    return value, ev
            return None, ev
        return None, ev

    def set_user_force_password_reset(self, user_id: str, required: bool) -> tuple[bool, dict[str, Any]]:  # pragma: no cover
        url = f"{self.base_url}/users/{user_id}"
        payload = {"passwordProfile": {"forceChangePasswordNextSignIn": required}}
        resp, ev = self._request("PATCH", url, json=payload)
        if resp is not None and resp.status_code in (200, 204):
            ev["forceChangePasswordNextSignIn"] = required
            return True, ev
        return False, ev
