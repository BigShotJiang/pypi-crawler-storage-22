from dataclasses import dataclass
from typing import Any, Dict


@dataclass(frozen=True)
class Action:
    name: str
    requires_approval: bool = False
    params: Dict[str, Any] | None = None


@dataclass
class StepExecution:
    """Records execution status and timing for a single action step."""
    step: int
    action: str
    status: str  # "planned" | "completed" | "blocked" | "failed" | "skipped"
    detail: str = ""
    started_at: str | None = None
    ended_at: str | None = None
    requires_approval: bool = False
    evidence: Dict[str, Any] | None = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "step": self.step,
            "action": self.action,
            "status": self.status,
            "detail": self.detail,
            "started_at": self.started_at,
            "ended_at": self.ended_at,
            "requires_approval": self.requires_approval,
            "evidence": self.evidence or {},
        }
