from dataclasses import dataclass
from typing import List

from msp_copilot.domain.action import Action


@dataclass(frozen=True)
class Plan:
    actions: List[Action]
