from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class RunResult:
    success: bool
    run_log_path: Path
