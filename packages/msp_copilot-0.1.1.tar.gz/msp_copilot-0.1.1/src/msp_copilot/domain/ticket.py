from dataclasses import dataclass

from pydantic import BaseModel, EmailStr, Field, ValidationError

_GUID_PATTERN = (
    r"^[0-9a-fA-F]{8}-"
    r"[0-9a-fA-F]{4}-"
    r"[0-9a-fA-F]{4}-"
    r"[0-9a-fA-F]{4}-"
    r"[0-9a-fA-F]{12}$"
)


class TicketModel(BaseModel):
    """Validated ticket schema using Pydantic."""
    ticket_id: str = Field(..., pattern=r'^[a-z0-9_-]+$', min_length=3, max_length=100)
    type: str = Field(..., pattern=r'^(onboarding|offboarding|group_diff)$')
    tenant_id: str = Field(..., pattern=r'^[a-z0-9-]+$', min_length=3, max_length=100)
    user_email: EmailStr
    remove_sku_ids: list[str] = Field(default_factory=list)
    add_sku_ids: list[str] = Field(default_factory=list)
    add_group_ids: list[str] = Field(default_factory=list)
    desired_group_ids: list[str] = Field(default_factory=list)
    group_diff_scope: str = Field(default="managed_only", pattern=r"^(all|managed_only)$")
    usage_location: str | None = Field(default=None, pattern=r"^[A-Za-z]{2}$")
    require_password_reset: bool = False
    mailbox_identity: EmailStr | None = None

    @staticmethod
    def _validate_sku_ids(sku_ids: list[str]) -> list[str]:
        normalized: list[str] = []
        for sku_id in sku_ids:
            value = (sku_id or "").strip()
            if not value:
                continue
            normalized.append(value)
        return normalized


@dataclass(frozen=True)
class Ticket:
    ticket_id: str
    type: str
    tenant_id: str
    user_email: str
    remove_sku_ids: tuple[str, ...] = ()
    add_sku_ids: tuple[str, ...] = ()
    add_group_ids: tuple[str, ...] = ()
    desired_group_ids: tuple[str, ...] = ()
    group_diff_scope: str = "managed_only"
    usage_location: str | None = None
    require_password_reset: bool = False
    mailbox_identity: str | None = None

    @staticmethod
    def from_dict(d: dict) -> "Ticket":
        """Create Ticket with validation."""
        try:
            validated = TicketModel(**d)
            remove_sku_ids = TicketModel._validate_sku_ids(validated.remove_sku_ids)
            add_sku_ids = TicketModel._validate_sku_ids(validated.add_sku_ids)
            add_group_ids = TicketModel._validate_sku_ids(validated.add_group_ids)
            desired_group_ids = TicketModel._validate_sku_ids(validated.desired_group_ids)
            return Ticket(
                ticket_id=validated.ticket_id,
                type=validated.type,
                tenant_id=validated.tenant_id,
                user_email=validated.user_email,
                remove_sku_ids=tuple(remove_sku_ids),
                add_sku_ids=tuple(add_sku_ids),
                add_group_ids=tuple(add_group_ids),
                desired_group_ids=tuple(desired_group_ids),
                group_diff_scope=validated.group_diff_scope,
                usage_location=validated.usage_location.upper() if validated.usage_location else None,
                require_password_reset=bool(validated.require_password_reset),
                mailbox_identity=str(validated.mailbox_identity) if validated.mailbox_identity else None,
            )
        except ValidationError as e:
            raise ValueError(f"Invalid ticket: {e}") from e
