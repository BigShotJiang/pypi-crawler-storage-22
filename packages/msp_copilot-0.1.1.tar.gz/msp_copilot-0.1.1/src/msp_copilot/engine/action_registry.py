from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ActionSpec:
    action_id: str
    requires_approval: bool
    safe_repeatable: bool
    touches: tuple[str, ...] = ()
    precheck: str | None = None
    execute: str | None = None
    verify: str | None = None
    compensation: str | None = None


ACTION_REGISTRY: dict[str, ActionSpec] = {
    "find_user": ActionSpec(
        action_id="find_user",
        requires_approval=False,
        safe_repeatable=True,
        touches=("directory:user", "directory:tenant"),
        execute="_action_find_user_execute",
        verify="_action_find_user_verify",
    ),
    "disable_sign_in": ActionSpec(
        action_id="disable_sign_in",
        requires_approval=False,
        safe_repeatable=True,
        touches=("directory:user.accountEnabled",),
        precheck="_action_disable_sign_in_precheck",
        execute="_action_disable_sign_in_execute",
        verify="_action_disable_sign_in_verify",
    ),
    "revoke_sessions": ActionSpec(
        action_id="revoke_sessions",
        requires_approval=False,
        safe_repeatable=True,
        touches=("identity:sessionTokens",),
        execute="_action_revoke_sessions_execute",
    ),
    "remove_admin_roles": ActionSpec(
        action_id="remove_admin_roles",
        requires_approval=False,
        safe_repeatable=True,
        touches=("directory:user.roles",),
        precheck="_action_remove_admin_roles_precheck",
        execute="_action_remove_admin_roles_execute",
        verify="_action_remove_admin_roles_verify",
    ),
    "remove_licenses": ActionSpec(
        action_id="remove_licenses",
        requires_approval=True,
        safe_repeatable=True,
        touches=("license:assignments",),
        precheck="_action_remove_licenses_precheck",
        execute="_action_remove_licenses_execute",
        verify="_action_remove_licenses_verify",
        compensation="_action_remove_licenses_compensation",
    ),
    "convert_mailbox": ActionSpec(
        action_id="convert_mailbox",
        requires_approval=True,
        safe_repeatable=True,
        touches=("exchange:mailboxType",),
        precheck="_action_convert_mailbox_precheck",
        execute="_action_convert_mailbox_execute",
        verify="_action_convert_mailbox_verify",
    ),
    "ensure_sign_in_enabled": ActionSpec(
        action_id="ensure_sign_in_enabled",
        requires_approval=False,
        safe_repeatable=True,
        touches=("directory:user.accountEnabled",),
        precheck="_action_ensure_sign_in_enabled_precheck",
        execute="_action_ensure_sign_in_enabled_execute",
        verify="_action_ensure_sign_in_enabled_verify",
    ),
    "set_usage_location": ActionSpec(
        action_id="set_usage_location",
        requires_approval=False,
        safe_repeatable=True,
        touches=("directory:user.usageLocation",),
        precheck="_action_set_usage_location_precheck",
        execute="_action_set_usage_location_execute",
        verify="_action_set_usage_location_verify",
    ),
    "assign_licenses": ActionSpec(
        action_id="assign_licenses",
        requires_approval=True,
        safe_repeatable=True,
        touches=("license:assignments",),
        precheck="_action_assign_licenses_precheck",
        execute="_action_assign_licenses_execute",
        verify="_action_assign_licenses_verify",
        compensation="_action_assign_licenses_compensation",
    ),
    "add_to_groups": ActionSpec(
        action_id="add_to_groups",
        requires_approval=False,
        safe_repeatable=True,
        touches=("directory:user.groupMembership",),
        precheck="_action_add_to_groups_precheck",
        execute="_action_add_to_groups_execute",
        verify="_action_add_to_groups_verify",
    ),
    "require_password_reset": ActionSpec(
        action_id="require_password_reset",
        requires_approval=False,
        safe_repeatable=True,
        touches=("directory:user.passwordProfile",),
        precheck="_action_require_password_reset_precheck",
        execute="_action_require_password_reset_execute",
        verify="_action_require_password_reset_verify",
    ),
    "group_diff_apply": ActionSpec(
        action_id="group_diff_apply",
        requires_approval=True,
        safe_repeatable=True,
        touches=("directory:user.groupMembership",),
        precheck="_action_group_diff_apply_precheck",
        execute="_action_group_diff_apply_execute",
        verify="_action_group_diff_apply_verify",
        compensation="_action_group_diff_apply_compensation",
    ),
}

WORKFLOW_REGISTRY: dict[str, list[str]] = {
    "offboarding": [
        "find_user",
        "disable_sign_in",
        "revoke_sessions",
        "remove_admin_roles",
        "remove_licenses",
        "convert_mailbox",
    ],
    "onboarding": [
        "find_user",
        "ensure_sign_in_enabled",
        "set_usage_location",
        "assign_licenses",
        "add_to_groups",
        "require_password_reset",
    ],
    "group_diff": [
        "find_user",
        "group_diff_apply",
    ],
}


def get_action_spec(action_id: str) -> ActionSpec:
    spec = ACTION_REGISTRY.get(action_id)
    if spec is None:
        raise ValueError(f"Unknown action id: {action_id}")
    return spec


def get_workflow_action_ids(ticket_type: str) -> list[str]:
    action_ids = WORKFLOW_REGISTRY.get(ticket_type)
    if action_ids is None:
        raise ValueError(f"Unsupported ticket type: {ticket_type}")
    return action_ids


def get_workflow_specs(ticket_type: str) -> list[ActionSpec]:
    action_ids = get_workflow_action_ids(ticket_type)
    return [get_action_spec(action_id) for action_id in action_ids]
