import json
from pathlib import Path
from typing import Any, Dict

from msp_copilot.storage.models import RunLog
from msp_copilot.utils.redact import redact_sensitive


class Auditor:
    def __init__(self, runs_dir: Path) -> None:
        self.runs_dir = runs_dir
        self.runs_dir.mkdir(parents=True, exist_ok=True)

    def _run_path(self, run_id: str) -> Path:
        return self.runs_dir / f"run_{run_id}.json"

    def create_run(self, run_id: str, payload: Dict[str, Any]) -> Path:
        path = self._run_path(run_id)
        validated = self._validate(payload)
        path.write_text(json.dumps(validated, indent=2), encoding="utf-8")
        return path

    def update_run(self, run_id: str, payload: Dict[str, Any]) -> Path:
        path = self._run_path(run_id)
        validated = self._validate(payload)
        path.write_text(json.dumps(validated, indent=2), encoding="utf-8")
        return path

    def write_run_log(self, payload: Dict[str, Any]) -> Path:
        run_id = str(payload.get("run_id", "unknown"))
        return self.update_run(run_id=run_id, payload=payload)

    def _validate(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        sanitized = redact_sensitive(payload)
        model = RunLog.model_validate(sanitized)
        return model.model_dump(by_alias=True)
