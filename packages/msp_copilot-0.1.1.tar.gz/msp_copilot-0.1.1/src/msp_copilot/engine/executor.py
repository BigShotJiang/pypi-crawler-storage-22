from __future__ import annotations

import os
import subprocess
import uuid
from collections.abc import Callable
from datetime import datetime, timezone
from importlib.metadata import PackageNotFoundError, version
from typing import Any

from msp_copilot.connectors.microsoft_graph.auth import DeviceCodeAuth
from msp_copilot.connectors.microsoft_graph.base import GraphOperations
from msp_copilot.connectors.microsoft_graph.operations import MockGraphOperations
from msp_copilot.connectors.microsoft_graph.real_operations import RealGraphOperations
from msp_copilot.domain.action import StepExecution
from msp_copilot.domain.plan import Plan
from msp_copilot.domain.result import RunResult
from msp_copilot.domain.ticket import Ticket
from msp_copilot.engine.action_registry import ActionSpec, get_action_spec
from msp_copilot.engine.auditor import Auditor


class Executor:
    def __init__(
        self,
        auditor: Auditor,
        prefer_real: bool = True,
        now_fn: Callable[[], datetime] | None = None,
    ) -> None:
        self.auditor = auditor
        self._now_fn = now_fn or (lambda: datetime.now(timezone.utc))
        client_id = os.getenv("MSP_GRAPH_CLIENT_ID", "").strip()
        tenant_id = os.getenv("MSP_GRAPH_TENANT_ID", "").strip()
        self.graph_ops: GraphOperations

        if prefer_real and client_id and tenant_id:
            auth = DeviceCodeAuth(client_id=client_id, tenant_id=tenant_id)
            token = auth.acquire_token()
            self.graph_ops = RealGraphOperations(token)
            print("[INFO] Using RealGraphOperations (Microsoft Graph)")
        else:
            self.graph_ops = MockGraphOperations()
            print(
                "[INFO] Using MockGraphOperations "
                "(set MSP_GRAPH_CLIENT_ID and MSP_GRAPH_TENANT_ID for real Graph)"
            )
        self.user_id: str | None = None
        self.resolved_tenant_id: str | None = None
        self.resolved_user_principal_name: str | None = None
        self._target_remove_sku_ids: list[str] = []
        self._target_add_sku_ids: list[str] = []
        self._target_remove_role_ids: list[str] = []
        self._target_add_group_ids: list[str] = []
        self._target_usage_location: str | None = None
        self._group_diff_to_add: list[str] = []
        self._group_diff_to_remove: list[str] = []
        self._group_diff_scope: str = "managed_only"
        self._approved_actions_runtime: set[str] = set()
        self._last_evidence: dict[str, Any] | None = None

    def _get_run_version(self) -> str:
        try:
            return version("msp-copilot")
        except PackageNotFoundError:
            return "unknown"

    def _get_git_commit(self) -> str:
        try:
            proc = subprocess.run(
                ["git", "rev-parse", "--short", "HEAD"],
                capture_output=True,
                text=True,
                check=True,
            )
            commit = proc.stdout.strip()
            return commit or "unknown"
        except Exception:
            return "unknown"

    def _build_run_summary(self, steps: list[dict[str, Any]]) -> str:
        lines: list[str] = []
        for step in steps:
            action = step.get("action", "unknown")
            status = step.get("status", "unknown")
            detail = step.get("detail", "")
            evidence = step.get("evidence", {}) if isinstance(step.get("evidence"), dict) else {}

            if status == "completed":
                extra = ""
                if action == "find_user":
                    user_id = self.user_id or evidence.get("user_id")
                    if user_id:
                        extra = f" (user id {user_id})"
                elif action == "disable_sign_in":
                    verify = evidence.get("verify", {})
                    if isinstance(verify, dict) and verify.get("accountEnabled") is False:
                        extra = " (verified)"
                lines.append(f"[OK] {action}{extra}")
            elif status == "blocked":
                if "Requires approval" in detail:
                    lines.append(f"[BLOCKED] {action} (approval required)")
                else:
                    lines.append(f"[BLOCKED] {action}")
            elif status == "failed":
                lines.append(f"[FAIL] {action}: {detail}")
            elif status == "skipped":
                lines.append(f"[SKIP] {action}: {detail}")
            else:
                lines.append(f"[{status.upper()}] {action}")
        return "\n".join(lines)

    def run(
        self,
        ticket: Ticket,
        plan: Plan,
        dry_run: bool = True,
        approved_actions: set[str] | None = None,
        operator: str = "system",
        run_id: str | None = None,
        started_at: datetime | None = None,
    ) -> RunResult:
        steps_out: list[dict[str, Any]] = []
        success = True
        approved_actions = approved_actions or set()
        self._target_remove_sku_ids = []
        self._target_add_sku_ids = []
        self._target_remove_role_ids = []
        self._target_add_group_ids = []
        self._target_usage_location = None
        self._group_diff_to_add = []
        self._group_diff_to_remove = []
        self._group_diff_scope = "managed_only"
        self._approved_actions_runtime = set(approved_actions)
        
        # Generate unique run ID for this execution
        run_id = run_id or str(uuid.uuid4())
        
        # Capture execution start time
        started_at = started_at or self._now_fn()

        print("\n=== PLAN ===")
        for i, action in enumerate(plan.actions, start=1):
            mode = "DRY RUN" if dry_run else "EXECUTE"
            approval = " (approval)" if action.requires_approval else ""
            print(f"[{mode}] {i}. {action.name}{approval}")

            step_exec = StepExecution(
                step=i,
                action=action.name,
                status="planned",
                detail="Step planned for execution",
                requires_approval=action.requires_approval,
            )

            if dry_run:
                steps_out.append(step_exec.to_dict())
                continue

            # Execute (with approval gating)
            step_exec = self._execute_step(
                ticket=ticket,
                step_exec=step_exec,
                requires_approval=action.requires_approval,
                approved_actions=approved_actions,
            )
            steps_out.append(step_exec.to_dict())

            if step_exec.status == "failed":
                success = False

                # Mark remaining steps as skipped
                for k in range(i + 1, len(plan.actions) + 1):
                    remaining_action = plan.actions[k - 1]
                    skipped = StepExecution(
                        step=k,
                        action=remaining_action.name,
                        status="skipped",
                        detail=f"Skipped due to failure at step {i}: {action.name}",
                        requires_approval=remaining_action.requires_approval,
                    )
                    steps_out.append(skipped.to_dict())
                break
        
        # Capture execution completion time
        completed_at = self._now_fn()
        duration_seconds = (completed_at - started_at).total_seconds()

        run_log = {
            "run_schema_version": 1,
            "run_id": run_id,
            "started_at": started_at.isoformat(),
            "completed_at": completed_at.isoformat(),
            "duration_seconds": duration_seconds,
            "ticket": {
                "ticket_id": ticket.ticket_id,
                "type": ticket.type,
                "tenant_id": ticket.tenant_id,
                "user_email": ticket.user_email,
            },
            "dry_run": dry_run,
            "operator": operator,
            "run_version": self._get_run_version(),
            "git_commit": self._get_git_commit(),
            "approved_actions": sorted(list(approved_actions)),
            "resolved_tenant_id": self.resolved_tenant_id,
            "resolved_user_id": self.user_id,
            "resolved_user_principal_name": self.resolved_user_principal_name,
            "steps": steps_out,
            "run_summary.txt": self._build_run_summary(steps_out),
            "success": success,
            "status": "completed" if success else "failed",
        }

        run_log_path = self.auditor.update_run(run_id=run_id, payload=run_log)
        return RunResult(success=success, run_log_path=run_log_path)

    def _execute_step(
        self,
        ticket: Ticket,
        step_exec: StepExecution,
        requires_approval: bool,
        approved_actions: set[str],
    ) -> StepExecution:
        started_at = self._now_fn().isoformat()
        self._last_evidence = None
        status = "completed"
        detail = "Step executed successfully"

        # Approval gate
        if (
            requires_approval
            and step_exec.action not in approved_actions
            and step_exec.action != "group_diff_apply"
        ):
            ended_at = self._now_fn().isoformat()
            return StepExecution(
                step=step_exec.step,
                action=step_exec.action,
                status="blocked",
                detail=f"Requires approval (use --approve {step_exec.action})",
                started_at=started_at,
                ended_at=ended_at,
                requires_approval=True,
                evidence=self._last_evidence,
            )

        try:
            spec = get_action_spec(step_exec.action)
            handler_result = self._execute_action_spec(spec=spec, ticket=ticket)

            if isinstance(handler_result, dict):
                status = handler_result.get("status", status)
                detail = handler_result.get("detail", detail)

            ended_at = self._now_fn().isoformat()
            return StepExecution(
                step=step_exec.step,
                action=step_exec.action,
                status=status,
                detail=detail,
                started_at=started_at,
                ended_at=ended_at,
                requires_approval=requires_approval,
                evidence=self._last_evidence,
            )

        except Exception as e:
            ended_at = self._now_fn().isoformat()
            error_suffix = ""
            if self._last_evidence:
                error_type = self._last_evidence.get("error_type")
                http_status = self._last_evidence.get("http_status")
                request_id = self._last_evidence.get("request_id")
                retryable = self._last_evidence.get("retryable")
                parts = []
                if error_type:
                    parts.append(f"error_type={error_type}")
                if http_status is not None:
                    parts.append(f"http_status={http_status}")
                if request_id:
                    parts.append(f"request_id={request_id}")
                if retryable is not None:
                    parts.append(f"retryable={retryable}")
                if parts:
                    error_suffix = " (" + ", ".join(parts) + ")"
            return StepExecution(
                step=step_exec.step,
                action=step_exec.action,
                status="failed",
                detail=f"Step failed with error: {str(e)}{error_suffix}",
                started_at=started_at,
                ended_at=ended_at,
                requires_approval=requires_approval,
                evidence=self._last_evidence,
            )

    def _normalize_email(self, email: str) -> str:
        return (email or "").strip().lower()

    def _resolve_target_remove_sku_ids(self, ticket: Ticket) -> list[str]:
        from_ticket = [sku.strip() for sku in ticket.remove_sku_ids if sku.strip()]
        raw = from_ticket
        if not raw:
            env_value = os.getenv("MSP_DEFAULT_REMOVE_SKU_IDS", "")
            raw = [sku.strip() for sku in env_value.split(",") if sku.strip()]

        normalized: list[str] = []
        for sku in raw:
            try:
                normalized.append(str(uuid.UUID(sku)))
            except ValueError as exc:
                raise Exception(f"Invalid SKU GUID in remove list: {sku}") from exc
        return normalized

    def _resolve_target_add_sku_ids(self, ticket: Ticket) -> list[str]:  # pragma: no cover
        from_ticket = [sku.strip() for sku in ticket.add_sku_ids if sku.strip()]
        raw = from_ticket
        if not raw:
            env_value = os.getenv("MSP_DEFAULT_ADD_SKU_IDS", "")
            raw = [sku.strip() for sku in env_value.split(",") if sku.strip()]
        normalized: list[str] = []
        for sku in raw:
            try:
                normalized.append(str(uuid.UUID(sku)))
            except ValueError as exc:
                raise Exception(f"Invalid SKU GUID in add list: {sku}") from exc
        return normalized

    def _resolve_target_add_group_ids(self, ticket: Ticket) -> list[str]:  # pragma: no cover
        from_ticket = [group_id.strip() for group_id in ticket.add_group_ids if group_id.strip()]
        raw = from_ticket
        if not raw:
            env_value = os.getenv("MSP_DEFAULT_ADD_GROUP_IDS", "")
            raw = [group_id.strip() for group_id in env_value.split(",") if group_id.strip()]
        normalized: list[str] = []
        for group_id in raw:
            try:
                normalized.append(str(uuid.UUID(group_id)))
            except ValueError as exc:
                raise Exception(f"Invalid group GUID in add list: {group_id}") from exc
        return normalized

    def _resolve_usage_location(self, ticket: Ticket) -> str:  # pragma: no cover
        env_default = os.getenv("MSP_DEFAULT_USAGE_LOCATION", "US") or "US"
        value = (ticket.usage_location or env_default).strip().upper()
        if len(value) != 2 or not value.isalpha():
            raise Exception(f"Invalid usage_location: {value}")
        return value

    def _parse_guid_list_env(self, env_name: str) -> list[str]:
        raw = os.getenv(env_name, "")
        values = [value.strip() for value in raw.split(",") if value.strip()]
        normalized: list[str] = []
        for value in values:
            try:
                normalized.append(str(uuid.UUID(value)))
            except ValueError as exc:
                raise Exception(f"Invalid GUID '{value}' in {env_name}") from exc
        return normalized

    def _group_remove_max(self) -> int:
        raw = (os.getenv("MSP_GROUP_REMOVE_MAX", "10") or "10").strip()
        try:
            value = int(raw)
        except ValueError as exc:
            raise Exception(f"Invalid MSP_GROUP_REMOVE_MAX: {raw}") from exc
        if value < 0:
            raise Exception(f"Invalid MSP_GROUP_REMOVE_MAX: {raw}")
        return value

    def _use_real_exchange(self) -> bool:
        flag = os.getenv("MSP_EXCHANGE_REAL", "").strip().lower()
        if flag in {"1", "true", "yes", "on"}:
            return True
        return self.graph_ops.__class__.__name__ == "RealGraphOperations"

    def _mailbox_identity(self, ticket: Ticket) -> str:
        return (
            (ticket.mailbox_identity or "").strip()
            or (self.resolved_user_principal_name or "").strip()
            or ticket.user_email
        )

    def _run_pwsh(self, script: str) -> tuple[bool, dict[str, Any]]:
        timeout_s = int(os.getenv("MSP_EXCHANGE_TIMEOUT_SECONDS", "120"))
        started = self._now_fn()
        try:
            proc = subprocess.run(
                ["pwsh", "-NoProfile", "-NonInteractive", "-Command", script],
                capture_output=True,
                text=True,
                check=False,
                timeout=timeout_s,
            )
        except FileNotFoundError:
            ended = self._now_fn()
            return False, {
                "error_type": "RUNTIME_ERROR",
                "retryable": False,
                "command": "pwsh",
                "detail": "pwsh is not installed or not in PATH",
                "duration_seconds": (ended - started).total_seconds(),
            }
        except subprocess.TimeoutExpired as exc:
            ended = self._now_fn()
            return False, {
                "error_type": "TRANSIENT",
                "retryable": True,
                "command": "pwsh",
                "detail": f"PowerShell timed out after {timeout_s}s",
                "duration_seconds": (ended - started).total_seconds(),
                "stdout": (exc.stdout or "")[:500],
                "stderr": (exc.stderr or "")[:500],
            }

        ended = self._now_fn()
        return proc.returncode == 0, {
            "return_code": proc.returncode,
            "command": "pwsh -NoProfile -NonInteractive -Command <redacted-script>",
            "duration_seconds": (ended - started).total_seconds(),
            "stdout": (proc.stdout or "")[:500],
            "stderr": (proc.stderr or "")[:500],
        }

    def _execute_action_spec(self, spec: ActionSpec, ticket: Ticket) -> dict[str, str] | None:
        handler_result: dict[str, str] | None = None
        for phase_name in (spec.precheck, spec.execute, spec.verify, spec.compensation):
            if phase_name is None:
                continue
            hook = getattr(self, phase_name, None)
            if hook is None or not callable(hook):
                raise ValueError(f"Unknown action hook: {phase_name} for action {spec.action_id}")
            phase_result = hook(ticket)
            if isinstance(phase_result, dict):
                handler_result = phase_result
                status = phase_result.get("status")
                if status in {"blocked", "failed", "skipped"}:
                    return phase_result
        return handler_result

    def _action_find_user_execute(self, ticket: Ticket) -> dict[str, str] | None:
        ticket_email = ticket.user_email

        tenant_id, tenant_ev = self.graph_ops.get_organization_tenant_id()
        self.resolved_tenant_id = tenant_id if isinstance(tenant_id, str) else None
        self._last_evidence = {"tenant_guard": tenant_ev or {}}
        if not self.resolved_tenant_id or self.resolved_tenant_id != ticket.tenant_id:
            self._last_evidence["error_type"] = "VALIDATION_ERROR"
            self._last_evidence["retryable"] = False
            raise Exception(
                "Tenant guard failed: "
                f"ticket.tenant_id={ticket.tenant_id} does not match "
                f"resolved tenant {self.resolved_tenant_id}"
            )

        email = ticket_email
        user_id, ev = self.graph_ops.find_user(email)
        if self._last_evidence is None:
            self._last_evidence = {}
        self._last_evidence["find_user"] = ev or {}
        self.user_id = user_id if isinstance(user_id, str) else None
        if not self.user_id:
            raise Exception(f"User not found: {email}")
        return None

    def _action_find_user_verify(self, ticket: Ticket) -> dict[str, str] | None:
        ticket_email = ticket.user_email
        if not self.user_id:
            raise Exception("User ID not set. Run 'find_user' step first.")
        profile, profile_ev = self.graph_ops.get_user_profile(self.user_id)
        if self._last_evidence is None:
            self._last_evidence = {}
        self._last_evidence["user_guard"] = profile_ev or {}
        upn = ""
        if isinstance(profile, dict):
            upn = str(profile.get("userPrincipalName") or "")
        self.resolved_user_principal_name = upn or None
        if self._normalize_email(upn) != self._normalize_email(ticket_email):
            self._last_evidence["error_type"] = "VALIDATION_ERROR"
            self._last_evidence["retryable"] = False
            raise Exception(
                "User guard failed: "
                f"ticket email {ticket_email} does not match "
                f"resolved userPrincipalName {upn}"
            )
        return None

    def _action_disable_sign_in_precheck(self, ticket: Ticket) -> dict[str, str] | None:
        _ = ticket
        if not self.user_id:
            raise Exception("User ID not set. Run 'find_user' step first.")
        enabled, precheck_ev = self.graph_ops.get_user_account_enabled(self.user_id)
        self._last_evidence = {"precheck": precheck_ev or {}}
        if enabled is False:
            return {"status": "skipped", "detail": "Already disabled (accountEnabled=false)"}
        return None

    def _action_disable_sign_in_execute(self, ticket: Ticket) -> dict[str, str] | None:
        _ = ticket
        if not self.user_id:
            raise Exception("User ID not set. Run 'find_user' step first.")
        ok, ev = self.graph_ops.disable_sign_in(self.user_id)
        if self._last_evidence is None:
            self._last_evidence = {}
        self._last_evidence["execute"] = ev or {}
        if not ok:
            raise Exception(f"Failed to disable sign-in for user {self.user_id}")
        return None

    def _action_disable_sign_in_verify(self, ticket: Ticket) -> dict[str, str] | None:
        _ = ticket
        if not self.user_id:
            raise Exception("User ID not set. Run 'find_user' step first.")
        enabled, verify_ev = self.graph_ops.get_user_account_enabled(self.user_id)
        if self._last_evidence is None:
            self._last_evidence = {}
        self._last_evidence["verify"] = verify_ev or {}
        if enabled is not False:
            raise Exception("Verification failed: accountEnabled did not become false")
        return None

    def _action_ensure_sign_in_enabled_precheck(self, ticket: Ticket) -> dict[str, str] | None:  # pragma: no cover
        _ = ticket
        if not self.user_id:
            raise Exception("User ID not set. Run 'find_user' step first.")
        enabled, precheck_ev = self.graph_ops.get_user_account_enabled(self.user_id)
        self._last_evidence = {"precheck": precheck_ev or {}}
        if enabled is True:
            return {"status": "skipped", "detail": "Sign-in already enabled"}
        return None

    def _action_ensure_sign_in_enabled_execute(self, ticket: Ticket) -> dict[str, str] | None:  # pragma: no cover
        _ = ticket
        if not self.user_id:
            raise Exception("User ID not set. Run 'find_user' step first.")
        if not hasattr(self.graph_ops, "enable_sign_in"):
            raise Exception("Graph operation enable_sign_in is not implemented")
        ok, ev = self.graph_ops.enable_sign_in(self.user_id)
        if self._last_evidence is None:
            self._last_evidence = {}
        self._last_evidence["execute"] = ev or {}
        if not ok:
            raise Exception(f"Failed to enable sign-in for user {self.user_id}")
        return None

    def _action_ensure_sign_in_enabled_verify(self, ticket: Ticket) -> dict[str, str] | None:  # pragma: no cover
        _ = ticket
        if not self.user_id:
            raise Exception("User ID not set. Run 'find_user' step first.")
        enabled, verify_ev = self.graph_ops.get_user_account_enabled(self.user_id)
        if self._last_evidence is None:
            self._last_evidence = {}
        self._last_evidence["verify"] = verify_ev or {}
        if enabled is not True:
            raise Exception("Verification failed: accountEnabled did not become true")
        return None

    def _action_set_usage_location_precheck(self, ticket: Ticket) -> dict[str, str] | None:  # pragma: no cover
        if not self.user_id:
            raise Exception("User ID not set. Run 'find_user' step first.")
        target = self._resolve_usage_location(ticket)
        self._target_usage_location = target
        if not hasattr(self.graph_ops, "get_user_usage_location"):
            self._last_evidence = {"legacy_mode": True, "target_usage_location": target}
            return None
        current, ev = self.graph_ops.get_user_usage_location(self.user_id)
        self._last_evidence = {
            "precheck": ev or {},
            "current_usage_location": current,
            "target_usage_location": target,
        }
        if isinstance(current, str) and current.upper() == target:
            return {"status": "skipped", "detail": f"Usage location already {target}"}
        return None

    def _action_set_usage_location_execute(self, ticket: Ticket) -> dict[str, str] | None:  # pragma: no cover
        _ = ticket
        if not self.user_id:
            raise Exception("User ID not set. Run 'find_user' step first.")
        target = self._target_usage_location or self._resolve_usage_location(ticket)
        if not hasattr(self.graph_ops, "set_user_usage_location"):
            raise Exception("Graph operation set_user_usage_location is not implemented")
        ok, ev = self.graph_ops.set_user_usage_location(self.user_id, target)
        if self._last_evidence is None:
            self._last_evidence = {}
        self._last_evidence["execute"] = ev or {}
        if not ok:
            raise Exception(f"Failed to set usage location to {target} for user {self.user_id}")
        return None

    def _action_set_usage_location_verify(self, ticket: Ticket) -> dict[str, str] | None:  # pragma: no cover
        _ = ticket
        if not self.user_id:
            raise Exception("User ID not set. Run 'find_user' step first.")
        target = self._target_usage_location or self._resolve_usage_location(ticket)
        if not hasattr(self.graph_ops, "get_user_usage_location"):
            return None
        current, ev = self.graph_ops.get_user_usage_location(self.user_id)
        if self._last_evidence is None:
            self._last_evidence = {}
        self._last_evidence["verify"] = ev or {}
        self._last_evidence["verify_usage_location"] = current
        if str(current or "").upper() != target:
            raise Exception(f"Verification failed: usageLocation is '{current}', expected '{target}'")
        return None

    def _action_assign_licenses_precheck(self, ticket: Ticket) -> dict[str, str] | None:  # pragma: no cover
        if not self.user_id:
            raise Exception("User ID not set. Run 'find_user' step first.")
        targets = self._resolve_target_add_sku_ids(ticket)
        if not targets:
            raise Exception(
                "assign_licenses requires explicit add_sku_ids (ticket.add_sku_ids or MSP_DEFAULT_ADD_SKU_IDS)"
            )
        if not hasattr(self.graph_ops, "get_user_license_details"):
            self._target_add_sku_ids = targets
            self._last_evidence = {"legacy_mode": True, "target_add_sku_ids": targets}
            return None
        assigned, ev = self.graph_ops.get_user_license_details(self.user_id)
        assigned_ids = {str(item.get("skuId") or "").strip() for item in assigned if str(item.get("skuId") or "").strip()}
        to_add = [sku_id for sku_id in targets if sku_id not in assigned_ids]
        self._target_add_sku_ids = to_add
        self._last_evidence = {
            "precheck": ev or {},
            "assigned_sku_ids": sorted(list(assigned_ids)),
            "target_add_sku_ids": targets,
        }
        if not to_add:
            return {"status": "skipped", "detail": "All target SKUs are already assigned"}
        return None

    def _action_assign_licenses_execute(self, ticket: Ticket) -> dict[str, str] | None:  # pragma: no cover
        _ = ticket
        if not self.user_id:
            raise Exception("User ID not set. Run 'find_user' step first.")
        if not self._target_add_sku_ids:
            raise Exception("assign_licenses has no resolved target SKUs to add")
        if not hasattr(self.graph_ops, "assign_licenses"):
            raise Exception("Graph operation assign_licenses is not implemented")
        ok, ev = self.graph_ops.assign_licenses(
            user_id=self.user_id,
            add_license_ids=self._target_add_sku_ids,
            remove_license_ids=[],
        )
        if self._last_evidence is None:
            self._last_evidence = {}
        self._last_evidence["execute"] = ev or {}
        self._last_evidence["added_sku_ids"] = list(self._target_add_sku_ids)
        self._last_evidence["compensation"] = {"addLicenses": [], "removeLicenses": list(self._target_add_sku_ids)}
        if not ok:
            raise Exception(f"Failed to assign licenses for user {self.user_id}")
        return None

    def _action_assign_licenses_verify(self, ticket: Ticket) -> dict[str, str] | None:  # pragma: no cover
        _ = ticket
        if not self.user_id:
            raise Exception("User ID not set. Run 'find_user' step first.")
        if not hasattr(self.graph_ops, "get_user_license_details"):
            return None
        assigned, ev = self.graph_ops.get_user_license_details(self.user_id)
        assigned_ids = {str(item.get("skuId") or "").strip() for item in assigned if str(item.get("skuId") or "").strip()}
        missing = [sku_id for sku_id in self._target_add_sku_ids if sku_id not in assigned_ids]
        if self._last_evidence is None:
            self._last_evidence = {}
        self._last_evidence["verify"] = ev or {}
        self._last_evidence["verify_missing_target_skus"] = missing
        if missing:
            raise Exception(f"Verification failed: target SKUs not assigned ({len(missing)})")
        return None

    def _action_assign_licenses_compensation(self, ticket: Ticket) -> dict[str, str] | None:  # pragma: no cover
        _ = ticket
        return None

    def _action_add_to_groups_precheck(self, ticket: Ticket) -> dict[str, str] | None:  # pragma: no cover
        if not self.user_id:
            raise Exception("User ID not set. Run 'find_user' step first.")
        targets = self._resolve_target_add_group_ids(ticket)
        if not targets:
            return {"status": "skipped", "detail": "No target groups provided"}
        if not hasattr(self.graph_ops, "list_user_group_ids"):
            self._target_add_group_ids = targets
            self._last_evidence = {"legacy_mode": True, "target_add_group_ids": targets}
            return None
        current, ev = self.graph_ops.list_user_group_ids(self.user_id)
        current_set = set(current)
        to_add = [group_id for group_id in targets if group_id not in current_set]
        self._target_add_group_ids = to_add
        self._last_evidence = {
            "precheck": ev or {},
            "current_group_ids": sorted(list(current_set)),
            "target_group_ids": targets,
        }
        if not to_add:
            return {"status": "skipped", "detail": "User is already in all target groups"}
        return None

    def _action_add_to_groups_execute(self, ticket: Ticket) -> dict[str, str] | None:  # pragma: no cover
        _ = ticket
        if not self.user_id:
            raise Exception("User ID not set. Run 'find_user' step first.")
        if not self._target_add_group_ids:
            raise Exception("add_to_groups has no resolved target groups to add")
        if not hasattr(self.graph_ops, "add_user_to_group"):
            raise Exception("Graph operation add_user_to_group is not implemented")
        if self._last_evidence is None:
            self._last_evidence = {}
        executed: list[dict[str, Any]] = []
        for group_id in self._target_add_group_ids:
            ok, ev = self.graph_ops.add_user_to_group(self.user_id, group_id)
            executed.append({"group_id": group_id, "evidence": ev or {}})
            if not ok:
                self._last_evidence["execute"] = executed
                raise Exception(f"Failed to add user {self.user_id} to group {group_id}")
        self._last_evidence["execute"] = executed
        self._last_evidence["added_group_ids"] = list(self._target_add_group_ids)
        return None

    def _action_add_to_groups_verify(self, ticket: Ticket) -> dict[str, str] | None:  # pragma: no cover
        _ = ticket
        if not self.user_id:
            raise Exception("User ID not set. Run 'find_user' step first.")
        if not hasattr(self.graph_ops, "list_user_group_ids"):
            return None
        current, ev = self.graph_ops.list_user_group_ids(self.user_id)
        current_set = set(current)
        missing = [group_id for group_id in self._target_add_group_ids if group_id not in current_set]
        if self._last_evidence is None:
            self._last_evidence = {}
        self._last_evidence["verify"] = ev or {}
        self._last_evidence["verify_missing_target_groups"] = missing
        if missing:
            raise Exception(f"Verification failed: target groups not assigned ({len(missing)})")
        return None

    def _action_group_diff_apply_precheck(self, ticket: Ticket) -> dict[str, str] | None:  # pragma: no cover
        if not self.user_id:
            raise Exception("User ID not set. Run 'find_user' step first.")
        if not hasattr(self.graph_ops, "list_user_group_ids"):
            raise Exception("Graph operation list_user_group_ids is not implemented")

        desired = sorted(set([group_id.strip() for group_id in ticket.desired_group_ids if group_id.strip()]))
        if not desired:
            self._last_evidence = {"error_type": "VALIDATION_ERROR", "retryable": False}
            raise Exception("group_diff_apply requires non-empty desired_group_ids")

        for group_id in desired:
            try:
                uuid.UUID(group_id)
            except ValueError as exc:
                self._last_evidence = {"error_type": "VALIDATION_ERROR", "retryable": False}
                raise Exception(f"Invalid group GUID in desired_group_ids: {group_id}") from exc

        scope = (ticket.group_diff_scope or "managed_only").strip()
        if scope not in {"all", "managed_only"}:
            self._last_evidence = {"error_type": "VALIDATION_ERROR", "retryable": False}
            raise Exception(f"Invalid group_diff_scope: {scope}")
        self._group_diff_scope = scope

        current_groups, ev = self.graph_ops.list_user_group_ids(self.user_id)
        current = sorted(set(current_groups))
        managed_group_ids = self._parse_guid_list_env("MSP_MANAGED_GROUP_IDS")
        managed_set = set(managed_group_ids)

        if scope == "managed_only":
            if not managed_group_ids:
                self._last_evidence = {"error_type": "VALIDATION_ERROR", "retryable": False}
                raise Exception("MSP_MANAGED_GROUP_IDS is required when group_diff_scope=managed_only")
            if any(group_id not in managed_set for group_id in desired):
                self._last_evidence = {"error_type": "VALIDATION_ERROR", "retryable": False}
                raise Exception("desired_group_ids must be a subset of MSP_MANAGED_GROUP_IDS in managed_only scope")
            current_considered = sorted([group_id for group_id in current if group_id in managed_set])
        else:
            current_considered = current

        current_set = set(current_considered)
        desired_set = set(desired)
        self._group_diff_to_add = sorted(list(desired_set - current_set))
        self._group_diff_to_remove = sorted(list(current_set - desired_set))

        protected_set = set(self._parse_guid_list_env("MSP_PROTECTED_GROUP_IDS"))
        protected_conflicts = sorted([group_id for group_id in self._group_diff_to_remove if group_id in protected_set])
        if protected_conflicts:
            self._last_evidence = {
                "error_type": "VALIDATION_ERROR",
                "retryable": False,
                "protected_conflicts": protected_conflicts,
            }
            raise Exception("Refusing to remove protected groups")

        remove_max = self._group_remove_max()
        if len(self._group_diff_to_remove) > remove_max:
            self._last_evidence = {
                "error_type": "VALIDATION_ERROR",
                "retryable": False,
                "remove_count": len(self._group_diff_to_remove),
                "remove_max": remove_max,
            }
            raise Exception(
                f"group_diff removal count {len(self._group_diff_to_remove)} exceeds MSP_GROUP_REMOVE_MAX={remove_max}"
            )

        self._last_evidence = {
            "precheck": ev or {},
            "scope": scope,
            "desired_group_ids": desired,
            "current_group_ids_count": len(current),
            "current_considered_group_ids": current_considered,
            "to_add": self._group_diff_to_add,
            "to_remove": self._group_diff_to_remove,
            "managed_group_ids": managed_group_ids if scope == "managed_only" else [],
            "to_add_count": len(self._group_diff_to_add),
            "to_remove_count": len(self._group_diff_to_remove),
        }

        if not self._group_diff_to_add and not self._group_diff_to_remove:
            return {"status": "skipped", "detail": "Group membership already matches desired state"}
        return None

    def _action_group_diff_apply_execute(self, ticket: Ticket) -> dict[str, str] | None:  # pragma: no cover
        _ = ticket
        if not self.user_id:
            raise Exception("User ID not set. Run 'find_user' step first.")
        if not hasattr(self.graph_ops, "add_user_to_group"):
            raise Exception("Graph operation add_user_to_group is not implemented")
        if not hasattr(self.graph_ops, "remove_user_from_group"):
            raise Exception("Graph operation remove_user_from_group is not implemented")

        added: list[dict[str, Any]] = []
        for group_id in self._group_diff_to_add:
            ok, ev = self.graph_ops.add_user_to_group(self.user_id, group_id)
            added.append({"group_id": group_id, "evidence": ev or {}})
            if not ok:
                if self._last_evidence is None:
                    self._last_evidence = {}
                self._last_evidence["add_results"] = added
                raise Exception(f"Failed to add user {self.user_id} to group {group_id}")
        if self._last_evidence is None:
            self._last_evidence = {}
        self._last_evidence["add_results"] = added

        if self._group_diff_to_remove and "group_diff_apply" not in self._approved_actions_runtime:
            self._last_evidence["removal_requires_approval"] = True
            return {
                "status": "blocked",
                "detail": f"Removals require approval (use --approve group_diff_apply): {','.join(self._group_diff_to_remove)}",
            }

        removed: list[dict[str, Any]] = []
        for group_id in self._group_diff_to_remove:
            ok, ev = self.graph_ops.remove_user_from_group(self.user_id, group_id)
            removed.append({"group_id": group_id, "evidence": ev or {}})
            if not ok:
                self._last_evidence["remove_results"] = removed
                raise Exception(f"Failed to remove user {self.user_id} from group {group_id}")
        self._last_evidence["remove_results"] = removed
        self._last_evidence["removed_group_ids"] = list(self._group_diff_to_remove)
        self._last_evidence["added_group_ids"] = list(self._group_diff_to_add)
        return None

    def _action_group_diff_apply_verify(self, ticket: Ticket) -> dict[str, str] | None:  # pragma: no cover
        if not self.user_id:
            raise Exception("User ID not set. Run 'find_user' step first.")
        if not hasattr(self.graph_ops, "list_user_group_ids"):
            return None
        current_groups, ev = self.graph_ops.list_user_group_ids(self.user_id)
        final_set = set(current_groups)
        desired = set([group_id.strip() for group_id in ticket.desired_group_ids if group_id.strip()])
        if self._group_diff_scope == "managed_only":
            managed = set(self._parse_guid_list_env("MSP_MANAGED_GROUP_IDS"))
            ok = set([group_id for group_id in final_set if group_id in managed]) == desired
        else:
            ok = final_set == desired
        if self._last_evidence is None:
            self._last_evidence = {}
        self._last_evidence["verify"] = ev or {}
        self._last_evidence["verify_final_group_count"] = len(final_set)
        if not ok:
            raise Exception("Verification failed: final group membership does not match desired state")
        return None

    def _action_group_diff_apply_compensation(self, ticket: Ticket) -> dict[str, str] | None:  # pragma: no cover
        _ = ticket
        if self._last_evidence is None:
            self._last_evidence = {}
        self._last_evidence["compensation"] = {
            "readd_removed_group_ids": list(self._group_diff_to_remove),
            "remove_added_group_ids": list(self._group_diff_to_add),
        }
        return None

    def _action_require_password_reset_precheck(self, ticket: Ticket) -> dict[str, str] | None:  # pragma: no cover
        if not ticket.require_password_reset:
            return {"status": "skipped", "detail": "Ticket does not request password reset"}
        if not self.user_id:
            raise Exception("User ID not set. Run 'find_user' step first.")
        if not hasattr(self.graph_ops, "get_user_force_password_reset"):
            self._last_evidence = {"legacy_mode": True}
            return None
        current, ev = self.graph_ops.get_user_force_password_reset(self.user_id)
        self._last_evidence = {"precheck": ev or {}, "current_force_password_reset": current}
        if current is True:
            return {"status": "skipped", "detail": "Password reset already required"}
        return None

    def _action_require_password_reset_execute(self, ticket: Ticket) -> dict[str, str] | None:  # pragma: no cover
        _ = ticket
        if not self.user_id:
            raise Exception("User ID not set. Run 'find_user' step first.")
        if not hasattr(self.graph_ops, "set_user_force_password_reset"):
            raise Exception("Graph operation set_user_force_password_reset is not implemented")
        ok, ev = self.graph_ops.set_user_force_password_reset(self.user_id, True)
        if self._last_evidence is None:
            self._last_evidence = {}
        self._last_evidence["execute"] = ev or {}
        if not ok:
            raise Exception(f"Failed to require password reset for user {self.user_id}")
        return None

    def _action_require_password_reset_verify(self, ticket: Ticket) -> dict[str, str] | None:  # pragma: no cover
        _ = ticket
        if not self.user_id:
            raise Exception("User ID not set. Run 'find_user' step first.")
        if not hasattr(self.graph_ops, "get_user_force_password_reset"):
            return None
        current, ev = self.graph_ops.get_user_force_password_reset(self.user_id)
        if self._last_evidence is None:
            self._last_evidence = {}
        self._last_evidence["verify"] = ev or {}
        self._last_evidence["verify_force_password_reset"] = current
        if current is False:
            raise Exception("Verification failed: forceChangePasswordNextSignIn is false")
        return None

    def _action_revoke_sessions_execute(self, ticket: Ticket) -> dict[str, str] | None:
        _ = ticket
        if not self.user_id:
            raise Exception("User ID not set. Run 'find_user' step first.")
        ok, ev = self.graph_ops.revoke_sessions(self.user_id)
        self._last_evidence = ev
        if not ok:
            raise Exception(f"Failed to revoke sessions for user {self.user_id}")
        return None

    def _action_remove_admin_roles_precheck(self, ticket: Ticket) -> dict[str, str] | None:
        _ = ticket
        if not self.user_id:
            raise Exception("User ID not set. Run 'find_user' step first.")
        if not hasattr(self.graph_ops, "list_user_directory_roles"):
            self._target_remove_role_ids = []
            self._last_evidence = {"legacy_mode": True}
            return None
        roles, ev = self.graph_ops.list_user_directory_roles(self.user_id)
        role_ids: list[str] = []
        role_names: list[str] = []
        for role in roles:
            role_id = str(role.get("id") or "")
            if not role_id:
                continue
            role_ids.append(role_id)
            role_names.append(str(role.get("displayName") or role_id))
        self._target_remove_role_ids = role_ids
        self._last_evidence = {
            "precheck": ev or {},
            "role_ids": role_ids,
            "role_names": role_names,
        }
        if not role_ids:
            return {"status": "skipped", "detail": "No directory admin roles assigned"}
        return None

    def _action_remove_admin_roles_execute(self, ticket: Ticket) -> dict[str, str] | None:
        _ = ticket
        if not self.user_id:
            raise Exception("User ID not set. Run 'find_user' step first.")
        # Backward-compatible path for simple stubs that only expose boolean remove_admin_roles.
        if not hasattr(self.graph_ops, "remove_directory_role_member") or not self._target_remove_role_ids:
            if not self.graph_ops.remove_admin_roles(self.user_id):
                raise Exception(f"Failed to remove admin roles for user {self.user_id}")
            if self._last_evidence is None:
                self._last_evidence = {}
            self._last_evidence["legacy_execute"] = {"mode": "remove_admin_roles(user_id)"}
            return None

        removed: list[str] = []
        for role_id in self._target_remove_role_ids:
            ok, ev = self.graph_ops.remove_directory_role_member(role_id=role_id, user_id=self.user_id)
            if self._last_evidence is None:
                self._last_evidence = {}
            self._last_evidence.setdefault("execute", [])
            if isinstance(self._last_evidence["execute"], list):
                self._last_evidence["execute"].append({"role_id": role_id, "evidence": ev or {}})
            if not ok:
                raise Exception(f"Failed to remove directory role {role_id} from user {self.user_id}")
            removed.append(role_id)
        if self._last_evidence is None:
            self._last_evidence = {}
        self._last_evidence["removed_role_ids"] = removed
        return None

    def _action_remove_admin_roles_verify(self, ticket: Ticket) -> dict[str, str] | None:
        _ = ticket
        if not self.user_id:
            raise Exception("User ID not set. Run 'find_user' step first.")
        if not hasattr(self.graph_ops, "list_user_directory_roles"):
            return None
        roles, ev = self.graph_ops.list_user_directory_roles(self.user_id)
        remaining = [str(role.get("id") or "") for role in roles if str(role.get("id") or "")]
        if self._last_evidence is None:
            self._last_evidence = {}
        self._last_evidence["verify"] = ev or {}
        self._last_evidence["remaining_role_ids"] = remaining
        if remaining:
            raise Exception(f"Verification failed: directory roles still assigned ({len(remaining)})")
        return None

    def _action_remove_licenses_precheck(self, ticket: Ticket) -> dict[str, str] | None:
        if not self.user_id:
            raise Exception("User ID not set. Run 'find_user' step first.")
        if not hasattr(self.graph_ops, "get_user_license_details"):
            self._target_remove_sku_ids = self._resolve_target_remove_sku_ids(ticket)
            self._last_evidence = {"legacy_mode": True, "target_remove_sku_ids": self._target_remove_sku_ids}
            if not self._target_remove_sku_ids:
                raise Exception(
                    "remove_licenses requires explicit remove_sku_ids (ticket.remove_sku_ids or MSP_DEFAULT_REMOVE_SKU_IDS)"
                )
            return None

        target_sku_ids = self._resolve_target_remove_sku_ids(ticket)
        if not target_sku_ids:
            raise Exception(
                "remove_licenses requires explicit remove_sku_ids (ticket.remove_sku_ids or MSP_DEFAULT_REMOVE_SKU_IDS)"
            )

        assigned, ev = self.graph_ops.get_user_license_details(self.user_id)
        assigned_by_id: dict[str, str] = {}
        for item in assigned:
            sku_id = str(item.get("skuId") or "").strip()
            if not sku_id:
                continue
            assigned_by_id[sku_id] = str(item.get("skuPartNumber") or sku_id)

        removable = [sku_id for sku_id in target_sku_ids if sku_id in assigned_by_id]
        missing = [sku_id for sku_id in target_sku_ids if sku_id not in assigned_by_id]
        self._target_remove_sku_ids = removable
        self._last_evidence = {
            "precheck": ev or {},
            "assigned_sku_ids": sorted(list(assigned_by_id.keys())),
            "assigned_sku_part_numbers": [assigned_by_id[sku_id] for sku_id in sorted(list(assigned_by_id.keys()))],
            "target_remove_sku_ids": target_sku_ids,
            "missing_target_sku_ids": missing,
        }
        if not removable:
            return {"status": "skipped", "detail": "None of the target SKUs are currently assigned"}
        return None

    def _action_remove_licenses_execute(self, ticket: Ticket) -> dict[str, str] | None:
        _ = ticket
        if not self.user_id:
            raise Exception("User ID not set. Run 'find_user' step first.")
        if not self._target_remove_sku_ids:
            raise Exception("remove_licenses has no resolved target SKUs to remove")

        if not hasattr(self.graph_ops, "assign_licenses"):
            if self._last_evidence is None:
                self._last_evidence = {}
            self._last_evidence["legacy_execute"] = {
                "removed_sku_ids": self._target_remove_sku_ids,
            }
            return None

        compensation = {"addLicenses": self._target_remove_sku_ids, "removeLicenses": []}
        ok, ev = self.graph_ops.assign_licenses(
            user_id=self.user_id,
            add_license_ids=[],
            remove_license_ids=self._target_remove_sku_ids,
        )
        if self._last_evidence is None:
            self._last_evidence = {}
        self._last_evidence["execute"] = ev or {}
        self._last_evidence["compensation"] = compensation
        if not ok:
            raise Exception(f"Failed to remove licenses for user {self.user_id}")
        self._last_evidence["removed_sku_ids"] = list(self._target_remove_sku_ids)
        return None

    def _action_remove_licenses_verify(self, ticket: Ticket) -> dict[str, str] | None:
        _ = ticket
        if not self.user_id:
            raise Exception("User ID not set. Run 'find_user' step first.")
        if not hasattr(self.graph_ops, "get_user_license_details"):
            return None
        assigned, ev = self.graph_ops.get_user_license_details(self.user_id)
        remaining_ids = {str(item.get("skuId") or "").strip() for item in assigned if str(item.get("skuId") or "").strip()}
        still_present = [sku_id for sku_id in self._target_remove_sku_ids if sku_id in remaining_ids]
        if self._last_evidence is None:
            self._last_evidence = {}
        self._last_evidence["verify"] = ev or {}
        self._last_evidence["verify_remaining_target_skus"] = still_present
        if still_present:
            raise Exception(f"Verification failed: target SKUs still assigned ({len(still_present)})")
        return None

    def _action_remove_licenses_compensation(self, ticket: Ticket) -> dict[str, str] | None:
        _ = ticket
        # Compensation is logged in evidence; it is not auto-executed.
        return None

    def _action_convert_mailbox_precheck(self, ticket: Ticket) -> dict[str, str] | None:
        identity = self._mailbox_identity(ticket)
        if not self._use_real_exchange():
            self._last_evidence = {"legacy_mode": True, "mailbox_identity": identity}
            return None
        script = (
            "$m = Get-Mailbox -Identity "
            f"'{identity}' "
            "| Select-Object -ExpandProperty RecipientTypeDetails; "
            "$m | ConvertTo-Json -Compress"
        )
        ok, ev = self._run_pwsh(script)
        self._last_evidence = {"precheck": ev, "mailbox_identity": identity}
        if not ok:
            raise Exception(f"Mailbox precheck failed for {identity}")
        output = str(ev.get("stdout") or "").strip().strip('"')
        self._last_evidence["precheck_recipient_type"] = output
        if output.lower() == "sharedmailbox":
            return {"status": "skipped", "detail": "Mailbox is already SharedMailbox"}
        return None

    def _action_convert_mailbox_execute(self, ticket: Ticket) -> dict[str, str] | None:
        identity = self._mailbox_identity(ticket)
        if not self.user_id:
            raise Exception("User ID not set. Run 'find_user' step first.")
        if not self._use_real_exchange():
            if self._last_evidence is None:
                self._last_evidence = {}
            self._last_evidence["legacy_execute"] = {"mailbox_identity": identity}
            return None

        script = f"Set-Mailbox -Identity '{identity}' -Type Shared"
        ok, ev = self._run_pwsh(script)
        if self._last_evidence is None:
            self._last_evidence = {}
        self._last_evidence["execute"] = ev
        self._last_evidence["mailbox_identity"] = identity
        if not ok:
            raise Exception(f"Failed to convert mailbox for {identity}")
        return None

    def _action_convert_mailbox_verify(self, ticket: Ticket) -> dict[str, str] | None:
        identity = self._mailbox_identity(ticket)
        if not self._use_real_exchange():
            return None
        script = (
            "$m = Get-Mailbox -Identity "
            f"'{identity}' "
            "| Select-Object -ExpandProperty RecipientTypeDetails; "
            "$m | ConvertTo-Json -Compress"
        )
        ok, ev = self._run_pwsh(script)
        if self._last_evidence is None:
            self._last_evidence = {}
        self._last_evidence["verify"] = ev
        if not ok:
            raise Exception(f"Mailbox verify failed for {identity}")
        output = str(ev.get("stdout") or "").strip().strip('"')
        self._last_evidence["verify_recipient_type"] = output
        if output.lower() != "sharedmailbox":
            raise Exception(f"Verification failed: mailbox type is '{output}', expected SharedMailbox")
        return None

