from msp_copilot.domain.action import Action
from msp_copilot.domain.plan import Plan
from msp_copilot.domain.ticket import Ticket
from msp_copilot.engine.action_registry import get_workflow_specs


class Planner:
    def build_plan(self, ticket: Ticket) -> Plan:
        action_specs = get_workflow_specs(ticket.type)
        actions = [
            Action(spec.action_id, requires_approval=spec.requires_approval)
            for spec in action_specs
        ]
        return Plan(actions=actions)
