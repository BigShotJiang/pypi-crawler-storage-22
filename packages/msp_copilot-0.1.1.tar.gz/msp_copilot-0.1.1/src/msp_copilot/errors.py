from __future__ import annotations


class MspCopilotError(Exception):
    error_type = "RUNTIME_ERROR"

    def __init__(self, message: str):
        super().__init__(message)
        self.message = message


class ValidationFailure(MspCopilotError):
    error_type = "VALIDATION_ERROR"


class AuthFailure(MspCopilotError):
    error_type = "AUTH_ERROR"


class PermissionFailure(MspCopilotError):
    error_type = "PERMISSION_ERROR"


class TransientFailure(MspCopilotError):
    error_type = "TRANSIENT"
