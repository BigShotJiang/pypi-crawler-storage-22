import argparse
import json
import os
import uuid
from collections.abc import Callable
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Literal, cast

from dotenv import load_dotenv

from msp_copilot.config.settings import RuntimeSettings
from msp_copilot.connectors.microsoft_graph.auth import DeviceCodeAuth
from msp_copilot.connectors.microsoft_graph.real_operations import RealGraphOperations
from msp_copilot.domain.ticket import Ticket
from msp_copilot.engine.action_registry import (
    get_workflow_action_ids,
    get_workflow_specs,
)
from msp_copilot.engine.auditor import Auditor
from msp_copilot.engine.executor import Executor
from msp_copilot.engine.planner import Planner
from msp_copilot.errors import MspCopilotError, ValidationFailure

EXIT_SUCCESS = 0
EXIT_FAILED = 1
EXIT_VALIDATION = 2
EXIT_AUTH = 3
EXIT_PERMISSION = 4
EXIT_TRANSIENT = 5


@dataclass(frozen=True)
class DoctorCheck:
    name: str
    status: Literal["ok", "warn", "fail", "skip"]
    message: str
    details: dict[str, object]


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _normalize_email(value: str) -> str:
    return (value or "").strip().lower()


def _base_run_payload(
    run_id: str,
    started_at: datetime,
    operator: str,
    ticket: Ticket,
    dry_run: bool,
) -> dict:
    return {
        "run_schema_version": 1,
        "run_id": run_id,
        "started_at": started_at.isoformat(),
        "completed_at": None,
        "duration_seconds": None,
        "ticket": {
            "ticket_id": ticket.ticket_id,
            "type": ticket.type,
            "tenant_id": ticket.tenant_id,
            "user_email": ticket.user_email,
        },
        "dry_run": dry_run,
        "operator": operator,
        "run_version": "unknown",
        "git_commit": "unknown",
        "approved_actions": [],
        "resolved_tenant_id": None,
        "resolved_user_id": None,
        "resolved_user_principal_name": None,
        "steps": [],
        "success": None,
        "status": "running",
    }


def _classify_top_level_error(message: str) -> str:
    msg = (message or "").lower()
    if "validation_error" in msg:
        return "VALIDATION_ERROR"
    if "auth failed" in msg or "authority configuration" in msg or "device login" in msg or "token" in msg:
        return "AUTH_ERROR"
    return "RUNTIME_ERROR"


def _error_type_from_exception(error: Exception) -> str:
    if isinstance(error, MspCopilotError):
        return error.error_type
    return _classify_top_level_error(str(error))


def _error_type_to_exit_code(error_type: str | None) -> int:
    if error_type == "VALIDATION_ERROR":
        return EXIT_VALIDATION
    if error_type == "AUTH_ERROR":
        return EXIT_AUTH
    if error_type == "PERMISSION_ERROR":
        return EXIT_PERMISSION
    if error_type in {"RATE_LIMIT", "TRANSIENT"}:
        return EXIT_TRANSIENT
    return EXIT_FAILED


def _exit_code_from_run_payload(payload: dict) -> int:
    if payload.get("success") is True:
        return EXIT_SUCCESS

    top_error = payload.get("error", {})
    if isinstance(top_error, dict):
        code = _error_type_to_exit_code(top_error.get("error_type"))
        if code != EXIT_FAILED:
            return code

    for step in payload.get("steps", []):
        if not isinstance(step, dict) or step.get("status") != "failed":
            continue
        evidence = step.get("evidence", {})
        if isinstance(evidence, dict):
            code = _error_type_to_exit_code(evidence.get("error_type"))
            if code != EXIT_FAILED:
                return code
    return EXIT_FAILED


def _load_ticket(ticket_path: Path) -> Ticket:
    try:
        ticket_data = json.loads(ticket_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise ValidationFailure("Invalid JSON in ticket file") from exc
    try:
        return Ticket.from_dict(ticket_data)
    except ValueError as exc:
        raise ValidationFailure(str(exc)) from exc


def _resolved_ticket_from_args(args: argparse.Namespace) -> Ticket:
    ticket_path = Path(args.ticket)
    if not ticket_path.exists():
        raise ValidationFailure(f"Ticket file not found: {ticket_path}")
    ticket = _load_ticket(ticket_path)

    confirm_tenant_arg = getattr(args, "confirm_tenant", "")
    confirm_user_arg = getattr(args, "confirm_user", "")
    resolved_tenant_id = RuntimeSettings.resolve_tenant_guid(ticket.tenant_id)
    if confirm_tenant_arg:
        confirmed_tenant_id = RuntimeSettings.resolve_tenant_guid(confirm_tenant_arg)
        if confirmed_tenant_id != resolved_tenant_id:
            raise ValidationFailure(
                f"confirm tenant mismatch ({confirmed_tenant_id} != {resolved_tenant_id})"
            )

    if confirm_user_arg and _normalize_email(confirm_user_arg) != _normalize_email(ticket.user_email):
        raise ValidationFailure(
            f"confirm user mismatch ({confirm_user_arg} != {ticket.user_email})"
        )
    return Ticket(
        ticket_id=ticket.ticket_id,
        type=ticket.type,
        tenant_id=resolved_tenant_id,
        user_email=ticket.user_email,
        remove_sku_ids=ticket.remove_sku_ids,
        add_sku_ids=ticket.add_sku_ids,
        add_group_ids=ticket.add_group_ids,
        desired_group_ids=ticket.desired_group_ids,
        group_diff_scope=ticket.group_diff_scope,
        usage_location=ticket.usage_location,
        require_password_reset=ticket.require_password_reset,
        mailbox_identity=ticket.mailbox_identity,
    )


def _new_doctor_check(
    name: str,
    status: Literal["ok", "warn", "fail", "skip"],
    message: str,
    details: dict[str, object] | None = None,
) -> DoctorCheck:
    return DoctorCheck(
        name=name,
        status=status,
        message=message,
        details=details or {},
    )


def _doctor_exit_code(checks: list[DoctorCheck]) -> int:
    failing = [c for c in checks if c.status == "fail"]
    if not failing:
        return EXIT_SUCCESS
    for check in failing:
        error_type = check.details.get("error_type")
        if isinstance(error_type, str):
            code = _error_type_to_exit_code(error_type)
            if code != EXIT_FAILED:
                return code
    return EXIT_FAILED


def _print_doctor_text(doctor_id: str, checks: list[DoctorCheck], verbose: bool) -> None:
    print(f"=== DOCTOR ({doctor_id}) ===")
    for check in checks:
        print(f"[{doctor_id}] [{check.status.upper()}] {check.name}: {check.message}")
        if verbose and check.details:
            print(f"[{doctor_id}] details={json.dumps(check.details, sort_keys=True)}")


def cmd_doctor(args: argparse.Namespace) -> int:
    doctor_id = str(uuid.uuid4())[:8]
    checks: list[DoctorCheck] = []
    settings = RuntimeSettings.from_env()

    checks.append(
        _new_doctor_check(
            name="kill_switch",
            status="ok" if settings.execution_enabled else "warn",
            message=(
                "MSP_EXECUTION_ENABLED is true"
                if settings.execution_enabled
                else "MSP_EXECUTION_ENABLED is false (safe default)"
            ),
            details={"execution_enabled": settings.execution_enabled},
        )
    )

    client_id = os.getenv("MSP_GRAPH_CLIENT_ID", "").strip()
    graph_tenant = os.getenv("MSP_GRAPH_TENANT_ID", "").strip()
    graph_ready = bool(client_id and graph_tenant)
    checks.append(
        _new_doctor_check(
            name="graph_config",
            status="ok" if graph_ready else "warn",
            message=(
                "Graph credentials configured"
                if graph_ready
                else "Missing MSP_GRAPH_CLIENT_ID or MSP_GRAPH_TENANT_ID"
            ),
            details={"tenant_id_present": bool(graph_tenant), "client_id_present": bool(client_id)},
        )
    )

    token_cache_path = Path("data/token_cache.json")
    if token_cache_path.exists():
        checks.append(
            _new_doctor_check(
                name="token_cache",
                status="ok",
                message="Token cache file found",
                details={"path": str(token_cache_path), "size_bytes": token_cache_path.stat().st_size},
            )
        )
    else:
        checks.append(
            _new_doctor_check(
                name="token_cache",
                status="warn",
                message="Token cache file not found yet",
                details={"path": str(token_cache_path)},
            )
        )

    tenant_input = str(getattr(args, "tenant", "") or "").strip()
    if tenant_input:
        try:
            resolved_tenant = RuntimeSettings.resolve_tenant_guid(tenant_input)
            checks.append(
                _new_doctor_check(
                    name="tenant_alias_resolution",
                    status="ok",
                    message="Tenant identifier resolved",
                    details={"input": tenant_input, "resolved_tenant_id": resolved_tenant},
                )
            )
        except ValidationFailure as exc:
            checks.append(
                _new_doctor_check(
                    name="tenant_alias_resolution",
                    status="fail",
                    message=str(exc),
                    details={"input": tenant_input, "error_type": "VALIDATION_ERROR"},
                )
            )
    else:
        checks.append(
            _new_doctor_check(
                name="tenant_alias_resolution",
                status="skip",
                message="No --tenant provided",
            )
        )

    test_user = str(getattr(args, "test_user", "") or "").strip() or os.getenv("MSP_DOCTOR_TEST_USER", "").strip()

    if graph_ready:
        try:
            auth = DeviceCodeAuth(client_id=client_id, tenant_id=graph_tenant)
            token = auth.acquire_token()
            checks.append(
                _new_doctor_check(
                    name="graph_auth",
                    status="ok",
                    message="Successfully acquired Graph access token",
                )
            )
            graph_ops = RealGraphOperations(token)
        except Exception as exc:
            checks.append(
                _new_doctor_check(
                    name="graph_auth",
                    status="fail",
                    message=str(exc),
                    details={"error_type": "AUTH_ERROR"},
                )
            )
            graph_ops = None
    else:
        checks.append(
            _new_doctor_check(
                name="graph_auth",
                status="skip",
                message="Skipped auth check: Graph credentials not fully configured",
            )
        )
        graph_ops = None

    if graph_ops is not None:
        org_id, org_ev = graph_ops.get_organization_tenant_id()
        if org_id:
            checks.append(
                _new_doctor_check(
                    name="graph_org_lookup",
                    status="ok",
                    message="Organization lookup succeeded",
                    details={"tenant_id": org_id},
                )
            )
        else:
            checks.append(
                _new_doctor_check(
                    name="graph_org_lookup",
                    status="fail",
                    message="Organization lookup failed",
                    details=dict(org_ev),
                )
            )
    else:
        checks.append(
            _new_doctor_check(
                name="graph_org_lookup",
                status="skip",
                message="Skipped org lookup",
            )
        )

    if not test_user:
        checks.append(
            _new_doctor_check(
                name="graph_test_user_lookup",
                status="skip",
                message="No --test-user provided and MSP_DOCTOR_TEST_USER not set",
            )
        )
    elif graph_ops is None:
        checks.append(
            _new_doctor_check(
                name="graph_test_user_lookup",
                status="skip",
                message="Skipped test-user lookup because auth was unavailable",
                details={"test_user": test_user},
            )
        )
    else:
        user_id, user_ev = graph_ops.find_user(test_user)
        if user_id:
            checks.append(
                _new_doctor_check(
                    name="graph_test_user_lookup",
                    status="ok",
                    message="Test user resolved",
                    details={"test_user": test_user, "user_id": user_id},
                )
            )
        else:
            checks.append(
                _new_doctor_check(
                    name="graph_test_user_lookup",
                    status="fail",
                    message="Test user lookup failed",
                    details=dict(user_ev) | {"test_user": test_user},
                )
            )

    if bool(getattr(args, "json_output", False)):
        payload = {
            "doctor_id": doctor_id,
            "ok": all(check.status != "fail" for check in checks),
            "checks": [
                {
                    "name": check.name,
                    "status": check.status,
                    "message": check.message,
                    "details": check.details,
                }
                for check in checks
            ],
        }
        print(json.dumps(payload, indent=2, sort_keys=True))
    else:
        _print_doctor_text(doctor_id=doctor_id, checks=checks, verbose=bool(getattr(args, "verbose", False)))

    return _doctor_exit_code(checks)


def cmd_last_run(args: argparse.Namespace) -> int:
    runs_dir = Path("data/runs")
    run_files = sorted(runs_dir.glob("run_*.json"), key=lambda p: p.stat().st_mtime, reverse=True)
    if not run_files:
        print("[ERROR] No run logs found in data/runs")
        return EXIT_FAILED

    run_path = run_files[0]
    payload = json.loads(run_path.read_text(encoding="utf-8"))
    summary = payload.get("run_summary.txt", "")
    print("=== LAST RUN ===")
    print(f"Path: {run_path}")
    print(f"Status: {payload.get('status')}")
    print(f"Success: {payload.get('success')}")
    if summary:
        print("\n" + summary)
    return EXIT_SUCCESS


def cmd_explain(args: argparse.Namespace) -> int:
    workflow = args.workflow.strip()
    try:
        specs = get_workflow_specs(workflow)
    except ValueError as exc:
        print(f"[ERROR] {exc}")
        return EXIT_VALIDATION

    print(f"=== WORKFLOW: {workflow} ===")
    for index, spec in enumerate(specs, start=1):
        touches = ", ".join(spec.touches) if spec.touches else "-"
        print(
            f"{index}. {spec.action_id} | "
            f"approval={'yes' if spec.requires_approval else 'no'} | "
            f"safe_repeatable={'yes' if spec.safe_repeatable else 'no'} | "
            f"precheck={spec.precheck or '-'} | execute={spec.execute or '-'} | "
            f"verify={spec.verify or '-'} | compensation={spec.compensation or '-'} | "
            f"touches={touches}"
        )
    return EXIT_SUCCESS


def cmd_validate(args: argparse.Namespace) -> int:
    try:
        ticket = _resolved_ticket_from_args(args)
        get_workflow_action_ids(ticket.type)
    except ValidationFailure as exc:
        print(f"[ERROR] {exc}")
        return EXIT_VALIDATION
    except ValueError as exc:
        print(f"[ERROR] {exc}")
        return EXIT_VALIDATION

    print("=== VALIDATION ===")
    print(f"Ticket: {ticket.ticket_id} | Type: {ticket.type}")
    print(f"Tenant: {ticket.tenant_id}")
    print(f"User: {ticket.user_email}")
    print("Result: valid")
    return EXIT_SUCCESS


def cmd_plan(args: argparse.Namespace) -> int:
    approve_arg = getattr(args, "approve", "")
    approved = {a.strip() for a in approve_arg.split(",") if a.strip()}
    try:
        ticket = _resolved_ticket_from_args(args)
        specs = get_workflow_specs(ticket.type)
    except ValidationFailure as exc:
        print(f"[ERROR] {exc}")
        return EXIT_VALIDATION
    except ValueError as exc:
        print(f"[ERROR] {exc}")
        return EXIT_VALIDATION

    print("=== PLAN PREVIEW ===")
    print(f"Ticket: {ticket.ticket_id} | Type: {ticket.type}")
    if ticket.type == "group_diff":
        print(
            "group_diff: to_add_count/to_remove_count are computed at execution time "
            f"(desired_count={len(ticket.desired_group_ids)})"
        )
    for index, spec in enumerate(specs, start=1):
        if spec.requires_approval and spec.action_id not in approved:
            outcome = "would_block"
            reason = "approval required"
        elif spec.precheck is not None and spec.safe_repeatable:
            outcome = "may_skip"
            reason = "precheck may find desired end-state already applied"
        else:
            outcome = "would_run"
            reason = "ready"
        touches = ", ".join(spec.touches) if spec.touches else "-"
        print(
            f"{index}. {spec.action_id} | {outcome} | reason={reason} | "
            f"approval={'yes' if spec.requires_approval else 'no'} | touches={touches}"
        )
    return EXIT_SUCCESS


def cmd_run(args: argparse.Namespace) -> int:
    ticket_path = Path(args.ticket)
    if not ticket_path.exists():
        print(f"[ERROR] Ticket file not found: {ticket_path}")
        return EXIT_VALIDATION

    operator_arg = getattr(args, "operator", "")
    approve_arg = getattr(args, "approve", "")
    execute_arg = bool(getattr(args, "execute", False))
    confirm_tenant_arg = getattr(args, "confirm_tenant", "")
    confirm_user_arg = getattr(args, "confirm_user", "")

    settings = RuntimeSettings.from_env()
    actor = operator_arg or settings.operator_email
    approved = {a.strip() for a in approve_arg.split(",") if a.strip()}
    dry_run = not execute_arg
    run_id = str(uuid.uuid4())
    started_at = _utc_now()

    try:
        ticket = _load_ticket(ticket_path)
    except ValidationFailure as e:
        print(f"[ERROR] {e}")
        return EXIT_VALIDATION

    auditor = Auditor(runs_dir=Path("data/runs"))
    run_payload = _base_run_payload(
        run_id=run_id,
        started_at=started_at,
        operator=actor,
        ticket=ticket,
        dry_run=dry_run,
    )
    run_payload["approved_actions"] = sorted(list(approved))
    run_log_path = auditor.create_run(run_id=run_id, payload=run_payload)

    print(f"\n[INFO] Operator: {actor}")

    try:
        if execute_arg and not settings.execution_enabled:
            raise ValidationFailure("execution disabled (set MSP_EXECUTION_ENABLED=true to allow --execute)")

        resolved_tenant_id = RuntimeSettings.resolve_tenant_guid(ticket.tenant_id)
        if confirm_tenant_arg:
            confirmed_tenant_id = RuntimeSettings.resolve_tenant_guid(confirm_tenant_arg)
            if confirmed_tenant_id != resolved_tenant_id:
                raise ValidationFailure(
                    f"confirm tenant mismatch ({confirmed_tenant_id} != {resolved_tenant_id})"
                )

        if confirm_user_arg and _normalize_email(confirm_user_arg) != _normalize_email(ticket.user_email):
            raise ValidationFailure(
                f"confirm user mismatch ({confirm_user_arg} != {ticket.user_email})"
            )

        ticket = Ticket(
            ticket_id=ticket.ticket_id,
            type=ticket.type,
            tenant_id=resolved_tenant_id,
            user_email=ticket.user_email,
            remove_sku_ids=ticket.remove_sku_ids,
            add_sku_ids=ticket.add_sku_ids,
            add_group_ids=ticket.add_group_ids,
            desired_group_ids=ticket.desired_group_ids,
            group_diff_scope=ticket.group_diff_scope,
            usage_location=ticket.usage_location,
            require_password_reset=ticket.require_password_reset,
            mailbox_identity=ticket.mailbox_identity,
        )
        planner = Planner()
        plan = planner.build_plan(ticket)

        # Dry-runs must never trigger interactive auth/device login.
        executor = Executor(auditor=auditor, prefer_real=not dry_run)
        result = executor.run(
            ticket=ticket,
            plan=plan,
            dry_run=dry_run,
            approved_actions=approved,
            operator=actor,
            run_id=run_id,
            started_at=started_at,
        )
        print("\n=== SUMMARY ===")
        print(f"Ticket: {ticket.ticket_id} | Type: {ticket.type}")
        print(f"Success: {result.success}")
        print(f"Run log: {result.run_log_path}")
        payload = json.loads(result.run_log_path.read_text(encoding="utf-8"))
        summary = payload.get("run_summary.txt", "")
        if summary:
            print("\n" + summary)
        return _exit_code_from_run_payload(payload)
    except Exception as e:
        completed_at = _utc_now()
        failed_payload = dict(run_payload)
        failed_payload["completed_at"] = completed_at.isoformat()
        failed_payload["duration_seconds"] = (completed_at - started_at).total_seconds()
        failed_payload["success"] = False
        failed_payload["status"] = "failed"
        error_type = _error_type_from_exception(e)
        failed_payload["error"] = {
            "message": str(e),
            "error_type": error_type,
        }
        run_log_path = auditor.update_run(run_id=run_id, payload=failed_payload)
        print("\n=== SUMMARY ===")
        print(f"Ticket: {ticket.ticket_id} | Type: {ticket.type}")
        print("Success: False")
        print(f"Run log: {run_log_path}")
        print(f"[ERROR] {e}")
        return _error_type_to_exit_code(error_type)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="msp-copilot")
    sub = parser.add_subparsers(dest="command", required=True)

    explain_p = sub.add_parser("explain", help="Explain workflow actions and metadata")
    explain_p.add_argument("workflow", type=str, help="Workflow ID (e.g. offboarding)")
    explain_p.set_defaults(func=cmd_explain)

    validate_p = sub.add_parser("validate", help="Validate ticket + guardrails (no auth, no writes)")
    validate_p.add_argument("--ticket", required=True, help="Path to ticket JSON")
    validate_p.add_argument("--confirm-tenant", type=str, default="", help="Explicit tenant confirmation")
    validate_p.add_argument("--confirm-user", type=str, default="", help="Explicit user email confirmation")
    validate_p.set_defaults(func=cmd_validate)

    plan_p = sub.add_parser("plan", help="Print workflow plan preview (no auth, no writes)")
    plan_p.add_argument("--ticket", required=True, help="Path to ticket JSON")
    plan_p.add_argument(
        "--approve",
        type=str,
        default="",
        help="Comma-separated list of actions to treat as approved during preview",
    )
    plan_p.add_argument("--confirm-tenant", type=str, default="", help="Explicit tenant confirmation")
    plan_p.add_argument("--confirm-user", type=str, default="", help="Explicit user email confirmation")
    plan_p.set_defaults(func=cmd_plan)

    doctor_p = sub.add_parser("doctor", help="Run environment and Graph readiness checks")
    doctor_p.add_argument("--tenant", type=str, default="", help="Tenant alias or GUID to verify resolution")
    doctor_p.add_argument("--test-user", type=str, default="", help="User email to verify Graph user resolution")
    doctor_p.add_argument("--verbose", action="store_true", help="Print detailed evidence for each check")
    doctor_p.add_argument("--json", dest="json_output", action="store_true", help="Emit doctor result as JSON")
    doctor_p.set_defaults(func=cmd_doctor)

    run_p = sub.add_parser("run", help="Run a workflow on a ticket JSON")
    run_p.add_argument("--ticket", required=True, help="Path to ticket JSON")
    run_p.add_argument("--execute", action="store_true", help="Execute actions (default is dry-run)")
    run_p.add_argument(
        "--approve",
        type=str,
        default="",
        help="Comma-separated list of actions to approve (e.g. 'remove_licenses,convert_mailbox')",
    )
    run_p.add_argument(
        "--operator",
        type=str,
        default="",
        help="Operator identity for audit logs (e.g. analyst@company.com)",
    )
    run_p.add_argument("--confirm-tenant", type=str, default="", help="Explicit tenant confirmation (alias or GUID)")
    run_p.add_argument("--confirm-user", type=str, default="", help="Explicit user email confirmation")
    run_p.set_defaults(func=cmd_run)

    last_p = sub.add_parser("last-run", help="Print latest run summary")
    last_p.set_defaults(func=cmd_last_run)
    return parser


def main() -> int:
    load_dotenv()
    parser = build_parser()
    args = parser.parse_args()
    handler = cast(Callable[[argparse.Namespace], int] | None, getattr(args, "func", None))
    if handler is None:
        raise ValidationFailure("No command handler configured")
    return handler(args)


if __name__ == "__main__":
    raise SystemExit(main())
