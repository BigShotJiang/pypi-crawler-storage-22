from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator


class TicketLog(BaseModel):
    model_config = ConfigDict(extra="forbid")
    ticket_id: str
    type: str
    tenant_id: str
    user_email: str


class StepLog(BaseModel):
    model_config = ConfigDict(extra="forbid")
    step: int = Field(ge=1)
    action: str
    status: Literal["planned", "completed", "blocked", "failed", "skipped"]
    detail: str = ""
    started_at: str | None = None
    ended_at: str | None = None
    requires_approval: bool = False
    evidence: dict[str, Any] = Field(default_factory=dict)


class ErrorLog(BaseModel):
    model_config = ConfigDict(extra="allow")
    message: str
    error_type: str


class RunLog(BaseModel):
    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    run_schema_version: Literal[1] = 1
    run_id: str
    started_at: str
    completed_at: str | None = None
    duration_seconds: float | None = None
    ticket: TicketLog
    dry_run: bool
    operator: str
    run_version: str = "unknown"
    git_commit: str = "unknown"
    approved_actions: list[str] = Field(default_factory=list)
    resolved_tenant_id: str | None = None
    resolved_user_id: str | None = None
    resolved_user_principal_name: str | None = None
    steps: list[StepLog] = Field(default_factory=list)
    success: bool | None = None
    status: Literal["running", "completed", "failed"]
    error: ErrorLog | None = None
    run_summary_txt: str = Field(default="", alias="run_summary.txt")

    @model_validator(mode="after")
    def enforce_success_contract(self) -> "RunLog":
        has_failed_steps = any(step.status == "failed" for step in self.steps)
        if self.success is True and has_failed_steps:
            raise ValueError("success=true cannot coexist with failed steps")
        if self.success is False and self.status == "completed":
            raise ValueError("success=false requires failed status")
        return self
