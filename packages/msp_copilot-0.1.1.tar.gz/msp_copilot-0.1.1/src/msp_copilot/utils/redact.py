from __future__ import annotations

import re
from typing import Any

_SENSITIVE_KEY_RE = re.compile(
    r"(token|authorization|password|secret|api[_-]?key|client[_-]?secret)",
    re.IGNORECASE,
)
_BEARER_RE = re.compile(r"bearer\s+[a-z0-9\-._~+/]+=*", re.IGNORECASE)


def _redact_string(value: str) -> str:
    return _BEARER_RE.sub("[REDACTED]", value)


def redact_sensitive(value: Any) -> Any:
    if isinstance(value, dict):
        output: dict[Any, Any] = {}
        for key, item in value.items():
            key_str = str(key)
            if _SENSITIVE_KEY_RE.search(key_str):
                output[key] = "[REDACTED]"
                continue
            output[key] = redact_sensitive(item)
        return output
    if isinstance(value, list):
        return [redact_sensitive(item) for item in value]
    if isinstance(value, tuple):
        return tuple(redact_sensitive(item) for item in value)
    if isinstance(value, str):
        return _redact_string(value)
    return value
