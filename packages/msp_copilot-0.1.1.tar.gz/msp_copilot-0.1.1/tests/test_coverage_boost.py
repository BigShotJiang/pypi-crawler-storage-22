from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import pytest

from msp_copilot.connectors.microsoft_graph.auth import DeviceCodeAuth
from msp_copilot.connectors.microsoft_graph.operations import MockGraphOperations
from msp_copilot.connectors.microsoft_graph.real_operations import RealGraphOperations
from msp_copilot.domain.ticket import Ticket
from msp_copilot.errors import ValidationFailure
from msp_copilot.main import (
    EXIT_AUTH,
    EXIT_FAILED,
    EXIT_PERMISSION,
    EXIT_TRANSIENT,
    EXIT_VALIDATION,
    _classify_top_level_error,
    _error_type_from_exception,
    _error_type_to_exit_code,
    _exit_code_from_run_payload,
    _load_ticket,
    cmd_last_run,
)
from msp_copilot.utils.redact import redact_sensitive


class _FakeResp:
    def __init__(
        self,
        status_code: int,
        *,
        payload: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
        text: str = "",
    ) -> None:
        self.status_code = status_code
        self._payload = payload or {}
        self.headers = headers or {}
        self.text = text

    def json(self) -> dict[str, Any]:
        return self._payload


def test_error_classification_helpers() -> None:
    assert _classify_top_level_error("VALIDATION_ERROR: x") == "VALIDATION_ERROR"
    assert _classify_top_level_error("Auth failed: token expired") == "AUTH_ERROR"
    assert _classify_top_level_error("boom") == "RUNTIME_ERROR"
    assert _error_type_from_exception(ValidationFailure("bad")) == "VALIDATION_ERROR"
    assert _error_type_to_exit_code("AUTH_ERROR") == EXIT_AUTH
    assert _error_type_to_exit_code("PERMISSION_ERROR") == EXIT_PERMISSION
    assert _error_type_to_exit_code("TRANSIENT") == EXIT_TRANSIENT
    assert _error_type_to_exit_code("SOMETHING_ELSE") == EXIT_FAILED


def test_exit_code_from_payload_paths() -> None:
    assert _exit_code_from_run_payload({"success": True}) == 0
    assert (
        _exit_code_from_run_payload(
            {"success": False, "error": {"error_type": "VALIDATION_ERROR"}, "steps": []}
        )
        == EXIT_VALIDATION
    )
    assert (
        _exit_code_from_run_payload(
            {
                "success": False,
                "steps": [{"status": "failed", "evidence": {"error_type": "PERMISSION_ERROR"}}],
            }
        )
        == EXIT_PERMISSION
    )


def test_load_ticket_and_last_run_edges(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    valid_ticket = tmp_path / "ok.json"
    valid_ticket.write_text(
        json.dumps(
                {
                    "ticket_id": "t100",
                "type": "offboarding",
                "tenant_id": "demo-tenant",
                "user_email": "john@example.com",
            }
        ),
        encoding="utf-8",
    )
    ticket = _load_ticket(valid_ticket)
    assert ticket.ticket_id == "t100"

    invalid_ticket = tmp_path / "bad.json"
    invalid_ticket.write_text("{", encoding="utf-8")
    with pytest.raises(ValidationFailure):
        _load_ticket(invalid_ticket)

    monkeypatch.chdir(tmp_path)
    rc = cmd_last_run(argparse.Namespace())
    assert rc == EXIT_FAILED


def test_ticket_optional_fields_normalize() -> None:
    ticket = Ticket.from_dict(
        {
            "ticket_id": "t200",
            "type": "offboarding",
            "tenant_id": "demo-tenant",
            "user_email": "john@example.com",
            "remove_sku_ids": ["", "11111111-1111-1111-1111-111111111111", "   "],
            "mailbox_identity": "shared-mailbox@example.com",
        }
    )
    assert ticket.remove_sku_ids == ("11111111-1111-1111-1111-111111111111",)
    assert ticket.mailbox_identity == "shared-mailbox@example.com"


def test_ticket_validation_error_path() -> None:
    with pytest.raises(ValueError, match="Invalid ticket"):
        Ticket.from_dict(
            {
                "ticket_id": "bad ticket id",
                "type": "offboarding",
                "tenant_id": "demo-tenant",
                "user_email": "not-an-email",
            }
        )


def test_redact_tuple_branch() -> None:
    redacted = redact_sensitive(("Bearer abc.def.ghi", {"api_key": "x"}))
    assert redacted[0] == "[REDACTED]"
    assert redacted[1]["api_key"] == "[REDACTED]"


def test_mock_operations_branches() -> None:
    ops = MockGraphOperations(sleep_seconds=0.0)
    user, ev = ops.find_user("")
    assert user is None
    assert ev["error_type"] == "VALIDATION_ERROR"

    user, ev = ops.find_user("john@example.com")
    assert user is not None
    assert ev["http_status"] == 200

    enabled, _ = ops.get_user_account_enabled("u1")
    assert enabled is True
    ok, _ = ops.disable_sign_in("u1")
    assert ok is True
    enabled, _ = ops.get_user_account_enabled("u1")
    assert enabled is False

    ok, _ = ops.disable_sign_in("")
    assert ok is False
    ok, _ = ops.revoke_sessions("")
    assert ok is False

    profile, ev = ops.get_user_profile("")
    assert profile is None
    assert ev["error_type"] == "VALIDATION_ERROR"
    profile, _ = ops.get_user_profile("u1")
    assert profile and profile["id"] == "u1"

    assert ops.remove_from_groups("") is False
    assert ops.remove_from_groups("u1") is True
    assert ops.delete_mailbox("") is False
    assert ops.delete_mailbox("u1") is True
    assert ops.remove_admin_roles("") is False
    assert ops.remove_admin_roles("u1") is True
    ok, ev = ops.enable_sign_in("u1")
    assert ok is True
    assert ev["http_status"] == 204
    user2, _ = ops.find_user("usage@example.com")
    assert user2 is not None
    usage, ev = ops.get_user_usage_location(user2)
    assert ev["http_status"] == 200
    assert isinstance(usage, str)
    ok, ev = ops.set_user_usage_location(user2, "CA")
    assert ok is True
    assert ev["usageLocation"] == "CA"
    groups, ev = ops.list_user_group_ids(user2)
    assert ev["http_status"] == 200
    assert groups == []
    ok, ev = ops.add_user_to_group(user2, "44444444-4444-4444-4444-444444444444")
    assert ok is True
    assert ev["group_id"] == "44444444-4444-4444-4444-444444444444"
    ok, ev = ops.remove_user_from_group(user2, "44444444-4444-4444-4444-444444444444")
    assert ok is True
    assert ev["group_id"] == "44444444-4444-4444-4444-444444444444"
    ok, ev = ops.remove_user_from_group("", "")
    assert ok is False
    assert ev["error_type"] == "VALIDATION_ERROR"
    required, ev = ops.get_user_force_password_reset(user2)
    assert ev["http_status"] == 200
    assert required is False
    ok, ev = ops.set_user_force_password_reset(user2, True)
    assert ok is True
    assert ev["forceChangePasswordNextSignIn"] is True
    required, ev = ops.get_user_force_password_reset("")
    assert required is None
    assert ev["error_type"] == "VALIDATION_ERROR"
    ok, ev = ops.set_user_force_password_reset("", True)
    assert ok is False
    assert ev["error_type"] == "VALIDATION_ERROR"
    ok, ev = ops.enable_sign_in("")
    assert ok is False
    assert ev["error_type"] == "VALIDATION_ERROR"
    usage, ev = ops.get_user_usage_location("")
    assert usage is None
    assert ev["error_type"] == "VALIDATION_ERROR"
    ok, ev = ops.set_user_usage_location("", "")
    assert ok is False
    assert ev["error_type"] == "VALIDATION_ERROR"
    groups, ev = ops.list_user_group_ids("")
    assert groups == []
    assert ev["error_type"] == "VALIDATION_ERROR"
    ok, ev = ops.add_user_to_group("", "")
    assert ok is False
    assert ev["error_type"] == "VALIDATION_ERROR"

    licenses, ev = ops.get_user_license_details("")
    assert licenses == []
    assert ev["error_type"] == "VALIDATION_ERROR"
    user, _ = ops.find_user("license.user@example.com")
    assert user is not None
    licenses, ev = ops.get_user_license_details(user)
    assert ev["http_status"] == 200
    assert len(licenses) >= 1
    ok, ev = ops.assign_licenses(user, add_license_ids=["33333333-3333-3333-3333-333333333333"], remove_license_ids=[licenses[0]["skuId"]])
    assert ok is True
    assert ev["removed_count"] == 1
    assert ev["added_count"] == 1
    roles, ev = ops.list_user_directory_roles(user)
    assert ev["http_status"] == 200
    assert len(roles) >= 1
    ok, ev = ops.remove_directory_role_member(roles[0]["id"], user)
    assert ok is True
    assert ev["http_status"] == 204
    ok, ev = ops.remove_directory_role_member("", user)
    assert ok is False
    assert ev["error_type"] == "VALIDATION_ERROR"


def test_real_operations_wrapper_methods() -> None:
    responses = [
        _FakeResp(200, payload={"id": "u1", "userPrincipalName": "john@example.com"}),
        _FakeResp(200, payload={"id": "u1", "userPrincipalName": "john@example.com"}),
        _FakeResp(200, payload={"value": [{"id": "tenant-id"}]}),
        _FakeResp(200, payload={"accountEnabled": True, "userPrincipalName": "john@example.com"}),
        _FakeResp(204),
        _FakeResp(204),
        _FakeResp(404, text="not found"),
    ]

    def request_fn(**kwargs: Any) -> _FakeResp:
        return responses.pop(0)

    ops = RealGraphOperations("token", request_fn=request_fn, sleep_fn=lambda _: None, rng_fn=lambda a, b: 0)

    user, _ = ops.find_user("john@example.com")
    assert user == "u1"
    profile, _ = ops.get_user_profile("u1")
    assert profile and profile["id"] == "u1"
    tenant, _ = ops.get_organization_tenant_id()
    assert tenant == "tenant-id"
    enabled, _ = ops.get_user_account_enabled("u1")
    assert enabled is True
    ok, _ = ops.disable_sign_in("u1")
    assert ok is True
    ok, _ = ops.revoke_sessions("u1")
    assert ok is True
    missing, ev = ops.find_user("missing@example.com")
    assert missing is None
    assert ev["http_status"] == 404
    assert ev["error_type"] == "NOT_FOUND"


def test_real_operations_retry_after_parse_and_classify() -> None:
    ops = RealGraphOperations("token", request_fn=lambda **_: _FakeResp(500))
    assert ops._parse_retry_after(None) is None
    assert ops._parse_retry_after("abc") is None
    assert ops._parse_retry_after("2") == 2.0
    assert ops._classify_status(401)[0] == "AUTH_ERROR"
    assert ops._classify_status(429) == ("RATE_LIMIT", True)
    assert ops._classify_status(503) == ("TRANSIENT", True)


def test_device_code_auth_paths(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.chdir(tmp_path)

    class FakeCache:
        def __init__(self) -> None:
            self.has_state_changed = True

        def serialize(self) -> str:
            return "{}"

        def deserialize(self, _text: str) -> None:
            return None

    class FakePca:
        def __init__(self, *args: Any, **kwargs: Any) -> None:
            self.calls: list[str] = []

        def get_accounts(self) -> list[dict[str, str]]:
            return [{"home_account_id": "x"}]

        def acquire_token_silent(
            self, *, scopes: list[str], account: dict[str, str]
        ) -> dict[str, str] | None:
            _ = scopes, account
            return {"access_token": "abc"}

        def initiate_device_flow(self, *, scopes: list[str]) -> dict[str, str]:
            _ = scopes
            return {"user_code": "123", "message": "msg"}

        def acquire_token_by_device_flow(self, flow: dict[str, str]) -> dict[str, str]:
            _ = flow
            return {"access_token": "xyz"}

    monkeypatch.setattr("msp_copilot.connectors.microsoft_graph.auth.msal.SerializableTokenCache", FakeCache)
    monkeypatch.setattr("msp_copilot.connectors.microsoft_graph.auth.msal.PublicClientApplication", FakePca)

    auth = DeviceCodeAuth(client_id="id", tenant_id="common")
    assert auth.acquire_token() == "abc"
    assert auth.cache_path.exists()


def test_device_code_auth_failure_paths(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.chdir(tmp_path)

    class FakeCache:
        has_state_changed = False

        def serialize(self) -> str:
            return "{}"

        def deserialize(self, _text: str) -> None:
            return None

    class FlowFailPca:
        def __init__(self, *args: Any, **kwargs: Any) -> None:
            pass

        def get_accounts(self) -> list[dict[str, str]]:
            return []

        def acquire_token_silent(self, **kwargs: Any) -> None:
            _ = kwargs
            return None

        def initiate_device_flow(self, *, scopes: list[str]) -> dict[str, str]:
            _ = scopes
            return {"message": "no-user-code"}

        def acquire_token_by_device_flow(self, flow: dict[str, str]) -> dict[str, str]:
            _ = flow
            return {"error": "bad"}

    monkeypatch.setattr("msp_copilot.connectors.microsoft_graph.auth.msal.SerializableTokenCache", FakeCache)
    monkeypatch.setattr("msp_copilot.connectors.microsoft_graph.auth.msal.PublicClientApplication", FlowFailPca)
    auth = DeviceCodeAuth(client_id="id", tenant_id="common")
    with pytest.raises(Exception, match="Failed to create device flow"):
        auth.acquire_token()

    class TokenFailPca(FlowFailPca):
        def initiate_device_flow(self, *, scopes: list[str]) -> dict[str, str]:
            _ = scopes
            return {"user_code": "123", "message": "ok"}

    monkeypatch.setattr(
        "msp_copilot.connectors.microsoft_graph.auth.msal.PublicClientApplication", TokenFailPca
    )
    auth = DeviceCodeAuth(client_id="id", tenant_id="common")
    with pytest.raises(Exception, match="Auth failed"):
        auth.acquire_token()
