from __future__ import annotations

import json
from datetime import datetime, timezone
from itertools import chain, repeat
from pathlib import Path
from typing import Any

from hypothesis import HealthCheck, given, settings
from hypothesis import strategies as st

from msp_copilot.domain.action import Action
from msp_copilot.domain.plan import Plan
from msp_copilot.domain.ticket import Ticket
from msp_copilot.engine.auditor import Auditor
from msp_copilot.engine.executor import Executor

APPROVAL_ACTIONS = {"remove_licenses", "convert_mailbox"}


class CountingOps:
    def __init__(self, fail_action: str | None = None) -> None:
        self.fail_action = fail_action
        self.calls: dict[str, int] = {}
        self._disabled_users: set[str] = set()

    def _call(self, action: str) -> None:
        self.calls[action] = self.calls.get(action, 0) + 1

    def get_organization_tenant_id(self) -> tuple[str | None, dict[str, Any]]:
        self._call("get_organization_tenant_id")
        if self.fail_action == "tenant_guard":
            return "wrong-tenant", {"http_status": 200}
        return "demo-tenant", {"http_status": 200}

    def find_user(self, email: str) -> tuple[str | None, dict[str, Any]]:
        self._call("find_user")
        if self.fail_action == "find_user":
            return None, {"http_status": 404, "error_type": "NOT_FOUND", "retryable": False}
        return "uid-1", {"http_status": 200}

    def get_user_profile(self, user_id: str) -> tuple[dict[str, Any] | None, dict[str, Any]]:
        self._call("get_user_profile")
        return {
            "id": user_id,
            "userPrincipalName": "john.doe@cryingman121212outlook882.onmicrosoft.com",
        }, {"http_status": 200}

    def get_user_account_enabled(self, user_id: str) -> tuple[bool | None, dict[str, Any]]:
        self._call("get_user_account_enabled")
        enabled = user_id not in self._disabled_users
        return enabled, {"http_status": 200, "accountEnabled": enabled}

    def disable_sign_in(self, user_id: str) -> tuple[bool, dict[str, Any]]:
        self._call("disable_sign_in")
        if self.fail_action == "disable_sign_in":
            return False, {"http_status": 503, "error_type": "TRANSIENT", "retryable": True}
        self._disabled_users.add(user_id)
        return True, {"http_status": 204}

    def revoke_sessions(self, user_id: str) -> tuple[bool, dict[str, Any]]:
        self._call("revoke_sessions")
        if self.fail_action == "revoke_sessions":
            return False, {"http_status": 503, "error_type": "TRANSIENT", "retryable": True}
        return True, {"http_status": 204}

    def remove_admin_roles(self, user_id: str) -> bool:
        self._call("remove_admin_roles")
        return self.fail_action != "remove_admin_roles"


def _ticket() -> Ticket:
    return Ticket(
        ticket_id="offboard_property",
        type="offboarding",
        tenant_id="demo-tenant",
        user_email="john.doe@cryingman121212outlook882.onmicrosoft.com",
        remove_sku_ids=("11111111-1111-1111-1111-111111111111",),
    )


def _result_payload(executor: Executor, plan: Plan, tmp_path: Path, approved_actions: set[str]) -> dict[str, Any]:
    result = executor.run(
        ticket=_ticket(),
        plan=plan,
        dry_run=False,
        approved_actions=approved_actions,
        operator="tester@example.com",
    )
    return json.loads(result.run_log_path.read_text(encoding="utf-8"))


@given(
    actions=st.lists(
        st.sampled_from(["find_user", "disable_sign_in", "revoke_sessions", "remove_admin_roles", "remove_licenses", "convert_mailbox"]),
        min_size=1,
        max_size=8,
    ),
    approved=st.sets(st.sampled_from(["remove_licenses", "convert_mailbox"]), max_size=2),
)
@settings(suppress_health_check=[HealthCheck.function_scoped_fixture], deadline=None)
def test_approval_actions_block_without_approval(actions: list[str], approved: set[str], tmp_path: Path) -> None:
    plan_actions = [Action(name=name, requires_approval=name in APPROVAL_ACTIONS) for name in actions]
    plan = Plan(actions=plan_actions)

    executor = Executor(auditor=Auditor(runs_dir=tmp_path / "runs"))
    executor.graph_ops = CountingOps()
    payload = _result_payload(executor, plan, tmp_path, approved)

    for idx, step in enumerate(payload["steps"]):
        action_name = actions[idx]
        if action_name in APPROVAL_ACTIONS and action_name not in approved:
            assert step["status"] != "completed"


@given(
    failure_action=st.sampled_from(["find_user", "disable_sign_in", "revoke_sessions", "remove_admin_roles"]),
    action_count=st.integers(min_value=4, max_value=8),
)
@settings(suppress_health_check=[HealthCheck.function_scoped_fixture], deadline=None)
def test_fail_fast_skips_remaining_steps(failure_action: str, action_count: int, tmp_path: Path) -> None:
    base = ["find_user", "disable_sign_in", "revoke_sessions", "remove_admin_roles"]
    actions = (base * ((action_count // len(base)) + 1))[:action_count]
    plan = Plan(actions=[Action(name=name) for name in actions])
    ops = CountingOps(fail_action=failure_action)

    executor = Executor(auditor=Auditor(runs_dir=tmp_path / "runs"))
    executor.graph_ops = ops
    payload = _result_payload(executor, plan, tmp_path, approved_actions=set())

    statuses = [step["status"] for step in payload["steps"]]
    if "failed" in statuses:
        first_failed = statuses.index("failed")
        assert all(status == "skipped" for status in statuses[first_failed + 1 :])


@given(approved=st.sets(st.sampled_from(["remove_licenses", "convert_mailbox"]), max_size=2))
@settings(suppress_health_check=[HealthCheck.function_scoped_fixture], deadline=None)
def test_run_log_contract_fields_always_present(approved: set[str], tmp_path: Path) -> None:
    plan = Plan(actions=[Action(name="find_user"), Action(name="remove_licenses", requires_approval=True)])
    executor = Executor(auditor=Auditor(runs_dir=tmp_path / "runs"))
    executor.graph_ops = CountingOps()
    payload = _result_payload(executor, plan, tmp_path, approved)

    assert payload["run_schema_version"] == 1
    assert payload["run_id"]
    assert payload["operator"]
    assert payload["status"] in {"completed", "failed", "running"}


def test_unknown_action_fails_explicitly(tmp_path: Path) -> None:
    plan = Plan(actions=[Action(name="find_user"), Action(name="definitely_unknown_action")])
    executor = Executor(auditor=Auditor(runs_dir=tmp_path / "runs"))
    executor.graph_ops = CountingOps()
    payload = _result_payload(executor, plan, tmp_path, approved_actions=set())

    assert payload["success"] is False
    assert any(step["status"] == "failed" for step in payload["steps"])


def test_executor_run_uses_injected_clock_for_timestamps(tmp_path: Path) -> None:
    fixed_start = datetime(2026, 2, 11, 1, 0, 0, tzinfo=timezone.utc)
    fixed_end = datetime(2026, 2, 11, 1, 0, 7, tzinfo=timezone.utc)
    times = iter(chain([fixed_start], repeat(fixed_end)))

    executor = Executor(
        auditor=Auditor(runs_dir=tmp_path / "runs"),
        now_fn=lambda: next(times),
    )
    executor.graph_ops = CountingOps()
    plan = Plan(actions=[Action(name="find_user")])

    payload = _result_payload(executor, plan, tmp_path, approved_actions=set())
    assert payload["started_at"] == "2026-02-11T01:00:00+00:00"
    assert payload["completed_at"] == "2026-02-11T01:00:07+00:00"
    assert payload["duration_seconds"] == 7.0
