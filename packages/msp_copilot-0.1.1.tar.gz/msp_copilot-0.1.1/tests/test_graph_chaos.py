from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import requests

from msp_copilot.connectors.microsoft_graph.real_operations import RealGraphOperations


@dataclass
class FakeResponse:
    status_code: int
    headers: dict[str, str] = field(default_factory=dict)
    text: str = ""
    _json: dict[str, Any] = field(default_factory=dict)

    def json(self) -> dict[str, Any]:
        return self._json


def test_retry_after_header_is_respected() -> None:
    responses = [
        FakeResponse(status_code=429, headers={"Retry-After": "2"}),
        FakeResponse(status_code=429, headers={"Retry-After": "1.5"}),
        FakeResponse(status_code=200, _json={"id": "uid"}),
    ]
    sleeps: list[float] = []

    def request_fn(**kwargs: Any) -> FakeResponse:
        return responses.pop(0)

    ops = RealGraphOperations(
        "token",
        request_fn=request_fn,
        sleep_fn=lambda seconds: sleeps.append(seconds),
        rng_fn=lambda a, b: 0.99,
    )
    _, ev = ops._request("GET", "https://graph.microsoft.com/v1.0/users/id")

    assert ev["http_status"] == 200
    assert ev["attempts"] == 3
    assert sleeps == [2.0, 1.5]


def test_intermittent_timeout_then_success() -> None:
    sleeps: list[float] = []
    calls = {"count": 0}

    def request_fn(**kwargs: Any) -> FakeResponse:
        calls["count"] += 1
        if calls["count"] == 1:
            raise requests.Timeout("timeout")
        return FakeResponse(status_code=200, _json={"id": "uid"})

    ops = RealGraphOperations(
        "token",
        request_fn=request_fn,
        sleep_fn=lambda seconds: sleeps.append(seconds),
        rng_fn=lambda a, b: 0.0,
    )
    _, ev = ops._request("GET", "https://graph.microsoft.com/v1.0/users/id")

    assert ev["http_status"] == 200
    assert ev["attempts"] == 2
    assert sleeps == [1.0]


def test_non_json_error_body_and_deterministic_classification() -> None:
    def request_fn(**kwargs: Any) -> FakeResponse:
        return FakeResponse(status_code=403, text="plain forbidden response")

    ops = RealGraphOperations("token", request_fn=request_fn, sleep_fn=lambda seconds: None)
    _, ev = ops._request("GET", "https://graph.microsoft.com/v1.0/users/id")

    assert ev["http_status"] == 403
    assert ev["error_type"] == "PERMISSION_ERROR"
    assert ev["retryable"] is False
    assert ev["error_body"] == "plain forbidden response"


def test_503_uses_jitter_when_retry_after_missing() -> None:
    responses = [
        FakeResponse(status_code=503),
        FakeResponse(status_code=200, _json={"id": "uid"}),
    ]
    sleeps: list[float] = []

    def request_fn(**kwargs: Any) -> FakeResponse:
        return responses.pop(0)

    ops = RealGraphOperations(
        "token",
        request_fn=request_fn,
        sleep_fn=lambda seconds: sleeps.append(seconds),
        rng_fn=lambda a, b: 0.25,
    )
    _, ev = ops._request("GET", "https://graph.microsoft.com/v1.0/users/id")

    assert ev["attempts"] == 2
    assert sleeps == [1.25]
