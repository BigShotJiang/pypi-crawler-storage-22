from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from msp_copilot.domain.ticket import Ticket
from msp_copilot.engine.auditor import Auditor
from msp_copilot.engine.executor import Executor
from msp_copilot.engine.planner import Planner


class GroupDiffOps:
    def __init__(self, groups: set[str]) -> None:
        self.groups = set(groups)

    def get_organization_tenant_id(self) -> tuple[str | None, dict[str, Any]]:
        return "demo-tenant", {"http_status": 200}

    def find_user(self, email: str) -> tuple[str | None, dict[str, Any]]:
        _ = email
        return "uid-1", {"http_status": 200}

    def get_user_profile(self, user_id: str) -> tuple[dict[str, Any] | None, dict[str, Any]]:
        return {"id": user_id, "userPrincipalName": "john.doe@cryingman121212outlook882.onmicrosoft.com"}, {"http_status": 200}

    def list_user_group_ids(self, user_id: str) -> tuple[list[str], dict[str, Any]]:
        _ = user_id
        return sorted(list(self.groups)), {"http_status": 200}

    def add_user_to_group(self, user_id: str, group_id: str) -> tuple[bool, dict[str, Any]]:
        _ = user_id
        self.groups.add(group_id)
        return True, {"http_status": 204}

    def remove_user_from_group(self, user_id: str, group_id: str) -> tuple[bool, dict[str, Any]]:
        _ = user_id
        self.groups.discard(group_id)
        return True, {"http_status": 204}


def _ticket(*, desired: tuple[str, ...], scope: str = "managed_only") -> Ticket:
    return Ticket(
        ticket_id="gd1",
        type="group_diff",
        tenant_id="demo-tenant",
        user_email="john.doe@cryingman121212outlook882.onmicrosoft.com",
        desired_group_ids=desired,
        group_diff_scope=scope,
    )


def test_group_diff_managed_only_computes_add_remove(tmp_path: Path, monkeypatch) -> None:
    g1 = "11111111-1111-1111-1111-111111111111"
    g2 = "22222222-2222-2222-2222-222222222222"
    g3 = "33333333-3333-3333-3333-333333333333"
    monkeypatch.setenv("MSP_MANAGED_GROUP_IDS", f"{g1},{g2},{g3}")
    monkeypatch.setenv("MSP_GROUP_REMOVE_MAX", "10")
    ops = GroupDiffOps(groups={g1, g2})
    executor = Executor(auditor=Auditor(runs_dir=tmp_path / "runs"))
    executor.graph_ops = ops
    plan = Planner().build_plan(_ticket(desired=(g2, g3), scope="managed_only"))
    result = executor.run(
        ticket=_ticket(desired=(g2, g3), scope="managed_only"),
        plan=plan,
        dry_run=False,
        approved_actions={"group_diff_apply"},
        operator="tester@example.com",
    )
    payload = json.loads(result.run_log_path.read_text(encoding="utf-8"))
    step = [s for s in payload["steps"] if s["action"] == "group_diff_apply"][0]
    assert step["status"] == "completed"
    assert step["evidence"]["to_add"] == [g3]
    assert step["evidence"]["to_remove"] == [g1]


def test_group_diff_scope_all_uses_full_membership(tmp_path: Path, monkeypatch) -> None:
    g1 = "11111111-1111-1111-1111-111111111111"
    g2 = "22222222-2222-2222-2222-222222222222"
    gx = "aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa"
    monkeypatch.setenv("MSP_GROUP_REMOVE_MAX", "10")
    ops = GroupDiffOps(groups={g1, g2, gx})
    executor = Executor(auditor=Auditor(runs_dir=tmp_path / "runs"))
    executor.graph_ops = ops
    ticket = _ticket(desired=(g2,), scope="all")
    plan = Planner().build_plan(ticket)
    result = executor.run(
        ticket=ticket,
        plan=plan,
        dry_run=False,
        approved_actions={"group_diff_apply"},
        operator="tester@example.com",
    )
    payload = json.loads(result.run_log_path.read_text(encoding="utf-8"))
    step = [s for s in payload["steps"] if s["action"] == "group_diff_apply"][0]
    assert step["status"] == "completed"
    assert sorted(step["evidence"]["to_remove"]) == sorted([g1, gx])


def test_group_diff_add_only_runs_without_approval(tmp_path: Path, monkeypatch) -> None:
    g1 = "11111111-1111-1111-1111-111111111111"
    monkeypatch.setenv("MSP_MANAGED_GROUP_IDS", g1)
    monkeypatch.setenv("MSP_GROUP_REMOVE_MAX", "10")
    ops = GroupDiffOps(groups=set())
    executor = Executor(auditor=Auditor(runs_dir=tmp_path / "runs"))
    executor.graph_ops = ops
    ticket = _ticket(desired=(g1,), scope="managed_only")
    plan = Planner().build_plan(ticket)
    result = executor.run(
        ticket=ticket,
        plan=plan,
        dry_run=False,
        approved_actions=set(),
        operator="tester@example.com",
    )
    payload = json.loads(result.run_log_path.read_text(encoding="utf-8"))
    step = [s for s in payload["steps"] if s["action"] == "group_diff_apply"][0]
    assert step["status"] == "completed"


def test_group_diff_remove_requires_approval(tmp_path: Path, monkeypatch) -> None:
    g1 = "11111111-1111-1111-1111-111111111111"
    g2 = "22222222-2222-2222-2222-222222222222"
    monkeypatch.setenv("MSP_MANAGED_GROUP_IDS", f"{g1},{g2}")
    monkeypatch.setenv("MSP_GROUP_REMOVE_MAX", "10")
    ops = GroupDiffOps(groups={g1, g2})
    executor = Executor(auditor=Auditor(runs_dir=tmp_path / "runs"))
    executor.graph_ops = ops
    ticket = _ticket(desired=(g1,), scope="managed_only")
    plan = Planner().build_plan(ticket)
    result = executor.run(
        ticket=ticket,
        plan=plan,
        dry_run=False,
        approved_actions=set(),
        operator="tester@example.com",
    )
    payload = json.loads(result.run_log_path.read_text(encoding="utf-8"))
    step = [s for s in payload["steps"] if s["action"] == "group_diff_apply"][0]
    assert step["status"] == "blocked"


def test_group_diff_protected_group_fails(tmp_path: Path, monkeypatch) -> None:
    g1 = "11111111-1111-1111-1111-111111111111"
    g2 = "22222222-2222-2222-2222-222222222222"
    monkeypatch.setenv("MSP_MANAGED_GROUP_IDS", f"{g1},{g2}")
    monkeypatch.setenv("MSP_PROTECTED_GROUP_IDS", g2)
    monkeypatch.setenv("MSP_GROUP_REMOVE_MAX", "10")
    ops = GroupDiffOps(groups={g1, g2})
    executor = Executor(auditor=Auditor(runs_dir=tmp_path / "runs"))
    executor.graph_ops = ops
    ticket = _ticket(desired=(g1,), scope="managed_only")
    plan = Planner().build_plan(ticket)
    result = executor.run(
        ticket=ticket,
        plan=plan,
        dry_run=False,
        approved_actions={"group_diff_apply"},
        operator="tester@example.com",
    )
    payload = json.loads(result.run_log_path.read_text(encoding="utf-8"))
    step = [s for s in payload["steps"] if s["action"] == "group_diff_apply"][0]
    assert step["status"] == "failed"
    assert "protected groups" in step["detail"].lower()


def test_group_diff_removal_cap_fails(tmp_path: Path, monkeypatch) -> None:
    gids = [
        "11111111-1111-1111-1111-111111111111",
        "22222222-2222-2222-2222-222222222222",
        "33333333-3333-3333-3333-333333333333",
    ]
    monkeypatch.setenv("MSP_MANAGED_GROUP_IDS", ",".join(gids))
    monkeypatch.setenv("MSP_GROUP_REMOVE_MAX", "1")
    ops = GroupDiffOps(groups=set(gids))
    executor = Executor(auditor=Auditor(runs_dir=tmp_path / "runs"))
    executor.graph_ops = ops
    ticket = _ticket(desired=(gids[0],), scope="managed_only")
    plan = Planner().build_plan(ticket)
    result = executor.run(
        ticket=ticket,
        plan=plan,
        dry_run=False,
        approved_actions={"group_diff_apply"},
        operator="tester@example.com",
    )
    payload = json.loads(result.run_log_path.read_text(encoding="utf-8"))
    step = [s for s in payload["steps"] if s["action"] == "group_diff_apply"][0]
    assert step["status"] == "failed"
    assert "exceeds msp_group_remove_max" in step["detail"].lower()


def test_group_diff_idempotent_rerun_skips(tmp_path: Path, monkeypatch) -> None:
    g1 = "11111111-1111-1111-1111-111111111111"
    g2 = "22222222-2222-2222-2222-222222222222"
    monkeypatch.setenv("MSP_MANAGED_GROUP_IDS", f"{g1},{g2}")
    monkeypatch.setenv("MSP_GROUP_REMOVE_MAX", "10")
    ops = GroupDiffOps(groups={g1})
    executor = Executor(auditor=Auditor(runs_dir=tmp_path / "runs"))
    executor.graph_ops = ops
    ticket = _ticket(desired=(g1, g2), scope="managed_only")
    plan = Planner().build_plan(ticket)

    first = executor.run(
        ticket=ticket,
        plan=plan,
        dry_run=False,
        approved_actions={"group_diff_apply"},
        operator="tester@example.com",
    )
    first_payload = json.loads(first.run_log_path.read_text(encoding="utf-8"))
    first_step = [s for s in first_payload["steps"] if s["action"] == "group_diff_apply"][0]
    assert first_step["status"] == "completed"

    second = executor.run(
        ticket=ticket,
        plan=plan,
        dry_run=False,
        approved_actions={"group_diff_apply"},
        operator="tester@example.com",
    )
    second_payload = json.loads(second.run_log_path.read_text(encoding="utf-8"))
    second_step = [s for s in second_payload["steps"] if s["action"] == "group_diff_apply"][0]
    assert second_step["status"] == "skipped"
