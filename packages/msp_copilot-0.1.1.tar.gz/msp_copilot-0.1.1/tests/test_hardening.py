import argparse
import json
from pathlib import Path

import msal

from msp_copilot.connectors.microsoft_graph.auth import DeviceCodeAuth
from msp_copilot.connectors.microsoft_graph.operations import MockGraphOperations
from msp_copilot.connectors.microsoft_graph.real_operations import RealGraphOperations
from msp_copilot.domain.ticket import Ticket
from msp_copilot.engine.auditor import Auditor
from msp_copilot.engine.executor import Executor
from msp_copilot.engine.planner import Planner
from msp_copilot.main import cmd_last_run, cmd_run


def _ticket(tenant_id: str = "demo-tenant", user_email: str = "john.doe@cryingman121212outlook882.onmicrosoft.com") -> Ticket:
    return Ticket(
        ticket_id="offboard_test",
        type="offboarding",
        tenant_id=tenant_id,
        user_email=user_email,
        remove_sku_ids=("11111111-1111-1111-1111-111111111111",),
    )


def _run_with_ops(tmp_path: Path, graph_ops, approved: set[str] | None = None):
    auditor = Auditor(runs_dir=tmp_path / "runs")
    executor = Executor(auditor=auditor)
    executor.graph_ops = graph_ops
    plan = Planner().build_plan(_ticket())
    return executor.run(
        ticket=_ticket(),
        plan=plan,
        dry_run=False,
        approved_actions=approved or set(),
        operator="tester@example.com",
    )


def test_tenant_mismatch_fails_before_write(tmp_path):
    class Ops:
        def __init__(self):
            self.find_called = False
            self.disable_called = False

        def get_organization_tenant_id(self):
            return "wrong-tenant", {"http_status": 200}

        def find_user(self, email):
            self.find_called = True
            return "uid", {"http_status": 200}

        def disable_sign_in(self, user_id):
            self.disable_called = True
            return True, {"http_status": 204}

        def revoke_sessions(self, user_id):
            return True, {"http_status": 204}

        def remove_admin_roles(self, user_id):
            return True

    ops = Ops()
    auditor = Auditor(runs_dir=tmp_path / "runs")
    executor = Executor(auditor=auditor)
    executor.graph_ops = ops
    ticket = _ticket(tenant_id="demo-tenant")
    plan = Planner().build_plan(ticket)
    result = executor.run(ticket=ticket, plan=plan, dry_run=False, approved_actions=set(), operator="tester")
    payload = json.loads(result.run_log_path.read_text(encoding="utf-8"))

    assert payload["success"] is False
    assert payload["steps"][0]["status"] == "failed"
    assert "Tenant guard failed" in payload["steps"][0]["detail"]
    assert ops.find_called is False
    assert ops.disable_called is False


def test_user_mismatch_fails_before_write(tmp_path):
    class Ops:
        def __init__(self):
            self.disable_called = False

        def get_organization_tenant_id(self):
            return "demo-tenant", {"http_status": 200}

        def find_user(self, email):
            return "uid", {"http_status": 200}

        def get_user_profile(self, user_id):
            return {"id": user_id, "userPrincipalName": "other@contoso.com"}, {"http_status": 200}

        def disable_sign_in(self, user_id):
            self.disable_called = True
            return True, {"http_status": 204}

        def revoke_sessions(self, user_id):
            return True, {"http_status": 204}

        def remove_admin_roles(self, user_id):
            return True

    ops = Ops()
    auditor = Auditor(runs_dir=tmp_path / "runs")
    executor = Executor(auditor=auditor)
    executor.graph_ops = ops
    ticket = _ticket(tenant_id="demo-tenant")
    plan = Planner().build_plan(ticket)
    result = executor.run(ticket=ticket, plan=plan, dry_run=False, approved_actions=set(), operator="tester")
    payload = json.loads(result.run_log_path.read_text(encoding="utf-8"))

    assert payload["success"] is False
    assert payload["steps"][0]["status"] == "failed"
    assert "User guard failed" in payload["steps"][0]["detail"]
    assert ops.disable_called is False


def test_approval_gating_blocks(tmp_path):
    result = _run_with_ops(tmp_path, MockGraphOperations(), approved=set())
    payload = json.loads(result.run_log_path.read_text(encoding="utf-8"))
    assert payload["steps"][4]["status"] == "blocked"
    assert payload["steps"][5]["status"] == "blocked"


def test_approved_actions_execute(tmp_path):
    result = _run_with_ops(
        tmp_path,
        MockGraphOperations(),
        approved={"remove_licenses", "convert_mailbox"},
    )
    payload = json.loads(result.run_log_path.read_text(encoding="utf-8"))
    assert payload["steps"][4]["status"] == "completed"
    assert payload["steps"][5]["status"] == "completed"


def test_idempotent_disable_sign_in_skips(tmp_path):
    class Ops:
        def __init__(self):
            self.disable_called = False

        def get_organization_tenant_id(self):
            return "demo-tenant", {"http_status": 200}

        def find_user(self, email):
            return "uid", {"http_status": 200}

        def get_user_profile(self, user_id):
            return {"id": user_id, "userPrincipalName": "john.doe@cryingman121212outlook882.onmicrosoft.com"}, {"http_status": 200}

        def get_user_account_enabled(self, user_id):
            return False, {"http_status": 200, "accountEnabled": False}

        def disable_sign_in(self, user_id):
            self.disable_called = True
            return True, {"http_status": 204}

        def revoke_sessions(self, user_id):
            return True, {"http_status": 204}

        def remove_admin_roles(self, user_id):
            return True

    ops = Ops()
    auditor = Auditor(runs_dir=tmp_path / "runs")
    executor = Executor(auditor=auditor)
    executor.graph_ops = ops
    ticket = _ticket()
    plan = Planner().build_plan(ticket)
    result = executor.run(ticket=ticket, plan=plan, dry_run=False, approved_actions=set(), operator="tester")
    payload = json.loads(result.run_log_path.read_text(encoding="utf-8"))

    assert payload["steps"][1]["status"] == "skipped"
    assert "Already disabled" in payload["steps"][1]["detail"]
    assert ops.disable_called is False


def test_retries_only_on_retryable_statuses(monkeypatch):
    class FakeResp:
        def __init__(self, status_code, headers=None, text=""):
            self.status_code = status_code
            self.headers = headers or {}
            self.text = text

        def json(self):
            return {}

    ops = RealGraphOperations("dummy-token")
    sleep_calls = []
    monkeypatch.setattr("time.sleep", lambda seconds: sleep_calls.append(seconds))

    responses = [FakeResp(429, headers={"Retry-After": "0"}), FakeResp(200)]
    calls = {"count": 0}

    def retryable_request(**kwargs):
        calls["count"] += 1
        return responses.pop(0)

    monkeypatch.setattr("requests.request", retryable_request)
    _, ev = ops._request("GET", "https://graph.microsoft.com/v1.0/users")
    assert calls["count"] == 2
    assert ev["http_status"] == 200
    assert ev["attempts"] == 2
    assert len(sleep_calls) == 1

    calls["count"] = 0
    sleep_calls.clear()

    def non_retryable_request(**kwargs):
        calls["count"] += 1
        return FakeResp(403, text="forbidden")

    monkeypatch.setattr("requests.request", non_retryable_request)
    _, ev = ops._request("GET", "https://graph.microsoft.com/v1.0/users")
    assert calls["count"] == 1
    assert ev["http_status"] == 403
    assert ev["error_type"] == "PERMISSION_ERROR"
    assert len(sleep_calls) == 0


def test_token_cache_path_loads(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    cache = msal.SerializableTokenCache()
    cache_path = tmp_path / "data" / "token_cache.json"
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    cache_path.write_text(cache.serialize(), encoding="utf-8")

    auth = DeviceCodeAuth(client_id="00000000-0000-0000-0000-000000000000", tenant_id="common")
    assert auth.cache_path.resolve() == cache_path.resolve()
    assert auth.cache_path.exists()


def test_run_stub_created_even_on_auth_failure(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    ticket_dir = tmp_path / "data" / "tickets"
    ticket_dir.mkdir(parents=True, exist_ok=True)
    ticket_path = ticket_dir / "offboard_auth_fail.json"
    ticket_path.write_text(
        json.dumps(
            {
                "ticket_id": "offboard_auth_fail",
                "type": "offboarding",
                "tenant_id": "67aca8ef-69a4-4853-9045-d4c345601d6e",
                "user_email": "john.doe@cryingman121212outlook882.onmicrosoft.com",
            }
        ),
        encoding="utf-8",
    )
    monkeypatch.setenv("MSP_GRAPH_CLIENT_ID", "test-client-id")
    monkeypatch.setenv("MSP_GRAPH_TENANT_ID", "common")
    monkeypatch.setenv("MSP_EXECUTION_ENABLED", "true")
    monkeypatch.setattr(
        "msp_copilot.engine.executor.DeviceCodeAuth.acquire_token",
        lambda self: (_ for _ in ()).throw(Exception("Auth failed: simulated")),
    )

    args = argparse.Namespace(
        ticket=str(ticket_path),
        execute=True,
        approve="",
        operator="tester@example.com",
    )
    rc = cmd_run(args)
    assert rc == 3

    run_logs = list((tmp_path / "data" / "runs").glob("run_*.json"))
    assert run_logs
    payload = json.loads(run_logs[0].read_text(encoding="utf-8"))
    assert payload["status"] == "failed"
    assert payload["error"]["error_type"] == "AUTH_ERROR"


def test_kill_switch_blocks_execute_and_logs_validation_error(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    ticket_dir = tmp_path / "data" / "tickets"
    ticket_dir.mkdir(parents=True, exist_ok=True)
    ticket_path = ticket_dir / "offboard_kill_switch.json"
    ticket_path.write_text(
        json.dumps(
            {
                "ticket_id": "offboard_kill_switch",
                "type": "offboarding",
                "tenant_id": "67aca8ef-69a4-4853-9045-d4c345601d6e",
                "user_email": "john.doe@cryingman121212outlook882.onmicrosoft.com",
            }
        ),
        encoding="utf-8",
    )
    monkeypatch.setenv("MSP_EXECUTION_ENABLED", "false")
    args = argparse.Namespace(ticket=str(ticket_path), execute=True, approve="", operator="tester")
    rc = cmd_run(args)
    assert rc == 2
    run_logs = list((tmp_path / "data" / "runs").glob("run_*.json"))
    assert run_logs
    payload = json.loads(run_logs[0].read_text(encoding="utf-8"))
    assert payload["error"]["error_type"] == "VALIDATION_ERROR"
    assert payload["status"] == "failed"


def test_last_run_command_prints_summary(tmp_path, monkeypatch, capsys):
    monkeypatch.chdir(tmp_path)
    runs = tmp_path / "data" / "runs"
    runs.mkdir(parents=True, exist_ok=True)
    payload = {
        "run_id": "abc",
        "status": "completed",
        "success": True,
        "run_summary.txt": "[OK] find_user",
    }
    (runs / "run_abc.json").write_text(json.dumps(payload), encoding="utf-8")
    rc = cmd_last_run(argparse.Namespace())
    out = capsys.readouterr().out
    assert rc == 0
    assert "run_abc.json" in out
    assert "[OK] find_user" in out


def test_run_log_contains_no_auth_secrets(tmp_path):
    result = _run_with_ops(
        tmp_path,
        MockGraphOperations(),
        approved={"remove_licenses", "convert_mailbox"},
    )
    text = result.run_log_path.read_text(encoding="utf-8")
    lower = text.lower()
    assert "bearer " not in lower
    assert "access_token" not in lower
    assert "authorization" not in lower


def test_error_body_truncated_to_300_chars():
    class FakeResp:
        text = "x" * 1000

    ops = RealGraphOperations("dummy-token")
    assert len(ops._safe_error_body(FakeResp())) == 300
