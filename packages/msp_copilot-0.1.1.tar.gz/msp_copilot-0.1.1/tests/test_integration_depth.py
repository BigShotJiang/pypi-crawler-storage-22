from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import pytest

from msp_copilot.connectors.microsoft_graph.operations import MockGraphOperations
from msp_copilot.connectors.microsoft_graph.real_operations import RealGraphOperations
from msp_copilot.domain.action import Action
from msp_copilot.domain.plan import Plan
from msp_copilot.domain.ticket import Ticket
from msp_copilot.engine.auditor import Auditor
from msp_copilot.engine.executor import Executor


class FakeResponse:
    def __init__(
        self,
        status_code: int,
        json_body: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> None:
        self.status_code = status_code
        self._json_body = json_body or {}
        self.headers = headers or {}
        self.text = json.dumps(self._json_body)

    def json(self) -> dict[str, Any]:
        return self._json_body


def _ticket(**kwargs: Any) -> Ticket:
    base = dict(
        ticket_id="offboard_integration",
        type="offboarding",
        tenant_id="demo-tenant",
        user_email="john.doe@cryingman121212outlook882.onmicrosoft.com",
        remove_sku_ids=("11111111-1111-1111-1111-111111111111",),
    )
    base.update(kwargs)
    return Ticket(**base)


def test_mock_graph_license_and_role_methods() -> None:
    ops = MockGraphOperations(sleep_seconds=0)
    user_id, _ = ops.find_user("doctor@example.com")
    assert user_id

    licenses, _ = ops.get_user_license_details(user_id)
    assert licenses
    ok, _ = ops.assign_licenses(user_id, add_license_ids=[], remove_license_ids=[licenses[0]["skuId"]])
    assert ok
    licenses_after, _ = ops.get_user_license_details(user_id)
    assert len(licenses_after) == len(licenses) - 1

    roles, _ = ops.list_user_directory_roles(user_id)
    assert roles
    ok, _ = ops.remove_directory_role_member(roles[0]["id"], user_id)
    assert ok
    roles_after, _ = ops.list_user_directory_roles(user_id)
    assert len(roles_after) == len(roles) - 1


def test_real_graph_operations_license_and_role_endpoints() -> None:
    calls: list[tuple[str, str]] = []

    def request_fn(**kwargs: Any) -> FakeResponse:
        method = kwargs["method"]
        url = kwargs["url"]
        calls.append((method, url))
        if method == "GET" and url.endswith("/licenseDetails"):
            return FakeResponse(
                200,
                {
                    "value": [
                        {"skuId": "11111111-1111-1111-1111-111111111111", "skuPartNumber": "M365_BUSINESS_STANDARD"},
                    ]
                },
            )
        if method == "POST" and url.endswith("/assignLicense"):
            return FakeResponse(200, {"value": []})
        if method == "GET" and "/memberOf" in url:
            return FakeResponse(
                200,
                {
                    "value": [
                        {"@odata.type": "#microsoft.graph.directoryRole", "id": "role-1", "displayName": "Global Administrator"},
                        {"@odata.type": "#microsoft.graph.group", "id": "group-1", "displayName": "Some Group"},
                    ]
                },
            )
        if method == "DELETE" and "/directoryRoles/role-1/members/user-1/$ref" in url:
            return FakeResponse(204, {})
        return FakeResponse(404, {"error": "not found"})

    ops = RealGraphOperations("token", request_fn=request_fn, sleep_fn=lambda seconds: None)
    licenses, ev = ops.get_user_license_details("user-1")
    assert ev["http_status"] == 200
    assert licenses[0]["skuPartNumber"] == "M365_BUSINESS_STANDARD"

    ok, ev = ops.assign_licenses(
        "user-1",
        add_license_ids=[],
        remove_license_ids=["11111111-1111-1111-1111-111111111111"],
    )
    assert ok is True
    assert ev["removed_count"] == 1

    roles, ev = ops.list_user_directory_roles("user-1")
    assert ev["count"] == 1
    assert roles[0]["id"] == "role-1"

    ok, ev = ops.remove_directory_role_member("role-1", "user-1")
    assert ok is True
    assert ev["http_status"] == 204

    assert any(url.endswith("/assignLicense") for _, url in calls)


def test_real_graph_operations_onboarding_endpoints() -> None:
    def request_fn(**kwargs: Any) -> FakeResponse:
        method = kwargs["method"]
        url = kwargs["url"]
        if method == "PATCH" and url.endswith("/users/user-1"):
            return FakeResponse(204, {})
        if method == "GET" and "usageLocation" in url:
            return FakeResponse(200, {"usageLocation": "US"})
        if method == "GET" and "passwordProfile" in url:
            return FakeResponse(200, {"passwordProfile": {"forceChangePasswordNextSignIn": True}})
        if method == "GET" and "/memberOf" in url:
            return FakeResponse(
                200,
                {
                    "value": [
                        {"@odata.type": "#microsoft.graph.group", "id": "group-1"},
                        {"@odata.type": "#microsoft.graph.directoryRole", "id": "role-1"},
                    ]
                },
            )
        if method == "POST" and "/groups/group-2/members/$ref" in url:
            return FakeResponse(204, {})
        return FakeResponse(404, {})

    ops = RealGraphOperations("token", request_fn=request_fn, sleep_fn=lambda seconds: None)
    ok, _ = ops.enable_sign_in("user-1")
    assert ok is True

    usage, _ = ops.get_user_usage_location("user-1")
    assert usage == "US"
    ok, _ = ops.set_user_usage_location("user-1", "CA")
    assert ok is True

    group_ids, _ = ops.list_user_group_ids("user-1")
    assert group_ids == ["group-1"]
    ok, _ = ops.add_user_to_group("user-1", "group-2")
    assert ok is True

    required, _ = ops.get_user_force_password_reset("user-1")
    assert required is True
    ok, _ = ops.set_user_force_password_reset("user-1", True)
    assert ok is True


def test_executor_remove_licenses_and_roles_realistic_with_mock(tmp_path: Path) -> None:
    auditor = Auditor(runs_dir=tmp_path / "runs")
    executor = Executor(auditor=auditor)
    executor.graph_ops = MockGraphOperations(sleep_seconds=0)
    plan = Plan(
        actions=[
            Action("find_user"),
            Action("remove_admin_roles"),
            Action("remove_licenses", requires_approval=True),
        ]
    )

    result = executor.run(
        ticket=_ticket(),
        plan=plan,
        dry_run=False,
        approved_actions={"remove_licenses"},
        operator="tester@example.com",
    )
    payload = json.loads(result.run_log_path.read_text(encoding="utf-8"))
    assert payload["success"] is True
    assert payload["steps"][1]["status"] == "completed"
    assert payload["steps"][2]["status"] == "completed"
    assert payload["steps"][2]["evidence"]["removed_sku_ids"]
    assert payload["steps"][2]["evidence"]["compensation"]["addLicenses"]


def test_executor_remove_licenses_requires_explicit_targets(tmp_path: Path) -> None:
    auditor = Auditor(runs_dir=tmp_path / "runs")
    executor = Executor(auditor=auditor)
    executor.graph_ops = MockGraphOperations(sleep_seconds=0)
    plan = Plan(actions=[Action("find_user"), Action("remove_licenses", requires_approval=True)])

    result = executor.run(
        ticket=_ticket(remove_sku_ids=()),
        plan=plan,
        dry_run=False,
        approved_actions={"remove_licenses"},
        operator="tester@example.com",
    )
    payload = json.loads(result.run_log_path.read_text(encoding="utf-8"))
    assert payload["success"] is False
    assert payload["steps"][1]["status"] == "failed"
    assert "requires explicit remove_sku_ids" in payload["steps"][1]["detail"]


def test_executor_convert_mailbox_with_pwsh_subprocess_mode(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    auditor = Auditor(runs_dir=tmp_path / "runs")
    executor = Executor(auditor=auditor)
    executor.graph_ops = MockGraphOperations(sleep_seconds=0)
    monkeypatch.setenv("MSP_EXCHANGE_REAL", "true")

    responses = iter(
        [
            (True, {"stdout": '"UserMailbox"', "stderr": "", "return_code": 0}),
            (True, {"stdout": "", "stderr": "", "return_code": 0}),
            (True, {"stdout": '"SharedMailbox"', "stderr": "", "return_code": 0}),
        ]
    )
    monkeypatch.setattr(executor, "_run_pwsh", lambda script: next(responses))

    plan = Plan(actions=[Action("find_user"), Action("convert_mailbox", requires_approval=True)])
    result = executor.run(
        ticket=_ticket(),
        plan=plan,
        dry_run=False,
        approved_actions={"convert_mailbox"},
        operator="tester@example.com",
    )
    payload = json.loads(result.run_log_path.read_text(encoding="utf-8"))
    assert payload["success"] is True
    assert payload["steps"][1]["status"] == "completed"


def test_executor_convert_mailbox_skips_when_already_shared(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    auditor = Auditor(runs_dir=tmp_path / "runs")
    executor = Executor(auditor=auditor)
    executor.graph_ops = MockGraphOperations(sleep_seconds=0)
    monkeypatch.setenv("MSP_EXCHANGE_REAL", "true")
    monkeypatch.setattr(
        executor,
        "_run_pwsh",
        lambda script: (True, {"stdout": '"SharedMailbox"', "stderr": "", "return_code": 0}),
    )

    plan = Plan(actions=[Action("find_user"), Action("convert_mailbox", requires_approval=True)])
    result = executor.run(
        ticket=_ticket(),
        plan=plan,
        dry_run=False,
        approved_actions={"convert_mailbox"},
        operator="tester@example.com",
    )
    payload = json.loads(result.run_log_path.read_text(encoding="utf-8"))
    assert payload["success"] is True
    assert payload["steps"][1]["status"] == "skipped"
