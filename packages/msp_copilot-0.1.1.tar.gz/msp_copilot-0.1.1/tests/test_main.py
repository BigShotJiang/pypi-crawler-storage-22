import argparse
import json
from datetime import datetime, timezone

import pytest

from msp_copilot.config.settings import RuntimeSettings
from msp_copilot.errors import ValidationFailure
from msp_copilot.main import (
    EXIT_AUTH,
    EXIT_FAILED,
    EXIT_PERMISSION,
    EXIT_SUCCESS,
    EXIT_VALIDATION,
    build_parser,
    cmd_doctor,
    cmd_explain,
    cmd_plan,
    cmd_run,
    cmd_validate,
)


def _write_ticket(path):
    path.write_text(
        json.dumps(
            {
                "ticket_id": "offboard_test",
                "type": "offboarding",
                "tenant_id": "67aca8ef-69a4-4853-9045-d4c345601d6e",
                "user_email": "john.doe@cryingman121212outlook882.onmicrosoft.com",
                "remove_sku_ids": ["11111111-1111-1111-1111-111111111111"],
            }
        ),
        encoding="utf-8",
    )


def test_runtime_settings_resolve_tenant_guid(monkeypatch):
    guid = "67aca8ef-69a4-4853-9045-d4c345601d6e"
    assert RuntimeSettings.resolve_tenant_guid(guid) == guid

    monkeypatch.setenv("MSP_TENANT_ALIAS_demo", guid)
    assert RuntimeSettings.resolve_tenant_guid("demo") == guid


def test_runtime_settings_rejects_unknown_alias(monkeypatch):
    monkeypatch.delenv("MSP_TENANT_ALIAS_unknown", raising=False)
    with pytest.raises(ValidationFailure):
        RuntimeSettings.resolve_tenant_guid("unknown")


def test_cmd_run_returns_runtime_exit_for_unexpected_error(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    ticket_dir = tmp_path / "data" / "tickets"
    ticket_dir.mkdir(parents=True, exist_ok=True)
    ticket_path = ticket_dir / "offboard_runtime_fail.json"
    _write_ticket(ticket_path)

    monkeypatch.setenv("MSP_EXECUTION_ENABLED", "false")
    monkeypatch.setattr(
        "msp_copilot.engine.planner.Planner.build_plan",
        lambda self, ticket: (_ for _ in ()).throw(RuntimeError("boom")),
    )

    args = argparse.Namespace(ticket=str(ticket_path), execute=False, approve="", operator="tester")
    rc = cmd_run(args)
    assert rc == EXIT_FAILED
    run_logs = list((tmp_path / "data" / "runs").glob("run_*.json"))
    assert run_logs
    payload = json.loads(run_logs[0].read_text(encoding="utf-8"))
    assert payload["error"]["error_type"] == "RUNTIME_ERROR"


def test_cmd_run_invalid_json_returns_validation_exit(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    ticket_dir = tmp_path / "data" / "tickets"
    ticket_dir.mkdir(parents=True, exist_ok=True)
    ticket_path = ticket_dir / "bad.json"
    ticket_path.write_text("{", encoding="utf-8")

    args = argparse.Namespace(ticket=str(ticket_path), execute=False, approve="", operator="tester")
    rc = cmd_run(args)
    assert rc == EXIT_VALIDATION


def test_build_parser_has_required_subcommands():
    parser = build_parser()
    args = parser.parse_args(["last-run"])
    assert args.command == "last-run"
    assert callable(args.func)

    args = parser.parse_args(["explain", "offboarding"])
    assert args.command == "explain"
    assert callable(args.func)

    args = parser.parse_args(["validate", "--ticket", "x.json"])
    assert args.command == "validate"
    assert callable(args.func)

    args = parser.parse_args(["plan", "--ticket", "x.json"])
    assert args.command == "plan"
    assert callable(args.func)

    args = parser.parse_args(["doctor"])
    assert args.command == "doctor"
    assert callable(args.func)


def test_dry_run_does_not_attempt_real_auth(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    ticket_dir = tmp_path / "data" / "tickets"
    ticket_dir.mkdir(parents=True, exist_ok=True)
    ticket_path = ticket_dir / "dry_run_auth_guard.json"
    _write_ticket(ticket_path)

    monkeypatch.setenv("MSP_GRAPH_CLIENT_ID", "configured")
    monkeypatch.setenv("MSP_GRAPH_TENANT_ID", "common")
    monkeypatch.setenv(
        "MSP_TENANT_ALIAS_67aca8ef_69a4_4853_9045_d4c345601d6e",
        "67aca8ef-69a4-4853-9045-d4c345601d6e",
    )
    monkeypatch.setattr(
        "msp_copilot.connectors.microsoft_graph.auth.DeviceCodeAuth.acquire_token",
        lambda self: (_ for _ in ()).throw(AssertionError("should not acquire token in dry-run")),
    )

    args = argparse.Namespace(ticket=str(ticket_path), execute=False, approve="", operator="tester")
    rc = cmd_run(args)
    assert rc == 0


def test_cmd_run_uses_freezable_clock_for_run_timestamps(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    ticket_dir = tmp_path / "data" / "tickets"
    ticket_dir.mkdir(parents=True, exist_ok=True)
    ticket_path = ticket_dir / "clock_freeze.json"
    _write_ticket(ticket_path)

    now_values = iter(
        [
            datetime(2026, 2, 11, 0, 0, 0, tzinfo=timezone.utc),
            datetime(2026, 2, 11, 0, 0, 5, tzinfo=timezone.utc),
        ]
    )
    monkeypatch.setattr("msp_copilot.main._utc_now", lambda: next(now_values))
    monkeypatch.setattr(
        "msp_copilot.engine.planner.Planner.build_plan",
        lambda self, ticket: (_ for _ in ()).throw(RuntimeError("boom")),
    )

    args = argparse.Namespace(ticket=str(ticket_path), execute=False, approve="", operator="tester")
    rc = cmd_run(args)
    assert rc == EXIT_FAILED

    run_logs = list((tmp_path / "data" / "runs").glob("run_*.json"))
    assert run_logs
    payload = json.loads(run_logs[0].read_text(encoding="utf-8"))
    assert payload["started_at"] == "2026-02-11T00:00:00+00:00"
    assert payload["completed_at"] == "2026-02-11T00:00:05+00:00"
    assert payload["duration_seconds"] == 5.0


def test_cmd_explain_prints_workflow_metadata(capsys):
    rc = cmd_explain(argparse.Namespace(workflow="offboarding"))
    out = capsys.readouterr().out
    assert rc == EXIT_SUCCESS
    assert "find_user" in out
    assert "touches=" in out


def test_cmd_validate_runs_without_writes(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    ticket_dir = tmp_path / "data" / "tickets"
    ticket_dir.mkdir(parents=True, exist_ok=True)
    ticket_path = ticket_dir / "validate.json"
    _write_ticket(ticket_path)

    args = argparse.Namespace(
        ticket=str(ticket_path),
        confirm_tenant="",
        confirm_user="",
    )
    rc = cmd_validate(args)
    assert rc == EXIT_SUCCESS
    run_logs = list((tmp_path / "data" / "runs").glob("run_*.json"))
    assert run_logs == []


def test_cmd_plan_marks_unapproved_actions_as_blocked(tmp_path, monkeypatch, capsys):
    monkeypatch.chdir(tmp_path)
    ticket_dir = tmp_path / "data" / "tickets"
    ticket_dir.mkdir(parents=True, exist_ok=True)
    ticket_path = ticket_dir / "plan.json"
    _write_ticket(ticket_path)

    args = argparse.Namespace(
        ticket=str(ticket_path),
        approve="",
        confirm_tenant="",
        confirm_user="",
    )
    rc = cmd_plan(args)
    out = capsys.readouterr().out
    assert rc == EXIT_SUCCESS
    assert "remove_licenses" in out
    assert "would_block" in out


def test_cmd_doctor_json_without_graph_config_returns_success(monkeypatch, capsys):
    monkeypatch.delenv("MSP_GRAPH_CLIENT_ID", raising=False)
    monkeypatch.delenv("MSP_GRAPH_TENANT_ID", raising=False)
    monkeypatch.delenv("MSP_DOCTOR_TEST_USER", raising=False)

    args = argparse.Namespace(
        tenant="",
        test_user="",
        verbose=False,
        json_output=True,
    )
    rc = cmd_doctor(args)
    out = capsys.readouterr().out
    payload = json.loads(out)

    assert rc == EXIT_SUCCESS
    assert payload["ok"] is True
    assert any(check["name"] == "graph_config" for check in payload["checks"])


def test_cmd_doctor_bad_tenant_alias_returns_validation(monkeypatch):
    monkeypatch.delenv("MSP_TENANT_ALIAS_missing", raising=False)
    args = argparse.Namespace(
        tenant="missing",
        test_user="",
        verbose=False,
        json_output=False,
    )
    rc = cmd_doctor(args)
    assert rc == EXIT_VALIDATION


def test_cmd_doctor_graph_happy_path_verbose(tmp_path, monkeypatch, capsys):
    monkeypatch.chdir(tmp_path)
    token_cache = tmp_path / "data" / "token_cache.json"
    token_cache.parent.mkdir(parents=True, exist_ok=True)
    token_cache.write_text("{}", encoding="utf-8")

    monkeypatch.setenv("MSP_EXECUTION_ENABLED", "true")
    monkeypatch.setenv("MSP_GRAPH_CLIENT_ID", "client")
    monkeypatch.setenv("MSP_GRAPH_TENANT_ID", "common")
    monkeypatch.setenv("MSP_DOCTOR_TEST_USER", "doctor@example.com")

    class FakeAuth:
        def __init__(self, client_id: str, tenant_id: str) -> None:
            _ = (client_id, tenant_id)

        def acquire_token(self) -> str:
            return "token"

    class FakeOps:
        def __init__(self, token: str) -> None:
            _ = token

        def get_organization_tenant_id(self):
            return "67aca8ef-69a4-4853-9045-d4c345601d6e", {"http_status": 200}

        def find_user(self, email: str):
            _ = email
            return "uid-123", {"http_status": 200}

    monkeypatch.setattr("msp_copilot.main.DeviceCodeAuth", FakeAuth)
    monkeypatch.setattr("msp_copilot.main.RealGraphOperations", FakeOps)

    args = argparse.Namespace(
        tenant="67aca8ef-69a4-4853-9045-d4c345601d6e",
        test_user="",
        verbose=True,
        json_output=False,
    )
    rc = cmd_doctor(args)
    out = capsys.readouterr().out

    assert rc == EXIT_SUCCESS
    assert "[OK] graph_auth" in out
    assert "[OK] graph_org_lookup" in out
    assert "[OK] graph_test_user_lookup" in out
    assert "details=" in out


def test_cmd_doctor_auth_failure_returns_auth_exit(monkeypatch, capsys):
    monkeypatch.setenv("MSP_GRAPH_CLIENT_ID", "client")
    monkeypatch.setenv("MSP_GRAPH_TENANT_ID", "common")

    class FailingAuth:
        def __init__(self, client_id: str, tenant_id: str) -> None:
            _ = (client_id, tenant_id)

        def acquire_token(self) -> str:
            raise Exception("Auth failed in test")

    monkeypatch.setattr("msp_copilot.main.DeviceCodeAuth", FailingAuth)

    args = argparse.Namespace(
        tenant="",
        test_user="user@example.com",
        verbose=False,
        json_output=True,
    )
    rc = cmd_doctor(args)
    out = capsys.readouterr().out
    payload = json.loads(out)

    assert rc == EXIT_AUTH
    assert payload["ok"] is False
    auth_check = next(check for check in payload["checks"] if check["name"] == "graph_auth")
    assert auth_check["status"] == "fail"


def test_cmd_doctor_org_lookup_permission_failure(monkeypatch):
    monkeypatch.setenv("MSP_GRAPH_CLIENT_ID", "client")
    monkeypatch.setenv("MSP_GRAPH_TENANT_ID", "common")

    class FakeAuth:
        def __init__(self, client_id: str, tenant_id: str) -> None:
            _ = (client_id, tenant_id)

        def acquire_token(self) -> str:
            return "token"

    class PermissionOps:
        def __init__(self, token: str) -> None:
            _ = token

        def get_organization_tenant_id(self):
            return None, {"http_status": 403, "error_type": "PERMISSION_ERROR", "retryable": False}

        def find_user(self, email: str):
            _ = email
            return None, {"http_status": 404, "error_type": "NOT_FOUND", "retryable": False}

    monkeypatch.setattr("msp_copilot.main.DeviceCodeAuth", FakeAuth)
    monkeypatch.setattr("msp_copilot.main.RealGraphOperations", PermissionOps)

    args = argparse.Namespace(
        tenant="",
        test_user="doctor@example.com",
        verbose=False,
        json_output=False,
    )
    rc = cmd_doctor(args)
    assert rc == EXIT_PERMISSION
