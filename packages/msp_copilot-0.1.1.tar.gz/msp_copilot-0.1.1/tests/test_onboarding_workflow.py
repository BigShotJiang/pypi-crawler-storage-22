from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from msp_copilot.connectors.microsoft_graph.operations import MockGraphOperations
from msp_copilot.domain.ticket import Ticket
from msp_copilot.engine.auditor import Auditor
from msp_copilot.engine.executor import Executor
from msp_copilot.engine.planner import Planner


def _onboard_ticket(
    *,
    add_sku_ids: tuple[str, ...] = ("99999999-9999-9999-9999-999999999999",),
    add_group_ids: tuple[str, ...] = ("33333333-3333-3333-3333-333333333333",),
    usage_location: str | None = "CA",
    require_password_reset: bool = True,
) -> Ticket:
    return Ticket(
        ticket_id="onboard_001",
        type="onboarding",
        tenant_id="demo-tenant",
        user_email="john.doe@cryingman121212outlook882.onmicrosoft.com",
        add_sku_ids=add_sku_ids,
        add_group_ids=add_group_ids,
        usage_location=usage_location,
        require_password_reset=require_password_reset,
    )


def test_planner_builds_onboarding_plan_with_license_approval() -> None:
    plan = Planner().build_plan(_onboard_ticket())
    names = [action.name for action in plan.actions]
    assert names == [
        "find_user",
        "ensure_sign_in_enabled",
        "set_usage_location",
        "assign_licenses",
        "add_to_groups",
        "require_password_reset",
    ]
    assign_step = [a for a in plan.actions if a.name == "assign_licenses"][0]
    assert assign_step.requires_approval is True


def test_onboarding_executes_successfully_with_required_approval(tmp_path: Path) -> None:
    auditor = Auditor(runs_dir=tmp_path / "runs")
    executor = Executor(auditor=auditor)
    executor.graph_ops = MockGraphOperations(sleep_seconds=0)
    ticket = _onboard_ticket()
    plan = Planner().build_plan(ticket)

    result = executor.run(
        ticket=ticket,
        plan=plan,
        dry_run=False,
        approved_actions={"assign_licenses"},
        operator="tester@example.com",
    )
    payload = json.loads(result.run_log_path.read_text(encoding="utf-8"))

    assert payload["success"] is True
    statuses = {step["action"]: step["status"] for step in payload["steps"]}
    assert statuses["assign_licenses"] == "completed"
    assert statuses["add_to_groups"] == "completed"
    assert statuses["require_password_reset"] == "completed"


def test_onboarding_assign_licenses_requires_explicit_add_sku_ids(tmp_path: Path) -> None:
    auditor = Auditor(runs_dir=tmp_path / "runs")
    executor = Executor(auditor=auditor)
    executor.graph_ops = MockGraphOperations(sleep_seconds=0)
    ticket = _onboard_ticket(add_sku_ids=())
    plan = Planner().build_plan(ticket)

    result = executor.run(
        ticket=ticket,
        plan=plan,
        dry_run=False,
        approved_actions={"assign_licenses"},
        operator="tester@example.com",
    )
    payload = json.loads(result.run_log_path.read_text(encoding="utf-8"))

    assert payload["success"] is False
    assign_step = [step for step in payload["steps"] if step["action"] == "assign_licenses"][0]
    assert assign_step["status"] == "failed"
    assert "requires explicit add_sku_ids" in assign_step["detail"]


def test_onboarding_password_reset_optional_skip(tmp_path: Path) -> None:
    auditor = Auditor(runs_dir=tmp_path / "runs")
    executor = Executor(auditor=auditor)
    executor.graph_ops = MockGraphOperations(sleep_seconds=0)
    ticket = _onboard_ticket(require_password_reset=False)
    plan = Planner().build_plan(ticket)

    result = executor.run(
        ticket=ticket,
        plan=plan,
        dry_run=False,
        approved_actions={"assign_licenses"},
        operator="tester@example.com",
    )
    payload = json.loads(result.run_log_path.read_text(encoding="utf-8"))
    step = [s for s in payload["steps"] if s["action"] == "require_password_reset"][0]
    assert step["status"] == "skipped"


class OnboardingOps:
    def __init__(
        self,
        *,
        enabled: bool = False,
        usage_location: str | None = None,
        assigned_skus: list[str] | None = None,
        groups: list[str] | None = None,
        force_password_reset: bool = False,
        fail_group_add: bool = False,
    ) -> None:
        self.enabled = enabled
        self.usage_location = usage_location
        self.assigned_skus = set(assigned_skus or [])
        self.groups = set(groups or [])
        self.force_password_reset = force_password_reset
        self.fail_group_add = fail_group_add

    def get_organization_tenant_id(self) -> tuple[str | None, dict[str, Any]]:
        return "demo-tenant", {"http_status": 200}

    def find_user(self, email: str) -> tuple[str | None, dict[str, Any]]:
        _ = email
        return "uid-1", {"http_status": 200}

    def get_user_profile(self, user_id: str) -> tuple[dict[str, Any] | None, dict[str, Any]]:
        return {"id": user_id, "userPrincipalName": "john.doe@cryingman121212outlook882.onmicrosoft.com"}, {"http_status": 200}

    def get_user_account_enabled(self, user_id: str) -> tuple[bool | None, dict[str, Any]]:
        _ = user_id
        return self.enabled, {"http_status": 200, "accountEnabled": self.enabled}

    def enable_sign_in(self, user_id: str) -> tuple[bool, dict[str, Any]]:
        _ = user_id
        self.enabled = True
        return True, {"http_status": 204}

    def get_user_usage_location(self, user_id: str) -> tuple[str | None, dict[str, Any]]:
        _ = user_id
        return self.usage_location, {"http_status": 200}

    def set_user_usage_location(self, user_id: str, usage_location: str) -> tuple[bool, dict[str, Any]]:
        _ = user_id
        self.usage_location = usage_location
        return True, {"http_status": 204}

    def get_user_license_details(self, user_id: str) -> tuple[list[dict[str, Any]], dict[str, Any]]:
        _ = user_id
        details = [{"skuId": sku_id, "skuPartNumber": sku_id} for sku_id in sorted(list(self.assigned_skus))]
        return details, {"http_status": 200}

    def assign_licenses(
        self,
        user_id: str,
        add_license_ids: list[str],
        remove_license_ids: list[str],
    ) -> tuple[bool, dict[str, Any]]:
        _ = user_id
        self.assigned_skus.difference_update(remove_license_ids)
        self.assigned_skus.update(add_license_ids)
        return True, {"http_status": 200}

    def list_user_group_ids(self, user_id: str) -> tuple[list[str], dict[str, Any]]:
        _ = user_id
        return sorted(list(self.groups)), {"http_status": 200}

    def add_user_to_group(self, user_id: str, group_id: str) -> tuple[bool, dict[str, Any]]:
        _ = user_id
        if self.fail_group_add:
            return False, {"http_status": 503, "error_type": "TRANSIENT", "retryable": True}
        self.groups.add(group_id)
        return True, {"http_status": 204}

    def get_user_force_password_reset(self, user_id: str) -> tuple[bool | None, dict[str, Any]]:
        _ = user_id
        return self.force_password_reset, {"http_status": 200}

    def set_user_force_password_reset(self, user_id: str, required: bool) -> tuple[bool, dict[str, Any]]:
        _ = user_id
        self.force_password_reset = required
        return True, {"http_status": 204}


def test_onboarding_branch_matrix_success(tmp_path: Path) -> None:
    auditor = Auditor(runs_dir=tmp_path / "runs")
    executor = Executor(auditor=auditor)
    executor.graph_ops = OnboardingOps()
    ticket = _onboard_ticket(
        add_sku_ids=("aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa",),
        add_group_ids=("bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb",),
        usage_location="GB",
        require_password_reset=True,
    )
    plan = Planner().build_plan(ticket)
    result = executor.run(
        ticket=ticket,
        plan=plan,
        dry_run=False,
        approved_actions={"assign_licenses"},
        operator="tester@example.com",
    )
    payload = json.loads(result.run_log_path.read_text(encoding="utf-8"))
    assert payload["success"] is True
    assert all(step["status"] in {"completed", "skipped"} for step in payload["steps"])


def test_onboarding_branch_matrix_skip(tmp_path: Path) -> None:
    auditor = Auditor(runs_dir=tmp_path / "runs")
    executor = Executor(auditor=auditor)
    executor.graph_ops = OnboardingOps(
        enabled=True,
        usage_location="US",
        assigned_skus=["cccccccc-cccc-cccc-cccc-cccccccccccc"],
        groups=["dddddddd-dddd-dddd-dddd-dddddddddddd"],
        force_password_reset=True,
    )
    ticket = _onboard_ticket(
        add_sku_ids=("cccccccc-cccc-cccc-cccc-cccccccccccc",),
        add_group_ids=("dddddddd-dddd-dddd-dddd-dddddddddddd",),
        usage_location="US",
        require_password_reset=True,
    )
    plan = Planner().build_plan(ticket)
    result = executor.run(
        ticket=ticket,
        plan=plan,
        dry_run=False,
        approved_actions={"assign_licenses"},
        operator="tester@example.com",
    )
    payload = json.loads(result.run_log_path.read_text(encoding="utf-8"))
    statuses = {step["action"]: step["status"] for step in payload["steps"]}
    assert statuses["ensure_sign_in_enabled"] == "skipped"
    assert statuses["set_usage_location"] == "skipped"
    assert statuses["assign_licenses"] == "skipped"
    assert statuses["add_to_groups"] == "skipped"
    assert statuses["require_password_reset"] == "skipped"


def test_onboarding_add_to_groups_failure(tmp_path: Path) -> None:
    auditor = Auditor(runs_dir=tmp_path / "runs")
    executor = Executor(auditor=auditor)
    executor.graph_ops = OnboardingOps(fail_group_add=True)
    ticket = _onboard_ticket(
        add_sku_ids=("eeeeeeee-eeee-eeee-eeee-eeeeeeeeeeee",),
        add_group_ids=("ffffffff-ffff-ffff-ffff-ffffffffffff",),
        require_password_reset=False,
    )
    plan = Planner().build_plan(ticket)
    result = executor.run(
        ticket=ticket,
        plan=plan,
        dry_run=False,
        approved_actions={"assign_licenses"},
        operator="tester@example.com",
    )
    payload = json.loads(result.run_log_path.read_text(encoding="utf-8"))
    assert payload["success"] is False
    step = [s for s in payload["steps"] if s["action"] == "add_to_groups"][0]
    assert step["status"] == "failed"


def test_onboarding_invalid_usage_location_fails(tmp_path: Path) -> None:
    auditor = Auditor(runs_dir=tmp_path / "runs")
    executor = Executor(auditor=auditor)
    executor.graph_ops = OnboardingOps()
    ticket = _onboard_ticket(usage_location="USA")
    plan = Planner().build_plan(ticket)
    result = executor.run(
        ticket=ticket,
        plan=plan,
        dry_run=False,
        approved_actions={"assign_licenses"},
        operator="tester@example.com",
    )
    payload = json.loads(result.run_log_path.read_text(encoding="utf-8"))
    assert payload["success"] is False
    step = [s for s in payload["steps"] if s["action"] == "set_usage_location"][0]
    assert step["status"] == "failed"
