import pytest

from msp_copilot.domain.ticket import Ticket
from msp_copilot.engine.planner import Planner


def test_planner_unsupported_ticket_type_message_contains_type() -> None:
    planner = Planner()
    ticket = Ticket(
        ticket_id="t100",
        type="nope-type",
        tenant_id="demo",
        user_email="john@example.com",
    )

    with pytest.raises(ValueError) as exc:
        planner.build_plan(ticket)

    assert "nope-type" in str(exc.value)
