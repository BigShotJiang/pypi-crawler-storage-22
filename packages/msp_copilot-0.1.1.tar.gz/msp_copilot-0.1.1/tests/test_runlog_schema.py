from __future__ import annotations

import json
from pathlib import Path

import pytest
from pydantic import ValidationError

from msp_copilot.engine.auditor import Auditor
from msp_copilot.storage.models import RunLog


def _base_payload() -> dict:
    return {
        "run_schema_version": 1,
        "run_id": "run-1",
        "started_at": "2026-02-11T00:00:00+00:00",
        "completed_at": "2026-02-11T00:00:01+00:00",
        "duration_seconds": 1.0,
        "ticket": {
            "ticket_id": "offboard_1",
            "type": "offboarding",
            "tenant_id": "demo-tenant",
            "user_email": "john@example.com",
        },
        "dry_run": False,
        "operator": "tester@example.com",
        "run_version": "0.0.1",
        "git_commit": "abc123",
        "approved_actions": [],
        "resolved_tenant_id": None,
        "resolved_user_id": None,
        "resolved_user_principal_name": None,
        "steps": [
            {
                "step": 1,
                "action": "find_user",
                "status": "completed",
                "detail": "",
                "started_at": "2026-02-11T00:00:00+00:00",
                "ended_at": "2026-02-11T00:00:01+00:00",
                "requires_approval": False,
                "evidence": {"Authorization": "Bearer abc.def.ghi", "ok": True},
            }
        ],
        "success": True,
        "status": "completed",
        "error": None,
        "run_summary.txt": "[OK] find_user",
    }


def test_auditor_validates_and_redacts(tmp_path: Path) -> None:
    auditor = Auditor(runs_dir=tmp_path / "runs")
    payload = _base_payload()
    path = auditor.create_run("run-1", payload)
    saved = json.loads(path.read_text(encoding="utf-8"))

    assert saved["run_schema_version"] == 1
    assert saved["steps"][0]["evidence"]["Authorization"] == "[REDACTED]"


def test_schema_rejects_invalid_success_contract(tmp_path: Path) -> None:
    auditor = Auditor(runs_dir=tmp_path / "runs")
    payload = _base_payload()
    payload["steps"][0]["status"] = "failed"
    payload["success"] = True
    payload["status"] = "completed"

    with pytest.raises(ValidationError):
        auditor.create_run("run-1", payload)


def test_auditor_writes_pretty_json(tmp_path: Path) -> None:
    auditor = Auditor(runs_dir=tmp_path / "runs")
    payload = _base_payload()

    out_path = auditor.write_run_log(payload)
    text = out_path.read_text(encoding="utf-8")

    assert "\n" in text
    assert "\n  " in text
    json.loads(text)


def test_auditor_create_run_writes_pretty_json(tmp_path: Path) -> None:
    auditor = Auditor(runs_dir=tmp_path / "runs")
    payload = _base_payload()

    out_path = auditor.create_run("run-1", payload)
    text = out_path.read_text(encoding="utf-8")

    assert "\n" in text
    assert "\n  " in text
    json.loads(text)


def test_runlog_v1_golden_fixture_parses() -> None:
    fixture_path = Path("tests/fixtures/run_v1_sanitized.json")
    run_log = RunLog.model_validate_json(fixture_path.read_text(encoding="utf-8"))
    assert run_log.run_schema_version == 1
    assert run_log.status == "completed"
