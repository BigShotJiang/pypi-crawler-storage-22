import argparse
from .theory import calculate_theory
from .practical import calculate_practical
from .subjects import subjects
from .students import students
from .timetable import (
    get_today_timetable,
    get_tomorrow_timetable,
    get_day_timetable,
    get_day_order,
    is_working_day,
)
from datetime import datetime



def main():
    parser = argparse.ArgumentParser(prog="mss")
    subparsers = parser.add_subparsers(dest="command")

    # Theory calculator
    theory_parser = subparsers.add_parser("theory")
    theory_parser.add_argument("--t1", type=float)
    theory_parser.add_argument("--t2", type=float)
    theory_parser.add_argument("--att", type=float)
    theory_parser.add_argument("--sit1", type=float)
    theory_parser.add_argument("--sit2", type=float)

    # Practical calculator
    practical_parser = subparsers.add_parser("practical")
    practical_parser.add_argument("--t1", type=float)
    practical_parser.add_argument("--t2", type=float)
    practical_parser.add_argument("--exp", type=float)
    practical_parser.add_argument("--rec", type=float)

        # Single student lookup
    student_parser = subparsers.add_parser("student")
    student_parser.add_argument("roll")

    # List all students
    subparsers.add_parser("students")


    # Subject lookup
    subject_parser = subparsers.add_parser("subject")
    subject_parser.add_argument("code")

    # Timetable commands
    timetable_today = subparsers.add_parser("today", help="Show today's timetable")
    timetable_tomorrow = subparsers.add_parser("tomorrow", help="Show tomorrow's timetable")
    timetable_day = subparsers.add_parser("day", help="Show timetable for a specific day order")
    timetable_day.add_argument("day_order", type=int, help="Day order (1-6)")

    args = parser.parse_args()

    if args.command == "theory":
        result = calculate_theory(args.t1, args.t2, args.att, args.sit1, args.sit2)
        print(f"Theory Internal = {result} / 25")

    elif args.command == "practical":
        result = calculate_practical(args.t1, args.t2, args.exp, args.rec)
        print(f"Practical Internal = {result} / 40")

    elif args.command == "subject":
        code = args.code.upper()
        if code in subjects:
            name, faculty = subjects[code]
            print(f"{code} - {name}")
            print(f"Faculty: {faculty}")
        else:
            print("Subject not found")

    elif args.command == "student":
        roll = args.roll.upper()
        if roll in students:
            print(f"Roll No : {roll}")
            print(f"Name    : {students[roll]}")
        else:
            print("Student not found")

    elif args.command == "students":
        for roll, name in students.items():
            print(f"{roll} - {name}")

    elif args.command == "today":
        print(get_today_timetable())

    elif args.command == "tomorrow":
        print(get_tomorrow_timetable())

    elif args.command == "day":
        try:
            print(get_day_timetable(args.day_order))
        except ValueError as e:
            print(f"Error: {e}")
