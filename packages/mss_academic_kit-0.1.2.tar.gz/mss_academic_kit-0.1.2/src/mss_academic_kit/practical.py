def calculate_practical(test1, test2, experiment, record):
    total = test1 + test2 + experiment + record
    return total
