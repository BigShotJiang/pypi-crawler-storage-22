subjects = {
    "23SSP634": ("Machine Learning", "Dr. A. Subhashini (AS)"),
    "23SSP635": ("Open-Source Technologies", "Lt. Dr. D. Antony Arul Raj (DA)"),
    "23SSP636": ("Programming in Python", "Dr. R. Umagandhi (RU)"),
    "23SSP637": ("Agile Software Development", "Dr. V. Usharani (VU)"),
    "23SSP638": ("Big Data Analytics", "Dr. N. Sathya (NS)"),
}
