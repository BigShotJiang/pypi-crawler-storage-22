def calculate_theory(test1, test2, attendance, sit1, sit2):
    total_tests = (test1 + test2) / 2  # average
    total_skill = sit1 + sit2
    total = total_tests + attendance + total_skill
    return round(total, 2)
