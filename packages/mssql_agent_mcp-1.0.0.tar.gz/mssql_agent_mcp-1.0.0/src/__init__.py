"""MSSQL Agent MCP Server.

A Model Context Protocol server for Microsoft SQL Server with support for
database queries, stored procedure management, and SQL Server Agent jobs.
"""

from .server import main, mcp

__all__ = ["main", "mcp"]
