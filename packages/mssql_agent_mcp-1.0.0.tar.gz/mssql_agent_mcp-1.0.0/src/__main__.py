"""Entry point for running the MSSQL MCP server as a module."""

from .server import main

if __name__ == "__main__":
    main()
