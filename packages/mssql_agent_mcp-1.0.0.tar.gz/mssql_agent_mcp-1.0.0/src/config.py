"""Configuration and environment variables for MSSQL MCP Server."""

import os

# Security configuration
READONLY_MODE = os.getenv("MSSQL_READONLY", "true").lower() in ("true", "1", "yes")

# Database configuration from environment variables
DB_CONFIG = {
    "server": os.getenv("MSSQL_SERVER", "localhost"),
    "database": os.getenv("MSSQL_DATABASE", "master"),
    "user": os.getenv("MSSQL_USER", ""),
    "password": os.getenv("MSSQL_PASSWORD", ""),
    "port": os.getenv("MSSQL_PORT", "1433"),
    "driver": os.getenv("MSSQL_DRIVER", "ODBC Driver 18 for SQL Server"),
    "encrypt": os.getenv("MSSQL_ENCRYPT", "yes"),
    "trust_server_certificate": os.getenv("MSSQL_TRUST_SERVER_CERTIFICATE", "no"),
    "auth_mode": os.getenv("MSSQL_AUTH_MODE", "sql"),  # sql, windows, azure
}

# Blocked SQL statement types when in readonly mode
BLOCKED_STATEMENT_TYPES = {
    "INSERT", "UPDATE", "DELETE", "DROP", "CREATE", "ALTER",
    "TRUNCATE", "MERGE", "EXEC", "EXECUTE", "GRANT", "REVOKE", "DENY",
}
