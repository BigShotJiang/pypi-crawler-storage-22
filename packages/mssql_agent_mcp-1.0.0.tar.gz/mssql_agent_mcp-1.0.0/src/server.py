#!/usr/bin/env python3
"""MSSQL MCP Server - Main entry point.

Provides tools for interacting with Microsoft SQL Server databases,
including stored procedure management and SQL Server Agent job management.
"""

from fastmcp import FastMCP

from .tools import database as db_tools
from .tools import jobs as job_tools
from .tools import procedures as proc_tools

# Create the FastMCP server instance
mcp = FastMCP(
    "mssql-agent-mcp",
    instructions="""This MCP server provides tools for interacting with Microsoft SQL Server databases.

    It supports:
    - Database queries and schema inspection
    - Stored procedure management with export/import workflows
    - SQL Server Agent job management with jobs-as-code workflow

    Use `query` for SELECT statements, `execute` for write operations.
    Jobs and procedures can be exported to files, edited, and pushed back to the server.
    """,
)

# Register database tools
mcp.tool()(db_tools.query)
mcp.tool()(db_tools.execute)
mcp.tool()(db_tools.list_tables)
mcp.tool()(db_tools.describe_table)
mcp.tool()(db_tools.list_databases)
mcp.tool()(db_tools.get_table_sample)
mcp.tool()(db_tools.get_table_indexes)
mcp.tool()(db_tools.get_foreign_keys)

# Register stored procedure tools
mcp.tool()(proc_tools.list_procedures)
mcp.tool()(proc_tools.list_all_procedures)
mcp.tool()(proc_tools.get_procedure_details)
mcp.tool()(proc_tools.get_procedure_parameters)
mcp.tool()(proc_tools.export_procedures_to_files)
mcp.tool()(proc_tools.update_procedure_from_file)

# Register SQL Server Agent job tools
mcp.tool()(job_tools.list_agent_jobs)
mcp.tool()(job_tools.get_job_steps)
mcp.tool()(job_tools.get_job_details)
mcp.tool()(job_tools.get_job_schedules)
mcp.tool()(job_tools.get_job_history)
mcp.tool()(job_tools.export_enabled_jobs_to_files)
mcp.tool()(job_tools.update_job_step_from_file)
mcp.tool()(job_tools.create_job_step_from_file)


def main():
    """Run the MCP server."""
    mcp.run()


if __name__ == "__main__":
    main()
