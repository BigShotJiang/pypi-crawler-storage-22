"""MCP tools for MSSQL Server operations."""

from .database import (
    describe_table,
    execute,
    get_foreign_keys,
    get_table_indexes,
    get_table_sample,
    list_databases,
    list_tables,
    query,
)
from .jobs import (
    create_job_step_from_file,
    export_enabled_jobs_to_files,
    get_job_details,
    get_job_history,
    get_job_schedules,
    get_job_steps,
    list_agent_jobs,
    update_job_step_from_file,
)
from .procedures import (
    export_procedures_to_files,
    get_procedure_details,
    get_procedure_parameters,
    list_all_procedures,
    list_procedures,
    update_procedure_from_file,
)

__all__ = [
    # Database tools
    "query",
    "execute",
    "list_tables",
    "describe_table",
    "list_databases",
    "get_table_sample",
    "get_table_indexes",
    "get_foreign_keys",
    # Procedure tools
    "list_procedures",
    "list_all_procedures",
    "get_procedure_details",
    "get_procedure_parameters",
    "export_procedures_to_files",
    "update_procedure_from_file",
    # Job tools
    "list_agent_jobs",
    "get_job_steps",
    "get_job_details",
    "get_job_schedules",
    "get_job_history",
    "export_enabled_jobs_to_files",
    "update_job_step_from_file",
    "create_job_step_from_file",
]
