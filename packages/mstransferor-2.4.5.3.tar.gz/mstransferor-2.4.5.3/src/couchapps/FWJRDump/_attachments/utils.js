function getRootDBName() {
  // 
  return location.href.split('/')[3];
}

