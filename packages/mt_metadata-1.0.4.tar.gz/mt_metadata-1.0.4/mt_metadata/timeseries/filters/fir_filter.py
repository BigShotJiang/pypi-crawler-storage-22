# =====================================================
# Imports
# =====================================================
from typing import Annotated

import matplotlib.pyplot as plt
import numpy as np
from pydantic import computed_field, Field, field_validator, PrivateAttr, ValidationInfo

from mt_metadata.base.helpers import requires
from mt_metadata.timeseries.filters import FilterBase, get_base_obspy_mapping

try:
    from obspy.core.inventory.response import FIRResponseStage
except ImportError:
    FIRResponseStage = None
import scipy.signal as signal

from mt_metadata.common import SymmetryEnum

# =====================================================


class FIRFilter(FilterBase):
    _filter_type: str = PrivateAttr("fir")
    type: Annotated[
        str,
        Field(
            default="fir",
            description="Type of filter.  Must be 'fir'",
            alias=None,
            json_schema_extra={
                "units": None,
                "required": True,
                "examples": "fir",
            },
        ),
    ]
    coefficients: Annotated[
        np.ndarray | list[float],
        Field(
            default_factory=lambda: np.empty(0),
            description="The FIR coefficients associated with the filter stage response.",
            alias=None,
            json_schema_extra={
                "units": None,
                "required": True,
                "items": {"type": "number"},
                "examples": '"[0.25, 0.5, 0.25]"',
            },
        ),
    ]

    decimation_factor: Annotated[
        float,
        Field(
            default=1.0,
            description="Downsample factor.",
            alias=None,
            json_schema_extra={
                "units": None,
                "required": False,
                "examples": "16",
            },
        ),
    ]

    decimation_input_sample_rate: Annotated[
        float,
        Field(
            default=1.0,
            description="Sample rate of FIR taps.",
            alias=None,
            json_schema_extra={
                "units": None,
                "required": False,
                "examples": "2000",
            },
        ),
    ]

    @computed_field
    @property
    def output_sampling_rate(self) -> float:
        return self.decimation_input_sample_rate / self.decimation_factor

    gain_frequency: Annotated[
        float,
        Field(
            default=0.0,
            description="Frequency of the reference gain, usually in passband.",
            alias=None,
            json_schema_extra={
                "units": "hertz",
                "required": True,
                "examples": "0.0",
            },
        ),
    ]

    symmetry: Annotated[
        SymmetryEnum,
        Field(
            default="NONE",
            description="Symmetry of FIR coefficients",
            alias=None,
            json_schema_extra={
                "units": None,
                "required": True,
                "examples": "NONE",
            },
        ),
    ]

    @field_validator("coefficients")
    @classmethod
    def validate_coefficients(
        cls, value: list[float], info: ValidationInfo
    ) -> list[float]:
        """
        Validate the coefficients to ensure they are a list of floats.
        :param value: The value to validate.
        :param info: Validation information.
        :return: The validated value.
        """
        if isinstance(value, (list, tuple, np.ndarray)):
            return np.array(value, dtype=float)
        elif isinstance(value, str):
            return np.array(value.split(","), dtype=float)
        else:
            raise ValueError("Coefficients must be a list, tuple, or string.")

    def make_obspy_mapping(self):
        mapping = get_base_obspy_mapping()
        mapping["_symmetry"] = "symmetry"
        mapping["_coefficients"] = "coefficients"
        mapping["decimation_factor"] = "decimation_factor"
        mapping["decimation_input_sample_rate"] = "decimation_input_sample_rate"
        mapping["stage_gain_frequency"] = "gain_frequency"
        return mapping

    @property
    def symmetry_corrected_coefficients(self):
        if self.symmetry == "EVEN":
            return np.hstack((self.coefficients, np.flipud(self.coefficients)))
        elif self.symmetry == "ODD":
            return np.hstack((self.coefficients, np.flipud(self.coefficients[1:])))
        else:
            return self.coefficients

    @property
    def coefficient_gain(self):
        """
        The gain at the reference frequency due only to the coefficients
        Sometimes this is different from the gain in the stationxml and a
        corrective scalar must be applied
        """
        if self.gain_frequency == 0.0:
            coefficient_gain = self.symmetry_corrected_coefficients.sum()
        else:
            # estimate the gain from the coefficeints at gain_frequency
            ww, hh = signal.freqz(
                self.symmetry_corrected_coefficients,
                worN=2 * np.pi * self.gain_frequency,
                fs=2 * np.pi * self.decimation_input_sample_rate,
            )
            coefficient_gain = np.abs(hh)
        return coefficient_gain

    @property
    def n_coefficients(self):
        return len(self.coefficients)

    @property
    def corrective_scalar(self):
        """ """
        if self.coefficient_gain != self.gain:
            return self.coefficient_gain / self.total_gain
        else:
            return 1.0

    def plot_fir_response(self):
        w, h = signal.freqz(self.full_coefficients)
        fig = plt.figure()
        plt.title("Digital filter frequency response")
        ax1 = fig.add_subplot(111)
        plt.plot(w, 20 * np.log10(abs(h)), "b")
        plt.ylabel("Amplitude [dB]", color="b")
        plt.xlabel("Frequency [rad/sample]")

        ax2 = ax1.twinx()
        angles = np.unwrap(np.angle(h))
        plt.plot(w, angles, "g")
        plt.ylabel("Angle (radians)", color="g")
        plt.grid()
        plt.axis("tight")
        plt.show()

        return fig

    @requires(obspy=FIRResponseStage)
    def to_obspy(
        self,
        stage_number=1,
        normalization_frequency=1,
        sample_rate=1,
    ):
        """
        create an obspy stage

        :return: DESCRIPTION
        :rtype: TYPE

        """
        # self, stage_sequence_number, stage_gain,
        # stage_gain_frequency, input_units, output_units,
        # symmetry="NONE", resource_id=None, resource_id2=None,
        # name=None,
        # coefficients=None, input_units_description=None,
        # output_units_description=None, description=None,
        # decimation_input_sample_rate=None, decimation_factor=None,
        # decimation_offset=None, decimation_delay=None,
        # decimation_correction=None
        rs = FIRResponseStage(
            stage_number,
            self.gain,
            normalization_frequency,
            self.units_in_object.symbol,
            self.units_out_object.symbol,
            coefficients=self.coefficients.tolist(),
            symmetry=self.symmetry,
            name=self.name,
            description=self.get_filter_description(),
            input_units_description=self.units_in_object.name,
            output_units_description=self.units_out_object.name,
            decimation_input_sample_rate=self.decimation_input_sample_rate,
            decimation_factor=self.decimation_factor,
        )

        return rs

    def unscaled_complex_response(self, frequencies):
        """
        need this to avoid RecursionError.
        The problem is that some FIRs need a scale factor to make their gains be
        the same as those reported in the stationXML.  The pure coefficients
        themselves sometimes result in pass-band gains that differ from the
        gain in the XML.  For example filter fs2d5 has a passband gain of 0.5
        based on the coefficients alone, but the cited gain in the xml is
        almost 1.

        I wanted to scale the coefficients so they equal the gain... but maybe
        we can add the gain in complex response
        :param frequencies:
        :return:
        """
        angular_frequencies = 2 * np.pi * frequencies
        w, h = signal.freqz(
            self.symmetry_corrected_coefficients,
            worN=angular_frequencies,
            fs=2 * np.pi * self.decimation_input_sample_rate,
        )
        return h

    def complex_response(self, frequencies, **kwargs):
        """

        Parameters
        ----------
        frequencies: numpy array of frequencies, expected in Hz

        Returns
        -------
        h : numpy array of (possibly complex-valued) frequency response at the input frequencies

        """
        # fir_filter.full_coefficients
        angular_frequencies = 2 * np.pi * frequencies
        w, h = signal.freqz(
            self.symmetry_corrected_coefficients,
            worN=angular_frequencies,
            fs=2 * np.pi * self.decimation_input_sample_rate,
        )
        h /= self.corrective_scalar

        return h
