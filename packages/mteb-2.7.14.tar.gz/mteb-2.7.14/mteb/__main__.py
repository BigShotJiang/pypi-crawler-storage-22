from mteb.cli import main

main()
