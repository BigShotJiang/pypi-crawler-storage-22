from .imagetext_pairclassification_evaluator import ImageTextPairClassificationEvaluator

__all__ = [
    "ImageTextPairClassificationEvaluator",
]
