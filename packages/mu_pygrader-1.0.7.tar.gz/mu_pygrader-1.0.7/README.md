Code developed by Ben Weaver for Messiah University Engineering
Owned and operated by Messiah University Engineering 2025

As this repository stands, there are capabilities to test student code, but there are few safeguards in place to protect the operator of this code. If you do not trust any student code, you should not run it.

See example_runner.py in the ./example/ directory to get started