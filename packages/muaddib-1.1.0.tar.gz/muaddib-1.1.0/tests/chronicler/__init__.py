"""Chronicler tests."""
