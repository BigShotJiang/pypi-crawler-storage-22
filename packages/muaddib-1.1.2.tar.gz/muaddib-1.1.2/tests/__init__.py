"""Tests for muaddib."""
