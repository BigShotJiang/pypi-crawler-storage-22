"""
Tests for Muban CLI.
"""
