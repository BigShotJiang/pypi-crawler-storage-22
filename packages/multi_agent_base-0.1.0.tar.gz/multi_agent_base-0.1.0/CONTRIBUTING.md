# Contributing to Multi-Agent Base

Thank you for your interest in contributing to Multi-Agent Base! This document provides guidelines and instructions for contributing.

## Development Setup

### Prerequisites

- Python 3.10+
- Git

### Setting Up Development Environment

1. Clone the repository:
```bash
git clone https://github.com/yourusername/multi-agent-base.git
cd multi-agent-base
```

2. Create a virtual environment:
```bash
python -m venv .venv
source .venv/bin/activate  # On Windows: .venv\Scripts\activate
```

3. Install development dependencies:
```bash
pip install -e ".[dev]"
```

4. Install pre-commit hooks:
```bash
pre-commit install
```

## Code Style

We use [Ruff](https://github.com/astral-sh/ruff) for linting and formatting:

```bash
# Check linting
ruff check src/ tests/

# Fix linting issues
ruff check --fix src/ tests/

# Format code
ruff format src/ tests/
```

### Style Guidelines

- Follow PEP 8 guidelines
- Use type hints for all function signatures
- Write docstrings for all public functions, classes, and modules
- Keep functions focused and small
- Use descriptive variable names

## Testing

### Running Tests

```bash
# Run all tests
PYTHONPATH=src pytest tests/ -v

# Run specific test file
PYTHONPATH=src pytest tests/test_cache.py -v

# Run with coverage
PYTHONPATH=src pytest tests/ --cov=src/multi_agent_base --cov-report=term-missing
```

### Writing Tests

- Place tests in the `tests/` directory
- Name test files with `test_` prefix
- Use descriptive test function names
- Use pytest fixtures for common setup
- Test both success and failure cases

Example test:
```python
import pytest
from multi_agent_base.cache import InMemoryCache, CacheConfig

class TestInMemoryCache:
    @pytest.fixture
    def cache(self):
        return InMemoryCache(CacheConfig(max_size=10))
    
    async def test_set_and_get(self, cache):
        await cache.set("key", "value")
        result = await cache.get("key")
        assert result == "value"
    
    async def test_get_missing_key(self, cache):
        result = await cache.get("missing")
        assert result is None
```

## Pull Request Process

1. **Fork the repository** and create a new branch:
```bash
git checkout -b feature/your-feature-name
```

2. **Make your changes** following the code style guidelines

3. **Add tests** for new functionality

4. **Update documentation** if needed

5. **Run the test suite** to ensure everything passes:
```bash
PYTHONPATH=src pytest tests/ -v
```

6. **Commit your changes** with a clear message:
```bash
git commit -m "feat: add new caching backend"
```

7. **Push to your fork** and create a Pull Request

### Commit Message Format

We follow [Conventional Commits](https://www.conventionalcommits.org/):

- `feat:` - New feature
- `fix:` - Bug fix
- `docs:` - Documentation changes
- `style:` - Code style changes (formatting, etc.)
- `refactor:` - Code refactoring
- `test:` - Adding or updating tests
- `chore:` - Maintenance tasks

Examples:
```
feat: add semantic caching with embeddings
fix: resolve race condition in rate limiter
docs: add memory module documentation
test: add tests for event bus priorities
```

## Project Structure

```
multi-agent-base/
├── src/multi_agent_base/
│   ├── core/           # Core agent and config
│   ├── memory/         # Memory backends
│   ├── resilience/     # Fault tolerance
│   ├── ratelimit/      # Rate limiting
│   ├── cache/          # Response caching
│   ├── events/         # Event system
│   ├── security/       # Security features
│   ├── providers/      # LLM providers
│   ├── a2a/            # Agent-to-Agent protocol
│   ├── cost/           # Cost tracking
│   └── observability/  # Tracing and logging
├── tests/              # Test files
├── docs/               # Documentation
├── examples/           # Example scripts
└── .github/            # GitHub workflows
```

## Adding New Features

### Adding a New Module

1. Create a new directory under `src/multi_agent_base/`
2. Add `__init__.py` with public exports
3. Implement core functionality
4. Add tests in `tests/test_<module>.py`
5. Add documentation in `docs/<module>.md`
6. Add example in `examples/`
7. Update `src/multi_agent_base/__init__.py` exports

### Feature Checklist

- [ ] Implementation complete
- [ ] Type hints added
- [ ] Docstrings written
- [ ] Tests added (aim for >80% coverage)
- [ ] Documentation updated
- [ ] Example added
- [ ] Changelog updated

## Questions?

Feel free to open an issue for:

- Bug reports
- Feature requests
- Questions about the codebase

Thank you for contributing! 🎉
