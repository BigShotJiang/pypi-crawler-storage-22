"""
Benchmarks for multi-agent-base performance testing.
"""
