"""
Cache system benchmarks.

Tests performance of different caching strategies.
"""

import asyncio
import time
import statistics
import random
import string
from typing import Any

import sys
sys.path.insert(0, "src")

from multi_agent_base.cache.lru import LRUCache, LRUCacheConfig
from multi_agent_base.cache.ttl import TTLCache, TTLCacheConfig


def generate_random_key(length: int = 20) -> str:
    """Generate a random cache key."""
    return "".join(random.choices(string.ascii_letters + string.digits, k=length))


def generate_random_value(length: int = 100) -> str:
    """Generate a random cache value."""
    return "".join(random.choices(string.ascii_letters + string.digits + " ", k=length))


async def benchmark_cache_set(
    cache: Any,
    n_operations: int = 10000,
) -> dict[str, float]:
    """Benchmark cache set operations.
    
    Args:
        cache: Cache instance
        n_operations: Number of set operations
        
    Returns:
        Benchmark results
    """
    keys = [generate_random_key() for _ in range(n_operations)]
    values = [generate_random_value() for _ in range(n_operations)]
    times: list[float] = []
    
    for key, value in zip(keys, values):
        start = time.perf_counter()
        await cache.set(key, value)
        end = time.perf_counter()
        times.append(end - start)
    
    return {
        "min_us": min(times) * 1_000_000,
        "max_us": max(times) * 1_000_000,
        "mean_us": statistics.mean(times) * 1_000_000,
        "median_us": statistics.median(times) * 1_000_000,
        "ops_per_sec": n_operations / sum(times),
    }


async def benchmark_cache_get_hit(
    cache: Any,
    keys: list[str],
    n_operations: int = 10000,
) -> dict[str, float]:
    """Benchmark cache get operations with hits.
    
    Args:
        cache: Cache instance
        keys: Pre-populated keys to get
        n_operations: Number of get operations
        
    Returns:
        Benchmark results
    """
    times: list[float] = []
    
    for _ in range(n_operations):
        key = random.choice(keys)
        start = time.perf_counter()
        await cache.get(key)
        end = time.perf_counter()
        times.append(end - start)
    
    return {
        "min_us": min(times) * 1_000_000,
        "max_us": max(times) * 1_000_000,
        "mean_us": statistics.mean(times) * 1_000_000,
        "median_us": statistics.median(times) * 1_000_000,
        "ops_per_sec": n_operations / sum(times),
    }


async def benchmark_cache_get_miss(
    cache: Any,
    n_operations: int = 10000,
) -> dict[str, float]:
    """Benchmark cache get operations with misses.
    
    Args:
        cache: Cache instance
        n_operations: Number of get operations
        
    Returns:
        Benchmark results
    """
    times: list[float] = []
    
    for _ in range(n_operations):
        key = generate_random_key() + "_nonexistent"
        start = time.perf_counter()
        await cache.get(key)
        end = time.perf_counter()
        times.append(end - start)
    
    return {
        "min_us": min(times) * 1_000_000,
        "max_us": max(times) * 1_000_000,
        "mean_us": statistics.mean(times) * 1_000_000,
        "median_us": statistics.median(times) * 1_000_000,
        "ops_per_sec": n_operations / sum(times),
    }


async def run_cache_benchmarks() -> None:
    """Run all cache benchmarks."""
    
    print("=" * 60)
    print("Cache System Benchmarks")
    print("=" * 60)
    
    # LRU Cache
    print("\n🔄 LRU Cache")
    print("-" * 40)
    
    lru = LRUCache(LRUCacheConfig(max_size=100000))
    
    print("\nSet operations (10000 ops):")
    set_results = await benchmark_cache_set(lru, 10000)
    print(f"  Mean: {set_results['mean_us']:.2f} μs")
    print(f"  Median: {set_results['median_us']:.2f} μs")
    print(f"  Ops/sec: {set_results['ops_per_sec']:.0f}")
    
    # Get existing keys
    keys = list(lru._cache.keys())[:1000] if hasattr(lru, '_cache') else []
    
    if keys:
        print("\nGet operations - hits (10000 ops):")
        get_hit_results = await benchmark_cache_get_hit(lru, keys, 10000)
        print(f"  Mean: {get_hit_results['mean_us']:.2f} μs")
        print(f"  Median: {get_hit_results['median_us']:.2f} μs")
        print(f"  Ops/sec: {get_hit_results['ops_per_sec']:.0f}")
    
    print("\nGet operations - misses (10000 ops):")
    get_miss_results = await benchmark_cache_get_miss(lru, 10000)
    print(f"  Mean: {get_miss_results['mean_us']:.2f} μs")
    print(f"  Median: {get_miss_results['median_us']:.2f} μs")
    print(f"  Ops/sec: {get_miss_results['ops_per_sec']:.0f}")
    
    # TTL Cache
    print("\n\n⏱️ TTL Cache")
    print("-" * 40)
    
    ttl = TTLCache(TTLCacheConfig(default_ttl=300.0, max_size=100000))
    
    print("\nSet operations (10000 ops):")
    set_results = await benchmark_cache_set(ttl, 10000)
    print(f"  Mean: {set_results['mean_us']:.2f} μs")
    print(f"  Median: {set_results['median_us']:.2f} μs")
    print(f"  Ops/sec: {set_results['ops_per_sec']:.0f}")
    
    # Get existing keys
    ttl_keys = list(ttl._cache.keys())[:1000] if hasattr(ttl, '_cache') else []
    
    if ttl_keys:
        print("\nGet operations - hits (10000 ops):")
        get_hit_results = await benchmark_cache_get_hit(ttl, ttl_keys, 10000)
        print(f"  Mean: {get_hit_results['mean_us']:.2f} μs")
        print(f"  Median: {get_hit_results['median_us']:.2f} μs")
        print(f"  Ops/sec: {get_hit_results['ops_per_sec']:.0f}")
    
    print("\nGet operations - misses (10000 ops):")
    get_miss_results = await benchmark_cache_get_miss(ttl, 10000)
    print(f"  Mean: {get_miss_results['mean_us']:.2f} μs")
    print(f"  Median: {get_miss_results['median_us']:.2f} μs")
    print(f"  Ops/sec: {get_miss_results['ops_per_sec']:.0f}")
    
    print("\n" + "=" * 60)
    print("Benchmarks Complete")
    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(run_cache_benchmarks())
