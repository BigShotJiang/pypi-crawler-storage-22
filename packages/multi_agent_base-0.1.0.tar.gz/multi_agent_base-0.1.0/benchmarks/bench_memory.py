"""
Memory system benchmarks.

Tests performance of different memory backends.
"""

import asyncio
import time
import statistics
from typing import Any

import sys
sys.path.insert(0, "src")

from multi_agent_base.memory.base import MemoryConfig, MemoryEntry
from multi_agent_base.memory.buffer import BufferMemory, SlidingWindowMemory


async def benchmark_store(
    memory: Any,
    n_operations: int = 1000,
) -> dict[str, float]:
    """Benchmark store operations.
    
    Args:
        memory: Memory backend instance
        n_operations: Number of store operations
        
    Returns:
        Benchmark results
    """
    times: list[float] = []
    
    for i in range(n_operations):
        start = time.perf_counter()
        await memory.add(
            role="user",
            content=f"Test message {i} with some content to make it more realistic. " * 10,
            metadata={"index": i},
        )
        end = time.perf_counter()
        times.append(end - start)
    
    return {
        "min_ms": min(times) * 1000,
        "max_ms": max(times) * 1000,
        "mean_ms": statistics.mean(times) * 1000,
        "median_ms": statistics.median(times) * 1000,
        "stddev_ms": statistics.stdev(times) * 1000 if len(times) > 1 else 0,
        "ops_per_sec": n_operations / sum(times),
    }


async def benchmark_retrieve(
    memory: Any,
    n_operations: int = 100,
    limit: int = 50,
) -> dict[str, float]:
    """Benchmark retrieve operations.
    
    Args:
        memory: Memory backend instance
        n_operations: Number of retrieve operations
        limit: Number of entries to retrieve
        
    Returns:
        Benchmark results
    """
    times: list[float] = []
    
    for _ in range(n_operations):
        start = time.perf_counter()
        await memory.get_recent(limit=limit)
        end = time.perf_counter()
        times.append(end - start)
    
    return {
        "min_ms": min(times) * 1000,
        "max_ms": max(times) * 1000,
        "mean_ms": statistics.mean(times) * 1000,
        "median_ms": statistics.median(times) * 1000,
        "stddev_ms": statistics.stdev(times) * 1000 if len(times) > 1 else 0,
        "ops_per_sec": n_operations / sum(times),
    }


async def benchmark_search(
    memory: Any,
    n_operations: int = 100,
) -> dict[str, float]:
    """Benchmark search operations.
    
    Args:
        memory: Memory backend instance
        n_operations: Number of search operations
        
    Returns:
        Benchmark results
    """
    times: list[float] = []
    
    for i in range(n_operations):
        start = time.perf_counter()
        await memory.search(f"message {i % 100}")
        end = time.perf_counter()
        times.append(end - start)
    
    return {
        "min_ms": min(times) * 1000,
        "max_ms": max(times) * 1000,
        "mean_ms": statistics.mean(times) * 1000,
        "median_ms": statistics.median(times) * 1000,
        "stddev_ms": statistics.stdev(times) * 1000 if len(times) > 1 else 0,
        "ops_per_sec": n_operations / sum(times),
    }


async def run_memory_benchmarks() -> None:
    """Run all memory benchmarks."""
    
    print("=" * 60)
    print("Memory System Benchmarks")
    print("=" * 60)
    
    # BufferMemory
    print("\n📦 BufferMemory")
    print("-" * 40)
    
    buffer = BufferMemory(MemoryConfig(max_entries=10000))
    
    print("\nStore operations (1000 ops):")
    store_results = await benchmark_store(buffer, 1000)
    print(f"  Mean: {store_results['mean_ms']:.3f} ms")
    print(f"  Median: {store_results['median_ms']:.3f} ms")
    print(f"  Min: {store_results['min_ms']:.3f} ms")
    print(f"  Max: {store_results['max_ms']:.3f} ms")
    print(f"  Ops/sec: {store_results['ops_per_sec']:.0f}")
    
    print("\nRetrieve operations (100 ops, 50 entries):")
    retrieve_results = await benchmark_retrieve(buffer, 100, 50)
    print(f"  Mean: {retrieve_results['mean_ms']:.3f} ms")
    print(f"  Median: {retrieve_results['median_ms']:.3f} ms")
    print(f"  Ops/sec: {retrieve_results['ops_per_sec']:.0f}")
    
    print("\nSearch operations (100 ops):")
    search_results = await benchmark_search(buffer, 100)
    print(f"  Mean: {search_results['mean_ms']:.3f} ms")
    print(f"  Median: {search_results['median_ms']:.3f} ms")
    print(f"  Ops/sec: {search_results['ops_per_sec']:.0f}")
    
    # SlidingWindowMemory
    print("\n\n📜 SlidingWindowMemory")
    print("-" * 40)
    
    await buffer.clear()
    sliding = SlidingWindowMemory(MemoryConfig(max_entries=10000))
    
    print("\nStore operations (1000 ops):")
    store_results = await benchmark_store(sliding, 1000)
    print(f"  Mean: {store_results['mean_ms']:.3f} ms")
    print(f"  Median: {store_results['median_ms']:.3f} ms")
    print(f"  Ops/sec: {store_results['ops_per_sec']:.0f}")
    
    print("\nRetrieve operations (100 ops, 50 entries):")
    retrieve_results = await benchmark_retrieve(sliding, 100, 50)
    print(f"  Mean: {retrieve_results['mean_ms']:.3f} ms")
    print(f"  Median: {retrieve_results['median_ms']:.3f} ms")
    print(f"  Ops/sec: {retrieve_results['ops_per_sec']:.0f}")
    
    print("\n" + "=" * 60)
    print("Benchmarks Complete")
    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(run_memory_benchmarks())
