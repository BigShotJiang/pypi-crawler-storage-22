"""
Rate limiter benchmarks.

Tests performance of different rate limiting strategies.
"""

import asyncio
import time
import statistics
from typing import Any

import sys
sys.path.insert(0, "src")

from multi_agent_base.ratelimit.limiter import (
    TokenBucketLimiter,
    SlidingWindowLimiter,
    RateLimitConfig,
)


async def benchmark_rate_limit_check(
    limiter: Any,
    n_operations: int = 10000,
) -> dict[str, float]:
    """Benchmark rate limit check operations.
    
    Args:
        limiter: Rate limiter instance
        n_operations: Number of check operations
        
    Returns:
        Benchmark results
    """
    times: list[float] = []
    
    for _ in range(n_operations):
        start = time.perf_counter()
        await limiter.can_acquire()
        end = time.perf_counter()
        times.append(end - start)
    
    return {
        "min_us": min(times) * 1_000_000,
        "max_us": max(times) * 1_000_000,
        "mean_us": statistics.mean(times) * 1_000_000,
        "median_us": statistics.median(times) * 1_000_000,
        "ops_per_sec": n_operations / sum(times),
    }


async def benchmark_rate_limit_acquire(
    limiter: Any,
    n_operations: int = 1000,
) -> dict[str, float]:
    """Benchmark rate limit acquire operations.
    
    Args:
        limiter: Rate limiter instance
        n_operations: Number of acquire operations
        
    Returns:
        Benchmark results
    """
    times: list[float] = []
    
    for _ in range(n_operations):
        start = time.perf_counter()
        await limiter.acquire(tokens=1)
        end = time.perf_counter()
        times.append(end - start)
        
        # Add small delay to not hit rate limit
        await asyncio.sleep(0.0001)
    
    return {
        "min_us": min(times) * 1_000_000,
        "max_us": max(times) * 1_000_000,
        "mean_us": statistics.mean(times) * 1_000_000,
        "median_us": statistics.median(times) * 1_000_000,
        "ops_per_sec": n_operations / sum(times),
    }


async def run_ratelimit_benchmarks() -> None:
    """Run all rate limiter benchmarks."""
    
    print("=" * 60)
    print("Rate Limiter Benchmarks")
    print("=" * 60)
    
    # Token Bucket Limiter
    print("\n🪣 Token Bucket Limiter")
    print("-" * 40)
    
    token_bucket = TokenBucketLimiter(RateLimitConfig(
        requests_per_minute=100000,  # High limit for benchmarking
        tokens_per_minute=1000000,
        burst_multiplier=10.0,
    ))
    
    print("\nCan acquire check (10000 ops):")
    check_results = await benchmark_rate_limit_check(token_bucket, 10000)
    print(f"  Mean: {check_results['mean_us']:.2f} μs")
    print(f"  Median: {check_results['median_us']:.2f} μs")
    print(f"  Ops/sec: {check_results['ops_per_sec']:.0f}")
    
    print("\nAcquire operations (1000 ops):")
    acquire_results = await benchmark_rate_limit_acquire(token_bucket, 1000)
    print(f"  Mean: {acquire_results['mean_us']:.2f} μs")
    print(f"  Median: {acquire_results['median_us']:.2f} μs")
    print(f"  Ops/sec: {acquire_results['ops_per_sec']:.0f}")
    
    # Sliding Window Limiter
    print("\n\n📊 Sliding Window Limiter")
    print("-" * 40)
    
    sliding_window = SlidingWindowLimiter(RateLimitConfig(
        requests_per_minute=100000,
        tokens_per_minute=1000000,
    ))
    
    print("\nCan acquire check (10000 ops):")
    check_results = await benchmark_rate_limit_check(sliding_window, 10000)
    print(f"  Mean: {check_results['mean_us']:.2f} μs")
    print(f"  Median: {check_results['median_us']:.2f} μs")
    print(f"  Ops/sec: {check_results['ops_per_sec']:.0f}")
    
    print("\nAcquire operations (1000 ops):")
    acquire_results = await benchmark_rate_limit_acquire(sliding_window, 1000)
    print(f"  Mean: {acquire_results['mean_us']:.2f} μs")
    print(f"  Median: {acquire_results['median_us']:.2f} μs")
    print(f"  Ops/sec: {acquire_results['ops_per_sec']:.0f}")
    
    print("\n" + "=" * 60)
    print("Benchmarks Complete")
    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(run_ratelimit_benchmarks())
