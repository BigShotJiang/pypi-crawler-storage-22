"""
Run all benchmarks.

Usage:
    cd base
    python benchmarks/run_all.py
"""

import asyncio
import sys

sys.path.insert(0, "src")


async def run_all_benchmarks() -> None:
    """Run all benchmarks."""
    
    print("\n" + "=" * 60)
    print("MULTI-AGENT-BASE PERFORMANCE BENCHMARKS")
    print("=" * 60 + "\n")
    
    # Import and run each benchmark
    print("Running Memory benchmarks...")
    from bench_memory import run_memory_benchmarks
    await run_memory_benchmarks()
    
    print("\n\n")
    print("Running Cache benchmarks...")
    from bench_cache import run_cache_benchmarks
    await run_cache_benchmarks()
    
    print("\n\n")
    print("Running Rate Limiter benchmarks...")
    from bench_ratelimit import run_ratelimit_benchmarks
    await run_ratelimit_benchmarks()
    
    print("\n\n")
    print("Running Security benchmarks...")
    from bench_security import run_security_benchmarks
    run_security_benchmarks()
    
    print("\n\n")
    print("=" * 60)
    print("ALL BENCHMARKS COMPLETE")
    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(run_all_benchmarks())
