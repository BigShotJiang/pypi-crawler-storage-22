# Agent Framework DevUI Özellikleri

Bu doküman, Agent Framework'ün DevUI özelliklerini ve nasıl kullanılacağını açıklar.

## 📋 İçindekiler

1. [DevUI Nedir?](#devui-nedir)
2. [Özellikler](#özellikler)
3. [Kurulum](#kurulum)
4. [Hızlı Başlangıç Scriptleri](#hızlı-başlangıç-scriptleri)
5. [Özellik Detayları](#özellik-detayları)

---

## DevUI Nedir?

Agent Framework DevUI, agent ve workflow geliştirme sürecini kolaylaştıran interaktif bir debugging ve test arayüzüdür. Tarayıcı tabanlı bir UI sunarak:

- Agent'larla sohbet etme
- Workflow'ları görselleştirme ve çalıştırma
- Trace ve event'leri izleme
- Human-in-the-loop onay akışları

gibi özellikleri sağlar.

---

## Özellikler

### 1. 🤖 Agent Chat Interface
Ollama veya diğer LLM'lerle çalışan agent'larla interaktif sohbet.

### 2. 📊 Workflow Visualization
Workflow'ların gerçek zamanlı görselleştirilmesi:
- Executor durumları (Pending, Running, Completed, Failed)
- Canlı güncellenen graph
- Events ve Traces panelleri

### 3. 🔭 Observability (Aspire Dashboard)
OpenTelemetry entegrasyonu ile trace'lerin Aspire Dashboard'da görüntülenmesi.

### 4. 🔧 Tool Calling
Agent'ların tool'ları kullanması ve sonuçların görüntülenmesi.

### 5. 📈 WorkflowViz
Workflow graph'larının Mermaid, DOT ve SVG formatlarında export edilmesi.

---

## Kurulum

### Gereksinimler

```bash
# Agent Framework paketleri
pip install agent-framework-core --pre
pip install agent-framework-devui --pre
pip install agent-framework-ollama --pre

# Observability için
pip install opentelemetry-exporter-otlp-proto-grpc

# Graph export için
brew install graphviz  # macOS
pip install graphviz
```

### Ollama Kurulumu

```bash
# Ollama'yı indir: https://ollama.ai
# Model indir
ollama pull qwen2.5-coder:7b
```

### Docker (Aspire Dashboard için)

```bash
brew install --cask docker
```

---

## Hızlı Başlangıç Scriptleri

Projenin `scripts/` klasöründe hazır scriptler bulunmaktadır:

| Script | Açıklama | URL |
|--------|----------|-----|
| `run_devui_agent.sh` | Ollama agent ile DevUI | http://localhost:8080 |
| `run_devui_workflow.sh` | Workflow görselleştirme | http://localhost:8080 |
| `run_aspire_dashboard.sh` | Aspire Dashboard | http://localhost:18888 |
| `run_all.sh` | Tüm servisleri başlat | Birden fazla URL |

### Kullanım

```bash
# Tek bir özellik için
./scripts/run_devui_agent.sh

# Tüm servisleri başlatmak için
./scripts/run_all.sh
```

---

## Özellik Detayları

### 1. DevUI Agent (Ollama)

**Dosya:** `examples/devui_ollama_agent.py`

**Özellikler:**
- Ollama modelleri ile çalışan ChatAgent
- Tool calling desteği (calculate, get_time, get_weather)
- Observability entegrasyonu

**Çalıştırma:**
```bash
./scripts/run_devui_agent.sh
```

**Erişim:** http://localhost:8080

---

### 2. Workflow Visualization

**Dosya:** `examples/workflow_devui_demo.py`

**Özellikler:**
- 5 adımlı email işleme pipeline'ı
- Gerçek zamanlı executor durumu görüntüleme
- Events ve Traces panelleri

**Pipeline:**
```
email_preprocessor → content_analyzer → spam_detector
    → message_responder → final_processor
```

**Çalıştırma:**
```bash
./scripts/run_devui_workflow.sh
```

**Erişim:** http://localhost:8080

**Kullanım:**
1. Workflow'u seç
2. Input alanına email yaz
3. "Run" butonuna tıkla
4. Executor'ların sırayla yeşile döndüğünü izle

---

### 3. Aspire Dashboard (Observability)

**Özellikler:**
- OpenTelemetry trace'lerini görüntüleme
- LLM çağrılarını izleme
- Span detayları ve timing bilgileri

**Çalıştırma:**
```bash
./scripts/run_aspire_dashboard.sh
```

**Erişim:** http://localhost:18888

**Not:** Token terminalde gösterilir, dashboard'a giriş için kullanın.

---

### 4. WorkflowViz (Graph Export)

**Dosya:** `examples/multi_agent_workflow_viz.py`

**Özellikler:**
- Mermaid diagram export
- DOT/GraphViz export
- SVG dosyası oluşturma

**Çalıştırma:**
```bash
./scripts/run_workflow_viz.sh
```

**Çıktı:** `workflow_graph.svg` dosyası oluşturulur ve açılır.

---

## Troubleshooting

### Ollama Tool Calling Çalışmıyor

**Problem:** Model tool çağrısını JSON olarak döndürüyor ama çalıştırmıyor.

**Çözüm:** Ollama'nın tool calling'i destekleyen modellerini kullanın:
- `mistral:7b`
- `llama3.2`
- `qwen2.5-coder:7b` (kısmi destek)

### DevUI Açılmıyor

**Kontrol:**
```bash
# Port kullanımda mı?
lsof -i :8080

# Ollama çalışıyor mu?
curl http://localhost:11434/api/tags
```

### Aspire Dashboard Bağlanamıyor

**Kontrol:**
```bash
# Docker çalışıyor mu?
docker ps

# Container durumu
docker logs aspire-dashboard
```

---

## Dosya Yapısı

```
base/
├── docs/
│   └── AF_DEVUI_FEATURES.md    # Bu doküman
├── examples/
│   ├── devui_ollama_agent.py   # Agent + DevUI örneği
│   ├── workflow_devui_demo.py  # Workflow görselleştirme
│   └── multi_agent_workflow_viz.py  # Graph export
├── scripts/
│   ├── run_devui_agent.sh      # Agent başlatma
│   ├── run_devui_workflow.sh   # Workflow başlatma
│   ├── run_aspire_dashboard.sh # Aspire başlatma
│   ├── run_workflow_viz.sh     # Graph export
│   └── run_all.sh              # Tüm servisler
└── workflow_graph.svg          # Export edilen graph
```

---

## Sonraki Adımlar

1. **Human-in-the-Loop (HIL)**: Workflow'lara kullanıcı onay adımları eklemek
2. **Branching Logic**: Koşullu workflow akışları oluşturmak
3. **Checkpointing**: Workflow durumunu kaydetme ve devam ettirme
4. **Multi-Agent Orchestration**: Birden fazla agent'ın koordinasyonu

---

*Son güncelleme: Şubat 2026*
