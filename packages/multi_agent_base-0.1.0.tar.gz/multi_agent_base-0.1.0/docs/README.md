# Agent Framework - Lokal Geliştirme Kılavuzu

Bu dokümantasyon, Microsoft Agent Framework'ü Ollama ile lokal ortamda kullanmak için hazırlanmış kapsamlı bir rehberdir.

---

## 📚 İçindekiler

| Bölüm | Açıklama |
|-------|----------|
| [Genel Bakış](./overview.md) | Agent Framework nedir, ne zaman kullanılır |
| [Hızlı Başlangıç](./quick-start.md) | 5 dakikada ilk agent'ınızı oluşturun |
| [Kurulum](./installation.md) | Detaylı kurulum adımları |
| [DevUI Özellikleri](./devui-features.md) | Geliştirme arayüzü kullanımı |
| [Workflow'lar](./workflows.md) | Multi-step iş akışları |
| [Observability](./observability.md) | Trace ve monitoring |
| [Troubleshooting](./troubleshooting.md) | Sık karşılaşılan sorunlar |

---

## 🚀 Hızlı Başlangıç

### 1. Kurulum

```bash
# Agent Framework paketleri
pip install agent-framework --pre
pip install agent-framework-devui --pre
pip install agent-framework-ollama --pre

# Ollama model
ollama pull qwen2.5-coder:7b
```

### 2. İlk Agent

```python
from agent_framework import ChatAgent, tool
from agent_framework.ollama import OllamaChatClient
from agent_framework.devui import serve

@tool
def calculate(expression: str) -> str:
    """Matematiksel ifadeyi hesapla."""
    return str(eval(expression))

client = OllamaChatClient(model_id="qwen2.5-coder:7b")
agent = ChatAgent(chat_client=client, tools=[calculate])

serve(entities=[agent], port=8080, auto_open=True)
```

### 3. Çalıştır

```bash
python my_agent.py
# Tarayıcıda: http://localhost:8080
```

---

## 📂 Proje Yapısı

```
base/
├── docs/
│   ├── README.md              # Bu dosya
│   ├── overview.md            # Genel bakış
│   ├── quick-start.md         # Hızlı başlangıç
│   ├── installation.md        # Kurulum
│   ├── devui-features.md      # DevUI özellikleri
│   ├── workflows.md           # Workflow'lar
│   ├── observability.md       # Observability
│   └── troubleshooting.md     # Sorun giderme
├── examples/
│   ├── devui_ollama_agent.py  # Agent + DevUI
│   ├── workflow_devui_demo.py # Workflow görselleştirme
│   └── multi_agent_workflow_viz.py  # Graph export
├── scripts/
│   ├── run_devui_agent.sh     # Agent başlatma
│   ├── run_devui_workflow.sh  # Workflow başlatma
│   ├── run_aspire_dashboard.sh # Aspire başlatma
│   └── run_all.sh             # Tüm servisler
└── src/                       # Kaynak kod
```

---

## 🎯 Hazır Scriptler

Projeyi hızlıca deneyimlemek için hazır scriptler:

| Script | Komut | URL |
|--------|-------|-----|
| Agent Demo | `./scripts/run_devui_agent.sh` | http://localhost:8080 |
| Workflow Demo | `./scripts/run_devui_workflow.sh` | http://localhost:8080 |
| Aspire Dashboard | `./scripts/run_aspire_dashboard.sh` | http://localhost:18888 |
| Tüm Servisler | `./scripts/run_all.sh` | Birden fazla |

---

## 📖 Sonraki Adımlar

1. **[Hızlı Başlangıç](./quick-start.md)** - 5 dakikada ilk agent'ınızı oluşturun
2. **[DevUI Özellikleri](./devui-features.md)** - Geliştirme arayüzünü keşfedin
3. **[Workflow'lar](./workflows.md)** - Multi-agent sistemler oluşturun

---

## 🔗 Faydalı Linkler

- [Microsoft Agent Framework Dokümantasyonu](https://learn.microsoft.com/en-us/agent-framework/)
- [GitHub Repository](https://github.com/microsoft/agent-framework)
- [Ollama](https://ollama.ai/)

---

*Son güncelleme: Şubat 2026*
