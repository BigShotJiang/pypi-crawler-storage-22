# A2A Agent Cards

Agent Cards are JSON metadata documents that describe an agent's capabilities, based on Google's Agent-to-Agent (A2A) protocol specification.

## Overview

Agent Cards provide a standardized way to:
- Describe what an agent can do
- List available skills
- Specify authentication requirements
- Enable agent discovery

## Creating Agent Cards

### Manual Creation

```python
from multi_agent_base.a2a import (
    AgentCard,
    AgentSkill,
    AgentCapabilities,
    AgentProvider,
)

# Create skills
search_skill = AgentSkill(
    id="web-search",
    name="Web Search",
    description="Search the web for information on any topic",
    tags=["search", "research", "information-retrieval"],
    examples=[
        "Search for the latest news about AI",
        "Find information about Python programming",
    ],
    input_modes=["text/plain"],
    output_modes=["text/plain", "application/json"],
)

analyze_skill = AgentSkill(
    id="data-analysis",
    name="Data Analysis",
    description="Analyze data and provide insights",
    tags=["analysis", "data", "insights"],
)

# Create capabilities
capabilities = AgentCapabilities(
    streaming=True,
    push_notifications=False,
    state_transition_history=True,
)

# Create provider info
provider = AgentProvider(
    organization="My Company",
    url="https://mycompany.com",
)

# Create the agent card
card = AgentCard(
    name="research-agent",
    description="An intelligent agent that researches topics and analyzes data",
    url="https://api.mycompany.com/agents/research",
    version="1.0.0",
    documentation_url="https://docs.mycompany.com/research-agent",
    capabilities=capabilities,
    skills=[search_skill, analyze_skill],
    provider=provider,
)

# Export to JSON
card.to_json("agent_card.json")
```

### Auto-Generation from Agent

```python
from multi_agent_base import SystemConfig, SingleAgentPattern

config = SystemConfig.from_env()
pattern = SingleAgentPattern(config)

def search_web(query: str) -> list[str]:
    """Search the web for information."""
    return []

agent = pattern.create_agent(
    name="assistant",
    system_prompt="You help with research.",
    tools=[search_web],
)

# Auto-generate agent card from agent
card = agent.generate_agent_card()
print(card)
```

## Skill Discovery

Automatically discover skills from Python functions:

### From Functions

```python
from multi_agent_base.a2a import SkillDiscoverer, discover_skills

def calculate_sum(numbers: list[float]) -> float:
    """Calculate the sum of a list of numbers.
    
    Args:
        numbers: List of numbers to sum
        
    Returns:
        The total sum
    """
    return sum(numbers)

def search_database(query: str, limit: int = 10) -> list[dict]:
    """Search the database for matching records.
    
    Args:
        query: Search query string
        limit: Maximum number of results
        
    Returns:
        List of matching records
    
    Example:
        >>> search_database("customer orders", limit=5)
    """
    return []

# Discover from single function
skill = SkillDiscoverer().discover_from_function(calculate_sum)
print(skill.name)  # "Calculate Sum"
print(skill.id)    # "calculate-sum"
print(skill.tags)  # ["calculation", "mathematics"]

# Discover from multiple functions
skills = discover_skills([calculate_sum, search_database])
for skill in skills:
    print(f"{skill.id}: {skill.description}")
```

### From Module

```python
from multi_agent_base.a2a import SkillDiscoverer

discoverer = SkillDiscoverer()
skills = discoverer.discover_from_module("path/to/tools.py")

for skill in skills:
    print(f"- {skill.name}: {skill.description}")
```

## Agent Card Registry

Manage multiple agent cards:

```python
from multi_agent_base.a2a import AgentCard, AgentCardRegistry

# Create registry
registry = AgentCardRegistry()

# Register agents
registry.register(research_agent_card)
registry.register(writer_agent_card)
registry.register(support_agent_card)

# Find by skill
agents_with_search = registry.find_by_skill("web-search")
print(f"Agents with web-search: {len(agents_with_search)}")

# Find by tag
research_agents = registry.find_by_tag("research")

# Find by capability
streaming_agents = registry.find_by_capability(streaming=True)

# Export all cards
registry.export_all("./agent_cards/")

# Import from directory
registry.import_from_directory("./agent_cards/")
```

## Agent Card Schema

### Full Schema

```json
{
  "name": "research-agent",
  "description": "An agent that researches topics",
  "url": "https://api.example.com/agents/research",
  "version": "1.0.0",
  "documentation_url": "https://docs.example.com/research-agent",
  "capabilities": {
    "streaming": true,
    "push_notifications": false,
    "state_transition_history": true
  },
  "authentication": {
    "schemes": ["bearer"],
    "credentials": "API key required"
  },
  "default_input_modes": ["text/plain"],
  "default_output_modes": ["text/plain", "application/json"],
  "skills": [
    {
      "id": "web-search",
      "name": "Web Search",
      "description": "Search the web for information",
      "tags": ["search", "research"],
      "examples": ["Search for AI news"],
      "input_modes": ["text/plain"],
      "output_modes": ["text/plain", "application/json"]
    }
  ],
  "provider": {
    "organization": "My Company",
    "url": "https://mycompany.com"
  },
  "metadata": {
    "custom_field": "value"
  },
  "created_at": "2024-01-15T10:30:00Z",
  "updated_at": "2024-01-15T10:30:00Z"
}
```

### AgentSkill Schema

```json
{
  "id": "skill-identifier",
  "name": "Human Readable Name",
  "description": "Detailed description of what the skill does",
  "tags": ["tag1", "tag2"],
  "examples": ["Example input 1", "Example input 2"],
  "input_modes": ["text/plain", "application/json"],
  "output_modes": ["text/plain"]
}
```

## Loading Agent Cards

### From JSON File

```python
from multi_agent_base.a2a import AgentCard

card = AgentCard.from_json("agent_card.json")
print(card.name)
print(card.skills)
```

### From JSON String

```python
json_str = '{"name": "agent", "description": "...", "url": "..."}'
card = AgentCard.from_json(json_str)
```

### From Dictionary

```python
data = {
    "name": "agent",
    "description": "An agent",
    "url": "https://example.com",
}
card = AgentCard.from_dict(data)
```

## Best Practices

1. **Descriptive Skills**: Write clear, detailed skill descriptions
2. **Good Examples**: Include realistic examples for each skill
3. **Appropriate Tags**: Use consistent, meaningful tags
4. **Version Control**: Update version when capabilities change
5. **Documentation**: Link to detailed documentation

## Integration with A2A Protocol

While this framework doesn't expose A2A servers, the Agent Cards are compatible with the A2A protocol specification. You can use them for:

- Agent catalogs
- Capability documentation
- Service discovery
- API documentation

For full A2A protocol implementation, see [Google's A2A specification](https://github.com/google/A2A).
