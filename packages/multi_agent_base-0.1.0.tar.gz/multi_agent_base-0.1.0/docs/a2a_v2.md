# A2A Protocol v2 Enhancements

This document describes the A2A (Agent-to-Agent) Protocol v2 enhancements implemented in the Multi-Agent Base framework.

## Overview

The A2A Protocol v2 provides a standardized way for AI agents to discover, communicate, and collaborate with each other. This implementation includes:

- **HTTP Server/Client**: Serve and discover agent cards via standard `.well-known/agent-card.json` endpoints
- **Conversation Threading**: Multi-turn conversation support with context preservation
- **Standardized Error Handling**: Comprehensive error codes and structured error responses

## Features

### 1. HTTP Server (`A2AServer`)

The A2A Server exposes an agent's capabilities via HTTP endpoints.

```python
from multi_agent_base.a2a import (
    AgentCard,
    AgentSkill,
    A2AServer,
    A2AServerConfig,
)

# Create agent card
card = AgentCard(
    name="translation-agent",
    description="A multilingual translation agent",
    url="http://localhost:8080",
    skills=[
        AgentSkill(
            id="translate",
            name="Translate",
            description="Translate text between languages",
            tags=["nlp", "translation"],
        ),
    ],
)

# Create and configure server
config = A2AServerConfig(
    host="0.0.0.0",
    port=8080,
    agent_card=card,
    enable_discovery=True,
)

server = A2AServer(config)

# Start the server
await server.start()

# Agent card now available at:
# http://localhost:8080/.well-known/agent-card.json
```

#### Server Endpoints

| Endpoint | Description |
|----------|-------------|
| `/.well-known/agent-card.json` | Agent card metadata (A2A standard) |
| `/health` | Health check endpoint |
| `/a2a/discover` | Discovery information |

#### Custom Routes

```python
async def custom_handler(request):
    return {
        "status": 200,
        "body": {"message": "Custom endpoint"},
    }

server.register_route("/custom", custom_handler)
```

### 2. HTTP Client (`A2AClient`)

The A2A Client discovers and interacts with remote agents.

```python
from multi_agent_base.a2a import A2AClient

client = A2AClient(
    timeout=30.0,
    retry_count=3,
)

# Discover agent at URL
card = await client.discover("http://remote-agent.example.com")
print(f"Found agent: {card.name}")
print(f"Skills: {[s.name for s in card.skills]}")

# Get specific skill
skill = client.get_skill(card, "translate")

# Get skills by tag
nlp_skills = client.get_skills_by_tag(card, "nlp")

# Cache management
client.cache_card("http://cached-agent.example.com", card)
client.clear_cache()
```

### 3. Agent Registry (`A2ARegistry`)

Registry for managing discovered agents.

```python
from multi_agent_base.a2a import A2ARegistry

registry = A2ARegistry()

# Register agents
registry.register(translator_card)
registry.register(summarizer_card)

# Find agents by name
agent = registry.get_by_name("translator")

# Find agents by URL
agent = registry.get_by_url("http://localhost:8080")

# Find agents by skill
translators = registry.find_by_skill("translate")

# Find agents by tag
nlp_agents = registry.find_by_tag("nlp")

# List all agents
all_agents = registry.list_all()
```

### 4. Conversation Threading

Multi-turn conversation support with full context preservation.

```python
from multi_agent_base.a2a import (
    ConversationThread,
    ThreadManager,
    ThreadMessage,
    MessageRole,
    ThreadState,
)

# Create a thread manager
manager = ThreadManager()

# Create a new conversation thread
thread = manager.create_thread(
    title="Translation Request",
    participants=["user", "translation-agent"],
    metadata={"language_pair": "en-fr"},
)

# Add messages
thread.add_message(
    content="Please translate: Hello, how are you?",
    role=MessageRole.USER,
)

thread.add_message(
    content="Bonjour, comment allez-vous?",
    role=MessageRole.AGENT,
    metadata={"source_lang": "en", "target_lang": "fr"},
)

# Query messages
last_message = thread.get_last_message()
agent_messages = thread.get_messages(role=MessageRole.AGENT)

# Thread lifecycle
thread.pause()
thread.resume()
thread.complete()

# Get context for agent
context = thread.get_context_for_agent("translation-agent")
```

#### Thread Context

```python
from multi_agent_base.a2a import ThreadContext

# Access thread context
ctx = thread.context

# Set and get variables
ctx.set_variable("user_preference", "formal")
preference = ctx.get_variable("user_preference")

# Track key points
ctx.add_key_point("User prefers formal translations")

# Update running summary
ctx.update_summary("Ongoing translation discussion about formal language")

# Agent-specific state
thread.update_agent_state("translation-agent", {"last_lang_pair": "en-fr"})
```

### 5. Standardized Error Handling

Comprehensive error types with HTTP status mapping.

```python
from multi_agent_base.a2a import (
    A2AError,
    A2AErrorCode,
    A2AErrorDetails,
    A2AErrorHandler,
    A2ADiscoveryError,
    A2ATimeoutError,
    A2ARateLimitError,
)

# Create custom error
error = A2AError(
    message="Agent not available",
    code=A2AErrorCode.AGENT_UNAVAILABLE,
    details=A2AErrorDetails(
        suggestion="Try again later",
        retry_after=60,
    ),
)

# Get HTTP status
print(error.http_status)  # 503

# Convert to HTTP response
response = error.to_response()
# {
#     "status": 503,
#     "body": {"error": {...}},
#     "headers": {"Content-Type": "application/json"}
# }
```

#### Error Code Categories

| Range | Category | Examples |
|-------|----------|----------|
| 1xxx | Client Errors | `INVALID_REQUEST`, `RATE_LIMITED`, `UNAUTHORIZED` |
| 2xxx | Agent Errors | `AGENT_NOT_FOUND`, `SKILL_NOT_FOUND`, `AGENT_TIMEOUT` |
| 3xxx | Communication Errors | `CONNECTION_FAILED`, `NETWORK_ERROR` |
| 4xxx | Protocol Errors | `PROTOCOL_VERSION_MISMATCH`, `THREAD_NOT_FOUND` |
| 5xxx | Internal Errors | `INTERNAL_ERROR`, `NOT_IMPLEMENTED` |

#### Error Handler

```python
handler = A2AErrorHandler(default_agent_name="my-agent")

# Handle exceptions
try:
    result = await risky_operation()
except Exception as e:
    error = handler.handle(e)
    return error.to_response()

# Register custom handlers
def handle_custom_error(exc):
    return A2AError(
        message=str(exc),
        code=A2AErrorCode.INTERNAL_ERROR,
    )

handler.register_handler(CustomException, handle_custom_error)
```

## Complete Example

```python
import asyncio
from multi_agent_base.a2a import (
    # HTTP
    AgentCard,
    AgentSkill,
    A2AServer,
    A2AServerConfig,
    A2AClient,
    A2ARegistry,
    # Threading
    ConversationThread,
    ThreadManager,
    MessageRole,
    # Errors
    A2AError,
    A2AErrorHandler,
)

async def main():
    # Create agent card
    card = AgentCard(
        name="assistant-agent",
        description="A helpful AI assistant",
        url="http://localhost:8080",
        skills=[
            AgentSkill(
                id="chat",
                name="Chat",
                description="General conversation",
            ),
            AgentSkill(
                id="summarize",
                name="Summarize",
                description="Text summarization",
                tags=["nlp"],
            ),
        ],
    )
    
    # Start server
    config = A2AServerConfig(port=8080, agent_card=card)
    server = A2AServer(config)
    await server.start()
    
    # Set up registry
    registry = A2ARegistry()
    registry.register(card)
    
    # Create conversation
    manager = ThreadManager()
    thread = manager.create_thread(title="Help Request")
    
    # Simulate conversation
    thread.add_message("Hello!", MessageRole.USER)
    thread.add_message("Hi! How can I help?", MessageRole.AGENT)
    
    # Error handling
    handler = A2AErrorHandler()
    try:
        # ... agent operations
        pass
    except Exception as e:
        error = handler.handle(e)
        print(f"Error: {error.code.value} - {error.message}")
    
    # Cleanup
    await server.stop()
    thread.complete()

if __name__ == "__main__":
    asyncio.run(main())
```

## API Reference

### Classes

| Class | Description |
|-------|-------------|
| `A2AServer` | HTTP server for agent cards |
| `A2AServerConfig` | Server configuration |
| `A2AClient` | HTTP client for agent discovery |
| `A2ARegistry` | Agent registry |
| `ConversationThread` | Conversation thread |
| `ThreadMessage` | Thread message |
| `ThreadContext` | Thread context data |
| `ThreadManager` | Thread lifecycle management |
| `ThreadState` | Thread state enum |
| `MessageRole` | Message role enum |
| `MessageStatus` | Message status enum |
| `A2AError` | Base error class |
| `A2AErrorCode` | Error code enum |
| `A2AErrorDetails` | Error details |
| `A2AErrorHandler` | Error handler |

### Specific Error Classes

| Class | Code | HTTP Status |
|-------|------|-------------|
| `A2ADiscoveryError` | `AGENT_NOT_FOUND` | 404 |
| `A2AConnectionError` | `CONNECTION_FAILED` | 502 |
| `A2ATimeoutError` | `RESPONSE_TIMEOUT` | 504 |
| `A2AAuthenticationError` | `UNAUTHORIZED` | 401 |
| `A2AProtocolError` | `PROTOCOL_VERSION_MISMATCH` | 400 |
| `A2AAgentError` | `AGENT_ERROR` | 500 |
| `A2AThreadError` | `THREAD_NOT_FOUND` | 404 |
| `A2AValidationError` | `INVALID_PARAMETER` | 400 |
| `A2ARateLimitError` | `RATE_LIMITED` | 429 |

## Reference

- [Google A2A Protocol](https://github.com/google/A2A)
- [Agent Card Specification](https://github.com/google/A2A/blob/main/spec/agent-card.md)
