# Advanced Orchestration Patterns

This module provides advanced orchestration patterns for complex multi-agent workflows.

## Overview

The advanced orchestration patterns extend the base framework with sophisticated agent coordination mechanisms:

| Pattern | Description | Use Case |
|---------|-------------|----------|
| `HierarchicalPattern` | Multi-level supervisor chains | Enterprise workflows with organizational hierarchy |
| `EnsemblePattern` | Multiple agents vote on responses | Consensus-building, expert panels |
| `SelfHealingPattern` | Auto-retry with modified approach | Fault-tolerant systems, critical tasks |

---

## HierarchicalPattern

Creates a tree-like structure of agents where supervisors at each level delegate to agents below them.

### Key Features

- **Multi-level hierarchy**: Define executive, management, and worker levels
- **Level-to-level delegation**: Supervisors delegate tasks downward
- **Result synthesis**: Results bubble up from bottom to top
- **Flexible structure**: Support for any number of levels

### Basic Usage

```python
from multi_agent_base.core import (
    HierarchicalPattern,
    SystemConfig,
    ProviderConfig,
    PatternType,
)

# Create configuration
config = SystemConfig(
    provider=ProviderConfig(model="gpt-4"),
    pattern=PatternType.HIERARCHICAL,
)

# Create pattern
pattern = HierarchicalPattern(config)

# Create levels (root level has no parent)
pattern.create_level("executive", supervisor="ceo")
pattern.create_level("management", supervisor="manager", parent="executive")
pattern.create_level("workers", agents=["worker1", "worker2"], parent="management")

# Add agents to levels
pattern.add_agent_to_level(
    level_name="executive",
    agent_name="ceo",
    system_prompt="You are the CEO overseeing all operations.",
    is_supervisor=True,
)

pattern.add_agent_to_level(
    level_name="management",
    agent_name="manager",
    system_prompt="You manage the worker team.",
    is_supervisor=True,
)

pattern.add_agent_to_level(
    level_name="workers",
    agent_name="worker1",
    system_prompt="You are a skilled worker.",
)

pattern.add_agent_to_level(
    level_name="workers",
    agent_name="worker2",
    system_prompt="You are another skilled worker.",
)

# Run the pattern
result = await pattern.run("Complete this complex project")

print(f"Result: {result.content}")
print(f"Levels involved: {result.metadata['levels']}")
```

### API Reference

#### `HierarchicalLevel`

```python
@dataclass
class HierarchicalLevel:
    name: str                      # Level name
    agents: list[str]              # Agents at this level
    supervisor: str | None         # Supervisor for this level
    parent_level: str | None       # Parent level name
```

#### `HierarchicalPattern`

| Method | Description |
|--------|-------------|
| `create_level(name, supervisor, agents, parent)` | Create a new level |
| `add_agent_to_level(level_name, agent_name, system_prompt, is_supervisor)` | Add agent to level |
| `get_level(name)` | Get level by name |
| `get_child_levels(level_name)` | Get child levels |
| `get_level_agents(level_name)` | Get all agents at level |
| `run(message)` | Execute the hierarchical workflow |

---

## EnsemblePattern

Multiple agents process the same input independently, then their responses are aggregated using a voting strategy.

### Key Features

- **Multiple voting strategies**: Majority, unanimous, weighted, ranked-choice
- **Configurable weights**: Assign importance to different voters
- **Optional aggregator**: Custom agent to synthesize diverse opinions
- **Automatic clustering**: Groups similar responses together

### Voting Strategies

| Strategy | Description |
|----------|-------------|
| `MAJORITY` | Most common response wins |
| `UNANIMOUS` | All must agree (returns empty if no consensus) |
| `WEIGHTED` | Weighted by agent importance |
| `RANKED_CHOICE` | Considers both frequency and weight |

### Basic Usage

```python
from multi_agent_base.core import (
    EnsemblePattern,
    VotingStrategy,
    SystemConfig,
    ProviderConfig,
)

# Create pattern with weighted voting
config = SystemConfig(provider=ProviderConfig(model="gpt-4"))
pattern = EnsemblePattern(config, voting_strategy=VotingStrategy.WEIGHTED)

# Add voters with different expertise
pattern.add_voter(
    name="security_expert",
    system_prompt="You are a security specialist.",
    weight=2.0,  # Higher weight for security decisions
)

pattern.add_voter(
    name="performance_expert",
    system_prompt="You are a performance optimization expert.",
    weight=1.5,
)

pattern.add_voter(
    name="ux_expert",
    system_prompt="You are a user experience expert.",
    weight=1.0,
)

# Optional: Add an aggregator to synthesize results
pattern.set_aggregator(
    name="synthesizer",
    system_prompt="You synthesize expert opinions into actionable recommendations.",
)

# Run the ensemble
result = await pattern.run("Should we implement feature X?")

print(f"Consensus: {result.content}")
print(f"Confidence: {result.metadata['confidence']:.1%}")
print(f"Voting strategy: {result.metadata['voting_strategy']}")
```

### API Reference

#### `VotingStrategy`

```python
class VotingStrategy(Enum):
    MAJORITY = "majority"
    UNANIMOUS = "unanimous"
    WEIGHTED = "weighted"
    RANKED_CHOICE = "ranked_choice"
```

#### `VoteResult`

```python
@dataclass
class VoteResult:
    winner: str                    # Winning response
    votes: dict[str, int]          # Votes per cluster
    confidence: float              # Confidence score (0-1)
    all_responses: list[str]       # All responses
```

#### `EnsemblePattern`

| Method | Description |
|--------|-------------|
| `add_voter(name, system_prompt, weight)` | Add a voting agent |
| `set_aggregator(name, system_prompt)` | Set optional aggregator |
| `run(message)` | Get consensus response |

---

## SelfHealingPattern

Automatically retries failed or unsatisfactory responses with modified prompts or strategies.

### Key Features

- **Configurable retries**: Set maximum retry attempts
- **Custom modification strategy**: Define how prompts change on retry
- **Custom validation**: Specify what constitutes success
- **Healer agent**: Optional agent to fix broken responses
- **Error pattern detection**: Automatic detection of common failure patterns

### Basic Usage

```python
from multi_agent_base.core import (
    SelfHealingPattern,
    SystemConfig,
    ProviderConfig,
)

# Define modification strategy
def modify_on_failure(attempt: int, last_response: str, error: str | None) -> str:
    strategies = [
        "Please try a different approach.",
        "Break down the problem step by step.",
        "Consider alternative methods.",
    ]
    return f"Previous attempt failed: {error}\n{strategies[min(attempt-1, 2)]}"

# Create pattern
config = SystemConfig(provider=ProviderConfig(model="gpt-4"))
pattern = SelfHealingPattern(
    config,
    max_retries=3,
    modification_strategy=modify_on_failure,
)

# Create the primary agent
pattern.create_agent(
    name="worker",
    system_prompt="You complete tasks reliably.",
)

# Set custom validator
pattern.set_validator(lambda response: "COMPLETE" in response)

# Optional: Set a healer agent
pattern.set_healer(
    name="healer",
    system_prompt="You fix incomplete or broken responses.",
)

# Run with auto-healing
result = await pattern.run("Complete this critical task")

print(f"Result: {result.content}")
print(f"Attempts: {result.metadata['attempts']}")
print(f"Was healed: {result.metadata['healed']}")
```

### Custom Error Patterns

```python
# Define custom patterns that indicate failure
pattern.set_error_patterns([
    "FAILED",
    "INCOMPLETE",
    "ERROR:",
    "Unable to",
])
```

### API Reference

#### `SelfHealingPattern`

| Method | Description |
|--------|-------------|
| `create_agent(name, system_prompt, tools)` | Create primary agent |
| `set_validator(validator)` | Set custom validation function |
| `set_healer(name, system_prompt)` | Set healer agent |
| `set_error_patterns(patterns)` | Set error detection patterns |
| `run(message)` | Execute with auto-healing |

---

## Combining Patterns

Patterns can be combined for complex workflows:

```python
# Hierarchical + Ensemble: Each level uses voting
pattern = HierarchicalPattern(config)
pattern.create_level("executive", supervisor="board")

# At the executive level, use ensemble voting
executive_ensemble = EnsemblePattern(config, voting_strategy=VotingStrategy.UNANIMOUS)
executive_ensemble.add_voter("ceo", "CEO perspective")
executive_ensemble.add_voter("cfo", "CFO perspective")
executive_ensemble.add_voter("cto", "CTO perspective")

# Self-Healing wrapper around any pattern
pattern = SelfHealingPattern(config, max_retries=2)
# ... configure for critical operations
```

---

## Best Practices

### HierarchicalPattern

1. **Keep hierarchy shallow**: 3-4 levels maximum
2. **Clear responsibilities**: Each level should have distinct responsibilities
3. **Supervisor guidance**: Give supervisors clear delegation instructions

### EnsemblePattern

1. **Diverse voters**: Include agents with different perspectives
2. **Appropriate weights**: Weight experts by their domain relevance
3. **Use aggregator**: For complex decisions, add a synthesizer

### SelfHealingPattern

1. **Reasonable retries**: 2-4 retries is usually sufficient
2. **Progressive modification**: Each retry should try a different approach
3. **Clear validation**: Make success criteria explicit

---

## Performance Considerations

| Pattern | Latency | Token Usage |
|---------|---------|-------------|
| Hierarchical | High (sequential) | Medium |
| Ensemble | Medium (parallel-ish) | High (all voters) |
| Self-Healing | Variable | Variable (depends on retries) |

---

## Error Handling

All patterns return a `PatternResult` with metadata about the execution:

```python
result = await pattern.run("Task")

if result.metadata.get("exhausted_retries"):
    # Handle failure
    pass

if result.metadata.get("confidence", 1.0) < 0.5:
    # Low confidence, may need human review
    pass
```

---

## Examples

See `examples/advanced_patterns_demo.py` for comprehensive examples.
