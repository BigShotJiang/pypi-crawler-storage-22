# API Reference

Complete API documentation for the Multi-Agent Base framework.

## Core Module

### SystemConfig

Main configuration class for the framework.

```python
class SystemConfig(BaseModel):
    pattern: PatternType = PatternType.SINGLE_AGENT
    provider: ProviderConfig = ProviderConfig()
    observability: ObservabilityConfig = ObservabilityConfig()
    cost_tracking: CostTrackingConfig = CostTrackingConfig()
    agents: list[AgentConfig] = []
    default_system_prompt: str = "You are a helpful AI assistant."
    retry_attempts: int = 3
    retry_delay: float = 1.0
    
    @classmethod
    def from_env(cls) -> SystemConfig:
        """Create configuration from environment variables."""
```

### ProviderConfig

LLM provider configuration.

```python
class ProviderConfig(BaseModel):
    provider: ProviderType = ProviderType.OLLAMA
    model: str = "llama3.2"
    api_key: str | None = None
    base_url: str | None = None
    temperature: float = 0.7
    max_tokens: int = 4096
    timeout: int = 120
    extra_params: dict[str, Any] = {}
```

### AgentConfig

Individual agent configuration.

```python
class AgentConfig(BaseModel):
    name: str
    description: str = ""
    system_prompt: str = "You are a helpful AI assistant."
    tools: list[str] = []
    provider_override: ProviderConfig | None = None
    max_iterations: int = 10
    enable_memory: bool = True
    metadata: dict[str, Any] = {}
```

### BaseAgent

Base agent class with unified interface.

```python
class BaseAgent:
    def __init__(
        self,
        name: str,
        config: AgentConfig,
        provider_config: ProviderConfig,
        tools: list[Tool] | None = None,
        logger: AgentLogger | None = None,
        cost_tracker: CostTracker | None = None,
    ) -> None: ...
    
    def register_tool(self, tool: Tool | Callable) -> None:
        """Register a tool with the agent."""
    
    async def run(
        self,
        message: str,
        context: dict[str, Any] | None = None,
    ) -> AgentResponse:
        """Run the agent with the given message."""
    
    def clear_memory(self) -> None:
        """Clear conversation memory."""
    
    def generate_agent_card(self) -> AgentCard:
        """Generate an A2A Agent Card."""
```

### AgentResponse

Response from an agent run.

```python
@dataclass
class AgentResponse:
    content: str
    messages: list[Message] = []
    tool_calls: list[dict[str, Any]] = []
    usage: dict[str, int] = {}
    cost: float | None = None
    duration_ms: float = 0.0
    metadata: dict[str, Any] = {}
```

## Patterns Module

### BasePattern

Abstract base class for patterns.

```python
class BasePattern(ABC):
    def __init__(
        self,
        config: SystemConfig,
        logger: AgentLogger | None = None,
        cost_tracker: CostTracker | None = None,
    ) -> None: ...
    
    @abstractmethod
    async def run(self, message: str, **kwargs) -> PatternResult: ...
    
    @abstractmethod
    def create_agent(
        self,
        name: str,
        system_prompt: str,
        tools: list | None = None,
        **kwargs,
    ) -> BaseAgent: ...
```

### SingleAgentPattern

Single agent with tools.

```python
class SingleAgentPattern(BasePattern):
    def create_agent(
        self,
        name: str,
        system_prompt: str,
        tools: list | None = None,
        **kwargs,
    ) -> BaseAgent: ...
    
    async def run(self, message: str, **kwargs) -> PatternResult: ...
```

### SupervisorPattern

Supervisor orchestrating workers.

```python
class SupervisorPattern(BasePattern):
    def create_supervisor(
        self,
        name: str,
        system_prompt: str,
        tools: list | None = None,
        **kwargs,
    ) -> BaseAgent: ...
    
    def create_worker(
        self,
        name: str,
        system_prompt: str,
        tools: list | None = None,
        **kwargs,
    ) -> BaseAgent: ...
    
    def create_team(
        self,
        supervisor_name: str,
        worker_configs: list[dict],
        supervisor_prompt: str = "...",
    ) -> BaseAgent: ...
    
    async def run(
        self,
        message: str,
        max_iterations: int = 10,
        **kwargs,
    ) -> PatternResult: ...
```

### SwarmPattern

Dynamic agent handoffs.

```python
class SwarmPattern(BasePattern):
    def create_agent(
        self,
        name: str,
        system_prompt: str,
        tools: list | None = None,
        can_handoff_to: list[str] | None = None,
        is_start_agent: bool = False,
        **kwargs,
    ) -> BaseAgent: ...
    
    async def run(
        self,
        message: str,
        start_agent: str | None = None,
        max_handoffs: int = 10,
        **kwargs,
    ) -> PatternResult: ...
```

### PatternResult

Result from pattern execution.

```python
@dataclass
class PatternResult:
    content: str
    agent_responses: list[AgentResponse] = []
    total_cost: float = 0.0
    total_tokens: dict[str, int] = {}
    metadata: dict[str, Any] = {}
```

### PipelinePattern

Sequential agent chain processing.

```python
class PipelinePattern(BasePattern):
    def add_stage(
        self,
        name: str,
        system_prompt: str,
        tools: list | None = None,
    ) -> None:
        """Add a stage to the pipeline."""
    
    def insert_stage(
        self,
        index: int,
        name: str,
        system_prompt: str,
        tools: list | None = None,
    ) -> None:
        """Insert a stage at a specific position."""
    
    def remove_stage(self, name: str) -> bool:
        """Remove a stage from the pipeline."""
    
    def get_stages(self) -> list[str]:
        """Get ordered list of stage names."""
    
    def add_transform(
        self,
        stage_name: str,
        transform: Callable[[str], str],
    ) -> None:
        """Add output transform after a stage."""
    
    async def run(
        self,
        message: str,
        **kwargs,
    ) -> PatternResult:
        """Run message through all pipeline stages."""
```

### ParallelPattern

Concurrent agent execution with optional aggregation.

```python
class ParallelPattern(BasePattern):
    def create_agent(
        self,
        name: str,
        system_prompt: str,
        tools: list | None = None,
    ) -> None:
        """Add a parallel worker agent."""
    
    def set_aggregator(
        self,
        name: str,
        system_prompt: str,
    ) -> None:
        """Set the aggregator agent for combining results."""
    
    async def run(
        self,
        message: str,
        aggregate: bool = True,
        **kwargs,
    ) -> PatternResult:
        """Run all workers in parallel."""
```

### RouterPattern

Intent-based message routing.

```python
class RouterPattern(BasePattern):
    def add_route(
        self,
        name: str,
        system_prompt: str,
        keywords: list[str] | None = None,
        tools: list | None = None,
    ) -> None:
        """Add a route with optional keyword triggers."""
    
    def set_default_route(self, name: str) -> None:
        """Set the fallback route."""
    
    def route(self, message: str) -> str | None:
        """Determine which route matches the message."""
    
    async def run(
        self,
        message: str,
        force_route: str | None = None,
        **kwargs,
    ) -> PatternResult:
        """Route and execute message."""
```

### ReflectionPattern

Self-improvement through actor-critic loop.

```python
class ReflectionPattern(BasePattern):
    def __init__(
        self,
        config: SystemConfig,
        max_refinements: int = 3,
        **kwargs,
    ) -> None: ...
    
    def set_actor(
        self,
        name: str,
        system_prompt: str,
        tools: list | None = None,
    ) -> None:
        """Set the actor (creator) agent."""
    
    def set_critic(
        self,
        name: str,
        system_prompt: str,
    ) -> None:
        """Set the critic (reviewer) agent."""
    
    def set_approval_check(
        self,
        check: Callable[[str], bool],
    ) -> None:
        """Set custom approval check function."""
    
    async def run(
        self,
        message: str,
        **kwargs,
    ) -> PatternResult:
        """Run actor-critic loop until approved or max iterations."""
```

### BlackboardPattern

Shared knowledge workspace.

```python
class BlackboardPattern(BasePattern):
    def __init__(
        self,
        config: SystemConfig,
        backend: str | Any = "memory",
        backend_config: dict | None = None,
        **kwargs,
    ) -> None: ...
    
    def add_expert(
        self,
        name: str,
        system_prompt: str,
        tools: list | None = None,
    ) -> None:
        """Add a knowledge source agent."""
    
    def write(
        self,
        key: str,
        value: Any,
        author: str | None = None,
    ) -> None:
        """Write to the blackboard."""
    
    def read(self, key: str) -> Any | None:
        """Read from the blackboard."""
    
    def read_all(self) -> dict[str, Any]:
        """Read all blackboard data."""
    
    def get_history(self) -> list[BlackboardEntry]:
        """Get modification history."""
    
    def clear(self) -> None:
        """Clear the blackboard."""
    
    async def run(
        self,
        message: str | None = None,
        max_iterations: int = 10,
        **kwargs,
    ) -> PatternResult:
        """Run experts iteratively on the blackboard."""
```

### CompositePattern

Combine multiple patterns into complex workflows.

```python
class CompositePattern(BasePattern):
    def add_pattern(
        self,
        name: str,
        pattern: BasePattern,
    ) -> None:
        """Add a sub-pattern."""
    
    def get_pattern(self, name: str) -> BasePattern | None:
        """Get a sub-pattern by name."""
    
    def set_flow(self, pattern_names: list[str]) -> None:
        """Set sequential execution order."""
    
    def add_condition(
        self,
        pattern_name: str,
        condition: Callable[[PatternResult], bool],
    ) -> None:
        """Add conditional execution for a pattern."""
    
    async def run(
        self,
        message: str,
        **kwargs,
    ) -> PatternResult:
        """Run patterns in configured flow order."""
    
    async def run_parallel(
        self,
        message: str,
        **kwargs,
    ) -> PatternResult:
        """Run all patterns in parallel."""
```

## Tools Module

### BaseTool

Abstract base class for tools.

```python
class BaseTool(ABC):
    def __init__(
        self,
        name: str,
        description: str,
        parameters: list[ToolParameter] | None = None,
        timeout: float = 30.0,
        max_retries: int = 3,
    ) -> None: ...
    
    @abstractmethod
    async def execute(self, **kwargs) -> ToolResult:
        """Execute the tool."""
    
    def run_sync(self, **kwargs) -> ToolResult:
        """Synchronous wrapper for execute."""
    
    def to_openai_schema(self) -> dict:
        """Convert to OpenAI function schema."""
    
    def to_anthropic_schema(self) -> dict:
        """Convert to Anthropic tool schema."""
    
    def to_agent_skill(self) -> AgentSkill:
        """Convert to A2A AgentSkill."""
```

### FunctionTool

Tool created from a function.

```python
class FunctionTool(BaseTool):
    @classmethod
    def from_function(
        cls,
        func: Callable,
        name: str | None = None,
        description: str | None = None,
        timeout: float = 30.0,
        max_retries: int = 3,
    ) -> FunctionTool:
        """Create tool from a function."""
```

### ToolParameter

Parameter definition for tools.

```python
@dataclass
class ToolParameter:
    name: str
    type: str  # "string", "integer", "number", "boolean", "array", "object"
    description: str
    required: bool = True
    default: Any = None
    enum: list[Any] | None = None
```

### ToolResult

Result from tool execution.

```python
@dataclass
class ToolResult:
    status: ToolResultStatus
    data: Any = None
    message: str = ""
    error: str | None = None
    execution_time_ms: float = 0.0
```

### ToolResultStatus

```python
class ToolResultStatus(str, Enum):
    SUCCESS = "success"
    ERROR = "error"
    PARTIAL = "partial"
    TIMEOUT = "timeout"
```

### ToolRegistry

Central tool management.

```python
class ToolRegistry:
    def register(self, tool: BaseTool) -> None:
        """Register a tool."""
    
    def register_many(self, tools: list[BaseTool]) -> None:
        """Register multiple tools."""
    
    def get(
        self,
        name: str,
        namespace: str | None = None,
    ) -> BaseTool | None:
        """Get a tool by name."""
    
    def get_by_category(self, category: str) -> list[BaseTool]:
        """Get tools by category."""
    
    def get_by_tags(self, tags: list[str]) -> list[BaseTool]:
        """Get tools that have all specified tags."""
    
    def list_all(self) -> list[BaseTool]:
        """List all registered tools."""
    
    def list_namespace(self, namespace: str) -> list[BaseTool]:
        """List tools in a namespace."""
    
    def add_namespace(self, namespace: ToolNamespace) -> None:
        """Add a namespace."""
    
    def clear(self) -> None:
        """Clear all tools."""

def get_registry() -> ToolRegistry:
    """Get the global tool registry singleton."""
```

### ToolNamespace

Isolated tool group.

```python
class ToolNamespace:
    def __init__(self, name: str) -> None: ...
    
    def register(self, tool: BaseTool) -> None:
        """Register a tool in this namespace."""
    
    def get(self, name: str) -> BaseTool | None:
        """Get a tool by name."""
    
    def list_all(self) -> list[BaseTool]:
        """List all tools in namespace."""
```

## Decorators

### @tool

Create a sync tool from a function.

```python
@tool(
    category: str | None = None,
    tags: list[str] | None = None,
    auto_register: bool = True,
)
def my_function(param: str) -> str:
    """Function docstring becomes description."""
    ...
```

### @async_tool

Create an async tool from an async function.

```python
@async_tool(
    timeout: float = 30.0,
    max_retries: int = 3,
    category: str | None = None,
    tags: list[str] | None = None,
)
async def my_async_function(param: str) -> dict:
    ...
```

### @action

Create an action tool (for side-effect operations).

```python
@action(
    category: str | None = None,
    requires_confirmation: bool = False,
)
def delete_resource(id: str) -> bool:
    ...
```

### @skill

Create a skill tool (for complex operations).

```python
@skill(
    category: str | None = None,
    complexity: str = "medium",  # "low", "medium", "high"
)
def analyze_data(data: dict) -> dict:
    ...
```

## Providers Module

### ModelClientFactory

Factory for creating model clients.

```python
class ModelClientFactory:
    @classmethod
    def create(cls, config: ProviderConfig) -> BaseModelClient: ...
    
    @classmethod
    def register(cls, provider_name: str, client_class: type) -> None: ...
```

### PricingCalculator

Cost calculation utilities.

```python
class PricingCalculator:
    @classmethod
    def calculate(
        cls,
        provider: str,
        model: str,
        input_tokens: int,
        output_tokens: int,
    ) -> float: ...
    
    @classmethod
    def get_pricing(cls, provider: str, model: str) -> ModelPricing: ...
    
    @classmethod
    def register_pricing(
        cls,
        provider: str,
        model: str,
        pricing: ModelPricing,
    ) -> None: ...
```

## A2A Module

### AgentCard

A2A Protocol Agent Card.

```python
class AgentCard(BaseModel):
    name: str
    description: str
    url: str
    version: str = "1.0.0"
    capabilities: AgentCapabilities = AgentCapabilities()
    skills: list[AgentSkill] = []
    provider: AgentProvider | None = None
    
    def add_skill(self, skill: AgentSkill) -> None: ...
    def get_skill(self, skill_id: str) -> AgentSkill | None: ...
    def to_json(self, path: str | None = None) -> str: ...
    @classmethod
    def from_json(cls, source: str | Path) -> AgentCard: ...
```

### AgentSkill

Skill definition for Agent Cards.

```python
class AgentSkill(BaseModel):
    id: str
    name: str
    description: str
    tags: list[str] = []
    examples: list[str] = []
    input_modes: list[str] = ["text/plain"]
    output_modes: list[str] = ["text/plain"]
```

### SkillDiscoverer

Auto-discover skills from functions.

```python
class SkillDiscoverer:
    def discover_from_function(
        self,
        func: Callable,
        skill_id: str | None = None,
    ) -> AgentSkill: ...
    
    def discover_from_tools(
        self,
        tools: list[Callable],
    ) -> list[AgentSkill]: ...
    
    def discover_from_module(
        self,
        module_path: str | Path,
    ) -> list[AgentSkill]: ...
```

### AgentCardRegistry

Registry for agent cards.

```python
class AgentCardRegistry:
    def register(self, card: AgentCard) -> None: ...
    def get(self, name: str) -> AgentCard | None: ...
    def find_by_skill(self, skill_id: str) -> list[AgentCard]: ...
    def find_by_tag(self, tag: str) -> list[AgentCard]: ...
    def export_all(self, directory: str | Path) -> None: ...
```

## Observability Module

### PhoenixTracer

Phoenix integration for tracing.

```python
class PhoenixTracer:
    def setup(self) -> None: ...
    def shutdown(self) -> None: ...
    
    @contextmanager
    def start_span(
        self,
        name: str,
        attributes: dict | None = None,
        kind: str = "internal",
    ) -> Generator[Span | None, None, None]: ...
    
    def trace_llm_call(
        self,
        model: str,
        provider: str,
        messages: list[dict],
        response: str,
        usage: dict[str, int],
        duration_ms: float,
    ) -> None: ...
    
    def trace_tool_call(
        self,
        tool_name: str,
        agent_name: str,
        arguments: dict,
        result: Any,
        duration_ms: float,
    ) -> None: ...
```

### AgentLogger

Structured logging for agents.

```python
class AgentLogger:
    def __init__(
        self,
        handlers: list[LogHandler] | None = None,
        default_level: LogLevel = LogLevel.INFO,
    ) -> None: ...
    
    def log_agent_start(self, agent_name: str, metadata: dict | None = None) -> None: ...
    def log_agent_end(self, agent_name: str, duration_ms: float | None = None) -> None: ...
    def log_message(self, agent_name: str, message: Any, direction: str = "in") -> None: ...
    def log_tool_call(
        self,
        agent_name: str,
        tool_name: str,
        arguments: dict,
        result: Any = None,
        duration_ms: float | None = None,
        error: str | None = None,
    ) -> None: ...
    def log_error(self, agent_name: str, error_message: str) -> None: ...
    def get_events(
        self,
        agent_name: str | None = None,
        event_type: EventType | None = None,
    ) -> list[LogEvent]: ...
```

## Cost Module

### CostTracker

Token usage and cost tracking.

```python
class CostTracker:
    def __init__(
        self,
        auto_persist: bool = False,
        persist_path: str | Path | None = None,
    ) -> None: ...
    
    def record(
        self,
        agent_name: str,
        provider: str,
        model: str,
        input_tokens: int,
        output_tokens: int,
        cost: float | None = None,
        metadata: dict | None = None,
    ) -> UsageRecord: ...
    
    def calculate_cost(
        self,
        provider: str,
        model: str,
        input_tokens: int,
        output_tokens: int,
    ) -> float: ...
    
    def get_records(
        self,
        agent_name: str | None = None,
        provider: str | None = None,
        start_time: datetime | None = None,
        end_time: datetime | None = None,
    ) -> list[UsageRecord]: ...
    
    def get_summary(
        self,
        agent_name: str | None = None,
        start_time: datetime | None = None,
    ) -> CostSummary: ...
    
    def export(self, path: str | Path, format: str = "json") -> None: ...
```

### CostSummary

Summary of costs and usage.

```python
@dataclass
class CostSummary:
    total_cost: float = 0.0
    total_input_tokens: int = 0
    total_output_tokens: int = 0
    record_count: int = 0
    by_agent: dict[str, dict] = {}
    by_provider: dict[str, dict] = {}
    by_model: dict[str, dict] = {}
    
    @property
    def total_tokens(self) -> int: ...
    @property
    def average_cost_per_call(self) -> float: ...
```

## Enums

### ProviderType

```python
class ProviderType(str, Enum):
    OLLAMA = "ollama"
    OPENAI = "openai"
    ANTHROPIC = "anthropic"
```

### PatternType

```python
class PatternType(str, Enum):
    SINGLE_AGENT = "single_agent"
    SUPERVISOR = "supervisor"
    SWARM = "swarm"
    DEBATE = "debate"
    PIPELINE = "pipeline"
    PARALLEL = "parallel"
    ROUTER = "router"
    REFLECTION = "reflection"
    BLACKBOARD = "blackboard"
    COMPOSITE = "composite"
```

### LogLevel

```python
class LogLevel(str, Enum):
    DEBUG = "debug"
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"
```

### EventType

```python
class EventType(str, Enum):
    AGENT_START = "agent.start"
    AGENT_END = "agent.end"
    AGENT_ERROR = "agent.error"
    MESSAGE_IN = "message.in"
    MESSAGE_OUT = "message.out"
    TOOL_CALL = "tool.call"
    LLM_REQUEST = "llm.request"
    LLM_RESPONSE = "llm.response"
    HANDOFF = "handoff"
```
