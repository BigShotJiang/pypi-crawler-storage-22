# Architecture Overview

Deep-dive into Multi-Agent Base architecture and design decisions.

## System Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           Application Layer                                  │
│  ┌──────────────────────────────────────────────────────────────────────┐  │
│  │                        Pattern Classes                                │  │
│  │  ┌────────────┐  ┌────────────┐  ┌────────────┐  ┌────────────┐     │  │
│  │  │ SingleAgent│  │ Supervisor │  │   Swarm    │  │ Blackboard │     │  │
│  │  │  Pattern   │  │  Pattern   │  │  Pattern   │  │  Pattern   │     │  │
│  │  └────────────┘  └────────────┘  └────────────┘  └────────────┘     │  │
│  └──────────────────────────────────────────────────────────────────────┘  │
├─────────────────────────────────────────────────────────────────────────────┤
│                           Core Agent Layer                                   │
│  ┌──────────────────────────────────────────────────────────────────────┐  │
│  │                          BaseAgent                                    │  │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐                  │  │
│  │  │   Tools     │  │   Memory    │  │  Streaming  │                  │  │
│  │  │ Management  │  │  Backend    │  │   Support   │                  │  │
│  │  └─────────────┘  └─────────────┘  └─────────────┘                  │  │
│  └──────────────────────────────────────────────────────────────────────┘  │
├─────────────────────────────────────────────────────────────────────────────┤
│                        Cross-Cutting Concerns                                │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐         │
│  │ Memory   │ │Resilience│ │  Rate    │ │  Cache   │ │ Security │         │
│  │ Backends │ │ Patterns │ │ Limiting │ │ Backends │ │  Layer   │         │
│  └──────────┘ └──────────┘ └──────────┘ └──────────┘ └──────────┘         │
├─────────────────────────────────────────────────────────────────────────────┤
│                          Service Layer                                       │
│  ┌──────────────┐ ┌──────────────┐ ┌──────────────┐ ┌──────────────┐      │
│  │     A2A      │ │     Cost     │ │ Observability│ │  Monitoring  │      │
│  │ Agent Cards  │ │   Tracker    │ │   (Phoenix)  │ │  (Metrics)   │      │
│  └──────────────┘ └──────────────┘ └──────────────┘ └──────────────┘      │
│  ┌──────────────┐                                                          │
│  │ Event System │                                                          │
│  └──────────────┘                                                          │
├─────────────────────────────────────────────────────────────────────────────┤
│                         Provider Layer                                       │
│  ┌──────────────────────────────────────────────────────────────────────┐  │
│  │                      Model Client Factory                             │  │
│  │  ┌──────────┐  ┌──────────┐  ┌──────────┐                           │  │
│  │  │  Ollama  │  │  OpenAI  │  │Anthropic │                           │  │
│  │  │  Client  │  │  Client  │  │  Client  │                           │  │
│  │  └──────────┘  └──────────┘  └──────────┘                           │  │
│  └──────────────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Core Concepts

### 1. Configuration-First Design

All components are configured through typed dataclasses/Pydantic models:

```python
@dataclass
class SystemConfig:
    provider: ProviderType
    model: str
    temperature: float = 0.7
    max_tokens: int = 4096
    
class AgentConfig(BaseModel):
    name: str
    system_prompt: str
    tools: list[str] = []
```

**Benefits:**
- Type safety and validation
- Easy serialization (JSON/YAML)
- IDE autocomplete
- Self-documenting

### 2. Dependency Injection

Components receive their dependencies through constructors:

```python
agent = BaseAgent(
    name="assistant",
    config=agent_config,
    provider_config=provider_config,
    logger=logger,           # Optional
    cost_tracker=tracker,    # Optional
    memory_backend=memory,   # Optional
    model_client=client,     # Optional
)
```

**Benefits:**
- Testability (easy mocking)
- Flexibility (swap implementations)
- Clear dependencies

### 3. Abstract Base Classes

Provider-agnostic interfaces:

```python
class BaseModelClient(ABC):
    @abstractmethod
    async def generate(self, messages, tools, **kwargs):
        pass
    
    @abstractmethod
    async def stream(self, messages, tools, **kwargs):
        pass

class MemoryBackend(ABC):
    @abstractmethod
    async def add(self, entry: MemoryEntry) -> str:
        pass
    
    @abstractmethod
    async def get_recent(self, limit: int) -> list[MemoryEntry]:
        pass
```

## Component Details

### Patterns Layer

Orchestrates agent behavior:

| Pattern | Use Case | Complexity |
|---------|----------|------------|
| SingleAgent | Simple Q&A, chat | Low |
| Supervisor | Coordinated team tasks | Medium |
| Swarm | Autonomous collaboration | High |
| Blackboard | Shared workspace | Medium |

### BaseAgent

Core agent with:
- Tool registration and execution loop
- Conversation memory (in-memory + backend)
- Streaming support
- A2A card generation

**Tool Execution Flow:**
```
User Message → Model Call → Tool Calls? 
    ↓ No                     ↓ Yes
Response ← ─ ─ ─ ─ ─ ─ ─ Execute Tools
    ↑                        ↓
    └─────── Model Call ←────┘
         (with results)
```

### Memory System

Multiple backend options:

```
┌─────────────────┐
│  MemoryBackend  │ (Abstract)
└────────┬────────┘
         │
    ┌────┴────┬─────────┬──────────┬──────────┐
    ▼         ▼         ▼          ▼          ▼
┌────────┐ ┌────────┐ ┌────────┐ ┌────────┐ ┌────────┐
│ Buffer │ │Sliding │ │ Vector │ │ Redis  │ │Summary │
│ Memory │ │ Window │ │ Memory │ │Backend │ │ Memory │
└────────┘ └────────┘ └────────┘ └────────┘ └────────┘
```

### Resilience Patterns

```
┌─────────────────────────────────────────┐
│           ResilientWrapper              │
│  ┌──────────┐ ┌──────────┐ ┌─────────┐ │
│  │  Retry   │→│ Circuit  │→│ Timeout │ │
│  │ Strategy │ │ Breaker  │ │ Handler │ │
│  └──────────┘ └──────────┘ └─────────┘ │
│         ↓          ↓           ↓       │
│       ┌────────────────────────────┐   │
│       │      Fallback Chain        │   │
│       └────────────────────────────┘   │
└─────────────────────────────────────────┘
```

### Event System

Decoupled communication:

```python
# Publisher
bus.publish("agent.started", {"name": "assistant"})

# Subscriber
@bus.subscribe("agent.*")
async def on_agent_event(event):
    logger.info(f"Agent event: {event.name}")
```

## Data Flow

### Request Flow

```
1. User Input
       ↓
2. Input Validation (Security)
       ↓
3. Rate Limit Check
       ↓
4. Cache Lookup
       ↓ (miss)
5. Agent.run()
       ↓
6. Memory Context Loading
       ↓
7. Model Client.generate()
       ↓
8. Tool Execution Loop
       ↓
9. Response Processing
       ↓
10. Cache Storage
       ↓
11. Cost Tracking
       ↓
12. Event Publishing
       ↓
13. Response to User
```

### Error Flow

```
Exception Raised
       ↓
1. Retry (if retryable)
       ↓ (exhausted)
2. Circuit Breaker (if open, fast fail)
       ↓
3. Fallback Chain
       ↓ (all failed)
4. Error Logging
       ↓
5. Metrics Recording
       ↓
6. Error Response to User
```

## Design Principles

### 1. Async-First

All I/O operations are async:

```python
# ✅ Good
async def process(message: str) -> str:
    result = await agent.run(message)
    return result

# ❌ Avoid
def process_sync(message: str) -> str:
    return asyncio.run(agent.run(message))
```

### 2. Fail-Safe Defaults

Optional components have sensible defaults:

```python
# Works without explicit configuration
agent = create_agent("assistant")

# Or fully configured
agent = create_agent(
    "assistant",
    memory=redis_memory,
    cache=semantic_cache,
    rate_limiter=distributed_limiter,
)
```

### 3. Composability

Components can be mixed and matched:

```python
# Use any memory backend
agent.memory_backend = RedisMemory(...)

# Use any rate limiter
agent.rate_limiter = RedisRateLimiter(...)

# Use any cache
response_cache = SemanticCache(...)
```

### 4. Observability Built-In

Every operation is traceable:

```python
with tracer.span("agent.run"):
    with tracer.span("model.generate"):
        response = await model.generate(...)
    
    with tracer.span("tool.execute"):
        result = await execute_tool(...)
```

## Extension Points

### Custom Providers

```python
class MyProvider(BaseModelClient):
    async def generate(self, messages, tools, **kwargs):
        # Your implementation
        pass

ModelClientFactory.register("my-provider", MyProvider)
```

### Custom Memory Backends

```python
class MyMemory(MemoryBackend):
    async def add(self, entry):
        # Your implementation
        pass
    
    async def get_recent(self, limit):
        # Your implementation
        pass
```

### Custom Resilience Policies

```python
class MyRetryStrategy(RetryStrategy):
    def calculate_delay(self, attempt: int) -> float:
        # Custom backoff logic
        return min(2 ** attempt, 60)
```

## Performance Considerations

### Concurrency

- Use connection pools for databases
- Limit concurrent API calls
- Use semaphores for resource control

### Memory

- Bound conversation history
- Use streaming for large responses
- Implement memory summarization

### Caching

- Cache at appropriate granularity
- Use TTL for freshness
- Consider semantic caching for similar queries

## Testing Strategy

### Unit Tests
- Test individual components in isolation
- Mock external dependencies

### Integration Tests
- Test component interactions
- Use test containers for Redis, etc.

### End-to-End Tests
- Test complete workflows
- Use real LLM APIs (with test keys)

See [testing documentation](testing.md) for more details.
