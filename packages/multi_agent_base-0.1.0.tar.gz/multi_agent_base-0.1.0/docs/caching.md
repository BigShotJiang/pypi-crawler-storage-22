# Caching Module

The Caching module provides response caching to reduce API calls, lower costs, and improve latency. It supports in-memory, TTL-based, and semantic caching.

## Cache Backends

### InMemoryCache

Fast LRU cache with configurable size:

```python
from multi_agent_base.cache import InMemoryCache, CacheConfig

cache = InMemoryCache(CacheConfig(
    max_size=1000,
    ttl_seconds=3600,  # 1 hour
))

# Cache a value
await cache.set("key", "value")

# Retrieve
value = await cache.get("key")

# Check existence
if await cache.exists("key"):
    print("Found in cache!")
```

### TTLCache

Time-based expiration with automatic cleanup:

```python
from multi_agent_base.cache import TTLCache

cache = TTLCache(
    default_ttl=300,  # 5 minutes default
    cleanup_interval=60,  # Cleanup every minute
)

# Set with custom TTL
await cache.set("session", data, ttl=1800)  # 30 minutes

# Get remaining TTL
remaining = await cache.ttl("session")
print(f"Expires in {remaining} seconds")
```

### SemanticCache

Embedding-based cache that finds similar queries:

```python
from multi_agent_base.cache import SemanticCache

cache = SemanticCache(
    embedding_fn=my_embedding_function,
    similarity_threshold=0.9,  # 90% similarity required
    max_entries=10000,
)

# First query
await cache.set(
    "What is the capital of France?",
    "The capital of France is Paris.",
)

# Similar query hits cache!
result = await cache.get("What's France's capital city?")
# Returns: "The capital of France is Paris."
```

## Configuration

```python
from multi_agent_base.cache import CacheConfig

config = CacheConfig(
    enabled=True,
    max_size=1000,           # Maximum entries
    ttl_seconds=3600,        # Default TTL
    cleanup_interval=300,    # Cleanup every 5 minutes
)
```

## Decorators

### @cached

Cache function results automatically:

```python
from multi_agent_base.cache import cached

@cached(ttl=3600)
async def expensive_operation(query: str) -> str:
    return await llm.complete(query)

# First call executes function
result1 = await expensive_operation("Hello")

# Second call returns cached result
result2 = await expensive_operation("Hello")  # Instant!
```

### Custom Cache Keys

```python
from multi_agent_base.cache import cached

def custom_key(query: str, user_id: str) -> str:
    return f"{user_id}:{query}"

@cached(ttl=3600, key_fn=custom_key)
async def user_query(query: str, user_id: str) -> str:
    return await process_query(query, user_id)
```

### @cache_response

For caching LLM responses:

```python
from multi_agent_base.cache import cache_response

@cache_response(
    cache=my_cache,
    key_prefix="llm:",
    ttl=3600,
)
async def generate_response(prompt: str) -> str:
    return await model.complete(prompt)
```

## LLM Response Caching

Specialized caching for LLM responses:

```python
from multi_agent_base.cache import LLMResponseCache

cache = LLMResponseCache(
    backend=InMemoryCache(CacheConfig(max_size=5000)),
    include_model=True,      # Different models = different cache
    include_temperature=True, # Different temps = different cache
)

# Cache key includes model and parameters
await cache.cache_response(
    prompt="Explain quantum computing",
    response="Quantum computing uses...",
    model="gpt-4o",
    temperature=0.7,
)

# Look up
cached = await cache.get_response(
    prompt="Explain quantum computing",
    model="gpt-4o",
    temperature=0.7,
)
```

## Cache Statistics

Monitor cache performance:

```python
from multi_agent_base.cache import InMemoryCache

cache = InMemoryCache(CacheConfig(max_size=1000))

# Use cache...

# Get statistics
stats = cache.stats()
print(f"Hits: {stats['hits']}")
print(f"Misses: {stats['misses']}")
print(f"Hit rate: {stats['hit_rate']:.2%}")
print(f"Size: {stats['size']}/{stats['max_size']}")
```

## Cache Invalidation

```python
# Delete specific key
await cache.delete("key")

# Clear all
await cache.clear()

# Clear by pattern (if supported)
await cache.clear_pattern("user:123:*")
```

## Integration with Agents

```python
from multi_agent_base.core.agent import BaseAgent
from multi_agent_base.cache import SemanticCache

# Create semantic cache
cache = SemanticCache(
    embedding_fn=embedding_function,
    similarity_threshold=0.95,
)

# Agent with caching
agent = BaseAgent(
    config=agent_config,
    response_cache=cache,
)

# Repeated similar queries use cache
response1 = agent.run("What is Python?")
response2 = agent.run("Tell me about Python")  # Cache hit!
```

## Best Practices

1. **Choose the right cache**:
   - Exact matches: `InMemoryCache` or `TTLCache`
   - Similar queries: `SemanticCache`
   - Distributed: Use Redis-backed cache

2. **Set appropriate TTLs**:
   - Static content: Long TTL (hours/days)
   - Dynamic content: Short TTL (minutes)
   - Real-time data: Don't cache

3. **Size your cache**:
   - Monitor memory usage
   - Set `max_size` based on available memory
   - Use LRU eviction for bounded memory

4. **Use semantic caching wisely**:
   - Higher threshold (0.95+) for precise matching
   - Lower threshold (0.85) for more aggressive caching
   - Monitor false positives

5. **Cache warming**:
   - Pre-populate cache with common queries
   - Use background jobs for warming

## Example: Multi-Level Cache

```python
from multi_agent_base.cache import (
    InMemoryCache,
    SemanticCache,
    CacheConfig,
)

class MultiLevelCache:
    """L1: Exact match, L2: Semantic match."""
    
    def __init__(self, embedding_fn):
        self.l1 = InMemoryCache(CacheConfig(max_size=1000))
        self.l2 = SemanticCache(
            embedding_fn=embedding_fn,
            similarity_threshold=0.9,
        )
    
    async def get(self, key: str):
        # Try L1 first
        result = await self.l1.get(key)
        if result:
            return result
        
        # Try L2 semantic search
        result = await self.l2.get(key)
        if result:
            # Promote to L1
            await self.l1.set(key, result)
            return result
        
        return None
    
    async def set(self, key: str, value: str):
        await self.l1.set(key, value)
        await self.l2.set(key, value)
```

## Example: Cache with Fallback

```python
from multi_agent_base.cache import cached
from multi_agent_base.resilience import with_fallback

@cached(ttl=3600)
@with_fallback(lambda e: "Default response")
async def resilient_query(prompt: str) -> str:
    """Cached and fault-tolerant query."""
    return await model.complete(prompt)
```
