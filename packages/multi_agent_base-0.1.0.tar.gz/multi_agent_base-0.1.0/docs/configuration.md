# Configuration Guide

This guide covers all configuration options in the Multi-Agent Base framework.

## SystemConfig

The main configuration object that combines all settings.

```python
from multi_agent_base import SystemConfig, PatternType, ProviderType

config = SystemConfig(
    pattern=PatternType.SUPERVISOR,
    provider=ProviderConfig(
        provider=ProviderType.OPENAI,
        model="gpt-4o-mini",
        api_key="sk-...",
    ),
    observability=ObservabilityConfig(enabled=True),
    cost_tracking=CostTrackingConfig(enabled=True),
)
```

### From Environment Variables

```python
config = SystemConfig.from_env()
```

Environment variables:
- `MULTI_AGENT_PROVIDER`: Provider type (ollama, openai, anthropic)
- `MULTI_AGENT_MODEL`: Model name
- `OPENAI_API_KEY`: OpenAI API key
- `ANTHROPIC_API_KEY`: Anthropic API key
- `OLLAMA_BASE_URL`: Ollama endpoint
- `OBSERVABILITY_ENABLED`: Enable tracing (true/false)
- `PHOENIX_ENDPOINT`: Phoenix collector URL
- `PROJECT_NAME`: Project name for traces

## ProviderConfig

Configuration for LLM providers.

```python
from multi_agent_base.core.config import ProviderConfig, ProviderType

# OpenAI
openai_config = ProviderConfig(
    provider=ProviderType.OPENAI,
    model="gpt-4o-mini",
    api_key="sk-...",
    temperature=0.7,
    max_tokens=4096,
    timeout=120,
)

# Ollama (local)
ollama_config = ProviderConfig(
    provider=ProviderType.OLLAMA,
    model="llama3.2",
    base_url="http://localhost:11434",
    temperature=0.7,
)

# Anthropic
anthropic_config = ProviderConfig(
    provider=ProviderType.ANTHROPIC,
    model="claude-3-5-sonnet-20241022",
    api_key="sk-ant-...",
    max_tokens=4096,
)
```

### Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `provider` | ProviderType | OLLAMA | LLM provider |
| `model` | str | "llama3.2" | Model name |
| `api_key` | str \| None | None | API key |
| `base_url` | str \| None | Auto | API endpoint |
| `temperature` | float | 0.7 | Sampling temperature (0-2) |
| `max_tokens` | int | 4096 | Max tokens in response |
| `timeout` | int | 120 | Request timeout (seconds) |
| `extra_params` | dict | {} | Additional parameters |

## AgentConfig

Configuration for individual agents.

```python
from multi_agent_base.core.config import AgentConfig

agent_config = AgentConfig(
    name="researcher",
    description="Researches topics thoroughly",
    system_prompt="""You are a research specialist.
    Always cite sources and provide accurate information.""",
    tools=["web_search", "document_reader"],
    max_iterations=10,
    enable_memory=True,
    metadata={"department": "research"},
)
```

### Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `name` | str | required | Unique agent identifier |
| `description` | str | "" | Agent description |
| `system_prompt` | str | default | System prompt |
| `tools` | list[str] | [] | Available tool names |
| `provider_override` | ProviderConfig \| None | None | Override default provider |
| `max_iterations` | int | 10 | Max reasoning iterations |
| `enable_memory` | bool | True | Enable conversation memory |
| `metadata` | dict | {} | Additional metadata |

## ObservabilityConfig

Configuration for tracing and logging.

```python
from multi_agent_base.core.config import ObservabilityConfig

obs_config = ObservabilityConfig(
    enabled=True,
    phoenix_endpoint="http://localhost:6006",
    project_name="my-agents",
    log_level="INFO",
    trace_tool_calls=True,
    trace_llm_calls=True,
    trace_agent_messages=True,
    export_spans=True,
)
```

### Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `enabled` | bool | True | Enable observability |
| `phoenix_endpoint` | str | "http://localhost:6006" | Phoenix endpoint |
| `project_name` | str | "multi-agent-base" | Project name |
| `log_level` | str | "INFO" | Log level |
| `trace_tool_calls` | bool | True | Trace tool calls |
| `trace_llm_calls` | bool | True | Trace LLM calls |
| `trace_agent_messages` | bool | True | Trace messages |
| `export_spans` | bool | True | Export to Phoenix |

## CostTrackingConfig

Configuration for cost tracking.

```python
from multi_agent_base.core.config import CostTrackingConfig

cost_config = CostTrackingConfig(
    enabled=True,
    track_tokens=True,
    track_costs=True,
    persist_records=True,
    records_path="./cost_records.jsonl",
)
```

### Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `enabled` | bool | True | Enable cost tracking |
| `track_tokens` | bool | True | Track token usage |
| `track_costs` | bool | True | Calculate costs |
| `persist_records` | bool | False | Persist to file |
| `records_path` | str | "./cost_records.jsonl" | Persist path |

## Complete Example

```python
from multi_agent_base import (
    SystemConfig,
    PatternType,
    ProviderConfig,
    ProviderType,
    ObservabilityConfig,
    CostTrackingConfig,
    AgentConfig,
)

# Full configuration
config = SystemConfig(
    # Pattern
    pattern=PatternType.SUPERVISOR,
    
    # Provider
    provider=ProviderConfig(
        provider=ProviderType.OPENAI,
        model="gpt-4o-mini",
        api_key="sk-...",
        temperature=0.7,
        max_tokens=4096,
    ),
    
    # Observability
    observability=ObservabilityConfig(
        enabled=True,
        phoenix_endpoint="http://localhost:6006",
        project_name="production-agents",
        log_level="INFO",
    ),
    
    # Cost tracking
    cost_tracking=CostTrackingConfig(
        enabled=True,
        persist_records=True,
        records_path="./logs/costs.jsonl",
    ),
    
    # Pre-configured agents
    agents=[
        AgentConfig(
            name="supervisor",
            system_prompt="You manage the team.",
        ),
        AgentConfig(
            name="worker-1",
            system_prompt="You handle specific tasks.",
        ),
    ],
    
    # General settings
    default_system_prompt="You are a helpful AI.",
    retry_attempts=3,
    retry_delay=1.0,
)
```

## Loading from File

You can also load configuration from YAML or JSON:

```python
import json
from multi_agent_base import SystemConfig

# From JSON file
with open("config.json") as f:
    data = json.load(f)
config = SystemConfig(**data)

# From YAML (requires pyyaml)
import yaml
with open("config.yaml") as f:
    data = yaml.safe_load(f)
config = SystemConfig(**data)
```

Example `config.yaml`:

```yaml
pattern: supervisor
provider:
  provider: openai
  model: gpt-4o-mini
  temperature: 0.7
observability:
  enabled: true
  phoenix_endpoint: http://localhost:6006
cost_tracking:
  enabled: true
```
