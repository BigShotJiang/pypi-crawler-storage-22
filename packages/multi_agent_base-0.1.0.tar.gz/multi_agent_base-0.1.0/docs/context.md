# Context Engineering Module

The Context Engineering module provides comprehensive tools for managing, optimizing, and compressing LLM context windows. This is essential for working with long conversations while staying within token limits.

## Overview

The module includes three main components:

1. **ContextOptimizer**: Main orchestrator that coordinates optimization strategies
2. **ContextPruner**: Specialized pruning strategies for removing messages
3. **ContextCompressor**: Compression and summarization utilities

## Installation

The context module is included in the multi-agent-base package:

```python
from multi_agent_base.context import (
    ContextOptimizer,
    ContextPruner,
    ContextCompressor,
    OptimizationConfig,
)
```

## Quick Start

### Basic Optimization

```python
from multi_agent_base.context import ContextOptimizer, OptimizationConfig

# Create optimizer with configuration
config = OptimizationConfig(max_tokens=4096, preserve_recent=3)
optimizer = ContextOptimizer(config=config)

# Your conversation messages
messages = [
    {"role": "system", "content": "You are a helpful assistant."},
    {"role": "user", "content": "What is Python?"},
    {"role": "assistant", "content": "Python is a programming language..."},
    # ... more messages
]

# Optimize to fit within token limit
result = optimizer.optimize(messages)

# Use optimized messages
print(f"Reduced from {result.stats.original_tokens} to {result.stats.optimized_tokens} tokens")
optimized_messages = result.to_list()
```

## Core Components

### ContextMessage

The base message type with metadata:

```python
from multi_agent_base.context import ContextMessage, MessageRole

# Create a message
msg = ContextMessage(
    role="user",  # or MessageRole.USER
    content="Hello, how are you?",
    importance=0.8,  # Optional: 0-1 importance score
)

# Estimate tokens
tokens = msg.estimate_tokens()

# Convert to dict for API calls
msg_dict = msg.to_dict()
```

### ContextWindow

Manages a window of messages with token tracking:

```python
from multi_agent_base.context import ContextWindow, ContextMessage

# Create window with token limit
window = ContextWindow(max_tokens=4096)

# Add messages
window.add_message(ContextMessage(role="system", content="You are helpful."))
window.add_message(ContextMessage(role="user", content="Hello!"))

# Check utilization
print(f"Using {window.current_tokens}/{window.max_tokens} tokens")
print(f"Utilization: {window.utilization * 100:.1f}%")

# Get messages by role
user_messages = window.get_messages_by_role("user")

# Convert to API format
messages_list = window.to_list()
```

### OptimizationConfig

Configure optimization behavior:

```python
from multi_agent_base.context import OptimizationConfig, PruningStrategy

# Manual configuration
config = OptimizationConfig(
    max_tokens=4096,           # Target token limit
    preserve_system=True,       # Always keep system messages
    preserve_recent=3,          # Keep last N messages
    min_messages=1,             # Minimum messages to keep
    pruning_strategy=PruningStrategy.SMART,  # Strategy choice
    relevance_threshold=0.3,    # Min relevance score
    importance_threshold=0.3,   # Min importance score
    enable_summarization=True,  # Summarize pruned content
    summarization_ratio=0.3,    # Summary length ratio
)

# Or use presets
aggressive = OptimizationConfig.aggressive()  # 2048 tokens, strict pruning
balanced = OptimizationConfig.balanced()       # 4096 tokens, smart pruning
conservative = OptimizationConfig.conservative()  # 8192 tokens, minimal pruning
```

## Pruning Strategies

### Available Strategies

```python
from multi_agent_base.context import PruningStrategy

# RECENCY: Keep most recent messages
config = OptimizationConfig(
    max_tokens=2048,
    pruning_strategy=PruningStrategy.RECENCY,
)

# RELEVANCE: Keep messages relevant to a query
config = OptimizationConfig(
    max_tokens=2048,
    pruning_strategy=PruningStrategy.RELEVANCE,
)
result = optimizer.optimize(messages, query="specific topic")

# IMPORTANCE: Keep high-importance messages
config = OptimizationConfig(
    max_tokens=2048,
    pruning_strategy=PruningStrategy.IMPORTANCE,
)

# SLIDING_WINDOW: Simple fixed window from end
config = OptimizationConfig(
    max_tokens=2048,
    pruning_strategy=PruningStrategy.SLIDING_WINDOW,
)

# SMART: Combines multiple strategies (default)
config = OptimizationConfig(
    max_tokens=2048,
    pruning_strategy=PruningStrategy.SMART,
)
```

### Using ContextPruner Directly

```python
from multi_agent_base.context import ContextPruner, ConversationPruner

pruner = ContextPruner(preserve_system=True)

# Prune by recency
result = pruner.prune_by_recency(messages, keep_count=10)
print(f"Kept {result.kept_count}, pruned {result.pruned_count}")

# Prune by relevance
result = pruner.prune_by_relevance(
    messages,
    query="Python programming",
    keep_count=10,
)

# Prune by token limit
result = pruner.prune_by_token_limit(messages, max_tokens=2000)

# Remove duplicates
result = pruner.prune_duplicates(messages, similarity_threshold=0.9)

# Filter by pattern (regex)
result = pruner.prune_by_pattern(
    messages,
    patterns=["debug", "error"],
    keep_matches=False,  # Remove matching messages
)

# Remove specific roles
result = pruner.prune_by_role(messages, roles_to_remove=["tool", "function"])

# Remove empty messages
result = pruner.prune_empty(messages)

# Truncate long tool results
result = pruner.prune_tool_results(messages, max_result_length=500)
```

### Conversation-Aware Pruning

```python
from multi_agent_base.context import ConversationPruner

pruner = ConversationPruner()

# Keep complete conversation turns
result = pruner.prune_keeping_turns(messages, keep_turns=5)

# Prune with summarization
result, summary = pruner.prune_summarizing_turns(
    messages,
    keep_turns=3,
    summarizer=my_summarizer_func,
)
if summary:
    print(f"Earlier conversation: {summary}")
```

## Compression Methods

### Using ContextCompressor

```python
from multi_agent_base.context import ContextCompressor, CompressionMethod

compressor = ContextCompressor()

# Compress by summarization
result = compressor.compress(
    messages,
    target_tokens=2048,
    method=CompressionMethod.SUMMARIZE,
)

# Compress by merging similar messages
result = compressor.compress(
    messages,
    target_tokens=2048,
    method=CompressionMethod.MERGE,
)

# Extract key points
result = compressor.compress(
    messages,
    target_tokens=2048,
    method=CompressionMethod.EXTRACT_KEY_POINTS,
)

# Hierarchical summarization
result = compressor.compress(
    messages,
    target_tokens=2048,
    method=CompressionMethod.HIERARCHICAL,
)
```

### Direct Compression Operations

```python
# Summarize messages
summary = compressor.summarize_messages(messages, max_summary_tokens=200)

# Merge similar messages
result = compressor.merge_similar_messages(messages, similarity_threshold=0.7)

# Extract key points from messages
result = compressor.extract_key_points(messages, max_points_per_message=3)

# Truncate long messages
result = compressor.truncate_messages(messages, max_chars_per_message=500)
```

### Tool Compression

```python
# Compress tool definitions
tools = [
    {"type": "function", "function": {"name": "search", "description": "..."}},
    {"type": "function", "function": {"name": "calculate", "description": "..."}},
]

compressed_tools = compressor.compress_tools(
    tools,
    max_tokens=1000,
    keep_names=["search"],  # Always keep these tools
)
```

## Optimizing with Tools

When using function calling, optimize both messages and tools:

```python
from multi_agent_base.context import ContextOptimizer, OptimizationConfig

optimizer = ContextOptimizer(config=OptimizationConfig(max_tokens=4096))

# Optimize messages and tools together
result, optimized_tools = optimizer.optimize_with_tools(
    messages,
    tools,
    max_tokens=4096,
)

# Use in API call
response = client.chat.completions.create(
    model="gpt-4",
    messages=result.to_list(),
    tools=[t.to_dict() for t in optimized_tools],
)
```

## Custom Summarization

Provide your own summarizer for better compression:

```python
from openai import OpenAI

client = OpenAI()

def llm_summarizer(contents: list[str]) -> str:
    """Summarize content using an LLM."""
    combined = "\n\n".join(contents)
    response = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": "Summarize the following conversation briefly."},
            {"role": "user", "content": combined},
        ],
        max_tokens=200,
    )
    return response.choices[0].message.content

# Use with optimizer
optimizer = ContextOptimizer(
    config=OptimizationConfig(enable_summarization=True),
    summarizer=llm_summarizer,
)

result = optimizer.optimize(messages)
if result.summary:
    print(f"Summarized content: {result.summary}")
```

## Custom Relevance Scoring

Provide custom relevance scoring with embeddings:

```python
def embedding_scorer(query: str, content: str) -> float:
    """Score relevance using embeddings."""
    query_emb = get_embedding(query)
    content_emb = get_embedding(content)
    return cosine_similarity(query_emb, content_emb)

# Use with pruner
pruner = ContextPruner()
result = pruner.prune_by_relevance(
    messages,
    query="machine learning",
    scorer=embedding_scorer,
)
```

## Token Estimation

Estimate tokens without tiktoken:

```python
from multi_agent_base.context import TokenEstimator

# Simple character-based estimate
tokens = TokenEstimator.estimate_simple("Hello world!")

# Model-specific estimate
tokens = TokenEstimator.estimate_simple("Hello world!", model="gpt-4")

# Word-based estimate
tokens = TokenEstimator.estimate_words("Hello world!")

# Estimate for message list
tokens = TokenEstimator.estimate_messages(messages)

# Estimate for tool definition
tokens = TokenEstimator.estimate_tool(tool_def)
```

## Debugging with Snapshots

Track optimization steps:

```python
optimizer = ContextOptimizer()
result = optimizer.optimize(messages)

# Get optimization history
snapshots = optimizer.get_snapshots()

for snapshot in snapshots:
    print(f"Operation: {snapshot.operation}")
    print(f"  Messages: {len(snapshot.window)}")
    print(f"  Tokens: {snapshot.window.current_tokens}")
```

## Statistics and Metrics

Access detailed optimization statistics:

```python
result = optimizer.optimize(messages)
stats = result.stats

print(f"Original: {stats.original_messages} messages, {stats.original_tokens} tokens")
print(f"Optimized: {stats.optimized_messages} messages, {stats.optimized_tokens} tokens")
print(f"Pruned: {stats.pruned_count} messages")
print(f"Tokens saved: {stats.tokens_saved}")
print(f"Reduction: {stats.token_reduction * 100:.1f}%")
print(f"Strategy: {stats.strategy_used}")
print(f"Time: {stats.operation_time_ms:.2f}ms")
```

## Best Practices

### 1. Choose the Right Strategy

```python
# For chat applications: preserve recent context
config = OptimizationConfig(
    pruning_strategy=PruningStrategy.RECENCY,
    preserve_recent=5,
)

# For search/RAG: keep relevant content
config = OptimizationConfig(
    pruning_strategy=PruningStrategy.RELEVANCE,
)
result = optimizer.optimize(messages, query=user_query)

# For agents: keep important decisions
config = OptimizationConfig(
    pruning_strategy=PruningStrategy.IMPORTANCE,
)
```

### 2. Always Preserve System Messages

```python
config = OptimizationConfig(
    preserve_system=True,  # Default
)
```

### 3. Set Appropriate Token Limits

```python
# Leave room for response
max_context = 4096
reserved_for_response = 1024
config = OptimizationConfig(
    max_tokens=max_context - reserved_for_response,
)
```

### 4. Use Summarization for Long Conversations

```python
config = OptimizationConfig(
    enable_summarization=True,
    summarization_ratio=0.3,  # 30% of original size
)
```

### 5. Handle Tool Results

```python
# Truncate verbose tool outputs
pruner = ContextPruner()
result = pruner.prune_tool_results(
    messages,
    max_result_length=500,
    truncate_instead=True,
)
```

## Integration Example

Complete integration with OpenAI:

```python
from openai import OpenAI
from multi_agent_base.context import (
    ContextOptimizer,
    OptimizationConfig,
    PruningStrategy,
)

client = OpenAI()

def chat_with_context_management(conversation: list, user_input: str) -> str:
    """Chat with automatic context management."""
    
    # Add user message
    conversation.append({"role": "user", "content": user_input})
    
    # Optimize context to fit token limit
    optimizer = ContextOptimizer(
        config=OptimizationConfig(
            max_tokens=3000,  # Leave room for response
            preserve_recent=5,
            pruning_strategy=PruningStrategy.SMART,
        )
    )
    
    result = optimizer.optimize(conversation)
    
    if result.stats.pruned_count > 0:
        print(f"Pruned {result.stats.pruned_count} messages to fit context")
    
    # Make API call with optimized messages
    response = client.chat.completions.create(
        model="gpt-4",
        messages=result.to_list(),
        max_tokens=1000,
    )
    
    assistant_message = response.choices[0].message.content
    conversation.append({"role": "assistant", "content": assistant_message})
    
    return assistant_message
```

## API Reference

### Types

| Type | Description |
|------|-------------|
| `MessageRole` | Enum: SYSTEM, USER, ASSISTANT, TOOL, FUNCTION |
| `PruningStrategy` | Enum: RECENCY, RELEVANCE, IMPORTANCE, SLIDING_WINDOW, SMART |
| `CompressionMethod` | Enum: SUMMARIZE, MERGE, EXTRACT_KEY_POINTS, HIERARCHICAL |
| `ContextMessage` | Message with metadata (role, content, importance, etc.) |
| `ContextWindow` | Container for messages with token tracking |
| `ContextStats` | Optimization statistics |
| `OptimizationConfig` | Configuration for optimization |
| `ToolContext` | Tool definition with usage tracking |
| `ContextSnapshot` | Snapshot of context state |

### Classes

| Class | Description |
|-------|-------------|
| `ContextOptimizer` | Main optimization orchestrator |
| `ContextPruner` | Specialized pruning utilities |
| `ConversationPruner` | Conversation-aware pruning |
| `ContextCompressor` | Compression and summarization |
| `TokenEstimator` | Token count estimation |

### Results

| Result Type | Contains |
|-------------|----------|
| `OptimizationResult` | window, stats, summary, snapshots |
| `PruningResult` | kept, pruned, stats |
| `CompressionResult` | messages, stats, summaries, merged_count |
