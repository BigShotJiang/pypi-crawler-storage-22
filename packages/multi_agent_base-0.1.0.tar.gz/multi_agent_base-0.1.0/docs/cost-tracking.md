# Cost Tracking

Monitor and analyze LLM usage costs across your agent system.

## Overview

The Cost Tracking module provides:
- Token usage recording
- Cost calculation per model
- Aggregation by agent, provider, model
- Export to various formats
- Persistent storage

## Basic Usage

```python
from multi_agent_base.cost import CostTracker, create_tracker

# Create tracker
tracker = CostTracker()

# Record usage
tracker.record(
    agent_name="assistant",
    provider="openai",
    model="gpt-4o-mini",
    input_tokens=100,
    output_tokens=50,
)

# Get summary
summary = tracker.get_summary()
print(summary)
```

## Integration with Patterns

```python
from multi_agent_base import SystemConfig, SingleAgentPattern
from multi_agent_base.cost import CostTracker

tracker = CostTracker()

config = SystemConfig.from_env()
pattern = SingleAgentPattern(config, cost_tracker=tracker)

agent = pattern.create_agent(
    name="assistant",
    system_prompt="You are helpful.",
)

# Run agent - costs are tracked automatically
result = await pattern.run("Hello!")
print(f"Cost: ${result.total_cost:.6f}")

# Get full summary
summary = tracker.get_summary()
print(summary)
```

## Recording Usage

### Automatic Recording

When using patterns with a cost tracker, usage is recorded automatically.

### Manual Recording

```python
# Record with auto-calculated cost
tracker.record(
    agent_name="assistant",
    provider="openai",
    model="gpt-4o-mini",
    input_tokens=1000,
    output_tokens=500,
)

# Record with pre-calculated cost
tracker.record(
    agent_name="assistant",
    provider="openai",
    model="gpt-4o-mini",
    input_tokens=1000,
    output_tokens=500,
    cost=0.0015,  # Override calculation
)

# Record with metadata
tracker.record(
    agent_name="assistant",
    provider="anthropic",
    model="claude-3-5-sonnet-20241022",
    input_tokens=500,
    output_tokens=200,
    metadata={
        "task": "summarization",
        "user_id": "user-123",
    },
)
```

## Cost Calculation

### Using PricingCalculator

```python
from multi_agent_base.providers import PricingCalculator, ModelPricing

# Calculate cost
cost = PricingCalculator.calculate(
    provider="openai",
    model="gpt-4o-mini",
    input_tokens=1000,
    output_tokens=500,
)
print(f"Cost: ${cost:.6f}")

# Get pricing info
pricing = PricingCalculator.get_pricing("openai", "gpt-4o-mini")
print(f"Input: ${pricing.input_price}/1M tokens")
print(f"Output: ${pricing.output_price}/1M tokens")

# List available models
models = PricingCalculator.list_models("openai")
print(models)

# Estimate from character count
estimated = PricingCalculator.estimate_cost(
    provider="openai",
    model="gpt-4o-mini",
    prompt_chars=4000,
    expected_output_chars=2000,
)
print(f"Estimated: ${estimated:.6f}")
```

### Custom Pricing

```python
from multi_agent_base.providers import PricingCalculator, ModelPricing

# Register custom model pricing
PricingCalculator.register_pricing(
    provider="custom",
    model="my-model",
    pricing=ModelPricing(
        input_price=1.00,   # $1.00 per 1M input tokens
        output_price=3.00,  # $3.00 per 1M output tokens
        context_window=32000,
    ),
)
```

## Querying Records

### Get Records

```python
# All records
all_records = tracker.get_records()

# Filter by agent
agent_records = tracker.get_records(agent_name="assistant")

# Filter by provider
openai_records = tracker.get_records(provider="openai")

# Filter by model
gpt4_records = tracker.get_records(model="gpt-4o-mini")

# Filter by time range
from datetime import datetime, timedelta

start = datetime.now() - timedelta(hours=1)
recent_records = tracker.get_records(start_time=start)
```

### Get Summary

```python
# Full summary
summary = tracker.get_summary()
print(summary)

# Summary for specific agent
agent_summary = tracker.get_summary(agent_name="assistant")

# Summary for time period
from datetime import datetime, timedelta

start = datetime.now() - timedelta(days=7)
weekly_summary = tracker.get_summary(start_time=start)
```

### Summary Output

```
==================================================
Cost Summary
==================================================
Total Cost: $0.001234
Total Tokens: 1,500
  - Input: 1,000
  - Output: 500
Record Count: 5
Avg Cost/Call: $0.000247
Avg Tokens/Call: 300.0

By Agent:
  assistant: $0.001000 (1,200 tokens)
  researcher: $0.000234 (300 tokens)

By Model:
  gpt-4o-mini: $0.000900 (1,000 tokens)
  claude-3-5-haiku: $0.000334 (500 tokens)
==================================================
```

## Exporting Data

### JSON Export

```python
# Export to JSON with summary
tracker.export("reports/costs.json", format="json")
```

Output:
```json
{
  "records": [
    {
      "timestamp": "2024-01-15T14:30:00",
      "agent_name": "assistant",
      "provider": "openai",
      "model": "gpt-4o-mini",
      "input_tokens": 100,
      "output_tokens": 50,
      "total_tokens": 150,
      "cost": 0.000045
    }
  ],
  "summary": {
    "total_cost": 0.000045,
    "total_tokens": 150,
    ...
  }
}
```

### JSONL Export

```python
# Export as JSON Lines (one record per line)
tracker.export("reports/costs.jsonl", format="jsonl")
```

### CSV Export

```python
# Export to CSV
tracker.export("reports/costs.csv", format="csv")
```

## Persistence

### Auto-Persistence

```python
# Create tracker with auto-persistence
tracker = CostTracker(
    auto_persist=True,
    persist_path="./data/cost_records.jsonl",
)

# Records are automatically saved after each record()
```

### Manual Persistence

```python
tracker = CostTracker(persist_path="./data/costs.jsonl")

# ... add records ...

# Manually persist
tracker.persist()
```

### Loading Existing Records

```python
# Records are automatically loaded from persist_path
tracker = CostTracker(persist_path="./data/existing_costs.jsonl")

# Check loaded records
print(f"Loaded {len(tracker)} records")
```

## Pricing Data

### Supported Providers

| Provider | Models | Notes |
|----------|--------|-------|
| OpenAI | GPT-4o, GPT-4o-mini, GPT-4, GPT-3.5, o1 series | Regular pricing |
| Anthropic | Claude 3.5, Claude 3 family | Regular pricing |
| Ollama | All models | Free (local) |

### OpenAI Pricing (per 1M tokens)

| Model | Input | Output |
|-------|-------|--------|
| gpt-4o | $2.50 | $10.00 |
| gpt-4o-mini | $0.15 | $0.60 |
| gpt-4-turbo | $10.00 | $30.00 |
| o1 | $15.00 | $60.00 |
| o1-mini | $3.00 | $12.00 |

### Anthropic Pricing (per 1M tokens)

| Model | Input | Output |
|-------|-------|--------|
| claude-3-5-sonnet | $3.00 | $15.00 |
| claude-3-5-haiku | $0.80 | $4.00 |
| claude-3-opus | $15.00 | $75.00 |

## Best Practices

1. **Track by Agent**: Use meaningful agent names for attribution
2. **Use Metadata**: Add context like task type, user ID
3. **Regular Exports**: Export data regularly for analysis
4. **Set Budgets**: Monitor total_cost against budgets
5. **Use Ollama**: For development, use Ollama (free) to avoid costs

## Example: Budget Monitoring

```python
from multi_agent_base.cost import CostTracker

DAILY_BUDGET = 10.00  # $10/day

tracker = CostTracker(
    auto_persist=True,
    persist_path="./costs.jsonl",
)

async def run_with_budget_check(pattern, message):
    from datetime import datetime, timedelta
    
    # Check today's spending
    today_start = datetime.now().replace(hour=0, minute=0, second=0)
    today_summary = tracker.get_summary(start_time=today_start)
    
    if today_summary.total_cost >= DAILY_BUDGET:
        raise Exception("Daily budget exceeded!")
    
    remaining = DAILY_BUDGET - today_summary.total_cost
    print(f"Budget remaining: ${remaining:.2f}")
    
    result = await pattern.run(message)
    return result
```
