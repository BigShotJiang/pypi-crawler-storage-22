# Cost Optimization Engine

A comprehensive cost management system for AI agent operations, providing budget management, cost-optimized model selection, cost estimation, and analysis tools.

## Overview

The Cost Optimization Engine provides:

- **Budget Management**: Set limits, track usage, receive alerts
- **Model Selection**: Choose optimal models based on cost, quality, and requirements
- **Cost Estimation**: Predict costs before execution
- **Cost Analysis**: Analyze trends, detect anomalies, get optimization recommendations

## Quick Start

```python
from multi_agent_base.cost import (
    BudgetManager,
    BudgetLimit,
    BudgetPeriod,
    BudgetAction,
    ModelSelector,
    SelectionCriteria,
    OptimizationGoal,
    CostEstimator,
    CostAnalyzer,
    CostDataPoint,
)
from datetime import datetime, timezone

# 1. Set up budget
manager = BudgetManager()
manager.add_limit(BudgetLimit(
    name="daily_limit",
    amount=50.0,  # $50 daily budget
    period=BudgetPeriod.DAILY,
    action=BudgetAction.WARN,
    alert_thresholds=[0.5, 0.8, 0.95],
))

# 2. Select optimal model
selector = ModelSelector()
result = selector.select(SelectionCriteria(
    goal=OptimizationGoal.BALANCED,
    min_quality=80,
    required_capabilities=["function_calling"],
))
print(f"Selected: {result.selected_model.name}")

# 3. Estimate cost
estimator = CostEstimator()
estimate = estimator.estimate(
    model=result.selected_model.name,
    input_text="What is machine learning?",
    expected_output_tokens=500,
)
print(f"Estimated cost: ${estimate.estimated_cost:.4f}")

# 4. Check budget before operation
status = manager.check_budget("global", estimate.estimated_cost)
if status.action == BudgetAction.ALLOW:
    # Proceed with operation
    manager.record_usage("global", estimate.estimated_cost)
```

## Budget Management

### Creating Budget Limits

```python
from multi_agent_base.cost import (
    BudgetManager,
    BudgetLimit,
    BudgetPeriod,
    BudgetAction,
)

manager = BudgetManager()

# Daily limit with blocking
manager.add_limit(BudgetLimit(
    name="daily",
    amount=100.0,
    period=BudgetPeriod.DAILY,
    action=BudgetAction.BLOCK,
    alert_thresholds=[0.5, 0.75, 0.9],
))

# Monthly limit with warning
manager.add_limit(BudgetLimit(
    name="monthly",
    amount=1000.0,
    period=BudgetPeriod.MONTHLY,
    action=BudgetAction.WARN,
))

# Per-agent limit
manager.add_limit(BudgetLimit(
    name="agent_researcher",
    amount=25.0,
    period=BudgetPeriod.DAILY,
    scope="agent:researcher",
))
```

### Budget Periods

| Period | Description |
|--------|-------------|
| `HOURLY` | Resets every hour |
| `DAILY` | Resets at midnight |
| `WEEKLY` | Resets weekly |
| `MONTHLY` | Resets monthly |
| `TOTAL` | Never resets |

### Budget Actions

| Action | Description |
|--------|-------------|
| `ALLOW` | Allow operation |
| `WARN` | Warn but allow |
| `BLOCK` | Block operation |
| `DOWNGRADE` | Suggest cheaper model |

### Alert Handling

```python
def on_budget_alert(alert):
    print(f"[{alert.severity.value.upper()}] {alert.message}")
    if alert.severity == AlertSeverity.CRITICAL:
        send_notification(alert.message)

manager.add_alert_handler(on_budget_alert)
```

### Checking and Recording Usage

```python
# Check before operation
status = manager.check_budget("global", estimated_cost=0.50)
if status.action == BudgetAction.BLOCK:
    print(f"Budget exceeded: ${status.current_usage:.2f}/${status.limit_amount:.2f}")
    return

# Record actual usage
alerts = manager.record_usage("global", 0.45)
for alert in alerts:
    print(f"Alert: {alert.message}")
```

### Using BudgetConfig

```python
from multi_agent_base.cost import BudgetConfig

config = BudgetConfig(
    limits=[
        {"name": "daily", "amount": 100.0, "period": "daily"},
        {"name": "monthly", "amount": 1000.0, "period": "monthly"},
    ],
    default_action=BudgetAction.WARN,
)

manager = config.create_manager()
```

## Model Selection

### Basic Selection

```python
from multi_agent_base.cost import (
    ModelSelector,
    SelectionCriteria,
    OptimizationGoal,
    TaskComplexity,
)

selector = ModelSelector()

# Cost-optimized selection
result = selector.select(SelectionCriteria(
    goal=OptimizationGoal.COST,
    min_quality=70,
))
print(f"Cheapest: {result.selected_model.name} at ${result.selected_model.avg_cost}/1M")

# Quality-optimized selection
result = selector.select(SelectionCriteria(
    goal=OptimizationGoal.QUALITY,
))
print(f"Best quality: {result.selected_model.name} with score {result.selected_model.quality_score}")
```

### Selection Criteria

| Criterion | Description |
|-----------|-------------|
| `goal` | Optimization goal (COST, QUALITY, BALANCED, LATENCY, THROUGHPUT) |
| `min_quality` | Minimum quality score (0-100) |
| `max_cost_per_1m` | Maximum cost per 1M tokens |
| `max_latency_ms` | Maximum acceptable latency |
| `required_capabilities` | Required model capabilities |
| `required_tokens` | Required context length |
| `preferred_providers` | Preferred providers in order |
| `complexity` | Task complexity level |

### Task Complexity Selection

```python
# Simple tasks use cheaper models
result = selector.select_for_complexity(TaskComplexity.SIMPLE)

# Expert tasks use high-quality models
result = selector.select_for_complexity(TaskComplexity.EXPERT)
```

### Budget-Based Selection

```python
# Select best model within budget
result = selector.select_for_budget(
    budget=0.10,  # $0.10 available
    estimated_tokens=50000,
    min_quality=75,
)
```

### Comparing Models

```python
comparisons = selector.compare_models(
    model_names=["gpt-4o", "gpt-4o-mini", "claude-3-5-sonnet-20241022"],
    input_tokens=1000,
    output_tokens=500,
)

for c in comparisons:
    print(f"{c['name']}: ${c['estimated_cost']:.4f}, quality: {c['quality']}")
```

### Custom Model Profiles

```python
from multi_agent_base.cost import ModelProfile

# Add custom model
selector.add_profile(ModelProfile(
    name="my-fine-tuned-model",
    provider="openai",
    input_cost=5.0,
    output_cost=15.0,
    quality_score=92,
    latency_ms=450,
    max_tokens=128000,
    capabilities=["function_calling", "json_mode"],
))
```

## Cost Estimation

### Basic Estimation

```python
from multi_agent_base.cost import CostEstimator

estimator = CostEstimator()

# Estimate from text
estimate = estimator.estimate(
    model="gpt-4o",
    input_text="Your prompt here...",
    expected_output_tokens=500,
)
print(f"Estimated: ${estimate.estimated_cost:.4f}")

# Estimate from token counts
estimate = estimator.estimate(
    model="gpt-4o",
    input_tokens=1000,
    expected_output_tokens=500,
)
```

### Batch Estimation

```python
items = ["Query 1", "Query 2", "Query 3"]
estimate = estimator.estimate_batch(
    model="gpt-4o",
    items=items,
    expected_output_per_item=200,
)
print(f"Total batch cost: ${estimate.estimated_cost:.4f}")
```

### Cost Comparison

```python
estimates = estimator.compare_costs(
    input_tokens=10000,
    output_tokens=5000,
)

print("Cost comparison:")
for est in estimates[:5]:  # Top 5 cheapest
    print(f"  {est.model}: ${est.estimated_cost:.4f}")
```

## Cost Analysis

### Setting Up the Analyzer

```python
from multi_agent_base.cost import CostAnalyzer, CostDataPoint
from datetime import datetime, timezone, timedelta

analyzer = CostAnalyzer()

# Add cost data points
for i in range(100):
    analyzer.add_data_point(CostDataPoint(
        timestamp=datetime.now(timezone.utc) - timedelta(hours=i),
        cost=0.05 + (i % 10) * 0.01,
        model="gpt-4o" if i % 2 == 0 else "gpt-4o-mini",
        tokens_input=1000,
        tokens_output=500,
        operation="chat" if i % 3 == 0 else "analysis",
    ))
```

### Generating Reports

```python
report = analyzer.generate_report()

print(f"Total Cost: ${report.total_cost:.2f}")
print(f"Total Requests: {report.total_requests:,}")
print(f"Avg Cost/Request: ${report.avg_cost_per_request:.4f}")
print(f"Avg Daily Cost: ${report.avg_daily_cost:.2f}")

# Trend analysis
if report.trend:
    print(f"\nTrend: {report.trend.direction.value}")
    print(f"Change: {report.trend.change_percent:+.1f}%")
    print(f"Projected: ${report.trend.projected_cost:.2f}/month")

# Model breakdown
print("\nCost by Model:")
for m in report.model_breakdown:
    print(f"  {m.model}: ${m.total_cost:.2f} ({m.percentage_of_total:.1f}%)")

# Recommendations
print("\nRecommendations:")
for r in report.recommendations:
    print(f"  [{r.priority}] {r.title}")
    print(f"      Potential savings: ${r.potential_savings:.2f}/month")
```

### Markdown Report

```python
md_report = report.to_markdown()
print(md_report)

# Save to file
with open("cost_report.md", "w") as f:
    f.write(md_report)
```

### Anomaly Detection

```python
anomalies = analyzer.detect_anomalies()

for a in anomalies:
    print(f"[{a.severity.upper()}] {a.description}")
    print(f"  Expected: ${a.expected_cost:.4f}, Actual: ${a.actual_cost:.4f}")
```

### Time Series Data

```python
from multi_agent_base.cost import TimeGranularity

# Daily time series
daily = analyzer.get_time_series(TimeGranularity.DAILY)
for point in daily:
    print(f"{point['period']}: ${point['cost']:.2f} ({point['requests']} requests)")

# Hourly time series
hourly = analyzer.get_time_series(TimeGranularity.HOURLY)
```

## Complete Workflow Example

```python
from multi_agent_base.cost import (
    BudgetManager,
    BudgetLimit,
    BudgetPeriod,
    BudgetAction,
    ModelSelector,
    SelectionCriteria,
    OptimizationGoal,
    TaskComplexity,
    CostEstimator,
    CostAnalyzer,
    CostDataPoint,
)
from datetime import datetime, timezone

class CostAwareAgent:
    def __init__(self, daily_budget: float = 50.0):
        # Set up budget
        self.budget = BudgetManager()
        self.budget.add_limit(BudgetLimit(
            name="daily",
            amount=daily_budget,
            period=BudgetPeriod.DAILY,
            action=BudgetAction.WARN,
        ))
        
        # Set up selector and estimator
        self.selector = ModelSelector()
        self.estimator = CostEstimator(selector=self.selector)
        
        # Set up analyzer
        self.analyzer = CostAnalyzer()
    
    def select_model(self, task_complexity: TaskComplexity):
        """Select optimal model for task."""
        return self.selector.select_for_complexity(task_complexity)
    
    def can_afford(self, model: str, input_text: str) -> tuple[bool, float]:
        """Check if we can afford this operation."""
        estimate = self.estimator.estimate(
            model=model,
            input_text=input_text,
            expected_output_tokens=500,
        )
        
        status = self.budget.check_budget("global", estimate.estimated_cost)
        return status.action != BudgetAction.BLOCK, estimate.estimated_cost
    
    def record_cost(self, cost: float, model: str, operation: str):
        """Record actual cost."""
        # Record in budget
        self.budget.record_usage("global", cost)
        
        # Track for analysis
        self.analyzer.add_data_point(CostDataPoint(
            timestamp=datetime.now(timezone.utc),
            cost=cost,
            model=model,
            operation=operation,
        ))
    
    def get_daily_report(self) -> str:
        """Get cost report."""
        return self.analyzer.generate_report().to_markdown()

# Usage
agent = CostAwareAgent(daily_budget=50.0)

# Select model based on task
result = agent.select_model(TaskComplexity.MODERATE)
model = result.selected_model.name

# Check affordability
prompt = "Explain quantum computing in simple terms"
can_proceed, estimated_cost = agent.can_afford(model, prompt)

if can_proceed:
    print(f"Proceeding with {model}, estimated cost: ${estimated_cost:.4f}")
    # ... execute LLM call ...
    agent.record_cost(estimated_cost, model, "explanation")
else:
    print("Budget exceeded, consider waiting or using cheaper model")
```

## Built-in Model Profiles

The system includes profiles for popular models:

| Model | Provider | Input Cost | Output Cost | Quality |
|-------|----------|------------|-------------|---------|
| gpt-4o | OpenAI | $2.50 | $10.00 | 95 |
| gpt-4o-mini | OpenAI | $0.15 | $0.60 | 82 |
| gpt-4-turbo | OpenAI | $10.00 | $30.00 | 90 |
| gpt-3.5-turbo | OpenAI | $0.50 | $1.50 | 70 |
| claude-3-5-sonnet | Anthropic | $3.00 | $15.00 | 94 |
| claude-3-5-haiku | Anthropic | $0.25 | $1.25 | 78 |
| claude-3-opus | Anthropic | $15.00 | $75.00 | 97 |
| gemini-1.5-pro | Google | $1.25 | $5.00 | 88 |
| gemini-1.5-flash | Google | $0.075 | $0.30 | 75 |

*Costs per 1M tokens (as of 2024)*

## Best Practices

1. **Set multiple budget levels**: Use daily, weekly, and monthly limits for comprehensive control.

2. **Use task complexity**: Match model quality to task requirements to optimize costs.

3. **Monitor trends**: Regularly review cost reports to identify optimization opportunities.

4. **Set up alerts**: Configure alert handlers to get notified before budget exhaustion.

5. **Track by operation**: Use operation labels to identify costly workflows.

6. **Pre-check budgets**: Always check budget status before expensive operations.

7. **Cache responses**: For repetitive queries, implement caching to reduce API calls.

## API Reference

### Budget Module

- `BudgetManager`: Manages budget limits and tracks usage
- `BudgetLimit`: Budget limit configuration
- `BudgetPeriod`: Time period enum
- `BudgetAction`: Action when limit reached
- `BudgetAlert`: Alert notification
- `BudgetStatus`: Current budget status
- `BudgetConfig`: Configuration for budget management
- `AlertSeverity`: Alert severity levels
- `MemoryBudgetStorage`: In-memory storage

### Optimization Module

- `ModelSelector`: Intelligent model selection
- `ModelProfile`: Model capabilities and costs
- `SelectionCriteria`: Selection parameters
- `SelectionResult`: Selection outcome
- `TaskComplexity`: Task complexity levels
- `OptimizationGoal`: Optimization goals
- `CostEstimator`: Cost prediction
- `CostEstimate`: Cost estimate result

### Analysis Module

- `CostAnalyzer`: Cost data analysis
- `CostDataPoint`: Individual cost record
- `CostTrend`: Trend analysis result
- `CostReport`: Comprehensive report
- `CostAnomaly`: Detected anomaly
- `ModelCostBreakdown`: Per-model cost breakdown
- `OperationCostBreakdown`: Per-operation breakdown
- `OptimizationRecommendation`: Optimization suggestion
- `TimeGranularity`: Time aggregation level
- `TrendDirection`: Trend direction
