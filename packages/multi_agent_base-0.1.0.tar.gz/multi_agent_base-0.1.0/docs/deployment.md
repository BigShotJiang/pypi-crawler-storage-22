# Deployment Guide

This guide covers deploying Multi-Agent Base applications to production.

## Pre-Deployment Checklist

- [ ] Environment variables configured
- [ ] API keys secured
- [ ] Rate limiting configured
- [ ] Logging enabled
- [ ] Health checks configured
- [ ] Metrics endpoint exposed
- [ ] Error handling tested

## Docker Deployment

### Dockerfile

```dockerfile
FROM python:3.12-slim

WORKDIR /app

# Install dependencies
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copy application
COPY src/ ./src/
COPY main.py .

# Non-root user
RUN useradd -m appuser && chown -R appuser /app
USER appuser

# Health check
HEALTHCHECK --interval=30s --timeout=10s \
  CMD python -c "import urllib.request; urllib.request.urlopen('http://localhost:8000/health')"

# Start application
CMD ["python", "main.py"]
```

### Docker Compose

```yaml
version: "3.8"

services:
  agent:
    build: .
    ports:
      - "8000:8000"
    environment:
      - OPENAI_API_KEY=${OPENAI_API_KEY}
      - REDIS_URL=redis://redis:6379
      - PHOENIX_ENDPOINT=http://phoenix:6006
    depends_on:
      - redis
      - phoenix
    deploy:
      replicas: 3
      resources:
        limits:
          memory: 1G
        reservations:
          memory: 512M
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8000/health"]
      interval: 30s
      timeout: 10s
      retries: 3

  redis:
    image: redis:7-alpine
    volumes:
      - redis_data:/data

  phoenix:
    image: arizephoenix/phoenix:latest
    ports:
      - "6006:6006"

volumes:
  redis_data:
```

## Kubernetes Deployment

### Deployment

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: agent-service
spec:
  replicas: 3
  selector:
    matchLabels:
      app: agent-service
  template:
    metadata:
      labels:
        app: agent-service
    spec:
      containers:
        - name: agent
          image: your-registry/agent-service:latest
          ports:
            - containerPort: 8000
          env:
            - name: OPENAI_API_KEY
              valueFrom:
                secretKeyRef:
                  name: api-keys
                  key: openai
            - name: REDIS_URL
              value: "redis://redis-service:6379"
          resources:
            requests:
              memory: "512Mi"
              cpu: "250m"
            limits:
              memory: "1Gi"
              cpu: "1"
          livenessProbe:
            httpGet:
              path: /health/live
              port: 8000
            initialDelaySeconds: 10
            periodSeconds: 30
          readinessProbe:
            httpGet:
              path: /health/ready
              port: 8000
            initialDelaySeconds: 5
            periodSeconds: 10
```

### Service

```yaml
apiVersion: v1
kind: Service
metadata:
  name: agent-service
spec:
  selector:
    app: agent-service
  ports:
    - port: 80
      targetPort: 8000
  type: LoadBalancer
```

### Secrets

```yaml
apiVersion: v1
kind: Secret
metadata:
  name: api-keys
type: Opaque
data:
  openai: <base64-encoded-key>
  anthropic: <base64-encoded-key>
```

## Health Checks

### Basic Health Endpoint

```python
from fastapi import FastAPI
from multi_agent_base.monitoring import create_health_check

app = FastAPI()
health = create_health_check(name="my-agent-service", version="1.0.0")

@app.get("/health")
async def health_check():
    result = await health.run_checks()
    status_code = 200 if result.is_healthy else 503
    return JSONResponse(result.to_dict(), status_code=status_code)

@app.get("/health/live")
async def liveness():
    result = await health.liveness()
    return result.to_dict()

@app.get("/health/ready")
async def readiness():
    result = await health.readiness()
    status_code = 200 if result.is_healthy else 503
    return JSONResponse(result.to_dict(), status_code=status_code)
```

### Custom Health Checks

```python
async def check_llm_provider():
    try:
        # Quick test
        response = await client.generate([{"role": "user", "content": "ping"}])
        return {"status": "healthy", "message": "LLM responding"}
    except Exception as e:
        return {"status": "unhealthy", "message": str(e)}

health.add_check("llm_provider", check_llm_provider)
```

## Metrics & Monitoring

### Prometheus Metrics

```python
from fastapi import FastAPI, Response
from multi_agent_base.monitoring import get_metrics

app = FastAPI()
metrics = get_metrics()

@app.get("/metrics")
def prometheus_metrics():
    return Response(
        content=metrics.export_prometheus(),
        media_type="text/plain",
    )
```

### Grafana Dashboard

Import our pre-built dashboard (coming soon) or create custom panels:

**Key Metrics:**
- `agent_requests_total` - Request count by agent/status
- `agent_request_duration_seconds` - Request latency
- `agent_tokens_total` - Token usage
- `agent_cost_total` - API costs
- `agent_errors_total` - Error count

### Alerting Rules

```yaml
groups:
  - name: agent-alerts
    rules:
      - alert: HighErrorRate
        expr: rate(agent_errors_total[5m]) > 0.1
        for: 5m
        labels:
          severity: warning
        annotations:
          summary: High error rate on agent {{ $labels.agent_name }}

      - alert: HighLatency
        expr: histogram_quantile(0.99, agent_request_duration_seconds_bucket) > 30
        for: 5m
        labels:
          severity: warning
        annotations:
          summary: High latency on agent {{ $labels.agent_name }}

      - alert: BudgetExceeded
        expr: agent_cost_total > 100
        for: 1m
        labels:
          severity: critical
        annotations:
          summary: Budget exceeded for {{ $labels.agent_name }}
```

## Observability

### Phoenix Setup

```python
from multi_agent_base.observability import PhoenixTracer, PhoenixConfig

tracer = PhoenixTracer(config=PhoenixConfig(
    endpoint="http://phoenix:6006",
    project_name="production-agents",
    enabled=True,
))
tracer.setup()
```

### Logging Configuration

```python
import logging
from multi_agent_base.observability import AgentLogger

# Configure structured logging
logging.basicConfig(
    format='%(asctime)s %(levelname)s %(name)s %(message)s',
    level=logging.INFO,
)

logger = AgentLogger(
    name="production",
    log_level="INFO",
    log_format="json",  # For log aggregation
)
```

## Security

### Secret Management

```python
from multi_agent_base.security import SecretManager

# Use environment variables
secrets = SecretManager()
api_key = secrets.get("OPENAI_API_KEY")

# For production, integrate with vault
# secrets = SecretManager(backend="vault", vault_url="...")
```

### Input Validation

```python
from multi_agent_base.security import InputValidator, InjectionDetector

validator = InputValidator()
detector = InjectionDetector()

@app.post("/agent")
async def agent_endpoint(request: AgentRequest):
    # Validate input
    validation = validator.validate(request.message)
    if not validation.is_valid:
        raise HTTPException(400, validation.errors)
    
    # Check for injection
    injection = detector.detect(request.message)
    if not injection.is_safe:
        logger.warning(f"Injection attempt: {injection.threats}")
        raise HTTPException(400, "Invalid input")
    
    return await agent.run(request.message)
```

## Scaling

### Horizontal Scaling

For distributed deployments:

```python
from multi_agent_base.ratelimit import RedisRateLimiter, RateLimitConfig
import redis.asyncio as redis

# Shared rate limiter across instances
redis_client = redis.Redis.from_url(os.environ["REDIS_URL"])

limiter = RedisRateLimiter(
    config=RateLimitConfig(
        requests_per_minute=1000,  # Total across all instances
        tokens_per_minute=100000,
    ),
    redis_client=redis_client,
    key_prefix="production:ratelimit",
)
```

### Auto-scaling

```yaml
# Kubernetes HPA
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: agent-hpa
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: agent-service
  minReplicas: 2
  maxReplicas: 10
  metrics:
    - type: Resource
      resource:
        name: cpu
        target:
          type: Utilization
          averageUtilization: 70
    - type: Pods
      pods:
        metric:
          name: agent_requests_per_second
        target:
          type: AverageValue
          averageValue: 100
```

## Graceful Shutdown

```python
import signal
import asyncio

async def shutdown(signal, loop):
    """Cleanup tasks on shutdown."""
    print(f"Received exit signal {signal.name}...")
    
    # Stop accepting new requests
    # Complete in-flight requests
    # Close connections
    
    tasks = [t for t in asyncio.all_tasks() if t is not asyncio.current_task()]
    [task.cancel() for task in tasks]
    
    await asyncio.gather(*tasks, return_exceptions=True)
    loop.stop()

# Register signal handlers
loop = asyncio.get_event_loop()
for sig in (signal.SIGTERM, signal.SIGINT):
    loop.add_signal_handler(sig, lambda s=sig: asyncio.create_task(shutdown(s, loop)))
```

## Troubleshooting

### Common Issues

**High memory usage**
- Check for memory leaks in conversation history
- Use memory backends with limits
- Configure max_entries in MemoryConfig

**Slow responses**
- Check network latency to LLM provider
- Review timeout settings
- Consider caching frequent queries

**Rate limit errors**
- Implement proper rate limiting
- Use Redis for distributed limiting
- Consider multiple API keys

### Debug Mode

```python
import logging

# Enable debug logging
logging.getLogger("multi_agent_base").setLevel(logging.DEBUG)
```
