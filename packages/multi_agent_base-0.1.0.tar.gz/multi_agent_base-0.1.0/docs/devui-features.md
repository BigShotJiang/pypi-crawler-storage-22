# DevUI Özellikleri

Agent Framework DevUI, agent ve workflow geliştirme sürecini kolaylaştıran interaktif bir web arayüzüdür.

---

## DevUI Nedir?

DevUI şu özellikleri sunar:

| Özellik | Açıklama |
|---------|----------|
| 🤖 Agent Chat | Agent'larla interaktif sohbet |
| 📊 Workflow Viz | Workflow'ları gerçek zamanlı görselleştirme |
| 📋 Events Panel | Executor event'lerini izleme |
| 🔍 Traces Panel | OpenTelemetry trace'leri |
| 🔧 Tools Panel | Tool çağrılarını görme |
| 💾 Checkpoints | Workflow durumlarını kaydetme |

---

## Hızlı Başlatma

### Agent Demo

```bash
./scripts/run_devui_agent.sh
```

**URL:** http://localhost:8080

### Workflow Demo

```bash
./scripts/run_devui_workflow.sh
```

**URL:** http://localhost:8080

---

## Agent Chat Interface

### Temel Kullanım

```python
from agent_framework import ChatAgent, tool
from agent_framework.ollama import OllamaChatClient
from agent_framework.devui import serve

@tool
def my_tool(param: str) -> str:
    """Tool açıklaması."""
    return f"Sonuç: {param}"

client = OllamaChatClient(model_id="qwen2.5-coder:7b")
agent = ChatAgent(chat_client=client, tools=[my_tool])

serve(entities=[agent], port=8080, auto_open=True)
```

### UI Bileşenleri

```
┌─────────────────────────────────────────────────────────────┐
│  Dev UI    │ Agent: MyAssistant          │ + New Conversation│
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  A helpful AI assistant                                     │
│                                                             │
│  ┌─────────────────────────────────────────────────────┐   │
│  │ User: Saat kaç?                                      │   │
│  └─────────────────────────────────────────────────────┘   │
│                                                             │
│  ┌─────────────────────────────────────────────────────┐   │
│  │ 🤖 get_current_time() çağrıldı                       │   │
│  │ Agent: Şu an saat 14:30                              │   │
│  └─────────────────────────────────────────────────────┘   │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│  [Mesajınızı yazın...]                          [Gönder]   │
└─────────────────────────────────────────────────────────────┘
```

---

## Workflow Visualization

### Temel Kullanım

```python
from agent_framework import Executor, WorkflowBuilder, WorkflowContext, handler
from agent_framework.devui import serve

class Step1(Executor):
    @handler
    async def handle(self, input: str, ctx: WorkflowContext[str]) -> None:
        await ctx.send_message("Step 1 tamamlandı")

class Step2(Executor):
    @handler
    async def handle(self, input: str, ctx: WorkflowContext[str]) -> None:
        await ctx.send_message("Step 2 tamamlandı")

step1 = Step1(id="step1")
step2 = Step2(id="step2")

workflow = (
    WorkflowBuilder(name="MyWorkflow")
    .set_start_executor(step1)
    .add_edge(step1, step2)
    .build()
)

serve(entities=[workflow], port=8080, auto_open=True)
```

### UI Bileşenleri

```
┌─────────────────────────────────────────────────────────────────────────┐
│  Dev UI    │  Workflow: Email Pipeline  │  6 executors      │ Running...│
├─────────────────────────────────────────────┬───────────────────────────┤
│                                             │                           │
│  Workflow Visualization                     │  Events           Traces  │
│                                             │                           │
│  ┌──────────────────┐                       │  ⚡ 1:45:29 PM            │
│  │ email_preprocess │ ✅ Completed          │    email_preprocessor     │
│  └────────┬─────────┘                       │    completed              │
│           │                                 │                           │
│           ▼                                 │  ⚡ 1:45:30 PM            │
│  ┌──────────────────┐                       │    content_analyzer       │
│  │ content_analyzer │ ✅ Completed          │    completed              │
│  └────────┬─────────┘                       │                           │
│           │                                 │  ⚡ 1:45:31 PM            │
│           ▼                                 │    spam_detector          │
│  ┌──────────────────┐                       │    completed              │
│  │  spam_detector   │ 🔄 Running            │                           │
│  └────────┬─────────┘                       │                           │
│           │                                 │                           │
│           ▼                                 │                           │
│  ┌──────────────────┐                       │                           │
│  │ message_responder│ ⏳ Pending            │                           │
│  └──────────────────┘                       │                           │
│                                             │                           │
├─────────────────────────────────────────────┴───────────────────────────┤
│  Input: {"email": "Hello!"}                                   [Run]     │
└─────────────────────────────────────────────────────────────────────────┘
```

### Executor Durumları

| Durum | Renk | Açıklama |
|-------|------|----------|
| ⏳ Pending | Gri | Henüz başlamadı |
| 🔄 Running | Mavi | Çalışıyor |
| ✅ Completed | Yeşil | Tamamlandı |
| ❌ Failed | Kırmızı | Hata oluştu |
| 🚫 Cancelled | Turuncu | İptal edildi |

---

## Events Panel

Her executor'ın lifecycle event'lerini gösterir:

- **workflow_event.started**: Executor başladı
- **workflow_event.complete**: Executor tamamlandı
- **workflow_event.failed**: Executor hata verdi

---

## Traces Panel

OpenTelemetry entegrasyonu ile:

- LLM çağrıları
- Tool çağrıları
- Executor süreleri
- Hata detayları

### Observability Etkinleştirme

```python
serve(
    entities=[agent],
    port=8080,
    instrumentation_enabled=True,  # Trace collection
)
```

---

## Human-in-the-Loop (HIL)

Workflow'da kullanıcı onayı gerektiren adımlar:

```python
from agent_framework import response_handler

class SpamDetector(Executor):
    @handler
    async def handle(self, email: EmailContent, ctx: WorkflowContext) -> None:
        # AI analizi
        is_spam = await self.analyze(email)
        
        # Kullanıcı onayı iste
        await ctx.request_info(
            request_data=SpamApprovalRequest(
                email=email,
                detected_as_spam=is_spam,
            ),
            response_type=SpamDecision,
        )
    
    @response_handler
    async def handle_response(
        self, 
        request: SpamApprovalRequest, 
        response: SpamDecision, 
        ctx: WorkflowContext
    ) -> None:
        # Kullanıcı kararını işle
        if response.decision == "spam":
            await ctx.send_message(SpamResult(is_spam=True))
        else:
            await ctx.send_message(SpamResult(is_spam=False))
```

---

## Checkpointing

Workflow durumunu kaydetme ve devam ettirme:

```python
workflow = (
    WorkflowBuilder(name="LongRunningWorkflow")
    .set_start_executor(step1)
    .add_edge(step1, step2)
    .with_checkpointing()  # Checkpoint aktif
    .build()
)
```

DevUI'da:
- Checkpoint listesi görüntülenir
- İstediğiniz checkpoint'ten devam edebilirsiniz
- Durum kaybolmaz

---

## Branching Logic

Koşullu yönlendirme:

```python
from agent_framework import Case, Default

workflow = (
    WorkflowBuilder(name="ConditionalWorkflow")
    .set_start_executor(analyzer)
    .add_switch_case_edge_group(
        analyzer,
        [
            Case(
                condition=lambda x: x.is_spam,
                target=spam_handler,
            ),
            Default(
                target=message_handler,
            ),
        ],
    )
    .build()
)
```

---

## serve() Parametreleri

```python
from agent_framework.devui import serve

serve(
    entities=[agent, workflow],     # Agent/Workflow listesi
    port=8080,                      # Port numarası
    host="127.0.0.1",               # Host adresi
    auto_open=True,                 # Tarayıcı otomatik aç
    instrumentation_enabled=True,   # Trace collection
    mode="developer",               # developer/viewer
)
```

| Parametre | Varsayılan | Açıklama |
|-----------|------------|----------|
| `entities` | `None` | Agent/Workflow listesi |
| `port` | `8080` | HTTP port |
| `host` | `127.0.0.1` | Bind adresi |
| `auto_open` | `False` | Tarayıcı otomatik aç |
| `instrumentation_enabled` | `False` | Trace collection |
| `mode` | `developer` | Erişim modu |

---

## Sonraki Adımlar

- [Workflow'lar](./workflows.md) - Detaylı workflow rehberi
- [Observability](./observability.md) - Aspire Dashboard entegrasyonu

---

*[← Kurulum](./installation.md) | [Workflow'lar →](./workflows.md)*
