# Events & Hooks Module

The Events module provides a flexible event system for agent lifecycle management, enabling extensibility, observability, and custom behaviors.

## Event Bus

### Basic Usage

```python
from multi_agent_base.events import EventBus, Event

# Create event bus
bus = EventBus()

# Subscribe to events
@bus.subscribe("user.message")
async def handle_message(event: Event):
    print(f"Received: {event.data}")

# Publish events
await bus.publish(Event(
    name="user.message",
    data={"content": "Hello!"},
))
```

### Event Priorities

Control handler execution order:

```python
from multi_agent_base.events import EventPriority

@bus.subscribe("agent.start", priority=EventPriority.HIGH)
async def logging_handler(event):
    """Runs first - logs the event."""
    log.info(f"Agent starting: {event.data}")

@bus.subscribe("agent.start", priority=EventPriority.NORMAL)
async def validation_handler(event):
    """Runs second - validates input."""
    validate(event.data)

@bus.subscribe("agent.start", priority=EventPriority.LOW)
async def metrics_handler(event):
    """Runs last - records metrics."""
    metrics.record("agent_start")
```

### One-Time Handlers

```python
@bus.once("system.ready")
async def on_ready(event):
    """Only called once, then automatically unsubscribed."""
    print("System is ready!")
```

### Global Handlers

```python
@bus.subscribe("*")  # Matches all events
async def audit_log(event: Event):
    """Log all events for auditing."""
    audit.log(event.name, event.data)
```

### Stop Propagation

```python
@bus.subscribe("request", priority=EventPriority.HIGH)
async def security_check(event: Event):
    if is_blocked(event.data):
        event.stop_propagation()  # Prevents other handlers
        return
```

## Lifecycle Hooks

Pre-defined hooks for agent lifecycle events:

```python
from multi_agent_base.events import (
    LifecycleHooks,
    HookType,
    HookContext,
)

hooks = LifecycleHooks()

# Before agent runs
@hooks.register(HookType.BEFORE_RUN)
async def log_input(ctx: HookContext):
    print(f"Input: {ctx.data['input']}")

# After agent runs
@hooks.register(HookType.AFTER_RUN)
async def log_output(ctx: HookContext):
    print(f"Output: {ctx.data['output']}")

# On error
@hooks.register(HookType.ON_ERROR)
async def handle_error(ctx: HookContext):
    error = ctx.data["error"]
    notify_ops_team(error)
```

### Available Hook Types

| Hook | Description | Data |
|------|-------------|------|
| `BEFORE_RUN` | Before agent.run() | `input`, `config` |
| `AFTER_RUN` | After agent.run() | `input`, `output`, `duration` |
| `BEFORE_TOOL` | Before tool execution | `tool_name`, `args` |
| `AFTER_TOOL` | After tool execution | `tool_name`, `result` |
| `ON_ERROR` | On any error | `error`, `traceback` |
| `ON_RETRY` | On retry attempt | `attempt`, `error` |
| `ON_TOKEN_USAGE` | Token usage update | `prompt`, `completion`, `total` |

### Hook Cancellation

Hooks can cancel operations:

```python
@hooks.register(HookType.BEFORE_RUN)
async def validate_input(ctx: HookContext):
    if is_harmful(ctx.data["input"]):
        ctx.cancel("Harmful content detected")
        return
```

## Decorators

### @on_event

Simple event subscription:

```python
from multi_agent_base.events import on_event, EventBus

bus = EventBus()

@on_event(bus, "message.received")
async def process_message(event):
    print(f"Processing: {event.data}")
```

### @hook

Hook registration decorator:

```python
from multi_agent_base.events import hook, HookType

@hook(HookType.AFTER_RUN)
async def record_response(ctx):
    save_to_database(ctx.data)
```

### @emit

Emit events from functions:

```python
from multi_agent_base.events import emit

@emit(bus, "operation.complete")
async def process_data(data: dict) -> dict:
    result = await transform(data)
    return result  # Result becomes event data
```

## Event Object

```python
from multi_agent_base.events import Event

event = Event(
    name="agent.complete",
    data={
        "agent_id": "agent-123",
        "duration_ms": 1500,
        "tokens_used": 500,
    },
    source="base-agent",
    timestamp=datetime.now(),
)

# Check if propagation stopped
if not event.propagation_stopped:
    # Continue processing
    pass

# Convert to dict
event_dict = event.to_dict()
```

## Integration with Agents

```python
from multi_agent_base.core.agent import BaseAgent
from multi_agent_base.events import LifecycleHooks, HookType

# Create hooks
hooks = LifecycleHooks()

@hooks.register(HookType.BEFORE_RUN)
async def validate(ctx):
    if len(ctx.data["input"]) > 10000:
        ctx.cancel("Input too long")

@hooks.register(HookType.AFTER_RUN)
async def track_usage(ctx):
    cost_tracker.record(ctx.data["usage"])

# Create agent with hooks
agent = BaseAgent(
    config=agent_config,
    lifecycle_hooks=hooks,
)
```

## Event History

Access past events:

```python
bus = EventBus(keep_history=True, max_history=1000)

# Publish some events...

# Query history
recent = bus.get_history(
    event_name="agent.complete",
    limit=10,
)

for event in recent:
    print(f"{event.timestamp}: {event.data}")
```

## Best Practices

1. **Use meaningful event names**:
   - Namespace events: `agent.start`, `agent.complete`
   - Use dots for hierarchy: `tool.search.start`

2. **Keep handlers fast**:
   - Offload heavy work to background tasks
   - Don't block event propagation

3. **Handle errors in handlers**:
   - Wrap handlers in try/except
   - Log errors but don't crash the bus

4. **Use priorities wisely**:
   - HIGH: Security, validation, logging
   - NORMAL: Business logic
   - LOW: Metrics, cleanup

5. **Clean up subscriptions**:
   - Unsubscribe when components are destroyed
   - Use `once()` for one-time handlers

## Example: Audit Trail

```python
from multi_agent_base.events import EventBus, Event

class AuditTrail:
    def __init__(self, bus: EventBus):
        self.bus = bus
        self.records = []
        self._setup_handlers()
    
    def _setup_handlers(self):
        @self.bus.subscribe("*")
        async def record(event: Event):
            self.records.append({
                "timestamp": event.timestamp.isoformat(),
                "event": event.name,
                "data": event.data,
                "source": event.source,
            })
    
    def get_trail(self, since=None):
        if since:
            return [r for r in self.records if r["timestamp"] > since]
        return self.records

# Usage
bus = EventBus()
audit = AuditTrail(bus)

# All events are now recorded
await bus.publish(Event(name="user.login", data={"user_id": "123"}))
```

## Example: Performance Monitoring

```python
from multi_agent_base.events import LifecycleHooks, HookType
import time

class PerformanceMonitor:
    def __init__(self, hooks: LifecycleHooks):
        self.metrics = []
        
        @hooks.register(HookType.BEFORE_RUN)
        async def start_timer(ctx):
            ctx.data["_start_time"] = time.monotonic()
        
        @hooks.register(HookType.AFTER_RUN)
        async def record_duration(ctx):
            duration = time.monotonic() - ctx.data["_start_time"]
            self.metrics.append({
                "duration": duration,
                "input_length": len(ctx.data["input"]),
                "output_length": len(ctx.data["output"]),
            })
    
    def get_average_duration(self):
        if not self.metrics:
            return 0
        return sum(m["duration"] for m in self.metrics) / len(self.metrics)
```
