# Getting Started

This guide will help you set up and use the Multi-Agent Base framework.

## Installation

### Basic Installation

```bash
pip install multi-agent-base
```

### With Provider Support

Install with support for specific LLM providers:

```bash
# Ollama (local inference)
pip install multi-agent-base[ollama]

# OpenAI
pip install multi-agent-base[openai]

# Anthropic
pip install multi-agent-base[anthropic]

# All providers
pip install multi-agent-base[all]
```

### Development Installation

```bash
git clone https://github.com/yourusername/multi-agent-base.git
cd multi-agent-base
pip install -e ".[dev,all]"
```

## Quick Start

### 1. Configure Your Environment

Create a `.env` file in your project root:

```env
# Provider settings
MULTI_AGENT_PROVIDER=openai
MULTI_AGENT_MODEL=gpt-4o-mini
OPENAI_API_KEY=sk-your-api-key

# For Ollama (no API key needed)
# MULTI_AGENT_PROVIDER=ollama
# MULTI_AGENT_MODEL=llama3.2
# OLLAMA_BASE_URL=http://localhost:11434

# Observability
OBSERVABILITY_ENABLED=true
PHOENIX_ENDPOINT=http://localhost:6006
PROJECT_NAME=my-agents
```

### 2. Create Your First Agent

```python
import asyncio
from multi_agent_base import SystemConfig, SingleAgentPattern

async def main():
    # Create configuration
    config = SystemConfig.from_env()
    
    # Create a single agent pattern
    pattern = SingleAgentPattern(config)
    
    # Create an agent
    agent = pattern.create_agent(
        name="assistant",
        system_prompt="You are a helpful AI assistant.",
    )
    
    # Run the agent
    result = await pattern.run("Hello! How can you help me today?")
    print(result.content)
    print(f"Tokens used: {result.total_tokens}")
    print(f"Cost: ${result.total_cost:.6f}")

asyncio.run(main())
```

### 3. Add Tools

```python
from multi_agent_base import SystemConfig, SingleAgentPattern

def calculate(expression: str) -> float:
    """Calculate a mathematical expression.
    
    Args:
        expression: Mathematical expression to evaluate
        
    Returns:
        Result of the calculation
    """
    # Simple and safe evaluation
    return eval(expression)

def get_weather(city: str) -> str:
    """Get the current weather for a city.
    
    Args:
        city: Name of the city
        
    Returns:
        Weather information
    """
    # Mock implementation
    return f"The weather in {city} is sunny, 22°C"

async def main():
    config = SystemConfig.from_env()
    pattern = SingleAgentPattern(config)
    
    agent = pattern.create_agent(
        name="assistant",
        system_prompt="You help with calculations and weather queries.",
        tools=[calculate, get_weather],
    )
    
    result = await pattern.run("What is 15 * 7 + 3?")
    print(result.content)

asyncio.run(main())
```

### 4. Enable Observability

```python
from multi_agent_base import SystemConfig, SingleAgentPattern
from multi_agent_base.observability import setup_phoenix, create_logger, LogLevel

async def main():
    # Set up Phoenix tracing
    tracer = setup_phoenix(
        endpoint="http://localhost:6006",
        project_name="my-agents",
        launch_app=True,  # Opens Phoenix UI
    )
    
    # Create logger
    logger = create_logger(
        console=True,
        file_path="logs/agents.jsonl",
        min_level=LogLevel.INFO,
    )
    
    # Create pattern with observability
    config = SystemConfig.from_env()
    pattern = SingleAgentPattern(
        config,
        logger=logger,
    )
    
    agent = pattern.create_agent(
        name="assistant",
        system_prompt="You are helpful.",
    )
    
    result = await pattern.run("Hello!")
    print(result.content)
    
    # View traces at http://localhost:6006

asyncio.run(main())
```

## Architecture Patterns

### Single Agent

For simple tasks with one agent:

```python
pattern = SingleAgentPattern(config)
agent = pattern.create_agent(name="helper", system_prompt="...")
result = await pattern.run("Task...")
```

### Supervisor Team

For complex tasks with multiple specialized workers:

```python
pattern = SupervisorPattern(config)
supervisor = pattern.create_team(
    supervisor_name="manager",
    worker_configs=[
        {"name": "researcher", "system_prompt": "Research topics..."},
        {"name": "writer", "system_prompt": "Write content..."},
    ]
)
result = await pattern.run("Write a blog post about AI")
```

### Swarm

For dynamic routing between agents:

```python
pattern = SwarmPattern(config)
pattern.create_agent(name="sales", system_prompt="...", can_handoff_to=["support"])
pattern.create_agent(name="support", system_prompt="...", can_handoff_to=["sales"])
result = await pattern.run("I need help", start_agent="sales")
```

## Next Steps

- [Configuration Guide](configuration.md) - Detailed configuration options
- [Architecture Patterns](patterns.md) - Deep dive into patterns
- [A2A Agent Cards](a2a-agent-cards.md) - Agent metadata and discovery
- [Observability](observability.md) - Tracing and logging
- [Cost Tracking](cost-tracking.md) - Monitor usage and costs
- [API Reference](api-reference.md) - Complete API documentation
