# Human-in-the-Loop (HITL) Framework

Bu dokümantasyon, Multi-Agent Base Framework'ün HITL modülünü açıklar. HITL, kritik operasyonlar için insan gözetimi ve onayı sağlayan bir sistemdir.

## İçindekiler

- [Genel Bakış](#genel-bakış)
- [Kurulum](#kurulum)
- [Approval System](#approval-system)
  - [ApprovalHandler](#approvalhandler)
  - [Decorators](#decorators)
  - [Callbacks](#callbacks)
- [Checkpoint System](#checkpoint-system)
  - [Checkpoint](#checkpoint)
  - [CheckpointManager](#checkpointmanager)
  - [WorkflowCheckpoint](#workflowcheckpoint)
- [Audit System](#audit-system)
  - [AuditLogger](#auditlogger)
  - [Backends](#backends)
- [Entegrasyon](#entegrasyon)
- [Best Practices](#best-practices)
- [API Reference](#api-reference)

---

## Genel Bakış

HITL Framework, AI agent'larının kritik kararlarında insan gözetimi sağlar:

```
┌─────────────────────────────────────────────────────────────────┐
│                    HITL Framework                                │
├─────────────────┬─────────────────┬─────────────────────────────┤
│  Approval       │  Checkpoint     │  Audit                      │
│  System         │  System         │  System                     │
├─────────────────┼─────────────────┼─────────────────────────────┤
│ • ApprovalHandler│ • Checkpoint   │ • AuditLogger               │
│ • @require_approval│ • Manager    │ • InMemoryBackend           │
│ • @conditional  │ • Workflow      │ • FileBackend               │
│ • Callbacks     │ • Pause/Resume  │ • ConsoleBackend            │
└─────────────────┴─────────────────┴─────────────────────────────┘
```

### Ne Zaman Kullanılır?

- **Yüksek riskli operasyonlar**: Veri silme, finansal işlemler
- **Üçüncü taraf API çağrıları**: Ücretli veya rate-limited servisler
- **Geri dönüşü olmayan işlemler**: Email gönderme, yayın yapma
- **Hassas veri erişimi**: PII, sağlık verileri
- **Kritik workflow adımları**: Onay gerektiren iş süreçleri

---

## Kurulum

```python
from multi_agent_base.hitl import (
    # Approval
    ApprovalHandler,
    ApprovalRequest,
    ApprovalResponse,
    ApprovalStatus,
    require_approval,
    conditional_approval,
    ConsoleApprovalHandler,
    
    # Checkpoint
    Checkpoint,
    CheckpointManager,
    CheckpointStatus,
    WorkflowCheckpoint,
    
    # Audit
    AuditLogger,
    AuditEntry,
    AuditDecision,
    InMemoryAuditBackend,
    FileAuditBackend,
    ConsoleAuditBackend,
    create_audit_logger,
)
```

---

## Approval System

Kritik operasyonlar için insan onayı mekanizması.

### ApprovalHandler

Merkezi onay yönetimi sınıfı:

```python
from multi_agent_base.hitl import ApprovalHandler

# Temel kullanım
handler = ApprovalHandler(timeout=300)  # 5 dakika timeout

# Test modları
test_handler = ApprovalHandler(auto_approve=True)  # Otomatik onay
reject_handler = ApprovalHandler(auto_reject=True)  # Otomatik ret
```

#### Onay İsteme

```python
response = await handler.request_approval(
    action="delete_user_data",
    reason="Kullanıcı hesap silme isteği",
    context={
        "user_id": "user_123",
        "email": "user@example.com",
        "data_size": "500MB",
    },
    timeout=60,  # Bu istek için özel timeout
)

if response.is_approved:
    print(f"Onaylandı: {response.approver}")
    await delete_user_data()
elif response.is_rejected:
    print(f"Reddedildi: {response.reason}")
elif response.is_timeout:
    print("Zaman aşımı!")
```

#### Manuel Onay/Ret

```python
# Bekleyen istekleri al
pending = handler.get_pending_requests()

for request in pending:
    print(f"Action: {request.action}")
    print(f"Reason: {request.reason}")
    print(f"Context: {request.context}")
    
    # Onayla
    await handler.approve(
        request_id=request.request_id,
        approver="admin@example.com",
        reason="Geçerli işlem",
    )
    
    # veya reddet
    await handler.reject(
        request_id=request.request_id,
        reason="Yetkisiz işlem",
    )
```

### Decorators

#### @require_approval

Her zaman onay gerektiren fonksiyonlar için:

```python
from multi_agent_base.hitl import require_approval, ApprovalHandler

handler = ApprovalHandler(auto_approve=True)  # Test için

@require_approval(
    handler=handler,
    reason="Bu işlem veritabanını siler",
    timeout=300,
)
async def delete_database():
    """Veritabanını sil."""
    await db.drop_all()
    return {"status": "deleted"}

# Çağrıldığında önce onay istenir
result = await delete_database()
```

#### @conditional_approval

Koşula bağlı onay:

```python
from multi_agent_base.hitl import conditional_approval

@conditional_approval(
    handler=handler,
    condition=lambda ctx: ctx.get("amount", 0) > 1000,
    reason="Yüksek tutarlı işlem onayı gerekli",
)
async def process_payment(amount: float):
    """Ödeme işle."""
    return await payment_api.charge(amount)

# Küçük işlem - onay gerekmez
await process_payment(amount=500)

# Büyük işlem - onay gerekir
await process_payment(amount=5000)
```

#### Rejected/Timeout Handlers

```python
async def on_rejected():
    print("İşlem reddedildi!")
    return {"status": "cancelled"}

async def on_timeout():
    print("Zaman aşımı!")
    return {"status": "timeout"}

@require_approval(
    handler=handler,
    reason="Kritik işlem",
    on_rejected=on_rejected,
    on_timeout=on_timeout,
)
async def critical_operation():
    return {"status": "completed"}
```

### Callbacks

Event-driven approval handling:

```python
handler = ApprovalHandler(timeout=300)

@handler.on_approved
async def handle_approved(action: str, context: dict):
    """Onaylandığında çağrılır."""
    print(f"✅ Onaylandı: {action}")
    await audit_logger.log_approval(action=action, context=context)

@handler.on_rejected
async def handle_rejected(action: str, context: dict):
    """Reddedildiğinde çağrılır."""
    print(f"❌ Reddedildi: {action}")
    await notify_admin(f"İşlem reddedildi: {action}")

@handler.on_timeout
async def handle_timeout(action: str, context: dict):
    """Zaman aşımında çağrılır."""
    print(f"⏰ Timeout: {action}")

@handler.on_request
async def handle_request(action: str, context: dict):
    """Yeni istek geldiğinde çağrılır."""
    await send_notification(f"Onay bekliyor: {action}")
```

### ConsoleApprovalHandler

İnteraktif konsol onayı:

```python
from multi_agent_base.hitl import ConsoleApprovalHandler

handler = ConsoleApprovalHandler(timeout=60)

# Konsola onay sorusu yazdırır
response = await handler.request_approval(
    action="send_email",
    reason="Toplu email gönderimi",
    context={"recipients": 1000},
)

# Konsol çıktısı:
# ┌────────────────────────────────────────────┐
# │ Approval Request                           │
# ├────────────────────────────────────────────┤
# │ Action: send_email                         │
# │ Reason: Toplu email gönderimi              │
# │ Context:                                   │
# │   recipients: 1000                         │
# ├────────────────────────────────────────────┤
# │ Approve? [y/n/timeout in 60s]:             │
# └────────────────────────────────────────────┘
```

---

## Checkpoint System

Workflow'ları duraklatıp devam ettirme mekanizması.

### Checkpoint

Tek bir duraklama noktası:

```python
from multi_agent_base.hitl import Checkpoint

# Checkpoint oluştur
checkpoint = Checkpoint(
    name="review_results",
    workflow_id="data_analysis",
    step_name="quality_check",
)

# Resume callback'i kaydet
@checkpoint.on_resume
async def handle_resume(data: dict):
    print(f"Devam ediliyor: {data}")

# Duraklat ve bekle
print("Analiz tamamlandı, inceleme bekleniyor...")
resume_data = await checkpoint.pause(
    state={"results": analysis_results},
    timeout=3600,  # 1 saat
)

# Resume edildiğinde devam et
if resume_data.get("approved"):
    await publish_results()
```

#### Resume

```python
# Başka bir yerden resume
await checkpoint.resume(
    data={"approved": True, "notes": "Sonuçlar iyi görünüyor"},
    resuming_user="reviewer@example.com",
)
```

#### Skip

```python
# Checkpoint'i atla (beklemeden devam et)
checkpoint.skip()
```

### CheckpointManager

Birden fazla checkpoint'i yönetme:

```python
from multi_agent_base.hitl import CheckpointManager

manager = CheckpointManager()

# Checkpoint oluştur
cp1 = manager.create_checkpoint(
    name="data_loaded",
    workflow_id="etl_pipeline",
    step_name="load",
)

cp2 = manager.create_checkpoint(
    name="data_transformed",
    workflow_id="etl_pipeline",
    step_name="transform",
)

# Workflow'a göre checkpoint'leri al
pipeline_checkpoints = manager.get_checkpoints_for_workflow("etl_pipeline")

# İsme göre bul
checkpoint = manager.get_checkpoint_by_name(
    name="data_loaded",
    workflow_id="etl_pipeline",
)

# Bekleyen checkpoint'ler
pending = manager.get_pending_checkpoints()

# Duraklatılmış checkpoint'ler
paused = manager.get_paused_checkpoints()
```

### WorkflowCheckpoint

Workflow entegrasyonu için yüksek seviye API:

```python
from multi_agent_base.hitl import WorkflowCheckpoint

# Workflow için checkpointer oluştur
checkpointer = WorkflowCheckpoint(
    workflow_id="document_processing",
    default_timeout=1800,  # 30 dakika
)

async def process_documents():
    # Step 1: Load
    documents = await load_documents()
    
    # Checkpoint 1
    await checkpointer.pause_for_review(
        step_name="after_load",
        state={"doc_count": len(documents)},
        message="Dökümanlar yüklendi, devam edilsin mi?",
    )
    
    # Step 2: Process
    results = await process_all(documents)
    
    # Checkpoint 2
    await checkpointer.pause_for_review(
        step_name="after_process",
        state={"results": results},
        message="İşlem tamamlandı, sonuçlar incelensin mi?",
    )
    
    # Step 3: Save
    await save_results(results)
```

---

## Audit System

Tüm HITL kararlarının kaydedilmesi.

### AuditLogger

Merkezi audit logging:

```python
from multi_agent_base.hitl import AuditLogger, InMemoryAuditBackend

# In-memory logger (test için)
logger = AuditLogger()

# Veya özel backend ile
from multi_agent_base.hitl import FileAuditBackend

logger = AuditLogger(backends=[
    InMemoryAuditBackend(),
    FileAuditBackend("./logs/audit.jsonl"),
])
```

#### Logging Methods

```python
# Onay logla
await logger.log_approval(
    action="delete_records",
    user="admin@example.com",
    context={"count": 1000},
    reason="Onaylandı - geçerli istek",
)

# Ret logla
await logger.log_rejection(
    action="access_pii",
    user="junior@example.com",
    reason="Yetersiz yetki",
)

# Timeout logla
await logger.log_timeout(
    action="critical_update",
    context={"timeout": 300},
)

# Resume logla
await logger.log_resume(
    action="paused_workflow",
    user="supervisor@example.com",
    context={"checkpoint": "review_step"},
)

# Hata logla
await logger.log_error(
    action="failed_operation",
    error="Connection timeout",
    context={"retry_count": 3},
)
```

#### Querying

```python
# Tüm kayıtları al
all_entries = await logger.get_all()

# Son N kayıt
recent = await logger.get_recent(count=10)

# Filtreleme ile sorgula
from multi_agent_base.hitl import AuditDecision
from datetime import datetime, timedelta

entries = await logger.query(
    action="delete_records",
    decision=AuditDecision.APPROVED,
    user="admin@example.com",
    start_time=datetime.now() - timedelta(days=7),
    end_time=datetime.now(),
)

# İstatistikler
stats = await logger.get_stats()
print(stats)
# {
#     "total_entries": 150,
#     "by_decision": {"approved": 100, "rejected": 30, "timeout": 20},
#     "by_action": {"delete_records": 50, "access_pii": 100},
#     "by_user": {"admin": 80, "junior": 70},
#     "approval_rate": 0.67,
# }
```

### Backends

#### InMemoryAuditBackend

Test ve geliştirme için:

```python
from multi_agent_base.hitl import InMemoryAuditBackend

backend = InMemoryAuditBackend(max_entries=10000)
```

#### FileAuditBackend

JSONL formatında dosyaya yazma:

```python
from multi_agent_base.hitl import FileAuditBackend

backend = FileAuditBackend(
    path="./logs/audit.jsonl",
    rotate_size=10 * 1024 * 1024,  # 10MB'da rotate
)
```

Dosya formatı:
```jsonl
{"entry_id":"abc123","action":"delete_records","decision":"approved","user":"admin","timestamp":"2026-02-02T08:00:00Z","context":{"count":1000}}
{"entry_id":"def456","action":"access_pii","decision":"rejected","user":"junior","timestamp":"2026-02-02T08:05:00Z","reason":"Yetersiz yetki"}
```

#### ConsoleAuditBackend

Geliştirme sırasında konsola yazma:

```python
from multi_agent_base.hitl import ConsoleAuditBackend

backend = ConsoleAuditBackend(
    format="detailed",  # "simple" | "detailed" | "json"
    colorize=True,
)
```

#### Custom Backend

Kendi backend'inizi oluşturun:

```python
from multi_agent_base.hitl import AuditEntry
from typing import List, Optional

class DatabaseAuditBackend:
    async def write(self, entry: AuditEntry) -> None:
        await db.insert("audit_log", entry.to_dict())
    
    async def query(
        self,
        action: Optional[str] = None,
        decision: Optional[str] = None,
        **filters,
    ) -> List[AuditEntry]:
        rows = await db.query("audit_log", filters)
        return [AuditEntry.from_dict(row) for row in rows]

# Kullanım
logger = AuditLogger(backends=[DatabaseAuditBackend()])
```

---

## Entegrasyon

### ApprovalHandler + AuditLogger

```python
handler = ApprovalHandler(timeout=300)
logger = AuditLogger()

@handler.on_approved
async def audit_approval(action, context):
    await logger.log_approval(action=action, user="auto", context=context)

@handler.on_rejected
async def audit_rejection(action, context):
    await logger.log_rejection(action=action, reason="User rejected")

@handler.on_timeout
async def audit_timeout(action, context):
    await logger.log_timeout(action=action, context=context)
```

### Checkpoint + AuditLogger

```python
checkpointer = WorkflowCheckpoint(workflow_id="my_workflow")
logger = AuditLogger()

async def logged_checkpoint(step_name: str, state: dict):
    await logger.log_checkpoint(
        action=f"{checkpointer.workflow_id}:{step_name}",
        context=state,
    )
    await checkpointer.pause_for_review(step_name=step_name, state=state)
```

### Agent Pattern Entegrasyonu

```python
from multi_agent_base import BaseAgent
from multi_agent_base.hitl import require_approval, ApprovalHandler

handler = ApprovalHandler(auto_approve=False)

class SafeAgent(BaseAgent):
    @require_approval(handler=handler, reason="External API call")
    async def call_external_api(self, query: str):
        return await external_api.search(query)
    
    async def run(self, task: str):
        # Normal işlemler - onay gerekmez
        analysis = await self.analyze(task)
        
        # Kritik işlem - onay gerekir
        if analysis.requires_external_data:
            data = await self.call_external_api(analysis.query)
```

---

## Best Practices

### 1. Timeout'ları Akıllıca Ayarlayın

```python
# Kritik işlemler için uzun timeout
handler = ApprovalHandler(timeout=3600)  # 1 saat

# Hızlı kararlar için kısa timeout
handler = ApprovalHandler(timeout=60)  # 1 dakika
```

### 2. Context'i Zengin Tutun

```python
# ❌ Kötü
await handler.request_approval(
    action="delete",
    reason="Silme işlemi",
)

# ✅ İyi
await handler.request_approval(
    action="delete_user_data",
    reason="Kullanıcı GDPR kapsamında veri silme talep etti",
    context={
        "user_id": "user_123",
        "email": "user@example.com",
        "data_types": ["profile", "orders", "messages"],
        "estimated_records": 1500,
        "request_date": "2026-02-02",
        "legal_reference": "GDPR Article 17",
    },
)
```

### 3. Test Modlarını Kullanın

```python
import os

# Environment'a göre handler seç
if os.getenv("ENV") == "test":
    handler = ApprovalHandler(auto_approve=True)
elif os.getenv("ENV") == "development":
    handler = ConsoleApprovalHandler()
else:
    handler = ApprovalHandler(timeout=300)
```

### 4. Audit Trail'i İhmal Etmeyin

```python
# Her zaman audit logging kullanın
async def critical_operation():
    response = await handler.request_approval(...)
    
    # Kararı logla
    if response.is_approved:
        await logger.log_approval(...)
    else:
        await logger.log_rejection(...)
    
    # İşlemi yap
    if response.is_approved:
        result = await do_operation()
        
        # Sonucu da logla
        await logger.log_completion(
            action="critical_operation",
            result=result,
        )
```

### 5. Graceful Degradation

```python
@require_approval(
    handler=handler,
    reason="Kritik işlem",
    on_timeout=lambda: {"status": "queued"},  # Timeout'ta kuyruğa al
    on_rejected=lambda: {"status": "cancelled"},  # Ret'te iptal et
)
async def critical_operation():
    ...
```

---

## API Reference

### ApprovalStatus

```python
class ApprovalStatus(str, Enum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    TIMEOUT = "timeout"
    CANCELLED = "cancelled"
```

### CheckpointStatus

```python
class CheckpointStatus(str, Enum):
    PENDING = "pending"
    PAUSED = "paused"
    RESUMED = "resumed"
    SKIPPED = "skipped"
    EXPIRED = "expired"
```

### AuditDecision

```python
class AuditDecision(str, Enum):
    APPROVED = "approved"
    REJECTED = "rejected"
    TIMEOUT = "timeout"
    RESUMED = "resumed"
    ERROR = "error"
```

### Full Class Reference

Detaylı API referansı için kaynak koduna bakın:
- `src/multi_agent_base/hitl/approval.py`
- `src/multi_agent_base/hitl/checkpoint.py`
- `src/multi_agent_base/hitl/audit.py`

---

## Örnek Senaryo: E-Ticaret Sipariş İşleme

```python
from multi_agent_base.hitl import (
    ApprovalHandler,
    CheckpointManager,
    AuditLogger,
    conditional_approval,
)

# Setup
handler = ApprovalHandler(timeout=300)
checkpoint_manager = CheckpointManager()
audit = AuditLogger()

# Yüksek tutarlı siparişler için onay
@conditional_approval(
    handler=handler,
    condition=lambda ctx: ctx.get("total", 0) > 10000,
    reason="Yüksek tutarlı sipariş onayı gerekli",
)
async def process_order(order_id: str, total: float):
    return await order_service.process(order_id)

# Sipariş işleme workflow'u
async def order_workflow(order: dict):
    # 1. Ödeme doğrulama
    payment = await verify_payment(order["payment_id"])
    
    # Checkpoint: Ödeme doğrulandı
    cp1 = checkpoint_manager.create_checkpoint(
        name="payment_verified",
        workflow_id=f"order_{order['id']}",
    )
    
    # 2. Stok kontrolü
    stock = await check_stock(order["items"])
    if not stock["available"]:
        await audit.log_rejection(
            action="order_processing",
            reason="Stok yetersiz",
            context=order,
        )
        return {"status": "failed", "reason": "out_of_stock"}
    
    # 3. Sipariş işleme (yüksek tutarlıysa onay gerekir)
    result = await process_order(
        order_id=order["id"],
        total=order["total"],
    )
    
    # 4. Kargo
    await schedule_shipping(order)
    
    await audit.log_approval(
        action="order_completed",
        user="system",
        context=order,
    )
    
    return {"status": "completed", "order_id": order["id"]}
```

---

## Sonraki Adımlar

- [AgentThread](./thread.md) - Konuşma persistance
- [MCP Support](./mcp.md) - Model Context Protocol
- [Patterns](./patterns.md) - Multi-agent patterns
