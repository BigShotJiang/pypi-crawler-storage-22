# Kurulum

Bu sayfa, Agent Framework'ü lokal ortamda Ollama ile kullanmak için gereken tüm kurulum adımlarını içerir.

---

## Sistem Gereksinimleri

| Bileşen | Minimum | Önerilen |
|---------|---------|----------|
| Python | 3.10 | 3.11+ |
| RAM | 8 GB | 16 GB+ |
| Disk | 10 GB | 50 GB+ (modeller için) |
| OS | macOS, Linux, Windows | macOS/Linux |

---

## Python Ortamı

### 1. Python Kurulumu

```bash
# macOS (Homebrew)
brew install python@3.11

# Ubuntu/Debian
sudo apt update && sudo apt install python3.11 python3.11-venv

# Windows
# https://python.org adresinden indir
```

### 2. Sanal Ortam

```bash
# Proje klasörü oluştur
mkdir my-agent-project
cd my-agent-project

# Sanal ortam oluştur
python3 -m venv .venv

# Aktifleştir
source .venv/bin/activate  # macOS/Linux
# .venv\Scripts\activate   # Windows

# pip güncelle
pip install --upgrade pip
```

---

## Agent Framework Paketleri

### Temel Paketler

```bash
# Core framework
pip install agent-framework --pre

# DevUI (geliştirme arayüzü)
pip install agent-framework-devui --pre

# Ollama entegrasyonu
pip install agent-framework-ollama --pre
```

### Opsiyonel Paketler

```bash
# OpenTelemetry (observability)
pip install opentelemetry-exporter-otlp-proto-grpc

# Graph export
pip install graphviz
brew install graphviz  # macOS sistem paketi
```

### Kurulumu Doğrula

```bash
python -c "import agent_framework; print(agent_framework.__version__)"
# Çıktı: 1.0.0b260130 (veya benzeri)
```

---

## Ollama Kurulumu

### macOS

```bash
# Homebrew ile
brew install ollama

# Veya doğrudan indir
curl -fsSL https://ollama.ai/install.sh | sh
```

### Linux

```bash
curl -fsSL https://ollama.ai/install.sh | sh
```

### Windows

[Ollama İndirme Sayfası](https://ollama.ai/download) adresinden indirin.

### Ollama'yı Başlat

```bash
# Arka planda çalıştır
ollama serve

# Veya macOS'ta otomatik başlar
```

### Model İndir

```bash
# Önerilen modeller
ollama pull qwen2.5-coder:7b      # 4.7 GB - Tool calling için iyi
ollama pull llama3.2              # 2.0 GB - Hızlı ve hafif
ollama pull mistral:7b            # 4.4 GB - Genel amaçlı

# Kurulu modelleri listele
ollama list
```

### Ollama'yı Test Et

```bash
# Basit test
ollama run qwen2.5-coder:7b "Merhaba!"

# API testi
curl http://localhost:11434/api/tags
```

---

## Docker (Opsiyonel)

Aspire Dashboard için Docker gereklidir.

### macOS

```bash
brew install --cask docker
# Docker Desktop'ı başlat
```

### Linux

```bash
# Docker Engine
curl -fsSL https://get.docker.com | sh
sudo usermod -aG docker $USER
```

### Docker'ı Doğrula

```bash
docker --version
docker run hello-world
```

---

## Graphviz (Opsiyonel)

Workflow graph'larını SVG olarak export etmek için.

### macOS

```bash
brew install graphviz
```

### Linux

```bash
sudo apt install graphviz
```

### Python Paketi

```bash
pip install graphviz
```

---

## Ortam Değişkenleri

### Zorunlu Değil (Ollama için)

Ollama varsayılan olarak `http://localhost:11434` adresinde çalışır.

### Opsiyonel

```bash
# .env dosyası oluştur
cat > .env << 'EOF'
# Ollama (varsayılan değerler)
OLLAMA_HOST=http://localhost:11434
OLLAMA_MODEL=qwen2.5-coder:7b

# DevUI
DEVUI_PORT=8080

# Aspire Dashboard
ASPIRE_DASHBOARD_PORT=18888
OTLP_ENDPOINT=http://localhost:4317
EOF
```

---

## Proje Yapısı

Önerilen proje yapısı:

```
my-agent-project/
├── .venv/                 # Sanal ortam
├── .env                   # Ortam değişkenleri
├── requirements.txt       # Bağımlılıklar
├── src/
│   └── my_agent/
│       ├── __init__.py
│       ├── agent.py       # Agent tanımları
│       ├── tools.py       # Tool'lar
│       └── workflows.py   # Workflow'lar
├── examples/
│   └── demo.py
├── scripts/
│   └── run.sh
└── docs/
    └── README.md
```

### requirements.txt

```txt
agent-framework>=1.0.0b260130
agent-framework-devui>=1.0.0b260130
agent-framework-ollama>=1.0.0b260130
opentelemetry-exporter-otlp-proto-grpc
graphviz
pydantic>=2.0.0
```

---

## Kurulumu Doğrula

Tüm kurulumun doğru yapıldığını kontrol edin:

```bash
# 1. Python ve paketler
python -c "
from agent_framework import ChatAgent
from agent_framework.devui import serve
from agent_framework.ollama import OllamaChatClient
print('✅ Agent Framework paketleri yüklü')
"

# 2. Ollama
curl -s http://localhost:11434/api/tags && echo "✅ Ollama çalışıyor"

# 3. Docker (opsiyonel)
docker info > /dev/null 2>&1 && echo "✅ Docker çalışıyor" || echo "⚠️ Docker yok (opsiyonel)"

# 4. Graphviz (opsiyonel)
which dot > /dev/null 2>&1 && echo "✅ Graphviz yüklü" || echo "⚠️ Graphviz yok (opsiyonel)"
```

---

## Sorun Giderme

### pip install hatası

```bash
# pip güncelle
pip install --upgrade pip setuptools wheel

# Önbelleği temizle
pip cache purge
```

### Ollama bağlantı hatası

```bash
# Ollama çalışıyor mu?
pgrep ollama || ollama serve &

# Port kontrolü
lsof -i :11434
```

### Docker başlamıyor

```bash
# macOS: Docker Desktop'ı başlat
open /Applications/Docker.app

# Linux: Docker daemon'ı başlat
sudo systemctl start docker
```

---

## Sonraki Adımlar

Kurulum tamamlandıysa:

1. [Hızlı Başlangıç](./quick-start.md) - İlk agent'ınızı oluşturun
2. [DevUI Özellikleri](./devui-features.md) - Arayüzü keşfedin

---

*[← Hızlı Başlangıç](./quick-start.md) | [DevUI Özellikleri →](./devui-features.md)*
