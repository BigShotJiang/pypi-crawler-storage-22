# MCP (Model Context Protocol) Module

The MCP module provides comprehensive support for Anthropic's Model Context Protocol, enabling tool discovery, server hosting, and client connections.

## Overview

MCP is a standardized protocol for AI models to interact with external tools, resources, and prompts. This module implements:

- **MCPClient**: Connect to MCP servers and discover/call tools
- **MCPServer**: Host tools, resources, and prompts for AI models
- **Tool Discovery**: Automatic discovery and conversion of MCP tools
- **Multiple Transports**: stdio, HTTP, and SSE support

## Quick Start

### Client Usage

```python
from multi_agent_base.mcp import MCPClient

# Connect to an MCP server via stdio
async with MCPClient.stdio("python", "mcp_server.py") as client:
    # List available tools
    tools = await client.list_tools()
    print(f"Found {len(tools)} tools")
    
    # Call a tool
    result = await client.call_tool("search", {"query": "AI agents"})
    print(result)
```

### Server Usage

```python
from multi_agent_base.mcp import MCPServer

server = MCPServer(name="my-server", version="1.0.0")

# Register a tool using decorator
@server.tool()
def search(query: str) -> str:
    """Search for documents."""
    return f"Results for: {query}"

@server.tool()
async def fetch_data(url: str) -> str:
    """Fetch data from URL."""
    async with aiohttp.ClientSession() as session:
        async with session.get(url) as response:
            return await response.text()

# Run the server
await server.run_stdio()
```

## Protocol Types

### MCPRequest

Represents an MCP request message:

```python
from multi_agent_base.mcp import MCPRequest

request = MCPRequest(
    method="tools/call",
    params={
        "name": "search",
        "arguments": {"query": "AI"},
    },
)

# Serialize
json_str = request.to_json()
data = request.to_dict()

# Deserialize
request = MCPRequest.from_dict(data)
```

### MCPResponse

Represents an MCP response message:

```python
from multi_agent_base.mcp import MCPResponse, MCPError, MCPErrorCode

# Success response
response = MCPResponse(
    id="request-123",
    result={"content": [{"type": "text", "text": "Hello!"}]},
)

# Error response
response = MCPResponse(
    id="request-123",
    error=MCPError(
        code=MCPErrorCode.TOOL_NOT_FOUND,
        message="Tool 'unknown' not found",
    ),
)

# Check status
if response.is_error:
    print(f"Error: {response.error.message}")
else:
    print(f"Result: {response.result}")
```

### MCPError

Error information with JSON-RPC style error codes:

```python
from multi_agent_base.mcp import MCPError, MCPErrorCode

error = MCPError(
    code=MCPErrorCode.INVALID_PARAMS,
    message="Missing required parameter: query",
    data={"parameter": "query"},
)

# Available error codes
MCPErrorCode.PARSE_ERROR        # -32700
MCPErrorCode.INVALID_REQUEST    # -32600
MCPErrorCode.METHOD_NOT_FOUND   # -32601
MCPErrorCode.INVALID_PARAMS     # -32602
MCPErrorCode.INTERNAL_ERROR     # -32603
MCPErrorCode.TOOL_NOT_FOUND     # -32001
MCPErrorCode.TOOL_EXECUTION_ERROR  # -32002
MCPErrorCode.RESOURCE_NOT_FOUND    # -32003
```

## Tool Types

### MCPTool

Represents an MCP tool definition:

```python
from multi_agent_base.mcp import MCPTool, MCPToolParameter

tool = MCPTool(
    name="calculate",
    description="Perform mathematical calculations",
    parameters=[
        MCPToolParameter(
            name="expression",
            type="string",
            description="Math expression to evaluate",
            required=True,
        ),
        MCPToolParameter(
            name="precision",
            type="integer",
            description="Decimal precision",
            required=False,
            default=2,
        ),
    ],
)

# Convert to JSON schema
schema = tool.to_dict()
```

### MCPToolResult

Represents the result of a tool call:

```python
from multi_agent_base.mcp import MCPToolResult

# Text result
result = MCPToolResult.text("Calculation complete: 42")

# Error result
result = MCPToolResult.error("Division by zero")

# JSON result
result = MCPToolResult.json({"answer": 42, "steps": ["2 + 2", "4 * 10", "40 + 2"]})

# Check if error
if result.isError:
    print("Tool failed")
```

## MCP Client

### Creating a Client

```python
from multi_agent_base.mcp import MCPClient

# Stdio transport (subprocess)
client = MCPClient.stdio("python", "server.py", env={"DEBUG": "1"})

# HTTP transport
client = MCPClient.http("http://localhost:8080")

# SSE transport
client = MCPClient.sse("http://localhost:8080/events")
```

### Connecting and Using

```python
async with MCPClient.stdio("python", "server.py") as client:
    # Client is automatically connected and initialized
    
    # List tools
    tools = await client.list_tools()
    for tool in tools:
        print(f"- {tool.name}: {tool.description}")
    
    # Call a tool
    result = await client.call_tool("search", {"query": "AI"})
    
    # List resources
    resources = await client.list_resources()
    
    # Read a resource
    content = await client.read_resource("config://app/settings")
    
    # List prompts
    prompts = await client.list_prompts()
    
    # Get a prompt
    messages = await client.get_prompt("code-review", {"code": "def hello(): pass"})
```

### Event Handling

```python
client = MCPClient.stdio("python", "server.py")

# Register notification handler
@client.on_notification("notifications/progress")
async def handle_progress(params):
    print(f"Progress: {params['progress']}%")

async with client:
    # Notifications will be handled automatically
    await client.call_tool("long_operation", {})
```

## MCP Server

### Creating a Server

```python
from multi_agent_base.mcp import MCPServer, MCPServerConfig

# Simple server
server = MCPServer(name="my-server", version="1.0.0")

# With configuration
config = MCPServerConfig(
    name="my-server",
    version="1.0.0",
    description="A powerful MCP server",
)
server = MCPServer(config=config)
```

### Registering Tools

```python
from multi_agent_base.mcp import MCPServer

server = MCPServer(name="my-server")

# Using decorator
@server.tool()
def search(query: str, limit: int = 10) -> str:
    """Search for documents.
    
    Args:
        query: Search query
        limit: Maximum results
    """
    return f"Found {limit} results for: {query}"

# Async tool
@server.tool()
async def fetch(url: str) -> str:
    """Fetch content from URL."""
    async with aiohttp.ClientSession() as session:
        async with session.get(url) as response:
            return await response.text()

# With custom name
@server.tool(name="web-search", description="Search the web")
def my_search_impl(q: str) -> str:
    return f"Web results for: {q}"

# Manual registration
def my_tool(x: int) -> int:
    return x * 2

server.register_tool("double", my_tool, "Double a number")
```

### Registering Resources

```python
from multi_agent_base.mcp import MCPServer

server = MCPServer(name="my-server")

# Dynamic resource
@server.resource("config://app/settings")
def get_settings() -> str:
    """Get application settings."""
    return json.dumps({"theme": "dark", "language": "en"})

# Static resource
server.register_static_resource(
    uri="file://readme.md",
    content="# Welcome\nThis is my app.",
    name="README",
    mimeType="text/markdown",
)

# Resource template
@server.resource_template("file://data/{filename}")
def get_data_file(filename: str) -> str:
    """Get a data file."""
    with open(f"data/{filename}") as f:
        return f.read()
```

### Registering Prompts

```python
from multi_agent_base.mcp import MCPServer

server = MCPServer(name="my-server")

@server.prompt()
def code_review(code: str, language: str = "python") -> str:
    """Review code for issues."""
    return f"""Please review this {language} code for:
- Bugs and errors
- Performance issues
- Security vulnerabilities

```{language}
{code}
```"""

@server.prompt(name="summarize")
def summarize_text(text: str, max_length: int = 100) -> str:
    """Summarize text."""
    return f"Summarize the following text in {max_length} words or less:\n\n{text}"
```

### Running the Server

```python
import asyncio
from multi_agent_base.mcp import MCPServer

server = MCPServer(name="my-server")

# Add tools...

# Run via stdio (for CLI tools)
async def main():
    await server.run_stdio()

asyncio.run(main())

# Run via HTTP
async def main():
    await server.run_http(host="localhost", port=8080)

asyncio.run(main())
```

### Handling Requests Directly

For testing or custom integrations:

```python
from multi_agent_base.mcp import MCPServer, MCPRequest, MCP_PROTOCOL_VERSION

server = MCPServer(name="test-server")

@server.tool()
def greet(name: str) -> str:
    return f"Hello, {name}!"

# Initialize
init_response = await server.handle_request(MCPRequest(
    method="initialize",
    params={
        "protocolVersion": MCP_PROTOCOL_VERSION,
        "capabilities": {},
        "clientInfo": {"name": "test", "version": "1.0"},
    },
))

# Call tool
response = await server.handle_request(MCPRequest(
    method="tools/call",
    params={"name": "greet", "arguments": {"name": "World"}},
))

print(response.result["content"][0]["text"])  # "Hello, World!"
```

## Tool Discovery

### ToolDiscovery Class

Manage tools from multiple MCP servers:

```python
from multi_agent_base.mcp import ToolDiscovery, MCPClient

discovery = ToolDiscovery()

async with MCPClient.stdio("python", "server1.py") as client1:
    async with MCPClient.stdio("python", "server2.py") as client2:
        # Add clients
        discovery.add_client(client1)
        discovery.add_client(client2)
        
        # Refresh tool list
        await discovery.refresh()
        
        # List all tools
        print(f"Found {len(discovery.tool_names)} tools")
        
        # Get a specific tool
        tool = discovery.get_tool("search")
        if tool:
            result = await discovery.call_tool("search", {"query": "AI"})
        
        # Get JSON schemas for all tools
        schemas = discovery.get_json_schemas()
```

### DiscoveredTool

Wrapper for calling discovered tools:

```python
from multi_agent_base.mcp import discover_tools, MCPClient

async with MCPClient.stdio("python", "server.py") as client:
    tools = await discover_tools(client)
    
    # Call a tool directly
    search_tool = tools["search"]
    result = await search_tool(query="AI agents")
    
    # Get JSON schema
    schema = search_tool.to_json_schema()
```

### MCPToolWrapper

Convenient wrapper for attribute-style access:

```python
from multi_agent_base.mcp import MCPToolWrapper, MCPClient

async with MCPClient.stdio("python", "server.py") as client:
    wrapper = MCPToolWrapper(client)
    await wrapper.discover()
    
    # Call tools as methods
    result = await wrapper.search(query="AI agents")
    result = await wrapper.calculate(a=10, b=20)
    
    # Or by name
    result = await wrapper("search", query="AI agents")
```

## Transport Protocols

### Stdio Transport

Used for subprocess communication:

```python
from multi_agent_base.mcp import StdioTransport, MCPClient

transport = StdioTransport(
    command="python",
    args=["server.py"],
    env={"DEBUG": "1"},
    cwd="/path/to/server",
)

client = MCPClient(transport=transport)
```

### HTTP Transport

For HTTP-based MCP servers:

```python
from multi_agent_base.mcp import HTTPTransport, MCPClient

transport = HTTPTransport(
    url="http://localhost:8080",
    headers={"Authorization": "Bearer token"},
)

client = MCPClient(transport=transport)
```

### SSE Transport

For Server-Sent Events:

```python
from multi_agent_base.mcp import SSETransport, MCPClient

transport = SSETransport(
    url="http://localhost:8080/events",
    post_url="http://localhost:8080/message",
)

client = MCPClient(transport=transport)
```

## Integration with Agent Framework

### Converting MCP Tools to Framework Tools

```python
from multi_agent_base.mcp import discover_and_convert, MCPClient

async with MCPClient.stdio("python", "mcp_server.py") as client:
    # Get JSON schemas compatible with OpenAI function calling
    tool_schemas = await discover_and_convert(client)
    
    # Use with agent
    response = await agent.chat_completion(
        messages=[{"role": "user", "content": "Search for AI"}],
        tools=tool_schemas,
    )
```

### Creating an MCP-Enabled Agent

```python
from multi_agent_base.mcp import MCPClient, MCPToolWrapper
from multi_agent_base import BaseAgent

class MCPEnabledAgent(BaseAgent):
    def __init__(self, mcp_servers: list[dict]):
        super().__init__()
        self.mcp_clients = []
        self.mcp_wrapper = None
        
        for server_config in mcp_servers:
            client = MCPClient.stdio(
                server_config["command"],
                *server_config.get("args", []),
            )
            self.mcp_clients.append(client)
    
    async def __aenter__(self):
        for client in self.mcp_clients:
            await client.__aenter__()
        
        # Discover all tools
        self.mcp_wrapper = MCPToolWrapper(self.mcp_clients[0])
        await self.mcp_wrapper.discover()
        
        return self
    
    async def call_mcp_tool(self, name: str, **kwargs):
        return await self.mcp_wrapper(name, **kwargs)
```

## Best Practices

### Error Handling

```python
from multi_agent_base.mcp import MCPClient, MCPError

async with MCPClient.stdio("python", "server.py") as client:
    try:
        result = await client.call_tool("risky_operation", {})
    except RuntimeError as e:
        print(f"Tool call failed: {e}")
```

### Timeout Configuration

```python
from multi_agent_base.mcp import MCPClient, MCPClientConfig

config = MCPClientConfig(
    timeout=60.0,  # Default timeout
    connect_timeout=10.0,
)

client = MCPClient.stdio("python", "server.py", config=config)
```

### Logging

```python
import logging

# Enable MCP logging
logging.getLogger("multi_agent_base.mcp").setLevel(logging.DEBUG)
```

## Protocol Version

The module implements MCP protocol version `2025-06-18`:

```python
from multi_agent_base.mcp import MCP_PROTOCOL_VERSION

print(f"Using MCP protocol: {MCP_PROTOCOL_VERSION}")
```

## See Also

- [MCP Specification](https://spec.modelcontextprotocol.io/)
- [Tool Registry](../core/registry.md)
- [Agent Framework Integration](../core/agent.md)
