# Memory Module

The Memory module provides flexible conversation memory management for agents. It supports multiple backend types from simple in-memory buffers to vector-based semantic search.

## Memory Backends

### InMemoryBackend

Simple in-memory storage, ideal for development and testing.

```python
from multi_agent_base.memory import InMemoryBackend

backend = InMemoryBackend()

# Store a message
await backend.add(MemoryEntry(
    role="user",
    content="Hello, world!"
))

# Retrieve messages
messages = await backend.get_all()
```

### BufferMemory

Fixed-size buffer that keeps the N most recent messages.

```python
from multi_agent_base.memory import BufferMemory

# Keep last 50 messages
memory = BufferMemory(max_messages=50)

# Use in agent
agent = BaseAgent(
    config=agent_config,
    memory_backend=memory,
)
```

### SlidingWindowMemory

Token-based window that maintains a maximum token count.

```python
from multi_agent_base.memory import SlidingWindowMemory

# Keep up to 4000 tokens of context
memory = SlidingWindowMemory(max_tokens=4000)
```

### SummaryMemory

Automatically summarizes older conversations to save tokens.

```python
from multi_agent_base.memory import SummaryMemory

memory = SummaryMemory(
    summarizer=my_summarizer_fn,  # Function to create summaries
    summary_threshold=20,          # Summarize after 20 messages
)
```

### VectorMemory

Embedding-based semantic memory for RAG applications.

```python
from multi_agent_base.memory import VectorMemory

memory = VectorMemory(
    embedding_fn=my_embedding_function,
    dimensions=1536,
    similarity_threshold=0.7,
)

# Semantic search
results = await memory.search("What did we discuss about Python?", top_k=5)
```

### RedisMemory

Persistent memory using Redis for distributed/production environments.

```python
from multi_agent_base.memory import RedisMemory

memory = RedisMemory(
    redis_url="redis://localhost:6379",
    key_prefix="agent:memory:",
    ttl_seconds=3600,  # 1 hour TTL
)
```

### CompositeMemory

Combines multiple memory backends with different strategies.

```python
from multi_agent_base.memory import CompositeMemory

memory = CompositeMemory(
    backends=[
        BufferMemory(max_messages=10),   # Recent context
        VectorMemory(embedding_fn=fn),    # Semantic search
    ],
    merge_strategy="union",  # or "priority"
)
```

## Configuration

Configure memory in your `SystemConfig`:

```python
from multi_agent_base.core.config import SystemConfig, MemoryConfig, MemoryBackendType

config = SystemConfig(
    memory=MemoryConfig(
        enabled=True,
        backend=MemoryBackendType.BUFFER,
        max_entries=100,
        persist=False,
    ),
)
```

## Using with Agents

Memory backends integrate seamlessly with `BaseAgent`:

```python
from multi_agent_base.core.agent import BaseAgent
from multi_agent_base.memory import BufferMemory

# Create memory backend
memory = BufferMemory(max_messages=100)

# Create agent with memory
agent = BaseAgent(
    config=agent_config,
    memory_backend=memory,
)

# Run agent - memory is automatically managed
response = agent.run("Hello!")

# Search memory
results = agent.search_memory("previous conversation about Python")

# Clear memory
agent.clear_memory()
```

## Memory Entry Structure

```python
from multi_agent_base.memory import MemoryEntry

entry = MemoryEntry(
    role="user",           # "user", "assistant", "system", "tool"
    content="Hello!",       # Message content
    metadata={              # Optional metadata
        "tool_calls": [],
        "model": "gpt-4o",
        "timestamp": "...",
    },
)
```

## Best Practices

1. **Choose the right backend**: 
   - Development: `InMemoryBackend` or `BufferMemory`
   - Production: `RedisMemory` or `CompositeMemory`
   - RAG: `VectorMemory`

2. **Set appropriate limits**:
   - Match `max_tokens` to your model's context window
   - Leave room for system prompt and response

3. **Consider persistence**:
   - Use `RedisMemory` for distributed systems
   - Use file-based persistence for single instances

4. **Use semantic search**:
   - `VectorMemory` enables RAG patterns
   - Combine with `BufferMemory` in `CompositeMemory`
