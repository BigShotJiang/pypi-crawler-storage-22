# 🖼️ Multimodal Support

Multi-Agent Base Framework'ün multimodal modülü, text, image, audio ve video içeriklerinin farklı AI provider'lar arasında birleşik bir şekilde işlenmesini sağlar.

## 📋 İçindekiler

- [Hızlı Başlangıç](#-hızlı-başlangıç)
- [MediaContent](#-mediacontent)
- [MultimodalMessage](#-multimodalmessage)
- [Provider Formatları](#-provider-formatları)
- [Encoding Utilities](#-encoding-utilities)
- [Media Processing](#-media-processing)
- [Provider Capabilities](#-provider-capabilities)
- [Best Practices](#-best-practices)

---

## 🚀 Hızlı Başlangıç

### Kurulum

```python
from multi_agent_base.multimodal import (
    MediaContent,
    MultimodalMessage,
    ImageProcessor,
    Base64Encoder,
)
```

### Temel Kullanım

```python
# Dosyadan image yükle
image = MediaContent.from_file("photo.jpg")

# URL'den image
image = MediaContent.from_url("https://example.com/image.png")

# Mesaj oluştur
message = MultimodalMessage.with_image(
    text="Bu resimde ne var?",
    image="./photo.jpg"
)

# Provider formatına çevir
openai_format = message.to_openai_format()
anthropic_format = message.to_anthropic_format()
```

---

## 📦 MediaContent

`MediaContent` sınıfı, tüm medya türleri için birleşik bir container sağlar.

### Oluşturma Metodları

#### Dosyadan Yükleme

```python
from multi_agent_base.multimodal import MediaContent

# Image
image = MediaContent.from_file("photo.jpg")
image = MediaContent.from_file("/path/to/image.png")

# Audio
audio = MediaContent.from_file("recording.mp3")

# Video
video = MediaContent.from_file("video.mp4")

# PDF
document = MediaContent.from_file("document.pdf")
```

#### URL'den Oluşturma

```python
# URL-based content (içerik indirilmez)
image = MediaContent.from_url("https://example.com/photo.jpg")

# Media type belirterek
audio = MediaContent.from_url(
    "https://example.com/audio/track",
    media_type=MediaType.AUDIO
)
```

#### Base64'ten Oluşturma

```python
import base64

# Base64 encoded data
b64_data = base64.b64encode(image_bytes).decode()
image = MediaContent.from_base64(b64_data, "image/png")
```

#### Raw Bytes'tan Oluşturma

```python
# Doğrudan bytes'tan
image = MediaContent.from_bytes(
    data=image_bytes,
    mime_type="image/jpeg",
    filename="photo.jpg"
)
```

### Dönüşüm Metodları

```python
image = MediaContent.from_file("photo.jpg")

# Base64'e çevir
b64 = image.to_base64()

# Data URI oluştur
uri = image.to_data_uri()  # data:image/jpeg;base64,...

# Provider formatlarına çevir
openai = image.to_openai_format()
anthropic = image.to_anthropic_format()
ollama = image.to_ollama_format()
google = image.to_google_format()
```

### Validasyon

```python
# Provider için validate et
errors = image.validate_for_provider("anthropic")
if errors:
    print(f"Validation errors: {errors}")
```

### Properties

```python
image = MediaContent.from_file("photo.jpg")

# Boyut bilgisi
print(f"Size: {image.size_bytes} bytes")
print(f"Size: {image.size_mb:.2f} MB")

# Media type
print(f"Type: {image.media_type}")  # MediaType.IMAGE
print(f"MIME: {image.mime_type}")   # image/jpeg
print(f"Filename: {image.filename}")
```

---

## 💬 MultimodalMessage

`MultimodalMessage` sınıfı, text ve medya içeriklerini birleştiren mesajlar oluşturur.

### Oluşturma Metodları

#### Text-Only Mesaj

```python
from multi_agent_base.multimodal import MultimodalMessage

message = MultimodalMessage.from_text("Merhaba!")
message = MultimodalMessage.from_text("Ben asistanım", role="assistant")
```

#### Tek Image ile Mesaj

```python
# Dosya path'i ile
message = MultimodalMessage.with_image(
    text="Bu resmi analiz et",
    image="photo.jpg"
)

# URL ile
message = MultimodalMessage.with_image(
    text="Bu resmi incele",
    image="https://example.com/image.png"
)

# MediaContent ile
content = MediaContent.from_file("photo.jpg")
message = MultimodalMessage.with_image(
    text="Ne görüyorsun?",
    image=content
)
```

#### Çoklu Image ile Mesaj

```python
message = MultimodalMessage.with_images(
    text="Bu resimleri karşılaştır",
    images=["image1.jpg", "image2.jpg", "https://example.com/image3.png"]
)
```

#### Audio ile Mesaj

```python
message = MultimodalMessage.with_audio(
    text="Bu ses kaydını transkript et",
    audio="recording.mp3"
)
```

#### Document ile Mesaj

```python
message = MultimodalMessage.with_document(
    text="Bu PDF'i özetle",
    document="report.pdf"
)
```

### Method Chaining

```python
message = (
    MultimodalMessage.from_text("Birden fazla resim")
    .add_image("image1.jpg")
    .add_image("image2.png")
    .add_document("notes.pdf")
)
```

### Provider Formatları

```python
message = MultimodalMessage.with_image(
    text="Analiz et",
    image="photo.jpg"
)

# OpenAI format (GPT-4V, GPT-4o)
openai_msg = message.to_openai_format()
# {
#     "role": "user",
#     "content": [
#         {"type": "text", "text": "Analiz et"},
#         {"type": "image_url", "image_url": {"url": "data:..."}}
#     ]
# }

# Anthropic format (Claude 3)
anthropic_msg = message.to_anthropic_format()
# {
#     "role": "user",
#     "content": [
#         {"type": "image", "source": {"type": "base64", ...}},
#         {"type": "text", "text": "Analiz et"}
#     ]
# }

# Ollama format (LLaVA)
ollama_msg = message.to_ollama_format()
# {
#     "role": "user",
#     "content": "Analiz et",
#     "images": ["base64..."]
# }

# Google Gemini format
google_msg = message.to_google_format()
# {
#     "role": "user",
#     "parts": [
#         {"text": "Analiz et"},
#         {"inline_data": {"mime_type": "image/jpeg", "data": "..."}}
#     ]
# }
```

### Generic Provider Conversion

```python
# Tek method ile istenen provider'a çevir
openai = message.to_provider_format("openai")
anthropic = message.to_provider_format("anthropic")
ollama = message.to_provider_format("ollama")
google = message.to_provider_format("google")
```

---

## 🔄 Provider Formatları

### OpenAI (GPT-4V, GPT-4o)

```python
from multi_agent_base.multimodal import MultimodalMessage

message = MultimodalMessage.with_image(
    text="Describe this image",
    image="photo.jpg"
)

# URL tercih et (eğer mevcutsa)
result = message.to_openai_format(prefer_url=True)

# Her zaman base64 kullan
result = message.to_openai_format(prefer_url=False)
```

**OpenAI Format Özellikleri:**
- URL ve base64 destekler
- Image: `image_url` type
- Audio: `input_audio` type

### Anthropic (Claude 3)

```python
message = MultimodalMessage.with_image(
    text="Analyze this",
    image=MediaContent.from_file("photo.jpg")  # Data gerekli
)

result = message.to_anthropic_format()
```

**Anthropic Format Özellikleri:**
- Sadece base64 destekler (URL desteklenmez!)
- Image'lar text'ten önce gelir
- PDF documents desteklenir

### Ollama (LLaVA, BakLLaVA)

```python
result = message.to_ollama_format()
# {
#     "role": "user",
#     "content": "text",
#     "images": ["base64_1", "base64_2"]
# }
```

**Ollama Format Özellikleri:**
- Sadece base64 destekler
- Images ayrı bir array olarak

### Google Gemini

```python
result = message.to_google_format(prefer_url=False)
```

**Google Format Özellikleri:**
- URL ve base64 destekler
- Video ve audio destekler
- "assistant" role'ü "model" olarak dönüşür

---

## 🔧 Encoding Utilities

### Base64Encoder

```python
from multi_agent_base.multimodal import Base64Encoder

# Encode/Decode
encoded = Base64Encoder.encode(b"data")
decoded = Base64Encoder.decode(encoded)

# File işlemleri
encoded = Base64Encoder.encode_file("image.png")
Base64Encoder.decode_to_file(encoded, "output.png")

# Data URI
uri = Base64Encoder.to_data_uri(data, "image/png")
decoded = Base64Encoder.from_data_uri(uri)

# Validation
is_valid = Base64Encoder.is_valid_base64(text)
is_uri = Base64Encoder.is_data_uri(text)
```

### URLEncoder

```python
from multi_agent_base.multimodal import URLEncoder

# Validation
is_valid = URLEncoder.is_valid_url("https://example.com")

# Type detection
is_image = URLEncoder.is_image_url("https://example.com/photo.jpg")
is_audio = URLEncoder.is_audio_url("https://example.com/song.mp3")
is_video = URLEncoder.is_video_url("https://example.com/video.mp4")

# URL parsing
extension = URLEncoder.get_extension("https://example.com/file.png")  # .png
filename = URLEncoder.get_filename("https://example.com/path/file.png")  # file.png
mime_type = URLEncoder.get_mime_type("https://example.com/image.png")  # image/png

# URL building
url = URLEncoder.build_url(
    "https://api.example.com",
    "/v1/search",
    {"q": "test", "limit": 10}
)
```

### ContentHasher

```python
from multi_agent_base.multimodal import ContentHasher

# Hash content
hash_val = ContentHasher.hash_bytes(data)
hash_val = ContentHasher.hash_file("image.png")

# Compare content
is_same = ContentHasher.compare(data1, data2)
is_same = ContentHasher.compare_files("file1.png", "file2.png")

# Generate content ID
content_id = ContentHasher.generate_content_id(data)  # 16 char hash
```

### MIMETypeDetector

```python
from multi_agent_base.multimodal import MIMETypeDetector

# Detect from bytes (magic numbers)
mime = MIMETypeDetector.from_bytes(data)  # "image/png"

# Detect from file
mime = MIMETypeDetector.from_file("image.png")

# From extension
mime = MIMETypeDetector.from_extension(".png")  # "image/png"

# Get extension
ext = MIMETypeDetector.get_extension("image/png")  # ".png"

# Type checks
is_image = MIMETypeDetector.is_image("image/png")  # True
is_audio = MIMETypeDetector.is_audio("audio/mp3")  # True
is_video = MIMETypeDetector.is_video("video/mp4")  # True
```

---

## 🖼️ Media Processing

### ImageProcessor

```python
from multi_agent_base.multimodal import (
    ImageProcessor,
    ImageDimensions,
    MediaContent
)

# Get image dimensions
dims = ImageProcessor.get_dimensions(image_bytes)
print(f"Size: {dims.width}x{dims.height}")
print(f"Aspect ratio: {dims.aspect_ratio}")
print(f"Orientation: {'landscape' if dims.is_landscape else 'portrait'}")

# Validate image
is_valid = ImageProcessor.is_valid_image(data)

# Get format
fmt = ImageProcessor.get_format(data)  # ImageFormat.PNG

# Validate for provider
content = MediaContent.from_file("image.png")
is_valid, errors = ImageProcessor.validate_for_provider(content, "anthropic")

# Prepare for provider
result = ImageProcessor.prepare_for_provider(content, "openai")
if result.success:
    prepared_content = result.to_media_content()
```

### ImageDimensions

```python
from multi_agent_base.multimodal import ImageDimensions

dims = ImageDimensions(1920, 1080)

# Properties
print(dims.aspect_ratio)  # 1.777...
print(dims.is_landscape)  # True
print(dims.is_portrait)   # False
print(dims.is_square)     # False

# Check if fits
fits = dims.fits_in(2000, 2000)  # True

# Scale to fit
scaled = dims.scale_to_fit(1000, 1000)
print(f"Scaled: {scaled.width}x{scaled.height}")  # 1000x562
```

### AudioProcessor

```python
from multi_agent_base.multimodal import AudioProcessor, AudioInfo

# Validate audio
is_valid = AudioProcessor.is_valid_audio(data)

# Get audio info (WAV, MP3)
info = AudioProcessor.get_info(data, "audio/wav")
print(f"Duration: {info.duration_formatted}")  # "02:30"
print(f"Sample rate: {info.sample_rate}")
print(f"Channels: {info.channels}")
```

### MediaProcessor

Tüm medya türlerini işleyen birleşik processor:

```python
from multi_agent_base.multimodal import MediaProcessor, MediaContent

processor = MediaProcessor()

# Get info for any media type
content = MediaContent.from_file("photo.jpg")
info = processor.get_info(content)  # ImageDimensions

content = MediaContent.from_file("audio.mp3")
info = processor.get_info(content)  # AudioInfo

# Validate for provider
is_valid, errors = processor.validate(content, "openai")

# Process for provider
result = processor.process(content, "anthropic")

# Detect media type
media_type = processor.detect_media_type(data)  # MediaType.IMAGE
```

---

## 📊 Provider Capabilities

Her provider'ın desteklediği özellikler:

```python
from multi_agent_base.multimodal import PROVIDER_CAPABILITIES

# OpenAI capabilities
openai = PROVIDER_CAPABILITIES["openai"]
print(openai["supports_url"])        # True
print(openai["supports_base64"])     # True
print(openai["max_image_size_mb"])   # 20
print(openai["image_formats"])       # [JPEG, PNG, GIF, WEBP]

# Anthropic capabilities
anthropic = PROVIDER_CAPABILITIES["anthropic"]
print(anthropic["supports_url"])     # False (!)
print(anthropic["max_image_size_mb"]) # 5

# Ollama capabilities
ollama = PROVIDER_CAPABILITIES["ollama"]
print(ollama["supports_url"])        # False

# Google capabilities
google = PROVIDER_CAPABILITIES["google"]
print(google["video_formats"])       # [MP4, WEBM]
```

### Provider Comparison

| Feature | OpenAI | Anthropic | Ollama | Google |
|---------|--------|-----------|--------|--------|
| URL Support | ✅ | ❌ | ❌ | ✅ |
| Base64 Support | ✅ | ✅ | ✅ | ✅ |
| Max Image Size | 20MB | 5MB | 10MB | 20MB |
| Audio Support | ✅ | ❌ | ❌ | ✅ |
| Video Support | ❌ | ❌ | ❌ | ✅ |
| PDF Support | ❌ | ✅ | ❌ | ❌ |

---

## ✅ Best Practices

### 1. Provider-Aware Content Creation

```python
# ❌ Yanlış: URL ile Anthropic
image = MediaContent.from_url("https://example.com/image.png")
message = MultimodalMessage.with_image("Describe", image)
result = message.to_anthropic_format()  # Hata verir!

# ✅ Doğru: Anthropic için file/bytes kullan
image = MediaContent.from_file("image.png")
message = MultimodalMessage.with_image("Describe", image)
result = message.to_anthropic_format()  # Çalışır
```

### 2. Validation Before Sending

```python
message = MultimodalMessage.with_image("Describe", "photo.jpg")

# Provider'a göndermeden önce validate et
errors = message.validate_for_provider("anthropic")
if errors:
    print(f"Cannot send to Anthropic: {errors}")
else:
    result = message.to_anthropic_format()
```

### 3. Size Management

```python
from multi_agent_base.multimodal import PROVIDER_CAPABILITIES

content = MediaContent.from_file("large_image.png")

# Boyut kontrolü
max_size = PROVIDER_CAPABILITIES["anthropic"]["max_image_size_mb"]
if content.size_mb > max_size:
    print(f"Image too large for Anthropic: {content.size_mb}MB > {max_size}MB")
```

### 4. Lazy Loading for URLs

```python
# URL content'ı tembel yüklenir - sadece gerektiğinde
images = [
    MediaContent.from_url("https://example.com/image1.png"),
    MediaContent.from_url("https://example.com/image2.png"),
]

# to_base64() çağrılana kadar içerik indirilmez
# Bu OpenAI için idealdir (URL destekler)
message = MultimodalMessage.with_images("Compare", images)
openai_format = message.to_openai_format(prefer_url=True)  # URL'ler kullanılır
```

### 5. Content ID for Caching

```python
from multi_agent_base.multimodal import ContentHasher

content = MediaContent.from_file("image.png")
content_id = ContentHasher.generate_content_id(content.data)

# Cache key olarak kullan
cache_key = f"analysis:{content_id}"
```

---

## 🔍 Tam Örnek

```python
from multi_agent_base.multimodal import (
    MediaContent,
    MultimodalMessage,
    ImageProcessor,
    PROVIDER_CAPABILITIES,
)

async def analyze_image(image_path: str, provider: str = "openai"):
    """Resmi analiz et ve provider'a gönder."""
    
    # Content oluştur
    content = MediaContent.from_file(image_path)
    
    # Boyut ve format kontrolü
    dims = ImageProcessor.get_dimensions(content.data)
    print(f"Image: {dims.width}x{dims.height}")
    
    # Provider validation
    caps = PROVIDER_CAPABILITIES[provider]
    if content.size_mb > caps["max_image_size_mb"]:
        raise ValueError(f"Image too large for {provider}")
    
    # Mesaj oluştur
    message = MultimodalMessage.with_image(
        text="Describe what you see in this image in detail.",
        image=content
    )
    
    # Validate
    errors = message.validate_for_provider(provider)
    if errors:
        raise ValueError(f"Validation errors: {errors}")
    
    # Provider formatına çevir
    formatted = message.to_provider_format(provider)
    
    return formatted

# Kullanım
result = await analyze_image("photo.jpg", "openai")
print(result)
```

---

## 📚 API Reference

### Types

| Class | Description |
|-------|-------------|
| `MediaContent` | Unified media content container |
| `MultimodalMessage` | Message with text and media |
| `MediaType` | Enum: IMAGE, AUDIO, VIDEO, DOCUMENT |
| `ImageFormat` | Enum: JPEG, PNG, GIF, WEBP, etc. |
| `AudioFormat` | Enum: MP3, WAV, OGG, etc. |
| `VideoFormat` | Enum: MP4, WEBM, MOV, etc. |

### Encoders

| Class | Description |
|-------|-------------|
| `Base64Encoder` | Base64 encoding utilities |
| `URLEncoder` | URL parsing and validation |
| `ContentHasher` | Content hashing utilities |
| `MIMETypeDetector` | MIME type detection |

### Processors

| Class | Description |
|-------|-------------|
| `ImageProcessor` | Image processing and validation |
| `AudioProcessor` | Audio processing |
| `VideoProcessor` | Video processing |
| `MediaProcessor` | Unified media processor |

### Info Types

| Class | Description |
|-------|-------------|
| `ImageDimensions` | Image size information |
| `AudioInfo` | Audio file information |
| `VideoInfo` | Video file information |
| `ProcessingResult` | Processing operation result |
