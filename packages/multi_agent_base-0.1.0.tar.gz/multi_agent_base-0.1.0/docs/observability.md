# Observability

Comprehensive guide to tracing and logging with Arize Phoenix.

## Overview

The Multi-Agent Base framework provides two layers of observability:
1. **Distributed Tracing**: OpenTelemetry-based tracing with Phoenix
2. **Structured Logging**: Detailed event logging for debugging

## Setting Up Phoenix

### Local Phoenix Server

```bash
# Install Phoenix
pip install arize-phoenix

# Start Phoenix server
phoenix serve
```

Phoenix will be available at `http://localhost:6006`.

### Docker Deployment

```yaml
# docker-compose.yml
version: '3.8'
services:
  phoenix:
    image: arizephoenix/phoenix:latest
    ports:
      - "6006:6006"
    volumes:
      - phoenix_data:/data
volumes:
  phoenix_data:
```

## Configuring Tracing

### Basic Setup

```python
from multi_agent_base.observability import setup_phoenix, PhoenixConfig

# Quick setup
tracer = setup_phoenix(
    endpoint="http://localhost:6006",
    project_name="my-agents",
    launch_app=True,  # Opens Phoenix UI
)
```

### Advanced Configuration

```python
from multi_agent_base.observability import PhoenixTracer, PhoenixConfig

config = PhoenixConfig(
    endpoint="http://localhost:6006",
    project_name="production-agents",
    enabled=True,
    export_to_collector=True,
    launch_app=False,
)

tracer = PhoenixTracer(config)
tracer.setup()
```

### Integration with Patterns

```python
from multi_agent_base import SystemConfig, SingleAgentPattern
from multi_agent_base.observability import setup_phoenix, create_logger

# Set up tracing
tracer = setup_phoenix(project_name="my-agents")

# Set up logging
logger = create_logger(console=True, file_path="logs/agents.jsonl")

# Create pattern with observability
config = SystemConfig.from_env()
pattern = SingleAgentPattern(config, logger=logger)
```

## Custom Traces

### Creating Spans

```python
from multi_agent_base.observability import get_tracer

tracer = get_tracer()

# Simple span
with tracer.start_span("custom_operation", attributes={"key": "value"}):
    # Your code here
    result = do_something()

# With more details
with tracer.start_span(
    "database_query",
    attributes={"query": "SELECT *", "table": "users"},
    kind="client",
) as span:
    result = query_database()
    span.set_attribute("row_count", len(result))
```

### Tracing LLM Calls

```python
tracer.trace_llm_call(
    model="gpt-4o-mini",
    provider="openai",
    messages=[{"role": "user", "content": "Hello"}],
    response="Hi there!",
    usage={"prompt_tokens": 10, "completion_tokens": 5},
    duration_ms=150.0,
)
```

### Tracing Tool Calls

```python
tracer.trace_tool_call(
    tool_name="search_web",
    agent_name="assistant",
    arguments={"query": "AI news"},
    result=["Result 1", "Result 2"],
    duration_ms=500.0,
    success=True,
)
```

### Tracing Agent Runs

```python
tracer.trace_agent_run(
    agent_name="assistant",
    input_message="What's the weather?",
    output_message="It's sunny today.",
    duration_ms=1200.0,
    tool_calls=[{"name": "get_weather"}],
    usage={"prompt_tokens": 50, "completion_tokens": 20},
    cost=0.001,
)
```

## Structured Logging

### Creating a Logger

```python
from multi_agent_base.observability import (
    AgentLogger,
    create_logger,
    StreamHandler,
    FileHandler,
    ConsoleFormatter,
    JSONFormatter,
    LogLevel,
)

# Simple logger
logger = create_logger(
    console=True,
    file_path="logs/agents.jsonl",
    min_level=LogLevel.INFO,
)

# Custom logger with multiple handlers
logger = AgentLogger(handlers=[
    StreamHandler(
        formatter=ConsoleFormatter(colors=True),
        min_level=LogLevel.DEBUG,
    ),
    FileHandler(
        path="logs/debug.jsonl",
        formatter=JSONFormatter(),
        min_level=LogLevel.DEBUG,
    ),
    FileHandler(
        path="logs/errors.jsonl",
        formatter=JSONFormatter(),
        min_level=LogLevel.ERROR,
    ),
])
```

### Logging Events

```python
# Agent lifecycle
logger.log_agent_start("assistant", metadata={"version": "1.0"})
logger.log_agent_end("assistant", duration_ms=5000.0)

# Messages
logger.log_message("assistant", {"role": "user", "content": "Hello"}, direction="in")
logger.log_message("assistant", {"role": "assistant", "content": "Hi!"}, direction="out")

# Tool calls
logger.log_tool_call(
    agent_name="assistant",
    tool_name="search",
    arguments={"query": "AI"},
    result="Found 10 results",
    duration_ms=200.0,
)

# LLM calls
logger.log_llm_call(
    agent_name="assistant",
    model="gpt-4o-mini",
    provider="openai",
    input_tokens=100,
    output_tokens=50,
    duration_ms=300.0,
    cost=0.001,
)

# Errors
logger.log_error("assistant", "API rate limit exceeded", error_type="rate_limit")

# Handoffs
logger.log_handoff("sales", "support", reason="Technical issue")
```

### Custom Event Types

```python
from multi_agent_base.observability import LogEvent, EventType, LogLevel

event = LogEvent(
    event_type=EventType.TOOL_CALL,
    agent_name="assistant",
    message="Custom event",
    data={"custom_field": "value"},
    level=LogLevel.INFO,
)

logger.log(event)
```

### Querying Events

```python
# Get all events for an agent
events = logger.get_events(agent_name="assistant")

# Get events by type
tool_events = logger.get_events(event_type=EventType.TOOL_CALL)

# Clear event history
logger.clear_events()
```

## Log Output Formats

### Console Format

```
[14:30:45.123] [INFO] [assistant] message.in - [user] What's the weather?
[14:30:45.456] [INFO] [assistant] tool.call - Tool get_weather called (200.00ms)
[14:30:46.789] [INFO] [assistant] message.out - [assistant] It's sunny today
[14:30:46.790] [INFO] [assistant] agent.end - Run complete (1567.00ms)
```

### JSON Format

```json
{"event_type": "message.in", "agent_name": "assistant", "timestamp": "2024-01-15T14:30:45.123000", "message": "[user] What's the weather?", "level": "info", "data": {"role": "user", "content": "What's the weather?"}}
{"event_type": "tool.call", "agent_name": "assistant", "timestamp": "2024-01-15T14:30:45.456000", "message": "Tool get_weather called", "level": "info", "duration_ms": 200.0}
```

## Viewing in Phoenix

### Traces View

Phoenix provides a web UI for viewing traces:
- Timeline of agent operations
- Nested spans for LLM and tool calls
- Latency analysis
- Token usage visualization

### Filtering

Filter traces by:
- Project name
- Time range
- Agent name
- Error status

## Best Practices

1. **Use Project Names**: Group related traces with project names
2. **Add Metadata**: Include relevant metadata in spans
3. **Track Costs**: Enable cost tracking for budget monitoring
4. **Log Levels**: Use appropriate log levels (DEBUG for development, INFO for production)
5. **File Rotation**: Implement log rotation for production deployments
6. **Sampling**: Consider trace sampling for high-volume applications

## Troubleshooting

### Phoenix Not Receiving Traces

1. Check Phoenix is running: `curl http://localhost:6006`
2. Verify endpoint configuration
3. Check network connectivity
4. Ensure `export_spans=True`

### Missing Log Files

1. Verify directory exists and is writable
2. Check file path configuration
3. Ensure handler is added to logger

### Performance Impact

If observability affects performance:
1. Reduce log level
2. Disable console output in production
3. Use async handlers for files
4. Consider trace sampling
