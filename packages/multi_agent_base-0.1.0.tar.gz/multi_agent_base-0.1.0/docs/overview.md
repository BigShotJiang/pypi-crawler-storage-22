# Genel Bakış

Microsoft Agent Framework, AI agent'lar ve multi-agent workflow'lar oluşturmak için açık kaynaklı bir geliştirme kitidir.

---

## Agent Framework Nedir?

Agent Framework iki temel yetenek sunar:

### 🤖 AI Agents
Kullanıcı girdilerini işleyen, tool'ları çağıran ve yanıt üreten bağımsız agent'lar.

```
┌─────────────────────────────────────────────────────┐
│                     AI Agent                        │
│  ┌─────────┐  ┌─────────┐  ┌─────────┐             │
│  │   LLM   │  │  Tools  │  │ Memory  │             │
│  └────┬────┘  └────┬────┘  └────┬────┘             │
│       │            │            │                   │
│       └────────────┴────────────┘                   │
│                    │                                │
│              ┌─────┴─────┐                         │
│              │  Response │                         │
│              └───────────┘                         │
└─────────────────────────────────────────────────────┘
```

### 📊 Workflows
Birden fazla agent ve fonksiyonu birleştiren graf tabanlı iş akışları.

```
┌──────────┐    ┌──────────┐    ┌──────────┐
│  Agent 1 │───▶│  Agent 2 │───▶│ Function │
└──────────┘    └──────────┘    └──────────┘
                     │
                     ▼
               ┌──────────┐
               │  Agent 3 │
               └──────────┘
```

---

## Ne Zaman Agent Kullanmalı?

Agent'lar şu durumlar için uygundur:

| ✅ Uygun | ❌ Uygun Değil |
|----------|----------------|
| Dinamik karar verme | Sabit kurallar |
| Belirsiz görevler | Önceden tanımlı adımlar |
| Keşif gerektiren işler | Deterministik süreçler |
| Kullanıcı etkileşimi | Basit hesaplamalar |

### Örnek Senaryolar

- **Müşteri Desteği**: Çoklu sorguları işleme, bilgi arama
- **Kod Geliştirme**: Kod üretme, debug, review
- **Araştırma**: Web arama, doküman özetleme
- **Eğitim**: Kişiselleştirilmiş öğretim

---

## Ne Zaman Workflow Kullanmalı?

Workflow'lar şu durumlar için uygundur:

| Özellik | Açıklama |
|---------|----------|
| **Modülerlik** | Küçük, yeniden kullanılabilir bileşenler |
| **Type Safety** | Mesajların doğru akması için tip kontrolü |
| **Koşullu Akış** | Dinamik yönlendirme |
| **Checkpointing** | Durum kaydetme ve devam ettirme |
| **Human-in-the-Loop** | İnsan onayı gerektiren adımlar |

### Örnek Workflow

```
Email Geldi
    │
    ▼
┌──────────────┐
│ Preprocessor │ ─────▶ Email temizleme
└──────────────┘
    │
    ▼
┌──────────────┐
│   Analyzer   │ ─────▶ İçerik analizi
└──────────────┘
    │
    ▼
┌──────────────┐
│ Spam Check   │
└──────────────┘
    │
    ├─── Spam ───▶ Karantina
    │
    └─── Değil ──▶ Yanıt Gönder
```

---

## Temel Kavramlar

### ChatAgent
LLM ile çalışan temel agent sınıfı.

```python
from agent_framework import ChatAgent

agent = ChatAgent(
    chat_client=client,
    name="MyAgent",
    instructions="Yardımcı bir asistan ol.",
    tools=[my_tool],
)
```

### Tool
Agent'ın kullanabileceği fonksiyonlar.

```python
from agent_framework import tool

@tool
def search_web(query: str) -> str:
    """Web'de arama yap."""
    return search_results
```

### Workflow
Birden fazla adımı birleştiren iş akışı.

```python
from agent_framework import WorkflowBuilder, Executor

workflow = (
    WorkflowBuilder(name="MyWorkflow")
    .set_start_executor(step1)
    .add_edge(step1, step2)
    .add_edge(step2, step3)
    .build()
)
```

### DevUI
Geliştirme ve debug için web arayüzü.

```python
from agent_framework.devui import serve

serve(entities=[agent], port=8080)
```

---

## Sonraki Adımlar

- [Hızlı Başlangıç](./quick-start.md) - İlk agent'ınızı oluşturun
- [Kurulum](./installation.md) - Detaylı kurulum
- [DevUI Özellikleri](./devui-features.md) - Arayüzü keşfedin

---

*[← Ana Sayfa](./README.md) | [Hızlı Başlangıç →](./quick-start.md)*
