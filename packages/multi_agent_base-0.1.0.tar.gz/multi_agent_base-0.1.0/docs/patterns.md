# Architecture Patterns

The Multi-Agent Base framework provides comprehensive architecture patterns for building agent systems.

## Overview

| Pattern | Use Case | Complexity | Scalability |
|---------|----------|------------|-------------|
| SingleAgent | Simple tasks, Q&A | Low | Low |
| Supervisor | Complex workflows | Medium | Medium |
| Swarm | Dynamic routing | High | High |
| Debate | Balanced analysis | Medium | Medium |
| **Pipeline** | Sequential processing | Low-Medium | Medium |
| **Parallel** | Concurrent tasks | Medium | High |
| **Router** | Intent-based routing | Medium | High |
| **Reflection** | Self-improvement | Medium | Low |
| **Blackboard** | Shared knowledge | High | High |
| **Composite** | Complex workflows | High | High |

## Single Agent Pattern

The simplest pattern with a single agent that can use tools.

### When to Use

- Simple Q&A applications
- Single-purpose assistants
- Tasks that don't require collaboration
- Prototyping and testing

### Architecture

```
┌─────────────────────────────────────┐
│            User Input               │
└─────────────────────────────────────┘
                  │
                  ▼
┌─────────────────────────────────────┐
│           Single Agent              │
│  ┌─────────────────────────────────┐│
│  │        System Prompt            ││
│  │        Tool Access              ││
│  │        Memory                   ││
│  └─────────────────────────────────┘│
└─────────────────────────────────────┘
                  │
                  ▼
┌─────────────────────────────────────┐
│            Response                 │
└─────────────────────────────────────┘
```

### Example

```python
from multi_agent_base import SystemConfig, SingleAgentPattern
from multi_agent_base.cost import CostTracker

async def main():
    config = SystemConfig.from_env()
    cost_tracker = CostTracker()
    
    pattern = SingleAgentPattern(config, cost_tracker=cost_tracker)
    
    # Define tools
    def search_database(query: str) -> list[str]:
        """Search the internal database.
        
        Args:
            query: Search query
            
        Returns:
            List of matching results
        """
        return ["Result 1", "Result 2"]
    
    def send_email(to: str, subject: str, body: str) -> bool:
        """Send an email.
        
        Args:
            to: Recipient email
            subject: Email subject
            body: Email body
            
        Returns:
            True if sent successfully
        """
        print(f"Sending email to {to}")
        return True
    
    # Create agent with tools
    agent = pattern.create_agent(
        name="office-assistant",
        system_prompt="""You are an office assistant that can:
        - Search the internal database
        - Send emails on behalf of users
        
        Always confirm before sending emails.""",
        tools=[search_database, send_email],
    )
    
    # Run
    result = await pattern.run("Search for project reports from last week")
    print(result.content)
    
    # Check cost
    print(f"Cost: ${result.total_cost:.6f}")

asyncio.run(main())
```

## Supervisor Pattern

A hierarchical pattern where a supervisor agent orchestrates worker agents.

### When to Use

- Complex workflows requiring multiple skills
- Tasks that benefit from division of labor
- When you need oversight and coordination
- Content creation pipelines

### Architecture

```
┌─────────────────────────────────────┐
│            User Input               │
└─────────────────────────────────────┘
                  │
                  ▼
┌─────────────────────────────────────┐
│           Supervisor                │
│  - Analyzes task                    │
│  - Delegates to workers             │
│  - Synthesizes results              │
└─────────────────────────────────────┘
         │              │
         ▼              ▼
┌─────────────┐  ┌─────────────┐
│  Worker 1   │  │  Worker 2   │
│ (Researcher)│  │  (Writer)   │
└─────────────┘  └─────────────┘
         │              │
         └──────┬───────┘
                ▼
┌─────────────────────────────────────┐
│         Final Response              │
└─────────────────────────────────────┘
```

### Example

```python
from multi_agent_base import SystemConfig, SupervisorPattern

async def main():
    config = SystemConfig.from_env()
    pattern = SupervisorPattern(config)
    
    # Create a team with supervisor and workers
    pattern.create_team(
        supervisor_name="content-manager",
        supervisor_prompt="""You manage a content creation team.
        
        Your workers are:
        - researcher: Gathers information and facts
        - writer: Creates engaging content
        - editor: Reviews and improves content
        
        For each content request:
        1. Have researcher gather relevant information
        2. Have writer create initial draft
        3. Have editor polish the final version
        
        Coordinate their work and provide the final result.""",
        worker_configs=[
            {
                "name": "researcher",
                "system_prompt": """You are a research specialist.
                When given a topic, gather key facts, statistics, and insights.
                Cite sources when possible.
                Format your findings in a clear, structured way.""",
            },
            {
                "name": "writer",
                "system_prompt": """You are a content writer.
                Create engaging, well-structured content based on provided research.
                Use clear language and compelling narratives.
                Adapt tone to the target audience.""",
            },
            {
                "name": "editor",
                "system_prompt": """You are a content editor.
                Review and improve written content for:
                - Grammar and clarity
                - Flow and structure
                - Engagement and impact
                Provide the polished final version.""",
            },
        ],
    )
    
    # Run the team
    result = await pattern.run(
        "Write a blog post about the future of AI agents in business",
        max_iterations=15,
    )
    
    print(result.content)
    print(f"\nTotal cost: ${result.total_cost:.6f}")
    print(f"Agents involved: {len(result.agent_responses)}")

asyncio.run(main())
```

### Delegation Protocol

The supervisor uses a specific protocol to delegate:

```
DELEGATE TO [worker_name]: [task description]
```

And provides final output with:

```
FINAL ANSWER: [response]
```

## Swarm Pattern

A dynamic pattern where agents can hand off conversations to each other.

### When to Use

- Customer service with multiple departments
- Complex routing requirements
- When expertise varies by topic
- Self-organizing agent systems

### Architecture

```
┌─────────────────────────────────────┐
│            User Input               │
└─────────────────────────────────────┘
                  │
                  ▼
┌───────────────────────────────────────────────────────┐
│                    Agent Swarm                         │
│                                                        │
│  ┌──────────┐      ┌──────────┐      ┌──────────┐    │
│  │  Sales   │ ←──→ │ Support  │ ←──→ │ Billing  │    │
│  │  Agent   │      │  Agent   │      │  Agent   │    │
│  └──────────┘      └──────────┘      └──────────┘    │
│       ↑                  ↑                  ↑         │
│       └──────────────────┴──────────────────┘         │
│                    Handoffs                            │
└───────────────────────────────────────────────────────┘
                  │
                  ▼
┌─────────────────────────────────────┐
│            Response                 │
└─────────────────────────────────────┘
```

### Example

```python
from multi_agent_base import SystemConfig, SwarmPattern

async def main():
    config = SystemConfig.from_env()
    pattern = SwarmPattern(config)
    
    # Create interconnected agents
    pattern.create_agent(
        name="triage",
        system_prompt="""You are the initial contact for customer inquiries.
        Analyze the customer's need and route to the appropriate department:
        - sales: For purchasing, pricing, product questions
        - support: For technical issues, how-to questions
        - billing: For invoices, payments, refunds
        
        Handoff immediately to the right department.""",
        can_handoff_to=["sales", "support", "billing"],
        is_start_agent=True,
    )
    
    pattern.create_agent(
        name="sales",
        system_prompt="""You are a sales specialist.
        Help with:
        - Product information and recommendations
        - Pricing and quotes
        - Purchase assistance
        
        If the customer has a technical issue, handoff to support.
        If they have a billing question, handoff to billing.""",
        can_handoff_to=["support", "billing"],
    )
    
    pattern.create_agent(
        name="support",
        system_prompt="""You are a technical support specialist.
        Help with:
        - Troubleshooting issues
        - How-to guidance
        - Feature explanations
        
        If the customer wants to buy something, handoff to sales.
        If they have a billing issue, handoff to billing.""",
        can_handoff_to=["sales", "billing"],
    )
    
    pattern.create_agent(
        name="billing",
        system_prompt="""You are a billing specialist.
        Help with:
        - Invoice questions
        - Payment processing
        - Refund requests
        - Account status
        
        If the customer has a technical issue, handoff to support.
        If they want to make a purchase, handoff to sales.""",
        can_handoff_to=["sales", "support"],
    )
    
    # Run - will start at triage and route as needed
    result = await pattern.run(
        "I'm having trouble logging into my account",
        max_handoffs=5,
    )
    
    print(result.content)
    print(f"\nHandoffs: {result.metadata.get('handoff_count', 0)}")
    print(f"Final agent: {result.metadata.get('final_agent', 'unknown')}")

asyncio.run(main())
```

### Handoff Protocol

Agents use this protocol to hand off:

```
HANDOFF TO [agent_name]: [context/reason]
```

## Pattern Selection Guide

```
                    ┌─────────────────────┐
                    │  What's your need?  │
                    └─────────────────────┘
                              │
              ┌───────────────┼───────────────┐
              ▼               ▼               ▼
     ┌────────────────┐ ┌───────────┐ ┌────────────────┐
     │ Simple, single │ │ Complex,  │ │ Dynamic routing│
     │ purpose task   │ │ workflow  │ │ based on input │
     └────────────────┘ └───────────┘ └────────────────┘
              │               │               │
              ▼               ▼               ▼
     ┌────────────────┐ ┌───────────┐ ┌────────────────┐
     │  SingleAgent   │ │Supervisor │ │     Swarm      │
     └────────────────┘ └───────────┘ └────────────────┘
```

## Factory Function

Use the factory function for dynamic pattern creation:

```python
from multi_agent_base.core.patterns import create_pattern
from multi_agent_base import SystemConfig, PatternType

config = SystemConfig(pattern=PatternType.SUPERVISOR)
pattern = create_pattern(config)
```

---

## Pipeline Pattern

Sequential processing through a chain of specialized agents.

### When to Use

- Content transformation pipelines
- Multi-stage data processing
- Sequential refinement tasks
- ETL-like workflows

### Architecture

```
┌──────────┐    ┌──────────┐    ┌──────────┐    ┌──────────┐
│  Input   │ →  │ Stage 1  │ →  │ Stage 2  │ →  │ Stage 3  │ → Output
│          │    │(Research)│    │ (Write)  │    │ (Edit)   │
└──────────┘    └──────────┘    └──────────┘    └──────────┘
```

### Example

```python
from multi_agent_base import SystemConfig
from multi_agent_base.core.patterns import PipelinePattern

async def main():
    config = SystemConfig.from_env()
    pattern = PipelinePattern(config)
    
    # Add stages in order
    pattern.add_stage(
        "research",
        "Research the given topic thoroughly and provide key facts."
    )
    
    pattern.add_stage(
        "outline", 
        "Create a structured outline based on the research provided."
    )
    
    pattern.add_stage(
        "write",
        "Write engaging content following the outline."
    )
    
    pattern.add_stage(
        "edit",
        "Polish and improve the content for final publication."
    )
    
    # Optional: Transform between stages
    pattern.add_transform("research", lambda r: f"Research findings:\n{r}")
    
    # Run pipeline
    result = await pattern.run("AI trends in 2024")
    
    print(f"Final output: {result.content}")
    print(f"Stages executed: {result.metadata['stages_completed']}")
    
asyncio.run(main())
```

### Dynamic Stage Management

```python
# Insert stage at specific position
pattern.insert_stage(2, "fact-check", "Verify all facts and claims.")

# Remove a stage
pattern.remove_stage("fact-check")

# Get current stage order
stages = pattern.get_stages()  # ["research", "outline", "write", "edit"]
```

---

## Parallel Pattern

Execute multiple agents concurrently with optional result aggregation.

### When to Use

- Gathering diverse perspectives
- Parallel analysis tasks
- MapReduce-style processing
- Performance-critical workflows

### Architecture

```
                    ┌──────────┐
                    │  Input   │
                    └──────────┘
                         │
         ┌───────────────┼───────────────┐
         ▼               ▼               ▼
    ┌──────────┐   ┌──────────┐   ┌──────────┐
    │ Worker 1 │   │ Worker 2 │   │ Worker 3 │
    │(Analysis)│   │(Research)│   │(Creative)│
    └──────────┘   └──────────┘   └──────────┘
         │               │               │
         └───────────────┼───────────────┘
                         ▼
                  ┌──────────┐
                  │Aggregator│ (optional)
                  └──────────┘
                         │
                         ▼
                    ┌──────────┐
                    │  Output  │
                    └──────────┘
```

### Example

```python
from multi_agent_base import SystemConfig
from multi_agent_base.core.patterns import ParallelPattern

async def main():
    config = SystemConfig.from_env()
    pattern = ParallelPattern(config)
    
    # Create parallel workers
    pattern.create_agent(
        "technical",
        "Analyze from a technical perspective. Focus on feasibility."
    )
    
    pattern.create_agent(
        "business",
        "Analyze from a business perspective. Focus on ROI."
    )
    
    pattern.create_agent(
        "user",
        "Analyze from a user perspective. Focus on experience."
    )
    
    # Optional: Set aggregator
    pattern.set_aggregator(
        "synthesizer",
        """Synthesize the different perspectives into a cohesive analysis.
        Highlight agreements and conflicts between viewpoints."""
    )
    
    # Run all workers in parallel
    result = await pattern.run("Should we migrate to microservices?")
    
    print(f"Aggregated result: {result.content}")
    print(f"Worker results: {result.metadata['worker_results']}")
    
asyncio.run(main())
```

### Without Aggregator

```python
# Get raw results from all workers
result = await pattern.run("Analyze this topic", aggregate=False)

# Access individual responses
for name, response in result.agent_responses.items():
    print(f"{name}: {response.content}")
```

---

## Router Pattern

Route messages to specialized agents based on content analysis.

### When to Use

- Customer service triage
- Multi-domain assistants
- Intent-based routing
- Specialized expertise handling

### Architecture

```
┌──────────────────────────────────────────────────┐
│                     Router                        │
│  ┌────────────────────────────────────────────┐  │
│  │          Intent Classification             │  │
│  │  [sales] [support] [billing] [general]     │  │
│  └────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────┘
         │           │           │           │
         ▼           ▼           ▼           ▼
    ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌─────────┐
    │  Sales  │ │ Support │ │ Billing │ │ General │
    │  Agent  │ │  Agent  │ │  Agent  │ │  Agent  │
    └─────────┘ └─────────┘ └─────────┘ └─────────┘
```

### Example

```python
from multi_agent_base import SystemConfig
from multi_agent_base.core.patterns import RouterPattern

async def main():
    config = SystemConfig.from_env()
    pattern = RouterPattern(config)
    
    # Add routes with keywords
    pattern.add_route(
        "sales",
        "You are a sales specialist. Help with pricing and purchases.",
        keywords=["buy", "price", "cost", "purchase", "quote"]
    )
    
    pattern.add_route(
        "support",
        "You are a technical support agent. Solve technical issues.",
        keywords=["error", "bug", "crash", "help", "problem", "issue"]
    )
    
    pattern.add_route(
        "billing",
        "You are a billing specialist. Handle payment and invoice questions.",
        keywords=["invoice", "payment", "refund", "charge", "subscription"]
    )
    
    # Set default fallback
    pattern.add_route(
        "general",
        "You are a helpful assistant for general inquiries."
    )
    pattern.set_default_route("general")
    
    # Route automatically based on content
    result = await pattern.run("I'm getting an error when logging in")
    
    print(f"Response: {result.content}")
    print(f"Routed to: {result.metadata['routed_to']}")  # "support"
    
asyncio.run(main())
```

### Manual Route Selection

```python
# Check which route would be selected
route = pattern.route("I want to buy a subscription")
print(route)  # "sales"

# Force specific route
result = await pattern.run("General question", force_route="support")
```

---

## Reflection Pattern

Self-improvement through actor-critic loop with iterative refinement.

### When to Use

- High-quality content generation
- Code review and improvement
- Self-correcting outputs
- Quality assurance workflows

### Architecture

```
┌──────────────────────────────────────────────────┐
│                 Reflection Loop                   │
│                                                   │
│  ┌─────────┐        ┌─────────┐                  │
│  │  Actor  │ ─────→ │  Critic │                  │
│  │(Create) │        │(Review) │                  │
│  └─────────┘        └─────────┘                  │
│       ▲                  │                        │
│       │    feedback      │                        │
│       └──────────────────┘                        │
│                                                   │
│           Repeat until APPROVED                   │
└──────────────────────────────────────────────────┘
```

### Example

```python
from multi_agent_base import SystemConfig
from multi_agent_base.core.patterns import ReflectionPattern

async def main():
    config = SystemConfig.from_env()
    pattern = ReflectionPattern(config, max_refinements=3)
    
    # Set up actor (creator)
    pattern.set_actor(
        "writer",
        """You are a professional writer. 
        Create content based on the request.
        If you receive feedback, improve your work accordingly."""
    )
    
    # Set up critic (reviewer)
    pattern.set_critic(
        "editor",
        """You are a strict editor. Review the content for:
        - Clarity and coherence
        - Grammar and style
        - Engagement and impact
        
        If improvements are needed, provide specific feedback.
        If the content meets standards, respond with 'APPROVED'."""
    )
    
    # Run reflection loop
    result = await pattern.run("Write a compelling product description for AI software")
    
    print(f"Final content: {result.content}")
    print(f"Refinement rounds: {result.metadata['refinements']}")
    
asyncio.run(main())
```

### Custom Approval Logic

```python
# Custom approval checker
pattern.set_approval_check(
    lambda response: "APPROVED" in response.upper() or response.startswith("LGTM")
)
```

---

## Blackboard Pattern

Shared knowledge workspace for collaborative problem-solving.

### When to Use

- Complex multi-step reasoning
- Collaborative problem-solving
- Iterative knowledge building
- Expert system architectures

### Architecture

```
┌───────────────────────────────────────────────────────┐
│                     Blackboard                         │
│  ┌─────────────────────────────────────────────────┐  │
│  │  problem: "..."                                 │  │
│  │  hypothesis: "..."                              │  │
│  │  evidence: [...]                                │  │
│  │  conclusion: "..."                              │  │
│  └─────────────────────────────────────────────────┘  │
└───────────────────────────────────────────────────────┘
         ▲           ▲           ▲           ▲
         │           │           │           │
    ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌─────────┐
    │ Expert1 │ │ Expert2 │ │ Expert3 │ │ Expert4 │
    │(Domain) │ │(Analysis)│ │(Validate)│ │(Conclude)│
    └─────────┘ └─────────┘ └─────────┘ └─────────┘
```

### Example

```python
from multi_agent_base import SystemConfig
from multi_agent_base.core.patterns import BlackboardPattern

async def main():
    config = SystemConfig.from_env()
    pattern = BlackboardPattern(config)
    
    # Add knowledge sources (experts)
    pattern.add_expert(
        "domain",
        """Read the blackboard and add relevant domain knowledge.
        Write your findings to the blackboard under 'domain_knowledge'."""
    )
    
    pattern.add_expert(
        "analyst",
        """Read the blackboard including domain knowledge.
        Analyze the problem and write hypotheses to 'hypotheses'."""
    )
    
    pattern.add_expert(
        "validator",
        """Review hypotheses on the blackboard.
        Validate or refute each, writing to 'validation'."""
    )
    
    pattern.add_expert(
        "synthesizer",
        """Synthesize all information on the blackboard.
        Write the final conclusion to 'conclusion'."""
    )
    
    # Initial problem statement
    pattern.write("problem", "Why are sales declining in Q4?")
    
    # Run iteratively
    result = await pattern.run(max_iterations=4)
    
    # Read final state
    conclusion = pattern.read("conclusion")
    print(f"Conclusion: {conclusion}")
    print(f"Blackboard state: {pattern.read_all()}")
    
asyncio.run(main())
```

### Blackboard Operations

```python
# Write to blackboard
pattern.write("key", "value", author="agent_name")

# Read from blackboard
value = pattern.read("key")

# Get all data
all_data = pattern.read_all()

# Get modification history
history = pattern.get_history()

# Clear blackboard
pattern.clear()
```

### Pluggable Backend

```python
# Memory backend (default)
pattern = BlackboardPattern(config, backend="memory")

# Redis backend
pattern = BlackboardPattern(config, backend="redis", backend_config={
    "host": "localhost",
    "port": 6379
})

# Custom backend
class MyBackend:
    def read(self, key): ...
    def write(self, key, value): ...
    def read_all(self): ...
    def clear(self): ...

pattern = BlackboardPattern(config, backend=my_backend_instance)
```

---

## Composite Pattern

Combine multiple patterns for complex workflows.

### When to Use

- Complex multi-stage workflows
- Combining different strategies
- Building reusable pattern components
- Enterprise-grade agent systems

### Architecture

```
┌───────────────────────────────────────────────────────┐
│                  Composite Pattern                     │
│                                                        │
│  ┌─────────────┐     ┌─────────────┐                  │
│  │  Pipeline   │ ──→ │  Parallel   │                  │
│  │  Pattern    │     │  Pattern    │                  │
│  └─────────────┘     └─────────────┘                  │
│                            │                           │
│                            ▼                           │
│                     ┌─────────────┐                   │
│                     │ Reflection  │                   │
│                     │  Pattern    │                   │
│                     └─────────────┘                   │
│                            │                           │
│                            ▼                           │
│                       Output                           │
└───────────────────────────────────────────────────────┘
```

### Example

```python
from multi_agent_base import SystemConfig
from multi_agent_base.core.patterns import (
    CompositePattern,
    PipelinePattern,
    ParallelPattern,
    ReflectionPattern
)

async def main():
    config = SystemConfig.from_env()
    
    # Create sub-patterns
    research = ParallelPattern(config)
    research.create_agent("market", "Research market trends")
    research.create_agent("competitor", "Research competitors")
    research.set_aggregator("merge", "Merge research findings")
    
    writing = PipelinePattern(config)
    writing.add_stage("outline", "Create content outline")
    writing.add_stage("draft", "Write first draft")
    
    review = ReflectionPattern(config)
    review.set_actor("polish", "Polish the content")
    review.set_critic("qa", "Review for quality")
    
    # Compose patterns
    composite = CompositePattern(config)
    composite.add_pattern("research", research)
    composite.add_pattern("writing", writing)
    composite.add_pattern("review", review)
    
    # Set execution flow (sequential)
    composite.set_flow(["research", "writing", "review"])
    
    # Run composite workflow
    result = await composite.run("Create a market analysis report")
    
    print(f"Final output: {result.content}")
    print(f"Patterns executed: {result.metadata['patterns_executed']}")
    
asyncio.run(main())
```

### Parallel Composite Execution

```python
# Run patterns in parallel instead of sequential
result = await composite.run_parallel("Input message")
```

### Conditional Flow

```python
# Add condition for pattern execution
composite.add_condition(
    "review",
    lambda prev_result: len(prev_result.content) > 500
)

# Now 'review' only runs if content > 500 chars
```

---

## Pattern Comparison

| Feature | Pipeline | Parallel | Router | Reflection | Blackboard | Composite |
|---------|----------|----------|--------|------------|------------|-----------|
| Execution | Sequential | Concurrent | Single | Iterative | Iterative | Mixed |
| Data Flow | Linear | Fan-out | Routed | Looped | Shared | Complex |
| Agent Count | 2-10 | 2-20 | 2-10 | 2 | 2-10 | Unlimited |
| Use Case | ETL | Analysis | Triage | QA | Knowledge | Complex |

## Pattern Selection Flowchart

```
                    ┌─────────────────────────────┐
                    │   What's your requirement?  │
                    └─────────────────────────────┘
                                  │
    ┌────────────┬───────────────┼───────────────┬────────────┐
    ▼            ▼               ▼               ▼            ▼
┌────────┐  ┌────────┐     ┌────────┐      ┌────────┐   ┌────────┐
│Multiple│  │Message │     │Quality │      │Shared  │   │Complex │
│parallel│  │routing?│     │control?│      │state?  │   │combo?  │
│tasks?  │  └────────┘     └────────┘      └────────┘   └────────┘
└────────┘       │              │               │            │
    │            ▼              ▼               ▼            ▼
    ▼       ┌────────┐    ┌────────┐      ┌────────┐   ┌────────┐
┌────────┐  │ Router │    │Reflect │      │Blackbd │   │Composit│
│Parallel│  │Pattern │    │Pattern │      │Pattern │   │Pattern │
│Pattern │  └────────┘    └────────┘      └────────┘   └────────┘
└────────┘
```
