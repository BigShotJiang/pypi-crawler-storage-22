# Provider Configuration

This guide covers setting up and configuring LLM providers for Multi-Agent Base.

## Supported Providers

| Provider | Models | Streaming | Tool Calling |
|----------|--------|-----------|--------------|
| Ollama | llama3.2, mistral, etc. | ✅ | ✅ (model dependent) |
| OpenAI | gpt-4o, gpt-4o-mini, etc. | ✅ | ✅ |
| Anthropic | claude-3.5-sonnet, etc. | ✅ | ✅ |

## Configuration

### Environment Variables

```bash
# Ollama (default: local)
OLLAMA_BASE_URL=http://localhost:11434

# OpenAI
OPENAI_API_KEY=sk-...

# Anthropic
ANTHROPIC_API_KEY=sk-ant-...
```

### Using SystemConfig

```python
from multi_agent_base import SystemConfig, ProviderType

# Load from environment
config = SystemConfig.from_env()

# Or configure explicitly
config = SystemConfig(
    provider=ProviderType.OPENAI,
    model="gpt-4o-mini",
    api_key="sk-...",
    temperature=0.7,
    max_tokens=4096,
)
```

## Provider-Specific Setup

### Ollama

Ollama runs locally and requires no API key.

```bash
# Install Ollama
brew install ollama  # macOS
# or
curl -fsSL https://ollama.com/install.sh | sh  # Linux

# Start Ollama
ollama serve

# Pull a model
ollama pull llama3.2
```

```python
from multi_agent_base import SystemConfig, ProviderType

config = SystemConfig(
    provider=ProviderType.OLLAMA,
    model="llama3.2",
    base_url="http://localhost:11434",  # optional
)
```

**Tool Calling Support:**
- llama3.2 and newer: Full support
- mistral: Limited support
- codellama: No tool support

### OpenAI

```python
from multi_agent_base import SystemConfig, ProviderType

config = SystemConfig(
    provider=ProviderType.OPENAI,
    model="gpt-4o-mini",  # or gpt-4o, gpt-3.5-turbo
    api_key="sk-...",  # or set OPENAI_API_KEY env var
    
    # Optional parameters
    temperature=0.7,
    max_tokens=4096,
    top_p=1.0,
)
```

**Available Models:**
| Model | Context | Best For |
|-------|---------|----------|
| gpt-4o | 128K | Complex reasoning |
| gpt-4o-mini | 128K | Cost-effective general use |
| gpt-4-turbo | 128K | Latest features |
| gpt-3.5-turbo | 16K | Fast, cheap |

### Anthropic

```python
from multi_agent_base import SystemConfig, ProviderType

config = SystemConfig(
    provider=ProviderType.ANTHROPIC,
    model="claude-3-5-sonnet-20241022",
    api_key="sk-ant-...",  # or set ANTHROPIC_API_KEY
    
    # Optional
    max_tokens=4096,
)
```

**Available Models:**
| Model | Context | Best For |
|-------|---------|----------|
| claude-3-5-sonnet | 200K | Best overall |
| claude-3-opus | 200K | Complex reasoning |
| claude-3-haiku | 200K | Fast, cheap |

## Using Model Client Directly

For advanced use cases, access the model client directly:

```python
from multi_agent_base.providers.factory import ModelClientFactory

# Create client
client = ModelClientFactory.create(
    provider="openai",
    model="gpt-4o-mini",
    api_key="sk-...",
)

# Generate response
content, usage, tool_calls = await client.generate(
    messages=[
        {"role": "system", "content": "You are helpful."},
        {"role": "user", "content": "Hello!"},
    ],
    tools=[{
        "type": "function",
        "function": {
            "name": "get_weather",
            "description": "Get current weather",
            "parameters": {
                "type": "object",
                "properties": {
                    "location": {"type": "string"}
                },
            },
        },
    }],
)

# Streaming
async for chunk in client.stream(messages):
    print(chunk, end="", flush=True)
```

## Rate Limits

Built-in rate limits by provider:

```python
from multi_agent_base.ratelimit import get_provider_limits

limits = get_provider_limits("openai")
print(f"RPM: {limits.requests_per_minute}")
print(f"TPM: {limits.tokens_per_minute}")
```

| Provider | Default RPM | Default TPM |
|----------|-------------|-------------|
| Ollama | No limit | No limit |
| OpenAI | 500 | 30,000 |
| Anthropic | 50 | 40,000 |

## Cost Tracking

Automatic cost tracking for API usage:

```python
from multi_agent_base.cost import CostTracker

tracker = CostTracker()

# Automatic tracking with agent
agent = pattern.create_agent(
    name="assistant",
    cost_tracker=tracker,
)

# Get usage report
report = tracker.get_summary()
print(f"Total cost: ${report['total_cost']:.4f}")
```

## Custom Providers

To add a custom provider:

```python
from multi_agent_base.providers.factory import BaseModelClient

class MyCustomClient(BaseModelClient):
    async def generate(self, messages, tools=None, **kwargs):
        # Your implementation
        response = await my_api_call(messages)
        return response.content, response.usage, []
    
    async def stream(self, messages, tools=None, **kwargs):
        async for chunk in my_streaming_api(messages):
            yield chunk.content

# Register with factory
from multi_agent_base.providers.factory import ModelClientFactory
ModelClientFactory.register("custom", MyCustomClient)

# Use it
config = SystemConfig(
    provider="custom",
    model="my-model",
)
```

## Troubleshooting

### Common Issues

**"Ollama package not installed"**
```bash
pip install multi-agent-base[ollama]
```

**"OpenAI package not installed"**
```bash
pip install multi-agent-base[openai]
```

**"Invalid API key"**
- Check environment variable is set
- Verify key hasn't expired
- Ensure correct provider prefix (sk- for OpenAI, sk-ant- for Anthropic)

**Rate limit errors**
```python
from multi_agent_base.ratelimit import TokenBucketLimiter, RateLimitConfig

limiter = TokenBucketLimiter(RateLimitConfig(
    requests_per_minute=50,
    tokens_per_minute=10000,
))

# Wrap your calls
if await limiter.can_acquire():
    await limiter.acquire(tokens=100)
    response = await agent.run(message)
```

## Future Providers

The following providers are planned for future releases:

- Azure OpenAI
- Google Vertex AI (Gemini)
- AWS Bedrock
- Groq
- Together AI

See [roadmap.md](roadmap.md) for timeline.
