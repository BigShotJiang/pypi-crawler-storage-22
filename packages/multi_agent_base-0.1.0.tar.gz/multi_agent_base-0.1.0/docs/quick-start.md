# Hızlı Başlangıç

Bu rehber, 5 dakika içinde Agent Framework ile çalışan ilk agent'ınızı oluşturmanızı sağlar.

---

## Ön Gereksinimler

- Python 3.10+
- Ollama (lokal LLM için)

---

## Adım 1: Kurulum

```bash
# Sanal ortam oluştur
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate

# Agent Framework paketleri
pip install agent-framework --pre
pip install agent-framework-devui --pre
pip install agent-framework-ollama --pre
```

---

## Adım 2: Ollama Kurulumu

```bash
# macOS
brew install ollama

# Veya https://ollama.ai adresinden indir

# Model indir
ollama pull qwen2.5-coder:7b
```

---

## Adım 3: İlk Agent

`my_first_agent.py` dosyası oluşturun:

```python
#!/usr/bin/env python3
"""İlk Agent Framework Agent'ınız"""

from datetime import datetime
from agent_framework import ChatAgent, tool
from agent_framework.ollama import OllamaChatClient
from agent_framework.devui import serve


# Tool tanımla
@tool
def get_current_time() -> str:
    """Şu anki tarih ve saati döndür."""
    return f"Şu an: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"


@tool
def calculate(expression: str) -> str:
    """Matematiksel ifadeyi hesapla.
    
    Args:
        expression: Hesaplanacak ifade (örn: "2 + 2")
    """
    try:
        result = eval(expression)
        return f"{expression} = {result}"
    except Exception as e:
        return f"Hata: {e}"


def main():
    # Ollama client oluştur
    client = OllamaChatClient(
        host="http://localhost:11434",
        model_id="qwen2.5-coder:7b",
    )
    
    # Agent oluştur
    agent = ChatAgent(
        chat_client=client,
        name="İlkAgent",
        description="Basit bir yardımcı asistan",
        instructions="""Sen yardımcı bir asistansın.
        
Kullanıcıya yardımcı olmak için tool'ları kullanabilirsin:
- get_current_time: Şu anki zamanı öğrenmek için
- calculate: Matematiksel hesaplamalar için

Türkçe yanıt ver.""",
        tools=[get_current_time, calculate],
    )
    
    print("🚀 Agent hazır!")
    print("📍 Tarayıcıda aç: http://localhost:8080")
    print("⏹️  Durdurmak için: Ctrl+C")
    
    # DevUI başlat
    serve(
        entities=[agent],
        port=8080,
        auto_open=True,
    )


if __name__ == "__main__":
    main()
```

---

## Adım 4: Çalıştır

```bash
python my_first_agent.py
```

Tarayıcınız otomatik olarak açılacak. Açılmazsa: http://localhost:8080

---

## Adım 5: Test Et

DevUI'da şu mesajları deneyin:

| Mesaj | Beklenen Davranış |
|-------|-------------------|
| "Saat kaç?" | `get_current_time` tool'u çağrılır |
| "25 * 4 hesapla" | `calculate` tool'u çağrılır |
| "Merhaba!" | Normal sohbet yanıtı |

---

## 🎉 Tebrikler!

İlk Agent Framework agent'ınızı oluşturdunuz!

---

## Sonraki Adımlar

### Workflow Oluştur

```bash
./scripts/run_devui_workflow.sh
```

5 adımlı email işleme workflow'unu göreceksiniz.

### Observability Ekle

```bash
./scripts/run_aspire_dashboard.sh
./scripts/run_devui_agent.sh
```

Aspire Dashboard'da trace'leri görün.

### Daha Fazla Tool Ekle

```python
@tool
def search_web(query: str) -> str:
    """Web'de arama yap."""
    # Gerçek implementasyon
    return f"'{query}' için sonuçlar..."

@tool
def send_email(to: str, subject: str, body: str) -> str:
    """Email gönder."""
    # Gerçek implementasyon
    return f"Email {to} adresine gönderildi."
```

---

## Örnek Projeler

| Örnek | Dosya | Açıklama |
|-------|-------|----------|
| Agent + DevUI | `examples/devui_ollama_agent.py` | Tool'lu agent |
| Workflow Viz | `examples/workflow_devui_demo.py` | 5 adımlı workflow |
| Graph Export | `examples/multi_agent_workflow_viz.py` | SVG export |

---

## Sorun mu Var?

[Troubleshooting](./troubleshooting.md) sayfasına bakın.

---

*[← Genel Bakış](./overview.md) | [Kurulum →](./installation.md)*
