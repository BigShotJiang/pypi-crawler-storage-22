# Rate Limiting Module

The Rate Limiting module helps manage API rate limits and prevent throttling. It supports multiple algorithms and provider-specific configurations.

## Rate Limiters

### TokenBucketLimiter

Classic token bucket algorithm allowing controlled bursting:

```python
from multi_agent_base.ratelimit import TokenBucketLimiter, RateLimitConfig

limiter = TokenBucketLimiter(RateLimitConfig(
    requests_per_minute=60,
    burst_multiplier=1.5,  # Allow 50% burst
    wait_on_limit=True,
))

# Acquire before making request
await limiter.acquire()
response = await api.call()
```

### SlidingWindowLimiter

Tracks requests in a sliding time window:

```python
from multi_agent_base.ratelimit import SlidingWindowLimiter, RateLimitConfig

limiter = SlidingWindowLimiter(RateLimitConfig(
    requests_per_minute=100,
    window_size_seconds=60,
))

# Check remaining capacity
remaining = limiter.get_remaining()
print(f"Can make {remaining} more requests")
```

### CompositeRateLimiter

Combine multiple limiters for complex scenarios:

```python
from multi_agent_base.ratelimit import (
    CompositeRateLimiter,
    TokenBucketLimiter,
    SlidingWindowLimiter,
)

# Per-second and per-minute limits
composite = CompositeRateLimiter([
    TokenBucketLimiter(RateLimitConfig(requests_per_second=5)),
    SlidingWindowLimiter(RateLimitConfig(requests_per_minute=100)),
])

# Respects both limits
await composite.acquire()
```

## Configuration

```python
from multi_agent_base.ratelimit import RateLimitConfig

config = RateLimitConfig(
    requests_per_minute=60,        # Base rate
    requests_per_second=None,      # Override per-second rate
    tokens_per_minute=100000,      # For token-based limits
    burst_multiplier=1.5,          # Burst capacity
    wait_on_limit=True,            # Wait vs raise exception
    max_wait_seconds=60.0,         # Maximum wait time
)
```

## Provider-Specific Limits

Use pre-configured limits for common providers:

```python
from multi_agent_base.ratelimit import ProviderRateLimits

# Get default limits for a provider
openai_limits = ProviderRateLimits.get("openai")
print(f"OpenAI: {openai_limits.requests_per_minute} RPM")

anthropic_limits = ProviderRateLimits.get("anthropic")
print(f"Anthropic: {anthropic_limits.requests_per_minute} RPM")

# Register custom provider limits
ProviderRateLimits.register("my_api", RateLimitConfig(
    requests_per_minute=1000,
    tokens_per_minute=500000,
))
```

### Built-in Provider Limits

| Provider | RPM | TPM |
|----------|-----|-----|
| OpenAI (free) | 60 | 150,000 |
| OpenAI (tier 1) | 500 | 200,000 |
| Anthropic | 60 | 100,000 |
| Ollama | Unlimited | Unlimited |

## Decorators

### @rate_limit

Add rate limiting to any async function:

```python
from multi_agent_base.ratelimit import rate_limit

@rate_limit(requests_per_minute=60)
async def call_api():
    return await api.request()

# Automatic rate limiting
for _ in range(100):
    await call_api()  # Will wait when limit reached
```

### @with_rate_limit

Share a limiter across multiple functions:

```python
from multi_agent_base.ratelimit import with_rate_limit, TokenBucketLimiter

# Shared limiter
api_limiter = TokenBucketLimiter(RateLimitConfig(
    requests_per_minute=100,
))

@with_rate_limit(api_limiter)
async def endpoint_a():
    pass

@with_rate_limit(api_limiter)
async def endpoint_b():
    pass

# Both share the same rate limit
```

## Error Handling

```python
from multi_agent_base.ratelimit import RateLimitExceeded

try:
    await limiter.acquire()
except RateLimitExceeded as e:
    print(f"Rate limited! Retry after {e.retry_after:.2f}s")
    await asyncio.sleep(e.retry_after)
```

## Token-Based Limiting

For LLM APIs that limit by tokens:

```python
from multi_agent_base.ratelimit import TokenRateLimiter

limiter = TokenRateLimiter(
    tokens_per_minute=100000,
)

# Acquire tokens before request
estimated_tokens = len(prompt) // 4  # Rough estimate
await limiter.acquire(tokens=estimated_tokens)

# After response, update with actual usage
limiter.record_usage(response.usage.total_tokens)
```

## Integration with Agents

Rate limiting integrates with the provider layer:

```python
from multi_agent_base.core.agent import BaseAgent
from multi_agent_base.ratelimit import TokenBucketLimiter

# Create rate-limited agent
agent = BaseAgent(
    config=agent_config,
    rate_limiter=TokenBucketLimiter(RateLimitConfig(
        requests_per_minute=60,
    )),
)

# Requests automatically rate limited
response = agent.run("Hello!")
```

## Best Practices

1. **Know your limits**: Check your API tier and set limits accordingly

2. **Use burst wisely**: 
   - `burst_multiplier=1.0` for strict limiting
   - `burst_multiplier=2.0` for flexible bursting

3. **Wait vs Fail**:
   - `wait_on_limit=True` for background jobs
   - `wait_on_limit=False` for user-facing requests

4. **Combine with resilience**:
   - Use rate limiting with retry logic
   - Circuit breaker protects against rate limit storms

5. **Monitor usage**:
   - Track `get_remaining()` to predict limits
   - Log rate limit events for capacity planning

## Example: Multi-Provider Setup

```python
from multi_agent_base.ratelimit import (
    TokenBucketLimiter,
    ProviderRateLimits,
)

# Create limiters for each provider
limiters = {
    "openai": TokenBucketLimiter(ProviderRateLimits.get("openai")),
    "anthropic": TokenBucketLimiter(ProviderRateLimits.get("anthropic")),
}

async def smart_route(prompt: str):
    """Route to available provider."""
    for provider, limiter in limiters.items():
        if limiter.get_remaining() > 0:
            await limiter.acquire()
            return await call_provider(provider, prompt)
    
    # All rate limited, wait for the one with shortest wait
    shortest = min(limiters.items(), key=lambda x: x[1].get_retry_after())
    await asyncio.sleep(shortest[1].get_retry_after())
    await shortest[1].acquire()
    return await call_provider(shortest[0], prompt)
```
