# Resilience Module

The Resilience module provides fault-tolerance patterns to make your agents production-ready. It includes retry logic, circuit breakers, timeouts, and fallback chains.

## Core Concepts

### ResilienceConfig

Configure resilience behavior through `ResilienceConfig`:

```python
from multi_agent_base.core.config import ResilienceConfig

config = ResilienceConfig(
    # Retry settings
    retry_enabled=True,
    retry_attempts=3,
    retry_delay=1.0,
    retry_max_delay=60.0,
    retry_backoff_multiplier=2.0,
    
    # Circuit breaker
    circuit_breaker_enabled=True,
    circuit_failure_threshold=5,
    circuit_recovery_timeout=30.0,
    
    # Timeout
    timeout_enabled=True,
    timeout_seconds=120.0,
    
    # Fallback
    fallback_enabled=True,
)
```

## Retry Logic

### RetryExecutor

Execute operations with configurable retry logic:

```python
from multi_agent_base.resilience import RetryExecutor, RetryStrategy

executor = RetryExecutor(
    max_attempts=3,
    base_delay=1.0,
    strategy=RetryStrategy.EXPONENTIAL,
    retryable_exceptions=[ConnectionError, TimeoutError],
)

@executor.retry
async def call_api():
    return await api.request()
```

### Backoff Strategies

- **FIXED**: Constant delay between retries
- **EXPONENTIAL**: Delay doubles each retry (1s, 2s, 4s, 8s...)
- **LINEAR**: Delay increases linearly (1s, 2s, 3s, 4s...)
- **JITTERED**: Exponential with random jitter to prevent thundering herd

```python
from multi_agent_base.resilience import retry_with_backoff

@retry_with_backoff(
    max_attempts=5,
    base_delay=0.5,
    strategy="exponential_jitter",
)
async def flaky_operation():
    pass
```

## Circuit Breaker

Prevent cascading failures with the circuit breaker pattern:

```python
from multi_agent_base.resilience import CircuitBreaker, CircuitState

breaker = CircuitBreaker(
    failure_threshold=5,      # Open after 5 failures
    recovery_timeout=30.0,    # Try again after 30s
    half_open_max_calls=3,    # Test with 3 calls
)

async def call_service():
    async with breaker:
        return await service.request()

# Check circuit state
if breaker.state == CircuitState.OPEN:
    print("Circuit is open - service unavailable")
```

### Circuit States

1. **CLOSED**: Normal operation, requests flow through
2. **OPEN**: Too many failures, requests immediately rejected
3. **HALF_OPEN**: Testing if service recovered

## Timeouts

Prevent hanging requests with configurable timeouts:

```python
from multi_agent_base.resilience import with_timeout, TimeoutContext

# Decorator
@with_timeout(seconds=30.0)
async def slow_operation():
    pass

# Context manager
async with TimeoutContext(seconds=30.0) as ctx:
    result = await long_running_task()
    
    if ctx.timed_out:
        print("Operation timed out")
```

## Fallback Chain

Define fallback strategies when primary options fail:

```python
from multi_agent_base.resilience import FallbackChain

chain = FallbackChain([
    lambda: call_primary_model(),      # Try first
    lambda: call_secondary_model(),    # Fallback 1
    lambda: call_cached_response(),    # Fallback 2
    lambda: return_default_response(), # Last resort
])

result = await chain.execute()
```

### With Fallback Decorator

```python
from multi_agent_base.resilience import with_fallback

async def fallback_handler(error):
    return "Default response due to error"

@with_fallback(fallback_handler)
async def risky_operation():
    return await external_api.call()
```

## Resilient Model Client

Wrap any model client with resilience:

```python
from multi_agent_base.providers.factory import ModelClientFactory

factory = ModelClientFactory()

# Create a resilient client
client = factory.create_resilient(
    provider_config,
    resilience_config=ResilienceConfig(
        retry_attempts=3,
        circuit_breaker_enabled=True,
        timeout_seconds=60.0,
    ),
)

# Use normally - resilience is automatic
response = await client.complete([...])
```

## Combining Patterns

Use multiple patterns together for robust operation:

```python
from multi_agent_base.resilience import (
    ResiliencePolicy,
    RetryExecutor,
    CircuitBreaker,
    FallbackChain,
)

# Create a comprehensive policy
policy = ResiliencePolicy(
    retry=RetryExecutor(max_attempts=3),
    circuit_breaker=CircuitBreaker(failure_threshold=5),
    timeout_seconds=30.0,
    fallback=FallbackChain([...]),
)

# Apply to operation
result = await policy.execute(risky_operation)
```

## Best Practices

1. **Start with defaults**: The default `ResilienceConfig` works well for most cases

2. **Tune for your use case**:
   - High-throughput: Lower retry delays, fewer attempts
   - Critical operations: More retries, longer timeouts
   - External APIs: Enable circuit breaker

3. **Use appropriate fallbacks**:
   - Cache fallback for read operations
   - Default values for non-critical data
   - Alternative providers for critical operations

4. **Monitor circuit state**:
   - Log when circuits open/close
   - Alert on high failure rates
   - Track recovery times

5. **Avoid retry storms**:
   - Use jittered backoff
   - Set reasonable max delays
   - Consider global rate limits

## Error Handling

```python
from multi_agent_base.resilience import (
    CircuitOpenError,
    RetryExhaustedError,
    TimeoutError,
)

try:
    result = await policy.execute(operation)
except CircuitOpenError:
    # Service is down, circuit is open
    handle_service_unavailable()
except RetryExhaustedError as e:
    # All retries failed
    log.error(f"Operation failed after {e.attempts} attempts")
except TimeoutError:
    # Operation took too long
    handle_timeout()
```
