# Roadmap & Future Features

This document outlines planned features and improvements for Multi-Agent Base.

## Current Status

### ✅ Completed Features

| Module | Feature | Status |
|--------|---------|--------|
| Core | Single Agent Pattern | ✅ Complete |
| Core | Supervisor Pattern | ✅ Complete |
| Core | Swarm Pattern | ✅ Complete |
| Core | Tool Execution Loop | ✅ Complete |
| Core | Streaming Support | ✅ Complete |
| Providers | Ollama | ✅ Complete |
| Providers | OpenAI | ✅ Complete |
| Providers | Anthropic | ✅ Complete |
| Memory | Buffer Memory | ✅ Complete |
| Memory | Sliding Window | ✅ Complete |
| Memory | Redis Backend | ✅ Complete |
| Memory | Vector Memory (Stub) | ✅ Complete |
| Resilience | Retry with Backoff | ✅ Complete |
| Resilience | Circuit Breaker | ✅ Complete |
| Resilience | Timeout Handling | ✅ Complete |
| Resilience | Fallback Chain | ✅ Complete |
| Rate Limiting | Token Bucket | ✅ Complete |
| Rate Limiting | Sliding Window | ✅ Complete |
| Rate Limiting | Redis Backend | ✅ Complete |
| Caching | LRU Cache | ✅ Complete |
| Caching | TTL Cache | ✅ Complete |
| Caching | Semantic Cache | ✅ Complete |
| Events | Event Bus | ✅ Complete |
| Events | Agent Hooks | ✅ Complete |
| Security | Input Validation | ✅ Complete |
| Security | Injection Detection | ✅ Complete |
| Security | Permission System | ✅ Complete |
| Security | Secret Management | ✅ Complete |
| Observability | Phoenix Integration | ✅ Complete |
| Observability | Structured Logging | ✅ Complete |
| Monitoring | Prometheus Metrics | ✅ Complete |
| Monitoring | Health Checks | ✅ Complete |
| A2A | Agent Cards | ✅ Complete |
| A2A | Skill Discovery | ✅ Complete |
| Cost | Usage Tracking | ✅ Complete |
| Cost | Pricing Calculator | ✅ Complete |

---

## 🚧 Planned Features

### Phase 1: Additional Providers (Q1 2026)

| Feature | Description | Priority |
|---------|-------------|----------|
| Azure OpenAI | Microsoft Azure-hosted OpenAI models | High |
| Google Vertex AI | Gemini models support | High |
| AWS Bedrock | Amazon Bedrock integration | Medium |
| Groq | Fast inference provider | Medium |
| Together AI | Open source model hosting | Low |

### Phase 2: Enterprise Features (Q2 2026)

| Feature | Description | Priority |
|---------|-------------|----------|
| OAuth2/OIDC | Enterprise SSO integration | High |
| Multi-tenancy | Tenant isolation and configuration | High |
| RBAC | Role-based access control | Medium |
| API Key Rotation | Zero-downtime key rotation | Medium |
| Audit Logging | Security audit trail | Medium |

### Phase 3: Advanced Agent Capabilities (Q2 2026)

| Feature | Description | Priority |
|---------|-------------|----------|
| Human-in-the-Loop | Approval workflows for critical actions | High |
| Checkpoint/Resume | State persistence for long tasks | High |
| Agent Versioning | Version management for prompts/configs | Medium |
| Long-Running Tasks | Background job queue | Medium |

### Phase 4: Data & Compliance (Q3 2026)

| Feature | Description | Priority |
|---------|-------------|----------|
| PII Detection | Automatic PII identification | High |
| PII Redaction | Mask sensitive data | High |
| GDPR Support | Right to erasure workflows | Medium |
| Data Retention | Compliance-grade retention policies | Medium |
| Conversation Export | Standardized backup format | Low |

### Phase 5: Integrations (Q3 2026)

| Feature | Description | Priority |
|---------|-------------|----------|
| ChromaDB | Full vector store integration | High |
| Pinecone | Cloud vector database | High |
| Qdrant | Open-source vector DB | Medium |
| OpenAI Embeddings | Production embeddings | High |
| Sentence Transformers | Local embeddings | Medium |
| LangSmith | Observability platform | Medium |
| Weights & Biases | Experiment tracking | Low |

### Phase 6: Distributed Systems (Q4 2026)

| Feature | Description | Priority |
|---------|-------------|----------|
| Message Queue | Kafka/RabbitMQ integration | High |
| Remote Agents | A2A network protocol | High |
| Agent Discovery | Registry for distributed lookup | Medium |
| Cross-Process Events | Distributed event bus | Medium |

### Phase 7: Testing & Quality (Ongoing)

| Feature | Description | Priority |
|---------|-------------|----------|
| Mock LLM Provider | Standardized testing mock | High |
| Evaluation Framework | Response quality evaluation | High |
| Regression Testing | Golden dataset comparison | Medium |
| Prompt Diff/History | Track prompt changes | Low |

---

## Feature Requests

To request a new feature:

1. Check if it's already planned above
2. Open a GitHub issue with `[Feature Request]` prefix
3. Describe the use case and expected behavior
4. We'll evaluate and add to the roadmap

---

## Contributing

We welcome contributions! Priority areas:

1. **Provider integrations** - Add new LLM providers
2. **Vector store backends** - Add database integrations
3. **Documentation** - Improve guides and examples
4. **Tests** - Increase coverage

See [CONTRIBUTING.md](../CONTRIBUTING.md) for guidelines.
