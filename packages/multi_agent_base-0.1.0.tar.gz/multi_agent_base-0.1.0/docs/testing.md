# Agent Testing Framework

A comprehensive testing framework for AI agents, providing mock implementations, fixtures, assertions, and scenario-based testing capabilities.

## Overview

The testing module provides:

- **Mock LLM**: Deterministic responses for reproducible tests
- **Mock Tools**: Configurable tool behavior simulation
- **Fixtures**: Pytest-compatible test helpers
- **Assertions**: Agent-specific assertion functions
- **Scenario Testing**: Multi-turn conversation testing
- **Test Suites**: Organized test collections

## Installation

The testing module is included in `multi_agent_base`:

```python
from multi_agent_base.testing import (
    MockLLM,
    MockTool,
    MockToolRegistry,
    MockResponse,
    MockLLMConfig,
    TestScenario,
    TestSuiteBuilder,
    ConversationFixture,
    assert_tool_called,
    assert_response_contains,
)
```

## Quick Start

### Basic Mock LLM

```python
import asyncio
from multi_agent_base.testing import MockLLM

async def test_basic():
    # Create mock with predefined responses
    mock = MockLLM(responses=["Hello!", "How can I help?"])
    
    # First call returns "Hello!"
    response1 = await mock.chat([{"role": "user", "content": "Hi"}])
    assert response1["choices"][0]["message"]["content"] == "Hello!"
    
    # Second call returns "How can I help?"
    response2 = await mock.chat([{"role": "user", "content": "What's up?"}])
    assert response2["choices"][0]["message"]["content"] == "How can I help?"

asyncio.run(test_basic())
```

### Mock with Configuration

```python
from multi_agent_base.testing import MockLLM, MockLLMConfig

# Create configuration
config = MockLLMConfig.from_strings(
    "Response 1",
    "Response 2", 
    "Response 3",
    cycle=True,  # Cycle through responses
)

mock = MockLLM(config=config)
```

## Core Components

### MockResponse

Create structured mock responses:

```python
from multi_agent_base.testing import MockResponse, MockToolCall

# Text response
text_response = MockResponse.text("Hello, world!")

# Response with tool calls
tool_response = MockResponse.with_tool_calls([
    MockToolCall(name="search", arguments={"query": "test"}),
    MockToolCall(name="calculate", arguments={"expression": "2+2"}),
])

# Response with delay (for timeout testing)
delayed = MockResponse(
    content="Delayed response",
    delay_ms=500,
)

# Error response
error = MockResponse.error("Rate limit exceeded", error_code="rate_limit")
```

### MockLLM

Full-featured mock LLM implementation:

```python
from multi_agent_base.testing import MockLLM, MockLLMConfig

# Basic usage
mock = MockLLM(responses=["Hello!", "Hi there!"])

# With cycling (loops through responses)
mock = MockLLM(responses=["A", "B", "C"], cycle_responses=True)

# With configuration
config = MockLLMConfig(
    responses=[MockResponse.text("Hello")],
    cycle_responses=True,
    simulate_latency=True,  # Respect delay_ms
    record_calls=True,      # Track all calls
)
mock = MockLLM(config=config)

# Check recorded calls
print(mock.call_count)
print(mock.recorded_calls)
print(mock.metrics)
```

#### Recording and Assertions

```python
mock = MockLLM(responses=["Response"])

# Make some calls
await mock.chat([{"role": "user", "content": "Hi"}])
await mock.chat([{"role": "user", "content": "Hello"}])

# Check call count
assert mock.call_count == 2

# Assert calls were made
mock.assert_called()
mock.assert_called_times(2)

# Access recorded calls
for call in mock.recorded_calls:
    print(f"Messages: {call.messages}")
    print(f"Response: {call.response}")
    print(f"Duration: {call.duration_ms}ms")
```

### MockTool

Create mock tools for testing:

```python
from multi_agent_base.testing import MockTool, MockToolRegistry

# Basic mock tool
search_tool = MockTool(name="search", return_value={"results": ["item1"]})
result = await search_tool.execute(query="test")

# Tool with side effects
counter = [0]
def increment_counter(**kwargs):
    counter[0] += 1
    return {"count": counter[0]}

counting_tool = MockTool(name="count", side_effect=increment_counter)

# Tool that fails after N calls
failing_tool = MockTool(name="api", return_value="ok", fail_after=3)
```

### MockToolRegistry

Manage multiple mock tools:

```python
registry = MockToolRegistry()

# Register tools
registry.register(MockTool(name="search", return_value=[]))
registry.register(MockTool(name="calculate", return_value=42))

# Execute tools
result = await registry.execute("search", query="test")
result = await registry.execute("calculate", x=1, y=2)

# Get tool by name
tool = registry.get("search")
```

## Test Fixtures

### TestContext

Lightweight context for isolated tests:

```python
from multi_agent_base.testing import TestContext

async with TestContext() as ctx:
    ctx.mock_llm.add_response("Hello!")
    ctx.mock_tools.register(MockTool(name="greet", return_value="Hi!"))
    
    response = await ctx.mock_llm.chat([{"role": "user", "content": "Hi"}])
    tool_result = await ctx.mock_tools.execute("greet")
```

### ConversationFixture

Test multi-turn conversations:

```python
from multi_agent_base.testing import MockLLM, ConversationFixture

mock = MockLLM(responses=["Hello!", "I can help with that.", "Goodbye!"])
fixture = ConversationFixture(mock)

async with fixture as conv:
    r1 = await conv.send("Hi")
    r2 = await conv.send("Can you help me?")
    r3 = await conv.send("Thanks, bye!")

assert fixture.turn_count == 3
assert fixture.last_response == "Goodbye!"
```

## Scenario-Based Testing

### TestScenario

Define test scenarios with expected behaviors:

```python
from multi_agent_base.testing import TestScenario, ConversationTurn

scenario = TestScenario(name="greeting_flow")

# Add conversation turns
scenario.add_turn(
    "Hello",
    expected_contains=["hi", "hello"],  # Response must contain these
)
scenario.add_turn(
    "What's 2+2?",
    expected_contains=["4"],
    expected_not_contains=["5", "6"],  # Must NOT contain these
)
scenario.add_turn(
    "Call the calculate tool",
    expected_tool_calls=["calculate"],  # Must call this tool
)
```

### ScenarioRunner

Execute test scenarios:

```python
from multi_agent_base.testing import MockLLM, ScenarioRunner, TestScenario

mock = MockLLM(responses=[
    "Hello! How can I help?",
    "2+2 equals 4",
])

scenario = (
    TestScenario(name="math_test")
    .add_turn("Hi", expected_contains=["hello"])
    .add_turn("What's 2+2?", expected_contains=["4"])
)

runner = ScenarioRunner(mock_llm=mock)
result = await runner.run(scenario)

assert result.passed
print(f"Duration: {result.duration_ms}ms")
```

### TestSuiteBuilder

Build organized test suites:

```python
from multi_agent_base.testing import (
    TestSuiteBuilder,
    TestScenario,
    MockLLMConfig,
)

suite = (
    TestSuiteBuilder("agent_tests")
    .with_mock_llm(config=MockLLMConfig.from_strings(
        "Hello! How can I help?",
        "2+2 equals 4.",
        "Goodbye!",
    ))
    .with_mock_tool("search", {"results": []})
    .with_setup(lambda: print("Setup"))
    .with_teardown(lambda: print("Cleanup"))
    .add_scenario(
        TestScenario(name="greeting")
        .add_turn("Hi", expected_contains=["hello"])
    )
    .add_scenario(
        TestScenario(name="math")
        .add_turn("What's 2+2?", expected_contains=["4"])
    )
    .add_scenario(
        TestScenario(name="farewell")
        .add_turn("Bye", expected_contains=["goodbye"])
    )
    .build()
)

# Run all scenarios
result = await suite.run()
print(f"Passed: {result.passed_tests}/{result.total_tests}")
print(f"Pass Rate: {result.pass_rate}%")
```

## Assertions

### Agent-Specific Assertions

```python
from multi_agent_base.testing import (
    MockLLM,
    assert_tool_called,
    assert_tool_not_called,
    assert_response_contains,
    assert_response_not_contains,
    assert_response_matches,
    assert_llm_called,
    assert_llm_not_called,
    assert_cost_under,
)

mock = MockLLM(responses=["Hello, world!"])
response = await mock.chat([{"role": "user", "content": "Hi"}])
message = response["choices"][0]["message"]

# Response content assertions
assert_response_contains(message, "hello")  # Case-insensitive
assert_response_not_contains(message, "error")
assert_response_matches(message, r"Hello,?\s+\w+!")

# LLM call assertions
assert_llm_called(mock)
assert_llm_called(mock, times=1)
```

### AgentAssertions Class

Fluent assertions for agents:

```python
from multi_agent_base.testing import MockLLM, MockTool, AgentAssertions

mock_llm = MockLLM(responses=["Response"])
mock_tool = MockTool(name="search", return_value=[])

assertions = AgentAssertions(mock_llm=mock_llm, mock_tools=[mock_tool])

# Chain assertions
assertions.assert_llm_called()
assertions.assert_tool_called("search")
assertions.assert_response_contains(response, "expected text")
```

## Decorators

### @with_mock_llm

```python
from multi_agent_base.testing import with_mock_llm, MockLLM

@with_mock_llm(responses=["Hello!", "Goodbye!"], cycle=True)
async def test_with_mock(mock_llm: MockLLM):
    response = await mock_llm.chat([{"role": "user", "content": "Hi"}])
    assert "Hello" in response["choices"][0]["message"]["content"]
```

### @with_mock_tools

```python
from multi_agent_base.testing import with_mock_tools, MockToolRegistry

@with_mock_tools(
    ("search", {"results": []}),
    ("calculate", 42),
)
async def test_with_tools(mock_tools: MockToolRegistry):
    result = await mock_tools.execute("calculate", x=1, y=2)
    assert result == 42
```

## Context Managers

### mock_llm_context

```python
from multi_agent_base.testing import mock_llm_context

async with mock_llm_context(["Response 1", "Response 2"]) as mock:
    response = await mock.chat([{"role": "user", "content": "Hi"}])
    # mock is automatically reset on exit
```

### mock_tool_context

```python
from multi_agent_base.testing import mock_tool_context

with mock_tool_context("search", return_value={"results": []}) as mock:
    result = await mock.execute(query="test")
    # mock is automatically reset on exit
```

## Pytest Integration

### Built-in Fixtures

```python
import pytest
from multi_agent_base.testing import mock_llm, mock_tools, test_context

@pytest.fixture
def mock_llm():
    return MockLLM(responses=["Test response"])

@pytest.fixture  
def mock_tools():
    registry = MockToolRegistry()
    registry.register(MockTool(name="test", return_value="ok"))
    return registry

# Use in tests
async def test_example(mock_llm, mock_tools):
    response = await mock_llm.chat([{"role": "user", "content": "Hi"}])
    assert mock_llm.call_count == 1
```

### Complete Test Example

```python
import pytest
from multi_agent_base.testing import (
    MockLLM,
    MockLLMConfig,
    MockTool,
    MockToolRegistry,
    TestScenario,
    ScenarioRunner,
    assert_response_contains,
    assert_llm_called,
)

class TestMyAgent:
    @pytest.fixture
    def mock_llm(self):
        return MockLLM(responses=[
            "Hello! I'm your assistant.",
            "Let me search for that.",
            "Here are the results: item1, item2",
        ])
    
    @pytest.fixture
    def mock_tools(self):
        registry = MockToolRegistry()
        registry.register(MockTool(
            name="search",
            return_value={"results": ["item1", "item2"]}
        ))
        return registry
    
    @pytest.mark.asyncio
    async def test_greeting(self, mock_llm):
        response = await mock_llm.chat([
            {"role": "user", "content": "Hi!"}
        ])
        
        message = response["choices"][0]["message"]
        assert_response_contains(message, "assistant")
        assert_llm_called(mock_llm)
    
    @pytest.mark.asyncio
    async def test_search_flow(self, mock_llm, mock_tools):
        scenario = (
            TestScenario(name="search_flow")
            .add_turn("Hi", expected_contains=["hello"])
            .add_turn("Search for items", expected_contains=["search"])
        )
        
        runner = ScenarioRunner(
            mock_llm=mock_llm,
            mock_tools=mock_tools
        )
        result = await runner.run(scenario)
        
        assert result.passed
```

## Error Simulation

### Simulate LLM Errors

```python
from multi_agent_base.testing import MockLLM, MockResponse

# Single error response
mock = MockLLM(responses=[
    MockResponse.error("API Error", error_code="api_error")
])

try:
    await mock.chat([{"role": "user", "content": "Hi"}])
except Exception as e:
    print(f"Caught error: {e}")

# Fail after N successful calls
mock = MockLLM(
    responses=["OK", "OK", MockResponse.error("Rate limited")],
)
```

### Simulate Tool Failures

```python
from multi_agent_base.testing import MockTool

# Tool that always fails
failing_tool = MockTool(
    name="unreliable_api",
    side_effect=lambda **kwargs: 1/0  # Raises ZeroDivisionError
)

# Tool that fails after N calls
limited_tool = MockTool(
    name="rate_limited",
    return_value="success",
    fail_after=5,  # Fails on 6th call
)
```

## Metrics and Reporting

### Test Metrics

```python
from multi_agent_base.testing import MockLLM

mock = MockLLM(responses=["Response"])
await mock.chat([{"role": "user", "content": "Hi"}])

metrics = mock.metrics
print(f"Total calls: {metrics.total_calls}")
print(f"Total tokens: {metrics.total_tokens}")
print(f"Error count: {metrics.error_count}")
print(f"Total duration: {metrics.total_duration_ms}ms")
```

### Suite Results

```python
from multi_agent_base.testing import TestSuiteBuilder, TestScenario

suite = TestSuiteBuilder("tests").add_scenario(...).build()
result = await suite.run()

print(f"Suite: {result.name}")
print(f"Total: {result.total_tests}")
print(f"Passed: {result.passed_tests}")
print(f"Failed: {result.failed_tests}")
print(f"Skipped: {result.skipped_tests}")
print(f"Pass Rate: {result.pass_rate}%")
print(f"Duration: {result.duration_ms}ms")

# Individual test results
for test in result.tests:
    status = "✓" if test.passed else "✗"
    print(f"  {status} {test.name}: {test.status.value}")
    if test.error:
        print(f"    Error: {test.error}")
```

## Best Practices

### 1. Use Deterministic Responses

```python
# Good: Predictable responses
mock = MockLLM(responses=["Expected response"])

# Avoid: Random or time-based responses
```

### 2. Test Edge Cases

```python
# Test empty responses
mock = MockLLM(responses=[""])

# Test long responses
mock = MockLLM(responses=["A" * 10000])

# Test special characters
mock = MockLLM(responses=['{"json": "response"}'])
```

### 3. Isolate Tests

```python
@pytest.fixture
def fresh_mock():
    return MockLLM(responses=["Test"])

async def test_one(fresh_mock):
    # Each test gets a fresh mock
    pass

async def test_two(fresh_mock):
    # Independent from test_one
    pass
```

### 4. Use Descriptive Scenario Names

```python
# Good
TestScenario(name="user_greeting_returns_welcome_message")

# Avoid
TestScenario(name="test1")
```

### 5. Assert Specific Behaviors

```python
# Good: Specific assertions
assert_response_contains(message, "weather")
assert_response_not_contains(message, "error")

# Avoid: Vague assertions
assert response is not None
```

## API Reference

### Types

| Type | Description |
|------|-------------|
| `MockResponse` | Structured mock response |
| `MockToolCall` | Mock tool call definition |
| `MockLLMConfig` | Configuration for MockLLM |
| `TestConfig` | Test configuration |
| `TestStatus` | Test result status enum |
| `TestResult` | Individual test result |
| `TestMetrics` | Execution metrics |
| `TestSuiteResult` | Suite execution result |
| `ConversationTurn` | Single conversation turn |
| `TestScenario` | Complete test scenario |

### Mocks

| Class | Description |
|-------|-------------|
| `MockLLM` | Mock LLM implementation |
| `MockTool` | Mock tool implementation |
| `MockToolRegistry` | Tool registry |
| `MockAgent` | Mock agent implementation |

### Fixtures

| Class/Function | Description |
|----------------|-------------|
| `TestContext` | Isolated test context |
| `ConversationFixture` | Multi-turn conversation helper |
| `ScenarioRunner` | Scenario executor |
| `TestSuiteBuilder` | Test suite builder |
| `TestSuite` | Test suite container |
| `@with_mock_llm` | MockLLM injection decorator |
| `@with_mock_tools` | Mock tools injection decorator |
| `mock_llm_context` | MockLLM context manager |
| `mock_tool_context` | MockTool context manager |

### Assertions

| Function | Description |
|----------|-------------|
| `assert_tool_called` | Assert tool was called |
| `assert_tool_not_called` | Assert tool was not called |
| `assert_response_contains` | Assert response contains text |
| `assert_response_not_contains` | Assert response doesn't contain text |
| `assert_response_matches` | Assert response matches regex |
| `assert_llm_called` | Assert LLM was called |
| `assert_llm_not_called` | Assert LLM was not called |
| `assert_cost_under` | Assert cost under threshold |
