# AgentThread - Persistent Conversations

Bu dokümantasyon, Multi-Agent Base Framework'ün AgentThread modülünü açıklar. AgentThread, agent konuşmalarını kaydetme ve devam ettirme imkanı sağlar.

## İçindekiler

- [Genel Bakış](#genel-bakış)
- [Temel Kullanım](#temel-kullanım)
- [Thread Oluşturma](#thread-oluşturma)
- [Mesaj Yönetimi](#mesaj-yönetimi)
- [Persistence](#persistence)
  - [Dosya Tabanlı](#dosya-tabanlı)
  - [Redis](#redis)
- [Checkpoints](#checkpoints)
- [Fork & Branch](#fork--branch)
- [Agent Framework Entegrasyonu](#agent-framework-entegrasyonu)
- [Best Practices](#best-practices)
- [API Reference](#api-reference)

---

## Genel Bakış

AgentThread, konuşma oturumlarını yönetmek için tasarlanmış bir sistemdir:

```
┌─────────────────────────────────────────────────────────────────┐
│                      AgentThread                                 │
├─────────────────────────────────────────────────────────────────┤
│  session_id: str          │  Unique session identifier          │
│  messages: List[Message]  │  Konuşma geçmişi                    │
│  metadata: Dict           │  Oturum metadata'sı                 │
│  checkpoints: List        │  Kayıtlı checkpoint'ler             │
│  created_at: datetime     │  Oluşturma zamanı                   │
│  updated_at: datetime     │  Son güncelleme                     │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
         ┌────────────────────┴────────────────────┐
         │                                         │
    ┌────▼────┐                              ┌────▼────┐
    │  File   │                              │  Redis  │
    │ Storage │                              │ Storage │
    └─────────┘                              └─────────┘
```

### Kullanım Senaryoları

- **Session Persistence**: Kullanıcı oturumlarını kaydetme
- **Conversation Resume**: Konuşmayı kaldığı yerden devam ettirme
- **Multi-turn Dialogs**: Uzun konuşma geçmişi yönetimi
- **A/B Testing**: Fork ile alternatif konuşma dalları
- **Debugging**: Checkpoint'ler ile geçmiş durumlara dönme

---

## Temel Kullanım

```python
from multi_agent_base.core import AgentThread, create_thread, resume_thread

# Yeni thread oluştur
thread = await create_thread(
    session_id="user_123",
    system_prompt="You are a helpful assistant.",
    metadata={"user_name": "Gökhan", "language": "tr"},
)

# Mesaj ekle
thread.add_user_message("Merhaba!")
thread.add_assistant_message("Merhaba! Size nasıl yardımcı olabilirim?")

# Kaydet
await thread.save("./sessions/")

# Sonra yükle ve devam et
loaded_thread = await resume_thread("user_123", path="./sessions/")
print(f"Önceki mesaj sayısı: {len(loaded_thread.messages)}")
```

---

## Thread Oluşturma

### Temel Oluşturma

```python
from multi_agent_base.core import AgentThread

# En basit hali
thread = AgentThread()

# Session ID ile
thread = AgentThread(session_id="user_123")

# Tam konfigürasyon
thread = AgentThread(
    session_id="user_123_chat_1",
    system_prompt="You are a coding assistant. Help with Python.",
    metadata={
        "user_id": "user_123",
        "context": "code_help",
        "preferences": {"verbose": True},
    },
)
```

### Convenience Functions

```python
from multi_agent_base.core import create_thread

# Async thread oluşturma
thread = await create_thread(
    session_id="user_123",
    system_prompt="You are helpful.",
)
```

### Session ID Best Practices

```python
# ❌ Kötü - Tahmin edilebilir
thread = AgentThread(session_id="1")

# ✅ İyi - Unique ve anlamlı
import uuid
thread = AgentThread(session_id=f"user_{user_id}_{uuid.uuid4().hex[:8]}")

# ✅ İyi - Timestamp ile
from datetime import datetime
session_id = f"user_{user_id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
thread = AgentThread(session_id=session_id)
```

---

## Mesaj Yönetimi

### Mesaj Ekleme

```python
# User mesajı
thread.add_user_message("Python'da liste nasıl oluşturulur?")

# Assistant mesajı
thread.add_assistant_message("""
Python'da liste oluşturmak için köşeli parantez kullanabilirsiniz:

```python
my_list = [1, 2, 3]
empty_list = []
```
""")

# System mesajı
thread.add_system_message("Format cevaplarını Türkçe olarak ver.")

# Tool çağrısı
thread.add_tool_message(
    tool_name="python_executor",
    tool_input={"code": "print('Hello')"},
    tool_output="Hello",
)
```

### Mesajları Okuma

```python
# Tüm mesajlar
for msg in thread.messages:
    print(f"[{msg.role}]: {msg.content[:50]}...")

# Son N mesaj
last_5 = thread.get_recent_messages(5)

# Role göre filtreleme
user_messages = thread.get_messages_by_role("user")
assistant_messages = thread.get_messages_by_role("assistant")

# Mesaj sayısı
print(f"Toplam: {thread.message_count}")
print(f"User: {thread.user_message_count}")
print(f"Assistant: {thread.assistant_message_count}")
```

### Mesaj Silme ve Düzenleme

```python
# Son mesajı sil
thread.pop_last_message()

# Belirli index'teki mesajı sil
thread.remove_message(index=3)

# Tüm mesajları temizle (system prompt hariç)
thread.clear_messages(keep_system=True)

# Mesajları truncate et (token limit için)
thread.truncate_messages(max_messages=50)
```

---

## Persistence

### Dosya Tabanlı

```python
# Kaydet
await thread.save("./sessions/")
# Oluşturur: ./sessions/user_123.json

# Özel dosya adı ile
await thread.save("./sessions/", filename="custom_session.json")

# Yükle
loaded = await AgentThread.load("user_123", path="./sessions/")

# Veya convenience function ile
loaded = await resume_thread("user_123", path="./sessions/")
```

#### Dosya Formatı

```json
{
  "session_id": "user_123",
  "created_at": "2026-02-02T08:00:00Z",
  "updated_at": "2026-02-02T08:30:00Z",
  "metadata": {
    "user_name": "Gökhan",
    "language": "tr"
  },
  "messages": [
    {
      "role": "system",
      "content": "You are a helpful assistant.",
      "timestamp": "2026-02-02T08:00:00Z"
    },
    {
      "role": "user",
      "content": "Merhaba!",
      "timestamp": "2026-02-02T08:01:00Z"
    },
    {
      "role": "assistant",
      "content": "Merhaba! Size nasıl yardımcı olabilirim?",
      "timestamp": "2026-02-02T08:01:01Z"
    }
  ],
  "checkpoints": []
}
```

### Redis

```python
import redis.asyncio as redis

# Redis client oluştur
redis_client = redis.from_url("redis://localhost:6379")

# Kaydet
await thread.save_to_redis(redis_client)

# TTL ile kaydet (1 saat sonra expire)
await thread.save_to_redis(redis_client, ttl=3600)

# Yükle
loaded = await AgentThread.load_from_redis("user_123", redis_client)

# Silme
await thread.delete_from_redis(redis_client)
```

#### Redis Key Format

```
thread:{session_id}
```

Örnek:
```
thread:user_123 -> JSON serialized thread data
```

### Hybrid Approach

```python
class ThreadManager:
    def __init__(self, redis_client, backup_path: str):
        self.redis = redis_client
        self.backup_path = backup_path
    
    async def save(self, thread: AgentThread):
        # Önce Redis'e kaydet (hızlı erişim)
        await thread.save_to_redis(self.redis, ttl=86400)
        
        # Sonra dosyaya yedekle (kalıcı)
        await thread.save(self.backup_path)
    
    async def load(self, session_id: str) -> AgentThread:
        # Önce Redis'ten dene
        try:
            return await AgentThread.load_from_redis(session_id, self.redis)
        except:
            # Redis'te yoksa dosyadan yükle
            thread = await AgentThread.load(session_id, self.backup_path)
            # Redis'e de ekle
            await thread.save_to_redis(self.redis, ttl=86400)
            return thread
```

---

## Checkpoints

Checkpoint'ler, konuşmanın belirli anlarını kaydetmenizi sağlar.

### Checkpoint Oluşturma

```python
# Checkpoint oluştur
cp = thread.create_checkpoint("after_greeting")
print(f"Checkpoint: {cp.name} at message {cp.message_index}")

# Metadata ile
cp = thread.create_checkpoint(
    name="before_code_generation",
    metadata={
        "user_request": "Python kodu yaz",
        "context": "data_analysis",
    },
)
```

### Checkpoint'leri Listeleme

```python
checkpoints = thread.list_checkpoints()
for cp in checkpoints:
    print(f"{cp.name}: {cp.created_at} (msg #{cp.message_index})")
```

### Rollback

```python
# Checkpoint'e geri dön
thread.rollback_to_checkpoint("after_greeting")
print(f"Mesaj sayısı: {thread.message_count}")  # Checkpoint anındaki sayı

# Index ile rollback
thread.rollback_to_message_index(5)
```

### Checkpoint Karşılaştırma

```python
# İki checkpoint arasındaki farkı göster
diff = thread.compare_checkpoints("cp1", "cp2")
print(f"Eklenen mesaj sayısı: {diff['added_messages']}")
print(f"Silinen mesaj sayısı: {diff['removed_messages']}")
```

---

## Fork & Branch

Alternatif konuşma dalları oluşturun.

### Fork Oluşturma

```python
# Mevcut durumu fork'la
fork = thread.fork("user_123_branch_a")
print(f"Fork session: {fork.session_id}")
print(f"Fork mesaj sayısı: {fork.message_count}")

# Fork'a farklı mesajlar ekle
fork.add_user_message("Bu alternatif bir soru")
fork.add_assistant_message("Bu alternatif bir cevap")

# Original thread etkilenmez
print(f"Original mesaj sayısı: {thread.message_count}")
```

### Checkpoint'ten Fork

```python
# Belirli bir checkpoint'ten fork
fork = thread.fork_from_checkpoint(
    checkpoint_name="before_code_generation",
    new_session_id="user_123_experiment",
)
```

### A/B Testing

```python
async def ab_test_responses(thread: AgentThread, user_message: str):
    # Fork A
    fork_a = thread.fork(f"{thread.session_id}_a")
    fork_a.add_user_message(user_message)
    response_a = await agent_a.run(fork_a)
    
    # Fork B
    fork_b = thread.fork(f"{thread.session_id}_b")
    fork_b.add_user_message(user_message)
    response_b = await agent_b.run(fork_b)
    
    # Karşılaştır
    return {
        "response_a": response_a,
        "response_b": response_b,
    }
```

---

## Agent Framework Entegrasyonu

### ChatHistoryProvider

```python
from multi_agent_base.core import ThreadChatHistoryProvider

# Thread'i ChatHistoryProvider'a dönüştür
provider = ThreadChatHistoryProvider(thread)

# Veya thread'den doğrudan
provider = thread.as_chat_history_provider()

# Agent Framework ile kullan
from agent_framework import Agent

agent = Agent(
    model="gpt-4",
    chat_history_provider=provider,
)
```

### BaseAgent Entegrasyonu

```python
from multi_agent_base.core import BaseAgent, AgentThread

# Thread'den agent oluştur
thread = await resume_thread("user_123", path="./sessions/")
agent = BaseAgent.from_thread(thread)

# Konuşmaya devam et
response = await agent.run("Kaldığımız yerden devam edelim")

# Thread otomatik güncellenir
print(f"Yeni mesaj sayısı: {thread.message_count}")

# Kaydet
await thread.save("./sessions/")
```

### Streaming ile Kullanım

```python
async def chat_with_persistence(
    session_id: str,
    user_message: str,
):
    # Thread'i yükle veya oluştur
    try:
        thread = await resume_thread(session_id, path="./sessions/")
    except FileNotFoundError:
        thread = await create_thread(session_id)
    
    # Mesajı ekle
    thread.add_user_message(user_message)
    
    # Agent ile cevap al (streaming)
    agent = BaseAgent.from_thread(thread)
    full_response = ""
    
    async for chunk in agent.run_stream(user_message):
        full_response += chunk
        yield chunk
    
    # Cevabı thread'e ekle
    thread.add_assistant_message(full_response)
    
    # Kaydet
    await thread.save("./sessions/")
```

---

## Best Practices

### 1. Session ID Stratejisi

```python
# Kullanıcı + Zaman bazlı
session_id = f"user_{user_id}_{datetime.now().strftime('%Y%m%d')}"

# Context bazlı
session_id = f"user_{user_id}_support_ticket_{ticket_id}"

# Rastgele unique
import uuid
session_id = f"session_{uuid.uuid4()}"
```

### 2. Düzenli Kaydetme

```python
# Her N mesajda bir kaydet
if thread.message_count % 5 == 0:
    await thread.save("./sessions/")

# Veya her assistant cevabından sonra
thread.add_assistant_message(response)
await thread.save("./sessions/")
```

### 3. Memory Management

```python
# Eski mesajları temizle
if thread.message_count > 100:
    # Son 50 mesajı tut
    thread.truncate_messages(max_messages=50)
    
    # Veya checkpoint oluştur ve temizle
    thread.create_checkpoint("before_cleanup")
    thread.truncate_messages(max_messages=20)
```

### 4. Error Handling

```python
async def safe_resume(session_id: str) -> AgentThread:
    try:
        return await resume_thread(session_id, path="./sessions/")
    except FileNotFoundError:
        # Yeni thread oluştur
        return await create_thread(session_id)
    except json.JSONDecodeError:
        # Bozuk dosya - yedekten dene
        return await resume_thread(session_id, path="./backups/")
```

### 5. Metadata Kullanımı

```python
thread = AgentThread(
    session_id="user_123",
    metadata={
        # Kullanıcı bilgileri
        "user_id": "user_123",
        "user_name": "Gökhan",
        "user_tier": "premium",
        
        # Context
        "conversation_type": "support",
        "language": "tr",
        
        # Analytics
        "start_time": datetime.now().isoformat(),
        "source": "web_chat",
        
        # Agent config
        "model": "gpt-4",
        "temperature": 0.7,
    },
)
```

---

## API Reference

### ThreadState

```python
class ThreadState:
    ACTIVE = "active"
    PAUSED = "paused"
    COMPLETED = "completed"
    ARCHIVED = "archived"
```

### AgentThread Methods

```python
class AgentThread:
    # Mesaj yönetimi
    def add_user_message(content: str) -> None
    def add_assistant_message(content: str) -> None
    def add_system_message(content: str) -> None
    def add_tool_message(tool_name: str, tool_input: dict, tool_output: str) -> None
    def get_recent_messages(count: int) -> List[Message]
    def get_messages_by_role(role: str) -> List[Message]
    def pop_last_message() -> Message
    def remove_message(index: int) -> None
    def clear_messages(keep_system: bool = True) -> None
    def truncate_messages(max_messages: int) -> None
    
    # Checkpoint
    def create_checkpoint(name: str, metadata: dict = None) -> ThreadCheckpoint
    def list_checkpoints() -> List[ThreadCheckpoint]
    def get_checkpoint(name: str) -> ThreadCheckpoint
    def rollback_to_checkpoint(name: str) -> None
    def rollback_to_message_index(index: int) -> None
    
    # Fork
    def fork(new_session_id: str) -> AgentThread
    def fork_from_checkpoint(checkpoint_name: str, new_session_id: str) -> AgentThread
    
    # Persistence
    async def save(path: str, filename: str = None) -> None
    @classmethod
    async def load(session_id: str, path: str) -> AgentThread
    async def save_to_redis(client: Redis, ttl: int = None) -> None
    @classmethod
    async def load_from_redis(session_id: str, client: Redis) -> AgentThread
    
    # Conversion
    def as_chat_history_provider() -> ChatHistoryProvider
    def to_dict() -> Dict
    @classmethod
    def from_dict(data: Dict) -> AgentThread
```

### ThreadCheckpoint

```python
@dataclass
class ThreadCheckpoint:
    checkpoint_id: str
    name: str
    message_index: int
    created_at: datetime
    metadata: Dict[str, Any]
```

---

## Örnek Senaryo: Customer Support Bot

```python
from multi_agent_base.core import AgentThread, create_thread, resume_thread
from multi_agent_base import BaseAgent

class SupportBot:
    def __init__(self, sessions_path: str = "./sessions/"):
        self.sessions_path = sessions_path
    
    async def start_or_resume_session(
        self,
        user_id: str,
        ticket_id: str,
    ) -> AgentThread:
        session_id = f"support_{user_id}_{ticket_id}"
        
        try:
            # Mevcut session'ı dene
            thread = await resume_thread(session_id, self.sessions_path)
            print(f"Resumed session with {thread.message_count} messages")
        except FileNotFoundError:
            # Yeni session oluştur
            thread = await create_thread(
                session_id=session_id,
                system_prompt="""You are a helpful customer support agent.
                Be polite, professional, and solution-oriented.
                If you can't solve the issue, escalate to a human.""",
                metadata={
                    "user_id": user_id,
                    "ticket_id": ticket_id,
                    "created_at": datetime.now().isoformat(),
                },
            )
            print("Created new support session")
        
        return thread
    
    async def handle_message(
        self,
        thread: AgentThread,
        user_message: str,
    ) -> str:
        # User mesajını ekle
        thread.add_user_message(user_message)
        
        # Agent ile cevap al
        agent = BaseAgent.from_thread(thread)
        response = await agent.run(user_message)
        
        # Cevabı ekle
        thread.add_assistant_message(response)
        
        # Kaydet
        await thread.save(self.sessions_path)
        
        return response
    
    async def escalate_to_human(self, thread: AgentThread) -> None:
        # Checkpoint oluştur
        thread.create_checkpoint(
            name="escalation_point",
            metadata={"reason": "User requested human agent"},
        )
        
        # Status güncelle
        thread.metadata["status"] = "escalated"
        thread.metadata["escalated_at"] = datetime.now().isoformat()
        
        await thread.save(self.sessions_path)
    
    async def close_ticket(self, thread: AgentThread) -> None:
        thread.metadata["status"] = "closed"
        thread.metadata["closed_at"] = datetime.now().isoformat()
        
        # Final checkpoint
        thread.create_checkpoint("ticket_closed")
        
        await thread.save(self.sessions_path)


# Kullanım
bot = SupportBot()

# Session başlat
thread = await bot.start_or_resume_session("user_123", "TICKET-456")

# Mesajlaşma
response = await bot.handle_message(thread, "Siparişim nerede?")
print(response)

response = await bot.handle_message(thread, "3 gündür bekliyorum")
print(response)

# Escalate
await bot.escalate_to_human(thread)
```

---

## Sonraki Adımlar

- [HITL Framework](./hitl.md) - Human-in-the-Loop
- [Patterns](./patterns.md) - Multi-agent patterns
- [Tools](./tools.md) - Tool sistemi
