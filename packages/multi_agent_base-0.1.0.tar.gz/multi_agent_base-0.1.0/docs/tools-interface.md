# Tools Interface Guide

Bu doküman, Multi-Agent Base Framework'ün araç (tool) tanımlama ve yönetim sistemini açıklar.

## İçindekiler

- [Genel Bakış](#genel-bakış)
- [BaseTool Interface](#basetool-interface)
- [Decorator'lar](#decoratorlar)
- [Tool Registry](#tool-registry)
- [Entegrasyon](#entegrasyon)
- [Best Practices](#best-practices)

---

## Genel Bakış

Framework, dışarıdan skill, action ve tool tanımlamaları için birleşik bir interface sunar:

```
┌─────────────────────────────────────────────────────┐
│                   Tool Ecosystem                     │
├─────────────────────────────────────────────────────┤
│  Decorators (@tool, @action, @skill, @async_tool)   │
├─────────────────────────────────────────────────────┤
│         FunctionTool / CustomTool Classes           │
├─────────────────────────────────────────────────────┤
│             BaseTool Abstract Interface             │
├─────────────────────────────────────────────────────┤
│      ToolRegistry (Namespaces, Categories, Tags)    │
├─────────────────────────────────────────────────────┤
│              Agent Integration Layer                │
└─────────────────────────────────────────────────────┘
```

---

## BaseTool Interface

### Temel Yapı

```python
from multi_agent_base.core.tools import (
    BaseTool,
    ToolParameter,
    ToolResult,
    ToolResultStatus
)

class MyCustomTool(BaseTool):
    """Özel araç implementasyonu."""
    
    def __init__(self):
        super().__init__(
            name="my_tool",
            description="Tool açıklaması",
            parameters=[
                ToolParameter(
                    name="input_text",
                    type="string",
                    description="Giriş metni",
                    required=True
                ),
                ToolParameter(
                    name="max_length",
                    type="integer",
                    description="Maksimum uzunluk",
                    required=False,
                    default=100
                )
            ],
            timeout=30.0,  # saniye
            max_retries=3
        )
    
    async def execute(self, **kwargs) -> ToolResult:
        """Araç mantığı."""
        input_text = kwargs.get("input_text")
        max_length = kwargs.get("max_length", 100)
        
        try:
            result = input_text[:max_length]
            return ToolResult(
                status=ToolResultStatus.SUCCESS,
                data={"result": result},
                message="İşlem başarılı"
            )
        except Exception as e:
            return ToolResult(
                status=ToolResultStatus.ERROR,
                error=str(e)
            )
```

### ToolResult Status'ları

| Status | Açıklama |
|--------|----------|
| `SUCCESS` | İşlem başarıyla tamamlandı |
| `ERROR` | Bir hata oluştu |
| `PARTIAL` | Kısmen başarılı |
| `TIMEOUT` | Zaman aşımı |

### Sync Wrapper

Async tool'ları sync context'te kullanmak için:

```python
# Async method
result = await my_tool.execute(input_text="Hello")

# Sync wrapper
result = my_tool.run_sync(input_text="Hello")
```

---

## Decorator'lar

Fonksiyonları kolayca tool'a çevirmek için decorator'lar:

### @tool - Basit Tool

```python
from multi_agent_base.core.decorators import tool

@tool(category="text", tags=["processing", "utility"])
def process_text(text: str, uppercase: bool = False) -> str:
    """Metni işler.
    
    Args:
        text: İşlenecek metin
        uppercase: Büyük harfe çevir
    
    Returns:
        İşlenmiş metin
    """
    if uppercase:
        return text.upper()
    return text.strip()

# Kullanım
result = process_text("  hello  ", uppercase=True)
# "HELLO"
```

### @async_tool - Async Tool

```python
from multi_agent_base.core.decorators import async_tool
import aiohttp

@async_tool(timeout=60.0, max_retries=2)
async def fetch_data(url: str) -> dict:
    """URL'den veri çeker.
    
    Args:
        url: Çekilecek URL
    
    Returns:
        JSON response
    """
    async with aiohttp.ClientSession() as session:
        async with session.get(url) as response:
            return await response.json()
```

### @action - Eylem

```python
from multi_agent_base.core.decorators import action

@action(category="file", requires_confirmation=True)
def delete_file(path: str) -> bool:
    """Dosya siler.
    
    Args:
        path: Silinecek dosya yolu
    
    Returns:
        Başarılı ise True
    """
    import os
    os.remove(path)
    return True
```

### @skill - Yetenek

```python
from multi_agent_base.core.decorators import skill

@skill(category="analysis", complexity="high")
def analyze_sentiment(text: str) -> dict:
    """Duygu analizi yapar.
    
    Args:
        text: Analiz edilecek metin
    
    Returns:
        Sentiment sonuçları
    """
    # Analiz mantığı
    return {
        "sentiment": "positive",
        "confidence": 0.85,
        "emotions": ["joy", "trust"]
    }
```

---

## Tool Registry

### Temel Kullanım

```python
from multi_agent_base.core.registry import get_registry, ToolNamespace

# Global registry
registry = get_registry()

# Tool ekleme (decorator'lar otomatik ekler)
registry.register(my_custom_tool)

# Tool bulma
tool = registry.get("my_tool")

# Kategori ile listeleme
text_tools = registry.get_by_category("text")

# Tag ile arama
utility_tools = registry.get_by_tags(["utility"])
```

### Namespace'ler

Tool'ları izole gruplar halinde organize edin:

```python
from multi_agent_base.core.registry import ToolNamespace

# Namespace oluşturma
sales_namespace = ToolNamespace("sales")
support_namespace = ToolNamespace("support")

# Namespace'e tool ekleme
sales_namespace.register(pricing_tool)
sales_namespace.register(discount_tool)

support_namespace.register(ticket_tool)
support_namespace.register(faq_tool)

# Registry'ye namespace ekleme
registry.add_namespace(sales_namespace)
registry.add_namespace(support_namespace)

# Namespace'ten tool alma
pricing = registry.get("pricing_tool", namespace="sales")
```

### Bulk İşlemler

```python
# Tüm tool'ları listele
all_tools = registry.list_all()

# Namespace içindekiler
sales_tools = registry.list_namespace("sales")

# Birden fazla tool ekle
registry.register_many([tool1, tool2, tool3])

# Tüm tool'ları temizle
registry.clear()
```

---

## Entegrasyon

### Agent'a Tool Ekleme

```python
from multi_agent_base.core import BaseAgent
from multi_agent_base.core.decorators import tool

@tool(category="math")
def calculate(expression: str) -> float:
    """Matematiksel ifade hesaplar."""
    return eval(expression)  # Gerçek kullanımda güvenli parser kullanın

# Agent'a skill olarak ekleme
agent = BaseAgent(config=my_config)

# Tool'u agent skill'ine çevir
skill = calculate.to_agent_skill()
agent.add_skill(skill)
```

### FunctionTool ile Hızlı Oluşturma

```python
from multi_agent_base.core.tools import FunctionTool

def simple_function(x: int, y: int) -> int:
    """İki sayıyı toplar."""
    return x + y

# Fonksiyondan otomatik tool oluştur
tool = FunctionTool.from_function(simple_function)
```

### Schema Export

OpenAI veya Anthropic formatına dönüştürme:

```python
# OpenAI format
openai_schema = my_tool.to_openai_schema()
# {
#     "name": "my_tool",
#     "description": "...",
#     "parameters": {
#         "type": "object",
#         "properties": {...},
#         "required": [...]
#     }
# }

# Anthropic format
anthropic_schema = my_tool.to_anthropic_schema()
```

---

## Best Practices

### 1. İyi Tool Tasarımı

```python
# ✅ İyi: Tek sorumluluk, açık parametreler
@tool(category="email")
def send_email(to: str, subject: str, body: str) -> bool:
    """E-posta gönderir."""
    pass

# ❌ Kötü: Çok fazla sorumluluk
@tool()
def do_everything(action: str, data: dict) -> Any:
    """Her şeyi yapar."""
    pass
```

### 2. Hata Yönetimi

```python
@async_tool(max_retries=3)
async def robust_operation(data: str) -> ToolResult:
    """Sağlam bir operasyon."""
    try:
        result = await process(data)
        return ToolResult(
            status=ToolResultStatus.SUCCESS,
            data=result
        )
    except ValidationError as e:
        return ToolResult(
            status=ToolResultStatus.ERROR,
            error=f"Validation failed: {e}",
            data={"field": e.field}
        )
    except TimeoutError:
        return ToolResult(
            status=ToolResultStatus.TIMEOUT,
            error="Operation timed out"
        )
```

### 3. Docstring Formatı

Parametreler otomatik çıkarılır, iyi docstring yazın:

```python
@tool()
def well_documented(param1: str, param2: int = 10) -> dict:
    """Kısa açıklama.
    
    Uzun açıklama ve detaylar burada.
    Birden fazla satır olabilir.
    
    Args:
        param1: İlk parametrenin açıklaması
        param2: İkinci parametrenin açıklaması.
            Varsayılan değeri 10'dur.
    
    Returns:
        Sonuç dictionary'si
    
    Raises:
        ValueError: Geçersiz parametre
    
    Example:
        >>> result = well_documented("test", 20)
        >>> print(result)
        {"processed": "test", "count": 20}
    """
    pass
```

### 4. Kategori ve Tag Stratejisi

```python
# Tutarlı kategori şeması
CATEGORIES = {
    "file": "Dosya işlemleri",
    "network": "Ağ işlemleri", 
    "data": "Veri işleme",
    "ai": "AI/ML işlemleri",
    "system": "Sistem işlemleri"
}

# Anlamlı tag'ler
@tool(
    category="network",
    tags=["http", "async", "external-api", "rate-limited"]
)
async def api_call(endpoint: str) -> dict:
    pass
```

### 5. Timeout ve Retry Konfigürasyonu

```python
# Hızlı işlemler için kısa timeout
@tool(timeout=5.0, max_retries=1)
def quick_lookup(key: str) -> str:
    pass

# Yavaş işlemler için uzun timeout, retry
@async_tool(timeout=120.0, max_retries=3)
async def long_running_task(data: dict) -> dict:
    pass
```

---

## Özet

| Özellik | Açıklama |
|---------|----------|
| `BaseTool` | Abstract base class, tüm tool'ların temeli |
| `FunctionTool` | Fonksiyondan otomatik tool oluşturma |
| `@tool` | Sync fonksiyon decorator'ı |
| `@async_tool` | Async fonksiyon decorator'ı |
| `@action` | Eylem decorator'ı (yan etkili işlemler) |
| `@skill` | Yetenek decorator'ı (kompleks işlemler) |
| `ToolRegistry` | Global tool yönetimi |
| `ToolNamespace` | İzole tool grupları |
| `ToolResult` | Standart sonuç formatı |
