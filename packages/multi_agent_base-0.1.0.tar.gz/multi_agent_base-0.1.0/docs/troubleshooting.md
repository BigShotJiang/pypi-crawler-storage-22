# Troubleshooting Guide

Common issues and solutions for Multi-Agent Base.

## Installation Issues

### "Package not found" errors

```bash
# Install with all providers
pip install multi-agent-base[all]

# Or specific providers
pip install multi-agent-base[openai]
pip install multi-agent-base[ollama]
pip install multi-agent-base[anthropic]
```

### Import errors after installation

```bash
# Verify installation
python -c "import multi_agent_base; print(multi_agent_base.__version__)"

# Reinstall if needed
pip uninstall multi-agent-base
pip install multi-agent-base[all]
```

---

## Provider Issues

### Ollama

**"Ollama package not installed"**
```bash
pip install ollama
```

**"Connection refused to localhost:11434"**
```bash
# Start Ollama service
ollama serve

# Or check if running
curl http://localhost:11434/api/version
```

**"Model not found"**
```bash
# Pull the model first
ollama pull llama3.2
ollama pull mistral
```

### OpenAI

**"Invalid API key"**
```python
# Check key format (should start with sk-)
import os
print(os.environ.get("OPENAI_API_KEY", "NOT SET")[:10])

# Set correctly
os.environ["OPENAI_API_KEY"] = "sk-..."
```

**"Rate limit exceeded"**
```python
from multi_agent_base.ratelimit import TokenBucketLimiter, RateLimitConfig

limiter = TokenBucketLimiter(RateLimitConfig(
    requests_per_minute=50,  # Lower than your limit
    tokens_per_minute=10000,
))

# Use before API calls
if await limiter.can_acquire():
    await limiter.acquire(tokens=estimated_tokens)
    response = await agent.run(message)
else:
    await asyncio.sleep(limiter.retry_after)
```

### Anthropic

**"Invalid API key"**
```python
# Key should start with sk-ant-
os.environ["ANTHROPIC_API_KEY"] = "sk-ant-..."
```

**"Max tokens required"**
```python
config = SystemConfig(
    provider=ProviderType.ANTHROPIC,
    model="claude-3-5-sonnet-20241022",
    max_tokens=4096,  # Required for Anthropic
)
```

---

## Memory Issues

### High memory usage

```python
# Use bounded memory
from multi_agent_base.memory import BufferMemory, MemoryConfig

memory = BufferMemory(MemoryConfig(
    max_entries=100,  # Limit entries
    max_tokens=10000,  # Limit tokens
))

# Or use sliding window
from multi_agent_base.memory import SlidingWindowMemory

memory = SlidingWindowMemory(MemoryConfig(
    max_entries=50,
))
```

### Redis connection errors

```python
import redis.asyncio as redis

# Test connection
client = redis.Redis.from_url("redis://localhost:6379")
await client.ping()  # Should return True

# Check Redis is running
# redis-cli ping
```

---

## Tool Execution Issues

### "Unknown tool" error

```python
# Ensure tool is registered
agent.register_tool(my_function)

# Check registered tools
print(agent.tools.keys())
```

### Tool execution fails

```python
# Check function signature matches expected args
def my_tool(arg1: str, arg2: int = 10) -> dict:
    """Tool description."""
    return {"result": arg1}

# Async tools need async def
async def async_tool(query: str) -> str:
    """Async tool."""
    result = await some_async_operation(query)
    return result
```

### Tool calls not being made

```python
# Ensure tools are passed to model
tools_schema = agent._build_tools_schema()
print(tools_schema)  # Should have your tools

# Check if model supports tools
# llama3.2: Yes
# older models: May not support
```

---

## Rate Limiting Issues

### Incorrect rate calculations

```python
# Check current state
status = await limiter.get_status()
print(f"Tokens: {status['current_tokens']}")
print(f"Requests: {status['requests_made']}")

# Reset if needed
await limiter.reset()
```

### Redis rate limiter sync issues

```python
# Use atomic operations
from multi_agent_base.ratelimit import RedisRateLimiter

limiter = RedisRateLimiter(
    config=config,
    redis_client=redis_client,
    key_prefix="unique_prefix",  # Use unique prefix
    identifier="instance_1",  # Per-instance if needed
)
```

---

## Caching Issues

### Cache not working

```python
# Check if caching is enabled
print(cache.config.enabled)

# Check TTL
print(cache.config.default_ttl)

# Verify key generation
key = cache._generate_key("test query")
print(key)
```

### Semantic cache misses

```python
# Lower similarity threshold
cache = SemanticCache(
    config=SemanticCacheConfig(
        similarity_threshold=0.8,  # Lower = more matches
    ),
    embedding_fn=my_embedding_function,
)
```

---

## Security Issues

### Injection detection false positives

```python
from multi_agent_base.security import InjectionDetector

detector = InjectionDetector()

# Adjust threshold
result = detector.detect(
    text,
    threshold=0.7,  # Higher = less sensitive
)

# Check what triggered
print(result.threats)
print(result.confidence)
```

### Input validation errors

```python
from multi_agent_base.security import InputValidator

validator = InputValidator()

result = validator.validate(text)
if not result.is_valid:
    for error in result.errors:
        print(f"Error: {error}")
```

---

## Observability Issues

### Phoenix not receiving traces

```python
from multi_agent_base.observability import PhoenixTracer, PhoenixConfig

tracer = PhoenixTracer(config=PhoenixConfig(
    endpoint="http://localhost:6006",
    enabled=True,  # Must be True
    export_to_collector=True,
))
tracer.setup()

# Verify Phoenix is running
# curl http://localhost:6006/health
```

### Missing logs

```python
import logging

# Enable debug logging
logging.getLogger("multi_agent_base").setLevel(logging.DEBUG)

# Or for specific module
logging.getLogger("multi_agent_base.core.agent").setLevel(logging.DEBUG)
```

---

## Performance Issues

### Slow response times

1. **Check network latency**
```python
import time

start = time.time()
response = await client.generate([{"role": "user", "content": "Hi"}])
print(f"Latency: {time.time() - start:.2f}s")
```

2. **Enable caching**
```python
from multi_agent_base.cache import LRUCache

cache = LRUCache(LRUCacheConfig(max_size=1000))
```

3. **Use streaming**
```python
async for chunk in agent.run_stream(message):
    print(chunk, end="", flush=True)
```

### High CPU usage

```python
# Profile your code
import cProfile
import pstats

profiler = cProfile.Profile()
profiler.enable()

# Your code here
await agent.run(message)

profiler.disable()
stats = pstats.Stats(profiler).sort_stats('cumulative')
stats.print_stats(10)
```

---

## Getting Help

1. **Check documentation**: [docs/](.)
2. **Search issues**: GitHub Issues
3. **Enable debug logging**: See above
4. **Create minimal reproduction**: Isolate the problem

When reporting issues, include:
- Python version
- Package version
- Full error traceback
- Minimal code to reproduce
