# Uyumsuzluklar ve AF Adapter Onerileri

Bu dokuman, projedeki kod/dokuman uyumsuzluklarini toparlar ve
Microsoft Agent Framework (AF) parcalarini "adapter" olarak kullanmak
icin pratik oneriler verir.

## 1) Uyumsuzluklar (kod <-> dokuman / ic API)

### A. Model client wiring yok (pattern -> agent -> LLM calismiyor)
- Durum: Pattern'lar BaseAgent olusturuyor ama `model_client` vermiyor.
  `BaseAgent._call_model()` `model_client` yoksa bos donuyor.
- Etkisi: `pattern.run(...)` bos cikti uretebiliyor.
- Oneri:
  - Pattern icinde `ModelClientFactory.create(self.config.provider)` ile
    `model_client` olustur ve BaseAgent'a ver.
  - Alternatif: BaseAgent `model_client` yoksa lazily olustursun.

### B. Tool schema uyumsuzlugu (OpenAI/Anthropic)
- Durum: `BaseAgent._build_tools_schema()` zaten OpenAI formatinda
  `{type:function,function:{...}}` donduruyor; `OpenAIClient.generate()`
  tekrar wrap ediyor. `AnthropicClient.generate()` ise `name/parameters`
  bekliyor. Tool call formatlari da farkli.
- Etkisi: Tool calling bozuluyor, tool loop calismiyor.
- Oneri:
  - Tek bir "kanonik tool schema" belirle (orn. sadece
    `{name, description, parameters}`) ve provider client'lari bunu
    kendi formatina cevirsin.
  - Tool call formatini tek tipe normalize et (orn.
    `{id, name, arguments}`) ve `_execute_tool()` bunu beklesin.

### C. Logger metot uyumsuzlugu
- Durum: BaseAgent `logger.log_tool_execution(...)` cagiriyor,
  `AgentLogger` icinde bu metod yok.
- Etkisi: Logger aktifse tool calismasinda runtime hata.
- Oneri:
  - BaseAgent tarafinda `log_tool_call` kullan, veya
    `AgentLogger.log_tool_execution` ekle.

### D. Iki ayri tool sistemi (BaseTool vs core.agent.Tool)
- Durum: `BaseAgent` kendi `Tool` wrapper'ini kullaniyor; `BaseTool` /
  `FunctionTool` ile uyumlu degil (schema ve execution farkli).
- Etkisi: `BaseTool` ozellikleri (timeout, retry, validation, tags)
  agent tarafinda calismiyor.
- Oneri:
  - Tek tool modelini "kanonik" yap (BaseTool ya da core.agent.Tool).
  - Eger iki sistem kalacaksa "adapter" yaz:
    `BaseTool -> Tool` ve `Tool -> BaseTool` ceviricileri.

### E. Dokuman ornekleri guncel API ile uyumsuz
- README + docs/providers:
  - `SystemConfig(provider=..., model=...)` ornekleri guncel degil;
    dogru kullanim `ProviderConfig` ile olmali.
- docs/tools-interface:
  - `timeout/max_retries`, `run_sync`, `ToolResult.message`,
    `agent.add_skill` API'leri kodda yok.
- docs/a2a-agent-cards:
  - `discover_skills` fonksiyonu export edilmiyor.
- Oneri:
  - Dokumanlari guncel API'ye hizala (tek otorite: kod).
  - Eksik fonksiyon/yardimci varsa ya ekle ya da dokumandan kaldir.

## 2) Oncelikli duzeltme sirasi (pratik)

1. **Model client wiring + tool schema normalize**  
   LLM calismadan diger katmanlarin degeri gorulmuyor.

2. **Tool sistemi birlestirme veya adapter**  
   `BaseTool` avantajlari (retry/timeout/validation) burada kayboluyor.

3. **Logger uyumu**  
   Basit ama production'da kritik bir runtime hatasi.

4. **Docs/README hizalama**  
   Onboarding ve kullanici deneyimini iyilestirir.

5. **Minimal entegrasyon testleri**  
   1-2 e2e test (single agent + tool calling) yeterli.

## 3) AF parcalarini adapter olarak kullanma (mantikli yerler)

Aşağıda AF'yi "motor" gibi kullanip senin base katmanini "facade" olarak
konumlamanin mantikli oldugu alanlar var:

### A. Orkestrasyon / workflow runtime (AF)
- AF'nin orchestration/workflow altyapisi:
  - Senin Pattern interface'ini koruyup AF orkestrasyonlarini
    arka planda kullanabilirsin.
- Adapter fikri:
  - `Pattern.run()` -> AF workflow run
  - `PatternResult` <- AF run sonucunu normalize et

### B. Tool invocation / function calling loop (AF)
- AF'nin tool loop / function calling yonetimini kullan,
  BaseAgent sadece "tool registry + schema" saglasin.
- Adapter fikri:
  - BaseAgent -> AF Agent wrapper
  - Tool schema -> AF tool definition

### C. Observability / tracing (AF -> OTel)
- AF zaten OTel tabanli; senin Phoenix/Logger katmanin buna oturabilir.
- Adapter fikri:
  - AF span/trace -> Phoenix export
  - Senin `AgentLogger`'in AF eventlerini dinleyen handler olsun

### D. Checkpointing / long-run / state
- Eger uzun isler ve resume gereksinimi varsa AF workflow
  checkpointing'i "engine" olarak kullanmak mantikli.

### E. Provider baglantilari
- AF tarafinda provider baglantilarini kullanip,
  senin `ModelClientFactory` katmanini adapter yapabilirsin.

## 4) Sonuc: "Base" katmanin rolu

En iyi pozisyonlama:
- **Base katman = ortak API + standartlar (docs, logging, cost, memory)**
- **AF = execution engine (workflow, tool loop, tracing)**

Bu sayede:
1) Tekrar eden altyapiyi senin katmanda standardize edersin.  
2) Orkestrasyon ve runtime karmaşasini AF'ye birakirsin.  

---

Istersen bu dokumani "uygulama planina" cevirebilirim:
hangi PR'lar, hangi dosyalar, hangi minimum testlerle ilerleyecegiz gibi.
