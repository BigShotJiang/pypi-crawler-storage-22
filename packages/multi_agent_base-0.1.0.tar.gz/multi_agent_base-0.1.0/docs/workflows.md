# Workflow'lar

Workflow'lar, birden fazla adımı ve agent'ı birleştiren graf tabanlı iş akışlarıdır.

---

## Workflow Nedir?

Workflow'lar şu problemleri çözer:

| Problem | Çözüm |
|---------|-------|
| Tek agent karmaşık görevlerde yetersiz | Multi-agent orchestration |
| Belirsiz yürütme sırası | Explicit control flow |
| Uzun süren işlemler | Checkpointing & resume |
| İnsan onayı gerektiren adımlar | Human-in-the-loop |
| Hata yönetimi | Branching & retry |

---

## Temel Kavramlar

### Executor

Workflow'un temel yapı taşı. Her executor bir adımı temsil eder.

```python
from agent_framework import Executor, WorkflowContext, handler

class MyExecutor(Executor):
    @handler
    async def handle(self, input: str, ctx: WorkflowContext[str]) -> None:
        # İşlemi yap
        result = process(input)
        
        # Sonucu gönder
        await ctx.send_message(result)
```

### Edge

Executor'lar arası bağlantı.

```python
workflow = (
    WorkflowBuilder(name="MyWorkflow")
    .set_start_executor(step1)
    .add_edge(step1, step2)      # step1 → step2
    .add_edge(step2, step3)      # step2 → step3
    .build()
)
```

### WorkflowContext

Executor içinde kullanılan context nesnesi.

```python
@handler
async def handle(self, input: str, ctx: WorkflowContext[str]) -> None:
    # Mesaj gönder (bir sonraki executor'a)
    await ctx.send_message("output")
    
    # Final output (workflow çıktısı)
    await ctx.yield_output("final result")
    
    # Shared state
    ctx.set_shared_state("key", "value")
    value = ctx.get_shared_state("key")
```

---

## Basit Workflow

### Örnek: 3 Adımlı Pipeline

```python
from agent_framework import Executor, WorkflowBuilder, WorkflowContext, handler
from pydantic import BaseModel
from typing_extensions import Never


class TextInput(BaseModel):
    text: str


class Step1(Executor):
    """Metni temizle."""
    
    @handler
    async def handle(self, input: TextInput, ctx: WorkflowContext[str]) -> None:
        cleaned = input.text.strip().lower()
        await ctx.send_message(cleaned)


class Step2(Executor):
    """Metni büyük harfe çevir."""
    
    @handler
    async def handle(self, input: str, ctx: WorkflowContext[str]) -> None:
        upper = input.upper()
        await ctx.send_message(upper)


class Step3(Executor):
    """Final işlem."""
    
    @handler
    async def handle(self, input: str, ctx: WorkflowContext[Never, str]) -> None:
        result = f"Sonuç: {input}"
        await ctx.yield_output(result)


# Executor'ları oluştur
step1 = Step1(id="clean")
step2 = Step2(id="uppercase")
step3 = Step3(id="output")

# Workflow'u oluştur
workflow = (
    WorkflowBuilder(name="TextProcessor", description="Metin işleme")
    .set_start_executor(step1)
    .add_edge(step1, step2)
    .add_edge(step2, step3)
    .build()
)
```

---

## Koşullu Yönlendirme

### Switch-Case Pattern

```python
from agent_framework import Case, Default

class Analyzer(Executor):
    @handler
    async def handle(self, input: TextInput, ctx: WorkflowContext) -> None:
        result = AnalysisResult(
            text=input.text,
            is_spam="spam" in input.text.lower(),
        )
        await ctx.send_message(result)


class SpamHandler(Executor):
    @handler
    async def handle(self, input: AnalysisResult, ctx: WorkflowContext) -> None:
        await ctx.yield_output("Spam tespit edildi!")


class NormalHandler(Executor):
    @handler
    async def handle(self, input: AnalysisResult, ctx: WorkflowContext) -> None:
        await ctx.yield_output("Normal mesaj işlendi.")


workflow = (
    WorkflowBuilder(name="ConditionalFlow")
    .set_start_executor(analyzer)
    .add_switch_case_edge_group(
        analyzer,
        [
            Case(
                condition=lambda x: x.is_spam,
                target=spam_handler,
            ),
            Default(target=normal_handler),
        ],
    )
    .build()
)
```

---

## Fan-Out / Fan-In

### Paralel İşleme

```python
workflow = (
    WorkflowBuilder(name="ParallelWorkflow")
    .set_start_executor(dispatcher)
    # Fan-out: dispatcher → [worker1, worker2, worker3]
    .add_fan_out_edges(dispatcher, [worker1, worker2, worker3])
    # Fan-in: [worker1, worker2, worker3] → aggregator
    .add_fan_in_edges([worker1, worker2, worker3], aggregator)
    .build()
)
```

```
                    ┌──────────┐
              ┌────▶│ Worker 1 │────┐
              │     └──────────┘    │
┌──────────┐  │     ┌──────────┐    │     ┌────────────┐
│Dispatcher│──┼────▶│ Worker 2 │────┼────▶│ Aggregator │
└──────────┘  │     └──────────┘    │     └────────────┘
              │     ┌──────────┐    │
              └────▶│ Worker 3 │────┘
                    └──────────┘
```

---

## Agent'ları Workflow'da Kullanma

### AgentExecutor

```python
from agent_framework import ChatAgent, WorkflowBuilder
from agent_framework._workflows import AgentExecutor

# Agent oluştur
writer_agent = ChatAgent(
    chat_client=client,
    name="Writer",
    instructions="İçerik yaz.",
)

reviewer_agent = ChatAgent(
    chat_client=client,
    name="Reviewer",
    instructions="İçeriği incele ve geri bildirim ver.",
)

# AgentExecutor'lara çevir
writer = AgentExecutor(agent=writer_agent, id="writer")
reviewer = AgentExecutor(agent=reviewer_agent, id="reviewer")

# Workflow oluştur
workflow = (
    WorkflowBuilder(name="ContentReview")
    .set_start_executor(writer)
    .add_edge(writer, reviewer)
    .build()
)
```

---

## Human-in-the-Loop

### Kullanıcı Onayı İsteme

```python
from agent_framework import response_handler
from pydantic import BaseModel


class ApprovalRequest(BaseModel):
    content: str
    question: str


class ApprovalResponse(BaseModel):
    approved: bool
    comment: str = ""


class ApprovalStep(Executor):
    @handler
    async def handle(self, input: str, ctx: WorkflowContext) -> None:
        # Kullanıcıya onay sorusu gönder
        await ctx.request_info(
            request_data=ApprovalRequest(
                content=input,
                question="Bu içeriği onaylıyor musunuz?",
            ),
            response_type=ApprovalResponse,
        )
    
    @response_handler
    async def handle_response(
        self,
        request: ApprovalRequest,
        response: ApprovalResponse,
        ctx: WorkflowContext,
    ) -> None:
        if response.approved:
            await ctx.send_message(ApprovedResult(content=request.content))
        else:
            await ctx.send_message(RejectedResult(reason=response.comment))
```

---

## Checkpointing

### Durum Kaydetme

```python
from agent_framework._workflows import FileCheckpointStorage

storage = FileCheckpointStorage(directory="./checkpoints")

workflow = (
    WorkflowBuilder(name="LongRunning")
    .set_start_executor(step1)
    .add_edge(step1, step2)
    .with_checkpointing(storage)
    .build()
)
```

DevUI otomatik olarak checkpoint yönetimi sağlar.

---

## WorkflowViz

### Graph Export

```python
from agent_framework._workflows import WorkflowViz

viz = WorkflowViz(workflow)

# Mermaid diagram
print(viz.to_mermaid())

# DOT diagram
print(viz.to_digraph())

# SVG dosyası
viz.save_svg("workflow_graph.svg")
```

### Örnek Mermaid Çıktısı

```mermaid
flowchart TD
  dispatcher["dispatcher (Start)"];
  worker1["worker1"];
  worker2["worker2"];
  aggregator["aggregator"];
  
  dispatcher --> worker1;
  dispatcher --> worker2;
  worker1 --> aggregator;
  worker2 --> aggregator;
```

---

## Örnek: Email İşleme Workflow

Tam çalışan örnek:

```python
# examples/workflow_devui_demo.py

from agent_framework import Executor, WorkflowBuilder, WorkflowContext, handler
from agent_framework.devui import serve
from pydantic import BaseModel
from typing_extensions import Never


class EmailInput(BaseModel):
    email: str


@dataclass
class ProcessedEmail:
    original: str
    cleaned: str
    word_count: int


class EmailPreprocessor(Executor):
    @handler
    async def handle(self, input: EmailInput, ctx: WorkflowContext[ProcessedEmail]) -> None:
        result = ProcessedEmail(
            original=input.email,
            cleaned=input.email.strip(),
            word_count=len(input.email.split()),
        )
        await ctx.send_message(result)


class SpamDetector(Executor):
    @handler
    async def handle(self, input: ProcessedEmail, ctx: WorkflowContext) -> None:
        spam_words = ["spam", "free", "winner"]
        is_spam = any(w in input.cleaned.lower() for w in spam_words)
        await ctx.send_message(SpamResult(email=input, is_spam=is_spam))


class FinalProcessor(Executor):
    @handler
    async def handle(self, input: SpamResult, ctx: WorkflowContext[Never, str]) -> None:
        if input.is_spam:
            await ctx.yield_output("Email spam olarak işaretlendi.")
        else:
            await ctx.yield_output("Email başarıyla işlendi.")


# Executor'lar
preprocessor = EmailPreprocessor(id="preprocessor")
detector = SpamDetector(id="detector")
processor = FinalProcessor(id="processor")

# Workflow
workflow = (
    WorkflowBuilder(
        name="Email Processing",
        description="Email işleme pipeline'ı",
    )
    .set_start_executor(preprocessor)
    .add_edge(preprocessor, detector)
    .add_edge(detector, processor)
    .build()
)

if __name__ == "__main__":
    serve(entities=[workflow], port=8080, auto_open=True)
```

---

## Çalıştırma

```bash
./scripts/run_devui_workflow.sh
```

**URL:** http://localhost:8080

---

## Sonraki Adımlar

- [Observability](./observability.md) - Trace ve monitoring
- [Troubleshooting](./troubleshooting.md) - Sorun giderme

---

*[← DevUI Özellikleri](./devui-features.md) | [Observability →](./observability.md)*
