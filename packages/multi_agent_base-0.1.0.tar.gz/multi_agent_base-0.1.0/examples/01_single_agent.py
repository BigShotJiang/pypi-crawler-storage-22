"""
Example 1: Single Agent with Tools

This example demonstrates how to create a single agent with
custom tools for performing specific tasks.
"""

import asyncio
from multi_agent_base import SystemConfig, SingleAgentPattern
from multi_agent_base.observability import create_logger, LogLevel
from multi_agent_base.cost import CostTracker


# Define custom tools
def calculate(expression: str) -> float:
    """Calculate a mathematical expression.
    
    Args:
        expression: A mathematical expression to evaluate (e.g., "2 + 2 * 3")
        
    Returns:
        The result of the calculation
    """
    # Safe evaluation for basic math
    allowed_chars = set("0123456789+-*/.() ")
    if not all(c in allowed_chars for c in expression):
        raise ValueError("Invalid characters in expression")
    return eval(expression)


def get_weather(city: str) -> dict:
    """Get the current weather for a city.
    
    Args:
        city: Name of the city
        
    Returns:
        Weather information including temperature and conditions
    """
    # Mock implementation - replace with real API call
    weather_data = {
        "istanbul": {"temp": 22, "condition": "sunny", "humidity": 45},
        "ankara": {"temp": 18, "condition": "cloudy", "humidity": 60},
        "izmir": {"temp": 28, "condition": "sunny", "humidity": 50},
    }
    
    city_lower = city.lower()
    if city_lower in weather_data:
        data = weather_data[city_lower]
        return {
            "city": city,
            "temperature": f"{data['temp']}°C",
            "condition": data["condition"],
            "humidity": f"{data['humidity']}%",
        }
    return {"city": city, "error": "City not found"}


def search_database(query: str, limit: int = 5) -> list[dict]:
    """Search the internal database for records.
    
    Args:
        query: Search query string
        limit: Maximum number of results to return
        
    Returns:
        List of matching records
    """
    # Mock implementation
    mock_records = [
        {"id": 1, "title": "Introduction to AI Agents", "type": "article"},
        {"id": 2, "title": "Building Multi-Agent Systems", "type": "tutorial"},
        {"id": 3, "title": "LLM Best Practices", "type": "guide"},
        {"id": 4, "title": "Agent Orchestration Patterns", "type": "article"},
        {"id": 5, "title": "Cost Optimization for LLMs", "type": "guide"},
    ]
    
    # Simple search simulation
    results = [
        r for r in mock_records 
        if query.lower() in r["title"].lower()
    ]
    return results[:limit]


async def main():
    # Create logger for observability
    logger = create_logger(
        console=True,
        file_path="logs/single_agent.jsonl",
        min_level=LogLevel.INFO,
    )
    
    # Create cost tracker
    cost_tracker = CostTracker(
        auto_persist=True,
        persist_path="logs/costs.jsonl",
    )
    
    # Load configuration from environment
    # Set these environment variables:
    # MULTI_AGENT_PROVIDER=ollama
    # MULTI_AGENT_MODEL=llama3.2
    config = SystemConfig.from_env()
    
    # Create single agent pattern
    pattern = SingleAgentPattern(
        config,
        logger=logger,
        cost_tracker=cost_tracker,
    )
    
    # Create the agent with tools
    agent = pattern.create_agent(
        name="assistant",
        system_prompt="""You are a helpful AI assistant with access to tools.

You can:
- Calculate mathematical expressions using the calculate tool
- Get weather information for cities using the get_weather tool
- Search the internal database using the search_database tool

Always use the appropriate tool when needed. Be helpful and concise.""",
        tools=[calculate, get_weather, search_database],
    )
    
    # Generate and display agent card
    card = agent.generate_agent_card()
    print("=" * 50)
    print("Agent Card Generated:")
    print(f"  Name: {card.name}")
    print(f"  Skills: {[s.id for s in card.skills]}")
    print("=" * 50)
    print()
    
    # Run example queries
    queries = [
        "What is 15 * 7 + 23?",
        "What's the weather like in Istanbul?",
        "Search for articles about agents",
    ]
    
    for query in queries:
        print(f"\n{'='*50}")
        print(f"User: {query}")
        print("=" * 50)
        
        result = await pattern.run(query)
        
        print(f"\nAssistant: {result.content}")
        print(f"\n[Tokens: {result.total_tokens}, Cost: ${result.total_cost:.6f}]")
    
    # Print cost summary
    print("\n" + "=" * 50)
    print("Session Cost Summary:")
    print("=" * 50)
    cost_tracker.print_summary()


if __name__ == "__main__":
    asyncio.run(main())
