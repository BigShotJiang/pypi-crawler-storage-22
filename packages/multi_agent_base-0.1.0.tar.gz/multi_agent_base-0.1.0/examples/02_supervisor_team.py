"""
Example 2: Supervisor Team Pattern

This example demonstrates a supervisor agent orchestrating
multiple specialized worker agents for content creation.
"""

import asyncio
from multi_agent_base import SystemConfig, SupervisorPattern
from multi_agent_base.observability import create_logger, LogLevel
from multi_agent_base.cost import CostTracker


async def main():
    # Set up observability
    logger = create_logger(
        console=True,
        file_path="logs/supervisor_team.jsonl",
        min_level=LogLevel.INFO,
    )
    
    cost_tracker = CostTracker(
        auto_persist=True,
        persist_path="logs/costs.jsonl",
    )
    
    # Load configuration
    config = SystemConfig.from_env()
    
    # Create supervisor pattern
    pattern = SupervisorPattern(
        config,
        logger=logger,
        cost_tracker=cost_tracker,
    )
    
    # Create a content creation team
    pattern.create_team(
        supervisor_name="content-manager",
        supervisor_prompt="""You are a content creation manager leading a team of specialists.

Your team members are:
- researcher: Gathers information, facts, and data on topics
- writer: Creates engaging, well-structured content
- editor: Reviews and polishes content for publication

Your workflow:
1. First, delegate research to the researcher
2. Then, have the writer create content based on research
3. Finally, have the editor polish the final piece

Use this format to delegate:
DELEGATE TO [worker_name]: [detailed task description]

When you have the final polished content, provide it with:
FINAL ANSWER: [the complete final content]

Be thorough and ensure quality at each step.""",
        worker_configs=[
            {
                "name": "researcher",
                "system_prompt": """You are a research specialist.

When given a topic:
1. Identify key aspects to research
2. Gather relevant facts, statistics, and insights
3. Note interesting angles and perspectives
4. Cite sources when possible

Provide your findings in a clear, structured format that a writer can use.
Be thorough but concise. Focus on accuracy and relevance.""",
            },
            {
                "name": "writer",
                "system_prompt": """You are a skilled content writer.

When given research and a content request:
1. Organize information logically
2. Write engaging, clear prose
3. Use appropriate tone for the audience
4. Include compelling introduction and conclusion
5. Add transitions between sections

Create content that is informative, engaging, and well-structured.
Follow best practices for the content type (blog post, article, etc.).""",
            },
            {
                "name": "editor",
                "system_prompt": """You are a meticulous editor.

When reviewing content:
1. Check for grammar and spelling errors
2. Improve clarity and flow
3. Ensure consistency in tone and style
4. Tighten prose - remove unnecessary words
5. Verify logical structure
6. Enhance readability

Provide the polished, publication-ready version of the content.
Make the content shine while preserving the author's voice.""",
            },
        ],
    )
    
    # Run the team on a content creation task
    print("=" * 60)
    print("Content Creation Team - Supervisor Pattern Demo")
    print("=" * 60)
    print()
    
    task = """Write a short blog post (about 300 words) about 
    "The Future of AI Agents in Business" 
    
    Target audience: Business professionals
    Tone: Professional but accessible
    Include: Key benefits, potential applications, and considerations"""
    
    print(f"Task: {task}")
    print()
    print("-" * 60)
    print("Team working...")
    print("-" * 60)
    
    result = await pattern.run(task, max_iterations=15)
    
    print("\n" + "=" * 60)
    print("FINAL CONTENT:")
    print("=" * 60)
    print(result.content)
    
    # Show metrics
    print("\n" + "=" * 60)
    print("METRICS:")
    print("=" * 60)
    print(f"Total agents involved: {len(result.agent_responses)}")
    print(f"Total tokens used: {result.total_tokens}")
    print(f"Total cost: ${result.total_cost:.6f}")
    
    # Show per-agent breakdown
    print("\nPer-agent breakdown:")
    for i, response in enumerate(result.agent_responses):
        agent_name = pattern.get_agents().keys()  # Get agent names
        print(f"  Step {i+1}: {response.usage} tokens")


if __name__ == "__main__":
    asyncio.run(main())
