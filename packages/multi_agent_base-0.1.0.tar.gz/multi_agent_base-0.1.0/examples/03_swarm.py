"""
Example 3: Swarm Pattern

This example demonstrates a customer service swarm with
dynamic agent handoffs based on customer needs.
"""

import asyncio
from multi_agent_base import SystemConfig, SwarmPattern
from multi_agent_base.observability import create_logger, LogLevel
from multi_agent_base.cost import CostTracker


async def main():
    # Set up observability
    logger = create_logger(
        console=True,
        file_path="logs/swarm.jsonl",
        min_level=LogLevel.INFO,
    )
    
    cost_tracker = CostTracker()
    
    # Load configuration
    config = SystemConfig.from_env()
    
    # Create swarm pattern
    pattern = SwarmPattern(
        config,
        logger=logger,
        cost_tracker=cost_tracker,
    )
    
    # Create the triage agent (entry point)
    pattern.create_agent(
        name="triage",
        system_prompt="""You are the initial contact for customer service.

Your job is to quickly understand what the customer needs and route them 
to the right department:

- sales: Product questions, pricing, purchases, demos
- support: Technical issues, how-to questions, troubleshooting
- billing: Invoices, payments, refunds, account balance

Greet the customer briefly and immediately route them.
Use: HANDOFF TO [department]: [brief context]

Do NOT try to solve the issue yourself - always handoff.""",
        can_handoff_to=["sales", "support", "billing"],
        is_start_agent=True,
    )
    
    # Create sales agent
    pattern.create_agent(
        name="sales",
        system_prompt="""You are a friendly sales representative.

You help customers with:
- Product information and features
- Pricing and packages
- Special offers and discounts
- Demo scheduling
- Purchase process

Be helpful and informative. Answer questions thoroughly.
If the customer has a technical issue, handoff to support.
If they have a billing question, handoff to billing.

For handoffs use: HANDOFF TO [department]: [context]
Otherwise, provide a helpful response directly.""",
        can_handoff_to=["support", "billing"],
    )
    
    # Create support agent
    pattern.create_agent(
        name="support",
        system_prompt="""You are a knowledgeable technical support specialist.

You help customers with:
- Troubleshooting technical issues
- How-to guidance and tutorials
- Feature explanations
- Bug reports
- Configuration help

Be patient and thorough. Provide step-by-step instructions when needed.
If the customer wants to buy something, handoff to sales.
If they have a payment/invoice issue, handoff to billing.

For handoffs use: HANDOFF TO [department]: [context]
Otherwise, provide helpful technical assistance.""",
        can_handoff_to=["sales", "billing"],
    )
    
    # Create billing agent
    pattern.create_agent(
        name="billing",
        system_prompt="""You are a billing and accounts specialist.

You help customers with:
- Invoice questions and copies
- Payment processing
- Refund requests
- Subscription changes
- Account balance inquiries

Be professional and clear about policies.
If the customer has a technical issue, handoff to support.
If they want to purchase/upgrade, handoff to sales.

For handoffs use: HANDOFF TO [department]: [context]
Otherwise, handle the billing inquiry directly.""",
        can_handoff_to=["sales", "support"],
    )
    
    # Test scenarios
    scenarios = [
        {
            "name": "Technical Issue",
            "message": "I can't log into my account. I keep getting an error.",
        },
        {
            "name": "Purchase Inquiry",
            "message": "What pricing plans do you have for enterprise customers?",
        },
        {
            "name": "Billing Question",
            "message": "I was charged twice last month. Can I get a refund?",
        },
        {
            "name": "Mixed Query",
            "message": "I want to upgrade my plan but first need help with a bug.",
        },
    ]
    
    print("=" * 60)
    print("Customer Service Swarm - Demo")
    print("=" * 60)
    
    for scenario in scenarios:
        print(f"\n{'='*60}")
        print(f"Scenario: {scenario['name']}")
        print(f"Customer: {scenario['message']}")
        print("-" * 60)
        
        result = await pattern.run(
            scenario["message"],
            max_handoffs=5,
        )
        
        print(f"\nFinal Response: {result.content[:300]}...")
        print(f"\nHandoffs: {result.metadata.get('handoff_count', 0)}")
        print(f"Final Agent: {result.metadata.get('final_agent', 'unknown')}")
        print(f"Total Cost: ${result.total_cost:.6f}")
    
    # Print overall summary
    print("\n" + "=" * 60)
    print("Session Summary")
    print("=" * 60)
    cost_tracker.print_summary()


if __name__ == "__main__":
    asyncio.run(main())
