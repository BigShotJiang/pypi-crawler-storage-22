"""
Example 4: Agent Card Generation and Discovery

This example demonstrates how to generate A2A Agent Cards
and use skill discovery from tool functions.
"""

import asyncio
from pathlib import Path

from multi_agent_base import SystemConfig, SingleAgentPattern
from multi_agent_base.a2a import (
    AgentCard,
    AgentSkill,
    AgentCapabilities,
    AgentProvider,
    AgentCardRegistry,
    SkillDiscoverer,
    discover_skills,
)


# Define some tool functions
def search_web(query: str, max_results: int = 10) -> list[str]:
    """Search the web for information.
    
    Args:
        query: The search query
        max_results: Maximum number of results to return
        
    Returns:
        List of search result URLs
        
    Example:
        >>> search_web("Python programming", max_results=5)
    """
    return [f"https://result{i}.com" for i in range(max_results)]


def analyze_data(data: list[float]) -> dict:
    """Analyze numerical data and provide statistics.
    
    Args:
        data: List of numerical values to analyze
        
    Returns:
        Dictionary with statistical measures
    """
    if not data:
        return {"error": "No data provided"}
    
    return {
        "count": len(data),
        "sum": sum(data),
        "mean": sum(data) / len(data),
        "min": min(data),
        "max": max(data),
    }


def generate_report(
    title: str,
    sections: list[str],
    include_summary: bool = True,
) -> str:
    """Generate a formatted report.
    
    Args:
        title: Report title
        sections: List of section contents
        include_summary: Whether to include a summary section
        
    Returns:
        Formatted report as a string
    """
    report = f"# {title}\n\n"
    for i, section in enumerate(sections, 1):
        report += f"## Section {i}\n{section}\n\n"
    if include_summary:
        report += "## Summary\n[Auto-generated summary]"
    return report


def main():
    print("=" * 60)
    print("A2A Agent Card Demo")
    print("=" * 60)
    
    # 1. Skill Discovery from Functions
    print("\n1. Discovering skills from functions...")
    print("-" * 40)
    
    discoverer = SkillDiscoverer()
    
    # Discover single skill
    search_skill = discoverer.discover_from_function(search_web)
    print(f"Discovered: {search_skill.name}")
    print(f"  ID: {search_skill.id}")
    print(f"  Description: {search_skill.description}")
    print(f"  Tags: {search_skill.tags}")
    
    # Discover multiple skills
    all_skills = discover_skills([search_web, analyze_data, generate_report])
    print(f"\nTotal skills discovered: {len(all_skills)}")
    for skill in all_skills:
        print(f"  - {skill.id}: {skill.name}")
    
    # 2. Manual Agent Card Creation
    print("\n2. Creating Agent Cards manually...")
    print("-" * 40)
    
    research_card = AgentCard(
        name="research-agent",
        description="An AI agent specialized in research and information gathering",
        url="local://research-agent",
        version="1.0.0",
        capabilities=AgentCapabilities(
            streaming=True,
            push_notifications=False,
            state_transition_history=True,
        ),
        skills=all_skills,
        provider=AgentProvider(
            organization="My Company",
            url="https://mycompany.com",
        ),
        metadata={
            "category": "research",
            "tier": "professional",
        },
    )
    
    print(f"Created: {research_card.name}")
    print(f"  Skills: {len(research_card.skills)}")
    print(f"  Version: {research_card.version}")
    
    # 3. Export/Import Agent Cards
    print("\n3. Exporting and importing cards...")
    print("-" * 40)
    
    # Create output directory
    output_dir = Path("examples/agent_cards")
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Export to JSON
    card_path = output_dir / "research_agent.json"
    json_str = research_card.to_json(card_path)
    print(f"Exported to: {card_path}")
    
    # Import from JSON
    loaded_card = AgentCard.from_json(card_path)
    print(f"Loaded: {loaded_card.name} with {len(loaded_card.skills)} skills")
    
    # 4. Agent Card Registry
    print("\n4. Using Agent Card Registry...")
    print("-" * 40)
    
    registry = AgentCardRegistry()
    
    # Create additional cards
    writer_card = AgentCard(
        name="writer-agent",
        description="An AI agent for content writing",
        url="local://writer-agent",
        skills=[
            AgentSkill(
                id="write-article",
                name="Write Article",
                description="Write articles on various topics",
                tags=["writing", "content-creation"],
            ),
            AgentSkill(
                id="summarize",
                name="Summarize",
                description="Summarize long content",
                tags=["writing", "summarization"],
            ),
        ],
    )
    
    support_card = AgentCard(
        name="support-agent",
        description="Customer support agent",
        url="local://support-agent",
        skills=[
            AgentSkill(
                id="answer-faq",
                name="Answer FAQ",
                description="Answer frequently asked questions",
                tags=["support", "customer-service"],
            ),
            AgentSkill(
                id="troubleshoot",
                name="Troubleshoot",
                description="Troubleshoot technical issues",
                tags=["support", "technical"],
            ),
        ],
    )
    
    # Register all cards
    registry.register(research_card)
    registry.register(writer_card)
    registry.register(support_card)
    
    print(f"Registered {len(registry)} agents")
    
    # Find by skill
    summarizers = registry.find_by_skill("summarize")
    print(f"\nAgents with 'summarize' skill: {[a.name for a in summarizers]}")
    
    # Find by tag
    writing_agents = registry.find_by_tag("writing")
    print(f"Agents with 'writing' tag: {[a.name for a in writing_agents]}")
    
    # Find by capability
    streaming_agents = registry.find_by_capability(streaming=True)
    print(f"Agents with streaming: {[a.name for a in streaming_agents]}")
    
    # Export all cards
    registry.export_all(output_dir)
    print(f"\nExported all cards to: {output_dir}")
    
    # 5. Auto-generation from Agent
    print("\n5. Auto-generating card from agent...")
    print("-" * 40)
    
    config = SystemConfig.from_env()
    pattern = SingleAgentPattern(config)
    
    agent = pattern.create_agent(
        name="demo-assistant",
        system_prompt="You help with research and analysis.",
        tools=[search_web, analyze_data],
    )
    
    auto_card = agent.generate_agent_card()
    print(f"Auto-generated card for: {auto_card.name}")
    print(f"  Skills: {[s.id for s in auto_card.skills]}")
    
    print("\n" + "=" * 60)
    print("Demo complete!")
    print("=" * 60)


if __name__ == "__main__":
    main()
