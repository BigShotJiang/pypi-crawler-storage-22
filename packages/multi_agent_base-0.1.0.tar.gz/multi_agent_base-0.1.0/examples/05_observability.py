"""
Example 5: Full Observability with Phoenix

This example demonstrates complete observability setup with
Arize Phoenix for distributed tracing and structured logging.
"""

import asyncio
from multi_agent_base import SystemConfig, SupervisorPattern
from multi_agent_base.observability import (
    setup_phoenix,
    get_tracer,
    create_logger,
    AgentLogger,
    StreamHandler,
    FileHandler,
    ConsoleFormatter,
    JSONFormatter,
    LogLevel,
    EventType,
)
from multi_agent_base.cost import CostTracker


def search_tool(query: str) -> str:
    """Search for information."""
    return f"Search results for: {query}"


async def main():
    print("=" * 60)
    print("Observability Demo with Arize Phoenix")
    print("=" * 60)
    
    # 1. Set up Phoenix tracing
    print("\n1. Setting up Phoenix tracing...")
    print("-" * 40)
    
    # This will connect to Phoenix at localhost:6006
    # Run `phoenix serve` or use Docker to start Phoenix
    tracer = setup_phoenix(
        endpoint="http://localhost:6006",
        project_name="observability-demo",
        launch_app=False,  # Set to True to auto-launch Phoenix UI
    )
    print("Phoenix tracer configured")
    print("View traces at: http://localhost:6006")
    
    # 2. Set up structured logging
    print("\n2. Setting up structured logging...")
    print("-" * 40)
    
    # Create a logger with multiple handlers
    logger = AgentLogger(handlers=[
        # Console output with colors
        StreamHandler(
            formatter=ConsoleFormatter(colors=True),
            min_level=LogLevel.DEBUG,
        ),
        # JSON file for all events
        FileHandler(
            path="logs/observability_demo.jsonl",
            formatter=JSONFormatter(),
            min_level=LogLevel.DEBUG,
        ),
        # Separate file for errors only
        FileHandler(
            path="logs/errors.jsonl",
            formatter=JSONFormatter(),
            min_level=LogLevel.ERROR,
        ),
    ])
    print("Logger configured with multiple handlers")
    
    # 3. Create cost tracker
    cost_tracker = CostTracker(
        auto_persist=True,
        persist_path="logs/costs.jsonl",
    )
    
    # 4. Create the pattern with observability
    print("\n3. Creating pattern with full observability...")
    print("-" * 40)
    
    config = SystemConfig.from_env()
    pattern = SupervisorPattern(
        config,
        logger=logger,
        cost_tracker=cost_tracker,
    )
    
    # Create a simple team
    pattern.create_team(
        supervisor_name="manager",
        supervisor_prompt="You manage a team. Delegate to worker for tasks.",
        worker_configs=[
            {
                "name": "worker",
                "system_prompt": "You complete tasks assigned to you.",
                "tools": [search_tool],
            },
        ],
    )
    
    # 5. Run with custom tracing
    print("\n4. Running with custom traces...")
    print("-" * 40)
    
    phoenix_tracer = get_tracer()
    
    # Create a custom parent span
    with phoenix_tracer.start_span(
        "full_workflow",
        attributes={
            "workflow.name": "observability_demo",
            "workflow.version": "1.0",
        },
    ) as parent_span:
        
        # Run the pattern
        result = await pattern.run("Search for information about AI agents")
        
        # Add result attributes to span
        if parent_span:
            parent_span.set_attribute("result.length", len(result.content))
            parent_span.set_attribute("result.cost", result.total_cost)
    
    print(f"\nResult: {result.content[:200]}...")
    
    # 6. Manual tracing examples
    print("\n5. Manual tracing examples...")
    print("-" * 40)
    
    # Trace an LLM call
    phoenix_tracer.trace_llm_call(
        model="gpt-4o-mini",
        provider="openai",
        messages=[
            {"role": "user", "content": "Hello"},
        ],
        response="Hi there!",
        usage={"prompt_tokens": 10, "completion_tokens": 5},
        duration_ms=150.0,
    )
    print("Traced LLM call")
    
    # Trace a tool call
    phoenix_tracer.trace_tool_call(
        tool_name="search",
        agent_name="worker",
        arguments={"query": "AI agents"},
        result="Found 10 results",
        duration_ms=200.0,
    )
    print("Traced tool call")
    
    # Trace an agent run
    phoenix_tracer.trace_agent_run(
        agent_name="assistant",
        input_message="What's the weather?",
        output_message="It's sunny today.",
        duration_ms=1500.0,
        tool_calls=[{"name": "get_weather"}],
        usage={"prompt_tokens": 50, "completion_tokens": 20},
        cost=0.001,
    )
    print("Traced agent run")
    
    # 7. Query logged events
    print("\n6. Querying logged events...")
    print("-" * 40)
    
    # Get all events
    all_events = logger.get_events()
    print(f"Total events logged: {len(all_events)}")
    
    # Get events by type
    tool_events = logger.get_events(event_type=EventType.TOOL_CALL)
    print(f"Tool call events: {len(tool_events)}")
    
    # Get events by agent
    manager_events = logger.get_events(agent_name="manager")
    print(f"Manager events: {len(manager_events)}")
    
    # 8. Print cost summary
    print("\n7. Cost Summary...")
    print("-" * 40)
    cost_tracker.print_summary()
    
    print("\n" + "=" * 60)
    print("Demo complete!")
    print("=" * 60)
    print("\nCheck these files for logs:")
    print("  - logs/observability_demo.jsonl")
    print("  - logs/errors.jsonl")
    print("  - logs/costs.jsonl")
    print("\nView Phoenix traces at: http://localhost:6006")


if __name__ == "__main__":
    asyncio.run(main())
