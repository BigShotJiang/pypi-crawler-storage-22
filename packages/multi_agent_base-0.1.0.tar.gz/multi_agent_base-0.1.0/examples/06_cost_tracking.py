"""
Example 6: Cost Tracking and Budget Management

This example demonstrates comprehensive cost tracking
and budget monitoring for LLM usage.
"""

import asyncio
from datetime import datetime, timedelta
from pathlib import Path

from multi_agent_base import SystemConfig, SingleAgentPattern
from multi_agent_base.cost import CostTracker, UsageRecord, CostSummary
from multi_agent_base.providers import PricingCalculator, ModelPricing


async def main():
    print("=" * 60)
    print("Cost Tracking and Budget Management Demo")
    print("=" * 60)
    
    # 1. Basic cost tracking
    print("\n1. Basic Cost Tracking...")
    print("-" * 40)
    
    tracker = CostTracker()
    
    # Record some usage
    tracker.record(
        agent_name="assistant",
        provider="openai",
        model="gpt-4o-mini",
        input_tokens=1000,
        output_tokens=500,
    )
    
    tracker.record(
        agent_name="researcher",
        provider="openai",
        model="gpt-4o",
        input_tokens=2000,
        output_tokens=1000,
    )
    
    tracker.record(
        agent_name="assistant",
        provider="anthropic",
        model="claude-3-5-haiku-20241022",
        input_tokens=500,
        output_tokens=200,
    )
    
    print(f"Recorded {len(tracker)} usage events")
    
    # 2. Get summary
    print("\n2. Cost Summary...")
    print("-" * 40)
    tracker.print_summary()
    
    # 3. Query by agent
    print("\n3. Filter by Agent...")
    print("-" * 40)
    
    assistant_records = tracker.get_records(agent_name="assistant")
    assistant_summary = tracker.get_summary(agent_name="assistant")
    
    print(f"Assistant records: {len(assistant_records)}")
    print(f"Assistant total cost: ${assistant_summary.total_cost:.6f}")
    print(f"Assistant total tokens: {assistant_summary.total_tokens}")
    
    # 4. Pricing calculator
    print("\n4. Pricing Calculator...")
    print("-" * 40)
    
    # Calculate cost for specific usage
    cost = PricingCalculator.calculate(
        provider="openai",
        model="gpt-4o-mini",
        input_tokens=10000,
        output_tokens=5000,
    )
    print(f"Cost for 10K input + 5K output tokens (gpt-4o-mini): ${cost:.6f}")
    
    # Get pricing info
    pricing = PricingCalculator.get_pricing("openai", "gpt-4o")
    print(f"\ngpt-4o pricing:")
    print(f"  Input: ${pricing.input_price}/1M tokens")
    print(f"  Output: ${pricing.output_price}/1M tokens")
    
    # List available models
    openai_models = PricingCalculator.list_models("openai")
    print(f"\nAvailable OpenAI models: {len(openai_models)}")
    for model in openai_models[:5]:
        print(f"  - {model}")
    
    # 5. Custom pricing
    print("\n5. Register Custom Pricing...")
    print("-" * 40)
    
    # Register custom model pricing
    PricingCalculator.register_pricing(
        provider="custom-provider",
        model="custom-model",
        pricing=ModelPricing(
            input_price=0.50,
            output_price=1.50,
            context_window=32000,
        ),
    )
    
    custom_cost = PricingCalculator.calculate(
        provider="custom-provider",
        model="custom-model",
        input_tokens=10000,
        output_tokens=5000,
    )
    print(f"Custom model cost: ${custom_cost:.6f}")
    
    # 6. Export data
    print("\n6. Export Cost Data...")
    print("-" * 40)
    
    output_dir = Path("examples/cost_reports")
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # JSON export
    tracker.export(output_dir / "costs.json", format="json")
    print(f"Exported to: {output_dir / 'costs.json'}")
    
    # CSV export
    tracker.export(output_dir / "costs.csv", format="csv")
    print(f"Exported to: {output_dir / 'costs.csv'}")
    
    # JSONL export
    tracker.export(output_dir / "costs.jsonl", format="jsonl")
    print(f"Exported to: {output_dir / 'costs.jsonl'}")
    
    # 7. Persistence
    print("\n7. Persistent Storage...")
    print("-" * 40)
    
    persistent_tracker = CostTracker(
        auto_persist=True,
        persist_path="examples/cost_reports/persistent_costs.jsonl",
    )
    
    persistent_tracker.record(
        agent_name="persistent-agent",
        provider="ollama",
        model="llama3.2",
        input_tokens=1000,
        output_tokens=500,
    )
    
    print("Records auto-persisted to file")
    
    # 8. Budget monitoring example
    print("\n8. Budget Monitoring Example...")
    print("-" * 40)
    
    DAILY_BUDGET = 1.00  # $1/day
    
    # Simulate today's spending
    budget_tracker = CostTracker()
    
    # Add some usage
    for i in range(10):
        budget_tracker.record(
            agent_name="production-agent",
            provider="openai",
            model="gpt-4o-mini",
            input_tokens=500,
            output_tokens=200,
        )
    
    # Check budget
    today_summary = budget_tracker.get_summary()
    spent = today_summary.total_cost
    remaining = DAILY_BUDGET - spent
    
    print(f"Daily budget: ${DAILY_BUDGET:.2f}")
    print(f"Spent today: ${spent:.6f}")
    print(f"Remaining: ${remaining:.6f}")
    print(f"Budget usage: {(spent/DAILY_BUDGET)*100:.1f}%")
    
    if spent >= DAILY_BUDGET * 0.8:
        print("⚠️  WARNING: Approaching daily budget limit!")
    
    # 9. Cost estimation
    print("\n9. Cost Estimation...")
    print("-" * 40)
    
    # Estimate from character count
    estimated = PricingCalculator.estimate_cost(
        provider="openai",
        model="gpt-4o",
        prompt_chars=10000,  # ~2500 tokens
        expected_output_chars=4000,  # ~1000 tokens
    )
    print(f"Estimated cost for ~10K char prompt + ~4K char output: ${estimated:.6f}")
    
    # 10. Integration with patterns
    print("\n10. Integration with Patterns...")
    print("-" * 40)
    
    config = SystemConfig.from_env()
    integration_tracker = CostTracker()
    
    pattern = SingleAgentPattern(config, cost_tracker=integration_tracker)
    agent = pattern.create_agent(
        name="demo-agent",
        system_prompt="You are helpful.",
    )
    
    # Note: This would need actual LLM calls to track real costs
    print("Cost tracker integrated with pattern")
    print("Costs will be automatically tracked during agent runs")
    
    print("\n" + "=" * 60)
    print("Demo complete!")
    print("=" * 60)
    print(f"\nCost reports saved to: {output_dir}")


if __name__ == "__main__":
    asyncio.run(main())
