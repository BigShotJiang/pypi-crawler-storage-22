"""
Example: Memory Backends

Demonstrates different memory backends for conversation management.
"""

import asyncio
from multi_agent_base.memory import (
    InMemoryBackend,
    BufferMemory,
    SlidingWindowMemory,
    CompositeMemory,
    MemoryEntry,
)


async def basic_memory_example():
    """Basic in-memory storage."""
    print("=" * 60)
    print("1. InMemoryBackend - Basic Storage")
    print("=" * 60)
    
    backend = InMemoryBackend()
    
    # Add messages
    await backend.add(MemoryEntry(role="user", content="Hello!"))
    await backend.add(MemoryEntry(role="assistant", content="Hi! How can I help?"))
    await backend.add(MemoryEntry(role="user", content="Tell me about Python."))
    
    # Retrieve all messages
    messages = await backend.get_all()
    print(f"Stored {len(messages)} messages:")
    for msg in messages:
        print(f"  {msg.role}: {msg.content[:50]}...")
    
    # Get formatted context
    context = await backend.get_context()
    print(f"\nContext for LLM ({len(context)} chars)")


async def buffer_memory_example():
    """Fixed-size buffer that keeps recent messages."""
    print("\n" + "=" * 60)
    print("2. BufferMemory - Fixed Size Buffer")
    print("=" * 60)
    
    # Keep only last 3 messages
    memory = BufferMemory(max_messages=3)
    
    # Add 5 messages
    messages = [
        ("user", "Message 1"),
        ("assistant", "Response 1"),
        ("user", "Message 2"),
        ("assistant", "Response 2"),
        ("user", "Message 3"),
    ]
    
    for role, content in messages:
        await memory.add(MemoryEntry(role=role, content=content))
    
    # Only last 3 remain
    stored = await memory.get_all()
    print(f"Added 5 messages, buffer keeps {len(stored)}:")
    for msg in stored:
        print(f"  {msg.role}: {msg.content}")


async def sliding_window_example():
    """Token-based window management."""
    print("\n" + "=" * 60)
    print("3. SlidingWindowMemory - Token-Based Window")
    print("=" * 60)
    
    # Simple token counter (real implementation should use tiktoken)
    def count_tokens(text: str) -> int:
        return len(text.split())
    
    memory = SlidingWindowMemory(
        max_tokens=50,
        token_counter=count_tokens,
    )
    
    # Add messages
    await memory.add(MemoryEntry(
        role="user", 
        content="Can you explain quantum computing in detail?"
    ))
    await memory.add(MemoryEntry(
        role="assistant",
        content="Quantum computing uses quantum mechanics principles like superposition and entanglement to process information."
    ))
    await memory.add(MemoryEntry(
        role="user",
        content="What about practical applications?"
    ))
    
    # Check token count
    context = await memory.get_context()
    print(f"Context tokens: {count_tokens(context)} (max: 50)")
    print(f"Messages in window: {len(await memory.get_all())}")


async def composite_memory_example():
    """Combining multiple memory backends."""
    print("\n" + "=" * 60)
    print("4. CompositeMemory - Multiple Backends")
    print("=" * 60)
    
    # Combine buffer (recent) + full history
    recent = BufferMemory(max_messages=5)
    full_history = InMemoryBackend()
    
    memory = CompositeMemory(
        backends=[recent, full_history],
        merge_strategy="union",
    )
    
    # Add messages to composite (goes to all backends)
    for i in range(10):
        await memory.add(MemoryEntry(
            role="user" if i % 2 == 0 else "assistant",
            content=f"Message {i + 1}",
        ))
    
    # Check each backend
    recent_msgs = await recent.get_all()
    full_msgs = await full_history.get_all()
    
    print(f"Recent memory: {len(recent_msgs)} messages (last 5)")
    print(f"Full history: {len(full_msgs)} messages (all)")
    
    # Composite search combines results
    all_msgs = await memory.get_all()
    print(f"Composite (union): {len(all_msgs)} unique messages")


async def memory_with_metadata():
    """Using metadata for advanced features."""
    print("\n" + "=" * 60)
    print("5. Memory with Metadata")
    print("=" * 60)
    
    backend = InMemoryBackend()
    
    # Add messages with rich metadata
    await backend.add(MemoryEntry(
        role="user",
        content="Search for Python tutorials",
        metadata={
            "tool_calls": [{"name": "web_search", "args": {"query": "Python tutorials"}}],
            "timestamp": "2024-01-15T10:30:00Z",
            "user_id": "user-123",
        },
    ))
    
    await backend.add(MemoryEntry(
        role="assistant",
        content="I found several Python tutorials for you.",
        metadata={
            "tool_results": [{"name": "web_search", "result": "[...]"}],
            "model": "gpt-4o",
            "tokens": {"prompt": 150, "completion": 50},
        },
    ))
    
    # Retrieve with metadata
    messages = await backend.get_all()
    for msg in messages:
        print(f"{msg.role}: {msg.content}")
        if msg.metadata:
            print(f"  Metadata: {list(msg.metadata.keys())}")


async def main():
    """Run all memory examples."""
    await basic_memory_example()
    await buffer_memory_example()
    await sliding_window_example()
    await composite_memory_example()
    await memory_with_metadata()
    
    print("\n" + "=" * 60)
    print("Memory examples completed!")
    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(main())
