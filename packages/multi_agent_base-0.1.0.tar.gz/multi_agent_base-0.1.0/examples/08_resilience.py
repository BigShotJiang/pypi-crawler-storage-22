"""
Example: Resilience Patterns

Demonstrates fault-tolerance with retry, circuit breaker, timeout, and fallback.
"""

import asyncio
import random
from multi_agent_base.resilience import (
    ResiliencePolicy,
    RetryExecutor,
    CircuitBreaker,
    CircuitState,
    FallbackChain,
    retry_with_backoff,
    with_timeout,
    with_fallback,
)


# Simulated flaky service
class FlakyService:
    def __init__(self, failure_rate: float = 0.5):
        self.failure_rate = failure_rate
        self.call_count = 0
    
    async def call(self, data: str) -> str:
        self.call_count += 1
        await asyncio.sleep(0.1)  # Simulate network delay
        
        if random.random() < self.failure_rate:
            raise ConnectionError(f"Service unavailable (attempt {self.call_count})")
        
        return f"Success: {data}"


async def retry_example():
    """Retry with exponential backoff."""
    print("=" * 60)
    print("1. Retry with Exponential Backoff")
    print("=" * 60)
    
    service = FlakyService(failure_rate=0.7)  # 70% failure
    
    @retry_with_backoff(
        max_attempts=5,
        base_delay=0.2,
        max_delay=2.0,
        retryable_exceptions=[ConnectionError],
    )
    async def call_with_retry(data: str) -> str:
        return await service.call(data)
    
    try:
        result = await call_with_retry("test data")
        print(f"✓ Result: {result}")
        print(f"  Total attempts: {service.call_count}")
    except ConnectionError as e:
        print(f"✗ All retries failed after {service.call_count} attempts")


async def circuit_breaker_example():
    """Circuit breaker pattern."""
    print("\n" + "=" * 60)
    print("2. Circuit Breaker")
    print("=" * 60)
    
    breaker = CircuitBreaker(
        failure_threshold=3,     # Open after 3 failures
        recovery_timeout=2.0,    # Try again after 2 seconds
        half_open_max_calls=2,   # Test with 2 calls
    )
    
    service = FlakyService(failure_rate=0.9)  # 90% failure
    
    async def call_with_breaker():
        async with breaker:
            return await service.call("data")
    
    # Make calls until circuit opens
    for i in range(10):
        try:
            result = await call_with_breaker()
            print(f"  Call {i+1}: ✓ {result}")
        except ConnectionError:
            print(f"  Call {i+1}: ✗ Service failed, state={breaker.state.value}")
        except Exception as e:
            print(f"  Call {i+1}: ⚡ Circuit OPEN - {e}")
        
        if breaker.state == CircuitState.OPEN:
            print(f"\n  Circuit is OPEN! Waiting for recovery...")
            await asyncio.sleep(2.5)  # Wait for recovery timeout
            print(f"  Circuit is now: {breaker.state.value}")
            break


async def timeout_example():
    """Timeout handling."""
    print("\n" + "=" * 60)
    print("3. Timeout Handling")
    print("=" * 60)
    
    @with_timeout(seconds=0.5)
    async def slow_operation():
        await asyncio.sleep(1.0)  # Takes 1 second
        return "completed"
    
    @with_timeout(seconds=2.0)
    async def fast_operation():
        await asyncio.sleep(0.1)  # Takes 0.1 second
        return "completed"
    
    # Slow operation times out
    try:
        result = await slow_operation()
        print(f"Slow operation: {result}")
    except asyncio.TimeoutError:
        print("✗ Slow operation timed out (as expected)")
    
    # Fast operation succeeds
    try:
        result = await fast_operation()
        print(f"✓ Fast operation: {result}")
    except asyncio.TimeoutError:
        print("Fast operation timed out")


async def fallback_example():
    """Fallback chain."""
    print("\n" + "=" * 60)
    print("4. Fallback Chain")
    print("=" * 60)
    
    # Primary always fails
    async def primary_service():
        raise ConnectionError("Primary service down")
    
    # Secondary sometimes fails
    secondary_attempts = [0]
    async def secondary_service():
        secondary_attempts[0] += 1
        if secondary_attempts[0] < 2:
            raise ConnectionError("Secondary service down")
        return "Response from secondary"
    
    # Fallback always succeeds
    async def cached_response():
        return "Cached response (fallback)"
    
    chain = FallbackChain([
        primary_service,
        secondary_service,
        cached_response,
    ])
    
    # First call: primary fails, secondary fails, cache succeeds
    result = await chain.execute()
    print(f"First call: {result}")
    
    # Second call: primary fails, secondary succeeds
    secondary_attempts[0] = 1  # Reset but already tried once
    result = await chain.execute()
    print(f"Second call: {result}")


async def combined_resilience():
    """Combining all patterns."""
    print("\n" + "=" * 60)
    print("5. Combined Resilience Policy")
    print("=" * 60)
    
    service = FlakyService(failure_rate=0.5)
    
    # Create comprehensive policy
    policy = ResiliencePolicy(
        retry=RetryExecutor(max_attempts=3, base_delay=0.2),
        circuit_breaker=CircuitBreaker(failure_threshold=5),
        timeout_seconds=5.0,
        fallback=FallbackChain([
            lambda: service.call("fallback_data"),
            lambda: asyncio.sleep(0) or "default_response",
        ]),
    )
    
    async def risky_operation():
        return await service.call("important_data")
    
    # Execute with full resilience
    for i in range(5):
        try:
            result = await policy.execute(risky_operation)
            print(f"  Call {i+1}: ✓ {result}")
        except Exception as e:
            print(f"  Call {i+1}: ✗ {e}")


async def with_fallback_decorator_example():
    """Using fallback decorator."""
    print("\n" + "=" * 60)
    print("6. @with_fallback Decorator")
    print("=" * 60)
    
    async def fallback_handler(error: Exception) -> str:
        return f"Fallback response (error was: {type(error).__name__})"
    
    @with_fallback(fallback_handler)
    async def maybe_fails():
        if random.random() > 0.5:
            raise ValueError("Random failure")
        return "Success!"
    
    for i in range(5):
        result = await maybe_fails()
        print(f"  Call {i+1}: {result}")


async def main():
    """Run all resilience examples."""
    await retry_example()
    await circuit_breaker_example()
    await timeout_example()
    await fallback_example()
    await combined_resilience()
    await with_fallback_decorator_example()
    
    print("\n" + "=" * 60)
    print("Resilience examples completed!")
    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(main())
