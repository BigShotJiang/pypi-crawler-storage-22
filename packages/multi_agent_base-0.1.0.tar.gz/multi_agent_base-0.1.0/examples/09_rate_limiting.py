"""
Example: Rate Limiting

Demonstrates rate limiting for API calls with different algorithms.
"""

import asyncio
import time
from multi_agent_base.ratelimit import (
    RateLimitConfig,
    TokenBucketLimiter,
    SlidingWindowLimiter,
    CompositeRateLimiter,
    ProviderRateLimits,
    RateLimitExceeded,
    rate_limit,
    with_rate_limit,
)


async def token_bucket_example():
    """Token bucket algorithm with bursting."""
    print("=" * 60)
    print("1. Token Bucket Limiter")
    print("=" * 60)
    
    limiter = TokenBucketLimiter(RateLimitConfig(
        requests_per_second=5,
        burst_multiplier=2.0,  # Allow burst up to 10
        wait_on_limit=True,
    ))
    
    print(f"Rate: 5 req/sec, Burst: 10 requests")
    print(f"Initial tokens: {limiter.get_remaining():.1f}")
    
    # Burst 8 requests
    start = time.monotonic()
    for i in range(8):
        await limiter.acquire()
        print(f"  Request {i+1} at {time.monotonic()-start:.2f}s, remaining: {limiter.get_remaining():.1f}")
    
    # Next requests will wait
    print("\nBurst exhausted, next requests will wait...")
    for i in range(3):
        await limiter.acquire()
        print(f"  Request {9+i} at {time.monotonic()-start:.2f}s")


async def sliding_window_example():
    """Sliding window algorithm."""
    print("\n" + "=" * 60)
    print("2. Sliding Window Limiter")
    print("=" * 60)
    
    limiter = SlidingWindowLimiter(RateLimitConfig(
        requests_per_minute=10,
        wait_on_limit=False,  # Raise exception instead
    ))
    
    print(f"Rate: 10 req/min")
    
    # Make 10 requests (should all succeed)
    successes = 0
    for i in range(12):
        try:
            await limiter.acquire()
            successes += 1
            print(f"  Request {i+1}: ✓")
        except RateLimitExceeded as e:
            print(f"  Request {i+1}: ✗ Rate limited, retry after {e.retry_after:.1f}s")
    
    print(f"\nSuccessful: {successes}/12")


async def composite_limiter_example():
    """Combining multiple limiters."""
    print("\n" + "=" * 60)
    print("3. Composite Rate Limiter")
    print("=" * 60)
    
    # Per-second and per-minute limits
    per_second = TokenBucketLimiter(RateLimitConfig(
        requests_per_second=3,
        burst_multiplier=1.0,
        wait_on_limit=False,
    ))
    
    per_minute = SlidingWindowLimiter(RateLimitConfig(
        requests_per_minute=10,
        wait_on_limit=False,
    ))
    
    composite = CompositeRateLimiter([per_second, per_minute])
    
    print("Limits: 3/second AND 10/minute")
    
    # Try rapid requests
    for i in range(15):
        try:
            await composite.acquire()
            print(f"  Request {i+1}: ✓")
        except RateLimitExceeded as e:
            print(f"  Request {i+1}: ✗ Limited (retry: {e.retry_after:.1f}s)")
            await asyncio.sleep(0.5)  # Wait a bit


async def decorator_example():
    """Rate limiting with decorators."""
    print("\n" + "=" * 60)
    print("4. Rate Limit Decorators")
    print("=" * 60)
    
    call_count = [0]
    
    @rate_limit(requests_per_second=5, wait_on_limit=True)
    async def limited_api_call():
        call_count[0] += 1
        return f"Response #{call_count[0]}"
    
    print("Making 10 calls with 5/second limit...")
    start = time.monotonic()
    
    results = []
    for _ in range(10):
        result = await limited_api_call()
        results.append(result)
    
    elapsed = time.monotonic() - start
    print(f"  Completed {len(results)} calls in {elapsed:.2f}s")
    print(f"  Effective rate: {len(results)/elapsed:.1f} req/sec")


async def shared_limiter_example():
    """Sharing limiter across functions."""
    print("\n" + "=" * 60)
    print("5. Shared Rate Limiter")
    print("=" * 60)
    
    # Shared limiter for an API
    api_limiter = TokenBucketLimiter(RateLimitConfig(
        requests_per_second=3,
        burst_multiplier=1.5,
        wait_on_limit=True,
    ))
    
    @with_rate_limit(api_limiter)
    async def get_user(user_id: int):
        await asyncio.sleep(0.05)
        return f"User {user_id}"
    
    @with_rate_limit(api_limiter)
    async def get_posts(user_id: int):
        await asyncio.sleep(0.05)
        return f"Posts for {user_id}"
    
    print("Two functions sharing 3/second limit...")
    start = time.monotonic()
    
    # Interleaved calls
    for i in range(3):
        user = await get_user(i)
        posts = await get_posts(i)
        print(f"  {time.monotonic()-start:.2f}s: {user}, {posts}")


async def provider_limits_example():
    """Using pre-configured provider limits."""
    print("\n" + "=" * 60)
    print("6. Provider-Specific Limits")
    print("=" * 60)
    
    # Get default limits
    providers = ["openai", "anthropic", "ollama"]
    
    for provider in providers:
        limits = ProviderRateLimits.get(provider)
        print(f"  {provider.upper()}:")
        print(f"    RPM: {limits.requests_per_minute}")
        print(f"    TPM: {limits.tokens_per_minute or 'N/A'}")
    
    # Register custom provider
    ProviderRateLimits.register("my_api", RateLimitConfig(
        requests_per_minute=1000,
        tokens_per_minute=500000,
    ))
    
    custom = ProviderRateLimits.get("my_api")
    print(f"\n  MY_API (custom):")
    print(f"    RPM: {custom.requests_per_minute}")
    print(f"    TPM: {custom.tokens_per_minute}")


async def wait_vs_fail_example():
    """Comparing wait and fail behaviors."""
    print("\n" + "=" * 60)
    print("7. Wait vs Fail Behavior")
    print("=" * 60)
    
    # Wait on limit
    wait_limiter = TokenBucketLimiter(RateLimitConfig(
        requests_per_second=2,
        burst_multiplier=1.0,
        wait_on_limit=True,
    ))
    
    # Fail on limit
    fail_limiter = TokenBucketLimiter(RateLimitConfig(
        requests_per_second=2,
        burst_multiplier=1.0,
        wait_on_limit=False,
    ))
    
    # Wait behavior
    print("Wait behavior (requests_per_second=2):")
    start = time.monotonic()
    for i in range(4):
        await wait_limiter.acquire()
        print(f"  Request {i+1} at {time.monotonic()-start:.2f}s")
    
    # Fail behavior
    print("\nFail behavior (requests_per_second=2):")
    for i in range(4):
        try:
            await fail_limiter.acquire()
            print(f"  Request {i+1}: ✓")
        except RateLimitExceeded as e:
            print(f"  Request {i+1}: ✗ Retry after {e.retry_after:.2f}s")


async def main():
    """Run all rate limiting examples."""
    await token_bucket_example()
    await sliding_window_example()
    await composite_limiter_example()
    await decorator_example()
    await shared_limiter_example()
    await provider_limits_example()
    await wait_vs_fail_example()
    
    print("\n" + "=" * 60)
    print("Rate limiting examples completed!")
    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(main())
