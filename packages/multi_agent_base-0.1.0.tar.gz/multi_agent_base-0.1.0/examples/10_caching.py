"""
Example: Caching

Demonstrates response caching to reduce API calls and improve performance.
"""

import asyncio
import time
import hashlib
from multi_agent_base.cache import (
    CacheConfig,
    InMemoryCache,
    TTLCache,
    SemanticCache,
    cached,
    cache_response,
)


async def basic_cache_example():
    """Basic in-memory caching."""
    print("=" * 60)
    print("1. Basic In-Memory Cache")
    print("=" * 60)
    
    cache = InMemoryCache(CacheConfig(
        max_size=100,
        ttl_seconds=60,
    ))
    
    # Set values
    await cache.set("greeting", "Hello, World!")
    await cache.set("farewell", "Goodbye!")
    
    # Get values
    greeting = await cache.get("greeting")
    print(f"  greeting: {greeting}")
    
    # Check existence
    exists = await cache.exists("greeting")
    print(f"  exists: {exists}")
    
    # Delete
    await cache.delete("greeting")
    exists = await cache.exists("greeting")
    print(f"  after delete: {exists}")
    
    # Clear all
    await cache.clear()
    print(f"  after clear: {await cache.exists('farewell')}")


async def ttl_cache_example():
    """Time-based cache expiration."""
    print("\n" + "=" * 60)
    print("2. TTL Cache (Time-Based Expiration)")
    print("=" * 60)
    
    cache = TTLCache(
        default_ttl=2,  # 2 seconds
        cleanup_interval=1,
    )
    
    # Set with default TTL
    await cache.set("short_lived", "I expire in 2s")
    
    # Set with custom TTL
    await cache.set("long_lived", "I expire in 10s", ttl=10)
    
    print("  Immediately after setting:")
    print(f"    short_lived: {await cache.get('short_lived')}")
    print(f"    long_lived: {await cache.get('long_lived')}")
    
    # Wait for short TTL to expire
    print("\n  After 3 seconds:")
    await asyncio.sleep(3)
    print(f"    short_lived: {await cache.get('short_lived')}")
    print(f"    long_lived: {await cache.get('long_lived')}")


async def lru_eviction_example():
    """LRU eviction when cache is full."""
    print("\n" + "=" * 60)
    print("3. LRU Eviction")
    print("=" * 60)
    
    cache = InMemoryCache(CacheConfig(
        max_size=3,  # Only 3 items
    ))
    
    # Fill cache
    await cache.set("a", "first")
    await cache.set("b", "second")
    await cache.set("c", "third")
    
    print("  Cache full (max=3):")
    print(f"    a: {await cache.get('a')}, b: {await cache.get('b')}, c: {await cache.get('c')}")
    
    # Access 'a' to make it recently used
    _ = await cache.get("a")
    
    # Add new item - should evict 'b' (least recently used)
    await cache.set("d", "fourth")
    
    print("\n  After adding 'd' (accessed 'a' before):")
    print(f"    a: {await cache.get('a')}")  # Still exists (recently used)
    print(f"    b: {await cache.get('b')}")  # Evicted
    print(f"    c: {await cache.get('c')}")  # Still exists
    print(f"    d: {await cache.get('d')}")  # New item


async def cache_stats_example():
    """Monitoring cache performance."""
    print("\n" + "=" * 60)
    print("4. Cache Statistics")
    print("=" * 60)
    
    cache = InMemoryCache(CacheConfig(max_size=100))
    
    # Populate cache
    await cache.set("key1", "value1")
    await cache.set("key2", "value2")
    
    # Some hits and misses
    await cache.get("key1")  # Hit
    await cache.get("key1")  # Hit
    await cache.get("key2")  # Hit
    await cache.get("key3")  # Miss
    await cache.get("key4")  # Miss
    
    stats = cache.stats()
    print(f"  Hits: {stats['hits']}")
    print(f"  Misses: {stats['misses']}")
    print(f"  Hit Rate: {stats['hit_rate']:.1%}")
    print(f"  Size: {stats['size']}/{stats['max_size']}")


async def cached_decorator_example():
    """Using @cached decorator."""
    print("\n" + "=" * 60)
    print("5. @cached Decorator")
    print("=" * 60)
    
    call_count = [0]
    
    @cached(ttl=60)
    async def expensive_computation(n: int) -> int:
        call_count[0] += 1
        await asyncio.sleep(0.5)  # Simulate slow operation
        return n * n
    
    # First call - executes function
    start = time.monotonic()
    result1 = await expensive_computation(5)
    print(f"  First call: {result1} ({time.monotonic()-start:.2f}s)")
    
    # Second call - returns cached
    start = time.monotonic()
    result2 = await expensive_computation(5)
    print(f"  Second call: {result2} ({time.monotonic()-start:.4f}s) [cached]")
    
    # Different argument - executes function
    start = time.monotonic()
    result3 = await expensive_computation(10)
    print(f"  Different arg: {result3} ({time.monotonic()-start:.2f}s)")
    
    print(f"\n  Total function executions: {call_count[0]}")


async def custom_cache_key_example():
    """Custom cache key generation."""
    print("\n" + "=" * 60)
    print("6. Custom Cache Keys")
    print("=" * 60)
    
    def user_aware_key(query: str, user_id: str) -> str:
        """Cache per user."""
        return f"{user_id}:{hashlib.md5(query.encode()).hexdigest()[:8]}"
    
    @cached(ttl=60, key_fn=user_aware_key)
    async def personalized_response(query: str, user_id: str) -> str:
        return f"Response for {user_id}: {query}"
    
    # Same query, different users
    r1 = await personalized_response("Hello", "user1")
    r2 = await personalized_response("Hello", "user2")
    
    print(f"  User1: {r1}")
    print(f"  User2: {r2}")
    
    # Same user, same query - cached
    r3 = await personalized_response("Hello", "user1")
    print(f"  User1 again: {r3} [cached]")


async def semantic_cache_example():
    """Semantic caching with embeddings."""
    print("\n" + "=" * 60)
    print("7. Semantic Cache (Similarity-Based)")
    print("=" * 60)
    
    # Simple embedding function (in reality, use OpenAI/sentence-transformers)
    def simple_embedding(text: str) -> list[float]:
        """Fake embedding based on word presence."""
        words = ["python", "programming", "code", "language", "learn"]
        text_lower = text.lower()
        return [1.0 if w in text_lower else 0.0 for w in words]
    
    cache = SemanticCache(
        embedding_fn=simple_embedding,
        similarity_threshold=0.8,
    )
    
    # Cache a response
    await cache.set(
        "What is Python programming?",
        "Python is a high-level programming language..."
    )
    
    # Exact match
    result = await cache.get("What is Python programming?")
    print(f"  Exact match: {result[:50] if result else 'None'}...")
    
    # Similar query (should hit cache)
    result = await cache.get("Tell me about Python programming language")
    print(f"  Similar query: {result[:50] if result else 'None'}...")
    
    # Different query (should miss)
    result = await cache.get("What is the weather today?")
    print(f"  Different query: {result or 'Cache miss'}")


async def cache_with_agent_simulation():
    """Simulating cache with LLM agent."""
    print("\n" + "=" * 60)
    print("8. LLM Response Caching Simulation")
    print("=" * 60)
    
    cache = InMemoryCache(CacheConfig(max_size=1000))
    api_calls = [0]
    
    async def simulate_llm_call(prompt: str) -> str:
        """Simulate expensive LLM API call."""
        api_calls[0] += 1
        await asyncio.sleep(0.2)  # Simulate latency
        return f"Generated response for: {prompt[:20]}..."
    
    async def cached_llm_call(prompt: str) -> str:
        """LLM call with caching."""
        # Create cache key
        key = hashlib.md5(prompt.encode()).hexdigest()
        
        # Check cache
        cached = await cache.get(key)
        if cached:
            return f"[CACHED] {cached}"
        
        # Call LLM
        response = await simulate_llm_call(prompt)
        
        # Cache response
        await cache.set(key, response)
        
        return response
    
    prompts = [
        "Explain quantum computing",
        "What is machine learning?",
        "Explain quantum computing",  # Duplicate
        "Tell me about Python",
        "What is machine learning?",  # Duplicate
    ]
    
    for prompt in prompts:
        start = time.monotonic()
        result = await cached_llm_call(prompt)
        elapsed = time.monotonic() - start
        print(f"  [{elapsed:.3f}s] {result[:50]}")
    
    print(f"\n  Total API calls: {api_calls[0]} (saved {len(prompts) - api_calls[0]})")


async def main():
    """Run all caching examples."""
    await basic_cache_example()
    await ttl_cache_example()
    await lru_eviction_example()
    await cache_stats_example()
    await cached_decorator_example()
    await custom_cache_key_example()
    await semantic_cache_example()
    await cache_with_agent_simulation()
    
    print("\n" + "=" * 60)
    print("Caching examples completed!")
    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(main())
