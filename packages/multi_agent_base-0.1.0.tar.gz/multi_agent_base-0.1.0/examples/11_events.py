"""
Example: Events and Hooks

Demonstrates the event system for agent lifecycle management.
"""

import asyncio
from datetime import datetime
from multi_agent_base.events import (
    Event,
    EventBus,
    EventPriority,
    LifecycleHooks,
    HookType,
    HookContext,
    on_event,
)


async def basic_event_bus():
    """Basic event publishing and subscription."""
    print("=" * 60)
    print("1. Basic Event Bus")
    print("=" * 60)
    
    bus = EventBus()
    received_events = []
    
    # Subscribe to events
    @bus.subscribe("user.message")
    async def handle_message(event: Event):
        received_events.append(event)
        print(f"  Received: {event.name} - {event.data}")
    
    # Publish events
    await bus.publish(Event(
        name="user.message",
        data={"content": "Hello!", "user_id": "123"},
    ))
    
    await bus.publish(Event(
        name="user.message",
        data={"content": "How are you?", "user_id": "123"},
    ))
    
    print(f"  Total events received: {len(received_events)}")


async def event_priorities():
    """Handler priority ordering."""
    print("\n" + "=" * 60)
    print("2. Event Priorities")
    print("=" * 60)
    
    bus = EventBus()
    execution_order = []
    
    @bus.subscribe("request", priority=EventPriority.LOW)
    async def metrics_handler(event):
        execution_order.append("metrics")
        print("  [LOW] Metrics recorded")
    
    @bus.subscribe("request", priority=EventPriority.NORMAL)
    async def business_logic(event):
        execution_order.append("business")
        print("  [NORMAL] Business logic executed")
    
    @bus.subscribe("request", priority=EventPriority.HIGH)
    async def validation(event):
        execution_order.append("validation")
        print("  [HIGH] Input validated")
    
    @bus.subscribe("request", priority=EventPriority.CRITICAL)
    async def security_check(event):
        execution_order.append("security")
        print("  [CRITICAL] Security checked")
    
    await bus.publish(Event(name="request", data={}))
    
    print(f"\n  Execution order: {' → '.join(execution_order)}")


async def stop_propagation():
    """Stopping event propagation."""
    print("\n" + "=" * 60)
    print("3. Stop Propagation")
    print("=" * 60)
    
    bus = EventBus()
    
    @bus.subscribe("action", priority=EventPriority.HIGH)
    async def security_gate(event: Event):
        if event.data.get("blocked"):
            print("  ⛔ Security: Request blocked!")
            event.stop_propagation()
        else:
            print("  ✓ Security: Request allowed")
    
    @bus.subscribe("action", priority=EventPriority.NORMAL)
    async def process_action(event: Event):
        print("  → Processing action...")
    
    # Allowed request
    print("  Request 1 (allowed):")
    await bus.publish(Event(name="action", data={"blocked": False}))
    
    # Blocked request
    print("\n  Request 2 (blocked):")
    await bus.publish(Event(name="action", data={"blocked": True}))


async def once_handler():
    """One-time event handlers."""
    print("\n" + "=" * 60)
    print("4. One-Time Handlers")
    print("=" * 60)
    
    bus = EventBus()
    init_count = [0]
    
    @bus.once("system.ready")
    async def on_system_ready(event):
        init_count[0] += 1
        print(f"  System initialized (call #{init_count[0]})")
    
    # First publish - handler runs
    await bus.publish(Event(name="system.ready", data={}))
    
    # Second publish - handler already removed
    await bus.publish(Event(name="system.ready", data={}))
    
    print(f"  Handler ran {init_count[0]} time(s)")


async def global_handler():
    """Handling all events."""
    print("\n" + "=" * 60)
    print("5. Global Event Handler")
    print("=" * 60)
    
    bus = EventBus()
    all_events = []
    
    @bus.subscribe("*")  # Match all events
    async def audit_log(event: Event):
        all_events.append(event.name)
        print(f"  [AUDIT] {event.name}: {event.data}")
    
    # Publish various events
    await bus.publish(Event(name="user.login", data={"user": "alice"}))
    await bus.publish(Event(name="agent.start", data={"agent": "bot1"}))
    await bus.publish(Event(name="tool.execute", data={"tool": "search"}))
    
    print(f"\n  Captured events: {all_events}")


async def lifecycle_hooks():
    """Agent lifecycle hooks."""
    print("\n" + "=" * 60)
    print("6. Lifecycle Hooks")
    print("=" * 60)
    
    hooks = LifecycleHooks()
    timings = {}
    
    @hooks.register(HookType.BEFORE_RUN)
    async def start_timer(ctx: HookContext):
        timings["start"] = datetime.now()
        print(f"  [BEFORE_RUN] Input: {ctx.data.get('input', '')[:30]}...")
    
    @hooks.register(HookType.AFTER_RUN)
    async def end_timer(ctx: HookContext):
        timings["end"] = datetime.now()
        duration = (timings["end"] - timings["start"]).total_seconds()
        print(f"  [AFTER_RUN] Output: {ctx.data.get('output', '')[:30]}... ({duration:.2f}s)")
    
    @hooks.register(HookType.ON_ERROR)
    async def log_error(ctx: HookContext):
        print(f"  [ON_ERROR] {ctx.data.get('error')}")
    
    # Simulate agent run
    print("  Simulating agent run...")
    await hooks.execute(HookType.BEFORE_RUN, {"input": "What is the meaning of life?"})
    await asyncio.sleep(0.1)  # Simulate processing
    await hooks.execute(HookType.AFTER_RUN, {"output": "The meaning of life is 42."})


async def hook_cancellation():
    """Cancelling operations from hooks."""
    print("\n" + "=" * 60)
    print("7. Hook Cancellation")
    print("=" * 60)
    
    hooks = LifecycleHooks()
    
    @hooks.register(HookType.BEFORE_RUN)
    async def content_filter(ctx: HookContext):
        input_text = ctx.data.get("input", "")
        if "banned" in input_text.lower():
            ctx.cancel("Content policy violation")
            print("  ⛔ Content filter: Cancelled!")
        else:
            print("  ✓ Content filter: Passed")
    
    # Allowed input
    print("  Input 1: 'Hello world'")
    ctx1 = HookContext(data={"input": "Hello world"})
    await hooks.execute(HookType.BEFORE_RUN, ctx1.data)
    print(f"    Cancelled: {ctx1.cancelled}")
    
    # Blocked input
    print("\n  Input 2: 'This is banned content'")
    ctx2 = HookContext(data={"input": "This is banned content"})
    await hooks.execute(HookType.BEFORE_RUN, ctx2.data)
    print(f"    Cancelled: {ctx2.cancelled}")


async def event_history():
    """Accessing event history."""
    print("\n" + "=" * 60)
    print("8. Event History")
    print("=" * 60)
    
    bus = EventBus(keep_history=True, max_history=100)
    
    # Publish some events
    for i in range(5):
        await bus.publish(Event(
            name="action",
            data={"step": i + 1},
        ))
    
    # Query history
    history = bus.get_history(event_name="action", limit=3)
    
    print(f"  Total events in history: {len(bus.get_history())}")
    print(f"  Last 3 'action' events:")
    for event in history:
        print(f"    - Step {event.data['step']} at {event.timestamp}")


async def subscriber_management():
    """Managing subscriptions."""
    print("\n" + "=" * 60)
    print("9. Subscriber Management")
    print("=" * 60)
    
    bus = EventBus()
    
    async def handler_a(event):
        print("    Handler A")
    
    async def handler_b(event):
        print("    Handler B")
    
    # Subscribe
    bus.subscribe("test")(handler_a)
    bus.subscribe("test")(handler_b)
    
    print("  Before unsubscribe:")
    await bus.publish(Event(name="test", data={}))
    
    # Unsubscribe one handler
    bus.unsubscribe("test", handler_a)
    
    print("\n  After unsubscribing handler_a:")
    await bus.publish(Event(name="test", data={}))
    
    print(f"\n  Active subscribers for 'test': {bus.subscriber_count('test')}")


async def complete_workflow():
    """Complete workflow with events and hooks."""
    print("\n" + "=" * 60)
    print("10. Complete Agent Workflow")
    print("=" * 60)
    
    bus = EventBus(keep_history=True)
    hooks = LifecycleHooks()
    
    # Set up monitoring
    @bus.subscribe("*")
    async def monitor(event):
        pass  # Silent monitoring
    
    @hooks.register(HookType.BEFORE_RUN)
    async def validate_input(ctx):
        print("  → Validating input...")
        await bus.publish(Event(name="validation.start", data=ctx.data))
    
    @hooks.register(HookType.AFTER_RUN)
    async def record_metrics(ctx):
        print("  → Recording metrics...")
        await bus.publish(Event(name="metrics.recorded", data={
            "tokens": 150,
            "latency_ms": 500,
        }))
    
    # Simulate complete workflow
    print("  Agent workflow simulation:")
    
    # Before run
    await hooks.execute(HookType.BEFORE_RUN, {"input": "Hello"})
    
    # Agent processing...
    await asyncio.sleep(0.1)
    await bus.publish(Event(name="agent.processing", data={}))
    
    # After run
    await hooks.execute(HookType.AFTER_RUN, {"output": "Hi there!"})
    
    # Summary
    history = bus.get_history()
    print(f"\n  Events recorded: {len(history)}")
    for event in history:
        print(f"    - {event.name}")


async def main():
    """Run all event examples."""
    await basic_event_bus()
    await event_priorities()
    await stop_propagation()
    await once_handler()
    await global_handler()
    await lifecycle_hooks()
    await hook_cancellation()
    await event_history()
    await subscriber_management()
    await complete_workflow()
    
    print("\n" + "=" * 60)
    print("Events and hooks examples completed!")
    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(main())
