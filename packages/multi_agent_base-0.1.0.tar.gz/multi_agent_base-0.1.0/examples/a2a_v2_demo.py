#!/usr/bin/env python3
"""
A2A Protocol v2 Demo

Demonstrates the A2A Protocol v2 features:
- HTTP Server/Client for agent discovery
- Conversation threading with context
- Standardized error handling
"""

import asyncio
from datetime import datetime

from multi_agent_base.a2a import (
    # Agent Card
    AgentCard,
    AgentSkill,
    AgentCapabilities,
    # HTTP
    A2AServer,
    A2AServerConfig,
    A2AClient,
    A2ARegistry,
    # Threading
    ConversationThread,
    ThreadMessage,
    ThreadContext,
    ThreadManager,
    ThreadState,
    MessageRole,
    MessageStatus,
    # Errors
    A2AError,
    A2AErrorCode,
    A2AErrorDetails,
    A2AErrorHandler,
    A2ADiscoveryError,
    A2AConnectionError,
    A2ATimeoutError,
    A2AAuthenticationError,
    A2ARateLimitError,
)


def print_section(title: str) -> None:
    """Print a section header."""
    print(f"\n{'=' * 60}")
    print(f"  {title}")
    print(f"{'=' * 60}\n")


def print_subsection(title: str) -> None:
    """Print a subsection header."""
    print(f"\n--- {title} ---\n")


async def demo_http_server_client():
    """Demonstrate HTTP server and client functionality."""
    print_section("HTTP Server & Client Demo")
    
    # Create agent cards for different agents
    translator = AgentCard(
        name="translator-agent",
        description="A multilingual translation agent supporting 50+ languages",
        url="http://localhost:8080",
        skills=[
            AgentSkill(
                id="translate",
                name="Translate",
                description="Translate text between languages",
                tags=["nlp", "translation", "multilingual"],
            ),
            AgentSkill(
                id="detect-language",
                name="Detect Language",
                description="Detect the language of input text",
                tags=["nlp", "language-detection"],
            ),
        ],
    )
    
    summarizer = AgentCard(
        name="summarizer-agent",
        description="An intelligent text summarization agent",
        url="http://localhost:8081",
        skills=[
            AgentSkill(
                id="summarize",
                name="Summarize",
                description="Create concise summaries of long texts",
                tags=["nlp", "summarization"],
            ),
            AgentSkill(
                id="extract-key-points",
                name="Extract Key Points",
                description="Extract key points from documents",
                tags=["nlp", "extraction"],
            ),
        ],
    )
    
    # Create server for translator
    print_subsection("Creating A2A Server")
    
    config = A2AServerConfig(
        host="0.0.0.0",
        port=8080,
        agent_card=translator,
        enable_discovery=True,
    )
    server = A2AServer(config)
    
    print(f"Server configured for: {translator.name}")
    print(f"Endpoint: http://{config.host}:{config.port}")
    print(f"Routes: {server.get_routes()}")
    
    # Start server
    await server.start()
    print(f"Server running: {server.is_running}")
    
    # Test endpoints
    print_subsection("Testing Server Endpoints")
    
    # Health check
    response = await server.handle_request("GET", "/health")
    print(f"Health check: {response}")
    
    # Agent card
    response = await server.handle_request("GET", "/.well-known/agent-card.json")
    print(f"Agent card status: {response['status']}")
    print(f"Agent name: {response['body']['name']}")
    
    # Discovery
    response = await server.handle_request("GET", "/a2a/discover")
    print(f"Discovery info: {response['body']}")
    
    # A2A Client
    print_subsection("A2A Client Operations")
    
    client = A2AClient(timeout=30.0, retry_count=3)
    print(f"Client timeout: {client.timeout}s")
    print(f"Client retry count: {client.retry_count}")
    
    # Cache card manually (since we don't have real HTTP)
    client.cache_card("http://localhost:8080", translator)
    client.cache_card("http://localhost:8081", summarizer)
    
    # Get skills
    skill = client.get_skill(translator, "translate")
    print(f"Found skill: {skill.name} - {skill.description}")
    
    nlp_skills = client.get_skills_by_tag(translator, "nlp")
    print(f"NLP skills: {[s.name for s in nlp_skills]}")
    
    # Stop server
    await server.stop()
    print(f"\nServer stopped: {not server.is_running}")


async def demo_registry():
    """Demonstrate agent registry functionality."""
    print_section("Agent Registry Demo")
    
    # Create agents with various skills
    agents = [
        AgentCard(
            name="translator",
            description="Translation agent",
            url="http://localhost:8080",
            skills=[
                AgentSkill(id="translate", name="Translate", description="Translate text"),
            ],
        ),
        AgentCard(
            name="summarizer",
            description="Summarization agent",
            url="http://localhost:8081",
            skills=[
                AgentSkill(id="summarize", name="Summarize", description="Summarize text"),
            ],
        ),
        AgentCard(
            name="analyst",
            description="Data analysis agent",
            url="http://localhost:8082",
            skills=[
                AgentSkill(id="analyze", name="Analyze", description="Analyze data"),
                AgentSkill(id="visualize", name="Visualize", description="Create charts"),
            ],
        ),
        AgentCard(
            name="polyglot",
            description="Multi-skill agent",
            url="http://localhost:8083",
            skills=[
                AgentSkill(id="translate", name="Translate", description="Translate text"),
                AgentSkill(id="summarize", name="Summarize", description="Summarize text"),
                AgentSkill(id="analyze", name="Analyze", description="Analyze text"),
            ],
        ),
    ]
    
    # Create and populate registry
    print_subsection("Registering Agents")
    
    registry = A2ARegistry()
    for agent in agents:
        registry.register(agent)
        print(f"Registered: {agent.name} at {agent.url}")
    
    # Query registry
    print_subsection("Querying Registry")
    
    # Get by name
    translator = registry.get_by_name("translator")
    print(f"By name 'translator': {translator.name if translator else 'Not found'}")
    
    # Get by URL
    agent = registry.get_by_url("http://localhost:8082")
    print(f"By URL 'localhost:8082': {agent.name if agent else 'Not found'}")
    
    # Find by skill
    translators = registry.find_by_skill("translate")
    print(f"Agents with 'translate' skill: {[a.name for a in translators]}")
    
    summarizers = registry.find_by_skill("summarize")
    print(f"Agents with 'summarize' skill: {[a.name for a in summarizers]}")
    
    # List all
    all_agents = registry.list_all()
    print(f"\nTotal registered agents: {len(all_agents)}")
    
    # Unregister
    print_subsection("Managing Registry")
    
    registry.unregister("analyst")
    print(f"Unregistered 'analyst'. Remaining: {len(registry.list_all())}")
    
    registry.clear()
    print(f"Cleared registry. Remaining: {len(registry.list_all())}")


async def demo_conversation_threading():
    """Demonstrate conversation threading functionality."""
    print_section("Conversation Threading Demo")
    
    # Create thread manager
    manager = ThreadManager()
    
    # Create threads
    print_subsection("Creating Threads")
    
    # Translation request thread
    translation_thread = manager.create_thread(
        title="Translation Request",
        participants=["user", "translator-agent"],
        metadata={"language_pair": "en-fr"},
    )
    print(f"Created thread: {translation_thread.id[:8]}... - '{translation_thread.title}'")
    
    # Research thread
    research_thread = manager.create_thread(
        title="Research Discussion",
        participants=["user", "research-agent", "summarizer-agent"],
    )
    print(f"Created thread: {research_thread.id[:8]}... - '{research_thread.title}'")
    
    # Simulate conversation
    print_subsection("Simulating Conversation")
    
    # Translation conversation
    translation_thread.add_message(
        content="Please translate 'Hello, how are you?' to French.",
        role=MessageRole.USER,
    )
    translation_thread.add_message(
        content="Bonjour, comment allez-vous?",
        role=MessageRole.AGENT,
        metadata={"confidence": 0.98, "source_lang": "en", "target_lang": "fr"},
    )
    translation_thread.add_message(
        content="Now translate 'Thank you very much' to French.",
        role=MessageRole.USER,
    )
    translation_thread.add_message(
        content="Merci beaucoup.",
        role=MessageRole.AGENT,
        metadata={"confidence": 0.99},
    )
    
    print(f"Translation thread messages: {len(translation_thread.messages)}")
    
    # Query messages
    print_subsection("Querying Messages")
    
    last_msg = translation_thread.get_last_message()
    print(f"Last message: '{last_msg.content}' (role: {last_msg.role.value})")
    
    user_msgs = translation_thread.get_messages(role=MessageRole.USER)
    print(f"User messages: {len(user_msgs)}")
    
    agent_msgs = translation_thread.get_messages(role=MessageRole.AGENT)
    print(f"Agent messages: {len(agent_msgs)}")
    
    # Last 2 messages
    recent = translation_thread.get_messages(limit=2)
    print(f"Recent messages: {[m.content[:30] for m in recent]}")
    
    # Thread context
    print_subsection("Thread Context")
    
    ctx = translation_thread.context
    ctx.set_variable("user_preference", "formal")
    ctx.set_variable("session_count", 1)
    ctx.add_key_point("User prefers French translations")
    ctx.add_key_point("High confidence translations achieved")
    ctx.update_summary("Translation session for English to French. User requests formal translations.")
    
    print(f"Variables: {ctx.variables}")
    print(f"Key points: {ctx.key_points}")
    print(f"Summary: {ctx.summary}")
    
    # Agent state
    translation_thread.update_agent_state("translator-agent", {
        "translations_done": 2,
        "avg_confidence": 0.985,
    })
    
    agent_context = translation_thread.get_context_for_agent("translator-agent")
    print(f"\nAgent context keys: {list(agent_context.keys())}")
    print(f"Agent state: {agent_context['agent_state']}")
    
    # Thread lifecycle
    print_subsection("Thread Lifecycle")
    
    print(f"Initial state: {translation_thread.state.value}")
    print(f"Is active: {translation_thread.is_active()}")
    
    translation_thread.pause()
    print(f"After pause: {translation_thread.state.value}")
    
    translation_thread.resume()
    print(f"After resume: {translation_thread.state.value}")
    
    translation_thread.complete()
    print(f"After complete: {translation_thread.state.value}")
    
    # Thread manager operations
    print_subsection("Thread Manager Operations")
    
    stats = manager.get_stats()
    print(f"Thread statistics: {stats}")
    
    all_threads = manager.list_threads()
    print(f"All threads: {len(all_threads)}")
    
    active_threads = manager.list_threads(state=ThreadState.ACTIVE)
    print(f"Active threads: {len(active_threads)}")
    
    # Serialization
    print_subsection("Serialization")
    
    thread_data = research_thread.to_dict()
    print(f"Serialized thread keys: {list(thread_data.keys())}")
    
    restored = ConversationThread.from_dict(thread_data)
    print(f"Restored thread: {restored.id} - '{restored.title}'")


async def demo_error_handling():
    """Demonstrate standardized error handling."""
    print_section("Error Handling Demo")
    
    # Error codes
    print_subsection("Error Code Categories")
    
    categories = {
        "Client Errors (1xxx)": [
            A2AErrorCode.INVALID_REQUEST,
            A2AErrorCode.RATE_LIMITED,
            A2AErrorCode.UNAUTHORIZED,
        ],
        "Agent Errors (2xxx)": [
            A2AErrorCode.AGENT_NOT_FOUND,
            A2AErrorCode.SKILL_NOT_FOUND,
            A2AErrorCode.AGENT_TIMEOUT,
        ],
        "Communication Errors (3xxx)": [
            A2AErrorCode.CONNECTION_FAILED,
            A2AErrorCode.NETWORK_ERROR,
        ],
        "Protocol Errors (4xxx)": [
            A2AErrorCode.PROTOCOL_VERSION_MISMATCH,
            A2AErrorCode.THREAD_NOT_FOUND,
        ],
        "Internal Errors (5xxx)": [
            A2AErrorCode.INTERNAL_ERROR,
            A2AErrorCode.NOT_IMPLEMENTED,
        ],
    }
    
    for category, codes in categories.items():
        print(f"\n{category}:")
        for code in codes:
            print(f"  - {code.value}: {code.name}")
    
    # Creating errors
    print_subsection("Creating Errors")
    
    error = A2AError(
        message="Agent temporarily unavailable",
        code=A2AErrorCode.AGENT_UNAVAILABLE,
        details=A2AErrorDetails(
            suggestion="Try again in a few minutes",
        ),
    )
    
    print(f"Error: {error.message}")
    print(f"Code: {error.code.value}")
    print(f"HTTP Status: {error.http_status}")
    print(f"Details: {error.details.to_dict() if error.details else None}")
    
    # Error to HTTP response
    response = error.to_response()
    print(f"\nHTTP Response:")
    print(f"  Status: {response['status']}")
    print(f"  Headers: {response['headers']}")
    
    # Specific error classes
    print_subsection("Specific Error Classes")
    
    errors = [
        A2ADiscoveryError("Agent not found", url="http://unknown-agent.com"),
        A2AConnectionError("Connection refused", host="localhost", port=8080),
        A2ATimeoutError("Request timed out", timeout_seconds=30.0),
        A2AAuthenticationError("Invalid API key"),
        A2ARateLimitError("Too many requests", retry_after=60),
    ]
    
    for err in errors:
        print(f"  {err.__class__.__name__}: {err.code.value} -> HTTP {err.http_status}")
    
    # Error handler
    print_subsection("Error Handler")
    
    handler = A2AErrorHandler(default_agent_name="my-agent")
    
    # Handle various exceptions
    exceptions = [
        TimeoutError("Operation timed out"),
        ConnectionError("Connection refused"),
        ValueError("Invalid input"),
        RuntimeError("Something went wrong"),
    ]
    
    print("Exception -> A2AError mapping:")
    for exc in exceptions:
        a2a_error = handler.handle(exc)
        print(f"  {type(exc).__name__} -> {type(a2a_error).__name__} ({a2a_error.code.value})")
    
    # Custom error handler
    print_subsection("Custom Error Handler")
    
    class CustomError(Exception):
        pass
    
    def handle_custom(exc):
        return A2AError(
            message=f"Custom error: {exc}",
            code=A2AErrorCode.INTERNAL_ERROR,
            details=A2AErrorDetails(
                suggestion="Check custom error handling",
            ),
        )
    
    handler.register_handler(CustomError, handle_custom)
    
    custom_exc = CustomError("Something custom failed")
    result = handler.handle(custom_exc)
    print(f"Custom exception handled: {result.message}")


async def demo_integration():
    """Demonstrate integrated workflow."""
    print_section("Integration Demo: Complete Agent Workflow")
    
    # Set up infrastructure
    print_subsection("Setting Up Infrastructure")
    
    # Create agents
    agents = [
        AgentCard(
            name="coordinator",
            description="Workflow coordinator agent",
            url="http://localhost:8080",
            skills=[
                AgentSkill(id="coordinate", name="Coordinate", description="Coordinate tasks"),
            ],
        ),
        AgentCard(
            name="worker-1",
            description="Worker agent 1",
            url="http://localhost:8081",
            skills=[
                AgentSkill(id="process", name="Process", description="Process data"),
            ],
        ),
        AgentCard(
            name="worker-2",
            description="Worker agent 2",
            url="http://localhost:8082",
            skills=[
                AgentSkill(id="analyze", name="Analyze", description="Analyze results"),
            ],
        ),
    ]
    
    # Registry
    registry = A2ARegistry()
    for agent in agents:
        registry.register(agent)
    print(f"Registered {len(registry.list_all())} agents")
    
    # Servers
    servers = []
    for i, agent in enumerate(agents):
        config = A2AServerConfig(
            port=8080 + i,
            agent_card=agent,
        )
        server = A2AServer(config)
        await server.start()
        servers.append(server)
    print(f"Started {len(servers)} servers")
    
    # Thread manager
    manager = ThreadManager()
    
    # Error handler
    handler = A2AErrorHandler(default_agent_name="coordinator")
    
    # Simulate workflow
    print_subsection("Running Workflow")
    
    # Create workflow thread
    workflow = manager.create_thread(
        title="Data Processing Workflow",
        participants=["user", "coordinator", "worker-1", "worker-2"],
        metadata={"workflow_type": "data-processing"},
    )
    
    try:
        # Step 1: User request
        workflow.add_message(
            content="Process the quarterly sales data",
            role=MessageRole.USER,
        )
        print("Step 1: User request received")
        
        # Step 2: Coordinator dispatches
        workflow.add_message(
            content="Dispatching to worker-1 for data processing",
            role=MessageRole.AGENT,
            metadata={"agent": "coordinator", "action": "dispatch"},
        )
        print("Step 2: Coordinator dispatched task")
        
        # Step 3: Worker processes
        workflow.add_message(
            content="Data processed successfully. 1000 records analyzed.",
            role=MessageRole.AGENT,
            metadata={"agent": "worker-1", "records": 1000},
        )
        print("Step 3: Worker-1 processed data")
        
        # Step 4: Worker analyzes
        workflow.add_message(
            content="Analysis complete. Key insights: 15% growth YoY.",
            role=MessageRole.AGENT,
            metadata={"agent": "worker-2", "growth": 0.15},
        )
        print("Step 4: Worker-2 analyzed results")
        
        # Step 5: Coordinator summarizes
        workflow.add_message(
            content="Workflow complete. Summary: Processed 1000 records, identified 15% YoY growth.",
            role=MessageRole.AGENT,
            metadata={"agent": "coordinator", "status": "complete"},
        )
        print("Step 5: Coordinator summarized workflow")
        
        # Update context
        workflow.context.update_summary(
            "Data processing workflow completed successfully. "
            "1000 records processed with 15% YoY growth identified."
        )
        workflow.context.add_key_point("15% YoY growth in quarterly sales")
        workflow.context.add_key_point("1000 records processed")
        
        workflow.complete()
        print("\nWorkflow completed successfully!")
        
    except Exception as e:
        error = handler.handle(e)
        print(f"Error: {error.message}")
        workflow.cancel()
    
    # Workflow summary
    print_subsection("Workflow Summary")
    
    print(f"Thread ID: {workflow.id[:8]}...")
    print(f"Title: {workflow.title}")
    print(f"State: {workflow.state.value}")
    print(f"Messages: {len(workflow.messages)}")
    print(f"Participants: {workflow.participants}")
    print(f"\nContext Summary: {workflow.context.summary}")
    print(f"Key Points: {workflow.context.key_points}")
    
    # Cleanup
    print_subsection("Cleanup")
    
    for server in servers:
        await server.stop()
    print(f"Stopped {len(servers)} servers")
    
    registry.clear()
    print("Cleared registry")


async def main():
    """Run all demos."""
    print("\n" + "=" * 60)
    print("   A2A Protocol v2 Demo")
    print("=" * 60)
    
    await demo_http_server_client()
    await demo_registry()
    await demo_conversation_threading()
    await demo_error_handling()
    await demo_integration()
    
    print_section("Demo Complete")
    print("All A2A Protocol v2 features demonstrated successfully!")
    print("\nKey Features:")
    print("  ✓ HTTP Server/Client for agent discovery")
    print("  ✓ Agent Registry for skill-based lookup")
    print("  ✓ Conversation Threading with context")
    print("  ✓ Standardized Error Handling")
    print("  ✓ Complete workflow integration")


if __name__ == "__main__":
    asyncio.run(main())
