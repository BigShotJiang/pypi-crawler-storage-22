#!/usr/bin/env python3
"""
Advanced Orchestration Patterns Demo

This demo showcases the HierarchicalPattern, EnsemblePattern, and SelfHealingPattern
implementations with realistic use cases.

Usage:
    python examples/advanced_patterns_demo.py
"""

import asyncio
from dataclasses import dataclass
from typing import Any

# =============================================================================
# Mock Components for Demo
# =============================================================================

@dataclass
class MockResponse:
    """Mock agent response for demo."""
    content: str
    cost: float = 0.001
    usage: dict = None
    
    def __post_init__(self):
        if self.usage is None:
            self.usage = {"prompt_tokens": 50, "completion_tokens": 100}


class MockAgent:
    """Mock agent for demo purposes."""
    
    def __init__(self, name: str, responses: list[str]):
        self.name = name
        self._responses = responses
        self._call_count = 0
    
    async def run(self, message: str, **kwargs) -> MockResponse:
        idx = min(self._call_count, len(self._responses) - 1)
        self._call_count += 1
        return MockResponse(content=self._responses[idx])
    
    def register_tool(self, tool: Any) -> None:
        pass


# =============================================================================
# Demo Functions
# =============================================================================

def print_header(title: str) -> None:
    """Print a formatted header."""
    print("\n" + "=" * 60)
    print(f"  {title}")
    print("=" * 60)


def print_section(title: str) -> None:
    """Print a section separator."""
    print(f"\n--- {title} ---")


async def demo_hierarchical_pattern() -> None:
    """Demonstrate the HierarchicalPattern."""
    print_header("HierarchicalPattern Demo")
    
    print("""
The HierarchicalPattern creates a tree-like structure of agents where
supervisors at each level delegate to agents below them.

Example: Corporate Decision Making
- Executive Level: CEO makes strategic decisions
- Management Level: Managers coordinate teams
- Worker Level: Workers execute tasks
""")
    
    # Import pattern
    from multi_agent_base.core.patterns import HierarchicalPattern, HierarchicalLevel
    from multi_agent_base.core.config import SystemConfig, ProviderConfig
    
    # Create config (we'll mock the agents)
    config = SystemConfig(provider=ProviderConfig(model="mock"))
    pattern = HierarchicalPattern(config)
    
    # Create organizational structure
    print_section("Creating Organizational Hierarchy")
    
    # Root level - Executive
    pattern.create_level("executive", supervisor="ceo")
    print("✓ Created 'executive' level (root)")
    
    # Middle level - Management
    pattern.create_level("management", supervisor="manager", parent="executive")
    print("✓ Created 'management' level (child of executive)")
    
    # Leaf level - Workers
    pattern.create_level("workers", agents=["analyst", "developer"], parent="management")
    print("✓ Created 'workers' level (child of management)")
    
    # Add mock agents
    print_section("Adding Agents to Levels")
    
    # CEO delegates to management
    ceo = MockAgent("ceo", [
        "DELEGATE: Review the project requirements and assign tasks.",
        "Based on the team's work, I approve the project plan."
    ])
    pattern._agents["ceo"] = ceo
    pattern._levels["executive"].supervisor = "ceo"
    print("✓ Added CEO to executive level")
    
    # Manager coordinates workers
    manager = MockAgent("manager", [
        "DELEGATE: Analyst, analyze requirements. Developer, propose solutions.",
        "Team has completed analysis and development plan."
    ])
    pattern._agents["manager"] = manager
    pattern._levels["management"].supervisor = "manager"
    print("✓ Added Manager to management level")
    
    # Workers execute
    analyst = MockAgent("analyst", ["Analysis complete: Project requires A, B, C features."])
    developer = MockAgent("developer", ["Development plan: Phase 1 - Setup, Phase 2 - Build."])
    pattern._agents["analyst"] = analyst
    pattern._agents["developer"] = developer
    print("✓ Added Analyst and Developer to workers level")
    
    # Run the pattern
    print_section("Running Hierarchical Workflow")
    result = await pattern.run("Plan the new product launch")
    
    print(f"\n📊 Result:")
    print(f"   Content: {result.content[:100]}...")
    print(f"   Levels: {result.metadata['levels']}")
    print(f"   Root Level: {result.metadata['root_level']}")
    print(f"   Total Cost: ${result.total_cost:.4f}")
    print(f"   Responses: {len(result.agent_responses)}")


async def demo_ensemble_pattern() -> None:
    """Demonstrate the EnsemblePattern."""
    print_header("EnsemblePattern Demo")
    
    print("""
The EnsemblePattern allows multiple agents to vote on responses.
This is useful for consensus-building and expert panels.

Example: Code Review Committee
- Security Expert: Reviews for vulnerabilities
- Performance Expert: Reviews for efficiency
- UX Expert: Reviews for user experience
""")
    
    from multi_agent_base.core.patterns import EnsemblePattern, VotingStrategy
    from multi_agent_base.core.config import SystemConfig, ProviderConfig
    
    config = SystemConfig(provider=ProviderConfig(model="mock"))
    
    # Demo 1: Majority Voting
    print_section("Demo 1: Majority Voting")
    
    pattern = EnsemblePattern(config, voting_strategy=VotingStrategy.MAJORITY)
    
    # Add voters
    pattern._voters = ["expert1", "expert2", "expert3"]
    pattern._weights = {"expert1": 1.0, "expert2": 1.0, "expert3": 1.0}
    
    # Two experts agree on the answer
    pattern._agents["expert1"] = MockAgent("expert1", ["The code is safe and efficient."])
    pattern._agents["expert2"] = MockAgent("expert2", ["The code is safe and efficient."])
    pattern._agents["expert3"] = MockAgent("expert3", ["The code needs more error handling."])
    
    result = await pattern.run("Review this code submission")
    
    print(f"   Voting Strategy: {result.metadata['voting_strategy']}")
    print(f"   Confidence: {result.metadata['confidence']:.1%}")
    print(f"   Winner: {result.content}")
    
    # Demo 2: Weighted Voting
    print_section("Demo 2: Weighted Voting")
    
    pattern = EnsemblePattern(config, voting_strategy=VotingStrategy.WEIGHTED)
    
    pattern._voters = ["security", "performance", "ux"]
    pattern._weights = {"security": 3.0, "performance": 1.0, "ux": 1.0}  # Security has high weight
    
    # Security expert disagrees but has more weight
    pattern._agents["security"] = MockAgent("security", ["REJECT: Critical vulnerability found."])
    pattern._agents["performance"] = MockAgent("performance", ["APPROVE: Good performance."])
    pattern._agents["ux"] = MockAgent("ux", ["APPROVE: Good user experience."])
    
    result = await pattern.run("Should we deploy this feature?")
    
    print(f"   Voting Strategy: {result.metadata['voting_strategy']}")
    print(f"   Expert Weights: security=3.0, performance=1.0, ux=1.0")
    print(f"   Confidence: {result.metadata['confidence']:.1%}")
    print(f"   Winner: {result.content}")
    
    # Demo 3: Unanimous Voting
    print_section("Demo 3: Unanimous Voting (No Consensus)")
    
    pattern = EnsemblePattern(config, voting_strategy=VotingStrategy.UNANIMOUS)
    
    pattern._voters = ["legal", "finance", "tech"]
    pattern._weights = {"legal": 1.0, "finance": 1.0, "tech": 1.0}
    
    # No agreement
    pattern._agents["legal"] = MockAgent("legal", ["Legal concerns with licensing."])
    pattern._agents["finance"] = MockAgent("finance", ["Budget approved."])
    pattern._agents["tech"] = MockAgent("tech", ["Technical feasibility confirmed."])
    
    result = await pattern.run("Proceed with acquisition?")
    
    print(f"   Voting Strategy: {result.metadata['voting_strategy']}")
    print(f"   Confidence: {result.metadata['confidence']:.1%}")
    print(f"   Winner: '{result.content}' (empty = no consensus)")
    print(f"   Clusters: {result.metadata['num_clusters']}")


async def demo_self_healing_pattern() -> None:
    """Demonstrate the SelfHealingPattern."""
    print_header("SelfHealingPattern Demo")
    
    print("""
The SelfHealingPattern automatically retries failed or unsatisfactory
responses with modified prompts.

Example: Reliable Task Completion
- First attempt may fail
- Subsequent attempts use modified strategies
- Optional healer agent can fix broken responses
""")
    
    from multi_agent_base.core.patterns import SelfHealingPattern
    from multi_agent_base.core.config import SystemConfig, ProviderConfig
    
    config = SystemConfig(provider=ProviderConfig(model="mock"))
    
    # Demo 1: Successful first attempt
    print_section("Demo 1: Success on First Attempt")
    
    pattern = SelfHealingPattern(config, max_retries=3)
    pattern._primary_agent = MockAgent("worker", ["Task completed successfully!"])
    pattern._agents["worker"] = pattern._primary_agent
    
    result = await pattern.run("Complete this task")
    
    print(f"   Attempts: {result.metadata['attempts']}")
    print(f"   Was Healed: {result.metadata['healed']}")
    print(f"   Result: {result.content}")
    
    # Demo 2: Retry until success
    print_section("Demo 2: Retry Until Success")
    
    pattern = SelfHealingPattern(config, max_retries=3)
    pattern._primary_agent = MockAgent("worker", [
        "Sorry, I can't do that.",  # Fails - contains error pattern
        "I'm not sure how to proceed.",  # Fails - contains error pattern
        "Task completed successfully!",  # Success
    ])
    pattern._agents["worker"] = pattern._primary_agent
    
    result = await pattern.run("Complete this difficult task")
    
    print(f"   Attempts: {result.metadata['attempts']}")
    print(f"   Attempt History:")
    for attempt in result.metadata['attempt_history']:
        status = "✓" if attempt['valid'] else "✗"
        print(f"      {status} Attempt {attempt['attempt']}: {attempt.get('error', 'Success')}")
    print(f"   Final Result: {result.content}")
    
    # Demo 3: With custom validator
    print_section("Demo 3: Custom Validator")
    
    pattern = SelfHealingPattern(config, max_retries=3)
    pattern._primary_agent = MockAgent("worker", [
        "Here is the partial result.",  # Fails custom validation
        "COMPLETE: Full result with all requirements.",  # Passes
    ])
    pattern._agents["worker"] = pattern._primary_agent
    
    # Custom validator requires "COMPLETE:" prefix
    pattern.set_validator(lambda response: response.startswith("COMPLETE:"))
    
    result = await pattern.run("Generate a complete report")
    
    print(f"   Custom Validator: response.startswith('COMPLETE:')")
    print(f"   Attempts: {result.metadata['attempts']}")
    print(f"   Result: {result.content}")
    
    # Demo 4: With healer agent
    print_section("Demo 4: With Healer Agent")
    
    pattern = SelfHealingPattern(config, max_retries=1)  # Only 1 retry
    pattern._primary_agent = MockAgent("worker", [
        "Unable to process request.",  # Always fails
        "Unable to process request.",
    ])
    pattern._agents["worker"] = pattern._primary_agent
    
    # Add healer to fix broken responses
    pattern._healer = MockAgent("healer", [
        "HEALED: Here is the corrected response with proper handling."
    ])
    pattern._agents["healer"] = pattern._healer
    
    # Make healed response pass validation
    pattern.set_validator(lambda r: "HEALED:" in r or "process" not in r.lower())
    
    result = await pattern.run("Process this data")
    
    print(f"   Primary agent always fails")
    print(f"   Healer agent fixes response")
    print(f"   Attempts (primary): {result.metadata['attempts']}")
    print(f"   Was Healed: {result.metadata['healed']}")
    print(f"   Result: {result.content}")


async def demo_voting_strategies() -> None:
    """Demonstrate different voting strategies in detail."""
    print_header("Voting Strategies Deep Dive")
    
    from multi_agent_base.core.patterns import EnsemblePattern, VotingStrategy
    from multi_agent_base.core.config import SystemConfig, ProviderConfig
    
    config = SystemConfig(provider=ProviderConfig(model="mock"))
    
    # Test data: Same responses, different strategies
    test_cases = [
        {
            "name": "Close Vote",
            "votes": {"a": 2, "b": 2},  # Tie
            "weights": {"a1": 1, "a2": 1, "b1": 1.5, "b2": 0.5},  # b1 has more weight
        },
        {
            "name": "Clear Majority",
            "votes": {"a": 3, "b": 1},
            "weights": {"a1": 1, "a2": 1, "a3": 1, "b1": 1},
        },
    ]
    
    for strategy in [VotingStrategy.MAJORITY, VotingStrategy.WEIGHTED, VotingStrategy.RANKED_CHOICE]:
        print_section(f"Strategy: {strategy.value.upper()}")
        
        pattern = EnsemblePattern(config, voting_strategy=strategy)
        
        # Close vote scenario
        pattern._voters = ["a1", "a2", "b1", "b2"]
        pattern._weights = {"a1": 1.0, "a2": 1.0, "b1": 1.5, "b2": 0.5}
        
        # a1, a2 vote for "Option A"
        # b1, b2 vote for "Option B"
        pattern._agents["a1"] = MockAgent("a1", ["Option A is the best choice."])
        pattern._agents["a2"] = MockAgent("a2", ["Option A is the best choice."])
        pattern._agents["b1"] = MockAgent("b1", ["Option B is the best choice."])
        pattern._agents["b2"] = MockAgent("b2", ["Option B is the best choice."])
        
        result = await pattern.run("Which option should we choose?")
        
        print(f"   Votes: A=2 (weight=2.0), B=2 (weight=2.0)")
        print(f"   BUT: a1=1.0, a2=1.0, b1=1.5, b2=0.5")
        print(f"   Confidence: {result.metadata['confidence']:.1%}")
        print(f"   Winner: {'Option A' if 'A' in result.content else 'Option B'}")


async def demo_combined_patterns() -> None:
    """Show how patterns can be conceptually combined."""
    print_header("Combining Patterns (Conceptual)")
    
    print("""
Patterns can be combined for complex workflows:

1. Hierarchical + Ensemble: 
   - Each level uses voting for decisions
   - CEO level: Board votes on strategy
   - Management level: Managers vote on implementation
   
2. Self-Healing + Any Pattern:
   - Wrap any pattern with retry logic
   - Ensure critical operations succeed
   
3. Ensemble + Self-Healing:
   - If consensus fails, retry with different prompts
   - Escalate to human if still no consensus
""")
    
    print_section("Example: Resilient Consensus Workflow")
    
    from multi_agent_base.core.patterns import SelfHealingPattern, EnsemblePattern, VotingStrategy
    from multi_agent_base.core.config import SystemConfig, ProviderConfig
    
    config = SystemConfig(provider=ProviderConfig(model="mock"))
    
    # Outer: Self-healing wrapper
    # Inner: Ensemble voting
    
    # Create ensemble that might fail to reach consensus
    ensemble = EnsemblePattern(config, voting_strategy=VotingStrategy.UNANIMOUS)
    ensemble._voters = ["expert1", "expert2"]
    ensemble._weights = {"expert1": 1.0, "expert2": 1.0}
    
    # First time: no consensus
    # Second time: consensus
    call_count = [0]
    
    async def resilient_consensus(message: str) -> str:
        call_count[0] += 1
        if call_count[0] == 1:
            # First call: disagreement
            ensemble._agents["expert1"] = MockAgent("e1", ["YES"])
            ensemble._agents["expert2"] = MockAgent("e2", ["NO"])
        else:
            # Second call: agreement
            ensemble._agents["expert1"] = MockAgent("e1", ["YES, proceed"])
            ensemble._agents["expert2"] = MockAgent("e2", ["YES, proceed"])
        
        result = await ensemble.run(message)
        return result
    
    # Simulate
    print("   Attempt 1: Experts disagree (YES vs NO)")
    result1 = await resilient_consensus("Should we proceed?")
    print(f"   Consensus: {result1.content if result1.content else 'NONE'}")
    
    print("   Attempt 2: Experts agree after more context")
    result2 = await resilient_consensus("With additional context, should we proceed?")
    print(f"   Consensus: {result2.content}")
    
    print("\n   ✓ Self-healing wrapper would handle the retry automatically")


async def main() -> None:
    """Run all demos."""
    print("\n" + "🎯 " * 20)
    print("   ADVANCED ORCHESTRATION PATTERNS DEMO")
    print("🎯 " * 20)
    
    await demo_hierarchical_pattern()
    await demo_ensemble_pattern()
    await demo_self_healing_pattern()
    await demo_voting_strategies()
    await demo_combined_patterns()
    
    print_header("Demo Complete!")
    print("""
Summary:
- HierarchicalPattern: Multi-level delegation for complex orgs
- EnsemblePattern: Consensus through voting strategies
- SelfHealingPattern: Automatic retry with modifications

These patterns can be combined for robust, fault-tolerant workflows.
""")


if __name__ == "__main__":
    asyncio.run(main())
