#!/usr/bin/env python3
"""
Context Engineering Demo

Demonstrates the capabilities of the Context Engineering module
for managing, optimizing, and compressing LLM context windows.
"""

import time
import sys
sys.path.insert(0, "src")

from multi_agent_base.context import (
    # Types
    MessageRole,
    PruningStrategy,
    CompressionMethod,
    ContextMessage,
    ContextWindow,
    ContextStats,
    OptimizationConfig,
    ToolContext,
    # Optimizer
    ContextOptimizer,
    OptimizationResult,
    TokenEstimator,
    # Pruner
    ContextPruner,
    ConversationPruner,
    PruningResult,
    # Compressor
    ContextCompressor,
    CompressionResult,
)


def print_header(title: str) -> None:
    """Print a formatted header."""
    print("\n" + "=" * 60)
    print(f"  {title}")
    print("=" * 60)


def print_stats(stats: ContextStats) -> None:
    """Print optimization statistics."""
    print(f"  Original: {stats.original_messages} messages, {stats.original_tokens} tokens")
    print(f"  Optimized: {stats.optimized_messages} messages, {stats.optimized_tokens} tokens")
    print(f"  Pruned: {stats.pruned_count} messages")
    print(f"  Tokens saved: {stats.tokens_saved}")
    print(f"  Reduction: {stats.token_reduction * 100:.1f}%")
    print(f"  Strategy: {stats.strategy_used}")
    print(f"  Time: {stats.operation_time_ms:.2f}ms")


def demo_basic_types() -> None:
    """Demo 1: Basic Types and Operations"""
    print_header("Demo 1: Basic Types and Operations")
    
    # Create ContextMessage
    print("\n1. Creating ContextMessage objects:")
    msg1 = ContextMessage(
        role=MessageRole.USER,
        content="What is the capital of France?",
        importance=0.8,
    )
    tokens = msg1.estimate_tokens()
    print(f"   Message: '{msg1.content[:40]}...'")
    print(f"   Role: {msg1.role}")
    print(f"   Estimated tokens: {tokens}")
    print(f"   Content hash: {msg1.content_hash}")
    
    # Create ContextWindow
    print("\n2. Creating ContextWindow:")
    window = ContextWindow(max_tokens=500)
    
    messages = [
        ContextMessage(role="system", content="You are a helpful geography assistant."),
        ContextMessage(role="user", content="What is the capital of France?"),
        ContextMessage(role="assistant", content="The capital of France is Paris. It's known as the City of Light."),
        ContextMessage(role="user", content="What is its population?"),
        ContextMessage(role="assistant", content="Paris has about 2.1 million people in the city proper."),
    ]
    
    for msg in messages:
        msg.estimate_tokens()
        added = window.add_message(msg)
        if not added:
            print(f"   ⚠️  Could not add: {msg.content[:30]}... (would exceed limit)")
    
    print(f"   Window size: {len(window)} messages")
    print(f"   Token usage: {window.current_tokens}/{window.max_tokens}")
    print(f"   Utilization: {window.utilization * 100:.1f}%")
    print(f"   Available: {window.available_tokens} tokens")
    
    # Convert to list
    print("\n3. Converting to API format:")
    api_messages = window.to_list()
    print(f"   Ready for API call: {len(api_messages)} messages")


def demo_optimization_strategies() -> None:
    """Demo 2: Optimization Strategies"""
    print_header("Demo 2: Optimization Strategies")
    
    # Create a long conversation
    messages = [
        {"role": "system", "content": "You are a helpful coding assistant specializing in Python."},
    ]
    
    topics = ["loops", "functions", "classes", "decorators", "async", "typing", "testing"]
    for i, topic in enumerate(topics):
        messages.append({
            "role": "user",
            "content": f"Question {i+1}: Can you explain Python {topic} in detail? " + "x" * 50,
        })
        messages.append({
            "role": "assistant",
            "content": f"Sure! Python {topic} is an important concept. Here's a detailed explanation... " + "y" * 100,
        })
    
    print(f"\n1. Original conversation: {len(messages)} messages")
    
    # Test different strategies
    strategies = [
        (PruningStrategy.RECENCY, "Keeps most recent messages"),
        (PruningStrategy.SLIDING_WINDOW, "Simple fixed window from end"),
        (PruningStrategy.SMART, "Combines multiple strategies"),
    ]
    
    for strategy, description in strategies:
        print(f"\n2. {strategy.value.upper()} Strategy ({description}):")
        
        config = OptimizationConfig(
            max_tokens=300,
            pruning_strategy=strategy,
            preserve_recent=2,
        )
        optimizer = ContextOptimizer(config=config)
        result = optimizer.optimize(messages)
        
        print_stats(result.stats)


def demo_pruning_operations() -> None:
    """Demo 3: Direct Pruning Operations"""
    print_header("Demo 3: Direct Pruning Operations")
    
    # Create test messages
    messages = [
        {"role": "system", "content": "You are helpful."},
        {"role": "user", "content": "Tell me about Python programming language."},
        {"role": "assistant", "content": "Python is a versatile programming language."},
        {"role": "user", "content": "What about JavaScript?"},
        {"role": "assistant", "content": "JavaScript is used for web development."},
        {"role": "user", "content": "Tell me about Python again."},  # Duplicate-ish
        {"role": "assistant", "content": "Python is great for data science and AI."},
        {"role": "tool", "content": "{'result': 'success', 'data': '" + "x" * 500 + "'}"},  # Long tool result
        {"role": "user", "content": ""},  # Empty message
        {"role": "assistant", "content": "   "},  # Whitespace only
    ]
    
    pruner = ContextPruner()
    
    # Prune by recency
    print("\n1. Prune by Recency (keep last 5):")
    result = pruner.prune_by_recency(messages, keep_count=5)
    print(f"   Kept: {result.kept_count}, Pruned: {result.pruned_count}")
    
    # Prune duplicates
    print("\n2. Prune Duplicates (similarity > 0.5):")
    result = pruner.prune_duplicates(messages, similarity_threshold=0.5)
    print(f"   Kept: {result.kept_count}, Pruned: {result.pruned_count}")
    
    # Prune by pattern
    print("\n3. Prune by Pattern (remove 'JavaScript' mentions):")
    result = pruner.prune_by_pattern(messages, patterns=["JavaScript"], keep_matches=False)
    print(f"   Kept: {result.kept_count}, Pruned: {result.pruned_count}")
    
    # Prune by role
    print("\n4. Prune by Role (remove tool messages):")
    result = pruner.prune_by_role(messages, roles_to_remove=["tool"])
    print(f"   Kept: {result.kept_count}, Pruned: {result.pruned_count}")
    
    # Prune empty
    print("\n5. Prune Empty Messages:")
    result = pruner.prune_empty(messages)
    print(f"   Kept: {result.kept_count}, Pruned: {result.pruned_count}")
    
    # Truncate tool results
    print("\n6. Truncate Long Tool Results (max 100 chars):")
    result = pruner.prune_tool_results(messages, max_result_length=100)
    tool_msgs = [m for m in result.kept if m.role == "tool"]
    if tool_msgs:
        print(f"   Tool result length: {len(tool_msgs[0].content)} chars")


def demo_conversation_pruning() -> None:
    """Demo 4: Conversation-Aware Pruning"""
    print_header("Demo 4: Conversation-Aware Pruning")
    
    # Create conversation with turns
    messages = [
        {"role": "system", "content": "You are a math tutor."},
    ]
    
    for i in range(10):
        messages.append({"role": "user", "content": f"What is {i+1} + {i+1}?"})
        messages.append({"role": "assistant", "content": f"The answer is {(i+1)*2}."})
    
    print(f"\n1. Original: {len(messages)} messages ({(len(messages)-1)//2} turns)")
    
    # Keep complete turns
    pruner = ConversationPruner()
    
    print("\n2. Keep Last 3 Complete Turns:")
    result = pruner.prune_keeping_turns(messages, keep_turns=3)
    print(f"   Kept: {result.kept_count} messages")
    print(f"   Pruned: {result.pruned_count} messages")
    
    # With summarization
    print("\n3. Prune with Summarization:")
    
    def mock_summarizer(contents: list[str]) -> str:
        return f"[Earlier: discussed {len(contents)} math problems]"
    
    result, summary = pruner.prune_summarizing_turns(
        messages,
        keep_turns=2,
        summarizer=mock_summarizer,
    )
    print(f"   Kept: {result.kept_count} messages")
    print(f"   Summary: {summary}")


def demo_compression() -> None:
    """Demo 5: Compression Techniques"""
    print_header("Demo 5: Compression Techniques")
    
    # Create verbose messages
    messages = [
        {"role": "system", "content": "You are a helpful assistant."},
        {"role": "user", "content": "Tell me everything about machine learning."},
        {"role": "assistant", "content": """Machine learning is a subset of artificial intelligence. 
        It enables computers to learn from data. There are many types including supervised, 
        unsupervised, and reinforcement learning. Deep learning is a subset that uses neural networks.
        Key concepts include features, labels, training, validation, and testing."""},
        {"role": "user", "content": "What about deep learning specifically?"},
        {"role": "assistant", "content": """Deep learning uses neural networks with multiple layers.
        Common architectures include CNNs for images, RNNs for sequences, and Transformers for NLP.
        Training requires large datasets and significant computational resources.
        Popular frameworks include TensorFlow, PyTorch, and JAX."""},
    ]
    
    compressor = ContextCompressor()
    
    # Summarize
    print("\n1. Summarize Messages:")
    summary = compressor.summarize_messages(messages)
    print(f"   Summary: {summary[:100]}...")
    
    # Truncate
    print("\n2. Truncate Messages (max 100 chars):")
    result = compressor.truncate_messages(messages, max_chars_per_message=100)
    print(f"   Original tokens: {result.stats.original_tokens}")
    print(f"   Truncated tokens: {result.stats.optimized_tokens}")
    
    # Extract key points
    print("\n3. Extract Key Points (max 2 per message):")
    result = compressor.extract_key_points(messages, max_points_per_message=2)
    for msg in result.messages:
        if msg.role == "assistant":
            print(f"   {msg.content[:80]}...")
    
    # Compression methods
    print("\n4. Compression Methods:")
    methods = [
        (CompressionMethod.SUMMARIZE, "Summarization"),
        (CompressionMethod.MERGE, "Merging"),
        (CompressionMethod.EXTRACT_KEY_POINTS, "Key Point Extraction"),
        (CompressionMethod.HIERARCHICAL, "Hierarchical"),
    ]
    
    for method, name in methods:
        result = compressor.compress(messages, target_tokens=50, method=method)
        print(f"   {name}: {result.stats.original_tokens} → {result.stats.optimized_tokens} tokens")


def demo_tool_compression() -> None:
    """Demo 6: Tool Definition Compression"""
    print_header("Demo 6: Tool Definition Compression")
    
    # Create tool definitions
    tools = [
        {
            "type": "function",
            "function": {
                "name": "search_web",
                "description": "Search the web for information on any topic. Returns relevant results.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "query": {"type": "string", "description": "Search query"}
                    }
                }
            }
        },
        {
            "type": "function", 
            "function": {
                "name": "get_weather",
                "description": "Get current weather conditions for a specified location.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "location": {"type": "string"},
                        "units": {"type": "string", "enum": ["celsius", "fahrenheit"]}
                    }
                }
            }
        },
        {
            "type": "function",
            "function": {
                "name": "calculate",
                "description": "Perform mathematical calculations and return the result.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "expression": {"type": "string"}
                    }
                }
            }
        },
    ]
    
    compressor = ContextCompressor()
    
    # Estimate original tokens
    original_tokens = sum(TokenEstimator.estimate_tool(t) for t in tools)
    print(f"\n1. Original: {len(tools)} tools, ~{original_tokens} tokens")
    
    # Compress tools
    compressed = compressor.compress_tools(tools, max_tokens=100)
    compressed_tokens = sum(t.token_count for t in compressed)
    print(f"\n2. Compressed: {len(compressed)} tools, ~{compressed_tokens} tokens")
    print(f"   Kept tools: {[t.name for t in compressed]}")
    
    # Compress with required tools
    compressed = compressor.compress_tools(tools, max_tokens=100, keep_names=["search_web"])
    print(f"\n3. With required 'search_web': {[t.name for t in compressed]}")


def demo_combined_optimization() -> None:
    """Demo 7: Combined Messages and Tools Optimization"""
    print_header("Demo 7: Combined Messages and Tools Optimization")
    
    # Messages
    messages = [
        {"role": "system", "content": "You are a helpful assistant with access to tools."},
        {"role": "user", "content": "What's the weather in Paris?"},
        {"role": "assistant", "content": "I'll check the weather for you."},
        {"role": "tool", "content": "{'temperature': 22, 'conditions': 'sunny'}"},
        {"role": "assistant", "content": "It's 22°C and sunny in Paris."},
        {"role": "user", "content": "Thanks! Now search for restaurants nearby."},
        {"role": "assistant", "content": "Let me search for restaurants."},
    ]
    
    # Tools
    tools = [
        {"type": "function", "function": {"name": "get_weather", "description": "Get weather"}},
        {"type": "function", "function": {"name": "search_places", "description": "Search places"}},
        {"type": "function", "function": {"name": "get_directions", "description": "Get directions"}},
    ]
    
    # Optimize both
    config = OptimizationConfig(max_tokens=200)
    optimizer = ContextOptimizer(config=config)
    
    result, opt_tools = optimizer.optimize_with_tools(messages, tools, max_tokens=200)
    
    print(f"\n1. Messages:")
    print(f"   Original: {result.stats.original_messages}")
    print(f"   Optimized: {result.stats.optimized_messages}")
    
    print(f"\n2. Tools:")
    print(f"   Original: {len(tools)}")
    print(f"   Optimized: {len(opt_tools)}")
    print(f"   Kept: {[t.name for t in opt_tools]}")


def demo_token_estimation() -> None:
    """Demo 8: Token Estimation"""
    print_header("Demo 8: Token Estimation")
    
    text = "Hello, world! This is a test message for token estimation."
    
    print("\n1. Simple Estimation:")
    print(f"   Text: '{text}'")
    print(f"   Default: {TokenEstimator.estimate_simple(text)} tokens")
    print(f"   GPT-4: {TokenEstimator.estimate_simple(text, 'gpt-4')} tokens")
    print(f"   Claude: {TokenEstimator.estimate_simple(text, 'claude')} tokens")
    
    print("\n2. Word-based Estimation:")
    print(f"   Words: {len(text.split())}")
    print(f"   Estimated tokens: {TokenEstimator.estimate_words(text)}")
    
    messages = [
        {"role": "system", "content": "You are helpful."},
        {"role": "user", "content": "Hello!"},
        {"role": "assistant", "content": "Hi there! How can I help?"},
    ]
    
    print("\n3. Message List Estimation:")
    print(f"   Messages: {len(messages)}")
    print(f"   Estimated tokens: {TokenEstimator.estimate_messages(messages)}")
    
    tool = {
        "type": "function",
        "function": {
            "name": "get_time",
            "description": "Get the current time",
            "parameters": {"type": "object", "properties": {}}
        }
    }
    
    print("\n4. Tool Definition Estimation:")
    print(f"   Tool: {tool['function']['name']}")
    print(f"   Estimated tokens: {TokenEstimator.estimate_tool(tool)}")


def demo_config_presets() -> None:
    """Demo 9: Configuration Presets"""
    print_header("Demo 9: Configuration Presets")
    
    # Create long conversation
    messages = [{"role": "system", "content": "You are helpful."}]
    for i in range(20):
        messages.append({"role": "user", "content": f"Message {i+1}: " + "x" * 50})
        messages.append({"role": "assistant", "content": f"Response {i+1}: " + "y" * 100})
    
    presets = [
        ("Aggressive", OptimizationConfig.aggressive()),
        ("Balanced", OptimizationConfig.balanced()),
        ("Conservative", OptimizationConfig.conservative()),
    ]
    
    print("\n1. Preset Comparison:")
    print(f"   Original messages: {len(messages)}")
    
    for name, config in presets:
        optimizer = ContextOptimizer(config=config)
        result = optimizer.optimize(messages)
        
        print(f"\n   {name} (max_tokens={config.max_tokens}):")
        print(f"     Result: {result.stats.optimized_messages} messages, {result.stats.optimized_tokens} tokens")
        print(f"     Preserve recent: {config.preserve_recent}")


def demo_debugging() -> None:
    """Demo 10: Debugging with Snapshots"""
    print_header("Demo 10: Debugging with Snapshots")
    
    messages = [
        {"role": "system", "content": "You are a helpful assistant."},
    ]
    for i in range(10):
        messages.append({"role": "user", "content": f"Question {i+1}?"})
        messages.append({"role": "assistant", "content": f"Answer {i+1}."})
    
    config = OptimizationConfig(
        max_tokens=100,
        pruning_strategy=PruningStrategy.SMART,
    )
    optimizer = ContextOptimizer(config=config)
    
    result = optimizer.optimize(messages)
    
    print("\n1. Optimization Snapshots:")
    snapshots = optimizer.get_snapshots()
    
    for i, snapshot in enumerate(snapshots):
        print(f"\n   Step {i+1}: {snapshot.operation}")
        print(f"     Messages: {len(snapshot.window)}")
        print(f"     Tokens: {snapshot.window.current_tokens}")


def main():
    """Run all demos."""
    print("\n" + "🔧" + " CONTEXT ENGINEERING MODULE DEMO " + "🔧")
    print("=" * 60)
    print("Demonstrates context management, optimization, and compression")
    print("for LLM context windows.\n")
    
    demos = [
        ("Basic Types", demo_basic_types),
        ("Optimization Strategies", demo_optimization_strategies),
        ("Pruning Operations", demo_pruning_operations),
        ("Conversation Pruning", demo_conversation_pruning),
        ("Compression Techniques", demo_compression),
        ("Tool Compression", demo_tool_compression),
        ("Combined Optimization", demo_combined_optimization),
        ("Token Estimation", demo_token_estimation),
        ("Configuration Presets", demo_config_presets),
        ("Debugging", demo_debugging),
    ]
    
    start_time = time.time()
    
    for name, demo_func in demos:
        try:
            demo_func()
            print(f"\n   ✅ {name} demo completed")
        except Exception as e:
            print(f"\n   ❌ {name} demo failed: {e}")
            import traceback
            traceback.print_exc()
    
    elapsed = time.time() - start_time
    
    print("\n" + "=" * 60)
    print(f"  All {len(demos)} demos completed in {elapsed:.2f}s")
    print("=" * 60)
    print("\n✨ Context Engineering module is ready for use!")
    print("\nKey features demonstrated:")
    print("  • ContextMessage and ContextWindow types")
    print("  • Multiple pruning strategies (recency, relevance, importance)")
    print("  • Compression methods (summarize, merge, extract, hierarchical)")
    print("  • Conversation-aware turn-based pruning")
    print("  • Tool definition compression")
    print("  • Combined message + tool optimization")
    print("  • Token estimation utilities")
    print("  • Configuration presets")
    print("  • Debugging with snapshots")


if __name__ == "__main__":
    main()
