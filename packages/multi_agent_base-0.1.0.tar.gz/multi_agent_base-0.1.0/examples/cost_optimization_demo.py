#!/usr/bin/env python3
"""
Cost Optimization Engine Demo

Demonstrates the comprehensive cost management features:
- Budget management with limits and alerts
- Cost-optimized model selection
- Cost estimation and prediction
- Cost analysis and reporting
"""

from __future__ import annotations

import random
from datetime import datetime, timedelta, timezone


def demo_budget_management():
    """Demonstrate budget management features."""
    print("\n" + "=" * 60)
    print("BUDGET MANAGEMENT DEMO")
    print("=" * 60)
    
    from multi_agent_base.cost import (
        BudgetManager,
        BudgetLimit,
        BudgetPeriod,
        BudgetAction,
        AlertSeverity,
    )
    
    # Create manager with alert handler
    alerts_received = []
    
    def on_alert(alert):
        alerts_received.append(alert)
        severity_icon = {
            AlertSeverity.INFO: "ℹ️",
            AlertSeverity.WARNING: "⚠️",
            AlertSeverity.CRITICAL: "🚨",
        }
        icon = severity_icon.get(alert.severity, "📢")
        print(f"  {icon} ALERT: {alert.message}")
    
    manager = BudgetManager()
    manager.add_alert_handler(on_alert)
    
    # Add budget limits
    print("\n1. Setting up budget limits...")
    
    manager.add_limit(BudgetLimit(
        name="daily_budget",
        amount=100.0,
        period=BudgetPeriod.DAILY,
        action=BudgetAction.WARN,
        alert_thresholds=[0.5, 0.75, 0.9],
    ))
    print("   ✓ Daily budget: $100 (warn when exceeded)")
    
    manager.add_limit(BudgetLimit(
        name="monthly_budget",
        amount=2000.0,
        period=BudgetPeriod.MONTHLY,
        action=BudgetAction.BLOCK,
        alert_thresholds=[0.8, 0.95],
    ))
    print("   ✓ Monthly budget: $2000 (block when exceeded)")
    
    # Check initial status
    print("\n2. Initial budget status:")
    status = manager.check_budget("global")
    print(f"   Current usage: ${status.current_usage:.2f}")
    print(f"   Remaining: ${status.remaining:.2f}")
    print(f"   Action: {status.action.value}")
    
    # Simulate usage
    print("\n3. Simulating API usage...")
    costs = [15.0, 20.0, 25.0, 30.0, 15.0]
    total = 0
    
    for i, cost in enumerate(costs, 1):
        total += cost
        print(f"\n   Recording usage #{i}: ${cost:.2f}")
        manager.record_usage("global", cost)
        
        status = manager.check_budget("global")
        print(f"   → Total: ${total:.2f}, Remaining: ${status.remaining:.2f}")
    
    # Check budget before large operation
    print("\n4. Checking budget for large operation ($50)...")
    status = manager.check_budget("global", 50.0)
    print(f"   Would exceed: {status.is_exceeded}")
    print(f"   Recommended action: {status.action.value}")
    
    # Summary
    print(f"\n5. Summary:")
    print(f"   Total alerts triggered: {len(alerts_received)}")
    for alert in alerts_received:
        print(f"   - [{alert.severity.value}] {alert.limit_name}: {alert.percentage:.1f}%")


def demo_model_selection():
    """Demonstrate model selection features."""
    print("\n" + "=" * 60)
    print("MODEL SELECTION DEMO")
    print("=" * 60)
    
    from multi_agent_base.cost import (
        ModelSelector,
        SelectionCriteria,
        OptimizationGoal,
        TaskComplexity,
    )
    
    selector = ModelSelector()
    
    # Cost optimization
    print("\n1. Cost-optimized selection:")
    result = selector.select(SelectionCriteria(
        goal=OptimizationGoal.COST,
        min_quality=70,
    ))
    print(f"   Selected: {result.selected_model.name}")
    print(f"   Provider: {result.selected_model.provider}")
    print(f"   Cost: ${result.selected_model.avg_cost:.2f}/1M tokens")
    print(f"   Quality: {result.selected_model.quality_score}/100")
    print(f"   Reason: {result.reason}")
    
    # Quality optimization
    print("\n2. Quality-optimized selection:")
    result = selector.select(SelectionCriteria(
        goal=OptimizationGoal.QUALITY,
    ))
    print(f"   Selected: {result.selected_model.name}")
    print(f"   Provider: {result.selected_model.provider}")
    print(f"   Cost: ${result.selected_model.avg_cost:.2f}/1M tokens")
    print(f"   Quality: {result.selected_model.quality_score}/100")
    
    # Balanced optimization
    print("\n3. Balanced selection (with constraints):")
    result = selector.select(SelectionCriteria(
        goal=OptimizationGoal.BALANCED,
        min_quality=85,
        max_latency_ms=600,
        required_capabilities=["function_calling"],
    ))
    print(f"   Selected: {result.selected_model.name}")
    print(f"   Cost: ${result.selected_model.avg_cost:.2f}/1M")
    print(f"   Quality: {result.selected_model.quality_score}")
    print(f"   Latency: {result.selected_model.latency_ms}ms")
    print(f"   Capabilities: {', '.join(result.selected_model.capabilities)}")
    
    # Task complexity selection
    print("\n4. Task complexity-based selection:")
    
    for complexity in TaskComplexity:
        result = selector.select_for_complexity(complexity)
        print(f"   {complexity.value:10s} → {result.selected_model.name:25s} "
              f"(quality: {result.selected_model.quality_score}, "
              f"cost: ${result.selected_model.avg_cost:.2f})")
    
    # Budget-based selection
    print("\n5. Budget-based selection:")
    result = selector.select_for_budget(
        budget=0.10,
        estimated_tokens=100000,
        min_quality=75,
    )
    print(f"   Budget: $0.10 for 100K tokens")
    print(f"   Selected: {result.selected_model.name}")
    print(f"   Estimated cost: ${result.selected_model.estimate_cost(50000, 50000):.4f}")
    
    # Compare models
    print("\n6. Model comparison for 10K input + 5K output tokens:")
    comparisons = selector.compare_models(
        model_names=["gpt-4o", "gpt-4o-mini", "claude-3-5-sonnet-20241022", "gemini-1.5-flash"],
        input_tokens=10000,
        output_tokens=5000,
    )
    
    print("   Model                         | Est. Cost | Quality | Efficiency")
    print("   " + "-" * 65)
    for c in comparisons:
        print(f"   {c['name']:30s} | ${c['estimated_cost']:.4f}  | {c['quality']:6} | "
              f"{c['cost_efficiency']:.1f}")


def demo_cost_estimation():
    """Demonstrate cost estimation features."""
    print("\n" + "=" * 60)
    print("COST ESTIMATION DEMO")
    print("=" * 60)
    
    from multi_agent_base.cost import CostEstimator
    
    estimator = CostEstimator()
    
    # Basic estimation
    print("\n1. Basic cost estimation:")
    estimate = estimator.estimate(
        model="gpt-4o",
        input_text="What is machine learning? Explain in detail with examples.",
        expected_output_tokens=1000,
    )
    print(f"   Model: {estimate.model}")
    print(f"   Input tokens: ~{estimate.input_tokens}")
    print(f"   Output tokens: {estimate.output_tokens}")
    print(f"   Estimated cost: ${estimate.estimated_cost:.4f}")
    print(f"   Confidence: {estimate.confidence:.0%}")
    print(f"   Breakdown:")
    print(f"     - Input: ${estimate.breakdown.get('input_cost', 0):.6f}")
    print(f"     - Output: ${estimate.breakdown.get('output_cost', 0):.6f}")
    
    # Batch estimation
    print("\n2. Batch estimation (100 queries):")
    queries = [
        f"Query {i}: What is {topic}?"
        for i, topic in enumerate([
            "AI", "ML", "NLP", "Computer Vision", "Deep Learning"
        ] * 20)
    ]
    
    estimate = estimator.estimate_batch(
        model="gpt-4o-mini",
        items=queries,
        expected_output_per_item=200,
    )
    print(f"   Total queries: {len(queries)}")
    print(f"   Total input tokens: ~{estimate.input_tokens}")
    print(f"   Total output tokens: {estimate.output_tokens}")
    print(f"   Estimated total cost: ${estimate.estimated_cost:.4f}")
    
    # Cost comparison
    print("\n3. Cost comparison across models (1K input, 500 output):")
    estimates = estimator.compare_costs(
        input_tokens=1000,
        output_tokens=500,
    )
    
    print("   Model                         | Cost")
    print("   " + "-" * 45)
    for est in estimates[:5]:
        print(f"   {est.model:30s} | ${est.estimated_cost:.6f}")


def demo_cost_analysis():
    """Demonstrate cost analysis features."""
    print("\n" + "=" * 60)
    print("COST ANALYSIS DEMO")
    print("=" * 60)
    
    from multi_agent_base.cost import (
        CostAnalyzer,
        CostDataPoint,
        TimeGranularity,
    )
    
    analyzer = CostAnalyzer()
    
    # Generate sample data
    print("\n1. Generating sample cost data (30 days)...")
    now = datetime.now(timezone.utc)
    models = ["gpt-4o", "gpt-4o-mini", "claude-3-5-sonnet-20241022"]
    operations = ["chat", "analysis", "code_generation", "summarization"]
    
    for i in range(500):
        # Simulate increasing trend
        base_cost = 0.05 + (i / 500) * 0.03
        cost = base_cost + random.uniform(-0.02, 0.02)
        
        # Add occasional anomalies
        if random.random() < 0.02:
            cost *= 5  # Anomaly
        
        analyzer.add_data_point(CostDataPoint(
            timestamp=now - timedelta(hours=i),
            cost=max(0.01, cost),
            model=random.choice(models),
            tokens_input=random.randint(500, 2000),
            tokens_output=random.randint(200, 1000),
            operation=random.choice(operations),
        ))
    
    print(f"   Added {len(analyzer.data_points)} data points")
    
    # Calculate totals
    print("\n2. Cost calculations:")
    total = analyzer.calculate_total()
    print(f"   Total cost: ${total:.2f}")
    
    for model in models:
        model_total = analyzer.calculate_total(model=model)
        print(f"   {model}: ${model_total:.2f}")
    
    # Trend analysis
    print("\n3. Trend analysis:")
    trend = analyzer.analyze_trend()
    if trend:
        direction_icon = {
            "increasing": "📈",
            "decreasing": "📉",
            "stable": "➡️",
        }
        icon = direction_icon.get(trend.direction.value, "")
        print(f"   Direction: {icon} {trend.direction.value}")
        print(f"   Change: {trend.change_percent:+.1f}%")
        print(f"   Avg daily cost: ${trend.avg_daily_cost:.2f}")
        print(f"   Projected monthly: ${trend.projected_cost:.2f}")
    
    # Model breakdown
    print("\n4. Cost breakdown by model:")
    breakdown = analyzer.breakdown_by_model()
    for m in breakdown:
        print(f"   {m.model}:")
        print(f"     - Total: ${m.total_cost:.2f} ({m.percentage_of_total:.1f}%)")
        print(f"     - Requests: {m.request_count}")
        print(f"     - Avg/request: ${m.avg_cost_per_request:.4f}")
    
    # Operation breakdown
    print("\n5. Cost breakdown by operation:")
    breakdown = analyzer.breakdown_by_operation()
    for o in breakdown:
        print(f"   {o.operation}: ${o.total_cost:.2f} ({o.percentage_of_total:.1f}%)")
    
    # Anomaly detection
    print("\n6. Detected anomalies:")
    anomalies = analyzer.detect_anomalies()
    if anomalies:
        for a in anomalies[:5]:  # Show top 5
            print(f"   [{a.severity.upper():8s}] Expected ${a.expected_cost:.4f}, "
                  f"got ${a.actual_cost:.4f} ({a.deviation_percent:+.1f}%)")
    else:
        print("   No anomalies detected")
    
    # Time series
    print("\n7. Daily time series (last 7 days):")
    series = analyzer.get_time_series(TimeGranularity.DAILY)
    for point in series[-7:]:
        print(f"   {point['period']}: ${point['cost']:.2f} ({point['requests']} requests)")
    
    # Generate report
    print("\n8. Generating comprehensive report...")
    report = analyzer.generate_report()
    
    print(f"\n   📊 COST REPORT SUMMARY")
    print(f"   " + "-" * 40)
    print(f"   Period: {report.days_in_period:.0f} days")
    print(f"   Total cost: ${report.total_cost:.2f}")
    print(f"   Total requests: {report.total_requests:,}")
    print(f"   Avg cost/request: ${report.avg_cost_per_request:.4f}")
    print(f"   Avg daily cost: ${report.avg_daily_cost:.2f}")
    
    if report.recommendations:
        print(f"\n   💡 RECOMMENDATIONS:")
        for r in report.recommendations[:3]:
            print(f"   [{r.priority}] {r.title}")
            print(f"       Potential savings: ${r.potential_savings:.2f}/month")


def demo_complete_workflow():
    """Demonstrate complete cost optimization workflow."""
    print("\n" + "=" * 60)
    print("COMPLETE WORKFLOW DEMO")
    print("=" * 60)
    
    from multi_agent_base.cost import (
        BudgetManager,
        BudgetLimit,
        BudgetPeriod,
        BudgetAction,
        ModelSelector,
        SelectionCriteria,
        OptimizationGoal,
        TaskComplexity,
        CostEstimator,
        CostAnalyzer,
        CostDataPoint,
    )
    
    # Initialize components
    print("\n1. Initializing cost optimization system...")
    
    budget_manager = BudgetManager()
    budget_manager.add_limit(BudgetLimit(
        name="session",
        amount=1.0,  # $1 session budget
        period=BudgetPeriod.TOTAL,
        action=BudgetAction.WARN,
        alert_thresholds=[0.5, 0.8],
    ))
    
    selector = ModelSelector()
    estimator = CostEstimator(selector=selector)
    analyzer = CostAnalyzer()
    
    print("   ✓ Budget manager configured ($1 session limit)")
    print("   ✓ Model selector ready (11 models)")
    print("   ✓ Cost estimator ready")
    print("   ✓ Cost analyzer ready")
    
    # Simulate a series of operations
    print("\n2. Simulating AI operations...")
    
    tasks = [
        ("simple", "What is 2+2?", TaskComplexity.SIMPLE),
        ("moderate", "Explain quantum computing", TaskComplexity.MODERATE),
        ("complex", "Analyze this codebase", TaskComplexity.COMPLEX),
        ("expert", "Write a research paper outline", TaskComplexity.EXPERT),
        ("simple", "Summarize this text", TaskComplexity.SIMPLE),
    ]
    
    session_cost = 0.0
    
    for i, (task_name, prompt, complexity) in enumerate(tasks, 1):
        print(f"\n   Task {i}: {task_name} ({complexity.value})")
        
        # Select model
        result = selector.select_for_complexity(complexity)
        model = result.selected_model
        print(f"   → Selected: {model.name}")
        
        # Estimate cost
        estimate = estimator.estimate(
            model=model.name,
            input_text=prompt,
            expected_output_tokens=300,
        )
        print(f"   → Estimated: ${estimate.estimated_cost:.4f}")
        
        # Check budget
        status = budget_manager.check_budget("global", estimate.estimated_cost)
        if status.action == BudgetAction.BLOCK:
            print(f"   ⛔ Blocked: Budget exceeded!")
            continue
        
        # Simulate execution (would call LLM here)
        actual_cost = estimate.estimated_cost * random.uniform(0.9, 1.1)
        
        # Record usage
        budget_manager.record_usage("global", actual_cost)
        analyzer.add_data_point(CostDataPoint(
            timestamp=datetime.now(timezone.utc),
            cost=actual_cost,
            model=model.name,
            tokens_input=estimate.input_tokens,
            tokens_output=estimate.output_tokens,
            operation=task_name,
        ))
        
        session_cost += actual_cost
        print(f"   ✓ Executed (${actual_cost:.4f})")
        print(f"   → Session total: ${session_cost:.4f}")
    
    # Final summary
    print("\n3. Session summary:")
    status = budget_manager.check_budget("global")
    print(f"   Total spent: ${session_cost:.4f}")
    print(f"   Budget used: {status.percentage_used:.1f}%")
    print(f"   Remaining: ${status.remaining:.4f}")
    
    # Generate report
    report = analyzer.generate_report()
    print(f"\n4. Quick analytics:")
    print(f"   Operations: {report.total_requests}")
    print(f"   Avg cost/op: ${report.avg_cost_per_request:.4f}")
    
    if report.model_breakdown:
        print(f"\n   By model:")
        for m in report.model_breakdown:
            print(f"   - {m.model}: ${m.total_cost:.4f} ({m.request_count} ops)")


def main():
    """Run all demos."""
    print("=" * 60)
    print("COST OPTIMIZATION ENGINE - COMPREHENSIVE DEMO")
    print("=" * 60)
    print("\nThis demo showcases the cost optimization features:")
    print("• Budget management with limits and alerts")
    print("• Intelligent model selection")
    print("• Cost estimation and prediction")
    print("• Cost analysis and reporting")
    print("• Complete workflow integration")
    
    try:
        demo_budget_management()
        demo_model_selection()
        demo_cost_estimation()
        demo_cost_analysis()
        demo_complete_workflow()
        
        print("\n" + "=" * 60)
        print("DEMO COMPLETED SUCCESSFULLY")
        print("=" * 60)
        print("\nAll cost optimization features demonstrated!")
        print("See docs/cost_optimization.md for detailed documentation.")
        
    except Exception as e:
        print(f"\n❌ Demo failed: {e}")
        import traceback
        traceback.print_exc()
        return 1
    
    return 0


if __name__ == "__main__":
    exit(main())
