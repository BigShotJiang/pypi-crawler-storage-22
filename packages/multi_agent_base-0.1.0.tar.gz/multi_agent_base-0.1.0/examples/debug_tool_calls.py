#!/usr/bin/env python3
"""Debug tool calls from Ollama."""

import asyncio
import ollama


async def main():
    client = ollama.AsyncClient()
    
    tools = [
        {
            "type": "function",
            "function": {
                "name": "calculate",
                "description": "Evaluate a math expression",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "expression": {"type": "string", "description": "Math expression"}
                    },
                    "required": ["expression"]
                }
            }
        },
        {
            "type": "function",
            "function": {
                "name": "get_current_time",
                "description": "Get current date and time",
                "parameters": {"type": "object", "properties": {}, "required": []}
            }
        },
    ]
    
    messages = [
        {"role": "system", "content": "You are a helpful assistant with access to tools."},
        {"role": "user", "content": "What is 25 * 4?"}
    ]
    
    print("Calling Ollama with tools...")
    
    response = await client.chat(
        model="qwen2.5-coder:7b",
        messages=messages,
        tools=tools,
    )
    
    print("\n=== Full Response ===")
    print(response)
    
    print("\n=== Message ===")
    print(response.get("message", {}))
    
    print("\n=== Tool Calls ===")
    print(response.get("message", {}).get("tool_calls", []))


if __name__ == "__main__":
    asyncio.run(main())
