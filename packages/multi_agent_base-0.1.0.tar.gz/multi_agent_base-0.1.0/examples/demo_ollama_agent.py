#!/usr/bin/env python3
"""
Simple Ollama Agent Demo

This example demonstrates using Multi-Agent Base with a local Ollama model.
No API keys required - runs completely locally!

Prerequisites:
- Ollama running locally (ollama serve)
- A model pulled (e.g., ollama pull llama3)

Usage:
    PYTHONPATH=src python examples/demo_ollama_agent.py
"""

import asyncio
from multi_agent_base.core.agent import BaseAgent, Tool
from multi_agent_base.core.config import AgentConfig, ProviderConfig, ProviderType


# =============================================================================
# Define Tools
# =============================================================================

def calculate(expression: str) -> str:
    """
    Safely evaluate a mathematical expression.
    
    Args:
        expression: A math expression like "2 + 2" or "10 * 5"
    
    Returns:
        The result as a string
    """
    try:
        # Only allow safe math operations
        allowed_chars = set("0123456789+-*/.() ")
        if not all(c in allowed_chars for c in expression):
            return f"Error: Invalid characters in expression"
        
        result = eval(expression)
        return f"Result: {result}"
    except Exception as e:
        return f"Error: {e}"


def get_current_time() -> str:
    """Get the current date and time."""
    from datetime import datetime
    now = datetime.now()
    return f"Current time: {now.strftime('%Y-%m-%d %H:%M:%S')}"


def greet(name: str) -> str:
    """
    Greet someone by name.
    
    Args:
        name: The person's name to greet
    
    Returns:
        A friendly greeting
    """
    return f"Hello, {name}! Nice to meet you! 👋"


# =============================================================================
# Create Agent
# =============================================================================

async def main():
    print("=" * 60)
    print("🤖 Multi-Agent Base - Ollama Demo")
    print("=" * 60)
    print()
    
    # Configure for Ollama
    provider_config = ProviderConfig(
        provider=ProviderType.OLLAMA,
        model="llama3",  # Using llama3 model
        base_url="http://localhost:11434",
        temperature=0.7,
    )
    
    agent_config = AgentConfig(
        name="ollama-assistant",
        system_prompt="""You are a helpful AI assistant running locally via Ollama.
You have access to tools that you can use to help the user.

Available tools:
- calculate: Evaluate math expressions
- get_current_time: Get the current date and time  
- greet: Greet someone by name

When the user asks you to do something that requires a tool, use it.
Be concise and helpful in your responses.""",
    )
    
    # Create tools
    tools = [
        Tool(
            name="calculate",
            description="Evaluate a mathematical expression safely. Use this when the user asks for calculations.",
            function=calculate,
            parameters={
                "type": "object",
                "properties": {
                    "expression": {
                        "type": "string",
                        "description": "The math expression to evaluate, e.g., '2 + 2' or '10 * 5'"
                    }
                },
                "required": ["expression"]
            }
        ),
        Tool(
            name="get_current_time",
            description="Get the current date and time. Use when user asks about the time.",
            function=get_current_time,
            parameters={
                "type": "object",
                "properties": {},
                "required": []
            }
        ),
        Tool(
            name="greet",
            description="Greet someone by their name.",
            function=greet,
            parameters={
                "type": "object",
                "properties": {
                    "name": {
                        "type": "string",
                        "description": "The name of the person to greet"
                    }
                },
                "required": ["name"]
            }
        ),
    ]
    
    # Create the agent
    agent = BaseAgent(
        name="ollama-assistant",
        config=agent_config,
        provider_config=provider_config,
        tools=tools,
    )
    
    print(f"✅ Agent created: {agent.name}")
    print(f"📦 Model: {provider_config.model}")
    print(f"🔧 Tools: {[t.name for t in tools]}")
    print()
    print("-" * 60)
    print()
    
    # Interactive loop
    print("💬 Start chatting! Type 'quit' to exit.")
    print()
    
    while True:
        try:
            user_input = input("You: ").strip()
            
            if not user_input:
                continue
            
            if user_input.lower() in ["quit", "exit", "q"]:
                print("\n👋 Goodbye!")
                break
            
            print("\n🤔 Thinking...\n")
            
            response = await agent.run(user_input)
            
            print(f"🤖 Assistant: {response.content}")
            
            if response.tool_calls:
                print(f"\n   📋 Tools used: {[tc.get('name', 'unknown') for tc in response.tool_calls]}")
            
            if response.usage:
                tokens = response.usage.get("total_tokens", 0)
                if tokens:
                    print(f"   📊 Tokens: {tokens}")
            
            print()
            
        except KeyboardInterrupt:
            print("\n\n👋 Goodbye!")
            break
        except Exception as e:
            print(f"\n❌ Error: {e}\n")


if __name__ == "__main__":
    asyncio.run(main())
