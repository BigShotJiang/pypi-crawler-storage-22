#!/usr/bin/env python3
"""
DevUI with Ollama Agent Example.

This demonstrates how to use Agent Framework DevUI with Ollama models
for an interactive debugging and testing experience.

Run this script to start the DevUI server, then open http://localhost:8080 in your browser.
"""

import os
from datetime import datetime

from agent_framework.ollama import OllamaChatClient
from agent_framework import ChatAgent, tool
from agent_framework.devui import serve
from agent_framework.observability import configure_otel_providers

# Import OpenTelemetry OTLP exporters for Aspire Dashboard
from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
from opentelemetry.exporter.otlp.proto.grpc._log_exporter import OTLPLogExporter
from opentelemetry.exporter.otlp.proto.grpc.metric_exporter import OTLPMetricExporter


# Define tools with approval_mode="never_require" for demo purposes
@tool(approval_mode="never_require")
def calculate(expression: str) -> str:
    """Evaluate a mathematical expression.
    
    Args:
        expression: A mathematical expression like "2 + 2" or "10 * 5"
    
    Returns:
        The result of the calculation
    """
    try:
        # Safety check: only allow math characters
        allowed_chars = set("0123456789+-*/.() ")
        if not all(c in allowed_chars for c in expression):
            return f"Error: Invalid characters in expression"
        result = eval(expression)
        return f"{expression} = {result}"
    except Exception as e:
        return f"Error calculating '{expression}': {e}"


@tool(approval_mode="never_require")
def get_current_time() -> str:
    """Get the current date and time.
    
    Returns:
        The current date and time in a readable format
    """
    return f"Current time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"


@tool(approval_mode="never_require")
def get_weather(city: str) -> str:
    """Get the weather for a city.
    
    Args:
        city: The name of the city
    
    Returns:
        A mock weather report for the city
    """
    import random
    conditions = ["sunny", "cloudy", "rainy", "windy", "snowy"]
    temp = random.randint(-5, 35)
    condition = random.choice(conditions)
    return f"Weather in {city}: {temp}°C, {condition}"


def main():
    print("=" * 60)
    print("🚀 Agent Framework DevUI with Ollama + Aspire Dashboard")
    print("=" * 60)
    print()
    
    # Enable observability/telemetry with Aspire Dashboard
    print("🔭 Setting up observability with Aspire Dashboard...")
    
    # Configure OTLP exporters for Aspire Dashboard (port 4317 -> 18889)
    otlp_endpoint = "http://localhost:4317"
    
    configure_otel_providers(
        enable_sensitive_data=True,  # Show prompts/responses (dev only!)
        exporters=[
            OTLPSpanExporter(endpoint=otlp_endpoint, insecure=True),
            OTLPLogExporter(endpoint=otlp_endpoint, insecure=True),
            OTLPMetricExporter(endpoint=otlp_endpoint, insecure=True),
        ],
    )
    
    print(f"✅ Observability enabled - traces sent to Aspire Dashboard")
    print(f"   📊 Open http://localhost:18888 to view traces")
    print()
    
    # Check available Ollama models
    model_id = "qwen2.5-coder:7b"  # Use a model you have installed
    
    print(f"📦 Using model: {model_id}")
    print()
    
    # Create the Ollama Chat Client
    ollama_client = OllamaChatClient(
        host="http://localhost:11434",
        model_id=model_id,
    )
    
    # Create the agent using ChatAgent with tools
    agent = ChatAgent(
        chat_client=ollama_client,
        name="OllamaAssistant",
        description="A helpful AI assistant powered by Ollama with local LLM",
        instructions="""You are a helpful AI assistant running locally via Ollama.
        
You have access to the following tools:
- calculate: Evaluate mathematical expressions
- get_current_time: Get the current date and time
- get_weather: Get the weather for a city

When a user asks a question that can be answered with a tool, use the appropriate tool.
Be concise and friendly in your responses.""",
        tools=[calculate, get_current_time, get_weather],
    )
    
    print(f"✅ Agent created: {agent.name}")
    print(f"🔧 Tools: calculate, get_current_time, get_weather")
    print()
    print("🌐 Starting DevUI server...")
    print("   Open http://localhost:8080 in your browser")
    print("   Press Ctrl+C to stop")
    print()
    
    # Start DevUI server with the agent
    serve(
        entities=[agent],
        port=8080,
        host="127.0.0.1",
        auto_open=True,  # Automatically open browser
        mode="developer",  # Full access mode
        instrumentation_enabled=True,  # Enable trace collection in DevUI
    )


if __name__ == "__main__":
    main()
