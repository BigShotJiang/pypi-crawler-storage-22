#!/usr/bin/env python3
"""
HITL (Human-in-the-Loop) Framework Demo

Bu demo, HITL framework'ünün temel özelliklerini gösterir:
1. Approval System - Kritik operasyonlar için insan onayı
2. Checkpoint System - İş akışını durdurup devam ettirme
3. Audit System - Tüm kararların kaydedilmesi

Kullanım:
    python examples/hitl_demo.py
"""

import asyncio
from datetime import datetime

from multi_agent_base.hitl import (
    # Approval
    ApprovalHandler,
    ApprovalResponse,
    ApprovalStatus,
    require_approval,
    conditional_approval,
    # Checkpoints
    Checkpoint,
    CheckpointManager,
    CheckpointStatus,
    # Audit
    AuditEntry,
    AuditLogger,
    AuditDecision,
    create_audit_logger,
)


# =============================================================================
# Demo 1: Basic Approval System
# =============================================================================

async def demo_basic_approval():
    """Temel onay sistemi demosu."""
    print("\n" + "=" * 60)
    print("Demo 1: Basic Approval System")
    print("=" * 60)
    
    # Auto-approve handler (testing mode)
    handler = ApprovalHandler(auto_approve=True)
    
    # Request approval
    response = await handler.request_approval(
        action="delete_user",
        reason="User requested account deletion",
        context={
            "user_id": "user_123",
            "email": "user@example.com",
        },
    )
    
    print(f"\nAction: delete_user")
    print(f"Status: {response.status.value}")
    print(f"Approved: {response.is_approved}")
    print(f"Approver: {response.approver}")
    print(f"Reason: {response.reason}")


# =============================================================================
# Demo 2: Approval with Callbacks
# =============================================================================

async def demo_approval_callbacks():
    """Callback'li onay sistemi demosu."""
    print("\n" + "=" * 60)
    print("Demo 2: Approval with Callbacks")
    print("=" * 60)
    
    handler = ApprovalHandler(auto_approve=True)
    audit_log = []
    
    @handler.on_approved
    async def log_approval(action, context):
        audit_log.append({
            "type": "approved",
            "action": action,
            "timestamp": datetime.now().isoformat(),
        })
        print(f"[CALLBACK] Action '{action}' was approved!")
    
    @handler.on_rejected
    async def log_rejection(action, context):
        audit_log.append({
            "type": "rejected",
            "action": action,
            "timestamp": datetime.now().isoformat(),
        })
        print(f"[CALLBACK] Action '{action}' was rejected!")
    
    # Make requests
    await handler.request_approval(
        action="publish_article",
        reason="Article ready for publication",
    )
    
    print(f"\nAudit log entries: {len(audit_log)}")
    for entry in audit_log:
        print(f"  - {entry['type']}: {entry['action']}")


# =============================================================================
# Demo 3: Decorator-based Approval
# =============================================================================

async def demo_decorator_approval():
    """Dekoratör tabanlı onay sistemi demosu."""
    print("\n" + "=" * 60)
    print("Demo 3: Decorator-based Approval")
    print("=" * 60)
    
    # Handler for testing (auto-approve)
    test_handler = ApprovalHandler(auto_approve=True)
    
    @require_approval(
        handler=test_handler,
        reason="Critical database operation",
        timeout=30,
    )
    async def delete_all_records():
        """Tüm kayıtları sil (onay gerektirir)."""
        print("  [EXECUTING] Deleting all records...")
        return {"deleted": 1000}
    
    # Call the function - will auto-approve
    result = await delete_all_records()
    print(f"\nResult: {result}")


# =============================================================================
# Demo 4: Conditional Approval
# =============================================================================

async def demo_conditional_approval():
    """Koşullu onay sistemi demosu."""
    print("\n" + "=" * 60)
    print("Demo 4: Conditional Approval")
    print("=" * 60)
    
    test_handler = ApprovalHandler(auto_approve=True)
    
    @conditional_approval(
        handler=test_handler,
        condition=lambda ctx: ctx.get("amount", 0) > 1000,
        reason="Large transaction requires approval",
    )
    async def process_payment(amount: float) -> dict:
        """Ödeme işle (büyük işlemler için onay gerektirir)."""
        print(f"  [EXECUTING] Processing payment: ${amount}")
        return {"status": "completed", "amount": amount}
    
    # Small payment - no approval needed
    print("\nSmall payment ($500):")
    result1 = await process_payment(amount=500)
    print(f"  Result: {result1}")
    
    # Large payment - requires approval
    print("\nLarge payment ($5000):")
    result2 = await process_payment(amount=5000)
    print(f"  Result: {result2}")


# =============================================================================
# Demo 5: Checkpoint System
# =============================================================================

async def demo_checkpoints():
    """Checkpoint sistemi demosu."""
    print("\n" + "=" * 60)
    print("Demo 5: Checkpoint System")
    print("=" * 60)
    
    manager = CheckpointManager()
    
    # Create a checkpoint
    cp = manager.create_checkpoint(
        name="review_results",
        workflow_id="analysis_workflow",
        step_name="analyze_data",
    )
    
    print(f"\nCheckpoint created:")
    print(f"  ID: {cp.checkpoint_id[:8]}...")
    print(f"  Name: {cp.name}")
    print(f"  Workflow: {cp.workflow_id}")
    print(f"  Status: {cp.status.value}")
    
    # Register resume callback
    @cp.on_resume
    async def handle_resume(data):
        print(f"  [CALLBACK] Resumed with data: {data}")
    
    # Simulate resume in background
    async def resume_later():
        await asyncio.sleep(0.1)
        await cp.resume(data={"approved": True, "reviewer": "admin"})
    
    asyncio.create_task(resume_later())
    
    # Pause and wait for resume
    print("\n  Pausing checkpoint...")
    resume_data = await cp.pause(
        state={"step": 1, "data": "analysis_results"},
        timeout=5.0,
    )
    
    print(f"\nCheckpoint resumed!")
    print(f"  Status: {cp.status.value}")
    print(f"  Resume data: {resume_data}")


# =============================================================================
# Demo 6: Checkpoint Manager
# =============================================================================

async def demo_checkpoint_manager():
    """Checkpoint manager demosu."""
    print("\n" + "=" * 60)
    print("Demo 6: Checkpoint Manager")
    print("=" * 60)
    
    manager = CheckpointManager()
    
    # Create multiple checkpoints
    cp1 = manager.create_checkpoint(
        name="step_1_complete",
        workflow_id="data_pipeline",
        step_name="load_data",
    )
    
    cp2 = manager.create_checkpoint(
        name="step_2_complete",
        workflow_id="data_pipeline",
        step_name="transform_data",
    )
    
    cp3 = manager.create_checkpoint(
        name="review_needed",
        workflow_id="other_workflow",
        step_name="review",
    )
    
    print(f"\nCreated 3 checkpoints")
    
    # Get checkpoints for a workflow
    pipeline_cps = manager.get_checkpoints_for_workflow("data_pipeline")
    print(f"\nCheckpoints for data_pipeline: {len(pipeline_cps)}")
    for cp in pipeline_cps:
        print(f"  - {cp.name} ({cp.step_name})")
    
    # Get by name
    found = manager.get_checkpoint_by_name("step_1_complete", workflow_id="data_pipeline")
    print(f"\nFound by name: {found.name if found else 'Not found'}")
    
    # Skip a checkpoint
    cp1.skip()
    print(f"\nSkipped cp1, status: {cp1.status.value}")


# =============================================================================
# Demo 7: Audit Logging
# =============================================================================

async def demo_audit_logging():
    """Audit logging demosu."""
    print("\n" + "=" * 60)
    print("Demo 7: Audit Logging")
    print("=" * 60)
    
    # Create logger with in-memory backend
    logger = AuditLogger()
    
    # Log various events
    await logger.log_approval(
        action="deploy_production",
        user="admin@example.com",
        context={"version": "2.0.0", "environment": "production"},
        reason="Approved after review",
    )
    
    await logger.log_rejection(
        action="delete_database",
        user="junior@example.com",
        reason="Insufficient permissions",
    )
    
    await logger.log_timeout(
        action="critical_update",
        context={"timeout_seconds": 30},
    )
    
    await logger.log_resume(
        action="paused_workflow:step_3",
        user="supervisor@example.com",
        context={"workflow_id": "wf_123"},
    )
    
    # Get all entries
    entries = await logger.get_all()
    print(f"\nTotal entries: {len(entries)}")
    
    for entry in entries:
        print(f"\n  [{entry.decision.value}] {entry.action}")
        print(f"    User: {entry.user or 'system'}")
        print(f"    Time: {entry.timestamp.strftime('%H:%M:%S')}")
    
    # Get statistics
    stats = await logger.get_stats()
    print(f"\nStatistics:")
    for key, value in stats.items():
        print(f"  {key}: {value}")


# =============================================================================
# Demo 8: Integrated HITL Workflow
# =============================================================================

async def demo_integrated_workflow():
    """Entegre HITL iş akışı demosu."""
    print("\n" + "=" * 60)
    print("Demo 8: Integrated HITL Workflow")
    print("=" * 60)
    
    # Setup
    handler = ApprovalHandler(auto_approve=True)
    manager = CheckpointManager()
    logger = AuditLogger()
    
    # Connect approval to audit
    @handler.on_approved
    async def audit_approval(action, context):
        await logger.log_approval(action=action, user="auto", context=context)
    
    @handler.on_rejected
    async def audit_rejection(action, context):
        await logger.log_rejection(action=action, user="auto", reason="Rejected")
    
    async def integrated_workflow():
        print("\n[WORKFLOW] Starting integrated workflow...")
        
        # Step 1: Request approval for critical action
        print("\n[STEP 1] Requesting approval for data processing...")
        response = await handler.request_approval(
            action="process_sensitive_data",
            reason="Need to process PII data",
            context={"data_type": "PII", "record_count": 500},
        )
        
        if not response.is_approved:
            print("  Workflow cancelled: approval denied")
            return
        
        print(f"  Approved by: {response.approver}")
        
        # Step 2: Create checkpoint
        print("\n[STEP 2] Creating checkpoint...")
        cp = manager.create_checkpoint(
            name="after_approval",
            workflow_id="integrated_workflow",
            step_name="process_data",
        )
        
        # Skip pause for demo
        cp.skip()
        print(f"  Checkpoint created and skipped (for demo)")
        
        # Step 3: Complete processing
        print("\n[STEP 3] Processing data...")
        await asyncio.sleep(0.1)
        
        print("\n[WORKFLOW] Completed successfully!")
        
        # Show audit trail
        entries = await logger.get_all()
        print(f"\n[AUDIT] {len(entries)} entries recorded:")
        for entry in entries:
            print(f"  - {entry.decision.value}: {entry.action}")
    
    await integrated_workflow()


# =============================================================================
# Main
# =============================================================================

async def main():
    """Tüm demoları çalıştır."""
    print("\n" + "=" * 60)
    print("HITL (Human-in-the-Loop) Framework Demo")
    print("=" * 60)
    print("""
Bu demo, HITL framework'ünün 3 temel bileşenini gösterir:

1. Approval System: Kritik operasyonlar için insan onayı
2. Checkpoint System: İş akışını durdurup devam ettirme
3. Audit System: Tüm kararların kaydedilmesi

Not: Demo auto-approve modunda çalışır (gerçek onay beklemez).
""")
    
    # Run all demos
    await demo_basic_approval()
    await demo_approval_callbacks()
    await demo_decorator_approval()
    await demo_conditional_approval()
    await demo_checkpoints()
    await demo_checkpoint_manager()
    await demo_audit_logging()
    await demo_integrated_workflow()
    
    print("\n" + "=" * 60)
    print("Demo tamamlandı!")
    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(main())
