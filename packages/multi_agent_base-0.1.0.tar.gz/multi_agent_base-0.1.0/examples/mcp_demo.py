#!/usr/bin/env python3
"""
MCP (Model Context Protocol) Demo.

This demo showcases the MCP module capabilities:
1. Server with tools, resources, and prompts
2. Direct request handling (simulated client)
3. Tool discovery and conversion
4. Async tool support

Run with:
    python examples/mcp_demo.py
"""

import asyncio
import json
from typing import Any, Dict

from multi_agent_base.mcp import (
    # Protocol types
    MCPRequest,
    MCPResponse,
    MCPError,
    MCPErrorCode,
    # Tool types
    MCPTool,
    MCPToolParameter,
    MCPToolResult,
    # Server
    MCPServer,
    # Discovery
    ToolDiscovery,
    DiscoveredTool,
    # Constants
    MCP_PROTOCOL_VERSION,
)


def print_header(title: str) -> None:
    """Print a formatted header."""
    print()
    print("=" * 60)
    print(f"  {title}")
    print("=" * 60)


def print_result(label: str, value: Any) -> None:
    """Print a formatted result."""
    if isinstance(value, dict):
        value = json.dumps(value, indent=2)
    print(f"\n{label}:")
    print(f"  {value}")


# =============================================================================
# Demo 1: Basic Server with Tools
# =============================================================================


async def demo_basic_server():
    """Demo basic server functionality with tools."""
    print_header("Demo 1: Basic MCP Server with Tools")
    
    # Create server
    server = MCPServer(name="demo-server", version="1.0.0")
    
    # Register tools using decorator
    @server.tool()
    def add(a: int, b: int) -> int:
        """Add two numbers together."""
        return a + b
    
    @server.tool()
    def multiply(a: int, b: int) -> int:
        """Multiply two numbers."""
        return a * b
    
    @server.tool()
    def greet(name: str, greeting: str = "Hello") -> str:
        """Greet a person with a custom greeting."""
        return f"{greeting}, {name}!"
    
    print(f"Server: {server.name} v{server.version}")
    print(f"Registered tools: {list(server.tools.keys())}")
    
    # Initialize server (required before handling requests)
    init_response = await server.handle_request(MCPRequest(
        method="initialize",
        params={
            "protocolVersion": MCP_PROTOCOL_VERSION,
            "capabilities": {},
            "clientInfo": {"name": "demo-client", "version": "1.0.0"},
        },
    ))
    
    print_result("Initialize response", {
        "serverInfo": init_response.result["serverInfo"],
        "protocolVersion": init_response.result["protocolVersion"],
    })
    
    # List tools
    list_response = await server.handle_request(MCPRequest(method="tools/list"))
    
    print_result("Available tools", len(list_response.result["tools"]))
    for tool in list_response.result["tools"]:
        print(f"  - {tool['name']}: {tool['description']}")
    
    # Call tools
    print("\n--- Calling Tools ---")
    
    # Add
    add_response = await server.handle_request(MCPRequest(
        method="tools/call",
        params={"name": "add", "arguments": {"a": 10, "b": 32}},
    ))
    print_result("add(10, 32)", add_response.result["content"][0]["text"])
    
    # Multiply
    mult_response = await server.handle_request(MCPRequest(
        method="tools/call",
        params={"name": "multiply", "arguments": {"a": 6, "b": 7}},
    ))
    print_result("multiply(6, 7)", mult_response.result["content"][0]["text"])
    
    # Greet with default
    greet_response = await server.handle_request(MCPRequest(
        method="tools/call",
        params={"name": "greet", "arguments": {"name": "World"}},
    ))
    print_result("greet('World')", greet_response.result["content"][0]["text"])
    
    # Greet with custom greeting
    greet2_response = await server.handle_request(MCPRequest(
        method="tools/call",
        params={"name": "greet", "arguments": {"name": "Alice", "greeting": "Welcome"}},
    ))
    print_result("greet('Alice', 'Welcome')", greet2_response.result["content"][0]["text"])


# =============================================================================
# Demo 2: Async Tools
# =============================================================================


async def demo_async_tools():
    """Demo async tool support."""
    print_header("Demo 2: Async Tools")
    
    server = MCPServer(name="async-server")
    
    @server.tool()
    async def slow_calculation(n: int) -> int:
        """Perform a slow calculation (simulated)."""
        await asyncio.sleep(0.1)  # Simulate work
        return n * n
    
    @server.tool()
    async def fetch_data(key: str) -> str:
        """Fetch data asynchronously (simulated)."""
        await asyncio.sleep(0.05)  # Simulate network
        data = {
            "user": {"name": "John", "email": "john@example.com"},
            "config": {"theme": "dark", "language": "en"},
        }
        return json.dumps(data.get(key, {}))
    
    # Initialize
    await server.handle_request(MCPRequest(
        method="initialize",
        params={
            "protocolVersion": MCP_PROTOCOL_VERSION,
            "capabilities": {},
            "clientInfo": {"name": "test", "version": "1.0"},
        },
    ))
    
    print("Testing async tools...")
    
    # Call async tool
    import time
    start = time.time()
    
    calc_response = await server.handle_request(MCPRequest(
        method="tools/call",
        params={"name": "slow_calculation", "arguments": {"n": 12}},
    ))
    
    elapsed = time.time() - start
    print_result(f"slow_calculation(12) [{elapsed:.3f}s]", calc_response.result["content"][0]["text"])
    
    # Fetch data
    fetch_response = await server.handle_request(MCPRequest(
        method="tools/call",
        params={"name": "fetch_data", "arguments": {"key": "user"}},
    ))
    print_result("fetch_data('user')", fetch_response.result["content"][0]["text"])


# =============================================================================
# Demo 3: Resources
# =============================================================================


async def demo_resources():
    """Demo resource serving."""
    print_header("Demo 3: Resources")
    
    server = MCPServer(name="resource-server")
    
    # Register resources
    @server.resource("config://app/settings")
    def get_settings() -> str:
        """Get application settings."""
        return json.dumps({
            "theme": "dark",
            "language": "en",
            "notifications": True,
        })
    
    @server.resource("config://app/version")
    def get_version() -> str:
        """Get application version."""
        return "2.1.0"
    
    # Static resource
    server.register_static_resource(
        uri="file://readme.md",
        content="# Demo App\n\nWelcome to the demo application!",
        name="README",
        description="Application readme file",
        mimeType="text/markdown",
    )
    
    # Initialize
    await server.handle_request(MCPRequest(
        method="initialize",
        params={
            "protocolVersion": MCP_PROTOCOL_VERSION,
            "capabilities": {},
            "clientInfo": {"name": "test", "version": "1.0"},
        },
    ))
    
    # List resources
    list_response = await server.handle_request(MCPRequest(method="resources/list"))
    
    print_result("Available resources", len(list_response.result["resources"]))
    for resource in list_response.result["resources"]:
        print(f"  - {resource['uri']}: {resource.get('name', 'N/A')}")
    
    # Read resources
    print("\n--- Reading Resources ---")
    
    settings_response = await server.handle_request(MCPRequest(
        method="resources/read",
        params={"uri": "config://app/settings"},
    ))
    print_result("config://app/settings", settings_response.result["contents"][0]["text"])
    
    version_response = await server.handle_request(MCPRequest(
        method="resources/read",
        params={"uri": "config://app/version"},
    ))
    print_result("config://app/version", version_response.result["contents"][0]["text"])
    
    readme_response = await server.handle_request(MCPRequest(
        method="resources/read",
        params={"uri": "file://readme.md"},
    ))
    print_result("file://readme.md", readme_response.result["contents"][0]["text"])


# =============================================================================
# Demo 4: Prompts
# =============================================================================


async def demo_prompts():
    """Demo prompt templates."""
    print_header("Demo 4: Prompt Templates")
    
    server = MCPServer(name="prompt-server")
    
    @server.prompt()
    def code_review(code: str, language: str = "python") -> str:
        """Review code for issues and improvements."""
        return f"""Please review this {language} code:

```{language}
{code}
```

Focus on:
1. Potential bugs
2. Performance issues
3. Code style
4. Security concerns"""
    
    @server.prompt()
    def summarize(text: str, max_words: int = 100) -> str:
        """Summarize text to specified length."""
        return f"Summarize the following text in {max_words} words or less:\n\n{text}"
    
    # Initialize
    await server.handle_request(MCPRequest(
        method="initialize",
        params={
            "protocolVersion": MCP_PROTOCOL_VERSION,
            "capabilities": {},
            "clientInfo": {"name": "test", "version": "1.0"},
        },
    ))
    
    # List prompts
    list_response = await server.handle_request(MCPRequest(method="prompts/list"))
    
    print_result("Available prompts", len(list_response.result["prompts"]))
    for prompt in list_response.result["prompts"]:
        print(f"  - {prompt['name']}: {prompt.get('description', 'N/A')}")
    
    # Get prompts
    print("\n--- Getting Prompts ---")
    
    review_response = await server.handle_request(MCPRequest(
        method="prompts/get",
        params={
            "name": "code_review",
            "arguments": {
                "code": "def add(a, b):\n    return a + b",
                "language": "python",
            },
        },
    ))
    print_result("code_review prompt", review_response.result["messages"][0]["content"]["text"])
    
    summarize_response = await server.handle_request(MCPRequest(
        method="prompts/get",
        params={
            "name": "summarize",
            "arguments": {
                "text": "AI is transforming how we work and live...",
                "max_words": 50,
            },
        },
    ))
    print_result("summarize prompt", summarize_response.result["messages"][0]["content"]["text"])


# =============================================================================
# Demo 5: Error Handling
# =============================================================================


async def demo_error_handling():
    """Demo error handling."""
    print_header("Demo 5: Error Handling")
    
    server = MCPServer(name="error-server")
    
    @server.tool()
    def divide(a: float, b: float) -> float:
        """Divide two numbers."""
        if b == 0:
            raise ValueError("Cannot divide by zero")
        return a / b
    
    @server.tool()
    def validate_email(email: str) -> bool:
        """Validate email format."""
        if "@" not in email:
            raise ValueError(f"Invalid email: {email}")
        return True
    
    # Initialize
    await server.handle_request(MCPRequest(
        method="initialize",
        params={
            "protocolVersion": MCP_PROTOCOL_VERSION,
            "capabilities": {},
            "clientInfo": {"name": "test", "version": "1.0"},
        },
    ))
    
    # Successful call
    success_response = await server.handle_request(MCPRequest(
        method="tools/call",
        params={"name": "divide", "arguments": {"a": 10, "b": 2}},
    ))
    print_result("divide(10, 2) - Success", success_response.result["content"][0]["text"])
    
    # Division by zero
    error_response = await server.handle_request(MCPRequest(
        method="tools/call",
        params={"name": "divide", "arguments": {"a": 10, "b": 0}},
    ))
    print_result("divide(10, 0) - Error", {
        "isError": error_response.result["isError"],
        "content": error_response.result["content"][0]["text"],
    })
    
    # Invalid email
    email_response = await server.handle_request(MCPRequest(
        method="tools/call",
        params={"name": "validate_email", "arguments": {"email": "invalid"}},
    ))
    print_result("validate_email('invalid') - Error", {
        "isError": email_response.result["isError"],
        "content": email_response.result["content"][0]["text"],
    })
    
    # Unknown method
    unknown_response = await server.handle_request(MCPRequest(method="unknown/method"))
    print_result("Unknown method - Error", {
        "code": unknown_response.error.code,
        "message": unknown_response.error.message,
    })
    
    # Non-existent tool - returns error in result (tool execution error)
    notfound_response = await server.handle_request(MCPRequest(
        method="tools/call",
        params={"name": "nonexistent", "arguments": {}},
    ))
    if notfound_response.error:
        print_result("Non-existent tool - Error", {
            "code": notfound_response.error.code,
            "message": notfound_response.error.message,
        })
    else:
        print_result("Non-existent tool - Error", {
            "isError": notfound_response.result.get("isError", False),
            "content": notfound_response.result.get("content", [{}])[0].get("text", ""),
        })


# =============================================================================
# Demo 6: Tool Discovery
# =============================================================================


async def demo_tool_discovery():
    """Demo tool discovery from server."""
    print_header("Demo 6: Tool Discovery")
    
    # Create a server to discover tools from
    server = MCPServer(name="discovery-server")
    
    @server.tool()
    def search(query: str, limit: int = 10) -> str:
        """Search for documents."""
        return f"Found {limit} results for: {query}"
    
    @server.tool()
    def calculate(expression: str) -> str:
        """Calculate a mathematical expression."""
        try:
            result = eval(expression)  # Note: eval is dangerous in production
            return str(result)
        except Exception as e:
            return f"Error: {e}"
    
    # Get tools from server
    tools = server.tools
    
    print(f"Discovered {len(tools)} tools from server")
    
    for name, tool in tools.items():
        print(f"\n  Tool: {name}")
        print(f"    Description: {tool.description}")
        print(f"    Async: {tool.is_async}")
        print(f"    Parameters:")
        for param in tool.parameters:
            req = "required" if param.required else f"optional, default={param.default}"
            print(f"      - {param.name}: {param.type} ({req})")
    
    # Create MCPTool from registered tool
    print("\n--- Converting to MCPTool format ---")
    
    for name, registered_tool in tools.items():
        mcp_tool = MCPTool(
            name=registered_tool.name,
            description=registered_tool.description,
            parameters=registered_tool.parameters,
        )
        
        schema = mcp_tool.to_dict()
        print(f"\n{name} schema:")
        print(f"  inputSchema: {json.dumps(schema['inputSchema'], indent=4)}")


# =============================================================================
# Demo 7: Manual Registration
# =============================================================================


async def demo_manual_registration():
    """Demo manual tool registration."""
    print_header("Demo 7: Manual Tool Registration")
    
    server = MCPServer(name="manual-server")
    
    # Define a function
    def custom_tool(x: int, y: int) -> int:
        """Custom tool function."""
        return x ** y
    
    # Register manually with explicit parameters
    server.register_tool(
        name="power",
        handler=custom_tool,
        description="Calculate x raised to the power of y",
        parameters=[
            MCPToolParameter(
                name="x",
                type="number",
                description="Base number",
                required=True,
            ),
            MCPToolParameter(
                name="y",
                type="number",
                description="Exponent",
                required=True,
            ),
        ],
    )
    
    # Lambda tool
    server.register_tool(
        name="double",
        handler=lambda n: n * 2,
        description="Double a number",
        parameters=[
            MCPToolParameter(
                name="n",
                type="number",
                description="Number to double",
                required=True,
            ),
        ],
    )
    
    print(f"Registered tools: {list(server.tools.keys())}")
    
    # Initialize and call
    await server.handle_request(MCPRequest(
        method="initialize",
        params={
            "protocolVersion": MCP_PROTOCOL_VERSION,
            "capabilities": {},
            "clientInfo": {"name": "test", "version": "1.0"},
        },
    ))
    
    # Call power
    power_response = await server.handle_request(MCPRequest(
        method="tools/call",
        params={"name": "power", "arguments": {"x": 2, "y": 10}},
    ))
    print_result("power(2, 10)", power_response.result["content"][0]["text"])
    
    # Call double
    double_response = await server.handle_request(MCPRequest(
        method="tools/call",
        params={"name": "double", "arguments": {"n": 21}},
    ))
    print_result("double(21)", double_response.result["content"][0]["text"])


# =============================================================================
# Demo 8: Protocol Types
# =============================================================================


def demo_protocol_types():
    """Demo protocol type usage."""
    print_header("Demo 8: Protocol Types")
    
    # MCPRequest
    print("\n--- MCPRequest ---")
    request = MCPRequest(
        method="tools/call",
        params={"name": "search", "arguments": {"query": "AI"}},
        id="req-123",
    )
    print(f"Request JSON:\n{request.to_json()}")
    
    # MCPResponse
    print("\n--- MCPResponse (Success) ---")
    response = MCPResponse(
        id="req-123",
        result={"content": [{"type": "text", "text": "Found 10 results"}]},
    )
    print(f"Response dict: {response.to_dict()}")
    print(f"Is error: {response.is_error}")
    
    # MCPResponse with error
    print("\n--- MCPResponse (Error) ---")
    error_response = MCPResponse(
        id="req-456",
        error=MCPError(
            code=MCPErrorCode.TOOL_NOT_FOUND,
            message="Tool 'unknown' not found",
            data={"tool": "unknown"},
        ),
    )
    print(f"Error response: {error_response.to_dict()}")
    print(f"Is error: {error_response.is_error}")
    
    # MCPTool
    print("\n--- MCPTool ---")
    tool = MCPTool(
        name="search",
        description="Search for documents",
        parameters=[
            MCPToolParameter(
                name="query",
                type="string",
                description="Search query",
                required=True,
            ),
            MCPToolParameter(
                name="limit",
                type="number",
                description="Max results",
                required=False,
                default=10,
            ),
        ],
    )
    print(f"Tool schema:\n{json.dumps(tool.to_dict(), indent=2)}")
    
    # MCPToolResult
    print("\n--- MCPToolResult ---")
    result = MCPToolResult.text("Search completed successfully")
    print(f"Result: {result.to_dict()}")
    
    error_result = MCPToolResult.error("Search failed: timeout")
    print(f"Error result: {error_result.to_dict()}")


# =============================================================================
# Main
# =============================================================================


async def main():
    """Run all demos."""
    print("\n" + "=" * 60)
    print("  MCP (Model Context Protocol) Demo")
    print("  Protocol Version: " + MCP_PROTOCOL_VERSION)
    print("=" * 60)
    
    # Run demos
    await demo_basic_server()
    await demo_async_tools()
    await demo_resources()
    await demo_prompts()
    await demo_error_handling()
    await demo_tool_discovery()
    await demo_manual_registration()
    demo_protocol_types()
    
    print("\n" + "=" * 60)
    print("  All demos completed successfully!")
    print("=" * 60 + "\n")


if __name__ == "__main__":
    asyncio.run(main())
