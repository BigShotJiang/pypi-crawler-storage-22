#!/usr/bin/env python3
"""
Multi-Agent Workflow with Graph Visualization.

This demonstrates:
1. Creating multiple agents with different roles
2. Building a workflow with fan-out/fan-in pattern
3. Visualizing the workflow as a graph (Mermaid + SVG)
4. Running the workflow with DevUI
"""

import os
from datetime import datetime
from dataclasses import dataclass

from agent_framework.ollama import OllamaChatClient
from agent_framework import (
    ChatAgent,
    WorkflowBuilder,
    WorkflowViz,
    Executor,
    WorkflowContext,
    AgentExecutorResponse,
    handler,
    tool,
)
from agent_framework.devui import serve
from agent_framework.observability import configure_otel_providers

# Import OTLP exporters for Aspire Dashboard
from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
from opentelemetry.exporter.otlp.proto.grpc._log_exporter import OTLPLogExporter
from opentelemetry.exporter.otlp.proto.grpc.metric_exporter import OTLPMetricExporter


# ============== Tools ==============

@tool(approval_mode="never_require")
def search_web(query: str) -> str:
    """Search the web for information."""
    return f"[Mock Web Search] Results for '{query}': Found 5 relevant articles about {query}."


@tool(approval_mode="never_require")
def analyze_data(data: str) -> str:
    """Analyze data and provide insights."""
    return f"[Mock Analysis] Data analysis complete. Key insight: The data shows positive trends in {data}."


@tool(approval_mode="never_require")
def write_report(topic: str) -> str:
    """Write a report on a topic."""
    return f"[Mock Report] Generated comprehensive report on '{topic}' with 3 sections and recommendations."


@tool(approval_mode="never_require")
def calculate(expression: str) -> str:
    """Evaluate a mathematical expression."""
    try:
        allowed_chars = set("0123456789+-*/.() ")
        if not all(c in allowed_chars for c in expression):
            return "Error: Invalid characters"
        return f"Result: {eval(expression)}"
    except Exception as e:
        return f"Error: {e}"


# ============== Executors ==============

class TaskDispatcher(Executor):
    """Dispatches tasks to specialized agents."""
    
    def __init__(self):
        super().__init__(id="dispatcher")
    
    @handler
    async def handle(self, message: str, ctx: WorkflowContext[str, str]) -> str:
        """Receive a task and prepare it for the agents."""
        return f"Task received: {message}"


class ResultAggregator(Executor):
    """Aggregates results from multiple agents."""
    
    def __init__(self):
        super().__init__(id="aggregator")
    
    @handler
    async def handle(self, message: list[AgentExecutorResponse], ctx: WorkflowContext[list[AgentExecutorResponse], str]) -> str:
        """Combine results from all agents."""
        results = []
        for resp in message:
            if hasattr(resp, 'text'):
                results.append(resp.text)
            else:
                results.append(str(resp))
        combined = "\n".join([f"- {r}" for r in results])
        return f"=== Aggregated Results ===\n{combined}"


# ============== Agent Factory ==============

def create_ollama_client():
    """Create a shared Ollama client."""
    return OllamaChatClient(
        host="http://localhost:11434",
        model_id="llama3:latest",  # llama3 has better tool calling support
    )


def create_researcher_agent():
    """Create a researcher agent."""
    return ChatAgent(
        chat_client=create_ollama_client(),
        name="Researcher",
        description="Researches and gathers information",
        instructions="You are a research specialist. Search for information and provide detailed findings.",
        tools=[search_web],
    )


def create_analyst_agent():
    """Create an analyst agent."""
    return ChatAgent(
        chat_client=create_ollama_client(),
        name="Analyst",
        description="Analyzes data and provides insights",
        instructions="You are a data analyst. Analyze information and provide insights.",
        tools=[analyze_data, calculate],
    )


def create_writer_agent():
    """Create a writer agent."""
    return ChatAgent(
        chat_client=create_ollama_client(),
        name="Writer",
        description="Writes reports and summaries",
        instructions="You are a technical writer. Create clear and concise reports.",
        tools=[write_report],
    )


def main():
    print("=" * 60)
    print("🚀 Multi-Agent Workflow with Graph Visualization")
    print("=" * 60)
    print()
    
    # Setup observability with Aspire Dashboard
    print("🔭 Setting up observability...")
    otlp_endpoint = "http://localhost:4317"
    try:
        configure_otel_providers(
            enable_sensitive_data=True,
            exporters=[
                OTLPSpanExporter(endpoint=otlp_endpoint, insecure=True),
                OTLPLogExporter(endpoint=otlp_endpoint, insecure=True),
                OTLPMetricExporter(endpoint=otlp_endpoint, insecure=True),
            ],
        )
        print(f"✅ Traces sent to Aspire Dashboard: http://localhost:18888")
    except Exception as e:
        print(f"⚠️  Aspire not available: {e}")
    print()
    
    # Build the multi-agent workflow
    print("🔧 Building multi-agent workflow...")
    
    workflow = (
        WorkflowBuilder()
        # Register agents
        .register_agent(create_researcher_agent, name="researcher")
        .register_agent(create_analyst_agent, name="analyst")
        .register_agent(create_writer_agent, name="writer")
        # Register executors
        .register_executor(lambda: TaskDispatcher(), name="dispatcher")
        .register_executor(lambda: ResultAggregator(), name="aggregator")
        # Set start point
        .set_start_executor("dispatcher")
        # Fan-out: dispatcher -> [researcher, analyst, writer]
        .add_fan_out_edges("dispatcher", ["researcher", "analyst", "writer"])
        # Fan-in: [researcher, analyst, writer] -> aggregator
        .add_fan_in_edges(["researcher", "analyst", "writer"], "aggregator")
        .build()
    )
    
    print("✅ Workflow built successfully!")
    print()
    
    # Generate workflow visualization
    print("📊 Generating workflow visualization...")
    viz = WorkflowViz(workflow)
    
    # Print Mermaid diagram
    print("\n=== Mermaid Diagram ===")
    mermaid = viz.to_mermaid()
    print(mermaid)
    print()
    
    # Print DOT diagram
    print("=== DOT Diagram ===")
    dot = viz.to_digraph()
    print(dot)
    print()
    
    # Try to export as SVG
    try:
        svg_path = viz.export(format="svg", filename="workflow_graph.svg")
        print(f"✅ SVG exported to: {svg_path}")
    except ImportError as e:
        print(f"ℹ️  SVG export requires graphviz: {e}")
        print("   Install with: brew install graphviz && pip install graphviz")
    print()
    
    # Create individual agents for DevUI
    researcher = create_researcher_agent()
    analyst = create_analyst_agent()
    writer = create_writer_agent()
    
    print("🌐 Starting DevUI server...")
    print("   Agents: Researcher, Analyst, Writer")
    print("   DevUI: http://localhost:8080")
    print("   Aspire: http://localhost:18888")
    print("   Press Ctrl+C to stop")
    print()
    
    # Start DevUI with all agents
    serve(
        entities=[researcher, analyst, writer],
        port=8080,
        host="127.0.0.1",
        auto_open=True,
        mode="developer",
        instrumentation_enabled=True,
    )


if __name__ == "__main__":
    main()
