#!/usr/bin/env python3
"""
Multimodal Demo - Multi-Agent Base Framework

Bu demo, multimodal modülünün özelliklerini gösterir:
1. MediaContent oluşturma
2. MultimodalMessage kullanımı
3. Provider format dönüşümleri
4. Encoding utilities
5. Media processing
6. Validation
7. URL vs File handling
8. Provider capabilities
"""

import base64
import io
import struct
import tempfile
from pathlib import Path

from multi_agent_base.multimodal import (
    # Core types
    MediaContent,
    MultimodalMessage,
    MediaType,
    # Format enums
    ImageFormat,
    AudioFormat,
    PROVIDER_CAPABILITIES,
    # Encoders
    Base64Encoder,
    URLEncoder,
    ContentHasher,
    MIMETypeDetector,
    # Processors
    ImageProcessor,
    AudioProcessor,
    MediaProcessor,
    ImageDimensions,
)


# =============================================================================
# Helper: Minimal test images
# =============================================================================

def create_minimal_png() -> bytes:
    """Create a minimal valid 1x1 PNG image."""
    return bytes([
        0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A,  # PNG signature
        0x00, 0x00, 0x00, 0x0D, 0x49, 0x48, 0x44, 0x52,  # IHDR chunk
        0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01,  # 1x1 dimensions
        0x08, 0x02, 0x00, 0x00, 0x00, 0x90, 0x77, 0x53,  # 8-bit RGB
        0xDE, 0x00, 0x00, 0x00, 0x0C, 0x49, 0x44, 0x41,  # IDAT chunk
        0x54, 0x08, 0xD7, 0x63, 0xF8, 0xCF, 0xC0, 0x00,
        0x00, 0x00, 0x03, 0x00, 0x01, 0x00, 0x18, 0xDD,
        0x8D, 0xB4, 0x00, 0x00, 0x00, 0x00, 0x49, 0x45,  # IEND chunk
        0x4E, 0x44, 0xAE, 0x42, 0x60, 0x82,
    ])


def create_minimal_jpeg() -> bytes:
    """Create a minimal valid 2x2 JPEG image."""
    return bytes([
        0xFF, 0xD8, 0xFF, 0xE0, 0x00, 0x10, 0x4A, 0x46,  # SOI + APP0
        0x49, 0x46, 0x00, 0x01, 0x01, 0x00, 0x00, 0x01,
        0x00, 0x01, 0x00, 0x00, 0xFF, 0xC0, 0x00, 0x0B,  # SOF0
        0x08, 0x00, 0x02, 0x00, 0x02, 0x01, 0x01, 0x11,  # 2x2 dimensions
        0x00, 0xFF, 0xD9,  # EOI
    ])


# =============================================================================
# Demo 1: MediaContent Oluşturma
# =============================================================================

def demo_media_content():
    """MediaContent sınıfının farklı oluşturma yollarını gösterir."""
    print("\n" + "=" * 60)
    print("Demo 1: MediaContent Oluşturma")
    print("=" * 60)
    
    png_data = create_minimal_png()
    
    # 1. Bytes'tan oluşturma
    print("\n1. Raw bytes'tan oluşturma:")
    content = MediaContent.from_bytes(
        data=png_data,
        mime_type="image/png",
        filename="test.png"
    )
    print(f"   - Media Type: {content.media_type}")
    print(f"   - MIME Type: {content.mime_type}")
    print(f"   - Filename: {content.filename}")
    print(f"   - Size: {content.size_bytes} bytes")
    
    # 2. File'dan oluşturma
    print("\n2. Dosyadan oluşturma (temp file):")
    with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as f:
        f.write(png_data)
        temp_path = f.name
    
    try:
        content = MediaContent.from_file(temp_path)
        print(f"   - File: {Path(temp_path).name}")
        print(f"   - Media Type: {content.media_type}")
        print(f"   - Has Data: {content.data is not None}")
    finally:
        Path(temp_path).unlink()
    
    # 3. URL'den oluşturma
    print("\n3. URL'den oluşturma:")
    url = "https://example.com/images/photo.jpg"
    content = MediaContent.from_url(url)
    print(f"   - URL: {url}")
    print(f"   - Media Type: {content.media_type}")
    print(f"   - Has Data: {content.data is not None}")
    print(f"   - Filename: {content.filename}")
    
    # 4. Base64'ten oluşturma
    print("\n4. Base64'ten oluşturma:")
    b64 = base64.b64encode(png_data).decode()
    content = MediaContent.from_base64(b64, "image/png")
    print(f"   - Original size: {len(png_data)} bytes")
    print(f"   - Decoded size: {content.size_bytes} bytes")
    print(f"   - Match: {content.data == png_data}")
    
    print("\n✅ Demo 1 tamamlandı!")


# =============================================================================
# Demo 2: MultimodalMessage Kullanımı
# =============================================================================

def demo_multimodal_message():
    """MultimodalMessage oluşturma ve kullanımını gösterir."""
    print("\n" + "=" * 60)
    print("Demo 2: MultimodalMessage Kullanımı")
    print("=" * 60)
    
    png_data = create_minimal_png()
    
    # 1. Text-only message
    print("\n1. Text-only mesaj:")
    message = MultimodalMessage.from_text("Merhaba dünya!")
    print(f"   - Text: {message.text}")
    print(f"   - Role: {message.role}")
    print(f"   - Has Media: {message.has_media}")
    
    # 2. Image ile mesaj
    print("\n2. Image ile mesaj:")
    content = MediaContent.from_bytes(png_data, "image/png")
    message = MultimodalMessage.with_image(
        text="Bu resimde ne var?",
        image=content
    )
    print(f"   - Text: {message.text}")
    print(f"   - Images: {len(message.images)}")
    print(f"   - Has Media: {message.has_media}")
    print(f"   - Media Count: {message.media_count}")
    
    # 3. Çoklu image ile mesaj
    print("\n3. Çoklu image ile mesaj:")
    message = MultimodalMessage(
        text="Bu resimleri karşılaştır",
        images=[
            MediaContent.from_bytes(png_data, "image/png"),
            MediaContent.from_bytes(create_minimal_jpeg(), "image/jpeg"),
        ]
    )
    print(f"   - Images: {len(message.images)}")
    print(f"   - Image 1: {message.images[0].mime_type}")
    print(f"   - Image 2: {message.images[1].mime_type}")
    
    # 4. Method chaining
    print("\n4. Method chaining:")
    message = (
        MultimodalMessage.from_text("Analiz")
        .add_image(MediaContent.from_bytes(png_data, "image/png"))
        .add_image(MediaContent.from_bytes(png_data, "image/png"))
    )
    print(f"   - Final image count: {len(message.images)}")
    
    # 5. Repr ve dict
    print("\n5. Repr ve dict:")
    message = MultimodalMessage.with_image("Describe", content)
    print(f"   - Repr: {repr(message)}")
    data = message.to_dict()
    print(f"   - Dict keys: {list(data.keys())}")
    
    print("\n✅ Demo 2 tamamlandı!")


# =============================================================================
# Demo 3: Provider Format Dönüşümleri
# =============================================================================

def demo_provider_formats():
    """Farklı provider formatlarına dönüşümü gösterir."""
    print("\n" + "=" * 60)
    print("Demo 3: Provider Format Dönüşümleri")
    print("=" * 60)
    
    png_data = create_minimal_png()
    content = MediaContent.from_bytes(png_data, "image/png", "test.png")
    message = MultimodalMessage.with_image("Describe this image", content)
    
    # 1. OpenAI format
    print("\n1. OpenAI Format:")
    openai = message.to_openai_format()
    print(f"   - Role: {openai['role']}")
    print(f"   - Content type: {type(openai['content']).__name__}")
    if isinstance(openai['content'], list):
        for i, item in enumerate(openai['content']):
            print(f"   - Part {i+1}: {item['type']}")
    
    # 2. Anthropic format
    print("\n2. Anthropic Format:")
    anthropic = message.to_anthropic_format()
    print(f"   - Role: {anthropic['role']}")
    if isinstance(anthropic['content'], list):
        for i, item in enumerate(anthropic['content']):
            print(f"   - Part {i+1}: {item['type']}")
            if item['type'] == 'image':
                print(f"     Source type: {item['source']['type']}")
    
    # 3. Ollama format
    print("\n3. Ollama Format:")
    ollama = message.to_ollama_format()
    print(f"   - Role: {ollama['role']}")
    print(f"   - Content: {ollama['content'][:30]}...")
    print(f"   - Images: {len(ollama.get('images', []))} items")
    
    # 4. Google Gemini format
    print("\n4. Google Gemini Format:")
    google = message.to_google_format()
    print(f"   - Role: {google['role']}")
    print(f"   - Parts: {len(google['parts'])} items")
    for i, part in enumerate(google['parts']):
        if 'text' in part:
            print(f"   - Part {i+1}: text")
        elif 'inline_data' in part:
            print(f"   - Part {i+1}: inline_data ({part['inline_data']['mime_type']})")
    
    # 5. Generic conversion
    print("\n5. Generic to_provider_format():")
    for provider in ["openai", "anthropic", "ollama", "google"]:
        result = message.to_provider_format(provider)
        print(f"   - {provider}: ✓")
    
    # 6. Text-only simple format
    print("\n6. Text-only mesaj (simple format):")
    text_msg = MultimodalMessage.from_text("Hello")
    for provider in ["openai", "anthropic"]:
        result = text_msg.to_provider_format(provider)
        is_simple = isinstance(result['content'], str)
        print(f"   - {provider}: {'simple string' if is_simple else 'array'}")
    
    print("\n✅ Demo 3 tamamlandı!")


# =============================================================================
# Demo 4: Encoding Utilities
# =============================================================================

def demo_encoding_utilities():
    """Encoding utility sınıflarını gösterir."""
    print("\n" + "=" * 60)
    print("Demo 4: Encoding Utilities")
    print("=" * 60)
    
    png_data = create_minimal_png()
    
    # 1. Base64Encoder
    print("\n1. Base64Encoder:")
    encoded = Base64Encoder.encode(png_data)
    decoded = Base64Encoder.decode(encoded)
    print(f"   - Original: {len(png_data)} bytes")
    print(f"   - Encoded: {len(encoded)} chars")
    print(f"   - Roundtrip: {'✓' if decoded == png_data else '✗'}")
    
    # Data URI
    uri = Base64Encoder.to_data_uri(png_data, "image/png")
    print(f"   - Data URI: {uri[:50]}...")
    
    parsed = Base64Encoder.from_data_uri(uri)
    print(f"   - Parsed MIME: {parsed.mime_type}")
    print(f"   - Is Base64: {parsed.is_base64}")
    
    # Validation
    print(f"   - Valid base64: {Base64Encoder.is_valid_base64(encoded)}")
    print(f"   - Is data URI: {Base64Encoder.is_data_uri(uri)}")
    
    # 2. URLEncoder
    print("\n2. URLEncoder:")
    urls = [
        "https://example.com/image.png",
        "https://api.example.com:8080/v1/files",
        "not-a-url",
    ]
    for url in urls:
        is_valid = URLEncoder.is_valid_url(url)
        print(f"   - '{url[:40]}...': {'valid' if is_valid else 'invalid'}")
    
    # URL parsing
    url = "https://example.com/path/photo.jpg?size=large"
    print(f"\n   URL: {url}")
    print(f"   - Extension: {URLEncoder.get_extension(url)}")
    print(f"   - Filename: {URLEncoder.get_filename(url)}")
    print(f"   - MIME: {URLEncoder.get_mime_type(url)}")
    print(f"   - Is image URL: {URLEncoder.is_image_url(url)}")
    
    # 3. ContentHasher
    print("\n3. ContentHasher:")
    hash1 = ContentHasher.hash_bytes(png_data)
    hash2 = ContentHasher.hash_bytes(png_data)
    hash3 = ContentHasher.hash_bytes(png_data + b"x")
    print(f"   - Hash 1: {hash1[:16]}...")
    print(f"   - Hash 2: {hash2[:16]}...")
    print(f"   - Same: {ContentHasher.compare(png_data, png_data)}")
    print(f"   - Different: {not ContentHasher.compare(png_data, png_data + b'x')}")
    
    content_id = ContentHasher.generate_content_id(png_data)
    print(f"   - Content ID: {content_id}")
    
    # 4. MIMETypeDetector
    print("\n4. MIMETypeDetector:")
    print(f"   - PNG bytes: {MIMETypeDetector.from_bytes(png_data)}")
    print(f"   - JPEG bytes: {MIMETypeDetector.from_bytes(create_minimal_jpeg())}")
    print(f"   - Extension '.png': {MIMETypeDetector.from_extension('.png')}")
    print(f"   - Is image 'image/png': {MIMETypeDetector.is_image('image/png')}")
    print(f"   - Is audio 'audio/mp3': {MIMETypeDetector.is_audio('audio/mp3')}")
    
    print("\n✅ Demo 4 tamamlandı!")


# =============================================================================
# Demo 5: Media Processing
# =============================================================================

def demo_media_processing():
    """Media processing özelliklerini gösterir."""
    print("\n" + "=" * 60)
    print("Demo 5: Media Processing")
    print("=" * 60)
    
    png_data = create_minimal_png()
    jpeg_data = create_minimal_jpeg()
    
    # 1. ImageProcessor
    print("\n1. ImageProcessor - Dimensions:")
    
    dims = ImageProcessor.get_dimensions(png_data)
    print(f"   - PNG: {dims.width}x{dims.height}")
    
    dims = ImageProcessor.get_dimensions(jpeg_data)
    print(f"   - JPEG: {dims.width}x{dims.height}")
    
    # 2. ImageDimensions methods
    print("\n2. ImageDimensions Methods:")
    dims = ImageDimensions(1920, 1080)
    print(f"   - Size: {dims.width}x{dims.height}")
    print(f"   - Aspect ratio: {dims.aspect_ratio:.3f}")
    print(f"   - Is landscape: {dims.is_landscape}")
    print(f"   - Is portrait: {dims.is_portrait}")
    print(f"   - Fits in 2000x2000: {dims.fits_in(2000, 2000)}")
    
    scaled = dims.scale_to_fit(1000, 1000)
    print(f"   - Scaled to 1000x1000: {scaled.width}x{scaled.height}")
    
    # 3. Format detection
    print("\n3. Format Detection:")
    print(f"   - PNG format: {ImageProcessor.get_format(png_data)}")
    print(f"   - JPEG format: {ImageProcessor.get_format(jpeg_data)}")
    print(f"   - Valid PNG: {ImageProcessor.is_valid_image(png_data)}")
    print(f"   - Valid random: {ImageProcessor.is_valid_image(b'random data')}")
    
    # 4. Provider validation
    print("\n4. Provider Validation:")
    content = MediaContent.from_bytes(png_data, "image/png")
    
    for provider in ["openai", "anthropic", "ollama", "google"]:
        is_valid, errors = ImageProcessor.validate_for_provider(content, provider)
        status = "✓" if is_valid else f"✗ ({', '.join(errors)})"
        print(f"   - {provider}: {status}")
    
    # 5. MediaProcessor (unified)
    print("\n5. MediaProcessor (unified):")
    processor = MediaProcessor()
    
    content = MediaContent.from_bytes(png_data, "image/png")
    info = processor.get_info(content)
    print(f"   - Image info: {info.width}x{info.height}")
    
    is_valid, errors = processor.validate(content, "openai")
    print(f"   - Valid for OpenAI: {is_valid}")
    
    result = processor.process(content, "openai")
    print(f"   - Processing success: {result.success}")
    
    # 6. Media type detection
    print("\n6. Media Type Detection:")
    print(f"   - PNG: {processor.detect_media_type(png_data)}")
    print(f"   - Random: {processor.detect_media_type(b'random')}")
    
    print("\n✅ Demo 5 tamamlandı!")


# =============================================================================
# Demo 6: Validation
# =============================================================================

def demo_validation():
    """Content ve message validation gösterir."""
    print("\n" + "=" * 60)
    print("Demo 6: Validation")
    print("=" * 60)
    
    png_data = create_minimal_png()
    
    # 1. MediaContent validation
    print("\n1. MediaContent Validation:")
    
    # Valid content
    content = MediaContent.from_bytes(png_data, "image/png")
    for provider in ["openai", "anthropic", "ollama", "google"]:
        errors = content.validate_for_provider(provider)
        print(f"   - {provider}: {'✓ valid' if not errors else '✗ ' + str(errors)}")
    
    # 2. URL-based validation
    print("\n2. URL-based Content Validation:")
    url_content = MediaContent.from_url("https://example.com/image.png")
    for provider in ["openai", "anthropic", "ollama"]:
        errors = url_content.validate_for_provider(provider)
        print(f"   - {provider}: {'✓ valid' if not errors else '✗ URL not supported'}")
    
    # 3. MultimodalMessage validation
    print("\n3. MultimodalMessage Validation:")
    message = MultimodalMessage.with_image("Describe", content)
    for provider in ["openai", "anthropic", "ollama", "google"]:
        errors = message.validate_for_provider(provider)
        print(f"   - {provider}: {'✓ valid' if not errors else '✗ ' + str(errors)}")
    
    # 4. Unknown provider
    print("\n4. Unknown Provider:")
    errors = content.validate_for_provider("unknown_provider")
    print(f"   - Errors: {errors}")
    
    print("\n✅ Demo 6 tamamlandı!")


# =============================================================================
# Demo 7: URL vs File Handling
# =============================================================================

def demo_url_vs_file():
    """URL ve file content arasındaki farkları gösterir."""
    print("\n" + "=" * 60)
    print("Demo 7: URL vs File Handling")
    print("=" * 60)
    
    png_data = create_minimal_png()
    
    # 1. File-based content
    print("\n1. File-based Content:")
    file_content = MediaContent.from_bytes(png_data, "image/png", "test.png")
    print(f"   - Has data: {file_content.data is not None}")
    print(f"   - Has URL: {file_content.url is not None}")
    print(f"   - Can base64: Yes")
    print(f"   - Size: {file_content.size_bytes} bytes")
    
    # 2. URL-based content
    print("\n2. URL-based Content:")
    url_content = MediaContent.from_url("https://example.com/photo.jpg")
    print(f"   - Has data: {url_content.data is not None}")
    print(f"   - Has URL: {url_content.url is not None}")
    print(f"   - Can base64: No (need download)")
    print(f"   - URL: {url_content.url}")
    
    # 3. OpenAI prefers URL when available
    print("\n3. OpenAI URL Preference:")
    
    # URL-based goes as URL
    message = MultimodalMessage.with_image("Describe", url_content)
    openai = message.to_openai_format(prefer_url=True)
    img_part = openai['content'][1]
    uses_url = 'https://' in img_part['image_url']['url']
    print(f"   - URL content, prefer_url=True: {'URL used' if uses_url else 'Base64 used'}")
    
    # File-based becomes data URI
    message = MultimodalMessage.with_image("Describe", file_content)
    openai = message.to_openai_format(prefer_url=False)
    img_part = openai['content'][1]
    uses_data = img_part['image_url']['url'].startswith('data:')
    print(f"   - File content, prefer_url=False: {'Data URI used' if uses_data else 'URL used'}")
    
    # 4. Anthropic always base64
    print("\n4. Anthropic Always Base64:")
    message = MultimodalMessage.with_image("Describe", file_content)
    anthropic = message.to_anthropic_format()
    img_part = anthropic['content'][0]
    print(f"   - Source type: {img_part['source']['type']}")
    
    # 5. Error when URL content needs base64
    print("\n5. URL Content Base64 Error:")
    try:
        url_content.to_base64()
        print("   - Error not raised!")
    except ValueError as e:
        print(f"   - Error: {str(e)[:50]}...")
    
    print("\n✅ Demo 7 tamamlandı!")


# =============================================================================
# Demo 8: Provider Capabilities
# =============================================================================

def demo_provider_capabilities():
    """Provider capability bilgilerini gösterir."""
    print("\n" + "=" * 60)
    print("Demo 8: Provider Capabilities")
    print("=" * 60)
    
    providers = ["openai", "anthropic", "ollama", "google"]
    
    # 1. URL Support
    print("\n1. URL Support:")
    for provider in providers:
        caps = PROVIDER_CAPABILITIES[provider]
        status = "✓" if caps["supports_url"] else "✗"
        print(f"   - {provider}: {status}")
    
    # 2. Max Image Size
    print("\n2. Max Image Size (MB):")
    for provider in providers:
        caps = PROVIDER_CAPABILITIES[provider]
        print(f"   - {provider}: {caps['max_image_size_mb']} MB")
    
    # 3. Supported Image Formats
    print("\n3. Supported Image Formats:")
    for provider in providers:
        caps = PROVIDER_CAPABILITIES[provider]
        formats = [f.value.split('/')[1] for f in caps['image_formats']]
        print(f"   - {provider}: {', '.join(formats)}")
    
    # 4. Audio/Video Support
    print("\n4. Audio/Video Support:")
    for provider in providers:
        caps = PROVIDER_CAPABILITIES[provider]
        audio = "✓" if caps.get("audio_formats") else "✗"
        video = "✓" if caps.get("video_formats") else "✗"
        print(f"   - {provider}: Audio {audio}, Video {video}")
    
    # 5. Detailed Google capabilities
    print("\n5. Google Gemini Details:")
    google = PROVIDER_CAPABILITIES["google"]
    print(f"   - URL: {google['supports_url']}")
    print(f"   - Base64: {google['supports_base64']}")
    print(f"   - Audio formats: {len(google['audio_formats'])}")
    print(f"   - Video formats: {len(google['video_formats'])}")
    
    print("\n✅ Demo 8 tamamlandı!")


# =============================================================================
# Main
# =============================================================================

def main():
    """Run all demos."""
    print("=" * 60)
    print("🖼️  Multi-Agent Base - Multimodal Demo")
    print("=" * 60)
    print("\nBu demo multimodal modülünün özelliklerini gösterir.")
    
    try:
        demo_media_content()
        demo_multimodal_message()
        demo_provider_formats()
        demo_encoding_utilities()
        demo_media_processing()
        demo_validation()
        demo_url_vs_file()
        demo_provider_capabilities()
        
        print("\n" + "=" * 60)
        print("🎉 All demos completed successfully!")
        print("=" * 60)
        
    except Exception as e:
        print(f"\n❌ Demo failed: {e}")
        import traceback
        traceback.print_exc()
        return 1
    
    return 0


if __name__ == "__main__":
    exit(main())
