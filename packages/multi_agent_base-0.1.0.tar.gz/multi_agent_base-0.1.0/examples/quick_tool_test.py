#!/usr/bin/env python3
"""
Quick Ollama Tool Calling Test.

Simple test to verify tool calling works with Agent Framework.
"""

import asyncio
from agent_framework.ollama import OllamaChatClient
from agent_framework import ChatAgent, tool


@tool(approval_mode="never_require")
def calculate(expression: str) -> str:
    """Evaluate a mathematical expression."""
    try:
        result = eval(expression)
        return f"Result: {result}"
    except Exception as e:
        return f"Error: {e}"


async def main():
    print("🧪 Quick Ollama Tool Calling Test")
    print("="*50)
    
    model_id = "qwen2.5-coder:7b"
    print(f"📦 Model: {model_id}")
    
    client = OllamaChatClient(
        host="http://localhost:11434",
        model_id=model_id,
    )
    
    agent = ChatAgent(
        chat_client=client,
        name="Calculator",
        tools=[calculate],
        instructions="You are a calculator. Use the calculate tool for math.",
    )
    
    print("\n📝 Query: 'What is 25 * 4?'")
    print("⏳ Processing...")
    
    response = await agent.run("What is 25 * 4?")
    
    print(f"\n✅ Response:")
    print(f"   {response}")


if __name__ == "__main__":
    asyncio.run(main())
