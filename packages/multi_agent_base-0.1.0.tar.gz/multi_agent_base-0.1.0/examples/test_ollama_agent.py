#!/usr/bin/env python3
"""
Non-interactive Ollama Agent Test.
"""

import asyncio
from multi_agent_base.core.agent import BaseAgent, Tool
from multi_agent_base.core.config import AgentConfig, ProviderConfig, ProviderType
from multi_agent_base.providers.factory import OllamaClient


def calculate(expression: str) -> str:
    """Evaluate a math expression."""
    try:
        allowed_chars = set("0123456789+-*/.() ")
        if not all(c in allowed_chars for c in expression):
            return f"Error: Invalid characters"
        return f"Result: {eval(expression)}"
    except Exception as e:
        return f"Error: {e}"


def get_current_time() -> str:
    """Get the current date and time."""
    from datetime import datetime
    return f"Current time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"


async def main():
    print("=" * 60)
    print("🤖 Multi-Agent Base - Ollama Agent Test")
    print("=" * 60)
    print()
    
    # Configure
    provider_config = ProviderConfig(
        provider=ProviderType.OLLAMA,
        model="llama3",
        base_url="http://localhost:11434",
        temperature=0.7,
    )
    
    agent_config = AgentConfig(
        name="test-agent",
        system_prompt="""You are a helpful AI assistant. Be concise and friendly.

When you receive a tool result, summarize it naturally for the user. Do NOT call the same tool again.""",
        max_iterations=2,  # Limit tool iterations
    )
    
    # Tools
    tools = [
        Tool(
            name="calculate",
            description="Evaluate a math expression",
            function=calculate,
            parameters={
                "type": "object",
                "properties": {
                    "expression": {"type": "string", "description": "Math expression"}
                },
                "required": ["expression"]
            }
        ),
        Tool(
            name="get_current_time",
            description="Get current date and time",
            function=get_current_time,
            parameters={"type": "object", "properties": {}, "required": []}
        ),
    ]
    
    # Create model client
    model_client = OllamaClient(
        model="qwen2.5-coder:7b",
        base_url="http://localhost:11434",
        temperature=0.7,
    )
    
    # Create agent
    agent = BaseAgent(
        name="test-agent",
        config=agent_config,
        provider_config=provider_config,
        tools=tools,
        model_client=model_client,  # Pass the model client
    )
    
    print(f"✅ Agent created: {agent.name}")
    print(f"📦 Model: qwen2.5-coder:7b")
    print(f"🔧 Tools: {[t.name for t in tools]}")
    print()
    
    # Test queries
    test_queries = [
        "What is 25 * 4?",
        "Hello! How are you?",
        "What time is it now?",
    ]
    
    for query in test_queries:
        print("-" * 50)
        print(f"📝 Query: {query}")
        print()
        
        try:
            response = await agent.run(query)
            print(f"🤖 Response: {response.content}")
            
            if response.tool_calls:
                print(f"   🔧 Tools used: {[tc.get('name', 'unknown') for tc in response.tool_calls]}")
            
            if response.usage:
                print(f"   📊 Tokens: {response.usage.get('total_tokens', 0)}")
        except Exception as e:
            print(f"❌ Error: {e}")
            import traceback
            traceback.print_exc()
        
        print()
    
    print("=" * 60)
    print("✅ Test completed!")


if __name__ == "__main__":
    asyncio.run(main())
