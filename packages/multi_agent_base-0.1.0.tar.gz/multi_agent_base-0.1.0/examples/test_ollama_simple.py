#!/usr/bin/env python3
"""
Simple Ollama test - direct API call.
"""

import asyncio


async def test_ollama_direct():
    """Test Ollama directly."""
    import ollama
    
    print("🔄 Testing direct Ollama call...")
    
    client = ollama.AsyncClient()
    
    response = await client.chat(
        model="llama3",
        messages=[
            {"role": "user", "content": "Say hello in 5 words or less."}
        ]
    )
    
    print(f"✅ Response: {response['message']['content']}")
    print(f"📊 Tokens: {response.get('eval_count', 0)}")
    

async def test_with_framework():
    """Test using our framework."""
    from multi_agent_base.providers.factory import OllamaClient
    
    print("\n🔄 Testing with Multi-Agent Base OllamaClient...")
    
    client = OllamaClient(
        model="llama3",
        base_url="http://localhost:11434",
    )
    
    messages = [
        {"role": "system", "content": "You are a helpful assistant. Be concise."},
        {"role": "user", "content": "What is 2 + 2? Answer in one word."}
    ]
    
    content, usage, tool_calls = await client.generate(messages)
    
    print(f"✅ Response: {content}")
    print(f"📊 Usage: {usage}")


async def main():
    print("=" * 50)
    print("🤖 Ollama Integration Test")
    print("=" * 50)
    print()
    
    await test_ollama_direct()
    await test_with_framework()
    
    print()
    print("✅ All tests passed!")


if __name__ == "__main__":
    asyncio.run(main())
