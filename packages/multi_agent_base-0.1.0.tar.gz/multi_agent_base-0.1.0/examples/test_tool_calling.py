#!/usr/bin/env python3
"""
Test Ollama Tool Calling with Agent Framework.

This script tests tool calling functionality with different Ollama models.
"""

import asyncio
from agent_framework.ollama import OllamaChatClient
from agent_framework import ChatAgent, tool


@tool(approval_mode="never_require")
def calculate(expression: str) -> str:
    """Evaluate a mathematical expression.
    
    Args:
        expression: A mathematical expression like "2 + 2" or "10 * 5"
    
    Returns:
        The result of the calculation
    """
    try:
        result = eval(expression)
        return f"{expression} = {result}"
    except Exception as e:
        return f"Error: {e}"


@tool(approval_mode="never_require")
def get_weather(city: str) -> str:
    """Get weather for a city.
    
    Args:
        city: The city name
    
    Returns:
        Weather information
    """
    import random
    temps = {"Istanbul": 15, "Ankara": 8, "Izmir": 18, "New York": 5}
    temp = temps.get(city, random.randint(0, 25))
    return f"Weather in {city}: {temp}°C, sunny"


async def test_model(model_id: str):
    """Test tool calling with a specific model."""
    print(f"\n{'='*60}")
    print(f"Testing model: {model_id}")
    print('='*60)
    
    try:
        client = OllamaChatClient(
            host="http://localhost:11434",
            model_id=model_id,
        )
        
        agent = ChatAgent(
            chat_client=client,
            name=f"TestAgent-{model_id}",
            tools=[calculate, get_weather],
            instructions="You are a helpful assistant. Use tools when appropriate.",
        )
        
        # Test 1: Math calculation
        print("\n📝 Test 1: 'Calculate 25 * 4'")
        response = await agent.run("Calculate 25 * 4")
        print(f"   Response: {response}")
        
        # Test 2: Weather query
        print("\n📝 Test 2: 'What is the weather in Istanbul?'")
        response = await agent.run("What is the weather in Istanbul?")
        print(f"   Response: {response}")
        
        # Test 3: Multiple tools
        print("\n📝 Test 3: 'Calculate 100/5 and tell me the weather in Ankara'")
        response = await agent.run("Calculate 100/5 and tell me the weather in Ankara")
        print(f"   Response: {response}")
        
        print(f"\n✅ {model_id} - All tests completed!")
        return True
        
    except Exception as e:
        print(f"\n❌ {model_id} - Error: {e}")
        return False


async def main():
    print("🧪 Agent Framework - Ollama Tool Calling Test")
    print("="*60)
    
    # Models to test
    models = [
        "qwen2.5-coder:7b",
        "mistral:7b",
        # "llama3:latest",  # Does not support tools
    ]
    
    results = {}
    for model in models:
        results[model] = await test_model(model)
    
    # Summary
    print("\n" + "="*60)
    print("📊 Summary")
    print("="*60)
    for model, success in results.items():
        status = "✅ Working" if success else "❌ Failed"
        print(f"   {model}: {status}")


if __name__ == "__main__":
    asyncio.run(main())
