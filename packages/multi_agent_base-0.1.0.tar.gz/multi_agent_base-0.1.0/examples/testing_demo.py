#!/usr/bin/env python3
"""
Agent Testing Framework Demo

Demonstrates the comprehensive testing capabilities for AI agents:
- Mock LLM with deterministic responses
- Mock tools with configurable behavior
- Scenario-based testing
- Test suites with metrics
- Assertions and validation

Run:
    cd /path/to/project
    PYTHONPATH=src python examples/testing_demo.py
"""

import asyncio
from dataclasses import dataclass
from typing import Any

# Import testing module
from multi_agent_base.testing import (
    # Types
    MockResponse,
    MockToolCall,
    MockLLMConfig,
    TestScenario,
    ConversationTurn,
    TestStatus,
    # Mocks
    MockLLM,
    MockTool,
    MockToolRegistry,
    MockAgent,
    # Fixtures
    TestContext,
    ConversationFixture,
    ScenarioRunner,
    TestSuiteBuilder,
    # Assertions
    assert_tool_called,
    assert_response_contains,
    assert_response_not_contains,
    assert_llm_called,
    AgentAssertions,
)


def print_section(title: str) -> None:
    """Print a section header."""
    print(f"\n{'='*60}")
    print(f"  {title}")
    print(f"{'='*60}\n")


async def demo_basic_mock_llm():
    """Demonstrate basic MockLLM usage."""
    print_section("1. Basic MockLLM")
    
    # Create mock with predefined responses
    mock = MockLLM(responses=["Hello!", "How can I help?", "Goodbye!"])
    
    # Make chat calls
    messages = [{"role": "user", "content": "Hi"}]
    
    response1 = await mock.chat(messages)
    print(f"Call 1: {response1['choices'][0]['message']['content']}")
    
    response2 = await mock.chat(messages)
    print(f"Call 2: {response2['choices'][0]['message']['content']}")
    
    response3 = await mock.chat(messages)
    print(f"Call 3: {response3['choices'][0]['message']['content']}")
    
    # Check metrics
    print(f"\nCall count: {mock.call_count}")
    print(f"Total tokens: {mock.metrics.total_tokens}")


async def demo_mock_with_config():
    """Demonstrate MockLLM with configuration."""
    print_section("2. MockLLM with Configuration")
    
    # Create configuration with cycling
    config = MockLLMConfig.from_strings(
        "Response A",
        "Response B",
        "Response C",
        cycle=True,  # Cycle through responses
    )
    
    mock = MockLLM(config=config)
    messages = [{"role": "user", "content": "Hi"}]
    
    # Make 5 calls - should cycle through A, B, C, A, B
    for i in range(5):
        response = await mock.chat(messages)
        content = response['choices'][0]['message']['content']
        print(f"Call {i+1}: {content}")


async def demo_mock_tool_calls():
    """Demonstrate MockLLM with tool calls."""
    print_section("3. Mock Tool Calls")
    
    # Create response with tool calls
    tool_response = MockResponse(
        content="",
        tool_calls=[
            MockToolCall(name="search", arguments={"query": "weather"}),
            MockToolCall(name="get_location", arguments={}),
        ],
        finish_reason="tool_calls",
    )
    
    mock = MockLLM(responses=[tool_response])
    
    response = await mock.chat(
        [{"role": "user", "content": "What's the weather?"}],
        tools=[{"name": "search"}, {"name": "get_location"}]
    )
    
    message = response['choices'][0]['message']
    print(f"Content: {message.get('content', 'None')}")
    print(f"Tool calls: {len(message.get('tool_calls', []))}")
    
    for tc in message.get('tool_calls', []):
        print(f"  - {tc['function']['name']}: {tc['function']['arguments']}")


async def demo_mock_tools():
    """Demonstrate MockTool and MockToolRegistry."""
    print_section("4. Mock Tools")
    
    # Create individual mock tools
    search_tool = MockTool(
        name="search",
        return_value={"results": ["item1", "item2", "item3"]}
    )
    
    calculate_tool = MockTool(
        name="calculate",
        side_effect=lambda expression, **kwargs: eval(expression)
    )
    
    # Execute tools
    search_result = await search_tool.execute(query="test")
    print(f"Search result: {search_result}")
    
    calc_result = await calculate_tool.execute(expression="2 + 3 * 4")
    print(f"Calculate result: {calc_result}")
    
    # Use registry
    registry = MockToolRegistry()
    registry.register(search_tool)
    registry.register(calculate_tool)
    
    # Execute through registry
    result = await registry.execute("calculate", expression="10 / 2")
    print(f"Registry execute: {result}")
    
    print(f"\nSearch tool call count: {search_tool.call_count}")
    print(f"Calculate tool call count: {calculate_tool.call_count}")


async def demo_conversation_fixture():
    """Demonstrate ConversationFixture for multi-turn testing."""
    print_section("5. Conversation Fixture")
    
    mock = MockLLM(responses=[
        "Hello! I'm an AI assistant.",
        "I can help with various tasks.",
        "Goodbye! Have a great day!",
    ])
    
    fixture = ConversationFixture(mock)
    
    async with fixture as conv:
        r1 = await conv.send("Hi!")
        print(f"User: Hi!")
        print(f"Agent: {r1}")
        
        r2 = await conv.send("What can you do?")
        print(f"\nUser: What can you do?")
        print(f"Agent: {r2}")
        
        r3 = await conv.send("Thanks, bye!")
        print(f"\nUser: Thanks, bye!")
        print(f"Agent: {r3}")
    
    print(f"\nConversation turns: {fixture.turn_count}")
    print(f"History length: {len(fixture.history)}")


async def demo_test_scenario():
    """Demonstrate scenario-based testing."""
    print_section("6. Test Scenarios")
    
    # Define a test scenario
    scenario = (
        TestScenario(name="greeting_and_math")
        .add_turn(
            "Hello!",
            expected_contains=["hello"],  # Response contains "Hello"
        )
        .add_turn(
            "What is 2+2?",
            expected_contains=["4"],
        )
        .add_turn(
            "Thanks!",
            expected_contains=["welcome"],  # Response contains "welcome"
        )
    )
    
    # Create mock with appropriate responses
    mock = MockLLM(responses=[
        "Hello! How can I help you today?",
        "2+2 equals 4.",
        "You're welcome! Glad I could help.",
    ])
    
    # Run scenario
    runner = ScenarioRunner(mock_llm=mock)
    result = await runner.run(scenario)
    
    print(f"Scenario: {result.name}")
    print(f"Status: {result.status.value}")
    print(f"Duration: {result.duration_ms:.2f}ms")
    
    if result.error:
        print(f"Error: {result.error}")
    else:
        print("✓ All assertions passed!")


async def demo_test_suite():
    """Demonstrate TestSuiteBuilder."""
    print_section("7. Test Suite")
    
    # Build a test suite
    suite = (
        TestSuiteBuilder("Customer Service Agent Tests")
        .with_mock_llm(config=MockLLMConfig.from_strings(
            "Welcome to customer service! How may I assist you?",
            "I understand your concern. Let me help.",
            "Your issue has been resolved. Reference #12345.",
            "Thank you for contacting us. Have a great day!",
        ))
        .with_mock_tool("lookup_order", {"status": "shipped", "eta": "2 days"})
        .with_mock_tool("create_ticket", {"ticket_id": "T-12345"})
        .add_scenario(
            TestScenario(name="greeting")
            .add_turn("Hi", expected_contains=["welcome", "assist"])
        )
        .add_scenario(
            TestScenario(name="issue_handling")
            .add_turn("I have a problem", expected_contains=["help", "concern"])
        )
        .add_scenario(
            TestScenario(name="resolution")
            .add_turn("Please fix it", expected_contains=["resolved", "reference"])
        )
        .add_scenario(
            TestScenario(name="farewell")
            .add_turn("Thanks, bye!", expected_contains=["thank"])
        )
        .build()
    )
    
    # Run the suite
    result = await suite.run()
    
    print(f"Suite: {result.name}")
    print(f"Total tests: {result.total_tests}")
    print(f"Passed: {result.passed_tests}")
    print(f"Failed: {result.failed_tests}")
    print(f"Pass rate: {result.pass_rate:.1f}%")
    print(f"Total duration: {result.total_duration_ms:.2f}ms")
    
    print("\nIndividual Results:")
    for test in result.tests:
        status = "✓" if test.passed else "✗"
        print(f"  {status} {test.name}: {test.status.value}")
        if test.error:
            print(f"    Error: {test.error}")


async def demo_assertions():
    """Demonstrate assertion functions."""
    print_section("8. Assertions")
    
    # Create mock
    mock = MockLLM(responses=[
        "Hello! I found some results for your search query."
    ])
    
    # Make a call
    response = await mock.chat([{"role": "user", "content": "Search for Python"}])
    message = response['choices'][0]['message']
    
    # Run assertions
    print("Running assertions...")
    
    try:
        assert_response_contains(message, "results")
        print("  ✓ Response contains 'results'")
    except AssertionError as e:
        print(f"  ✗ {e}")
    
    try:
        assert_response_not_contains(message, "error")
        print("  ✓ Response does not contain 'error'")
    except AssertionError as e:
        print(f"  ✗ {e}")
    
    try:
        assert_llm_called(mock)
        print("  ✓ LLM was called")
    except AssertionError as e:
        print(f"  ✗ {e}")
    
    try:
        assert_llm_called(mock, times=1)
        print("  ✓ LLM was called exactly 1 time")
    except AssertionError as e:
        print(f"  ✗ {e}")
    
    # Demonstrate AgentAssertions
    print("\nUsing AgentAssertions:")
    tool = MockTool(name="search", return_value=[])
    await tool.execute(query="test")
    
    # Create tool registry for AgentAssertions
    tool_registry = MockToolRegistry()
    tool_registry.register(tool)
    
    assertions = AgentAssertions(mock_llm=mock, mock_tools=tool_registry)
    
    try:
        assertions.assert_llm_called()
        print("  ✓ assertions.assert_llm_called()")
    except AssertionError as e:
        print(f"  ✗ {e}")
    
    try:
        assertions.assert_tool_called("search")
        print("  ✓ assertions.assert_tool_called('search')")
    except AssertionError as e:
        print(f"  ✗ {e}")


async def demo_error_simulation():
    """Demonstrate error simulation."""
    print_section("9. Error Simulation")
    
    # Create mock with error response
    mock = MockLLM(responses=[
        MockResponse.text("First call succeeds"),
        MockResponse.text("Second call succeeds"),
        MockResponse.error("Rate limit exceeded", code="rate_limit"),
    ])
    
    messages = [{"role": "user", "content": "Hi"}]
    
    for i in range(3):
        try:
            response = await mock.chat(messages)
            content = response['choices'][0]['message']['content']
            print(f"Call {i+1}: {content}")
        except Exception as e:
            print(f"Call {i+1}: ERROR - {e}")
    
    # Tool that fails with custom side effect
    print("\nTool with failing side effect:")
    call_count = [0]
    
    def fail_on_third(**kwargs):
        call_count[0] += 1
        if call_count[0] >= 3:
            raise Exception("Too many calls")
        return "success"
    
    failing_tool = MockTool(
        name="limited_api",
        side_effect=fail_on_third,
    )
    
    for i in range(4):
        try:
            result = await failing_tool.execute()
            print(f"Call {i+1}: {result}")
        except Exception as e:
            print(f"Call {i+1}: ERROR - {e}")


async def demo_streaming():
    """Demonstrate streaming responses."""
    print_section("10. Streaming Responses")
    
    mock = MockLLM(responses=[
        "This is a streaming response that will be chunked."
    ])
    
    messages = [{"role": "user", "content": "Hi"}]
    
    print("Streaming response:")
    async for chunk in mock.stream(messages):
        if chunk.get('choices', [{}])[0].get('delta', {}).get('content'):
            print(chunk['choices'][0]['delta']['content'], end='', flush=True)
    print()  # New line


async def demo_recorded_calls():
    """Demonstrate call recording and inspection."""
    print_section("11. Call Recording")
    
    config = MockLLMConfig(
        responses=[
            MockResponse.text("Response 1"),
            MockResponse.text("Response 2"),
        ],
        record_calls=True,
    )
    
    mock = MockLLM(config=config)
    
    # Make some calls
    await mock.chat([{"role": "user", "content": "First message"}])
    await mock.chat([
        {"role": "user", "content": "First message"},
        {"role": "assistant", "content": "Response 1"},
        {"role": "user", "content": "Follow-up question"},
    ])
    
    # Inspect recorded calls
    print(f"Total calls recorded: {len(mock.recorded_calls)}")
    
    for i, call in enumerate(mock.recorded_calls):
        print(f"\nCall {i+1}:")
        print(f"  Timestamp: {call.timestamp}")
        print(f"  Messages: {len(call.messages)}")
        print(f"  Response: {call.response.content}")
        print(f"  Duration: {call.duration_ms:.2f}ms")


async def demo_complete_agent_test():
    """Demonstrate a complete agent testing workflow."""
    print_section("12. Complete Agent Test Example")
    
    @dataclass
    class SimpleAgent:
        """A simple agent for demonstration."""
        llm: MockLLM
        tools: MockToolRegistry
        
        async def handle_message(self, message: str) -> str:
            """Handle a user message."""
            # Check if we need to use tools
            if "search" in message.lower():
                search_result = await self.tools.execute("search", query=message)
                context = f"Search results: {search_result}"
            elif "calculate" in message.lower():
                calc_result = await self.tools.execute("calculate", expression="2+2")
                context = f"Calculation: {calc_result}"
            else:
                context = ""
            
            # Get LLM response
            messages = [
                {"role": "system", "content": f"Context: {context}" if context else ""},
                {"role": "user", "content": message}
            ]
            
            response = await self.llm.chat(messages)
            return response['choices'][0]['message']['content']
    
    # Set up mocks
    mock_llm = MockLLM(responses=[
        "I'll search for that information.",
        "Based on the search results: Python is great!",
        "Let me calculate that for you.",
        "The result is 4.",
    ])
    
    mock_tools = MockToolRegistry()
    mock_tools.register(MockTool(name="search", return_value=["Python", "AI"]))
    mock_tools.register(MockTool(name="calculate", return_value=4))
    
    # Create agent
    agent = SimpleAgent(llm=mock_llm, tools=mock_tools)
    
    # Test the agent
    print("Testing SimpleAgent:")
    
    response1 = await agent.handle_message("Search for Python info")
    print(f"\nUser: Search for Python info")
    print(f"Agent: {response1}")
    
    response2 = await agent.handle_message("What did you find?")
    print(f"\nUser: What did you find?")
    print(f"Agent: {response2}")
    
    response3 = await agent.handle_message("Calculate 2+2")
    print(f"\nUser: Calculate 2+2")
    print(f"Agent: {response3}")
    
    # Verify behavior
    print("\n--- Verification ---")
    print(f"LLM calls: {mock_llm.call_count}")
    print(f"Search tool calls: {mock_tools.get('search').call_count}")
    print(f"Calculate tool calls: {mock_tools.get('calculate').call_count}")
    
    # Assertions
    assert_llm_called(mock_llm, times=3)
    search_tool = mock_tools.get('search')
    calc_tool = mock_tools.get('calculate')
    
    # Check tool was called
    assert search_tool.call_count > 0, "Search tool was not called"
    assert calc_tool.call_count > 0, "Calculate tool was not called"
    
    print("\n✓ All assertions passed!")


async def main():
    """Run all demos."""
    print("\n" + "="*60)
    print("  AGENT TESTING FRAMEWORK DEMO")
    print("="*60)
    
    await demo_basic_mock_llm()
    await demo_mock_with_config()
    await demo_mock_tool_calls()
    await demo_mock_tools()
    await demo_conversation_fixture()
    await demo_test_scenario()
    await demo_test_suite()
    await demo_assertions()
    await demo_error_simulation()
    await demo_streaming()
    await demo_recorded_calls()
    await demo_complete_agent_test()
    
    print_section("Demo Complete!")
    print("The testing framework provides comprehensive tools for:")
    print("  • Mock LLM responses (deterministic, cycling, streaming)")
    print("  • Mock tools with configurable behavior")
    print("  • Scenario-based testing")
    print("  • Test suites with metrics")
    print("  • Rich assertion library")
    print("  • Error simulation")
    print("  • Call recording and inspection")


if __name__ == "__main__":
    asyncio.run(main())
