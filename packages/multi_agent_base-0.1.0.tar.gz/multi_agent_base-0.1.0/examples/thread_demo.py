#!/usr/bin/env python3
"""
AgentThread Demo - Persistent Conversation Sessions.

This example demonstrates:
1. Creating conversation threads
2. Saving and loading threads
3. Using checkpoints for rollback
4. Thread forking
5. Integration with ChatHistoryProvider
"""

import asyncio
import tempfile
from pathlib import Path

from multi_agent_base.core.thread import (
    AgentThread,
    create_thread,
    resume_thread,
)
from multi_agent_base.core.agent import Message


async def basic_usage():
    """Basic thread creation and message management."""
    print("\n" + "=" * 60)
    print("📝 Basic Usage")
    print("=" * 60)
    
    # Create a new thread
    thread = AgentThread(session_id="demo_session")
    print(f"Created thread: {thread.session_id}")
    
    # Add messages
    thread.add_system_message("You are a helpful assistant.")
    thread.add_user_message("What's the capital of France?")
    thread.add_assistant_message("The capital of France is Paris.")
    
    print(f"Messages: {thread.message_count}")
    for msg in thread.messages:
        print(f"  [{msg.role}]: {msg.content[:50]}...")
    
    # Thread variables
    thread.set_variable("topic", "geography")
    thread.set_variable("question_count", 1)
    print(f"Variables: {thread.variables}")


async def persistence_demo():
    """Demonstrate saving and loading threads."""
    print("\n" + "=" * 60)
    print("💾 Persistence Demo")
    print("=" * 60)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        # Create and save a thread
        thread = await create_thread(
            session_id="persist_demo",
            system_prompt="You are a helpful coding assistant.",
            metadata={"user_id": "user_123", "topic": "Python"},
        )
        
        thread.add_user_message("How do I read a file in Python?")
        thread.add_assistant_message("""
You can read a file using the open() function:

```python
with open('file.txt', 'r') as f:
    content = f.read()
```
""")
        
        # Save to file
        path = await thread.save(tmpdir)
        print(f"Saved to: {path}")
        
        # List available sessions
        sessions = await AgentThread.list_sessions(tmpdir)
        print(f"Available sessions: {sessions}")
        
        # Load and resume
        loaded = await resume_thread("persist_demo", path=tmpdir)
        print(f"Loaded thread with {loaded.message_count} messages")
        print(f"Metadata: {loaded.metadata}")
        
        # Continue the conversation
        loaded.add_user_message("Can you show me how to write to a file?")
        loaded.add_assistant_message("""
To write to a file:

```python
with open('file.txt', 'w') as f:
    f.write('Hello, World!')
```
""")
        
        # Save again
        await loaded.save()
        print(f"Updated thread saved with {loaded.message_count} messages")


async def checkpoint_demo():
    """Demonstrate checkpoints and rollback."""
    print("\n" + "=" * 60)
    print("🔖 Checkpoint Demo")
    print("=" * 60)
    
    thread = AgentThread(session_id="checkpoint_demo")
    
    # Build up conversation
    thread.add_user_message("Let's plan a trip to Japan.")
    thread.add_assistant_message("Great choice! What aspects would you like to plan?")
    
    # Create checkpoint after initial planning
    cp1 = thread.create_checkpoint(
        "initial_planning",
        metadata={"stage": "destination_selected"},
    )
    print(f"Created checkpoint: {cp1.name} at message {cp1.message_index}")
    
    # Continue conversation - take wrong path
    thread.add_user_message("Actually, let's go to Paris instead.")
    thread.add_assistant_message("Paris is wonderful! Let me suggest...")
    thread.add_user_message("Hmm, I changed my mind again.")
    
    print(f"Messages before rollback: {thread.message_count}")
    
    # Rollback to checkpoint
    success = thread.rollback_to_checkpoint(cp1.checkpoint_id)
    print(f"Rollback successful: {success}")
    print(f"Messages after rollback: {thread.message_count}")
    print(f"Last message: [{thread.last_message.role}] {thread.last_message.content[:50]}...")
    
    # Continue on the right path
    thread.add_user_message("I want to focus on Tokyo and Kyoto.")
    thread.add_assistant_message("Excellent! For Tokyo, I recommend...")
    
    print(f"Final message count: {thread.message_count}")


async def fork_demo():
    """Demonstrate thread forking."""
    print("\n" + "=" * 60)
    print("🌿 Fork Demo")
    print("=" * 60)
    
    # Create original thread
    original = AgentThread(session_id="original_thread")
    original.add_system_message("You are a creative writing assistant.")
    original.add_user_message("Write a story about a robot.")
    original.add_assistant_message("Once upon a time, there was a robot named Atlas...")
    
    print(f"Original thread: {original.session_id}")
    print(f"Messages: {original.message_count}")
    
    # Fork for alternate storyline
    fork1 = original.fork("storyline_adventure")
    fork1.add_user_message("Make it an adventure story!")
    fork1.add_assistant_message("Atlas decided to explore the unknown galaxy...")
    
    # Fork for romance storyline
    fork2 = original.fork("storyline_romance")
    fork2.add_user_message("Make it a romance story!")
    fork2.add_assistant_message("Atlas met another robot named Luna...")
    
    print(f"\nForked threads:")
    print(f"  {fork1.session_id}: {fork1.message_count} messages - {fork1.metadata}")
    print(f"  {fork2.session_id}: {fork2.message_count} messages - {fork2.metadata}")
    
    # Original unchanged
    print(f"\nOriginal unchanged: {original.message_count} messages")


async def chat_history_provider_demo():
    """Demonstrate integration with ChatHistoryProvider."""
    print("\n" + "=" * 60)
    print("🔄 ChatHistoryProvider Integration")
    print("=" * 60)
    
    # Create thread with messages
    thread = AgentThread(session_id="provider_demo")
    thread.add_user_message("Hello!")
    thread.add_assistant_message("Hi there! How can I help you?")
    
    # Get as ChatHistoryProvider
    provider = thread.as_chat_history_provider()
    print(f"Created ChatHistoryProvider for thread: {thread.session_id}")
    
    # Get chat messages
    from multi_agent_base.core.chat_history import InvokingContext
    
    messages = await provider.invoking_async(InvokingContext())
    print(f"Retrieved {len(messages)} messages via provider:")
    for msg in messages:
        print(f"  [{msg.role}]: {msg.content}")
    
    # Serialize provider (for checkpointing)
    state = provider.serialize()
    print(f"\nSerialized state has {len(state['messages'])} messages")


async def summary_demo():
    """Demonstrate thread summary and utilities."""
    print("\n" + "=" * 60)
    print("📊 Summary Demo")
    print("=" * 60)
    
    thread = AgentThread(
        session_id="summary_demo",
        metadata={"user": "Alice", "purpose": "coding_help"},
    )
    
    # Add conversation
    thread.add_system_message("You are a Python expert.")
    thread.add_user_message("Explain list comprehensions.")
    thread.add_assistant_message("List comprehensions are a concise way to create lists...")
    thread.add_user_message("Show me examples.")
    thread.add_assistant_message("Here are some examples: [x**2 for x in range(10)]...")
    
    # Create checkpoints
    thread.create_checkpoint("intro_complete")
    
    # Set variables
    thread.set_variable("topic", "list_comprehensions")
    thread.set_variable("examples_shown", 3)
    
    # Get summary
    summary = thread.get_summary()
    print("Thread Summary:")
    for key, value in summary.items():
        print(f"  {key}: {value}")
    
    # String representation
    print(f"\nRepr: {repr(thread)}")
    print(f"Length: {len(thread)}")


async def main():
    """Run all demos."""
    print("🧵 AgentThread - Persistent Conversation Sessions")
    print("=" * 60)
    
    await basic_usage()
    await persistence_demo()
    await checkpoint_demo()
    await fork_demo()
    await chat_history_provider_demo()
    await summary_demo()
    
    print("\n" + "=" * 60)
    print("✅ All demos completed!")
    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(main())
