#!/usr/bin/env python3
"""
Workflow DevUI Demo - Email Processing Pipeline

This demonstrates AF DevUI's Workflow Visualization feature
with a multi-step email processing workflow.

The DevUI will show:
- Real-time workflow graph with executor states (Pending, Running, Completed)
- Events panel showing workflow_event.complete events
- Traces panel for observability
"""

import asyncio
import logging
from dataclasses import dataclass
from typing_extensions import Never

from pydantic import BaseModel, Field

from agent_framework import (
    Executor,
    WorkflowBuilder,
    WorkflowContext,
    handler,
)
from agent_framework.devui import serve


# ============================================================
# Data Models
# ============================================================

class EmailInput(BaseModel):
    """Input model for email processing."""
    email: str = Field(
        description="The email message to be processed.",
        default="Hello! Thank you for your message. I wanted to follow up on our meeting.",
    )


@dataclass
class ProcessedEmail:
    """Processed email data."""
    original_message: str
    cleaned_message: str
    word_count: int


@dataclass
class AnalyzedEmail:
    """Analyzed email data with sentiment and urgency."""
    email: ProcessedEmail
    sentiment: str
    is_urgent: bool
    keywords: list[str]


@dataclass
class SpamCheckResult:
    """Spam check result."""
    email: AnalyzedEmail
    is_spam: bool
    spam_score: float


@dataclass
class ResponseResult:
    """Auto-response result."""
    email: SpamCheckResult
    auto_response: str
    priority: str


# ============================================================
# Workflow Executors - Class-based with @handler
# ============================================================

class EmailPreprocessor(Executor):
    """Step 1: Preprocess incoming email - extract metadata and clean content."""
    
    @handler
    async def handle_email(self, email: EmailInput, ctx: WorkflowContext[ProcessedEmail]) -> None:
        """Clean and preprocess the email message."""
        await asyncio.sleep(1.0)  # Simulate processing
        
        # Clean and process email
        cleaned = email.email.strip()
        word_count = len(email.email.split())
        
        result = ProcessedEmail(
            original_message=email.email,
            cleaned_message=cleaned,
            word_count=word_count,
        )
        
        await ctx.send_message(result)


class ContentAnalyzer(Executor):
    """Step 2: Analyze email content for keywords and sentiment."""
    
    @handler
    async def handle_preprocessed(self, email: ProcessedEmail, ctx: WorkflowContext[AnalyzedEmail]) -> None:
        """Analyze email content."""
        await asyncio.sleep(1.5)  # Simulate AI analysis
        
        text = email.cleaned_message.lower()
        
        # Simple sentiment analysis
        positive_words = ["thank", "appreciate", "great", "good", "happy"]
        negative_words = ["urgent", "problem", "issue", "complaint"]
        
        positive_count = sum(1 for w in positive_words if w in text)
        negative_count = sum(1 for w in negative_words if w in text)
        
        if positive_count > negative_count:
            sentiment = "positive"
        elif negative_count > positive_count:
            sentiment = "negative"
        else:
            sentiment = "neutral"
        
        # Check urgency
        urgent_keywords = ["urgent", "asap", "immediately", "critical"]
        is_urgent = any(kw in text for kw in urgent_keywords)
        
        # Extract keywords
        keywords = [w for w in text.split() if len(w) > 4][:5]
        
        result = AnalyzedEmail(
            email=email,
            sentiment=sentiment,
            is_urgent=is_urgent,
            keywords=keywords,
        )
        
        await ctx.send_message(result)


class SpamDetector(Executor):
    """Step 3: Determine if email is spam based on analysis."""
    
    @handler
    async def handle_analyzed(self, email: AnalyzedEmail, ctx: WorkflowContext[SpamCheckResult]) -> None:
        """Check if email is spam."""
        await asyncio.sleep(0.8)  # Simulate spam check
        
        text = email.email.cleaned_message.lower()
        
        # Spam keywords
        spam_keywords = ["free", "winner", "click here", "limited time", "act now"]
        spam_count = sum(1 for kw in spam_keywords if kw in text)
        
        spam_score = min(spam_count * 0.25, 1.0)
        is_spam = spam_score > 0.5
        
        result = SpamCheckResult(
            email=email,
            is_spam=is_spam,
            spam_score=spam_score,
        )
        
        await ctx.send_message(result)


class MessageResponder(Executor):
    """Step 4: Generate auto-response for legitimate emails."""
    
    @handler
    async def handle_spam_result(self, result: SpamCheckResult, ctx: WorkflowContext[ResponseResult]) -> None:
        """Generate auto-response."""
        await asyncio.sleep(1.2)  # Simulate response generation
        
        if result.email.is_urgent:
            auto_response = "Thank you for your urgent message. We will respond within 1 hour."
            priority = "high"
        else:
            auto_response = "Thank you for your email. We will respond within 24 hours."
            priority = "normal"
        
        response_result = ResponseResult(
            email=result,
            auto_response=auto_response,
            priority=priority,
        )
        
        await ctx.send_message(response_result)


class FinalProcessor(Executor):
    """Step 5: Final processing - log and store result."""
    
    @handler
    async def handle_response(self, result: ResponseResult, ctx: WorkflowContext[Never, str]) -> None:
        """Complete the workflow with final processing."""
        await asyncio.sleep(0.5)  # Simulate final processing
        
        # Build summary
        is_spam = result.email.is_spam
        sentiment = result.email.email.sentiment
        priority = result.priority
        
        if is_spam:
            summary = f"Email marked as SPAM (score: {result.email.spam_score:.2f}). No response sent."
        else:
            summary = (
                f"Email processed successfully!\n"
                f"Sentiment: {sentiment}\n"
                f"Priority: {priority}\n"
                f"Auto-response: {result.auto_response}"
            )
        
        await ctx.yield_output(summary)


# ============================================================
# Build the Workflow
# ============================================================

# Create executor instances
email_preprocessor = EmailPreprocessor(id="email_preprocessor")
content_analyzer = ContentAnalyzer(id="content_analyzer")
spam_detector = SpamDetector(id="spam_detector")
message_responder = MessageResponder(id="message_responder")
final_processor = FinalProcessor(id="final_processor")

# Build the workflow
workflow = (
    WorkflowBuilder(
        name="Email Processing Pipeline",
        description="5-step email processing workflow with spam detection and auto-response",
    )
    .set_start_executor(email_preprocessor)
    .add_edge(email_preprocessor, content_analyzer)
    .add_edge(content_analyzer, spam_detector)
    .add_edge(spam_detector, message_responder)
    .add_edge(message_responder, final_processor)
    .build()
)


# ============================================================
# Main - Start DevUI with Workflow
# ============================================================

def main():
    logging.basicConfig(level=logging.INFO, format="%(message)s")
    logger = logging.getLogger(__name__)
    
    print("=" * 60)
    print("🚀 Agent Framework DevUI - Workflow Visualization Demo")
    print("=" * 60)
    print()
    print("Pipeline:")
    print("  email_preprocessor → content_analyzer → spam_detector")
    print("       → message_responder → final_processor")
    print()
    print("🌐 Starting DevUI server...")
    print("   Open http://localhost:8080 in your browser")
    print("   Select the workflow and click 'Run' to see visualization")
    print("   Press Ctrl+C to stop")
    print()
    
    # Start DevUI with the workflow
    serve(
        entities=[workflow],
        port=8080,
        auto_open=True,
        instrumentation_enabled=True,
    )


if __name__ == "__main__":
    main()
