#!/bin/bash
# Run All Services
# Starts Aspire Dashboard and DevUI together
# 
# Usage: ./scripts/run_all.sh
# Access: 
#   - DevUI:    http://localhost:8080
#   - Aspire:   http://localhost:18888

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

cd "$PROJECT_DIR"

echo "============================================================"
echo "🚀 Agent Framework - Full Stack"
echo "============================================================"
echo ""

# Function to cleanup on exit
cleanup() {
    echo ""
    echo "🛑 Shutting down services..."
    docker stop aspire-dashboard 2>/dev/null || true
    kill $DEVUI_PID 2>/dev/null || true
    echo "✅ All services stopped"
}

trap cleanup EXIT

# Start Aspire Dashboard
echo "1️⃣  Starting Aspire Dashboard..."
"$SCRIPT_DIR/run_aspire_dashboard.sh"

echo ""
echo "2️⃣  Starting DevUI..."
echo ""

# Ask which demo to run
echo "Hangi demo'yu çalıştırmak istiyorsunuz?"
echo "  1) Agent Demo (Ollama ile sohbet)"
echo "  2) Workflow Demo (Görselleştirme)"
echo ""
read -p "Seçiminiz (1 veya 2): " choice

case $choice in
    1)
        echo ""
        echo "🤖 Agent Demo başlatılıyor..."
        source .venv/bin/activate
        export PYTHONPATH=src
        python examples/devui_ollama_agent.py &
        DEVUI_PID=$!
        ;;
    2)
        echo ""
        echo "📊 Workflow Demo başlatılıyor..."
        source .venv/bin/activate
        export PYTHONPATH=src
        python examples/workflow_devui_demo.py &
        DEVUI_PID=$!
        ;;
    *)
        echo "Geçersiz seçim. Workflow Demo başlatılıyor..."
        source .venv/bin/activate
        export PYTHONPATH=src
        python examples/workflow_devui_demo.py &
        DEVUI_PID=$!
        ;;
esac

sleep 2

echo ""
echo "┌─────────────────────────────────────────────────────────┐"
echo "│  ✅ Tüm servisler çalışıyor!                            │"
echo "│                                                         │"
echo "│  📍 DevUI:    http://localhost:8080                     │"
echo "│  📍 Aspire:   http://localhost:18888                    │"
echo "│                                                         │"
echo "│  Press Ctrl+C to stop all services                      │"
echo "└─────────────────────────────────────────────────────────┘"
echo ""

# Wait for DevUI process
wait $DEVUI_PID
