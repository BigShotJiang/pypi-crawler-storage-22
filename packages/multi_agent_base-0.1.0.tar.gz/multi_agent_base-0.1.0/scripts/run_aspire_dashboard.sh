#!/bin/bash
# Aspire Dashboard for Observability
# Starts the Aspire Dashboard Docker container for viewing OpenTelemetry traces
# 
# Usage: ./scripts/run_aspire_dashboard.sh
# Access: http://localhost:18888

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

cd "$PROJECT_DIR"

echo "============================================================"
echo "🔭 Aspire Dashboard - OpenTelemetry Observability"
echo "============================================================"
echo ""

# Check if Docker is running
if ! docker info > /dev/null 2>&1; then
    echo "❌ Docker is not running!"
    echo "   Please start Docker Desktop first"
    exit 1
fi

echo "✅ Docker is running"

# Check if container is already running
if docker ps | grep -q aspire-dashboard; then
    echo "✅ Aspire Dashboard is already running"
else
    # Remove old container if exists
    docker rm -f aspire-dashboard 2>/dev/null || true
    
    echo "🚀 Starting Aspire Dashboard container..."
    docker run --rm -d \
        -p 18888:18888 \
        -p 4317:18889 \
        --name aspire-dashboard \
        mcr.microsoft.com/dotnet/aspire-dashboard:latest
    
    # Wait for container to start
    sleep 3
fi

# Get login token
echo ""
echo "🔑 Login token:"
docker logs aspire-dashboard 2>&1 | grep -o 't=[^"]*' | head -1 || echo "   (Check docker logs aspire-dashboard)"

echo ""
echo "┌─────────────────────────────────────────────────────────┐"
echo "│  📍 Aspire Dashboard: http://localhost:18888            │"
echo "│  📍 OTLP Endpoint:    localhost:4317                    │"
echo "│                                                         │"
echo "│  📝 Not:                                                │"
echo "│     DevUI'ı --instrumentation-enabled ile çalıştırın    │"
echo "│     Trace'leri Aspire Dashboard'da görebilirsiniz       │"
echo "└─────────────────────────────────────────────────────────┘"
echo ""
echo "Container durumu:"
docker ps --filter name=aspire-dashboard --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}"
echo ""
echo "Durdurmak için: docker stop aspire-dashboard"
