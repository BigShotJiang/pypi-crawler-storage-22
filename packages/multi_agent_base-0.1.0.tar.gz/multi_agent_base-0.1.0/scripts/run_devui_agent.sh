#!/bin/bash
# DevUI Agent with Ollama
# Starts the DevUI server with an Ollama-powered agent
# 
# Usage: ./scripts/run_devui_agent.sh
# Access: http://localhost:8080

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

cd "$PROJECT_DIR"

echo "============================================================"
echo "🤖 Agent Framework DevUI - Ollama Agent"
echo "============================================================"
echo ""

# Check if Ollama is running
if ! curl -s http://localhost:11434/api/tags > /dev/null 2>&1; then
    echo "❌ Ollama is not running!"
    echo "   Please start Ollama first: ollama serve"
    exit 1
fi

echo "✅ Ollama is running"

# Check for required model
MODEL="qwen2.5-coder:7b"
if ! ollama list | grep -q "$MODEL"; then
    echo "⚠️  Model $MODEL not found. Pulling..."
    ollama pull "$MODEL"
fi

echo "✅ Model $MODEL is available"
echo ""

# Activate virtual environment and run
source .venv/bin/activate
export PYTHONPATH=src

echo "🚀 Starting DevUI server..."
echo ""
echo "┌─────────────────────────────────────────────────────────┐"
echo "│  📍 DevUI:    http://localhost:8080                     │"
echo "│  📍 Aspire:   http://localhost:18888 (if running)       │"
echo "└─────────────────────────────────────────────────────────┘"
echo ""
echo "Press Ctrl+C to stop"
echo ""

python examples/devui_ollama_agent.py
