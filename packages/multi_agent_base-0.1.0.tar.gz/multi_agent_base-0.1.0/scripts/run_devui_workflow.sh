#!/bin/bash
# DevUI Workflow Visualization
# Starts the DevUI server with a sample workflow for visualization
# 
# Usage: ./scripts/run_devui_workflow.sh
# Access: http://localhost:8080

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

cd "$PROJECT_DIR"

echo "============================================================"
echo "📊 Agent Framework DevUI - Workflow Visualization"
echo "============================================================"
echo ""
echo "Pipeline:"
echo "  email_preprocessor → content_analyzer → spam_detector"
echo "       → message_responder → final_processor"
echo ""

# Activate virtual environment and run
source .venv/bin/activate
export PYTHONPATH=src

echo "🚀 Starting DevUI server..."
echo ""
echo "┌─────────────────────────────────────────────────────────┐"
echo "│  📍 DevUI:    http://localhost:8080                     │"
echo "│                                                         │"
echo "│  📝 Kullanım:                                           │"
echo "│     1. Workflow'u seç                                   │"
echo "│     2. Input alanına email yaz                          │"
echo "│     3. 'Run' butonuna tıkla                             │"
echo "│     4. Executor'ları canlı izle!                        │"
echo "└─────────────────────────────────────────────────────────┘"
echo ""
echo "Press Ctrl+C to stop"
echo ""

python examples/workflow_devui_demo.py
