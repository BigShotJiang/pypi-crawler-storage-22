#!/bin/bash
# WorkflowViz - Graph Export
# Generates workflow visualization in Mermaid, DOT, and SVG formats
# 
# Usage: ./scripts/run_workflow_viz.sh
# Output: workflow_graph.svg

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

cd "$PROJECT_DIR"

echo "============================================================"
echo "📈 WorkflowViz - Workflow Graph Export"
echo "============================================================"
echo ""

# Check for graphviz
if ! command -v dot &> /dev/null; then
    echo "⚠️  Graphviz not found. Installing..."
    if [[ "$OSTYPE" == "darwin"* ]]; then
        brew install graphviz
    else
        echo "❌ Please install graphviz manually"
        exit 1
    fi
fi

echo "✅ Graphviz is installed"
echo ""

# Activate virtual environment and run
source .venv/bin/activate
export PYTHONPATH=src

echo "🚀 Generating workflow graph..."
echo ""

python examples/multi_agent_workflow_viz.py

echo ""
echo "┌─────────────────────────────────────────────────────────┐"
echo "│  ✅ Graph generated successfully!                       │"
echo "│                                                         │"
echo "│  📄 Output files:                                       │"
echo "│     • workflow_graph.svg (SVG image)                    │"
echo "│     • Mermaid diagram (console output)                  │"
echo "│     • DOT diagram (console output)                      │"
echo "└─────────────────────────────────────────────────────────┘"
echo ""

# Open SVG file
if [[ "$OSTYPE" == "darwin"* ]]; then
    open workflow_graph.svg
    echo "📂 SVG file opened in default viewer"
fi
