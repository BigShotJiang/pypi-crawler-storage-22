"""
Multi-Agent Base Framework

A reusable foundation for building multi-agent AI systems with
observability, cost tracking, and A2A protocol support.
"""

from multi_agent_base.core.config import (
    AgentConfig,
    ObservabilityConfig,
    PatternType,
    ProviderConfig,
    ProviderType,
    SystemConfig,
    MemoryConfig,
    MemoryBackendType,
    ResilienceConfig,
    BackoffStrategy,
)
from multi_agent_base.core.agent import BaseAgent
from multi_agent_base.core.patterns import (
    BasePattern,
    PatternResult,
    SingleAgentPattern,
    SupervisorPattern,
    SwarmPattern,
    PipelinePattern,
    ParallelPattern,
    RouterPattern,
    ReflectionPattern,
    BlackboardPattern,
    CompositePattern,
    DebatePattern,
    create_pattern,
)
from multi_agent_base.core.tools import (
    BaseTool,
    FunctionTool,
    ActionTool,
    ToolResult,
    ToolResultStatus,
    ToolParameter,
)
from multi_agent_base.core.registry import (
    ToolRegistry,
    ToolNamespace,
    get_registry,
)
from multi_agent_base.core.decorators import (
    tool,
    async_tool,
    action,
    skill,
    get_tool,
    get_tools,
    register_tools,
)
from multi_agent_base.core.thread import (
    AgentThread,
    ThreadState,
    ThreadCheckpoint,
    ThreadChatHistoryProvider,
)
from multi_agent_base.hitl import (
    ApprovalHandler,
    ApprovalRequest,
    ApprovalResponse,
    ApprovalStatus,
    ConsoleApprovalHandler,
    require_approval,
    conditional_approval,
    Checkpoint,
    CheckpointManager,
    CheckpointStatus,
    CheckpointState,
    WorkflowCheckpoint,
    AuditEntry,
    AuditLogger,
    AuditDecision,
    AuditSeverity,
    InMemoryAuditBackend,
    FileAuditBackend,
    ConsoleAuditBackend,
    create_audit_logger,
)
from multi_agent_base.mcp import (
    # Protocol types
    MCPRequest,
    MCPResponse,
    MCPError,
    MCPNotification,
    # Tool types
    MCPTool,
    MCPToolParameter,
    MCPToolResult,
    MCPToolResultContent,
    # Resource types
    MCPResource,
    MCPResourceContent,
    MCPResourceTemplate,
    # Prompt types
    MCPPrompt,
    MCPPromptArgument,
    MCPPromptMessage,
    # Error codes
    MCPErrorCode,
    # Client
    MCPClient,
    MCPTransport,
    StdioTransport,
    HTTPTransport,
    SSETransport,
    # Server
    MCPServer,
    MCPServerConfig,
    # Discovery
    ToolDiscovery,
    DiscoveredTool,
    MCPToolWrapper,
    discover_tools,
    discover_and_convert,
    # Constants
    MCP_PROTOCOL_VERSION,
)
from multi_agent_base.multimodal import (
    # Core types
    MediaContent,
    MultimodalMessage,
    MediaType,
    # Format enums
    ImageFormat,
    AudioFormat,
    VideoFormat,
    DocumentFormat,
    # Provider capabilities
    PROVIDER_CAPABILITIES,
    # Encoders
    Base64Encoder,
    DecodedDataURI,
    URLEncoder,
    ContentHasher,
    MIMETypeDetector,
    # Info types
    ImageDimensions,
    AudioInfo,
    VideoInfo,
    ProcessingResult,
    # Processor classes
    ImageProcessor,
    AudioProcessor,
    VideoProcessor,
    MediaProcessor,
    # Convenience functions
    get_image_dimensions,
    get_audio_info,
    get_video_info,
    is_valid_image,
    is_valid_audio,
    is_valid_video,
)
from multi_agent_base.context import (
    # Types
    MessageRole,
    PruningStrategy,
    CompressionMethod,
    ContextMessage,
    ContextWindow,
    ContextStats,
    OptimizationConfig,
    ToolContext,
    ContextSnapshot,
    # Optimizer
    ContextOptimizer,
    OptimizationResult,
    TokenEstimator,
    # Pruner
    ContextPruner,
    ConversationPruner,
    PruningResult,
    # Compressor
    ContextCompressor,
    CompressionResult,
)
from multi_agent_base.testing import (
    # Types
    MockResponseType,
    AssertionType,
    TestStatus,
    MockToolCall,
    MockResponse,
    MockLLMConfig,
    MockToolConfig,
    RecordedCall,
    AssertionResult,
    TestMetrics,
    TestResult,
    TestSuiteResult,
    ConversationTurn,
    TestScenario,
    # Mocks
    MockLLM,
    MockLLMError,
    MockTool,
    MockToolError,
    MockToolRegistry,
    MockAgent,
    # Fixtures
    TestContext,
    ConversationFixture,
    ScenarioRunner,
    TestSuiteBuilder,
    TestSuite,
    agent_test,
    with_mock_llm,
    with_mock_tools,
    mock_llm_context,
    mock_tool_context,
    # Assertions
    AgentAssertions,
    assert_tool_called,
    assert_tool_not_called,
    assert_response_contains,
    assert_response_not_contains,
    assert_response_matches,
    assert_cost_under,
    assert_tokens_under,
    assert_latency_under,
    assert_llm_called,
)

__version__ = "0.1.0"

__all__ = [
    # Config
    "AgentConfig",
    "ObservabilityConfig",
    "PatternType",
    "ProviderConfig",
    "ProviderType",
    "SystemConfig",
    "MemoryConfig",
    "MemoryBackendType",
    "ResilienceConfig",
    "BackoffStrategy",
    # Agent
    "BaseAgent",
    # Patterns
    "BasePattern",
    "PatternResult",
    "SingleAgentPattern",
    "SupervisorPattern",
    "SwarmPattern",
    "PipelinePattern",
    "ParallelPattern",
    "RouterPattern",
    "ReflectionPattern",
    "BlackboardPattern",
    "CompositePattern",
    "DebatePattern",
    "create_pattern",
    # Tools
    "BaseTool",
    "FunctionTool",
    "ActionTool",
    "ToolResult",
    "ToolResultStatus",
    "ToolParameter",
    # Registry
    "ToolRegistry",
    "ToolNamespace",
    "get_registry",
    # Decorators
    "tool",
    "async_tool",
    "action",
    "skill",
    "get_tool",
    "get_tools",
    "register_tools",
    # Thread Management
    "AgentThread",
    "ThreadState",
    "ThreadCheckpoint",
    "ThreadChatHistoryProvider",
    # HITL - Approval
    "ApprovalHandler",
    "ApprovalRequest",
    "ApprovalResponse",
    "ApprovalStatus",
    "ConsoleApprovalHandler",
    "require_approval",
    "conditional_approval",
    # HITL - Checkpoints
    "Checkpoint",
    "CheckpointManager",
    "CheckpointStatus",
    "CheckpointState",
    "WorkflowCheckpoint",
    # HITL - Audit
    "AuditEntry",
    "AuditLogger",
    "AuditDecision",
    "AuditSeverity",
    "InMemoryAuditBackend",
    "FileAuditBackend",
    "ConsoleAuditBackend",
    "create_audit_logger",
    # MCP - Protocol types
    "MCPRequest",
    "MCPResponse",
    "MCPError",
    "MCPNotification",
    # MCP - Tool types
    "MCPTool",
    "MCPToolParameter",
    "MCPToolResult",
    "MCPToolResultContent",
    # MCP - Resource types
    "MCPResource",
    "MCPResourceContent",
    "MCPResourceTemplate",
    # MCP - Prompt types
    "MCPPrompt",
    "MCPPromptArgument",
    "MCPPromptMessage",
    # MCP - Error codes
    "MCPErrorCode",
    # MCP - Client
    "MCPClient",
    "MCPTransport",
    "StdioTransport",
    "HTTPTransport",
    "SSETransport",
    # MCP - Server
    "MCPServer",
    "MCPServerConfig",
    # MCP - Discovery
    "ToolDiscovery",
    "DiscoveredTool",
    "MCPToolWrapper",
    "discover_tools",
    "discover_and_convert",
    # MCP - Constants
    "MCP_PROTOCOL_VERSION",
    # Multimodal - Core types
    "MediaContent",
    "MultimodalMessage",
    "MediaType",
    # Multimodal - Format enums
    "ImageFormat",
    "AudioFormat",
    "VideoFormat",
    "DocumentFormat",
    # Multimodal - Provider capabilities
    "PROVIDER_CAPABILITIES",
    # Multimodal - Encoders
    "Base64Encoder",
    "DecodedDataURI",
    "URLEncoder",
    "ContentHasher",
    "MIMETypeDetector",
    # Multimodal - Info types
    "ImageDimensions",
    "AudioInfo",
    "VideoInfo",
    "ProcessingResult",
    # Multimodal - Processor classes
    "ImageProcessor",
    "AudioProcessor",
    "VideoProcessor",
    "MediaProcessor",
    # Multimodal - Convenience functions
    "get_image_dimensions",
    "get_audio_info",
    "get_video_info",
    "is_valid_image",
    "is_valid_audio",
    "is_valid_video",
    # Context Engineering - Types
    "MessageRole",
    "PruningStrategy",
    "CompressionMethod",
    "ContextMessage",
    "ContextWindow",
    "ContextStats",
    "OptimizationConfig",
    "ToolContext",
    "ContextSnapshot",
    # Context Engineering - Optimizer
    "ContextOptimizer",
    "OptimizationResult",
    "TokenEstimator",
    # Context Engineering - Pruner
    "ContextPruner",
    "ConversationPruner",
    "PruningResult",
    # Context Engineering - Compressor
    "ContextCompressor",
    "CompressionResult",
    # Testing Framework - Types
    "MockResponseType",
    "AssertionType",
    "TestStatus",
    "MockToolCall",
    "MockResponse",
    "MockLLMConfig",
    "MockToolConfig",
    "RecordedCall",
    "AssertionResult",
    "TestMetrics",
    "TestResult",
    "TestSuiteResult",
    "ConversationTurn",
    "TestScenario",
    # Testing Framework - Mocks
    "MockLLM",
    "MockLLMError",
    "MockTool",
    "MockToolError",
    "MockToolRegistry",
    "MockAgent",
    # Testing Framework - Fixtures
    "TestContext",
    "ConversationFixture",
    "ScenarioRunner",
    "TestSuiteBuilder",
    "TestSuite",
    "agent_test",
    "with_mock_llm",
    "with_mock_tools",
    "mock_llm_context",
    "mock_tool_context",
    # Testing Framework - Assertions
    "AgentAssertions",
    "assert_tool_called",
    "assert_tool_not_called",
    "assert_response_contains",
    "assert_response_not_contains",
    "assert_response_matches",
    "assert_cost_under",
    "assert_tokens_under",
    "assert_latency_under",
    "assert_llm_called",
]
