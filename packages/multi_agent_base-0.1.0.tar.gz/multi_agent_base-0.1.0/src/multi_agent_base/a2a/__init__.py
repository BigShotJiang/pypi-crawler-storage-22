"""A2A Protocol module for Agent Cards, skill discovery, threading, and HTTP support.

This module provides:
- Agent Cards: Metadata describing agent capabilities
- Skill Discovery: Finding agents by skill
- HTTP Server/Client: Serving and discovering agent cards via HTTP
- Threading: Conversation threading with context preservation
- Errors: Standardized error handling
"""

from multi_agent_base.a2a.agent_card import (
    AgentCard,
    AgentSkill,
    AgentCapabilities,
    AgentAuthentication,
    AgentProvider,
)
from multi_agent_base.a2a.skill_discovery import SkillDiscoverer
from multi_agent_base.a2a.http import (
    A2AServer,
    A2AServerConfig,
    A2AClient,
    A2ARegistry,
)
from multi_agent_base.a2a.threading import (
    ConversationThread,
    ThreadMessage,
    ThreadContext,
    ThreadManager,
    ThreadState,
    MessageRole,
    MessageStatus,
)
from multi_agent_base.a2a.errors import (
    A2AError,
    A2AErrorCode,
    A2AErrorDetails,
    A2AErrorHandler,
    A2ADiscoveryError,
    A2AConnectionError,
    A2ATimeoutError,
    A2AAuthenticationError,
    A2AProtocolError,
    A2AAgentError,
    A2AThreadError,
    A2AValidationError,
    A2ARateLimitError,
)

__all__ = [
    # Agent Card
    "AgentCard",
    "AgentSkill",
    "AgentCapabilities",
    "AgentAuthentication",
    "AgentProvider",
    # Skill Discovery
    "SkillDiscoverer",
    # HTTP Server/Client
    "A2AServer",
    "A2AServerConfig",
    "A2AClient",
    "A2ARegistry",
    # Threading
    "ConversationThread",
    "ThreadMessage",
    "ThreadContext",
    "ThreadManager",
    "ThreadState",
    "MessageRole",
    "MessageStatus",
    # Errors
    "A2AError",
    "A2AErrorCode",
    "A2AErrorDetails",
    "A2AErrorHandler",
    "A2ADiscoveryError",
    "A2AConnectionError",
    "A2ATimeoutError",
    "A2AAuthenticationError",
    "A2AProtocolError",
    "A2AAgentError",
    "A2AThreadError",
    "A2AValidationError",
    "A2ARateLimitError",
]
