"""
A2A Protocol Agent Card implementation.

Agent Cards are JSON metadata documents that describe an agent's
capabilities, skills, and communication requirements based on
Google's Agent-to-Agent (A2A) protocol specification.

Reference: https://github.com/google/A2A
"""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Any, Literal

from pydantic import BaseModel, Field, HttpUrl


class AgentSkill(BaseModel):
    """Represents a skill that an agent can perform.
    
    Skills describe specific capabilities of an agent that
    can be invoked through the A2A protocol.
    
    Attributes:
        id: Unique identifier for the skill
        name: Human-readable skill name
        description: Detailed description of what the skill does
        tags: Categorization tags
        examples: Example inputs/prompts for the skill
        input_modes: Supported input content types
        output_modes: Supported output content types
    """
    
    id: str = Field(
        ...,
        description="Unique identifier for the skill"
    )
    name: str = Field(
        ...,
        description="Human-readable skill name"
    )
    description: str = Field(
        ...,
        description="Detailed description of the skill"
    )
    tags: list[str] = Field(
        default_factory=list,
        description="Categorization tags"
    )
    examples: list[str] = Field(
        default_factory=list,
        description="Example inputs/prompts"
    )
    input_modes: list[str] = Field(
        default_factory=lambda: ["text/plain"],
        description="Supported input content types"
    )
    output_modes: list[str] = Field(
        default_factory=lambda: ["text/plain"],
        description="Supported output content types"
    )


class AgentCapabilities(BaseModel):
    """Describes the capabilities of an agent.
    
    Attributes:
        streaming: Whether the agent supports streaming responses
        push_notifications: Whether the agent supports push notifications
        state_transition_history: Whether agent maintains state history
    """
    
    streaming: bool = Field(
        default=False,
        description="Supports streaming responses"
    )
    push_notifications: bool = Field(
        default=False,
        description="Supports push notifications"
    )
    state_transition_history: bool = Field(
        default=False,
        description="Maintains state transition history"
    )


class AgentAuthentication(BaseModel):
    """Authentication requirements for an agent.
    
    Attributes:
        schemes: Supported authentication schemes
        credentials: Optional credential requirements
    """
    
    schemes: list[str] = Field(
        default_factory=lambda: ["none"],
        description="Authentication schemes (e.g., 'bearer', 'api_key', 'none')"
    )
    credentials: str | None = Field(
        default=None,
        description="Credential requirements description"
    )


class AgentProvider(BaseModel):
    """Information about the agent provider/organization.
    
    Attributes:
        organization: Organization name
        url: Organization URL
    """
    
    organization: str = Field(
        ...,
        description="Provider organization name"
    )
    url: str | None = Field(
        default=None,
        description="Provider URL"
    )


class AgentCard(BaseModel):
    """A2A Protocol Agent Card.
    
    An Agent Card is a JSON document that describes an agent's
    identity, capabilities, and communication requirements.
    
    Example:
        ```python
        card = AgentCard(
            name="research-agent",
            description="An agent that researches topics",
            url="https://example.com/agents/research",
            version="1.0.0",
            capabilities=AgentCapabilities(streaming=True),
            skills=[
                AgentSkill(
                    id="web-search",
                    name="Web Search",
                    description="Search the web for information",
                )
            ],
        )
        
        # Export to JSON
        card.to_json("agent_card.json")
        
        # Import from JSON
        card = AgentCard.from_json("agent_card.json")
        ```
    
    Attributes:
        name: Unique agent identifier
        description: Human-readable description
        url: Agent endpoint URL
        version: Agent version (semver format)
        documentation_url: URL to agent documentation
        capabilities: Agent capabilities
        authentication: Authentication requirements
        default_input_modes: Default input content types
        default_output_modes: Default output content types
        skills: List of agent skills
        provider: Provider information
        metadata: Additional metadata
        created_at: Card creation timestamp
        updated_at: Last update timestamp
    """
    
    name: str = Field(
        ...,
        min_length=1,
        max_length=100,
        description="Unique agent identifier"
    )
    description: str = Field(
        ...,
        max_length=1000,
        description="Human-readable agent description"
    )
    url: str = Field(
        ...,
        description="Agent endpoint URL"
    )
    version: str = Field(
        default="1.0.0",
        description="Agent version (semver)"
    )
    documentation_url: str | None = Field(
        default=None,
        description="Documentation URL"
    )
    capabilities: AgentCapabilities = Field(
        default_factory=AgentCapabilities,
        description="Agent capabilities"
    )
    authentication: AgentAuthentication = Field(
        default_factory=AgentAuthentication,
        description="Authentication requirements"
    )
    default_input_modes: list[str] = Field(
        default_factory=lambda: ["text/plain"],
        description="Default input content types"
    )
    default_output_modes: list[str] = Field(
        default_factory=lambda: ["text/plain"],
        description="Default output content types"
    )
    skills: list[AgentSkill] = Field(
        default_factory=list,
        description="Agent skills"
    )
    provider: AgentProvider | None = Field(
        default=None,
        description="Provider information"
    )
    metadata: dict[str, Any] = Field(
        default_factory=dict,
        description="Additional metadata"
    )
    created_at: datetime = Field(
        default_factory=datetime.now,
        description="Card creation timestamp"
    )
    updated_at: datetime = Field(
        default_factory=datetime.now,
        description="Last update timestamp"
    )
    
    def add_skill(self, skill: AgentSkill) -> None:
        """Add a skill to the agent card.
        
        Args:
            skill: Skill to add
        """
        self.skills.append(skill)
        self.updated_at = datetime.now()
    
    def remove_skill(self, skill_id: str) -> bool:
        """Remove a skill by ID.
        
        Args:
            skill_id: ID of skill to remove
            
        Returns:
            True if skill was removed, False if not found
        """
        for i, skill in enumerate(self.skills):
            if skill.id == skill_id:
                self.skills.pop(i)
                self.updated_at = datetime.now()
                return True
        return False
    
    def get_skill(self, skill_id: str) -> AgentSkill | None:
        """Get a skill by ID.
        
        Args:
            skill_id: ID of skill to find
            
        Returns:
            Skill if found, None otherwise
        """
        for skill in self.skills:
            if skill.id == skill_id:
                return skill
        return None
    
    def has_skill(self, skill_id: str) -> bool:
        """Check if agent has a specific skill.
        
        Args:
            skill_id: ID of skill to check
            
        Returns:
            True if skill exists
        """
        return self.get_skill(skill_id) is not None
    
    def to_dict(self) -> dict[str, Any]:
        """Convert agent card to dictionary.
        
        Returns:
            Dictionary representation
        """
        return self.model_dump(mode="json")
    
    def to_json(self, path: str | Path | None = None, indent: int = 2) -> str:
        """Export agent card to JSON.
        
        Args:
            path: Optional file path to write to
            indent: JSON indentation level
            
        Returns:
            JSON string representation
        """
        json_str = self.model_dump_json(indent=indent)
        
        if path:
            Path(path).write_text(json_str)
        
        return json_str
    
    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "AgentCard":
        """Create agent card from dictionary.
        
        Args:
            data: Dictionary with card data
            
        Returns:
            AgentCard instance
        """
        return cls.model_validate(data)
    
    @classmethod
    def from_json(cls, source: str | Path) -> "AgentCard":
        """Load agent card from JSON file or string.
        
        Args:
            source: File path or JSON string
            
        Returns:
            AgentCard instance
        """
        if isinstance(source, Path) or (isinstance(source, str) and Path(source).exists()):
            content = Path(source).read_text()
        else:
            content = source
        
        data = json.loads(content)
        return cls.from_dict(data)
    
    def __str__(self) -> str:
        """String representation of the agent card."""
        skill_count = len(self.skills)
        return f"AgentCard(name={self.name!r}, skills={skill_count}, version={self.version})"


class AgentCardRegistry:
    """Registry for managing multiple agent cards.
    
    Provides methods to register, discover, and query agent cards.
    
    Example:
        ```python
        registry = AgentCardRegistry()
        
        # Register cards
        registry.register(research_agent_card)
        registry.register(writer_agent_card)
        
        # Find agents by skill
        agents = registry.find_by_skill("web-search")
        
        # Export all cards
        registry.export_all("agents/")
        ```
    """
    
    def __init__(self) -> None:
        """Initialize the registry."""
        self._cards: dict[str, AgentCard] = {}
    
    def register(self, card: AgentCard) -> None:
        """Register an agent card.
        
        Args:
            card: Agent card to register
        """
        self._cards[card.name] = card
    
    def unregister(self, name: str) -> bool:
        """Unregister an agent card.
        
        Args:
            name: Agent name to unregister
            
        Returns:
            True if agent was unregistered
        """
        if name in self._cards:
            del self._cards[name]
            return True
        return False
    
    def get(self, name: str) -> AgentCard | None:
        """Get an agent card by name.
        
        Args:
            name: Agent name
            
        Returns:
            Agent card if found
        """
        return self._cards.get(name)
    
    def list_all(self) -> list[AgentCard]:
        """List all registered agent cards.
        
        Returns:
            List of all agent cards
        """
        return list(self._cards.values())
    
    def find_by_skill(self, skill_id: str) -> list[AgentCard]:
        """Find agents that have a specific skill.
        
        Args:
            skill_id: Skill ID to search for
            
        Returns:
            List of agents with the skill
        """
        return [
            card for card in self._cards.values()
            if card.has_skill(skill_id)
        ]
    
    def find_by_tag(self, tag: str) -> list[AgentCard]:
        """Find agents with skills tagged with a specific tag.
        
        Args:
            tag: Tag to search for
            
        Returns:
            List of matching agents
        """
        result = []
        for card in self._cards.values():
            for skill in card.skills:
                if tag in skill.tags:
                    result.append(card)
                    break
        return result
    
    def find_by_capability(
        self,
        streaming: bool | None = None,
        push_notifications: bool | None = None,
    ) -> list[AgentCard]:
        """Find agents by capabilities.
        
        Args:
            streaming: Filter by streaming support
            push_notifications: Filter by push notification support
            
        Returns:
            List of matching agents
        """
        result = []
        for card in self._cards.values():
            if streaming is not None and card.capabilities.streaming != streaming:
                continue
            if push_notifications is not None and \
               card.capabilities.push_notifications != push_notifications:
                continue
            result.append(card)
        return result
    
    def export_all(self, directory: str | Path) -> None:
        """Export all agent cards to a directory.
        
        Args:
            directory: Directory to export to
        """
        dir_path = Path(directory)
        dir_path.mkdir(parents=True, exist_ok=True)
        
        for name, card in self._cards.items():
            card.to_json(dir_path / f"{name}.json")
    
    def import_from_directory(self, directory: str | Path) -> int:
        """Import agent cards from a directory.
        
        Args:
            directory: Directory containing JSON files
            
        Returns:
            Number of cards imported
        """
        dir_path = Path(directory)
        count = 0
        
        for json_file in dir_path.glob("*.json"):
            try:
                card = AgentCard.from_json(json_file)
                self.register(card)
                count += 1
            except Exception:
                pass  # Skip invalid files
        
        return count
    
    def __len__(self) -> int:
        """Return the number of registered agents."""
        return len(self._cards)
    
    def __iter__(self):
        """Iterate over registered agents."""
        return iter(self._cards.values())
