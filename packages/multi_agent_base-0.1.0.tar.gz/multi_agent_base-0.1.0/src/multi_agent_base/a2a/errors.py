"""
A2A Protocol v2 Standardized Error Handling.

This module provides standardized error types and error codes for
the A2A protocol, enabling consistent error handling across agents.

Reference: https://github.com/google/A2A
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any


class A2AErrorCode(Enum):
    """Standard A2A Protocol error codes.
    
    These codes follow a hierarchical structure:
    - 1xxx: Client errors
    - 2xxx: Agent errors
    - 3xxx: Communication errors
    - 4xxx: Protocol errors
    - 5xxx: Internal errors
    """
    
    # Client errors (1xxx)
    INVALID_REQUEST = "A2A_1001"
    MISSING_PARAMETER = "A2A_1002"
    INVALID_PARAMETER = "A2A_1003"
    INVALID_CONTENT_TYPE = "A2A_1004"
    CONTENT_TOO_LARGE = "A2A_1005"
    RATE_LIMITED = "A2A_1006"
    UNAUTHORIZED = "A2A_1007"
    FORBIDDEN = "A2A_1008"
    
    # Agent errors (2xxx)
    AGENT_NOT_FOUND = "A2A_2001"
    AGENT_UNAVAILABLE = "A2A_2002"
    SKILL_NOT_FOUND = "A2A_2003"
    SKILL_DISABLED = "A2A_2004"
    CAPABILITY_NOT_SUPPORTED = "A2A_2005"
    AGENT_BUSY = "A2A_2006"
    AGENT_TIMEOUT = "A2A_2007"
    AGENT_ERROR = "A2A_2008"
    
    # Communication errors (3xxx)
    CONNECTION_FAILED = "A2A_3001"
    CONNECTION_TIMEOUT = "A2A_3002"
    CONNECTION_CLOSED = "A2A_3003"
    MESSAGE_DELIVERY_FAILED = "A2A_3004"
    RESPONSE_TIMEOUT = "A2A_3005"
    NETWORK_ERROR = "A2A_3006"
    SSL_ERROR = "A2A_3007"
    DNS_ERROR = "A2A_3008"
    
    # Protocol errors (4xxx)
    PROTOCOL_VERSION_MISMATCH = "A2A_4001"
    INVALID_AGENT_CARD = "A2A_4002"
    INVALID_MESSAGE_FORMAT = "A2A_4003"
    THREAD_NOT_FOUND = "A2A_4004"
    THREAD_EXPIRED = "A2A_4005"
    AUTHENTICATION_SCHEME_UNSUPPORTED = "A2A_4006"
    HANDSHAKE_FAILED = "A2A_4007"
    
    # Internal errors (5xxx)
    INTERNAL_ERROR = "A2A_5001"
    CONFIGURATION_ERROR = "A2A_5002"
    DEPENDENCY_ERROR = "A2A_5003"
    RESOURCE_EXHAUSTED = "A2A_5004"
    NOT_IMPLEMENTED = "A2A_5005"


# Error code to HTTP status mapping
ERROR_HTTP_STATUS: dict[A2AErrorCode, int] = {
    # Client errors -> 4xx
    A2AErrorCode.INVALID_REQUEST: 400,
    A2AErrorCode.MISSING_PARAMETER: 400,
    A2AErrorCode.INVALID_PARAMETER: 400,
    A2AErrorCode.INVALID_CONTENT_TYPE: 415,
    A2AErrorCode.CONTENT_TOO_LARGE: 413,
    A2AErrorCode.RATE_LIMITED: 429,
    A2AErrorCode.UNAUTHORIZED: 401,
    A2AErrorCode.FORBIDDEN: 403,
    
    # Agent errors -> 4xx/5xx
    A2AErrorCode.AGENT_NOT_FOUND: 404,
    A2AErrorCode.AGENT_UNAVAILABLE: 503,
    A2AErrorCode.SKILL_NOT_FOUND: 404,
    A2AErrorCode.SKILL_DISABLED: 403,
    A2AErrorCode.CAPABILITY_NOT_SUPPORTED: 501,
    A2AErrorCode.AGENT_BUSY: 503,
    A2AErrorCode.AGENT_TIMEOUT: 504,
    A2AErrorCode.AGENT_ERROR: 500,
    
    # Communication errors -> 5xx
    A2AErrorCode.CONNECTION_FAILED: 502,
    A2AErrorCode.CONNECTION_TIMEOUT: 504,
    A2AErrorCode.CONNECTION_CLOSED: 502,
    A2AErrorCode.MESSAGE_DELIVERY_FAILED: 502,
    A2AErrorCode.RESPONSE_TIMEOUT: 504,
    A2AErrorCode.NETWORK_ERROR: 502,
    A2AErrorCode.SSL_ERROR: 495,
    A2AErrorCode.DNS_ERROR: 502,
    
    # Protocol errors -> 4xx
    A2AErrorCode.PROTOCOL_VERSION_MISMATCH: 400,
    A2AErrorCode.INVALID_AGENT_CARD: 400,
    A2AErrorCode.INVALID_MESSAGE_FORMAT: 400,
    A2AErrorCode.THREAD_NOT_FOUND: 404,
    A2AErrorCode.THREAD_EXPIRED: 410,
    A2AErrorCode.AUTHENTICATION_SCHEME_UNSUPPORTED: 401,
    A2AErrorCode.HANDSHAKE_FAILED: 400,
    
    # Internal errors -> 5xx
    A2AErrorCode.INTERNAL_ERROR: 500,
    A2AErrorCode.CONFIGURATION_ERROR: 500,
    A2AErrorCode.DEPENDENCY_ERROR: 500,
    A2AErrorCode.RESOURCE_EXHAUSTED: 503,
    A2AErrorCode.NOT_IMPLEMENTED: 501,
}


@dataclass
class A2AErrorDetails:
    """Additional details for an A2A error.
    
    Attributes:
        field: The field or parameter that caused the error
        expected: Expected value or format
        actual: Actual value received
        suggestion: Suggestion for fixing the error
        docs_url: URL to relevant documentation
    """
    
    field: str | None = None
    expected: str | None = None
    actual: str | None = None
    suggestion: str | None = None
    docs_url: str | None = None
    
    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        result = {}
        if self.field:
            result["field"] = self.field
        if self.expected:
            result["expected"] = self.expected
        if self.actual:
            result["actual"] = self.actual
        if self.suggestion:
            result["suggestion"] = self.suggestion
        if self.docs_url:
            result["docs_url"] = self.docs_url
        return result


class A2AError(Exception):
    """Base exception for A2A Protocol errors.
    
    All A2A-related exceptions inherit from this class, providing
    standardized error handling with codes, messages, and details.
    
    Example:
        ```python
        try:
            result = await agent.invoke(message)
        except A2AError as e:
            print(f"Error: {e.code.value} - {e.message}")
            print(f"HTTP Status: {e.http_status}")
            if e.details:
                print(f"Details: {e.details.suggestion}")
        ```
    
    Attributes:
        code: A2A error code
        message: Human-readable error message
        details: Additional error details
        timestamp: When the error occurred
        request_id: ID of the request that caused the error
        agent_name: Name of the agent that raised the error
    """
    
    def __init__(
        self,
        message: str,
        code: A2AErrorCode = A2AErrorCode.INTERNAL_ERROR,
        details: A2AErrorDetails | None = None,
        request_id: str | None = None,
        agent_name: str | None = None,
    ) -> None:
        """Initialize A2A error.
        
        Args:
            message: Error message
            code: Error code
            details: Optional details
            request_id: Optional request ID
            agent_name: Optional agent name
        """
        super().__init__(message)
        self.code = code
        self.message = message
        self.details = details
        self.timestamp = datetime.now()
        self.request_id = request_id
        self.agent_name = agent_name
    
    @property
    def http_status(self) -> int:
        """Get the HTTP status code for this error."""
        return ERROR_HTTP_STATUS.get(self.code, 500)
    
    def to_dict(self) -> dict[str, Any]:
        """Convert error to dictionary for JSON response."""
        result = {
            "error": {
                "code": self.code.value,
                "message": self.message,
                "timestamp": self.timestamp.isoformat(),
            }
        }
        
        if self.details:
            result["error"]["details"] = self.details.to_dict()
        
        if self.request_id:
            result["error"]["request_id"] = self.request_id
        
        if self.agent_name:
            result["error"]["agent"] = self.agent_name
        
        return result
    
    def to_response(self) -> dict[str, Any]:
        """Convert to HTTP response format."""
        return {
            "status": self.http_status,
            "body": self.to_dict(),
            "headers": {"Content-Type": "application/json"},
        }


# =============================================================================
# Specific Error Types
# =============================================================================

class A2ADiscoveryError(A2AError):
    """Error during agent discovery."""
    
    def __init__(
        self,
        message: str,
        url: str | None = None,
        code: str | None = None,
        **kwargs: Any,
    ) -> None:
        details = A2AErrorDetails(
            field="url",
            actual=url,
            suggestion="Verify the agent URL is correct and accessible",
        )
        # Handle string code for backwards compatibility
        error_code = A2AErrorCode.AGENT_NOT_FOUND
        if code:
            try:
                error_code = A2AErrorCode(code)
            except ValueError:
                pass
        super().__init__(message, code=error_code, details=details, **kwargs)
        self.url = url


class A2AConnectionError(A2AError):
    """Error establishing connection to an agent."""
    
    def __init__(
        self,
        message: str,
        host: str | None = None,
        port: int | None = None,
        **kwargs: Any,
    ) -> None:
        details = A2AErrorDetails(
            field="connection",
            actual=f"{host}:{port}" if host and port else host,
            suggestion="Check network connectivity and agent availability",
        )
        super().__init__(
            message,
            code=A2AErrorCode.CONNECTION_FAILED,
            details=details,
            **kwargs,
        )


class A2ATimeoutError(A2AError):
    """Timeout error during agent communication."""
    
    def __init__(
        self,
        message: str,
        timeout_seconds: float | None = None,
        operation: str | None = None,
        **kwargs: Any,
    ) -> None:
        details = A2AErrorDetails(
            field="timeout",
            expected=f"{timeout_seconds}s" if timeout_seconds else None,
            suggestion="Try increasing the timeout or check agent responsiveness",
        )
        super().__init__(
            message,
            code=A2AErrorCode.RESPONSE_TIMEOUT,
            details=details,
            **kwargs,
        )


class A2AAuthenticationError(A2AError):
    """Authentication error with an agent."""
    
    def __init__(
        self,
        message: str,
        scheme: str | None = None,
        **kwargs: Any,
    ) -> None:
        details = A2AErrorDetails(
            field="authentication",
            actual=scheme,
            suggestion="Verify your authentication credentials",
        )
        super().__init__(
            message,
            code=A2AErrorCode.UNAUTHORIZED,
            details=details,
            **kwargs,
        )


class A2AProtocolError(A2AError):
    """Protocol-level error."""
    
    def __init__(
        self,
        message: str,
        expected_version: str | None = None,
        actual_version: str | None = None,
        **kwargs: Any,
    ) -> None:
        details = A2AErrorDetails(
            field="protocol_version",
            expected=expected_version,
            actual=actual_version,
            docs_url="https://github.com/google/A2A",
        )
        super().__init__(
            message,
            code=A2AErrorCode.PROTOCOL_VERSION_MISMATCH,
            details=details,
            **kwargs,
        )


class A2AAgentError(A2AError):
    """Error from an agent during processing."""
    
    def __init__(
        self,
        message: str,
        agent_name: str | None = None,
        skill_id: str | None = None,
        **kwargs: Any,
    ) -> None:
        details = A2AErrorDetails(
            field="skill" if skill_id else "agent",
            actual=skill_id or agent_name,
        )
        super().__init__(
            message,
            code=A2AErrorCode.AGENT_ERROR,
            details=details,
            agent_name=agent_name,
            **kwargs,
        )


class A2AThreadError(A2AError):
    """Error related to conversation threads."""
    
    def __init__(
        self,
        message: str,
        thread_id: str | None = None,
        expired: bool = False,
        **kwargs: Any,
    ) -> None:
        details = A2AErrorDetails(
            field="thread_id",
            actual=thread_id,
            suggestion="Create a new thread or verify the thread ID",
        )
        code = A2AErrorCode.THREAD_EXPIRED if expired else A2AErrorCode.THREAD_NOT_FOUND
        super().__init__(message, code=code, details=details, **kwargs)


class A2AValidationError(A2AError):
    """Validation error for request parameters."""
    
    def __init__(
        self,
        message: str,
        field: str | None = None,
        expected: str | None = None,
        actual: Any = None,
        **kwargs: Any,
    ) -> None:
        details = A2AErrorDetails(
            field=field,
            expected=expected,
            actual=str(actual) if actual is not None else None,
        )
        super().__init__(
            message,
            code=A2AErrorCode.INVALID_PARAMETER,
            details=details,
            **kwargs,
        )


class A2ARateLimitError(A2AError):
    """Rate limit exceeded error."""
    
    def __init__(
        self,
        message: str,
        retry_after: int | None = None,
        limit: int | None = None,
        remaining: int | None = None,
        **kwargs: Any,
    ) -> None:
        suggestion = f"Retry after {retry_after} seconds" if retry_after else "Reduce request rate"
        details = A2AErrorDetails(
            field="rate_limit",
            expected=f"{limit} requests" if limit else None,
            actual=f"{remaining} remaining" if remaining is not None else None,
            suggestion=suggestion,
        )
        super().__init__(
            message,
            code=A2AErrorCode.RATE_LIMITED,
            details=details,
            **kwargs,
        )
        self.retry_after = retry_after


# =============================================================================
# Error Handler
# =============================================================================

class A2AErrorHandler:
    """Centralized error handler for A2A errors.
    
    Provides error logging, transformation, and response formatting.
    
    Example:
        ```python
        handler = A2AErrorHandler()
        
        try:
            result = await agent.invoke(message)
        except Exception as e:
            error = handler.handle(e)
            return error.to_response()
        ```
    """
    
    def __init__(
        self,
        default_agent_name: str | None = None,
        include_traceback: bool = False,
    ) -> None:
        """Initialize error handler.
        
        Args:
            default_agent_name: Default agent name for errors
            include_traceback: Whether to include tracebacks in responses
        """
        self.default_agent_name = default_agent_name
        self.include_traceback = include_traceback
        self._error_handlers: dict[type, Callable] = {}
    
    def register_handler(
        self,
        exception_type: type,
        handler: Callable[[Exception], A2AError],
    ) -> None:
        """Register a custom error handler.
        
        Args:
            exception_type: Type of exception to handle
            handler: Handler function
        """
        self._error_handlers[exception_type] = handler
    
    def handle(self, exception: Exception, **context: Any) -> A2AError:
        """Handle an exception and return an A2AError.
        
        Args:
            exception: The exception to handle
            **context: Additional context
            
        Returns:
            A2AError instance
        """
        # Check for registered handlers
        for exc_type, handler in self._error_handlers.items():
            if isinstance(exception, exc_type):
                return handler(exception)
        
        # Already an A2AError
        if isinstance(exception, A2AError):
            return exception
        
        # Convert common exceptions
        if isinstance(exception, TimeoutError):
            return A2ATimeoutError(
                str(exception) or "Operation timed out",
                agent_name=self.default_agent_name,
            )
        
        if isinstance(exception, ConnectionError):
            return A2AConnectionError(
                str(exception) or "Connection failed",
                agent_name=self.default_agent_name,
            )
        
        if isinstance(exception, ValueError):
            return A2AValidationError(
                str(exception) or "Invalid value",
                agent_name=self.default_agent_name,
            )
        
        if isinstance(exception, NotImplementedError):
            return A2AError(
                str(exception) or "Not implemented",
                code=A2AErrorCode.NOT_IMPLEMENTED,
                agent_name=self.default_agent_name,
            )
        
        # Generic error
        return A2AError(
            str(exception) or "An internal error occurred",
            code=A2AErrorCode.INTERNAL_ERROR,
            agent_name=self.default_agent_name,
        )
    
    def create_error_response(
        self,
        exception: Exception,
        request_id: str | None = None,
    ) -> dict[str, Any]:
        """Create an error response for an exception.
        
        Args:
            exception: The exception
            request_id: Optional request ID
            
        Returns:
            HTTP response dictionary
        """
        error = self.handle(exception)
        if request_id:
            error.request_id = request_id
        return error.to_response()


# Type alias for callable handlers
Callable = type(lambda: None)
