"""
A2A Protocol v2 HTTP Server and Client.

This module provides HTTP-based Agent Card serving and discovery,
enabling agents to expose and discover each other via standard
`.well-known/agent-card.json` endpoints.

Reference: https://github.com/google/A2A
"""

from __future__ import annotations

import asyncio
import json
from dataclasses import dataclass, field
from typing import Any, Callable
from urllib.parse import urljoin, urlparse

from multi_agent_base.a2a.agent_card import AgentCard


@dataclass
class A2AServerConfig:
    """Configuration for A2A HTTP server.
    
    Attributes:
        host: Server host address
        port: Server port
        base_path: Base URL path for endpoints
        cors_origins: Allowed CORS origins
        enable_discovery: Enable auto-discovery endpoint
        agent_card: The agent card to serve
    """
    
    host: str = "0.0.0.0"
    port: int = 8080
    base_path: str = ""
    cors_origins: list[str] = field(default_factory=lambda: ["*"])
    enable_discovery: bool = True
    agent_card: AgentCard | None = None


class A2AServer:
    """HTTP Server for A2A Protocol Agent Cards.
    
    Serves an agent's card at the standard `.well-known/agent-card.json`
    endpoint and provides additional A2A protocol endpoints.
    
    Example:
        ```python
        from multi_agent_base.a2a import AgentCard
        from multi_agent_base.a2a.http import A2AServer, A2AServerConfig
        
        # Create agent card
        card = AgentCard(
            name="my-agent",
            description="My awesome agent",
            url="http://localhost:8080",
        )
        
        # Create and start server
        config = A2AServerConfig(port=8080, agent_card=card)
        server = A2AServer(config)
        await server.start()
        
        # Agent card available at: http://localhost:8080/.well-known/agent-card.json
        ```
    """
    
    def __init__(self, config: A2AServerConfig) -> None:
        """Initialize the A2A server.
        
        Args:
            config: Server configuration
        """
        self.config = config
        self._agent_card = config.agent_card
        self._routes: dict[str, Callable] = {}
        self._running = False
        self._server: Any = None
        
        # Register default routes
        self._register_default_routes()
    
    def _register_default_routes(self) -> None:
        """Register default A2A protocol routes."""
        # Standard agent card endpoint
        self._routes["/.well-known/agent-card.json"] = self._handle_agent_card
        
        # Health check
        self._routes["/health"] = self._handle_health
        
        # Discovery endpoint
        if self.config.enable_discovery:
            self._routes["/a2a/discover"] = self._handle_discover
    
    def set_agent_card(self, card: AgentCard) -> None:
        """Set or update the agent card.
        
        Args:
            card: The agent card to serve
        """
        self._agent_card = card
    
    def get_agent_card(self) -> AgentCard | None:
        """Get the current agent card."""
        return self._agent_card
    
    async def _handle_agent_card(self, request: dict[str, Any]) -> dict[str, Any]:
        """Handle agent card requests."""
        if not self._agent_card:
            return {
                "status": 404,
                "body": {"error": "Agent card not configured"},
            }
        
        return {
            "status": 200,
            "body": self._agent_card.model_dump(),
            "headers": {"Content-Type": "application/json"},
        }
    
    async def _handle_health(self, request: dict[str, Any]) -> dict[str, Any]:
        """Handle health check requests."""
        return {
            "status": 200,
            "body": {
                "status": "healthy",
                "agent": self._agent_card.name if self._agent_card else None,
            },
        }
    
    async def _handle_discover(self, request: dict[str, Any]) -> dict[str, Any]:
        """Handle discovery requests."""
        if not self._agent_card:
            return {
                "status": 404,
                "body": {"error": "Agent card not configured"},
            }
        
        return {
            "status": 200,
            "body": {
                "agent_card_url": f"http://{self.config.host}:{self.config.port}/.well-known/agent-card.json",
                "skills": [s.model_dump() for s in self._agent_card.skills],
                "capabilities": self._agent_card.capabilities.model_dump(),
            },
        }
    
    def register_route(
        self,
        path: str,
        handler: Callable[[dict[str, Any]], dict[str, Any]],
    ) -> None:
        """Register a custom route.
        
        Args:
            path: URL path
            handler: Async handler function
        """
        self._routes[path] = handler
    
    async def handle_request(
        self,
        method: str,
        path: str,
        body: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """Handle an incoming HTTP request.
        
        This is a simple request router for testing or embedding
        in other HTTP frameworks.
        
        Args:
            method: HTTP method
            path: Request path
            body: Request body
            headers: Request headers
            
        Returns:
            Response dictionary with status, body, and headers
        """
        request = {
            "method": method,
            "path": path,
            "body": body or {},
            "headers": headers or {},
        }
        
        handler = self._routes.get(path)
        if not handler:
            return {
                "status": 404,
                "body": {"error": "Not found"},
            }
        
        return await handler(request)
    
    def get_routes(self) -> list[str]:
        """Get all registered routes."""
        return list(self._routes.keys())
    
    @property
    def is_running(self) -> bool:
        """Check if server is running."""
        return self._running
    
    async def start(self) -> None:
        """Start the HTTP server.
        
        Note: This is a placeholder. In a real implementation,
        you would use aiohttp, FastAPI, or another framework.
        """
        self._running = True
    
    async def stop(self) -> None:
        """Stop the HTTP server."""
        self._running = False
        if self._server:
            self._server.close()
            self._server = None


class A2AClient:
    """HTTP Client for A2A Protocol Agent Discovery.
    
    Discovers and fetches agent cards from remote agents using
    the standard `.well-known/agent-card.json` endpoint.
    
    Example:
        ```python
        from multi_agent_base.a2a.http import A2AClient
        
        client = A2AClient()
        
        # Discover agent at URL
        card = await client.discover("http://example.com")
        print(f"Found agent: {card.name}")
        
        # Fetch specific skill
        skill = client.get_skill(card, "web-search")
        ```
    """
    
    def __init__(
        self,
        timeout: float = 30.0,
        retry_count: int = 3,
        verify_ssl: bool = True,
    ) -> None:
        """Initialize the A2A client.
        
        Args:
            timeout: Request timeout in seconds
            retry_count: Number of retries for failed requests
            verify_ssl: Whether to verify SSL certificates
        """
        self.timeout = timeout
        self.retry_count = retry_count
        self.verify_ssl = verify_ssl
        self._cache: dict[str, AgentCard] = {}
    
    def _build_agent_card_url(self, base_url: str) -> str:
        """Build the agent card URL from a base URL.
        
        Args:
            base_url: Base URL of the agent
            
        Returns:
            Full URL to the agent card
        """
        # Ensure base URL ends with /
        if not base_url.endswith("/"):
            base_url += "/"
        
        return urljoin(base_url, ".well-known/agent-card.json")
    
    async def discover(
        self,
        url: str,
        use_cache: bool = True,
    ) -> AgentCard:
        """Discover an agent at the given URL.
        
        Fetches the agent card from the standard endpoint.
        
        Args:
            url: Base URL of the agent
            use_cache: Whether to use cached results
            
        Returns:
            The agent's card
            
        Raises:
            A2ADiscoveryError: If discovery fails
        """
        from multi_agent_base.a2a.errors import A2ADiscoveryError
        
        # Check cache
        if use_cache and url in self._cache:
            return self._cache[url]
        
        card_url = self._build_agent_card_url(url)
        
        # Note: This is a mock implementation
        # In real use, you would use aiohttp or httpx
        try:
            # Simulate HTTP request
            # In production: async with aiohttp.ClientSession() as session:
            #                    async with session.get(card_url) as response:
            raise NotImplementedError(
                f"HTTP client not implemented. Would fetch: {card_url}"
            )
        except NotImplementedError:
            raise A2ADiscoveryError(
                f"Discovery requires HTTP client implementation",
                url=url,
                code="HTTP_CLIENT_NOT_IMPLEMENTED",
            )
    
    async def discover_from_card_data(self, data: dict[str, Any]) -> AgentCard:
        """Create an AgentCard from JSON data.
        
        Args:
            data: Agent card JSON data
            
        Returns:
            Parsed AgentCard
        """
        return AgentCard.model_validate(data)
    
    def get_skill(
        self,
        card: AgentCard,
        skill_id: str,
    ) -> Any | None:
        """Get a specific skill from an agent card.
        
        Args:
            card: Agent card to search
            skill_id: ID of the skill to find
            
        Returns:
            The skill if found, None otherwise
        """
        for skill in card.skills:
            if skill.id == skill_id:
                return skill
        return None
    
    def get_skills_by_tag(
        self,
        card: AgentCard,
        tag: str,
    ) -> list[Any]:
        """Get skills matching a tag.
        
        Args:
            card: Agent card to search
            tag: Tag to match
            
        Returns:
            List of matching skills
        """
        return [s for s in card.skills if tag in s.tags]
    
    def clear_cache(self) -> None:
        """Clear the agent card cache."""
        self._cache.clear()
    
    def cache_card(self, url: str, card: AgentCard) -> None:
        """Manually cache an agent card.
        
        Args:
            url: URL key for the cache
            card: Agent card to cache
        """
        self._cache[url] = card


@dataclass
class A2ARegistry:
    """Registry for discovered A2A agents.
    
    Maintains a registry of discovered agents and their capabilities
    for quick lookup and routing.
    
    Attributes:
        agents: Registered agent cards indexed by name
        endpoints: Agent endpoints indexed by URL
    """
    
    agents: dict[str, AgentCard] = field(default_factory=dict)
    endpoints: dict[str, str] = field(default_factory=dict)
    
    def register(self, card: AgentCard) -> None:
        """Register an agent card.
        
        Args:
            card: Agent card to register
        """
        self.agents[card.name] = card
        self.endpoints[card.url] = card.name
    
    def unregister(self, name: str) -> None:
        """Unregister an agent by name.
        
        Args:
            name: Agent name to unregister
        """
        if name in self.agents:
            card = self.agents[name]
            del self.agents[name]
            if card.url in self.endpoints:
                del self.endpoints[card.url]
    
    def get_by_name(self, name: str) -> AgentCard | None:
        """Get an agent by name.
        
        Args:
            name: Agent name
            
        Returns:
            Agent card if found
        """
        return self.agents.get(name)
    
    def get_by_url(self, url: str) -> AgentCard | None:
        """Get an agent by URL.
        
        Args:
            url: Agent URL
            
        Returns:
            Agent card if found
        """
        name = self.endpoints.get(url)
        if name:
            return self.agents.get(name)
        return None
    
    def find_by_skill(self, skill_id: str) -> list[AgentCard]:
        """Find agents with a specific skill.
        
        Args:
            skill_id: Skill ID to search for
            
        Returns:
            List of agents with the skill
        """
        result = []
        for card in self.agents.values():
            for skill in card.skills:
                if skill.id == skill_id:
                    result.append(card)
                    break
        return result
    
    def find_by_tag(self, tag: str) -> list[AgentCard]:
        """Find agents with skills matching a tag.
        
        Args:
            tag: Tag to search for
            
        Returns:
            List of agents with matching skills
        """
        result = []
        for card in self.agents.values():
            for skill in card.skills:
                if tag in skill.tags:
                    result.append(card)
                    break
        return result
    
    def list_all(self) -> list[AgentCard]:
        """List all registered agents."""
        return list(self.agents.values())
    
    def clear(self) -> None:
        """Clear all registered agents."""
        self.agents.clear()
        self.endpoints.clear()
