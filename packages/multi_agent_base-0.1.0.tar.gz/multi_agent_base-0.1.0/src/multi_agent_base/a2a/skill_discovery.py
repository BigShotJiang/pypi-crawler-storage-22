"""
Skill auto-discovery for A2A Agent Cards.

This module provides utilities to automatically discover and
extract skill definitions from Python functions, enabling
automatic Agent Card generation.
"""

from __future__ import annotations

import ast
import inspect
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, get_type_hints

from multi_agent_base.a2a.agent_card import AgentSkill


@dataclass
class ParameterInfo:
    """Information about a function parameter.
    
    Attributes:
        name: Parameter name
        type_hint: Type hint string
        description: Parameter description from docstring
        required: Whether the parameter is required
        default: Default value if any
    """
    
    name: str
    type_hint: str = "any"
    description: str = ""
    required: bool = True
    default: Any = None


@dataclass
class FunctionInfo:
    """Extracted information from a function.
    
    Attributes:
        name: Function name
        description: Function description from docstring
        parameters: List of parameter info
        return_type: Return type hint
        return_description: Return description from docstring
        examples: Example usages from docstring
        tags: Inferred tags
    """
    
    name: str
    description: str = ""
    parameters: list[ParameterInfo] = None
    return_type: str = "any"
    return_description: str = ""
    examples: list[str] = None
    tags: list[str] = None
    
    def __post_init__(self):
        if self.parameters is None:
            self.parameters = []
        if self.examples is None:
            self.examples = []
        if self.tags is None:
            self.tags = []


class DocstringParser:
    """Parser for extracting information from docstrings.
    
    Supports Google, NumPy, and reStructuredText docstring styles.
    """
    
    # Common section headers
    PARAM_HEADERS = ["Args", "Arguments", "Parameters", "Params"]
    RETURN_HEADERS = ["Returns", "Return", "Yields"]
    EXAMPLE_HEADERS = ["Example", "Examples", "Usage"]
    
    @classmethod
    def parse(cls, docstring: str | None) -> dict[str, Any]:
        """Parse a docstring and extract sections.
        
        Args:
            docstring: The docstring to parse
            
        Returns:
            Dictionary with extracted sections
        """
        if not docstring:
            return {
                "description": "",
                "parameters": {},
                "returns": "",
                "examples": [],
            }
        
        lines = docstring.strip().split("\n")
        
        # First paragraph is the description
        description_lines = []
        current_line = 0
        
        for i, line in enumerate(lines):
            stripped = line.strip()
            if not stripped:
                current_line = i + 1
                break
            # Check if it's a section header
            if any(stripped.startswith(h + ":") or stripped == h + ":" 
                   for h in cls.PARAM_HEADERS + cls.RETURN_HEADERS + cls.EXAMPLE_HEADERS):
                current_line = i
                break
            description_lines.append(stripped)
            current_line = i + 1
        
        description = " ".join(description_lines)
        
        # Parse remaining sections
        parameters: dict[str, str] = {}
        returns = ""
        examples: list[str] = []
        
        current_section = None
        section_content: list[str] = []
        
        for i in range(current_line, len(lines)):
            line = lines[i]
            stripped = line.strip()
            
            # Check for section headers
            header_match = None
            for h in cls.PARAM_HEADERS:
                if stripped.startswith(h + ":") or stripped == h + ":":
                    header_match = "parameters"
                    break
            for h in cls.RETURN_HEADERS:
                if stripped.startswith(h + ":") or stripped == h + ":":
                    header_match = "returns"
                    break
            for h in cls.EXAMPLE_HEADERS:
                if stripped.startswith(h + ":") or stripped == h + ":":
                    header_match = "examples"
                    break
            
            if header_match:
                # Process previous section
                if current_section == "parameters":
                    parameters = cls._parse_parameters(section_content)
                elif current_section == "returns":
                    returns = " ".join(section_content)
                elif current_section == "examples":
                    examples = cls._parse_examples(section_content)
                
                current_section = header_match
                section_content = []
                continue
            
            if current_section and stripped:
                section_content.append(stripped)
        
        # Process last section
        if current_section == "parameters":
            parameters = cls._parse_parameters(section_content)
        elif current_section == "returns":
            returns = " ".join(section_content)
        elif current_section == "examples":
            examples = cls._parse_examples(section_content)
        
        return {
            "description": description,
            "parameters": parameters,
            "returns": returns,
            "examples": examples,
        }
    
    @classmethod
    def _parse_parameters(cls, lines: list[str]) -> dict[str, str]:
        """Parse parameter descriptions from lines.
        
        Args:
            lines: Lines containing parameter descriptions
            
        Returns:
            Dictionary of param name to description
        """
        params = {}
        current_param = None
        current_desc: list[str] = []
        
        for line in lines:
            # Check for new parameter (name: description or name (type): description)
            match = re.match(r'^(\w+)(?:\s*\([^)]*\))?\s*:\s*(.*)$', line)
            if match:
                # Save previous parameter
                if current_param:
                    params[current_param] = " ".join(current_desc)
                
                current_param = match.group(1)
                current_desc = [match.group(2)] if match.group(2) else []
            elif current_param and line.startswith(" "):
                current_desc.append(line.strip())
        
        # Save last parameter
        if current_param:
            params[current_param] = " ".join(current_desc)
        
        return params
    
    @classmethod
    def _parse_examples(cls, lines: list[str]) -> list[str]:
        """Parse examples from docstring lines.
        
        Args:
            lines: Lines containing examples
            
        Returns:
            List of example strings
        """
        examples = []
        current_example: list[str] = []
        in_code_block = False
        
        for line in lines:
            if line.startswith("```") or line.startswith(">>>"):
                if in_code_block:
                    examples.append("\n".join(current_example))
                    current_example = []
                in_code_block = not in_code_block
            elif in_code_block:
                current_example.append(line)
        
        if current_example:
            examples.append("\n".join(current_example))
        
        return examples


class SkillDiscoverer:
    """Discovers and extracts skills from Python functions.
    
    This class analyzes Python functions and generates AgentSkill
    definitions based on function signatures and docstrings.
    
    Example:
        ```python
        def search_web(query: str, max_results: int = 10) -> list[str]:
            '''Search the web for information.
            
            Args:
                query: Search query string
                max_results: Maximum number of results to return
                
            Returns:
                List of search result URLs
            '''
            pass
        
        discoverer = SkillDiscoverer()
        skill = discoverer.discover_from_function(search_web)
        print(skill.name)  # "search_web"
        print(skill.description)  # "Search the web for information."
        ```
    """
    
    # Common skill tags based on function names
    TAG_PATTERNS: dict[str, list[str]] = {
        r"search|find|query|lookup": ["search", "information-retrieval"],
        r"write|create|generate|compose": ["content-creation", "generation"],
        r"analyze|evaluate|assess": ["analysis", "evaluation"],
        r"calculate|compute|math": ["calculation", "mathematics"],
        r"fetch|get|retrieve|download": ["data-retrieval", "api"],
        r"send|post|push|publish": ["communication", "api"],
        r"parse|extract|scrape": ["parsing", "data-extraction"],
        r"validate|check|verify": ["validation"],
        r"convert|transform|format": ["transformation"],
        r"summarize|summary": ["summarization", "nlp"],
        r"translate": ["translation", "nlp"],
    }
    
    def __init__(self) -> None:
        """Initialize the skill discoverer."""
        self._parser = DocstringParser()
    
    def discover_from_function(
        self,
        func: Callable[..., Any],
        skill_id: str | None = None,
    ) -> AgentSkill:
        """Discover a skill from a Python function.
        
        Args:
            func: The function to analyze
            skill_id: Optional custom skill ID
            
        Returns:
            AgentSkill extracted from the function
        """
        info = self._extract_function_info(func)
        
        return AgentSkill(
            id=skill_id or self._generate_skill_id(info.name),
            name=self._format_name(info.name),
            description=info.description or f"Execute {info.name} operation",
            tags=info.tags,
            examples=info.examples,
            input_modes=["text/plain", "application/json"],
            output_modes=self._infer_output_modes(info.return_type),
        )
    
    def discover_from_tools(
        self,
        tools: list[Callable[..., Any]],
    ) -> list[AgentSkill]:
        """Discover skills from a list of tool functions.
        
        Args:
            tools: List of tool functions
            
        Returns:
            List of AgentSkill definitions
        """
        return [
            self.discover_from_function(tool)
            for tool in tools
        ]
    
    def discover_from_module(
        self,
        module_path: str | Path,
    ) -> list[AgentSkill]:
        """Discover skills from a Python module file.
        
        Args:
            module_path: Path to the Python module
            
        Returns:
            List of discovered skills
        """
        path = Path(module_path)
        content = path.read_text()
        
        return self._discover_from_source(content)
    
    def _extract_function_info(self, func: Callable[..., Any]) -> FunctionInfo:
        """Extract detailed information from a function.
        
        Args:
            func: The function to analyze
            
        Returns:
            FunctionInfo with extracted data
        """
        name = func.__name__
        docstring = func.__doc__
        
        # Parse docstring
        parsed = self._parser.parse(docstring)
        
        # Get signature
        try:
            sig = inspect.signature(func)
        except (ValueError, TypeError):
            sig = None
        
        # Get type hints
        try:
            hints = get_type_hints(func)
        except Exception:
            hints = {}
        
        # Extract parameters
        parameters: list[ParameterInfo] = []
        if sig:
            for param_name, param in sig.parameters.items():
                if param_name in ("self", "cls"):
                    continue
                
                type_hint = "any"
                if param_name in hints:
                    type_hint = self._format_type_hint(hints[param_name])
                elif param.annotation != inspect.Parameter.empty:
                    type_hint = self._format_type_hint(param.annotation)
                
                parameters.append(ParameterInfo(
                    name=param_name,
                    type_hint=type_hint,
                    description=parsed["parameters"].get(param_name, ""),
                    required=param.default == inspect.Parameter.empty,
                    default=None if param.default == inspect.Parameter.empty else param.default,
                ))
        
        # Get return type
        return_type = "any"
        if "return" in hints:
            return_type = self._format_type_hint(hints["return"])
        
        # Infer tags
        tags = self._infer_tags(name, parsed["description"])
        
        return FunctionInfo(
            name=name,
            description=parsed["description"],
            parameters=parameters,
            return_type=return_type,
            return_description=parsed["returns"],
            examples=parsed["examples"],
            tags=tags,
        )
    
    def _discover_from_source(self, source: str) -> list[AgentSkill]:
        """Discover skills from Python source code.
        
        Args:
            source: Python source code
            
        Returns:
            List of discovered skills
        """
        skills = []
        
        try:
            tree = ast.parse(source)
        except SyntaxError:
            return skills
        
        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef):
                # Skip private functions
                if node.name.startswith("_"):
                    continue
                
                docstring = ast.get_docstring(node)
                parsed = self._parser.parse(docstring)
                
                tags = self._infer_tags(node.name, parsed["description"])
                
                skill = AgentSkill(
                    id=self._generate_skill_id(node.name),
                    name=self._format_name(node.name),
                    description=parsed["description"] or f"Execute {node.name}",
                    tags=tags,
                    examples=parsed["examples"],
                )
                skills.append(skill)
        
        return skills
    
    def _generate_skill_id(self, name: str) -> str:
        """Generate a skill ID from a function name.
        
        Args:
            name: Function name
            
        Returns:
            Skill ID string
        """
        # Convert snake_case to kebab-case
        return name.replace("_", "-").lower()
    
    def _format_name(self, name: str) -> str:
        """Format a function name as a human-readable skill name.
        
        Args:
            name: Function name
            
        Returns:
            Formatted skill name
        """
        # Convert snake_case to Title Case
        words = name.replace("_", " ").replace("-", " ").split()
        return " ".join(word.capitalize() for word in words)
    
    def _format_type_hint(self, hint: Any) -> str:
        """Format a type hint as a string.
        
        Args:
            hint: Type hint object
            
        Returns:
            String representation
        """
        if hint is None:
            return "null"
        if hint is str or hint == "str":
            return "string"
        if hint is int or hint == "int":
            return "integer"
        if hint is float or hint == "float":
            return "number"
        if hint is bool or hint == "bool":
            return "boolean"
        if hint is list or str(hint).startswith("list"):
            return "array"
        if hint is dict or str(hint).startswith("dict"):
            return "object"
        
        return str(hint)
    
    def _infer_tags(self, name: str, description: str) -> list[str]:
        """Infer tags based on function name and description.
        
        Args:
            name: Function name
            description: Function description
            
        Returns:
            List of inferred tags
        """
        tags = set()
        text = f"{name} {description}".lower()
        
        for pattern, pattern_tags in self.TAG_PATTERNS.items():
            if re.search(pattern, text):
                tags.update(pattern_tags)
        
        return sorted(tags)
    
    def _infer_output_modes(self, return_type: str) -> list[str]:
        """Infer output content types from return type.
        
        Args:
            return_type: Return type string
            
        Returns:
            List of output content types
        """
        modes = ["text/plain"]
        
        if return_type in ("object", "array"):
            modes.append("application/json")
        elif "dict" in return_type or "list" in return_type:
            modes.append("application/json")
        
        return modes


def discover_skills(
    source: Callable[..., Any] | list[Callable[..., Any]] | str | Path,
) -> list[AgentSkill]:
    """Convenience function to discover skills from various sources.
    
    Args:
        source: Function, list of functions, or path to module
        
    Returns:
        List of discovered AgentSkill objects
        
    Example:
        ```python
        # From a single function
        skills = discover_skills(my_function)
        
        # From multiple functions
        skills = discover_skills([func1, func2, func3])
        
        # From a module file
        skills = discover_skills("path/to/module.py")
        ```
    """
    discoverer = SkillDiscoverer()
    
    if callable(source):
        return [discoverer.discover_from_function(source)]
    elif isinstance(source, list):
        return discoverer.discover_from_tools(source)
    elif isinstance(source, (str, Path)):
        return discoverer.discover_from_module(source)
    else:
        raise TypeError(f"Unsupported source type: {type(source)}")
