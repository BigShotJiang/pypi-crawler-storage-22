"""
A2A Protocol v2 Conversation Threading.

This module provides conversation threading support for the A2A protocol,
enabling multi-turn conversations with context preservation.

Reference: https://github.com/google/A2A
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any


class MessageRole(Enum):
    """Role of a message sender."""
    
    USER = "user"
    AGENT = "agent"
    SYSTEM = "system"


class MessageStatus(Enum):
    """Status of a message."""
    
    PENDING = "pending"
    DELIVERED = "delivered"
    PROCESSED = "processed"
    FAILED = "failed"


@dataclass
class ThreadMessage:
    """A message within a conversation thread.
    
    Attributes:
        id: Unique message identifier
        thread_id: ID of the parent thread
        role: Message sender role
        content: Message content
        content_type: MIME type of the content
        status: Message delivery/processing status
        metadata: Additional message metadata
        created_at: Message creation timestamp
        parent_message_id: ID of the message this replies to
        artifacts: Attached artifacts (files, data)
    """
    
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    thread_id: str = ""
    role: MessageRole = MessageRole.USER
    content: str = ""
    content_type: str = "text/plain"
    status: MessageStatus = MessageStatus.PENDING
    metadata: dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=datetime.now)
    parent_message_id: str | None = None
    artifacts: list[dict[str, Any]] = field(default_factory=list)
    
    def to_dict(self) -> dict[str, Any]:
        """Convert message to dictionary."""
        return {
            "id": self.id,
            "thread_id": self.thread_id,
            "role": self.role.value,
            "content": self.content,
            "content_type": self.content_type,
            "status": self.status.value,
            "metadata": self.metadata,
            "created_at": self.created_at.isoformat(),
            "parent_message_id": self.parent_message_id,
            "artifacts": self.artifacts,
        }
    
    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ThreadMessage":
        """Create message from dictionary."""
        return cls(
            id=data.get("id", str(uuid.uuid4())),
            thread_id=data.get("thread_id", ""),
            role=MessageRole(data.get("role", "user")),
            content=data.get("content", ""),
            content_type=data.get("content_type", "text/plain"),
            status=MessageStatus(data.get("status", "pending")),
            metadata=data.get("metadata", {}),
            created_at=datetime.fromisoformat(data["created_at"]) if "created_at" in data else datetime.now(),
            parent_message_id=data.get("parent_message_id"),
            artifacts=data.get("artifacts", []),
        )


class ThreadState(Enum):
    """State of a conversation thread."""
    
    ACTIVE = "active"
    PAUSED = "paused"
    COMPLETED = "completed"
    CANCELLED = "cancelled"
    EXPIRED = "expired"


@dataclass
class ThreadContext:
    """Context data preserved across a thread.
    
    Attributes:
        variables: Thread variables
        agent_states: State of each participating agent
        summary: Running summary of the conversation
        key_points: Key points extracted from conversation
    """
    
    variables: dict[str, Any] = field(default_factory=dict)
    agent_states: dict[str, Any] = field(default_factory=dict)
    summary: str = ""
    key_points: list[str] = field(default_factory=list)
    
    def set_variable(self, key: str, value: Any) -> None:
        """Set a context variable."""
        self.variables[key] = value
    
    def get_variable(self, key: str, default: Any = None) -> Any:
        """Get a context variable."""
        return self.variables.get(key, default)
    
    def add_key_point(self, point: str) -> None:
        """Add a key point."""
        if point not in self.key_points:
            self.key_points.append(point)
    
    def update_summary(self, summary: str) -> None:
        """Update the conversation summary."""
        self.summary = summary
    
    def to_dict(self) -> dict[str, Any]:
        """Convert context to dictionary."""
        return {
            "variables": self.variables,
            "agent_states": self.agent_states,
            "summary": self.summary,
            "key_points": self.key_points,
        }
    
    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ThreadContext":
        """Create context from dictionary."""
        return cls(
            variables=data.get("variables", {}),
            agent_states=data.get("agent_states", {}),
            summary=data.get("summary", ""),
            key_points=data.get("key_points", []),
        )


@dataclass
class ConversationThread:
    """A2A Protocol conversation thread.
    
    Represents a multi-turn conversation between agents or between
    a user and agents. Maintains message history and context.
    
    Example:
        ```python
        from multi_agent_base.a2a.threading import ConversationThread, ThreadMessage
        
        # Create a new thread
        thread = ConversationThread.create(
            title="Research Discussion",
            participants=["user", "research-agent"],
        )
        
        # Add messages
        thread.add_message(
            content="Research AI agents",
            role=MessageRole.USER,
        )
        
        thread.add_message(
            content="Here's what I found...",
            role=MessageRole.AGENT,
            metadata={"agent": "research-agent"},
        )
        
        # Get thread history
        for msg in thread.get_messages():
            print(f"{msg.role}: {msg.content}")
        ```
    
    Attributes:
        id: Unique thread identifier
        title: Thread title
        state: Current thread state
        participants: List of participant identifiers
        messages: Messages in the thread
        context: Thread context data
        created_at: Thread creation timestamp
        updated_at: Last update timestamp
        metadata: Additional thread metadata
        max_messages: Maximum messages before auto-summarization
    """
    
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    title: str = ""
    state: ThreadState = ThreadState.ACTIVE
    participants: list[str] = field(default_factory=list)
    messages: list[ThreadMessage] = field(default_factory=list)
    context: ThreadContext = field(default_factory=ThreadContext)
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)
    metadata: dict[str, Any] = field(default_factory=dict)
    max_messages: int = 100
    
    @classmethod
    def create(
        cls,
        title: str = "",
        participants: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> "ConversationThread":
        """Create a new conversation thread.
        
        Args:
            title: Optional thread title
            participants: List of participant IDs
            metadata: Optional metadata
            
        Returns:
            New ConversationThread instance
        """
        return cls(
            title=title,
            participants=participants or [],
            metadata=metadata or {},
        )
    
    def add_message(
        self,
        content: str,
        role: MessageRole = MessageRole.USER,
        content_type: str = "text/plain",
        metadata: dict[str, Any] | None = None,
        parent_message_id: str | None = None,
        artifacts: list[dict[str, Any]] | None = None,
    ) -> ThreadMessage:
        """Add a message to the thread.
        
        Args:
            content: Message content
            role: Sender role
            content_type: MIME type
            metadata: Optional metadata
            parent_message_id: ID of parent message (for replies)
            artifacts: Optional artifacts
            
        Returns:
            The created message
        """
        message = ThreadMessage(
            thread_id=self.id,
            role=role,
            content=content,
            content_type=content_type,
            metadata=metadata or {},
            parent_message_id=parent_message_id,
            artifacts=artifacts or [],
        )
        
        self.messages.append(message)
        self.updated_at = datetime.now()
        
        return message
    
    def get_messages(
        self,
        limit: int | None = None,
        role: MessageRole | None = None,
        since: datetime | None = None,
    ) -> list[ThreadMessage]:
        """Get messages from the thread.
        
        Args:
            limit: Maximum messages to return (from most recent)
            role: Filter by role
            since: Only messages after this time
            
        Returns:
            List of messages
        """
        result = self.messages
        
        if role:
            result = [m for m in result if m.role == role]
        
        if since:
            result = [m for m in result if m.created_at > since]
        
        if limit:
            result = result[-limit:]
        
        return result
    
    def get_message(self, message_id: str) -> ThreadMessage | None:
        """Get a specific message by ID.
        
        Args:
            message_id: Message ID
            
        Returns:
            The message if found
        """
        for msg in self.messages:
            if msg.id == message_id:
                return msg
        return None
    
    def get_last_message(self, role: MessageRole | None = None) -> ThreadMessage | None:
        """Get the last message in the thread.
        
        Args:
            role: Optional role filter
            
        Returns:
            The last message if any
        """
        messages = self.get_messages(role=role)
        return messages[-1] if messages else None
    
    def update_message_status(
        self,
        message_id: str,
        status: MessageStatus,
    ) -> bool:
        """Update a message's status.
        
        Args:
            message_id: Message ID
            status: New status
            
        Returns:
            True if message was found and updated
        """
        msg = self.get_message(message_id)
        if msg:
            msg.status = status
            self.updated_at = datetime.now()
            return True
        return False
    
    def set_state(self, state: ThreadState) -> None:
        """Set the thread state.
        
        Args:
            state: New state
        """
        self.state = state
        self.updated_at = datetime.now()
    
    def is_active(self) -> bool:
        """Check if thread is active."""
        return self.state == ThreadState.ACTIVE
    
    def complete(self) -> None:
        """Mark thread as completed."""
        self.set_state(ThreadState.COMPLETED)
    
    def cancel(self) -> None:
        """Cancel the thread."""
        self.set_state(ThreadState.CANCELLED)
    
    def pause(self) -> None:
        """Pause the thread."""
        self.set_state(ThreadState.PAUSED)
    
    def resume(self) -> None:
        """Resume a paused thread."""
        if self.state == ThreadState.PAUSED:
            self.set_state(ThreadState.ACTIVE)
    
    def get_context_for_agent(self, agent_id: str) -> dict[str, Any]:
        """Get context relevant to a specific agent.
        
        Args:
            agent_id: Agent identifier
            
        Returns:
            Context dictionary for the agent
        """
        return {
            "thread_id": self.id,
            "title": self.title,
            "message_count": len(self.messages),
            "summary": self.context.summary,
            "key_points": self.context.key_points,
            "agent_state": self.context.agent_states.get(agent_id, {}),
            "variables": self.context.variables,
        }
    
    def update_agent_state(
        self,
        agent_id: str,
        state: dict[str, Any],
    ) -> None:
        """Update an agent's state in the context.
        
        Args:
            agent_id: Agent identifier
            state: State data to merge
        """
        if agent_id not in self.context.agent_states:
            self.context.agent_states[agent_id] = {}
        self.context.agent_states[agent_id].update(state)
        self.updated_at = datetime.now()
    
    def to_dict(self) -> dict[str, Any]:
        """Convert thread to dictionary."""
        return {
            "id": self.id,
            "title": self.title,
            "state": self.state.value,
            "participants": self.participants,
            "messages": [m.to_dict() for m in self.messages],
            "context": self.context.to_dict(),
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
            "metadata": self.metadata,
            "max_messages": self.max_messages,
        }
    
    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ConversationThread":
        """Create thread from dictionary."""
        thread = cls(
            id=data.get("id", str(uuid.uuid4())),
            title=data.get("title", ""),
            state=ThreadState(data.get("state", "active")),
            participants=data.get("participants", []),
            context=ThreadContext.from_dict(data.get("context", {})),
            created_at=datetime.fromisoformat(data["created_at"]) if "created_at" in data else datetime.now(),
            updated_at=datetime.fromisoformat(data["updated_at"]) if "updated_at" in data else datetime.now(),
            metadata=data.get("metadata", {}),
            max_messages=data.get("max_messages", 100),
        )
        
        # Parse messages
        for msg_data in data.get("messages", []):
            thread.messages.append(ThreadMessage.from_dict(msg_data))
        
        return thread


class ThreadManager:
    """Manager for conversation threads.
    
    Provides thread lifecycle management including creation,
    retrieval, and cleanup.
    
    Example:
        ```python
        manager = ThreadManager()
        
        # Create a new thread
        thread = manager.create_thread("My Conversation")
        
        # Add messages
        thread.add_message("Hello!", MessageRole.USER)
        
        # Retrieve thread later
        same_thread = manager.get_thread(thread.id)
        
        # List active threads
        active = manager.list_threads(state=ThreadState.ACTIVE)
        ```
    """
    
    def __init__(self) -> None:
        """Initialize the thread manager."""
        self._threads: dict[str, ConversationThread] = {}
    
    def create_thread(
        self,
        title: str = "",
        participants: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> ConversationThread:
        """Create a new thread.
        
        Args:
            title: Thread title
            participants: Participant IDs
            metadata: Optional metadata
            
        Returns:
            New thread
        """
        thread = ConversationThread.create(
            title=title,
            participants=participants,
            metadata=metadata,
        )
        self._threads[thread.id] = thread
        return thread
    
    def get_thread(self, thread_id: str) -> ConversationThread | None:
        """Get a thread by ID.
        
        Args:
            thread_id: Thread ID
            
        Returns:
            Thread if found
        """
        return self._threads.get(thread_id)
    
    def list_threads(
        self,
        state: ThreadState | None = None,
        participant: str | None = None,
        limit: int | None = None,
    ) -> list[ConversationThread]:
        """List threads with optional filters.
        
        Args:
            state: Filter by state
            participant: Filter by participant
            limit: Maximum threads to return
            
        Returns:
            List of matching threads
        """
        result = list(self._threads.values())
        
        if state:
            result = [t for t in result if t.state == state]
        
        if participant:
            result = [t for t in result if participant in t.participants]
        
        # Sort by updated_at descending
        result.sort(key=lambda t: t.updated_at, reverse=True)
        
        if limit:
            result = result[:limit]
        
        return result
    
    def delete_thread(self, thread_id: str) -> bool:
        """Delete a thread.
        
        Args:
            thread_id: Thread ID
            
        Returns:
            True if deleted
        """
        if thread_id in self._threads:
            del self._threads[thread_id]
            return True
        return False
    
    def cleanup_expired(
        self,
        max_age_hours: int = 24,
    ) -> int:
        """Clean up expired or old threads.
        
        Args:
            max_age_hours: Maximum age in hours
            
        Returns:
            Number of threads deleted
        """
        from datetime import timedelta
        
        cutoff = datetime.now() - timedelta(hours=max_age_hours)
        to_delete = []
        
        for thread_id, thread in self._threads.items():
            if thread.state in (ThreadState.COMPLETED, ThreadState.CANCELLED, ThreadState.EXPIRED):
                if thread.updated_at < cutoff:
                    to_delete.append(thread_id)
        
        for thread_id in to_delete:
            del self._threads[thread_id]
        
        return len(to_delete)
    
    def get_stats(self) -> dict[str, int]:
        """Get thread statistics.
        
        Returns:
            Stats dictionary
        """
        stats = {
            "total": len(self._threads),
            "active": 0,
            "paused": 0,
            "completed": 0,
            "cancelled": 0,
            "expired": 0,
        }
        
        for thread in self._threads.values():
            stats[thread.state.value] += 1
        
        return stats
