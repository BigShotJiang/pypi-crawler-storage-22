"""
Caching Module for Multi-Agent Base.

This module provides response caching capabilities:
- In-memory LRU cache
- Redis-backed distributed cache
- Semantic caching for similar queries
- Cache decorators
"""

from multi_agent_base.cache.backend import (
    CacheBackend,
    CacheEntry,
    CacheConfig,
    InMemoryCache,
    TTLCache,
)
from multi_agent_base.cache.semantic import (
    SemanticCache,
    SemanticCacheConfig,
)
from multi_agent_base.cache.decorators import (
    cached,
    cache_response,
)

__all__ = [
    # Core
    "CacheBackend",
    "CacheEntry",
    "CacheConfig",
    # Implementations
    "InMemoryCache",
    "TTLCache",
    "SemanticCache",
    "SemanticCacheConfig",
    # Decorators
    "cached",
    "cache_response",
]
