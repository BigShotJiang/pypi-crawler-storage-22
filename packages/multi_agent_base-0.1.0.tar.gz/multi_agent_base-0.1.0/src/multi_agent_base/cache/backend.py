"""
Cache backend implementations.

Provides in-memory and TTL-based caching.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import time
from abc import ABC, abstractmethod
from collections import OrderedDict
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Generic, TypeVar

from pydantic import BaseModel, Field

T = TypeVar("T")


@dataclass
class CacheEntry(Generic[T]):
    """A cache entry with metadata.
    
    Attributes:
        key: Cache key
        value: Cached value
        created_at: When the entry was created
        expires_at: When the entry expires (None = never)
        hits: Number of cache hits
        metadata: Additional metadata
    """
    
    key: str
    value: T
    created_at: datetime = field(default_factory=datetime.now)
    expires_at: datetime | None = None
    hits: int = 0
    metadata: dict[str, Any] = field(default_factory=dict)
    
    def is_expired(self) -> bool:
        """Check if entry has expired."""
        if self.expires_at is None:
            return False
        return datetime.now() > self.expires_at
    
    def hit(self) -> None:
        """Record a cache hit."""
        self.hits += 1


class CacheConfig(BaseModel):
    """Configuration for cache.
    
    Attributes:
        enabled: Whether caching is enabled
        max_size: Maximum number of entries
        ttl_seconds: Default TTL for entries
        eviction_policy: Eviction policy (lru, lfu, fifo)
    """
    
    enabled: bool = Field(
        default=True,
        description="Enable caching"
    )
    max_size: int = Field(
        default=1000,
        gt=0,
        description="Maximum cache entries"
    )
    ttl_seconds: int | None = Field(
        default=3600,
        description="Default TTL in seconds"
    )
    eviction_policy: str = Field(
        default="lru",
        description="Eviction policy"
    )


class CacheBackend(ABC, Generic[T]):
    """Abstract base class for cache backends.
    
    All cache implementations must inherit from this class.
    """
    
    @abstractmethod
    async def get(self, key: str) -> T | None:
        """Get a value from cache.
        
        Args:
            key: Cache key
            
        Returns:
            Cached value or None if not found/expired
        """
        pass
    
    @abstractmethod
    async def set(
        self,
        key: str,
        value: T,
        ttl_seconds: int | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Set a value in cache.
        
        Args:
            key: Cache key
            value: Value to cache
            ttl_seconds: Time-to-live in seconds
            metadata: Additional metadata
        """
        pass
    
    @abstractmethod
    async def delete(self, key: str) -> bool:
        """Delete a key from cache.
        
        Args:
            key: Cache key
            
        Returns:
            True if key was deleted
        """
        pass
    
    @abstractmethod
    async def clear(self) -> None:
        """Clear all entries from cache."""
        pass
    
    @abstractmethod
    async def exists(self, key: str) -> bool:
        """Check if key exists in cache.
        
        Args:
            key: Cache key
            
        Returns:
            True if key exists and is not expired
        """
        pass
    
    @abstractmethod
    def size(self) -> int:
        """Get current cache size.
        
        Returns:
            Number of entries in cache
        """
        pass
    
    @staticmethod
    def generate_key(*args: Any, **kwargs: Any) -> str:
        """Generate a cache key from arguments.
        
        Args:
            *args: Positional arguments
            **kwargs: Keyword arguments
            
        Returns:
            Hash-based cache key
        """
        key_data = json.dumps(
            {"args": args, "kwargs": kwargs},
            sort_keys=True,
            default=str,
        )
        return hashlib.sha256(key_data.encode()).hexdigest()[:32]


class InMemoryCache(CacheBackend[T]):
    """In-memory LRU cache.
    
    Simple in-memory cache with LRU eviction.
    
    Example:
        ```python
        cache = InMemoryCache[str](max_size=100)
        
        await cache.set("key", "value")
        result = await cache.get("key")
        ```
    """
    
    def __init__(
        self,
        max_size: int = 1000,
        config: CacheConfig | None = None,
    ) -> None:
        """Initialize in-memory cache.
        
        Args:
            max_size: Maximum number of entries
            config: Optional cache configuration
        """
        self.config = config or CacheConfig(max_size=max_size)
        self._cache: OrderedDict[str, CacheEntry[T]] = OrderedDict()
        self._lock = asyncio.Lock()
    
    async def get(self, key: str) -> T | None:
        """Get value from cache."""
        async with self._lock:
            if key not in self._cache:
                return None
            
            entry = self._cache[key]
            
            # Check expiration
            if entry.is_expired():
                del self._cache[key]
                return None
            
            # Move to end (LRU)
            self._cache.move_to_end(key)
            entry.hit()
            
            return entry.value
    
    async def set(
        self,
        key: str,
        value: T,
        ttl_seconds: int | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Set value in cache."""
        async with self._lock:
            # Evict if at capacity
            while len(self._cache) >= self.config.max_size:
                self._cache.popitem(last=False)  # Remove oldest
            
            # Calculate expiration
            expires_at = None
            ttl = ttl_seconds or self.config.ttl_seconds
            if ttl:
                from datetime import timedelta
                expires_at = datetime.now() + timedelta(seconds=ttl)
            
            # Create entry
            entry = CacheEntry(
                key=key,
                value=value,
                expires_at=expires_at,
                metadata=metadata or {},
            )
            
            self._cache[key] = entry
    
    async def delete(self, key: str) -> bool:
        """Delete key from cache."""
        async with self._lock:
            if key in self._cache:
                del self._cache[key]
                return True
            return False
    
    async def clear(self) -> None:
        """Clear all entries."""
        async with self._lock:
            self._cache.clear()
    
    async def exists(self, key: str) -> bool:
        """Check if key exists."""
        async with self._lock:
            if key not in self._cache:
                return False
            
            entry = self._cache[key]
            if entry.is_expired():
                del self._cache[key]
                return False
            
            return True
    
    def size(self) -> int:
        """Get cache size."""
        return len(self._cache)
    
    async def get_stats(self) -> dict[str, Any]:
        """Get cache statistics.
        
        Returns:
            Dictionary with cache stats
        """
        async with self._lock:
            total_hits = sum(e.hits for e in self._cache.values())
            expired = sum(1 for e in self._cache.values() if e.is_expired())
            
            return {
                "size": len(self._cache),
                "max_size": self.config.max_size,
                "total_hits": total_hits,
                "expired_entries": expired,
            }


class TTLCache(CacheBackend[T]):
    """TTL-based cache with automatic expiration cleanup.
    
    Periodically removes expired entries.
    
    Example:
        ```python
        cache = TTLCache[dict](
            max_size=500,
            default_ttl=300,  # 5 minutes
            cleanup_interval=60,
        )
        
        await cache.set("response", {"data": "value"})
        ```
    """
    
    def __init__(
        self,
        max_size: int = 1000,
        default_ttl: int = 3600,
        cleanup_interval: int = 60,
    ) -> None:
        """Initialize TTL cache.
        
        Args:
            max_size: Maximum entries
            default_ttl: Default TTL in seconds
            cleanup_interval: Cleanup interval in seconds
        """
        self.max_size = max_size
        self.default_ttl = default_ttl
        self.cleanup_interval = cleanup_interval
        
        self._cache: dict[str, CacheEntry[T]] = {}
        self._lock = asyncio.Lock()
        self._cleanup_task: asyncio.Task | None = None
    
    async def start_cleanup(self) -> None:
        """Start background cleanup task."""
        if self._cleanup_task is None:
            self._cleanup_task = asyncio.create_task(self._cleanup_loop())
    
    async def stop_cleanup(self) -> None:
        """Stop background cleanup task."""
        if self._cleanup_task:
            self._cleanup_task.cancel()
            self._cleanup_task = None
    
    async def _cleanup_loop(self) -> None:
        """Background cleanup loop."""
        while True:
            await asyncio.sleep(self.cleanup_interval)
            await self._cleanup_expired()
    
    async def _cleanup_expired(self) -> None:
        """Remove expired entries."""
        async with self._lock:
            expired_keys = [
                k for k, v in self._cache.items()
                if v.is_expired()
            ]
            for key in expired_keys:
                del self._cache[key]
    
    async def get(self, key: str) -> T | None:
        """Get value from cache."""
        async with self._lock:
            if key not in self._cache:
                return None
            
            entry = self._cache[key]
            
            if entry.is_expired():
                del self._cache[key]
                return None
            
            entry.hit()
            return entry.value
    
    async def set(
        self,
        key: str,
        value: T,
        ttl_seconds: int | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Set value in cache."""
        async with self._lock:
            # Evict oldest if at capacity
            if len(self._cache) >= self.max_size:
                # Sort by created_at and remove oldest
                oldest_key = min(
                    self._cache.keys(),
                    key=lambda k: self._cache[k].created_at
                )
                del self._cache[oldest_key]
            
            # Calculate expiration
            ttl = ttl_seconds or self.default_ttl
            from datetime import timedelta
            expires_at = datetime.now() + timedelta(seconds=ttl)
            
            entry = CacheEntry(
                key=key,
                value=value,
                expires_at=expires_at,
                metadata=metadata or {},
            )
            
            self._cache[key] = entry
    
    async def delete(self, key: str) -> bool:
        """Delete key from cache."""
        async with self._lock:
            if key in self._cache:
                del self._cache[key]
                return True
            return False
    
    async def clear(self) -> None:
        """Clear all entries."""
        async with self._lock:
            self._cache.clear()
    
    async def exists(self, key: str) -> bool:
        """Check if key exists."""
        async with self._lock:
            if key not in self._cache:
                return False
            
            entry = self._cache[key]
            if entry.is_expired():
                del self._cache[key]
                return False
            
            return True
    
    def size(self) -> int:
        """Get cache size."""
        return len(self._cache)


class LLMResponseCache(CacheBackend[dict[str, Any]]):
    """Specialized cache for LLM responses.
    
    Caches LLM responses based on messages hash.
    
    Example:
        ```python
        cache = LLMResponseCache(max_size=500)
        
        # Check cache before calling LLM
        key = cache.generate_key(messages=messages, model=model)
        cached = await cache.get(key)
        if cached:
            return cached
            
        # Call LLM and cache response
        response = await llm.generate(messages)
        await cache.set(key, response)
        ```
    """
    
    def __init__(
        self,
        max_size: int = 1000,
        default_ttl: int = 3600,
    ) -> None:
        """Initialize LLM response cache.
        
        Args:
            max_size: Maximum entries
            default_ttl: Default TTL in seconds
        """
        self._inner = TTLCache[dict[str, Any]](
            max_size=max_size,
            default_ttl=default_ttl,
        )
    
    @staticmethod
    def generate_message_key(
        messages: list[dict[str, str]],
        model: str,
        temperature: float = 0.7,
    ) -> str:
        """Generate cache key from messages.
        
        Args:
            messages: List of messages
            model: Model name
            temperature: Temperature setting
            
        Returns:
            Cache key
        """
        key_data = {
            "messages": messages,
            "model": model,
            "temperature": temperature,
        }
        return hashlib.sha256(
            json.dumps(key_data, sort_keys=True).encode()
        ).hexdigest()[:32]
    
    async def get(self, key: str) -> dict[str, Any] | None:
        """Get cached response."""
        return await self._inner.get(key)
    
    async def set(
        self,
        key: str,
        value: dict[str, Any],
        ttl_seconds: int | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Cache LLM response."""
        await self._inner.set(key, value, ttl_seconds, metadata)
    
    async def delete(self, key: str) -> bool:
        """Delete cached response."""
        return await self._inner.delete(key)
    
    async def clear(self) -> None:
        """Clear all cached responses."""
        await self._inner.clear()
    
    async def exists(self, key: str) -> bool:
        """Check if response is cached."""
        return await self._inner.exists(key)
    
    def size(self) -> int:
        """Get cache size."""
        return self._inner.size()
