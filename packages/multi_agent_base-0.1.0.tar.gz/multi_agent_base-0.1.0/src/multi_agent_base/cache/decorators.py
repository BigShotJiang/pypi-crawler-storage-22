"""
Cache decorators.

Provides decorators for easily adding caching to functions.
"""

from __future__ import annotations

import functools
import hashlib
import json
from typing import Any, Callable, TypeVar

from multi_agent_base.cache.backend import (
    CacheBackend,
    InMemoryCache,
)

F = TypeVar("F", bound=Callable[..., Any])


def cached(
    ttl_seconds: int = 3600,
    max_size: int = 1000,
    key_prefix: str = "",
) -> Callable[[F], F]:
    """Decorator to add caching to async functions.
    
    Creates an in-memory cache for the decorated function.
    
    Args:
        ttl_seconds: Time-to-live for cached entries
        max_size: Maximum cache size
        key_prefix: Prefix for cache keys
        
    Returns:
        Decorator function
        
    Example:
        ```python
        @cached(ttl_seconds=300)
        async def expensive_operation(x: int) -> int:
            await asyncio.sleep(1)
            return x * 2
        ```
    """
    cache: InMemoryCache[Any] = InMemoryCache(max_size=max_size)
    
    def decorator(func: F) -> F:
        @functools.wraps(func)
        async def wrapper(*args: Any, **kwargs: Any) -> Any:
            # Generate cache key
            key_data = json.dumps(
                {"args": args, "kwargs": kwargs},
                sort_keys=True,
                default=str,
            )
            key = f"{key_prefix}{hashlib.sha256(key_data.encode()).hexdigest()[:32]}"
            
            # Try to get from cache
            cached_value = await cache.get(key)
            if cached_value is not None:
                return cached_value
            
            # Call function
            result = await func(*args, **kwargs)
            
            # Cache result
            await cache.set(key, result, ttl_seconds=ttl_seconds)
            
            return result
        
        # Attach cache for inspection
        wrapper._cache = cache  # type: ignore
        
        # Add cache control methods
        async def clear_cache() -> None:
            await cache.clear()
        
        def cache_size() -> int:
            return cache.size()
        
        wrapper.clear_cache = clear_cache  # type: ignore
        wrapper.cache_size = cache_size  # type: ignore
        
        return wrapper  # type: ignore
    
    return decorator


def cache_response(
    cache: CacheBackend[Any],
    key_fn: Callable[..., str] | None = None,
    ttl_seconds: int | None = None,
) -> Callable[[F], F]:
    """Decorator to use an existing cache backend.
    
    Allows sharing a cache across multiple functions.
    
    Args:
        cache: Cache backend to use
        key_fn: Optional function to generate cache key
        ttl_seconds: Optional TTL override
        
    Returns:
        Decorator function
        
    Example:
        ```python
        shared_cache = InMemoryCache(max_size=500)
        
        @cache_response(shared_cache)
        async def fetch_data(id: int) -> dict:
            return await api.get(id)
        ```
    """
    def decorator(func: F) -> F:
        @functools.wraps(func)
        async def wrapper(*args: Any, **kwargs: Any) -> Any:
            # Generate cache key
            if key_fn:
                key = key_fn(*args, **kwargs)
            else:
                key_data = json.dumps(
                    {"fn": func.__name__, "args": args, "kwargs": kwargs},
                    sort_keys=True,
                    default=str,
                )
                key = hashlib.sha256(key_data.encode()).hexdigest()[:32]
            
            # Try to get from cache
            cached_value = await cache.get(key)
            if cached_value is not None:
                return cached_value
            
            # Call function
            result = await func(*args, **kwargs)
            
            # Cache result
            await cache.set(key, result, ttl_seconds=ttl_seconds)
            
            return result
        
        wrapper._cache = cache  # type: ignore
        
        return wrapper  # type: ignore
    
    return decorator


def cache_llm_response(
    cache: CacheBackend[dict[str, Any]],
    model: str,
    temperature: float = 0.7,
) -> Callable[[F], F]:
    """Decorator for caching LLM responses.
    
    Specialized decorator for LLM API calls that caches
    based on messages and model parameters.
    
    Args:
        cache: Cache backend to use
        model: Model name for cache key
        temperature: Temperature for cache key
        
    Returns:
        Decorator function
        
    Example:
        ```python
        llm_cache = LLMResponseCache(max_size=500)
        
        @cache_llm_response(llm_cache, model="gpt-4")
        async def generate(messages: list[dict]) -> str:
            return await openai.chat.completions.create(
                messages=messages
            )
        ```
    """
    def decorator(func: F) -> F:
        @functools.wraps(func)
        async def wrapper(messages: list[dict[str, str]], **kwargs: Any) -> Any:
            # Generate cache key from messages
            key_data = {
                "messages": messages,
                "model": model,
                "temperature": temperature,
            }
            key = hashlib.sha256(
                json.dumps(key_data, sort_keys=True).encode()
            ).hexdigest()[:32]
            
            # Try to get from cache
            cached_value = await cache.get(key)
            if cached_value is not None:
                return cached_value
            
            # Call function
            result = await func(messages, **kwargs)
            
            # Cache result
            await cache.set(
                key,
                result,
                metadata={"model": model, "temperature": temperature},
            )
            
            return result
        
        wrapper._cache = cache  # type: ignore
        
        return wrapper  # type: ignore
    
    return decorator


class CacheMixin:
    """Mixin class to add caching to classes.
    
    Example:
        ```python
        class MyService(CacheMixin):
            def __init__(self):
                super().__init__(cache_ttl=300)
            
            async def get_data(self, key: str) -> dict:
                cached = await self.get_cached(key)
                if cached:
                    return cached
                
                data = await self._fetch_data(key)
                await self.set_cached(key, data)
                return data
        ```
    """
    
    def __init__(
        self,
        cache_ttl: int = 3600,
        cache_max_size: int = 1000,
        **kwargs: Any,
    ) -> None:
        """Initialize cache mixin.
        
        Args:
            cache_ttl: Default TTL for cache entries
            cache_max_size: Maximum cache size
            **kwargs: Additional arguments for parent class
        """
        super().__init__(**kwargs)
        self._cache: InMemoryCache[Any] = InMemoryCache(max_size=cache_max_size)
        self._cache_ttl = cache_ttl
    
    async def get_cached(self, key: str) -> Any | None:
        """Get value from cache.
        
        Args:
            key: Cache key
            
        Returns:
            Cached value or None
        """
        return await self._cache.get(key)
    
    async def set_cached(
        self,
        key: str,
        value: Any,
        ttl_seconds: int | None = None,
    ) -> None:
        """Set value in cache.
        
        Args:
            key: Cache key
            value: Value to cache
            ttl_seconds: Optional TTL override
        """
        await self._cache.set(
            key,
            value,
            ttl_seconds=ttl_seconds or self._cache_ttl,
        )
    
    async def invalidate_cache(self, key: str) -> bool:
        """Invalidate a cache entry.
        
        Args:
            key: Cache key
            
        Returns:
            True if entry was removed
        """
        return await self._cache.delete(key)
    
    async def clear_cache(self) -> None:
        """Clear all cache entries."""
        await self._cache.clear()
