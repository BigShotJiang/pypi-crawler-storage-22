"""
Semantic caching for similar queries.

Uses embeddings to find semantically similar cached entries.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Callable

from pydantic import BaseModel, Field

from multi_agent_base.cache.backend import CacheBackend, CacheEntry


class SemanticCacheConfig(BaseModel):
    """Configuration for semantic cache.
    
    Attributes:
        enabled: Whether semantic caching is enabled
        max_size: Maximum number of entries
        ttl_seconds: Time-to-live for entries
        similarity_threshold: Minimum similarity score for cache hit
        embedding_dimension: Dimension of embedding vectors
    """
    
    enabled: bool = Field(
        default=True,
        description="Enable semantic caching"
    )
    max_size: int = Field(
        default=1000,
        gt=0,
        description="Maximum cache entries"
    )
    ttl_seconds: int = Field(
        default=3600,
        gt=0,
        description="TTL in seconds"
    )
    similarity_threshold: float = Field(
        default=0.95,
        ge=0.0,
        le=1.0,
        description="Minimum similarity for cache hit"
    )
    embedding_dimension: int = Field(
        default=1536,
        gt=0,
        description="Embedding vector dimension"
    )


@dataclass
class SemanticCacheEntry:
    """A semantic cache entry with embedding.
    
    Attributes:
        key: Cache key
        query: Original query text
        embedding: Query embedding vector
        response: Cached response
        created_at: Creation timestamp
        expires_at: Expiration timestamp
        hits: Number of cache hits
        metadata: Additional metadata
    """
    
    key: str
    query: str
    embedding: list[float]
    response: Any
    created_at: datetime = field(default_factory=datetime.now)
    expires_at: datetime | None = None
    hits: int = 0
    metadata: dict[str, Any] = field(default_factory=dict)
    
    def is_expired(self) -> bool:
        """Check if entry has expired."""
        if self.expires_at is None:
            return False
        return datetime.now() > self.expires_at


class SemanticCache:
    """Semantic cache using embeddings for similarity matching.
    
    Caches responses and retrieves them based on semantic similarity
    of queries, not exact matches.
    
    Example:
        ```python
        async def get_embedding(text: str) -> list[float]:
            # Your embedding function
            return await embedder.embed(text)
        
        cache = SemanticCache(
            embedding_fn=get_embedding,
            config=SemanticCacheConfig(
                similarity_threshold=0.9,
            )
        )
        
        # Try to get from cache
        result = await cache.get("What is Python?")
        if result is None:
            response = await llm.generate("What is Python?")
            await cache.set("What is Python?", response)
        ```
    """
    
    def __init__(
        self,
        embedding_fn: Callable[[str], Any],
        config: SemanticCacheConfig | None = None,
    ) -> None:
        """Initialize semantic cache.
        
        Args:
            embedding_fn: Async function to generate embeddings
            config: Cache configuration
        """
        self.embedding_fn = embedding_fn
        self.config = config or SemanticCacheConfig()
        
        self._entries: list[SemanticCacheEntry] = []
        self._lock = asyncio.Lock()
    
    async def _get_embedding(self, text: str) -> list[float]:
        """Get embedding for text.
        
        Args:
            text: Text to embed
            
        Returns:
            Embedding vector
        """
        result = self.embedding_fn(text)
        if asyncio.iscoroutine(result):
            result = await result
        return list(result)  # type: ignore[return-value]
    
    @staticmethod
    def _cosine_similarity(vec1: list[float], vec2: list[float]) -> float:
        """Calculate cosine similarity between two vectors.
        
        Args:
            vec1: First vector
            vec2: Second vector
            
        Returns:
            Cosine similarity (0-1)
        """
        if len(vec1) != len(vec2):
            return 0.0
        
        dot_product = sum(a * b for a, b in zip(vec1, vec2))
        norm1 = sum(a * a for a in vec1) ** 0.5
        norm2 = sum(b * b for b in vec2) ** 0.5
        
        if norm1 == 0 or norm2 == 0:
            return 0.0
        
        return float(dot_product / (norm1 * norm2))
    
    async def get(self, query: str) -> Any | None:
        """Get cached response for semantically similar query.
        
        Args:
            query: Query text
            
        Returns:
            Cached response or None
        """
        if not self.config.enabled:
            return None
        
        # Get query embedding
        query_embedding = await self._get_embedding(query)
        
        async with self._lock:
            # Remove expired entries
            self._entries = [
                e for e in self._entries
                if not e.is_expired()
            ]
            
            # Find most similar entry
            best_entry = None
            best_similarity = 0.0
            
            for entry in self._entries:
                similarity = self._cosine_similarity(
                    query_embedding,
                    entry.embedding,
                )
                
                if similarity > best_similarity:
                    best_similarity = similarity
                    best_entry = entry
            
            # Check threshold
            if best_entry and best_similarity >= self.config.similarity_threshold:
                best_entry.hits += 1
                return best_entry.response
            
            return None
    
    async def set(
        self,
        query: str,
        response: Any,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Cache a response for a query.
        
        Args:
            query: Query text
            response: Response to cache
            metadata: Optional metadata
        """
        if not self.config.enabled:
            return
        
        # Get query embedding
        query_embedding = await self._get_embedding(query)
        
        # Generate key
        key = hashlib.sha256(query.encode()).hexdigest()[:32]
        
        # Calculate expiration
        from datetime import timedelta
        expires_at = datetime.now() + timedelta(seconds=self.config.ttl_seconds)
        
        entry = SemanticCacheEntry(
            key=key,
            query=query,
            embedding=query_embedding,
            response=response,
            expires_at=expires_at,
            metadata=metadata or {},
        )
        
        async with self._lock:
            # Check if we need to evict
            while len(self._entries) >= self.config.max_size:
                # Remove oldest entry
                self._entries.sort(key=lambda e: e.created_at)
                self._entries.pop(0)
            
            self._entries.append(entry)
    
    async def delete(self, query: str) -> bool:
        """Delete a cached entry.
        
        Args:
            query: Query to delete
            
        Returns:
            True if entry was deleted
        """
        key = hashlib.sha256(query.encode()).hexdigest()[:32]
        
        async with self._lock:
            for i, entry in enumerate(self._entries):
                if entry.key == key:
                    self._entries.pop(i)
                    return True
            return False
    
    async def clear(self) -> None:
        """Clear all cached entries."""
        async with self._lock:
            self._entries.clear()
    
    def size(self) -> int:
        """Get number of cached entries."""
        return len(self._entries)
    
    async def get_stats(self) -> dict[str, Any]:
        """Get cache statistics.
        
        Returns:
            Dictionary with cache stats
        """
        async with self._lock:
            total_hits = sum(e.hits for e in self._entries)
            avg_hits = total_hits / len(self._entries) if self._entries else 0
            
            return {
                "size": len(self._entries),
                "max_size": self.config.max_size,
                "total_hits": total_hits,
                "average_hits_per_entry": avg_hits,
                "similarity_threshold": self.config.similarity_threshold,
            }
    
    async def find_similar(
        self,
        query: str,
        limit: int = 5,
    ) -> list[tuple[str, float]]:
        """Find similar cached queries.
        
        Args:
            query: Query to find similar entries for
            limit: Maximum results
            
        Returns:
            List of (query, similarity) tuples
        """
        query_embedding = await self._get_embedding(query)
        
        async with self._lock:
            similarities = []
            
            for entry in self._entries:
                if entry.is_expired():
                    continue
                
                similarity = self._cosine_similarity(
                    query_embedding,
                    entry.embedding,
                )
                similarities.append((entry.query, similarity))
            
            # Sort by similarity descending
            similarities.sort(key=lambda x: x[1], reverse=True)
            
            return similarities[:limit]
