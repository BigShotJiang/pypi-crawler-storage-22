"""
Context Engineering Module

Provides tools for managing, optimizing, and compressing LLM context windows.

This module includes:
- ContextOptimizer: Main orchestrator for context optimization
- ContextPruner: Specialized pruning strategies
- ContextCompressor: Compression and summarization utilities
- Type definitions for context management

Example:
    >>> from multi_agent_base.context import (
    ...     ContextOptimizer,
    ...     ContextPruner,
    ...     ContextCompressor,
    ...     OptimizationConfig,
    ... )
    >>> 
    >>> # Create optimizer with configuration
    >>> config = OptimizationConfig(max_tokens=4096, preserve_recent=3)
    >>> optimizer = ContextOptimizer(config=config)
    >>> 
    >>> # Optimize messages
    >>> messages = [
    ...     {"role": "system", "content": "You are helpful."},
    ...     {"role": "user", "content": "Hello!"},
    ...     {"role": "assistant", "content": "Hi there!"},
    ... ]
    >>> result = optimizer.optimize(messages)
    >>> print(f"Tokens: {result.stats.original_tokens} -> {result.stats.optimized_tokens}")
"""

from .compressor import (
    CompressionResult,
    ContextCompressor,
)
from .optimizer import (
    ContextOptimizer,
    OptimizationResult,
    TokenEstimator,
)
from .pruner import (
    ContextPruner,
    ConversationPruner,
    PruningResult,
)
from .types import (
    CompressionMethod,
    ContextMessage,
    ContextSnapshot,
    ContextStats,
    ContextWindow,
    MessageRole,
    OptimizationConfig,
    PruningStrategy,
    ToolContext,
)

__all__ = [
    # Types
    "MessageRole",
    "PruningStrategy",
    "CompressionMethod",
    "ContextMessage",
    "ContextWindow",
    "ContextStats",
    "OptimizationConfig",
    "ToolContext",
    "ContextSnapshot",
    # Optimizer
    "ContextOptimizer",
    "OptimizationResult",
    "TokenEstimator",
    # Pruner
    "ContextPruner",
    "ConversationPruner",
    "PruningResult",
    # Compressor
    "ContextCompressor",
    "CompressionResult",
]
