"""
Context Compressor

Utilities for compressing and summarizing context content.
"""

from __future__ import annotations

import re
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Optional

from .types import (
    CompressionMethod,
    ContextMessage,
    ContextStats,
    ContextWindow,
    MessageRole,
    ToolContext,
)


@dataclass
class CompressionResult:
    """
    Result of a compression operation.
    
    Attributes:
        messages: Compressed messages
        stats: Compression statistics
        summaries: Generated summaries
        merged_count: Number of messages merged
    """
    
    messages: list[ContextMessage]
    stats: ContextStats
    summaries: list[str] = field(default_factory=list)
    merged_count: int = 0
    
    @property
    def message_count(self) -> int:
        """Number of resulting messages."""
        return len(self.messages)
    
    def to_list(self) -> list[dict[str, Any]]:
        """Convert messages to list of dictionaries."""
        return [msg.to_dict() for msg in self.messages]


class ContextCompressor:
    """
    Context compression and summarization utilities.
    
    Provides methods to reduce context size while preserving
    important information through various compression techniques.
    
    Example:
        >>> compressor = ContextCompressor()
        >>> messages = [...] # long list of messages
        >>> result = compressor.compress(messages, target_tokens=2048)
        >>> print(f"Compressed from {result.stats.original_tokens} to {result.stats.optimized_tokens}")
    """
    
    def __init__(
        self,
        summarizer: Optional[Callable[[list[str]], str]] = None,
        default_compression_ratio: float = 0.5,
    ) -> None:
        """
        Initialize the compressor.
        
        Args:
            summarizer: Function to summarize a list of message contents
            default_compression_ratio: Target ratio for compression (0.5 = 50% of original)
        """
        self.summarizer = summarizer
        self.default_compression_ratio = default_compression_ratio
    
    def compress(
        self,
        messages: list[dict[str, Any]] | list[ContextMessage],
        target_tokens: Optional[int] = None,
        method: CompressionMethod = CompressionMethod.SUMMARIZE,
        preserve_recent: int = 3,
    ) -> CompressionResult:
        """
        Compress messages to reduce token count.
        
        Args:
            messages: Messages to compress
            target_tokens: Target token count (if None, uses compression ratio)
            method: Compression method to use
            preserve_recent: Number of recent messages to keep uncompressed
            
        Returns:
            CompressionResult with compressed messages
        """
        start_time = time.time()
        ctx_messages = self._to_context_messages(messages)
        original_count = len(ctx_messages)
        original_tokens = sum(m.token_count for m in ctx_messages)
        
        # Calculate target if not provided
        if target_tokens is None:
            target_tokens = int(original_tokens * self.default_compression_ratio)
        
        # If already within limit, return as-is
        if original_tokens <= target_tokens:
            stats = ContextStats(
                original_messages=original_count,
                optimized_messages=original_count,
                original_tokens=original_tokens,
                optimized_tokens=original_tokens,
                operation_time_ms=(time.time() - start_time) * 1000,
                strategy_used="none_needed",
            )
            return CompressionResult(messages=ctx_messages, stats=stats)
        
        # Apply compression based on method
        if method == CompressionMethod.SUMMARIZE:
            result = self._compress_by_summarization(
                ctx_messages, target_tokens, preserve_recent
            )
        elif method == CompressionMethod.MERGE:
            result = self._compress_by_merging(
                ctx_messages, target_tokens, preserve_recent
            )
        elif method == CompressionMethod.EXTRACT_KEY_POINTS:
            result = self._compress_by_extraction(
                ctx_messages, target_tokens, preserve_recent
            )
        elif method == CompressionMethod.HIERARCHICAL:
            result = self._compress_hierarchically(
                ctx_messages, target_tokens, preserve_recent
            )
        else:
            # Default to summarization
            result = self._compress_by_summarization(
                ctx_messages, target_tokens, preserve_recent
            )
        
        # Update timing
        result.stats.operation_time_ms = (time.time() - start_time) * 1000
        
        return result
    
    def summarize_messages(
        self,
        messages: list[dict[str, Any]] | list[ContextMessage],
        max_summary_tokens: int = 200,
    ) -> str:
        """
        Generate a summary of messages.
        
        Args:
            messages: Messages to summarize
            max_summary_tokens: Maximum tokens for summary
            
        Returns:
            Summary string
        """
        ctx_messages = self._to_context_messages(messages)
        
        if self.summarizer:
            contents = [msg.content for msg in ctx_messages]
            return self.summarizer(contents)
        
        # Fallback: simple extraction
        return self._simple_summarize(ctx_messages, max_summary_tokens)
    
    def compress_tools(
        self,
        tools: list[dict[str, Any]] | list[ToolContext],
        max_tokens: int = 1000,
        keep_names: Optional[list[str]] = None,
    ) -> list[ToolContext]:
        """
        Compress tool definitions to fit within token limit.
        
        Args:
            tools: Tool definitions to compress
            max_tokens: Maximum tokens for all tools
            keep_names: Tool names that must be kept
            
        Returns:
            List of compressed ToolContext objects
        """
        tool_contexts = self._to_tool_contexts(tools)
        
        # Prioritize kept tools
        must_keep: list[ToolContext] = []
        optional: list[ToolContext] = []
        
        for tool in tool_contexts:
            if keep_names and tool.name in keep_names:
                must_keep.append(tool)
            else:
                optional.append(tool)
        
        # Calculate tokens for must-keep tools
        must_keep_tokens = sum(t.estimate_tokens() for t in must_keep)
        remaining_tokens = max_tokens - must_keep_tokens
        
        if remaining_tokens <= 0:
            # Only return must-keep tools, possibly compressed
            return self._compress_tool_descriptions(must_keep, max_tokens)
        
        # Sort optional by usage and importance
        optional.sort(key=lambda t: (t.usage_count, t.importance), reverse=True)
        
        # Add optional tools that fit
        result = list(must_keep)
        current_tokens = must_keep_tokens
        
        for tool in optional:
            tool_tokens = tool.estimate_tokens()
            if current_tokens + tool_tokens <= max_tokens:
                result.append(tool)
                current_tokens += tool_tokens
        
        return result
    
    def merge_similar_messages(
        self,
        messages: list[dict[str, Any]] | list[ContextMessage],
        similarity_threshold: float = 0.7,
    ) -> CompressionResult:
        """
        Merge similar consecutive messages.
        
        Args:
            messages: Messages to merge
            similarity_threshold: Threshold for considering messages similar
            
        Returns:
            CompressionResult with merged messages
        """
        start_time = time.time()
        ctx_messages = self._to_context_messages(messages)
        original_count = len(ctx_messages)
        original_tokens = sum(m.token_count for m in ctx_messages)
        
        merged: list[ContextMessage] = []
        i = 0
        merged_count = 0
        
        while i < len(ctx_messages):
            current = ctx_messages[i]
            
            # Try to merge with next messages of same role
            merged_content = [current.content]
            j = i + 1
            
            while j < len(ctx_messages):
                next_msg = ctx_messages[j]
                
                if next_msg.role != current.role:
                    break
                
                similarity = self._calculate_similarity(current.content, next_msg.content)
                if similarity >= similarity_threshold:
                    merged_content.append(next_msg.content)
                    merged_count += 1
                    j += 1
                else:
                    break
            
            # Create merged message
            if len(merged_content) > 1:
                # Combine content, removing duplicates
                unique_sentences = self._deduplicate_sentences(merged_content)
                combined_content = " ".join(unique_sentences)
                
                merged_msg = ContextMessage(
                    role=current.role,
                    content=combined_content,
                    name=current.name,
                    tool_call_id=current.tool_call_id,
                    metadata={**current.metadata, "merged_from": len(merged_content)},
                    timestamp=current.timestamp,
                    importance=max(m.importance for m in ctx_messages[i:j]),
                )
                merged_msg.estimate_tokens()
                merged.append(merged_msg)
            else:
                merged.append(current)
            
            i = j
        
        stats = ContextStats(
            original_messages=original_count,
            optimized_messages=len(merged),
            original_tokens=original_tokens,
            optimized_tokens=sum(m.token_count for m in merged),
            compressed_count=merged_count,
            operation_time_ms=(time.time() - start_time) * 1000,
            strategy_used="merge",
        )
        
        return CompressionResult(
            messages=merged,
            stats=stats,
            merged_count=merged_count,
        )
    
    def extract_key_points(
        self,
        messages: list[dict[str, Any]] | list[ContextMessage],
        max_points_per_message: int = 3,
    ) -> CompressionResult:
        """
        Extract key points from messages.
        
        Args:
            messages: Messages to extract from
            max_points_per_message: Maximum key points per message
            
        Returns:
            CompressionResult with extracted key points
        """
        start_time = time.time()
        ctx_messages = self._to_context_messages(messages)
        original_count = len(ctx_messages)
        original_tokens = sum(m.token_count for m in ctx_messages)
        
        extracted: list[ContextMessage] = []
        
        for msg in ctx_messages:
            # Extract key sentences/points
            key_points = self._extract_key_sentences(msg.content, max_points_per_message)
            
            if key_points:
                compressed_content = " • ".join(key_points)
                
                new_msg = ContextMessage(
                    role=msg.role,
                    content=compressed_content,
                    name=msg.name,
                    tool_call_id=msg.tool_call_id,
                    metadata={**msg.metadata, "extracted_points": len(key_points)},
                    timestamp=msg.timestamp,
                    importance=msg.importance,
                )
                new_msg.estimate_tokens()
                extracted.append(new_msg)
            else:
                # Keep original if no extraction possible
                extracted.append(msg)
        
        stats = ContextStats(
            original_messages=original_count,
            optimized_messages=len(extracted),
            original_tokens=original_tokens,
            optimized_tokens=sum(m.token_count for m in extracted),
            operation_time_ms=(time.time() - start_time) * 1000,
            strategy_used="extract_key_points",
        )
        
        return CompressionResult(messages=extracted, stats=stats)
    
    def truncate_messages(
        self,
        messages: list[dict[str, Any]] | list[ContextMessage],
        max_chars_per_message: int = 500,
        add_ellipsis: bool = True,
    ) -> CompressionResult:
        """
        Truncate long messages.
        
        Args:
            messages: Messages to truncate
            max_chars_per_message: Maximum characters per message
            add_ellipsis: Whether to add "..." to truncated messages
            
        Returns:
            CompressionResult with truncated messages
        """
        start_time = time.time()
        ctx_messages = self._to_context_messages(messages)
        original_count = len(ctx_messages)
        original_tokens = sum(m.token_count for m in ctx_messages)
        
        truncated: list[ContextMessage] = []
        truncated_count = 0
        
        for msg in ctx_messages:
            if len(msg.content) > max_chars_per_message:
                suffix = "..." if add_ellipsis else ""
                new_content = msg.content[:max_chars_per_message - len(suffix)] + suffix
                
                new_msg = ContextMessage(
                    role=msg.role,
                    content=new_content,
                    name=msg.name,
                    tool_call_id=msg.tool_call_id,
                    metadata={**msg.metadata, "truncated": True},
                    timestamp=msg.timestamp,
                    importance=msg.importance,
                )
                new_msg.estimate_tokens()
                truncated.append(new_msg)
                truncated_count += 1
            else:
                truncated.append(msg)
        
        stats = ContextStats(
            original_messages=original_count,
            optimized_messages=len(truncated),
            original_tokens=original_tokens,
            optimized_tokens=sum(m.token_count for m in truncated),
            compressed_count=truncated_count,
            operation_time_ms=(time.time() - start_time) * 1000,
            strategy_used="truncate",
        )
        
        return CompressionResult(messages=truncated, stats=stats)
    
    def _compress_by_summarization(
        self,
        messages: list[ContextMessage],
        target_tokens: int,
        preserve_recent: int,
    ) -> CompressionResult:
        """Compress by summarizing older messages."""
        original_count = len(messages)
        original_tokens = sum(m.token_count for m in messages)
        
        # Separate system, older, and recent messages
        system_msgs = [m for m in messages if m.role == "system"]
        non_system = [m for m in messages if m.role != "system"]
        
        recent = non_system[-preserve_recent:] if preserve_recent > 0 else []
        older = non_system[:-preserve_recent] if preserve_recent > 0 and len(non_system) > preserve_recent else []
        
        if not older:
            # Nothing to summarize
            stats = ContextStats(
                original_messages=original_count,
                optimized_messages=original_count,
                original_tokens=original_tokens,
                optimized_tokens=original_tokens,
                strategy_used="summarize",
            )
            return CompressionResult(messages=messages, stats=stats)
        
        # Summarize older messages
        if self.summarizer:
            older_contents = [m.content for m in older]
            summary = self.summarizer(older_contents)
        else:
            summary = self._simple_summarize(older, target_tokens // 4)
        
        # Create summary message
        summary_msg = ContextMessage(
            role="system",
            content=f"[Summary of previous conversation: {summary}]",
            metadata={"is_summary": True, "summarized_count": len(older)},
        )
        summary_msg.estimate_tokens()
        
        # Build result
        result_messages = system_msgs + [summary_msg] + recent
        
        stats = ContextStats(
            original_messages=original_count,
            optimized_messages=len(result_messages),
            original_tokens=original_tokens,
            optimized_tokens=sum(m.token_count for m in result_messages),
            compressed_count=len(older),
            strategy_used="summarize",
        )
        
        return CompressionResult(
            messages=result_messages,
            stats=stats,
            summaries=[summary],
        )
    
    def _compress_by_merging(
        self,
        messages: list[ContextMessage],
        target_tokens: int,
        preserve_recent: int,
    ) -> CompressionResult:
        """Compress by merging consecutive same-role messages."""
        original_count = len(messages)
        original_tokens = sum(m.token_count for m in messages)
        
        # Keep recent messages separate
        to_merge = messages[:-preserve_recent] if preserve_recent > 0 else messages
        recent = messages[-preserve_recent:] if preserve_recent > 0 else []
        
        # Merge consecutive messages with same role
        merged: list[ContextMessage] = []
        current_role = None
        current_contents: list[str] = []
        current_msg: Optional[ContextMessage] = None
        merged_count = 0
        
        for msg in to_merge:
            if msg.role == current_role and current_msg:
                current_contents.append(msg.content)
                merged_count += 1
            else:
                if current_msg and current_contents:
                    combined = "\n\n".join(current_contents)
                    final_msg = ContextMessage(
                        role=current_msg.role,
                        content=combined,
                        metadata={"merged_count": len(current_contents)},
                        timestamp=current_msg.timestamp,
                    )
                    final_msg.estimate_tokens()
                    merged.append(final_msg)
                
                current_role = msg.role
                current_contents = [msg.content]
                current_msg = msg
        
        # Don't forget the last group
        if current_msg and current_contents:
            combined = "\n\n".join(current_contents)
            final_msg = ContextMessage(
                role=current_msg.role,
                content=combined,
                metadata={"merged_count": len(current_contents)},
                timestamp=current_msg.timestamp,
            )
            final_msg.estimate_tokens()
            merged.append(final_msg)
        
        result_messages = merged + recent
        
        stats = ContextStats(
            original_messages=original_count,
            optimized_messages=len(result_messages),
            original_tokens=original_tokens,
            optimized_tokens=sum(m.token_count for m in result_messages),
            compressed_count=merged_count,
            strategy_used="merge",
        )
        
        return CompressionResult(
            messages=result_messages,
            stats=stats,
            merged_count=merged_count,
        )
    
    def _compress_by_extraction(
        self,
        messages: list[ContextMessage],
        target_tokens: int,
        preserve_recent: int,
    ) -> CompressionResult:
        """Compress by extracting key points from older messages."""
        original_count = len(messages)
        original_tokens = sum(m.token_count for m in messages)
        
        # Keep recent messages unchanged
        to_compress = messages[:-preserve_recent] if preserve_recent > 0 else messages
        recent = messages[-preserve_recent:] if preserve_recent > 0 else []
        
        compressed: list[ContextMessage] = []
        
        for msg in to_compress:
            key_points = self._extract_key_sentences(msg.content, 2)
            if key_points:
                new_content = " • ".join(key_points)
                new_msg = ContextMessage(
                    role=msg.role,
                    content=new_content,
                    metadata={**msg.metadata, "compressed": True},
                    timestamp=msg.timestamp,
                )
                new_msg.estimate_tokens()
                compressed.append(new_msg)
            else:
                compressed.append(msg)
        
        result_messages = compressed + recent
        
        stats = ContextStats(
            original_messages=original_count,
            optimized_messages=len(result_messages),
            original_tokens=original_tokens,
            optimized_tokens=sum(m.token_count for m in result_messages),
            strategy_used="extract_key_points",
        )
        
        return CompressionResult(messages=result_messages, stats=stats)
    
    def _compress_hierarchically(
        self,
        messages: list[ContextMessage],
        target_tokens: int,
        preserve_recent: int,
    ) -> CompressionResult:
        """Compress with hierarchical summarization."""
        original_count = len(messages)
        original_tokens = sum(m.token_count for m in messages)
        
        # Divide into chunks
        chunk_size = 5
        system_msgs = [m for m in messages if m.role == "system"]
        non_system = [m for m in messages if m.role != "system"]
        
        recent = non_system[-preserve_recent:] if preserve_recent > 0 else []
        to_summarize = non_system[:-preserve_recent] if preserve_recent > 0 else []
        
        if not to_summarize:
            stats = ContextStats(
                original_messages=original_count,
                optimized_messages=original_count,
                original_tokens=original_tokens,
                optimized_tokens=original_tokens,
                strategy_used="hierarchical",
            )
            return CompressionResult(messages=messages, stats=stats)
        
        # Create chunk summaries
        chunks = [to_summarize[i:i + chunk_size] for i in range(0, len(to_summarize), chunk_size)]
        summaries: list[str] = []
        
        for chunk in chunks:
            if self.summarizer:
                chunk_contents = [m.content for m in chunk]
                summary = self.summarizer(chunk_contents)
            else:
                summary = self._simple_summarize(chunk, 50)
            summaries.append(summary)
        
        # Create hierarchical summary message
        combined_summary = " | ".join(summaries)
        summary_msg = ContextMessage(
            role="system",
            content=f"[Conversation history: {combined_summary}]",
            metadata={"is_hierarchical_summary": True, "chunk_count": len(chunks)},
        )
        summary_msg.estimate_tokens()
        
        result_messages = system_msgs + [summary_msg] + recent
        
        stats = ContextStats(
            original_messages=original_count,
            optimized_messages=len(result_messages),
            original_tokens=original_tokens,
            optimized_tokens=sum(m.token_count for m in result_messages),
            compressed_count=len(to_summarize),
            strategy_used="hierarchical",
        )
        
        return CompressionResult(
            messages=result_messages,
            stats=stats,
            summaries=summaries,
        )
    
    def _simple_summarize(
        self,
        messages: list[ContextMessage],
        max_tokens: int,
    ) -> str:
        """Simple extractive summarization without external API."""
        # Extract first sentence from each message
        sentences: list[str] = []
        
        for msg in messages:
            # Get first sentence
            first_sentence = self._get_first_sentence(msg.content)
            if first_sentence:
                sentences.append(first_sentence)
        
        # Combine and truncate
        combined = ". ".join(sentences)
        max_chars = max_tokens * 4  # Approximate chars from tokens
        
        if len(combined) > max_chars:
            combined = combined[:max_chars - 3] + "..."
        
        return combined
    
    def _get_first_sentence(self, text: str) -> str:
        """Extract first sentence from text."""
        # Split by sentence-ending punctuation
        match = re.match(r'^(.+?[.!?])\s', text + " ")
        if match:
            return match.group(1).strip()
        
        # If no sentence ending, take first 100 chars
        return text[:100].strip() if len(text) > 100 else text.strip()
    
    def _extract_key_sentences(
        self,
        text: str,
        max_sentences: int,
    ) -> list[str]:
        """Extract key sentences from text."""
        # Split into sentences
        sentences = re.split(r'(?<=[.!?])\s+', text)
        
        if len(sentences) <= max_sentences:
            return sentences
        
        # Score sentences by various factors
        scored: list[tuple[str, float]] = []
        
        for sentence in sentences:
            score = 0.0
            
            # Length score (prefer medium-length sentences)
            length = len(sentence)
            if 20 < length < 200:
                score += 1.0
            elif length > 10:
                score += 0.5
            
            # Key phrases
            key_phrases = ["important", "key", "main", "summary", "conclusion", "result"]
            for phrase in key_phrases:
                if phrase in sentence.lower():
                    score += 0.5
            
            # Position (first and last sentences often important)
            if sentence == sentences[0]:
                score += 0.3
            if sentence == sentences[-1]:
                score += 0.3
            
            scored.append((sentence, score))
        
        # Sort by score and take top
        scored.sort(key=lambda x: x[1], reverse=True)
        
        return [s for s, _ in scored[:max_sentences]]
    
    def _calculate_similarity(self, text1: str, text2: str) -> float:
        """Calculate Jaccard similarity between two texts."""
        words1 = set(text1.lower().split())
        words2 = set(text2.lower().split())
        
        if not words1 and not words2:
            return 1.0
        if not words1 or not words2:
            return 0.0
        
        intersection = len(words1 & words2)
        union = len(words1 | words2)
        
        return intersection / union
    
    def _deduplicate_sentences(self, contents: list[str]) -> list[str]:
        """Remove duplicate sentences across contents."""
        seen: set[str] = set()
        unique: list[str] = []
        
        for content in contents:
            sentences = re.split(r'(?<=[.!?])\s+', content)
            for sentence in sentences:
                normalized = sentence.lower().strip()
                if normalized and normalized not in seen:
                    seen.add(normalized)
                    unique.append(sentence.strip())
        
        return unique
    
    def _compress_tool_descriptions(
        self,
        tools: list[ToolContext],
        max_tokens: int,
    ) -> list[ToolContext]:
        """Compress tool descriptions to fit within limit."""
        result: list[ToolContext] = []
        current_tokens = 0
        
        for tool in tools:
            # Truncate description if needed
            max_desc_chars = 100
            if len(tool.description) > max_desc_chars:
                compressed = ToolContext(
                    name=tool.name,
                    description=tool.description[:max_desc_chars] + "...",
                    parameters=tool.parameters,
                    usage_count=tool.usage_count,
                    importance=tool.importance,
                )
                compressed.estimate_tokens()
            else:
                compressed = tool
            
            if current_tokens + compressed.token_count <= max_tokens:
                result.append(compressed)
                current_tokens += compressed.token_count
        
        return result
    
    def _to_context_messages(
        self,
        messages: list[dict[str, Any]] | list[ContextMessage]
    ) -> list[ContextMessage]:
        """Convert to list of ContextMessage."""
        result: list[ContextMessage] = []
        
        for msg in messages:
            if isinstance(msg, ContextMessage):
                if msg.token_count == 0:
                    msg.estimate_tokens()
                result.append(msg)
            else:
                ctx_msg = ContextMessage.from_dict(msg)
                ctx_msg.estimate_tokens()
                result.append(ctx_msg)
        
        return result
    
    def _to_tool_contexts(
        self,
        tools: list[dict[str, Any]] | list[ToolContext]
    ) -> list[ToolContext]:
        """Convert tool definitions to ToolContext."""
        contexts: list[ToolContext] = []
        
        for tool in tools:
            if isinstance(tool, ToolContext):
                contexts.append(tool)
            else:
                func = tool.get("function", tool)
                ctx = ToolContext(
                    name=func.get("name", ""),
                    description=func.get("description", ""),
                    parameters=func.get("parameters", {}),
                )
                ctx.estimate_tokens()
                contexts.append(ctx)
        
        return contexts
