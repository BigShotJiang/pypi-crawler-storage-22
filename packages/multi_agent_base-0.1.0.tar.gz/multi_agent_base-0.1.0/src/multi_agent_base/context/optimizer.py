"""
Context Optimizer

Main optimizer class that coordinates pruning and compression operations.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Callable, Optional

from .types import (
    CompressionMethod,
    ContextMessage,
    ContextSnapshot,
    ContextStats,
    ContextWindow,
    MessageRole,
    OptimizationConfig,
    PruningStrategy,
    ToolContext,
)


@dataclass
class OptimizationResult:
    """
    Result of context optimization.
    
    Attributes:
        window: Optimized context window
        stats: Optimization statistics
        summary: Optional summary of pruned content
        snapshots: History of optimization steps
    """
    
    window: ContextWindow
    stats: ContextStats
    summary: Optional[str] = None
    snapshots: list[ContextSnapshot] = field(default_factory=list)
    
    @property
    def messages(self) -> list[ContextMessage]:
        """Get optimized messages."""
        return self.window.messages
    
    def to_list(self) -> list[dict[str, Any]]:
        """Convert messages to list of dictionaries."""
        return self.window.to_list()


class ContextOptimizer:
    """
    Main context optimization orchestrator.
    
    Coordinates pruning, compression, and summarization to fit
    context within token limits while preserving important information.
    
    Attributes:
        config: Optimization configuration
        summarizer: Optional function for summarizing content
        embedder: Optional function for generating embeddings
    
    Example:
        >>> optimizer = ContextOptimizer(
        ...     config=OptimizationConfig(max_tokens=4096)
        ... )
        >>> messages = [
        ...     {"role": "system", "content": "You are helpful."},
        ...     {"role": "user", "content": "Hello!"},
        ...     {"role": "assistant", "content": "Hi there!"},
        ... ]
        >>> result = optimizer.optimize(messages)
        >>> print(result.stats.tokens_saved)
    """
    
    def __init__(
        self,
        config: Optional[OptimizationConfig] = None,
        summarizer: Optional[Callable[[list[str]], str]] = None,
        embedder: Optional[Callable[[str], list[float]]] = None,
    ) -> None:
        """
        Initialize the context optimizer.
        
        Args:
            config: Optimization configuration
            summarizer: Function to summarize a list of message contents
            embedder: Function to generate embeddings for semantic similarity
        """
        self.config = config or OptimizationConfig()
        self.summarizer = summarizer
        self.embedder = embedder
        self._snapshots: list[ContextSnapshot] = []
    
    def optimize(
        self,
        messages: list[dict[str, Any]] | list[ContextMessage] | ContextWindow,
        query: Optional[str] = None,
        max_tokens: Optional[int] = None,
    ) -> OptimizationResult:
        """
        Optimize context to fit within token limits.
        
        Args:
            messages: Input messages in various formats
            query: Optional query for relevance-based pruning
            max_tokens: Override max tokens from config
            
        Returns:
            OptimizationResult with optimized context and stats
        """
        start_time = time.time()
        self._snapshots = []
        
        # Convert to ContextWindow
        window = self._to_window(messages)
        original_tokens = window.current_tokens
        original_count = len(window)
        
        # Take initial snapshot
        self._take_snapshot(window, "initial")
        
        # Determine target tokens
        target_tokens = max_tokens or self.config.max_tokens
        
        # If already within limit, return early
        if window.current_tokens <= target_tokens:
            stats = ContextStats(
                original_messages=original_count,
                optimized_messages=len(window),
                original_tokens=original_tokens,
                optimized_tokens=window.current_tokens,
                operation_time_ms=(time.time() - start_time) * 1000,
                strategy_used="none_needed",
            )
            return OptimizationResult(
                window=window,
                stats=stats,
                snapshots=self._snapshots,
            )
        
        # Apply optimization based on strategy
        summary = None
        if self.config.pruning_strategy == PruningStrategy.RECENCY:
            window = self._prune_by_recency(window, target_tokens)
        elif self.config.pruning_strategy == PruningStrategy.RELEVANCE:
            window = self._prune_by_relevance(window, target_tokens, query)
        elif self.config.pruning_strategy == PruningStrategy.IMPORTANCE:
            window = self._prune_by_importance(window, target_tokens)
        elif self.config.pruning_strategy == PruningStrategy.SLIDING_WINDOW:
            window = self._apply_sliding_window(window, target_tokens)
        else:  # SMART strategy
            window, summary = self._apply_smart_optimization(
                window, target_tokens, query
            )
        
        # Take final snapshot
        self._take_snapshot(window, "final")
        
        # Calculate stats
        stats = ContextStats(
            original_messages=original_count,
            optimized_messages=len(window),
            original_tokens=original_tokens,
            optimized_tokens=window.current_tokens,
            pruned_count=original_count - len(window),
            operation_time_ms=(time.time() - start_time) * 1000,
            strategy_used=self.config.pruning_strategy.value,
        )
        
        return OptimizationResult(
            window=window,
            stats=stats,
            summary=summary,
            snapshots=self._snapshots,
        )
    
    def optimize_with_tools(
        self,
        messages: list[dict[str, Any]] | list[ContextMessage] | ContextWindow,
        tools: list[dict[str, Any]] | list[ToolContext],
        max_tokens: Optional[int] = None,
    ) -> tuple[OptimizationResult, list[ToolContext]]:
        """
        Optimize both messages and tools to fit within token limits.
        
        Args:
            messages: Input messages
            tools: Tool definitions
            max_tokens: Override max tokens from config
            
        Returns:
            Tuple of (optimization result, optimized tools)
        """
        # Convert tools to ToolContext
        tool_contexts = self._to_tool_contexts(tools)
        
        # Estimate tool tokens
        tool_tokens = sum(t.estimate_tokens() for t in tool_contexts)
        
        # Calculate message budget
        target_tokens = max_tokens or self.config.max_tokens
        message_budget = target_tokens - tool_tokens
        
        # If tools take too much space, prune them too
        if message_budget < target_tokens * 0.5:
            # Keep at most 50% for tools
            max_tool_tokens = target_tokens // 2
            tool_contexts = self._prune_tools(tool_contexts, max_tool_tokens)
            tool_tokens = sum(t.token_count for t in tool_contexts)
            message_budget = target_tokens - tool_tokens
        
        # Optimize messages with reduced budget
        result = self.optimize(messages, max_tokens=message_budget)
        
        return result, tool_contexts
    
    def _to_window(
        self,
        messages: list[dict[str, Any]] | list[ContextMessage] | ContextWindow
    ) -> ContextWindow:
        """Convert various message formats to ContextWindow."""
        if isinstance(messages, ContextWindow):
            return messages
        
        window = ContextWindow(max_tokens=self.config.max_tokens)
        
        for msg in messages:
            if isinstance(msg, ContextMessage):
                window.add_message(msg)
            else:
                ctx_msg = ContextMessage.from_dict(msg)
                window.add_message(ctx_msg)
        
        window.recalculate_tokens()
        return window
    
    def _to_tool_contexts(
        self,
        tools: list[dict[str, Any]] | list[ToolContext]
    ) -> list[ToolContext]:
        """Convert tool definitions to ToolContext."""
        contexts = []
        
        for tool in tools:
            if isinstance(tool, ToolContext):
                contexts.append(tool)
            else:
                # Parse OpenAI format
                func = tool.get("function", tool)
                contexts.append(ToolContext(
                    name=func.get("name", ""),
                    description=func.get("description", ""),
                    parameters=func.get("parameters", {}),
                ))
        
        return contexts
    
    def _take_snapshot(self, window: ContextWindow, operation: str) -> None:
        """Take a snapshot of current state."""
        # Create a copy of the window
        snapshot_window = ContextWindow(
            messages=list(window.messages),
            max_tokens=window.max_tokens,
            current_tokens=window.current_tokens,
        )
        snapshot = ContextSnapshot(
            window=snapshot_window,
            operation=operation,
        )
        self._snapshots.append(snapshot)
    
    def _prune_by_recency(
        self,
        window: ContextWindow,
        target_tokens: int
    ) -> ContextWindow:
        """
        Prune by keeping most recent messages.
        
        Preserves system messages and most recent user/assistant messages.
        """
        # Separate system and other messages
        system_msgs = [m for m in window.messages if m.role == "system"]
        other_msgs = [m for m in window.messages if m.role != "system"]
        
        # Calculate available tokens after system messages
        system_tokens = sum(m.token_count for m in system_msgs)
        available = target_tokens - system_tokens
        
        # Keep messages from the end until we hit the limit
        kept_msgs: list[ContextMessage] = []
        current_tokens = 0
        
        # Always preserve recent messages as configured
        preserve_count = min(self.config.preserve_recent, len(other_msgs))
        for msg in reversed(other_msgs):
            if current_tokens + msg.token_count <= available:
                kept_msgs.insert(0, msg)
                current_tokens += msg.token_count
            elif len(kept_msgs) < preserve_count:
                # Must keep minimum recent messages
                kept_msgs.insert(0, msg)
                current_tokens += msg.token_count
            else:
                break
        
        # Create new window
        result = ContextWindow(max_tokens=target_tokens)
        for msg in system_msgs:
            result.add_message(msg)
        for msg in kept_msgs:
            result.add_message(msg)
        
        result.recalculate_tokens()
        self._take_snapshot(result, "prune_recency")
        
        return result
    
    def _prune_by_relevance(
        self,
        window: ContextWindow,
        target_tokens: int,
        query: Optional[str] = None
    ) -> ContextWindow:
        """
        Prune by relevance to query.
        
        Uses embeddings if available, falls back to keyword matching.
        """
        # Calculate relevance scores
        if query and self.embedder:
            query_embedding = self.embedder(query)
            for msg in window.messages:
                if msg.embedding is None:
                    msg.embedding = self.embedder(msg.content)
                # Calculate cosine similarity
                score = self._cosine_similarity(query_embedding, msg.embedding)
                msg.relevance_scores[query] = score
        elif query:
            # Fallback: keyword matching
            query_words = set(query.lower().split())
            for msg in window.messages:
                msg_words = set(msg.content.lower().split())
                overlap = len(query_words & msg_words)
                score = overlap / len(query_words) if query_words else 0
                msg.relevance_scores[query] = score
        
        # Sort by relevance (keep high scores)
        system_msgs = [m for m in window.messages if m.role == "system"]
        other_msgs = [m for m in window.messages if m.role != "system"]
        
        if query:
            other_msgs.sort(
                key=lambda m: m.relevance_scores.get(query, 0),
                reverse=True
            )
        
        # Keep messages above threshold or until token limit
        system_tokens = sum(m.token_count for m in system_msgs)
        available = target_tokens - system_tokens
        
        kept_msgs: list[ContextMessage] = []
        current_tokens = 0
        
        for msg in other_msgs:
            score = msg.relevance_scores.get(query, 0.5) if query else 0.5
            if score >= self.config.relevance_threshold:
                if current_tokens + msg.token_count <= available:
                    kept_msgs.append(msg)
                    current_tokens += msg.token_count
        
        # Ensure minimum messages
        if len(kept_msgs) < self.config.min_messages:
            for msg in other_msgs:
                if msg not in kept_msgs:
                    kept_msgs.append(msg)
                    if len(kept_msgs) >= self.config.min_messages:
                        break
        
        # Sort by original order (timestamp)
        kept_msgs.sort(key=lambda m: m.timestamp)
        
        # Create new window
        result = ContextWindow(max_tokens=target_tokens)
        for msg in system_msgs:
            result.add_message(msg)
        for msg in kept_msgs:
            result.add_message(msg)
        
        result.recalculate_tokens()
        self._take_snapshot(result, "prune_relevance")
        
        return result
    
    def _prune_by_importance(
        self,
        window: ContextWindow,
        target_tokens: int
    ) -> ContextWindow:
        """
        Prune by importance score.
        
        Uses message importance attribute.
        """
        # Assign default importance based on role
        for msg in window.messages:
            if msg.importance == 0.5:  # Default value
                if msg.role == "system":
                    msg.importance = 1.0
                elif msg.role == "user":
                    msg.importance = 0.7
                elif msg.role == "assistant":
                    msg.importance = 0.6
                else:
                    msg.importance = 0.4
        
        # Sort by importance
        system_msgs = [m for m in window.messages if m.role == "system"]
        other_msgs = [m for m in window.messages if m.role != "system"]
        other_msgs.sort(key=lambda m: m.importance, reverse=True)
        
        # Keep messages above threshold or until token limit
        system_tokens = sum(m.token_count for m in system_msgs)
        available = target_tokens - system_tokens
        
        kept_msgs: list[ContextMessage] = []
        current_tokens = 0
        
        for msg in other_msgs:
            if msg.importance >= self.config.importance_threshold:
                if current_tokens + msg.token_count <= available:
                    kept_msgs.append(msg)
                    current_tokens += msg.token_count
        
        # Ensure minimum messages
        if len(kept_msgs) < self.config.min_messages:
            for msg in other_msgs:
                if msg not in kept_msgs:
                    kept_msgs.append(msg)
                    if len(kept_msgs) >= self.config.min_messages:
                        break
        
        # Sort by original order
        kept_msgs.sort(key=lambda m: m.timestamp)
        
        # Create new window
        result = ContextWindow(max_tokens=target_tokens)
        for msg in system_msgs:
            result.add_message(msg)
        for msg in kept_msgs:
            result.add_message(msg)
        
        result.recalculate_tokens()
        self._take_snapshot(result, "prune_importance")
        
        return result
    
    def _apply_sliding_window(
        self,
        window: ContextWindow,
        target_tokens: int
    ) -> ContextWindow:
        """
        Apply sliding window from the end.
        
        Simply keeps the most recent messages that fit.
        """
        # Keep system messages
        system_msgs = [m for m in window.messages if m.role == "system"]
        other_msgs = [m for m in window.messages if m.role != "system"]
        
        system_tokens = sum(m.token_count for m in system_msgs)
        available = target_tokens - system_tokens
        
        # Take from end
        kept_msgs: list[ContextMessage] = []
        current_tokens = 0
        
        for msg in reversed(other_msgs):
            if current_tokens + msg.token_count <= available:
                kept_msgs.insert(0, msg)
                current_tokens += msg.token_count
            else:
                break
        
        # Create new window
        result = ContextWindow(max_tokens=target_tokens)
        for msg in system_msgs:
            result.add_message(msg)
        for msg in kept_msgs:
            result.add_message(msg)
        
        result.recalculate_tokens()
        self._take_snapshot(result, "sliding_window")
        
        return result
    
    def _apply_smart_optimization(
        self,
        window: ContextWindow,
        target_tokens: int,
        query: Optional[str] = None
    ) -> tuple[ContextWindow, Optional[str]]:
        """
        Apply smart optimization combining multiple strategies.
        
        1. Preserve system messages
        2. Preserve recent messages
        3. Score messages by importance + relevance
        4. Optionally summarize removed content
        """
        # Separate messages
        system_msgs = [m for m in window.messages if m.role == "system"]
        other_msgs = [m for m in window.messages if m.role != "system"]
        
        # Calculate scores (importance + recency + relevance)
        for i, msg in enumerate(other_msgs):
            # Recency score (higher for more recent)
            recency_score = i / len(other_msgs) if other_msgs else 0
            
            # Importance score
            importance_score = msg.importance
            
            # Relevance score
            if query:
                query_words = set(query.lower().split())
                msg_words = set(msg.content.lower().split())
                relevance_score = len(query_words & msg_words) / len(query_words) if query_words else 0
            else:
                relevance_score = 0.5
            
            # Combined score
            combined = (
                recency_score * 0.4 +
                importance_score * 0.3 +
                relevance_score * 0.3
            )
            msg.metadata["combined_score"] = combined
        
        # Protect recent messages
        recent_msgs = other_msgs[-self.config.preserve_recent:] if self.config.preserve_recent > 0 else []
        candidate_msgs = other_msgs[:-self.config.preserve_recent] if self.config.preserve_recent > 0 else other_msgs
        
        # Sort candidates by score
        candidate_msgs.sort(
            key=lambda m: m.metadata.get("combined_score", 0),
            reverse=True
        )
        
        # Calculate budget
        system_tokens = sum(m.token_count for m in system_msgs)
        recent_tokens = sum(m.token_count for m in recent_msgs)
        available = target_tokens - system_tokens - recent_tokens
        
        # Keep top scoring candidates that fit
        kept_candidates: list[ContextMessage] = []
        pruned_msgs: list[ContextMessage] = []
        current_tokens = 0
        
        for msg in candidate_msgs:
            if current_tokens + msg.token_count <= available:
                kept_candidates.append(msg)
                current_tokens += msg.token_count
            else:
                pruned_msgs.append(msg)
        
        # Generate summary of pruned content if enabled
        summary = None
        if pruned_msgs and self.config.enable_summarization and self.summarizer:
            pruned_contents = [m.content for m in pruned_msgs]
            summary = self.summarizer(pruned_contents)
        
        # Sort kept candidates by original order
        kept_candidates.sort(key=lambda m: m.timestamp)
        
        # Create new window
        result = ContextWindow(max_tokens=target_tokens)
        
        # Add in order: system, kept candidates, recent
        for msg in system_msgs:
            result.add_message(msg)
        
        # Add summary as a system message if available
        if summary:
            summary_msg = ContextMessage(
                role="system",
                content=f"[Summary of earlier conversation: {summary}]",
            )
            summary_msg.estimate_tokens()
            result.add_message(summary_msg)
        
        for msg in kept_candidates:
            result.add_message(msg)
        for msg in recent_msgs:
            result.add_message(msg)
        
        result.recalculate_tokens()
        self._take_snapshot(result, "smart_optimization")
        
        return result, summary
    
    def _prune_tools(
        self,
        tools: list[ToolContext],
        max_tokens: int
    ) -> list[ToolContext]:
        """
        Prune tools to fit within token limit.
        
        Keeps most used/important tools.
        """
        # Sort by usage and importance
        tools.sort(
            key=lambda t: (t.usage_count, t.importance),
            reverse=True
        )
        
        kept_tools: list[ToolContext] = []
        current_tokens = 0
        
        for tool in tools:
            if current_tokens + tool.token_count <= max_tokens:
                kept_tools.append(tool)
                current_tokens += tool.token_count
        
        return kept_tools
    
    def _cosine_similarity(
        self,
        vec1: list[float],
        vec2: list[float]
    ) -> float:
        """Calculate cosine similarity between two vectors."""
        if not vec1 or not vec2 or len(vec1) != len(vec2):
            return 0.0
        
        dot_product = sum(a * b for a, b in zip(vec1, vec2))
        norm1 = sum(a * a for a in vec1) ** 0.5
        norm2 = sum(b * b for b in vec2) ** 0.5
        
        if norm1 == 0 or norm2 == 0:
            return 0.0
        
        return dot_product / (norm1 * norm2)
    
    def get_snapshots(self) -> list[ContextSnapshot]:
        """Get optimization snapshots for debugging."""
        return self._snapshots.copy()


class TokenEstimator:
    """
    Utility for estimating token counts.
    
    Provides various estimation methods for different accuracy/speed tradeoffs.
    """
    
    # Average characters per token for different models
    CHAR_PER_TOKEN = {
        "gpt-4": 4,
        "gpt-3.5-turbo": 4,
        "claude": 3.5,
        "default": 4,
    }
    
    @classmethod
    def estimate_simple(cls, text: str, model: str = "default") -> int:
        """
        Simple character-based estimation.
        
        Args:
            text: Text to estimate
            model: Model name for calibration
            
        Returns:
            Estimated token count
        """
        chars_per_token = cls.CHAR_PER_TOKEN.get(model, cls.CHAR_PER_TOKEN["default"])
        return int(len(text) / chars_per_token) + 1
    
    @classmethod
    def estimate_words(cls, text: str) -> int:
        """
        Word-based estimation (~1.3 tokens per word).
        
        Args:
            text: Text to estimate
            
        Returns:
            Estimated token count
        """
        words = len(text.split())
        return int(words * 1.3) + 1
    
    @classmethod
    def estimate_messages(
        cls,
        messages: list[dict[str, Any]],
        model: str = "default"
    ) -> int:
        """
        Estimate tokens for a list of messages.
        
        Args:
            messages: List of message dictionaries
            model: Model name for calibration
            
        Returns:
            Estimated total token count
        """
        total = 0
        
        for msg in messages:
            # Base overhead per message (~4 tokens)
            total += 4
            
            # Content tokens
            content = msg.get("content", "")
            if content:
                total += cls.estimate_simple(content, model)
            
            # Role overhead (~1 token)
            total += 1
            
            # Name overhead if present
            if msg.get("name"):
                total += cls.estimate_simple(msg["name"], model)
        
        # Reply priming (~3 tokens)
        total += 3
        
        return total
    
    @classmethod
    def estimate_tool(cls, tool: dict[str, Any]) -> int:
        """
        Estimate tokens for a tool definition.
        
        Args:
            tool: Tool definition dictionary
            
        Returns:
            Estimated token count
        """
        import json
        
        func = tool.get("function", tool)
        name = func.get("name", "")
        description = func.get("description", "")
        parameters = func.get("parameters", {})
        
        total = cls.estimate_simple(name) + cls.estimate_simple(description)
        total += cls.estimate_simple(json.dumps(parameters))
        
        # Overhead for structure
        total += 10
        
        return total
