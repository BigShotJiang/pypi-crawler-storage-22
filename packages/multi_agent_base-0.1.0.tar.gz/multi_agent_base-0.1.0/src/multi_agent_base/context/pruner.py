"""
Context Pruner

Specialized pruning strategies for context management.
"""

from __future__ import annotations

import re
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Optional

from .types import (
    ContextMessage,
    ContextStats,
    ContextWindow,
    MessageRole,
    PruningStrategy,
)


@dataclass
class PruningResult:
    """
    Result of a pruning operation.
    
    Attributes:
        kept: Messages that were kept
        pruned: Messages that were removed
        stats: Pruning statistics
    """
    
    kept: list[ContextMessage]
    pruned: list[ContextMessage]
    stats: ContextStats
    
    @property
    def kept_count(self) -> int:
        """Number of kept messages."""
        return len(self.kept)
    
    @property
    def pruned_count(self) -> int:
        """Number of pruned messages."""
        return len(self.pruned)


class ContextPruner:
    """
    Specialized context pruning utilities.
    
    Provides granular control over message pruning with various
    strategies and filters.
    
    Example:
        >>> pruner = ContextPruner()
        >>> messages = [...] # list of messages
        >>> result = pruner.prune_by_recency(messages, keep_count=10)
        >>> print(f"Kept {result.kept_count}, pruned {result.pruned_count}")
    """
    
    def __init__(
        self,
        preserve_system: bool = True,
        preserve_tool_pairs: bool = True,
        min_messages: int = 1,
    ) -> None:
        """
        Initialize the pruner.
        
        Args:
            preserve_system: Whether to always preserve system messages
            preserve_tool_pairs: Whether to keep tool call/result pairs together
            min_messages: Minimum messages to keep
        """
        self.preserve_system = preserve_system
        self.preserve_tool_pairs = preserve_tool_pairs
        self.min_messages = min_messages
    
    def prune_by_recency(
        self,
        messages: list[dict[str, Any]] | list[ContextMessage],
        keep_count: int = 10,
        preserve_recent: int = 3,
    ) -> PruningResult:
        """
        Prune messages keeping most recent.
        
        Args:
            messages: Messages to prune
            keep_count: Maximum messages to keep
            preserve_recent: Guaranteed recent messages to keep
            
        Returns:
            PruningResult with kept and pruned messages
        """
        start_time = time.time()
        ctx_messages = self._to_context_messages(messages)
        original_count = len(ctx_messages)
        original_tokens = sum(m.token_count for m in ctx_messages)
        
        # Separate system messages
        system_msgs, other_msgs = self._separate_system(ctx_messages)
        
        # Calculate how many non-system messages to keep
        available_slots = keep_count - len(system_msgs)
        
        if available_slots <= 0:
            # Only keep system messages
            kept = system_msgs[:keep_count]
            pruned = system_msgs[keep_count:] + other_msgs
        elif len(other_msgs) <= available_slots:
            # Keep all messages
            kept = system_msgs + other_msgs
            pruned = []
        else:
            # Keep recent messages
            preserve_count = min(preserve_recent, available_slots)
            recent = other_msgs[-preserve_count:] if preserve_count > 0 else []
            
            # Fill remaining slots from earlier messages
            remaining_slots = available_slots - len(recent)
            earlier = other_msgs[-available_slots:-preserve_count] if remaining_slots > 0 else []
            
            kept = system_msgs + earlier + recent
            pruned = [m for m in other_msgs if m not in kept]
        
        stats = ContextStats(
            original_messages=original_count,
            optimized_messages=len(kept),
            original_tokens=original_tokens,
            optimized_tokens=sum(m.token_count for m in kept),
            pruned_count=len(pruned),
            operation_time_ms=(time.time() - start_time) * 1000,
            strategy_used="recency",
        )
        
        return PruningResult(kept=kept, pruned=pruned, stats=stats)
    
    def prune_by_relevance(
        self,
        messages: list[dict[str, Any]] | list[ContextMessage],
        query: str,
        keep_count: int = 10,
        scorer: Optional[Callable[[str, str], float]] = None,
    ) -> PruningResult:
        """
        Prune messages by relevance to a query.
        
        Args:
            messages: Messages to prune
            query: Query to measure relevance against
            keep_count: Maximum messages to keep
            scorer: Optional custom scoring function(query, content) -> score
            
        Returns:
            PruningResult with kept and pruned messages
        """
        start_time = time.time()
        ctx_messages = self._to_context_messages(messages)
        original_count = len(ctx_messages)
        original_tokens = sum(m.token_count for m in ctx_messages)
        
        # Use provided scorer or default keyword matching
        score_func = scorer or self._default_relevance_scorer
        
        # Score messages
        for msg in ctx_messages:
            if msg.role != "system":  # Don't score system messages
                score = score_func(query, msg.content)
                msg.relevance_scores[query] = score
        
        # Separate system messages
        system_msgs, other_msgs = self._separate_system(ctx_messages)
        
        # Sort by relevance
        other_msgs.sort(
            key=lambda m: m.relevance_scores.get(query, 0),
            reverse=True
        )
        
        # Keep top messages
        available_slots = keep_count - len(system_msgs)
        kept_other = other_msgs[:max(0, available_slots)]
        pruned_other = other_msgs[max(0, available_slots):]
        
        # Restore original order
        kept_other.sort(key=lambda m: m.timestamp)
        
        kept = system_msgs + kept_other
        pruned = pruned_other
        
        stats = ContextStats(
            original_messages=original_count,
            optimized_messages=len(kept),
            original_tokens=original_tokens,
            optimized_tokens=sum(m.token_count for m in kept),
            pruned_count=len(pruned),
            operation_time_ms=(time.time() - start_time) * 1000,
            strategy_used="relevance",
        )
        
        return PruningResult(kept=kept, pruned=pruned, stats=stats)
    
    def prune_by_token_limit(
        self,
        messages: list[dict[str, Any]] | list[ContextMessage],
        max_tokens: int,
        strategy: PruningStrategy = PruningStrategy.RECENCY,
    ) -> PruningResult:
        """
        Prune messages to fit within token limit.
        
        Args:
            messages: Messages to prune
            max_tokens: Maximum tokens to keep
            strategy: Strategy for deciding what to prune
            
        Returns:
            PruningResult with kept and pruned messages
        """
        start_time = time.time()
        ctx_messages = self._to_context_messages(messages)
        original_count = len(ctx_messages)
        original_tokens = sum(m.token_count for m in ctx_messages)
        
        # If already within limit, return all
        if original_tokens <= max_tokens:
            stats = ContextStats(
                original_messages=original_count,
                optimized_messages=original_count,
                original_tokens=original_tokens,
                optimized_tokens=original_tokens,
                operation_time_ms=(time.time() - start_time) * 1000,
                strategy_used="none_needed",
            )
            return PruningResult(kept=ctx_messages, pruned=[], stats=stats)
        
        # Separate system messages
        system_msgs, other_msgs = self._separate_system(ctx_messages)
        system_tokens = sum(m.token_count for m in system_msgs)
        
        if system_tokens >= max_tokens:
            # Can only fit some system messages
            kept = []
            current_tokens = 0
            for msg in system_msgs:
                if current_tokens + msg.token_count <= max_tokens:
                    kept.append(msg)
                    current_tokens += msg.token_count
            pruned = [m for m in ctx_messages if m not in kept]
        else:
            # Room for system + some other messages
            available_tokens = max_tokens - system_tokens
            
            if strategy == PruningStrategy.RECENCY:
                # Keep from the end
                kept_other: list[ContextMessage] = []
                current_tokens = 0
                for msg in reversed(other_msgs):
                    if current_tokens + msg.token_count <= available_tokens:
                        kept_other.insert(0, msg)
                        current_tokens += msg.token_count
                    else:
                        break
            elif strategy == PruningStrategy.IMPORTANCE:
                # Sort by importance and keep top
                sorted_msgs = sorted(other_msgs, key=lambda m: m.importance, reverse=True)
                kept_other = []
                current_tokens = 0
                for msg in sorted_msgs:
                    if current_tokens + msg.token_count <= available_tokens:
                        kept_other.append(msg)
                        current_tokens += msg.token_count
                # Restore order
                kept_other.sort(key=lambda m: m.timestamp)
            else:
                # Default: sliding window from end
                kept_other = []
                current_tokens = 0
                for msg in reversed(other_msgs):
                    if current_tokens + msg.token_count <= available_tokens:
                        kept_other.insert(0, msg)
                        current_tokens += msg.token_count
            
            kept = system_msgs + kept_other
            pruned = [m for m in other_msgs if m not in kept_other]
        
        stats = ContextStats(
            original_messages=original_count,
            optimized_messages=len(kept),
            original_tokens=original_tokens,
            optimized_tokens=sum(m.token_count for m in kept),
            pruned_count=len(pruned),
            operation_time_ms=(time.time() - start_time) * 1000,
            strategy_used=strategy.value,
        )
        
        return PruningResult(kept=kept, pruned=pruned, stats=stats)
    
    def prune_duplicates(
        self,
        messages: list[dict[str, Any]] | list[ContextMessage],
        similarity_threshold: float = 0.9,
    ) -> PruningResult:
        """
        Remove duplicate or very similar messages.
        
        Args:
            messages: Messages to deduplicate
            similarity_threshold: Similarity threshold for considering duplicates
            
        Returns:
            PruningResult with unique messages
        """
        start_time = time.time()
        ctx_messages = self._to_context_messages(messages)
        original_count = len(ctx_messages)
        original_tokens = sum(m.token_count for m in ctx_messages)
        
        kept: list[ContextMessage] = []
        pruned: list[ContextMessage] = []
        seen_hashes: set[str] = set()
        
        for msg in ctx_messages:
            msg_hash = msg.content_hash
            
            # Check exact duplicates first
            if msg_hash in seen_hashes:
                pruned.append(msg)
                continue
            
            # Check similarity with kept messages
            is_duplicate = False
            for kept_msg in kept:
                similarity = self._calculate_similarity(msg.content, kept_msg.content)
                if similarity >= similarity_threshold:
                    is_duplicate = True
                    break
            
            if is_duplicate:
                pruned.append(msg)
            else:
                kept.append(msg)
                seen_hashes.add(msg_hash)
        
        stats = ContextStats(
            original_messages=original_count,
            optimized_messages=len(kept),
            original_tokens=original_tokens,
            optimized_tokens=sum(m.token_count for m in kept),
            pruned_count=len(pruned),
            operation_time_ms=(time.time() - start_time) * 1000,
            strategy_used="deduplication",
        )
        
        return PruningResult(kept=kept, pruned=pruned, stats=stats)
    
    def prune_by_pattern(
        self,
        messages: list[dict[str, Any]] | list[ContextMessage],
        patterns: list[str],
        keep_matches: bool = False,
    ) -> PruningResult:
        """
        Prune messages matching regex patterns.
        
        Args:
            messages: Messages to filter
            patterns: List of regex patterns
            keep_matches: If True, keep matching messages; if False, remove them
            
        Returns:
            PruningResult with filtered messages
        """
        start_time = time.time()
        ctx_messages = self._to_context_messages(messages)
        original_count = len(ctx_messages)
        original_tokens = sum(m.token_count for m in ctx_messages)
        
        # Compile patterns
        compiled_patterns = [re.compile(p, re.IGNORECASE) for p in patterns]
        
        kept: list[ContextMessage] = []
        pruned: list[ContextMessage] = []
        
        for msg in ctx_messages:
            # Check if message matches any pattern
            matches = any(p.search(msg.content) for p in compiled_patterns)
            
            if (matches and keep_matches) or (not matches and not keep_matches):
                kept.append(msg)
            else:
                pruned.append(msg)
        
        stats = ContextStats(
            original_messages=original_count,
            optimized_messages=len(kept),
            original_tokens=original_tokens,
            optimized_tokens=sum(m.token_count for m in kept),
            pruned_count=len(pruned),
            operation_time_ms=(time.time() - start_time) * 1000,
            strategy_used="pattern_filter",
        )
        
        return PruningResult(kept=kept, pruned=pruned, stats=stats)
    
    def prune_by_role(
        self,
        messages: list[dict[str, Any]] | list[ContextMessage],
        roles_to_remove: list[str],
    ) -> PruningResult:
        """
        Remove messages with specific roles.
        
        Args:
            messages: Messages to filter
            roles_to_remove: List of roles to remove (e.g., ["tool", "function"])
            
        Returns:
            PruningResult with filtered messages
        """
        start_time = time.time()
        ctx_messages = self._to_context_messages(messages)
        original_count = len(ctx_messages)
        original_tokens = sum(m.token_count for m in ctx_messages)
        
        kept: list[ContextMessage] = []
        pruned: list[ContextMessage] = []
        
        for msg in ctx_messages:
            if msg.role in roles_to_remove:
                pruned.append(msg)
            else:
                kept.append(msg)
        
        stats = ContextStats(
            original_messages=original_count,
            optimized_messages=len(kept),
            original_tokens=original_tokens,
            optimized_tokens=sum(m.token_count for m in kept),
            pruned_count=len(pruned),
            operation_time_ms=(time.time() - start_time) * 1000,
            strategy_used="role_filter",
        )
        
        return PruningResult(kept=kept, pruned=pruned, stats=stats)
    
    def prune_empty(
        self,
        messages: list[dict[str, Any]] | list[ContextMessage],
    ) -> PruningResult:
        """
        Remove messages with empty or whitespace-only content.
        
        Args:
            messages: Messages to filter
            
        Returns:
            PruningResult with non-empty messages
        """
        start_time = time.time()
        ctx_messages = self._to_context_messages(messages)
        original_count = len(ctx_messages)
        original_tokens = sum(m.token_count for m in ctx_messages)
        
        kept: list[ContextMessage] = []
        pruned: list[ContextMessage] = []
        
        for msg in ctx_messages:
            if msg.content and msg.content.strip():
                kept.append(msg)
            else:
                pruned.append(msg)
        
        stats = ContextStats(
            original_messages=original_count,
            optimized_messages=len(kept),
            original_tokens=original_tokens,
            optimized_tokens=sum(m.token_count for m in kept),
            pruned_count=len(pruned),
            operation_time_ms=(time.time() - start_time) * 1000,
            strategy_used="empty_filter",
        )
        
        return PruningResult(kept=kept, pruned=pruned, stats=stats)
    
    def prune_tool_results(
        self,
        messages: list[dict[str, Any]] | list[ContextMessage],
        max_result_length: int = 500,
        truncate_instead: bool = True,
    ) -> PruningResult:
        """
        Prune or truncate long tool/function results.
        
        Args:
            messages: Messages to process
            max_result_length: Maximum length for tool results
            truncate_instead: If True, truncate; if False, remove entirely
            
        Returns:
            PruningResult with processed messages
        """
        start_time = time.time()
        ctx_messages = self._to_context_messages(messages)
        original_count = len(ctx_messages)
        original_tokens = sum(m.token_count for m in ctx_messages)
        
        kept: list[ContextMessage] = []
        pruned: list[ContextMessage] = []
        
        for msg in ctx_messages:
            if msg.role in ("tool", "function"):
                if len(msg.content) > max_result_length:
                    if truncate_instead:
                        # Create truncated copy
                        truncated_msg = ContextMessage(
                            role=msg.role,
                            content=msg.content[:max_result_length] + "... [truncated]",
                            name=msg.name,
                            tool_call_id=msg.tool_call_id,
                            metadata=msg.metadata,
                            timestamp=msg.timestamp,
                            importance=msg.importance,
                        )
                        truncated_msg.estimate_tokens()
                        kept.append(truncated_msg)
                    else:
                        pruned.append(msg)
                else:
                    kept.append(msg)
            else:
                kept.append(msg)
        
        stats = ContextStats(
            original_messages=original_count,
            optimized_messages=len(kept),
            original_tokens=original_tokens,
            optimized_tokens=sum(m.token_count for m in kept),
            pruned_count=len(pruned),
            operation_time_ms=(time.time() - start_time) * 1000,
            strategy_used="tool_result_pruning",
        )
        
        return PruningResult(kept=kept, pruned=pruned, stats=stats)
    
    def _to_context_messages(
        self,
        messages: list[dict[str, Any]] | list[ContextMessage]
    ) -> list[ContextMessage]:
        """Convert to list of ContextMessage."""
        result: list[ContextMessage] = []
        
        for msg in messages:
            if isinstance(msg, ContextMessage):
                # Ensure token count is set
                if msg.token_count == 0:
                    msg.estimate_tokens()
                result.append(msg)
            else:
                ctx_msg = ContextMessage.from_dict(msg)
                ctx_msg.estimate_tokens()
                result.append(ctx_msg)
        
        return result
    
    def _separate_system(
        self,
        messages: list[ContextMessage]
    ) -> tuple[list[ContextMessage], list[ContextMessage]]:
        """Separate system and non-system messages."""
        if self.preserve_system:
            system = [m for m in messages if m.role == "system"]
            other = [m for m in messages if m.role != "system"]
        else:
            system = []
            other = messages
        
        return system, other
    
    def _default_relevance_scorer(self, query: str, content: str) -> float:
        """
        Default keyword-based relevance scorer.
        
        Args:
            query: Query string
            content: Content to score
            
        Returns:
            Relevance score between 0 and 1
        """
        query_words = set(query.lower().split())
        content_words = set(content.lower().split())
        
        if not query_words:
            return 0.0
        
        overlap = len(query_words & content_words)
        return overlap / len(query_words)
    
    def _calculate_similarity(self, text1: str, text2: str) -> float:
        """
        Calculate Jaccard similarity between two texts.
        
        Args:
            text1: First text
            text2: Second text
            
        Returns:
            Similarity score between 0 and 1
        """
        words1 = set(text1.lower().split())
        words2 = set(text2.lower().split())
        
        if not words1 and not words2:
            return 1.0
        if not words1 or not words2:
            return 0.0
        
        intersection = len(words1 & words2)
        union = len(words1 | words2)
        
        return intersection / union


class ConversationPruner(ContextPruner):
    """
    Specialized pruner for conversation-style contexts.
    
    Preserves conversation structure and turn-taking patterns.
    """
    
    def prune_keeping_turns(
        self,
        messages: list[dict[str, Any]] | list[ContextMessage],
        keep_turns: int = 5,
    ) -> PruningResult:
        """
        Prune keeping complete conversation turns.
        
        A turn is a user message followed by an assistant response.
        
        Args:
            messages: Messages to prune
            keep_turns: Number of complete turns to keep
            
        Returns:
            PruningResult with complete turns preserved
        """
        start_time = time.time()
        ctx_messages = self._to_context_messages(messages)
        original_count = len(ctx_messages)
        original_tokens = sum(m.token_count for m in ctx_messages)
        
        # Separate system messages
        system_msgs, other_msgs = self._separate_system(ctx_messages)
        
        # Find turns (user -> assistant pairs)
        turns: list[list[ContextMessage]] = []
        current_turn: list[ContextMessage] = []
        
        for msg in other_msgs:
            if msg.role == "user":
                if current_turn:  # Start new turn
                    turns.append(current_turn)
                current_turn = [msg]
            else:
                current_turn.append(msg)
        
        if current_turn:
            turns.append(current_turn)
        
        # Keep last N turns
        kept_turns = turns[-keep_turns:] if len(turns) > keep_turns else turns
        pruned_turns = turns[:-keep_turns] if len(turns) > keep_turns else []
        
        kept_other = [msg for turn in kept_turns for msg in turn]
        pruned = [msg for turn in pruned_turns for msg in turn]
        
        kept = system_msgs + kept_other
        
        stats = ContextStats(
            original_messages=original_count,
            optimized_messages=len(kept),
            original_tokens=original_tokens,
            optimized_tokens=sum(m.token_count for m in kept),
            pruned_count=len(pruned),
            operation_time_ms=(time.time() - start_time) * 1000,
            strategy_used="turn_based",
        )
        
        return PruningResult(kept=kept, pruned=pruned, stats=stats)
    
    def prune_summarizing_turns(
        self,
        messages: list[dict[str, Any]] | list[ContextMessage],
        keep_turns: int = 3,
        summarizer: Optional[Callable[[list[str]], str]] = None,
    ) -> tuple[PruningResult, Optional[str]]:
        """
        Prune older turns and optionally summarize them.
        
        Args:
            messages: Messages to prune
            keep_turns: Number of recent turns to keep
            summarizer: Function to summarize pruned content
            
        Returns:
            Tuple of (PruningResult, optional summary of pruned content)
        """
        # First get the turn-based pruning
        result = self.prune_keeping_turns(messages, keep_turns)
        
        # Generate summary if summarizer provided and content was pruned
        summary = None
        if summarizer and result.pruned:
            pruned_contents = [msg.content for msg in result.pruned]
            summary = summarizer(pruned_contents)
        
        return result, summary
