"""
Context Engineering Types

Core types for context management and optimization.
"""

from __future__ import annotations

import hashlib
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional


class MessageRole(Enum):
    """Message roles in conversation context."""
    
    SYSTEM = "system"
    USER = "user"
    ASSISTANT = "assistant"
    TOOL = "tool"
    FUNCTION = "function"


class PruningStrategy(Enum):
    """Strategy for pruning context."""
    
    RECENCY = "recency"  # Keep most recent messages
    RELEVANCE = "relevance"  # Keep most relevant to query
    IMPORTANCE = "importance"  # Keep by importance score
    SLIDING_WINDOW = "sliding_window"  # Fixed window from end
    SMART = "smart"  # Combination of strategies


class CompressionMethod(Enum):
    """Method for compressing context."""
    
    SUMMARIZE = "summarize"  # Summarize older messages
    MERGE = "merge"  # Merge similar messages
    EXTRACT_KEY_POINTS = "extract_key_points"  # Extract key information
    HIERARCHICAL = "hierarchical"  # Create hierarchy of summaries


@dataclass
class ContextMessage:
    """
    Represents a message in the context.
    
    Attributes:
        role: The role of the message sender
        content: The message content
        name: Optional name for function/tool messages
        tool_call_id: Optional tool call ID for tool messages
        metadata: Additional metadata for the message
        timestamp: When the message was created
        token_count: Estimated token count for this message
        importance: Importance score (0-1)
        relevance_scores: Relevance scores to different queries
        embedding: Vector embedding for semantic search
    """
    
    role: MessageRole | str
    content: str
    name: Optional[str] = None
    tool_call_id: Optional[str] = None
    metadata: dict[str, Any] = field(default_factory=dict)
    timestamp: float = field(default_factory=time.time)
    token_count: int = 0
    importance: float = 0.5
    relevance_scores: dict[str, float] = field(default_factory=dict)
    embedding: Optional[list[float]] = None
    
    def __post_init__(self) -> None:
        """Normalize role to string."""
        if isinstance(self.role, MessageRole):
            self.role = self.role.value
    
    @property
    def role_enum(self) -> MessageRole:
        """Get role as enum."""
        return MessageRole(self.role)
    
    @property
    def content_hash(self) -> str:
        """Get hash of content for deduplication."""
        return hashlib.md5(self.content.encode()).hexdigest()[:16]
    
    def estimate_tokens(self) -> int:
        """
        Estimate token count using rough heuristic.
        
        Returns:
            Estimated number of tokens
        """
        # Rough estimate: 1 token per 4 characters
        self.token_count = len(self.content) // 4 + 1
        return self.token_count
    
    def to_dict(self) -> dict[str, Any]:
        """
        Convert to dictionary format.
        
        Returns:
            Dictionary representation
        """
        result: dict[str, Any] = {
            "role": self.role,
            "content": self.content,
        }
        
        if self.name:
            result["name"] = self.name
        if self.tool_call_id:
            result["tool_call_id"] = self.tool_call_id
            
        return result
    
    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ContextMessage:
        """
        Create from dictionary.
        
        Args:
            data: Dictionary with message data
            
        Returns:
            New ContextMessage instance
        """
        return cls(
            role=data.get("role", "user"),
            content=data.get("content", ""),
            name=data.get("name"),
            tool_call_id=data.get("tool_call_id"),
            metadata=data.get("metadata", {}),
            timestamp=data.get("timestamp", time.time()),
            token_count=data.get("token_count", 0),
            importance=data.get("importance", 0.5),
        )
    
    def __repr__(self) -> str:
        """String representation."""
        content_preview = self.content[:50] + "..." if len(self.content) > 50 else self.content
        return f"ContextMessage(role={self.role}, content='{content_preview}')"


@dataclass
class ContextWindow:
    """
    Represents a context window with messages.
    
    Attributes:
        messages: List of messages in the context
        max_tokens: Maximum token limit for the window
        current_tokens: Current token count
        metadata: Additional metadata
    """
    
    messages: list[ContextMessage] = field(default_factory=list)
    max_tokens: int = 8192
    current_tokens: int = 0
    metadata: dict[str, Any] = field(default_factory=dict)
    
    def add_message(self, message: ContextMessage) -> bool:
        """
        Add a message to the context window.
        
        Args:
            message: Message to add
            
        Returns:
            True if added successfully, False if would exceed limit
        """
        if message.token_count == 0:
            message.estimate_tokens()
        
        if self.current_tokens + message.token_count > self.max_tokens:
            return False
        
        self.messages.append(message)
        self.current_tokens += message.token_count
        return True
    
    def remove_message(self, index: int) -> Optional[ContextMessage]:
        """
        Remove a message by index.
        
        Args:
            index: Index of message to remove
            
        Returns:
            Removed message or None if index invalid
        """
        if 0 <= index < len(self.messages):
            message = self.messages.pop(index)
            self.current_tokens -= message.token_count
            return message
        return None
    
    def clear(self) -> None:
        """Clear all messages."""
        self.messages.clear()
        self.current_tokens = 0
    
    @property
    def available_tokens(self) -> int:
        """Get available token space."""
        return self.max_tokens - self.current_tokens
    
    @property
    def utilization(self) -> float:
        """Get token utilization percentage."""
        return self.current_tokens / self.max_tokens if self.max_tokens > 0 else 0
    
    def recalculate_tokens(self) -> int:
        """
        Recalculate total token count.
        
        Returns:
            Total token count
        """
        self.current_tokens = sum(
            msg.estimate_tokens() if msg.token_count == 0 else msg.token_count
            for msg in self.messages
        )
        return self.current_tokens
    
    def get_messages_by_role(self, role: MessageRole | str) -> list[ContextMessage]:
        """
        Get messages filtered by role.
        
        Args:
            role: Role to filter by
            
        Returns:
            List of matching messages
        """
        role_str = role.value if isinstance(role, MessageRole) else role
        return [msg for msg in self.messages if msg.role == role_str]
    
    def to_list(self) -> list[dict[str, Any]]:
        """
        Convert to list of dictionaries.
        
        Returns:
            List of message dictionaries
        """
        return [msg.to_dict() for msg in self.messages]
    
    @classmethod
    def from_list(
        cls,
        messages: list[dict[str, Any]],
        max_tokens: int = 8192
    ) -> ContextWindow:
        """
        Create from list of dictionaries.
        
        Args:
            messages: List of message dictionaries
            max_tokens: Maximum token limit
            
        Returns:
            New ContextWindow instance
        """
        window = cls(max_tokens=max_tokens)
        for msg_data in messages:
            msg = ContextMessage.from_dict(msg_data)
            window.add_message(msg)
        return window
    
    def __len__(self) -> int:
        """Get number of messages."""
        return len(self.messages)
    
    def __iter__(self):
        """Iterate over messages."""
        return iter(self.messages)


@dataclass
class ContextStats:
    """
    Statistics about context optimization.
    
    Attributes:
        original_messages: Original message count
        optimized_messages: Optimized message count
        original_tokens: Original token count
        optimized_tokens: Optimized token count
        pruned_count: Number of messages pruned
        compressed_count: Number of messages compressed
        operation_time_ms: Time taken in milliseconds
        strategy_used: Strategy that was applied
    """
    
    original_messages: int = 0
    optimized_messages: int = 0
    original_tokens: int = 0
    optimized_tokens: int = 0
    pruned_count: int = 0
    compressed_count: int = 0
    operation_time_ms: float = 0.0
    strategy_used: str = ""
    
    @property
    def message_reduction(self) -> float:
        """Get message reduction percentage."""
        if self.original_messages == 0:
            return 0.0
        return 1 - (self.optimized_messages / self.original_messages)
    
    @property
    def token_reduction(self) -> float:
        """Get token reduction percentage."""
        if self.original_tokens == 0:
            return 0.0
        return 1 - (self.optimized_tokens / self.original_tokens)
    
    @property
    def tokens_saved(self) -> int:
        """Get number of tokens saved."""
        return self.original_tokens - self.optimized_tokens
    
    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "original_messages": self.original_messages,
            "optimized_messages": self.optimized_messages,
            "original_tokens": self.original_tokens,
            "optimized_tokens": self.optimized_tokens,
            "pruned_count": self.pruned_count,
            "compressed_count": self.compressed_count,
            "operation_time_ms": self.operation_time_ms,
            "strategy_used": self.strategy_used,
            "message_reduction_pct": round(self.message_reduction * 100, 2),
            "token_reduction_pct": round(self.token_reduction * 100, 2),
            "tokens_saved": self.tokens_saved,
        }


@dataclass
class OptimizationConfig:
    """
    Configuration for context optimization.
    
    Attributes:
        max_tokens: Maximum tokens to target
        preserve_system: Whether to preserve system messages
        preserve_recent: Number of recent messages to preserve
        min_messages: Minimum messages to keep
        pruning_strategy: Strategy for pruning
        compression_method: Method for compression
        relevance_threshold: Minimum relevance score to keep
        importance_threshold: Minimum importance score to keep
        enable_summarization: Whether to summarize pruned content
        summarization_ratio: Target ratio for summarization (e.g., 0.3 = 30% of original)
    """
    
    max_tokens: int = 4096
    preserve_system: bool = True
    preserve_recent: int = 3
    min_messages: int = 1
    pruning_strategy: PruningStrategy = PruningStrategy.SMART
    compression_method: CompressionMethod = CompressionMethod.SUMMARIZE
    relevance_threshold: float = 0.3
    importance_threshold: float = 0.3
    enable_summarization: bool = True
    summarization_ratio: float = 0.3
    
    def __post_init__(self) -> None:
        """Validate configuration."""
        if self.max_tokens <= 0:
            raise ValueError("max_tokens must be positive")
        if self.preserve_recent < 0:
            raise ValueError("preserve_recent cannot be negative")
        if not 0 <= self.relevance_threshold <= 1:
            raise ValueError("relevance_threshold must be between 0 and 1")
        if not 0 <= self.importance_threshold <= 1:
            raise ValueError("importance_threshold must be between 0 and 1")
        if not 0 < self.summarization_ratio <= 1:
            raise ValueError("summarization_ratio must be between 0 and 1")
    
    @classmethod
    def aggressive(cls) -> OptimizationConfig:
        """Create aggressive optimization config."""
        return cls(
            max_tokens=2048,
            preserve_recent=1,
            min_messages=1,
            pruning_strategy=PruningStrategy.RELEVANCE,
            relevance_threshold=0.5,
            importance_threshold=0.5,
            summarization_ratio=0.2,
        )
    
    @classmethod
    def balanced(cls) -> OptimizationConfig:
        """Create balanced optimization config."""
        return cls(
            max_tokens=4096,
            preserve_recent=3,
            min_messages=2,
            pruning_strategy=PruningStrategy.SMART,
            relevance_threshold=0.3,
            importance_threshold=0.3,
            summarization_ratio=0.3,
        )
    
    @classmethod
    def conservative(cls) -> OptimizationConfig:
        """Create conservative optimization config."""
        return cls(
            max_tokens=8192,
            preserve_recent=5,
            min_messages=3,
            pruning_strategy=PruningStrategy.RECENCY,
            relevance_threshold=0.2,
            importance_threshold=0.2,
            summarization_ratio=0.5,
        )


@dataclass
class ToolContext:
    """
    Represents tool/function context information.
    
    Attributes:
        name: Tool name
        description: Tool description
        parameters: Tool parameters schema
        token_count: Estimated token count
        usage_count: How many times used in conversation
        last_used: Last usage timestamp
        importance: Importance score
    """
    
    name: str
    description: str
    parameters: dict[str, Any] = field(default_factory=dict)
    token_count: int = 0
    usage_count: int = 0
    last_used: Optional[float] = None
    importance: float = 0.5
    
    def estimate_tokens(self) -> int:
        """Estimate token count for this tool definition."""
        import json
        
        # Estimate based on name + description + parameters
        content = self.name + self.description + json.dumps(self.parameters)
        self.token_count = len(content) // 4 + 1
        return self.token_count
    
    def to_dict(self) -> dict[str, Any]:
        """Convert to function/tool definition format."""
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.parameters,
            }
        }


@dataclass
class ContextSnapshot:
    """
    Snapshot of context state for history/debugging.
    
    Attributes:
        window: The context window state
        stats: Statistics at this point
        timestamp: When snapshot was taken
        operation: What operation was performed
        notes: Additional notes
    """
    
    window: ContextWindow
    stats: Optional[ContextStats] = None
    timestamp: float = field(default_factory=time.time)
    operation: str = ""
    notes: str = ""
    
    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "message_count": len(self.window),
            "token_count": self.window.current_tokens,
            "timestamp": self.timestamp,
            "operation": self.operation,
            "notes": self.notes,
            "stats": self.stats.to_dict() if self.stats else None,
        }
