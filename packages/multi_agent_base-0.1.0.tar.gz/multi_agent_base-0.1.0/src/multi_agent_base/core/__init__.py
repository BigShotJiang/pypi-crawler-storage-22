"""Core module containing configuration, agent base, pattern implementations, and tools.

This module also provides adapters for Microsoft Agent Framework integration:
- Workflows: Pattern → AF Workflow conversion with checkpointing
- Middleware: Resilience, Security, Rate Limiting as AF middleware
- ChatHistory: Memory backends as AF ChatHistoryProvider
- DevUI: Agent debugging and visualization interface
"""

from multi_agent_base.core.config import (
    AgentConfig,
    ObservabilityConfig,
    PatternType,
    ProviderConfig,
    ProviderType,
    SystemConfig,
)
from multi_agent_base.core.agent import BaseAgent
from multi_agent_base.core.af_adapter import (
    EnhancedAgent,
    EnhancedAgentConfig,
    EnhancedAgentResult,
    create_enhanced_agent,
)
from multi_agent_base.core.patterns import (
    BasePattern,
    PatternResult,
    SingleAgentPattern,
    SupervisorPattern,
    SwarmPattern,
    PipelinePattern,
    ParallelPattern,
    RouterPattern,
    ReflectionPattern,
    BlackboardPattern,
    CompositePattern,
    DebatePattern,
    HierarchicalPattern,
    HierarchicalLevel,
    EnsemblePattern,
    VotingStrategy,
    VoteResult,
    SelfHealingPattern,
    create_pattern,
)
from multi_agent_base.core.tools import (
    BaseTool,
    FunctionTool,
    ActionTool,
    ToolResult,
    ToolResultStatus,
    ToolParameter,
    # Tool adapters
    base_tool_to_agent_tool,
    agent_tool_to_base_tool,
    callable_to_base_tool,
)
from multi_agent_base.core.registry import (
    ToolRegistry,
    ToolNamespace,
    get_registry,
)
from multi_agent_base.core.decorators import (
    tool,
    async_tool,
    action,
    skill,
    get_tool,
    get_tools,
    register_tools,
)
# AF Workflows Adapter
from multi_agent_base.core.workflows import (
    Workflow,
    WorkflowBuilder,
    WorkflowResult,
    WorkflowState,
    WorkflowContext,
    WorkflowCheckpoint,
    Executor,
    FunctionExecutor,
    AgentExecutor,
    RouterExecutor,
    Edge,
    CheckpointStore,
    InMemoryCheckpointStore,
    SequentialWorkflowBuilder,
    ConcurrentWorkflowBuilder,
    PatternToWorkflow,
    # Convenience aliases
    AFWorkflow,
    AFWorkflowBuilder,
    AFWorkflowResult,
)
# AF Middleware Adapter
from multi_agent_base.core.middleware import (
    BaseMiddleware,
    AgentMiddleware,
    ChatMiddleware,
    FunctionMiddleware,
    MiddlewareContext,
    MiddlewarePipeline,
    # Concrete implementations
    ResilienceMiddleware,
    SecurityMiddleware,
    RateLimitMiddleware,
    CostTrackingMiddleware,
    MetricsMiddleware,
    LoggingMiddleware,
    # Factory
    create_default_middleware_pipeline,
    # Convenience aliases
    AFAgentMiddleware,
    AFChatMiddleware,
    AFMiddlewarePipeline,
)
# AF ChatHistoryProvider Adapter
from multi_agent_base.core.chat_history import (
    ChatHistoryProvider,
    ChatMessage,
    InvokingContext,
    InvokedContext,
    MemoryBackendChatHistoryProvider,
    InMemoryChatHistoryProvider,
    SlidingWindowChatHistoryProvider,
    TokenLimitedChatHistoryProvider,
    # Factory
    create_chat_history_provider,
    # Convenience aliases
    AFChatHistoryProvider,
    AFChatMessage,
    AFInMemoryChatHistoryProvider,
)
# AF DevUI Integration
from multi_agent_base.core.devui import (
    DevUI,
    DevUIConfig,
    start_devui,
    create_devui_middleware,
    DevUITracer,
    # Convenience aliases
    AFDevUI,
    AFDevUIConfig,
)
# AgentThread - Persistent Conversations
from multi_agent_base.core.thread import (
    AgentThread,
    ThreadCheckpoint,
    ThreadState,
    ThreadChatHistoryProvider,
    create_thread,
    resume_thread,
)

__all__ = [
    # Config
    "AgentConfig",
    "ObservabilityConfig",
    "PatternType",
    "ProviderConfig",
    "ProviderType",
    "SystemConfig",
    # Agent
    "BaseAgent",
    # AF Adapter (Enhanced Agent)
    "EnhancedAgent",
    "EnhancedAgentConfig",
    "EnhancedAgentResult",
    "create_enhanced_agent",
    # Patterns
    "BasePattern",
    "PatternResult",
    "SingleAgentPattern",
    "SupervisorPattern",
    "SwarmPattern",
    "PipelinePattern",
    "ParallelPattern",
    "RouterPattern",
    "ReflectionPattern",
    "BlackboardPattern",
    "CompositePattern",
    "DebatePattern",
    "HierarchicalPattern",
    "HierarchicalLevel",
    "EnsemblePattern",
    "VotingStrategy",
    "VoteResult",
    "SelfHealingPattern",
    "create_pattern",
    # Tools
    "BaseTool",
    "FunctionTool",
    "ActionTool",
    "ToolResult",
    "ToolResultStatus",
    "ToolParameter",
    # Tool adapters
    "base_tool_to_agent_tool",
    "agent_tool_to_base_tool",
    "callable_to_base_tool",
    # Registry
    "ToolRegistry",
    "ToolNamespace",
    "get_registry",
    # Decorators
    "tool",
    "async_tool",
    "action",
    "skill",
    "get_tool",
    "get_tools",
    "register_tools",
    # AF Workflows Adapter
    "Workflow",
    "WorkflowBuilder",
    "WorkflowResult",
    "WorkflowState",
    "WorkflowContext",
    "WorkflowCheckpoint",
    "Executor",
    "FunctionExecutor",
    "AgentExecutor",
    "RouterExecutor",
    "Edge",
    "CheckpointStore",
    "InMemoryCheckpointStore",
    "SequentialWorkflowBuilder",
    "ConcurrentWorkflowBuilder",
    "PatternToWorkflow",
    "AFWorkflow",
    "AFWorkflowBuilder",
    "AFWorkflowResult",
    # AF Middleware Adapter
    "BaseMiddleware",
    "AgentMiddleware",
    "ChatMiddleware",
    "FunctionMiddleware",
    "MiddlewareContext",
    "MiddlewarePipeline",
    "ResilienceMiddleware",
    "SecurityMiddleware",
    "RateLimitMiddleware",
    "CostTrackingMiddleware",
    "MetricsMiddleware",
    "LoggingMiddleware",
    "create_default_middleware_pipeline",
    "AFAgentMiddleware",
    "AFChatMiddleware",
    "AFMiddlewarePipeline",
    # AF ChatHistoryProvider Adapter
    "ChatHistoryProvider",
    "ChatMessage",
    "InvokingContext",
    "InvokedContext",
    "MemoryBackendChatHistoryProvider",
    "InMemoryChatHistoryProvider",
    "SlidingWindowChatHistoryProvider",
    "TokenLimitedChatHistoryProvider",
    "create_chat_history_provider",
    "AFChatHistoryProvider",
    "AFChatMessage",
    "AFInMemoryChatHistoryProvider",
    # AF DevUI Integration
    "DevUI",
    "DevUIConfig",
    "start_devui",
    "create_devui_middleware",
    "DevUITracer",
    "AFDevUI",
    "AFDevUIConfig",
    # AgentThread - Persistent Conversations
    "AgentThread",
    "ThreadCheckpoint",
    "ThreadState",
    "ThreadChatHistoryProvider",
    "create_thread",
    "resume_thread",
]
