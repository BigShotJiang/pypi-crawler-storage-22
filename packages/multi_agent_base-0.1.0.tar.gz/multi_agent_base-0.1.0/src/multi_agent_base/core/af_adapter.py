"""
Microsoft Agent Framework Adapter Layer.

This module provides adapters to use Microsoft Agent Framework (AF)
as the execution engine while layering our unique extensions on top:

- Resilience: Circuit breaker, retry with jitter, fallback chains
- Rate Limiting: Token bucket, Redis distributed limiting
- Cost Tracking: Per-model, per-agent cost tracking
- Security: Injection detection, permissions, validation
- Monitoring: Prometheus metrics, K8s health checks

Usage:
    ```python
    from multi_agent_base.core.af_adapter import EnhancedAgent
    
    agent = EnhancedAgent(
        name="assistant",
        instructions="You are helpful.",
        model="gpt-4o-mini",
        resilience_config=ResilienceConfig(),
        rate_limit_config=RateLimitConfig(),
    )
    
    result = await agent.run("Hello!")
    ```
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from datetime import datetime
from typing import TYPE_CHECKING, Any, Callable, AsyncIterator

if TYPE_CHECKING:
    from multi_agent_base.resilience.patterns import ResilienceWrapper
    from multi_agent_base.ratelimit.limiter import RateLimiter
    from multi_agent_base.cost.tracker import CostTracker
    from multi_agent_base.security.validator import SecurityValidator
    from multi_agent_base.observability.logger import AgentLogger
    from multi_agent_base.monitoring.metrics import MetricsCollector


@dataclass
class EnhancedAgentConfig:
    """Configuration for EnhancedAgent.
    
    Attributes:
        name: Agent identifier
        instructions: System prompt for the agent
        model: Model name (e.g., gpt-4o-mini, claude-3-sonnet)
        provider: Provider name (openai, anthropic, azure_openai)
        api_key: Optional API key (uses env var if not provided)
        enable_resilience: Enable circuit breaker and retry patterns
        enable_rate_limiting: Enable rate limiting
        enable_cost_tracking: Enable cost tracking
        enable_security: Enable input validation and injection detection
        enable_metrics: Enable Prometheus metrics
        max_tokens: Maximum tokens in response
        temperature: Model temperature
    """
    
    name: str
    instructions: str = "You are a helpful assistant."
    model: str = "gpt-4o-mini"
    provider: str = "openai"
    api_key: str | None = None
    enable_resilience: bool = True
    enable_rate_limiting: bool = False
    enable_cost_tracking: bool = True
    enable_security: bool = True
    enable_metrics: bool = False
    max_tokens: int = 4096
    temperature: float = 0.7


@dataclass
class EnhancedAgentResult:
    """Result from an EnhancedAgent run.
    
    Attributes:
        content: The response content
        tokens: Token usage dict
        cost: Cost in USD if tracking enabled
        duration_ms: Run duration in milliseconds
        rate_limited: Whether rate limiting was applied
        from_cache: Whether response came from cache
        metadata: Additional metadata
    """
    
    content: str
    tokens: dict[str, int] = field(default_factory=dict)
    cost: float | None = None
    duration_ms: float = 0.0
    rate_limited: bool = False
    from_cache: bool = False
    metadata: dict[str, Any] = field(default_factory=dict)


class EnhancedAgent:
    """Agent with enhanced capabilities on top of Microsoft Agent Framework.
    
    This class wraps AF's ChatAgent and adds:
    - Resilience patterns (circuit breaker, retry)
    - Rate limiting (token bucket)
    - Cost tracking
    - Security validation
    - Prometheus metrics
    
    Example:
        ```python
        agent = EnhancedAgent(
            config=EnhancedAgentConfig(
                name="assistant",
                instructions="You help with coding.",
                model="gpt-4o-mini",
            ),
            cost_tracker=CostTracker(),
        )
        
        result = await agent.run("Help me write a Python function")
        print(result.content)
        print(f"Cost: ${result.cost:.4f}")
        ```
    """
    
    def __init__(
        self,
        config: EnhancedAgentConfig,
        resilience_wrapper: "ResilienceWrapper | None" = None,
        rate_limiter: "RateLimiter | None" = None,
        cost_tracker: "CostTracker | None" = None,
        security_validator: "SecurityValidator | None" = None,
        logger: "AgentLogger | None" = None,
        metrics: "MetricsCollector | None" = None,
        tools: list[Callable[..., Any]] | None = None,
    ) -> None:
        """Initialize enhanced agent.
        
        Args:
            config: Agent configuration
            resilience_wrapper: Optional resilience patterns wrapper
            rate_limiter: Optional rate limiter
            cost_tracker: Optional cost tracker
            security_validator: Optional security validator
            logger: Optional logger
            metrics: Optional Prometheus metrics collector
            tools: Optional list of tool functions
        """
        self.config = config
        self.resilience_wrapper = resilience_wrapper
        self.rate_limiter = rate_limiter
        self.cost_tracker = cost_tracker
        self.security_validator = security_validator
        self.logger = logger
        self.metrics = metrics
        self.tools = tools or []
        
        # Lazy-initialized AF agent
        self._af_agent = None
        self._af_client = None
    
    async def _ensure_af_agent(self) -> None:
        """Lazily initialize the Microsoft Agent Framework agent."""
        if self._af_agent is not None:
            return
        
        try:
            from agent_framework import ChatAgent
            from agent_framework.openai import OpenAIChatClient
        except ImportError:
            raise ImportError(
                "agent-framework package not installed. "
                "Install with: pip install agent-framework --pre"
            )
        
        # Create chat client based on provider
        if self.config.provider == "openai":
            self._af_client = OpenAIChatClient(
                model=self.config.model,
                api_key=self.config.api_key,
            )
        elif self.config.provider == "azure_openai":
            try:
                from agent_framework.azure import AzureOpenAIChatClient
                self._af_client = AzureOpenAIChatClient(
                    deployment_name=self.config.model,
                    api_key=self.config.api_key,
                )
            except ImportError:
                raise ImportError(
                    "agent-framework-azure-ai package not installed. "
                    "Install with: pip install agent-framework-azure-ai --pre"
                )
        else:
            # Default to OpenAI for now
            self._af_client = OpenAIChatClient(
                model=self.config.model,
                api_key=self.config.api_key,
            )
        
        # Create the AF ChatAgent
        self._af_agent = ChatAgent(
            chat_client=self._af_client,
            instructions=self.config.instructions,
            tools=self.tools if self.tools else None,
        )
    
    async def run(
        self,
        message: str,
        context: dict[str, Any] | None = None,
    ) -> EnhancedAgentResult:
        """Run the agent with enhanced capabilities.
        
        Args:
            message: User message
            context: Optional context dict
            
        Returns:
            EnhancedAgentResult with response and metadata
        """
        start_time = datetime.now()
        metadata: dict[str, Any] = {}
        
        # Security validation
        if self.security_validator and self.config.enable_security:
            is_safe, reason = await self._validate_input(message)
            if not is_safe:
                return EnhancedAgentResult(
                    content=f"Input rejected: {reason}",
                    metadata={"security_blocked": True, "reason": reason},
                )
        
        # Rate limiting
        if self.rate_limiter and self.config.enable_rate_limiting:
            is_allowed, limit_info = await self._check_rate_limit()
            if not is_allowed:
                return EnhancedAgentResult(
                    content="Rate limit exceeded. Please try again later.",
                    rate_limited=True,
                    metadata={"rate_limit_info": limit_info},
                )
        
        # Execute with resilience
        try:
            if self.resilience_wrapper and self.config.enable_resilience:
                result = await self._run_with_resilience(message)
            else:
                result = await self._run_direct(message)
        except Exception as e:
            if self.logger:
                self.logger.log_error(self.config.name, str(e))
            raise
        
        # Calculate cost
        cost = None
        if self.cost_tracker and self.config.enable_cost_tracking and result.get("usage"):
            usage = result["usage"]
            cost = self.cost_tracker.calculate_cost(
                provider=self.config.provider,
                model=self.config.model,
                input_tokens=usage.get("prompt_tokens", 0),
                output_tokens=usage.get("completion_tokens", 0),
            )
            self.cost_tracker.record(
                agent_name=self.config.name,
                provider=self.config.provider,
                model=self.config.model,
                input_tokens=usage.get("prompt_tokens", 0),
                output_tokens=usage.get("completion_tokens", 0),
                cost=cost,
            )
        
        # Record metrics
        duration_ms = (datetime.now() - start_time).total_seconds() * 1000
        if self.metrics and self.config.enable_metrics:
            await self._record_metrics(duration_ms, result.get("usage", {}))
        
        return EnhancedAgentResult(
            content=result.get("content", ""),
            tokens=result.get("usage", {}),
            cost=cost,
            duration_ms=duration_ms,
            metadata=metadata,
        )
    
    async def _validate_input(self, message: str) -> tuple[bool, str | None]:
        """Validate input for security threats."""
        if not self.security_validator:
            return True, None
        
        # Check for prompt injection
        result = self.security_validator.check_prompt_injection(message)
        if not result.is_safe:
            return False, result.reason
        
        return True, None
    
    async def _check_rate_limit(self) -> tuple[bool, dict[str, Any]]:
        """Check rate limit."""
        if not self.rate_limiter:
            return True, {}
        
        result = await self.rate_limiter.acquire(self.config.name)
        return result.allowed, {
            "remaining": result.remaining,
            "reset_after": result.reset_after,
        }
    
    async def _run_with_resilience(self, message: str) -> dict[str, Any]:
        """Run agent with resilience patterns."""
        if not self.resilience_wrapper:
            return await self._run_direct(message)
        
        async def execute():
            return await self._run_direct(message)
        
        return await self.resilience_wrapper.execute(execute)
    
    async def _run_direct(self, message: str) -> dict[str, Any]:
        """Run the AF agent directly."""
        await self._ensure_af_agent()
        
        response = await self._af_agent.run(message)
        
        # Extract content and usage from response
        content = str(response) if response else ""
        
        # Try to get usage info if available
        usage = {}
        if hasattr(response, 'usage'):
            usage = {
                "prompt_tokens": getattr(response.usage, 'prompt_tokens', 0),
                "completion_tokens": getattr(response.usage, 'completion_tokens', 0),
                "total_tokens": getattr(response.usage, 'total_tokens', 0),
            }
        
        return {
            "content": content,
            "usage": usage,
        }
    
    async def _record_metrics(
        self,
        duration_ms: float,
        usage: dict[str, int],
    ) -> None:
        """Record Prometheus metrics."""
        if not self.metrics:
            return
        
        # Record request duration
        self.metrics.observe_histogram(
            "agent_request_duration_seconds",
            duration_ms / 1000,
            {"agent": self.config.name, "model": self.config.model},
        )
        
        # Record tokens
        if usage:
            self.metrics.increment_counter(
                "agent_tokens_total",
                usage.get("total_tokens", 0),
                {"agent": self.config.name, "type": "total"},
            )
    
    def register_tool(self, tool: Callable[..., Any]) -> None:
        """Register a tool function.
        
        Args:
            tool: A callable function to use as a tool
        """
        self.tools.append(tool)
        # Reset AF agent to pick up new tool
        self._af_agent = None


def create_enhanced_agent(
    name: str,
    instructions: str,
    model: str = "gpt-4o-mini",
    provider: str = "openai",
    tools: list[Callable[..., Any]] | None = None,
    enable_cost_tracking: bool = True,
    enable_security: bool = True,
) -> EnhancedAgent:
    """Factory function to create an EnhancedAgent with default settings.
    
    Args:
        name: Agent identifier
        instructions: System prompt
        model: Model name
        provider: Provider name
        tools: Optional tools
        enable_cost_tracking: Enable cost tracking
        enable_security: Enable security validation
        
    Returns:
        Configured EnhancedAgent
        
    Example:
        ```python
        agent = create_enhanced_agent(
            name="coder",
            instructions="You are an expert Python developer.",
            tools=[code_search, run_tests],
        )
        ```
    """
    config = EnhancedAgentConfig(
        name=name,
        instructions=instructions,
        model=model,
        provider=provider,
        enable_cost_tracking=enable_cost_tracking,
        enable_security=enable_security,
    )
    
    # Initialize optional components
    cost_tracker = None
    security_validator = None
    
    if enable_cost_tracking:
        try:
            from multi_agent_base.cost.tracker import CostTracker
            cost_tracker = CostTracker()
        except ImportError:
            pass
    
    if enable_security:
        try:
            from multi_agent_base.security.validator import SecurityValidator
            security_validator = SecurityValidator()
        except ImportError:
            pass
    
    return EnhancedAgent(
        config=config,
        cost_tracker=cost_tracker,
        security_validator=security_validator,
        tools=tools,
    )
