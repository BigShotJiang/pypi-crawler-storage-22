"""
Base Agent wrapper for the Multi-Agent Base framework.

This module provides a unified agent interface that wraps
Microsoft Agent Framework agents with additional capabilities
like observability, cost tracking, and A2A card generation.
"""

from __future__ import annotations

import asyncio
import json
from dataclasses import dataclass, field
from datetime import datetime
from typing import TYPE_CHECKING, Any, AsyncIterator, Callable

from pydantic import BaseModel

if TYPE_CHECKING:
    from multi_agent_base.a2a.agent_card import AgentCard
    from multi_agent_base.core.config import AgentConfig, ProviderConfig
    from multi_agent_base.cost.tracker import CostTracker
    from multi_agent_base.memory.base import MemoryBackend
    from multi_agent_base.observability.logger import AgentLogger
    from multi_agent_base.providers.factory import BaseModelClient


@dataclass
class Message:
    """Represents a message in the agent conversation.
    
    Attributes:
        role: The role of the message sender (user, assistant, system, tool)
        content: The message content
        name: Optional name of the sender
        tool_call_id: Optional tool call ID for tool responses
        timestamp: When the message was created
        metadata: Additional message metadata
    """
    
    role: str
    content: str
    name: str | None = None
    tool_call_id: str | None = None
    timestamp: datetime = field(default_factory=datetime.now)
    metadata: dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> dict[str, Any]:
        """Convert message to dictionary format."""
        result = {
            "role": self.role,
            "content": self.content,
            "timestamp": self.timestamp.isoformat(),
        }
        if self.name:
            result["name"] = self.name
        if self.tool_call_id:
            result["tool_call_id"] = self.tool_call_id
        if self.metadata:
            result["metadata"] = self.metadata
        return result


@dataclass
class AgentResponse:
    """Response from an agent run.
    
    Attributes:
        content: The response content
        messages: Full conversation history
        tool_calls: List of tool calls made during the run
        usage: Token usage information
        cost: Cost information if tracking enabled
        duration_ms: Run duration in milliseconds
        metadata: Additional response metadata
    """
    
    content: str
    messages: list[Message] = field(default_factory=list)
    tool_calls: list[dict[str, Any]] = field(default_factory=list)
    usage: dict[str, int] = field(default_factory=dict)
    cost: float | None = None
    duration_ms: float = 0.0
    metadata: dict[str, Any] = field(default_factory=dict)


class Tool(BaseModel):
    """Wrapper for tool functions.
    
    Attributes:
        name: Tool name
        description: Tool description
        function: The callable function
        parameters: JSON schema for parameters
    """
    
    name: str
    description: str
    function: Callable[..., Any]
    parameters: dict[str, Any] = {}
    
    class Config:
        arbitrary_types_allowed = True


class BaseAgent:
    """Base agent class providing unified interface for all agents.
    
    This class wraps Microsoft Agent Framework agents and adds:
    - Observability through Arize Phoenix
    - Cost tracking
    - A2A Agent Card generation
    - Tool management
    - Conversation memory
    
    Attributes:
        name: Agent identifier
        config: Agent configuration
        provider_config: LLM provider configuration
        tools: Registered tools
        memory: Conversation memory
        logger: Agent logger instance
        cost_tracker: Cost tracker instance
    
    Example:
        ```python
        agent = BaseAgent(
            name="assistant",
            config=AgentConfig(
                name="assistant",
                system_prompt="You are helpful."
            ),
            provider_config=provider_config,
        )
        
        # Add tools
        agent.register_tool(my_tool_function)
        
        # Run agent
        response = await agent.run("Hello!")
        print(response.content)
        ```
    """
    
    def __init__(
        self,
        name: str,
        config: AgentConfig,
        provider_config: ProviderConfig,
        tools: list[Tool] | None = None,
        logger: AgentLogger | None = None,
        cost_tracker: CostTracker | None = None,
        memory_backend: MemoryBackend | None = None,
        model_client: BaseModelClient | None = None,
    ) -> None:
        """Initialize the base agent.
        
        Args:
            name: Agent identifier
            config: Agent configuration
            provider_config: LLM provider configuration
            tools: List of tools to register
            logger: Optional logger instance
            cost_tracker: Optional cost tracker instance
            memory_backend: Optional memory backend for persistent conversation memory
            model_client: Optional pre-configured model client
        """
        self.name = name
        self.config = config
        self.provider_config = config.provider_override or provider_config
        self.tools: dict[str, Tool] = {}
        self.memory: list[Message] = []
        self.memory_backend = memory_backend
        self.logger = logger
        self.cost_tracker = cost_tracker
        self.model_client = model_client
        self._client = None
        self._agent = None
        
        # Maximum iterations for tool execution loop
        self.max_tool_iterations = config.max_iterations if hasattr(config, 'max_iterations') else 10
        
        # Register initial tools
        if tools:
            for tool in tools:
                self.register_tool(tool)
        
        # Add system message to memory
        if config.system_prompt:
            self.memory.append(Message(
                role="system",
                content=config.system_prompt,
            ))
    
    def register_tool(self, tool: Tool | Callable[..., Any]) -> None:
        """Register a tool with the agent.
        
        Args:
            tool: Tool instance or callable function
        """
        if callable(tool) and not isinstance(tool, Tool):
            # Convert function to Tool
            tool = self._function_to_tool(tool)
        
        self.tools[tool.name] = tool
        
        if self.logger:
            self.logger.log_tool_registered(self.name, tool.name)
    
    def _function_to_tool(self, func: Callable[..., Any]) -> Tool:
        """Convert a function to a Tool instance.
        
        Args:
            func: The function to convert
            
        Returns:
            Tool instance
        """
        import inspect
        
        name = func.__name__
        description = func.__doc__ or f"Tool: {name}"
        
        # Extract parameters from function signature
        sig = inspect.signature(func)
        parameters = {
            "type": "object",
            "properties": {},
            "required": [],
        }
        
        for param_name, param in sig.parameters.items():
            if param_name == "self":
                continue
            
            param_info: dict[str, Any] = {"type": "string"}
            
            # Try to infer type from annotation
            if param.annotation != inspect.Parameter.empty:
                if param.annotation == int:
                    param_info["type"] = "integer"
                elif param.annotation == float:
                    param_info["type"] = "number"
                elif param.annotation == bool:
                    param_info["type"] = "boolean"
                elif param.annotation == list:
                    param_info["type"] = "array"
                elif param.annotation == dict:
                    param_info["type"] = "object"
            
            parameters["properties"][param_name] = param_info
            
            if param.default == inspect.Parameter.empty:
                parameters["required"].append(param_name)
        
        return Tool(
            name=name,
            description=description.strip(),
            function=func,
            parameters=parameters,
        )
    
    async def run(
        self,
        message: str,
        context: dict[str, Any] | None = None,
    ) -> AgentResponse:
        """Run the agent with the given message.
        
        Args:
            message: User message to process
            context: Optional context dictionary
            
        Returns:
            AgentResponse with the result
        """
        start_time = datetime.now()
        
        # Add user message to memory
        user_message = Message(role="user", content=message)
        self.memory.append(user_message)
        
        # Persist to memory backend if available
        if self.memory_backend:
            await self._persist_message(user_message)
        
        # Log the incoming message
        if self.logger:
            self.logger.log_message(self.name, user_message)
        
        try:
            # Build messages for the model
            messages = self._build_messages()
            
            # Get response from model client
            response_content, usage, tool_calls = await self._call_model(
                messages=messages,
                context=context,
            )
            
            # Add assistant response to memory
            assistant_message = Message(
                role="assistant",
                content=response_content,
                metadata={"tool_calls": tool_calls} if tool_calls else {},
            )
            self.memory.append(assistant_message)
            
            # Persist to memory backend if available
            if self.memory_backend:
                await self._persist_message(assistant_message)
            
            # Calculate cost if tracking enabled
            cost = None
            if self.cost_tracker and usage:
                cost = self.cost_tracker.calculate_cost(
                    provider=str(self.provider_config.provider),
                    model=self.provider_config.model,
                    input_tokens=usage.get("prompt_tokens", 0),
                    output_tokens=usage.get("completion_tokens", 0),
                )
                self.cost_tracker.record(
                    agent_name=self.name,
                    provider=str(self.provider_config.provider),
                    model=self.provider_config.model,
                    input_tokens=usage.get("prompt_tokens", 0),
                    output_tokens=usage.get("completion_tokens", 0),
                    cost=cost,
                )
            
            # Calculate duration
            duration_ms = (datetime.now() - start_time).total_seconds() * 1000
            
            # Log the response
            if self.logger:
                self.logger.log_message(self.name, assistant_message)
                self.logger.log_run_complete(
                    self.name,
                    duration_ms=duration_ms,
                    tokens=usage,
                    cost=cost,
                )
            
            return AgentResponse(
                content=response_content,
                messages=list(self.memory),
                tool_calls=tool_calls,
                usage=usage,
                cost=cost,
                duration_ms=duration_ms,
            )
            
        except Exception as e:
            if self.logger:
                self.logger.log_error(self.name, str(e))
            raise
    
    def _build_messages(self) -> list[dict[str, str]]:
        """Build messages list for the model.
        
        Returns:
            List of message dictionaries
        """
        return [
            {"role": msg.role, "content": msg.content}
            for msg in self.memory
        ]
    
    async def _call_model(
        self,
        messages: list[dict[str, str]],
        context: dict[str, Any] | None = None,
    ) -> tuple[str, dict[str, int], list[dict[str, Any]]]:
        """Call the model and return response.
        
        Implements a tool execution loop that:
        1. Sends messages to the model
        2. If model returns tool calls, executes them
        3. Adds tool results to messages
        4. Repeats until no more tool calls or max iterations
        
        Args:
            messages: List of messages
            context: Optional context
            
        Returns:
            Tuple of (response_content, usage, tool_calls)
        """
        if not self.model_client:
            # No model client - return empty (subclasses may override)
            return "", {}, []
        
        # Build tool definitions for the model
        tools_schema = self._build_tools_schema() if self.tools else None
        
        all_tool_calls: list[dict[str, Any]] = []
        total_usage: dict[str, int] = {
            "prompt_tokens": 0,
            "completion_tokens": 0,
            "total_tokens": 0,
        }
        
        current_messages = list(messages)
        iteration = 0
        
        while iteration < self.max_tool_iterations:
            iteration += 1
            
            # Call the model
            content, usage, tool_calls = await self.model_client.generate(
                messages=current_messages,
                tools=tools_schema,
            )
            
            # Accumulate usage
            for key in total_usage:
                total_usage[key] += usage.get(key, 0)
            
            # If no tool calls, we're done
            if not tool_calls:
                return content, total_usage, all_tool_calls
            
            # Process tool calls
            all_tool_calls.extend(tool_calls)
            
            # Add assistant message with tool calls
            current_messages.append({
                "role": "assistant",
                "content": content or "",
                "tool_calls": tool_calls,
            })
            
            # Execute each tool and add results
            for tool_call in tool_calls:
                tool_result = await self._execute_tool(tool_call)
                
                # Get tool name from normalized or raw format
                tool_name = tool_call.get("name") or tool_call.get("function", {}).get("name", "")
                
                # Add tool result message
                current_messages.append({
                    "role": "tool",
                    "tool_call_id": tool_call.get("id", ""),
                    "name": tool_name,
                    "content": json.dumps(tool_result) if not isinstance(tool_result, str) else tool_result,
                })
                
                # Log tool execution
                if self.logger:
                    # Get arguments from normalized or raw format
                    args_raw = tool_call.get("arguments") or tool_call.get("function", {}).get("arguments", "{}")
                    try:
                        args = json.loads(args_raw) if isinstance(args_raw, str) else args_raw
                    except (json.JSONDecodeError, TypeError):
                        args = {}
                    
                    self.logger.log_tool_call(
                        agent_name=self.name,
                        tool_name=tool_name,
                        arguments=args,
                        result=tool_result,
                    )
        
        # Max iterations reached, return last response
        return content, total_usage, all_tool_calls
    
    async def _execute_tool(self, tool_call: dict[str, Any]) -> Any:
        """Execute a single tool call.
        
        Handles normalized tool call format from providers:
        - {id, name, arguments} (canonical format)
        - {id, function: {name, arguments}} (OpenAI raw format)
        
        Args:
            tool_call: Tool call specification from the model
            
        Returns:
            Tool execution result
        """
        # Handle both normalized and OpenAI raw formats
        if "function" in tool_call:
            # OpenAI raw format: {id, function: {name, arguments}}
            function_info = tool_call.get("function", {})
            tool_name = function_info.get("name", "")
            arguments_raw = function_info.get("arguments", "{}")
        else:
            # Normalized format: {id, name, arguments}
            tool_name = tool_call.get("name", "")
            arguments_raw = tool_call.get("arguments", "{}")
        
        # Parse arguments - handle both string and dict
        try:
            if isinstance(arguments_raw, str):
                arguments = json.loads(arguments_raw) if arguments_raw else {}
            else:
                arguments = arguments_raw or {}
        except json.JSONDecodeError:
            return {"error": f"Invalid JSON arguments: {arguments_raw}"}
        
        # Find and execute the tool
        if tool_name not in self.tools:
            return {"error": f"Unknown tool: {tool_name}"}
        
        tool = self.tools[tool_name]
        
        try:
            # Execute the tool function
            result = tool.function(**arguments)
            
            # Handle async functions
            if asyncio.iscoroutine(result):
                result = await result
            
            return result
            
        except Exception as e:
            return {"error": f"Tool execution failed: {str(e)}"}
    
    def _build_tools_schema(self) -> list[dict[str, Any]]:
        """Build canonical tools schema.
        
        Returns a provider-agnostic format that each client adapts:
        - {name, description, parameters}
        
        Each provider client (OpenAI, Anthropic, etc.) is responsible
        for converting this to their specific format.
        
        Returns:
            List of tool definitions in canonical format
        """
        tools_schema = []
        
        for tool in self.tools.values():
            tools_schema.append({
                "name": tool.name,
                "description": tool.description,
                "parameters": tool.parameters,
            })
        
        return tools_schema
    
    async def run_stream(
        self,
        message: str,
        context: dict[str, Any] | None = None,
    ) -> AsyncIterator[str]:
        """Run the agent with streaming response.
        
        Args:
            message: User message to process
            context: Optional context dictionary
            
        Yields:
            Response chunks as they arrive
        """
        if not self.model_client:
            yield ""
            return
        
        # Add user message to memory
        user_message = Message(role="user", content=message)
        self.memory.append(user_message)
        
        # Build messages
        messages = self._build_messages()
        tools_schema = self._build_tools_schema() if self.tools else None
        
        # Stream response
        full_content = ""
        async for chunk in self.model_client.stream(messages, tools=tools_schema):
            full_content += chunk
            yield chunk
        
        # Add assistant response to memory
        assistant_message = Message(role="assistant", content=full_content)
        self.memory.append(assistant_message)
    
    async def _persist_message(self, message: Message) -> None:
        """Persist a message to the memory backend.
        
        Args:
            message: Message to persist
        """
        if not self.memory_backend:
            return
            
        from multi_agent_base.memory.base import MemoryEntry
        
        entry = MemoryEntry(
            role=message.role,
            content=message.content,
            metadata={
                "agent_name": self.name,
                "name": message.name,
                "tool_call_id": message.tool_call_id,
                **message.metadata,
            },
            timestamp=message.timestamp,
        )
        await self.memory_backend.add(entry)
    
    async def load_memory_context(self, query: str | None = None, limit: int = 10) -> list[Message]:
        """Load relevant context from memory backend.
        
        Args:
            query: Optional query for semantic search
            limit: Maximum entries to retrieve
            
        Returns:
            List of relevant messages
        """
        if not self.memory_backend:
            return []
        
        entries = await self.memory_backend.get_recent(limit=limit)
        
        return [
            Message(
                role=entry.role,
                content=entry.content,
                name=entry.metadata.get("name"),
                tool_call_id=entry.metadata.get("tool_call_id"),
                timestamp=entry.timestamp,
                metadata={k: v for k, v in entry.metadata.items() 
                         if k not in ["agent_name", "name", "tool_call_id"]},
            )
            for entry in entries
        ]
    
    async def search_memory(self, query: str, limit: int = 5) -> list[Message]:
        """Search memory backend for relevant entries.
        
        Args:
            query: Search query
            limit: Maximum results to return
            
        Returns:
            List of relevant messages
        """
        if not self.memory_backend:
            return []
        
        results = await self.memory_backend.search(query=query, limit=limit)
        
        return [
            Message(
                role=result.entry.role,
                content=result.entry.content,
                name=result.entry.metadata.get("name"),
                tool_call_id=result.entry.metadata.get("tool_call_id"),
                timestamp=result.entry.timestamp,
                metadata={
                    "relevance_score": result.score,
                    **{k: v for k, v in result.entry.metadata.items()
                       if k not in ["agent_name", "name", "tool_call_id"]},
                },
            )
            for result in results
        ]
    
    def clear_memory(self) -> None:
        """Clear the conversation memory, keeping only the system prompt."""
        system_messages = [m for m in self.memory if m.role == "system"]
        self.memory = system_messages
        
        # Clear memory backend asynchronously if available
        if self.memory_backend:
            asyncio.create_task(self.memory_backend.clear())
    
    async def clear_memory_async(self) -> None:
        """Clear the conversation memory asynchronously.
        
        This method properly awaits memory backend clearing.
        """
        system_messages = [m for m in self.memory if m.role == "system"]
        self.memory = system_messages
        
        if self.memory_backend:
            await self.memory_backend.clear()
    
    def get_memory(self) -> list[Message]:
        """Get the conversation memory.
        
        Returns:
            List of messages in memory
        """
        return list(self.memory)
    
    def generate_agent_card(self) -> AgentCard:
        """Generate an A2A Agent Card for this agent.
        
        Returns:
            AgentCard instance representing this agent
        """
        from multi_agent_base.a2a.agent_card import AgentCard, AgentCapabilities
        from multi_agent_base.a2a.skill_discovery import SkillDiscoverer
        
        # Discover skills from registered tools
        discoverer = SkillDiscoverer()
        skills = discoverer.discover_from_tools(
            [tool.function for tool in self.tools.values()]
        )
        
        # Build capabilities
        capabilities = AgentCapabilities(
            streaming=False,
            push_notifications=False,
            state_transition_history=True,
        )
        
        return AgentCard(
            name=self.name,
            description=self.config.description or f"Agent: {self.name}",
            url=f"local://{self.name}",
            version="1.0.0",
            capabilities=capabilities,
            skills=skills,
        )
    
    def __repr__(self) -> str:
        """String representation of the agent."""
        return f"BaseAgent(name={self.name!r}, tools={list(self.tools.keys())})"
