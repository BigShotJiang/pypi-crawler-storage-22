"""
Microsoft Agent Framework ChatHistoryProvider Adapter.

This module adapts our MemoryBackend implementations to work as
AF ChatHistoryProvider instances, enabling:

- Use of our advanced memory backends (Buffer, Vector, Redis, Summary)
- Seamless integration with AF's ChatAgent and Workflow sessions
- Persistence across AF workflow checkpoints

AF ChatHistoryProvider Interface:
- InvokingAsync: Called before agent invocation to retrieve history
- InvokedAsync: Called after agent invocation to store new messages

Our MemoryBackend Interface:
- add(): Add a memory entry
- get_recent(): Get recent entries
- search(): Semantic search
- get_context(): Get formatted messages for LLM

Usage:
    ```python
    from multi_agent_base.memory import VectorMemory
    from multi_agent_base.core.chat_history import MemoryBackendChatHistoryProvider
    
    # Create our advanced memory backend
    memory = VectorMemory(config=MemoryConfig(
        embedding_model="text-embedding-3-small",
        top_k=10,
    ))
    
    # Wrap as AF ChatHistoryProvider
    provider = MemoryBackendChatHistoryProvider(memory)
    
    # Use with AF ChatAgent
    session = ChatClientAgentSession(
        chat_history_provider=provider,
    )
    ```
"""

from __future__ import annotations

import asyncio
import json
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from typing import (
    TYPE_CHECKING,
    Any,
    Dict,
    Iterator,
    List,
    Optional,
    Sequence,
)

if TYPE_CHECKING:
    from multi_agent_base.memory.base import MemoryBackend, MemoryEntry, MemoryConfig


# =============================================================================
# AF ChatHistoryProvider Protocol (for compatibility without importing AF)
# =============================================================================


class ChatMessage:
    """Represents a chat message (AF-compatible)."""
    
    def __init__(
        self,
        role: str,
        content: str,
        message_id: str | None = None,
        author_name: str | None = None,
        created_at: datetime | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Initialize chat message.
        
        Args:
            role: Message role (user, assistant, system, tool)
            content: Message content
            message_id: Unique message identifier
            author_name: Name of the author (for multi-agent)
            created_at: When the message was created
            metadata: Additional metadata
        """
        self.role = role
        self.content = content
        self.text = content  # AF uses 'text'
        self.message_id = message_id or self._generate_id()
        self.author_name = author_name
        self.created_at = created_at or datetime.utcnow()
        self.metadata = metadata or {}
    
    def _generate_id(self) -> str:
        """Generate a unique message ID."""
        import uuid
        return str(uuid.uuid4())
    
    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "role": self.role,
            "content": self.content,
            "message_id": self.message_id,
            "author_name": self.author_name,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "metadata": self.metadata,
        }
    
    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ChatMessage":
        """Create from dictionary."""
        created_at = data.get("created_at")
        if isinstance(created_at, str):
            created_at = datetime.fromisoformat(created_at)
        
        return cls(
            role=data.get("role", "user"),
            content=data.get("content") or data.get("text", ""),
            message_id=data.get("message_id"),
            author_name=data.get("author_name"),
            created_at=created_at,
            metadata=data.get("metadata", {}),
        )
    
    def __repr__(self) -> str:
        return f"ChatMessage(role={self.role!r}, content={self.content[:50]!r}...)"


@dataclass
class InvokingContext:
    """Context for ChatHistoryProvider.InvokingAsync."""
    
    input_messages: Sequence[ChatMessage] = field(default_factory=list)
    
    def __init__(self, input_messages: Sequence[ChatMessage] | None = None):
        self.input_messages = list(input_messages or [])


@dataclass
class InvokedContext:
    """Context for ChatHistoryProvider.InvokedAsync."""
    
    request_messages: Sequence[ChatMessage] = field(default_factory=list)
    response_messages: Sequence[ChatMessage] = field(default_factory=list)
    ai_context_provider_messages: Sequence[ChatMessage] | None = None
    invoke_exception: Exception | None = None
    
    def __init__(
        self,
        request_messages: Sequence[ChatMessage] | None = None,
        response_messages: Sequence[ChatMessage] | None = None,
        ai_context_provider_messages: Sequence[ChatMessage] | None = None,
        invoke_exception: Exception | None = None,
    ):
        self.request_messages = list(request_messages or [])
        self.response_messages = list(response_messages or [])
        self.ai_context_provider_messages = ai_context_provider_messages
        self.invoke_exception = invoke_exception


class ChatHistoryProvider(ABC):
    """Abstract base class for chat history providers (AF-compatible).
    
    This matches AF's ChatHistoryProvider interface, allowing our
    implementations to be used directly with AF agents.
    """
    
    @abstractmethod
    async def invoking_async(
        self,
        context: InvokingContext,
    ) -> Sequence[ChatMessage]:
        """Called before agent invocation to retrieve chat history.
        
        Args:
            context: Invoking context with input messages
            
        Returns:
            Sequence of historical messages to include
        """
        pass
    
    @abstractmethod
    async def invoked_async(
        self,
        context: InvokedContext,
    ) -> None:
        """Called after agent invocation to store new messages.
        
        Args:
            context: Invoked context with request/response messages
        """
        pass
    
    async def add_messages(
        self,
        messages: Sequence[ChatMessage],
    ) -> None:
        """Add messages to history (convenience method).
        
        Args:
            messages: Messages to add
        """
        # Default: store via invoked_async
        await self.invoked_async(InvokedContext(
            request_messages=messages,
        ))
    
    def serialize(self) -> dict[str, Any]:
        """Serialize provider state for checkpointing.
        
        Returns:
            Serialized state dict
        """
        return {}
    
    @classmethod
    def deserialize(cls, state: dict[str, Any]) -> "ChatHistoryProvider":
        """Deserialize provider from checkpoint state.
        
        Args:
            state: Serialized state dict
            
        Returns:
            Restored provider instance
        """
        raise NotImplementedError()


# =============================================================================
# Memory Backend Adapters
# =============================================================================


class MemoryBackendChatHistoryProvider(ChatHistoryProvider):
    """Adapts our MemoryBackend to AF's ChatHistoryProvider interface.
    
    This allows using our advanced memory backends (Buffer, Vector, Redis,
    Summary, Composite) with AF's ChatAgent and Workflow sessions.
    
    Features:
    - Automatic conversion between MemoryEntry and ChatMessage
    - Session-scoped history
    - Serialization for workflow checkpoints
    - Semantic search for relevant context (with VectorMemory)
    
    Example:
        ```python
        from multi_agent_base.memory import BufferMemory, VectorMemory
        
        # Simple buffer memory
        buffer_provider = MemoryBackendChatHistoryProvider(
            BufferMemory(max_messages=100)
        )
        
        # Vector memory with semantic search
        vector_provider = MemoryBackendChatHistoryProvider(
            VectorMemory(config=MemoryConfig(top_k=10)),
            use_semantic_search=True,
        )
        ```
    """
    
    def __init__(
        self,
        backend: "MemoryBackend",
        session_id: str | None = None,
        agent_name: str | None = None,
        use_semantic_search: bool = False,
        max_history_messages: int | None = None,
    ) -> None:
        """Initialize adapter.
        
        Args:
            backend: Memory backend to adapt
            session_id: Session identifier for scoping
            agent_name: Agent name for scoping
            use_semantic_search: Use semantic search for context retrieval
            max_history_messages: Maximum messages to return in history
        """
        self._backend = backend
        self._session_id = session_id
        self._agent_name = agent_name
        self._use_semantic_search = use_semantic_search
        self._max_history = max_history_messages
    
    async def invoking_async(
        self,
        context: InvokingContext,
    ) -> Sequence[ChatMessage]:
        """Retrieve chat history for agent invocation.
        
        If semantic search is enabled and there are input messages,
        uses the last user message to find relevant history.
        Otherwise, returns recent messages.
        """
        # Determine query for semantic search
        query = None
        if self._use_semantic_search and context.input_messages:
            # Use last user message as query
            for msg in reversed(context.input_messages):
                if msg.role == "user":
                    query = msg.content
                    break
        
        # Get entries from backend
        if query and self._use_semantic_search:
            entries = await self._backend.search(
                query=query,
                k=self._max_history,
                session_id=self._session_id,
                agent_name=self._agent_name,
            )
        else:
            entries = await self._backend.get_recent(
                limit=self._max_history,
                session_id=self._session_id,
                agent_name=self._agent_name,
            )
        
        # Convert to ChatMessages
        messages = [self._entry_to_message(entry) for entry in entries]
        
        return messages
    
    async def invoked_async(
        self,
        context: InvokedContext,
    ) -> None:
        """Store new messages after agent invocation.
        
        Stores both request and response messages, skipping if
        there was an exception.
        """
        if context.invoke_exception is not None:
            return
        
        # Collect all messages to store
        all_messages = list(context.request_messages)
        if context.ai_context_provider_messages:
            all_messages.extend(context.ai_context_provider_messages)
        all_messages.extend(context.response_messages)
        
        # Store each message
        for msg in all_messages:
            await self._backend.add(
                role=msg.role,
                content=msg.content,
                agent_name=self._agent_name or msg.author_name,
                session_id=self._session_id,
                metadata={
                    "message_id": msg.message_id,
                    "created_at": msg.created_at.isoformat() if msg.created_at else None,
                    **msg.metadata,
                },
            )
    
    async def add_messages(
        self,
        messages: Sequence[ChatMessage],
    ) -> None:
        """Add messages to history."""
        for msg in messages:
            await self._backend.add(
                role=msg.role,
                content=msg.content,
                agent_name=self._agent_name or msg.author_name,
                session_id=self._session_id,
                metadata={
                    "message_id": msg.message_id,
                    **msg.metadata,
                },
            )
    
    def serialize(self) -> dict[str, Any]:
        """Serialize provider state for checkpointing."""
        return {
            "provider_type": "MemoryBackendChatHistoryProvider",
            "backend_type": self._backend.__class__.__name__,
            "session_id": self._session_id,
            "agent_name": self._agent_name,
            "use_semantic_search": self._use_semantic_search,
            "max_history": self._max_history,
            # Note: Backend state would need its own serialization
        }
    
    def _entry_to_message(self, entry: "MemoryEntry") -> ChatMessage:
        """Convert MemoryEntry to ChatMessage."""
        return ChatMessage(
            role=entry.role,
            content=entry.content,
            message_id=entry.id,
            author_name=entry.agent_name,
            created_at=entry.timestamp,
            metadata=entry.metadata,
        )
    
    def _message_to_entry_data(self, msg: ChatMessage) -> dict[str, Any]:
        """Convert ChatMessage to entry data dict."""
        return {
            "role": msg.role,
            "content": msg.content,
            "agent_name": msg.author_name,
            "metadata": {
                "message_id": msg.message_id,
                **msg.metadata,
            },
        }


class InMemoryChatHistoryProvider(ChatHistoryProvider):
    """Simple in-memory chat history provider.
    
    Stores messages in memory. Useful for testing or short-lived sessions.
    
    Example:
        ```python
        provider = InMemoryChatHistoryProvider(max_messages=100)
        ```
    """
    
    def __init__(
        self,
        max_messages: int | None = None,
        messages: Sequence[ChatMessage] | None = None,
    ) -> None:
        """Initialize provider.
        
        Args:
            max_messages: Maximum messages to retain
            messages: Initial messages
        """
        self._messages: list[ChatMessage] = list(messages or [])
        self._max_messages = max_messages
        self._bookmark = 0
    
    async def invoking_async(
        self,
        context: InvokingContext,
    ) -> Sequence[ChatMessage]:
        """Return all stored messages."""
        return list(self._messages)
    
    async def invoked_async(
        self,
        context: InvokedContext,
    ) -> None:
        """Store new messages."""
        if context.invoke_exception is not None:
            return
        
        # Collect all messages
        all_messages = list(context.request_messages)
        if context.ai_context_provider_messages:
            all_messages.extend(context.ai_context_provider_messages)
        all_messages.extend(context.response_messages)
        
        self._messages.extend(all_messages)
        
        # Trim if needed
        if self._max_messages and len(self._messages) > self._max_messages:
            self._messages = self._messages[-self._max_messages:]
    
    async def add_messages(
        self,
        messages: Sequence[ChatMessage],
    ) -> None:
        """Add messages to history."""
        self._messages.extend(messages)
        
        if self._max_messages and len(self._messages) > self._max_messages:
            self._messages = self._messages[-self._max_messages:]
    
    def get_from_bookmark(self) -> Iterator[ChatMessage]:
        """Get messages since last bookmark."""
        for i in range(self._bookmark, len(self._messages)):
            yield self._messages[i]
    
    def update_bookmark(self) -> None:
        """Update bookmark to current position."""
        self._bookmark = len(self._messages)
    
    def clear(self) -> None:
        """Clear all messages."""
        self._messages.clear()
        self._bookmark = 0
    
    def serialize(self) -> dict[str, Any]:
        """Serialize provider state."""
        return {
            "provider_type": "InMemoryChatHistoryProvider",
            "messages": [msg.to_dict() for msg in self._messages],
            "bookmark": self._bookmark,
            "max_messages": self._max_messages,
        }
    
    @classmethod
    def deserialize(cls, state: dict[str, Any]) -> "InMemoryChatHistoryProvider":
        """Deserialize from state."""
        messages = [
            ChatMessage.from_dict(m)
            for m in state.get("messages", [])
        ]
        provider = cls(
            max_messages=state.get("max_messages"),
            messages=messages,
        )
        provider._bookmark = state.get("bookmark", 0)
        return provider
    
    def __len__(self) -> int:
        return len(self._messages)
    
    def __iter__(self) -> Iterator[ChatMessage]:
        return iter(self._messages)


class SlidingWindowChatHistoryProvider(InMemoryChatHistoryProvider):
    """Chat history provider with sliding window.
    
    Maintains a sliding window of the most recent messages,
    optionally keeping the system message.
    
    Example:
        ```python
        provider = SlidingWindowChatHistoryProvider(
            window_size=50,
            preserve_system=True,
        )
        ```
    """
    
    def __init__(
        self,
        window_size: int = 50,
        preserve_system: bool = True,
        messages: Sequence[ChatMessage] | None = None,
    ) -> None:
        """Initialize provider.
        
        Args:
            window_size: Number of messages to keep in window
            preserve_system: Always keep system messages at the start
            messages: Initial messages
        """
        super().__init__(max_messages=None, messages=messages)
        self._window_size = window_size
        self._preserve_system = preserve_system
    
    async def invoking_async(
        self,
        context: InvokingContext,
    ) -> Sequence[ChatMessage]:
        """Return windowed messages."""
        return self._get_windowed_messages()
    
    def _get_windowed_messages(self) -> list[ChatMessage]:
        """Get messages within the sliding window."""
        if not self._messages:
            return []
        
        # Separate system messages and others
        system_messages = []
        other_messages = []
        
        for msg in self._messages:
            if self._preserve_system and msg.role == "system":
                system_messages.append(msg)
            else:
                other_messages.append(msg)
        
        # Apply window to non-system messages
        if len(other_messages) > self._window_size:
            other_messages = other_messages[-self._window_size:]
        
        # Combine: system messages first, then windowed messages
        return system_messages + other_messages


class TokenLimitedChatHistoryProvider(InMemoryChatHistoryProvider):
    """Chat history provider with token limit.
    
    Keeps as many messages as fit within a token budget,
    using a simple token counting heuristic.
    
    Example:
        ```python
        provider = TokenLimitedChatHistoryProvider(
            max_tokens=4000,
            preserve_system=True,
        )
        ```
    """
    
    def __init__(
        self,
        max_tokens: int = 4000,
        preserve_system: bool = True,
        messages: Sequence[ChatMessage] | None = None,
    ) -> None:
        """Initialize provider.
        
        Args:
            max_tokens: Maximum tokens for context
            preserve_system: Always keep system messages
            messages: Initial messages
        """
        super().__init__(max_messages=None, messages=messages)
        self._max_tokens = max_tokens
        self._preserve_system = preserve_system
    
    async def invoking_async(
        self,
        context: InvokingContext,
    ) -> Sequence[ChatMessage]:
        """Return token-limited messages."""
        return self._get_token_limited_messages()
    
    def _get_token_limited_messages(self) -> list[ChatMessage]:
        """Get messages within token limit."""
        if not self._messages:
            return []
        
        # Separate system messages
        system_messages = []
        other_messages = []
        
        for msg in self._messages:
            if self._preserve_system and msg.role == "system":
                system_messages.append(msg)
            else:
                other_messages.append(msg)
        
        # Count tokens for system messages
        system_tokens = sum(self._estimate_tokens(msg) for msg in system_messages)
        remaining_tokens = self._max_tokens - system_tokens
        
        # Add messages from most recent, staying within budget
        selected = []
        for msg in reversed(other_messages):
            msg_tokens = self._estimate_tokens(msg)
            if remaining_tokens >= msg_tokens:
                selected.insert(0, msg)
                remaining_tokens -= msg_tokens
            else:
                break
        
        return system_messages + selected
    
    def _estimate_tokens(self, msg: ChatMessage) -> int:
        """Estimate token count for a message.
        
        Uses a simple heuristic: ~4 characters per token.
        """
        return len(msg.content) // 4 + 3  # +3 for role overhead


# =============================================================================
# Factory Functions
# =============================================================================


def create_chat_history_provider(
    provider_type: str = "in_memory",
    **kwargs: Any,
) -> ChatHistoryProvider:
    """Factory function to create chat history providers.
    
    Args:
        provider_type: Type of provider to create
        **kwargs: Provider-specific arguments
        
    Returns:
        Configured ChatHistoryProvider
        
    Supported types:
        - "in_memory": Simple in-memory storage
        - "sliding_window": Sliding window of recent messages
        - "token_limited": Token-budget limited storage
        - "buffer_memory": Our BufferMemory backend
        - "vector_memory": Our VectorMemory backend
        - "redis_memory": Our RedisMemory backend
    
    Example:
        ```python
        # Simple in-memory
        provider = create_chat_history_provider("in_memory", max_messages=100)
        
        # With our vector memory
        provider = create_chat_history_provider(
            "vector_memory",
            embedding_model="text-embedding-3-small",
            use_semantic_search=True,
        )
        ```
    """
    if provider_type == "in_memory":
        return InMemoryChatHistoryProvider(
            max_messages=kwargs.get("max_messages"),
        )
    
    elif provider_type == "sliding_window":
        return SlidingWindowChatHistoryProvider(
            window_size=kwargs.get("window_size", 50),
            preserve_system=kwargs.get("preserve_system", True),
        )
    
    elif provider_type == "token_limited":
        return TokenLimitedChatHistoryProvider(
            max_tokens=kwargs.get("max_tokens", 4000),
            preserve_system=kwargs.get("preserve_system", True),
        )
    
    elif provider_type == "buffer_memory":
        try:
            from multi_agent_base.memory.buffer import BufferMemory
            from multi_agent_base.memory.base import MemoryConfig
            
            config = MemoryConfig(
                max_messages=kwargs.get("max_messages", 100),
            )
            backend = BufferMemory(config=config)
            
            return MemoryBackendChatHistoryProvider(
                backend=backend,
                session_id=kwargs.get("session_id"),
                agent_name=kwargs.get("agent_name"),
            )
        except ImportError as e:
            raise ImportError(f"BufferMemory not available: {e}")
    
    elif provider_type == "vector_memory":
        try:
            from multi_agent_base.memory.vector import VectorMemory
            from multi_agent_base.memory.base import MemoryConfig
            
            config = MemoryConfig(
                embedding_model=kwargs.get("embedding_model", "text-embedding-3-small"),
                embedding_dimensions=kwargs.get("embedding_dimensions", 1536),
                top_k=kwargs.get("top_k", 10),
            )
            backend = VectorMemory(config=config)
            
            return MemoryBackendChatHistoryProvider(
                backend=backend,
                session_id=kwargs.get("session_id"),
                agent_name=kwargs.get("agent_name"),
                use_semantic_search=kwargs.get("use_semantic_search", True),
                max_history_messages=kwargs.get("max_history_messages"),
            )
        except ImportError as e:
            raise ImportError(f"VectorMemory not available: {e}")
    
    elif provider_type == "redis_memory":
        try:
            from multi_agent_base.memory.redis_backend import RedisMemory
            from multi_agent_base.memory.base import MemoryConfig
            
            config = MemoryConfig(
                redis_url=kwargs.get("redis_url"),
                redis_prefix=kwargs.get("redis_prefix", "chat_history"),
                ttl_seconds=kwargs.get("ttl_seconds"),
            )
            backend = RedisMemory(config=config)
            
            return MemoryBackendChatHistoryProvider(
                backend=backend,
                session_id=kwargs.get("session_id"),
                agent_name=kwargs.get("agent_name"),
            )
        except ImportError as e:
            raise ImportError(f"RedisMemory not available: {e}")
    
    else:
        raise ValueError(f"Unknown provider type: {provider_type}")


# Convenience aliases
AFChatHistoryProvider = ChatHistoryProvider
AFChatMessage = ChatMessage
AFInMemoryChatHistoryProvider = InMemoryChatHistoryProvider
