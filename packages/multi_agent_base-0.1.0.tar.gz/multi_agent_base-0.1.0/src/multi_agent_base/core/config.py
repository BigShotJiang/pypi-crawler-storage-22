"""
Configuration models for the Multi-Agent Base framework.

This module provides Pydantic models for:
- SystemConfig: Main system configuration
- ProviderConfig: LLM provider settings
- AgentConfig: Individual agent configuration
- ObservabilityConfig: Phoenix/tracing settings
"""

from enum import Enum
from typing import Any, Literal

from pydantic import BaseModel, Field, field_validator


class ProviderType(str, Enum):
    """Supported LLM providers."""
    
    OLLAMA = "ollama"
    OPENAI = "openai"
    ANTHROPIC = "anthropic"


class PatternType(str, Enum):
    """Supported agent architecture patterns."""
    
    SINGLE_AGENT = "single_agent"
    SUPERVISOR = "supervisor"
    SWARM = "swarm"
    PIPELINE = "pipeline"
    PARALLEL = "parallel"
    ROUTER = "router"
    REFLECTION = "reflection"
    BLACKBOARD = "blackboard"
    COMPOSITE = "composite"
    DEBATE = "debate"
    HIERARCHICAL = "hierarchical"
    ENSEMBLE = "ensemble"
    SELF_HEALING = "self_healing"


class ProviderConfig(BaseModel):
    """Configuration for an LLM provider.
    
    Attributes:
        provider: The LLM provider type (ollama, openai, anthropic)
        model: The model name/identifier
        api_key: API key for the provider (optional for Ollama)
        base_url: Base URL for the API endpoint
        temperature: Sampling temperature (0.0-2.0)
        max_tokens: Maximum tokens in response
        timeout: Request timeout in seconds
        extra_params: Additional provider-specific parameters
    """
    
    provider: ProviderType = Field(
        default=ProviderType.OLLAMA,
        description="The LLM provider to use"
    )
    model: str = Field(
        default="llama3.2",
        description="Model name or identifier"
    )
    api_key: str | None = Field(
        default=None,
        description="API key (not needed for Ollama)"
    )
    base_url: str | None = Field(
        default=None,
        description="Custom base URL for API"
    )
    temperature: float = Field(
        default=0.7,
        ge=0.0,
        le=2.0,
        description="Sampling temperature"
    )
    max_tokens: int = Field(
        default=4096,
        gt=0,
        description="Maximum tokens in response"
    )
    timeout: int = Field(
        default=120,
        gt=0,
        description="Request timeout in seconds"
    )
    extra_params: dict[str, Any] = Field(
        default_factory=dict,
        description="Additional provider-specific parameters"
    )
    
    @field_validator("base_url", mode="before")
    @classmethod
    def set_default_base_url(cls, v: str | None, info) -> str | None:
        """Set default base URL based on provider if not specified."""
        if v is not None:
            return v
        
        provider = info.data.get("provider")
        if provider == ProviderType.OLLAMA:
            return "http://localhost:11434"
        return None

    model_config = {"use_enum_values": True}


class ObservabilityConfig(BaseModel):
    """Configuration for observability and tracing.
    
    Attributes:
        enabled: Whether observability is enabled
        phoenix_endpoint: Phoenix collector endpoint
        project_name: Project name for grouping traces
        log_level: Logging level
        trace_tool_calls: Whether to trace tool/function calls
        trace_llm_calls: Whether to trace LLM API calls
        trace_agent_messages: Whether to trace agent messages
        export_spans: Whether to export spans to Phoenix
    """
    
    enabled: bool = Field(
        default=True,
        description="Enable observability features"
    )
    phoenix_endpoint: str = Field(
        default="http://localhost:6006",
        description="Phoenix collector endpoint"
    )
    project_name: str = Field(
        default="multi-agent-base",
        description="Project name for trace grouping"
    )
    log_level: Literal["DEBUG", "INFO", "WARNING", "ERROR"] = Field(
        default="INFO",
        description="Logging level"
    )
    trace_tool_calls: bool = Field(
        default=True,
        description="Trace tool/function calls"
    )
    trace_llm_calls: bool = Field(
        default=True,
        description="Trace LLM API calls"
    )
    trace_agent_messages: bool = Field(
        default=True,
        description="Trace agent messages"
    )
    export_spans: bool = Field(
        default=True,
        description="Export spans to Phoenix"
    )


class AgentConfig(BaseModel):
    """Configuration for an individual agent.
    
    Attributes:
        name: Unique identifier for the agent
        description: Human-readable description
        system_prompt: System prompt/instructions for the agent
        tools: List of tool names available to this agent
        provider_override: Override default provider settings
        max_iterations: Maximum reasoning iterations
        enable_memory: Whether to enable conversation memory
        metadata: Additional metadata for the agent
    """
    
    name: str = Field(
        ...,
        min_length=1,
        max_length=100,
        description="Unique agent identifier"
    )
    description: str = Field(
        default="",
        max_length=500,
        description="Agent description"
    )
    system_prompt: str = Field(
        default="You are a helpful AI assistant.",
        description="System prompt for the agent"
    )
    tools: list[str] = Field(
        default_factory=list,
        description="List of available tool names"
    )
    provider_override: ProviderConfig | None = Field(
        default=None,
        description="Override default provider for this agent"
    )
    max_iterations: int = Field(
        default=10,
        gt=0,
        le=100,
        description="Maximum reasoning iterations"
    )
    enable_memory: bool = Field(
        default=True,
        description="Enable conversation memory"
    )
    metadata: dict[str, Any] = Field(
        default_factory=dict,
        description="Additional agent metadata"
    )

    @field_validator("name")
    @classmethod
    def validate_name(cls, v: str) -> str:
        """Validate agent name follows naming conventions."""
        if not v.replace("-", "").replace("_", "").isalnum():
            raise ValueError("Agent name must be alphanumeric with hyphens/underscores only")
        return v.lower()


class PatternConfig(BaseModel):
    """Configuration for agent orchestration patterns.
    
    Attributes:
        pattern_type: The type of agent pattern (single, supervisor, swarm, etc.)
        agents: List of agent configurations for multi-agent patterns
        supervisor_name: Name of the supervisor agent (for supervisor pattern)
        max_iterations: Maximum iterations for iterative patterns
        allow_handoffs: Whether agents can hand off to each other
        router_model: Model for routing decisions (router pattern)
        parallel_max_workers: Max concurrent workers for parallel pattern
        metadata: Additional pattern-specific metadata
    """
    
    pattern_type: str = Field(
        default="single",
        description="Agent pattern type"
    )
    agents: list[AgentConfig] = Field(
        default_factory=list,
        description="List of agent configurations"
    )
    supervisor_name: str | None = Field(
        default=None,
        description="Supervisor agent name"
    )
    max_iterations: int = Field(
        default=10,
        gt=0,
        description="Maximum iterations"
    )
    allow_handoffs: bool = Field(
        default=True,
        description="Allow agent handoffs"
    )
    router_model: str | None = Field(
        default=None,
        description="Model for routing decisions"
    )
    parallel_max_workers: int = Field(
        default=5,
        gt=0,
        description="Max parallel workers"
    )
    metadata: dict[str, Any] = Field(
        default_factory=dict,
        description="Additional pattern metadata"
    )
    
    @field_validator("pattern_type")
    @classmethod
    def validate_pattern_type(cls, v: str) -> str:
        """Validate pattern type is supported."""
        valid_types = {
            "single", "single_agent", "supervisor", "swarm", 
            "pipeline", "parallel", "router", "reflection",
            "blackboard", "composite", "debate"
        }
        if v.lower() not in valid_types:
            raise ValueError(f"Pattern type must be one of: {valid_types}")
        return v.lower()


class CostTrackingConfig(BaseModel):
    """Configuration for cost tracking.
    
    Attributes:
        enabled: Whether cost tracking is enabled
        track_tokens: Track token usage
        track_costs: Calculate costs based on pricing
        persist_records: Persist usage records to file
        records_path: Path for persisting records
    """
    
    enabled: bool = Field(
        default=True,
        description="Enable cost tracking"
    )
    track_tokens: bool = Field(
        default=True,
        description="Track token usage"
    )
    track_costs: bool = Field(
        default=True,
        description="Calculate monetary costs"
    )
    persist_records: bool = Field(
        default=False,
        description="Persist records to file"
    )
    records_path: str = Field(
        default="./cost_records.jsonl",
        description="Path for persisting records"
    )


class MemoryBackendType(str, Enum):
    """Supported memory backend types."""
    
    IN_MEMORY = "in_memory"
    BUFFER = "buffer"
    SLIDING_WINDOW = "sliding_window"
    SUMMARY = "summary"
    VECTOR = "vector"
    REDIS = "redis"
    COMPOSITE = "composite"


class MemoryConfig(BaseModel):
    """Configuration for conversation memory.
    
    Attributes:
        enabled: Whether memory is enabled
        backend: Memory backend type
        max_entries: Maximum entries for buffer memory
        max_tokens: Maximum tokens for sliding window
        persist: Whether to persist memory
        redis_url: Redis connection URL (for redis backend)
        ttl_seconds: Time-to-live for entries (optional)
        vector_collection: Collection name for vector memory
    """
    
    enabled: bool = Field(
        default=True,
        description="Enable conversation memory"
    )
    backend: MemoryBackendType = Field(
        default=MemoryBackendType.IN_MEMORY,
        description="Memory backend type"
    )
    max_entries: int = Field(
        default=100,
        gt=0,
        description="Maximum entries for buffer memory"
    )
    max_tokens: int = Field(
        default=4000,
        gt=0,
        description="Maximum tokens for sliding window"
    )
    persist: bool = Field(
        default=False,
        description="Persist memory to storage"
    )
    redis_url: str | None = Field(
        default=None,
        description="Redis connection URL"
    )
    ttl_seconds: int | None = Field(
        default=None,
        gt=0,
        description="Time-to-live for entries"
    )
    vector_collection: str = Field(
        default="agent_memory",
        description="Collection name for vector memory"
    )

    model_config = {"use_enum_values": True}


class BackoffStrategy(str, Enum):
    """Backoff strategies for retry."""
    
    CONSTANT = "constant"
    LINEAR = "linear"
    EXPONENTIAL = "exponential"
    EXPONENTIAL_JITTER = "exponential_jitter"


class ResilienceConfig(BaseModel):
    """Configuration for resilience patterns (retry, circuit breaker, etc).
    
    Attributes:
        enabled: Whether resilience is enabled
        retry_enabled: Enable retry mechanism
        max_retries: Maximum retry attempts
        retry_delay: Initial delay between retries (seconds)
        backoff_strategy: Backoff strategy for retries
        circuit_breaker_enabled: Enable circuit breaker
        failure_threshold: Failures before opening circuit
        reset_timeout: Seconds before attempting to close circuit
        timeout_seconds: Request timeout in seconds
        fallback_enabled: Enable fallback mechanism
    """
    
    enabled: bool = Field(
        default=True,
        description="Enable resilience features"
    )
    retry_enabled: bool = Field(
        default=True,
        description="Enable retry mechanism"
    )
    max_retries: int = Field(
        default=3,
        ge=0,
        le=10,
        description="Maximum retry attempts"
    )
    retry_delay: float = Field(
        default=1.0,
        ge=0.0,
        description="Initial delay between retries"
    )
    backoff_strategy: BackoffStrategy = Field(
        default=BackoffStrategy.EXPONENTIAL_JITTER,
        description="Backoff strategy for retries"
    )
    circuit_breaker_enabled: bool = Field(
        default=True,
        description="Enable circuit breaker"
    )
    failure_threshold: int = Field(
        default=5,
        ge=1,
        description="Failures before opening circuit"
    )
    reset_timeout: float = Field(
        default=60.0,
        gt=0,
        description="Seconds before attempting to close circuit"
    )
    timeout_seconds: float = Field(
        default=120.0,
        gt=0,
        description="Request timeout in seconds"
    )
    fallback_enabled: bool = Field(
        default=False,
        description="Enable fallback mechanism"
    )

    model_config = {"use_enum_values": True}


class SystemConfig(BaseModel):
    """Main system configuration for Multi-Agent Base.
    
    This is the primary configuration object that combines all
    settings for the multi-agent system.
    
    Attributes:
        pattern: The agent architecture pattern to use
        provider: Default LLM provider configuration
        observability: Observability/tracing configuration
        cost_tracking: Cost tracking configuration
        agents: List of agent configurations
        default_system_prompt: Default system prompt for agents
        retry_attempts: Number of retry attempts for failed operations
        retry_delay: Delay between retries in seconds
    
    Example:
        ```python
        config = SystemConfig(
            pattern=PatternType.SUPERVISOR,
            provider=ProviderConfig(
                provider=ProviderType.OPENAI,
                model="gpt-4o-mini",
                api_key="sk-..."
            ),
            observability=ObservabilityConfig(enabled=True),
        )
        ```
    """
    
    pattern: PatternType = Field(
        default=PatternType.SINGLE_AGENT,
        description="Agent architecture pattern"
    )
    pattern_config: PatternConfig = Field(
        default_factory=PatternConfig,
        description="Pattern configuration details"
    )
    provider: ProviderConfig = Field(
        default_factory=ProviderConfig,
        description="Default LLM provider configuration"
    )
    observability: ObservabilityConfig = Field(
        default_factory=ObservabilityConfig,
        description="Observability configuration"
    )
    cost_tracking: CostTrackingConfig = Field(
        default_factory=CostTrackingConfig,
        description="Cost tracking configuration"
    )
    memory: MemoryConfig = Field(
        default_factory=MemoryConfig,
        description="Memory configuration"
    )
    resilience: ResilienceConfig = Field(
        default_factory=ResilienceConfig,
        description="Resilience configuration"
    )
    agents: list[AgentConfig] = Field(
        default_factory=list,
        description="Agent configurations"
    )
    default_system_prompt: str = Field(
        default="You are a helpful AI assistant.",
        description="Default system prompt"
    )
    retry_attempts: int = Field(
        default=3,
        ge=0,
        le=10,
        description="Retry attempts for failed operations"
    )
    retry_delay: float = Field(
        default=1.0,
        ge=0.0,
        description="Delay between retries in seconds"
    )

    model_config = {"use_enum_values": True}

    @classmethod
    def from_env(cls) -> "SystemConfig":
        """Create configuration from environment variables.
        
        Reads the following environment variables:
        - MULTI_AGENT_PROVIDER: Provider type (ollama, openai, anthropic)
        - MULTI_AGENT_MODEL: Model name
        - OPENAI_API_KEY: OpenAI API key
        - ANTHROPIC_API_KEY: Anthropic API key
        - OLLAMA_BASE_URL: Ollama base URL
        - PHOENIX_ENDPOINT: Phoenix collector endpoint
        
        Returns:
            SystemConfig instance configured from environment
        """
        import os
        from dotenv import load_dotenv
        
        load_dotenv()
        
        provider_type = os.getenv("MULTI_AGENT_PROVIDER", "ollama")
        model = os.getenv("MULTI_AGENT_MODEL", "llama3.2")
        
        api_key = None
        if provider_type == "openai":
            api_key = os.getenv("OPENAI_API_KEY")
        elif provider_type == "anthropic":
            api_key = os.getenv("ANTHROPIC_API_KEY")
        
        base_url = None
        if provider_type == "ollama":
            base_url = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
        
        provider_config = ProviderConfig(
            provider=ProviderType(provider_type),
            model=model,
            api_key=api_key,
            base_url=base_url,
        )
        
        observability_config = ObservabilityConfig(
            enabled=os.getenv("OBSERVABILITY_ENABLED", "true").lower() == "true",
            phoenix_endpoint=os.getenv("PHOENIX_ENDPOINT", "http://localhost:6006"),
            project_name=os.getenv("PROJECT_NAME", "multi-agent-base"),
        )
        
        return cls(
            provider=provider_config,
            observability=observability_config,
        )


def load_config(path: str) -> SystemConfig:
    """Load configuration from a JSON or YAML file.
    
    Args:
        path: Path to configuration file
        
    Returns:
        SystemConfig instance
        
    Raises:
        FileNotFoundError: If config file doesn't exist
        ValueError: If config format is invalid
    """
    import json
    from pathlib import Path
    
    config_path = Path(path)
    
    if not config_path.exists():
        raise FileNotFoundError(f"Config file not found: {path}")
    
    with open(config_path, "r") as f:
        if config_path.suffix in (".yaml", ".yml"):
            try:
                import yaml
                data = yaml.safe_load(f)
            except ImportError:
                raise ImportError("PyYAML required for YAML config files")
        else:
            data = json.load(f)
    
    return SystemConfig(**data)


def save_config(config: SystemConfig, path: str) -> None:
    """Save configuration to a JSON file.
    
    Args:
        config: SystemConfig instance to save
        path: Path to save configuration to
    """
    import json
    from pathlib import Path
    
    config_path = Path(path)
    config_path.parent.mkdir(parents=True, exist_ok=True)
    
    with open(config_path, "w") as f:
        json.dump(config.model_dump(), f, indent=2, default=str)
