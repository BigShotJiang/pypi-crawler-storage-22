"""
Decorator-based Tool Definitions for Multi-Agent Framework.

Provides convenient decorators for creating tools from functions:
- @tool - Create a tool from a sync/async function
- @action - Create an action with confirmation support
- @async_tool - Explicitly mark as async tool

Usage:
```python
from multi_agent_base.core.decorators import tool, action

@tool(category="math", tags=["calculation"])
def add(a: int, b: int) -> int:
    '''Add two numbers together.'''
    return a + b

@action(requires_confirmation=True)
async def delete_file(path: str) -> bool:
    '''Delete a file from disk.'''
    os.remove(path)
    return True

# Tools are automatically registered if auto_register=True
# Or manually register:
from multi_agent_base.core.registry import get_registry
get_registry().register(add)
```
"""

from typing import Any, Callable, TypeVar, ParamSpec, overload
from functools import wraps
import asyncio
import inspect

from multi_agent_base.core.tools import (
    BaseTool,
    FunctionTool,
    ActionTool,
    ToolResult,
    ToolParameter,
)
from multi_agent_base.core.registry import ToolRegistry

P = ParamSpec('P')
R = TypeVar('R')


def tool(
    func: Callable[P, R] | None = None,
    *,
    name: str | None = None,
    description: str | None = None,
    category: str = "general",
    tags: list[str] | None = None,
    timeout_seconds: float = 30.0,
    retry_count: int = 0,
    auto_register: bool = False,
    namespace: str = "default",
) -> Callable[P, R] | Callable[[Callable[P, R]], Callable[P, R]]:
    """
    Decorator to create a tool from a function.
    
    Can be used with or without arguments:
    
    ```python
    @tool
    def simple_tool(x: int) -> int:
        return x * 2
    
    @tool(category="math", tags=["arithmetic"])
    def add(a: int, b: int) -> int:
        return a + b
    ```
    
    Args:
        func: The function to wrap (when used without parentheses)
        name: Tool name (defaults to function name)
        description: Tool description (defaults to docstring)
        category: Tool category for organization
        tags: List of tags for filtering
        timeout_seconds: Execution timeout
        retry_count: Number of retries on failure
        auto_register: If True, register with global registry
        namespace: Namespace for auto-registration
    
    Returns:
        Decorated function with .tool attribute containing the BaseTool
    """
    
    def decorator(fn: Callable[P, R]) -> Callable[P, R]:
        # Create the tool
        tool_instance = FunctionTool.from_function(
            fn,
            name=name,
            description=description,
            category=category,
            tags=tags,
            timeout_seconds=timeout_seconds,
            retry_count=retry_count,
        )
        
        # Auto-register if requested
        if auto_register:
            registry = ToolRegistry.get_global()
            registry.register(tool_instance, namespace=namespace)
        
        # Wrap the function to preserve original behavior
        if asyncio.iscoroutinefunction(fn):
            @wraps(fn)
            async def async_wrapper(*args: P.args, **kwargs: P.kwargs) -> R:
                return await fn(*args, **kwargs)
            wrapper = async_wrapper
        else:
            @wraps(fn)
            def sync_wrapper(*args: P.args, **kwargs: P.kwargs) -> R:
                return fn(*args, **kwargs)
            wrapper = sync_wrapper
        
        # Attach tool to function for access
        wrapper.tool = tool_instance  # type: ignore
        wrapper.as_tool = lambda: tool_instance  # type: ignore
        
        return wrapper  # type: ignore
    
    # Handle both @tool and @tool(...) usage
    if func is not None:
        return decorator(func)
    return decorator


def async_tool(
    func: Callable[P, R] | None = None,
    *,
    name: str | None = None,
    description: str | None = None,
    category: str = "general",
    tags: list[str] | None = None,
    timeout_seconds: float = 30.0,
    retry_count: int = 0,
    auto_register: bool = False,
    namespace: str = "default",
) -> Callable[P, R] | Callable[[Callable[P, R]], Callable[P, R]]:
    """
    Decorator specifically for async tool functions.
    
    Same as @tool but explicitly indicates async nature.
    
    ```python
    @async_tool(timeout_seconds=60)
    async def fetch_data(url: str) -> dict:
        '''Fetch data from a URL.'''
        async with aiohttp.ClientSession() as session:
            async with session.get(url) as response:
                return await response.json()
    ```
    """
    return tool(
        func,
        name=name,
        description=description,
        category=category,
        tags=tags or ["async"],
        timeout_seconds=timeout_seconds,
        retry_count=retry_count,
        auto_register=auto_register,
        namespace=namespace,
    )


class _ActionToolWrapper(ActionTool):
    """Internal wrapper for action decorator."""
    
    _function: Callable[..., Any] | None = None
    _is_async: bool = False
    
    async def execute(self, **kwargs: Any) -> ToolResult:
        """Execute the wrapped action function."""
        if self._function is None:
            return ToolResult.failure("No function attached to action")
        
        try:
            if self._is_async:
                result = await self._function(**kwargs)
            else:
                loop = asyncio.get_event_loop()
                result = await loop.run_in_executor(None, lambda: self._function(**kwargs))
            
            return ToolResult.success(result)
            
        except Exception as e:
            return ToolResult.failure(str(e))


def action(
    func: Callable[P, R] | None = None,
    *,
    name: str | None = None,
    description: str | None = None,
    category: str = "action",
    tags: list[str] | None = None,
    timeout_seconds: float = 30.0,
    retry_count: int = 0,
    requires_confirmation: bool = False,
    is_destructive: bool = False,
    auto_register: bool = False,
    namespace: str = "default",
) -> Callable[P, R] | Callable[[Callable[P, R]], Callable[P, R]]:
    """
    Decorator to create an action tool with confirmation support.
    
    Actions are tools that may have side effects and can require
    user confirmation before execution.
    
    ```python
    @action(requires_confirmation=True, is_destructive=True)
    def delete_database(name: str) -> bool:
        '''Delete an entire database.'''
        # Deletion logic
        return True
    
    @action(category="email")
    async def send_email(to: str, subject: str, body: str) -> dict:
        '''Send an email to a recipient.'''
        # Email sending logic
        return {"sent": True}
    ```
    
    Args:
        func: The function to wrap
        name: Action name
        description: Action description
        category: Action category
        tags: List of tags
        timeout_seconds: Execution timeout
        retry_count: Retry count
        requires_confirmation: If True, action requires user confirmation
        is_destructive: If True, action may cause data loss
        auto_register: Auto-register with global registry
        namespace: Namespace for registration
    """
    
    def decorator(fn: Callable[P, R]) -> Callable[P, R]:
        action_name = name or fn.__name__
        action_description = description or (fn.__doc__ or "").strip().split("\n")[0]
        is_async = asyncio.iscoroutinefunction(fn)
        
        # Extract parameters
        sig = inspect.signature(fn)
        hints = {}
        try:
            from typing import get_type_hints
            hints = get_type_hints(fn)
        except Exception:
            pass
        
        params = []
        for param_name, param in sig.parameters.items():
            if param_name in ('self', 'kwargs', 'args'):
                continue
            
            param_type = hints.get(param_name, str)
            json_type = BaseTool._python_type_to_json_type(param_type)
            has_default = param.default != inspect.Parameter.empty
            
            params.append(ToolParameter(
                name=param_name,
                type=json_type,
                required=not has_default,
                default=param.default if has_default else None,
            ))
        
        # Create action tool
        action_tool = _ActionToolWrapper(
            name=action_name,
            description=action_description,
            category=category,
            tags=tags or ["action"],
            timeout_seconds=timeout_seconds,
            retry_count=retry_count,
            requires_confirmation=requires_confirmation,
            is_destructive=is_destructive,
            parameters=params,
        )
        
        object.__setattr__(action_tool, '_function', fn)
        object.__setattr__(action_tool, '_is_async', is_async)
        
        if auto_register:
            registry = ToolRegistry.get_global()
            registry.register(action_tool, namespace=namespace)
        
        # Wrap function
        if is_async:
            @wraps(fn)
            async def async_wrapper(*args: P.args, **kwargs: P.kwargs) -> R:
                return await fn(*args, **kwargs)
            wrapper = async_wrapper
        else:
            @wraps(fn)
            def sync_wrapper(*args: P.args, **kwargs: P.kwargs) -> R:
                return fn(*args, **kwargs)
            wrapper = sync_wrapper
        
        wrapper.tool = action_tool  # type: ignore
        wrapper.action = action_tool  # type: ignore
        wrapper.as_tool = lambda: action_tool  # type: ignore
        
        return wrapper  # type: ignore
    
    if func is not None:
        return decorator(func)
    return decorator


def skill(
    func: Callable[P, R] | None = None,
    *,
    name: str | None = None,
    description: str | None = None,
    input_modes: list[str] | None = None,
    output_modes: list[str] | None = None,
    tags: list[str] | None = None,
    auto_register: bool = False,
) -> Callable[P, R] | Callable[[Callable[P, R]], Callable[P, R]]:
    """
    Decorator to create an A2A-compatible skill from a function.
    
    Skills are tools that are also exposed as A2A AgentSkills.
    
    ```python
    @skill(
        input_modes=["text", "image"],
        output_modes=["text"],
        tags=["vision", "analysis"]
    )
    async def analyze_image(image_url: str, prompt: str) -> str:
        '''Analyze an image based on a prompt.'''
        # Analysis logic
        return "Analysis result"
    ```
    
    Args:
        func: Function to wrap
        name: Skill name
        description: Skill description
        input_modes: Supported input modes (e.g., ["text", "image"])
        output_modes: Supported output modes
        tags: Skill tags
        auto_register: Auto-register with registry
    """
    
    def decorator(fn: Callable[P, R]) -> Callable[P, R]:
        # Create as regular tool first
        decorated = tool(
            fn,
            name=name,
            description=description,
            category="skill",
            tags=tags,
            auto_register=auto_register,
        )
        
        # Enhance with skill metadata
        tool_instance = decorated.tool  # type: ignore
        
        # Store skill-specific metadata
        tool_instance._skill_input_modes = input_modes or ["text"]
        tool_instance._skill_output_modes = output_modes or ["text"]
        
        # Override to_agent_skill to use custom modes
        original_to_skill = tool_instance.to_agent_skill
        
        def enhanced_to_skill():
            from multi_agent_base.a2a.agent_card import AgentSkill
            return AgentSkill(
                id=tool_instance.id,
                name=tool_instance.name,
                description=tool_instance.description,
                tags=tool_instance.tags,
                input_modes=tool_instance._skill_input_modes,
                output_modes=tool_instance._skill_output_modes,
            )
        
        tool_instance.to_agent_skill = enhanced_to_skill
        decorated.as_skill = enhanced_to_skill  # type: ignore
        
        return decorated
    
    if func is not None:
        return decorator(func)
    return decorator


# Utility functions for working with decorated functions

def get_tool(fn: Callable) -> BaseTool | None:
    """Get the tool from a decorated function."""
    return getattr(fn, 'tool', None)


def get_tools(*functions: Callable) -> list[BaseTool]:
    """Get tools from multiple decorated functions."""
    tools = []
    for fn in functions:
        t = get_tool(fn)
        if t:
            tools.append(t)
    return tools


def register_tools(*functions: Callable, namespace: str = "default") -> list[BaseTool]:
    """Register tools from decorated functions with global registry."""
    registry = ToolRegistry.get_global()
    tools = []
    
    for fn in functions:
        t = get_tool(fn)
        if t:
            registry.register(t, namespace=namespace)
            tools.append(t)
    
    return tools
