"""
Microsoft Agent Framework DevUI Integration.

This module provides integration with AF's DevUI for debugging
and visualizing agent execution:

- Interactive debugging interface
- Conversation history viewer
- Workflow execution visualization
- Tool call inspection
- Metrics dashboard

Requirements:
    pip install agent-framework-devui --pre

Usage:
    ```python
    from multi_agent_base.core.devui import DevUI, start_devui
    
    # Start DevUI server
    devui = DevUI(
        host="localhost",
        port=8080,
    )
    await devui.start()
    
    # Register agents for debugging
    devui.register_agent(my_agent)
    devui.register_workflow(my_workflow)
    
    # Or use convenience function
    await start_devui(agents=[my_agent], workflows=[my_workflow])
    ```
"""

from __future__ import annotations

import asyncio
import json
import logging
from dataclasses import dataclass, field
from datetime import datetime
from typing import (
    TYPE_CHECKING,
    Any,
    Callable,
    Dict,
    List,
    Optional,
    Sequence,
    Union,
)

if TYPE_CHECKING:
    from multi_agent_base.core.agent import BaseAgent
    from multi_agent_base.core.workflows import Workflow
    from multi_agent_base.core.af_adapter import EnhancedAgent


logger = logging.getLogger(__name__)


@dataclass
class DevUIConfig:
    """Configuration for DevUI server.
    
    Attributes:
        host: Host to bind to
        port: Port to listen on
        enable_auth: Require authentication
        auth_token: Authentication token if enabled
        enable_metrics: Show metrics dashboard
        enable_tracing: Enable OpenTelemetry tracing
        log_level: Logging level
        auto_open_browser: Open browser on start
    """
    
    host: str = "localhost"
    port: int = 8080
    enable_auth: bool = False
    auth_token: str | None = None
    enable_metrics: bool = True
    enable_tracing: bool = True
    log_level: str = "INFO"
    auto_open_browser: bool = True


@dataclass
class AgentSession:
    """Represents a debugging session for an agent."""
    
    id: str
    agent_name: str
    created_at: datetime = field(default_factory=datetime.utcnow)
    messages: list[dict[str, Any]] = field(default_factory=list)
    tool_calls: list[dict[str, Any]] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class WorkflowSession:
    """Represents a debugging session for a workflow."""
    
    id: str
    workflow_id: str
    created_at: datetime = field(default_factory=datetime.utcnow)
    executor_runs: list[dict[str, Any]] = field(default_factory=list)
    checkpoints: list[dict[str, Any]] = field(default_factory=list)
    state: str = "pending"
    metadata: dict[str, Any] = field(default_factory=dict)


class DevUI:
    """DevUI server for debugging agents and workflows.
    
    Provides a web-based interface for:
    - Viewing agent conversations in real-time
    - Inspecting tool calls and responses
    - Visualizing workflow execution graphs
    - Monitoring metrics and costs
    - Setting breakpoints and stepping through execution
    
    Example:
        ```python
        devui = DevUI(config=DevUIConfig(port=8080))
        
        # Register entities
        devui.register_agent(my_agent, alias="Assistant")
        devui.register_workflow(my_workflow)
        
        # Start server
        await devui.start()
        
        # Access at http://localhost:8080
        ```
    """
    
    def __init__(
        self,
        config: DevUIConfig | None = None,
        host: str | None = None,
        port: int | None = None,
    ) -> None:
        """Initialize DevUI.
        
        Args:
            config: DevUI configuration
            host: Override host from config
            port: Override port from config
        """
        self.config = config or DevUIConfig()
        if host:
            self.config.host = host
        if port:
            self.config.port = port
        
        self._agents: dict[str, Any] = {}
        self._workflows: dict[str, Any] = {}
        self._agent_sessions: dict[str, AgentSession] = {}
        self._workflow_sessions: dict[str, WorkflowSession] = {}
        self._server = None
        self._is_running = False
        self._af_devui = None
    
    def register_agent(
        self,
        agent: Union["BaseAgent", "EnhancedAgent"],
        alias: str | None = None,
    ) -> None:
        """Register an agent for debugging.
        
        Args:
            agent: Agent instance
            alias: Optional display name
        """
        name = alias or getattr(agent, 'name', str(id(agent)))
        self._agents[name] = agent
        logger.info(f"Registered agent '{name}' for DevUI debugging")
    
    def register_workflow(
        self,
        workflow: "Workflow",
        alias: str | None = None,
    ) -> None:
        """Register a workflow for debugging.
        
        Args:
            workflow: Workflow instance
            alias: Optional display name
        """
        name = alias or getattr(workflow, 'name', workflow.id)
        self._workflows[name] = workflow
        logger.info(f"Registered workflow '{name}' for DevUI debugging")
    
    async def start(self) -> None:
        """Start the DevUI server."""
        if self._is_running:
            logger.warning("DevUI is already running")
            return
        
        # Try to use AF's native DevUI
        try:
            from agent_framework_devui import DevUI as AFDevUI
            
            self._af_devui = AFDevUI(
                host=self.config.host,
                port=self.config.port,
            )
            
            # Register agents with AF DevUI
            for name, agent in self._agents.items():
                if hasattr(self._af_devui, 'register_agent'):
                    self._af_devui.register_agent(agent, name=name)
            
            # Register workflows with AF DevUI
            for name, workflow in self._workflows.items():
                if hasattr(self._af_devui, 'register_workflow'):
                    self._af_devui.register_workflow(workflow, name=name)
            
            await self._af_devui.start()
            self._is_running = True
            
            logger.info(
                f"DevUI started at http://{self.config.host}:{self.config.port}"
            )
            
            if self.config.auto_open_browser:
                self._open_browser()
            
        except ImportError:
            logger.warning(
                "agent-framework-devui not installed. "
                "Using fallback DevUI. Install with: pip install agent-framework-devui --pre"
            )
            await self._start_fallback()
    
    async def stop(self) -> None:
        """Stop the DevUI server."""
        if not self._is_running:
            return
        
        if self._af_devui:
            await self._af_devui.stop()
        elif self._server:
            self._server.close()
            await self._server.wait_closed()
        
        self._is_running = False
        logger.info("DevUI stopped")
    
    async def _start_fallback(self) -> None:
        """Start a basic fallback DevUI server."""
        from aiohttp import web
        
        app = web.Application()
        
        # Basic routes
        app.router.add_get("/", self._handle_index)
        app.router.add_get("/api/agents", self._handle_list_agents)
        app.router.add_get("/api/workflows", self._handle_list_workflows)
        app.router.add_get("/api/sessions", self._handle_list_sessions)
        app.router.add_get("/health", self._handle_health)
        
        runner = web.AppRunner(app)
        await runner.setup()
        
        self._server = await asyncio.get_event_loop().create_server(
            runner.server,
            self.config.host,
            self.config.port,
        )
        
        self._is_running = True
        logger.info(
            f"Fallback DevUI started at http://{self.config.host}:{self.config.port}"
        )
        
        if self.config.auto_open_browser:
            self._open_browser()
    
    async def _handle_index(self, request) -> Any:
        """Handle index page request."""
        from aiohttp import web
        
        html = self._generate_index_html()
        return web.Response(text=html, content_type="text/html")
    
    async def _handle_list_agents(self, request) -> Any:
        """Handle list agents API request."""
        from aiohttp import web
        
        agents = [
            {
                "name": name,
                "type": agent.__class__.__name__,
                "model": getattr(agent, 'model', 'unknown'),
            }
            for name, agent in self._agents.items()
        ]
        return web.json_response({"agents": agents})
    
    async def _handle_list_workflows(self, request) -> Any:
        """Handle list workflows API request."""
        from aiohttp import web
        
        workflows = [
            {
                "id": workflow.id,
                "name": name,
                "executor_count": len(workflow.executors),
                "edge_count": len(workflow.edges),
            }
            for name, workflow in self._workflows.items()
        ]
        return web.json_response({"workflows": workflows})
    
    async def _handle_list_sessions(self, request) -> Any:
        """Handle list sessions API request."""
        from aiohttp import web
        
        sessions = {
            "agent_sessions": [
                {
                    "id": s.id,
                    "agent_name": s.agent_name,
                    "message_count": len(s.messages),
                    "created_at": s.created_at.isoformat(),
                }
                for s in self._agent_sessions.values()
            ],
            "workflow_sessions": [
                {
                    "id": s.id,
                    "workflow_id": s.workflow_id,
                    "state": s.state,
                    "created_at": s.created_at.isoformat(),
                }
                for s in self._workflow_sessions.values()
            ],
        }
        return web.json_response(sessions)
    
    async def _handle_health(self, request) -> Any:
        """Handle health check request."""
        from aiohttp import web
        
        return web.json_response({
            "status": "healthy",
            "agents": len(self._agents),
            "workflows": len(self._workflows),
        })
    
    def _generate_index_html(self) -> str:
        """Generate fallback index HTML page."""
        agents_html = "".join(
            f"<li>{name} ({agent.__class__.__name__})</li>"
            for name, agent in self._agents.items()
        )
        
        workflows_html = "".join(
            f"<li>{name} (ID: {workflow.id})</li>"
            for name, workflow in self._workflows.items()
        )
        
        return f"""
<!DOCTYPE html>
<html>
<head>
    <title>Multi-Agent Base - DevUI</title>
    <style>
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background: #1a1a2e;
            color: #eee;
        }}
        h1 {{ color: #00d4ff; }}
        h2 {{ color: #00ff88; }}
        .card {{
            background: #16213e;
            border-radius: 8px;
            padding: 20px;
            margin: 20px 0;
            border: 1px solid #0f3460;
        }}
        ul {{ list-style-type: none; padding: 0; }}
        li {{
            padding: 10px;
            background: #0f3460;
            margin: 5px 0;
            border-radius: 4px;
        }}
        .status {{ color: #00ff88; }}
        .note {{
            background: #e94560;
            padding: 15px;
            border-radius: 8px;
            margin: 20px 0;
        }}
    </style>
</head>
<body>
    <h1>🤖 Multi-Agent Base DevUI</h1>
    
    <div class="note">
        <strong>Note:</strong> This is a fallback DevUI. For full functionality, install:
        <code>pip install agent-framework-devui --pre</code>
    </div>
    
    <div class="card">
        <h2>Registered Agents</h2>
        <ul>
            {agents_html if agents_html else "<li>No agents registered</li>"}
        </ul>
    </div>
    
    <div class="card">
        <h2>Registered Workflows</h2>
        <ul>
            {workflows_html if workflows_html else "<li>No workflows registered</li>"}
        </ul>
    </div>
    
    <div class="card">
        <h2>API Endpoints</h2>
        <ul>
            <li><code>GET /api/agents</code> - List registered agents</li>
            <li><code>GET /api/workflows</code> - List registered workflows</li>
            <li><code>GET /api/sessions</code> - List active sessions</li>
            <li><code>GET /health</code> - Health check</li>
        </ul>
    </div>
    
    <p class="status">Status: Running ✓</p>
</body>
</html>
"""
    
    def _open_browser(self) -> None:
        """Open the DevUI in the default browser."""
        import webbrowser
        url = f"http://{self.config.host}:{self.config.port}"
        webbrowser.open(url)
    
    @property
    def is_running(self) -> bool:
        """Check if DevUI is running."""
        return self._is_running
    
    @property
    def url(self) -> str:
        """Get the DevUI URL."""
        return f"http://{self.config.host}:{self.config.port}"


# =============================================================================
# Convenience Functions
# =============================================================================


async def start_devui(
    agents: Sequence[Any] | None = None,
    workflows: Sequence[Any] | None = None,
    host: str = "localhost",
    port: int = 8080,
    auto_open_browser: bool = True,
) -> DevUI:
    """Convenience function to start DevUI with agents and workflows.
    
    Args:
        agents: List of agents to register
        workflows: List of workflows to register
        host: Host to bind to
        port: Port to listen on
        auto_open_browser: Open browser on start
        
    Returns:
        Running DevUI instance
        
    Example:
        ```python
        devui = await start_devui(
            agents=[assistant_agent, researcher_agent],
            workflows=[research_workflow],
            port=8080,
        )
        
        # When done
        await devui.stop()
        ```
    """
    config = DevUIConfig(
        host=host,
        port=port,
        auto_open_browser=auto_open_browser,
    )
    
    devui = DevUI(config=config)
    
    # Register agents
    for agent in (agents or []):
        devui.register_agent(agent)
    
    # Register workflows
    for workflow in (workflows or []):
        devui.register_workflow(workflow)
    
    await devui.start()
    
    return devui


def create_devui_middleware() -> Any:
    """Create middleware that sends events to DevUI.
    
    Returns middleware that can be added to agents to stream
    events to the DevUI for real-time debugging.
    
    Returns:
        Middleware instance
        
    Example:
        ```python
        devui_mw = create_devui_middleware()
        
        agent = EnhancedAgent(
            config=config,
            middleware=[devui_mw],
        )
        ```
    """
    try:
        from agent_framework_devui import DevUIMiddleware
        return DevUIMiddleware()
    except ImportError:
        # Return a no-op middleware
        from multi_agent_base.core.middleware import AgentMiddleware, MiddlewareContext
        
        class NoOpDevUIMiddleware(AgentMiddleware):
            async def before(self, context: MiddlewareContext, *args, **kwargs):
                pass
            
            async def after(self, context: MiddlewareContext, result, error=None):
                return result
        
        logger.warning(
            "agent-framework-devui not installed, DevUI middleware disabled"
        )
        return NoOpDevUIMiddleware()


# =============================================================================
# Tracing Integration
# =============================================================================


class DevUITracer:
    """Tracer that sends spans to DevUI for visualization.
    
    Integrates with OpenTelemetry to capture and display:
    - Agent runs
    - LLM calls
    - Tool executions
    - Workflow steps
    
    Example:
        ```python
        tracer = DevUITracer(devui=devui)
        
        with tracer.span("agent_run", agent_name="assistant"):
            response = await agent.run(message)
        ```
    """
    
    def __init__(
        self,
        devui: DevUI | None = None,
        service_name: str = "multi-agent-base",
    ) -> None:
        """Initialize tracer.
        
        Args:
            devui: DevUI instance to send traces to
            service_name: Name of the service for tracing
        """
        self._devui = devui
        self._service_name = service_name
        self._spans: list[dict[str, Any]] = []
    
    def span(
        self,
        name: str,
        **attributes: Any,
    ) -> "SpanContext":
        """Create a new span context.
        
        Args:
            name: Span name
            **attributes: Span attributes
            
        Returns:
            SpanContext manager
        """
        return SpanContext(self, name, attributes)
    
    def record_span(self, span_data: dict[str, Any]) -> None:
        """Record a completed span."""
        self._spans.append(span_data)
        
        # TODO: Send to DevUI via WebSocket if connected


@dataclass
class SpanContext:
    """Context manager for tracing spans."""
    
    tracer: DevUITracer
    name: str
    attributes: dict[str, Any]
    start_time: datetime | None = None
    
    def __enter__(self) -> "SpanContext":
        self.start_time = datetime.utcnow()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        end_time = datetime.utcnow()
        duration_ms = (end_time - self.start_time).total_seconds() * 1000
        
        span_data = {
            "name": self.name,
            "start_time": self.start_time.isoformat(),
            "end_time": end_time.isoformat(),
            "duration_ms": duration_ms,
            "attributes": self.attributes,
            "error": str(exc_val) if exc_val else None,
        }
        
        self.tracer.record_span(span_data)
    
    async def __aenter__(self) -> "SpanContext":
        return self.__enter__()
    
    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        self.__exit__(exc_type, exc_val, exc_tb)


# Convenience aliases
AFDevUI = DevUI
AFDevUIConfig = DevUIConfig
