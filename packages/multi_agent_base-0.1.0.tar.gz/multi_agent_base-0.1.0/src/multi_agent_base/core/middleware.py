"""
Microsoft Agent Framework Middleware Adapter.

This module provides middleware implementations that bridge our extension
modules with AF's middleware system:

- AgentMiddleware: Wraps our Resilience patterns
- ChatMiddleware: Wraps our Security validation
- FunctionMiddleware: Wraps our Rate Limiting

AF Middleware Types:
1. AgentMiddleware: Before/after agent run
2. ChatMiddleware: Before/after chat client call
3. FunctionMiddleware: Before/after tool/function execution

Usage:
    ```python
    from multi_agent_base.core.middleware import (
        ResilienceMiddleware,
        SecurityMiddleware,
        RateLimitMiddleware,
        MetricsMiddleware,
    )
    
    # Add to AF ChatAgent
    agent = ChatAgent(
        chat_client=client,
        middleware=[
            ResilienceMiddleware(config),
            SecurityMiddleware(validator),
            RateLimitMiddleware(limiter),
            MetricsMiddleware(collector),
        ],
    )
    ```
"""

from __future__ import annotations

import asyncio
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from typing import (
    TYPE_CHECKING,
    Any,
    AsyncIterator,
    Awaitable,
    Callable,
    Dict,
    Generic,
    List,
    MutableSequence,
    Optional,
    Sequence,
    TypeVar,
    Union,
)

if TYPE_CHECKING:
    from multi_agent_base.resilience.config import ResilienceConfig
    from multi_agent_base.resilience.patterns import ResilienceWrapper
    from multi_agent_base.ratelimit.limiter import RateLimiter
    from multi_agent_base.security.validator import SecurityValidator
    from multi_agent_base.monitoring.metrics import MetricsCollector
    from multi_agent_base.cost.tracker import CostTracker


# Type aliases matching AF's patterns
AgentRunContext = Any
AgentResponse = Any
ChatMessage = Any
ChatResponse = Any
FunctionContext = Any
FunctionResult = Any


@dataclass
class MiddlewareContext:
    """Context for middleware execution.
    
    Attributes:
        metadata: Shared metadata between middleware
        start_time: When the request started
        agent_name: Name of the agent being invoked
        terminate: Whether to terminate the middleware chain
        result: Result to return if terminating early
    """
    
    metadata: dict[str, Any] = field(default_factory=dict)
    start_time: float = field(default_factory=time.time)
    agent_name: str | None = None
    terminate: bool = False
    result: Any = None


class BaseMiddleware(ABC):
    """Base class for all middleware implementations."""
    
    @abstractmethod
    async def before(self, context: MiddlewareContext, *args: Any, **kwargs: Any) -> None:
        """Called before the wrapped operation.
        
        Args:
            context: Middleware context
            *args: Positional arguments to operation
            **kwargs: Keyword arguments to operation
        """
        pass
    
    @abstractmethod
    async def after(
        self,
        context: MiddlewareContext,
        result: Any,
        error: Exception | None = None,
    ) -> Any:
        """Called after the wrapped operation.
        
        Args:
            context: Middleware context
            result: Result from operation (None if error)
            error: Exception if operation failed
            
        Returns:
            Modified result (or original if unchanged)
        """
        pass


class AgentMiddleware(BaseMiddleware):
    """Middleware for agent run operations.
    
    Wraps the entire agent.run() call, allowing interception
    before the agent processes messages and after it returns.
    
    Use for:
    - Resilience patterns (retry, circuit breaker)
    - Cost tracking
    - Metrics collection
    - Logging
    """
    
    async def invoke(
        self,
        agent: Any,
        messages: list[Any],
        context: AgentRunContext,
        next_handler: Callable[[AgentRunContext], Awaitable[AgentResponse]],
    ) -> AgentResponse:
        """Invoke the middleware.
        
        Args:
            agent: The agent being invoked
            messages: Input messages
            context: Agent run context
            next_handler: Next handler in the chain
            
        Returns:
            Agent response
        """
        middleware_ctx = MiddlewareContext(
            agent_name=getattr(agent, 'name', None),
        )
        
        # Before hook
        await self.before(middleware_ctx, agent, messages, context)
        
        if middleware_ctx.terminate:
            return middleware_ctx.result
        
        # Execute next handler
        error = None
        result = None
        try:
            result = await next_handler(context)
        except Exception as e:
            error = e
        
        # After hook
        result = await self.after(middleware_ctx, result, error)
        
        if error and result is None:
            raise error
        
        return result


class ChatMiddleware(BaseMiddleware):
    """Middleware for chat client operations.
    
    Wraps the chat client's get_response() call, allowing interception
    before messages are sent to the LLM and after response is received.
    
    Use for:
    - Input validation
    - Prompt injection detection
    - Content filtering
    - Message transformation
    """
    
    async def invoke(
        self,
        chat_client: Any,
        messages: MutableSequence[Any],
        options: dict[str, Any] | None,
        context: Any,
        next_handler: Callable[[Any], Awaitable[ChatResponse]],
    ) -> ChatResponse:
        """Invoke the middleware.
        
        Args:
            chat_client: The chat client
            messages: Messages to send
            options: Chat options
            context: Chat context
            next_handler: Next handler in chain
            
        Returns:
            Chat response
        """
        middleware_ctx = MiddlewareContext()
        middleware_ctx.metadata["messages"] = messages
        middleware_ctx.metadata["options"] = options
        
        # Before hook
        await self.before(middleware_ctx, chat_client, messages, options, context)
        
        if middleware_ctx.terminate:
            return middleware_ctx.result
        
        # Execute next handler
        error = None
        result = None
        try:
            result = await next_handler(context)
        except Exception as e:
            error = e
        
        # After hook
        result = await self.after(middleware_ctx, result, error)
        
        if error and result is None:
            raise error
        
        return result


class FunctionMiddleware(BaseMiddleware):
    """Middleware for function/tool execution.
    
    Wraps tool execution, allowing interception before a tool is called
    and after it returns.
    
    Use for:
    - Rate limiting
    - Permission checks
    - Argument validation
    - Result caching
    """
    
    async def invoke(
        self,
        function_name: str,
        arguments: dict[str, Any],
        context: FunctionContext,
        next_handler: Callable[[FunctionContext], Awaitable[FunctionResult]],
    ) -> FunctionResult:
        """Invoke the middleware.
        
        Args:
            function_name: Name of the function/tool
            arguments: Function arguments
            context: Function context
            next_handler: Next handler in chain
            
        Returns:
            Function result
        """
        middleware_ctx = MiddlewareContext()
        middleware_ctx.metadata["function_name"] = function_name
        middleware_ctx.metadata["arguments"] = arguments
        
        # Before hook
        await self.before(middleware_ctx, function_name, arguments, context)
        
        if middleware_ctx.terminate:
            return middleware_ctx.result
        
        # Execute next handler
        error = None
        result = None
        try:
            result = await next_handler(context)
        except Exception as e:
            error = e
        
        # After hook
        result = await self.after(middleware_ctx, result, error)
        
        if error and result is None:
            raise error
        
        return result


# =============================================================================
# Concrete Middleware Implementations
# =============================================================================


class ResilienceMiddleware(AgentMiddleware):
    """Middleware that adds resilience patterns to agent calls.
    
    Wraps agent runs with:
    - Circuit breaker: Prevents cascade failures
    - Retry with jitter: Automatic retries with backoff
    - Timeout: Prevents hanging requests
    - Fallback: Alternative responses on failure
    
    Example:
        ```python
        from multi_agent_base.resilience.config import ResilienceConfig
        
        middleware = ResilienceMiddleware(
            config=ResilienceConfig(
                max_retries=3,
                circuit_breaker_threshold=5,
                timeout_seconds=30,
            )
        )
        ```
    """
    
    def __init__(
        self,
        config: "ResilienceConfig | None" = None,
        wrapper: "ResilienceWrapper | None" = None,
    ) -> None:
        """Initialize resilience middleware.
        
        Args:
            config: Resilience configuration
            wrapper: Pre-configured resilience wrapper
        """
        self._config = config
        self._wrapper = wrapper
        self._initialized = False
    
    def _ensure_wrapper(self) -> None:
        """Lazily initialize the resilience wrapper."""
        if self._initialized:
            return
        
        if self._wrapper is None and self._config:
            try:
                from multi_agent_base.resilience.patterns import ResilienceWrapper
                self._wrapper = ResilienceWrapper(self._config)
            except ImportError:
                pass
        
        self._initialized = True
    
    async def before(
        self,
        context: MiddlewareContext,
        *args: Any,
        **kwargs: Any,
    ) -> None:
        """Check circuit breaker state before agent run."""
        self._ensure_wrapper()
        
        if self._wrapper:
            # Check if circuit is open
            if hasattr(self._wrapper, 'is_circuit_open') and self._wrapper.is_circuit_open():
                context.terminate = True
                context.result = self._get_fallback_response(context)
                context.metadata["circuit_open"] = True
    
    async def after(
        self,
        context: MiddlewareContext,
        result: Any,
        error: Exception | None = None,
    ) -> Any:
        """Record success/failure for circuit breaker."""
        self._ensure_wrapper()
        
        if self._wrapper:
            if error:
                # Record failure
                if hasattr(self._wrapper, 'record_failure'):
                    self._wrapper.record_failure(error)
                
                # Attempt retry if configured
                if hasattr(self._wrapper, 'should_retry') and self._wrapper.should_retry(error):
                    context.metadata["retry_attempted"] = True
            else:
                # Record success
                if hasattr(self._wrapper, 'record_success'):
                    self._wrapper.record_success()
        
        return result
    
    def _get_fallback_response(self, context: MiddlewareContext) -> Any:
        """Get fallback response when circuit is open."""
        return {
            "content": "Service temporarily unavailable. Please try again later.",
            "error": "circuit_breaker_open",
            "agent": context.agent_name,
        }
    
    async def invoke(
        self,
        agent: Any,
        messages: list[Any],
        context: AgentRunContext,
        next_handler: Callable[[AgentRunContext], Awaitable[AgentResponse]],
    ) -> AgentResponse:
        """Invoke with resilience patterns."""
        self._ensure_wrapper()
        
        if self._wrapper:
            async def wrapped_call():
                return await next_handler(context)
            
            try:
                return await self._wrapper.execute(wrapped_call)
            except Exception as e:
                # Fallback on final failure
                return self._get_fallback_response(MiddlewareContext(agent_name=getattr(agent, 'name', None)))
        
        return await super().invoke(agent, messages, context, next_handler)


class SecurityMiddleware(ChatMiddleware):
    """Middleware that adds security validation to chat requests.
    
    Validates input messages for:
    - Prompt injection attempts
    - Harmful content
    - PII exposure
    - Unauthorized commands
    
    Example:
        ```python
        from multi_agent_base.security.validator import SecurityValidator
        
        middleware = SecurityMiddleware(
            validator=SecurityValidator(
                detect_injection=True,
                detect_pii=True,
            )
        )
        ```
    """
    
    def __init__(
        self,
        validator: "SecurityValidator | None" = None,
        block_on_threat: bool = True,
        log_threats: bool = True,
    ) -> None:
        """Initialize security middleware.
        
        Args:
            validator: Security validator instance
            block_on_threat: Block requests that fail validation
            log_threats: Log detected threats
        """
        self._validator = validator
        self._block_on_threat = block_on_threat
        self._log_threats = log_threats
    
    async def before(
        self,
        context: MiddlewareContext,
        *args: Any,
        **kwargs: Any,
    ) -> None:
        """Validate messages before sending to LLM."""
        if not self._validator:
            return
        
        messages = context.metadata.get("messages", [])
        
        for msg in messages:
            content = msg.get("content", "") if isinstance(msg, dict) else str(msg)
            
            # Check for prompt injection
            if hasattr(self._validator, 'check_prompt_injection'):
                result = self._validator.check_prompt_injection(content)
                if not result.is_safe:
                    if self._log_threats:
                        context.metadata["security_threat"] = {
                            "type": "prompt_injection",
                            "reason": result.reason,
                        }
                    
                    if self._block_on_threat:
                        context.terminate = True
                        context.result = self._create_blocked_response(result.reason)
                        return
            
            # Check for PII
            if hasattr(self._validator, 'check_pii'):
                result = self._validator.check_pii(content)
                if not result.is_safe:
                    if self._log_threats:
                        context.metadata["security_threat"] = {
                            "type": "pii_detected",
                            "reason": result.reason,
                        }
                    
                    if self._block_on_threat:
                        context.terminate = True
                        context.result = self._create_blocked_response(result.reason)
                        return
    
    async def after(
        self,
        context: MiddlewareContext,
        result: Any,
        error: Exception | None = None,
    ) -> Any:
        """Optionally validate response content."""
        # Could add output validation here
        return result
    
    def _create_blocked_response(self, reason: str) -> dict[str, Any]:
        """Create response for blocked requests."""
        return {
            "content": "Request blocked due to security policy.",
            "blocked": True,
            "reason": reason,
        }


class RateLimitMiddleware(FunctionMiddleware):
    """Middleware that adds rate limiting to function/tool calls.
    
    Implements token bucket rate limiting for:
    - Per-function limits
    - Per-agent limits
    - Global limits
    
    Example:
        ```python
        from multi_agent_base.ratelimit.limiter import RateLimiter
        
        middleware = RateLimitMiddleware(
            limiter=RateLimiter(
                requests_per_second=10,
                burst_size=20,
            )
        )
        ```
    """
    
    def __init__(
        self,
        limiter: "RateLimiter | None" = None,
        limit_by: str = "function",  # "function", "agent", "global"
    ) -> None:
        """Initialize rate limit middleware.
        
        Args:
            limiter: Rate limiter instance
            limit_by: What to use as the rate limit key
        """
        self._limiter = limiter
        self._limit_by = limit_by
    
    async def before(
        self,
        context: MiddlewareContext,
        *args: Any,
        **kwargs: Any,
    ) -> None:
        """Check rate limit before function execution."""
        if not self._limiter:
            return
        
        # Determine rate limit key
        if self._limit_by == "function":
            key = context.metadata.get("function_name", "unknown")
        elif self._limit_by == "agent":
            key = context.agent_name or "unknown"
        else:
            key = "global"
        
        # Check rate limit
        result = await self._limiter.acquire(key)
        
        if not result.allowed:
            context.terminate = True
            context.result = {
                "error": "rate_limit_exceeded",
                "retry_after": result.reset_after,
                "remaining": result.remaining,
            }
            context.metadata["rate_limited"] = True
        else:
            context.metadata["rate_limit_remaining"] = result.remaining
    
    async def after(
        self,
        context: MiddlewareContext,
        result: Any,
        error: Exception | None = None,
    ) -> Any:
        """Record function completion for rate tracking."""
        return result


class CostTrackingMiddleware(AgentMiddleware):
    """Middleware that tracks token usage and costs.
    
    Records:
    - Input/output token counts
    - Cost per request
    - Cumulative costs per agent/model
    
    Example:
        ```python
        from multi_agent_base.cost.tracker import CostTracker
        
        middleware = CostTrackingMiddleware(
            tracker=CostTracker()
        )
        
        # After runs, check costs
        print(tracker.get_total_cost())
        print(tracker.get_cost_by_agent())
        ```
    """
    
    def __init__(
        self,
        tracker: "CostTracker | None" = None,
    ) -> None:
        """Initialize cost tracking middleware.
        
        Args:
            tracker: Cost tracker instance
        """
        self._tracker = tracker
    
    async def before(
        self,
        context: MiddlewareContext,
        *args: Any,
        **kwargs: Any,
    ) -> None:
        """Record request start."""
        context.metadata["cost_tracking_start"] = time.time()
    
    async def after(
        self,
        context: MiddlewareContext,
        result: Any,
        error: Exception | None = None,
    ) -> Any:
        """Track token usage and cost from response."""
        if not self._tracker or error:
            return result
        
        # Extract usage from result
        usage = None
        if isinstance(result, dict):
            usage = result.get("usage")
        elif hasattr(result, 'usage'):
            usage = result.usage
        
        if usage:
            input_tokens = (
                usage.get("prompt_tokens", 0) 
                if isinstance(usage, dict) 
                else getattr(usage, 'prompt_tokens', 0)
            )
            output_tokens = (
                usage.get("completion_tokens", 0)
                if isinstance(usage, dict)
                else getattr(usage, 'completion_tokens', 0)
            )
            
            # Get model info from context
            model = context.metadata.get("model", "unknown")
            provider = context.metadata.get("provider", "openai")
            
            # Calculate and record cost
            cost = self._tracker.calculate_cost(
                provider=provider,
                model=model,
                input_tokens=input_tokens,
                output_tokens=output_tokens,
            )
            
            self._tracker.record(
                agent_name=context.agent_name or "unknown",
                provider=provider,
                model=model,
                input_tokens=input_tokens,
                output_tokens=output_tokens,
                cost=cost,
            )
            
            context.metadata["tracked_cost"] = cost
        
        return result


class MetricsMiddleware(AgentMiddleware):
    """Middleware that records Prometheus metrics.
    
    Tracks:
    - Request duration histograms
    - Request counters (success/failure)
    - Token usage gauges
    - Active request gauges
    
    Example:
        ```python
        from multi_agent_base.monitoring.metrics import MetricsCollector
        
        middleware = MetricsMiddleware(
            collector=MetricsCollector()
        )
        ```
    """
    
    def __init__(
        self,
        collector: "MetricsCollector | None" = None,
    ) -> None:
        """Initialize metrics middleware.
        
        Args:
            collector: Prometheus metrics collector
        """
        self._collector = collector
        self._active_requests: dict[str, int] = {}
    
    async def before(
        self,
        context: MiddlewareContext,
        *args: Any,
        **kwargs: Any,
    ) -> None:
        """Record request start."""
        if not self._collector:
            return
        
        agent_name = context.agent_name or "unknown"
        
        # Increment active requests
        self._active_requests[agent_name] = self._active_requests.get(agent_name, 0) + 1
        
        if hasattr(self._collector, 'set_gauge'):
            self._collector.set_gauge(
                "agent_active_requests",
                self._active_requests[agent_name],
                {"agent": agent_name},
            )
    
    async def after(
        self,
        context: MiddlewareContext,
        result: Any,
        error: Exception | None = None,
    ) -> Any:
        """Record request completion metrics."""
        if not self._collector:
            return result
        
        agent_name = context.agent_name or "unknown"
        duration_ms = (time.time() - context.start_time) * 1000
        
        # Decrement active requests
        self._active_requests[agent_name] = max(0, self._active_requests.get(agent_name, 1) - 1)
        
        if hasattr(self._collector, 'set_gauge'):
            self._collector.set_gauge(
                "agent_active_requests",
                self._active_requests[agent_name],
                {"agent": agent_name},
            )
        
        # Record duration
        if hasattr(self._collector, 'observe_histogram'):
            self._collector.observe_histogram(
                "agent_request_duration_seconds",
                duration_ms / 1000,
                {"agent": agent_name},
            )
        
        # Record success/failure
        if hasattr(self._collector, 'increment_counter'):
            status = "error" if error else "success"
            self._collector.increment_counter(
                "agent_requests_total",
                1,
                {"agent": agent_name, "status": status},
            )
        
        return result


class LoggingMiddleware(AgentMiddleware):
    """Middleware that logs agent operations.
    
    Logs:
    - Request details
    - Response summaries
    - Errors
    - Timing information
    
    Example:
        ```python
        from multi_agent_base.observability.logger import AgentLogger
        
        middleware = LoggingMiddleware(
            logger=AgentLogger()
        )
        ```
    """
    
    def __init__(
        self,
        logger: Any = None,
        log_level: str = "INFO",
        include_messages: bool = False,
    ) -> None:
        """Initialize logging middleware.
        
        Args:
            logger: Logger instance
            log_level: Log level
            include_messages: Whether to log full messages
        """
        self._logger = logger
        self._log_level = log_level
        self._include_messages = include_messages
    
    async def before(
        self,
        context: MiddlewareContext,
        *args: Any,
        **kwargs: Any,
    ) -> None:
        """Log request start."""
        if self._logger:
            agent_name = context.agent_name or "unknown"
            
            if hasattr(self._logger, 'log_agent_run'):
                self._logger.log_agent_run(agent_name, "start")
    
    async def after(
        self,
        context: MiddlewareContext,
        result: Any,
        error: Exception | None = None,
    ) -> Any:
        """Log request completion."""
        if self._logger:
            agent_name = context.agent_name or "unknown"
            duration_ms = (time.time() - context.start_time) * 1000
            
            if error:
                if hasattr(self._logger, 'log_error'):
                    self._logger.log_error(agent_name, str(error))
            else:
                if hasattr(self._logger, 'log_agent_run'):
                    self._logger.log_agent_run(
                        agent_name, 
                        "complete",
                        metadata={"duration_ms": duration_ms},
                    )
        
        return result


# =============================================================================
# Middleware Pipeline
# =============================================================================


class MiddlewarePipeline:
    """Executes a chain of middleware in order.
    
    Middleware are executed in order for 'before' hooks,
    and in reverse order for 'after' hooks.
    
    Example:
        ```python
        pipeline = MiddlewarePipeline([
            LoggingMiddleware(),
            MetricsMiddleware(),
            ResilienceMiddleware(config),
            SecurityMiddleware(validator),
        ])
        
        result = await pipeline.execute(
            handler=agent.run,
            messages=messages,
        )
        ```
    """
    
    def __init__(
        self,
        middleware: Sequence[BaseMiddleware] | None = None,
    ) -> None:
        """Initialize pipeline.
        
        Args:
            middleware: List of middleware to execute
        """
        self._middleware: list[BaseMiddleware] = list(middleware or [])
    
    def add(self, middleware: BaseMiddleware) -> "MiddlewarePipeline":
        """Add middleware to the pipeline.
        
        Args:
            middleware: Middleware to add
            
        Returns:
            Self for chaining
        """
        self._middleware.append(middleware)
        return self
    
    def insert(self, index: int, middleware: BaseMiddleware) -> "MiddlewarePipeline":
        """Insert middleware at specific position.
        
        Args:
            index: Position to insert at
            middleware: Middleware to insert
            
        Returns:
            Self for chaining
        """
        self._middleware.insert(index, middleware)
        return self
    
    async def execute(
        self,
        handler: Callable[..., Awaitable[Any]],
        *args: Any,
        **kwargs: Any,
    ) -> Any:
        """Execute the middleware pipeline.
        
        Args:
            handler: Final handler to execute
            *args: Arguments for handler
            **kwargs: Keyword arguments for handler
            
        Returns:
            Result from handler (or middleware if short-circuited)
        """
        context = MiddlewareContext()
        
        # Execute before hooks
        for mw in self._middleware:
            await mw.before(context, *args, **kwargs)
            
            if context.terminate:
                return context.result
        
        # Execute handler
        error = None
        result = None
        try:
            result = await handler(*args, **kwargs)
        except Exception as e:
            error = e
        
        # Execute after hooks (reverse order)
        for mw in reversed(self._middleware):
            result = await mw.after(context, result, error)
        
        if error and result is None:
            raise error
        
        return result


# =============================================================================
# Factory Functions
# =============================================================================


def create_default_middleware_pipeline(
    enable_resilience: bool = True,
    enable_security: bool = True,
    enable_rate_limiting: bool = False,
    enable_cost_tracking: bool = True,
    enable_metrics: bool = False,
    enable_logging: bool = True,
    resilience_config: "ResilienceConfig | None" = None,
    security_validator: "SecurityValidator | None" = None,
    rate_limiter: "RateLimiter | None" = None,
    cost_tracker: "CostTracker | None" = None,
    metrics_collector: "MetricsCollector | None" = None,
    logger: Any = None,
) -> MiddlewarePipeline:
    """Create a middleware pipeline with common configurations.
    
    Args:
        enable_resilience: Include resilience middleware
        enable_security: Include security middleware
        enable_rate_limiting: Include rate limit middleware
        enable_cost_tracking: Include cost tracking middleware
        enable_metrics: Include metrics middleware
        enable_logging: Include logging middleware
        resilience_config: Config for resilience
        security_validator: Validator for security
        rate_limiter: Limiter for rate limiting
        cost_tracker: Tracker for costs
        metrics_collector: Collector for metrics
        logger: Logger instance
        
    Returns:
        Configured MiddlewarePipeline
    """
    middleware: list[BaseMiddleware] = []
    
    # Logging first (to capture everything)
    if enable_logging:
        middleware.append(LoggingMiddleware(logger=logger))
    
    # Metrics (to track timing accurately)
    if enable_metrics:
        middleware.append(MetricsMiddleware(collector=metrics_collector))
    
    # Resilience (wraps actual call)
    if enable_resilience:
        middleware.append(ResilienceMiddleware(config=resilience_config))
    
    # Security (validate input)
    if enable_security:
        middleware.append(SecurityMiddleware(validator=security_validator))
    
    # Rate limiting
    if enable_rate_limiting:
        middleware.append(RateLimitMiddleware(limiter=rate_limiter))
    
    # Cost tracking (needs to see response)
    if enable_cost_tracking:
        middleware.append(CostTrackingMiddleware(tracker=cost_tracker))
    
    return MiddlewarePipeline(middleware)


# Convenience aliases
AFAgentMiddleware = AgentMiddleware
AFChatMiddleware = ChatMiddleware
AFMiddlewarePipeline = MiddlewarePipeline
