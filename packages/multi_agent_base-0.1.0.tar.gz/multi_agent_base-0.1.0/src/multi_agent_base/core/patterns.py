"""
Agent architecture patterns for the Multi-Agent Base framework.

This module provides parametric pattern implementations:
- SingleAgentPattern: Single agent with tools
- SupervisorPattern: Supervisor orchestrating worker agents
- SwarmPattern: Dynamic agent-to-agent handoffs
- HierarchicalPattern: Multi-level supervisor chains
- EnsemblePattern: Multiple agents vote on responses
- SelfHealingPattern: Auto-retry with modified approach

Each pattern provides a consistent interface for creating and
running agent systems with observability and cost tracking.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import TYPE_CHECKING, Any, Callable

if TYPE_CHECKING:
    from multi_agent_base.core.config import AgentConfig, SystemConfig
    from multi_agent_base.core.agent import AgentResponse, BaseAgent, Tool
    from multi_agent_base.cost.tracker import CostTracker
    from multi_agent_base.observability.logger import AgentLogger
    from multi_agent_base.providers.factory import BaseModelClient


@dataclass
class PatternResult:
    """Result from a pattern execution.
    
    Attributes:
        content: Final response content
        agent_responses: Responses from each agent involved
        total_cost: Total cost across all agents
        total_tokens: Total tokens used
        metadata: Additional result metadata
    """
    
    content: str
    agent_responses: list[AgentResponse] = field(default_factory=list)
    total_cost: float = 0.0
    total_tokens: dict[str, int] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)


class BasePattern(ABC):
    """Abstract base class for agent patterns.
    
    All pattern implementations should inherit from this class
    and implement the abstract methods.
    
    Attributes:
        config: System configuration
        logger: Optional agent logger
        cost_tracker: Optional cost tracker
    """
    
    def __init__(
        self,
        config: SystemConfig,
        logger: AgentLogger | None = None,
        cost_tracker: CostTracker | None = None,
    ) -> None:
        """Initialize the pattern.
        
        Args:
            config: System configuration
            logger: Optional logger instance
            cost_tracker: Optional cost tracker instance
        """
        self.config = config
        self.logger = logger
        self.cost_tracker = cost_tracker
        self._agents: dict[str, BaseAgent] = {}
    
    @abstractmethod
    async def run(self, message: str, **kwargs: Any) -> PatternResult:
        """Run the pattern with the given message.
        
        Args:
            message: User message to process
            **kwargs: Additional arguments
            
        Returns:
            PatternResult with the outcome
        """
        pass
    
    @abstractmethod
    def create_agent(
        self,
        name: str,
        system_prompt: str,
        tools: list[Tool | Callable[..., Any]] | None = None,
        **kwargs: Any,
    ) -> BaseAgent:
        """Create an agent within this pattern.
        
        Args:
            name: Agent name
            system_prompt: System prompt for the agent
            tools: Optional list of tools
            **kwargs: Additional agent configuration
            
        Returns:
            Created BaseAgent instance
        """
        pass
    
    def get_agents(self) -> dict[str, BaseAgent]:
        """Get all agents in this pattern.
        
        Returns:
            Dictionary of agent name to agent instance
        """
        return self._agents.copy()
    
    def get_agent(self, name: str) -> BaseAgent | None:
        """Get a specific agent by name.
        
        Args:
            name: Agent name
            
        Returns:
            Agent instance or None if not found
        """
        return self._agents.get(name)
    
    def _create_model_client(self) -> "BaseModelClient":
        """Create a model client from the system configuration.
        
        This ensures all agents created by patterns have a working
        model client for LLM calls.
        
        Returns:
            Configured BaseModelClient instance
        """
        from multi_agent_base.providers.factory import ModelClientFactory
        
        return ModelClientFactory.create(
            config=self.config.provider,
            resilience_config=getattr(self.config, 'resilience', None),
        )


class SingleAgentPattern(BasePattern):
    """Single agent pattern with tool support.
    
    This is the simplest pattern, consisting of a single agent
    that can use tools to accomplish tasks.
    
    Example:
        ```python
        pattern = SingleAgentPattern(config)
        agent = pattern.create_agent(
            name="assistant",
            system_prompt="You are a helpful assistant.",
            tools=[search_tool, calculator_tool],
        )
        result = await pattern.run("What is 2+2?")
        print(result.content)
        ```
    """
    
    def __init__(
        self,
        config: SystemConfig,
        logger: AgentLogger | None = None,
        cost_tracker: CostTracker | None = None,
    ) -> None:
        """Initialize single agent pattern."""
        super().__init__(config, logger, cost_tracker)
        self._primary_agent: BaseAgent | None = None
    
    def create_agent(
        self,
        name: str,
        system_prompt: str,
        tools: list[Tool | Callable[..., Any]] | None = None,
        **kwargs: Any,
    ) -> BaseAgent:
        """Create the primary agent for this pattern.
        
        Args:
            name: Agent name
            system_prompt: System prompt
            tools: Optional tools list
            **kwargs: Additional configuration
            
        Returns:
            Created agent instance
        """
        from multi_agent_base.core.agent import BaseAgent, Tool
        from multi_agent_base.core.config import AgentConfig
        from multi_agent_base.providers.factory import ModelClientFactory
        
        agent_config = AgentConfig(
            name=name,
            system_prompt=system_prompt,
            **kwargs,
        )
        
        # Convert callable tools to Tool instances
        tool_list = []
        if tools:
            for tool in tools:
                if isinstance(tool, Tool):
                    tool_list.append(tool)
                elif callable(tool):
                    # Will be converted by BaseAgent
                    tool_list.append(tool)
        
        # Create model client from provider config
        model_client = ModelClientFactory.create(
            config=self.config.provider,
            resilience_config=getattr(self.config, 'resilience', None),
        )
        
        agent = BaseAgent(
            name=name,
            config=agent_config,
            provider_config=self.config.provider,
            tools=None,  # Register after creation
            logger=self.logger,
            cost_tracker=self.cost_tracker,
            model_client=model_client,
        )
        
        # Register tools
        for tool in tool_list:
            agent.register_tool(tool)
        
        self._agents[name] = agent
        self._primary_agent = agent
        
        return agent
    
    async def run(self, message: str, **kwargs: Any) -> PatternResult:
        """Run the single agent pattern.
        
        Args:
            message: User message
            **kwargs: Additional arguments
            
        Returns:
            PatternResult with response
        """
        if not self._primary_agent:
            raise RuntimeError("No agent created. Call create_agent first.")
        
        response = await self._primary_agent.run(message, **kwargs)
        
        return PatternResult(
            content=response.content,
            agent_responses=[response],
            total_cost=response.cost or 0.0,
            total_tokens=response.usage,
        )


class SupervisorPattern(BasePattern):
    """Supervisor pattern with worker agents.
    
    A supervisor agent orchestrates multiple worker agents,
    delegating tasks and synthesizing results.
    
    Example:
        ```python
        pattern = SupervisorPattern(config)
        
        pattern.create_supervisor(
            name="manager",
            system_prompt="You manage a team of specialists.",
        )
        
        pattern.create_worker(
            name="researcher",
            system_prompt="You research topics thoroughly.",
        )
        
        pattern.create_worker(
            name="writer",
            system_prompt="You write clear content.",
        )
        
        result = await pattern.run("Write a report on AI agents.")
        ```
    """
    
    def __init__(
        self,
        config: SystemConfig,
        logger: AgentLogger | None = None,
        cost_tracker: CostTracker | None = None,
    ) -> None:
        """Initialize supervisor pattern."""
        super().__init__(config, logger, cost_tracker)
        self._supervisor: BaseAgent | None = None
        self._workers: dict[str, BaseAgent] = {}
    
    def create_agent(
        self,
        name: str,
        system_prompt: str,
        tools: list[Tool | Callable[..., Any]] | None = None,
        role: str = "worker",
        **kwargs: Any,
    ) -> BaseAgent:
        """Create an agent in the supervisor pattern.
        
        Args:
            name: Agent name
            system_prompt: System prompt
            tools: Optional tools
            role: 'supervisor' or 'worker'
            **kwargs: Additional configuration
            
        Returns:
            Created agent instance
        """
        if role == "supervisor":
            return self.create_supervisor(name, system_prompt, tools, **kwargs)
        return self.create_worker(name, system_prompt, tools, **kwargs)
    
    def create_supervisor(
        self,
        name: str,
        system_prompt: str,
        tools: list[Tool | Callable[..., Any]] | None = None,
        **kwargs: Any,
    ) -> BaseAgent:
        """Create the supervisor agent.
        
        Args:
            name: Supervisor name
            system_prompt: System prompt
            tools: Optional tools
            **kwargs: Additional configuration
            
        Returns:
            Created supervisor agent
        """
        from multi_agent_base.core.agent import BaseAgent
        from multi_agent_base.core.config import AgentConfig
        
        # Enhanced system prompt for supervisor role
        enhanced_prompt = f"""{system_prompt}

You are a supervisor managing the following workers: {{workers}}

To delegate a task to a worker, respond with:
DELEGATE TO [worker_name]: [task description]

To provide the final answer, respond with:
FINAL ANSWER: [your response]
"""
        
        agent_config = AgentConfig(
            name=name,
            system_prompt=enhanced_prompt,
            **kwargs,
        )
        
        agent = BaseAgent(
            name=name,
            config=agent_config,
            provider_config=self.config.provider,
            logger=self.logger,
            cost_tracker=self.cost_tracker,
            model_client=self._create_model_client(),
        )
        
        if tools:
            for tool in tools:
                agent.register_tool(tool)
        
        self._supervisor = agent
        self._agents[name] = agent
        
        return agent
    
    def create_worker(
        self,
        name: str,
        system_prompt: str,
        tools: list[Tool | Callable[..., Any]] | None = None,
        **kwargs: Any,
    ) -> BaseAgent:
        """Create a worker agent.
        
        Args:
            name: Worker name
            system_prompt: System prompt
            tools: Optional tools
            **kwargs: Additional configuration
            
        Returns:
            Created worker agent
        """
        from multi_agent_base.core.agent import BaseAgent
        from multi_agent_base.core.config import AgentConfig
        
        agent_config = AgentConfig(
            name=name,
            system_prompt=system_prompt,
            **kwargs,
        )
        
        agent = BaseAgent(
            name=name,
            config=agent_config,
            provider_config=self.config.provider,
            logger=self.logger,
            cost_tracker=self.cost_tracker,
            model_client=self._create_model_client(),
        )
        
        if tools:
            for tool in tools:
                agent.register_tool(tool)
        
        self._workers[name] = agent
        self._agents[name] = agent
        
        return agent
    
    def create_team(
        self,
        supervisor_name: str,
        worker_configs: list[dict[str, Any]],
        supervisor_prompt: str = "You are a supervisor managing a team.",
    ) -> BaseAgent:
        """Create a complete supervisor team.
        
        Args:
            supervisor_name: Name for the supervisor
            worker_configs: List of worker configuration dicts
            supervisor_prompt: System prompt for supervisor
            
        Returns:
            The supervisor agent
        """
        # Create workers first
        worker_names = []
        for wc in worker_configs:
            name = wc.pop("name")
            system_prompt = wc.pop("system_prompt", "You are a helpful worker.")
            tools = wc.pop("tools", None)
            self.create_worker(name, system_prompt, tools, **wc)
            worker_names.append(name)
        
        # Create supervisor with worker list
        supervisor = self.create_supervisor(
            name=supervisor_name,
            system_prompt=supervisor_prompt.format(workers=", ".join(worker_names)),
        )
        
        return supervisor
    
    async def run(self, message: str, max_iterations: int = 10, **kwargs: Any) -> PatternResult:
        """Run the supervisor pattern.
        
        The supervisor will orchestrate workers until it provides
        a final answer or max iterations is reached.
        
        Args:
            message: User message
            max_iterations: Maximum delegation iterations
            **kwargs: Additional arguments
            
        Returns:
            PatternResult with response
        """
        if not self._supervisor:
            raise RuntimeError("No supervisor created. Call create_supervisor first.")
        
        all_responses = []
        total_cost = 0.0
        total_tokens: dict[str, int] = {}
        
        current_message = message
        
        for _ in range(max_iterations):
            # Get supervisor response
            supervisor_response = await self._supervisor.run(current_message, **kwargs)
            all_responses.append(supervisor_response)
            total_cost += supervisor_response.cost or 0.0
            
            for key, value in supervisor_response.usage.items():
                total_tokens[key] = total_tokens.get(key, 0) + value
            
            content = supervisor_response.content
            
            # Check for final answer
            if "FINAL ANSWER:" in content:
                final_answer = content.split("FINAL ANSWER:", 1)[1].strip()
                return PatternResult(
                    content=final_answer,
                    agent_responses=all_responses,
                    total_cost=total_cost,
                    total_tokens=total_tokens,
                )
            
            # Check for delegation
            if "DELEGATE TO" in content:
                parts = content.split("DELEGATE TO", 1)[1]
                if ":" in parts:
                    worker_name = parts.split(":", 1)[0].strip().strip("[]")
                    task = parts.split(":", 1)[1].strip()
                    
                    worker = self._workers.get(worker_name)
                    if worker:
                        worker_response = await worker.run(task, **kwargs)
                        all_responses.append(worker_response)
                        total_cost += worker_response.cost or 0.0
                        
                        for key, value in worker_response.usage.items():
                            total_tokens[key] = total_tokens.get(key, 0) + value
                        
                        # Feed worker response back to supervisor
                        current_message = f"Worker {worker_name} responded: {worker_response.content}"
                        continue
            
            # No delegation or final answer, treat as final
            return PatternResult(
                content=content,
                agent_responses=all_responses,
                total_cost=total_cost,
                total_tokens=total_tokens,
            )
        
        # Max iterations reached
        return PatternResult(
            content="Max iterations reached without final answer.",
            agent_responses=all_responses,
            total_cost=total_cost,
            total_tokens=total_tokens,
            metadata={"max_iterations_reached": True},
        )


class SwarmPattern(BasePattern):
    """Swarm pattern with dynamic agent handoffs.
    
    Agents can dynamically hand off conversations to other agents
    based on the context and task requirements.
    
    Example:
        ```python
        pattern = SwarmPattern(config)
        
        sales_agent = pattern.create_agent(
            name="sales",
            system_prompt="You handle sales inquiries.",
            can_handoff_to=["support", "billing"],
        )
        
        support_agent = pattern.create_agent(
            name="support",
            system_prompt="You handle support issues.",
            can_handoff_to=["sales", "billing"],
        )
        
        result = await pattern.run(
            "I want to buy a product",
            start_agent="sales"
        )
        ```
    """
    
    def __init__(
        self,
        config: SystemConfig,
        logger: AgentLogger | None = None,
        cost_tracker: CostTracker | None = None,
    ) -> None:
        """Initialize swarm pattern."""
        super().__init__(config, logger, cost_tracker)
        self._handoff_map: dict[str, list[str]] = {}
        self._start_agent: str | None = None
    
    def create_agent(
        self,
        name: str,
        system_prompt: str,
        tools: list[Tool | Callable[..., Any]] | None = None,
        can_handoff_to: list[str] | None = None,
        is_start_agent: bool = False,
        **kwargs: Any,
    ) -> BaseAgent:
        """Create an agent in the swarm.
        
        Args:
            name: Agent name
            system_prompt: System prompt
            tools: Optional tools
            can_handoff_to: List of agent names this agent can hand off to
            is_start_agent: Whether this is the starting agent
            **kwargs: Additional configuration
            
        Returns:
            Created agent instance
        """
        from multi_agent_base.core.agent import BaseAgent
        from multi_agent_base.core.config import AgentConfig
        
        # Record handoff capabilities
        self._handoff_map[name] = can_handoff_to or []
        
        # Enhanced system prompt for handoff
        handoff_targets = can_handoff_to or []
        if handoff_targets:
            handoff_instruction = f"""
You can hand off to the following agents: {', '.join(handoff_targets)}

To hand off, respond with:
HANDOFF TO [agent_name]: [context/reason]

To provide a final response, just respond normally without HANDOFF.
"""
            enhanced_prompt = f"{system_prompt}\n{handoff_instruction}"
        else:
            enhanced_prompt = system_prompt
        
        agent_config = AgentConfig(
            name=name,
            system_prompt=enhanced_prompt,
            **kwargs,
        )
        
        agent = BaseAgent(
            name=name,
            config=agent_config,
            provider_config=self.config.provider,
            logger=self.logger,
            cost_tracker=self.cost_tracker,
            model_client=self._create_model_client(),
        )
        
        if tools:
            for tool in tools:
                agent.register_tool(tool)
        
        self._agents[name] = agent
        
        if is_start_agent or self._start_agent is None:
            self._start_agent = name
        
        return agent
    
    async def run(
        self,
        message: str,
        start_agent: str | None = None,
        max_handoffs: int = 10,
        **kwargs: Any,
    ) -> PatternResult:
        """Run the swarm pattern.
        
        The conversation will flow through agents via handoffs
        until a final response is provided.
        
        Args:
            message: User message
            start_agent: Starting agent name (optional)
            max_handoffs: Maximum number of handoffs
            **kwargs: Additional arguments
            
        Returns:
            PatternResult with response
        """
        current_agent_name = start_agent or self._start_agent
        if not current_agent_name or current_agent_name not in self._agents:
            raise RuntimeError(f"Start agent '{current_agent_name}' not found.")
        
        all_responses = []
        total_cost = 0.0
        total_tokens: dict[str, int] = {}
        
        current_message = message
        handoff_count = 0
        
        while handoff_count < max_handoffs:
            current_agent = self._agents[current_agent_name]
            
            response = await current_agent.run(current_message, **kwargs)
            all_responses.append(response)
            total_cost += response.cost or 0.0
            
            for key, value in response.usage.items():
                total_tokens[key] = total_tokens.get(key, 0) + value
            
            content = response.content
            
            # Check for handoff
            if "HANDOFF TO" in content:
                parts = content.split("HANDOFF TO", 1)[1]
                if ":" in parts:
                    target_name = parts.split(":", 1)[0].strip().strip("[]")
                    context = parts.split(":", 1)[1].strip()
                    
                    # Validate handoff is allowed
                    allowed_handoffs = self._handoff_map.get(current_agent_name, [])
                    if target_name in allowed_handoffs and target_name in self._agents:
                        current_agent_name = target_name
                        current_message = f"Handed off from previous agent with context: {context}\n\nOriginal message: {message}"
                        handoff_count += 1
                        continue
            
            # No handoff, this is the final response
            return PatternResult(
                content=content,
                agent_responses=all_responses,
                total_cost=total_cost,
                total_tokens=total_tokens,
                metadata={
                    "handoff_count": handoff_count,
                    "final_agent": current_agent_name,
                },
            )
        
        # Max handoffs reached
        last_response = all_responses[-1] if all_responses else None
        return PatternResult(
            content=last_response.content if last_response else "Max handoffs reached.",
            agent_responses=all_responses,
            total_cost=total_cost,
            total_tokens=total_tokens,
            metadata={
                "max_handoffs_reached": True,
                "handoff_count": handoff_count,
            },
        )


class PipelinePattern(BasePattern):
    """Pipeline pattern for sequential agent processing.
    
    Each agent in the pipeline processes the output of the previous agent,
    enabling complex transformation workflows.
    
    Example:
        ```python
        pattern = PipelinePattern(config)
        
        pattern.add_stage("researcher", "You research and gather information.")
        pattern.add_stage("analyzer", "You analyze the research findings.")
        pattern.add_stage("writer", "You write a clear summary.")
        
        result = await pattern.run("Explain quantum computing")
        # Research -> Analysis -> Summary
        ```
    """
    
    def __init__(
        self,
        config: SystemConfig,
        logger: AgentLogger | None = None,
        cost_tracker: CostTracker | None = None,
    ) -> None:
        """Initialize pipeline pattern."""
        super().__init__(config, logger, cost_tracker)
        self._stages: list[str] = []  # Ordered list of agent names
        self._transformers: dict[str, Callable[[str], str] | None] = {}
    
    def create_agent(
        self,
        name: str,
        system_prompt: str,
        tools: list[Tool | Callable[..., Any]] | None = None,
        position: int | None = None,
        **kwargs: Any,
    ) -> BaseAgent:
        """Create an agent and add it to the pipeline.
        
        Args:
            name: Agent name
            system_prompt: System prompt
            tools: Optional tools
            position: Position in pipeline (None = append)
            **kwargs: Additional configuration
            
        Returns:
            Created agent instance
        """
        from multi_agent_base.core.agent import BaseAgent
        from multi_agent_base.core.config import AgentConfig
        
        agent_config = AgentConfig(
            name=name,
            system_prompt=system_prompt,
            **kwargs,
        )
        
        agent = BaseAgent(
            name=name,
            config=agent_config,
            provider_config=self.config.provider,
            logger=self.logger,
            cost_tracker=self.cost_tracker,
            model_client=self._create_model_client(),
        )
        
        if tools:
            for tool in tools:
                agent.register_tool(tool)
        
        self._agents[name] = agent
        
        if position is not None:
            self._stages.insert(position, name)
        else:
            self._stages.append(name)
        
        return agent
    
    def add_stage(
        self,
        name: str,
        system_prompt: str,
        tools: list[Tool | Callable[..., Any]] | None = None,
        transformer: Callable[[str], str] | None = None,
        **kwargs: Any,
    ) -> BaseAgent:
        """Add a stage to the pipeline.
        
        Args:
            name: Stage agent name
            system_prompt: System prompt
            tools: Optional tools
            transformer: Optional output transformer function
            **kwargs: Additional configuration
            
        Returns:
            Created agent
        """
        agent = self.create_agent(name, system_prompt, tools, **kwargs)
        self._transformers[name] = transformer
        return agent
    
    def insert_stage(
        self,
        position: int,
        name: str,
        system_prompt: str,
        tools: list[Tool | Callable[..., Any]] | None = None,
        **kwargs: Any,
    ) -> BaseAgent:
        """Insert a stage at a specific position."""
        return self.create_agent(name, system_prompt, tools, position=position, **kwargs)
    
    def remove_stage(self, name: str) -> bool:
        """Remove a stage from the pipeline."""
        if name in self._stages:
            self._stages.remove(name)
            self._agents.pop(name, None)
            self._transformers.pop(name, None)
            return True
        return False
    
    def get_stages(self) -> list[str]:
        """Get ordered list of stage names."""
        return self._stages.copy()
    
    async def run(
        self,
        message: str,
        skip_stages: list[str] | None = None,
        **kwargs: Any,
    ) -> PatternResult:
        """Run the pipeline pattern.
        
        Args:
            message: Initial input message
            skip_stages: Optional stages to skip
            **kwargs: Additional arguments
            
        Returns:
            PatternResult with final output
        """
        if not self._stages:
            raise RuntimeError("No stages in pipeline. Call add_stage first.")
        
        skip_stages = skip_stages or []
        all_responses = []
        total_cost = 0.0
        total_tokens: dict[str, int] = {}
        stage_outputs: dict[str, str] = {}
        
        current_input = message
        
        for stage_name in self._stages:
            if stage_name in skip_stages:
                continue
            
            agent = self._agents.get(stage_name)
            if not agent:
                continue
            
            # Create stage-aware prompt
            stage_message = f"Previous context:\n{current_input}\n\nProcess and provide your output:"
            
            response = await agent.run(stage_message, **kwargs)
            all_responses.append(response)
            total_cost += response.cost or 0.0
            
            for key, value in response.usage.items():
                total_tokens[key] = total_tokens.get(key, 0) + value
            
            # Apply transformer if exists
            output = response.content
            transformer = self._transformers.get(stage_name)
            if transformer:
                output = transformer(output)
            
            stage_outputs[stage_name] = output
            current_input = output
        
        return PatternResult(
            content=current_input,
            agent_responses=all_responses,
            total_cost=total_cost,
            total_tokens=total_tokens,
            metadata={
                "stages_executed": [s for s in self._stages if s not in skip_stages],
                "stage_outputs": stage_outputs,
            },
        )


class ParallelPattern(BasePattern):
    """Parallel/MapReduce pattern for concurrent agent execution.
    
    Splits tasks across multiple agents running in parallel,
    then aggregates the results.
    
    Example:
        ```python
        pattern = ParallelPattern(config)
        
        pattern.create_agent("analyst1", "Analyze from technical perspective.")
        pattern.create_agent("analyst2", "Analyze from business perspective.")
        pattern.create_agent("analyst3", "Analyze from user perspective.")
        
        pattern.set_aggregator("aggregator", "Combine all analyses into one report.")
        
        result = await pattern.run("Evaluate this product design")
        ```
    """
    
    def __init__(
        self,
        config: SystemConfig,
        logger: AgentLogger | None = None,
        cost_tracker: CostTracker | None = None,
    ) -> None:
        """Initialize parallel pattern."""
        super().__init__(config, logger, cost_tracker)
        self._worker_names: list[str] = []
        self._aggregator: BaseAgent | None = None
        self._aggregator_name: str | None = None
    
    def create_agent(
        self,
        name: str,
        system_prompt: str,
        tools: list[Tool | Callable[..., Any]] | None = None,
        is_aggregator: bool = False,
        **kwargs: Any,
    ) -> BaseAgent:
        """Create an agent for parallel execution.
        
        Args:
            name: Agent name
            system_prompt: System prompt
            tools: Optional tools
            is_aggregator: If True, this is the aggregator agent
            **kwargs: Additional configuration
            
        Returns:
            Created agent
        """
        from multi_agent_base.core.agent import BaseAgent
        from multi_agent_base.core.config import AgentConfig
        
        agent_config = AgentConfig(
            name=name,
            system_prompt=system_prompt,
            **kwargs,
        )
        
        agent = BaseAgent(
            name=name,
            config=agent_config,
            provider_config=self.config.provider,
            logger=self.logger,
            cost_tracker=self.cost_tracker,
            model_client=self._create_model_client(),
        )
        
        if tools:
            for tool in tools:
                agent.register_tool(tool)
        
        self._agents[name] = agent
        
        if is_aggregator:
            self._aggregator = agent
            self._aggregator_name = name
        else:
            self._worker_names.append(name)
        
        return agent
    
    def set_aggregator(
        self,
        name: str,
        system_prompt: str,
        tools: list[Tool | Callable[..., Any]] | None = None,
        **kwargs: Any,
    ) -> BaseAgent:
        """Set the aggregator agent for combining results."""
        return self.create_agent(name, system_prompt, tools, is_aggregator=True, **kwargs)
    
    def add_workers(
        self,
        worker_configs: list[dict[str, Any]],
    ) -> list[BaseAgent]:
        """Add multiple worker agents at once."""
        agents = []
        for config in worker_configs:
            name = config.pop("name")
            system_prompt = config.pop("system_prompt")
            tools = config.pop("tools", None)
            agents.append(self.create_agent(name, system_prompt, tools, **config))
        return agents
    
    async def run(
        self,
        message: str,
        aggregate: bool = True,
        **kwargs: Any,
    ) -> PatternResult:
        """Run workers in parallel and optionally aggregate.
        
        Args:
            message: Input message for all workers
            aggregate: Whether to aggregate results
            **kwargs: Additional arguments
            
        Returns:
            PatternResult with aggregated or combined output
        """
        import asyncio
        
        if not self._worker_names:
            raise RuntimeError("No worker agents created.")
        
        all_responses = []
        total_cost = 0.0
        total_tokens: dict[str, int] = {}
        worker_outputs: dict[str, str] = {}
        
        # Run all workers in parallel
        async def run_worker(name: str) -> tuple[str, Any]:
            agent = self._agents[name]
            response = await agent.run(message, **kwargs)
            return name, response
        
        tasks = [run_worker(name) for name in self._worker_names]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        for result in results:
            if isinstance(result, Exception):
                continue
            name, response = result
            all_responses.append(response)
            total_cost += response.cost or 0.0
            worker_outputs[name] = response.content
            
            for key, value in response.usage.items():
                total_tokens[key] = total_tokens.get(key, 0) + value
        
        # Aggregate if requested and aggregator exists
        final_content = ""
        if aggregate and self._aggregator:
            # Create aggregation prompt
            outputs_text = "\n\n".join([
                f"[{name}]:\n{output}"
                for name, output in worker_outputs.items()
            ])
            agg_message = f"Aggregate the following outputs:\n\n{outputs_text}"
            
            agg_response = await self._aggregator.run(agg_message, **kwargs)
            all_responses.append(agg_response)
            total_cost += agg_response.cost or 0.0
            
            for key, value in agg_response.usage.items():
                total_tokens[key] = total_tokens.get(key, 0) + value
            
            final_content = agg_response.content
        else:
            # Just combine outputs
            final_content = "\n\n".join([
                f"[{name}]: {output}"
                for name, output in worker_outputs.items()
            ])
        
        return PatternResult(
            content=final_content,
            agent_responses=all_responses,
            total_cost=total_cost,
            total_tokens=total_tokens,
            metadata={
                "worker_count": len(self._worker_names),
                "worker_outputs": worker_outputs,
                "aggregated": aggregate and self._aggregator is not None,
            },
        )
    
    async def map_reduce(
        self,
        items: list[Any],
        map_prompt_template: str,
        reduce_prompt: str | None = None,
        **kwargs: Any,
    ) -> PatternResult:
        """Run MapReduce style operation.
        
        Args:
            items: List of items to process
            map_prompt_template: Template with {item} placeholder
            reduce_prompt: Prompt for reduction (uses aggregator if None)
            **kwargs: Additional arguments
            
        Returns:
            PatternResult with reduced output
        """
        import asyncio
        
        all_responses = []
        total_cost = 0.0
        total_tokens: dict[str, int] = {}
        mapped_outputs: list[str] = []
        
        # Map phase - distribute items across workers
        workers = [self._agents[name] for name in self._worker_names]
        
        async def map_item(worker: Any, item: Any) -> str:
            prompt = map_prompt_template.format(item=item)
            response = await worker.run(prompt, **kwargs)
            all_responses.append(response)
            return response.content
        
        # Distribute items round-robin
        tasks = []
        for i, item in enumerate(items):
            worker = workers[i % len(workers)]
            tasks.append(map_item(worker, item))
        
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        for result in results:
            if not isinstance(result, Exception):
                mapped_outputs.append(result)
        
        # Reduce phase
        if self._aggregator:
            combined = "\n\n".join([f"- {output}" for output in mapped_outputs])
            reduce_msg = reduce_prompt or f"Reduce these outputs:\n{combined}"
            
            reduce_response = await self._aggregator.run(reduce_msg, **kwargs)
            all_responses.append(reduce_response)
            
            final_content = reduce_response.content
        else:
            final_content = "\n".join(mapped_outputs)
        
        # Calculate totals
        for resp in all_responses:
            total_cost += resp.cost or 0.0
            for key, value in resp.usage.items():
                total_tokens[key] = total_tokens.get(key, 0) + value
        
        return PatternResult(
            content=final_content,
            agent_responses=all_responses,
            total_cost=total_cost,
            total_tokens=total_tokens,
            metadata={
                "items_processed": len(items),
                "mapped_outputs": mapped_outputs,
            },
        )


class RouterPattern(BasePattern):
    """Router pattern for intelligent request routing.
    
    Routes incoming requests to specialized agents based on
    intent classification or content analysis.
    
    Example:
        ```python
        pattern = RouterPattern(config)
        
        pattern.add_route("sales", "You handle sales inquiries.", 
                         keywords=["buy", "purchase", "price"])
        pattern.add_route("support", "You handle technical support.",
                         keywords=["help", "error", "broken"])
        pattern.add_route("general", "You handle general questions.")
        
        pattern.set_default_route("general")
        
        result = await pattern.run("How do I fix this error?")
        # Routes to 'support' agent
        ```
    """
    
    def __init__(
        self,
        config: SystemConfig,
        logger: AgentLogger | None = None,
        cost_tracker: CostTracker | None = None,
    ) -> None:
        """Initialize router pattern."""
        super().__init__(config, logger, cost_tracker)
        self._routes: dict[str, dict[str, Any]] = {}
        self._default_route: str | None = None
        self._router_agent: BaseAgent | None = None
    
    def create_agent(
        self,
        name: str,
        system_prompt: str,
        tools: list[Tool | Callable[..., Any]] | None = None,
        keywords: list[str] | None = None,
        patterns: list[str] | None = None,
        **kwargs: Any,
    ) -> BaseAgent:
        """Create a routable agent."""
        from multi_agent_base.core.agent import BaseAgent
        from multi_agent_base.core.config import AgentConfig
        
        agent_config = AgentConfig(
            name=name,
            system_prompt=system_prompt,
            **kwargs,
        )
        
        agent = BaseAgent(
            name=name,
            config=agent_config,
            provider_config=self.config.provider,
            logger=self.logger,
            cost_tracker=self.cost_tracker,
            model_client=self._create_model_client(),
        )
        
        if tools:
            for tool in tools:
                agent.register_tool(tool)
        
        self._agents[name] = agent
        self._routes[name] = {
            "keywords": keywords or [],
            "patterns": patterns or [],
        }
        
        return agent
    
    def add_route(
        self,
        name: str,
        system_prompt: str,
        keywords: list[str] | None = None,
        patterns: list[str] | None = None,
        tools: list[Tool | Callable[..., Any]] | None = None,
        **kwargs: Any,
    ) -> BaseAgent:
        """Add a route with matching rules."""
        return self.create_agent(name, system_prompt, tools, keywords, patterns, **kwargs)
    
    def set_default_route(self, name: str) -> None:
        """Set the default route for unmatched requests."""
        if name not in self._agents:
            raise ValueError(f"Agent '{name}' not found")
        self._default_route = name
    
    def set_router_agent(
        self,
        name: str = "router",
        system_prompt: str | None = None,
    ) -> BaseAgent:
        """Set an LLM-based router agent for intelligent routing."""
        route_descriptions = "\n".join([
            f"- {name}: For requests matching keywords {route['keywords']}"
            for name, route in self._routes.items()
        ])
        
        default_prompt = f"""You are a routing agent. Analyze the user message and decide which specialist agent should handle it.

Available agents:
{route_descriptions}

Respond with ONLY the agent name that should handle this request."""
        
        agent = self.create_agent(
            name=name,
            system_prompt=system_prompt or default_prompt,
        )
        self._router_agent = agent
        return agent
    
    def _match_keywords(self, message: str, keywords: list[str]) -> bool:
        """Check if message matches any keywords."""
        message_lower = message.lower()
        return any(kw.lower() in message_lower for kw in keywords)
    
    def _match_patterns(self, message: str, patterns: list[str]) -> bool:
        """Check if message matches any regex patterns."""
        import re
        return any(re.search(pattern, message, re.IGNORECASE) for pattern in patterns)
    
    def route(self, message: str) -> str | None:
        """Determine which agent should handle the message.
        
        Returns agent name or None if no match.
        """
        for name, route in self._routes.items():
            if route["keywords"] and self._match_keywords(message, route["keywords"]):
                return name
            if route["patterns"] and self._match_patterns(message, route["patterns"]):
                return name
        
        return self._default_route
    
    async def run(
        self,
        message: str,
        force_route: str | None = None,
        use_llm_router: bool = False,
        **kwargs: Any,
    ) -> PatternResult:
        """Run the router pattern.
        
        Args:
            message: User message
            force_route: Force routing to specific agent
            use_llm_router: Use LLM for routing decision
            **kwargs: Additional arguments
            
        Returns:
            PatternResult with response
        """
        all_responses = []
        total_cost = 0.0
        total_tokens: dict[str, int] = {}
        
        # Determine route
        if force_route:
            target_name = force_route
        elif use_llm_router and self._router_agent:
            router_response = await self._router_agent.run(message, **kwargs)
            all_responses.append(router_response)
            total_cost += router_response.cost or 0.0
            
            for key, value in router_response.usage.items():
                total_tokens[key] = total_tokens.get(key, 0) + value
            
            target_name = router_response.content.strip()
        else:
            target_name = self.route(message)
        
        if not target_name or target_name not in self._agents:
            target_name = self._default_route
        
        if not target_name or target_name not in self._agents:
            return PatternResult(
                content="No suitable agent found for this request.",
                agent_responses=all_responses,
                total_cost=total_cost,
                total_tokens=total_tokens,
                metadata={"routing_failed": True},
            )
        
        # Execute target agent
        target_agent = self._agents[target_name]
        response = await target_agent.run(message, **kwargs)
        all_responses.append(response)
        total_cost += response.cost or 0.0
        
        for key, value in response.usage.items():
            total_tokens[key] = total_tokens.get(key, 0) + value
        
        return PatternResult(
            content=response.content,
            agent_responses=all_responses,
            total_cost=total_cost,
            total_tokens=total_tokens,
            metadata={
                "routed_to": target_name,
                "routing_method": "forced" if force_route else ("llm" if use_llm_router else "keyword"),
            },
        )


class ReflectionPattern(BasePattern):
    """Reflection pattern for self-critique and improvement.
    
    An actor agent generates output, then a critic agent reviews
    and suggests improvements, iterating until quality is achieved.
    
    Example:
        ```python
        pattern = ReflectionPattern(config)
        
        pattern.set_actor("writer", "You write content.")
        pattern.set_critic("editor", "You review and suggest improvements.")
        
        result = await pattern.run(
            "Write a poem about AI",
            max_refinements=3
        )
        ```
    """
    
    def __init__(
        self,
        config: SystemConfig,
        logger: AgentLogger | None = None,
        cost_tracker: CostTracker | None = None,
    ) -> None:
        """Initialize reflection pattern."""
        super().__init__(config, logger, cost_tracker)
        self._actor: BaseAgent | None = None
        self._critic: BaseAgent | None = None
        self._actor_name: str | None = None
        self._critic_name: str | None = None
    
    def create_agent(
        self,
        name: str,
        system_prompt: str,
        tools: list[Tool | Callable[..., Any]] | None = None,
        role: str = "actor",
        **kwargs: Any,
    ) -> BaseAgent:
        """Create an agent in the reflection pattern."""
        from multi_agent_base.core.agent import BaseAgent
        from multi_agent_base.core.config import AgentConfig
        
        agent_config = AgentConfig(
            name=name,
            system_prompt=system_prompt,
            **kwargs,
        )
        
        agent = BaseAgent(
            name=name,
            config=agent_config,
            provider_config=self.config.provider,
            logger=self.logger,
            cost_tracker=self.cost_tracker,
            model_client=self._create_model_client(),
        )
        
        if tools:
            for tool in tools:
                agent.register_tool(tool)
        
        self._agents[name] = agent
        
        if role == "actor":
            self._actor = agent
            self._actor_name = name
        elif role == "critic":
            self._critic = agent
            self._critic_name = name
        
        return agent
    
    def set_actor(
        self,
        name: str,
        system_prompt: str,
        tools: list[Tool | Callable[..., Any]] | None = None,
        **kwargs: Any,
    ) -> BaseAgent:
        """Set the actor agent."""
        return self.create_agent(name, system_prompt, tools, role="actor", **kwargs)
    
    def set_critic(
        self,
        name: str,
        system_prompt: str,
        tools: list[Tool | Callable[..., Any]] | None = None,
        **kwargs: Any,
    ) -> BaseAgent:
        """Set the critic agent."""
        enhanced_prompt = f"""{system_prompt}

Review the provided content and respond with:
- If improvements needed: FEEDBACK: [your suggestions]
- If content is good: APPROVED: [any final comments]
"""
        return self.create_agent(name, enhanced_prompt, tools, role="critic", **kwargs)
    
    async def run(
        self,
        message: str,
        max_refinements: int = 3,
        **kwargs: Any,
    ) -> PatternResult:
        """Run the reflection pattern.
        
        Args:
            message: Initial request
            max_refinements: Maximum improvement iterations
            **kwargs: Additional arguments
            
        Returns:
            PatternResult with refined output
        """
        if not self._actor:
            raise RuntimeError("No actor agent set. Call set_actor first.")
        
        all_responses = []
        total_cost = 0.0
        total_tokens: dict[str, int] = {}
        refinement_history: list[dict[str, str]] = []
        
        # Initial generation
        actor_response = await self._actor.run(message, **kwargs)
        all_responses.append(actor_response)
        total_cost += actor_response.cost or 0.0
        
        for key, value in actor_response.usage.items():
            total_tokens[key] = total_tokens.get(key, 0) + value
        
        current_output = actor_response.content
        refinement_history.append({"version": 0, "content": current_output})
        
        # If no critic, return initial output
        if not self._critic:
            return PatternResult(
                content=current_output,
                agent_responses=all_responses,
                total_cost=total_cost,
                total_tokens=total_tokens,
                metadata={"refinements": 0},
            )
        
        # Refinement loop
        for i in range(max_refinements):
            # Get critic feedback
            critic_prompt = f"Review this content:\n\n{current_output}"
            critic_response = await self._critic.run(critic_prompt, **kwargs)
            all_responses.append(critic_response)
            total_cost += critic_response.cost or 0.0
            
            for key, value in critic_response.usage.items():
                total_tokens[key] = total_tokens.get(key, 0) + value
            
            feedback = critic_response.content
            
            # Check if approved
            if "APPROVED:" in feedback:
                break
            
            # Extract feedback and refine
            if "FEEDBACK:" in feedback:
                suggestions = feedback.split("FEEDBACK:", 1)[1].strip()
                
                # Ask actor to refine
                refine_prompt = f"""Original request: {message}

Your previous output:
{current_output}

Feedback for improvement:
{suggestions}

Please provide an improved version."""
                
                actor_response = await self._actor.run(refine_prompt, **kwargs)
                all_responses.append(actor_response)
                total_cost += actor_response.cost or 0.0
                
                for key, value in actor_response.usage.items():
                    total_tokens[key] = total_tokens.get(key, 0) + value
                
                current_output = actor_response.content
                refinement_history.append({
                    "version": i + 1,
                    "content": current_output,
                    "feedback": suggestions,
                })
        
        return PatternResult(
            content=current_output,
            agent_responses=all_responses,
            total_cost=total_cost,
            total_tokens=total_tokens,
            metadata={
                "refinements": len(refinement_history) - 1,
                "refinement_history": refinement_history,
            },
        )


@dataclass
class BlackboardEntry:
    """Entry in the blackboard."""
    key: str
    value: Any
    author: str
    timestamp: float = field(default_factory=lambda: __import__("time").time())
    metadata: dict[str, Any] = field(default_factory=dict)


class BlackboardPattern(BasePattern):
    """Blackboard pattern for collaborative problem solving.
    
    Agents share a common workspace (blackboard) where they can
    read and write information to collaboratively solve problems.
    
    Example:
        ```python
        pattern = BlackboardPattern(config)
        
        pattern.create_agent("researcher", "Research and add findings to blackboard.")
        pattern.create_agent("analyst", "Analyze blackboard data and add insights.")
        pattern.create_agent("writer", "Synthesize blackboard content into report.")
        
        # Initial problem
        pattern.write("problem", "How can we improve user engagement?")
        
        result = await pattern.run(max_rounds=3)
        ```
    """
    
    def __init__(
        self,
        config: SystemConfig,
        logger: AgentLogger | None = None,
        cost_tracker: CostTracker | None = None,
    ) -> None:
        """Initialize blackboard pattern."""
        super().__init__(config, logger, cost_tracker)
        self._blackboard: dict[str, BlackboardEntry] = {}
        self._history: list[BlackboardEntry] = []
        self._agent_order: list[str] = []
    
    def create_agent(
        self,
        name: str,
        system_prompt: str,
        tools: list[Tool | Callable[..., Any]] | None = None,
        **kwargs: Any,
    ) -> BaseAgent:
        """Create an agent that can access the blackboard."""
        from multi_agent_base.core.agent import BaseAgent
        from multi_agent_base.core.config import AgentConfig
        
        # Enhance prompt with blackboard instructions
        enhanced_prompt = f"""{system_prompt}

You have access to a shared blackboard. The current blackboard state will be provided.

To add information to the blackboard, use this format in your response:
WRITE [key]: [value]

To indicate you're done contributing:
DONE: [summary of your contribution]
"""
        
        agent_config = AgentConfig(
            name=name,
            system_prompt=enhanced_prompt,
            **kwargs,
        )
        
        agent = BaseAgent(
            name=name,
            config=agent_config,
            provider_config=self.config.provider,
            logger=self.logger,
            cost_tracker=self.cost_tracker,
            model_client=self._create_model_client(),
        )
        
        if tools:
            for tool in tools:
                agent.register_tool(tool)
        
        self._agents[name] = agent
        self._agent_order.append(name)
        
        return agent
    
    def write(self, key: str, value: Any, author: str = "system") -> None:
        """Write to the blackboard."""
        entry = BlackboardEntry(key=key, value=value, author=author)
        self._blackboard[key] = entry
        self._history.append(entry)
    
    def read(self, key: str) -> Any | None:
        """Read from the blackboard."""
        entry = self._blackboard.get(key)
        return entry.value if entry else None
    
    def read_all(self) -> dict[str, Any]:
        """Read all blackboard entries."""
        return {k: v.value for k, v in self._blackboard.items()}
    
    def get_history(self) -> list[BlackboardEntry]:
        """Get blackboard modification history."""
        return self._history.copy()
    
    def clear(self) -> None:
        """Clear the blackboard."""
        self._blackboard.clear()
        self._history.clear()
    
    def _format_blackboard(self) -> str:
        """Format blackboard state for agent consumption."""
        if not self._blackboard:
            return "Blackboard is empty."
        
        lines = ["Current Blackboard State:", "=" * 40]
        for key, entry in self._blackboard.items():
            lines.append(f"[{key}] (by {entry.author}):")
            lines.append(f"  {entry.value}")
            lines.append("")
        
        return "\n".join(lines)
    
    def _parse_writes(self, content: str, author: str) -> list[tuple[str, str]]:
        """Parse WRITE commands from agent response."""
        writes = []
        for line in content.split("\n"):
            if line.strip().startswith("WRITE "):
                parts = line.split(":", 1)
                if len(parts) == 2:
                    key = parts[0].replace("WRITE ", "").strip().strip("[]")
                    value = parts[1].strip()
                    writes.append((key, value))
                    self.write(key, value, author)
        return writes
    
    async def run(
        self,
        message: str | None = None,
        max_rounds: int = 3,
        agents_per_round: list[str] | None = None,
        **kwargs: Any,
    ) -> PatternResult:
        """Run the blackboard pattern.
        
        Args:
            message: Optional initial message (written to blackboard)
            max_rounds: Maximum collaboration rounds
            agents_per_round: Specific agent order (None = all agents each round)
            **kwargs: Additional arguments
            
        Returns:
            PatternResult with final blackboard state
        """
        if not self._agents:
            raise RuntimeError("No agents created.")
        
        all_responses = []
        total_cost = 0.0
        total_tokens: dict[str, int] = {}
        
        # Write initial message if provided
        if message:
            self.write("initial_problem", message)
        
        agent_sequence = agents_per_round or self._agent_order
        
        for round_num in range(max_rounds):
            round_changes = []
            
            for agent_name in agent_sequence:
                agent = self._agents.get(agent_name)
                if not agent:
                    continue
                
                # Create prompt with blackboard state
                prompt = f"""{self._format_blackboard()}

Round {round_num + 1}: Please review the blackboard and contribute your expertise."""
                
                response = await agent.run(prompt, **kwargs)
                all_responses.append(response)
                total_cost += response.cost or 0.0
                
                for key, value in response.usage.items():
                    total_tokens[key] = total_tokens.get(key, 0) + value
                
                # Parse and apply writes
                writes = self._parse_writes(response.content, agent_name)
                round_changes.extend(writes)
                
                # Check if agent is done
                if "DONE:" in response.content:
                    continue
            
            # If no changes this round, we're done
            if not round_changes:
                break
        
        # Format final output
        final_content = self._format_blackboard()
        
        return PatternResult(
            content=final_content,
            agent_responses=all_responses,
            total_cost=total_cost,
            total_tokens=total_tokens,
            metadata={
                "rounds_completed": round_num + 1,
                "blackboard_state": self.read_all(),
                "modification_count": len(self._history),
            },
        )


class CompositePattern(BasePattern):
    """Composite pattern for combining multiple patterns.
    
    Allows nesting and chaining patterns for complex workflows.
    
    Example:
        ```python
        # Create sub-patterns
        research_pattern = PipelinePattern(config)
        research_pattern.add_stage("gather", "Gather information")
        research_pattern.add_stage("analyze", "Analyze findings")
        
        review_pattern = ReflectionPattern(config)
        review_pattern.set_actor("writer", "Write report")
        review_pattern.set_critic("editor", "Review report")
        
        # Combine them
        composite = CompositePattern(config)
        composite.add_pattern("research", research_pattern)
        composite.add_pattern("review", review_pattern)
        composite.set_flow(["research", "review"])
        
        result = await composite.run("Research AI trends")
        ```
    """
    
    def __init__(
        self,
        config: SystemConfig,
        logger: AgentLogger | None = None,
        cost_tracker: CostTracker | None = None,
    ) -> None:
        """Initialize composite pattern."""
        super().__init__(config, logger, cost_tracker)
        self._patterns: dict[str, BasePattern] = {}
        self._flow: list[str] = []
        self._transformers: dict[str, Callable[[str], str]] = {}
    
    def create_agent(
        self,
        name: str,
        system_prompt: str,
        tools: list[Tool | Callable[..., Any]] | None = None,
        **kwargs: Any,
    ) -> BaseAgent:
        """Not directly supported - use add_pattern instead."""
        raise NotImplementedError(
            "CompositePattern doesn't create agents directly. "
            "Add sub-patterns with add_pattern()."
        )
    
    def add_pattern(
        self,
        name: str,
        pattern: BasePattern,
        output_transformer: Callable[[str], str] | None = None,
    ) -> None:
        """Add a sub-pattern.
        
        Args:
            name: Pattern identifier
            pattern: Pattern instance
            output_transformer: Optional function to transform output
        """
        self._patterns[name] = pattern
        if output_transformer:
            self._transformers[name] = output_transformer
        
        # Add pattern's agents to our registry
        for agent_name, agent in pattern.get_agents().items():
            self._agents[f"{name}.{agent_name}"] = agent
    
    def set_flow(self, pattern_names: list[str]) -> None:
        """Set the execution flow order."""
        for name in pattern_names:
            if name not in self._patterns:
                raise ValueError(f"Pattern '{name}' not found")
        self._flow = pattern_names
    
    def get_pattern(self, name: str) -> BasePattern | None:
        """Get a sub-pattern by name."""
        return self._patterns.get(name)
    
    async def run(
        self,
        message: str,
        pattern_kwargs: dict[str, dict[str, Any]] | None = None,
        **kwargs: Any,
    ) -> PatternResult:
        """Run the composite pattern.
        
        Args:
            message: Input message
            pattern_kwargs: Per-pattern additional arguments
            **kwargs: Arguments passed to all patterns
            
        Returns:
            PatternResult with combined output
        """
        if not self._flow:
            raise RuntimeError("No flow defined. Call set_flow first.")
        
        pattern_kwargs = pattern_kwargs or {}
        all_responses = []
        total_cost = 0.0
        total_tokens: dict[str, int] = {}
        pattern_outputs: dict[str, str] = {}
        
        current_input = message
        
        for pattern_name in self._flow:
            pattern = self._patterns.get(pattern_name)
            if not pattern:
                continue
            
            # Merge kwargs
            merged_kwargs = {**kwargs, **pattern_kwargs.get(pattern_name, {})}
            
            # Run pattern
            result = await pattern.run(current_input, **merged_kwargs)
            all_responses.extend(result.agent_responses)
            total_cost += result.total_cost
            
            for key, value in result.total_tokens.items():
                total_tokens[key] = total_tokens.get(key, 0) + value
            
            # Apply transformer if exists
            output = result.content
            if pattern_name in self._transformers:
                output = self._transformers[pattern_name](output)
            
            pattern_outputs[pattern_name] = output
            current_input = output
        
        return PatternResult(
            content=current_input,
            agent_responses=all_responses,
            total_cost=total_cost,
            total_tokens=total_tokens,
            metadata={
                "patterns_executed": self._flow,
                "pattern_outputs": pattern_outputs,
            },
        )
    
    async def run_parallel(
        self,
        message: str,
        pattern_names: list[str] | None = None,
        aggregator: Callable[[list[str]], str] | None = None,
        **kwargs: Any,
    ) -> PatternResult:
        """Run multiple patterns in parallel.
        
        Args:
            message: Input message
            pattern_names: Patterns to run (None = all)
            aggregator: Function to combine outputs
            **kwargs: Arguments for patterns
            
        Returns:
            PatternResult with aggregated output
        """
        import asyncio
        
        patterns_to_run = pattern_names or list(self._patterns.keys())
        
        async def run_pattern(name: str) -> tuple[str, PatternResult]:
            pattern = self._patterns[name]
            result = await pattern.run(message, **kwargs)
            return name, result
        
        tasks = [run_pattern(name) for name in patterns_to_run]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        all_responses = []
        total_cost = 0.0
        total_tokens: dict[str, int] = {}
        pattern_outputs: dict[str, str] = {}
        
        for result in results:
            if isinstance(result, Exception):
                continue
            name, pattern_result = result
            all_responses.extend(pattern_result.agent_responses)
            total_cost += pattern_result.total_cost
            pattern_outputs[name] = pattern_result.content
            
            for key, value in pattern_result.total_tokens.items():
                total_tokens[key] = total_tokens.get(key, 0) + value
        
        # Aggregate outputs
        if aggregator:
            final_content = aggregator(list(pattern_outputs.values()))
        else:
            final_content = "\n\n".join([
                f"[{name}]:\n{output}"
                for name, output in pattern_outputs.items()
            ])
        
        return PatternResult(
            content=final_content,
            agent_responses=all_responses,
            total_cost=total_cost,
            total_tokens=total_tokens,
            metadata={
                "patterns_executed": patterns_to_run,
                "pattern_outputs": pattern_outputs,
                "execution_mode": "parallel",
            },
        )


class DebatePattern(BasePattern):
    """Debate pattern for adversarial discussion.
    
    Multiple agents debate a topic from different perspectives,
    with an optional judge to determine the winner or synthesize.
    
    Example:
        ```python
        pattern = DebatePattern(config)
        
        pattern.add_debater("optimist", "You argue the positive aspects.")
        pattern.add_debater("pessimist", "You argue the negative aspects.")
        pattern.set_judge("moderator", "You synthesize both perspectives.")
        
        result = await pattern.run("Is AI beneficial for society?", rounds=3)
        ```
    """
    
    def __init__(
        self,
        config: SystemConfig,
        logger: AgentLogger | None = None,
        cost_tracker: CostTracker | None = None,
    ) -> None:
        """Initialize debate pattern."""
        super().__init__(config, logger, cost_tracker)
        self._debaters: list[str] = []
        self._judge: BaseAgent | None = None
        self._judge_name: str | None = None
    
    def create_agent(
        self,
        name: str,
        system_prompt: str,
        tools: list[Tool | Callable[..., Any]] | None = None,
        role: str = "debater",
        **kwargs: Any,
    ) -> BaseAgent:
        """Create a debate participant."""
        from multi_agent_base.core.agent import BaseAgent
        from multi_agent_base.core.config import AgentConfig
        
        agent_config = AgentConfig(
            name=name,
            system_prompt=system_prompt,
            **kwargs,
        )
        
        agent = BaseAgent(
            name=name,
            config=agent_config,
            provider_config=self.config.provider,
            logger=self.logger,
            cost_tracker=self.cost_tracker,
            model_client=self._create_model_client(),
        )
        
        if tools:
            for tool in tools:
                agent.register_tool(tool)
        
        self._agents[name] = agent
        
        if role == "debater":
            self._debaters.append(name)
        elif role == "judge":
            self._judge = agent
            self._judge_name = name
        
        return agent
    
    def add_debater(
        self,
        name: str,
        system_prompt: str,
        **kwargs: Any,
    ) -> BaseAgent:
        """Add a debater agent."""
        return self.create_agent(name, system_prompt, role="debater", **kwargs)
    
    def set_judge(
        self,
        name: str,
        system_prompt: str,
        **kwargs: Any,
    ) -> BaseAgent:
        """Set the judge agent."""
        return self.create_agent(name, system_prompt, role="judge", **kwargs)
    
    async def run(
        self,
        message: str,
        rounds: int = 2,
        **kwargs: Any,
    ) -> PatternResult:
        """Run the debate.
        
        Args:
            message: Debate topic
            rounds: Number of debate rounds
            **kwargs: Additional arguments
            
        Returns:
            PatternResult with debate outcome
        """
        if len(self._debaters) < 2:
            raise RuntimeError("Need at least 2 debaters.")
        
        all_responses = []
        total_cost = 0.0
        total_tokens: dict[str, int] = {}
        debate_log: list[dict[str, str]] = []
        
        # Opening statements
        opening_prompt = f"Topic for debate: {message}\n\nProvide your opening argument."
        
        for debater_name in self._debaters:
            agent = self._agents[debater_name]
            response = await agent.run(opening_prompt, **kwargs)
            all_responses.append(response)
            total_cost += response.cost or 0.0
            
            for key, value in response.usage.items():
                total_tokens[key] = total_tokens.get(key, 0) + value
            
            debate_log.append({
                "round": 0,
                "type": "opening",
                "speaker": debater_name,
                "content": response.content,
            })
        
        # Debate rounds
        for round_num in range(1, rounds + 1):
            # Compile previous arguments
            prev_args = "\n\n".join([
                f"{entry['speaker']}: {entry['content']}"
                for entry in debate_log
            ])
            
            for debater_name in self._debaters:
                agent = self._agents[debater_name]
                
                round_prompt = f"""Topic: {message}

Previous arguments:
{prev_args}

Round {round_num}: Respond to the other arguments and strengthen your position."""
                
                response = await agent.run(round_prompt, **kwargs)
                all_responses.append(response)
                total_cost += response.cost or 0.0
                
                for key, value in response.usage.items():
                    total_tokens[key] = total_tokens.get(key, 0) + value
                
                debate_log.append({
                    "round": round_num,
                    "type": "rebuttal",
                    "speaker": debater_name,
                    "content": response.content,
                })
        
        # Judge's verdict
        if self._judge:
            all_args = "\n\n".join([
                f"[{entry['speaker']} - Round {entry['round']}]:\n{entry['content']}"
                for entry in debate_log
            ])
            
            judge_prompt = f"""Topic: {message}

Complete debate transcript:
{all_args}

Please provide your verdict and synthesis of the debate."""
            
            judge_response = await self._judge.run(judge_prompt, **kwargs)
            all_responses.append(judge_response)
            total_cost += judge_response.cost or 0.0
            
            for key, value in judge_response.usage.items():
                total_tokens[key] = total_tokens.get(key, 0) + value
            
            final_content = judge_response.content
        else:
            final_content = "\n\n".join([
                f"[{entry['speaker']}]: {entry['content']}"
                for entry in debate_log
            ])
        
        return PatternResult(
            content=final_content,
            agent_responses=all_responses,
            total_cost=total_cost,
            total_tokens=total_tokens,
            metadata={
                "rounds": rounds,
                "debaters": self._debaters,
                "judge": self._judge_name,
                "debate_log": debate_log,
            },
        )


@dataclass
class HierarchicalLevel:
    """Represents a level in a hierarchical agent structure.
    
    Attributes:
        name: Level name
        agents: Agents at this level
        supervisor: Supervisor for this level (optional)
        parent_level: Parent level name (optional)
    """
    
    name: str
    agents: list[str] = field(default_factory=list)
    supervisor: str | None = None
    parent_level: str | None = None


class HierarchicalPattern(BasePattern):
    """Hierarchical pattern with multi-level supervisor chains.
    
    Creates a tree-like structure of agents where supervisors at each
    level can delegate to agents below them. Messages flow from top
    to bottom, and results bubble up from bottom to top.
    
    Example:
        ```python
        pattern = HierarchicalPattern(config)
        
        # Create levels
        pattern.create_level("executive", supervisor="ceo")
        pattern.create_level("management", supervisor="manager", parent="executive")
        pattern.create_level("workers", agents=["worker1", "worker2"], parent="management")
        
        # Add agents to levels
        pattern.add_agent_to_level("executive", "ceo", "You are the CEO.")
        pattern.add_agent_to_level("management", "manager", "You manage workers.")
        pattern.add_agent_to_level("workers", "worker1", "You are worker 1.")
        pattern.add_agent_to_level("workers", "worker2", "You are worker 2.")
        
        result = await pattern.run("Complete this project")
        ```
    """
    
    def __init__(
        self,
        config: SystemConfig,
        logger: AgentLogger | None = None,
        cost_tracker: CostTracker | None = None,
    ) -> None:
        """Initialize hierarchical pattern."""
        super().__init__(config, logger, cost_tracker)
        self._levels: dict[str, HierarchicalLevel] = {}
        self._level_order: list[str] = []  # Top to bottom
        self._root_level: str | None = None
    
    def create_level(
        self,
        name: str,
        supervisor: str | None = None,
        agents: list[str] | None = None,
        parent: str | None = None,
    ) -> HierarchicalLevel:
        """Create a new hierarchical level.
        
        Args:
            name: Level name
            supervisor: Name of the supervisor agent for this level
            agents: List of agent names at this level
            parent: Parent level name (None for root level)
            
        Returns:
            Created HierarchicalLevel
        """
        if parent and parent not in self._levels:
            raise ValueError(f"Parent level '{parent}' does not exist")
        
        level = HierarchicalLevel(
            name=name,
            agents=agents or [],
            supervisor=supervisor,
            parent_level=parent,
        )
        
        self._levels[name] = level
        self._level_order.append(name)
        
        if parent is None:
            self._root_level = name
        
        return level
    
    def add_agent_to_level(
        self,
        level_name: str,
        agent_name: str,
        system_prompt: str,
        tools: list[Tool | Callable[..., Any]] | None = None,
        is_supervisor: bool = False,
        **kwargs: Any,
    ) -> BaseAgent:
        """Add an agent to a specific level.
        
        Args:
            level_name: Name of the level
            agent_name: Name of the agent
            system_prompt: System prompt for the agent
            tools: Optional tools
            is_supervisor: Whether this agent is the level's supervisor
            **kwargs: Additional configuration
            
        Returns:
            Created agent
        """
        if level_name not in self._levels:
            raise ValueError(f"Level '{level_name}' does not exist")
        
        level = self._levels[level_name]
        agent = self.create_agent(agent_name, system_prompt, tools, **kwargs)
        
        if is_supervisor:
            level.supervisor = agent_name
        else:
            if agent_name not in level.agents:
                level.agents.append(agent_name)
        
        return agent
    
    def create_agent(
        self,
        name: str,
        system_prompt: str,
        tools: list[Tool | Callable[..., Any]] | None = None,
        **kwargs: Any,
    ) -> BaseAgent:
        """Create an agent.
        
        Args:
            name: Agent name
            system_prompt: System prompt
            tools: Optional tools
            **kwargs: Additional configuration
            
        Returns:
            Created agent
        """
        from multi_agent_base.core.agent import BaseAgent
        from multi_agent_base.core.config import AgentConfig
        
        agent_config = AgentConfig(
            name=name,
            system_prompt=system_prompt,
            **kwargs,
        )
        
        agent = BaseAgent(
            name=name,
            config=agent_config,
            provider_config=self.config.provider,
            logger=self.logger,
            cost_tracker=self.cost_tracker,
            model_client=self._create_model_client(),
        )
        
        if tools:
            for tool in tools:
                agent.register_tool(tool)
        
        self._agents[name] = agent
        return agent
    
    def get_level(self, name: str) -> HierarchicalLevel | None:
        """Get a level by name."""
        return self._levels.get(name)
    
    def get_child_levels(self, level_name: str) -> list[str]:
        """Get child levels of a given level."""
        return [
            name for name, level in self._levels.items()
            if level.parent_level == level_name
        ]
    
    def get_level_agents(self, level_name: str) -> list[BaseAgent]:
        """Get all agents at a level including supervisor."""
        level = self._levels.get(level_name)
        if not level:
            return []
        
        agents = []
        if level.supervisor and level.supervisor in self._agents:
            agents.append(self._agents[level.supervisor])
        for agent_name in level.agents:
            if agent_name in self._agents:
                agents.append(self._agents[agent_name])
        return agents
    
    async def _delegate_to_level(
        self,
        level_name: str,
        message: str,
        context: dict[str, Any],
        **kwargs: Any,
    ) -> tuple[str, list[Any], float, dict[str, int]]:
        """Delegate a task to a level and its children.
        
        Returns:
            Tuple of (response, responses, cost, tokens)
        """
        level = self._levels[level_name]
        all_responses = []
        total_cost = 0.0
        total_tokens: dict[str, int] = {}
        
        # Get supervisor or first agent at this level
        executor = None
        if level.supervisor and level.supervisor in self._agents:
            executor = self._agents[level.supervisor]
        elif level.agents:
            executor = self._agents.get(level.agents[0])
        
        if not executor:
            return f"No agents at level {level_name}", [], 0.0, {}
        
        # Check for child levels
        child_levels = self.get_child_levels(level_name)
        
        if child_levels:
            # Supervisor delegates to child levels
            delegation_prompt = f"""You are overseeing the following sub-levels: {', '.join(child_levels)}

Current context: {context}

Task: {message}

Analyze the task and provide instructions for your subordinates.
Format: DELEGATE: [instructions for subordinates]
Or if you can handle it directly: DIRECT: [your response]"""
            
            response = await executor.run(delegation_prompt, **kwargs)
            all_responses.append(response)
            total_cost += response.cost or 0.0
            for k, v in response.usage.items():
                total_tokens[k] = total_tokens.get(k, 0) + v
            
            if "DELEGATE:" in response.content:
                # Get delegated instructions
                instructions = response.content.split("DELEGATE:", 1)[1].strip()
                
                # Delegate to child levels
                child_results = []
                for child_level in child_levels:
                    result, child_responses, cost, tokens = await self._delegate_to_level(
                        child_level,
                        instructions,
                        {**context, "parent_level": level_name},
                        **kwargs,
                    )
                    child_results.append(f"[{child_level}]: {result}")
                    all_responses.extend(child_responses)
                    total_cost += cost
                    for k, v in tokens.items():
                        total_tokens[k] = total_tokens.get(k, 0) + v
                
                # Synthesize child results
                synthesis_prompt = f"""Original task: {message}

Results from subordinate levels:
{chr(10).join(child_results)}

Synthesize these results into a coherent response."""
                
                synthesis_response = await executor.run(synthesis_prompt, **kwargs)
                all_responses.append(synthesis_response)
                total_cost += synthesis_response.cost or 0.0
                for k, v in synthesis_response.usage.items():
                    total_tokens[k] = total_tokens.get(k, 0) + v
                
                return synthesis_response.content, all_responses, total_cost, total_tokens
            else:
                # Direct response
                content = response.content
                if "DIRECT:" in content:
                    content = content.split("DIRECT:", 1)[1].strip()
                return content, all_responses, total_cost, total_tokens
        else:
            # Leaf level - workers execute
            if len(level.agents) > 1:
                # Multiple workers - parallel execution
                worker_results = []
                for agent_name in level.agents:
                    agent = self._agents.get(agent_name)
                    if agent:
                        worker_response = await agent.run(message, **kwargs)
                        all_responses.append(worker_response)
                        total_cost += worker_response.cost or 0.0
                        for k, v in worker_response.usage.items():
                            total_tokens[k] = total_tokens.get(k, 0) + v
                        worker_results.append(f"[{agent_name}]: {worker_response.content}")
                
                # Combine worker results if supervisor exists
                if executor and level.supervisor:
                    combine_prompt = f"""Task: {message}

Worker results:
{chr(10).join(worker_results)}

Combine these results into a single coherent response."""
                    
                    combine_response = await executor.run(combine_prompt, **kwargs)
                    all_responses.append(combine_response)
                    total_cost += combine_response.cost or 0.0
                    for k, v in combine_response.usage.items():
                        total_tokens[k] = total_tokens.get(k, 0) + v
                    return combine_response.content, all_responses, total_cost, total_tokens
                
                return "\n\n".join(worker_results), all_responses, total_cost, total_tokens
            else:
                # Single agent at leaf
                response = await executor.run(message, **kwargs)
                all_responses.append(response)
                total_cost += response.cost or 0.0
                for k, v in response.usage.items():
                    total_tokens[k] = total_tokens.get(k, 0) + v
                return response.content, all_responses, total_cost, total_tokens
    
    async def run(self, message: str, **kwargs: Any) -> PatternResult:
        """Run the hierarchical pattern.
        
        Starts from the root level and delegates downward through the hierarchy.
        
        Args:
            message: User message
            **kwargs: Additional arguments
            
        Returns:
            PatternResult with response
        """
        if not self._root_level:
            raise RuntimeError("No root level defined. Create a level without a parent.")
        
        if not self._levels:
            raise RuntimeError("No levels defined. Use create_level first.")
        
        content, all_responses, total_cost, total_tokens = await self._delegate_to_level(
            self._root_level,
            message,
            {"original_task": message},
            **kwargs,
        )
        
        return PatternResult(
            content=content,
            agent_responses=all_responses,
            total_cost=total_cost,
            total_tokens=total_tokens,
            metadata={
                "levels": list(self._levels.keys()),
                "root_level": self._root_level,
            },
        )


@dataclass
class VoteResult:
    """Result of voting by ensemble agents.
    
    Attributes:
        winner: The winning response
        votes: Vote counts per option
        confidence: Confidence score (0-1)
        all_responses: All agent responses
    """
    
    winner: str
    votes: dict[str, int] = field(default_factory=dict)
    confidence: float = 0.0
    all_responses: list[str] = field(default_factory=list)


class VotingStrategy(Enum):
    """Voting strategies for ensemble pattern."""
    
    MAJORITY = "majority"
    UNANIMOUS = "unanimous"
    WEIGHTED = "weighted"
    RANKED_CHOICE = "ranked_choice"


class EnsemblePattern(BasePattern):
    """Ensemble pattern where multiple agents vote on responses.
    
    Multiple agents process the same input independently, then their
    responses are aggregated using a voting strategy to produce a
    consensus result.
    
    Example:
        ```python
        pattern = EnsemblePattern(config, voting_strategy=VotingStrategy.MAJORITY)
        
        pattern.add_voter("expert1", "You are a domain expert.", weight=2.0)
        pattern.add_voter("expert2", "You are another expert.", weight=1.0)
        pattern.add_voter("expert3", "You are a third expert.", weight=1.0)
        
        result = await pattern.run("What is the best approach?")
        print(f"Consensus: {result.content}")
        print(f"Confidence: {result.metadata['confidence']}")
        ```
    """
    
    def __init__(
        self,
        config: SystemConfig,
        voting_strategy: VotingStrategy = VotingStrategy.MAJORITY,
        logger: AgentLogger | None = None,
        cost_tracker: CostTracker | None = None,
    ) -> None:
        """Initialize ensemble pattern.
        
        Args:
            config: System configuration
            voting_strategy: Strategy for aggregating votes
            logger: Optional logger
            cost_tracker: Optional cost tracker
        """
        super().__init__(config, logger, cost_tracker)
        self.voting_strategy = voting_strategy
        self._voters: list[str] = []
        self._weights: dict[str, float] = {}
        self._aggregator: BaseAgent | None = None
    
    def add_voter(
        self,
        name: str,
        system_prompt: str,
        weight: float = 1.0,
        tools: list[Tool | Callable[..., Any]] | None = None,
        **kwargs: Any,
    ) -> BaseAgent:
        """Add a voting agent to the ensemble.
        
        Args:
            name: Agent name
            system_prompt: System prompt
            weight: Vote weight (for weighted voting)
            tools: Optional tools
            **kwargs: Additional configuration
            
        Returns:
            Created agent
        """
        agent = self.create_agent(name, system_prompt, tools, **kwargs)
        self._voters.append(name)
        self._weights[name] = weight
        return agent
    
    def set_aggregator(
        self,
        name: str,
        system_prompt: str | None = None,
        **kwargs: Any,
    ) -> BaseAgent:
        """Set a custom aggregator agent for synthesizing votes.
        
        Args:
            name: Agent name
            system_prompt: System prompt (defaults to aggregation prompt)
            **kwargs: Additional configuration
            
        Returns:
            Created aggregator agent
        """
        default_prompt = """You are a consensus builder. Given multiple expert opinions,
synthesize them into a single coherent response that represents the best elements
of each perspective. Highlight areas of agreement and resolve conflicts."""
        
        agent = self.create_agent(
            name,
            system_prompt or default_prompt,
            **kwargs,
        )
        self._aggregator = agent
        return agent
    
    def create_agent(
        self,
        name: str,
        system_prompt: str,
        tools: list[Tool | Callable[..., Any]] | None = None,
        **kwargs: Any,
    ) -> BaseAgent:
        """Create an agent."""
        from multi_agent_base.core.agent import BaseAgent
        from multi_agent_base.core.config import AgentConfig
        
        agent_config = AgentConfig(
            name=name,
            system_prompt=system_prompt,
            **kwargs,
        )
        
        agent = BaseAgent(
            name=name,
            config=agent_config,
            provider_config=self.config.provider,
            logger=self.logger,
            cost_tracker=self.cost_tracker,
            model_client=self._create_model_client(),
        )
        
        if tools:
            for tool in tools:
                agent.register_tool(tool)
        
        self._agents[name] = agent
        return agent
    
    def _calculate_similarity(self, text1: str, text2: str) -> float:
        """Calculate similarity between two texts using word overlap."""
        words1 = set(text1.lower().split())
        words2 = set(text2.lower().split())
        
        if not words1 or not words2:
            return 0.0
        
        intersection = words1 & words2
        union = words1 | words2
        
        return len(intersection) / len(union) if union else 0.0
    
    def _cluster_responses(
        self,
        responses: list[tuple[str, str]],  # (agent_name, response)
        threshold: float = 0.3,
    ) -> list[list[tuple[str, str]]]:
        """Cluster similar responses together."""
        if not responses:
            return []
        
        clusters: list[list[tuple[str, str]]] = []
        
        for response in responses:
            placed = False
            for cluster in clusters:
                # Compare with first item in cluster
                similarity = self._calculate_similarity(
                    response[1], cluster[0][1]
                )
                if similarity > threshold:
                    cluster.append(response)
                    placed = True
                    break
            
            if not placed:
                clusters.append([response])
        
        return clusters
    
    def _apply_voting(
        self,
        clusters: list[list[tuple[str, str]]],
    ) -> VoteResult:
        """Apply voting strategy to clustered responses."""
        if not clusters:
            return VoteResult(winner="", confidence=0.0)
        
        if self.voting_strategy == VotingStrategy.MAJORITY:
            # Count votes per cluster
            cluster_votes = []
            for i, cluster in enumerate(clusters):
                total_weight = sum(
                    self._weights.get(name, 1.0) for name, _ in cluster
                )
                cluster_votes.append((i, total_weight, cluster))
            
            # Sort by vote count
            cluster_votes.sort(key=lambda x: x[1], reverse=True)
            
            winner_cluster = cluster_votes[0][2]
            total_votes = sum(v[1] for v in cluster_votes)
            confidence = cluster_votes[0][1] / total_votes if total_votes else 0.0
            
            return VoteResult(
                winner=winner_cluster[0][1],  # First response in winning cluster
                votes={
                    f"cluster_{i}": int(v)
                    for i, v, _ in cluster_votes
                },
                confidence=confidence,
                all_responses=[r[1] for cluster in clusters for r in cluster],
            )
        
        elif self.voting_strategy == VotingStrategy.UNANIMOUS:
            # Check if all responses are in one cluster
            if len(clusters) == 1:
                return VoteResult(
                    winner=clusters[0][0][1],
                    votes={"unanimous": len(clusters[0])},
                    confidence=1.0,
                    all_responses=[r[1] for r in clusters[0]],
                )
            else:
                # No unanimous decision
                return VoteResult(
                    winner="",
                    votes={f"cluster_{i}": len(c) for i, c in enumerate(clusters)},
                    confidence=0.0,
                    all_responses=[r[1] for cluster in clusters for r in cluster],
                )
        
        elif self.voting_strategy == VotingStrategy.WEIGHTED:
            # Use weights explicitly
            cluster_weights = []
            for i, cluster in enumerate(clusters):
                total_weight = sum(
                    self._weights.get(name, 1.0) for name, _ in cluster
                )
                cluster_weights.append((i, total_weight, cluster))
            
            cluster_weights.sort(key=lambda x: x[1], reverse=True)
            
            winner_cluster = cluster_weights[0][2]
            total_weight = sum(w[1] for w in cluster_weights)
            confidence = cluster_weights[0][1] / total_weight if total_weight else 0.0
            
            return VoteResult(
                winner=winner_cluster[0][1],
                votes={
                    f"cluster_{i}": w
                    for i, w, _ in cluster_weights
                },
                confidence=confidence,
                all_responses=[r[1] for cluster in clusters for r in cluster],
            )
        
        elif self.voting_strategy == VotingStrategy.RANKED_CHOICE:
            # Simple ranked choice: use cluster size * average weight
            cluster_scores = []
            for i, cluster in enumerate(clusters):
                size = len(cluster)
                avg_weight = sum(
                    self._weights.get(name, 1.0) for name, _ in cluster
                ) / size
                score = size * avg_weight
                cluster_scores.append((i, score, cluster))
            
            cluster_scores.sort(key=lambda x: x[1], reverse=True)
            
            winner_cluster = cluster_scores[0][2]
            total_score = sum(s[1] for s in cluster_scores)
            confidence = cluster_scores[0][1] / total_score if total_score else 0.0
            
            return VoteResult(
                winner=winner_cluster[0][1],
                votes={
                    f"cluster_{i}": int(s)
                    for i, s, _ in cluster_scores
                },
                confidence=confidence,
                all_responses=[r[1] for cluster in clusters for r in cluster],
            )
        
        # Fallback
        return VoteResult(
            winner=clusters[0][0][1] if clusters else "",
            confidence=0.0,
            all_responses=[r[1] for cluster in clusters for r in cluster],
        )
    
    async def run(self, message: str, **kwargs: Any) -> PatternResult:
        """Run the ensemble pattern.
        
        All voters process the message independently, then votes are aggregated.
        
        Args:
            message: User message
            **kwargs: Additional arguments
            
        Returns:
            PatternResult with consensus response
        """
        if not self._voters:
            raise RuntimeError("No voters added. Use add_voter first.")
        
        all_responses = []
        total_cost = 0.0
        total_tokens: dict[str, int] = {}
        
        # Collect responses from all voters
        voter_responses: list[tuple[str, str]] = []
        for voter_name in self._voters:
            agent = self._agents[voter_name]
            response = await agent.run(message, **kwargs)
            all_responses.append(response)
            total_cost += response.cost or 0.0
            for k, v in response.usage.items():
                total_tokens[k] = total_tokens.get(k, 0) + v
            voter_responses.append((voter_name, response.content))
        
        # Cluster and vote
        clusters = self._cluster_responses(voter_responses)
        vote_result = self._apply_voting(clusters)
        
        # If we have an aggregator and multiple clusters, synthesize
        if self._aggregator and len(clusters) > 1:
            synthesis_prompt = f"""Original question: {message}

Expert opinions:
{chr(10).join(f'[{name}]: {resp}' for name, resp in voter_responses)}

Vote result: Cluster sizes = {vote_result.votes}
Confidence: {vote_result.confidence:.2%}

Please synthesize these opinions into a coherent consensus response."""
            
            aggregator_response = await self._aggregator.run(synthesis_prompt, **kwargs)
            all_responses.append(aggregator_response)
            total_cost += aggregator_response.cost or 0.0
            for k, v in aggregator_response.usage.items():
                total_tokens[k] = total_tokens.get(k, 0) + v
            
            final_content = aggregator_response.content
        else:
            final_content = vote_result.winner
        
        return PatternResult(
            content=final_content,
            agent_responses=all_responses,
            total_cost=total_cost,
            total_tokens=total_tokens,
            metadata={
                "voting_strategy": self.voting_strategy.value,
                "votes": vote_result.votes,
                "confidence": vote_result.confidence,
                "num_voters": len(self._voters),
                "num_clusters": len(clusters),
            },
        )


class SelfHealingPattern(BasePattern):
    """Self-healing pattern with automatic retry and modification.
    
    When an agent fails or produces an unsatisfactory result, this pattern
    automatically retries with modified prompts or strategies.
    
    Example:
        ```python
        def modify_on_failure(attempt: int, last_response: str, error: str | None) -> str:
            return f"Previous attempt failed: {error}. Please try a different approach."
        
        pattern = SelfHealingPattern(
            config,
            max_retries=3,
            modification_strategy=modify_on_failure,
        )
        
        pattern.create_agent("worker", "You complete tasks reliably.")
        
        # Optional: Add validator and healer
        pattern.set_validator(lambda resp: "error" not in resp.lower())
        pattern.set_healer("healer", "You fix broken responses.")
        
        result = await pattern.run("Complete this task")
        ```
    """
    
    def __init__(
        self,
        config: SystemConfig,
        max_retries: int = 3,
        modification_strategy: Callable[[int, str, str | None], str] | None = None,
        logger: AgentLogger | None = None,
        cost_tracker: CostTracker | None = None,
    ) -> None:
        """Initialize self-healing pattern.
        
        Args:
            config: System configuration
            max_retries: Maximum retry attempts
            modification_strategy: Function to modify prompt on retry
                Takes (attempt_number, last_response, error_message) -> modified_prompt
            logger: Optional logger
            cost_tracker: Optional cost tracker
        """
        super().__init__(config, logger, cost_tracker)
        self.max_retries = max_retries
        self.modification_strategy = modification_strategy or self._default_modification
        self._primary_agent: BaseAgent | None = None
        self._healer: BaseAgent | None = None
        self._validator: Callable[[str], bool] | None = None
        self._error_patterns: list[str] = [
            "error", "failed", "cannot", "unable", "sorry",
            "I don't know", "I can't", "I'm not sure",
        ]
    
    def _default_modification(
        self,
        attempt: int,
        last_response: str,
        error: str | None,
    ) -> str:
        """Default strategy for modifying prompts on retry."""
        modifications = [
            "Please try again with a different approach.",
            "Think step by step and provide a more detailed solution.",
            "Break down the problem into smaller parts and solve each one.",
            "Consider alternative methods or perspectives.",
        ]
        
        mod_index = min(attempt - 1, len(modifications) - 1)
        modification = modifications[mod_index]
        
        if error:
            return f"Previous attempt had an issue: {error}\n\n{modification}"
        return modification
    
    def create_agent(
        self,
        name: str,
        system_prompt: str,
        tools: list[Tool | Callable[..., Any]] | None = None,
        **kwargs: Any,
    ) -> BaseAgent:
        """Create the primary agent."""
        from multi_agent_base.core.agent import BaseAgent
        from multi_agent_base.core.config import AgentConfig
        
        agent_config = AgentConfig(
            name=name,
            system_prompt=system_prompt,
            **kwargs,
        )
        
        agent = BaseAgent(
            name=name,
            config=agent_config,
            provider_config=self.config.provider,
            logger=self.logger,
            cost_tracker=self.cost_tracker,
            model_client=self._create_model_client(),
        )
        
        if tools:
            for tool in tools:
                agent.register_tool(tool)
        
        self._agents[name] = agent
        self._primary_agent = agent
        return agent
    
    def set_validator(
        self,
        validator: Callable[[str], bool],
    ) -> None:
        """Set a custom validation function.
        
        Args:
            validator: Function that returns True if response is valid
        """
        self._validator = validator
    
    def set_healer(
        self,
        name: str,
        system_prompt: str | None = None,
        **kwargs: Any,
    ) -> BaseAgent:
        """Set a healer agent that attempts to fix invalid responses.
        
        Args:
            name: Healer agent name
            system_prompt: System prompt for healer
            **kwargs: Additional configuration
            
        Returns:
            Created healer agent
        """
        default_prompt = """You are a response healer. When given a problematic response,
analyze what went wrong and provide a corrected version. Maintain the original intent
while fixing any errors, inconsistencies, or issues."""
        
        from multi_agent_base.core.agent import BaseAgent
        from multi_agent_base.core.config import AgentConfig
        
        agent_config = AgentConfig(
            name=name,
            system_prompt=system_prompt or default_prompt,
            **kwargs,
        )
        
        agent = BaseAgent(
            name=name,
            config=agent_config,
            provider_config=self.config.provider,
            logger=self.logger,
            cost_tracker=self.cost_tracker,
            model_client=self._create_model_client(),
        )
        
        self._agents[name] = agent
        self._healer = agent
        return agent
    
    def set_error_patterns(self, patterns: list[str]) -> None:
        """Set custom error patterns for detection.
        
        Args:
            patterns: List of substrings indicating errors
        """
        self._error_patterns = patterns
    
    def _detect_error(self, response: str) -> str | None:
        """Detect if response contains error indicators."""
        response_lower = response.lower()
        
        for pattern in self._error_patterns:
            if pattern.lower() in response_lower:
                return f"Response contains error indicator: '{pattern}'"
        
        return None
    
    def _validate_response(self, response: str) -> tuple[bool, str | None]:
        """Validate a response.
        
        Returns:
            Tuple of (is_valid, error_message)
        """
        # Custom validator takes precedence
        if self._validator:
            if not self._validator(response):
                return False, "Custom validation failed"
            return True, None
        
        # Check for empty response
        if not response or not response.strip():
            return False, "Empty response"
        
        # Check for error patterns
        error = self._detect_error(response)
        if error:
            return False, error
        
        return True, None
    
    async def _attempt_healing(
        self,
        original_message: str,
        failed_response: str,
        error: str | None,
        **kwargs: Any,
    ) -> tuple[str, Any, float, dict[str, int]]:
        """Attempt to heal a failed response using the healer agent."""
        if not self._healer:
            return failed_response, None, 0.0, {}
        
        heal_prompt = f"""Original request: {original_message}

Failed response: {failed_response}

Error detected: {error or 'Response did not meet quality standards'}

Please analyze what went wrong and provide a corrected, improved response."""
        
        healed_response = await self._healer.run(heal_prompt, **kwargs)
        
        return (
            healed_response.content,
            healed_response,
            healed_response.cost or 0.0,
            healed_response.usage,
        )
    
    async def run(self, message: str, **kwargs: Any) -> PatternResult:
        """Run the self-healing pattern.
        
        Attempts to get a valid response, retrying with modifications if needed.
        
        Args:
            message: User message
            **kwargs: Additional arguments
            
        Returns:
            PatternResult with response
        """
        if not self._primary_agent:
            raise RuntimeError("No agent created. Call create_agent first.")
        
        all_responses = []
        total_cost = 0.0
        total_tokens: dict[str, int] = {}
        attempt_history: list[dict[str, Any]] = []
        
        current_message = message
        last_response = ""
        last_error: str | None = None
        
        for attempt in range(1, self.max_retries + 2):  # +1 for initial, +1 for final
            if attempt > 1:
                # Apply modification strategy
                modification = self.modification_strategy(
                    attempt - 1, last_response, last_error
                )
                current_message = f"{message}\n\n{modification}"
            
            # Run the agent
            try:
                response = await self._primary_agent.run(current_message, **kwargs)
                all_responses.append(response)
                total_cost += response.cost or 0.0
                for k, v in response.usage.items():
                    total_tokens[k] = total_tokens.get(k, 0) + v
                
                last_response = response.content
                
                # Validate response
                is_valid, error = self._validate_response(response.content)
                
                attempt_history.append({
                    "attempt": attempt,
                    "valid": is_valid,
                    "error": error,
                    "response_length": len(response.content),
                })
                
                if is_valid:
                    return PatternResult(
                        content=response.content,
                        agent_responses=all_responses,
                        total_cost=total_cost,
                        total_tokens=total_tokens,
                        metadata={
                            "attempts": attempt,
                            "attempt_history": attempt_history,
                            "healed": False,
                        },
                    )
                
                last_error = error
                
            except Exception as e:
                last_error = str(e)
                attempt_history.append({
                    "attempt": attempt,
                    "valid": False,
                    "error": last_error,
                    "exception": True,
                })
        
        # All retries exhausted - try healing
        if self._healer and last_response:
            healed_content, healed_response, heal_cost, heal_tokens = await self._attempt_healing(
                message, last_response, last_error, **kwargs
            )
            
            if healed_response:
                all_responses.append(healed_response)
                total_cost += heal_cost
                for k, v in heal_tokens.items():
                    total_tokens[k] = total_tokens.get(k, 0) + v
            
            # Validate healed response
            is_valid, _ = self._validate_response(healed_content)
            
            if is_valid:
                return PatternResult(
                    content=healed_content,
                    agent_responses=all_responses,
                    total_cost=total_cost,
                    total_tokens=total_tokens,
                    metadata={
                        "attempts": self.max_retries + 1,
                        "attempt_history": attempt_history,
                        "healed": True,
                    },
                )
        
        # Return best effort response
        return PatternResult(
            content=last_response or "Failed to generate a valid response.",
            agent_responses=all_responses,
            total_cost=total_cost,
            total_tokens=total_tokens,
            metadata={
                "attempts": self.max_retries + 1,
                "attempt_history": attempt_history,
                "healed": False,
                "exhausted_retries": True,
            },
        )


def create_pattern(config: SystemConfig, **kwargs: Any) -> BasePattern:
    """Factory function to create a pattern based on configuration.
    
    Args:
        config: System configuration with pattern type
        **kwargs: Additional arguments for pattern creation
        
    Returns:
        Appropriate pattern instance
        
    Raises:
        ValueError: If pattern type is not recognized
    """
    from multi_agent_base.core.config import PatternType
    
    pattern_map = {
        PatternType.SINGLE_AGENT: SingleAgentPattern,
        PatternType.SUPERVISOR: SupervisorPattern,
        PatternType.SWARM: SwarmPattern,
        PatternType.PIPELINE: PipelinePattern,
        PatternType.PARALLEL: ParallelPattern,
        PatternType.ROUTER: RouterPattern,
        PatternType.REFLECTION: ReflectionPattern,
        PatternType.BLACKBOARD: BlackboardPattern,
        PatternType.COMPOSITE: CompositePattern,
        PatternType.DEBATE: DebatePattern,
        PatternType.HIERARCHICAL: HierarchicalPattern,
        PatternType.ENSEMBLE: EnsemblePattern,
        PatternType.SELF_HEALING: SelfHealingPattern,
    }
    
    pattern_type = config.pattern
    if pattern_type not in pattern_map:
        raise ValueError(f"Unknown pattern type: {pattern_type}")
    
    return pattern_map[pattern_type](config, **kwargs)
