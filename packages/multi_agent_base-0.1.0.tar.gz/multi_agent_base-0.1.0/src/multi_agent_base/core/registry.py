"""
Tool Registry for Multi-Agent Framework.

Provides central management for tools with:
- Category and tag-based organization
- Namespace support for avoiding conflicts
- Global and local registries
- Tool discovery and listing
"""

from typing import Any, Callable, Iterator
from threading import Lock
import fnmatch

from pydantic import BaseModel, Field

from multi_agent_base.core.tools import BaseTool, FunctionTool


class ToolNamespace(BaseModel):
    """Namespace for organizing tools."""
    
    name: str
    description: str = ""
    tools: dict[str, BaseTool] = Field(default_factory=dict)
    
    model_config = {"arbitrary_types_allowed": True}
    
    def add(self, tool: BaseTool) -> None:
        """Add a tool to this namespace."""
        self.tools[tool.name] = tool
    
    def get(self, name: str) -> BaseTool | None:
        """Get a tool by name."""
        return self.tools.get(name)
    
    def remove(self, name: str) -> bool:
        """Remove a tool by name."""
        if name in self.tools:
            del self.tools[name]
            return True
        return False
    
    def list_tools(self) -> list[str]:
        """List all tool names in namespace."""
        return list(self.tools.keys())
    
    def __len__(self) -> int:
        return len(self.tools)
    
    def __iter__(self) -> Iterator[BaseTool]:
        return iter(self.tools.values())


class ToolRegistry:
    """
    Central registry for managing tools across the framework.
    
    Features:
    - Organize tools by namespace (e.g., "math.", "web.", "file.")
    - Filter by category and tags
    - Global singleton or instance-based usage
    - Batch registration and discovery
    
    Usage:
    ```python
    # Get global registry
    registry = ToolRegistry.get_global()
    
    # Register tools
    registry.register(calculator_tool)
    registry.register(weather_tool, namespace="external")
    
    # Get tools
    tool = registry.get("calculator")
    tool = registry.get("external.weather")
    
    # Filter tools
    math_tools = registry.get_by_category("math")
    api_tools = registry.get_by_tags(["api", "external"])
    ```
    """
    
    _global_instance: "ToolRegistry | None" = None
    _lock: Lock = Lock()
    
    def __init__(self):
        self._namespaces: dict[str, ToolNamespace] = {
            "default": ToolNamespace(name="default", description="Default namespace")
        }
        self._tools_by_id: dict[str, BaseTool] = {}
    
    @classmethod
    def get_global(cls) -> "ToolRegistry":
        """Get the global registry singleton."""
        if cls._global_instance is None:
            with cls._lock:
                if cls._global_instance is None:
                    cls._global_instance = cls()
        return cls._global_instance
    
    @classmethod
    def reset_global(cls) -> None:
        """Reset the global registry (mainly for testing)."""
        with cls._lock:
            cls._global_instance = None
    
    def register(
        self,
        tool: BaseTool | Callable[..., Any],
        namespace: str = "default",
        **kwargs: Any,
    ) -> BaseTool:
        """
        Register a tool in the registry.
        
        Args:
            tool: BaseTool instance or callable function
            namespace: Namespace to register under
            **kwargs: Additional args passed to FunctionTool.from_function if tool is callable
        
        Returns:
            The registered BaseTool
        """
        # Convert function to tool if needed
        if callable(tool) and not isinstance(tool, BaseTool):
            tool = FunctionTool.from_function(tool, **kwargs)
        
        # Ensure namespace exists
        if namespace not in self._namespaces:
            self._namespaces[namespace] = ToolNamespace(name=namespace)
        
        # Register tool
        self._namespaces[namespace].add(tool)
        self._tools_by_id[tool.id] = tool
        
        return tool
    
    def register_many(
        self,
        tools: list[BaseTool | Callable[..., Any]],
        namespace: str = "default",
    ) -> list[BaseTool]:
        """Register multiple tools at once."""
        return [self.register(tool, namespace) for tool in tools]
    
    def unregister(self, name: str, namespace: str = "default") -> bool:
        """
        Unregister a tool by name.
        
        Args:
            name: Tool name
            namespace: Namespace to look in
        
        Returns:
            True if tool was found and removed
        """
        if namespace in self._namespaces:
            ns = self._namespaces[namespace]
            tool = ns.get(name)
            if tool:
                self._tools_by_id.pop(tool.id, None)
                return ns.remove(name)
        return False
    
    def get(self, name: str, namespace: str | None = None) -> BaseTool | None:
        """
        Get a tool by name.
        
        Name can include namespace prefix (e.g., "math.calculator").
        If no namespace prefix and namespace arg not provided, searches default.
        
        Args:
            name: Tool name, optionally with namespace prefix
            namespace: Explicit namespace to search
        
        Returns:
            BaseTool if found, None otherwise
        """
        # Check if name includes namespace
        if "." in name and namespace is None:
            parts = name.split(".", 1)
            namespace = parts[0]
            name = parts[1]
        
        namespace = namespace or "default"
        
        if namespace in self._namespaces:
            return self._namespaces[namespace].get(name)
        
        return None
    
    def get_by_id(self, tool_id: str) -> BaseTool | None:
        """Get a tool by its unique ID."""
        return self._tools_by_id.get(tool_id)
    
    def get_by_category(self, category: str) -> list[BaseTool]:
        """Get all tools in a category."""
        tools = []
        for ns in self._namespaces.values():
            for tool in ns:
                if tool.category == category:
                    tools.append(tool)
        return tools
    
    def get_by_tags(self, tags: list[str], match_all: bool = False) -> list[BaseTool]:
        """
        Get tools that have specified tags.
        
        Args:
            tags: Tags to match
            match_all: If True, tool must have all tags. If False, any tag matches.
        
        Returns:
            List of matching tools
        """
        tools = []
        tag_set = set(tags)
        
        for ns in self._namespaces.values():
            for tool in ns:
                tool_tags = set(tool.tags)
                if match_all:
                    if tag_set.issubset(tool_tags):
                        tools.append(tool)
                else:
                    if tag_set.intersection(tool_tags):
                        tools.append(tool)
        
        return tools
    
    def get_by_namespace(self, namespace: str) -> list[BaseTool]:
        """Get all tools in a namespace."""
        if namespace in self._namespaces:
            return list(self._namespaces[namespace])
        return []
    
    def search(self, pattern: str) -> list[BaseTool]:
        """
        Search tools by name pattern (supports wildcards).
        
        Args:
            pattern: Glob pattern (e.g., "calc*", "*weather*")
        
        Returns:
            List of matching tools
        """
        tools = []
        for ns in self._namespaces.values():
            for tool in ns:
                if fnmatch.fnmatch(tool.name, pattern):
                    tools.append(tool)
        return tools
    
    def list_all(self) -> list[BaseTool]:
        """List all registered tools."""
        tools = []
        for ns in self._namespaces.values():
            tools.extend(ns)
        return tools
    
    def list_namespaces(self) -> list[str]:
        """List all namespace names."""
        return list(self._namespaces.keys())
    
    def list_names(self, namespace: str | None = None, include_namespace: bool = False) -> list[str]:
        """
        List all tool names.
        
        Args:
            namespace: Limit to specific namespace
            include_namespace: Prefix names with namespace
        
        Returns:
            List of tool names
        """
        names = []
        
        namespaces = [namespace] if namespace else self._namespaces.keys()
        
        for ns_name in namespaces:
            if ns_name not in self._namespaces:
                continue
            ns = self._namespaces[ns_name]
            for tool_name in ns.list_tools():
                if include_namespace and ns_name != "default":
                    names.append(f"{ns_name}.{tool_name}")
                else:
                    names.append(tool_name)
        
        return names
    
    def get_openai_schemas(
        self,
        tools: list[str] | None = None,
        namespace: str | None = None,
    ) -> list[dict[str, Any]]:
        """
        Get OpenAI-formatted schemas for tools.
        
        Args:
            tools: Specific tool names to include (None = all)
            namespace: Limit to namespace
        
        Returns:
            List of OpenAI function schemas
        """
        if tools:
            tool_objs = [self.get(name, namespace) for name in tools]
            tool_objs = [t for t in tool_objs if t is not None]
        elif namespace:
            tool_objs = self.get_by_namespace(namespace)
        else:
            tool_objs = self.list_all()
        
        return [tool.to_openai_schema() for tool in tool_objs]
    
    def get_anthropic_schemas(
        self,
        tools: list[str] | None = None,
        namespace: str | None = None,
    ) -> list[dict[str, Any]]:
        """Get Anthropic-formatted schemas for tools."""
        if tools:
            tool_objs = [self.get(name, namespace) for name in tools]
            tool_objs = [t for t in tool_objs if t is not None]
        elif namespace:
            tool_objs = self.get_by_namespace(namespace)
        else:
            tool_objs = self.list_all()
        
        return [tool.to_anthropic_schema() for tool in tool_objs]
    
    def create_namespace(self, name: str, description: str = "") -> ToolNamespace:
        """Create a new namespace."""
        if name not in self._namespaces:
            self._namespaces[name] = ToolNamespace(name=name, description=description)
        return self._namespaces[name]
    
    def clear(self, namespace: str | None = None) -> None:
        """
        Clear tools from registry.
        
        Args:
            namespace: Clear only this namespace (None = clear all)
        """
        if namespace:
            if namespace in self._namespaces:
                for tool in self._namespaces[namespace]:
                    self._tools_by_id.pop(tool.id, None)
                self._namespaces[namespace] = ToolNamespace(name=namespace)
        else:
            self._namespaces = {
                "default": ToolNamespace(name="default", description="Default namespace")
            }
            self._tools_by_id.clear()
    
    def __len__(self) -> int:
        """Get total number of tools."""
        return sum(len(ns) for ns in self._namespaces.values())
    
    def __contains__(self, name: str) -> bool:
        """Check if tool exists."""
        return self.get(name) is not None


# Convenience function for global registry access
def get_registry() -> ToolRegistry:
    """Get the global tool registry."""
    return ToolRegistry.get_global()
