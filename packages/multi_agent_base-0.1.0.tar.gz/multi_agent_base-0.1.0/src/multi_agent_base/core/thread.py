"""
AgentThread - Persistent Conversation Sessions.

This module provides session persistence for agent conversations,
enabling:

- Save and restore conversation state
- Resume conversations across sessions
- Multi-backend persistence (file, Redis)
- Thread metadata management
- Seamless BaseAgent integration

Usage:
    ```python
    from multi_agent_base.core import AgentThread, BaseAgent
    
    # Create new thread
    thread = AgentThread(session_id="user_123")
    
    # Use with agent
    agent = BaseAgent.from_thread(thread)
    response = await agent.run("Hello!")
    
    # Save thread
    await thread.save("./sessions/user_123.json")
    
    # Later: resume conversation
    loaded_thread = await AgentThread.load("user_123")
    agent = BaseAgent.from_thread(loaded_thread)
    response = await agent.run("Let's continue...")
    ```
"""

from __future__ import annotations

import asyncio
import json
import os
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import (
    TYPE_CHECKING,
    Any,
    Dict,
    List,
    Optional,
    Sequence,
    Union,
)

from multi_agent_base.core.agent import Message
from multi_agent_base.core.chat_history import ChatMessage, ChatHistoryProvider

if TYPE_CHECKING:
    try:
        from redis.asyncio import Redis
    except ImportError:
        Redis = Any


# =============================================================================
# Thread State
# =============================================================================


@dataclass
class ThreadCheckpoint:
    """Represents a checkpoint in the conversation.
    
    Checkpoints allow saving intermediate states within a thread,
    useful for branching conversations or rollback.
    
    Attributes:
        checkpoint_id: Unique checkpoint identifier
        name: Human-readable checkpoint name
        message_index: Index in messages where checkpoint was taken
        created_at: When checkpoint was created
        metadata: Additional checkpoint metadata
    """
    
    checkpoint_id: str
    name: str
    message_index: int
    created_at: datetime = field(default_factory=datetime.utcnow)
    metadata: dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> dict[str, Any]:
        """Convert checkpoint to dictionary."""
        return {
            "checkpoint_id": self.checkpoint_id,
            "name": self.name,
            "message_index": self.message_index,
            "created_at": self.created_at.isoformat(),
            "metadata": self.metadata,
        }
    
    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ThreadCheckpoint":
        """Create checkpoint from dictionary."""
        created_at = data.get("created_at")
        if isinstance(created_at, str):
            created_at = datetime.fromisoformat(created_at)
        
        return cls(
            checkpoint_id=data["checkpoint_id"],
            name=data["name"],
            message_index=data["message_index"],
            created_at=created_at or datetime.now(timezone.utc),
            metadata=data.get("metadata", {}),
        )


@dataclass
class ThreadState:
    """Internal state of an AgentThread.
    
    Attributes:
        messages: Conversation messages
        checkpoints: Saved checkpoints
        variables: Thread-scoped variables
    """
    
    messages: list[Message] = field(default_factory=list)
    checkpoints: list[ThreadCheckpoint] = field(default_factory=list)
    variables: dict[str, Any] = field(default_factory=dict)


# =============================================================================
# AgentThread
# =============================================================================


class AgentThread:
    """Persistent conversation session for agents.
    
    AgentThread manages conversation history with persistence support,
    enabling conversations to be saved, loaded, and resumed.
    
    Features:
    - Unique session identification
    - Message history management
    - Checkpoints for branching/rollback
    - File and Redis persistence
    - Thread metadata
    - Variable storage
    
    Attributes:
        session_id: Unique session identifier
        messages: Conversation messages
        metadata: Thread metadata
        created_at: When thread was created
        updated_at: When thread was last updated
    
    Example:
        ```python
        # New conversation
        thread = AgentThread(session_id="user_123")
        thread.add_message(Message(role="user", content="Hello"))
        thread.add_message(Message(role="assistant", content="Hi there!"))
        
        # Save
        await thread.save("./sessions/user_123.json")
        
        # Resume later
        thread = await AgentThread.load("user_123", path="./sessions/")
        print(f"Resuming with {len(thread.messages)} messages")
        ```
    """
    
    def __init__(
        self,
        session_id: str | None = None,
        metadata: dict[str, Any] | None = None,
        messages: list[Message] | None = None,
        created_at: datetime | None = None,
        updated_at: datetime | None = None,
    ) -> None:
        """Initialize AgentThread.
        
        Args:
            session_id: Unique session identifier (auto-generated if None)
            metadata: Optional thread metadata
            messages: Optional initial messages
            created_at: Creation timestamp (defaults to now)
            updated_at: Update timestamp (defaults to now)
        """
        self.session_id = session_id or str(uuid.uuid4())
        self.metadata = metadata or {}
        self._state = ThreadState(
            messages=list(messages) if messages else [],
        )
        self.created_at = created_at or datetime.now(timezone.utc)
        self.updated_at = updated_at or datetime.now(timezone.utc)
        
        # Storage path (set after save/load)
        self._storage_path: str | None = None
    
    # =========================================================================
    # Properties
    # =========================================================================
    
    @property
    def messages(self) -> list[Message]:
        """Get conversation messages."""
        return self._state.messages
    
    @property
    def checkpoints(self) -> list[ThreadCheckpoint]:
        """Get saved checkpoints."""
        return self._state.checkpoints
    
    @property
    def variables(self) -> dict[str, Any]:
        """Get thread-scoped variables."""
        return self._state.variables
    
    @property
    def message_count(self) -> int:
        """Get number of messages."""
        return len(self._state.messages)
    
    @property
    def last_message(self) -> Message | None:
        """Get last message in thread."""
        if self._state.messages:
            return self._state.messages[-1]
        return None
    
    # =========================================================================
    # Message Management
    # =========================================================================
    
    def add_message(self, message: Message) -> None:
        """Add a message to the thread.
        
        Args:
            message: Message to add
        """
        self._state.messages.append(message)
        self.updated_at = datetime.now(timezone.utc)
    
    def add_messages(self, messages: Sequence[Message]) -> None:
        """Add multiple messages to the thread.
        
        Args:
            messages: Messages to add
        """
        self._state.messages.extend(messages)
        self.updated_at = datetime.now(timezone.utc)
    
    def add_user_message(self, content: str, **kwargs: Any) -> Message:
        """Add a user message.
        
        Args:
            content: Message content
            **kwargs: Additional message attributes
            
        Returns:
            Created message
        """
        message = Message(role="user", content=content, **kwargs)
        self.add_message(message)
        return message
    
    def add_assistant_message(self, content: str, **kwargs: Any) -> Message:
        """Add an assistant message.
        
        Args:
            content: Message content
            **kwargs: Additional message attributes
            
        Returns:
            Created message
        """
        message = Message(role="assistant", content=content, **kwargs)
        self.add_message(message)
        return message
    
    def add_system_message(self, content: str, **kwargs: Any) -> Message:
        """Add a system message.
        
        Args:
            content: Message content
            **kwargs: Additional message attributes
            
        Returns:
            Created message
        """
        message = Message(role="system", content=content, **kwargs)
        self.add_message(message)
        return message
    
    def get_recent_messages(self, n: int = 10) -> list[Message]:
        """Get the n most recent messages.
        
        Args:
            n: Number of messages to get
            
        Returns:
            List of recent messages
        """
        return self._state.messages[-n:]
    
    def get_messages_by_role(self, role: str) -> list[Message]:
        """Get messages by role.
        
        Args:
            role: Role to filter by (user, assistant, system)
            
        Returns:
            List of messages with matching role
        """
        return [m for m in self._state.messages if m.role == role]
    
    def clear_messages(self) -> None:
        """Clear all messages."""
        self._state.messages.clear()
        self.updated_at = datetime.now(timezone.utc)
    
    # =========================================================================
    # Checkpoint Management
    # =========================================================================
    
    def create_checkpoint(
        self,
        name: str,
        metadata: dict[str, Any] | None = None,
    ) -> ThreadCheckpoint:
        """Create a checkpoint at current position.
        
        Args:
            name: Checkpoint name
            metadata: Optional checkpoint metadata
            
        Returns:
            Created checkpoint
        """
        checkpoint = ThreadCheckpoint(
            checkpoint_id=str(uuid.uuid4()),
            name=name,
            message_index=len(self._state.messages),
            metadata=metadata or {},
        )
        self._state.checkpoints.append(checkpoint)
        self.updated_at = datetime.now(timezone.utc)
        return checkpoint
    
    def rollback_to_checkpoint(self, checkpoint_id: str) -> bool:
        """Rollback thread to a checkpoint.
        
        Args:
            checkpoint_id: Checkpoint to rollback to
            
        Returns:
            True if rollback succeeded
        """
        for cp in self._state.checkpoints:
            if cp.checkpoint_id == checkpoint_id:
                # Truncate messages to checkpoint
                self._state.messages = self._state.messages[:cp.message_index]
                # Remove later checkpoints
                self._state.checkpoints = [
                    c for c in self._state.checkpoints
                    if c.message_index <= cp.message_index
                ]
                self.updated_at = datetime.now(timezone.utc)
                return True
        return False
    
    def get_checkpoint(self, checkpoint_id: str) -> ThreadCheckpoint | None:
        """Get checkpoint by ID.
        
        Args:
            checkpoint_id: Checkpoint ID
            
        Returns:
            Checkpoint or None
        """
        for cp in self._state.checkpoints:
            if cp.checkpoint_id == checkpoint_id:
                return cp
        return None
    
    def get_checkpoint_by_name(self, name: str) -> ThreadCheckpoint | None:
        """Get checkpoint by name.
        
        Args:
            name: Checkpoint name
            
        Returns:
            Checkpoint or None (returns last match if multiple)
        """
        for cp in reversed(self._state.checkpoints):
            if cp.name == name:
                return cp
        return None
    
    # =========================================================================
    # Variable Management
    # =========================================================================
    
    def set_variable(self, key: str, value: Any) -> None:
        """Set a thread-scoped variable.
        
        Args:
            key: Variable key
            value: Variable value
        """
        self._state.variables[key] = value
        self.updated_at = datetime.now(timezone.utc)
    
    def get_variable(self, key: str, default: Any = None) -> Any:
        """Get a thread-scoped variable.
        
        Args:
            key: Variable key
            default: Default value if not found
            
        Returns:
            Variable value or default
        """
        return self._state.variables.get(key, default)
    
    def delete_variable(self, key: str) -> bool:
        """Delete a thread-scoped variable.
        
        Args:
            key: Variable key
            
        Returns:
            True if variable was deleted
        """
        if key in self._state.variables:
            del self._state.variables[key]
            self.updated_at = datetime.now(timezone.utc)
            return True
        return False
    
    # =========================================================================
    # Serialization
    # =========================================================================
    
    def to_dict(self) -> dict[str, Any]:
        """Serialize thread to dictionary.
        
        Returns:
            Serialized thread data
        """
        return {
            "session_id": self.session_id,
            "metadata": self.metadata,
            "messages": [m.to_dict() for m in self._state.messages],
            "checkpoints": [cp.to_dict() for cp in self._state.checkpoints],
            "variables": self._state.variables,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
        }
    
    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "AgentThread":
        """Create thread from dictionary.
        
        Args:
            data: Serialized thread data
            
        Returns:
            AgentThread instance
        """
        # Parse timestamps
        created_at = data.get("created_at")
        if isinstance(created_at, str):
            created_at = datetime.fromisoformat(created_at)
        
        updated_at = data.get("updated_at")
        if isinstance(updated_at, str):
            updated_at = datetime.fromisoformat(updated_at)
        
        # Parse messages
        messages = []
        for m_data in data.get("messages", []):
            messages.append(Message(
                role=m_data["role"],
                content=m_data["content"],
                name=m_data.get("name"),
                tool_call_id=m_data.get("tool_call_id"),
                timestamp=datetime.fromisoformat(m_data["timestamp"])
                    if "timestamp" in m_data else datetime.now(timezone.utc),
                metadata=m_data.get("metadata", {}),
            ))
        
        # Parse checkpoints
        checkpoints = [
            ThreadCheckpoint.from_dict(cp_data)
            for cp_data in data.get("checkpoints", [])
        ]
        
        # Create thread
        thread = cls(
            session_id=data["session_id"],
            metadata=data.get("metadata", {}),
            messages=messages,
            created_at=created_at,
            updated_at=updated_at,
        )
        thread._state.checkpoints = checkpoints
        thread._state.variables = data.get("variables", {})
        
        return thread
    
    def to_json(self, indent: int | None = 2) -> str:
        """Serialize thread to JSON string.
        
        Args:
            indent: JSON indentation (None for compact)
            
        Returns:
            JSON string
        """
        return json.dumps(self.to_dict(), indent=indent, ensure_ascii=False)
    
    @classmethod
    def from_json(cls, json_str: str) -> "AgentThread":
        """Create thread from JSON string.
        
        Args:
            json_str: JSON string
            
        Returns:
            AgentThread instance
        """
        return cls.from_dict(json.loads(json_str))
    
    # =========================================================================
    # File Persistence
    # =========================================================================
    
    async def save(self, path: str | None = None) -> str:
        """Save thread to file.
        
        Args:
            path: File path (uses session_id if directory, or auto-generates)
            
        Returns:
            Path where thread was saved
        """
        if path is None:
            if self._storage_path:
                path = self._storage_path
            else:
                path = f"./sessions/{self.session_id}.json"
        
        # Handle directory vs file path
        path_obj = Path(path)
        if path_obj.is_dir() or not path.endswith(".json"):
            path_obj = path_obj / f"{self.session_id}.json"
        
        # Ensure directory exists
        path_obj.parent.mkdir(parents=True, exist_ok=True)
        
        # Write file
        def _write():
            with open(path_obj, "w", encoding="utf-8") as f:
                f.write(self.to_json())
        
        await asyncio.get_event_loop().run_in_executor(None, _write)
        
        self._storage_path = str(path_obj)
        return str(path_obj)
    
    @classmethod
    async def load(
        cls,
        session_id: str,
        path: str = "./sessions/",
    ) -> "AgentThread":
        """Load thread from file.
        
        Args:
            session_id: Session ID to load
            path: Directory or file path
            
        Returns:
            Loaded AgentThread
            
        Raises:
            FileNotFoundError: If session file not found
        """
        path_obj = Path(path)
        if path_obj.is_dir():
            path_obj = path_obj / f"{session_id}.json"
        
        if not path_obj.exists():
            raise FileNotFoundError(f"Session not found: {path_obj}")
        
        def _read():
            with open(path_obj, "r", encoding="utf-8") as f:
                return f.read()
        
        json_str = await asyncio.get_event_loop().run_in_executor(None, _read)
        thread = cls.from_json(json_str)
        thread._storage_path = str(path_obj)
        
        return thread
    
    @classmethod
    async def load_or_create(
        cls,
        session_id: str,
        path: str = "./sessions/",
        **kwargs: Any,
    ) -> "AgentThread":
        """Load existing thread or create new one.
        
        Args:
            session_id: Session ID
            path: Directory path
            **kwargs: Additional args for new thread
            
        Returns:
            Loaded or new AgentThread
        """
        try:
            return await cls.load(session_id, path)
        except FileNotFoundError:
            thread = cls(session_id=session_id, **kwargs)
            thread._storage_path = str(Path(path) / f"{session_id}.json")
            return thread
    
    @classmethod
    async def list_sessions(cls, path: str = "./sessions/") -> list[str]:
        """List all available session IDs.
        
        Args:
            path: Sessions directory
            
        Returns:
            List of session IDs
        """
        path_obj = Path(path)
        if not path_obj.exists():
            return []
        
        def _list():
            return [
                f.stem for f in path_obj.glob("*.json")
            ]
        
        return await asyncio.get_event_loop().run_in_executor(None, _list)
    
    async def delete(self) -> bool:
        """Delete thread file.
        
        Returns:
            True if deleted successfully
        """
        if self._storage_path and Path(self._storage_path).exists():
            def _delete():
                os.remove(self._storage_path)
            await asyncio.get_event_loop().run_in_executor(None, _delete)
            return True
        return False
    
    # =========================================================================
    # Redis Persistence
    # =========================================================================
    
    async def save_to_redis(
        self,
        redis_client: "Redis",
        prefix: str = "thread:",
        ttl: int | None = None,
    ) -> str:
        """Save thread to Redis.
        
        Args:
            redis_client: Async Redis client
            prefix: Key prefix
            ttl: Time-to-live in seconds (None for no expiry)
            
        Returns:
            Redis key
        """
        key = f"{prefix}{self.session_id}"
        data = self.to_json()
        
        if ttl:
            await redis_client.setex(key, ttl, data)
        else:
            await redis_client.set(key, data)
        
        return key
    
    @classmethod
    async def load_from_redis(
        cls,
        session_id: str,
        redis_client: "Redis",
        prefix: str = "thread:",
    ) -> "AgentThread":
        """Load thread from Redis.
        
        Args:
            session_id: Session ID
            redis_client: Async Redis client
            prefix: Key prefix
            
        Returns:
            Loaded AgentThread
            
        Raises:
            KeyError: If session not found
        """
        key = f"{prefix}{session_id}"
        data = await redis_client.get(key)
        
        if data is None:
            raise KeyError(f"Session not found: {key}")
        
        if isinstance(data, bytes):
            data = data.decode("utf-8")
        
        return cls.from_json(data)
    
    @classmethod
    async def load_or_create_redis(
        cls,
        session_id: str,
        redis_client: "Redis",
        prefix: str = "thread:",
        **kwargs: Any,
    ) -> "AgentThread":
        """Load existing thread from Redis or create new one.
        
        Args:
            session_id: Session ID
            redis_client: Async Redis client
            prefix: Key prefix
            **kwargs: Additional args for new thread
            
        Returns:
            Loaded or new AgentThread
        """
        try:
            return await cls.load_from_redis(session_id, redis_client, prefix)
        except KeyError:
            return cls(session_id=session_id, **kwargs)
    
    @classmethod
    async def list_sessions_redis(
        cls,
        redis_client: "Redis",
        prefix: str = "thread:",
    ) -> list[str]:
        """List all session IDs in Redis.
        
        Args:
            redis_client: Async Redis client
            prefix: Key prefix
            
        Returns:
            List of session IDs
        """
        keys = await redis_client.keys(f"{prefix}*")
        return [
            key.decode("utf-8").removeprefix(prefix)
            if isinstance(key, bytes)
            else key.removeprefix(prefix)
            for key in keys
        ]
    
    async def delete_from_redis(
        self,
        redis_client: "Redis",
        prefix: str = "thread:",
    ) -> bool:
        """Delete thread from Redis.
        
        Args:
            redis_client: Async Redis client
            prefix: Key prefix
            
        Returns:
            True if deleted
        """
        key = f"{prefix}{self.session_id}"
        result = await redis_client.delete(key)
        return result > 0
    
    # =========================================================================
    # ChatHistoryProvider Conversion
    # =========================================================================
    
    def to_chat_messages(self) -> list[ChatMessage]:
        """Convert messages to ChatMessage format.
        
        Returns:
            List of ChatMessage instances
        """
        return [
            ChatMessage(
                role=m.role,
                content=m.content,
                author_name=m.name,
                created_at=m.timestamp,
                metadata=m.metadata,
            )
            for m in self._state.messages
        ]
    
    def as_chat_history_provider(self) -> "ThreadChatHistoryProvider":
        """Create ChatHistoryProvider backed by this thread.
        
        Returns:
            ChatHistoryProvider instance
        """
        return ThreadChatHistoryProvider(self)
    
    # =========================================================================
    # Utilities
    # =========================================================================
    
    def fork(self, new_session_id: str | None = None) -> "AgentThread":
        """Create a fork of this thread.
        
        Args:
            new_session_id: Session ID for fork (auto-generated if None)
            
        Returns:
            New AgentThread with copied state
        """
        fork_data = self.to_dict()
        fork_data["session_id"] = new_session_id or str(uuid.uuid4())
        fork_data["metadata"] = {
            **fork_data["metadata"],
            "forked_from": self.session_id,
            "forked_at": datetime.now(timezone.utc).isoformat(),
        }
        return AgentThread.from_dict(fork_data)
    
    def get_summary(self) -> dict[str, Any]:
        """Get thread summary.
        
        Returns:
            Summary dict with key statistics
        """
        return {
            "session_id": self.session_id,
            "message_count": len(self._state.messages),
            "checkpoint_count": len(self._state.checkpoints),
            "variable_count": len(self._state.variables),
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
            "last_message_role": self.last_message.role if self.last_message else None,
        }
    
    def __repr__(self) -> str:
        return (
            f"AgentThread(session_id={self.session_id!r}, "
            f"messages={len(self._state.messages)}, "
            f"checkpoints={len(self._state.checkpoints)})"
        )
    
    def __len__(self) -> int:
        return len(self._state.messages)


# =============================================================================
# ChatHistoryProvider Adapter
# =============================================================================


class ThreadChatHistoryProvider(ChatHistoryProvider):
    """ChatHistoryProvider backed by an AgentThread.
    
    This allows using AgentThread with AF's ChatAgent sessions.
    
    Example:
        ```python
        thread = AgentThread(session_id="user_123")
        provider = thread.as_chat_history_provider()
        
        # Use with AF
        session = ChatClientAgentSession(
            chat_history_provider=provider,
        )
        ```
    """
    
    def __init__(self, thread: AgentThread) -> None:
        """Initialize provider.
        
        Args:
            thread: AgentThread to wrap
        """
        self.thread = thread
    
    async def invoking_async(
        self,
        context: "InvokingContext",
    ) -> Sequence[ChatMessage]:
        """Get chat history for invocation.
        
        Args:
            context: Invoking context
            
        Returns:
            Historical messages
        """
        from multi_agent_base.core.chat_history import InvokingContext
        return self.thread.to_chat_messages()
    
    async def invoked_async(
        self,
        context: "InvokedContext",
    ) -> None:
        """Store new messages after invocation.
        
        Args:
            context: Invoked context with messages
        """
        from multi_agent_base.core.chat_history import InvokedContext
        
        # Add request messages
        for msg in context.request_messages:
            self.thread.add_message(Message(
                role=msg.role,
                content=msg.content,
                name=msg.author_name,
                metadata=msg.metadata,
            ))
        
        # Add response messages
        for msg in context.response_messages:
            self.thread.add_message(Message(
                role=msg.role,
                content=msg.content,
                name=msg.author_name,
                metadata=msg.metadata,
            ))
    
    def serialize(self) -> dict[str, Any]:
        """Serialize provider state."""
        return self.thread.to_dict()
    
    @classmethod
    def deserialize(cls, state: dict[str, Any]) -> "ThreadChatHistoryProvider":
        """Deserialize provider from state."""
        thread = AgentThread.from_dict(state)
        return cls(thread)


# =============================================================================
# Convenience Functions
# =============================================================================


async def create_thread(
    session_id: str | None = None,
    system_prompt: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> AgentThread:
    """Create a new AgentThread with optional system prompt.
    
    Args:
        session_id: Session ID (auto-generated if None)
        system_prompt: Optional system prompt to add
        metadata: Optional metadata
        
    Returns:
        New AgentThread
    """
    thread = AgentThread(session_id=session_id, metadata=metadata)
    
    if system_prompt:
        thread.add_system_message(system_prompt)
    
    return thread


async def resume_thread(
    session_id: str,
    path: str = "./sessions/",
    redis_client: Optional["Redis"] = None,
) -> AgentThread:
    """Resume a thread from storage.
    
    Args:
        session_id: Session ID to resume
        path: File path (if using file storage)
        redis_client: Redis client (if using Redis storage)
        
    Returns:
        Loaded AgentThread
        
    Raises:
        FileNotFoundError: If session not found (file)
        KeyError: If session not found (Redis)
    """
    if redis_client:
        return await AgentThread.load_from_redis(session_id, redis_client)
    else:
        return await AgentThread.load(session_id, path)
