"""
Base Tool Interface for Multi-Agent Framework.

Provides unified abstraction for tools, skills, and actions with:
- Async execution support
- Timeout and retry handling
- Multi-provider schema conversion (OpenAI, Anthropic, Ollama)
- A2A AgentSkill integration
"""

from abc import ABC, abstractmethod
from enum import Enum
from typing import Any, Callable, get_type_hints, Union
from datetime import datetime
import asyncio
import inspect
import json
import uuid

from pydantic import BaseModel, Field


class ToolResultStatus(Enum):
    """Status of tool execution result."""
    SUCCESS = "success"
    ERROR = "error"
    PARTIAL = "partial"
    TIMEOUT = "timeout"
    CANCELLED = "cancelled"


class ToolResult(BaseModel):
    """Result of a tool execution."""
    status: ToolResultStatus = ToolResultStatus.SUCCESS
    data: Any = None
    error: str | None = None
    execution_time_ms: float = 0.0
    metadata: dict[str, Any] = Field(default_factory=dict)
    
    @classmethod
    def success(cls, data: Any, **metadata) -> "ToolResult":
        """Create a successful result."""
        return cls(status=ToolResultStatus.SUCCESS, data=data, metadata=metadata)
    
    @classmethod
    def failure(cls, error: str, **metadata) -> "ToolResult":
        """Create a failed result."""
        return cls(status=ToolResultStatus.ERROR, error=error, metadata=metadata)
    
    @classmethod
    def timeout(cls, error: str = "Execution timed out") -> "ToolResult":
        """Create a timeout result."""
        return cls(status=ToolResultStatus.TIMEOUT, error=error)
    
    def is_success(self) -> bool:
        """Check if result is successful."""
        return self.status == ToolResultStatus.SUCCESS
    
    def to_string(self) -> str:
        """Convert result to string for LLM consumption."""
        if self.is_success():
            if isinstance(self.data, str):
                return self.data
            return json.dumps(self.data, default=str, ensure_ascii=False)
        return f"Error: {self.error}"


class ToolParameter(BaseModel):
    """Definition of a tool parameter."""
    name: str
    type: str  # JSON Schema type: string, integer, number, boolean, array, object
    description: str = ""
    required: bool = True
    default: Any = None
    enum: list[Any] | None = None
    items: dict[str, Any] | None = None  # For array types
    properties: dict[str, Any] | None = None  # For object types
    
    def to_json_schema(self) -> dict[str, Any]:
        """Convert to JSON Schema format."""
        schema: dict[str, Any] = {"type": self.type}
        
        if self.description:
            schema["description"] = self.description
        if self.default is not None:
            schema["default"] = self.default
        if self.enum:
            schema["enum"] = self.enum
        if self.items and self.type == "array":
            schema["items"] = self.items
        if self.properties and self.type == "object":
            schema["properties"] = self.properties
            
        return schema


class BaseTool(ABC, BaseModel):
    """
    Unified base class for all tools/skills/actions.
    
    Inherit from this class to create custom tools:
    
    ```python
    class CalculatorTool(BaseTool):
        name: str = "calculator"
        description: str = "Perform mathematical calculations"
        
        async def execute(self, expression: str) -> ToolResult:
            try:
                result = eval(expression)  # Use safer evaluation in production
                return ToolResult.success(result)
            except Exception as e:
                return ToolResult.failure(str(e))
    ```
    """
    
    model_config = {"arbitrary_types_allowed": True}
    
    # Tool metadata
    name: str
    description: str
    category: str = "general"
    version: str = "1.0.0"
    tags: list[str] = Field(default_factory=list)
    
    # Execution settings
    timeout_seconds: float = 30.0
    retry_count: int = 0
    retry_delay_seconds: float = 1.0
    
    # Parameter definitions (auto-extracted from execute signature if not provided)
    parameters: list[ToolParameter] = Field(default_factory=list)
    
    # Internal state
    _id: str = ""
    
    def __init__(self, **data):
        super().__init__(**data)
        if not self._id:
            object.__setattr__(self, '_id', str(uuid.uuid4()))
        
        # Auto-extract parameters from execute method if not provided
        if not self.parameters:
            self._extract_parameters()
    
    @property
    def id(self) -> str:
        """Get unique tool ID."""
        return self._id
    
    def _extract_parameters(self) -> None:
        """Extract parameters from execute method signature."""
        sig = inspect.signature(self.execute)
        hints = get_type_hints(self.execute) if hasattr(self.execute, '__annotations__') else {}
        
        params = []
        for param_name, param in sig.parameters.items():
            if param_name in ('self', 'kwargs', 'args'):
                continue
            
            # Get type
            param_type = hints.get(param_name, str)
            json_type = self._python_type_to_json_type(param_type)
            
            # Check if required
            has_default = param.default != inspect.Parameter.empty
            
            params.append(ToolParameter(
                name=param_name,
                type=json_type,
                required=not has_default,
                default=param.default if has_default else None,
            ))
        
        object.__setattr__(self, 'parameters', params)
    
    @staticmethod
    def _python_type_to_json_type(python_type: type) -> str:
        """Convert Python type to JSON Schema type."""
        type_map = {
            str: "string",
            int: "integer",
            float: "number",
            bool: "boolean",
            list: "array",
            dict: "object",
        }
        
        # Handle Optional, Union types
        origin = getattr(python_type, '__origin__', None)
        if origin is Union:
            args = [a for a in python_type.__args__ if a is not type(None)]
            if args:
                return BaseTool._python_type_to_json_type(args[0])
        
        return type_map.get(python_type, "string")
    
    @abstractmethod
    async def execute(self, **kwargs: Any) -> ToolResult:
        """
        Execute the tool with given parameters.
        
        Override this method in subclasses to implement tool logic.
        Must be async and return a ToolResult.
        """
        pass
    
    async def run(self, **kwargs: Any) -> ToolResult:
        """
        Execute tool with timeout and retry handling.
        
        This is the main entry point for tool execution.
        """
        start_time = datetime.now()
        last_error: str | None = None
        
        for attempt in range(self.retry_count + 1):
            try:
                result = await asyncio.wait_for(
                    self.execute(**kwargs),
                    timeout=self.timeout_seconds
                )
                
                # Add execution time
                execution_time = (datetime.now() - start_time).total_seconds() * 1000
                result.execution_time_ms = execution_time
                result.metadata["attempt"] = attempt + 1
                
                return result
                
            except asyncio.TimeoutError:
                last_error = f"Timeout after {self.timeout_seconds}s"
                if attempt < self.retry_count:
                    await asyncio.sleep(self.retry_delay_seconds)
                    
            except Exception as e:
                last_error = str(e)
                if attempt < self.retry_count:
                    await asyncio.sleep(self.retry_delay_seconds)
        
        # All retries exhausted
        execution_time = (datetime.now() - start_time).total_seconds() * 1000
        return ToolResult(
            status=ToolResultStatus.ERROR,
            error=last_error,
            execution_time_ms=execution_time,
            metadata={"attempts": self.retry_count + 1}
        )
    
    def validate_params(self, **kwargs: Any) -> tuple[bool, str | None]:
        """
        Validate input parameters against schema.
        
        Returns (is_valid, error_message).
        """
        for param in self.parameters:
            if param.required and param.name not in kwargs:
                return False, f"Missing required parameter: {param.name}"
            
            if param.name in kwargs and param.enum:
                if kwargs[param.name] not in param.enum:
                    return False, f"Invalid value for {param.name}. Must be one of: {param.enum}"
        
        return True, None
    
    def to_openai_schema(self) -> dict[str, Any]:
        """Convert to OpenAI function calling format."""
        properties = {}
        required = []
        
        for param in self.parameters:
            properties[param.name] = param.to_json_schema()
            if param.required:
                required.append(param.name)
        
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": {
                    "type": "object",
                    "properties": properties,
                    "required": required,
                }
            }
        }
    
    def to_anthropic_schema(self) -> dict[str, Any]:
        """Convert to Anthropic tool format."""
        properties = {}
        required = []
        
        for param in self.parameters:
            properties[param.name] = param.to_json_schema()
            if param.required:
                required.append(param.name)
        
        return {
            "name": self.name,
            "description": self.description,
            "input_schema": {
                "type": "object",
                "properties": properties,
                "required": required,
            }
        }
    
    def to_ollama_schema(self) -> dict[str, Any]:
        """Convert to Ollama tool format (same as OpenAI)."""
        return self.to_openai_schema()
    
    def to_agent_skill(self) -> "AgentSkill":
        """Convert to A2A AgentSkill format."""
        from multi_agent_base.a2a.agent_card import AgentSkill
        
        return AgentSkill(
            id=self.id,
            name=self.name,
            description=self.description,
            tags=self.tags or [self.category],
            input_modes=["text"],
            output_modes=["text"],
        )


class FunctionTool(BaseTool):
    """
    Tool wrapper for regular Python functions.
    
    Allows using existing functions as tools without creating a class:
    
    ```python
    def add_numbers(a: int, b: int) -> int:
        '''Add two numbers together.'''
        return a + b
    
    tool = FunctionTool.from_function(add_numbers)
    result = await tool.run(a=5, b=3)
    ```
    """
    
    _function: Callable[..., Any] | None = None
    _is_async: bool = False
    
    async def execute(self, **kwargs: Any) -> ToolResult:
        """Execute the wrapped function."""
        if self._function is None:
            return ToolResult.failure("No function attached to tool")
        
        try:
            if self._is_async:
                result = await self._function(**kwargs)
            else:
                # Run sync function in executor to not block
                loop = asyncio.get_event_loop()
                result = await loop.run_in_executor(None, lambda: self._function(**kwargs))
            
            return ToolResult.success(result)
            
        except Exception as e:
            return ToolResult.failure(str(e))
    
    @classmethod
    def from_function(
        cls,
        func: Callable[..., Any],
        name: str | None = None,
        description: str | None = None,
        category: str = "general",
        tags: list[str] | None = None,
        timeout_seconds: float = 30.0,
        retry_count: int = 0,
    ) -> "FunctionTool":
        """
        Create a FunctionTool from a Python function.
        
        Args:
            func: The function to wrap
            name: Tool name (defaults to function name)
            description: Tool description (defaults to docstring)
            category: Tool category
            tags: Tool tags
            timeout_seconds: Execution timeout
            retry_count: Number of retries on failure
        
        Returns:
            FunctionTool instance
        """
        tool_name = name or func.__name__
        tool_description = description or (func.__doc__ or "").strip().split("\n")[0]
        is_async = asyncio.iscoroutinefunction(func)
        
        # Extract parameters
        sig = inspect.signature(func)
        hints = get_type_hints(func) if hasattr(func, '__annotations__') else {}
        
        params = []
        for param_name, param in sig.parameters.items():
            if param_name in ('self', 'kwargs', 'args'):
                continue
            
            param_type = hints.get(param_name, str)
            json_type = BaseTool._python_type_to_json_type(param_type)
            has_default = param.default != inspect.Parameter.empty
            
            # Try to extract description from docstring
            param_desc = ""
            if func.__doc__:
                # Simple Args parsing
                doc_lines = func.__doc__.split("\n")
                for i, line in enumerate(doc_lines):
                    if param_name in line and ":" in line:
                        param_desc = line.split(":", 1)[-1].strip()
                        break
            
            params.append(ToolParameter(
                name=param_name,
                type=json_type,
                description=param_desc,
                required=not has_default,
                default=param.default if has_default else None,
            ))
        
        tool = cls(
            name=tool_name,
            description=tool_description,
            category=category,
            tags=tags or [],
            timeout_seconds=timeout_seconds,
            retry_count=retry_count,
            parameters=params,
        )
        
        object.__setattr__(tool, '_function', func)
        object.__setattr__(tool, '_is_async', is_async)
        
        return tool


class ActionTool(BaseTool):
    """
    Tool for performing actions with side effects.
    
    Actions are tools that modify external state (write files, send emails, etc.)
    and may have confirmation requirements.
    
    ```python
    class SendEmailAction(ActionTool):
        name: str = "send_email"
        description: str = "Send an email to a recipient"
        requires_confirmation: bool = True
        
        async def execute(self, to: str, subject: str, body: str) -> ToolResult:
            # Send email logic
            return ToolResult.success({"sent": True, "to": to})
    ```
    """
    
    requires_confirmation: bool = False
    is_destructive: bool = False
    
    def get_confirmation_message(self, **kwargs: Any) -> str:
        """Get confirmation message for user."""
        return f"Are you sure you want to execute '{self.name}' with parameters: {kwargs}?"


class CompositeToolMixin:
    """
    Mixin for tools that compose other tools.
    
    Allows creating tools that orchestrate multiple sub-tools.
    """
    
    sub_tools: list[BaseTool] = []
    
    def add_sub_tool(self, tool: BaseTool) -> None:
        """Add a sub-tool."""
        self.sub_tools.append(tool)
    
    def get_sub_tool(self, name: str) -> BaseTool | None:
        """Get sub-tool by name."""
        for tool in self.sub_tools:
            if tool.name == name:
                return tool
        return None
    
    async def execute_sub_tool(self, name: str, **kwargs: Any) -> ToolResult:
        """Execute a sub-tool by name."""
        tool = self.get_sub_tool(name)
        if not tool:
            return ToolResult.failure(f"Sub-tool not found: {name}")
        return await tool.run(**kwargs)


# =============================================================================
# Tool Adapters - Bridge between core.agent.Tool and core.tools.BaseTool
# =============================================================================

def base_tool_to_agent_tool(base_tool: BaseTool) -> "AgentTool":
    """Convert a BaseTool to core.agent.Tool format.
    
    This allows using advanced BaseTool features (timeout, retry, validation)
    with the simpler BaseAgent tool system.
    
    Args:
        base_tool: A BaseTool instance
        
    Returns:
        Tool instance compatible with BaseAgent
    """
    from multi_agent_base.core.agent import Tool as AgentTool
    
    # Build parameters schema
    properties = {}
    required = []
    for param in base_tool.parameters:
        properties[param.name] = param.to_json_schema()
        if param.required:
            required.append(param.name)
    
    parameters = {
        "type": "object",
        "properties": properties,
        "required": required,
    }
    
    # Create wrapper function that calls base_tool.run()
    async def wrapper_func(**kwargs: Any) -> Any:
        result = await base_tool.run(**kwargs)
        if result.is_success():
            return result.data
        else:
            return {"error": result.error}
    
    return AgentTool(
        name=base_tool.name,
        description=base_tool.description,
        function=wrapper_func,
        parameters=parameters,
    )


def agent_tool_to_base_tool(
    agent_tool: "AgentTool",
    timeout_seconds: float = 30.0,
    retry_count: int = 0,
    category: str = "general",
    tags: list[str] | None = None,
) -> FunctionTool:
    """Convert a core.agent.Tool to BaseTool format.
    
    This allows using the simple Tool class with BaseTool features
    like timeout and retry.
    
    Args:
        agent_tool: A Tool instance from core.agent
        timeout_seconds: Execution timeout
        retry_count: Number of retries on failure
        category: Tool category
        tags: Optional tags
        
    Returns:
        FunctionTool instance with BaseTool capabilities
    """
    return FunctionTool.from_function(
        func=agent_tool.function,
        name=agent_tool.name,
        description=agent_tool.description,
        timeout_seconds=timeout_seconds,
        retry_count=retry_count,
        category=category,
        tags=tags or [],
    )


def callable_to_base_tool(
    func: Callable[..., Any],
    name: str | None = None,
    description: str | None = None,
    timeout_seconds: float = 30.0,
    retry_count: int = 0,
    category: str = "general",
    tags: list[str] | None = None,
) -> FunctionTool:
    """Convert a callable function to a FunctionTool.
    
    Convenience function for quick tool creation from functions.
    
    Args:
        func: The function to wrap
        name: Tool name (defaults to function name)
        description: Tool description (defaults to docstring)
        timeout_seconds: Execution timeout
        retry_count: Number of retries on failure
        category: Tool category
        tags: Optional tags
        
    Returns:
        FunctionTool instance
        
    Example:
        ```python
        def get_weather(location: str) -> str:
            '''Get weather for a location.'''
            return f"Weather in {location}: Sunny, 22°C"
        
        tool = callable_to_base_tool(get_weather, timeout_seconds=10)
        result = await tool.run(location="Paris")
        ```
    """
    return FunctionTool.from_function(
        func=func,
        name=name,
        description=description,
        timeout_seconds=timeout_seconds,
        retry_count=retry_count,
        category=category,
        tags=tags or [],
    )