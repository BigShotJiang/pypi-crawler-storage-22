"""
Microsoft Agent Framework Workflows Adapter.

This module provides adapters to use AF's Workflow engine with our Pattern classes,
enabling:

- Pattern → Workflow conversion
- Checkpointing and state persistence
- Workflow visualization
- Orchestration types: Sequential, Concurrent, GroupChat, Handoff

Usage:
    ```python
    from multi_agent_base.core.workflows import (
        WorkflowAdapter,
        PatternToWorkflow,
        SequentialWorkflowBuilder,
    )
    
    # Convert a Pattern to AF Workflow
    pattern = SupervisorPattern(config)
    workflow = PatternToWorkflow(pattern).build()
    
    # Run with checkpointing
    result = await workflow.run("Process this data")
    ```
"""

from __future__ import annotations

import asyncio
import uuid
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import (
    TYPE_CHECKING,
    Any,
    AsyncIterator,
    Callable,
    Dict,
    Generic,
    List,
    Optional,
    Sequence,
    TypeVar,
    Union,
)

if TYPE_CHECKING:
    from multi_agent_base.core.patterns import BasePattern, PatternResult
    from multi_agent_base.core.agent import BaseAgent
    from multi_agent_base.observability.logger import AgentLogger


# Type variables
T = TypeVar("T")
TInput = TypeVar("TInput")
TOutput = TypeVar("TOutput")


class WorkflowState(str, Enum):
    """State of a workflow execution."""
    
    PENDING = "pending"
    RUNNING = "running"
    PAUSED = "paused"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class ExecutorType(str, Enum):
    """Types of workflow executors."""
    
    AGENT = "agent"
    FUNCTION = "function"
    WORKFLOW = "workflow"
    ROUTER = "router"
    FAN_OUT = "fan_out"
    FAN_IN = "fan_in"


@dataclass
class ExecutorResult:
    """Result from an executor."""
    
    executor_id: str
    output: Any
    success: bool = True
    error: str | None = None
    duration_ms: float = 0.0
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class WorkflowCheckpoint:
    """Checkpoint for workflow state persistence.
    
    Allows resumption of workflows from a specific point.
    """
    
    id: str
    workflow_id: str
    state: WorkflowState
    current_executor_id: str | None
    completed_executors: list[str] = field(default_factory=list)
    executor_results: dict[str, ExecutorResult] = field(default_factory=dict)
    shared_state: dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=datetime.utcnow)
    metadata: dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> dict[str, Any]:
        """Serialize checkpoint to dict."""
        return {
            "id": self.id,
            "workflow_id": self.workflow_id,
            "state": self.state.value,
            "current_executor_id": self.current_executor_id,
            "completed_executors": self.completed_executors,
            "executor_results": {
                k: {
                    "executor_id": v.executor_id,
                    "output": v.output,
                    "success": v.success,
                    "error": v.error,
                }
                for k, v in self.executor_results.items()
            },
            "shared_state": self.shared_state,
            "created_at": self.created_at.isoformat(),
            "metadata": self.metadata,
        }
    
    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "WorkflowCheckpoint":
        """Deserialize checkpoint from dict."""
        return cls(
            id=data["id"],
            workflow_id=data["workflow_id"],
            state=WorkflowState(data["state"]),
            current_executor_id=data.get("current_executor_id"),
            completed_executors=data.get("completed_executors", []),
            executor_results={
                k: ExecutorResult(**v)
                for k, v in data.get("executor_results", {}).items()
            },
            shared_state=data.get("shared_state", {}),
            created_at=datetime.fromisoformat(data["created_at"]) if data.get("created_at") else datetime.utcnow(),
            metadata=data.get("metadata", {}),
        )


class CheckpointStore(ABC):
    """Abstract checkpoint storage backend."""
    
    @abstractmethod
    async def save(self, checkpoint: WorkflowCheckpoint) -> None:
        """Save a checkpoint."""
        pass
    
    @abstractmethod
    async def load(self, checkpoint_id: str) -> WorkflowCheckpoint | None:
        """Load a checkpoint by ID."""
        pass
    
    @abstractmethod
    async def load_latest(self, workflow_id: str) -> WorkflowCheckpoint | None:
        """Load the latest checkpoint for a workflow."""
        pass
    
    @abstractmethod
    async def list_checkpoints(self, workflow_id: str) -> list[WorkflowCheckpoint]:
        """List all checkpoints for a workflow."""
        pass
    
    @abstractmethod
    async def delete(self, checkpoint_id: str) -> bool:
        """Delete a checkpoint."""
        pass


class InMemoryCheckpointStore(CheckpointStore):
    """In-memory checkpoint store for development/testing."""
    
    def __init__(self) -> None:
        self._checkpoints: dict[str, WorkflowCheckpoint] = {}
        self._by_workflow: dict[str, list[str]] = {}
    
    async def save(self, checkpoint: WorkflowCheckpoint) -> None:
        """Save checkpoint to memory."""
        self._checkpoints[checkpoint.id] = checkpoint
        
        if checkpoint.workflow_id not in self._by_workflow:
            self._by_workflow[checkpoint.workflow_id] = []
        self._by_workflow[checkpoint.workflow_id].append(checkpoint.id)
    
    async def load(self, checkpoint_id: str) -> WorkflowCheckpoint | None:
        """Load checkpoint from memory."""
        return self._checkpoints.get(checkpoint_id)
    
    async def load_latest(self, workflow_id: str) -> WorkflowCheckpoint | None:
        """Load latest checkpoint for workflow."""
        checkpoint_ids = self._by_workflow.get(workflow_id, [])
        if not checkpoint_ids:
            return None
        return self._checkpoints.get(checkpoint_ids[-1])
    
    async def list_checkpoints(self, workflow_id: str) -> list[WorkflowCheckpoint]:
        """List all checkpoints for workflow."""
        checkpoint_ids = self._by_workflow.get(workflow_id, [])
        return [
            self._checkpoints[cid]
            for cid in checkpoint_ids
            if cid in self._checkpoints
        ]
    
    async def delete(self, checkpoint_id: str) -> bool:
        """Delete checkpoint from memory."""
        if checkpoint_id not in self._checkpoints:
            return False
        
        checkpoint = self._checkpoints.pop(checkpoint_id)
        if checkpoint.workflow_id in self._by_workflow:
            self._by_workflow[checkpoint.workflow_id] = [
                cid for cid in self._by_workflow[checkpoint.workflow_id]
                if cid != checkpoint_id
            ]
        return True


@dataclass
class Edge:
    """Represents an edge in the workflow graph.
    
    Connects source executor to target executor with optional condition.
    """
    
    source_id: str
    target_id: str
    condition: Callable[[Any], bool] | None = None
    condition_name: str | None = None
    
    def matches(self, output: Any) -> bool:
        """Check if edge condition matches the output."""
        if self.condition is None:
            return True
        return self.condition(output)


class Executor(ABC, Generic[TInput, TOutput]):
    """Base class for workflow executors.
    
    Executors are the nodes in a workflow graph. They receive input,
    perform some action, and produce output.
    """
    
    def __init__(
        self,
        id: str,
        executor_type: ExecutorType = ExecutorType.FUNCTION,
    ) -> None:
        """Initialize executor.
        
        Args:
            id: Unique executor identifier
            executor_type: Type of executor
        """
        self.id = id
        self.executor_type = executor_type
    
    @abstractmethod
    async def execute(
        self,
        input: TInput,
        context: "WorkflowContext",
    ) -> TOutput:
        """Execute the executor logic.
        
        Args:
            input: Input to the executor
            context: Workflow execution context
            
        Returns:
            Executor output
        """
        pass
    
    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(id={self.id!r})"


class FunctionExecutor(Executor[TInput, TOutput]):
    """Executor that wraps a Python function."""
    
    def __init__(
        self,
        id: str,
        func: Callable[[TInput, "WorkflowContext"], TOutput],
    ) -> None:
        """Initialize function executor.
        
        Args:
            id: Unique identifier
            func: Function to execute
        """
        super().__init__(id, ExecutorType.FUNCTION)
        self.func = func
    
    async def execute(
        self,
        input: TInput,
        context: "WorkflowContext",
    ) -> TOutput:
        """Execute the wrapped function."""
        if asyncio.iscoroutinefunction(self.func):
            return await self.func(input, context)
        return self.func(input, context)


class AgentExecutor(Executor[str, str]):
    """Executor that wraps a BaseAgent."""
    
    def __init__(
        self,
        id: str,
        agent: "BaseAgent",
    ) -> None:
        """Initialize agent executor.
        
        Args:
            id: Unique identifier
            agent: Agent instance to execute
        """
        super().__init__(id, ExecutorType.AGENT)
        self.agent = agent
    
    async def execute(
        self,
        input: str,
        context: "WorkflowContext",
    ) -> str:
        """Execute the agent with input message."""
        # Get conversation history from context
        messages = context.get_messages()
        
        # Add input as user message
        messages.append({"role": "user", "content": input})
        
        # Run agent
        response = await self.agent.run(messages)
        
        # Store response in context
        if hasattr(response, 'content'):
            content = response.content
        else:
            content = str(response)
        
        context.add_message("assistant", content, agent_name=self.agent.name)
        
        return content


class RouterExecutor(Executor[TInput, tuple[str, TInput]]):
    """Executor that routes to different targets based on input."""
    
    def __init__(
        self,
        id: str,
        router_func: Callable[[TInput], str],
    ) -> None:
        """Initialize router executor.
        
        Args:
            id: Unique identifier
            router_func: Function that returns target executor ID
        """
        super().__init__(id, ExecutorType.ROUTER)
        self.router_func = router_func
    
    async def execute(
        self,
        input: TInput,
        context: "WorkflowContext",
    ) -> tuple[str, TInput]:
        """Route input to target executor."""
        if asyncio.iscoroutinefunction(self.router_func):
            target_id = await self.router_func(input)
        else:
            target_id = self.router_func(input)
        
        return (target_id, input)


@dataclass
class WorkflowContext:
    """Context passed through workflow execution.
    
    Contains shared state, messages, and utilities for executors.
    """
    
    workflow_id: str
    run_id: str
    shared_state: dict[str, Any] = field(default_factory=dict)
    messages: list[dict[str, Any]] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)
    _checkpoint_store: CheckpointStore | None = None
    
    def get(self, key: str, default: Any = None) -> Any:
        """Get value from shared state."""
        return self.shared_state.get(key, default)
    
    def set(self, key: str, value: Any) -> None:
        """Set value in shared state."""
        self.shared_state[key] = value
    
    def get_messages(self) -> list[dict[str, str]]:
        """Get messages for LLM context."""
        return [
            {"role": m["role"], "content": m["content"]}
            for m in self.messages
        ]
    
    def add_message(
        self,
        role: str,
        content: str,
        agent_name: str | None = None,
    ) -> None:
        """Add a message to conversation history."""
        self.messages.append({
            "role": role,
            "content": content,
            "agent_name": agent_name,
            "timestamp": datetime.utcnow().isoformat(),
        })
    
    async def save_checkpoint(
        self,
        current_executor_id: str,
        completed: list[str],
        results: dict[str, ExecutorResult],
    ) -> WorkflowCheckpoint:
        """Save a checkpoint of current workflow state."""
        checkpoint = WorkflowCheckpoint(
            id=str(uuid.uuid4()),
            workflow_id=self.workflow_id,
            state=WorkflowState.RUNNING,
            current_executor_id=current_executor_id,
            completed_executors=completed,
            executor_results=results,
            shared_state=self.shared_state.copy(),
            metadata=self.metadata.copy(),
        )
        
        if self._checkpoint_store:
            await self._checkpoint_store.save(checkpoint)
        
        return checkpoint


@dataclass
class WorkflowResult:
    """Result from workflow execution."""
    
    workflow_id: str
    run_id: str
    state: WorkflowState
    output: Any = None
    executor_results: dict[str, ExecutorResult] = field(default_factory=dict)
    duration_ms: float = 0.0
    checkpoints_created: int = 0
    metadata: dict[str, Any] = field(default_factory=dict)


class Workflow:
    """Represents a workflow graph with executors and edges.
    
    A workflow consists of:
    - Executors: Nodes that perform actions
    - Edges: Connections between executors
    - Start executor: Entry point
    - Checkpointing: State persistence
    
    Example:
        ```python
        workflow = Workflow(id="my-workflow")
        
        # Add executors
        workflow.add_executor(agent1_executor)
        workflow.add_executor(agent2_executor)
        
        # Connect with edges
        workflow.add_edge("agent1", "agent2")
        
        # Set start
        workflow.set_start("agent1")
        
        # Run
        result = await workflow.run("Hello!")
        ```
    """
    
    def __init__(
        self,
        id: str | None = None,
        name: str | None = None,
        description: str | None = None,
        checkpoint_store: CheckpointStore | None = None,
        max_iterations: int = 100,
    ) -> None:
        """Initialize workflow.
        
        Args:
            id: Workflow identifier
            name: Human-readable name
            description: Workflow description
            checkpoint_store: Storage for checkpoints
            max_iterations: Maximum iterations to prevent infinite loops
        """
        self.id = id or str(uuid.uuid4())
        self.name = name
        self.description = description
        self.checkpoint_store = checkpoint_store or InMemoryCheckpointStore()
        self.max_iterations = max_iterations
        
        self._executors: dict[str, Executor] = {}
        self._edges: list[Edge] = {}
        self._start_executor_id: str | None = None
    
    def add_executor(self, executor: Executor) -> "Workflow":
        """Add an executor to the workflow.
        
        Args:
            executor: Executor to add
            
        Returns:
            Self for chaining
        """
        self._executors[executor.id] = executor
        return self
    
    def add_edge(
        self,
        source_id: str,
        target_id: str,
        condition: Callable[[Any], bool] | None = None,
        condition_name: str | None = None,
    ) -> "Workflow":
        """Add an edge between executors.
        
        Args:
            source_id: Source executor ID
            target_id: Target executor ID
            condition: Optional condition function
            condition_name: Optional name for the condition
            
        Returns:
            Self for chaining
        """
        edge = Edge(
            source_id=source_id,
            target_id=target_id,
            condition=condition,
            condition_name=condition_name,
        )
        if source_id not in self._edges:
            self._edges[source_id] = []
        self._edges[source_id].append(edge)
        return self
    
    def set_start(self, executor_id: str) -> "Workflow":
        """Set the start executor.
        
        Args:
            executor_id: ID of the start executor
            
        Returns:
            Self for chaining
        """
        if executor_id not in self._executors:
            raise ValueError(f"Executor {executor_id!r} not found")
        self._start_executor_id = executor_id
        return self
    
    @property
    def executors(self) -> dict[str, Executor]:
        """Get all executors."""
        return self._executors.copy()
    
    @property
    def edges(self) -> list[Edge]:
        """Get all edges."""
        return [e for edges in self._edges.values() for e in edges]
    
    @property
    def start_executor_id(self) -> str | None:
        """Get start executor ID."""
        return self._start_executor_id
    
    def _get_next_executors(
        self,
        current_id: str,
        output: Any,
    ) -> list[str]:
        """Get next executor IDs based on edges and output."""
        edges = self._edges.get(current_id, [])
        next_ids = []
        
        for edge in edges:
            if edge.matches(output):
                next_ids.append(edge.target_id)
        
        return next_ids
    
    async def run(
        self,
        input: Any,
        resume_from: str | None = None,
        context: WorkflowContext | None = None,
    ) -> WorkflowResult:
        """Run the workflow.
        
        Args:
            input: Initial input to the workflow
            resume_from: Checkpoint ID to resume from
            context: Optional existing context
            
        Returns:
            WorkflowResult with final output and metadata
        """
        start_time = datetime.now()
        run_id = str(uuid.uuid4())
        
        # Initialize or restore context
        if resume_from:
            checkpoint = await self.checkpoint_store.load(resume_from)
            if not checkpoint:
                raise ValueError(f"Checkpoint {resume_from!r} not found")
            
            context = WorkflowContext(
                workflow_id=self.id,
                run_id=run_id,
                shared_state=checkpoint.shared_state,
                metadata=checkpoint.metadata,
                _checkpoint_store=self.checkpoint_store,
            )
            current_id = checkpoint.current_executor_id
            completed = set(checkpoint.completed_executors)
            results = checkpoint.executor_results
        else:
            context = context or WorkflowContext(
                workflow_id=self.id,
                run_id=run_id,
                _checkpoint_store=self.checkpoint_store,
            )
            current_id = self._start_executor_id
            completed = set()
            results = {}
        
        if not current_id:
            raise ValueError("No start executor set")
        
        # Execute workflow
        current_output = input
        iterations = 0
        checkpoints_created = 0
        
        while current_id and iterations < self.max_iterations:
            iterations += 1
            
            executor = self._executors.get(current_id)
            if not executor:
                raise ValueError(f"Executor {current_id!r} not found")
            
            # Execute
            exec_start = datetime.now()
            try:
                current_output = await executor.execute(current_output, context)
                
                result = ExecutorResult(
                    executor_id=current_id,
                    output=current_output,
                    success=True,
                    duration_ms=(datetime.now() - exec_start).total_seconds() * 1000,
                )
            except Exception as e:
                result = ExecutorResult(
                    executor_id=current_id,
                    output=None,
                    success=False,
                    error=str(e),
                    duration_ms=(datetime.now() - exec_start).total_seconds() * 1000,
                )
                
                return WorkflowResult(
                    workflow_id=self.id,
                    run_id=run_id,
                    state=WorkflowState.FAILED,
                    output=None,
                    executor_results=results,
                    duration_ms=(datetime.now() - start_time).total_seconds() * 1000,
                    metadata={"error": str(e)},
                )
            
            results[current_id] = result
            completed.add(current_id)
            
            # Save checkpoint
            await context.save_checkpoint(current_id, list(completed), results)
            checkpoints_created += 1
            
            # Get next executor(s)
            next_ids = self._get_next_executors(current_id, current_output)
            
            if not next_ids:
                # No more executors, workflow complete
                break
            
            # For now, take the first matching edge
            # TODO: Support parallel execution with fan-out
            current_id = next_ids[0]
        
        duration_ms = (datetime.now() - start_time).total_seconds() * 1000
        
        return WorkflowResult(
            workflow_id=self.id,
            run_id=run_id,
            state=WorkflowState.COMPLETED,
            output=current_output,
            executor_results=results,
            duration_ms=duration_ms,
            checkpoints_created=checkpoints_created,
        )
    
    def visualize(self, format: str = "mermaid") -> str:
        """Generate visualization of the workflow.
        
        Args:
            format: Output format ("mermaid" or "dot")
            
        Returns:
            Visualization string
        """
        if format == "mermaid":
            return self._to_mermaid()
        elif format == "dot":
            return self._to_dot()
        else:
            raise ValueError(f"Unknown format: {format}")
    
    def _to_mermaid(self) -> str:
        """Generate Mermaid diagram."""
        lines = ["flowchart TD"]
        
        # Nodes
        for executor_id, executor in self._executors.items():
            label = f"{executor_id}"
            if executor_id == self._start_executor_id:
                label += " (Start)"
            
            if executor.executor_type == ExecutorType.AGENT:
                lines.append(f'    {executor_id}["{label}"]')
            elif executor.executor_type == ExecutorType.ROUTER:
                lines.append(f'    {executor_id}{{{label}}}')
            else:
                lines.append(f'    {executor_id}["{label}"]')
        
        # Edges
        for source_id, edges in self._edges.items():
            for edge in edges:
                if edge.condition_name:
                    lines.append(f'    {source_id} -->|{edge.condition_name}| {edge.target_id}')
                else:
                    lines.append(f'    {source_id} --> {edge.target_id}')
        
        return "\n".join(lines)
    
    def _to_dot(self) -> str:
        """Generate DOT format for Graphviz."""
        lines = ["digraph workflow {", "    rankdir=TB;"]
        
        # Nodes
        for executor_id, executor in self._executors.items():
            if executor_id == self._start_executor_id:
                lines.append(f'    {executor_id} [label="{executor_id}\\n(Start)" style=filled fillcolor=lightgreen];')
            elif executor.executor_type == ExecutorType.ROUTER:
                lines.append(f'    {executor_id} [label="{executor_id}" shape=diamond];')
            else:
                lines.append(f'    {executor_id} [label="{executor_id}"];')
        
        # Edges
        for source_id, edges in self._edges.items():
            for edge in edges:
                if edge.condition_name:
                    lines.append(f'    {source_id} -> {edge.target_id} [label="{edge.condition_name}"];')
                else:
                    lines.append(f'    {source_id} -> {edge.target_id};')
        
        lines.append("}")
        return "\n".join(lines)


class WorkflowBuilder:
    """Builder for constructing workflows.
    
    Provides a fluent API for building workflows:
    
        ```python
        workflow = (
            WorkflowBuilder("my-workflow")
            .add_agent_executor("agent1", agent1)
            .add_agent_executor("agent2", agent2)
            .add_edge("agent1", "agent2")
            .set_start("agent1")
            .build()
        )
        ```
    """
    
    def __init__(
        self,
        workflow_id: str | None = None,
        name: str | None = None,
        description: str | None = None,
    ) -> None:
        """Initialize builder.
        
        Args:
            workflow_id: Workflow identifier
            name: Human-readable name
            description: Workflow description
        """
        self.workflow_id = workflow_id
        self.name = name
        self.description = description
        
        self._executors: list[Executor] = []
        self._edges: list[tuple[str, str, Callable | None, str | None]] = []
        self._start_id: str | None = None
        self._checkpoint_store: CheckpointStore | None = None
        self._max_iterations: int = 100
    
    def add_executor(self, executor: Executor) -> "WorkflowBuilder":
        """Add an executor.
        
        Args:
            executor: Executor to add
            
        Returns:
            Self for chaining
        """
        self._executors.append(executor)
        return self
    
    def add_agent_executor(
        self,
        id: str,
        agent: "BaseAgent",
    ) -> "WorkflowBuilder":
        """Add an agent executor.
        
        Args:
            id: Executor ID
            agent: Agent instance
            
        Returns:
            Self for chaining
        """
        executor = AgentExecutor(id=id, agent=agent)
        return self.add_executor(executor)
    
    def add_function_executor(
        self,
        id: str,
        func: Callable,
    ) -> "WorkflowBuilder":
        """Add a function executor.
        
        Args:
            id: Executor ID
            func: Function to execute
            
        Returns:
            Self for chaining
        """
        executor = FunctionExecutor(id=id, func=func)
        return self.add_executor(executor)
    
    def add_router_executor(
        self,
        id: str,
        router_func: Callable[[Any], str],
    ) -> "WorkflowBuilder":
        """Add a router executor.
        
        Args:
            id: Executor ID
            router_func: Function returning target executor ID
            
        Returns:
            Self for chaining
        """
        executor = RouterExecutor(id=id, router_func=router_func)
        return self.add_executor(executor)
    
    def add_edge(
        self,
        source_id: str,
        target_id: str,
        condition: Callable[[Any], bool] | None = None,
        condition_name: str | None = None,
    ) -> "WorkflowBuilder":
        """Add an edge between executors.
        
        Args:
            source_id: Source executor ID
            target_id: Target executor ID
            condition: Optional condition function
            condition_name: Optional condition label
            
        Returns:
            Self for chaining
        """
        self._edges.append((source_id, target_id, condition, condition_name))
        return self
    
    def add_chain(self, *executor_ids: str) -> "WorkflowBuilder":
        """Add a chain of edges between executors.
        
        Args:
            *executor_ids: Executor IDs in order
            
        Returns:
            Self for chaining
        """
        for i in range(len(executor_ids) - 1):
            self.add_edge(executor_ids[i], executor_ids[i + 1])
        return self
    
    def set_start(self, executor_id: str) -> "WorkflowBuilder":
        """Set the start executor.
        
        Args:
            executor_id: Start executor ID
            
        Returns:
            Self for chaining
        """
        self._start_id = executor_id
        return self
    
    def with_checkpoint_store(
        self,
        store: CheckpointStore,
    ) -> "WorkflowBuilder":
        """Set checkpoint storage.
        
        Args:
            store: Checkpoint store
            
        Returns:
            Self for chaining
        """
        self._checkpoint_store = store
        return self
    
    def with_max_iterations(self, max_iterations: int) -> "WorkflowBuilder":
        """Set maximum iterations.
        
        Args:
            max_iterations: Maximum iterations
            
        Returns:
            Self for chaining
        """
        self._max_iterations = max_iterations
        return self
    
    def build(self) -> Workflow:
        """Build the workflow.
        
        Returns:
            Configured Workflow instance
        """
        workflow = Workflow(
            id=self.workflow_id,
            name=self.name,
            description=self.description,
            checkpoint_store=self._checkpoint_store,
            max_iterations=self._max_iterations,
        )
        
        # Add executors
        for executor in self._executors:
            workflow.add_executor(executor)
        
        # Add edges
        for source_id, target_id, condition, condition_name in self._edges:
            workflow.add_edge(source_id, target_id, condition, condition_name)
        
        # Set start
        if self._start_id:
            workflow.set_start(self._start_id)
        elif self._executors:
            workflow.set_start(self._executors[0].id)
        
        return workflow


class SequentialWorkflowBuilder(WorkflowBuilder):
    """Builder for sequential workflows.
    
    Creates workflows where executors run in sequence:
    executor1 → executor2 → executor3
    
    Example:
        ```python
        workflow = (
            SequentialWorkflowBuilder("pipeline")
            .add_agent_executor("extract", extractor_agent)
            .add_agent_executor("transform", transformer_agent)
            .add_agent_executor("load", loader_agent)
            .build()
        )
        ```
    """
    
    def build(self) -> Workflow:
        """Build sequential workflow with automatic chaining."""
        if self._executors:
            # Auto-chain all executors
            executor_ids = [e.id for e in self._executors]
            self.add_chain(*executor_ids)
            self._start_id = executor_ids[0]
        
        return super().build()


class ConcurrentWorkflowBuilder(WorkflowBuilder):
    """Builder for concurrent/parallel workflows.
    
    Creates workflows where executors run in parallel and results
    are aggregated:
    
        start → [exec1, exec2, exec3] → aggregate
    
    Example:
        ```python
        workflow = (
            ConcurrentWorkflowBuilder("parallel-analysis")
            .add_agent_executor("analyze_code", code_analyzer)
            .add_agent_executor("analyze_docs", doc_analyzer)
            .add_agent_executor("analyze_tests", test_analyzer)
            .with_aggregator(aggregate_results)
            .build()
        )
        ```
    """
    
    def __init__(
        self,
        workflow_id: str | None = None,
        name: str | None = None,
    ) -> None:
        super().__init__(workflow_id, name)
        self._aggregator: Callable | None = None
    
    def with_aggregator(
        self,
        aggregator: Callable[[list[Any], WorkflowContext], Any],
    ) -> "ConcurrentWorkflowBuilder":
        """Set result aggregator function.
        
        Args:
            aggregator: Function to aggregate parallel results
            
        Returns:
            Self for chaining
        """
        self._aggregator = aggregator
        return self
    
    def build(self) -> Workflow:
        """Build concurrent workflow.
        
        Note: This builds a sequential approximation. True parallel
        execution requires AF's native ConcurrentBuilder.
        """
        # For now, run sequentially and collect results
        # TODO: Integrate with AF's native ConcurrentBuilder
        if self._aggregator:
            self.add_function_executor("__aggregate__", self._aggregator)
            if self._executors:
                for executor in self._executors[:-1]:  # Exclude aggregator
                    self.add_edge(executor.id, "__aggregate__")
        
        return super().build()


class PatternToWorkflow:
    """Converts Pattern instances to AF Workflows.
    
    Enables using Pattern abstractions while leveraging AF's
    workflow engine for execution, checkpointing, and visualization.
    
    Example:
        ```python
        pattern = SupervisorPattern(config)
        pattern.create_agent("researcher", "Research topics")
        pattern.create_agent("writer", "Write content")
        
        workflow = PatternToWorkflow(pattern).build()
        result = await workflow.run("Research AI trends")
        ```
    """
    
    def __init__(
        self,
        pattern: "BasePattern",
        checkpoint_store: CheckpointStore | None = None,
    ) -> None:
        """Initialize converter.
        
        Args:
            pattern: Pattern to convert
            checkpoint_store: Optional checkpoint storage
        """
        self.pattern = pattern
        self.checkpoint_store = checkpoint_store or InMemoryCheckpointStore()
    
    def build(self) -> Workflow:
        """Build workflow from pattern.
        
        Returns:
            Workflow representing the pattern
        """
        from multi_agent_base.core.patterns import (
            SingleAgentPattern,
            SupervisorPattern,
            SwarmPattern,
            PipelinePattern,
            ParallelPattern,
        )
        
        pattern_name = self.pattern.__class__.__name__
        
        if isinstance(self.pattern, SingleAgentPattern):
            return self._build_single_agent_workflow()
        elif isinstance(self.pattern, SupervisorPattern):
            return self._build_supervisor_workflow()
        elif isinstance(self.pattern, SwarmPattern):
            return self._build_swarm_workflow()
        elif isinstance(self.pattern, PipelinePattern):
            return self._build_pipeline_workflow()
        elif isinstance(self.pattern, ParallelPattern):
            return self._build_parallel_workflow()
        else:
            # Generic fallback
            return self._build_generic_workflow()
    
    def _build_single_agent_workflow(self) -> Workflow:
        """Build workflow for SingleAgentPattern."""
        builder = WorkflowBuilder(
            workflow_id=f"single-agent-{uuid.uuid4().hex[:8]}",
            name="Single Agent Workflow",
        )
        builder.with_checkpoint_store(self.checkpoint_store)
        
        agents = self.pattern.get_agents()
        if agents:
            agent_name, agent = next(iter(agents.items()))
            builder.add_agent_executor(agent_name, agent)
            builder.set_start(agent_name)
        
        return builder.build()
    
    def _build_supervisor_workflow(self) -> Workflow:
        """Build workflow for SupervisorPattern."""
        builder = WorkflowBuilder(
            workflow_id=f"supervisor-{uuid.uuid4().hex[:8]}",
            name="Supervisor Workflow",
        )
        builder.with_checkpoint_store(self.checkpoint_store)
        
        agents = self.pattern.get_agents()
        
        # Find supervisor (usually named "supervisor" or first agent)
        supervisor_name = "supervisor" if "supervisor" in agents else next(iter(agents.keys()), None)
        
        if supervisor_name:
            # Add all agents as executors
            for agent_name, agent in agents.items():
                builder.add_agent_executor(agent_name, agent)
            
            # Supervisor routes to workers
            for agent_name in agents:
                if agent_name != supervisor_name:
                    builder.add_edge(supervisor_name, agent_name)
                    builder.add_edge(agent_name, supervisor_name)
            
            builder.set_start(supervisor_name)
        
        return builder.build()
    
    def _build_swarm_workflow(self) -> Workflow:
        """Build workflow for SwarmPattern."""
        builder = WorkflowBuilder(
            workflow_id=f"swarm-{uuid.uuid4().hex[:8]}",
            name="Swarm Workflow",
        )
        builder.with_checkpoint_store(self.checkpoint_store)
        
        agents = self.pattern.get_agents()
        
        # Add all agents
        for agent_name, agent in agents.items():
            builder.add_agent_executor(agent_name, agent)
        
        # In swarm, any agent can hand off to any other
        for source in agents:
            for target in agents:
                if source != target:
                    builder.add_edge(source, target)
        
        # Set first agent as start
        if agents:
            builder.set_start(next(iter(agents.keys())))
        
        return builder.build()
    
    def _build_pipeline_workflow(self) -> Workflow:
        """Build workflow for PipelinePattern."""
        builder = SequentialWorkflowBuilder(
            workflow_id=f"pipeline-{uuid.uuid4().hex[:8]}",
            name="Pipeline Workflow",
        )
        builder.with_checkpoint_store(self.checkpoint_store)
        
        agents = self.pattern.get_agents()
        
        # Add agents in order (dict preserves insertion order in Python 3.7+)
        for agent_name, agent in agents.items():
            builder.add_agent_executor(agent_name, agent)
        
        return builder.build()
    
    def _build_parallel_workflow(self) -> Workflow:
        """Build workflow for ParallelPattern."""
        builder = ConcurrentWorkflowBuilder(
            workflow_id=f"parallel-{uuid.uuid4().hex[:8]}",
            name="Parallel Workflow",
        )
        builder.with_checkpoint_store(self.checkpoint_store)
        
        agents = self.pattern.get_agents()
        
        # Add all agents (will run in parallel)
        for agent_name, agent in agents.items():
            builder.add_agent_executor(agent_name, agent)
        
        return builder.build()
    
    def _build_generic_workflow(self) -> Workflow:
        """Build generic workflow for unknown patterns."""
        builder = WorkflowBuilder(
            workflow_id=f"pattern-{uuid.uuid4().hex[:8]}",
            name=f"{self.pattern.__class__.__name__} Workflow",
        )
        builder.with_checkpoint_store(self.checkpoint_store)
        
        agents = self.pattern.get_agents()
        
        for agent_name, agent in agents.items():
            builder.add_agent_executor(agent_name, agent)
        
        if agents:
            builder.set_start(next(iter(agents.keys())))
        
        return builder.build()


# Convenience aliases
AFWorkflow = Workflow
AFWorkflowBuilder = WorkflowBuilder
AFWorkflowResult = WorkflowResult
