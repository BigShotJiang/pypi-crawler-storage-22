"""
Cost tracking, optimization, and analysis module.

Provides comprehensive cost management including:
- Token usage tracking
- Budget management
- Cost-optimized model selection
- Cost analysis and reporting
"""

from multi_agent_base.cost.tracker import CostTracker, UsageRecord, CostSummary
from multi_agent_base.cost.budget import (
    BudgetManager,
    BudgetConfig,
    BudgetAlert,
    AlertSeverity,
    BudgetStatus,
    BudgetPeriod,
    BudgetLimit,
    BudgetAction,
    BudgetStorage,
    MemoryBudgetStorage,
)
from multi_agent_base.cost.optimization import (
    ModelSelector,
    ModelProfile,
    SelectionCriteria,
    SelectionResult,
    TaskComplexity,
    OptimizationGoal,
    CostEstimator,
    CostEstimate,
    DEFAULT_MODEL_PROFILES,
)
from multi_agent_base.cost.analysis import (
    CostAnalyzer,
    CostDataPoint,
    CostTrend,
    CostReport,
    CostAnomaly,
    ModelCostBreakdown,
    OperationCostBreakdown,
    OptimizationRecommendation,
    TimeGranularity,
    TrendDirection,
)

__all__ = [
    # Tracker
    "CostTracker",
    "UsageRecord",
    "CostSummary",
    # Budget
    "BudgetManager",
    "BudgetConfig",
    "BudgetAlert",
    "AlertSeverity",
    "BudgetStatus",
    "BudgetPeriod",
    "BudgetLimit",
    "BudgetAction",
    "BudgetStorage",
    "MemoryBudgetStorage",
    # Optimization
    "ModelSelector",
    "ModelProfile",
    "SelectionCriteria",
    "SelectionResult",
    "TaskComplexity",
    "OptimizationGoal",
    "CostEstimator",
    "CostEstimate",
    "DEFAULT_MODEL_PROFILES",
    # Analysis
    "CostAnalyzer",
    "CostDataPoint",
    "CostTrend",
    "CostReport",
    "CostAnomaly",
    "ModelCostBreakdown",
    "OperationCostBreakdown",
    "OptimizationRecommendation",
    "TimeGranularity",
    "TrendDirection",
]
