"""
Cost analysis and reporting.

Provides comprehensive cost analysis, trends,
and optimization recommendations.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from enum import Enum
from typing import Any


class TimeGranularity(str, Enum):
    """Time granularity for analysis."""
    
    HOURLY = "hourly"
    DAILY = "daily"
    WEEKLY = "weekly"
    MONTHLY = "monthly"


class TrendDirection(str, Enum):
    """Direction of a trend."""
    
    INCREASING = "increasing"
    DECREASING = "decreasing"
    STABLE = "stable"


@dataclass
class CostDataPoint:
    """A single cost data point.
    
    Attributes:
        timestamp: When the cost occurred
        cost: Cost amount in USD
        model: Model used
        tokens_input: Input tokens
        tokens_output: Output tokens
        operation: Operation type
    """
    
    timestamp: datetime
    cost: float
    model: str
    tokens_input: int = 0
    tokens_output: int = 0
    operation: str = "default"
    metadata: dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "timestamp": self.timestamp.isoformat(),
            "cost": self.cost,
            "model": self.model,
            "tokens_input": self.tokens_input,
            "tokens_output": self.tokens_output,
            "operation": self.operation,
            "metadata": self.metadata,
        }


@dataclass
class CostTrend:
    """Cost trend analysis.
    
    Attributes:
        direction: Trend direction
        change_percent: Percentage change
        period_start: Start of analysis period
        period_end: End of analysis period
        avg_daily_cost: Average daily cost
        projected_cost: Projected cost for next period
    """
    
    direction: TrendDirection
    change_percent: float
    period_start: datetime
    period_end: datetime
    avg_daily_cost: float
    projected_cost: float
    data_points: int = 0
    
    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "direction": self.direction.value,
            "change_percent": self.change_percent,
            "period_start": self.period_start.isoformat(),
            "period_end": self.period_end.isoformat(),
            "avg_daily_cost": self.avg_daily_cost,
            "projected_cost": self.projected_cost,
            "data_points": self.data_points,
        }


@dataclass
class ModelCostBreakdown:
    """Cost breakdown by model.
    
    Attributes:
        model: Model name
        total_cost: Total cost
        request_count: Number of requests
        avg_cost_per_request: Average cost per request
        total_input_tokens: Total input tokens
        total_output_tokens: Total output tokens
        percentage_of_total: Percentage of total costs
    """
    
    model: str
    total_cost: float
    request_count: int
    avg_cost_per_request: float
    total_input_tokens: int
    total_output_tokens: int
    percentage_of_total: float
    
    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "model": self.model,
            "total_cost": self.total_cost,
            "request_count": self.request_count,
            "avg_cost_per_request": self.avg_cost_per_request,
            "total_input_tokens": self.total_input_tokens,
            "total_output_tokens": self.total_output_tokens,
            "percentage_of_total": self.percentage_of_total,
        }


@dataclass
class OperationCostBreakdown:
    """Cost breakdown by operation.
    
    Attributes:
        operation: Operation name
        total_cost: Total cost
        request_count: Number of requests
        avg_cost_per_request: Average cost per request
        percentage_of_total: Percentage of total costs
    """
    
    operation: str
    total_cost: float
    request_count: int
    avg_cost_per_request: float
    percentage_of_total: float
    top_models: list[str] = field(default_factory=list)
    
    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "operation": self.operation,
            "total_cost": self.total_cost,
            "request_count": self.request_count,
            "avg_cost_per_request": self.avg_cost_per_request,
            "percentage_of_total": self.percentage_of_total,
            "top_models": self.top_models,
        }


@dataclass
class CostAnomaly:
    """Detected cost anomaly.
    
    Attributes:
        timestamp: When the anomaly occurred
        expected_cost: Expected cost based on baseline
        actual_cost: Actual cost
        deviation_percent: Percentage deviation
        severity: Anomaly severity
        description: Human-readable description
    """
    
    timestamp: datetime
    expected_cost: float
    actual_cost: float
    deviation_percent: float
    severity: str  # low, medium, high
    description: str
    model: str | None = None
    operation: str | None = None
    
    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "timestamp": self.timestamp.isoformat(),
            "expected_cost": self.expected_cost,
            "actual_cost": self.actual_cost,
            "deviation_percent": self.deviation_percent,
            "severity": self.severity,
            "description": self.description,
            "model": self.model,
            "operation": self.operation,
        }


@dataclass
class OptimizationRecommendation:
    """Cost optimization recommendation.
    
    Attributes:
        title: Recommendation title
        description: Detailed description
        potential_savings: Potential monthly savings
        implementation_effort: Implementation effort (low/medium/high)
        priority: Priority level (1-5, 1 being highest)
        category: Recommendation category
    """
    
    title: str
    description: str
    potential_savings: float
    implementation_effort: str  # low, medium, high
    priority: int
    category: str
    affected_models: list[str] = field(default_factory=list)
    affected_operations: list[str] = field(default_factory=list)
    
    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "title": self.title,
            "description": self.description,
            "potential_savings": self.potential_savings,
            "implementation_effort": self.implementation_effort,
            "priority": self.priority,
            "category": self.category,
            "affected_models": self.affected_models,
            "affected_operations": self.affected_operations,
        }


@dataclass
class CostReport:
    """Comprehensive cost report.
    
    Attributes:
        period_start: Report period start
        period_end: Report period end
        total_cost: Total cost in period
        total_requests: Total requests
        trend: Cost trend analysis
        model_breakdown: Breakdown by model
        operation_breakdown: Breakdown by operation
        anomalies: Detected anomalies
        recommendations: Optimization recommendations
    """
    
    period_start: datetime
    period_end: datetime
    total_cost: float
    total_requests: int
    trend: CostTrend | None = None
    model_breakdown: list[ModelCostBreakdown] = field(default_factory=list)
    operation_breakdown: list[OperationCostBreakdown] = field(default_factory=list)
    anomalies: list[CostAnomaly] = field(default_factory=list)
    recommendations: list[OptimizationRecommendation] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)
    
    @property
    def avg_cost_per_request(self) -> float:
        """Average cost per request."""
        if self.total_requests == 0:
            return 0.0
        return self.total_cost / self.total_requests
    
    @property
    def days_in_period(self) -> float:
        """Days in the report period."""
        delta = self.period_end - self.period_start
        return max(delta.days + delta.seconds / 86400, 1)
    
    @property
    def avg_daily_cost(self) -> float:
        """Average daily cost."""
        return self.total_cost / self.days_in_period
    
    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "period_start": self.period_start.isoformat(),
            "period_end": self.period_end.isoformat(),
            "total_cost": self.total_cost,
            "total_requests": self.total_requests,
            "avg_cost_per_request": self.avg_cost_per_request,
            "avg_daily_cost": self.avg_daily_cost,
            "days_in_period": self.days_in_period,
            "trend": self.trend.to_dict() if self.trend else None,
            "model_breakdown": [m.to_dict() for m in self.model_breakdown],
            "operation_breakdown": [o.to_dict() for o in self.operation_breakdown],
            "anomalies": [a.to_dict() for a in self.anomalies],
            "recommendations": [r.to_dict() for r in self.recommendations],
            "metadata": self.metadata,
        }
    
    def to_markdown(self) -> str:
        """Generate markdown report."""
        lines = [
            "# Cost Analysis Report",
            "",
            f"**Period:** {self.period_start.date()} to {self.period_end.date()}",
            "",
            "## Summary",
            "",
            f"- **Total Cost:** ${self.total_cost:.2f}",
            f"- **Total Requests:** {self.total_requests:,}",
            f"- **Average Cost per Request:** ${self.avg_cost_per_request:.4f}",
            f"- **Average Daily Cost:** ${self.avg_daily_cost:.2f}",
            "",
        ]
        
        if self.trend:
            lines.extend([
                "## Trend Analysis",
                "",
                f"- **Direction:** {self.trend.direction.value}",
                f"- **Change:** {self.trend.change_percent:+.1f}%",
                f"- **Projected Next Period:** ${self.trend.projected_cost:.2f}",
                "",
            ])
        
        if self.model_breakdown:
            lines.extend([
                "## Cost by Model",
                "",
                "| Model | Cost | Requests | Avg/Request | % of Total |",
                "|-------|------|----------|-------------|------------|",
            ])
            for m in self.model_breakdown:
                lines.append(
                    f"| {m.model} | ${m.total_cost:.2f} | {m.request_count} | "
                    f"${m.avg_cost_per_request:.4f} | {m.percentage_of_total:.1f}% |"
                )
            lines.append("")
        
        if self.operation_breakdown:
            lines.extend([
                "## Cost by Operation",
                "",
                "| Operation | Cost | Requests | Avg/Request | % of Total |",
                "|-----------|------|----------|-------------|------------|",
            ])
            for o in self.operation_breakdown:
                lines.append(
                    f"| {o.operation} | ${o.total_cost:.2f} | {o.request_count} | "
                    f"${o.avg_cost_per_request:.4f} | {o.percentage_of_total:.1f}% |"
                )
            lines.append("")
        
        if self.anomalies:
            lines.extend([
                "## Detected Anomalies",
                "",
            ])
            for a in self.anomalies:
                lines.append(f"- **{a.severity.upper()}:** {a.description}")
            lines.append("")
        
        if self.recommendations:
            lines.extend([
                "## Recommendations",
                "",
            ])
            for i, r in enumerate(self.recommendations, 1):
                lines.extend([
                    f"### {i}. {r.title}",
                    "",
                    r.description,
                    "",
                    f"- **Potential Savings:** ${r.potential_savings:.2f}/month",
                    f"- **Effort:** {r.implementation_effort}",
                    f"- **Priority:** {r.priority}/5",
                    "",
                ])
        
        return "\n".join(lines)


class CostAnalyzer:
    """Analyze cost data and generate insights.
    
    Example:
        ```python
        analyzer = CostAnalyzer()
        
        # Add cost data
        analyzer.add_data_point(CostDataPoint(
            timestamp=datetime.now(),
            cost=0.05,
            model="gpt-4o",
            tokens_input=1000,
            tokens_output=500,
        ))
        
        # Generate report
        report = analyzer.generate_report()
        print(report.to_markdown())
        ```
    """
    
    def __init__(
        self,
        anomaly_threshold: float = 2.0,  # Standard deviations
    ) -> None:
        """Initialize cost analyzer.
        
        Args:
            anomaly_threshold: Threshold for anomaly detection
        """
        self.data_points: list[CostDataPoint] = []
        self.anomaly_threshold = anomaly_threshold
    
    def add_data_point(self, point: CostDataPoint) -> None:
        """Add a cost data point."""
        self.data_points.append(point)
    
    def add_data_points(self, points: list[CostDataPoint]) -> None:
        """Add multiple cost data points."""
        self.data_points.extend(points)
    
    def clear(self) -> None:
        """Clear all data points."""
        self.data_points.clear()
    
    def _filter_by_period(
        self,
        start: datetime | None = None,
        end: datetime | None = None,
    ) -> list[CostDataPoint]:
        """Filter data points by time period."""
        filtered = self.data_points
        
        if start:
            filtered = [p for p in filtered if p.timestamp >= start]
        if end:
            filtered = [p for p in filtered if p.timestamp <= end]
        
        return filtered
    
    def calculate_total(
        self,
        start: datetime | None = None,
        end: datetime | None = None,
        model: str | None = None,
        operation: str | None = None,
    ) -> float:
        """Calculate total cost for a period.
        
        Args:
            start: Period start
            end: Period end
            model: Filter by model
            operation: Filter by operation
            
        Returns:
            Total cost
        """
        points = self._filter_by_period(start, end)
        
        if model:
            points = [p for p in points if p.model == model]
        if operation:
            points = [p for p in points if p.operation == operation]
        
        return sum(p.cost for p in points)
    
    def analyze_trend(
        self,
        start: datetime | None = None,
        end: datetime | None = None,
    ) -> CostTrend | None:
        """Analyze cost trend.
        
        Args:
            start: Period start
            end: Period end
            
        Returns:
            Cost trend analysis
        """
        points = self._filter_by_period(start, end)
        
        if not points:
            return None
        
        # Sort by timestamp
        points = sorted(points, key=lambda p: p.timestamp)
        
        # Get period bounds
        period_start = points[0].timestamp
        period_end = points[-1].timestamp
        
        # Calculate daily costs
        daily_costs: dict[str, float] = {}
        for point in points:
            day_key = point.timestamp.date().isoformat()
            daily_costs[day_key] = daily_costs.get(day_key, 0) + point.cost
        
        if len(daily_costs) < 2:
            avg_cost = sum(daily_costs.values()) / len(daily_costs) if daily_costs else 0
            return CostTrend(
                direction=TrendDirection.STABLE,
                change_percent=0.0,
                period_start=period_start,
                period_end=period_end,
                avg_daily_cost=avg_cost,
                projected_cost=avg_cost * 30,
                data_points=len(points),
            )
        
        # Calculate trend using simple linear regression
        sorted_days = sorted(daily_costs.keys())
        costs = [daily_costs[d] for d in sorted_days]
        
        n = len(costs)
        x = list(range(n))
        y = costs
        
        # Calculate slope
        x_mean = sum(x) / n
        y_mean = sum(y) / n
        
        numerator = sum((x[i] - x_mean) * (y[i] - y_mean) for i in range(n))
        denominator = sum((x[i] - x_mean) ** 2 for i in range(n))
        
        slope = numerator / denominator if denominator != 0 else 0
        
        # Determine direction
        first_half_avg = sum(costs[:n//2]) / (n//2) if n >= 2 else costs[0]
        second_half_avg = sum(costs[n//2:]) / (n - n//2) if n >= 2 else costs[-1]
        
        if first_half_avg == 0:
            change_percent = 100.0 if second_half_avg > 0 else 0.0
        else:
            change_percent = ((second_half_avg - first_half_avg) / first_half_avg) * 100
        
        if change_percent > 10:
            direction = TrendDirection.INCREASING
        elif change_percent < -10:
            direction = TrendDirection.DECREASING
        else:
            direction = TrendDirection.STABLE
        
        avg_daily = sum(costs) / n
        projected = avg_daily * 30 * (1 + change_percent / 100)
        
        return CostTrend(
            direction=direction,
            change_percent=change_percent,
            period_start=period_start,
            period_end=period_end,
            avg_daily_cost=avg_daily,
            projected_cost=projected,
            data_points=len(points),
        )
    
    def breakdown_by_model(
        self,
        start: datetime | None = None,
        end: datetime | None = None,
    ) -> list[ModelCostBreakdown]:
        """Get cost breakdown by model.
        
        Args:
            start: Period start
            end: Period end
            
        Returns:
            List of model cost breakdowns
        """
        points = self._filter_by_period(start, end)
        
        if not points:
            return []
        
        # Aggregate by model
        model_data: dict[str, dict[str, Any]] = {}
        
        for point in points:
            if point.model not in model_data:
                model_data[point.model] = {
                    "cost": 0.0,
                    "count": 0,
                    "input_tokens": 0,
                    "output_tokens": 0,
                }
            
            model_data[point.model]["cost"] += point.cost
            model_data[point.model]["count"] += 1
            model_data[point.model]["input_tokens"] += point.tokens_input
            model_data[point.model]["output_tokens"] += point.tokens_output
        
        total_cost = sum(d["cost"] for d in model_data.values())
        
        breakdowns = []
        for model, data in model_data.items():
            breakdowns.append(ModelCostBreakdown(
                model=model,
                total_cost=data["cost"],
                request_count=data["count"],
                avg_cost_per_request=data["cost"] / data["count"] if data["count"] > 0 else 0,
                total_input_tokens=data["input_tokens"],
                total_output_tokens=data["output_tokens"],
                percentage_of_total=(data["cost"] / total_cost * 100) if total_cost > 0 else 0,
            ))
        
        # Sort by cost descending
        breakdowns.sort(key=lambda x: x.total_cost, reverse=True)
        
        return breakdowns
    
    def breakdown_by_operation(
        self,
        start: datetime | None = None,
        end: datetime | None = None,
    ) -> list[OperationCostBreakdown]:
        """Get cost breakdown by operation.
        
        Args:
            start: Period start
            end: Period end
            
        Returns:
            List of operation cost breakdowns
        """
        points = self._filter_by_period(start, end)
        
        if not points:
            return []
        
        # Aggregate by operation
        op_data: dict[str, dict[str, Any]] = {}
        
        for point in points:
            if point.operation not in op_data:
                op_data[point.operation] = {
                    "cost": 0.0,
                    "count": 0,
                    "models": {},
                }
            
            op_data[point.operation]["cost"] += point.cost
            op_data[point.operation]["count"] += 1
            op_data[point.operation]["models"][point.model] = (
                op_data[point.operation]["models"].get(point.model, 0) + 1
            )
        
        total_cost = sum(d["cost"] for d in op_data.values())
        
        breakdowns = []
        for operation, data in op_data.items():
            # Get top models by request count
            sorted_models = sorted(
                data["models"].items(),
                key=lambda x: x[1],
                reverse=True
            )
            top_models = [m[0] for m in sorted_models[:3]]
            
            breakdowns.append(OperationCostBreakdown(
                operation=operation,
                total_cost=data["cost"],
                request_count=data["count"],
                avg_cost_per_request=data["cost"] / data["count"] if data["count"] > 0 else 0,
                percentage_of_total=(data["cost"] / total_cost * 100) if total_cost > 0 else 0,
                top_models=top_models,
            ))
        
        # Sort by cost descending
        breakdowns.sort(key=lambda x: x.total_cost, reverse=True)
        
        return breakdowns
    
    def detect_anomalies(
        self,
        start: datetime | None = None,
        end: datetime | None = None,
    ) -> list[CostAnomaly]:
        """Detect cost anomalies.
        
        Args:
            start: Period start
            end: Period end
            
        Returns:
            List of detected anomalies
        """
        points = self._filter_by_period(start, end)
        
        if len(points) < 5:
            return []
        
        # Calculate baseline statistics
        costs = [p.cost for p in points]
        mean_cost = sum(costs) / len(costs)
        variance = sum((c - mean_cost) ** 2 for c in costs) / len(costs)
        std_dev = variance ** 0.5
        
        if std_dev == 0:
            return []
        
        anomalies = []
        
        for point in points:
            z_score = abs(point.cost - mean_cost) / std_dev
            
            if z_score >= self.anomaly_threshold:
                deviation_percent = ((point.cost - mean_cost) / mean_cost) * 100
                
                # Determine severity
                if z_score >= 3:
                    severity = "high"
                elif z_score >= 2.5:
                    severity = "medium"
                else:
                    severity = "low"
                
                direction = "higher" if point.cost > mean_cost else "lower"
                description = (
                    f"Cost of ${point.cost:.4f} is {abs(deviation_percent):.1f}% "
                    f"{direction} than average (${mean_cost:.4f})"
                )
                
                anomalies.append(CostAnomaly(
                    timestamp=point.timestamp,
                    expected_cost=mean_cost,
                    actual_cost=point.cost,
                    deviation_percent=deviation_percent,
                    severity=severity,
                    description=description,
                    model=point.model,
                    operation=point.operation,
                ))
        
        # Sort by severity and deviation
        severity_order = {"high": 0, "medium": 1, "low": 2}
        anomalies.sort(key=lambda a: (severity_order[a.severity], -abs(a.deviation_percent)))
        
        return anomalies
    
    def generate_recommendations(
        self,
        model_breakdown: list[ModelCostBreakdown],
        operation_breakdown: list[OperationCostBreakdown],
    ) -> list[OptimizationRecommendation]:
        """Generate optimization recommendations.
        
        Args:
            model_breakdown: Cost breakdown by model
            operation_breakdown: Cost breakdown by operation
            
        Returns:
            List of recommendations
        """
        recommendations = []
        
        # Check for expensive models that could be downgraded
        expensive_models = [
            m for m in model_breakdown
            if m.avg_cost_per_request > 0.05 and m.percentage_of_total > 20
        ]
        
        for model in expensive_models:
            recommendations.append(OptimizationRecommendation(
                title=f"Consider downgrading {model.model}",
                description=(
                    f"{model.model} accounts for {model.percentage_of_total:.1f}% "
                    f"of costs with ${model.avg_cost_per_request:.4f} per request. "
                    f"Consider using a smaller model for simpler tasks."
                ),
                potential_savings=model.total_cost * 0.4,  # Estimate 40% savings
                implementation_effort="medium",
                priority=2,
                category="model_selection",
                affected_models=[model.model],
            ))
        
        # Check for high-frequency operations
        high_freq_ops = [
            o for o in operation_breakdown
            if o.request_count > 100 and o.percentage_of_total > 15
        ]
        
        for op in high_freq_ops:
            recommendations.append(OptimizationRecommendation(
                title=f"Optimize '{op.operation}' operation",
                description=(
                    f"The '{op.operation}' operation has {op.request_count} requests "
                    f"costing ${op.total_cost:.2f}. Consider caching responses or "
                    f"batching similar requests."
                ),
                potential_savings=op.total_cost * 0.25,  # Estimate 25% savings
                implementation_effort="high",
                priority=3,
                category="operation_optimization",
                affected_operations=[op.operation],
            ))
        
        # Check for caching opportunities
        if len(self.data_points) > 50:
            recommendations.append(OptimizationRecommendation(
                title="Implement response caching",
                description=(
                    "With significant request volume, implementing a response cache "
                    "for similar queries could reduce redundant API calls."
                ),
                potential_savings=sum(m.total_cost for m in model_breakdown) * 0.15,
                implementation_effort="high",
                priority=4,
                category="caching",
            ))
        
        # Sort by priority
        recommendations.sort(key=lambda r: r.priority)
        
        return recommendations
    
    def generate_report(
        self,
        start: datetime | None = None,
        end: datetime | None = None,
    ) -> CostReport:
        """Generate a comprehensive cost report.
        
        Args:
            start: Report period start
            end: Report period end
            
        Returns:
            Complete cost report
        """
        points = self._filter_by_period(start, end)
        
        if not points:
            now = datetime.now(timezone.utc)
            return CostReport(
                period_start=start or now,
                period_end=end or now,
                total_cost=0.0,
                total_requests=0,
            )
        
        # Calculate period
        sorted_points = sorted(points, key=lambda p: p.timestamp)
        period_start = start or sorted_points[0].timestamp
        period_end = end or sorted_points[-1].timestamp
        
        # Calculate totals
        total_cost = sum(p.cost for p in points)
        total_requests = len(points)
        
        # Generate analyses
        trend = self.analyze_trend(period_start, period_end)
        model_breakdown = self.breakdown_by_model(period_start, period_end)
        operation_breakdown = self.breakdown_by_operation(period_start, period_end)
        anomalies = self.detect_anomalies(period_start, period_end)
        recommendations = self.generate_recommendations(model_breakdown, operation_breakdown)
        
        return CostReport(
            period_start=period_start,
            period_end=period_end,
            total_cost=total_cost,
            total_requests=total_requests,
            trend=trend,
            model_breakdown=model_breakdown,
            operation_breakdown=operation_breakdown,
            anomalies=anomalies,
            recommendations=recommendations,
        )
    
    def get_time_series(
        self,
        granularity: TimeGranularity = TimeGranularity.DAILY,
        start: datetime | None = None,
        end: datetime | None = None,
    ) -> list[dict[str, Any]]:
        """Get time series data for visualization.
        
        Args:
            granularity: Time granularity
            start: Period start
            end: Period end
            
        Returns:
            List of time series data points
        """
        points = self._filter_by_period(start, end)
        
        if not points:
            return []
        
        # Group by time period
        grouped: dict[str, dict[str, Any]] = {}
        
        for point in points:
            if granularity == TimeGranularity.HOURLY:
                key = point.timestamp.strftime("%Y-%m-%d %H:00")
            elif granularity == TimeGranularity.DAILY:
                key = point.timestamp.strftime("%Y-%m-%d")
            elif granularity == TimeGranularity.WEEKLY:
                # Get start of week
                start_of_week = point.timestamp - timedelta(days=point.timestamp.weekday())
                key = start_of_week.strftime("%Y-%m-%d")
            else:  # MONTHLY
                key = point.timestamp.strftime("%Y-%m")
            
            if key not in grouped:
                grouped[key] = {"cost": 0.0, "requests": 0}
            
            grouped[key]["cost"] += point.cost
            grouped[key]["requests"] += 1
        
        # Convert to list
        result = [
            {
                "period": period,
                "cost": data["cost"],
                "requests": data["requests"],
            }
            for period, data in sorted(grouped.items())
        ]
        
        return result
