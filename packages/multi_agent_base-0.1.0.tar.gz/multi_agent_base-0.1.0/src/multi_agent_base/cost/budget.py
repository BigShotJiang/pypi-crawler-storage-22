"""
Budget management for cost control.

Provides budget limits, alerts, and automatic controls
to prevent cost overruns in AI agent operations.
"""

from __future__ import annotations

import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime, timezone, timedelta
from enum import Enum
from typing import Any, Callable
from collections import defaultdict


class BudgetPeriod(str, Enum):
    """Budget time periods."""
    
    HOURLY = "hourly"
    DAILY = "daily"
    WEEKLY = "weekly"
    MONTHLY = "monthly"
    TOTAL = "total"  # No time limit


class BudgetAction(str, Enum):
    """Actions to take when budget limits are reached."""
    
    ALLOW = "allow"  # Allow operation
    WARN = "warn"    # Warn but allow
    BLOCK = "block"  # Block operation
    DOWNGRADE = "downgrade"  # Switch to cheaper model


class AlertSeverity(str, Enum):
    """Severity levels for budget alerts."""
    
    INFO = "info"
    WARNING = "warning"
    CRITICAL = "critical"


@dataclass
class BudgetLimit:
    """A budget limit configuration.
    
    Attributes:
        name: Limit name
        amount: Maximum amount in USD
        period: Time period for the limit
        action: Action when limit is reached
        alert_thresholds: Percentages at which to alert
        scope: What the limit applies to (agent, session, global)
    """
    
    name: str
    amount: float
    period: BudgetPeriod
    action: BudgetAction = BudgetAction.BLOCK
    alert_thresholds: list[float] = field(default_factory=lambda: [0.5, 0.75, 0.9])
    scope: str = "global"  # global, agent:<name>, session:<id>
    metadata: dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "name": self.name,
            "amount": self.amount,
            "period": self.period.value,
            "action": self.action.value,
            "alert_thresholds": self.alert_thresholds,
            "scope": self.scope,
            "metadata": self.metadata,
        }


@dataclass
class BudgetAlert:
    """A budget alert notification.
    
    Attributes:
        limit_name: Name of the limit
        severity: Alert severity
        message: Alert message
        current_usage: Current usage amount
        limit_amount: Limit amount
        percentage: Percentage of limit used
        timestamp: When alert was triggered
    """
    
    limit_name: str
    severity: AlertSeverity
    message: str
    current_usage: float
    limit_amount: float
    percentage: float
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    
    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "limit_name": self.limit_name,
            "severity": self.severity.value,
            "message": self.message,
            "current_usage": self.current_usage,
            "limit_amount": self.limit_amount,
            "percentage": self.percentage,
            "timestamp": self.timestamp,
        }


@dataclass
class BudgetStatus:
    """Current status of budget limits.
    
    Attributes:
        limit_name: Name of the limit
        current_usage: Current usage amount
        limit_amount: Limit amount
        remaining: Remaining budget
        percentage_used: Percentage of limit used
        period_start: Start of current period
        period_end: End of current period
        is_exceeded: Whether limit is exceeded
    """
    
    limit_name: str
    current_usage: float
    limit_amount: float
    remaining: float
    percentage_used: float
    period_start: str
    period_end: str
    is_exceeded: bool
    action: BudgetAction = BudgetAction.ALLOW
    
    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "limit_name": self.limit_name,
            "current_usage": self.current_usage,
            "limit_amount": self.limit_amount,
            "remaining": self.remaining,
            "percentage_used": self.percentage_used,
            "period_start": self.period_start,
            "period_end": self.period_end,
            "is_exceeded": self.is_exceeded,
            "action": self.action.value,
        }


class BudgetStorage(ABC):
    """Abstract storage for budget data."""
    
    @abstractmethod
    def record_usage(
        self,
        scope: str,
        amount: float,
        timestamp: datetime,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Record a usage event."""
        pass
    
    @abstractmethod
    def get_usage(
        self,
        scope: str,
        start_time: datetime,
        end_time: datetime,
    ) -> float:
        """Get total usage for a scope and time range."""
        pass
    
    @abstractmethod
    def clear(self, scope: str | None = None) -> None:
        """Clear usage data."""
        pass


class MemoryBudgetStorage(BudgetStorage):
    """In-memory budget storage."""
    
    def __init__(self) -> None:
        self.records: list[dict[str, Any]] = []
    
    def record_usage(
        self,
        scope: str,
        amount: float,
        timestamp: datetime,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Record a usage event."""
        self.records.append({
            "scope": scope,
            "amount": amount,
            "timestamp": timestamp,
            "metadata": metadata or {},
        })
    
    def get_usage(
        self,
        scope: str,
        start_time: datetime,
        end_time: datetime,
    ) -> float:
        """Get total usage for a scope and time range."""
        total = 0.0
        for record in self.records:
            if record["scope"] != scope:
                continue
            if start_time <= record["timestamp"] <= end_time:
                total += record["amount"]
        return total
    
    def clear(self, scope: str | None = None) -> None:
        """Clear usage data."""
        if scope is None:
            self.records.clear()
        else:
            self.records = [r for r in self.records if r["scope"] != scope]


class BudgetManager:
    """Manages budget limits and tracks usage.
    
    Provides budget management with configurable limits,
    alerts, and automatic actions when limits are reached.
    
    Example:
        ```python
        manager = BudgetManager()
        
        # Add budget limits
        manager.add_limit(BudgetLimit(
            name="daily_limit",
            amount=10.0,
            period=BudgetPeriod.DAILY,
            action=BudgetAction.BLOCK,
        ))
        
        # Check before operation
        result = manager.check_budget("global", estimated_cost=0.50)
        if result.action == BudgetAction.BLOCK:
            raise Exception("Budget exceeded")
        
        # Record actual usage
        manager.record_usage("global", 0.45)
        ```
    """
    
    def __init__(
        self,
        storage: BudgetStorage | None = None,
        alert_handlers: list[Callable[[BudgetAlert], None]] | None = None,
    ) -> None:
        """Initialize budget manager.
        
        Args:
            storage: Storage backend for usage data
            alert_handlers: Handlers for budget alerts
        """
        self.storage = storage or MemoryBudgetStorage()
        self.limits: dict[str, BudgetLimit] = {}
        self.alert_handlers = alert_handlers or []
        self._triggered_alerts: set[tuple[str, float]] = set()
    
    def add_limit(self, limit: BudgetLimit) -> None:
        """Add a budget limit."""
        self.limits[limit.name] = limit
    
    def remove_limit(self, name: str) -> bool:
        """Remove a budget limit."""
        if name in self.limits:
            del self.limits[name]
            return True
        return False
    
    def get_limit(self, name: str) -> BudgetLimit | None:
        """Get a budget limit by name."""
        return self.limits.get(name)
    
    def add_alert_handler(self, handler: Callable[[BudgetAlert], None]) -> None:
        """Add an alert handler."""
        self.alert_handlers.append(handler)
    
    def _get_period_bounds(
        self,
        period: BudgetPeriod,
        reference: datetime | None = None,
    ) -> tuple[datetime, datetime]:
        """Get start and end times for a period."""
        now = reference or datetime.now(timezone.utc)
        
        if period == BudgetPeriod.HOURLY:
            start = now.replace(minute=0, second=0, microsecond=0)
            end = start + timedelta(hours=1)
        elif period == BudgetPeriod.DAILY:
            start = now.replace(hour=0, minute=0, second=0, microsecond=0)
            end = start + timedelta(days=1)
        elif period == BudgetPeriod.WEEKLY:
            start = now - timedelta(days=now.weekday())
            start = start.replace(hour=0, minute=0, second=0, microsecond=0)
            end = start + timedelta(weeks=1)
        elif period == BudgetPeriod.MONTHLY:
            start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
            if now.month == 12:
                end = start.replace(year=now.year + 1, month=1)
            else:
                end = start.replace(month=now.month + 1)
        else:  # TOTAL
            start = datetime.min.replace(tzinfo=timezone.utc)
            end = datetime.max.replace(tzinfo=timezone.utc)
        
        return start, end
    
    def _check_alerts(
        self,
        limit: BudgetLimit,
        current_usage: float,
    ) -> list[BudgetAlert]:
        """Check and trigger alerts based on thresholds."""
        alerts = []
        percentage = (current_usage / limit.amount) * 100 if limit.amount > 0 else 0
        
        for threshold in sorted(limit.alert_thresholds):
            threshold_pct = threshold * 100
            
            # Check if this threshold is reached and not already triggered
            alert_key = (limit.name, threshold)
            if percentage >= threshold_pct and alert_key not in self._triggered_alerts:
                self._triggered_alerts.add(alert_key)
                
                # Determine severity
                if threshold >= 0.9:
                    severity = AlertSeverity.CRITICAL
                elif threshold >= 0.75:
                    severity = AlertSeverity.WARNING
                else:
                    severity = AlertSeverity.INFO
                
                alert = BudgetAlert(
                    limit_name=limit.name,
                    severity=severity,
                    message=f"Budget limit '{limit.name}' is at {percentage:.1f}% "
                            f"(${current_usage:.2f} of ${limit.amount:.2f})",
                    current_usage=current_usage,
                    limit_amount=limit.amount,
                    percentage=percentage,
                )
                alerts.append(alert)
                
                # Call handlers
                for handler in self.alert_handlers:
                    try:
                        handler(alert)
                    except Exception:
                        pass
        
        return alerts
    
    def record_usage(
        self,
        scope: str,
        amount: float,
        metadata: dict[str, Any] | None = None,
    ) -> list[BudgetAlert]:
        """Record usage and check for alerts.
        
        Args:
            scope: Usage scope
            amount: Usage amount in USD
            metadata: Additional metadata
            
        Returns:
            List of triggered alerts
        """
        now = datetime.now(timezone.utc)
        self.storage.record_usage(scope, amount, now, metadata)
        
        # Check all applicable limits
        all_alerts = []
        for limit in self.limits.values():
            if self._limit_applies_to_scope(limit, scope):
                start, end = self._get_period_bounds(limit.period)
                current_usage = self.storage.get_usage(scope, start, end)
                alerts = self._check_alerts(limit, current_usage)
                all_alerts.extend(alerts)
        
        return all_alerts
    
    def _limit_applies_to_scope(self, limit: BudgetLimit, scope: str) -> bool:
        """Check if a limit applies to a scope."""
        if limit.scope == "global":
            return True
        if limit.scope.startswith("agent:"):
            agent_name = limit.scope[6:]
            return scope == f"agent:{agent_name}"
        if limit.scope.startswith("session:"):
            session_id = limit.scope[8:]
            return scope == f"session:{session_id}"
        return limit.scope == scope
    
    def check_budget(
        self,
        scope: str,
        estimated_cost: float = 0.0,
    ) -> BudgetStatus:
        """Check budget status before an operation.
        
        Args:
            scope: Usage scope
            estimated_cost: Estimated cost of upcoming operation
            
        Returns:
            Budget status with recommended action
        """
        now = datetime.now(timezone.utc)
        
        # Find the most restrictive applicable limit
        most_restrictive: BudgetStatus | None = None
        
        for limit in self.limits.values():
            if not self._limit_applies_to_scope(limit, scope):
                continue
            
            start, end = self._get_period_bounds(limit.period)
            current_usage = self.storage.get_usage(scope, start, end)
            projected_usage = current_usage + estimated_cost
            
            remaining = max(0.0, limit.amount - current_usage)
            percentage = (current_usage / limit.amount) * 100 if limit.amount > 0 else 0
            is_exceeded = projected_usage > limit.amount
            
            status = BudgetStatus(
                limit_name=limit.name,
                current_usage=current_usage,
                limit_amount=limit.amount,
                remaining=remaining,
                percentage_used=percentage,
                period_start=start.isoformat(),
                period_end=end.isoformat(),
                is_exceeded=is_exceeded,
                action=limit.action if is_exceeded else BudgetAction.ALLOW,
            )
            
            # Keep the most restrictive status
            if most_restrictive is None or (
                is_exceeded and 
                (not most_restrictive.is_exceeded or 
                 status.remaining < most_restrictive.remaining)
            ):
                most_restrictive = status
        
        if most_restrictive is None:
            # No limits configured
            return BudgetStatus(
                limit_name="none",
                current_usage=0.0,
                limit_amount=float("inf"),
                remaining=float("inf"),
                percentage_used=0.0,
                period_start=now.isoformat(),
                period_end=now.isoformat(),
                is_exceeded=False,
                action=BudgetAction.ALLOW,
            )
        
        return most_restrictive
    
    def get_all_status(self, scope: str = "global") -> list[BudgetStatus]:
        """Get status of all limits for a scope."""
        now = datetime.now(timezone.utc)
        statuses = []
        
        for limit in self.limits.values():
            if not self._limit_applies_to_scope(limit, scope):
                continue
            
            start, end = self._get_period_bounds(limit.period)
            current_usage = self.storage.get_usage(scope, start, end)
            
            remaining = max(0.0, limit.amount - current_usage)
            percentage = (current_usage / limit.amount) * 100 if limit.amount > 0 else 0
            is_exceeded = current_usage > limit.amount
            
            statuses.append(BudgetStatus(
                limit_name=limit.name,
                current_usage=current_usage,
                limit_amount=limit.amount,
                remaining=remaining,
                percentage_used=percentage,
                period_start=start.isoformat(),
                period_end=end.isoformat(),
                is_exceeded=is_exceeded,
                action=limit.action if is_exceeded else BudgetAction.ALLOW,
            ))
        
        return statuses
    
    def reset_period(self, limit_name: str) -> bool:
        """Reset alerts for a limit (for new period)."""
        self._triggered_alerts = {
            (name, threshold)
            for name, threshold in self._triggered_alerts
            if name != limit_name
        }
        return limit_name in self.limits


@dataclass
class BudgetConfig:
    """Configuration for budget management."""
    
    limits: list[dict[str, Any]] = field(default_factory=list)
    default_action: BudgetAction = BudgetAction.WARN
    alert_email: str | None = None
    alert_webhook: str | None = None
    
    def create_manager(self) -> BudgetManager:
        """Create a budget manager from config."""
        manager = BudgetManager()
        
        for limit_dict in self.limits:
            limit = BudgetLimit(
                name=limit_dict["name"],
                amount=limit_dict["amount"],
                period=BudgetPeriod(limit_dict.get("period", "daily")),
                action=BudgetAction(limit_dict.get("action", self.default_action.value)),
                alert_thresholds=limit_dict.get("alert_thresholds", [0.5, 0.75, 0.9]),
                scope=limit_dict.get("scope", "global"),
            )
            manager.add_limit(limit)
        
        return manager
