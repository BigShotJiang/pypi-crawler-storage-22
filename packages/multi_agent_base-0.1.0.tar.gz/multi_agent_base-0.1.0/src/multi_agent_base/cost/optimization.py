"""
Cost-optimized model selection.

Provides intelligent model selection based on cost,
quality requirements, and task complexity.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any


class TaskComplexity(str, Enum):
    """Task complexity levels."""
    
    SIMPLE = "simple"      # Simple queries, classification
    MODERATE = "moderate"  # General conversation, summarization
    COMPLEX = "complex"    # Analysis, reasoning, coding
    EXPERT = "expert"      # Research, creative writing, complex coding


class OptimizationGoal(str, Enum):
    """Optimization goals for model selection."""
    
    COST = "cost"               # Minimize cost
    QUALITY = "quality"         # Maximize quality
    BALANCED = "balanced"       # Balance cost and quality
    LATENCY = "latency"         # Minimize latency
    THROUGHPUT = "throughput"   # Maximize throughput


@dataclass
class ModelProfile:
    """Profile of a model's capabilities and costs.
    
    Attributes:
        name: Model name
        provider: Provider name
        input_cost: Cost per 1M input tokens
        output_cost: Cost per 1M output tokens
        quality_score: Quality score (0-100)
        latency_ms: Typical latency in ms
        max_tokens: Maximum context length
        capabilities: List of capabilities
    """
    
    name: str
    provider: str
    input_cost: float  # per 1M tokens
    output_cost: float  # per 1M tokens
    quality_score: float  # 0-100
    latency_ms: int
    max_tokens: int
    capabilities: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)
    
    @property
    def avg_cost(self) -> float:
        """Average cost per 1M tokens."""
        return (self.input_cost + self.output_cost) / 2
    
    @property
    def cost_efficiency(self) -> float:
        """Quality per dollar (higher is better)."""
        if self.avg_cost == 0:
            return float("inf")
        return self.quality_score / self.avg_cost
    
    def estimate_cost(self, input_tokens: int, output_tokens: int) -> float:
        """Estimate cost for a request."""
        input_cost = (input_tokens / 1_000_000) * self.input_cost
        output_cost = (output_tokens / 1_000_000) * self.output_cost
        return input_cost + output_cost
    
    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "name": self.name,
            "provider": self.provider,
            "input_cost": self.input_cost,
            "output_cost": self.output_cost,
            "quality_score": self.quality_score,
            "latency_ms": self.latency_ms,
            "max_tokens": self.max_tokens,
            "capabilities": self.capabilities,
            "avg_cost": self.avg_cost,
            "cost_efficiency": self.cost_efficiency,
            "metadata": self.metadata,
        }


# Built-in model profiles (prices as of 2024)
DEFAULT_MODEL_PROFILES = [
    ModelProfile(
        name="gpt-4o",
        provider="openai",
        input_cost=2.50,
        output_cost=10.00,
        quality_score=95,
        latency_ms=500,
        max_tokens=128000,
        capabilities=["vision", "function_calling", "json_mode"],
    ),
    ModelProfile(
        name="gpt-4o-mini",
        provider="openai",
        input_cost=0.15,
        output_cost=0.60,
        quality_score=82,
        latency_ms=300,
        max_tokens=128000,
        capabilities=["vision", "function_calling", "json_mode"],
    ),
    ModelProfile(
        name="gpt-4-turbo",
        provider="openai",
        input_cost=10.00,
        output_cost=30.00,
        quality_score=90,
        latency_ms=800,
        max_tokens=128000,
        capabilities=["vision", "function_calling", "json_mode"],
    ),
    ModelProfile(
        name="gpt-3.5-turbo",
        provider="openai",
        input_cost=0.50,
        output_cost=1.50,
        quality_score=70,
        latency_ms=200,
        max_tokens=16385,
        capabilities=["function_calling", "json_mode"],
    ),
    ModelProfile(
        name="claude-3-5-sonnet-20241022",
        provider="anthropic",
        input_cost=3.00,
        output_cost=15.00,
        quality_score=94,
        latency_ms=600,
        max_tokens=200000,
        capabilities=["vision", "function_calling"],
    ),
    ModelProfile(
        name="claude-3-5-haiku-20241022",
        provider="anthropic",
        input_cost=0.25,
        output_cost=1.25,
        quality_score=78,
        latency_ms=250,
        max_tokens=200000,
        capabilities=["vision", "function_calling"],
    ),
    ModelProfile(
        name="claude-3-opus-20240229",
        provider="anthropic",
        input_cost=15.00,
        output_cost=75.00,
        quality_score=97,
        latency_ms=1000,
        max_tokens=200000,
        capabilities=["vision", "function_calling"],
    ),
    ModelProfile(
        name="gemini-1.5-pro",
        provider="google",
        input_cost=1.25,
        output_cost=5.00,
        quality_score=88,
        latency_ms=400,
        max_tokens=2000000,
        capabilities=["vision", "function_calling", "json_mode"],
    ),
    ModelProfile(
        name="gemini-1.5-flash",
        provider="google",
        input_cost=0.075,
        output_cost=0.30,
        quality_score=75,
        latency_ms=150,
        max_tokens=1000000,
        capabilities=["vision", "function_calling", "json_mode"],
    ),
    ModelProfile(
        name="mistral-large-latest",
        provider="mistral",
        input_cost=2.00,
        output_cost=6.00,
        quality_score=85,
        latency_ms=350,
        max_tokens=128000,
        capabilities=["function_calling", "json_mode"],
    ),
    ModelProfile(
        name="mistral-small-latest",
        provider="mistral",
        input_cost=0.20,
        output_cost=0.60,
        quality_score=72,
        latency_ms=200,
        max_tokens=32000,
        capabilities=["function_calling", "json_mode"],
    ),
]


@dataclass
class SelectionCriteria:
    """Criteria for model selection.
    
    Attributes:
        goal: Primary optimization goal
        min_quality: Minimum acceptable quality score
        max_cost_per_1m: Maximum cost per 1M tokens
        max_latency_ms: Maximum acceptable latency
        required_capabilities: Required model capabilities
        required_tokens: Required context length
        preferred_providers: Preferred providers (in order)
        complexity: Task complexity
    """
    
    goal: OptimizationGoal = OptimizationGoal.BALANCED
    min_quality: float = 0.0
    max_cost_per_1m: float = float("inf")
    max_latency_ms: int = 10000
    required_capabilities: list[str] = field(default_factory=list)
    required_tokens: int = 0
    preferred_providers: list[str] = field(default_factory=list)
    complexity: TaskComplexity = TaskComplexity.MODERATE
    
    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "goal": self.goal.value,
            "min_quality": self.min_quality,
            "max_cost_per_1m": self.max_cost_per_1m,
            "max_latency_ms": self.max_latency_ms,
            "required_capabilities": self.required_capabilities,
            "required_tokens": self.required_tokens,
            "preferred_providers": self.preferred_providers,
            "complexity": self.complexity.value,
        }


@dataclass
class SelectionResult:
    """Result of model selection.
    
    Attributes:
        selected_model: Selected model profile
        score: Selection score
        reason: Reason for selection
        alternatives: Alternative models
        criteria: Selection criteria used
    """
    
    selected_model: ModelProfile
    score: float
    reason: str
    alternatives: list[ModelProfile] = field(default_factory=list)
    criteria: SelectionCriteria | None = None
    
    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "selected_model": self.selected_model.to_dict(),
            "score": self.score,
            "reason": self.reason,
            "alternatives": [m.to_dict() for m in self.alternatives[:3]],
            "criteria": self.criteria.to_dict() if self.criteria else None,
        }


class ModelSelector:
    """Intelligent model selection based on criteria.
    
    Provides cost-optimized model selection considering
    quality, latency, capabilities, and budget constraints.
    
    Example:
        ```python
        selector = ModelSelector()
        
        # Select for cost optimization
        result = selector.select(SelectionCriteria(
            goal=OptimizationGoal.COST,
            min_quality=70,
            required_capabilities=["function_calling"],
        ))
        
        print(f"Selected: {result.selected_model.name}")
        print(f"Cost: ${result.selected_model.avg_cost}/1M tokens")
        ```
    """
    
    def __init__(
        self,
        profiles: list[ModelProfile] | None = None,
    ) -> None:
        """Initialize model selector.
        
        Args:
            profiles: Custom model profiles (uses defaults if not provided)
        """
        self.profiles = profiles or DEFAULT_MODEL_PROFILES.copy()
    
    def add_profile(self, profile: ModelProfile) -> None:
        """Add a model profile."""
        self.profiles.append(profile)
    
    def remove_profile(self, name: str) -> bool:
        """Remove a model profile by name."""
        for i, profile in enumerate(self.profiles):
            if profile.name == name:
                del self.profiles[i]
                return True
        return False
    
    def get_profile(self, name: str) -> ModelProfile | None:
        """Get a model profile by name."""
        for profile in self.profiles:
            if profile.name == name:
                return profile
        return None
    
    def _filter_profiles(self, criteria: SelectionCriteria) -> list[ModelProfile]:
        """Filter profiles based on hard criteria."""
        filtered = []
        
        for profile in self.profiles:
            # Check quality
            if profile.quality_score < criteria.min_quality:
                continue
            
            # Check cost
            if profile.avg_cost > criteria.max_cost_per_1m:
                continue
            
            # Check latency
            if profile.latency_ms > criteria.max_latency_ms:
                continue
            
            # Check context length
            if profile.max_tokens < criteria.required_tokens:
                continue
            
            # Check capabilities
            if criteria.required_capabilities:
                if not all(cap in profile.capabilities 
                          for cap in criteria.required_capabilities):
                    continue
            
            filtered.append(profile)
        
        return filtered
    
    def _score_profile(
        self,
        profile: ModelProfile,
        criteria: SelectionCriteria,
    ) -> float:
        """Calculate selection score for a profile."""
        score = 0.0
        
        if criteria.goal == OptimizationGoal.COST:
            # Lower cost = higher score
            max_cost = max(p.avg_cost for p in self.profiles) or 1
            score = 100 * (1 - profile.avg_cost / max_cost)
            
        elif criteria.goal == OptimizationGoal.QUALITY:
            score = profile.quality_score
            
        elif criteria.goal == OptimizationGoal.LATENCY:
            max_latency = max(p.latency_ms for p in self.profiles) or 1
            score = 100 * (1 - profile.latency_ms / max_latency)
            
        elif criteria.goal == OptimizationGoal.THROUGHPUT:
            # Inverse of latency + cost efficiency
            max_latency = max(p.latency_ms for p in self.profiles) or 1
            latency_score = 1 - profile.latency_ms / max_latency
            cost_score = profile.cost_efficiency / 100
            score = 50 * latency_score + 50 * cost_score
            
        else:  # BALANCED
            # Weighted combination
            quality_weight = 0.4
            cost_weight = 0.4
            latency_weight = 0.2
            
            max_cost = max(p.avg_cost for p in self.profiles) or 1
            max_latency = max(p.latency_ms for p in self.profiles) or 1
            
            quality_score = profile.quality_score
            cost_score = 100 * (1 - profile.avg_cost / max_cost)
            latency_score = 100 * (1 - profile.latency_ms / max_latency)
            
            score = (quality_weight * quality_score +
                    cost_weight * cost_score +
                    latency_weight * latency_score)
        
        # Bonus for preferred provider
        if criteria.preferred_providers:
            if profile.provider in criteria.preferred_providers:
                rank = criteria.preferred_providers.index(profile.provider)
                score += (len(criteria.preferred_providers) - rank) * 5
        
        # Adjust for complexity
        if criteria.complexity == TaskComplexity.SIMPLE:
            # Prefer cheaper models for simple tasks
            if profile.quality_score < 80:
                score += 10
        elif criteria.complexity == TaskComplexity.EXPERT:
            # Prefer higher quality for expert tasks
            if profile.quality_score >= 90:
                score += 10
        
        return score
    
    def select(self, criteria: SelectionCriteria | None = None) -> SelectionResult:
        """Select the best model based on criteria.
        
        Args:
            criteria: Selection criteria (uses defaults if not provided)
            
        Returns:
            Selection result with model and alternatives
        """
        criteria = criteria or SelectionCriteria()
        
        # Filter by hard constraints
        candidates = self._filter_profiles(criteria)
        
        if not candidates:
            # Fall back to least restrictive filtering
            candidates = self.profiles.copy()
        
        # Score candidates
        scored = [(self._score_profile(p, criteria), p) for p in candidates]
        scored.sort(key=lambda x: x[0], reverse=True)
        
        if not scored:
            raise ValueError("No models available")
        
        best_score, best_model = scored[0]
        alternatives = [p for _, p in scored[1:5]]
        
        # Generate reason
        reason = self._generate_reason(best_model, criteria)
        
        return SelectionResult(
            selected_model=best_model,
            score=best_score,
            reason=reason,
            alternatives=alternatives,
            criteria=criteria,
        )
    
    def _generate_reason(
        self,
        model: ModelProfile,
        criteria: SelectionCriteria,
    ) -> str:
        """Generate human-readable reason for selection."""
        parts = []
        
        if criteria.goal == OptimizationGoal.COST:
            parts.append(f"lowest cost at ${model.avg_cost:.2f}/1M tokens")
        elif criteria.goal == OptimizationGoal.QUALITY:
            parts.append(f"highest quality score of {model.quality_score}")
        elif criteria.goal == OptimizationGoal.LATENCY:
            parts.append(f"lowest latency at {model.latency_ms}ms")
        elif criteria.goal == OptimizationGoal.THROUGHPUT:
            parts.append("best throughput/cost ratio")
        else:
            parts.append("best balanced score")
        
        if criteria.required_capabilities:
            parts.append(f"supports {', '.join(criteria.required_capabilities)}")
        
        return f"Selected {model.name}: " + ", ".join(parts)
    
    def select_for_budget(
        self,
        budget: float,
        estimated_tokens: int,
        min_quality: float = 70.0,
    ) -> SelectionResult:
        """Select best model within a budget.
        
        Args:
            budget: Available budget in USD
            estimated_tokens: Estimated total tokens (input + output)
            min_quality: Minimum quality score
            
        Returns:
            Selection result
        """
        # Calculate max cost per 1M tokens
        max_cost = (budget / estimated_tokens) * 1_000_000
        
        criteria = SelectionCriteria(
            goal=OptimizationGoal.QUALITY,
            max_cost_per_1m=max_cost,
            min_quality=min_quality,
        )
        
        return self.select(criteria)
    
    def select_for_complexity(
        self,
        complexity: TaskComplexity,
        goal: OptimizationGoal = OptimizationGoal.BALANCED,
    ) -> SelectionResult:
        """Select model based on task complexity.
        
        Args:
            complexity: Task complexity level
            goal: Optimization goal
            
        Returns:
            Selection result
        """
        # Set min quality based on complexity
        min_quality_map = {
            TaskComplexity.SIMPLE: 60,
            TaskComplexity.MODERATE: 70,
            TaskComplexity.COMPLEX: 80,
            TaskComplexity.EXPERT: 90,
        }
        
        criteria = SelectionCriteria(
            goal=goal,
            min_quality=min_quality_map[complexity],
            complexity=complexity,
        )
        
        return self.select(criteria)
    
    def compare_models(
        self,
        model_names: list[str],
        input_tokens: int = 1000,
        output_tokens: int = 500,
    ) -> list[dict[str, Any]]:
        """Compare specific models.
        
        Args:
            model_names: Model names to compare
            input_tokens: Estimated input tokens
            output_tokens: Estimated output tokens
            
        Returns:
            List of comparison data
        """
        comparisons = []
        
        for name in model_names:
            profile = self.get_profile(name)
            if profile:
                cost = profile.estimate_cost(input_tokens, output_tokens)
                comparisons.append({
                    "name": profile.name,
                    "provider": profile.provider,
                    "quality": profile.quality_score,
                    "estimated_cost": cost,
                    "latency_ms": profile.latency_ms,
                    "cost_efficiency": profile.cost_efficiency,
                })
        
        # Sort by cost efficiency
        comparisons.sort(key=lambda x: x["cost_efficiency"], reverse=True)
        
        return comparisons


@dataclass
class CostEstimate:
    """Cost estimate for an operation.
    
    Attributes:
        model: Model name
        input_tokens: Estimated input tokens
        output_tokens: Estimated output tokens
        estimated_cost: Estimated cost in USD
        confidence: Confidence level (0-1)
    """
    
    model: str
    input_tokens: int
    output_tokens: int
    estimated_cost: float
    confidence: float
    breakdown: dict[str, float] = field(default_factory=dict)
    
    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "model": self.model,
            "input_tokens": self.input_tokens,
            "output_tokens": self.output_tokens,
            "estimated_cost": self.estimated_cost,
            "confidence": self.confidence,
            "breakdown": self.breakdown,
        }


class CostEstimator:
    """Estimate costs for LLM operations.
    
    Example:
        ```python
        estimator = CostEstimator()
        
        estimate = estimator.estimate(
            model="gpt-4o",
            input_text="Hello, world!",
            expected_output_tokens=500,
        )
        
        print(f"Estimated cost: ${estimate.estimated_cost:.4f}")
        ```
    """
    
    def __init__(
        self,
        selector: ModelSelector | None = None,
        chars_per_token: float = 4.0,
    ) -> None:
        """Initialize cost estimator.
        
        Args:
            selector: Model selector for profiles
            chars_per_token: Average characters per token
        """
        self.selector = selector or ModelSelector()
        self.chars_per_token = chars_per_token
    
    def estimate_tokens(self, text: str) -> int:
        """Estimate token count for text."""
        return int(len(text) / self.chars_per_token)
    
    def estimate(
        self,
        model: str,
        input_text: str | None = None,
        input_tokens: int | None = None,
        expected_output_tokens: int = 500,
    ) -> CostEstimate:
        """Estimate cost for an operation.
        
        Args:
            model: Model name
            input_text: Input text (for token estimation)
            input_tokens: Known input token count
            expected_output_tokens: Expected output tokens
            
        Returns:
            Cost estimate
        """
        profile = self.selector.get_profile(model)
        
        if profile is None:
            # Default pricing
            profile = ModelProfile(
                name=model,
                provider="unknown",
                input_cost=1.0,
                output_cost=2.0,
                quality_score=80,
                latency_ms=500,
                max_tokens=100000,
            )
        
        # Calculate input tokens
        if input_tokens is None and input_text is not None:
            input_tokens = self.estimate_tokens(input_text)
        elif input_tokens is None:
            input_tokens = 0
        
        # Calculate costs
        input_cost = (input_tokens / 1_000_000) * profile.input_cost
        output_cost = (expected_output_tokens / 1_000_000) * profile.output_cost
        total_cost = input_cost + output_cost
        
        # Confidence based on token estimation method
        confidence = 0.95 if input_tokens is not None else 0.7
        
        return CostEstimate(
            model=model,
            input_tokens=input_tokens,
            output_tokens=expected_output_tokens,
            estimated_cost=total_cost,
            confidence=confidence,
            breakdown={
                "input_cost": input_cost,
                "output_cost": output_cost,
            },
        )
    
    def estimate_batch(
        self,
        model: str,
        items: list[str],
        expected_output_per_item: int = 200,
    ) -> CostEstimate:
        """Estimate cost for a batch of items.
        
        Args:
            model: Model name
            items: List of input texts
            expected_output_per_item: Expected output tokens per item
            
        Returns:
            Total cost estimate
        """
        total_input_tokens = sum(self.estimate_tokens(item) for item in items)
        total_output_tokens = len(items) * expected_output_per_item
        
        return self.estimate(
            model=model,
            input_tokens=total_input_tokens,
            expected_output_tokens=total_output_tokens,
        )
    
    def compare_costs(
        self,
        input_tokens: int,
        output_tokens: int,
        models: list[str] | None = None,
    ) -> list[CostEstimate]:
        """Compare costs across models.
        
        Args:
            input_tokens: Input token count
            output_tokens: Output token count
            models: Models to compare (all if None)
            
        Returns:
            List of cost estimates sorted by cost
        """
        if models is None:
            models = [p.name for p in self.selector.profiles]
        
        estimates = []
        for model in models:
            estimate = self.estimate(
                model=model,
                input_tokens=input_tokens,
                expected_output_tokens=output_tokens,
            )
            estimates.append(estimate)
        
        estimates.sort(key=lambda x: x.estimated_cost)
        return estimates
