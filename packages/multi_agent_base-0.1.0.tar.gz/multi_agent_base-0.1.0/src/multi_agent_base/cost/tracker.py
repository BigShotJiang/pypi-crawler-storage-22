"""
Cost tracking for LLM usage.

This module provides utilities to track token usage and
calculate costs across agents and sessions.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any

from multi_agent_base.providers.pricing import PricingCalculator


class BudgetExceededError(Exception):
    """Exception raised when budget limit is exceeded.
    
    Attributes:
        limit: The budget limit that was exceeded
        current: The current total cost
        attempted: The cost that would exceed the budget
    """
    
    def __init__(
        self,
        message: str = "Budget limit exceeded",
        limit: float | None = None,
        current: float | None = None,
        attempted: float | None = None,
    ) -> None:
        super().__init__(message)
        self.limit = limit
        self.current = current
        self.attempted = attempted


@dataclass
class UsageRecord:
    """Record of a single LLM usage event.
    
    Attributes:
        timestamp: When the usage occurred
        agent_name: Name of the agent
        provider: LLM provider
        model: Model name
        input_tokens: Number of input tokens
        output_tokens: Number of output tokens
        cost: Cost in USD
        metadata: Additional metadata
    """
    
    timestamp: datetime
    agent_name: str
    provider: str
    model: str
    input_tokens: int
    output_tokens: int
    cost: float
    metadata: dict[str, Any] = field(default_factory=dict)
    
    @property
    def total_tokens(self) -> int:
        """Get total token count."""
        return self.input_tokens + self.output_tokens
    
    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary.
        
        Returns:
            Dictionary representation
        """
        return {
            "timestamp": self.timestamp.isoformat(),
            "agent_name": self.agent_name,
            "provider": self.provider,
            "model": self.model,
            "input_tokens": self.input_tokens,
            "output_tokens": self.output_tokens,
            "total_tokens": self.total_tokens,
            "cost": self.cost,
            "metadata": self.metadata,
        }
    
    def to_json(self) -> str:
        """Convert to JSON string.
        
        Returns:
            JSON string
        """
        return json.dumps(self.to_dict())
    
    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "UsageRecord":
        """Create from dictionary.
        
        Args:
            data: Dictionary with record data
            
        Returns:
            UsageRecord instance
        """
        timestamp = data.get("timestamp")
        if isinstance(timestamp, str):
            timestamp = datetime.fromisoformat(timestamp)
        elif timestamp is None:
            timestamp = datetime.now()
        
        return cls(
            timestamp=timestamp,
            agent_name=data.get("agent_name", ""),
            provider=data.get("provider", ""),
            model=data.get("model", ""),
            input_tokens=data.get("input_tokens", 0),
            output_tokens=data.get("output_tokens", 0),
            cost=data.get("cost", 0.0),
            metadata=data.get("metadata", {}),
        )


@dataclass
class CostSummary:
    """Summary of costs and usage.
    
    Attributes:
        total_cost: Total cost in USD
        total_input_tokens: Total input tokens
        total_output_tokens: Total output tokens
        record_count: Number of usage records
        by_agent: Breakdown by agent
        by_provider: Breakdown by provider
        by_model: Breakdown by model
        period_start: Start of the period
        period_end: End of the period
    """
    
    total_cost: float = 0.0
    total_input_tokens: int = 0
    total_output_tokens: int = 0
    record_count: int = 0
    by_agent: dict[str, dict[str, float]] = field(default_factory=dict)
    by_provider: dict[str, dict[str, float]] = field(default_factory=dict)
    by_model: dict[str, dict[str, float]] = field(default_factory=dict)
    period_start: datetime | None = None
    period_end: datetime | None = None
    
    @property
    def total_tokens(self) -> int:
        """Get total tokens."""
        return self.total_input_tokens + self.total_output_tokens
    
    @property
    def average_cost_per_call(self) -> float:
        """Get average cost per call."""
        if self.record_count == 0:
            return 0.0
        return self.total_cost / self.record_count
    
    @property
    def average_tokens_per_call(self) -> float:
        """Get average tokens per call."""
        if self.record_count == 0:
            return 0.0
        return self.total_tokens / self.record_count
    
    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary.
        
        Returns:
            Dictionary representation
        """
        return {
            "total_cost": self.total_cost,
            "total_input_tokens": self.total_input_tokens,
            "total_output_tokens": self.total_output_tokens,
            "total_tokens": self.total_tokens,
            "record_count": self.record_count,
            "average_cost_per_call": self.average_cost_per_call,
            "average_tokens_per_call": self.average_tokens_per_call,
            "by_agent": self.by_agent,
            "by_provider": self.by_provider,
            "by_model": self.by_model,
            "period_start": self.period_start.isoformat() if self.period_start else None,
            "period_end": self.period_end.isoformat() if self.period_end else None,
        }
    
    def __str__(self) -> str:
        """String representation."""
        lines = [
            "=" * 50,
            "Cost Summary",
            "=" * 50,
            f"Total Cost: ${self.total_cost:.6f}",
            f"Total Tokens: {self.total_tokens:,}",
            f"  - Input: {self.total_input_tokens:,}",
            f"  - Output: {self.total_output_tokens:,}",
            f"Record Count: {self.record_count}",
            f"Avg Cost/Call: ${self.average_cost_per_call:.6f}",
            f"Avg Tokens/Call: {self.average_tokens_per_call:.1f}",
        ]
        
        if self.by_agent:
            lines.append("\nBy Agent:")
            for agent, data in self.by_agent.items():
                lines.append(f"  {agent}: ${data['cost']:.6f} ({data['tokens']:,} tokens)")
        
        if self.by_model:
            lines.append("\nBy Model:")
            for model, data in self.by_model.items():
                lines.append(f"  {model}: ${data['cost']:.6f} ({data['tokens']:,} tokens)")
        
        lines.append("=" * 50)
        
        return "\n".join(lines)


class CostTracker:
    """Tracks token usage and costs across agents.
    
    Provides methods to record usage, calculate costs, and
    generate summaries and reports.
    
    Example:
        ```python
        tracker = CostTracker()
        
        # Record usage
        tracker.record(
            agent_name="assistant",
            provider="openai",
            model="gpt-4o-mini",
            input_tokens=100,
            output_tokens=50,
        )
        
        # Get summary
        summary = tracker.get_summary()
        print(summary)
        
        # Export to file
        tracker.export("usage_report.json")
        ```
    """
    
    def __init__(
        self,
        auto_persist: bool = False,
        persist_path: str | Path | None = None,
    ) -> None:
        """Initialize the cost tracker.
        
        Args:
            auto_persist: Whether to auto-persist records
            persist_path: Path for persisting records
        """
        self._records: list[UsageRecord] = []
        self.auto_persist = auto_persist
        self.persist_path = Path(persist_path) if persist_path else None
        
        # Load existing records if file exists
        if self.persist_path and self.persist_path.exists():
            self._load_records()
    
    def record(
        self,
        agent_name: str,
        provider: str,
        model: str,
        input_tokens: int,
        output_tokens: int,
        cost: float | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> UsageRecord:
        """Record a usage event.
        
        Args:
            agent_name: Name of the agent
            provider: LLM provider
            model: Model name
            input_tokens: Input token count
            output_tokens: Output token count
            cost: Pre-calculated cost (calculated if None)
            metadata: Additional metadata
            
        Returns:
            The created UsageRecord
        """
        # Calculate cost if not provided
        if cost is None:
            cost = self.calculate_cost(
                provider=provider,
                model=model,
                input_tokens=input_tokens,
                output_tokens=output_tokens,
            )
        
        record = UsageRecord(
            timestamp=datetime.now(),
            agent_name=agent_name,
            provider=provider,
            model=model,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            cost=cost,
            metadata=metadata or {},
        )
        
        self._records.append(record)
        
        if self.auto_persist and self.persist_path:
            self._append_record(record)
        
        return record
    
    def calculate_cost(
        self,
        provider: str,
        model: str,
        input_tokens: int,
        output_tokens: int,
    ) -> float:
        """Calculate cost for token usage.
        
        Args:
            provider: LLM provider
            model: Model name
            input_tokens: Input token count
            output_tokens: Output token count
            
        Returns:
            Cost in USD
        """
        return PricingCalculator.calculate(
            provider=provider,
            model=model,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
        )
    
    def get_records(
        self,
        agent_name: str | None = None,
        provider: str | None = None,
        model: str | None = None,
        start_time: datetime | None = None,
        end_time: datetime | None = None,
    ) -> list[UsageRecord]:
        """Get usage records with optional filtering.
        
        Args:
            agent_name: Filter by agent
            provider: Filter by provider
            model: Filter by model
            start_time: Filter by start time
            end_time: Filter by end time
            
        Returns:
            List of matching records
        """
        records = self._records
        
        if agent_name:
            records = [r for r in records if r.agent_name == agent_name]
        
        if provider:
            records = [r for r in records if r.provider == provider]
        
        if model:
            records = [r for r in records if r.model == model]
        
        if start_time:
            records = [r for r in records if r.timestamp >= start_time]
        
        if end_time:
            records = [r for r in records if r.timestamp <= end_time]
        
        return records
    
    def get_summary(
        self,
        agent_name: str | None = None,
        provider: str | None = None,
        model: str | None = None,
        start_time: datetime | None = None,
        end_time: datetime | None = None,
    ) -> CostSummary:
        """Get a cost summary.
        
        Args:
            agent_name: Filter by agent
            provider: Filter by provider
            model: Filter by model
            start_time: Filter by start time
            end_time: Filter by end time
            
        Returns:
            CostSummary with aggregated data
        """
        records = self.get_records(
            agent_name=agent_name,
            provider=provider,
            model=model,
            start_time=start_time,
            end_time=end_time,
        )
        
        if not records:
            return CostSummary()
        
        summary = CostSummary(
            period_start=min(r.timestamp for r in records),
            period_end=max(r.timestamp for r in records),
            record_count=len(records),
        )
        
        # Aggregate data
        for record in records:
            summary.total_cost += record.cost
            summary.total_input_tokens += record.input_tokens
            summary.total_output_tokens += record.output_tokens
            
            # By agent
            if record.agent_name not in summary.by_agent:
                summary.by_agent[record.agent_name] = {"cost": 0.0, "tokens": 0, "calls": 0}
            summary.by_agent[record.agent_name]["cost"] += record.cost
            summary.by_agent[record.agent_name]["tokens"] += record.total_tokens
            summary.by_agent[record.agent_name]["calls"] += 1
            
            # By provider
            if record.provider not in summary.by_provider:
                summary.by_provider[record.provider] = {"cost": 0.0, "tokens": 0, "calls": 0}
            summary.by_provider[record.provider]["cost"] += record.cost
            summary.by_provider[record.provider]["tokens"] += record.total_tokens
            summary.by_provider[record.provider]["calls"] += 1
            
            # By model
            if record.model not in summary.by_model:
                summary.by_model[record.model] = {"cost": 0.0, "tokens": 0, "calls": 0}
            summary.by_model[record.model]["cost"] += record.cost
            summary.by_model[record.model]["tokens"] += record.total_tokens
            summary.by_model[record.model]["calls"] += 1
        
        return summary
    
    def get_total_cost(
        self,
        agent_name: str | None = None,
    ) -> float:
        """Get total cost.
        
        Args:
            agent_name: Optional filter by agent
            
        Returns:
            Total cost in USD
        """
        records = self.get_records(agent_name=agent_name)
        return sum(r.cost for r in records)
    
    def get_total_tokens(
        self,
        agent_name: str | None = None,
    ) -> dict[str, int]:
        """Get total token usage.
        
        Args:
            agent_name: Optional filter by agent
            
        Returns:
            Dict with input, output, and total tokens
        """
        records = self.get_records(agent_name=agent_name)
        return {
            "input_tokens": sum(r.input_tokens for r in records),
            "output_tokens": sum(r.output_tokens for r in records),
            "total_tokens": sum(r.total_tokens for r in records),
        }
    
    def clear(self) -> None:
        """Clear all records."""
        self._records = []
    
    def export(
        self,
        path: str | Path,
        format: str = "json",
    ) -> None:
        """Export records to a file.
        
        Args:
            path: Output file path
            format: Export format (json, jsonl, csv)
        """
        path = Path(path)
        
        if format == "json":
            data = {
                "records": [r.to_dict() for r in self._records],
                "summary": self.get_summary().to_dict(),
            }
            path.write_text(json.dumps(data, indent=2))
        
        elif format == "jsonl":
            with open(path, "w") as f:
                for record in self._records:
                    f.write(record.to_json() + "\n")
        
        elif format == "csv":
            import csv
            with open(path, "w", newline="") as f:
                writer = csv.writer(f)
                writer.writerow([
                    "timestamp", "agent_name", "provider", "model",
                    "input_tokens", "output_tokens", "total_tokens", "cost"
                ])
                for r in self._records:
                    writer.writerow([
                        r.timestamp.isoformat(), r.agent_name, r.provider,
                        r.model, r.input_tokens, r.output_tokens,
                        r.total_tokens, r.cost
                    ])
        
        else:
            raise ValueError(f"Unsupported format: {format}")
    
    def _load_records(self) -> None:
        """Load records from persist path."""
        if not self.persist_path:
            return
        
        try:
            content = self.persist_path.read_text()
            for line in content.strip().split("\n"):
                if line:
                    data = json.loads(line)
                    self._records.append(UsageRecord.from_dict(data))
        except Exception:
            pass
    
    def _append_record(self, record: UsageRecord) -> None:
        """Append a single record to persist file."""
        if not self.persist_path:
            return
        
        self.persist_path.parent.mkdir(parents=True, exist_ok=True)
        
        with open(self.persist_path, "a") as f:
            f.write(record.to_json() + "\n")
    
    def persist(self) -> None:
        """Persist all records to file."""
        if not self.persist_path:
            return
        
        self.persist_path.parent.mkdir(parents=True, exist_ok=True)
        
        with open(self.persist_path, "w") as f:
            for record in self._records:
                f.write(record.to_json() + "\n")
    
    def print_summary(self) -> None:
        """Print a formatted summary to console."""
        print(self.get_summary())
    
    def __len__(self) -> int:
        """Return number of records."""
        return len(self._records)


def create_tracker(
    persist_path: str | Path | None = None,
    auto_persist: bool = False,
) -> CostTracker:
    """Create a configured cost tracker.
    
    Args:
        persist_path: Path for persisting records
        auto_persist: Whether to auto-persist
        
    Returns:
        Configured CostTracker instance
    """
    return CostTracker(
        auto_persist=auto_persist,
        persist_path=persist_path,
    )
