"""
Events/Hooks Module for Multi-Agent Base.

This module provides event-driven architecture:
- Event bus for pub/sub messaging
- Lifecycle hooks for agents
- Event decorators
- Async event handling
"""

from multi_agent_base.events.bus import (
    EventBus,
    Event,
    EventHandler,
    EventPriority,
)
from multi_agent_base.events.hooks import (
    Hook,
    HookManager,
    LifecycleHook,
    AgentLifecycleHooks,
)
from multi_agent_base.events.decorators import (
    on_event,
    before_hook,
    after_hook,
)

__all__ = [
    # Event Bus
    "EventBus",
    "Event",
    "EventHandler",
    "EventPriority",
    # Hooks
    "Hook",
    "HookManager",
    "LifecycleHook",
    "AgentLifecycleHooks",
    # Decorators
    "on_event",
    "before_hook",
    "after_hook",
]
