"""
Event Bus implementation.

Provides publish-subscribe messaging for the agent system.
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from datetime import datetime
from enum import IntEnum
from typing import Any, Callable, Coroutine
from uuid import uuid4


class EventPriority(IntEnum):
    """Event handler priority levels.
    
    Lower values = higher priority (executed first).
    """
    
    HIGHEST = 0
    HIGH = 25
    NORMAL = 50
    LOW = 75
    LOWEST = 100


@dataclass
class Event:
    """Represents an event in the system.
    
    Attributes:
        name: Event name/type
        data: Event payload
        source: Source of the event (agent name, etc.)
        id: Unique event identifier
        timestamp: When the event was created
        metadata: Additional metadata
        propagate: Whether to continue to next handlers
    """
    
    name: str
    data: dict[str, Any] = field(default_factory=dict)
    source: str | None = None
    id: str = field(default_factory=lambda: str(uuid4()))
    timestamp: datetime = field(default_factory=datetime.now)
    metadata: dict[str, Any] = field(default_factory=dict)
    propagate: bool = True
    
    def stop_propagation(self) -> None:
        """Stop event from propagating to remaining handlers."""
        self.propagate = False
    
    def to_dict(self) -> dict[str, Any]:
        """Convert event to dictionary."""
        return {
            "name": self.name,
            "data": self.data,
            "source": self.source,
            "id": self.id,
            "timestamp": self.timestamp.isoformat(),
            "metadata": self.metadata,
        }


# Type alias for event handlers
EventHandler = Callable[[Event], Coroutine[Any, Any, None]]


@dataclass
class EventSubscription:
    """A subscription to an event.
    
    Attributes:
        event_name: Name of the event to handle
        handler: Handler function
        priority: Handler priority
        once: Whether to unsubscribe after first call
    """
    
    event_name: str
    handler: EventHandler
    priority: EventPriority = EventPriority.NORMAL
    once: bool = False


class EventBus:
    """Event bus for publish-subscribe messaging.
    
    Allows agents and components to communicate through events
    without direct coupling.
    
    Example:
        ```python
        bus = EventBus()
        
        # Subscribe to events
        async def on_message(event: Event):
            print(f"Message received: {event.data}")
        
        bus.subscribe("message", on_message)
        
        # Publish events
        await bus.publish(Event(
            name="message",
            data={"text": "Hello!"}
        ))
        ```
    """
    
    def __init__(self) -> None:
        """Initialize event bus."""
        self._subscriptions: dict[str, list[EventSubscription]] = {}
        self._global_handlers: list[EventSubscription] = []
        self._lock = asyncio.Lock()
        self._event_history: list[Event] = []
        self._max_history = 1000
    
    def subscribe(
        self,
        event_name: str,
        handler: EventHandler,
        priority: EventPriority = EventPriority.NORMAL,
        once: bool = False,
    ) -> Callable[[], None]:
        """Subscribe to an event.
        
        Args:
            event_name: Event name to subscribe to ("*" for all events)
            handler: Async handler function
            priority: Handler priority
            once: If True, unsubscribe after first call
            
        Returns:
            Unsubscribe function
        """
        subscription = EventSubscription(
            event_name=event_name,
            handler=handler,
            priority=priority,
            once=once,
        )
        
        if event_name == "*":
            self._global_handlers.append(subscription)
            self._global_handlers.sort(key=lambda s: s.priority)
        else:
            if event_name not in self._subscriptions:
                self._subscriptions[event_name] = []
            self._subscriptions[event_name].append(subscription)
            self._subscriptions[event_name].sort(key=lambda s: s.priority)
        
        # Return unsubscribe function
        def unsubscribe() -> None:
            self.unsubscribe(event_name, handler)
        
        return unsubscribe
    
    def unsubscribe(
        self,
        event_name: str,
        handler: EventHandler,
    ) -> bool:
        """Unsubscribe a handler from an event.
        
        Args:
            event_name: Event name
            handler: Handler to remove
            
        Returns:
            True if handler was removed
        """
        if event_name == "*":
            for i, sub in enumerate(self._global_handlers):
                if sub.handler == handler:
                    self._global_handlers.pop(i)
                    return True
            return False
        
        if event_name not in self._subscriptions:
            return False
        
        for i, sub in enumerate(self._subscriptions[event_name]):
            if sub.handler == handler:
                self._subscriptions[event_name].pop(i)
                return True
        
        return False
    
    async def publish(
        self,
        event: Event,
        wait: bool = True,
    ) -> None:
        """Publish an event to all subscribers.
        
        Args:
            event: Event to publish
            wait: Whether to wait for all handlers to complete
        """
        # Add to history
        self._event_history.append(event)
        if len(self._event_history) > self._max_history:
            self._event_history.pop(0)
        
        # Collect all handlers
        handlers: list[EventSubscription] = []
        
        # Global handlers
        handlers.extend(self._global_handlers)
        
        # Event-specific handlers
        if event.name in self._subscriptions:
            handlers.extend(self._subscriptions[event.name])
        
        # Sort by priority
        handlers.sort(key=lambda h: h.priority)
        
        # Track once handlers to remove
        to_remove: list[EventSubscription] = []
        
        # Execute handlers
        for subscription in handlers:
            if not event.propagate:
                break
            
            try:
                if wait:
                    await subscription.handler(event)
                else:
                    asyncio.create_task(subscription.handler(event))
            except Exception as e:
                # Log error but continue with other handlers
                event.metadata["handler_error"] = str(e)
            
            if subscription.once:
                to_remove.append(subscription)
        
        # Remove once handlers
        for sub in to_remove:
            self.unsubscribe(sub.event_name, sub.handler)
    
    async def emit(
        self,
        name: str,
        data: dict[str, Any] | None = None,
        source: str | None = None,
    ) -> Event:
        """Convenience method to create and publish an event.
        
        Args:
            name: Event name
            data: Event data
            source: Event source
            
        Returns:
            The created event
        """
        event = Event(
            name=name,
            data=data or {},
            source=source,
        )
        await self.publish(event)
        return event
    
    def clear(self, event_name: str | None = None) -> None:
        """Clear subscriptions.
        
        Args:
            event_name: Event to clear (None = clear all)
        """
        if event_name is None:
            self._subscriptions.clear()
            self._global_handlers.clear()
        elif event_name == "*":
            self._global_handlers.clear()
        elif event_name in self._subscriptions:
            del self._subscriptions[event_name]
    
    def get_history(
        self,
        event_name: str | None = None,
        limit: int = 100,
    ) -> list[Event]:
        """Get event history.
        
        Args:
            event_name: Filter by event name
            limit: Maximum events to return
            
        Returns:
            List of recent events
        """
        history = self._event_history
        
        if event_name:
            history = [e for e in history if e.name == event_name]
        
        return history[-limit:]
    
    def get_subscriber_count(self, event_name: str) -> int:
        """Get number of subscribers for an event.
        
        Args:
            event_name: Event name
            
        Returns:
            Number of subscribers
        """
        count = len(self._global_handlers)
        
        if event_name in self._subscriptions:
            count += len(self._subscriptions[event_name])
        
        return count


# Default global event bus
_default_bus: EventBus | None = None


def get_event_bus() -> EventBus:
    """Get the default event bus singleton.
    
    Returns:
        Default EventBus instance
    """
    global _default_bus
    if _default_bus is None:
        _default_bus = EventBus()
    return _default_bus


def set_event_bus(bus: EventBus) -> None:
    """Set the default event bus.
    
    Args:
        bus: EventBus to use as default
    """
    global _default_bus
    _default_bus = bus
