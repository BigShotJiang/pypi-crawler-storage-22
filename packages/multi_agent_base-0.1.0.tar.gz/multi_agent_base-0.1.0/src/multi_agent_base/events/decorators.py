"""
Event and hook decorators.

Provides decorators for event subscription and hook registration.
"""

from __future__ import annotations

import functools
from typing import Any, Callable, TypeVar

from multi_agent_base.events.bus import (
    Event,
    EventBus,
    EventPriority,
    get_event_bus,
)
from multi_agent_base.events.hooks import (
    HookContext,
    HookFunction,
    HookManager,
    LifecycleHook,
)

F = TypeVar("F", bound=Callable[..., Any])


def on_event(
    event_name: str,
    bus: EventBus | None = None,
    priority: EventPriority = EventPriority.NORMAL,
    once: bool = False,
) -> Callable[[F], F]:
    """Decorator to subscribe a function to an event.
    
    Args:
        event_name: Event to subscribe to
        bus: EventBus to use (default: global)
        priority: Handler priority
        once: Unsubscribe after first call
        
    Returns:
        Decorator function
        
    Example:
        ```python
        @on_event("user_message")
        async def handle_message(event: Event):
            print(f"Received: {event.data}")
        ```
    """
    def decorator(func: F) -> F:
        event_bus = bus or get_event_bus()
        event_bus.subscribe(event_name, func, priority, once)
        
        # Attach metadata
        func._event_subscription = {  # type: ignore
            "event_name": event_name,
            "priority": priority,
            "once": once,
        }
        
        return func
    
    return decorator


def before_hook(
    hook_name: str | LifecycleHook,
    manager: HookManager | None = None,
    priority: int = 50,
) -> Callable[[F], F]:
    """Decorator to register a before hook.
    
    The decorated function will be called before the hooked operation.
    It can cancel the operation by setting ctx.cancelled = True.
    
    Args:
        hook_name: Hook point name
        manager: HookManager to use
        priority: Hook priority
        
    Returns:
        Decorator function
        
    Example:
        ```python
        hooks = HookManager()
        
        @before_hook(LifecycleHook.BEFORE_RUN, hooks)
        async def validate_input(ctx: HookContext):
            if not ctx.data.get("message"):
                ctx.cancel()
                ctx.result = "No message provided"
        ```
    """
    def decorator(func: F) -> F:
        if manager:
            manager.register(hook_name, func, priority)
        
        func._hook_registration = {  # type: ignore
            "hook_name": str(hook_name.value if isinstance(hook_name, LifecycleHook) else hook_name),
            "type": "before",
            "priority": priority,
        }
        
        return func
    
    return decorator


def after_hook(
    hook_name: str | LifecycleHook,
    manager: HookManager | None = None,
    priority: int = 50,
) -> Callable[[F], F]:
    """Decorator to register an after hook.
    
    The decorated function will be called after the hooked operation.
    It can modify the result by setting ctx.result.
    
    Args:
        hook_name: Hook point name
        manager: HookManager to use
        priority: Hook priority
        
    Returns:
        Decorator function
        
    Example:
        ```python
        hooks = HookManager()
        
        @after_hook(LifecycleHook.AFTER_RUN, hooks)
        async def log_result(ctx: HookContext):
            print(f"Agent {ctx.agent_name} completed")
            print(f"Result: {ctx.data.get('result')}")
        ```
    """
    def decorator(func: F) -> F:
        if manager:
            manager.register(hook_name, func, priority)
        
        func._hook_registration = {  # type: ignore
            "hook_name": str(hook_name.value if isinstance(hook_name, LifecycleHook) else hook_name),
            "type": "after",
            "priority": priority,
        }
        
        return func
    
    return decorator


def with_hooks(
    manager: HookManager,
    before: str | LifecycleHook | None = None,
    after: str | LifecycleHook | None = None,
) -> Callable[[F], F]:
    """Decorator to add hooks around a function.
    
    Automatically executes before and after hooks around
    the decorated function.
    
    Args:
        manager: HookManager to use
        before: Before hook name
        after: After hook name
        
    Returns:
        Decorator function
        
    Example:
        ```python
        hooks = HookManager()
        
        @with_hooks(
            hooks,
            before=LifecycleHook.BEFORE_RUN,
            after=LifecycleHook.AFTER_RUN,
        )
        async def run(self, message: str) -> str:
            return await self._process(message)
        ```
    """
    def decorator(func: F) -> F:
        @functools.wraps(func)
        async def wrapper(*args: Any, **kwargs: Any) -> Any:
            # Get agent name if available
            agent_name = "unknown"
            if args and hasattr(args[0], "name"):
                agent_name = args[0].name
            
            # Execute before hook
            if before:
                ctx = HookContext(
                    hook_name=str(before.value if isinstance(before, LifecycleHook) else before),
                    agent_name=agent_name,
                    data={"args": args[1:], "kwargs": kwargs},
                )
                await manager.execute(before, ctx)
                
                if ctx.cancelled:
                    return ctx.result
            
            # Execute function
            try:
                result = await func(*args, **kwargs)
            except Exception as e:
                # Execute error hook if registered
                error_ctx = HookContext(
                    hook_name=LifecycleHook.ON_ERROR.value,
                    agent_name=agent_name,
                    data={"error": str(e), "error_type": type(e).__name__},
                )
                await manager.execute(LifecycleHook.ON_ERROR, error_ctx)
                raise
            
            # Execute after hook
            if after:
                ctx = HookContext(
                    hook_name=str(after.value if isinstance(after, LifecycleHook) else after),
                    agent_name=agent_name,
                    data={"result": result},
                    result=result,
                )
                await manager.execute(after, ctx)
                result = ctx.result
            
            return result
        
        return wrapper  # type: ignore
    
    return decorator


class EventEmitter:
    """Mixin class to add event emission capabilities.
    
    Example:
        ```python
        class MyAgent(BaseAgent, EventEmitter):
            async def run(self, message: str):
                await self.emit("agent_started", {"message": message})
                result = await super().run(message)
                await self.emit("agent_completed", {"result": result})
                return result
        ```
    """
    
    _event_bus: EventBus | None = None
    
    @property
    def event_bus(self) -> EventBus:
        """Get the event bus."""
        if self._event_bus is None:
            self._event_bus = get_event_bus()
        return self._event_bus
    
    @event_bus.setter
    def event_bus(self, bus: EventBus) -> None:
        """Set the event bus."""
        self._event_bus = bus
    
    async def emit(
        self,
        event_name: str,
        data: dict[str, Any] | None = None,
        source: str | None = None,
    ) -> Event:
        """Emit an event.
        
        Args:
            event_name: Event name
            data: Event data
            source: Event source (defaults to self.name if available)
            
        Returns:
            The emitted event
        """
        if source is None and hasattr(self, "name"):
            source = getattr(self, "name")
        
        return await self.event_bus.emit(event_name, data, source)
    
    def subscribe(
        self,
        event_name: str,
        handler: Callable[[Event], Any],
        priority: EventPriority = EventPriority.NORMAL,
    ) -> Callable[[], None]:
        """Subscribe to an event.
        
        Args:
            event_name: Event name
            handler: Handler function
            priority: Handler priority
            
        Returns:
            Unsubscribe function
        """
        return self.event_bus.subscribe(event_name, handler, priority)
