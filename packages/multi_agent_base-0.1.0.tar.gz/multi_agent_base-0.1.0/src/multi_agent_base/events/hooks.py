"""
Lifecycle hooks for agents.

Provides hook points for agent lifecycle events.
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Coroutine


# Type alias for hook functions
HookFunction = Callable[..., Coroutine[Any, Any, Any]]


class LifecycleHook(str, Enum):
    """Agent lifecycle hook points."""
    
    # Agent lifecycle
    BEFORE_INIT = "before_init"
    AFTER_INIT = "after_init"
    BEFORE_RUN = "before_run"
    AFTER_RUN = "after_run"
    ON_ERROR = "on_error"
    
    # Message lifecycle
    BEFORE_MESSAGE = "before_message"
    AFTER_MESSAGE = "after_message"
    
    # Tool lifecycle
    BEFORE_TOOL_CALL = "before_tool_call"
    AFTER_TOOL_CALL = "after_tool_call"
    
    # LLM lifecycle
    BEFORE_LLM_CALL = "before_llm_call"
    AFTER_LLM_CALL = "after_llm_call"
    
    # Memory lifecycle
    BEFORE_MEMORY_ADD = "before_memory_add"
    AFTER_MEMORY_ADD = "after_memory_add"


@dataclass
class Hook:
    """A registered hook.
    
    Attributes:
        name: Hook point name
        handler: Handler function
        priority: Execution priority (lower = first)
        metadata: Additional metadata
    """
    
    name: str
    handler: HookFunction
    priority: int = 50
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class HookContext:
    """Context passed to hook handlers.
    
    Attributes:
        hook_name: Name of the hook
        agent_name: Name of the agent
        data: Hook-specific data
        cancelled: Whether to cancel the operation
        result: Modified result (for after hooks)
    """
    
    hook_name: str
    agent_name: str
    data: dict[str, Any] = field(default_factory=dict)
    cancelled: bool = False
    result: Any = None
    
    def cancel(self) -> None:
        """Cancel the operation (for before hooks)."""
        self.cancelled = True


class HookManager:
    """Manages lifecycle hooks for agents.
    
    Allows registering and executing hooks at various lifecycle points.
    
    Example:
        ```python
        hooks = HookManager()
        
        @hooks.on(LifecycleHook.BEFORE_RUN)
        async def log_start(ctx: HookContext):
            print(f"Agent {ctx.agent_name} starting")
        
        # In agent
        ctx = HookContext(
            hook_name=LifecycleHook.BEFORE_RUN,
            agent_name="my_agent",
        )
        await hooks.execute(LifecycleHook.BEFORE_RUN, ctx)
        ```
    """
    
    def __init__(self) -> None:
        """Initialize hook manager."""
        self._hooks: dict[str, list[Hook]] = {}
    
    def register(
        self,
        hook_name: str | LifecycleHook,
        handler: HookFunction,
        priority: int = 50,
        metadata: dict[str, Any] | None = None,
    ) -> Callable[[], None]:
        """Register a hook handler.
        
        Args:
            hook_name: Hook point name
            handler: Async handler function
            priority: Execution priority (lower = first)
            metadata: Additional metadata
            
        Returns:
            Unregister function
        """
        name = str(hook_name.value if isinstance(hook_name, LifecycleHook) else hook_name)
        
        hook = Hook(
            name=name,
            handler=handler,
            priority=priority,
            metadata=metadata or {},
        )
        
        if name not in self._hooks:
            self._hooks[name] = []
        
        self._hooks[name].append(hook)
        self._hooks[name].sort(key=lambda h: h.priority)
        
        def unregister() -> None:
            self.unregister(name, handler)
        
        return unregister
    
    def unregister(
        self,
        hook_name: str | LifecycleHook,
        handler: HookFunction,
    ) -> bool:
        """Unregister a hook handler.
        
        Args:
            hook_name: Hook point name
            handler: Handler to remove
            
        Returns:
            True if handler was removed
        """
        name = str(hook_name.value if isinstance(hook_name, LifecycleHook) else hook_name)
        
        if name not in self._hooks:
            return False
        
        for i, hook in enumerate(self._hooks[name]):
            if hook.handler == handler:
                self._hooks[name].pop(i)
                return True
        
        return False
    
    def on(
        self,
        hook_name: str | LifecycleHook,
        priority: int = 50,
    ) -> Callable[[HookFunction], HookFunction]:
        """Decorator to register a hook handler.
        
        Args:
            hook_name: Hook point name
            priority: Execution priority
            
        Returns:
            Decorator function
        """
        def decorator(handler: HookFunction) -> HookFunction:
            self.register(hook_name, handler, priority)
            return handler
        
        return decorator
    
    async def execute(
        self,
        hook_name: str | LifecycleHook,
        context: HookContext,
    ) -> HookContext:
        """Execute all handlers for a hook.
        
        Args:
            hook_name: Hook point name
            context: Hook context
            
        Returns:
            Modified context
        """
        name = str(hook_name.value if isinstance(hook_name, LifecycleHook) else hook_name)
        
        if name not in self._hooks:
            return context
        
        for hook in self._hooks[name]:
            if context.cancelled:
                break
            
            try:
                await hook.handler(context)
            except Exception as e:
                context.data["hook_error"] = str(e)
        
        return context
    
    def has_hooks(self, hook_name: str | LifecycleHook) -> bool:
        """Check if any hooks are registered.
        
        Args:
            hook_name: Hook point name
            
        Returns:
            True if hooks are registered
        """
        name = str(hook_name.value if isinstance(hook_name, LifecycleHook) else hook_name)
        return name in self._hooks and len(self._hooks[name]) > 0
    
    def clear(self, hook_name: str | LifecycleHook | None = None) -> None:
        """Clear hooks.
        
        Args:
            hook_name: Hook to clear (None = clear all)
        """
        if hook_name is None:
            self._hooks.clear()
        else:
            name = str(hook_name.value if isinstance(hook_name, LifecycleHook) else hook_name)
            if name in self._hooks:
                del self._hooks[name]


class AgentLifecycleHooks:
    """Pre-configured hooks for agent lifecycle.
    
    Provides a standard set of hooks for agent operations.
    
    Example:
        ```python
        class MyAgent(BaseAgent):
            def __init__(self):
                super().__init__()
                self.hooks = AgentLifecycleHooks()
            
            async def run(self, message: str):
                # Before run hook
                ctx = await self.hooks.before_run(
                    self.name,
                    {"message": message}
                )
                if ctx.cancelled:
                    return None
                
                result = await super().run(message)
                
                # After run hook
                await self.hooks.after_run(
                    self.name,
                    {"message": message, "result": result}
                )
                
                return result
        ```
    """
    
    def __init__(self) -> None:
        """Initialize agent lifecycle hooks."""
        self._manager = HookManager()
    
    @property
    def manager(self) -> HookManager:
        """Get the underlying hook manager."""
        return self._manager
    
    def on_before_run(
        self,
        handler: HookFunction,
        priority: int = 50,
    ) -> Callable[[], None]:
        """Register a before_run hook.
        
        Args:
            handler: Handler function
            priority: Priority
            
        Returns:
            Unregister function
        """
        return self._manager.register(LifecycleHook.BEFORE_RUN, handler, priority)
    
    def on_after_run(
        self,
        handler: HookFunction,
        priority: int = 50,
    ) -> Callable[[], None]:
        """Register an after_run hook.
        
        Args:
            handler: Handler function
            priority: Priority
            
        Returns:
            Unregister function
        """
        return self._manager.register(LifecycleHook.AFTER_RUN, handler, priority)
    
    def on_error(
        self,
        handler: HookFunction,
        priority: int = 50,
    ) -> Callable[[], None]:
        """Register an error hook.
        
        Args:
            handler: Handler function
            priority: Priority
            
        Returns:
            Unregister function
        """
        return self._manager.register(LifecycleHook.ON_ERROR, handler, priority)
    
    def on_before_tool_call(
        self,
        handler: HookFunction,
        priority: int = 50,
    ) -> Callable[[], None]:
        """Register a before_tool_call hook.
        
        Args:
            handler: Handler function
            priority: Priority
            
        Returns:
            Unregister function
        """
        return self._manager.register(LifecycleHook.BEFORE_TOOL_CALL, handler, priority)
    
    def on_after_tool_call(
        self,
        handler: HookFunction,
        priority: int = 50,
    ) -> Callable[[], None]:
        """Register an after_tool_call hook.
        
        Args:
            handler: Handler function
            priority: Priority
            
        Returns:
            Unregister function
        """
        return self._manager.register(LifecycleHook.AFTER_TOOL_CALL, handler, priority)
    
    async def before_run(
        self,
        agent_name: str,
        data: dict[str, Any],
    ) -> HookContext:
        """Execute before_run hooks.
        
        Args:
            agent_name: Agent name
            data: Hook data
            
        Returns:
            Hook context
        """
        ctx = HookContext(
            hook_name=LifecycleHook.BEFORE_RUN.value,
            agent_name=agent_name,
            data=data,
        )
        return await self._manager.execute(LifecycleHook.BEFORE_RUN, ctx)
    
    async def after_run(
        self,
        agent_name: str,
        data: dict[str, Any],
    ) -> HookContext:
        """Execute after_run hooks.
        
        Args:
            agent_name: Agent name
            data: Hook data
            
        Returns:
            Hook context
        """
        ctx = HookContext(
            hook_name=LifecycleHook.AFTER_RUN.value,
            agent_name=agent_name,
            data=data,
        )
        return await self._manager.execute(LifecycleHook.AFTER_RUN, ctx)
    
    async def on_agent_error(
        self,
        agent_name: str,
        error: Exception,
        data: dict[str, Any] | None = None,
    ) -> HookContext:
        """Execute error hooks.
        
        Args:
            agent_name: Agent name
            error: The exception
            data: Additional data
            
        Returns:
            Hook context
        """
        ctx = HookContext(
            hook_name=LifecycleHook.ON_ERROR.value,
            agent_name=agent_name,
            data={
                "error": str(error),
                "error_type": type(error).__name__,
                **(data or {}),
            },
        )
        return await self._manager.execute(LifecycleHook.ON_ERROR, ctx)
