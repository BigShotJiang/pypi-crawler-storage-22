"""
Human-in-the-Loop (HITL) Framework.

This module provides mechanisms for human oversight in AI agent operations:

- Approval System: Request human approval for critical operations
- Checkpoints: Pause workflows for human review
- Audit Trail: Log all human decisions
- Decorators: Easy integration with existing code

Example:
    ```python
    from multi_agent_base.hitl import require_approval, ApprovalHandler

    # Simple decorator usage
    @require_approval(reason="This will delete data")
    async def delete_records(count: int):
        return await db.delete(count)

    # Handler-based usage
    handler = ApprovalHandler(timeout=300)
    
    @handler.on_approved
    async def handle_approved(action, context):
        print(f"Approved: {action}")
    
    approved = await handler.request_approval(
        action="delete_records",
        context={"count": 1000},
    )
    ```
"""

from multi_agent_base.hitl.approval import (
    ApprovalHandler,
    ApprovalRequest,
    ApprovalResponse,
    ApprovalStatus,
    ConsoleApprovalHandler,
    require_approval,
    conditional_approval,
)
from multi_agent_base.hitl.checkpoint import (
    Checkpoint,
    CheckpointManager,
    CheckpointStatus,
    CheckpointState,
    WorkflowCheckpoint,
)
from multi_agent_base.hitl.audit import (
    AuditLogger,
    AuditEntry,
    AuditDecision,
    AuditSeverity,
    InMemoryAuditBackend,
    FileAuditBackend,
    ConsoleAuditBackend,
    create_audit_logger,
)

__all__ = [
    # Approval
    "ApprovalHandler",
    "ApprovalRequest",
    "ApprovalResponse",
    "ApprovalStatus",
    "ConsoleApprovalHandler",
    "require_approval",
    "conditional_approval",
    # Checkpoint
    "Checkpoint",
    "CheckpointManager",
    "CheckpointStatus",
    "CheckpointState",
    "WorkflowCheckpoint",
    # Audit
    "AuditLogger",
    "AuditEntry",
    "AuditDecision",
    "AuditSeverity",
    "InMemoryAuditBackend",
    "FileAuditBackend",
    "ConsoleAuditBackend",
    "create_audit_logger",
]
