"""
Approval System for Human-in-the-Loop operations.

This module provides:
- ApprovalHandler: Central approval management
- ApprovalRequest/Response: Data structures for approval flow
- Decorators: @require_approval, @conditional_approval
- Callbacks: on_approved, on_rejected, on_timeout
"""

from __future__ import annotations

import asyncio
import functools
import inspect
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import (
    Any,
    Awaitable,
    Callable,
    Dict,
    Generic,
    List,
    Optional,
    TypeVar,
    Union,
)


# =============================================================================
# Types
# =============================================================================

T = TypeVar("T")
ApprovalCallback = Callable[[str, Dict[str, Any]], Awaitable[None]]
ApprovalCondition = Callable[[Dict[str, Any]], bool]


class ApprovalStatus(str, Enum):
    """Status of an approval request."""
    
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    TIMEOUT = "timeout"
    CANCELLED = "cancelled"


# =============================================================================
# Data Classes
# =============================================================================


@dataclass
class ApprovalRequest:
    """Represents a request for human approval.
    
    Attributes:
        request_id: Unique identifier for the request
        action: Name of the action requiring approval
        reason: Why approval is needed
        context: Additional context for the approver
        created_at: When the request was created
        timeout: Timeout in seconds (None for no timeout)
        metadata: Additional metadata
    """
    
    request_id: str
    action: str
    reason: str
    context: Dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    timeout: float | None = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "request_id": self.request_id,
            "action": self.action,
            "reason": self.reason,
            "context": self.context,
            "created_at": self.created_at.isoformat(),
            "timeout": self.timeout,
            "metadata": self.metadata,
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ApprovalRequest":
        """Create from dictionary."""
        created_at = data.get("created_at")
        if isinstance(created_at, str):
            created_at = datetime.fromisoformat(created_at)
        
        return cls(
            request_id=data["request_id"],
            action=data["action"],
            reason=data["reason"],
            context=data.get("context", {}),
            created_at=created_at or datetime.now(timezone.utc),
            timeout=data.get("timeout"),
            metadata=data.get("metadata", {}),
        )


@dataclass
class ApprovalResponse:
    """Response to an approval request.
    
    Attributes:
        request_id: ID of the original request
        status: Approval status
        approver: Who made the decision (if applicable)
        reason: Reason for the decision
        responded_at: When the response was made
        metadata: Additional metadata
    """
    
    request_id: str
    status: ApprovalStatus
    approver: str | None = None
    reason: str | None = None
    responded_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    @property
    def is_approved(self) -> bool:
        """Check if request was approved."""
        return self.status == ApprovalStatus.APPROVED
    
    @property
    def is_rejected(self) -> bool:
        """Check if request was rejected."""
        return self.status == ApprovalStatus.REJECTED
    
    @property
    def is_timeout(self) -> bool:
        """Check if request timed out."""
        return self.status == ApprovalStatus.TIMEOUT
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "request_id": self.request_id,
            "status": self.status.value,
            "approver": self.approver,
            "reason": self.reason,
            "responded_at": self.responded_at.isoformat(),
            "metadata": self.metadata,
        }


# =============================================================================
# Approval Handler
# =============================================================================


class ApprovalHandler:
    """Central handler for approval requests.
    
    Manages the lifecycle of approval requests including:
    - Creating and tracking requests
    - Handling approvals/rejections
    - Timeout management
    - Callback invocation
    
    Attributes:
        timeout: Default timeout in seconds
        auto_approve: If True, auto-approve all requests (for testing)
        auto_reject: If True, auto-reject all requests (for testing)
    
    Example:
        ```python
        handler = ApprovalHandler(timeout=300)  # 5 minutes
        
        @handler.on_approved
        async def handle_approved(action, context):
            print(f"Approved: {action}")
        
        @handler.on_rejected
        async def handle_rejected(action, context):
            print(f"Rejected: {action}")
        
        # Request approval
        response = await handler.request_approval(
            action="delete_records",
            reason="Bulk deletion requested",
            context={"count": 1000, "table": "users"},
        )
        
        if response.is_approved:
            await delete_records()
        ```
    """
    
    def __init__(
        self,
        timeout: float = 300.0,  # 5 minutes default
        auto_approve: bool = False,
        auto_reject: bool = False,
    ) -> None:
        """Initialize approval handler.
        
        Args:
            timeout: Default timeout in seconds
            auto_approve: Auto-approve all requests (testing mode)
            auto_reject: Auto-reject all requests (testing mode)
        """
        self.timeout = timeout
        self.auto_approve = auto_approve
        self.auto_reject = auto_reject
        
        # Pending requests
        self._pending: Dict[str, ApprovalRequest] = {}
        self._responses: Dict[str, asyncio.Future[ApprovalResponse]] = {}
        
        # Callbacks
        self._on_approved_callbacks: List[ApprovalCallback] = []
        self._on_rejected_callbacks: List[ApprovalCallback] = []
        self._on_timeout_callbacks: List[ApprovalCallback] = []
        self._on_request_callbacks: List[ApprovalCallback] = []
    
    # =========================================================================
    # Callback Decorators
    # =========================================================================
    
    def on_approved(self, callback: ApprovalCallback) -> ApprovalCallback:
        """Register callback for approved requests.
        
        Args:
            callback: Async function(action, context) to call
            
        Returns:
            The callback (for decorator chaining)
        """
        self._on_approved_callbacks.append(callback)
        return callback
    
    def on_rejected(self, callback: ApprovalCallback) -> ApprovalCallback:
        """Register callback for rejected requests.
        
        Args:
            callback: Async function(action, context) to call
            
        Returns:
            The callback (for decorator chaining)
        """
        self._on_rejected_callbacks.append(callback)
        return callback
    
    def on_timeout(self, callback: ApprovalCallback) -> ApprovalCallback:
        """Register callback for timed out requests.
        
        Args:
            callback: Async function(action, context) to call
            
        Returns:
            The callback (for decorator chaining)
        """
        self._on_timeout_callbacks.append(callback)
        return callback
    
    def on_request(self, callback: ApprovalCallback) -> ApprovalCallback:
        """Register callback for new approval requests.
        
        Args:
            callback: Async function(action, context) to call
            
        Returns:
            The callback (for decorator chaining)
        """
        self._on_request_callbacks.append(callback)
        return callback
    
    # =========================================================================
    # Request Management
    # =========================================================================
    
    async def request_approval(
        self,
        action: str,
        reason: str = "",
        context: Dict[str, Any] | None = None,
        timeout: float | None = None,
        metadata: Dict[str, Any] | None = None,
    ) -> ApprovalResponse:
        """Request approval for an action.
        
        This method will block until:
        1. The request is approved via approve()
        2. The request is rejected via reject()
        3. The timeout is reached
        
        Args:
            action: Name of the action requiring approval
            reason: Why approval is needed
            context: Additional context for the approver
            timeout: Override default timeout (None uses handler default)
            metadata: Additional metadata
            
        Returns:
            ApprovalResponse with the decision
        """
        # Handle auto modes
        if self.auto_approve:
            response = ApprovalResponse(
                request_id=str(uuid.uuid4()),
                status=ApprovalStatus.APPROVED,
                approver="auto",
                reason="Auto-approved (testing mode)",
            )
            # Still fire callbacks for testing
            await self._fire_callbacks(
                self._on_approved_callbacks,
                action,
                context or {},
            )
            return response
        
        if self.auto_reject:
            response = ApprovalResponse(
                request_id=str(uuid.uuid4()),
                status=ApprovalStatus.REJECTED,
                approver="auto",
                reason="Auto-rejected (testing mode)",
            )
            # Still fire callbacks for testing
            await self._fire_callbacks(
                self._on_rejected_callbacks,
                action,
                context or {},
            )
            return response
        
        # Create request
        request = ApprovalRequest(
            request_id=str(uuid.uuid4()),
            action=action,
            reason=reason or f"Approval required for: {action}",
            context=context or {},
            timeout=timeout or self.timeout,
            metadata=metadata or {},
        )
        
        # Store request and create future
        self._pending[request.request_id] = request
        future: asyncio.Future[ApprovalResponse] = asyncio.Future()
        self._responses[request.request_id] = future
        
        # Fire on_request callbacks
        await self._fire_callbacks(
            self._on_request_callbacks,
            action,
            {"request": request.to_dict(), **(context or {})},
        )
        
        # Wait for response with timeout
        effective_timeout = timeout or self.timeout
        try:
            response = await asyncio.wait_for(future, timeout=effective_timeout)
            
            # Fire appropriate callbacks
            if response.is_approved:
                await self._fire_callbacks(
                    self._on_approved_callbacks,
                    action,
                    context or {},
                )
            elif response.is_rejected:
                await self._fire_callbacks(
                    self._on_rejected_callbacks,
                    action,
                    context or {},
                )
            
            return response
            
        except asyncio.TimeoutError:
            # Timeout - create timeout response
            response = ApprovalResponse(
                request_id=request.request_id,
                status=ApprovalStatus.TIMEOUT,
                reason=f"Request timed out after {effective_timeout} seconds",
            )
            
            await self._fire_callbacks(
                self._on_timeout_callbacks,
                action,
                context or {},
            )
            
            return response
            
        finally:
            # Cleanup
            self._pending.pop(request.request_id, None)
            self._responses.pop(request.request_id, None)
    
    async def approve(
        self,
        request_id: str,
        approver: str | None = None,
        reason: str | None = None,
    ) -> bool:
        """Approve a pending request.
        
        Args:
            request_id: ID of the request to approve
            approver: Who is approving
            reason: Reason for approval
            
        Returns:
            True if request was approved, False if not found
        """
        future = self._responses.get(request_id)
        if future is None or future.done():
            return False
        
        response = ApprovalResponse(
            request_id=request_id,
            status=ApprovalStatus.APPROVED,
            approver=approver,
            reason=reason,
        )
        future.set_result(response)
        return True
    
    async def reject(
        self,
        request_id: str,
        approver: str | None = None,
        reason: str | None = None,
    ) -> bool:
        """Reject a pending request.
        
        Args:
            request_id: ID of the request to reject
            approver: Who is rejecting
            reason: Reason for rejection
            
        Returns:
            True if request was rejected, False if not found
        """
        future = self._responses.get(request_id)
        if future is None or future.done():
            return False
        
        response = ApprovalResponse(
            request_id=request_id,
            status=ApprovalStatus.REJECTED,
            approver=approver,
            reason=reason,
        )
        future.set_result(response)
        return True
    
    async def cancel(self, request_id: str) -> bool:
        """Cancel a pending request.
        
        Args:
            request_id: ID of the request to cancel
            
        Returns:
            True if request was cancelled, False if not found
        """
        future = self._responses.get(request_id)
        if future is None or future.done():
            return False
        
        response = ApprovalResponse(
            request_id=request_id,
            status=ApprovalStatus.CANCELLED,
            reason="Request cancelled",
        )
        future.set_result(response)
        return True
    
    # =========================================================================
    # Query Methods
    # =========================================================================
    
    def get_pending_requests(self) -> List[ApprovalRequest]:
        """Get all pending approval requests.
        
        Returns:
            List of pending requests
        """
        return list(self._pending.values())
    
    def get_pending_request(self, request_id: str) -> ApprovalRequest | None:
        """Get a specific pending request.
        
        Args:
            request_id: Request ID
            
        Returns:
            Request or None
        """
        return self._pending.get(request_id)
    
    def has_pending_requests(self) -> bool:
        """Check if there are pending requests.
        
        Returns:
            True if there are pending requests
        """
        return len(self._pending) > 0
    
    @property
    def pending_count(self) -> int:
        """Get number of pending requests."""
        return len(self._pending)
    
    # =========================================================================
    # Helper Methods
    # =========================================================================
    
    async def _fire_callbacks(
        self,
        callbacks: List[ApprovalCallback],
        action: str,
        context: Dict[str, Any],
    ) -> None:
        """Fire a list of callbacks."""
        for callback in callbacks:
            try:
                await callback(action, context)
            except Exception as e:
                # Log but don't fail
                print(f"Callback error: {e}")


# =============================================================================
# Decorators
# =============================================================================


def require_approval(
    reason: str | None = None,
    handler: ApprovalHandler | None = None,
    timeout: float | None = None,
    on_rejected: Callable[..., Any] | None = None,
    on_timeout: Callable[..., Any] | None = None,
) -> Callable[[Callable[..., T]], Callable[..., Awaitable[T | None]]]:
    """Decorator to require approval before executing a function.
    
    Args:
        reason: Reason for requiring approval
        handler: ApprovalHandler to use (creates default if None)
        timeout: Timeout in seconds
        on_rejected: Function to call if rejected
        on_timeout: Function to call on timeout
    
    Returns:
        Decorated function
    
    Example:
        ```python
        @require_approval(reason="This will delete data")
        async def delete_records(count: int):
            return await db.delete(count)
        
        # Calling will wait for approval
        result = await delete_records(100)
        ```
    """
    _handler = handler or ApprovalHandler(timeout=timeout or 300.0)
    
    def decorator(func: Callable[..., T]) -> Callable[..., Awaitable[T | None]]:
        @functools.wraps(func)
        async def wrapper(*args: Any, **kwargs: Any) -> T | None:
            # Build context from function arguments
            context = {
                "function": func.__name__,
                "args": str(args),
                "kwargs": kwargs,
            }
            
            # Request approval
            response = await _handler.request_approval(
                action=func.__name__,
                reason=reason or f"Approval required for {func.__name__}",
                context=context,
                timeout=timeout,
            )
            
            if response.is_approved:
                # Execute the function
                if inspect.iscoroutinefunction(func):
                    return await func(*args, **kwargs)
                else:
                    return func(*args, **kwargs)
            
            elif response.is_rejected:
                if on_rejected:
                    if inspect.iscoroutinefunction(on_rejected):
                        return await on_rejected(*args, **kwargs)
                    else:
                        return on_rejected(*args, **kwargs)
                return None
            
            else:  # Timeout or cancelled
                if on_timeout:
                    if inspect.iscoroutinefunction(on_timeout):
                        return await on_timeout(*args, **kwargs)
                    else:
                        return on_timeout(*args, **kwargs)
                return None
        
        # Attach handler for external access
        wrapper._approval_handler = _handler  # type: ignore
        return wrapper
    
    return decorator


def conditional_approval(
    condition: ApprovalCondition,
    reason: str | None = None,
    handler: ApprovalHandler | None = None,
    timeout: float | None = None,
) -> Callable[[Callable[..., T]], Callable[..., Awaitable[T]]]:
    """Decorator to conditionally require approval.
    
    Only requests approval if the condition returns True.
    
    Args:
        condition: Function that returns True if approval needed
        reason: Reason for requiring approval
        handler: ApprovalHandler to use
        timeout: Timeout in seconds
    
    Returns:
        Decorated function
    
    Example:
        ```python
        @conditional_approval(
            condition=lambda ctx: ctx.get("cost", 0) > 100,
            reason="High-cost operation",
        )
        async def process_order(order: dict):
            return await api.process(order)
        
        # Low cost - no approval needed
        await process_order({"cost": 50})
        
        # High cost - approval required
        await process_order({"cost": 200})
        ```
    """
    _handler = handler or ApprovalHandler(timeout=timeout or 300.0)
    
    def decorator(func: Callable[..., T]) -> Callable[..., Awaitable[T]]:
        @functools.wraps(func)
        async def wrapper(*args: Any, **kwargs: Any) -> T:
            # Build context
            context = {
                "function": func.__name__,
                "args": str(args),
                **kwargs,
            }
            
            # Check condition
            if condition(context):
                # Approval needed
                response = await _handler.request_approval(
                    action=func.__name__,
                    reason=reason or f"Conditional approval for {func.__name__}",
                    context=context,
                    timeout=timeout,
                )
                
                if not response.is_approved:
                    raise PermissionError(
                        f"Approval denied for {func.__name__}: {response.reason}"
                    )
            
            # Execute the function
            if inspect.iscoroutinefunction(func):
                return await func(*args, **kwargs)
            else:
                return func(*args, **kwargs)
        
        wrapper._approval_handler = _handler  # type: ignore
        return wrapper
    
    return decorator


# =============================================================================
# Console-based Approval Handler
# =============================================================================


class ConsoleApprovalHandler(ApprovalHandler):
    """Approval handler that prompts in the console.
    
    Useful for CLI applications and testing.
    
    Example:
        ```python
        handler = ConsoleApprovalHandler()
        
        response = await handler.request_approval(
            action="delete_all",
            reason="This will delete all records",
        )
        # User will see:
        # ⚠️  Approval Required: delete_all
        # Reason: This will delete all records
        # Approve? [y/N]:
        ```
    """
    
    def __init__(self, timeout: float = 300.0) -> None:
        super().__init__(timeout=timeout)
        
        # Register console prompt as request callback
        @self.on_request
        async def prompt_console(action: str, context: Dict[str, Any]) -> None:
            request = context.get("request", {})
            request_id = request.get("request_id")
            reason = request.get("reason", "")
            
            print(f"\n⚠️  Approval Required: {action}")
            print(f"   Reason: {reason}")
            if request.get("context"):
                print(f"   Context: {request.get('context')}")
            
            # Run input in thread to not block
            loop = asyncio.get_event_loop()
            response = await loop.run_in_executor(
                None,
                lambda: input("   Approve? [y/N]: ").strip().lower(),
            )
            
            if response in ("y", "yes"):
                await self.approve(request_id, approver="console")
            else:
                await self.reject(request_id, approver="console", reason="User rejected")
