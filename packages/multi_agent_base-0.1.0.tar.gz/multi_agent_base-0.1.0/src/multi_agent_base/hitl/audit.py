"""
Audit Logging for Human-in-the-Loop operations.

This module provides:
- AuditLogger: Log all human decisions
- AuditEntry: Individual audit records
- Multiple output backends (file, JSON, console)
"""

from __future__ import annotations

import asyncio
import json
import os
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import (
    Any,
    Callable,
    Dict,
    List,
    Optional,
    Protocol,
    Union,
)


# =============================================================================
# Types
# =============================================================================


class AuditDecision(str, Enum):
    """Types of audit decisions."""
    
    APPROVED = "approved"
    REJECTED = "rejected"
    TIMEOUT = "timeout"
    CANCELLED = "cancelled"
    RESUMED = "resumed"
    SKIPPED = "skipped"
    ERROR = "error"


class AuditSeverity(str, Enum):
    """Severity levels for audit entries."""
    
    INFO = "info"
    WARNING = "warning"
    CRITICAL = "critical"


# =============================================================================
# Data Classes
# =============================================================================


@dataclass
class AuditEntry:
    """Represents a single audit log entry.
    
    Attributes:
        entry_id: Unique identifier
        action: Action that was audited
        decision: Decision made (approved, rejected, etc.)
        user: Who made the decision
        timestamp: When the decision was made
        context: Additional context
        reason: Reason for the decision
        severity: Entry severity level
        metadata: Additional metadata
    """
    
    entry_id: str = field(default_factory=lambda: str(__import__("uuid").uuid4()))
    action: str = ""
    decision: AuditDecision = AuditDecision.APPROVED
    user: str | None = None
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    context: Dict[str, Any] = field(default_factory=dict)
    reason: str | None = None
    severity: AuditSeverity = AuditSeverity.INFO
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "entry_id": self.entry_id,
            "action": self.action,
            "decision": self.decision.value,
            "user": self.user,
            "timestamp": self.timestamp.isoformat(),
            "context": self.context,
            "reason": self.reason,
            "severity": self.severity.value,
            "metadata": self.metadata,
        }
    
    def to_json(self, indent: int | None = None) -> str:
        """Convert to JSON string."""
        return json.dumps(self.to_dict(), indent=indent, ensure_ascii=False)
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "AuditEntry":
        """Create from dictionary."""
        timestamp = data.get("timestamp")
        if isinstance(timestamp, str):
            timestamp = datetime.fromisoformat(timestamp)
        
        return cls(
            entry_id=data.get("entry_id", ""),
            action=data.get("action", ""),
            decision=AuditDecision(data.get("decision", "approved")),
            user=data.get("user"),
            timestamp=timestamp or datetime.now(timezone.utc),
            context=data.get("context", {}),
            reason=data.get("reason"),
            severity=AuditSeverity(data.get("severity", "info")),
            metadata=data.get("metadata", {}),
        )
    
    def __str__(self) -> str:
        return (
            f"[{self.timestamp.isoformat()}] "
            f"{self.severity.value.upper()}: "
            f"{self.action} - {self.decision.value} "
            f"by {self.user or 'unknown'}"
        )


# =============================================================================
# Audit Backend Protocol
# =============================================================================


class AuditBackend(Protocol):
    """Protocol for audit logging backends."""
    
    async def write(self, entry: AuditEntry) -> None:
        """Write an audit entry."""
        ...
    
    async def read_all(self) -> List[AuditEntry]:
        """Read all audit entries."""
        ...
    
    async def query(
        self,
        action: str | None = None,
        user: str | None = None,
        decision: AuditDecision | None = None,
        start_time: datetime | None = None,
        end_time: datetime | None = None,
    ) -> List[AuditEntry]:
        """Query audit entries."""
        ...


# =============================================================================
# Audit Backends
# =============================================================================


class InMemoryAuditBackend:
    """In-memory audit backend for testing."""
    
    def __init__(self) -> None:
        self._entries: List[AuditEntry] = []
    
    async def write(self, entry: AuditEntry) -> None:
        """Write entry to memory."""
        self._entries.append(entry)
    
    async def read_all(self) -> List[AuditEntry]:
        """Read all entries."""
        return list(self._entries)
    
    async def query(
        self,
        action: str | None = None,
        user: str | None = None,
        decision: AuditDecision | None = None,
        start_time: datetime | None = None,
        end_time: datetime | None = None,
    ) -> List[AuditEntry]:
        """Query entries with filters."""
        results = []
        for entry in self._entries:
            if action and entry.action != action:
                continue
            if user and entry.user != user:
                continue
            if decision and entry.decision != decision:
                continue
            if start_time and entry.timestamp < start_time:
                continue
            if end_time and entry.timestamp > end_time:
                continue
            results.append(entry)
        return results
    
    def clear(self) -> None:
        """Clear all entries."""
        self._entries.clear()


class FileAuditBackend:
    """File-based audit backend (JSON lines format)."""
    
    def __init__(self, path: str = "./audit.jsonl") -> None:
        """Initialize file backend.
        
        Args:
            path: Path to audit log file
        """
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
    
    async def write(self, entry: AuditEntry) -> None:
        """Append entry to file."""
        def _write():
            with open(self.path, "a", encoding="utf-8") as f:
                f.write(entry.to_json() + "\n")
        
        await asyncio.get_event_loop().run_in_executor(None, _write)
    
    async def read_all(self) -> List[AuditEntry]:
        """Read all entries from file."""
        if not self.path.exists():
            return []
        
        def _read():
            entries = []
            with open(self.path, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if line:
                        entries.append(AuditEntry.from_dict(json.loads(line)))
            return entries
        
        return await asyncio.get_event_loop().run_in_executor(None, _read)
    
    async def query(
        self,
        action: str | None = None,
        user: str | None = None,
        decision: AuditDecision | None = None,
        start_time: datetime | None = None,
        end_time: datetime | None = None,
    ) -> List[AuditEntry]:
        """Query entries with filters."""
        all_entries = await self.read_all()
        results = []
        
        for entry in all_entries:
            if action and entry.action != action:
                continue
            if user and entry.user != user:
                continue
            if decision and entry.decision != decision:
                continue
            if start_time and entry.timestamp < start_time:
                continue
            if end_time and entry.timestamp > end_time:
                continue
            results.append(entry)
        
        return results


class ConsoleAuditBackend:
    """Console output backend for debugging."""
    
    def __init__(self, color: bool = True) -> None:
        """Initialize console backend.
        
        Args:
            color: Enable colored output
        """
        self.color = color
        self._entries: List[AuditEntry] = []
    
    async def write(self, entry: AuditEntry) -> None:
        """Write entry to console."""
        self._entries.append(entry)
        
        # Color codes
        colors = {
            AuditDecision.APPROVED: "\033[92m",  # Green
            AuditDecision.REJECTED: "\033[91m",  # Red
            AuditDecision.TIMEOUT: "\033[93m",   # Yellow
            AuditDecision.ERROR: "\033[91m",     # Red
        }
        reset = "\033[0m"
        
        if self.color:
            color = colors.get(entry.decision, "")
            print(f"{color}[AUDIT] {entry}{reset}")
        else:
            print(f"[AUDIT] {entry}")
    
    async def read_all(self) -> List[AuditEntry]:
        """Read all entries."""
        return list(self._entries)
    
    async def query(
        self,
        action: str | None = None,
        user: str | None = None,
        decision: AuditDecision | None = None,
        start_time: datetime | None = None,
        end_time: datetime | None = None,
    ) -> List[AuditEntry]:
        """Query entries with filters."""
        results = []
        for entry in self._entries:
            if action and entry.action != action:
                continue
            if user and entry.user != user:
                continue
            if decision and entry.decision != decision:
                continue
            if start_time and entry.timestamp < start_time:
                continue
            if end_time and entry.timestamp > end_time:
                continue
            results.append(entry)
        return results


# =============================================================================
# Audit Logger
# =============================================================================


class AuditLogger:
    """Central audit logger for HITL operations.
    
    Logs all human decisions with full context for:
    - Compliance requirements
    - Debugging and troubleshooting
    - Analytics and reporting
    
    Attributes:
        backends: List of output backends
        default_severity: Default severity for entries
    
    Example:
        ```python
        # Create logger with file and console output
        logger = AuditLogger(backends=[
            FileAuditBackend("./audit.jsonl"),
            ConsoleAuditBackend(),
        ])
        
        # Log an approval
        await logger.log_approval(
            action="delete_records",
            user="admin@example.com",
            context={"count": 1000},
            reason="Approved after review",
        )
        
        # Query audit trail
        entries = await logger.query(
            action="delete_records",
            decision=AuditDecision.APPROVED,
        )
        ```
    """
    
    def __init__(
        self,
        backends: List[AuditBackend] | None = None,
        default_severity: AuditSeverity = AuditSeverity.INFO,
    ) -> None:
        """Initialize audit logger.
        
        Args:
            backends: Output backends (creates InMemory if None)
            default_severity: Default severity level
        """
        self.backends: List[AuditBackend] = backends or [InMemoryAuditBackend()]
        self.default_severity = default_severity
    
    # =========================================================================
    # Logging Methods
    # =========================================================================
    
    async def log(self, entry: AuditEntry) -> None:
        """Log an audit entry.
        
        Args:
            entry: Entry to log
        """
        for backend in self.backends:
            await backend.write(entry)
    
    async def log_approval(
        self,
        action: str,
        user: str | None = None,
        context: Dict[str, Any] | None = None,
        reason: str | None = None,
        severity: AuditSeverity | None = None,
        metadata: Dict[str, Any] | None = None,
    ) -> AuditEntry:
        """Log an approval decision.
        
        Args:
            action: Action that was approved
            user: Who approved
            context: Action context
            reason: Approval reason
            severity: Entry severity
            metadata: Additional metadata
            
        Returns:
            Created audit entry
        """
        entry = AuditEntry(
            action=action,
            decision=AuditDecision.APPROVED,
            user=user,
            context=context or {},
            reason=reason,
            severity=severity or self.default_severity,
            metadata=metadata or {},
        )
        await self.log(entry)
        return entry
    
    async def log_rejection(
        self,
        action: str,
        user: str | None = None,
        context: Dict[str, Any] | None = None,
        reason: str | None = None,
        severity: AuditSeverity | None = None,
        metadata: Dict[str, Any] | None = None,
    ) -> AuditEntry:
        """Log a rejection decision.
        
        Args:
            action: Action that was rejected
            user: Who rejected
            context: Action context
            reason: Rejection reason
            severity: Entry severity
            metadata: Additional metadata
            
        Returns:
            Created audit entry
        """
        entry = AuditEntry(
            action=action,
            decision=AuditDecision.REJECTED,
            user=user,
            context=context or {},
            reason=reason,
            severity=severity or AuditSeverity.WARNING,
            metadata=metadata or {},
        )
        await self.log(entry)
        return entry
    
    async def log_timeout(
        self,
        action: str,
        context: Dict[str, Any] | None = None,
        timeout_seconds: float | None = None,
        metadata: Dict[str, Any] | None = None,
    ) -> AuditEntry:
        """Log a timeout.
        
        Args:
            action: Action that timed out
            context: Action context
            timeout_seconds: Timeout duration
            metadata: Additional metadata
            
        Returns:
            Created audit entry
        """
        entry = AuditEntry(
            action=action,
            decision=AuditDecision.TIMEOUT,
            context=context or {},
            reason=f"Timed out after {timeout_seconds}s" if timeout_seconds else "Timed out",
            severity=AuditSeverity.WARNING,
            metadata=metadata or {},
        )
        await self.log(entry)
        return entry
    
    async def log_resume(
        self,
        action: str,
        user: str | None = None,
        context: Dict[str, Any] | None = None,
        resume_data: Dict[str, Any] | None = None,
        metadata: Dict[str, Any] | None = None,
    ) -> AuditEntry:
        """Log a workflow resume.
        
        Args:
            action: Checkpoint/workflow that was resumed
            user: Who resumed
            context: Checkpoint context
            resume_data: Data provided on resume
            metadata: Additional metadata
            
        Returns:
            Created audit entry
        """
        entry = AuditEntry(
            action=action,
            decision=AuditDecision.RESUMED,
            user=user,
            context={**(context or {}), "resume_data": resume_data},
            severity=self.default_severity,
            metadata=metadata or {},
        )
        await self.log(entry)
        return entry
    
    async def log_error(
        self,
        action: str,
        error: str | Exception,
        context: Dict[str, Any] | None = None,
        metadata: Dict[str, Any] | None = None,
    ) -> AuditEntry:
        """Log an error.
        
        Args:
            action: Action that errored
            error: Error message or exception
            context: Action context
            metadata: Additional metadata
            
        Returns:
            Created audit entry
        """
        entry = AuditEntry(
            action=action,
            decision=AuditDecision.ERROR,
            context=context or {},
            reason=str(error),
            severity=AuditSeverity.CRITICAL,
            metadata=metadata or {},
        )
        await self.log(entry)
        return entry
    
    # =========================================================================
    # Query Methods
    # =========================================================================
    
    async def query(
        self,
        action: str | None = None,
        user: str | None = None,
        decision: AuditDecision | None = None,
        start_time: datetime | None = None,
        end_time: datetime | None = None,
    ) -> List[AuditEntry]:
        """Query audit entries.
        
        Args:
            action: Filter by action
            user: Filter by user
            decision: Filter by decision
            start_time: Filter by start time
            end_time: Filter by end time
            
        Returns:
            Matching audit entries
        """
        # Query first backend (primary)
        if self.backends:
            return await self.backends[0].query(
                action=action,
                user=user,
                decision=decision,
                start_time=start_time,
                end_time=end_time,
            )
        return []
    
    async def get_all(self) -> List[AuditEntry]:
        """Get all audit entries.
        
        Returns:
            All entries from primary backend
        """
        if self.backends:
            return await self.backends[0].read_all()
        return []
    
    async def get_recent(self, count: int = 10) -> List[AuditEntry]:
        """Get recent audit entries.
        
        Args:
            count: Number of entries to return
            
        Returns:
            Most recent entries
        """
        all_entries = await self.get_all()
        return all_entries[-count:]
    
    # =========================================================================
    # Statistics
    # =========================================================================
    
    async def get_stats(self) -> Dict[str, Any]:
        """Get audit statistics.
        
        Returns:
            Statistics dictionary
        """
        entries = await self.get_all()
        
        by_decision = {}
        by_action = {}
        by_user = {}
        
        for entry in entries:
            # By decision
            dec = entry.decision.value
            by_decision[dec] = by_decision.get(dec, 0) + 1
            
            # By action
            by_action[entry.action] = by_action.get(entry.action, 0) + 1
            
            # By user
            user = entry.user or "unknown"
            by_user[user] = by_user.get(user, 0) + 1
        
        return {
            "total_entries": len(entries),
            "by_decision": by_decision,
            "by_action": by_action,
            "by_user": by_user,
            "approval_rate": (
                by_decision.get("approved", 0) / len(entries)
                if entries else 0
            ),
        }


# =============================================================================
# Factory Function
# =============================================================================


def create_audit_logger(
    file_path: str | None = None,
    console: bool = False,
    in_memory: bool = True,
) -> AuditLogger:
    """Create an audit logger with common configurations.
    
    Args:
        file_path: Path for file logging (None to disable)
        console: Enable console output
        in_memory: Enable in-memory storage
        
    Returns:
        Configured AuditLogger
    """
    backends: List[AuditBackend] = []
    
    if in_memory:
        backends.append(InMemoryAuditBackend())
    
    if file_path:
        backends.append(FileAuditBackend(file_path))
    
    if console:
        backends.append(ConsoleAuditBackend())
    
    return AuditLogger(backends=backends)
