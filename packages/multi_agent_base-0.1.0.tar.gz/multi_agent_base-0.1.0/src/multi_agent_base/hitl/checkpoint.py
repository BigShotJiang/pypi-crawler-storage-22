"""
Checkpoint System for Human-in-the-Loop workflows.

This module provides:
- Checkpoint: Pause point in a workflow
- CheckpointManager: Manage multiple checkpoints
- WorkflowCheckpoint: Integration with workflow system
"""

from __future__ import annotations

import asyncio
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import (
    Any,
    Awaitable,
    Callable,
    Dict,
    Generic,
    List,
    Optional,
    TypeVar,
)


# =============================================================================
# Types
# =============================================================================

T = TypeVar("T")
ResumeCallback = Callable[[Dict[str, Any]], Awaitable[None]]


class CheckpointStatus(str, Enum):
    """Status of a checkpoint."""
    
    PENDING = "pending"      # Created but not paused yet
    PAUSED = "paused"        # Workflow is paused at this checkpoint
    RESUMED = "resumed"      # Checkpoint was resumed
    SKIPPED = "skipped"      # Checkpoint was skipped
    EXPIRED = "expired"      # Checkpoint expired without resume


# =============================================================================
# Data Classes
# =============================================================================


@dataclass
class CheckpointState:
    """State captured at a checkpoint.
    
    Attributes:
        data: Arbitrary state data
        context: Execution context
        metadata: Additional metadata
    """
    
    data: Dict[str, Any] = field(default_factory=dict)
    context: Dict[str, Any] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "data": self.data,
            "context": self.context,
            "metadata": self.metadata,
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "CheckpointState":
        """Create from dictionary."""
        return cls(
            data=data.get("data", {}),
            context=data.get("context", {}),
            metadata=data.get("metadata", {}),
        )


# =============================================================================
# Checkpoint
# =============================================================================


@dataclass
class Checkpoint:
    """Represents a pause point in a workflow.
    
    Checkpoints allow workflows to be paused for human review
    and then resumed with optional modifications.
    
    Attributes:
        checkpoint_id: Unique identifier
        name: Human-readable name
        workflow_id: ID of the parent workflow
        step_name: Name of the step being paused
        status: Current checkpoint status
        state: Captured state at pause
        created_at: When checkpoint was created
        paused_at: When workflow was paused
        resumed_at: When workflow was resumed
        expires_at: When checkpoint expires
        resume_data: Data provided on resume
    
    Example:
        ```python
        checkpoint = Checkpoint(
            name="review_results",
            workflow_id="wf_123",
            step_name="analyze_data",
        )
        
        # Pause the workflow
        await checkpoint.pause(state={"results": analysis_results})
        
        # Later, resume with modifications
        await checkpoint.resume(data={"approved": True, "notes": "Looks good"})
        ```
    """
    
    checkpoint_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = ""
    workflow_id: str = ""
    step_name: str = ""
    status: CheckpointStatus = CheckpointStatus.PENDING
    state: CheckpointState = field(default_factory=CheckpointState)
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    paused_at: datetime | None = None
    resumed_at: datetime | None = None
    expires_at: datetime | None = None
    resume_data: Dict[str, Any] = field(default_factory=dict)
    
    # Internal
    _resume_event: asyncio.Event = field(default_factory=asyncio.Event, repr=False)
    _on_resume_callbacks: List[ResumeCallback] = field(default_factory=list, repr=False)
    
    def __post_init__(self):
        """Initialize event if not set."""
        if not hasattr(self, "_resume_event") or self._resume_event is None:
            self._resume_event = asyncio.Event()
        if not hasattr(self, "_on_resume_callbacks"):
            self._on_resume_callbacks = []
    
    # =========================================================================
    # Core Methods
    # =========================================================================
    
    async def pause(
        self,
        state: Dict[str, Any] | None = None,
        context: Dict[str, Any] | None = None,
        timeout: float | None = None,
    ) -> Dict[str, Any]:
        """Pause at this checkpoint and wait for resume.
        
        Args:
            state: State data to capture
            context: Execution context
            timeout: Timeout in seconds (None for no timeout)
            
        Returns:
            Resume data provided when resumed
            
        Raises:
            asyncio.TimeoutError: If timeout is reached
        """
        # Update state
        self.state = CheckpointState(
            data=state or {},
            context=context or {},
            metadata={"paused_by": "pause()"},
        )
        self.status = CheckpointStatus.PAUSED
        self.paused_at = datetime.now(timezone.utc)
        
        # Reset event
        self._resume_event.clear()
        
        # Wait for resume
        if timeout:
            try:
                await asyncio.wait_for(self._resume_event.wait(), timeout=timeout)
            except asyncio.TimeoutError:
                self.status = CheckpointStatus.EXPIRED
                raise
        else:
            await self._resume_event.wait()
        
        return self.resume_data
    
    async def resume(
        self,
        data: Dict[str, Any] | None = None,
        resuming_user: str | None = None,
    ) -> None:
        """Resume from this checkpoint.
        
        Args:
            data: Data to pass to the paused workflow
            resuming_user: Who is resuming the workflow
        """
        self.resume_data = data or {}
        self.resume_data["_resuming_user"] = resuming_user
        self.resumed_at = datetime.now(timezone.utc)
        self.status = CheckpointStatus.RESUMED
        
        # Fire callbacks
        for callback in self._on_resume_callbacks:
            try:
                await callback(self.resume_data)
            except Exception as e:
                print(f"Resume callback error: {e}")
        
        # Signal resume
        self._resume_event.set()
    
    def skip(self) -> None:
        """Skip this checkpoint without pausing."""
        self.status = CheckpointStatus.SKIPPED
    
    # =========================================================================
    # Callback Registration
    # =========================================================================
    
    def on_resume(self, callback: ResumeCallback) -> ResumeCallback:
        """Register callback for resume event.
        
        Args:
            callback: Async function(resume_data) to call
            
        Returns:
            The callback (for decorator chaining)
        """
        self._on_resume_callbacks.append(callback)
        return callback
    
    # =========================================================================
    # Status Checks
    # =========================================================================
    
    @property
    def is_pending(self) -> bool:
        """Check if checkpoint is pending."""
        return self.status == CheckpointStatus.PENDING
    
    @property
    def is_paused(self) -> bool:
        """Check if checkpoint is paused."""
        return self.status == CheckpointStatus.PAUSED
    
    @property
    def is_resumed(self) -> bool:
        """Check if checkpoint was resumed."""
        return self.status == CheckpointStatus.RESUMED
    
    @property
    def is_expired(self) -> bool:
        """Check if checkpoint expired."""
        return self.status == CheckpointStatus.EXPIRED
    
    @property
    def duration(self) -> float | None:
        """Get duration in seconds from pause to resume."""
        if self.paused_at and self.resumed_at:
            return (self.resumed_at - self.paused_at).total_seconds()
        return None
    
    # =========================================================================
    # Serialization
    # =========================================================================
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "checkpoint_id": self.checkpoint_id,
            "name": self.name,
            "workflow_id": self.workflow_id,
            "step_name": self.step_name,
            "status": self.status.value,
            "state": self.state.to_dict(),
            "created_at": self.created_at.isoformat(),
            "paused_at": self.paused_at.isoformat() if self.paused_at else None,
            "resumed_at": self.resumed_at.isoformat() if self.resumed_at else None,
            "expires_at": self.expires_at.isoformat() if self.expires_at else None,
            "resume_data": self.resume_data,
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Checkpoint":
        """Create from dictionary."""
        def parse_dt(val: Any) -> datetime | None:
            if val is None:
                return None
            if isinstance(val, str):
                return datetime.fromisoformat(val)
            return val
        
        return cls(
            checkpoint_id=data["checkpoint_id"],
            name=data.get("name", ""),
            workflow_id=data.get("workflow_id", ""),
            step_name=data.get("step_name", ""),
            status=CheckpointStatus(data.get("status", "pending")),
            state=CheckpointState.from_dict(data.get("state", {})),
            created_at=parse_dt(data.get("created_at")) or datetime.now(timezone.utc),
            paused_at=parse_dt(data.get("paused_at")),
            resumed_at=parse_dt(data.get("resumed_at")),
            expires_at=parse_dt(data.get("expires_at")),
            resume_data=data.get("resume_data", {}),
        )


# =============================================================================
# Checkpoint Manager
# =============================================================================


class CheckpointManager:
    """Manager for multiple checkpoints.
    
    Provides centralized checkpoint management including:
    - Creating and tracking checkpoints
    - Finding checkpoints by ID/name/workflow
    - Bulk operations
    
    Example:
        ```python
        manager = CheckpointManager()
        
        # Create checkpoint
        cp = manager.create_checkpoint(
            name="review_step",
            workflow_id="wf_123",
        )
        
        # Get pending checkpoints
        pending = manager.get_pending_checkpoints()
        
        # Resume by ID
        await manager.resume_checkpoint(cp.checkpoint_id, data={"ok": True})
        ```
    """
    
    def __init__(self) -> None:
        """Initialize checkpoint manager."""
        self._checkpoints: Dict[str, Checkpoint] = {}
    
    def create_checkpoint(
        self,
        name: str,
        workflow_id: str = "",
        step_name: str = "",
        **kwargs: Any,
    ) -> Checkpoint:
        """Create a new checkpoint.
        
        Args:
            name: Checkpoint name
            workflow_id: Parent workflow ID
            step_name: Step name
            **kwargs: Additional checkpoint attributes
            
        Returns:
            Created checkpoint
        """
        checkpoint = Checkpoint(
            name=name,
            workflow_id=workflow_id,
            step_name=step_name,
            **kwargs,
        )
        self._checkpoints[checkpoint.checkpoint_id] = checkpoint
        return checkpoint
    
    def get_checkpoint(self, checkpoint_id: str) -> Checkpoint | None:
        """Get checkpoint by ID.
        
        Args:
            checkpoint_id: Checkpoint ID
            
        Returns:
            Checkpoint or None
        """
        return self._checkpoints.get(checkpoint_id)
    
    def get_checkpoint_by_name(
        self,
        name: str,
        workflow_id: str | None = None,
    ) -> Checkpoint | None:
        """Get checkpoint by name.
        
        Args:
            name: Checkpoint name
            workflow_id: Optional workflow filter
            
        Returns:
            Checkpoint or None (returns most recent match)
        """
        for cp in reversed(list(self._checkpoints.values())):
            if cp.name == name:
                if workflow_id is None or cp.workflow_id == workflow_id:
                    return cp
        return None
    
    def get_checkpoints_for_workflow(self, workflow_id: str) -> List[Checkpoint]:
        """Get all checkpoints for a workflow.
        
        Args:
            workflow_id: Workflow ID
            
        Returns:
            List of checkpoints
        """
        return [
            cp for cp in self._checkpoints.values()
            if cp.workflow_id == workflow_id
        ]
    
    def get_pending_checkpoints(self) -> List[Checkpoint]:
        """Get all pending checkpoints.
        
        Returns:
            List of pending checkpoints
        """
        return [
            cp for cp in self._checkpoints.values()
            if cp.status == CheckpointStatus.PENDING
        ]
    
    def get_paused_checkpoints(self) -> List[Checkpoint]:
        """Get all paused checkpoints.
        
        Returns:
            List of paused checkpoints
        """
        return [
            cp for cp in self._checkpoints.values()
            if cp.status == CheckpointStatus.PAUSED
        ]
    
    async def resume_checkpoint(
        self,
        checkpoint_id: str,
        data: Dict[str, Any] | None = None,
        resuming_user: str | None = None,
    ) -> bool:
        """Resume a checkpoint.
        
        Args:
            checkpoint_id: Checkpoint to resume
            data: Resume data
            resuming_user: Who is resuming
            
        Returns:
            True if resumed, False if not found
        """
        checkpoint = self._checkpoints.get(checkpoint_id)
        if checkpoint is None or not checkpoint.is_paused:
            return False
        
        await checkpoint.resume(data=data, resuming_user=resuming_user)
        return True
    
    def remove_checkpoint(self, checkpoint_id: str) -> bool:
        """Remove a checkpoint.
        
        Args:
            checkpoint_id: Checkpoint to remove
            
        Returns:
            True if removed
        """
        if checkpoint_id in self._checkpoints:
            del self._checkpoints[checkpoint_id]
            return True
        return False
    
    def clear(self) -> None:
        """Clear all checkpoints."""
        self._checkpoints.clear()
    
    @property
    def count(self) -> int:
        """Get total checkpoint count."""
        return len(self._checkpoints)
    
    @property
    def paused_count(self) -> int:
        """Get paused checkpoint count."""
        return len(self.get_paused_checkpoints())


# =============================================================================
# Workflow Integration
# =============================================================================


class WorkflowCheckpoint:
    """Checkpoint integration for workflow patterns.
    
    Provides a higher-level interface for adding checkpoints
    to workflow patterns.
    
    Example:
        ```python
        wf_checkpoint = WorkflowCheckpoint(
            manager=checkpoint_manager,
            workflow_id="data_pipeline",
        )
        
        # In workflow step
        async def analyze_step(data):
            results = await analyze(data)
            
            # Pause for review
            resume_data = await wf_checkpoint.pause_for_review(
                step_name="analyze",
                state={"results": results},
                reason="Review analysis results",
            )
            
            if resume_data.get("approved"):
                return results
            else:
                raise ValueError("Analysis rejected")
        ```
    """
    
    def __init__(
        self,
        manager: CheckpointManager | None = None,
        workflow_id: str = "",
        default_timeout: float | None = None,
    ) -> None:
        """Initialize workflow checkpoint.
        
        Args:
            manager: Checkpoint manager (creates new if None)
            workflow_id: Workflow ID
            default_timeout: Default pause timeout
        """
        self.manager = manager or CheckpointManager()
        self.workflow_id = workflow_id
        self.default_timeout = default_timeout
    
    async def pause_for_review(
        self,
        step_name: str,
        state: Dict[str, Any] | None = None,
        reason: str = "",
        timeout: float | None = None,
    ) -> Dict[str, Any]:
        """Pause workflow for human review.
        
        Args:
            step_name: Current step name
            state: State to capture
            reason: Why review is needed
            timeout: Pause timeout
            
        Returns:
            Resume data from reviewer
        """
        checkpoint = self.manager.create_checkpoint(
            name=f"{self.workflow_id}:{step_name}:review",
            workflow_id=self.workflow_id,
            step_name=step_name,
        )
        checkpoint.state.metadata["reason"] = reason
        
        return await checkpoint.pause(
            state=state,
            timeout=timeout or self.default_timeout,
        )
    
    def create_checkpoint(
        self,
        step_name: str,
        name: str | None = None,
    ) -> Checkpoint:
        """Create a checkpoint for current step.
        
        Args:
            step_name: Step name
            name: Optional checkpoint name
            
        Returns:
            Created checkpoint
        """
        return self.manager.create_checkpoint(
            name=name or f"{self.workflow_id}:{step_name}",
            workflow_id=self.workflow_id,
            step_name=step_name,
        )
    
    def get_step_checkpoints(self, step_name: str) -> List[Checkpoint]:
        """Get checkpoints for a specific step.
        
        Args:
            step_name: Step name
            
        Returns:
            List of checkpoints
        """
        return [
            cp for cp in self.manager.get_checkpoints_for_workflow(self.workflow_id)
            if cp.step_name == step_name
        ]
