"""
MCP (Model Context Protocol) Support Module.

This module provides comprehensive MCP support for tool discovery,
server hosting, and protocol implementation.

Usage:
    ```python
    from multi_agent_base.mcp import (
        MCPClient,
        MCPServer,
        MCPTool,
        discover_tools,
    )
    
    # Client usage
    async with MCPClient.stdio("python", "server.py") as client:
        tools = await client.list_tools()
        result = await client.call_tool("search", {"query": "AI"})
    
    # Server usage
    server = MCPServer(name="my-server")
    
    @server.tool
    def search(query: str) -> str:
        '''Search for documents.'''
        return f"Results for: {query}"
    
    await server.start_http(port=8080)
    ```

Features:
- Multiple transport protocols (stdio, HTTP, SSE)
- Automatic tool discovery
- Resource and prompt management
- Async context managers
- Event-driven architecture
"""

from multi_agent_base.mcp.types import (
    # Protocol types
    MCPRequest,
    MCPResponse,
    MCPError,
    MCPNotification,
    
    # Tool types
    MCPTool,
    MCPToolParameter,
    MCPToolResult,
    MCPToolResultContent,
    
    # Resource types
    MCPResource,
    MCPResourceContent,
    MCPResourceTemplate,
    
    # Prompt types
    MCPPrompt,
    MCPPromptArgument,
    MCPPromptMessage,
    
    # Error codes
    MCPErrorCode,
    
    # Constants
    MCP_PROTOCOL_VERSION,
)

from multi_agent_base.mcp.client import (
    MCPClient,
    MCPTransport,
    StdioTransport,
    HTTPTransport,
    SSETransport,
)

from multi_agent_base.mcp.server import (
    MCPServer,
    MCPServerConfig,
)

from multi_agent_base.mcp.discovery import (
    ToolDiscovery,
    DiscoveredTool,
    MCPToolWrapper,
    discover_tools,
    discover_and_convert,
)

__all__ = [
    # Protocol types
    "MCPRequest",
    "MCPResponse",
    "MCPError",
    "MCPNotification",
    
    # Tool types
    "MCPTool",
    "MCPToolParameter",
    "MCPToolResult",
    "MCPToolResultContent",
    
    # Resource types
    "MCPResource",
    "MCPResourceContent",
    "MCPResourceTemplate",
    
    # Prompt types
    "MCPPrompt",
    "MCPPromptArgument",
    "MCPPromptMessage",
    
    # Error codes
    "MCPErrorCode",
    
    # Client
    "MCPClient",
    "MCPTransport",
    "StdioTransport",
    "HTTPTransport",
    "SSETransport",
    
    # Server
    "MCPServer",
    "MCPServerConfig",
    
    # Discovery
    "ToolDiscovery",
    "DiscoveredTool",
    "MCPToolWrapper",
    "discover_tools",
    "discover_and_convert",
    
    # Constants
    "MCP_PROTOCOL_VERSION",
]
