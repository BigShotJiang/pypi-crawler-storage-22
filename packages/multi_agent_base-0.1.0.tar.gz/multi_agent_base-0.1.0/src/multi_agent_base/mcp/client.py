"""
MCP Client Implementation.

This module provides an MCP client that can:
- Connect to MCP servers via stdio or HTTP
- Discover available tools
- Call tools and handle responses
- Manage resources and prompts

Usage:
    ```python
    from multi_agent_base.mcp import MCPClient
    
    async with MCPClient.stdio("python", "my_server.py") as client:
        tools = await client.list_tools()
        result = await client.call_tool("search", {"query": "AI"})
    ```
"""

from __future__ import annotations

import asyncio
import json
import logging
import subprocess
import sys
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, TYPE_CHECKING

from multi_agent_base.mcp.types import (
    MCP_PROTOCOL_VERSION,
    MCP_DEFAULT_TIMEOUT,
    MCPClientInfo,
    MCPError,
    MCPErrorCode,
    MCPInitializeParams,
    MCPInitializeResult,
    MCPNotification,
    MCPRequest,
    MCPResponse,
    MCPServerInfo,
    MCPTool,
    MCPToolCall,
    MCPToolResult,
    MCPResource,
    MCPResourceContent,
    MCPPrompt,
)

if TYPE_CHECKING:
    import aiohttp

logger = logging.getLogger(__name__)


# =============================================================================
# Transport Layer
# =============================================================================


class MCPTransport(ABC):
    """Abstract transport layer for MCP communication."""
    
    @abstractmethod
    async def connect(self) -> None:
        """Establish connection."""
        pass
    
    @abstractmethod
    async def send(self, message: Dict[str, Any]) -> None:
        """Send a message."""
        pass
    
    @abstractmethod
    async def receive(self) -> Dict[str, Any]:
        """Receive a message."""
        pass
    
    @abstractmethod
    async def close(self) -> None:
        """Close connection."""
        pass
    
    @property
    @abstractmethod
    def is_connected(self) -> bool:
        """Check if connected."""
        pass


class StdioTransport(MCPTransport):
    """Transport using stdio (stdin/stdout) communication.
    
    This transport spawns a subprocess and communicates via
    JSON-RPC messages over stdin/stdout.
    """
    
    def __init__(
        self,
        command: str,
        args: List[str] | None = None,
        env: Dict[str, str] | None = None,
        cwd: str | None = None,
    ):
        """Initialize stdio transport.
        
        Args:
            command: Command to run (e.g., "python", "node")
            args: Command arguments (e.g., ["server.py"])
            env: Environment variables
            cwd: Working directory
        """
        self.command = command
        self.args = args or []
        self.env = env
        self.cwd = cwd
        self._process: subprocess.Popen | None = None
        self._reader_task: asyncio.Task | None = None
        self._message_queue: asyncio.Queue[Dict[str, Any]] = asyncio.Queue()
        self._connected = False
    
    async def connect(self) -> None:
        """Start subprocess and connect."""
        import os
        
        # Merge environment
        env = os.environ.copy()
        if self.env:
            env.update(self.env)
        
        # Start process
        cmd = [self.command] + self.args
        self._process = subprocess.Popen(
            cmd,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            env=env,
            cwd=self.cwd,
            bufsize=0,
        )
        
        # Start reader task
        self._reader_task = asyncio.create_task(self._read_loop())
        self._connected = True
        
        logger.info(f"Started MCP server process: {' '.join(cmd)}")
    
    async def _read_loop(self) -> None:
        """Read messages from stdout."""
        if not self._process or not self._process.stdout:
            return
        
        loop = asyncio.get_event_loop()
        
        while self._connected and self._process.poll() is None:
            try:
                # Read line in executor to avoid blocking
                line = await loop.run_in_executor(
                    None,
                    self._process.stdout.readline,
                )
                
                if not line:
                    break
                
                # Parse JSON
                try:
                    message = json.loads(line.decode().strip())
                    await self._message_queue.put(message)
                except json.JSONDecodeError:
                    logger.warning(f"Invalid JSON received: {line}")
                    
            except Exception as e:
                logger.error(f"Read error: {e}")
                break
    
    async def send(self, message: Dict[str, Any]) -> None:
        """Send message via stdin."""
        if not self._process or not self._process.stdin:
            raise ConnectionError("Not connected")
        
        # Serialize and send
        data = json.dumps(message) + "\n"
        self._process.stdin.write(data.encode())
        self._process.stdin.flush()
    
    async def receive(self) -> Dict[str, Any]:
        """Receive message from queue."""
        return await self._message_queue.get()
    
    async def close(self) -> None:
        """Terminate subprocess."""
        self._connected = False
        
        if self._reader_task:
            self._reader_task.cancel()
            try:
                await self._reader_task
            except asyncio.CancelledError:
                pass
        
        if self._process:
            self._process.terminate()
            try:
                self._process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self._process.kill()
            
            logger.info("MCP server process terminated")
    
    @property
    def is_connected(self) -> bool:
        """Check if connected."""
        return self._connected and self._process is not None


class HTTPTransport(MCPTransport):
    """Transport using HTTP/SSE communication.
    
    This transport connects to an HTTP-based MCP server
    using Server-Sent Events for receiving messages.
    """
    
    def __init__(
        self,
        url: str,
        headers: Dict[str, str] | None = None,
        timeout: float = MCP_DEFAULT_TIMEOUT,
    ):
        """Initialize HTTP transport.
        
        Args:
            url: Server URL (e.g., "http://localhost:8080")
            headers: Additional HTTP headers
            timeout: Request timeout
        """
        self.url = url.rstrip("/")
        self.headers = headers or {}
        self.timeout = timeout
        self._session: Optional["aiohttp.ClientSession"] = None
        self._connected = False
    
    async def connect(self) -> None:
        """Create HTTP session."""
        try:
            import aiohttp
        except ImportError:
            raise ImportError(
                "aiohttp is required for HTTP transport. "
                "Install with: pip install aiohttp"
            )
        
        self._session = aiohttp.ClientSession(
            headers=self.headers,
            timeout=aiohttp.ClientTimeout(total=self.timeout),
        )
        self._connected = True
        
        logger.info(f"Connected to MCP server: {self.url}")
    
    async def send(self, message: Dict[str, Any]) -> None:
        """Send message via HTTP POST."""
        if not self._session:
            raise ConnectionError("Not connected")
        
        async with self._session.post(
            f"{self.url}/message",
            json=message,
        ) as response:
            if response.status != 200:
                text = await response.text()
                raise ConnectionError(f"HTTP {response.status}: {text}")
    
    async def receive(self) -> Dict[str, Any]:
        """Receive message via HTTP GET or SSE."""
        if not self._session:
            raise ConnectionError("Not connected")
        
        async with self._session.get(f"{self.url}/message") as response:
            if response.status != 200:
                text = await response.text()
                raise ConnectionError(f"HTTP {response.status}: {text}")
            
            return await response.json()
    
    async def close(self) -> None:
        """Close HTTP session."""
        self._connected = False
        
        if self._session:
            await self._session.close()
            self._session = None
            
            logger.info("Disconnected from MCP server")
    
    @property
    def is_connected(self) -> bool:
        """Check if connected."""
        return self._connected and self._session is not None


# =============================================================================
# MCP Client
# =============================================================================


@dataclass
class MCPClientConfig:
    """MCP Client configuration.
    
    Attributes:
        name: Client name
        version: Client version
        timeout: Default request timeout
        auto_reconnect: Auto reconnect on disconnect
    """
    
    name: str = "MultiAgentBase MCP Client"
    version: str = "1.0.0"
    timeout: float = MCP_DEFAULT_TIMEOUT
    auto_reconnect: bool = False


class MCPClient:
    """MCP Client for communicating with MCP servers.
    
    The client supports:
    - stdio transport (subprocess communication)
    - HTTP transport (REST/SSE communication)
    - Tool discovery and execution
    - Resource access
    - Prompt templates
    
    Example:
        ```python
        # Stdio transport
        async with MCPClient.stdio("python", "server.py") as client:
            tools = await client.list_tools()
            result = await client.call_tool("search", {"query": "AI"})
        
        # HTTP transport
        async with MCPClient.http("http://localhost:8080") as client:
            resources = await client.list_resources()
        ```
    """
    
    def __init__(
        self,
        transport: MCPTransport,
        config: MCPClientConfig | None = None,
    ):
        """Initialize MCP client.
        
        Args:
            transport: Transport layer
            config: Client configuration
        """
        self._transport = transport
        self._config = config or MCPClientConfig()
        self._server_info: MCPServerInfo | None = None
        self._initialized = False
        self._pending_requests: Dict[str, asyncio.Future] = {}
        self._notification_handlers: Dict[str, List[Callable]] = {}
        self._receiver_task: asyncio.Task | None = None
    
    # =========================================================================
    # Factory Methods
    # =========================================================================
    
    @classmethod
    def stdio(
        cls,
        command: str,
        *args: str,
        env: Dict[str, str] | None = None,
        cwd: str | None = None,
        config: MCPClientConfig | None = None,
    ) -> "MCPClient":
        """Create client with stdio transport.
        
        Args:
            command: Command to run
            *args: Command arguments
            env: Environment variables
            cwd: Working directory
            config: Client configuration
            
        Returns:
            MCPClient instance
        """
        transport = StdioTransport(
            command=command,
            args=list(args),
            env=env,
            cwd=cwd,
        )
        return cls(transport, config)
    
    @classmethod
    def http(
        cls,
        url: str,
        headers: Dict[str, str] | None = None,
        timeout: float = MCP_DEFAULT_TIMEOUT,
        config: MCPClientConfig | None = None,
    ) -> "MCPClient":
        """Create client with HTTP transport.
        
        Args:
            url: Server URL
            headers: HTTP headers
            timeout: Request timeout
            config: Client configuration
            
        Returns:
            MCPClient instance
        """
        transport = HTTPTransport(
            url=url,
            headers=headers,
            timeout=timeout,
        )
        return cls(transport, config)
    
    # =========================================================================
    # Context Manager
    # =========================================================================
    
    async def __aenter__(self) -> "MCPClient":
        """Enter async context."""
        await self.connect()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        """Exit async context."""
        await self.close()
    
    # =========================================================================
    # Connection Management
    # =========================================================================
    
    async def connect(self) -> None:
        """Connect to MCP server and initialize."""
        # Connect transport
        await self._transport.connect()
        
        # Start receiver
        self._receiver_task = asyncio.create_task(self._receive_loop())
        
        # Initialize protocol
        await self._initialize()
    
    async def _initialize(self) -> None:
        """Send initialize request."""
        params = MCPInitializeParams(
            protocolVersion=MCP_PROTOCOL_VERSION,
            clientInfo=MCPClientInfo(
                name=self._config.name,
                version=self._config.version,
            ),
            capabilities={
                "tools": {},
                "resources": {},
                "prompts": {},
            },
        )
        
        response = await self._request("initialize", params.to_dict())
        
        if response.is_error:
            raise ConnectionError(f"Initialize failed: {response.error}")
        
        result = MCPInitializeResult.from_dict(response.result or {})
        self._server_info = result.serverInfo
        self._initialized = True
        
        # Send initialized notification
        await self._notify("notifications/initialized", {})
        
        logger.info(
            f"Initialized MCP connection with {self._server_info.name} "
            f"v{self._server_info.version}"
        )
    
    async def close(self) -> None:
        """Close connection."""
        if self._initialized:
            # Send shutdown notification
            try:
                await self._notify("notifications/shutdown", {})
            except Exception:
                pass
        
        # Cancel receiver
        if self._receiver_task:
            self._receiver_task.cancel()
            try:
                await self._receiver_task
            except asyncio.CancelledError:
                pass
        
        # Close transport
        await self._transport.close()
        self._initialized = False
    
    @property
    def is_connected(self) -> bool:
        """Check if connected and initialized."""
        return self._transport.is_connected and self._initialized
    
    @property
    def server_info(self) -> MCPServerInfo | None:
        """Get server information."""
        return self._server_info
    
    # =========================================================================
    # Message Handling
    # =========================================================================
    
    async def _receive_loop(self) -> None:
        """Receive and dispatch messages."""
        while self._transport.is_connected:
            try:
                message = await self._transport.receive()
                await self._handle_message(message)
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Receive error: {e}")
    
    async def _handle_message(self, message: Dict[str, Any]) -> None:
        """Handle incoming message."""
        # Check if it's a response
        if "id" in message and ("result" in message or "error" in message):
            response = MCPResponse.from_dict(message)
            future = self._pending_requests.pop(response.id, None)
            if future:
                future.set_result(response)
            return
        
        # Check if it's a notification
        if "method" in message and "id" not in message:
            notification = MCPNotification.from_dict(message)
            await self._handle_notification(notification)
            return
        
        # Check if it's a request from server
        if "method" in message and "id" in message:
            request = MCPRequest.from_dict(message)
            await self._handle_server_request(request)
            return
        
        logger.warning(f"Unknown message type: {message}")
    
    async def _handle_notification(self, notification: MCPNotification) -> None:
        """Handle incoming notification."""
        handlers = self._notification_handlers.get(notification.method, [])
        for handler in handlers:
            try:
                await handler(notification.params)
            except Exception as e:
                logger.error(f"Notification handler error: {e}")
    
    async def _handle_server_request(self, request: MCPRequest) -> None:
        """Handle request from server (e.g., sampling)."""
        # For now, just log - can be extended
        logger.debug(f"Server request: {request.method}")
    
    async def _request(
        self,
        method: str,
        params: Dict[str, Any] | None = None,
        timeout: float | None = None,
    ) -> MCPResponse:
        """Send request and wait for response.
        
        Args:
            method: RPC method
            params: Method parameters
            timeout: Request timeout
            
        Returns:
            MCPResponse
        """
        request = MCPRequest(method=method, params=params or {})
        
        # Create future for response
        future: asyncio.Future[MCPResponse] = asyncio.Future()
        self._pending_requests[request.id] = future
        
        try:
            # Send request
            await self._transport.send(request.to_dict())
            
            # Wait for response
            response = await asyncio.wait_for(
                future,
                timeout=timeout or self._config.timeout,
            )
            return response
            
        except asyncio.TimeoutError:
            self._pending_requests.pop(request.id, None)
            return MCPResponse(
                id=request.id,
                error=MCPError(
                    code=MCPErrorCode.TIMEOUT,
                    message=f"Request timed out after {timeout}s",
                ),
            )
    
    async def _notify(self, method: str, params: Dict[str, Any]) -> None:
        """Send notification (no response expected)."""
        notification = MCPNotification(method=method, params=params)
        await self._transport.send(notification.to_dict())
    
    def on_notification(
        self,
        method: str,
        handler: Callable,
    ) -> Callable:
        """Register notification handler.
        
        Args:
            method: Notification method to handle
            handler: Async handler function
            
        Returns:
            The handler (for decorator use)
        """
        if method not in self._notification_handlers:
            self._notification_handlers[method] = []
        self._notification_handlers[method].append(handler)
        return handler
    
    # =========================================================================
    # Tool Operations
    # =========================================================================
    
    async def list_tools(self) -> List[MCPTool]:
        """List available tools.
        
        Returns:
            List of MCPTool objects
        """
        response = await self._request("tools/list", {})
        
        if response.is_error:
            raise RuntimeError(f"Failed to list tools: {response.error}")
        
        tools_data = response.result.get("tools", []) if response.result else []
        return [MCPTool.from_dict(t) for t in tools_data]
    
    async def call_tool(
        self,
        name: str,
        arguments: Dict[str, Any] | None = None,
    ) -> MCPToolResult:
        """Call a tool.
        
        Args:
            name: Tool name
            arguments: Tool arguments
            
        Returns:
            MCPToolResult
        """
        response = await self._request("tools/call", {
            "name": name,
            "arguments": arguments or {},
        })
        
        if response.is_error:
            return MCPToolResult.error(str(response.error))
        
        return MCPToolResult.from_dict(response.result or {})
    
    async def discover_tools(self) -> Dict[str, MCPTool]:
        """Discover tools and return as name->tool mapping.
        
        Returns:
            Dictionary mapping tool names to MCPTool objects
        """
        tools = await self.list_tools()
        return {tool.name: tool for tool in tools}
    
    # =========================================================================
    # Resource Operations
    # =========================================================================
    
    async def list_resources(self) -> List[MCPResource]:
        """List available resources.
        
        Returns:
            List of MCPResource objects
        """
        response = await self._request("resources/list", {})
        
        if response.is_error:
            raise RuntimeError(f"Failed to list resources: {response.error}")
        
        resources_data = (
            response.result.get("resources", []) if response.result else []
        )
        return [MCPResource.from_dict(r) for r in resources_data]
    
    async def read_resource(self, uri: str) -> MCPResourceContent:
        """Read a resource.
        
        Args:
            uri: Resource URI
            
        Returns:
            MCPResourceContent
        """
        response = await self._request("resources/read", {"uri": uri})
        
        if response.is_error:
            raise RuntimeError(f"Failed to read resource: {response.error}")
        
        contents = response.result.get("contents", []) if response.result else []
        if not contents:
            raise RuntimeError(f"Empty resource: {uri}")
        
        content = contents[0]
        return MCPResourceContent(
            uri=content.get("uri", uri),
            mimeType=content.get("mimeType", "text/plain"),
            text=content.get("text"),
            blob=content.get("blob"),
        )
    
    # =========================================================================
    # Prompt Operations
    # =========================================================================
    
    async def list_prompts(self) -> List[MCPPrompt]:
        """List available prompts.
        
        Returns:
            List of MCPPrompt objects
        """
        response = await self._request("prompts/list", {})
        
        if response.is_error:
            raise RuntimeError(f"Failed to list prompts: {response.error}")
        
        prompts_data = response.result.get("prompts", []) if response.result else []
        return [MCPPrompt(**p) for p in prompts_data]
    
    async def get_prompt(
        self,
        name: str,
        arguments: Dict[str, str] | None = None,
    ) -> List[Dict[str, Any]]:
        """Get a prompt with arguments.
        
        Args:
            name: Prompt name
            arguments: Prompt arguments
            
        Returns:
            List of prompt messages
        """
        response = await self._request("prompts/get", {
            "name": name,
            "arguments": arguments or {},
        })
        
        if response.is_error:
            raise RuntimeError(f"Failed to get prompt: {response.error}")
        
        return response.result.get("messages", []) if response.result else []


# =============================================================================
# SSE Transport
# =============================================================================


class SSETransport(MCPTransport):
    """Server-Sent Events (SSE) transport for MCP.
    
    This transport uses HTTP SSE for receiving messages
    and HTTP POST for sending messages.
    
    Attributes:
        url: SSE endpoint URL
        post_url: POST endpoint URL (defaults to url + "/message")
    """
    
    def __init__(
        self,
        url: str,
        post_url: str | None = None,
        headers: Dict[str, str] | None = None,
    ):
        """Initialize SSE transport.
        
        Args:
            url: SSE endpoint URL
            post_url: Optional POST endpoint URL
            headers: Optional HTTP headers
        """
        self._url = url
        self._post_url = post_url or f"{url}/message"
        self._headers = headers or {}
        self._session: Optional[aiohttp.ClientSession] = None
        self._sse_response: Optional[aiohttp.ClientResponse] = None
        self._message_queue: asyncio.Queue = asyncio.Queue()
        self._reader_task: Optional[asyncio.Task] = None
        self._connected = False
    
    @property
    def is_connected(self) -> bool:
        """Check if transport is connected."""
        return self._connected
    
    async def connect(self) -> None:
        """Connect to SSE endpoint."""
        if self._connected:
            return
        
        self._session = aiohttp.ClientSession(headers=self._headers)
        
        try:
            # Connect to SSE endpoint
            self._sse_response = await self._session.get(
                self._url,
                headers={"Accept": "text/event-stream"},
            )
            
            if self._sse_response.status != 200:
                raise ConnectionError(
                    f"Failed to connect to SSE endpoint: {self._sse_response.status}"
                )
            
            # Start reader task
            self._reader_task = asyncio.create_task(self._read_sse())
            self._connected = True
            
        except Exception as e:
            await self._session.close()
            raise ConnectionError(f"Failed to connect: {e}")
    
    async def disconnect(self) -> None:
        """Disconnect from SSE endpoint."""
        if not self._connected:
            return
        
        self._connected = False
        
        if self._reader_task:
            self._reader_task.cancel()
            try:
                await self._reader_task
            except asyncio.CancelledError:
                pass
            self._reader_task = None
        
        if self._sse_response:
            self._sse_response.close()
            self._sse_response = None
        
        if self._session:
            await self._session.close()
            self._session = None
    
    async def send(self, message: Dict[str, Any]) -> None:
        """Send a message via HTTP POST.
        
        Args:
            message: Message to send
        """
        if not self._session:
            raise RuntimeError("Transport not connected")
        
        async with self._session.post(
            self._post_url,
            json=message,
            headers={"Content-Type": "application/json"},
        ) as response:
            if response.status >= 400:
                error_text = await response.text()
                raise RuntimeError(f"Failed to send message: {error_text}")
    
    async def receive(self, timeout: float | None = None) -> Dict[str, Any]:
        """Receive a message from SSE stream.
        
        Args:
            timeout: Optional timeout in seconds
            
        Returns:
            Received message
        """
        try:
            if timeout:
                return await asyncio.wait_for(
                    self._message_queue.get(),
                    timeout=timeout,
                )
            else:
                return await self._message_queue.get()
        except asyncio.TimeoutError:
            raise TimeoutError("Receive timed out")
    
    async def _read_sse(self) -> None:
        """Read SSE events and put them in queue."""
        if not self._sse_response:
            return
        
        buffer = ""
        
        async for chunk in self._sse_response.content:
            if not self._connected:
                break
            
            buffer += chunk.decode("utf-8")
            
            while "\n\n" in buffer:
                event_str, buffer = buffer.split("\n\n", 1)
                
                # Parse SSE event
                event_data = None
                for line in event_str.split("\n"):
                    if line.startswith("data:"):
                        data_str = line[5:].strip()
                        try:
                            event_data = json.loads(data_str)
                        except json.JSONDecodeError:
                            logger.warning(f"Invalid JSON in SSE: {data_str}")
                
                if event_data:
                    await self._message_queue.put(event_data)
