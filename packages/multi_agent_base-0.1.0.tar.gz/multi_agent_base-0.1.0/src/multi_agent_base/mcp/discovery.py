"""
MCP Tool Discovery.

This module provides utilities for discovering and
converting tools between MCP format and framework tools.

Usage:
    ```python
    from multi_agent_base.mcp import MCPClient
    from multi_agent_base.mcp.discovery import discover_and_convert
    
    async with MCPClient.stdio("python", "server.py") as client:
        tools = await discover_and_convert(client)
        # tools is now a list of framework-compatible tools
    ```
"""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, TYPE_CHECKING

from multi_agent_base.mcp.types import (
    MCPTool,
    MCPToolParameter,
    MCPToolResult,
)

if TYPE_CHECKING:
    from multi_agent_base.mcp.client import MCPClient
    from multi_agent_base.core import BaseTool

logger = logging.getLogger(__name__)


# =============================================================================
# Tool Discovery
# =============================================================================


@dataclass
class DiscoveredTool:
    """A tool discovered from an MCP server.
    
    Attributes:
        name: Tool name
        description: Tool description
        parameters: Tool parameters
        client: MCP client for calling the tool
        cached: Whether results are cached
    """
    
    name: str
    description: str
    parameters: List[MCPToolParameter]
    client: "MCPClient"
    cached: bool = False
    _cache: Dict[str, Any] = field(default_factory=dict)
    
    async def __call__(self, **kwargs: Any) -> Any:
        """Call the tool.
        
        Args:
            **kwargs: Tool arguments
            
        Returns:
            Tool result
        """
        # Check cache
        if self.cached:
            cache_key = str(sorted(kwargs.items()))
            if cache_key in self._cache:
                logger.debug(f"Cache hit for {self.name}")
                return self._cache[cache_key]
        
        # Call via MCP
        result = await self.client.call_tool(self.name, kwargs)
        
        # Extract text result
        if result.content and len(result.content) > 0:
            content = result.content[0]
            if content.get("type") == "text":
                value = content.get("text", "")
                
                # Cache if enabled
                if self.cached:
                    self._cache[cache_key] = value
                
                return value
        
        return result
    
    def to_json_schema(self) -> Dict[str, Any]:
        """Convert to JSON Schema format."""
        properties = {}
        required = []
        
        for param in self.parameters:
            properties[param.name] = param.to_json_schema()
            if param.required:
                required.append(param.name)
        
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": {
                    "type": "object",
                    "properties": properties,
                    "required": required,
                },
            },
        }
    
    def get_parameter_schema(self) -> Dict[str, Any]:
        """Get parameter schema only."""
        properties = {}
        required = []
        
        for param in self.parameters:
            properties[param.name] = param.to_json_schema()
            if param.required:
                required.append(param.name)
        
        return {
            "type": "object",
            "properties": properties,
            "required": required,
        }


class ToolDiscovery:
    """Tool discovery and management for MCP clients.
    
    Attributes:
        clients: List of MCP clients to discover from
        tools: Discovered tools
        
    Example:
        ```python
        discovery = ToolDiscovery()
        
        async with MCPClient.stdio("python", "server1.py") as client1:
            async with MCPClient.stdio("python", "server2.py") as client2:
                discovery.add_client(client1)
                discovery.add_client(client2)
                
                await discovery.refresh()
                
                # Get all tools
                tools = discovery.tools
                
                # Call a tool
                result = await discovery.call_tool("search", {"query": "AI"})
        ```
    """
    
    def __init__(self):
        """Initialize tool discovery."""
        self._clients: List["MCPClient"] = []
        self._tools: Dict[str, DiscoveredTool] = {}
        self._tool_to_client: Dict[str, "MCPClient"] = {}
    
    @property
    def tools(self) -> Dict[str, DiscoveredTool]:
        """Get all discovered tools."""
        return self._tools.copy()
    
    @property
    def tool_names(self) -> List[str]:
        """Get list of tool names."""
        return list(self._tools.keys())
    
    def add_client(self, client: "MCPClient") -> None:
        """Add an MCP client to discover from.
        
        Args:
            client: MCP client
        """
        if client not in self._clients:
            self._clients.append(client)
    
    def remove_client(self, client: "MCPClient") -> None:
        """Remove an MCP client.
        
        Args:
            client: MCP client
        """
        if client in self._clients:
            self._clients.remove(client)
            
            # Remove tools from this client
            for name, tool in list(self._tools.items()):
                if tool.client is client:
                    del self._tools[name]
                    del self._tool_to_client[name]
    
    async def refresh(self) -> None:
        """Refresh tool list from all clients."""
        self._tools.clear()
        self._tool_to_client.clear()
        
        for client in self._clients:
            if not client.is_connected:
                continue
            
            try:
                mcp_tools = await client.list_tools()
                
                for mcp_tool in mcp_tools:
                    # Check for conflicts
                    if mcp_tool.name in self._tools:
                        logger.warning(
                            f"Tool name conflict: {mcp_tool.name}, "
                            f"keeping first discovered"
                        )
                        continue
                    
                    # Create discovered tool
                    tool = DiscoveredTool(
                        name=mcp_tool.name,
                        description=mcp_tool.description,
                        parameters=mcp_tool.parameters,
                        client=client,
                    )
                    
                    self._tools[mcp_tool.name] = tool
                    self._tool_to_client[mcp_tool.name] = client
                    
            except Exception as e:
                logger.error(f"Failed to discover tools: {e}")
    
    def get_tool(self, name: str) -> DiscoveredTool | None:
        """Get a tool by name.
        
        Args:
            name: Tool name
            
        Returns:
            DiscoveredTool or None
        """
        return self._tools.get(name)
    
    async def call_tool(
        self,
        name: str,
        arguments: Dict[str, Any] | None = None,
    ) -> Any:
        """Call a tool by name.
        
        Args:
            name: Tool name
            arguments: Tool arguments
            
        Returns:
            Tool result
        """
        tool = self.get_tool(name)
        if not tool:
            raise ValueError(f"Tool not found: {name}")
        
        return await tool(**(arguments or {}))
    
    def get_json_schemas(self) -> List[Dict[str, Any]]:
        """Get JSON schemas for all tools.
        
        Returns:
            List of tool schemas
        """
        return [tool.to_json_schema() for tool in self._tools.values()]


# =============================================================================
# Convenience Functions
# =============================================================================


async def discover_tools(client: "MCPClient") -> Dict[str, DiscoveredTool]:
    """Discover tools from an MCP client.
    
    Args:
        client: Connected MCP client
        
    Returns:
        Dictionary of tool name -> DiscoveredTool
    """
    discovery = ToolDiscovery()
    discovery.add_client(client)
    await discovery.refresh()
    return discovery.tools


async def discover_and_convert(
    client: "MCPClient",
) -> List[Dict[str, Any]]:
    """Discover tools and convert to JSON schema format.
    
    Args:
        client: Connected MCP client
        
    Returns:
        List of tool schemas
    """
    discovery = ToolDiscovery()
    discovery.add_client(client)
    await discovery.refresh()
    return discovery.get_json_schemas()


# =============================================================================
# Tool Wrapper
# =============================================================================


class MCPToolWrapper:
    """Wrapper to use MCP tools as local functions.
    
    Example:
        ```python
        async with MCPClient.stdio("python", "server.py") as client:
            wrapper = MCPToolWrapper(client)
            await wrapper.discover()
            
            # Call like a regular function
            result = await wrapper.search(query="AI agents")
            
            # Or access by name
            result = await wrapper("search", query="AI agents")
        ```
    """
    
    def __init__(self, client: "MCPClient"):
        """Initialize wrapper.
        
        Args:
            client: MCP client
        """
        self._client = client
        self._tools: Dict[str, DiscoveredTool] = {}
    
    async def discover(self) -> None:
        """Discover tools from client."""
        self._tools = await discover_tools(self._client)
        
        # Add tools as attributes
        for name, tool in self._tools.items():
            setattr(self, name, tool)
    
    def __getattr__(self, name: str) -> DiscoveredTool:
        """Get tool by attribute access."""
        if name.startswith("_"):
            raise AttributeError(name)
        
        if name not in self._tools:
            raise AttributeError(f"Tool not found: {name}")
        
        return self._tools[name]
    
    async def __call__(
        self,
        name: str,
        **kwargs: Any,
    ) -> Any:
        """Call a tool by name.
        
        Args:
            name: Tool name
            **kwargs: Tool arguments
            
        Returns:
            Tool result
        """
        if name not in self._tools:
            raise ValueError(f"Tool not found: {name}")
        
        return await self._tools[name](**kwargs)
    
    @property
    def tool_names(self) -> List[str]:
        """Get list of tool names."""
        return list(self._tools.keys())
