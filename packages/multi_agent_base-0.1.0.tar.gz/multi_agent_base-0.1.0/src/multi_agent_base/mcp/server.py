"""
MCP Server Implementation.

This module provides an MCP server that can:
- Register and expose tools
- Handle tool calls
- Serve resources
- Provide prompt templates

Usage:
    ```python
    from multi_agent_base.mcp import MCPServer
    from multi_agent_base.core import tool
    
    server = MCPServer(name="MyServer")
    
    @server.tool
    def search(query: str) -> str:
        return f"Results for: {query}"
    
    await server.run_stdio()
    ```
"""

from __future__ import annotations

import asyncio
import inspect
import json
import logging
import sys
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Union

from multi_agent_base.mcp.types import (
    MCP_PROTOCOL_VERSION,
    MCPCapability,
    MCPError,
    MCPErrorCode,
    MCPInitializeResult,
    MCPNotification,
    MCPPrompt,
    MCPPromptArgument,
    MCPRequest,
    MCPResource,
    MCPResourceContent,
    MCPResponse,
    MCPServerInfo,
    MCPTool,
    MCPToolParameter,
    MCPToolResult,
)

logger = logging.getLogger(__name__)


# =============================================================================
# Server Transport
# =============================================================================


class MCPServerTransport(ABC):
    """Abstract server transport."""
    
    @abstractmethod
    async def start(self) -> None:
        """Start the transport."""
        pass
    
    @abstractmethod
    async def stop(self) -> None:
        """Stop the transport."""
        pass
    
    @abstractmethod
    async def send(self, message: Dict[str, Any]) -> None:
        """Send a message."""
        pass
    
    @abstractmethod
    async def receive(self) -> Dict[str, Any]:
        """Receive a message."""
        pass


class StdioServerTransport(MCPServerTransport):
    """Stdio server transport (stdin/stdout)."""
    
    def __init__(self):
        self._running = False
        self._message_queue: asyncio.Queue[Dict[str, Any]] = asyncio.Queue()
        self._reader_task: asyncio.Task | None = None
    
    async def start(self) -> None:
        """Start reading from stdin."""
        self._running = True
        self._reader_task = asyncio.create_task(self._read_loop())
    
    async def _read_loop(self) -> None:
        """Read messages from stdin."""
        loop = asyncio.get_event_loop()
        
        while self._running:
            try:
                # Read line in executor
                line = await loop.run_in_executor(
                    None,
                    sys.stdin.readline,
                )
                
                if not line:
                    break
                
                # Parse JSON
                try:
                    message = json.loads(line.strip())
                    await self._message_queue.put(message)
                except json.JSONDecodeError:
                    logger.warning(f"Invalid JSON: {line}")
                    
            except Exception as e:
                logger.error(f"Read error: {e}")
                break
    
    async def stop(self) -> None:
        """Stop reading."""
        self._running = False
        if self._reader_task:
            self._reader_task.cancel()
            try:
                await self._reader_task
            except asyncio.CancelledError:
                pass
    
    async def send(self, message: Dict[str, Any]) -> None:
        """Send message to stdout."""
        data = json.dumps(message) + "\n"
        sys.stdout.write(data)
        sys.stdout.flush()
    
    async def receive(self) -> Dict[str, Any]:
        """Receive message from queue."""
        return await self._message_queue.get()


class HTTPServerTransport(MCPServerTransport):
    """HTTP server transport using aiohttp."""
    
    def __init__(
        self,
        host: str = "localhost",
        port: int = 8080,
    ):
        self.host = host
        self.port = port
        self._app: Any = None
        self._runner: Any = None
        self._site: Any = None
        self._message_queue: asyncio.Queue[Dict[str, Any]] = asyncio.Queue()
        self._response_map: Dict[str, asyncio.Queue] = {}
    
    async def start(self) -> None:
        """Start HTTP server."""
        try:
            from aiohttp import web
        except ImportError:
            raise ImportError(
                "aiohttp is required for HTTP transport. "
                "Install with: pip install aiohttp"
            )
        
        self._app = web.Application()
        self._app.router.add_post("/message", self._handle_message)
        self._app.router.add_get("/message/{request_id}", self._get_response)
        
        self._runner = web.AppRunner(self._app)
        await self._runner.setup()
        
        self._site = web.TCPSite(self._runner, self.host, self.port)
        await self._site.start()
        
        logger.info(f"MCP HTTP server started on {self.host}:{self.port}")
    
    async def _handle_message(self, request) -> Any:
        """Handle incoming HTTP message."""
        from aiohttp import web
        
        message = await request.json()
        await self._message_queue.put(message)
        
        # Wait for response if it's a request
        if "id" in message:
            request_id = message["id"]
            self._response_map[request_id] = asyncio.Queue()
            
            try:
                response = await asyncio.wait_for(
                    self._response_map[request_id].get(),
                    timeout=30.0,
                )
                return web.json_response(response)
            finally:
                del self._response_map[request_id]
        
        return web.json_response({"status": "ok"})
    
    async def _get_response(self, request) -> Any:
        """Get response for a request."""
        from aiohttp import web
        
        request_id = request.match_info["request_id"]
        if request_id in self._response_map:
            response = await self._response_map[request_id].get()
            return web.json_response(response)
        
        return web.json_response(
            {"error": "Request not found"},
            status=404,
        )
    
    async def stop(self) -> None:
        """Stop HTTP server."""
        if self._runner:
            await self._runner.cleanup()
        logger.info("MCP HTTP server stopped")
    
    async def send(self, message: Dict[str, Any]) -> None:
        """Send response to waiting request."""
        if "id" in message:
            request_id = message["id"]
            if request_id in self._response_map:
                await self._response_map[request_id].put(message)
    
    async def receive(self) -> Dict[str, Any]:
        """Receive message from queue."""
        return await self._message_queue.get()


# =============================================================================
# Tool Registry
# =============================================================================


@dataclass
class RegisteredTool:
    """A registered tool in the server."""
    
    name: str
    description: str
    handler: Callable
    parameters: List[MCPToolParameter] = field(default_factory=list)
    is_async: bool = False
    
    def to_mcp_tool(self) -> MCPTool:
        """Convert to MCPTool."""
        return MCPTool(
            name=self.name,
            description=self.description,
            parameters=self.parameters,
        )


@dataclass
class RegisteredResource:
    """A registered resource in the server."""
    
    uri: str
    name: str
    description: str = ""
    mimeType: str = "text/plain"
    handler: Callable | None = None
    static_content: str | None = None
    
    def to_mcp_resource(self) -> MCPResource:
        """Convert to MCPResource."""
        return MCPResource(
            uri=self.uri,
            name=self.name,
            description=self.description,
            mimeType=self.mimeType,
        )


@dataclass
class RegisteredPrompt:
    """A registered prompt in the server."""
    
    name: str
    description: str = ""
    arguments: List[MCPPromptArgument] = field(default_factory=list)
    template: str = ""
    handler: Callable | None = None
    
    def to_mcp_prompt(self) -> MCPPrompt:
        """Convert to MCPPrompt."""
        return MCPPrompt(
            name=self.name,
            description=self.description,
            arguments=self.arguments,
        )


# =============================================================================
# MCP Server
# =============================================================================


@dataclass
class MCPServerConfig:
    """MCP Server configuration."""
    
    name: str = "Multi-Agent Base MCP Server"
    version: str = "1.0.0"
    capabilities: Dict[str, Any] = field(default_factory=lambda: {
        "tools": {},
        "resources": {},
        "prompts": {},
    })


class MCPServer:
    """MCP Server implementation.
    
    The server can:
    - Register and expose tools
    - Serve resources
    - Provide prompt templates
    - Run via stdio or HTTP
    
    Example:
        ```python
        server = MCPServer(name="MyServer")
        
        @server.tool
        def search(query: str) -> str:
            '''Search for information.'''
            return f"Results for: {query}"
        
        @server.resource("file://readme.txt")
        def get_readme():
            return "# My Project\\nWelcome!"
        
        await server.run_stdio()
        ```
    """
    
    def __init__(
        self,
        name: str = "MCP Server",
        version: str = "1.0.0",
        config: MCPServerConfig | None = None,
    ):
        """Initialize MCP server.
        
        Args:
            name: Server name
            version: Server version
            config: Full server configuration
        """
        self._config = config or MCPServerConfig(name=name, version=version)
        self._transport: MCPServerTransport | None = None
        self._running = False
        
        # Registries
        self._tools: Dict[str, RegisteredTool] = {}
        self._resources: Dict[str, RegisteredResource] = {}
        self._prompts: Dict[str, RegisteredPrompt] = {}
        
        # Client info (set during initialize)
        self._client_info: Dict[str, Any] = {}
        self._initialized = False
    
    # =========================================================================
    # Properties
    # =========================================================================
    
    @property
    def name(self) -> str:
        """Get server name."""
        return self._config.name
    
    @property
    def version(self) -> str:
        """Get server version."""
        return self._config.version
    
    @property
    def tools(self) -> Dict[str, RegisteredTool]:
        """Get registered tools."""
        return self._tools.copy()
    
    @property
    def resources(self) -> Dict[str, RegisteredResource]:
        """Get registered resources."""
        return self._resources.copy()
    
    @property
    def prompts(self) -> Dict[str, RegisteredPrompt]:
        """Get registered prompts."""
        return self._prompts.copy()
    
    # =========================================================================
    # Registration Decorators
    # =========================================================================
    
    def tool(
        self,
        name: str | None = None,
        description: str | None = None,
    ) -> Callable:
        """Decorator to register a tool.
        
        Args:
            name: Tool name (defaults to function name)
            description: Tool description (defaults to docstring)
            
        Returns:
            Decorator function
        
        Example:
            ```python
            @server.tool
            def calculate(expression: str) -> float:
                '''Calculate a mathematical expression.'''
                return eval(expression)
            
            @server.tool(name="search", description="Web search")
            async def web_search(query: str) -> str:
                return await search_api(query)
            ```
        """
        def decorator(func: Callable) -> Callable:
            tool_name = name or func.__name__
            tool_desc = description or (func.__doc__ or "").strip()
            
            # Extract parameters from function signature
            sig = inspect.signature(func)
            parameters = []
            
            for param_name, param in sig.parameters.items():
                if param_name in ("self", "cls"):
                    continue
                
                # Determine type
                param_type = "string"
                if param.annotation != inspect.Parameter.empty:
                    type_map = {
                        str: "string",
                        int: "number",
                        float: "number",
                        bool: "boolean",
                        list: "array",
                        dict: "object",
                    }
                    param_type = type_map.get(param.annotation, "string")
                
                # Check if required
                required = param.default == inspect.Parameter.empty
                default = None if required else param.default
                
                parameters.append(MCPToolParameter(
                    name=param_name,
                    type=param_type,
                    required=required,
                    default=default,
                ))
            
            # Register tool
            self._tools[tool_name] = RegisteredTool(
                name=tool_name,
                description=tool_desc,
                handler=func,
                parameters=parameters,
                is_async=asyncio.iscoroutinefunction(func),
            )
            
            return func
        
        return decorator
    
    def resource(
        self,
        uri: str,
        name: str | None = None,
        description: str = "",
        mimeType: str = "text/plain",
    ) -> Callable:
        """Decorator to register a resource.
        
        Args:
            uri: Resource URI
            name: Resource name
            description: Resource description
            mimeType: MIME type
            
        Returns:
            Decorator function
        
        Example:
            ```python
            @server.resource("file://config.json", mimeType="application/json")
            def get_config():
                return json.dumps({"key": "value"})
            ```
        """
        def decorator(func: Callable) -> Callable:
            resource_name = name or uri.split("/")[-1]
            
            self._resources[uri] = RegisteredResource(
                uri=uri,
                name=resource_name,
                description=description,
                mimeType=mimeType,
                handler=func,
            )
            
            return func
        
        return decorator
    
    def prompt(
        self,
        name: str | None = None,
        description: str = "",
    ) -> Callable:
        """Decorator to register a prompt template.
        
        Args:
            name: Prompt name
            description: Prompt description
            
        Returns:
            Decorator function
        
        Example:
            ```python
            @server.prompt(description="Code review prompt")
            def code_review(language: str, code: str) -> List[dict]:
                return [
                    {"role": "user", "content": f"Review this {language}:\\n{code}"}
                ]
            ```
        """
        def decorator(func: Callable) -> Callable:
            prompt_name = name or func.__name__
            
            # Extract arguments from function signature
            sig = inspect.signature(func)
            arguments = []
            
            for param_name, param in sig.parameters.items():
                if param_name in ("self", "cls"):
                    continue
                
                required = param.default == inspect.Parameter.empty
                
                arguments.append(MCPPromptArgument(
                    name=param_name,
                    required=required,
                ))
            
            self._prompts[prompt_name] = RegisteredPrompt(
                name=prompt_name,
                description=description or (func.__doc__ or "").strip(),
                arguments=arguments,
                handler=func,
            )
            
            return func
        
        return decorator
    
    # =========================================================================
    # Manual Registration
    # =========================================================================
    
    def register_tool(
        self,
        name: str,
        handler: Callable,
        description: str = "",
        parameters: List[MCPToolParameter] | None = None,
    ) -> None:
        """Register a tool manually.
        
        Args:
            name: Tool name
            handler: Tool handler function
            description: Tool description
            parameters: Tool parameters
        """
        self._tools[name] = RegisteredTool(
            name=name,
            description=description or (handler.__doc__ or "").strip(),
            handler=handler,
            parameters=parameters or [],
            is_async=asyncio.iscoroutinefunction(handler),
        )
    
    def register_static_resource(
        self,
        uri: str,
        content: str,
        name: str | None = None,
        description: str = "",
        mimeType: str = "text/plain",
    ) -> None:
        """Register a static resource.
        
        Args:
            uri: Resource URI
            content: Static content
            name: Resource name
            description: Resource description
            mimeType: MIME type
        """
        self._resources[uri] = RegisteredResource(
            uri=uri,
            name=name or uri.split("/")[-1],
            description=description,
            mimeType=mimeType,
            static_content=content,
        )
    
    # =========================================================================
    # Request Handlers
    # =========================================================================
    
    async def _handle_request(self, request: MCPRequest) -> MCPResponse:
        """Handle incoming request."""
        method = request.method
        params = request.params
        
        try:
            # Dispatch by method
            if method == "initialize":
                result = await self._handle_initialize(params)
            elif method == "tools/list":
                result = await self._handle_tools_list()
            elif method == "tools/call":
                result = await self._handle_tools_call(params)
            elif method == "resources/list":
                result = await self._handle_resources_list()
            elif method == "resources/read":
                result = await self._handle_resources_read(params)
            elif method == "prompts/list":
                result = await self._handle_prompts_list()
            elif method == "prompts/get":
                result = await self._handle_prompts_get(params)
            else:
                return MCPResponse(
                    id=request.id,
                    error=MCPError(
                        code=MCPErrorCode.METHOD_NOT_FOUND,
                        message=f"Unknown method: {method}",
                    ),
                )
            
            return MCPResponse(id=request.id, result=result)
            
        except Exception as e:
            logger.error(f"Request handler error: {e}")
            return MCPResponse(
                id=request.id,
                error=MCPError(
                    code=MCPErrorCode.INTERNAL_ERROR,
                    message=str(e),
                ),
            )
    
    async def _handle_initialize(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Handle initialize request."""
        self._client_info = params.get("clientInfo", {})
        self._initialized = True
        
        logger.info(
            f"Client initialized: {self._client_info.get('name', 'Unknown')}"
        )
        
        result = MCPInitializeResult(
            protocolVersion=MCP_PROTOCOL_VERSION,
            serverInfo=MCPServerInfo(
                name=self._config.name,
                version=self._config.version,
                protocolVersion=MCP_PROTOCOL_VERSION,
            ),
            capabilities=self._config.capabilities,
        )
        
        return result.to_dict()
    
    async def _handle_tools_list(self) -> Dict[str, Any]:
        """Handle tools/list request."""
        tools = [tool.to_mcp_tool().to_dict() for tool in self._tools.values()]
        return {"tools": tools}
    
    async def _handle_tools_call(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Handle tools/call request."""
        name = params.get("name", "")
        arguments = params.get("arguments", {})
        
        if name not in self._tools:
            return MCPToolResult.error(f"Tool not found: {name}").to_dict()
        
        tool = self._tools[name]
        
        try:
            # Call handler
            if tool.is_async:
                result = await tool.handler(**arguments)
            else:
                result = tool.handler(**arguments)
            
            # Convert result
            if isinstance(result, MCPToolResult):
                return result.to_dict()
            elif isinstance(result, dict):
                return MCPToolResult.json(result).to_dict()
            else:
                return MCPToolResult.text(str(result)).to_dict()
                
        except Exception as e:
            logger.error(f"Tool execution error: {e}")
            return MCPToolResult.error(str(e)).to_dict()
    
    async def _handle_resources_list(self) -> Dict[str, Any]:
        """Handle resources/list request."""
        resources = [
            res.to_mcp_resource().to_dict() for res in self._resources.values()
        ]
        return {"resources": resources}
    
    async def _handle_resources_read(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Handle resources/read request."""
        uri = params.get("uri", "")
        
        if uri not in self._resources:
            raise RuntimeError(f"Resource not found: {uri}")
        
        resource = self._resources[uri]
        
        # Get content
        if resource.static_content is not None:
            content = resource.static_content
        elif resource.handler:
            if asyncio.iscoroutinefunction(resource.handler):
                content = await resource.handler()
            else:
                content = resource.handler()
        else:
            raise RuntimeError(f"No content for resource: {uri}")
        
        return {
            "contents": [{
                "uri": uri,
                "mimeType": resource.mimeType,
                "text": content,
            }]
        }
    
    async def _handle_prompts_list(self) -> Dict[str, Any]:
        """Handle prompts/list request."""
        prompts = [p.to_mcp_prompt().to_dict() for p in self._prompts.values()]
        return {"prompts": prompts}
    
    async def _handle_prompts_get(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Handle prompts/get request."""
        name = params.get("name", "")
        arguments = params.get("arguments", {})
        
        if name not in self._prompts:
            raise RuntimeError(f"Prompt not found: {name}")
        
        prompt = self._prompts[name]
        
        if prompt.handler:
            if asyncio.iscoroutinefunction(prompt.handler):
                result = await prompt.handler(**arguments)
            else:
                result = prompt.handler(**arguments)
            
            # Convert result to messages format
            if isinstance(result, str):
                messages = [{"role": "user", "content": {"type": "text", "text": result}}]
            elif isinstance(result, list):
                messages = result
            else:
                messages = [{"role": "user", "content": {"type": "text", "text": str(result)}}]
        elif prompt.template:
            # Simple template substitution
            text = prompt.template.format(**arguments)
            messages = [{"role": "user", "content": {"type": "text", "text": text}}]
        else:
            raise RuntimeError(f"No handler or template for prompt: {name}")
        
        return {"messages": messages}
    
    async def _handle_notification(self, notification: MCPNotification) -> None:
        """Handle notification."""
        method = notification.method
        
        if method == "notifications/initialized":
            logger.info("Client completed initialization")
        elif method == "notifications/shutdown":
            logger.info("Client requested shutdown")
            self._running = False
        else:
            logger.debug(f"Unhandled notification: {method}")
    
    # =========================================================================
    # Server Lifecycle
    # =========================================================================
    
    async def run_stdio(self) -> None:
        """Run server with stdio transport."""
        self._transport = StdioServerTransport()
        await self._run()
    
    async def run_http(
        self,
        host: str = "localhost",
        port: int = 8080,
    ) -> None:
        """Run server with HTTP transport.
        
        Args:
            host: Host to bind to
            port: Port to listen on
        """
        self._transport = HTTPServerTransport(host=host, port=port)
        await self._run()
    
    async def _run(self) -> None:
        """Main server loop."""
        if not self._transport:
            raise RuntimeError("No transport configured")
        
        self._running = True
        await self._transport.start()
        
        logger.info(f"MCP Server '{self._config.name}' started")
        
        try:
            while self._running:
                try:
                    message = await self._transport.receive()
                    
                    # Check message type
                    if "method" in message:
                        if "id" in message:
                            # Request
                            request = MCPRequest.from_dict(message)
                            response = await self._handle_request(request)
                            await self._transport.send(response.to_dict())
                        else:
                            # Notification
                            notification = MCPNotification.from_dict(message)
                            await self._handle_notification(notification)
                    
                except asyncio.CancelledError:
                    break
                except Exception as e:
                    logger.error(f"Server error: {e}")
                    
        finally:
            await self._transport.stop()
            logger.info("MCP Server stopped")
    
    async def stop(self) -> None:
        """Stop the server."""
        self._running = False
    
    async def handle_request(self, request: MCPRequest) -> MCPResponse:
        """Handle an MCP request (public API).
        
        This is the main entry point for handling requests.
        Use this for testing or when integrating with custom transports.
        
        Args:
            request: MCP request to handle
            
        Returns:
            MCP response
        """
        return await self._handle_request(request)
