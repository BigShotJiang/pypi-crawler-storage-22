"""
Model Context Protocol (MCP) Types.

This module defines the message types used in MCP communication:
- Request/Response messages
- Tool definitions
- Error handling
- Protocol versioning

Based on Anthropic's MCP specification.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional, Union


# =============================================================================
# Protocol Constants
# =============================================================================

MCP_PROTOCOL_VERSION = "2025-06-18"
MCP_DEFAULT_TIMEOUT = 30.0


# =============================================================================
# Enums
# =============================================================================


class MCPMessageType(str, Enum):
    """MCP message types."""
    
    # Lifecycle
    INITIALIZE = "initialize"
    INITIALIZED = "initialized"
    SHUTDOWN = "shutdown"
    
    # Tools
    TOOLS_LIST = "tools/list"
    TOOLS_CALL = "tools/call"
    
    # Resources
    RESOURCES_LIST = "resources/list"
    RESOURCES_READ = "resources/read"
    
    # Prompts
    PROMPTS_LIST = "prompts/list"
    PROMPTS_GET = "prompts/get"
    
    # Notifications
    NOTIFICATION = "notification"
    PROGRESS = "progress"
    
    # Errors
    ERROR = "error"


class MCPErrorCode(int, Enum):
    """MCP error codes (JSON-RPC style)."""
    
    PARSE_ERROR = -32700
    INVALID_REQUEST = -32600
    METHOD_NOT_FOUND = -32601
    INVALID_PARAMS = -32602
    INTERNAL_ERROR = -32603
    
    # Custom error codes
    TOOL_NOT_FOUND = -32001
    TOOL_EXECUTION_ERROR = -32002
    RESOURCE_NOT_FOUND = -32003
    PERMISSION_DENIED = -32004
    TIMEOUT = -32005
    CONNECTION_ERROR = -32006


class MCPCapability(str, Enum):
    """MCP server capabilities."""
    
    TOOLS = "tools"
    RESOURCES = "resources"
    PROMPTS = "prompts"
    LOGGING = "logging"


# =============================================================================
# Base Message Types
# =============================================================================


@dataclass
class MCPMessage:
    """Base MCP message."""
    
    jsonrpc: str = "2.0"
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "jsonrpc": self.jsonrpc,
            "id": self.id,
        }
    
    def to_json(self) -> str:
        """Convert to JSON string."""
        import json
        return json.dumps(self.to_dict())


@dataclass
class MCPRequest(MCPMessage):
    """MCP request message.
    
    Attributes:
        method: The RPC method to call
        params: Optional parameters for the method
        
    Example:
        ```python
        request = MCPRequest(
            method="tools/call",
            params={
                "name": "search",
                "arguments": {"query": "AI agents"},
            },
        )
        ```
    """
    
    method: str = ""
    params: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        result = super().to_dict()
        result["method"] = self.method
        if self.params:
            result["params"] = self.params
        return result
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "MCPRequest":
        """Create from dictionary."""
        return cls(
            jsonrpc=data.get("jsonrpc", "2.0"),
            id=data.get("id", str(uuid.uuid4())),
            method=data.get("method", ""),
            params=data.get("params", {}),
        )


@dataclass
class MCPResponse(MCPMessage):
    """MCP response message.
    
    Attributes:
        result: The result of a successful request
        error: Error information if request failed
        
    Example:
        ```python
        # Success response
        response = MCPResponse(
            id="request_123",
            result={"content": [{"type": "text", "text": "Result here"}]},
        )
        
        # Error response
        response = MCPResponse(
            id="request_123",
            error=MCPError(
                code=MCPErrorCode.TOOL_NOT_FOUND,
                message="Tool 'unknown' not found",
            ),
        )
        ```
    """
    
    result: Dict[str, Any] | None = None
    error: "MCPError | None" = None
    
    @property
    def is_success(self) -> bool:
        """Check if response is successful."""
        return self.error is None
    
    @property
    def is_error(self) -> bool:
        """Check if response is an error."""
        return self.error is not None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        result = super().to_dict()
        if self.result is not None:
            result["result"] = self.result
        if self.error is not None:
            result["error"] = self.error.to_dict()
        return result
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "MCPResponse":
        """Create from dictionary."""
        error = None
        if "error" in data:
            error = MCPError.from_dict(data["error"])
        
        return cls(
            jsonrpc=data.get("jsonrpc", "2.0"),
            id=data.get("id", ""),
            result=data.get("result"),
            error=error,
        )


@dataclass
class MCPError:
    """MCP error information.
    
    Attributes:
        code: Error code (see MCPErrorCode)
        message: Human-readable error message
        data: Optional additional error data
    """
    
    code: int = MCPErrorCode.INTERNAL_ERROR
    message: str = ""
    data: Dict[str, Any] | None = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        result = {
            "code": self.code,
            "message": self.message,
        }
        if self.data:
            result["data"] = self.data
        return result
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "MCPError":
        """Create from dictionary."""
        return cls(
            code=data.get("code", MCPErrorCode.INTERNAL_ERROR),
            message=data.get("message", "Unknown error"),
            data=data.get("data"),
        )
    
    def __str__(self) -> str:
        return f"MCPError({self.code}): {self.message}"


@dataclass
class MCPNotification:
    """MCP notification message (no response expected).
    
    Attributes:
        method: Notification method
        params: Optional parameters
    """
    
    jsonrpc: str = "2.0"
    method: str = ""
    params: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        result = {
            "jsonrpc": self.jsonrpc,
            "method": self.method,
        }
        if self.params:
            result["params"] = self.params
        return result
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "MCPNotification":
        """Create from dictionary."""
        return cls(
            jsonrpc=data.get("jsonrpc", "2.0"),
            method=data.get("method", ""),
            params=data.get("params", {}),
        )


# =============================================================================
# Tool Types
# =============================================================================


@dataclass
class MCPToolParameter:
    """Parameter definition for an MCP tool.
    
    Attributes:
        name: Parameter name
        type: JSON Schema type (string, number, boolean, object, array)
        description: Human-readable description
        required: Whether parameter is required
        enum: Optional list of allowed values
        default: Optional default value
    """
    
    name: str
    type: str = "string"
    description: str = ""
    required: bool = False
    enum: List[str] | None = None
    default: Any = None
    
    def to_json_schema(self) -> Dict[str, Any]:
        """Convert to JSON Schema format."""
        schema: Dict[str, Any] = {
            "type": self.type,
        }
        if self.description:
            schema["description"] = self.description
        if self.enum:
            schema["enum"] = self.enum
        if self.default is not None:
            schema["default"] = self.default
        return schema


@dataclass
class MCPTool:
    """MCP Tool definition.
    
    Attributes:
        name: Tool name (must be unique)
        description: Human-readable description
        parameters: List of parameters
        returns: Description of return value
        
    Example:
        ```python
        tool = MCPTool(
            name="search",
            description="Search the web for information",
            parameters=[
                MCPToolParameter(
                    name="query",
                    type="string",
                    description="Search query",
                    required=True,
                ),
                MCPToolParameter(
                    name="max_results",
                    type="number",
                    description="Maximum results to return",
                    default=10,
                ),
            ],
        )
        ```
    """
    
    name: str
    description: str = ""
    parameters: List[MCPToolParameter] = field(default_factory=list)
    returns: str = ""
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to MCP tool format."""
        # Build JSON Schema for input
        properties = {}
        required = []
        
        for param in self.parameters:
            properties[param.name] = param.to_json_schema()
            if param.required:
                required.append(param.name)
        
        input_schema: Dict[str, Any] = {
            "type": "object",
            "properties": properties,
        }
        if required:
            input_schema["required"] = required
        
        return {
            "name": self.name,
            "description": self.description,
            "inputSchema": input_schema,
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "MCPTool":
        """Create from dictionary."""
        parameters = []
        input_schema = data.get("inputSchema", {})
        properties = input_schema.get("properties", {})
        required_list = input_schema.get("required", [])
        
        for name, schema in properties.items():
            parameters.append(MCPToolParameter(
                name=name,
                type=schema.get("type", "string"),
                description=schema.get("description", ""),
                required=name in required_list,
                enum=schema.get("enum"),
                default=schema.get("default"),
            ))
        
        return cls(
            name=data.get("name", ""),
            description=data.get("description", ""),
            parameters=parameters,
        )


@dataclass
class MCPToolCall:
    """MCP tool call request.
    
    Attributes:
        name: Tool name to call
        arguments: Arguments to pass to the tool
    """
    
    name: str
    arguments: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "name": self.name,
            "arguments": self.arguments,
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "MCPToolCall":
        """Create from dictionary."""
        return cls(
            name=data.get("name", ""),
            arguments=data.get("arguments", {}),
        )


@dataclass
class MCPToolResultContent:
    """Content block for MCP tool result.
    
    Attributes:
        type: Content type (text, image, etc.)
        text: Text content (for text type)
        data: Binary data (for image type)
        mime_type: MIME type for binary content
    """
    
    type: str = "text"
    text: str = ""
    data: Optional[bytes] = None
    mime_type: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        result = {"type": self.type}
        if self.type == "text":
            result["text"] = self.text
        elif self.type == "image" and self.data:
            import base64
            result["data"] = base64.b64encode(self.data).decode()
            result["mimeType"] = self.mime_type or "image/png"
        return result
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "MCPToolResultContent":
        """Create from dictionary."""
        content = cls(
            type=data.get("type", "text"),
            text=data.get("text", ""),
            mime_type=data.get("mimeType"),
        )
        if "data" in data:
            import base64
            content.data = base64.b64decode(data["data"])
        return content


@dataclass
class MCPToolResult:
    """MCP tool execution result.
    
    Attributes:
        content: Result content (list of content blocks)
        isError: Whether the result is an error
    """
    
    content: List[Dict[str, Any]] = field(default_factory=list)
    isError: bool = False
    
    @classmethod
    def text(cls, text: str, is_error: bool = False) -> "MCPToolResult":
        """Create a text result."""
        return cls(
            content=[{"type": "text", "text": text}],
            isError=is_error,
        )
    
    @classmethod
    def error(cls, message: str) -> "MCPToolResult":
        """Create an error result."""
        return cls(
            content=[{"type": "text", "text": f"Error: {message}"}],
            isError=True,
        )
    
    @classmethod
    def json(cls, data: Dict[str, Any]) -> "MCPToolResult":
        """Create a JSON result."""
        import json
        return cls(
            content=[{"type": "text", "text": json.dumps(data, indent=2)}],
            isError=False,
        )
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "content": self.content,
            "isError": self.isError,
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "MCPToolResult":
        """Create from dictionary."""
        return cls(
            content=data.get("content", []),
            isError=data.get("isError", False),
        )


# =============================================================================
# Resource Types
# =============================================================================


@dataclass
class MCPResource:
    """MCP Resource definition.
    
    Attributes:
        uri: Resource URI (e.g., "file:///path/to/file.txt")
        name: Human-readable name
        description: Optional description
        mimeType: Optional MIME type
    """
    
    uri: str
    name: str = ""
    description: str = ""
    mimeType: str | None = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        result = {
            "uri": self.uri,
            "name": self.name or self.uri,
        }
        if self.description:
            result["description"] = self.description
        if self.mimeType:
            result["mimeType"] = self.mimeType
        return result
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "MCPResource":
        """Create from dictionary."""
        return cls(
            uri=data.get("uri", ""),
            name=data.get("name", ""),
            description=data.get("description", ""),
            mimeType=data.get("mimeType"),
        )


@dataclass
class MCPResourceContent:
    """MCP Resource content.
    
    Attributes:
        uri: Resource URI
        mimeType: Content MIME type
        text: Text content (for text resources)
        blob: Base64 encoded binary content (for binary resources)
    """
    
    uri: str
    mimeType: str = "text/plain"
    text: str | None = None
    blob: str | None = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        result = {
            "uri": self.uri,
            "mimeType": self.mimeType,
        }
        if self.text is not None:
            result["text"] = self.text
        if self.blob is not None:
            result["blob"] = self.blob
        return result


@dataclass
class MCPResourceTemplate:
    """MCP Resource template definition.
    
    Attributes:
        uri_template: URI template with placeholders (e.g., "file:///{path}")
        name: Template name
        description: Optional description
        mime_type: Optional MIME type
    """
    
    uri_template: str
    name: str
    description: str = ""
    mime_type: str | None = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        result = {
            "uriTemplate": self.uri_template,
            "name": self.name,
        }
        if self.description:
            result["description"] = self.description
        if self.mime_type:
            result["mimeType"] = self.mime_type
        return result
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "MCPResourceTemplate":
        """Create from dictionary."""
        return cls(
            uri_template=data.get("uriTemplate", ""),
            name=data.get("name", ""),
            description=data.get("description", ""),
            mime_type=data.get("mimeType"),
        )


# =============================================================================
# Prompt Types
# =============================================================================


@dataclass
class MCPPromptArgument:
    """MCP Prompt argument definition.
    
    Attributes:
        name: Argument name
        description: Optional description
        required: Whether argument is required
    """
    
    name: str
    description: str = ""
    required: bool = False
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        result = {
            "name": self.name,
        }
        if self.description:
            result["description"] = self.description
        if self.required:
            result["required"] = True
        return result


@dataclass
class MCPPrompt:
    """MCP Prompt template definition.
    
    Attributes:
        name: Prompt name
        description: Optional description
        arguments: List of required arguments
    """
    
    name: str
    description: str = ""
    arguments: List[MCPPromptArgument] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        result = {
            "name": self.name,
        }
        if self.description:
            result["description"] = self.description
        if self.arguments:
            result["arguments"] = [arg.to_dict() for arg in self.arguments]
        return result


@dataclass
class MCPPromptMessage:
    """MCP Prompt message.
    
    Attributes:
        role: Message role (user, assistant)
        content: Message content
    """
    
    role: str
    content: Dict[str, Any]
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "role": self.role,
            "content": self.content,
        }


# =============================================================================
# Server Info Types
# =============================================================================


@dataclass
class MCPServerInfo:
    """MCP Server information.
    
    Attributes:
        name: Server name
        version: Server version
        protocolVersion: MCP protocol version
        capabilities: Server capabilities
    """
    
    name: str = "MCP Server"
    version: str = "1.0.0"
    protocolVersion: str = MCP_PROTOCOL_VERSION
    capabilities: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "name": self.name,
            "version": self.version,
            "protocolVersion": self.protocolVersion,
            "capabilities": self.capabilities,
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "MCPServerInfo":
        """Create from dictionary."""
        return cls(
            name=data.get("name", "MCP Server"),
            version=data.get("version", "1.0.0"),
            protocolVersion=data.get("protocolVersion", MCP_PROTOCOL_VERSION),
            capabilities=data.get("capabilities", {}),
        )


@dataclass
class MCPClientInfo:
    """MCP Client information.
    
    Attributes:
        name: Client name
        version: Client version
    """
    
    name: str = "MCP Client"
    version: str = "1.0.0"
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "name": self.name,
            "version": self.version,
        }


# =============================================================================
# Initialize Messages
# =============================================================================


@dataclass
class MCPInitializeParams:
    """Parameters for initialize request.
    
    Attributes:
        protocolVersion: Requested protocol version
        clientInfo: Client information
        capabilities: Requested capabilities
    """
    
    protocolVersion: str = MCP_PROTOCOL_VERSION
    clientInfo: MCPClientInfo = field(default_factory=MCPClientInfo)
    capabilities: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "protocolVersion": self.protocolVersion,
            "clientInfo": self.clientInfo.to_dict(),
            "capabilities": self.capabilities,
        }


@dataclass
class MCPInitializeResult:
    """Result of initialize request.
    
    Attributes:
        protocolVersion: Negotiated protocol version
        serverInfo: Server information
        capabilities: Server capabilities
    """
    
    protocolVersion: str = MCP_PROTOCOL_VERSION
    serverInfo: MCPServerInfo = field(default_factory=MCPServerInfo)
    capabilities: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "protocolVersion": self.protocolVersion,
            "serverInfo": self.serverInfo.to_dict(),
            "capabilities": self.capabilities,
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "MCPInitializeResult":
        """Create from dictionary."""
        return cls(
            protocolVersion=data.get("protocolVersion", MCP_PROTOCOL_VERSION),
            serverInfo=MCPServerInfo.from_dict(data.get("serverInfo", {})),
            capabilities=data.get("capabilities", {}),
        )


# =============================================================================
# Type Aliases
# =============================================================================

MCPContent = List[Dict[str, Any]]
MCPArguments = Dict[str, Any]
