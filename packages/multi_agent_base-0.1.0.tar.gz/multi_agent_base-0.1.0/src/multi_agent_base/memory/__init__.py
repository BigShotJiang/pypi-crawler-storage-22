"""
Memory module for multi-agent framework.

Provides memory backends for agent state management, conversation history,
and semantic retrieval.
"""

from multi_agent_base.memory.base import (
    MemoryBackend,
    MemoryEntry,
    MemoryConfig,
    MemoryType,
)
from multi_agent_base.memory.buffer import BufferMemory, SlidingWindowMemory
from multi_agent_base.memory.summary import SummaryMemory
from multi_agent_base.memory.vector import VectorMemory
from multi_agent_base.memory.redis_backend import RedisMemory
from multi_agent_base.memory.composite import CompositeMemory

__all__ = [
    # Base
    "MemoryBackend",
    "MemoryEntry",
    "MemoryConfig",
    "MemoryType",
    # Implementations
    "BufferMemory",
    "SlidingWindowMemory",
    "SummaryMemory",
    "VectorMemory",
    "RedisMemory",
    "CompositeMemory",
]
