"""
Base memory backend interface and common types.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Optional
from pydantic import BaseModel, Field


class MemoryType(str, Enum):
    """Types of memory backends."""
    
    BUFFER = "buffer"
    SLIDING_WINDOW = "sliding_window"
    SUMMARY = "summary"
    VECTOR = "vector"
    REDIS = "redis"
    COMPOSITE = "composite"


class MemoryConfig(BaseModel):
    """Configuration for memory backend."""
    
    memory_type: MemoryType = Field(
        default=MemoryType.BUFFER,
        description="Type of memory backend to use"
    )
    max_messages: int = Field(
        default=100,
        ge=1,
        description="Maximum messages to retain"
    )
    max_tokens: int = Field(
        default=4000,
        ge=100,
        description="Maximum tokens for context window"
    )
    persist: bool = Field(
        default=False,
        description="Enable persistence"
    )
    persist_path: Optional[str] = Field(
        default=None,
        description="Path for persistence storage"
    )
    # Vector memory specific
    embedding_model: str = Field(
        default="text-embedding-3-small",
        description="Model for embeddings"
    )
    embedding_dimensions: int = Field(
        default=1536,
        description="Embedding vector dimensions"
    )
    similarity_threshold: float = Field(
        default=0.7,
        ge=0.0,
        le=1.0,
        description="Minimum similarity for retrieval"
    )
    top_k: int = Field(
        default=5,
        ge=1,
        description="Number of results for semantic search"
    )
    # Redis specific
    redis_url: Optional[str] = Field(
        default=None,
        description="Redis connection URL"
    )
    redis_prefix: str = Field(
        default="agent_memory",
        description="Key prefix for Redis storage"
    )
    ttl_seconds: Optional[int] = Field(
        default=None,
        description="Time-to-live for entries"
    )
    # Summary specific
    summary_model: Optional[str] = Field(
        default=None,
        description="Model for summarization"
    )
    summary_threshold: int = Field(
        default=20,
        ge=5,
        description="Message count before summarization"
    )
    
    class Config:
        use_enum_values = True


@dataclass
class MemorySearchResult:
    """Result of a memory search operation.
    
    Attributes:
        entry: The matched memory entry
        score: Relevance score (0-1)
        distance: Vector distance (if applicable)
    """
    
    entry: "MemoryEntry"
    score: float = 1.0
    distance: float | None = None
    
    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "entry": self.entry.to_dict(),
            "score": self.score,
            "distance": self.distance,
        }


@dataclass
class MemoryEntry:
    """A single memory entry."""
    
    id: str
    role: str  # "user", "assistant", "system", "tool"
    content: str
    timestamp: datetime = field(default_factory=datetime.utcnow)
    agent_name: Optional[str] = None
    session_id: Optional[str] = None
    metadata: dict[str, Any] = field(default_factory=dict)
    embedding: Optional[list[float]] = None
    token_count: int = 0
    
    def to_message(self) -> dict[str, str]:
        """Convert to message dict for LLM."""
        return {"role": self.role, "content": self.content}
    
    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "id": self.id,
            "role": self.role,
            "content": self.content,
            "timestamp": self.timestamp.isoformat(),
            "agent_name": self.agent_name,
            "session_id": self.session_id,
            "metadata": self.metadata,
            "token_count": self.token_count,
        }
    
    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "MemoryEntry":
        """Create from dictionary."""
        timestamp = data.get("timestamp")
        if isinstance(timestamp, str):
            timestamp = datetime.fromisoformat(timestamp)
        elif timestamp is None:
            timestamp = datetime.utcnow()
        
        return cls(
            id=data["id"],
            role=data["role"],
            content=data["content"],
            timestamp=timestamp,
            agent_name=data.get("agent_name"),
            session_id=data.get("session_id"),
            metadata=data.get("metadata", {}),
            token_count=data.get("token_count", 0),
        )


class MemoryBackend(ABC):
    """Abstract base class for memory backends.
    
    All memory implementations must inherit from this class
    and implement the required methods.
    """
    
    def __init__(self, config: MemoryConfig | None = None):
        """Initialize memory backend.
        
        Args:
            config: Memory configuration
        """
        self.config = config or MemoryConfig()
    
    @abstractmethod
    async def add(
        self,
        role: str,
        content: str,
        agent_name: str | None = None,
        session_id: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> MemoryEntry:
        """Add a memory entry.
        
        Args:
            role: Message role (user, assistant, system, tool)
            content: Message content
            agent_name: Name of the agent
            session_id: Session identifier
            metadata: Additional metadata
            
        Returns:
            Created memory entry
        """
        pass
    
    @abstractmethod
    async def get_recent(
        self,
        limit: int | None = None,
        session_id: str | None = None,
        agent_name: str | None = None,
    ) -> list[MemoryEntry]:
        """Get recent memory entries.
        
        Args:
            limit: Maximum entries to return
            session_id: Filter by session
            agent_name: Filter by agent
            
        Returns:
            List of recent entries
        """
        pass
    
    @abstractmethod
    async def search(
        self,
        query: str,
        k: int | None = None,
        session_id: str | None = None,
        agent_name: str | None = None,
    ) -> list[MemoryEntry]:
        """Search memory entries semantically.
        
        Args:
            query: Search query
            k: Number of results
            session_id: Filter by session
            agent_name: Filter by agent
            
        Returns:
            List of matching entries
        """
        pass
    
    @abstractmethod
    async def clear(
        self,
        session_id: str | None = None,
        agent_name: str | None = None,
    ) -> int:
        """Clear memory entries.
        
        Args:
            session_id: Clear only this session
            agent_name: Clear only this agent
            
        Returns:
            Number of entries cleared
        """
        pass
    
    @abstractmethod
    async def get_context(
        self,
        max_tokens: int | None = None,
        session_id: str | None = None,
        include_system: bool = True,
    ) -> list[dict[str, str]]:
        """Get messages formatted for LLM context.
        
        Args:
            max_tokens: Maximum tokens for context
            session_id: Filter by session
            include_system: Include system messages
            
        Returns:
            List of message dicts
        """
        pass
    
    async def get_stats(self) -> dict[str, Any]:
        """Get memory statistics.
        
        Returns:
            Statistics dictionary
        """
        return {
            "type": self.__class__.__name__,
            "config": self.config.model_dump(),
        }
    
    async def close(self) -> None:
        """Clean up resources."""
        pass
    
    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(config={self.config})"
