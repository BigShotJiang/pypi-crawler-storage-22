"""
Buffer-based memory implementations.

Simple in-memory storage with size limits.
"""

import uuid
from datetime import datetime
from typing import Any, Optional
from collections import deque

from multi_agent_base.memory.base import (
    MemoryBackend,
    MemoryConfig,
    MemoryEntry,
)


class BufferMemory(MemoryBackend):
    """Simple buffer memory with maximum size limit.
    
    Stores messages in a list, removing oldest when limit is reached.
    """
    
    def __init__(self, config: MemoryConfig | None = None):
        """Initialize buffer memory.
        
        Args:
            config: Memory configuration
        """
        super().__init__(config)
        self._entries: list[MemoryEntry] = []
        self._system_message: MemoryEntry | None = None
    
    async def add(
        self,
        role: str,
        content: str,
        agent_name: str | None = None,
        session_id: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> MemoryEntry:
        """Add a memory entry."""
        entry = MemoryEntry(
            id=str(uuid.uuid4()),
            role=role,
            content=content,
            timestamp=datetime.utcnow(),
            agent_name=agent_name,
            session_id=session_id,
            metadata=metadata or {},
            token_count=self._estimate_tokens(content),
        )
        
        # System messages are stored separately
        if role == "system":
            self._system_message = entry
            return entry
        
        self._entries.append(entry)
        
        # Trim if exceeds max
        while len(self._entries) > self.config.max_messages:
            self._entries.pop(0)
        
        return entry
    
    async def get_recent(
        self,
        limit: int | None = None,
        session_id: str | None = None,
        agent_name: str | None = None,
    ) -> list[MemoryEntry]:
        """Get recent entries."""
        entries = self._filter_entries(session_id, agent_name)
        
        if limit:
            entries = entries[-limit:]
        
        return entries
    
    async def search(
        self,
        query: str,
        k: int | None = None,
        session_id: str | None = None,
        agent_name: str | None = None,
    ) -> list[MemoryEntry]:
        """Simple keyword search (no semantic search in buffer memory)."""
        entries = self._filter_entries(session_id, agent_name)
        query_lower = query.lower()
        
        # Simple keyword matching
        matches = [
            e for e in entries
            if query_lower in e.content.lower()
        ]
        
        if k:
            matches = matches[:k]
        
        return matches
    
    async def clear(
        self,
        session_id: str | None = None,
        agent_name: str | None = None,
    ) -> int:
        """Clear entries."""
        if session_id is None and agent_name is None:
            count = len(self._entries)
            self._entries.clear()
            self._system_message = None
            return count
        
        original_count = len(self._entries)
        self._entries = [
            e for e in self._entries
            if not self._matches_filter(e, session_id, agent_name)
        ]
        
        return original_count - len(self._entries)
    
    async def get_context(
        self,
        max_tokens: int | None = None,
        session_id: str | None = None,
        include_system: bool = True,
    ) -> list[dict[str, str]]:
        """Get messages for LLM context."""
        max_tokens = max_tokens or self.config.max_tokens
        messages = []
        total_tokens = 0
        
        # Add system message first
        if include_system and self._system_message:
            messages.append(self._system_message.to_message())
            total_tokens += self._system_message.token_count
        
        # Get entries in reverse order (newest first)
        entries = await self.get_recent(session_id=session_id)
        
        # Build context respecting token limit
        context_entries = []
        for entry in reversed(entries):
            if total_tokens + entry.token_count > max_tokens:
                break
            context_entries.insert(0, entry)
            total_tokens += entry.token_count
        
        messages.extend([e.to_message() for e in context_entries])
        return messages
    
    async def get_stats(self) -> dict[str, Any]:
        """Get memory statistics."""
        stats = await super().get_stats()
        stats.update({
            "entry_count": len(self._entries),
            "has_system_message": self._system_message is not None,
            "total_tokens": sum(e.token_count for e in self._entries),
        })
        return stats
    
    def _filter_entries(
        self,
        session_id: str | None,
        agent_name: str | None,
    ) -> list[MemoryEntry]:
        """Filter entries by session and agent."""
        entries = self._entries
        
        if session_id:
            entries = [e for e in entries if e.session_id == session_id]
        
        if agent_name:
            entries = [e for e in entries if e.agent_name == agent_name]
        
        return entries
    
    def _matches_filter(
        self,
        entry: MemoryEntry,
        session_id: str | None,
        agent_name: str | None,
    ) -> bool:
        """Check if entry matches filter criteria."""
        if session_id and entry.session_id != session_id:
            return False
        if agent_name and entry.agent_name != agent_name:
            return False
        return True
    
    def _estimate_tokens(self, text: str) -> int:
        """Estimate token count (rough approximation)."""
        # ~4 chars per token on average
        return len(text) // 4 + 1


class SlidingWindowMemory(MemoryBackend):
    """Sliding window memory with token-based limits.
    
    Maintains a fixed context window by token count,
    automatically removing oldest messages when limit is exceeded.
    """
    
    def __init__(self, config: MemoryConfig | None = None):
        """Initialize sliding window memory.
        
        Args:
            config: Memory configuration
        """
        super().__init__(config)
        self._entries: deque[MemoryEntry] = deque()
        self._system_message: MemoryEntry | None = None
        self._current_tokens: int = 0
    
    async def add(
        self,
        role: str,
        content: str,
        agent_name: str | None = None,
        session_id: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> MemoryEntry:
        """Add entry with automatic window sliding."""
        token_count = self._estimate_tokens(content)
        
        entry = MemoryEntry(
            id=str(uuid.uuid4()),
            role=role,
            content=content,
            timestamp=datetime.utcnow(),
            agent_name=agent_name,
            session_id=session_id,
            metadata=metadata or {},
            token_count=token_count,
        )
        
        if role == "system":
            # System message doesn't count against window
            self._system_message = entry
            return entry
        
        # Slide window if needed
        while (self._current_tokens + token_count > self.config.max_tokens
               and self._entries):
            removed = self._entries.popleft()
            self._current_tokens -= removed.token_count
        
        self._entries.append(entry)
        self._current_tokens += token_count
        
        return entry
    
    async def get_recent(
        self,
        limit: int | None = None,
        session_id: str | None = None,
        agent_name: str | None = None,
    ) -> list[MemoryEntry]:
        """Get recent entries."""
        entries = list(self._entries)
        
        if session_id:
            entries = [e for e in entries if e.session_id == session_id]
        if agent_name:
            entries = [e for e in entries if e.agent_name == agent_name]
        if limit:
            entries = entries[-limit:]
        
        return entries
    
    async def search(
        self,
        query: str,
        k: int | None = None,
        session_id: str | None = None,
        agent_name: str | None = None,
    ) -> list[MemoryEntry]:
        """Simple keyword search."""
        entries = await self.get_recent(session_id=session_id, agent_name=agent_name)
        query_lower = query.lower()
        
        matches = [e for e in entries if query_lower in e.content.lower()]
        
        if k:
            matches = matches[:k]
        
        return matches
    
    async def clear(
        self,
        session_id: str | None = None,
        agent_name: str | None = None,
    ) -> int:
        """Clear entries."""
        if session_id is None and agent_name is None:
            count = len(self._entries)
            self._entries.clear()
            self._system_message = None
            self._current_tokens = 0
            return count
        
        # Filter and rebuild
        remaining = deque()
        removed_count = 0
        new_tokens = 0
        
        for entry in self._entries:
            should_remove = (
                (session_id is None or entry.session_id == session_id) and
                (agent_name is None or entry.agent_name == agent_name)
            )
            if should_remove:
                removed_count += 1
            else:
                remaining.append(entry)
                new_tokens += entry.token_count
        
        self._entries = remaining
        self._current_tokens = new_tokens
        
        return removed_count
    
    async def get_context(
        self,
        max_tokens: int | None = None,
        session_id: str | None = None,
        include_system: bool = True,
    ) -> list[dict[str, str]]:
        """Get messages for LLM context."""
        messages = []
        
        if include_system and self._system_message:
            messages.append(self._system_message.to_message())
        
        # Window already respects token limit
        entries = await self.get_recent(session_id=session_id)
        messages.extend([e.to_message() for e in entries])
        
        return messages
    
    async def get_stats(self) -> dict[str, Any]:
        """Get memory statistics."""
        stats = await super().get_stats()
        stats.update({
            "entry_count": len(self._entries),
            "current_tokens": self._current_tokens,
            "max_tokens": self.config.max_tokens,
            "utilization": self._current_tokens / self.config.max_tokens,
        })
        return stats
    
    def _estimate_tokens(self, text: str) -> int:
        """Estimate token count."""
        return len(text) // 4 + 1


# Alias for backward compatibility
InMemoryBackend = BufferMemory
