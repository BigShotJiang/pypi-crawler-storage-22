"""
Composite memory combining multiple backends.

Enables layered memory architecture (e.g., buffer + vector for RAG).
"""

import uuid
from datetime import datetime
from typing import Any

from multi_agent_base.memory.base import (
    MemoryBackend,
    MemoryConfig,
    MemoryEntry,
)


class CompositeMemory(MemoryBackend):
    """Composite memory combining multiple backends.
    
    Enables sophisticated memory architectures:
    - Short-term buffer + Long-term vector storage
    - Local buffer + Remote Redis for persistence
    - Multiple specialized memories for different purposes
    
    Example:
        composite = CompositeMemory()
        composite.add_backend("buffer", BufferMemory())
        composite.add_backend("vector", VectorMemory(), search_enabled=True)
        composite.add_backend("redis", RedisMemory(), persist_enabled=True)
    """
    
    def __init__(self, config: MemoryConfig | None = None):
        """Initialize composite memory.
        
        Args:
            config: Memory configuration
        """
        super().__init__(config)
        self._backends: dict[str, MemoryBackend] = {}
        self._primary_backend: str | None = None
        self._search_backend: str | None = None
        self._persist_backends: list[str] = []
    
    def add_backend(
        self,
        name: str,
        backend: MemoryBackend,
        primary: bool = False,
        search_enabled: bool = False,
        persist_enabled: bool = False,
    ) -> None:
        """Add a memory backend.
        
        Args:
            name: Unique name for this backend
            backend: Memory backend instance
            primary: Use as primary for get_recent/get_context
            search_enabled: Use for semantic search
            persist_enabled: Write to this backend for persistence
        """
        self._backends[name] = backend
        
        if primary or self._primary_backend is None:
            self._primary_backend = name
        
        if search_enabled:
            self._search_backend = name
        
        if persist_enabled:
            self._persist_backends.append(name)
    
    def get_backend(self, name: str) -> MemoryBackend | None:
        """Get a specific backend by name."""
        return self._backends.get(name)
    
    def remove_backend(self, name: str) -> bool:
        """Remove a backend."""
        if name in self._backends:
            del self._backends[name]
            
            if self._primary_backend == name:
                self._primary_backend = next(iter(self._backends), None)
            
            if self._search_backend == name:
                self._search_backend = None
            
            if name in self._persist_backends:
                self._persist_backends.remove(name)
            
            return True
        return False
    
    async def add(
        self,
        role: str,
        content: str,
        agent_name: str | None = None,
        session_id: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> MemoryEntry:
        """Add to all backends (or persist backends only)."""
        entry = None
        
        # Determine which backends to write to
        backends_to_write = self._persist_backends if self._persist_backends else list(self._backends.keys())
        
        for name in backends_to_write:
            backend = self._backends.get(name)
            if backend:
                result = await backend.add(
                    role=role,
                    content=content,
                    agent_name=agent_name,
                    session_id=session_id,
                    metadata=metadata,
                )
                if entry is None:
                    entry = result
        
        # If no persist backends, write to primary
        if not backends_to_write and self._primary_backend:
            entry = await self._backends[self._primary_backend].add(
                role=role,
                content=content,
                agent_name=agent_name,
                session_id=session_id,
                metadata=metadata,
            )
        
        return entry or MemoryEntry(
            id=str(uuid.uuid4()),
            role=role,
            content=content,
            timestamp=datetime.utcnow(),
            agent_name=agent_name,
            session_id=session_id,
            metadata=metadata or {},
        )
    
    async def get_recent(
        self,
        limit: int | None = None,
        session_id: str | None = None,
        agent_name: str | None = None,
    ) -> list[MemoryEntry]:
        """Get recent from primary backend."""
        if self._primary_backend and self._primary_backend in self._backends:
            return await self._backends[self._primary_backend].get_recent(
                limit=limit,
                session_id=session_id,
                agent_name=agent_name,
            )
        return []
    
    async def search(
        self,
        query: str,
        k: int | None = None,
        session_id: str | None = None,
        agent_name: str | None = None,
    ) -> list[MemoryEntry]:
        """Search using search-enabled backend (falls back to primary)."""
        backend_name = self._search_backend or self._primary_backend
        
        if backend_name and backend_name in self._backends:
            return await self._backends[backend_name].search(
                query=query,
                k=k,
                session_id=session_id,
                agent_name=agent_name,
            )
        return []
    
    async def clear(
        self,
        session_id: str | None = None,
        agent_name: str | None = None,
    ) -> int:
        """Clear all backends."""
        total_cleared = 0
        
        for backend in self._backends.values():
            cleared = await backend.clear(
                session_id=session_id,
                agent_name=agent_name,
            )
            total_cleared += cleared
        
        return total_cleared
    
    async def get_context(
        self,
        max_tokens: int | None = None,
        session_id: str | None = None,
        include_system: bool = True,
        query: str | None = None,
    ) -> list[dict[str, str]]:
        """Get context, optionally with RAG from search backend.
        
        Args:
            max_tokens: Maximum tokens
            session_id: Filter by session
            include_system: Include system message
            query: If provided and search backend exists, include relevant context
        """
        max_tokens = max_tokens or self.config.max_tokens
        messages = []
        total_tokens = 0
        
        # Get relevant context from search backend if query provided
        if query and self._search_backend:
            search_backend = self._backends.get(self._search_backend)
            if search_backend:
                relevant = await search_backend.search(
                    query=query,
                    k=self.config.top_k,
                    session_id=session_id,
                )
                
                if relevant:
                    context_parts = [
                        f"[Relevant]: {e.content}" for e in relevant
                    ]
                    context_text = "\n".join(context_parts)
                    context_tokens = len(context_text) // 4 + 1
                    
                    if total_tokens + context_tokens <= max_tokens:
                        messages.append({
                            "role": "system",
                            "content": context_text
                        })
                        total_tokens += context_tokens
        
        # Get recent from primary backend
        if self._primary_backend:
            primary = self._backends.get(self._primary_backend)
            if primary:
                # Check if backend supports query parameter
                if hasattr(primary, 'get_context'):
                    import inspect
                    sig = inspect.signature(primary.get_context)
                    if 'query' in sig.parameters:
                        primary_messages = await primary.get_context(
                            max_tokens=max_tokens - total_tokens,
                            session_id=session_id,
                            include_system=include_system,
                            query=None,  # Already handled above
                        )
                    else:
                        primary_messages = await primary.get_context(
                            max_tokens=max_tokens - total_tokens,
                            session_id=session_id,
                            include_system=include_system,
                        )
                    messages.extend(primary_messages)
        
        return messages
    
    async def get_stats(self) -> dict[str, Any]:
        """Get statistics from all backends."""
        stats = await super().get_stats()
        
        backend_stats = {}
        for name, backend in self._backends.items():
            backend_stats[name] = await backend.get_stats()
        
        stats.update({
            "backend_count": len(self._backends),
            "primary_backend": self._primary_backend,
            "search_backend": self._search_backend,
            "persist_backends": self._persist_backends,
            "backends": backend_stats,
        })
        
        return stats
    
    async def close(self) -> None:
        """Close all backends."""
        for backend in self._backends.values():
            await backend.close()


def create_memory(
    config: MemoryConfig | None = None,
    **kwargs,
) -> MemoryBackend:
    """Factory function to create memory backend from config.
    
    Args:
        config: Memory configuration
        **kwargs: Additional arguments for specific backends
        
    Returns:
        Configured memory backend
    """
    from multi_agent_base.memory.buffer import BufferMemory, SlidingWindowMemory
    from multi_agent_base.memory.summary import SummaryMemory
    from multi_agent_base.memory.vector import VectorMemory
    from multi_agent_base.memory.redis_backend import RedisMemory
    from multi_agent_base.memory.base import MemoryType
    
    config = config or MemoryConfig()
    
    memory_classes = {
        MemoryType.BUFFER: BufferMemory,
        MemoryType.SLIDING_WINDOW: SlidingWindowMemory,
        MemoryType.SUMMARY: SummaryMemory,
        MemoryType.VECTOR: VectorMemory,
        MemoryType.REDIS: RedisMemory,
        MemoryType.COMPOSITE: CompositeMemory,
    }
    
    memory_class = memory_classes.get(config.memory_type, BufferMemory)
    return memory_class(config=config, **kwargs)
