"""
Redis-based persistent memory backend.

Provides distributed, persistent memory storage.
"""

import uuid
import json
from datetime import datetime
from typing import Any, Optional

from multi_agent_base.memory.base import (
    MemoryBackend,
    MemoryConfig,
    MemoryEntry,
)


class RedisMemory(MemoryBackend):
    """Redis-backed persistent memory.
    
    Provides:
    - Persistent storage across restarts
    - Distributed access for multi-instance deployments
    - TTL support for automatic expiration
    - Efficient sorted set operations for ordering
    """
    
    def __init__(
        self,
        config: MemoryConfig | None = None,
        redis_client: Optional[Any] = None,
    ):
        """Initialize Redis memory.
        
        Args:
            config: Memory configuration
            redis_client: Optional redis.asyncio.Redis client.
                         If not provided, will create from config.
        """
        super().__init__(config)
        self._client = redis_client
        self._initialized = False
    
    async def _ensure_client(self) -> None:
        """Ensure Redis client is initialized."""
        if self._initialized:
            return
        
        if self._client is None:
            try:
                import redis.asyncio as redis
                
                url = self.config.redis_url or "redis://localhost:6379"
                self._client = redis.from_url(url, decode_responses=True)
            except ImportError:
                raise ImportError(
                    "Redis client not installed. "
                    "Install with: pip install redis"
                )
        
        self._initialized = True
    
    def _key(self, *parts: str) -> str:
        """Build Redis key with prefix."""
        return ":".join([self.config.redis_prefix] + list(parts))
    
    async def add(
        self,
        role: str,
        content: str,
        agent_name: str | None = None,
        session_id: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> MemoryEntry:
        """Add entry to Redis."""
        await self._ensure_client()
        
        entry_id = str(uuid.uuid4())
        timestamp = datetime.utcnow()
        
        entry = MemoryEntry(
            id=entry_id,
            role=role,
            content=content,
            timestamp=timestamp,
            agent_name=agent_name,
            session_id=session_id or "default",
            metadata=metadata or {},
            token_count=self._estimate_tokens(content),
        )
        
        # Store entry as hash
        entry_key = self._key("entry", entry_id)
        await self._client.hset(entry_key, mapping={
            "id": entry.id,
            "role": entry.role,
            "content": entry.content,
            "timestamp": entry.timestamp.isoformat(),
            "agent_name": entry.agent_name or "",
            "session_id": entry.session_id or "",
            "metadata": json.dumps(entry.metadata),
            "token_count": str(entry.token_count),
        })
        
        # Set TTL if configured
        if self.config.ttl_seconds:
            await self._client.expire(entry_key, self.config.ttl_seconds)
        
        # Add to sorted set for ordering (by timestamp)
        score = timestamp.timestamp()
        
        # Global timeline
        await self._client.zadd(
            self._key("timeline"),
            {entry_id: score}
        )
        
        # Session timeline
        if session_id:
            await self._client.zadd(
                self._key("session", session_id),
                {entry_id: score}
            )
        
        # Agent timeline
        if agent_name:
            await self._client.zadd(
                self._key("agent", agent_name),
                {entry_id: score}
            )
        
        # Trim if exceeds max
        await self._trim_entries()
        
        return entry
    
    async def get_recent(
        self,
        limit: int | None = None,
        session_id: str | None = None,
        agent_name: str | None = None,
    ) -> list[MemoryEntry]:
        """Get recent entries from Redis."""
        await self._ensure_client()
        
        limit = limit or self.config.max_messages
        
        # Determine which sorted set to use
        if session_id:
            timeline_key = self._key("session", session_id)
        elif agent_name:
            timeline_key = self._key("agent", agent_name)
        else:
            timeline_key = self._key("timeline")
        
        # Get recent entry IDs (sorted by timestamp, newest last)
        entry_ids = await self._client.zrange(
            timeline_key,
            -limit,
            -1
        )
        
        # Fetch entries
        entries = []
        for entry_id in entry_ids:
            entry = await self._get_entry(entry_id)
            if entry:
                # Additional filtering
                if session_id and entry.session_id != session_id:
                    continue
                if agent_name and entry.agent_name != agent_name:
                    continue
                entries.append(entry)
        
        return entries
    
    async def search(
        self,
        query: str,
        k: int | None = None,
        session_id: str | None = None,
        agent_name: str | None = None,
    ) -> list[MemoryEntry]:
        """Search entries (keyword-based for basic Redis).
        
        Note: For semantic search with Redis, use RediSearch module.
        """
        await self._ensure_client()
        
        k = k or self.config.top_k
        
        # Get all entries (limited)
        entries = await self.get_recent(
            limit=self.config.max_messages,
            session_id=session_id,
            agent_name=agent_name
        )
        
        # Simple keyword match
        query_lower = query.lower()
        matches = [
            e for e in entries
            if query_lower in e.content.lower()
        ]
        
        return matches[:k]
    
    async def clear(
        self,
        session_id: str | None = None,
        agent_name: str | None = None,
    ) -> int:
        """Clear entries from Redis."""
        await self._ensure_client()
        
        if session_id:
            # Clear session entries
            timeline_key = self._key("session", session_id)
            entry_ids = await self._client.zrange(timeline_key, 0, -1)
            
            for entry_id in entry_ids:
                await self._delete_entry(entry_id)
            
            await self._client.delete(timeline_key)
            return len(entry_ids)
        
        elif agent_name:
            # Clear agent entries
            timeline_key = self._key("agent", agent_name)
            entry_ids = await self._client.zrange(timeline_key, 0, -1)
            
            for entry_id in entry_ids:
                await self._delete_entry(entry_id)
            
            await self._client.delete(timeline_key)
            return len(entry_ids)
        
        else:
            # Clear all
            timeline_key = self._key("timeline")
            entry_ids = await self._client.zrange(timeline_key, 0, -1)
            
            for entry_id in entry_ids:
                await self._delete_entry(entry_id)
            
            # Delete all timeline keys
            pattern = self._key("*")
            keys = []
            async for key in self._client.scan_iter(match=pattern):
                keys.append(key)
            
            if keys:
                await self._client.delete(*keys)
            
            return len(entry_ids)
    
    async def get_context(
        self,
        max_tokens: int | None = None,
        session_id: str | None = None,
        include_system: bool = True,
    ) -> list[dict[str, str]]:
        """Get context from Redis."""
        max_tokens = max_tokens or self.config.max_tokens
        
        entries = await self.get_recent(session_id=session_id)
        
        messages = []
        total_tokens = 0
        
        # Build context respecting token limit
        for entry in reversed(entries):
            if total_tokens + entry.token_count > max_tokens:
                break
            messages.insert(0, entry.to_message())
            total_tokens += entry.token_count
        
        return messages
    
    async def get_stats(self) -> dict[str, Any]:
        """Get memory statistics."""
        await self._ensure_client()
        
        stats = await super().get_stats()
        
        timeline_key = self._key("timeline")
        entry_count = await self._client.zcard(timeline_key)
        
        stats.update({
            "entry_count": entry_count,
            "redis_url": self.config.redis_url or "redis://localhost:6379",
            "prefix": self.config.redis_prefix,
            "ttl_seconds": self.config.ttl_seconds,
        })
        
        return stats
    
    async def close(self) -> None:
        """Close Redis connection."""
        if self._client:
            await self._client.close()
    
    async def _get_entry(self, entry_id: str) -> MemoryEntry | None:
        """Get entry by ID."""
        entry_key = self._key("entry", entry_id)
        data = await self._client.hgetall(entry_key)
        
        if not data:
            return None
        
        return MemoryEntry(
            id=data["id"],
            role=data["role"],
            content=data["content"],
            timestamp=datetime.fromisoformat(data["timestamp"]),
            agent_name=data.get("agent_name") or None,
            session_id=data.get("session_id") or None,
            metadata=json.loads(data.get("metadata", "{}")),
            token_count=int(data.get("token_count", 0)),
        )
    
    async def _delete_entry(self, entry_id: str) -> None:
        """Delete entry and remove from all indices."""
        entry_key = self._key("entry", entry_id)
        
        # Get entry to know which indices to clean
        entry = await self._get_entry(entry_id)
        
        # Delete entry
        await self._client.delete(entry_key)
        
        # Remove from indices
        await self._client.zrem(self._key("timeline"), entry_id)
        
        if entry:
            if entry.session_id:
                await self._client.zrem(
                    self._key("session", entry.session_id),
                    entry_id
                )
            if entry.agent_name:
                await self._client.zrem(
                    self._key("agent", entry.agent_name),
                    entry_id
                )
    
    async def _trim_entries(self) -> None:
        """Trim entries to max count."""
        timeline_key = self._key("timeline")
        count = await self._client.zcard(timeline_key)
        
        if count > self.config.max_messages:
            # Get oldest entries to remove
            to_remove = count - self.config.max_messages
            oldest_ids = await self._client.zrange(timeline_key, 0, to_remove - 1)
            
            for entry_id in oldest_ids:
                await self._delete_entry(entry_id)
    
    def _estimate_tokens(self, text: str) -> int:
        """Estimate token count."""
        return len(text) // 4 + 1
