"""
Summary-based memory implementation.

Uses LLM to summarize conversation when it exceeds threshold.
"""

import uuid
from datetime import datetime
from typing import Any, Callable, Awaitable

from multi_agent_base.memory.base import (
    MemoryBackend,
    MemoryConfig,
    MemoryEntry,
)


class SummaryMemory(MemoryBackend):
    """Memory that summarizes old conversations.
    
    When message count exceeds threshold, older messages are
    summarized using an LLM and replaced with the summary.
    """
    
    def __init__(
        self,
        config: MemoryConfig | None = None,
        summarizer: Callable[[list[dict]], Awaitable[str]] | None = None,
    ):
        """Initialize summary memory.
        
        Args:
            config: Memory configuration
            summarizer: Async function to summarize messages.
                        If not provided, uses simple concatenation.
        """
        super().__init__(config)
        self._entries: list[MemoryEntry] = []
        self._summaries: list[MemoryEntry] = []
        self._system_message: MemoryEntry | None = None
        self._summarizer = summarizer or self._default_summarizer
    
    async def add(
        self,
        role: str,
        content: str,
        agent_name: str | None = None,
        session_id: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> MemoryEntry:
        """Add entry, triggering summarization if threshold reached."""
        entry = MemoryEntry(
            id=str(uuid.uuid4()),
            role=role,
            content=content,
            timestamp=datetime.utcnow(),
            agent_name=agent_name,
            session_id=session_id,
            metadata=metadata or {},
            token_count=self._estimate_tokens(content),
        )
        
        if role == "system":
            self._system_message = entry
            return entry
        
        self._entries.append(entry)
        
        # Check if summarization needed
        if len(self._entries) >= self.config.summary_threshold:
            await self._summarize_oldest()
        
        return entry
    
    async def get_recent(
        self,
        limit: int | None = None,
        session_id: str | None = None,
        agent_name: str | None = None,
    ) -> list[MemoryEntry]:
        """Get recent entries including summaries."""
        # Combine summaries and entries
        all_entries = self._summaries + self._entries
        
        if session_id:
            all_entries = [e for e in all_entries if e.session_id == session_id]
        if agent_name:
            all_entries = [e for e in all_entries if e.agent_name == agent_name]
        if limit:
            all_entries = all_entries[-limit:]
        
        return all_entries
    
    async def search(
        self,
        query: str,
        k: int | None = None,
        session_id: str | None = None,
        agent_name: str | None = None,
    ) -> list[MemoryEntry]:
        """Search in entries and summaries."""
        entries = await self.get_recent(session_id=session_id, agent_name=agent_name)
        query_lower = query.lower()
        
        matches = [e for e in entries if query_lower in e.content.lower()]
        
        if k:
            matches = matches[:k]
        
        return matches
    
    async def clear(
        self,
        session_id: str | None = None,
        agent_name: str | None = None,
    ) -> int:
        """Clear entries and summaries."""
        if session_id is None and agent_name is None:
            count = len(self._entries) + len(self._summaries)
            self._entries.clear()
            self._summaries.clear()
            self._system_message = None
            return count
        
        original_count = len(self._entries) + len(self._summaries)
        
        self._entries = [
            e for e in self._entries
            if not self._matches_filter(e, session_id, agent_name)
        ]
        self._summaries = [
            e for e in self._summaries
            if not self._matches_filter(e, session_id, agent_name)
        ]
        
        return original_count - len(self._entries) - len(self._summaries)
    
    async def get_context(
        self,
        max_tokens: int | None = None,
        session_id: str | None = None,
        include_system: bool = True,
    ) -> list[dict[str, str]]:
        """Get context with summaries and recent messages."""
        max_tokens = max_tokens or self.config.max_tokens
        messages = []
        total_tokens = 0
        
        # System message
        if include_system and self._system_message:
            messages.append(self._system_message.to_message())
            total_tokens += self._system_message.token_count
        
        # Add summaries first (condensed history)
        for summary in self._summaries:
            if session_id and summary.session_id != session_id:
                continue
            if total_tokens + summary.token_count > max_tokens:
                break
            messages.append({
                "role": "system",
                "content": f"[Previous conversation summary]: {summary.content}"
            })
            total_tokens += summary.token_count
        
        # Add recent entries
        for entry in self._entries:
            if session_id and entry.session_id != session_id:
                continue
            if total_tokens + entry.token_count > max_tokens:
                break
            messages.append(entry.to_message())
            total_tokens += entry.token_count
        
        return messages
    
    async def get_stats(self) -> dict[str, Any]:
        """Get memory statistics."""
        stats = await super().get_stats()
        stats.update({
            "entry_count": len(self._entries),
            "summary_count": len(self._summaries),
            "summary_threshold": self.config.summary_threshold,
        })
        return stats
    
    async def _summarize_oldest(self) -> None:
        """Summarize oldest messages."""
        # Take half of entries for summarization
        split_point = len(self._entries) // 2
        to_summarize = self._entries[:split_point]
        self._entries = self._entries[split_point:]
        
        if not to_summarize:
            return
        
        # Create summary
        messages = [e.to_message() for e in to_summarize]
        summary_content = await self._summarizer(messages)
        
        summary_entry = MemoryEntry(
            id=str(uuid.uuid4()),
            role="system",
            content=summary_content,
            timestamp=datetime.utcnow(),
            metadata={"type": "summary", "summarized_count": len(to_summarize)},
            token_count=self._estimate_tokens(summary_content),
        )
        
        self._summaries.append(summary_entry)
    
    async def _default_summarizer(self, messages: list[dict]) -> str:
        """Default summarizer (simple concatenation)."""
        parts = []
        for msg in messages:
            role = msg["role"]
            content = msg["content"][:200]  # Truncate
            parts.append(f"{role}: {content}")
        
        return "Summary of previous conversation:\n" + "\n".join(parts)
    
    def set_summarizer(
        self,
        summarizer: Callable[[list[dict]], Awaitable[str]]
    ) -> None:
        """Set custom summarizer function.
        
        Args:
            summarizer: Async function that takes messages and returns summary
        """
        self._summarizer = summarizer
    
    def _matches_filter(
        self,
        entry: MemoryEntry,
        session_id: str | None,
        agent_name: str | None,
    ) -> bool:
        """Check if entry matches filter."""
        if session_id and entry.session_id != session_id:
            return False
        if agent_name and entry.agent_name != agent_name:
            return False
        return True
    
    def _estimate_tokens(self, text: str) -> int:
        """Estimate token count."""
        return len(text) // 4 + 1
