"""
Vector-based memory with semantic search.

Uses embeddings for similarity-based retrieval (RAG support).
"""

import uuid
from datetime import datetime
from typing import Any, Callable, Awaitable, Optional
import math

from multi_agent_base.memory.base import (
    MemoryBackend,
    MemoryConfig,
    MemoryEntry,
)


class VectorMemory(MemoryBackend):
    """Vector memory with semantic search capabilities.
    
    Stores embeddings alongside messages for similarity-based retrieval.
    Supports integration with embedding providers (OpenAI, local models).
    """
    
    def __init__(
        self,
        config: MemoryConfig | None = None,
        embedder: Callable[[str], Awaitable[list[float]]] | None = None,
        vector_store: Optional[Any] = None,
    ):
        """Initialize vector memory.
        
        Args:
            config: Memory configuration
            embedder: Async function to generate embeddings.
                     If not provided, uses simple TF-IDF-like vectors.
            vector_store: Optional external vector store (ChromaDB, Pinecone).
                         If not provided, uses in-memory storage.
        """
        super().__init__(config)
        self._entries: list[MemoryEntry] = []
        self._system_message: MemoryEntry | None = None
        self._embedder = embedder or self._default_embedder
        self._vector_store = vector_store
        self._vocabulary: dict[str, int] = {}
    
    async def add(
        self,
        role: str,
        content: str,
        agent_name: str | None = None,
        session_id: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> MemoryEntry:
        """Add entry with embedding."""
        # Generate embedding
        embedding = await self._embedder(content)
        
        entry = MemoryEntry(
            id=str(uuid.uuid4()),
            role=role,
            content=content,
            timestamp=datetime.utcnow(),
            agent_name=agent_name,
            session_id=session_id,
            metadata=metadata or {},
            embedding=embedding,
            token_count=self._estimate_tokens(content),
        )
        
        if role == "system":
            self._system_message = entry
            return entry
        
        # Add to vector store if available
        if self._vector_store is not None:
            await self._add_to_vector_store(entry)
        else:
            self._entries.append(entry)
        
        # Trim if exceeds max
        while len(self._entries) > self.config.max_messages:
            self._entries.pop(0)
        
        return entry
    
    async def get_recent(
        self,
        limit: int | None = None,
        session_id: str | None = None,
        agent_name: str | None = None,
    ) -> list[MemoryEntry]:
        """Get recent entries."""
        entries = self._filter_entries(session_id, agent_name)
        
        if limit:
            entries = entries[-limit:]
        
        return entries
    
    async def search(
        self,
        query: str,
        k: int | None = None,
        session_id: str | None = None,
        agent_name: str | None = None,
    ) -> list[MemoryEntry]:
        """Semantic search using embeddings."""
        k = k or self.config.top_k
        
        # External vector store
        if self._vector_store is not None:
            return await self._search_vector_store(
                query, k, session_id, agent_name
            )
        
        # In-memory semantic search
        query_embedding = await self._embedder(query)
        entries = self._filter_entries(session_id, agent_name)
        
        # Calculate similarities
        scored_entries = []
        for entry in entries:
            if entry.embedding:
                similarity = self._cosine_similarity(
                    query_embedding, entry.embedding
                )
                if similarity >= self.config.similarity_threshold:
                    scored_entries.append((similarity, entry))
        
        # Sort by similarity (descending)
        scored_entries.sort(key=lambda x: x[0], reverse=True)
        
        return [entry for _, entry in scored_entries[:k]]
    
    async def clear(
        self,
        session_id: str | None = None,
        agent_name: str | None = None,
    ) -> int:
        """Clear entries."""
        if self._vector_store is not None:
            return await self._clear_vector_store(session_id, agent_name)
        
        if session_id is None and agent_name is None:
            count = len(self._entries)
            self._entries.clear()
            self._system_message = None
            return count
        
        original_count = len(self._entries)
        self._entries = [
            e for e in self._entries
            if not self._matches_filter(e, session_id, agent_name)
        ]
        
        return original_count - len(self._entries)
    
    async def get_context(
        self,
        max_tokens: int | None = None,
        session_id: str | None = None,
        include_system: bool = True,
        query: str | None = None,
    ) -> list[dict[str, str]]:
        """Get context with optional RAG retrieval.
        
        Args:
            max_tokens: Maximum tokens for context
            session_id: Filter by session
            include_system: Include system message
            query: If provided, retrieves relevant context via search
        """
        max_tokens = max_tokens or self.config.max_tokens
        messages = []
        total_tokens = 0
        
        # System message
        if include_system and self._system_message:
            messages.append(self._system_message.to_message())
            total_tokens += self._system_message.token_count
        
        # Retrieve relevant context if query provided
        if query:
            relevant = await self.search(
                query,
                k=self.config.top_k,
                session_id=session_id
            )
            
            if relevant:
                context_text = "\n".join([
                    f"[Relevant context]: {e.content}" for e in relevant
                ])
                context_tokens = self._estimate_tokens(context_text)
                
                if total_tokens + context_tokens <= max_tokens:
                    messages.append({
                        "role": "system",
                        "content": context_text
                    })
                    total_tokens += context_tokens
        
        # Add recent messages
        entries = await self.get_recent(session_id=session_id)
        context_entries = []
        
        for entry in reversed(entries):
            if total_tokens + entry.token_count > max_tokens:
                break
            context_entries.insert(0, entry)
            total_tokens += entry.token_count
        
        messages.extend([e.to_message() for e in context_entries])
        
        return messages
    
    async def get_stats(self) -> dict[str, Any]:
        """Get memory statistics."""
        stats = await super().get_stats()
        stats.update({
            "entry_count": len(self._entries),
            "has_external_store": self._vector_store is not None,
            "vocabulary_size": len(self._vocabulary),
            "embedding_dimensions": self.config.embedding_dimensions,
        })
        return stats
    
    def set_embedder(
        self,
        embedder: Callable[[str], Awaitable[list[float]]]
    ) -> None:
        """Set custom embedding function.
        
        Args:
            embedder: Async function that takes text and returns embedding vector
        """
        self._embedder = embedder
    
    def set_vector_store(self, store: Any) -> None:
        """Set external vector store.
        
        Args:
            store: Vector store instance (ChromaDB, Pinecone, etc.)
        """
        self._vector_store = store
    
    async def _add_to_vector_store(self, entry: MemoryEntry) -> None:
        """Add entry to external vector store."""
        # Interface for common vector stores
        if hasattr(self._vector_store, 'add'):
            await self._vector_store.add(
                ids=[entry.id],
                embeddings=[entry.embedding],
                documents=[entry.content],
                metadatas=[entry.to_dict()]
            )
        elif hasattr(self._vector_store, 'upsert'):
            await self._vector_store.upsert(
                vectors=[(entry.id, entry.embedding, entry.to_dict())]
            )
    
    async def _search_vector_store(
        self,
        query: str,
        k: int,
        session_id: str | None,
        agent_name: str | None,
    ) -> list[MemoryEntry]:
        """Search external vector store."""
        query_embedding = await self._embedder(query)
        
        # Build filter
        filter_dict = {}
        if session_id:
            filter_dict["session_id"] = session_id
        if agent_name:
            filter_dict["agent_name"] = agent_name
        
        # Query vector store
        if hasattr(self._vector_store, 'query'):
            results = await self._vector_store.query(
                query_embeddings=[query_embedding],
                n_results=k,
                where=filter_dict if filter_dict else None
            )
            
            entries = []
            for i, doc in enumerate(results.get('documents', [[]])[0]):
                metadata = results.get('metadatas', [[]])[0][i]
                entries.append(MemoryEntry.from_dict({
                    **metadata,
                    'content': doc
                }))
            return entries
        
        return []
    
    async def _clear_vector_store(
        self,
        session_id: str | None,
        agent_name: str | None,
    ) -> int:
        """Clear entries from vector store."""
        if hasattr(self._vector_store, 'delete'):
            filter_dict = {}
            if session_id:
                filter_dict["session_id"] = session_id
            if agent_name:
                filter_dict["agent_name"] = agent_name
            
            if filter_dict:
                await self._vector_store.delete(where=filter_dict)
            else:
                # Clear all - implementation depends on store
                pass
        
        return 0  # Can't easily get count from external store
    
    async def _default_embedder(self, text: str) -> list[float]:
        """Default embedder using simple TF-IDF-like approach.
        
        For production, replace with actual embedding model.
        """
        # Tokenize
        words = text.lower().split()
        
        # Update vocabulary
        for word in words:
            if word not in self._vocabulary:
                self._vocabulary[word] = len(self._vocabulary)
        
        # Create sparse vector (simplified)
        dimensions = min(self.config.embedding_dimensions, 1000)
        vector = [0.0] * dimensions
        
        for word in words:
            idx = self._vocabulary.get(word, 0) % dimensions
            vector[idx] += 1.0
        
        # Normalize
        magnitude = math.sqrt(sum(v * v for v in vector))
        if magnitude > 0:
            vector = [v / magnitude for v in vector]
        
        return vector
    
    def _cosine_similarity(
        self,
        vec1: list[float],
        vec2: list[float],
    ) -> float:
        """Calculate cosine similarity between vectors."""
        if len(vec1) != len(vec2):
            # Pad shorter vector
            max_len = max(len(vec1), len(vec2))
            vec1 = vec1 + [0.0] * (max_len - len(vec1))
            vec2 = vec2 + [0.0] * (max_len - len(vec2))
        
        dot_product = sum(a * b for a, b in zip(vec1, vec2))
        magnitude1 = math.sqrt(sum(a * a for a in vec1))
        magnitude2 = math.sqrt(sum(b * b for b in vec2))
        
        if magnitude1 == 0 or magnitude2 == 0:
            return 0.0
        
        return dot_product / (magnitude1 * magnitude2)
    
    def _filter_entries(
        self,
        session_id: str | None,
        agent_name: str | None,
    ) -> list[MemoryEntry]:
        """Filter entries."""
        entries = self._entries
        
        if session_id:
            entries = [e for e in entries if e.session_id == session_id]
        if agent_name:
            entries = [e for e in entries if e.agent_name == agent_name]
        
        return entries
    
    def _matches_filter(
        self,
        entry: MemoryEntry,
        session_id: str | None,
        agent_name: str | None,
    ) -> bool:
        """Check if entry matches filter."""
        if session_id and entry.session_id != session_id:
            return False
        if agent_name and entry.agent_name != agent_name:
            return False
        return True
    
    def _estimate_tokens(self, text: str) -> int:
        """Estimate token count."""
        return len(text) // 4 + 1
