"""
Monitoring Module for Multi-Agent Base.

Provides Prometheus metrics, health checks, and monitoring capabilities
for production deployments.
"""

from multi_agent_base.monitoring.metrics import (
    MetricsCollector,
    Counter,
    Gauge,
    Histogram,
    MetricSample,
    get_metrics,
    create_default_metrics,
)
from multi_agent_base.monitoring.health import (
    HealthCheck,
    HealthStatus,
    HealthResult,
    create_health_check,
)

__all__ = [
    # Metrics
    "MetricsCollector",
    "Counter",
    "Gauge", 
    "Histogram",
    "MetricSample",
    "get_metrics",
    "create_default_metrics",
    # Health
    "HealthCheck",
    "HealthStatus",
    "HealthResult",
    "create_health_check",
]
