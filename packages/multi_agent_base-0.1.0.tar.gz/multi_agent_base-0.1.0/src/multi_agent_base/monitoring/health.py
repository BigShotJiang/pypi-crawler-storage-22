"""
Health check utilities for Multi-Agent Base.

Provides health check endpoints and status monitoring
for production deployments.
"""

from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Callable, Awaitable


class HealthStatus(str, Enum):
    """Health status values."""
    
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    UNHEALTHY = "unhealthy"


@dataclass
class HealthResult:
    """Result of a health check.
    
    Attributes:
        status: Overall health status
        checks: Individual check results
        timestamp: When the check was performed
        duration_ms: Check duration in milliseconds
        metadata: Additional metadata
    """
    
    status: HealthStatus
    checks: dict[str, dict[str, Any]] = field(default_factory=dict)
    timestamp: datetime = field(default_factory=datetime.now)
    duration_ms: float = 0.0
    metadata: dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary.
        
        Returns:
            Dictionary representation
        """
        return {
            "status": self.status.value,
            "checks": self.checks,
            "timestamp": self.timestamp.isoformat(),
            "duration_ms": self.duration_ms,
            "metadata": self.metadata,
        }
    
    @property
    def is_healthy(self) -> bool:
        """Check if status is healthy."""
        return self.status == HealthStatus.HEALTHY


class HealthCheck:
    """Health check manager.
    
    Manages multiple health checks and provides aggregated status.
    
    Example:
        ```python
        health = HealthCheck()
        
        # Add checks
        health.add_check("database", check_database)
        health.add_check("redis", check_redis)
        health.add_check("llm_provider", check_llm)
        
        # Run all checks
        result = await health.run_checks()
        print(result.status)
        
        # For HTTP endpoints
        if result.is_healthy:
            return 200, result.to_dict()
        else:
            return 503, result.to_dict()
        ```
    """
    
    def __init__(
        self,
        name: str = "multi-agent-base",
        version: str = "1.0.0",
    ) -> None:
        """Initialize health check.
        
        Args:
            name: Service name
            version: Service version
        """
        self.name = name
        self.version = version
        self._checks: dict[str, Callable[[], Awaitable[dict[str, Any]]]] = {}
        self._sync_checks: dict[str, Callable[[], dict[str, Any]]] = {}
    
    def add_check(
        self,
        name: str,
        check: Callable[[], Awaitable[dict[str, Any]] | dict[str, Any]],
    ) -> None:
        """Add a health check.
        
        Args:
            name: Check name
            check: Check function (sync or async)
        """
        if asyncio.iscoroutinefunction(check):
            self._checks[name] = check  # type: ignore
        else:
            self._sync_checks[name] = check  # type: ignore
    
    def remove_check(self, name: str) -> None:
        """Remove a health check.
        
        Args:
            name: Check name
        """
        self._checks.pop(name, None)
        self._sync_checks.pop(name, None)
    
    async def run_checks(
        self,
        timeout: float = 5.0,
    ) -> HealthResult:
        """Run all health checks.
        
        Args:
            timeout: Timeout for each check in seconds
            
        Returns:
            Aggregated health result
        """
        start_time = time.perf_counter()
        results: dict[str, dict[str, Any]] = {}
        overall_status = HealthStatus.HEALTHY
        
        # Run async checks
        for name, check in self._checks.items():
            try:
                check_result = await asyncio.wait_for(
                    check(),
                    timeout=timeout,
                )
                results[name] = {
                    "status": check_result.get("status", "healthy"),
                    "message": check_result.get("message", "OK"),
                    **{k: v for k, v in check_result.items() if k not in ["status", "message"]},
                }
                
                if check_result.get("status") == "unhealthy":
                    overall_status = HealthStatus.UNHEALTHY
                elif check_result.get("status") == "degraded" and overall_status == HealthStatus.HEALTHY:
                    overall_status = HealthStatus.DEGRADED
                    
            except asyncio.TimeoutError:
                results[name] = {
                    "status": "unhealthy",
                    "message": "Check timed out",
                }
                overall_status = HealthStatus.UNHEALTHY
            except Exception as e:
                results[name] = {
                    "status": "unhealthy",
                    "message": str(e),
                }
                overall_status = HealthStatus.UNHEALTHY
        
        # Run sync checks
        for name, check in self._sync_checks.items():
            try:
                check_result = check()
                results[name] = {
                    "status": check_result.get("status", "healthy"),
                    "message": check_result.get("message", "OK"),
                    **{k: v for k, v in check_result.items() if k not in ["status", "message"]},
                }
                
                if check_result.get("status") == "unhealthy":
                    overall_status = HealthStatus.UNHEALTHY
                elif check_result.get("status") == "degraded" and overall_status == HealthStatus.HEALTHY:
                    overall_status = HealthStatus.DEGRADED
                    
            except Exception as e:
                results[name] = {
                    "status": "unhealthy",
                    "message": str(e),
                }
                overall_status = HealthStatus.UNHEALTHY
        
        duration_ms = (time.perf_counter() - start_time) * 1000
        
        return HealthResult(
            status=overall_status,
            checks=results,
            duration_ms=duration_ms,
            metadata={
                "service": self.name,
                "version": self.version,
            },
        )
    
    async def liveness(self) -> HealthResult:
        """Simple liveness check.
        
        Returns True if the service is running.
        Kubernetes uses this to know when to restart a container.
        
        Returns:
            Simple health result
        """
        return HealthResult(
            status=HealthStatus.HEALTHY,
            metadata={
                "service": self.name,
                "version": self.version,
            },
        )
    
    async def readiness(self) -> HealthResult:
        """Readiness check.
        
        Runs all checks to determine if the service is ready
        to accept traffic.
        
        Returns:
            Full health result
        """
        return await self.run_checks()


def create_health_check(
    name: str = "multi-agent-base",
    version: str = "1.0.0",
) -> HealthCheck:
    """Create a health check instance with default checks.
    
    Args:
        name: Service name
        version: Service version
        
    Returns:
        Configured HealthCheck instance
    """
    health = HealthCheck(name=name, version=version)
    
    # Add basic memory check
    def check_memory() -> dict[str, Any]:
        """Check memory usage."""
        try:
            import psutil
            memory = psutil.virtual_memory()
            if memory.percent > 90:
                return {"status": "degraded", "message": f"High memory usage: {memory.percent}%"}
            return {"status": "healthy", "message": f"Memory usage: {memory.percent}%"}
        except ImportError:
            return {"status": "healthy", "message": "Memory check skipped (psutil not installed)"}
    
    health.add_check("memory", check_memory)
    
    return health


# Pre-built check functions

async def check_redis(
    redis_client: Any,
    timeout: float = 1.0,
) -> dict[str, Any]:
    """Health check for Redis connection.
    
    Args:
        redis_client: Redis client instance
        timeout: Ping timeout
        
    Returns:
        Check result
    """
    try:
        await asyncio.wait_for(redis_client.ping(), timeout=timeout)
        return {"status": "healthy", "message": "Redis connected"}
    except asyncio.TimeoutError:
        return {"status": "unhealthy", "message": "Redis ping timeout"}
    except Exception as e:
        return {"status": "unhealthy", "message": f"Redis error: {e}"}


async def check_llm_provider(
    client: Any,
    test_prompt: str = "Say 'ok'",
    timeout: float = 10.0,
) -> dict[str, Any]:
    """Health check for LLM provider.
    
    Args:
        client: Model client instance
        test_prompt: Simple test prompt
        timeout: Request timeout
        
    Returns:
        Check result
    """
    try:
        start = time.perf_counter()
        response, _, _ = await asyncio.wait_for(
            client.generate([{"role": "user", "content": test_prompt}]),
            timeout=timeout,
        )
        latency_ms = (time.perf_counter() - start) * 1000
        
        if response:
            return {
                "status": "healthy",
                "message": "LLM provider responding",
                "latency_ms": latency_ms,
            }
        else:
            return {
                "status": "degraded",
                "message": "LLM returned empty response",
                "latency_ms": latency_ms,
            }
    except asyncio.TimeoutError:
        return {"status": "unhealthy", "message": "LLM request timeout"}
    except Exception as e:
        return {"status": "unhealthy", "message": f"LLM error: {e}"}


def check_disk_space(
    path: str = "/",
    min_free_percent: float = 10.0,
) -> dict[str, Any]:
    """Check available disk space.
    
    Args:
        path: Path to check
        min_free_percent: Minimum free percentage
        
    Returns:
        Check result
    """
    try:
        import shutil
        total, used, free = shutil.disk_usage(path)
        free_percent = (free / total) * 100
        
        if free_percent < min_free_percent:
            return {
                "status": "degraded",
                "message": f"Low disk space: {free_percent:.1f}% free",
                "free_bytes": free,
            }
        return {
            "status": "healthy",
            "message": f"Disk space: {free_percent:.1f}% free",
            "free_bytes": free,
        }
    except Exception as e:
        return {"status": "unhealthy", "message": f"Disk check error: {e}"}
