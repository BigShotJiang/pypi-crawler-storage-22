"""
Prometheus-compatible metrics for Multi-Agent Base.

Provides metrics collection without requiring prometheus_client
as a hard dependency - falls back to in-memory collection.
"""

from __future__ import annotations

import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Callable
from collections import defaultdict
import threading


@dataclass
class MetricSample:
    """A single metric sample."""
    
    name: str
    value: float
    labels: dict[str, str] = field(default_factory=dict)
    timestamp: float = field(default_factory=time.time)


class Metric(ABC):
    """Base class for metrics."""
    
    def __init__(
        self,
        name: str,
        description: str,
        labels: list[str] | None = None,
    ) -> None:
        """Initialize metric.
        
        Args:
            name: Metric name (should follow prometheus naming conventions)
            description: Human-readable description
            labels: List of label names
        """
        self.name = name
        self.description = description
        self.labels = labels or []
        self._values: dict[tuple, float] = defaultdict(float)
        self._lock = threading.Lock()
    
    def _label_key(self, labels: dict[str, str] | None = None) -> tuple:
        """Create a hashable key from labels."""
        if not labels:
            return ()
        return tuple(sorted(labels.items()))
    
    @abstractmethod
    def collect(self) -> list[MetricSample]:
        """Collect all samples for this metric."""
        pass


class Counter(Metric):
    """A counter that can only increase.
    
    Example:
        ```python
        request_count = Counter(
            "agent_requests_total",
            "Total number of agent requests",
            labels=["agent_name", "status"],
        )
        
        request_count.inc(labels={"agent_name": "assistant", "status": "success"})
        ```
    """
    
    def inc(self, value: float = 1.0, labels: dict[str, str] | None = None) -> None:
        """Increment the counter.
        
        Args:
            value: Value to add (must be positive)
            labels: Label values
        """
        if value < 0:
            raise ValueError("Counter can only be incremented")
        
        with self._lock:
            key = self._label_key(labels)
            self._values[key] += value
    
    def collect(self) -> list[MetricSample]:
        """Collect counter samples."""
        samples = []
        with self._lock:
            for key, value in self._values.items():
                labels = dict(key) if key else {}
                samples.append(MetricSample(
                    name=self.name,
                    value=value,
                    labels=labels,
                ))
        return samples


class Gauge(Metric):
    """A gauge that can go up and down.
    
    Example:
        ```python
        active_agents = Gauge(
            "active_agents",
            "Number of currently active agents",
        )
        
        active_agents.set(5)
        active_agents.inc()
        active_agents.dec()
        ```
    """
    
    def set(self, value: float, labels: dict[str, str] | None = None) -> None:
        """Set the gauge value.
        
        Args:
            value: Value to set
            labels: Label values
        """
        with self._lock:
            key = self._label_key(labels)
            self._values[key] = value
    
    def inc(self, value: float = 1.0, labels: dict[str, str] | None = None) -> None:
        """Increment the gauge.
        
        Args:
            value: Value to add
            labels: Label values
        """
        with self._lock:
            key = self._label_key(labels)
            self._values[key] += value
    
    def dec(self, value: float = 1.0, labels: dict[str, str] | None = None) -> None:
        """Decrement the gauge.
        
        Args:
            value: Value to subtract
            labels: Label values
        """
        with self._lock:
            key = self._label_key(labels)
            self._values[key] -= value
    
    def collect(self) -> list[MetricSample]:
        """Collect gauge samples."""
        samples = []
        with self._lock:
            for key, value in self._values.items():
                labels = dict(key) if key else {}
                samples.append(MetricSample(
                    name=self.name,
                    value=value,
                    labels=labels,
                ))
        return samples


class Histogram(Metric):
    """A histogram for measuring distributions.
    
    Example:
        ```python
        request_duration = Histogram(
            "agent_request_duration_seconds",
            "Request duration in seconds",
            buckets=[0.1, 0.5, 1.0, 2.0, 5.0, 10.0],
        )
        
        with request_duration.time():
            # do work
            pass
        
        # Or manually
        request_duration.observe(0.5)
        ```
    """
    
    DEFAULT_BUCKETS = (0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0, 10.0)
    
    def __init__(
        self,
        name: str,
        description: str,
        labels: list[str] | None = None,
        buckets: tuple[float, ...] | list[float] | None = None,
    ) -> None:
        """Initialize histogram.
        
        Args:
            name: Metric name
            description: Description
            labels: Label names
            buckets: Histogram bucket boundaries
        """
        super().__init__(name, description, labels)
        self.buckets = tuple(sorted(buckets or self.DEFAULT_BUCKETS))
        self._bucket_counts: dict[tuple, list[int]] = defaultdict(
            lambda: [0] * len(self.buckets)
        )
        self._sums: dict[tuple, float] = defaultdict(float)
        self._counts: dict[tuple, int] = defaultdict(int)
    
    def observe(self, value: float, labels: dict[str, str] | None = None) -> None:
        """Record an observation.
        
        Args:
            value: Observed value
            labels: Label values
        """
        with self._lock:
            key = self._label_key(labels)
            
            # Update bucket counts
            for i, boundary in enumerate(self.buckets):
                if value <= boundary:
                    self._bucket_counts[key][i] += 1
            
            self._sums[key] += value
            self._counts[key] += 1
    
    def time(self, labels: dict[str, str] | None = None) -> "HistogramTimer":
        """Context manager for timing operations.
        
        Args:
            labels: Label values
            
        Returns:
            Timer context manager
        """
        return HistogramTimer(self, labels)
    
    def collect(self) -> list[MetricSample]:
        """Collect histogram samples."""
        samples = []
        with self._lock:
            for key, bucket_counts in self._bucket_counts.items():
                labels = dict(key) if key else {}
                
                # Emit bucket samples
                cumulative = 0
                for i, (boundary, count) in enumerate(zip(self.buckets, bucket_counts)):
                    cumulative += count
                    samples.append(MetricSample(
                        name=f"{self.name}_bucket",
                        value=cumulative,
                        labels={**labels, "le": str(boundary)},
                    ))
                
                # Add +Inf bucket
                samples.append(MetricSample(
                    name=f"{self.name}_bucket",
                    value=self._counts[key],
                    labels={**labels, "le": "+Inf"},
                ))
                
                # Sum and count
                samples.append(MetricSample(
                    name=f"{self.name}_sum",
                    value=self._sums[key],
                    labels=labels,
                ))
                samples.append(MetricSample(
                    name=f"{self.name}_count",
                    value=self._counts[key],
                    labels=labels,
                ))
        
        return samples


class HistogramTimer:
    """Context manager for timing histogram observations."""
    
    def __init__(self, histogram: Histogram, labels: dict[str, str] | None) -> None:
        self.histogram = histogram
        self.labels = labels
        self.start_time: float = 0
    
    def __enter__(self) -> "HistogramTimer":
        self.start_time = time.perf_counter()
        return self
    
    def __exit__(self, *args) -> None:
        duration = time.perf_counter() - self.start_time
        self.histogram.observe(duration, self.labels)


class MetricsCollector:
    """Central metrics collector.
    
    Manages all metrics and provides export functionality.
    
    Example:
        ```python
        metrics = MetricsCollector()
        
        # Create metrics
        requests = metrics.counter(
            "agent_requests_total",
            "Total requests",
        )
        
        duration = metrics.histogram(
            "agent_duration_seconds",
            "Request duration",
        )
        
        # Use metrics
        requests.inc()
        duration.observe(0.5)
        
        # Export as Prometheus format
        output = metrics.export_prometheus()
        ```
    """
    
    def __init__(self) -> None:
        """Initialize collector."""
        self._metrics: dict[str, Metric] = {}
        self._lock = threading.Lock()
    
    def counter(
        self,
        name: str,
        description: str,
        labels: list[str] | None = None,
    ) -> Counter:
        """Create or get a counter.
        
        Args:
            name: Metric name
            description: Description
            labels: Label names
            
        Returns:
            Counter instance
        """
        with self._lock:
            if name not in self._metrics:
                self._metrics[name] = Counter(name, description, labels)
            return self._metrics[name]  # type: ignore
    
    def gauge(
        self,
        name: str,
        description: str,
        labels: list[str] | None = None,
    ) -> Gauge:
        """Create or get a gauge.
        
        Args:
            name: Metric name
            description: Description
            labels: Label names
            
        Returns:
            Gauge instance
        """
        with self._lock:
            if name not in self._metrics:
                self._metrics[name] = Gauge(name, description, labels)
            return self._metrics[name]  # type: ignore
    
    def histogram(
        self,
        name: str,
        description: str,
        labels: list[str] | None = None,
        buckets: tuple[float, ...] | list[float] | None = None,
    ) -> Histogram:
        """Create or get a histogram.
        
        Args:
            name: Metric name
            description: Description
            labels: Label names
            buckets: Histogram buckets
            
        Returns:
            Histogram instance
        """
        with self._lock:
            if name not in self._metrics:
                self._metrics[name] = Histogram(name, description, labels, buckets)
            return self._metrics[name]  # type: ignore
    
    def collect(self) -> list[MetricSample]:
        """Collect all metric samples.
        
        Returns:
            List of all samples
        """
        samples = []
        with self._lock:
            for metric in self._metrics.values():
                samples.extend(metric.collect())
        return samples
    
    def export_prometheus(self) -> str:
        """Export metrics in Prometheus text format.
        
        Returns:
            Prometheus exposition format string
        """
        lines = []
        seen_help = set()
        
        with self._lock:
            for metric in self._metrics.values():
                # Add help and type
                if metric.name not in seen_help:
                    lines.append(f"# HELP {metric.name} {metric.description}")
                    if isinstance(metric, Counter):
                        lines.append(f"# TYPE {metric.name} counter")
                    elif isinstance(metric, Gauge):
                        lines.append(f"# TYPE {metric.name} gauge")
                    elif isinstance(metric, Histogram):
                        lines.append(f"# TYPE {metric.name} histogram")
                    seen_help.add(metric.name)
                
                # Add samples
                for sample in metric.collect():
                    if sample.labels:
                        label_str = ",".join(
                            f'{k}="{v}"' for k, v in sorted(sample.labels.items())
                        )
                        lines.append(f"{sample.name}{{{label_str}}} {sample.value}")
                    else:
                        lines.append(f"{sample.name} {sample.value}")
        
        return "\n".join(lines)
    
    def export_json(self) -> list[dict[str, Any]]:
        """Export metrics as JSON-serializable list.
        
        Returns:
            List of metric dictionaries
        """
        return [
            {
                "name": sample.name,
                "value": sample.value,
                "labels": sample.labels,
                "timestamp": sample.timestamp,
            }
            for sample in self.collect()
        ]


# Global metrics instance
_global_metrics: MetricsCollector | None = None


def get_metrics() -> MetricsCollector:
    """Get the global metrics collector.
    
    Returns:
        Global MetricsCollector instance
    """
    global _global_metrics
    if _global_metrics is None:
        _global_metrics = MetricsCollector()
    return _global_metrics


# Pre-defined metrics for multi-agent-base
def create_default_metrics(collector: MetricsCollector | None = None) -> dict[str, Metric]:
    """Create default metrics for multi-agent-base.
    
    Args:
        collector: Optional collector to use
        
    Returns:
        Dictionary of metric instances
    """
    metrics = collector or get_metrics()
    
    return {
        "agent_requests_total": metrics.counter(
            "agent_requests_total",
            "Total number of agent requests",
            labels=["agent_name", "status"],
        ),
        "agent_request_duration_seconds": metrics.histogram(
            "agent_request_duration_seconds",
            "Agent request duration in seconds",
            labels=["agent_name"],
            buckets=[0.1, 0.5, 1.0, 2.0, 5.0, 10.0, 30.0, 60.0],
        ),
        "agent_tokens_total": metrics.counter(
            "agent_tokens_total",
            "Total tokens used",
            labels=["agent_name", "type"],
        ),
        "agent_cost_total": metrics.counter(
            "agent_cost_total",
            "Total cost in USD",
            labels=["agent_name", "provider", "model"],
        ),
        "agent_tool_calls_total": metrics.counter(
            "agent_tool_calls_total",
            "Total tool calls",
            labels=["agent_name", "tool_name", "status"],
        ),
        "agent_errors_total": metrics.counter(
            "agent_errors_total",
            "Total errors",
            labels=["agent_name", "error_type"],
        ),
        "active_agents": metrics.gauge(
            "active_agents",
            "Number of active agents",
        ),
        "rate_limit_remaining": metrics.gauge(
            "rate_limit_remaining",
            "Remaining rate limit tokens",
            labels=["provider"],
        ),
    }
