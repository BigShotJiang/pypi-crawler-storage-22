"""
Multimodal content support for multi-agent systems.

This module provides unified support for multimodal content (images, audio, video)
across different AI providers including OpenAI, Anthropic, Ollama, and Google.

Features:
- Unified MediaContent class for all media types
- MultimodalMessage for mixed text and media messages
- Provider-specific format conversion
- Base64 encoding/decoding utilities
- Media processing and validation

Example:
    from multi_agent_base.multimodal import MultimodalMessage, MediaContent
    
    # Create a message with an image
    message = MultimodalMessage.with_image(
        text="What's in this image?",
        image="./photo.jpg"
    )
    
    # Convert to provider-specific format
    openai_format = message.to_openai_format()
    anthropic_format = message.to_anthropic_format()
    
    # Create from URL
    message = MultimodalMessage.with_image(
        text="Analyze this image",
        image="https://example.com/image.png"
    )

Supported Providers:
- OpenAI: GPT-4 Vision, GPT-4o
- Anthropic: Claude 3 family
- Ollama: LLaVA, BakLLaVA
- Google: Gemini models
"""

from .types import (
    # Core types
    MediaContent,
    MultimodalMessage,
    MediaType,
    # Format enums
    ImageFormat,
    AudioFormat,
    VideoFormat,
    DocumentFormat,
    # Provider capabilities
    PROVIDER_CAPABILITIES,
)

from .encoders import (
    # Base64 utilities
    Base64Encoder,
    DecodedDataURI,
    # URL utilities
    URLEncoder,
    # Content hashing
    ContentHasher,
    # MIME type detection
    MIMETypeDetector,
)

from .processors import (
    # Info types
    ImageDimensions,
    AudioInfo,
    VideoInfo,
    ProcessingResult,
    # Processor classes
    ImageProcessor,
    AudioProcessor,
    VideoProcessor,
    MediaProcessor,
    # Convenience functions
    get_image_dimensions,
    get_audio_info,
    get_video_info,
    is_valid_image,
    is_valid_audio,
    is_valid_video,
)


__all__ = [
    # Core types
    "MediaContent",
    "MultimodalMessage",
    "MediaType",
    # Format enums
    "ImageFormat",
    "AudioFormat",
    "VideoFormat",
    "DocumentFormat",
    # Provider capabilities
    "PROVIDER_CAPABILITIES",
    # Encoders
    "Base64Encoder",
    "DecodedDataURI",
    "URLEncoder",
    "ContentHasher",
    "MIMETypeDetector",
    # Info types
    "ImageDimensions",
    "AudioInfo",
    "VideoInfo",
    "ProcessingResult",
    # Processor classes
    "ImageProcessor",
    "AudioProcessor",
    "VideoProcessor",
    "MediaProcessor",
    # Convenience functions
    "get_image_dimensions",
    "get_audio_info",
    "get_video_info",
    "is_valid_image",
    "is_valid_audio",
    "is_valid_video",
]

__version__ = "1.0.0"
