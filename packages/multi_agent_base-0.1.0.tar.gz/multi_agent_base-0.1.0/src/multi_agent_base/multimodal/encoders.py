"""
Encoding utilities for multimodal content.

This module provides encoding/decoding functionality for media content,
including base64, URL handling, and data URI conversion.
"""

from __future__ import annotations

import base64
import hashlib
import mimetypes
import re
import urllib.parse
from dataclasses import dataclass
from pathlib import Path
from typing import Any

# Common data URI pattern
DATA_URI_PATTERN = re.compile(
    r"^data:(?P<mime>[^;,]+)(?:;(?P<encoding>base64))?,(?P<data>.+)$",
    re.DOTALL
)


@dataclass
class DecodedDataURI:
    """Represents a decoded data URI."""
    
    mime_type: str
    data: bytes
    is_base64: bool
    original_uri: str
    
    @property
    def size_bytes(self) -> int:
        """Get data size in bytes."""
        return len(self.data)
    
    @property
    def size_kb(self) -> float:
        """Get data size in kilobytes."""
        return self.size_bytes / 1024
    
    @property
    def size_mb(self) -> float:
        """Get data size in megabytes."""
        return self.size_bytes / (1024 * 1024)


class Base64Encoder:
    """
    Utilities for base64 encoding and decoding.
    
    Example:
        # Encode file to base64
        encoded = Base64Encoder.encode_file("image.png")
        
        # Decode base64 to bytes
        data = Base64Encoder.decode(encoded)
        
        # Create data URI
        uri = Base64Encoder.to_data_uri(data, "image/png")
    """
    
    @staticmethod
    def encode(data: bytes) -> str:
        """
        Encode bytes to base64 string.
        
        Args:
            data: Raw bytes to encode
            
        Returns:
            Base64 encoded string
        """
        return base64.b64encode(data).decode("utf-8")
    
    @staticmethod
    def decode(data: str) -> bytes:
        """
        Decode base64 string to bytes.
        
        Args:
            data: Base64 encoded string
            
        Returns:
            Decoded bytes
            
        Raises:
            ValueError: If data is not valid base64
        """
        try:
            # Handle URL-safe base64
            data = data.replace("-", "+").replace("_", "/")
            # Add padding if needed
            padding = 4 - len(data) % 4
            if padding != 4:
                data += "=" * padding
            return base64.b64decode(data)
        except Exception as e:
            raise ValueError(f"Invalid base64 data: {e}")
    
    @classmethod
    def encode_file(cls, path: str | Path) -> str:
        """
        Encode file contents to base64.
        
        Args:
            path: Path to file
            
        Returns:
            Base64 encoded string
            
        Raises:
            FileNotFoundError: If file doesn't exist
        """
        path = Path(path)
        if not path.exists():
            raise FileNotFoundError(f"File not found: {path}")
        
        return cls.encode(path.read_bytes())
    
    @classmethod
    def decode_to_file(cls, data: str, path: str | Path) -> Path:
        """
        Decode base64 string and save to file.
        
        Args:
            data: Base64 encoded string
            path: Path to save file
            
        Returns:
            Path to saved file
        """
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(cls.decode(data))
        return path
    
    @staticmethod
    def to_data_uri(data: bytes, mime_type: str) -> str:
        """
        Convert bytes to data URI.
        
        Args:
            data: Raw bytes
            mime_type: MIME type of the data
            
        Returns:
            Data URI string
        """
        encoded = base64.b64encode(data).decode("utf-8")
        return f"data:{mime_type};base64,{encoded}"
    
    @classmethod
    def file_to_data_uri(cls, path: str | Path) -> str:
        """
        Convert file to data URI.
        
        Args:
            path: Path to file
            
        Returns:
            Data URI string
        """
        path = Path(path)
        if not path.exists():
            raise FileNotFoundError(f"File not found: {path}")
        
        mime_type, _ = mimetypes.guess_type(str(path))
        if mime_type is None:
            mime_type = "application/octet-stream"
        
        return cls.to_data_uri(path.read_bytes(), mime_type)
    
    @classmethod
    def from_data_uri(cls, uri: str) -> DecodedDataURI:
        """
        Parse and decode a data URI.
        
        Args:
            uri: Data URI string
            
        Returns:
            DecodedDataURI with mime type and data
            
        Raises:
            ValueError: If URI is not a valid data URI
        """
        match = DATA_URI_PATTERN.match(uri)
        if not match:
            raise ValueError(f"Invalid data URI format")
        
        mime_type = match.group("mime")
        is_base64 = match.group("encoding") == "base64"
        raw_data = match.group("data")
        
        if is_base64:
            data = cls.decode(raw_data)
        else:
            # URL-encoded data
            data = urllib.parse.unquote(raw_data).encode("utf-8")
        
        return DecodedDataURI(
            mime_type=mime_type,
            data=data,
            is_base64=is_base64,
            original_uri=uri,
        )
    
    @staticmethod
    def is_valid_base64(data: str) -> bool:
        """
        Check if string is valid base64.
        
        Args:
            data: String to check
            
        Returns:
            True if valid base64
        """
        try:
            # Remove whitespace
            data = data.replace(" ", "").replace("\n", "")
            # Check character set
            if not re.match(r"^[A-Za-z0-9+/=_-]*$", data):
                return False
            # Try decoding
            base64.b64decode(data, validate=True)
            return True
        except Exception:
            return False
    
    @staticmethod
    def is_data_uri(text: str) -> bool:
        """
        Check if string is a data URI.
        
        Args:
            text: String to check
            
        Returns:
            True if data URI
        """
        return text.startswith("data:") and DATA_URI_PATTERN.match(text) is not None


class URLEncoder:
    """
    URL encoding and validation utilities.
    
    Example:
        # Check if valid URL
        is_valid = URLEncoder.is_valid_url("https://example.com/image.png")
        
        # Get file extension from URL
        ext = URLEncoder.get_extension("https://example.com/image.png")
        
        # Encode URL components
        encoded = URLEncoder.encode_query({"q": "hello world"})
    """
    
    # URL pattern for validation
    URL_PATTERN = re.compile(
        r"^https?://"  # http:// or https://
        r"(?:(?:[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?\.)+[A-Z]{2,6}\.?|"  # domain
        r"localhost|"  # localhost
        r"\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})"  # or IP
        r"(?::\d+)?"  # optional port
        r"(?:/?|[/?]\S+)$",  # path
        re.IGNORECASE
    )
    
    @classmethod
    def is_valid_url(cls, text: str) -> bool:
        """
        Check if string is a valid HTTP/HTTPS URL.
        
        Args:
            text: String to check
            
        Returns:
            True if valid URL
        """
        return bool(cls.URL_PATTERN.match(text))
    
    @staticmethod
    def is_image_url(url: str) -> bool:
        """
        Check if URL likely points to an image.
        
        Args:
            url: URL to check
            
        Returns:
            True if likely an image URL
        """
        # Check extension
        image_extensions = {".jpg", ".jpeg", ".png", ".gif", ".webp", ".svg", ".bmp", ".tiff"}
        parsed = urllib.parse.urlparse(url)
        path = parsed.path.lower()
        ext = Path(path).suffix
        return ext in image_extensions
    
    @staticmethod
    def is_audio_url(url: str) -> bool:
        """
        Check if URL likely points to audio.
        
        Args:
            url: URL to check
            
        Returns:
            True if likely an audio URL
        """
        audio_extensions = {".mp3", ".wav", ".ogg", ".flac", ".m4a", ".webm", ".aac"}
        parsed = urllib.parse.urlparse(url)
        path = parsed.path.lower()
        ext = Path(path).suffix
        return ext in audio_extensions
    
    @staticmethod
    def is_video_url(url: str) -> bool:
        """
        Check if URL likely points to video.
        
        Args:
            url: URL to check
            
        Returns:
            True if likely a video URL
        """
        video_extensions = {".mp4", ".webm", ".mov", ".avi", ".mkv", ".m4v"}
        parsed = urllib.parse.urlparse(url)
        path = parsed.path.lower()
        ext = Path(path).suffix
        return ext in video_extensions
    
    @staticmethod
    def get_extension(url: str) -> str | None:
        """
        Extract file extension from URL.
        
        Args:
            url: URL to parse
            
        Returns:
            Extension (with dot) or None
        """
        parsed = urllib.parse.urlparse(url)
        path = parsed.path
        # Remove query and fragment from path
        path = path.split("?")[0].split("#")[0]
        ext = Path(path).suffix.lower()
        return ext if ext else None
    
    @staticmethod
    def get_filename(url: str) -> str | None:
        """
        Extract filename from URL.
        
        Args:
            url: URL to parse
            
        Returns:
            Filename or None
        """
        parsed = urllib.parse.urlparse(url)
        path = parsed.path
        # Remove query and fragment
        path = path.split("?")[0].split("#")[0]
        name = Path(path).name
        return name if name else None
    
    @staticmethod
    def get_mime_type(url: str) -> str | None:
        """
        Guess MIME type from URL.
        
        Args:
            url: URL to check
            
        Returns:
            MIME type or None
        """
        ext = URLEncoder.get_extension(url)
        if ext:
            mime, _ = mimetypes.guess_type(f"file{ext}")
            return mime
        return None
    
    @staticmethod
    def encode_query(params: dict[str, Any]) -> str:
        """
        Encode dictionary to URL query string.
        
        Args:
            params: Dictionary of parameters
            
        Returns:
            URL-encoded query string
        """
        return urllib.parse.urlencode(params)
    
    @staticmethod
    def decode_query(query: str) -> dict[str, list[str]]:
        """
        Decode URL query string to dictionary.
        
        Args:
            query: URL-encoded query string
            
        Returns:
            Dictionary of parameters
        """
        return urllib.parse.parse_qs(query)
    
    @staticmethod
    def build_url(
        base: str,
        path: str | None = None,
        params: dict[str, Any] | None = None
    ) -> str:
        """
        Build URL from components.
        
        Args:
            base: Base URL
            path: Optional path to append
            params: Optional query parameters
            
        Returns:
            Complete URL
        """
        if path:
            base = urllib.parse.urljoin(base, path)
        
        if params:
            parsed = urllib.parse.urlparse(base)
            query = urllib.parse.urlencode(params)
            if parsed.query:
                query = f"{parsed.query}&{query}"
            base = urllib.parse.urlunparse(
                (parsed.scheme, parsed.netloc, parsed.path, parsed.params, query, parsed.fragment)
            )
        
        return base
    
    @staticmethod
    def normalize_url(url: str) -> str:
        """
        Normalize URL (lowercase scheme/host, remove default ports, etc).
        
        Args:
            url: URL to normalize
            
        Returns:
            Normalized URL
        """
        parsed = urllib.parse.urlparse(url)
        
        # Lowercase scheme and host
        scheme = parsed.scheme.lower()
        netloc = parsed.netloc.lower()
        
        # Remove default ports
        if scheme == "http" and netloc.endswith(":80"):
            netloc = netloc[:-3]
        elif scheme == "https" and netloc.endswith(":443"):
            netloc = netloc[:-4]
        
        # Remove trailing slash from path if no query
        path = parsed.path
        if path.endswith("/") and not parsed.query:
            path = path.rstrip("/") or "/"
        
        return urllib.parse.urlunparse(
            (scheme, netloc, path, parsed.params, parsed.query, parsed.fragment)
        )


class ContentHasher:
    """
    Utilities for hashing content.
    
    Example:
        # Hash bytes
        hash_val = ContentHasher.hash_bytes(data)
        
        # Hash file
        file_hash = ContentHasher.hash_file("image.png")
        
        # Compare content
        is_same = ContentHasher.compare(data1, data2)
    """
    
    @staticmethod
    def hash_bytes(data: bytes, algorithm: str = "sha256") -> str:
        """
        Hash bytes using specified algorithm.
        
        Args:
            data: Bytes to hash
            algorithm: Hash algorithm (md5, sha1, sha256, sha512)
            
        Returns:
            Hex digest of hash
        """
        hasher = hashlib.new(algorithm)
        hasher.update(data)
        return hasher.hexdigest()
    
    @classmethod
    def hash_file(cls, path: str | Path, algorithm: str = "sha256") -> str:
        """
        Hash file contents.
        
        Args:
            path: Path to file
            algorithm: Hash algorithm
            
        Returns:
            Hex digest of hash
        """
        path = Path(path)
        if not path.exists():
            raise FileNotFoundError(f"File not found: {path}")
        
        return cls.hash_bytes(path.read_bytes(), algorithm)
    
    @classmethod
    def hash_base64(cls, data: str, algorithm: str = "sha256") -> str:
        """
        Hash base64 encoded content.
        
        Args:
            data: Base64 encoded string
            algorithm: Hash algorithm
            
        Returns:
            Hex digest of hash
        """
        decoded = Base64Encoder.decode(data)
        return cls.hash_bytes(decoded, algorithm)
    
    @classmethod
    def compare(cls, data1: bytes, data2: bytes) -> bool:
        """
        Compare two byte arrays by hash.
        
        Args:
            data1: First byte array
            data2: Second byte array
            
        Returns:
            True if content is identical
        """
        return cls.hash_bytes(data1) == cls.hash_bytes(data2)
    
    @classmethod
    def compare_files(cls, path1: str | Path, path2: str | Path) -> bool:
        """
        Compare two files by content hash.
        
        Args:
            path1: Path to first file
            path2: Path to second file
            
        Returns:
            True if files have identical content
        """
        return cls.hash_file(path1) == cls.hash_file(path2)
    
    @staticmethod
    def generate_content_id(data: bytes) -> str:
        """
        Generate a unique content ID based on hash.
        
        Args:
            data: Content bytes
            
        Returns:
            Short content ID
        """
        full_hash = hashlib.sha256(data).hexdigest()
        return full_hash[:16]  # First 16 chars


class MIMETypeDetector:
    """
    MIME type detection utilities.
    
    Example:
        # Detect from bytes (magic numbers)
        mime = MIMETypeDetector.from_bytes(data)
        
        # Detect from file
        mime = MIMETypeDetector.from_file("image.png")
        
        # Detect from extension
        mime = MIMETypeDetector.from_extension(".png")
    """
    
    # Magic number signatures
    SIGNATURES: dict[bytes, str] = {
        # Images
        b"\x89PNG\r\n\x1a\n": "image/png",
        b"\xff\xd8\xff": "image/jpeg",
        b"GIF87a": "image/gif",
        b"GIF89a": "image/gif",
        b"RIFF": "image/webp",  # WebP (need to check for WEBP after RIFF)
        b"BM": "image/bmp",
        b"II*\x00": "image/tiff",
        b"MM\x00*": "image/tiff",
        # Audio
        b"ID3": "audio/mpeg",
        b"\xff\xfb": "audio/mpeg",
        b"\xff\xfa": "audio/mpeg",
        b"OggS": "audio/ogg",
        b"fLaC": "audio/flac",
        b"RIFF_WAVE": "audio/wav",  # Special case
        # Video
        b"\x00\x00\x00\x18ftypmp4": "video/mp4",
        b"\x00\x00\x00\x1cftypmp4": "video/mp4",
        b"\x00\x00\x00 ftypmp4": "video/mp4",
        b"\x1aE\xdf\xa3": "video/webm",
        # Documents
        b"%PDF": "application/pdf",
        b"PK\x03\x04": "application/zip",
    }
    
    @classmethod
    def from_bytes(cls, data: bytes) -> str | None:
        """
        Detect MIME type from bytes using magic numbers.
        
        Args:
            data: Bytes to check
            
        Returns:
            MIME type or None
        """
        # Check for standard signatures
        for signature, mime_type in cls.SIGNATURES.items():
            if signature == b"RIFF":
                # Special case for RIFF formats (WebP, WAV)
                if data[:4] == b"RIFF" and len(data) >= 12:
                    if data[8:12] == b"WEBP":
                        return "image/webp"
                    elif data[8:12] == b"WAVE":
                        return "audio/wav"
            elif signature == b"RIFF_WAVE":
                continue  # Skip placeholder
            elif data.startswith(signature):
                return mime_type
        
        # Check for MP4 variants
        if len(data) >= 12:
            if b"ftyp" in data[4:12]:
                type_code = data[8:12].decode("latin-1", errors="ignore")
                if type_code.startswith("mp4") or type_code in ["isom", "M4V ", "M4A "]:
                    return "video/mp4"
                elif type_code == "qt  ":
                    return "video/quicktime"
        
        return None
    
    @classmethod
    def from_file(cls, path: str | Path) -> str | None:
        """
        Detect MIME type from file.
        
        Args:
            path: Path to file
            
        Returns:
            MIME type or None
        """
        path = Path(path)
        if not path.exists():
            raise FileNotFoundError(f"File not found: {path}")
        
        # Read first 32 bytes for magic number detection
        with open(path, "rb") as f:
            header = f.read(32)
        
        # Try magic number first
        detected = cls.from_bytes(header)
        if detected:
            return detected
        
        # Fall back to extension
        return cls.from_extension(path.suffix)
    
    @staticmethod
    def from_extension(ext: str) -> str | None:
        """
        Get MIME type from file extension.
        
        Args:
            ext: File extension (with or without dot)
            
        Returns:
            MIME type or None
        """
        if not ext.startswith("."):
            ext = f".{ext}"
        
        mime_type, _ = mimetypes.guess_type(f"file{ext}")
        return mime_type
    
    @staticmethod
    def get_extension(mime_type: str) -> str | None:
        """
        Get file extension for MIME type.
        
        Args:
            mime_type: MIME type
            
        Returns:
            Extension (with dot) or None
        """
        ext = mimetypes.guess_extension(mime_type)
        return ext
    
    @staticmethod
    def is_image(mime_type: str) -> bool:
        """Check if MIME type is an image."""
        return mime_type.startswith("image/")
    
    @staticmethod
    def is_audio(mime_type: str) -> bool:
        """Check if MIME type is audio."""
        return mime_type.startswith("audio/")
    
    @staticmethod
    def is_video(mime_type: str) -> bool:
        """Check if MIME type is video."""
        return mime_type.startswith("video/")
    
    @staticmethod
    def is_document(mime_type: str) -> bool:
        """Check if MIME type is a document."""
        document_types = {
            "application/pdf",
            "text/plain",
            "text/html",
            "application/json",
            "application/xml",
            "text/xml",
        }
        return mime_type in document_types
