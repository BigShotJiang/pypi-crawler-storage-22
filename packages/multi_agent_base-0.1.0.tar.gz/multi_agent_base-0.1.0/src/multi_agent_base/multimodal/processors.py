"""
Media content processors for multimodal support.

This module provides processing capabilities for various media types:
- Image processing: resize, compress, format conversion
- Audio processing: format conversion, duration detection
- Video processing: thumbnail extraction, metadata
"""

from __future__ import annotations

import asyncio
import io
import struct
import wave
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, TypeVar

from .types import (
    MediaContent,
    MediaType,
    ImageFormat,
    AudioFormat,
    VideoFormat,
    PROVIDER_CAPABILITIES,
)
from .encoders import Base64Encoder, MIMETypeDetector


T = TypeVar("T")


@dataclass
class ImageDimensions:
    """Image dimension information."""
    
    width: int
    height: int
    
    @property
    def aspect_ratio(self) -> float:
        """Get aspect ratio (width/height)."""
        return self.width / self.height if self.height > 0 else 0
    
    @property
    def is_landscape(self) -> bool:
        """Check if image is landscape orientation."""
        return self.width > self.height
    
    @property
    def is_portrait(self) -> bool:
        """Check if image is portrait orientation."""
        return self.height > self.width
    
    @property
    def is_square(self) -> bool:
        """Check if image is square."""
        return self.width == self.height
    
    def fits_in(self, max_width: int, max_height: int) -> bool:
        """Check if image fits within given dimensions."""
        return self.width <= max_width and self.height <= max_height
    
    def scale_to_fit(self, max_width: int, max_height: int) -> ImageDimensions:
        """
        Calculate new dimensions to fit within max dimensions.
        
        Maintains aspect ratio.
        """
        if self.fits_in(max_width, max_height):
            return ImageDimensions(self.width, self.height)
        
        # Calculate scaling factors
        width_scale = max_width / self.width
        height_scale = max_height / self.height
        scale = min(width_scale, height_scale)
        
        return ImageDimensions(
            width=int(self.width * scale),
            height=int(self.height * scale)
        )
    
    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "width": self.width,
            "height": self.height,
            "aspect_ratio": self.aspect_ratio,
            "orientation": "landscape" if self.is_landscape else "portrait" if self.is_portrait else "square",
        }


@dataclass
class AudioInfo:
    """Audio file information."""
    
    duration_seconds: float
    sample_rate: int | None = None
    channels: int | None = None
    bit_depth: int | None = None
    codec: str | None = None
    
    @property
    def duration_formatted(self) -> str:
        """Get formatted duration (MM:SS or HH:MM:SS)."""
        total_seconds = int(self.duration_seconds)
        hours = total_seconds // 3600
        minutes = (total_seconds % 3600) // 60
        seconds = total_seconds % 60
        
        if hours > 0:
            return f"{hours:02d}:{minutes:02d}:{seconds:02d}"
        return f"{minutes:02d}:{seconds:02d}"
    
    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "duration_seconds": self.duration_seconds,
            "duration_formatted": self.duration_formatted,
            "sample_rate": self.sample_rate,
            "channels": self.channels,
            "bit_depth": self.bit_depth,
            "codec": self.codec,
        }


@dataclass
class VideoInfo:
    """Video file information."""
    
    duration_seconds: float
    width: int | None = None
    height: int | None = None
    frame_rate: float | None = None
    codec: str | None = None
    has_audio: bool = True
    
    @property
    def duration_formatted(self) -> str:
        """Get formatted duration (MM:SS or HH:MM:SS)."""
        total_seconds = int(self.duration_seconds)
        hours = total_seconds // 3600
        minutes = (total_seconds % 3600) // 60
        seconds = total_seconds % 60
        
        if hours > 0:
            return f"{hours:02d}:{minutes:02d}:{seconds:02d}"
        return f"{minutes:02d}:{seconds:02d}"
    
    @property
    def dimensions(self) -> ImageDimensions | None:
        """Get video dimensions."""
        if self.width and self.height:
            return ImageDimensions(self.width, self.height)
        return None
    
    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "duration_seconds": self.duration_seconds,
            "duration_formatted": self.duration_formatted,
            "width": self.width,
            "height": self.height,
            "frame_rate": self.frame_rate,
            "codec": self.codec,
            "has_audio": self.has_audio,
        }


@dataclass
class ProcessingResult:
    """Result of media processing operation."""
    
    success: bool
    data: bytes | None = None
    mime_type: str | None = None
    message: str | None = None
    original_size: int = 0
    processed_size: int = 0
    metadata: dict[str, Any] = field(default_factory=dict)
    
    @property
    def size_reduction_percent(self) -> float:
        """Get size reduction percentage."""
        if self.original_size == 0:
            return 0
        return (1 - self.processed_size / self.original_size) * 100
    
    def to_media_content(self) -> MediaContent | None:
        """Convert to MediaContent if successful."""
        if self.success and self.data and self.mime_type:
            return MediaContent.from_bytes(
                data=self.data,
                mime_type=self.mime_type,
                filename=self.metadata.get("filename"),
            )
        return None


class ImageProcessor:
    """
    Pure Python image processing utilities.
    
    Note: For advanced image processing, consider using Pillow (PIL).
    This class provides basic functionality without external dependencies.
    
    Example:
        # Get image dimensions
        dims = ImageProcessor.get_dimensions(image_data)
        
        # Check if valid image
        is_valid = ImageProcessor.is_valid_image(data)
        
        # Prepare for provider
        prepared = ImageProcessor.prepare_for_provider(content, "anthropic")
    """
    
    @staticmethod
    def get_dimensions(data: bytes) -> ImageDimensions | None:
        """
        Get image dimensions from raw bytes.
        
        Supports PNG, JPEG, GIF, WEBP formats.
        
        Args:
            data: Image bytes
            
        Returns:
            ImageDimensions or None if format not recognized
        """
        if len(data) < 24:
            return None
        
        # PNG
        if data[:8] == b"\x89PNG\r\n\x1a\n":
            # Width and height at bytes 16-24
            width = struct.unpack(">I", data[16:20])[0]
            height = struct.unpack(">I", data[20:24])[0]
            return ImageDimensions(width, height)
        
        # JPEG
        if data[:3] == b"\xff\xd8\xff":
            return ImageProcessor._get_jpeg_dimensions(data)
        
        # GIF
        if data[:6] in (b"GIF87a", b"GIF89a"):
            width = struct.unpack("<H", data[6:8])[0]
            height = struct.unpack("<H", data[8:10])[0]
            return ImageDimensions(width, height)
        
        # WebP
        if data[:4] == b"RIFF" and data[8:12] == b"WEBP":
            return ImageProcessor._get_webp_dimensions(data)
        
        # BMP
        if data[:2] == b"BM":
            width = struct.unpack("<I", data[18:22])[0]
            height = abs(struct.unpack("<i", data[22:26])[0])
            return ImageDimensions(width, height)
        
        return None
    
    @staticmethod
    def _get_jpeg_dimensions(data: bytes) -> ImageDimensions | None:
        """Parse JPEG to get dimensions."""
        i = 2  # Skip SOI marker
        while i < len(data) - 8:
            if data[i] != 0xFF:
                return None
            
            marker = data[i + 1]
            
            # Skip padding bytes
            while marker == 0xFF and i < len(data) - 2:
                i += 1
                marker = data[i + 1]
            
            i += 2
            
            # SOF markers contain image dimensions
            if marker in (0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7,
                          0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF):
                # Skip length (2 bytes) and precision (1 byte)
                height = struct.unpack(">H", data[i + 3:i + 5])[0]
                width = struct.unpack(">H", data[i + 5:i + 7])[0]
                return ImageDimensions(width, height)
            
            # Skip to next marker
            if i + 2 > len(data):
                return None
            length = struct.unpack(">H", data[i:i + 2])[0]
            i += length
        
        return None
    
    @staticmethod
    def _get_webp_dimensions(data: bytes) -> ImageDimensions | None:
        """Parse WebP to get dimensions."""
        if len(data) < 30:
            return None
        
        # VP8 format
        if data[12:16] == b"VP8 ":
            # Dimensions at bytes 26-30
            if len(data) < 30:
                return None
            width = struct.unpack("<H", data[26:28])[0] & 0x3FFF
            height = struct.unpack("<H", data[28:30])[0] & 0x3FFF
            return ImageDimensions(width, height)
        
        # VP8L (lossless)
        if data[12:16] == b"VP8L":
            if len(data) < 25:
                return None
            # Skip signature byte
            bits = struct.unpack("<I", data[21:25])[0]
            width = (bits & 0x3FFF) + 1
            height = ((bits >> 14) & 0x3FFF) + 1
            return ImageDimensions(width, height)
        
        # VP8X (extended)
        if data[12:16] == b"VP8X":
            if len(data) < 30:
                return None
            width = struct.unpack("<I", data[24:27] + b"\x00")[0] + 1
            height = struct.unpack("<I", data[27:30] + b"\x00")[0] + 1
            return ImageDimensions(width, height)
        
        return None
    
    @staticmethod
    def is_valid_image(data: bytes) -> bool:
        """
        Check if data is a valid image.
        
        Args:
            data: Bytes to check
            
        Returns:
            True if valid image format
        """
        mime = MIMETypeDetector.from_bytes(data)
        return mime is not None and mime.startswith("image/")
    
    @staticmethod
    def get_format(data: bytes) -> ImageFormat | None:
        """
        Get image format from bytes.
        
        Args:
            data: Image bytes
            
        Returns:
            ImageFormat enum or None
        """
        mime = MIMETypeDetector.from_bytes(data)
        if not mime:
            return None
        
        try:
            return ImageFormat(mime)
        except ValueError:
            return None
    
    @staticmethod
    def validate_for_provider(
        content: MediaContent,
        provider: str
    ) -> tuple[bool, list[str]]:
        """
        Validate image content for a specific provider.
        
        Args:
            content: MediaContent to validate
            provider: Provider name
            
        Returns:
            Tuple of (is_valid, list of error messages)
        """
        errors = content.validate_for_provider(provider)
        
        capabilities = PROVIDER_CAPABILITIES.get(provider, {})
        
        # Check dimensions if data is available
        if content.data:
            dims = ImageProcessor.get_dimensions(content.data)
            if dims:
                max_dim = capabilities.get("max_image_dimension", float("inf"))
                if dims.width > max_dim or dims.height > max_dim:
                    errors.append(
                        f"Image dimensions {dims.width}x{dims.height} exceed "
                        f"{provider} limit of {max_dim}px"
                    )
        
        return len(errors) == 0, errors
    
    @classmethod
    def prepare_for_provider(
        cls,
        content: MediaContent,
        provider: str
    ) -> ProcessingResult:
        """
        Prepare image content for a specific provider.
        
        This method validates and potentially transforms the content
        to meet provider requirements.
        
        Args:
            content: MediaContent to prepare
            provider: Target provider
            
        Returns:
            ProcessingResult with prepared data
        """
        if content.data is None:
            # URL-based content - can't process without downloading
            return ProcessingResult(
                success=True,
                data=None,
                mime_type=content.mime_type,
                message="URL-based content passed through without processing",
                metadata={"url": content.url}
            )
        
        is_valid, errors = cls.validate_for_provider(content, provider)
        
        if not is_valid:
            return ProcessingResult(
                success=False,
                message="; ".join(errors),
                original_size=len(content.data),
            )
        
        # Return processed content
        return ProcessingResult(
            success=True,
            data=content.data,
            mime_type=content.mime_type,
            original_size=len(content.data),
            processed_size=len(content.data),
            metadata={
                "dimensions": ImageProcessor.get_dimensions(content.data),
                "provider": provider,
            }
        )


class AudioProcessor:
    """
    Audio processing utilities.
    
    Note: For advanced audio processing, consider using pydub or librosa.
    This class provides basic functionality without external dependencies.
    
    Example:
        # Get audio info
        info = AudioProcessor.get_info(audio_data, "audio/wav")
        
        # Check if valid audio
        is_valid = AudioProcessor.is_valid_audio(data)
    """
    
    @staticmethod
    def get_info(data: bytes, mime_type: str) -> AudioInfo | None:
        """
        Get audio information from bytes.
        
        Args:
            data: Audio bytes
            mime_type: MIME type of audio
            
        Returns:
            AudioInfo or None
        """
        if mime_type == "audio/wav" or mime_type == "audio/wave":
            return AudioProcessor._get_wav_info(data)
        elif mime_type == "audio/mpeg" or mime_type == "audio/mp3":
            return AudioProcessor._get_mp3_info(data)
        
        return None
    
    @staticmethod
    def _get_wav_info(data: bytes) -> AudioInfo | None:
        """Parse WAV file to get info."""
        try:
            with io.BytesIO(data) as buf:
                with wave.open(buf, "rb") as wav:
                    frames = wav.getnframes()
                    rate = wav.getframerate()
                    channels = wav.getnchannels()
                    sample_width = wav.getsampwidth()
                    
                    duration = frames / rate if rate > 0 else 0
                    
                    return AudioInfo(
                        duration_seconds=duration,
                        sample_rate=rate,
                        channels=channels,
                        bit_depth=sample_width * 8,
                        codec="PCM",
                    )
        except Exception:
            return None
    
    @staticmethod
    def _get_mp3_info(data: bytes) -> AudioInfo | None:
        """
        Parse MP3 file to get approximate info.
        
        Note: This is a simplified parser and may not be accurate for VBR files.
        """
        # Look for ID3 tag
        offset = 0
        if data[:3] == b"ID3":
            # Skip ID3 tag
            if len(data) < 10:
                return None
            size = ((data[6] & 0x7F) << 21 |
                    (data[7] & 0x7F) << 14 |
                    (data[8] & 0x7F) << 7 |
                    (data[9] & 0x7F))
            offset = size + 10
        
        # Find first frame header
        while offset < len(data) - 4:
            if data[offset] == 0xFF and (data[offset + 1] & 0xE0) == 0xE0:
                break
            offset += 1
        else:
            return None
        
        if offset + 4 > len(data):
            return None
        
        # Parse frame header
        header = struct.unpack(">I", data[offset:offset + 4])[0]
        
        # MPEG version
        version = (header >> 19) & 0x03
        version_map = {0: 2.5, 2: 2, 3: 1}
        mpeg_version = version_map.get(version, 1)
        
        # Layer
        layer = (header >> 17) & 0x03
        layer_map = {1: 3, 2: 2, 3: 1}
        layer_num = layer_map.get(layer, 3)
        
        # Bitrate
        bitrate_idx = (header >> 12) & 0x0F
        if mpeg_version == 1:
            bitrate_table = [0, 32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320]
        else:
            bitrate_table = [0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160]
        bitrate = bitrate_table[bitrate_idx] if bitrate_idx < len(bitrate_table) else 128
        
        # Sample rate
        sample_idx = (header >> 10) & 0x03
        if mpeg_version == 1:
            sample_table = [44100, 48000, 32000]
        elif mpeg_version == 2:
            sample_table = [22050, 24000, 16000]
        else:
            sample_table = [11025, 12000, 8000]
        sample_rate = sample_table[sample_idx] if sample_idx < len(sample_table) else 44100
        
        # Channels
        channel_mode = (header >> 6) & 0x03
        channels = 1 if channel_mode == 3 else 2
        
        # Estimate duration from file size and bitrate
        duration = (len(data) * 8) / (bitrate * 1000) if bitrate > 0 else 0
        
        return AudioInfo(
            duration_seconds=duration,
            sample_rate=sample_rate,
            channels=channels,
            bit_depth=16,  # MP3 is typically 16-bit equivalent
            codec=f"MPEG {mpeg_version} Layer {layer_num}",
        )
    
    @staticmethod
    def is_valid_audio(data: bytes) -> bool:
        """
        Check if data is valid audio.
        
        Args:
            data: Bytes to check
            
        Returns:
            True if valid audio format
        """
        mime = MIMETypeDetector.from_bytes(data)
        return mime is not None and mime.startswith("audio/")
    
    @staticmethod
    def get_format(data: bytes) -> AudioFormat | None:
        """
        Get audio format from bytes.
        
        Args:
            data: Audio bytes
            
        Returns:
            AudioFormat enum or None
        """
        mime = MIMETypeDetector.from_bytes(data)
        if not mime:
            return None
        
        try:
            return AudioFormat(mime)
        except ValueError:
            return None


class VideoProcessor:
    """
    Video processing utilities.
    
    Note: For advanced video processing, consider using moviepy or ffmpeg-python.
    This class provides basic functionality without external dependencies.
    
    Example:
        # Get video info
        info = VideoProcessor.get_info(video_data)
        
        # Check if valid video
        is_valid = VideoProcessor.is_valid_video(data)
    """
    
    @staticmethod
    def get_info(data: bytes) -> VideoInfo | None:
        """
        Get video information from bytes.
        
        Args:
            data: Video bytes
            
        Returns:
            VideoInfo or None
        """
        mime = MIMETypeDetector.from_bytes(data)
        
        if mime == "video/mp4":
            return VideoProcessor._get_mp4_info(data)
        elif mime == "video/webm":
            return VideoProcessor._get_webm_info(data)
        
        return None
    
    @staticmethod
    def _get_mp4_info(data: bytes) -> VideoInfo | None:
        """
        Parse MP4 file to get basic info.
        
        This is a simplified parser that looks for common atoms.
        """
        # Very basic MP4 parsing - look for moov atom
        offset = 0
        while offset < len(data) - 8:
            try:
                size = struct.unpack(">I", data[offset:offset + 4])[0]
                atom_type = data[offset + 4:offset + 8]
                
                if size == 0:
                    break
                if size == 1:
                    if offset + 16 > len(data):
                        break
                    size = struct.unpack(">Q", data[offset + 8:offset + 16])[0]
                
                if atom_type == b"moov":
                    # Found moov - could parse further for metadata
                    # For now, just return basic info
                    return VideoInfo(
                        duration_seconds=0,  # Would need to parse mvhd
                        codec="H.264",  # Common assumption
                    )
                
                offset += size
            except Exception:
                break
        
        return VideoInfo(duration_seconds=0, codec="MP4")
    
    @staticmethod
    def _get_webm_info(data: bytes) -> VideoInfo | None:
        """Parse WebM file for basic info."""
        # WebM uses EBML format - very complex to parse
        # Return basic info
        return VideoInfo(
            duration_seconds=0,
            codec="VP8/VP9",
        )
    
    @staticmethod
    def is_valid_video(data: bytes) -> bool:
        """
        Check if data is valid video.
        
        Args:
            data: Bytes to check
            
        Returns:
            True if valid video format
        """
        mime = MIMETypeDetector.from_bytes(data)
        return mime is not None and mime.startswith("video/")
    
    @staticmethod
    def get_format(data: bytes) -> VideoFormat | None:
        """
        Get video format from bytes.
        
        Args:
            data: Video bytes
            
        Returns:
            VideoFormat enum or None
        """
        mime = MIMETypeDetector.from_bytes(data)
        if not mime:
            return None
        
        try:
            return VideoFormat(mime)
        except ValueError:
            return None


class MediaProcessor:
    """
    Unified media processor that routes to appropriate processor.
    
    Example:
        processor = MediaProcessor()
        
        # Process any media type
        result = processor.process(content, provider="openai")
        
        # Get media info
        info = processor.get_info(content)
    """
    
    def __init__(self) -> None:
        """Initialize media processor."""
        self.image_processor = ImageProcessor()
        self.audio_processor = AudioProcessor()
        self.video_processor = VideoProcessor()
    
    def get_info(
        self,
        content: MediaContent
    ) -> ImageDimensions | AudioInfo | VideoInfo | None:
        """
        Get information about media content.
        
        Args:
            content: MediaContent to analyze
            
        Returns:
            Media info object or None
        """
        if content.data is None:
            return None
        
        if content.media_type == MediaType.IMAGE:
            return ImageProcessor.get_dimensions(content.data)
        elif content.media_type == MediaType.AUDIO:
            return AudioProcessor.get_info(content.data, content.mime_type)
        elif content.media_type == MediaType.VIDEO:
            return VideoProcessor.get_info(content.data)
        
        return None
    
    def validate(
        self,
        content: MediaContent,
        provider: str
    ) -> tuple[bool, list[str]]:
        """
        Validate content for a provider.
        
        Args:
            content: MediaContent to validate
            provider: Target provider
            
        Returns:
            Tuple of (is_valid, error messages)
        """
        errors = content.validate_for_provider(provider)
        
        if content.media_type == MediaType.IMAGE and content.data:
            _, image_errors = ImageProcessor.validate_for_provider(content, provider)
            errors.extend(image_errors)
        
        return len(errors) == 0, list(set(errors))  # Remove duplicates
    
    def process(
        self,
        content: MediaContent,
        provider: str
    ) -> ProcessingResult:
        """
        Process content for a specific provider.
        
        Args:
            content: MediaContent to process
            provider: Target provider
            
        Returns:
            ProcessingResult
        """
        if content.media_type == MediaType.IMAGE:
            return ImageProcessor.prepare_for_provider(content, provider)
        
        # For audio/video, just validate
        is_valid, errors = self.validate(content, provider)
        
        if not is_valid:
            return ProcessingResult(
                success=False,
                message="; ".join(errors),
                original_size=content.size_bytes or 0,
            )
        
        return ProcessingResult(
            success=True,
            data=content.data,
            mime_type=content.mime_type,
            original_size=content.size_bytes or 0,
            processed_size=content.size_bytes or 0,
            metadata={"provider": provider}
        )
    
    def is_valid_media(self, data: bytes) -> bool:
        """
        Check if data is valid media content.
        
        Args:
            data: Bytes to check
            
        Returns:
            True if valid media
        """
        return (
            ImageProcessor.is_valid_image(data) or
            AudioProcessor.is_valid_audio(data) or
            VideoProcessor.is_valid_video(data)
        )
    
    def detect_media_type(self, data: bytes) -> MediaType | None:
        """
        Detect media type from bytes.
        
        Args:
            data: Bytes to analyze
            
        Returns:
            MediaType or None
        """
        if ImageProcessor.is_valid_image(data):
            return MediaType.IMAGE
        elif AudioProcessor.is_valid_audio(data):
            return MediaType.AUDIO
        elif VideoProcessor.is_valid_video(data):
            return MediaType.VIDEO
        
        return None


# Convenience functions

def get_image_dimensions(data: bytes) -> ImageDimensions | None:
    """Get image dimensions from bytes."""
    return ImageProcessor.get_dimensions(data)


def get_audio_info(data: bytes, mime_type: str) -> AudioInfo | None:
    """Get audio information from bytes."""
    return AudioProcessor.get_info(data, mime_type)


def get_video_info(data: bytes) -> VideoInfo | None:
    """Get video information from bytes."""
    return VideoProcessor.get_info(data)


def is_valid_image(data: bytes) -> bool:
    """Check if data is a valid image."""
    return ImageProcessor.is_valid_image(data)


def is_valid_audio(data: bytes) -> bool:
    """Check if data is valid audio."""
    return AudioProcessor.is_valid_audio(data)


def is_valid_video(data: bytes) -> bool:
    """Check if data is valid video."""
    return VideoProcessor.is_valid_video(data)
