"""
Multimodal content types for multi-provider support.

This module provides unified types for handling multimodal content
(images, audio, video) across different AI providers.

Supported Providers:
- OpenAI: base64 or URL for images
- Anthropic: base64 only for images
- Ollama: base64 only for images
- Google Gemini: base64 or URL for images
"""

from __future__ import annotations

import base64
import mimetypes
import os
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Literal


class MediaType(str, Enum):
    """Supported media types."""
    
    IMAGE = "image"
    AUDIO = "audio"
    VIDEO = "video"
    DOCUMENT = "document"


class ImageFormat(str, Enum):
    """Supported image formats."""
    
    JPEG = "image/jpeg"
    PNG = "image/png"
    GIF = "image/gif"
    WEBP = "image/webp"
    SVG = "image/svg+xml"
    BMP = "image/bmp"
    TIFF = "image/tiff"


class AudioFormat(str, Enum):
    """Supported audio formats."""
    
    MP3 = "audio/mpeg"
    WAV = "audio/wav"
    OGG = "audio/ogg"
    FLAC = "audio/flac"
    M4A = "audio/mp4"
    WEBM = "audio/webm"


class VideoFormat(str, Enum):
    """Supported video formats."""
    
    MP4 = "video/mp4"
    WEBM = "video/webm"
    MOV = "video/quicktime"
    AVI = "video/x-msvideo"
    MKV = "video/x-matroska"


class DocumentFormat(str, Enum):
    """Supported document formats."""
    
    PDF = "application/pdf"
    TXT = "text/plain"
    HTML = "text/html"
    JSON = "application/json"
    XML = "application/xml"


# Provider capabilities
PROVIDER_CAPABILITIES: dict[str, dict[str, Any]] = {
    "openai": {
        "supports_url": True,
        "supports_base64": True,
        "image_formats": [ImageFormat.JPEG, ImageFormat.PNG, ImageFormat.GIF, ImageFormat.WEBP],
        "audio_formats": [AudioFormat.MP3, AudioFormat.WAV, AudioFormat.M4A],
        "video_formats": [],  # Not supported yet
        "max_image_size_mb": 20,
        "max_image_dimension": 2048,
    },
    "anthropic": {
        "supports_url": False,
        "supports_base64": True,
        "image_formats": [ImageFormat.JPEG, ImageFormat.PNG, ImageFormat.GIF, ImageFormat.WEBP],
        "audio_formats": [],  # Not supported yet
        "video_formats": [],  # Not supported yet
        "max_image_size_mb": 5,
        "max_image_dimension": 8000,
    },
    "ollama": {
        "supports_url": False,
        "supports_base64": True,
        "image_formats": [ImageFormat.JPEG, ImageFormat.PNG, ImageFormat.GIF],
        "audio_formats": [],
        "video_formats": [],
        "max_image_size_mb": 10,
        "max_image_dimension": 4096,
    },
    "google": {
        "supports_url": True,
        "supports_base64": True,
        "image_formats": [ImageFormat.JPEG, ImageFormat.PNG, ImageFormat.GIF, ImageFormat.WEBP],
        "audio_formats": [AudioFormat.MP3, AudioFormat.WAV, AudioFormat.OGG],
        "video_formats": [VideoFormat.MP4, VideoFormat.WEBM],
        "max_image_size_mb": 20,
        "max_image_dimension": 4096,
    },
}


@dataclass
class MediaContent:
    """
    Unified media content container.
    
    Supports loading from files, URLs, and raw bytes.
    Provides conversion to provider-specific formats.
    
    Example:
        # From file
        image = MediaContent.from_file("photo.jpg")
        
        # From URL
        image = MediaContent.from_url("https://example.com/image.png")
        
        # From base64
        image = MediaContent.from_base64(data, "image/png")
        
        # Convert to provider format
        openai_format = image.to_openai_format()
        anthropic_format = image.to_anthropic_format()
    """
    
    media_type: MediaType
    mime_type: str
    data: bytes | None = None
    url: str | None = None
    filename: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    
    def __post_init__(self) -> None:
        """Validate that either data or url is provided."""
        if self.data is None and self.url is None:
            raise ValueError("Either data or url must be provided")
    
    @classmethod
    def from_file(cls, path: str | Path) -> MediaContent:
        """
        Load media content from a file.
        
        Args:
            path: Path to the media file
            
        Returns:
            MediaContent instance
            
        Raises:
            FileNotFoundError: If file doesn't exist
            ValueError: If file type is not supported
        """
        path = Path(path)
        if not path.exists():
            raise FileNotFoundError(f"File not found: {path}")
        
        # Detect MIME type
        mime_type, _ = mimetypes.guess_type(str(path))
        if mime_type is None:
            mime_type = "application/octet-stream"
        
        # Determine media type
        media_type = cls._detect_media_type(mime_type)
        
        # Read file data
        data = path.read_bytes()
        
        return cls(
            media_type=media_type,
            mime_type=mime_type,
            data=data,
            filename=path.name,
            metadata={
                "source": "file",
                "path": str(path.absolute()),
                "size_bytes": len(data),
            }
        )
    
    @classmethod
    def from_url(cls, url: str, media_type: MediaType | None = None) -> MediaContent:
        """
        Create media content from a URL.
        
        Note: The content is not downloaded until needed.
        
        Args:
            url: URL of the media content
            media_type: Optional media type (auto-detected if not provided)
            
        Returns:
            MediaContent instance
        """
        # Try to detect MIME type from URL
        mime_type, _ = mimetypes.guess_type(url)
        if mime_type is None:
            # Default based on media type or assume image
            if media_type == MediaType.AUDIO:
                mime_type = "audio/mpeg"
            elif media_type == MediaType.VIDEO:
                mime_type = "video/mp4"
            else:
                mime_type = "image/jpeg"
        
        # Detect media type from MIME type if not provided
        if media_type is None:
            media_type = cls._detect_media_type(mime_type)
        
        # Extract filename from URL
        filename = url.split("/")[-1].split("?")[0] or None
        
        return cls(
            media_type=media_type,
            mime_type=mime_type,
            url=url,
            filename=filename,
            metadata={
                "source": "url",
            }
        )
    
    @classmethod
    def from_base64(
        cls,
        data: str,
        mime_type: str,
        filename: str | None = None
    ) -> MediaContent:
        """
        Create media content from base64 encoded data.
        
        Args:
            data: Base64 encoded string
            mime_type: MIME type of the content
            filename: Optional filename
            
        Returns:
            MediaContent instance
        """
        # Decode base64
        try:
            raw_data = base64.b64decode(data)
        except Exception as e:
            raise ValueError(f"Invalid base64 data: {e}")
        
        media_type = cls._detect_media_type(mime_type)
        
        return cls(
            media_type=media_type,
            mime_type=mime_type,
            data=raw_data,
            filename=filename,
            metadata={
                "source": "base64",
                "size_bytes": len(raw_data),
            }
        )
    
    @classmethod
    def from_bytes(
        cls,
        data: bytes,
        mime_type: str,
        filename: str | None = None
    ) -> MediaContent:
        """
        Create media content from raw bytes.
        
        Args:
            data: Raw bytes
            mime_type: MIME type of the content
            filename: Optional filename
            
        Returns:
            MediaContent instance
        """
        media_type = cls._detect_media_type(mime_type)
        
        return cls(
            media_type=media_type,
            mime_type=mime_type,
            data=data,
            filename=filename,
            metadata={
                "source": "bytes",
                "size_bytes": len(data),
            }
        )
    
    @staticmethod
    def _detect_media_type(mime_type: str) -> MediaType:
        """Detect media type from MIME type."""
        if mime_type.startswith("image/"):
            return MediaType.IMAGE
        elif mime_type.startswith("audio/"):
            return MediaType.AUDIO
        elif mime_type.startswith("video/"):
            return MediaType.VIDEO
        elif mime_type in ["application/pdf", "text/plain", "text/html"]:
            return MediaType.DOCUMENT
        else:
            return MediaType.DOCUMENT
    
    def to_base64(self) -> str:
        """
        Convert content to base64 string.
        
        Returns:
            Base64 encoded string
            
        Raises:
            ValueError: If content is URL-only and not downloaded
        """
        if self.data is None:
            raise ValueError(
                "Cannot convert URL-based content to base64 without downloading. "
                "Use download() first or provide base64/file source."
            )
        return base64.b64encode(self.data).decode("utf-8")
    
    def to_data_uri(self) -> str:
        """
        Convert content to data URI.
        
        Returns:
            Data URI string (data:mime_type;base64,...)
        """
        b64 = self.to_base64()
        return f"data:{self.mime_type};base64,{b64}"
    
    def to_openai_format(self, prefer_url: bool = True) -> dict[str, Any]:
        """
        Convert to OpenAI message format.
        
        Args:
            prefer_url: If True and URL is available, use URL instead of base64
            
        Returns:
            OpenAI content format dictionary
        """
        if self.media_type == MediaType.IMAGE:
            if prefer_url and self.url:
                return {
                    "type": "image_url",
                    "image_url": {
                        "url": self.url,
                    }
                }
            else:
                return {
                    "type": "image_url",
                    "image_url": {
                        "url": self.to_data_uri(),
                    }
                }
        elif self.media_type == MediaType.AUDIO:
            # OpenAI uses input_audio for audio
            return {
                "type": "input_audio",
                "input_audio": {
                    "data": self.to_base64(),
                    "format": self._get_audio_format(),
                }
            }
        else:
            # Fallback for other types
            return {
                "type": "text",
                "text": f"[{self.media_type.value}: {self.filename or 'unnamed'}]",
            }
    
    def to_anthropic_format(self) -> dict[str, Any]:
        """
        Convert to Anthropic message format.
        
        Note: Anthropic only supports base64, not URLs.
        
        Returns:
            Anthropic content format dictionary
        """
        if self.media_type == MediaType.IMAGE:
            return {
                "type": "image",
                "source": {
                    "type": "base64",
                    "media_type": self.mime_type,
                    "data": self.to_base64(),
                }
            }
        elif self.media_type == MediaType.DOCUMENT:
            # Anthropic supports PDF documents
            if self.mime_type == "application/pdf":
                return {
                    "type": "document",
                    "source": {
                        "type": "base64",
                        "media_type": self.mime_type,
                        "data": self.to_base64(),
                    }
                }
        # Fallback
        return {
            "type": "text",
            "text": f"[{self.media_type.value}: {self.filename or 'unnamed'}]",
        }
    
    def to_ollama_format(self) -> str:
        """
        Convert to Ollama format.
        
        Note: Ollama uses raw base64 string for images.
        
        Returns:
            Base64 encoded string
        """
        return self.to_base64()
    
    def to_google_format(self, prefer_url: bool = False) -> dict[str, Any]:
        """
        Convert to Google Gemini format.
        
        Args:
            prefer_url: If True and URL is available, use URL
            
        Returns:
            Google content format dictionary
        """
        if prefer_url and self.url:
            return {
                "file_uri": self.url,
                "mime_type": self.mime_type,
            }
        else:
            return {
                "inline_data": {
                    "mime_type": self.mime_type,
                    "data": self.to_base64(),
                }
            }
    
    def _get_audio_format(self) -> str:
        """Get audio format string for OpenAI."""
        format_map = {
            "audio/mpeg": "mp3",
            "audio/mp3": "mp3",
            "audio/wav": "wav",
            "audio/wave": "wav",
            "audio/x-wav": "wav",
            "audio/mp4": "mp4",
            "audio/m4a": "mp4",
        }
        return format_map.get(self.mime_type, "mp3")
    
    @property
    def size_bytes(self) -> int | None:
        """Get content size in bytes."""
        if self.data:
            return len(self.data)
        return self.metadata.get("size_bytes")
    
    @property
    def size_mb(self) -> float | None:
        """Get content size in megabytes."""
        size = self.size_bytes
        if size:
            return size / (1024 * 1024)
        return None
    
    def validate_for_provider(self, provider: str) -> list[str]:
        """
        Validate content for a specific provider.
        
        Args:
            provider: Provider name (openai, anthropic, ollama, google)
            
        Returns:
            List of validation errors (empty if valid)
        """
        errors = []
        capabilities = PROVIDER_CAPABILITIES.get(provider)
        
        if not capabilities:
            errors.append(f"Unknown provider: {provider}")
            return errors
        
        # Check if URL is supported
        if self.url and self.data is None:
            if not capabilities.get("supports_url", False):
                errors.append(f"{provider} doesn't support URL-based content. Use from_file() instead.")
        
        # Check format support for images
        if self.media_type == MediaType.IMAGE:
            supported = capabilities.get("image_formats", [])
            try:
                format_enum = ImageFormat(self.mime_type)
                if format_enum not in supported:
                    errors.append(f"{provider} doesn't support {self.mime_type}")
            except ValueError:
                errors.append(f"Unknown image format: {self.mime_type}")
        
        # Check size limits
        if self.size_mb:
            max_size = capabilities.get("max_image_size_mb", float("inf"))
            if self.size_mb > max_size:
                errors.append(f"Content size {self.size_mb:.2f}MB exceeds {provider} limit of {max_size}MB")
        
        return errors
    
    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary representation."""
        return {
            "media_type": self.media_type.value,
            "mime_type": self.mime_type,
            "has_data": self.data is not None,
            "url": self.url,
            "filename": self.filename,
            "size_bytes": self.size_bytes,
            "metadata": self.metadata,
        }
    
    def __repr__(self) -> str:
        source = "url" if self.url else "data"
        size = f", {self.size_mb:.2f}MB" if self.size_mb else ""
        return f"MediaContent({self.media_type.value}, {self.mime_type}, {source}{size})"


@dataclass
class MultimodalMessage:
    """
    A message that can contain text and multiple media elements.
    
    Provides unified API for creating messages with multimodal content
    and converting to provider-specific formats.
    
    Example:
        # Text with images
        message = MultimodalMessage(
            text="What's in this image?",
            images=[MediaContent.from_file("photo.jpg")]
        )
        
        # Convert to provider format
        openai_content = message.to_openai_format()
        anthropic_content = message.to_anthropic_format()
    """
    
    text: str | None = None
    images: list[MediaContent] = field(default_factory=list)
    audio: MediaContent | None = None
    video: MediaContent | None = None
    documents: list[MediaContent] = field(default_factory=list)
    role: Literal["user", "assistant", "system"] = "user"
    metadata: dict[str, Any] = field(default_factory=dict)
    
    def __post_init__(self) -> None:
        """Validate that message has some content."""
        if not any([self.text, self.images, self.audio, self.video, self.documents]):
            raise ValueError("Message must have at least one content element (text, images, audio, video, or documents)")
    
    @classmethod
    def from_text(cls, text: str, role: str = "user") -> MultimodalMessage:
        """Create a text-only message."""
        return cls(text=text, role=role)
    
    @classmethod
    def with_image(
        cls,
        text: str,
        image: str | Path | MediaContent,
        role: str = "user"
    ) -> MultimodalMessage:
        """
        Create a message with text and a single image.
        
        Args:
            text: The text content
            image: Image as path string, Path, or MediaContent
            role: Message role
            
        Returns:
            MultimodalMessage instance
        """
        if isinstance(image, (str, Path)):
            # Check if it's a URL
            if isinstance(image, str) and image.startswith(("http://", "https://")):
                media = MediaContent.from_url(image)
            else:
                media = MediaContent.from_file(image)
        else:
            media = image
        
        return cls(text=text, images=[media], role=role)
    
    @classmethod
    def with_images(
        cls,
        text: str,
        images: list[str | Path | MediaContent],
        role: str = "user"
    ) -> MultimodalMessage:
        """
        Create a message with text and multiple images.
        
        Args:
            text: The text content
            images: List of images as paths or MediaContent
            role: Message role
            
        Returns:
            MultimodalMessage instance
        """
        media_list = []
        for img in images:
            if isinstance(img, (str, Path)):
                if isinstance(img, str) and img.startswith(("http://", "https://")):
                    media_list.append(MediaContent.from_url(img))
                else:
                    media_list.append(MediaContent.from_file(img))
            else:
                media_list.append(img)
        
        return cls(text=text, images=media_list, role=role)
    
    @classmethod
    def with_audio(
        cls,
        text: str | None,
        audio: str | Path | MediaContent,
        role: str = "user"
    ) -> MultimodalMessage:
        """
        Create a message with optional text and audio.
        
        Args:
            text: Optional text content
            audio: Audio as path string, Path, or MediaContent
            role: Message role
            
        Returns:
            MultimodalMessage instance
        """
        if isinstance(audio, (str, Path)):
            if isinstance(audio, str) and audio.startswith(("http://", "https://")):
                media = MediaContent.from_url(audio, MediaType.AUDIO)
            else:
                media = MediaContent.from_file(audio)
        else:
            media = audio
        
        return cls(text=text, audio=media, role=role)
    
    @classmethod
    def with_document(
        cls,
        text: str,
        document: str | Path | MediaContent,
        role: str = "user"
    ) -> MultimodalMessage:
        """
        Create a message with text and a document.
        
        Args:
            text: The text content
            document: Document as path string, Path, or MediaContent
            role: Message role
            
        Returns:
            MultimodalMessage instance
        """
        if isinstance(document, (str, Path)):
            media = MediaContent.from_file(document)
        else:
            media = document
        
        return cls(text=text, documents=[media], role=role)
    
    def add_image(self, image: str | Path | MediaContent) -> MultimodalMessage:
        """
        Add an image to the message.
        
        Args:
            image: Image to add
            
        Returns:
            Self for chaining
        """
        if isinstance(image, (str, Path)):
            if isinstance(image, str) and image.startswith(("http://", "https://")):
                self.images.append(MediaContent.from_url(image))
            else:
                self.images.append(MediaContent.from_file(image))
        else:
            self.images.append(image)
        return self
    
    def add_document(self, document: str | Path | MediaContent) -> MultimodalMessage:
        """
        Add a document to the message.
        
        Args:
            document: Document to add
            
        Returns:
            Self for chaining
        """
        if isinstance(document, (str, Path)):
            self.documents.append(MediaContent.from_file(document))
        else:
            self.documents.append(document)
        return self
    
    def to_openai_format(self, prefer_url: bool = True) -> dict[str, Any]:
        """
        Convert to OpenAI message format.
        
        Args:
            prefer_url: If True, prefer URLs over base64 for images
            
        Returns:
            OpenAI message dictionary
        """
        content = []
        
        # Add text first
        if self.text:
            content.append({
                "type": "text",
                "text": self.text,
            })
        
        # Add images
        for image in self.images:
            content.append(image.to_openai_format(prefer_url=prefer_url))
        
        # Add audio if present
        if self.audio:
            content.append(self.audio.to_openai_format())
        
        # If only text, return simple format
        if len(content) == 1 and content[0]["type"] == "text":
            return {
                "role": self.role,
                "content": self.text,
            }
        
        return {
            "role": self.role,
            "content": content,
        }
    
    def to_anthropic_format(self) -> dict[str, Any]:
        """
        Convert to Anthropic message format.
        
        Returns:
            Anthropic message dictionary
        """
        content = []
        
        # Add images first (Anthropic prefers images before text)
        for image in self.images:
            content.append(image.to_anthropic_format())
        
        # Add documents
        for doc in self.documents:
            content.append(doc.to_anthropic_format())
        
        # Add text
        if self.text:
            content.append({
                "type": "text",
                "text": self.text,
            })
        
        # If only text, return simple format
        if len(content) == 1 and content[0]["type"] == "text":
            return {
                "role": self.role,
                "content": self.text,
            }
        
        return {
            "role": self.role,
            "content": content,
        }
    
    def to_ollama_format(self) -> dict[str, Any]:
        """
        Convert to Ollama message format.
        
        Returns:
            Ollama message dictionary
        """
        message: dict[str, Any] = {
            "role": self.role,
            "content": self.text or "",
        }
        
        # Add images as base64 list
        if self.images:
            message["images"] = [img.to_ollama_format() for img in self.images]
        
        return message
    
    def to_google_format(self, prefer_url: bool = False) -> dict[str, Any]:
        """
        Convert to Google Gemini format.
        
        Args:
            prefer_url: If True, prefer URLs over base64
            
        Returns:
            Google message dictionary
        """
        parts = []
        
        # Add text
        if self.text:
            parts.append({"text": self.text})
        
        # Add images
        for image in self.images:
            parts.append(image.to_google_format(prefer_url=prefer_url))
        
        # Add audio
        if self.audio:
            parts.append(self.audio.to_google_format(prefer_url=prefer_url))
        
        # Add video
        if self.video:
            parts.append(self.video.to_google_format(prefer_url=prefer_url))
        
        return {
            "role": self.role if self.role != "assistant" else "model",
            "parts": parts,
        }
    
    def to_provider_format(
        self,
        provider: str,
        **kwargs: Any
    ) -> dict[str, Any]:
        """
        Convert to provider-specific format.
        
        Args:
            provider: Provider name (openai, anthropic, ollama, google)
            **kwargs: Provider-specific options
            
        Returns:
            Provider-specific message dictionary
            
        Raises:
            ValueError: If provider is not supported
        """
        if provider == "openai":
            return self.to_openai_format(**kwargs)
        elif provider == "anthropic":
            return self.to_anthropic_format()
        elif provider == "ollama":
            return self.to_ollama_format()
        elif provider == "google":
            return self.to_google_format(**kwargs)
        else:
            raise ValueError(f"Unsupported provider: {provider}")
    
    def validate_for_provider(self, provider: str) -> list[str]:
        """
        Validate message for a specific provider.
        
        Args:
            provider: Provider name
            
        Returns:
            List of validation errors
        """
        errors = []
        
        for i, image in enumerate(self.images):
            img_errors = image.validate_for_provider(provider)
            errors.extend([f"Image {i + 1}: {e}" for e in img_errors])
        
        if self.audio:
            audio_errors = self.audio.validate_for_provider(provider)
            errors.extend([f"Audio: {e}" for e in audio_errors])
        
        if self.video:
            video_errors = self.video.validate_for_provider(provider)
            errors.extend([f"Video: {e}" for e in video_errors])
        
        for i, doc in enumerate(self.documents):
            doc_errors = doc.validate_for_provider(provider)
            errors.extend([f"Document {i + 1}: {e}" for e in doc_errors])
        
        return errors
    
    @property
    def has_media(self) -> bool:
        """Check if message has any media content."""
        return bool(self.images or self.audio or self.video or self.documents)
    
    @property
    def media_count(self) -> int:
        """Get total count of media elements."""
        count = len(self.images) + len(self.documents)
        if self.audio:
            count += 1
        if self.video:
            count += 1
        return count
    
    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary representation."""
        return {
            "role": self.role,
            "text": self.text,
            "images": [img.to_dict() for img in self.images],
            "audio": self.audio.to_dict() if self.audio else None,
            "video": self.video.to_dict() if self.video else None,
            "documents": [doc.to_dict() for doc in self.documents],
            "has_media": self.has_media,
            "media_count": self.media_count,
            "metadata": self.metadata,
        }
    
    def __repr__(self) -> str:
        parts = []
        if self.text:
            text_preview = self.text[:50] + "..." if len(self.text) > 50 else self.text
            parts.append(f"text='{text_preview}'")
        if self.images:
            parts.append(f"images={len(self.images)}")
        if self.audio:
            parts.append("audio=1")
        if self.video:
            parts.append("video=1")
        if self.documents:
            parts.append(f"documents={len(self.documents)}")
        return f"MultimodalMessage({self.role}, {', '.join(parts)})"
