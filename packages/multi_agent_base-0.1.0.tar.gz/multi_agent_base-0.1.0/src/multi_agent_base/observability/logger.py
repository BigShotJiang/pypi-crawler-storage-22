"""
Structured logging for agent operations.

This module provides structured logging capabilities specifically
designed for multi-agent systems, with support for agent messages,
tool calls, and performance metrics.
"""

from __future__ import annotations

import json
import sys
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Callable, TextIO

import structlog


class LogLevel(str, Enum):
    """Log levels for agent logging."""
    
    DEBUG = "debug"
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"


class EventType(str, Enum):
    """Types of log events."""
    
    AGENT_START = "agent.start"
    AGENT_END = "agent.end"
    AGENT_ERROR = "agent.error"
    MESSAGE_IN = "message.in"
    MESSAGE_OUT = "message.out"
    TOOL_CALL = "tool.call"
    TOOL_RESULT = "tool.result"
    TOOL_ERROR = "tool.error"
    LLM_REQUEST = "llm.request"
    LLM_RESPONSE = "llm.response"
    HANDOFF = "handoff"
    PATTERN_START = "pattern.start"
    PATTERN_END = "pattern.end"


@dataclass
class LogEvent:
    """Structured log event.
    
    Attributes:
        event_type: Type of the event
        agent_name: Name of the agent
        timestamp: Event timestamp
        message: Log message
        data: Additional event data
        level: Log level
        trace_id: Optional trace ID for correlation
        span_id: Optional span ID for correlation
        duration_ms: Optional duration in milliseconds
        error: Optional error information
    """
    
    event_type: EventType
    agent_name: str
    timestamp: datetime = field(default_factory=datetime.now)
    message: str = ""
    data: dict[str, Any] = field(default_factory=dict)
    level: LogLevel = LogLevel.INFO
    trace_id: str | None = None
    span_id: str | None = None
    duration_ms: float | None = None
    error: str | None = None
    
    def to_dict(self) -> dict[str, Any]:
        """Convert event to dictionary.
        
        Returns:
            Dictionary representation
        """
        result = {
            "event_type": self.event_type.value,
            "agent_name": self.agent_name,
            "timestamp": self.timestamp.isoformat(),
            "message": self.message,
            "level": self.level.value,
        }
        
        if self.data:
            result["data"] = self.data
        if self.trace_id:
            result["trace_id"] = self.trace_id
        if self.span_id:
            result["span_id"] = self.span_id
        if self.duration_ms is not None:
            result["duration_ms"] = self.duration_ms
        if self.error:
            result["error"] = self.error
        
        return result
    
    def to_json(self) -> str:
        """Convert event to JSON string.
        
        Returns:
            JSON string representation
        """
        return json.dumps(self.to_dict())


class LogFormatter:
    """Base class for log formatters."""
    
    def format(self, event: LogEvent) -> str:
        """Format a log event.
        
        Args:
            event: The log event to format
            
        Returns:
            Formatted string
        """
        raise NotImplementedError


class JSONFormatter(LogFormatter):
    """JSON log formatter."""
    
    def __init__(self, pretty: bool = False) -> None:
        """Initialize JSON formatter.
        
        Args:
            pretty: Whether to pretty-print JSON
        """
        self.pretty = pretty
    
    def format(self, event: LogEvent) -> str:
        """Format event as JSON.
        
        Args:
            event: Log event
            
        Returns:
            JSON string
        """
        if self.pretty:
            return json.dumps(event.to_dict(), indent=2)
        return event.to_json()


class ConsoleFormatter(LogFormatter):
    """Human-readable console formatter with colors."""
    
    COLORS = {
        LogLevel.DEBUG: "\033[36m",     # Cyan
        LogLevel.INFO: "\033[32m",      # Green
        LogLevel.WARNING: "\033[33m",   # Yellow
        LogLevel.ERROR: "\033[31m",     # Red
        LogLevel.CRITICAL: "\033[35m",  # Magenta
    }
    RESET = "\033[0m"
    
    def __init__(self, colors: bool = True) -> None:
        """Initialize console formatter.
        
        Args:
            colors: Whether to use ANSI colors
        """
        self.colors = colors
    
    def format(self, event: LogEvent) -> str:
        """Format event for console output.
        
        Args:
            event: Log event
            
        Returns:
            Formatted string
        """
        timestamp = event.timestamp.strftime("%H:%M:%S.%f")[:-3]
        level = event.level.value.upper()[:4]
        
        if self.colors:
            color = self.COLORS.get(event.level, "")
            level_str = f"{color}{level}{self.RESET}"
        else:
            level_str = level
        
        parts = [
            f"[{timestamp}]",
            f"[{level_str}]",
            f"[{event.agent_name}]",
            event.event_type.value,
        ]
        
        if event.message:
            parts.append(f"- {event.message}")
        
        if event.duration_ms is not None:
            parts.append(f"({event.duration_ms:.2f}ms)")
        
        if event.error:
            parts.append(f"ERROR: {event.error}")
        
        return " ".join(parts)


class LogHandler:
    """Base class for log handlers."""
    
    def __init__(
        self,
        formatter: LogFormatter | None = None,
        min_level: LogLevel = LogLevel.DEBUG,
    ) -> None:
        """Initialize handler.
        
        Args:
            formatter: Log formatter
            min_level: Minimum log level to handle
        """
        self.formatter = formatter or JSONFormatter()
        self.min_level = min_level
    
    def should_handle(self, event: LogEvent) -> bool:
        """Check if event should be handled.
        
        Args:
            event: Log event
            
        Returns:
            True if event should be handled
        """
        levels = list(LogLevel)
        return levels.index(event.level) >= levels.index(self.min_level)
    
    def handle(self, event: LogEvent) -> None:
        """Handle a log event.
        
        Args:
            event: Log event to handle
        """
        raise NotImplementedError


class StreamHandler(LogHandler):
    """Handler that writes to a stream."""
    
    def __init__(
        self,
        stream: TextIO | None = None,
        formatter: LogFormatter | None = None,
        min_level: LogLevel = LogLevel.DEBUG,
    ) -> None:
        """Initialize stream handler.
        
        Args:
            stream: Output stream (default: stderr)
            formatter: Log formatter
            min_level: Minimum log level
        """
        super().__init__(formatter or ConsoleFormatter(), min_level)
        self.stream = stream or sys.stderr
    
    def handle(self, event: LogEvent) -> None:
        """Write event to stream.
        
        Args:
            event: Log event
        """
        if self.should_handle(event):
            message = self.formatter.format(event)
            self.stream.write(message + "\n")
            self.stream.flush()


class FileHandler(LogHandler):
    """Handler that writes to a file."""
    
    def __init__(
        self,
        path: str | Path,
        formatter: LogFormatter | None = None,
        min_level: LogLevel = LogLevel.DEBUG,
        append: bool = True,
    ) -> None:
        """Initialize file handler.
        
        Args:
            path: Output file path
            formatter: Log formatter
            min_level: Minimum log level
            append: Whether to append to existing file
        """
        super().__init__(formatter or JSONFormatter(), min_level)
        self.path = Path(path)
        self.mode = "a" if append else "w"
        
        # Ensure directory exists
        self.path.parent.mkdir(parents=True, exist_ok=True)
    
    def handle(self, event: LogEvent) -> None:
        """Write event to file.
        
        Args:
            event: Log event
        """
        if self.should_handle(event):
            message = self.formatter.format(event)
            with open(self.path, self.mode) as f:
                f.write(message + "\n")


class CallbackHandler(LogHandler):
    """Handler that calls a callback function."""
    
    def __init__(
        self,
        callback: Callable[[LogEvent], None],
        min_level: LogLevel = LogLevel.DEBUG,
    ) -> None:
        """Initialize callback handler.
        
        Args:
            callback: Function to call with events
            min_level: Minimum log level
        """
        super().__init__(min_level=min_level)
        self.callback = callback
    
    def handle(self, event: LogEvent) -> None:
        """Call callback with event.
        
        Args:
            event: Log event
        """
        if self.should_handle(event):
            self.callback(event)


class AgentLogger:
    """Structured logger for agent operations.
    
    Provides methods for logging agent events with structured
    data and multiple output handlers.
    
    Example:
        ```python
        logger = AgentLogger(
            handlers=[
                StreamHandler(min_level=LogLevel.INFO),
                FileHandler("logs/agents.jsonl"),
            ]
        )
        
        logger.log_agent_start("assistant")
        logger.log_message("assistant", Message(role="user", content="Hi"))
        logger.log_tool_call("assistant", "search", {"query": "AI"}, "result")
        logger.log_agent_end("assistant", duration_ms=1500.0)
        ```
    """
    
    def __init__(
        self,
        handlers: list[LogHandler] | None = None,
        default_level: LogLevel = LogLevel.INFO,
    ) -> None:
        """Initialize the agent logger.
        
        Args:
            handlers: List of log handlers
            default_level: Default log level
        """
        self.handlers = handlers or [StreamHandler()]
        self.default_level = default_level
        self._events: list[LogEvent] = []
        
        # Also set up structlog
        structlog.configure(
            processors=[
                structlog.stdlib.filter_by_level,
                structlog.stdlib.add_logger_name,
                structlog.stdlib.add_log_level,
                structlog.processors.TimeStamper(fmt="iso"),
                structlog.processors.JSONRenderer(),
            ],
            context_class=dict,
            logger_factory=structlog.PrintLoggerFactory(),
            cache_logger_on_first_use=True,
        )
    
    def add_handler(self, handler: LogHandler) -> None:
        """Add a log handler.
        
        Args:
            handler: Handler to add
        """
        self.handlers.append(handler)
    
    def remove_handler(self, handler: LogHandler) -> bool:
        """Remove a log handler.
        
        Args:
            handler: Handler to remove
            
        Returns:
            True if handler was removed
        """
        try:
            self.handlers.remove(handler)
            return True
        except ValueError:
            return False
    
    def log(self, event: LogEvent) -> None:
        """Log an event.
        
        Args:
            event: Log event to record
        """
        self._events.append(event)
        for handler in self.handlers:
            try:
                handler.handle(event)
            except Exception:
                pass  # Don't let handler errors break the flow
    
    def log_agent_start(
        self,
        agent_name: str,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Log agent start.
        
        Args:
            agent_name: Name of the agent
            metadata: Additional metadata
        """
        self.log(LogEvent(
            event_type=EventType.AGENT_START,
            agent_name=agent_name,
            message=f"Agent {agent_name} started",
            data=metadata or {},
        ))
    
    def log_agent_end(
        self,
        agent_name: str,
        duration_ms: float | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Log agent end.
        
        Args:
            agent_name: Name of the agent
            duration_ms: Total duration
            metadata: Additional metadata
        """
        self.log(LogEvent(
            event_type=EventType.AGENT_END,
            agent_name=agent_name,
            message=f"Agent {agent_name} finished",
            duration_ms=duration_ms,
            data=metadata or {},
        ))
    
    def log_message(
        self,
        agent_name: str,
        message: Any,
        direction: str = "in",
    ) -> None:
        """Log a message.
        
        Args:
            agent_name: Name of the agent
            message: Message object or dict
            direction: "in" for incoming, "out" for outgoing
        """
        event_type = EventType.MESSAGE_IN if direction == "in" else EventType.MESSAGE_OUT
        
        content = ""
        role = ""
        
        if hasattr(message, "content"):
            content = message.content
            role = getattr(message, "role", "")
        elif isinstance(message, dict):
            content = message.get("content", "")
            role = message.get("role", "")
        else:
            content = str(message)
        
        self.log(LogEvent(
            event_type=event_type,
            agent_name=agent_name,
            message=f"[{role}] {content[:100]}..." if len(content) > 100 else f"[{role}] {content}",
            data={"role": role, "content": content},
        ))
    
    def log_tool_call(
        self,
        agent_name: str,
        tool_name: str,
        arguments: dict[str, Any],
        result: Any = None,
        duration_ms: float | None = None,
        error: str | None = None,
    ) -> None:
        """Log a tool call.
        
        Args:
            agent_name: Name of the agent
            tool_name: Name of the tool
            arguments: Tool arguments
            result: Tool result
            duration_ms: Call duration
            error: Error message if failed
        """
        level = LogLevel.ERROR if error else LogLevel.INFO
        event_type = EventType.TOOL_ERROR if error else EventType.TOOL_CALL
        
        self.log(LogEvent(
            event_type=event_type,
            agent_name=agent_name,
            message=f"Tool {tool_name} called",
            data={
                "tool": tool_name,
                "arguments": arguments,
                "result": str(result)[:500] if result else None,
            },
            duration_ms=duration_ms,
            error=error,
            level=level,
        ))
    
    def log_tool_registered(
        self,
        agent_name: str,
        tool_name: str,
    ) -> None:
        """Log tool registration.
        
        Args:
            agent_name: Name of the agent
            tool_name: Name of the tool
        """
        self.log(LogEvent(
            event_type=EventType.TOOL_CALL,
            agent_name=agent_name,
            message=f"Tool {tool_name} registered",
            data={"tool": tool_name, "action": "register"},
            level=LogLevel.DEBUG,
        ))
    
    def log_llm_call(
        self,
        agent_name: str,
        model: str,
        provider: str,
        input_tokens: int,
        output_tokens: int,
        duration_ms: float,
        cost: float | None = None,
    ) -> None:
        """Log an LLM call.
        
        Args:
            agent_name: Name of the agent
            model: Model name
            provider: Provider name
            input_tokens: Input token count
            output_tokens: Output token count
            duration_ms: Call duration
            cost: Cost in USD
        """
        self.log(LogEvent(
            event_type=EventType.LLM_RESPONSE,
            agent_name=agent_name,
            message=f"LLM call to {provider}/{model}",
            data={
                "model": model,
                "provider": provider,
                "input_tokens": input_tokens,
                "output_tokens": output_tokens,
                "total_tokens": input_tokens + output_tokens,
                "cost_usd": cost,
            },
            duration_ms=duration_ms,
        ))
    
    def log_run_complete(
        self,
        agent_name: str,
        duration_ms: float,
        tokens: dict[str, int] | None = None,
        cost: float | None = None,
    ) -> None:
        """Log run completion with summary.
        
        Args:
            agent_name: Name of the agent
            duration_ms: Total duration
            tokens: Token usage summary
            cost: Total cost
        """
        self.log(LogEvent(
            event_type=EventType.AGENT_END,
            agent_name=agent_name,
            message=f"Run complete",
            data={
                "tokens": tokens or {},
                "cost_usd": cost,
            },
            duration_ms=duration_ms,
        ))
    
    def log_error(
        self,
        agent_name: str,
        error_message: str,
        error_type: str = "error",
    ) -> None:
        """Log an error.
        
        Args:
            agent_name: Name of the agent
            error_message: Error message
            error_type: Type of error
        """
        self.log(LogEvent(
            event_type=EventType.AGENT_ERROR,
            agent_name=agent_name,
            message=error_message,
            error=error_message,
            level=LogLevel.ERROR,
            data={"error_type": error_type},
        ))
    
    def log_handoff(
        self,
        from_agent: str,
        to_agent: str,
        reason: str = "",
    ) -> None:
        """Log an agent handoff.
        
        Args:
            from_agent: Source agent
            to_agent: Target agent
            reason: Reason for handoff
        """
        self.log(LogEvent(
            event_type=EventType.HANDOFF,
            agent_name=from_agent,
            message=f"Handoff to {to_agent}",
            data={
                "from": from_agent,
                "to": to_agent,
                "reason": reason,
            },
        ))
    
    def get_events(
        self,
        agent_name: str | None = None,
        event_type: EventType | None = None,
    ) -> list[LogEvent]:
        """Get logged events with optional filtering.
        
        Args:
            agent_name: Filter by agent name
            event_type: Filter by event type
            
        Returns:
            List of matching events
        """
        events = self._events
        
        if agent_name:
            events = [e for e in events if e.agent_name == agent_name]
        
        if event_type:
            events = [e for e in events if e.event_type == event_type]
        
        return events
    
    def clear_events(self) -> None:
        """Clear the event history."""
        self._events = []


def create_logger(
    console: bool = True,
    file_path: str | None = None,
    min_level: LogLevel = LogLevel.INFO,
) -> AgentLogger:
    """Create a configured agent logger.
    
    Args:
        console: Whether to log to console
        file_path: Optional file path for logging
        min_level: Minimum log level
        
    Returns:
        Configured AgentLogger instance
    """
    handlers: list[LogHandler] = []
    
    if console:
        handlers.append(StreamHandler(
            formatter=ConsoleFormatter(colors=True),
            min_level=min_level,
        ))
    
    if file_path:
        handlers.append(FileHandler(
            path=file_path,
            formatter=JSONFormatter(),
            min_level=min_level,
        ))
    
    return AgentLogger(handlers=handlers, default_level=min_level)
