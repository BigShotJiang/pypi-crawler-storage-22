"""
Arize Phoenix integration for observability.

This module provides integration with Arize Phoenix for
distributed tracing, LLM observability, and agent monitoring.
Phoenix is an open-source, OpenTelemetry-based observability
platform for AI applications.
"""

from __future__ import annotations

import atexit
from contextlib import contextmanager
from typing import TYPE_CHECKING, Any, Generator

if TYPE_CHECKING:
    from opentelemetry.trace import Span, Tracer


class PhoenixConfig:
    """Configuration for Phoenix integration.
    
    Attributes:
        endpoint: Phoenix collector endpoint
        project_name: Project name for trace grouping
        enabled: Whether Phoenix tracing is enabled
        export_to_collector: Whether to export spans to remote collector
        launch_app: Whether to launch Phoenix app locally
    """
    
    def __init__(
        self,
        endpoint: str = "http://localhost:6006",
        project_name: str = "multi-agent-base",
        enabled: bool = True,
        export_to_collector: bool = True,
        launch_app: bool = False,
    ) -> None:
        """Initialize Phoenix configuration.
        
        Args:
            endpoint: Phoenix collector endpoint
            project_name: Project name for grouping
            enabled: Enable Phoenix tracing
            export_to_collector: Export to remote collector
            launch_app: Launch local Phoenix app
        """
        self.endpoint = endpoint
        self.project_name = project_name
        self.enabled = enabled
        self.export_to_collector = export_to_collector
        self.launch_app = launch_app


class PhoenixTracer:
    """Tracer wrapper for Arize Phoenix.
    
    Provides a convenient interface for creating traces and spans
    for agent operations, LLM calls, and tool executions.
    
    Example:
        ```python
        tracer = PhoenixTracer(config=PhoenixConfig(
            endpoint="http://localhost:6006",
            project_name="my-agents",
        ))
        
        tracer.setup()
        
        with tracer.start_span("agent_run", attributes={"agent": "assistant"}):
            # Agent execution code
            pass
        ```
    """
    
    _instance: "PhoenixTracer | None" = None
    _initialized: bool = False
    
    def __init__(
        self,
        config: PhoenixConfig | None = None,
    ) -> None:
        """Initialize the Phoenix tracer.
        
        Args:
            config: Phoenix configuration
        """
        self.config = config or PhoenixConfig()
        self._tracer: Tracer | None = None
        self._phoenix_session = None
    
    @classmethod
    def get_instance(cls, config: PhoenixConfig | None = None) -> "PhoenixTracer":
        """Get the singleton instance of PhoenixTracer.
        
        Args:
            config: Optional configuration for first initialization
            
        Returns:
            PhoenixTracer singleton instance
        """
        if cls._instance is None:
            cls._instance = cls(config)
        return cls._instance
    
    def setup(self) -> None:
        """Set up Phoenix tracing.
        
        This initializes the OpenTelemetry tracing provider and
        configures the Phoenix exporter.
        """
        if not self.config.enabled:
            return
        
        if self._initialized:
            return
        
        try:
            # Import Phoenix and OpenTelemetry
            from opentelemetry import trace
            from opentelemetry.sdk.trace import TracerProvider
            from opentelemetry.sdk.resources import Resource
            
            # Create resource with project name
            resource = Resource.create({
                "service.name": self.config.project_name,
                "service.version": "1.0.0",
            })
            
            # Create tracer provider
            provider = TracerProvider(resource=resource)
            
            # Add Phoenix exporter if configured
            if self.config.export_to_collector:
                try:
                    from phoenix.otel import register
                    
                    register(
                        project_name=self.config.project_name,
                        endpoint=f"{self.config.endpoint}/v1/traces",
                    )
                except ImportError:
                    # Fall back to basic OTLP exporter
                    from opentelemetry.exporter.otlp.proto.http.trace_exporter import (
                        OTLPSpanExporter,
                    )
                    from opentelemetry.sdk.trace.export import BatchSpanProcessor
                    
                    exporter = OTLPSpanExporter(
                        endpoint=f"{self.config.endpoint}/v1/traces",
                    )
                    provider.add_span_processor(BatchSpanProcessor(exporter))
            
            # Set as global provider
            trace.set_tracer_provider(provider)
            
            # Get tracer
            self._tracer = trace.get_tracer(
                self.config.project_name,
                "1.0.0",
            )
            
            # Launch Phoenix app if configured
            if self.config.launch_app:
                self._launch_phoenix_app()
            
            self.__class__._initialized = True
            
            # Register cleanup on exit
            atexit.register(self.shutdown)
            
        except ImportError as e:
            print(f"Warning: Could not initialize Phoenix tracing: {e}")
            print("Install with: pip install arize-phoenix arize-phoenix-otel")
    
    def _launch_phoenix_app(self) -> None:
        """Launch the Phoenix app locally."""
        try:
            import phoenix as px
            self._phoenix_session = px.launch_app()
            print(f"Phoenix app launched at: {self._phoenix_session.url}")
        except Exception as e:
            print(f"Could not launch Phoenix app: {e}")
    
    def shutdown(self) -> None:
        """Shutdown the tracer and flush pending spans."""
        try:
            from opentelemetry import trace
            provider = trace.get_tracer_provider()
            if hasattr(provider, 'force_flush'):
                provider.force_flush()
            if hasattr(provider, 'shutdown'):
                provider.shutdown()
        except Exception:
            pass
    
    def get_tracer(self) -> Tracer | None:
        """Get the underlying OpenTelemetry tracer.
        
        Returns:
            The tracer instance or None if not initialized
        """
        return self._tracer
    
    @contextmanager
    def start_span(
        self,
        name: str,
        attributes: dict[str, Any] | None = None,
        kind: str = "internal",
    ) -> Generator[Span | None, None, None]:
        """Start a new span.
        
        Args:
            name: Span name
            attributes: Span attributes
            kind: Span kind (internal, client, server, producer, consumer)
            
        Yields:
            The created span or None if tracing is disabled
        """
        if not self._tracer or not self.config.enabled:
            yield None
            return
        
        from opentelemetry.trace import SpanKind
        
        kind_map = {
            "internal": SpanKind.INTERNAL,
            "client": SpanKind.CLIENT,
            "server": SpanKind.SERVER,
            "producer": SpanKind.PRODUCER,
            "consumer": SpanKind.CONSUMER,
        }
        
        span_kind = kind_map.get(kind, SpanKind.INTERNAL)
        
        with self._tracer.start_as_current_span(
            name,
            kind=span_kind,
            attributes=attributes or {},
        ) as span:
            yield span
    
    def trace_llm_call(
        self,
        model: str,
        provider: str,
        messages: list[dict[str, str]],
        response: str,
        usage: dict[str, int],
        duration_ms: float,
        **kwargs: Any,
    ) -> None:
        """Record an LLM call trace.
        
        Args:
            model: Model name
            provider: Provider name
            messages: Input messages
            response: Model response
            usage: Token usage info
            duration_ms: Call duration in milliseconds
            **kwargs: Additional attributes
        """
        if not self._tracer or not self.config.enabled:
            return
        
        with self.start_span(
            "llm.call",
            attributes={
                "llm.model": model,
                "llm.provider": provider,
                "llm.input_tokens": usage.get("prompt_tokens", 0),
                "llm.output_tokens": usage.get("completion_tokens", 0),
                "llm.total_tokens": usage.get("total_tokens", 0),
                "duration_ms": duration_ms,
                **kwargs,
            },
            kind="client",
        ) as span:
            if span:
                # Add events for messages
                for i, msg in enumerate(messages):
                    span.add_event(
                        f"input.message.{i}",
                        attributes={
                            "role": msg.get("role", ""),
                            "content": msg.get("content", "")[:1000],  # Truncate
                        },
                    )
                
                span.add_event(
                    "output",
                    attributes={"content": response[:1000]},  # Truncate
                )
    
    def trace_tool_call(
        self,
        tool_name: str,
        agent_name: str,
        arguments: dict[str, Any],
        result: Any,
        duration_ms: float,
        success: bool = True,
        error: str | None = None,
    ) -> None:
        """Record a tool call trace.
        
        Args:
            tool_name: Name of the tool
            agent_name: Agent that called the tool
            arguments: Tool arguments
            result: Tool result
            duration_ms: Call duration
            success: Whether the call succeeded
            error: Error message if failed
        """
        if not self._tracer or not self.config.enabled:
            return
        
        with self.start_span(
            "tool.call",
            attributes={
                "tool.name": tool_name,
                "agent.name": agent_name,
                "tool.success": success,
                "duration_ms": duration_ms,
            },
            kind="internal",
        ) as span:
            if span:
                span.add_event(
                    "tool.input",
                    attributes={"arguments": str(arguments)[:1000]},
                )
                span.add_event(
                    "tool.output",
                    attributes={"result": str(result)[:1000]},
                )
                if error:
                    span.set_attribute("error.message", error)
    
    def trace_agent_run(
        self,
        agent_name: str,
        input_message: str,
        output_message: str,
        duration_ms: float,
        tool_calls: list[dict[str, Any]] | None = None,
        usage: dict[str, int] | None = None,
        cost: float | None = None,
    ) -> None:
        """Record an agent run trace.
        
        Args:
            agent_name: Agent name
            input_message: User input
            output_message: Agent output
            duration_ms: Run duration
            tool_calls: List of tool calls made
            usage: Token usage
            cost: Cost in USD
        """
        if not self._tracer or not self.config.enabled:
            return
        
        attributes: dict[str, Any] = {
            "agent.name": agent_name,
            "duration_ms": duration_ms,
        }
        
        if usage:
            attributes["tokens.input"] = usage.get("prompt_tokens", 0)
            attributes["tokens.output"] = usage.get("completion_tokens", 0)
            attributes["tokens.total"] = usage.get("total_tokens", 0)
        
        if cost is not None:
            attributes["cost.usd"] = cost
        
        if tool_calls:
            attributes["tool_calls.count"] = len(tool_calls)
        
        with self.start_span(
            "agent.run",
            attributes=attributes,
            kind="server",
        ) as span:
            if span:
                span.add_event("input", attributes={"message": input_message[:2000]})
                span.add_event("output", attributes={"message": output_message[:2000]})
                
                if tool_calls:
                    for tc in tool_calls:
                        span.add_event(
                            "tool_call",
                            attributes={
                                "name": tc.get("name", ""),
                                "arguments": str(tc.get("arguments", ""))[:500],
                            },
                        )


def setup_phoenix(
    endpoint: str = "http://localhost:6006",
    project_name: str = "multi-agent-base",
    launch_app: bool = False,
) -> PhoenixTracer:
    """Set up Phoenix tracing for the application.
    
    This is a convenience function to quickly set up Phoenix
    tracing with common defaults.
    
    Args:
        endpoint: Phoenix collector endpoint
        project_name: Project name for grouping traces
        launch_app: Whether to launch Phoenix app locally
        
    Returns:
        Configured PhoenixTracer instance
        
    Example:
        ```python
        tracer = setup_phoenix(
            endpoint="http://localhost:6006",
            project_name="my-agents",
            launch_app=True,
        )
        
        # Traces will now be sent to Phoenix
        ```
    """
    config = PhoenixConfig(
        endpoint=endpoint,
        project_name=project_name,
        launch_app=launch_app,
    )
    
    tracer = PhoenixTracer.get_instance(config)
    tracer.setup()
    
    return tracer


def get_tracer() -> PhoenixTracer:
    """Get the global Phoenix tracer instance.
    
    Returns:
        The global PhoenixTracer instance
    """
    return PhoenixTracer.get_instance()


# Aliases for backward compatibility
PhoenixManager = PhoenixTracer
AgentTracer = PhoenixTracer
