"""
Model Client Factory for the Multi-Agent Base framework.

This module provides factory functions to create LLM clients
for different providers (Ollama, OpenAI, Anthropic) using
Microsoft Agent Framework.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from multi_agent_base.core.config import ProviderConfig, ProviderType, ResilienceConfig


class BaseModelClient(ABC):
    """Abstract base class for model clients.
    
    All provider-specific clients should inherit from this class.
    """
    
    @abstractmethod
    async def generate(
        self,
        messages: list[dict[str, str]],
        tools: list[dict[str, Any]] | None = None,
        **kwargs: Any,
    ) -> tuple[str, dict[str, int], list[dict[str, Any]]]:
        """Generate a response from the model.
        
        Args:
            messages: List of message dictionaries
            tools: Optional list of tool definitions
            **kwargs: Additional generation parameters
            
        Returns:
            Tuple of (response_content, usage_dict, tool_calls)
        """
        pass
    
    @abstractmethod
    async def stream(
        self,
        messages: list[dict[str, str]],
        tools: list[dict[str, Any]] | None = None,
        **kwargs: Any,
    ):
        """Stream a response from the model.
        
        Args:
            messages: List of message dictionaries
            tools: Optional list of tool definitions
            **kwargs: Additional generation parameters
            
        Yields:
            Chunks of the response
        """
        pass


class OllamaClient(BaseModelClient):
    """Ollama model client.
    
    Uses the Ollama API for local model inference.
    
    Attributes:
        model: Model name
        base_url: Ollama API base URL
        options: Additional Ollama options
    """
    
    def __init__(
        self,
        model: str,
        base_url: str = "http://localhost:11434",
        **options: Any,
    ) -> None:
        """Initialize Ollama client.
        
        Args:
            model: Model name (e.g., llama3.2)
            base_url: Ollama API endpoint
            **options: Additional options (temperature, etc.)
        """
        self.model = model
        self.base_url = base_url
        self.options = options
        self._client = None
    
    async def _ensure_client(self) -> None:
        """Ensure the Ollama client is initialized."""
        if self._client is None:
            try:
                import ollama
                self._client = ollama.AsyncClient(host=self.base_url)
            except ImportError:
                raise ImportError(
                    "Ollama package not installed. "
                    "Install with: pip install multi-agent-base[ollama]"
                )
    
    async def generate(
        self,
        messages: list[dict[str, str]],
        tools: list[dict[str, Any]] | None = None,
        **kwargs: Any,
    ) -> tuple[str, dict[str, int], list[dict[str, Any]]]:
        """Generate a response using Ollama.
        
        Args:
            messages: List of messages
            tools: Optional tools (limited support in Ollama)
            **kwargs: Additional parameters
            
        Returns:
            Tuple of (content, usage, tool_calls)
        """
        await self._ensure_client()
        
        options = {**self.options, **kwargs}
        
        # Clean messages for Ollama - remove tool_calls from assistant messages
        # and convert tool messages to a format Ollama understands
        cleaned_messages = []
        for msg in messages:
            clean_msg = {"role": msg["role"], "content": msg.get("content", "")}
            
            # Handle tool results - Ollama doesn't support tool role natively
            if msg["role"] == "tool":
                tool_name = msg.get("name", "tool")
                tool_content = msg.get("content", "")
                clean_msg = {
                    "role": "user",
                    "content": f"[Tool Result from {tool_name}]: {tool_content}"
                }
            
            cleaned_messages.append(clean_msg)
        
        # Build chat parameters
        chat_params = {
            "model": self.model,
            "messages": cleaned_messages,
            "options": options,
        }
        
        # Add tools if provided (for models that support function calling)
        if tools:
            chat_params["tools"] = [
                {"type": "function", "function": t} for t in tools
            ]
        
        response = await self._client.chat(**chat_params)
        
        # Handle response - could be object or dict
        if hasattr(response, 'get'):
            message = response.get("message", {})
            content = message.get("content", "") if isinstance(message, dict) else getattr(message, 'content', "")
            prompt_eval_count = response.get("prompt_eval_count", 0)
            eval_count = response.get("eval_count", 0)
            native_tool_calls = message.get("tool_calls", []) if isinstance(message, dict) else getattr(message, 'tool_calls', None)
        else:
            message = getattr(response, 'message', None)
            content = getattr(message, 'content', "") if message else ""
            prompt_eval_count = getattr(response, 'prompt_eval_count', 0)
            eval_count = getattr(response, 'eval_count', 0)
            native_tool_calls = getattr(message, 'tool_calls', None) if message else None
        
        # Ollama provides some usage stats
        usage = {
            "prompt_tokens": prompt_eval_count,
            "completion_tokens": eval_count,
            "total_tokens": prompt_eval_count + eval_count,
        }
        
        # Tool calls from Ollama (if supported by model)
        tool_calls = native_tool_calls or []
        
        # Some models return tool calls as JSON in content instead of native tool_calls
        # Try to parse JSON tool call from content if no native tool_calls
        if not tool_calls and content and tools:
            tool_calls = self._try_parse_json_tool_call(content)
            if tool_calls:
                # Clear content since it was a tool call
                content = ""
        
        return content, usage, tool_calls
    
    def _try_parse_json_tool_call(self, content: str) -> list[dict[str, Any]]:
        """Try to parse a JSON tool call from content.
        
        Some models like Qwen return tool calls as JSON in content.
        
        Args:
            content: The response content
            
        Returns:
            List of parsed tool calls or empty list
        """
        import json
        import re
        
        content = content.strip()
        
        # Try to find JSON in the content
        # Pattern 1: {"name": "...", "arguments": {...}}
        try:
            if content.startswith("{") and "name" in content:
                data = json.loads(content)
                if "name" in data:
                    return [{
                        "id": f"call_{hash(content) % 10000}",
                        "name": data.get("name"),
                        "arguments": json.dumps(data.get("arguments", {})),
                    }]
        except json.JSONDecodeError:
            pass
        
        # Pattern 2: Look for JSON in markdown code blocks
        json_match = re.search(r'```(?:json)?\s*(\{.*?\})\s*```', content, re.DOTALL)
        if json_match:
            try:
                data = json.loads(json_match.group(1))
                if "name" in data:
                    return [{
                        "id": f"call_{hash(content) % 10000}",
                        "name": data.get("name"),
                        "arguments": json.dumps(data.get("arguments", {})),
                    }]
            except json.JSONDecodeError:
                pass
        
        return []
    
    async def stream(
        self,
        messages: list[dict[str, str]],
        tools: list[dict[str, Any]] | None = None,
        **kwargs: Any,
    ):
        """Stream a response using Ollama.
        
        Args:
            messages: List of messages
            tools: Optional tools
            **kwargs: Additional parameters
            
        Yields:
            Response chunks
        """
        await self._ensure_client()
        
        options = {**self.options, **kwargs}
        
        async for chunk in await self._client.chat(
            model=self.model,
            messages=messages,
            options=options,
            stream=True,
        ):
            yield chunk.get("message", {}).get("content", "")


class OpenAIClient(BaseModelClient):
    """OpenAI model client.
    
    Uses the OpenAI API for model inference.
    
    Attributes:
        model: Model name
        api_key: OpenAI API key
        base_url: Optional custom base URL
    """
    
    def __init__(
        self,
        model: str,
        api_key: str,
        base_url: str | None = None,
        **options: Any,
    ) -> None:
        """Initialize OpenAI client.
        
        Args:
            model: Model name (e.g., gpt-4o-mini)
            api_key: OpenAI API key
            base_url: Optional custom base URL
            **options: Additional options
        """
        self.model = model
        self.api_key = api_key
        self.base_url = base_url
        self.options = options
        self._client = None
    
    async def _ensure_client(self) -> None:
        """Ensure the OpenAI client is initialized."""
        if self._client is None:
            try:
                from openai import AsyncOpenAI
                self._client = AsyncOpenAI(
                    api_key=self.api_key,
                    base_url=self.base_url,
                )
            except ImportError:
                raise ImportError(
                    "OpenAI package not installed. "
                    "Install with: pip install multi-agent-base[openai]"
                )
    
    async def generate(
        self,
        messages: list[dict[str, str]],
        tools: list[dict[str, Any]] | None = None,
        **kwargs: Any,
    ) -> tuple[str, dict[str, int], list[dict[str, Any]]]:
        """Generate a response using OpenAI.
        
        Args:
            messages: List of messages
            tools: Optional tools for function calling
            **kwargs: Additional parameters
            
        Returns:
            Tuple of (content, usage, tool_calls)
        """
        await self._ensure_client()
        
        params = {
            "model": self.model,
            "messages": messages,
            **self.options,
            **kwargs,
        }
        
        if tools:
            params["tools"] = [
                {"type": "function", "function": t} for t in tools
            ]
        
        response = await self._client.chat.completions.create(**params)
        
        message = response.choices[0].message
        content = message.content or ""
        
        usage = {
            "prompt_tokens": response.usage.prompt_tokens,
            "completion_tokens": response.usage.completion_tokens,
            "total_tokens": response.usage.total_tokens,
        }
        
        tool_calls = []
        if message.tool_calls:
            for tc in message.tool_calls:
                tool_calls.append({
                    "id": tc.id,
                    "name": tc.function.name,
                    "arguments": tc.function.arguments,
                })
        
        return content, usage, tool_calls
    
    async def stream(
        self,
        messages: list[dict[str, str]],
        tools: list[dict[str, Any]] | None = None,
        **kwargs: Any,
    ):
        """Stream a response using OpenAI.
        
        Args:
            messages: List of messages
            tools: Optional tools
            **kwargs: Additional parameters
            
        Yields:
            Response chunks
        """
        await self._ensure_client()
        
        params = {
            "model": self.model,
            "messages": messages,
            "stream": True,
            **self.options,
            **kwargs,
        }
        
        if tools:
            params["tools"] = [
                {"type": "function", "function": t} for t in tools
            ]
        
        async for chunk in await self._client.chat.completions.create(**params):
            if chunk.choices and chunk.choices[0].delta.content:
                yield chunk.choices[0].delta.content


class AnthropicClient(BaseModelClient):
    """Anthropic model client.
    
    Uses the Anthropic API for Claude model inference.
    
    Attributes:
        model: Model name
        api_key: Anthropic API key
    """
    
    def __init__(
        self,
        model: str,
        api_key: str,
        **options: Any,
    ) -> None:
        """Initialize Anthropic client.
        
        Args:
            model: Model name (e.g., claude-3-5-sonnet-20241022)
            api_key: Anthropic API key
            **options: Additional options
        """
        self.model = model
        self.api_key = api_key
        self.options = options
        self._client = None
    
    async def _ensure_client(self) -> None:
        """Ensure the Anthropic client is initialized."""
        if self._client is None:
            try:
                from anthropic import AsyncAnthropic
                self._client = AsyncAnthropic(api_key=self.api_key)
            except ImportError:
                raise ImportError(
                    "Anthropic package not installed. "
                    "Install with: pip install multi-agent-base[anthropic]"
                )
    
    async def generate(
        self,
        messages: list[dict[str, str]],
        tools: list[dict[str, Any]] | None = None,
        **kwargs: Any,
    ) -> tuple[str, dict[str, int], list[dict[str, Any]]]:
        """Generate a response using Anthropic.
        
        Args:
            messages: List of messages
            tools: Optional tools
            **kwargs: Additional parameters
            
        Returns:
            Tuple of (content, usage, tool_calls)
        """
        await self._ensure_client()
        
        # Extract system message if present
        system = ""
        chat_messages = []
        for msg in messages:
            if msg["role"] == "system":
                system = msg["content"]
            else:
                chat_messages.append(msg)
        
        params = {
            "model": self.model,
            "messages": chat_messages,
            "max_tokens": kwargs.pop("max_tokens", self.options.get("max_tokens", 4096)),
            **self.options,
            **kwargs,
        }
        
        if system:
            params["system"] = system
        
        if tools:
            params["tools"] = [
                {
                    "name": t["name"],
                    "description": t.get("description", ""),
                    "input_schema": t.get("parameters", {}),
                }
                for t in tools
            ]
        
        response = await self._client.messages.create(**params)
        
        content = ""
        tool_calls = []
        
        for block in response.content:
            if block.type == "text":
                content += block.text
            elif block.type == "tool_use":
                tool_calls.append({
                    "id": block.id,
                    "name": block.name,
                    "arguments": block.input,
                })
        
        usage = {
            "prompt_tokens": response.usage.input_tokens,
            "completion_tokens": response.usage.output_tokens,
            "total_tokens": response.usage.input_tokens + response.usage.output_tokens,
        }
        
        return content, usage, tool_calls
    
    async def stream(
        self,
        messages: list[dict[str, str]],
        tools: list[dict[str, Any]] | None = None,
        **kwargs: Any,
    ):
        """Stream a response using Anthropic.
        
        Args:
            messages: List of messages
            tools: Optional tools
            **kwargs: Additional parameters
            
        Yields:
            Response chunks
        """
        await self._ensure_client()
        
        # Extract system message
        system = ""
        chat_messages = []
        for msg in messages:
            if msg["role"] == "system":
                system = msg["content"]
            else:
                chat_messages.append(msg)
        
        params = {
            "model": self.model,
            "messages": chat_messages,
            "max_tokens": kwargs.pop("max_tokens", self.options.get("max_tokens", 4096)),
            "stream": True,
            **self.options,
            **kwargs,
        }
        
        if system:
            params["system"] = system
        
        async with self._client.messages.stream(**params) as stream:
            async for text in stream.text_stream:
                yield text


class ResilientModelClient(BaseModelClient):
    """Model client wrapper with resilience patterns.
    
    Wraps any BaseModelClient with retry, circuit breaker, timeout,
    and fallback capabilities.
    
    Attributes:
        client: The underlying model client
        config: Resilience configuration
    """
    
    def __init__(
        self,
        client: BaseModelClient,
        config: "ResilienceConfig",
    ) -> None:
        """Initialize resilient client wrapper.
        
        Args:
            client: Underlying model client to wrap
            config: Resilience configuration
        """
        self.client = client
        self.config = config
        self._wrapper = None
    
    def _ensure_wrapper(self) -> None:
        """Lazily initialize the resilience wrapper."""
        if self._wrapper is None:
            from multi_agent_base.resilience.wrapper import ResilientWrapper
            from multi_agent_base.resilience.policy import (
                ResiliencePolicy,
                RetryConfig,
                TimeoutConfig,
            )
            
            # Build retry config
            retry_config = None
            if self.config.retry_enabled:
                from multi_agent_base.resilience.retry import BackoffStrategy
                
                strategy_map = {
                    "constant": BackoffStrategy.CONSTANT,
                    "linear": BackoffStrategy.LINEAR,
                    "exponential": BackoffStrategy.EXPONENTIAL,
                    "exponential_jitter": BackoffStrategy.EXPONENTIAL_JITTER,
                }
                
                retry_config = RetryConfig(
                    max_attempts=self.config.max_retries,
                    base_delay=self.config.retry_delay,
                    strategy=strategy_map.get(
                        self.config.backoff_strategy,
                        BackoffStrategy.EXPONENTIAL_JITTER
                    ),
                )
            
            # Build timeout config
            timeout_config = TimeoutConfig(
                timeout_seconds=self.config.timeout_seconds,
            )
            
            # Build policy
            policy = ResiliencePolicy(
                retry=retry_config,
                timeout=timeout_config,
                circuit_breaker_enabled=self.config.circuit_breaker_enabled,
                failure_threshold=self.config.failure_threshold,
                reset_timeout=self.config.reset_timeout,
            )
            
            self._wrapper = ResilientWrapper(policy=policy)
    
    async def generate(
        self,
        messages: list[dict[str, str]],
        tools: list[dict[str, Any]] | None = None,
        **kwargs: Any,
    ) -> tuple[str, dict[str, int], list[dict[str, Any]]]:
        """Generate a response with resilience.
        
        Args:
            messages: List of messages
            tools: Optional tools
            **kwargs: Additional parameters
            
        Returns:
            Tuple of (content, usage, tool_calls)
        """
        self._ensure_wrapper()
        
        async def _generate():
            return await self.client.generate(messages, tools, **kwargs)
        
        return await self._wrapper.execute(_generate)
    
    async def stream(
        self,
        messages: list[dict[str, str]],
        tools: list[dict[str, Any]] | None = None,
        **kwargs: Any,
    ):
        """Stream a response with resilience.
        
        Note: Streaming is passed through without retry (cannot retry mid-stream).
        
        Args:
            messages: List of messages
            tools: Optional tools
            **kwargs: Additional parameters
            
        Yields:
            Response chunks
        """
        # Streaming cannot be easily retried, pass through
        async for chunk in self.client.stream(messages, tools, **kwargs):
            yield chunk


class ModelClientFactory:
    """Factory for creating model clients based on configuration.
    
    Example:
        ```python
        factory = ModelClientFactory()
        
        client = factory.create(ProviderConfig(
            provider=ProviderType.OPENAI,
            model="gpt-4o-mini",
            api_key="sk-...",
        ))
        
        content, usage, tools = await client.generate([
            {"role": "user", "content": "Hello!"}
        ])
        ```
    """
    
    _clients: dict[str, type[BaseModelClient]] = {
        "ollama": OllamaClient,
        "openai": OpenAIClient,
        "anthropic": AnthropicClient,
    }
    
    @classmethod
    def register(cls, provider_name: str, client_class: type[BaseModelClient]) -> None:
        """Register a custom client class.
        
        Args:
            provider_name: Provider identifier
            client_class: Client class to register
        """
        cls._clients[provider_name] = client_class
    
    @classmethod
    def create(
        cls,
        config: ProviderConfig,
        resilience_config: "ResilienceConfig | None" = None,
    ) -> BaseModelClient:
        """Create a model client from configuration.
        
        Args:
            config: Provider configuration
            resilience_config: Optional resilience configuration for retry/circuit breaker
            
        Returns:
            Configured model client (optionally wrapped with resilience)
            
        Raises:
            ValueError: If provider is not supported
        """
        provider = str(config.provider).lower()
        
        if provider not in cls._clients:
            raise ValueError(
                f"Unsupported provider: {provider}. "
                f"Available: {list(cls._clients.keys())}"
            )
        
        client_class = cls._clients[provider]
        
        # Build kwargs based on provider
        kwargs: dict[str, Any] = {"model": config.model}
        
        if config.api_key:
            kwargs["api_key"] = config.api_key
        
        if config.base_url:
            kwargs["base_url"] = config.base_url
        
        # Add extra params
        if config.temperature is not None:
            kwargs["temperature"] = config.temperature
        
        if config.max_tokens:
            kwargs["max_tokens"] = config.max_tokens
        
        kwargs.update(config.extra_params)
        
        client = client_class(**kwargs)
        
        # Wrap with resilience if config provided
        if resilience_config and resilience_config.enabled:
            client = ResilientModelClient(client, resilience_config)
        
        return client
    
    @classmethod
    def create_from_env(cls, with_resilience: bool = False) -> BaseModelClient:
        """Create a model client from environment variables.
        
        Args:
            with_resilience: Whether to wrap with resilience patterns
            
        Returns:
            Configured model client
        """
        from multi_agent_base.core.config import ProviderConfig, ResilienceConfig
        
        config = ProviderConfig()  # Uses defaults and env vars
        resilience_config = ResilienceConfig() if with_resilience else None
        return cls.create(config, resilience_config)
