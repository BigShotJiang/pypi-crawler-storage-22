"""
Pricing information and cost calculation for LLM providers.

This module provides pricing data for different models and
utilities to calculate costs based on token usage.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass
class ModelPricing:
    """Pricing information for a model.
    
    Prices are in USD per 1 million tokens.
    
    Attributes:
        input_price: Price per 1M input tokens
        output_price: Price per 1M output tokens
        context_window: Maximum context window size
        notes: Additional pricing notes
    """
    
    input_price: float  # USD per 1M tokens
    output_price: float  # USD per 1M tokens
    context_window: int = 0
    notes: str = ""
    
    def calculate(self, input_tokens: int, output_tokens: int) -> float:
        """Calculate cost for given token usage.
        
        Args:
            input_tokens: Number of input tokens
            output_tokens: Number of output tokens
            
        Returns:
            Total cost in USD
        """
        input_cost = (input_tokens / 1_000_000) * self.input_price
        output_cost = (output_tokens / 1_000_000) * self.output_price
        return input_cost + output_cost


# OpenAI Pricing (as of 2024)
OPENAI_PRICING: dict[str, ModelPricing] = {
    # GPT-4o series
    "gpt-4o": ModelPricing(
        input_price=2.50,
        output_price=10.00,
        context_window=128_000,
    ),
    "gpt-4o-2024-11-20": ModelPricing(
        input_price=2.50,
        output_price=10.00,
        context_window=128_000,
    ),
    "gpt-4o-mini": ModelPricing(
        input_price=0.15,
        output_price=0.60,
        context_window=128_000,
    ),
    "gpt-4o-mini-2024-07-18": ModelPricing(
        input_price=0.15,
        output_price=0.60,
        context_window=128_000,
    ),
    
    # GPT-4 Turbo
    "gpt-4-turbo": ModelPricing(
        input_price=10.00,
        output_price=30.00,
        context_window=128_000,
    ),
    "gpt-4-turbo-2024-04-09": ModelPricing(
        input_price=10.00,
        output_price=30.00,
        context_window=128_000,
    ),
    
    # GPT-4
    "gpt-4": ModelPricing(
        input_price=30.00,
        output_price=60.00,
        context_window=8_192,
    ),
    "gpt-4-32k": ModelPricing(
        input_price=60.00,
        output_price=120.00,
        context_window=32_768,
    ),
    
    # GPT-3.5
    "gpt-3.5-turbo": ModelPricing(
        input_price=0.50,
        output_price=1.50,
        context_window=16_385,
    ),
    "gpt-3.5-turbo-0125": ModelPricing(
        input_price=0.50,
        output_price=1.50,
        context_window=16_385,
    ),
    
    # o1 series (reasoning models)
    "o1": ModelPricing(
        input_price=15.00,
        output_price=60.00,
        context_window=200_000,
    ),
    "o1-preview": ModelPricing(
        input_price=15.00,
        output_price=60.00,
        context_window=128_000,
    ),
    "o1-mini": ModelPricing(
        input_price=3.00,
        output_price=12.00,
        context_window=128_000,
    ),
    "o3-mini": ModelPricing(
        input_price=1.10,
        output_price=4.40,
        context_window=200_000,
    ),
}

# Anthropic Pricing (as of 2024)
ANTHROPIC_PRICING: dict[str, ModelPricing] = {
    # Claude 3.5 series
    "claude-3-5-sonnet-20241022": ModelPricing(
        input_price=3.00,
        output_price=15.00,
        context_window=200_000,
    ),
    "claude-3-5-sonnet-latest": ModelPricing(
        input_price=3.00,
        output_price=15.00,
        context_window=200_000,
    ),
    "claude-3-5-haiku-20241022": ModelPricing(
        input_price=0.80,
        output_price=4.00,
        context_window=200_000,
    ),
    "claude-3-5-haiku-latest": ModelPricing(
        input_price=0.80,
        output_price=4.00,
        context_window=200_000,
    ),
    
    # Claude 3 series
    "claude-3-opus-20240229": ModelPricing(
        input_price=15.00,
        output_price=75.00,
        context_window=200_000,
    ),
    "claude-3-opus-latest": ModelPricing(
        input_price=15.00,
        output_price=75.00,
        context_window=200_000,
    ),
    "claude-3-sonnet-20240229": ModelPricing(
        input_price=3.00,
        output_price=15.00,
        context_window=200_000,
    ),
    "claude-3-haiku-20240307": ModelPricing(
        input_price=0.25,
        output_price=1.25,
        context_window=200_000,
    ),
}

# Ollama Pricing (local, typically free)
OLLAMA_PRICING: dict[str, ModelPricing] = {
    # Free for local inference
    "llama3.2": ModelPricing(input_price=0.0, output_price=0.0),
    "llama3.2:1b": ModelPricing(input_price=0.0, output_price=0.0),
    "llama3.2:3b": ModelPricing(input_price=0.0, output_price=0.0),
    "llama3.1": ModelPricing(input_price=0.0, output_price=0.0),
    "llama3.1:8b": ModelPricing(input_price=0.0, output_price=0.0),
    "llama3.1:70b": ModelPricing(input_price=0.0, output_price=0.0),
    "llama3": ModelPricing(input_price=0.0, output_price=0.0),
    "mistral": ModelPricing(input_price=0.0, output_price=0.0),
    "mixtral": ModelPricing(input_price=0.0, output_price=0.0),
    "phi3": ModelPricing(input_price=0.0, output_price=0.0),
    "phi3:mini": ModelPricing(input_price=0.0, output_price=0.0),
    "phi3:medium": ModelPricing(input_price=0.0, output_price=0.0),
    "codellama": ModelPricing(input_price=0.0, output_price=0.0),
    "deepseek-coder": ModelPricing(input_price=0.0, output_price=0.0),
    "qwen2.5": ModelPricing(input_price=0.0, output_price=0.0),
    "qwen2.5-coder": ModelPricing(input_price=0.0, output_price=0.0),
}

# Default pricing for unknown models
DEFAULT_PRICING = ModelPricing(
    input_price=1.00,
    output_price=3.00,
    notes="Default pricing for unknown model",
)


class PricingCalculator:
    """Calculator for LLM usage costs.
    
    Provides methods to look up pricing and calculate costs
    for different providers and models.
    
    Example:
        ```python
        calc = PricingCalculator()
        
        cost = calc.calculate(
            provider="openai",
            model="gpt-4o-mini",
            input_tokens=1000,
            output_tokens=500,
        )
        print(f"Cost: ${cost:.6f}")
        ```
    """
    
    _pricing_data: dict[str, dict[str, ModelPricing]] = {
        "openai": OPENAI_PRICING,
        "anthropic": ANTHROPIC_PRICING,
        "ollama": OLLAMA_PRICING,
    }
    
    _custom_pricing: dict[str, dict[str, ModelPricing]] = {}
    
    @classmethod
    def register_pricing(
        cls,
        provider: str,
        model: str,
        pricing: ModelPricing,
    ) -> None:
        """Register custom pricing for a model.
        
        Args:
            provider: Provider name
            model: Model name
            pricing: Pricing information
        """
        if provider not in cls._custom_pricing:
            cls._custom_pricing[provider] = {}
        cls._custom_pricing[provider][model] = pricing
    
    @classmethod
    def get_pricing(
        cls,
        provider: str,
        model: str,
    ) -> ModelPricing:
        """Get pricing for a specific model.
        
        Args:
            provider: Provider name (openai, anthropic, ollama)
            model: Model name
            
        Returns:
            ModelPricing for the model
        """
        provider = provider.lower()
        
        # Check custom pricing first
        if provider in cls._custom_pricing:
            if model in cls._custom_pricing[provider]:
                return cls._custom_pricing[provider][model]
        
        # Check built-in pricing
        if provider in cls._pricing_data:
            provider_pricing = cls._pricing_data[provider]
            
            # Exact match
            if model in provider_pricing:
                return provider_pricing[model]
            
            # Try to match by prefix (for versioned models)
            for known_model, pricing in provider_pricing.items():
                if model.startswith(known_model) or known_model.startswith(model):
                    return pricing
        
        # Return default pricing
        return DEFAULT_PRICING
    
    @classmethod
    def calculate(
        cls,
        provider: str,
        model: str,
        input_tokens: int,
        output_tokens: int,
    ) -> float:
        """Calculate cost for token usage.
        
        Args:
            provider: Provider name
            model: Model name
            input_tokens: Number of input tokens
            output_tokens: Number of output tokens
            
        Returns:
            Cost in USD
        """
        pricing = cls.get_pricing(provider, model)
        return pricing.calculate(input_tokens, output_tokens)
    
    @classmethod
    def get_all_pricing(cls) -> dict[str, dict[str, ModelPricing]]:
        """Get all registered pricing data.
        
        Returns:
            Dictionary of provider -> model -> pricing
        """
        result: dict[str, dict[str, ModelPricing]] = {}
        
        # Add built-in pricing
        for provider, models in cls._pricing_data.items():
            result[provider] = models.copy()
        
        # Merge custom pricing
        for provider, models in cls._custom_pricing.items():
            if provider not in result:
                result[provider] = {}
            result[provider].update(models)
        
        return result
    
    @classmethod
    def list_models(cls, provider: str) -> list[str]:
        """List available models for a provider.
        
        Args:
            provider: Provider name
            
        Returns:
            List of model names
        """
        provider = provider.lower()
        models = set()
        
        if provider in cls._pricing_data:
            models.update(cls._pricing_data[provider].keys())
        
        if provider in cls._custom_pricing:
            models.update(cls._custom_pricing[provider].keys())
        
        return sorted(models)
    
    @classmethod
    def estimate_cost(
        cls,
        provider: str,
        model: str,
        prompt_chars: int,
        expected_output_chars: int,
        chars_per_token: float = 4.0,
    ) -> float:
        """Estimate cost based on character counts.
        
        This is a rough estimate as tokenization varies.
        
        Args:
            provider: Provider name
            model: Model name
            prompt_chars: Prompt character count
            expected_output_chars: Expected output character count
            chars_per_token: Average characters per token (default 4)
            
        Returns:
            Estimated cost in USD
        """
        input_tokens = int(prompt_chars / chars_per_token)
        output_tokens = int(expected_output_chars / chars_per_token)
        return cls.calculate(provider, model, input_tokens, output_tokens)


# Convenience alias for all pricing data
MODEL_PRICING: dict[str, dict[str, ModelPricing]] = {
    "openai": OPENAI_PRICING,
    "anthropic": ANTHROPIC_PRICING,
    "ollama": OLLAMA_PRICING,
}


def calculate_cost(
    provider: str,
    model: str,
    input_tokens: int,
    output_tokens: int,
) -> float:
    """Convenience function to calculate cost.
    
    Args:
        provider: LLM provider name
        model: Model name
        input_tokens: Number of input tokens
        output_tokens: Number of output tokens
        
    Returns:
        Total cost in USD
    """
    return PricingCalculator.calculate(provider, model, input_tokens, output_tokens)