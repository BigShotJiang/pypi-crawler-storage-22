"""
Rate Limiting Module for Multi-Agent Base.

This module provides rate limiting capabilities:
- Token bucket algorithm
- Sliding window rate limiting
- Per-provider rate limits
- Distributed rate limiting (Redis-backed)
"""

from multi_agent_base.ratelimit.limiter import (
    RateLimiter,
    RateLimitConfig,
    RateLimitExceeded,
    RateLimitResult,
    TokenBucketLimiter,
    SlidingWindowLimiter,
)
from multi_agent_base.ratelimit.provider_limits import (
    ProviderRateLimits,
    get_provider_limits,
)
from multi_agent_base.ratelimit.decorators import (
    rate_limit,
    with_rate_limit,
)
from multi_agent_base.ratelimit.redis_limiter import (
    RedisRateLimiter,
    RedisSlidingWindowLimiter,
)

__all__ = [
    # Core
    "RateLimiter",
    "RateLimitConfig",
    "RateLimitExceeded",
    "RateLimitResult",
    # Implementations
    "TokenBucketLimiter",
    "SlidingWindowLimiter",
    # Redis implementations
    "RedisRateLimiter",
    "RedisSlidingWindowLimiter",
    # Provider limits
    "ProviderRateLimits",
    "get_provider_limits",
    # Decorators
    "rate_limit",
    "with_rate_limit",
]
