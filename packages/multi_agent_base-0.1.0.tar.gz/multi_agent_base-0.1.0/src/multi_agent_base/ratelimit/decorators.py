"""
Rate limiting decorators.

Provides decorators for easily adding rate limiting to functions.
"""

from __future__ import annotations

import functools
from typing import Any, Callable, TypeVar

from multi_agent_base.ratelimit.limiter import (
    RateLimiter,
    RateLimitConfig,
    TokenBucketLimiter,
)

F = TypeVar("F", bound=Callable[..., Any])


def rate_limit(
    requests_per_minute: int = 60,
    requests_per_second: float | None = None,
    burst_multiplier: float = 1.5,
    wait_on_limit: bool = True,
    max_wait_seconds: float = 60.0,
) -> Callable[[F], F]:
    """Decorator to add rate limiting to async functions.
    
    Creates a token bucket rate limiter for the decorated function.
    
    Args:
        requests_per_minute: Maximum requests per minute
        requests_per_second: Maximum requests per second (overrides rpm)
        burst_multiplier: Allow burst up to this multiplier
        wait_on_limit: Whether to wait when limit is hit
        max_wait_seconds: Maximum seconds to wait
        
    Returns:
        Decorator function
        
    Example:
        ```python
        @rate_limit(requests_per_minute=60)
        async def call_api():
            return await api.request()
        ```
    """
    config = RateLimitConfig(
        requests_per_minute=requests_per_minute,
        requests_per_second=requests_per_second,
        burst_multiplier=burst_multiplier,
        wait_on_limit=wait_on_limit,
        max_wait_seconds=max_wait_seconds,
    )
    limiter = TokenBucketLimiter(config)
    
    def decorator(func: F) -> F:
        @functools.wraps(func)
        async def wrapper(*args: Any, **kwargs: Any) -> Any:
            await limiter.acquire()
            return await func(*args, **kwargs)
        
        # Attach limiter for inspection
        wrapper._rate_limiter = limiter  # type: ignore
        
        return wrapper  # type: ignore
    
    return decorator


def with_rate_limit(limiter: RateLimiter) -> Callable[[F], F]:
    """Decorator to use an existing rate limiter.
    
    Allows sharing a rate limiter across multiple functions.
    
    Args:
        limiter: Rate limiter instance to use
        
    Returns:
        Decorator function
        
    Example:
        ```python
        shared_limiter = TokenBucketLimiter(
            RateLimitConfig(requests_per_minute=100)
        )
        
        @with_rate_limit(shared_limiter)
        async def endpoint_a():
            pass
            
        @with_rate_limit(shared_limiter)
        async def endpoint_b():
            pass
        ```
    """
    def decorator(func: F) -> F:
        @functools.wraps(func)
        async def wrapper(*args: Any, **kwargs: Any) -> Any:
            await limiter.acquire()
            return await func(*args, **kwargs)
        
        wrapper._rate_limiter = limiter  # type: ignore
        
        return wrapper  # type: ignore
    
    return decorator


class RateLimitedClient:
    """Mixin class to add rate limiting to clients.
    
    Example:
        ```python
        class MyClient(RateLimitedClient):
            def __init__(self):
                super().__init__(
                    RateLimitConfig(requests_per_minute=60)
                )
            
            async def request(self):
                async with self.rate_limited():
                    return await self._do_request()
        ```
    """
    
    _rate_limiter: TokenBucketLimiter | None
    
    def __init__(
        self,
        rate_limit_config: RateLimitConfig | None = None,
        **kwargs: Any,
    ) -> None:
        """Initialize rate limited client.
        
        Args:
            rate_limit_config: Rate limit configuration
            **kwargs: Additional arguments for parent class
        """
        super().__init__(**kwargs)
        
        if rate_limit_config:
            self._rate_limiter = TokenBucketLimiter(rate_limit_config)
        else:
            self._rate_limiter = None
    
    async def rate_limited(self, tokens: int = 1) -> "RateLimitContext":
        """Context manager for rate limited operations.
        
        Args:
            tokens: Number of tokens to acquire
            
        Returns:
            Async context manager
        """
        return RateLimitContext(self._rate_limiter, tokens)


class RateLimitContext:
    """Async context manager for rate limiting."""
    
    def __init__(
        self,
        limiter: RateLimiter | None,
        tokens: int = 1,
    ) -> None:
        self.limiter = limiter
        self.tokens = tokens
    
    async def __aenter__(self) -> None:
        if self.limiter:
            await self.limiter.acquire(self.tokens)
    
    async def __aexit__(self, *args: Any) -> None:
        pass  # Don't release on exit
