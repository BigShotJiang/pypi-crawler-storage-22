"""
Rate Limiter implementations.

Provides token bucket and sliding window algorithms for rate limiting.
"""

from __future__ import annotations

import asyncio
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field


class RateLimitExceeded(Exception):
    """Exception raised when rate limit is exceeded.
    
    Attributes:
        limit: The limit that was exceeded
        retry_after: Seconds until the limit resets
    """
    
    def __init__(
        self,
        message: str = "Rate limit exceeded",
        limit: int | None = None,
        retry_after: float | None = None,
    ) -> None:
        super().__init__(message)
        self.limit = limit
        self.retry_after = retry_after


@dataclass
class RateLimitResult:
    """Result of a rate limit check/acquire.
    
    Attributes:
        allowed: Whether the request was allowed
        remaining_tokens: Remaining tokens in the bucket
        remaining_requests: Remaining requests in the window
        retry_after: Seconds to wait before retrying (if not allowed)
    """
    
    allowed: bool
    remaining_tokens: float = 0.0
    remaining_requests: int = 0
    retry_after: float | None = None


class RateLimitAlgorithm(str, Enum):
    """Rate limiting algorithms."""
    
    TOKEN_BUCKET = "token_bucket"
    SLIDING_WINDOW = "sliding_window"
    FIXED_WINDOW = "fixed_window"
    LEAKY_BUCKET = "leaky_bucket"


class RateLimitConfig(BaseModel):
    """Configuration for rate limiting.
    
    Attributes:
        requests_per_minute: Maximum requests per minute
        requests_per_second: Maximum requests per second (overrides rpm if set)
        tokens_per_minute: Maximum tokens per minute (for LLM APIs)
        burst_multiplier: Allow burst up to this multiplier of the base rate
        algorithm: Rate limiting algorithm
        wait_on_limit: Whether to wait when limit is hit (vs raise exception)
        max_wait_seconds: Maximum seconds to wait if wait_on_limit is True
    """
    
    requests_per_minute: int = Field(
        default=60,
        gt=0,
        description="Maximum requests per minute"
    )
    requests_per_second: float | None = Field(
        default=None,
        gt=0,
        description="Maximum requests per second"
    )
    tokens_per_minute: int | None = Field(
        default=None,
        gt=0,
        description="Maximum tokens per minute"
    )
    burst_multiplier: float = Field(
        default=1.5,
        ge=1.0,
        description="Burst multiplier for token bucket"
    )
    algorithm: RateLimitAlgorithm = Field(
        default=RateLimitAlgorithm.TOKEN_BUCKET,
        description="Rate limiting algorithm"
    )
    wait_on_limit: bool = Field(
        default=True,
        description="Wait when limit is hit"
    )
    max_wait_seconds: float = Field(
        default=60.0,
        gt=0,
        description="Maximum wait time"
    )

    model_config = {"use_enum_values": True}


class RateLimiter(ABC):
    """Abstract base class for rate limiters.
    
    Subclasses must implement acquire() and release() methods.
    """
    
    def __init__(self, config: RateLimitConfig | None = None) -> None:
        """Initialize rate limiter.
        
        Args:
            config: Rate limit configuration
        """
        self.config = config or RateLimitConfig()
    
    @abstractmethod
    async def acquire(self, tokens: int = 1) -> bool:
        """Acquire tokens from the rate limiter.
        
        Args:
            tokens: Number of tokens to acquire
            
        Returns:
            True if tokens were acquired, False otherwise
            
        Raises:
            RateLimitExceeded: If limit exceeded and not waiting
        """
        pass
    
    @abstractmethod
    async def release(self, tokens: int = 1) -> None:
        """Release tokens back to the limiter (for leaky bucket).
        
        Args:
            tokens: Number of tokens to release
        """
        pass
    
    @abstractmethod
    def reset(self) -> None:
        """Reset the rate limiter state."""
        pass
    
    @abstractmethod
    def get_remaining(self) -> int:
        """Get remaining tokens/requests.
        
        Returns:
            Number of remaining tokens
        """
        pass
    
    @abstractmethod
    def get_retry_after(self) -> float:
        """Get seconds until tokens are available.
        
        Returns:
            Seconds until retry is allowed
        """
        pass


@dataclass
class TokenBucketState:
    """State for token bucket algorithm."""
    
    tokens: float
    last_update: float
    max_tokens: float
    refill_rate: float  # tokens per second


class TokenBucketLimiter(RateLimiter):
    """Token bucket rate limiter.
    
    Allows bursting up to max_tokens, then limits to refill_rate.
    
    Example:
        ```python
        limiter = TokenBucketLimiter(
            config=RateLimitConfig(
                requests_per_minute=60,
                burst_multiplier=2.0,
            )
        )
        
        if await limiter.acquire():
            # Proceed with request
            pass
        ```
    """
    
    def __init__(self, config: RateLimitConfig) -> None:
        """Initialize token bucket limiter.
        
        Args:
            config: Rate limit configuration
        """
        self.config = config
        
        # Calculate rates
        if config.requests_per_second:
            self._refill_rate = config.requests_per_second
        else:
            self._refill_rate = config.requests_per_minute / 60.0
        
        self._max_tokens = self._refill_rate * config.burst_multiplier
        
        self._state = TokenBucketState(
            tokens=self._max_tokens,
            last_update=time.monotonic(),
            max_tokens=self._max_tokens,
            refill_rate=self._refill_rate,
        )
        self._lock = asyncio.Lock()
    
    def _refill(self) -> None:
        """Refill tokens based on elapsed time."""
        now = time.monotonic()
        elapsed = now - self._state.last_update
        
        # Add tokens based on elapsed time
        new_tokens = self._state.tokens + (elapsed * self._state.refill_rate)
        self._state.tokens = min(new_tokens, self._state.max_tokens)
        self._state.last_update = now
    
    async def acquire(self, tokens: int = 1) -> bool:
        """Acquire tokens from the bucket.
        
        Args:
            tokens: Number of tokens to acquire
            
        Returns:
            True if acquired successfully
            
        Raises:
            RateLimitExceeded: If limit exceeded and wait_on_limit is False
        """
        async with self._lock:
            self._refill()
            
            if self._state.tokens >= tokens:
                self._state.tokens -= tokens
                return True
            
            if not self.config.wait_on_limit:
                raise RateLimitExceeded(
                    f"Rate limit exceeded. Retry after {self.get_retry_after():.2f}s",
                    limit=int(self._max_tokens),
                    retry_after=self.get_retry_after(),
                )
            
            # Calculate wait time
            needed = tokens - self._state.tokens
            wait_time = needed / self._state.refill_rate
            
            if wait_time > self.config.max_wait_seconds:
                raise RateLimitExceeded(
                    f"Wait time {wait_time:.2f}s exceeds max {self.config.max_wait_seconds}s",
                    limit=int(self._max_tokens),
                    retry_after=wait_time,
                )
        
        # Wait outside lock
        await asyncio.sleep(wait_time)
        
        async with self._lock:
            self._refill()
            self._state.tokens -= tokens
            return True
    
    async def release(self, tokens: int = 1) -> None:
        """Release tokens (no-op for token bucket)."""
        pass  # Token bucket doesn't support release
    
    def reset(self) -> None:
        """Reset the bucket to full."""
        self._state.tokens = self._max_tokens
        self._state.last_update = time.monotonic()
    
    def get_remaining(self) -> int:
        """Get remaining tokens."""
        self._refill()
        return int(self._state.tokens)
    
    def get_retry_after(self) -> float:
        """Get seconds until at least one token is available."""
        self._refill()
        if self._state.tokens >= 1:
            return 0.0
        needed = 1 - self._state.tokens
        return needed / self._state.refill_rate


@dataclass
class WindowEntry:
    """Entry in sliding window."""
    
    timestamp: float
    tokens: int = 1


class SlidingWindowLimiter(RateLimiter):
    """Sliding window rate limiter.
    
    Tracks requests in a sliding time window for more accurate limiting.
    
    Example:
        ```python
        limiter = SlidingWindowLimiter(
            config=RateLimitConfig(
                requests_per_minute=100,
                wait_on_limit=True,
            )
        )
        
        async with limiter:
            # Request is rate limited
            await make_request()
        ```
    """
    
    def __init__(self, config: RateLimitConfig) -> None:
        """Initialize sliding window limiter.
        
        Args:
            config: Rate limit configuration
        """
        self.config = config
        
        # Determine window size and limit
        if config.requests_per_second:
            self._window_seconds = 1.0
            self._limit = int(config.requests_per_second)
        else:
            self._window_seconds = 60.0
            self._limit = config.requests_per_minute
        
        self._entries: list[WindowEntry] = []
        self._lock = asyncio.Lock()
    
    def _cleanup(self) -> None:
        """Remove expired entries from window."""
        cutoff = time.monotonic() - self._window_seconds
        self._entries = [e for e in self._entries if e.timestamp > cutoff]
    
    def _current_count(self) -> int:
        """Get current request count in window."""
        self._cleanup()
        return sum(e.tokens for e in self._entries)
    
    async def acquire(self, tokens: int = 1) -> bool:
        """Acquire tokens from the window.
        
        Args:
            tokens: Number of tokens to acquire
            
        Returns:
            True if acquired successfully
            
        Raises:
            RateLimitExceeded: If limit exceeded
        """
        async with self._lock:
            self._cleanup()
            current = self._current_count()
            
            if current + tokens <= self._limit:
                self._entries.append(WindowEntry(
                    timestamp=time.monotonic(),
                    tokens=tokens,
                ))
                return True
            
            if not self.config.wait_on_limit:
                raise RateLimitExceeded(
                    f"Rate limit exceeded ({current}/{self._limit})",
                    limit=self._limit,
                    retry_after=self.get_retry_after(),
                )
            
            # Calculate wait time (until oldest entry expires)
            wait_time = self.get_retry_after()
            
            if wait_time > self.config.max_wait_seconds:
                raise RateLimitExceeded(
                    f"Wait time {wait_time:.2f}s exceeds max",
                    limit=self._limit,
                    retry_after=wait_time,
                )
        
        # Wait outside lock
        await asyncio.sleep(wait_time)
        
        # Retry after waiting
        return await self.acquire(tokens)
    
    async def release(self, tokens: int = 1) -> None:
        """Release tokens (removes from window)."""
        async with self._lock:
            # Remove most recent entry
            for i in range(len(self._entries) - 1, -1, -1):
                if self._entries[i].tokens >= tokens:
                    self._entries[i].tokens -= tokens
                    if self._entries[i].tokens == 0:
                        self._entries.pop(i)
                    break
    
    def reset(self) -> None:
        """Clear the window."""
        self._entries.clear()
    
    def get_remaining(self) -> int:
        """Get remaining requests in window."""
        return max(0, self._limit - self._current_count())
    
    def get_retry_after(self) -> float:
        """Get seconds until oldest entry expires."""
        if not self._entries:
            return 0.0
        
        oldest = min(e.timestamp for e in self._entries)
        expire_time = oldest + self._window_seconds
        return max(0.0, expire_time - time.monotonic())
    
    async def __aenter__(self) -> "SlidingWindowLimiter":
        """Async context manager entry."""
        await self.acquire()
        return self
    
    async def __aexit__(self, *args: Any) -> None:
        """Async context manager exit."""
        pass  # Don't release on exit


class CompositeRateLimiter(RateLimiter):
    """Combines multiple rate limiters.
    
    All limiters must allow the request for it to proceed.
    
    Example:
        ```python
        # Limit both requests/min and tokens/min
        limiter = CompositeRateLimiter([
            TokenBucketLimiter(RateLimitConfig(requests_per_minute=60)),
            TokenBucketLimiter(RateLimitConfig(tokens_per_minute=100000)),
        ])
        ```
    """
    
    def __init__(self, limiters: list[RateLimiter]) -> None:
        """Initialize composite limiter.
        
        Args:
            limiters: List of rate limiters to combine
        """
        self.limiters = limiters
    
    async def acquire(self, tokens: int = 1) -> bool:
        """Acquire from all limiters.
        
        Args:
            tokens: Number of tokens
            
        Returns:
            True if all limiters allow
        """
        for limiter in self.limiters:
            if not await limiter.acquire(tokens):
                return False
        return True
    
    async def release(self, tokens: int = 1) -> None:
        """Release from all limiters."""
        for limiter in self.limiters:
            await limiter.release(tokens)
    
    def reset(self) -> None:
        """Reset all limiters."""
        for limiter in self.limiters:
            limiter.reset()
    
    def get_remaining(self) -> int:
        """Get minimum remaining across all limiters."""
        return min(l.get_remaining() for l in self.limiters)
    
    def get_retry_after(self) -> float:
        """Get maximum retry_after across all limiters."""
        return max(l.get_retry_after() for l in self.limiters)
