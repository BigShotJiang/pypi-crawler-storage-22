"""
Provider-specific rate limits.

Contains default rate limits for various LLM providers.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass
class ProviderRateLimits:
    """Rate limits for a specific provider.
    
    Attributes:
        requests_per_minute: Request rate limit
        tokens_per_minute: Token rate limit
        requests_per_day: Daily request limit
        tokens_per_day: Daily token limit
        concurrent_requests: Max concurrent requests
    """
    
    requests_per_minute: int = 60
    tokens_per_minute: int | None = None
    requests_per_day: int | None = None
    tokens_per_day: int | None = None
    concurrent_requests: int = 10


# Default rate limits by provider and tier
# These are approximations - actual limits depend on account tier
_PROVIDER_LIMITS: dict[str, dict[str, ProviderRateLimits]] = {
    "openai": {
        "free": ProviderRateLimits(
            requests_per_minute=3,
            tokens_per_minute=40000,
            requests_per_day=200,
            concurrent_requests=1,
        ),
        "tier1": ProviderRateLimits(
            requests_per_minute=500,
            tokens_per_minute=60000,
            concurrent_requests=5,
        ),
        "tier2": ProviderRateLimits(
            requests_per_minute=5000,
            tokens_per_minute=80000,
            concurrent_requests=10,
        ),
        "tier3": ProviderRateLimits(
            requests_per_minute=5000,
            tokens_per_minute=160000,
            concurrent_requests=20,
        ),
        "tier4": ProviderRateLimits(
            requests_per_minute=10000,
            tokens_per_minute=1000000,
            concurrent_requests=50,
        ),
        "tier5": ProviderRateLimits(
            requests_per_minute=10000,
            tokens_per_minute=2000000,
            concurrent_requests=100,
        ),
        "default": ProviderRateLimits(
            requests_per_minute=500,
            tokens_per_minute=60000,
            concurrent_requests=5,
        ),
    },
    "anthropic": {
        "free": ProviderRateLimits(
            requests_per_minute=5,
            tokens_per_minute=20000,
            concurrent_requests=1,
        ),
        "tier1": ProviderRateLimits(
            requests_per_minute=50,
            tokens_per_minute=40000,
            concurrent_requests=5,
        ),
        "tier2": ProviderRateLimits(
            requests_per_minute=1000,
            tokens_per_minute=80000,
            concurrent_requests=10,
        ),
        "tier3": ProviderRateLimits(
            requests_per_minute=2000,
            tokens_per_minute=160000,
            concurrent_requests=20,
        ),
        "tier4": ProviderRateLimits(
            requests_per_minute=4000,
            tokens_per_minute=400000,
            concurrent_requests=50,
        ),
        "default": ProviderRateLimits(
            requests_per_minute=50,
            tokens_per_minute=40000,
            concurrent_requests=5,
        ),
    },
    "ollama": {
        # Ollama is local, so limits are based on hardware
        "default": ProviderRateLimits(
            requests_per_minute=60,
            tokens_per_minute=None,  # No token limit for local
            concurrent_requests=1,  # Usually single request at a time
        ),
        "high_end": ProviderRateLimits(
            requests_per_minute=120,
            concurrent_requests=2,
        ),
    },
    "azure_openai": {
        "default": ProviderRateLimits(
            requests_per_minute=60,
            tokens_per_minute=120000,
            concurrent_requests=10,
        ),
        "s0": ProviderRateLimits(
            requests_per_minute=60,
            tokens_per_minute=120000,
            concurrent_requests=10,
        ),
    },
    "google": {
        "free": ProviderRateLimits(
            requests_per_minute=15,
            requests_per_day=1500,
            concurrent_requests=1,
        ),
        "default": ProviderRateLimits(
            requests_per_minute=360,
            tokens_per_minute=120000,
            concurrent_requests=10,
        ),
    },
}


def get_provider_limits(
    provider: str,
    tier: str = "default",
) -> ProviderRateLimits:
    """Get rate limits for a provider and tier.
    
    Args:
        provider: Provider name (openai, anthropic, ollama, etc.)
        tier: Account tier (free, tier1, tier2, etc.)
        
    Returns:
        ProviderRateLimits for the provider/tier combination
        
    Example:
        ```python
        limits = get_provider_limits("openai", "tier1")
        print(f"Max {limits.requests_per_minute} requests/min")
        ```
    """
    provider = provider.lower()
    
    if provider not in _PROVIDER_LIMITS:
        # Return conservative defaults
        return ProviderRateLimits()
    
    provider_tiers = _PROVIDER_LIMITS[provider]
    
    if tier not in provider_tiers:
        tier = "default"
    
    return provider_tiers.get(tier, ProviderRateLimits())


def register_provider_limits(
    provider: str,
    tier: str,
    limits: ProviderRateLimits,
) -> None:
    """Register custom rate limits for a provider.
    
    Args:
        provider: Provider name
        tier: Tier name
        limits: Rate limits to register
        
    Example:
        ```python
        register_provider_limits(
            "custom_llm",
            "default",
            ProviderRateLimits(
                requests_per_minute=100,
                tokens_per_minute=50000,
            )
        )
        ```
    """
    provider = provider.lower()
    
    if provider not in _PROVIDER_LIMITS:
        _PROVIDER_LIMITS[provider] = {}
    
    _PROVIDER_LIMITS[provider][tier] = limits


def list_providers() -> list[str]:
    """List all registered providers.
    
    Returns:
        List of provider names
    """
    return list(_PROVIDER_LIMITS.keys())


def list_tiers(provider: str) -> list[str]:
    """List available tiers for a provider.
    
    Args:
        provider: Provider name
        
    Returns:
        List of tier names
    """
    provider = provider.lower()
    if provider not in _PROVIDER_LIMITS:
        return []
    return list(_PROVIDER_LIMITS[provider].keys())
