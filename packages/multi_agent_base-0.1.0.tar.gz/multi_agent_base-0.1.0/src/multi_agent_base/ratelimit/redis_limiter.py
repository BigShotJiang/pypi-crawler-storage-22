"""
Redis-backed distributed rate limiter.

Provides distributed rate limiting using Redis for multi-process
and multi-node deployments.
"""

from __future__ import annotations

import time
from typing import Any

from multi_agent_base.ratelimit.limiter import (
    RateLimiter,
    RateLimitConfig,
    RateLimitResult,
)


class RedisRateLimiter(RateLimiter):
    """Distributed rate limiter using Redis.
    
    Implements token bucket algorithm with Redis as the backend,
    allowing rate limiting across multiple processes and nodes.
    
    Example:
        ```python
        import redis.asyncio as redis
        
        client = redis.Redis.from_url("redis://localhost:6379")
        
        limiter = RedisRateLimiter(
            config=RateLimitConfig(
                requests_per_minute=60,
                tokens_per_minute=10000,
            ),
            redis_client=client,
            key_prefix="myapp:ratelimit",
        )
        
        if await limiter.can_acquire():
            await limiter.acquire(tokens=100)
            # Make API call
        ```
    """
    
    def __init__(
        self,
        config: RateLimitConfig,
        redis_client: Any,
        key_prefix: str = "ratelimit",
        identifier: str = "default",
    ) -> None:
        """Initialize Redis rate limiter.
        
        Args:
            config: Rate limit configuration
            redis_client: Async Redis client instance
            key_prefix: Key prefix for Redis keys
            identifier: Unique identifier for this limiter
        """
        super().__init__(config)
        self.redis = redis_client
        self.key_prefix = key_prefix
        self.identifier = identifier
        
        # Redis key names
        self._tokens_key = f"{key_prefix}:{identifier}:tokens"
        self._last_update_key = f"{key_prefix}:{identifier}:last_update"
        self._request_count_key = f"{key_prefix}:{identifier}:requests"
    
    async def can_acquire(self, tokens: int = 1) -> bool:
        """Check if tokens can be acquired without blocking.
        
        Args:
            tokens: Number of tokens to check
            
        Returns:
            True if tokens are available
        """
        await self._refill_tokens()
        
        current_tokens = await self.redis.get(self._tokens_key)
        current_tokens = float(current_tokens) if current_tokens else self._get_bucket_capacity()
        
        return current_tokens >= tokens
    
    async def acquire(self, tokens: int = 1) -> RateLimitResult:
        """Acquire tokens from the bucket.
        
        Args:
            tokens: Number of tokens to acquire
            
        Returns:
            RateLimitResult with acquisition details
        """
        await self._refill_tokens()
        
        current_tokens = await self.redis.get(self._tokens_key)
        current_tokens = float(current_tokens) if current_tokens else self._get_bucket_capacity()
        
        if current_tokens >= tokens:
            # Atomically decrement tokens
            new_tokens = current_tokens - tokens
            await self.redis.set(self._tokens_key, new_tokens)
            
            # Increment request counter
            await self.redis.incr(self._request_count_key)
            
            return RateLimitResult(
                allowed=True,
                remaining_tokens=new_tokens,
                remaining_requests=await self._get_remaining_requests(),
                retry_after=None,
            )
        else:
            # Calculate retry time
            tokens_needed = tokens - current_tokens
            refill_rate = self.config.tokens_per_minute / 60.0
            retry_after = tokens_needed / refill_rate if refill_rate > 0 else 60.0
            
            return RateLimitResult(
                allowed=False,
                remaining_tokens=current_tokens,
                remaining_requests=await self._get_remaining_requests(),
                retry_after=retry_after,
            )
    
    async def _refill_tokens(self) -> None:
        """Refill tokens based on elapsed time."""
        now = time.time()
        
        last_update = await self.redis.get(self._last_update_key)
        last_update = float(last_update) if last_update else now
        
        elapsed = now - last_update
        
        if elapsed > 0:
            # Calculate tokens to add
            refill_rate = self.config.tokens_per_minute / 60.0
            tokens_to_add = elapsed * refill_rate
            
            # Get current tokens
            current_tokens = await self.redis.get(self._tokens_key)
            current_tokens = float(current_tokens) if current_tokens else 0
            
            # Add tokens up to capacity
            capacity = self._get_bucket_capacity()
            new_tokens = min(current_tokens + tokens_to_add, capacity)
            
            # Update Redis atomically using pipeline
            pipe = self.redis.pipeline()
            pipe.set(self._tokens_key, new_tokens)
            pipe.set(self._last_update_key, now)
            await pipe.execute()
    
    def _get_bucket_capacity(self) -> float:
        """Get the token bucket capacity."""
        return self.config.tokens_per_minute * self.config.burst_multiplier
    
    async def _get_remaining_requests(self) -> int:
        """Get remaining requests in the current window."""
        count = await self.redis.get(self._request_count_key)
        count = int(count) if count else 0
        return max(0, self.config.requests_per_minute - count)
    
    async def release(self, tokens: int = 1) -> None:
        """Release tokens back to the limiter (not typically used for token bucket).
        
        Args:
            tokens: Number of tokens to release
        """
        # Token bucket doesn't typically release, but we implement it
        current_tokens = await self.redis.get(self._tokens_key)
        current_tokens = float(current_tokens) if current_tokens else 0
        
        capacity = self._get_bucket_capacity()
        new_tokens = min(current_tokens + tokens, capacity)
        await self.redis.set(self._tokens_key, new_tokens)
    
    def reset(self) -> None:
        """Reset the rate limiter state (sync wrapper)."""
        # We can't truly be sync with async Redis, but we implement the interface
        # Users should call reset_async() for async context
        pass
    
    async def reset_async(self) -> None:
        """Reset the rate limiter state."""
        pipe = self.redis.pipeline()
        pipe.delete(self._tokens_key)
        pipe.delete(self._last_update_key)
        pipe.delete(self._request_count_key)
        await pipe.execute()
    
    def get_remaining(self) -> int:
        """Get remaining tokens/requests (sync - returns cached/estimated value).
        
        Returns:
            Estimated remaining tokens
        """
        # Return max capacity as estimate - for accurate value use get_status()
        return int(self._get_bucket_capacity())
    
    def get_retry_after(self) -> float:
        """Get seconds until tokens are available.
        
        Returns:
            Estimated seconds until retry (0 if tokens available)
        """
        # Return 0 as estimate - for accurate value use acquire() result
        return 0.0
    
    async def get_status(self) -> dict[str, Any]:
        """Get current rate limiter status.
        
        Returns:
            Dictionary with current state
        """
        await self._refill_tokens()
        
        tokens = await self.redis.get(self._tokens_key)
        requests = await self.redis.get(self._request_count_key)
        
        return {
            "identifier": self.identifier,
            "current_tokens": float(tokens) if tokens else self._get_bucket_capacity(),
            "capacity": self._get_bucket_capacity(),
            "requests_made": int(requests) if requests else 0,
            "requests_limit": self.config.requests_per_minute,
        }


class RedisSlidingWindowLimiter(RateLimiter):
    """Redis-backed sliding window rate limiter.
    
    Uses Redis sorted sets to implement a sliding window
    for more accurate rate limiting.
    """
    
    def __init__(
        self,
        config: RateLimitConfig,
        redis_client: Any,
        key_prefix: str = "ratelimit:sliding",
        identifier: str = "default",
        window_seconds: float = 60.0,
    ) -> None:
        """Initialize sliding window limiter.
        
        Args:
            config: Rate limit configuration
            redis_client: Async Redis client
            key_prefix: Redis key prefix
            identifier: Unique identifier
            window_seconds: Window size in seconds
        """
        super().__init__(config)
        self.redis = redis_client
        self.key_prefix = key_prefix
        self.identifier = identifier
        self.window_seconds = window_seconds
        
        self._requests_key = f"{key_prefix}:{identifier}:requests"
        self._tokens_key = f"{key_prefix}:{identifier}:tokens"
    
    async def can_acquire(self, tokens: int = 1) -> bool:
        """Check if request can be made.
        
        Args:
            tokens: Number of tokens needed
            
        Returns:
            True if request is allowed
        """
        await self._cleanup_old_entries()
        
        # Count requests in window
        count = await self.redis.zcard(self._requests_key)
        
        return count < self.config.requests_per_minute
    
    async def acquire(self, tokens: int = 1) -> RateLimitResult:
        """Acquire permission for a request.
        
        Args:
            tokens: Number of tokens
            
        Returns:
            RateLimitResult
        """
        await self._cleanup_old_entries()
        
        now = time.time()
        count = await self.redis.zcard(self._requests_key)
        
        if count < self.config.requests_per_minute:
            # Add request to sorted set
            await self.redis.zadd(self._requests_key, {f"{now}:{tokens}": now})
            await self.redis.expire(self._requests_key, int(self.window_seconds * 2))
            
            return RateLimitResult(
                allowed=True,
                remaining_tokens=self.config.tokens_per_minute - await self._get_token_usage(),
                remaining_requests=self.config.requests_per_minute - count - 1,
                retry_after=None,
            )
        else:
            # Get oldest request to calculate retry time
            oldest = await self.redis.zrange(self._requests_key, 0, 0, withscores=True)
            if oldest:
                oldest_time = oldest[0][1]
                retry_after = (oldest_time + self.window_seconds) - now
            else:
                retry_after = self.window_seconds
            
            return RateLimitResult(
                allowed=False,
                remaining_tokens=0,
                remaining_requests=0,
                retry_after=max(0, retry_after),
            )
    
    async def _cleanup_old_entries(self) -> None:
        """Remove entries outside the window."""
        cutoff = time.time() - self.window_seconds
        await self.redis.zremrangebyscore(self._requests_key, "-inf", cutoff)
        await self.redis.zremrangebyscore(self._tokens_key, "-inf", cutoff)
    
    async def _get_token_usage(self) -> float:
        """Get total tokens used in current window."""
        entries = await self.redis.zrange(self._requests_key, 0, -1)
        total = 0.0
        for entry in entries:
            if isinstance(entry, bytes):
                entry = entry.decode()
            parts = entry.split(":")
            if len(parts) >= 2:
                try:
                    total += float(parts[1])
                except ValueError:
                    total += 1
        return total
    
    async def release(self, tokens: int = 1) -> None:
        """Release tokens (not applicable for sliding window).
        
        Args:
            tokens: Number of tokens to release
        """
        # Sliding window doesn't support release
        pass
    
    def reset(self) -> None:
        """Reset the limiter (sync wrapper)."""
        pass
    
    async def reset_async(self) -> None:
        """Reset the limiter."""
        await self.redis.delete(self._requests_key)
        await self.redis.delete(self._tokens_key)
    
    def get_remaining(self) -> int:
        """Get remaining requests (estimate).
        
        Returns:
            Estimated remaining requests
        """
        return self.config.requests_per_minute
    
    def get_retry_after(self) -> float:
        """Get retry after time (estimate).
        
        Returns:
            Estimated retry time
        """
        return 0.0
