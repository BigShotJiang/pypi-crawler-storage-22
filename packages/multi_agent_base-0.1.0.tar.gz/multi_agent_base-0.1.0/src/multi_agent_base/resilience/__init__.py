"""
Resilience module for multi-agent framework.

Provides retry, circuit breaker, timeout, and fallback patterns
for robust agent and provider operations.
"""

from multi_agent_base.resilience.policy import (
    ResiliencePolicy,
    ResilienceConfig,
    CircuitState,
)
from multi_agent_base.resilience.retry import (
    retry_with_backoff,
    RetryStrategy,
    RetryConfig,
)
from multi_agent_base.resilience.circuit import (
    CircuitBreaker,
    CircuitBreakerError,
    CircuitOpenError,
)
from multi_agent_base.resilience.timeout import (
    with_timeout,
    TimeoutError as ResilienceTimeoutError,
)
from multi_agent_base.resilience.fallback import (
    Fallback,
    FallbackChain,
)
from multi_agent_base.resilience.wrapper import (
    ResilientWrapper,
    resilient,
)

__all__ = [
    # Policy
    "ResiliencePolicy",
    "ResilienceConfig",
    "CircuitState",
    # Retry
    "retry_with_backoff",
    "RetryStrategy",
    "RetryConfig",
    # Circuit Breaker
    "CircuitBreaker",
    "CircuitBreakerError",
    "CircuitOpenError",
    # Timeout
    "with_timeout",
    "ResilienceTimeoutError",
    # Fallback
    "Fallback",
    "FallbackChain",
    # Wrapper
    "ResilientWrapper",
    "resilient",
]
