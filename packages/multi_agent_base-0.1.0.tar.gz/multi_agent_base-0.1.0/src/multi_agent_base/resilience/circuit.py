"""
Circuit breaker pattern implementation.

Prevents cascading failures by failing fast when service is unhealthy.
"""

import asyncio
import time
from typing import Any, Callable, TypeVar
from dataclasses import dataclass, field
from enum import Enum


class CircuitState(str, Enum):
    """Circuit breaker states."""
    
    CLOSED = "closed"      # Normal operation, requests flow through
    OPEN = "open"          # Failing, requests are rejected immediately
    HALF_OPEN = "half_open"  # Testing if service recovered


class CircuitBreakerError(Exception):
    """Base exception for circuit breaker errors."""
    pass


class CircuitOpenError(CircuitBreakerError):
    """Raised when circuit is open and rejecting requests."""
    
    def __init__(self, message: str, time_until_reset: float | None = None):
        super().__init__(message)
        self.time_until_reset = time_until_reset


@dataclass
class CircuitStats:
    """Statistics for circuit breaker."""
    
    total_calls: int = 0
    successful_calls: int = 0
    failed_calls: int = 0
    rejected_calls: int = 0
    state_changes: int = 0
    last_failure_time: float | None = None
    last_success_time: float | None = None
    
    @property
    def failure_rate(self) -> float:
        """Calculate failure rate."""
        if self.total_calls == 0:
            return 0.0
        return self.failed_calls / self.total_calls


class CircuitBreaker:
    """Circuit breaker for protecting against cascading failures.
    
    States:
    - CLOSED: Normal operation, tracking failures
    - OPEN: Too many failures, rejecting all requests
    - HALF_OPEN: Testing if service recovered
    
    Example:
        circuit = CircuitBreaker(failure_threshold=5)
        
        if circuit.can_execute():
            try:
                result = await risky_operation()
                circuit.record_success()
            except Exception:
                circuit.record_failure()
    """
    
    def __init__(
        self,
        name: str = "default",
        failure_threshold: int = 5,
        success_threshold: int = 3,
        reset_timeout: float = 60.0,
        half_open_max_calls: int = 3,
        excluded_exceptions: tuple[type[Exception], ...] | None = None,
    ):
        """Initialize circuit breaker.
        
        Args:
            name: Circuit breaker name for identification
            failure_threshold: Failures before opening circuit
            success_threshold: Successes in half-open before closing
            reset_timeout: Seconds before transitioning to half-open
            half_open_max_calls: Max concurrent calls in half-open
            excluded_exceptions: Exceptions that don't count as failures
        """
        self.name = name
        self.failure_threshold = failure_threshold
        self.success_threshold = success_threshold
        self.reset_timeout = reset_timeout
        self.half_open_max_calls = half_open_max_calls
        self.excluded_exceptions = excluded_exceptions or ()
        
        # State
        self._state = CircuitState.CLOSED
        self._failure_count = 0
        self._success_count = 0
        self._half_open_calls = 0
        self._last_failure_time: float | None = None
        self._last_state_change: float = time.time()
        
        # Stats
        self._stats = CircuitStats()
        
        # Lock for thread safety
        self._lock = asyncio.Lock()
    
    @property
    def state(self) -> CircuitState:
        """Get current circuit state."""
        self._check_state_transition()
        return self._state
    
    @property
    def failure_count(self) -> int:
        """Get current failure count."""
        return self._failure_count
    
    @property
    def success_count(self) -> int:
        """Get current success count in half-open."""
        return self._success_count
    
    def can_execute(self) -> bool:
        """Check if a request can be executed.
        
        Returns:
            True if request should proceed
        """
        self._check_state_transition()
        
        if self._state == CircuitState.CLOSED:
            return True
        
        elif self._state == CircuitState.OPEN:
            return False
        
        elif self._state == CircuitState.HALF_OPEN:
            # Limit concurrent calls in half-open
            return self._half_open_calls < self.half_open_max_calls
        
        return False
    
    def record_success(self) -> None:
        """Record a successful call."""
        self._stats.total_calls += 1
        self._stats.successful_calls += 1
        self._stats.last_success_time = time.time()
        
        if self._state == CircuitState.HALF_OPEN:
            self._success_count += 1
            self._half_open_calls = max(0, self._half_open_calls - 1)
            
            # Check if we should close circuit
            if self._success_count >= self.success_threshold:
                self._transition_to(CircuitState.CLOSED)
        
        elif self._state == CircuitState.CLOSED:
            # Reset failure count on success in closed state
            self._failure_count = 0
    
    def record_failure(self, exception: Exception | None = None) -> None:
        """Record a failed call.
        
        Args:
            exception: The exception that occurred
        """
        # Check if exception should be excluded
        if exception and isinstance(exception, self.excluded_exceptions):
            return
        
        self._stats.total_calls += 1
        self._stats.failed_calls += 1
        self._stats.last_failure_time = time.time()
        self._last_failure_time = time.time()
        
        if self._state == CircuitState.HALF_OPEN:
            # Any failure in half-open reopens circuit
            self._half_open_calls = max(0, self._half_open_calls - 1)
            self._transition_to(CircuitState.OPEN)
        
        elif self._state == CircuitState.CLOSED:
            self._failure_count += 1
            
            # Check if we should open circuit
            if self._failure_count >= self.failure_threshold:
                self._transition_to(CircuitState.OPEN)
    
    def record_rejected(self) -> None:
        """Record a rejected call (circuit was open)."""
        self._stats.rejected_calls += 1
    
    def reset(self) -> None:
        """Reset circuit to closed state."""
        self._state = CircuitState.CLOSED
        self._failure_count = 0
        self._success_count = 0
        self._half_open_calls = 0
        self._last_failure_time = None
        self._last_state_change = time.time()
    
    def get_stats(self) -> dict[str, Any]:
        """Get circuit breaker statistics."""
        return {
            "name": self.name,
            "state": self._state.value,
            "failure_count": self._failure_count,
            "success_count": self._success_count,
            "half_open_calls": self._half_open_calls,
            "failure_threshold": self.failure_threshold,
            "success_threshold": self.success_threshold,
            "reset_timeout": self.reset_timeout,
            "time_in_state": time.time() - self._last_state_change,
            "stats": {
                "total_calls": self._stats.total_calls,
                "successful_calls": self._stats.successful_calls,
                "failed_calls": self._stats.failed_calls,
                "rejected_calls": self._stats.rejected_calls,
                "failure_rate": self._stats.failure_rate,
                "state_changes": self._stats.state_changes,
            }
        }
    
    def _check_state_transition(self) -> None:
        """Check if state should transition based on timeout."""
        if self._state == CircuitState.OPEN:
            if self._last_failure_time:
                elapsed = time.time() - self._last_failure_time
                if elapsed >= self.reset_timeout:
                    self._transition_to(CircuitState.HALF_OPEN)
    
    def _transition_to(self, new_state: CircuitState) -> None:
        """Transition to a new state."""
        if self._state == new_state:
            return
        
        old_state = self._state
        self._state = new_state
        self._last_state_change = time.time()
        self._stats.state_changes += 1
        
        # Reset counters based on new state
        if new_state == CircuitState.CLOSED:
            self._failure_count = 0
            self._success_count = 0
            self._half_open_calls = 0
        
        elif new_state == CircuitState.HALF_OPEN:
            self._success_count = 0
            self._half_open_calls = 0
        
        elif new_state == CircuitState.OPEN:
            self._success_count = 0
            self._half_open_calls = 0


def circuit_breaker(
    name: str = "default",
    failure_threshold: int = 5,
    success_threshold: int = 3,
    reset_timeout: float = 60.0,
) -> Callable:
    """Decorator to apply circuit breaker to async function.
    
    Args:
        name: Circuit breaker name
        failure_threshold: Failures before opening
        success_threshold: Successes before closing
        reset_timeout: Seconds before half-open
        
    Returns:
        Decorated function
        
    Example:
        @circuit_breaker(name="api", failure_threshold=3)
        async def call_api():
            ...
    """
    breaker = CircuitBreaker(
        name=name,
        failure_threshold=failure_threshold,
        success_threshold=success_threshold,
        reset_timeout=reset_timeout,
    )
    
    def decorator(func: Callable) -> Callable:
        import functools
        
        @functools.wraps(func)
        async def wrapper(*args, **kwargs):
            if not breaker.can_execute():
                breaker.record_rejected()
                time_until_reset = None
                if breaker._last_failure_time:
                    time_until_reset = max(
                        0,
                        breaker.reset_timeout - (time.time() - breaker._last_failure_time)
                    )
                raise CircuitOpenError(
                    f"Circuit {name} is open",
                    time_until_reset=time_until_reset,
                )
            
            if breaker.state == CircuitState.HALF_OPEN:
                breaker._half_open_calls += 1
            
            try:
                result = await func(*args, **kwargs)
                breaker.record_success()
                return result
            except Exception as e:
                breaker.record_failure(e)
                raise
        
        # Attach circuit breaker for inspection
        wrapper.circuit_breaker = breaker
        
        return wrapper
    
    return decorator


# Global circuit breaker registry
_circuit_breakers: dict[str, CircuitBreaker] = {}


def get_circuit_breaker(
    name: str,
    create: bool = True,
    **kwargs,
) -> CircuitBreaker | None:
    """Get or create a named circuit breaker.
    
    Args:
        name: Circuit breaker name
        create: Create if doesn't exist
        **kwargs: Arguments for new circuit breaker
        
    Returns:
        Circuit breaker instance or None
    """
    if name in _circuit_breakers:
        return _circuit_breakers[name]
    
    if create:
        breaker = CircuitBreaker(name=name, **kwargs)
        _circuit_breakers[name] = breaker
        return breaker
    
    return None


def reset_all_circuits() -> None:
    """Reset all circuit breakers."""
    for breaker in _circuit_breakers.values():
        breaker.reset()
