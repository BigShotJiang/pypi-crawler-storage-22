"""
Fallback pattern implementations.
"""

import asyncio
from typing import Any, Callable, TypeVar, Generic
from dataclasses import dataclass, field


T = TypeVar('T')


@dataclass
class FallbackResult(Generic[T]):
    """Result from fallback execution."""
    
    value: T
    source: str  # "primary" or fallback name
    used_fallback: bool = False
    error: Exception | None = None


class Fallback:
    """Fallback handler for graceful degradation.
    
    Provides alternative responses when primary operation fails.
    
    Example:
        fallback = Fallback(
            default="Service temporarily unavailable",
            on_error=lambda e: f"Error: {e}"
        )
        
        result = await fallback.execute(risky_operation)
    """
    
    def __init__(
        self,
        default: Any = None,
        on_error: Callable[[Exception], Any] | None = None,
        on_timeout: Any = None,
        cache_fallback: bool = False,
    ):
        """Initialize fallback handler.
        
        Args:
            default: Default fallback value
            on_error: Function to generate fallback from exception
            on_timeout: Specific fallback for timeout errors
            cache_fallback: Cache last successful result as fallback
        """
        self.default = default
        self.on_error = on_error
        self.on_timeout = on_timeout
        self.cache_fallback = cache_fallback
        
        self._cached_result: Any = None
        self._has_cached: bool = False
    
    async def execute(
        self,
        func: Callable[..., Any],
        *args,
        fallback_override: Any = None,
        **kwargs,
    ) -> FallbackResult:
        """Execute with fallback support.
        
        Args:
            func: Async function to execute
            *args: Positional arguments
            fallback_override: Override fallback value
            **kwargs: Keyword arguments
            
        Returns:
            FallbackResult with value and metadata
        """
        try:
            result = await func(*args, **kwargs)
            
            # Cache successful result
            if self.cache_fallback:
                self._cached_result = result
                self._has_cached = True
            
            return FallbackResult(
                value=result,
                source="primary",
                used_fallback=False,
            )
            
        except asyncio.TimeoutError as e:
            return self._get_fallback(e, fallback_override, "timeout")
            
        except Exception as e:
            return self._get_fallback(e, fallback_override, "error")
    
    def _get_fallback(
        self,
        error: Exception,
        override: Any,
        error_type: str,
    ) -> FallbackResult:
        """Determine and return fallback value."""
        # Priority: override > cache > specific handler > default
        
        if override is not None:
            return FallbackResult(
                value=override,
                source="override",
                used_fallback=True,
                error=error,
            )
        
        if self.cache_fallback and self._has_cached:
            return FallbackResult(
                value=self._cached_result,
                source="cache",
                used_fallback=True,
                error=error,
            )
        
        if error_type == "timeout" and self.on_timeout is not None:
            return FallbackResult(
                value=self.on_timeout,
                source="timeout_handler",
                used_fallback=True,
                error=error,
            )
        
        if self.on_error is not None:
            try:
                fallback_value = self.on_error(error)
                return FallbackResult(
                    value=fallback_value,
                    source="error_handler",
                    used_fallback=True,
                    error=error,
                )
            except Exception:
                pass  # Fall through to default
        
        return FallbackResult(
            value=self.default,
            source="default",
            used_fallback=True,
            error=error,
        )
    
    def clear_cache(self) -> None:
        """Clear cached fallback value."""
        self._cached_result = None
        self._has_cached = False


class FallbackChain:
    """Chain of fallback providers.
    
    Tries multiple fallbacks in order until one succeeds.
    
    Example:
        chain = FallbackChain()
        chain.add("primary", primary_api)
        chain.add("backup", backup_api)
        chain.add("cache", get_from_cache)
        chain.add("default", lambda: "Default response")
        
        result = await chain.execute("query")
    """
    
    def __init__(self, name: str = "fallback_chain"):
        """Initialize fallback chain.
        
        Args:
            name: Chain name for identification
        """
        self.name = name
        self._providers: list[tuple[str, Callable]] = []
        self._stats: dict[str, dict] = {}
    
    def add(
        self,
        name: str,
        provider: Callable[..., Any],
        condition: Callable[[], bool] | None = None,
    ) -> "FallbackChain":
        """Add a fallback provider.
        
        Args:
            name: Provider name
            provider: Async or sync function
            condition: Optional condition to check before trying
            
        Returns:
            Self for chaining
        """
        self._providers.append((name, provider, condition))
        self._stats[name] = {
            "attempts": 0,
            "successes": 0,
            "failures": 0,
        }
        return self
    
    def remove(self, name: str) -> bool:
        """Remove a provider by name."""
        for i, (pname, _, _) in enumerate(self._providers):
            if pname == name:
                self._providers.pop(i)
                self._stats.pop(name, None)
                return True
        return False
    
    async def execute(self, *args, **kwargs) -> FallbackResult:
        """Execute chain until success.
        
        Args:
            *args: Arguments for providers
            **kwargs: Keyword arguments for providers
            
        Returns:
            FallbackResult from first successful provider
        """
        errors = []
        
        for name, provider, condition in self._providers:
            # Check condition if provided
            if condition is not None:
                try:
                    if not condition():
                        continue
                except Exception:
                    continue
            
            self._stats[name]["attempts"] += 1
            
            try:
                # Handle both sync and async providers
                if asyncio.iscoroutinefunction(provider):
                    result = await provider(*args, **kwargs)
                else:
                    result = provider(*args, **kwargs)
                
                self._stats[name]["successes"] += 1
                
                return FallbackResult(
                    value=result,
                    source=name,
                    used_fallback=name != self._providers[0][0] if self._providers else True,
                )
                
            except Exception as e:
                self._stats[name]["failures"] += 1
                errors.append((name, e))
                continue
        
        # All providers failed
        return FallbackResult(
            value=None,
            source="none",
            used_fallback=True,
            error=errors[-1][1] if errors else None,
        )
    
    def get_stats(self) -> dict[str, Any]:
        """Get chain statistics."""
        return {
            "name": self.name,
            "provider_count": len(self._providers),
            "providers": dict(self._stats),
        }


def with_fallback(
    default: Any = None,
    on_error: Callable[[Exception], Any] | None = None,
) -> Callable:
    """Decorator to add fallback to async functions.
    
    Args:
        default: Default fallback value
        on_error: Function to generate fallback from exception
        
    Returns:
        Decorated function
        
    Example:
        @with_fallback(default="Error occurred")
        async def fetch_data():
            ...
    """
    fallback = Fallback(default=default, on_error=on_error)
    
    def decorator(func: Callable) -> Callable:
        import functools
        
        @functools.wraps(func)
        async def wrapper(*args, **kwargs):
            result = await fallback.execute(func, *args, **kwargs)
            return result.value
        
        # Attach fallback for inspection
        wrapper.fallback = fallback
        
        return wrapper
    
    return decorator
