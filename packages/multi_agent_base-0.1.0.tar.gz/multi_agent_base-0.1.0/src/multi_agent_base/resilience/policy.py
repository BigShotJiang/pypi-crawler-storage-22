"""
Resilience policy configuration.
"""

from enum import Enum
from typing import Any, Optional
from pydantic import BaseModel, Field


class CircuitState(str, Enum):
    """Circuit breaker states."""
    
    CLOSED = "closed"      # Normal operation
    OPEN = "open"          # Failing, rejecting requests
    HALF_OPEN = "half_open"  # Testing if service recovered


class RetryStrategy(str, Enum):
    """Retry backoff strategies."""
    
    FIXED = "fixed"          # Fixed delay between retries
    EXPONENTIAL = "exponential"  # Exponential backoff
    LINEAR = "linear"        # Linear increase
    JITTERED = "jittered"    # Exponential with random jitter


class ResilienceConfig(BaseModel):
    """Configuration for resilience features."""
    
    # Retry settings
    retry_enabled: bool = Field(
        default=True,
        description="Enable retry logic"
    )
    retry_attempts: int = Field(
        default=3,
        ge=0,
        le=10,
        description="Maximum retry attempts"
    )
    retry_delay: float = Field(
        default=1.0,
        ge=0.0,
        description="Initial delay between retries (seconds)"
    )
    retry_max_delay: float = Field(
        default=60.0,
        ge=1.0,
        description="Maximum delay between retries (seconds)"
    )
    retry_backoff_multiplier: float = Field(
        default=2.0,
        ge=1.0,
        description="Backoff multiplier for exponential/linear strategies"
    )
    retry_strategy: RetryStrategy = Field(
        default=RetryStrategy.EXPONENTIAL,
        description="Retry backoff strategy"
    )
    retry_jitter: float = Field(
        default=0.1,
        ge=0.0,
        le=1.0,
        description="Jitter factor for randomized delays"
    )
    retry_exceptions: list[str] = Field(
        default_factory=lambda: [
            "ConnectionError",
            "TimeoutError",
            "RateLimitError",
            "ServiceUnavailableError",
        ],
        description="Exception types to retry on"
    )
    
    # Circuit breaker settings
    circuit_breaker_enabled: bool = Field(
        default=True,
        description="Enable circuit breaker"
    )
    circuit_failure_threshold: int = Field(
        default=5,
        ge=1,
        description="Failures before opening circuit"
    )
    circuit_success_threshold: int = Field(
        default=3,
        ge=1,
        description="Successes in half-open before closing"
    )
    circuit_reset_timeout: float = Field(
        default=60.0,
        ge=1.0,
        description="Seconds before half-open from open"
    )
    circuit_half_open_max_calls: int = Field(
        default=3,
        ge=1,
        description="Max calls allowed in half-open state"
    )
    
    # Timeout settings
    timeout_enabled: bool = Field(
        default=True,
        description="Enable timeout handling"
    )
    timeout_seconds: float = Field(
        default=120.0,
        ge=1.0,
        description="Operation timeout in seconds"
    )
    
    # Fallback settings
    fallback_enabled: bool = Field(
        default=False,
        description="Enable fallback responses"
    )
    fallback_response: Optional[str] = Field(
        default=None,
        description="Static fallback response"
    )
    
    class Config:
        use_enum_values = True


class RetryConfig(BaseModel):
    """Configuration for retry behavior.
    
    Simplified config for direct retry control.
    """
    
    max_attempts: int = Field(default=3, ge=1, description="Maximum retry attempts")
    base_delay: float = Field(default=1.0, ge=0, description="Base delay between retries")
    max_delay: float = Field(default=60.0, ge=1.0, description="Maximum delay")
    strategy: RetryStrategy = Field(default=RetryStrategy.EXPONENTIAL, description="Backoff strategy")
    jitter: float = Field(default=0.1, ge=0, le=1.0, description="Jitter factor")
    
    class Config:
        use_enum_values = True


class TimeoutConfig(BaseModel):
    """Configuration for timeout behavior."""
    
    seconds: float = Field(default=120.0, ge=0.1, description="Timeout in seconds")
    cancel_on_timeout: bool = Field(default=True, description="Cancel operation on timeout")
    
    class Config:
        use_enum_values = True


class ResiliencePolicy:
    """Resilience policy combining multiple patterns.
    
    Wraps operations with retry, circuit breaker, timeout, and fallback.
    
    Example:
        policy = ResiliencePolicy(config)
        result = await policy.execute(my_async_function, arg1, arg2)
    """
    
    def __init__(
        self,
        config: ResilienceConfig | None = None,
        name: str = "default",
    ):
        """Initialize resilience policy.
        
        Args:
            config: Resilience configuration
            name: Policy name for identification
        """
        self.config = config or ResilienceConfig()
        self.name = name
        
        # Lazy initialization of components
        self._circuit_breaker = None
        self._initialized = False
    
    def _ensure_initialized(self) -> None:
        """Ensure components are initialized."""
        if self._initialized:
            return
        
        if self.config.circuit_breaker_enabled:
            from multi_agent_base.resilience.circuit import CircuitBreaker
            self._circuit_breaker = CircuitBreaker(
                name=self.name,
                failure_threshold=self.config.circuit_failure_threshold,
                success_threshold=self.config.circuit_success_threshold,
                reset_timeout=self.config.circuit_reset_timeout,
                half_open_max_calls=self.config.circuit_half_open_max_calls,
            )
        
        self._initialized = True
    
    async def execute(
        self,
        func,
        *args,
        timeout: float | None = None,
        fallback: Any = None,
        **kwargs,
    ):
        """Execute function with resilience patterns.
        
        Args:
            func: Async function to execute
            *args: Positional arguments
            timeout: Override timeout
            fallback: Override fallback value
            **kwargs: Keyword arguments
            
        Returns:
            Function result or fallback
            
        Raises:
            Exception if all resilience measures fail
        """
        import asyncio
        from multi_agent_base.resilience.retry import retry_with_backoff
        from multi_agent_base.resilience.circuit import CircuitOpenError
        
        self._ensure_initialized()
        
        # Use configured or override values
        timeout_value = timeout or (
            self.config.timeout_seconds if self.config.timeout_enabled else None
        )
        fallback_value = fallback if fallback is not None else self.config.fallback_response
        
        async def wrapped():
            # Check circuit breaker
            if self._circuit_breaker:
                if not self._circuit_breaker.can_execute():
                    raise CircuitOpenError(
                        f"Circuit {self.name} is open"
                    )
            
            try:
                result = await func(*args, **kwargs)
                
                # Record success
                if self._circuit_breaker:
                    self._circuit_breaker.record_success()
                
                return result
                
            except Exception as e:
                # Record failure
                if self._circuit_breaker:
                    self._circuit_breaker.record_failure()
                raise
        
        try:
            # Apply retry if enabled
            if self.config.retry_enabled:
                operation = retry_with_backoff(
                    max_attempts=self.config.retry_attempts,
                    delay=self.config.retry_delay,
                    max_delay=self.config.retry_max_delay,
                    backoff_multiplier=self.config.retry_backoff_multiplier,
                    strategy=self.config.retry_strategy,
                    jitter=self.config.retry_jitter,
                )(wrapped)
            else:
                operation = wrapped
            
            # Apply timeout if enabled
            if timeout_value:
                result = await asyncio.wait_for(
                    operation(),
                    timeout=timeout_value
                )
            else:
                result = await operation()
            
            return result
            
        except asyncio.TimeoutError:
            if fallback_value is not None:
                return fallback_value
            raise
            
        except CircuitOpenError:
            if fallback_value is not None:
                return fallback_value
            raise
            
        except Exception as e:
            if self.config.fallback_enabled and fallback_value is not None:
                return fallback_value
            raise
    
    def get_circuit_state(self) -> CircuitState | None:
        """Get current circuit breaker state."""
        if self._circuit_breaker:
            return self._circuit_breaker.state
        return None
    
    def reset_circuit(self) -> None:
        """Reset circuit breaker to closed state."""
        if self._circuit_breaker:
            self._circuit_breaker.reset()
    
    def get_stats(self) -> dict[str, Any]:
        """Get resilience statistics."""
        stats = {
            "name": self.name,
            "config": self.config.model_dump(),
        }
        
        if self._circuit_breaker:
            stats["circuit_breaker"] = {
                "state": self._circuit_breaker.state.value,
                "failure_count": self._circuit_breaker.failure_count,
                "success_count": self._circuit_breaker.success_count,
            }
        
        return stats
