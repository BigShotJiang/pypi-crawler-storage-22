"""
Retry logic with configurable backoff strategies.
"""

import asyncio
import random
import functools
from enum import Enum
from typing import Any, Callable, TypeVar, ParamSpec
from dataclasses import dataclass

from multi_agent_base.resilience.policy import RetryStrategy


P = ParamSpec('P')
T = TypeVar('T')


@dataclass
class RetryConfig:
    """Configuration for retry behavior."""
    
    max_attempts: int = 3
    delay: float = 1.0
    max_delay: float = 60.0
    backoff_multiplier: float = 2.0
    strategy: RetryStrategy = RetryStrategy.EXPONENTIAL
    jitter: float = 0.1
    retry_on: tuple[type[Exception], ...] = (Exception,)
    
    def calculate_delay(self, attempt: int) -> float:
        """Calculate delay for a specific attempt.
        
        Args:
            attempt: Current attempt number (0-indexed)
            
        Returns:
            Delay in seconds
        """
        if self.strategy == RetryStrategy.FIXED:
            base_delay = self.delay
            
        elif self.strategy == RetryStrategy.EXPONENTIAL:
            base_delay = self.delay * (self.backoff_multiplier ** attempt)
            
        elif self.strategy == RetryStrategy.LINEAR:
            base_delay = self.delay * (1 + attempt * self.backoff_multiplier)
            
        elif self.strategy == RetryStrategy.JITTERED:
            base_delay = self.delay * (self.backoff_multiplier ** attempt)
            # Add random jitter
            jitter_range = base_delay * self.jitter
            base_delay += random.uniform(-jitter_range, jitter_range)
            
        else:
            base_delay = self.delay
        
        # Apply jitter if not already jittered
        if self.strategy != RetryStrategy.JITTERED and self.jitter > 0:
            jitter_range = base_delay * self.jitter
            base_delay += random.uniform(0, jitter_range)
        
        # Clamp to max delay
        return min(base_delay, self.max_delay)


class RetryExhaustedError(Exception):
    """Raised when all retry attempts are exhausted."""
    
    def __init__(
        self,
        message: str,
        attempts: int,
        last_exception: Exception | None = None,
    ):
        super().__init__(message)
        self.attempts = attempts
        self.last_exception = last_exception


def retry_with_backoff(
    max_attempts: int = 3,
    delay: float = 1.0,
    max_delay: float = 60.0,
    backoff_multiplier: float = 2.0,
    strategy: RetryStrategy | str = RetryStrategy.EXPONENTIAL,
    jitter: float = 0.1,
    retry_on: tuple[type[Exception], ...] | None = None,
    on_retry: Callable[[int, Exception], None] | None = None,
) -> Callable[[Callable[P, T]], Callable[P, T]]:
    """Decorator for retrying async functions with backoff.
    
    Args:
        max_attempts: Maximum number of attempts
        delay: Initial delay between retries
        max_delay: Maximum delay between retries
        backoff_multiplier: Multiplier for delay increase
        strategy: Backoff strategy
        jitter: Random jitter factor (0-1)
        retry_on: Exception types to retry on (default: all)
        on_retry: Callback called on each retry
        
    Returns:
        Decorated function
        
    Example:
        @retry_with_backoff(max_attempts=3, delay=1.0)
        async def fetch_data():
            ...
    """
    if isinstance(strategy, str):
        strategy = RetryStrategy(strategy)
    
    retry_exceptions = retry_on or (Exception,)
    
    config = RetryConfig(
        max_attempts=max_attempts,
        delay=delay,
        max_delay=max_delay,
        backoff_multiplier=backoff_multiplier,
        strategy=strategy,
        jitter=jitter,
        retry_on=retry_exceptions,
    )
    
    def decorator(func: Callable[P, T]) -> Callable[P, T]:
        @functools.wraps(func)
        async def wrapper(*args: P.args, **kwargs: P.kwargs) -> T:
            last_exception = None
            
            for attempt in range(max_attempts):
                try:
                    return await func(*args, **kwargs)
                    
                except retry_exceptions as e:
                    last_exception = e
                    
                    # Don't retry on last attempt
                    if attempt == max_attempts - 1:
                        break
                    
                    # Calculate delay
                    wait_time = config.calculate_delay(attempt)
                    
                    # Call retry callback if provided
                    if on_retry:
                        on_retry(attempt + 1, e)
                    
                    # Wait before next attempt
                    await asyncio.sleep(wait_time)
            
            raise RetryExhaustedError(
                f"All {max_attempts} retry attempts exhausted",
                attempts=max_attempts,
                last_exception=last_exception,
            )
        
        # Store config for inspection
        wrapper.retry_config = config
        
        return wrapper
    
    return decorator


class Retry:
    """Retry manager for programmatic retry control.
    
    Example:
        retry = Retry(max_attempts=3, delay=1.0)
        
        async with retry:
            result = await risky_operation()
    """
    
    def __init__(
        self,
        max_attempts: int = 3,
        delay: float = 1.0,
        max_delay: float = 60.0,
        backoff_multiplier: float = 2.0,
        strategy: RetryStrategy = RetryStrategy.EXPONENTIAL,
        jitter: float = 0.1,
        retry_on: tuple[type[Exception], ...] | None = None,
    ):
        """Initialize retry manager."""
        self.config = RetryConfig(
            max_attempts=max_attempts,
            delay=delay,
            max_delay=max_delay,
            backoff_multiplier=backoff_multiplier,
            strategy=strategy,
            jitter=jitter,
            retry_on=retry_on or (Exception,),
        )
        self._attempt = 0
        self._last_exception: Exception | None = None
    
    @property
    def attempt(self) -> int:
        """Current attempt number (1-indexed)."""
        return self._attempt
    
    @property
    def has_attempts_remaining(self) -> bool:
        """Check if more attempts are available."""
        return self._attempt < self.config.max_attempts
    
    def record_failure(self, exception: Exception) -> None:
        """Record a failed attempt."""
        self._last_exception = exception
    
    def get_delay(self) -> float:
        """Get delay for current attempt."""
        return self.config.calculate_delay(self._attempt)
    
    async def wait(self) -> None:
        """Wait before next attempt."""
        delay = self.get_delay()
        await asyncio.sleep(delay)
    
    async def execute(
        self,
        func: Callable[..., Any],
        *args,
        **kwargs,
    ) -> Any:
        """Execute function with retry.
        
        Args:
            func: Async function to execute
            *args: Positional arguments
            **kwargs: Keyword arguments
            
        Returns:
            Function result
            
        Raises:
            RetryExhaustedError: If all attempts fail
        """
        while self.has_attempts_remaining:
            self._attempt += 1
            
            try:
                return await func(*args, **kwargs)
                
            except self.config.retry_on as e:
                self.record_failure(e)
                
                if self.has_attempts_remaining:
                    await self.wait()
        
        raise RetryExhaustedError(
            f"All {self.config.max_attempts} retry attempts exhausted",
            attempts=self.config.max_attempts,
            last_exception=self._last_exception,
        )
    
    def reset(self) -> None:
        """Reset retry state for reuse."""
        self._attempt = 0
        self._last_exception = None


# Aliases for backward compatibility
RetryExecutor = Retry
BackoffStrategy = RetryStrategy
