"""
Timeout handling utilities.
"""

import asyncio
import functools
from typing import Any, Callable, TypeVar, ParamSpec


P = ParamSpec('P')
T = TypeVar('T')


class TimeoutError(Exception):
    """Raised when operation times out."""
    
    def __init__(
        self,
        message: str = "Operation timed out",
        timeout: float | None = None,
        operation: str | None = None,
    ):
        super().__init__(message)
        self.timeout = timeout
        self.operation = operation


async def with_timeout(
    coro,
    timeout: float,
    timeout_message: str | None = None,
) -> Any:
    """Execute coroutine with timeout.
    
    Args:
        coro: Coroutine to execute
        timeout: Timeout in seconds
        timeout_message: Custom timeout error message
        
    Returns:
        Coroutine result
        
    Raises:
        TimeoutError: If operation times out
    """
    try:
        return await asyncio.wait_for(coro, timeout=timeout)
    except asyncio.TimeoutError:
        message = timeout_message or f"Operation timed out after {timeout}s"
        raise TimeoutError(message, timeout=timeout)


def timeout(
    seconds: float,
    message: str | None = None,
) -> Callable[[Callable[P, T]], Callable[P, T]]:
    """Decorator to add timeout to async functions.
    
    Args:
        seconds: Timeout in seconds
        message: Custom timeout error message
        
    Returns:
        Decorated function
        
    Example:
        @timeout(30)
        async def slow_operation():
            ...
    """
    def decorator(func: Callable[P, T]) -> Callable[P, T]:
        @functools.wraps(func)
        async def wrapper(*args: P.args, **kwargs: P.kwargs) -> T:
            try:
                return await asyncio.wait_for(
                    func(*args, **kwargs),
                    timeout=seconds
                )
            except asyncio.TimeoutError:
                error_message = message or f"{func.__name__} timed out after {seconds}s"
                raise TimeoutError(
                    error_message,
                    timeout=seconds,
                    operation=func.__name__,
                )
        
        # Store timeout value for inspection
        wrapper.timeout_seconds = seconds
        
        return wrapper
    
    return decorator


class TimeoutManager:
    """Manager for dynamic timeout control.
    
    Supports adaptive timeouts based on operation history.
    
    Example:
        manager = TimeoutManager(default_timeout=30)
        
        async with manager.timeout_context("operation_name"):
            result = await slow_operation()
    """
    
    def __init__(
        self,
        default_timeout: float = 30.0,
        min_timeout: float = 5.0,
        max_timeout: float = 300.0,
        adaptive: bool = False,
    ):
        """Initialize timeout manager.
        
        Args:
            default_timeout: Default timeout in seconds
            min_timeout: Minimum timeout (for adaptive)
            max_timeout: Maximum timeout (for adaptive)
            adaptive: Enable adaptive timeout adjustment
        """
        self.default_timeout = default_timeout
        self.min_timeout = min_timeout
        self.max_timeout = max_timeout
        self.adaptive = adaptive
        
        # Track operation times for adaptive timeout
        self._operation_times: dict[str, list[float]] = {}
        self._operation_timeouts: dict[str, float] = {}
    
    def get_timeout(self, operation: str | None = None) -> float:
        """Get timeout for an operation.
        
        Args:
            operation: Operation name for per-operation timeouts
            
        Returns:
            Timeout in seconds
        """
        if operation and operation in self._operation_timeouts:
            return self._operation_timeouts[operation]
        return self.default_timeout
    
    def set_timeout(self, operation: str, timeout: float) -> None:
        """Set timeout for a specific operation.
        
        Args:
            operation: Operation name
            timeout: Timeout in seconds
        """
        self._operation_timeouts[operation] = max(
            self.min_timeout,
            min(timeout, self.max_timeout)
        )
    
    def record_duration(self, operation: str, duration: float) -> None:
        """Record operation duration for adaptive timeouts.
        
        Args:
            operation: Operation name
            duration: Duration in seconds
        """
        if operation not in self._operation_times:
            self._operation_times[operation] = []
        
        times = self._operation_times[operation]
        times.append(duration)
        
        # Keep last 100 samples
        if len(times) > 100:
            times.pop(0)
        
        # Update adaptive timeout
        if self.adaptive and len(times) >= 5:
            self._update_adaptive_timeout(operation)
    
    def _update_adaptive_timeout(self, operation: str) -> None:
        """Update timeout based on operation history."""
        times = self._operation_times.get(operation, [])
        if not times:
            return
        
        # Use 95th percentile + buffer
        sorted_times = sorted(times)
        p95_index = int(len(sorted_times) * 0.95)
        p95_time = sorted_times[p95_index]
        
        # Add 50% buffer
        new_timeout = p95_time * 1.5
        
        self.set_timeout(operation, new_timeout)
    
    async def execute(
        self,
        coro,
        operation: str | None = None,
        timeout_override: float | None = None,
    ) -> Any:
        """Execute with managed timeout.
        
        Args:
            coro: Coroutine to execute
            operation: Operation name for timeout lookup
            timeout_override: Override timeout value
            
        Returns:
            Coroutine result
        """
        import time
        
        timeout_value = timeout_override or self.get_timeout(operation)
        start_time = time.time()
        
        try:
            result = await asyncio.wait_for(coro, timeout=timeout_value)
            
            # Record successful duration
            if operation:
                duration = time.time() - start_time
                self.record_duration(operation, duration)
            
            return result
            
        except asyncio.TimeoutError:
            raise TimeoutError(
                f"Operation {operation or 'unknown'} timed out after {timeout_value}s",
                timeout=timeout_value,
                operation=operation,
            )
    
    def timeout_context(self, operation: str | None = None):
        """Context manager for timeout tracking.
        
        Args:
            operation: Operation name
            
        Returns:
            Async context manager
        """
        return TimeoutContext(self, operation)
    
    def get_stats(self) -> dict[str, Any]:
        """Get timeout statistics."""
        stats = {
            "default_timeout": self.default_timeout,
            "adaptive": self.adaptive,
            "operations": {},
        }
        
        for operation in set(self._operation_times.keys()) | set(self._operation_timeouts.keys()):
            times = self._operation_times.get(operation, [])
            stats["operations"][operation] = {
                "current_timeout": self.get_timeout(operation),
                "sample_count": len(times),
                "avg_duration": sum(times) / len(times) if times else None,
                "max_duration": max(times) if times else None,
            }
        
        return stats


class TimeoutContext:
    """Async context manager for timeout operations."""
    
    def __init__(self, manager: TimeoutManager, operation: str | None):
        self.manager = manager
        self.operation = operation
        self.start_time: float | None = None
    
    async def __aenter__(self):
        import time
        self.start_time = time.time()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        import time
        
        if self.start_time and self.operation:
            duration = time.time() - self.start_time
            
            # Only record on success (no exception)
            if exc_type is None:
                self.manager.record_duration(self.operation, duration)
        
        return False  # Don't suppress exceptions
