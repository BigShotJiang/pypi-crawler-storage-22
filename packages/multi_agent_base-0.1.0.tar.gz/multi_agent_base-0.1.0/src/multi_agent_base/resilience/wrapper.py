"""
Resilient wrapper combining all resilience patterns.
"""

import asyncio
import functools
from typing import Any, Callable, TypeVar, ParamSpec

from multi_agent_base.resilience.policy import ResiliencePolicy, ResilienceConfig
from multi_agent_base.resilience.circuit import CircuitBreaker, CircuitOpenError
from multi_agent_base.resilience.retry import retry_with_backoff, RetryExhaustedError
from multi_agent_base.resilience.fallback import Fallback, FallbackResult
from multi_agent_base.resilience.timeout import TimeoutError as ResilienceTimeoutError


P = ParamSpec('P')
T = TypeVar('T')


class ResilientWrapper:
    """Wrapper that applies all resilience patterns to an operation.
    
    Combines retry, circuit breaker, timeout, and fallback in optimal order:
    1. Circuit breaker check (fast fail if circuit open)
    2. Timeout wrapper
    3. Retry logic
    4. Fallback on final failure
    
    Example:
        wrapper = ResilientWrapper(config)
        result = await wrapper.call(risky_function, arg1, arg2)
    """
    
    def __init__(
        self,
        config: ResilienceConfig | None = None,
        name: str = "default",
        fallback: Fallback | None = None,
    ):
        """Initialize resilient wrapper.
        
        Args:
            config: Resilience configuration
            name: Wrapper name for identification
            fallback: Optional fallback handler
        """
        self.config = config or ResilienceConfig()
        self.name = name
        self.fallback = fallback
        
        # Initialize circuit breaker if enabled
        self._circuit_breaker: CircuitBreaker | None = None
        if self.config.circuit_breaker_enabled:
            self._circuit_breaker = CircuitBreaker(
                name=name,
                failure_threshold=self.config.circuit_failure_threshold,
                success_threshold=self.config.circuit_success_threshold,
                reset_timeout=self.config.circuit_reset_timeout,
                half_open_max_calls=self.config.circuit_half_open_max_calls,
            )
        
        # Stats
        self._total_calls = 0
        self._successful_calls = 0
        self._failed_calls = 0
        self._fallback_calls = 0
        self._timeout_calls = 0
        self._circuit_rejections = 0
    
    async def call(
        self,
        func: Callable[..., Any],
        *args,
        timeout_override: float | None = None,
        fallback_override: Any = None,
        **kwargs,
    ) -> Any:
        """Execute function with all resilience patterns.
        
        Args:
            func: Async function to execute
            *args: Positional arguments
            timeout_override: Override timeout value
            fallback_override: Override fallback value
            **kwargs: Keyword arguments
            
        Returns:
            Function result or fallback
            
        Raises:
            CircuitOpenError: If circuit is open and no fallback
            RetryExhaustedError: If all retries exhausted and no fallback
            TimeoutError: If timeout and no fallback
        """
        self._total_calls += 1
        
        # 1. Check circuit breaker
        if self._circuit_breaker:
            if not self._circuit_breaker.can_execute():
                self._circuit_rejections += 1
                return await self._handle_failure(
                    CircuitOpenError(f"Circuit {self.name} is open"),
                    fallback_override,
                )
            
            # Mark as in-flight for half-open
            if self._circuit_breaker.state.value == "half_open":
                self._circuit_breaker._half_open_calls += 1
        
        # 2. Prepare timeout
        timeout_value = timeout_override
        if timeout_value is None and self.config.timeout_enabled:
            timeout_value = self.config.timeout_seconds
        
        # 3. Define the operation with retry
        async def operation():
            return await func(*args, **kwargs)
        
        # Apply retry if enabled
        if self.config.retry_enabled:
            operation = self._wrap_with_retry(operation)
        
        # 4. Execute with timeout
        try:
            if timeout_value:
                result = await asyncio.wait_for(
                    operation(),
                    timeout=timeout_value
                )
            else:
                result = await operation()
            
            # Record success
            self._successful_calls += 1
            if self._circuit_breaker:
                self._circuit_breaker.record_success()
            
            return result
            
        except asyncio.TimeoutError as e:
            self._timeout_calls += 1
            if self._circuit_breaker:
                self._circuit_breaker.record_failure(e)
            return await self._handle_failure(e, fallback_override)
            
        except RetryExhaustedError as e:
            if self._circuit_breaker:
                self._circuit_breaker.record_failure(e.last_exception)
            return await self._handle_failure(e, fallback_override)
            
        except Exception as e:
            self._failed_calls += 1
            if self._circuit_breaker:
                self._circuit_breaker.record_failure(e)
            return await self._handle_failure(e, fallback_override)
    
    def _wrap_with_retry(self, operation: Callable) -> Callable:
        """Wrap operation with retry logic."""
        @retry_with_backoff(
            max_attempts=self.config.retry_attempts,
            delay=self.config.retry_delay,
            max_delay=self.config.retry_max_delay,
            backoff_multiplier=self.config.retry_backoff_multiplier,
            strategy=self.config.retry_strategy,
            jitter=self.config.retry_jitter,
        )
        async def wrapped():
            return await operation()
        
        return wrapped
    
    async def _handle_failure(
        self,
        error: Exception,
        fallback_override: Any,
    ) -> Any:
        """Handle failure with fallback."""
        self._failed_calls += 1
        
        # Check for fallback
        if fallback_override is not None:
            self._fallback_calls += 1
            return fallback_override
        
        if self.fallback:
            self._fallback_calls += 1
            result = self.fallback._get_fallback(error, None, "error")
            return result.value
        
        if self.config.fallback_enabled and self.config.fallback_response is not None:
            self._fallback_calls += 1
            return self.config.fallback_response
        
        # No fallback available
        raise error
    
    def get_stats(self) -> dict[str, Any]:
        """Get wrapper statistics."""
        stats = {
            "name": self.name,
            "total_calls": self._total_calls,
            "successful_calls": self._successful_calls,
            "failed_calls": self._failed_calls,
            "fallback_calls": self._fallback_calls,
            "timeout_calls": self._timeout_calls,
            "circuit_rejections": self._circuit_rejections,
            "success_rate": (
                self._successful_calls / self._total_calls
                if self._total_calls > 0 else 0.0
            ),
        }
        
        if self._circuit_breaker:
            stats["circuit_breaker"] = self._circuit_breaker.get_stats()
        
        return stats
    
    def reset(self) -> None:
        """Reset wrapper state."""
        self._total_calls = 0
        self._successful_calls = 0
        self._failed_calls = 0
        self._fallback_calls = 0
        self._timeout_calls = 0
        self._circuit_rejections = 0
        
        if self._circuit_breaker:
            self._circuit_breaker.reset()


def resilient(
    retry_attempts: int = 3,
    retry_delay: float = 1.0,
    timeout: float = 30.0,
    circuit_breaker: bool = True,
    failure_threshold: int = 5,
    fallback: Any = None,
    name: str | None = None,
) -> Callable[[Callable[P, T]], Callable[P, T]]:
    """Decorator to make async function resilient.
    
    Applies retry, circuit breaker, timeout, and fallback.
    
    Args:
        retry_attempts: Maximum retry attempts
        retry_delay: Initial retry delay
        timeout: Operation timeout
        circuit_breaker: Enable circuit breaker
        failure_threshold: Failures before opening circuit
        fallback: Fallback value on failure
        name: Name for identification
        
    Returns:
        Decorated function
        
    Example:
        @resilient(retry_attempts=3, timeout=30, fallback="Error")
        async def call_api():
            ...
    """
    config = ResilienceConfig(
        retry_enabled=retry_attempts > 0,
        retry_attempts=retry_attempts,
        retry_delay=retry_delay,
        timeout_enabled=timeout > 0,
        timeout_seconds=timeout,
        circuit_breaker_enabled=circuit_breaker,
        circuit_failure_threshold=failure_threshold,
        fallback_enabled=fallback is not None,
        fallback_response=fallback if isinstance(fallback, str) else None,
    )
    
    def decorator(func: Callable[P, T]) -> Callable[P, T]:
        wrapper_name = name or func.__name__
        
        wrapper = ResilientWrapper(
            config=config,
            name=wrapper_name,
            fallback=Fallback(default=fallback) if fallback else None,
        )
        
        @functools.wraps(func)
        async def wrapped(*args: P.args, **kwargs: P.kwargs) -> T:
            return await wrapper.call(func, *args, **kwargs)
        
        # Attach wrapper for inspection
        wrapped.resilient_wrapper = wrapper
        wrapped.get_stats = wrapper.get_stats
        
        return wrapped
    
    return decorator


# Global wrapper registry
_wrappers: dict[str, ResilientWrapper] = {}


def get_resilient_wrapper(
    name: str,
    config: ResilienceConfig | None = None,
    create: bool = True,
) -> ResilientWrapper | None:
    """Get or create a named resilient wrapper.
    
    Args:
        name: Wrapper name
        config: Configuration for new wrapper
        create: Create if doesn't exist
        
    Returns:
        Wrapper instance or None
    """
    if name in _wrappers:
        return _wrappers[name]
    
    if create:
        wrapper = ResilientWrapper(config=config, name=name)
        _wrappers[name] = wrapper
        return wrapper
    
    return None


def get_all_stats() -> dict[str, Any]:
    """Get statistics from all wrappers."""
    return {name: wrapper.get_stats() for name, wrapper in _wrappers.items()}
