"""
Security Module for Multi-Agent Base.

This module provides comprehensive security capabilities:
- Input validation and sanitization
- Prompt injection detection
- Secret management
- Permission controls
- PII detection and redaction
- Content filtering
- Security audit logging
"""

from multi_agent_base.security.validation import (
    InputValidator,
    ValidationResult,
    ValidationRule,
    sanitize_input,
)
from multi_agent_base.security.injection import (
    InjectionDetector,
    InjectionType,
    DetectionResult,
)
from multi_agent_base.security.secrets import (
    SecretManager,
    Secret,
    mask_secrets,
)
from multi_agent_base.security.permissions import (
    Permission,
    PermissionSet,
    ToolPermission,
    check_permission,
)
from multi_agent_base.security.pii import (
    PIIDetector,
    PIIType,
    PIISeverity,
    PIIMatch,
    PIIDetectionResult,
    PIIPattern,
    PIIPolicy,
    PIIRedactor,
    PlaceholderRedactor,
    MaskingRedactor,
    HashRedactor,
)
from multi_agent_base.security.content import (
    ContentFilter,
    ContentCategory,
    ContentSeverity,
    ContentViolation,
    FilterResult,
    ContentRule,
    ContentPolicy,
    ContentFilterConfig,
)
from multi_agent_base.security.audit import (
    AuditLogger,
    AuditEvent,
    AuditEventType,
    AuditSeverity,
    AuditContext,
    AuditBackend,
    MemoryAuditBackend,
    FileAuditBackend,
    AuditReport,
)

__all__ = [
    # Validation
    "InputValidator",
    "ValidationResult",
    "ValidationRule",
    "sanitize_input",
    # Injection Detection
    "InjectionDetector",
    "InjectionType",
    "DetectionResult",
    # Secrets
    "SecretManager",
    "Secret",
    "mask_secrets",
    # Permissions
    "Permission",
    "PermissionSet",
    "ToolPermission",
    "check_permission",
    # PII Detection
    "PIIDetector",
    "PIIType",
    "PIISeverity",
    "PIIMatch",
    "PIIDetectionResult",
    "PIIPattern",
    "PIIPolicy",
    "PIIRedactor",
    "PlaceholderRedactor",
    "MaskingRedactor",
    "HashRedactor",
    # Content Filtering
    "ContentFilter",
    "ContentCategory",
    "ContentSeverity",
    "ContentViolation",
    "FilterResult",
    "ContentRule",
    "ContentPolicy",
    "ContentFilterConfig",
    # Audit Logging
    "AuditLogger",
    "AuditEvent",
    "AuditEventType",
    "AuditSeverity",
    "AuditContext",
    "AuditBackend",
    "MemoryAuditBackend",
    "FileAuditBackend",
    "AuditReport",
]
