"""
Security audit trail for logging and monitoring.

Provides comprehensive audit logging for security events,
access control, and compliance requirements.
"""

from __future__ import annotations

import json
import time
import hashlib
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Callable
from collections import deque


class AuditEventType(str, Enum):
    """Types of audit events."""
    
    # Authentication
    AUTH_SUCCESS = "auth_success"
    AUTH_FAILURE = "auth_failure"
    AUTH_LOGOUT = "auth_logout"
    TOKEN_ISSUED = "token_issued"
    TOKEN_REVOKED = "token_revoked"
    
    # Authorization
    ACCESS_GRANTED = "access_granted"
    ACCESS_DENIED = "access_denied"
    PERMISSION_CHANGE = "permission_change"
    
    # Data
    DATA_ACCESS = "data_access"
    DATA_MODIFY = "data_modify"
    DATA_DELETE = "data_delete"
    DATA_EXPORT = "data_export"
    
    # Security
    PII_DETECTED = "pii_detected"
    PII_REDACTED = "pii_redacted"
    CONTENT_BLOCKED = "content_blocked"
    INJECTION_DETECTED = "injection_detected"
    RATE_LIMITED = "rate_limited"
    
    # Agent
    AGENT_STARTED = "agent_started"
    AGENT_STOPPED = "agent_stopped"
    AGENT_ERROR = "agent_error"
    TOOL_CALLED = "tool_called"
    TOOL_BLOCKED = "tool_blocked"
    
    # System
    CONFIG_CHANGE = "config_change"
    POLICY_CHANGE = "policy_change"
    SYSTEM_ERROR = "system_error"
    
    # Custom
    CUSTOM = "custom"


class AuditSeverity(str, Enum):
    """Severity levels for audit events."""
    
    DEBUG = "debug"
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"


@dataclass
class AuditContext:
    """Context information for an audit event.
    
    Attributes:
        user_id: User identifier
        session_id: Session identifier
        agent_id: Agent identifier
        request_id: Request identifier
        ip_address: Client IP address
        user_agent: Client user agent
        metadata: Additional context
    """
    
    user_id: str | None = None
    session_id: str | None = None
    agent_id: str | None = None
    request_id: str | None = None
    ip_address: str | None = None
    user_agent: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "user_id": self.user_id,
            "session_id": self.session_id,
            "agent_id": self.agent_id,
            "request_id": self.request_id,
            "ip_address": self.ip_address,
            "user_agent": self.user_agent,
            "metadata": self.metadata,
        }


@dataclass
class AuditEvent:
    """An audit event record.
    
    Attributes:
        id: Unique event identifier
        event_type: Type of event
        severity: Severity level
        timestamp: Event timestamp
        message: Human-readable message
        context: Event context
        data: Event-specific data
        outcome: Outcome of the event
    """
    
    id: str
    event_type: AuditEventType
    severity: AuditSeverity
    timestamp: str
    message: str
    context: AuditContext = field(default_factory=AuditContext)
    data: dict[str, Any] = field(default_factory=dict)
    outcome: str = "success"
    
    @classmethod
    def create(
        cls,
        event_type: AuditEventType,
        message: str,
        severity: AuditSeverity = AuditSeverity.INFO,
        context: AuditContext | None = None,
        data: dict[str, Any] | None = None,
        outcome: str = "success",
    ) -> "AuditEvent":
        """Create a new audit event with auto-generated ID and timestamp."""
        event_id = hashlib.sha256(
            f"{time.time_ns()}{event_type.value}".encode()
        ).hexdigest()[:16]
        
        return cls(
            id=event_id,
            event_type=event_type,
            severity=severity,
            timestamp=datetime.now(timezone.utc).isoformat(),
            message=message,
            context=context or AuditContext(),
            data=data or {},
            outcome=outcome,
        )
    
    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "id": self.id,
            "event_type": self.event_type.value,
            "severity": self.severity.value,
            "timestamp": self.timestamp,
            "message": self.message,
            "context": self.context.to_dict(),
            "data": self.data,
            "outcome": self.outcome,
        }
    
    def to_json(self) -> str:
        """Convert to JSON string."""
        return json.dumps(self.to_dict())
    
    @property
    def signature(self) -> str:
        """Get event signature for integrity verification."""
        content = f"{self.id}{self.event_type.value}{self.timestamp}{self.message}"
        return hashlib.sha256(content.encode()).hexdigest()[:32]


class AuditBackend(ABC):
    """Abstract backend for storing audit events."""
    
    @abstractmethod
    def write(self, event: AuditEvent) -> None:
        """Write an event to the backend."""
        pass
    
    @abstractmethod
    def query(
        self,
        event_types: list[AuditEventType] | None = None,
        start_time: str | None = None,
        end_time: str | None = None,
        context_filter: dict[str, Any] | None = None,
        limit: int = 100,
    ) -> list[AuditEvent]:
        """Query events from the backend."""
        pass
    
    @abstractmethod
    def close(self) -> None:
        """Close the backend."""
        pass


class MemoryAuditBackend(AuditBackend):
    """In-memory audit backend for testing."""
    
    def __init__(self, max_events: int = 10000) -> None:
        self.max_events = max_events
        self.events: deque[AuditEvent] = deque(maxlen=max_events)
    
    def write(self, event: AuditEvent) -> None:
        """Write event to memory."""
        self.events.append(event)
    
    def query(
        self,
        event_types: list[AuditEventType] | None = None,
        start_time: str | None = None,
        end_time: str | None = None,
        context_filter: dict[str, Any] | None = None,
        limit: int = 100,
    ) -> list[AuditEvent]:
        """Query events from memory."""
        results = []
        
        for event in self.events:
            # Filter by event type
            if event_types and event.event_type not in event_types:
                continue
            
            # Filter by time range
            if start_time and event.timestamp < start_time:
                continue
            if end_time and event.timestamp > end_time:
                continue
            
            # Filter by context
            if context_filter:
                context_dict = event.context.to_dict()
                match = True
                for key, value in context_filter.items():
                    if context_dict.get(key) != value:
                        match = False
                        break
                if not match:
                    continue
            
            results.append(event)
            
            if len(results) >= limit:
                break
        
        return results
    
    def close(self) -> None:
        """Clear memory."""
        self.events.clear()
    
    def get_all(self) -> list[AuditEvent]:
        """Get all events."""
        return list(self.events)


class FileAuditBackend(AuditBackend):
    """File-based audit backend."""
    
    def __init__(
        self,
        file_path: str | Path,
        rotate_size_mb: int = 100,
        max_files: int = 10,
    ) -> None:
        """Initialize file backend.
        
        Args:
            file_path: Path to audit log file
            rotate_size_mb: Size in MB before rotation
            max_files: Maximum number of rotated files
        """
        self.file_path = Path(file_path)
        self.rotate_size_bytes = rotate_size_mb * 1024 * 1024
        self.max_files = max_files
        
        # Ensure directory exists
        self.file_path.parent.mkdir(parents=True, exist_ok=True)
        
        self._file = open(self.file_path, "a")
    
    def write(self, event: AuditEvent) -> None:
        """Write event to file."""
        self._file.write(event.to_json() + "\n")
        self._file.flush()
        
        # Check for rotation
        if self.file_path.stat().st_size > self.rotate_size_bytes:
            self._rotate()
    
    def _rotate(self) -> None:
        """Rotate log files."""
        self._file.close()
        
        # Rotate existing files
        for i in range(self.max_files - 1, 0, -1):
            old_path = self.file_path.with_suffix(f".{i}")
            new_path = self.file_path.with_suffix(f".{i + 1}")
            if old_path.exists():
                if new_path.exists():
                    new_path.unlink()
                old_path.rename(new_path)
        
        # Rotate current file
        rotated_path = self.file_path.with_suffix(".1")
        if rotated_path.exists():
            rotated_path.unlink()
        self.file_path.rename(rotated_path)
        
        # Open new file
        self._file = open(self.file_path, "a")
    
    def query(
        self,
        event_types: list[AuditEventType] | None = None,
        start_time: str | None = None,
        end_time: str | None = None,
        context_filter: dict[str, Any] | None = None,
        limit: int = 100,
    ) -> list[AuditEvent]:
        """Query events from file (reads from all rotated files)."""
        results = []
        files_to_read = [self.file_path]
        
        # Add rotated files
        for i in range(1, self.max_files + 1):
            rotated = self.file_path.with_suffix(f".{i}")
            if rotated.exists():
                files_to_read.append(rotated)
        
        for file_path in files_to_read:
            if not file_path.exists():
                continue
            
            with open(file_path, "r") as f:
                for line in f:
                    if len(results) >= limit:
                        return results
                    
                    try:
                        data = json.loads(line.strip())
                        event = AuditEvent(
                            id=data["id"],
                            event_type=AuditEventType(data["event_type"]),
                            severity=AuditSeverity(data["severity"]),
                            timestamp=data["timestamp"],
                            message=data["message"],
                            context=AuditContext(**data.get("context", {})),
                            data=data.get("data", {}),
                            outcome=data.get("outcome", "success"),
                        )
                        
                        # Apply filters
                        if event_types and event.event_type not in event_types:
                            continue
                        if start_time and event.timestamp < start_time:
                            continue
                        if end_time and event.timestamp > end_time:
                            continue
                        
                        if context_filter:
                            context_dict = event.context.to_dict()
                            match = True
                            for key, value in context_filter.items():
                                if context_dict.get(key) != value:
                                    match = False
                                    break
                            if not match:
                                continue
                        
                        results.append(event)
                    except (json.JSONDecodeError, KeyError):
                        continue
        
        return results
    
    def close(self) -> None:
        """Close the file."""
        self._file.close()


class AuditLogger:
    """Audit logger for security events.
    
    Provides a centralized logging system for security-relevant
    events with support for multiple backends.
    
    Example:
        ```python
        logger = AuditLogger()
        
        # Log an authentication event
        logger.log_auth(
            success=True,
            user_id="user123",
            message="User logged in successfully",
        )
        
        # Log PII detection
        logger.log_pii_detected(
            pii_types=["email", "phone"],
            action="redacted",
            agent_id="agent-1",
        )
        ```
    """
    
    def __init__(
        self,
        backend: AuditBackend | None = None,
        default_context: AuditContext | None = None,
    ) -> None:
        """Initialize audit logger.
        
        Args:
            backend: Storage backend (default: MemoryAuditBackend)
            default_context: Default context for all events
        """
        self.backend = backend or MemoryAuditBackend()
        self.default_context = default_context or AuditContext()
        self._handlers: list[Callable[[AuditEvent], None]] = []
    
    def add_handler(self, handler: Callable[[AuditEvent], None]) -> None:
        """Add an event handler for real-time processing."""
        self._handlers.append(handler)
    
    def remove_handler(self, handler: Callable[[AuditEvent], None]) -> None:
        """Remove an event handler."""
        self._handlers.remove(handler)
    
    def _merge_context(self, context: AuditContext | None) -> AuditContext:
        """Merge provided context with default context."""
        if not context:
            return self.default_context
        
        # Merge metadata
        merged_metadata = {**self.default_context.metadata, **context.metadata}
        
        return AuditContext(
            user_id=context.user_id or self.default_context.user_id,
            session_id=context.session_id or self.default_context.session_id,
            agent_id=context.agent_id or self.default_context.agent_id,
            request_id=context.request_id or self.default_context.request_id,
            ip_address=context.ip_address or self.default_context.ip_address,
            user_agent=context.user_agent or self.default_context.user_agent,
            metadata=merged_metadata,
        )
    
    def log(
        self,
        event_type: AuditEventType,
        message: str,
        severity: AuditSeverity = AuditSeverity.INFO,
        context: AuditContext | None = None,
        data: dict[str, Any] | None = None,
        outcome: str = "success",
    ) -> AuditEvent:
        """Log an audit event.
        
        Args:
            event_type: Type of event
            message: Human-readable message
            severity: Severity level
            context: Event context
            data: Additional data
            outcome: Event outcome
            
        Returns:
            Created audit event
        """
        event = AuditEvent.create(
            event_type=event_type,
            message=message,
            severity=severity,
            context=self._merge_context(context),
            data=data,
            outcome=outcome,
        )
        
        # Write to backend
        self.backend.write(event)
        
        # Call handlers
        for handler in self._handlers:
            try:
                handler(event)
            except Exception:
                pass  # Don't let handler errors affect logging
        
        return event
    
    def log_auth(
        self,
        success: bool,
        message: str,
        user_id: str | None = None,
        context: AuditContext | None = None,
        data: dict[str, Any] | None = None,
    ) -> AuditEvent:
        """Log an authentication event."""
        event_type = AuditEventType.AUTH_SUCCESS if success else AuditEventType.AUTH_FAILURE
        severity = AuditSeverity.INFO if success else AuditSeverity.WARNING
        
        ctx = context or AuditContext()
        if user_id:
            ctx.user_id = user_id
        
        return self.log(
            event_type=event_type,
            message=message,
            severity=severity,
            context=ctx,
            data=data,
            outcome="success" if success else "failure",
        )
    
    def log_access(
        self,
        granted: bool,
        resource: str,
        action: str,
        message: str | None = None,
        context: AuditContext | None = None,
        data: dict[str, Any] | None = None,
    ) -> AuditEvent:
        """Log an access control event."""
        event_type = AuditEventType.ACCESS_GRANTED if granted else AuditEventType.ACCESS_DENIED
        severity = AuditSeverity.INFO if granted else AuditSeverity.WARNING
        
        msg = message or f"Access {'granted' if granted else 'denied'} to {resource}"
        
        event_data = data or {}
        event_data["resource"] = resource
        event_data["action"] = action
        
        return self.log(
            event_type=event_type,
            message=msg,
            severity=severity,
            context=context,
            data=event_data,
            outcome="granted" if granted else "denied",
        )
    
    def log_pii_detected(
        self,
        pii_types: list[str],
        action: str,
        context: AuditContext | None = None,
        data: dict[str, Any] | None = None,
    ) -> AuditEvent:
        """Log PII detection event."""
        event_type = (
            AuditEventType.PII_REDACTED if action == "redacted"
            else AuditEventType.PII_DETECTED
        )
        
        event_data = data or {}
        event_data["pii_types"] = pii_types
        event_data["action"] = action
        
        return self.log(
            event_type=event_type,
            message=f"PII detected: {', '.join(pii_types)}. Action: {action}",
            severity=AuditSeverity.WARNING,
            context=context,
            data=event_data,
            outcome=action,
        )
    
    def log_content_blocked(
        self,
        categories: list[str],
        reason: str,
        context: AuditContext | None = None,
        data: dict[str, Any] | None = None,
    ) -> AuditEvent:
        """Log content blocking event."""
        event_data = data or {}
        event_data["categories"] = categories
        event_data["reason"] = reason
        
        return self.log(
            event_type=AuditEventType.CONTENT_BLOCKED,
            message=f"Content blocked: {', '.join(categories)}. Reason: {reason}",
            severity=AuditSeverity.WARNING,
            context=context,
            data=event_data,
            outcome="blocked",
        )
    
    def log_injection_detected(
        self,
        injection_type: str,
        confidence: float,
        context: AuditContext | None = None,
        data: dict[str, Any] | None = None,
    ) -> AuditEvent:
        """Log injection detection event."""
        severity = AuditSeverity.CRITICAL if confidence > 0.8 else AuditSeverity.WARNING
        
        event_data = data or {}
        event_data["injection_type"] = injection_type
        event_data["confidence"] = confidence
        
        return self.log(
            event_type=AuditEventType.INJECTION_DETECTED,
            message=f"Injection detected: {injection_type} (confidence: {confidence:.2f})",
            severity=severity,
            context=context,
            data=event_data,
            outcome="detected",
        )
    
    def log_tool_call(
        self,
        tool_name: str,
        allowed: bool,
        context: AuditContext | None = None,
        data: dict[str, Any] | None = None,
    ) -> AuditEvent:
        """Log tool call event."""
        event_type = AuditEventType.TOOL_CALLED if allowed else AuditEventType.TOOL_BLOCKED
        severity = AuditSeverity.INFO if allowed else AuditSeverity.WARNING
        
        event_data = data or {}
        event_data["tool_name"] = tool_name
        
        return self.log(
            event_type=event_type,
            message=f"Tool {'called' if allowed else 'blocked'}: {tool_name}",
            severity=severity,
            context=context,
            data=event_data,
            outcome="allowed" if allowed else "blocked",
        )
    
    def log_rate_limited(
        self,
        resource: str,
        limit: int,
        window: str,
        context: AuditContext | None = None,
        data: dict[str, Any] | None = None,
    ) -> AuditEvent:
        """Log rate limiting event."""
        event_data = data or {}
        event_data["resource"] = resource
        event_data["limit"] = limit
        event_data["window"] = window
        
        return self.log(
            event_type=AuditEventType.RATE_LIMITED,
            message=f"Rate limited: {resource} ({limit} per {window})",
            severity=AuditSeverity.WARNING,
            context=context,
            data=event_data,
            outcome="limited",
        )
    
    def query(
        self,
        event_types: list[AuditEventType] | None = None,
        start_time: str | None = None,
        end_time: str | None = None,
        context_filter: dict[str, Any] | None = None,
        limit: int = 100,
    ) -> list[AuditEvent]:
        """Query audit events.
        
        Args:
            event_types: Filter by event types
            start_time: Start of time range (ISO format)
            end_time: End of time range (ISO format)
            context_filter: Filter by context fields
            limit: Maximum number of results
            
        Returns:
            List of matching audit events
        """
        return self.backend.query(
            event_types=event_types,
            start_time=start_time,
            end_time=end_time,
            context_filter=context_filter,
            limit=limit,
        )
    
    def close(self) -> None:
        """Close the logger and backend."""
        self.backend.close()


class AuditReport:
    """Generate audit reports from logged events."""
    
    def __init__(self, logger: AuditLogger) -> None:
        """Initialize report generator."""
        self.logger = logger
    
    def summary(
        self,
        start_time: str | None = None,
        end_time: str | None = None,
    ) -> dict[str, Any]:
        """Generate summary report.
        
        Returns:
            Summary statistics
        """
        events = self.logger.query(
            start_time=start_time,
            end_time=end_time,
            limit=10000,
        )
        
        # Count by type
        by_type: dict[str, int] = {}
        by_severity: dict[str, int] = {}
        by_outcome: dict[str, int] = {}
        
        for event in events:
            type_key = event.event_type.value
            by_type[type_key] = by_type.get(type_key, 0) + 1
            
            severity_key = event.severity.value
            by_severity[severity_key] = by_severity.get(severity_key, 0) + 1
            
            by_outcome[event.outcome] = by_outcome.get(event.outcome, 0) + 1
        
        return {
            "total_events": len(events),
            "by_type": by_type,
            "by_severity": by_severity,
            "by_outcome": by_outcome,
            "time_range": {
                "start": start_time,
                "end": end_time,
            },
        }
    
    def security_events(
        self,
        start_time: str | None = None,
        end_time: str | None = None,
    ) -> list[AuditEvent]:
        """Get security-related events."""
        security_types = [
            AuditEventType.AUTH_FAILURE,
            AuditEventType.ACCESS_DENIED,
            AuditEventType.PII_DETECTED,
            AuditEventType.CONTENT_BLOCKED,
            AuditEventType.INJECTION_DETECTED,
            AuditEventType.RATE_LIMITED,
            AuditEventType.TOOL_BLOCKED,
        ]
        
        return self.logger.query(
            event_types=security_types,
            start_time=start_time,
            end_time=end_time,
        )
    
    def user_activity(
        self,
        user_id: str,
        start_time: str | None = None,
        end_time: str | None = None,
    ) -> list[AuditEvent]:
        """Get events for a specific user."""
        return self.logger.query(
            start_time=start_time,
            end_time=end_time,
            context_filter={"user_id": user_id},
        )
