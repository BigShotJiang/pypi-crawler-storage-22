"""
Content filtering for harmful content detection.

Provides detection and filtering of potentially harmful, inappropriate,
or policy-violating content in AI inputs and outputs.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable


class ContentCategory(str, Enum):
    """Categories of content violations."""
    
    # Harmful content
    VIOLENCE = "violence"
    SELF_HARM = "self_harm"
    HATE_SPEECH = "hate_speech"
    HARASSMENT = "harassment"
    
    # Adult content
    SEXUAL = "sexual"
    EXPLICIT = "explicit"
    
    # Illegal
    ILLEGAL_ACTIVITY = "illegal_activity"
    WEAPONS = "weapons"
    DRUGS = "drugs"
    
    # Deception
    MISINFORMATION = "misinformation"
    SCAM = "scam"
    PHISHING = "phishing"
    
    # Privacy
    DOXXING = "doxxing"
    STALKING = "stalking"
    
    # Harmful AI
    JAILBREAK = "jailbreak"
    PROMPT_INJECTION = "prompt_injection"
    
    # Policy
    POLICY_VIOLATION = "policy_violation"
    SPAM = "spam"
    
    # Other
    CUSTOM = "custom"
    UNKNOWN = "unknown"


class ContentSeverity(str, Enum):
    """Severity levels for content violations."""
    
    NONE = "none"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


@dataclass
class ContentViolation:
    """A detected content violation.
    
    Attributes:
        category: Category of violation
        severity: Severity level
        matched_text: Text that triggered the violation
        start: Start position in text
        end: End position in text
        confidence: Detection confidence (0-1)
        context: Surrounding context
        rule_id: ID of the rule that matched
    """
    
    category: ContentCategory
    severity: ContentSeverity
    matched_text: str
    start: int
    end: int
    confidence: float = 1.0
    context: str = ""
    rule_id: str = ""
    
    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "category": self.category.value,
            "severity": self.severity.value,
            "matched_text": self.matched_text,
            "position": {"start": self.start, "end": self.end},
            "confidence": self.confidence,
            "rule_id": self.rule_id,
        }


@dataclass
class FilterResult:
    """Result of content filtering.
    
    Attributes:
        is_safe: Whether content is safe
        violations: List of detected violations
        action: Recommended action
        filtered_text: Text with violations removed/replaced
        summary: Summary of violations by category
    """
    
    is_safe: bool = True
    violations: list[ContentViolation] = field(default_factory=list)
    action: str = "allow"
    filtered_text: str = ""
    summary: dict[str, int] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)
    
    def add_violation(self, violation: ContentViolation) -> None:
        """Add a violation."""
        self.is_safe = False
        self.violations.append(violation)
        
        category = violation.category.value
        self.summary[category] = self.summary.get(category, 0) + 1
        
        # Update action based on severity
        severity_order = [
            ContentSeverity.NONE,
            ContentSeverity.LOW,
            ContentSeverity.MEDIUM,
            ContentSeverity.HIGH,
            ContentSeverity.CRITICAL,
        ]
        
        if violation.severity == ContentSeverity.CRITICAL:
            self.action = "block"
        elif violation.severity == ContentSeverity.HIGH and self.action != "block":
            self.action = "block"
        elif violation.severity == ContentSeverity.MEDIUM and self.action not in ("block",):
            self.action = "warn"
    
    def get_max_severity(self) -> ContentSeverity:
        """Get the maximum severity of all violations."""
        if not self.violations:
            return ContentSeverity.NONE
        
        severity_order = [
            ContentSeverity.NONE,
            ContentSeverity.LOW,
            ContentSeverity.MEDIUM,
            ContentSeverity.HIGH,
            ContentSeverity.CRITICAL,
        ]
        
        max_severity = ContentSeverity.NONE
        for v in self.violations:
            if severity_order.index(v.severity) > severity_order.index(max_severity):
                max_severity = v.severity
        
        return max_severity
    
    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "is_safe": self.is_safe,
            "action": self.action,
            "max_severity": self.get_max_severity().value,
            "violation_count": len(self.violations),
            "violations": [v.to_dict() for v in self.violations],
            "summary": self.summary,
        }


@dataclass
class ContentRule:
    """A content filtering rule.
    
    Attributes:
        id: Unique rule identifier
        category: Category this rule detects
        severity: Severity of violations
        patterns: List of regex patterns
        keywords: List of keywords to match
        enabled: Whether rule is active
    """
    
    id: str
    category: ContentCategory
    severity: ContentSeverity
    patterns: list[str] = field(default_factory=list)
    keywords: list[str] = field(default_factory=list)
    enabled: bool = True
    case_sensitive: bool = False
    
    def __post_init__(self) -> None:
        """Compile patterns."""
        flags = 0 if self.case_sensitive else re.IGNORECASE
        self._compiled_patterns = [
            re.compile(p, flags) for p in self.patterns
        ]
        
        # Build keyword pattern
        if self.keywords:
            keyword_pattern = r'\b(?:' + '|'.join(
                re.escape(k) for k in self.keywords
            ) + r')\b'
            self._keyword_pattern = re.compile(keyword_pattern, flags)
        else:
            self._keyword_pattern = None
    
    def find_matches(self, text: str) -> list[ContentViolation]:
        """Find all matches in text."""
        if not self.enabled:
            return []
        
        violations = []
        
        # Check patterns
        for pattern in self._compiled_patterns:
            for match in pattern.finditer(text):
                violations.append(ContentViolation(
                    category=self.category,
                    severity=self.severity,
                    matched_text=match.group(),
                    start=match.start(),
                    end=match.end(),
                    rule_id=self.id,
                ))
        
        # Check keywords
        if self._keyword_pattern:
            for match in self._keyword_pattern.finditer(text):
                violations.append(ContentViolation(
                    category=self.category,
                    severity=self.severity,
                    matched_text=match.group(),
                    start=match.start(),
                    end=match.end(),
                    rule_id=self.id,
                ))
        
        return violations


class ContentFilter:
    """Content filter for detecting harmful content.
    
    Provides rule-based filtering with customizable rules and policies.
    
    Example:
        ```python
        filter = ContentFilter()
        
        result = filter.filter("Some potentially harmful text")
        
        if not result.is_safe:
            print(f"Violations: {result.summary}")
            print(f"Action: {result.action}")
        ```
    """
    
    def __init__(
        self,
        rules: list[ContentRule] | None = None,
        use_defaults: bool = True,
    ) -> None:
        """Initialize content filter.
        
        Args:
            rules: Custom rules to use
            use_defaults: Whether to include default rules
        """
        self.rules: list[ContentRule] = []
        
        if use_defaults:
            self.rules.extend(self._get_default_rules())
        
        if rules:
            self.rules.extend(rules)
    
    def _get_default_rules(self) -> list[ContentRule]:
        """Get default content rules."""
        return [
            # Jailbreak attempts
            ContentRule(
                id="jailbreak_001",
                category=ContentCategory.JAILBREAK,
                severity=ContentSeverity.HIGH,
                patterns=[
                    r'ignore\s+(?:all\s+)?(?:previous\s+)?instructions?',
                    r'disregard\s+(?:all\s+)?(?:previous\s+)?(?:rules?|instructions?|guidelines?)',
                    r'forget\s+(?:everything|all)\s+(?:you\s+)?(?:were\s+)?(?:told|instructed)',
                    r'you\s+are\s+now\s+(?:a\s+)?(?:new\s+)?(?:different\s+)?(?:AI|assistant|bot)',
                    r'pretend\s+(?:you\s+are|to\s+be)\s+(?:a\s+)?(?:different|new)',
                ],
            ),
            
            # Prompt injection
            ContentRule(
                id="injection_001",
                category=ContentCategory.PROMPT_INJECTION,
                severity=ContentSeverity.HIGH,
                patterns=[
                    r'system\s*:\s*(?:you\s+are|act\s+as)',
                    r'<\s*system\s*>',
                    r'\[\[\s*SYSTEM\s*\]\]',
                    r'---\s*BEGIN\s+(?:NEW\s+)?INSTRUCTIONS?\s*---',
                ],
            ),
            
            # Violence
            ContentRule(
                id="violence_001",
                category=ContentCategory.VIOLENCE,
                severity=ContentSeverity.HIGH,
                patterns=[
                    r'(?:how\s+to\s+)?(?:make|build|create)\s+(?:a\s+)?(?:bomb|explosive)',
                    r'(?:how\s+to\s+)?(?:kill|murder|assassinate)\s+(?:a\s+)?person',
                ],
            ),
            
            # Hate speech indicators
            ContentRule(
                id="hate_001",
                category=ContentCategory.HATE_SPEECH,
                severity=ContentSeverity.HIGH,
                patterns=[
                    r'(?:all\s+)?(?:\w+)\s+(?:are|should)\s+(?:die|be\s+killed)',
                    r'(?:death\s+to|kill\s+all)\s+(?:\w+)',
                ],
            ),
            
            # Phishing patterns
            ContentRule(
                id="phishing_001",
                category=ContentCategory.PHISHING,
                severity=ContentSeverity.MEDIUM,
                patterns=[
                    r'(?:verify|confirm)\s+your\s+(?:account|password|credentials)',
                    r'click\s+(?:this\s+)?link\s+(?:to\s+)?(?:verify|confirm)',
                    r'your\s+account\s+(?:has\s+been|will\s+be)\s+(?:suspended|locked)',
                ],
            ),
            
            # Spam indicators
            ContentRule(
                id="spam_001",
                category=ContentCategory.SPAM,
                severity=ContentSeverity.LOW,
                patterns=[
                    r'(?:click\s+here|act\s+now|limited\s+time)\s+(?:offer)?',
                    r'(?:congratulations|you\s+have\s+won)\s+(?:\$|dollars?|prize)',
                    r'(?:no\s+obligation|risk\s+free|money\s+back)\s+guarantee',
                ],
            ),
        ]
    
    def add_rule(self, rule: ContentRule) -> None:
        """Add a custom rule."""
        self.rules.append(rule)
    
    def remove_rule(self, rule_id: str) -> bool:
        """Remove a rule by ID."""
        for i, rule in enumerate(self.rules):
            if rule.id == rule_id:
                del self.rules[i]
                return True
        return False
    
    def enable_rule(self, rule_id: str) -> bool:
        """Enable a rule by ID."""
        for rule in self.rules:
            if rule.id == rule_id:
                rule.enabled = True
                return True
        return False
    
    def disable_rule(self, rule_id: str) -> bool:
        """Disable a rule by ID."""
        for rule in self.rules:
            if rule.id == rule_id:
                rule.enabled = False
                return True
        return False
    
    def filter(self, text: str) -> FilterResult:
        """Filter content for violations.
        
        Args:
            text: Text to filter
            
        Returns:
            Filter result with violations
        """
        result = FilterResult(filtered_text=text)
        
        for rule in self.rules:
            violations = rule.find_matches(text)
            for v in violations:
                result.add_violation(v)
        
        # Sort violations by position
        result.violations.sort(key=lambda v: v.start)
        
        return result
    
    def filter_and_replace(
        self,
        text: str,
        replacement: str = "[FILTERED]",
    ) -> FilterResult:
        """Filter content and replace violations.
        
        Args:
            text: Text to filter
            replacement: Replacement text
            
        Returns:
            Filter result with filtered text
        """
        result = self.filter(text)
        
        if not result.violations:
            result.filtered_text = text
            return result
        
        # Sort violations by position (reverse for replacement)
        sorted_violations = sorted(
            result.violations,
            key=lambda v: v.start,
            reverse=True,
        )
        
        filtered = text
        for v in sorted_violations:
            filtered = filtered[:v.start] + replacement + filtered[v.end:]
        
        result.filtered_text = filtered
        return result
    
    def is_safe(self, text: str) -> bool:
        """Quick check if content is safe.
        
        Args:
            text: Text to check
            
        Returns:
            True if no violations detected
        """
        return self.filter(text).is_safe
    
    def get_categories(self, text: str) -> list[ContentCategory]:
        """Get list of detected categories.
        
        Args:
            text: Text to check
            
        Returns:
            List of detected content categories
        """
        result = self.filter(text)
        return list(set(v.category for v in result.violations))


class ContentPolicy:
    """Policy for content filtering decisions.
    
    Defines how to handle different categories and severities.
    """
    
    def __init__(
        self,
        blocked_categories: list[ContentCategory] | None = None,
        max_allowed_severity: ContentSeverity = ContentSeverity.LOW,
        custom_handlers: dict[ContentCategory, Callable[[ContentViolation], str]] | None = None,
    ) -> None:
        """Initialize content policy.
        
        Args:
            blocked_categories: Categories to always block
            max_allowed_severity: Maximum severity to allow
            custom_handlers: Custom handlers per category
        """
        self.blocked_categories = set(blocked_categories) if blocked_categories else set()
        self.max_allowed_severity = max_allowed_severity
        self.custom_handlers = custom_handlers or {}
        
        # Default blocked categories
        if not blocked_categories:
            self.blocked_categories = {
                ContentCategory.VIOLENCE,
                ContentCategory.HATE_SPEECH,
                ContentCategory.ILLEGAL_ACTIVITY,
                ContentCategory.JAILBREAK,
                ContentCategory.PROMPT_INJECTION,
            }
    
    def evaluate(self, result: FilterResult) -> dict[str, Any]:
        """Evaluate filter result against policy.
        
        Returns:
            Dictionary with action and details
        """
        if result.is_safe:
            return {
                "action": "allow",
                "reasons": [],
                "blocked_violations": [],
            }
        
        action = "allow"
        reasons: list[str] = []
        blocked_violations: list[ContentViolation] = []
        
        severity_order = [
            ContentSeverity.NONE,
            ContentSeverity.LOW,
            ContentSeverity.MEDIUM,
            ContentSeverity.HIGH,
            ContentSeverity.CRITICAL,
        ]
        
        max_severity_idx = severity_order.index(self.max_allowed_severity)
        
        for violation in result.violations:
            # Check blocked categories
            if violation.category in self.blocked_categories:
                action = "block"
                reasons.append(f"Blocked category: {violation.category.value}")
                blocked_violations.append(violation)
                continue
            
            # Check severity
            violation_severity_idx = severity_order.index(violation.severity)
            if violation_severity_idx > max_severity_idx:
                action = "block"
                reasons.append(
                    f"Severity {violation.severity.value} exceeds max "
                    f"allowed {self.max_allowed_severity.value}"
                )
                blocked_violations.append(violation)
        
        return {
            "action": action,
            "reasons": reasons,
            "blocked_violations": blocked_violations,
            "max_severity": result.get_max_severity().value,
        }


@dataclass
class ContentFilterConfig:
    """Configuration for content filter."""
    
    enabled: bool = True
    use_default_rules: bool = True
    custom_rules: list[dict[str, Any]] = field(default_factory=list)
    blocked_categories: list[str] = field(default_factory=list)
    max_severity: str = "low"
    
    def create_filter(self) -> ContentFilter:
        """Create content filter from config."""
        custom_rules = []
        for rule_dict in self.custom_rules:
            custom_rules.append(ContentRule(
                id=rule_dict.get("id", "custom"),
                category=ContentCategory(rule_dict.get("category", "custom")),
                severity=ContentSeverity(rule_dict.get("severity", "medium")),
                patterns=rule_dict.get("patterns", []),
                keywords=rule_dict.get("keywords", []),
            ))
        
        return ContentFilter(
            rules=custom_rules,
            use_defaults=self.use_default_rules,
        )
    
    def create_policy(self) -> ContentPolicy:
        """Create content policy from config."""
        blocked = [ContentCategory(c) for c in self.blocked_categories]
        return ContentPolicy(
            blocked_categories=blocked,
            max_allowed_severity=ContentSeverity(self.max_severity),
        )
