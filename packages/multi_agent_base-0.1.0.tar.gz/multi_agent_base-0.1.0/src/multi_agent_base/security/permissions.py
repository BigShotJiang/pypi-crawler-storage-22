"""
Permission controls for agents and tools.

Provides fine-grained permission management.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum, Flag, auto
from typing import Any


class Permission(Flag):
    """Permission flags for operations."""
    
    NONE = 0
    READ = auto()
    WRITE = auto()
    EXECUTE = auto()
    DELETE = auto()
    ADMIN = auto()
    
    # Composite permissions
    READ_WRITE = READ | WRITE
    FULL = READ | WRITE | EXECUTE | DELETE
    ALL = READ | WRITE | EXECUTE | DELETE | ADMIN


class ToolPermission(str, Enum):
    """Permission levels for tool execution."""
    
    DENY = "deny"
    ASK = "ask"
    ALLOW = "allow"
    ALLOW_ONCE = "allow_once"


@dataclass
class PermissionRule:
    """A permission rule.
    
    Attributes:
        resource: Resource pattern (e.g., "file:*", "tool:web_search")
        permission: Permission level
        conditions: Additional conditions
    """
    
    resource: str
    permission: Permission | ToolPermission
    conditions: dict[str, Any] = field(default_factory=dict)
    
    def matches(self, resource: str) -> bool:
        """Check if rule matches a resource.
        
        Args:
            resource: Resource to check
            
        Returns:
            True if rule matches
        """
        if self.resource == "*":
            return True
        
        if self.resource.endswith("*"):
            prefix = self.resource[:-1]
            return resource.startswith(prefix)
        
        return self.resource == resource


class PermissionSet:
    """A set of permissions for an agent or user.
    
    Example:
        ```python
        permissions = PermissionSet()
        
        # Allow file reading
        permissions.grant("file:*", Permission.READ)
        
        # Allow specific tool
        permissions.grant_tool("web_search", ToolPermission.ALLOW)
        
        # Check permission
        if permissions.can("file:/path/to/file", Permission.READ):
            # Read file
            pass
        ```
    """
    
    def __init__(self, default_permission: Permission = Permission.NONE) -> None:
        """Initialize permission set.
        
        Args:
            default_permission: Default permission for unspecified resources
        """
        self.default_permission = default_permission
        self._rules: list[PermissionRule] = []
        self._tool_permissions: dict[str, ToolPermission] = {}
    
    def grant(
        self,
        resource: str,
        permission: Permission,
        conditions: dict[str, Any] | None = None,
    ) -> None:
        """Grant permission on a resource.
        
        Args:
            resource: Resource pattern
            permission: Permission to grant
            conditions: Optional conditions
        """
        self._rules.append(PermissionRule(
            resource=resource,
            permission=permission,
            conditions=conditions or {},
        ))
    
    def revoke(self, resource: str) -> bool:
        """Revoke all permissions on a resource.
        
        Args:
            resource: Resource pattern
            
        Returns:
            True if any rules were removed
        """
        original_count = len(self._rules)
        self._rules = [r for r in self._rules if r.resource != resource]
        return len(self._rules) < original_count
    
    def grant_tool(
        self,
        tool_name: str,
        permission: ToolPermission,
    ) -> None:
        """Grant permission for a tool.
        
        Args:
            tool_name: Tool name
            permission: Tool permission level
        """
        self._tool_permissions[tool_name] = permission
    
    def revoke_tool(self, tool_name: str) -> bool:
        """Revoke tool permission.
        
        Args:
            tool_name: Tool name
            
        Returns:
            True if permission was revoked
        """
        if tool_name in self._tool_permissions:
            del self._tool_permissions[tool_name]
            return True
        return False
    
    def can(self, resource: str, permission: Permission) -> bool:
        """Check if permission is granted.
        
        Args:
            resource: Resource to check
            permission: Required permission
            
        Returns:
            True if permission is granted
        """
        # Find matching rules (most specific first)
        matching_rules = [r for r in self._rules if r.matches(resource)]
        
        if not matching_rules:
            return (self.default_permission & permission) == permission
        
        # Use most specific rule (longest pattern)
        matching_rules.sort(key=lambda r: len(r.resource), reverse=True)
        rule = matching_rules[0]
        
        if isinstance(rule.permission, Permission):
            return (rule.permission & permission) == permission
        
        return False
    
    def can_use_tool(self, tool_name: str) -> ToolPermission:
        """Check tool permission.
        
        Args:
            tool_name: Tool name
            
        Returns:
            Tool permission level
        """
        return self._tool_permissions.get(tool_name, ToolPermission.ASK)
    
    def get_permissions(self, resource: str) -> Permission:
        """Get all permissions for a resource.
        
        Args:
            resource: Resource to check
            
        Returns:
            Combined permissions
        """
        result = self.default_permission
        
        for rule in self._rules:
            if rule.matches(resource) and isinstance(rule.permission, Permission):
                result |= rule.permission
        
        return result
    
    def list_rules(self) -> list[PermissionRule]:
        """Get all permission rules.
        
        Returns:
            List of permission rules
        """
        return list(self._rules)
    
    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary.
        
        Returns:
            Dictionary representation
        """
        return {
            "default": self.default_permission.name,
            "rules": [
                {
                    "resource": r.resource,
                    "permission": r.permission.name if hasattr(r.permission, 'name') else str(r.permission),
                    "conditions": r.conditions,
                }
                for r in self._rules
            ],
            "tools": {
                name: perm.value
                for name, perm in self._tool_permissions.items()
            },
        }


def check_permission(
    permissions: PermissionSet,
    resource: str,
    required: Permission,
) -> bool:
    """Check if permission is granted.
    
    Args:
        permissions: Permission set
        resource: Resource to check
        required: Required permission
        
    Returns:
        True if permission is granted
    """
    return permissions.can(resource, required)


class PermissionDenied(Exception):
    """Exception raised when permission is denied.
    
    Attributes:
        resource: Resource that was accessed
        permission: Permission that was denied
    """
    
    def __init__(
        self,
        resource: str,
        permission: Permission,
        message: str | None = None,
    ) -> None:
        self.resource = resource
        self.permission = permission
        super().__init__(
            message or f"Permission denied: {permission.name} on {resource}"
        )


def require_permission(
    permissions: PermissionSet,
    resource: str,
    required: Permission,
) -> None:
    """Require a permission or raise exception.
    
    Args:
        permissions: Permission set
        resource: Resource to check
        required: Required permission
        
    Raises:
        PermissionDenied: If permission is not granted
    """
    if not permissions.can(resource, required):
        raise PermissionDenied(resource, required)


class PermissionContext:
    """Context manager for temporary permission elevation.
    
    Example:
        ```python
        permissions = PermissionSet()
        
        with PermissionContext(permissions, "admin:*", Permission.ALL):
            # Temporarily has admin access
            do_admin_stuff()
        # Admin access revoked
        ```
    """
    
    def __init__(
        self,
        permissions: PermissionSet,
        resource: str,
        permission: Permission,
    ) -> None:
        """Initialize permission context.
        
        Args:
            permissions: Permission set to modify
            resource: Resource to grant access to
            permission: Permission to grant
        """
        self.permissions = permissions
        self.resource = resource
        self.permission = permission
        self._rule: PermissionRule | None = None
    
    def __enter__(self) -> "PermissionContext":
        """Enter context and grant permission."""
        self._rule = PermissionRule(
            resource=self.resource,
            permission=self.permission,
        )
        self.permissions._rules.append(self._rule)
        return self
    
    def __exit__(self, *args: Any) -> None:
        """Exit context and revoke permission."""
        if self._rule in self.permissions._rules:
            self.permissions._rules.remove(self._rule)
