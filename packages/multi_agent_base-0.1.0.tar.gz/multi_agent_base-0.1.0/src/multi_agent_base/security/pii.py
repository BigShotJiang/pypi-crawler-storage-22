"""
PII (Personally Identifiable Information) Detection and Redaction.

Provides detection, classification, and redaction of personal data
to ensure compliance and privacy protection.
"""

from __future__ import annotations

import re
import hashlib
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable


class PIIType(str, Enum):
    """Types of personally identifiable information."""
    
    # Contact Information
    EMAIL = "email"
    PHONE = "phone"
    ADDRESS = "address"
    
    # Identity Documents
    SSN = "ssn"  # Social Security Number
    PASSPORT = "passport"
    DRIVERS_LICENSE = "drivers_license"
    NATIONAL_ID = "national_id"
    
    # Financial
    CREDIT_CARD = "credit_card"
    BANK_ACCOUNT = "bank_account"
    IBAN = "iban"
    
    # Personal
    NAME = "name"
    DATE_OF_BIRTH = "date_of_birth"
    AGE = "age"
    
    # Medical
    MEDICAL_RECORD = "medical_record"
    HEALTH_INFO = "health_info"
    
    # Network
    IP_ADDRESS = "ip_address"
    MAC_ADDRESS = "mac_address"
    
    # Authentication
    PASSWORD = "password"
    API_KEY = "api_key"
    
    # Other
    CUSTOM = "custom"
    UNKNOWN = "unknown"


class PIISeverity(str, Enum):
    """Severity level of PII detection."""
    
    LOW = "low"  # Non-sensitive identifiers
    MEDIUM = "medium"  # Contact information
    HIGH = "high"  # Financial, government IDs
    CRITICAL = "critical"  # Passwords, secret keys


@dataclass
class PIIMatch:
    """A detected PII instance.
    
    Attributes:
        pii_type: Type of PII detected
        value: Original detected value
        start: Start position in text
        end: End position in text
        severity: Severity level
        confidence: Detection confidence (0-1)
        context: Surrounding context for review
    """
    
    pii_type: PIIType
    value: str
    start: int
    end: int
    severity: PIISeverity = PIISeverity.MEDIUM
    confidence: float = 1.0
    context: str = ""
    
    @property
    def masked_value(self) -> str:
        """Get masked version of the value."""
        if len(self.value) <= 4:
            return "*" * len(self.value)
        return self.value[:2] + "*" * (len(self.value) - 4) + self.value[-2:]
    
    @property
    def hashed_value(self) -> str:
        """Get SHA-256 hash of the value."""
        return hashlib.sha256(self.value.encode()).hexdigest()[:16]


@dataclass
class PIIDetectionResult:
    """Result of PII detection.
    
    Attributes:
        has_pii: Whether PII was detected
        matches: List of PII matches
        redacted_text: Text with PII redacted
        summary: Summary of detected PII types
    """
    
    has_pii: bool = False
    matches: list[PIIMatch] = field(default_factory=list)
    redacted_text: str = ""
    summary: dict[str, int] = field(default_factory=dict)
    
    def add_match(self, match: PIIMatch) -> None:
        """Add a PII match."""
        self.has_pii = True
        self.matches.append(match)
        
        type_name = match.pii_type.value
        self.summary[type_name] = self.summary.get(type_name, 0) + 1
    
    def get_severity_score(self) -> float:
        """Calculate overall severity score (0-1)."""
        if not self.matches:
            return 0.0
        
        severity_weights = {
            PIISeverity.LOW: 0.25,
            PIISeverity.MEDIUM: 0.5,
            PIISeverity.HIGH: 0.75,
            PIISeverity.CRITICAL: 1.0,
        }
        
        total_weight = sum(
            severity_weights[m.severity] * m.confidence
            for m in self.matches
        )
        return min(1.0, total_weight / len(self.matches))
    
    def get_critical_matches(self) -> list[PIIMatch]:
        """Get only critical severity matches."""
        return [m for m in self.matches if m.severity == PIISeverity.CRITICAL]
    
    def get_matches_by_type(self, pii_type: PIIType) -> list[PIIMatch]:
        """Get matches of a specific type."""
        return [m for m in self.matches if m.pii_type == pii_type]


class PIIPattern:
    """A pattern for detecting PII."""
    
    def __init__(
        self,
        pii_type: PIIType,
        pattern: str,
        severity: PIISeverity = PIISeverity.MEDIUM,
        validator: Callable[[str], bool] | None = None,
        redact_format: str = "[{type}]",
    ) -> None:
        """Initialize PII pattern.
        
        Args:
            pii_type: Type of PII this pattern detects
            pattern: Regular expression pattern
            severity: Severity level
            validator: Optional validation function
            redact_format: Format string for redaction
        """
        self.pii_type = pii_type
        self.pattern = re.compile(pattern, re.IGNORECASE)
        self.severity = severity
        self.validator = validator
        self.redact_format = redact_format
    
    def find_matches(self, text: str) -> list[PIIMatch]:
        """Find all matches in text."""
        matches = []
        
        for match in self.pattern.finditer(text):
            value = match.group()
            
            # Validate if validator provided
            if self.validator and not self.validator(value):
                continue
            
            # Get context (20 chars before and after)
            start = max(0, match.start() - 20)
            end = min(len(text), match.end() + 20)
            context = text[start:end]
            
            matches.append(PIIMatch(
                pii_type=self.pii_type,
                value=value,
                start=match.start(),
                end=match.end(),
                severity=self.severity,
                confidence=1.0,
                context=context,
            ))
        
        return matches
    
    def redact(self, text: str) -> str:
        """Redact matches in text."""
        replacement = self.redact_format.format(type=self.pii_type.value.upper())
        return self.pattern.sub(replacement, text)


def validate_credit_card(number: str) -> bool:
    """Validate credit card number using Luhn algorithm."""
    digits = [int(d) for d in re.sub(r'\D', '', number)]
    if len(digits) < 13 or len(digits) > 19:
        return False
    
    # Luhn algorithm
    checksum = 0
    for i, digit in enumerate(reversed(digits)):
        if i % 2 == 1:
            digit *= 2
            if digit > 9:
                digit -= 9
        checksum += digit
    
    return checksum % 10 == 0


def validate_ssn(ssn: str) -> bool:
    """Validate SSN format."""
    digits = re.sub(r'\D', '', ssn)
    if len(digits) != 9:
        return False
    
    # Check for invalid patterns
    if digits[:3] in ('000', '666') or digits[:3].startswith('9'):
        return False
    if digits[3:5] == '00' or digits[5:] == '0000':
        return False
    
    return True


def validate_email(email: str) -> bool:
    """Validate email format."""
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return bool(re.match(pattern, email))


class PIIDetector:
    """Detects and redacts PII in text.
    
    Supports multiple PII types including emails, phone numbers,
    credit cards, SSNs, and more.
    
    Example:
        ```python
        detector = PIIDetector()
        
        result = detector.detect(
            "Contact John at john@example.com or 555-123-4567"
        )
        
        print(f"Found PII: {result.has_pii}")
        print(f"Redacted: {result.redacted_text}")
        ```
    """
    
    # Default patterns for common PII types
    DEFAULT_PATTERNS: list[PIIPattern] = [
        # Email
        PIIPattern(
            PIIType.EMAIL,
            r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
            PIISeverity.MEDIUM,
            validate_email,
        ),
        
        # Phone numbers (US format)
        PIIPattern(
            PIIType.PHONE,
            r'\b(?:\+1[-.\s]?)?(?:\(?[0-9]{3}\)?[-.\s]?)?[0-9]{3}[-.\s]?[0-9]{4}\b',
            PIISeverity.MEDIUM,
        ),
        
        # Credit card
        PIIPattern(
            PIIType.CREDIT_CARD,
            r'\b(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14}|3[47][0-9]{13}|6(?:011|5[0-9]{2})[0-9]{12})\b',
            PIISeverity.HIGH,
            validate_credit_card,
        ),
        
        # Credit card with separators
        PIIPattern(
            PIIType.CREDIT_CARD,
            r'\b(?:[0-9]{4}[-\s]?){3}[0-9]{4}\b',
            PIISeverity.HIGH,
        ),
        
        # SSN
        PIIPattern(
            PIIType.SSN,
            r'\b[0-9]{3}[-\s]?[0-9]{2}[-\s]?[0-9]{4}\b',
            PIISeverity.HIGH,
            validate_ssn,
        ),
        
        # IP Address
        PIIPattern(
            PIIType.IP_ADDRESS,
            r'\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b',
            PIISeverity.LOW,
        ),
        
        # Date of birth patterns
        PIIPattern(
            PIIType.DATE_OF_BIRTH,
            r'\b(?:DOB|Date of Birth|Birthday)[:\s]+[0-9]{1,2}[/-][0-9]{1,2}[/-][0-9]{2,4}\b',
            PIISeverity.MEDIUM,
        ),
        
        # API Keys (common formats)
        PIIPattern(
            PIIType.API_KEY,
            r'\b(?:sk-|pk-|api[_-]?key[_-]?)[a-zA-Z0-9]{20,}\b',
            PIISeverity.CRITICAL,
        ),
        
        # Generic secret/password in context
        PIIPattern(
            PIIType.PASSWORD,
            r'(?:password|passwd|pwd)[:\s=]+[^\s]{4,}',
            PIISeverity.CRITICAL,
        ),
        
        # AWS Access Key
        PIIPattern(
            PIIType.API_KEY,
            r'\bAKIA[0-9A-Z]{16}\b',
            PIISeverity.CRITICAL,
        ),
        
        # IBAN
        PIIPattern(
            PIIType.IBAN,
            r'\b[A-Z]{2}[0-9]{2}[A-Z0-9]{4}[0-9]{7}(?:[A-Z0-9]?){0,16}\b',
            PIISeverity.HIGH,
        ),
        
        # MAC Address
        PIIPattern(
            PIIType.MAC_ADDRESS,
            r'\b(?:[0-9A-Fa-f]{2}[:-]){5}[0-9A-Fa-f]{2}\b',
            PIISeverity.LOW,
        ),
    ]
    
    def __init__(
        self,
        patterns: list[PIIPattern] | None = None,
        use_defaults: bool = True,
        context_window: int = 20,
    ) -> None:
        """Initialize PII detector.
        
        Args:
            patterns: Custom patterns to use
            use_defaults: Whether to include default patterns
            context_window: Characters of context to include
        """
        self.patterns: list[PIIPattern] = []
        self.context_window = context_window
        
        if use_defaults:
            self.patterns.extend(self.DEFAULT_PATTERNS)
        
        if patterns:
            self.patterns.extend(patterns)
    
    def add_pattern(self, pattern: PIIPattern) -> None:
        """Add a custom pattern."""
        self.patterns.append(pattern)
    
    def detect(self, text: str) -> PIIDetectionResult:
        """Detect PII in text.
        
        Args:
            text: Text to analyze
            
        Returns:
            Detection result with matches
        """
        result = PIIDetectionResult()
        
        for pattern in self.patterns:
            matches = pattern.find_matches(text)
            for match in matches:
                result.add_match(match)
        
        # Sort matches by position
        result.matches.sort(key=lambda m: m.start)
        
        # Generate redacted text
        result.redacted_text = self.redact(text)
        
        return result
    
    def redact(
        self,
        text: str,
        pii_types: list[PIIType] | None = None,
        replacement_format: str = "[{type}]",
    ) -> str:
        """Redact PII from text.
        
        Args:
            text: Text to redact
            pii_types: Specific types to redact (None = all)
            replacement_format: Format for replacement text
            
        Returns:
            Redacted text
        """
        result = text
        
        for pattern in self.patterns:
            if pii_types and pattern.pii_type not in pii_types:
                continue
            
            replacement = replacement_format.format(type=pattern.pii_type.value.upper())
            result = pattern.pattern.sub(replacement, result)
        
        return result
    
    def mask(
        self,
        text: str,
        pii_types: list[PIIType] | None = None,
    ) -> str:
        """Mask PII in text (partial redaction).
        
        Args:
            text: Text to mask
            pii_types: Specific types to mask (None = all)
            
        Returns:
            Masked text
        """
        result = PIIDetectionResult()
        
        for pattern in self.patterns:
            if pii_types and pattern.pii_type not in pii_types:
                continue
            
            matches = pattern.find_matches(text)
            for match in matches:
                result.add_match(match)
        
        # Sort by position (reverse order for replacement)
        result.matches.sort(key=lambda m: m.start, reverse=True)
        
        # Apply masking
        masked_text = text
        for match in result.matches:
            masked_text = (
                masked_text[:match.start] +
                match.masked_value +
                masked_text[match.end:]
            )
        
        return masked_text
    
    def anonymize(
        self,
        text: str,
        pii_types: list[PIIType] | None = None,
        consistent: bool = True,
    ) -> tuple[str, dict[str, str]]:
        """Anonymize PII with consistent replacements.
        
        Args:
            text: Text to anonymize
            pii_types: Specific types to anonymize (None = all)
            consistent: Use consistent replacements for same value
            
        Returns:
            Tuple of (anonymized text, mapping of original to anonymous)
        """
        mapping: dict[str, str] = {}
        counters: dict[PIIType, int] = {}
        
        result = PIIDetectionResult()
        
        for pattern in self.patterns:
            if pii_types and pattern.pii_type not in pii_types:
                continue
            
            matches = pattern.find_matches(text)
            for match in matches:
                result.add_match(match)
        
        # Sort by position (reverse order for replacement)
        result.matches.sort(key=lambda m: m.start, reverse=True)
        
        anonymized = text
        
        for match in result.matches:
            if consistent and match.value in mapping:
                replacement = mapping[match.value]
            else:
                counter = counters.get(match.pii_type, 0) + 1
                counters[match.pii_type] = counter
                replacement = f"[{match.pii_type.value.upper()}_{counter}]"
                mapping[match.value] = replacement
            
            anonymized = (
                anonymized[:match.start] +
                replacement +
                anonymized[match.end:]
            )
        
        return anonymized, mapping


class PIIRedactor(ABC):
    """Abstract base class for PII redaction strategies."""
    
    @abstractmethod
    def redact(self, match: PIIMatch) -> str:
        """Redact a PII match."""
        pass


class PlaceholderRedactor(PIIRedactor):
    """Redacts PII with type placeholders."""
    
    def __init__(self, format_string: str = "[{type}]") -> None:
        self.format_string = format_string
    
    def redact(self, match: PIIMatch) -> str:
        return self.format_string.format(type=match.pii_type.value.upper())


class MaskingRedactor(PIIRedactor):
    """Redacts PII with partial masking."""
    
    def __init__(self, mask_char: str = "*", visible_chars: int = 2) -> None:
        self.mask_char = mask_char
        self.visible_chars = visible_chars
    
    def redact(self, match: PIIMatch) -> str:
        value = match.value
        if len(value) <= self.visible_chars * 2:
            return self.mask_char * len(value)
        
        return (
            value[:self.visible_chars] +
            self.mask_char * (len(value) - self.visible_chars * 2) +
            value[-self.visible_chars:]
        )


class HashRedactor(PIIRedactor):
    """Redacts PII with hashed values."""
    
    def __init__(self, prefix: str = "HASH_", length: int = 8) -> None:
        self.prefix = prefix
        self.length = length
    
    def redact(self, match: PIIMatch) -> str:
        hash_value = hashlib.sha256(match.value.encode()).hexdigest()
        return f"{self.prefix}{hash_value[:self.length]}"


class PIIPolicy:
    """Policy for handling detected PII.
    
    Defines rules for what actions to take when PII is detected.
    """
    
    def __init__(
        self,
        block_critical: bool = True,
        redact_high: bool = True,
        warn_medium: bool = True,
        log_all: bool = True,
        allowed_types: list[PIIType] | None = None,
        blocked_types: list[PIIType] | None = None,
    ) -> None:
        """Initialize PII policy.
        
        Args:
            block_critical: Block messages with critical PII
            redact_high: Auto-redact high severity PII
            warn_medium: Warn about medium severity PII
            log_all: Log all PII detections
            allowed_types: PII types to allow (whitelist)
            blocked_types: PII types to block (blacklist)
        """
        self.block_critical = block_critical
        self.redact_high = redact_high
        self.warn_medium = warn_medium
        self.log_all = log_all
        self.allowed_types = set(allowed_types) if allowed_types else None
        self.blocked_types = set(blocked_types) if blocked_types else set()
    
    def evaluate(self, result: PIIDetectionResult) -> dict[str, Any]:
        """Evaluate detection result against policy.
        
        Returns:
            Dictionary with action, reasons, and details
        """
        action = "allow"
        reasons: list[str] = []
        should_redact: list[PIIMatch] = []
        
        for match in result.matches:
            # Check blocked types
            if match.pii_type in self.blocked_types:
                action = "block"
                reasons.append(f"Blocked PII type: {match.pii_type.value}")
                continue
            
            # Check allowed types
            if self.allowed_types and match.pii_type not in self.allowed_types:
                if match.severity in (PIISeverity.HIGH, PIISeverity.CRITICAL):
                    action = "block"
                    reasons.append(f"Non-allowed PII type: {match.pii_type.value}")
                continue
            
            # Apply severity rules
            if match.severity == PIISeverity.CRITICAL and self.block_critical:
                action = "block"
                reasons.append(f"Critical PII detected: {match.pii_type.value}")
            
            elif match.severity == PIISeverity.HIGH and self.redact_high:
                should_redact.append(match)
                if action != "block":
                    action = "redact"
                reasons.append(f"High severity PII: {match.pii_type.value}")
            
            elif match.severity == PIISeverity.MEDIUM and self.warn_medium:
                if action not in ("block", "redact"):
                    action = "warn"
                reasons.append(f"Medium severity PII: {match.pii_type.value}")
        
        return {
            "action": action,
            "reasons": reasons,
            "should_redact": should_redact,
            "severity_score": result.get_severity_score(),
        }
