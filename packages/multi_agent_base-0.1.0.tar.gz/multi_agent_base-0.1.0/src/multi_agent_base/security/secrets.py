"""
Secret management.

Provides secure handling of API keys and sensitive data.
"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from typing import Any


@dataclass
class Secret:
    """A secret value with metadata.
    
    Attributes:
        name: Secret name/identifier
        value: The actual secret value
        source: Where the secret came from
        masked_value: Masked representation
    """
    
    name: str
    value: str
    source: str = "unknown"
    
    @property
    def masked_value(self) -> str:
        """Get masked version of the secret."""
        if len(self.value) <= 8:
            return "*" * len(self.value)
        return self.value[:4] + "*" * (len(self.value) - 8) + self.value[-4:]
    
    def __repr__(self) -> str:
        """String representation (masked)."""
        return f"Secret(name={self.name!r}, value={self.masked_value!r})"
    
    def __str__(self) -> str:
        """String representation (masked)."""
        return self.masked_value


class SecretManager:
    """Manages secrets and API keys.
    
    Provides secure storage and access to sensitive values.
    
    Example:
        ```python
        secrets = SecretManager()
        
        # Load from environment
        secrets.load_from_env(prefix="MYAPP_")
        
        # Get secrets
        api_key = secrets.get("OPENAI_API_KEY")
        
        # Mask secrets in logs
        log_message = secrets.mask_text(f"Using key {api_key}")
        print(log_message)  # "Using key sk-ab****ef"
        ```
    """
    
    def __init__(self) -> None:
        """Initialize secret manager."""
        self._secrets: dict[str, Secret] = {}
        self._patterns: list[tuple[str, re.Pattern[str]]] = []
        self._setup_default_patterns()
    
    def _setup_default_patterns(self) -> None:
        """Set up default secret detection patterns."""
        patterns = [
            ("openai_api_key", r"sk-[a-zA-Z0-9]{20,}"),
            ("anthropic_api_key", r"sk-ant-[a-zA-Z0-9\-_]{20,}"),
            ("github_token", r"gh[ps]_[a-zA-Z0-9]{36,}"),
            ("aws_access_key", r"AKIA[0-9A-Z]{16}"),
            ("azure_key", r"[a-f0-9]{32}"),
            ("generic_api_key", r"[a-zA-Z0-9_\-]{32,}key[a-zA-Z0-9_\-]*"),
        ]
        
        for name, pattern in patterns:
            self._patterns.append((name, re.compile(pattern)))
    
    def add(
        self,
        name: str,
        value: str,
        source: str = "manual",
    ) -> None:
        """Add a secret.
        
        Args:
            name: Secret name
            value: Secret value
            source: Source of the secret
        """
        self._secrets[name] = Secret(
            name=name,
            value=value,
            source=source,
        )
    
    def get(
        self,
        name: str,
        default: str | None = None,
    ) -> str | None:
        """Get a secret value.
        
        Args:
            name: Secret name
            default: Default value if not found
            
        Returns:
            Secret value or default
        """
        secret = self._secrets.get(name)
        if secret:
            return secret.value
        return default
    
    def get_secret(self, name: str) -> Secret | None:
        """Get a secret object.
        
        Args:
            name: Secret name
            
        Returns:
            Secret object or None
        """
        return self._secrets.get(name)
    
    def has(self, name: str) -> bool:
        """Check if a secret exists.
        
        Args:
            name: Secret name
            
        Returns:
            True if secret exists
        """
        return name in self._secrets
    
    def remove(self, name: str) -> bool:
        """Remove a secret.
        
        Args:
            name: Secret name
            
        Returns:
            True if secret was removed
        """
        if name in self._secrets:
            del self._secrets[name]
            return True
        return False
    
    def load_from_env(
        self,
        prefix: str = "",
        keys: list[str] | None = None,
    ) -> int:
        """Load secrets from environment variables.
        
        Args:
            prefix: Only load variables with this prefix
            keys: Specific keys to load (if None, load all with prefix)
            
        Returns:
            Number of secrets loaded
        """
        count = 0
        
        if keys:
            for key in keys:
                value = os.getenv(key)
                if value:
                    self.add(key, value, source="environment")
                    count += 1
        else:
            for key, value in os.environ.items():
                if prefix and not key.startswith(prefix):
                    continue
                
                # Only load if it looks like a secret
                if any(s in key.upper() for s in ["KEY", "SECRET", "TOKEN", "PASSWORD", "CREDENTIAL"]):
                    self.add(key, value, source="environment")
                    count += 1
        
        return count
    
    def mask_text(self, text: str) -> str:
        """Mask all known secrets in text.
        
        Args:
            text: Text to mask
            
        Returns:
            Text with secrets masked
        """
        result = text
        
        # Mask known secrets
        for secret in self._secrets.values():
            if secret.value in result:
                result = result.replace(secret.value, secret.masked_value)
        
        # Mask pattern-matched secrets
        for name, pattern in self._patterns:
            for match in pattern.finditer(result):
                matched = match.group()
                if len(matched) <= 8:
                    masked = "*" * len(matched)
                else:
                    masked = matched[:4] + "*" * (len(matched) - 8) + matched[-4:]
                result = result.replace(matched, masked)
        
        return result
    
    def detect_secrets(self, text: str) -> list[tuple[str, str]]:
        """Detect potential secrets in text.
        
        Args:
            text: Text to scan
            
        Returns:
            List of (pattern_name, matched_value) tuples
        """
        found = []
        
        for name, pattern in self._patterns:
            for match in pattern.finditer(text):
                found.append((name, match.group()))
        
        return found
    
    def list_secrets(self) -> list[str]:
        """List all secret names.
        
        Returns:
            List of secret names
        """
        return list(self._secrets.keys())
    
    def clear(self) -> None:
        """Clear all secrets."""
        self._secrets.clear()


def mask_secrets(text: str, secrets: dict[str, str]) -> str:
    """Quick function to mask secrets in text.
    
    Args:
        text: Text to mask
        secrets: Dictionary of name -> value secrets
        
    Returns:
        Text with secrets masked
        
    Example:
        ```python
        masked = mask_secrets(
            "API key is sk-abc123xyz",
            {"api_key": "sk-abc123xyz"}
        )
        # Result: "API key is sk-a****xyz"
        ```
    """
    result = text
    
    for name, value in secrets.items():
        if value in result:
            if len(value) <= 8:
                masked = "*" * len(value)
            else:
                masked = value[:4] + "*" * (len(value) - 8) + value[-4:]
            result = result.replace(value, masked)
    
    return result


# Global secret manager singleton
_global_secrets: SecretManager | None = None


def get_secret_manager() -> SecretManager:
    """Get the global secret manager.
    
    Returns:
        Global SecretManager instance
    """
    global _global_secrets
    if _global_secrets is None:
        _global_secrets = SecretManager()
    return _global_secrets
