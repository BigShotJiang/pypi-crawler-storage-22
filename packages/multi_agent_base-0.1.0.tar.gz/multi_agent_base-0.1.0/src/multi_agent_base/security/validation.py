"""
Input validation and sanitization.

Provides validation rules and sanitization for agent inputs.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Pattern


class ValidationType(str, Enum):
    """Types of validation rules."""
    
    LENGTH = "length"
    PATTERN = "pattern"
    CONTENT = "content"
    FORMAT = "format"
    CUSTOM = "custom"


@dataclass
class ValidationResult:
    """Result of input validation.
    
    Attributes:
        is_valid: Whether the input is valid
        errors: List of validation errors
        sanitized: Sanitized version of input
        warnings: Non-fatal warnings
    """
    
    is_valid: bool
    errors: list[str] = field(default_factory=list)
    sanitized: str | None = None
    warnings: list[str] = field(default_factory=list)
    
    def add_error(self, error: str) -> None:
        """Add a validation error."""
        self.errors.append(error)
        self.is_valid = False
    
    def add_warning(self, warning: str) -> None:
        """Add a validation warning."""
        self.warnings.append(warning)


@dataclass
class ValidationRule:
    """A validation rule.
    
    Attributes:
        name: Rule name
        type: Rule type
        check: Check function
        message: Error message
        enabled: Whether rule is enabled
    """
    
    name: str
    type: ValidationType
    check: Callable[[str], bool]
    message: str = "Validation failed"
    enabled: bool = True


class InputValidator:
    """Validates and sanitizes user inputs.
    
    Example:
        ```python
        validator = InputValidator()
        
        # Add custom rule
        validator.add_rule(ValidationRule(
            name="no_code",
            type=ValidationType.CONTENT,
            check=lambda x: "<script>" not in x.lower(),
            message="Script tags not allowed",
        ))
        
        result = validator.validate("Hello <script>alert(1)</script>")
        if not result.is_valid:
            print(result.errors)
        ```
    """
    
    def __init__(
        self,
        max_length: int = 10000,
        min_length: int = 1,
        allow_unicode: bool = True,
    ) -> None:
        """Initialize validator.
        
        Args:
            max_length: Maximum input length
            min_length: Minimum input length
            allow_unicode: Allow unicode characters
        """
        self.max_length = max_length
        self.min_length = min_length
        self.allow_unicode = allow_unicode
        
        self._rules: list[ValidationRule] = []
        self._setup_default_rules()
    
    def _setup_default_rules(self) -> None:
        """Set up default validation rules."""
        # Length validation
        self.add_rule(ValidationRule(
            name="max_length",
            type=ValidationType.LENGTH,
            check=lambda x: len(x) <= self.max_length,
            message=f"Input exceeds maximum length of {self.max_length}",
        ))
        
        self.add_rule(ValidationRule(
            name="min_length",
            type=ValidationType.LENGTH,
            check=lambda x: len(x) >= self.min_length,
            message=f"Input must be at least {self.min_length} characters",
        ))
        
        # Control character removal (keep newlines, tabs)
        self.add_rule(ValidationRule(
            name="no_control_chars",
            type=ValidationType.CONTENT,
            check=lambda x: not any(
                ord(c) < 32 and c not in '\n\r\t' for c in x
            ),
            message="Control characters not allowed",
        ))
    
    def add_rule(self, rule: ValidationRule) -> None:
        """Add a validation rule.
        
        Args:
            rule: Validation rule to add
        """
        self._rules.append(rule)
    
    def remove_rule(self, name: str) -> bool:
        """Remove a validation rule.
        
        Args:
            name: Rule name
            
        Returns:
            True if rule was removed
        """
        for i, rule in enumerate(self._rules):
            if rule.name == name:
                self._rules.pop(i)
                return True
        return False
    
    def validate(self, input_text: str) -> ValidationResult:
        """Validate input text.
        
        Args:
            input_text: Text to validate
            
        Returns:
            ValidationResult with errors and sanitized text
        """
        result = ValidationResult(is_valid=True)
        
        # Run all enabled rules
        for rule in self._rules:
            if not rule.enabled:
                continue
            
            try:
                if not rule.check(input_text):
                    result.add_error(rule.message)
            except Exception as e:
                result.add_warning(f"Rule {rule.name} error: {e}")
        
        # Create sanitized version
        result.sanitized = self.sanitize(input_text)
        
        return result
    
    def sanitize(self, input_text: str) -> str:
        """Sanitize input text.
        
        Args:
            input_text: Text to sanitize
            
        Returns:
            Sanitized text
        """
        text = input_text
        
        # Remove control characters (keep newlines, tabs)
        text = ''.join(
            c for c in text
            if ord(c) >= 32 or c in '\n\r\t'
        )
        
        # Normalize unicode if needed
        if not self.allow_unicode:
            text = text.encode('ascii', 'ignore').decode('ascii')
        
        # Truncate if needed
        if len(text) > self.max_length:
            text = text[:self.max_length]
        
        # Strip whitespace
        text = text.strip()
        
        return text


def sanitize_input(
    text: str,
    max_length: int = 10000,
    remove_urls: bool = False,
    remove_emails: bool = False,
) -> str:
    """Quick sanitization function.
    
    Args:
        text: Text to sanitize
        max_length: Maximum length
        remove_urls: Remove URLs from text
        remove_emails: Remove email addresses
        
    Returns:
        Sanitized text
        
    Example:
        ```python
        clean = sanitize_input(
            "Check out https://evil.com and email me@bad.com",
            remove_urls=True,
            remove_emails=True,
        )
        # Result: "Check out  and email "
        ```
    """
    result = text
    
    # Remove control characters
    result = ''.join(
        c for c in result
        if ord(c) >= 32 or c in '\n\r\t'
    )
    
    # Remove URLs if requested
    if remove_urls:
        result = re.sub(
            r'https?://\S+|www\.\S+',
            '',
            result,
        )
    
    # Remove emails if requested
    if remove_emails:
        result = re.sub(
            r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
            '',
            result,
        )
    
    # Truncate
    if len(result) > max_length:
        result = result[:max_length]
    
    return result.strip()
