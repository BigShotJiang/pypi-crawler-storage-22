"""
Agent Testing Framework

Deterministic testing framework for AI agents with mock LLMs,
mock tools, and agent-specific assertions.

Key Components:
- MockLLM: Mock language model for deterministic testing
- MockTool: Mock tool implementation
- TestContext: Test context with utilities
- AgentAssertions: Agent-specific assertion methods

Example:
    ```python
    from multi_agent_base.testing import (
        MockLLM, MockTool, agent_test, TestContext,
        assert_tool_called, assert_response_contains
    )
    
    @agent_test
    async def test_my_agent(ctx: TestContext):
        # Setup mock responses
        ctx.add_llm_response("I'll search for that")
        ctx.add_llm_response("Here are the results...")
        
        # Register mock tool
        search_tool = ctx.register_mock_tool(
            "web_search",
            return_value={"results": ["result1", "result2"]}
        )
        
        # Run agent
        agent = MyAgent(model=ctx.mock_llm, tools=[search_tool])
        response = await agent.run("Search for AI trends")
        
        # Assert
        ctx.assert_tool_called("web_search")
        ctx.assert_response_contains(response, "results")
    ```
"""

from .types import (
    # Enums
    MockResponseType,
    AssertionType,
    TestStatus,
    # Mock types
    MockToolCall,
    MockResponse,
    MockLLMConfig,
    MockToolConfig,
    RecordedCall,
    # Test types
    AssertionResult,
    TestMetrics,
    TestResult,
    TestSuiteResult,
    # Scenario types
    ConversationTurn,
    TestScenario,
)

from .mocks import (
    # Mock implementations
    MockLLM,
    MockLLMError,
    MockTool,
    MockToolError,
    MockToolRegistry,
    MockAgent,
)

from .fixtures import (
    # Test utilities
    TestContext,
    ConversationFixture,
    ScenarioRunner,
    TestSuiteBuilder,
    TestSuite,
    # Decorators
    agent_test,
    with_mock_llm,
    with_mock_tools,
    # Context managers
    mock_llm_context,
    mock_tool_context,
)

from .assertions import (
    # Assertion class
    AgentAssertions,
    # Standalone assertion functions
    assert_tool_called,
    assert_tool_not_called,
    assert_response_contains,
    assert_response_not_contains,
    assert_response_matches,
    assert_cost_under,
    assert_tokens_under,
    assert_latency_under,
    assert_llm_called,
)

__all__ = [
    # Enums
    "MockResponseType",
    "AssertionType",
    "TestStatus",
    # Mock types
    "MockToolCall",
    "MockResponse",
    "MockLLMConfig",
    "MockToolConfig",
    "RecordedCall",
    # Test types
    "AssertionResult",
    "TestMetrics",
    "TestResult",
    "TestSuiteResult",
    # Scenario types
    "ConversationTurn",
    "TestScenario",
    # Mock implementations
    "MockLLM",
    "MockLLMError",
    "MockTool",
    "MockToolError",
    "MockToolRegistry",
    "MockAgent",
    # Test utilities
    "TestContext",
    "ConversationFixture",
    "ScenarioRunner",
    "TestSuiteBuilder",
    "TestSuite",
    # Decorators
    "agent_test",
    "with_mock_llm",
    "with_mock_tools",
    # Context managers
    "mock_llm_context",
    "mock_tool_context",
    # Assertion class
    "AgentAssertions",
    # Standalone assertion functions
    "assert_tool_called",
    "assert_tool_not_called",
    "assert_response_contains",
    "assert_response_not_contains",
    "assert_response_matches",
    "assert_cost_under",
    "assert_tokens_under",
    "assert_latency_under",
    "assert_llm_called",
]
