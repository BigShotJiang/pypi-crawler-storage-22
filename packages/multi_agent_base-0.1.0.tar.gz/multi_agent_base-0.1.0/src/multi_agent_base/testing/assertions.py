"""
Agent Testing Framework - Assertions

Agent-specific assertions for testing agent behavior.
"""

import re
from dataclasses import dataclass, field
from typing import Any, Callable, Optional, Pattern, Union

from .types import AssertionResult, AssertionType, TestMetrics
from .mocks import MockLLM, MockTool, MockToolRegistry


@dataclass
class AgentAssertions:
    """
    Collection of agent-specific assertions.
    
    Example:
        ```python
        assertions = AgentAssertions(mock_llm=mock, mock_tools=tools)
        
        assertions.assert_tool_called("web_search")
        assertions.assert_response_contains(response, "results")
        assertions.assert_cost_under(0.01)
        ```
    """
    
    mock_llm: Optional[MockLLM] = None
    mock_tools: Optional[MockToolRegistry] = None
    metrics: Optional[TestMetrics] = None
    _results: list[AssertionResult] = field(default_factory=list)
    raise_on_failure: bool = True
    
    @property
    def results(self) -> list[AssertionResult]:
        """Get all assertion results."""
        return self._results
    
    @property
    def all_passed(self) -> bool:
        """Check if all assertions passed."""
        return all(r.passed for r in self._results)
    
    @property
    def failed_count(self) -> int:
        """Get count of failed assertions."""
        return sum(1 for r in self._results if not r.passed)
    
    def _add_result(self, result: AssertionResult) -> AssertionResult:
        """Add result and optionally raise."""
        self._results.append(result)
        if self.raise_on_failure and not result.passed:
            result.raise_if_failed()
        return result
    
    # ==================== Tool Assertions ====================
    
    def assert_tool_called(
        self,
        tool_name: str,
        times: Optional[int] = None,
        message: str = "",
    ) -> AssertionResult:
        """
        Assert that a tool was called.
        
        Args:
            tool_name: Name of the tool
            times: Expected number of calls (None = at least once)
            message: Custom error message
        """
        if self.mock_tools:
            tool = self.mock_tools.get(tool_name)
            call_count = tool.call_count if tool else 0
        elif self.mock_llm:
            call_count = self.mock_llm.metrics.tool_calls.get(tool_name, 0)
        else:
            call_count = 0
        
        if times is not None:
            passed = call_count == times
            expected = f"called {times} times"
        else:
            passed = call_count > 0
            expected = "called at least once"
        
        return self._add_result(AssertionResult(
            assertion_type=AssertionType.TOOL_CALLED,
            passed=passed,
            message=message or f"Tool '{tool_name}' should be {expected}",
            expected=times if times is not None else ">= 1",
            actual=call_count,
        ))
    
    def assert_tool_not_called(
        self,
        tool_name: str,
        message: str = "",
    ) -> AssertionResult:
        """
        Assert that a tool was not called.
        
        Args:
            tool_name: Name of the tool
            message: Custom error message
        """
        if self.mock_tools:
            tool = self.mock_tools.get(tool_name)
            call_count = tool.call_count if tool else 0
        elif self.mock_llm:
            call_count = self.mock_llm.metrics.tool_calls.get(tool_name, 0)
        else:
            call_count = 0
        
        passed = call_count == 0
        
        return self._add_result(AssertionResult(
            assertion_type=AssertionType.TOOL_NOT_CALLED,
            passed=passed,
            message=message or f"Tool '{tool_name}' should not be called",
            expected=0,
            actual=call_count,
        ))
    
    def assert_tool_called_with(
        self,
        tool_name: str,
        **expected_args: Any,
    ) -> AssertionResult:
        """
        Assert that a tool was called with specific arguments.
        
        Args:
            tool_name: Name of the tool
            **expected_args: Expected arguments
        """
        if not self.mock_tools:
            return self._add_result(AssertionResult(
                assertion_type=AssertionType.TOOL_CALLED,
                passed=False,
                message="No mock tools registry provided",
            ))
        
        tool = self.mock_tools.get(tool_name)
        if not tool or tool.call_count == 0:
            return self._add_result(AssertionResult(
                assertion_type=AssertionType.TOOL_CALLED,
                passed=False,
                message=f"Tool '{tool_name}' was never called",
                expected=expected_args,
                actual=None,
            ))
        
        # Check if any call matches
        for call in tool.recorded_calls:
            if all(call.tool_args.get(k) == v for k, v in expected_args.items()):
                return self._add_result(AssertionResult(
                    assertion_type=AssertionType.TOOL_CALLED,
                    passed=True,
                    message=f"Tool '{tool_name}' called with expected args",
                    expected=expected_args,
                    actual=call.tool_args,
                ))
        
        return self._add_result(AssertionResult(
            assertion_type=AssertionType.TOOL_CALLED,
            passed=False,
            message=f"Tool '{tool_name}' not called with expected args",
            expected=expected_args,
            actual=[c.tool_args for c in tool.recorded_calls],
        ))
    
    # ==================== Response Assertions ====================
    
    def assert_response_contains(
        self,
        response: Union[str, dict[str, Any]],
        text: str,
        case_sensitive: bool = False,
        message: str = "",
    ) -> AssertionResult:
        """
        Assert that response contains specific text.
        
        Args:
            response: Response string or dict with 'content' key
            text: Text to find
            case_sensitive: Whether to match case
            message: Custom error message
        """
        if isinstance(response, dict):
            content = response.get("content", "")
        else:
            content = response
        
        if case_sensitive:
            passed = text in content
        else:
            passed = text.lower() in content.lower()
        
        return self._add_result(AssertionResult(
            assertion_type=AssertionType.RESPONSE_CONTAINS,
            passed=passed,
            message=message or f"Response should contain '{text}'",
            expected=text,
            actual=content[:200] + "..." if len(content) > 200 else content,
        ))
    
    def assert_response_not_contains(
        self,
        response: Union[str, dict[str, Any]],
        text: str,
        case_sensitive: bool = False,
        message: str = "",
    ) -> AssertionResult:
        """
        Assert that response does not contain specific text.
        
        Args:
            response: Response string or dict with 'content' key
            text: Text that should not be present
            case_sensitive: Whether to match case
            message: Custom error message
        """
        if isinstance(response, dict):
            content = response.get("content", "")
        else:
            content = response
        
        if case_sensitive:
            passed = text not in content
        else:
            passed = text.lower() not in content.lower()
        
        return self._add_result(AssertionResult(
            assertion_type=AssertionType.RESPONSE_CONTAINS,
            passed=passed,
            message=message or f"Response should not contain '{text}'",
            expected=f"NOT '{text}'",
            actual=content[:200] + "..." if len(content) > 200 else content,
        ))
    
    def assert_response_matches(
        self,
        response: Union[str, dict[str, Any]],
        pattern: Union[str, Pattern[str]],
        message: str = "",
    ) -> AssertionResult:
        """
        Assert that response matches a regex pattern.
        
        Args:
            response: Response string or dict with 'content' key
            pattern: Regex pattern to match
            message: Custom error message
        """
        if isinstance(response, dict):
            content = response.get("content", "")
        else:
            content = response
        
        if isinstance(pattern, str):
            pattern = re.compile(pattern)
        
        passed = bool(pattern.search(content))
        
        return self._add_result(AssertionResult(
            assertion_type=AssertionType.RESPONSE_MATCHES,
            passed=passed,
            message=message or f"Response should match pattern '{pattern.pattern}'",
            expected=pattern.pattern,
            actual=content[:200] + "..." if len(content) > 200 else content,
        ))
    
    def assert_response_equals(
        self,
        response: Union[str, dict[str, Any]],
        expected: str,
        message: str = "",
    ) -> AssertionResult:
        """
        Assert that response equals expected string exactly.
        
        Args:
            response: Response string or dict with 'content' key
            expected: Expected response
            message: Custom error message
        """
        if isinstance(response, dict):
            content = response.get("content", "")
        else:
            content = response
        
        passed = content == expected
        
        return self._add_result(AssertionResult(
            assertion_type=AssertionType.RESPONSE_CONTAINS,
            passed=passed,
            message=message or "Response should match expected value",
            expected=expected,
            actual=content,
        ))
    
    # ==================== Cost/Token Assertions ====================
    
    def assert_cost_under(
        self,
        max_cost: float,
        message: str = "",
    ) -> AssertionResult:
        """
        Assert that total cost is under a maximum.
        
        Args:
            max_cost: Maximum allowed cost in dollars
            message: Custom error message
        """
        actual_cost = 0.0
        if self.metrics:
            actual_cost = self.metrics.total_cost
        elif self.mock_llm:
            actual_cost = self.mock_llm.metrics.total_cost
        
        passed = actual_cost <= max_cost
        
        return self._add_result(AssertionResult(
            assertion_type=AssertionType.COST_UNDER,
            passed=passed,
            message=message or f"Cost should be under ${max_cost}",
            expected=max_cost,
            actual=actual_cost,
        ))
    
    def assert_tokens_under(
        self,
        max_tokens: int,
        message: str = "",
    ) -> AssertionResult:
        """
        Assert that total tokens used is under a maximum.
        
        Args:
            max_tokens: Maximum allowed tokens
            message: Custom error message
        """
        actual_tokens = 0
        if self.metrics:
            actual_tokens = self.metrics.total_tokens
        elif self.mock_llm:
            actual_tokens = self.mock_llm.metrics.total_tokens
        
        passed = actual_tokens <= max_tokens
        
        return self._add_result(AssertionResult(
            assertion_type=AssertionType.TOKENS_UNDER,
            passed=passed,
            message=message or f"Tokens should be under {max_tokens}",
            expected=max_tokens,
            actual=actual_tokens,
        ))
    
    def assert_latency_under(
        self,
        max_latency_ms: float,
        message: str = "",
    ) -> AssertionResult:
        """
        Assert that total latency is under a maximum.
        
        Args:
            max_latency_ms: Maximum allowed latency in milliseconds
            message: Custom error message
        """
        actual_latency = 0.0
        if self.metrics:
            actual_latency = self.metrics.total_duration_ms
        elif self.mock_llm:
            actual_latency = self.mock_llm.metrics.total_duration_ms
        
        passed = actual_latency <= max_latency_ms
        
        return self._add_result(AssertionResult(
            assertion_type=AssertionType.LATENCY_UNDER,
            passed=passed,
            message=message or f"Latency should be under {max_latency_ms}ms",
            expected=max_latency_ms,
            actual=actual_latency,
        ))
    
    # ==================== LLM Call Assertions ====================
    
    def assert_llm_called(
        self,
        times: Optional[int] = None,
        message: str = "",
    ) -> AssertionResult:
        """
        Assert that LLM was called.
        
        Args:
            times: Expected number of calls (None = at least once)
            message: Custom error message
        """
        if not self.mock_llm:
            return self._add_result(AssertionResult(
                assertion_type=AssertionType.CUSTOM,
                passed=False,
                message="No mock LLM provided",
            ))
        
        call_count = self.mock_llm.call_count
        
        if times is not None:
            passed = call_count == times
            expected = times
        else:
            passed = call_count > 0
            expected = ">= 1"
        
        return self._add_result(AssertionResult(
            assertion_type=AssertionType.CUSTOM,
            passed=passed,
            message=message or f"LLM should be called {expected} times",
            expected=expected,
            actual=call_count,
        ))
    
    def assert_turn_count(
        self,
        expected_turns: int,
        message: str = "",
    ) -> AssertionResult:
        """
        Assert the number of conversation turns.
        
        Args:
            expected_turns: Expected number of turns
            message: Custom error message
        """
        if not self.mock_llm:
            return self._add_result(AssertionResult(
                assertion_type=AssertionType.TURN_COUNT,
                passed=False,
                message="No mock LLM provided",
            ))
        
        actual_turns = self.mock_llm.call_count
        passed = actual_turns == expected_turns
        
        return self._add_result(AssertionResult(
            assertion_type=AssertionType.TURN_COUNT,
            passed=passed,
            message=message or f"Should have {expected_turns} conversation turns",
            expected=expected_turns,
            actual=actual_turns,
        ))
    
    # ==================== Custom Assertions ====================
    
    def assert_custom(
        self,
        condition: bool,
        message: str,
        expected: Any = None,
        actual: Any = None,
    ) -> AssertionResult:
        """
        Make a custom assertion.
        
        Args:
            condition: Boolean condition to assert
            message: Assertion message
            expected: Expected value (for error message)
            actual: Actual value (for error message)
        """
        return self._add_result(AssertionResult(
            assertion_type=AssertionType.CUSTOM,
            passed=condition,
            message=message,
            expected=expected,
            actual=actual,
        ))
    
    def assert_predicate(
        self,
        value: Any,
        predicate: Callable[[Any], bool],
        message: str = "",
    ) -> AssertionResult:
        """
        Assert that a value satisfies a predicate.
        
        Args:
            value: Value to test
            predicate: Function that returns True if valid
            message: Custom error message
        """
        passed = predicate(value)
        
        return self._add_result(AssertionResult(
            assertion_type=AssertionType.CUSTOM,
            passed=passed,
            message=message or "Value should satisfy predicate",
            expected="predicate() == True",
            actual=value,
        ))


# ==================== Standalone Assertion Functions ====================


def assert_tool_called(
    mock: Union[MockLLM, MockToolRegistry, MockTool],
    tool_name: str,
    times: Optional[int] = None,
) -> None:
    """
    Assert that a tool was called.
    
    Args:
        mock: Mock object (LLM, registry, or tool)
        tool_name: Name of the tool
        times: Expected number of calls
        
    Raises:
        AssertionError: If assertion fails
    """
    if isinstance(mock, MockTool):
        call_count = mock.call_count if mock.name == tool_name else 0
    elif isinstance(mock, MockToolRegistry):
        tool = mock.get(tool_name)
        call_count = tool.call_count if tool else 0
    elif isinstance(mock, MockLLM):
        call_count = mock.metrics.tool_calls.get(tool_name, 0)
    else:
        raise TypeError(f"Unsupported mock type: {type(mock)}")
    
    if times is not None:
        if call_count != times:
            raise AssertionError(
                f"Expected tool '{tool_name}' to be called {times} times, "
                f"but was called {call_count} times"
            )
    else:
        if call_count == 0:
            raise AssertionError(f"Expected tool '{tool_name}' to be called")


def assert_tool_not_called(
    mock: Union[MockLLM, MockToolRegistry, MockTool],
    tool_name: str,
) -> None:
    """
    Assert that a tool was not called.
    
    Args:
        mock: Mock object (LLM, registry, or tool)
        tool_name: Name of the tool
        
    Raises:
        AssertionError: If assertion fails
    """
    if isinstance(mock, MockTool):
        call_count = mock.call_count if mock.name == tool_name else 0
    elif isinstance(mock, MockToolRegistry):
        tool = mock.get(tool_name)
        call_count = tool.call_count if tool else 0
    elif isinstance(mock, MockLLM):
        call_count = mock.metrics.tool_calls.get(tool_name, 0)
    else:
        raise TypeError(f"Unsupported mock type: {type(mock)}")
    
    if call_count > 0:
        raise AssertionError(
            f"Expected tool '{tool_name}' to not be called, "
            f"but was called {call_count} times"
        )


def assert_response_contains(
    response: Union[str, dict[str, Any]],
    text: str,
    case_sensitive: bool = False,
) -> None:
    """
    Assert that response contains text.
    
    Args:
        response: Response string or dict with 'content' key
        text: Text to find
        case_sensitive: Whether to match case
        
    Raises:
        AssertionError: If assertion fails
    """
    if isinstance(response, dict):
        content = response.get("content", "")
    else:
        content = response
    
    if case_sensitive:
        found = text in content
    else:
        found = text.lower() in content.lower()
    
    if not found:
        raise AssertionError(
            f"Expected response to contain '{text}', got: {content[:200]}"
        )


def assert_response_not_contains(
    response: Union[str, dict[str, Any]],
    text: str,
    case_sensitive: bool = False,
) -> None:
    """
    Assert that response does not contain text.
    
    Args:
        response: Response string or dict with 'content' key
        text: Text that should not be present
        case_sensitive: Whether to match case
        
    Raises:
        AssertionError: If assertion fails
    """
    if isinstance(response, dict):
        content = response.get("content", "")
    else:
        content = response
    
    if case_sensitive:
        found = text in content
    else:
        found = text.lower() in content.lower()
    
    if found:
        raise AssertionError(
            f"Expected response to not contain '{text}', got: {content[:200]}"
        )


def assert_response_matches(
    response: Union[str, dict[str, Any]],
    pattern: Union[str, Pattern[str]],
) -> None:
    """
    Assert that response matches a regex pattern.
    
    Args:
        response: Response string or dict with 'content' key
        pattern: Regex pattern to match
        
    Raises:
        AssertionError: If assertion fails
    """
    if isinstance(response, dict):
        content = response.get("content", "")
    else:
        content = response
    
    if isinstance(pattern, str):
        pattern = re.compile(pattern)
    
    if not pattern.search(content):
        raise AssertionError(
            f"Expected response to match pattern '{pattern.pattern}', "
            f"got: {content[:200]}"
        )


def assert_cost_under(
    mock: Union[MockLLM, TestMetrics],
    max_cost: float,
) -> None:
    """
    Assert that cost is under maximum.
    
    Args:
        mock: Mock LLM or TestMetrics
        max_cost: Maximum allowed cost in dollars
        
    Raises:
        AssertionError: If assertion fails
    """
    if isinstance(mock, MockLLM):
        actual_cost = mock.metrics.total_cost
    else:
        actual_cost = mock.total_cost
    
    if actual_cost > max_cost:
        raise AssertionError(
            f"Expected cost to be under ${max_cost}, got ${actual_cost}"
        )


def assert_tokens_under(
    mock: Union[MockLLM, TestMetrics],
    max_tokens: int,
) -> None:
    """
    Assert that tokens used is under maximum.
    
    Args:
        mock: Mock LLM or TestMetrics
        max_tokens: Maximum allowed tokens
        
    Raises:
        AssertionError: If assertion fails
    """
    if isinstance(mock, MockLLM):
        actual_tokens = mock.metrics.total_tokens
    else:
        actual_tokens = mock.total_tokens
    
    if actual_tokens > max_tokens:
        raise AssertionError(
            f"Expected tokens to be under {max_tokens}, got {actual_tokens}"
        )


def assert_latency_under(
    mock: Union[MockLLM, TestMetrics],
    max_latency_ms: float,
) -> None:
    """
    Assert that latency is under maximum.
    
    Args:
        mock: Mock LLM or TestMetrics
        max_latency_ms: Maximum allowed latency in milliseconds
        
    Raises:
        AssertionError: If assertion fails
    """
    if isinstance(mock, MockLLM):
        actual_latency = mock.metrics.total_duration_ms
    else:
        actual_latency = mock.total_duration_ms
    
    if actual_latency > max_latency_ms:
        raise AssertionError(
            f"Expected latency to be under {max_latency_ms}ms, "
            f"got {actual_latency}ms"
        )


def assert_llm_called(
    mock: MockLLM,
    times: Optional[int] = None,
) -> None:
    """
    Assert that LLM was called.
    
    Args:
        mock: Mock LLM
        times: Expected number of calls (None = at least once)
        
    Raises:
        AssertionError: If assertion fails
    """
    if times is not None:
        if mock.call_count != times:
            raise AssertionError(
                f"Expected LLM to be called {times} times, "
                f"got {mock.call_count}"
            )
    else:
        if mock.call_count == 0:
            raise AssertionError("Expected LLM to be called")
