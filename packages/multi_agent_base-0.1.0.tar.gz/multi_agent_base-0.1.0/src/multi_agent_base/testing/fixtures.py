"""
Agent Testing Framework - Test Fixtures

Pytest-compatible fixtures and utilities for agent testing.
"""

import asyncio
import functools
from contextlib import asynccontextmanager, contextmanager
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, AsyncIterator, Callable, Iterator, Optional, TypeVar

from .types import (
    ConversationTurn,
    MockLLMConfig,
    MockResponse,
    MockToolCall,
    TestMetrics,
    TestResult,
    TestScenario,
    TestStatus,
    TestSuiteResult,
)
from .mocks import MockLLM, MockTool, MockToolRegistry, MockAgent


F = TypeVar("F", bound=Callable[..., Any])


@dataclass
class TestContext:
    """
    Context for a test execution.
    
    Provides access to mock objects and test utilities during test execution.
    
    Example:
        ```python
        @agent_test
        async def test_something(ctx: TestContext):
            ctx.mock_llm.add_response("Hello!")
            result = await my_agent.run("Hi")
            ctx.assert_response_contains(result, "Hello")
        ```
    """
    
    mock_llm: MockLLM = field(default_factory=MockLLM)
    mock_tools: MockToolRegistry = field(default_factory=MockToolRegistry)
    metrics: TestMetrics = field(default_factory=TestMetrics)
    _start_time: datetime = field(default_factory=datetime.now)
    _assertions: list[tuple[bool, str]] = field(default_factory=list)
    
    def add_llm_response(self, response: str | MockResponse) -> None:
        """Add a response to the mock LLM."""
        self.mock_llm.config.add_response(response)
    
    def add_llm_responses(self, *responses: str | MockResponse) -> None:
        """Add multiple responses to the mock LLM."""
        for response in responses:
            self.mock_llm.config.add_response(response)
    
    def add_tool_call_response(
        self,
        tool_name: str,
        arguments: dict[str, Any],
        result: Any = None,
    ) -> None:
        """Add a tool call response to the mock LLM."""
        self.mock_llm.config.add_response(
            MockResponse.tool_call(tool_name, arguments, result)
        )
    
    def register_mock_tool(
        self,
        name: str,
        return_value: Any = None,
        side_effect: Optional[Callable[..., Any]] = None,
    ) -> MockTool:
        """Register a mock tool."""
        tool = MockTool(
            name=name,
            return_value=return_value,
            side_effect=side_effect,
        )
        self.mock_tools.register(tool)
        return tool
    
    def assert_true(self, condition: bool, message: str = "") -> None:
        """Assert a condition is true."""
        self._assertions.append((condition, message))
        if not condition:
            raise AssertionError(message or "Assertion failed")
    
    def assert_equal(self, actual: Any, expected: Any, message: str = "") -> None:
        """Assert two values are equal."""
        equal = actual == expected
        msg = message or f"Expected {expected}, got {actual}"
        self._assertions.append((equal, msg))
        if not equal:
            raise AssertionError(msg)
    
    def assert_response_contains(
        self,
        response: dict[str, Any] | str,
        text: str,
        message: str = "",
    ) -> None:
        """Assert response contains text."""
        if isinstance(response, dict):
            content = response.get("content", "")
        else:
            content = response
        
        contains = text in content
        msg = message or f"Expected '{text}' in response"
        self._assertions.append((contains, msg))
        if not contains:
            raise AssertionError(f"{msg}, got: {content}")
    
    def assert_tool_called(self, tool_name: str, message: str = "") -> None:
        """Assert a tool was called."""
        tool = self.mock_tools.get(tool_name)
        called = tool is not None and tool.call_count > 0
        msg = message or f"Expected tool '{tool_name}' to be called"
        self._assertions.append((called, msg))
        if not called:
            raise AssertionError(msg)
    
    def assert_tool_not_called(self, tool_name: str, message: str = "") -> None:
        """Assert a tool was not called."""
        tool = self.mock_tools.get(tool_name)
        not_called = tool is None or tool.call_count == 0
        msg = message or f"Expected tool '{tool_name}' to not be called"
        self._assertions.append((not_called, msg))
        if not not_called:
            raise AssertionError(f"{msg}, but was called {tool.call_count} times")
    
    def assert_llm_called(self, times: Optional[int] = None, message: str = "") -> None:
        """Assert LLM was called."""
        if times is not None:
            correct = self.mock_llm.call_count == times
            msg = message or f"Expected LLM to be called {times} times"
            self._assertions.append((correct, msg))
            if not correct:
                raise AssertionError(f"{msg}, got {self.mock_llm.call_count}")
        else:
            called = self.mock_llm.call_count > 0
            msg = message or "Expected LLM to be called"
            self._assertions.append((called, msg))
            if not called:
                raise AssertionError(msg)
    
    @property
    def duration_ms(self) -> float:
        """Get test duration in milliseconds."""
        return (datetime.now() - self._start_time).total_seconds() * 1000
    
    @property
    def assertion_count(self) -> int:
        """Get number of assertions made."""
        return len(self._assertions)
    
    @property
    def passed_assertions(self) -> int:
        """Get number of passed assertions."""
        return sum(1 for passed, _ in self._assertions if passed)
    
    def reset(self) -> None:
        """Reset test context."""
        self.mock_llm.reset()
        self.mock_tools.reset_all()
        self.metrics = TestMetrics()
        self._start_time = datetime.now()
        self._assertions.clear()


def agent_test(func: F) -> F:
    """
    Decorator for agent tests.
    
    Provides a TestContext and handles async execution.
    
    Example:
        ```python
        @agent_test
        async def test_my_agent(ctx: TestContext):
            ctx.add_llm_response("Hello!")
            # ... test logic
        ```
    """
    @functools.wraps(func)
    async def async_wrapper(*args: Any, **kwargs: Any) -> TestResult:
        ctx = TestContext()
        start_time = datetime.now()
        
        try:
            # Check if function expects context
            if "ctx" in func.__code__.co_varnames[:func.__code__.co_argcount]:
                result = await func(ctx, *args, **kwargs)
            else:
                result = await func(*args, **kwargs)
            
            return TestResult(
                name=func.__name__,
                status=TestStatus.PASSED,
                duration_ms=ctx.duration_ms,
                metrics=ctx.mock_llm.metrics,
            )
        except AssertionError as e:
            return TestResult(
                name=func.__name__,
                status=TestStatus.FAILED,
                duration_ms=(datetime.now() - start_time).total_seconds() * 1000,
                error=str(e),
            )
        except Exception as e:
            import traceback
            return TestResult(
                name=func.__name__,
                status=TestStatus.ERROR,
                duration_ms=(datetime.now() - start_time).total_seconds() * 1000,
                error=str(e),
                traceback=traceback.format_exc(),
            )
    
    @functools.wraps(func)
    def sync_wrapper(*args: Any, **kwargs: Any) -> TestResult:
        return asyncio.get_event_loop().run_until_complete(
            async_wrapper(*args, **kwargs)
        )
    
    if asyncio.iscoroutinefunction(func):
        return async_wrapper  # type: ignore
    else:
        # Wrap sync function
        @functools.wraps(func)
        async def async_from_sync(*args: Any, **kwargs: Any) -> TestResult:
            ctx = TestContext()
            try:
                if "ctx" in func.__code__.co_varnames[:func.__code__.co_argcount]:
                    func(ctx, *args, **kwargs)
                else:
                    func(*args, **kwargs)
                
                return TestResult(
                    name=func.__name__,
                    status=TestStatus.PASSED,
                    duration_ms=ctx.duration_ms,
                )
            except AssertionError as e:
                return TestResult(
                    name=func.__name__,
                    status=TestStatus.FAILED,
                    duration_ms=ctx.duration_ms,
                    error=str(e),
                )
        return async_from_sync  # type: ignore


def with_mock_llm(
    responses: Optional[list[str | MockResponse]] = None,
    cycle: bool = False,
    default_response: Optional[str] = None,
) -> Callable[[F], F]:
    """
    Decorator to inject a MockLLM into the test.
    
    Example:
        ```python
        @with_mock_llm(responses=["Hello!", "How can I help?"])
        async def test_agent(mock_llm: MockLLM):
            result = await mock_llm.chat([{"role": "user", "content": "Hi"}])
            assert "Hello" in result["choices"][0]["message"]["content"]
        ```
    """
    def decorator(func: F) -> F:
        @functools.wraps(func)
        async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
            mock_llm = MockLLM(
                responses=responses,
                cycle_responses=cycle,
                default_response=default_response,
            )
            
            # Inject mock_llm as first argument or keyword
            if "mock_llm" in func.__code__.co_varnames[:func.__code__.co_argcount]:
                kwargs["mock_llm"] = mock_llm
                return await func(*args, **kwargs)
            else:
                return await func(mock_llm, *args, **kwargs)
        
        return async_wrapper  # type: ignore
    
    return decorator


def with_mock_tools(
    *tools: tuple[str, Any],
) -> Callable[[F], F]:
    """
    Decorator to inject mock tools into the test.
    
    Example:
        ```python
        @with_mock_tools(
            ("search", {"results": ["result1"]}),
            ("calculate", 42),
        )
        async def test_tools(mock_tools: MockToolRegistry):
            result = await mock_tools.execute("search", query="test")
        ```
    """
    def decorator(func: F) -> F:
        @functools.wraps(func)
        async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
            registry = MockToolRegistry()
            for name, return_value in tools:
                registry.register(MockTool(name=name, return_value=return_value))
            
            # Inject registry
            if "mock_tools" in func.__code__.co_varnames[:func.__code__.co_argcount]:
                kwargs["mock_tools"] = registry
                return await func(*args, **kwargs)
            else:
                return await func(registry, *args, **kwargs)
        
        return async_wrapper  # type: ignore
    
    return decorator


@asynccontextmanager
async def mock_llm_context(
    responses: Optional[list[str | MockResponse]] = None,
    cycle: bool = False,
) -> AsyncIterator[MockLLM]:
    """
    Async context manager for MockLLM.
    
    Example:
        ```python
        async with mock_llm_context(["Hello!", "Hi there!"]) as mock:
            response = await mock.chat([{"role": "user", "content": "Hi"}])
        ```
    """
    mock = MockLLM(responses=responses, cycle_responses=cycle)
    try:
        yield mock
    finally:
        mock.reset()


@contextmanager
def mock_tool_context(
    name: str,
    return_value: Any = None,
    side_effect: Optional[Callable[..., Any]] = None,
) -> Iterator[MockTool]:
    """
    Context manager for MockTool.
    
    Example:
        ```python
        with mock_tool_context("search", return_value={"results": []}) as mock:
            result = await mock.execute(query="test")
        ```
    """
    mock = MockTool(name=name, return_value=return_value, side_effect=side_effect)
    try:
        yield mock
    finally:
        mock.reset()


@dataclass
class ConversationFixture:
    """
    Fixture for testing multi-turn conversations.
    
    Example:
        ```python
        fixture = ConversationFixture(
            MockLLM(responses=["Hello!", "How can I help?", "Here's the answer."])
        )
        
        async with fixture as conv:
            response1 = await conv.send("Hi")
            response2 = await conv.send("What's 2+2?")
            response3 = await conv.send("Thanks!")
        
        assert fixture.turn_count == 3
        ```
    """
    
    mock_llm: MockLLM
    _history: list[dict[str, Any]] = field(default_factory=list)
    _responses: list[str] = field(default_factory=list)
    
    @property
    def history(self) -> list[dict[str, Any]]:
        """Get conversation history."""
        return self._history
    
    @property
    def turn_count(self) -> int:
        """Get number of conversation turns."""
        return len(self._responses)
    
    @property
    def last_response(self) -> Optional[str]:
        """Get last response."""
        return self._responses[-1] if self._responses else None
    
    async def send(self, message: str) -> str:
        """Send a message and get response."""
        self._history.append({"role": "user", "content": message})
        
        response = await self.mock_llm.chat(self._history)
        content = response["choices"][0]["message"].get("content", "")
        
        self._history.append({"role": "assistant", "content": content})
        self._responses.append(content)
        
        return content
    
    async def __aenter__(self) -> "ConversationFixture":
        """Enter context."""
        return self
    
    async def __aexit__(self, *args: Any) -> None:
        """Exit context."""
        pass
    
    def reset(self) -> None:
        """Reset conversation state."""
        self._history.clear()
        self._responses.clear()
        self.mock_llm.reset()


@dataclass
class ScenarioRunner:
    """
    Runner for test scenarios.
    
    Example:
        ```python
        scenario = TestScenario(
            name="greeting_test",
            turns=[
                ConversationTurn(
                    user_message="Hello",
                    expected_contains=["hi", "hello"]
                ),
                ConversationTurn(
                    user_message="What's 2+2?",
                    expected_contains=["4"]
                ),
            ]
        )
        
        runner = ScenarioRunner(mock_llm)
        result = await runner.run(scenario)
        assert result.passed
        ```
    """
    
    mock_llm: MockLLM
    mock_tools: Optional[MockToolRegistry] = None
    
    async def run(self, scenario: TestScenario) -> TestResult:
        """Run a test scenario."""
        start_time = datetime.now()
        history: list[dict[str, Any]] = []
        errors: list[str] = []
        
        try:
            # Run setup if provided
            if scenario.setup:
                if asyncio.iscoroutinefunction(scenario.setup):
                    await scenario.setup()
                else:
                    scenario.setup()
            
            # Execute each turn
            for i, turn in enumerate(scenario.turns):
                # Send user message
                history.append({"role": "user", "content": turn.user_message})
                
                try:
                    response = await asyncio.wait_for(
                        self.mock_llm.chat(history),
                        timeout=turn.timeout_ms / 1000,
                    )
                except asyncio.TimeoutError:
                    errors.append(f"Turn {i+1}: Timeout after {turn.timeout_ms}ms")
                    continue
                
                content = response["choices"][0]["message"].get("content", "")
                tool_calls = response["choices"][0]["message"].get("tool_calls", [])
                
                history.append({"role": "assistant", "content": content})
                
                # Check expected response
                if turn.expected_response and content != turn.expected_response:
                    errors.append(
                        f"Turn {i+1}: Expected '{turn.expected_response}', got '{content}'"
                    )
                
                # Check expected contains
                for expected in turn.expected_contains:
                    if expected.lower() not in content.lower():
                        errors.append(
                            f"Turn {i+1}: Expected '{expected}' in response"
                        )
                
                # Check not contains
                for not_expected in turn.expected_not_contains:
                    if not_expected.lower() in content.lower():
                        errors.append(
                            f"Turn {i+1}: Did not expect '{not_expected}' in response"
                        )
                
                # Check tool calls
                actual_tool_names = [tc["function"]["name"] for tc in tool_calls]
                for expected_tool in turn.expected_tool_calls:
                    if expected_tool not in actual_tool_names:
                        errors.append(
                            f"Turn {i+1}: Expected tool '{expected_tool}' to be called"
                        )
            
            # Run teardown if provided
            if scenario.teardown:
                if asyncio.iscoroutinefunction(scenario.teardown):
                    await scenario.teardown()
                else:
                    scenario.teardown()
            
            duration_ms = (datetime.now() - start_time).total_seconds() * 1000
            
            if errors:
                return TestResult(
                    name=scenario.name,
                    status=TestStatus.FAILED,
                    duration_ms=duration_ms,
                    error="\n".join(errors),
                    tags=scenario.tags,
                )
            
            return TestResult(
                name=scenario.name,
                status=TestStatus.PASSED,
                duration_ms=duration_ms,
                tags=scenario.tags,
            )
        
        except Exception as e:
            import traceback
            return TestResult(
                name=scenario.name,
                status=TestStatus.ERROR,
                duration_ms=(datetime.now() - start_time).total_seconds() * 1000,
                error=str(e),
                traceback=traceback.format_exc(),
                tags=scenario.tags,
            )


class TestSuiteBuilder:
    """
    Builder for test suites.
    
    Example:
        ```python
        suite = (
            TestSuiteBuilder("my_tests")
            .add_scenario(scenario1)
            .add_scenario(scenario2)
            .with_mock_llm(responses=["Response 1", "Response 2"])
            .build()
        )
        
        results = await suite.run()
        ```
    """
    
    def __init__(self, name: str):
        self.name = name
        self._scenarios: list[TestScenario] = []
        self._mock_llm_config: Optional[MockLLMConfig] = None
        self._mock_tools: list[tuple[str, Any]] = []
        self._setup: Optional[Callable] = None
        self._teardown: Optional[Callable] = None
    
    def add_scenario(self, scenario: TestScenario) -> "TestSuiteBuilder":
        """Add a test scenario."""
        self._scenarios.append(scenario)
        return self
    
    def add_scenarios(self, *scenarios: TestScenario) -> "TestSuiteBuilder":
        """Add multiple scenarios."""
        self._scenarios.extend(scenarios)
        return self
    
    def with_mock_llm(
        self,
        responses: Optional[list[str | MockResponse]] = None,
        config: Optional[MockLLMConfig] = None,
    ) -> "TestSuiteBuilder":
        """Configure mock LLM."""
        if config:
            self._mock_llm_config = config
        else:
            self._mock_llm_config = MockLLMConfig()
            if responses:
                for r in responses:
                    if isinstance(r, str):
                        self._mock_llm_config.add_response(MockResponse.text(r))
                    else:
                        self._mock_llm_config.add_response(r)
        return self
    
    def with_mock_tool(
        self,
        name: str,
        return_value: Any = None,
    ) -> "TestSuiteBuilder":
        """Add a mock tool."""
        self._mock_tools.append((name, return_value))
        return self
    
    def with_setup(self, setup: Callable) -> "TestSuiteBuilder":
        """Set suite setup function."""
        self._setup = setup
        return self
    
    def with_teardown(self, teardown: Callable) -> "TestSuiteBuilder":
        """Set suite teardown function."""
        self._teardown = teardown
        return self
    
    def build(self) -> "TestSuite":
        """Build the test suite."""
        return TestSuite(
            name=self.name,
            scenarios=self._scenarios,
            mock_llm_config=self._mock_llm_config,
            mock_tools=self._mock_tools,
            setup=self._setup,
            teardown=self._teardown,
        )


@dataclass
class TestSuite:
    """
    A collection of test scenarios.
    """
    
    name: str
    scenarios: list[TestScenario] = field(default_factory=list)
    mock_llm_config: Optional[MockLLMConfig] = None
    mock_tools: list[tuple[str, Any]] = field(default_factory=list)
    setup: Optional[Callable] = None
    teardown: Optional[Callable] = None
    
    async def run(self) -> TestSuiteResult:
        """Run all scenarios in the suite."""
        result = TestSuiteResult(name=self.name)
        
        # Run setup
        if self.setup:
            if asyncio.iscoroutinefunction(self.setup):
                await self.setup()
            else:
                self.setup()
        
        # Create mock tools
        mock_tools = MockToolRegistry()
        for name, return_value in self.mock_tools:
            mock_tools.register(MockTool(name=name, return_value=return_value))
        
        # Run each scenario with fresh mock LLM
        for i, scenario in enumerate(self.scenarios):
            # Create fresh mock LLM for each scenario
            # Each scenario should start from its own response index
            if self.mock_llm_config:
                # Create new mock for each scenario
                mock_llm = MockLLM(config=self.mock_llm_config)
                # Start at the correct response index for this scenario
                mock_llm._call_index = i
            else:
                mock_llm = MockLLM()
            
            runner = ScenarioRunner(mock_llm=mock_llm, mock_tools=mock_tools)
            test_result = await runner.run(scenario)
            result.add_test(test_result)
        
        # Run teardown
        if self.teardown:
            if asyncio.iscoroutinefunction(self.teardown):
                await self.teardown()
            else:
                self.teardown()
        
        result.finalize()
        return result


# Pytest fixtures (if pytest is available)
try:
    import pytest
    
    @pytest.fixture
    def mock_llm() -> MockLLM:
        """Pytest fixture for MockLLM."""
        return MockLLM()
    
    @pytest.fixture
    def mock_tools() -> MockToolRegistry:
        """Pytest fixture for MockToolRegistry."""
        return MockToolRegistry()
    
    @pytest.fixture
    def test_context() -> TestContext:
        """Pytest fixture for TestContext."""
        return TestContext()
    
    @pytest.fixture
    def conversation_fixture(mock_llm: MockLLM) -> ConversationFixture:
        """Pytest fixture for ConversationFixture."""
        return ConversationFixture(mock_llm=mock_llm)

except ImportError:
    # pytest not available, skip fixture definitions
    pass
