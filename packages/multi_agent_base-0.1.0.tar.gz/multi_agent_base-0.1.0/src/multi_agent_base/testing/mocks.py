"""
Agent Testing Framework - Mock Implementations

Mock LLM client and mock tools for deterministic agent testing.
"""

import asyncio
import time
from dataclasses import dataclass, field
from typing import Any, AsyncIterator, Callable, Optional, Protocol
from datetime import datetime

from .types import (
    MockLLMConfig,
    MockResponse,
    MockResponseType,
    MockToolCall,
    MockToolConfig,
    RecordedCall,
    TestMetrics,
)


class ChatClientProtocol(Protocol):
    """Protocol for chat client compatibility."""
    
    async def chat(
        self,
        messages: list[dict[str, Any]],
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Send a chat request."""
        ...


@dataclass
class MockLLM:
    """
    Mock LLM client for deterministic testing.
    
    Provides predefined responses for testing agent behavior without
    making actual API calls.
    
    Example:
        ```python
        mock = MockLLM(responses=[
            "I'll help you with that.",
            "Here are the results..."
        ])
        
        # Use as a chat client
        response = await mock.chat([{"role": "user", "content": "Hello"}])
        
        # Check recorded calls
        assert mock.call_count == 1
        assert "Hello" in mock.recorded_calls[0].messages[0]["content"]
        ```
    """
    
    config: MockLLMConfig = field(default_factory=MockLLMConfig)
    _call_index: int = field(default=0, init=False)
    _recorded_calls: list[RecordedCall] = field(default_factory=list, init=False)
    _metrics: TestMetrics = field(default_factory=TestMetrics, init=False)
    
    def __init__(
        self,
        responses: Optional[list[str | MockResponse]] = None,
        config: Optional[MockLLMConfig] = None,
        cycle_responses: bool = False,
        default_response: Optional[str] = None,
    ):
        """
        Initialize MockLLM.
        
        Args:
            responses: List of string or MockResponse objects
            config: Full MockLLMConfig (overrides other params)
            cycle_responses: If True, cycle through responses
            default_response: Default response when responses exhausted
        """
        if config:
            self.config = config
        else:
            self.config = MockLLMConfig(cycle_responses=cycle_responses)
            if responses:
                for r in responses:
                    if isinstance(r, str):
                        self.config.add_response(MockResponse.text(r))
                    else:
                        self.config.add_response(r)
            if default_response:
                self.config.default_response = MockResponse.text(default_response)
        
        self._call_index = 0
        self._recorded_calls = []
        self._metrics = TestMetrics()
    
    @property
    def call_count(self) -> int:
        """Number of calls made."""
        return len(self._recorded_calls)
    
    @property
    def recorded_calls(self) -> list[RecordedCall]:
        """List of recorded calls."""
        return self._recorded_calls
    
    @property
    def metrics(self) -> TestMetrics:
        """Test metrics."""
        return self._metrics
    
    @property
    def last_call(self) -> Optional[RecordedCall]:
        """Get the last recorded call."""
        return self._recorded_calls[-1] if self._recorded_calls else None
    
    @property
    def last_messages(self) -> list[dict[str, Any]]:
        """Get messages from last call."""
        return self.last_call.messages if self.last_call else []
    
    def _get_next_response(self) -> MockResponse:
        """Get the next response from queue."""
        # Check if should fail
        if self.config.fail_after >= 0 and self._call_index >= self.config.fail_after:
            return MockResponse.error(self.config.fail_message)
        
        # No responses configured
        if not self.config.responses:
            if self.config.default_response:
                return self.config.default_response
            return MockResponse.text("Mock response")
        
        # Get response by index
        if self.config.cycle_responses:
            index = self._call_index % len(self.config.responses)
        else:
            index = min(self._call_index, len(self.config.responses) - 1)
        
        return self.config.responses[index]
    
    async def chat(
        self,
        messages: list[dict[str, Any]],
        tools: Optional[list[dict[str, Any]]] = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """
        Simulate a chat request.
        
        Args:
            messages: List of message dictionaries
            tools: Optional list of tool definitions
            **kwargs: Additional arguments (ignored)
            
        Returns:
            Response dictionary in OpenAI-compatible format
        """
        start_time = time.time()
        
        # Get response
        response = self._get_next_response()
        self._call_index += 1
        
        # Simulate latency
        if self.config.simulate_latency and response.delay_ms > 0:
            await asyncio.sleep(response.delay_ms / 1000)
        
        duration_ms = (time.time() - start_time) * 1000
        
        # Record call
        if self.config.record_calls:
            recorded = RecordedCall(
                timestamp=datetime.now(),
                messages=messages.copy(),
                response=response,
                duration_ms=duration_ms,
            )
            self._recorded_calls.append(recorded)
        
        # Record metrics
        self._metrics.record_call(
            tokens=response.tokens_used,
            duration_ms=duration_ms,
            is_error=response.response_type == MockResponseType.ERROR,
        )
        
        # Handle error response
        if response.response_type == MockResponseType.ERROR:
            raise MockLLMError(response.content, response.metadata.get("error_code", "error"))
        
        # Build response
        result: dict[str, Any] = {
            "id": f"mock-{self._call_index}",
            "object": "chat.completion",
            "created": int(time.time()),
            "model": "mock-model",
            "choices": [{
                "index": 0,
                "message": {
                    "role": "assistant",
                    "content": response.content if response.content else None,
                },
                "finish_reason": response.finish_reason,
            }],
            "usage": {
                "prompt_tokens": sum(len(str(m.get("content", "")).split()) for m in messages),
                "completion_tokens": response.tokens_used,
                "total_tokens": response.tokens_used + sum(len(str(m.get("content", "")).split()) for m in messages),
            },
        }
        
        # Add tool calls if present
        if response.tool_calls:
            result["choices"][0]["message"]["tool_calls"] = [
                {
                    "id": tc.call_id,
                    "type": "function",
                    "function": {
                        "name": tc.name,
                        "arguments": str(tc.arguments) if isinstance(tc.arguments, dict) else tc.arguments,
                    },
                }
                for tc in response.tool_calls
            ]
            result["choices"][0]["finish_reason"] = "tool_calls"
            
            # Record tool calls in metrics
            for tc in response.tool_calls:
                self._metrics.record_call(tool_name=tc.name)
        
        return result
    
    async def stream(
        self,
        messages: list[dict[str, Any]],
        **kwargs: Any,
    ) -> AsyncIterator[dict[str, Any]]:
        """
        Simulate a streaming chat request.
        
        Args:
            messages: List of message dictionaries
            **kwargs: Additional arguments
            
        Yields:
            Stream chunks in OpenAI-compatible format
        """
        response = self._get_next_response()
        self._call_index += 1
        
        # Record call
        if self.config.record_calls:
            recorded = RecordedCall(
                timestamp=datetime.now(),
                messages=messages.copy(),
                response=response,
            )
            self._recorded_calls.append(recorded)
        
        # Get chunks
        if response.response_type == MockResponseType.STREAM:
            chunks = response.metadata.get("chunks", [response.content])
            delay = response.metadata.get("delay_per_chunk_ms", 10)
        else:
            # Split content into chunks
            words = response.content.split()
            chunks = [" ".join(words[i:i+3]) for i in range(0, len(words), 3)]
            delay = 10
        
        # Yield chunks
        for i, chunk in enumerate(chunks):
            if self.config.simulate_latency and delay > 0:
                await asyncio.sleep(delay / 1000)
            
            yield {
                "id": f"mock-{self._call_index}",
                "object": "chat.completion.chunk",
                "created": int(time.time()),
                "model": "mock-model",
                "choices": [{
                    "index": 0,
                    "delta": {
                        "role": "assistant" if i == 0 else None,
                        "content": chunk + (" " if i < len(chunks) - 1 else ""),
                    },
                    "finish_reason": None if i < len(chunks) - 1 else "stop",
                }],
            }
    
    def reset(self) -> None:
        """Reset mock state."""
        self._call_index = 0
        self._recorded_calls.clear()
        self._metrics = TestMetrics()
    
    def get_calls_with_tool(self, tool_name: str) -> list[RecordedCall]:
        """Get all calls that resulted in a specific tool call."""
        return [
            call for call in self._recorded_calls
            if call.response and any(
                tc.name == tool_name for tc in call.response.tool_calls
            )
        ]
    
    def assert_called(self) -> None:
        """Assert that mock was called at least once."""
        if self.call_count == 0:
            raise AssertionError("MockLLM was never called")
    
    def assert_called_times(self, n: int) -> None:
        """Assert mock was called exactly n times."""
        if self.call_count != n:
            raise AssertionError(
                f"MockLLM was called {self.call_count} times, expected {n}"
            )
    
    def assert_last_message_contains(self, text: str) -> None:
        """Assert last user message contains text."""
        if not self.last_messages:
            raise AssertionError("No messages recorded")
        
        user_messages = [m for m in self.last_messages if m.get("role") == "user"]
        if not user_messages:
            raise AssertionError("No user messages in last call")
        
        last_user = user_messages[-1]
        content = last_user.get("content", "")
        if text not in content:
            raise AssertionError(
                f"Expected '{text}' in last user message, got: {content}"
            )


class MockLLMError(Exception):
    """Error raised by MockLLM."""
    
    def __init__(self, message: str, code: str = "error"):
        super().__init__(message)
        self.code = code


@dataclass
class MockTool:
    """
    Mock tool for testing tool execution.
    
    Example:
        ```python
        mock_search = MockTool(
            name="web_search",
            return_value={"results": ["result1", "result2"]}
        )
        
        result = await mock_search.execute(query="test")
        assert result == {"results": ["result1", "result2"]}
        assert mock_search.call_count == 1
        ```
    """
    
    config: MockToolConfig
    _call_index: int = field(default=0, init=False)
    _recorded_calls: list[RecordedCall] = field(default_factory=list, init=False)
    
    def __init__(
        self,
        name: str,
        return_value: Any = None,
        return_values: Optional[list[Any]] = None,
        side_effect: Optional[Callable[..., Any]] = None,
        delay_ms: int = 0,
    ):
        """
        Initialize MockTool.
        
        Args:
            name: Tool name
            return_value: Value to return (static)
            return_values: List of values to cycle through
            side_effect: Callable to execute instead
            delay_ms: Simulated execution delay
        """
        self.config = MockToolConfig(
            name=name,
            return_value=return_value,
            return_values=return_values or [],
            side_effect=side_effect,
            delay_ms=delay_ms,
        )
        self._call_index = 0
        self._recorded_calls = []
    
    @property
    def name(self) -> str:
        """Tool name."""
        return self.config.name
    
    @property
    def call_count(self) -> int:
        """Number of calls."""
        return len(self._recorded_calls)
    
    @property
    def recorded_calls(self) -> list[RecordedCall]:
        """Recorded calls."""
        return self._recorded_calls
    
    @property
    def last_call(self) -> Optional[RecordedCall]:
        """Last recorded call."""
        return self._recorded_calls[-1] if self._recorded_calls else None
    
    @property
    def last_args(self) -> dict[str, Any]:
        """Arguments from last call."""
        return self.last_call.tool_args if self.last_call else {}
    
    async def execute(self, **kwargs: Any) -> Any:
        """Execute the mock tool."""
        start_time = time.time()
        
        # Check if should fail
        if self.config.fail_after >= 0 and self._call_index >= self.config.fail_after:
            raise MockToolError(self.config.fail_message, self.name)
        
        # Simulate delay
        if self.config.delay_ms > 0:
            await asyncio.sleep(self.config.delay_ms / 1000)
        
        # Get return value
        if self.config.side_effect:
            if asyncio.iscoroutinefunction(self.config.side_effect):
                result = await self.config.side_effect(**kwargs)
            else:
                result = self.config.side_effect(**kwargs)
        elif self.config.return_values:
            index = self._call_index % len(self.config.return_values)
            result = self.config.return_values[index]
        else:
            result = self.config.return_value
        
        duration_ms = (time.time() - start_time) * 1000
        self._call_index += 1
        
        # Record call
        if self.config.record_calls:
            recorded = RecordedCall(
                timestamp=datetime.now(),
                tool_name=self.name,
                tool_args=kwargs,
                duration_ms=duration_ms,
            )
            self._recorded_calls.append(recorded)
        
        return result
    
    def __call__(self, **kwargs: Any) -> Any:
        """Synchronous call (for compatibility)."""
        return asyncio.get_event_loop().run_until_complete(self.execute(**kwargs))
    
    def reset(self) -> None:
        """Reset mock state."""
        self._call_index = 0
        self._recorded_calls.clear()
    
    def assert_called(self) -> None:
        """Assert tool was called at least once."""
        if self.call_count == 0:
            raise AssertionError(f"MockTool '{self.name}' was never called")
    
    def assert_called_with(self, **expected_kwargs: Any) -> None:
        """Assert tool was called with specific arguments."""
        if not self._recorded_calls:
            raise AssertionError(f"MockTool '{self.name}' was never called")
        
        for call in self._recorded_calls:
            if all(
                call.tool_args.get(k) == v 
                for k, v in expected_kwargs.items()
            ):
                return
        
        raise AssertionError(
            f"MockTool '{self.name}' was not called with {expected_kwargs}. "
            f"Recorded calls: {[c.tool_args for c in self._recorded_calls]}"
        )


class MockToolError(Exception):
    """Error raised by MockTool."""
    
    def __init__(self, message: str, tool_name: str):
        super().__init__(message)
        self.tool_name = tool_name


@dataclass
class MockToolRegistry:
    """
    Registry of mock tools for testing.
    
    Example:
        ```python
        registry = MockToolRegistry()
        registry.register(MockTool("search", return_value="results"))
        registry.register(MockTool("calculate", return_value=42))
        
        result = await registry.execute("search", query="test")
        ```
    """
    
    _tools: dict[str, MockTool] = field(default_factory=dict)
    
    def register(self, tool: MockTool) -> None:
        """Register a mock tool."""
        self._tools[tool.name] = tool
    
    def get(self, name: str) -> Optional[MockTool]:
        """Get a mock tool by name."""
        return self._tools.get(name)
    
    def has(self, name: str) -> bool:
        """Check if tool exists."""
        return name in self._tools
    
    async def execute(self, name: str, **kwargs: Any) -> Any:
        """Execute a mock tool by name."""
        tool = self._tools.get(name)
        if not tool:
            raise MockToolError(f"Tool '{name}' not found", name)
        return await tool.execute(**kwargs)
    
    def reset_all(self) -> None:
        """Reset all mock tools."""
        for tool in self._tools.values():
            tool.reset()
    
    def get_all_calls(self) -> dict[str, list[RecordedCall]]:
        """Get all recorded calls by tool name."""
        return {
            name: tool.recorded_calls
            for name, tool in self._tools.items()
        }
    
    @property
    def tools(self) -> list[MockTool]:
        """Get all registered tools."""
        return list(self._tools.values())


class MockAgent:
    """
    Mock agent for testing agent interactions.
    
    Example:
        ```python
        mock_agent = MockAgent(
            name="research_agent",
            responses=["I found the information.", "Here are the details..."]
        )
        
        result = await mock_agent.run("Research AI trends")
        ```
    """
    
    def __init__(
        self,
        name: str = "mock_agent",
        responses: Optional[list[str]] = None,
        model: Optional[MockLLM] = None,
        tools: Optional[list[MockTool]] = None,
    ):
        self.name = name
        self.model = model or MockLLM(responses=responses or ["Mock agent response"])
        self.tools = MockToolRegistry()
        if tools:
            for tool in tools:
                self.tools.register(tool)
        self._history: list[dict[str, Any]] = []
    
    @property
    def history(self) -> list[dict[str, Any]]:
        """Conversation history."""
        return self._history
    
    async def run(
        self,
        message: str,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """
        Run the mock agent with a message.
        
        Args:
            message: User message
            **kwargs: Additional arguments
            
        Returns:
            Agent response
        """
        # Add user message to history
        self._history.append({"role": "user", "content": message})
        
        # Get response from mock LLM
        response = await self.model.chat(self._history)
        
        # Extract content
        content = response["choices"][0]["message"].get("content", "")
        
        # Add to history
        self._history.append({"role": "assistant", "content": content})
        
        return {
            "content": content,
            "tool_calls": response["choices"][0]["message"].get("tool_calls", []),
            "usage": response.get("usage", {}),
        }
    
    def reset(self) -> None:
        """Reset agent state."""
        self._history.clear()
        self.model.reset()
        self.tools.reset_all()
