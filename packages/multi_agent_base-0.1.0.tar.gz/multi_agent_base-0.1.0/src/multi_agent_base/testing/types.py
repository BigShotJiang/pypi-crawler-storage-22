"""
Agent Testing Framework - Core Types

Type definitions for agent testing framework including mock configurations,
test results, and assertion types.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Optional, TypeVar
from datetime import datetime


# Type variable for generic types
T = TypeVar("T")


class MockResponseType(Enum):
    """Type of mock response."""
    
    TEXT = "text"
    TOOL_CALL = "tool_call"
    ERROR = "error"
    STREAM = "stream"
    MULTI_TURN = "multi_turn"


class AssertionType(Enum):
    """Type of assertion."""
    
    TOOL_CALLED = "tool_called"
    TOOL_NOT_CALLED = "tool_not_called"
    RESPONSE_CONTAINS = "response_contains"
    RESPONSE_MATCHES = "response_matches"
    COST_UNDER = "cost_under"
    TOKENS_UNDER = "tokens_under"
    LATENCY_UNDER = "latency_under"
    TURN_COUNT = "turn_count"
    CUSTOM = "custom"


class TestStatus(Enum):
    """Status of a test execution."""
    
    PENDING = "pending"
    RUNNING = "running"
    PASSED = "passed"
    FAILED = "failed"
    SKIPPED = "skipped"
    ERROR = "error"


@dataclass
class MockToolCall:
    """Represents a mock tool call response."""
    
    name: str
    arguments: dict[str, Any] = field(default_factory=dict)
    result: Any = None
    error: Optional[str] = None
    call_id: str = ""
    
    def __post_init__(self):
        if not self.call_id:
            import uuid
            self.call_id = f"call_{uuid.uuid4().hex[:8]}"
    
    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary representation."""
        return {
            "name": self.name,
            "arguments": self.arguments,
            "result": self.result,
            "error": self.error,
            "call_id": self.call_id,
        }
    
    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "MockToolCall":
        """Create from dictionary."""
        return cls(
            name=data.get("name", ""),
            arguments=data.get("arguments", {}),
            result=data.get("result"),
            error=data.get("error"),
            call_id=data.get("call_id", ""),
        )


@dataclass
class MockResponse:
    """Represents a single mock response."""
    
    content: str = ""
    tool_calls: list[MockToolCall] = field(default_factory=list)
    response_type: MockResponseType = MockResponseType.TEXT
    delay_ms: int = 0  # Simulated latency
    tokens_used: int = 0
    finish_reason: str = "stop"
    metadata: dict[str, Any] = field(default_factory=dict)
    
    @classmethod
    def text(cls, content: str, delay_ms: int = 0) -> "MockResponse":
        """Create a text response."""
        return cls(
            content=content,
            response_type=MockResponseType.TEXT,
            delay_ms=delay_ms,
            tokens_used=len(content.split()) * 2,  # Approximate
        )
    
    @classmethod
    def tool_call(
        cls,
        name: str,
        arguments: dict[str, Any],
        result: Any = None,
        delay_ms: int = 0,
    ) -> "MockResponse":
        """Create a tool call response."""
        return cls(
            tool_calls=[MockToolCall(name=name, arguments=arguments, result=result)],
            response_type=MockResponseType.TOOL_CALL,
            delay_ms=delay_ms,
            finish_reason="tool_calls",
        )
    
    @classmethod
    def error(cls, message: str, code: str = "error") -> "MockResponse":
        """Create an error response."""
        return cls(
            content=message,
            response_type=MockResponseType.ERROR,
            metadata={"error_code": code},
        )
    
    @classmethod
    def stream(cls, chunks: list[str], delay_per_chunk_ms: int = 10) -> "MockResponse":
        """Create a streaming response."""
        return cls(
            content="".join(chunks),
            response_type=MockResponseType.STREAM,
            metadata={
                "chunks": chunks,
                "delay_per_chunk_ms": delay_per_chunk_ms,
            },
        )
    
    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary representation."""
        return {
            "content": self.content,
            "tool_calls": [tc.to_dict() for tc in self.tool_calls],
            "response_type": self.response_type.value,
            "delay_ms": self.delay_ms,
            "tokens_used": self.tokens_used,
            "finish_reason": self.finish_reason,
            "metadata": self.metadata,
        }


@dataclass
class MockLLMConfig:
    """Configuration for mock LLM behavior."""
    
    responses: list[MockResponse] = field(default_factory=list)
    default_response: Optional[MockResponse] = None
    cycle_responses: bool = False  # If True, cycle through responses
    fail_after: int = -1  # Fail after N calls (-1 = never)
    fail_message: str = "Mock failure"
    record_calls: bool = True
    simulate_latency: bool = True
    
    def add_response(self, response: MockResponse | str) -> "MockLLMConfig":
        """Add a response to the queue."""
        if isinstance(response, str):
            response = MockResponse.text(response)
        self.responses.append(response)
        return self
    
    def add_responses(self, *responses: MockResponse | str) -> "MockLLMConfig":
        """Add multiple responses."""
        for response in responses:
            self.add_response(response)
        return self
    
    @classmethod
    def from_strings(cls, *responses: str, cycle: bool = False) -> "MockLLMConfig":
        """Create config from string responses."""
        config = cls(cycle_responses=cycle)
        for response in responses:
            config.add_response(response)
        return config


@dataclass 
class MockToolConfig:
    """Configuration for mock tool behavior."""
    
    name: str
    return_value: Any = None
    return_values: list[Any] = field(default_factory=list)  # Cycle through these
    side_effect: Optional[Callable[..., Any]] = None
    fail_after: int = -1
    fail_message: str = "Mock tool failure"
    delay_ms: int = 0
    record_calls: bool = True
    
    def __post_init__(self):
        if self.return_values is None:
            self.return_values = []


@dataclass
class RecordedCall:
    """A recorded call to mock LLM or tool."""
    
    timestamp: datetime = field(default_factory=datetime.now)
    messages: list[dict[str, Any]] = field(default_factory=list)
    response: Optional[MockResponse] = None
    tool_name: Optional[str] = None
    tool_args: dict[str, Any] = field(default_factory=dict)
    duration_ms: float = 0.0
    error: Optional[str] = None
    
    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary representation."""
        return {
            "timestamp": self.timestamp.isoformat(),
            "messages": self.messages,
            "response": self.response.to_dict() if self.response else None,
            "tool_name": self.tool_name,
            "tool_args": self.tool_args,
            "duration_ms": self.duration_ms,
            "error": self.error,
        }


@dataclass
class AssertionResult:
    """Result of an assertion check."""
    
    assertion_type: AssertionType
    passed: bool
    message: str
    expected: Any = None
    actual: Any = None
    details: dict[str, Any] = field(default_factory=dict)
    
    def __bool__(self) -> bool:
        return self.passed
    
    def raise_if_failed(self) -> None:
        """Raise AssertionError if failed."""
        if not self.passed:
            raise AssertionError(
                f"{self.assertion_type.value} failed: {self.message}\n"
                f"Expected: {self.expected}\n"
                f"Actual: {self.actual}"
            )


@dataclass
class TestMetrics:
    """Metrics collected during test execution."""
    
    total_calls: int = 0
    total_tokens: int = 0
    total_cost: float = 0.0
    total_duration_ms: float = 0.0
    tool_calls: dict[str, int] = field(default_factory=dict)  # tool_name -> call_count
    error_count: int = 0
    
    def record_call(
        self,
        tokens: int = 0,
        cost: float = 0.0,
        duration_ms: float = 0.0,
        tool_name: Optional[str] = None,
        is_error: bool = False,
    ) -> None:
        """Record a call."""
        self.total_calls += 1
        self.total_tokens += tokens
        self.total_cost += cost
        self.total_duration_ms += duration_ms
        if tool_name:
            self.tool_calls[tool_name] = self.tool_calls.get(tool_name, 0) + 1
        if is_error:
            self.error_count += 1
    
    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary representation."""
        return {
            "total_calls": self.total_calls,
            "total_tokens": self.total_tokens,
            "total_cost": self.total_cost,
            "total_duration_ms": self.total_duration_ms,
            "tool_calls": self.tool_calls,
            "error_count": self.error_count,
        }


@dataclass
class TestResult:
    """Result of a test execution."""
    
    name: str
    status: TestStatus
    duration_ms: float
    assertions: list[AssertionResult] = field(default_factory=list)
    metrics: TestMetrics = field(default_factory=TestMetrics)
    error: Optional[str] = None
    traceback: Optional[str] = None
    recorded_calls: list[RecordedCall] = field(default_factory=list)
    tags: list[str] = field(default_factory=list)
    
    @property
    def passed(self) -> bool:
        """Check if test passed."""
        return self.status == TestStatus.PASSED
    
    @property
    def failed(self) -> bool:
        """Check if test failed."""
        return self.status == TestStatus.FAILED
    
    @property
    def assertion_count(self) -> int:
        """Count of assertions."""
        return len(self.assertions)
    
    @property
    def passed_assertions(self) -> int:
        """Count of passed assertions."""
        return sum(1 for a in self.assertions if a.passed)
    
    @property
    def failed_assertions(self) -> int:
        """Count of failed assertions."""
        return sum(1 for a in self.assertions if not a.passed)
    
    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary representation."""
        return {
            "name": self.name,
            "status": self.status.value,
            "duration_ms": self.duration_ms,
            "passed": self.passed,
            "assertion_count": self.assertion_count,
            "passed_assertions": self.passed_assertions,
            "failed_assertions": self.failed_assertions,
            "error": self.error,
            "metrics": self.metrics.to_dict(),
            "tags": self.tags,
        }


@dataclass
class TestSuiteResult:
    """Result of a test suite execution."""
    
    name: str
    tests: list[TestResult] = field(default_factory=list)
    start_time: datetime = field(default_factory=datetime.now)
    end_time: Optional[datetime] = None
    
    @property
    def total_tests(self) -> int:
        """Total number of tests."""
        return len(self.tests)
    
    @property
    def passed_tests(self) -> int:
        """Number of passed tests."""
        return sum(1 for t in self.tests if t.passed)
    
    @property
    def failed_tests(self) -> int:
        """Number of failed tests."""
        return sum(1 for t in self.tests if t.failed)
    
    @property
    def skipped_tests(self) -> int:
        """Number of skipped tests."""
        return sum(1 for t in self.tests if t.status == TestStatus.SKIPPED)
    
    @property
    def total_duration_ms(self) -> float:
        """Total duration of all tests."""
        return sum(t.duration_ms for t in self.tests)
    
    @property
    def pass_rate(self) -> float:
        """Pass rate as percentage."""
        if self.total_tests == 0:
            return 0.0
        return (self.passed_tests / self.total_tests) * 100
    
    def add_test(self, result: TestResult) -> None:
        """Add a test result."""
        self.tests.append(result)
    
    def finalize(self) -> None:
        """Finalize the suite (set end time)."""
        self.end_time = datetime.now()
    
    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary representation."""
        return {
            "name": self.name,
            "total_tests": self.total_tests,
            "passed_tests": self.passed_tests,
            "failed_tests": self.failed_tests,
            "skipped_tests": self.skipped_tests,
            "pass_rate": self.pass_rate,
            "total_duration_ms": self.total_duration_ms,
            "start_time": self.start_time.isoformat(),
            "end_time": self.end_time.isoformat() if self.end_time else None,
            "tests": [t.to_dict() for t in self.tests],
        }
    
    def summary(self) -> str:
        """Generate a summary string."""
        status = "✅" if self.failed_tests == 0 else "❌"
        return (
            f"{status} {self.name}: "
            f"{self.passed_tests}/{self.total_tests} passed "
            f"({self.pass_rate:.1f}%) in {self.total_duration_ms:.2f}ms"
        )


@dataclass
class ConversationTurn:
    """Represents a turn in a test conversation."""
    
    user_message: str
    expected_response: Optional[str] = None
    expected_tool_calls: list[str] = field(default_factory=list)
    expected_contains: list[str] = field(default_factory=list)
    expected_not_contains: list[str] = field(default_factory=list)
    timeout_ms: int = 30000
    
    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary representation."""
        return {
            "user_message": self.user_message,
            "expected_response": self.expected_response,
            "expected_tool_calls": self.expected_tool_calls,
            "expected_contains": self.expected_contains,
            "expected_not_contains": self.expected_not_contains,
            "timeout_ms": self.timeout_ms,
        }


@dataclass
class TestScenario:
    """A test scenario with multiple conversation turns."""
    
    name: str
    description: str = ""
    turns: list[ConversationTurn] = field(default_factory=list)
    setup: Optional[Callable] = None
    teardown: Optional[Callable] = None
    tags: list[str] = field(default_factory=list)
    
    def add_turn(
        self,
        user_message: str,
        expected_response: Optional[str] = None,
        expected_tool_calls: Optional[list[str]] = None,
        expected_contains: Optional[list[str]] = None,
    ) -> "TestScenario":
        """Add a conversation turn."""
        self.turns.append(ConversationTurn(
            user_message=user_message,
            expected_response=expected_response,
            expected_tool_calls=expected_tool_calls or [],
            expected_contains=expected_contains or [],
        ))
        return self
    
    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary representation."""
        return {
            "name": self.name,
            "description": self.description,
            "turns": [t.to_dict() for t in self.turns],
            "tags": self.tags,
        }
