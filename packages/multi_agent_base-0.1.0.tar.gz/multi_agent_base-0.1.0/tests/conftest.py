"""
Pytest fixtures for Multi-Agent Base Framework tests.
"""

import pytest
from unittest.mock import MagicMock, AsyncMock
from typing import Any, Dict, List

from multi_agent_base.core.config import (
    SystemConfig,
    ProviderConfig,
    AgentConfig,
    PatternConfig,
    ObservabilityConfig,
)
from multi_agent_base.core.agent import BaseAgent
from multi_agent_base.a2a.agent_card import AgentCard, AgentSkill, AgentCapabilities
from multi_agent_base.cost.tracker import CostTracker


# ============================================================================
# Configuration Fixtures
# ============================================================================

@pytest.fixture
def provider_config() -> ProviderConfig:
    """Create a test provider configuration."""
    return ProviderConfig(
        provider="openai",
        model="gpt-4o-mini",
        api_key="test-api-key",
        base_url=None,
        temperature=0.7,
        max_tokens=4096,
    )


@pytest.fixture
def ollama_provider_config() -> ProviderConfig:
    """Create an Ollama provider configuration."""
    return ProviderConfig(
        provider="ollama",
        model="llama3.2",
        base_url="http://localhost:11434",
        temperature=0.7,
        max_tokens=4096,
    )


@pytest.fixture
def anthropic_provider_config() -> ProviderConfig:
    """Create an Anthropic provider configuration."""
    return ProviderConfig(
        provider="anthropic",
        model="claude-3-5-sonnet-20241022",
        api_key="test-anthropic-key",
        temperature=0.7,
        max_tokens=4096,
    )


@pytest.fixture
def agent_config(provider_config: ProviderConfig) -> AgentConfig:
    """Create a test agent configuration."""
    return AgentConfig(
        name="test-agent",
        description="A test agent for unit testing",
        system_prompt="You are a helpful test assistant.",
        provider=provider_config,
        tools=[],
        metadata={"test": True},
    )


@pytest.fixture
def observability_config() -> ObservabilityConfig:
    """Create a test observability configuration."""
    return ObservabilityConfig(
        enabled=True,
        phoenix_endpoint="http://localhost:6006",
        log_level="DEBUG",
        log_file="test.log",
        trace_sample_rate=1.0,
    )


@pytest.fixture
def pattern_config() -> PatternConfig:
    """Create a test pattern configuration."""
    return PatternConfig(
        pattern_type="single",
        agents=[],
        supervisor_name="test-supervisor",
        max_iterations=10,
        allow_handoffs=True,
    )


@pytest.fixture
def system_config(
    observability_config: ObservabilityConfig,
    pattern_config: PatternConfig,
) -> SystemConfig:
    """Create a complete system configuration."""
    return SystemConfig(
        observability=observability_config,
        pattern_config=pattern_config,
    )


# ============================================================================
# Tool Fixtures
# ============================================================================

@pytest.fixture
def sample_tools() -> List[callable]:
    """Create sample tools for testing."""
    
    def add_numbers(a: int, b: int) -> int:
        """Add two numbers together.
        
        Args:
            a: First number to add
            b: Second number to add
            
        Returns:
            The sum of a and b
        """
        return a + b
    
    def multiply_numbers(x: float, y: float) -> float:
        """Multiply two numbers.
        
        Args:
            x: First number
            y: Second number
            
        Returns:
            Product of x and y
        """
        return x * y
    
    def get_weather(city: str, units: str = "celsius") -> Dict[str, Any]:
        """Get weather information for a city.
        
        Args:
            city: Name of the city
            units: Temperature units (celsius or fahrenheit)
            
        Returns:
            Weather information dictionary
        """
        return {
            "city": city,
            "temperature": 22,
            "units": units,
            "condition": "sunny",
        }
    
    async def async_search(query: str, max_results: int = 10) -> List[str]:
        """Search for information asynchronously.
        
        Args:
            query: Search query string
            max_results: Maximum number of results to return
            
        Returns:
            List of search results
        """
        return [f"Result {i} for: {query}" for i in range(max_results)]
    
    return [add_numbers, multiply_numbers, get_weather, async_search]


@pytest.fixture
def calculator_tool():
    """Create a calculator tool."""
    def calculate(expression: str) -> float:
        """Evaluate a mathematical expression.
        
        Args:
            expression: Mathematical expression to evaluate
            
        Returns:
            Result of the calculation
        """
        # Simple safe eval for testing
        allowed_chars = set("0123456789+-*/.(). ")
        if all(c in allowed_chars for c in expression):
            return eval(expression)
        return 0.0
    
    return calculate


# ============================================================================
# Agent Card Fixtures
# ============================================================================

@pytest.fixture
def agent_skill() -> AgentSkill:
    """Create a sample agent skill."""
    return AgentSkill(
        id="skill-001",
        name="calculate",
        description="Perform mathematical calculations",
        input_modes=["text"],
        output_modes=["text"],
        tags=["math", "calculation"],
    )


@pytest.fixture
def agent_capabilities() -> AgentCapabilities:
    """Create sample agent capabilities."""
    return AgentCapabilities(
        streaming=True,
        push_notifications=False,
        state_transition_history=True,
    )


@pytest.fixture
def agent_card(
    agent_skill: AgentSkill,
    agent_capabilities: AgentCapabilities,
) -> AgentCard:
    """Create a sample agent card."""
    return AgentCard(
        name="test-agent",
        description="A test agent for unit testing",
        url="http://localhost:8000/agent/test-agent",
        version="1.0.0",
        provider={"organization": "Test Provider", "url": "https://test.example.com"},
        skills=[agent_skill],
        capabilities=agent_capabilities,
        default_input_modes=["text"],
        default_output_modes=["text"],
    )


# ============================================================================
# Cost Tracker Fixtures
# ============================================================================

@pytest.fixture
def cost_tracker() -> CostTracker:
    """Create a cost tracker instance."""
    return CostTracker()


# ============================================================================
# Mock Fixtures
# ============================================================================

@pytest.fixture
def mock_model_client():
    """Create a mock model client."""
    client = MagicMock()
    client.create_completion = AsyncMock(return_value={
        "content": "Test response",
        "usage": {
            "prompt_tokens": 100,
            "completion_tokens": 50,
        },
    })
    return client


@pytest.fixture
def mock_phoenix_manager():
    """Create a mock Phoenix manager."""
    manager = MagicMock()
    manager.tracer = MagicMock()
    manager.start_span = MagicMock()
    manager.end_span = MagicMock()
    return manager


@pytest.fixture
def mock_agent(mock_model_client, sample_tools):
    """Create a mock agent for testing."""
    agent = MagicMock(spec=BaseAgent)
    agent.name = "mock-agent"
    agent.description = "A mock agent"
    agent.tools = sample_tools
    agent.client = mock_model_client
    return agent


# ============================================================================
# Async Test Helpers
# ============================================================================

@pytest.fixture
def event_loop():
    """Create an event loop for async tests."""
    import asyncio
    loop = asyncio.new_event_loop()
    yield loop
    loop.close()
