"""
Tests for A2A Protocol v2 Enhancements.

Tests HTTP server/client, conversation threading, and error handling.
"""

import asyncio
import json
import pytest
from datetime import datetime, timedelta
from unittest.mock import AsyncMock, MagicMock, patch

from multi_agent_base.a2a import (
    # Core types
    AgentCard,
    AgentSkill,
    AgentCapabilities,
    # HTTP
    A2AServer,
    A2AServerConfig,
    A2AClient,
    A2ARegistry,
    # Threading
    ConversationThread,
    ThreadMessage,
    ThreadContext,
    ThreadManager,
    ThreadState,
    MessageRole,
    MessageStatus,
    # Errors
    A2AError,
    A2AErrorCode,
    A2AErrorDetails,
    A2AErrorHandler,
    A2ADiscoveryError,
    A2AConnectionError,
    A2ATimeoutError,
    A2AAuthenticationError,
    A2AProtocolError,
    A2AAgentError,
    A2AThreadError,
    A2AValidationError,
    A2ARateLimitError,
)


# =============================================================================
# HTTP Server Tests
# =============================================================================

class TestA2AServerConfig:
    """Tests for A2AServerConfig."""
    
    def test_default_config(self):
        """Test default configuration values."""
        config = A2AServerConfig()
        
        assert config.host == "0.0.0.0"
        assert config.port == 8080
        assert config.base_path == ""
        assert config.cors_origins == ["*"]
        assert config.enable_discovery is True
        assert config.agent_card is None
    
    def test_custom_config(self):
        """Test custom configuration values."""
        card = AgentCard(
            name="test-agent",
            description="Test",
            url="http://localhost:8080",
        )
        config = A2AServerConfig(
            host="localhost",
            port=9000,
            base_path="/api",
            cors_origins=["http://localhost:3000"],
            enable_discovery=False,
            agent_card=card,
        )
        
        assert config.host == "localhost"
        assert config.port == 9000
        assert config.base_path == "/api"
        assert config.cors_origins == ["http://localhost:3000"]
        assert config.enable_discovery is False
        assert config.agent_card is card


class TestA2AServer:
    """Tests for A2AServer."""
    
    def test_server_initialization(self):
        """Test server initialization."""
        config = A2AServerConfig()
        server = A2AServer(config)
        
        assert server.config == config
        assert not server._running
        assert "/.well-known/agent-card.json" in server._routes
        assert "/health" in server._routes
    
    def test_server_with_agent_card(self):
        """Test server with agent card."""
        card = AgentCard(
            name="test-agent",
            description="A test agent",
            url="http://localhost:8080",
        )
        config = A2AServerConfig(agent_card=card)
        server = A2AServer(config)
        
        assert server._agent_card == card
    
    def test_set_agent_card(self):
        """Test setting agent card after initialization."""
        server = A2AServer(A2AServerConfig())
        card = AgentCard(
            name="new-agent",
            description="New agent",
            url="http://localhost:8080",
        )
        
        server.set_agent_card(card)
        assert server._agent_card == card
    
    def test_get_agent_card(self):
        """Test getting agent card."""
        card = AgentCard(
            name="test-agent",
            description="Test",
            url="http://localhost:8080",
        )
        config = A2AServerConfig(agent_card=card)
        server = A2AServer(config)
        
        assert server.get_agent_card() == card
    
    def test_discovery_route_enabled(self):
        """Test discovery route is registered when enabled."""
        config = A2AServerConfig(enable_discovery=True)
        server = A2AServer(config)
        
        assert "/a2a/discover" in server._routes
    
    def test_discovery_route_disabled(self):
        """Test discovery route not registered when disabled."""
        config = A2AServerConfig(enable_discovery=False)
        server = A2AServer(config)
        
        assert "/a2a/discover" not in server._routes
    
    @pytest.mark.asyncio
    async def test_handle_agent_card(self):
        """Test agent card endpoint handler."""
        card = AgentCard(
            name="test-agent",
            description="Test agent",
            url="http://localhost:8080",
        )
        config = A2AServerConfig(agent_card=card)
        server = A2AServer(config)
        
        handler = server._routes["/.well-known/agent-card.json"]
        response = await handler({})
        
        assert response["status"] == 200
        assert "body" in response
    
    @pytest.mark.asyncio
    async def test_handle_agent_card_not_configured(self):
        """Test agent card endpoint when not configured."""
        server = A2AServer(A2AServerConfig())
        
        handler = server._routes["/.well-known/agent-card.json"]
        response = await handler({})
        
        assert response["status"] == 404
    
    @pytest.mark.asyncio
    async def test_handle_health(self):
        """Test health endpoint handler."""
        server = A2AServer(A2AServerConfig())
        
        handler = server._routes["/health"]
        response = await handler({})
        
        assert response["status"] == 200
        assert "healthy" in str(response["body"]).lower()
    
    @pytest.mark.asyncio
    async def test_handle_request(self):
        """Test handle_request method."""
        card = AgentCard(
            name="test-agent",
            description="Test",
            url="http://localhost:8080",
        )
        config = A2AServerConfig(agent_card=card)
        server = A2AServer(config)
        
        response = await server.handle_request("GET", "/health")
        assert response["status"] == 200
    
    @pytest.mark.asyncio
    async def test_handle_request_not_found(self):
        """Test handle_request with unknown path."""
        server = A2AServer(A2AServerConfig())
        
        response = await server.handle_request("GET", "/unknown")
        assert response["status"] == 404
    
    def test_register_route(self):
        """Test registering custom routes."""
        server = A2AServer(A2AServerConfig())
        
        async def custom_handler(request):
            return {"status": 200, "body": "custom"}
        
        server.register_route("/custom", custom_handler)
        assert "/custom" in server._routes
    
    def test_get_routes(self):
        """Test getting all routes."""
        server = A2AServer(A2AServerConfig())
        routes = server.get_routes()
        
        assert "/.well-known/agent-card.json" in routes
        assert "/health" in routes
    
    @pytest.mark.asyncio
    async def test_start_stop(self):
        """Test start and stop methods."""
        server = A2AServer(A2AServerConfig())
        
        assert not server.is_running
        
        await server.start()
        assert server.is_running
        
        await server.stop()
        assert not server.is_running


class TestA2AClient:
    """Tests for A2AClient."""
    
    def test_client_initialization(self):
        """Test client initialization."""
        client = A2AClient()
        
        assert client.timeout == 30.0
        assert client.retry_count == 3
        assert client.verify_ssl is True
        assert client._cache == {}
    
    def test_client_with_custom_settings(self):
        """Test client with custom settings."""
        client = A2AClient(timeout=60.0, retry_count=5, verify_ssl=False)
        
        assert client.timeout == 60.0
        assert client.retry_count == 5
        assert client.verify_ssl is False
    
    def test_build_agent_card_url(self):
        """Test URL building."""
        client = A2AClient()
        
        url = client._build_agent_card_url("http://localhost:8080")
        assert url == "http://localhost:8080/.well-known/agent-card.json"
        
        url = client._build_agent_card_url("http://localhost:8080/")
        assert url == "http://localhost:8080/.well-known/agent-card.json"
    
    def test_clear_cache(self):
        """Test clearing the cache."""
        client = A2AClient()
        card = AgentCard(
            name="a1",
            description="A1",
            url="http://localhost:8080",
        )
        client.cache_card("url1", card)
        
        client.clear_cache()
        
        assert len(client._cache) == 0
    
    def test_cache_card(self):
        """Test manually caching an agent card."""
        client = A2AClient()
        card = AgentCard(
            name="test",
            description="Test",
            url="http://localhost:8080",
        )
        
        client.cache_card("http://localhost:8080", card)
        
        assert client._cache["http://localhost:8080"] == card
    
    def test_get_skill(self):
        """Test getting skill from card."""
        client = A2AClient()
        card = AgentCard(
            name="test",
            description="Test",
            url="http://localhost:8080",
            skills=[
                AgentSkill(id="translate", name="Translate", description="Translate text"),
                AgentSkill(id="summarize", name="Summarize", description="Summarize text"),
            ],
        )
        
        skill = client.get_skill(card, "translate")
        assert skill is not None
        assert skill.id == "translate"
        
        skill = client.get_skill(card, "nonexistent")
        assert skill is None
    
    def test_get_skills_by_tag(self):
        """Test getting skills by tag."""
        client = A2AClient()
        card = AgentCard(
            name="test",
            description="Test",
            url="http://localhost:8080",
            skills=[
                AgentSkill(id="s1", name="S1", description="Skill 1", tags=["nlp", "text"]),
                AgentSkill(id="s2", name="S2", description="Skill 2", tags=["vision"]),
                AgentSkill(id="s3", name="S3", description="Skill 3", tags=["nlp"]),
            ],
        )
        
        nlp_skills = client.get_skills_by_tag(card, "nlp")
        assert len(nlp_skills) == 2
    
    @pytest.mark.asyncio
    async def test_discover_from_card_data(self):
        """Test creating card from data."""
        client = A2AClient()
        data = {
            "name": "test-agent",
            "description": "Test agent",
            "url": "http://localhost:8080",
        }
        
        card = await client.discover_from_card_data(data)
        assert card.name == "test-agent"


class TestA2ARegistry:
    """Tests for A2ARegistry."""
    
    def test_registry_initialization(self):
        """Test registry initialization."""
        registry = A2ARegistry()
        
        assert len(registry.agents) == 0
        assert len(registry.endpoints) == 0
    
    def test_register_agent(self):
        """Test registering an agent."""
        registry = A2ARegistry()
        card = AgentCard(
            name="agent1",
            description="Agent 1",
            url="http://localhost:8080",
        )
        
        registry.register(card)
        
        assert "agent1" in registry.agents
        assert registry.agents["agent1"] == card
    
    def test_unregister_agent(self):
        """Test unregistering an agent."""
        registry = A2ARegistry()
        card = AgentCard(
            name="agent1",
            description="Agent 1",
            url="http://localhost:8080",
        )
        registry.register(card)
        
        registry.unregister("agent1")
        
        assert "agent1" not in registry.agents
    
    def test_get_by_name(self):
        """Test getting an agent by name."""
        registry = A2ARegistry()
        card = AgentCard(
            name="agent1",
            description="Agent 1",
            url="http://localhost:8080",
        )
        registry.register(card)
        
        result = registry.get_by_name("agent1")
        
        assert result == card
    
    def test_get_by_name_nonexistent(self):
        """Test getting nonexistent agent returns None."""
        registry = A2ARegistry()
        
        result = registry.get_by_name("nonexistent")
        
        assert result is None
    
    def test_get_by_url(self):
        """Test getting agent by URL."""
        registry = A2ARegistry()
        card = AgentCard(
            name="agent1",
            description="Agent 1",
            url="http://localhost:8080",
        )
        registry.register(card)
        
        result = registry.get_by_url("http://localhost:8080")
        
        assert result == card
    
    def test_list_all(self):
        """Test listing all agents."""
        registry = A2ARegistry()
        card1 = AgentCard(
            name="agent1",
            description="Agent 1",
            url="http://localhost:8080",
        )
        card2 = AgentCard(
            name="agent2",
            description="Agent 2",
            url="http://localhost:8081",
        )
        registry.register(card1)
        registry.register(card2)
        
        agents = registry.list_all()
        
        assert len(agents) == 2
        assert card1 in agents
        assert card2 in agents
    
    def test_find_by_skill(self):
        """Test finding agents by skill."""
        registry = A2ARegistry()
        
        card1 = AgentCard(
            name="agent1",
            description="Agent 1",
            url="http://localhost:8080",
            skills=[AgentSkill(id="translate", name="Translate", description="Translate text")],
        )
        card2 = AgentCard(
            name="agent2",
            description="Agent 2",
            url="http://localhost:8081",
            skills=[AgentSkill(id="summarize", name="Summarize", description="Summarize text")],
        )
        card3 = AgentCard(
            name="agent3",
            description="Agent 3",
            url="http://localhost:8082",
            skills=[
                AgentSkill(id="translate", name="Translate", description="Translate text"),
                AgentSkill(id="summarize", name="Summarize", description="Summarize text"),
            ],
        )
        
        registry.register(card1)
        registry.register(card2)
        registry.register(card3)
        
        translators = registry.find_by_skill("translate")
        
        assert len(translators) == 2
        assert card1 in translators
        assert card3 in translators
    
    def test_find_by_tag(self):
        """Test finding agents by skill tag."""
        registry = A2ARegistry()
        
        card = AgentCard(
            name="agent1",
            description="Agent 1",
            url="http://localhost:8080",
            skills=[AgentSkill(id="s1", name="S1", description="Skill 1", tags=["nlp"])],
        )
        registry.register(card)
        
        results = registry.find_by_tag("nlp")
        assert len(results) == 1
    
    def test_clear(self):
        """Test clearing registry."""
        registry = A2ARegistry()
        card = AgentCard(
            name="agent1",
            description="Agent 1",
            url="http://localhost:8080",
        )
        registry.register(card)
        
        registry.clear()
        
        assert len(registry.agents) == 0
        assert len(registry.endpoints) == 0


# =============================================================================
# Threading Tests
# =============================================================================

class TestMessageRole:
    """Tests for MessageRole enum."""
    
    def test_message_roles(self):
        """Test message role values."""
        assert MessageRole.USER.value == "user"
        assert MessageRole.AGENT.value == "agent"
        assert MessageRole.SYSTEM.value == "system"


class TestMessageStatus:
    """Tests for MessageStatus enum."""
    
    def test_message_statuses(self):
        """Test message status values."""
        assert MessageStatus.PENDING.value == "pending"
        assert MessageStatus.DELIVERED.value == "delivered"
        assert MessageStatus.PROCESSED.value == "processed"
        assert MessageStatus.FAILED.value == "failed"


class TestThreadState:
    """Tests for ThreadState enum."""
    
    def test_thread_states(self):
        """Test thread state values."""
        assert ThreadState.ACTIVE.value == "active"
        assert ThreadState.PAUSED.value == "paused"
        assert ThreadState.COMPLETED.value == "completed"
        assert ThreadState.CANCELLED.value == "cancelled"


class TestThreadMessage:
    """Tests for ThreadMessage."""
    
    def test_default_message(self):
        """Test default message creation."""
        msg = ThreadMessage()
        
        assert msg.id is not None
        assert msg.thread_id == ""
        assert msg.role == MessageRole.USER
        assert msg.content == ""
        assert msg.content_type == "text/plain"
        assert msg.status == MessageStatus.PENDING
        assert msg.metadata == {}
        assert isinstance(msg.created_at, datetime)
        assert msg.parent_message_id is None
        assert msg.artifacts == []
    
    def test_custom_message(self):
        """Test custom message creation."""
        now = datetime.now()
        msg = ThreadMessage(
            id="msg-123",
            thread_id="thread-456",
            role=MessageRole.AGENT,
            content="Hello, world!",
            content_type="text/markdown",
            status=MessageStatus.DELIVERED,
            metadata={"key": "value"},
            created_at=now,
            parent_message_id="msg-100",
            artifacts=[{"type": "file", "name": "doc.pdf"}],
        )
        
        assert msg.id == "msg-123"
        assert msg.thread_id == "thread-456"
        assert msg.role == MessageRole.AGENT
        assert msg.content == "Hello, world!"
        assert msg.content_type == "text/markdown"
        assert msg.status == MessageStatus.DELIVERED
        assert msg.metadata == {"key": "value"}
        assert msg.created_at == now
        assert msg.parent_message_id == "msg-100"
        assert len(msg.artifacts) == 1
    
    def test_to_dict(self):
        """Test message serialization."""
        msg = ThreadMessage(
            id="msg-123",
            thread_id="thread-456",
            role=MessageRole.USER,
            content="Test content",
        )
        
        data = msg.to_dict()
        
        assert data["id"] == "msg-123"
        assert data["thread_id"] == "thread-456"
        assert data["role"] == "user"
        assert data["content"] == "Test content"
        assert "created_at" in data
    
    def test_from_dict(self):
        """Test message deserialization."""
        data = {
            "id": "msg-789",
            "thread_id": "thread-123",
            "role": "agent",
            "content": "Response",
            "status": "processed",
            "created_at": "2024-01-01T12:00:00",
        }
        
        msg = ThreadMessage.from_dict(data)
        
        assert msg.id == "msg-789"
        assert msg.thread_id == "thread-123"
        assert msg.role == MessageRole.AGENT
        assert msg.content == "Response"
        assert msg.status == MessageStatus.PROCESSED


class TestThreadContext:
    """Tests for ThreadContext."""
    
    def test_default_context(self):
        """Test default context creation."""
        ctx = ThreadContext()
        
        assert ctx.variables == {}
        assert ctx.agent_states == {}
        assert ctx.summary == ""
        assert ctx.key_points == []
    
    def test_custom_context(self):
        """Test custom context creation."""
        ctx = ThreadContext(
            variables={"user_name": "Alice"},
            agent_states={"agent1": {"status": "ready"}},
            summary="Previous conversation summary",
            key_points=["Point 1", "Point 2"],
        )
        
        assert ctx.variables == {"user_name": "Alice"}
        assert ctx.agent_states == {"agent1": {"status": "ready"}}
        assert ctx.summary == "Previous conversation summary"
        assert ctx.key_points == ["Point 1", "Point 2"]
    
    def test_set_variable(self):
        """Test setting context variable."""
        ctx = ThreadContext()
        
        ctx.set_variable("key", "value")
        
        assert ctx.variables["key"] == "value"
    
    def test_get_variable(self):
        """Test getting context variable."""
        ctx = ThreadContext(variables={"key": "value"})
        
        result = ctx.get_variable("key")
        
        assert result == "value"
    
    def test_get_variable_with_default(self):
        """Test getting variable with default."""
        ctx = ThreadContext()
        
        result = ctx.get_variable("nonexistent", "default")
        
        assert result == "default"
    
    def test_add_key_point(self):
        """Test adding key points."""
        ctx = ThreadContext()
        
        ctx.add_key_point("Point 1")
        ctx.add_key_point("Point 2")
        ctx.add_key_point("Point 1")  # Duplicate
        
        assert len(ctx.key_points) == 2
    
    def test_update_summary(self):
        """Test updating summary."""
        ctx = ThreadContext()
        
        ctx.update_summary("New summary")
        
        assert ctx.summary == "New summary"
    
    def test_to_dict(self):
        """Test context serialization."""
        ctx = ThreadContext(
            variables={"key": "value"},
            summary="Summary",
        )
        
        data = ctx.to_dict()
        
        assert data["variables"] == {"key": "value"}
        assert data["summary"] == "Summary"
    
    def test_from_dict(self):
        """Test context deserialization."""
        data = {
            "variables": {"key": "value"},
            "summary": "Test summary",
            "key_points": ["Point 1"],
        }
        
        ctx = ThreadContext.from_dict(data)
        
        assert ctx.variables == {"key": "value"}
        assert ctx.summary == "Test summary"


class TestConversationThread:
    """Tests for ConversationThread."""
    
    def test_default_thread(self):
        """Test default thread creation."""
        thread = ConversationThread()
        
        assert thread.id is not None
        assert thread.state == ThreadState.ACTIVE
        assert len(thread.messages) == 0
        assert isinstance(thread.created_at, datetime)
    
    def test_create_thread(self):
        """Test creating thread with factory method."""
        thread = ConversationThread.create(
            title="Test Thread",
            participants=["user", "agent"],
            metadata={"key": "value"},
        )
        
        assert thread.title == "Test Thread"
        assert thread.participants == ["user", "agent"]
        assert thread.metadata == {"key": "value"}
    
    def test_add_message(self):
        """Test adding a message to thread."""
        thread = ConversationThread()
        
        msg = thread.add_message(
            content="Hello!",
            role=MessageRole.USER,
        )
        
        assert len(thread.messages) == 1
        assert msg.thread_id == thread.id
        assert msg.content == "Hello!"
        assert msg.role == MessageRole.USER
    
    def test_get_messages(self):
        """Test getting messages with filters."""
        thread = ConversationThread()
        thread.add_message("User 1", MessageRole.USER)
        thread.add_message("Agent 1", MessageRole.AGENT)
        thread.add_message("User 2", MessageRole.USER)
        
        # Get all
        all_msgs = thread.get_messages()
        assert len(all_msgs) == 3
        
        # Get by role
        user_msgs = thread.get_messages(role=MessageRole.USER)
        assert len(user_msgs) == 2
        
        # Get with limit
        last_2 = thread.get_messages(limit=2)
        assert len(last_2) == 2
    
    def test_get_message_by_id(self):
        """Test getting message by ID."""
        thread = ConversationThread()
        msg = thread.add_message("Hello", MessageRole.USER)
        
        found = thread.get_message(msg.id)
        assert found == msg
        
        not_found = thread.get_message("nonexistent")
        assert not_found is None
    
    def test_get_last_message(self):
        """Test getting last message."""
        thread = ConversationThread()
        thread.add_message("First", MessageRole.USER)
        thread.add_message("Second", MessageRole.AGENT)
        thread.add_message("Third", MessageRole.USER)
        
        last = thread.get_last_message()
        assert last.content == "Third"
        
        last_agent = thread.get_last_message(role=MessageRole.AGENT)
        assert last_agent.content == "Second"
    
    def test_update_message_status(self):
        """Test updating message status."""
        thread = ConversationThread()
        msg = thread.add_message("Hello", MessageRole.USER)
        
        result = thread.update_message_status(msg.id, MessageStatus.DELIVERED)
        
        assert result is True
        assert msg.status == MessageStatus.DELIVERED
    
    def test_pause_and_resume(self):
        """Test pausing and resuming thread."""
        thread = ConversationThread()
        
        assert thread.state == ThreadState.ACTIVE
        assert thread.is_active()
        
        thread.pause()
        assert thread.state == ThreadState.PAUSED
        assert not thread.is_active()
        
        thread.resume()
        assert thread.state == ThreadState.ACTIVE
    
    def test_complete_and_cancel(self):
        """Test completing and cancelling thread."""
        thread = ConversationThread()
        
        thread.complete()
        assert thread.state == ThreadState.COMPLETED
        
        thread2 = ConversationThread()
        thread2.cancel()
        assert thread2.state == ThreadState.CANCELLED
    
    def test_get_context_for_agent(self):
        """Test getting context for agent."""
        thread = ConversationThread(title="Test")
        thread.context.summary = "Test summary"
        thread.update_agent_state("agent1", {"status": "ready"})
        
        ctx = thread.get_context_for_agent("agent1")
        
        assert ctx["thread_id"] == thread.id
        assert ctx["title"] == "Test"
        assert ctx["summary"] == "Test summary"
        assert ctx["agent_state"] == {"status": "ready"}
    
    def test_to_dict(self):
        """Test thread serialization."""
        thread = ConversationThread(id="thread-123", title="Test")
        thread.add_message("Hello", MessageRole.USER)
        
        data = thread.to_dict()
        
        assert data["id"] == "thread-123"
        assert data["title"] == "Test"
        assert data["state"] == "active"
        assert len(data["messages"]) == 1
    
    def test_from_dict(self):
        """Test thread deserialization."""
        data = {
            "id": "thread-456",
            "title": "Test Thread",
            "state": "paused",
            "messages": [
                {"role": "user", "content": "Test"},
            ],
            "created_at": "2024-01-01T12:00:00",
        }
        
        thread = ConversationThread.from_dict(data)
        
        assert thread.id == "thread-456"
        assert thread.title == "Test Thread"
        assert thread.state == ThreadState.PAUSED
        assert len(thread.messages) == 1


class TestThreadManager:
    """Tests for ThreadManager."""
    
    def test_manager_initialization(self):
        """Test manager initialization."""
        manager = ThreadManager()
        
        assert len(manager._threads) == 0
    
    def test_create_thread(self):
        """Test creating a new thread."""
        manager = ThreadManager()
        
        thread = manager.create_thread(title="Test")
        
        assert thread.id in manager._threads
        assert thread.title == "Test"
    
    def test_get_thread(self):
        """Test getting a thread by ID."""
        manager = ThreadManager()
        thread = manager.create_thread()
        
        result = manager.get_thread(thread.id)
        
        assert result == thread
    
    def test_get_nonexistent_thread(self):
        """Test getting nonexistent thread returns None."""
        manager = ThreadManager()
        
        result = manager.get_thread("nonexistent")
        
        assert result is None
    
    def test_list_threads(self):
        """Test listing threads with filters."""
        manager = ThreadManager()
        t1 = manager.create_thread()
        t2 = manager.create_thread()
        t2.pause()
        
        all_threads = manager.list_threads()
        assert len(all_threads) == 2
        
        active = manager.list_threads(state=ThreadState.ACTIVE)
        assert len(active) == 1
        
        paused = manager.list_threads(state=ThreadState.PAUSED)
        assert len(paused) == 1
    
    def test_delete_thread(self):
        """Test deleting a thread."""
        manager = ThreadManager()
        thread = manager.create_thread()
        
        result = manager.delete_thread(thread.id)
        
        assert result is True
        assert thread.id not in manager._threads
    
    def test_get_stats(self):
        """Test getting thread statistics."""
        manager = ThreadManager()
        manager.create_thread()
        t2 = manager.create_thread()
        t2.pause()
        t3 = manager.create_thread()
        t3.complete()
        
        stats = manager.get_stats()
        
        assert stats["total"] == 3
        assert stats["active"] == 1
        assert stats["paused"] == 1
        assert stats["completed"] == 1


# =============================================================================
# Error Handling Tests
# =============================================================================

class TestA2AErrorCode:
    """Tests for A2AErrorCode enum."""
    
    def test_client_error_codes(self):
        """Test client error codes."""
        assert A2AErrorCode.INVALID_REQUEST.value == "A2A_1001"
        assert A2AErrorCode.MISSING_PARAMETER.value == "A2A_1002"
        assert A2AErrorCode.RATE_LIMITED.value == "A2A_1006"
        assert A2AErrorCode.UNAUTHORIZED.value == "A2A_1007"
    
    def test_agent_error_codes(self):
        """Test agent error codes."""
        assert A2AErrorCode.AGENT_NOT_FOUND.value == "A2A_2001"
        assert A2AErrorCode.AGENT_UNAVAILABLE.value == "A2A_2002"
        assert A2AErrorCode.SKILL_NOT_FOUND.value == "A2A_2003"
        assert A2AErrorCode.AGENT_TIMEOUT.value == "A2A_2007"
    
    def test_communication_error_codes(self):
        """Test communication error codes."""
        assert A2AErrorCode.CONNECTION_FAILED.value == "A2A_3001"
        assert A2AErrorCode.CONNECTION_TIMEOUT.value == "A2A_3002"
        assert A2AErrorCode.NETWORK_ERROR.value == "A2A_3006"
    
    def test_protocol_error_codes(self):
        """Test protocol error codes."""
        assert A2AErrorCode.PROTOCOL_VERSION_MISMATCH.value == "A2A_4001"
        assert A2AErrorCode.INVALID_AGENT_CARD.value == "A2A_4002"
        assert A2AErrorCode.THREAD_NOT_FOUND.value == "A2A_4004"
    
    def test_internal_error_codes(self):
        """Test internal error codes."""
        assert A2AErrorCode.INTERNAL_ERROR.value == "A2A_5001"
        assert A2AErrorCode.CONFIGURATION_ERROR.value == "A2A_5002"
        assert A2AErrorCode.NOT_IMPLEMENTED.value == "A2A_5005"


class TestA2AErrorDetails:
    """Tests for A2AErrorDetails."""
    
    def test_default_details(self):
        """Test default error details."""
        details = A2AErrorDetails()
        
        assert details.field is None
        assert details.expected is None
        assert details.actual is None
        assert details.suggestion is None
        assert details.docs_url is None
    
    def test_custom_details(self):
        """Test custom error details."""
        details = A2AErrorDetails(
            field="agent_id",
            expected="string",
            actual="integer",
            suggestion="Provide a valid agent ID string",
            docs_url="https://example.com/docs",
        )
        
        assert details.field == "agent_id"
        assert details.expected == "string"
        assert details.actual == "integer"
        assert details.suggestion == "Provide a valid agent ID string"
        assert details.docs_url == "https://example.com/docs"
    
    def test_to_dict(self):
        """Test details serialization."""
        details = A2AErrorDetails(
            field="test",
            suggestion="Fix it",
        )
        
        data = details.to_dict()
        
        assert data["field"] == "test"
        assert data["suggestion"] == "Fix it"


class TestA2AError:
    """Tests for A2AError."""
    
    def test_basic_error(self):
        """Test basic error creation."""
        error = A2AError(
            message="Invalid request format",
            code=A2AErrorCode.INVALID_REQUEST,
        )
        
        assert error.code == A2AErrorCode.INVALID_REQUEST
        assert error.message == "Invalid request format"
        assert str(error) == "Invalid request format"
    
    def test_error_with_details(self):
        """Test error with details."""
        details = A2AErrorDetails(
            field="name",
            expected="string",
        )
        error = A2AError(
            message="Invalid parameter",
            code=A2AErrorCode.INVALID_PARAMETER,
            details=details,
        )
        
        assert error.details == details
    
    def test_error_http_status(self):
        """Test error HTTP status mapping."""
        error = A2AError(
            message="Authentication required",
            code=A2AErrorCode.UNAUTHORIZED,
        )
        
        assert error.http_status == 401
    
    def test_error_to_dict(self):
        """Test error serialization."""
        error = A2AError(
            message="Agent not found",
            code=A2AErrorCode.AGENT_NOT_FOUND,
        )
        
        data = error.to_dict()
        
        assert data["error"]["code"] == "A2A_2001"
        assert data["error"]["message"] == "Agent not found"
        assert "timestamp" in data["error"]
    
    def test_error_to_response(self):
        """Test error to HTTP response."""
        error = A2AError(
            message="Not found",
            code=A2AErrorCode.AGENT_NOT_FOUND,
        )
        
        response = error.to_response()
        
        assert response["status"] == 404
        assert "body" in response
        assert response["headers"]["Content-Type"] == "application/json"


class TestSpecificErrorClasses:
    """Tests for specific error classes."""
    
    def test_discovery_error(self):
        """Test A2ADiscoveryError."""
        error = A2ADiscoveryError("Agent not found", url="http://example.com")
        
        assert error.code == A2AErrorCode.AGENT_NOT_FOUND
        assert error.url == "http://example.com"
    
    def test_connection_error(self):
        """Test A2AConnectionError."""
        error = A2AConnectionError(
            "Connection refused",
            host="localhost",
            port=8080,
        )
        
        assert error.code == A2AErrorCode.CONNECTION_FAILED
    
    def test_timeout_error(self):
        """Test A2ATimeoutError."""
        error = A2ATimeoutError("Operation timed out", timeout_seconds=30.0)
        
        assert error.code == A2AErrorCode.RESPONSE_TIMEOUT
    
    def test_authentication_error(self):
        """Test A2AAuthenticationError."""
        error = A2AAuthenticationError("Invalid API key")
        
        assert error.code == A2AErrorCode.UNAUTHORIZED
    
    def test_protocol_error(self):
        """Test A2AProtocolError."""
        error = A2AProtocolError(
            "Version mismatch",
            expected_version="2.0",
            actual_version="1.0",
        )
        
        assert error.code == A2AErrorCode.PROTOCOL_VERSION_MISMATCH
    
    def test_agent_error(self):
        """Test A2AAgentError."""
        error = A2AAgentError("Agent crashed", agent_name="agent-123")
        
        assert error.code == A2AErrorCode.AGENT_ERROR
        assert error.agent_name == "agent-123"
    
    def test_thread_error(self):
        """Test A2AThreadError."""
        error = A2AThreadError("Thread not found", thread_id="thread-456")
        
        assert error.code == A2AErrorCode.THREAD_NOT_FOUND
    
    def test_thread_error_expired(self):
        """Test A2AThreadError with expired flag."""
        error = A2AThreadError("Thread expired", thread_id="t1", expired=True)
        
        assert error.code == A2AErrorCode.THREAD_EXPIRED
    
    def test_validation_error(self):
        """Test A2AValidationError."""
        error = A2AValidationError(
            "Invalid value",
            field="name",
            expected="string",
            actual=123,
        )
        
        assert error.code == A2AErrorCode.INVALID_PARAMETER
        assert error.details.field == "name"
    
    def test_rate_limit_error(self):
        """Test A2ARateLimitError."""
        error = A2ARateLimitError("Too many requests", retry_after=60)
        
        assert error.code == A2AErrorCode.RATE_LIMITED
        assert error.retry_after == 60


class TestA2AErrorHandler:
    """Tests for A2AErrorHandler."""
    
    def test_handler_initialization(self):
        """Test handler initialization."""
        handler = A2AErrorHandler()
        
        assert handler.default_agent_name is None
        assert handler.include_traceback is False
    
    def test_handler_with_agent_name(self):
        """Test handler with default agent name."""
        handler = A2AErrorHandler(default_agent_name="my-agent")
        
        assert handler.default_agent_name == "my-agent"
    
    def test_register_handler(self):
        """Test registering custom error handler."""
        handler = A2AErrorHandler()
        
        def custom_handler(exc):
            return A2AError("Custom error", code=A2AErrorCode.INTERNAL_ERROR)
        
        handler.register_handler(ValueError, custom_handler)
        
        assert ValueError in handler._error_handlers
    
    def test_handle_a2a_error(self):
        """Test handling A2AError passthrough."""
        handler = A2AErrorHandler()
        
        original = A2AError("Test error", code=A2AErrorCode.INVALID_REQUEST)
        result = handler.handle(original)
        
        assert result == original
    
    def test_handle_timeout_error(self):
        """Test handling TimeoutError."""
        handler = A2AErrorHandler()
        
        original = TimeoutError("Timed out")
        result = handler.handle(original)
        
        assert isinstance(result, A2ATimeoutError)
    
    def test_handle_connection_error(self):
        """Test handling ConnectionError."""
        handler = A2AErrorHandler()
        
        original = ConnectionError("Connection refused")
        result = handler.handle(original)
        
        assert isinstance(result, A2AConnectionError)
    
    def test_handle_value_error(self):
        """Test handling ValueError."""
        handler = A2AErrorHandler()
        
        original = ValueError("Invalid value")
        result = handler.handle(original)
        
        assert isinstance(result, A2AValidationError)
    
    def test_handle_generic_error(self):
        """Test handling generic exception."""
        handler = A2AErrorHandler()
        
        original = RuntimeError("Something went wrong")
        result = handler.handle(original)
        
        assert isinstance(result, A2AError)
        assert result.code == A2AErrorCode.INTERNAL_ERROR
    
    def test_create_error_response(self):
        """Test creating error response."""
        handler = A2AErrorHandler()
        
        original = ValueError("Bad input")
        response = handler.create_error_response(original, request_id="req-123")
        
        assert response["status"] == 400  # Validation error
        assert "body" in response


# =============================================================================
# Integration Tests
# =============================================================================

class TestA2AIntegration:
    """Integration tests for A2A Protocol v2."""
    
    @pytest.mark.asyncio
    async def test_server_client_flow(self):
        """Test server and client interaction flow."""
        # Create agent card
        card = AgentCard(
            name="test-agent",
            description="A test agent for integration testing",
            url="http://localhost:8080",
            skills=[
                AgentSkill(id="echo", name="Echo", description="Echoes input"),
            ],
        )
        
        # Create server config
        config = A2AServerConfig(
            port=8080,
            agent_card=card,
        )
        server = A2AServer(config)
        
        # Verify server has card
        assert server._agent_card == card
        assert server._agent_card.name == "test-agent"
    
    def test_thread_conversation_flow(self):
        """Test conversation thread flow."""
        manager = ThreadManager()
        
        # Create thread
        thread = manager.create_thread(title="Help Request")
        
        # Simulate conversation
        thread.add_message("Hello, can you help me?", MessageRole.USER)
        thread.add_message("Of course! How can I assist you?", MessageRole.AGENT)
        thread.add_message("I need to translate some text.", MessageRole.USER)
        thread.add_message("I'd be happy to help with translation.", MessageRole.AGENT)
        
        # Verify conversation
        assert len(thread.messages) == 4
        assert thread.get_last_message().role == MessageRole.AGENT
        
        # Get context
        context = thread.get_context_for_agent("assistant")
        assert context["thread_id"] == thread.id
    
    def test_error_handling_flow(self):
        """Test error handling flow."""
        handler = A2AErrorHandler(default_agent_name="my-agent")
        
        # Handle various exceptions
        timeout_error = handler.handle(TimeoutError("Timed out"))
        assert isinstance(timeout_error, A2ATimeoutError)
        
        conn_error = handler.handle(ConnectionError("Refused"))
        assert isinstance(conn_error, A2AConnectionError)
        
        # Get response
        response = handler.create_error_response(ValueError("Bad"))
        assert response["status"] == 400
    
    def test_registry_with_skills(self):
        """Test registry skill discovery."""
        registry = A2ARegistry()
        
        # Register agents with different skills
        translator = AgentCard(
            name="translator",
            description="Translation agent",
            url="http://localhost:8080",
            skills=[AgentSkill(id="translate", name="Translate", description="Translate text")],
        )
        
        summarizer = AgentCard(
            name="summarizer",
            description="Summarization agent",
            url="http://localhost:8081",
            skills=[AgentSkill(id="summarize", name="Summarize", description="Summarize text")],
        )
        
        multi_skill = AgentCard(
            name="multi-skill",
            description="Multi-skill agent",
            url="http://localhost:8082",
            skills=[
                AgentSkill(id="translate", name="Translate", description="Translate text"),
                AgentSkill(id="summarize", name="Summarize", description="Summarize text"),
                AgentSkill(id="analyze", name="Analyze", description="Analyze text"),
            ],
        )
        
        registry.register(translator)
        registry.register(summarizer)
        registry.register(multi_skill)
        
        # Find by skill
        translators = registry.find_by_skill("translate")
        assert len(translators) == 2
        
        analyzers = registry.find_by_skill("analyze")
        assert len(analyzers) == 1
        
        coders = registry.find_by_skill("code")
        assert len(coders) == 0
    
    def test_thread_with_artifacts(self):
        """Test thread with message artifacts."""
        thread = ConversationThread()
        
        # Add message with artifact
        msg = thread.add_message(
            content="Please analyze this document",
            role=MessageRole.USER,
            artifacts=[{
                "type": "file",
                "name": "document.pdf",
                "mime_type": "application/pdf",
                "size": 1024,
            }],
        )
        
        # Verify artifact
        assert len(thread.messages[0].artifacts) == 1
        assert thread.messages[0].artifacts[0]["name"] == "document.pdf"
    
    def test_error_response_generation(self):
        """Test generating HTTP response from error."""
        error = A2ARateLimitError(
            "Too many requests",
            retry_after=60,
        )
        
        response = error.to_response()
        
        assert response["status"] == 429


# =============================================================================
# Edge Case Tests
# =============================================================================

class TestEdgeCases:
    """Edge case tests."""
    
    def test_empty_thread(self):
        """Test operations on empty thread."""
        thread = ConversationThread()
        
        assert len(thread.messages) == 0
        assert thread.get_last_message() is None
        assert thread.get_messages(limit=5) == []
    
    def test_thread_with_many_messages(self):
        """Test thread with many messages."""
        thread = ConversationThread()
        
        for i in range(100):
            role = MessageRole.USER if i % 2 == 0 else MessageRole.AGENT
            thread.add_message(f"Message {i}", role)
        
        assert len(thread.messages) == 100
        
        last_10 = thread.get_messages(limit=10)
        assert len(last_10) == 10
    
    def test_registry_duplicate_registration(self):
        """Test registering duplicate agent."""
        registry = A2ARegistry()
        card1 = AgentCard(
            name="agent",
            description="First version",
            url="http://localhost:8080",
        )
        card2 = AgentCard(
            name="agent",
            description="Second version",
            url="http://localhost:8080",
        )
        
        registry.register(card1)
        registry.register(card2)
        
        # Should replace
        assert registry.get_by_name("agent").description == "Second version"
    
    def test_thread_serialization_roundtrip(self):
        """Test thread serialization and deserialization."""
        thread = ConversationThread.create(title="Test Thread")
        thread.add_message("Hello", MessageRole.USER)
        thread.add_message("Hi there!", MessageRole.AGENT)
        thread.add_message("How are you?", MessageRole.USER)
        
        # Serialize
        data = thread.to_dict()
        
        # Deserialize
        restored = ConversationThread.from_dict(data)
        
        assert restored.id == thread.id
        assert len(restored.messages) == len(thread.messages)
        assert restored.messages[0].content == "Hello"
        assert restored.messages[1].content == "Hi there!"
    
    def test_context_variable_types(self):
        """Test context with different variable types."""
        ctx = ThreadContext()
        
        ctx.set_variable("string", "value")
        ctx.set_variable("number", 42)
        ctx.set_variable("list", [1, 2, 3])
        ctx.set_variable("dict", {"key": "value"})
        ctx.set_variable("none", None)
        
        assert ctx.get_variable("string") == "value"
        assert ctx.get_variable("number") == 42
        assert ctx.get_variable("list") == [1, 2, 3]
        assert ctx.get_variable("dict") == {"key": "value"}
        assert ctx.get_variable("none") is None
    
    def test_message_parent_chain(self):
        """Test message parent-child relationships."""
        thread = ConversationThread()
        
        msg1 = thread.add_message("First message", MessageRole.USER)
        msg2 = thread.add_message(
            content="Reply to first",
            role=MessageRole.AGENT,
            parent_message_id=msg1.id,
        )
        
        assert msg2.parent_message_id == msg1.id
