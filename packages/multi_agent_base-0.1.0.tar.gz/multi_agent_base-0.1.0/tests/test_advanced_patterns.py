"""
Tests for Advanced Orchestration Patterns.

This module tests the HierarchicalPattern, EnsemblePattern, and SelfHealingPattern
implementations.
"""

import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from dataclasses import dataclass
from typing import Any

from multi_agent_base.core.patterns import (
    HierarchicalPattern,
    HierarchicalLevel,
    EnsemblePattern,
    VotingStrategy,
    VoteResult,
    SelfHealingPattern,
    PatternResult,
)
from multi_agent_base.core.config import SystemConfig, ProviderConfig, ProviderType, PatternType


# =============================================================================
# Fixtures
# =============================================================================

@pytest.fixture
def mock_config():
    """Create a mock system configuration."""
    return SystemConfig(
        provider=ProviderConfig(
            provider=ProviderType.OLLAMA,
            model="llama3.2",
            base_url="http://localhost:11434",
        ),
        pattern=PatternType.HIERARCHICAL,
    )


@pytest.fixture
def mock_response():
    """Create a mock agent response."""
    @dataclass
    class MockResponse:
        content: str
        cost: float = 0.001
        usage: dict = None
        
        def __post_init__(self):
            if self.usage is None:
                self.usage = {"prompt_tokens": 10, "completion_tokens": 20}
    
    return MockResponse


@pytest.fixture
def mock_agent_factory(mock_response):
    """Create a factory for mock agents."""
    def create_mock_agent(responses: list[str] | None = None):
        responses = responses or ["Default response"]
        call_count = [0]
        
        async def mock_run(message: str, **kwargs):
            idx = min(call_count[0], len(responses) - 1)
            call_count[0] += 1
            return mock_response(content=responses[idx])
        
        agent = MagicMock()
        agent.run = AsyncMock(side_effect=mock_run)
        agent.register_tool = MagicMock()
        return agent
    
    return create_mock_agent


# =============================================================================
# HierarchicalLevel Tests
# =============================================================================

class TestHierarchicalLevel:
    """Tests for HierarchicalLevel dataclass."""
    
    def test_level_creation(self):
        """Test creating a hierarchical level."""
        level = HierarchicalLevel(
            name="executive",
            agents=["agent1", "agent2"],
            supervisor="supervisor1",
            parent_level=None,
        )
        
        assert level.name == "executive"
        assert len(level.agents) == 2
        assert level.supervisor == "supervisor1"
        assert level.parent_level is None
    
    def test_level_with_parent(self):
        """Test creating a level with a parent."""
        level = HierarchicalLevel(
            name="workers",
            agents=["worker1"],
            parent_level="management",
        )
        
        assert level.parent_level == "management"
        assert level.supervisor is None
    
    def test_level_defaults(self):
        """Test level with default values."""
        level = HierarchicalLevel(name="test")
        
        assert level.agents == []
        assert level.supervisor is None
        assert level.parent_level is None


# =============================================================================
# HierarchicalPattern Tests
# =============================================================================

class TestHierarchicalPattern:
    """Tests for HierarchicalPattern."""
    
    def test_pattern_initialization(self, mock_config):
        """Test pattern initialization."""
        pattern = HierarchicalPattern(mock_config)
        
        assert pattern._levels == {}
        assert pattern._level_order == []
        assert pattern._root_level is None
    
    def test_create_root_level(self, mock_config):
        """Test creating a root level."""
        pattern = HierarchicalPattern(mock_config)
        level = pattern.create_level("executive", supervisor="ceo")
        
        assert level.name == "executive"
        assert level.supervisor == "ceo"
        assert pattern._root_level == "executive"
        assert "executive" in pattern._levels
    
    def test_create_child_level(self, mock_config):
        """Test creating a child level."""
        pattern = HierarchicalPattern(mock_config)
        pattern.create_level("executive")
        level = pattern.create_level("management", parent="executive")
        
        assert level.parent_level == "executive"
        assert pattern._root_level == "executive"  # Root unchanged
    
    def test_create_level_invalid_parent(self, mock_config):
        """Test creating a level with invalid parent raises error."""
        pattern = HierarchicalPattern(mock_config)
        
        with pytest.raises(ValueError, match="does not exist"):
            pattern.create_level("management", parent="nonexistent")
    
    @patch("multi_agent_base.core.patterns.HierarchicalPattern._create_model_client")
    def test_add_agent_to_level(self, mock_model_client, mock_config):
        """Test adding an agent to a level."""
        mock_model_client.return_value = MagicMock()
        pattern = HierarchicalPattern(mock_config)
        pattern.create_level("workers")
        
        agent = pattern.add_agent_to_level(
            "workers",
            "worker1",
            "You are a worker.",
        )
        
        assert "worker1" in pattern._levels["workers"].agents
        assert "worker1" in pattern._agents
    
    @patch("multi_agent_base.core.patterns.HierarchicalPattern._create_model_client")
    def test_add_supervisor_to_level(self, mock_model_client, mock_config):
        """Test adding a supervisor to a level."""
        mock_model_client.return_value = MagicMock()
        pattern = HierarchicalPattern(mock_config)
        pattern.create_level("management")
        
        pattern.add_agent_to_level(
            "management",
            "manager",
            "You manage workers.",
            is_supervisor=True,
        )
        
        assert pattern._levels["management"].supervisor == "manager"
    
    def test_add_agent_invalid_level(self, mock_config):
        """Test adding agent to invalid level raises error."""
        pattern = HierarchicalPattern(mock_config)
        
        with pytest.raises(ValueError, match="does not exist"):
            pattern.add_agent_to_level("nonexistent", "agent", "prompt")
    
    def test_get_level(self, mock_config):
        """Test getting a level by name."""
        pattern = HierarchicalPattern(mock_config)
        pattern.create_level("executive")
        
        level = pattern.get_level("executive")
        assert level is not None
        assert level.name == "executive"
        
        assert pattern.get_level("nonexistent") is None
    
    def test_get_child_levels(self, mock_config):
        """Test getting child levels."""
        pattern = HierarchicalPattern(mock_config)
        pattern.create_level("executive")
        pattern.create_level("management", parent="executive")
        pattern.create_level("operations", parent="executive")
        pattern.create_level("workers", parent="management")
        
        children = pattern.get_child_levels("executive")
        assert len(children) == 2
        assert "management" in children
        assert "operations" in children
        
        management_children = pattern.get_child_levels("management")
        assert len(management_children) == 1
        assert "workers" in management_children
    
    @pytest.mark.asyncio
    async def test_run_no_root_level(self, mock_config):
        """Test running pattern without root level raises error."""
        pattern = HierarchicalPattern(mock_config)
        
        with pytest.raises(RuntimeError, match="No root level"):
            await pattern.run("Test message")
    
    @pytest.mark.asyncio
    async def test_run_no_levels(self, mock_config):
        """Test running pattern without levels raises error."""
        pattern = HierarchicalPattern(mock_config)
        pattern._root_level = "executive"  # Set manually but no levels
        
        with pytest.raises(RuntimeError, match="No levels defined"):
            await pattern.run("Test message")
    
    @pytest.mark.asyncio
    async def test_run_single_level(self, mock_config, mock_agent_factory):
        """Test running pattern with a single level."""
        pattern = HierarchicalPattern(mock_config)
        pattern.create_level("workers", agents=["worker1"])
        
        # Add mock agent
        mock_agent = mock_agent_factory(["Task completed successfully"])
        pattern._agents["worker1"] = mock_agent
        
        result = await pattern.run("Complete the task")
        
        assert result.content == "Task completed successfully"
        assert len(result.agent_responses) == 1
    
    @pytest.mark.asyncio
    async def test_run_hierarchical_delegation(self, mock_config, mock_agent_factory):
        """Test running pattern with hierarchical delegation."""
        pattern = HierarchicalPattern(mock_config)
        pattern.create_level("executive", supervisor="ceo")
        pattern.create_level("workers", agents=["worker1"], parent="executive")
        
        # Add mock agents
        ceo_agent = mock_agent_factory([
            "DELEGATE: Please complete this task.",
            "Summary: Task completed by workers."
        ])
        worker_agent = mock_agent_factory(["Worker completed the task."])
        
        pattern._agents["ceo"] = ceo_agent
        pattern._agents["worker1"] = worker_agent
        pattern._levels["executive"].supervisor = "ceo"
        
        result = await pattern.run("Complete project")
        
        assert result is not None
        assert "levels" in result.metadata


# =============================================================================
# VotingStrategy Tests
# =============================================================================

class TestVotingStrategy:
    """Tests for VotingStrategy enum."""
    
    def test_voting_strategies(self):
        """Test all voting strategies exist."""
        assert VotingStrategy.MAJORITY.value == "majority"
        assert VotingStrategy.UNANIMOUS.value == "unanimous"
        assert VotingStrategy.WEIGHTED.value == "weighted"
        assert VotingStrategy.RANKED_CHOICE.value == "ranked_choice"


# =============================================================================
# VoteResult Tests
# =============================================================================

class TestVoteResult:
    """Tests for VoteResult dataclass."""
    
    def test_vote_result_creation(self):
        """Test creating a vote result."""
        result = VoteResult(
            winner="Best answer",
            votes={"option1": 3, "option2": 1},
            confidence=0.75,
            all_responses=["resp1", "resp2", "resp3", "resp4"],
        )
        
        assert result.winner == "Best answer"
        assert result.votes["option1"] == 3
        assert result.confidence == 0.75
        assert len(result.all_responses) == 4
    
    def test_vote_result_defaults(self):
        """Test vote result with default values."""
        result = VoteResult(winner="Answer")
        
        assert result.votes == {}
        assert result.confidence == 0.0
        assert result.all_responses == []


# =============================================================================
# EnsemblePattern Tests
# =============================================================================

class TestEnsemblePattern:
    """Tests for EnsemblePattern."""
    
    def test_pattern_initialization(self, mock_config):
        """Test pattern initialization."""
        pattern = EnsemblePattern(mock_config)
        
        assert pattern.voting_strategy == VotingStrategy.MAJORITY
        assert pattern._voters == []
        assert pattern._weights == {}
        assert pattern._aggregator is None
    
    def test_pattern_with_custom_strategy(self, mock_config):
        """Test pattern with custom voting strategy."""
        pattern = EnsemblePattern(
            mock_config,
            voting_strategy=VotingStrategy.WEIGHTED,
        )
        
        assert pattern.voting_strategy == VotingStrategy.WEIGHTED
    
    @patch("multi_agent_base.core.patterns.EnsemblePattern._create_model_client")
    def test_add_voter(self, mock_model_client, mock_config):
        """Test adding a voter."""
        mock_model_client.return_value = MagicMock()
        pattern = EnsemblePattern(mock_config)
        
        pattern.add_voter("expert1", "You are an expert.", weight=2.0)
        
        assert "expert1" in pattern._voters
        assert pattern._weights["expert1"] == 2.0
        assert "expert1" in pattern._agents
    
    @patch("multi_agent_base.core.patterns.EnsemblePattern._create_model_client")
    def test_add_multiple_voters(self, mock_model_client, mock_config):
        """Test adding multiple voters."""
        mock_model_client.return_value = MagicMock()
        pattern = EnsemblePattern(mock_config)
        
        pattern.add_voter("expert1", "Expert 1", weight=1.0)
        pattern.add_voter("expert2", "Expert 2", weight=1.5)
        pattern.add_voter("expert3", "Expert 3", weight=0.5)
        
        assert len(pattern._voters) == 3
        assert pattern._weights["expert2"] == 1.5
    
    @patch("multi_agent_base.core.patterns.EnsemblePattern._create_model_client")
    def test_set_aggregator(self, mock_model_client, mock_config):
        """Test setting an aggregator."""
        mock_model_client.return_value = MagicMock()
        pattern = EnsemblePattern(mock_config)
        
        pattern.set_aggregator("aggregator", "You synthesize responses.")
        
        assert pattern._aggregator is not None
    
    def test_calculate_similarity(self, mock_config):
        """Test similarity calculation."""
        pattern = EnsemblePattern(mock_config)
        
        # Same text
        sim = pattern._calculate_similarity("hello world", "hello world")
        assert sim == 1.0
        
        # Different text
        sim = pattern._calculate_similarity("hello world", "goodbye universe")
        assert sim == 0.0
        
        # Partial overlap
        sim = pattern._calculate_similarity("hello world", "hello universe")
        assert 0 < sim < 1
    
    def test_cluster_responses_identical(self, mock_config):
        """Test clustering identical responses."""
        pattern = EnsemblePattern(mock_config)
        
        responses = [
            ("agent1", "The answer is 42."),
            ("agent2", "The answer is 42."),
            ("agent3", "The answer is 42."),
        ]
        
        clusters = pattern._cluster_responses(responses)
        
        assert len(clusters) == 1
        assert len(clusters[0]) == 3
    
    def test_cluster_responses_different(self, mock_config):
        """Test clustering different responses."""
        pattern = EnsemblePattern(mock_config)
        
        responses = [
            ("agent1", "Red is the best color."),
            ("agent2", "Blue is the best color."),
            ("agent3", "Green is the best color."),
        ]
        
        clusters = pattern._cluster_responses(responses, threshold=0.8)
        
        # Each response should be in its own cluster
        assert len(clusters) >= 2
    
    def test_apply_voting_majority(self, mock_config):
        """Test majority voting."""
        pattern = EnsemblePattern(mock_config, voting_strategy=VotingStrategy.MAJORITY)
        pattern._weights = {"agent1": 1.0, "agent2": 1.0, "agent3": 1.0}
        
        clusters = [
            [("agent1", "Answer A"), ("agent2", "Answer A")],
            [("agent3", "Answer B")],
        ]
        
        result = pattern._apply_voting(clusters)
        
        assert result.winner == "Answer A"
        assert result.confidence > 0.5
    
    def test_apply_voting_unanimous_success(self, mock_config):
        """Test unanimous voting with agreement."""
        pattern = EnsemblePattern(mock_config, voting_strategy=VotingStrategy.UNANIMOUS)
        pattern._weights = {"agent1": 1.0, "agent2": 1.0}
        
        clusters = [
            [("agent1", "Same answer"), ("agent2", "Same answer")],
        ]
        
        result = pattern._apply_voting(clusters)
        
        assert result.winner == "Same answer"
        assert result.confidence == 1.0
    
    def test_apply_voting_unanimous_failure(self, mock_config):
        """Test unanimous voting without agreement."""
        pattern = EnsemblePattern(mock_config, voting_strategy=VotingStrategy.UNANIMOUS)
        pattern._weights = {"agent1": 1.0, "agent2": 1.0}
        
        clusters = [
            [("agent1", "Answer A")],
            [("agent2", "Answer B")],
        ]
        
        result = pattern._apply_voting(clusters)
        
        assert result.winner == ""
        assert result.confidence == 0.0
    
    def test_apply_voting_weighted(self, mock_config):
        """Test weighted voting."""
        pattern = EnsemblePattern(mock_config, voting_strategy=VotingStrategy.WEIGHTED)
        pattern._weights = {"agent1": 3.0, "agent2": 1.0, "agent3": 1.0}
        
        # Agent1 has high weight and is alone in its cluster
        clusters = [
            [("agent1", "Expert opinion")],
            [("agent2", "Other"), ("agent3", "Other")],
        ]
        
        result = pattern._apply_voting(clusters)
        
        # Agent1's cluster should win due to higher weight
        assert result.winner == "Expert opinion"
    
    @pytest.mark.asyncio
    async def test_run_no_voters(self, mock_config):
        """Test running pattern without voters raises error."""
        pattern = EnsemblePattern(mock_config)
        
        with pytest.raises(RuntimeError, match="No voters added"):
            await pattern.run("Test message")
    
    @pytest.mark.asyncio
    async def test_run_single_voter(self, mock_config, mock_agent_factory):
        """Test running pattern with single voter."""
        pattern = EnsemblePattern(mock_config)
        
        mock_agent = mock_agent_factory(["The answer is 42."])
        pattern._voters = ["expert1"]
        pattern._weights = {"expert1": 1.0}
        pattern._agents["expert1"] = mock_agent
        
        result = await pattern.run("What is the answer?")
        
        assert result.content == "The answer is 42."
        assert result.metadata["num_voters"] == 1
    
    @pytest.mark.asyncio
    async def test_run_multiple_voters_consensus(self, mock_config, mock_agent_factory):
        """Test running pattern with consensus."""
        pattern = EnsemblePattern(mock_config)
        
        pattern._voters = ["expert1", "expert2", "expert3"]
        pattern._weights = {"expert1": 1.0, "expert2": 1.0, "expert3": 1.0}
        pattern._agents["expert1"] = mock_agent_factory(["Answer is A"])
        pattern._agents["expert2"] = mock_agent_factory(["Answer is A"])
        pattern._agents["expert3"] = mock_agent_factory(["Answer is A"])
        
        result = await pattern.run("Question?")
        
        assert "Answer is A" in result.content
        assert result.metadata["confidence"] > 0


# =============================================================================
# SelfHealingPattern Tests
# =============================================================================

class TestSelfHealingPattern:
    """Tests for SelfHealingPattern."""
    
    def test_pattern_initialization(self, mock_config):
        """Test pattern initialization."""
        pattern = SelfHealingPattern(mock_config)
        
        assert pattern.max_retries == 3
        assert pattern._primary_agent is None
        assert pattern._healer is None
        assert pattern._validator is None
    
    def test_pattern_with_custom_retries(self, mock_config):
        """Test pattern with custom retry count."""
        pattern = SelfHealingPattern(mock_config, max_retries=5)
        
        assert pattern.max_retries == 5
    
    def test_pattern_with_custom_modification(self, mock_config):
        """Test pattern with custom modification strategy."""
        def custom_mod(attempt, resp, err):
            return f"Attempt {attempt}: Try again"
        
        pattern = SelfHealingPattern(
            mock_config,
            modification_strategy=custom_mod,
        )
        
        result = pattern.modification_strategy(1, "bad", "error")
        assert "Attempt 1" in result
    
    @patch("multi_agent_base.core.patterns.SelfHealingPattern._create_model_client")
    def test_create_agent(self, mock_model_client, mock_config):
        """Test creating the primary agent."""
        mock_model_client.return_value = MagicMock()
        pattern = SelfHealingPattern(mock_config)
        
        pattern.create_agent("worker", "You are a worker.")
        
        assert pattern._primary_agent is not None
        assert "worker" in pattern._agents
    
    def test_set_validator(self, mock_config):
        """Test setting a custom validator."""
        pattern = SelfHealingPattern(mock_config)
        
        pattern.set_validator(lambda x: len(x) > 10)
        
        assert pattern._validator is not None
        assert pattern._validator("short") is False
        assert pattern._validator("this is longer than 10") is True
    
    @patch("multi_agent_base.core.patterns.SelfHealingPattern._create_model_client")
    def test_set_healer(self, mock_model_client, mock_config):
        """Test setting a healer agent."""
        mock_model_client.return_value = MagicMock()
        pattern = SelfHealingPattern(mock_config)
        
        pattern.set_healer("healer", "You fix responses.")
        
        assert pattern._healer is not None
        assert "healer" in pattern._agents
    
    def test_set_error_patterns(self, mock_config):
        """Test setting custom error patterns."""
        pattern = SelfHealingPattern(mock_config)
        
        pattern.set_error_patterns(["FAIL", "BAD"])
        
        assert pattern._error_patterns == ["FAIL", "BAD"]
    
    def test_detect_error(self, mock_config):
        """Test error detection."""
        pattern = SelfHealingPattern(mock_config)
        
        # Should detect error
        assert pattern._detect_error("I'm sorry, I can't do that") is not None
        assert pattern._detect_error("Error occurred") is not None
        assert pattern._detect_error("Unable to process") is not None
        
        # Should not detect error
        assert pattern._detect_error("Task completed successfully") is None
    
    def test_validate_response_empty(self, mock_config):
        """Test validation rejects empty response."""
        pattern = SelfHealingPattern(mock_config)
        
        valid, error = pattern._validate_response("")
        assert valid is False
        assert "Empty" in error
        
        valid, error = pattern._validate_response("   ")
        assert valid is False
    
    def test_validate_response_with_error(self, mock_config):
        """Test validation detects error patterns."""
        pattern = SelfHealingPattern(mock_config)
        
        valid, error = pattern._validate_response("Sorry, I can't help")
        assert valid is False
        assert error is not None
    
    def test_validate_response_custom_validator(self, mock_config):
        """Test validation with custom validator."""
        pattern = SelfHealingPattern(mock_config)
        pattern.set_validator(lambda x: "success" in x.lower())
        
        valid, error = pattern._validate_response("Task failed")
        assert valid is False
        
        valid, error = pattern._validate_response("Success!")
        assert valid is True
    
    def test_default_modification(self, mock_config):
        """Test default modification strategy."""
        pattern = SelfHealingPattern(mock_config)
        
        # First attempt
        mod = pattern._default_modification(1, "bad response", None)
        assert "different approach" in mod.lower()
        
        # With error
        mod = pattern._default_modification(1, "bad", "Validation failed")
        assert "Validation failed" in mod
    
    @pytest.mark.asyncio
    async def test_run_no_agent(self, mock_config):
        """Test running pattern without agent raises error."""
        pattern = SelfHealingPattern(mock_config)
        
        with pytest.raises(RuntimeError, match="No agent created"):
            await pattern.run("Test message")
    
    @pytest.mark.asyncio
    async def test_run_success_first_attempt(self, mock_config, mock_agent_factory):
        """Test running pattern with successful first attempt."""
        pattern = SelfHealingPattern(mock_config)
        
        mock_agent = mock_agent_factory(["Task completed successfully."])
        pattern._primary_agent = mock_agent
        pattern._agents["worker"] = mock_agent
        
        result = await pattern.run("Complete task")
        
        assert "successfully" in result.content
        assert result.metadata["attempts"] == 1
        assert result.metadata["healed"] is False
    
    @pytest.mark.asyncio
    async def test_run_retry_then_success(self, mock_config, mock_agent_factory):
        """Test running pattern with retry leading to success."""
        pattern = SelfHealingPattern(mock_config, max_retries=3)
        
        mock_agent = mock_agent_factory([
            "Sorry, I can't do that.",  # First attempt fails
            "Sorry, I can't do that.",  # Second attempt fails
            "Task completed successfully.",  # Third attempt succeeds
        ])
        pattern._primary_agent = mock_agent
        pattern._agents["worker"] = mock_agent
        
        result = await pattern.run("Complete task")
        
        assert "successfully" in result.content
        assert result.metadata["attempts"] == 3
    
    @pytest.mark.asyncio
    async def test_run_exhausted_retries(self, mock_config, mock_agent_factory):
        """Test running pattern with exhausted retries."""
        pattern = SelfHealingPattern(mock_config, max_retries=2)
        
        mock_agent = mock_agent_factory([
            "Sorry, I can't do that.",
            "Sorry, I can't do that.",
            "Sorry, I can't do that.",
            "Sorry, I can't do that.",
        ])
        pattern._primary_agent = mock_agent
        pattern._agents["worker"] = mock_agent
        
        result = await pattern.run("Complete task")
        
        assert result.metadata["exhausted_retries"] is True
    
    @pytest.mark.asyncio
    async def test_run_with_healer(self, mock_config, mock_agent_factory):
        """Test running pattern with healer on exhausted retries."""
        pattern = SelfHealingPattern(mock_config, max_retries=1)
        
        # Primary agent always fails
        primary_agent = mock_agent_factory(["Sorry, I failed."])
        pattern._primary_agent = primary_agent
        pattern._agents["worker"] = primary_agent
        
        # Healer fixes the response
        healer_agent = mock_agent_factory(["Task completed after healing."])
        pattern._healer = healer_agent
        pattern._agents["healer"] = healer_agent
        
        result = await pattern.run("Complete task")
        
        assert "healing" in result.content or result.metadata.get("healed", False)


# =============================================================================
# Integration Tests
# =============================================================================

class TestPatternIntegration:
    """Integration tests for advanced patterns."""
    
    def test_pattern_type_enum(self):
        """Test that new pattern types are in enum."""
        assert PatternType.HIERARCHICAL.value == "hierarchical"
        assert PatternType.ENSEMBLE.value == "ensemble"
        assert PatternType.SELF_HEALING.value == "self_healing"
    
    def test_create_pattern_hierarchical(self, mock_config):
        """Test creating hierarchical pattern via factory."""
        from multi_agent_base.core.patterns import create_pattern
        
        mock_config.pattern = PatternType.HIERARCHICAL
        pattern = create_pattern(mock_config)
        
        assert isinstance(pattern, HierarchicalPattern)
    
    def test_create_pattern_ensemble(self, mock_config):
        """Test creating ensemble pattern via factory."""
        from multi_agent_base.core.patterns import create_pattern
        
        mock_config.pattern = PatternType.ENSEMBLE
        pattern = create_pattern(mock_config)
        
        assert isinstance(pattern, EnsemblePattern)
    
    def test_create_pattern_self_healing(self, mock_config):
        """Test creating self-healing pattern via factory."""
        from multi_agent_base.core.patterns import create_pattern
        
        mock_config.pattern = PatternType.SELF_HEALING
        pattern = create_pattern(mock_config)
        
        assert isinstance(pattern, SelfHealingPattern)
    
    @pytest.mark.asyncio
    async def test_ensemble_with_aggregator(self, mock_config, mock_agent_factory):
        """Test ensemble pattern with custom aggregator."""
        pattern = EnsemblePattern(mock_config)
        
        # Add voters with different opinions
        pattern._voters = ["expert1", "expert2"]
        pattern._weights = {"expert1": 1.0, "expert2": 1.0}
        pattern._agents["expert1"] = mock_agent_factory(["Opinion A"])
        pattern._agents["expert2"] = mock_agent_factory(["Opinion B"])
        
        # Add aggregator
        aggregator = mock_agent_factory(["Synthesized opinion combining A and B"])
        pattern._aggregator = aggregator
        pattern._agents["aggregator"] = aggregator
        
        result = await pattern.run("Question?")
        
        # Should have used aggregator since there were multiple clusters
        assert result is not None
    
    @pytest.mark.asyncio
    async def test_self_healing_custom_validator(self, mock_config, mock_agent_factory):
        """Test self-healing with custom validator."""
        pattern = SelfHealingPattern(mock_config, max_retries=2)
        
        # Custom validator requires specific keyword
        pattern.set_validator(lambda x: "VERIFIED" in x)
        
        mock_agent = mock_agent_factory([
            "Regular response",  # Fails validation
            "Still regular",  # Fails validation
            "VERIFIED response",  # Passes validation
        ])
        pattern._primary_agent = mock_agent
        
        result = await pattern.run("Test")
        
        assert "VERIFIED" in result.content


# =============================================================================
# Edge Cases and Error Handling
# =============================================================================

class TestEdgeCases:
    """Tests for edge cases and error handling."""
    
    def test_ensemble_empty_responses(self, mock_config):
        """Test ensemble with empty response list."""
        pattern = EnsemblePattern(mock_config)
        
        clusters = pattern._cluster_responses([])
        assert clusters == []
        
        result = pattern._apply_voting([])
        assert result.winner == ""
    
    def test_ensemble_single_voter_cluster(self, mock_config):
        """Test ensemble with single voter forms single cluster."""
        pattern = EnsemblePattern(mock_config)
        pattern._weights = {"agent1": 1.0}
        
        clusters = pattern._cluster_responses([("agent1", "Only response")])
        
        assert len(clusters) == 1
    
    def test_hierarchical_empty_level(self, mock_config, mock_agent_factory):
        """Test hierarchical pattern with empty level."""
        pattern = HierarchicalPattern(mock_config)
        pattern.create_level("empty")
        
        agents = pattern.get_level_agents("empty")
        assert agents == []
    
    def test_self_healing_validate_empty_string(self, mock_config):
        """Test self-healing validates empty strings."""
        pattern = SelfHealingPattern(mock_config)
        
        valid, error = pattern._validate_response("")
        assert valid is False
        
        valid, error = pattern._validate_response("\n\n\n")
        assert valid is False
    
    def test_voting_ranked_choice(self, mock_config):
        """Test ranked choice voting."""
        pattern = EnsemblePattern(
            mock_config,
            voting_strategy=VotingStrategy.RANKED_CHOICE,
        )
        pattern._weights = {"a1": 2.0, "a2": 1.0, "a3": 1.0, "a4": 1.0}
        
        clusters = [
            [("a1", "High weight")],
            [("a2", "Low"), ("a3", "Low"), ("a4", "Low")],
        ]
        
        result = pattern._apply_voting(clusters)
        
        # Ranked choice considers both size and weight
        assert result is not None
        assert result.confidence >= 0


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
