"""
Tests for the Cache module.
"""

import pytest
import asyncio

from multi_agent_base.cache.backend import (
    CacheConfig,
    CacheEntry,
    InMemoryCache,
    TTLCache,
    LLMResponseCache,
)
from multi_agent_base.cache.decorators import cached, cache_response


class TestCacheEntry:
    """Tests for CacheEntry."""
    
    def test_create_entry(self):
        """Test creating a cache entry."""
        entry = CacheEntry(
            key="test_key",
            value="test_value",
        )
        
        assert entry.key == "test_key"
        assert entry.value == "test_value"
        assert entry.hits == 0
    
    def test_entry_expiration(self):
        """Test entry expiration check."""
        from datetime import datetime, timedelta
        
        # Not expired
        entry = CacheEntry(
            key="test",
            value="value",
            expires_at=datetime.now() + timedelta(hours=1),
        )
        assert not entry.is_expired()
        
        # Expired
        expired_entry = CacheEntry(
            key="test",
            value="value",
            expires_at=datetime.now() - timedelta(hours=1),
        )
        assert expired_entry.is_expired()
    
    def test_hit_counter(self):
        """Test hit counter increment."""
        entry = CacheEntry(key="test", value="value")
        
        assert entry.hits == 0
        entry.hit()
        assert entry.hits == 1
        entry.hit()
        assert entry.hits == 2


class TestInMemoryCache:
    """Tests for InMemoryCache."""
    
    @pytest.mark.asyncio
    async def test_set_and_get(self):
        """Test basic set and get operations."""
        cache = InMemoryCache[str]()
        
        await cache.set("key1", "value1")
        result = await cache.get("key1")
        
        assert result == "value1"
    
    @pytest.mark.asyncio
    async def test_get_missing_key(self):
        """Test getting a missing key."""
        cache = InMemoryCache[str]()
        
        result = await cache.get("nonexistent")
        
        assert result is None
    
    @pytest.mark.asyncio
    async def test_delete(self):
        """Test deleting a key."""
        cache = InMemoryCache[str]()
        
        await cache.set("key1", "value1")
        deleted = await cache.delete("key1")
        
        assert deleted is True
        assert await cache.get("key1") is None
    
    @pytest.mark.asyncio
    async def test_lru_eviction(self):
        """Test LRU eviction when cache is full."""
        cache = InMemoryCache[str](max_size=3)
        
        await cache.set("key1", "value1")
        await cache.set("key2", "value2")
        await cache.set("key3", "value3")
        
        # Access key1 to make it recently used
        await cache.get("key1")
        
        # Add key4, should evict key2 (least recently used)
        await cache.set("key4", "value4")
        
        assert await cache.get("key1") == "value1"  # Still there (recently used)
        assert await cache.get("key2") is None  # Evicted
        assert await cache.get("key3") == "value3"
        assert await cache.get("key4") == "value4"
    
    @pytest.mark.asyncio
    async def test_ttl_expiration(self):
        """Test TTL-based expiration."""
        cache = InMemoryCache[str](
            config=CacheConfig(ttl_seconds=1)
        )
        
        await cache.set("key1", "value1", ttl_seconds=1)
        
        # Should exist immediately
        assert await cache.get("key1") == "value1"
        
        # Wait for expiration
        await asyncio.sleep(1.1)
        
        # Should be expired
        assert await cache.get("key1") is None
    
    @pytest.mark.asyncio
    async def test_clear(self):
        """Test clearing the cache."""
        cache = InMemoryCache[str]()
        
        await cache.set("key1", "value1")
        await cache.set("key2", "value2")
        
        await cache.clear()
        
        assert cache.size() == 0
    
    @pytest.mark.asyncio
    async def test_exists(self):
        """Test checking key existence."""
        cache = InMemoryCache[str]()
        
        await cache.set("key1", "value1")
        
        assert await cache.exists("key1") is True
        assert await cache.exists("key2") is False
    
    @pytest.mark.asyncio
    async def test_stats(self):
        """Test cache statistics."""
        cache = InMemoryCache[str](max_size=100)
        
        await cache.set("key1", "value1")
        await cache.get("key1")
        await cache.get("key1")
        
        stats = await cache.get_stats()
        
        assert stats["size"] == 1
        assert stats["max_size"] == 100
        assert stats["total_hits"] == 2


class TestTTLCache:
    """Tests for TTLCache."""
    
    @pytest.mark.asyncio
    async def test_automatic_expiration(self):
        """Test automatic expiration of entries."""
        cache = TTLCache[str](default_ttl=1)
        
        await cache.set("key1", "value1")
        
        assert await cache.get("key1") == "value1"
        
        await asyncio.sleep(1.1)
        
        assert await cache.get("key1") is None
    
    @pytest.mark.asyncio
    async def test_custom_ttl_per_entry(self):
        """Test custom TTL per entry."""
        cache = TTLCache[str](default_ttl=10)
        
        await cache.set("short", "value", ttl_seconds=1)
        await cache.set("long", "value", ttl_seconds=10)
        
        await asyncio.sleep(1.1)
        
        assert await cache.get("short") is None
        assert await cache.get("long") == "value"


class TestLLMResponseCache:
    """Tests for LLMResponseCache."""
    
    @pytest.mark.asyncio
    async def test_cache_llm_response(self):
        """Test caching LLM responses."""
        cache = LLMResponseCache()
        
        messages = [{"role": "user", "content": "Hello"}]
        key = cache.generate_message_key(messages, "gpt-4", 0.7)
        
        response = {"content": "Hi there!", "usage": {"tokens": 10}}
        await cache.set(key, response)
        
        cached = await cache.get(key)
        
        assert cached == response
    
    def test_key_generation(self):
        """Test consistent key generation."""
        cache = LLMResponseCache()
        
        messages = [{"role": "user", "content": "Test"}]
        
        key1 = cache.generate_message_key(messages, "gpt-4", 0.7)
        key2 = cache.generate_message_key(messages, "gpt-4", 0.7)
        
        assert key1 == key2
        
        # Different temperature = different key
        key3 = cache.generate_message_key(messages, "gpt-4", 0.5)
        assert key1 != key3


class TestCachedDecorator:
    """Tests for @cached decorator."""
    
    @pytest.mark.asyncio
    async def test_decorator_caches_result(self):
        """Test that decorator caches function results."""
        call_count = 0
        
        @cached(ttl_seconds=60)
        async def expensive_operation(x: int) -> int:
            nonlocal call_count
            call_count += 1
            return x * 2
        
        # First call
        result1 = await expensive_operation(5)
        assert result1 == 10
        assert call_count == 1
        
        # Second call (should be cached)
        result2 = await expensive_operation(5)
        assert result2 == 10
        assert call_count == 1  # No additional call
    
    @pytest.mark.asyncio
    async def test_different_args_different_cache(self):
        """Test that different arguments use different cache entries."""
        call_count = 0
        
        @cached(ttl_seconds=60)
        async def compute(x: int) -> int:
            nonlocal call_count
            call_count += 1
            return x + 1
        
        await compute(1)
        await compute(2)
        await compute(1)  # Should be cached
        
        assert call_count == 2
    
    @pytest.mark.asyncio
    async def test_cache_clear(self):
        """Test clearing decorator cache."""
        @cached(ttl_seconds=60)
        async def func():
            return "value"
        
        await func()
        assert func.cache_size() == 1
        
        await func.clear_cache()
        assert func.cache_size() == 0


class TestCacheResponseDecorator:
    """Tests for @cache_response decorator."""
    
    @pytest.mark.asyncio
    async def test_shared_cache(self):
        """Test using shared cache across functions."""
        cache = InMemoryCache[str]()
        
        @cache_response(cache)
        async def func1(key: str) -> str:
            return f"func1_{key}"
        
        @cache_response(cache)
        async def func2(key: str) -> str:
            return f"func2_{key}"
        
        await func1("test")
        await func2("test")
        
        # Both should be in the same cache
        assert cache.size() == 2
