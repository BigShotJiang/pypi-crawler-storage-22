"""Tests for AF ChatHistoryProvider Adapter."""

import pytest
from datetime import datetime
from unittest.mock import AsyncMock, MagicMock

from multi_agent_base.core.chat_history import (
    ChatMessage,
    InvokingContext,
    InvokedContext,
    ChatHistoryProvider,
    MemoryBackendChatHistoryProvider,
    InMemoryChatHistoryProvider,
    SlidingWindowChatHistoryProvider,
    TokenLimitedChatHistoryProvider,
    create_chat_history_provider,
)


class TestChatMessage:
    """Tests for ChatMessage."""
    
    def test_create_message(self):
        """Test creating a chat message."""
        msg = ChatMessage(role="user", content="Hello")
        
        assert msg.role == "user"
        assert msg.content == "Hello"
        assert msg.text == "Hello"  # AF compatibility
        assert msg.message_id is not None
    
    def test_message_with_metadata(self):
        """Test message with metadata."""
        msg = ChatMessage(
            role="assistant",
            content="Hi there",
            author_name="bot",
            metadata={"source": "test"}
        )
        
        assert msg.author_name == "bot"
        assert msg.metadata["source"] == "test"
    
    def test_message_to_dict(self):
        """Test message serialization."""
        msg = ChatMessage(
            role="user",
            content="Test",
            message_id="msg-1"
        )
        
        data = msg.to_dict()
        
        assert data["role"] == "user"
        assert data["content"] == "Test"
        assert data["message_id"] == "msg-1"
    
    def test_message_from_dict(self):
        """Test message deserialization."""
        data = {
            "role": "assistant",
            "content": "Response",
            "message_id": "msg-2",
            "author_name": "assistant-1",
            "created_at": "2024-01-01T00:00:00",
        }
        
        msg = ChatMessage.from_dict(data)
        
        assert msg.role == "assistant"
        assert msg.content == "Response"
        assert msg.message_id == "msg-2"
        assert msg.author_name == "assistant-1"


class TestInvokingContext:
    """Tests for InvokingContext."""
    
    def test_create_empty_context(self):
        """Test creating empty context."""
        context = InvokingContext()
        
        assert len(context.input_messages) == 0
    
    def test_create_with_messages(self):
        """Test creating context with messages."""
        messages = [
            ChatMessage(role="user", content="Hello"),
            ChatMessage(role="assistant", content="Hi"),
        ]
        
        context = InvokingContext(input_messages=messages)
        
        assert len(context.input_messages) == 2


class TestInvokedContext:
    """Tests for InvokedContext."""
    
    def test_create_context(self):
        """Test creating invoked context."""
        request = [ChatMessage(role="user", content="Question")]
        response = [ChatMessage(role="assistant", content="Answer")]
        
        context = InvokedContext(
            request_messages=request,
            response_messages=response,
        )
        
        assert len(context.request_messages) == 1
        assert len(context.response_messages) == 1
    
    def test_context_with_exception(self):
        """Test context with exception."""
        context = InvokedContext(
            request_messages=[],
            invoke_exception=ValueError("Something went wrong")
        )
        
        assert context.invoke_exception is not None


class TestInMemoryChatHistoryProvider:
    """Tests for InMemoryChatHistoryProvider."""
    
    @pytest.mark.asyncio
    async def test_invoking_returns_history(self):
        """Test invoking returns stored history."""
        provider = InMemoryChatHistoryProvider()
        
        # Add some messages
        await provider.add_messages([
            ChatMessage(role="user", content="Hello"),
            ChatMessage(role="assistant", content="Hi"),
        ])
        
        history = await provider.invoking_async(InvokingContext())
        
        assert len(history) == 2
    
    @pytest.mark.asyncio
    async def test_invoked_stores_messages(self):
        """Test invoked stores request and response messages."""
        provider = InMemoryChatHistoryProvider()
        
        context = InvokedContext(
            request_messages=[ChatMessage(role="user", content="Question")],
            response_messages=[ChatMessage(role="assistant", content="Answer")],
        )
        
        await provider.invoked_async(context)
        
        assert len(provider) == 2
    
    @pytest.mark.asyncio
    async def test_invoked_skips_on_exception(self):
        """Test invoked skips storing when exception occurred."""
        provider = InMemoryChatHistoryProvider()
        
        context = InvokedContext(
            request_messages=[ChatMessage(role="user", content="Question")],
            invoke_exception=ValueError("Error"),
        )
        
        await provider.invoked_async(context)
        
        assert len(provider) == 0
    
    @pytest.mark.asyncio
    async def test_max_messages_limit(self):
        """Test messages are trimmed to max_messages."""
        provider = InMemoryChatHistoryProvider(max_messages=3)
        
        for i in range(5):
            await provider.add_messages([
                ChatMessage(role="user", content=f"Message {i}")
            ])
        
        assert len(provider) == 3
    
    def test_get_from_bookmark(self):
        """Test getting messages since bookmark."""
        provider = InMemoryChatHistoryProvider()
        
        provider._messages = [
            ChatMessage(role="user", content="Old"),
            ChatMessage(role="assistant", content="Response"),
        ]
        provider._bookmark = 1
        
        new_messages = list(provider.get_from_bookmark())
        
        assert len(new_messages) == 1
        assert new_messages[0].content == "Response"
    
    def test_update_bookmark(self):
        """Test updating bookmark."""
        provider = InMemoryChatHistoryProvider()
        
        provider._messages = [
            ChatMessage(role="user", content="One"),
            ChatMessage(role="assistant", content="Two"),
        ]
        
        provider.update_bookmark()
        
        assert provider._bookmark == 2
    
    def test_clear(self):
        """Test clearing history."""
        provider = InMemoryChatHistoryProvider()
        
        provider._messages = [ChatMessage(role="user", content="Test")]
        provider._bookmark = 1
        
        provider.clear()
        
        assert len(provider) == 0
        assert provider._bookmark == 0
    
    def test_serialize(self):
        """Test serializing provider state."""
        provider = InMemoryChatHistoryProvider()
        provider._messages = [ChatMessage(role="user", content="Test")]
        provider._bookmark = 1
        
        state = provider.serialize()
        
        assert state["provider_type"] == "InMemoryChatHistoryProvider"
        assert len(state["messages"]) == 1
        assert state["bookmark"] == 1
    
    def test_deserialize(self):
        """Test deserializing provider state."""
        state = {
            "provider_type": "InMemoryChatHistoryProvider",
            "messages": [{"role": "user", "content": "Test"}],
            "bookmark": 1,
            "max_messages": 100,
        }
        
        provider = InMemoryChatHistoryProvider.deserialize(state)
        
        assert len(provider) == 1
        assert provider._bookmark == 1


class TestSlidingWindowChatHistoryProvider:
    """Tests for SlidingWindowChatHistoryProvider."""
    
    @pytest.mark.asyncio
    async def test_window_limits_messages(self):
        """Test sliding window limits messages."""
        provider = SlidingWindowChatHistoryProvider(window_size=3)
        
        for i in range(5):
            await provider.add_messages([
                ChatMessage(role="user", content=f"Message {i}")
            ])
        
        history = await provider.invoking_async(InvokingContext())
        
        # Should only return last 3 messages
        assert len(history) == 3
        assert history[0].content == "Message 2"
    
    @pytest.mark.asyncio
    async def test_preserves_system_messages(self):
        """Test system messages are preserved."""
        provider = SlidingWindowChatHistoryProvider(
            window_size=2,
            preserve_system=True
        )
        
        # Add system message first
        await provider.add_messages([
            ChatMessage(role="system", content="System prompt")
        ])
        
        # Add more messages
        for i in range(5):
            await provider.add_messages([
                ChatMessage(role="user", content=f"User {i}"),
                ChatMessage(role="assistant", content=f"Assistant {i}"),
            ])
        
        history = await provider.invoking_async(InvokingContext())
        
        # Should have system message + 2 from window
        assert history[0].role == "system"
        assert history[0].content == "System prompt"


class TestTokenLimitedChatHistoryProvider:
    """Tests for TokenLimitedChatHistoryProvider."""
    
    @pytest.mark.asyncio
    async def test_token_limit(self):
        """Test token limit constrains messages."""
        provider = TokenLimitedChatHistoryProvider(max_tokens=50)
        
        # Add long messages
        for i in range(5):
            await provider.add_messages([
                ChatMessage(role="user", content="A" * 100)  # ~25 tokens each
            ])
        
        history = await provider.invoking_async(InvokingContext())
        
        # Should only fit ~2 messages
        assert len(history) <= 2
    
    @pytest.mark.asyncio
    async def test_preserves_system_messages(self):
        """Test system messages are preserved within budget."""
        provider = TokenLimitedChatHistoryProvider(
            max_tokens=100,
            preserve_system=True
        )
        
        await provider.add_messages([
            ChatMessage(role="system", content="System"),
            ChatMessage(role="user", content="A" * 200),
            ChatMessage(role="assistant", content="B" * 200),
        ])
        
        history = await provider.invoking_async(InvokingContext())
        
        # System should be first
        assert history[0].role == "system"


class TestMemoryBackendChatHistoryProvider:
    """Tests for MemoryBackendChatHistoryProvider."""
    
    @pytest.mark.asyncio
    async def test_invoking_uses_backend(self):
        """Test invoking calls backend.get_recent."""
        mock_backend = MagicMock()
        mock_entry = MagicMock()
        mock_entry.role = "user"
        mock_entry.content = "Hello"
        mock_entry.id = "entry-1"
        mock_entry.agent_name = None
        mock_entry.timestamp = datetime.utcnow()
        mock_entry.metadata = {}
        
        mock_backend.get_recent = AsyncMock(return_value=[mock_entry])
        
        provider = MemoryBackendChatHistoryProvider(
            backend=mock_backend,
            session_id="session-1",
        )
        
        history = await provider.invoking_async(InvokingContext())
        
        assert len(history) == 1
        mock_backend.get_recent.assert_called_once()
    
    @pytest.mark.asyncio
    async def test_invoking_with_semantic_search(self):
        """Test invoking uses semantic search when enabled."""
        mock_backend = MagicMock()
        mock_backend.search = AsyncMock(return_value=[])
        
        provider = MemoryBackendChatHistoryProvider(
            backend=mock_backend,
            use_semantic_search=True,
        )
        
        context = InvokingContext(input_messages=[
            ChatMessage(role="user", content="What about AI?")
        ])
        
        await provider.invoking_async(context)
        
        mock_backend.search.assert_called_once()
    
    @pytest.mark.asyncio
    async def test_invoked_stores_messages(self):
        """Test invoked stores messages to backend."""
        mock_backend = MagicMock()
        mock_backend.add = AsyncMock()
        
        provider = MemoryBackendChatHistoryProvider(backend=mock_backend)
        
        context = InvokedContext(
            request_messages=[ChatMessage(role="user", content="Question")],
            response_messages=[ChatMessage(role="assistant", content="Answer")],
        )
        
        await provider.invoked_async(context)
        
        assert mock_backend.add.call_count == 2
    
    def test_serialize(self):
        """Test serializing provider state."""
        mock_backend = MagicMock()
        mock_backend.__class__.__name__ = "MockMemoryBackend"
        
        provider = MemoryBackendChatHistoryProvider(
            backend=mock_backend,
            session_id="session-1",
            use_semantic_search=True,
        )
        
        state = provider.serialize()
        
        assert state["provider_type"] == "MemoryBackendChatHistoryProvider"
        assert state["session_id"] == "session-1"
        assert state["use_semantic_search"] is True


class TestCreateChatHistoryProvider:
    """Tests for create_chat_history_provider factory."""
    
    def test_create_in_memory(self):
        """Test creating in-memory provider."""
        provider = create_chat_history_provider("in_memory", max_messages=50)
        
        assert isinstance(provider, InMemoryChatHistoryProvider)
    
    def test_create_sliding_window(self):
        """Test creating sliding window provider."""
        provider = create_chat_history_provider(
            "sliding_window",
            window_size=100
        )
        
        assert isinstance(provider, SlidingWindowChatHistoryProvider)
    
    def test_create_token_limited(self):
        """Test creating token limited provider."""
        provider = create_chat_history_provider(
            "token_limited",
            max_tokens=8000
        )
        
        assert isinstance(provider, TokenLimitedChatHistoryProvider)
    
    def test_unknown_type_raises_error(self):
        """Test unknown provider type raises error."""
        with pytest.raises(ValueError, match="Unknown provider type"):
            create_chat_history_provider("unknown_type")
