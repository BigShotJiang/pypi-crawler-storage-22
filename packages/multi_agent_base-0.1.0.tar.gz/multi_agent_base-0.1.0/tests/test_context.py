"""
Tests for Context Engineering Module

Comprehensive tests for context optimization, pruning, and compression.
"""

import time
import pytest
from typing import Any

from multi_agent_base.context import (
    # Types
    MessageRole,
    PruningStrategy,
    CompressionMethod,
    ContextMessage,
    ContextWindow,
    ContextStats,
    OptimizationConfig,
    ToolContext,
    ContextSnapshot,
    # Optimizer
    ContextOptimizer,
    OptimizationResult,
    TokenEstimator,
    # Pruner
    ContextPruner,
    ConversationPruner,
    PruningResult,
    # Compressor
    ContextCompressor,
    CompressionResult,
)


# ============================================================================
# Test Fixtures
# ============================================================================

@pytest.fixture
def sample_messages() -> list[dict[str, Any]]:
    """Sample messages for testing."""
    return [
        {"role": "system", "content": "You are a helpful assistant."},
        {"role": "user", "content": "What is the capital of France?"},
        {"role": "assistant", "content": "The capital of France is Paris."},
        {"role": "user", "content": "What is its population?"},
        {"role": "assistant", "content": "Paris has a population of about 2.1 million people in the city proper."},
    ]


@pytest.fixture
def long_conversation() -> list[dict[str, Any]]:
    """Long conversation for testing pruning."""
    messages = [
        {"role": "system", "content": "You are a helpful coding assistant."},
    ]
    
    for i in range(50):
        messages.append({
            "role": "user",
            "content": f"Question {i+1}: Can you help me with problem number {i+1}? " + "x" * 100,
        })
        messages.append({
            "role": "assistant", 
            "content": f"Answer {i+1}: Yes, here is the solution for problem {i+1}. " + "y" * 200,
        })
    
    return messages


@pytest.fixture
def context_messages() -> list[ContextMessage]:
    """Sample ContextMessage objects."""
    return [
        ContextMessage(role="system", content="You are helpful.", importance=1.0),
        ContextMessage(role="user", content="Hello!", importance=0.7),
        ContextMessage(role="assistant", content="Hi there! How can I help?", importance=0.6),
        ContextMessage(role="user", content="Tell me about Python.", importance=0.8),
        ContextMessage(role="assistant", content="Python is a programming language.", importance=0.6),
    ]


@pytest.fixture
def sample_tools() -> list[dict[str, Any]]:
    """Sample tool definitions."""
    return [
        {
            "type": "function",
            "function": {
                "name": "get_weather",
                "description": "Get weather for a location",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "location": {"type": "string"}
                    }
                }
            }
        },
        {
            "type": "function",
            "function": {
                "name": "search_web",
                "description": "Search the web for information",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "query": {"type": "string"}
                    }
                }
            }
        },
    ]


# ============================================================================
# Tests for Types
# ============================================================================

class TestMessageRole:
    """Tests for MessageRole enum."""
    
    def test_enum_values(self):
        """Test enum values."""
        assert MessageRole.SYSTEM.value == "system"
        assert MessageRole.USER.value == "user"
        assert MessageRole.ASSISTANT.value == "assistant"
        assert MessageRole.TOOL.value == "tool"
        assert MessageRole.FUNCTION.value == "function"


class TestPruningStrategy:
    """Tests for PruningStrategy enum."""
    
    def test_enum_values(self):
        """Test enum values."""
        assert PruningStrategy.RECENCY.value == "recency"
        assert PruningStrategy.RELEVANCE.value == "relevance"
        assert PruningStrategy.IMPORTANCE.value == "importance"
        assert PruningStrategy.SLIDING_WINDOW.value == "sliding_window"
        assert PruningStrategy.SMART.value == "smart"


class TestCompressionMethod:
    """Tests for CompressionMethod enum."""
    
    def test_enum_values(self):
        """Test enum values."""
        assert CompressionMethod.SUMMARIZE.value == "summarize"
        assert CompressionMethod.MERGE.value == "merge"
        assert CompressionMethod.EXTRACT_KEY_POINTS.value == "extract_key_points"
        assert CompressionMethod.HIERARCHICAL.value == "hierarchical"


class TestContextMessage:
    """Tests for ContextMessage dataclass."""
    
    def test_creation_with_role_string(self):
        """Test creation with role as string."""
        msg = ContextMessage(role="user", content="Hello")
        assert msg.role == "user"
        assert msg.content == "Hello"
    
    def test_creation_with_role_enum(self):
        """Test creation with role as enum."""
        msg = ContextMessage(role=MessageRole.USER, content="Hello")
        assert msg.role == "user"
    
    def test_role_enum_property(self):
        """Test role_enum property."""
        msg = ContextMessage(role="assistant", content="Hi")
        assert msg.role_enum == MessageRole.ASSISTANT
    
    def test_content_hash(self):
        """Test content hash generation."""
        msg = ContextMessage(role="user", content="Hello")
        hash1 = msg.content_hash
        
        msg2 = ContextMessage(role="user", content="Hello")
        hash2 = msg2.content_hash
        
        assert hash1 == hash2
        
        msg3 = ContextMessage(role="user", content="Different")
        assert msg.content_hash != msg3.content_hash
    
    def test_estimate_tokens(self):
        """Test token estimation."""
        msg = ContextMessage(role="user", content="Hello world this is a test")
        tokens = msg.estimate_tokens()
        
        assert tokens > 0
        assert msg.token_count == tokens
    
    def test_to_dict(self):
        """Test conversion to dictionary."""
        msg = ContextMessage(role="user", content="Hello", name="test_user")
        d = msg.to_dict()
        
        assert d["role"] == "user"
        assert d["content"] == "Hello"
        assert d["name"] == "test_user"
    
    def test_from_dict(self):
        """Test creation from dictionary."""
        data = {"role": "user", "content": "Hello", "name": "test"}
        msg = ContextMessage.from_dict(data)
        
        assert msg.role == "user"
        assert msg.content == "Hello"
        assert msg.name == "test"
    
    def test_repr(self):
        """Test string representation."""
        msg = ContextMessage(role="user", content="Hello world")
        repr_str = repr(msg)
        
        assert "ContextMessage" in repr_str
        assert "user" in repr_str


class TestContextWindow:
    """Tests for ContextWindow dataclass."""
    
    def test_creation(self):
        """Test window creation."""
        window = ContextWindow(max_tokens=4096)
        assert window.max_tokens == 4096
        assert len(window) == 0
    
    def test_add_message(self):
        """Test adding messages."""
        window = ContextWindow(max_tokens=4096)
        msg = ContextMessage(role="user", content="Hello")
        msg.estimate_tokens()
        
        result = window.add_message(msg)
        
        assert result is True
        assert len(window) == 1
    
    def test_add_message_exceeds_limit(self):
        """Test adding message that exceeds limit."""
        window = ContextWindow(max_tokens=10)
        msg = ContextMessage(role="user", content="This is a very long message that exceeds the token limit")
        msg.estimate_tokens()
        
        result = window.add_message(msg)
        
        # Should fail if it exceeds limit
        assert result is False or window.current_tokens > 0
    
    def test_remove_message(self):
        """Test removing messages."""
        window = ContextWindow(max_tokens=4096)
        msg = ContextMessage(role="user", content="Hello")
        msg.estimate_tokens()
        window.add_message(msg)
        
        removed = window.remove_message(0)
        
        assert removed is not None
        assert len(window) == 0
    
    def test_clear(self):
        """Test clearing messages."""
        window = ContextWindow(max_tokens=4096)
        window.add_message(ContextMessage(role="user", content="Hello"))
        window.add_message(ContextMessage(role="assistant", content="Hi"))
        
        window.clear()
        
        assert len(window) == 0
        assert window.current_tokens == 0
    
    def test_available_tokens(self):
        """Test available tokens calculation."""
        window = ContextWindow(max_tokens=1000)
        msg = ContextMessage(role="user", content="Hello")
        msg.estimate_tokens()
        window.add_message(msg)
        
        assert window.available_tokens == window.max_tokens - window.current_tokens
    
    def test_utilization(self):
        """Test utilization calculation."""
        window = ContextWindow(max_tokens=100)
        
        assert window.utilization == 0.0
        
        msg = ContextMessage(role="user", content="Test")
        msg.estimate_tokens()
        window.add_message(msg)
        
        assert window.utilization > 0
    
    def test_get_messages_by_role(self):
        """Test filtering by role."""
        window = ContextWindow(max_tokens=4096)
        window.add_message(ContextMessage(role="user", content="Hello"))
        window.add_message(ContextMessage(role="assistant", content="Hi"))
        window.add_message(ContextMessage(role="user", content="Bye"))
        
        user_msgs = window.get_messages_by_role("user")
        
        assert len(user_msgs) == 2
    
    def test_to_list(self):
        """Test conversion to list of dicts."""
        window = ContextWindow(max_tokens=4096)
        window.add_message(ContextMessage(role="user", content="Hello"))
        
        result = window.to_list()
        
        assert isinstance(result, list)
        assert len(result) == 1
        assert result[0]["role"] == "user"
    
    def test_from_list(self):
        """Test creation from list of dicts."""
        messages = [
            {"role": "user", "content": "Hello"},
            {"role": "assistant", "content": "Hi"},
        ]
        
        window = ContextWindow.from_list(messages, max_tokens=4096)
        
        assert len(window) == 2
    
    def test_iteration(self):
        """Test iterating over window."""
        window = ContextWindow(max_tokens=4096)
        window.add_message(ContextMessage(role="user", content="Hello"))
        window.add_message(ContextMessage(role="assistant", content="Hi"))
        
        count = 0
        for msg in window:
            count += 1
            assert isinstance(msg, ContextMessage)
        
        assert count == 2


class TestContextStats:
    """Tests for ContextStats dataclass."""
    
    def test_creation(self):
        """Test stats creation."""
        stats = ContextStats(
            original_messages=10,
            optimized_messages=5,
            original_tokens=1000,
            optimized_tokens=500,
        )
        
        assert stats.original_messages == 10
        assert stats.optimized_messages == 5
    
    def test_message_reduction(self):
        """Test message reduction calculation."""
        stats = ContextStats(
            original_messages=10,
            optimized_messages=5,
        )
        
        assert stats.message_reduction == 0.5
    
    def test_token_reduction(self):
        """Test token reduction calculation."""
        stats = ContextStats(
            original_tokens=1000,
            optimized_tokens=500,
        )
        
        assert stats.token_reduction == 0.5
    
    def test_tokens_saved(self):
        """Test tokens saved calculation."""
        stats = ContextStats(
            original_tokens=1000,
            optimized_tokens=600,
        )
        
        assert stats.tokens_saved == 400
    
    def test_to_dict(self):
        """Test conversion to dictionary."""
        stats = ContextStats(
            original_messages=10,
            optimized_messages=5,
            original_tokens=1000,
            optimized_tokens=500,
            strategy_used="recency",
        )
        
        d = stats.to_dict()
        
        assert d["original_messages"] == 10
        assert d["message_reduction_pct"] == 50.0
        assert d["tokens_saved"] == 500


class TestOptimizationConfig:
    """Tests for OptimizationConfig dataclass."""
    
    def test_default_config(self):
        """Test default configuration."""
        config = OptimizationConfig()
        
        assert config.max_tokens == 4096
        assert config.preserve_system is True
        assert config.preserve_recent == 3
    
    def test_validation_negative_max_tokens(self):
        """Test validation for negative max_tokens."""
        with pytest.raises(ValueError):
            OptimizationConfig(max_tokens=-100)
    
    def test_validation_invalid_threshold(self):
        """Test validation for invalid threshold."""
        with pytest.raises(ValueError):
            OptimizationConfig(relevance_threshold=1.5)
    
    def test_aggressive_config(self):
        """Test aggressive configuration preset."""
        config = OptimizationConfig.aggressive()
        
        assert config.max_tokens == 2048
        assert config.preserve_recent == 1
        assert config.relevance_threshold == 0.5
    
    def test_balanced_config(self):
        """Test balanced configuration preset."""
        config = OptimizationConfig.balanced()
        
        assert config.max_tokens == 4096
        assert config.preserve_recent == 3
    
    def test_conservative_config(self):
        """Test conservative configuration preset."""
        config = OptimizationConfig.conservative()
        
        assert config.max_tokens == 8192
        assert config.preserve_recent == 5


class TestToolContext:
    """Tests for ToolContext dataclass."""
    
    def test_creation(self):
        """Test tool context creation."""
        tool = ToolContext(
            name="get_weather",
            description="Get weather for a location",
            parameters={"type": "object"},
        )
        
        assert tool.name == "get_weather"
        assert tool.usage_count == 0
    
    def test_estimate_tokens(self):
        """Test token estimation for tool."""
        tool = ToolContext(
            name="search",
            description="Search for information",
            parameters={"type": "object", "properties": {"query": {"type": "string"}}},
        )
        
        tokens = tool.estimate_tokens()
        
        assert tokens > 0
        assert tool.token_count == tokens
    
    def test_to_dict(self):
        """Test conversion to dict."""
        tool = ToolContext(
            name="get_time",
            description="Get current time",
            parameters={},
        )
        
        d = tool.to_dict()
        
        assert d["type"] == "function"
        assert d["function"]["name"] == "get_time"


# ============================================================================
# Tests for ContextOptimizer
# ============================================================================

class TestContextOptimizer:
    """Tests for ContextOptimizer class."""
    
    def test_creation(self):
        """Test optimizer creation."""
        optimizer = ContextOptimizer()
        
        assert optimizer.config is not None
        assert optimizer.summarizer is None
    
    def test_creation_with_config(self):
        """Test optimizer creation with config."""
        config = OptimizationConfig(max_tokens=2048)
        optimizer = ContextOptimizer(config=config)
        
        assert optimizer.config.max_tokens == 2048
    
    def test_optimize_already_within_limit(self, sample_messages):
        """Test optimization when already within limit."""
        config = OptimizationConfig(max_tokens=10000)
        optimizer = ContextOptimizer(config=config)
        
        result = optimizer.optimize(sample_messages)
        
        assert result.stats.strategy_used == "none_needed"
        assert len(result.messages) == len(sample_messages)
    
    def test_optimize_prune_by_recency(self, long_conversation):
        """Test optimization with recency pruning."""
        config = OptimizationConfig(
            max_tokens=100,
            pruning_strategy=PruningStrategy.RECENCY,
        )
        optimizer = ContextOptimizer(config=config)
        
        result = optimizer.optimize(long_conversation)
        
        # With very low token limit, should either prune or hit limit naturally
        assert len(result.messages) <= len(long_conversation)
    
    def test_optimize_prune_by_sliding_window(self, long_conversation):
        """Test optimization with sliding window."""
        config = OptimizationConfig(
            max_tokens=500,
            pruning_strategy=PruningStrategy.SLIDING_WINDOW,
        )
        optimizer = ContextOptimizer(config=config)
        
        result = optimizer.optimize(long_conversation)
        
        assert len(result.messages) < len(long_conversation)
    
    def test_optimize_prune_by_importance(self, context_messages):
        """Test optimization with importance pruning."""
        config = OptimizationConfig(
            max_tokens=20,
            pruning_strategy=PruningStrategy.IMPORTANCE,
        )
        optimizer = ContextOptimizer(config=config)
        
        result = optimizer.optimize(context_messages)
        
        # Should apply importance strategy when tokens exceed limit
        assert result.stats.strategy_used in ("importance", "none_needed")
    
    def test_optimize_prune_by_relevance(self, long_conversation):
        """Test optimization with relevance pruning."""
        config = OptimizationConfig(
            max_tokens=200,
            pruning_strategy=PruningStrategy.RELEVANCE,
        )
        optimizer = ContextOptimizer(config=config)
        
        result = optimizer.optimize(long_conversation, query="problem 15")
        
        assert result.stats.strategy_used in ("relevance", "none_needed")
    
    def test_optimize_smart_strategy(self, long_conversation):
        """Test optimization with smart strategy."""
        config = OptimizationConfig(
            max_tokens=200,
            pruning_strategy=PruningStrategy.SMART,
        )
        optimizer = ContextOptimizer(config=config)
        
        result = optimizer.optimize(long_conversation)
        
        assert result.stats.strategy_used in ("smart", "none_needed")
    
    def test_optimize_with_summarizer(self, long_conversation):
        """Test optimization with custom summarizer."""
        def mock_summarizer(contents: list[str]) -> str:
            return f"Summary of {len(contents)} messages"
        
        config = OptimizationConfig(
            max_tokens=500,
            pruning_strategy=PruningStrategy.SMART,
            enable_summarization=True,
        )
        optimizer = ContextOptimizer(config=config, summarizer=mock_summarizer)
        
        result = optimizer.optimize(long_conversation)
        
        # Should have generated a summary
        assert result.summary is not None or result.stats.pruned_count == 0
    
    def test_optimize_with_context_window(self, sample_messages):
        """Test optimization with ContextWindow input."""
        window = ContextWindow.from_list(sample_messages, max_tokens=10000)
        optimizer = ContextOptimizer()
        
        result = optimizer.optimize(window)
        
        assert isinstance(result, OptimizationResult)
    
    def test_optimize_with_tools(self, sample_messages, sample_tools):
        """Test optimization with tools."""
        config = OptimizationConfig(max_tokens=2000)
        optimizer = ContextOptimizer(config=config)
        
        result, tools = optimizer.optimize_with_tools(sample_messages, sample_tools)
        
        assert isinstance(result, OptimizationResult)
        assert isinstance(tools, list)
    
    def test_get_snapshots(self, long_conversation):
        """Test getting optimization snapshots."""
        config = OptimizationConfig(max_tokens=500)
        optimizer = ContextOptimizer(config=config)
        
        optimizer.optimize(long_conversation)
        snapshots = optimizer.get_snapshots()
        
        assert len(snapshots) > 0
        assert all(isinstance(s, ContextSnapshot) for s in snapshots)
    
    def test_optimization_result_to_list(self, sample_messages):
        """Test OptimizationResult to_list method."""
        optimizer = ContextOptimizer()
        result = optimizer.optimize(sample_messages)
        
        messages_list = result.to_list()
        
        assert isinstance(messages_list, list)
        assert all(isinstance(m, dict) for m in messages_list)


class TestTokenEstimator:
    """Tests for TokenEstimator class."""
    
    def test_estimate_simple(self):
        """Test simple token estimation."""
        text = "Hello world, this is a test."
        tokens = TokenEstimator.estimate_simple(text)
        
        assert tokens > 0
    
    def test_estimate_simple_with_model(self):
        """Test estimation with specific model."""
        text = "Hello world"
        tokens_gpt4 = TokenEstimator.estimate_simple(text, "gpt-4")
        tokens_claude = TokenEstimator.estimate_simple(text, "claude")
        
        # Claude has different chars per token
        assert tokens_gpt4 > 0
        assert tokens_claude > 0
    
    def test_estimate_words(self):
        """Test word-based estimation."""
        text = "one two three four five"
        tokens = TokenEstimator.estimate_words(text)
        
        # ~1.3 tokens per word, so 5 words = ~6-7 tokens
        assert tokens >= 5
    
    def test_estimate_messages(self, sample_messages):
        """Test message list estimation."""
        tokens = TokenEstimator.estimate_messages(sample_messages)
        
        assert tokens > 0
    
    def test_estimate_tool(self, sample_tools):
        """Test tool definition estimation."""
        tokens = TokenEstimator.estimate_tool(sample_tools[0])
        
        assert tokens > 0


# ============================================================================
# Tests for ContextPruner
# ============================================================================

class TestContextPruner:
    """Tests for ContextPruner class."""
    
    def test_creation(self):
        """Test pruner creation."""
        pruner = ContextPruner()
        
        assert pruner.preserve_system is True
        assert pruner.min_messages == 1
    
    def test_prune_by_recency(self, sample_messages):
        """Test recency-based pruning."""
        pruner = ContextPruner()
        
        result = pruner.prune_by_recency(sample_messages, keep_count=3)
        
        assert isinstance(result, PruningResult)
        assert result.kept_count <= 3
    
    def test_prune_by_recency_preserves_system(self, sample_messages):
        """Test that system messages are preserved."""
        pruner = ContextPruner(preserve_system=True)
        
        result = pruner.prune_by_recency(sample_messages, keep_count=10)
        
        system_msgs = [m for m in result.kept if m.role == "system"]
        assert len(system_msgs) == 1
    
    def test_prune_by_relevance(self, sample_messages):
        """Test relevance-based pruning."""
        pruner = ContextPruner()
        
        result = pruner.prune_by_relevance(
            sample_messages,
            query="Paris",
            keep_count=3,
        )
        
        assert isinstance(result, PruningResult)
    
    def test_prune_by_relevance_with_scorer(self, sample_messages):
        """Test relevance pruning with custom scorer."""
        def scorer(query: str, content: str) -> float:
            return 1.0 if query.lower() in content.lower() else 0.0
        
        pruner = ContextPruner()
        result = pruner.prune_by_relevance(
            sample_messages,
            query="Paris",
            keep_count=5,
            scorer=scorer,
        )
        
        assert result is not None
    
    def test_prune_by_token_limit(self, long_conversation):
        """Test token-based pruning."""
        pruner = ContextPruner()
        
        result = pruner.prune_by_token_limit(long_conversation, max_tokens=500)
        
        assert result.stats.optimized_tokens <= 500 or result.kept_count <= 2
    
    def test_prune_by_token_limit_already_within(self, sample_messages):
        """Test when already within token limit."""
        pruner = ContextPruner()
        
        result = pruner.prune_by_token_limit(sample_messages, max_tokens=10000)
        
        assert result.stats.strategy_used == "none_needed"
        assert result.pruned_count == 0
    
    def test_prune_duplicates(self):
        """Test duplicate removal."""
        messages = [
            {"role": "user", "content": "Hello"},
            {"role": "user", "content": "Hello"},  # Exact duplicate
            {"role": "assistant", "content": "Hi there"},
            {"role": "user", "content": "Hello there"},  # Similar
        ]
        
        pruner = ContextPruner()
        result = pruner.prune_duplicates(messages, similarity_threshold=0.9)
        
        # Should remove exact duplicate
        assert result.pruned_count >= 1
    
    def test_prune_by_pattern(self, sample_messages):
        """Test pattern-based pruning."""
        pruner = ContextPruner()
        
        # Remove messages containing "Paris"
        result = pruner.prune_by_pattern(
            sample_messages,
            patterns=["Paris"],
            keep_matches=False,
        )
        
        # Check that Paris messages are pruned
        for msg in result.kept:
            assert "Paris" not in msg.content
    
    def test_prune_by_pattern_keep_matches(self, sample_messages):
        """Test pattern-based pruning keeping matches."""
        pruner = ContextPruner()
        
        result = pruner.prune_by_pattern(
            sample_messages,
            patterns=["Paris|France"],
            keep_matches=True,
        )
        
        # Should only keep messages mentioning Paris or France
        assert result.kept_count > 0
    
    def test_prune_by_role(self, sample_messages):
        """Test role-based pruning."""
        pruner = ContextPruner()
        
        result = pruner.prune_by_role(
            sample_messages,
            roles_to_remove=["assistant"],
        )
        
        for msg in result.kept:
            assert msg.role != "assistant"
    
    def test_prune_empty(self):
        """Test empty message removal."""
        messages = [
            {"role": "user", "content": "Hello"},
            {"role": "assistant", "content": ""},
            {"role": "user", "content": "   "},
            {"role": "assistant", "content": "Hi"},
        ]
        
        pruner = ContextPruner()
        result = pruner.prune_empty(messages)
        
        assert result.kept_count == 2
        assert result.pruned_count == 2
    
    def test_prune_tool_results(self):
        """Test tool result pruning."""
        messages = [
            {"role": "user", "content": "Get weather"},
            {"role": "tool", "content": "x" * 1000},  # Long result
            {"role": "assistant", "content": "Weather is nice"},
        ]
        
        pruner = ContextPruner()
        result = pruner.prune_tool_results(
            messages,
            max_result_length=100,
            truncate_instead=True,
        )
        
        # Tool message should be truncated
        tool_msg = [m for m in result.kept if m.role == "tool"][0]
        assert len(tool_msg.content) <= 115  # 100 + "... [truncated]"


class TestConversationPruner:
    """Tests for ConversationPruner class."""
    
    def test_prune_keeping_turns(self, long_conversation):
        """Test turn-based pruning."""
        pruner = ConversationPruner()
        
        result = pruner.prune_keeping_turns(long_conversation, keep_turns=3)
        
        # Should keep system + 3 turns (6 messages)
        assert result.kept_count <= 7
    
    def test_prune_summarizing_turns(self, long_conversation):
        """Test turn pruning with summarization."""
        def summarizer(contents: list[str]) -> str:
            return f"Summarized {len(contents)} messages"
        
        pruner = ConversationPruner()
        result, summary = pruner.prune_summarizing_turns(
            long_conversation,
            keep_turns=2,
            summarizer=summarizer,
        )
        
        assert result.pruned_count > 0
        if summary:
            assert "Summarized" in summary


# ============================================================================
# Tests for ContextCompressor
# ============================================================================

class TestContextCompressor:
    """Tests for ContextCompressor class."""
    
    def test_creation(self):
        """Test compressor creation."""
        compressor = ContextCompressor()
        
        assert compressor.summarizer is None
        assert compressor.default_compression_ratio == 0.5
    
    def test_compress_already_within_limit(self, sample_messages):
        """Test compression when already within limit."""
        compressor = ContextCompressor()
        
        result = compressor.compress(sample_messages, target_tokens=10000)
        
        assert result.stats.strategy_used == "none_needed"
    
    def test_compress_by_summarization(self, long_conversation):
        """Test summarization compression."""
        compressor = ContextCompressor()
        
        result = compressor.compress(
            long_conversation,
            target_tokens=500,
            method=CompressionMethod.SUMMARIZE,
        )
        
        assert result.stats.strategy_used == "summarize"
    
    def test_compress_by_merging(self, long_conversation):
        """Test merge compression."""
        compressor = ContextCompressor()
        
        result = compressor.compress(
            long_conversation,
            target_tokens=500,
            method=CompressionMethod.MERGE,
        )
        
        assert result.stats.strategy_used == "merge"
    
    def test_compress_by_extraction(self, long_conversation):
        """Test key point extraction compression."""
        compressor = ContextCompressor()
        
        result = compressor.compress(
            long_conversation,
            target_tokens=500,
            method=CompressionMethod.EXTRACT_KEY_POINTS,
        )
        
        assert result.stats.strategy_used == "extract_key_points"
    
    def test_compress_hierarchically(self, long_conversation):
        """Test hierarchical compression."""
        compressor = ContextCompressor()
        
        result = compressor.compress(
            long_conversation,
            target_tokens=500,
            method=CompressionMethod.HIERARCHICAL,
        )
        
        assert result.stats.strategy_used == "hierarchical"
    
    def test_summarize_messages(self, sample_messages):
        """Test message summarization."""
        compressor = ContextCompressor()
        
        summary = compressor.summarize_messages(sample_messages)
        
        assert isinstance(summary, str)
        assert len(summary) > 0
    
    def test_summarize_with_custom_summarizer(self, sample_messages):
        """Test with custom summarizer."""
        def custom_summarizer(contents: list[str]) -> str:
            return f"Custom summary of {len(contents)} items"
        
        compressor = ContextCompressor(summarizer=custom_summarizer)
        summary = compressor.summarize_messages(sample_messages)
        
        assert "Custom summary" in summary
    
    def test_compress_tools(self, sample_tools):
        """Test tool compression."""
        compressor = ContextCompressor()
        
        result = compressor.compress_tools(sample_tools, max_tokens=500)
        
        assert isinstance(result, list)
        assert all(isinstance(t, ToolContext) for t in result)
    
    def test_compress_tools_with_keep_names(self, sample_tools):
        """Test tool compression with required tools."""
        compressor = ContextCompressor()
        
        result = compressor.compress_tools(
            sample_tools,
            max_tokens=500,
            keep_names=["get_weather"],
        )
        
        names = [t.name for t in result]
        assert "get_weather" in names
    
    def test_merge_similar_messages(self):
        """Test similar message merging."""
        messages = [
            {"role": "user", "content": "Hello there friend"},
            {"role": "user", "content": "Hello there buddy"},
            {"role": "assistant", "content": "Hi"},
        ]
        
        compressor = ContextCompressor()
        result = compressor.merge_similar_messages(messages, similarity_threshold=0.5)
        
        assert isinstance(result, CompressionResult)
    
    def test_extract_key_points(self, long_conversation):
        """Test key point extraction."""
        compressor = ContextCompressor()
        
        result = compressor.extract_key_points(
            long_conversation,
            max_points_per_message=2,
        )
        
        assert isinstance(result, CompressionResult)
    
    def test_truncate_messages(self, long_conversation):
        """Test message truncation."""
        compressor = ContextCompressor()
        
        result = compressor.truncate_messages(
            long_conversation,
            max_chars_per_message=50,
        )
        
        for msg in result.messages:
            assert len(msg.content) <= 53  # 50 + "..."


# ============================================================================
# Integration Tests
# ============================================================================

class TestIntegration:
    """Integration tests for the context module."""
    
    def test_full_optimization_pipeline(self, long_conversation):
        """Test complete optimization pipeline."""
        # Configure
        config = OptimizationConfig(
            max_tokens=1000,
            preserve_system=True,
            preserve_recent=3,
            pruning_strategy=PruningStrategy.SMART,
            enable_summarization=True,
        )
        
        # Create optimizer
        optimizer = ContextOptimizer(config=config)
        
        # Optimize
        result = optimizer.optimize(long_conversation)
        
        # Verify
        assert result.stats.optimized_tokens <= config.max_tokens or len(result.messages) <= 5
        assert len(result.messages) > 0
        assert result.stats.operation_time_ms >= 0
    
    def test_optimization_with_tools(self, long_conversation, sample_tools):
        """Test optimization with both messages and tools."""
        config = OptimizationConfig(max_tokens=2000)
        optimizer = ContextOptimizer(config=config)
        
        result, tools = optimizer.optimize_with_tools(
            long_conversation,
            sample_tools,
        )
        
        assert isinstance(result, OptimizationResult)
        assert len(tools) > 0
    
    def test_chained_operations(self, long_conversation):
        """Test chaining pruner and compressor."""
        # First prune
        pruner = ContextPruner()
        prune_result = pruner.prune_by_recency(long_conversation, keep_count=15)
        
        # Then compress
        compressor = ContextCompressor()
        compress_result = compressor.truncate_messages(
            prune_result.kept,
            max_chars_per_message=100,
        )
        
        # Verify reduction
        original_tokens = sum(m.token_count for m in pruner._to_context_messages(long_conversation))
        final_tokens = compress_result.stats.optimized_tokens
        
        assert final_tokens <= original_tokens
    
    def test_context_window_workflow(self):
        """Test complete ContextWindow workflow."""
        # Create window
        window = ContextWindow(max_tokens=1000)
        
        # Add messages
        window.add_message(ContextMessage(role="system", content="You are helpful."))
        window.add_message(ContextMessage(role="user", content="Hello!"))
        window.add_message(ContextMessage(role="assistant", content="Hi there!"))
        
        # Recalculate
        window.recalculate_tokens()
        
        # Convert to list
        messages = window.to_list()
        
        # Optimize
        optimizer = ContextOptimizer()
        result = optimizer.optimize(messages)
        
        # Verify
        assert len(result.messages) == 3
    
    def test_preservation_of_important_messages(self):
        """Test that important messages are preserved."""
        messages = [
            ContextMessage(role="system", content="System prompt", importance=1.0),
            ContextMessage(role="user", content="Low importance", importance=0.1),
            ContextMessage(role="assistant", content="Response", importance=0.2),
            ContextMessage(role="user", content="High importance question", importance=0.9),
            ContextMessage(role="assistant", content="Important answer", importance=0.8),
        ]
        
        config = OptimizationConfig(
            max_tokens=100,
            pruning_strategy=PruningStrategy.IMPORTANCE,
            importance_threshold=0.5,
        )
        optimizer = ContextOptimizer(config=config)
        
        result = optimizer.optimize(messages)
        
        # High importance messages should be preserved
        contents = [m.content for m in result.messages]
        assert "System prompt" in contents or "High importance" in contents


# ============================================================================
# Performance Tests
# ============================================================================

class TestPerformance:
    """Performance tests for the context module."""
    
    def test_large_conversation_optimization(self):
        """Test optimization of large conversation."""
        # Create large conversation (500 messages)
        messages = [{"role": "system", "content": "You are helpful."}]
        for i in range(250):
            messages.append({"role": "user", "content": f"Question {i}: " + "x" * 100})
            messages.append({"role": "assistant", "content": f"Answer {i}: " + "y" * 200})
        
        optimizer = ContextOptimizer(
            config=OptimizationConfig(max_tokens=2000)
        )
        
        start = time.time()
        result = optimizer.optimize(messages)
        elapsed = time.time() - start
        
        # Should complete in reasonable time (< 1 second)
        assert elapsed < 1.0
        assert result.stats.optimized_messages < len(messages)
    
    def test_repeated_optimization(self, long_conversation):
        """Test repeated optimization calls."""
        optimizer = ContextOptimizer()
        
        for _ in range(10):
            result = optimizer.optimize(long_conversation)
            assert result is not None
    
    def test_token_estimation_performance(self):
        """Test token estimation is fast."""
        text = "x" * 10000  # 10K characters
        
        start = time.time()
        for _ in range(1000):
            TokenEstimator.estimate_simple(text)
        elapsed = time.time() - start
        
        # 1000 estimations should be very fast
        assert elapsed < 0.1


# ============================================================================
# Edge Cases
# ============================================================================

class TestEdgeCases:
    """Edge case tests."""
    
    def test_empty_messages(self):
        """Test with empty message list."""
        optimizer = ContextOptimizer()
        result = optimizer.optimize([])
        
        assert len(result.messages) == 0
    
    def test_single_message(self):
        """Test with single message."""
        messages = [{"role": "user", "content": "Hello"}]
        
        optimizer = ContextOptimizer()
        result = optimizer.optimize(messages)
        
        assert len(result.messages) == 1
    
    def test_only_system_messages(self):
        """Test with only system messages."""
        messages = [
            {"role": "system", "content": "Instruction 1"},
            {"role": "system", "content": "Instruction 2"},
        ]
        
        optimizer = ContextOptimizer()
        result = optimizer.optimize(messages)
        
        assert len(result.messages) == 2
    
    def test_very_long_single_message(self):
        """Test with very long single message."""
        messages = [
            {"role": "user", "content": "x" * 100000}  # 100K chars
        ]
        
        compressor = ContextCompressor()
        result = compressor.truncate_messages(messages, max_chars_per_message=1000)
        
        assert len(result.messages[0].content) <= 1003
    
    def test_unicode_content(self):
        """Test with unicode content."""
        messages = [
            {"role": "user", "content": "你好世界 🌍 مرحبا"},
            {"role": "assistant", "content": "Привет! 👋"},
        ]
        
        optimizer = ContextOptimizer()
        result = optimizer.optimize(messages)
        
        assert len(result.messages) == 2
    
    def test_special_characters(self):
        """Test with special characters."""
        messages = [
            {"role": "user", "content": "Test <script>alert('xss')</script>"},
            {"role": "assistant", "content": "Response with\nnewlines\tand\ttabs"},
        ]
        
        optimizer = ContextOptimizer()
        result = optimizer.optimize(messages)
        
        assert len(result.messages) == 2
    
    def test_zero_max_tokens(self):
        """Test with zero max tokens."""
        with pytest.raises(ValueError):
            OptimizationConfig(max_tokens=0)
    
    def test_preserve_recent_larger_than_messages(self, sample_messages):
        """Test when preserve_recent is larger than message count."""
        config = OptimizationConfig(
            max_tokens=100,
            preserve_recent=100,  # More than message count
        )
        optimizer = ContextOptimizer(config=config)
        
        result = optimizer.optimize(sample_messages)
        
        # Should handle gracefully
        assert len(result.messages) > 0


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
