"""Tests for cost optimization module."""

from __future__ import annotations

import pytest
from datetime import datetime, timedelta, timezone
from unittest.mock import MagicMock

# Budget module tests
from multi_agent_base.cost.budget import (
    BudgetManager,
    BudgetConfig,
    BudgetAlert,
    AlertSeverity,
    BudgetStatus,
    BudgetPeriod,
    BudgetLimit,
    BudgetAction,
    MemoryBudgetStorage,
)

# Optimization module tests
from multi_agent_base.cost.optimization import (
    ModelSelector,
    ModelProfile,
    SelectionCriteria,
    SelectionResult,
    TaskComplexity,
    OptimizationGoal,
    CostEstimator,
    CostEstimate,
    DEFAULT_MODEL_PROFILES,
)

# Analysis module tests
from multi_agent_base.cost.analysis import (
    CostAnalyzer,
    CostDataPoint,
    CostTrend,
    CostReport,
    CostAnomaly,
    ModelCostBreakdown,
    OperationCostBreakdown,
    OptimizationRecommendation,
    TimeGranularity,
    TrendDirection,
)


# =============================================================================
# Budget Module Tests
# =============================================================================


class TestAlertSeverity:
    """Tests for AlertSeverity enum."""
    
    def test_levels_exist(self):
        """Test all alert levels exist."""
        assert AlertSeverity.INFO
        assert AlertSeverity.WARNING
        assert AlertSeverity.CRITICAL
    
    def test_level_values(self):
        """Test level values."""
        assert AlertSeverity.INFO.value == "info"
        assert AlertSeverity.WARNING.value == "warning"
        assert AlertSeverity.CRITICAL.value == "critical"


class TestBudgetPeriod:
    """Tests for BudgetPeriod enum."""
    
    def test_periods_exist(self):
        """Test all periods exist."""
        assert BudgetPeriod.HOURLY
        assert BudgetPeriod.DAILY
        assert BudgetPeriod.WEEKLY
        assert BudgetPeriod.MONTHLY
        assert BudgetPeriod.TOTAL
    
    def test_period_values(self):
        """Test period values."""
        assert BudgetPeriod.HOURLY.value == "hourly"
        assert BudgetPeriod.DAILY.value == "daily"


class TestBudgetAction:
    """Tests for BudgetAction enum."""
    
    def test_actions_exist(self):
        """Test all actions exist."""
        assert BudgetAction.ALLOW
        assert BudgetAction.WARN
        assert BudgetAction.BLOCK
        assert BudgetAction.DOWNGRADE


class TestBudgetLimit:
    """Tests for BudgetLimit dataclass."""
    
    def test_basic_limit(self):
        """Test basic budget limit."""
        limit = BudgetLimit(
            name="daily",
            amount=100.0,
            period=BudgetPeriod.DAILY,
        )
        assert limit.name == "daily"
        assert limit.amount == 100.0
        assert limit.period == BudgetPeriod.DAILY
        assert limit.action == BudgetAction.BLOCK
    
    def test_limit_with_all_fields(self):
        """Test limit with all fields."""
        limit = BudgetLimit(
            name="production",
            amount=500.0,
            period=BudgetPeriod.MONTHLY,
            action=BudgetAction.WARN,
            alert_thresholds=[0.5, 0.8, 0.95],
            scope="global",
        )
        assert limit.scope == "global"
        assert limit.alert_thresholds == [0.5, 0.8, 0.95]
    
    def test_limit_to_dict(self):
        """Test limit serialization."""
        limit = BudgetLimit(name="test", amount=100.0, period=BudgetPeriod.DAILY)
        data = limit.to_dict()
        assert data["name"] == "test"
        assert data["amount"] == 100.0
        assert data["period"] == "daily"


class TestBudgetAlert:
    """Tests for BudgetAlert dataclass."""
    
    def test_alert_creation(self):
        """Test alert creation."""
        alert = BudgetAlert(
            limit_name="daily",
            severity=AlertSeverity.WARNING,
            message="Budget at 80%",
            current_usage=80.0,
            limit_amount=100.0,
            percentage=80.0,
        )
        assert alert.severity == AlertSeverity.WARNING
        assert alert.percentage == 80.0
    
    def test_alert_to_dict(self):
        """Test alert serialization."""
        alert = BudgetAlert(
            limit_name="test",
            severity=AlertSeverity.WARNING,
            message="Test",
            current_usage=50.0,
            limit_amount=100.0,
            percentage=50.0,
        )
        data = alert.to_dict()
        assert data["severity"] == "warning"
        assert data["limit_name"] == "test"


class TestBudgetStatus:
    """Tests for BudgetStatus dataclass."""
    
    def test_status_creation(self):
        """Test status creation."""
        status = BudgetStatus(
            limit_name="default",
            current_usage=50.0,
            limit_amount=100.0,
            remaining=50.0,
            percentage_used=50.0,
            period_start="2024-01-01T00:00:00Z",
            period_end="2024-01-02T00:00:00Z",
            is_exceeded=False,
        )
        assert status.remaining == 50.0
        assert not status.is_exceeded
    
    def test_exceeded_status(self):
        """Test exceeded budget status."""
        status = BudgetStatus(
            limit_name="default",
            current_usage=120.0,
            limit_amount=100.0,
            remaining=0.0,
            percentage_used=120.0,
            period_start="2024-01-01T00:00:00Z",
            period_end="2024-01-02T00:00:00Z",
            is_exceeded=True,
            action=BudgetAction.BLOCK,
        )
        assert status.is_exceeded
        assert status.action == BudgetAction.BLOCK


class TestMemoryBudgetStorage:
    """Tests for MemoryBudgetStorage."""
    
    def test_record_and_get_usage(self):
        """Test recording and retrieving usage."""
        storage = MemoryBudgetStorage()
        now = datetime.now(timezone.utc)
        
        storage.record_usage("global", 10.0, now)
        storage.record_usage("global", 15.0, now)
        
        usage = storage.get_usage(
            "global",
            now - timedelta(hours=1),
            now + timedelta(hours=1),
        )
        assert usage == 25.0
    
    def test_clear_all(self):
        """Test clearing all records."""
        storage = MemoryBudgetStorage()
        now = datetime.now(timezone.utc)
        
        storage.record_usage("global", 10.0, now)
        storage.clear()
        
        assert len(storage.records) == 0
    
    def test_clear_scope(self):
        """Test clearing specific scope."""
        storage = MemoryBudgetStorage()
        now = datetime.now(timezone.utc)
        
        storage.record_usage("scope1", 10.0, now)
        storage.record_usage("scope2", 20.0, now)
        storage.clear("scope1")
        
        assert len(storage.records) == 1
        assert storage.records[0]["scope"] == "scope2"


class TestBudgetManager:
    """Tests for BudgetManager class."""
    
    def test_basic_initialization(self):
        """Test basic initialization."""
        manager = BudgetManager()
        assert manager is not None
    
    def test_add_limit(self):
        """Test adding a limit."""
        manager = BudgetManager()
        limit = BudgetLimit(name="test", amount=100.0, period=BudgetPeriod.DAILY)
        manager.add_limit(limit)
        
        assert manager.get_limit("test") is not None
        assert manager.get_limit("test").amount == 100.0
    
    def test_remove_limit(self):
        """Test removing a limit."""
        manager = BudgetManager()
        limit = BudgetLimit(name="test", amount=100.0, period=BudgetPeriod.DAILY)
        manager.add_limit(limit)
        
        result = manager.remove_limit("test")
        assert result is True
        assert manager.get_limit("test") is None
    
    def test_record_usage(self):
        """Test recording usage."""
        manager = BudgetManager()
        limit = BudgetLimit(name="test", amount=100.0, period=BudgetPeriod.DAILY)
        manager.add_limit(limit)
        
        alerts = manager.record_usage("global", 25.0)
        
        status = manager.check_budget("global")
        assert status.current_usage == 25.0
    
    def test_usage_triggers_alerts(self):
        """Test that usage triggers alerts."""
        manager = BudgetManager()
        limit = BudgetLimit(
            name="test",
            amount=100.0,
            period=BudgetPeriod.DAILY,
            alert_thresholds=[0.5, 0.8, 0.95],
        )
        manager.add_limit(limit)
        
        # First recording - below thresholds
        alerts = manager.record_usage("global", 40.0)
        assert len(alerts) == 0
        
        # Cross 50% threshold
        alerts = manager.record_usage("global", 15.0)
        assert len(alerts) > 0
    
    def test_check_budget(self):
        """Test budget check."""
        manager = BudgetManager()
        limit = BudgetLimit(
            name="test",
            amount=100.0,
            period=BudgetPeriod.DAILY,
            action=BudgetAction.BLOCK,
        )
        manager.add_limit(limit)
        
        # Should pass
        status = manager.check_budget("global", 50.0)
        assert status.action == BudgetAction.ALLOW
        
        # Record usage
        manager.record_usage("global", 80.0)
        
        # Should fail
        status = manager.check_budget("global", 30.0)
        assert status.action == BudgetAction.BLOCK
    
    def test_get_status(self):
        """Test getting budget status."""
        manager = BudgetManager()
        limit = BudgetLimit(name="test", amount=100.0, period=BudgetPeriod.DAILY)
        manager.add_limit(limit)
        
        manager.record_usage("global", 25.0)
        status = manager.check_budget("global")
        
        assert status.current_usage == 25.0
        assert status.remaining == 75.0
    
    def test_alert_handler_callback(self):
        """Test alert handler callback."""
        manager = BudgetManager()
        limit = BudgetLimit(
            name="test",
            amount=100.0,
            period=BudgetPeriod.DAILY,
            alert_thresholds=[0.5],
        )
        manager.add_limit(limit)
        
        callback_called = []
        
        def on_alert(alert):
            callback_called.append(alert)
        
        manager.add_alert_handler(on_alert)
        manager.record_usage("global", 60.0)
        
        assert len(callback_called) > 0


class TestBudgetConfig:
    """Tests for BudgetConfig dataclass."""
    
    def test_config_creation(self):
        """Test config creation."""
        config = BudgetConfig(
            limits=[
                {"name": "daily", "amount": 100.0, "period": "daily"},
            ],
            default_action=BudgetAction.WARN,
        )
        assert len(config.limits) == 1
    
    def test_create_manager_from_config(self):
        """Test creating manager from config."""
        config = BudgetConfig(
            limits=[
                {"name": "daily", "amount": 100.0, "period": "daily"},
                {"name": "monthly", "amount": 500.0, "period": "monthly"},
            ],
        )
        manager = config.create_manager()
        
        assert manager.get_limit("daily") is not None
        assert manager.get_limit("monthly") is not None


# =============================================================================
# Optimization Module Tests
# =============================================================================


class TestTaskComplexity:
    """Tests for TaskComplexity enum."""
    
    def test_complexities_exist(self):
        """Test all complexity levels exist."""
        assert TaskComplexity.SIMPLE
        assert TaskComplexity.MODERATE
        assert TaskComplexity.COMPLEX
        assert TaskComplexity.EXPERT


class TestOptimizationGoal:
    """Tests for OptimizationGoal enum."""
    
    def test_goals_exist(self):
        """Test all goals exist."""
        assert OptimizationGoal.COST
        assert OptimizationGoal.QUALITY
        assert OptimizationGoal.BALANCED
        assert OptimizationGoal.LATENCY
        assert OptimizationGoal.THROUGHPUT


class TestModelProfile:
    """Tests for ModelProfile dataclass."""
    
    def test_basic_profile(self):
        """Test basic model profile."""
        profile = ModelProfile(
            name="test-model",
            provider="test",
            input_cost=1.0,
            output_cost=2.0,
            quality_score=80,
            latency_ms=500,
            max_tokens=100000,
        )
        assert profile.name == "test-model"
        assert profile.avg_cost == 1.5
    
    def test_cost_efficiency(self):
        """Test cost efficiency calculation."""
        profile = ModelProfile(
            name="test",
            provider="test",
            input_cost=0.5,
            output_cost=1.5,
            quality_score=80,
            latency_ms=300,
            max_tokens=100000,
        )
        # avg_cost = 1.0, quality = 80, efficiency = 80
        assert profile.cost_efficiency == 80.0
    
    def test_estimate_cost(self):
        """Test cost estimation."""
        profile = ModelProfile(
            name="test",
            provider="test",
            input_cost=1.0,  # per 1M
            output_cost=2.0,  # per 1M
            quality_score=80,
            latency_ms=300,
            max_tokens=100000,
        )
        cost = profile.estimate_cost(1000, 500)
        # (1000/1M)*1.0 + (500/1M)*2.0 = 0.001 + 0.001 = 0.002
        assert abs(cost - 0.002) < 0.0001
    
    def test_to_dict(self):
        """Test serialization."""
        profile = ModelProfile(
            name="test",
            provider="test",
            input_cost=1.0,
            output_cost=2.0,
            quality_score=80,
            latency_ms=300,
            max_tokens=100000,
            capabilities=["vision"],
        )
        data = profile.to_dict()
        assert data["name"] == "test"
        assert "vision" in data["capabilities"]


class TestSelectionCriteria:
    """Tests for SelectionCriteria dataclass."""
    
    def test_default_criteria(self):
        """Test default criteria."""
        criteria = SelectionCriteria()
        assert criteria.goal == OptimizationGoal.BALANCED
        assert criteria.min_quality == 0.0
    
    def test_custom_criteria(self):
        """Test custom criteria."""
        criteria = SelectionCriteria(
            goal=OptimizationGoal.COST,
            min_quality=70.0,
            max_cost_per_1m=5.0,
            required_capabilities=["vision"],
        )
        assert criteria.goal == OptimizationGoal.COST
        assert criteria.min_quality == 70.0


class TestSelectionResult:
    """Tests for SelectionResult dataclass."""
    
    def test_result_creation(self):
        """Test result creation."""
        profile = ModelProfile(
            name="test",
            provider="test",
            input_cost=1.0,
            output_cost=2.0,
            quality_score=80,
            latency_ms=300,
            max_tokens=100000,
        )
        result = SelectionResult(
            selected_model=profile,
            score=85.0,
            reason="Best match",
        )
        assert result.selected_model.name == "test"
        assert result.score == 85.0


class TestModelSelector:
    """Tests for ModelSelector class."""
    
    def test_initialization(self):
        """Test initialization with default profiles."""
        selector = ModelSelector()
        assert len(selector.profiles) > 0
    
    def test_initialization_custom_profiles(self):
        """Test initialization with custom profiles."""
        profiles = [
            ModelProfile(
                name="custom",
                provider="custom",
                input_cost=1.0,
                output_cost=2.0,
                quality_score=80,
                latency_ms=300,
                max_tokens=100000,
            )
        ]
        selector = ModelSelector(profiles=profiles)
        assert len(selector.profiles) == 1
    
    def test_add_profile(self):
        """Test adding a profile."""
        selector = ModelSelector()
        initial_count = len(selector.profiles)
        profile = ModelProfile(
            name="new",
            provider="test",
            input_cost=1.0,
            output_cost=2.0,
            quality_score=80,
            latency_ms=300,
            max_tokens=100000,
        )
        selector.add_profile(profile)
        assert len(selector.profiles) == initial_count + 1
    
    def test_remove_profile(self):
        """Test removing a profile."""
        selector = ModelSelector()
        initial_count = len(selector.profiles)
        result = selector.remove_profile("gpt-4o")
        assert result is True
        assert len(selector.profiles) == initial_count - 1
    
    def test_get_profile(self):
        """Test getting a profile."""
        selector = ModelSelector()
        profile = selector.get_profile("gpt-4o")
        assert profile is not None
        assert profile.name == "gpt-4o"
    
    def test_select_cost_optimization(self):
        """Test selection with cost optimization."""
        selector = ModelSelector()
        result = selector.select(SelectionCriteria(
            goal=OptimizationGoal.COST,
        ))
        assert result.selected_model is not None
        # Should be a cheaper model
        assert result.selected_model.avg_cost < 10.0
    
    def test_select_quality_optimization(self):
        """Test selection with quality optimization."""
        selector = ModelSelector()
        result = selector.select(SelectionCriteria(
            goal=OptimizationGoal.QUALITY,
        ))
        assert result.selected_model is not None
        # Should be a high-quality model
        assert result.selected_model.quality_score >= 90
    
    def test_select_with_min_quality(self):
        """Test selection with minimum quality."""
        selector = ModelSelector()
        result = selector.select(SelectionCriteria(
            goal=OptimizationGoal.COST,
            min_quality=80.0,
        ))
        assert result.selected_model.quality_score >= 80.0
    
    def test_select_with_required_capabilities(self):
        """Test selection with required capabilities."""
        selector = ModelSelector()
        result = selector.select(SelectionCriteria(
            required_capabilities=["vision"],
        ))
        assert "vision" in result.selected_model.capabilities
    
    def test_select_with_max_latency(self):
        """Test selection with max latency."""
        selector = ModelSelector()
        result = selector.select(SelectionCriteria(
            max_latency_ms=400,
        ))
        assert result.selected_model.latency_ms <= 400
    
    def test_select_for_budget(self):
        """Test budget-based selection."""
        selector = ModelSelector()
        result = selector.select_for_budget(
            budget=0.10,
            estimated_tokens=100000,
            min_quality=70.0,
        )
        assert result.selected_model is not None
    
    def test_select_for_complexity(self):
        """Test complexity-based selection."""
        selector = ModelSelector()
        
        # Simple task
        simple_result = selector.select_for_complexity(TaskComplexity.SIMPLE)
        
        # Expert task
        expert_result = selector.select_for_complexity(TaskComplexity.EXPERT)
        
        # Expert should have higher quality
        assert expert_result.selected_model.quality_score >= simple_result.selected_model.quality_score
    
    def test_compare_models(self):
        """Test model comparison."""
        selector = ModelSelector()
        comparisons = selector.compare_models(
            model_names=["gpt-4o", "gpt-4o-mini"],
            input_tokens=1000,
            output_tokens=500,
        )
        assert len(comparisons) == 2
        assert "estimated_cost" in comparisons[0]
    
    def test_alternatives_in_result(self):
        """Test alternatives are provided."""
        selector = ModelSelector()
        result = selector.select()
        assert len(result.alternatives) > 0


class TestCostEstimator:
    """Tests for CostEstimator class."""
    
    def test_initialization(self):
        """Test initialization."""
        estimator = CostEstimator()
        assert estimator is not None
    
    def test_estimate_tokens(self):
        """Test token estimation."""
        estimator = CostEstimator(chars_per_token=4.0)
        tokens = estimator.estimate_tokens("Hello, world!")  # 13 chars
        assert tokens == 3
    
    def test_estimate_with_text(self):
        """Test cost estimation with text."""
        estimator = CostEstimator()
        estimate = estimator.estimate(
            model="gpt-4o",
            input_text="Hello, world!",
            expected_output_tokens=500,
        )
        assert estimate.model == "gpt-4o"
        assert estimate.estimated_cost > 0
    
    def test_estimate_with_tokens(self):
        """Test cost estimation with token count."""
        estimator = CostEstimator()
        estimate = estimator.estimate(
            model="gpt-4o",
            input_tokens=1000,
            expected_output_tokens=500,
        )
        assert estimate.input_tokens == 1000
        assert estimate.output_tokens == 500
    
    def test_estimate_batch(self):
        """Test batch estimation."""
        estimator = CostEstimator()
        items = ["Item 1", "Item 2", "Item 3"]
        estimate = estimator.estimate_batch(
            model="gpt-4o",
            items=items,
            expected_output_per_item=100,
        )
        assert estimate.output_tokens == 300
    
    def test_compare_costs(self):
        """Test cost comparison."""
        estimator = CostEstimator()
        estimates = estimator.compare_costs(
            input_tokens=1000,
            output_tokens=500,
            models=["gpt-4o", "gpt-4o-mini"],
        )
        assert len(estimates) == 2
        # Should be sorted by cost
        assert estimates[0].estimated_cost <= estimates[1].estimated_cost
    
    def test_estimate_unknown_model(self):
        """Test estimation for unknown model."""
        estimator = CostEstimator()
        estimate = estimator.estimate(
            model="unknown-model",
            input_tokens=1000,
            expected_output_tokens=500,
        )
        assert estimate.estimated_cost > 0


class TestCostEstimate:
    """Tests for CostEstimate dataclass."""
    
    def test_estimate_creation(self):
        """Test estimate creation."""
        estimate = CostEstimate(
            model="gpt-4o",
            input_tokens=1000,
            output_tokens=500,
            estimated_cost=0.01,
            confidence=0.95,
        )
        assert estimate.model == "gpt-4o"
        assert estimate.confidence == 0.95
    
    def test_estimate_to_dict(self):
        """Test serialization."""
        estimate = CostEstimate(
            model="gpt-4o",
            input_tokens=1000,
            output_tokens=500,
            estimated_cost=0.01,
            confidence=0.95,
            breakdown={"input_cost": 0.003, "output_cost": 0.007},
        )
        data = estimate.to_dict()
        assert data["model"] == "gpt-4o"
        assert "breakdown" in data


class TestDefaultModelProfiles:
    """Tests for default model profiles."""
    
    def test_profiles_exist(self):
        """Test default profiles exist."""
        assert len(DEFAULT_MODEL_PROFILES) > 0
    
    def test_profiles_have_required_fields(self):
        """Test profiles have required fields."""
        for profile in DEFAULT_MODEL_PROFILES:
            assert profile.name
            assert profile.provider
            assert profile.input_cost >= 0
            assert profile.output_cost >= 0
            assert profile.quality_score >= 0
            assert profile.latency_ms >= 0
            assert profile.max_tokens > 0
    
    def test_major_models_included(self):
        """Test major models are included."""
        names = [p.name for p in DEFAULT_MODEL_PROFILES]
        assert "gpt-4o" in names
        assert "gpt-4o-mini" in names
        assert "claude-3-5-sonnet-20241022" in names


# =============================================================================
# Analysis Module Tests
# =============================================================================


class TestTimeGranularity:
    """Tests for TimeGranularity enum."""
    
    def test_granularities_exist(self):
        """Test all granularities exist."""
        assert TimeGranularity.HOURLY
        assert TimeGranularity.DAILY
        assert TimeGranularity.WEEKLY
        assert TimeGranularity.MONTHLY


class TestTrendDirection:
    """Tests for TrendDirection enum."""
    
    def test_directions_exist(self):
        """Test all directions exist."""
        assert TrendDirection.INCREASING
        assert TrendDirection.DECREASING
        assert TrendDirection.STABLE


class TestCostDataPoint:
    """Tests for CostDataPoint dataclass."""
    
    def test_basic_data_point(self):
        """Test basic data point creation."""
        now = datetime.now(timezone.utc)
        point = CostDataPoint(
            timestamp=now,
            cost=0.05,
            model="gpt-4o",
            tokens_input=1000,
            tokens_output=500,
        )
        assert point.cost == 0.05
        assert point.model == "gpt-4o"
    
    def test_data_point_to_dict(self):
        """Test serialization."""
        now = datetime.now(timezone.utc)
        point = CostDataPoint(
            timestamp=now,
            cost=0.05,
            model="gpt-4o",
        )
        data = point.to_dict()
        assert data["cost"] == 0.05
        assert "timestamp" in data


class TestCostTrend:
    """Tests for CostTrend dataclass."""
    
    def test_trend_creation(self):
        """Test trend creation."""
        now = datetime.now(timezone.utc)
        trend = CostTrend(
            direction=TrendDirection.INCREASING,
            change_percent=25.0,
            period_start=now - timedelta(days=7),
            period_end=now,
            avg_daily_cost=10.0,
            projected_cost=350.0,
        )
        assert trend.direction == TrendDirection.INCREASING
        assert trend.change_percent == 25.0
    
    def test_trend_to_dict(self):
        """Test serialization."""
        now = datetime.now(timezone.utc)
        trend = CostTrend(
            direction=TrendDirection.STABLE,
            change_percent=0.0,
            period_start=now - timedelta(days=7),
            period_end=now,
            avg_daily_cost=10.0,
            projected_cost=300.0,
        )
        data = trend.to_dict()
        assert data["direction"] == "stable"


class TestModelCostBreakdown:
    """Tests for ModelCostBreakdown dataclass."""
    
    def test_breakdown_creation(self):
        """Test breakdown creation."""
        breakdown = ModelCostBreakdown(
            model="gpt-4o",
            total_cost=100.0,
            request_count=1000,
            avg_cost_per_request=0.10,
            total_input_tokens=1000000,
            total_output_tokens=500000,
            percentage_of_total=50.0,
        )
        assert breakdown.model == "gpt-4o"
        assert breakdown.percentage_of_total == 50.0


class TestOperationCostBreakdown:
    """Tests for OperationCostBreakdown dataclass."""
    
    def test_breakdown_creation(self):
        """Test breakdown creation."""
        breakdown = OperationCostBreakdown(
            operation="chat",
            total_cost=80.0,
            request_count=800,
            avg_cost_per_request=0.10,
            percentage_of_total=40.0,
            top_models=["gpt-4o", "gpt-4o-mini"],
        )
        assert breakdown.operation == "chat"
        assert len(breakdown.top_models) == 2


class TestCostAnomaly:
    """Tests for CostAnomaly dataclass."""
    
    def test_anomaly_creation(self):
        """Test anomaly creation."""
        now = datetime.now(timezone.utc)
        anomaly = CostAnomaly(
            timestamp=now,
            expected_cost=0.05,
            actual_cost=0.25,
            deviation_percent=400.0,
            severity="high",
            description="Cost 400% higher than average",
        )
        assert anomaly.severity == "high"
        assert anomaly.deviation_percent == 400.0


class TestOptimizationRecommendation:
    """Tests for OptimizationRecommendation dataclass."""
    
    def test_recommendation_creation(self):
        """Test recommendation creation."""
        rec = OptimizationRecommendation(
            title="Switch to smaller model",
            description="Consider using gpt-4o-mini",
            potential_savings=50.0,
            implementation_effort="low",
            priority=1,
            category="model_selection",
        )
        assert rec.priority == 1
        assert rec.potential_savings == 50.0


class TestCostReport:
    """Tests for CostReport dataclass."""
    
    def test_report_creation(self):
        """Test report creation."""
        now = datetime.now(timezone.utc)
        report = CostReport(
            period_start=now - timedelta(days=30),
            period_end=now,
            total_cost=500.0,
            total_requests=5000,
        )
        assert report.total_cost == 500.0
        assert report.avg_cost_per_request == 0.10
    
    def test_report_avg_daily_cost(self):
        """Test average daily cost calculation."""
        now = datetime.now(timezone.utc)
        report = CostReport(
            period_start=now - timedelta(days=10),
            period_end=now,
            total_cost=100.0,
            total_requests=1000,
        )
        assert abs(report.avg_daily_cost - 10.0) < 0.1
    
    def test_report_to_markdown(self):
        """Test markdown generation."""
        now = datetime.now(timezone.utc)
        report = CostReport(
            period_start=now - timedelta(days=7),
            period_end=now,
            total_cost=100.0,
            total_requests=1000,
        )
        md = report.to_markdown()
        assert "Cost Analysis Report" in md
        assert "$100.00" in md


class TestCostAnalyzer:
    """Tests for CostAnalyzer class."""
    
    def test_initialization(self):
        """Test initialization."""
        analyzer = CostAnalyzer()
        assert analyzer is not None
    
    def test_add_data_point(self):
        """Test adding data points."""
        analyzer = CostAnalyzer()
        point = CostDataPoint(
            timestamp=datetime.now(timezone.utc),
            cost=0.05,
            model="gpt-4o",
        )
        analyzer.add_data_point(point)
        assert len(analyzer.data_points) == 1
    
    def test_add_multiple_data_points(self):
        """Test adding multiple data points."""
        analyzer = CostAnalyzer()
        points = [
            CostDataPoint(
                timestamp=datetime.now(timezone.utc),
                cost=0.05 * i,
                model="gpt-4o",
            )
            for i in range(5)
        ]
        analyzer.add_data_points(points)
        assert len(analyzer.data_points) == 5
    
    def test_clear_data(self):
        """Test clearing data."""
        analyzer = CostAnalyzer()
        analyzer.add_data_point(CostDataPoint(
            timestamp=datetime.now(timezone.utc),
            cost=0.05,
            model="gpt-4o",
        ))
        analyzer.clear()
        assert len(analyzer.data_points) == 0
    
    def test_calculate_total(self):
        """Test total calculation."""
        analyzer = CostAnalyzer()
        now = datetime.now(timezone.utc)
        
        for i in range(10):
            analyzer.add_data_point(CostDataPoint(
                timestamp=now,
                cost=0.10,
                model="gpt-4o",
            ))
        
        total = analyzer.calculate_total()
        assert total == 1.0
    
    def test_calculate_total_by_model(self):
        """Test total by model."""
        analyzer = CostAnalyzer()
        now = datetime.now(timezone.utc)
        
        for i in range(5):
            analyzer.add_data_point(CostDataPoint(
                timestamp=now,
                cost=0.10,
                model="gpt-4o",
            ))
            analyzer.add_data_point(CostDataPoint(
                timestamp=now,
                cost=0.05,
                model="gpt-4o-mini",
            ))
        
        total_gpt4 = analyzer.calculate_total(model="gpt-4o")
        total_mini = analyzer.calculate_total(model="gpt-4o-mini")
        
        assert total_gpt4 == 0.50
        assert total_mini == 0.25
    
    def test_analyze_trend(self):
        """Test trend analysis."""
        analyzer = CostAnalyzer()
        now = datetime.now(timezone.utc)
        
        # Add increasing costs over time
        for i in range(10):
            analyzer.add_data_point(CostDataPoint(
                timestamp=now - timedelta(days=9-i),
                cost=0.10 + (i * 0.05),
                model="gpt-4o",
            ))
        
        trend = analyzer.analyze_trend()
        assert trend is not None
        assert trend.direction == TrendDirection.INCREASING
    
    def test_breakdown_by_model(self):
        """Test model breakdown."""
        analyzer = CostAnalyzer()
        now = datetime.now(timezone.utc)
        
        for i in range(10):
            analyzer.add_data_point(CostDataPoint(
                timestamp=now,
                cost=0.10,
                model="gpt-4o",
                tokens_input=1000,
                tokens_output=500,
            ))
        
        for i in range(5):
            analyzer.add_data_point(CostDataPoint(
                timestamp=now,
                cost=0.02,
                model="gpt-4o-mini",
                tokens_input=1000,
                tokens_output=500,
            ))
        
        breakdown = analyzer.breakdown_by_model()
        assert len(breakdown) == 2
        assert breakdown[0].model == "gpt-4o"  # Higher cost
    
    def test_breakdown_by_operation(self):
        """Test operation breakdown."""
        analyzer = CostAnalyzer()
        now = datetime.now(timezone.utc)
        
        for i in range(10):
            analyzer.add_data_point(CostDataPoint(
                timestamp=now,
                cost=0.10,
                model="gpt-4o",
                operation="chat",
            ))
        
        for i in range(5):
            analyzer.add_data_point(CostDataPoint(
                timestamp=now,
                cost=0.05,
                model="gpt-4o",
                operation="embedding",
            ))
        
        breakdown = analyzer.breakdown_by_operation()
        assert len(breakdown) == 2
    
    def test_detect_anomalies(self):
        """Test anomaly detection."""
        analyzer = CostAnalyzer(anomaly_threshold=2.0)
        now = datetime.now(timezone.utc)
        
        # Add normal costs
        for i in range(20):
            analyzer.add_data_point(CostDataPoint(
                timestamp=now - timedelta(hours=20-i),
                cost=0.05,
                model="gpt-4o",
            ))
        
        # Add anomaly
        analyzer.add_data_point(CostDataPoint(
            timestamp=now,
            cost=0.50,  # 10x normal
            model="gpt-4o",
        ))
        
        anomalies = analyzer.detect_anomalies()
        assert len(anomalies) > 0
        assert anomalies[0].severity in ["high", "medium", "low"]
    
    def test_generate_recommendations(self):
        """Test recommendation generation."""
        analyzer = CostAnalyzer()
        
        model_breakdown = [
            ModelCostBreakdown(
                model="gpt-4o",
                total_cost=200.0,
                request_count=1000,
                avg_cost_per_request=0.20,
                total_input_tokens=1000000,
                total_output_tokens=500000,
                percentage_of_total=80.0,
            )
        ]
        
        op_breakdown = [
            OperationCostBreakdown(
                operation="chat",
                total_cost=150.0,
                request_count=500,
                avg_cost_per_request=0.30,
                percentage_of_total=60.0,
            )
        ]
        
        recs = analyzer.generate_recommendations(model_breakdown, op_breakdown)
        assert len(recs) > 0
    
    def test_generate_report(self):
        """Test report generation."""
        analyzer = CostAnalyzer()
        now = datetime.now(timezone.utc)
        
        for i in range(50):
            analyzer.add_data_point(CostDataPoint(
                timestamp=now - timedelta(hours=50-i),
                cost=0.05 + (i % 5) * 0.01,
                model="gpt-4o" if i % 2 == 0 else "gpt-4o-mini",
                tokens_input=1000,
                tokens_output=500,
                operation="chat" if i % 3 == 0 else "analysis",
            ))
        
        report = analyzer.generate_report()
        
        assert report.total_cost > 0
        assert report.total_requests == 50
        assert len(report.model_breakdown) > 0
        assert len(report.operation_breakdown) > 0
    
    def test_get_time_series(self):
        """Test time series data."""
        analyzer = CostAnalyzer()
        now = datetime.now(timezone.utc)
        
        for i in range(10):
            analyzer.add_data_point(CostDataPoint(
                timestamp=now - timedelta(days=i),
                cost=0.10,
                model="gpt-4o",
            ))
        
        series = analyzer.get_time_series(TimeGranularity.DAILY)
        assert len(series) > 0
        assert "cost" in series[0]
        assert "requests" in series[0]
    
    def test_empty_report(self):
        """Test report with no data."""
        analyzer = CostAnalyzer()
        report = analyzer.generate_report()
        
        assert report.total_cost == 0.0
        assert report.total_requests == 0


# =============================================================================
# Integration Tests
# =============================================================================


class TestCostOptimizationIntegration:
    """Integration tests for cost optimization."""
    
    def test_selector_with_analyzer(self):
        """Test using selector with analyzer data."""
        # Create analyzer with data
        analyzer = CostAnalyzer()
        now = datetime.now(timezone.utc)
        
        for i in range(20):
            analyzer.add_data_point(CostDataPoint(
                timestamp=now - timedelta(hours=i),
                cost=0.15,
                model="gpt-4o",
                operation="chat",
            ))
        
        # Get breakdown
        breakdown = analyzer.breakdown_by_model()
        
        # Use selector to find cheaper alternative
        selector = ModelSelector()
        result = selector.select(SelectionCriteria(
            goal=OptimizationGoal.COST,
            min_quality=70.0,
        ))
        
        # Verify selection
        assert result.selected_model.avg_cost < 10.0
    
    def test_budget_with_estimator(self):
        """Test budget management with cost estimation."""
        # Create budget
        manager = BudgetManager()
        manager.add_limit(BudgetLimit(
            name="test",
            amount=1.0,  # $1 budget
            period=BudgetPeriod.DAILY,
            action=BudgetAction.BLOCK,
        ))
        
        # Estimate cost
        estimator = CostEstimator()
        estimate = estimator.estimate(
            model="gpt-4o",
            input_tokens=10000,
            expected_output_tokens=5000,
        )
        
        # Check if within budget
        status = manager.check_budget("global", estimate.estimated_cost)
        assert status.action == BudgetAction.ALLOW  # Should be allowed initially
    
    def test_full_workflow(self):
        """Test complete cost optimization workflow."""
        # 1. Select optimal model
        selector = ModelSelector()
        selection = selector.select_for_complexity(TaskComplexity.MODERATE)
        
        # 2. Estimate cost
        estimator = CostEstimator(selector=selector)
        estimate = estimator.estimate(
            model=selection.selected_model.name,
            input_text="What is machine learning?",
            expected_output_tokens=500,
        )
        
        # 3. Check budget
        manager = BudgetManager()
        manager.add_limit(BudgetLimit(
            name="default",
            amount=10.0,
            period=BudgetPeriod.DAILY,
        ))
        
        status = manager.check_budget("global", estimate.estimated_cost)
        assert status.action == BudgetAction.ALLOW
        
        # 4. Record usage
        manager.record_usage("global", estimate.estimated_cost)
        
        # 5. Track for analysis
        analyzer = CostAnalyzer()
        analyzer.add_data_point(CostDataPoint(
            timestamp=datetime.now(timezone.utc),
            cost=estimate.estimated_cost,
            model=selection.selected_model.name,
            tokens_input=estimate.input_tokens,
            tokens_output=estimate.output_tokens,
        ))
        
        # 6. Generate report
        report = analyzer.generate_report()
        assert report.total_cost > 0


class TestEdgeCases:
    """Edge case tests."""
    
    def test_selector_custom_profiles(self):
        """Test selector with custom profiles."""
        custom = ModelProfile(
            name="custom",
            provider="test",
            input_cost=0.01,  # Very cheap
            output_cost=0.01,
            quality_score=95,  # High quality
            latency_ms=100,
            max_tokens=100000,
        )
        selector = ModelSelector(profiles=[custom])
        
        result = selector.select()
        assert result.selected_model.name == "custom"
    
    def test_analyzer_single_data_point(self):
        """Test analyzer with single data point."""
        analyzer = CostAnalyzer()
        analyzer.add_data_point(CostDataPoint(
            timestamp=datetime.now(timezone.utc),
            cost=0.05,
            model="gpt-4o",
        ))
        
        report = analyzer.generate_report()
        assert report.total_cost == 0.05
        assert report.total_requests == 1
    
    def test_budget_zero_usage(self):
        """Test budget with zero usage."""
        manager = BudgetManager()
        manager.add_limit(BudgetLimit(
            name="test",
            amount=100.0,
            period=BudgetPeriod.DAILY,
        ))
        
        status = manager.check_budget("global")
        assert status.current_usage == 0.0
        assert status.percentage_used == 0.0
    
    def test_estimator_zero_tokens(self):
        """Test estimator with zero tokens."""
        estimator = CostEstimator()
        estimate = estimator.estimate(
            model="gpt-4o",
            input_tokens=0,
            expected_output_tokens=0,
        )
        assert estimate.estimated_cost == 0.0
    
    def test_trend_stable_data(self):
        """Test trend with stable data."""
        analyzer = CostAnalyzer()
        now = datetime.now(timezone.utc)
        
        for i in range(10):
            analyzer.add_data_point(CostDataPoint(
                timestamp=now - timedelta(days=i),
                cost=0.10,  # Same cost
                model="gpt-4o",
            ))
        
        trend = analyzer.analyze_trend()
        assert trend.direction == TrendDirection.STABLE
