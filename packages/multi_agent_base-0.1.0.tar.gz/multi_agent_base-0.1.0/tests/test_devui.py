"""Tests for AF DevUI Integration."""

import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from multi_agent_base.core.devui import (
    DevUI,
    DevUIConfig,
    AgentSession,
    WorkflowSession,
    start_devui,
    create_devui_middleware,
    DevUITracer,
    SpanContext,
)


class TestDevUIConfig:
    """Tests for DevUIConfig."""
    
    def test_default_config(self):
        """Test default configuration."""
        config = DevUIConfig()
        
        assert config.host == "localhost"
        assert config.port == 8080
        assert config.enable_auth is False
        assert config.enable_metrics is True
        assert config.auto_open_browser is True
    
    def test_custom_config(self):
        """Test custom configuration."""
        config = DevUIConfig(
            host="0.0.0.0",
            port=9000,
            enable_auth=True,
            auth_token="secret-token",
        )
        
        assert config.host == "0.0.0.0"
        assert config.port == 9000
        assert config.enable_auth is True
        assert config.auth_token == "secret-token"


class TestAgentSession:
    """Tests for AgentSession."""
    
    def test_create_session(self):
        """Test creating an agent session."""
        session = AgentSession(
            id="session-1",
            agent_name="test-agent",
        )
        
        assert session.id == "session-1"
        assert session.agent_name == "test-agent"
        assert len(session.messages) == 0
        assert len(session.tool_calls) == 0


class TestWorkflowSession:
    """Tests for WorkflowSession."""
    
    def test_create_session(self):
        """Test creating a workflow session."""
        session = WorkflowSession(
            id="wf-session-1",
            workflow_id="my-workflow",
        )
        
        assert session.id == "wf-session-1"
        assert session.workflow_id == "my-workflow"
        assert session.state == "pending"


class TestDevUI:
    """Tests for DevUI."""
    
    def test_create_devui(self):
        """Test creating DevUI instance."""
        devui = DevUI()
        
        assert devui.config.host == "localhost"
        assert devui.config.port == 8080
        assert devui.is_running is False
    
    def test_create_with_config(self):
        """Test creating DevUI with config."""
        config = DevUIConfig(port=9000)
        devui = DevUI(config=config)
        
        assert devui.config.port == 9000
    
    def test_create_with_overrides(self):
        """Test creating DevUI with parameter overrides."""
        devui = DevUI(host="0.0.0.0", port=3000)
        
        assert devui.config.host == "0.0.0.0"
        assert devui.config.port == 3000
    
    def test_register_agent(self):
        """Test registering an agent."""
        devui = DevUI()
        
        mock_agent = MagicMock(name="test-agent")
        devui.register_agent(mock_agent, alias="Assistant")
        
        assert "Assistant" in devui._agents
    
    def test_register_workflow(self):
        """Test registering a workflow."""
        devui = DevUI()
        
        mock_workflow = MagicMock()
        mock_workflow.id = "wf-1"
        mock_workflow.name = "Test Workflow"
        
        devui.register_workflow(mock_workflow, alias="My Workflow")
        
        assert "My Workflow" in devui._workflows
    
    def test_url_property(self):
        """Test url property."""
        devui = DevUI(host="localhost", port=8080)
        
        assert devui.url == "http://localhost:8080"
    
    def test_generate_index_html(self):
        """Test generating fallback HTML."""
        devui = DevUI()
        
        mock_agent = MagicMock()
        mock_agent.__class__.__name__ = "EnhancedAgent"
        devui.register_agent(mock_agent, alias="TestAgent")
        
        html = devui._generate_index_html()
        
        assert "Multi-Agent Base DevUI" in html
        assert "TestAgent" in html


class TestStartDevUI:
    """Tests for start_devui function."""
    
    @pytest.mark.asyncio
    async def test_start_registers_entities(self):
        """Test start_devui registers agents and workflows."""
        mock_agent = MagicMock(name="agent")
        mock_workflow = MagicMock()
        mock_workflow.id = "wf-1"
        
        with patch.object(DevUI, 'start', new_callable=AsyncMock):
            devui = await start_devui(
                agents=[mock_agent],
                workflows=[mock_workflow],
                port=9999,
                auto_open_browser=False,
            )
        
        assert len(devui._agents) == 1
        assert len(devui._workflows) == 1


class TestCreateDevUIMiddleware:
    """Tests for create_devui_middleware function."""
    
    def test_returns_middleware(self):
        """Test function returns middleware."""
        middleware = create_devui_middleware()
        
        # Should be a middleware instance
        assert middleware is not None
        assert hasattr(middleware, 'before')
        assert hasattr(middleware, 'after')


class TestDevUITracer:
    """Tests for DevUITracer."""
    
    def test_create_tracer(self):
        """Test creating tracer."""
        tracer = DevUITracer(service_name="test-service")
        
        assert tracer._service_name == "test-service"
        assert len(tracer._spans) == 0
    
    def test_record_span(self):
        """Test recording span."""
        tracer = DevUITracer()
        
        span_data = {
            "name": "test-span",
            "duration_ms": 100,
        }
        
        tracer.record_span(span_data)
        
        assert len(tracer._spans) == 1


class TestSpanContext:
    """Tests for SpanContext."""
    
    def test_sync_context_manager(self):
        """Test span as sync context manager."""
        tracer = DevUITracer()
        
        with tracer.span("test-span", key="value") as span:
            assert span.name == "test-span"
            assert span.attributes["key"] == "value"
            assert span.start_time is not None
        
        # Span should be recorded
        assert len(tracer._spans) == 1
        assert tracer._spans[0]["name"] == "test-span"
    
    @pytest.mark.asyncio
    async def test_async_context_manager(self):
        """Test span as async context manager."""
        tracer = DevUITracer()
        
        async with tracer.span("async-span", count=42) as span:
            assert span.name == "async-span"
        
        assert len(tracer._spans) == 1
    
    def test_span_records_duration(self):
        """Test span records duration."""
        import time
        tracer = DevUITracer()
        
        with tracer.span("timed-span"):
            time.sleep(0.01)  # 10ms
        
        span_data = tracer._spans[0]
        assert "duration_ms" in span_data
        assert span_data["duration_ms"] >= 10
    
    def test_span_records_error(self):
        """Test span records error on exception."""
        tracer = DevUITracer()
        
        try:
            with tracer.span("error-span"):
                raise ValueError("Test error")
        except ValueError:
            pass
        
        span_data = tracer._spans[0]
        assert span_data["error"] == "Test error"


class TestDevUIIntegration:
    """Integration tests for DevUI."""
    
    @pytest.mark.asyncio
    async def test_full_workflow(self):
        """Test full DevUI workflow."""
        # Create DevUI
        config = DevUIConfig(
            auto_open_browser=False
        )
        devui = DevUI(config=config)
        
        # Register entities
        mock_agent = MagicMock()
        mock_agent.name = "assistant"
        mock_agent.__class__.__name__ = "EnhancedAgent"
        devui.register_agent(mock_agent)
        
        mock_workflow = MagicMock()
        mock_workflow.id = "my-workflow"
        mock_workflow.name = "My Workflow"
        mock_workflow.executors = {}
        mock_workflow.edges = []
        devui.register_workflow(mock_workflow)
        
        # Check state before start
        assert devui.is_running is False
        assert len(devui._agents) == 1
        assert len(devui._workflows) == 1
        
        # Note: We don't actually start the server in tests
        # as it would bind to a port
