"""
Tests for the Events module.
"""

import pytest
import asyncio

from multi_agent_base.events.bus import (
    Event,
    EventBus,
    EventPriority,
    get_event_bus,
)
from multi_agent_base.events.hooks import (
    Hook,
    HookContext,
    HookManager,
    LifecycleHook,
    AgentLifecycleHooks,
)
from multi_agent_base.events.decorators import on_event, before_hook, after_hook


class TestEvent:
    """Tests for Event class."""
    
    def test_create_event(self):
        """Test creating an event."""
        event = Event(
            name="test_event",
            data={"key": "value"},
            source="test_source",
        )
        
        assert event.name == "test_event"
        assert event.data["key"] == "value"
        assert event.source == "test_source"
        assert event.id is not None
        assert event.propagate is True
    
    def test_stop_propagation(self):
        """Test stopping event propagation."""
        event = Event(name="test")
        
        assert event.propagate is True
        event.stop_propagation()
        assert event.propagate is False
    
    def test_to_dict(self):
        """Test converting event to dictionary."""
        event = Event(name="test", data={"x": 1})
        
        data = event.to_dict()
        
        assert data["name"] == "test"
        assert data["data"]["x"] == 1


class TestEventBus:
    """Tests for EventBus."""
    
    @pytest.mark.asyncio
    async def test_subscribe_and_publish(self):
        """Test subscribing to and publishing events."""
        bus = EventBus()
        received = []
        
        async def handler(event: Event):
            received.append(event.data)
        
        bus.subscribe("test", handler)
        await bus.publish(Event(name="test", data={"value": 42}))
        
        assert len(received) == 1
        assert received[0]["value"] == 42
    
    @pytest.mark.asyncio
    async def test_unsubscribe(self):
        """Test unsubscribing from events."""
        bus = EventBus()
        received = []
        
        async def handler(event: Event):
            received.append(event)
        
        unsubscribe = bus.subscribe("test", handler)
        
        await bus.emit("test", {"first": True})
        unsubscribe()
        await bus.emit("test", {"second": True})
        
        assert len(received) == 1
    
    @pytest.mark.asyncio
    async def test_priority_ordering(self):
        """Test handlers are called in priority order."""
        bus = EventBus()
        order = []
        
        async def high_priority(event: Event):
            order.append("high")
        
        async def low_priority(event: Event):
            order.append("low")
        
        bus.subscribe("test", low_priority, priority=EventPriority.LOW)
        bus.subscribe("test", high_priority, priority=EventPriority.HIGH)
        
        await bus.emit("test")
        
        assert order == ["high", "low"]
    
    @pytest.mark.asyncio
    async def test_once_handler(self):
        """Test one-time handlers."""
        bus = EventBus()
        count = 0
        
        async def once_handler(event: Event):
            nonlocal count
            count += 1
        
        bus.subscribe("test", once_handler, once=True)
        
        await bus.emit("test")
        await bus.emit("test")
        
        assert count == 1
    
    @pytest.mark.asyncio
    async def test_global_handler(self):
        """Test global handler receives all events."""
        bus = EventBus()
        received = []
        
        async def global_handler(event: Event):
            received.append(event.name)
        
        bus.subscribe("*", global_handler)
        
        await bus.emit("event1")
        await bus.emit("event2")
        
        assert "event1" in received
        assert "event2" in received
    
    @pytest.mark.asyncio
    async def test_stop_propagation(self):
        """Test stopping event propagation."""
        bus = EventBus()
        called = []
        
        async def first(event: Event):
            called.append("first")
            event.stop_propagation()
        
        async def second(event: Event):
            called.append("second")
        
        bus.subscribe("test", first, priority=EventPriority.HIGH)
        bus.subscribe("test", second, priority=EventPriority.LOW)
        
        await bus.emit("test")
        
        assert called == ["first"]
    
    def test_event_history(self):
        """Test event history tracking."""
        bus = EventBus()
        
        asyncio.run(bus.emit("event1"))
        asyncio.run(bus.emit("event2"))
        
        history = bus.get_history()
        
        assert len(history) == 2
    
    def test_subscriber_count(self):
        """Test getting subscriber count."""
        bus = EventBus()
        
        async def handler(e): pass
        
        bus.subscribe("test", handler)
        bus.subscribe("test", handler)
        
        assert bus.get_subscriber_count("test") == 2


class TestHookContext:
    """Tests for HookContext."""
    
    def test_create_context(self):
        """Test creating hook context."""
        ctx = HookContext(
            hook_name="before_run",
            agent_name="test_agent",
            data={"message": "Hello"},
        )
        
        assert ctx.hook_name == "before_run"
        assert ctx.agent_name == "test_agent"
        assert ctx.cancelled is False
    
    def test_cancel(self):
        """Test cancelling hook context."""
        ctx = HookContext(hook_name="test", agent_name="agent")
        
        ctx.cancel()
        
        assert ctx.cancelled is True


class TestHookManager:
    """Tests for HookManager."""
    
    @pytest.mark.asyncio
    async def test_register_and_execute(self):
        """Test registering and executing hooks."""
        manager = HookManager()
        called = False
        
        async def hook_handler(ctx: HookContext):
            nonlocal called
            called = True
        
        manager.register("before_run", hook_handler)
        
        ctx = HookContext(hook_name="before_run", agent_name="test")
        await manager.execute("before_run", ctx)
        
        assert called is True
    
    @pytest.mark.asyncio
    async def test_hook_priority(self):
        """Test hooks are called in priority order."""
        manager = HookManager()
        order = []
        
        async def first(ctx: HookContext):
            order.append("first")
        
        async def second(ctx: HookContext):
            order.append("second")
        
        manager.register("test", second, priority=100)
        manager.register("test", first, priority=10)
        
        ctx = HookContext(hook_name="test", agent_name="agent")
        await manager.execute("test", ctx)
        
        assert order == ["first", "second"]
    
    @pytest.mark.asyncio
    async def test_hook_cancellation(self):
        """Test hook cancellation stops execution."""
        manager = HookManager()
        called = []
        
        async def cancelling_hook(ctx: HookContext):
            called.append("cancelling")
            ctx.cancel()
        
        async def after_hook(ctx: HookContext):
            called.append("after")
        
        manager.register("test", cancelling_hook, priority=10)
        manager.register("test", after_hook, priority=20)
        
        ctx = HookContext(hook_name="test", agent_name="agent")
        await manager.execute("test", ctx)
        
        assert called == ["cancelling"]
    
    def test_decorator_registration(self):
        """Test decorator-based registration."""
        manager = HookManager()
        
        @manager.on(LifecycleHook.BEFORE_RUN)
        async def hook_handler(ctx: HookContext):
            pass
        
        assert manager.has_hooks(LifecycleHook.BEFORE_RUN)


class TestAgentLifecycleHooks:
    """Tests for AgentLifecycleHooks."""
    
    @pytest.mark.asyncio
    async def test_before_run_hook(self):
        """Test before_run hook."""
        hooks = AgentLifecycleHooks()
        called = False
        
        async def handler(ctx: HookContext):
            nonlocal called
            called = True
        
        hooks.on_before_run(handler)
        
        await hooks.before_run("test_agent", {"message": "Hello"})
        
        assert called is True
    
    @pytest.mark.asyncio
    async def test_after_run_hook(self):
        """Test after_run hook."""
        hooks = AgentLifecycleHooks()
        result_data = None
        
        async def handler(ctx: HookContext):
            nonlocal result_data
            result_data = ctx.data
        
        hooks.on_after_run(handler)
        
        await hooks.after_run("test_agent", {"result": "success"})
        
        assert result_data["result"] == "success"
    
    @pytest.mark.asyncio
    async def test_error_hook(self):
        """Test error hook."""
        hooks = AgentLifecycleHooks()
        error_info = None
        
        async def handler(ctx: HookContext):
            nonlocal error_info
            error_info = ctx.data
        
        hooks.on_error(handler)
        
        await hooks.on_agent_error(
            "test_agent",
            ValueError("Test error"),
        )
        
        assert "Test error" in error_info["error"]
        assert error_info["error_type"] == "ValueError"


class TestEventDecorator:
    """Tests for @on_event decorator."""
    
    @pytest.mark.asyncio
    async def test_decorator_subscribes(self):
        """Test that decorator subscribes function."""
        bus = EventBus()
        received = []
        
        @on_event("test", bus=bus)
        async def handler(event: Event):
            received.append(event.data)
        
        await bus.emit("test", {"value": 1})
        
        assert len(received) == 1
