"""Tests for HITL (Human-in-the-Loop) Framework."""

import asyncio
import tempfile
from datetime import datetime, timezone
from pathlib import Path

import pytest

from multi_agent_base.hitl.approval import (
    ApprovalHandler,
    ApprovalRequest,
    ApprovalResponse,
    ApprovalStatus,
    require_approval,
    conditional_approval,
)
from multi_agent_base.hitl.checkpoint import (
    Checkpoint,
    CheckpointManager,
    CheckpointStatus,
    WorkflowCheckpoint,
)
from multi_agent_base.hitl.audit import (
    AuditLogger,
    AuditEntry,
    AuditDecision,
    AuditSeverity,
    InMemoryAuditBackend,
    FileAuditBackend,
    create_audit_logger,
)


# =============================================================================
# Approval Tests
# =============================================================================


class TestApprovalRequest:
    """Test ApprovalRequest data class."""
    
    def test_create_request(self):
        """Test creating an approval request."""
        request = ApprovalRequest(
            request_id="req_123",
            action="delete_records",
            reason="Bulk deletion",
            context={"count": 100},
        )
        
        assert request.request_id == "req_123"
        assert request.action == "delete_records"
        assert request.reason == "Bulk deletion"
        assert request.context["count"] == 100
    
    def test_request_serialization(self):
        """Test request serialization."""
        request = ApprovalRequest(
            request_id="req_456",
            action="update_config",
            reason="Config change",
        )
        
        data = request.to_dict()
        restored = ApprovalRequest.from_dict(data)
        
        assert restored.request_id == request.request_id
        assert restored.action == request.action


class TestApprovalResponse:
    """Test ApprovalResponse data class."""
    
    def test_create_response(self):
        """Test creating an approval response."""
        response = ApprovalResponse(
            request_id="req_123",
            status=ApprovalStatus.APPROVED,
            approver="admin",
        )
        
        assert response.is_approved
        assert not response.is_rejected
        assert response.approver == "admin"
    
    def test_rejected_response(self):
        """Test rejected response."""
        response = ApprovalResponse(
            request_id="req_123",
            status=ApprovalStatus.REJECTED,
            reason="Not authorized",
        )
        
        assert response.is_rejected
        assert not response.is_approved
        assert response.reason == "Not authorized"
    
    def test_timeout_response(self):
        """Test timeout response."""
        response = ApprovalResponse(
            request_id="req_123",
            status=ApprovalStatus.TIMEOUT,
        )
        
        assert response.is_timeout


class TestApprovalHandler:
    """Test ApprovalHandler."""
    
    @pytest.mark.asyncio
    async def test_auto_approve(self):
        """Test auto-approve mode."""
        handler = ApprovalHandler(auto_approve=True)
        
        response = await handler.request_approval(
            action="test_action",
            reason="Testing",
        )
        
        assert response.is_approved
        assert response.approver == "auto"
    
    @pytest.mark.asyncio
    async def test_auto_reject(self):
        """Test auto-reject mode."""
        handler = ApprovalHandler(auto_reject=True)
        
        response = await handler.request_approval(
            action="test_action",
            reason="Testing",
        )
        
        assert response.is_rejected
    
    @pytest.mark.asyncio
    async def test_manual_approve(self):
        """Test manual approval."""
        handler = ApprovalHandler(timeout=10)
        
        async def approve_later():
            await asyncio.sleep(0.1)
            requests = handler.get_pending_requests()
            assert len(requests) == 1
            await handler.approve(requests[0].request_id, approver="tester")
        
        # Start approval in background
        asyncio.create_task(approve_later())
        
        response = await handler.request_approval(
            action="test_action",
            reason="Testing manual approval",
        )
        
        assert response.is_approved
        assert response.approver == "tester"
    
    @pytest.mark.asyncio
    async def test_manual_reject(self):
        """Test manual rejection."""
        handler = ApprovalHandler(timeout=10)
        
        async def reject_later():
            await asyncio.sleep(0.1)
            requests = handler.get_pending_requests()
            await handler.reject(
                requests[0].request_id,
                approver="admin",
                reason="Not allowed",
            )
        
        asyncio.create_task(reject_later())
        
        response = await handler.request_approval(
            action="risky_action",
            reason="Needs review",
        )
        
        assert response.is_rejected
        assert response.reason == "Not allowed"
    
    @pytest.mark.asyncio
    async def test_timeout(self):
        """Test request timeout."""
        handler = ApprovalHandler(timeout=0.1)  # 100ms
        
        response = await handler.request_approval(
            action="slow_action",
            reason="This will timeout",
        )
        
        assert response.is_timeout
    
    @pytest.mark.asyncio
    async def test_callbacks(self):
        """Test approval callbacks."""
        handler = ApprovalHandler(auto_approve=True)
        callback_called = {"approved": False}
        
        @handler.on_approved
        async def on_approved(action, context):
            callback_called["approved"] = True
        
        await handler.request_approval(
            action="callback_test",
            reason="Test callbacks",
        )
        
        assert callback_called["approved"]
    
    def test_pending_requests(self):
        """Test getting pending requests."""
        handler = ApprovalHandler()
        
        assert handler.pending_count == 0
        assert not handler.has_pending_requests()
    
    @pytest.mark.asyncio
    async def test_cancel_request(self):
        """Test cancelling a request."""
        handler = ApprovalHandler(timeout=10)
        
        async def cancel_later():
            await asyncio.sleep(0.1)
            requests = handler.get_pending_requests()
            await handler.cancel(requests[0].request_id)
        
        asyncio.create_task(cancel_later())
        
        response = await handler.request_approval(
            action="cancel_test",
            reason="Will be cancelled",
        )
        
        assert response.status == ApprovalStatus.CANCELLED


class TestApprovalDecorators:
    """Test approval decorators."""
    
    @pytest.mark.asyncio
    async def test_require_approval_decorator(self):
        """Test @require_approval decorator."""
        handler = ApprovalHandler(auto_approve=True)
        
        @require_approval(reason="Test approval", handler=handler)
        async def protected_function(x: int) -> int:
            return x * 2
        
        result = await protected_function(5)
        assert result == 10
    
    @pytest.mark.asyncio
    async def test_require_approval_rejected(self):
        """Test @require_approval with rejection."""
        handler = ApprovalHandler(auto_reject=True)
        
        @require_approval(reason="Test rejection", handler=handler)
        async def protected_function(x: int) -> int:
            return x * 2
        
        result = await protected_function(5)
        assert result is None
    
    @pytest.mark.asyncio
    async def test_conditional_approval_skip(self):
        """Test @conditional_approval when condition is False."""
        handler = ApprovalHandler(timeout=0.1)  # Would timeout if called
        
        @conditional_approval(
            condition=lambda ctx: ctx.get("cost", 0) > 100,
            handler=handler,
        )
        async def process(cost: int) -> str:
            return f"Processed with cost {cost}"
        
        # Low cost - no approval needed
        result = await process(cost=50)
        assert result == "Processed with cost 50"
    
    @pytest.mark.asyncio
    async def test_conditional_approval_required(self):
        """Test @conditional_approval when condition is True."""
        handler = ApprovalHandler(auto_approve=True)
        
        @conditional_approval(
            condition=lambda ctx: ctx.get("cost", 0) > 100,
            reason="High cost operation",
            handler=handler,
        )
        async def process(cost: int) -> str:
            return f"Processed with cost {cost}"
        
        # High cost - approval needed (auto-approved)
        result = await process(cost=200)
        assert result == "Processed with cost 200"


# =============================================================================
# Checkpoint Tests
# =============================================================================


class TestCheckpoint:
    """Test Checkpoint class."""
    
    def test_create_checkpoint(self):
        """Test creating a checkpoint."""
        cp = Checkpoint(
            name="review_step",
            workflow_id="wf_123",
            step_name="analyze",
        )
        
        assert cp.name == "review_step"
        assert cp.workflow_id == "wf_123"
        assert cp.is_pending
    
    @pytest.mark.asyncio
    async def test_pause_and_resume(self):
        """Test pausing and resuming at checkpoint."""
        cp = Checkpoint(name="test_checkpoint")
        
        async def resume_later():
            await asyncio.sleep(0.1)
            await cp.resume(data={"approved": True})
        
        asyncio.create_task(resume_later())
        
        resume_data = await cp.pause(
            state={"results": [1, 2, 3]},
            timeout=5,
        )
        
        assert resume_data["approved"] is True
        assert cp.is_resumed
    
    @pytest.mark.asyncio
    async def test_pause_timeout(self):
        """Test checkpoint timeout."""
        cp = Checkpoint(name="timeout_checkpoint")
        
        with pytest.raises(asyncio.TimeoutError):
            await cp.pause(timeout=0.1)
        
        assert cp.is_expired
    
    def test_skip_checkpoint(self):
        """Test skipping a checkpoint."""
        cp = Checkpoint(name="skipped_checkpoint")
        cp.skip()
        
        assert cp.status == CheckpointStatus.SKIPPED
    
    @pytest.mark.asyncio
    async def test_on_resume_callback(self):
        """Test on_resume callback."""
        cp = Checkpoint(name="callback_checkpoint")
        callback_data = {}
        
        @cp.on_resume
        async def handle_resume(data):
            callback_data.update(data)
        
        async def resume_later():
            await asyncio.sleep(0.1)
            await cp.resume(data={"message": "Hello"})
        
        asyncio.create_task(resume_later())
        await cp.pause(timeout=5)
        
        assert callback_data["message"] == "Hello"
    
    def test_checkpoint_serialization(self):
        """Test checkpoint serialization."""
        cp = Checkpoint(
            name="serialize_test",
            workflow_id="wf_456",
        )
        
        data = cp.to_dict()
        restored = Checkpoint.from_dict(data)
        
        assert restored.name == cp.name
        assert restored.workflow_id == cp.workflow_id


class TestCheckpointManager:
    """Test CheckpointManager."""
    
    def test_create_checkpoint(self):
        """Test creating checkpoint via manager."""
        manager = CheckpointManager()
        
        cp = manager.create_checkpoint(
            name="managed_checkpoint",
            workflow_id="wf_123",
        )
        
        assert manager.count == 1
        assert manager.get_checkpoint(cp.checkpoint_id) is cp
    
    def test_get_by_name(self):
        """Test getting checkpoint by name."""
        manager = CheckpointManager()
        
        manager.create_checkpoint(name="first", workflow_id="wf_1")
        manager.create_checkpoint(name="second", workflow_id="wf_1")
        
        found = manager.get_checkpoint_by_name("first")
        assert found is not None
        assert found.name == "first"
    
    def test_get_for_workflow(self):
        """Test getting checkpoints for workflow."""
        manager = CheckpointManager()
        
        manager.create_checkpoint(name="cp1", workflow_id="wf_1")
        manager.create_checkpoint(name="cp2", workflow_id="wf_1")
        manager.create_checkpoint(name="cp3", workflow_id="wf_2")
        
        wf1_checkpoints = manager.get_checkpoints_for_workflow("wf_1")
        assert len(wf1_checkpoints) == 2
    
    @pytest.mark.asyncio
    async def test_resume_checkpoint(self):
        """Test resuming checkpoint via manager."""
        manager = CheckpointManager()
        cp = manager.create_checkpoint(name="resume_test")
        
        async def pause_checkpoint():
            await cp.pause(timeout=5)
        
        # Start pause in background
        task = asyncio.create_task(pause_checkpoint())
        
        # Wait for checkpoint to be paused
        await asyncio.sleep(0.1)
        
        # Resume via manager
        success = await manager.resume_checkpoint(
            cp.checkpoint_id,
            data={"ok": True},
        )
        
        await task
        
        assert success
        assert cp.is_resumed
    
    def test_remove_checkpoint(self):
        """Test removing checkpoint."""
        manager = CheckpointManager()
        cp = manager.create_checkpoint(name="to_remove")
        
        assert manager.remove_checkpoint(cp.checkpoint_id)
        assert manager.count == 0
    
    def test_clear_checkpoints(self):
        """Test clearing all checkpoints."""
        manager = CheckpointManager()
        
        for i in range(5):
            manager.create_checkpoint(name=f"cp_{i}")
        
        assert manager.count == 5
        manager.clear()
        assert manager.count == 0


class TestWorkflowCheckpoint:
    """Test WorkflowCheckpoint integration."""
    
    @pytest.mark.asyncio
    async def test_pause_for_review(self):
        """Test pause_for_review method."""
        manager = CheckpointManager()
        wf_cp = WorkflowCheckpoint(
            manager=manager,
            workflow_id="test_workflow",
        )
        
        async def resume_later():
            await asyncio.sleep(0.1)
            paused = manager.get_paused_checkpoints()
            if paused:
                await manager.resume_checkpoint(
                    paused[0].checkpoint_id,
                    data={"reviewed": True},
                )
        
        asyncio.create_task(resume_later())
        
        resume_data = await wf_cp.pause_for_review(
            step_name="analyze",
            state={"data": [1, 2, 3]},
            timeout=5,
        )
        
        assert resume_data["reviewed"] is True
    
    def test_create_checkpoint(self):
        """Test creating checkpoint for step."""
        manager = CheckpointManager()
        wf_cp = WorkflowCheckpoint(
            manager=manager,
            workflow_id="my_workflow",
        )
        
        cp = wf_cp.create_checkpoint(step_name="process_data")
        
        assert cp.workflow_id == "my_workflow"
        assert cp.step_name == "process_data"


# =============================================================================
# Audit Tests
# =============================================================================


class TestAuditEntry:
    """Test AuditEntry data class."""
    
    def test_create_entry(self):
        """Test creating an audit entry."""
        entry = AuditEntry(
            action="delete_records",
            decision=AuditDecision.APPROVED,
            user="admin",
            context={"count": 100},
        )
        
        assert entry.action == "delete_records"
        assert entry.decision == AuditDecision.APPROVED
        assert entry.user == "admin"
    
    def test_entry_serialization(self):
        """Test entry serialization."""
        entry = AuditEntry(
            action="update_config",
            decision=AuditDecision.REJECTED,
            reason="Not authorized",
        )
        
        data = entry.to_dict()
        restored = AuditEntry.from_dict(data)
        
        assert restored.action == entry.action
        assert restored.decision == entry.decision
        assert restored.reason == entry.reason
    
    def test_entry_str(self):
        """Test entry string representation."""
        entry = AuditEntry(
            action="test_action",
            decision=AuditDecision.APPROVED,
            user="tester",
        )
        
        s = str(entry)
        assert "test_action" in s
        assert "approved" in s
        assert "tester" in s


class TestAuditBackends:
    """Test audit backends."""
    
    @pytest.mark.asyncio
    async def test_in_memory_backend(self):
        """Test in-memory backend."""
        backend = InMemoryAuditBackend()
        
        entry = AuditEntry(
            action="test",
            decision=AuditDecision.APPROVED,
        )
        await backend.write(entry)
        
        entries = await backend.read_all()
        assert len(entries) == 1
        assert entries[0].action == "test"
    
    @pytest.mark.asyncio
    async def test_in_memory_query(self):
        """Test in-memory backend query."""
        backend = InMemoryAuditBackend()
        
        await backend.write(AuditEntry(
            action="action1",
            decision=AuditDecision.APPROVED,
            user="alice",
        ))
        await backend.write(AuditEntry(
            action="action2",
            decision=AuditDecision.REJECTED,
            user="bob",
        ))
        
        # Query by user
        results = await backend.query(user="alice")
        assert len(results) == 1
        assert results[0].user == "alice"
        
        # Query by decision
        results = await backend.query(decision=AuditDecision.REJECTED)
        assert len(results) == 1
        assert results[0].action == "action2"
    
    @pytest.mark.asyncio
    async def test_file_backend(self):
        """Test file backend."""
        with tempfile.TemporaryDirectory() as tmpdir:
            path = Path(tmpdir) / "audit.jsonl"
            backend = FileAuditBackend(str(path))
            
            entry = AuditEntry(
                action="file_test",
                decision=AuditDecision.APPROVED,
            )
            await backend.write(entry)
            
            entries = await backend.read_all()
            assert len(entries) == 1
            assert entries[0].action == "file_test"


class TestAuditLogger:
    """Test AuditLogger."""
    
    @pytest.mark.asyncio
    async def test_log_approval(self):
        """Test logging approval."""
        logger = AuditLogger()
        
        entry = await logger.log_approval(
            action="approve_test",
            user="admin",
            context={"item_id": 123},
        )
        
        assert entry.decision == AuditDecision.APPROVED
        
        entries = await logger.get_all()
        assert len(entries) == 1
    
    @pytest.mark.asyncio
    async def test_log_rejection(self):
        """Test logging rejection."""
        logger = AuditLogger()
        
        entry = await logger.log_rejection(
            action="reject_test",
            user="reviewer",
            reason="Does not meet criteria",
        )
        
        assert entry.decision == AuditDecision.REJECTED
        assert entry.severity == AuditSeverity.WARNING
    
    @pytest.mark.asyncio
    async def test_log_timeout(self):
        """Test logging timeout."""
        logger = AuditLogger()
        
        entry = await logger.log_timeout(
            action="timeout_test",
            timeout_seconds=300,
        )
        
        assert entry.decision == AuditDecision.TIMEOUT
    
    @pytest.mark.asyncio
    async def test_log_error(self):
        """Test logging error."""
        logger = AuditLogger()
        
        entry = await logger.log_error(
            action="error_test",
            error="Something went wrong",
        )
        
        assert entry.decision == AuditDecision.ERROR
        assert entry.severity == AuditSeverity.CRITICAL
    
    @pytest.mark.asyncio
    async def test_query(self):
        """Test querying audit entries."""
        logger = AuditLogger()
        
        await logger.log_approval(action="action1", user="alice")
        await logger.log_rejection(action="action2", user="bob")
        await logger.log_approval(action="action3", user="alice")
        
        # Query by user
        alice_entries = await logger.query(user="alice")
        assert len(alice_entries) == 2
        
        # Query by decision
        rejections = await logger.query(decision=AuditDecision.REJECTED)
        assert len(rejections) == 1
    
    @pytest.mark.asyncio
    async def test_get_recent(self):
        """Test getting recent entries."""
        logger = AuditLogger()
        
        for i in range(20):
            await logger.log_approval(action=f"action_{i}")
        
        recent = await logger.get_recent(5)
        assert len(recent) == 5
        assert recent[-1].action == "action_19"
    
    @pytest.mark.asyncio
    async def test_get_stats(self):
        """Test getting statistics."""
        logger = AuditLogger()
        
        await logger.log_approval(action="action1", user="alice")
        await logger.log_approval(action="action2", user="bob")
        await logger.log_rejection(action="action3", user="alice")
        
        stats = await logger.get_stats()
        
        assert stats["total_entries"] == 3
        assert stats["by_decision"]["approved"] == 2
        assert stats["by_decision"]["rejected"] == 1
        assert stats["by_user"]["alice"] == 2


class TestCreateAuditLogger:
    """Test create_audit_logger factory."""
    
    def test_default_logger(self):
        """Test creating default logger."""
        logger = create_audit_logger()
        assert len(logger.backends) == 1  # InMemory only
    
    def test_with_file(self):
        """Test creating logger with file backend."""
        with tempfile.TemporaryDirectory() as tmpdir:
            path = Path(tmpdir) / "audit.jsonl"
            logger = create_audit_logger(file_path=str(path))
            
            assert len(logger.backends) == 2  # InMemory + File
    
    def test_with_console(self):
        """Test creating logger with console backend."""
        logger = create_audit_logger(console=True)
        assert len(logger.backends) == 2  # InMemory + Console


# =============================================================================
# Integration Tests
# =============================================================================


class TestHITLIntegration:
    """Integration tests for HITL components."""
    
    @pytest.mark.asyncio
    async def test_approval_with_audit(self):
        """Test approval with audit logging."""
        handler = ApprovalHandler(auto_approve=True)
        logger = AuditLogger()
        
        # Register audit callback
        @handler.on_approved
        async def log_approval(action, context):
            await logger.log_approval(
                action=action,
                user="auto",
                context=context,
            )
        
        # Make request
        await handler.request_approval(
            action="critical_operation",
            context={"data": "test"},
        )
        
        # Check audit log
        entries = await logger.get_all()
        assert len(entries) == 1
        assert entries[0].action == "critical_operation"
    
    @pytest.mark.asyncio
    async def test_checkpoint_with_audit(self):
        """Test checkpoint resume with audit logging."""
        manager = CheckpointManager()
        logger = AuditLogger()
        
        cp = manager.create_checkpoint(
            name="review_checkpoint",
            workflow_id="wf_test",
        )
        
        # Register resume callback
        @cp.on_resume
        async def log_resume(data):
            await logger.log_resume(
                action=f"{cp.workflow_id}:{cp.name}",
                user=data.get("_resuming_user"),
                resume_data=data,
            )
        
        async def resume_later():
            await asyncio.sleep(0.1)
            await cp.resume(data={"approved": True})
        
        asyncio.create_task(resume_later())
        await cp.pause(timeout=5)
        
        # Check audit log
        entries = await logger.get_all()
        assert len(entries) == 1
        assert entries[0].decision == AuditDecision.RESUMED


# =============================================================================
# Run Tests
# =============================================================================

if __name__ == "__main__":
    pytest.main([__file__, "-v"])
