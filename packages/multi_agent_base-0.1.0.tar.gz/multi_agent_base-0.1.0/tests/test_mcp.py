"""
Tests for MCP (Model Context Protocol) module.

This module tests core MCP functionality:
- Protocol types
- Server implementation
- Tool discovery
"""

import asyncio
import json
import pytest
from typing import Any, Dict, List
from unittest.mock import MagicMock

from multi_agent_base.mcp import (
    # Protocol types
    MCPRequest,
    MCPResponse,
    MCPError,
    MCPNotification,
    # Tool types
    MCPTool,
    MCPToolParameter,
    MCPToolResult,
    MCPToolResultContent,
    # Resource types
    MCPResource,
    MCPResourceTemplate,
    # Prompt types
    MCPPrompt,
    MCPPromptArgument,
    # Error codes
    MCPErrorCode,
    # Server
    MCPServer,
    # Discovery
    ToolDiscovery,
    DiscoveredTool,
    # Constants
    MCP_PROTOCOL_VERSION,
)


# =============================================================================
# Protocol Types Tests
# =============================================================================


class TestMCPRequest:
    """Tests for MCPRequest."""
    
    def test_create_request(self):
        """Test creating a request."""
        request = MCPRequest(
            method="tools/call",
            params={"name": "search", "arguments": {"query": "AI"}},
        )
        
        assert request.method == "tools/call"
        assert request.params == {"name": "search", "arguments": {"query": "AI"}}
        assert request.id is not None
        assert request.jsonrpc == "2.0"
    
    def test_request_to_dict(self):
        """Test serializing request to dict."""
        request = MCPRequest(
            method="tools/call",
            params={"name": "search"},
            id="test-id",
        )
        
        data = request.to_dict()
        
        assert data["jsonrpc"] == "2.0"
        assert data["method"] == "tools/call"
        assert data["params"] == {"name": "search"}
        assert data["id"] == "test-id"
    
    def test_request_to_json(self):
        """Test serializing request to JSON."""
        request = MCPRequest(
            method="tools/list",
            id="json-test",
        )
        
        json_str = request.to_json()
        data = json.loads(json_str)
        
        assert data["method"] == "tools/list"
        assert data["id"] == "json-test"


class TestMCPResponse:
    """Tests for MCPResponse."""
    
    def test_create_response(self):
        """Test creating a response."""
        response = MCPResponse(
            result={"tools": []},
            id="resp-id",
        )
        
        assert response.result == {"tools": []}
        assert response.id == "resp-id"
        assert response.error is None
    
    def test_response_with_error(self):
        """Test creating an error response."""
        error = MCPError(
            code=MCPErrorCode.INVALID_REQUEST,
            message="Invalid request format",
        )
        
        response = MCPResponse(error=error, id="error-resp")
        
        assert response.result is None
        assert response.error is not None
        assert response.error.code == MCPErrorCode.INVALID_REQUEST
    
    def test_response_is_error(self):
        """Test is_error property."""
        success = MCPResponse(result={}, id="1")
        error = MCPResponse(
            error=MCPError(code=MCPErrorCode.INTERNAL_ERROR, message="Error"),
            id="2",
        )
        
        assert not success.is_error
        assert error.is_error


class TestMCPError:
    """Tests for MCPError."""
    
    def test_create_error(self):
        """Test creating an error."""
        error = MCPError(
            code=MCPErrorCode.METHOD_NOT_FOUND,
            message="Method not found",
            data={"method": "unknown/method"},
        )
        
        assert error.code == MCPErrorCode.METHOD_NOT_FOUND
        assert error.message == "Method not found"
        assert error.data == {"method": "unknown/method"}
    
    def test_error_to_dict(self):
        """Test serializing error to dict."""
        error = MCPError(
            code=MCPErrorCode.INVALID_PARAMS,
            message="Invalid parameters",
        )
        
        data = error.to_dict()
        
        assert data["code"] == MCPErrorCode.INVALID_PARAMS
        assert data["message"] == "Invalid parameters"


class TestMCPNotification:
    """Tests for MCPNotification."""
    
    def test_create_notification(self):
        """Test creating a notification."""
        notification = MCPNotification(
            method="notifications/progress",
            params={"progress": 50},
        )
        
        assert notification.method == "notifications/progress"
        assert notification.params == {"progress": 50}


class TestMCPErrorCode:
    """Tests for MCPErrorCode."""
    
    def test_error_codes(self):
        """Test error code values."""
        assert MCPErrorCode.PARSE_ERROR == -32700
        assert MCPErrorCode.INVALID_REQUEST == -32600
        assert MCPErrorCode.METHOD_NOT_FOUND == -32601
        assert MCPErrorCode.INVALID_PARAMS == -32602
        assert MCPErrorCode.INTERNAL_ERROR == -32603


# =============================================================================
# Tool Types Tests
# =============================================================================


class TestMCPTool:
    """Tests for MCPTool."""
    
    def test_create_tool(self):
        """Test creating a tool."""
        tool = MCPTool(
            name="search",
            description="Search for documents",
            parameters=[
                MCPToolParameter(
                    name="query",
                    type="string",
                    description="Search query",
                    required=True,
                ),
            ],
        )
        
        assert tool.name == "search"
        assert tool.description == "Search for documents"
        assert len(tool.parameters) == 1
        assert tool.parameters[0].name == "query"
    
    def test_tool_to_dict(self):
        """Test serializing tool to dict."""
        tool = MCPTool(
            name="calculate",
            description="Perform calculations",
            parameters=[],
        )
        
        data = tool.to_dict()
        
        assert data["name"] == "calculate"
        assert data["description"] == "Perform calculations"
        assert "inputSchema" in data


class TestMCPToolParameter:
    """Tests for MCPToolParameter."""
    
    def test_create_parameter(self):
        """Test creating a parameter."""
        param = MCPToolParameter(
            name="count",
            type="integer",
            description="Number of items",
            required=False,
            default=10,
        )
        
        assert param.name == "count"
        assert param.type == "integer"
        assert param.required is False
        assert param.default == 10
    
    def test_parameter_to_json_schema(self):
        """Test converting parameter to JSON schema."""
        param = MCPToolParameter(
            name="query",
            type="string",
            description="Search query",
            required=True,
        )
        
        schema = param.to_json_schema()
        
        assert schema["type"] == "string"
        assert schema["description"] == "Search query"


class TestMCPToolResult:
    """Tests for MCPToolResult."""
    
    def test_create_result(self):
        """Test creating a tool result."""
        result = MCPToolResult.text("Search results...")
        
        assert len(result.content) == 1
        assert result.content[0]["type"] == "text"
        assert result.isError is False
    
    def test_result_with_error(self):
        """Test creating an error result."""
        result = MCPToolResult.error("Something went wrong")
        
        assert result.isError is True


# =============================================================================
# Resource Types Tests
# =============================================================================


class TestMCPResource:
    """Tests for MCPResource."""
    
    def test_create_resource(self):
        """Test creating a resource."""
        resource = MCPResource(
            uri="file:///data/config.json",
            name="config.json",
            description="Configuration file",
            mimeType="application/json",
        )
        
        assert resource.uri == "file:///data/config.json"
        assert resource.name == "config.json"


class TestMCPResourceTemplate:
    """Tests for MCPResourceTemplate."""
    
    def test_create_template(self):
        """Test creating a resource template."""
        template = MCPResourceTemplate(
            uri_template="file:///data/{filename}",
            name="Data Files",
            description="Access data files",
        )
        
        assert "{filename}" in template.uri_template
        assert template.name == "Data Files"


# =============================================================================
# Server Tests
# =============================================================================


class TestMCPServer:
    """Tests for MCPServer."""
    
    def test_create_server(self):
        """Test creating a server."""
        server = MCPServer(
            name="test-server",
            version="1.0.0",
        )
        
        assert server.name == "test-server"
        assert server.version == "1.0.0"
    
    def test_register_tool_with_decorator(self):
        """Test registering tool with decorator."""
        server = MCPServer(name="test-server")
        
        @server.tool()
        def calculate(a: int, b: int) -> int:
            """Calculate sum of two numbers."""
            return a + b
        
        tools = server.tools
        assert "calculate" in tools
    
    def test_register_tool_manually(self):
        """Test registering tool manually."""
        server = MCPServer(name="test-server")
        
        def my_tool(x: str) -> str:
            """A test tool."""
            return x
        
        server.register_tool("my_tool", my_tool, "A test tool")
        
        tools = server.tools
        assert "my_tool" in tools
    
    @pytest.mark.asyncio
    async def test_handle_initialize(self):
        """Test handling initialize request."""
        server = MCPServer(name="test-server")
        
        request = MCPRequest(
            method="initialize",
            params={
                "protocolVersion": MCP_PROTOCOL_VERSION,
                "capabilities": {},
                "clientInfo": {"name": "test-client", "version": "1.0.0"},
            },
        )
        
        response = await server.handle_request(request)
        
        assert response.error is None
        assert response.result is not None
        assert response.result["serverInfo"]["name"] == "test-server"
    
    @pytest.mark.asyncio
    async def test_handle_tools_list(self):
        """Test handling tools/list request."""
        server = MCPServer(name="test-server")
        
        @server.tool()
        def my_tool(x: int) -> int:
            """A test tool."""
            return x * 2
        
        # Initialize first
        await server.handle_request(MCPRequest(
            method="initialize",
            params={
                "protocolVersion": MCP_PROTOCOL_VERSION,
                "capabilities": {},
                "clientInfo": {"name": "test", "version": "1.0"},
            },
        ))
        
        request = MCPRequest(method="tools/list")
        response = await server.handle_request(request)
        
        assert response.error is None
        assert "tools" in response.result
        assert len(response.result["tools"]) == 1
    
    @pytest.mark.asyncio
    async def test_handle_tools_call(self):
        """Test handling tools/call request."""
        server = MCPServer(name="test-server")
        
        @server.tool()
        def multiply(a: int, b: int) -> int:
            """Multiply two numbers."""
            return a * b
        
        # Initialize first
        await server.handle_request(MCPRequest(
            method="initialize",
            params={
                "protocolVersion": MCP_PROTOCOL_VERSION,
                "capabilities": {},
                "clientInfo": {"name": "test", "version": "1.0"},
            },
        ))
        
        request = MCPRequest(
            method="tools/call",
            params={
                "name": "multiply",
                "arguments": {"a": 6, "b": 7},
            },
        )
        
        response = await server.handle_request(request)
        
        assert response.error is None
        assert response.result["content"][0]["text"] == "42"
    
    @pytest.mark.asyncio
    async def test_handle_unknown_method(self):
        """Test handling unknown method."""
        server = MCPServer(name="test-server")
        
        request = MCPRequest(method="unknown/method")
        response = await server.handle_request(request)
        
        assert response.error is not None
        assert response.error.code == MCPErrorCode.METHOD_NOT_FOUND


# =============================================================================
# Discovery Tests
# =============================================================================


class TestToolDiscovery:
    """Tests for ToolDiscovery."""
    
    def test_create_discovery(self):
        """Test creating a discovery."""
        discovery = ToolDiscovery()
        
        assert discovery.tools == {}
        assert discovery.tool_names == []


class TestDiscoveredTool:
    """Tests for DiscoveredTool."""
    
    def test_create_discovered_tool(self):
        """Test creating a discovered tool."""
        client = MagicMock()
        
        tool = DiscoveredTool(
            name="search",
            description="Search for documents",
            parameters=[
                MCPToolParameter(
                    name="query",
                    type="string",
                    description="Search query",
                    required=True,
                ),
            ],
            client=client,
        )
        
        assert tool.name == "search"
        assert len(tool.parameters) == 1
    
    def test_to_json_schema(self):
        """Test converting to JSON schema."""
        client = MagicMock()
        
        tool = DiscoveredTool(
            name="calculate",
            description="Calculate sum",
            parameters=[
                MCPToolParameter(
                    name="a",
                    type="integer",
                    description="First number",
                    required=True,
                ),
            ],
            client=client,
        )
        
        schema = tool.to_json_schema()
        
        assert schema["type"] == "function"
        assert schema["function"]["name"] == "calculate"


# =============================================================================
# Integration Tests
# =============================================================================


class TestMCPIntegration:
    """Integration tests for MCP components."""
    
    @pytest.mark.asyncio
    async def test_server_tool_workflow(self):
        """Test complete server tool workflow."""
        # Create server with tools
        server = MCPServer(name="integration-server")
        
        @server.tool()
        def greet(name: str) -> str:
            """Greet a person."""
            return f"Hello, {name}!"
        
        @server.tool()
        def add(a: int, b: int) -> int:
            """Add two numbers."""
            return a + b
        
        # Initialize server
        init_response = await server.handle_request(MCPRequest(
            method="initialize",
            params={
                "protocolVersion": MCP_PROTOCOL_VERSION,
                "capabilities": {},
                "clientInfo": {"name": "test-client", "version": "1.0"},
            },
        ))
        assert init_response.error is None
        
        # List tools
        list_response = await server.handle_request(MCPRequest(method="tools/list"))
        assert list_response.error is None
        assert len(list_response.result["tools"]) == 2
        
        # Call greet tool
        greet_response = await server.handle_request(MCPRequest(
            method="tools/call",
            params={"name": "greet", "arguments": {"name": "World"}},
        ))
        assert greet_response.error is None
        assert greet_response.result["content"][0]["text"] == "Hello, World!"
        
        # Call add tool
        add_response = await server.handle_request(MCPRequest(
            method="tools/call",
            params={"name": "add", "arguments": {"a": 100, "b": 200}},
        ))
        assert add_response.error is None
        assert add_response.result["content"][0]["text"] == "300"
    
    @pytest.mark.asyncio
    async def test_async_tool_call(self):
        """Test calling async tools."""
        server = MCPServer(name="async-server")
        
        @server.tool()
        async def slow_operation(delay: float) -> str:
            """Perform a slow operation."""
            await asyncio.sleep(delay)
            return "Done"
        
        # Initialize
        await server.handle_request(MCPRequest(
            method="initialize",
            params={
                "protocolVersion": MCP_PROTOCOL_VERSION,
                "capabilities": {},
                "clientInfo": {"name": "test", "version": "1.0"},
            },
        ))
        
        # Call async tool
        response = await server.handle_request(MCPRequest(
            method="tools/call",
            params={"name": "slow_operation", "arguments": {"delay": 0.01}},
        ))
        
        assert response.error is None
        assert response.result["content"][0]["text"] == "Done"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
