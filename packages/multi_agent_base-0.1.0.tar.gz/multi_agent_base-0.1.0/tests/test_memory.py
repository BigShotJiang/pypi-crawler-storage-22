"""
Tests for the memory module.

Tests cover:
- Memory types and configuration
- BufferMemory implementation
- SlidingWindowMemory implementation
- Memory entry operations
- Context retrieval
- Memory statistics
"""

import pytest
from datetime import datetime, timedelta
from unittest.mock import AsyncMock, MagicMock, patch

from multi_agent_base.memory import (
    MemoryBackend,
    MemoryEntry,
    MemoryConfig,
    MemoryType,
    BufferMemory,
    SlidingWindowMemory,
    SummaryMemory,
    VectorMemory,
    CompositeMemory,
)


# ============================================================================
# MemoryType Tests
# ============================================================================

class TestMemoryType:
    """Tests for MemoryType enum."""
    
    def test_memory_types_exist(self):
        """Test all memory types are defined."""
        assert MemoryType.BUFFER == "buffer"
        assert MemoryType.SLIDING_WINDOW == "sliding_window"
        assert MemoryType.SUMMARY == "summary"
        assert MemoryType.VECTOR == "vector"
        assert MemoryType.REDIS == "redis"
        assert MemoryType.COMPOSITE == "composite"
    
    def test_memory_type_from_string(self):
        """Test creating memory type from string."""
        assert MemoryType("buffer") == MemoryType.BUFFER
        assert MemoryType("summary") == MemoryType.SUMMARY


# ============================================================================
# MemoryConfig Tests
# ============================================================================

class TestMemoryConfig:
    """Tests for MemoryConfig."""
    
    def test_default_config(self):
        """Test default configuration values."""
        config = MemoryConfig()
        
        assert config.memory_type == MemoryType.BUFFER
        assert config.max_messages == 100
        assert config.max_tokens == 4000
        assert config.persist is False
        assert config.persist_path is None
    
    def test_custom_config(self):
        """Test custom configuration."""
        config = MemoryConfig(
            memory_type=MemoryType.VECTOR,
            max_messages=50,
            max_tokens=8000,
            persist=True,
            persist_path="/tmp/memory",
        )
        
        assert config.memory_type == MemoryType.VECTOR
        assert config.max_messages == 50
        assert config.max_tokens == 8000
        assert config.persist is True
        assert config.persist_path == "/tmp/memory"
    
    def test_vector_config(self):
        """Test vector memory configuration."""
        config = MemoryConfig(
            memory_type=MemoryType.VECTOR,
            embedding_model="text-embedding-3-large",
            embedding_dimensions=3072,
            similarity_threshold=0.8,
            top_k=10,
        )
        
        assert config.embedding_model == "text-embedding-3-large"
        assert config.embedding_dimensions == 3072
        assert config.similarity_threshold == 0.8
        assert config.top_k == 10
    
    def test_redis_config(self):
        """Test Redis memory configuration."""
        config = MemoryConfig(
            memory_type=MemoryType.REDIS,
            redis_url="redis://localhost:6379",
            redis_prefix="test_memory",
            ttl_seconds=3600,
        )
        
        assert config.redis_url == "redis://localhost:6379"
        assert config.redis_prefix == "test_memory"
        assert config.ttl_seconds == 3600
    
    def test_summary_config(self):
        """Test summary memory configuration."""
        config = MemoryConfig(
            memory_type=MemoryType.SUMMARY,
            summary_model="gpt-4o-mini",
            summary_threshold=15,
        )
        
        assert config.summary_model == "gpt-4o-mini"
        assert config.summary_threshold == 15
    
    def test_validation_max_messages(self):
        """Test max_messages validation."""
        with pytest.raises(ValueError):
            MemoryConfig(max_messages=0)
    
    def test_validation_max_tokens(self):
        """Test max_tokens validation."""
        with pytest.raises(ValueError):
            MemoryConfig(max_tokens=50)  # min is 100
    
    def test_validation_similarity_threshold(self):
        """Test similarity_threshold validation."""
        # Should be between 0 and 1
        with pytest.raises(ValueError):
            MemoryConfig(similarity_threshold=1.5)
        
        with pytest.raises(ValueError):
            MemoryConfig(similarity_threshold=-0.1)


# ============================================================================
# MemoryEntry Tests
# ============================================================================

class TestMemoryEntry:
    """Tests for MemoryEntry dataclass."""
    
    def test_create_entry(self):
        """Test creating a memory entry."""
        entry = MemoryEntry(
            id="test-123",
            role="user",
            content="Hello, world!",
        )
        
        assert entry.id == "test-123"
        assert entry.role == "user"
        assert entry.content == "Hello, world!"
        assert entry.agent_name is None
        assert entry.session_id is None
        assert entry.metadata == {}
    
    def test_entry_with_metadata(self):
        """Test entry with metadata."""
        entry = MemoryEntry(
            id="test-456",
            role="assistant",
            content="Response",
            agent_name="agent1",
            session_id="session-1",
            metadata={"tool": "search", "confidence": 0.95},
            token_count=10,
        )
        
        assert entry.agent_name == "agent1"
        assert entry.session_id == "session-1"
        assert entry.metadata["tool"] == "search"
        assert entry.token_count == 10
    
    def test_to_message(self):
        """Test converting entry to message dict."""
        entry = MemoryEntry(
            id="test",
            role="user",
            content="Test message",
        )
        
        message = entry.to_message()
        assert message == {"role": "user", "content": "Test message"}
    
    def test_to_dict(self):
        """Test converting entry to dictionary."""
        now = datetime.utcnow()
        entry = MemoryEntry(
            id="test",
            role="assistant",
            content="Response",
            timestamp=now,
            agent_name="agent1",
            session_id="session-1",
            metadata={"key": "value"},
            token_count=20,
        )
        
        d = entry.to_dict()
        assert d["id"] == "test"
        assert d["role"] == "assistant"
        assert d["content"] == "Response"
        assert d["agent_name"] == "agent1"
        assert d["session_id"] == "session-1"
        assert d["metadata"] == {"key": "value"}
        assert d["token_count"] == 20


# ============================================================================
# BufferMemory Tests
# ============================================================================

class TestBufferMemory:
    """Tests for BufferMemory implementation."""
    
    @pytest.fixture
    def memory(self):
        """Create a buffer memory instance."""
        return BufferMemory(MemoryConfig(max_messages=5))
    
    @pytest.mark.asyncio
    async def test_add_entry(self, memory):
        """Test adding a memory entry."""
        entry = await memory.add(
            role="user",
            content="Hello!",
        )
        
        assert entry.id is not None
        assert entry.role == "user"
        assert entry.content == "Hello!"
    
    @pytest.mark.asyncio
    async def test_add_with_metadata(self, memory):
        """Test adding entry with metadata."""
        entry = await memory.add(
            role="assistant",
            content="Response",
            agent_name="test-agent",
            session_id="session-1",
            metadata={"tool": "search"},
        )
        
        assert entry.agent_name == "test-agent"
        assert entry.session_id == "session-1"
        assert entry.metadata["tool"] == "search"
    
    @pytest.mark.asyncio
    async def test_system_message_stored_separately(self, memory):
        """Test system messages are stored separately."""
        await memory.add(role="system", content="You are helpful")
        await memory.add(role="user", content="Hello")
        
        # Get recent should only return user message
        entries = await memory.get_recent()
        assert len(entries) == 1
        assert entries[0].role == "user"
    
    @pytest.mark.asyncio
    async def test_max_messages_limit(self, memory):
        """Test max messages limit enforcement."""
        # Add 7 messages (limit is 5)
        for i in range(7):
            await memory.add(role="user", content=f"Message {i}")
        
        entries = await memory.get_recent()
        assert len(entries) == 5
        # Should keep the newest messages
        assert entries[0].content == "Message 2"
        assert entries[-1].content == "Message 6"
    
    @pytest.mark.asyncio
    async def test_get_recent_with_limit(self, memory):
        """Test getting recent entries with limit."""
        for i in range(5):
            await memory.add(role="user", content=f"Message {i}")
        
        entries = await memory.get_recent(limit=3)
        assert len(entries) == 3
        assert entries[-1].content == "Message 4"
    
    @pytest.mark.asyncio
    async def test_get_recent_filtered_by_session(self, memory):
        """Test filtering by session ID."""
        await memory.add(role="user", content="Msg 1", session_id="session-1")
        await memory.add(role="user", content="Msg 2", session_id="session-2")
        await memory.add(role="user", content="Msg 3", session_id="session-1")
        
        entries = await memory.get_recent(session_id="session-1")
        assert len(entries) == 2
        assert all(e.session_id == "session-1" for e in entries)
    
    @pytest.mark.asyncio
    async def test_get_recent_filtered_by_agent(self, memory):
        """Test filtering by agent name."""
        await memory.add(role="user", content="Msg 1", agent_name="agent-1")
        await memory.add(role="user", content="Msg 2", agent_name="agent-2")
        
        entries = await memory.get_recent(agent_name="agent-1")
        assert len(entries) == 1
        assert entries[0].agent_name == "agent-1"
    
    @pytest.mark.asyncio
    async def test_search_keyword(self, memory):
        """Test keyword search."""
        await memory.add(role="user", content="I love Python programming")
        await memory.add(role="user", content="JavaScript is also great")
        await memory.add(role="user", content="Python and Django")
        
        results = await memory.search("Python")
        assert len(results) == 2
    
    @pytest.mark.asyncio
    async def test_search_case_insensitive(self, memory):
        """Test case insensitive search."""
        await memory.add(role="user", content="PYTHON is great")
        
        results = await memory.search("python")
        assert len(results) == 1
    
    @pytest.mark.asyncio
    async def test_search_with_limit(self, memory):
        """Test search with result limit."""
        await memory.add(role="user", content="Python 1")
        await memory.add(role="user", content="Python 2")
        await memory.add(role="user", content="Python 3")
        
        results = await memory.search("Python", k=2)
        assert len(results) == 2
    
    @pytest.mark.asyncio
    async def test_clear_all(self, memory):
        """Test clearing all entries."""
        await memory.add(role="user", content="Message 1")
        await memory.add(role="user", content="Message 2")
        await memory.add(role="system", content="System")
        
        count = await memory.clear()
        assert count == 2  # Only non-system messages
        
        entries = await memory.get_recent()
        assert len(entries) == 0
    
    @pytest.mark.asyncio
    async def test_clear_by_session(self, memory):
        """Test clearing entries by session."""
        await memory.add(role="user", content="Msg 1", session_id="session-1")
        await memory.add(role="user", content="Msg 2", session_id="session-2")
        await memory.add(role="user", content="Msg 3", session_id="session-1")
        
        count = await memory.clear(session_id="session-1")
        assert count == 2
        
        entries = await memory.get_recent()
        assert len(entries) == 1
        assert entries[0].session_id == "session-2"
    
    @pytest.mark.asyncio
    async def test_get_context(self, memory):
        """Test getting context for LLM."""
        await memory.add(role="system", content="You are helpful")
        await memory.add(role="user", content="Hello")
        await memory.add(role="assistant", content="Hi there!")
        
        context = await memory.get_context()
        
        assert len(context) == 3
        assert context[0]["role"] == "system"
        assert context[1]["role"] == "user"
        assert context[2]["role"] == "assistant"
    
    @pytest.mark.asyncio
    async def test_get_context_without_system(self, memory):
        """Test getting context without system message."""
        await memory.add(role="system", content="You are helpful")
        await memory.add(role="user", content="Hello")
        
        context = await memory.get_context(include_system=False)
        
        assert len(context) == 1
        assert context[0]["role"] == "user"
    
    @pytest.mark.asyncio
    async def test_get_context_token_limit(self, memory):
        """Test context respects token limit."""
        await memory.add(role="user", content="Short message")
        await memory.add(role="user", content="A" * 1000)  # Long message
        await memory.add(role="user", content="Another short")
        
        # Very small token limit
        context = await memory.get_context(max_tokens=50)
        
        # Should include only what fits
        assert len(context) <= 3
    
    @pytest.mark.asyncio
    async def test_get_stats(self, memory):
        """Test getting memory statistics."""
        await memory.add(role="user", content="Hello")
        await memory.add(role="assistant", content="Hi")
        
        stats = await memory.get_stats()
        
        assert stats["entry_count"] == 2
        assert "total_tokens" in stats
        assert stats["has_system_message"] is False


# ============================================================================
# SlidingWindowMemory Tests
# ============================================================================

class TestSlidingWindowMemory:
    """Tests for SlidingWindowMemory implementation."""
    
    @pytest.fixture
    def memory(self):
        """Create a sliding window memory instance."""
        return SlidingWindowMemory(MemoryConfig(max_tokens=200))
    
    @pytest.mark.asyncio
    async def test_add_entry(self, memory):
        """Test adding entries."""
        entry = await memory.add(role="user", content="Hello world")
        
        assert entry.id is not None
        assert entry.content == "Hello world"
    
    @pytest.mark.asyncio
    async def test_token_based_sliding(self, memory):
        """Test sliding based on token count."""
        # Add messages until we exceed token limit
        for i in range(20):
            await memory.add(role="user", content=f"Message {i} with some content")
        
        entries = await memory.get_recent()
        
        # Should have kept only what fits in token limit
        total_tokens = sum(e.token_count for e in entries)
        assert total_tokens <= 200
    
    @pytest.mark.asyncio
    async def test_get_context(self, memory):
        """Test getting context respects token limit."""
        await memory.add(role="system", content="System prompt")
        await memory.add(role="user", content="User message")
        await memory.add(role="assistant", content="Assistant response")
        
        context = await memory.get_context(max_tokens=100)
        
        assert len(context) >= 1


# ============================================================================
# SummaryMemory Tests
# ============================================================================

class TestSummaryMemory:
    """Tests for SummaryMemory implementation."""
    
    @pytest.fixture
    def memory(self):
        """Create a summary memory instance."""
        return SummaryMemory(MemoryConfig(summary_threshold=5))
    
    @pytest.mark.asyncio
    async def test_add_entry(self, memory):
        """Test adding entries."""
        entry = await memory.add(role="user", content="Hello")
        
        assert entry.id is not None
        assert entry.content == "Hello"
    
    @pytest.mark.asyncio
    async def test_summary_not_triggered_below_threshold(self, memory):
        """Test summarization doesn't trigger below threshold."""
        for i in range(3):
            await memory.add(role="user", content=f"Message {i}")
        
        # No summary should be created yet
        entries = await memory.get_recent()
        assert len(entries) == 3


# ============================================================================
# VectorMemory Tests
# ============================================================================

class TestVectorMemory:
    """Tests for VectorMemory implementation."""
    
    @pytest.fixture
    def memory(self):
        """Create a vector memory instance."""
        return VectorMemory(MemoryConfig(
            memory_type=MemoryType.VECTOR,
            embedding_dimensions=384,
            top_k=3,
        ))
    
    @pytest.mark.asyncio
    async def test_add_entry(self, memory):
        """Test adding entries."""
        entry = await memory.add(role="user", content="Hello world")
        
        assert entry.id is not None
        assert entry.content == "Hello world"
    
    @pytest.mark.asyncio
    async def test_add_multiple_entries(self, memory):
        """Test adding multiple entries."""
        await memory.add(role="user", content="First message")
        await memory.add(role="assistant", content="Second message")
        
        entries = await memory.get_recent()
        assert len(entries) == 2


# ============================================================================
# CompositeMemory Tests
# ============================================================================

class TestCompositeMemory:
    """Tests for CompositeMemory implementation."""
    
    @pytest.fixture
    def memory(self):
        """Create a composite memory instance."""
        buffer = BufferMemory(MemoryConfig(max_messages=10))
        composite = CompositeMemory(config=MemoryConfig())
        composite.add_backend("buffer", buffer, primary=True)
        return composite
    
    @pytest.mark.asyncio
    async def test_add_entry(self, memory):
        """Test adding to composite memory."""
        entry = await memory.add(role="user", content="Hello")
        
        assert entry.id is not None
        assert entry.content == "Hello"
    
    @pytest.mark.asyncio
    async def test_get_recent(self, memory):
        """Test getting recent from composite memory."""
        await memory.add(role="user", content="Message 1")
        await memory.add(role="user", content="Message 2")
        
        entries = await memory.get_recent()
        assert len(entries) == 2


# ============================================================================
# Integration Tests
# ============================================================================

class TestMemoryIntegration:
    """Integration tests for memory module."""
    
    @pytest.mark.asyncio
    async def test_full_conversation_flow(self):
        """Test a full conversation flow."""
        memory = BufferMemory(MemoryConfig(max_messages=100))
        
        # Add system message
        await memory.add(role="system", content="You are a helpful assistant")
        
        # Simulate conversation
        await memory.add(role="user", content="What is Python?")
        await memory.add(
            role="assistant", 
            content="Python is a programming language."
        )
        await memory.add(role="user", content="What can I do with it?")
        await memory.add(
            role="assistant",
            content="You can build web apps, AI systems, and more."
        )
        
        # Get context for next LLM call
        context = await memory.get_context()
        
        assert len(context) == 5
        assert context[0]["role"] == "system"
        assert context[-1]["role"] == "assistant"
    
    @pytest.mark.asyncio
    async def test_multi_session_conversation(self):
        """Test handling multiple sessions."""
        memory = BufferMemory(MemoryConfig(max_messages=100))
        
        # Session 1
        await memory.add(
            role="user", content="Hello", session_id="session-1"
        )
        await memory.add(
            role="assistant", content="Hi!", session_id="session-1"
        )
        
        # Session 2
        await memory.add(
            role="user", content="Bonjour", session_id="session-2"
        )
        await memory.add(
            role="assistant", content="Salut!", session_id="session-2"
        )
        
        # Get each session
        session1 = await memory.get_recent(session_id="session-1")
        session2 = await memory.get_recent(session_id="session-2")
        
        assert len(session1) == 2
        assert len(session2) == 2
        assert session1[0].content == "Hello"
        assert session2[0].content == "Bonjour"
    
    @pytest.mark.asyncio
    async def test_multi_agent_memory(self):
        """Test handling multiple agents."""
        memory = BufferMemory(MemoryConfig(max_messages=100))
        
        await memory.add(
            role="assistant", content="I'll search for that", agent_name="search-agent"
        )
        await memory.add(
            role="assistant", content="Here's my analysis", agent_name="analysis-agent"
        )
        
        search_entries = await memory.get_recent(agent_name="search-agent")
        analysis_entries = await memory.get_recent(agent_name="analysis-agent")
        
        assert len(search_entries) == 1
        assert len(analysis_entries) == 1


# ============================================================================
# Edge Cases
# ============================================================================

class TestMemoryEdgeCases:
    """Edge case tests for memory module."""
    
    @pytest.mark.asyncio
    async def test_empty_memory(self):
        """Test operations on empty memory."""
        memory = BufferMemory()
        
        entries = await memory.get_recent()
        assert entries == []
        
        results = await memory.search("anything")
        assert results == []
        
        context = await memory.get_context()
        assert context == []
    
    @pytest.mark.asyncio
    async def test_clear_empty_memory(self):
        """Test clearing empty memory."""
        memory = BufferMemory()
        
        count = await memory.clear()
        assert count == 0
    
    @pytest.mark.asyncio
    async def test_empty_content(self):
        """Test adding empty content."""
        memory = BufferMemory()
        
        entry = await memory.add(role="user", content="")
        assert entry.content == ""
    
    @pytest.mark.asyncio
    async def test_unicode_content(self):
        """Test Unicode content handling."""
        memory = BufferMemory()
        
        content = "Hello 🌍! 你好世界! مرحبا"
        entry = await memory.add(role="user", content=content)
        
        assert entry.content == content
        
        entries = await memory.get_recent()
        assert entries[0].content == content
    
    @pytest.mark.asyncio
    async def test_very_long_content(self):
        """Test very long content."""
        memory = BufferMemory(MemoryConfig(max_messages=10))
        
        long_content = "A" * 100000
        entry = await memory.add(role="user", content=long_content)
        
        assert len(entry.content) == 100000
    
    @pytest.mark.asyncio
    async def test_special_characters_in_search(self):
        """Test search with special characters."""
        memory = BufferMemory()
        
        await memory.add(role="user", content="Hello [world] (test)")
        
        results = await memory.search("[world]")
        assert len(results) == 1
