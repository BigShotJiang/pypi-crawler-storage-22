"""Tests for AF Middleware Adapter."""

import pytest
import time
from unittest.mock import AsyncMock, MagicMock, patch

from multi_agent_base.core.middleware import (
    BaseMiddleware,
    AgentMiddleware,
    ChatMiddleware,
    FunctionMiddleware,
    MiddlewareContext,
    MiddlewarePipeline,
    ResilienceMiddleware,
    SecurityMiddleware,
    RateLimitMiddleware,
    CostTrackingMiddleware,
    MetricsMiddleware,
    LoggingMiddleware,
    create_default_middleware_pipeline,
)


class TestMiddlewareContext:
    """Tests for MiddlewareContext."""
    
    def test_create_context(self):
        """Test creating a middleware context."""
        context = MiddlewareContext()
        
        assert context.metadata == {}
        assert context.terminate is False
        assert context.result is None
    
    def test_context_with_agent(self):
        """Test context with agent name."""
        context = MiddlewareContext(agent_name="test-agent")
        
        assert context.agent_name == "test-agent"
    
    def test_context_metadata(self):
        """Test context metadata manipulation."""
        context = MiddlewareContext()
        
        context.metadata["key"] = "value"
        context.metadata["count"] = 42
        
        assert context.metadata["key"] == "value"
        assert context.metadata["count"] == 42


class ConcreteMiddleware(BaseMiddleware):
    """Concrete middleware for testing."""
    
    def __init__(self):
        self.before_called = False
        self.after_called = False
        self.before_args = None
        self.after_args = None
    
    async def before(self, context, *args, **kwargs):
        self.before_called = True
        self.before_args = args
        context.metadata["before"] = True
    
    async def after(self, context, result, error=None):
        self.after_called = True
        self.after_args = (result, error)
        context.metadata["after"] = True
        return result


class TestBaseMiddleware:
    """Tests for BaseMiddleware implementations."""
    
    @pytest.mark.asyncio
    async def test_concrete_middleware(self):
        """Test concrete middleware implementation."""
        middleware = ConcreteMiddleware()
        context = MiddlewareContext()
        
        await middleware.before(context, "arg1", "arg2")
        result = await middleware.after(context, "result", None)
        
        assert middleware.before_called is True
        assert middleware.after_called is True
        assert middleware.before_args == ("arg1", "arg2")
        assert result == "result"
        assert context.metadata["before"] is True
        assert context.metadata["after"] is True


class TestAgentMiddleware:
    """Tests for AgentMiddleware."""
    
    @pytest.mark.asyncio
    async def test_agent_middleware_invoke(self):
        """Test agent middleware invoke pattern."""
        
        class TestAgentMiddleware(AgentMiddleware):
            def __init__(self):
                self.invoked = False
            
            async def before(self, context, *args, **kwargs):
                context.metadata["agent_before"] = True
            
            async def after(self, context, result, error=None):
                context.metadata["agent_after"] = True
                return result
        
        middleware = TestAgentMiddleware()
        mock_agent = MagicMock(name="test_agent")
        messages = [{"role": "user", "content": "hello"}]
        context = MagicMock()
        
        async def next_handler(ctx):
            return {"content": "response"}
        
        result = await middleware.invoke(mock_agent, messages, context, next_handler)
        
        assert result["content"] == "response"


class TestChatMiddleware:
    """Tests for ChatMiddleware."""
    
    @pytest.mark.asyncio
    async def test_chat_middleware_invoke(self):
        """Test chat middleware invoke pattern."""
        
        class TestChatMiddleware(ChatMiddleware):
            async def before(self, context, *args, **kwargs):
                context.metadata["chat_before"] = True
            
            async def after(self, context, result, error=None):
                context.metadata["chat_after"] = True
                return result
        
        middleware = TestChatMiddleware()
        mock_client = MagicMock()
        messages = [{"role": "user", "content": "hello"}]
        options = {"temperature": 0.7}
        context = MagicMock()
        
        async def next_handler(ctx):
            return {"content": "response"}
        
        result = await middleware.invoke(
            mock_client, messages, options, context, next_handler
        )
        
        assert result["content"] == "response"


class TestFunctionMiddleware:
    """Tests for FunctionMiddleware."""
    
    @pytest.mark.asyncio
    async def test_function_middleware_invoke(self):
        """Test function middleware invoke pattern."""
        
        class TestFunctionMiddleware(FunctionMiddleware):
            async def before(self, context, *args, **kwargs):
                context.metadata["func_before"] = True
            
            async def after(self, context, result, error=None):
                context.metadata["func_after"] = True
                return result
        
        middleware = TestFunctionMiddleware()
        context = MagicMock()
        
        async def next_handler(ctx):
            return "function_result"
        
        result = await middleware.invoke(
            "my_function", {"arg1": "value"}, context, next_handler
        )
        
        assert result == "function_result"


class TestResilienceMiddleware:
    """Tests for ResilienceMiddleware."""
    
    def test_create_middleware(self):
        """Test creating resilience middleware."""
        middleware = ResilienceMiddleware()
        
        assert middleware._wrapper is None
        assert middleware._initialized is False
    
    @pytest.mark.asyncio
    async def test_middleware_without_wrapper(self):
        """Test middleware passes through without wrapper."""
        middleware = ResilienceMiddleware()
        context = MiddlewareContext(agent_name="test")
        
        await middleware.before(context)
        result = await middleware.after(context, {"content": "response"})
        
        assert result["content"] == "response"
        assert context.terminate is False


class TestSecurityMiddleware:
    """Tests for SecurityMiddleware."""
    
    def test_create_middleware(self):
        """Test creating security middleware."""
        middleware = SecurityMiddleware()
        
        assert middleware._validator is None
        assert middleware._block_on_threat is True
    
    @pytest.mark.asyncio
    async def test_middleware_without_validator(self):
        """Test middleware passes through without validator."""
        middleware = SecurityMiddleware()
        context = MiddlewareContext()
        context.metadata["messages"] = [{"content": "hello"}]
        
        await middleware.before(context)
        
        assert context.terminate is False
    
    @pytest.mark.asyncio
    async def test_middleware_blocks_on_threat(self):
        """Test middleware blocks when threat detected."""
        mock_validator = MagicMock()
        mock_validator.check_prompt_injection.return_value = MagicMock(
            is_safe=False,
            reason="Prompt injection detected"
        )
        
        middleware = SecurityMiddleware(validator=mock_validator)
        context = MiddlewareContext()
        context.metadata["messages"] = [{"content": "malicious input"}]
        
        await middleware.before(context)
        
        assert context.terminate is True
        assert context.result["blocked"] is True


class TestRateLimitMiddleware:
    """Tests for RateLimitMiddleware."""
    
    def test_create_middleware(self):
        """Test creating rate limit middleware."""
        middleware = RateLimitMiddleware()
        
        assert middleware._limiter is None
        assert middleware._limit_by == "function"
    
    @pytest.mark.asyncio
    async def test_middleware_without_limiter(self):
        """Test middleware passes through without limiter."""
        middleware = RateLimitMiddleware()
        context = MiddlewareContext()
        
        await middleware.before(context)
        
        assert context.terminate is False
    
    @pytest.mark.asyncio
    async def test_middleware_rate_limited(self):
        """Test middleware blocks when rate limited."""
        mock_limiter = MagicMock()
        mock_limiter.acquire = AsyncMock(return_value=MagicMock(
            allowed=False,
            remaining=0,
            reset_after=60.0
        ))
        
        middleware = RateLimitMiddleware(limiter=mock_limiter)
        context = MiddlewareContext()
        context.metadata["function_name"] = "my_function"
        
        await middleware.before(context)
        
        assert context.terminate is True
        assert context.metadata["rate_limited"] is True


class TestCostTrackingMiddleware:
    """Tests for CostTrackingMiddleware."""
    
    def test_create_middleware(self):
        """Test creating cost tracking middleware."""
        middleware = CostTrackingMiddleware()
        
        assert middleware._tracker is None
    
    @pytest.mark.asyncio
    async def test_middleware_tracks_cost(self):
        """Test middleware tracks cost from response."""
        mock_tracker = MagicMock()
        mock_tracker.calculate_cost.return_value = 0.0025
        
        middleware = CostTrackingMiddleware(tracker=mock_tracker)
        context = MiddlewareContext()
        context.metadata["model"] = "gpt-4o-mini"
        context.metadata["provider"] = "openai"
        
        await middleware.before(context)
        
        result = {
            "content": "response",
            "usage": {"prompt_tokens": 100, "completion_tokens": 50}
        }
        
        await middleware.after(context, result)
        
        mock_tracker.calculate_cost.assert_called_once()
        mock_tracker.record.assert_called_once()


class TestMetricsMiddleware:
    """Tests for MetricsMiddleware."""
    
    def test_create_middleware(self):
        """Test creating metrics middleware."""
        middleware = MetricsMiddleware()
        
        assert middleware._collector is None
    
    @pytest.mark.asyncio
    async def test_middleware_records_metrics(self):
        """Test middleware records metrics."""
        mock_collector = MagicMock()
        
        middleware = MetricsMiddleware(collector=mock_collector)
        context = MiddlewareContext(agent_name="test-agent")
        
        await middleware.before(context)
        await middleware.after(context, {"content": "response"})
        
        # Should have called set_gauge for active requests
        assert mock_collector.set_gauge.call_count >= 2
        # Should have called observe_histogram for duration
        mock_collector.observe_histogram.assert_called_once()
        # Should have called increment_counter for request count
        mock_collector.increment_counter.assert_called_once()


class TestLoggingMiddleware:
    """Tests for LoggingMiddleware."""
    
    def test_create_middleware(self):
        """Test creating logging middleware."""
        middleware = LoggingMiddleware()
        
        assert middleware._logger is None
    
    @pytest.mark.asyncio
    async def test_middleware_logs(self):
        """Test middleware logs agent runs."""
        mock_logger = MagicMock()
        mock_logger.log_agent_run = MagicMock()
        mock_logger.log_error = MagicMock()
        
        middleware = LoggingMiddleware(logger=mock_logger)
        context = MiddlewareContext(agent_name="test-agent")
        
        await middleware.before(context)
        await middleware.after(context, {"content": "response"})
        
        assert mock_logger.log_agent_run.call_count == 2


class TestMiddlewarePipeline:
    """Tests for MiddlewarePipeline."""
    
    def test_create_pipeline(self):
        """Test creating a pipeline."""
        pipeline = MiddlewarePipeline()
        
        assert len(pipeline._middleware) == 0
    
    def test_add_middleware(self):
        """Test adding middleware to pipeline."""
        pipeline = MiddlewarePipeline()
        
        mw1 = ConcreteMiddleware()
        mw2 = ConcreteMiddleware()
        
        pipeline.add(mw1).add(mw2)
        
        assert len(pipeline._middleware) == 2
    
    def test_insert_middleware(self):
        """Test inserting middleware at position."""
        pipeline = MiddlewarePipeline([ConcreteMiddleware(), ConcreteMiddleware()])
        
        new_mw = ConcreteMiddleware()
        pipeline.insert(1, new_mw)
        
        assert len(pipeline._middleware) == 3
        assert pipeline._middleware[1] is new_mw
    
    @pytest.mark.asyncio
    async def test_execute_pipeline(self):
        """Test executing middleware pipeline."""
        order = []
        
        class OrderedMiddleware(BaseMiddleware):
            def __init__(self, name):
                self.name = name
            
            async def before(self, context, *args, **kwargs):
                order.append(f"{self.name}_before")
            
            async def after(self, context, result, error=None):
                order.append(f"{self.name}_after")
                return result
        
        pipeline = MiddlewarePipeline([
            OrderedMiddleware("first"),
            OrderedMiddleware("second"),
            OrderedMiddleware("third"),
        ])
        
        async def handler():
            order.append("handler")
            return "result"
        
        result = await pipeline.execute(handler)
        
        assert result == "result"
        assert order == [
            "first_before",
            "second_before",
            "third_before",
            "handler",
            "third_after",
            "second_after",
            "first_after",
        ]
    
    @pytest.mark.asyncio
    async def test_pipeline_short_circuit(self):
        """Test pipeline short-circuits on terminate."""
        
        class TerminatingMiddleware(BaseMiddleware):
            async def before(self, context, *args, **kwargs):
                context.terminate = True
                context.result = "terminated"
            
            async def after(self, context, result, error=None):
                return result
        
        pipeline = MiddlewarePipeline([
            TerminatingMiddleware(),
            ConcreteMiddleware(),  # Should not be called
        ])
        
        async def handler():
            raise AssertionError("Handler should not be called")
        
        result = await pipeline.execute(handler)
        
        assert result == "terminated"


class TestCreateDefaultMiddlewarePipeline:
    """Tests for create_default_middleware_pipeline factory."""
    
    def test_create_with_defaults(self):
        """Test creating pipeline with defaults."""
        pipeline = create_default_middleware_pipeline()
        
        # Should have logging, resilience, security, cost tracking
        assert len(pipeline._middleware) >= 3
    
    def test_create_with_all_disabled(self):
        """Test creating pipeline with all features disabled."""
        pipeline = create_default_middleware_pipeline(
            enable_resilience=False,
            enable_security=False,
            enable_rate_limiting=False,
            enable_cost_tracking=False,
            enable_metrics=False,
            enable_logging=False,
        )
        
        assert len(pipeline._middleware) == 0
    
    def test_create_with_all_enabled(self):
        """Test creating pipeline with all features enabled."""
        pipeline = create_default_middleware_pipeline(
            enable_resilience=True,
            enable_security=True,
            enable_rate_limiting=True,
            enable_cost_tracking=True,
            enable_metrics=True,
            enable_logging=True,
        )
        
        assert len(pipeline._middleware) == 6
