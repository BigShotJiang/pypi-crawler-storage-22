"""Tests for monitoring module."""

from __future__ import annotations

import asyncio
import pytest
import time
from unittest.mock import AsyncMock, MagicMock, patch

from multi_agent_base.monitoring import (
    Counter,
    Gauge,
    Histogram,
    MetricsCollector,
    HealthCheck,
    HealthStatus,
    HealthResult,
    create_default_metrics,
)


class TestCounter:
    """Tests for Counter metric."""
    
    def test_create_counter(self):
        """Test counter creation."""
        counter = Counter(
            name="test_counter",
            description="A test counter",
            labels=["method", "status"],
        )
        assert counter.name == "test_counter"
        assert counter.description == "A test counter"
        assert counter.labels == ["method", "status"]
    
    def test_inc_without_labels(self):
        """Test incrementing counter without labels."""
        counter = Counter("test_counter", "Test")
        counter.inc()
        counter.inc(5)
        
        samples = counter.collect()
        assert len(samples) == 1
        assert samples[0].value == 6.0
    
    def test_inc_with_labels(self):
        """Test incrementing counter with labels."""
        counter = Counter("test_counter", "Test", labels=["method"])
        counter.inc(labels={"method": "GET"})
        counter.inc(labels={"method": "POST"})
        counter.inc(labels={"method": "GET"})
        
        samples = counter.collect()
        assert len(samples) == 2
        
        get_sample = next(s for s in samples if s.labels.get("method") == "GET")
        post_sample = next(s for s in samples if s.labels.get("method") == "POST")
        
        assert get_sample.value == 2.0
        assert post_sample.value == 1.0
    
    def test_inc_negative_raises(self):
        """Test that incrementing with negative value raises."""
        counter = Counter("test_counter", "Test")
        with pytest.raises(ValueError, match="Counter can only be incremented"):
            counter.inc(-1)
    
    def test_collect_returns_samples(self):
        """Test that collect returns MetricSample objects."""
        counter = Counter("test_counter", "Test")
        counter.inc()
        
        samples = counter.collect()
        assert len(samples) == 1
        assert samples[0].name == "test_counter"
        assert samples[0].value == 1.0
        assert samples[0].timestamp > 0


class TestGauge:
    """Tests for Gauge metric."""
    
    def test_create_gauge(self):
        """Test gauge creation."""
        gauge = Gauge(
            name="test_gauge",
            description="A test gauge",
        )
        assert gauge.name == "test_gauge"
        assert gauge.description == "A test gauge"
    
    def test_set_value(self):
        """Test setting gauge value."""
        gauge = Gauge("test_gauge", "Test")
        gauge.set(42.5)
        
        samples = gauge.collect()
        assert len(samples) == 1
        assert samples[0].value == 42.5
    
    def test_inc_dec(self):
        """Test incrementing and decrementing gauge."""
        gauge = Gauge("test_gauge", "Test")
        gauge.set(10)
        gauge.inc(5)
        gauge.dec(3)
        
        samples = gauge.collect()
        assert samples[0].value == 12.0
    
    def test_gauge_with_labels(self):
        """Test gauge with labels."""
        gauge = Gauge("test_gauge", "Test", labels=["region"])
        gauge.set(10, labels={"region": "us"})
        gauge.set(20, labels={"region": "eu"})
        
        samples = gauge.collect()
        assert len(samples) == 2
    
    def test_set_current_time_manually(self):
        """Test setting gauge to current time manually."""
        gauge = Gauge("test_gauge", "Test")
        before = time.time()
        gauge.set(time.time())
        after = time.time()
        
        samples = gauge.collect()
        assert before <= samples[0].value <= after


class TestHistogram:
    """Tests for Histogram metric."""
    
    def test_create_histogram(self):
        """Test histogram creation."""
        histogram = Histogram(
            name="test_histogram",
            description="A test histogram",
        )
        assert histogram.name == "test_histogram"
        assert len(histogram.buckets) > 0  # Default buckets
    
    def test_custom_buckets(self):
        """Test histogram with custom buckets."""
        histogram = Histogram(
            "test_histogram",
            "Test",
            buckets=[0.1, 0.5, 1.0, 5.0],
        )
        # Implementation stores buckets as tuple
        assert 0.1 in histogram.buckets
        assert 5.0 in histogram.buckets
    
    def test_observe(self):
        """Test observing values."""
        histogram = Histogram(
            "test_histogram",
            "Test",
            buckets=[1.0, 5.0, 10.0],
        )
        histogram.observe(0.5)
        histogram.observe(2.0)
        histogram.observe(7.0)
        histogram.observe(15.0)
        
        samples = histogram.collect()
        
        # Find bucket samples
        bucket_samples = [s for s in samples if "_bucket" in s.name]
        sum_sample = next(s for s in samples if "_sum" in s.name)
        count_sample = next(s for s in samples if "_count" in s.name)
        
        assert sum_sample.value == 0.5 + 2.0 + 7.0 + 15.0
        assert count_sample.value == 4
        assert len(bucket_samples) >= 4  # At least one per bucket
    
    def test_observe_with_labels(self):
        """Test observing with labels."""
        histogram = Histogram(
            "test_histogram",
            "Test",
            labels=["method"],
            buckets=[1.0],
        )
        histogram.observe(0.5, labels={"method": "GET"})
        histogram.observe(2.0, labels={"method": "POST"})
        
        samples = histogram.collect()
        assert len(samples) > 0
    
    def test_time_context_manager(self):
        """Test time() context manager."""
        histogram = Histogram("test_histogram", "Test")
        
        with histogram.time():
            time.sleep(0.01)  # 10ms
        
        samples = histogram.collect()
        sum_sample = next(s for s in samples if "_sum" in s.name)
        assert sum_sample.value >= 0.01


class TestMetricsCollector:
    """Tests for MetricsCollector."""
    
    def test_create_collector(self):
        """Test collector creation."""
        collector = MetricsCollector()
        assert collector is not None
    
    def test_create_counter(self):
        """Test creating counter via collector."""
        collector = MetricsCollector()
        counter = collector.counter("test_counter", "Test", labels=["method"])
        
        assert counter.name == "test_counter"
        counter.inc(labels={"method": "GET"})
        
        samples = collector.collect()
        assert len(samples) >= 1
    
    def test_create_gauge(self):
        """Test creating gauge via collector."""
        collector = MetricsCollector()
        gauge = collector.gauge("test_gauge", "Test")
        
        gauge.set(42)
        
        samples = collector.collect()
        assert len(samples) >= 1
    
    def test_create_histogram(self):
        """Test creating histogram via collector."""
        collector = MetricsCollector()
        histogram = collector.histogram(
            "test_histogram",
            "Test",
            buckets=[0.1, 0.5, 1.0],
        )
        
        histogram.observe(0.3)
        
        samples = collector.collect()
        assert len(samples) >= 1
    
    def test_get_or_create(self):
        """Test that collector returns existing metric."""
        collector = MetricsCollector()
        counter1 = collector.counter("test_counter", "Test")
        counter2 = collector.counter("test_counter", "Test")
        
        assert counter1 is counter2
    
    def test_collect_all_metrics(self):
        """Test collecting all metrics."""
        collector = MetricsCollector()
        counter = collector.counter("test_counter", "Test")
        gauge = collector.gauge("test_gauge", "Test")
        
        counter.inc()
        gauge.set(42)
        
        samples = collector.collect()
        assert len(samples) >= 2


class TestCreateDefaultMetrics:
    """Tests for default agent metrics."""
    
    def test_creates_all_metrics(self):
        """Test that all default metrics are created."""
        collector = MetricsCollector()
        metrics = create_default_metrics(collector)
        
        assert "agent_requests_total" in metrics
        assert "agent_request_duration_seconds" in metrics
        assert "agent_tokens_total" in metrics
        assert "agent_errors_total" in metrics
        assert "active_agents" in metrics
    
    def test_default_metrics_work(self):
        """Test that default metrics can be used."""
        collector = MetricsCollector()
        metrics = create_default_metrics(collector)
        
        # Use the metrics
        metrics["agent_requests_total"].inc(labels={"agent_name": "test", "status": "success"})
        metrics["active_agents"].inc()
        metrics["agent_request_duration_seconds"].observe(0.5, labels={"agent_name": "test"})
        
        samples = collector.collect()
        assert len(samples) >= 3


class TestHealthCheck:
    """Tests for HealthCheck."""
    
    @pytest.mark.asyncio
    async def test_create_health_check(self):
        """Test health check creation."""
        health = HealthCheck(name="test-service", version="1.0.0")
        assert health.name == "test-service"
        assert health.version == "1.0.0"
    
    @pytest.mark.asyncio
    async def test_add_sync_check(self):
        """Test adding a sync health check."""
        health = HealthCheck()
        
        def check_db():
            return {"status": "healthy", "latency_ms": 5}
        
        health.add_check("database", check_db)
        result = await health.run_checks()
        
        assert result.status == HealthStatus.HEALTHY
        assert "database" in result.checks
        assert result.checks["database"]["status"] == "healthy"
    
    @pytest.mark.asyncio
    async def test_add_async_check(self):
        """Test adding an async health check."""
        health = HealthCheck()
        
        async def check_redis():
            await asyncio.sleep(0.001)
            return {"status": "healthy", "connections": 10}
        
        health.add_check("redis", check_redis)
        result = await health.run_checks()
        
        assert result.status == HealthStatus.HEALTHY
        assert "redis" in result.checks
    
    @pytest.mark.asyncio
    async def test_failing_check(self):
        """Test that failing check results in unhealthy status."""
        health = HealthCheck()
        
        async def check_failing():
            raise Exception("Connection refused")
        
        health.add_check("failing_service", check_failing)
        result = await health.run_checks()
        
        assert result.status == HealthStatus.UNHEALTHY
        assert "failing_service" in result.checks
        assert result.checks["failing_service"]["status"] == "unhealthy"
        # Implementation uses 'message' key for error details
        assert "message" in result.checks["failing_service"]
    
    @pytest.mark.asyncio
    async def test_mixed_checks(self):
        """Test mixed healthy and unhealthy checks."""
        health = HealthCheck()
        
        health.add_check("healthy", lambda: {"status": "healthy"})
        health.add_check("unhealthy", lambda: (_ for _ in ()).throw(Exception("fail")))
        
        result = await health.run_checks()
        
        # Overall status should be unhealthy
        assert result.status in [HealthStatus.UNHEALTHY, HealthStatus.DEGRADED]
    
    @pytest.mark.asyncio
    async def test_timeout_check(self):
        """Test that slow checks timeout."""
        health = HealthCheck()
        
        async def slow_check():
            await asyncio.sleep(10)  # 10 seconds
            return {"status": "healthy"}
        
        health.add_check("slow", slow_check)
        result = await health.run_checks(timeout=0.1)  # 100ms timeout
        
        assert "slow" in result.checks
        assert result.checks["slow"]["status"] == "unhealthy"
        # Implementation uses 'message' key and 'timed out' phrasing
        assert "timed out" in result.checks["slow"].get("message", "").lower()
    
    @pytest.mark.asyncio
    async def test_remove_check(self):
        """Test removing a health check."""
        health = HealthCheck()
        health.add_check("test", lambda: {"status": "healthy"})
        health.remove_check("test")
        
        result = await health.run_checks()
        assert "test" not in result.checks
    
    @pytest.mark.asyncio
    async def test_result_to_dict(self):
        """Test HealthResult.to_dict()."""
        health = HealthCheck()
        health.add_check("test", lambda: {"status": "healthy"})
        
        result = await health.run_checks()
        result_dict = result.to_dict()
        
        assert "status" in result_dict
        assert "checks" in result_dict
        assert "timestamp" in result_dict
        assert "duration_ms" in result_dict
    
    @pytest.mark.asyncio
    async def test_is_healthy_property(self):
        """Test is_healthy property."""
        result_healthy = HealthResult(status=HealthStatus.HEALTHY)
        result_unhealthy = HealthResult(status=HealthStatus.UNHEALTHY)
        result_degraded = HealthResult(status=HealthStatus.DEGRADED)
        
        assert result_healthy.is_healthy is True
        assert result_unhealthy.is_healthy is False
        assert result_degraded.is_healthy is False
    
    @pytest.mark.asyncio
    async def test_duration_tracking(self):
        """Test that check duration is tracked."""
        health = HealthCheck()
        
        async def slow_check():
            await asyncio.sleep(0.05)  # 50ms
            return {"status": "healthy"}
        
        health.add_check("slow", slow_check)
        result = await health.run_checks()
        
        assert result.duration_ms >= 50  # At least 50ms
    
    @pytest.mark.asyncio
    async def test_multiple_checks(self):
        """Test running multiple checks."""
        health = HealthCheck()
        
        health.add_check("check1", lambda: {"status": "healthy"})
        health.add_check("check2", lambda: {"status": "healthy"})
        health.add_check("check3", lambda: {"status": "healthy"})
        
        result = await health.run_checks()
        
        assert result.status == HealthStatus.HEALTHY
        assert len(result.checks) == 3


class TestHealthStatus:
    """Tests for HealthStatus enum."""
    
    def test_status_values(self):
        """Test status enum values."""
        assert HealthStatus.HEALTHY.value == "healthy"
        assert HealthStatus.DEGRADED.value == "degraded"
        assert HealthStatus.UNHEALTHY.value == "unhealthy"
    
    def test_status_is_string(self):
        """Test that status inherits from str."""
        assert isinstance(HealthStatus.HEALTHY, str)
        assert HealthStatus.HEALTHY == "healthy"
