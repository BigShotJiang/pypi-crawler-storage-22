"""
Tests for the multimodal module.

Tests cover:
- MediaContent creation and conversion
- MultimodalMessage creation and provider formats
- Base64 encoding/decoding
- URL utilities
- Image/Audio/Video processing
"""

import base64
import io
import os
import pytest
import struct
import tempfile
from pathlib import Path
from unittest.mock import patch, MagicMock

from multi_agent_base.multimodal import (
    # Core types
    MediaContent,
    MultimodalMessage,
    MediaType,
    # Format enums
    ImageFormat,
    AudioFormat,
    VideoFormat,
    DocumentFormat,
    # Provider capabilities
    PROVIDER_CAPABILITIES,
    # Encoders
    Base64Encoder,
    DecodedDataURI,
    URLEncoder,
    ContentHasher,
    MIMETypeDetector,
    # Info types
    ImageDimensions,
    AudioInfo,
    VideoInfo,
    ProcessingResult,
    # Processor classes
    ImageProcessor,
    AudioProcessor,
    VideoProcessor,
    MediaProcessor,
    # Convenience functions
    get_image_dimensions,
    get_audio_info,
    get_video_info,
    is_valid_image,
    is_valid_audio,
    is_valid_video,
)


# =============================================================================
# Test Fixtures
# =============================================================================

# Minimal valid PNG image (1x1 red pixel)
MINIMAL_PNG = bytes([
    0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A,  # PNG signature
    0x00, 0x00, 0x00, 0x0D, 0x49, 0x48, 0x44, 0x52,  # IHDR chunk
    0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01,  # 1x1 dimensions
    0x08, 0x02, 0x00, 0x00, 0x00, 0x90, 0x77, 0x53,  # 8-bit RGB
    0xDE, 0x00, 0x00, 0x00, 0x0C, 0x49, 0x44, 0x41,  # IDAT chunk
    0x54, 0x08, 0xD7, 0x63, 0xF8, 0xCF, 0xC0, 0x00,
    0x00, 0x00, 0x03, 0x00, 0x01, 0x00, 0x18, 0xDD,
    0x8D, 0xB4, 0x00, 0x00, 0x00, 0x00, 0x49, 0x45,  # IEND chunk
    0x4E, 0x44, 0xAE, 0x42, 0x60, 0x82,
])

# Minimal valid JPEG (simplified header)
MINIMAL_JPEG = bytes([
    0xFF, 0xD8, 0xFF, 0xE0, 0x00, 0x10, 0x4A, 0x46,  # SOI + APP0
    0x49, 0x46, 0x00, 0x01, 0x01, 0x00, 0x00, 0x01,
    0x00, 0x01, 0x00, 0x00, 0xFF, 0xC0, 0x00, 0x0B,  # SOF0
    0x08, 0x00, 0x02, 0x00, 0x02, 0x01, 0x01, 0x11,  # 2x2 dimensions
    0x00, 0xFF, 0xD9,  # EOI
])

# Minimal valid GIF (1x1)
MINIMAL_GIF = bytes([
    0x47, 0x49, 0x46, 0x38, 0x39, 0x61,  # GIF89a
    0x01, 0x00, 0x01, 0x00,  # 1x1 dimensions
    0x00, 0x00, 0x00,  # Global color table info
    0x2C, 0x00, 0x00, 0x00, 0x00,  # Image descriptor
    0x01, 0x00, 0x01, 0x00, 0x00,
    0x02, 0x02, 0x44, 0x01, 0x00,  # Image data
    0x3B,  # Trailer
])


@pytest.fixture
def png_data():
    """Minimal valid PNG image."""
    return MINIMAL_PNG


@pytest.fixture
def jpeg_data():
    """Minimal valid JPEG image."""
    return MINIMAL_JPEG


@pytest.fixture
def gif_data():
    """Minimal valid GIF image."""
    return MINIMAL_GIF


@pytest.fixture
def temp_png_file(png_data):
    """Create a temporary PNG file."""
    with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as f:
        f.write(png_data)
        path = f.name
    yield path
    os.unlink(path)


@pytest.fixture
def temp_jpeg_file(jpeg_data):
    """Create a temporary JPEG file."""
    with tempfile.NamedTemporaryFile(suffix=".jpg", delete=False) as f:
        f.write(jpeg_data)
        path = f.name
    yield path
    os.unlink(path)


# =============================================================================
# MediaContent Tests
# =============================================================================

class TestMediaContent:
    """Tests for MediaContent class."""
    
    def test_from_bytes_png(self, png_data):
        """Test creating MediaContent from PNG bytes."""
        content = MediaContent.from_bytes(png_data, "image/png", "test.png")
        
        assert content.media_type == MediaType.IMAGE
        assert content.mime_type == "image/png"
        assert content.data == png_data
        assert content.filename == "test.png"
        assert content.size_bytes == len(png_data)
    
    def test_from_file(self, temp_png_file):
        """Test creating MediaContent from file."""
        content = MediaContent.from_file(temp_png_file)
        
        assert content.media_type == MediaType.IMAGE
        assert content.mime_type == "image/png"
        assert content.data is not None
        assert content.filename == Path(temp_png_file).name
    
    def test_from_file_not_found(self):
        """Test FileNotFoundError for missing file."""
        with pytest.raises(FileNotFoundError):
            MediaContent.from_file("/nonexistent/path/image.png")
    
    def test_from_url(self):
        """Test creating MediaContent from URL."""
        url = "https://example.com/images/photo.jpg"
        content = MediaContent.from_url(url)
        
        assert content.media_type == MediaType.IMAGE
        assert content.mime_type == "image/jpeg"
        assert content.url == url
        assert content.data is None
        assert content.filename == "photo.jpg"
    
    def test_from_url_with_query(self):
        """Test URL parsing with query parameters."""
        url = "https://example.com/image.png?size=large&format=webp"
        content = MediaContent.from_url(url)
        
        assert content.filename == "image.png"
        assert content.mime_type == "image/png"
    
    def test_from_base64(self, png_data):
        """Test creating MediaContent from base64."""
        b64 = base64.b64encode(png_data).decode("utf-8")
        content = MediaContent.from_base64(b64, "image/png")
        
        assert content.media_type == MediaType.IMAGE
        assert content.data == png_data
    
    def test_from_base64_invalid(self):
        """Test invalid base64 raises ValueError."""
        with pytest.raises(ValueError):
            MediaContent.from_base64("not-valid-base64!!!", "image/png")
    
    def test_to_base64(self, png_data):
        """Test converting to base64."""
        content = MediaContent.from_bytes(png_data, "image/png")
        b64 = content.to_base64()
        
        decoded = base64.b64decode(b64)
        assert decoded == png_data
    
    def test_to_base64_url_only_raises(self):
        """Test that URL-only content raises on to_base64."""
        content = MediaContent.from_url("https://example.com/image.png")
        
        with pytest.raises(ValueError, match="Cannot convert URL-based"):
            content.to_base64()
    
    def test_to_data_uri(self, png_data):
        """Test converting to data URI."""
        content = MediaContent.from_bytes(png_data, "image/png")
        uri = content.to_data_uri()
        
        assert uri.startswith("data:image/png;base64,")
    
    def test_to_openai_format_with_data(self, png_data):
        """Test OpenAI format conversion with data."""
        content = MediaContent.from_bytes(png_data, "image/png")
        result = content.to_openai_format(prefer_url=False)
        
        assert result["type"] == "image_url"
        assert result["image_url"]["url"].startswith("data:image/png;base64,")
    
    def test_to_openai_format_with_url(self):
        """Test OpenAI format conversion with URL."""
        url = "https://example.com/image.png"
        content = MediaContent.from_url(url)
        result = content.to_openai_format(prefer_url=True)
        
        assert result["type"] == "image_url"
        assert result["image_url"]["url"] == url
    
    def test_to_anthropic_format(self, png_data):
        """Test Anthropic format conversion."""
        content = MediaContent.from_bytes(png_data, "image/png")
        result = content.to_anthropic_format()
        
        assert result["type"] == "image"
        assert result["source"]["type"] == "base64"
        assert result["source"]["media_type"] == "image/png"
        assert "data" in result["source"]
    
    def test_to_ollama_format(self, png_data):
        """Test Ollama format conversion."""
        content = MediaContent.from_bytes(png_data, "image/png")
        result = content.to_ollama_format()
        
        # Ollama uses raw base64
        decoded = base64.b64decode(result)
        assert decoded == png_data
    
    def test_to_google_format_inline(self, png_data):
        """Test Google Gemini format with inline data."""
        content = MediaContent.from_bytes(png_data, "image/png")
        result = content.to_google_format(prefer_url=False)
        
        assert "inline_data" in result
        assert result["inline_data"]["mime_type"] == "image/png"
    
    def test_validate_for_provider_valid(self, png_data):
        """Test validation passes for valid content."""
        content = MediaContent.from_bytes(png_data, "image/png")
        errors = content.validate_for_provider("openai")
        
        assert len(errors) == 0
    
    def test_validate_for_provider_url_not_supported(self):
        """Test validation fails for URL when not supported."""
        content = MediaContent.from_url("https://example.com/image.png")
        errors = content.validate_for_provider("anthropic")
        
        assert len(errors) > 0
        assert any("URL" in e for e in errors)
    
    def test_validate_for_unknown_provider(self, png_data):
        """Test validation with unknown provider."""
        content = MediaContent.from_bytes(png_data, "image/png")
        errors = content.validate_for_provider("unknown_provider")
        
        assert any("Unknown provider" in e for e in errors)
    
    def test_size_properties(self, png_data):
        """Test size calculation properties."""
        content = MediaContent.from_bytes(png_data, "image/png")
        
        assert content.size_bytes == len(png_data)
        assert content.size_mb == len(png_data) / (1024 * 1024)
    
    def test_to_dict(self, png_data):
        """Test dictionary conversion."""
        content = MediaContent.from_bytes(png_data, "image/png", "test.png")
        result = content.to_dict()
        
        assert result["media_type"] == "image"
        assert result["mime_type"] == "image/png"
        assert result["has_data"] is True
        assert result["filename"] == "test.png"
    
    def test_repr(self, png_data):
        """Test string representation."""
        content = MediaContent.from_bytes(png_data, "image/png")
        repr_str = repr(content)
        
        assert "MediaContent" in repr_str
        assert "image" in repr_str
        assert "image/png" in repr_str


# =============================================================================
# MultimodalMessage Tests
# =============================================================================

class TestMultimodalMessage:
    """Tests for MultimodalMessage class."""
    
    def test_from_text(self):
        """Test creating text-only message."""
        message = MultimodalMessage.from_text("Hello, world!")
        
        assert message.text == "Hello, world!"
        assert message.role == "user"
        assert len(message.images) == 0
        assert message.has_media is False
    
    def test_from_text_with_role(self):
        """Test text message with custom role."""
        message = MultimodalMessage.from_text("I am an assistant", role="assistant")
        
        assert message.role == "assistant"
    
    def test_with_image_from_file(self, temp_png_file):
        """Test creating message with image from file."""
        message = MultimodalMessage.with_image(
            text="What's in this image?",
            image=temp_png_file
        )
        
        assert message.text == "What's in this image?"
        assert len(message.images) == 1
        assert message.has_media is True
    
    def test_with_image_from_url(self):
        """Test creating message with image from URL."""
        message = MultimodalMessage.with_image(
            text="Describe this",
            image="https://example.com/image.png"
        )
        
        assert len(message.images) == 1
        assert message.images[0].url == "https://example.com/image.png"
    
    def test_with_image_from_media_content(self, png_data):
        """Test creating message with MediaContent."""
        content = MediaContent.from_bytes(png_data, "image/png")
        message = MultimodalMessage.with_image(
            text="Analyze",
            image=content
        )
        
        assert len(message.images) == 1
        assert message.images[0] is content
    
    def test_with_images_multiple(self, temp_png_file, temp_jpeg_file):
        """Test creating message with multiple images."""
        message = MultimodalMessage.with_images(
            text="Compare these images",
            images=[temp_png_file, temp_jpeg_file]
        )
        
        assert len(message.images) == 2
        assert message.media_count == 2
    
    def test_add_image_chaining(self, png_data):
        """Test adding images with method chaining."""
        content = MediaContent.from_bytes(png_data, "image/png")
        
        message = MultimodalMessage.from_text("Multi-image").add_image(content).add_image(content)
        
        assert len(message.images) == 2
    
    def test_empty_message_raises(self):
        """Test that empty message raises ValueError."""
        with pytest.raises(ValueError, match="at least one content"):
            MultimodalMessage()
    
    def test_to_openai_format_text_only(self):
        """Test OpenAI format for text-only message."""
        message = MultimodalMessage.from_text("Hello")
        result = message.to_openai_format()
        
        assert result["role"] == "user"
        assert result["content"] == "Hello"
    
    def test_to_openai_format_with_image(self, png_data):
        """Test OpenAI format for message with image."""
        content = MediaContent.from_bytes(png_data, "image/png")
        message = MultimodalMessage.with_image("Describe", content)
        result = message.to_openai_format()
        
        assert result["role"] == "user"
        assert isinstance(result["content"], list)
        assert len(result["content"]) == 2
        assert result["content"][0]["type"] == "text"
        assert result["content"][1]["type"] == "image_url"
    
    def test_to_anthropic_format_text_only(self):
        """Test Anthropic format for text-only message."""
        message = MultimodalMessage.from_text("Hello")
        result = message.to_anthropic_format()
        
        assert result["role"] == "user"
        assert result["content"] == "Hello"
    
    def test_to_anthropic_format_with_image(self, png_data):
        """Test Anthropic format for message with image."""
        content = MediaContent.from_bytes(png_data, "image/png")
        message = MultimodalMessage.with_image("Describe", content)
        result = message.to_anthropic_format()
        
        assert result["role"] == "user"
        assert isinstance(result["content"], list)
        # Anthropic puts images first
        assert result["content"][0]["type"] == "image"
        assert result["content"][1]["type"] == "text"
    
    def test_to_ollama_format(self, png_data):
        """Test Ollama format conversion."""
        content = MediaContent.from_bytes(png_data, "image/png")
        message = MultimodalMessage.with_image("Describe", content)
        result = message.to_ollama_format()
        
        assert result["role"] == "user"
        assert result["content"] == "Describe"
        assert "images" in result
        assert len(result["images"]) == 1
    
    def test_to_google_format(self, png_data):
        """Test Google Gemini format conversion."""
        content = MediaContent.from_bytes(png_data, "image/png")
        message = MultimodalMessage.with_image("Describe", content)
        result = message.to_google_format()
        
        # Google uses "model" instead of "assistant"
        assert result["role"] == "user"
        assert "parts" in result
    
    def test_to_provider_format(self, png_data):
        """Test generic provider format conversion."""
        content = MediaContent.from_bytes(png_data, "image/png")
        message = MultimodalMessage.with_image("Describe", content)
        
        openai = message.to_provider_format("openai")
        anthropic = message.to_provider_format("anthropic")
        
        assert "content" in openai
        assert "content" in anthropic
    
    def test_to_provider_format_unknown_raises(self):
        """Test unknown provider raises ValueError."""
        message = MultimodalMessage.from_text("Hello")
        
        with pytest.raises(ValueError, match="Unsupported provider"):
            message.to_provider_format("unknown_provider")
    
    def test_validate_for_provider(self, png_data):
        """Test message validation for provider."""
        content = MediaContent.from_bytes(png_data, "image/png")
        message = MultimodalMessage.with_image("Describe", content)
        
        errors = message.validate_for_provider("openai")
        assert len(errors) == 0
    
    def test_media_count(self, png_data):
        """Test media count calculation."""
        content = MediaContent.from_bytes(png_data, "image/png")
        message = MultimodalMessage(
            text="Test",
            images=[content, content],
            documents=[content]
        )
        
        assert message.media_count == 3
    
    def test_to_dict(self, png_data):
        """Test dictionary conversion."""
        content = MediaContent.from_bytes(png_data, "image/png")
        message = MultimodalMessage.with_image("Describe", content)
        result = message.to_dict()
        
        assert result["role"] == "user"
        assert result["text"] == "Describe"
        assert result["has_media"] is True
        assert result["media_count"] == 1
    
    def test_repr(self, png_data):
        """Test string representation."""
        content = MediaContent.from_bytes(png_data, "image/png")
        message = MultimodalMessage.with_image("Describe", content)
        repr_str = repr(message)
        
        assert "MultimodalMessage" in repr_str
        assert "user" in repr_str


# =============================================================================
# Base64Encoder Tests
# =============================================================================

class TestBase64Encoder:
    """Tests for Base64Encoder class."""
    
    def test_encode_decode_roundtrip(self):
        """Test encode/decode roundtrip."""
        data = b"Hello, World!"
        encoded = Base64Encoder.encode(data)
        decoded = Base64Encoder.decode(encoded)
        
        assert decoded == data
    
    def test_encode_file(self, temp_png_file):
        """Test encoding file to base64."""
        encoded = Base64Encoder.encode_file(temp_png_file)
        decoded = base64.b64decode(encoded)
        
        with open(temp_png_file, "rb") as f:
            original = f.read()
        
        assert decoded == original
    
    def test_encode_file_not_found(self):
        """Test FileNotFoundError for missing file."""
        with pytest.raises(FileNotFoundError):
            Base64Encoder.encode_file("/nonexistent/file.txt")
    
    def test_decode_to_file(self):
        """Test decoding base64 to file."""
        data = b"Test content"
        encoded = base64.b64encode(data).decode("utf-8")
        
        with tempfile.TemporaryDirectory() as tmpdir:
            path = Path(tmpdir) / "output.txt"
            result = Base64Encoder.decode_to_file(encoded, path)
            
            assert result.exists()
            assert result.read_bytes() == data
    
    def test_to_data_uri(self, png_data):
        """Test data URI creation."""
        uri = Base64Encoder.to_data_uri(png_data, "image/png")
        
        assert uri.startswith("data:image/png;base64,")
    
    def test_file_to_data_uri(self, temp_png_file):
        """Test file to data URI conversion."""
        uri = Base64Encoder.file_to_data_uri(temp_png_file)
        
        assert uri.startswith("data:image/png;base64,")
    
    def test_from_data_uri(self, png_data):
        """Test parsing data URI."""
        uri = f"data:image/png;base64,{base64.b64encode(png_data).decode()}"
        result = Base64Encoder.from_data_uri(uri)
        
        assert result.mime_type == "image/png"
        assert result.data == png_data
        assert result.is_base64 is True
    
    def test_from_data_uri_invalid(self):
        """Test invalid data URI raises ValueError."""
        with pytest.raises(ValueError):
            Base64Encoder.from_data_uri("not-a-data-uri")
    
    def test_is_valid_base64(self):
        """Test base64 validation."""
        valid = base64.b64encode(b"test").decode()
        assert Base64Encoder.is_valid_base64(valid) is True
        assert Base64Encoder.is_valid_base64("not-valid!!!") is False
    
    def test_is_data_uri(self, png_data):
        """Test data URI detection."""
        uri = f"data:image/png;base64,{base64.b64encode(png_data).decode()}"
        
        assert Base64Encoder.is_data_uri(uri) is True
        assert Base64Encoder.is_data_uri("https://example.com") is False


# =============================================================================
# URLEncoder Tests
# =============================================================================

class TestURLEncoder:
    """Tests for URLEncoder class."""
    
    def test_is_valid_url(self):
        """Test URL validation."""
        assert URLEncoder.is_valid_url("https://example.com") is True
        assert URLEncoder.is_valid_url("http://localhost:8080/path") is True
        assert URLEncoder.is_valid_url("not-a-url") is False
        assert URLEncoder.is_valid_url("ftp://example.com") is False
    
    def test_is_image_url(self):
        """Test image URL detection."""
        assert URLEncoder.is_image_url("https://example.com/photo.jpg") is True
        assert URLEncoder.is_image_url("https://example.com/doc.pdf") is False
    
    def test_is_audio_url(self):
        """Test audio URL detection."""
        assert URLEncoder.is_audio_url("https://example.com/song.mp3") is True
        assert URLEncoder.is_audio_url("https://example.com/video.mp4") is False
    
    def test_is_video_url(self):
        """Test video URL detection."""
        assert URLEncoder.is_video_url("https://example.com/video.mp4") is True
        assert URLEncoder.is_video_url("https://example.com/audio.mp3") is False
    
    def test_get_extension(self):
        """Test extension extraction."""
        assert URLEncoder.get_extension("https://example.com/image.png") == ".png"
        assert URLEncoder.get_extension("https://example.com/no-ext") is None
    
    def test_get_filename(self):
        """Test filename extraction."""
        assert URLEncoder.get_filename("https://example.com/path/file.jpg") == "file.jpg"
    
    def test_get_mime_type(self):
        """Test MIME type guessing from URL."""
        assert URLEncoder.get_mime_type("https://example.com/image.png") == "image/png"
    
    def test_encode_query(self):
        """Test query string encoding."""
        result = URLEncoder.encode_query({"key": "value", "q": "hello world"})
        assert "key=value" in result
        assert "hello" in result
    
    def test_build_url(self):
        """Test URL building."""
        url = URLEncoder.build_url(
            "https://api.example.com",
            "/v1/search",
            {"q": "test"}
        )
        assert url.startswith("https://api.example.com/v1/search")
        assert "q=test" in url
    
    def test_normalize_url(self):
        """Test URL normalization."""
        normalized = URLEncoder.normalize_url("HTTPS://EXAMPLE.COM:443/path/")
        assert normalized == "https://example.com/path"


# =============================================================================
# ContentHasher Tests
# =============================================================================

class TestContentHasher:
    """Tests for ContentHasher class."""
    
    def test_hash_bytes(self):
        """Test bytes hashing."""
        data = b"Hello, World!"
        hash1 = ContentHasher.hash_bytes(data)
        hash2 = ContentHasher.hash_bytes(data)
        
        assert hash1 == hash2
        assert len(hash1) == 64  # SHA256 hex digest
    
    def test_hash_bytes_different_algorithm(self):
        """Test hashing with different algorithms."""
        data = b"Test"
        sha256 = ContentHasher.hash_bytes(data, "sha256")
        md5 = ContentHasher.hash_bytes(data, "md5")
        
        assert len(sha256) == 64
        assert len(md5) == 32
    
    def test_hash_file(self, temp_png_file):
        """Test file hashing."""
        hash_val = ContentHasher.hash_file(temp_png_file)
        assert len(hash_val) == 64
    
    def test_compare(self):
        """Test content comparison."""
        data1 = b"Same content"
        data2 = b"Same content"
        data3 = b"Different content"
        
        assert ContentHasher.compare(data1, data2) is True
        assert ContentHasher.compare(data1, data3) is False
    
    def test_generate_content_id(self):
        """Test content ID generation."""
        data = b"Test content"
        content_id = ContentHasher.generate_content_id(data)
        
        assert len(content_id) == 16


# =============================================================================
# MIMETypeDetector Tests
# =============================================================================

class TestMIMETypeDetector:
    """Tests for MIMETypeDetector class."""
    
    def test_from_bytes_png(self, png_data):
        """Test PNG detection from bytes."""
        mime = MIMETypeDetector.from_bytes(png_data)
        assert mime == "image/png"
    
    def test_from_bytes_jpeg(self, jpeg_data):
        """Test JPEG detection from bytes."""
        mime = MIMETypeDetector.from_bytes(jpeg_data)
        assert mime == "image/jpeg"
    
    def test_from_bytes_gif(self, gif_data):
        """Test GIF detection from bytes."""
        mime = MIMETypeDetector.from_bytes(gif_data)
        assert mime == "image/gif"
    
    def test_from_bytes_unknown(self):
        """Test unknown format returns None."""
        mime = MIMETypeDetector.from_bytes(b"unknown data format")
        assert mime is None
    
    def test_from_file(self, temp_png_file):
        """Test MIME detection from file."""
        mime = MIMETypeDetector.from_file(temp_png_file)
        assert mime == "image/png"
    
    def test_from_extension(self):
        """Test MIME type from extension."""
        assert MIMETypeDetector.from_extension(".png") == "image/png"
        assert MIMETypeDetector.from_extension("jpg") == "image/jpeg"
    
    def test_get_extension(self):
        """Test extension from MIME type."""
        assert MIMETypeDetector.get_extension("image/png") == ".png"
    
    def test_is_image(self):
        """Test image MIME type check."""
        assert MIMETypeDetector.is_image("image/png") is True
        assert MIMETypeDetector.is_image("audio/mp3") is False
    
    def test_is_audio(self):
        """Test audio MIME type check."""
        assert MIMETypeDetector.is_audio("audio/mpeg") is True
        assert MIMETypeDetector.is_audio("image/png") is False
    
    def test_is_video(self):
        """Test video MIME type check."""
        assert MIMETypeDetector.is_video("video/mp4") is True
        assert MIMETypeDetector.is_video("audio/mp3") is False


# =============================================================================
# ImageProcessor Tests
# =============================================================================

class TestImageProcessor:
    """Tests for ImageProcessor class."""
    
    def test_get_dimensions_png(self, png_data):
        """Test getting PNG dimensions."""
        dims = ImageProcessor.get_dimensions(png_data)
        
        assert dims is not None
        assert dims.width == 1
        assert dims.height == 1
    
    def test_get_dimensions_jpeg(self, jpeg_data):
        """Test getting JPEG dimensions."""
        dims = ImageProcessor.get_dimensions(jpeg_data)
        
        assert dims is not None
        assert dims.width == 2
        assert dims.height == 2
    
    def test_get_dimensions_gif(self, gif_data):
        """Test getting GIF dimensions."""
        dims = ImageProcessor.get_dimensions(gif_data)
        
        assert dims is not None
        assert dims.width == 1
        assert dims.height == 1
    
    def test_get_dimensions_invalid(self):
        """Test invalid data returns None."""
        dims = ImageProcessor.get_dimensions(b"not an image")
        assert dims is None
    
    def test_is_valid_image(self, png_data, jpeg_data):
        """Test image validation."""
        assert ImageProcessor.is_valid_image(png_data) is True
        assert ImageProcessor.is_valid_image(jpeg_data) is True
        assert ImageProcessor.is_valid_image(b"not an image") is False
    
    def test_get_format(self, png_data, jpeg_data):
        """Test format detection."""
        assert ImageProcessor.get_format(png_data) == ImageFormat.PNG
        assert ImageProcessor.get_format(jpeg_data) == ImageFormat.JPEG
    
    def test_validate_for_provider(self, png_data):
        """Test provider validation."""
        content = MediaContent.from_bytes(png_data, "image/png")
        is_valid, errors = ImageProcessor.validate_for_provider(content, "openai")
        
        assert is_valid is True
        assert len(errors) == 0
    
    def test_prepare_for_provider(self, png_data):
        """Test preparing content for provider."""
        content = MediaContent.from_bytes(png_data, "image/png")
        result = ImageProcessor.prepare_for_provider(content, "openai")
        
        assert result.success is True
        assert result.data == png_data


# =============================================================================
# ImageDimensions Tests
# =============================================================================

class TestImageDimensions:
    """Tests for ImageDimensions class."""
    
    def test_aspect_ratio(self):
        """Test aspect ratio calculation."""
        dims = ImageDimensions(1920, 1080)
        assert abs(dims.aspect_ratio - 16/9) < 0.01
    
    def test_orientation(self):
        """Test orientation detection."""
        landscape = ImageDimensions(1920, 1080)
        portrait = ImageDimensions(1080, 1920)
        square = ImageDimensions(1000, 1000)
        
        assert landscape.is_landscape is True
        assert portrait.is_portrait is True
        assert square.is_square is True
    
    def test_fits_in(self):
        """Test dimension fitting."""
        dims = ImageDimensions(800, 600)
        
        assert dims.fits_in(1000, 1000) is True
        assert dims.fits_in(400, 400) is False
    
    def test_scale_to_fit(self):
        """Test scaling to fit."""
        dims = ImageDimensions(1000, 500)
        scaled = dims.scale_to_fit(500, 500)
        
        assert scaled.width == 500
        assert scaled.height == 250


# =============================================================================
# AudioProcessor Tests
# =============================================================================

class TestAudioProcessor:
    """Tests for AudioProcessor class."""
    
    def test_is_valid_audio(self):
        """Test audio validation."""
        # MP3 header
        mp3_data = b"\xff\xfb" + b"\x00" * 100
        assert AudioProcessor.is_valid_audio(mp3_data) is True
        assert AudioProcessor.is_valid_audio(b"not audio") is False
    
    def test_get_format(self):
        """Test format detection."""
        mp3_data = b"\xff\xfb" + b"\x00" * 100
        fmt = AudioProcessor.get_format(mp3_data)
        assert fmt == AudioFormat.MP3


# =============================================================================
# MediaProcessor Tests
# =============================================================================

class TestMediaProcessor:
    """Tests for MediaProcessor class."""
    
    def test_get_info_image(self, png_data):
        """Test getting image info."""
        content = MediaContent.from_bytes(png_data, "image/png")
        processor = MediaProcessor()
        info = processor.get_info(content)
        
        assert isinstance(info, ImageDimensions)
    
    def test_validate(self, png_data):
        """Test content validation."""
        content = MediaContent.from_bytes(png_data, "image/png")
        processor = MediaProcessor()
        is_valid, errors = processor.validate(content, "openai")
        
        assert is_valid is True
    
    def test_process(self, png_data):
        """Test content processing."""
        content = MediaContent.from_bytes(png_data, "image/png")
        processor = MediaProcessor()
        result = processor.process(content, "openai")
        
        assert result.success is True
    
    def test_is_valid_media(self, png_data):
        """Test media validation."""
        processor = MediaProcessor()
        
        assert processor.is_valid_media(png_data) is True
        assert processor.is_valid_media(b"not media") is False
    
    def test_detect_media_type(self, png_data):
        """Test media type detection."""
        processor = MediaProcessor()
        media_type = processor.detect_media_type(png_data)
        
        assert media_type == MediaType.IMAGE


# =============================================================================
# Convenience Function Tests
# =============================================================================

class TestConvenienceFunctions:
    """Tests for module-level convenience functions."""
    
    def test_get_image_dimensions(self, png_data):
        """Test get_image_dimensions function."""
        dims = get_image_dimensions(png_data)
        assert dims.width == 1
        assert dims.height == 1
    
    def test_is_valid_image_function(self, png_data):
        """Test is_valid_image function."""
        assert is_valid_image(png_data) is True
        assert is_valid_image(b"not image") is False
    
    def test_is_valid_audio_function(self):
        """Test is_valid_audio function."""
        mp3_data = b"\xff\xfb" + b"\x00" * 100
        assert is_valid_audio(mp3_data) is True
    
    def test_is_valid_video_function(self):
        """Test is_valid_video function."""
        # Simple MP4 signature
        mp4_data = b"\x00\x00\x00\x18ftypmp42" + b"\x00" * 100
        # This won't be detected as valid with our simple parser
        assert is_valid_video(b"not video") is False


# =============================================================================
# Provider Capabilities Tests
# =============================================================================

class TestProviderCapabilities:
    """Tests for provider capabilities constants."""
    
    def test_openai_capabilities(self):
        """Test OpenAI capability definition."""
        caps = PROVIDER_CAPABILITIES["openai"]
        
        assert caps["supports_url"] is True
        assert caps["supports_base64"] is True
        assert ImageFormat.PNG in caps["image_formats"]
    
    def test_anthropic_capabilities(self):
        """Test Anthropic capability definition."""
        caps = PROVIDER_CAPABILITIES["anthropic"]
        
        assert caps["supports_url"] is False
        assert caps["supports_base64"] is True
    
    def test_ollama_capabilities(self):
        """Test Ollama capability definition."""
        caps = PROVIDER_CAPABILITIES["ollama"]
        
        assert caps["supports_url"] is False
        assert ImageFormat.PNG in caps["image_formats"]
    
    def test_google_capabilities(self):
        """Test Google capability definition."""
        caps = PROVIDER_CAPABILITIES["google"]
        
        assert caps["supports_url"] is True
        assert VideoFormat.MP4 in caps["video_formats"]
