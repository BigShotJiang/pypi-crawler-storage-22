"""
Tests for the observability module.

Tests cover:
- LogEvent
- LogLevel
- EventType
- Log formatters
- Log handlers
- AgentLogger
- PhoenixTracer
- PhoenixConfig
"""

import pytest
import json
from datetime import datetime
from unittest.mock import MagicMock, patch
from io import StringIO

from multi_agent_base.observability import (
    PhoenixTracer,
    setup_phoenix,
    AgentLogger,
    LogEvent,
)
from multi_agent_base.observability.logger import (
    LogLevel,
    EventType,
    JSONFormatter,
    ConsoleFormatter,
    StreamHandler,
    FileHandler,
    LogHandler,
)


# ============================================================================
# LogLevel Tests
# ============================================================================

class TestLogLevel:
    """Tests for LogLevel enum."""
    
    def test_log_levels_exist(self):
        """Test all log levels are defined."""
        assert LogLevel.DEBUG == "debug"
        assert LogLevel.INFO == "info"
        assert LogLevel.WARNING == "warning"
        assert LogLevel.ERROR == "error"
        assert LogLevel.CRITICAL == "critical"
    
    def test_log_level_ordering(self):
        """Test log levels can be compared."""
        levels = list(LogLevel)
        assert levels.index(LogLevel.DEBUG) < levels.index(LogLevel.ERROR)


# ============================================================================
# EventType Tests
# ============================================================================

class TestEventType:
    """Tests for EventType enum."""
    
    def test_event_types_exist(self):
        """Test event types are defined."""
        assert EventType.AGENT_START == "agent.start"
        assert EventType.AGENT_END == "agent.end"
        assert EventType.TOOL_CALL == "tool.call"
        assert EventType.LLM_REQUEST == "llm.request"
    
    def test_all_event_types(self):
        """Test all expected event types exist."""
        event_types = [
            "agent.start", "agent.end", "agent.error",
            "message.in", "message.out",
            "tool.call", "tool.result", "tool.error",
            "llm.request", "llm.response",
            "handoff",
            "pattern.start", "pattern.end",
        ]
        
        for et in event_types:
            assert EventType(et) is not None


# ============================================================================
# LogEvent Tests
# ============================================================================

class TestLogEvent:
    """Tests for LogEvent."""
    
    def test_create_log_event(self):
        """Test creating a log event."""
        event = LogEvent(
            event_type=EventType.AGENT_START,
            agent_name="test-agent",
            message="Agent started",
        )
        
        assert event.event_type == EventType.AGENT_START
        assert event.agent_name == "test-agent"
        assert event.message == "Agent started"
    
    def test_log_event_with_data(self):
        """Test log event with additional data."""
        event = LogEvent(
            event_type=EventType.TOOL_CALL,
            agent_name="test-agent",
            message="Calling tool",
            data={"tool_name": "search", "args": {"query": "test"}},
        )
        
        assert event.data["tool_name"] == "search"
        assert event.data["args"]["query"] == "test"
    
    def test_log_event_with_trace_info(self):
        """Test log event with trace information."""
        event = LogEvent(
            event_type=EventType.LLM_REQUEST,
            agent_name="test-agent",
            trace_id="trace-123",
            span_id="span-456",
        )
        
        assert event.trace_id == "trace-123"
        assert event.span_id == "span-456"
    
    def test_log_event_with_duration(self):
        """Test log event with duration."""
        event = LogEvent(
            event_type=EventType.AGENT_END,
            agent_name="test-agent",
            duration_ms=150.5,
        )
        
        assert event.duration_ms == 150.5
    
    def test_log_event_with_error(self):
        """Test log event with error."""
        event = LogEvent(
            event_type=EventType.AGENT_ERROR,
            agent_name="test-agent",
            error="Connection timeout",
        )
        
        assert event.error == "Connection timeout"
    
    def test_log_event_to_dict(self):
        """Test converting log event to dictionary."""
        event = LogEvent(
            event_type=EventType.MESSAGE_OUT,
            agent_name="test-agent",
            message="Response sent",
            data={"content": "Hello"},
        )
        
        d = event.to_dict()
        
        assert d["event_type"] == "message.out"
        assert d["agent_name"] == "test-agent"
        assert d["message"] == "Response sent"
        assert d["data"]["content"] == "Hello"
        assert "timestamp" in d
    
    def test_log_event_to_json(self):
        """Test converting log event to JSON."""
        event = LogEvent(
            event_type=EventType.AGENT_START,
            agent_name="test-agent",
        )
        
        json_str = event.to_json()
        parsed = json.loads(json_str)
        
        assert parsed["event_type"] == "agent.start"
        assert parsed["agent_name"] == "test-agent"
    
    def test_log_event_timestamp_default(self):
        """Test log event has default timestamp."""
        event = LogEvent(
            event_type=EventType.AGENT_START,
            agent_name="agent",
        )
        
        assert event.timestamp is not None
        assert isinstance(event.timestamp, datetime)


# ============================================================================
# Formatter Tests
# ============================================================================

class TestFormatters:
    """Tests for log formatters."""
    
    def test_json_formatter(self):
        """Test JSON formatter."""
        formatter = JSONFormatter()
        
        event = LogEvent(
            event_type=EventType.AGENT_START,
            agent_name="test-agent",
            message="Started",
        )
        
        formatted = formatter.format(event)
        parsed = json.loads(formatted)
        
        assert parsed["event_type"] == "agent.start"
        assert parsed["agent_name"] == "test-agent"
    
    def test_json_formatter_pretty(self):
        """Test JSON formatter with pretty print."""
        formatter = JSONFormatter(pretty=True)
        
        event = LogEvent(
            event_type=EventType.AGENT_START,
            agent_name="test-agent",
        )
        
        formatted = formatter.format(event)
        
        # Pretty printed should have newlines
        assert "\n" in formatted
    
    def test_console_formatter(self):
        """Test console formatter."""
        formatter = ConsoleFormatter(colors=False)
        
        event = LogEvent(
            event_type=EventType.AGENT_START,
            agent_name="test-agent",
            message="Agent started",
            level=LogLevel.INFO,
        )
        
        formatted = formatter.format(event)
        
        assert "test-agent" in formatted
        assert "agent.start" in formatted
    
    def test_console_formatter_with_colors(self):
        """Test console formatter with colors."""
        formatter = ConsoleFormatter(colors=True)
        
        event = LogEvent(
            event_type=EventType.AGENT_ERROR,
            agent_name="test-agent",
            level=LogLevel.ERROR,
        )
        
        formatted = formatter.format(event)
        
        # Should contain ANSI color codes
        assert "\033[" in formatted


# ============================================================================
# Handler Tests
# ============================================================================

class TestHandlers:
    """Tests for log handlers."""
    
    def test_stream_handler(self):
        """Test stream handler."""
        output = StringIO()
        handler = StreamHandler(stream=output)
        
        event = LogEvent(
            event_type=EventType.AGENT_START,
            agent_name="test-agent",
            level=LogLevel.INFO,
        )
        
        handler.handle(event)
        
        output_str = output.getvalue()
        assert len(output_str) > 0
    
    def test_handler_min_level(self):
        """Test handler respects minimum level."""
        output = StringIO()
        handler = StreamHandler(stream=output, min_level=LogLevel.ERROR)
        
        # This should be ignored (below min level)
        debug_event = LogEvent(
            event_type=EventType.AGENT_START,
            agent_name="test-agent",
            level=LogLevel.DEBUG,
        )
        handler.handle(debug_event)
        
        # This should be logged
        error_event = LogEvent(
            event_type=EventType.AGENT_ERROR,
            agent_name="test-agent",
            level=LogLevel.ERROR,
        )
        handler.handle(error_event)
        
        output_str = output.getvalue()
        # Should only have one event logged
        assert "error" in output_str.lower() or "agent" in output_str
    
    def test_file_handler(self):
        """Test file handler."""
        import tempfile
        import os
        
        with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.log') as f:
            temp_path = f.name
        
        try:
            handler = FileHandler(path=temp_path)
            
            event = LogEvent(
                event_type=EventType.AGENT_START,
                agent_name="test-agent",
            )
            
            handler.handle(event)
            
            with open(temp_path) as f:
                content = f.read()
                assert "test-agent" in content
        finally:
            if os.path.exists(temp_path):
                os.remove(temp_path)


# ============================================================================
# AgentLogger Tests
# ============================================================================

class TestAgentLogger:
    """Tests for AgentLogger."""
    
    @pytest.fixture
    def logger(self):
        """Create an agent logger."""
        output = StringIO()
        handler = StreamHandler(stream=output, min_level=LogLevel.DEBUG)
        return AgentLogger(handlers=[handler])
    
    def test_create_logger(self, logger):
        """Test creating a logger."""
        assert logger is not None
    
    def test_log_agent_start(self, logger):
        """Test logging agent start."""
        # Should not raise
        logger.log_agent_start("test-agent")
    
    def test_log_agent_end(self, logger):
        """Test logging agent end."""
        logger.log_agent_end("test-agent", duration_ms=100.0)
    
    def test_log_tool_call(self, logger):
        """Test logging tool call."""
        logger.log_tool_call(
            agent_name="test-agent",
            tool_name="search",
            arguments={"query": "test"},
        )
    
    def test_log_tool_call_with_result(self, logger):
        """Test logging tool call with result."""
        logger.log_tool_call(
            agent_name="test-agent",
            tool_name="search",
            arguments={"query": "test"},
            result={"results": ["item1"]},
            duration_ms=50.0,
        )
    
    def test_log_llm_call(self, logger):
        """Test logging LLM call."""
        logger.log_llm_call(
            agent_name="test-agent",
            model="gpt-4o",
            provider="openai",
            input_tokens=10,
            output_tokens=5,
            duration_ms=100.0,
        )
    
    def test_log_llm_call_with_cost(self, logger):
        """Test logging LLM call with cost."""
        logger.log_llm_call(
            agent_name="test-agent",
            model="gpt-4o",
            provider="openai",
            input_tokens=100,
            output_tokens=50,
            duration_ms=200.0,
            cost=0.005,
        )
    
    def test_log_handoff(self, logger):
        """Test logging handoff."""
        logger.log_handoff(
            from_agent="agent1",
            to_agent="agent2",
            reason="Needs specialist",
        )
    
    def test_add_handler(self, logger):
        """Test adding handler."""
        new_handler = StreamHandler()
        logger.add_handler(new_handler)
        
        assert new_handler in logger.handlers


# ============================================================================
# PhoenixTracer Tests
# ============================================================================

class TestPhoenixTracer:
    """Tests for PhoenixTracer."""
    
    def test_create_tracer(self):
        """Test creating a Phoenix tracer."""
        tracer = PhoenixTracer()
        assert tracer is not None
    
    def test_tracer_config(self):
        """Test tracer with configuration."""
        from multi_agent_base.observability.phoenix import PhoenixConfig
        
        config = PhoenixConfig(
            project_name="test-project",
            enabled=False,  # Don't actually connect
        )
        
        tracer = PhoenixTracer(config=config)
        assert tracer.config.project_name == "test-project"
    
    def test_tracer_disabled(self):
        """Test tracer when disabled."""
        from multi_agent_base.observability.phoenix import PhoenixConfig
        
        config = PhoenixConfig(enabled=False)
        tracer = PhoenixTracer(config=config)
        
        # Should work without errors even when disabled
        assert tracer.config.enabled is False


# ============================================================================
# setup_phoenix Tests
# ============================================================================

class TestSetupPhoenix:
    """Tests for setup_phoenix function."""
    
    def test_setup_returns_tracer(self):
        """Test setup_phoenix returns a tracer."""
        # Reset singleton for testing
        PhoenixTracer._instance = None
        tracer = setup_phoenix(launch_app=False)
        
        assert tracer is not None
    
    def test_setup_with_project_name(self):
        """Test setup with project name."""
        # Reset singleton for testing
        PhoenixTracer._instance = None
        tracer = setup_phoenix(
            project_name="test-project",
            launch_app=False,
        )
        
        assert tracer.config.project_name == "test-project"


# ============================================================================
# Integration Tests
# ============================================================================

class TestObservabilityIntegration:
    """Integration tests for observability module."""
    
    def test_logger_with_multiple_handlers(self):
        """Test logger with multiple handlers."""
        output1 = StringIO()
        output2 = StringIO()
        
        logger = AgentLogger(handlers=[
            StreamHandler(stream=output1),
            StreamHandler(stream=output2),
        ])
        
        logger.log_agent_start("test-agent")
        
        # Both handlers should receive the event
        assert len(output1.getvalue()) > 0
        assert len(output2.getvalue()) > 0
    
    def test_full_agent_lifecycle_logging(self):
        """Test logging a full agent lifecycle."""
        output = StringIO()
        logger = AgentLogger(handlers=[
            StreamHandler(stream=output, formatter=JSONFormatter())
        ])
        
        # Log complete lifecycle
        logger.log_agent_start("assistant")
        logger.log_llm_call(
            agent_name="assistant",
            model="gpt-4o",
            provider="openai",
            input_tokens=50,
            output_tokens=25,
            duration_ms=100.0,
        )
        logger.log_agent_end("assistant", duration_ms=500.0)
        
        output_str = output.getvalue()
        
        # Should have all events
        assert "agent.start" in output_str
        assert "llm.response" in output_str
        assert "agent.end" in output_str


# ============================================================================
# Edge Cases
# ============================================================================

class TestObservabilityEdgeCases:
    """Edge case tests for observability module."""
    
    def test_log_empty_message(self):
        """Test logging empty message."""
        event = LogEvent(
            event_type=EventType.AGENT_START,
            agent_name="agent",
            message="",
        )
        
        assert event.message == ""
    
    def test_log_unicode_content(self):
        """Test logging Unicode content."""
        event = LogEvent(
            event_type=EventType.MESSAGE_OUT,
            agent_name="agent",
            message="Hello 🌍! 你好世界!",
        )
        
        json_str = event.to_json()
        parsed = json.loads(json_str)
        
        assert "🌍" in parsed["message"]
    
    def test_log_large_data(self):
        """Test logging large data."""
        large_data = {"items": list(range(1000))}
        
        event = LogEvent(
            event_type=EventType.TOOL_RESULT,
            agent_name="agent",
            data=large_data,
        )
        
        # Should handle without error
        d = event.to_dict()
        assert len(d["data"]["items"]) == 1000
    
    def test_special_characters_in_log(self):
        """Test logging special characters."""
        event = LogEvent(
            event_type=EventType.MESSAGE_OUT,
            agent_name="agent",
            message='Special: "quotes", \\backslash, \ttab, \nnewline',
        )
        
        # Should serialize properly
        json_str = event.to_json()
        parsed = json.loads(json_str)
        
        assert "quotes" in parsed["message"]
