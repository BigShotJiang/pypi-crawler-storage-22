"""
Tests for the providers module.

Tests cover:
- ModelClientFactory
- PricingCalculator
- ModelPricing
"""

import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from multi_agent_base.providers import (
    ModelClientFactory,
    PricingCalculator,
    ModelPricing,
)


# ============================================================================
# ModelPricing Tests
# ============================================================================

class TestModelPricing:
    """Tests for ModelPricing."""
    
    def test_create_pricing(self):
        """Test creating model pricing."""
        pricing = ModelPricing(
            input_price=2.50,
            output_price=10.00,
            context_window=128000,
        )
        
        assert pricing.input_price == 2.50
        assert pricing.output_price == 10.00
        assert pricing.context_window == 128000
    
    def test_pricing_with_notes(self):
        """Test pricing with notes."""
        pricing = ModelPricing(
            input_price=0.0,
            output_price=0.0,
            notes="Free local model",
        )
        
        assert pricing.notes == "Free local model"
    
    def test_calculate_cost(self):
        """Test calculating cost for tokens."""
        pricing = ModelPricing(
            input_price=1.0,  # $1 per 1M tokens
            output_price=3.0,  # $3 per 1M tokens
        )
        
        # 1M input + 1M output
        cost = pricing.calculate(input_tokens=1_000_000, output_tokens=1_000_000)
        
        # Expected: 1.0 + 3.0 = 4.0
        assert cost == pytest.approx(4.0)
    
    def test_calculate_cost_small_tokens(self):
        """Test calculating cost for small token counts."""
        pricing = ModelPricing(
            input_price=2.50,
            output_price=10.00,
        )
        
        # 1000 tokens input, 500 output
        cost = pricing.calculate(input_tokens=1000, output_tokens=500)
        
        # Expected: (1000/1M * 2.5) + (500/1M * 10) = 0.0025 + 0.005 = 0.0075
        assert cost == pytest.approx(0.0075)
    
    def test_calculate_cost_zero_tokens(self):
        """Test calculating cost with zero tokens."""
        pricing = ModelPricing(
            input_price=1.0,
            output_price=2.0,
        )
        
        cost = pricing.calculate(input_tokens=0, output_tokens=0)
        assert cost == 0.0


# ============================================================================
# PricingCalculator Tests
# ============================================================================

class TestPricingCalculator:
    """Tests for PricingCalculator."""
    
    def test_get_pricing_openai(self):
        """Test getting pricing for OpenAI models."""
        pricing = PricingCalculator.get_pricing("openai", "gpt-4o")
        
        assert pricing is not None
        assert pricing.input_price > 0 or pricing.output_price > 0
    
    def test_get_pricing_anthropic(self):
        """Test getting pricing for Anthropic models."""
        pricing = PricingCalculator.get_pricing("anthropic", "claude-3-5-sonnet-20241022")
        
        assert pricing is not None
    
    def test_get_pricing_ollama(self):
        """Test getting pricing for Ollama models (free)."""
        pricing = PricingCalculator.get_pricing("ollama", "llama3.2")
        
        assert pricing is not None
        assert pricing.input_price == 0.0
        assert pricing.output_price == 0.0
    
    def test_get_pricing_unknown_model(self):
        """Test getting pricing for unknown model (returns default)."""
        pricing = PricingCalculator.get_pricing("openai", "unknown-model-xyz")
        
        # Should return default pricing
        assert pricing is not None
    
    def test_calculate_cost(self):
        """Test calculating cost."""
        cost = PricingCalculator.calculate(
            provider="openai",
            model="gpt-4o-mini",
            input_tokens=1000,
            output_tokens=500,
        )
        
        assert cost >= 0
    
    def test_calculate_cost_ollama_free(self):
        """Test Ollama is free."""
        cost = PricingCalculator.calculate(
            provider="ollama",
            model="llama3.2",
            input_tokens=10000,
            output_tokens=5000,
        )
        
        assert cost == 0.0
    
    def test_list_models(self):
        """Test listing models for a provider."""
        models = PricingCalculator.list_models("openai")
        
        assert len(models) > 0
        assert any("gpt" in m for m in models)
    
    def test_list_models_ollama(self):
        """Test listing Ollama models."""
        models = PricingCalculator.list_models("ollama")
        
        assert len(models) > 0
        assert any("llama" in m for m in models)
    
    def test_get_all_pricing(self):
        """Test getting all pricing data."""
        all_pricing = PricingCalculator.get_all_pricing()
        
        assert "openai" in all_pricing
        assert "anthropic" in all_pricing
        assert "ollama" in all_pricing
    
    def test_register_custom_pricing(self):
        """Test registering custom pricing."""
        custom_pricing = ModelPricing(
            input_price=0.5,
            output_price=1.5,
            notes="Custom model",
        )
        
        PricingCalculator.register_pricing(
            provider="custom",
            model="my-model",
            pricing=custom_pricing,
        )
        
        # Should be able to retrieve it
        retrieved = PricingCalculator.get_pricing("custom", "my-model")
        assert retrieved.input_price == 0.5
        assert retrieved.output_price == 1.5
    
    def test_estimate_cost(self):
        """Test estimating cost from character counts."""
        cost = PricingCalculator.estimate_cost(
            provider="openai",
            model="gpt-4o",
            prompt_chars=4000,  # ~1000 tokens
            expected_output_chars=2000,  # ~500 tokens
        )
        
        assert cost >= 0


# ============================================================================
# ModelClientFactory Tests
# ============================================================================

class TestModelClientFactory:
    """Tests for ModelClientFactory."""
    
    def test_factory_registered_providers(self):
        """Test factory has registered providers."""
        # Factory should have some clients registered
        assert ModelClientFactory._clients is not None
        assert len(ModelClientFactory._clients) > 0
    
    def test_factory_has_ollama(self):
        """Test factory has Ollama provider."""
        assert "ollama" in ModelClientFactory._clients
    
    def test_factory_has_openai(self):
        """Test factory has OpenAI provider."""
        assert "openai" in ModelClientFactory._clients
    
    def test_factory_has_anthropic(self):
        """Test factory has Anthropic provider."""
        assert "anthropic" in ModelClientFactory._clients
    
    def test_register_custom_client(self):
        """Test registering a custom client."""
        from multi_agent_base.providers.factory import BaseModelClient
        
        class CustomClient(BaseModelClient):
            def __init__(self, model: str, **kwargs):
                self.model = model
            
            async def generate(self, messages, tools=None, **kwargs):
                return "response", {"total_tokens": 10}, []
            
            async def stream(self, messages, tools=None, **kwargs):
                yield "chunk"
        
        ModelClientFactory.register("custom", CustomClient)
        
        assert "custom" in ModelClientFactory._clients


# ============================================================================
# Integration Tests
# ============================================================================

class TestProvidersIntegration:
    """Integration tests for providers module."""
    
    def test_pricing_matches_provider(self):
        """Test pricing data exists for all factory providers."""
        for provider in ["openai", "anthropic", "ollama"]:
            models = PricingCalculator.list_models(provider)
            assert len(models) > 0, f"No pricing for {provider}"
    
    def test_cost_calculation_flow(self):
        """Test complete cost calculation flow."""
        # Simulate a usage scenario
        input_tokens = 500
        output_tokens = 200
        
        # Calculate for different providers
        openai_cost = PricingCalculator.calculate(
            "openai", "gpt-4o-mini", input_tokens, output_tokens
        )
        
        ollama_cost = PricingCalculator.calculate(
            "ollama", "llama3.2", input_tokens, output_tokens
        )
        
        # OpenAI should cost something, Ollama is free
        assert openai_cost > 0
        assert ollama_cost == 0


# ============================================================================
# Edge Cases
# ============================================================================

class TestProvidersEdgeCases:
    """Edge case tests for providers module."""
    
    def test_pricing_large_token_count(self):
        """Test pricing with very large token counts."""
        pricing = ModelPricing(
            input_price=2.50,
            output_price=10.00,
        )
        
        # 10 billion tokens (very large)
        cost = pricing.calculate(
            input_tokens=10_000_000_000,
            output_tokens=5_000_000_000,
        )
        
        # Should calculate without overflow
        assert cost > 0
        assert cost < float('inf')
    
    def test_pricing_zero_price(self):
        """Test pricing with zero prices."""
        pricing = ModelPricing(
            input_price=0.0,
            output_price=0.0,
        )
        
        cost = pricing.calculate(input_tokens=1_000_000, output_tokens=1_000_000)
        assert cost == 0.0
    
    def test_case_insensitive_provider(self):
        """Test provider names are case insensitive."""
        pricing1 = PricingCalculator.get_pricing("openai", "gpt-4o")
        pricing2 = PricingCalculator.get_pricing("OpenAI", "gpt-4o")
        pricing3 = PricingCalculator.get_pricing("OPENAI", "gpt-4o")
        
        # All should return valid pricing
        assert pricing1 is not None
        assert pricing2 is not None
        assert pricing3 is not None


# ============================================================================
# Model Pricing Data Tests
# ============================================================================

class TestPricingData:
    """Tests for built-in pricing data."""
    
    def test_gpt4o_pricing(self):
        """Test GPT-4o pricing exists."""
        pricing = PricingCalculator.get_pricing("openai", "gpt-4o")
        
        assert pricing.input_price > 0
        assert pricing.output_price > 0
        assert pricing.output_price > pricing.input_price  # Output is more expensive
    
    def test_claude_pricing(self):
        """Test Claude pricing exists."""
        pricing = PricingCalculator.get_pricing("anthropic", "claude-3-5-sonnet-20241022")
        
        assert pricing is not None
    
    def test_local_models_are_free(self):
        """Test local models have zero pricing."""
        local_models = ["llama3.2", "mistral", "codellama"]
        
        for model in local_models:
            pricing = PricingCalculator.get_pricing("ollama", model)
            assert pricing.input_price == 0.0, f"{model} should be free"
            assert pricing.output_price == 0.0, f"{model} should be free"
