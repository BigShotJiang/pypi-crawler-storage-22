"""
Tests for the Rate Limiting module.
"""

import pytest
import asyncio
import time

from multi_agent_base.ratelimit.limiter import (
    RateLimitConfig,
    RateLimitExceeded,
    TokenBucketLimiter,
    SlidingWindowLimiter,
    CompositeRateLimiter,
)
from multi_agent_base.ratelimit.provider_limits import (
    get_provider_limits,
    register_provider_limits,
    ProviderRateLimits,
)
from multi_agent_base.ratelimit.decorators import rate_limit, with_rate_limit


class TestRateLimitConfig:
    """Tests for RateLimitConfig."""
    
    def test_default_config(self):
        """Test default rate limit configuration."""
        config = RateLimitConfig()
        
        assert config.requests_per_minute == 60
        assert config.burst_multiplier == 1.5
        assert config.wait_on_limit is True
    
    def test_custom_config(self):
        """Test custom rate limit configuration."""
        config = RateLimitConfig(
            requests_per_minute=100,
            requests_per_second=5,
            burst_multiplier=2.0,
        )
        
        assert config.requests_per_minute == 100
        assert config.requests_per_second == 5


class TestTokenBucketLimiter:
    """Tests for TokenBucketLimiter."""
    
    @pytest.mark.asyncio
    async def test_allows_requests_within_limit(self):
        """Test that requests within limit are allowed."""
        limiter = TokenBucketLimiter(RateLimitConfig(
            requests_per_second=10,
            burst_multiplier=1.0,
        ))
        
        # Should allow immediate requests
        for _ in range(5):
            result = await limiter.acquire()
            assert result is True
    
    @pytest.mark.asyncio
    async def test_burst_capacity(self):
        """Test burst capacity."""
        limiter = TokenBucketLimiter(RateLimitConfig(
            requests_per_second=2,
            burst_multiplier=2.0,  # 4 burst capacity
        ))
        
        # Should allow burst
        for _ in range(4):
            result = await limiter.acquire()
            assert result is True
    
    @pytest.mark.asyncio
    async def test_raises_when_exceeded(self):
        """Test exception when limit exceeded."""
        limiter = TokenBucketLimiter(RateLimitConfig(
            requests_per_second=1,
            burst_multiplier=1.0,
            wait_on_limit=False,
        ))
        
        # First request should succeed
        await limiter.acquire()
        
        # Second should raise
        with pytest.raises(RateLimitExceeded):
            await limiter.acquire()
    
    @pytest.mark.asyncio
    async def test_refill_over_time(self):
        """Test token refill over time."""
        limiter = TokenBucketLimiter(RateLimitConfig(
            requests_per_second=10,
            burst_multiplier=1.0,
        ))
        
        # Use all tokens
        for _ in range(10):
            await limiter.acquire()
        
        remaining = limiter.get_remaining()
        assert remaining == 0
        
        # Wait for refill
        await asyncio.sleep(0.2)
        
        remaining = limiter.get_remaining()
        assert remaining >= 1
    
    def test_reset(self):
        """Test resetting the limiter."""
        limiter = TokenBucketLimiter(RateLimitConfig(
            requests_per_second=10,
        ))
        
        # Manually deplete
        limiter._state.tokens = 0
        assert limiter.get_remaining() == 0
        
        # Reset
        limiter.reset()
        
        assert limiter.get_remaining() > 0


class TestSlidingWindowLimiter:
    """Tests for SlidingWindowLimiter."""
    
    @pytest.mark.asyncio
    async def test_allows_within_window(self):
        """Test requests within window limit."""
        limiter = SlidingWindowLimiter(RateLimitConfig(
            requests_per_second=5,
        ))
        
        for _ in range(5):
            result = await limiter.acquire()
            assert result is True
    
    @pytest.mark.asyncio
    async def test_rejects_over_limit(self):
        """Test rejection when over limit."""
        limiter = SlidingWindowLimiter(RateLimitConfig(
            requests_per_second=2,
            wait_on_limit=False,
        ))
        
        await limiter.acquire()
        await limiter.acquire()
        
        with pytest.raises(RateLimitExceeded):
            await limiter.acquire()
    
    @pytest.mark.asyncio
    async def test_window_slides(self):
        """Test that window slides over time."""
        limiter = SlidingWindowLimiter(RateLimitConfig(
            requests_per_second=2,
            wait_on_limit=False,
        ))
        
        # Use up limit
        await limiter.acquire()
        await limiter.acquire()
        
        # Wait for window to slide
        await asyncio.sleep(1.1)
        
        # Should be able to acquire again
        result = await limiter.acquire()
        assert result is True


class TestProviderLimits:
    """Tests for provider rate limits."""
    
    def test_get_openai_limits(self):
        """Test getting OpenAI rate limits."""
        limits = get_provider_limits("openai", "tier1")
        
        assert limits.requests_per_minute > 0
        assert limits.tokens_per_minute is not None
    
    def test_get_anthropic_limits(self):
        """Test getting Anthropic rate limits."""
        limits = get_provider_limits("anthropic", "default")
        
        assert limits.requests_per_minute > 0
    
    def test_unknown_provider_defaults(self):
        """Test default limits for unknown provider."""
        limits = get_provider_limits("unknown_provider")
        
        # Should return default limits
        assert limits.requests_per_minute == 60
    
    def test_register_custom_limits(self):
        """Test registering custom provider limits."""
        custom = ProviderRateLimits(
            requests_per_minute=200,
            tokens_per_minute=50000,
        )
        
        register_provider_limits("custom_llm", "default", custom)
        
        limits = get_provider_limits("custom_llm", "default")
        assert limits.requests_per_minute == 200


class TestRateLimitDecorator:
    """Tests for rate limit decorators."""
    
    @pytest.mark.asyncio
    async def test_decorator_limits_calls(self):
        """Test that decorator limits function calls."""
        call_count = 0
        
        @rate_limit(requests_per_second=2, burst_multiplier=1.0, wait_on_limit=False)
        async def limited_function():
            nonlocal call_count
            call_count += 1
            return call_count
        
        # First two calls should succeed
        await limited_function()
        await limited_function()
        
        # Third should raise
        with pytest.raises(RateLimitExceeded):
            await limited_function()
    
    @pytest.mark.asyncio
    async def test_shared_limiter(self):
        """Test using shared limiter across functions."""
        limiter = TokenBucketLimiter(RateLimitConfig(
            requests_per_second=2,
            burst_multiplier=1.0,
            wait_on_limit=False,
        ))
        
        @with_rate_limit(limiter)
        async def function_a():
            return "a"
        
        @with_rate_limit(limiter)
        async def function_b():
            return "b"
        
        # Both share the same limiter
        await function_a()
        await function_b()
        
        # Third call to either should fail
        with pytest.raises(RateLimitExceeded):
            await function_a()


class TestCompositeRateLimiter:
    """Tests for CompositeRateLimiter."""
    
    @pytest.mark.asyncio
    async def test_combines_limiters(self):
        """Test that composite combines multiple limiters."""
        limiter1 = TokenBucketLimiter(RateLimitConfig(
            requests_per_second=5,
            burst_multiplier=1.0,
            wait_on_limit=False,
        ))
        limiter2 = TokenBucketLimiter(RateLimitConfig(
            requests_per_second=3,  # More restrictive
            burst_multiplier=1.0,
            wait_on_limit=False,
        ))
        
        composite = CompositeRateLimiter([limiter1, limiter2])
        
        # Should respect most restrictive (3 per second)
        for _ in range(3):
            result = await composite.acquire()
            assert result is True
        
        # Fourth should fail (limiter2 exhausted)
        with pytest.raises(RateLimitExceeded):
            await composite.acquire()


class MockRedisClient:
    """Mock Redis client for testing RedisRateLimiter."""
    
    def __init__(self):
        self._data: dict[str, str] = {}
    
    async def get(self, key: str) -> str | None:
        return self._data.get(key)
    
    async def set(self, key: str, value: str | float | int, ex: int | None = None) -> None:
        self._data[key] = str(value)
    
    async def incr(self, key: str) -> int:
        current = int(self._data.get(key, "0"))
        self._data[key] = str(current + 1)
        return current + 1
    
    async def delete(self, key: str) -> None:
        self._data.pop(key, None)
    
    async def expire(self, key: str, seconds: int) -> None:
        pass  # Mock doesn't implement TTL
    
    async def eval(self, script: str, numkeys: int, *args) -> list:
        """Mock Lua script execution."""
        # Return mock success response
        return [1, 100.0, 60.0]


class TestRedisRateLimiter:
    """Tests for RedisRateLimiter."""
    
    @pytest.mark.asyncio
    async def test_create_limiter(self):
        """Test Redis rate limiter creation."""
        from multi_agent_base.ratelimit import RedisRateLimiter, RateLimitConfig
        
        redis_client = MockRedisClient()
        limiter = RedisRateLimiter(
            config=RateLimitConfig(
                requests_per_minute=60,
                tokens_per_minute=10000,
            ),
            redis_client=redis_client,
            key_prefix="test:ratelimit",
            identifier="test",
        )
        
        assert limiter is not None
        assert limiter.key_prefix == "test:ratelimit"
        assert limiter.identifier == "test"
    
    @pytest.mark.asyncio
    async def test_acquire_tokens(self):
        """Test acquiring tokens from Redis limiter."""
        from multi_agent_base.ratelimit import RedisRateLimiter, RateLimitConfig
        
        redis_client = MockRedisClient()
        limiter = RedisRateLimiter(
            config=RateLimitConfig(
                requests_per_minute=60,
                tokens_per_minute=1000,
            ),
            redis_client=redis_client,
        )
        
        # First acquire should succeed
        result = await limiter.acquire(tokens=100)
        assert result.allowed is True
        assert result.remaining_tokens >= 0
    
    @pytest.mark.asyncio
    async def test_can_acquire_check(self):
        """Test can_acquire check without consuming."""
        from multi_agent_base.ratelimit import RedisRateLimiter, RateLimitConfig
        
        redis_client = MockRedisClient()
        limiter = RedisRateLimiter(
            config=RateLimitConfig(
                requests_per_minute=60,
                tokens_per_minute=1000,
            ),
            redis_client=redis_client,
        )
        
        # Check availability
        can_acquire = await limiter.can_acquire(tokens=100)
        assert can_acquire is True
    
    @pytest.mark.asyncio
    async def test_rate_limit_exceeded(self):
        """Test behavior when rate limit is exceeded."""
        from multi_agent_base.ratelimit import RedisRateLimiter, RateLimitConfig
        
        redis_client = MockRedisClient()
        limiter = RedisRateLimiter(
            config=RateLimitConfig(
                tokens_per_minute=100,  # Low limit
            ),
            redis_client=redis_client,
        )
        
        # First acquire succeeds
        result1 = await limiter.acquire(tokens=100)
        assert result1.allowed is True
        
        # Second should fail
        result2 = await limiter.acquire(tokens=100)
        assert result2.allowed is False
        assert result2.retry_after is not None
        assert result2.retry_after > 0
    
    @pytest.mark.asyncio
    async def test_key_prefix_isolation(self):
        """Test that different prefixes are isolated."""
        from multi_agent_base.ratelimit import RedisRateLimiter, RateLimitConfig
        
        redis_client = MockRedisClient()
        
        limiter1 = RedisRateLimiter(
            config=RateLimitConfig(tokens_per_minute=100),
            redis_client=redis_client,
            key_prefix="app1",
            identifier="user1",
        )
        
        limiter2 = RedisRateLimiter(
            config=RateLimitConfig(tokens_per_minute=100),
            redis_client=redis_client,
            key_prefix="app2",
            identifier="user1",
        )
        
        # Keys should be different
        assert limiter1._tokens_key != limiter2._tokens_key
        assert "app1" in limiter1._tokens_key
        assert "app2" in limiter2._tokens_key
    
    @pytest.mark.asyncio
    async def test_identifier_isolation(self):
        """Test that different identifiers are isolated."""
        from multi_agent_base.ratelimit import RedisRateLimiter, RateLimitConfig
        
        redis_client = MockRedisClient()
        
        limiter1 = RedisRateLimiter(
            config=RateLimitConfig(tokens_per_minute=100),
            redis_client=redis_client,
            identifier="user1",
        )
        
        limiter2 = RedisRateLimiter(
            config=RateLimitConfig(tokens_per_minute=100),
            redis_client=redis_client,
            identifier="user2",
        )
        
        # Each user has their own limit
        result1 = await limiter1.acquire(tokens=100)
        result2 = await limiter2.acquire(tokens=100)
        
        assert result1.allowed is True
        assert result2.allowed is True
    
    @pytest.mark.asyncio
    async def test_remaining_values(self):
        """Test that remaining values are tracked."""
        from multi_agent_base.ratelimit import RedisRateLimiter, RateLimitConfig
        
        redis_client = MockRedisClient()
        limiter = RedisRateLimiter(
            config=RateLimitConfig(
                tokens_per_minute=1000,
                requests_per_minute=10,
            ),
            redis_client=redis_client,
        )
        
        # Acquire some tokens
        result = await limiter.acquire(tokens=100)
        
        # Check remaining is tracked
        assert result.remaining_tokens is not None
        # Capacity is tokens_per_minute * burst_multiplier (1000 * 1.5 = 1500)
        # After acquiring 100, remaining should be 1400
        assert result.remaining_tokens < 1500  # Less than initial capacity
