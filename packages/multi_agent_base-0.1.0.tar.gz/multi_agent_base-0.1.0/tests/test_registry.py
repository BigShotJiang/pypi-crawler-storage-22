"""
Tests for Tool Registry module.
"""

import pytest

from multi_agent_base.core.registry import (
    ToolRegistry,
    ToolNamespace,
    get_registry,
)
from multi_agent_base.core.tools import BaseTool, FunctionTool, ToolResult


class SampleTool(BaseTool):
    """Sample tool for testing."""
    name: str = "sample"
    description: str = "A sample tool"
    category: str = "test"
    tags: list = ["sample", "test"]
    
    async def execute(self) -> ToolResult:
        return ToolResult.success("OK")


class MathTool(BaseTool):
    """Math tool for testing."""
    name: str = "calculator"
    description: str = "A calculator tool"
    category: str = "math"
    tags: list = ["math", "calculation"]
    
    async def execute(self, expression: str) -> ToolResult:
        return ToolResult.success(eval(expression))


class TestToolNamespace:
    """Tests for ToolNamespace."""
    
    def test_create_namespace(self):
        """Test creating namespace."""
        ns = ToolNamespace(name="test", description="Test namespace")
        
        assert ns.name == "test"
        assert ns.description == "Test namespace"
        assert len(ns) == 0
    
    def test_add_tool(self):
        """Test adding tool to namespace."""
        ns = ToolNamespace(name="test")
        tool = SampleTool()
        
        ns.add(tool)
        
        assert len(ns) == 1
        assert ns.get("sample") == tool
    
    def test_remove_tool(self):
        """Test removing tool from namespace."""
        ns = ToolNamespace(name="test")
        tool = SampleTool()
        ns.add(tool)
        
        result = ns.remove("sample")
        
        assert result is True
        assert len(ns) == 0
    
    def test_list_tools(self):
        """Test listing tools in namespace."""
        ns = ToolNamespace(name="test")
        ns.add(SampleTool())
        ns.add(MathTool())
        
        tools = ns.list_tools()
        
        assert "sample" in tools
        assert "calculator" in tools
    
    def test_iterate_namespace(self):
        """Test iterating over namespace."""
        ns = ToolNamespace(name="test")
        ns.add(SampleTool())
        ns.add(MathTool())
        
        tools = list(ns)
        
        assert len(tools) == 2


class TestToolRegistry:
    """Tests for ToolRegistry."""
    
    def setup_method(self):
        """Reset global registry before each test."""
        ToolRegistry.reset_global()
    
    def test_register_tool(self):
        """Test registering a tool."""
        registry = ToolRegistry()
        tool = SampleTool()
        
        registered = registry.register(tool)
        
        assert registered == tool
        assert len(registry) == 1
    
    def test_register_function(self):
        """Test registering a function as tool."""
        registry = ToolRegistry()
        
        def my_func(x: int) -> int:
            """Double a number."""
            return x * 2
        
        tool = registry.register(my_func)
        
        assert tool.name == "my_func"
        assert len(registry) == 1
    
    def test_register_with_namespace(self):
        """Test registering in specific namespace."""
        registry = ToolRegistry()
        tool = SampleTool()
        
        registry.register(tool, namespace="custom")
        
        assert registry.get("custom.sample") == tool
        assert registry.get("sample", namespace="custom") == tool
    
    def test_unregister_tool(self):
        """Test unregistering a tool."""
        registry = ToolRegistry()
        registry.register(SampleTool())
        
        result = registry.unregister("sample")
        
        assert result is True
        assert len(registry) == 0
    
    def test_get_tool(self):
        """Test getting tool by name."""
        registry = ToolRegistry()
        tool = SampleTool()
        registry.register(tool)
        
        found = registry.get("sample")
        
        assert found == tool
    
    def test_get_tool_with_namespace_prefix(self):
        """Test getting tool with namespace prefix."""
        registry = ToolRegistry()
        registry.register(SampleTool(), namespace="ns1")
        registry.register(MathTool(), namespace="ns2")
        
        assert registry.get("ns1.sample") is not None
        assert registry.get("ns2.calculator") is not None
    
    def test_get_by_category(self):
        """Test getting tools by category."""
        registry = ToolRegistry()
        registry.register(SampleTool())
        registry.register(MathTool())
        
        math_tools = registry.get_by_category("math")
        
        assert len(math_tools) == 1
        assert math_tools[0].name == "calculator"
    
    def test_get_by_tags(self):
        """Test getting tools by tags."""
        registry = ToolRegistry()
        registry.register(SampleTool())
        registry.register(MathTool())
        
        # Match any tag
        tools = registry.get_by_tags(["math", "sample"])
        assert len(tools) == 2
        
        # Match all tags
        tools = registry.get_by_tags(["math", "calculation"], match_all=True)
        assert len(tools) == 1
    
    def test_get_by_namespace(self):
        """Test getting tools by namespace."""
        registry = ToolRegistry()
        registry.register(SampleTool(), namespace="ns1")
        registry.register(MathTool(), namespace="ns1")
        registry.register(SampleTool(), namespace="ns2")
        
        ns1_tools = registry.get_by_namespace("ns1")
        
        assert len(ns1_tools) == 2
    
    def test_search_tools(self):
        """Test searching tools by pattern."""
        registry = ToolRegistry()
        registry.register(SampleTool())
        registry.register(MathTool())
        
        tools = registry.search("calc*")
        
        assert len(tools) == 1
        assert tools[0].name == "calculator"
    
    def test_list_all_tools(self):
        """Test listing all tools."""
        registry = ToolRegistry()
        registry.register(SampleTool())
        registry.register(MathTool())
        
        tools = registry.list_all()
        
        assert len(tools) == 2
    
    def test_list_namespaces(self):
        """Test listing namespaces."""
        registry = ToolRegistry()
        registry.register(SampleTool(), namespace="ns1")
        registry.register(MathTool(), namespace="ns2")
        
        namespaces = registry.list_namespaces()
        
        assert "default" in namespaces
        assert "ns1" in namespaces
        assert "ns2" in namespaces
    
    def test_get_openai_schemas(self):
        """Test getting OpenAI schemas."""
        registry = ToolRegistry()
        registry.register(SampleTool())
        registry.register(MathTool())
        
        schemas = registry.get_openai_schemas()
        
        assert len(schemas) == 2
        assert all(s["type"] == "function" for s in schemas)
    
    def test_get_anthropic_schemas(self):
        """Test getting Anthropic schemas."""
        registry = ToolRegistry()
        registry.register(SampleTool())
        
        schemas = registry.get_anthropic_schemas()
        
        assert len(schemas) == 1
        assert "input_schema" in schemas[0]
    
    def test_clear_registry(self):
        """Test clearing registry."""
        registry = ToolRegistry()
        registry.register(SampleTool())
        registry.register(MathTool())
        
        registry.clear()
        
        assert len(registry) == 0
    
    def test_clear_namespace(self):
        """Test clearing specific namespace."""
        registry = ToolRegistry()
        registry.register(SampleTool(), namespace="ns1")
        registry.register(MathTool(), namespace="ns2")
        
        registry.clear(namespace="ns1")
        
        assert len(registry.get_by_namespace("ns1")) == 0
        assert len(registry.get_by_namespace("ns2")) == 1
    
    def test_contains(self):
        """Test contains check."""
        registry = ToolRegistry()
        registry.register(SampleTool())
        
        assert "sample" in registry
        assert "nonexistent" not in registry


class TestGlobalRegistry:
    """Tests for global registry functions."""
    
    def setup_method(self):
        """Reset global registry before each test."""
        ToolRegistry.reset_global()
    
    def test_get_global_registry(self):
        """Test getting global registry."""
        registry1 = ToolRegistry.get_global()
        registry2 = ToolRegistry.get_global()
        
        assert registry1 is registry2
    
    def test_get_registry_function(self):
        """Test get_registry convenience function."""
        registry = get_registry()
        
        assert registry is ToolRegistry.get_global()
    
    def test_reset_global_registry(self):
        """Test resetting global registry."""
        registry1 = ToolRegistry.get_global()
        registry1.register(SampleTool())
        
        ToolRegistry.reset_global()
        
        registry2 = ToolRegistry.get_global()
        assert len(registry2) == 0
