"""
Tests for the resilience module.

Tests cover:
- Retry strategies and configuration
- Circuit breaker patterns
- Timeout handling
- Fallback chains
- Resilient wrappers
"""

import pytest
import asyncio
from datetime import datetime
from unittest.mock import AsyncMock, MagicMock, patch

from multi_agent_base.resilience import (
    # Policy
    ResiliencePolicy,
    ResilienceConfig,
    CircuitState,
    # Retry
    retry_with_backoff,
    RetryStrategy,
    RetryConfig,
    # Circuit Breaker
    CircuitBreaker,
    CircuitBreakerError,
    CircuitOpenError,
    # Timeout
    with_timeout,
    ResilienceTimeoutError,
    # Fallback
    Fallback,
    FallbackChain,
    # Wrapper
    ResilientWrapper,
    resilient,
)


# ============================================================================
# RetryStrategy Tests
# ============================================================================

class TestRetryStrategy:
    """Tests for RetryStrategy enum."""
    
    def test_retry_strategies_exist(self):
        """Test all retry strategies are defined."""
        assert RetryStrategy.FIXED is not None
        assert RetryStrategy.EXPONENTIAL is not None
        assert RetryStrategy.LINEAR is not None
        assert RetryStrategy.JITTERED is not None


# ============================================================================
# RetryConfig Tests
# ============================================================================

class TestRetryConfig:
    """Tests for RetryConfig."""
    
    def test_default_config(self):
        """Test default configuration."""
        config = RetryConfig()
        
        assert config.max_attempts == 3
        assert config.delay == 1.0
        assert config.max_delay == 60.0
        assert config.backoff_multiplier == 2.0
        assert config.strategy == RetryStrategy.EXPONENTIAL
        assert config.jitter == 0.1
    
    def test_custom_config(self):
        """Test custom configuration."""
        config = RetryConfig(
            max_attempts=5,
            delay=0.5,
            max_delay=30.0,
            backoff_multiplier=3.0,
            strategy=RetryStrategy.LINEAR,
            jitter=0.2,
        )
        
        assert config.max_attempts == 5
        assert config.delay == 0.5
        assert config.strategy == RetryStrategy.LINEAR
    
    def test_calculate_delay_fixed(self):
        """Test fixed delay calculation."""
        config = RetryConfig(
            delay=1.0,
            strategy=RetryStrategy.FIXED,
            jitter=0,  # No jitter for predictable test
        )
        
        assert config.calculate_delay(0) == 1.0
        assert config.calculate_delay(1) == 1.0
        assert config.calculate_delay(5) == 1.0
    
    def test_calculate_delay_exponential(self):
        """Test exponential delay calculation."""
        config = RetryConfig(
            delay=1.0,
            backoff_multiplier=2.0,
            strategy=RetryStrategy.EXPONENTIAL,
            jitter=0,
        )
        
        # 1.0 * 2^0 = 1.0, 1.0 * 2^1 = 2.0, 1.0 * 2^2 = 4.0
        assert config.calculate_delay(0) == 1.0
        assert config.calculate_delay(1) == 2.0
        assert config.calculate_delay(2) == 4.0
    
    def test_calculate_delay_linear(self):
        """Test linear delay calculation."""
        config = RetryConfig(
            delay=1.0,
            backoff_multiplier=1.0,
            strategy=RetryStrategy.LINEAR,
            jitter=0,
        )
        
        assert config.calculate_delay(0) == 1.0  # 1.0 * (1 + 0*1)
        assert config.calculate_delay(1) == 2.0  # 1.0 * (1 + 1*1)
        assert config.calculate_delay(2) == 3.0  # 1.0 * (1 + 2*1)
    
    def test_calculate_delay_max_limit(self):
        """Test delay is capped at max_delay."""
        config = RetryConfig(
            delay=10.0,
            max_delay=5.0,
            backoff_multiplier=2.0,
            strategy=RetryStrategy.EXPONENTIAL,
            jitter=0,
        )
        
        # Even with exponential backoff, should not exceed max
        delay = config.calculate_delay(10)
        assert delay <= 5.0
    
    def test_calculate_delay_jitter(self):
        """Test jitter is applied."""
        config = RetryConfig(
            delay=1.0,
            strategy=RetryStrategy.JITTERED,
            jitter=0.5,
        )
        
        # Should vary due to jitter
        delays = [config.calculate_delay(0) for _ in range(10)]
        assert len(set(delays)) > 1  # Should have variation


# ============================================================================
# retry_with_backoff Decorator Tests
# ============================================================================

class TestRetryWithBackoff:
    """Tests for retry_with_backoff decorator."""
    
    @pytest.mark.asyncio
    async def test_no_retry_on_success(self):
        """Test no retry when function succeeds."""
        call_count = 0
        
        @retry_with_backoff(max_attempts=3)
        async def succeeds():
            nonlocal call_count
            call_count += 1
            return "success"
        
        result = await succeeds()
        
        assert result == "success"
        assert call_count == 1
    
    @pytest.mark.asyncio
    async def test_retry_on_failure(self):
        """Test retry on transient failure."""
        call_count = 0
        
        @retry_with_backoff(max_attempts=3, delay=0.01)
        async def fails_twice():
            nonlocal call_count
            call_count += 1
            if call_count < 3:
                raise ValueError("Transient error")
            return "success"
        
        result = await fails_twice()
        
        assert result == "success"
        assert call_count == 3
    
    @pytest.mark.asyncio
    async def test_max_retries_exceeded(self):
        """Test all retries exhausted."""
        call_count = 0
        
        @retry_with_backoff(max_attempts=3, delay=0.01)
        async def always_fails():
            nonlocal call_count
            call_count += 1
            raise ValueError("Permanent error")
        
        # Should raise either ValueError or RetryExhaustedError
        with pytest.raises(Exception):
            await always_fails()
        
        assert call_count == 3
    
    @pytest.mark.asyncio
    async def test_retry_on_specific_exception(self):
        """Test retry only on specific exception types."""
        call_count = 0
        
        @retry_with_backoff(
            max_attempts=3,
            delay=0.01,
            retry_on=(ValueError,),
        )
        async def fails_with_type_error():
            nonlocal call_count
            call_count += 1
            raise TypeError("Not retried")
        
        with pytest.raises(TypeError):
            await fails_with_type_error()
        
        # Should only try once because TypeError is not in retry_on
        assert call_count == 1
    
    @pytest.mark.asyncio
    async def test_on_retry_callback(self):
        """Test on_retry callback is called."""
        retry_attempts = []
        
        def on_retry(attempt: int, error: Exception):
            retry_attempts.append((attempt, str(error)))
        
        @retry_with_backoff(max_attempts=3, delay=0.01, on_retry=on_retry)
        async def fails_twice():
            if len(retry_attempts) < 2:
                raise ValueError("Retry me")
            return "success"
        
        await fails_twice()
        
        assert len(retry_attempts) == 2
        assert retry_attempts[0][0] == 1
        assert retry_attempts[1][0] == 2
    
    @pytest.mark.asyncio
    async def test_retry_with_string_strategy(self):
        """Test retry with string strategy."""
        call_count = 0
        
        @retry_with_backoff(max_attempts=2, delay=0.01, strategy="fixed")
        async def fails_once():
            nonlocal call_count
            call_count += 1
            if call_count < 2:
                raise ValueError("Retry")
            return "success"
        
        result = await fails_once()
        assert result == "success"


# ============================================================================
# CircuitBreaker Tests
# ============================================================================

class TestCircuitBreaker:
    """Tests for CircuitBreaker."""
    
    def test_initial_state_closed(self):
        """Test initial state is CLOSED."""
        cb = CircuitBreaker()
        
        assert cb.state == CircuitState.CLOSED
        assert cb.failure_count == 0
    
    def test_can_execute_when_closed(self):
        """Test can execute when closed."""
        cb = CircuitBreaker()
        
        assert cb.can_execute() is True
    
    def test_record_success(self):
        """Test recording success."""
        cb = CircuitBreaker()
        
        cb.record_success()
        
        assert cb.state == CircuitState.CLOSED
    
    def test_record_failure_increments_count(self):
        """Test recording failure increments count."""
        cb = CircuitBreaker(failure_threshold=5)
        
        cb.record_failure()
        
        assert cb.failure_count == 1
        assert cb.state == CircuitState.CLOSED
    
    def test_circuit_opens_after_threshold(self):
        """Test circuit opens after failure threshold."""
        cb = CircuitBreaker(failure_threshold=3)
        
        for _ in range(3):
            cb.record_failure()
        
        assert cb.state == CircuitState.OPEN
        assert cb.can_execute() is False
    
    def test_circuit_rejects_when_open(self):
        """Test circuit rejects requests when open."""
        cb = CircuitBreaker(failure_threshold=1)
        
        cb.record_failure()  # Opens circuit
        
        assert cb.can_execute() is False
    
    def test_circuit_transitions_to_half_open(self):
        """Test circuit transitions to half-open after timeout."""
        cb = CircuitBreaker(failure_threshold=1, reset_timeout=0.1)
        
        cb.record_failure()  # Opens circuit
        
        # Wait for reset timeout
        import time
        time.sleep(0.15)
        
        # Should transition to half-open
        assert cb.state == CircuitState.HALF_OPEN
    
    def test_circuit_closes_after_success_in_half_open(self):
        """Test circuit closes after successful calls in half-open."""
        cb = CircuitBreaker(
            failure_threshold=1,
            success_threshold=1,  # Just 1 success needed
            reset_timeout=0.05,
        )
        
        cb.record_failure()  # Opens circuit
        
        import time
        time.sleep(0.1)  # Wait for half-open
        
        # Record successes - may need multiple depending on implementation
        cb.record_success()
        
        # Check if it's closed or still needs more successes
        # Different implementations may require different success counts
        assert cb.state in [CircuitState.CLOSED, CircuitState.HALF_OPEN]
    
    def test_circuit_reopens_on_failure_in_half_open(self):
        """Test circuit reopens on failure in half-open."""
        cb = CircuitBreaker(failure_threshold=1, reset_timeout=0.05)
        
        cb.record_failure()  # Opens circuit
        
        import time
        time.sleep(0.1)  # Wait for half-open
        
        assert cb.state == CircuitState.HALF_OPEN
        
        cb.record_failure()  # Reopens circuit
        
        assert cb.state == CircuitState.OPEN
    
    def test_half_open_max_calls_limit(self):
        """Test half-open limits concurrent calls."""
        cb = CircuitBreaker(
            failure_threshold=1,
            reset_timeout=0.05,
            half_open_max_calls=2,
        )
        
        cb.record_failure()  # Opens circuit
        
        import time
        time.sleep(0.1)
        
        # First calls should be allowed
        assert cb.can_execute() is True
    
    def test_circuit_breaker_name(self):
        """Test circuit breaker name."""
        cb = CircuitBreaker(name="test-circuit")
        
        assert cb.name == "test-circuit"


# ============================================================================
# CircuitOpenError Tests
# ============================================================================

class TestCircuitOpenError:
    """Tests for CircuitOpenError."""
    
    def test_error_message(self):
        """Test error message."""
        error = CircuitOpenError("Circuit is open")
        
        assert str(error) == "Circuit is open"
    
    def test_error_with_reset_time(self):
        """Test error with reset time."""
        error = CircuitOpenError(
            "Circuit is open",
            time_until_reset=30.0,
        )
        
        assert error.time_until_reset == 30.0


# ============================================================================
# with_timeout Tests
# ============================================================================

class TestWithTimeout:
    """Tests for with_timeout."""
    
    @pytest.mark.asyncio
    async def test_completes_within_timeout(self):
        """Test function completes within timeout."""
        async def fast_operation():
            return "done"
        
        result = await with_timeout(fast_operation(), timeout=1.0)
        assert result == "done"
    
    @pytest.mark.asyncio
    async def test_timeout_exceeded(self):
        """Test timeout is raised when exceeded."""
        async def slow_operation():
            await asyncio.sleep(1.0)
            return "done"
        
        with pytest.raises((asyncio.TimeoutError, ResilienceTimeoutError)):
            await with_timeout(slow_operation(), timeout=0.1)
    
    @pytest.mark.asyncio
    async def test_exception_propagated(self):
        """Test exceptions are propagated."""
        async def raises_error():
            raise ValueError("Error")
        
        with pytest.raises(ValueError, match="Error"):
            await with_timeout(raises_error(), timeout=1.0)


# ============================================================================
# Fallback Tests
# ============================================================================

class TestFallback:
    """Tests for Fallback."""
    
    @pytest.mark.asyncio
    async def test_primary_succeeds(self):
        """Test primary function succeeds."""
        async def primary():
            return "primary"
        
        fb = Fallback(default="fallback")
        result = await fb.execute(primary)
        
        assert result.value == "primary"
        assert result.used_fallback is False
    
    @pytest.mark.asyncio
    async def test_fallback_on_failure(self):
        """Test fallback is used on primary failure."""
        async def primary():
            raise ValueError("Primary failed")
        
        fb = Fallback(default="fallback")
        result = await fb.execute(primary)
        
        assert result.value == "fallback"
        assert result.used_fallback is True
    
    @pytest.mark.asyncio
    async def test_fallback_with_error_handler(self):
        """Test fallback with error handler."""
        async def primary():
            raise ValueError("Primary failed")
        
        fb = Fallback(on_error=lambda e: f"Error: {e}")
        result = await fb.execute(primary)
        
        assert "Error" in str(result.value)
        assert result.used_fallback is True


# ============================================================================
# FallbackChain Tests
# ============================================================================

class TestFallbackChain:
    """Tests for FallbackChain."""
    
    @pytest.mark.asyncio
    async def test_chain_creation(self):
        """Test creating a fallback chain."""
        chain = FallbackChain(name="test-chain")
        
        assert chain.name == "test-chain"
    
    @pytest.mark.asyncio
    async def test_add_provider(self):
        """Test adding providers to chain."""
        async def provider1():
            return "result1"
        
        chain = FallbackChain()
        chain.add("primary", provider1)
        
        # Chain should have the provider
        assert len(chain._providers) >= 1
    
    @pytest.mark.asyncio
    async def test_chain_execute(self):
        """Test executing fallback chain."""
        async def provider1():
            return "result1"
        
        chain = FallbackChain()
        chain.add("primary", provider1)
        
        result = await chain.execute()
        
        assert result is not None


# ============================================================================
# ResilientWrapper Tests
# ============================================================================

class TestResilientWrapper:
    """Tests for ResilientWrapper."""
    
    @pytest.mark.asyncio
    async def test_basic_execution(self):
        """Test basic execution through wrapper."""
        async def operation():
            return "result"
        
        wrapper = ResilientWrapper()
        result = await wrapper.call(operation)
        
        assert result == "result"
    
    @pytest.mark.asyncio
    async def test_wrapper_creation(self):
        """Test creating wrapper with config."""
        wrapper = ResilientWrapper(
            name="test-wrapper",
        )
        
        assert wrapper.name == "test-wrapper"


# ============================================================================
# resilient Decorator Tests
# ============================================================================

class TestResilientDecorator:
    """Tests for resilient decorator."""
    
    @pytest.mark.asyncio
    async def test_basic_decoration(self):
        """Test basic decoration."""
        @resilient()
        async def operation():
            return "result"
        
        result = await operation()
        assert result == "result"
    
    @pytest.mark.asyncio
    async def test_decorated_function(self):
        """Test decorated function with arguments."""
        @resilient()
        async def operation(x, y):
            return x + y
        
        result = await operation(1, 2)
        assert result == 3


# ============================================================================
# CircuitState Tests
# ============================================================================

class TestCircuitState:
    """Tests for CircuitState enum."""
    
    def test_circuit_states(self):
        """Test all circuit states are defined."""
        assert CircuitState.CLOSED == "closed"
        assert CircuitState.OPEN == "open"
        assert CircuitState.HALF_OPEN == "half_open"


# ============================================================================
# ResilienceConfig Tests
# ============================================================================

class TestResilienceConfig:
    """Tests for ResilienceConfig."""
    
    def test_default_config(self):
        """Test default resilience configuration."""
        config = ResilienceConfig()
        
        assert config is not None


# ============================================================================
# ResiliencePolicy Tests
# ============================================================================

class TestResiliencePolicy:
    """Tests for ResiliencePolicy."""
    
    def test_create_policy(self):
        """Test creating a resilience policy."""
        policy = ResiliencePolicy()
        
        assert policy is not None


# ============================================================================
# Integration Tests
# ============================================================================

class TestResilienceIntegration:
    """Integration tests for resilience module."""
    
    @pytest.mark.asyncio
    async def test_retry_with_circuit_breaker(self):
        """Test combining retry with circuit breaker."""
        cb = CircuitBreaker(failure_threshold=3)
        call_count = 0
        
        @retry_with_backoff(max_attempts=2, delay=0.01)
        async def operation():
            nonlocal call_count
            call_count += 1
            
            if not cb.can_execute():
                raise CircuitOpenError("Circuit is open")
            
            try:
                if call_count < 4:
                    raise ValueError("Transient error")
                return "success"
            except Exception as e:
                cb.record_failure()
                raise
        
        # Should fail because retry exhausted before success
        with pytest.raises(Exception):
            await operation()
    
    @pytest.mark.asyncio
    async def test_timeout_with_fallback(self):
        """Test timeout with fallback."""
        async def slow_primary():
            await asyncio.sleep(1.0)
            return "primary"
        
        fb = Fallback(default="fallback")
        
        try:
            result = await with_timeout(slow_primary(), timeout=0.1)
        except (asyncio.TimeoutError, ResilienceTimeoutError):
            result = await fb.execute(slow_primary)
        
        # Either got timeout or fallback
        assert result is not None


# ============================================================================
# Edge Cases
# ============================================================================

class TestResilienceEdgeCases:
    """Edge case tests for resilience module."""
    
    @pytest.mark.asyncio
    async def test_retry_with_zero_delay(self):
        """Test retry with zero delay."""
        call_count = 0
        
        @retry_with_backoff(max_attempts=3, delay=0)
        async def operation():
            nonlocal call_count
            call_count += 1
            if call_count < 3:
                raise ValueError("Retry")
            return "success"
        
        result = await operation()
        assert result == "success"
    
    @pytest.mark.asyncio
    async def test_circuit_breaker_with_zero_threshold(self):
        """Test circuit breaker with very low threshold."""
        cb = CircuitBreaker(failure_threshold=1)
        
        cb.record_failure()
        
        assert cb.state == CircuitState.OPEN
    
    @pytest.mark.asyncio
    async def test_nested_retry_decorators(self):
        """Test nested retry decorators."""
        outer_calls = 0
        inner_calls = 0
        
        @retry_with_backoff(max_attempts=2, delay=0.01)
        async def outer():
            nonlocal outer_calls
            outer_calls += 1
            return await inner()
        
        @retry_with_backoff(max_attempts=2, delay=0.01)
        async def inner():
            nonlocal inner_calls
            inner_calls += 1
            if inner_calls < 2:
                raise ValueError("Retry")
            return "success"
        
        result = await outer()
        
        assert result == "success"
        assert outer_calls == 1
        assert inner_calls == 2
