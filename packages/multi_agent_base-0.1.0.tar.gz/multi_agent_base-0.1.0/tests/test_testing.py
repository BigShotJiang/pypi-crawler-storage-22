"""
Tests for Agent Testing Framework

Comprehensive tests for MockLLM, MockTool, fixtures, and assertions.
"""

import asyncio
import pytest
import re
from datetime import datetime
from typing import Any

from multi_agent_base.testing import (
    # Types
    MockResponseType,
    AssertionType,
    TestStatus,
    MockToolCall,
    MockResponse,
    MockLLMConfig,
    MockToolConfig,
    RecordedCall,
    AssertionResult,
    TestMetrics,
    TestResult,
    TestSuiteResult,
    ConversationTurn,
    TestScenario,
    # Mocks
    MockLLM,
    MockLLMError,
    MockTool,
    MockToolError,
    MockToolRegistry,
    MockAgent,
    # Fixtures
    TestContext,
    ConversationFixture,
    ScenarioRunner,
    TestSuiteBuilder,
    TestSuite,
    agent_test,
    with_mock_llm,
    with_mock_tools,
    mock_llm_context,
    mock_tool_context,
    # Assertions
    AgentAssertions,
    assert_tool_called,
    assert_tool_not_called,
    assert_response_contains,
    assert_response_not_contains,
    assert_response_matches,
    assert_cost_under,
    assert_tokens_under,
    assert_latency_under,
    assert_llm_called,
)


# ==================== MockToolCall Tests ====================


class TestMockToolCall:
    """Tests for MockToolCall dataclass."""
    
    def test_basic_creation(self):
        """Test basic MockToolCall creation."""
        call = MockToolCall(name="search", arguments={"query": "test"})
        assert call.name == "search"
        assert call.arguments == {"query": "test"}
        assert call.result is None
        assert call.error is None
        assert call.call_id.startswith("call_")
    
    def test_with_result(self):
        """Test MockToolCall with result."""
        call = MockToolCall(
            name="calculate",
            arguments={"x": 1, "y": 2},
            result=3,
        )
        assert call.result == 3
    
    def test_with_error(self):
        """Test MockToolCall with error."""
        call = MockToolCall(
            name="search",
            arguments={},
            error="Connection failed",
        )
        assert call.error == "Connection failed"
    
    def test_to_dict(self):
        """Test conversion to dictionary."""
        call = MockToolCall(
            name="test",
            arguments={"a": 1},
            result="result",
            call_id="call_123",
        )
        d = call.to_dict()
        assert d["name"] == "test"
        assert d["arguments"] == {"a": 1}
        assert d["result"] == "result"
        assert d["call_id"] == "call_123"
    
    def test_from_dict(self):
        """Test creation from dictionary."""
        data = {
            "name": "search",
            "arguments": {"q": "test"},
            "result": ["a", "b"],
            "call_id": "call_456",
        }
        call = MockToolCall.from_dict(data)
        assert call.name == "search"
        assert call.arguments == {"q": "test"}
        assert call.result == ["a", "b"]
        assert call.call_id == "call_456"


# ==================== MockResponse Tests ====================


class TestMockResponse:
    """Tests for MockResponse dataclass."""
    
    def test_text_response(self):
        """Test text response creation."""
        response = MockResponse.text("Hello, world!")
        assert response.content == "Hello, world!"
        assert response.response_type == MockResponseType.TEXT
        assert response.finish_reason == "stop"
    
    def test_text_response_with_delay(self):
        """Test text response with delay."""
        response = MockResponse.text("Hello!", delay_ms=100)
        assert response.delay_ms == 100
    
    def test_tool_call_response(self):
        """Test tool call response creation."""
        response = MockResponse.tool_call(
            name="search",
            arguments={"query": "AI"},
            result=["result1", "result2"],
        )
        assert response.response_type == MockResponseType.TOOL_CALL
        assert len(response.tool_calls) == 1
        assert response.tool_calls[0].name == "search"
        assert response.finish_reason == "tool_calls"
    
    def test_error_response(self):
        """Test error response creation."""
        response = MockResponse.error("Rate limit exceeded", code="rate_limit")
        assert response.response_type == MockResponseType.ERROR
        assert response.content == "Rate limit exceeded"
        assert response.metadata["error_code"] == "rate_limit"
    
    def test_stream_response(self):
        """Test stream response creation."""
        chunks = ["Hello", " ", "world", "!"]
        response = MockResponse.stream(chunks, delay_per_chunk_ms=5)
        assert response.response_type == MockResponseType.STREAM
        assert response.content == "Hello world!"
        assert response.metadata["chunks"] == chunks
    
    def test_to_dict(self):
        """Test conversion to dictionary."""
        response = MockResponse.text("test")
        d = response.to_dict()
        assert d["content"] == "test"
        assert d["response_type"] == "text"
        assert d["finish_reason"] == "stop"


# ==================== MockLLMConfig Tests ====================


class TestMockLLMConfig:
    """Tests for MockLLMConfig dataclass."""
    
    def test_default_config(self):
        """Test default configuration."""
        config = MockLLMConfig()
        assert config.responses == []
        assert config.default_response is None
        assert config.cycle_responses is False
        assert config.record_calls is True
    
    def test_add_response(self):
        """Test adding responses."""
        config = MockLLMConfig()
        config.add_response("Hello")
        config.add_response(MockResponse.text("World"))
        assert len(config.responses) == 2
    
    def test_add_responses(self):
        """Test adding multiple responses."""
        config = MockLLMConfig()
        config.add_responses("One", "Two", "Three")
        assert len(config.responses) == 3
    
    def test_from_strings(self):
        """Test creation from strings."""
        config = MockLLMConfig.from_strings("A", "B", "C", cycle=True)
        assert len(config.responses) == 3
        assert config.cycle_responses is True
    
    def test_chaining(self):
        """Test method chaining."""
        config = (
            MockLLMConfig()
            .add_response("First")
            .add_response("Second")
            .add_responses("Third", "Fourth")
        )
        assert len(config.responses) == 4


# ==================== MockLLM Tests ====================


class TestMockLLM:
    """Tests for MockLLM class."""
    
    @pytest.fixture
    def mock_llm(self):
        """Create a basic MockLLM."""
        return MockLLM(responses=["Response 1", "Response 2", "Response 3"])
    
    @pytest.mark.asyncio
    async def test_basic_chat(self, mock_llm):
        """Test basic chat functionality."""
        response = await mock_llm.chat([{"role": "user", "content": "Hello"}])
        
        assert response["choices"][0]["message"]["content"] == "Response 1"
        assert response["choices"][0]["finish_reason"] == "stop"
        assert mock_llm.call_count == 1
    
    @pytest.mark.asyncio
    async def test_sequential_responses(self, mock_llm):
        """Test that responses are returned sequentially."""
        r1 = await mock_llm.chat([{"role": "user", "content": "1"}])
        r2 = await mock_llm.chat([{"role": "user", "content": "2"}])
        r3 = await mock_llm.chat([{"role": "user", "content": "3"}])
        
        assert r1["choices"][0]["message"]["content"] == "Response 1"
        assert r2["choices"][0]["message"]["content"] == "Response 2"
        assert r3["choices"][0]["message"]["content"] == "Response 3"
    
    @pytest.mark.asyncio
    async def test_cycle_responses(self):
        """Test cycling through responses."""
        mock = MockLLM(responses=["A", "B"], cycle_responses=True)
        
        r1 = await mock.chat([{"role": "user", "content": "1"}])
        r2 = await mock.chat([{"role": "user", "content": "2"}])
        r3 = await mock.chat([{"role": "user", "content": "3"}])
        
        assert r1["choices"][0]["message"]["content"] == "A"
        assert r2["choices"][0]["message"]["content"] == "B"
        assert r3["choices"][0]["message"]["content"] == "A"  # Cycles back
    
    @pytest.mark.asyncio
    async def test_default_response(self):
        """Test default response when exhausted."""
        mock = MockLLM(responses=["Only one"], default_response="Default")
        
        r1 = await mock.chat([{"role": "user", "content": "1"}])
        r2 = await mock.chat([{"role": "user", "content": "2"}])
        
        assert r1["choices"][0]["message"]["content"] == "Only one"
        # When exhausted and not cycling, returns last response
        assert r2["choices"][0]["message"]["content"] == "Only one"
    
    @pytest.mark.asyncio
    async def test_recorded_calls(self, mock_llm):
        """Test that calls are recorded."""
        await mock_llm.chat([{"role": "user", "content": "Hello"}])
        await mock_llm.chat([{"role": "user", "content": "World"}])
        
        assert len(mock_llm.recorded_calls) == 2
        assert mock_llm.recorded_calls[0].messages[0]["content"] == "Hello"
        assert mock_llm.recorded_calls[1].messages[0]["content"] == "World"
    
    @pytest.mark.asyncio
    async def test_last_call(self, mock_llm):
        """Test last_call property."""
        await mock_llm.chat([{"role": "user", "content": "First"}])
        await mock_llm.chat([{"role": "user", "content": "Last"}])
        
        assert mock_llm.last_call is not None
        assert mock_llm.last_messages[0]["content"] == "Last"
    
    @pytest.mark.asyncio
    async def test_tool_call_response(self):
        """Test tool call in response."""
        mock = MockLLM(responses=[
            MockResponse.tool_call(
                name="web_search",
                arguments={"query": "AI trends"},
            )
        ])
        
        response = await mock.chat([{"role": "user", "content": "Search"}])
        
        assert response["choices"][0]["finish_reason"] == "tool_calls"
        assert len(response["choices"][0]["message"]["tool_calls"]) == 1
        assert response["choices"][0]["message"]["tool_calls"][0]["function"]["name"] == "web_search"
    
    @pytest.mark.asyncio
    async def test_error_response(self):
        """Test error response."""
        mock = MockLLM(responses=[MockResponse.error("Rate limit")])
        
        with pytest.raises(MockLLMError) as exc_info:
            await mock.chat([{"role": "user", "content": "Hello"}])
        
        assert "Rate limit" in str(exc_info.value)
    
    @pytest.mark.asyncio
    async def test_fail_after(self):
        """Test fail_after configuration."""
        config = MockLLMConfig(fail_after=2, fail_message="Max calls reached")
        config.add_responses("One", "Two", "Three")
        mock = MockLLM(config=config)
        
        await mock.chat([{"role": "user", "content": "1"}])  # OK
        await mock.chat([{"role": "user", "content": "2"}])  # OK
        
        with pytest.raises(MockLLMError) as exc_info:
            await mock.chat([{"role": "user", "content": "3"}])  # Fails
        
        assert "Max calls reached" in str(exc_info.value)
    
    @pytest.mark.asyncio
    async def test_reset(self, mock_llm):
        """Test reset functionality."""
        await mock_llm.chat([{"role": "user", "content": "Hello"}])
        await mock_llm.chat([{"role": "user", "content": "World"}])
        
        mock_llm.reset()
        
        assert mock_llm.call_count == 0
        assert len(mock_llm.recorded_calls) == 0
        
        # Should start from first response again
        response = await mock_llm.chat([{"role": "user", "content": "Again"}])
        assert response["choices"][0]["message"]["content"] == "Response 1"
    
    @pytest.mark.asyncio
    async def test_metrics(self, mock_llm):
        """Test metrics collection."""
        await mock_llm.chat([{"role": "user", "content": "Hello"}])
        
        assert mock_llm.metrics.total_calls >= 1
    
    @pytest.mark.asyncio
    async def test_assert_called(self, mock_llm):
        """Test assert_called method."""
        with pytest.raises(AssertionError):
            mock_llm.assert_called()
        
        await mock_llm.chat([{"role": "user", "content": "Hello"}])
        mock_llm.assert_called()  # Should not raise
    
    @pytest.mark.asyncio
    async def test_assert_called_times(self, mock_llm):
        """Test assert_called_times method."""
        await mock_llm.chat([{"role": "user", "content": "1"}])
        await mock_llm.chat([{"role": "user", "content": "2"}])
        
        mock_llm.assert_called_times(2)  # Should not raise
        
        with pytest.raises(AssertionError):
            mock_llm.assert_called_times(3)
    
    @pytest.mark.asyncio
    async def test_streaming(self, mock_llm):
        """Test streaming response."""
        chunks = []
        async for chunk in mock_llm.stream([{"role": "user", "content": "Hello"}]):
            chunks.append(chunk)
        
        assert len(chunks) > 0
        # First chunk should have role
        assert chunks[0]["choices"][0]["delta"].get("role") == "assistant"


# ==================== MockTool Tests ====================


class TestMockTool:
    """Tests for MockTool class."""
    
    @pytest.fixture
    def mock_tool(self):
        """Create a basic MockTool."""
        return MockTool(name="search", return_value={"results": ["a", "b"]})
    
    @pytest.mark.asyncio
    async def test_basic_execution(self, mock_tool):
        """Test basic tool execution."""
        result = await mock_tool.execute(query="test")
        assert result == {"results": ["a", "b"]}
        assert mock_tool.call_count == 1
    
    @pytest.mark.asyncio
    async def test_recorded_calls(self, mock_tool):
        """Test that calls are recorded."""
        await mock_tool.execute(query="first")
        await mock_tool.execute(query="second")
        
        assert len(mock_tool.recorded_calls) == 2
        assert mock_tool.recorded_calls[0].tool_args["query"] == "first"
        assert mock_tool.recorded_calls[1].tool_args["query"] == "second"
    
    @pytest.mark.asyncio
    async def test_return_values_cycle(self):
        """Test cycling through return values."""
        tool = MockTool(
            name="random",
            return_values=[1, 2, 3],
        )
        
        r1 = await tool.execute()
        r2 = await tool.execute()
        r3 = await tool.execute()
        r4 = await tool.execute()  # Cycles back
        
        assert r1 == 1
        assert r2 == 2
        assert r3 == 3
        assert r4 == 1
    
    @pytest.mark.asyncio
    async def test_side_effect(self):
        """Test side effect function."""
        def add(x: int, y: int) -> int:
            return x + y
        
        tool = MockTool(name="add", side_effect=add)
        result = await tool.execute(x=5, y=3)
        assert result == 8
    
    @pytest.mark.asyncio
    async def test_async_side_effect(self):
        """Test async side effect function."""
        async def async_fetch(url: str) -> str:
            await asyncio.sleep(0.01)
            return f"Fetched: {url}"
        
        tool = MockTool(name="fetch", side_effect=async_fetch)
        result = await tool.execute(url="http://example.com")
        assert result == "Fetched: http://example.com"
    
    @pytest.mark.asyncio
    async def test_fail_after(self):
        """Test fail_after configuration."""
        tool = MockTool(name="flaky", return_value="ok")
        tool.config.fail_after = 2
        tool.config.fail_message = "Tool failed"
        
        await tool.execute()  # OK
        await tool.execute()  # OK
        
        with pytest.raises(MockToolError) as exc_info:
            await tool.execute()  # Fails
        
        assert "Tool failed" in str(exc_info.value)
    
    @pytest.mark.asyncio
    async def test_assert_called(self, mock_tool):
        """Test assert_called method."""
        with pytest.raises(AssertionError):
            mock_tool.assert_called()
        
        await mock_tool.execute(query="test")
        mock_tool.assert_called()  # Should not raise
    
    @pytest.mark.asyncio
    async def test_assert_called_with(self, mock_tool):
        """Test assert_called_with method."""
        await mock_tool.execute(query="test", limit=10)
        
        mock_tool.assert_called_with(query="test")
        mock_tool.assert_called_with(limit=10)
        mock_tool.assert_called_with(query="test", limit=10)
        
        with pytest.raises(AssertionError):
            mock_tool.assert_called_with(query="other")
    
    @pytest.mark.asyncio
    async def test_reset(self, mock_tool):
        """Test reset functionality."""
        await mock_tool.execute(query="test")
        mock_tool.reset()
        
        assert mock_tool.call_count == 0
        assert len(mock_tool.recorded_calls) == 0


# ==================== MockToolRegistry Tests ====================


class TestMockToolRegistry:
    """Tests for MockToolRegistry class."""
    
    @pytest.fixture
    def registry(self):
        """Create a registry with tools."""
        reg = MockToolRegistry()
        reg.register(MockTool(name="search", return_value=["a", "b"]))
        reg.register(MockTool(name="calculate", return_value=42))
        return reg
    
    def test_register_and_get(self, registry):
        """Test registering and getting tools."""
        assert registry.has("search")
        assert registry.has("calculate")
        assert not registry.has("nonexistent")
        
        tool = registry.get("search")
        assert tool is not None
        assert tool.name == "search"
    
    @pytest.mark.asyncio
    async def test_execute(self, registry):
        """Test executing tools by name."""
        result = await registry.execute("search", query="test")
        assert result == ["a", "b"]
        
        result = await registry.execute("calculate", x=1, y=2)
        assert result == 42
    
    @pytest.mark.asyncio
    async def test_execute_nonexistent(self, registry):
        """Test executing nonexistent tool."""
        with pytest.raises(MockToolError) as exc_info:
            await registry.execute("nonexistent")
        
        assert "not found" in str(exc_info.value)
    
    @pytest.mark.asyncio
    async def test_reset_all(self, registry):
        """Test resetting all tools."""
        await registry.execute("search")
        await registry.execute("calculate")
        
        registry.reset_all()
        
        assert registry.get("search").call_count == 0
        assert registry.get("calculate").call_count == 0
    
    @pytest.mark.asyncio
    async def test_get_all_calls(self, registry):
        """Test getting all recorded calls."""
        await registry.execute("search", q="a")
        await registry.execute("search", q="b")
        await registry.execute("calculate", x=1)
        
        calls = registry.get_all_calls()
        assert len(calls["search"]) == 2
        assert len(calls["calculate"]) == 1


# ==================== MockAgent Tests ====================


class TestMockAgent:
    """Tests for MockAgent class."""
    
    @pytest.fixture
    def mock_agent(self):
        """Create a MockAgent."""
        return MockAgent(
            name="test_agent",
            responses=["Response 1", "Response 2"],
        )
    
    @pytest.mark.asyncio
    async def test_basic_run(self, mock_agent):
        """Test basic agent run."""
        result = await mock_agent.run("Hello")
        
        assert result["content"] == "Response 1"
        assert len(mock_agent.history) == 2  # User + assistant
    
    @pytest.mark.asyncio
    async def test_conversation_history(self, mock_agent):
        """Test conversation history tracking."""
        await mock_agent.run("First message")
        await mock_agent.run("Second message")
        
        assert len(mock_agent.history) == 4
        assert mock_agent.history[0]["content"] == "First message"
        assert mock_agent.history[1]["content"] == "Response 1"
        assert mock_agent.history[2]["content"] == "Second message"
        assert mock_agent.history[3]["content"] == "Response 2"
    
    @pytest.mark.asyncio
    async def test_reset(self, mock_agent):
        """Test agent reset."""
        await mock_agent.run("Test")
        mock_agent.reset()
        
        assert len(mock_agent.history) == 0
        assert mock_agent.model.call_count == 0


# ==================== TestContext Tests ====================


class TestTestContext:
    """Tests for TestContext class."""
    
    @pytest.fixture
    def ctx(self):
        """Create a TestContext."""
        return TestContext()
    
    def test_add_llm_response(self, ctx):
        """Test adding LLM responses."""
        ctx.add_llm_response("Hello")
        ctx.add_llm_responses("World", "!")
        
        assert len(ctx.mock_llm.config.responses) == 3
    
    def test_register_mock_tool(self, ctx):
        """Test registering mock tools."""
        tool = ctx.register_mock_tool("search", return_value="results")
        
        assert ctx.mock_tools.has("search")
        assert tool.name == "search"
    
    def test_assert_true(self, ctx):
        """Test assert_true method."""
        ctx.assert_true(True, "Should pass")
        
        with pytest.raises(AssertionError):
            ctx.assert_true(False, "Should fail")
    
    def test_assert_equal(self, ctx):
        """Test assert_equal method."""
        ctx.assert_equal(1, 1)
        
        with pytest.raises(AssertionError):
            ctx.assert_equal(1, 2)
    
    def test_assert_response_contains(self, ctx):
        """Test assert_response_contains method."""
        ctx.assert_response_contains("Hello, world!", "world")
        ctx.assert_response_contains({"content": "Hello"}, "Hello")
        
        with pytest.raises(AssertionError):
            ctx.assert_response_contains("Hello", "xyz")
    
    @pytest.mark.asyncio
    async def test_assert_tool_called(self, ctx):
        """Test assert_tool_called method."""
        tool = ctx.register_mock_tool("search", return_value="ok")
        await tool.execute()
        
        ctx.assert_tool_called("search")
        
        with pytest.raises(AssertionError):
            ctx.assert_tool_called("nonexistent")
    
    def test_duration(self, ctx):
        """Test duration tracking."""
        import time
        time.sleep(0.01)
        assert ctx.duration_ms >= 10
    
    def test_reset(self, ctx):
        """Test reset functionality."""
        ctx.add_llm_response("Test")
        ctx.register_mock_tool("test")
        ctx._assertions.append((True, "test"))
        
        ctx.reset()
        
        assert ctx.mock_llm.call_count == 0
        assert len(ctx._assertions) == 0


# ==================== Decorator Tests ====================


class TestDecorators:
    """Tests for test decorators."""
    
    @pytest.mark.asyncio
    async def test_agent_test_decorator(self):
        """Test @agent_test decorator."""
        @agent_test
        async def my_test(ctx: TestContext):
            ctx.add_llm_response("Hello")
            response = await ctx.mock_llm.chat([{"role": "user", "content": "Hi"}])
            ctx.assert_response_contains(response["choices"][0]["message"], "Hello")
        
        result = await my_test()
        assert result.status == TestStatus.PASSED
    
    @pytest.mark.asyncio
    async def test_agent_test_failure(self):
        """Test @agent_test with failure."""
        @agent_test
        async def failing_test(ctx: TestContext):
            ctx.assert_true(False, "This should fail")
        
        result = await failing_test()
        assert result.status == TestStatus.FAILED
        assert "This should fail" in result.error
    
    @pytest.mark.asyncio
    async def test_with_mock_llm_decorator(self):
        """Test @with_mock_llm decorator."""
        @with_mock_llm(responses=["Hello!", "Hi there!"])
        async def test_with_mock(mock_llm: MockLLM):
            r1 = await mock_llm.chat([{"role": "user", "content": "1"}])
            r2 = await mock_llm.chat([{"role": "user", "content": "2"}])
            return r1, r2
        
        r1, r2 = await test_with_mock()
        assert r1["choices"][0]["message"]["content"] == "Hello!"
        assert r2["choices"][0]["message"]["content"] == "Hi there!"
    
    @pytest.mark.asyncio
    async def test_with_mock_tools_decorator(self):
        """Test @with_mock_tools decorator."""
        @with_mock_tools(
            ("search", ["result1", "result2"]),
            ("calculate", 42),
        )
        async def test_with_tools(mock_tools: MockToolRegistry):
            r1 = await mock_tools.execute("search")
            r2 = await mock_tools.execute("calculate")
            return r1, r2
        
        r1, r2 = await test_with_tools()
        assert r1 == ["result1", "result2"]
        assert r2 == 42


# ==================== Context Manager Tests ====================


class TestContextManagers:
    """Tests for context managers."""
    
    @pytest.mark.asyncio
    async def test_mock_llm_context(self):
        """Test mock_llm_context."""
        async with mock_llm_context(["Hello", "World"]) as mock:
            r1 = await mock.chat([{"role": "user", "content": "1"}])
            r2 = await mock.chat([{"role": "user", "content": "2"}])
            
            assert r1["choices"][0]["message"]["content"] == "Hello"
            assert r2["choices"][0]["message"]["content"] == "World"
    
    @pytest.mark.asyncio
    async def test_mock_tool_context(self):
        """Test mock_tool_context."""
        with mock_tool_context("test", return_value=42) as mock:
            result = await mock.execute()
            assert result == 42


# ==================== ConversationFixture Tests ====================


class TestConversationFixture:
    """Tests for ConversationFixture class."""
    
    @pytest.mark.asyncio
    async def test_multi_turn_conversation(self):
        """Test multi-turn conversation."""
        mock = MockLLM(responses=["Hello!", "I'm good, thanks!", "Bye!"])
        fixture = ConversationFixture(mock_llm=mock)
        
        async with fixture as conv:
            r1 = await conv.send("Hi")
            r2 = await conv.send("How are you?")
            r3 = await conv.send("Goodbye")
        
        assert r1 == "Hello!"
        assert r2 == "I'm good, thanks!"
        assert r3 == "Bye!"
        assert fixture.turn_count == 3
    
    @pytest.mark.asyncio
    async def test_history_tracking(self):
        """Test conversation history tracking."""
        mock = MockLLM(responses=["Response 1", "Response 2"])
        fixture = ConversationFixture(mock_llm=mock)
        
        await fixture.send("Message 1")
        await fixture.send("Message 2")
        
        assert len(fixture.history) == 4
        assert fixture.history[0]["role"] == "user"
        assert fixture.history[1]["role"] == "assistant"
    
    @pytest.mark.asyncio
    async def test_last_response(self):
        """Test last_response property."""
        mock = MockLLM(responses=["First", "Second"])
        fixture = ConversationFixture(mock_llm=mock)
        
        assert fixture.last_response is None
        
        await fixture.send("Test")
        assert fixture.last_response == "First"
        
        await fixture.send("Test 2")
        assert fixture.last_response == "Second"


# ==================== TestScenario Tests ====================


class TestTestScenario:
    """Tests for TestScenario class."""
    
    def test_scenario_creation(self):
        """Test scenario creation."""
        scenario = TestScenario(
            name="greeting_test",
            description="Test greeting flow",
            tags=["greeting", "basic"],
        )
        assert scenario.name == "greeting_test"
        assert len(scenario.turns) == 0
    
    def test_add_turn(self):
        """Test adding turns."""
        scenario = (
            TestScenario(name="test")
            .add_turn("Hello", expected_contains=["hi", "hello"])
            .add_turn("What's 2+2?", expected_contains=["4"])
        )
        assert len(scenario.turns) == 2
    
    def test_to_dict(self):
        """Test conversion to dictionary."""
        scenario = TestScenario(
            name="test",
            description="A test",
            tags=["tag1"],
        )
        scenario.add_turn("Hello", expected_contains=["hi"])
        
        d = scenario.to_dict()
        assert d["name"] == "test"
        assert d["description"] == "A test"
        assert len(d["turns"]) == 1


# ==================== ScenarioRunner Tests ====================


class TestScenarioRunner:
    """Tests for ScenarioRunner class."""
    
    @pytest.mark.asyncio
    async def test_run_passing_scenario(self):
        """Test running a passing scenario."""
        mock = MockLLM(responses=["Hello there!", "4", "Bye!"])
        runner = ScenarioRunner(mock_llm=mock)
        
        scenario = (
            TestScenario(name="math_test")
            .add_turn("Hi", expected_contains=["hello"])
            .add_turn("What is 2+2?", expected_contains=["4"])
            .add_turn("Bye", expected_contains=["bye"])
        )
        
        result = await runner.run(scenario)
        assert result.passed
    
    @pytest.mark.asyncio
    async def test_run_failing_scenario(self):
        """Test running a failing scenario."""
        mock = MockLLM(responses=["Hello", "I don't know"])
        runner = ScenarioRunner(mock_llm=mock)
        
        scenario = (
            TestScenario(name="fail_test")
            .add_turn("Hi", expected_contains=["hello"])
            .add_turn("What is 2+2?", expected_contains=["4"])  # Will fail
        )
        
        result = await runner.run(scenario)
        assert result.failed
        assert "Expected '4'" in result.error


# ==================== TestSuite Tests ====================


class TestTestSuite:
    """Tests for TestSuite and TestSuiteBuilder."""
    
    @pytest.mark.asyncio
    async def test_suite_builder(self):
        """Test building a test suite."""
        suite = (
            TestSuiteBuilder("my_suite")
            .with_mock_llm(responses=["A", "B", "C", "D"])
            .with_mock_tool("search", return_value="results")
            .add_scenario(
                TestScenario(name="test1").add_turn("Q1", expected_contains=["a"])
            )
            .add_scenario(
                TestScenario(name="test2").add_turn("Q2", expected_contains=["c"])
            )
            .build()
        )
        
        assert suite.name == "my_suite"
        assert len(suite.scenarios) == 2
    
    @pytest.mark.asyncio
    async def test_suite_run(self):
        """Test running a test suite."""
        # Each scenario gets the first response after reset since cycle=True
        config = MockLLMConfig.from_strings(
            "Hello! Hi there!",  # Contains "hello"
            "Goodbye! Farewell!",  # Contains "goodbye"
            cycle=True,
        )
        suite = (
            TestSuiteBuilder("test_suite")
            .with_mock_llm(config=config)
            .add_scenario(
                TestScenario(name="greet").add_turn("Hi", expected_contains=["hello"])
            )
            .add_scenario(
                TestScenario(name="farewell").add_turn("Bye", expected_contains=["goodbye"])
            )
            .build()
        )
        
        result = await suite.run()
        
        assert result.total_tests == 2
        assert result.passed_tests == 2
        assert result.pass_rate == 100.0


# ==================== AgentAssertions Tests ====================


class TestAgentAssertions:
    """Tests for AgentAssertions class."""
    
    @pytest.fixture
    def mock_llm(self):
        """Create a MockLLM for assertions."""
        mock = MockLLM(responses=[
            MockResponse.tool_call("search", {"q": "test"}),
            MockResponse.text("Results found"),
        ])
        return mock
    
    @pytest.fixture
    def mock_tools(self):
        """Create MockToolRegistry for assertions."""
        registry = MockToolRegistry()
        registry.register(MockTool(name="search", return_value="results"))
        registry.register(MockTool(name="calculate", return_value=42))
        return registry
    
    @pytest.mark.asyncio
    async def test_assert_tool_called(self, mock_tools):
        """Test assert_tool_called assertion."""
        await mock_tools.execute("search", q="test")
        
        assertions = AgentAssertions(mock_tools=mock_tools)
        result = assertions.assert_tool_called("search")
        assert result.passed
        
        with pytest.raises(AssertionError):
            assertions.assert_tool_called("nonexistent")
    
    @pytest.mark.asyncio
    async def test_assert_tool_not_called(self, mock_tools):
        """Test assert_tool_not_called assertion."""
        await mock_tools.execute("search")
        
        assertions = AgentAssertions(mock_tools=mock_tools)
        assertions.assert_tool_not_called("calculate")  # Should pass
        
        with pytest.raises(AssertionError):
            assertions.assert_tool_not_called("search")  # Should fail
    
    def test_assert_response_contains(self):
        """Test assert_response_contains assertion."""
        assertions = AgentAssertions()
        
        result = assertions.assert_response_contains("Hello, world!", "world")
        assert result.passed
        
        result = assertions.assert_response_contains(
            {"content": "Hello"}, "hello", case_sensitive=False
        )
        assert result.passed
    
    def test_assert_response_matches(self):
        """Test assert_response_matches assertion."""
        assertions = AgentAssertions()
        
        result = assertions.assert_response_matches(
            "The result is 42.",
            r"\d+"
        )
        assert result.passed
        
        with pytest.raises(AssertionError):
            assertions.assert_response_matches("No numbers here", r"\d+")
    
    @pytest.mark.asyncio
    async def test_assert_cost_under(self, mock_llm):
        """Test assert_cost_under assertion."""
        await mock_llm.chat([{"role": "user", "content": "Hi"}])
        
        assertions = AgentAssertions(mock_llm=mock_llm)
        result = assertions.assert_cost_under(100.0)  # Mock has 0 cost
        assert result.passed
    
    @pytest.mark.asyncio
    async def test_assert_llm_called(self, mock_llm):
        """Test assert_llm_called assertion."""
        assertions = AgentAssertions(mock_llm=mock_llm)
        
        with pytest.raises(AssertionError):
            assertions.assert_llm_called()  # Not called yet
        
        await mock_llm.chat([{"role": "user", "content": "Hi"}])
        assertions.assert_llm_called()  # Should pass now
        assertions.assert_llm_called(times=1)


# ==================== Standalone Assertion Tests ====================


class TestStandaloneAssertions:
    """Tests for standalone assertion functions."""
    
    @pytest.mark.asyncio
    async def test_assert_tool_called_standalone(self):
        """Test standalone assert_tool_called."""
        tool = MockTool(name="test", return_value="ok")
        
        with pytest.raises(AssertionError):
            assert_tool_called(tool, "test")
        
        await tool.execute()
        assert_tool_called(tool, "test")  # Should pass
    
    @pytest.mark.asyncio
    async def test_assert_tool_not_called_standalone(self):
        """Test standalone assert_tool_not_called."""
        tool = MockTool(name="test", return_value="ok")
        
        assert_tool_not_called(tool, "test")  # Should pass
        
        await tool.execute()
        with pytest.raises(AssertionError):
            assert_tool_not_called(tool, "test")
    
    def test_assert_response_contains_standalone(self):
        """Test standalone assert_response_contains."""
        assert_response_contains("Hello, World!", "world", case_sensitive=False)
        
        with pytest.raises(AssertionError):
            assert_response_contains("Hello", "xyz")
    
    def test_assert_response_not_contains_standalone(self):
        """Test standalone assert_response_not_contains."""
        assert_response_not_contains("Hello, World!", "xyz")
        
        with pytest.raises(AssertionError):
            assert_response_not_contains("Hello, World!", "world", case_sensitive=False)
    
    def test_assert_response_matches_standalone(self):
        """Test standalone assert_response_matches."""
        assert_response_matches("The answer is 42", r"\d+")
        assert_response_matches("email@example.com", re.compile(r"[\w.]+@[\w.]+"))
        
        with pytest.raises(AssertionError):
            assert_response_matches("No numbers", r"\d+")
    
    @pytest.mark.asyncio
    async def test_assert_llm_called_standalone(self):
        """Test standalone assert_llm_called."""
        mock = MockLLM(responses=["Hello"])
        
        with pytest.raises(AssertionError):
            assert_llm_called(mock)
        
        await mock.chat([{"role": "user", "content": "Hi"}])
        assert_llm_called(mock)
        assert_llm_called(mock, times=1)


# ==================== TestMetrics Tests ====================


class TestTestMetrics:
    """Tests for TestMetrics class."""
    
    def test_record_call(self):
        """Test recording calls."""
        metrics = TestMetrics()
        
        metrics.record_call(tokens=100, cost=0.01, duration_ms=50)
        metrics.record_call(tokens=200, cost=0.02, duration_ms=75, tool_name="search")
        
        assert metrics.total_calls == 2
        assert metrics.total_tokens == 300
        assert metrics.total_cost == 0.03
        assert metrics.total_duration_ms == 125
        assert metrics.tool_calls["search"] == 1
    
    def test_error_count(self):
        """Test error counting."""
        metrics = TestMetrics()
        
        metrics.record_call(is_error=True)
        metrics.record_call(is_error=False)
        metrics.record_call(is_error=True)
        
        assert metrics.error_count == 2
    
    def test_to_dict(self):
        """Test conversion to dictionary."""
        metrics = TestMetrics()
        metrics.record_call(tokens=100, tool_name="test")
        
        d = metrics.to_dict()
        assert d["total_calls"] == 1
        assert d["total_tokens"] == 100
        assert d["tool_calls"]["test"] == 1


# ==================== TestResult Tests ====================


class TestTestResult:
    """Tests for TestResult class."""
    
    def test_passed_result(self):
        """Test passed test result."""
        result = TestResult(
            name="test_something",
            status=TestStatus.PASSED,
            duration_ms=100.0,
        )
        
        assert result.passed
        assert not result.failed
    
    def test_failed_result(self):
        """Test failed test result."""
        result = TestResult(
            name="test_something",
            status=TestStatus.FAILED,
            duration_ms=100.0,
            error="Assertion failed",
        )
        
        assert result.failed
        assert not result.passed
        assert result.error == "Assertion failed"
    
    def test_assertion_counts(self):
        """Test assertion counting."""
        result = TestResult(
            name="test",
            status=TestStatus.PASSED,
            duration_ms=50,
            assertions=[
                AssertionResult(AssertionType.CUSTOM, passed=True, message="OK"),
                AssertionResult(AssertionType.CUSTOM, passed=True, message="OK"),
                AssertionResult(AssertionType.CUSTOM, passed=False, message="Failed"),
            ],
        )
        
        assert result.assertion_count == 3
        assert result.passed_assertions == 2
        assert result.failed_assertions == 1


# ==================== TestSuiteResult Tests ====================


class TestTestSuiteResult:
    """Tests for TestSuiteResult class."""
    
    def test_suite_stats(self):
        """Test suite statistics."""
        result = TestSuiteResult(name="my_suite")
        result.add_test(TestResult("test1", TestStatus.PASSED, 50))
        result.add_test(TestResult("test2", TestStatus.PASSED, 60))
        result.add_test(TestResult("test3", TestStatus.FAILED, 70))
        result.add_test(TestResult("test4", TestStatus.SKIPPED, 0))
        
        assert result.total_tests == 4
        assert result.passed_tests == 2
        assert result.failed_tests == 1
        assert result.skipped_tests == 1
        assert result.pass_rate == 50.0
        assert result.total_duration_ms == 180
    
    def test_summary(self):
        """Test summary generation."""
        result = TestSuiteResult(name="test_suite")
        result.add_test(TestResult("test1", TestStatus.PASSED, 50))
        result.add_test(TestResult("test2", TestStatus.PASSED, 50))
        
        summary = result.summary()
        assert "test_suite" in summary
        assert "2/2" in summary
        assert "100.0%" in summary
    
    def test_to_dict(self):
        """Test conversion to dictionary."""
        result = TestSuiteResult(name="suite")
        result.add_test(TestResult("test1", TestStatus.PASSED, 100))
        result.finalize()
        
        d = result.to_dict()
        assert d["name"] == "suite"
        assert d["total_tests"] == 1
        assert d["passed_tests"] == 1


# ==================== Integration Tests ====================


class TestIntegration:
    """Integration tests for the testing framework."""
    
    @pytest.mark.asyncio
    async def test_full_agent_test_workflow(self):
        """Test complete agent testing workflow."""
        # Create mock LLM with tool call followed by text response
        mock_llm = MockLLM(responses=[
            MockResponse.tool_call("web_search", {"query": "AI trends"}),
            MockResponse.text("Based on my search, AI trends include..."),
        ])
        
        # Create mock tools
        mock_tools = MockToolRegistry()
        mock_tools.register(MockTool(
            name="web_search",
            return_value={"results": ["trend1", "trend2"]},
        ))
        
        # Simulate agent workflow
        messages = [{"role": "user", "content": "What are the latest AI trends?"}]
        
        # First call - agent decides to use tool
        response1 = await mock_llm.chat(messages)
        assert response1["choices"][0]["finish_reason"] == "tool_calls"
        
        # Execute tool
        tool_result = await mock_tools.execute("web_search", query="AI trends")
        assert "results" in tool_result
        
        # Add tool result to messages
        messages.append({
            "role": "assistant",
            "tool_calls": response1["choices"][0]["message"]["tool_calls"],
        })
        messages.append({
            "role": "tool",
            "content": str(tool_result),
        })
        
        # Second call - agent generates final response
        response2 = await mock_llm.chat(messages)
        assert "AI trends" in response2["choices"][0]["message"]["content"]
        
        # Verify assertions
        assert_tool_called(mock_tools, "web_search")
        assert_llm_called(mock_llm, times=2)
        assert_response_contains(response2["choices"][0]["message"], "trends")
    
    @pytest.mark.asyncio
    async def test_scenario_based_testing(self):
        """Test scenario-based testing workflow."""
        # Define test scenarios - each scenario gets its response by index
        scenarios = [
            TestScenario(name="greeting")
            .add_turn("Hello", expected_contains=["hello"]),  # Response: "Hello! How can I help?"
            
            TestScenario(name="math_question")
            .add_turn("What is 2+2?", expected_contains=["4"]),  # Response: "2+2 equals 4."
            
            TestScenario(name="farewell")
            .add_turn("Goodbye", expected_contains=["goodbye"]),  # Response: "Goodbye! Have a nice day!"
        ]
        
        # Build test suite with cycling responses
        suite = (
            TestSuiteBuilder("conversation_tests")
            .with_mock_llm(config=MockLLMConfig.from_strings(
                "Hello! How can I help?",
                "2+2 equals 4.",
                "Goodbye! Have a nice day!",
                cycle=True,  # Cycle through responses
            ))
            .add_scenarios(*scenarios)
            .build()
        )
        
        # Run suite
        result = await suite.run()
        
        # Verify results
        assert result.total_tests == 3
        assert result.passed_tests == 3
        assert result.pass_rate == 100.0
    
    @pytest.mark.asyncio
    async def test_context_based_testing(self):
        """Test using TestContext for testing."""
        ctx = TestContext()
        
        # Setup
        ctx.add_llm_responses(
            "I'll help you with that.",
            "Here's the information you requested.",
        )
        search_tool = ctx.register_mock_tool(
            "search",
            return_value={"found": True, "data": "Important info"},
        )
        
        # Simulate agent behavior
        response1 = await ctx.mock_llm.chat([
            {"role": "user", "content": "Find info about topic X"}
        ])
        
        await search_tool.execute(query="topic X")
        
        response2 = await ctx.mock_llm.chat([
            {"role": "user", "content": "Find info about topic X"},
            {"role": "assistant", "content": response1["choices"][0]["message"]["content"]},
            {"role": "tool", "content": '{"found": true}'},
        ])
        
        # Assertions
        ctx.assert_llm_called(times=2)
        ctx.assert_tool_called("search")
        ctx.assert_response_contains(response2["choices"][0]["message"], "information")


# ==================== Edge Cases Tests ====================


class TestEdgeCases:
    """Tests for edge cases and error handling."""
    
    @pytest.mark.asyncio
    async def test_empty_responses(self):
        """Test mock with no responses configured."""
        mock = MockLLM()
        response = await mock.chat([{"role": "user", "content": "Hello"}])
        
        # Should return default mock response
        assert response["choices"][0]["message"]["content"] == "Mock response"
    
    @pytest.mark.asyncio
    async def test_empty_messages(self):
        """Test chat with empty messages."""
        mock = MockLLM(responses=["Response"])
        response = await mock.chat([])
        
        assert response["choices"][0]["message"]["content"] == "Response"
    
    def test_assertion_result_bool(self):
        """Test AssertionResult boolean conversion."""
        passed = AssertionResult(AssertionType.CUSTOM, passed=True, message="OK")
        failed = AssertionResult(AssertionType.CUSTOM, passed=False, message="Fail")
        
        assert bool(passed) is True
        assert bool(failed) is False
    
    def test_assertion_result_raise(self):
        """Test AssertionResult.raise_if_failed."""
        passed = AssertionResult(AssertionType.CUSTOM, passed=True, message="OK")
        passed.raise_if_failed()  # Should not raise
        
        failed = AssertionResult(
            AssertionType.CUSTOM,
            passed=False,
            message="Failed",
            expected=42,
            actual=0,
        )
        
        with pytest.raises(AssertionError) as exc_info:
            failed.raise_if_failed()
        
        assert "Expected: 42" in str(exc_info.value)
        assert "Actual: 0" in str(exc_info.value)
    
    @pytest.mark.asyncio
    async def test_mock_tool_no_calls(self):
        """Test mock tool properties when never called."""
        tool = MockTool(name="unused", return_value=None)
        
        assert tool.call_count == 0
        assert tool.last_call is None
        assert tool.last_args == {}
    
    def test_test_result_with_traceback(self):
        """Test TestResult with traceback."""
        result = TestResult(
            name="error_test",
            status=TestStatus.ERROR,
            duration_ms=10,
            error="Something went wrong",
            traceback="Traceback (most recent call last):\n  ...",
        )
        
        assert result.status == TestStatus.ERROR
        assert "Traceback" in result.traceback
