"""Tests for AgentThread - Persistent Conversation Sessions."""

import asyncio
import json
import os
import tempfile
from datetime import datetime
from pathlib import Path

import pytest

from multi_agent_base.core.thread import (
    AgentThread,
    ThreadCheckpoint,
    ThreadChatHistoryProvider,
    create_thread,
    resume_thread,
)
from multi_agent_base.core.agent import Message


# =============================================================================
# Basic Thread Tests
# =============================================================================


class TestAgentThreadBasics:
    """Test basic AgentThread functionality."""
    
    def test_create_thread_auto_id(self):
        """Test creating thread with auto-generated ID."""
        thread = AgentThread()
        assert thread.session_id is not None
        assert len(thread.session_id) > 0
        assert thread.message_count == 0
    
    def test_create_thread_with_id(self):
        """Test creating thread with custom ID."""
        thread = AgentThread(session_id="user_123")
        assert thread.session_id == "user_123"
    
    def test_create_thread_with_metadata(self):
        """Test creating thread with metadata."""
        thread = AgentThread(
            session_id="test",
            metadata={"user_name": "Alice", "topic": "AI"},
        )
        assert thread.metadata["user_name"] == "Alice"
        assert thread.metadata["topic"] == "AI"
    
    def test_timestamps(self):
        """Test that timestamps are set correctly."""
        thread = AgentThread()
        assert thread.created_at is not None
        assert thread.updated_at is not None
        assert thread.created_at <= thread.updated_at


class TestMessageManagement:
    """Test message management functionality."""
    
    def test_add_message(self):
        """Test adding a message."""
        thread = AgentThread()
        message = Message(role="user", content="Hello")
        thread.add_message(message)
        
        assert thread.message_count == 1
        assert thread.messages[0].role == "user"
        assert thread.messages[0].content == "Hello"
    
    def test_add_multiple_messages(self):
        """Test adding multiple messages."""
        thread = AgentThread()
        thread.add_messages([
            Message(role="user", content="Hi"),
            Message(role="assistant", content="Hello!"),
        ])
        
        assert thread.message_count == 2
    
    def test_add_user_message(self):
        """Test convenience method for user messages."""
        thread = AgentThread()
        msg = thread.add_user_message("How are you?")
        
        assert msg.role == "user"
        assert msg.content == "How are you?"
        assert thread.message_count == 1
    
    def test_add_assistant_message(self):
        """Test convenience method for assistant messages."""
        thread = AgentThread()
        msg = thread.add_assistant_message("I'm fine, thanks!")
        
        assert msg.role == "assistant"
        assert msg.content == "I'm fine, thanks!"
    
    def test_add_system_message(self):
        """Test convenience method for system messages."""
        thread = AgentThread()
        msg = thread.add_system_message("You are a helpful assistant.")
        
        assert msg.role == "system"
    
    def test_get_recent_messages(self):
        """Test getting recent messages."""
        thread = AgentThread()
        for i in range(20):
            thread.add_user_message(f"Message {i}")
        
        recent = thread.get_recent_messages(5)
        assert len(recent) == 5
        assert recent[0].content == "Message 15"
        assert recent[-1].content == "Message 19"
    
    def test_get_messages_by_role(self):
        """Test filtering messages by role."""
        thread = AgentThread()
        thread.add_user_message("Q1")
        thread.add_assistant_message("A1")
        thread.add_user_message("Q2")
        thread.add_assistant_message("A2")
        
        user_messages = thread.get_messages_by_role("user")
        assert len(user_messages) == 2
        assert all(m.role == "user" for m in user_messages)
    
    def test_last_message(self):
        """Test getting last message."""
        thread = AgentThread()
        assert thread.last_message is None
        
        thread.add_user_message("Hello")
        assert thread.last_message.content == "Hello"
        
        thread.add_assistant_message("Hi!")
        assert thread.last_message.content == "Hi!"
    
    def test_clear_messages(self):
        """Test clearing messages."""
        thread = AgentThread()
        thread.add_user_message("Hello")
        thread.add_assistant_message("Hi!")
        
        thread.clear_messages()
        assert thread.message_count == 0


class TestCheckpoints:
    """Test checkpoint functionality."""
    
    def test_create_checkpoint(self):
        """Test creating a checkpoint."""
        thread = AgentThread()
        thread.add_user_message("Message 1")
        thread.add_assistant_message("Response 1")
        
        cp = thread.create_checkpoint("after_intro")
        
        assert cp.name == "after_intro"
        assert cp.message_index == 2
        assert len(thread.checkpoints) == 1
    
    def test_checkpoint_with_metadata(self):
        """Test checkpoint with metadata."""
        thread = AgentThread()
        thread.add_user_message("Hello")
        
        cp = thread.create_checkpoint(
            "start",
            metadata={"reason": "initial state"},
        )
        
        assert cp.metadata["reason"] == "initial state"
    
    def test_rollback_to_checkpoint(self):
        """Test rolling back to a checkpoint."""
        thread = AgentThread()
        thread.add_user_message("Message 1")
        thread.add_assistant_message("Response 1")
        
        cp = thread.create_checkpoint("checkpoint_1")
        
        thread.add_user_message("Message 2")
        thread.add_assistant_message("Response 2")
        
        assert thread.message_count == 4
        
        success = thread.rollback_to_checkpoint(cp.checkpoint_id)
        
        assert success
        assert thread.message_count == 2
        assert thread.last_message.content == "Response 1"
    
    def test_rollback_removes_later_checkpoints(self):
        """Test that rollback removes later checkpoints."""
        thread = AgentThread()
        thread.add_user_message("M1")
        cp1 = thread.create_checkpoint("cp1")
        
        thread.add_user_message("M2")
        cp2 = thread.create_checkpoint("cp2")
        
        thread.add_user_message("M3")
        
        thread.rollback_to_checkpoint(cp1.checkpoint_id)
        
        assert len(thread.checkpoints) == 1
        assert thread.checkpoints[0].name == "cp1"
    
    def test_get_checkpoint(self):
        """Test getting checkpoint by ID."""
        thread = AgentThread()
        thread.add_user_message("Hello")
        cp = thread.create_checkpoint("test")
        
        found = thread.get_checkpoint(cp.checkpoint_id)
        assert found is not None
        assert found.name == "test"
        
        not_found = thread.get_checkpoint("invalid")
        assert not_found is None
    
    def test_get_checkpoint_by_name(self):
        """Test getting checkpoint by name."""
        thread = AgentThread()
        thread.add_user_message("Hello")
        thread.create_checkpoint("start")
        
        found = thread.get_checkpoint_by_name("start")
        assert found is not None


class TestVariables:
    """Test thread-scoped variable management."""
    
    def test_set_and_get_variable(self):
        """Test setting and getting variables."""
        thread = AgentThread()
        thread.set_variable("count", 10)
        
        assert thread.get_variable("count") == 10
    
    def test_get_variable_default(self):
        """Test getting variable with default."""
        thread = AgentThread()
        
        value = thread.get_variable("missing", default="default_value")
        assert value == "default_value"
    
    def test_delete_variable(self):
        """Test deleting a variable."""
        thread = AgentThread()
        thread.set_variable("temp", "value")
        
        assert thread.delete_variable("temp")
        assert thread.get_variable("temp") is None
        
        # Deleting non-existent returns False
        assert not thread.delete_variable("nonexistent")
    
    def test_variables_property(self):
        """Test variables property access."""
        thread = AgentThread()
        thread.set_variable("a", 1)
        thread.set_variable("b", 2)
        
        assert thread.variables == {"a": 1, "b": 2}


class TestSerialization:
    """Test serialization functionality."""
    
    def test_to_dict(self):
        """Test serializing to dictionary."""
        thread = AgentThread(session_id="test_123")
        thread.add_user_message("Hello")
        thread.add_assistant_message("Hi!")
        thread.create_checkpoint("cp1")
        thread.set_variable("count", 5)
        
        data = thread.to_dict()
        
        assert data["session_id"] == "test_123"
        assert len(data["messages"]) == 2
        assert len(data["checkpoints"]) == 1
        assert data["variables"]["count"] == 5
    
    def test_from_dict(self):
        """Test deserializing from dictionary."""
        original = AgentThread(session_id="test_456")
        original.add_user_message("Question")
        original.add_assistant_message("Answer")
        original.set_variable("key", "value")
        
        data = original.to_dict()
        restored = AgentThread.from_dict(data)
        
        assert restored.session_id == "test_456"
        assert restored.message_count == 2
        assert restored.get_variable("key") == "value"
    
    def test_to_json(self):
        """Test JSON serialization."""
        thread = AgentThread(session_id="json_test")
        thread.add_user_message("Test")
        
        json_str = thread.to_json()
        parsed = json.loads(json_str)
        
        assert parsed["session_id"] == "json_test"
    
    def test_from_json(self):
        """Test JSON deserialization."""
        original = AgentThread(session_id="json_test_2")
        original.add_user_message("Hello")
        
        json_str = original.to_json()
        restored = AgentThread.from_json(json_str)
        
        assert restored.session_id == "json_test_2"
        assert restored.message_count == 1


class TestFilePersistence:
    """Test file-based persistence."""
    
    @pytest.mark.asyncio
    async def test_save_and_load(self):
        """Test saving and loading thread."""
        with tempfile.TemporaryDirectory() as tmpdir:
            # Create and save
            thread = AgentThread(session_id="persist_test")
            thread.add_user_message("Saved message")
            thread.set_variable("persisted", True)
            
            path = await thread.save(tmpdir)
            assert Path(path).exists()
            
            # Load
            loaded = await AgentThread.load("persist_test", tmpdir)
            
            assert loaded.session_id == "persist_test"
            assert loaded.message_count == 1
            assert loaded.get_variable("persisted") is True
    
    @pytest.mark.asyncio
    async def test_save_creates_directory(self):
        """Test that save creates directory if needed."""
        with tempfile.TemporaryDirectory() as tmpdir:
            nested_path = Path(tmpdir) / "nested" / "deep"
            
            thread = AgentThread(session_id="nested_test")
            await thread.save(str(nested_path))
            
            assert (nested_path / "nested_test.json").exists()
    
    @pytest.mark.asyncio
    async def test_load_or_create_existing(self):
        """Test load_or_create with existing thread."""
        with tempfile.TemporaryDirectory() as tmpdir:
            # Save first
            thread = AgentThread(session_id="existing")
            thread.add_user_message("Existing message")
            await thread.save(tmpdir)
            
            # Load or create
            loaded = await AgentThread.load_or_create("existing", tmpdir)
            
            assert loaded.message_count == 1
    
    @pytest.mark.asyncio
    async def test_load_or_create_new(self):
        """Test load_or_create with new thread."""
        with tempfile.TemporaryDirectory() as tmpdir:
            thread = await AgentThread.load_or_create(
                "new_session",
                tmpdir,
                metadata={"new": True},
            )
            
            assert thread.session_id == "new_session"
            assert thread.metadata["new"] is True
            assert thread.message_count == 0
    
    @pytest.mark.asyncio
    async def test_list_sessions(self):
        """Test listing available sessions."""
        with tempfile.TemporaryDirectory() as tmpdir:
            # Create multiple sessions
            for i in range(3):
                thread = AgentThread(session_id=f"session_{i}")
                await thread.save(tmpdir)
            
            sessions = await AgentThread.list_sessions(tmpdir)
            
            assert len(sessions) == 3
            assert "session_0" in sessions
            assert "session_1" in sessions
            assert "session_2" in sessions
    
    @pytest.mark.asyncio
    async def test_delete(self):
        """Test deleting thread file."""
        with tempfile.TemporaryDirectory() as tmpdir:
            thread = AgentThread(session_id="to_delete")
            path = await thread.save(tmpdir)
            
            assert Path(path).exists()
            
            result = await thread.delete()
            
            assert result is True
            assert not Path(path).exists()
    
    @pytest.mark.asyncio
    async def test_load_not_found(self):
        """Test loading non-existent session raises error."""
        with tempfile.TemporaryDirectory() as tmpdir:
            with pytest.raises(FileNotFoundError):
                await AgentThread.load("nonexistent", tmpdir)


class TestFork:
    """Test thread forking functionality."""
    
    def test_fork_creates_copy(self):
        """Test that fork creates a copy."""
        original = AgentThread(session_id="original")
        original.add_user_message("Message 1")
        original.add_assistant_message("Response 1")
        original.set_variable("count", 10)
        
        forked = original.fork("forked")
        
        assert forked.session_id == "forked"
        assert forked.message_count == 2
        assert forked.get_variable("count") == 10
    
    def test_fork_is_independent(self):
        """Test that fork is independent of original."""
        original = AgentThread(session_id="original")
        original.add_user_message("Original message")
        
        forked = original.fork()
        forked.add_user_message("Forked message")
        
        assert original.message_count == 1
        assert forked.message_count == 2
    
    def test_fork_metadata(self):
        """Test that fork includes fork metadata."""
        original = AgentThread(session_id="parent")
        forked = original.fork("child")
        
        assert forked.metadata["forked_from"] == "parent"
        assert "forked_at" in forked.metadata


class TestChatHistoryProvider:
    """Test ChatHistoryProvider integration."""
    
    def test_to_chat_messages(self):
        """Test converting to ChatMessage format."""
        thread = AgentThread()
        thread.add_user_message("Hello")
        thread.add_assistant_message("Hi!")
        
        chat_messages = thread.to_chat_messages()
        
        assert len(chat_messages) == 2
        assert chat_messages[0].role == "user"
        assert chat_messages[0].content == "Hello"
    
    def test_as_chat_history_provider(self):
        """Test creating ChatHistoryProvider."""
        thread = AgentThread()
        thread.add_user_message("Test")
        
        provider = thread.as_chat_history_provider()
        
        assert isinstance(provider, ThreadChatHistoryProvider)
        assert provider.thread is thread
    
    @pytest.mark.asyncio
    async def test_provider_invoking_async(self):
        """Test ChatHistoryProvider.invoking_async."""
        from multi_agent_base.core.chat_history import InvokingContext
        
        thread = AgentThread()
        thread.add_user_message("Message 1")
        thread.add_assistant_message("Response 1")
        
        provider = thread.as_chat_history_provider()
        
        messages = await provider.invoking_async(InvokingContext())
        
        assert len(messages) == 2


class TestConvenienceFunctions:
    """Test convenience functions."""
    
    @pytest.mark.asyncio
    async def test_create_thread(self):
        """Test create_thread function."""
        thread = await create_thread(
            session_id="convenience_test",
            system_prompt="You are helpful.",
            metadata={"key": "value"},
        )
        
        assert thread.session_id == "convenience_test"
        assert thread.message_count == 1
        assert thread.messages[0].role == "system"
        assert thread.metadata["key"] == "value"
    
    @pytest.mark.asyncio
    async def test_resume_thread(self):
        """Test resume_thread function."""
        with tempfile.TemporaryDirectory() as tmpdir:
            # Create and save
            thread = AgentThread(session_id="resume_test")
            thread.add_user_message("Saved")
            await thread.save(tmpdir)
            
            # Resume
            resumed = await resume_thread("resume_test", path=tmpdir)
            
            assert resumed.session_id == "resume_test"
            assert resumed.message_count == 1


class TestUtilities:
    """Test utility methods."""
    
    def test_get_summary(self):
        """Test getting thread summary."""
        thread = AgentThread(session_id="summary_test")
        thread.add_user_message("Hello")
        thread.add_assistant_message("Hi!")
        thread.create_checkpoint("cp1")
        thread.set_variable("count", 10)
        
        summary = thread.get_summary()
        
        assert summary["session_id"] == "summary_test"
        assert summary["message_count"] == 2
        assert summary["checkpoint_count"] == 1
        assert summary["variable_count"] == 1
        assert summary["last_message_role"] == "assistant"
    
    def test_repr(self):
        """Test string representation."""
        thread = AgentThread(session_id="repr_test")
        thread.add_user_message("Hello")
        
        repr_str = repr(thread)
        
        assert "repr_test" in repr_str
        assert "messages=1" in repr_str
    
    def test_len(self):
        """Test len() on thread."""
        thread = AgentThread()
        assert len(thread) == 0
        
        thread.add_user_message("Hello")
        assert len(thread) == 1
        
        thread.add_assistant_message("Hi!")
        assert len(thread) == 2


# =============================================================================
# Run Tests
# =============================================================================

if __name__ == "__main__":
    pytest.main([__file__, "-v"])
