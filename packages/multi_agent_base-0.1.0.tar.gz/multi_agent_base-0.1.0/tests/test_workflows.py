"""Tests for AF Workflows Adapter."""

import pytest
from datetime import datetime

from multi_agent_base.core.workflows import (
    Workflow,
    WorkflowBuilder,
    WorkflowResult,
    WorkflowState,
    WorkflowContext,
    WorkflowCheckpoint,
    Executor,
    FunctionExecutor,
    AgentExecutor,
    RouterExecutor,
    Edge,
    ExecutorResult,
    ExecutorType,
    CheckpointStore,
    InMemoryCheckpointStore,
    SequentialWorkflowBuilder,
    ConcurrentWorkflowBuilder,
)


class TestWorkflowCheckpoint:
    """Tests for WorkflowCheckpoint."""
    
    def test_create_checkpoint(self):
        """Test creating a checkpoint."""
        checkpoint = WorkflowCheckpoint(
            id="cp-1",
            workflow_id="wf-1",
            state=WorkflowState.RUNNING,
            current_executor_id="exec-1",
        )
        
        assert checkpoint.id == "cp-1"
        assert checkpoint.workflow_id == "wf-1"
        assert checkpoint.state == WorkflowState.RUNNING
        assert checkpoint.current_executor_id == "exec-1"
    
    def test_checkpoint_to_dict(self):
        """Test serializing checkpoint to dict."""
        checkpoint = WorkflowCheckpoint(
            id="cp-1",
            workflow_id="wf-1",
            state=WorkflowState.COMPLETED,
            current_executor_id=None,
            completed_executors=["exec-1", "exec-2"],
            shared_state={"key": "value"},
        )
        
        data = checkpoint.to_dict()
        
        assert data["id"] == "cp-1"
        assert data["state"] == "completed"
        assert data["completed_executors"] == ["exec-1", "exec-2"]
        assert data["shared_state"] == {"key": "value"}
    
    def test_checkpoint_from_dict(self):
        """Test deserializing checkpoint from dict."""
        data = {
            "id": "cp-2",
            "workflow_id": "wf-2",
            "state": "paused",
            "current_executor_id": "exec-3",
            "completed_executors": ["exec-1"],
            "shared_state": {"count": 42},
            "created_at": "2024-01-01T00:00:00",
        }
        
        checkpoint = WorkflowCheckpoint.from_dict(data)
        
        assert checkpoint.id == "cp-2"
        assert checkpoint.state == WorkflowState.PAUSED
        assert checkpoint.shared_state["count"] == 42


class TestInMemoryCheckpointStore:
    """Tests for InMemoryCheckpointStore."""
    
    @pytest.mark.asyncio
    async def test_save_and_load(self):
        """Test saving and loading checkpoints."""
        store = InMemoryCheckpointStore()
        
        checkpoint = WorkflowCheckpoint(
            id="cp-1",
            workflow_id="wf-1",
            state=WorkflowState.RUNNING,
            current_executor_id="exec-1",
        )
        
        await store.save(checkpoint)
        loaded = await store.load("cp-1")
        
        assert loaded is not None
        assert loaded.id == "cp-1"
    
    @pytest.mark.asyncio
    async def test_load_latest(self):
        """Test loading the latest checkpoint for a workflow."""
        store = InMemoryCheckpointStore()
        
        for i in range(3):
            checkpoint = WorkflowCheckpoint(
                id=f"cp-{i}",
                workflow_id="wf-1",
                state=WorkflowState.RUNNING,
                current_executor_id=f"exec-{i}",
            )
            await store.save(checkpoint)
        
        latest = await store.load_latest("wf-1")
        
        assert latest is not None
        assert latest.id == "cp-2"
    
    @pytest.mark.asyncio
    async def test_list_checkpoints(self):
        """Test listing checkpoints for a workflow."""
        store = InMemoryCheckpointStore()
        
        for i in range(3):
            await store.save(WorkflowCheckpoint(
                id=f"cp-{i}",
                workflow_id="wf-1",
                state=WorkflowState.RUNNING,
                current_executor_id=f"exec-{i}",
            ))
        
        # Different workflow
        await store.save(WorkflowCheckpoint(
            id="cp-other",
            workflow_id="wf-2",
            state=WorkflowState.RUNNING,
            current_executor_id="other",
        ))
        
        checkpoints = await store.list_checkpoints("wf-1")
        
        assert len(checkpoints) == 3
    
    @pytest.mark.asyncio
    async def test_delete_checkpoint(self):
        """Test deleting a checkpoint."""
        store = InMemoryCheckpointStore()
        
        checkpoint = WorkflowCheckpoint(
            id="cp-1",
            workflow_id="wf-1",
            state=WorkflowState.RUNNING,
            current_executor_id="exec-1",
        )
        await store.save(checkpoint)
        
        deleted = await store.delete("cp-1")
        
        assert deleted is True
        assert await store.load("cp-1") is None


class TestEdge:
    """Tests for Edge."""
    
    def test_edge_without_condition(self):
        """Test edge without condition always matches."""
        edge = Edge(source_id="a", target_id="b")
        
        assert edge.matches("anything") is True
        assert edge.matches(None) is True
        assert edge.matches(42) is True
    
    def test_edge_with_condition(self):
        """Test edge with condition."""
        edge = Edge(
            source_id="a",
            target_id="b",
            condition=lambda x: x > 10,
            condition_name="greater than 10",
        )
        
        assert edge.matches(15) is True
        assert edge.matches(5) is False


class TestFunctionExecutor:
    """Tests for FunctionExecutor."""
    
    @pytest.mark.asyncio
    async def test_sync_function(self):
        """Test executing a sync function."""
        def uppercase(text: str, ctx: WorkflowContext) -> str:
            return text.upper()
        
        executor = FunctionExecutor(id="upper", func=uppercase)
        context = WorkflowContext(workflow_id="wf", run_id="run")
        
        result = await executor.execute("hello", context)
        
        assert result == "HELLO"
    
    @pytest.mark.asyncio
    async def test_async_function(self):
        """Test executing an async function."""
        async def async_transform(text: str, ctx: WorkflowContext) -> str:
            return text[::-1]  # Reverse
        
        executor = FunctionExecutor(id="reverse", func=async_transform)
        context = WorkflowContext(workflow_id="wf", run_id="run")
        
        result = await executor.execute("hello", context)
        
        assert result == "olleh"
    
    @pytest.mark.asyncio
    async def test_function_with_context(self):
        """Test function that uses context."""
        def counter(text: str, ctx: WorkflowContext) -> str:
            count = ctx.get("count", 0)
            ctx.set("count", count + 1)
            return f"{text}-{count}"
        
        executor = FunctionExecutor(id="counter", func=counter)
        context = WorkflowContext(workflow_id="wf", run_id="run")
        
        result1 = await executor.execute("msg", context)
        result2 = await executor.execute("msg", context)
        
        assert result1 == "msg-0"
        assert result2 == "msg-1"
        assert context.get("count") == 2


class TestWorkflowContext:
    """Tests for WorkflowContext."""
    
    def test_shared_state(self):
        """Test getting and setting shared state."""
        context = WorkflowContext(workflow_id="wf", run_id="run")
        
        context.set("key", "value")
        
        assert context.get("key") == "value"
        assert context.get("missing", "default") == "default"
    
    def test_messages(self):
        """Test adding and getting messages."""
        context = WorkflowContext(workflow_id="wf", run_id="run")
        
        context.add_message("user", "Hello", agent_name="user1")
        context.add_message("assistant", "Hi there")
        
        messages = context.get_messages()
        
        assert len(messages) == 2
        assert messages[0]["role"] == "user"
        assert messages[0]["content"] == "Hello"


class TestWorkflow:
    """Tests for Workflow."""
    
    def test_create_workflow(self):
        """Test creating a workflow."""
        workflow = Workflow(id="wf-1", name="Test Workflow")
        
        assert workflow.id == "wf-1"
        assert workflow.name == "Test Workflow"
        assert len(workflow.executors) == 0
    
    def test_add_executor(self):
        """Test adding executors."""
        workflow = Workflow()
        
        executor = FunctionExecutor(
            id="test",
            func=lambda x, ctx: x
        )
        workflow.add_executor(executor)
        
        assert "test" in workflow.executors
    
    def test_add_edge(self):
        """Test adding edges."""
        workflow = Workflow()
        
        workflow.add_executor(FunctionExecutor("a", lambda x, ctx: x))
        workflow.add_executor(FunctionExecutor("b", lambda x, ctx: x))
        workflow.add_edge("a", "b")
        
        assert len(workflow.edges) == 1
    
    def test_set_start(self):
        """Test setting start executor."""
        workflow = Workflow()
        
        workflow.add_executor(FunctionExecutor("start", lambda x, ctx: x))
        workflow.set_start("start")
        
        assert workflow.start_executor_id == "start"
    
    @pytest.mark.asyncio
    async def test_run_simple_workflow(self):
        """Test running a simple workflow."""
        workflow = (
            Workflow(id="simple")
            .add_executor(FunctionExecutor("upper", lambda x, ctx: x.upper()))
            .add_executor(FunctionExecutor("reverse", lambda x, ctx: x[::-1]))
            .add_edge("upper", "reverse")
            .set_start("upper")
        )
        
        result = await workflow.run("hello")
        
        assert result.state == WorkflowState.COMPLETED
        assert result.output == "OLLEH"
    
    @pytest.mark.asyncio
    async def test_run_with_checkpoints(self):
        """Test workflow creates checkpoints."""
        workflow = (
            Workflow(id="checkpointed")
            .add_executor(FunctionExecutor("step1", lambda x, ctx: x + "1"))
            .add_executor(FunctionExecutor("step2", lambda x, ctx: x + "2"))
            .add_edge("step1", "step2")
            .set_start("step1")
        )
        
        result = await workflow.run("start")
        
        assert result.checkpoints_created == 2
        assert "step1" in result.executor_results
        assert "step2" in result.executor_results
    
    def test_visualize_mermaid(self):
        """Test generating Mermaid diagram."""
        workflow = (
            Workflow(id="viz")
            .add_executor(FunctionExecutor("a", lambda x, ctx: x))
            .add_executor(FunctionExecutor("b", lambda x, ctx: x))
            .add_edge("a", "b")
            .set_start("a")
        )
        
        mermaid = workflow.visualize("mermaid")
        
        assert "flowchart TD" in mermaid
        assert "a" in mermaid
        assert "b" in mermaid
        assert "-->" in mermaid


class TestWorkflowBuilder:
    """Tests for WorkflowBuilder."""
    
    def test_fluent_api(self):
        """Test fluent API for building workflows."""
        workflow = (
            WorkflowBuilder(workflow_id="builder-test")
            .add_function_executor("step1", lambda x, ctx: x + "1")
            .add_function_executor("step2", lambda x, ctx: x + "2")
            .add_edge("step1", "step2")
            .set_start("step1")
            .build()
        )
        
        assert workflow.id == "builder-test"
        assert len(workflow.executors) == 2
    
    def test_add_chain(self):
        """Test adding a chain of edges."""
        workflow = (
            WorkflowBuilder()
            .add_function_executor("a", lambda x, ctx: x)
            .add_function_executor("b", lambda x, ctx: x)
            .add_function_executor("c", lambda x, ctx: x)
            .add_chain("a", "b", "c")
            .set_start("a")
            .build()
        )
        
        assert len(workflow.edges) == 2
    
    def test_add_router_executor(self):
        """Test adding router executor."""
        workflow = (
            WorkflowBuilder()
            .add_function_executor("process_a", lambda x, ctx: "A: " + x)
            .add_function_executor("process_b", lambda x, ctx: "B: " + x)
            .add_router_executor(
                "router",
                lambda x: "process_a" if x.startswith("a") else "process_b"
            )
            .set_start("router")
            .build()
        )
        
        router = workflow.executors["router"]
        assert router.executor_type == ExecutorType.ROUTER


class TestSequentialWorkflowBuilder:
    """Tests for SequentialWorkflowBuilder."""
    
    @pytest.mark.asyncio
    async def test_auto_chaining(self):
        """Test automatic chaining in sequential builder."""
        workflow = (
            SequentialWorkflowBuilder("sequential")
            .add_function_executor("step1", lambda x, ctx: x + "-1")
            .add_function_executor("step2", lambda x, ctx: x + "-2")
            .add_function_executor("step3", lambda x, ctx: x + "-3")
            .build()
        )
        
        result = await workflow.run("start")
        
        assert result.output == "start-1-2-3"


class TestRouterExecutor:
    """Tests for RouterExecutor."""
    
    @pytest.mark.asyncio
    async def test_routing(self):
        """Test routing logic."""
        router = RouterExecutor(
            id="router",
            router_func=lambda x: "target_a" if x == "go_a" else "target_b"
        )
        context = WorkflowContext(workflow_id="wf", run_id="run")
        
        target_a, _ = await router.execute("go_a", context)
        target_b, _ = await router.execute("go_b", context)
        
        assert target_a == "target_a"
        assert target_b == "target_b"


class TestExecutorResult:
    """Tests for ExecutorResult."""
    
    def test_success_result(self):
        """Test successful executor result."""
        result = ExecutorResult(
            executor_id="exec-1",
            output="result data",
            success=True,
            duration_ms=100.5,
        )
        
        assert result.success is True
        assert result.error is None
        assert result.output == "result data"
    
    def test_error_result(self):
        """Test error executor result."""
        result = ExecutorResult(
            executor_id="exec-1",
            output=None,
            success=False,
            error="Something went wrong",
        )
        
        assert result.success is False
        assert result.error == "Something went wrong"
