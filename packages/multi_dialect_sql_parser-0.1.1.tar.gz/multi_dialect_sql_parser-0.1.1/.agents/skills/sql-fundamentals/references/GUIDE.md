# sql-fundamentals Guide
