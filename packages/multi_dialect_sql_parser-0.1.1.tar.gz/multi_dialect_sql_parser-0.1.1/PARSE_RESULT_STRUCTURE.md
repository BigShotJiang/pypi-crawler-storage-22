# SQL 解析结果结构说明

## 概述

所有数据库方言返回**统一的基础结构**，同时各方言有自己的**特有信息字段**。

## 通用字段（所有方言一致）

```python
class ParseResult:
    # 基础信息
    sql: str                    # 原始 SQL
    dialect: str                # 方言名称
    statement_type: str         # 语句类型 (SELECT/INSERT/UPDATE/DELETE/CREATE/...)
    success: bool               # 是否解析成功
    
    # 表信息
    tables: list[TableReference]
    # TableReference:
    #   - name: str             # 表名
    #   - schema_name: str      # Schema 名（如 public.users 中的 public）
    #   - alias: str            # 别名（如 users u 中的 u）
    #   - type: str             # 类型：table/view/subquery/cte
    
    # 列信息
    columns: list[ColumnReference]
    # ColumnReference:
    #   - name: str             # 列名
    #   - table: str            # 所属表（别名或表名）
    #   - alias: str            # 列别名
    #   - expression: str       # 表达式（如 COUNT(*)）
    
    # JOIN 信息
    joins: list[JoinInfo]
    # JoinInfo:
    #   - type: str             # JOIN 类型：INNER/LEFT/RIGHT/FULL/CROSS/NATURAL
    #   - table: TableReference # 关联的表
    #   - condition: str        # JOIN 条件（如 u.id = o.user_id）
    
    # WHERE 条件（嵌套树结构）
    conditions: list[ConditionNode]
    # ConditionNode:
    #   - type: str             # 类型：comparison/logical/in/exists/between/like/is_null
    #   - operator: str         # 操作符：=/!=/>/>=/</<=/AND/OR/IN/LIKE/...
    #   - column: str           # 列名（如 u.status）
    #   - value: str            # 值（如 'active'）
    #   - children: list        # 子条件（用于 AND/OR 逻辑组合）
    
    # 分组排序
    group_by: list[str]         # GROUP BY 列列表
    order_by: list[OrderByItem]
    # OrderByItem:
    #   - column: str           # 排序列
    #   - direction: str        # ASC/DESC
    
    # 分页
    limit: int | None           # LIMIT 值
    offset_value: int | None    # OFFSET 值
    
    # 错误/警告
    errors: list[ParseError]    # 错误列表
    warnings: list[ParseError]  # 警告列表
```

## 方言特有字段

### MySQL

```python
mysql_info: MySQLSpecificInfo
    preprocessed: bool                      # 是否经过预处理
    procedural_info: ProceduralInfo | None  # 存储过程/函数信息
```

### PostgreSQL

```python
postgresql_info: PostgreSQLSpecificInfo
    preprocessed: bool                      # 是否经过预处理
    procedural_info: ProceduralInfo | None  # PL/pgSQL 对象信息
```

### Oracle

```python
oracle_info: OracleSpecificInfo
    sequences: list[str]                    # 序列引用（NEXTVAL/CURRVAL）
    pseudo_columns: list[str]               # 伪列（ROWNUM/ROWID/LEVEL）
    hierarchy: dict | None                  # 层次查询信息（CONNECT BY）
    merge_info: dict | None                 # MERGE 语句信息
    procedural_info: ProceduralInfo | None  # PL/SQL 对象信息
```

### TiDB

```python
tidb_info: TiDBSpecificInfo
    hints: list[TiDBHint]                   # Hint 列表
    # TiDBHint:
    #   - name: str                         # Hint 名称（USE_INDEX/HASH_JOIN/...）
    #   - type: str                         # Hint 类型
    #   - args: str                         # Hint 参数
    auto_random_columns: list[str]          # AUTO_RANDOM 列
    preprocessed: bool                      # 是否经过预处理
    procedural_info: ProceduralInfo | None  # 存储过程信息
```

### OceanBase

```python
oceanbase_info: OceanBaseSpecificInfo
    mode: str                               # 模式：mysql/oracle
    hints: list[OceanBaseHint]              # Hint 列表
    # OceanBaseHint:
    #   - name: str                         # Hint 名称（PARALLEL/INDEX/...）
    #   - type: str                         # Hint 类型
    #   - args: str                         # Hint 参数
    preprocessed: bool                      # 是否经过预处理
    procedural_info: ProceduralInfo | None  # 存储过程信息

# 注意：OceanBase-Oracle 模式同时返回 oracle_info 和 oceanbase_info
```

## 过程化对象信息（通用）

```python
class ProceduralInfo:
    type: str                   # FUNCTION/PROCEDURE/PACKAGE/TRIGGER/ANONYMOUS_BLOCK
    name: str | None            # 对象名
    schema_name: str | None     # Schema 名
    parameters: list[ParameterInfo]  # 参数列表
    # ParameterInfo:
    #   - name: str             # 参数名
    #   - mode: str             # IN/OUT/INOUT
    #   - datatype: str         # 数据类型
    #   - default_value: str    # 默认值
    
    return_type: str | None     # 返回类型（函数）
    deterministic: bool         # 是否确定性（MySQL）
    
    # 触发器特有
    timing: str | None          # BEFORE/AFTER/INSTEAD OF
    events: list[str]           # [INSERT, UPDATE, DELETE]
    table_name: str | None      # 触发表
    
    # PostgreSQL 特有
    language: str | None        # plpgsql/sql/python
    
    # 通用
    body: str | None            # 原始代码体
    is_replace: bool            # OR REPLACE
    definer: str | None         # DEFINER（MySQL）
```

## 示例输出

### 输入 SQL
```sql
SELECT u.id, u.name, o.amount
FROM users u
LEFT JOIN orders o ON u.id = o.user_id
WHERE u.status = 'active' AND o.amount > 100
GROUP BY u.department
ORDER BY o.amount DESC
LIMIT 10 OFFSET 5
```

### 解析结果（所有方言一致的部分）

```json
{
  "success": true,
  "statement_type": "SELECT",
  "tables": [
    {"name": "users", "schema_name": "", "alias": "u", "type": "table"},
    {"name": "orders", "schema_name": "", "alias": "o", "type": "table"}
  ],
  "columns": [
    {"name": "id", "table": "u"},
    {"name": "name", "table": "u"},
    {"name": "amount", "table": "o"}
  ],
  "joins": [
    {
      "type": "LEFT",
      "table": {"name": "orders", "alias": "o"},
      "condition": "u.id = o.user_id"
    }
  ],
  "conditions": [
    {
      "type": "logical",
      "operator": "AND",
      "children": [
        {"type": "comparison", "operator": "=", "column": "u.status", "value": "'active'"},
        {"type": "comparison", "operator": ">", "column": "o.amount", "value": "100"}
      ]
    }
  ],
  "group_by": ["u.department"],
  "order_by": [{"column": "o.amount", "direction": "DESC"}],
  "limit": 10,
  "offset_value": 5
}
```

## 一致性总结

| 字段 | MySQL | PostgreSQL | Oracle | TiDB | OceanBase |
|------|-------|------------|--------|------|-----------|
| tables | ✅ 一致 | ✅ 一致 | ✅ 一致 | ✅ 一致 | ✅ 一致 |
| columns | ✅ 一致 | ✅ 一致 | ✅ 一致 | ✅ 一致 | ✅ 一致 |
| joins | ✅ 一致 | ✅ 一致 | ✅ 一致 | ✅ 一致 | ✅ 一致 |
| conditions | ✅ 一致 | ✅ 一致 | ✅ 一致 | ✅ 一致 | ✅ 一致 |
| group_by | ✅ 一致 | ✅ 一致 | ✅ 一致 | ✅ 一致 | ✅ 一致 |
| order_by | ✅ 一致 | ✅ 一致 | ✅ 一致 | ✅ 一致 | ✅ 一致 |
| limit/offset | ✅ 一致 | ✅ 一致 | ✅ 一致 | ✅ 一致 | ✅ 一致 |
| 特有信息 | mysql_info | postgresql_info | oracle_info | tidb_info | oceanbase_info |
