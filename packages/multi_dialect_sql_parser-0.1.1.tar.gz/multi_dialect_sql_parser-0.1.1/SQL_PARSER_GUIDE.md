# SQL Parser 使用指南

## 概述

SQL Parser 是一个多方言 SQL 解析器，基于 SQLGlot 构建，支持 MySQL、PostgreSQL、Oracle、TiDB、OceanBase 等主流数据库方言。

## 支持场景

### 支持的数据库方言

| 方言 | 标识符 | 说明 |
|------|--------|------|
| MySQL | `mysql` | MySQL 5.7+ |
| PostgreSQL | `postgresql` | PostgreSQL 10+ |
| Oracle | `oracle` | Oracle 11g+ |
| TiDB | `tidb` | TiDB 4.0+，兼容 MySQL 语法 |
| OceanBase MySQL | `oceanbase-mysql` | OceanBase MySQL 模式 |
| OceanBase Oracle | `oceanbase-oracle` | OceanBase Oracle 模式 |

### 支持的 SQL 语句类型

- **DQL**: SELECT（含子查询、CTE、UNION/INTERSECT/EXCEPT）
- **DML**: INSERT、UPDATE、DELETE、MERGE
- **DDL**: CREATE、ALTER、DROP、TRUNCATE
- **过程化对象**: FUNCTION、PROCEDURE、TRIGGER、PACKAGE（Oracle）

### 特有语法支持

| 方言 | 特有语法 |
|------|----------|
| Oracle | 层次查询（CONNECT BY）、序列（NEXTVAL/CURRVAL）、伪列（ROWNUM/ROWID）、MERGE |
| TiDB | AUTO_RANDOM、Hint（USE_INDEX/HASH_JOIN 等） |
| OceanBase | Hint（PARALLEL/INDEX 等）、双模式（MySQL/Oracle） |

---

## 接入方式

### 安装

```bash
# 从源码安装（开发模式）
pip install -e .

# 安装开发依赖
pip install -e ".[dev]"
```

### 依赖要求

- Python >= 3.11
- sqlglot[rs] >= 26.0.0
- pydantic >= 2.0.0

### 基础使用

```python
from sql_parser import SQLParser

# 创建解析器（指定方言）
parser = SQLParser(dialect="mysql")

# 解析单条 SQL
result = parser.parse("SELECT * FROM users WHERE id = 1")

# 检查解析结果
if result.success:
    print(f"语句类型: {result.statement_type}")
    print(f"涉及表: {[t.name for t in result.tables]}")
    print(f"涉及列: {[c.name for c in result.columns]}")
else:
    print(f"解析失败: {result.errors}")
```

### 批量解析

```python
from sql_parser import SQLParser

parser = SQLParser(dialect="mysql", max_workers=4, batch_size=1000)

sqls = [
    "SELECT * FROM users",
    "INSERT INTO orders (user_id, amount) VALUES (1, 100)",
    "UPDATE products SET price = 99.9 WHERE id = 1",
]

# 方式一：流式返回（推荐，内存友好）
for result in parser.parse_batch(sqls):
    print(f"{result.statement_type}: {result.success}")

# 方式二：返回汇总结果
batch_result = parser.parse_batch_all(sqls)
print(f"总数: {batch_result.total_statements}")
print(f"成功: {batch_result.successful}")
print(f"失败: {batch_result.failed}")
```

### 多方言示例

```python
from sql_parser import SQLParser

# Oracle 特有语法
oracle_parser = SQLParser(dialect="oracle")
result = oracle_parser.parse("""
    SELECT * FROM employees
    START WITH manager_id IS NULL
    CONNECT BY PRIOR employee_id = manager_id
""")
print(result.oracle_info.hierarchy)  # 层次查询信息

# TiDB 特有语法
tidb_parser = SQLParser(dialect="tidb")
result = tidb_parser.parse("""
    SELECT /*+ USE_INDEX(t, idx_name) */ * FROM t
""")
print(result.tidb_info.hints)  # Hint 信息

# OceanBase Oracle 模式
ob_parser = SQLParser(dialect="oceanbase-oracle")
result = ob_parser.parse("SELECT /*+ PARALLEL(4) */ * FROM t")
print(result.oceanbase_info.hints)  # Hint 信息
print(result.oceanbase_info.mode)   # "oracle"
```

---

## 打包方式

### 构建 Wheel 包

```bash
# 安装构建工具
pip install build

# 构建
python -m build

# 产物位于 dist/ 目录
# - multi_dialect_sql_parser-0.1.0-py3-none-any.whl
# - multi_dialect_sql_parser-0.1.0.tar.gz
```

### 安装 Wheel 包

```bash
pip install dist/multi_dialect_sql_parser-0.1.0-py3-none-any.whl
```

### 发布到 PyPI

```bash
# 安装 twine
pip install twine

# 上传到 TestPyPI（测试）
twine upload --repository testpypi dist/*

# 上传到正式 PyPI
twine upload dist/*

# 使用 API Token 上传（推荐）
twine upload dist/* -u __token__ -p pypi-your-api-token
```

### 从 PyPI 安装

```bash
pip install multi-dialect-sql-parser
```

---

## 返回格式

### ParseResult 结构

所有方言返回统一的 `ParseResult` 结构：

```python
class ParseResult:
    # 基础信息
    sql: str                    # 原始 SQL
    dialect: str                # 方言名称
    statement_type: str         # 语句类型 (SELECT/INSERT/UPDATE/DELETE/CREATE/...)
    success: bool               # 是否解析成功
    
    # 表信息
    tables: list[TableReference]
    #   - name: str             # 表名
    #   - schema_name: str      # Schema 名
    #   - alias: str            # 别名
    #   - type: str             # table/view/subquery/cte
    
    # 列信息
    columns: list[ColumnReference]
    #   - name: str             # 列名
    #   - table: str            # 所属表
    #   - alias: str            # 列别名
    #   - expression: str       # 表达式
    
    # JOIN 信息
    joins: list[JoinInfo]
    #   - type: str             # INNER/LEFT/RIGHT/FULL/CROSS/NATURAL
    #   - table: TableReference # 关联的表
    #   - condition: str        # JOIN 条件
    
    # WHERE 条件（树结构）
    conditions: list[ConditionNode]
    #   - type: str             # comparison/logical/in/exists/between/like/is_null
    #   - operator: str         # =/!=/>/AND/OR/IN/LIKE/...
    #   - column: str           # 列名
    #   - value: str            # 值
    #   - children: list        # 子条件
    
    # 分组排序
    group_by: list[str]         # GROUP BY 列
    order_by: list[OrderByItem] # ORDER BY 列
    #   - column: str           # 排序列
    #   - direction: str        # ASC/DESC
    
    # 分页
    limit: int | None           # LIMIT 值
    offset_value: int | None    # OFFSET 值
    
    # 错误/警告
    errors: list[ParseError]    # 错误列表
    warnings: list[ParseError]  # 警告列表
    
    # 方言特有信息
    mysql_info: MySQLSpecificInfo | None
    postgresql_info: PostgreSQLSpecificInfo | None
    oracle_info: OracleSpecificInfo | None
    tidb_info: TiDBSpecificInfo | None
    oceanbase_info: OceanBaseSpecificInfo | None
```

### JSON 输出示例

```python
result = parser.parse("""
    SELECT u.id, u.name, o.amount
    FROM users u
    LEFT JOIN orders o ON u.id = o.user_id
    WHERE u.status = 'active' AND o.amount > 100
    ORDER BY o.amount DESC
    LIMIT 10
""")

# 转为 JSON
print(result.model_dump_json(indent=2))
```

输出：

```json
{
  "sql": "SELECT u.id, u.name, o.amount FROM users u LEFT JOIN orders o ON u.id = o.user_id WHERE u.status = 'active' AND o.amount > 100 ORDER BY o.amount DESC LIMIT 10",
  "dialect": "mysql",
  "statement_type": "SELECT",
  "success": true,
  "tables": [
    {"name": "users", "schema_name": null, "alias": "u", "type": "table"},
    {"name": "orders", "schema_name": null, "alias": "o", "type": "table"}
  ],
  "columns": [
    {"name": "id", "table": "u", "alias": null, "expression": null},
    {"name": "name", "table": "u", "alias": null, "expression": null},
    {"name": "amount", "table": "o", "alias": null, "expression": null}
  ],
  "joins": [
    {
      "type": "LEFT",
      "table": {"name": "orders", "schema_name": null, "alias": "o", "type": "table"},
      "condition": "u.id = o.user_id"
    }
  ],
  "conditions": [
    {
      "type": "logical",
      "operator": "AND",
      "column": null,
      "value": null,
      "children": [
        {"type": "comparison", "operator": "=", "column": "u.status", "value": "'active'", "children": null},
        {"type": "comparison", "operator": ">", "column": "o.amount", "value": "100", "children": null}
      ]
    }
  ],
  "group_by": [],
  "order_by": [{"column": "o.amount", "direction": "DESC"}],
  "limit": 10,
  "offset_value": null,
  "errors": [],
  "warnings": []
}
```

### 错误信息格式

```python
class ParseError:
    error_type: str     # syntax_error/semantic_warning/unsupported_syntax/...
    message: str        # 错误消息
    line: int | None    # 行号（从 1 开始）
    column: int | None  # 列号（从 1 开始）
    offset: int | None  # 字符偏移量
    context: str | None # 错误上下文
    marked_sql: str | None  # 带错误标记的 SQL
```

---

## 性能配置

### 批量解析参数

| 参数 | 默认值 | 说明 |
|------|--------|------|
| `max_workers` | CPU 核心数（上限 8） | 最大进程数 |
| `batch_size` | 1000 | 每批处理的 SQL 数量 |

### 性能建议

1. **大批量解析**：使用 `parse_batch()` 流式返回，避免内存累积
2. **小批量解析**（< 1000 条）：直接使用 `parse()` 循环即可
3. **内存敏感场景**：降低 `batch_size`，如 500

```python
# 大批量、内存敏感场景
parser = SQLParser(dialect="mysql", max_workers=4, batch_size=500)

for result in parser.parse_batch(large_sql_list):
    process(result)  # 逐条处理，不累积
```

---

## 常见问题

### Q: 解析失败怎么办？

检查 `result.errors` 获取详细错误信息：

```python
if not result.success:
    for error in result.errors:
        print(f"[{error.error_type}] {error.message}")
        if error.line:
            print(f"  位置: 第 {error.line} 行，第 {error.column} 列")
```

### Q: 如何获取方言特有信息？

根据方言访问对应的 `*_info` 字段：

```python
# Oracle
if result.oracle_info:
    print(result.oracle_info.hierarchy)      # 层次查询
    print(result.oracle_info.sequences)      # 序列
    print(result.oracle_info.pseudo_columns) # 伪列

# TiDB
if result.tidb_info:
    print(result.tidb_info.hints)            # Hint 列表
    print(result.tidb_info.auto_random_columns)

# OceanBase
if result.oceanbase_info:
    print(result.oceanbase_info.mode)        # mysql/oracle
    print(result.oceanbase_info.hints)       # Hint 列表
```

### Q: 支持存储过程/函数解析吗？

支持。过程化对象信息在 `*_info.procedural_info` 中：

```python
result = parser.parse("""
    CREATE FUNCTION get_user_name(p_id INT) RETURNS VARCHAR(100)
    BEGIN
        RETURN (SELECT name FROM users WHERE id = p_id);
    END
""")

if result.mysql_info and result.mysql_info.procedural_info:
    proc = result.mysql_info.procedural_info
    print(f"类型: {proc.type}")        # FUNCTION
    print(f"名称: {proc.name}")        # get_user_name
    print(f"参数: {proc.parameters}")  # [ParameterInfo(...)]
    print(f"返回类型: {proc.return_type}")  # VARCHAR(100)
```

---

## API 参考

### SQLParser

```python
class SQLParser:
    def __init__(
        self,
        dialect: str = "mysql",      # 数据库方言
        max_workers: int | None = None,  # 最大进程数
        batch_size: int = 1000,      # 批量大小
    ): ...
    
    def parse(self, sql: str) -> ParseResult:
        """解析单条 SQL"""
        ...
    
    def parse_batch(self, sqls: list[str]) -> Iterator[ParseResult]:
        """批量解析，流式返回"""
        ...
    
    def parse_batch_all(self, sqls: list[str]) -> BatchParseResult:
        """批量解析，返回汇总结果"""
        ...
```

### 导出的类型

```python
from sql_parser import (
    SQLParser,           # 解析器
    ParseResult,         # 解析结果
    BatchParseResult,    # 批量解析结果
    TableReference,      # 表引用
    ColumnReference,     # 列引用
    ConditionNode,       # 条件节点
    JoinInfo,            # JOIN 信息
    OrderByItem,         # ORDER BY 项
    ParseError,          # 错误信息
    OracleSpecificInfo,  # Oracle 特有信息
    TiDBSpecificInfo,    # TiDB 特有信息
    TiDBHint,            # TiDB Hint
    OceanBaseSpecificInfo,  # OceanBase 特有信息
    OceanBaseHint,       # OceanBase Hint
    SUPPORTED_DIALECTS,  # 支持的方言集合
)
```
