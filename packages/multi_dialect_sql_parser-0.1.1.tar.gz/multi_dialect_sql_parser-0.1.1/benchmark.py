# -*- coding: utf-8 -*-
"""SQL Parser 压力测试脚本。

测试内容：
1. 单条 SQL 解析性能
2. 批量解析性能（不同规模）
3. 内存使用情况
4. 不同方言的性能对比
"""
from __future__ import annotations

import gc
import sys
import time
import tracemalloc
from typing import List, Dict, Any

from sql_parser import SQLParser


# ==================== 测试 SQL 样本 ====================

SIMPLE_SQLS = [
    "SELECT * FROM users",
    "SELECT id, name FROM users WHERE id = 1",
    "INSERT INTO users (name, email) VALUES ('test', 'test@example.com')",
    "UPDATE users SET name = 'new' WHERE id = 1",
    "DELETE FROM users WHERE id = 1",
]

COMPLEX_SQLS = [
    """
    SELECT u.id, u.name, o.amount, p.name as product_name
    FROM users u
    LEFT JOIN orders o ON u.id = o.user_id
    LEFT JOIN products p ON o.product_id = p.id
    WHERE u.status = 'active' AND o.amount > 100
    GROUP BY u.department
    ORDER BY o.amount DESC
    LIMIT 10 OFFSET 5
    """,
    """
    SELECT 
        department,
        COUNT(*) as emp_count,
        AVG(salary) as avg_salary,
        MAX(salary) as max_salary
    FROM employees
    WHERE hire_date > '2020-01-01'
    GROUP BY department
    HAVING COUNT(*) > 5
    ORDER BY avg_salary DESC
    """,
    """
    WITH ranked_sales AS (
        SELECT 
            product_id,
            SUM(quantity) as total_qty,
            ROW_NUMBER() OVER (ORDER BY SUM(quantity) DESC) as rank
        FROM sales
        GROUP BY product_id
    )
    SELECT p.name, rs.total_qty, rs.rank
    FROM ranked_sales rs
    JOIN products p ON rs.product_id = p.id
    WHERE rs.rank <= 10
    """,
]


def generate_sqls(count: int, complexity: str = "mixed") -> List[str]:
    """生成测试 SQL 列表。
    
    Args:
        count: SQL 数量
        complexity: simple/complex/mixed
    
    Returns:
        SQL 列表
    """
    if complexity == "simple":
        base = SIMPLE_SQLS
    elif complexity == "complex":
        base = COMPLEX_SQLS
    else:
        base = SIMPLE_SQLS + COMPLEX_SQLS
    
    sqls = []
    for i in range(count):
        sqls.append(base[i % len(base)])
    return sqls


# ==================== 性能测试 ====================

def benchmark_single_parse(parser: SQLParser, sql: str, iterations: int = 1000) -> Dict[str, Any]:
    """测试单条 SQL 解析性能。
    
    Args:
        parser: 解析器实例
        sql: SQL 语句
        iterations: 迭代次数
    
    Returns:
        性能指标
    """
    # 预热
    for _ in range(10):
        parser.parse(sql)
    
    # 正式测试
    start = time.perf_counter()
    for _ in range(iterations):
        parser.parse(sql)
    elapsed = time.perf_counter() - start
    
    return {
        "iterations": iterations,
        "total_time": elapsed,
        "avg_time_ms": (elapsed / iterations) * 1000,
        "ops_per_sec": iterations / elapsed,
    }


def benchmark_batch_parse(parser: SQLParser, sqls: List[str]) -> Dict[str, Any]:
    """测试批量解析性能。
    
    Args:
        parser: 解析器实例
        sqls: SQL 列表
    
    Returns:
        性能指标
    """
    gc.collect()
    
    start = time.perf_counter()
    results = list(parser.parse_batch(sqls))
    elapsed = time.perf_counter() - start
    
    success_count = sum(1 for r in results if r.success)
    
    return {
        "total_sqls": len(sqls),
        "success_count": success_count,
        "total_time": elapsed,
        "avg_time_ms": (elapsed / len(sqls)) * 1000,
        "ops_per_sec": len(sqls) / elapsed,
    }


def benchmark_memory(parser: SQLParser, sqls: List[str]) -> Dict[str, Any]:
    """测试内存使用情况。
    
    Args:
        parser: 解析器实例
        sqls: SQL 列表
    
    Returns:
        内存指标
    """
    gc.collect()
    tracemalloc.start()
    
    snapshot_before = tracemalloc.take_snapshot()
    
    # 执行解析
    results = list(parser.parse_batch(sqls))
    
    snapshot_after = tracemalloc.take_snapshot()
    
    # 计算内存差异
    top_stats = snapshot_after.compare_to(snapshot_before, 'lineno')
    
    current, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    
    # 清理
    del results
    gc.collect()
    
    return {
        "current_mb": current / 1024 / 1024,
        "peak_mb": peak / 1024 / 1024,
        "per_sql_kb": (peak / len(sqls)) / 1024,
        "top_allocations": [(str(stat.traceback), stat.size_diff) for stat in top_stats[:5]],
    }


def benchmark_dialects(sql_count: int = 1000) -> Dict[str, Dict[str, Any]]:
    """测试不同方言的性能。
    
    Args:
        sql_count: 每个方言测试的 SQL 数量
    
    Returns:
        各方言性能指标
    """
    dialects = ["mysql", "postgresql", "oracle", "tidb", "oceanbase-mysql"]
    sqls = generate_sqls(sql_count, "mixed")
    
    results = {}
    for dialect in dialects:
        parser = SQLParser(dialect=dialect)
        
        start = time.perf_counter()
        parsed = list(parser.parse_batch(sqls))
        elapsed = time.perf_counter() - start
        
        success_count = sum(1 for r in parsed if r.success)
        
        results[dialect] = {
            "total_time": elapsed,
            "ops_per_sec": sql_count / elapsed,
            "success_rate": success_count / sql_count * 100,
        }
        
        del parsed
        gc.collect()
    
    return results


# ==================== 主测试流程 ====================

def run_benchmark():
    """运行完整的压力测试。"""
    print("=" * 60)
    print("SQL Parser 压力测试")
    print("=" * 60)
    
    parser = SQLParser(dialect="mysql")
    
    # 1. 单条 SQL 解析性能
    print("\n【1. 单条 SQL 解析性能】")
    print("-" * 40)
    
    for name, sql in [("简单查询", SIMPLE_SQLS[0]), ("复杂查询", COMPLEX_SQLS[0])]:
        result = benchmark_single_parse(parser, sql, iterations=1000)
        print(f"\n{name}:")
        print(f"  迭代次数: {result['iterations']}")
        print(f"  总耗时: {result['total_time']:.3f}s")
        print(f"  平均耗时: {result['avg_time_ms']:.3f}ms")
        print(f"  吞吐量: {result['ops_per_sec']:.0f} ops/s")
    
    # 2. 批量解析性能（不同规模）
    print("\n【2. 批量解析性能】")
    print("-" * 40)
    
    for count in [100, 1000, 5000, 10000]:
        sqls = generate_sqls(count, "mixed")
        result = benchmark_batch_parse(parser, sqls)
        print(f"\n{count} 条 SQL:")
        print(f"  成功率: {result['success_count']}/{result['total_sqls']}")
        print(f"  总耗时: {result['total_time']:.3f}s")
        print(f"  平均耗时: {result['avg_time_ms']:.3f}ms")
        print(f"  吞吐量: {result['ops_per_sec']:.0f} ops/s")
    
    # 3. 内存使用情况
    print("\n【3. 内存使用情况】")
    print("-" * 40)
    
    for count in [1000, 5000, 10000]:
        sqls = generate_sqls(count, "mixed")
        result = benchmark_memory(parser, sqls)
        print(f"\n{count} 条 SQL:")
        print(f"  当前内存: {result['current_mb']:.2f} MB")
        print(f"  峰值内存: {result['peak_mb']:.2f} MB")
        print(f"  每条 SQL: {result['per_sql_kb']:.2f} KB")
    
    # 4. 不同方言性能对比
    print("\n【4. 不同方言性能对比】")
    print("-" * 40)
    
    dialect_results = benchmark_dialects(1000)
    print(f"\n{'方言':<20} {'耗时(s)':<12} {'吞吐量(ops/s)':<15} {'成功率':<10}")
    print("-" * 60)
    for dialect, result in dialect_results.items():
        print(f"{dialect:<20} {result['total_time']:<12.3f} {result['ops_per_sec']:<15.0f} {result['success_rate']:.1f}%")
    
    # 5. 流式解析 vs 全量解析
    print("\n【5. 流式解析 vs 全量解析】")
    print("-" * 40)
    
    sqls = generate_sqls(5000, "mixed")
    
    # 流式解析
    gc.collect()
    tracemalloc.start()
    start = time.perf_counter()
    count = 0
    for result in parser.parse_batch(sqls):
        count += 1
    stream_time = time.perf_counter() - start
    _, stream_peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    
    # 全量解析
    gc.collect()
    tracemalloc.start()
    start = time.perf_counter()
    all_results = parser.parse_batch_all(sqls)
    all_time = time.perf_counter() - start
    _, all_peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    
    print(f"\n流式解析 (parse_batch):")
    print(f"  耗时: {stream_time:.3f}s")
    print(f"  峰值内存: {stream_peak / 1024 / 1024:.2f} MB")
    
    print(f"\n全量解析 (parse_batch_all):")
    print(f"  耗时: {all_time:.3f}s")
    print(f"  峰值内存: {all_peak / 1024 / 1024:.2f} MB")
    
    print("\n" + "=" * 60)
    print("测试完成")
    print("=" * 60)


if __name__ == "__main__":
    run_benchmark()
