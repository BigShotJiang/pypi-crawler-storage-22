## Context
构建 SQL 解析器核心框架，优先支持 SQLGlot 原生支持的 MySQL 和 PostgreSQL 方言。这是整个解析器系统的基础，后续方言扩展都依赖此核心。

**技术栈**：Python + SQLGlot[rs]
**性能目标**：简单查询 <1ms，批量 >1000 条/秒

## 设计原则

### 性能优先（设计内置）

| 原则 | 实现方式 |
|------|----------|
| O(1) 查找 | dict/set 代替 list |
| 列表推导式 | 代替显式 for 循环 |
| 局部变量缓存 | 减少属性查找开销 |
| lru_cache | 缓存方言解析器 |
| 流式处理 | 生成器 yield |
| Rust 加速 | sqlglot[rs] |

## Decisions

### 解析库选型

**决策**：使用 SQLGlot，无需自己实现解析器

| 特性 | SQLGlot |
|------|---------|
| 方言支持 | 31+ 种（含 MySQL、PostgreSQL、Oracle） |
| 性能 | Rust tokenizer 提升 30-40% |
| 可扩展 | 支持自定义方言 |

### 数据模型

```python
from __future__ import annotations
from pydantic import BaseModel
from typing import Literal

# 常量查找表（O(1)）
SUPPORTED_DIALECTS = {"mysql", "postgresql", "oracle", "tidb", "oceanbase-mysql", "oceanbase-oracle"}

DIALECT_MAP = {
    "mysql": "mysql",
    "postgresql": "postgres",
    "oracle": "oracle",
    "tidb": "mysql",
    "oceanbase-mysql": "mysql",
    "oceanbase-oracle": "oracle",
}

class TableReference(BaseModel):
    name: str
    schema_name: str | None = None
    alias: str | None = None
    type: Literal['table', 'view', 'subquery'] = 'table'

class ColumnReference(BaseModel):
    name: str
    table: str | None = None
    alias: str | None = None
    expression: str | None = None

class ParseError(BaseModel):
    error_type: Literal['syntax_error', 'semantic_warning', 'unsupported_syntax']
    message: str
    line: int | None = None
    column: int | None = None
    offset: int | None = None
    context: str | None = None
    marked_sql: str | None = None

class ParseResult(BaseModel):
    dialect: str
    statement_type: str
    tables: list[TableReference] = []
    columns: list[ColumnReference] = []
    conditions: list[dict] = []
    joins: list[dict] = []
    group_by: list[str] = []
    order_by: list[dict] = []
    errors: list[ParseError] = []
```

### 核心解析器实现

```python
from __future__ import annotations
import os
from concurrent.futures import ProcessPoolExecutor, as_completed
from functools import lru_cache
from typing import Iterator
import sqlglot
from sqlglot import exp

MAX_WORKERS = min(os.cpu_count() or 4, 8)
BATCH_SIZE = 1000
MAX_TASKS_PER_CHILD = 100


@lru_cache(maxsize=16)
def get_dialect(dialect: str):
    """缓存方言解析器"""
    return sqlglot.Dialect.get_or_raise(DIALECT_MAP.get(dialect, dialect))


def parse_single(sql: str, dialect: str) -> dict:
    """单条解析（性能优化版）"""
    # 局部变量缓存
    parse_one = sqlglot.parse_one
    Table = exp.Table
    Column = exp.Column
    
    try:
        ast = parse_one(sql, dialect=DIALECT_MAP.get(dialect, dialect))
        
        # 列表推导式提取
        tables = [
            {"name": t.name, "alias": t.alias, "schema": t.db}
            for t in ast.find_all(Table)
        ]
        columns = [
            {"name": c.name, "table": c.table}
            for c in ast.find_all(Column)
        ]
        
        return {
            "success": True,
            "dialect": dialect,
            "statement_type": type(ast).__name__,
            "tables": tables,
            "columns": columns,
        }
    except Exception as e:
        return {
            "success": False,
            "dialect": dialect,
            "error": str(e),
        }


class SQLParser:
    """SQL 解析器"""
    
    def __init__(self, dialect: str = "mysql", max_workers: int | None = None):
        if dialect not in SUPPORTED_DIALECTS:
            raise ValueError(f"Unsupported dialect: {dialect}")
        self.dialect = dialect
        self.max_workers = max_workers or MAX_WORKERS
    
    def parse(self, sql: str) -> ParseResult:
        """解析单条 SQL"""
        result = parse_single(sql, self.dialect)
        return ParseResult(**result)
    
    def parse_batch(self, sqls: list[str]) -> Iterator[ParseResult]:
        """批量解析（流式返回）"""
        batches = [sqls[i:i+BATCH_SIZE] for i in range(0, len(sqls), BATCH_SIZE)]
        
        with ProcessPoolExecutor(
            max_workers=self.max_workers,
            max_tasks_per_child=MAX_TASKS_PER_CHILD,
        ) as executor:
            futures = {
                executor.submit(self._parse_chunk, batch): i
                for i, batch in enumerate(batches)
            }
            
            for future in as_completed(futures):
                for result in future.result():
                    yield ParseResult(**result)
    
    def _parse_chunk(self, sqls: list[str]) -> list[dict]:
        return [parse_single(sql, self.dialect) for sql in sqls]
```

### MySQL 特有语法处理

| 语法 | SQLGlot 支持 | 处理方式 |
|------|-------------|----------|
| 反引号标识符 | ✅ 原生支持 | 自动处理 |
| LIMIT | ✅ 原生支持 | 自动处理 |
| AUTO_INCREMENT | ✅ 原生支持 | 提取为列属性 |
| IFNULL/GROUP_CONCAT | ✅ 原生支持 | 识别为函数 |

### PostgreSQL 特有语法处理

| 语法 | SQLGlot 支持 | 处理方式 |
|------|-------------|----------|
| 双引号标识符 | ✅ 原生支持 | 自动处理 |
| :: 类型转换 | ✅ 原生支持 | 识别为 Cast |
| SERIAL | ✅ 原生支持 | 识别为类型 |
| 数组操作 | ✅ 原生支持 | 识别为表达式 |

## 性能目标

| 指标 | 目标值 |
|------|--------|
| 简单查询解析 | < 1ms |
| 复杂查询解析 | < 10ms |
| 批量吞吐量（4核） | > 1000 条/秒 |
| 峰值内存（10000条） | < 500MB |

## Risks / Trade-offs

| 风险 | 缓解措施 |
|------|----------|
| SQLGlot 版本更新 | 锁定版本，定期评估 |
| 进程间通信开销 | 批量提交，每批 1000 条 |
| 内存泄漏 | max_tasks_per_child 回收进程 |
