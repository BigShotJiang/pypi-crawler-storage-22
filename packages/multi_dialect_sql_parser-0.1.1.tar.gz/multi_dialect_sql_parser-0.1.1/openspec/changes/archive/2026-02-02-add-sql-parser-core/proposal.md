# Change: SQL 解析器核心框架 + MySQL/PostgreSQL 支持

## Why
构建 SQL 解析器的核心框架，优先支持 SQLGlot 原生支持的 MySQL 和 PostgreSQL 方言。这是整个解析器系统的基础。

## What Changes
- 新增核心解析器框架（SQLParser 类）
- 支持 MySQL 方言解析
- 支持 PostgreSQL 方言解析
- 实现多进程批量解析
- 实现性能优化策略（设计内置）

## Impact
- Affected specs: sql-parser-core (新建)
- Affected code: 新建 sql_parser/ 模块
- 后续提案依赖此核心框架
