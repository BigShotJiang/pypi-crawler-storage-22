## ADDED Requirements

### Requirement: 核心解析器框架
系统 SHALL 提供统一的 SQL 解析器接口。

#### Scenario: 解析器初始化
- **WHEN** 创建 SQLParser 实例并指定方言
- **THEN** 返回配置好的解析器实例

#### Scenario: 单条 SQL 解析
- **WHEN** 调用 parse_single(sql) 方法
- **THEN** 返回 ParseResult 对象，包含表名、列名、条件等信息

#### Scenario: 批量 SQL 解析
- **WHEN** 调用 parse_batch(sqls) 方法
- **THEN** 流式返回每条 SQL 的解析结果

---

### Requirement: MySQL 方言支持
系统 SHALL 支持 MySQL 语法解析。

#### Scenario: MySQL 标识符解析
- **WHEN** SQL 包含反引号标识符（如 \`table_name\`）
- **THEN** 正确识别并提取表名

#### Scenario: MySQL LIMIT 解析
- **WHEN** SQL 包含 LIMIT 子句
- **THEN** 正确提取 LIMIT 值

#### Scenario: MySQL 特有函数
- **WHEN** SQL 包含 MySQL 特有函数（如 IFNULL、GROUP_CONCAT）
- **THEN** 正确识别函数类型和参数

#### Scenario: MySQL AUTO_INCREMENT
- **WHEN** DDL 包含 AUTO_INCREMENT
- **THEN** 正确识别自增列属性

---

### Requirement: PostgreSQL 方言支持
系统 SHALL 支持 PostgreSQL 语法解析。

#### Scenario: PostgreSQL 标识符解析
- **WHEN** SQL 包含双引号标识符（如 "table_name"）
- **THEN** 正确识别并提取表名

#### Scenario: PostgreSQL 类型转换
- **WHEN** SQL 包含 :: 类型转换（如 value::integer）
- **THEN** 正确识别类型转换表达式

#### Scenario: PostgreSQL SERIAL 类型
- **WHEN** DDL 包含 SERIAL/BIGSERIAL 类型
- **THEN** 正确识别自增列类型

#### Scenario: PostgreSQL 数组操作
- **WHEN** SQL 包含数组操作（如 ANY、ALL、@>）
- **THEN** 正确识别数组表达式

---

### Requirement: 多进程批量解析
系统 SHALL 支持高性能多进程批量解析。

#### Scenario: 进程池配置
- **WHEN** 初始化解析器
- **THEN** 进程数基于 CPU 核心数，上限 8

#### Scenario: 分批处理
- **WHEN** 批量解析超过 1000 条 SQL
- **THEN** 自动分批处理，每批 1000 条

#### Scenario: 流式返回
- **WHEN** 批量解析进行中
- **THEN** 使用生成器流式返回结果，不累积内存

#### Scenario: 进程回收
- **WHEN** 子进程处理 100 批任务后
- **THEN** 自动重启进程释放内存

---

### Requirement: 性能要求
系统 SHALL 满足以下性能指标。

#### Scenario: 简单查询性能
- **WHEN** 解析简单 SELECT 语句
- **THEN** 解析时间 < 1ms

#### Scenario: 复杂查询性能
- **WHEN** 解析复杂 SQL（多表 JOIN、子查询）
- **THEN** 解析时间 < 10ms

#### Scenario: 批量吞吐量
- **WHEN** 4 核 CPU 多进程解析
- **THEN** 吞吐量 > 1000 条/秒

#### Scenario: 内存控制
- **WHEN** 批量解析 10000 条 SQL
- **THEN** 峰值内存 < 500MB


---

### Requirement: 错误信息数据模型
系统 SHALL 提供详细的错误位置信息。

#### Scenario: ParseError 包含行号
- **WHEN** 解析出错
- **THEN** ParseError.line 包含错误所在行号（从 1 开始）

#### Scenario: ParseError 包含列号
- **WHEN** 解析出错
- **THEN** ParseError.column 包含错误所在列号（从 1 开始）

#### Scenario: ParseError 包含偏移量
- **WHEN** 解析出错
- **THEN** ParseError.offset 包含错误在原始 SQL 中的字符偏移量

#### Scenario: ParseError 包含上下文
- **WHEN** 解析出错
- **THEN** ParseError.context 包含错误位置前后的 SQL 片段

#### Scenario: ParseError 包含标记文本
- **WHEN** 解析出错
- **THEN** ParseError.marked_sql 包含带错误标记的 SQL 文本
