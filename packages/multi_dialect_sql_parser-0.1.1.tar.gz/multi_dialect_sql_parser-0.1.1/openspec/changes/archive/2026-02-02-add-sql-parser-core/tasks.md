## 1. 项目初始化
- [x] 1.1 初始化 Python 项目（pyproject.toml）
- [x] 1.2 安装依赖：sqlglot[rs], pydantic
- [x] 1.3 配置性能监控工具

## 2. 数据模型定义
- [x] 2.1 定义 ParseResult, TableReference, ColumnReference 等 Pydantic 模型
- [x] 2.2 定义 DIALECT_MAP, SUPPORTED_DIALECTS 常量（dict/set）
- [x] 2.3 定义 BatchParseResult 批量结果模型

## 3. 核心解析器实现
- [x] 3.1 实现 SQLParser 类基础结构
- [x] 3.2 实现 parse_single() 方法（含局部变量缓存优化）
- [x] 3.3 实现表名提取（列表推导式）
- [x] 3.4 实现列名提取（列表推导式）
- [x] 3.5 实现条件表达式提取
- [x] 3.6 实现 JOIN 关系提取
- [x] 3.7 实现 GROUP BY / ORDER BY 提取
- [x] 3.8 实现语句类型识别（dict 映射）

## 4. MySQL 方言适配
- [x] 4.1 测试反引号标识符解析
- [x] 4.2 测试 LIMIT 子句解析
- [x] 4.3 测试 MySQL 特有函数识别
- [x] 4.4 测试 AUTO_INCREMENT 识别

## 5. PostgreSQL 方言适配
- [x] 5.1 测试双引号标识符解析
- [x] 5.2 测试 :: 类型转换解析
- [x] 5.3 测试 SERIAL 类型识别
- [x] 5.4 测试数组操作解析

## 6. 多进程批量解析
- [x] 6.1 实现 ProcessPoolExecutor 进程池
- [x] 6.2 实现分批处理逻辑
- [x] 6.3 实现流式返回（Iterator yield）
- [x] 6.4 配置进程回收（max_tasks_per_child）
- [x] 6.5 实现显式内存释放

## 7. 测试
- [x] 7.1 MySQL 方言单元测试
- [x] 7.2 PostgreSQL 方言单元测试
- [x] 7.3 批量解析测试
- [x] 7.4 性能基准测试
- [x] 7.5 内存占用测试
