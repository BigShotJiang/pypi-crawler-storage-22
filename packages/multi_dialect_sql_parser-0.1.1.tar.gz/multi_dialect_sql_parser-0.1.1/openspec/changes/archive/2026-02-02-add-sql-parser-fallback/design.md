## Context
处理 SQL 解析过程中的各种异常情况，包括语法错误、语义错误、不支持的语法等。核心目标是提供精确的错误位置信息，帮助用户快速定位问题。

## Goals / Non-Goals

### Goals
- 精确定位语法错误位置（行号、列号、偏移量）
- 提供错误上下文和可视化标记
- 检测常见语义错误
- 优雅降级处理不支持的语法

### Non-Goals
- 完整的语义分析（需要表结构信息）
- SQL 自动修复建议

## Decisions

### 错误位置数据模型

```python
from __future__ import annotations
from pydantic import BaseModel
from typing import Literal

class ParseError(BaseModel):
    """解析错误详细信息"""
    
    # 错误类型
    error_type: Literal[
        'syntax_error',           # 语法错误
        'semantic_warning',       # 语义警告
        'unsupported_syntax',     # 不支持的语法
        'dialect_unsupported',    # 方言不支持
        'unknown_element',        # 未知元素
    ]
    
    # 错误消息
    message: str
    
    # 位置信息
    line: int | None = None           # 行号（从 1 开始）
    column: int | None = None         # 列号（从 1 开始）
    offset: int | None = None         # 字符偏移量（从 0 开始）
    end_offset: int | None = None     # 错误结束位置
    
    # 上下文信息
    context: str | None = None        # 错误位置前后的 SQL 片段
    context_start: int | None = None  # 上下文起始偏移量
    
    # 可视化
    marked_sql: str | None = None     # 带错误标记的 SQL
    
    # 原始信息
    original_sql: str | None = None   # 原始 SQL（用于批量解析时定位）


class SemanticWarning(BaseModel):
    """语义警告"""
    
    warning_type: Literal[
        'ambiguous_column',       # 列名歧义
        'unknown_column',         # 未知列引用
        'missing_group_by',       # 缺少 GROUP BY
        'subquery_mismatch',      # 子查询不匹配
    ]
    
    message: str
    line: int | None = None
    column: int | None = None
    related_elements: list[str] = []  # 相关的列名/表名
```

### 错误位置计算

```python
def calculate_position(sql: str, offset: int) -> tuple[int, int]:
    """
    根据字符偏移量计算行号和列号
    
    Args:
        sql: 原始 SQL 文本
        offset: 字符偏移量（从 0 开始）
    
    Returns:
        (line, column) 行号和列号（从 1 开始）
    """
    lines = sql[:offset].split('\n')
    line = len(lines)
    column = len(lines[-1]) + 1
    return line, column


def extract_context(sql: str, offset: int, context_size: int = 30) -> str:
    """
    提取错误位置的上下文
    
    Args:
        sql: 原始 SQL 文本
        offset: 错误位置偏移量
        context_size: 上下文大小（前后各多少字符）
    
    Returns:
        上下文字符串
    """
    start = max(0, offset - context_size)
    end = min(len(sql), offset + context_size)
    
    prefix = "..." if start > 0 else ""
    suffix = "..." if end < len(sql) else ""
    
    return f"{prefix}{sql[start:end]}{suffix}"


def mark_error_position(sql: str, offset: int, length: int = 1) -> str:
    """
    生成带错误标记的 SQL 文本
    
    Args:
        sql: 原始 SQL 文本
        offset: 错误位置偏移量
        length: 错误长度
    
    Returns:
        带标记的 SQL 文本
    
    Example:
        SELECT * FORM users
                 ^^^^
        Error: Expected 'FROM', got 'FORM'
    """
    lines = sql.split('\n')
    line_num, col_num = calculate_position(sql, offset)
    
    error_line = lines[line_num - 1]
    marker = ' ' * (col_num - 1) + '^' * length
    
    return f"{error_line}\n{marker}"
```

### 错误处理流程

```
SQL 输入
    │
    ▼
┌─────────────────┐
│  语法解析       │
│  (SQLGlot)      │
└────────┬────────┘
         │
    ┌────┴────┐
    │ 成功?   │
    └────┬────┘
         │
    ┌────┴────┐
    │         │
    ▼         ▼
  成功      失败
    │         │
    ▼         ▼
┌─────────┐ ┌─────────────────┐
│语义检查 │ │ 捕获异常        │
│(可选)   │ │ 提取位置信息    │
└────┬────┘ │ 生成 ParseError │
     │      └────────┬────────┘
     ▼               │
┌─────────┐          │
│返回结果 │◄─────────┘
│+ 警告   │
└─────────┘
```

### 语义检查策略

| 检查项 | 检测方法 | 严重程度 |
|--------|----------|----------|
| 列名歧义 | 检查多表 JOIN 中无表前缀的列 | Warning |
| 缺少 GROUP BY | 检查 SELECT 中混合聚合和非聚合 | Warning |
| 子查询列数 | 检查 IN 子查询的 SELECT 列数 | Error |
| 未知函数 | 检查函数名是否在已知列表中 | Info |

## Risks / Trade-offs

| 风险 | 缓解措施 |
|------|----------|
| SQLGlot 异常信息不完整 | 自行解析异常消息提取位置 |
| 语义检查误报 | 默认关闭，可配置开启 |
| 性能影响 | 语义检查仅在单条解析时执行 |
