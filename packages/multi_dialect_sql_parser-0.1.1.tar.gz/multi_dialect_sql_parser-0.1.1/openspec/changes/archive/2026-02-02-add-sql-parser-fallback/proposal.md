# Change: SQL 解析器降级处理策略

## Why
当遇到不支持的语法时，需要优雅降级而非直接失败。这包括：
1. 完全不支持的数据库方言
2. 支持的方言中不支持的特有语法
3. 语法错误的 SQL

## What Changes
- 实现降级处理策略
- 实现部分解析（尽可能提取信息）
- 实现错误报告机制
- 实现未知语法标记

## Impact
- Affected specs: sql-parser-fallback (新建)
- Affected code: sql_parser/fallback.py
- 依赖: add-sql-parser-core
