## Context
OceanBase 支持两种模式：MySQL 兼容模式和 Oracle 兼容模式。需要创建两个自定义方言分别处理。

## Goals / Non-Goals

### Goals
- 支持 OceanBase MySQL 模式
- 支持 OceanBase Oracle 模式
- 处理 OceanBase 特有 Hint 和语法

### Non-Goals
- OceanBase 特有系统表解析
- OceanBase 集群管理语句

## Decisions

### 双模式方言实现

```python
from sqlglot.dialects.mysql import MySQL
from sqlglot.dialects.oracle import Oracle

class OceanBaseMySQL(MySQL):
    """OceanBase MySQL 模式"""
    
    class Tokenizer(MySQL.Tokenizer):
        pass
    
    class Parser(MySQL.Parser):
        pass


class OceanBaseOracle(Oracle):
    """OceanBase Oracle 模式"""
    
    class Tokenizer(Oracle.Tokenizer):
        pass
    
    class Parser(Oracle.Parser):
        pass


# 注册方言
from sqlglot.dialects import Dialects
Dialects.register("oceanbase-mysql", OceanBaseMySQL)
Dialects.register("oceanbase-oracle", OceanBaseOracle)
```

### OceanBase Hint 解析

```python
OCEANBASE_HINTS = {
    "PARALLEL": "parallel_hint",
    "USE_HASH": "join_hint",
    "USE_MERGE": "join_hint",
    "USE_NL": "join_hint",
    "LEADING": "join_order_hint",
    "ORDERED": "join_order_hint",
    "INDEX": "index_hint",
    "FULL": "scan_hint",
    "NO_REWRITE": "optimizer_hint",
}

def extract_oceanbase_hints(sql: str) -> list[dict]:
    """提取 OceanBase Hint"""
    # 与 TiDB 类似的 Hint 格式
    pass
```

### 模式选择策略

```python
def detect_oceanbase_mode(sql: str) -> str:
    """
    检测 OceanBase 模式
    
    基于语法特征判断：
    - (+) 外连接 -> Oracle 模式
    - 反引号标识符 -> MySQL 模式
    - ROWNUM -> Oracle 模式
    - LIMIT -> MySQL 模式
    """
    oracle_indicators = ["(+)", "ROWNUM", "CONNECT BY", "NVL("]
    mysql_indicators = ["`", "LIMIT", "IFNULL(", "AUTO_INCREMENT"]
    
    sql_upper = sql.upper()
    
    oracle_score = sum(1 for i in oracle_indicators if i in sql_upper or i in sql)
    mysql_score = sum(1 for i in mysql_indicators if i in sql_upper or i in sql)
    
    return "oceanbase-oracle" if oracle_score > mysql_score else "oceanbase-mysql"
```

## 数据模型

```python
class OceanBaseSpecificInfo(BaseModel):
    """OceanBase 特有信息"""
    
    mode: str  # "mysql" or "oracle"
    hints: list[dict] = []
    partition_info: dict | None = None
```

## Risks / Trade-offs

| 风险 | 缓解措施 |
|------|----------|
| 模式检测错误 | 允许显式指定模式 |
| 版本差异 | 支持通用语法 |
