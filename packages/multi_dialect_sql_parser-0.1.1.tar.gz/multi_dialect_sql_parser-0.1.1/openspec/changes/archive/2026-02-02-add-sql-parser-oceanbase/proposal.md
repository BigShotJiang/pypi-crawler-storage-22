# Change: SQL 解析器 OceanBase 双模式方言支持

## Why
OceanBase 支持两种模式：MySQL 兼容模式和 Oracle 兼容模式。需要创建两个自定义方言分别处理。

## What Changes
- 创建 OceanBase-MySQL 自定义方言（继承 MySQL）
- 创建 OceanBase-Oracle 自定义方言（继承 Oracle）
- 处理 OceanBase 特有语法和函数

## Impact
- Affected specs: sql-parser-oceanbase (新建)
- Affected code: sql_parser/dialects/oceanbase.py
- 依赖: add-sql-parser-core, add-sql-parser-oracle
