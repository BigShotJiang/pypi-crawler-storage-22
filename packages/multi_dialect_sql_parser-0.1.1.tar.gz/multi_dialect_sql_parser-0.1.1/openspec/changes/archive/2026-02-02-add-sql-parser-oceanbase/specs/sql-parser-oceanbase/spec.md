## ADDED Requirements

### Requirement: OceanBase-MySQL 模式支持
系统 SHALL 支持 OceanBase MySQL 兼容模式语法解析。

#### Scenario: MySQL 兼容语法
- **WHEN** SQL 使用标准 MySQL 语法
- **THEN** 正确解析（继承 MySQL 方言能力）

#### Scenario: OceanBase Hint 解析
- **WHEN** SQL 包含 OceanBase 特有 Hint（如 /*+ PARALLEL(4) */）
- **THEN** 正确识别 Hint 类型和参数

#### Scenario: OceanBase 分区表
- **WHEN** DDL 包含 OceanBase 分区语法
- **THEN** 正确识别分区类型（RANGE/HASH/LIST/KEY）

#### Scenario: OceanBase 特有函数
- **WHEN** SQL 包含 OceanBase 特有函数
- **THEN** 正确识别为 OceanBase 系统函数

---

### Requirement: OceanBase-Oracle 模式支持
系统 SHALL 支持 OceanBase Oracle 兼容模式语法解析。

#### Scenario: Oracle 兼容语法
- **WHEN** SQL 使用 Oracle 语法
- **THEN** 正确解析（继承 Oracle 方言能力）

#### Scenario: OceanBase Oracle 模式 Hint
- **WHEN** SQL 包含 OceanBase Oracle 模式 Hint
- **THEN** 正确识别 Hint 类型和参数

#### Scenario: OceanBase Oracle 模式特有语法
- **WHEN** SQL 包含 OceanBase Oracle 模式特有语法
- **THEN** 正确解析或标记为 OceanBase 扩展

---

### Requirement: 双模式方言实现
系统 SHALL 通过继承实现 OceanBase 双模式支持。

#### Scenario: MySQL 模式方言
- **WHEN** 指定 dialect="oceanbase-mysql"
- **THEN** 使用 OceanBase-MySQL 方言类（继承 MySQL）

#### Scenario: Oracle 模式方言
- **WHEN** 指定 dialect="oceanbase-oracle"
- **THEN** 使用 OceanBase-Oracle 方言类（继承 Oracle）

#### Scenario: 方言注册
- **WHEN** 解析器初始化
- **THEN** 两种 OceanBase 方言均已注册到 SQLGlot
