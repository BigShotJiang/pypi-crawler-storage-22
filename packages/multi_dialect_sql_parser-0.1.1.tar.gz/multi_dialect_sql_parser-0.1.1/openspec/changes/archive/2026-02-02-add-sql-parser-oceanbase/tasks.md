## 1. OceanBase-MySQL 方言创建
- [x] 1.1 创建 OceanBaseMySQL 方言类（继承 MySQL）
- [x] 1.2 注册方言到 SQLGlot
- [x] 1.3 验证 MySQL 兼容语法正常工作

## 2. OceanBase-MySQL 特有语法
- [x] 2.1 实现 OceanBase Hint 解析
- [x] 2.2 实现 OceanBase 分区表语法解析
- [x] 2.3 实现 OceanBase 特有函数识别

## 3. OceanBase-Oracle 方言创建
- [x] 3.1 创建 OceanBaseOracle 方言类（继承 Oracle）
- [x] 3.2 注册方言到 SQLGlot
- [x] 3.3 验证 Oracle 兼容语法正常工作

## 4. OceanBase-Oracle 特有语法
- [x] 4.1 实现 OceanBase Oracle 模式 Hint 解析
- [x] 4.2 实现 OceanBase Oracle 模式特有语法

## 5. 测试
- [x] 5.1 OceanBase-MySQL 模式测试
- [x] 5.2 OceanBase-Oracle 模式测试
- [x] 5.3 双模式切换测试
