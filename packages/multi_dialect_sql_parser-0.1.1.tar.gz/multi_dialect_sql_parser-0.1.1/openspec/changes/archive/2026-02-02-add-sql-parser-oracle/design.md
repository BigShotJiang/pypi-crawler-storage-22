## Context
扩展 SQL 解析器支持 Oracle 数据库方言。Oracle 有许多特有语法需要专门处理，同时为 OceanBase-Oracle 模式奠定基础。

## Goals / Non-Goals

### Goals
- 支持 Oracle 特有语法解析
- 正确处理 Oracle 标识符规则（默认大写）
- 为 OceanBase-Oracle 提供基础

### Non-Goals
- PL/SQL 存储过程体解析（标记为不支持）
- Oracle 特有的系统表查询优化

## Decisions

### Oracle 特有语法处理策略

| 语法 | SQLGlot 支持 | 处理方式 |
|------|-------------|----------|
| 双引号标识符 | ✅ 原生支持 | 自动处理 |
| ROWNUM | ✅ 原生支持 | 识别为伪列 |
| CONNECT BY | ✅ 原生支持 | 提取层次关系 |
| (+) 外连接 | ⚠️ 部分支持 | 转换为标准 JOIN |
| DUAL 表 | ✅ 原生支持 | 标记为系统表 |
| 序列 NEXTVAL/CURRVAL | ✅ 原生支持 | 识别为序列引用 |
| DECODE | ✅ 原生支持 | 识别为条件函数 |
| NVL/NVL2 | ✅ 原生支持 | 识别为空值函数 |
| MERGE INTO | ✅ 原生支持 | 提取完整结构 |
| 分析函数 | ✅ 原生支持 | 提取窗口定义 |

### (+) 外连接转换

```python
def convert_oracle_join(sql: str) -> str:
    """
    将 Oracle (+) 语法转换为标准 ANSI JOIN
    
    Oracle: SELECT * FROM a, b WHERE a.id = b.id(+)
    ANSI:   SELECT * FROM a LEFT JOIN b ON a.id = b.id
    """
    # SQLGlot 可以自动处理这种转换
    ast = sqlglot.parse_one(sql, dialect="oracle")
    return ast.sql(dialect="oracle")
```

### CONNECT BY 层次查询提取

```python
from sqlglot import exp

def extract_hierarchy(ast) -> dict | None:
    """提取 CONNECT BY 层次查询信息"""
    connect_by = ast.find(exp.ConnectByRoot)
    if not connect_by:
        return None
    
    return {
        "start_with": str(ast.find(exp.StartWith)),
        "connect_by": str(connect_by),
        "prior_column": extract_prior_column(connect_by),
    }
```

### Oracle 函数映射

```python
ORACLE_FUNCTIONS = {
    "NVL": "null_handling",
    "NVL2": "null_handling",
    "DECODE": "conditional",
    "ROWNUM": "pseudo_column",
    "ROWID": "pseudo_column",
    "SYSDATE": "datetime",
    "SYSTIMESTAMP": "datetime",
    "TO_DATE": "conversion",
    "TO_CHAR": "conversion",
    "TO_NUMBER": "conversion",
}

def classify_oracle_function(func_name: str) -> str:
    """分类 Oracle 函数"""
    return ORACLE_FUNCTIONS.get(func_name.upper(), "unknown")
```

### MERGE 语句解析

```python
def extract_merge_info(ast) -> dict:
    """提取 MERGE 语句信息"""
    merge = ast.find(exp.Merge)
    if not merge:
        return {}
    
    return {
        "target_table": str(merge.this),
        "source": str(merge.using),
        "on_condition": str(merge.on),
        "when_matched": extract_when_matched(merge),
        "when_not_matched": extract_when_not_matched(merge),
    }
```

## 数据模型扩展

```python
class OracleSpecificInfo(BaseModel):
    """Oracle 特有信息"""
    
    # 层次查询
    hierarchy: dict | None = None
    
    # 序列引用
    sequences: list[str] = []
    
    # 伪列使用
    pseudo_columns: list[str] = []  # ROWNUM, ROWID
    
    # (+) 外连接（原始语法）
    oracle_outer_joins: list[dict] = []
```

## Risks / Trade-offs

| 风险 | 缓解措施 |
|------|----------|
| (+) 语法转换不完整 | 保留原始语法信息 |
| PL/SQL 不支持 | 明确标记，返回过程名 |
| Oracle 版本差异 | 支持通用语法，特殊语法标记 |
