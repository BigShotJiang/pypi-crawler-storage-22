# Change: SQL 解析器 Oracle 方言支持

## Why
扩展 SQL 解析器支持 Oracle 数据库方言。Oracle 有许多特有语法（如 ROWNUM、CONNECT BY、(+) 外连接），需要专门处理。

## What Changes
- 新增 Oracle 方言解析支持
- 处理 Oracle 特有语法
- 为 OceanBase-Oracle 模式奠定基础

## Impact
- Affected specs: sql-parser-oracle (新建)
- Affected code: sql_parser/dialects/oracle.py
- 依赖: add-sql-parser-core
