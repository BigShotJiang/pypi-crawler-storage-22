## 1. Oracle 方言适配
- [x] 1.1 验证 SQLGlot Oracle 方言基础支持
- [x] 1.2 测试双引号标识符解析
- [x] 1.3 测试 ROWNUM 伪列识别
- [x] 1.4 测试 CONNECT BY 层次查询解析

## 2. Oracle 特有语法处理
- [x] 2.1 实现 (+) 外连接语法转换
- [x] 2.2 实现序列引用识别（NEXTVAL/CURRVAL）
- [x] 2.3 实现 DUAL 表识别
- [x] 2.4 实现 DECODE 函数解析
- [x] 2.5 实现 NVL/NVL2 函数解析

## 3. Oracle 高级语法
- [x] 3.1 实现分析函数/窗口函数解析
- [x] 3.2 实现 MERGE 语句解析
- [x] 3.3 实现 PL/SQL 块识别（标记为不支持）

## 4. 测试
- [x] 4.1 Oracle 基础语法单元测试
- [x] 4.2 Oracle 特有语法单元测试
- [x] 4.3 Oracle 复杂查询测试
