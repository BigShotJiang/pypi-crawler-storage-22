# Design: 多数据库存储过程/函数语法支持

## Context

SQLGlot 对各数据库的过程化语法支持有限，主要问题：

| 数据库 | 问题 |
|--------|------|
| Oracle | RETURN 关键字冲突、PACKAGE 内部声明、触发器 PL/SQL 体 |
| MySQL | DELIMITER 语法、复杂 BEGIN...END 块 |
| PostgreSQL | $$ 美元引号语法、LANGUAGE 子句 |
| TiDB | 同 MySQL |
| OceanBase | Oracle 模式同 Oracle，MySQL 模式同 MySQL |

## Goals / Non-Goals

### Goals
- 解析各数据库过程化对象的元信息（名称、参数、返回类型等）
- 保留完整的过程化源代码供后续使用
- 与现有预处理器架构保持一致
- 提供统一的 ProceduralInfo 数据模型

### Non-Goals
- 解析过程体内部的控制流语句
- 解析游标、异常处理
- 验证过程化语法正确性

## Decisions

### 1. 统一数据模型

```python
class ProceduralInfo(BaseModel):
    """过程化对象信息（通用模型）"""
    
    # 对象类型
    type: Literal[
        "FUNCTION",           # 函数
        "PROCEDURE",          # 存储过程
        "PACKAGE",            # 包（Oracle）
        "PACKAGE_BODY",       # 包体（Oracle）
        "TRIGGER",            # 触发器
        "ANONYMOUS_BLOCK",    # 匿名块
    ]
    
    # 基本信息
    name: str | None = None           # 对象名（匿名块为 None）
    schema: str | None = None         # Schema 名
    
    # 参数信息
    parameters: list[ParameterInfo] = []
    
    # 函数特有
    return_type: str | None = None    # 返回类型
    deterministic: bool = False       # 是否确定性（MySQL）
    
    # 包特有（Oracle）
    is_body: bool = False             # 是否为 PACKAGE BODY
    procedures: list[dict] = []       # 包内过程声明
    functions: list[dict] = []        # 包内函数声明
    
    # 触发器特有
    timing: str | None = None         # BEFORE | AFTER | INSTEAD OF
    events: list[str] = []            # [INSERT, UPDATE, DELETE]
    table_name: str | None = None     # 触发表
    level: str | None = None          # ROW | STATEMENT
    when_condition: str | None = None # WHEN 条件
    
    # PostgreSQL 特有
    language: str | None = None       # plpgsql, sql, python 等
    
    # 通用
    body: str | None = None           # 原始代码体
    is_replace: bool = False          # OR REPLACE
    dialect: str | None = None        # 来源方言


class ParameterInfo(BaseModel):
    """参数信息"""
    name: str                         # 参数名
    mode: str = "IN"                  # IN | OUT | INOUT
    datatype: str                     # 数据类型
    default_value: str | None = None  # 默认值
```

### 2. 各数据库语法识别

#### Oracle PL/SQL

| 语法 | 识别模式 |
|------|----------|
| CREATE FUNCTION | `CREATE [OR REPLACE] FUNCTION ... RETURN ... AS/IS` |
| CREATE PROCEDURE | `CREATE [OR REPLACE] PROCEDURE ... AS/IS` |
| CREATE PACKAGE | `CREATE [OR REPLACE] PACKAGE ... AS/IS` |
| CREATE PACKAGE BODY | `CREATE [OR REPLACE] PACKAGE BODY ... AS/IS` |
| CREATE TRIGGER | `CREATE [OR REPLACE] TRIGGER ... BEFORE/AFTER ... ON` |
| 匿名块 | `^(DECLARE|BEGIN)` |

#### MySQL

| 语法 | 识别模式 |
|------|----------|
| CREATE FUNCTION | `CREATE FUNCTION ... RETURNS ... BEGIN` |
| CREATE PROCEDURE | `CREATE PROCEDURE ... BEGIN` |
| CREATE TRIGGER | `CREATE TRIGGER ... BEFORE/AFTER ... ON ... FOR EACH ROW` |

#### PostgreSQL

| 语法 | 识别模式 |
|------|----------|
| CREATE FUNCTION | `CREATE [OR REPLACE] FUNCTION ... RETURNS ... AS \$\$` |
| CREATE PROCEDURE | `CREATE [OR REPLACE] PROCEDURE ... AS \$\$` |
| CREATE TRIGGER | `CREATE TRIGGER ... EXECUTE FUNCTION/PROCEDURE` |
| DO 块 | `^DO \$\$` |

### 3. 预处理器扩展

```python
class SQLPreprocessor:
    def preprocess(self, sql: str) -> PreprocessResult:
        # ... 现有逻辑 ...
        
        if self.dialect == "oracle":
            sql, mods, proc_info = self._preprocess_oracle_procedural(sql)
        elif self.dialect == "mysql":
            sql, mods, proc_info = self._preprocess_mysql_procedural(sql)
        elif self.dialect == "postgresql":
            sql, mods, proc_info = self._preprocess_postgresql_procedural(sql)
        elif self.dialect == "tidb":
            sql, mods, proc_info = self._preprocess_mysql_procedural(sql)  # 兼容 MySQL
        elif self.dialect in ("oceanbase-mysql", "oceanbase-oracle"):
            sql, mods, proc_info = self._preprocess_oceanbase_procedural(sql)
```

### 4. Oracle PL/SQL 解析

```python
def _preprocess_oracle_procedural(self, sql: str) -> tuple[str, list[dict], ProceduralInfo | None]:
    """Oracle PL/SQL 预处理"""
    sql_upper = sql.upper().strip()
    
    # CREATE FUNCTION
    if "CREATE" in sql_upper and "FUNCTION" in sql_upper and "RETURN" in sql_upper:
        return self._parse_oracle_function(sql)
    
    # CREATE PROCEDURE
    if "CREATE" in sql_upper and "PROCEDURE" in sql_upper:
        return self._parse_oracle_procedure(sql)
    
    # CREATE PACKAGE
    if "CREATE" in sql_upper and "PACKAGE" in sql_upper:
        return self._parse_oracle_package(sql)
    
    # CREATE TRIGGER
    if "CREATE" in sql_upper and "TRIGGER" in sql_upper:
        return self._parse_oracle_trigger(sql)
    
    # 匿名块
    if sql_upper.startswith("BEGIN") or sql_upper.startswith("DECLARE"):
        return self._parse_oracle_anonymous_block(sql)
    
    return sql, [], None
```

**Oracle FUNCTION 正则：**
```python
ORACLE_FUNCTION_PATTERN = re.compile(
    r'CREATE\s+(?:OR\s+REPLACE\s+)?FUNCTION\s+'
    r'(\w+(?:\.\w+)?)\s*'           # 函数名
    r'(?:\(([^)]*)\))?\s*'          # 参数列表
    r'RETURN\s+(\w+(?:\([^)]*\))?)\s*'  # 返回类型
    r'(?:DETERMINISTIC\s+)?'        # DETERMINISTIC（可选）
    r'(?:IS|AS)\s*'                 # IS 或 AS
    r'(.*)',                        # 函数体
    re.IGNORECASE | re.DOTALL
)
```

### 5. MySQL 存储过程解析

```python
def _preprocess_mysql_procedural(self, sql: str) -> tuple[str, list[dict], ProceduralInfo | None]:
    """MySQL 存储过程预处理"""
    sql_upper = sql.upper().strip()
    
    # CREATE FUNCTION
    if "CREATE" in sql_upper and "FUNCTION" in sql_upper and "RETURNS" in sql_upper:
        return self._parse_mysql_function(sql)
    
    # CREATE PROCEDURE
    if "CREATE" in sql_upper and "PROCEDURE" in sql_upper:
        return self._parse_mysql_procedure(sql)
    
    # CREATE TRIGGER
    if "CREATE" in sql_upper and "TRIGGER" in sql_upper:
        return self._parse_mysql_trigger(sql)
    
    return sql, [], None
```

**MySQL FUNCTION 正则：**
```python
MYSQL_FUNCTION_PATTERN = re.compile(
    r'CREATE\s+(?:DEFINER\s*=\s*\S+\s+)?FUNCTION\s+'
    r'(\w+(?:\.\w+)?)\s*'           # 函数名
    r'\(([^)]*)\)\s*'               # 参数列表
    r'RETURNS\s+(\w+(?:\([^)]*\))?)\s*'  # 返回类型
    r'(?:DETERMINISTIC\s+)?'        # DETERMINISTIC
    r'(?:NO\s+SQL|READS\s+SQL\s+DATA|MODIFIES\s+SQL\s+DATA|CONTAINS\s+SQL)?\s*'
    r'(?:BEGIN\s+)?'                # BEGIN（可选）
    r'(.*)',                        # 函数体
    re.IGNORECASE | re.DOTALL
)
```

**MySQL TRIGGER 正则：**
```python
MYSQL_TRIGGER_PATTERN = re.compile(
    r'CREATE\s+(?:DEFINER\s*=\s*\S+\s+)?TRIGGER\s+'
    r'(\w+(?:\.\w+)?)\s+'           # 触发器名
    r'(BEFORE|AFTER)\s+'            # 触发时机
    r'(INSERT|UPDATE|DELETE)\s+'    # 触发事件
    r'ON\s+(\w+(?:\.\w+)?)\s+'      # 表名
    r'FOR\s+EACH\s+ROW\s*'          # FOR EACH ROW
    r'(?:FOLLOWS\s+\w+\s*)?'        # FOLLOWS（可选）
    r'(?:PRECEDES\s+\w+\s*)?'       # PRECEDES（可选）
    r'(.*)',                        # 触发器体
    re.IGNORECASE | re.DOTALL
)
```

### 6. PostgreSQL PL/pgSQL 解析

```python
def _preprocess_postgresql_procedural(self, sql: str) -> tuple[str, list[dict], ProceduralInfo | None]:
    """PostgreSQL PL/pgSQL 预处理"""
    sql_upper = sql.upper().strip()
    
    # CREATE FUNCTION
    if "CREATE" in sql_upper and "FUNCTION" in sql_upper:
        return self._parse_postgresql_function(sql)
    
    # CREATE PROCEDURE
    if "CREATE" in sql_upper and "PROCEDURE" in sql_upper:
        return self._parse_postgresql_procedure(sql)
    
    # CREATE TRIGGER
    if "CREATE" in sql_upper and "TRIGGER" in sql_upper:
        return self._parse_postgresql_trigger(sql)
    
    # DO 块
    if sql_upper.startswith("DO"):
        return self._parse_postgresql_do_block(sql)
    
    return sql, [], None
```

**PostgreSQL FUNCTION 正则（处理 $$ 语法）：**
```python
POSTGRESQL_FUNCTION_PATTERN = re.compile(
    r'CREATE\s+(?:OR\s+REPLACE\s+)?FUNCTION\s+'
    r'(\w+(?:\.\w+)?)\s*'           # 函数名
    r'\(([^)]*)\)\s*'               # 参数列表
    r'RETURNS\s+(\w+(?:\([^)]*\))?)\s*'  # 返回类型
    r'(?:AS\s+)?'                   # AS
    r'\$(\w*)\$'                    # 开始 $$ 或 $tag$
    r'(.*?)'                        # 函数体
    r'\$\4\$'                       # 结束 $$ 或 $tag$
    r'\s*LANGUAGE\s+(\w+)',         # LANGUAGE
    re.IGNORECASE | re.DOTALL
)
```

**PostgreSQL TRIGGER 正则：**
```python
POSTGRESQL_TRIGGER_PATTERN = re.compile(
    r'CREATE\s+(?:OR\s+REPLACE\s+)?(?:CONSTRAINT\s+)?TRIGGER\s+'
    r'(\w+)\s+'                     # 触发器名
    r'(BEFORE|AFTER|INSTEAD\s+OF)\s+'  # 触发时机
    r'(INSERT|UPDATE|DELETE|TRUNCATE)'  # 触发事件
    r'(?:\s+OR\s+(INSERT|UPDATE|DELETE|TRUNCATE))*\s+'
    r'ON\s+(\w+(?:\.\w+)?)\s*'      # 表名
    r'(?:FOR\s+EACH\s+(ROW|STATEMENT))?\s*'
    r'(?:WHEN\s*\(([^)]+)\))?\s*'   # WHEN 条件
    r'EXECUTE\s+(?:FUNCTION|PROCEDURE)\s+'
    r'(\w+(?:\.\w+)?)\s*\(\)',      # 执行函数
    re.IGNORECASE | re.DOTALL
)
```

### 7. OceanBase 双模式处理

```python
def _preprocess_oceanbase_procedural(self, sql: str) -> tuple[str, list[dict], ProceduralInfo | None]:
    """OceanBase 过程化语法预处理"""
    if self.dialect == "oceanbase-oracle":
        # Oracle 模式使用 Oracle 解析器
        return self._preprocess_oracle_procedural(sql)
    else:
        # MySQL 模式使用 MySQL 解析器
        return self._preprocess_mysql_procedural(sql)
```

### 8. 转换策略

| 原始语法 | 转换为 |
|----------|--------|
| Oracle CREATE FUNCTION | CREATE PROCEDURE (SQLGlot 支持) |
| Oracle CREATE PACKAGE | CREATE PROCEDURE pkg_name_pkg |
| Oracle CREATE TRIGGER | CREATE PROCEDURE trigger_name_trigger |
| Oracle 匿名块 | SELECT 1 FROM DUAL |
| MySQL CREATE FUNCTION | CREATE PROCEDURE (移除 RETURNS) |
| MySQL CREATE TRIGGER | CREATE PROCEDURE trigger_name_trigger |
| PostgreSQL CREATE FUNCTION | CREATE PROCEDURE (移除 $$) |
| PostgreSQL DO 块 | SELECT 1 |

### 9. statement_type 映射

| 过程化类型 | statement_type |
|------------|----------------|
| CREATE FUNCTION | CREATE_FUNCTION |
| CREATE PROCEDURE | CREATE_PROCEDURE |
| CREATE PACKAGE | CREATE_PACKAGE |
| CREATE PACKAGE BODY | CREATE_PACKAGE_BODY |
| CREATE TRIGGER | CREATE_TRIGGER |
| 匿名块/DO 块 | ANONYMOUS_BLOCK |

## 测试用例设计

### Oracle 测试用例

```python
ORACLE_PROCEDURAL_CASES = [
    {
        "name": "oracle_function",
        "sql": "CREATE FUNCTION get_count RETURN NUMBER AS BEGIN RETURN 1; END;",
        "expected": {
            "success": True,
            "statement_type": "CREATE_FUNCTION",
            "procedural_info": {
                "type": "FUNCTION",
                "name": "get_count",
                "return_type": "NUMBER",
            }
        }
    },
    {
        "name": "oracle_package",
        "sql": "CREATE PACKAGE emp_pkg AS PROCEDURE hire(p_name VARCHAR2); END;",
        "expected": {
            "success": True,
            "statement_type": "CREATE_PACKAGE",
            "procedural_info": {
                "type": "PACKAGE",
                "name": "emp_pkg",
                "procedures": [{"name": "hire"}],
            }
        }
    },
]
```

### MySQL 测试用例

```python
MYSQL_PROCEDURAL_CASES = [
    {
        "name": "mysql_function",
        "sql": "CREATE FUNCTION get_count() RETURNS INT DETERMINISTIC BEGIN RETURN 1; END",
        "expected": {
            "success": True,
            "statement_type": "CREATE_FUNCTION",
            "procedural_info": {
                "type": "FUNCTION",
                "name": "get_count",
                "return_type": "INT",
                "deterministic": True,
            }
        }
    },
    {
        "name": "mysql_procedure",
        "sql": "CREATE PROCEDURE hire(IN p_name VARCHAR(100)) BEGIN INSERT INTO emp(name) VALUES(p_name); END",
        "expected": {
            "success": True,
            "statement_type": "CREATE_PROCEDURE",
            "procedural_info": {
                "type": "PROCEDURE",
                "name": "hire",
                "parameters": [{"name": "p_name", "mode": "IN", "datatype": "VARCHAR(100)"}],
            }
        }
    },
]
```

### PostgreSQL 测试用例

```python
POSTGRESQL_PROCEDURAL_CASES = [
    {
        "name": "postgresql_function",
        "sql": "CREATE FUNCTION get_count() RETURNS INTEGER AS $$ BEGIN RETURN 1; END; $$ LANGUAGE plpgsql",
        "expected": {
            "success": True,
            "statement_type": "CREATE_FUNCTION",
            "procedural_info": {
                "type": "FUNCTION",
                "name": "get_count",
                "return_type": "INTEGER",
                "language": "plpgsql",
            }
        }
    },
    {
        "name": "postgresql_do_block",
        "sql": "DO $$ BEGIN RAISE NOTICE 'Hello'; END; $$",
        "expected": {
            "success": True,
            "statement_type": "ANONYMOUS_BLOCK",
            "procedural_info": {
                "type": "ANONYMOUS_BLOCK",
                "language": "plpgsql",
            }
        }
    },
]
```

## Risks / Trade-offs

| 风险 | 影响 | 缓解措施 |
|------|------|----------|
| 正则表达式无法处理复杂嵌套 | 部分复杂语法解析失败 | 保留原始代码，标记为部分解析 |
| $$ 内部包含 $$ | PostgreSQL 解析失败 | 使用命名标签 $tag$ |
| DELIMITER 语法 | MySQL 批量脚本问题 | 预处理移除 DELIMITER |
| 参数默认值包含括号 | 参数解析不完整 | 使用更复杂的括号匹配 |

## 实现优先级

1. **P0 - 必须实现**
   - Oracle CREATE FUNCTION/TRIGGER/匿名块
   - MySQL CREATE FUNCTION/PROCEDURE/TRIGGER
   - PostgreSQL CREATE FUNCTION

2. **P1 - 应该实现**
   - Oracle CREATE PACKAGE/PACKAGE BODY
   - PostgreSQL CREATE PROCEDURE/TRIGGER/DO 块
   - 参数详细解析

3. **P2 - 可以延后**
   - 复杂默认值解析
   - INSTEAD OF 触发器
   - 多事件触发器解析


## 复杂查询测试用例

### Oracle 复杂查询测试用例

| 测试用例 | 描述 | 关键特性 |
|----------|------|----------|
| oracle_complex_multi_join | 多表连接查询 | INNER JOIN, LEFT JOIN, 6表关联 |
| oracle_complex_cte_subquery | CTE 和子查询 | WITH 子句, RANK(), PERCENT_RANK() |
| oracle_complex_connect_by | 层次查询 | CONNECT BY, START WITH, SYS_CONNECT_BY_PATH |

### MySQL 复杂查询测试用例

| 测试用例 | 描述 | 关键特性 |
|----------|------|----------|
| mysql_complex_multi_join | 多表连接查询 | INNER JOIN, LEFT JOIN, 6表关联 |
| mysql_complex_subquery | 子查询和派生表 | 相关子查询, 派生表 |
| mysql_complex_cte_window | CTE 和窗口函数 | WITH 子句, SUM() OVER, LAG() |
| mysql_complex_union | UNION 查询 | UNION ALL, 条件聚合 |
| mysql_complex_exists | EXISTS 子查询 | EXISTS, NOT EXISTS |

### PostgreSQL 复杂查询测试用例

| 测试用例 | 描述 | 关键特性 |
|----------|------|----------|
| postgresql_complex_window | 窗口函数 | RANK(), PERCENT_RANK(), RETURNS TABLE |
| postgresql_complex_recursive_cte | 递归 CTE | WITH RECURSIVE, UNION ALL |
| postgresql_complex_lateral_join | LATERAL JOIN | CROSS JOIN LATERAL, ROW_NUMBER() |
| postgresql_complex_json | JSON 操作 | jsonb_build_object, jsonb_agg |
| postgresql_complex_array | 数组操作 | TEXT[], unnest, INTERSECT, && 操作符 |

### 测试用例实现位置

所有复杂查询测试用例已添加到 `tests/sql_scripts/procedural_scripts.py` 文件中：

- Oracle: `ORACLE_PROCEDURAL_CASES` 字典
- MySQL: `MYSQL_PROCEDURAL_CASES` 字典
- PostgreSQL: `POSTGRESQL_PROCEDURAL_CASES` 字典
