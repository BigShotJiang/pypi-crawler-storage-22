# Proposal: 多数据库存储过程/函数语法支持

## 概述

扩展 SQL 解析器以支持各数据库的存储过程、函数、触发器等过程化语法的解析。

## 背景

当前 SQL 解析器基于 SQLGlot 库，对标准 DDL/DML 支持良好，但对各数据库的过程化语法支持有限：

| 数据库 | 过程化语言 | 当前状态 |
|--------|-----------|----------|
| Oracle | PL/SQL | ❌ CREATE FUNCTION/PACKAGE/TRIGGER 失败 |
| MySQL | 存储过程 | ⚠️ 部分支持，复杂语法失败 |
| PostgreSQL | PL/pgSQL | ⚠️ 部分支持，$$ 语法问题 |
| TiDB | 兼容 MySQL | ⚠️ 同 MySQL |
| OceanBase | PL/SQL + MySQL | ⚠️ 双模式，问题同上 |

## 各数据库过程化语法对比

### Oracle PL/SQL
```sql
CREATE FUNCTION get_salary(p_id NUMBER) RETURN NUMBER AS
BEGIN
    RETURN 1000;
END;

CREATE PACKAGE emp_pkg AS
    PROCEDURE hire(p_name VARCHAR2);
    FUNCTION get_count RETURN NUMBER;
END emp_pkg;

CREATE TRIGGER trg_audit BEFORE INSERT ON employees
FOR EACH ROW BEGIN
    :NEW.created_at := SYSDATE;
END;
```

### MySQL 存储过程
```sql
CREATE FUNCTION get_salary(p_id INT) RETURNS INT
DETERMINISTIC
BEGIN
    RETURN 1000;
END;

CREATE PROCEDURE hire_employee(IN p_name VARCHAR(100))
BEGIN
    INSERT INTO employees(name) VALUES(p_name);
END;

CREATE TRIGGER trg_audit BEFORE INSERT ON employees
FOR EACH ROW SET NEW.created_at = NOW();
```

### PostgreSQL PL/pgSQL
```sql
CREATE FUNCTION get_salary(p_id INTEGER) RETURNS INTEGER AS $$
BEGIN
    RETURN 1000;
END;
$$ LANGUAGE plpgsql;

CREATE PROCEDURE hire_employee(p_name VARCHAR)
LANGUAGE plpgsql AS $$
BEGIN
    INSERT INTO employees(name) VALUES(p_name);
END;
$$;

CREATE TRIGGER trg_audit BEFORE INSERT ON employees
FOR EACH ROW EXECUTE FUNCTION audit_func();
```

## 目标

1. 支持 Oracle PL/SQL 对象解析（FUNCTION, PACKAGE, TRIGGER, 匿名块）
2. 支持 MySQL 存储过程/函数/触发器解析
3. 支持 PostgreSQL PL/pgSQL 对象解析（含 $$ 语法）
4. 支持 TiDB 存储过程（兼容 MySQL）
5. 支持 OceanBase 双模式存储过程
6. 提取过程化对象的元信息（名称、参数、返回类型等）

## 非目标

- 解析过程体内部的控制流语句（IF/LOOP/CASE）
- 解析游标声明和操作
- 解析异常处理块
- 验证过程化语法正确性
- 执行或模拟存储过程

## 技术方案

采用预处理器模式，为每种数据库方言添加过程化语法处理：
1. 检测过程化语句类型
2. 使用正则表达式提取关键元信息
3. 将过程化语法转换为 SQLGlot 可解析的简化形式
4. 在结果中保留完整的过程化信息

## 影响范围

- `src/sql_parser/preprocessor.py` - 添加各方言过程化语法预处理
- `src/sql_parser/models.py` - 添加 ProceduralInfo 通用模型
- `src/sql_parser/extractors/` - 各方言提取器传递过程化信息
- `src/sql_parser/core.py` - 集成预处理结果
- `tests/sql_scripts/` - 各方言添加过程化测试用例

## 依赖

- 依赖 `add-sql-parser-core` 提案（已实现）
- 依赖 `add-sql-parser-oracle` 提案（已实现）
- 依赖 `add-sql-parser-tidb` 提案（已实现）
- 依赖 `add-sql-parser-oceanbase` 提案（已实现）
