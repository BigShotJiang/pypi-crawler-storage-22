# Tasks: 多数据库存储过程/函数语法支持

## 1. 数据模型扩展

- [x] 1.1 在 `models.py` 中添加 `ParameterInfo` 模型
- [x] 1.2 在 `models.py` 中添加 `ProceduralInfo` 通用模型
- [x] 1.3 扩展 `PreprocessResult` 添加 `procedural_info` 字段
- [x] 1.4 扩展各方言 SpecificInfo 模型添加 `procedural_info` 字段

## 2. Oracle PL/SQL 预处理器

- [x] 2.1 实现 `_preprocess_oracle_procedural()` 主入口
- [x] 2.2 实现 `_parse_oracle_function()` - CREATE FUNCTION 解析
- [x] 2.3 实现 `_parse_oracle_procedure()` - CREATE PROCEDURE 解析
- [x] 2.4 实现 `_parse_oracle_package()` - CREATE PACKAGE 解析
- [x] 2.5 实现 `_parse_oracle_trigger()` - CREATE TRIGGER 解析
- [x] 2.6 实现 `_parse_oracle_anonymous_block()` - 匿名块解析

## 3. MySQL 存储过程预处理器

- [x] 3.1 实现 `_preprocess_mysql_procedural()` 主入口
- [x] 3.2 实现 `_parse_mysql_function()` - CREATE FUNCTION 解析
- [x] 3.3 实现 `_parse_mysql_procedure()` - CREATE PROCEDURE 解析
- [x] 3.4 实现 `_parse_mysql_trigger()` - CREATE TRIGGER 解析

## 4. PostgreSQL PL/pgSQL 预处理器

- [x] 4.1 实现 `_preprocess_postgresql_procedural()` 主入口
- [x] 4.2 实现 `_parse_postgresql_function()` - CREATE FUNCTION 解析（含 $$ 语法）
- [x] 4.3 实现 `_parse_postgresql_procedure()` - CREATE PROCEDURE 解析
- [x] 4.4 实现 `_parse_postgresql_trigger()` - CREATE TRIGGER 解析
- [x] 4.5 实现 `_parse_postgresql_do_block()` - DO 块解析

## 5. TiDB/OceanBase 适配

- [x] 5.1 TiDB 复用 MySQL 预处理器
- [x] 5.2 OceanBase-MySQL 模式复用 MySQL 预处理器
- [x] 5.3 OceanBase-Oracle 模式复用 Oracle 预处理器

## 6. 通用工具函数

- [x] 6.1 实现 `_parse_parameters()` - 参数列表解析
- [x] 6.2 实现 `_extract_package_members()` - Oracle 包成员提取
- [x] 6.3 实现 `_extract_dollar_quoted_body()` - PostgreSQL $$ 内容提取

## 7. 核心解析器集成

- [x] 7.1 修改 `core.py` 传递 `procedural_info` 到各提取器
- [x] 7.2 修改各方言提取器接收并返回 `procedural_info`
- [x] 7.3 根据过程化类型设置正确的 `statement_type`

## 8. Oracle 测试用例

> 测试物料：`test-cases/oracle_procedural_cases.md`

- [x] 8.1 添加 CREATE FUNCTION 测试用例（5个：简单/带参数/OR REPLACE/带 Schema/复杂返回类型）
- [x] 8.2 添加 CREATE PROCEDURE 测试用例（4个：简单/IN OUT/IN OUT/复杂业务逻辑）
- [x] 8.3 添加 CREATE PACKAGE 测试用例（3个：简单包/复杂包/包体）
- [x] 8.4 添加 CREATE TRIGGER 测试用例（4个：BEFORE INSERT/AFTER UPDATE/带 WHEN/INSTEAD OF）
- [x] 8.5 添加匿名块测试用例（3个：简单/带 DECLARE/带异常处理）
- [x] 8.6 添加复杂查询测试用例（3个：多表连接/子查询 CTE/层次查询 CONNECT BY）

## 9. MySQL 测试用例

> 测试物料：`test-cases/mysql_procedural_cases.md`

- [x] 9.1 添加 CREATE FUNCTION 测试用例（5个：简单/带参数/DEFINER/复杂逻辑/字符串处理）
- [x] 9.2 添加 CREATE PROCEDURE 测试用例（5个：简单/IN OUT/INOUT/事务控制/游标）
- [x] 9.3 添加 CREATE TRIGGER 测试用例（5个：BEFORE INSERT/AFTER INSERT/BEFORE UPDATE/AFTER DELETE/DEFINER）
- [x] 9.4 添加复杂查询测试用例（5个：多表连接/子查询/CTE 窗口函数/UNION/EXISTS）

## 10. PostgreSQL 测试用例

> 测试物料：`test-cases/postgresql_procedural_cases.md`

- [x] 10.1 添加 CREATE FUNCTION 测试用例（7个：简单/$$/OR REPLACE/命名标签/返回表/SETOF/OUT 参数）
- [x] 10.2 添加 CREATE PROCEDURE 测试用例（4个：简单/INOUT/事务控制/批量处理）
- [x] 10.3 添加 CREATE TRIGGER 测试用例（5个：BEFORE INSERT/AFTER UPDATE/带 WHEN/INSTEAD OF/STATEMENT 级）
- [x] 10.4 添加 DO 块测试用例（4个：简单/带变量/异常处理/命名标签）
- [x] 10.5 添加复杂查询测试用例（5个：窗口函数/递归 CTE/LATERAL JOIN/JSON/数组）

## 11. TiDB/OceanBase 测试用例

> 测试物料：`test-cases/tidb_oceanbase_cases.md`

- [x] 11.1 添加 TiDB 存储过程测试用例（6个：函数/带 Hint/分布式事务/批量处理/触发器）
- [x] 11.2 添加 OceanBase-MySQL 模式测试用例（4个：函数/带 Hint/多租户/分区维护）
- [x] 11.3 添加 OceanBase-Oracle 模式测试用例（6个：函数/复杂函数/分布式同步/报表/包声明/包体）

## 12. 验证与文档

- [x] 12.1 运行所有现有测试确保无回归
- [x] 12.2 运行新增过程化测试用例
- [x] 12.3 更新各方言 design.md 文档

## 验收标准

1. 所有现有测试通过（无回归）
2. Oracle PL/SQL 对象解析成功率 > 90%
3. MySQL 存储过程解析成功率 > 90%
4. PostgreSQL PL/pgSQL 解析成功率 > 90%
5. 各方言 procedural_info 包含正确的元信息
6. statement_type 正确标识过程化对象类型
