# MySQL 存储过程测试用例

## 1. CREATE FUNCTION 测试用例

### 1.1 简单函数（无参数）
```sql
CREATE FUNCTION get_current_timestamp()
RETURNS DATETIME
DETERMINISTIC
BEGIN
    RETURN NOW();
END
```

### 1.2 带参数函数
```sql
CREATE FUNCTION calculate_tax(
    amount DECIMAL(10,2),
    tax_rate DECIMAL(5,4)
)
RETURNS DECIMAL(10,2)
DETERMINISTIC
BEGIN
    RETURN amount * tax_rate;
END
```

### 1.3 带 DEFINER 的函数
```sql
CREATE DEFINER=`admin`@`localhost` FUNCTION get_employee_count(
    dept_id INT
)
RETURNS INT
READS SQL DATA
BEGIN
    DECLARE emp_count INT;
    SELECT COUNT(*) INTO emp_count
    FROM employees
    WHERE department_id = dept_id;
    RETURN emp_count;
END
```

### 1.4 复杂业务逻辑函数
```sql
CREATE FUNCTION calculate_bonus(
    emp_id INT,
    base_rate DECIMAL(5,4)
)
RETURNS DECIMAL(10,2)
READS SQL DATA
BEGIN
    DECLARE emp_salary DECIMAL(10,2);
    DECLARE years_employed INT;
    DECLARE bonus DECIMAL(10,2);
    
    SELECT salary, TIMESTAMPDIFF(YEAR, hire_date, CURDATE())
    INTO emp_salary, years_employed
    FROM employees
    WHERE employee_id = emp_id;
    
    -- 根据工龄调整奖金比例
    SET bonus = emp_salary * base_rate;
    IF years_employed >= 10 THEN
        SET bonus = bonus * 1.5;
    ELSEIF years_employed >= 5 THEN
        SET bonus = bonus * 1.2;
    END IF;
    
    RETURN bonus;
END
```

### 1.5 字符串处理函数
```sql
CREATE FUNCTION format_full_name(
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    title VARCHAR(20)
)
RETURNS VARCHAR(150)
DETERMINISTIC
BEGIN
    DECLARE full_name VARCHAR(150);
    
    IF title IS NOT NULL AND title != '' THEN
        SET full_name = CONCAT(title, ' ', first_name, ' ', last_name);
    ELSE
        SET full_name = CONCAT(first_name, ' ', last_name);
    END IF;
    
    RETURN full_name;
END
```

---

## 2. CREATE PROCEDURE 测试用例

### 2.1 简单存储过程
```sql
CREATE PROCEDURE log_activity(
    IN user_id INT,
    IN activity_type VARCHAR(50)
)
BEGIN
    INSERT INTO activity_log(user_id, activity_type, created_at)
    VALUES(user_id, activity_type, NOW());
END
```

### 2.2 带 IN/OUT 参数的存储过程
```sql
CREATE PROCEDURE get_employee_info(
    IN emp_id INT,
    OUT emp_name VARCHAR(100),
    OUT emp_salary DECIMAL(10,2),
    OUT emp_dept VARCHAR(100)
)
BEGIN
    SELECT 
        CONCAT(first_name, ' ', last_name),
        salary,
        d.department_name
    INTO emp_name, emp_salary, emp_dept
    FROM employees e
    LEFT JOIN departments d ON e.department_id = d.department_id
    WHERE e.employee_id = emp_id;
END
```

### 2.3 带 INOUT 参数的存储过程
```sql
CREATE PROCEDURE adjust_salary(
    IN emp_id INT,
    INOUT salary_amount DECIMAL(10,2),
    IN adjustment_type VARCHAR(20)
)
BEGIN
    DECLARE current_salary DECIMAL(10,2);
    
    SELECT salary INTO current_salary
    FROM employees
    WHERE employee_id = emp_id;
    
    IF adjustment_type = 'INCREASE' THEN
        SET salary_amount = current_salary + salary_amount;
    ELSEIF adjustment_type = 'DECREASE' THEN
        SET salary_amount = current_salary - salary_amount;
    ELSEIF adjustment_type = 'SET' THEN
        -- salary_amount 保持不变
        SET salary_amount = salary_amount;
    END IF;
    
    UPDATE employees
    SET salary = salary_amount
    WHERE employee_id = emp_id;
END
```

### 2.4 带事务控制的存储过程
```sql
CREATE PROCEDURE transfer_funds(
    IN from_account INT,
    IN to_account INT,
    IN amount DECIMAL(15,2),
    OUT status VARCHAR(50)
)
BEGIN
    DECLARE from_balance DECIMAL(15,2);
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SET status = 'FAILED: Transaction rolled back';
    END;
    
    START TRANSACTION;
    
    -- 检查余额
    SELECT balance INTO from_balance
    FROM accounts
    WHERE account_id = from_account
    FOR UPDATE;
    
    IF from_balance < amount THEN
        SET status = 'FAILED: Insufficient funds';
        ROLLBACK;
    ELSE
        -- 扣款
        UPDATE accounts
        SET balance = balance - amount
        WHERE account_id = from_account;
        
        -- 入账
        UPDATE accounts
        SET balance = balance + amount
        WHERE account_id = to_account;
        
        -- 记录交易
        INSERT INTO transactions(from_account, to_account, amount, transaction_date)
        VALUES(from_account, to_account, amount, NOW());
        
        COMMIT;
        SET status = 'SUCCESS';
    END IF;
END
```

### 2.5 带游标的存储过程
```sql
CREATE PROCEDURE process_pending_orders()
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE order_id INT;
    DECLARE order_total DECIMAL(15,2);
    
    DECLARE order_cursor CURSOR FOR
        SELECT o.order_id, SUM(oi.quantity * oi.unit_price) AS total
        FROM orders o
        JOIN order_items oi ON o.order_id = oi.order_id
        WHERE o.status = 'PENDING'
        GROUP BY o.order_id;
    
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    
    OPEN order_cursor;
    
    read_loop: LOOP
        FETCH order_cursor INTO order_id, order_total;
        IF done THEN
            LEAVE read_loop;
        END IF;
        
        -- 更新订单总额和状态
        UPDATE orders
        SET total_amount = order_total,
            status = 'PROCESSED',
            processed_at = NOW()
        WHERE orders.order_id = order_id;
    END LOOP;
    
    CLOSE order_cursor;
END
```

---

## 3. CREATE TRIGGER 测试用例

### 3.1 BEFORE INSERT 触发器
```sql
CREATE TRIGGER trg_employee_before_insert
BEFORE INSERT ON employees
FOR EACH ROW
BEGIN
    SET NEW.created_at = NOW();
    SET NEW.updated_at = NOW();
    IF NEW.status IS NULL THEN
        SET NEW.status = 'ACTIVE';
    END IF;
END
```

### 3.2 AFTER INSERT 触发器
```sql
CREATE TRIGGER trg_order_after_insert
AFTER INSERT ON orders
FOR EACH ROW
BEGIN
    -- 更新客户订单统计
    UPDATE customers
    SET total_orders = total_orders + 1,
        last_order_date = NOW()
    WHERE customer_id = NEW.customer_id;
    
    -- 记录日志
    INSERT INTO order_log(order_id, action, action_date)
    VALUES(NEW.order_id, 'CREATED', NOW());
END
```

### 3.3 BEFORE UPDATE 触发器
```sql
CREATE TRIGGER trg_product_before_update
BEFORE UPDATE ON products
FOR EACH ROW
BEGIN
    SET NEW.updated_at = NOW();
    
    -- 记录价格变更历史
    IF OLD.price != NEW.price THEN
        INSERT INTO price_history(product_id, old_price, new_price, changed_at)
        VALUES(OLD.product_id, OLD.price, NEW.price, NOW());
    END IF;
END
```

### 3.4 AFTER DELETE 触发器
```sql
CREATE TRIGGER trg_employee_after_delete
AFTER DELETE ON employees
FOR EACH ROW
BEGIN
    -- 归档已删除员工
    INSERT INTO employees_archive(
        employee_id, first_name, last_name, email,
        department_id, salary, hire_date, deleted_at
    ) VALUES (
        OLD.employee_id, OLD.first_name, OLD.last_name, OLD.email,
        OLD.department_id, OLD.salary, OLD.hire_date, NOW()
    );
    
    -- 更新部门员工数
    UPDATE departments
    SET employee_count = employee_count - 1
    WHERE department_id = OLD.department_id;
END
```

### 3.5 带 DEFINER 的触发器
```sql
CREATE DEFINER=`admin`@`localhost` TRIGGER trg_audit_sensitive_data
AFTER UPDATE ON user_profiles
FOR EACH ROW
BEGIN
    IF OLD.email != NEW.email OR OLD.phone != NEW.phone THEN
        INSERT INTO security_audit(
            table_name, record_id, field_changed,
            old_value, new_value, changed_by, changed_at
        ) VALUES
        ('user_profiles', NEW.user_id, 'contact_info',
         CONCAT('email:', OLD.email, ',phone:', OLD.phone),
         CONCAT('email:', NEW.email, ',phone:', NEW.phone),
         CURRENT_USER(), NOW());
    END IF;
END
```

---

## 4. 复杂查询测试用例（在过程中使用）

### 4.1 多表连接查询
```sql
CREATE PROCEDURE get_order_details(
    IN p_order_id INT
)
BEGIN
    SELECT 
        o.order_id,
        o.order_date,
        o.status,
        c.customer_name,
        c.email AS customer_email,
        p.product_name,
        oi.quantity,
        oi.unit_price,
        (oi.quantity * oi.unit_price) AS line_total,
        s.shipper_name,
        a.street_address,
        a.city,
        a.postal_code
    FROM orders o
    INNER JOIN customers c ON o.customer_id = c.customer_id
    INNER JOIN order_items oi ON o.order_id = oi.order_id
    INNER JOIN products p ON oi.product_id = p.product_id
    LEFT JOIN shippers s ON o.shipper_id = s.shipper_id
    LEFT JOIN addresses a ON o.shipping_address_id = a.address_id
    WHERE o.order_id = p_order_id
    ORDER BY oi.line_number;
END
```

### 4.2 子查询和派生表
```sql
CREATE PROCEDURE get_top_customers(
    IN p_year INT,
    IN p_limit INT
)
BEGIN
    SELECT 
        c.customer_id,
        c.customer_name,
        customer_stats.total_orders,
        customer_stats.total_amount,
        customer_stats.avg_order_value,
        (
            SELECT COUNT(DISTINCT product_id)
            FROM order_items oi
            JOIN orders o ON oi.order_id = o.order_id
            WHERE o.customer_id = c.customer_id
        ) AS unique_products_purchased
    FROM customers c
    INNER JOIN (
        SELECT 
            customer_id,
            COUNT(*) AS total_orders,
            SUM(total_amount) AS total_amount,
            AVG(total_amount) AS avg_order_value
        FROM orders
        WHERE YEAR(order_date) = p_year
        GROUP BY customer_id
    ) customer_stats ON c.customer_id = customer_stats.customer_id
    WHERE customer_stats.total_orders >= 3
    ORDER BY customer_stats.total_amount DESC
    LIMIT p_limit;
END
```

### 4.3 CTE 和窗口函数
```sql
CREATE PROCEDURE generate_sales_report(
    IN p_start_date DATE,
    IN p_end_date DATE
)
BEGIN
    WITH daily_sales AS (
        SELECT 
            DATE(order_date) AS sale_date,
            SUM(total_amount) AS daily_total,
            COUNT(*) AS order_count
        FROM orders
        WHERE order_date BETWEEN p_start_date AND p_end_date
        GROUP BY DATE(order_date)
    ),
    running_totals AS (
        SELECT 
            sale_date,
            daily_total,
            order_count,
            SUM(daily_total) OVER (ORDER BY sale_date) AS cumulative_total,
            AVG(daily_total) OVER (
                ORDER BY sale_date
                ROWS BETWEEN 6 PRECEDING AND CURRENT ROW
            ) AS moving_avg_7day
        FROM daily_sales
    )
    SELECT 
        rt.sale_date,
        rt.daily_total,
        rt.order_count,
        rt.cumulative_total,
        ROUND(rt.moving_avg_7day, 2) AS moving_avg_7day,
        ROUND(
            (rt.daily_total - LAG(rt.daily_total) OVER (ORDER BY rt.sale_date)) 
            / LAG(rt.daily_total) OVER (ORDER BY rt.sale_date) * 100, 
            2
        ) AS day_over_day_growth
    FROM running_totals rt
    ORDER BY rt.sale_date;
END
```

### 4.4 UNION 和条件聚合
```sql
CREATE PROCEDURE get_inventory_summary()
BEGIN
    SELECT 
        'Low Stock' AS category,
        COUNT(*) AS product_count,
        SUM(quantity_in_stock) AS total_quantity,
        SUM(quantity_in_stock * unit_cost) AS total_value
    FROM products
    WHERE quantity_in_stock < reorder_level
    
    UNION ALL
    
    SELECT 
        'Normal Stock' AS category,
        COUNT(*) AS product_count,
        SUM(quantity_in_stock) AS total_quantity,
        SUM(quantity_in_stock * unit_cost) AS total_value
    FROM products
    WHERE quantity_in_stock >= reorder_level 
      AND quantity_in_stock <= reorder_level * 3
    
    UNION ALL
    
    SELECT 
        'Overstock' AS category,
        COUNT(*) AS product_count,
        SUM(quantity_in_stock) AS total_quantity,
        SUM(quantity_in_stock * unit_cost) AS total_value
    FROM products
    WHERE quantity_in_stock > reorder_level * 3;
END
```

### 4.5 EXISTS 和 NOT EXISTS
```sql
CREATE PROCEDURE find_inactive_customers(
    IN p_days_inactive INT
)
BEGIN
    SELECT 
        c.customer_id,
        c.customer_name,
        c.email,
        c.registration_date,
        (
            SELECT MAX(order_date)
            FROM orders o
            WHERE o.customer_id = c.customer_id
        ) AS last_order_date
    FROM customers c
    WHERE EXISTS (
        SELECT 1 FROM orders o
        WHERE o.customer_id = c.customer_id
    )
    AND NOT EXISTS (
        SELECT 1 FROM orders o
        WHERE o.customer_id = c.customer_id
        AND o.order_date > DATE_SUB(CURDATE(), INTERVAL p_days_inactive DAY)
    )
    ORDER BY last_order_date;
END
```
