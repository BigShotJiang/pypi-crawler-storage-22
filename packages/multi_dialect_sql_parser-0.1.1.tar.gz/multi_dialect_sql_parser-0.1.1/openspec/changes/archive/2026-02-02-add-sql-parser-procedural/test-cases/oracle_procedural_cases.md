# Oracle PL/SQL 测试用例

## 1. CREATE FUNCTION 测试用例

### 1.1 简单函数（无参数）
```sql
CREATE FUNCTION get_current_date RETURN DATE AS
BEGIN
    RETURN SYSDATE;
END;
```

### 1.2 带参数函数
```sql
CREATE FUNCTION calculate_salary(
    p_base_salary NUMBER,
    p_bonus_rate NUMBER DEFAULT 0.1
) RETURN NUMBER AS
    v_total NUMBER;
BEGIN
    v_total := p_base_salary * (1 + p_bonus_rate);
    RETURN v_total;
END calculate_salary;
```

### 1.3 OR REPLACE 函数
```sql
CREATE OR REPLACE FUNCTION get_employee_count(
    p_dept_id IN NUMBER
) RETURN NUMBER AS
    v_count NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_count
    FROM employees
    WHERE department_id = p_dept_id;
    RETURN v_count;
END;
```

### 1.4 带 Schema 的函数
```sql
CREATE OR REPLACE FUNCTION hr.get_manager_name(
    p_emp_id NUMBER
) RETURN VARCHAR2 AS
    v_name VARCHAR2(100);
BEGIN
    SELECT manager_name INTO v_name
    FROM employees e
    JOIN departments d ON e.department_id = d.department_id
    WHERE e.employee_id = p_emp_id;
    RETURN v_name;
END;
```

### 1.5 复杂返回类型函数
```sql
CREATE FUNCTION get_employee_info(p_id NUMBER)
RETURN SYS_REFCURSOR AS
    v_cursor SYS_REFCURSOR;
BEGIN
    OPEN v_cursor FOR
        SELECT e.employee_id, e.first_name, e.last_name,
               d.department_name, j.job_title
        FROM employees e
        LEFT JOIN departments d ON e.department_id = d.department_id
        LEFT JOIN jobs j ON e.job_id = j.job_id
        WHERE e.employee_id = p_id;
    RETURN v_cursor;
END;
```

---

## 2. CREATE PROCEDURE 测试用例

### 2.1 简单存储过程
```sql
CREATE PROCEDURE log_message(p_message VARCHAR2) AS
BEGIN
    INSERT INTO log_table(message, created_at)
    VALUES(p_message, SYSDATE);
    COMMIT;
END;
```

### 2.2 带 IN/OUT 参数的存储过程
```sql
CREATE OR REPLACE PROCEDURE get_employee_salary(
    p_emp_id IN NUMBER,
    p_salary OUT NUMBER,
    p_bonus OUT NUMBER
) AS
BEGIN
    SELECT salary, bonus
    INTO p_salary, p_bonus
    FROM employees
    WHERE employee_id = p_emp_id;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        p_salary := 0;
        p_bonus := 0;
END;
```

### 2.3 带 IN OUT 参数的存储过程
```sql
CREATE PROCEDURE update_and_return_salary(
    p_emp_id IN NUMBER,
    p_salary IN OUT NUMBER,
    p_increase_rate IN NUMBER DEFAULT 0.05
) AS
BEGIN
    UPDATE employees
    SET salary = salary * (1 + p_increase_rate)
    WHERE employee_id = p_emp_id
    RETURNING salary INTO p_salary;
    COMMIT;
END;
```

### 2.4 复杂业务逻辑存储过程
```sql
CREATE OR REPLACE PROCEDURE transfer_employee(
    p_emp_id IN NUMBER,
    p_new_dept_id IN NUMBER,
    p_new_manager_id IN NUMBER,
    p_effective_date IN DATE DEFAULT SYSDATE
) AS
    v_old_dept_id NUMBER;
    v_old_manager_id NUMBER;
BEGIN
    -- 获取当前信息
    SELECT department_id, manager_id
    INTO v_old_dept_id, v_old_manager_id
    FROM employees
    WHERE employee_id = p_emp_id;
    
    -- 记录历史
    INSERT INTO employee_history(
        employee_id, old_dept_id, new_dept_id,
        old_manager_id, new_manager_id, transfer_date
    ) VALUES (
        p_emp_id, v_old_dept_id, p_new_dept_id,
        v_old_manager_id, p_new_manager_id, p_effective_date
    );
    
    -- 更新员工信息
    UPDATE employees
    SET department_id = p_new_dept_id,
        manager_id = p_new_manager_id,
        last_update_date = SYSDATE
    WHERE employee_id = p_emp_id;
    
    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        RAISE;
END transfer_employee;
```

---

## 3. CREATE PACKAGE 测试用例

### 3.1 简单包声明
```sql
CREATE PACKAGE employee_pkg AS
    PROCEDURE hire_employee(p_name VARCHAR2, p_salary NUMBER);
    FUNCTION get_employee_count RETURN NUMBER;
END employee_pkg;
```

### 3.2 复杂包声明（带类型定义）
```sql
CREATE OR REPLACE PACKAGE hr_utils AS
    -- 类型定义
    TYPE emp_record IS RECORD (
        emp_id NUMBER,
        emp_name VARCHAR2(100),
        salary NUMBER
    );
    TYPE emp_table IS TABLE OF emp_record;
    
    -- 常量
    c_max_salary CONSTANT NUMBER := 1000000;
    c_min_salary CONSTANT NUMBER := 30000;
    
    -- 过程声明
    PROCEDURE hire_employee(
        p_first_name VARCHAR2,
        p_last_name VARCHAR2,
        p_email VARCHAR2,
        p_salary NUMBER DEFAULT c_min_salary
    );
    
    PROCEDURE fire_employee(p_emp_id NUMBER);
    
    -- 函数声明
    FUNCTION get_department_budget(p_dept_id NUMBER) RETURN NUMBER;
    FUNCTION get_employees_by_dept(p_dept_id NUMBER) RETURN emp_table PIPELINED;
    
END hr_utils;
```

### 3.3 包体实现
```sql
CREATE OR REPLACE PACKAGE BODY hr_utils AS
    
    PROCEDURE hire_employee(
        p_first_name VARCHAR2,
        p_last_name VARCHAR2,
        p_email VARCHAR2,
        p_salary NUMBER DEFAULT c_min_salary
    ) AS
    BEGIN
        INSERT INTO employees(first_name, last_name, email, salary, hire_date)
        VALUES(p_first_name, p_last_name, p_email, p_salary, SYSDATE);
        COMMIT;
    END hire_employee;
    
    PROCEDURE fire_employee(p_emp_id NUMBER) AS
    BEGIN
        UPDATE employees
        SET termination_date = SYSDATE,
            status = 'TERMINATED'
        WHERE employee_id = p_emp_id;
        COMMIT;
    END fire_employee;
    
    FUNCTION get_department_budget(p_dept_id NUMBER) RETURN NUMBER AS
        v_budget NUMBER;
    BEGIN
        SELECT SUM(salary) INTO v_budget
        FROM employees
        WHERE department_id = p_dept_id;
        RETURN NVL(v_budget, 0);
    END get_department_budget;
    
    FUNCTION get_employees_by_dept(p_dept_id NUMBER) RETURN emp_table PIPELINED AS
        v_rec emp_record;
    BEGIN
        FOR r IN (
            SELECT employee_id, first_name || ' ' || last_name, salary
            FROM employees
            WHERE department_id = p_dept_id
        ) LOOP
            v_rec.emp_id := r.employee_id;
            v_rec.emp_name := r.first_name || ' ' || r.last_name;
            v_rec.salary := r.salary;
            PIPE ROW(v_rec);
        END LOOP;
        RETURN;
    END get_employees_by_dept;
    
END hr_utils;
```

---

## 4. CREATE TRIGGER 测试用例

### 4.1 BEFORE INSERT 触发器
```sql
CREATE TRIGGER trg_employee_before_insert
BEFORE INSERT ON employees
FOR EACH ROW
BEGIN
    :NEW.created_at := SYSDATE;
    :NEW.created_by := USER;
    IF :NEW.employee_id IS NULL THEN
        SELECT employee_seq.NEXTVAL INTO :NEW.employee_id FROM DUAL;
    END IF;
END;
```

### 4.2 AFTER UPDATE 触发器
```sql
CREATE OR REPLACE TRIGGER trg_salary_audit
AFTER UPDATE OF salary ON employees
FOR EACH ROW
BEGIN
    INSERT INTO salary_audit_log(
        employee_id, old_salary, new_salary,
        changed_by, changed_at
    ) VALUES (
        :OLD.employee_id, :OLD.salary, :NEW.salary,
        USER, SYSDATE
    );
END;
```

### 4.3 带 WHEN 条件的触发器
```sql
CREATE TRIGGER trg_high_salary_alert
AFTER INSERT OR UPDATE OF salary ON employees
FOR EACH ROW
WHEN (NEW.salary > 100000)
BEGIN
    INSERT INTO high_salary_alerts(
        employee_id, salary, alert_date
    ) VALUES (
        :NEW.employee_id, :NEW.salary, SYSDATE
    );
END;
```

### 4.4 INSTEAD OF 触发器（视图）
```sql
CREATE OR REPLACE TRIGGER trg_emp_view_insert
INSTEAD OF INSERT ON employee_department_view
FOR EACH ROW
DECLARE
    v_dept_id NUMBER;
BEGIN
    -- 查找或创建部门
    SELECT department_id INTO v_dept_id
    FROM departments
    WHERE department_name = :NEW.department_name;
    
    -- 插入员工
    INSERT INTO employees(first_name, last_name, department_id)
    VALUES(:NEW.first_name, :NEW.last_name, v_dept_id);
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20001, 'Department not found');
END;
```

---

## 5. 匿名块测试用例

### 5.1 简单匿名块
```sql
BEGIN
    DBMS_OUTPUT.PUT_LINE('Hello, World!');
END;
```

### 5.2 带 DECLARE 的匿名块
```sql
DECLARE
    v_count NUMBER;
    v_name VARCHAR2(100);
BEGIN
    SELECT COUNT(*), MAX(first_name)
    INTO v_count, v_name
    FROM employees;
    
    DBMS_OUTPUT.PUT_LINE('Count: ' || v_count);
    DBMS_OUTPUT.PUT_LINE('Name: ' || v_name);
END;
```

### 5.3 复杂匿名块（带异常处理）
```sql
DECLARE
    v_emp_id NUMBER := 100;
    v_salary NUMBER;
    v_dept_name VARCHAR2(100);
    e_not_found EXCEPTION;
BEGIN
    SELECT e.salary, d.department_name
    INTO v_salary, v_dept_name
    FROM employees e
    JOIN departments d ON e.department_id = d.department_id
    WHERE e.employee_id = v_emp_id;
    
    IF v_salary IS NULL THEN
        RAISE e_not_found;
    END IF;
    
    DBMS_OUTPUT.PUT_LINE('Salary: ' || v_salary);
    DBMS_OUTPUT.PUT_LINE('Department: ' || v_dept_name);
    
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('Employee not found');
    WHEN e_not_found THEN
        DBMS_OUTPUT.PUT_LINE('Salary is null');
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
END;
```

---

## 6. 复杂查询测试用例（在过程中使用）

### 6.1 多表连接查询
```sql
CREATE FUNCTION get_employee_full_info(p_emp_id NUMBER)
RETURN SYS_REFCURSOR AS
    v_cursor SYS_REFCURSOR;
BEGIN
    OPEN v_cursor FOR
        SELECT 
            e.employee_id,
            e.first_name || ' ' || e.last_name AS full_name,
            e.email,
            e.salary,
            d.department_name,
            l.city || ', ' || l.country_id AS location,
            m.first_name || ' ' || m.last_name AS manager_name,
            j.job_title,
            jh.start_date AS job_start_date
        FROM employees e
        INNER JOIN departments d ON e.department_id = d.department_id
        INNER JOIN locations l ON d.location_id = l.location_id
        LEFT JOIN employees m ON e.manager_id = m.employee_id
        INNER JOIN jobs j ON e.job_id = j.job_id
        LEFT JOIN job_history jh ON e.employee_id = jh.employee_id
            AND jh.end_date IS NULL
        WHERE e.employee_id = p_emp_id;
    RETURN v_cursor;
END;
```

### 6.2 子查询和 CTE
```sql
CREATE OR REPLACE PROCEDURE generate_salary_report(
    p_dept_id IN NUMBER,
    p_result OUT SYS_REFCURSOR
) AS
BEGIN
    OPEN p_result FOR
        WITH dept_stats AS (
            SELECT 
                department_id,
                AVG(salary) AS avg_salary,
                MIN(salary) AS min_salary,
                MAX(salary) AS max_salary,
                COUNT(*) AS emp_count
            FROM employees
            GROUP BY department_id
        ),
        salary_ranks AS (
            SELECT 
                employee_id,
                salary,
                RANK() OVER (PARTITION BY department_id ORDER BY salary DESC) AS salary_rank,
                PERCENT_RANK() OVER (PARTITION BY department_id ORDER BY salary) AS percentile
            FROM employees
        )
        SELECT 
            e.employee_id,
            e.first_name || ' ' || e.last_name AS employee_name,
            e.salary,
            ds.avg_salary AS dept_avg_salary,
            e.salary - ds.avg_salary AS salary_diff,
            sr.salary_rank,
            ROUND(sr.percentile * 100, 2) AS salary_percentile,
            CASE 
                WHEN e.salary > ds.avg_salary * 1.2 THEN 'Above Average'
                WHEN e.salary < ds.avg_salary * 0.8 THEN 'Below Average'
                ELSE 'Average'
            END AS salary_category
        FROM employees e
        JOIN dept_stats ds ON e.department_id = ds.department_id
        JOIN salary_ranks sr ON e.employee_id = sr.employee_id
        WHERE e.department_id = p_dept_id
        ORDER BY sr.salary_rank;
END;
```

### 6.3 层次查询（CONNECT BY）
```sql
CREATE FUNCTION get_org_hierarchy(p_manager_id NUMBER)
RETURN SYS_REFCURSOR AS
    v_cursor SYS_REFCURSOR;
BEGIN
    OPEN v_cursor FOR
        SELECT 
            LEVEL AS hierarchy_level,
            LPAD(' ', (LEVEL - 1) * 4) || first_name || ' ' || last_name AS employee_tree,
            employee_id,
            manager_id,
            job_id,
            salary,
            SYS_CONNECT_BY_PATH(last_name, '/') AS path
        FROM employees
        START WITH employee_id = p_manager_id
        CONNECT BY PRIOR employee_id = manager_id
        ORDER SIBLINGS BY last_name;
    RETURN v_cursor;
END;
```
