# PostgreSQL PL/pgSQL 测试用例

## 1. CREATE FUNCTION 测试用例

### 1.1 简单函数（无参数）
```sql
CREATE FUNCTION get_current_timestamp()
RETURNS TIMESTAMP AS $$
BEGIN
    RETURN NOW();
END;
$$ LANGUAGE plpgsql;
```

### 1.2 带参数函数
```sql
CREATE FUNCTION calculate_discount(
    price NUMERIC,
    discount_rate NUMERIC DEFAULT 0.1
)
RETURNS NUMERIC AS $$
BEGIN
    RETURN price * (1 - discount_rate);
END;
$$ LANGUAGE plpgsql;
```

### 1.3 OR REPLACE 函数
```sql
CREATE OR REPLACE FUNCTION get_employee_count(
    dept_id INTEGER
)
RETURNS INTEGER AS $$
DECLARE
    emp_count INTEGER;
BEGIN
    SELECT COUNT(*) INTO emp_count
    FROM employees
    WHERE department_id = dept_id;
    RETURN emp_count;
END;
$$ LANGUAGE plpgsql;
```

### 1.4 带命名标签的函数（$tag$）
```sql
CREATE OR REPLACE FUNCTION format_address(
    street VARCHAR,
    city VARCHAR,
    state VARCHAR,
    zip VARCHAR
)
RETURNS VARCHAR AS $format_addr$
DECLARE
    formatted TEXT;
BEGIN
    formatted := street || E'\n' || city || ', ' || state || ' ' || zip;
    RETURN formatted;
END;
$format_addr$ LANGUAGE plpgsql;
```

### 1.5 返回表的函数
```sql
CREATE OR REPLACE FUNCTION get_employees_by_department(
    p_dept_id INTEGER
)
RETURNS TABLE (
    employee_id INTEGER,
    full_name VARCHAR,
    email VARCHAR,
    salary NUMERIC
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        e.employee_id,
        (e.first_name || ' ' || e.last_name)::VARCHAR,
        e.email,
        e.salary
    FROM employees e
    WHERE e.department_id = p_dept_id
    ORDER BY e.last_name, e.first_name;
END;
$$ LANGUAGE plpgsql;
```

### 1.6 返回 SETOF 的函数
```sql
CREATE OR REPLACE FUNCTION search_products(
    search_term VARCHAR,
    min_price NUMERIC DEFAULT 0,
    max_price NUMERIC DEFAULT 999999
)
RETURNS SETOF products AS $$
BEGIN
    RETURN QUERY
    SELECT *
    FROM products
    WHERE (product_name ILIKE '%' || search_term || '%'
           OR description ILIKE '%' || search_term || '%')
      AND price BETWEEN min_price AND max_price
    ORDER BY product_name;
END;
$$ LANGUAGE plpgsql;
```

### 1.7 带 OUT 参数的函数
```sql
CREATE OR REPLACE FUNCTION get_order_stats(
    p_customer_id INTEGER,
    OUT total_orders INTEGER,
    OUT total_amount NUMERIC,
    OUT avg_order_value NUMERIC
) AS $$
BEGIN
    SELECT 
        COUNT(*),
        COALESCE(SUM(total_amount), 0),
        COALESCE(AVG(total_amount), 0)
    INTO total_orders, total_amount, avg_order_value
    FROM orders
    WHERE customer_id = p_customer_id;
END;
$$ LANGUAGE plpgsql;
```

---

## 2. CREATE PROCEDURE 测试用例

### 2.1 简单存储过程
```sql
CREATE OR REPLACE PROCEDURE log_event(
    p_event_type VARCHAR,
    p_message TEXT
)
LANGUAGE plpgsql AS $$
BEGIN
    INSERT INTO event_log(event_type, message, created_at)
    VALUES(p_event_type, p_message, NOW());
END;
$$;
```

### 2.2 带 INOUT 参数的存储过程
```sql
CREATE OR REPLACE PROCEDURE update_inventory(
    p_product_id INTEGER,
    INOUT p_quantity INTEGER,
    p_operation VARCHAR DEFAULT 'ADD'
)
LANGUAGE plpgsql AS $$
DECLARE
    current_qty INTEGER;
BEGIN
    SELECT quantity_in_stock INTO current_qty
    FROM products
    WHERE product_id = p_product_id
    FOR UPDATE;
    
    IF p_operation = 'ADD' THEN
        p_quantity := current_qty + p_quantity;
    ELSIF p_operation = 'SUBTRACT' THEN
        p_quantity := current_qty - p_quantity;
        IF p_quantity < 0 THEN
            RAISE EXCEPTION 'Insufficient inventory';
        END IF;
    ELSIF p_operation = 'SET' THEN
        -- p_quantity 保持不变
        NULL;
    END IF;
    
    UPDATE products
    SET quantity_in_stock = p_quantity,
        updated_at = NOW()
    WHERE product_id = p_product_id;
END;
$$;
```

### 2.3 带事务控制的存储过程
```sql
CREATE OR REPLACE PROCEDURE transfer_funds(
    p_from_account INTEGER,
    p_to_account INTEGER,
    p_amount NUMERIC
)
LANGUAGE plpgsql AS $$
DECLARE
    from_balance NUMERIC;
BEGIN
    -- 锁定源账户
    SELECT balance INTO from_balance
    FROM accounts
    WHERE account_id = p_from_account
    FOR UPDATE;
    
    IF from_balance < p_amount THEN
        RAISE EXCEPTION 'Insufficient funds: balance=%, required=%', from_balance, p_amount;
    END IF;
    
    -- 扣款
    UPDATE accounts
    SET balance = balance - p_amount,
        updated_at = NOW()
    WHERE account_id = p_from_account;
    
    -- 入账
    UPDATE accounts
    SET balance = balance + p_amount,
        updated_at = NOW()
    WHERE account_id = p_to_account;
    
    -- 记录交易
    INSERT INTO transactions(from_account, to_account, amount, transaction_date)
    VALUES(p_from_account, p_to_account, p_amount, NOW());
    
    COMMIT;
END;
$$;
```

### 2.4 批量处理存储过程
```sql
CREATE OR REPLACE PROCEDURE process_expired_subscriptions()
LANGUAGE plpgsql AS $$
DECLARE
    rec RECORD;
    processed_count INTEGER := 0;
BEGIN
    FOR rec IN 
        SELECT subscription_id, user_id, plan_id
        FROM subscriptions
        WHERE status = 'ACTIVE'
          AND end_date < CURRENT_DATE
    LOOP
        -- 更新订阅状态
        UPDATE subscriptions
        SET status = 'EXPIRED',
            updated_at = NOW()
        WHERE subscription_id = rec.subscription_id;
        
        -- 发送通知
        INSERT INTO notifications(user_id, notification_type, message, created_at)
        VALUES(rec.user_id, 'SUBSCRIPTION_EXPIRED', 
               'Your subscription has expired', NOW());
        
        processed_count := processed_count + 1;
        
        -- 每处理100条提交一次
        IF processed_count % 100 = 0 THEN
            COMMIT;
        END IF;
    END LOOP;
    
    COMMIT;
    RAISE NOTICE 'Processed % expired subscriptions', processed_count;
END;
$$;
```

---

## 3. CREATE TRIGGER 测试用例

### 3.1 BEFORE INSERT 触发器
```sql
CREATE OR REPLACE FUNCTION trg_set_timestamps()
RETURNS TRIGGER AS $$
BEGIN
    NEW.created_at := NOW();
    NEW.updated_at := NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_employees_before_insert
BEFORE INSERT ON employees
FOR EACH ROW
EXECUTE FUNCTION trg_set_timestamps();
```

### 3.2 AFTER UPDATE 触发器
```sql
CREATE OR REPLACE FUNCTION trg_audit_salary_change()
RETURNS TRIGGER AS $$
BEGIN
    IF OLD.salary IS DISTINCT FROM NEW.salary THEN
        INSERT INTO salary_audit(
            employee_id, old_salary, new_salary,
            changed_by, changed_at
        ) VALUES (
            NEW.employee_id, OLD.salary, NEW.salary,
            current_user, NOW()
        );
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_employees_salary_audit
AFTER UPDATE OF salary ON employees
FOR EACH ROW
EXECUTE FUNCTION trg_audit_salary_change();
```

### 3.3 带 WHEN 条件的触发器
```sql
CREATE OR REPLACE FUNCTION trg_notify_high_value_order()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO notifications(
        notification_type, reference_id, message, created_at
    ) VALUES (
        'HIGH_VALUE_ORDER', NEW.order_id,
        'High value order placed: $' || NEW.total_amount,
        NOW()
    );
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_high_value_order_alert
AFTER INSERT ON orders
FOR EACH ROW
WHEN (NEW.total_amount > 10000)
EXECUTE FUNCTION trg_notify_high_value_order();
```

### 3.4 INSTEAD OF 触发器（视图）
```sql
CREATE OR REPLACE FUNCTION trg_employee_view_insert()
RETURNS TRIGGER AS $$
DECLARE
    v_dept_id INTEGER;
BEGIN
    -- 查找部门ID
    SELECT department_id INTO v_dept_id
    FROM departments
    WHERE department_name = NEW.department_name;
    
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Department % not found', NEW.department_name;
    END IF;
    
    -- 插入员工
    INSERT INTO employees(first_name, last_name, email, department_id, salary)
    VALUES(NEW.first_name, NEW.last_name, NEW.email, v_dept_id, NEW.salary);
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_employee_dept_view_insert
INSTEAD OF INSERT ON employee_department_view
FOR EACH ROW
EXECUTE FUNCTION trg_employee_view_insert();
```

### 3.5 STATEMENT 级触发器
```sql
CREATE OR REPLACE FUNCTION trg_log_bulk_update()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO bulk_operation_log(
        table_name, operation, row_count, executed_at, executed_by
    ) VALUES (
        TG_TABLE_NAME, TG_OP, 
        (SELECT COUNT(*) FROM employees WHERE updated_at > NOW() - INTERVAL '1 second'),
        NOW(), current_user
    );
    RETURN NULL;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_employees_bulk_update_log
AFTER UPDATE ON employees
FOR EACH STATEMENT
EXECUTE FUNCTION trg_log_bulk_update();
```

---

## 4. DO 块测试用例

### 4.1 简单 DO 块
```sql
DO $$
BEGIN
    RAISE NOTICE 'Hello, PostgreSQL!';
END;
$$;
```

### 4.2 带变量的 DO 块
```sql
DO $$
DECLARE
    v_count INTEGER;
    v_max_salary NUMERIC;
BEGIN
    SELECT COUNT(*), MAX(salary)
    INTO v_count, v_max_salary
    FROM employees;
    
    RAISE NOTICE 'Employee count: %, Max salary: %', v_count, v_max_salary;
END;
$$;
```

### 4.3 复杂 DO 块（带异常处理）
```sql
DO $$
DECLARE
    v_emp_id INTEGER := 100;
    v_salary NUMERIC;
    v_dept_name VARCHAR;
BEGIN
    SELECT e.salary, d.department_name
    INTO STRICT v_salary, v_dept_name
    FROM employees e
    JOIN departments d ON e.department_id = d.department_id
    WHERE e.employee_id = v_emp_id;
    
    RAISE NOTICE 'Employee % has salary % in department %', 
                 v_emp_id, v_salary, v_dept_name;
                 
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RAISE NOTICE 'Employee % not found', v_emp_id;
    WHEN TOO_MANY_ROWS THEN
        RAISE NOTICE 'Multiple records found for employee %', v_emp_id;
    WHEN OTHERS THEN
        RAISE NOTICE 'Error: %', SQLERRM;
END;
$$;
```

### 4.4 带命名标签的 DO 块
```sql
DO $migration$
DECLARE
    v_version INTEGER;
BEGIN
    -- 检查当前版本
    SELECT MAX(version) INTO v_version FROM schema_migrations;
    
    IF v_version IS NULL OR v_version < 10 THEN
        -- 执行迁移
        ALTER TABLE employees ADD COLUMN IF NOT EXISTS middle_name VARCHAR(50);
        ALTER TABLE employees ADD COLUMN IF NOT EXISTS suffix VARCHAR(10);
        
        INSERT INTO schema_migrations(version, applied_at)
        VALUES(10, NOW());
        
        RAISE NOTICE 'Migration to version 10 completed';
    ELSE
        RAISE NOTICE 'Already at version % or higher', v_version;
    END IF;
END;
$migration$;
```

---

## 5. 复杂查询测试用例（在函数中使用）

### 5.1 多表连接和窗口函数
```sql
CREATE OR REPLACE FUNCTION get_employee_ranking(
    p_dept_id INTEGER DEFAULT NULL
)
RETURNS TABLE (
    employee_id INTEGER,
    full_name VARCHAR,
    department_name VARCHAR,
    salary NUMERIC,
    dept_rank INTEGER,
    company_rank INTEGER,
    salary_percentile NUMERIC
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        e.employee_id,
        (e.first_name || ' ' || e.last_name)::VARCHAR,
        d.department_name,
        e.salary,
        RANK() OVER (PARTITION BY e.department_id ORDER BY e.salary DESC)::INTEGER,
        RANK() OVER (ORDER BY e.salary DESC)::INTEGER,
        ROUND(PERCENT_RANK() OVER (ORDER BY e.salary) * 100, 2)
    FROM employees e
    INNER JOIN departments d ON e.department_id = d.department_id
    WHERE p_dept_id IS NULL OR e.department_id = p_dept_id
    ORDER BY e.salary DESC;
END;
$$ LANGUAGE plpgsql;
```

### 5.2 递归 CTE
```sql
CREATE OR REPLACE FUNCTION get_org_hierarchy(
    p_manager_id INTEGER
)
RETURNS TABLE (
    level INTEGER,
    employee_id INTEGER,
    employee_name VARCHAR,
    manager_id INTEGER,
    path TEXT
) AS $$
BEGIN
    RETURN QUERY
    WITH RECURSIVE org_tree AS (
        -- 基础情况：起始员工
        SELECT 
            1 AS level,
            e.employee_id,
            (e.first_name || ' ' || e.last_name)::VARCHAR AS employee_name,
            e.manager_id,
            e.last_name::TEXT AS path
        FROM employees e
        WHERE e.employee_id = p_manager_id
        
        UNION ALL
        
        -- 递归情况：下属员工
        SELECT 
            ot.level + 1,
            e.employee_id,
            (e.first_name || ' ' || e.last_name)::VARCHAR,
            e.manager_id,
            ot.path || ' -> ' || e.last_name
        FROM employees e
        INNER JOIN org_tree ot ON e.manager_id = ot.employee_id
        WHERE ot.level < 10  -- 防止无限递归
    )
    SELECT * FROM org_tree
    ORDER BY level, employee_name;
END;
$$ LANGUAGE plpgsql;
```

### 5.3 LATERAL JOIN
```sql
CREATE OR REPLACE FUNCTION get_top_products_per_category(
    p_top_n INTEGER DEFAULT 3
)
RETURNS TABLE (
    category_id INTEGER,
    category_name VARCHAR,
    product_id INTEGER,
    product_name VARCHAR,
    total_sales NUMERIC,
    rank INTEGER
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        c.category_id,
        c.category_name,
        top_products.product_id,
        top_products.product_name,
        top_products.total_sales,
        top_products.rank::INTEGER
    FROM categories c
    CROSS JOIN LATERAL (
        SELECT 
            p.product_id,
            p.product_name,
            COALESCE(SUM(oi.quantity * oi.unit_price), 0) AS total_sales,
            ROW_NUMBER() OVER (ORDER BY COALESCE(SUM(oi.quantity * oi.unit_price), 0) DESC) AS rank
        FROM products p
        LEFT JOIN order_items oi ON p.product_id = oi.product_id
        WHERE p.category_id = c.category_id
        GROUP BY p.product_id, p.product_name
        ORDER BY total_sales DESC
        LIMIT p_top_n
    ) top_products
    ORDER BY c.category_name, top_products.rank;
END;
$$ LANGUAGE plpgsql;
```

### 5.4 JSON 操作
```sql
CREATE OR REPLACE FUNCTION get_order_as_json(
    p_order_id INTEGER
)
RETURNS JSONB AS $$
DECLARE
    v_result JSONB;
BEGIN
    SELECT jsonb_build_object(
        'order_id', o.order_id,
        'order_date', o.order_date,
        'status', o.status,
        'customer', jsonb_build_object(
            'customer_id', c.customer_id,
            'name', c.customer_name,
            'email', c.email
        ),
        'items', (
            SELECT jsonb_agg(jsonb_build_object(
                'product_id', p.product_id,
                'product_name', p.product_name,
                'quantity', oi.quantity,
                'unit_price', oi.unit_price,
                'line_total', oi.quantity * oi.unit_price
            ) ORDER BY oi.line_number)
            FROM order_items oi
            JOIN products p ON oi.product_id = p.product_id
            WHERE oi.order_id = o.order_id
        ),
        'total_amount', o.total_amount
    ) INTO v_result
    FROM orders o
    JOIN customers c ON o.customer_id = c.customer_id
    WHERE o.order_id = p_order_id;
    
    RETURN v_result;
END;
$$ LANGUAGE plpgsql;
```

### 5.5 数组操作
```sql
CREATE OR REPLACE FUNCTION find_employees_with_skills(
    p_required_skills TEXT[]
)
RETURNS TABLE (
    employee_id INTEGER,
    employee_name VARCHAR,
    skills TEXT[],
    matching_skills TEXT[],
    match_count INTEGER
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        e.employee_id,
        (e.first_name || ' ' || e.last_name)::VARCHAR,
        e.skills,
        ARRAY(
            SELECT unnest(e.skills) 
            INTERSECT 
            SELECT unnest(p_required_skills)
        ) AS matching_skills,
        (
            SELECT COUNT(*)::INTEGER
            FROM unnest(e.skills) s
            WHERE s = ANY(p_required_skills)
        ) AS match_count
    FROM employees e
    WHERE e.skills && p_required_skills  -- 数组重叠操作符
    ORDER BY match_count DESC, e.last_name;
END;
$$ LANGUAGE plpgsql;
```
