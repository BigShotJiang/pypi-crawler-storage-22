# TiDB 和 OceanBase 存储过程测试用例

## TiDB 测试用例

> TiDB 兼容 MySQL 语法，以下测试用例验证 TiDB 特有场景

### 1. CREATE FUNCTION 测试用例

#### 1.1 简单函数
```sql
CREATE FUNCTION tidb_get_version()
RETURNS VARCHAR(100)
DETERMINISTIC
BEGIN
    RETURN VERSION();
END
```

#### 1.2 带 TiDB Hint 的函数
```sql
CREATE FUNCTION get_user_orders(p_user_id BIGINT)
RETURNS INT
READS SQL DATA
BEGIN
    DECLARE order_count INT;
    SELECT /*+ USE_INDEX(orders, idx_user_id) */ COUNT(*)
    INTO order_count
    FROM orders
    WHERE user_id = p_user_id;
    RETURN order_count;
END
```

#### 1.3 使用 AUTO_RANDOM 表的函数
```sql
CREATE FUNCTION get_next_order_id()
RETURNS BIGINT
READS SQL DATA
BEGIN
    DECLARE next_id BIGINT;
    -- AUTO_RANDOM 表不需要手动生成 ID
    SELECT MAX(order_id) + 1 INTO next_id FROM orders;
    RETURN COALESCE(next_id, 1);
END
```

### 2. CREATE PROCEDURE 测试用例

#### 2.1 分布式事务存储过程
```sql
CREATE PROCEDURE transfer_between_regions(
    IN from_region VARCHAR(50),
    IN to_region VARCHAR(50),
    IN amount DECIMAL(15,2)
)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Transfer failed';
    END;
    
    START TRANSACTION;
    
    -- 从源区域扣款
    UPDATE regional_accounts
    SET balance = balance - amount
    WHERE region = from_region;
    
    -- 向目标区域入账
    UPDATE regional_accounts
    SET balance = balance + amount
    WHERE region = to_region;
    
    -- 记录跨区域交易
    INSERT INTO cross_region_transactions(
        from_region, to_region, amount, transaction_time
    ) VALUES (
        from_region, to_region, amount, NOW()
    );
    
    COMMIT;
END
```

#### 2.2 批量数据处理（分区表）
```sql
CREATE PROCEDURE archive_old_orders(
    IN cutoff_date DATE,
    IN batch_size INT
)
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE processed INT DEFAULT 0;
    
    WHILE NOT done DO
        -- 使用 LIMIT 分批处理
        INSERT INTO orders_archive
        SELECT * FROM orders
        WHERE order_date < cutoff_date
        LIMIT batch_size;
        
        SET processed = ROW_COUNT();
        
        IF processed > 0 THEN
            DELETE FROM orders
            WHERE order_date < cutoff_date
            LIMIT batch_size;
        ELSE
            SET done = TRUE;
        END IF;
        
        -- 每批次提交
        COMMIT;
    END WHILE;
END
```

#### 2.3 使用 TiDB 特有函数
```sql
CREATE PROCEDURE analyze_table_stats(
    IN table_name VARCHAR(100)
)
BEGIN
    -- TiDB 特有的统计信息分析
    SET @sql = CONCAT('ANALYZE TABLE ', table_name);
    PREPARE stmt FROM @sql;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
    
    -- 记录分析时间
    INSERT INTO stats_history(table_name, analyzed_at)
    VALUES(table_name, NOW());
END
```

### 3. CREATE TRIGGER 测试用例

#### 3.1 审计触发器
```sql
CREATE TRIGGER trg_user_audit
AFTER UPDATE ON users
FOR EACH ROW
BEGIN
    IF OLD.email != NEW.email OR OLD.phone != NEW.phone THEN
        INSERT INTO user_audit_log(
            user_id, field_changed, old_value, new_value, changed_at
        ) VALUES (
            NEW.user_id,
            CASE 
                WHEN OLD.email != NEW.email THEN 'email'
                ELSE 'phone'
            END,
            CASE 
                WHEN OLD.email != NEW.email THEN OLD.email
                ELSE OLD.phone
            END,
            CASE 
                WHEN OLD.email != NEW.email THEN NEW.email
                ELSE NEW.phone
            END,
            NOW()
        );
    END IF;
END
```

---

## OceanBase MySQL 模式测试用例

### 1. CREATE FUNCTION 测试用例

#### 1.1 简单函数
```sql
CREATE FUNCTION ob_mysql_get_tenant_id()
RETURNS BIGINT
DETERMINISTIC
BEGIN
    RETURN @@ob_tenant_id;
END
```

#### 1.2 带 OceanBase Hint 的函数
```sql
CREATE FUNCTION get_partition_data(p_partition_key INT)
RETURNS INT
READS SQL DATA
BEGIN
    DECLARE result INT;
    SELECT /*+ PARALLEL(4) */ COUNT(*)
    INTO result
    FROM partitioned_table
    WHERE partition_key = p_partition_key;
    RETURN result;
END
```

### 2. CREATE PROCEDURE 测试用例

#### 2.1 多租户数据处理
```sql
CREATE PROCEDURE sync_tenant_data(
    IN source_tenant_id BIGINT,
    IN target_tenant_id BIGINT
)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
    
    START TRANSACTION;
    
    -- 复制配置数据
    INSERT INTO tenant_config (tenant_id, config_key, config_value)
    SELECT target_tenant_id, config_key, config_value
    FROM tenant_config
    WHERE tenant_id = source_tenant_id
    ON DUPLICATE KEY UPDATE config_value = VALUES(config_value);
    
    COMMIT;
END
```

#### 2.2 分区表维护
```sql
CREATE PROCEDURE maintain_partitions(
    IN table_name VARCHAR(100),
    IN retention_days INT
)
BEGIN
    DECLARE partition_name VARCHAR(100);
    DECLARE partition_date DATE;
    DECLARE done INT DEFAULT FALSE;
    
    DECLARE partition_cursor CURSOR FOR
        SELECT partition_name, 
               STR_TO_DATE(partition_description, '%Y-%m-%d') AS partition_date
        FROM information_schema.partitions
        WHERE table_name = table_name
          AND partition_method = 'RANGE';
    
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    
    OPEN partition_cursor;
    
    partition_loop: LOOP
        FETCH partition_cursor INTO partition_name, partition_date;
        IF done THEN
            LEAVE partition_loop;
        END IF;
        
        IF partition_date < DATE_SUB(CURDATE(), INTERVAL retention_days DAY) THEN
            SET @drop_sql = CONCAT('ALTER TABLE ', table_name, 
                                   ' DROP PARTITION ', partition_name);
            PREPARE stmt FROM @drop_sql;
            EXECUTE stmt;
            DEALLOCATE PREPARE stmt;
        END IF;
    END LOOP;
    
    CLOSE partition_cursor;
END
```

---

## OceanBase Oracle 模式测试用例

### 1. CREATE FUNCTION 测试用例

#### 1.1 简单函数
```sql
CREATE FUNCTION ob_oracle_get_sysdate RETURN DATE AS
BEGIN
    RETURN SYSDATE;
END;
```

#### 1.2 带 OceanBase Hint 的函数
```sql
CREATE OR REPLACE FUNCTION get_table_row_count(
    p_table_name VARCHAR2
) RETURN NUMBER AS
    v_count NUMBER;
BEGIN
    EXECUTE IMMEDIATE 
        'SELECT /*+ PARALLEL(4) */ COUNT(*) FROM ' || p_table_name
        INTO v_count;
    RETURN v_count;
END;
```

#### 1.3 复杂业务函数
```sql
CREATE OR REPLACE FUNCTION calculate_commission(
    p_sales_amount NUMBER,
    p_sales_region VARCHAR2
) RETURN NUMBER AS
    v_commission NUMBER;
    v_rate NUMBER;
BEGIN
    -- 根据区域获取佣金率
    SELECT commission_rate INTO v_rate
    FROM region_commission_rates
    WHERE region_code = p_sales_region;
    
    -- 计算佣金（带阶梯）
    IF p_sales_amount <= 10000 THEN
        v_commission := p_sales_amount * v_rate;
    ELSIF p_sales_amount <= 50000 THEN
        v_commission := 10000 * v_rate + (p_sales_amount - 10000) * v_rate * 1.2;
    ELSE
        v_commission := 10000 * v_rate + 40000 * v_rate * 1.2 + 
                       (p_sales_amount - 50000) * v_rate * 1.5;
    END IF;
    
    RETURN v_commission;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RETURN 0;
END;
```

### 2. CREATE PROCEDURE 测试用例

#### 2.1 分布式数据同步
```sql
CREATE OR REPLACE PROCEDURE sync_distributed_data(
    p_source_zone VARCHAR2,
    p_target_zone VARCHAR2,
    p_batch_size NUMBER DEFAULT 1000
) AS
    v_processed NUMBER := 0;
    v_total NUMBER;
BEGIN
    -- 获取待同步数据量
    SELECT COUNT(*) INTO v_total
    FROM sync_queue
    WHERE source_zone = p_source_zone
      AND status = 'PENDING';
    
    -- 分批处理
    WHILE v_processed < v_total LOOP
        -- 处理一批数据
        FOR rec IN (
            SELECT * FROM sync_queue
            WHERE source_zone = p_source_zone
              AND status = 'PENDING'
              AND ROWNUM <= p_batch_size
            FOR UPDATE SKIP LOCKED
        ) LOOP
            -- 同步数据到目标区域
            INSERT INTO zone_data (zone_id, data_key, data_value, sync_time)
            VALUES (p_target_zone, rec.data_key, rec.data_value, SYSDATE);
            
            -- 更新同步状态
            UPDATE sync_queue
            SET status = 'COMPLETED',
                sync_time = SYSDATE
            WHERE queue_id = rec.queue_id;
            
            v_processed := v_processed + 1;
        END LOOP;
        
        COMMIT;
    END LOOP;
    
    DBMS_OUTPUT.PUT_LINE('Synced ' || v_processed || ' records');
END;
```

#### 2.2 多租户报表生成
```sql
CREATE OR REPLACE PROCEDURE generate_tenant_report(
    p_tenant_id NUMBER,
    p_report_date DATE,
    p_result OUT SYS_REFCURSOR
) AS
BEGIN
    OPEN p_result FOR
        WITH tenant_metrics AS (
            SELECT 
                metric_name,
                metric_value,
                RANK() OVER (PARTITION BY metric_category ORDER BY metric_value DESC) AS rank_in_category
            FROM tenant_daily_metrics
            WHERE tenant_id = p_tenant_id
              AND metric_date = p_report_date
        ),
        comparison AS (
            SELECT 
                m1.metric_name,
                m1.metric_value AS current_value,
                m2.metric_value AS previous_value,
                ROUND((m1.metric_value - m2.metric_value) / NULLIF(m2.metric_value, 0) * 100, 2) AS change_pct
            FROM tenant_daily_metrics m1
            LEFT JOIN tenant_daily_metrics m2 
                ON m1.tenant_id = m2.tenant_id
                AND m1.metric_name = m2.metric_name
                AND m2.metric_date = p_report_date - 1
            WHERE m1.tenant_id = p_tenant_id
              AND m1.metric_date = p_report_date
        )
        SELECT 
            tm.metric_name,
            tm.metric_value,
            tm.rank_in_category,
            c.previous_value,
            c.change_pct
        FROM tenant_metrics tm
        JOIN comparison c ON tm.metric_name = c.metric_name
        ORDER BY tm.rank_in_category;
END;
```

### 3. CREATE PACKAGE 测试用例

#### 3.1 租户管理包
```sql
CREATE OR REPLACE PACKAGE tenant_mgmt AS
    -- 常量
    c_max_users_per_tenant CONSTANT NUMBER := 10000;
    c_default_quota CONSTANT NUMBER := 1073741824; -- 1GB
    
    -- 类型
    TYPE tenant_info_rec IS RECORD (
        tenant_id NUMBER,
        tenant_name VARCHAR2(100),
        user_count NUMBER,
        storage_used NUMBER
    );
    
    -- 过程声明
    PROCEDURE create_tenant(
        p_tenant_name VARCHAR2,
        p_admin_email VARCHAR2,
        p_quota NUMBER DEFAULT c_default_quota
    );
    
    PROCEDURE suspend_tenant(p_tenant_id NUMBER);
    
    PROCEDURE activate_tenant(p_tenant_id NUMBER);
    
    -- 函数声明
    FUNCTION get_tenant_info(p_tenant_id NUMBER) RETURN tenant_info_rec;
    
    FUNCTION get_tenant_usage_pct(p_tenant_id NUMBER) RETURN NUMBER;
    
END tenant_mgmt;
```

#### 3.2 租户管理包体
```sql
CREATE OR REPLACE PACKAGE BODY tenant_mgmt AS
    
    PROCEDURE create_tenant(
        p_tenant_name VARCHAR2,
        p_admin_email VARCHAR2,
        p_quota NUMBER DEFAULT c_default_quota
    ) AS
        v_tenant_id NUMBER;
    BEGIN
        -- 创建租户
        INSERT INTO tenants(tenant_name, status, quota, created_at)
        VALUES(p_tenant_name, 'ACTIVE', p_quota, SYSDATE)
        RETURNING tenant_id INTO v_tenant_id;
        
        -- 创建管理员用户
        INSERT INTO tenant_users(tenant_id, email, role, created_at)
        VALUES(v_tenant_id, p_admin_email, 'ADMIN', SYSDATE);
        
        -- 初始化租户配置
        INSERT INTO tenant_config(tenant_id, config_key, config_value)
        SELECT v_tenant_id, default_key, default_value
        FROM default_tenant_config;
        
        COMMIT;
    END create_tenant;
    
    PROCEDURE suspend_tenant(p_tenant_id NUMBER) AS
    BEGIN
        UPDATE tenants
        SET status = 'SUSPENDED',
            suspended_at = SYSDATE
        WHERE tenant_id = p_tenant_id;
        COMMIT;
    END suspend_tenant;
    
    PROCEDURE activate_tenant(p_tenant_id NUMBER) AS
    BEGIN
        UPDATE tenants
        SET status = 'ACTIVE',
            suspended_at = NULL
        WHERE tenant_id = p_tenant_id;
        COMMIT;
    END activate_tenant;
    
    FUNCTION get_tenant_info(p_tenant_id NUMBER) RETURN tenant_info_rec AS
        v_info tenant_info_rec;
    BEGIN
        SELECT tenant_id, tenant_name,
               (SELECT COUNT(*) FROM tenant_users WHERE tenant_id = t.tenant_id),
               (SELECT COALESCE(SUM(storage_used), 0) FROM tenant_storage WHERE tenant_id = t.tenant_id)
        INTO v_info.tenant_id, v_info.tenant_name, v_info.user_count, v_info.storage_used
        FROM tenants t
        WHERE tenant_id = p_tenant_id;
        
        RETURN v_info;
    END get_tenant_info;
    
    FUNCTION get_tenant_usage_pct(p_tenant_id NUMBER) RETURN NUMBER AS
        v_quota NUMBER;
        v_used NUMBER;
    BEGIN
        SELECT quota INTO v_quota FROM tenants WHERE tenant_id = p_tenant_id;
        SELECT COALESCE(SUM(storage_used), 0) INTO v_used 
        FROM tenant_storage WHERE tenant_id = p_tenant_id;
        
        RETURN ROUND(v_used / v_quota * 100, 2);
    END get_tenant_usage_pct;
    
END tenant_mgmt;
```

---

## 复杂查询场景（跨数据库通用）

### 多层嵌套子查询
```sql
-- 适用于所有数据库
CREATE PROCEDURE get_top_performers(
    IN/p_year INT/NUMBER,
    IN/p_limit INT/NUMBER
)
BEGIN/AS
    SELECT 
        e.employee_id,
        e.first_name,
        e.last_name,
        dept_stats.department_name,
        emp_stats.total_sales,
        emp_stats.sales_rank
    FROM employees e
    INNER JOIN (
        SELECT 
            s.employee_id,
            SUM(s.amount) AS total_sales,
            RANK() OVER (ORDER BY SUM(s.amount) DESC) AS sales_rank
        FROM sales s
        WHERE YEAR(s.sale_date) = p_year
        GROUP BY s.employee_id
        HAVING SUM(s.amount) > (
            SELECT AVG(annual_sales)
            FROM (
                SELECT employee_id, SUM(amount) AS annual_sales
                FROM sales
                WHERE YEAR(sale_date) = p_year
                GROUP BY employee_id
            ) avg_sales
        )
    ) emp_stats ON e.employee_id = emp_stats.employee_id
    INNER JOIN (
        SELECT 
            d.department_id,
            d.department_name,
            COUNT(e2.employee_id) AS emp_count
        FROM departments d
        LEFT JOIN employees e2 ON d.department_id = e2.department_id
        GROUP BY d.department_id, d.department_name
    ) dept_stats ON e.department_id = dept_stats.department_id
    WHERE emp_stats.sales_rank <= p_limit
    ORDER BY emp_stats.sales_rank;
END;
```

### 递归层次查询
```sql
-- MySQL/TiDB 版本 (CTE)
WITH RECURSIVE category_tree AS (
    SELECT category_id, category_name, parent_id, 1 AS level,
           CAST(category_name AS CHAR(1000)) AS path
    FROM categories
    WHERE parent_id IS NULL
    
    UNION ALL
    
    SELECT c.category_id, c.category_name, c.parent_id, ct.level + 1,
           CONCAT(ct.path, ' > ', c.category_name)
    FROM categories c
    INNER JOIN category_tree ct ON c.parent_id = ct.category_id
    WHERE ct.level < 10
)
SELECT * FROM category_tree ORDER BY path;

-- Oracle/OceanBase-Oracle 版本 (CONNECT BY)
SELECT 
    LEVEL AS hierarchy_level,
    category_id,
    category_name,
    parent_id,
    SYS_CONNECT_BY_PATH(category_name, ' > ') AS path
FROM categories
START WITH parent_id IS NULL
CONNECT BY PRIOR category_id = parent_id
ORDER SIBLINGS BY category_name;
```
