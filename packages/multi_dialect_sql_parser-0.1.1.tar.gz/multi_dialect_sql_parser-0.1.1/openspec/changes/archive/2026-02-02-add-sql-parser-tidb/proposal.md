# Change: SQL 解析器 TiDB 方言支持

## Why
TiDB 兼容 MySQL 语法，但有一些特有扩展（如 TiDB 特有 Hint、分区表语法）。需要创建自定义方言继承 MySQL 并处理这些扩展。

## What Changes
- 创建 TiDB 自定义方言（继承 MySQL）
- 处理 TiDB 特有 Hint 语法
- 处理 TiDB 特有函数和表达式

## Impact
- Affected specs: sql-parser-tidb (新建)
- Affected code: sql_parser/dialects/tidb.py
- 依赖: add-sql-parser-core
