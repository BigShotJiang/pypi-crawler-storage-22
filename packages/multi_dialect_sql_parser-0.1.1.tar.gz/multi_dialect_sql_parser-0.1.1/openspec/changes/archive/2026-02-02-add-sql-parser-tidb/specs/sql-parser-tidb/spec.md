## ADDED Requirements

### Requirement: TiDB 方言支持
系统 SHALL 支持 TiDB 语法解析，基于 MySQL 方言扩展。

#### Scenario: MySQL 兼容语法
- **WHEN** SQL 使用标准 MySQL 语法
- **THEN** 正确解析（继承 MySQL 方言能力）

#### Scenario: TiDB Hint 解析
- **WHEN** SQL 包含 TiDB 特有 Hint（如 /*+ USE_INDEX(t, idx) */）
- **THEN** 正确识别 Hint 类型和参数

#### Scenario: TiDB 读写分离 Hint
- **WHEN** SQL 包含 /*+ READ_FROM_STORAGE(tiflash[t]) */
- **THEN** 正确识别存储引擎指定

#### Scenario: TiDB 分区表语法
- **WHEN** DDL 包含 TiDB 分区语法（PARTITION BY RANGE/HASH）
- **THEN** 正确识别分区类型和分区键

#### Scenario: TiDB 特有函数
- **WHEN** SQL 包含 TiDB 特有函数（如 TIDB_VERSION()）
- **THEN** 正确识别为 TiDB 系统函数

#### Scenario: TiDB AUTO_RANDOM
- **WHEN** DDL 包含 AUTO_RANDOM 属性
- **THEN** 正确识别为 TiDB 自动随机 ID

---

### Requirement: TiDB 自定义方言实现
系统 SHALL 通过继承 MySQL 方言实现 TiDB 支持。

#### Scenario: 方言继承
- **WHEN** 指定 dialect="tidb"
- **THEN** 使用 TiDB 自定义方言类（继承 MySQL）

#### Scenario: 方言注册
- **WHEN** 解析器初始化
- **THEN** TiDB 方言已注册到 SQLGlot 方言系统
