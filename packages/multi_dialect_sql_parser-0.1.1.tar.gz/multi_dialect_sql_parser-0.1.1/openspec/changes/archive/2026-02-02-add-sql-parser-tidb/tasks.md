## 1. TiDB 自定义方言创建
- [x] 1.1 创建 TiDB 方言类（继承 sqlglot.dialects.mysql.MySQL）
- [x] 1.2 注册 TiDB 方言到 SQLGlot
- [x] 1.3 验证 MySQL 兼容语法正常工作

## 2. TiDB Hint 解析
- [x] 2.1 扩展 Tokenizer 识别 TiDB Hint 语法
- [x] 2.2 实现 USE_INDEX Hint 解析
- [x] 2.3 实现 READ_FROM_STORAGE Hint 解析
- [x] 2.4 实现其他常用 Hint 解析

## 3. TiDB 特有语法
- [x] 3.1 实现 AUTO_RANDOM 属性识别
- [x] 3.2 实现 TiDB 分区表语法解析
- [x] 3.3 实现 TiDB 特有函数识别

## 4. 测试
- [x] 4.1 MySQL 兼容语法测试
- [x] 4.2 TiDB Hint 解析测试
- [x] 4.3 TiDB 特有语法测试
