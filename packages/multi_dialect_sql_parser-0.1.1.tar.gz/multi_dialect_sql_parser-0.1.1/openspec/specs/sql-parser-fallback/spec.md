# sql-parser-fallback Specification

## Purpose
TBD - created by archiving change add-sql-parser-fallback. Update Purpose after archive.
## Requirements
### Requirement: 不支持方言处理
系统 SHALL 优雅处理不支持的数据库方言。

#### Scenario: 未知方言指定
- **WHEN** 指定不支持的方言（如 dialect="db2"）
- **THEN** 返回错误信息，列出支持的方言列表

#### Scenario: 方言自动检测失败
- **WHEN** 无法自动检测 SQL 方言
- **THEN** 使用通用 SQL 解析器尝试解析，标记方言为 "unknown"

---

### Requirement: 不支持语法处理
系统 SHALL 优雅处理支持方言中的不支持语法。

#### Scenario: 存储过程/函数体
- **WHEN** SQL 包含存储过程或函数定义体
- **THEN** 标记为 "unsupported_syntax"，提取可识别的部分（如过程名）

#### Scenario: 数据库特有扩展
- **WHEN** SQL 包含数据库特有扩展语法（如 MySQL 的 HANDLER 语句）
- **THEN** 标记为 "dialect_specific_unsupported"，记录原始 SQL

#### Scenario: 复杂嵌套结构
- **WHEN** SQL 嵌套层级过深导致解析失败
- **THEN** 返回部分解析结果，标记未解析部分

---

### Requirement: 语法错误处理
系统 SHALL 优雅处理语法错误的 SQL，并精确定位错误位置。

#### Scenario: 语法错误定位
- **WHEN** SQL 存在语法错误
- **THEN** 返回错误位置（行号、列号、字符偏移量）和错误描述

#### Scenario: 部分解析
- **WHEN** SQL 前半部分正确，后半部分有错误
- **THEN** 返回前半部分的解析结果，标记错误位置

#### Scenario: 多语句部分失败
- **WHEN** 批量 SQL 中部分语句有错误
- **THEN** 成功语句正常返回，失败语句返回错误信息，不中断整体解析

---

### Requirement: 错误位置精确定位
系统 SHALL 提供精确的错误位置信息。

#### Scenario: 行号定位
- **WHEN** SQL 存在语法错误
- **THEN** 返回错误所在行号（从 1 开始）

#### Scenario: 列号定位
- **WHEN** SQL 存在语法错误
- **THEN** 返回错误所在列号（从 1 开始）

#### Scenario: 字符偏移量
- **WHEN** SQL 存在语法错误
- **THEN** 返回错误在原始 SQL 中的字符偏移量（从 0 开始）

#### Scenario: 错误上下文
- **WHEN** SQL 存在语法错误
- **THEN** 返回错误位置前后的 SQL 片段（上下文），便于定位

#### Scenario: 错误标记显示
- **WHEN** SQL 存在语法错误
- **THEN** 返回带有错误标记的 SQL 文本（如用 ^^^ 标记错误位置）

---

### Requirement: 语义错误检测
系统 SHALL 检测常见的语义错误（在语法正确的前提下）。

#### Scenario: 列名歧义
- **WHEN** 多表查询中列名未指定表前缀且存在歧义
- **THEN** 标记为 "ambiguous_column" 警告

#### Scenario: 未知列引用
- **WHEN** WHERE/SELECT 中引用的列名不在 FROM 表中
- **THEN** 标记为 "unknown_column" 警告（仅当可检测时）

#### Scenario: 聚合函数误用
- **WHEN** SELECT 中混合聚合函数和非聚合列，但缺少 GROUP BY
- **THEN** 标记为 "missing_group_by" 警告

#### Scenario: 子查询列数不匹配
- **WHEN** IN 子查询返回多列
- **THEN** 标记为 "subquery_column_mismatch" 错误

---

### Requirement: 降级策略配置
系统 SHALL 支持配置降级策略。

#### Scenario: 严格模式
- **WHEN** 配置 strict_mode=True
- **THEN** 遇到任何不支持语法立即抛出异常

#### Scenario: 宽松模式
- **WHEN** 配置 strict_mode=False（默认）
- **THEN** 尽可能解析，返回部分结果和警告

#### Scenario: 错误收集
- **WHEN** 解析完成
- **THEN** ParseResult.errors 包含所有遇到的问题

---

### Requirement: 未知语法标记
系统 SHALL 标记无法识别的语法元素。

#### Scenario: 未知函数
- **WHEN** SQL 包含无法识别的函数
- **THEN** 标记为 "unknown_function"，保留函数名和参数

#### Scenario: 未知表达式
- **WHEN** SQL 包含无法解析的表达式
- **THEN** 标记为 "unknown_expression"，保留原始文本

#### Scenario: 未知子句
- **WHEN** SQL 包含无法识别的子句
- **THEN** 标记为 "unknown_clause"，保留原始文本

