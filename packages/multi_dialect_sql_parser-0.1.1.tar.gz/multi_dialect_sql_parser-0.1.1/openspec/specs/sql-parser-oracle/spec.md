# sql-parser-oracle Specification

## Purpose
TBD - created by archiving change add-sql-parser-oracle. Update Purpose after archive.
## Requirements
### Requirement: Oracle 方言支持
系统 SHALL 支持 Oracle 语法解析。

#### Scenario: Oracle 标识符解析
- **WHEN** SQL 包含双引号标识符（如 "TABLE_NAME"）
- **THEN** 正确识别并提取表名（Oracle 默认大写）

#### Scenario: Oracle ROWNUM 解析
- **WHEN** SQL 包含 ROWNUM 伪列
- **THEN** 正确识别为行号限制条件

#### Scenario: Oracle CONNECT BY 解析
- **WHEN** SQL 包含 CONNECT BY 层次查询
- **THEN** 正确识别层次关系（START WITH、CONNECT BY PRIOR）

#### Scenario: Oracle (+) 外连接
- **WHEN** SQL 包含 (+) 外连接语法
- **THEN** 正确识别为 LEFT/RIGHT OUTER JOIN

#### Scenario: Oracle 序列
- **WHEN** SQL 包含 sequence.NEXTVAL 或 sequence.CURRVAL
- **THEN** 正确识别序列引用

#### Scenario: Oracle DUAL 表
- **WHEN** SQL 查询 DUAL 表
- **THEN** 正确识别为系统虚拟表

#### Scenario: Oracle 分析函数
- **WHEN** SQL 包含 OVER (PARTITION BY ... ORDER BY ...)
- **THEN** 正确识别窗口函数和分区

#### Scenario: Oracle DECODE 函数
- **WHEN** SQL 包含 DECODE 函数
- **THEN** 正确识别为条件表达式

#### Scenario: Oracle NVL/NVL2 函数
- **WHEN** SQL 包含 NVL 或 NVL2 函数
- **THEN** 正确识别为空值处理函数

#### Scenario: Oracle MERGE 语句
- **WHEN** SQL 为 MERGE INTO 语句
- **THEN** 正确提取目标表、源表、匹配条件、更新/插入操作

