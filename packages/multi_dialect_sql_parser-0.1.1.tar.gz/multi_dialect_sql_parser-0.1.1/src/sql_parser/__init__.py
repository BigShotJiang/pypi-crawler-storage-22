# -*- coding: utf-8 -*-
"""SQL 解析器包。

支持多种数据库方言的 SQL 解析，包括：
- MySQL
- PostgreSQL
- Oracle
- TiDB
- OceanBase (MySQL/Oracle 模式)

特性：
- 多进程批量解析
- 流式返回结果
- 精确错误位置定位
- 预处理 SQLGlot 不支持的语法
"""
from sql_parser.parser import SQLParser
from sql_parser.models import (
    ParseResult,
    BatchParseResult,
    TableReference,
    ColumnReference,
    ConditionNode,
    JoinInfo,
    OrderByItem,
    ParseError,
    OracleSpecificInfo,
    TiDBSpecificInfo,
    TiDBHint,
    OceanBaseSpecificInfo,
    OceanBaseHint,
)
from sql_parser.constants import SUPPORTED_DIALECTS

__all__ = [
    "SQLParser",
    "ParseResult",
    "BatchParseResult",
    "TableReference",
    "ColumnReference",
    "ConditionNode",
    "JoinInfo",
    "OrderByItem",
    "ParseError",
    "OracleSpecificInfo",
    "TiDBSpecificInfo",
    "TiDBHint",
    "OceanBaseSpecificInfo",
    "OceanBaseHint",
    "SUPPORTED_DIALECTS",
]

__version__ = "0.1.1"
