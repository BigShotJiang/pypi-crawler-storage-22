# -*- coding: utf-8 -*-
"""SQL 解析器常量定义。"""
from __future__ import annotations

import os
from typing import Dict, Set

# 配置常量
MAX_WORKERS = min(os.cpu_count() or 4, 8)  # 最大进程数，基于 CPU 核心数，上限 8
BATCH_SIZE = 1000  # 每批处理的 SQL 数量
MAX_TASKS_PER_CHILD = 100  # 子进程处理任务数上限，超过后重启以释放内存

# 支持的数据库方言集合（O(1) 查找）
SUPPORTED_DIALECTS: Set[str] = {
    "mysql",
    "postgresql",
    "oracle",
    "tidb",
    "oceanbase-mysql",
    "oceanbase-oracle",
}

# 方言映射表：将用户指定的方言映射到 SQLGlot 支持的方言名
DIALECT_MAP: Dict[str, str] = {
    "mysql": "mysql",
    "postgresql": "postgres",
    "oracle": "oracle",
    "tidb": "mysql",  # TiDB 兼容 MySQL 语法
    "oceanbase-mysql": "mysql",  # OceanBase MySQL 模式
    "oceanbase-oracle": "oracle",  # OceanBase Oracle 模式
}

# SQL 语句类型映射表
STATEMENT_TYPE_MAP: Dict[str, str] = {
    "Select": "SELECT",
    "Insert": "INSERT",
    "Update": "UPDATE",
    "Delete": "DELETE",
    "Create": "CREATE",
    "Alter": "ALTER",
    "Drop": "DROP",
    "Merge": "MERGE",
    "Truncate": "TRUNCATE",
    # 集合操作（UNION/INTERSECT/EXCEPT）本质上是 SELECT 查询
    "Union": "SELECT",
    "Intersect": "SELECT",
    "Except": "SELECT",
    # TRUNCATE TABLE
    "TruncateTable": "TRUNCATE",
    # Oracle INSERT ALL/FIRST
    "MultitableInserts": "INSERT",
}

# Oracle 函数分类映射
ORACLE_FUNCTIONS: Dict[str, str] = {
    "NVL": "null_handling",
    "NVL2": "null_handling",
    "DECODE": "conditional",
    "ROWNUM": "pseudo_column",
    "ROWID": "pseudo_column",
    "SYSDATE": "datetime",
    "SYSTIMESTAMP": "datetime",
    "TO_DATE": "conversion",
    "TO_CHAR": "conversion",
    "TO_NUMBER": "conversion",
}

# Oracle 伪列集合
ORACLE_PSEUDO_COLUMNS: Set[str] = {
    "ROWNUM", "ROWID", "LEVEL", 
    "CONNECT_BY_ISLEAF", "CONNECT_BY_ISCYCLE",
}

# TiDB Hint 类型映射
TIDB_HINTS: Dict[str, str] = {
    "USE_INDEX": "index_hint",
    "USE_INDEX_MERGE": "index_hint",
    "IGNORE_INDEX": "index_hint",
    "READ_FROM_STORAGE": "storage_hint",
    "TIDB_SMJ": "join_hint",
    "TIDB_HJ": "join_hint",
    "TIDB_INLJ": "join_hint",
    "HASH_AGG": "agg_hint",
    "STREAM_AGG": "agg_hint",
    "NO_INDEX_MERGE": "index_hint",
    "INL_JOIN": "join_hint",
    "INL_HASH_JOIN": "join_hint",
    "MERGE_JOIN": "join_hint",
    "HASH_JOIN": "join_hint",
}

# OceanBase Hint 类型映射
OCEANBASE_HINTS: Dict[str, str] = {
    "PARALLEL": "parallel_hint",
    "USE_HASH": "join_hint",
    "USE_MERGE": "join_hint",
    "USE_NL": "join_hint",
    "LEADING": "join_order_hint",
    "ORDERED": "join_order_hint",
    "INDEX": "index_hint",
    "FULL": "scan_hint",
    "NO_REWRITE": "optimizer_hint",
    "USE_PLAN_CACHE": "cache_hint",
    "NO_USE_PLAN_CACHE": "cache_hint",
}

# TiDB 特有关键字（SQLGlot 不支持）
TIDB_KEYWORDS: Set[str] = {
    "AUTO_RANDOM",
    "SHARD_ROW_ID_BITS",
    "PRE_SPLIT_REGIONS",
    "CLUSTERED",
    "NONCLUSTERED",
}

# OceanBase 特有关键字
OCEANBASE_KEYWORDS: Set[str] = {
    "TABLEGROUP",
    "LOCALITY",
    "REPLICA_NUM",
    "PRIMARY_ZONE",
}
