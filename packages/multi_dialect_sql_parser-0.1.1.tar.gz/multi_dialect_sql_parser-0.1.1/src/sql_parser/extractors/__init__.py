"""SQL 信息提取器模块。"""
from dataclasses import asdict

from sql_parser.extractors.base import BaseExtractor
from sql_parser.extractors.oracle import OracleExtractor
from sql_parser.extractors.tidb import TiDBExtractor
from sql_parser.extractors.oceanbase import OceanBaseExtractor


def procedural_info_to_dict(procedural_info) -> dict | None:
    """将 ProceduralInfo 转换为字典（共享辅助函数）。
    
    Args:
        procedural_info: 过程化信息对象
    
    Returns:
        字典形式的过程化信息，None 输入返回 None
    """
    if procedural_info is None:
        return None
    return asdict(procedural_info)


__all__ = [
    "BaseExtractor",
    "OracleExtractor",
    "TiDBExtractor",
    "OceanBaseExtractor",
    "procedural_info_to_dict",
]
