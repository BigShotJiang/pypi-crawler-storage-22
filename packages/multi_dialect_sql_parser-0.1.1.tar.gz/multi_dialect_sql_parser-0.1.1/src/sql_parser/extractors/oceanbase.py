"""OceanBase 特有信息提取器。"""
from __future__ import annotations

from typing import Dict, List, Optional, Any

import re
from dataclasses import asdict

from sql_parser.constants import OCEANBASE_HINTS


# OceanBase Hint 正则表达式（模块级预编译）
_RE_OCEANBASE_HINT = re.compile(r'/\*\+\s*(\w+)\s*(?:\(([^)]*)\))?\s*\*/', re.IGNORECASE)


class OceanBaseExtractor:
    """OceanBase 特有信息提取器。"""
    
    __slots__ = ()  # 无实例属性
    
    @staticmethod
    def extract(sql: str, dialect: str, preprocessed: bool = False, procedural_info=None) -> Optional[Dict[str, Any]]:
        """提取 OceanBase 特有信息。
        
        Args:
            sql: SQL 语句
            dialect: 方言
            preprocessed: 是否经过预处理
            procedural_info: 过程化对象信息
        
        Returns:
            OceanBase 特有信息字典，非 OceanBase 方言返回 None
        """
        if dialect not in ("oceanbase-mysql", "oceanbase-oracle"):
            return None
        
        # 使用 asdict 转换 procedural_info
        proc_info_dict = asdict(procedural_info) if procedural_info else None
        
        return {
            "mode": "mysql" if dialect == "oceanbase-mysql" else "oracle",
            "hints": OceanBaseExtractor._extract_hints(sql),
            "preprocessed": preprocessed,
            "procedural_info": proc_info_dict,
        }
    
    @staticmethod
    def _extract_hints(sql: str) -> List[Dict[str, Any]]:
        """提取 OceanBase Hint 信息。
        
        Args:
            sql: SQL 语句
        
        Returns:
            Hint 列表
        """
        return [
            {
                "name": (hint_name := match.group(1).upper()),
                "type": OCEANBASE_HINTS.get(hint_name, "unknown"),
                "args": match.group(2).strip() if match.group(2) else "",
            }
            for match in _RE_OCEANBASE_HINT.finditer(sql)
        ]
