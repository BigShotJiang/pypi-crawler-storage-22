"""Oracle 特有信息提取器。"""
from __future__ import annotations

from typing import Dict, List, Optional, Any

from dataclasses import asdict

from sqlglot import exp

from sql_parser.constants import ORACLE_PSEUDO_COLUMNS


class OracleExtractor:
    """Oracle 特有信息提取器。"""
    
    __slots__ = ()  # 无实例属性
    
    @staticmethod
    def extract(ast, sql: str, dialect: str, procedural_info=None) -> Optional[Dict[str, Any]]:
        """提取 Oracle 特有信息。
        
        Args:
            ast: SQL AST
            sql: 原始 SQL
            dialect: 方言
            procedural_info: 过程化对象信息
        
        Returns:
            Oracle 特有信息字典，非 Oracle 方言返回 None
        """
        if dialect not in ("oracle", "oceanbase-oracle"):
            return None
        
        # 使用 asdict 转换 procedural_info
        proc_info_dict = asdict(procedural_info) if procedural_info else None
        
        oracle_info = {
            "hierarchy": None,
            "sequences": [],
            "pseudo_columns": [],
            "merge_info": None,
            "plsql_info": None,  # 兼容旧版
            "procedural_info": proc_info_dict,
        }
        
        # 如果 AST 为空（解析失败），只返回过程化信息
        if ast is None:
            return oracle_info
        
        # 提取伪列
        oracle_info["pseudo_columns"] = OracleExtractor._extract_pseudo_columns(ast)
        
        # 提取序列引用
        oracle_info["sequences"] = OracleExtractor._extract_sequences(ast)
        
        # 提取层次查询信息
        oracle_info["hierarchy"] = OracleExtractor._extract_hierarchy(ast, sql)
        
        # 提取 MERGE 语句信息
        oracle_info["merge_info"] = OracleExtractor._extract_merge_info(ast)
        
        return oracle_info
    
    @staticmethod
    def _extract_pseudo_columns(ast) -> list[str]:
        """提取伪列使用。
        
        Args:
            ast: SQL AST
        
        Returns:
            伪列名称列表
        """
        pseudo_columns = []
        for col in ast.find_all(exp.Column):
            col_name = col.name.upper() if col.name else ""
            if col_name in ORACLE_PSEUDO_COLUMNS:
                if col_name not in pseudo_columns:
                    pseudo_columns.append(col_name)
        return pseudo_columns
    
    @staticmethod
    def _extract_sequences(ast) -> list[str]:
        """提取序列引用。
        
        Args:
            ast: SQL AST
        
        Returns:
            序列名称列表
        """
        sequences = []
        sql_text = str(ast).upper()
        
        if ".NEXTVAL" in sql_text or ".CURRVAL" in sql_text:
            for node in ast.walk():
                node_str = str(node).upper()
                if ".NEXTVAL" in node_str:
                    seq_name = node_str.split(".NEXTVAL")[0].split()[-1]
                    if seq_name and seq_name not in sequences:
                        sequences.append(seq_name)
                elif ".CURRVAL" in node_str:
                    seq_name = node_str.split(".CURRVAL")[0].split()[-1]
                    if seq_name and seq_name not in sequences:
                        sequences.append(seq_name)
        
        return sequences
    
    @staticmethod
    def _extract_hierarchy(ast, sql: str) -> Optional[Dict[str, Any]]:
        """提取层次查询信息。
        
        Args:
            ast: SQL AST
            sql: 原始 SQL
        
        Returns:
            层次查询信息字典
        """
        connect_by = ast.find(exp.Connect)
        if connect_by:
            hierarchy = {
                "connect_by": str(connect_by),
            }
            start_with = ast.find(exp.Where)
            if start_with and "START WITH" in sql.upper():
                hierarchy["start_with"] = str(start_with)
            return hierarchy
        return None
    
    @staticmethod
    def _extract_merge_info(ast) -> Optional[Dict[str, Any]]:
        """提取 MERGE 语句信息。
        
        Args:
            ast: SQL AST
        
        Returns:
            MERGE 信息字典
        """
        merge = ast.find(exp.Merge)
        if merge:
            return {
                "target_table": str(merge.this) if merge.this else None,
                "source": str(merge.using) if hasattr(merge, "using") and merge.using else None,
            }
        return None
