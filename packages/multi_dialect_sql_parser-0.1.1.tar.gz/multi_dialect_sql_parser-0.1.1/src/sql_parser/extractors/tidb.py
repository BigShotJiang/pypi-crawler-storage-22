"""TiDB 特有信息提取器。"""
from __future__ import annotations

from typing import Dict, List, Optional, Any

import re
from dataclasses import asdict

from sql_parser.constants import TIDB_HINTS


# TiDB Hint 正则表达式（模块级预编译）
_RE_TIDB_HINT = re.compile(r'/\*\+\s*(\w+)\s*\(([^)]*)\)\s*\*/', re.IGNORECASE)

# AUTO_RANDOM 正则表达式（模块级预编译）
_RE_AUTO_RANDOM = re.compile(r'(\w+)\s+\w+\s+AUTO_RANDOM', re.IGNORECASE)


class TiDBExtractor:
    """TiDB 特有信息提取器。"""
    
    __slots__ = ()  # 无实例属性
    
    @staticmethod
    def extract(sql: str, dialect: str, preprocessed: bool = False, procedural_info=None) -> Optional[Dict[str, Any]]:
        """提取 TiDB 特有信息。
        
        Args:
            sql: SQL 语句
            dialect: 方言
            preprocessed: 是否经过预处理
            procedural_info: 过程化对象信息
        
        Returns:
            TiDB 特有信息字典，非 TiDB 方言返回 None
        """
        if dialect != "tidb":
            return None
        
        # 使用 asdict 转换 procedural_info
        proc_info_dict = asdict(procedural_info) if procedural_info else None
        
        return {
            "hints": TiDBExtractor._extract_hints(sql),
            "auto_random_columns": TiDBExtractor._extract_auto_random(sql),
            "preprocessed": preprocessed,
            "procedural_info": proc_info_dict,
        }
    
    @staticmethod
    def _extract_hints(sql: str) -> List[Dict[str, Any]]:
        """提取 TiDB Hint 信息。
        
        Args:
            sql: SQL 语句
        
        Returns:
            Hint 列表
        """
        return [
            {
                "name": (hint_name := match.group(1).upper()),
                "type": TIDB_HINTS.get(hint_name, "unknown"),
                "args": match.group(2).strip(),
            }
            for match in _RE_TIDB_HINT.finditer(sql)
        ]
    
    @staticmethod
    def _extract_auto_random(sql: str) -> list[str]:
        """提取 AUTO_RANDOM 列。
        
        Args:
            sql: SQL 语句
        
        Returns:
            AUTO_RANDOM 列名列表
        """
        if "AUTO_RANDOM" not in sql.upper():
            return []
        return [match.group(1) for match in _RE_AUTO_RANDOM.finditer(sql)]
