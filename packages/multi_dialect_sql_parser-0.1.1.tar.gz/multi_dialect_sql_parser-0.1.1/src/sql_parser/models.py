# -*- coding: utf-8 -*-
"""SQL 解析器数据模型定义。"""
from __future__ import annotations

from typing import List, Optional, Dict, Any, Literal

from pydantic import BaseModel, Field


class ParameterInfo(BaseModel):
    """参数信息。"""
    name: str  # 参数名
    mode: str = "IN"  # IN | OUT | INOUT
    datatype: str = ""  # 数据类型
    default_value: Optional[str] = None  # 默认值


class ProceduralInfo(BaseModel):
    """过程化对象信息（通用模型）。"""
    
    # 对象类型
    type: Literal[
        "FUNCTION",           # 函数
        "PROCEDURE",          # 存储过程
        "PACKAGE",            # 包（Oracle）
        "PACKAGE_BODY",       # 包体（Oracle）
        "TRIGGER",            # 触发器
        "ANONYMOUS_BLOCK",    # 匿名块
    ]
    
    # 基本信息
    name: Optional[str] = None           # 对象名（匿名块为 None）
    schema_name: Optional[str] = None    # Schema 名
    
    # 参数信息
    parameters: List[ParameterInfo] = Field(default_factory=list)
    
    # 函数特有
    return_type: Optional[str] = None    # 返回类型
    deterministic: bool = False       # 是否确定性（MySQL）
    
    # 包特有（Oracle）
    is_body: bool = False             # 是否为 PACKAGE BODY
    procedures: List[Dict[str, Any]] = Field(default_factory=list)  # 包内过程声明
    functions: List[Dict[str, Any]] = Field(default_factory=list)   # 包内函数声明
    
    # 触发器特有
    timing: Optional[str] = None         # BEFORE | AFTER | INSTEAD OF
    events: List[str] = Field(default_factory=list)  # [INSERT, UPDATE, DELETE]
    table_name: Optional[str] = None     # 触发表
    level: Optional[str] = None          # ROW | STATEMENT
    when_condition: Optional[str] = None # WHEN 条件
    
    # PostgreSQL 特有
    language: Optional[str] = None       # plpgsql, sql, python 等
    
    # 通用
    body: Optional[str] = None           # 原始代码体
    is_replace: bool = False          # OR REPLACE
    dialect: Optional[str] = None        # 来源方言
    definer: Optional[str] = None        # DEFINER（MySQL）


class TableReference(BaseModel):
    """表引用信息。"""

    name: str  # 表名
    schema_name: Optional[str] = None  # Schema 名称
    alias: Optional[str] = None  # 别名
    type: Literal["table", "view", "subquery", "cte"] = "table"  # 类型


class ColumnReference(BaseModel):
    """列引用信息。"""

    name: str  # 列名
    table: Optional[str] = None  # 所属表名
    alias: Optional[str] = None  # 别名
    expression: Optional[str] = None  # 表达式，如 COUNT(*)、SUM(amount)


class ConditionNode(BaseModel):
    """WHERE/HAVING 子句中的条件节点。"""

    type: Literal["comparison", "logical", "in", "exists", "between", "like", "is_null"]
    operator: Optional[str] = None  # 操作符
    column: Optional[str] = None  # 列名
    value: Optional[str] = None  # 值
    children: Optional[List[ConditionNode]] = None  # 子条件（用于 AND/OR）


class JoinInfo(BaseModel):
    """JOIN 信息。"""

    type: Literal["INNER", "LEFT", "RIGHT", "FULL", "CROSS", "NATURAL"]
    table: TableReference  # 关联的表
    condition: Optional[str] = None  # JOIN 条件


class OrderByItem(BaseModel):
    """ORDER BY 项。"""

    column: str  # 排序列
    direction: Literal["ASC", "DESC"] = "ASC"  # 排序方向


class ParseError(BaseModel):
    """解析错误信息，包含精确位置。"""

    error_type: Literal[
        "syntax_error",  # 语法错误
        "semantic_warning",  # 语义警告
        "unsupported_syntax",  # 不支持的语法
        "dialect_unsupported",  # 方言不支持
        "unknown_element",  # 未知元素
        "preprocessed",  # 预处理后解析
    ]
    message: str  # 错误消息
    line: Optional[int] = None  # 行号（从 1 开始）
    column: Optional[int] = None  # 列号（从 1 开始）
    offset: Optional[int] = None  # 字符偏移量（从 0 开始）
    context: Optional[str] = None  # 错误上下文
    marked_sql: Optional[str] = None  # 带错误标记的 SQL


class OracleSpecificInfo(BaseModel):
    """Oracle 特有信息。"""
    
    hierarchy: Optional[Dict[str, Any]] = None  # 层次查询信息
    sequences: List[str] = Field(default_factory=list)  # 序列引用（NEXTVAL/CURRVAL）
    pseudo_columns: List[str] = Field(default_factory=list)  # 伪列使用（ROWNUM, ROWID, LEVEL 等）
    merge_info: Optional[Dict[str, Any]] = None  # MERGE 语句信息
    plsql_info: Optional[Dict[str, Any]] = None  # PL/SQL 对象信息（兼容旧版）
    procedural_info: Optional[ProceduralInfo] = None  # 过程化对象信息


class TiDBHint(BaseModel):
    """TiDB Hint 信息。"""
    
    name: str  # Hint 名称
    type: str  # Hint 类型
    args: str  # Hint 参数


class TiDBSpecificInfo(BaseModel):
    """TiDB 特有信息。"""
    
    hints: List[TiDBHint] = Field(default_factory=list)  # Hint 列表
    auto_random_columns: List[str] = Field(default_factory=list)  # AUTO_RANDOM 列
    preprocessed: bool = False  # 是否经过预处理
    procedural_info: Optional[ProceduralInfo] = None  # 过程化对象信息


class OceanBaseHint(BaseModel):
    """OceanBase Hint 信息。"""
    
    name: str  # Hint 名称
    type: str  # Hint 类型
    args: str  # Hint 参数


class OceanBaseSpecificInfo(BaseModel):
    """OceanBase 特有信息。"""
    
    mode: str  # 模式：mysql 或 oracle
    hints: List[OceanBaseHint] = Field(default_factory=list)  # Hint 列表
    preprocessed: bool = False  # 是否经过预处理
    procedural_info: Optional[ProceduralInfo] = None  # 过程化对象信息


class MySQLSpecificInfo(BaseModel):
    """MySQL 特有信息。"""
    
    procedural_info: Optional[ProceduralInfo] = None  # 过程化对象信息
    preprocessed: bool = False  # 是否经过预处理


class PostgreSQLSpecificInfo(BaseModel):
    """PostgreSQL 特有信息。"""
    
    procedural_info: Optional[ProceduralInfo] = None  # 过程化对象信息
    preprocessed: bool = False  # 是否经过预处理


class ParseResult(BaseModel):
    """单条 SQL 语句的解析结果。"""

    sql: str  # 原始 SQL
    dialect: str  # 方言
    statement_type: str  # 语句类型
    tables: List[TableReference] = Field(default_factory=list)  # 表列表
    columns: List[ColumnReference] = Field(default_factory=list)  # 列列表
    conditions: List[ConditionNode] = Field(default_factory=list)  # 条件列表
    joins: List[JoinInfo] = Field(default_factory=list)  # JOIN 列表
    group_by: List[str] = Field(default_factory=list)  # GROUP BY 列
    order_by: List[OrderByItem] = Field(default_factory=list)  # ORDER BY 列
    limit: Optional[int] = None  # LIMIT 值
    offset_value: Optional[int] = None  # OFFSET 值
    errors: List[ParseError] = Field(default_factory=list)  # 错误列表
    warnings: List[ParseError] = Field(default_factory=list)  # 警告列表
    success: bool = True  # 是否解析成功
    oracle_info: Optional[OracleSpecificInfo] = None  # Oracle 特有信息
    tidb_info: Optional[TiDBSpecificInfo] = None  # TiDB 特有信息
    oceanbase_info: Optional[OceanBaseSpecificInfo] = None  # OceanBase 特有信息
    mysql_info: Optional[MySQLSpecificInfo] = None  # MySQL 特有信息
    postgresql_info: Optional[PostgreSQLSpecificInfo] = None  # PostgreSQL 特有信息


class BatchParseResult(BaseModel):
    """批量解析结果。"""

    results: List[ParseResult]  # 解析结果列表
    total_statements: int  # 总语句数
    successful: int  # 成功数
    failed: int  # 失败数
