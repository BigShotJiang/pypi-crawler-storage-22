# -*- coding: utf-8 -*-
"""SQL 解析器主类。"""
from __future__ import annotations

from concurrent.futures import ProcessPoolExecutor, as_completed
from typing import Iterator, List, Optional

from sql_parser.constants import (
    SUPPORTED_DIALECTS,
    MAX_WORKERS,
    BATCH_SIZE,
    MAX_TASKS_PER_CHILD,
)
from sql_parser.core import parse_single_sql, parse_batch_chunk
from sql_parser.models import ParseResult, BatchParseResult


class SQLParser:
    """多方言 SQL 解析器，支持批量处理。
    
    支持的方言：MySQL、PostgreSQL、Oracle、TiDB、OceanBase
    
    特性：
    - 多进程批量解析
    - 流式返回结果
    - 自动内存管理
    - 预处理 SQLGlot 不支持的语法
    
    示例：
        >>> parser = SQLParser(dialect="mysql")
        >>> result = parser.parse("SELECT * FROM users WHERE id = 1")
        >>> print(result.tables)
        
        >>> # TiDB 特有语法也能解析
        >>> parser = SQLParser(dialect="tidb")
        >>> result = parser.parse("CREATE TABLE t (id BIGINT AUTO_RANDOM PRIMARY KEY)")
        >>> print(result.success)  # True
    """
    
    def __init__(
        self,
        dialect: str = "mysql",
        max_workers: Optional[int] = None,
        batch_size: int = BATCH_SIZE,
    ):
        """初始化解析器。
        
        Args:
            dialect: 数据库方言，支持 mysql/postgresql/oracle/tidb/oceanbase-mysql/oceanbase-oracle
            max_workers: 最大进程数，默认基于 CPU 核心数
            batch_size: 批量处理时每批的大小
        
        Raises:
            ValueError: 如果指定了不支持的方言
        """
        if dialect not in SUPPORTED_DIALECTS:
            raise ValueError(
                f"不支持的方言: {dialect}。"
                f"支持的方言: {', '.join(sorted(SUPPORTED_DIALECTS))}"
            )
        self.dialect = dialect
        self.max_workers = max_workers or MAX_WORKERS
        self.batch_size = batch_size
    
    def parse(self, sql: str) -> ParseResult:
        """解析单条 SQL 语句。
        
        Args:
            sql: SQL 语句
        
        Returns:
            解析结果
        """
        result = parse_single_sql(sql, self.dialect)
        return ParseResult(**result)
    
    def parse_batch(self, sqls: List[str]) -> Iterator[ParseResult]:
        """批量解析 SQL 语句，使用多进程。
        
        使用生成器流式返回结果，避免内存累积。
        
        Args:
            sqls: SQL 语句列表
        
        Yields:
            每条 SQL 的解析结果
        """
        if not sqls:
            return
        
        # 小批量直接单进程处理
        if len(sqls) <= self.batch_size:
            for sql in sqls:
                yield self.parse(sql)
            return
        
        # 分批
        batches = [
            sqls[i : i + self.batch_size]
            for i in range(0, len(sqls), self.batch_size)
        ]
        
        # 多进程执行
        with ProcessPoolExecutor(
            max_workers=self.max_workers,
        ) as executor:
            futures = {
                executor.submit(parse_batch_chunk, batch, self.dialect): i
                for i, batch in enumerate(batches)
            }
            
            for future in as_completed(futures):
                batch_results = future.result()
                for result in batch_results:
                    yield ParseResult(**result)
                # 显式清理，帮助 GC
                del batch_results
    
    def parse_batch_all(self, sqls: List[str]) -> BatchParseResult:
        """批量解析 SQL 语句，返回汇总结果。
        
        Args:
            sqls: SQL 语句列表
        
        Returns:
            批量解析结果，包含所有结果和统计信息
        """
        results = list(self.parse_batch(sqls))
        successful = sum(1 for r in results if r.success)
        
        return BatchParseResult(
            results=results,
            total_statements=len(results),
            successful=successful,
            failed=len(results) - successful,
        )
