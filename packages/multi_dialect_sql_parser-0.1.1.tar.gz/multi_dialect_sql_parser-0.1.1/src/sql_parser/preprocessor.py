"""SQL 预处理器 - 处理 SQLGlot 不支持的语法。"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Literal, List, Dict, Optional, Tuple, Any

from sql_parser.constants import TIDB_KEYWORDS, OCEANBASE_KEYWORDS


@dataclass
class ParameterInfo:
    """参数信息。"""
    name: str  # 参数名
    mode: str = "IN"  # IN | OUT | INOUT
    datatype: str = ""  # 数据类型
    default_value: Optional[str] = None  # 默认值


@dataclass
class ProceduralInfo:
    """过程化对象信息（通用模型）。"""
    
    # 对象类型
    type: Literal[
        "FUNCTION",           # 函数
        "PROCEDURE",          # 存储过程
        "PACKAGE",            # 包（Oracle）
        "PACKAGE_BODY",       # 包体（Oracle）
        "TRIGGER",            # 触发器
        "ANONYMOUS_BLOCK",    # 匿名块
    ]
    
    # 基本信息
    name: Optional[str] = None           # 对象名（匿名块为 None）
    schema_name: Optional[str] = None    # Schema 名
    
    # 参数信息
    parameters: List[ParameterInfo] = field(default_factory=list)
    
    # 函数特有
    return_type: Optional[str] = None    # 返回类型
    deterministic: bool = False       # 是否确定性（MySQL）
    
    # 包特有（Oracle）
    is_body: bool = False             # 是否为 PACKAGE BODY
    procedures: List[Dict[str, Any]] = field(default_factory=list)  # 包内过程声明
    functions: List[Dict[str, Any]] = field(default_factory=list)   # 包内函数声明
    
    # 触发器特有
    timing: Optional[str] = None         # BEFORE | AFTER | INSTEAD OF
    events: List[str] = field(default_factory=list)  # [INSERT, UPDATE, DELETE]
    table_name: Optional[str] = None     # 触发表
    level: Optional[str] = None          # ROW | STATEMENT
    when_condition: Optional[str] = None # WHEN 条件
    
    # PostgreSQL 特有
    language: Optional[str] = None       # plpgsql, sql, python 等
    
    # 通用
    body: Optional[str] = None           # 原始代码体
    is_replace: bool = False          # OR REPLACE
    dialect: Optional[str] = None        # 来源方言
    definer: Optional[str] = None        # DEFINER（MySQL）


@dataclass
class PreprocessResult:
    """预处理结果。"""
    sql: str  # 处理后的 SQL
    original_sql: str  # 原始 SQL
    modifications: List[Dict[str, Any]]  # 修改记录
    preprocessed: bool  # 是否进行了预处理
    procedural_info: Optional[ProceduralInfo] = None  # 过程化对象信息


# 预编译的正则表达式（模块级别，避免重复编译）
_RE_TIDB_AUTO_RANDOM = re.compile(
    r'\b(\w+)\s+(\w+)\s+AUTO_RANDOM(?:\s*\(\s*(\d+)\s*\))?',
    re.IGNORECASE
)
_RE_TIDB_SHARD_ROW_ID = re.compile(r'\bSHARD_ROW_ID_BITS\s*=\s*\d+', re.IGNORECASE)
_RE_TIDB_PRE_SPLIT = re.compile(r'\bPRE_SPLIT_REGIONS\s*=\s*\d+', re.IGNORECASE)
_RE_TIDB_CLUSTERED = re.compile(r'\b(NON)?CLUSTERED\b', re.IGNORECASE)

_RE_OB_TABLEGROUP = re.compile(r'\bTABLEGROUP\s*=\s*[\'"]?\w+[\'"]?', re.IGNORECASE)
_RE_OB_LOCALITY = re.compile(r'\bLOCALITY\s*=\s*[\'"][^"\']+[\'"]', re.IGNORECASE)
_RE_OB_REPLICA_NUM = re.compile(r'\bREPLICA_NUM\s*=\s*\d+', re.IGNORECASE)
_RE_OB_PRIMARY_ZONE = re.compile(r'\bPRIMARY_ZONE\s*=\s*[\'"][^"\']+[\'"]', re.IGNORECASE)

_RE_CLEANUP_COMMA = re.compile(r',\s*,')
_RE_CLEANUP_TRAILING_COMMA = re.compile(r',\s*\)')
_RE_CLEANUP_LEADING_COMMA = re.compile(r'\(\s*,')

_RE_DEFINER = re.compile(r'DEFINER\s*=\s*(\S+)', re.IGNORECASE)
_RE_PARAM_MODE = re.compile(r'^\s*(IN\s+OUT|INOUT|IN|OUT)\s+', re.IGNORECASE)

_RE_PG_DOLLAR_QUOTED = re.compile(r'\$(\w*)\$(.*?)\$\1\$', re.DOTALL)
_RE_PG_LANGUAGE = re.compile(r'LANGUAGE\s+(\w+)', re.IGNORECASE)


class SQLPreprocessor:
    """SQL 预处理器，处理各方言特有语法。"""
    
    def __init__(self, dialect: str):
        """初始化预处理器。
        
        Args:
            dialect: 数据库方言
        """
        self.dialect = dialect
    
    def preprocess(self, sql: str) -> PreprocessResult:
        """预处理 SQL 语句。
        
        Args:
            sql: 原始 SQL
        
        Returns:
            预处理结果
        """
        original_sql = sql
        modifications = []
        procedural_info = None
        
        if self.dialect == "tidb":
            sql, mods = self._preprocess_tidb(sql)
            modifications.extend(mods)
            # TiDB 过程化语法复用 MySQL
            if not modifications:
                sql, mods, procedural_info = self._preprocess_mysql_procedural(sql)
                modifications.extend(mods)
        elif self.dialect == "mysql":
            sql, mods, procedural_info = self._preprocess_mysql_procedural(sql)
            modifications.extend(mods)
        elif self.dialect == "postgresql":
            sql, mods, procedural_info = self._preprocess_postgresql_procedural(sql)
            modifications.extend(mods)
        elif self.dialect in ("oceanbase-mysql", "oceanbase-oracle"):
            sql, mods = self._preprocess_oceanbase(sql)
            modifications.extend(mods)
            # OceanBase 过程化语法根据模式选择
            if not modifications:
                if self.dialect == "oceanbase-oracle":
                    sql, mods, procedural_info = self._preprocess_oracle_procedural(sql)
                else:
                    sql, mods, procedural_info = self._preprocess_mysql_procedural(sql)
                modifications.extend(mods)
        elif self.dialect == "oracle":
            sql, mods, procedural_info = self._preprocess_oracle_procedural(sql)
            modifications.extend(mods)
        
        return PreprocessResult(
            sql=sql,
            original_sql=original_sql,
            modifications=modifications,
            preprocessed=len(modifications) > 0,
            procedural_info=procedural_info,
        )
    
    def _preprocess_tidb(self, sql: str) -> tuple[str, List[Dict[str, Any]]]:
        """预处理 TiDB 特有语法。
        
        Args:
            sql: SQL 语句
        
        Returns:
            (处理后的 SQL, 修改记录列表)
        """
        modifications = []
        processed_sql = sql
        
        # 处理 AUTO_RANDOM
        for match in _RE_TIDB_AUTO_RANDOM.finditer(sql):
            col_name = match.group(1)
            col_type = match.group(2)
            shard_bits = match.group(3) or "5"
            
            modifications.append({
                "type": "auto_random",
                "column": col_name,
                "column_type": col_type,
                "shard_bits": shard_bits,
                "original": match.group(0),
            })
            
            # 替换为 AUTO_INCREMENT（SQLGlot 支持）
            replacement = f"{col_name} {col_type} AUTO_INCREMENT"
            processed_sql = processed_sql.replace(match.group(0), replacement)
        
        # 处理 SHARD_ROW_ID_BITS
        for match in _RE_TIDB_SHARD_ROW_ID.finditer(sql):
            modifications.append({
                "type": "shard_row_id_bits",
                "original": match.group(0),
            })
            processed_sql = processed_sql.replace(match.group(0), "")
        
        # 处理 PRE_SPLIT_REGIONS
        for match in _RE_TIDB_PRE_SPLIT.finditer(sql):
            modifications.append({
                "type": "pre_split_regions",
                "original": match.group(0),
            })
            processed_sql = processed_sql.replace(match.group(0), "")
        
        # 处理 CLUSTERED/NONCLUSTERED
        for match in _RE_TIDB_CLUSTERED.finditer(sql):
            modifications.append({
                "type": "clustered",
                "original": match.group(0),
            })
            processed_sql = processed_sql.replace(match.group(0), "")
        
        # 清理多余的逗号和空格
        processed_sql = _RE_CLEANUP_COMMA.sub(',', processed_sql)
        processed_sql = _RE_CLEANUP_TRAILING_COMMA.sub(')', processed_sql)
        processed_sql = _RE_CLEANUP_LEADING_COMMA.sub('(', processed_sql)
        
        return processed_sql, modifications
    
    def _preprocess_oceanbase(self, sql: str) -> tuple[str, List[Dict[str, Any]]]:
        """预处理 OceanBase 特有语法。
        
        Args:
            sql: SQL 语句
        
        Returns:
            (处理后的 SQL, 修改记录列表)
        """
        modifications = []
        processed_sql = sql
        
        # 处理 TABLEGROUP
        for match in _RE_OB_TABLEGROUP.finditer(sql):
            modifications.append({
                "type": "tablegroup",
                "original": match.group(0),
            })
            processed_sql = processed_sql.replace(match.group(0), "")
        
        # 处理 LOCALITY
        for match in _RE_OB_LOCALITY.finditer(sql):
            modifications.append({
                "type": "locality",
                "original": match.group(0),
            })
            processed_sql = processed_sql.replace(match.group(0), "")
        
        # 处理 REPLICA_NUM
        for match in _RE_OB_REPLICA_NUM.finditer(sql):
            modifications.append({
                "type": "replica_num",
                "original": match.group(0),
            })
            processed_sql = processed_sql.replace(match.group(0), "")
        
        # 处理 PRIMARY_ZONE
        for match in _RE_OB_PRIMARY_ZONE.finditer(sql):
            modifications.append({
                "type": "primary_zone",
                "original": match.group(0),
            })
            processed_sql = processed_sql.replace(match.group(0), "")
        
        # 清理多余的逗号和空格
        processed_sql = _RE_CLEANUP_COMMA.sub(',', processed_sql)
        processed_sql = _RE_CLEANUP_TRAILING_COMMA.sub(')', processed_sql)
        processed_sql = _RE_CLEANUP_LEADING_COMMA.sub('(', processed_sql)
        
        return processed_sql, modifications

    # ==================== Oracle PL/SQL 预处理器 ====================
    
    def _preprocess_oracle_procedural(self, sql: str) -> tuple[str, List[Dict[str, Any]], Optional[ProceduralInfo]]:
        """预处理 Oracle PL/SQL 语法。
        
        处理 SQLGlot 不支持的 PL/SQL 语法：
        - CREATE FUNCTION (带 RETURN 关键字)
        - CREATE PROCEDURE
        - CREATE PACKAGE / PACKAGE BODY
        - CREATE TRIGGER (带 PL/SQL 体)
        - 匿名 PL/SQL 块 (BEGIN...END)
        
        Args:
            sql: SQL 语句
        
        Returns:
            (处理后的 SQL, 修改记录列表, 过程化信息)
        """
        sql_upper = sql.upper().strip()
        
        # CREATE PACKAGE / PACKAGE BODY（必须在 FUNCTION/PROCEDURE 之前检查，因为包内可能包含这些关键字）
        if sql_upper.startswith("CREATE") and "PACKAGE" in sql_upper:
            return self._parse_oracle_package(sql)
        
        # CREATE FUNCTION（带 RETURN 关键字）
        if sql_upper.startswith("CREATE") and "FUNCTION" in sql_upper and "RETURN" in sql_upper:
            return self._parse_oracle_function(sql)
        
        # CREATE PROCEDURE
        if sql_upper.startswith("CREATE") and "PROCEDURE" in sql_upper:
            return self._parse_oracle_procedure(sql)
        
        # CREATE TRIGGER
        if sql_upper.startswith("CREATE") and "TRIGGER" in sql_upper:
            return self._parse_oracle_trigger(sql)
        
        # 匿名块
        if sql_upper.startswith("BEGIN") or sql_upper.startswith("DECLARE"):
            return self._parse_oracle_anonymous_block(sql)
        
        return sql, [], None
    
    def _parse_oracle_function(self, sql: str) -> tuple[str, List[Dict[str, Any]], Optional[ProceduralInfo]]:
        """解析 Oracle CREATE FUNCTION 语句。"""
        modifications = []
        
        # 检测 OR REPLACE
        is_replace = "OR REPLACE" in sql.upper()
        
        # 匹配 CREATE [OR REPLACE] FUNCTION [schema.]name [(params)] RETURN type [IS|AS] body
        pattern = re.compile(
            r'CREATE\s+(?:OR\s+REPLACE\s+)?FUNCTION\s+'
            r'(?:(\w+)\.)?'           # schema（可选）
            r'(\w+)\s*'               # 函数名
            r'(?:\(([^)]*)\))?\s*'    # 参数列表（可选）
            r'RETURN\s+(\S+)\s*'      # 返回类型
            r'(?:DETERMINISTIC\s+)?'  # DETERMINISTIC（可选）
            r'(?:IS|AS)\s*'           # IS 或 AS
            r'(.*)',                  # 函数体
            re.IGNORECASE | re.DOTALL
        )
        
        match = pattern.match(sql.strip())
        if match:
            schema_name = match.group(1)
            func_name = match.group(2)
            params_str = match.group(3) or ""
            return_type = match.group(4)
            body = match.group(5).strip()
            
            # 移除末尾的分号和斜杠
            body = re.sub(r'[;/]\s*$', '', body).strip()
            
            # 解析参数
            parameters = self._parse_oracle_parameters(params_str)
            
            procedural_info = ProceduralInfo(
                type="FUNCTION",
                name=func_name,
                schema_name=schema_name,
                parameters=parameters,
                return_type=return_type,
                body=body,
                is_replace=is_replace,
                dialect="oracle",
            )
            
            modifications.append({
                "type": "oracle_function",
                "name": func_name,
                "original": sql,
            })
            
            # 转换为 SQLGlot 可解析的简化形式
            processed_sql = f"CREATE PROCEDURE {func_name}"
            if params_str:
                processed_sql += f"({params_str})"
            processed_sql += " AS BEGIN NULL; END"
            
            return processed_sql, modifications, procedural_info
        
        return sql, [], None
    
    def _parse_oracle_procedure(self, sql: str) -> tuple[str, List[Dict[str, Any]], Optional[ProceduralInfo]]:
        """解析 Oracle CREATE PROCEDURE 语句。"""
        modifications = []
        
        is_replace = "OR REPLACE" in sql.upper()
        
        # 匹配 CREATE [OR REPLACE] PROCEDURE [schema.]name [(params)] [IS|AS] body
        pattern = re.compile(
            r'CREATE\s+(?:OR\s+REPLACE\s+)?PROCEDURE\s+'
            r'(?:(\w+)\.)?'           # schema（可选）
            r'(\w+)\s*'               # 过程名
            r'(?:\(([^)]*)\))?\s*'    # 参数列表（可选）
            r'(?:IS|AS)\s*'           # IS 或 AS
            r'(.*)',                  # 过程体
            re.IGNORECASE | re.DOTALL
        )
        
        match = pattern.match(sql.strip())
        if match:
            schema_name = match.group(1)
            proc_name = match.group(2)
            params_str = match.group(3) or ""
            body = match.group(4).strip()
            
            body = re.sub(r'[;/]\s*$', '', body).strip()
            parameters = self._parse_oracle_parameters(params_str)
            
            procedural_info = ProceduralInfo(
                type="PROCEDURE",
                name=proc_name,
                schema_name=schema_name,
                parameters=parameters,
                body=body,
                is_replace=is_replace,
                dialect="oracle",
            )
            
            modifications.append({
                "type": "oracle_procedure",
                "name": proc_name,
                "original": sql,
            })
            
            # Oracle PROCEDURE SQLGlot 可以解析，但为了统一处理
            processed_sql = f"CREATE PROCEDURE {proc_name}"
            if params_str:
                processed_sql += f"({params_str})"
            processed_sql += " AS BEGIN NULL; END"
            
            return processed_sql, modifications, procedural_info
        
        return sql, [], None
    
    def _parse_oracle_package(self, sql: str) -> tuple[str, List[Dict[str, Any]], Optional[ProceduralInfo]]:
        """解析 Oracle CREATE PACKAGE 语句。"""
        modifications = []
        sql_upper = sql.upper()
        
        is_replace = "OR REPLACE" in sql_upper
        is_body = "PACKAGE BODY" in sql_upper
        
        # 匹配 CREATE [OR REPLACE] PACKAGE [BODY] [schema.]name [IS|AS] body END [name];
        # 注意：IS|AS 可能紧跟在包名后面（同一行）或换行后
        pattern = re.compile(
            r'CREATE\s+(?:OR\s+REPLACE\s+)?PACKAGE\s+'
            r'(?:BODY\s+)?'           # BODY（可选）
            r'(?:(\w+)\.)?'           # schema（可选）
            r'(\w+)\s+'               # 包名（后面必须有空白）
            r'(?:IS|AS)\s+'           # IS 或 AS（后面必须有空白或换行）
            r'(.*)',                  # 包体
            re.IGNORECASE | re.DOTALL
        )
        
        match = pattern.match(sql.strip())
        if match:
            schema_name = match.group(1)
            pkg_name = match.group(2)
            body = match.group(3).strip()
            
            # 解析包内的过程和函数声明
            procedures = self._extract_package_members(body, "PROCEDURE")
            functions = self._extract_package_members(body, "FUNCTION")
            
            procedural_info = ProceduralInfo(
                type="PACKAGE_BODY" if is_body else "PACKAGE",
                name=pkg_name,
                schema_name=schema_name,
                is_body=is_body,
                procedures=procedures,
                functions=functions,
                body=body,
                is_replace=is_replace,
                dialect="oracle",
            )
            
            modifications.append({
                "type": "oracle_package",
                "name": pkg_name,
                "is_body": is_body,
                "original": sql,
            })
            
            processed_sql = f"CREATE PROCEDURE {pkg_name}_pkg AS BEGIN NULL; END"
            
            return processed_sql, modifications, procedural_info
        
        return sql, [], None
    
    def _parse_oracle_trigger(self, sql: str) -> tuple[str, List[Dict[str, Any]], Optional[ProceduralInfo]]:
        """解析 Oracle CREATE TRIGGER 语句。"""
        modifications = []
        
        is_replace = "OR REPLACE" in sql.upper()
        
        # 匹配 CREATE [OR REPLACE] TRIGGER name timing event [OF column] ON table [FOR EACH ROW] [WHEN (...)] body
        # 支持 UPDATE OF column 语法
        pattern = re.compile(
            r'CREATE\s+(?:OR\s+REPLACE\s+)?TRIGGER\s+'
            r'(?:(\w+)\.)?'           # schema（可选）
            r'(\w+)\s+'               # 触发器名
            r'(BEFORE|AFTER|INSTEAD\s+OF)\s+'  # 触发时机
            r'(INSERT|UPDATE|DELETE)'  # 第一个触发事件
            r'(?:\s+OF\s+\w+)?'       # OF column（可选，用于 UPDATE OF）
            r'(?:\s+OR\s+(INSERT|UPDATE|DELETE)(?:\s+OF\s+\w+)?)*\s+'  # 其他事件
            r'ON\s+(\w+(?:\.\w+)?)\s*'  # 表名
            r'(?:FOR\s+EACH\s+(ROW|STATEMENT))?\s*'  # 触发级别
            r'(?:WHEN\s*\(([^)]+)\))?\s*'  # WHEN 条件
            r'(.*)',                  # 触发器体
            re.IGNORECASE | re.DOTALL
        )
        
        match = pattern.match(sql.strip())
        if match:
            schema_name = match.group(1)
            trigger_name = match.group(2)
            timing = match.group(3).upper().replace("  ", " ")
            event1 = match.group(4).upper()
            event2 = match.group(5)
            table_name = match.group(6)
            level = (match.group(7) or "ROW").upper()
            when_condition = match.group(8)
            body = match.group(9).strip() if match.group(9) else ""
            
            # 收集所有事件
            events = [event1]
            if event2:
                events.append(event2.upper())
            
            procedural_info = ProceduralInfo(
                type="TRIGGER",
                name=trigger_name,
                schema_name=schema_name,
                timing=timing,
                events=events,
                table_name=table_name,
                level=level,
                when_condition=when_condition,
                body=body,
                is_replace=is_replace,
                dialect="oracle",
            )
            
            modifications.append({
                "type": "oracle_trigger",
                "name": trigger_name,
                "table": table_name,
                "original": sql,
            })
            
            processed_sql = f"CREATE PROCEDURE {trigger_name}_trigger AS BEGIN NULL; END"
            
            return processed_sql, modifications, procedural_info
        
        return sql, [], None
    
    def _parse_oracle_anonymous_block(self, sql: str) -> tuple[str, List[Dict[str, Any]], Optional[ProceduralInfo]]:
        """解析 Oracle 匿名 PL/SQL 块。"""
        modifications = []
        
        # 匹配 [DECLARE ...] BEGIN ... END [;/]
        pattern = re.compile(
            r'(?:DECLARE\s+(.*?))?\s*BEGIN\s+(.*?)\s*END\s*[;/]?\s*$',
            re.IGNORECASE | re.DOTALL
        )
        
        match = pattern.match(sql.strip())
        if match:
            declare_section = match.group(1) or ""
            body = match.group(2) or ""
            
            procedural_info = ProceduralInfo(
                type="ANONYMOUS_BLOCK",
                name=None,
                body=f"DECLARE {declare_section} BEGIN {body} END" if declare_section else f"BEGIN {body} END",
                dialect="oracle",
            )
            
            modifications.append({
                "type": "oracle_anonymous_block",
                "original": sql,
            })
            
            processed_sql = "SELECT 1 FROM DUAL"
            
            return processed_sql, modifications, procedural_info
        
        return sql, [], None
    
    def _parse_oracle_parameters(self, params_str: str) -> List[ParameterInfo]:
        """解析 Oracle 函数/过程参数列表。"""
        if not params_str.strip():
            return []
        
        params = []
        # 简单分割参数
        for param in params_str.split(","):
            param = param.strip()
            if not param:
                continue
            
            # 匹配 name [IN|OUT|IN OUT] type [DEFAULT value]
            param_pattern = re.compile(
                r'(\w+)\s+'
                r'(?:(IN\s+OUT|IN|OUT)\s+)?'
                r'(\w+(?:\([^)]*\))?)'
                r'(?:\s+DEFAULT\s+(.+))?',
                re.IGNORECASE
            )
            
            match = param_pattern.match(param)
            if match:
                params.append(ParameterInfo(
                    name=match.group(1),
                    mode=(match.group(2) or "IN").upper().replace("  ", " "),
                    datatype=match.group(3),
                    default_value=match.group(4),
                ))
            else:
                # 简单情况：只有名称和类型
                parts = param.split()
                if len(parts) >= 2:
                    params.append(ParameterInfo(
                        name=parts[0],
                        mode="IN",
                        datatype=parts[-1],
                    ))
        
        return params
    
    def _extract_package_members(self, body: str, member_type: str) -> List[Dict[str, Any]]:
        """从包体中提取过程或函数声明。"""
        from dataclasses import asdict
        
        members = []
        
        if member_type == "PROCEDURE":
            pattern = re.compile(
                r'PROCEDURE\s+(\w+)\s*(?:\(([^)]*)\))?\s*;',
                re.IGNORECASE
            )
        else:
            pattern = re.compile(
                r'FUNCTION\s+(\w+)\s*(?:\(([^)]*)\))?\s*RETURN\s+(\w+(?:\([^)]*\))?)\s*;',
                re.IGNORECASE
            )
        
        for match in pattern.finditer(body):
            member = {"name": match.group(1)}
            if match.group(2):
                member["parameters"] = [asdict(p) for p in self._parse_oracle_parameters(match.group(2))]
            if member_type == "FUNCTION" and match.group(3):
                member["return_type"] = match.group(3)
            members.append(member)
        
        return members

    # ==================== MySQL 存储过程预处理器 ====================
    
    def _preprocess_mysql_procedural(self, sql: str) -> tuple[str, List[Dict[str, Any]], Optional[ProceduralInfo]]:
        """预处理 MySQL 存储过程语法。
        
        处理 SQLGlot 不支持的 MySQL 过程化语法：
        - CREATE FUNCTION (带 RETURNS 关键字和 BEGIN...END)
        - CREATE PROCEDURE (带 BEGIN...END)
        - CREATE TRIGGER
        
        Args:
            sql: SQL 语句
        
        Returns:
            (处理后的 SQL, 修改记录列表, 过程化信息)
        """
        sql_upper = sql.upper().strip()
        
        # CREATE FUNCTION（带 RETURNS 关键字）
        if sql_upper.startswith("CREATE") and "FUNCTION" in sql_upper and "RETURNS" in sql_upper:
            return self._parse_mysql_function(sql)
        
        # CREATE PROCEDURE
        if sql_upper.startswith("CREATE") and "PROCEDURE" in sql_upper:
            return self._parse_mysql_procedure(sql)
        
        # CREATE TRIGGER
        if sql_upper.startswith("CREATE") and "TRIGGER" in sql_upper:
            return self._parse_mysql_trigger(sql)
        
        return sql, [], None
    
    def _parse_mysql_function(self, sql: str) -> tuple[str, List[Dict[str, Any]], Optional[ProceduralInfo]]:
        """解析 MySQL CREATE FUNCTION 语句。"""
        modifications = []
        
        # 提取 DEFINER
        definer = None
        definer_match = re.search(r'DEFINER\s*=\s*(\S+)', sql, re.IGNORECASE)
        if definer_match:
            definer = definer_match.group(1)
        
        # 使用更智能的方式提取参数列表（处理嵌套括号）
        params_str = self._extract_balanced_parentheses(sql)
        
        # 匹配 CREATE [DEFINER=...] FUNCTION name (...) RETURNS type [characteristics] BEGIN body END
        pattern = re.compile(
            r'CREATE\s+(?:DEFINER\s*=\s*\S+\s+)?FUNCTION\s+'
            r'(?:(\w+)\.)?'           # schema（可选）
            r'(\w+)\s*'               # 函数名
            r'\(',                    # 参数列表开始
            re.IGNORECASE | re.DOTALL
        )
        
        match = pattern.match(sql.strip())
        if match and params_str is not None:
            schema_name = match.group(1)
            func_name = match.group(2)
            
            # 提取 RETURNS 后的返回类型
            returns_match = re.search(r'RETURNS\s+(\S+)', sql, re.IGNORECASE)
            return_type = returns_match.group(1) if returns_match else None
            
            # 提取特性
            characteristics = ""
            char_match = re.search(
                r'RETURNS\s+\S+\s+((?:DETERMINISTIC|NO\s+SQL|READS\s+SQL\s+DATA|MODIFIES\s+SQL\s+DATA|CONTAINS\s+SQL)\s*)+',
                sql, re.IGNORECASE
            )
            if char_match:
                characteristics = char_match.group(1)
            
            # 提取函数体（BEGIN 到 END）
            body_match = re.search(r'BEGIN\s+(.*?)\s*END\s*$', sql, re.IGNORECASE | re.DOTALL)
            body = body_match.group(1).strip() if body_match else ""
            
            # 检测 DETERMINISTIC
            deterministic = "DETERMINISTIC" in characteristics.upper() if characteristics else False
            
            # 解析参数
            parameters = self._parse_mysql_parameters(params_str)
            
            procedural_info = ProceduralInfo(
                type="FUNCTION",
                name=func_name,
                schema_name=schema_name,
                parameters=parameters,
                return_type=return_type,
                deterministic=deterministic,
                body=body,
                definer=definer,
                dialect="mysql",
            )
            
            modifications.append({
                "type": "mysql_function",
                "name": func_name,
                "original": sql,
            })
            
            # 移除参数模式关键字（IN/OUT/INOUT），SQLGlot 不支持
            clean_params = self._clean_mysql_params_for_sqlglot(params_str)
            processed_sql = f"CREATE PROCEDURE {func_name}({clean_params}) BEGIN SELECT 1; END"
            
            return processed_sql, modifications, procedural_info
        
        return sql, [], None
    
    def _parse_mysql_procedure(self, sql: str) -> tuple[str, List[Dict[str, Any]], Optional[ProceduralInfo]]:
        """解析 MySQL CREATE PROCEDURE 语句。"""
        modifications = []
        
        # 提取 DEFINER
        definer = None
        definer_match = re.search(r'DEFINER\s*=\s*(\S+)', sql, re.IGNORECASE)
        if definer_match:
            definer = definer_match.group(1)
        
        # 使用更智能的方式提取参数列表（处理嵌套括号）
        params_str = self._extract_balanced_parentheses(sql)
        
        # 匹配 CREATE [DEFINER=...] PROCEDURE name (...) [characteristics] BEGIN body END
        pattern = re.compile(
            r'CREATE\s+(?:DEFINER\s*=\s*\S+\s+)?PROCEDURE\s+'
            r'(?:(\w+)\.)?'           # schema（可选）
            r'(\w+)\s*'               # 过程名
            r'\(',                    # 参数列表开始
            re.IGNORECASE | re.DOTALL
        )
        
        match = pattern.match(sql.strip())
        if match and params_str is not None:
            schema_name = match.group(1)
            proc_name = match.group(2)
            
            # 提取过程体（BEGIN 到 END）
            body_match = re.search(r'BEGIN\s+(.*?)\s*END\s*$', sql, re.IGNORECASE | re.DOTALL)
            body = body_match.group(1).strip() if body_match else ""
            
            parameters = self._parse_mysql_parameters(params_str)
            
            procedural_info = ProceduralInfo(
                type="PROCEDURE",
                name=proc_name,
                schema_name=schema_name,
                parameters=parameters,
                body=body,
                definer=definer,
                dialect="mysql",
            )
            
            modifications.append({
                "type": "mysql_procedure",
                "name": proc_name,
                "original": sql,
            })
            
            # 移除参数模式关键字（IN/OUT/INOUT），SQLGlot 不支持
            clean_params = self._clean_mysql_params_for_sqlglot(params_str)
            processed_sql = f"CREATE PROCEDURE {proc_name}({clean_params}) BEGIN SELECT 1; END"
            
            return processed_sql, modifications, procedural_info
        
        return sql, [], None
    
    def _parse_mysql_trigger(self, sql: str) -> tuple[str, List[Dict[str, Any]], Optional[ProceduralInfo]]:
        """解析 MySQL CREATE TRIGGER 语句。"""
        modifications = []
        
        # 提取 DEFINER
        definer = None
        definer_match = re.search(r'DEFINER\s*=\s*(\S+)', sql, re.IGNORECASE)
        if definer_match:
            definer = definer_match.group(1)
        
        # 匹配 CREATE [DEFINER=...] TRIGGER name timing event ON table FOR EACH ROW [FOLLOWS/PRECEDES] body
        pattern = re.compile(
            r'CREATE\s+(?:DEFINER\s*=\s*\S+\s+)?TRIGGER\s+'
            r'(?:(\w+)\.)?'           # schema（可选）
            r'(\w+)\s+'               # 触发器名
            r'(BEFORE|AFTER)\s+'      # 触发时机
            r'(INSERT|UPDATE|DELETE)\s+'  # 触发事件
            r'ON\s+(\w+(?:\.\w+)?)\s+'  # 表名
            r'FOR\s+EACH\s+ROW\s*'    # FOR EACH ROW
            r'(?:(?:FOLLOWS|PRECEDES)\s+\w+\s*)?'  # FOLLOWS/PRECEDES（可选）
            r'(.*)',                  # 触发器体
            re.IGNORECASE | re.DOTALL
        )
        
        match = pattern.match(sql.strip())
        if match:
            schema_name = match.group(1)
            trigger_name = match.group(2)
            timing = match.group(3).upper()
            event = match.group(4).upper()
            table_name = match.group(5)
            body = match.group(6).strip()
            
            # 移除 BEGIN...END 包装
            body = re.sub(r'^\s*BEGIN\s+', '', body, flags=re.IGNORECASE)
            body = re.sub(r'\s*END\s*$', '', body, flags=re.IGNORECASE).strip()
            
            procedural_info = ProceduralInfo(
                type="TRIGGER",
                name=trigger_name,
                schema_name=schema_name,
                timing=timing,
                events=[event],
                table_name=table_name,
                level="ROW",
                body=body,
                definer=definer,
                dialect="mysql",
            )
            
            modifications.append({
                "type": "mysql_trigger",
                "name": trigger_name,
                "table": table_name,
                "original": sql,
            })
            
            processed_sql = f"CREATE PROCEDURE {trigger_name}_trigger() BEGIN SELECT 1; END"
            
            return processed_sql, modifications, procedural_info
        
        return sql, [], None
    
    def _parse_mysql_parameters(self, params_str: str) -> List[ParameterInfo]:
        """解析 MySQL 函数/过程参数列表。"""
        if not params_str.strip():
            return []
        
        params = []
        # 使用智能分割处理嵌套括号
        param_list = self._split_parameters(params_str)
        
        for param in param_list:
            param = param.strip()
            if not param:
                continue
            
            # 匹配 [IN|OUT|INOUT] name type（type 可能包含括号如 VARCHAR(100)）
            param_pattern = re.compile(
                r'(?:(IN|OUT|INOUT)\s+)?'
                r'(\w+)\s+'
                r'(.+)',
                re.IGNORECASE
            )
            
            match = param_pattern.match(param)
            if match:
                params.append(ParameterInfo(
                    name=match.group(2),
                    mode=(match.group(1) or "IN").upper(),
                    datatype=match.group(3).strip(),
                ))
            else:
                # 简单情况：只有名称和类型
                parts = param.split()
                if len(parts) >= 2:
                    params.append(ParameterInfo(
                        name=parts[0],
                        mode="IN",
                        datatype=" ".join(parts[1:]),
                    ))
        
        return params
    
    def _extract_balanced_parentheses(self, sql: str) -> Optional[str]:
        """从 SQL 中提取第一对平衡括号内的内容。
        
        处理嵌套括号，如 VARCHAR(100) 或 DECIMAL(10,2)。
        
        Args:
            sql: SQL 语句
        
        Returns:
            括号内的内容，如果没有找到则返回 None
        """
        start = sql.find('(')
        if start == -1:
            return None
        
        depth = 0
        for i, char in enumerate(sql[start:], start):
            if char == '(':
                depth += 1
            elif char == ')':
                depth -= 1
                if depth == 0:
                    return sql[start + 1:i]
        
        return None
    
    def _split_parameters(self, params_str: str) -> List[str]:
        """智能分割参数列表，处理嵌套括号。
        
        例如: "IN p_id INT, OUT p_name VARCHAR(100)" -> ["IN p_id INT", "OUT p_name VARCHAR(100)"]
        
        Args:
            params_str: 参数字符串
        
        Returns:
            参数列表
        """
        params = []
        current = []
        depth = 0
        
        for char in params_str:
            if char == '(':
                depth += 1
                current.append(char)
            elif char == ')':
                depth -= 1
                current.append(char)
            elif char == ',' and depth == 0:
                params.append(''.join(current).strip())
                current = []
            else:
                current.append(char)
        
        # 添加最后一个参数
        if current:
            params.append(''.join(current).strip())
        
        return params
    
    def _clean_mysql_params_for_sqlglot(self, params_str: str) -> str:
        """清理 MySQL 参数字符串，移除 IN/OUT/INOUT 关键字以便 SQLGlot 解析。
        
        Args:
            params_str: 原始参数字符串，如 "IN user_id INT, OUT result VARCHAR(100)"
        
        Returns:
            清理后的参数字符串，如 "user_id INT, result VARCHAR(100)"
        """
        if not params_str.strip():
            return ""
        
        cleaned_params = []
        param_list = self._split_parameters(params_str)
        
        for param in param_list:
            param = param.strip()
            if not param:
                continue
            
            # 移除 IN/OUT/INOUT 前缀
            cleaned = _RE_PARAM_MODE.sub('', param)
            cleaned_params.append(cleaned.strip())
        
        return ", ".join(cleaned_params)
    
    def _clean_postgresql_params_for_sqlglot(self, params_str: str) -> str:
        """清理 PostgreSQL 参数字符串，移除 IN/OUT/INOUT 关键字以便 SQLGlot 解析。
        
        Args:
            params_str: 原始参数字符串，如 "IN p_id INTEGER, INOUT p_count INTEGER"
        
        Returns:
            清理后的参数字符串，如 "p_id INTEGER, p_count INTEGER"
        """
        if not params_str.strip():
            return ""
        
        cleaned_params = []
        # PostgreSQL 参数可能包含 DEFAULT，需要智能分割
        param_list = self._split_parameters(params_str)
        
        for param in param_list:
            param = param.strip()
            if not param:
                continue
            
            # 移除 IN/OUT/INOUT 前缀
            cleaned = _RE_PARAM_MODE.sub('', param)
            cleaned_params.append(cleaned.strip())
        
        return ", ".join(cleaned_params)

    # ==================== PostgreSQL PL/pgSQL 预处理器 ====================
    
    def _preprocess_postgresql_procedural(self, sql: str) -> tuple[str, List[Dict[str, Any]], Optional[ProceduralInfo]]:
        """预处理 PostgreSQL PL/pgSQL 语法。
        
        处理 SQLGlot 不支持的 PostgreSQL 过程化语法：
        - CREATE FUNCTION (带 $$ 语法)
        - CREATE PROCEDURE (带 $$ 语法)
        - CREATE TRIGGER
        - DO 块
        
        Args:
            sql: SQL 语句
        
        Returns:
            (处理后的 SQL, 修改记录列表, 过程化信息)
        """
        sql_upper = sql.upper().strip()
        
        # CREATE TRIGGER（必须在 FUNCTION 之前检查，因为触发器可能包含 EXECUTE FUNCTION）
        if sql_upper.startswith("CREATE") and "TRIGGER" in sql_upper:
            return self._parse_postgresql_trigger(sql)
        
        # CREATE FUNCTION
        if sql_upper.startswith("CREATE") and "FUNCTION" in sql_upper:
            return self._parse_postgresql_function(sql)
        
        # CREATE PROCEDURE
        if sql_upper.startswith("CREATE") and "PROCEDURE" in sql_upper:
            return self._parse_postgresql_procedure(sql)
        
        # DO 块
        if sql_upper.startswith("DO"):
            return self._parse_postgresql_do_block(sql)
        
        return sql, [], None
    
    def _parse_postgresql_function(self, sql: str) -> tuple[str, List[Dict[str, Any]], Optional[ProceduralInfo]]:
        """解析 PostgreSQL CREATE FUNCTION 语句。"""
        modifications = []
        
        is_replace = "OR REPLACE" in sql.upper()
        
        # 提取 $$ 或 $tag$ 包裹的函数体
        body, language = self._extract_dollar_quoted_body(sql)
        
        # 匹配 CREATE [OR REPLACE] FUNCTION [schema.]name (params) RETURNS type AS $...$ body $...$ LANGUAGE lang
        pattern = re.compile(
            r'CREATE\s+(?:OR\s+REPLACE\s+)?FUNCTION\s+'
            r'(?:(\w+)\.)?'           # schema（可选）
            r'(\w+)\s*'               # 函数名
            r'\(([^)]*)\)\s*'         # 参数列表
            r'RETURNS\s+(\S+)',       # 返回类型
            re.IGNORECASE | re.DOTALL
        )
        
        match = pattern.match(sql.strip())
        if match:
            schema_name = match.group(1)
            func_name = match.group(2)
            params_str = match.group(3) or ""
            return_type = match.group(4)
            
            parameters = self._parse_postgresql_parameters(params_str)
            
            procedural_info = ProceduralInfo(
                type="FUNCTION",
                name=func_name,
                schema_name=schema_name,
                parameters=parameters,
                return_type=return_type,
                body=body,
                language=language,
                is_replace=is_replace,
                dialect="postgresql",
            )
            
            modifications.append({
                "type": "postgresql_function",
                "name": func_name,
                "original": sql,
            })
            
            # 移除参数模式关键字（IN/OUT/INOUT），SQLGlot 不支持
            clean_params = self._clean_postgresql_params_for_sqlglot(params_str)
            processed_sql = f"CREATE PROCEDURE {func_name}({clean_params}) AS $$ SELECT 1; $$ LANGUAGE plpgsql"
            
            return processed_sql, modifications, procedural_info
        
        return sql, [], None
    
    def _parse_postgresql_procedure(self, sql: str) -> tuple[str, List[Dict[str, Any]], Optional[ProceduralInfo]]:
        """解析 PostgreSQL CREATE PROCEDURE 语句。"""
        modifications = []
        
        is_replace = "OR REPLACE" in sql.upper()
        
        body, language = self._extract_dollar_quoted_body(sql)
        
        # 匹配 CREATE [OR REPLACE] PROCEDURE [schema.]name (params) LANGUAGE lang AS $...$ body $...$
        pattern = re.compile(
            r'CREATE\s+(?:OR\s+REPLACE\s+)?PROCEDURE\s+'
            r'(?:(\w+)\.)?'           # schema（可选）
            r'(\w+)\s*'               # 过程名
            r'\(([^)]*)\)',           # 参数列表
            re.IGNORECASE | re.DOTALL
        )
        
        match = pattern.match(sql.strip())
        if match:
            schema_name = match.group(1)
            proc_name = match.group(2)
            params_str = match.group(3) or ""
            
            parameters = self._parse_postgresql_parameters(params_str)
            
            procedural_info = ProceduralInfo(
                type="PROCEDURE",
                name=proc_name,
                schema_name=schema_name,
                parameters=parameters,
                body=body,
                language=language,
                is_replace=is_replace,
                dialect="postgresql",
            )
            
            modifications.append({
                "type": "postgresql_procedure",
                "name": proc_name,
                "original": sql,
            })
            
            # 移除参数模式关键字（IN/OUT/INOUT），SQLGlot 不支持
            clean_params = self._clean_postgresql_params_for_sqlglot(params_str)
            processed_sql = f"CREATE PROCEDURE {proc_name}({clean_params}) AS $$ SELECT 1; $$ LANGUAGE plpgsql"
            
            return processed_sql, modifications, procedural_info
        
        return sql, [], None
    
    def _parse_postgresql_trigger(self, sql: str) -> tuple[str, List[Dict[str, Any]], Optional[ProceduralInfo]]:
        """解析 PostgreSQL CREATE TRIGGER 语句。"""
        modifications = []
        
        is_replace = "OR REPLACE" in sql.upper()
        
        # 匹配 CREATE [OR REPLACE] [CONSTRAINT] TRIGGER name timing event [OF column] ON table 
        # [FOR EACH ROW|STATEMENT] [WHEN (...)] EXECUTE FUNCTION/PROCEDURE func()
        # 支持 UPDATE OF column 语法
        pattern = re.compile(
            r'CREATE\s+(?:OR\s+REPLACE\s+)?(?:CONSTRAINT\s+)?TRIGGER\s+'
            r'(\w+)\s+'               # 触发器名
            r'(BEFORE|AFTER|INSTEAD\s+OF)\s+'  # 触发时机
            r'(INSERT|UPDATE|DELETE|TRUNCATE)'  # 第一个触发事件
            r'(?:\s+OF\s+\w+)?'       # OF column（可选，用于 UPDATE OF）
            r'(?:\s+OR\s+(INSERT|UPDATE|DELETE|TRUNCATE)(?:\s+OF\s+\w+)?)*\s+'  # 其他事件
            r'ON\s+(\w+(?:\.\w+)?)\s+'  # 表名
            r'(?:FOR\s+EACH\s+(ROW|STATEMENT)\s+)?'  # 触发级别（可选）
            r'(?:WHEN\s*\(([^)]+)\)\s+)?'  # WHEN 条件（可选）
            r'EXECUTE\s+(?:FUNCTION|PROCEDURE)\s+'
            r'(\w+(?:\.\w+)?)\s*\(\)',  # 执行函数
            re.IGNORECASE | re.DOTALL
        )
        
        match = pattern.match(sql.strip())
        if match:
            trigger_name = match.group(1)
            timing = match.group(2).upper().replace("  ", " ")
            event1 = match.group(3).upper()
            event2 = match.group(4)
            table_name = match.group(5)
            level = (match.group(6) or "STATEMENT").upper()
            when_condition = match.group(7)
            execute_func = match.group(8)
            
            events = [event1]
            if event2:
                events.append(event2.upper())
            
            procedural_info = ProceduralInfo(
                type="TRIGGER",
                name=trigger_name,
                timing=timing,
                events=events,
                table_name=table_name,
                level=level,
                when_condition=when_condition,
                body=f"EXECUTE FUNCTION {execute_func}()",
                is_replace=is_replace,
                dialect="postgresql",
            )
            
            modifications.append({
                "type": "postgresql_trigger",
                "name": trigger_name,
                "table": table_name,
                "original": sql,
            })
            
            processed_sql = f"CREATE PROCEDURE {trigger_name}_trigger() AS $$ SELECT 1; $$ LANGUAGE plpgsql"
            
            return processed_sql, modifications, procedural_info
        
        return sql, [], None
    
    def _parse_postgresql_do_block(self, sql: str) -> tuple[str, List[Dict[str, Any]], Optional[ProceduralInfo]]:
        """解析 PostgreSQL DO 块。"""
        modifications = []
        
        body, language = self._extract_dollar_quoted_body(sql)
        
        if body:
            procedural_info = ProceduralInfo(
                type="ANONYMOUS_BLOCK",
                name=None,
                body=body,
                language=language or "plpgsql",
                dialect="postgresql",
            )
            
            modifications.append({
                "type": "postgresql_do_block",
                "original": sql,
            })
            
            processed_sql = "SELECT 1"
            
            return processed_sql, modifications, procedural_info
        
        return sql, [], None
    
    def _extract_dollar_quoted_body(self, sql: str) -> tuple[Optional[str], Optional[str]]:
        """提取 PostgreSQL $$ 或 $tag$ 包裹的内容。
        
        Returns:
            (body, language)
        """
        # 使用预编译的正则表达式
        match = _RE_PG_DOLLAR_QUOTED.search(sql)
        body = match.group(2).strip() if match else None
        
        # 提取 LANGUAGE
        lang_match = _RE_PG_LANGUAGE.search(sql)
        language = lang_match.group(1).lower() if lang_match else None
        
        return body, language
    
    def _parse_postgresql_parameters(self, params_str: str) -> List[ParameterInfo]:
        """解析 PostgreSQL 函数/过程参数列表。"""
        if not params_str.strip():
            return []
        
        params = []
        # 简单分割参数
        for param in params_str.split(","):
            param = param.strip()
            if not param:
                continue
            
            # 匹配 [IN|OUT|INOUT] name type [DEFAULT value]
            param_pattern = re.compile(
                r'(?:(IN|OUT|INOUT)\s+)?'
                r'(\w+)\s+'
                r'(\w+(?:\([^)]*\))?)'
                r'(?:\s+DEFAULT\s+(.+))?',
                re.IGNORECASE
            )
            
            match = param_pattern.match(param)
            if match:
                params.append(ParameterInfo(
                    name=match.group(2),
                    mode=(match.group(1) or "IN").upper(),
                    datatype=match.group(3),
                    default_value=match.group(4),
                ))
            else:
                # 简单情况：只有名称和类型
                parts = param.split()
                if len(parts) >= 2:
                    params.append(ParameterInfo(
                        name=parts[0],
                        mode="IN",
                        datatype=parts[-1],
                    ))
        
        return params


def preprocess_sql(sql: str, dialect: str) -> PreprocessResult:
    """预处理 SQL 语句的便捷函数。
    
    Args:
        sql: SQL 语句
        dialect: 数据库方言
    
    Returns:
        预处理结果
    """
    preprocessor = SQLPreprocessor(dialect)
    return preprocessor.preprocess(sql)
