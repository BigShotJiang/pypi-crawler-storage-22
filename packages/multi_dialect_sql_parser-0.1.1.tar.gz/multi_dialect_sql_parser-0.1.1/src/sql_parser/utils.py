# -*- coding: utf-8 -*-
"""SQL 解析器工具函数。"""
from __future__ import annotations

from functools import lru_cache
from typing import Tuple

from sql_parser.constants import DIALECT_MAP


@lru_cache(maxsize=8)
def get_sqlglot_dialect(dialect: str) -> str:
    """获取 SQLGlot 方言名称，带缓存。
    
    Args:
        dialect: 用户指定的方言
    
    Returns:
        SQLGlot 支持的方言名称
    """
    return DIALECT_MAP.get(dialect, dialect)


def calculate_error_position(sql: str, offset: int) -> Tuple[int, int]:
    """根据字符偏移量计算行号和列号。
    
    Args:
        sql: 原始 SQL 文本
        offset: 字符偏移量（从 0 开始）
    
    Returns:
        (行号, 列号)，均从 1 开始
    """
    if offset < 0 or offset > len(sql):
        return 1, 1
    lines = sql[:offset].split("\n")
    return len(lines), len(lines[-1]) + 1


def extract_error_context(sql: str, offset: int, context_size: int = 30) -> str:
    """提取错误位置的上下文。
    
    Args:
        sql: 原始 SQL 文本
        offset: 错误位置偏移量
        context_size: 上下文大小（前后各多少字符）
    
    Returns:
        上下文字符串
    """
    start = max(0, offset - context_size)
    end = min(len(sql), offset + context_size)
    prefix = "..." if start > 0 else ""
    suffix = "..." if end < len(sql) else ""
    return f"{prefix}{sql[start:end]}{suffix}"


def mark_error_position(sql: str, offset: int, length: int = 1) -> str:
    """生成带错误标记的 SQL 文本。
    
    Args:
        sql: 原始 SQL 文本
        offset: 错误位置偏移量
        length: 错误长度
    
    Returns:
        带标记的 SQL 文本
    """
    lines = sql.split('\n')
    line_num, col_num = calculate_error_position(sql, offset)
    
    if line_num <= len(lines):
        error_line = lines[line_num - 1]
        marker = ' ' * (col_num - 1) + '^' * length
        return f"{error_line}\n{marker}"
    
    return sql
