"""Tests for sql_parser."""
