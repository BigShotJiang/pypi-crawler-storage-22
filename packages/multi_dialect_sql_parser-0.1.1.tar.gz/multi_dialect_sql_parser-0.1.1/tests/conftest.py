"""pytest 共享 fixtures 和配置。"""
import pytest
from typing import Any
from sql_parser import SQLParser
from sql_parser.models import ParseResult


@pytest.fixture
def mysql_parser() -> SQLParser:
    """MySQL 解析器 fixture。"""
    return SQLParser(dialect="mysql")


@pytest.fixture
def postgresql_parser() -> SQLParser:
    """PostgreSQL 解析器 fixture。"""
    return SQLParser(dialect="postgresql")


@pytest.fixture
def oracle_parser() -> SQLParser:
    """Oracle 解析器 fixture。"""
    return SQLParser(dialect="oracle")


@pytest.fixture
def tidb_parser() -> SQLParser:
    """TiDB 解析器 fixture。"""
    return SQLParser(dialect="tidb")


@pytest.fixture
def oceanbase_mysql_parser() -> SQLParser:
    """OceanBase MySQL 模式解析器 fixture。"""
    return SQLParser(dialect="oceanbase-mysql")


@pytest.fixture
def oceanbase_oracle_parser() -> SQLParser:
    """OceanBase Oracle 模式解析器 fixture。"""
    return SQLParser(dialect="oceanbase-oracle")


def verify_parse_result(result: ParseResult, expected: dict[str, Any]) -> None:
    """验证解析结果是否符合期望。
    
    支持的验证字段:
    - success: 是否解析成功
    - dialect: 方言
    - statement_type: 语句类型
    - tables: 表列表（完整验证）
    - tables_count: 表数量（仅验证数量）
    - tables_has_dual: 是否包含 DUAL 表
    - columns: 列列表（完整验证）
    - columns_count: 列数量（仅验证数量）
    - conditions: 条件列表
    - conditions_count: 条件数量
    - joins: JOIN 列表（完整验证）
    - joins_count: JOIN 数量
    - group_by: GROUP BY 列
    - order_by: ORDER BY 列
    - limit: LIMIT 值
    - offset_value: OFFSET 值
    - errors: 错误列表
    - warnings: 警告列表
    - oracle_info: Oracle 特有信息
    - tidb_info: TiDB 特有信息
    - oceanbase_info: OceanBase 特有信息
    """
    # 基础字段验证
    if "success" in expected:
        assert result.success == expected["success"], f"success 不匹配: {result.success} != {expected['success']}"
    
    if "dialect" in expected:
        assert result.dialect == expected["dialect"], f"dialect 不匹配: {result.dialect} != {expected['dialect']}"
    
    if "statement_type" in expected:
        assert result.statement_type == expected["statement_type"], f"statement_type 不匹配: {result.statement_type} != {expected['statement_type']}"
    
    # 表验证
    if "tables" in expected:
        _verify_tables(result.tables, expected["tables"])
    
    if "tables_count" in expected:
        assert len(result.tables) == expected["tables_count"], f"tables 数量不匹配: {len(result.tables)} != {expected['tables_count']}"
    
    if "tables_has_dual" in expected and expected["tables_has_dual"]:
        assert any(t.name.upper() == "DUAL" for t in result.tables), "未找到 DUAL 表"
    
    # 列验证
    if "columns" in expected:
        _verify_columns(result.columns, expected["columns"])
    
    if "columns_count" in expected:
        assert len(result.columns) == expected["columns_count"], f"columns 数量不匹配: {len(result.columns)} != {expected['columns_count']}"
    
    # 条件验证
    if "conditions" in expected:
        assert len(result.conditions) == len(expected["conditions"]), f"conditions 数量不匹配"
    
    if "conditions_count" in expected:
        assert len(result.conditions) == expected["conditions_count"], f"conditions 数量不匹配: {len(result.conditions)} != {expected['conditions_count']}"
    
    # JOIN 验证
    if "joins" in expected:
        _verify_joins(result.joins, expected["joins"])
    
    if "joins_count" in expected:
        assert len(result.joins) == expected["joins_count"], f"joins 数量不匹配: {len(result.joins)} != {expected['joins_count']}"
    
    # GROUP BY 验证
    if "group_by" in expected:
        assert result.group_by == expected["group_by"], f"group_by 不匹配: {result.group_by} != {expected['group_by']}"
    
    # ORDER BY 验证
    if "order_by" in expected:
        _verify_order_by(result.order_by, expected["order_by"])
    
    # LIMIT / OFFSET 验证
    if "limit" in expected:
        assert result.limit == expected["limit"], f"limit 不匹配: {result.limit} != {expected['limit']}"
    
    if "offset_value" in expected:
        assert result.offset_value == expected["offset_value"], f"offset_value 不匹配: {result.offset_value} != {expected['offset_value']}"
    
    # 错误/警告验证
    if "errors" in expected:
        assert len(result.errors) == len(expected["errors"]), f"errors 数量不匹配: {len(result.errors)} != {len(expected['errors'])}"
    
    if "warnings" in expected:
        assert len(result.warnings) == len(expected["warnings"]), f"warnings 数量不匹配: {len(result.warnings)} != {len(expected['warnings'])}"
    
    # Oracle 特有信息验证
    if "oracle_info" in expected:
        _verify_oracle_info(result.oracle_info, expected["oracle_info"])
    
    # TiDB 特有信息验证
    if "tidb_info" in expected:
        _verify_tidb_info(result.tidb_info, expected["tidb_info"])
    
    # OceanBase 特有信息验证
    if "oceanbase_info" in expected:
        _verify_oceanbase_info(result.oceanbase_info, expected["oceanbase_info"])


def _normalize_empty(value: str | None) -> str | None:
    """将空字符串标准化为 None。"""
    if value == "" or value is None:
        return None
    return value


def _verify_tables(actual: list, expected: list[dict]) -> None:
    """验证表列表。"""
    assert len(actual) == len(expected), f"tables 数量不匹配: {len(actual)} != {len(expected)}"
    
    for i, (act, exp) in enumerate(zip(actual, expected)):
        if "name" in exp:
            assert act.name == exp["name"], f"tables[{i}].name 不匹配: {act.name} != {exp['name']}"
        if "schema_name" in exp:
            actual_schema = _normalize_empty(act.schema_name)
            expected_schema = _normalize_empty(exp["schema_name"])
            assert actual_schema == expected_schema, f"tables[{i}].schema_name 不匹配: {actual_schema} != {expected_schema}"
        if "alias" in exp:
            actual_alias = _normalize_empty(act.alias)
            expected_alias = _normalize_empty(exp["alias"])
            assert actual_alias == expected_alias, f"tables[{i}].alias 不匹配: {actual_alias} != {expected_alias}"
        if "type" in exp:
            assert act.type == exp["type"], f"tables[{i}].type 不匹配: {act.type} != {exp['type']}"


def _verify_columns(actual: list, expected: list[dict]) -> None:
    """验证列列表。"""
    assert len(actual) == len(expected), f"columns 数量不匹配: {len(actual)} != {len(expected)}"
    
    for i, (act, exp) in enumerate(zip(actual, expected)):
        if "name" in exp:
            assert act.name == exp["name"], f"columns[{i}].name 不匹配: {act.name} != {exp['name']}"
        if "table" in exp:
            assert act.table == exp["table"], f"columns[{i}].table 不匹配: {act.table} != {exp['table']}"
        if "alias" in exp:
            assert act.alias == exp["alias"], f"columns[{i}].alias 不匹配: {act.alias} != {exp['alias']}"
        if "expression" in exp:
            assert act.expression == exp["expression"], f"columns[{i}].expression 不匹配: {act.expression} != {exp['expression']}"


def _verify_joins(actual: list, expected: list[dict]) -> None:
    """验证 JOIN 列表。"""
    assert len(actual) == len(expected), f"joins 数量不匹配: {len(actual)} != {len(expected)}"
    
    for i, (act, exp) in enumerate(zip(actual, expected)):
        if "type" in exp:
            assert act.type == exp["type"], f"joins[{i}].type 不匹配: {act.type} != {exp['type']}"
        if "table" in exp:
            _verify_single_table(act.table, exp["table"], f"joins[{i}].table")
        if "condition" in exp:
            assert act.condition == exp["condition"], f"joins[{i}].condition 不匹配: {act.condition} != {exp['condition']}"


def _verify_single_table(actual, expected: dict, prefix: str) -> None:
    """验证单个表引用。"""
    if "name" in expected:
        assert actual.name == expected["name"], f"{prefix}.name 不匹配: {actual.name} != {expected['name']}"
    if "schema_name" in expected:
        actual_schema = _normalize_empty(actual.schema_name)
        expected_schema = _normalize_empty(expected["schema_name"])
        assert actual_schema == expected_schema, f"{prefix}.schema_name 不匹配"
    if "alias" in expected:
        actual_alias = _normalize_empty(actual.alias)
        expected_alias = _normalize_empty(expected["alias"])
        assert actual_alias == expected_alias, f"{prefix}.alias 不匹配: {actual_alias} != {expected_alias}"
    if "type" in expected:
        assert actual.type == expected["type"], f"{prefix}.type 不匹配"


def _verify_order_by(actual: list, expected: list[dict]) -> None:
    """验证 ORDER BY 列表。"""
    assert len(actual) == len(expected), f"order_by 数量不匹配: {len(actual)} != {len(expected)}"
    
    for i, (act, exp) in enumerate(zip(actual, expected)):
        if "column" in exp:
            assert act.column == exp["column"], f"order_by[{i}].column 不匹配: {act.column} != {exp['column']}"
        if "direction" in exp:
            assert act.direction == exp["direction"], f"order_by[{i}].direction 不匹配: {act.direction} != {exp['direction']}"


def _verify_oracle_info(actual, expected: dict) -> None:
    """验证 Oracle 特有信息。"""
    if actual is None:
        assert expected is None or expected == {}, "oracle_info 应该存在"
        return
    
    if "hierarchy" in expected:
        assert actual.hierarchy == expected["hierarchy"], f"oracle_info.hierarchy 不匹配"
    if "sequences" in expected:
        assert actual.sequences == expected["sequences"], f"oracle_info.sequences 不匹配"
    if "pseudo_columns" in expected:
        for col in expected["pseudo_columns"]:
            assert col in actual.pseudo_columns, f"oracle_info.pseudo_columns 缺少 {col}"
    if "merge_info" in expected:
        assert actual.merge_info == expected["merge_info"], f"oracle_info.merge_info 不匹配"


def _verify_tidb_info(actual, expected: dict) -> None:
    """验证 TiDB 特有信息。"""
    if actual is None:
        assert expected is None or expected == {}, "tidb_info 应该存在"
        return
    
    if "hints" in expected:
        _verify_hints(actual.hints, expected["hints"], "tidb_info")
    if "hints_count" in expected:
        assert len(actual.hints) == expected["hints_count"], f"tidb_info.hints 数量不匹配"
    if "auto_random_columns" in expected:
        for col in expected["auto_random_columns"]:
            assert col in actual.auto_random_columns, f"tidb_info.auto_random_columns 缺少 {col}"
    if "preprocessed" in expected:
        assert actual.preprocessed == expected["preprocessed"], f"tidb_info.preprocessed 不匹配"


def _verify_oceanbase_info(actual, expected: dict) -> None:
    """验证 OceanBase 特有信息。"""
    if actual is None:
        assert expected is None or expected == {}, "oceanbase_info 应该存在"
        return
    
    if "mode" in expected:
        assert actual.mode == expected["mode"], f"oceanbase_info.mode 不匹配: {actual.mode} != {expected['mode']}"
    if "hints" in expected:
        _verify_hints(actual.hints, expected["hints"], "oceanbase_info")
    if "hints_count" in expected:
        assert len(actual.hints) == expected["hints_count"], f"oceanbase_info.hints 数量不匹配"
    if "preprocessed" in expected:
        assert actual.preprocessed == expected["preprocessed"], f"oceanbase_info.preprocessed 不匹配"


def _verify_hints(actual: list, expected: list[dict], prefix: str) -> None:
    """验证 Hint 列表。"""
    assert len(actual) == len(expected), f"{prefix}.hints 数量不匹配: {len(actual)} != {len(expected)}"
    
    for i, (act, exp) in enumerate(zip(actual, expected)):
        if "name" in exp:
            assert act.name == exp["name"], f"{prefix}.hints[{i}].name 不匹配: {act.name} != {exp['name']}"
        if "type" in exp:
            assert act.type == exp["type"], f"{prefix}.hints[{i}].type 不匹配: {act.type} != {exp['type']}"
        if "args" in exp:
            assert act.args == exp["args"], f"{prefix}.hints[{i}].args 不匹配: {act.args} != {exp['args']}"
