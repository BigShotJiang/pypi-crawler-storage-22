"""MySQL 测试 SQL 脚本及期望结果定义。

每个测试用例包含:
- sql: SQL 脚本
- expected: 期望的解析结果（完整验证所有字段）
"""
from typing import Any

# MySQL 测试用例定义
MYSQL_TEST_CASES: list[dict[str, Any]] = [
    # ==================== 基础 SELECT 测试 ====================
    {
        "name": "simple_select",
        "description": "简单 SELECT 语句",
        "sql": "SELECT id, name FROM users",
        "expected": {
            "success": True,
            "dialect": "mysql",
            "statement_type": "SELECT",
            "tables": [{"name": "users"}],
            "columns_count": 2,
            "errors": [],
        },
    },
    {
        "name": "backtick_identifier",
        "description": "反引号标识符解析",
        "sql": "SELECT `id`, `user_name` FROM `user_table`",
        "expected": {
            "success": True,
            "dialect": "mysql",
            "statement_type": "SELECT",
            "tables": [{"name": "user_table"}],
            "errors": [],
        },
    },
    {
        "name": "select_with_alias",
        "description": "带别名的 SELECT",
        "sql": "SELECT u.id AS user_id, u.name AS user_name FROM users AS u",
        "expected": {
            "success": True,
            "dialect": "mysql",
            "statement_type": "SELECT",
            "tables": [{"name": "users", "alias": "u"}],
            "errors": [],
        },
    },
    # ==================== LIMIT / OFFSET 测试 ====================
    {
        "name": "limit_clause",
        "description": "LIMIT 子句解析",
        "sql": "SELECT * FROM users LIMIT 10",
        "expected": {
            "success": True,
            "dialect": "mysql",
            "statement_type": "SELECT",
            "tables": [{"name": "users"}],
            "limit": 10,
            "offset_value": None,
            "errors": [],
        },
    },
    {
        "name": "limit_offset",
        "description": "LIMIT OFFSET 解析",
        "sql": "SELECT * FROM users LIMIT 10 OFFSET 20",
        "expected": {
            "success": True,
            "dialect": "mysql",
            "statement_type": "SELECT",
            "tables": [{"name": "users"}],
            "limit": 10,
            "offset_value": 20,
            "errors": [],
        },
    },
    # ==================== WHERE 条件测试 ====================
    {
        "name": "where_simple",
        "description": "简单 WHERE 条件",
        "sql": "SELECT * FROM users WHERE age > 18",
        "expected": {
            "success": True,
            "dialect": "mysql",
            "statement_type": "SELECT",
            "tables": [{"name": "users"}],
            "conditions_count": 1,
            "errors": [],
        },
    },
    {
        "name": "where_multiple_conditions",
        "description": "多条件 WHERE",
        "sql": "SELECT * FROM users WHERE age > 18 AND status = 'active'",
        "expected": {
            "success": True,
            "dialect": "mysql",
            "statement_type": "SELECT",
            "tables": [{"name": "users"}],
            "conditions_count": 1,
            "errors": [],
        },
    },
    # ==================== JOIN 测试 ====================
    {
        "name": "inner_join",
        "description": "INNER JOIN",
        "sql": "SELECT * FROM users u INNER JOIN orders o ON u.id = o.user_id",
        "expected": {
            "success": True,
            "dialect": "mysql",
            "statement_type": "SELECT",
            "tables_count": 2,
            "joins": [{"type": "INNER", "table": {"name": "orders", "alias": "o"}}],
            "errors": [],
        },
    },
    {
        "name": "left_join",
        "description": "LEFT JOIN",
        "sql": "SELECT * FROM users u LEFT JOIN orders o ON u.id = o.user_id",
        "expected": {
            "success": True,
            "dialect": "mysql",
            "statement_type": "SELECT",
            "tables_count": 2,
            "joins": [{"type": "LEFT", "table": {"name": "orders", "alias": "o"}}],
            "errors": [],
        },
    },
    {
        "name": "multiple_joins",
        "description": "多表 JOIN",
        "sql": """
        SELECT * FROM users u
        LEFT JOIN orders o ON u.id = o.user_id
        LEFT JOIN products p ON o.product_id = p.id
        """,
        "expected": {
            "success": True,
            "dialect": "mysql",
            "statement_type": "SELECT",
            "tables_count": 3,
            "joins_count": 2,
            "errors": [],
        },
    },
    # ==================== GROUP BY / ORDER BY 测试 ====================
    {
        "name": "group_by",
        "description": "GROUP BY",
        "sql": "SELECT department, COUNT(*) FROM employees GROUP BY department",
        "expected": {
            "success": True,
            "dialect": "mysql",
            "statement_type": "SELECT",
            "tables": [{"name": "employees"}],
            "group_by": ["department"],
            "errors": [],
        },
    },
    {
        "name": "order_by_desc",
        "description": "ORDER BY DESC",
        "sql": "SELECT * FROM users ORDER BY created_at DESC",
        "expected": {
            "success": True,
            "dialect": "mysql",
            "statement_type": "SELECT",
            "tables": [{"name": "users"}],
            "order_by": [{"column": "created_at", "direction": "DESC"}],
            "errors": [],
        },
    },
    {
        "name": "group_order_combined",
        "description": "GROUP BY + ORDER BY 组合",
        "sql": """
        SELECT department, COUNT(*) as cnt
        FROM employees
        GROUP BY department
        ORDER BY cnt DESC
        """,
        "expected": {
            "success": True,
            "dialect": "mysql",
            "statement_type": "SELECT",
            "tables": [{"name": "employees"}],
            "group_by": ["department"],
            "order_by": [{"column": "cnt", "direction": "DESC"}],
            "errors": [],
        },
    },
    # ==================== MySQL 特有函数测试 ====================
    {
        "name": "ifnull_function",
        "description": "IFNULL 函数",
        "sql": "SELECT IFNULL(name, 'unknown') FROM users",
        "expected": {
            "success": True,
            "dialect": "mysql",
            "statement_type": "SELECT",
            "tables": [{"name": "users"}],
            "errors": [],
        },
    },
    {
        "name": "group_concat",
        "description": "GROUP_CONCAT 函数",
        "sql": "SELECT GROUP_CONCAT(name) FROM users GROUP BY department",
        "expected": {
            "success": True,
            "dialect": "mysql",
            "statement_type": "SELECT",
            "tables": [{"name": "users"}],
            "group_by": ["department"],
            "errors": [],
        },
    },
    # ==================== DDL 语句测试 ====================
    {
        "name": "create_table",
        "description": "CREATE TABLE",
        "sql": """
        CREATE TABLE users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
            email VARCHAR(255) UNIQUE
        )
        """,
        "expected": {
            "success": True,
            "dialect": "mysql",
            "statement_type": "CREATE",
            "errors": [],
        },
    },
    {
        "name": "insert",
        "description": "INSERT 语句",
        "sql": "INSERT INTO users (name, email) VALUES ('John', 'john@example.com')",
        "expected": {
            "success": True,
            "dialect": "mysql",
            "statement_type": "INSERT",
            "tables": [{"name": "users"}],
            "errors": [],
        },
    },
    {
        "name": "update",
        "description": "UPDATE 语句",
        "sql": "UPDATE users SET name = 'Jane' WHERE id = 1",
        "expected": {
            "success": True,
            "dialect": "mysql",
            "statement_type": "UPDATE",
            "tables": [{"name": "users"}],
            "conditions_count": 1,
            "errors": [],
        },
    },
    {
        "name": "delete",
        "description": "DELETE 语句",
        "sql": "DELETE FROM users WHERE id = 1",
        "expected": {
            "success": True,
            "dialect": "mysql",
            "statement_type": "DELETE",
            "tables": [{"name": "users"}],
            "conditions_count": 1,
            "errors": [],
        },
    },
    # ==================== 补充用例：确保每种类型至少 2 个 ====================
    {
        "name": "select_with_alias_2",
        "description": "带别名的 SELECT（补充）",
        "sql": "SELECT t.col1 AS c1, t.col2 AS c2 FROM table1 AS t WHERE t.status = 1",
        "expected": {
            "success": True,
            "dialect": "mysql",
            "statement_type": "SELECT",
            "errors": [],
        },
    },
    {
        "name": "right_join",
        "description": "RIGHT JOIN",
        "sql": "SELECT * FROM users u RIGHT JOIN orders o ON u.id = o.user_id",
        "expected": {
            "success": True,
            "dialect": "mysql",
            "statement_type": "SELECT",
            "tables_count": 2,
            "errors": [],
        },
    },
    {
        "name": "cross_join",
        "description": "CROSS JOIN",
        "sql": "SELECT * FROM colors CROSS JOIN sizes",
        "expected": {
            "success": True,
            "dialect": "mysql",
            "statement_type": "SELECT",
            "tables_count": 2,
            "errors": [],
        },
    },
    {
        "name": "group_by_having",
        "description": "GROUP BY + HAVING",
        "sql": "SELECT department, COUNT(*) as cnt FROM employees GROUP BY department HAVING cnt > 5",
        "expected": {
            "success": True,
            "dialect": "mysql",
            "statement_type": "SELECT",
            "group_by": ["department"],
            "errors": [],
        },
    },
    {
        "name": "order_by_multiple",
        "description": "多列 ORDER BY",
        "sql": "SELECT * FROM users ORDER BY last_name ASC, first_name DESC",
        "expected": {
            "success": True,
            "dialect": "mysql",
            "statement_type": "SELECT",
            "errors": [],
        },
    },
    {
        "name": "subquery_in_where",
        "description": "WHERE 子查询",
        "sql": "SELECT * FROM users WHERE department_id IN (SELECT id FROM departments WHERE active = 1)",
        "expected": {
            "success": True,
            "dialect": "mysql",
            "statement_type": "SELECT",
            "errors": [],
        },
    },
    {
        "name": "subquery_in_from",
        "description": "FROM 子查询",
        "sql": "SELECT t.* FROM (SELECT id, name FROM users WHERE status = 'active') AS t",
        "expected": {
            "success": True,
            "dialect": "mysql",
            "statement_type": "SELECT",
            "errors": [],
        },
    },
    {
        "name": "cte_simple",
        "description": "CTE (WITH 子句)",
        "sql": """
        WITH active_users AS (
            SELECT * FROM users WHERE status = 'active'
        )
        SELECT * FROM active_users WHERE created_at > '2024-01-01'
        """,
        "expected": {
            "success": True,
            "dialect": "mysql",
            "statement_type": "SELECT",
            "errors": [],
        },
    },
    {
        "name": "cte_multiple",
        "description": "多个 CTE",
        "sql": """
        WITH 
            active_users AS (SELECT * FROM users WHERE status = 'active'),
            recent_orders AS (SELECT * FROM orders WHERE order_date > '2024-01-01')
        SELECT u.*, o.order_id FROM active_users u JOIN recent_orders o ON u.id = o.user_id
        """,
        "expected": {
            "success": True,
            "dialect": "mysql",
            "statement_type": "SELECT",
            "errors": [],
        },
    },
    {
        "name": "window_row_number",
        "description": "ROW_NUMBER 窗口函数",
        "sql": """
        SELECT 
            name, salary,
            ROW_NUMBER() OVER (PARTITION BY department ORDER BY salary DESC) as rank
        FROM employees
        """,
        "expected": {
            "success": True,
            "dialect": "mysql",
            "statement_type": "SELECT",
            "errors": [],
        },
    },
    {
        "name": "window_rank",
        "description": "RANK 窗口函数",
        "sql": """
        SELECT 
            name, salary,
            RANK() OVER (ORDER BY salary DESC) as salary_rank
        FROM employees
        """,
        "expected": {
            "success": True,
            "dialect": "mysql",
            "statement_type": "SELECT",
            "errors": [],
        },
    },
    {
        "name": "union_all",
        "description": "UNION ALL",
        "sql": """
        SELECT id, name FROM users WHERE status = 'active'
        UNION ALL
        SELECT id, name FROM archived_users
        """,
        "expected": {
            "success": True,
            "dialect": "mysql",
            "statement_type": "SELECT",
            "errors": [],
        },
    },
    {
        "name": "union_distinct",
        "description": "UNION DISTINCT",
        "sql": """
        SELECT city FROM customers
        UNION
        SELECT city FROM suppliers
        """,
        "expected": {
            "success": True,
            "dialect": "mysql",
            "statement_type": "SELECT",
            "errors": [],
        },
    },
    {
        "name": "case_when",
        "description": "CASE WHEN 表达式",
        "sql": """
        SELECT name,
            CASE 
                WHEN salary > 10000 THEN 'high'
                WHEN salary > 5000 THEN 'medium'
                ELSE 'low'
            END as salary_level
        FROM employees
        """,
        "expected": {
            "success": True,
            "dialect": "mysql",
            "statement_type": "SELECT",
            "errors": [],
        },
    },
    {
        "name": "insert_multiple_rows",
        "description": "INSERT 多行",
        "sql": "INSERT INTO users (name, email) VALUES ('John', 'john@example.com'), ('Jane', 'jane@example.com')",
        "expected": {
            "success": True,
            "dialect": "mysql",
            "statement_type": "INSERT",
            "errors": [],
        },
    },
    {
        "name": "insert_select",
        "description": "INSERT SELECT",
        "sql": "INSERT INTO users_backup (id, name) SELECT id, name FROM users WHERE status = 'active'",
        "expected": {
            "success": True,
            "dialect": "mysql",
            "statement_type": "INSERT",
            "errors": [],
        },
    },
    {
        "name": "update_multiple_columns",
        "description": "UPDATE 多列",
        "sql": "UPDATE users SET name = 'Jane', email = 'jane@new.com', updated_at = NOW() WHERE id = 1",
        "expected": {
            "success": True,
            "dialect": "mysql",
            "statement_type": "UPDATE",
            "errors": [],
        },
    },
    {
        "name": "delete_with_limit",
        "description": "DELETE 带 LIMIT",
        "sql": "DELETE FROM logs WHERE created_at < '2024-01-01' LIMIT 1000",
        "expected": {
            "success": True,
            "dialect": "mysql",
            "statement_type": "DELETE",
            "errors": [],
        },
    },
    {
        "name": "create_table_with_index",
        "description": "CREATE TABLE 带索引",
        "sql": """
        CREATE TABLE orders (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            total DECIMAL(10,2),
            INDEX idx_user_id (user_id)
        )
        """,
        "expected": {
            "success": True,
            "dialect": "mysql",
            "statement_type": "CREATE",
            "errors": [],
        },
    },
    {
        "name": "alter_table_add_column",
        "description": "ALTER TABLE 添加列",
        "sql": "ALTER TABLE users ADD COLUMN phone VARCHAR(20) AFTER email",
        "expected": {
            "success": True,
            "dialect": "mysql",
            "statement_type": "ALTER",
            "errors": [],
        },
    },
    {
        "name": "drop_table",
        "description": "DROP TABLE",
        "sql": "DROP TABLE IF EXISTS temp_users",
        "expected": {
            "success": True,
            "dialect": "mysql",
            "statement_type": "DROP",
            "errors": [],
        },
    },
    {
        "name": "coalesce_function",
        "description": "COALESCE 函数",
        "sql": "SELECT COALESCE(nickname, name, 'Anonymous') as display_name FROM users",
        "expected": {
            "success": True,
            "dialect": "mysql",
            "statement_type": "SELECT",
            "errors": [],
        },
    },
    {
        "name": "date_functions",
        "description": "日期函数",
        "sql": "SELECT DATE_FORMAT(created_at, '%Y-%m-%d'), DATEDIFF(NOW(), created_at) FROM users",
        "expected": {
            "success": True,
            "dialect": "mysql",
            "statement_type": "SELECT",
            "errors": [],
        },
    },
    {
        "name": "string_functions",
        "description": "字符串函数",
        "sql": "SELECT CONCAT(first_name, ' ', last_name), UPPER(email), LENGTH(name) FROM users",
        "expected": {
            "success": True,
            "dialect": "mysql",
            "statement_type": "SELECT",
            "errors": [],
        },
    },
    {
        "name": "aggregate_functions",
        "description": "聚合函数",
        "sql": "SELECT COUNT(*), SUM(amount), AVG(amount), MIN(amount), MAX(amount) FROM orders",
        "expected": {
            "success": True,
            "dialect": "mysql",
            "statement_type": "SELECT",
            "errors": [],
        },
    },
]
