"""OceanBase 测试 SQL 脚本及期望结果定义。"""
from typing import Any

OCEANBASE_MYSQL_TEST_CASES: list[dict[str, Any]] = [
    {
        "name": "simple_select",
        "description": "简单 SELECT 语句",
        "sql": "SELECT id, name FROM users",
        "expected": {
            "success": True,
            "dialect": "oceanbase-mysql",
            "statement_type": "SELECT",
            "tables": [{"name": "users"}],
            "columns_count": 2,
            "errors": [],
            "oceanbase_info": {"mode": "mysql", "hints": [], "preprocessed": False},
        },
    },
    {
        "name": "backtick_identifier",
        "description": "反引号标识符（MySQL 兼容）",
        "sql": "SELECT `id`, `user_name` FROM `user_table`",
        "expected": {
            "success": True,
            "dialect": "oceanbase-mysql",
            "statement_type": "SELECT",
            "tables": [{"name": "user_table"}],
            "oceanbase_info": {"mode": "mysql"},
            "errors": [],
        },
    },
    {
        "name": "limit_clause",
        "description": "LIMIT 子句（MySQL 兼容）",
        "sql": "SELECT * FROM users LIMIT 10",
        "expected": {
            "success": True,
            "dialect": "oceanbase-mysql",
            "statement_type": "SELECT",
            "tables": [{"name": "users"}],
            "limit": 10,
            "oceanbase_info": {"mode": "mysql"},
            "errors": [],
        },
    },
    {
        "name": "join",
        "description": "JOIN（MySQL 兼容）",
        "sql": "SELECT * FROM users u LEFT JOIN orders o ON u.id = o.user_id",
        "expected": {
            "success": True,
            "dialect": "oceanbase-mysql",
            "statement_type": "SELECT",
            "tables_count": 2,
            "joins": [{"type": "LEFT", "table": {"name": "orders", "alias": "o"}}],
            "oceanbase_info": {"mode": "mysql"},
            "errors": [],
        },
    },
    {
        "name": "mysql_functions",
        "description": "MySQL 函数",
        "sql": "SELECT IFNULL(name, 'unknown'), GROUP_CONCAT(tag) FROM users GROUP BY id",
        "expected": {
            "success": True,
            "dialect": "oceanbase-mysql",
            "statement_type": "SELECT",
            "tables": [{"name": "users"}],
            "group_by": ["id"],
            "oceanbase_info": {"mode": "mysql"},
            "errors": [],
        },
    },
    {
        "name": "parallel_hint",
        "description": "PARALLEL Hint",
        "sql": "SELECT /*+ PARALLEL(4) */ * FROM large_table",
        "expected": {
            "success": True,
            "dialect": "oceanbase-mysql",
            "statement_type": "SELECT",
            "tables": [{"name": "large_table"}],
            "oceanbase_info": {
                "mode": "mysql",
                "hints": [{"name": "PARALLEL", "type": "parallel_hint", "args": "4"}],
            },
            "errors": [],
        },
    },
    {
        "name": "index_hint",
        "description": "INDEX Hint",
        "sql": "SELECT /*+ INDEX(t idx_name) */ * FROM t WHERE id = 1",
        "expected": {
            "success": True,
            "dialect": "oceanbase-mysql",
            "statement_type": "SELECT",
            "tables": [{"name": "t"}],
            "oceanbase_info": {
                "mode": "mysql",
                "hints": [{"name": "INDEX", "type": "index_hint", "args": "t idx_name"}],
            },
            "errors": [],
        },
    },
    {
        "name": "use_hash_hint",
        "description": "USE_HASH Hint",
        "sql": "SELECT /*+ USE_HASH(t1, t2) */ * FROM t1 JOIN t2 ON t1.id = t2.id",
        "expected": {
            "success": True,
            "dialect": "oceanbase-mysql",
            "statement_type": "SELECT",
            "oceanbase_info": {
                "mode": "mysql",
                "hints": [{"name": "USE_HASH", "type": "join_hint", "args": "t1, t2"}],
            },
            "errors": [],
        },
    },
    {
        "name": "leading_hint",
        "description": "LEADING Hint",
        "sql": "SELECT /*+ LEADING(t1 t2 t3) */ * FROM t1, t2, t3 WHERE t1.id = t2.id AND t2.id = t3.id",
        "expected": {
            "success": True,
            "dialect": "oceanbase-mysql",
            "statement_type": "SELECT",
            "oceanbase_info": {
                "mode": "mysql",
                "hints": [{"name": "LEADING", "type": "join_order_hint", "args": "t1 t2 t3"}],
            },
            "errors": [],
        },
    },
    {
        "name": "multiple_hints",
        "description": "多个 Hint",
        "sql": "SELECT /*+ PARALLEL(4) */ /*+ INDEX(t idx1) */ * FROM t",
        "expected": {
            "success": True,
            "dialect": "oceanbase-mysql",
            "statement_type": "SELECT",
            "tables": [{"name": "t"}],
            "oceanbase_info": {"mode": "mysql", "hints_count": 2},
            "errors": [],
        },
    },
    {
        "name": "create_table",
        "description": "CREATE TABLE",
        "sql": """
        CREATE TABLE users (
            id BIGINT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100) NOT NULL
        )
        """,
        "expected": {
            "success": True,
            "dialect": "oceanbase-mysql",
            "statement_type": "CREATE",
            "oceanbase_info": {"mode": "mysql"},
            "errors": [],
        },
    },
    {
        "name": "insert",
        "description": "INSERT",
        "sql": "INSERT INTO users (name) VALUES ('John')",
        "expected": {
            "success": True,
            "dialect": "oceanbase-mysql",
            "statement_type": "INSERT",
            "tables": [{"name": "users"}],
            "oceanbase_info": {"mode": "mysql"},
            "errors": [],
        },
    },
    {
        "name": "subquery",
        "description": "子查询",
        "sql": """
        SELECT * FROM users
        WHERE department_id IN (
            SELECT id FROM departments WHERE status = 'active'
        )
        """,
        "expected": {
            "success": True,
            "dialect": "oceanbase-mysql",
            "statement_type": "SELECT",
            "oceanbase_info": {"mode": "mysql"},
            "errors": [],
        },
    },
    {
        "name": "cte",
        "description": "CTE",
        "sql": """
        WITH active_users AS (
            SELECT * FROM users WHERE status = 'active'
        )
        SELECT * FROM active_users
        """,
        "expected": {
            "success": True,
            "dialect": "oceanbase-mysql",
            "statement_type": "SELECT",
            "oceanbase_info": {"mode": "mysql"},
            "errors": [],
        },
    },
    {
        "name": "window_function",
        "description": "窗口函数",
        "sql": """
        SELECT 
            name,
            salary,
            ROW_NUMBER() OVER (PARTITION BY department ORDER BY salary DESC) as rank
        FROM employees
        """,
        "expected": {
            "success": True,
            "dialect": "oceanbase-mysql",
            "statement_type": "SELECT",
            "tables": [{"name": "employees"}],
            "oceanbase_info": {"mode": "mysql"},
            "errors": [],
        },
    },
]

OCEANBASE_ORACLE_TEST_CASES: list[dict[str, Any]] = [
    {
        "name": "simple_select",
        "description": "简单 SELECT 语句",
        "sql": "SELECT id, name FROM users",
        "expected": {
            "success": True,
            "dialect": "oceanbase-oracle",
            "statement_type": "SELECT",
            "tables": [{"name": "users"}],
            "columns_count": 2,
            "errors": [],
            "oceanbase_info": {"mode": "oracle", "hints": [], "preprocessed": False},
        },
    },
    {
        "name": "double_quote_identifier",
        "description": "双引号标识符（Oracle 兼容）",
        "sql": 'SELECT "id", "user_name" FROM "user_table"',
        "expected": {
            "success": True,
            "dialect": "oceanbase-oracle",
            "statement_type": "SELECT",
            "tables": [{"name": "user_table"}],
            "oceanbase_info": {"mode": "oracle"},
            "errors": [],
        },
    },
    {
        "name": "rownum",
        "description": "ROWNUM（Oracle 兼容）",
        "sql": "SELECT * FROM users WHERE ROWNUM <= 10",
        "expected": {
            "success": True,
            "dialect": "oceanbase-oracle",
            "statement_type": "SELECT",
            "tables": [{"name": "users"}],
            "oracle_info": {"pseudo_columns": ["ROWNUM"]},
            "oceanbase_info": {"mode": "oracle"},
            "errors": [],
        },
    },
    {
        "name": "oracle_functions",
        "description": "Oracle 函数",
        "sql": "SELECT NVL(name, 'unknown'), DECODE(status, 'A', 'Active', 'Unknown') FROM users",
        "expected": {
            "success": True,
            "dialect": "oceanbase-oracle",
            "statement_type": "SELECT",
            "tables": [{"name": "users"}],
            "oceanbase_info": {"mode": "oracle"},
            "errors": [],
        },
    },
    {
        "name": "parallel_hint",
        "description": "PARALLEL Hint",
        "sql": "SELECT /*+ PARALLEL(4) */ * FROM large_table",
        "expected": {
            "success": True,
            "dialect": "oceanbase-oracle",
            "statement_type": "SELECT",
            "tables": [{"name": "large_table"}],
            "oceanbase_info": {
                "mode": "oracle",
                "hints": [{"name": "PARALLEL", "type": "parallel_hint", "args": "4"}],
            },
            "errors": [],
        },
    },
    {
        "name": "create_table",
        "description": "CREATE TABLE",
        "sql": """
        CREATE TABLE users (
            id NUMBER PRIMARY KEY,
            name VARCHAR2(100) NOT NULL
        )
        """,
        "expected": {
            "success": True,
            "dialect": "oceanbase-oracle",
            "statement_type": "CREATE",
            "oceanbase_info": {"mode": "oracle"},
            "errors": [],
        },
    },
    {
        "name": "insert",
        "description": "INSERT",
        "sql": "INSERT INTO users (name) VALUES ('John')",
        "expected": {
            "success": True,
            "dialect": "oceanbase-oracle",
            "statement_type": "INSERT",
            "tables": [{"name": "users"}],
            "oceanbase_info": {"mode": "oracle"},
            "errors": [],
        },
    },
    {
        "name": "subquery",
        "description": "子查询",
        "sql": """
        SELECT * FROM users
        WHERE department_id IN (
            SELECT id FROM departments WHERE status = 'active'
        )
        """,
        "expected": {
            "success": True,
            "dialect": "oceanbase-oracle",
            "statement_type": "SELECT",
            "oceanbase_info": {"mode": "oracle"},
            "errors": [],
        },
    },
    {
        "name": "cte",
        "description": "CTE",
        "sql": """
        WITH active_users AS (
            SELECT * FROM users WHERE status = 'active'
        )
        SELECT * FROM active_users
        """,
        "expected": {
            "success": True,
            "dialect": "oceanbase-oracle",
            "statement_type": "SELECT",
            "oceanbase_info": {"mode": "oracle"},
            "errors": [],
        },
    },
    {
        "name": "window_function",
        "description": "窗口函数",
        "sql": """
        SELECT 
            name,
            salary,
            ROW_NUMBER() OVER (PARTITION BY department ORDER BY salary DESC) as rank
        FROM employees
        """,
        "expected": {
            "success": True,
            "dialect": "oceanbase-oracle",
            "statement_type": "SELECT",
            "tables": [{"name": "employees"}],
            "oceanbase_info": {"mode": "oracle"},
            "errors": [],
        },
    },
]

OCEANBASE_MODE_SWITCH_TEST_CASES: list[dict[str, Any]] = [
    {
        "name": "same_sql_mysql_mode",
        "description": "同一 SQL 在 MySQL 模式下",
        "dialect": "oceanbase-mysql",
        "sql": "SELECT id, name FROM users WHERE status = 'active'",
        "expected": {
            "success": True,
            "dialect": "oceanbase-mysql",
            "statement_type": "SELECT",
            "oceanbase_info": {"mode": "mysql"},
            "errors": [],
        },
    },
    {
        "name": "same_sql_oracle_mode",
        "description": "同一 SQL 在 Oracle 模式下",
        "dialect": "oceanbase-oracle",
        "sql": "SELECT id, name FROM users WHERE status = 'active'",
        "expected": {
            "success": True,
            "dialect": "oceanbase-oracle",
            "statement_type": "SELECT",
            "oceanbase_info": {"mode": "oracle"},
            "errors": [],
        },
    },
]
