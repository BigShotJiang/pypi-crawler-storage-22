"""Oracle 测试 SQL 脚本及期望结果定义。"""
from typing import Any

ORACLE_TEST_CASES: list[dict[str, Any]] = [
    {
        "name": "simple_select",
        "description": "简单 SELECT 语句",
        "sql": "SELECT id, name FROM users",
        "expected": {
            "success": True,
            "dialect": "oracle",
            "statement_type": "SELECT",
            "tables": [{"name": "users"}],
            "columns_count": 2,
            "errors": [],
        },
    },
    {
        "name": "double_quote_identifier",
        "description": "双引号标识符解析",
        "sql": 'SELECT "id", "user_name" FROM "user_table"',
        "expected": {
            "success": True,
            "dialect": "oracle",
            "statement_type": "SELECT",
            "tables": [{"name": "user_table"}],
            "errors": [],
        },
    },
    {
        "name": "dual_table",
        "description": "DUAL 表",
        "sql": "SELECT SYSDATE FROM DUAL",
        "expected": {
            "success": True,
            "dialect": "oracle",
            "statement_type": "SELECT",
            "tables_has_dual": True,
            "errors": [],
        },
    },
    {
        "name": "schema_qualified_table",
        "description": "带 schema 的表名",
        "sql": "SELECT * FROM hr.employees",
        "expected": {
            "success": True,
            "dialect": "oracle",
            "statement_type": "SELECT",
            "tables": [{"name": "employees", "schema_name": "hr"}],
            "errors": [],
        },
    },
    {
        "name": "rownum_in_where",
        "description": "WHERE 中的 ROWNUM",
        "sql": "SELECT * FROM users WHERE ROWNUM <= 10",
        "expected": {
            "success": True,
            "dialect": "oracle",
            "statement_type": "SELECT",
            "tables": [{"name": "users"}],
            "oracle_info": {"pseudo_columns": ["ROWNUM"]},
            "errors": [],
        },
    },
    {
        "name": "rownum_in_select",
        "description": "SELECT 中的 ROWNUM",
        "sql": "SELECT ROWNUM, id, name FROM users",
        "expected": {
            "success": True,
            "dialect": "oracle",
            "statement_type": "SELECT",
            "tables": [{"name": "users"}],
            "oracle_info": {"pseudo_columns": ["ROWNUM"]},
            "errors": [],
        },
    },
    {
        "name": "nvl_function",
        "description": "NVL 函数",
        "sql": "SELECT NVL(name, 'unknown') FROM users",
        "expected": {
            "success": True,
            "dialect": "oracle",
            "statement_type": "SELECT",
            "tables": [{"name": "users"}],
            "errors": [],
        },
    },
    {
        "name": "nvl2_function",
        "description": "NVL2 函数",
        "sql": "SELECT NVL2(commission, salary + commission, salary) FROM employees",
        "expected": {
            "success": True,
            "dialect": "oracle",
            "statement_type": "SELECT",
            "tables": [{"name": "employees"}],
            "errors": [],
        },
    },
    {
        "name": "decode_function",
        "description": "DECODE 函数",
        "sql": "SELECT DECODE(status, 'A', 'Active', 'I', 'Inactive', 'Unknown') FROM users",
        "expected": {
            "success": True,
            "dialect": "oracle",
            "statement_type": "SELECT",
            "tables": [{"name": "users"}],
            "errors": [],
        },
    },
    {
        "name": "to_date_function",
        "description": "TO_DATE 函数",
        "sql": "SELECT * FROM orders WHERE order_date > TO_DATE('2024-01-01', 'YYYY-MM-DD')",
        "expected": {
            "success": True,
            "dialect": "oracle",
            "statement_type": "SELECT",
            "tables": [{"name": "orders"}],
            "conditions_count": 1,
            "errors": [],
        },
    },
    {
        "name": "to_char_function",
        "description": "TO_CHAR 函数",
        "sql": "SELECT TO_CHAR(hire_date, 'YYYY-MM-DD') FROM employees",
        "expected": {
            "success": True,
            "dialect": "oracle",
            "statement_type": "SELECT",
            "tables": [{"name": "employees"}],
            "errors": [],
        },
    },
    {
        "name": "inner_join",
        "description": "INNER JOIN",
        "sql": "SELECT * FROM employees e INNER JOIN departments d ON e.dept_id = d.id",
        "expected": {
            "success": True,
            "dialect": "oracle",
            "statement_type": "SELECT",
            "tables_count": 2,
            "joins": [{"type": "INNER", "table": {"name": "departments", "alias": "d"}}],
            "errors": [],
        },
    },
    {
        "name": "left_outer_join",
        "description": "LEFT OUTER JOIN",
        "sql": "SELECT * FROM employees e LEFT OUTER JOIN departments d ON e.dept_id = d.id",
        "expected": {
            "success": True,
            "dialect": "oracle",
            "statement_type": "SELECT",
            "tables_count": 2,
            "joins": [{"type": "LEFT", "table": {"name": "departments", "alias": "d"}}],
            "errors": [],
        },
    },
    {
        "name": "row_number",
        "description": "ROW_NUMBER 分析函数",
        "sql": """
        SELECT 
            employee_id,
            salary,
            ROW_NUMBER() OVER (PARTITION BY department_id ORDER BY salary DESC) as rank
        FROM employees
        """,
        "expected": {
            "success": True,
            "dialect": "oracle",
            "statement_type": "SELECT",
            "tables": [{"name": "employees"}],
            "errors": [],
        },
    },
    {
        "name": "rank_function",
        "description": "RANK 分析函数",
        "sql": """
        SELECT 
            employee_id,
            salary,
            RANK() OVER (ORDER BY salary DESC) as salary_rank
        FROM employees
        """,
        "expected": {
            "success": True,
            "dialect": "oracle",
            "statement_type": "SELECT",
            "tables": [{"name": "employees"}],
            "errors": [],
        },
    },
    {
        "name": "lag_lead",
        "description": "LAG/LEAD 分析函数",
        "sql": """
        SELECT 
            employee_id,
            salary,
            LAG(salary, 1) OVER (ORDER BY hire_date) as prev_salary,
            LEAD(salary, 1) OVER (ORDER BY hire_date) as next_salary
        FROM employees
        """,
        "expected": {
            "success": True,
            "dialect": "oracle",
            "statement_type": "SELECT",
            "tables": [{"name": "employees"}],
            "errors": [],
        },
    },
    {
        "name": "create_table",
        "description": "CREATE TABLE",
        "sql": """
        CREATE TABLE employees (
            id NUMBER PRIMARY KEY,
            name VARCHAR2(100) NOT NULL,
            hire_date DATE DEFAULT SYSDATE
        )
        """,
        "expected": {
            "success": True,
            "dialect": "oracle",
            "statement_type": "CREATE",
            "errors": [],
        },
    },
    {
        "name": "insert",
        "description": "INSERT 语句",
        "sql": "INSERT INTO employees (id, name) VALUES (1, 'John')",
        "expected": {
            "success": True,
            "dialect": "oracle",
            "statement_type": "INSERT",
            "tables": [{"name": "employees"}],
            "errors": [],
        },
    },
    {
        "name": "update",
        "description": "UPDATE 语句",
        "sql": "UPDATE employees SET salary = salary * 1.1 WHERE department_id = 10",
        "expected": {
            "success": True,
            "dialect": "oracle",
            "statement_type": "UPDATE",
            "tables": [{"name": "employees"}],
            "conditions_count": 1,
            "errors": [],
        },
    },
    {
        "name": "delete",
        "description": "DELETE 语句",
        "sql": "DELETE FROM employees WHERE id = 1",
        "expected": {
            "success": True,
            "dialect": "oracle",
            "statement_type": "DELETE",
            "tables": [{"name": "employees"}],
            "errors": [],
        },
    },
    {
        "name": "merge_basic",
        "description": "基本 MERGE 语句",
        "sql": """
        MERGE INTO target_table t
        USING source_table s
        ON (t.id = s.id)
        WHEN MATCHED THEN
            UPDATE SET t.name = s.name
        WHEN NOT MATCHED THEN
            INSERT (id, name) VALUES (s.id, s.name)
        """,
        "expected": {
            "success": True,
            "dialect": "oracle",
            "statement_type": "MERGE",
            "errors": [],
        },
    },
    {
        "name": "subquery",
        "description": "子查询",
        "sql": """
        SELECT * FROM employees
        WHERE department_id IN (
            SELECT id FROM departments WHERE location = 'New York'
        )
        """,
        "expected": {
            "success": True,
            "dialect": "oracle",
            "statement_type": "SELECT",
            "errors": [],
        },
    },
    {
        "name": "cte",
        "description": "CTE (WITH 子句)",
        "sql": """
        WITH dept_salaries AS (
            SELECT department_id, AVG(salary) as avg_salary
            FROM employees
            GROUP BY department_id
        )
        SELECT e.*, d.avg_salary
        FROM employees e
        JOIN dept_salaries d ON e.department_id = d.department_id
        """,
        "expected": {
            "success": True,
            "dialect": "oracle",
            "statement_type": "SELECT",
            "errors": [],
        },
    },
    # ==================== 补充用例 ====================
    {
        "name": "subquery_2",
        "description": "子查询（补充）",
        "sql": """
        SELECT * FROM employees e
        WHERE salary > (SELECT AVG(salary) FROM employees WHERE department_id = e.department_id)
        """,
        "expected": {
            "success": True,
            "dialect": "oracle",
            "statement_type": "SELECT",
            "errors": [],
        },
    },
    {
        "name": "cte_multiple",
        "description": "多个 CTE",
        "sql": """
        WITH 
            dept_stats AS (SELECT department_id, COUNT(*) as cnt FROM employees GROUP BY department_id),
            high_salary AS (SELECT * FROM employees WHERE salary > 10000)
        SELECT d.department_id, d.cnt, h.employee_id
        FROM dept_stats d LEFT JOIN high_salary h ON d.department_id = h.department_id
        """,
        "expected": {
            "success": True,
            "dialect": "oracle",
            "statement_type": "SELECT",
            "errors": [],
        },
    },
    {
        "name": "right_outer_join",
        "description": "RIGHT OUTER JOIN",
        "sql": "SELECT * FROM employees e RIGHT OUTER JOIN departments d ON e.dept_id = d.id",
        "expected": {
            "success": True,
            "dialect": "oracle",
            "statement_type": "SELECT",
            "errors": [],
        },
    },
    {
        "name": "full_outer_join",
        "description": "FULL OUTER JOIN",
        "sql": "SELECT * FROM employees e FULL OUTER JOIN departments d ON e.dept_id = d.id",
        "expected": {
            "success": True,
            "dialect": "oracle",
            "statement_type": "SELECT",
            "errors": [],
        },
    },
    {
        "name": "dense_rank",
        "description": "DENSE_RANK 分析函数",
        "sql": """
        SELECT employee_id, salary,
            DENSE_RANK() OVER (ORDER BY salary DESC) as dense_rank
        FROM employees
        """,
        "expected": {
            "success": True,
            "dialect": "oracle",
            "statement_type": "SELECT",
            "errors": [],
        },
    },
    {
        "name": "ntile",
        "description": "NTILE 分析函数",
        "sql": """
        SELECT employee_id, salary,
            NTILE(4) OVER (ORDER BY salary DESC) as quartile
        FROM employees
        """,
        "expected": {
            "success": True,
            "dialect": "oracle",
            "statement_type": "SELECT",
            "errors": [],
        },
    },
    {
        "name": "listagg",
        "description": "LISTAGG 聚合函数",
        "sql": """
        SELECT department_id, LISTAGG(last_name, ', ') WITHIN GROUP (ORDER BY last_name) as employees
        FROM employees GROUP BY department_id
        """,
        "expected": {
            "success": True,
            "dialect": "oracle",
            "statement_type": "SELECT",
            "errors": [],
        },
    },
    {
        "name": "case_when",
        "description": "CASE WHEN 表达式",
        "sql": """
        SELECT employee_id,
            CASE 
                WHEN salary > 15000 THEN 'Executive'
                WHEN salary > 10000 THEN 'Senior'
                WHEN salary > 5000 THEN 'Junior'
                ELSE 'Entry'
            END as level
        FROM employees
        """,
        "expected": {
            "success": True,
            "dialect": "oracle",
            "statement_type": "SELECT",
            "errors": [],
        },
    },
    {
        "name": "union_all",
        "description": "UNION ALL",
        "sql": """
        SELECT employee_id, first_name FROM employees WHERE department_id = 10
        UNION ALL
        SELECT employee_id, first_name FROM employees WHERE department_id = 20
        """,
        "expected": {
            "success": True,
            "dialect": "oracle",
            "statement_type": "SELECT",
            "errors": [],
        },
    },
    {
        "name": "intersect",
        "description": "INTERSECT",
        "sql": """
        SELECT employee_id FROM employees WHERE salary > 10000
        INTERSECT
        SELECT employee_id FROM employees WHERE department_id = 10
        """,
        "expected": {
            "success": True,
            "dialect": "oracle",
            "statement_type": "SELECT",
            "errors": [],
        },
    },
    {
        "name": "minus",
        "description": "MINUS",
        "sql": """
        SELECT employee_id FROM employees
        MINUS
        SELECT employee_id FROM job_history
        """,
        "expected": {
            "success": True,
            "dialect": "oracle",
            "statement_type": "SELECT",
            "errors": [],
        },
    },
    {
        "name": "insert_all",
        "description": "INSERT ALL",
        "sql": """
        INSERT ALL
            INTO sales_history (product_id, amount) VALUES (product_id, amount)
            INTO sales_archive (product_id, amount) VALUES (product_id, amount)
        SELECT product_id, amount FROM sales WHERE sale_date < SYSDATE - 365
        """,
        "expected": {
            "success": True,
            "dialect": "oracle",
            "statement_type": "INSERT",
            "errors": [],
        },
    },
    {
        "name": "update_with_subquery",
        "description": "UPDATE 带子查询",
        "sql": """
        UPDATE employees e SET salary = (
            SELECT AVG(salary) * 1.1 FROM employees WHERE department_id = e.department_id
        ) WHERE performance_rating = 'A'
        """,
        "expected": {
            "success": True,
            "dialect": "oracle",
            "statement_type": "UPDATE",
            "errors": [],
        },
    },
    {
        "name": "delete_with_exists",
        "description": "DELETE 带 EXISTS",
        "sql": """
        DELETE FROM employees e WHERE EXISTS (
            SELECT 1 FROM terminated_employees t WHERE t.employee_id = e.employee_id
        )
        """,
        "expected": {
            "success": True,
            "dialect": "oracle",
            "statement_type": "DELETE",
            "errors": [],
        },
    },
    {
        "name": "create_table_as_select",
        "description": "CREATE TABLE AS SELECT",
        "sql": """
        CREATE TABLE employees_backup AS
        SELECT * FROM employees WHERE hire_date < TO_DATE('2020-01-01', 'YYYY-MM-DD')
        """,
        "expected": {
            "success": True,
            "dialect": "oracle",
            "statement_type": "CREATE",
            "errors": [],
        },
    },
    {
        "name": "alter_table",
        "description": "ALTER TABLE",
        "sql": "ALTER TABLE employees ADD (phone VARCHAR2(20), address VARCHAR2(200))",
        "expected": {
            "success": True,
            "dialect": "oracle",
            "statement_type": "ALTER",
            "errors": [],
        },
    },
    {
        "name": "truncate_table",
        "description": "TRUNCATE TABLE",
        "sql": "TRUNCATE TABLE temp_data",
        "expected": {
            "success": True,
            "dialect": "oracle",
            "statement_type": "TRUNCATE",
            "errors": [],
        },
    },
    {
        "name": "sequence_nextval",
        "description": "序列 NEXTVAL",
        "sql": "SELECT employee_seq.NEXTVAL FROM DUAL",
        "expected": {
            "success": True,
            "dialect": "oracle",
            "statement_type": "SELECT",
            "errors": [],
        },
    },
    {
        "name": "sequence_currval",
        "description": "序列 CURRVAL",
        "sql": "SELECT employee_seq.CURRVAL FROM DUAL",
        "expected": {
            "success": True,
            "dialect": "oracle",
            "statement_type": "SELECT",
            "errors": [],
        },
    },
]
