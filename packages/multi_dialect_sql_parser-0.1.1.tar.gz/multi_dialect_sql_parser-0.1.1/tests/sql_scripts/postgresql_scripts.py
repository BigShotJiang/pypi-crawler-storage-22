"""PostgreSQL 测试 SQL 脚本及期望结果定义。"""
from typing import Any

POSTGRESQL_TEST_CASES: list[dict[str, Any]] = [
    {
        "name": "simple_select",
        "description": "简单 SELECT 语句",
        "sql": "SELECT id, name FROM users",
        "expected": {
            "success": True,
            "dialect": "postgresql",
            "statement_type": "SELECT",
            "tables": [{"name": "users"}],
            "columns_count": 2,
            "errors": [],
        },
    },
    {
        "name": "double_quote_identifier",
        "description": "双引号标识符解析",
        "sql": 'SELECT "id", "user_name" FROM "user_table"',
        "expected": {
            "success": True,
            "dialect": "postgresql",
            "statement_type": "SELECT",
            "tables": [{"name": "user_table"}],
            "errors": [],
        },
    },
    {
        "name": "schema_qualified_table",
        "description": "带 schema 的表名",
        "sql": "SELECT * FROM public.users",
        "expected": {
            "success": True,
            "dialect": "postgresql",
            "statement_type": "SELECT",
            "tables": [{"name": "users", "schema_name": "public"}],
            "errors": [],
        },
    },
    {
        "name": "double_colon_cast",
        "description": ":: 类型转换",
        "sql": "SELECT '123'::integer FROM dual",
        "expected": {
            "success": True,
            "dialect": "postgresql",
            "statement_type": "SELECT",
            "errors": [],
        },
    },
    {
        "name": "cast_in_where",
        "description": "WHERE 中的类型转换",
        "sql": "SELECT * FROM users WHERE created_at::date = '2024-01-01'",
        "expected": {
            "success": True,
            "dialect": "postgresql",
            "statement_type": "SELECT",
            "tables": [{"name": "users"}],
            "conditions_count": 1,
            "errors": [],
        },
    },
    {
        "name": "array_literal",
        "description": "数组字面量",
        "sql": "SELECT ARRAY[1, 2, 3]",
        "expected": {
            "success": True,
            "dialect": "postgresql",
            "statement_type": "SELECT",
            "errors": [],
        },
    },
    {
        "name": "any_operator",
        "description": "ANY 操作符",
        "sql": "SELECT * FROM users WHERE id = ANY(ARRAY[1, 2, 3])",
        "expected": {
            "success": True,
            "dialect": "postgresql",
            "statement_type": "SELECT",
            "tables": [{"name": "users"}],
            "errors": [],
        },
    },
    {
        "name": "returning_clause",
        "description": "RETURNING 子句",
        "sql": "INSERT INTO users (name) VALUES ('John') RETURNING id",
        "expected": {
            "success": True,
            "dialect": "postgresql",
            "statement_type": "INSERT",
            "tables": [{"name": "users"}],
            "errors": [],
        },
    },
    {
        "name": "cte",
        "description": "CTE (WITH 子句)",
        "sql": """
        WITH active_users AS (
            SELECT * FROM users WHERE status = 'active'
        )
        SELECT * FROM active_users
        """,
        "expected": {
            "success": True,
            "dialect": "postgresql",
            "statement_type": "SELECT",
            "errors": [],
        },
    },
    {
        "name": "window_function",
        "description": "窗口函数",
        "sql": """
        SELECT 
            name,
            salary,
            ROW_NUMBER() OVER (PARTITION BY department ORDER BY salary DESC) as rank
        FROM employees
        """,
        "expected": {
            "success": True,
            "dialect": "postgresql",
            "statement_type": "SELECT",
            "tables": [{"name": "employees"}],
            "errors": [],
        },
    },
    {
        "name": "coalesce",
        "description": "COALESCE 函数",
        "sql": "SELECT COALESCE(name, 'unknown') FROM users",
        "expected": {
            "success": True,
            "dialect": "postgresql",
            "statement_type": "SELECT",
            "tables": [{"name": "users"}],
            "errors": [],
        },
    },
    {
        "name": "create_table_serial",
        "description": "SERIAL 类型",
        "sql": """
        CREATE TABLE users (
            id SERIAL PRIMARY KEY,
            name VARCHAR(100) NOT NULL
        )
        """,
        "expected": {
            "success": True,
            "dialect": "postgresql",
            "statement_type": "CREATE",
            "errors": [],
        },
    },
    {
        "name": "create_table_bigserial",
        "description": "BIGSERIAL 类型",
        "sql": """
        CREATE TABLE logs (
            id BIGSERIAL PRIMARY KEY,
            message TEXT
        )
        """,
        "expected": {
            "success": True,
            "dialect": "postgresql",
            "statement_type": "CREATE",
            "errors": [],
        },
    },
    # ==================== 补充用例 ====================
    {
        "name": "limit_offset",
        "description": "LIMIT OFFSET",
        "sql": "SELECT * FROM users ORDER BY id LIMIT 10 OFFSET 20",
        "expected": {
            "success": True,
            "dialect": "postgresql",
            "statement_type": "SELECT",
            "errors": [],
        },
    },
    {
        "name": "inner_join",
        "description": "INNER JOIN",
        "sql": "SELECT * FROM users u INNER JOIN orders o ON u.id = o.user_id",
        "expected": {
            "success": True,
            "dialect": "postgresql",
            "statement_type": "SELECT",
            "errors": [],
        },
    },
    {
        "name": "left_join",
        "description": "LEFT JOIN",
        "sql": "SELECT * FROM users u LEFT JOIN orders o ON u.id = o.user_id",
        "expected": {
            "success": True,
            "dialect": "postgresql",
            "statement_type": "SELECT",
            "errors": [],
        },
    },
    {
        "name": "group_by_having",
        "description": "GROUP BY HAVING",
        "sql": "SELECT department, COUNT(*) as cnt FROM employees GROUP BY department HAVING COUNT(*) > 5",
        "expected": {
            "success": True,
            "dialect": "postgresql",
            "statement_type": "SELECT",
            "errors": [],
        },
    },
    {
        "name": "order_by_nulls",
        "description": "ORDER BY NULLS FIRST/LAST",
        "sql": "SELECT * FROM users ORDER BY last_login NULLS LAST",
        "expected": {
            "success": True,
            "dialect": "postgresql",
            "statement_type": "SELECT",
            "errors": [],
        },
    },
    {
        "name": "recursive_cte",
        "description": "递归 CTE",
        "sql": """
        WITH RECURSIVE subordinates AS (
            SELECT id, name, manager_id FROM employees WHERE id = 1
            UNION ALL
            SELECT e.id, e.name, e.manager_id FROM employees e
            INNER JOIN subordinates s ON e.manager_id = s.id
        )
        SELECT * FROM subordinates
        """,
        "expected": {
            "success": True,
            "dialect": "postgresql",
            "statement_type": "SELECT",
            "errors": [],
        },
    },
    {
        "name": "lateral_join",
        "description": "LATERAL JOIN",
        "sql": """
        SELECT d.name, top_emp.* FROM departments d
        CROSS JOIN LATERAL (
            SELECT * FROM employees e WHERE e.department_id = d.id ORDER BY salary DESC LIMIT 3
        ) top_emp
        """,
        "expected": {
            "success": True,
            "dialect": "postgresql",
            "statement_type": "SELECT",
            "errors": [],
        },
    },
    {
        "name": "json_operators",
        "description": "JSON 操作符",
        "sql": "SELECT data->>'name' as name, data->'address'->>'city' as city FROM users",
        "expected": {
            "success": True,
            "dialect": "postgresql",
            "statement_type": "SELECT",
            "errors": [],
        },
    },
    {
        "name": "jsonb_functions",
        "description": "JSONB 函数",
        "sql": "SELECT jsonb_build_object('id', id, 'name', name) FROM users",
        "expected": {
            "success": True,
            "dialect": "postgresql",
            "statement_type": "SELECT",
            "errors": [],
        },
    },
    {
        "name": "array_operations",
        "description": "数组操作",
        "sql": "SELECT * FROM users WHERE 'admin' = ANY(roles) AND tags && ARRAY['vip', 'premium']",
        "expected": {
            "success": True,
            "dialect": "postgresql",
            "statement_type": "SELECT",
            "errors": [],
        },
    },
    {
        "name": "array_agg",
        "description": "ARRAY_AGG 聚合",
        "sql": "SELECT department, ARRAY_AGG(name ORDER BY name) as members FROM employees GROUP BY department",
        "expected": {
            "success": True,
            "dialect": "postgresql",
            "statement_type": "SELECT",
            "errors": [],
        },
    },
    {
        "name": "string_agg",
        "description": "STRING_AGG 聚合",
        "sql": "SELECT department, STRING_AGG(name, ', ' ORDER BY name) as members FROM employees GROUP BY department",
        "expected": {
            "success": True,
            "dialect": "postgresql",
            "statement_type": "SELECT",
            "errors": [],
        },
    },
    {
        "name": "window_lag_lead",
        "description": "LAG/LEAD 窗口函数",
        "sql": """
        SELECT name, salary,
            LAG(salary) OVER (ORDER BY hire_date) as prev_salary,
            LEAD(salary) OVER (ORDER BY hire_date) as next_salary
        FROM employees
        """,
        "expected": {
            "success": True,
            "dialect": "postgresql",
            "statement_type": "SELECT",
            "errors": [],
        },
    },
    {
        "name": "insert_on_conflict",
        "description": "INSERT ON CONFLICT (UPSERT)",
        "sql": """
        INSERT INTO users (id, name, email) VALUES (1, 'John', 'john@example.com')
        ON CONFLICT (id) DO UPDATE SET name = EXCLUDED.name, email = EXCLUDED.email
        """,
        "expected": {
            "success": True,
            "dialect": "postgresql",
            "statement_type": "INSERT",
            "errors": [],
        },
    },
    {
        "name": "update_from",
        "description": "UPDATE FROM",
        "sql": """
        UPDATE users u SET status = 'inactive'
        FROM inactive_list i WHERE u.id = i.user_id
        """,
        "expected": {
            "success": True,
            "dialect": "postgresql",
            "statement_type": "UPDATE",
            "errors": [],
        },
    },
    {
        "name": "delete_using",
        "description": "DELETE USING",
        "sql": """
        DELETE FROM orders o USING customers c
        WHERE o.customer_id = c.id AND c.status = 'deleted'
        """,
        "expected": {
            "success": True,
            "dialect": "postgresql",
            "statement_type": "DELETE",
            "errors": [],
        },
    },
    {
        "name": "distinct_on",
        "description": "DISTINCT ON",
        "sql": """
        SELECT DISTINCT ON (department) department, name, salary
        FROM employees ORDER BY department, salary DESC
        """,
        "expected": {
            "success": True,
            "dialect": "postgresql",
            "statement_type": "SELECT",
            "errors": [],
        },
    },
    {
        "name": "generate_series",
        "description": "generate_series 函数",
        "sql": "SELECT generate_series(1, 10) as num",
        "expected": {
            "success": True,
            "dialect": "postgresql",
            "statement_type": "SELECT",
            "errors": [],
        },
    },
    {
        "name": "interval_arithmetic",
        "description": "INTERVAL 运算",
        "sql": "SELECT * FROM events WHERE event_date > NOW() - INTERVAL '7 days'",
        "expected": {
            "success": True,
            "dialect": "postgresql",
            "statement_type": "SELECT",
            "errors": [],
        },
    },
]
