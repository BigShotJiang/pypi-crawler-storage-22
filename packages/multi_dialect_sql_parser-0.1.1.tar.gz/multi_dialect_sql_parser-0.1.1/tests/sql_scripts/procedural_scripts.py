"""过程化语法测试用例。"""

# ==================== Oracle PL/SQL 测试用例 ====================

ORACLE_PROCEDURAL_CASES = {
    # CREATE FUNCTION 测试用例
    "oracle_function_simple": {
        "sql": """CREATE FUNCTION get_current_date RETURN DATE AS
BEGIN
    RETURN SYSDATE;
END;""",
        "expected": {
            "type": "FUNCTION",
            "name": "get_current_date",
            "return_type": "DATE",
        }
    },
    "oracle_function_with_params": {
        "sql": """CREATE FUNCTION calculate_salary(
    p_base_salary NUMBER,
    p_bonus_rate NUMBER DEFAULT 0.1
) RETURN NUMBER AS
    v_total NUMBER;
BEGIN
    v_total := p_base_salary * (1 + p_bonus_rate);
    RETURN v_total;
END calculate_salary;""",
        "expected": {
            "type": "FUNCTION",
            "name": "calculate_salary",
            "return_type": "NUMBER",
            "param_count": 2,
        }
    },
    "oracle_function_or_replace": {
        "sql": """CREATE OR REPLACE FUNCTION get_employee_count(
    p_dept_id IN NUMBER
) RETURN NUMBER AS
    v_count NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_count FROM employees WHERE department_id = p_dept_id;
    RETURN v_count;
END;""",
        "expected": {
            "type": "FUNCTION",
            "name": "get_employee_count",
            "is_replace": True,
        }
    },
    "oracle_function_with_schema": {
        "sql": """CREATE OR REPLACE FUNCTION hr.get_manager_name(
    p_emp_id NUMBER
) RETURN VARCHAR2 AS
    v_name VARCHAR2(100);
BEGIN
    SELECT manager_name INTO v_name FROM employees WHERE employee_id = p_emp_id;
    RETURN v_name;
END;""",
        "expected": {
            "type": "FUNCTION",
            "name": "get_manager_name",
            "schema_name": "hr",
        }
    },
    
    # CREATE PROCEDURE 测试用例
    "oracle_procedure_simple": {
        "sql": """CREATE PROCEDURE log_message(p_message VARCHAR2) AS
BEGIN
    INSERT INTO log_table(message, created_at) VALUES(p_message, SYSDATE);
    COMMIT;
END;""",
        "expected": {
            "type": "PROCEDURE",
            "name": "log_message",
            "param_count": 1,
        }
    },
    "oracle_procedure_in_out": {
        "sql": """CREATE OR REPLACE PROCEDURE get_employee_salary(
    p_emp_id IN NUMBER,
    p_salary OUT NUMBER,
    p_bonus OUT NUMBER
) AS
BEGIN
    SELECT salary, bonus INTO p_salary, p_bonus FROM employees WHERE employee_id = p_emp_id;
END;""",
        "expected": {
            "type": "PROCEDURE",
            "name": "get_employee_salary",
            "param_count": 3,
        }
    },
    
    # CREATE PACKAGE 测试用例
    "oracle_package_simple": {
        "sql": """CREATE PACKAGE employee_pkg AS
    PROCEDURE hire_employee(p_name VARCHAR2, p_salary NUMBER);
    FUNCTION get_employee_count RETURN NUMBER;
END employee_pkg;""",
        "expected": {
            "type": "PACKAGE",
            "name": "employee_pkg",
            "procedure_count": 1,
            "function_count": 1,
        }
    },
    "oracle_package_body": {
        "sql": """CREATE OR REPLACE PACKAGE BODY hr_utils AS
    PROCEDURE hire_employee(p_name VARCHAR2) AS
    BEGIN
        INSERT INTO employees(name) VALUES(p_name);
    END hire_employee;
END hr_utils;""",
        "expected": {
            "type": "PACKAGE_BODY",
            "name": "hr_utils",
            "is_body": True,
        }
    },
    
    # CREATE TRIGGER 测试用例
    "oracle_trigger_before_insert": {
        "sql": """CREATE TRIGGER trg_employee_before_insert
BEFORE INSERT ON employees
FOR EACH ROW
BEGIN
    :NEW.created_at := SYSDATE;
END;""",
        "expected": {
            "type": "TRIGGER",
            "name": "trg_employee_before_insert",
            "timing": "BEFORE",
            "table_name": "employees",
        }
    },
    "oracle_trigger_after_update": {
        "sql": """CREATE OR REPLACE TRIGGER trg_salary_audit
AFTER UPDATE OF salary ON employees
FOR EACH ROW
BEGIN
    INSERT INTO salary_audit_log(employee_id, old_salary, new_salary)
    VALUES(:OLD.employee_id, :OLD.salary, :NEW.salary);
END;""",
        "expected": {
            "type": "TRIGGER",
            "name": "trg_salary_audit",
            "timing": "AFTER",
            "is_replace": True,
        }
    },
    
    # 匿名块测试用例
    "oracle_anonymous_simple": {
        "sql": """BEGIN
    DBMS_OUTPUT.PUT_LINE('Hello, World!');
END;""",
        "expected": {
            "type": "ANONYMOUS_BLOCK",
            "name": None,
        }
    },
    "oracle_anonymous_with_declare": {
        "sql": """DECLARE
    v_count NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_count FROM employees;
    DBMS_OUTPUT.PUT_LINE('Count: ' || v_count);
END;""",
        "expected": {
            "type": "ANONYMOUS_BLOCK",
            "name": None,
        }
    },
    
    # 复杂查询测试用例（在过程中使用）
    "oracle_complex_multi_join": {
        "sql": """CREATE FUNCTION get_employee_full_info(p_emp_id NUMBER)
RETURN SYS_REFCURSOR AS
    v_cursor SYS_REFCURSOR;
BEGIN
    OPEN v_cursor FOR
        SELECT 
            e.employee_id,
            e.first_name || ' ' || e.last_name AS full_name,
            e.email,
            e.salary,
            d.department_name,
            l.city || ', ' || l.country_id AS location,
            m.first_name || ' ' || m.last_name AS manager_name,
            j.job_title,
            jh.start_date AS job_start_date
        FROM employees e
        INNER JOIN departments d ON e.department_id = d.department_id
        INNER JOIN locations l ON d.location_id = l.location_id
        LEFT JOIN employees m ON e.manager_id = m.employee_id
        INNER JOIN jobs j ON e.job_id = j.job_id
        LEFT JOIN job_history jh ON e.employee_id = jh.employee_id
            AND jh.end_date IS NULL
        WHERE e.employee_id = p_emp_id;
    RETURN v_cursor;
END;""",
        "expected": {
            "type": "FUNCTION",
            "name": "get_employee_full_info",
            "return_type": "SYS_REFCURSOR",
        }
    },
    "oracle_complex_cte_subquery": {
        "sql": """CREATE OR REPLACE PROCEDURE generate_salary_report(
    p_dept_id IN NUMBER,
    p_result OUT SYS_REFCURSOR
) AS
BEGIN
    OPEN p_result FOR
        WITH dept_stats AS (
            SELECT 
                department_id,
                AVG(salary) AS avg_salary,
                MIN(salary) AS min_salary,
                MAX(salary) AS max_salary,
                COUNT(*) AS emp_count
            FROM employees
            GROUP BY department_id
        ),
        salary_ranks AS (
            SELECT 
                employee_id,
                salary,
                RANK() OVER (PARTITION BY department_id ORDER BY salary DESC) AS salary_rank,
                PERCENT_RANK() OVER (PARTITION BY department_id ORDER BY salary) AS percentile
            FROM employees
        )
        SELECT 
            e.employee_id,
            e.first_name || ' ' || e.last_name AS employee_name,
            e.salary,
            ds.avg_salary AS dept_avg_salary,
            e.salary - ds.avg_salary AS salary_diff,
            sr.salary_rank,
            ROUND(sr.percentile * 100, 2) AS salary_percentile
        FROM employees e
        JOIN dept_stats ds ON e.department_id = ds.department_id
        JOIN salary_ranks sr ON e.employee_id = sr.employee_id
        WHERE e.department_id = p_dept_id
        ORDER BY sr.salary_rank;
END;""",
        "expected": {
            "type": "PROCEDURE",
            "name": "generate_salary_report",
            "param_count": 2,
            "is_replace": True,
        }
    },
    "oracle_complex_connect_by": {
        "sql": """CREATE FUNCTION get_org_hierarchy(p_manager_id NUMBER)
RETURN SYS_REFCURSOR AS
    v_cursor SYS_REFCURSOR;
BEGIN
    OPEN v_cursor FOR
        SELECT 
            LEVEL AS hierarchy_level,
            LPAD(' ', (LEVEL - 1) * 4) || first_name || ' ' || last_name AS employee_tree,
            employee_id,
            manager_id,
            job_id,
            salary,
            SYS_CONNECT_BY_PATH(last_name, '/') AS path
        FROM employees
        START WITH employee_id = p_manager_id
        CONNECT BY PRIOR employee_id = manager_id
        ORDER SIBLINGS BY last_name;
    RETURN v_cursor;
END;""",
        "expected": {
            "type": "FUNCTION",
            "name": "get_org_hierarchy",
            "return_type": "SYS_REFCURSOR",
        }
    },
}

# ==================== MySQL 存储过程测试用例 ====================

MYSQL_PROCEDURAL_CASES = {
    # CREATE FUNCTION 测试用例
    "mysql_function_simple": {
        "sql": """CREATE FUNCTION get_current_timestamp()
RETURNS DATETIME
DETERMINISTIC
BEGIN
    RETURN NOW();
END""",
        "expected": {
            "type": "FUNCTION",
            "name": "get_current_timestamp",
            "return_type": "DATETIME",
            "deterministic": True,
        }
    },
    "mysql_function_with_params": {
        "sql": """CREATE FUNCTION calculate_tax(
    amount DECIMAL(10,2),
    tax_rate DECIMAL(5,4)
)
RETURNS DECIMAL(10,2)
DETERMINISTIC
BEGIN
    RETURN amount * tax_rate;
END""",
        "expected": {
            "type": "FUNCTION",
            "name": "calculate_tax",
            "param_count": 2,
        }
    },
    "mysql_function_with_definer": {
        "sql": """CREATE DEFINER=`admin`@`localhost` FUNCTION get_employee_count(
    dept_id INT
)
RETURNS INT
READS SQL DATA
BEGIN
    DECLARE emp_count INT;
    SELECT COUNT(*) INTO emp_count FROM employees WHERE department_id = dept_id;
    RETURN emp_count;
END""",
        "expected": {
            "type": "FUNCTION",
            "name": "get_employee_count",
            "definer": "`admin`@`localhost`",
        }
    },
    
    # CREATE PROCEDURE 测试用例
    "mysql_procedure_simple": {
        "sql": """CREATE PROCEDURE log_activity(
    IN user_id INT,
    IN activity_type VARCHAR(50)
)
BEGIN
    INSERT INTO activity_log(user_id, activity_type, created_at) VALUES(user_id, activity_type, NOW());
END""",
        "expected": {
            "type": "PROCEDURE",
            "name": "log_activity",
            "param_count": 2,
        }
    },
    "mysql_procedure_in_out": {
        "sql": """CREATE PROCEDURE get_employee_info(
    IN emp_id INT,
    OUT emp_name VARCHAR(100),
    OUT emp_salary DECIMAL(10,2)
)
BEGIN
    SELECT CONCAT(first_name, ' ', last_name), salary
    INTO emp_name, emp_salary
    FROM employees WHERE employee_id = emp_id;
END""",
        "expected": {
            "type": "PROCEDURE",
            "name": "get_employee_info",
            "param_count": 3,
        }
    },
    "mysql_procedure_inout": {
        "sql": """CREATE PROCEDURE adjust_salary(
    IN emp_id INT,
    INOUT salary_amount DECIMAL(10,2),
    IN adjustment_type VARCHAR(20)
)
BEGIN
    UPDATE employees SET salary = salary_amount WHERE employee_id = emp_id;
END""",
        "expected": {
            "type": "PROCEDURE",
            "name": "adjust_salary",
            "param_count": 3,
        }
    },
    
    # CREATE TRIGGER 测试用例
    "mysql_trigger_before_insert": {
        "sql": """CREATE TRIGGER trg_employee_before_insert
BEFORE INSERT ON employees
FOR EACH ROW
BEGIN
    SET NEW.created_at = NOW();
    SET NEW.updated_at = NOW();
END""",
        "expected": {
            "type": "TRIGGER",
            "name": "trg_employee_before_insert",
            "timing": "BEFORE",
            "table_name": "employees",
        }
    },
    "mysql_trigger_after_insert": {
        "sql": """CREATE TRIGGER trg_order_after_insert
AFTER INSERT ON orders
FOR EACH ROW
BEGIN
    UPDATE customers SET total_orders = total_orders + 1 WHERE customer_id = NEW.customer_id;
END""",
        "expected": {
            "type": "TRIGGER",
            "name": "trg_order_after_insert",
            "timing": "AFTER",
        }
    },
    "mysql_trigger_with_definer": {
        "sql": """CREATE DEFINER=`admin`@`localhost` TRIGGER trg_audit
AFTER UPDATE ON user_profiles
FOR EACH ROW
BEGIN
    INSERT INTO audit_log(table_name, record_id) VALUES('user_profiles', NEW.user_id);
END""",
        "expected": {
            "type": "TRIGGER",
            "name": "trg_audit",
            "definer": "`admin`@`localhost`",
        }
    },
    
    # 复杂查询测试用例（在过程中使用）
    "mysql_complex_multi_join": {
        "sql": """CREATE PROCEDURE get_order_details(
    IN p_order_id INT
)
BEGIN
    SELECT 
        o.order_id,
        o.order_date,
        o.status,
        c.customer_name,
        c.email AS customer_email,
        p.product_name,
        oi.quantity,
        oi.unit_price,
        (oi.quantity * oi.unit_price) AS line_total,
        s.shipper_name,
        a.street_address,
        a.city,
        a.postal_code
    FROM orders o
    INNER JOIN customers c ON o.customer_id = c.customer_id
    INNER JOIN order_items oi ON o.order_id = oi.order_id
    INNER JOIN products p ON oi.product_id = p.product_id
    LEFT JOIN shippers s ON o.shipper_id = s.shipper_id
    LEFT JOIN addresses a ON o.shipping_address_id = a.address_id
    WHERE o.order_id = p_order_id
    ORDER BY oi.line_number;
END""",
        "expected": {
            "type": "PROCEDURE",
            "name": "get_order_details",
            "param_count": 1,
        }
    },
    "mysql_complex_subquery": {
        "sql": """CREATE PROCEDURE get_top_customers(
    IN p_year INT,
    IN p_limit INT
)
BEGIN
    SELECT 
        c.customer_id,
        c.customer_name,
        customer_stats.total_orders,
        customer_stats.total_amount,
        customer_stats.avg_order_value,
        (
            SELECT COUNT(DISTINCT product_id)
            FROM order_items oi
            JOIN orders o ON oi.order_id = o.order_id
            WHERE o.customer_id = c.customer_id
        ) AS unique_products_purchased
    FROM customers c
    INNER JOIN (
        SELECT 
            customer_id,
            COUNT(*) AS total_orders,
            SUM(total_amount) AS total_amount,
            AVG(total_amount) AS avg_order_value
        FROM orders
        WHERE YEAR(order_date) = p_year
        GROUP BY customer_id
    ) customer_stats ON c.customer_id = customer_stats.customer_id
    WHERE customer_stats.total_orders >= 3
    ORDER BY customer_stats.total_amount DESC
    LIMIT p_limit;
END""",
        "expected": {
            "type": "PROCEDURE",
            "name": "get_top_customers",
            "param_count": 2,
        }
    },
    "mysql_complex_cte_window": {
        "sql": """CREATE PROCEDURE generate_sales_report(
    IN p_start_date DATE,
    IN p_end_date DATE
)
BEGIN
    WITH daily_sales AS (
        SELECT 
            DATE(order_date) AS sale_date,
            SUM(total_amount) AS daily_total,
            COUNT(*) AS order_count
        FROM orders
        WHERE order_date BETWEEN p_start_date AND p_end_date
        GROUP BY DATE(order_date)
    ),
    running_totals AS (
        SELECT 
            sale_date,
            daily_total,
            order_count,
            SUM(daily_total) OVER (ORDER BY sale_date) AS cumulative_total,
            AVG(daily_total) OVER (
                ORDER BY sale_date
                ROWS BETWEEN 6 PRECEDING AND CURRENT ROW
            ) AS moving_avg_7day
        FROM daily_sales
    )
    SELECT 
        rt.sale_date,
        rt.daily_total,
        rt.order_count,
        rt.cumulative_total,
        ROUND(rt.moving_avg_7day, 2) AS moving_avg_7day,
        ROUND(
            (rt.daily_total - LAG(rt.daily_total) OVER (ORDER BY rt.sale_date)) 
            / LAG(rt.daily_total) OVER (ORDER BY rt.sale_date) * 100, 
            2
        ) AS day_over_day_growth
    FROM running_totals rt
    ORDER BY rt.sale_date;
END""",
        "expected": {
            "type": "PROCEDURE",
            "name": "generate_sales_report",
            "param_count": 2,
        }
    },
    "mysql_complex_union": {
        "sql": """CREATE PROCEDURE get_inventory_summary()
BEGIN
    SELECT 
        'Low Stock' AS category,
        COUNT(*) AS product_count,
        SUM(quantity_in_stock) AS total_quantity,
        SUM(quantity_in_stock * unit_cost) AS total_value
    FROM products
    WHERE quantity_in_stock < reorder_level
    
    UNION ALL
    
    SELECT 
        'Normal Stock' AS category,
        COUNT(*) AS product_count,
        SUM(quantity_in_stock) AS total_quantity,
        SUM(quantity_in_stock * unit_cost) AS total_value
    FROM products
    WHERE quantity_in_stock >= reorder_level 
      AND quantity_in_stock <= reorder_level * 3
    
    UNION ALL
    
    SELECT 
        'Overstock' AS category,
        COUNT(*) AS product_count,
        SUM(quantity_in_stock) AS total_quantity,
        SUM(quantity_in_stock * unit_cost) AS total_value
    FROM products
    WHERE quantity_in_stock > reorder_level * 3;
END""",
        "expected": {
            "type": "PROCEDURE",
            "name": "get_inventory_summary",
            "param_count": 0,
        }
    },
    "mysql_complex_exists": {
        "sql": """CREATE PROCEDURE find_inactive_customers(
    IN p_days_inactive INT
)
BEGIN
    SELECT 
        c.customer_id,
        c.customer_name,
        c.email,
        c.registration_date,
        (
            SELECT MAX(order_date)
            FROM orders o
            WHERE o.customer_id = c.customer_id
        ) AS last_order_date
    FROM customers c
    WHERE EXISTS (
        SELECT 1 FROM orders o
        WHERE o.customer_id = c.customer_id
    )
    AND NOT EXISTS (
        SELECT 1 FROM orders o
        WHERE o.customer_id = c.customer_id
        AND o.order_date > DATE_SUB(CURDATE(), INTERVAL p_days_inactive DAY)
    )
    ORDER BY last_order_date;
END""",
        "expected": {
            "type": "PROCEDURE",
            "name": "find_inactive_customers",
            "param_count": 1,
        }
    },
}

# ==================== PostgreSQL PL/pgSQL 测试用例 ====================

POSTGRESQL_PROCEDURAL_CASES = {
    # CREATE FUNCTION 测试用例
    "postgresql_function_simple": {
        "sql": """CREATE FUNCTION get_current_timestamp()
RETURNS TIMESTAMP AS $$
BEGIN
    RETURN NOW();
END;
$$ LANGUAGE plpgsql;""",
        "expected": {
            "type": "FUNCTION",
            "name": "get_current_timestamp",
            "return_type": "TIMESTAMP",
            "language": "plpgsql",
        }
    },
    "postgresql_function_with_params": {
        "sql": """CREATE FUNCTION calculate_discount(
    price NUMERIC,
    discount_rate NUMERIC DEFAULT 0.1
)
RETURNS NUMERIC AS $$
BEGIN
    RETURN price * (1 - discount_rate);
END;
$$ LANGUAGE plpgsql;""",
        "expected": {
            "type": "FUNCTION",
            "name": "calculate_discount",
            "param_count": 2,
        }
    },
    "postgresql_function_or_replace": {
        "sql": """CREATE OR REPLACE FUNCTION get_employee_count(
    dept_id INTEGER
)
RETURNS INTEGER AS $$
DECLARE
    emp_count INTEGER;
BEGIN
    SELECT COUNT(*) INTO emp_count FROM employees WHERE department_id = dept_id;
    RETURN emp_count;
END;
$$ LANGUAGE plpgsql;""",
        "expected": {
            "type": "FUNCTION",
            "name": "get_employee_count",
            "is_replace": True,
        }
    },
    "postgresql_function_named_tag": {
        "sql": """CREATE OR REPLACE FUNCTION format_address(
    street VARCHAR,
    city VARCHAR
)
RETURNS VARCHAR AS $format_addr$
BEGIN
    RETURN street || ', ' || city;
END;
$format_addr$ LANGUAGE plpgsql;""",
        "expected": {
            "type": "FUNCTION",
            "name": "format_address",
        }
    },
    
    # CREATE PROCEDURE 测试用例
    "postgresql_procedure_simple": {
        "sql": """CREATE OR REPLACE PROCEDURE log_event(
    p_event_type VARCHAR,
    p_message TEXT
)
LANGUAGE plpgsql AS $$
BEGIN
    INSERT INTO event_log(event_type, message, created_at) VALUES(p_event_type, p_message, NOW());
END;
$$;""",
        "expected": {
            "type": "PROCEDURE",
            "name": "log_event",
            "param_count": 2,
        }
    },
    "postgresql_procedure_inout": {
        "sql": """CREATE OR REPLACE PROCEDURE update_inventory(
    p_product_id INTEGER,
    INOUT p_quantity INTEGER
)
LANGUAGE plpgsql AS $$
BEGIN
    UPDATE products SET quantity_in_stock = p_quantity WHERE product_id = p_product_id;
END;
$$;""",
        "expected": {
            "type": "PROCEDURE",
            "name": "update_inventory",
            "param_count": 2,
        }
    },
    
    # CREATE TRIGGER 测试用例
    "postgresql_trigger_before_insert": {
        "sql": """CREATE TRIGGER trg_employees_before_insert
BEFORE INSERT ON employees
FOR EACH ROW
EXECUTE FUNCTION trg_set_timestamps();""",
        "expected": {
            "type": "TRIGGER",
            "name": "trg_employees_before_insert",
            "timing": "BEFORE",
            "table_name": "employees",
        }
    },
    "postgresql_trigger_after_update": {
        "sql": """CREATE TRIGGER trg_employees_salary_audit
AFTER UPDATE OF salary ON employees
FOR EACH ROW
EXECUTE FUNCTION trg_audit_salary_change();""",
        "expected": {
            "type": "TRIGGER",
            "name": "trg_employees_salary_audit",
            "timing": "AFTER",
        }
    },
    
    # DO 块测试用例
    "postgresql_do_simple": {
        "sql": """DO $$
BEGIN
    RAISE NOTICE 'Hello, PostgreSQL!';
END;
$$;""",
        "expected": {
            "type": "ANONYMOUS_BLOCK",
            "name": None,
            "language": "plpgsql",
        }
    },
    "postgresql_do_with_declare": {
        "sql": """DO $$
DECLARE
    v_count INTEGER;
BEGIN
    SELECT COUNT(*) INTO v_count FROM employees;
    RAISE NOTICE 'Count: %', v_count;
END;
$$;""",
        "expected": {
            "type": "ANONYMOUS_BLOCK",
            "name": None,
        }
    },

    # 复杂查询测试用例（在函数中使用）
    "postgresql_complex_window": {
        "sql": """CREATE OR REPLACE FUNCTION get_employee_ranking(
    p_dept_id INTEGER DEFAULT NULL
)
RETURNS TABLE (
    employee_id INTEGER,
    full_name VARCHAR,
    department_name VARCHAR,
    salary NUMERIC,
    dept_rank INTEGER,
    company_rank INTEGER,
    salary_percentile NUMERIC
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        e.employee_id,
        (e.first_name || ' ' || e.last_name)::VARCHAR,
        d.department_name,
        e.salary,
        RANK() OVER (PARTITION BY e.department_id ORDER BY e.salary DESC)::INTEGER,
        RANK() OVER (ORDER BY e.salary DESC)::INTEGER,
        ROUND(PERCENT_RANK() OVER (ORDER BY e.salary) * 100, 2)
    FROM employees e
    INNER JOIN departments d ON e.department_id = d.department_id
    WHERE p_dept_id IS NULL OR e.department_id = p_dept_id
    ORDER BY e.salary DESC;
END;
$$ LANGUAGE plpgsql;""",
        "expected": {
            "type": "FUNCTION",
            "name": "get_employee_ranking",
            "is_replace": True,
            "language": "plpgsql",
        }
    },
    "postgresql_complex_recursive_cte": {
        "sql": """CREATE OR REPLACE FUNCTION get_org_hierarchy(
    p_manager_id INTEGER
)
RETURNS TABLE (
    level INTEGER,
    employee_id INTEGER,
    employee_name VARCHAR,
    manager_id INTEGER,
    path TEXT
) AS $$
BEGIN
    RETURN QUERY
    WITH RECURSIVE org_tree AS (
        SELECT 
            1 AS level,
            e.employee_id,
            (e.first_name || ' ' || e.last_name)::VARCHAR AS employee_name,
            e.manager_id,
            e.last_name::TEXT AS path
        FROM employees e
        WHERE e.employee_id = p_manager_id
        
        UNION ALL
        
        SELECT 
            ot.level + 1,
            e.employee_id,
            (e.first_name || ' ' || e.last_name)::VARCHAR,
            e.manager_id,
            ot.path || ' -> ' || e.last_name
        FROM employees e
        INNER JOIN org_tree ot ON e.manager_id = ot.employee_id
        WHERE ot.level < 10
    )
    SELECT * FROM org_tree
    ORDER BY level, employee_name;
END;
$$ LANGUAGE plpgsql;""",
        "expected": {
            "type": "FUNCTION",
            "name": "get_org_hierarchy",
            "is_replace": True,
        }
    },
    "postgresql_complex_lateral_join": {
        "sql": """CREATE OR REPLACE FUNCTION get_top_products_per_category(
    p_top_n INTEGER DEFAULT 3
)
RETURNS TABLE (
    category_id INTEGER,
    category_name VARCHAR,
    product_id INTEGER,
    product_name VARCHAR,
    total_sales NUMERIC,
    rank INTEGER
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        c.category_id,
        c.category_name,
        top_products.product_id,
        top_products.product_name,
        top_products.total_sales,
        top_products.rank::INTEGER
    FROM categories c
    CROSS JOIN LATERAL (
        SELECT 
            p.product_id,
            p.product_name,
            COALESCE(SUM(oi.quantity * oi.unit_price), 0) AS total_sales,
            ROW_NUMBER() OVER (ORDER BY COALESCE(SUM(oi.quantity * oi.unit_price), 0) DESC) AS rank
        FROM products p
        LEFT JOIN order_items oi ON p.product_id = oi.product_id
        WHERE p.category_id = c.category_id
        GROUP BY p.product_id, p.product_name
        ORDER BY total_sales DESC
        LIMIT p_top_n
    ) top_products
    ORDER BY c.category_name, top_products.rank;
END;
$$ LANGUAGE plpgsql;""",
        "expected": {
            "type": "FUNCTION",
            "name": "get_top_products_per_category",
            "is_replace": True,
        }
    },
    "postgresql_complex_json": {
        "sql": """CREATE OR REPLACE FUNCTION get_order_as_json(
    p_order_id INTEGER
)
RETURNS JSONB AS $$
DECLARE
    v_result JSONB;
BEGIN
    SELECT jsonb_build_object(
        'order_id', o.order_id,
        'order_date', o.order_date,
        'status', o.status,
        'customer', jsonb_build_object(
            'customer_id', c.customer_id,
            'name', c.customer_name,
            'email', c.email
        ),
        'items', (
            SELECT jsonb_agg(jsonb_build_object(
                'product_id', p.product_id,
                'product_name', p.product_name,
                'quantity', oi.quantity,
                'unit_price', oi.unit_price,
                'line_total', oi.quantity * oi.unit_price
            ) ORDER BY oi.line_number)
            FROM order_items oi
            JOIN products p ON oi.product_id = p.product_id
            WHERE oi.order_id = o.order_id
        ),
        'total_amount', o.total_amount
    ) INTO v_result
    FROM orders o
    JOIN customers c ON o.customer_id = c.customer_id
    WHERE o.order_id = p_order_id;
    
    RETURN v_result;
END;
$$ LANGUAGE plpgsql;""",
        "expected": {
            "type": "FUNCTION",
            "name": "get_order_as_json",
            "return_type": "JSONB",
            "is_replace": True,
        }
    },
    "postgresql_complex_array": {
        "sql": """CREATE OR REPLACE FUNCTION find_employees_with_skills(
    p_required_skills TEXT[]
)
RETURNS TABLE (
    employee_id INTEGER,
    employee_name VARCHAR,
    skills TEXT[],
    matching_skills TEXT[],
    match_count INTEGER
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        e.employee_id,
        (e.first_name || ' ' || e.last_name)::VARCHAR,
        e.skills,
        ARRAY(
            SELECT unnest(e.skills) 
            INTERSECT 
            SELECT unnest(p_required_skills)
        ) AS matching_skills,
        (
            SELECT COUNT(*)::INTEGER
            FROM unnest(e.skills) s
            WHERE s = ANY(p_required_skills)
        ) AS match_count
    FROM employees e
    WHERE e.skills && p_required_skills
    ORDER BY match_count DESC, e.last_name;
END;
$$ LANGUAGE plpgsql;""",
        "expected": {
            "type": "FUNCTION",
            "name": "find_employees_with_skills",
            "is_replace": True,
        }
    },
}

# ==================== TiDB 测试用例 ====================

TIDB_PROCEDURAL_CASES = {
    "tidb_function_simple": {
        "sql": """CREATE FUNCTION tidb_get_version()
RETURNS VARCHAR(100)
DETERMINISTIC
BEGIN
    RETURN VERSION();
END""",
        "expected": {
            "type": "FUNCTION",
            "name": "tidb_get_version",
            "deterministic": True,
        }
    },
    "tidb_procedure_simple": {
        "sql": """CREATE PROCEDURE archive_old_orders(
    IN cutoff_date DATE,
    IN batch_size INT
)
BEGIN
    INSERT INTO orders_archive SELECT * FROM orders WHERE order_date < cutoff_date LIMIT batch_size;
END""",
        "expected": {
            "type": "PROCEDURE",
            "name": "archive_old_orders",
            "param_count": 2,
        }
    },
    "tidb_trigger_audit": {
        "sql": """CREATE TRIGGER trg_user_audit
AFTER UPDATE ON users
FOR EACH ROW
BEGIN
    INSERT INTO user_audit_log(user_id, changed_at) VALUES(NEW.user_id, NOW());
END""",
        "expected": {
            "type": "TRIGGER",
            "name": "trg_user_audit",
            "timing": "AFTER",
        }
    },
}

# ==================== OceanBase 测试用例 ====================

OCEANBASE_MYSQL_PROCEDURAL_CASES = {
    "oceanbase_mysql_function": {
        "sql": """CREATE FUNCTION ob_mysql_get_tenant_id()
RETURNS BIGINT
DETERMINISTIC
BEGIN
    RETURN 1;
END""",
        "expected": {
            "type": "FUNCTION",
            "name": "ob_mysql_get_tenant_id",
        }
    },
    "oceanbase_mysql_procedure": {
        "sql": """CREATE PROCEDURE sync_tenant_data(
    IN source_tenant_id BIGINT,
    IN target_tenant_id BIGINT
)
BEGIN
    INSERT INTO tenant_config (tenant_id, config_key, config_value)
    SELECT target_tenant_id, config_key, config_value FROM tenant_config WHERE tenant_id = source_tenant_id;
END""",
        "expected": {
            "type": "PROCEDURE",
            "name": "sync_tenant_data",
            "param_count": 2,
        }
    },
}

OCEANBASE_ORACLE_PROCEDURAL_CASES = {
    "oceanbase_oracle_function": {
        "sql": """CREATE FUNCTION ob_oracle_get_sysdate RETURN DATE AS
BEGIN
    RETURN SYSDATE;
END;""",
        "expected": {
            "type": "FUNCTION",
            "name": "ob_oracle_get_sysdate",
            "return_type": "DATE",
        }
    },
    "oceanbase_oracle_procedure": {
        "sql": """CREATE OR REPLACE PROCEDURE sync_distributed_data(
    p_source_zone VARCHAR2,
    p_target_zone VARCHAR2
) AS
BEGIN
    INSERT INTO zone_data (zone_id, data_key) VALUES (p_target_zone, 'test');
END;""",
        "expected": {
            "type": "PROCEDURE",
            "name": "sync_distributed_data",
            "param_count": 2,
        }
    },
}
