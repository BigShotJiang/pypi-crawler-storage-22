"""TiDB 测试 SQL 脚本及期望结果定义。"""
from typing import Any

TIDB_TEST_CASES: list[dict[str, Any]] = [
    {
        "name": "simple_select",
        "description": "简单 SELECT 语句",
        "sql": "SELECT id, name FROM users",
        "expected": {
            "success": True,
            "dialect": "tidb",
            "statement_type": "SELECT",
            "tables": [{"name": "users"}],
            "columns_count": 2,
            "errors": [],
            "tidb_info": {"hints": [], "preprocessed": False},
        },
    },
    {
        "name": "backtick_identifier",
        "description": "反引号标识符（MySQL 兼容）",
        "sql": "SELECT `id`, `user_name` FROM `user_table`",
        "expected": {
            "success": True,
            "dialect": "tidb",
            "statement_type": "SELECT",
            "tables": [{"name": "user_table"}],
            "errors": [],
        },
    },
    {
        "name": "limit_clause",
        "description": "LIMIT 子句（MySQL 兼容）",
        "sql": "SELECT * FROM users LIMIT 10",
        "expected": {
            "success": True,
            "dialect": "tidb",
            "statement_type": "SELECT",
            "tables": [{"name": "users"}],
            "limit": 10,
            "errors": [],
        },
    },
    {
        "name": "join",
        "description": "JOIN（MySQL 兼容）",
        "sql": "SELECT * FROM users u LEFT JOIN orders o ON u.id = o.user_id",
        "expected": {
            "success": True,
            "dialect": "tidb",
            "statement_type": "SELECT",
            "tables_count": 2,
            "joins": [{"type": "LEFT", "table": {"name": "orders", "alias": "o"}}],
            "errors": [],
        },
    },
    {
        "name": "group_by_order_by",
        "description": "GROUP BY / ORDER BY（MySQL 兼容）",
        "sql": """
        SELECT department, COUNT(*) as cnt
        FROM employees
        GROUP BY department
        ORDER BY cnt DESC
        """,
        "expected": {
            "success": True,
            "dialect": "tidb",
            "statement_type": "SELECT",
            "tables": [{"name": "employees"}],
            "group_by": ["department"],
            "order_by": [{"column": "cnt", "direction": "DESC"}],
            "errors": [],
        },
    },
    {
        "name": "use_index_hint",
        "description": "USE_INDEX Hint",
        "sql": "SELECT /*+ USE_INDEX(t, idx_name) */ * FROM t WHERE id = 1",
        "expected": {
            "success": True,
            "dialect": "tidb",
            "statement_type": "SELECT",
            "tables": [{"name": "t"}],
            "tidb_info": {
                "hints": [{"name": "USE_INDEX", "type": "index_hint", "args": "t, idx_name"}],
            },
            "errors": [],
        },
    },
    {
        "name": "hash_join_hint",
        "description": "HASH_JOIN Hint",
        "sql": "SELECT /*+ HASH_JOIN(t1, t2) */ * FROM t1 JOIN t2 ON t1.id = t2.id",
        "expected": {
            "success": True,
            "dialect": "tidb",
            "statement_type": "SELECT",
            "tidb_info": {
                "hints": [{"name": "HASH_JOIN", "type": "join_hint", "args": "t1, t2"}],
            },
            "errors": [],
        },
    },
    {
        "name": "read_from_storage_hint",
        "description": "READ_FROM_STORAGE Hint",
        "sql": "SELECT /*+ READ_FROM_STORAGE(tikv[t]) */ * FROM t",
        "expected": {
            "success": True,
            "dialect": "tidb",
            "statement_type": "SELECT",
            "tables": [{"name": "t"}],
            "tidb_info": {
                "hints": [{"name": "READ_FROM_STORAGE", "type": "storage_hint", "args": "tikv[t]"}],
            },
            "errors": [],
        },
    },
    {
        "name": "multiple_hints",
        "description": "多个 Hint",
        "sql": """
        SELECT /*+ USE_INDEX(t1, idx1) */ /*+ HASH_JOIN(t1, t2) */ *
        FROM t1 JOIN t2 ON t1.id = t2.id
        """,
        "expected": {
            "success": True,
            "dialect": "tidb",
            "statement_type": "SELECT",
            "tidb_info": {"hints_count": 2},
            "errors": [],
        },
    },
    {
        "name": "hash_agg_hint",
        "description": "HASH_AGG Hint",
        "sql": "SELECT /*+ HASH_AGG() */ department, COUNT(*) FROM employees GROUP BY department",
        "expected": {
            "success": True,
            "dialect": "tidb",
            "statement_type": "SELECT",
            "tables": [{"name": "employees"}],
            "group_by": ["department"],
            "tidb_info": {
                "hints": [{"name": "HASH_AGG", "type": "agg_hint", "args": ""}],
            },
            "errors": [],
        },
    },
    {
        "name": "auto_random_detection",
        "description": "AUTO_RANDOM 检测（通过预处理支持）",
        "sql": """
        CREATE TABLE users (
            id BIGINT AUTO_RANDOM PRIMARY KEY,
            name VARCHAR(100)
        )
        """,
        "expected": {
            "success": True,
            "dialect": "tidb",
            "statement_type": "CREATE",
            "tidb_info": {
                "preprocessed": True,
                "auto_random_columns": ["id"],
            },
            "errors": [],
        },
    },
    {
        "name": "insert",
        "description": "INSERT 语句",
        "sql": "INSERT INTO users (name, email) VALUES ('John', 'john@example.com')",
        "expected": {
            "success": True,
            "dialect": "tidb",
            "statement_type": "INSERT",
            "tables": [{"name": "users"}],
            "errors": [],
        },
    },
    {
        "name": "update",
        "description": "UPDATE 语句",
        "sql": "UPDATE users SET name = 'Jane' WHERE id = 1",
        "expected": {
            "success": True,
            "dialect": "tidb",
            "statement_type": "UPDATE",
            "tables": [{"name": "users"}],
            "conditions_count": 1,
            "errors": [],
        },
    },
    {
        "name": "delete",
        "description": "DELETE 语句",
        "sql": "DELETE FROM users WHERE id = 1",
        "expected": {
            "success": True,
            "dialect": "tidb",
            "statement_type": "DELETE",
            "tables": [{"name": "users"}],
            "conditions_count": 1,
            "errors": [],
        },
    },
    {
        "name": "subquery",
        "description": "子查询",
        "sql": """
        SELECT * FROM users
        WHERE department_id IN (
            SELECT id FROM departments WHERE status = 'active'
        )
        """,
        "expected": {
            "success": True,
            "dialect": "tidb",
            "statement_type": "SELECT",
            "errors": [],
        },
    },
    {
        "name": "cte",
        "description": "CTE (WITH 子句)",
        "sql": """
        WITH active_users AS (
            SELECT * FROM users WHERE status = 'active'
        )
        SELECT * FROM active_users
        """,
        "expected": {
            "success": True,
            "dialect": "tidb",
            "statement_type": "SELECT",
            "errors": [],
        },
    },
    {
        "name": "window_function",
        "description": "窗口函数",
        "sql": """
        SELECT 
            name,
            salary,
            ROW_NUMBER() OVER (PARTITION BY department ORDER BY salary DESC) as rank
        FROM employees
        """,
        "expected": {
            "success": True,
            "dialect": "tidb",
            "statement_type": "SELECT",
            "tables": [{"name": "employees"}],
            "errors": [],
        },
    },
    {
        "name": "no_hints",
        "description": "无 Hint 的 SQL",
        "sql": "SELECT * FROM users WHERE id = 1",
        "expected": {
            "success": True,
            "dialect": "tidb",
            "statement_type": "SELECT",
            "tables": [{"name": "users"}],
            "tidb_info": {"hints": []},
            "errors": [],
        },
    },
]
