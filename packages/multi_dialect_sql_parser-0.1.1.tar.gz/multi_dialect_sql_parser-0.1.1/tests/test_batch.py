"""批量解析测试。"""
import pytest
from sql_parser import SQLParser


class TestBatchParsing:
    """批量解析功能测试。"""
    
    def setup_method(self):
        """初始化解析器。"""
        self.parser = SQLParser(dialect="mysql")
    
    def test_batch_parse_small(self):
        """测试小批量解析（不触发多进程）。"""
        sqls = [
            "SELECT * FROM users",
            "SELECT id, name FROM products WHERE price > 100",
            "INSERT INTO logs (message) VALUES ('test')",
        ]
        
        results = list(self.parser.parse_batch(sqls))
        
        assert len(results) == 3
        assert all(r.success for r in results)
    
    def test_batch_parse_empty(self):
        """测试空列表。"""
        results = list(self.parser.parse_batch([]))
        assert len(results) == 0
    
    def test_batch_parse_single(self):
        """测试单条 SQL 批量解析。"""
        sqls = ["SELECT 1"]
        results = list(self.parser.parse_batch(sqls))
        
        assert len(results) == 1
        assert results[0].success
    
    def test_batch_parse_with_errors(self):
        """测试包含错误 SQL 的批量解析。"""
        sqls = [
            "SELECT * FROM users",
            "SELEC * FROM invalid",  # 语法错误
            "SELECT id FROM products",
        ]
        
        results = list(self.parser.parse_batch(sqls))
        
        assert len(results) == 3
        assert results[0].success
        assert not results[1].success  # 错误的 SQL
        assert results[2].success
    
    def test_batch_parse_all(self):
        """测试 parse_batch_all 方法。"""
        sqls = [
            "SELECT * FROM users",
            "SELECT * FROM products",
            "SELECT * FROM WHERE",  # 语法错误：WHERE 后缺少条件
        ]
        
        result = self.parser.parse_batch_all(sqls)
        
        assert result.total_statements == 3
        assert result.successful == 2
        assert result.failed == 1
        assert len(result.results) == 3
    
    def test_batch_parse_medium(self):
        """测试中等批量（100 条）。"""
        sqls = [f"SELECT * FROM table_{i}" for i in range(100)]
        
        results = list(self.parser.parse_batch(sqls))
        
        assert len(results) == 100
        assert all(r.success for r in results)
    
    def test_batch_parse_mixed_statements(self):
        """测试混合语句类型。"""
        sqls = [
            "SELECT * FROM users",
            "INSERT INTO users (name) VALUES ('test')",
            "UPDATE users SET name = 'new' WHERE id = 1",
            "DELETE FROM users WHERE id = 2",
            "CREATE TABLE temp (id INT)",
        ]
        
        results = list(self.parser.parse_batch(sqls))
        
        assert len(results) == 5
        assert results[0].statement_type == "SELECT"
        assert results[1].statement_type == "INSERT"
        assert results[2].statement_type == "UPDATE"
        assert results[3].statement_type == "DELETE"
        assert results[4].statement_type == "CREATE"


class TestBatchParsingMultiDialect:
    """多方言批量解析测试。"""
    
    def test_mysql_batch(self):
        """MySQL 批量解析。"""
        parser = SQLParser(dialect="mysql")
        sqls = [
            "SELECT `id` FROM `users`",
            "SELECT * FROM users LIMIT 10",
        ]
        
        results = list(parser.parse_batch(sqls))
        assert len(results) == 2
        assert all(r.success for r in results)
    
    def test_postgresql_batch(self):
        """PostgreSQL 批量解析。"""
        parser = SQLParser(dialect="postgresql")
        sqls = [
            'SELECT "id" FROM "users"',
            "SELECT '123'::integer",
        ]
        
        results = list(parser.parse_batch(sqls))
        assert len(results) == 2
        assert all(r.success for r in results)
