"""错误处理和降级策略测试。"""
import pytest
from sql_parser import SQLParser
from sql_parser.utils import calculate_error_position, extract_error_context


class TestErrorPositionCalculation:
    """错误位置计算测试。"""
    
    def test_calculate_position_first_line(self):
        """测试第一行的位置计算。"""
        sql = "SELECT * FROM users"
        line, col = calculate_error_position(sql, 7)  # 指向 '*'
        
        assert line == 1
        assert col == 8
    
    def test_calculate_position_multiline(self):
        """测试多行 SQL 的位置计算。"""
        sql = "SELECT *\nFROM users\nWHERE id = 1"
        
        # 第一行
        line, col = calculate_error_position(sql, 0)
        assert line == 1
        assert col == 1
        
        # 第二行开头 (offset 9 是 'F')
        line, col = calculate_error_position(sql, 9)
        assert line == 2
        assert col == 1
        
        # 第三行 (offset 20 是换行符后的 'W')
        line, col = calculate_error_position(sql, 20)  # 'W' in WHERE
        assert line == 3
        assert col == 1
    
    def test_calculate_position_edge_cases(self):
        """测试边界情况。"""
        sql = "SELECT 1"
        
        # 负数偏移量
        line, col = calculate_error_position(sql, -1)
        assert line == 1
        assert col == 1
        
        # 超出范围
        line, col = calculate_error_position(sql, 100)
        assert line == 1
        assert col == 1


class TestErrorContextExtraction:
    """错误上下文提取测试。"""
    
    def test_extract_context_middle(self):
        """测试中间位置的上下文提取。"""
        sql = "SELECT * FROM users WHERE id = 1"
        context = extract_error_context(sql, 14, context_size=10)
        
        assert "FROM" in context
        assert "users" in context
    
    def test_extract_context_start(self):
        """测试开头位置的上下文提取。"""
        sql = "SELECT * FROM users"
        context = extract_error_context(sql, 0, context_size=10)
        
        assert context.startswith("SELECT")
        assert "..." in context  # 应该有省略号
    
    def test_extract_context_end(self):
        """测试结尾位置的上下文提取。"""
        sql = "SELECT * FROM users"
        context = extract_error_context(sql, len(sql) - 1, context_size=10)
        
        assert "users" in context


class TestSyntaxErrorHandling:
    """语法错误处理测试。"""
    
    def setup_method(self):
        self.parser = SQLParser(dialect="mysql")
    
    def test_syntax_error_detection(self):
        """测试语法错误检测。"""
        sql = "SELECT * FROM WHERE"  # 缺少表名
        result = self.parser.parse(sql)
        
        assert not result.success
        assert len(result.errors) > 0
        assert result.errors[0].error_type == "syntax_error"
    
    def test_syntax_error_message(self):
        """测试语法错误消息。"""
        sql = "SELEC * FROM users"  # 拼写错误
        result = self.parser.parse(sql)
        
        # SQLGlot 可能会把 SELEC 当作列名，所以这个测试可能通过
        # 使用更明确的语法错误
        sql = "SELECT * FROM users WHERE"  # 缺少条件
        result = self.parser.parse(sql)
        
        assert not result.success
        assert len(result.errors) > 0
    
    def test_syntax_error_context(self):
        """测试语法错误上下文。"""
        sql = "SELECT * FROM users WHERE id ="  # 缺少值
        result = self.parser.parse(sql)
        
        assert not result.success
        assert len(result.errors) > 0
        assert result.errors[0].context is not None


class TestDialectValidation:
    """方言验证测试。"""
    
    def test_invalid_dialect(self):
        """测试无效方言。"""
        with pytest.raises(ValueError) as exc_info:
            SQLParser(dialect="invalid_dialect")
        
        assert "不支持的方言" in str(exc_info.value)
    
    def test_supported_dialects_in_error(self):
        """测试错误消息包含支持的方言列表。"""
        with pytest.raises(ValueError) as exc_info:
            SQLParser(dialect="unknown")
        
        error_msg = str(exc_info.value)
        assert "mysql" in error_msg
        assert "postgresql" in error_msg
        assert "oracle" in error_msg


class TestBatchErrorIsolation:
    """批量解析错误隔离测试。"""
    
    def setup_method(self):
        self.parser = SQLParser(dialect="mysql")
    
    def test_error_isolation(self):
        """测试错误不影响其他 SQL 解析。"""
        sqls = [
            "SELECT * FROM users",
            "SELECT * FROM WHERE",  # 错误
            "SELECT * FROM products",
        ]
        
        results = list(self.parser.parse_batch(sqls))
        
        assert len(results) == 3
        assert results[0].success
        assert not results[1].success
        assert results[2].success
    
    def test_multiple_errors(self):
        """测试多个错误的处理。"""
        sqls = [
            "SELECT * FROM WHERE",  # 错误 1
            "SELECT * FROM users",
            "SELECT * FROM WHERE id",  # 错误 2
        ]
        
        results = list(self.parser.parse_batch(sqls))
        
        assert len(results) == 3
        assert not results[0].success
        assert results[1].success
        assert not results[2].success
    
    def test_batch_all_error_count(self):
        """测试批量解析错误计数。"""
        sqls = [
            "SELECT * FROM users",
            "SELECT * FROM WHERE",  # 错误
            "SELECT * FROM products",
            "SELECT * FROM WHERE id",  # 错误
        ]
        
        result = self.parser.parse_batch_all(sqls)
        
        assert result.total_statements == 4
        assert result.successful == 2
        assert result.failed == 2


class TestPartialParsing:
    """部分解析测试。"""
    
    def setup_method(self):
        self.parser = SQLParser(dialect="mysql")
    
    def test_error_preserves_sql(self):
        """测试错误结果保留原始 SQL。"""
        sql = "SELECT * FROM WHERE"
        result = self.parser.parse(sql)
        
        assert result.sql == sql
    
    def test_error_preserves_dialect(self):
        """测试错误结果保留方言信息。"""
        sql = "SELECT * FROM WHERE"
        result = self.parser.parse(sql)
        
        assert result.dialect == "mysql"


class TestUnsupportedSyntax:
    """不支持语法处理测试。"""
    
    def setup_method(self):
        self.parser = SQLParser(dialect="mysql")
    
    def test_complex_syntax_handling(self):
        """测试复杂语法处理。"""
        # 大多数标准 SQL 应该能解析
        sql = """
        WITH RECURSIVE cte AS (
            SELECT 1 as n
            UNION ALL
            SELECT n + 1 FROM cte WHERE n < 10
        )
        SELECT * FROM cte
        """
        result = self.parser.parse(sql)
        
        # 递归 CTE 应该能解析
        assert result.success


class TestErrorTypes:
    """错误类型测试。"""
    
    def setup_method(self):
        self.parser = SQLParser(dialect="mysql")
    
    def test_syntax_error_type(self):
        """测试语法错误类型。"""
        sql = "SELECT * FROM WHERE"
        result = self.parser.parse(sql)
        
        assert not result.success
        assert result.errors[0].error_type == "syntax_error"
    
    def test_error_has_line_info(self):
        """测试错误包含行信息。"""
        sql = "SELECT * FROM WHERE"
        result = self.parser.parse(sql)
        
        assert not result.success
        assert result.errors[0].line is not None
    
    def test_error_has_column_info(self):
        """测试错误包含列信息。"""
        sql = "SELECT * FROM WHERE"
        result = self.parser.parse(sql)
        
        assert not result.success
        assert result.errors[0].column is not None


class TestMultiDialectErrors:
    """多方言错误处理测试。"""
    
    def test_mysql_specific_error(self):
        """测试 MySQL 特有语法错误。"""
        parser = SQLParser(dialect="mysql")
        # MySQL 不支持 :: 类型转换
        sql = "SELECT '123'::integer"
        result = parser.parse(sql)
        
        # SQLGlot 可能会解析成功或失败，取决于版本
        # 主要测试不会崩溃
        assert result is not None
    
    def test_postgresql_specific_error(self):
        """测试 PostgreSQL 特有语法错误。"""
        parser = SQLParser(dialect="postgresql")
        sql = "SELECT * FROM users"
        result = parser.parse(sql)
        
        assert result.success
    
    def test_oracle_specific_error(self):
        """测试 Oracle 特有语法错误。"""
        parser = SQLParser(dialect="oracle")
        sql = "SELECT * FROM users"
        result = parser.parse(sql)
        
        assert result.success
