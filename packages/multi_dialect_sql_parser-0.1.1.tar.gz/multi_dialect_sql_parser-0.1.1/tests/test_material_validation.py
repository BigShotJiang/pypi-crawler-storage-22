"""批量验证所有 SQL 测试物料的解析支持情况。

运行方式：
    pytest tests/test_material_validation.py -v -s

生成报告：
    python -m tests.test_material_validation
"""
from __future__ import annotations

import sys
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any

from sql_parser import SQLParser

# 导入所有测试物料
from tests.sql_scripts.mysql_scripts import MYSQL_TEST_CASES
from tests.sql_scripts.postgresql_scripts import POSTGRESQL_TEST_CASES
from tests.sql_scripts.oracle_scripts import ORACLE_TEST_CASES
from tests.sql_scripts.tidb_scripts import TIDB_TEST_CASES
from tests.sql_scripts.oceanbase_scripts import (
    OCEANBASE_MYSQL_TEST_CASES,
    OCEANBASE_ORACLE_TEST_CASES,
)
from tests.sql_scripts.procedural_scripts import (
    ORACLE_PROCEDURAL_CASES,
    MYSQL_PROCEDURAL_CASES,
    POSTGRESQL_PROCEDURAL_CASES,
    TIDB_PROCEDURAL_CASES,
    OCEANBASE_MYSQL_PROCEDURAL_CASES,
    OCEANBASE_ORACLE_PROCEDURAL_CASES,
)


@dataclass
class TestResult:
    """单个测试用例的结果。"""
    name: str
    description: str
    sql: str
    success: bool
    error: str | None = None
    category: str = ""


@dataclass
class CategoryResult:
    """按类别汇总的结果。"""
    total: int = 0
    passed: int = 0
    failed: int = 0
    cases: list[TestResult] = field(default_factory=list)


@dataclass
class DialectResult:
    """按方言汇总的结果。"""
    dialect: str
    total: int = 0
    passed: int = 0
    failed: int = 0
    categories: dict[str, CategoryResult] = field(default_factory=dict)


def extract_category(name: str) -> str:
    """从测试用例名称提取类别。"""
    # 常见类别映射
    category_keywords = {
        "select": "SELECT 查询",
        "insert": "INSERT 语句",
        "update": "UPDATE 语句",
        "delete": "DELETE 语句",
        "create": "CREATE 语句",
        "join": "JOIN 连接",
        "limit": "LIMIT/分页",
        "where": "WHERE 条件",
        "group": "GROUP BY",
        "order": "ORDER BY",
        "function": "函数/存储函数",
        "procedure": "存储过程",
        "trigger": "触发器",
        "package": "包(Package)",
        "anonymous": "匿名块",
        "cte": "CTE/WITH",
        "window": "窗口函数",
        "subquery": "子查询",
        "hint": "Hint 优化",
        "merge": "MERGE 语句",
        "complex": "复杂查询",
        "cast": "类型转换",
        "array": "数组操作",
        "json": "JSON 操作",
        "rownum": "ROWNUM/伪列",
        "dual": "DUAL 表",
        "nvl": "NVL 函数",
        "decode": "DECODE 函数",
        "backtick": "反引号标识符",
        "double_quote": "双引号标识符",
        "schema": "Schema 限定",
        "returning": "RETURNING 子句",
        "coalesce": "COALESCE 函数",
        "serial": "SERIAL 类型",
        "auto_random": "AUTO_RANDOM",
        "parallel": "并行 Hint",
        "index": "索引 Hint",
        "lateral": "LATERAL JOIN",
        "recursive": "递归 CTE",
        "do": "DO 块",
    }
    
    name_lower = name.lower()
    for keyword, category in category_keywords.items():
        if keyword in name_lower:
            return category
    return "其他"


def run_validation(
    dialect: str,
    test_cases: list[dict[str, Any]] | dict[str, dict[str, Any]],
    is_procedural: bool = False,
) -> DialectResult:
    """运行指定方言的所有测试用例验证。"""
    result = DialectResult(dialect=dialect)
    parser = SQLParser(dialect=dialect)
    
    # 统一处理 list 和 dict 格式的测试用例
    if isinstance(test_cases, dict):
        cases_list = [
            {"name": name, "sql": case["sql"], "description": name, **case}
            for name, case in test_cases.items()
        ]
    else:
        cases_list = test_cases
    
    for case in cases_list:
        name = case.get("name", "unknown")
        sql = case.get("sql", "")
        description = case.get("description", name)
        
        # 确定类别
        if is_procedural:
            # 过程化语法根据类型分类
            expected_type = case.get("expected", {}).get("type", "")
            category = {
                "FUNCTION": "函数/存储函数",
                "PROCEDURE": "存储过程",
                "TRIGGER": "触发器",
                "PACKAGE": "包(Package)",
                "PACKAGE_BODY": "包体(Package Body)",
                "ANONYMOUS_BLOCK": "匿名块",
            }.get(expected_type, extract_category(name))
        else:
            category = extract_category(name)
        
        # 执行解析
        test_result = TestResult(
            name=name,
            description=description,
            sql=sql[:200] + "..." if len(sql) > 200 else sql,
            success=False,
            category=category,
        )
        
        try:
            parse_result = parser.parse(sql)
            test_result.success = parse_result.success
            if not parse_result.success:
                errors = parse_result.errors or []
                test_result.error = "; ".join(str(e) for e in errors[:2])
        except Exception as e:
            test_result.success = False
            test_result.error = str(e)[:200]
        
        # 更新统计
        result.total += 1
        if test_result.success:
            result.passed += 1
        else:
            result.failed += 1
        
        # 按类别统计
        if category not in result.categories:
            result.categories[category] = CategoryResult()
        cat_result = result.categories[category]
        cat_result.total += 1
        if test_result.success:
            cat_result.passed += 1
        else:
            cat_result.failed += 1
        cat_result.cases.append(test_result)
    
    return result


def generate_report(results: list[DialectResult]) -> str:
    """生成 Markdown 格式的测试报告。"""
    lines = [
        "# SQL 解析器支持情况报告",
        "",
        f"生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        "",
        "## 总览",
        "",
    ]
    
    # 总体统计
    total_all = sum(r.total for r in results)
    passed_all = sum(r.passed for r in results)
    failed_all = sum(r.failed for r in results)
    pass_rate = (passed_all / total_all * 100) if total_all > 0 else 0
    
    lines.extend([
        f"- 总测试用例: {total_all}",
        f"- 成功: {passed_all} ({pass_rate:.1f}%)",
        f"- 失败: {failed_all} ({100 - pass_rate:.1f}%)",
        "",
        "### 各方言概览",
        "",
        "| 方言 | 总数 | 成功 | 失败 | 成功率 |",
        "|------|------|------|------|--------|",
    ])
    
    for r in results:
        rate = (r.passed / r.total * 100) if r.total > 0 else 0
        lines.append(f"| {r.dialect} | {r.total} | {r.passed} | {r.failed} | {rate:.1f}% |")
    
    lines.append("")
    
    # 各方言详情
    for r in results:
        lines.extend([
            f"## {r.dialect}",
            "",
            f"总计: {r.total} 个用例，成功 {r.passed}，失败 {r.failed}",
            "",
        ])
        
        # 按类别展示
        lines.extend([
            "### 支持情况",
            "",
            "| 语法类型 | 状态 | 用例数 | 失败原因 |",
            "|---------|------|-------|---------|",
        ])
        
        for cat_name, cat_result in sorted(r.categories.items()):
            status = "✅" if cat_result.failed == 0 else "❌" if cat_result.passed == 0 else "⚠️"
            count = f"{cat_result.passed}/{cat_result.total}"
            
            # 收集失败原因
            failed_reasons = []
            for case in cat_result.cases:
                if not case.success and case.error:
                    # 简化错误信息
                    error = case.error
                    if len(error) > 80:
                        error = error[:80] + "..."
                    failed_reasons.append(f"`{case.name}`: {error}")
            
            reason = "<br>".join(failed_reasons[:3]) if failed_reasons else "-"
            lines.append(f"| {cat_name} | {status} | {count} | {reason} |")
        
        lines.append("")
        
        # 失败用例详情
        failed_cases = [c for cat in r.categories.values() for c in cat.cases if not c.success]
        if failed_cases:
            lines.extend([
                "### 失败用例详情",
                "",
            ])
            for case in failed_cases[:20]:  # 最多显示 20 个
                lines.extend([
                    f"#### {case.name}",
                    "",
                    f"- 类别: {case.category}",
                    f"- 错误: `{case.error}`",
                    "",
                    "```sql",
                    case.sql,
                    "```",
                    "",
                ])
            
            if len(failed_cases) > 20:
                lines.append(f"... 还有 {len(failed_cases) - 20} 个失败用例未显示")
                lines.append("")
    
    return "\n".join(lines)


def run_all_validations() -> list[DialectResult]:
    """运行所有方言的验证。"""
    results = []
    
    # 基础 SQL 测试
    print("验证 MySQL 基础语法...")
    results.append(run_validation("mysql", MYSQL_TEST_CASES))
    
    print("验证 PostgreSQL 基础语法...")
    results.append(run_validation("postgresql", POSTGRESQL_TEST_CASES))
    
    print("验证 Oracle 基础语法...")
    results.append(run_validation("oracle", ORACLE_TEST_CASES))
    
    print("验证 TiDB 基础语法...")
    results.append(run_validation("tidb", TIDB_TEST_CASES))
    
    print("验证 OceanBase-MySQL 基础语法...")
    results.append(run_validation("oceanbase-mysql", OCEANBASE_MYSQL_TEST_CASES))
    
    print("验证 OceanBase-Oracle 基础语法...")
    results.append(run_validation("oceanbase-oracle", OCEANBASE_ORACLE_TEST_CASES))
    
    # 过程化语法测试
    print("验证 Oracle PL/SQL...")
    results.append(run_validation("oracle", ORACLE_PROCEDURAL_CASES, is_procedural=True))
    
    print("验证 MySQL 存储过程...")
    results.append(run_validation("mysql", MYSQL_PROCEDURAL_CASES, is_procedural=True))
    
    print("验证 PostgreSQL PL/pgSQL...")
    results.append(run_validation("postgresql", POSTGRESQL_PROCEDURAL_CASES, is_procedural=True))
    
    print("验证 TiDB 存储过程...")
    results.append(run_validation("tidb", TIDB_PROCEDURAL_CASES, is_procedural=True))
    
    print("验证 OceanBase-MySQL 存储过程...")
    results.append(run_validation("oceanbase-mysql", OCEANBASE_MYSQL_PROCEDURAL_CASES, is_procedural=True))
    
    print("验证 OceanBase-Oracle 存储过程...")
    results.append(run_validation("oceanbase-oracle", OCEANBASE_ORACLE_PROCEDURAL_CASES, is_procedural=True))
    
    return results


def merge_dialect_results(results: list[DialectResult]) -> list[DialectResult]:
    """合并同一方言的结果。"""
    merged: dict[str, DialectResult] = {}
    
    for r in results:
        if r.dialect not in merged:
            merged[r.dialect] = DialectResult(dialect=r.dialect)
        
        m = merged[r.dialect]
        m.total += r.total
        m.passed += r.passed
        m.failed += r.failed
        
        for cat_name, cat_result in r.categories.items():
            if cat_name not in m.categories:
                m.categories[cat_name] = CategoryResult()
            mc = m.categories[cat_name]
            mc.total += cat_result.total
            mc.passed += cat_result.passed
            mc.failed += cat_result.failed
            mc.cases.extend(cat_result.cases)
    
    return list(merged.values())


# pytest 测试函数
def test_validate_all_materials():
    """pytest 入口：验证所有物料并输出摘要。"""
    results = run_all_validations()
    merged = merge_dialect_results(results)
    
    total = sum(r.total for r in merged)
    passed = sum(r.passed for r in merged)
    failed = sum(r.failed for r in merged)
    
    print(f"\n{'='*60}")
    print(f"验证完成: {total} 个用例，成功 {passed}，失败 {failed}")
    print(f"{'='*60}")
    
    for r in merged:
        rate = (r.passed / r.total * 100) if r.total > 0 else 0
        status = "✅" if r.failed == 0 else "❌"
        print(f"{status} {r.dialect}: {r.passed}/{r.total} ({rate:.1f}%)")
    
    # 不因为有失败用例而让测试失败，只是报告
    # 如果需要严格模式，取消下面的注释
    # assert failed == 0, f"{failed} 个用例解析失败"


if __name__ == "__main__":
    print("开始验证所有 SQL 测试物料...")
    print("=" * 60)
    
    results = run_all_validations()
    merged = merge_dialect_results(results)
    
    # 生成报告
    report = generate_report(merged)
    
    # 保存报告
    report_path = Path(__file__).parent.parent / "PARSE_SUPPORT_REPORT.md"
    report_path.write_text(report, encoding="utf-8")
    
    print("=" * 60)
    print(f"报告已生成: {report_path}")
    
    # 输出摘要
    total = sum(r.total for r in merged)
    passed = sum(r.passed for r in merged)
    print(f"总计: {total} 个用例，成功 {passed} ({passed/total*100:.1f}%)")
