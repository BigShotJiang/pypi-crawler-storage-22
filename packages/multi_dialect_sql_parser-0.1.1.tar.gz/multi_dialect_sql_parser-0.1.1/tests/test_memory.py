"""内存占用测试。"""
import gc
import sys
import pytest
from sql_parser import SQLParser


class TestMemoryUsage:
    """内存占用测试。"""
    
    def setup_method(self):
        """初始化解析器。"""
        self.parser = SQLParser(dialect="mysql")
    
    def test_streaming_memory(self):
        """测试流式返回不会累积内存。"""
        # 生成 200 条 SQL
        sqls = [f"SELECT * FROM table_{i} WHERE id = {i}" for i in range(200)]
        
        # 强制 GC
        gc.collect()
        
        # 使用生成器逐条处理，不保留结果
        count = 0
        for result in self.parser.parse_batch(sqls):
            count += 1
            # 不保留 result 引用
        
        assert count == 200
    
    def test_batch_result_cleanup(self):
        """测试批量结果可以被正确清理。"""
        sqls = [f"SELECT * FROM table_{i}" for i in range(100)]
        
        # 获取结果
        results = list(self.parser.parse_batch(sqls))
        assert len(results) == 100
        
        # 删除引用
        del results
        gc.collect()
        
        # 再次解析，确保没有内存泄漏
        results2 = list(self.parser.parse_batch(sqls))
        assert len(results2) == 100
    
    def test_parser_reuse(self):
        """测试解析器重复使用。"""
        sqls = [f"SELECT * FROM table_{i}" for i in range(50)]
        
        # 多次使用同一个解析器
        for _ in range(5):
            results = list(self.parser.parse_batch(sqls))
            assert len(results) == 50
            del results
            gc.collect()
    
    def test_result_size(self):
        """测试单个结果的大小合理。"""
        sql = "SELECT id, name FROM users WHERE status = 'active'"
        result = self.parser.parse(sql)
        
        # 检查结果对象大小（粗略估计）
        result_size = sys.getsizeof(result)
        
        # 结果对象不应该太大（小于 10KB）
        assert result_size < 10240, f"结果对象太大: {result_size} bytes"
    
    def test_error_result_cleanup(self):
        """测试错误结果的清理。"""
        sqls = [
            "SELECT * FROM users",
            "INVALID SQL SYNTAX",
            "SELECT * FROM products",
        ]
        
        results = list(self.parser.parse_batch(sqls))
        
        # 检查错误结果
        assert not results[1].success
        assert len(results[1].errors) > 0
        
        # 清理
        del results
        gc.collect()


class TestLargeInput:
    """大输入测试。"""
    
    def setup_method(self):
        self.parser = SQLParser(dialect="mysql")
    
    def test_long_sql(self):
        """测试长 SQL 语句。"""
        # 生成一个有很多列的 SELECT
        columns = ", ".join([f"col_{i}" for i in range(100)])
        sql = f"SELECT {columns} FROM large_table"
        
        result = self.parser.parse(sql)
        
        assert result.success
        assert len(result.columns) == 100
    
    def test_many_conditions(self):
        """测试多条件 WHERE。"""
        conditions = " AND ".join([f"col_{i} = {i}" for i in range(20)])
        sql = f"SELECT * FROM users WHERE {conditions}"
        
        result = self.parser.parse(sql)
        
        assert result.success
    
    def test_many_joins(self):
        """测试多表 JOIN。"""
        joins = " ".join([
            f"LEFT JOIN table_{i} t{i} ON t0.id = t{i}.ref_id"
            for i in range(1, 10)
        ])
        sql = f"SELECT * FROM table_0 t0 {joins}"
        
        result = self.parser.parse(sql)
        
        assert result.success
        assert len(result.joins) == 9
