"""MySQL 方言单元测试。

使用 SQL 脚本作为入参，完整验证所有解析后的参数。
"""
import pytest
from sql_parser import SQLParser
from tests.conftest import verify_parse_result
from tests.sql_scripts.mysql_scripts import MYSQL_TEST_CASES


class TestMySQLFromScripts:
    """MySQL SQL 脚本测试。"""
    
    @pytest.fixture(autouse=True)
    def setup(self, mysql_parser: SQLParser) -> None:
        """初始化 MySQL 解析器。"""
        self.parser = mysql_parser
    
    @pytest.mark.parametrize(
        "test_case",
        MYSQL_TEST_CASES,
        ids=[tc["name"] for tc in MYSQL_TEST_CASES]
    )
    def test_mysql_sql_scripts(self, test_case: dict) -> None:
        """测试 MySQL SQL 脚本解析。
        
        Args:
            test_case: 测试用例，包含 sql 和 expected 字段
        """
        # 解析 SQL
        result = self.parser.parse(test_case["sql"])
        
        # 验证所有期望的字段
        verify_parse_result(result, test_case["expected"])


class TestMySQLBasic:
    """MySQL 基础语法测试（保留原有测试以确保兼容性）。"""
    
    def setup_method(self) -> None:
        """初始化 MySQL 解析器。"""
        self.parser = SQLParser(dialect="mysql")
    
    def test_simple_select(self) -> None:
        """测试简单 SELECT 语句。"""
        sql = "SELECT id, name FROM users"
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "mysql",
            "statement_type": "SELECT",
            "tables": [
                {"name": "users", "schema_name": None, "alias": None, "type": "table"}
            ],
            "errors": [],
            "warnings": [],
        })
    
    def test_backtick_identifier(self) -> None:
        """测试反引号标识符解析。"""
        sql = "SELECT `id`, `user_name` FROM `user_table`"
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "mysql",
            "statement_type": "SELECT",
            "tables": [
                {"name": "user_table", "schema_name": None, "alias": None, "type": "table"}
            ],
            "errors": [],
            "warnings": [],
        })
    
    def test_limit_clause(self) -> None:
        """测试 LIMIT 子句解析。"""
        sql = "SELECT * FROM users LIMIT 10"
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "mysql",
            "statement_type": "SELECT",
            "limit": 10,
            "offset_value": None,
            "errors": [],
            "warnings": [],
        })
    
    def test_limit_offset(self) -> None:
        """测试 LIMIT OFFSET 解析。"""
        sql = "SELECT * FROM users LIMIT 10 OFFSET 20"
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "mysql",
            "statement_type": "SELECT",
            "limit": 10,
            "offset_value": 20,
            "errors": [],
            "warnings": [],
        })
    
    def test_where_condition(self) -> None:
        """测试 WHERE 条件解析。"""
        sql = "SELECT * FROM users WHERE age > 18"
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "mysql",
            "statement_type": "SELECT",
            "conditions_count": 1,
            "errors": [],
            "warnings": [],
        })
    
    def test_multiple_conditions(self) -> None:
        """测试多条件 WHERE 解析。"""
        sql = "SELECT * FROM users WHERE age > 18 AND status = 'active'"
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "mysql",
            "statement_type": "SELECT",
            "conditions_count": 1,
            "errors": [],
            "warnings": [],
        })


class TestMySQLJoin:
    """MySQL JOIN 语法测试。"""
    
    def setup_method(self) -> None:
        self.parser = SQLParser(dialect="mysql")
    
    def test_inner_join(self) -> None:
        """测试 INNER JOIN。"""
        sql = "SELECT * FROM users u INNER JOIN orders o ON u.id = o.user_id"
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "mysql",
            "statement_type": "SELECT",
            "tables_count": 2,
            "joins": [{"type": "INNER", "table": {"name": "orders", "alias": "o"}}],
            "errors": [],
        })
    
    def test_left_join(self) -> None:
        """测试 LEFT JOIN。"""
        sql = "SELECT * FROM users u LEFT JOIN orders o ON u.id = o.user_id"
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "mysql",
            "statement_type": "SELECT",
            "tables_count": 2,
            "joins": [{"type": "LEFT", "table": {"name": "orders", "alias": "o"}}],
            "errors": [],
        })
    
    def test_multiple_joins(self) -> None:
        """测试多表 JOIN。"""
        sql = """
        SELECT * FROM users u
        LEFT JOIN orders o ON u.id = o.user_id
        LEFT JOIN products p ON o.product_id = p.id
        """
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "mysql",
            "statement_type": "SELECT",
            "tables_count": 3,
            "joins_count": 2,
            "errors": [],
        })


class TestMySQLGroupOrder:
    """MySQL GROUP BY / ORDER BY 测试。"""
    
    def setup_method(self) -> None:
        self.parser = SQLParser(dialect="mysql")
    
    def test_group_by(self) -> None:
        """测试 GROUP BY。"""
        sql = "SELECT department, COUNT(*) FROM employees GROUP BY department"
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "mysql",
            "statement_type": "SELECT",
            "group_by": ["department"],
            "errors": [],
            "warnings": [],
        })
    
    def test_order_by(self) -> None:
        """测试 ORDER BY。"""
        sql = "SELECT * FROM users ORDER BY created_at DESC"
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "mysql",
            "statement_type": "SELECT",
            "order_by": [
                {"column": "created_at", "direction": "DESC"}
            ],
            "errors": [],
            "warnings": [],
        })
    
    def test_group_order_combined(self) -> None:
        """测试 GROUP BY + ORDER BY 组合。"""
        sql = """
        SELECT department, COUNT(*) as cnt
        FROM employees
        GROUP BY department
        ORDER BY cnt DESC
        """
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "mysql",
            "statement_type": "SELECT",
            "group_by": ["department"],
            "order_by": [
                {"column": "cnt", "direction": "DESC"}
            ],
            "errors": [],
            "warnings": [],
        })


class TestMySQLFunctions:
    """MySQL 特有函数测试。"""
    
    def setup_method(self) -> None:
        self.parser = SQLParser(dialect="mysql")
    
    def test_ifnull_function(self) -> None:
        """测试 IFNULL 函数。"""
        sql = "SELECT IFNULL(name, 'unknown') FROM users"
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "mysql",
            "statement_type": "SELECT",
            "errors": [],
            "warnings": [],
        })
    
    def test_group_concat(self) -> None:
        """测试 GROUP_CONCAT 函数。"""
        sql = "SELECT GROUP_CONCAT(name) FROM users GROUP BY department"
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "mysql",
            "statement_type": "SELECT",
            "group_by": ["department"],
            "errors": [],
            "warnings": [],
        })


class TestMySQLDDL:
    """MySQL DDL 语句测试。"""
    
    def setup_method(self) -> None:
        self.parser = SQLParser(dialect="mysql")
    
    def test_create_table(self) -> None:
        """测试 CREATE TABLE。"""
        sql = """
        CREATE TABLE users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
            email VARCHAR(255) UNIQUE
        )
        """
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "mysql",
            "statement_type": "CREATE",
            "errors": [],
            "warnings": [],
        })
    
    def test_insert(self) -> None:
        """测试 INSERT 语句。"""
        sql = "INSERT INTO users (name, email) VALUES ('John', 'john@example.com')"
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "mysql",
            "statement_type": "INSERT",
            "tables": [
                {"name": "users", "schema_name": None, "alias": None, "type": "table"}
            ],
            "errors": [],
            "warnings": [],
        })
    
    def test_update(self) -> None:
        """测试 UPDATE 语句。"""
        sql = "UPDATE users SET name = 'Jane' WHERE id = 1"
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "mysql",
            "statement_type": "UPDATE",
            "tables": [
                {"name": "users", "schema_name": None, "alias": None, "type": "table"}
            ],
            "conditions_count": 1,
            "errors": [],
            "warnings": [],
        })
    
    def test_delete(self) -> None:
        """测试 DELETE 语句。"""
        sql = "DELETE FROM users WHERE id = 1"
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "mysql",
            "statement_type": "DELETE",
            "tables": [
                {"name": "users", "schema_name": None, "alias": None, "type": "table"}
            ],
            "conditions_count": 1,
            "errors": [],
            "warnings": [],
        })
