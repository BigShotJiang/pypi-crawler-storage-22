"""OceanBase 方言单元测试。

使用 SQL 脚本作为入参，完整验证所有解析后的参数。
"""
import pytest
from sql_parser import SQLParser
from tests.conftest import verify_parse_result
from tests.sql_scripts.oceanbase_scripts import (
    OCEANBASE_MYSQL_TEST_CASES,
    OCEANBASE_ORACLE_TEST_CASES,
    OCEANBASE_MODE_SWITCH_TEST_CASES,
)


class TestOceanBaseMySQLFromScripts:
    """OceanBase MySQL 模式 SQL 脚本测试。"""
    
    @pytest.fixture(autouse=True)
    def setup(self, oceanbase_mysql_parser: SQLParser) -> None:
        """初始化 OceanBase MySQL 模式解析器。"""
        self.parser = oceanbase_mysql_parser
    
    @pytest.mark.parametrize(
        "test_case",
        OCEANBASE_MYSQL_TEST_CASES,
        ids=[tc["name"] for tc in OCEANBASE_MYSQL_TEST_CASES]
    )
    def test_oceanbase_mysql_sql_scripts(self, test_case: dict) -> None:
        """测试 OceanBase MySQL 模式 SQL 脚本解析。
        
        Args:
            test_case: 测试用例，包含 sql 和 expected 字段
        """
        # 解析 SQL
        result = self.parser.parse(test_case["sql"])
        
        # 验证所有期望的字段
        verify_parse_result(result, test_case["expected"])


class TestOceanBaseOracleFromScripts:
    """OceanBase Oracle 模式 SQL 脚本测试。"""
    
    @pytest.fixture(autouse=True)
    def setup(self, oceanbase_oracle_parser: SQLParser) -> None:
        """初始化 OceanBase Oracle 模式解析器。"""
        self.parser = oceanbase_oracle_parser
    
    @pytest.mark.parametrize(
        "test_case",
        OCEANBASE_ORACLE_TEST_CASES,
        ids=[tc["name"] for tc in OCEANBASE_ORACLE_TEST_CASES]
    )
    def test_oceanbase_oracle_sql_scripts(self, test_case: dict) -> None:
        """测试 OceanBase Oracle 模式 SQL 脚本解析。
        
        Args:
            test_case: 测试用例，包含 sql 和 expected 字段
        """
        # 解析 SQL
        result = self.parser.parse(test_case["sql"])
        
        # 验证所有期望的字段
        verify_parse_result(result, test_case["expected"])


class TestOceanBaseMySQLMode:
    """OceanBase MySQL 模式测试。"""
    
    def setup_method(self) -> None:
        """初始化 OceanBase MySQL 模式解析器。"""
        self.parser = SQLParser(dialect="oceanbase-mysql")
    
    def test_simple_select(self) -> None:
        """测试简单 SELECT 语句。"""
        sql = "SELECT id, name FROM users"
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "oceanbase-mysql",
            "statement_type": "SELECT",
            "oceanbase_info": {
                "mode": "mysql",
            },
            "errors": [],
            "warnings": [],
        })
    
    def test_backtick_identifier(self) -> None:
        """测试反引号标识符（MySQL 兼容）。"""
        sql = "SELECT `id`, `user_name` FROM `user_table`"
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "oceanbase-mysql",
            "statement_type": "SELECT",
            "tables": [
                {"name": "user_table", "schema_name": None, "alias": None, "type": "table"}
            ],
            "errors": [],
            "warnings": [],
        })
    
    def test_limit_clause(self) -> None:
        """测试 LIMIT 子句（MySQL 兼容）。"""
        sql = "SELECT * FROM users LIMIT 10"
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "oceanbase-mysql",
            "statement_type": "SELECT",
            "limit": 10,
            "errors": [],
            "warnings": [],
        })
    
    def test_join(self) -> None:
        """测试 JOIN（MySQL 兼容）。"""
        sql = "SELECT * FROM users u LEFT JOIN orders o ON u.id = o.user_id"
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "oceanbase-mysql",
            "statement_type": "SELECT",
            "joins_count": 1,
            "errors": [],
            "warnings": [],
        })
    
    def test_mysql_functions(self) -> None:
        """测试 MySQL 函数。"""
        sql = "SELECT IFNULL(name, 'unknown'), GROUP_CONCAT(tag) FROM users GROUP BY id"
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "oceanbase-mysql",
            "statement_type": "SELECT",
            "group_by": ["id"],
            "errors": [],
            "warnings": [],
        })


class TestOceanBaseOracleMode:
    """OceanBase Oracle 模式测试。"""
    
    def setup_method(self) -> None:
        """初始化 OceanBase Oracle 模式解析器。"""
        self.parser = SQLParser(dialect="oceanbase-oracle")
    
    def test_simple_select(self) -> None:
        """测试简单 SELECT 语句。"""
        sql = "SELECT id, name FROM users"
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "oceanbase-oracle",
            "statement_type": "SELECT",
            "oceanbase_info": {
                "mode": "oracle",
            },
            "errors": [],
            "warnings": [],
        })
    
    def test_double_quote_identifier(self) -> None:
        """测试双引号标识符（Oracle 兼容）。"""
        sql = 'SELECT "id", "user_name" FROM "user_table"'
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "oceanbase-oracle",
            "statement_type": "SELECT",
            "tables": [
                {"name": "user_table", "schema_name": None, "alias": None, "type": "table"}
            ],
            "errors": [],
            "warnings": [],
        })
    
    def test_rownum(self) -> None:
        """测试 ROWNUM（Oracle 兼容）。"""
        sql = "SELECT * FROM users WHERE ROWNUM <= 10"
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "oceanbase-oracle",
            "statement_type": "SELECT",
            "oracle_info": {
                "pseudo_columns": ["ROWNUM"],
            },
            "errors": [],
            "warnings": [],
        })
    
    def test_oracle_functions(self) -> None:
        """测试 Oracle 函数。"""
        sql = "SELECT NVL(name, 'unknown'), DECODE(status, 'A', 'Active', 'Unknown') FROM users"
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "oceanbase-oracle",
            "statement_type": "SELECT",
            "errors": [],
            "warnings": [],
        })


class TestOceanBaseHints:
    """OceanBase Hint 解析测试。"""
    
    def setup_method(self) -> None:
        self.mysql_parser = SQLParser(dialect="oceanbase-mysql")
        self.oracle_parser = SQLParser(dialect="oceanbase-oracle")
    
    def test_parallel_hint_mysql(self) -> None:
        """测试 PARALLEL Hint（MySQL 模式）。"""
        sql = "SELECT /*+ PARALLEL(4) */ * FROM large_table"
        result = self.mysql_parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "oceanbase-mysql",
            "statement_type": "SELECT",
            "oceanbase_info": {
                "mode": "mysql",
                "hints": [
                    {"name": "PARALLEL", "type": "parallel_hint", "args": "4"}
                ],
            },
            "errors": [],
            "warnings": [],
        })
    
    def test_parallel_hint_oracle(self) -> None:
        """测试 PARALLEL Hint（Oracle 模式）。"""
        sql = "SELECT /*+ PARALLEL(4) */ * FROM large_table"
        result = self.oracle_parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "oceanbase-oracle",
            "statement_type": "SELECT",
            "oceanbase_info": {
                "mode": "oracle",
                "hints": [
                    {"name": "PARALLEL", "type": "parallel_hint", "args": "4"}
                ],
            },
            "errors": [],
            "warnings": [],
        })
    
    def test_index_hint(self) -> None:
        """测试 INDEX Hint。"""
        sql = "SELECT /*+ INDEX(t idx_name) */ * FROM t WHERE id = 1"
        result = self.mysql_parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "oceanbase-mysql",
            "statement_type": "SELECT",
            "oceanbase_info": {
                "hints": [
                    {"name": "INDEX", "type": "index_hint", "args": "t idx_name"}
                ],
            },
            "errors": [],
            "warnings": [],
        })
    
    def test_use_hash_hint(self) -> None:
        """测试 USE_HASH Hint。"""
        sql = "SELECT /*+ USE_HASH(t1, t2) */ * FROM t1 JOIN t2 ON t1.id = t2.id"
        result = self.mysql_parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "oceanbase-mysql",
            "statement_type": "SELECT",
            "oceanbase_info": {
                "hints": [
                    {"name": "USE_HASH", "type": "join_hint", "args": "t1, t2"}
                ],
            },
            "errors": [],
            "warnings": [],
        })
    
    def test_leading_hint(self) -> None:
        """测试 LEADING Hint。"""
        sql = "SELECT /*+ LEADING(t1 t2 t3) */ * FROM t1, t2, t3 WHERE t1.id = t2.id AND t2.id = t3.id"
        result = self.mysql_parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "oceanbase-mysql",
            "statement_type": "SELECT",
            "oceanbase_info": {
                "hints": [
                    {"name": "LEADING", "type": "join_order_hint", "args": "t1 t2 t3"}
                ],
            },
            "errors": [],
            "warnings": [],
        })
    
    def test_multiple_hints(self) -> None:
        """测试多个 Hint。"""
        sql = "SELECT /*+ PARALLEL(4) */ /*+ INDEX(t idx1) */ * FROM t"
        result = self.mysql_parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "oceanbase-mysql",
            "statement_type": "SELECT",
            "oceanbase_info": {
                "hints_count": 2,
            },
            "errors": [],
            "warnings": [],
        })


class TestOceanBaseDDL:
    """OceanBase DDL 语句测试。"""
    
    def setup_method(self) -> None:
        self.mysql_parser = SQLParser(dialect="oceanbase-mysql")
        self.oracle_parser = SQLParser(dialect="oceanbase-oracle")
    
    def test_create_table_mysql(self) -> None:
        """测试 CREATE TABLE（MySQL 模式）。"""
        sql = """
        CREATE TABLE users (
            id BIGINT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100) NOT NULL
        )
        """
        result = self.mysql_parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "oceanbase-mysql",
            "statement_type": "CREATE",
            "errors": [],
            "warnings": [],
        })
    
    def test_create_table_oracle(self) -> None:
        """测试 CREATE TABLE（Oracle 模式）。"""
        sql = """
        CREATE TABLE users (
            id NUMBER PRIMARY KEY,
            name VARCHAR2(100) NOT NULL
        )
        """
        result = self.oracle_parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "oceanbase-oracle",
            "statement_type": "CREATE",
            "errors": [],
            "warnings": [],
        })
    
    def test_insert_mysql(self) -> None:
        """测试 INSERT（MySQL 模式）。"""
        sql = "INSERT INTO users (name) VALUES ('John')"
        result = self.mysql_parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "oceanbase-mysql",
            "statement_type": "INSERT",
            "errors": [],
            "warnings": [],
        })
    
    def test_insert_oracle(self) -> None:
        """测试 INSERT（Oracle 模式）。"""
        sql = "INSERT INTO users (name) VALUES ('John')"
        result = self.oracle_parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "oceanbase-oracle",
            "statement_type": "INSERT",
            "errors": [],
            "warnings": [],
        })


class TestOceanBaseComplexQueries:
    """OceanBase 复杂查询测试。"""
    
    def setup_method(self) -> None:
        self.mysql_parser = SQLParser(dialect="oceanbase-mysql")
        self.oracle_parser = SQLParser(dialect="oceanbase-oracle")
    
    def test_subquery_mysql(self) -> None:
        """测试子查询（MySQL 模式）。"""
        sql = """
        SELECT * FROM users
        WHERE department_id IN (
            SELECT id FROM departments WHERE status = 'active'
        )
        """
        result = self.mysql_parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "oceanbase-mysql",
            "statement_type": "SELECT",
            "errors": [],
            "warnings": [],
        })
    
    def test_subquery_oracle(self) -> None:
        """测试子查询（Oracle 模式）。"""
        sql = """
        SELECT * FROM users
        WHERE department_id IN (
            SELECT id FROM departments WHERE status = 'active'
        )
        """
        result = self.oracle_parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "oceanbase-oracle",
            "statement_type": "SELECT",
            "errors": [],
            "warnings": [],
        })
    
    def test_cte_mysql(self) -> None:
        """测试 CTE（MySQL 模式）。"""
        sql = """
        WITH active_users AS (
            SELECT * FROM users WHERE status = 'active'
        )
        SELECT * FROM active_users
        """
        result = self.mysql_parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "oceanbase-mysql",
            "statement_type": "SELECT",
            "errors": [],
            "warnings": [],
        })
    
    def test_cte_oracle(self) -> None:
        """测试 CTE（Oracle 模式）。"""
        sql = """
        WITH active_users AS (
            SELECT * FROM users WHERE status = 'active'
        )
        SELECT * FROM active_users
        """
        result = self.oracle_parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "oceanbase-oracle",
            "statement_type": "SELECT",
            "errors": [],
            "warnings": [],
        })
    
    def test_window_function_mysql(self) -> None:
        """测试窗口函数（MySQL 模式）。"""
        sql = """
        SELECT 
            name,
            salary,
            ROW_NUMBER() OVER (PARTITION BY department ORDER BY salary DESC) as rank
        FROM employees
        """
        result = self.mysql_parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "oceanbase-mysql",
            "statement_type": "SELECT",
            "errors": [],
            "warnings": [],
        })
    
    def test_window_function_oracle(self) -> None:
        """测试窗口函数（Oracle 模式）。"""
        sql = """
        SELECT 
            name,
            salary,
            ROW_NUMBER() OVER (PARTITION BY department ORDER BY salary DESC) as rank
        FROM employees
        """
        result = self.oracle_parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "oceanbase-oracle",
            "statement_type": "SELECT",
            "errors": [],
            "warnings": [],
        })


class TestOceanBaseModeSwitch:
    """OceanBase 双模式切换测试。"""
    
    def test_mode_info_mysql(self) -> None:
        """测试 MySQL 模式信息。"""
        parser = SQLParser(dialect="oceanbase-mysql")
        result = parser.parse("SELECT * FROM users")
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "oceanbase-mysql",
            "oceanbase_info": {
                "mode": "mysql",
            },
            "errors": [],
            "warnings": [],
        })
    
    def test_mode_info_oracle(self) -> None:
        """测试 Oracle 模式信息。"""
        parser = SQLParser(dialect="oceanbase-oracle")
        result = parser.parse("SELECT * FROM users")
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "oceanbase-oracle",
            "oceanbase_info": {
                "mode": "oracle",
            },
            "errors": [],
            "warnings": [],
        })
    
    def test_same_sql_different_modes(self) -> None:
        """测试同一 SQL 在不同模式下的解析。"""
        sql = "SELECT id, name FROM users WHERE status = 'active'"
        
        mysql_parser = SQLParser(dialect="oceanbase-mysql")
        oracle_parser = SQLParser(dialect="oceanbase-oracle")
        
        mysql_result = mysql_parser.parse(sql)
        oracle_result = oracle_parser.parse(sql)
        
        verify_parse_result(mysql_result, {
            "success": True,
            "dialect": "oceanbase-mysql",
            "oceanbase_info": {
                "mode": "mysql",
            },
            "errors": [],
            "warnings": [],
        })
        
        verify_parse_result(oracle_result, {
            "success": True,
            "dialect": "oceanbase-oracle",
            "oceanbase_info": {
                "mode": "oracle",
            },
            "errors": [],
            "warnings": [],
        })
