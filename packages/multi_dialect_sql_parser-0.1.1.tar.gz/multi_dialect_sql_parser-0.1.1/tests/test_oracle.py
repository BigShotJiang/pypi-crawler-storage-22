"""Oracle 方言单元测试。

使用 SQL 脚本作为入参，完整验证所有解析后的参数。
"""
import pytest
from sql_parser import SQLParser
from tests.conftest import verify_parse_result
from tests.sql_scripts.oracle_scripts import ORACLE_TEST_CASES


class TestOracleFromScripts:
    """Oracle SQL 脚本测试。"""
    
    @pytest.fixture(autouse=True)
    def setup(self, oracle_parser: SQLParser) -> None:
        """初始化 Oracle 解析器。"""
        self.parser = oracle_parser
    
    @pytest.mark.parametrize(
        "test_case",
        ORACLE_TEST_CASES,
        ids=[tc["name"] for tc in ORACLE_TEST_CASES]
    )
    def test_oracle_sql_scripts(self, test_case: dict) -> None:
        """测试 Oracle SQL 脚本解析。
        
        Args:
            test_case: 测试用例，包含 sql 和 expected 字段
        """
        # 解析 SQL
        result = self.parser.parse(test_case["sql"])
        
        # 验证所有期望的字段
        verify_parse_result(result, test_case["expected"])


class TestOracleBasic:
    """Oracle 基础语法测试。"""
    
    def setup_method(self) -> None:
        """初始化 Oracle 解析器。"""
        self.parser = SQLParser(dialect="oracle")
    
    def test_simple_select(self) -> None:
        """测试简单 SELECT 语句。"""
        sql = "SELECT id, name FROM users"
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "oracle",
            "statement_type": "SELECT",
            "tables": [
                {"name": "users", "schema_name": None, "alias": None, "type": "table"}
            ],
            "errors": [],
            "warnings": [],
        })
    
    def test_double_quote_identifier(self) -> None:
        """测试双引号标识符解析。"""
        sql = 'SELECT "id", "user_name" FROM "user_table"'
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "oracle",
            "statement_type": "SELECT",
            "tables": [
                {"name": "user_table", "schema_name": None, "alias": None, "type": "table"}
            ],
            "errors": [],
            "warnings": [],
        })
    
    def test_dual_table(self) -> None:
        """测试 DUAL 表。"""
        sql = "SELECT SYSDATE FROM DUAL"
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "oracle",
            "statement_type": "SELECT",
            "tables_has_dual": True,
            "errors": [],
            "warnings": [],
        })
    
    def test_schema_qualified_table(self) -> None:
        """测试带 schema 的表名。"""
        sql = "SELECT * FROM hr.employees"
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "oracle",
            "statement_type": "SELECT",
            "tables": [
                {"name": "employees", "schema_name": "hr", "alias": None, "type": "table"}
            ],
            "errors": [],
            "warnings": [],
        })


class TestOracleRownum:
    """Oracle ROWNUM 伪列测试。"""
    
    def setup_method(self) -> None:
        self.parser = SQLParser(dialect="oracle")
    
    def test_rownum_in_where(self) -> None:
        """测试 WHERE 中的 ROWNUM。"""
        sql = "SELECT * FROM users WHERE ROWNUM <= 10"
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "oracle",
            "statement_type": "SELECT",
            "oracle_info": {
                "pseudo_columns": ["ROWNUM"],
            },
            "errors": [],
            "warnings": [],
        })
    
    def test_rownum_in_select(self) -> None:
        """测试 SELECT 中的 ROWNUM。"""
        sql = "SELECT ROWNUM, id, name FROM users"
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "oracle",
            "statement_type": "SELECT",
            "oracle_info": {
                "pseudo_columns": ["ROWNUM"],
            },
            "errors": [],
            "warnings": [],
        })


class TestOracleFunctions:
    """Oracle 特有函数测试。"""
    
    def setup_method(self) -> None:
        self.parser = SQLParser(dialect="oracle")
    
    def test_nvl_function(self) -> None:
        """测试 NVL 函数。"""
        sql = "SELECT NVL(name, 'unknown') FROM users"
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "oracle",
            "statement_type": "SELECT",
            "errors": [],
            "warnings": [],
        })
    
    def test_nvl2_function(self) -> None:
        """测试 NVL2 函数。"""
        sql = "SELECT NVL2(commission, salary + commission, salary) FROM employees"
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "oracle",
            "statement_type": "SELECT",
            "errors": [],
            "warnings": [],
        })
    
    def test_decode_function(self) -> None:
        """测试 DECODE 函数。"""
        sql = "SELECT DECODE(status, 'A', 'Active', 'I', 'Inactive', 'Unknown') FROM users"
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "oracle",
            "statement_type": "SELECT",
            "errors": [],
            "warnings": [],
        })
    
    def test_to_date_function(self) -> None:
        """测试 TO_DATE 函数。"""
        sql = "SELECT * FROM orders WHERE order_date > TO_DATE('2024-01-01', 'YYYY-MM-DD')"
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "oracle",
            "statement_type": "SELECT",
            "conditions_count": 1,
            "errors": [],
            "warnings": [],
        })
    
    def test_to_char_function(self) -> None:
        """测试 TO_CHAR 函数。"""
        sql = "SELECT TO_CHAR(hire_date, 'YYYY-MM-DD') FROM employees"
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "oracle",
            "statement_type": "SELECT",
            "errors": [],
            "warnings": [],
        })


class TestOracleJoin:
    """Oracle JOIN 语法测试。"""
    
    def setup_method(self) -> None:
        self.parser = SQLParser(dialect="oracle")
    
    def test_inner_join(self) -> None:
        """测试 INNER JOIN。"""
        sql = "SELECT * FROM employees e INNER JOIN departments d ON e.dept_id = d.id"
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "oracle",
            "statement_type": "SELECT",
            "joins": [
                {
                    "type": "INNER",
                    "table": {"name": "departments", "schema_name": None, "alias": "d", "type": "table"},
                    "condition": "e.dept_id = d.id",
                }
            ],
            "errors": [],
            "warnings": [],
        })
    
    def test_left_outer_join(self) -> None:
        """测试 LEFT OUTER JOIN。"""
        sql = "SELECT * FROM employees e LEFT OUTER JOIN departments d ON e.dept_id = d.id"
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "oracle",
            "statement_type": "SELECT",
            "joins": [
                {
                    "type": "LEFT",
                    "table": {"name": "departments", "schema_name": None, "alias": "d", "type": "table"},
                    "condition": "e.dept_id = d.id",
                }
            ],
            "errors": [],
            "warnings": [],
        })


class TestOracleAnalyticFunctions:
    """Oracle 分析函数测试。"""
    
    def setup_method(self) -> None:
        self.parser = SQLParser(dialect="oracle")
    
    def test_row_number(self) -> None:
        """测试 ROW_NUMBER 分析函数。"""
        sql = """
        SELECT 
            employee_id,
            salary,
            ROW_NUMBER() OVER (PARTITION BY department_id ORDER BY salary DESC) as rank
        FROM employees
        """
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "oracle",
            "statement_type": "SELECT",
            "errors": [],
            "warnings": [],
        })
    
    def test_rank_function(self) -> None:
        """测试 RANK 分析函数。"""
        sql = """
        SELECT 
            employee_id,
            salary,
            RANK() OVER (ORDER BY salary DESC) as salary_rank
        FROM employees
        """
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "oracle",
            "statement_type": "SELECT",
            "errors": [],
            "warnings": [],
        })
    
    def test_lag_lead(self) -> None:
        """测试 LAG/LEAD 分析函数。"""
        sql = """
        SELECT 
            employee_id,
            salary,
            LAG(salary, 1) OVER (ORDER BY hire_date) as prev_salary,
            LEAD(salary, 1) OVER (ORDER BY hire_date) as next_salary
        FROM employees
        """
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "oracle",
            "statement_type": "SELECT",
            "errors": [],
            "warnings": [],
        })


class TestOracleDDL:
    """Oracle DDL 语句测试。"""
    
    def setup_method(self) -> None:
        self.parser = SQLParser(dialect="oracle")
    
    def test_create_table(self) -> None:
        """测试 CREATE TABLE。"""
        sql = """
        CREATE TABLE employees (
            id NUMBER PRIMARY KEY,
            name VARCHAR2(100) NOT NULL,
            hire_date DATE DEFAULT SYSDATE
        )
        """
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "oracle",
            "statement_type": "CREATE",
            "errors": [],
            "warnings": [],
        })
    
    def test_insert(self) -> None:
        """测试 INSERT 语句。"""
        sql = "INSERT INTO employees (id, name) VALUES (1, 'John')"
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "oracle",
            "statement_type": "INSERT",
            "errors": [],
            "warnings": [],
        })
    
    def test_update(self) -> None:
        """测试 UPDATE 语句。"""
        sql = "UPDATE employees SET salary = salary * 1.1 WHERE department_id = 10"
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "oracle",
            "statement_type": "UPDATE",
            "conditions_count": 1,
            "errors": [],
            "warnings": [],
        })
    
    def test_delete(self) -> None:
        """测试 DELETE 语句。"""
        sql = "DELETE FROM employees WHERE id = 1"
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "oracle",
            "statement_type": "DELETE",
            "errors": [],
        })


class TestOracleMerge:
    """Oracle MERGE 语句测试。"""
    
    def setup_method(self) -> None:
        self.parser = SQLParser(dialect="oracle")
    
    def test_merge_basic(self) -> None:
        """测试基本 MERGE 语句。"""
        sql = """
        MERGE INTO target_table t
        USING source_table s
        ON (t.id = s.id)
        WHEN MATCHED THEN
            UPDATE SET t.name = s.name
        WHEN NOT MATCHED THEN
            INSERT (id, name) VALUES (s.id, s.name)
        """
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "oracle",
            "statement_type": "MERGE",
            "errors": [],
            "warnings": [],
        })


class TestOracleComplexQueries:
    """Oracle 复杂查询测试。"""
    
    def setup_method(self) -> None:
        self.parser = SQLParser(dialect="oracle")
    
    def test_subquery(self) -> None:
        """测试子查询。"""
        sql = """
        SELECT * FROM employees
        WHERE department_id IN (
            SELECT id FROM departments WHERE location = 'New York'
        )
        """
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "oracle",
            "statement_type": "SELECT",
            "errors": [],
            "warnings": [],
        })
    
    def test_cte(self) -> None:
        """测试 CTE (WITH 子句)。"""
        sql = """
        WITH dept_salaries AS (
            SELECT department_id, AVG(salary) as avg_salary
            FROM employees
            GROUP BY department_id
        )
        SELECT e.*, d.avg_salary
        FROM employees e
        JOIN dept_salaries d ON e.department_id = d.department_id
        """
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "oracle",
            "statement_type": "SELECT",
            "errors": [],
            "warnings": [],
        })
    
    def test_union(self) -> None:
        """测试 UNION。"""
        sql = """
        SELECT id, name FROM employees WHERE status = 'ACTIVE'
        UNION
        SELECT id, name FROM contractors WHERE status = 'ACTIVE'
        """
        result = self.parser.parse(sql)
        
        # UNION 语句在 SQLGlot 中被解析为 OTHER 类型
        verify_parse_result(result, {
            "success": True,
            "dialect": "oracle",
            "errors": [],
        })
