"""性能基准测试。"""
import time
import pytest
from sql_parser import SQLParser


class TestPerformance:
    """性能基准测试。"""
    
    def setup_method(self):
        """初始化解析器。"""
        self.parser = SQLParser(dialect="mysql")
    
    def test_single_parse_speed(self):
        """测试单条 SQL 解析速度。"""
        sql = """
        SELECT u.id, u.name, o.order_id, o.total
        FROM users u
        LEFT JOIN orders o ON u.id = o.user_id
        WHERE u.status = 'active' AND o.total > 100
        ORDER BY o.created_at DESC
        LIMIT 10
        """
        
        # 预热
        self.parser.parse(sql)
        
        # 计时
        iterations = 100
        start = time.perf_counter()
        for _ in range(iterations):
            self.parser.parse(sql)
        elapsed = time.perf_counter() - start
        
        avg_time = elapsed / iterations * 1000  # 毫秒
        qps = iterations / elapsed
        
        print(f"\n单条解析: 平均 {avg_time:.3f}ms, QPS: {qps:.0f}")
        
        # 断言：单条解析应该在 10ms 以内
        assert avg_time < 10, f"单条解析太慢: {avg_time:.3f}ms"
    
    def test_batch_parse_speed(self):
        """测试批量解析速度。"""
        # 生成 500 条不同的 SQL
        sqls = []
        for i in range(500):
            sqls.append(f"SELECT * FROM table_{i} WHERE id = {i}")
        
        # 预热
        list(self.parser.parse_batch(sqls[:10]))
        
        # 计时
        start = time.perf_counter()
        results = list(self.parser.parse_batch(sqls))
        elapsed = time.perf_counter() - start
        
        qps = len(sqls) / elapsed
        
        print(f"\n批量解析 {len(sqls)} 条: {elapsed:.3f}s, QPS: {qps:.0f}")
        
        assert len(results) == 500
        # 断言：500 条应该在 5 秒内完成
        assert elapsed < 5, f"批量解析太慢: {elapsed:.3f}s"
    
    def test_complex_sql_parse_speed(self):
        """测试复杂 SQL 解析速度。"""
        sql = """
        WITH active_users AS (
            SELECT id, name, department_id
            FROM users
            WHERE status = 'active' AND created_at > '2024-01-01'
        ),
        dept_stats AS (
            SELECT department_id, COUNT(*) as user_count
            FROM active_users
            GROUP BY department_id
        )
        SELECT 
            d.name as department_name,
            ds.user_count,
            AVG(u.salary) as avg_salary,
            MAX(u.salary) as max_salary
        FROM departments d
        INNER JOIN dept_stats ds ON d.id = ds.department_id
        LEFT JOIN active_users au ON d.id = au.department_id
        LEFT JOIN users u ON au.id = u.id
        WHERE ds.user_count > 5
        GROUP BY d.name, ds.user_count
        HAVING AVG(u.salary) > 50000
        ORDER BY ds.user_count DESC, avg_salary DESC
        LIMIT 20 OFFSET 0
        """
        
        # 预热
        self.parser.parse(sql)
        
        # 计时
        iterations = 50
        start = time.perf_counter()
        for _ in range(iterations):
            self.parser.parse(sql)
        elapsed = time.perf_counter() - start
        
        avg_time = elapsed / iterations * 1000
        
        print(f"\n复杂 SQL 解析: 平均 {avg_time:.3f}ms")
        
        # 断言：复杂 SQL 应该在 50ms 以内
        assert avg_time < 50, f"复杂 SQL 解析太慢: {avg_time:.3f}ms"
    
    def test_throughput_1000(self):
        """测试 1000 条 SQL 吞吐量。"""
        sqls = [f"SELECT id, name FROM users WHERE id = {i}" for i in range(1000)]
        
        start = time.perf_counter()
        results = list(self.parser.parse_batch(sqls))
        elapsed = time.perf_counter() - start
        
        qps = len(sqls) / elapsed
        
        print(f"\n1000 条吞吐量: {elapsed:.3f}s, QPS: {qps:.0f}")
        
        assert len(results) == 1000
        # 断言：1000 条应该在 10 秒内完成
        assert elapsed < 10, f"吞吐量测试太慢: {elapsed:.3f}s"


class TestParserInitialization:
    """解析器初始化测试。"""
    
    def test_invalid_dialect(self):
        """测试无效方言。"""
        with pytest.raises(ValueError) as exc_info:
            SQLParser(dialect="invalid_dialect")
        
        assert "不支持的方言" in str(exc_info.value)
    
    def test_custom_workers(self):
        """测试自定义进程数。"""
        parser = SQLParser(dialect="mysql", max_workers=2)
        assert parser.max_workers == 2
    
    def test_custom_batch_size(self):
        """测试自定义批量大小。"""
        parser = SQLParser(dialect="mysql", batch_size=500)
        assert parser.batch_size == 500
