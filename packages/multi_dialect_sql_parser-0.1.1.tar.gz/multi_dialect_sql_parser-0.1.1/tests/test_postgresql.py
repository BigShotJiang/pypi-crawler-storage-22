"""PostgreSQL 方言单元测试。

使用 SQL 脚本作为入参，完整验证所有解析后的参数。
"""
import pytest
from sql_parser import SQLParser
from tests.conftest import verify_parse_result
from tests.sql_scripts.postgresql_scripts import POSTGRESQL_TEST_CASES


class TestPostgreSQLFromScripts:
    """PostgreSQL SQL 脚本测试。"""
    
    @pytest.fixture(autouse=True)
    def setup(self, postgresql_parser: SQLParser) -> None:
        """初始化 PostgreSQL 解析器。"""
        self.parser = postgresql_parser
    
    @pytest.mark.parametrize(
        "test_case",
        POSTGRESQL_TEST_CASES,
        ids=[tc["name"] for tc in POSTGRESQL_TEST_CASES]
    )
    def test_postgresql_sql_scripts(self, test_case: dict) -> None:
        """测试 PostgreSQL SQL 脚本解析。
        
        Args:
            test_case: 测试用例，包含 sql 和 expected 字段
        """
        # 解析 SQL
        result = self.parser.parse(test_case["sql"])
        
        # 验证所有期望的字段
        verify_parse_result(result, test_case["expected"])


class TestPostgreSQLBasic:
    """PostgreSQL 基础语法测试。"""
    
    def setup_method(self) -> None:
        """初始化 PostgreSQL 解析器。"""
        self.parser = SQLParser(dialect="postgresql")
    
    def test_simple_select(self) -> None:
        """测试简单 SELECT 语句。"""
        sql = "SELECT id, name FROM users"
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "postgresql",
            "statement_type": "SELECT",
            "tables": [
                {"name": "users", "schema_name": None, "alias": None, "type": "table"}
            ],
            "errors": [],
            "warnings": [],
        })
    
    def test_double_quote_identifier(self) -> None:
        """测试双引号标识符解析。"""
        sql = 'SELECT "id", "user_name" FROM "user_table"'
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "postgresql",
            "statement_type": "SELECT",
            "tables": [
                {"name": "user_table", "schema_name": None, "alias": None, "type": "table"}
            ],
            "errors": [],
            "warnings": [],
        })
    
    def test_schema_qualified_table(self) -> None:
        """测试带 schema 的表名。"""
        sql = "SELECT * FROM public.users"
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "postgresql",
            "statement_type": "SELECT",
            "tables": [
                {"name": "users", "schema_name": "public", "alias": None, "type": "table"}
            ],
            "errors": [],
            "warnings": [],
        })


class TestPostgreSQLTypeCast:
    """PostgreSQL 类型转换测试。"""
    
    def setup_method(self) -> None:
        self.parser = SQLParser(dialect="postgresql")
    
    def test_double_colon_cast(self) -> None:
        """测试 :: 类型转换。"""
        sql = "SELECT '123'::integer FROM dual"
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "postgresql",
            "statement_type": "SELECT",
            "errors": [],
            "warnings": [],
        })
    
    def test_cast_in_where(self) -> None:
        """测试 WHERE 中的类型转换。"""
        sql = "SELECT * FROM users WHERE created_at::date = '2024-01-01'"
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "postgresql",
            "statement_type": "SELECT",
            "conditions_count": 1,
            "errors": [],
            "warnings": [],
        })


class TestPostgreSQLArray:
    """PostgreSQL 数组操作测试。"""
    
    def setup_method(self) -> None:
        self.parser = SQLParser(dialect="postgresql")
    
    def test_array_literal(self) -> None:
        """测试数组字面量。"""
        sql = "SELECT ARRAY[1, 2, 3]"
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "postgresql",
            "statement_type": "SELECT",
            "errors": [],
            "warnings": [],
        })
    
    def test_any_operator(self) -> None:
        """测试 ANY 操作符。"""
        sql = "SELECT * FROM users WHERE id = ANY(ARRAY[1, 2, 3])"
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "postgresql",
            "statement_type": "SELECT",
            "errors": [],
            "warnings": [],
        })


class TestPostgreSQLSpecific:
    """PostgreSQL 特有语法测试。"""
    
    def setup_method(self) -> None:
        self.parser = SQLParser(dialect="postgresql")
    
    def test_returning_clause(self) -> None:
        """测试 RETURNING 子句。"""
        sql = "INSERT INTO users (name) VALUES ('John') RETURNING id"
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "postgresql",
            "statement_type": "INSERT",
            "tables": [
                {"name": "users", "schema_name": None, "alias": None, "type": "table"}
            ],
            "errors": [],
            "warnings": [],
        })
    
    def test_cte(self) -> None:
        """测试 CTE (WITH 子句)。"""
        sql = """
        WITH active_users AS (
            SELECT * FROM users WHERE status = 'active'
        )
        SELECT * FROM active_users
        """
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "postgresql",
            "statement_type": "SELECT",
            "errors": [],
            "warnings": [],
        })
    
    def test_window_function(self) -> None:
        """测试窗口函数。"""
        sql = """
        SELECT 
            name,
            salary,
            ROW_NUMBER() OVER (PARTITION BY department ORDER BY salary DESC) as rank
        FROM employees
        """
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "postgresql",
            "statement_type": "SELECT",
            "tables": [
                {"name": "employees", "schema_name": None, "alias": None, "type": "table"}
            ],
            "errors": [],
            "warnings": [],
        })
    
    def test_coalesce(self) -> None:
        """测试 COALESCE 函数。"""
        sql = "SELECT COALESCE(name, 'unknown') FROM users"
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "postgresql",
            "statement_type": "SELECT",
            "errors": [],
            "warnings": [],
        })


class TestPostgreSQLDDL:
    """PostgreSQL DDL 语句测试。"""
    
    def setup_method(self) -> None:
        self.parser = SQLParser(dialect="postgresql")
    
    def test_create_table_serial(self) -> None:
        """测试 SERIAL 类型。"""
        sql = """
        CREATE TABLE users (
            id SERIAL PRIMARY KEY,
            name VARCHAR(100) NOT NULL
        )
        """
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "postgresql",
            "statement_type": "CREATE",
            "errors": [],
            "warnings": [],
        })
    
    def test_create_table_bigserial(self) -> None:
        """测试 BIGSERIAL 类型。"""
        sql = """
        CREATE TABLE logs (
            id BIGSERIAL PRIMARY KEY,
            message TEXT
        )
        """
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "postgresql",
            "statement_type": "CREATE",
            "errors": [],
            "warnings": [],
        })
