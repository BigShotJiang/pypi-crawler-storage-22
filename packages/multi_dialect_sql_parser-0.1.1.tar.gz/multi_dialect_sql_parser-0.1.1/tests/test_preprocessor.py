"""预处理器测试。"""
import pytest
from sql_parser.preprocessor import SQLPreprocessor, preprocess_sql


class TestTiDBPreprocessor:
    """TiDB 预处理器测试。"""
    
    def setup_method(self):
        self.preprocessor = SQLPreprocessor(dialect="tidb")
    
    def test_auto_random_basic(self):
        """测试 AUTO_RANDOM 基本处理。"""
        sql = "CREATE TABLE t (id BIGINT AUTO_RANDOM PRIMARY KEY)"
        result = self.preprocessor.preprocess(sql)
        
        assert result.preprocessed
        assert "AUTO_INCREMENT" in result.sql
        assert "AUTO_RANDOM" not in result.sql
        assert len(result.modifications) == 1
        assert result.modifications[0]["type"] == "auto_random"
    
    def test_auto_random_with_bits(self):
        """测试带参数的 AUTO_RANDOM。"""
        sql = "CREATE TABLE t (id BIGINT AUTO_RANDOM(5) PRIMARY KEY)"
        result = self.preprocessor.preprocess(sql)
        
        assert result.preprocessed
        assert "AUTO_INCREMENT" in result.sql
        assert len(result.modifications) == 1
        assert result.modifications[0]["shard_bits"] == "5"
    
    def test_shard_row_id_bits(self):
        """测试 SHARD_ROW_ID_BITS 处理。"""
        sql = "CREATE TABLE t (id INT) SHARD_ROW_ID_BITS=4"
        result = self.preprocessor.preprocess(sql)
        
        assert result.preprocessed
        assert "SHARD_ROW_ID_BITS" not in result.sql
        assert len(result.modifications) == 1
        assert result.modifications[0]["type"] == "shard_row_id_bits"
    
    def test_pre_split_regions(self):
        """测试 PRE_SPLIT_REGIONS 处理。"""
        sql = "CREATE TABLE t (id INT) PRE_SPLIT_REGIONS=3"
        result = self.preprocessor.preprocess(sql)
        
        assert result.preprocessed
        assert "PRE_SPLIT_REGIONS" not in result.sql
    
    def test_clustered(self):
        """测试 CLUSTERED/NONCLUSTERED 处理。"""
        sql = "CREATE TABLE t (id INT PRIMARY KEY CLUSTERED)"
        result = self.preprocessor.preprocess(sql)
        
        assert result.preprocessed
        assert "CLUSTERED" not in result.sql
    
    def test_no_modification_needed(self):
        """测试不需要预处理的 SQL。"""
        sql = "SELECT * FROM users WHERE id = 1"
        result = self.preprocessor.preprocess(sql)
        
        assert not result.preprocessed
        assert result.sql == sql
        assert len(result.modifications) == 0
    
    def test_multiple_modifications(self):
        """测试多个修改。"""
        sql = """
        CREATE TABLE t (
            id BIGINT AUTO_RANDOM PRIMARY KEY
        ) SHARD_ROW_ID_BITS=4 PRE_SPLIT_REGIONS=3
        """
        result = self.preprocessor.preprocess(sql)
        
        assert result.preprocessed
        assert len(result.modifications) == 3


class TestOceanBasePreprocessor:
    """OceanBase 预处理器测试。"""
    
    def setup_method(self):
        self.mysql_preprocessor = SQLPreprocessor(dialect="oceanbase-mysql")
        self.oracle_preprocessor = SQLPreprocessor(dialect="oceanbase-oracle")
    
    def test_tablegroup(self):
        """测试 TABLEGROUP 处理。"""
        sql = "CREATE TABLE t (id INT) TABLEGROUP=tg1"
        result = self.mysql_preprocessor.preprocess(sql)
        
        assert result.preprocessed
        assert "TABLEGROUP" not in result.sql
    
    def test_locality(self):
        """测试 LOCALITY 处理。"""
        sql = "CREATE TABLE t (id INT) LOCALITY='F@zone1'"
        result = self.mysql_preprocessor.preprocess(sql)
        
        assert result.preprocessed
        assert "LOCALITY" not in result.sql
    
    def test_replica_num(self):
        """测试 REPLICA_NUM 处理。"""
        sql = "CREATE TABLE t (id INT) REPLICA_NUM=3"
        result = self.mysql_preprocessor.preprocess(sql)
        
        assert result.preprocessed
        assert "REPLICA_NUM" not in result.sql
    
    def test_primary_zone(self):
        """测试 PRIMARY_ZONE 处理。"""
        sql = "CREATE TABLE t (id INT) PRIMARY_ZONE='zone1'"
        result = self.mysql_preprocessor.preprocess(sql)
        
        assert result.preprocessed
        assert "PRIMARY_ZONE" not in result.sql
    
    def test_oracle_mode(self):
        """测试 Oracle 模式预处理。"""
        sql = "CREATE TABLE t (id NUMBER) TABLEGROUP=tg1"
        result = self.oracle_preprocessor.preprocess(sql)
        
        assert result.preprocessed
        assert "TABLEGROUP" not in result.sql


class TestPreprocessFunction:
    """preprocess_sql 函数测试。"""
    
    def test_convenience_function(self):
        """测试便捷函数。"""
        sql = "CREATE TABLE t (id BIGINT AUTO_RANDOM PRIMARY KEY)"
        result = preprocess_sql(sql, "tidb")
        
        assert result.preprocessed
        assert "AUTO_INCREMENT" in result.sql
    
    def test_unsupported_dialect(self):
        """测试不需要预处理的方言。"""
        sql = "SELECT * FROM users"
        result = preprocess_sql(sql, "mysql")
        
        assert not result.preprocessed
        assert result.sql == sql
