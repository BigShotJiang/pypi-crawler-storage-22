"""过程化语法解析测试。"""
import pytest
from sql_parser.preprocessor import SQLPreprocessor, ProceduralInfo
from tests.sql_scripts.procedural_scripts import (
    ORACLE_PROCEDURAL_CASES,
    MYSQL_PROCEDURAL_CASES,
    POSTGRESQL_PROCEDURAL_CASES,
    TIDB_PROCEDURAL_CASES,
    OCEANBASE_MYSQL_PROCEDURAL_CASES,
    OCEANBASE_ORACLE_PROCEDURAL_CASES,
)


class TestOracleProcedural:
    """Oracle PL/SQL 过程化语法测试。"""
    
    @pytest.fixture
    def preprocessor(self):
        return SQLPreprocessor("oracle")
    
    @pytest.mark.parametrize("case_name,case_data", ORACLE_PROCEDURAL_CASES.items())
    def test_oracle_procedural(self, preprocessor, case_name, case_data):
        """测试 Oracle 过程化语法解析。"""
        result = preprocessor.preprocess(case_data["sql"])
        expected = case_data["expected"]
        
        # 验证预处理成功
        assert result.preprocessed, f"Case {case_name}: 预处理应该成功"
        assert result.procedural_info is not None, f"Case {case_name}: 应该有过程化信息"
        
        # 验证类型
        assert result.procedural_info.type == expected["type"], \
            f"Case {case_name}: 类型应该是 {expected['type']}"
        
        # 验证名称
        if "name" in expected:
            assert result.procedural_info.name == expected["name"], \
                f"Case {case_name}: 名称应该是 {expected['name']}"
        
        # 验证返回类型
        if "return_type" in expected:
            assert result.procedural_info.return_type == expected["return_type"], \
                f"Case {case_name}: 返回类型应该是 {expected['return_type']}"
        
        # 验证参数数量
        if "param_count" in expected:
            assert len(result.procedural_info.parameters) == expected["param_count"], \
                f"Case {case_name}: 参数数量应该是 {expected['param_count']}"
        
        # 验证 OR REPLACE
        if "is_replace" in expected:
            assert result.procedural_info.is_replace == expected["is_replace"], \
                f"Case {case_name}: is_replace 应该是 {expected['is_replace']}"
        
        # 验证 schema
        if "schema_name" in expected:
            assert result.procedural_info.schema_name == expected["schema_name"], \
                f"Case {case_name}: schema 应该是 {expected['schema_name']}"
        
        # 验证触发器信息
        if "timing" in expected:
            assert result.procedural_info.timing == expected["timing"], \
                f"Case {case_name}: timing 应该是 {expected['timing']}"
        
        if "table_name" in expected:
            assert result.procedural_info.table_name == expected["table_name"], \
                f"Case {case_name}: table_name 应该是 {expected['table_name']}"
        
        # 验证包信息
        if "is_body" in expected:
            assert result.procedural_info.is_body == expected["is_body"], \
                f"Case {case_name}: is_body 应该是 {expected['is_body']}"
        
        if "procedure_count" in expected:
            assert len(result.procedural_info.procedures) == expected["procedure_count"], \
                f"Case {case_name}: 过程数量应该是 {expected['procedure_count']}"
        
        if "function_count" in expected:
            assert len(result.procedural_info.functions) == expected["function_count"], \
                f"Case {case_name}: 函数数量应该是 {expected['function_count']}"


class TestMySQLProcedural:
    """MySQL 存储过程语法测试。"""
    
    @pytest.fixture
    def preprocessor(self):
        return SQLPreprocessor("mysql")
    
    @pytest.mark.parametrize("case_name,case_data", MYSQL_PROCEDURAL_CASES.items())
    def test_mysql_procedural(self, preprocessor, case_name, case_data):
        """测试 MySQL 过程化语法解析。"""
        result = preprocessor.preprocess(case_data["sql"])
        expected = case_data["expected"]
        
        assert result.preprocessed, f"Case {case_name}: 预处理应该成功"
        assert result.procedural_info is not None, f"Case {case_name}: 应该有过程化信息"
        
        assert result.procedural_info.type == expected["type"], \
            f"Case {case_name}: 类型应该是 {expected['type']}"
        
        if "name" in expected:
            assert result.procedural_info.name == expected["name"]
        
        if "return_type" in expected:
            assert result.procedural_info.return_type == expected["return_type"]
        
        if "param_count" in expected:
            assert len(result.procedural_info.parameters) == expected["param_count"]
        
        if "deterministic" in expected:
            assert result.procedural_info.deterministic == expected["deterministic"]
        
        if "definer" in expected:
            assert result.procedural_info.definer == expected["definer"]
        
        if "timing" in expected:
            assert result.procedural_info.timing == expected["timing"]
        
        if "table_name" in expected:
            assert result.procedural_info.table_name == expected["table_name"]


class TestPostgreSQLProcedural:
    """PostgreSQL PL/pgSQL 语法测试。"""
    
    @pytest.fixture
    def preprocessor(self):
        return SQLPreprocessor("postgresql")
    
    @pytest.mark.parametrize("case_name,case_data", POSTGRESQL_PROCEDURAL_CASES.items())
    def test_postgresql_procedural(self, preprocessor, case_name, case_data):
        """测试 PostgreSQL 过程化语法解析。"""
        result = preprocessor.preprocess(case_data["sql"])
        expected = case_data["expected"]
        
        assert result.preprocessed, f"Case {case_name}: 预处理应该成功"
        assert result.procedural_info is not None, f"Case {case_name}: 应该有过程化信息"
        
        assert result.procedural_info.type == expected["type"], \
            f"Case {case_name}: 类型应该是 {expected['type']}"
        
        if "name" in expected:
            assert result.procedural_info.name == expected["name"]
        
        if "return_type" in expected:
            assert result.procedural_info.return_type == expected["return_type"]
        
        if "param_count" in expected:
            assert len(result.procedural_info.parameters) == expected["param_count"]
        
        if "language" in expected:
            assert result.procedural_info.language == expected["language"]
        
        if "is_replace" in expected:
            assert result.procedural_info.is_replace == expected["is_replace"]
        
        if "timing" in expected:
            assert result.procedural_info.timing == expected["timing"]
        
        if "table_name" in expected:
            assert result.procedural_info.table_name == expected["table_name"]


class TestTiDBProcedural:
    """TiDB 过程化语法测试（复用 MySQL）。"""
    
    @pytest.fixture
    def preprocessor(self):
        return SQLPreprocessor("tidb")
    
    @pytest.mark.parametrize("case_name,case_data", TIDB_PROCEDURAL_CASES.items())
    def test_tidb_procedural(self, preprocessor, case_name, case_data):
        """测试 TiDB 过程化语法解析。"""
        result = preprocessor.preprocess(case_data["sql"])
        expected = case_data["expected"]
        
        assert result.preprocessed, f"Case {case_name}: 预处理应该成功"
        assert result.procedural_info is not None, f"Case {case_name}: 应该有过程化信息"
        
        assert result.procedural_info.type == expected["type"]
        
        if "name" in expected:
            assert result.procedural_info.name == expected["name"]
        
        if "param_count" in expected:
            assert len(result.procedural_info.parameters) == expected["param_count"]
        
        if "deterministic" in expected:
            assert result.procedural_info.deterministic == expected["deterministic"]
        
        if "timing" in expected:
            assert result.procedural_info.timing == expected["timing"]


class TestOceanBaseMySQLProcedural:
    """OceanBase MySQL 模式过程化语法测试。"""
    
    @pytest.fixture
    def preprocessor(self):
        return SQLPreprocessor("oceanbase-mysql")
    
    @pytest.mark.parametrize("case_name,case_data", OCEANBASE_MYSQL_PROCEDURAL_CASES.items())
    def test_oceanbase_mysql_procedural(self, preprocessor, case_name, case_data):
        """测试 OceanBase MySQL 模式过程化语法解析。"""
        result = preprocessor.preprocess(case_data["sql"])
        expected = case_data["expected"]
        
        assert result.preprocessed, f"Case {case_name}: 预处理应该成功"
        assert result.procedural_info is not None, f"Case {case_name}: 应该有过程化信息"
        
        assert result.procedural_info.type == expected["type"]
        
        if "name" in expected:
            assert result.procedural_info.name == expected["name"]
        
        if "param_count" in expected:
            assert len(result.procedural_info.parameters) == expected["param_count"]


class TestOceanBaseOracleProcedural:
    """OceanBase Oracle 模式过程化语法测试。"""
    
    @pytest.fixture
    def preprocessor(self):
        return SQLPreprocessor("oceanbase-oracle")
    
    @pytest.mark.parametrize("case_name,case_data", OCEANBASE_ORACLE_PROCEDURAL_CASES.items())
    def test_oceanbase_oracle_procedural(self, preprocessor, case_name, case_data):
        """测试 OceanBase Oracle 模式过程化语法解析。"""
        result = preprocessor.preprocess(case_data["sql"])
        expected = case_data["expected"]
        
        assert result.preprocessed, f"Case {case_name}: 预处理应该成功"
        assert result.procedural_info is not None, f"Case {case_name}: 应该有过程化信息"
        
        assert result.procedural_info.type == expected["type"]
        
        if "name" in expected:
            assert result.procedural_info.name == expected["name"]
        
        if "return_type" in expected:
            assert result.procedural_info.return_type == expected["return_type"]
        
        if "param_count" in expected:
            assert len(result.procedural_info.parameters) == expected["param_count"]


class TestParameterParsing:
    """参数解析测试。"""
    
    def test_oracle_in_out_parameters(self):
        """测试 Oracle IN/OUT 参数解析。"""
        preprocessor = SQLPreprocessor("oracle")
        sql = """CREATE PROCEDURE test_proc(
            p_in IN NUMBER,
            p_out OUT VARCHAR2,
            p_inout IN OUT NUMBER
        ) AS BEGIN NULL; END;"""
        
        result = preprocessor.preprocess(sql)
        assert result.procedural_info is not None
        
        params = result.procedural_info.parameters
        assert len(params) == 3
        assert params[0].mode == "IN"
        assert params[1].mode == "OUT"
        assert params[2].mode == "IN OUT"
    
    def test_mysql_in_out_parameters(self):
        """测试 MySQL IN/OUT 参数解析。"""
        preprocessor = SQLPreprocessor("mysql")
        sql = """CREATE PROCEDURE test_proc(
            IN p_in INT,
            OUT p_out VARCHAR(100),
            INOUT p_inout DECIMAL(10,2)
        )
        BEGIN
            SELECT 1;
        END"""
        
        result = preprocessor.preprocess(sql)
        assert result.procedural_info is not None
        
        params = result.procedural_info.parameters
        assert len(params) == 3
        assert params[0].mode == "IN"
        assert params[1].mode == "OUT"
        assert params[2].mode == "INOUT"
    
    def test_postgresql_default_parameters(self):
        """测试 PostgreSQL 默认参数解析。"""
        preprocessor = SQLPreprocessor("postgresql")
        sql = """CREATE FUNCTION test_func(
            p_required INTEGER,
            p_optional INTEGER DEFAULT 10
        )
        RETURNS INTEGER AS $$
        BEGIN
            RETURN p_required + p_optional;
        END;
        $$ LANGUAGE plpgsql;"""
        
        result = preprocessor.preprocess(sql)
        assert result.procedural_info is not None
        
        params = result.procedural_info.parameters
        assert len(params) == 2
        assert params[1].default_value == "10"


class TestDollarQuotedBody:
    """PostgreSQL $$ 语法测试。"""
    
    def test_simple_dollar_quote(self):
        """测试简单 $$ 语法。"""
        preprocessor = SQLPreprocessor("postgresql")
        sql = """CREATE FUNCTION test() RETURNS INTEGER AS $$
BEGIN
    RETURN 1;
END;
$$ LANGUAGE plpgsql;"""
        
        result = preprocessor.preprocess(sql)
        assert result.procedural_info is not None
        assert "RETURN 1" in result.procedural_info.body
    
    def test_named_dollar_quote(self):
        """测试命名 $tag$ 语法。"""
        preprocessor = SQLPreprocessor("postgresql")
        sql = """CREATE FUNCTION test() RETURNS INTEGER AS $func_body$
BEGIN
    RETURN 1;
END;
$func_body$ LANGUAGE plpgsql;"""
        
        result = preprocessor.preprocess(sql)
        assert result.procedural_info is not None
        assert "RETURN 1" in result.procedural_info.body


class TestStatementTypeMapping:
    """测试 statement_type 映射。"""
    
    def test_oracle_function_statement_type(self):
        """测试 Oracle 函数的 statement_type。"""
        from sql_parser.core import parse_single_sql
        
        sql = """CREATE FUNCTION get_count RETURN NUMBER AS
BEGIN
    RETURN 1;
END;"""
        result = parse_single_sql(sql, "oracle")
        assert result["statement_type"] == "CREATE_FUNCTION"
        assert result["oracle_info"] is not None
        assert result["oracle_info"]["procedural_info"] is not None
        assert result["oracle_info"]["procedural_info"]["type"] == "FUNCTION"
    
    def test_oracle_procedure_statement_type(self):
        """测试 Oracle 存储过程的 statement_type。"""
        from sql_parser.core import parse_single_sql
        
        sql = """CREATE PROCEDURE log_msg(p_msg VARCHAR2) AS
BEGIN
    NULL;
END;"""
        result = parse_single_sql(sql, "oracle")
        assert result["statement_type"] == "CREATE_PROCEDURE"
    
    def test_oracle_package_statement_type(self):
        """测试 Oracle 包的 statement_type。"""
        from sql_parser.core import parse_single_sql
        
        sql = """CREATE PACKAGE emp_pkg AS
    PROCEDURE hire(p_name VARCHAR2);
END emp_pkg;"""
        result = parse_single_sql(sql, "oracle")
        assert result["statement_type"] == "CREATE_PACKAGE"
    
    def test_oracle_trigger_statement_type(self):
        """测试 Oracle 触发器的 statement_type。"""
        from sql_parser.core import parse_single_sql
        
        sql = """CREATE TRIGGER trg_test
BEFORE INSERT ON employees
FOR EACH ROW
BEGIN
    NULL;
END;"""
        result = parse_single_sql(sql, "oracle")
        assert result["statement_type"] == "CREATE_TRIGGER"
    
    def test_oracle_anonymous_block_statement_type(self):
        """测试 Oracle 匿名块的 statement_type。"""
        from sql_parser.core import parse_single_sql
        
        sql = """BEGIN
    DBMS_OUTPUT.PUT_LINE('Hello');
END;"""
        result = parse_single_sql(sql, "oracle")
        assert result["statement_type"] == "ANONYMOUS_BLOCK"
    
    def test_mysql_function_statement_type(self):
        """测试 MySQL 函数的 statement_type。"""
        from sql_parser.core import parse_single_sql
        
        sql = """CREATE FUNCTION get_count()
RETURNS INT
DETERMINISTIC
BEGIN
    RETURN 1;
END"""
        result = parse_single_sql(sql, "mysql")
        assert result["statement_type"] == "CREATE_FUNCTION"
        assert result["mysql_info"] is not None
        assert result["mysql_info"]["procedural_info"] is not None
    
    def test_mysql_procedure_statement_type(self):
        """测试 MySQL 存储过程的 statement_type。"""
        from sql_parser.core import parse_single_sql
        
        sql = """CREATE PROCEDURE log_msg(IN msg VARCHAR(100))
BEGIN
    SELECT 1;
END"""
        result = parse_single_sql(sql, "mysql")
        assert result["statement_type"] == "CREATE_PROCEDURE"
    
    def test_mysql_trigger_statement_type(self):
        """测试 MySQL 触发器的 statement_type。"""
        from sql_parser.core import parse_single_sql
        
        sql = """CREATE TRIGGER trg_test
BEFORE INSERT ON employees
FOR EACH ROW
BEGIN
    SET NEW.created_at = NOW();
END"""
        result = parse_single_sql(sql, "mysql")
        assert result["statement_type"] == "CREATE_TRIGGER"
    
    def test_postgresql_function_statement_type(self):
        """测试 PostgreSQL 函数的 statement_type。"""
        from sql_parser.core import parse_single_sql
        
        sql = """CREATE FUNCTION get_count()
RETURNS INTEGER AS $
BEGIN
    RETURN 1;
END;
$ LANGUAGE plpgsql;"""
        result = parse_single_sql(sql, "postgresql")
        assert result["statement_type"] == "CREATE_FUNCTION"
        assert result["postgresql_info"] is not None
        assert result["postgresql_info"]["procedural_info"] is not None
    
    def test_postgresql_do_block_statement_type(self):
        """测试 PostgreSQL DO 块的 statement_type。"""
        from sql_parser.core import parse_single_sql
        
        sql = """DO $$
BEGIN
    RAISE NOTICE 'Hello';
END;
$$;"""
        result = parse_single_sql(sql, "postgresql")
        assert result["statement_type"] == "ANONYMOUS_BLOCK"
    
    def test_tidb_function_statement_type(self):
        """测试 TiDB 函数的 statement_type。"""
        from sql_parser.core import parse_single_sql
        
        sql = """CREATE FUNCTION get_count()
RETURNS INT
DETERMINISTIC
BEGIN
    RETURN 1;
END"""
        result = parse_single_sql(sql, "tidb")
        assert result["statement_type"] == "CREATE_FUNCTION"
        assert result["tidb_info"] is not None
        assert result["tidb_info"]["procedural_info"] is not None
    
    def test_oceanbase_mysql_function_statement_type(self):
        """测试 OceanBase MySQL 模式函数的 statement_type。"""
        from sql_parser.core import parse_single_sql
        
        sql = """CREATE FUNCTION get_count()
RETURNS INT
DETERMINISTIC
BEGIN
    RETURN 1;
END"""
        result = parse_single_sql(sql, "oceanbase-mysql")
        assert result["statement_type"] == "CREATE_FUNCTION"
        assert result["oceanbase_info"] is not None
        assert result["oceanbase_info"]["procedural_info"] is not None
    
    def test_oceanbase_oracle_function_statement_type(self):
        """测试 OceanBase Oracle 模式函数的 statement_type。"""
        from sql_parser.core import parse_single_sql
        
        sql = """CREATE FUNCTION get_count RETURN NUMBER AS
BEGIN
    RETURN 1;
END;"""
        result = parse_single_sql(sql, "oceanbase-oracle")
        assert result["statement_type"] == "CREATE_FUNCTION"
        assert result["oceanbase_info"] is not None
        assert result["oceanbase_info"]["procedural_info"] is not None
