"""TiDB 方言单元测试。

使用 SQL 脚本作为入参，完整验证所有解析后的参数。
"""
import pytest
from sql_parser import SQLParser
from tests.conftest import verify_parse_result
from tests.sql_scripts.tidb_scripts import TIDB_TEST_CASES


class TestTiDBFromScripts:
    """TiDB SQL 脚本测试。"""
    
    @pytest.fixture(autouse=True)
    def setup(self, tidb_parser: SQLParser) -> None:
        """初始化 TiDB 解析器。"""
        self.parser = tidb_parser
    
    @pytest.mark.parametrize(
        "test_case",
        TIDB_TEST_CASES,
        ids=[tc["name"] for tc in TIDB_TEST_CASES]
    )
    def test_tidb_sql_scripts(self, test_case: dict) -> None:
        """测试 TiDB SQL 脚本解析。
        
        Args:
            test_case: 测试用例，包含 sql 和 expected 字段
        """
        # 解析 SQL
        result = self.parser.parse(test_case["sql"])
        
        # 验证所有期望的字段
        verify_parse_result(result, test_case["expected"])


class TestTiDBMySQLCompatibility:
    """TiDB MySQL 兼容性测试。"""
    
    def setup_method(self) -> None:
        """初始化 TiDB 解析器。"""
        self.parser = SQLParser(dialect="tidb")
    
    def test_simple_select(self) -> None:
        """测试简单 SELECT 语句。"""
        sql = "SELECT id, name FROM users"
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "tidb",
            "statement_type": "SELECT",
            "tables": [
                {"name": "users", "schema_name": None, "alias": None, "type": "table"}
            ],
            "errors": [],
            "warnings": [],
        })
    
    def test_backtick_identifier(self) -> None:
        """测试反引号标识符（MySQL 兼容）。"""
        sql = "SELECT `id`, `user_name` FROM `user_table`"
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "tidb",
            "statement_type": "SELECT",
            "tables": [
                {"name": "user_table", "schema_name": None, "alias": None, "type": "table"}
            ],
            "errors": [],
            "warnings": [],
        })
    
    def test_limit_clause(self) -> None:
        """测试 LIMIT 子句（MySQL 兼容）。"""
        sql = "SELECT * FROM users LIMIT 10"
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "tidb",
            "statement_type": "SELECT",
            "limit": 10,
            "errors": [],
            "warnings": [],
        })
    
    def test_join(self) -> None:
        """测试 JOIN（MySQL 兼容）。"""
        sql = "SELECT * FROM users u LEFT JOIN orders o ON u.id = o.user_id"
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "tidb",
            "statement_type": "SELECT",
            "joins_count": 1,
            "errors": [],
            "warnings": [],
        })
    
    def test_group_by_order_by(self) -> None:
        """测试 GROUP BY / ORDER BY（MySQL 兼容）。"""
        sql = """
        SELECT department, COUNT(*) as cnt
        FROM employees
        GROUP BY department
        ORDER BY cnt DESC
        """
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "tidb",
            "statement_type": "SELECT",
            "group_by": ["department"],
            "order_by": [
                {"column": "cnt", "direction": "DESC"}
            ],
            "errors": [],
            "warnings": [],
        })


class TestTiDBHints:
    """TiDB Hint 解析测试。"""
    
    def setup_method(self) -> None:
        self.parser = SQLParser(dialect="tidb")
    
    def test_use_index_hint(self) -> None:
        """测试 USE_INDEX Hint。"""
        sql = "SELECT /*+ USE_INDEX(t, idx_name) */ * FROM t WHERE id = 1"
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "tidb",
            "statement_type": "SELECT",
            "tidb_info": {
                "hints": [
                    {"name": "USE_INDEX", "type": "index_hint", "args": "t, idx_name"}
                ],
            },
            "errors": [],
            "warnings": [],
        })
    
    def test_hash_join_hint(self) -> None:
        """测试 HASH_JOIN Hint。"""
        sql = "SELECT /*+ HASH_JOIN(t1, t2) */ * FROM t1 JOIN t2 ON t1.id = t2.id"
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "tidb",
            "statement_type": "SELECT",
            "tidb_info": {
                "hints": [
                    {"name": "HASH_JOIN", "type": "join_hint", "args": "t1, t2"}
                ],
            },
            "errors": [],
            "warnings": [],
        })
    
    def test_read_from_storage_hint(self) -> None:
        """测试 READ_FROM_STORAGE Hint。"""
        sql = "SELECT /*+ READ_FROM_STORAGE(tikv[t]) */ * FROM t"
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "tidb",
            "statement_type": "SELECT",
            "tidb_info": {
                "hints": [
                    {"name": "READ_FROM_STORAGE", "type": "storage_hint", "args": "tikv[t]"}
                ],
            },
            "errors": [],
            "warnings": [],
        })
    
    def test_multiple_hints(self) -> None:
        """测试多个 Hint。"""
        sql = """
        SELECT /*+ USE_INDEX(t1, idx1) */ /*+ HASH_JOIN(t1, t2) */ *
        FROM t1 JOIN t2 ON t1.id = t2.id
        """
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "tidb",
            "statement_type": "SELECT",
            "tidb_info": {
                "hints_count": 2,
            },
            "errors": [],
            "warnings": [],
        })
    
    def test_hash_agg_hint(self) -> None:
        """测试 HASH_AGG Hint。"""
        sql = "SELECT /*+ HASH_AGG() */ department, COUNT(*) FROM employees GROUP BY department"
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "tidb",
            "statement_type": "SELECT",
            "group_by": ["department"],
            "tidb_info": {
                "hints": [
                    {"name": "HASH_AGG", "type": "agg_hint", "args": ""}
                ],
            },
            "errors": [],
            "warnings": [],
        })


class TestTiDBSpecificSyntax:
    """TiDB 特有语法测试。"""
    
    def setup_method(self) -> None:
        self.parser = SQLParser(dialect="tidb")
    
    def test_auto_random_detection(self) -> None:
        """测试 AUTO_RANDOM 检测（通过预处理支持）。"""
        sql = """
        CREATE TABLE users (
            id BIGINT AUTO_RANDOM PRIMARY KEY,
            name VARCHAR(100)
        )
        """
        result = self.parser.parse(sql)
        
        # 预处理后应该能解析成功，会有 warnings 提示经过预处理
        verify_parse_result(result, {
            "success": True,
            "dialect": "tidb",
            "statement_type": "CREATE",
            "tidb_info": {
                "preprocessed": True,
                "auto_random_columns": ["id"],
            },
            "errors": [],
        })
    
    def test_insert(self) -> None:
        """测试 INSERT 语句。"""
        sql = "INSERT INTO users (name, email) VALUES ('John', 'john@example.com')"
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "tidb",
            "statement_type": "INSERT",
            "errors": [],
            "warnings": [],
        })
    
    def test_update(self) -> None:
        """测试 UPDATE 语句。"""
        sql = "UPDATE users SET name = 'Jane' WHERE id = 1"
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "tidb",
            "statement_type": "UPDATE",
            "conditions_count": 1,
            "errors": [],
            "warnings": [],
        })
    
    def test_delete(self) -> None:
        """测试 DELETE 语句。"""
        sql = "DELETE FROM users WHERE id = 1"
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "tidb",
            "statement_type": "DELETE",
            "conditions_count": 1,
            "errors": [],
            "warnings": [],
        })


class TestTiDBComplexQueries:
    """TiDB 复杂查询测试。"""
    
    def setup_method(self) -> None:
        self.parser = SQLParser(dialect="tidb")
    
    def test_subquery(self) -> None:
        """测试子查询。"""
        sql = """
        SELECT * FROM users
        WHERE department_id IN (
            SELECT id FROM departments WHERE status = 'active'
        )
        """
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "tidb",
            "statement_type": "SELECT",
            "errors": [],
            "warnings": [],
        })
    
    def test_cte(self) -> None:
        """测试 CTE (WITH 子句)。"""
        sql = """
        WITH active_users AS (
            SELECT * FROM users WHERE status = 'active'
        )
        SELECT * FROM active_users
        """
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "tidb",
            "statement_type": "SELECT",
            "errors": [],
            "warnings": [],
        })
    
    def test_window_function(self) -> None:
        """测试窗口函数。"""
        sql = """
        SELECT 
            name,
            salary,
            ROW_NUMBER() OVER (PARTITION BY department ORDER BY salary DESC) as rank
        FROM employees
        """
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "tidb",
            "statement_type": "SELECT",
            "errors": [],
            "warnings": [],
        })
    
    def test_union(self) -> None:
        """测试 UNION。"""
        sql = """
        SELECT id, name FROM users WHERE status = 'active'
        UNION ALL
        SELECT id, name FROM archived_users
        """
        result = self.parser.parse(sql)
        
        # UNION 语句在 SQLGlot 中被解析为 OTHER 类型
        verify_parse_result(result, {
            "success": True,
            "dialect": "tidb",
            "errors": [],
        })


class TestTiDBNoHints:
    """TiDB 无 Hint 情况测试。"""
    
    def setup_method(self) -> None:
        self.parser = SQLParser(dialect="tidb")
    
    def test_no_hints(self) -> None:
        """测试无 Hint 的 SQL。"""
        sql = "SELECT * FROM users WHERE id = 1"
        result = self.parser.parse(sql)
        
        verify_parse_result(result, {
            "success": True,
            "dialect": "tidb",
            "statement_type": "SELECT",
            "tidb_info": {
                "hints": [],
            },
            "errors": [],
            "warnings": [],
        })
