# Design Document: SQL Parser Performance Optimization

## Overview

This design document describes the technical approach for optimizing the multi-dialect SQL parser library. The optimization focuses on three main areas:

1. **Memory Optimization**: Reduce memory allocation through `model_construct()`, lazy loading, and shared collections
2. **Efficiency Optimization**: Single AST traversal and `__slots__` classes for intermediate results
3. **Caching**: Optional LRU cache for repeated SQL parsing

The design maintains full backward compatibility while achieving at least 20% speed improvement and 30% memory reduction.

## Architecture

The optimization touches four main components:

```mermaid
graph TB
    subgraph "SQL Parser Architecture"
        A[SQLParser] --> B[core.py - parse_single_sql]
        B --> C[extractors/base.py - BaseExtractor]
        B --> D[models.py - ParseResult]
        
        subgraph "Optimizations"
            E[LRU Cache Layer]
            F[Single Traversal Extractor]
            G[Optimized Model Construction]
            H[Shared Empty Collections]
        end
        
        A -.-> E
        C -.-> F
        D -.-> G
        D -.-> H
    end
```

### Component Interaction Flow

```mermaid
sequenceDiagram
    participant Client
    participant SQLParser
    participant Cache
    participant Core
    participant Extractor
    participant Models

    Client->>SQLParser: parse(sql)
    
    alt Cache Enabled
        SQLParser->>Cache: lookup(sql, dialect)
        alt Cache Hit
            Cache-->>SQLParser: cached_result
            SQLParser-->>Client: ParseResult
        else Cache Miss
            SQLParser->>Core: parse_single_sql(sql, dialect)
            Core->>Extractor: extract_all(ast)
            Extractor-->>Core: extraction_result
            Core->>Models: build_result_optimized()
            Models-->>Core: ParseResult
            Core-->>SQLParser: result
            SQLParser->>Cache: store(sql, dialect, result)
            SQLParser-->>Client: ParseResult
        end
    else Cache Disabled
        SQLParser->>Core: parse_single_sql(sql, dialect)
        Core->>Extractor: extract_all(ast)
        Extractor-->>Core: extraction_result
        Core->>Models: build_result_optimized()
        Models-->>Core: ParseResult
        Core-->>SQLParser: result
        SQLParser-->>Client: ParseResult
    end
```

## Components and Interfaces

### 1. Shared Empty Collections Module

A new module or section in `models.py` that defines shared immutable empty collections:

```python
# Shared empty collections (immutable tuples for safety)
EMPTY_TUPLE: tuple = ()
EMPTY_LIST: list = []  # For Pydantic compatibility, but prefer tuples

# Type-specific empty collections for model defaults
EMPTY_TABLES: tuple = ()
EMPTY_COLUMNS: tuple = ()
EMPTY_CONDITIONS: tuple = ()
EMPTY_JOINS: tuple = ()
EMPTY_GROUP_BY: tuple = ()
EMPTY_ORDER_BY: tuple = ()
EMPTY_ERRORS: tuple = ()
EMPTY_WARNINGS: tuple = ()
```

### 2. Slots-Based Intermediate Result Classes

New classes in `extractors/base.py` for memory-efficient intermediate storage:

```python
class TableInfo:
    """Memory-efficient table info storage."""
    __slots__ = ('name', 'schema_name', 'alias', 'type')
    
    def __init__(self, name: str, schema_name: str | None = None, 
                 alias: str | None = None, type: str = 'table'):
        self.name = name
        self.schema_name = schema_name
        self.alias = alias
        self.type = type
    
    def to_dict(self) -> dict:
        return {
            'name': self.name,
            'schema_name': self.schema_name,
            'alias': self.alias,
            'type': self.type,
        }


class ColumnInfo:
    """Memory-efficient column info storage."""
    __slots__ = ('name', 'table', 'alias')
    
    def __init__(self, name: str, table: str | None = None, 
                 alias: str | None = None):
        self.name = name
        self.table = table
        self.alias = alias
    
    def to_dict(self) -> dict:
        return {
            'name': self.name,
            'table': self.table,
            'alias': self.alias,
        }


class JoinInfo:
    """Memory-efficient join info storage."""
    __slots__ = ('type', 'table', 'condition')
    
    def __init__(self, type: str, table: TableInfo, 
                 condition: str | None = None):
        self.type = type
        self.table = table
        self.condition = condition


class ExtractionResult:
    """Container for all extracted information from single traversal."""
    __slots__ = ('tables', 'columns', 'conditions', 'joins', 
                 'group_by', 'order_by', 'limit', 'offset',
                 'where_clause', 'statement_type')
    
    def __init__(self):
        self.tables: list[TableInfo] = []
        self.columns: list[ColumnInfo] = []
        self.conditions: list = []
        self.joins: list[JoinInfo] = []
        self.group_by: list[str] = []
        self.order_by: list = []
        self.limit: int | None = None
        self.offset: int | None = None
        self.where_clause = None
        self.statement_type: str = 'OTHER'
```

### 3. Single Traversal Extractor

Enhanced `BaseExtractor` with a unified extraction method:

```python
class BaseExtractor:
    """Base SQL information extractor with single-traversal optimization."""
    
    __slots__ = ()
    
    @staticmethod
    def extract_all(ast: Any) -> ExtractionResult:
        """Extract all information in a single AST traversal.
        
        This method replaces multiple find_all() calls with a single
        traversal that collects all required information.
        
        Args:
            ast: SQL AST from sqlglot
        
        Returns:
            ExtractionResult containing all extracted information
        """
        result = ExtractionResult()
        result.statement_type = STATEMENT_TYPE_MAP.get(
            type(ast).__name__, 'OTHER'
        )
        
        # Single traversal using walk()
        for node in ast.walk():
            node_type = type(node)
            
            if node_type is exp.Table:
                result.tables.append(TableInfo(
                    name=node.name,
                    schema_name=node.db,
                    alias=node.alias,
                    type='table'
                ))
            
            elif node_type is exp.Column:
                result.columns.append(ColumnInfo(
                    name=node.name,
                    table=node.table,
                    alias=None
                ))
            
            elif node_type is exp.Join:
                # Extract join info
                table_node = node.this
                on_cond = node.args.get('on')
                result.joins.append(JoinInfo(
                    type=BaseExtractor._get_join_type(node),
                    table=TableInfo(
                        name=table_node.name if hasattr(table_node, 'name') else str(table_node),
                        alias=table_node.alias if hasattr(table_node, 'alias') else None
                    ),
                    condition=str(on_cond) if on_cond else None
                ))
            
            elif node_type is exp.Where:
                result.where_clause = node
            
            elif node_type is exp.Group:
                result.group_by = [str(g) for g in node.expressions]
            
            elif node_type is exp.Order:
                result.order_by = [
                    {'column': str(o.this), 
                     'direction': 'DESC' if o.args.get('desc') else 'ASC'}
                    for o in node.expressions
                ]
            
            elif node_type is exp.Limit:
                if node.expression:
                    try:
                        result.limit = int(str(node.expression))
                    except (ValueError, TypeError):
                        pass
            
            elif node_type is exp.Offset:
                if node.expression:
                    try:
                        result.offset = int(str(node.expression))
                    except (ValueError, TypeError):
                        pass
        
        # Extract conditions from where clause if present
        if result.where_clause:
            cond = BaseExtractor._extract_condition_tree(result.where_clause.this)
            if cond:
                result.conditions = [cond]
        
        return result
```

### 4. Optimized Model Construction

Updated `core.py` with optimized result building:

```python
def build_parse_result_optimized(
    original_sql: str,
    dialect: str,
    extraction: ExtractionResult,
    warnings: list,
    procedural_info: Optional[ProceduralInfo],
    preprocessed: bool
) -> dict:
    """Build parse result dictionary with optimizations.
    
    Uses shared empty collections and lazy dialect info creation.
    """
    # Convert slots objects to dicts for Pydantic
    tables = [t.to_dict() for t in extraction.tables] if extraction.tables else EMPTY_TUPLE
    columns = [c.to_dict() for c in extraction.columns] if extraction.columns else EMPTY_TUPLE
    joins = [
        {
            'type': j.type,
            'table': j.table.to_dict(),
            'condition': j.condition
        }
        for j in extraction.joins
    ] if extraction.joins else EMPTY_TUPLE
    
    # Get statement type (prefer procedural type if available)
    if procedural_info and procedural_info.type in PROCEDURAL_TYPE_MAP:
        statement_type = PROCEDURAL_TYPE_MAP[procedural_info.type]
    else:
        statement_type = extraction.statement_type
    
    # Build result with lazy dialect info
    result = {
        'sql': original_sql,
        'dialect': dialect,
        'statement_type': statement_type,
        'tables': tables,
        'columns': columns,
        'conditions': extraction.conditions or EMPTY_TUPLE,
        'joins': joins,
        'group_by': extraction.group_by or EMPTY_TUPLE,
        'order_by': extraction.order_by or EMPTY_TUPLE,
        'limit': extraction.limit,
        'offset_value': extraction.offset,
        'errors': EMPTY_TUPLE,
        'warnings': warnings or EMPTY_TUPLE,
        'success': True,
        # Lazy dialect info - only create for matching dialect
        'oracle_info': None,
        'tidb_info': None,
        'oceanbase_info': None,
        'mysql_info': None,
        'postgresql_info': None,
    }
    
    # Only create dialect-specific info for the actual dialect
    if dialect in ('oracle', 'oceanbase-oracle'):
        result['oracle_info'] = OracleExtractor.extract(
            ast, original_sql, dialect, procedural_info
        )
    elif dialect == 'tidb':
        result['tidb_info'] = TiDBExtractor.extract(
            original_sql, dialect, preprocessed, procedural_info
        )
    elif dialect.startswith('oceanbase'):
        result['oceanbase_info'] = OceanBaseExtractor.extract(
            original_sql, dialect, preprocessed, procedural_info
        )
    elif dialect == 'mysql':
        result['mysql_info'] = _build_mysql_info(dialect, preprocessed, procedural_info)
    elif dialect == 'postgresql':
        result['postgresql_info'] = _build_postgresql_info(dialect, preprocessed, procedural_info)
    
    return result
```

### 5. LRU Cache Implementation

New caching layer in `parser.py`:

```python
from functools import lru_cache
from typing import NamedTuple
import threading


class CacheStats(NamedTuple):
    """Cache statistics."""
    hits: int
    misses: int
    size: int
    maxsize: int


class SQLParser:
    """Multi-dialect SQL parser with optional caching."""
    
    def __init__(
        self,
        dialect: str = 'mysql',
        max_workers: Optional[int] = None,
        batch_size: int = BATCH_SIZE,
        cache_size: Optional[int] = None,  # None = disabled, 0 = unlimited
    ):
        # ... existing init ...
        self._cache_size = cache_size
        self._cache_hits = 0
        self._cache_misses = 0
        self._cache: dict[str, ParseResult] = {}
        self._cache_lock = threading.Lock()
        
        if cache_size is not None and cache_size > 0:
            self._cache_enabled = True
            self._cache_maxsize = cache_size
        elif cache_size == 0:
            self._cache_enabled = True
            self._cache_maxsize = float('inf')
        else:
            self._cache_enabled = False
            self._cache_maxsize = 0
    
    def parse(self, sql: str) -> ParseResult:
        """Parse single SQL with optional caching."""
        if self._cache_enabled:
            cache_key = f"{self.dialect}:{sql}"
            
            with self._cache_lock:
                if cache_key in self._cache:
                    self._cache_hits += 1
                    return self._cache[cache_key]
            
            self._cache_misses += 1
            result = parse_single_sql(sql, self.dialect)
            parse_result = ParseResult.model_construct(**result)
            
            with self._cache_lock:
                if len(self._cache) < self._cache_maxsize:
                    self._cache[cache_key] = parse_result
                elif self._cache:
                    # Simple LRU: remove oldest entry
                    oldest_key = next(iter(self._cache))
                    del self._cache[oldest_key]
                    self._cache[cache_key] = parse_result
            
            return parse_result
        
        result = parse_single_sql(sql, self.dialect)
        return ParseResult.model_construct(**result)
    
    def clear_cache(self) -> None:
        """Clear the parse result cache."""
        with self._cache_lock:
            self._cache.clear()
            self._cache_hits = 0
            self._cache_misses = 0
    
    def cache_stats(self) -> CacheStats:
        """Get cache statistics."""
        with self._cache_lock:
            return CacheStats(
                hits=self._cache_hits,
                misses=self._cache_misses,
                size=len(self._cache),
                maxsize=self._cache_maxsize if self._cache_maxsize != float('inf') else -1
            )
```

### 6. Model Construction Optimization

Updated model instantiation using `model_construct()`:

```python
# In parser.py or core.py
def create_parse_result(data: dict) -> ParseResult:
    """Create ParseResult using model_construct for performance.
    
    model_construct() bypasses Pydantic validation, which is safe
    because we control the data structure internally.
    """
    # Convert nested dicts to model instances using model_construct
    tables = [
        TableReference.model_construct(**t) 
        for t in data.get('tables', EMPTY_TUPLE)
    ]
    columns = [
        ColumnReference.model_construct(**c)
        for c in data.get('columns', EMPTY_TUPLE)
    ]
    conditions = [
        ConditionNode.model_construct(**c)
        for c in data.get('conditions', EMPTY_TUPLE)
    ]
    joins = [
        JoinInfo.model_construct(
            type=j['type'],
            table=TableReference.model_construct(**j['table']),
            condition=j.get('condition')
        )
        for j in data.get('joins', EMPTY_TUPLE)
    ]
    order_by = [
        OrderByItem.model_construct(**o)
        for o in data.get('order_by', EMPTY_TUPLE)
    ]
    errors = [
        ParseError.model_construct(**e)
        for e in data.get('errors', EMPTY_TUPLE)
    ]
    warnings = [
        ParseError.model_construct(**w)
        for w in data.get('warnings', EMPTY_TUPLE)
    ]
    
    # Create dialect-specific info if present
    oracle_info = None
    if data.get('oracle_info'):
        oracle_info = OracleSpecificInfo.model_construct(**data['oracle_info'])
    
    # ... similar for other dialect infos ...
    
    return ParseResult.model_construct(
        sql=data['sql'],
        dialect=data['dialect'],
        statement_type=data['statement_type'],
        tables=tables or EMPTY_TUPLE,
        columns=columns or EMPTY_TUPLE,
        conditions=conditions or EMPTY_TUPLE,
        joins=joins or EMPTY_TUPLE,
        group_by=data.get('group_by', EMPTY_TUPLE),
        order_by=order_by or EMPTY_TUPLE,
        limit=data.get('limit'),
        offset_value=data.get('offset_value'),
        errors=errors or EMPTY_TUPLE,
        warnings=warnings or EMPTY_TUPLE,
        success=data.get('success', True),
        oracle_info=oracle_info,
        tidb_info=tidb_info,
        oceanbase_info=oceanbase_info,
        mysql_info=mysql_info,
        postgresql_info=postgresql_info,
    )
```

## Data Models

### Cache Key Structure

```
cache_key = f"{dialect}:{sql_string}"
```

The cache key combines dialect and SQL to ensure dialect-specific parsing is respected.

### ExtractionResult Fields

| Field | Type | Description |
|-------|------|-------------|
| tables | list[TableInfo] | Extracted table references |
| columns | list[ColumnInfo] | Extracted column references |
| conditions | list[dict] | WHERE clause conditions |
| joins | list[JoinInfo] | JOIN information |
| group_by | list[str] | GROUP BY columns |
| order_by | list[dict] | ORDER BY items |
| limit | int \| None | LIMIT value |
| offset | int \| None | OFFSET value |
| where_clause | exp.Where \| None | Raw WHERE clause for condition extraction |
| statement_type | str | SQL statement type |

### CacheStats Fields

| Field | Type | Description |
|-------|------|-------------|
| hits | int | Number of cache hits |
| misses | int | Number of cache misses |
| size | int | Current cache size |
| maxsize | int | Maximum cache size (-1 for unlimited) |



## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system—essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

Based on the prework analysis, the following properties have been identified for property-based testing:

### Property 1: Parse Result Semantic Equivalence

*For any* valid SQL string and supported dialect, parsing with the optimized implementation SHALL produce a ParseResult that is semantically equivalent to the pre-optimization implementation (same tables, columns, conditions, joins, group_by, order_by, limit, offset, statement_type, and success status).

**Validates: Requirements 1.4, 5.2, 5.4**

### Property 2: Parse Result Field Completeness

*For any* valid SQL string and supported dialect, the resulting ParseResult SHALL have all required fields present with correct types (sql: str, dialect: str, statement_type: str, tables: list, columns: list, conditions: list, joins: list, group_by: list, order_by: list, limit: int|None, offset_value: int|None, errors: list, warnings: list, success: bool).

**Validates: Requirements 1.3, 2.4**

### Property 3: Dialect Info Isolation

*For any* SQL string and dialect, the ParseResult SHALL have only the dialect-specific info field for the matching dialect set to a non-None value, while all other dialect info fields (oracle_info, tidb_info, oceanbase_info, mysql_info, postgresql_info) SHALL be None.

**Validates: Requirements 3.1, 3.2, 3.3**

### Property 4: Shared Empty Collections

*For any* SQL string that results in empty tables, columns, conditions, joins, group_by, order_by, errors, or warnings, those fields SHALL reference the same shared empty collection instance (identity equality with module-level constants).

**Validates: Requirements 4.1, 4.2, 4.3**

### Property 5: Cache Hit Returns Identical Result

*For any* SQL string parsed twice with cache enabled, the second parse call SHALL return a result that is identical to the first (same object reference or equivalent content).

**Validates: Requirements 7.2**

### Property 6: Cache Hit Performance

*For any* SQL string parsed with cache enabled, the cache hit (second parse) SHALL complete in less than 10% of the time required for the initial parse (cache miss).

**Validates: Requirements 7.7**

### Property 7: Memory Reduction

*For any* batch of SQL strings, the optimized implementation SHALL use at least 30% less memory per SQL statement compared to the baseline measurement.

**Validates: Requirements 2.3, 8.2**

### Property 8: Speed Improvement

*For any* complex SQL string (with JOINs, WHERE clauses, GROUP BY, ORDER BY), the optimized implementation SHALL parse at least 20% faster than the baseline measurement.

**Validates: Requirements 5.3, 8.1**

### Property 9: Batch Throughput Maintained

*For any* batch of SQL strings, the optimized implementation SHALL achieve equal or better throughput (ops/sec) compared to the baseline implementation.

**Validates: Requirements 8.3**

## Error Handling

### Parse Errors

When SQL parsing fails:
1. The parser SHALL return a ParseResult with `success=False`
2. The `errors` list SHALL contain at least one ParseError with error details
3. All other fields SHALL be populated with safe defaults (empty collections, None values)
4. The cache SHALL NOT store failed parse results (to allow retry)

### Cache Errors

When cache operations fail:
1. The parser SHALL fall back to non-cached parsing
2. Cache errors SHALL NOT propagate to the caller
3. Cache statistics SHALL remain accurate despite errors

### Memory Pressure

When memory is constrained:
1. The LRU cache SHALL evict oldest entries to make room for new ones
2. Shared empty collections SHALL always be available (module-level constants)
3. The parser SHALL not fail due to cache memory issues

## Testing Strategy

### Dual Testing Approach

The testing strategy combines unit tests and property-based tests:

- **Unit tests**: Verify specific examples, edge cases, API compatibility, and error conditions
- **Property tests**: Verify universal properties across randomly generated inputs

### Property-Based Testing Configuration

- **Library**: `hypothesis` (Python's standard PBT library)
- **Minimum iterations**: 100 per property test
- **Tag format**: `# Feature: sql-parser-performance-optimization, Property N: {property_text}`

### Test Categories

1. **Backward Compatibility Tests** (Unit)
   - Run existing test suite
   - Verify API signatures unchanged
   - Check field structure compatibility

2. **Semantic Equivalence Tests** (Property)
   - Generate random valid SQL
   - Compare optimized vs baseline results
   - Property 1 implementation

3. **Memory Tests** (Property + Unit)
   - Measure memory per SQL statement
   - Verify shared collection usage
   - Properties 4, 7 implementation

4. **Performance Tests** (Property + Unit)
   - Benchmark parsing speed
   - Measure cache hit performance
   - Properties 6, 8, 9 implementation

5. **Cache Tests** (Property + Unit)
   - Verify cache hit behavior
   - Test cache eviction
   - Test cache statistics
   - Property 5 implementation

6. **Dialect Isolation Tests** (Property)
   - Verify only matching dialect info is set
   - Property 3 implementation

### Test File Structure

```
tests/
├── test_performance_optimization/
│   ├── __init__.py
│   ├── test_backward_compat.py      # Unit tests for API compatibility
│   ├── test_semantic_equivalence.py # Property tests for correctness
│   ├── test_memory.py               # Property tests for memory
│   ├── test_cache.py                # Property + unit tests for cache
│   └── test_performance.py          # Property tests for speed
```

### Hypothesis Strategies

```python
from hypothesis import strategies as st

# Strategy for generating valid simple SQL
simple_sql = st.sampled_from([
    "SELECT * FROM users",
    "SELECT id, name FROM products WHERE price > 100",
    "INSERT INTO logs (message) VALUES ('test')",
    "UPDATE users SET status = 'active' WHERE id = 1",
    "DELETE FROM temp_data WHERE created_at < '2024-01-01'",
])

# Strategy for generating complex SQL
complex_sql = st.sampled_from([
    """SELECT u.id, u.name, o.total 
       FROM users u 
       LEFT JOIN orders o ON u.id = o.user_id 
       WHERE u.status = 'active' 
       ORDER BY o.total DESC 
       LIMIT 10""",
    # ... more complex examples
])

# Strategy for dialects
dialect = st.sampled_from([
    'mysql', 'postgresql', 'oracle', 'tidb', 
    'oceanbase-mysql', 'oceanbase-oracle'
])
```
