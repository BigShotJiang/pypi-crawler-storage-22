# Requirements Document

## Introduction

This document specifies the requirements for optimizing the performance of the multi-dialect SQL parser library. The optimization targets memory usage reduction and parsing speed improvements while maintaining full backward compatibility with existing functionality.

## Glossary

- **SQL_Parser**: The main SQLParser class that provides parsing functionality for multiple SQL dialects
- **AST**: Abstract Syntax Tree - the tree representation of parsed SQL produced by sqlglot
- **Extractor**: Components that traverse the AST to extract specific information (tables, columns, conditions, etc.)
- **Parse_Result**: The Pydantic model containing all extracted information from a parsed SQL statement
- **LRU_Cache**: Least Recently Used cache - a caching strategy that evicts the least recently accessed items when full
- **model_construct**: Pydantic's method to create model instances without validation, bypassing field validators
- **Dialect_Info**: Dialect-specific information fields (oracle_info, tidb_info, oceanbase_info, mysql_info, postgresql_info)

## Requirements

### Requirement 1: Backward Compatibility

**User Story:** As a library user, I want all existing functionality to continue working after optimization, so that I can upgrade without breaking my application.

#### Acceptance Criteria

1. THE SQL_Parser SHALL pass all existing unit tests without modification
2. THE SQL_Parser SHALL maintain the same public API interface (SQLParser class, parse(), parse_batch(), parse_batch_all() methods)
3. THE Parse_Result SHALL maintain the same field structure and types
4. WHEN parsing any valid SQL statement, THE SQL_Parser SHALL produce semantically equivalent results to the pre-optimization version

### Requirement 2: Memory Optimization via model_construct

**User Story:** As a developer processing large batches of SQL, I want reduced memory allocation per parse result, so that I can process more SQL statements without running out of memory.

#### Acceptance Criteria

1. WHEN creating Parse_Result instances, THE SQL_Parser SHALL use Pydantic's model_construct() method instead of standard validation
2. WHEN creating nested model instances (TableReference, ColumnReference, etc.), THE SQL_Parser SHALL use model_construct() for all internal models
3. THE SQL_Parser SHALL reduce memory allocation per SQL statement by at least 30% compared to baseline
4. WHEN using model_construct(), THE SQL_Parser SHALL ensure all required fields are properly initialized

### Requirement 3: Lazy Loading of Dialect-Specific Info

**User Story:** As a developer parsing SQL for a specific dialect, I want dialect-specific info fields to only be created when needed, so that memory is not wasted on unused dialect information.

#### Acceptance Criteria

1. WHEN parsing SQL for a specific dialect, THE SQL_Parser SHALL only create the Dialect_Info object for that dialect
2. WHEN the dialect is MySQL, THE SQL_Parser SHALL set oracle_info, tidb_info, oceanbase_info, and postgresql_info to None without creating empty objects
3. WHEN the dialect is Oracle, THE SQL_Parser SHALL set mysql_info, tidb_info, oceanbase_info, and postgresql_info to None without creating empty objects
4. THE SQL_Parser SHALL reduce the number of Dialect_Info objects created by at least 60% compared to baseline

### Requirement 4: Shared Empty Collections

**User Story:** As a developer, I want the parser to reuse empty collection instances, so that memory is not wasted on duplicate empty lists and tuples.

#### Acceptance Criteria

1. WHEN a Parse_Result has no tables, THE SQL_Parser SHALL use a shared empty tuple instead of creating a new empty list
2. WHEN a Parse_Result has no columns, THE SQL_Parser SHALL use a shared empty tuple instead of creating a new empty list
3. WHEN a Parse_Result has no conditions, joins, group_by, order_by, errors, or warnings, THE SQL_Parser SHALL use shared empty tuples
4. THE SQL_Parser SHALL define shared empty collections as module-level constants

### Requirement 5: Single AST Traversal

**User Story:** As a developer parsing complex SQL, I want the parser to extract all information in a single AST traversal, so that parsing is faster.

#### Acceptance Criteria

1. WHEN extracting tables, columns, joins, and other information, THE Extractor SHALL traverse the AST only once
2. THE Extractor SHALL collect all required information (tables, columns, conditions, joins, group_by, order_by, limit, offset) during a single traversal
3. THE SQL_Parser SHALL improve parsing speed by at least 20% compared to baseline for complex SQL statements
4. WHEN using single traversal, THE Extractor SHALL produce the same results as multiple find_all() calls

### Requirement 6: Slots-Based Intermediate Results

**User Story:** As a developer, I want intermediate extraction results to use memory-efficient data structures, so that parsing uses less memory.

#### Acceptance Criteria

1. WHEN storing intermediate extraction results, THE Extractor SHALL use classes with __slots__ instead of dictionaries
2. THE Extractor SHALL define __slots__ classes for table info, column info, join info, and condition info
3. THE SQL_Parser SHALL reduce memory overhead for intermediate results by using __slots__

### Requirement 7: Optional LRU Cache for Repeated SQL

**User Story:** As a developer parsing the same SQL statements repeatedly, I want an optional caching mechanism, so that repeated parsing is faster.

#### Acceptance Criteria

1. THE SQL_Parser SHALL provide an optional LRU cache for parse results
2. WHEN cache is enabled, THE SQL_Parser SHALL return cached results for identical SQL strings
3. THE SQL_Parser SHALL allow configuring the cache size (default: 1000 entries)
4. WHEN cache is disabled (default), THE SQL_Parser SHALL not use any caching
5. THE SQL_Parser SHALL provide a method to clear the cache
6. THE SQL_Parser SHALL provide a method to get cache statistics (hits, misses, size)
7. WHEN cache is enabled and SQL is found in cache, THE SQL_Parser SHALL return results at least 10x faster than parsing

### Requirement 8: Performance Targets

**User Story:** As a library maintainer, I want measurable performance improvements, so that I can verify the optimization is effective.

#### Acceptance Criteria

1. THE SQL_Parser SHALL achieve at least 20% improvement in parsing speed (ops/sec) for single SQL parsing
2. THE SQL_Parser SHALL achieve at least 30% reduction in memory usage per SQL statement
3. THE SQL_Parser SHALL maintain or improve batch parsing throughput (ops/sec)
4. WHEN running benchmark.py, THE SQL_Parser SHALL demonstrate measurable improvements in all metrics

### Requirement 9: Python Version Compatibility

**User Story:** As a developer using Python 3.8+, I want the optimizations to work on all supported Python versions, so that I can use the library in my environment.

#### Acceptance Criteria

1. THE SQL_Parser SHALL use `from __future__ import annotations` for forward reference support
2. THE SQL_Parser SHALL be compatible with Python 3.8, 3.9, 3.10, 3.11, and 3.12
3. THE SQL_Parser SHALL not use Python features introduced after 3.8
4. IF using functools.lru_cache, THE SQL_Parser SHALL use the Python 3.8 compatible syntax
