# Implementation Plan: SQL Parser Performance Optimization

## Overview

This implementation plan breaks down the performance optimization into incremental tasks. Each task builds on previous work and includes testing to validate correctness. The implementation uses Python with the existing project structure.

## Tasks

- [ ] 1. Add shared empty collections and slots-based classes
  - [ ] 1.1 Create shared empty collection constants in models.py
    - Add module-level constants: EMPTY_TUPLE, EMPTY_TABLES, EMPTY_COLUMNS, etc.
    - Use tuples for immutability
    - _Requirements: 4.1, 4.2, 4.3, 4.4_
  
  - [ ] 1.2 Create __slots__ classes for intermediate results in extractors/base.py
    - Add TableInfo, ColumnInfo, JoinInfo classes with __slots__
    - Add ExtractionResult container class with __slots__
    - Include to_dict() methods for conversion
    - _Requirements: 6.1, 6.2_
  
  - [ ]* 1.3 Write property test for shared empty collections
    - **Property 4: Shared Empty Collections**
    - **Validates: Requirements 4.1, 4.2, 4.3**

- [ ] 2. Implement single AST traversal extractor
  - [ ] 2.1 Add extract_all() method to BaseExtractor
    - Implement single traversal using ast.walk()
    - Collect tables, columns, joins, group_by, order_by, limit, offset in one pass
    - Return ExtractionResult instance
    - _Requirements: 5.1, 5.2_
  
  - [ ] 2.2 Update core.py to use extract_all()
    - Replace multiple find_all() calls with single extract_all()
    - Convert ExtractionResult to dict format for result building
    - Maintain backward compatibility with existing result structure
    - _Requirements: 5.2, 5.4_
  
  - [ ]* 2.3 Write property test for semantic equivalence
    - **Property 1: Parse Result Semantic Equivalence**
    - **Validates: Requirements 1.4, 5.2, 5.4**

- [ ] 3. Checkpoint - Verify extraction correctness
  - Ensure all existing tests pass
  - Run benchmark.py to establish intermediate metrics
  - Ask the user if questions arise

- [ ] 4. Implement optimized model construction
  - [ ] 4.1 Create helper function for model_construct() usage
    - Add create_parse_result() function in core.py
    - Use model_construct() for ParseResult and all nested models
    - Handle nested model construction (TableReference, ColumnReference, etc.)
    - _Requirements: 2.1, 2.2, 2.4_
  
  - [ ] 4.2 Implement lazy dialect info creation
    - Only create dialect-specific info for matching dialect
    - Set non-matching dialect info fields to None
    - Update _build_mysql_info, _build_postgresql_info patterns
    - _Requirements: 3.1, 3.2, 3.3, 3.4_
  
  - [ ] 4.3 Integrate shared empty collections in result building
    - Use EMPTY_TUPLE constants for empty result fields
    - Ensure empty collections are shared instances
    - _Requirements: 4.1, 4.2, 4.3_
  
  - [ ]* 4.4 Write property test for field completeness
    - **Property 2: Parse Result Field Completeness**
    - **Validates: Requirements 1.3, 2.4**
  
  - [ ]* 4.5 Write property test for dialect info isolation
    - **Property 3: Dialect Info Isolation**
    - **Validates: Requirements 3.1, 3.2, 3.3**

- [ ] 5. Checkpoint - Verify model construction
  - Ensure all existing tests pass
  - Verify memory reduction with simple benchmark
  - Ask the user if questions arise

- [ ] 6. Implement LRU cache
  - [ ] 6.1 Add cache infrastructure to SQLParser class
    - Add cache_size parameter to __init__ (default: None = disabled)
    - Add _cache dict and _cache_lock for thread safety
    - Add _cache_hits and _cache_misses counters
    - _Requirements: 7.1, 7.3, 7.4_
  
  - [ ] 6.2 Implement cached parse() method
    - Check cache before parsing when enabled
    - Store results in cache after parsing
    - Implement simple LRU eviction when cache is full
    - _Requirements: 7.2_
  
  - [ ] 6.3 Add cache management methods
    - Implement clear_cache() method
    - Implement cache_stats() method returning CacheStats
    - Add CacheStats NamedTuple class
    - _Requirements: 7.5, 7.6_
  
  - [ ]* 6.4 Write property test for cache hit behavior
    - **Property 5: Cache Hit Returns Identical Result**
    - **Validates: Requirements 7.2**
  
  - [ ]* 6.5 Write property test for cache performance
    - **Property 6: Cache Hit Performance**
    - **Validates: Requirements 7.7**

- [ ] 7. Checkpoint - Verify cache functionality
  - Ensure all existing tests pass
  - Test cache with various SQL patterns
  - Ask the user if questions arise

- [ ] 8. Performance validation and tuning
  - [ ] 8.1 Update benchmark.py with optimization metrics
    - Add comparison mode to show before/after metrics
    - Add cache performance benchmarks
    - Add memory per-SQL measurement
    - _Requirements: 8.4_
  
  - [ ]* 8.2 Write property test for memory reduction
    - **Property 7: Memory Reduction**
    - **Validates: Requirements 2.3, 8.2**
  
  - [ ]* 8.3 Write property test for speed improvement
    - **Property 8: Speed Improvement**
    - **Validates: Requirements 5.3, 8.1**
  
  - [ ]* 8.4 Write property test for batch throughput
    - **Property 9: Batch Throughput Maintained**
    - **Validates: Requirements 8.3**

- [ ] 9. Final validation and documentation
  - [ ] 9.1 Run full test suite and verify all tests pass
    - Execute pytest with coverage
    - Verify no regressions in existing functionality
    - _Requirements: 1.1, 1.2_
  
  - [ ] 9.2 Run benchmark.py and document improvements
    - Record final performance metrics
    - Compare against baseline
    - Document achieved improvements
    - _Requirements: 8.1, 8.2, 8.3, 8.4_
  
  - [ ] 9.3 Verify Python 3.8+ compatibility
    - Ensure all code uses `from __future__ import annotations`
    - Verify no Python 3.9+ only features used
    - _Requirements: 9.1, 9.2, 9.3, 9.4_

- [ ] 10. Final checkpoint
  - Ensure all tests pass
  - Verify performance targets met (20% speed, 30% memory)
  - Ask the user if questions arise

## Notes

- Tasks marked with `*` are optional and can be skipped for faster MVP
- Each task references specific requirements for traceability
- Checkpoints ensure incremental validation
- Property tests validate universal correctness properties
- Unit tests validate specific examples and edge cases
- The implementation maintains full backward compatibility throughout
