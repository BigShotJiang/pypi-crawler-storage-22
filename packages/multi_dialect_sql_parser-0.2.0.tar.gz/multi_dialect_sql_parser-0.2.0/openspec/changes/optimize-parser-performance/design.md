## Context
SQL 解析器需要处理大量 SQL 语句，当前实现存在以下性能瓶颈：
1. 多次 AST 遍历（每种信息类型单独遍历）
2. Pydantic 模型验证开销
3. 频繁创建空列表/元组
4. 每次解析都创建方言特有信息对象

## Goals / Non-Goals
- Goals:
  - 提升解析速度 20-30%
  - 减少内存占用 30-50%
  - 保持 API 向后兼容
  - 保持代码可读性
- Non-Goals:
  - 不改变公共 API 签名
  - 不引入新的外部依赖
  - 不牺牲正确性换取性能

## Decisions

### 1. 单次 AST 遍历
**决策**: 实现 `extract_all()` 方法，一次遍历收集所有信息

**原因**: 当前 `extract_tables()`, `extract_columns()` 等方法各自遍历 AST，造成重复工作

**实现**:
```python
@staticmethod
def extract_all(ast: Any) -> Dict[str, Any]:
    """单次遍历提取所有信息"""
    tables, columns, joins = [], [], []
    where_clause = None
    group_clause = None
    order_clause = None
    limit_clause = None
    offset_clause = None
    
    for node in ast.walk():
        node_type = type(node)
        if node_type is exp.Table:
            tables.append(...)
        elif node_type is exp.Column:
            columns.append(...)
        # ... 其他类型
    
    return {
        "tables": tables,
        "columns": columns,
        ...
    }
```

### 2. Pydantic model_construct()
**决策**: 使用 `model_construct()` 跳过验证

**原因**: 内部数据已知正确，无需重复验证

**实现**:
```python
# 之前
return ParseResult(**result)

# 之后
return ParseResult.model_construct(**result)
```

### 3. 共享空集合
**决策**: 使用模块级常量共享空集合

**实现**:
```python
# 模块级常量
_EMPTY_LIST: List[Any] = []
_EMPTY_TUPLE: Tuple[Any, ...] = ()

# 使用时
return _EMPTY_LIST if not items else items
```

### 4. 延迟加载方言信息
**决策**: 仅在访问时创建方言特有信息

**原因**: 大多数使用场景不需要所有方言信息

**实现**:
```python
# 返回 None 而非空对象
oracle_info = OracleExtractor.extract(...) if dialect == "oracle" else None
```

### 5. LRU 缓存
**决策**: 可选的缓存支持，默认关闭

**实现**:
```python
class SQLParser:
    def __init__(self, ..., enable_cache: bool = False, cache_size: int = 1000):
        self._cache = {} if enable_cache else None
        self._cache_size = cache_size
```

## Risks / Trade-offs
- **风险**: `model_construct()` 跳过验证可能隐藏数据问题
  - **缓解**: 添加开发模式下的验证选项
- **风险**: 缓存可能导致内存增长
  - **缓解**: 使用 LRU 策略限制缓存大小

## Migration Plan
1. 实现优化但保持 API 不变
2. 运行完整测试套件
3. 运行性能基准测试
4. 更新文档和版本号

## Open Questions
- 是否需要添加性能监控 API？
- 缓存默认大小是否合适？
