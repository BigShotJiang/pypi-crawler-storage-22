# Change: SQL 解析器性能优化

## Why
当前解析器在批量处理时内存占用较高（每条 SQL 约 10.6 KB），解析效率有提升空间（复杂 SQL 约 656 ops/s）。通过优化 AST 遍历、Pydantic 模型构建和内存分配，可显著提升性能。

## What Changes
- 单次 AST 遍历替代多次 `find_all()` 调用（预计 20-30% 速度提升）
- 使用 `model_construct()` 跳过 Pydantic 验证（预计 30-50% 内存减少）
- 延迟加载方言特有信息（仅在需要时创建对象）
- 共享空元组/列表实例（减少对象创建）
- 可选的 LRU 缓存支持重复 SQL 解析

## Impact
- Affected specs: `sql-parser-core`
- Affected code:
  - `src/sql_parser/core.py` - 主解析逻辑
  - `src/sql_parser/extractors/base.py` - AST 提取器
  - `src/sql_parser/parser.py` - 解析器类
  - `src/sql_parser/models.py` - Pydantic 模型
