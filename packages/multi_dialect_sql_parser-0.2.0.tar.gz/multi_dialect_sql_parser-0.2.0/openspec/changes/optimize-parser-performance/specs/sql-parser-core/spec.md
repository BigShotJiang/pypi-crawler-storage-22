## MODIFIED Requirements

### Requirement: 性能要求
系统 SHALL 满足以下性能指标。

#### Scenario: 简单查询性能
- **WHEN** 解析简单 SELECT 语句
- **THEN** 解析时间 < 0.5ms（优化后）

#### Scenario: 复杂查询性能
- **WHEN** 解析复杂 SQL（多表 JOIN、子查询）
- **THEN** 解析时间 < 5ms（优化后）

#### Scenario: 批量吞吐量
- **WHEN** 4 核 CPU 多进程解析
- **THEN** 吞吐量 > 2000 条/秒（优化后）

#### Scenario: 内存控制
- **WHEN** 批量解析 10000 条 SQL
- **THEN** 峰值内存 < 300MB（优化后）

#### Scenario: 单条 SQL 内存占用
- **WHEN** 解析单条 SQL
- **THEN** 平均内存占用 < 7KB（优化后）

---

## ADDED Requirements

### Requirement: 解析缓存支持
系统 SHALL 支持可选的解析结果缓存。

#### Scenario: 启用缓存
- **WHEN** 初始化解析器时设置 enable_cache=True
- **THEN** 相同 SQL 的重复解析直接返回缓存结果

#### Scenario: 缓存大小限制
- **WHEN** 缓存条目超过 cache_size 限制
- **THEN** 使用 LRU 策略淘汰最久未使用的条目

#### Scenario: 缓存统计
- **WHEN** 调用 cache_info() 方法
- **THEN** 返回缓存命中率、条目数等统计信息

#### Scenario: 缓存清除
- **WHEN** 调用 clear_cache() 方法
- **THEN** 清空所有缓存条目

---

### Requirement: 单次 AST 遍历
系统 SHALL 使用单次 AST 遍历提取所有信息。

#### Scenario: 统一提取
- **WHEN** 解析 SQL 语句
- **THEN** 通过单次 AST 遍历提取表、列、条件、JOIN 等所有信息

#### Scenario: 性能提升
- **WHEN** 使用单次遍历替代多次遍历
- **THEN** 解析速度提升 20-30%
