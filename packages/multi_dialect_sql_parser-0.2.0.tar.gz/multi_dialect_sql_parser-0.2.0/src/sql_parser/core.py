# -*- coding: utf-8 -*-
"""SQL 解析器核心解析逻辑。"""
from __future__ import annotations

from typing import Dict, List, Optional, Any

import sqlglot
from sqlglot import exp

from sql_parser.constants import SUPPORTED_DIALECTS
from sql_parser.extractors.base import BaseExtractor
from sql_parser.extractors.oracle import OracleExtractor
from sql_parser.extractors.tidb import TiDBExtractor
from sql_parser.extractors.oceanbase import OceanBaseExtractor
from sql_parser.preprocessor import preprocess_sql, ProceduralInfo
from sql_parser.utils import get_sqlglot_dialect, extract_error_context


# 过程化类型到 statement_type 的映射
PROCEDURAL_TYPE_MAP = {
    "FUNCTION": "CREATE_FUNCTION",
    "PROCEDURE": "CREATE_PROCEDURE",
    "PACKAGE": "CREATE_PACKAGE",
    "PACKAGE_BODY": "CREATE_PACKAGE_BODY",
    "TRIGGER": "CREATE_TRIGGER",
    "ANONYMOUS_BLOCK": "ANONYMOUS_BLOCK",
}


def parse_single_sql(sql: str, dialect: str) -> Dict[str, Any]:
    """解析单条 SQL 语句。
    
    使用预处理器处理 SQLGlot 不支持的语法，然后进行解析。
    
    Args:
        sql: SQL 语句
        dialect: 数据库方言
    
    Returns:
        解析结果字典
    """
    original_sql = sql
    preprocessed = False
    warnings: List[Dict[str, Any]] = []
    procedural_info: Optional[ProceduralInfo] = None
    
    # 预处理 SQL（处理 SQLGlot 不支持的语法）
    preprocess_result = preprocess_sql(sql, dialect)
    if preprocess_result.preprocessed:
        sql = preprocess_result.sql
        preprocessed = True
        procedural_info = preprocess_result.procedural_info
        warnings.append({
            "error_type": "preprocessed",
            "message": f"SQL 经过预处理，移除了 {len(preprocess_result.modifications)} 个方言特有语法",
            "line": None,
            "column": None,
            "offset": None,
            "context": None,
        })
    
    # 局部变量缓存（减少属性查找开销）
    parse_one = sqlglot.parse_one
    
    sqlglot_dialect = get_sqlglot_dialect(dialect)
    
    try:
        ast = parse_one(sql, dialect=sqlglot_dialect)
        
        # 使用单次遍历提取所有信息
        extracted = BaseExtractor.extract_all(ast)
        tables = extracted["tables"]
        columns = extracted["columns"]
        conditions = extracted["conditions"]
        joins = extracted["joins"]
        group_by = extracted["group_by"]
        order_by = extracted["order_by"]
        limit_value = extracted["limit"]
        offset_value = extracted["offset_value"]
        
        # 获取语句类型（优先使用过程化类型）
        if procedural_info and procedural_info.type in PROCEDURAL_TYPE_MAP:
            statement_type = PROCEDURAL_TYPE_MAP[procedural_info.type]
        else:
            statement_type = BaseExtractor.get_statement_type(ast)
        
        # 提取方言特有信息（仅为当前方言创建，延迟加载）
        oracle_info = None
        tidb_info = None
        oceanbase_info = None
        mysql_info = None
        postgresql_info = None
        
        if dialect == "oracle":
            oracle_info = OracleExtractor.extract(ast, original_sql, dialect, procedural_info)
        elif dialect == "tidb":
            tidb_info = TiDBExtractor.extract(original_sql, dialect, preprocessed, procedural_info)
        elif dialect.startswith("oceanbase"):
            oceanbase_info = OceanBaseExtractor.extract(original_sql, dialect, preprocessed, procedural_info)
            # oceanbase-oracle 也需要提取 oracle_info
            if dialect == "oceanbase-oracle":
                oracle_info = OracleExtractor.extract(ast, original_sql, dialect, procedural_info)
        elif dialect == "mysql":
            mysql_info = _build_mysql_info(dialect, preprocessed, procedural_info)
        elif dialect == "postgresql":
            postgresql_info = _build_postgresql_info(dialect, preprocessed, procedural_info)
        
        return {
            "sql": original_sql,
            "dialect": dialect,
            "statement_type": statement_type,
            "tables": tables,
            "columns": columns,
            "conditions": conditions,
            "joins": joins,
            "group_by": group_by,
            "order_by": order_by,
            "limit": limit_value,
            "offset_value": offset_value,
            "errors": [],
            "warnings": warnings,
            "success": True,
            "oracle_info": oracle_info,
            "tidb_info": tidb_info,
            "oceanbase_info": oceanbase_info,
            "mysql_info": mysql_info,
            "postgresql_info": postgresql_info,
        }
        
    except Exception as e:
        # 解析失败，提取错误信息
        error_msg = str(e)
        line, column = 1, 1
        offset = 0
        
        # 尝试从异常中提取位置信息
        if hasattr(e, "line"):
            line = e.line
        if hasattr(e, "col"):
            column = e.col
        
        # 即使解析失败，也尝试使用过程化类型
        error_statement_type = "UNKNOWN"
        if procedural_info and procedural_info.type in PROCEDURAL_TYPE_MAP:
            error_statement_type = PROCEDURAL_TYPE_MAP[procedural_info.type]
        
        return {
            "sql": original_sql,
            "dialect": dialect,
            "statement_type": error_statement_type,
            "tables": [],
            "columns": [],
            "conditions": [],
            "joins": [],
            "group_by": [],
            "order_by": [],
            "limit": None,
            "offset_value": None,
            "errors": [
                {
                    "error_type": "syntax_error",
                    "message": error_msg,
                    "line": line,
                    "column": column,
                    "offset": offset,
                    "context": extract_error_context(original_sql, offset),
                }
            ],
            "warnings": warnings,
            "success": False,
            "oracle_info": OracleExtractor.extract(None, original_sql, dialect, procedural_info) if dialect in ("oracle", "oceanbase-oracle") else None,
            "tidb_info": TiDBExtractor.extract(original_sql, dialect, preprocessed, procedural_info) if dialect == "tidb" else None,
            "oceanbase_info": OceanBaseExtractor.extract(original_sql, dialect, preprocessed, procedural_info) if dialect.startswith("oceanbase") else None,
            "mysql_info": _build_mysql_info(dialect, preprocessed, procedural_info) if dialect == "mysql" else None,
            "postgresql_info": _build_postgresql_info(dialect, preprocessed, procedural_info) if dialect == "postgresql" else None,
        }


def parse_batch_chunk(sqls: List[str], dialect: str) -> List[Dict[str, Any]]:
    """解析一批 SQL 语句（在子进程中执行）。
    
    Args:
        sqls: SQL 语句列表
        dialect: 数据库方言
    
    Returns:
        解析结果列表
    """
    return [parse_single_sql(sql, dialect) for sql in sqls]


def _build_mysql_info(dialect: str, preprocessed: bool, procedural_info: Optional[ProceduralInfo]) -> Optional[Dict[str, Any]]:
    """构建 MySQL 特有信息。
    
    Args:
        dialect: 方言
        preprocessed: 是否经过预处理
        procedural_info: 过程化信息
    
    Returns:
        MySQL 特有信息字典，非 MySQL 方言返回 None
    """
    if dialect != "mysql":
        return None
    
    return {
        "procedural_info": _procedural_info_to_dict(procedural_info),
        "preprocessed": preprocessed,
    }


def _build_postgresql_info(dialect: str, preprocessed: bool, procedural_info: Optional[ProceduralInfo]) -> Optional[Dict[str, Any]]:
    """构建 PostgreSQL 特有信息。
    
    Args:
        dialect: 方言
        preprocessed: 是否经过预处理
        procedural_info: 过程化信息
    
    Returns:
        PostgreSQL 特有信息字典，非 PostgreSQL 方言返回 None
    """
    if dialect != "postgresql":
        return None
    
    return {
        "procedural_info": _procedural_info_to_dict(procedural_info),
        "preprocessed": preprocessed,
    }


def _procedural_info_to_dict(procedural_info: Optional[ProceduralInfo]) -> Optional[Dict[str, Any]]:
    """将 ProceduralInfo 转换为字典。
    
    Args:
        procedural_info: 过程化信息
    
    Returns:
        字典形式的过程化信息
    """
    if procedural_info is None:
        return None
    
    from dataclasses import asdict
    return asdict(procedural_info)
