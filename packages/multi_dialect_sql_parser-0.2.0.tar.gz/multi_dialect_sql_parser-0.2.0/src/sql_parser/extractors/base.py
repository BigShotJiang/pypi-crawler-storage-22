# -*- coding: utf-8 -*-
"""基础信息提取器。"""
from __future__ import annotations

from typing import Dict, List, Optional, Tuple, Any

from sqlglot import exp

from sql_parser.constants import STATEMENT_TYPE_MAP


# 条件类型映射表（避免多次 isinstance 调用）
_CONDITION_TYPE_MAP = {
    exp.EQ: ("comparison", "="),
    exp.NEQ: ("comparison", "!="),
    exp.GT: ("comparison", ">"),
    exp.GTE: ("comparison", ">="),
    exp.LT: ("comparison", "<"),
    exp.LTE: ("comparison", "<="),
}

# 共享空集合常量（减少对象创建）
_EMPTY_LIST: List[Any] = []
_EMPTY_TUPLE: Tuple[Any, ...] = ()

# 需要在单次遍历中收集的节点类型
_COLLECT_TYPES = frozenset({
    exp.Table, exp.Column, exp.Join, exp.Where,
    exp.Group, exp.Order, exp.Limit, exp.Offset,
})


class BaseExtractor:
    """基础 SQL 信息提取器。"""
    
    __slots__ = ()  # 无实例属性，节省内存
    
    @staticmethod
    def extract_tables(ast: Any) -> List[Dict[str, Any]]:
        """提取表引用信息。
        
        Args:
            ast: SQL AST
        
        Returns:
            表信息列表
        """
        return [
            {
                "name": t.name,
                "schema_name": t.db,
                "alias": t.alias,
                "type": "table",
            }
            for t in ast.find_all(exp.Table)
        ]
    
    @staticmethod
    def extract_columns(ast: Any) -> List[Dict[str, Any]]:
        """提取列引用信息。
        
        Args:
            ast: SQL AST
        
        Returns:
            列信息列表
        """
        return [
            {
                "name": c.name,
                "table": c.table,
                "alias": None,
            }
            for c in ast.find_all(exp.Column)
        ]
    
    @staticmethod
    def extract_conditions(where_clause: Any) -> List[Dict[str, Any]]:
        """从 WHERE 子句提取条件。
        
        Args:
            where_clause: WHERE 子句 AST 节点
        
        Returns:
            条件列表
        """
        cond = BaseExtractor._extract_condition_tree(where_clause.this)
        return [cond] if cond else []
    
    @staticmethod
    def _extract_condition_tree(node: Any) -> Optional[Dict[str, Any]]:
        """递归提取条件树。
        
        Args:
            node: AST 节点
        
        Returns:
            条件字典或 None
        """
        node_type = type(node)
        
        # 使用类型检查替代多次 isinstance
        if node_type is exp.And:
            left = BaseExtractor._extract_condition_tree(node.left)
            right = BaseExtractor._extract_condition_tree(node.right)
            children = [c for c in (left, right) if c is not None]
            return {"type": "logical", "operator": "AND", "children": children}
        
        if node_type is exp.Or:
            left = BaseExtractor._extract_condition_tree(node.left)
            right = BaseExtractor._extract_condition_tree(node.right)
            children = [c for c in (left, right) if c is not None]
            return {"type": "logical", "operator": "OR", "children": children}
        
        return BaseExtractor._extract_single_condition(node)
    
    @staticmethod
    def _extract_single_condition(node: Any) -> Optional[Dict[str, Any]]:
        """提取单个条件。
        
        Args:
            node: 条件 AST 节点
        
        Returns:
            条件字典，如果无法识别则返回 None
        """
        node_type = type(node)
        
        # 使用映射表处理常见比较操作符
        if node_type in _CONDITION_TYPE_MAP:
            cond_type, operator = _CONDITION_TYPE_MAP[node_type]
            return {"type": cond_type, "operator": operator, "column": str(node.left), "value": str(node.right)}
        
        # 处理其他条件类型
        if node_type is exp.In:
            return {"type": "in", "column": str(node.this), "value": str(node.expressions)}
        if node_type is exp.Like:
            return {"type": "like", "column": str(node.this), "value": str(node.expression)}
        if node_type is exp.Between:
            return {"type": "between", "column": str(node.this), "value": f"{node.low} AND {node.high}"}
        if node_type is exp.Is:
            return {"type": "is_null", "column": str(node.this), "value": "NULL"}
        
        return None
    
    @staticmethod
    def extract_joins(ast: Any) -> List[Dict[str, Any]]:
        """提取 JOIN 信息。
        
        Args:
            ast: SQL AST
        
        Returns:
            JOIN 信息列表
        """
        joins = []
        for j in ast.find_all(exp.Join):
            table_node = j.this
            on_cond = j.args.get("on")
            joins.append({
                "type": BaseExtractor._get_join_type(j),
                "table": {
                    "name": table_node.name if hasattr(table_node, "name") else str(table_node),
                    "alias": table_node.alias if hasattr(table_node, "alias") else None,
                },
                "condition": str(on_cond) if on_cond else None,
            })
        return joins
    
    @staticmethod
    def _get_join_type(join_node: Any) -> str:
        """获取 JOIN 类型。
        
        Args:
            join_node: JOIN AST 节点
        
        Returns:
            JOIN 类型字符串
        """
        args = join_node.args
        side = args.get("side")
        if side:
            return side  # LEFT, RIGHT, FULL
        kind = args.get("kind")
        if kind in ("CROSS", "NATURAL"):
            return kind
        return "INNER"
    
    @staticmethod
    def extract_group_by(ast: Any) -> List[str]:
        """提取 GROUP BY 信息。
        
        Args:
            ast: SQL AST
        
        Returns:
            GROUP BY 列列表
        """
        group_clause = ast.find(exp.Group)
        if group_clause:
            return [str(g) for g in group_clause.expressions]
        return []
    
    @staticmethod
    def extract_order_by(ast: Any) -> List[Dict[str, Any]]:
        """提取 ORDER BY 信息。
        
        Args:
            ast: SQL AST
        
        Returns:
            ORDER BY 项列表
        """
        order_clause = ast.find(exp.Order)
        if order_clause:
            return [
                {
                    "column": str(o.this),
                    "direction": "DESC" if o.args.get("desc") else "ASC",
                }
                for o in order_clause.expressions
            ]
        return []
    
    @staticmethod
    def extract_limit_offset(ast: Any) -> Tuple[Optional[int], Optional[int]]:
        """提取 LIMIT 和 OFFSET 值。
        
        Args:
            ast: SQL AST
        
        Returns:
            (limit, offset) 元组
        """
        limit_value = None
        offset_value = None
        
        limit_clause = ast.find(exp.Limit)
        if limit_clause and limit_clause.expression:
            try:
                limit_value = int(str(limit_clause.expression))
            except (ValueError, TypeError):
                pass
        
        offset_clause = ast.find(exp.Offset)
        if offset_clause and offset_clause.expression:
            try:
                offset_value = int(str(offset_clause.expression))
            except (ValueError, TypeError):
                pass
        
        return limit_value, offset_value
    
    @staticmethod
    def get_statement_type(ast: Any) -> str:
        """获取语句类型。
        
        Args:
            ast: SQL AST
        
        Returns:
            语句类型字符串
        """
        return STATEMENT_TYPE_MAP.get(type(ast).__name__, "OTHER")
    
    @staticmethod
    def extract_all(ast: Any) -> Dict[str, Any]:
        """单次遍历提取所有信息。
        
        通过一次 AST 遍历收集所有需要的信息，避免多次 find_all() 调用。
        
        Args:
            ast: SQL AST
        
        Returns:
            包含所有提取信息的字典
        """
        # 局部变量缓存（减少属性查找）
        Table = exp.Table
        Column = exp.Column
        Join = exp.Join
        Where = exp.Where
        Group = exp.Group
        Order = exp.Order
        Limit = exp.Limit
        Offset = exp.Offset
        
        # 收集容器
        tables: List[Dict[str, Any]] = []
        columns: List[Dict[str, Any]] = []
        joins: List[Dict[str, Any]] = []
        where_clause = None
        group_clause = None
        order_clause = None
        limit_clause = None
        offset_clause = None
        
        # 单次遍历
        for node in ast.walk():
            node_type = type(node)
            
            if node_type is Table:
                tables.append({
                    "name": node.name,
                    "schema_name": node.db,
                    "alias": node.alias,
                    "type": "table",
                })
            elif node_type is Column:
                columns.append({
                    "name": node.name,
                    "table": node.table,
                    "alias": None,
                })
            elif node_type is Join:
                table_node = node.this
                on_cond = node.args.get("on")
                joins.append({
                    "type": BaseExtractor._get_join_type(node),
                    "table": {
                        "name": table_node.name if hasattr(table_node, "name") else str(table_node),
                        "alias": table_node.alias if hasattr(table_node, "alias") else None,
                    },
                    "condition": str(on_cond) if on_cond else None,
                })
            elif node_type is Where and where_clause is None:
                where_clause = node
            elif node_type is Group and group_clause is None:
                group_clause = node
            elif node_type is Order and order_clause is None:
                order_clause = node
            elif node_type is Limit and limit_clause is None:
                limit_clause = node
            elif node_type is Offset and offset_clause is None:
                offset_clause = node
        
        # 处理条件
        conditions: List[Dict[str, Any]] = []
        if where_clause:
            cond = BaseExtractor._extract_condition_tree(where_clause.this)
            if cond:
                conditions = [cond]
        
        # 处理 GROUP BY
        group_by: List[str] = []
        if group_clause:
            group_by = [str(g) for g in group_clause.expressions]
        
        # 处理 ORDER BY
        order_by: List[Dict[str, Any]] = []
        if order_clause:
            order_by = [
                {
                    "column": str(o.this),
                    "direction": "DESC" if o.args.get("desc") else "ASC",
                }
                for o in order_clause.expressions
            ]
        
        # 处理 LIMIT/OFFSET
        limit_value = None
        offset_value = None
        if limit_clause and limit_clause.expression:
            try:
                limit_value = int(str(limit_clause.expression))
            except (ValueError, TypeError):
                pass
        if offset_clause and offset_clause.expression:
            try:
                offset_value = int(str(offset_clause.expression))
            except (ValueError, TypeError):
                pass
        
        return {
            "tables": tables or _EMPTY_LIST,
            "columns": columns or _EMPTY_LIST,
            "joins": joins or _EMPTY_LIST,
            "conditions": conditions or _EMPTY_LIST,
            "group_by": group_by or _EMPTY_LIST,
            "order_by": order_by or _EMPTY_LIST,
            "limit": limit_value,
            "offset_value": offset_value,
        }
