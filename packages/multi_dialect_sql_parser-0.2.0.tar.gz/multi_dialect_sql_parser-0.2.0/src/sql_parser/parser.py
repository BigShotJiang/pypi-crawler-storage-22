# -*- coding: utf-8 -*-
"""SQL 解析器主类。"""
from __future__ import annotations

from collections import OrderedDict
from concurrent.futures import ProcessPoolExecutor, as_completed
from typing import Iterator, List, Optional, Dict, Any, NamedTuple

from sql_parser.constants import (
    SUPPORTED_DIALECTS,
    MAX_WORKERS,
    BATCH_SIZE,
    MAX_TASKS_PER_CHILD,
)
from sql_parser.core import parse_single_sql, parse_batch_chunk
from sql_parser.models import (
    ParseResult, BatchParseResult, TableReference, ColumnReference,
    ConditionNode, JoinInfo, OrderByItem, ParseError,
    OracleSpecificInfo, TiDBSpecificInfo, OceanBaseSpecificInfo,
    MySQLSpecificInfo, PostgreSQLSpecificInfo,
    TiDBHint, OceanBaseHint,
)

# 开发模式标志（设为 True 启用 Pydantic 验证）
_VALIDATE_MODE = False


class CacheInfo(NamedTuple):
    """缓存统计信息。"""
    hits: int  # 命中次数
    misses: int  # 未命中次数
    size: int  # 当前缓存大小
    maxsize: int  # 最大缓存大小


def _construct_parse_result(data: Dict[str, Any]) -> ParseResult:
    """使用 model_construct 快速构建 ParseResult，跳过验证。
    
    Args:
        data: 解析结果字典
    
    Returns:
        ParseResult 实例
    """
    # 开发模式下使用完整验证
    if _VALIDATE_MODE:
        return ParseResult(**data)
    # 构建嵌套模型（使用 model_construct 跳过验证）
    tables = [TableReference.model_construct(**t) for t in data.get("tables", [])]
    columns = [ColumnReference.model_construct(**c) for c in data.get("columns", [])]
    joins = [
        JoinInfo.model_construct(
            type=j["type"],
            table=TableReference.model_construct(**j["table"]),
            condition=j.get("condition"),
        )
        for j in data.get("joins", [])
    ]
    order_by = [OrderByItem.model_construct(**o) for o in data.get("order_by", [])]
    errors = [ParseError.model_construct(**e) for e in data.get("errors", [])]
    warnings = [ParseError.model_construct(**w) for w in data.get("warnings", [])]
    
    # 构建条件树（递归）
    conditions = [_construct_condition(c) for c in data.get("conditions", [])]
    
    # 构建方言特有信息
    oracle_info = None
    if data.get("oracle_info"):
        oracle_info = OracleSpecificInfo.model_construct(**data["oracle_info"])
    
    tidb_info = None
    if data.get("tidb_info"):
        tidb_data = data["tidb_info"]
        hints = [TiDBHint.model_construct(**h) for h in tidb_data.get("hints", [])]
        tidb_info = TiDBSpecificInfo.model_construct(
            hints=hints,
            auto_random_columns=tidb_data.get("auto_random_columns", []),
            preprocessed=tidb_data.get("preprocessed", False),
            procedural_info=tidb_data.get("procedural_info"),
        )
    
    oceanbase_info = None
    if data.get("oceanbase_info"):
        ob_data = data["oceanbase_info"]
        hints = [OceanBaseHint.model_construct(**h) for h in ob_data.get("hints", [])]
        oceanbase_info = OceanBaseSpecificInfo.model_construct(
            mode=ob_data.get("mode", "mysql"),
            hints=hints,
            preprocessed=ob_data.get("preprocessed", False),
            procedural_info=ob_data.get("procedural_info"),
        )
    
    mysql_info = None
    if data.get("mysql_info"):
        mysql_info = MySQLSpecificInfo.model_construct(**data["mysql_info"])
    
    postgresql_info = None
    if data.get("postgresql_info"):
        postgresql_info = PostgreSQLSpecificInfo.model_construct(**data["postgresql_info"])
    
    return ParseResult.model_construct(
        sql=data["sql"],
        dialect=data["dialect"],
        statement_type=data["statement_type"],
        tables=tables,
        columns=columns,
        conditions=conditions,
        joins=joins,
        group_by=data.get("group_by", []),
        order_by=order_by,
        limit=data.get("limit"),
        offset_value=data.get("offset_value"),
        errors=errors,
        warnings=warnings,
        success=data.get("success", True),
        oracle_info=oracle_info,
        tidb_info=tidb_info,
        oceanbase_info=oceanbase_info,
        mysql_info=mysql_info,
        postgresql_info=postgresql_info,
    )


def _construct_condition(data: Dict[str, Any]) -> ConditionNode:
    """递归构建条件节点。"""
    children = None
    if data.get("children"):
        children = [_construct_condition(c) for c in data["children"]]
    
    return ConditionNode.model_construct(
        type=data["type"],
        operator=data.get("operator"),
        column=data.get("column"),
        value=data.get("value"),
        children=children,
    )


class SQLParser:
    """多方言 SQL 解析器，支持批量处理。
    
    支持的方言：MySQL、PostgreSQL、Oracle、TiDB、OceanBase
    
    特性：
    - 多进程批量解析
    - 流式返回结果
    - 自动内存管理
    - 预处理 SQLGlot 不支持的语法
    - 可选的 LRU 缓存支持
    
    示例：
        >>> parser = SQLParser(dialect="mysql")
        >>> result = parser.parse("SELECT * FROM users WHERE id = 1")
        >>> print(result.tables)
        
        >>> # 启用缓存
        >>> parser = SQLParser(dialect="mysql", enable_cache=True, cache_size=1000)
        >>> result1 = parser.parse("SELECT * FROM users")  # 解析
        >>> result2 = parser.parse("SELECT * FROM users")  # 缓存命中
        >>> print(parser.cache_info())  # CacheInfo(hits=1, misses=1, size=1, maxsize=1000)
    """
    
    def __init__(
        self,
        dialect: str = "mysql",
        max_workers: Optional[int] = None,
        batch_size: int = BATCH_SIZE,
        enable_cache: bool = False,
        cache_size: int = 1000,
    ):
        """初始化解析器。
        
        Args:
            dialect: 数据库方言，支持 mysql/postgresql/oracle/tidb/oceanbase-mysql/oceanbase-oracle
            max_workers: 最大进程数，默认基于 CPU 核心数
            batch_size: 批量处理时每批的大小
            enable_cache: 是否启用解析结果缓存
            cache_size: 缓存最大条目数（LRU 策略）
        
        Raises:
            ValueError: 如果指定了不支持的方言
        """
        if dialect not in SUPPORTED_DIALECTS:
            raise ValueError(
                f"不支持的方言: {dialect}。"
                f"支持的方言: {', '.join(sorted(SUPPORTED_DIALECTS))}"
            )
        self.dialect = dialect
        self.max_workers = max_workers or MAX_WORKERS
        self.batch_size = batch_size
        
        # 缓存相关
        self._enable_cache = enable_cache
        self._cache_size = cache_size
        self._cache: Optional[OrderedDict[str, ParseResult]] = OrderedDict() if enable_cache else None
        self._cache_hits = 0
        self._cache_misses = 0
    
    def parse(self, sql: str) -> ParseResult:
        """解析单条 SQL 语句。
        
        Args:
            sql: SQL 语句
        
        Returns:
            解析结果
        """
        # 检查缓存
        if self._cache is not None:
            if sql in self._cache:
                self._cache_hits += 1
                # 移动到末尾（LRU）
                self._cache.move_to_end(sql)
                return self._cache[sql]
            self._cache_misses += 1
        
        # 解析
        result_dict = parse_single_sql(sql, self.dialect)
        result = _construct_parse_result(result_dict)
        
        # 存入缓存
        if self._cache is not None:
            self._cache[sql] = result
            # LRU 淘汰
            while len(self._cache) > self._cache_size:
                self._cache.popitem(last=False)
        
        return result
    
    def cache_info(self) -> Optional[CacheInfo]:
        """获取缓存统计信息。
        
        Returns:
            缓存统计信息，如果未启用缓存则返回 None
        """
        if self._cache is None:
            return None
        return CacheInfo(
            hits=self._cache_hits,
            misses=self._cache_misses,
            size=len(self._cache),
            maxsize=self._cache_size,
        )
    
    def clear_cache(self) -> None:
        """清空缓存。"""
        if self._cache is not None:
            self._cache.clear()
            self._cache_hits = 0
            self._cache_misses = 0
    
    def parse_batch(self, sqls: List[str]) -> Iterator[ParseResult]:
        """批量解析 SQL 语句，使用多进程。
        
        使用生成器流式返回结果，避免内存累积。
        
        Args:
            sqls: SQL 语句列表
        
        Yields:
            每条 SQL 的解析结果
        """
        if not sqls:
            return
        
        # 小批量直接单进程处理
        if len(sqls) <= self.batch_size:
            for sql in sqls:
                yield self.parse(sql)
            return
        
        # 分批
        batches = [
            sqls[i : i + self.batch_size]
            for i in range(0, len(sqls), self.batch_size)
        ]
        
        # 多进程执行
        with ProcessPoolExecutor(
            max_workers=self.max_workers,
        ) as executor:
            futures = {
                executor.submit(parse_batch_chunk, batch, self.dialect): i
                for i, batch in enumerate(batches)
            }
            
            for future in as_completed(futures):
                batch_results = future.result()
                for result in batch_results:
                    yield _construct_parse_result(result)
                # 显式清理，帮助 GC
                del batch_results
    
    def parse_batch_all(self, sqls: List[str]) -> BatchParseResult:
        """批量解析 SQL 语句，返回汇总结果。
        
        Args:
            sqls: SQL 语句列表
        
        Returns:
            批量解析结果，包含所有结果和统计信息
        """
        results = list(self.parse_batch(sqls))
        successful = sum(1 for r in results if r.success)
        
        return BatchParseResult(
            results=results,
            total_statements=len(results),
            successful=successful,
            failed=len(results) - successful,
        )
