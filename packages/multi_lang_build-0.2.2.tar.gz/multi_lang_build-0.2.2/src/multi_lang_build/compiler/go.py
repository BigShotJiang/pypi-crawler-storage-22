"""Go compiler with mirror acceleration support."""

from pathlib import Path
from typing import Final, Literal
import shutil
import subprocess
import os
import tempfile

from multi_lang_build.compiler.base import CompilerBase, BuildResult, CompilerInfo
from multi_lang_build.mirror.config import (
    get_mirror_config, 
    apply_mirror_environment,
    GO_PROXY_GOPROXY_CN,
    GO_PROXY_GOPROXY_IO,
    GO_PROXY_GOVIP_CN,
    DEFAULT_GO_MIRROR,
)


class GoCompiler(CompilerBase):
    """Compiler for Go projects with module support."""
    
    NAME: Final[str] = "go"
    DEFAULT_MIRROR: Final[str] = DEFAULT_GO_MIRROR
    
    def __init__(
        self, 
        go_path: str | None = None,
        mirror: str | None = None,
    ) -> None:
        """Initialize the Go compiler.
        
        Args:
            go_path: Optional path to go executable. If None, uses system PATH.
            mirror: Mirror configuration name (e.g., "go", "go_qiniu", "go_vip").
                    Defaults to DEFAULT_GO_MIRROR (goproxy.cn).
        """
        self._go_path = go_path
        self._mirror = mirror
        self._version_cache: str | None = None
    
    @property
    def name(self) -> str:
        """Get the compiler name."""
        return self.NAME
    
    @property
    def version(self) -> str:
        """Get the Go version."""
        if self._version_cache:
            return self._version_cache
        
        go_executable = self._get_executable_path()
        
        try:
            result = subprocess.run(
                [go_executable, "version"],
                capture_output=True,
                text=True,
                timeout=10,
            )
            output = result.stdout.strip()
            if output:
                parts = output.split()
                if len(parts) >= 3:
                    self._version_cache = parts[2]
                else:
                    self._version_cache = output
            else:
                self._version_cache = "unknown"
        except Exception:
            self._version_cache = "unknown"
        
        return self._version_cache
    
    @property
    def supported_mirrors(self) -> list[str]:
        """Get list of supported mirror configurations."""
        return ["go", "go_qiniu", "go_vip"]
    
    @property
    def current_mirror(self) -> str:
        """Get the current mirror configuration name."""
        return self._mirror or "go"
    
    def get_info(self) -> CompilerInfo:
        """Get compiler information."""
        return {
            "name": self.name,
            "version": self.version,
            "supported_mirrors": self.supported_mirrors,
            "default_mirror": self.DEFAULT_MIRROR,
            "executable": self._get_executable_path(),
        }
    
    def set_mirror(self, mirror: str) -> None:
        """Set the mirror configuration.
        
        Args:
            mirror: Mirror configuration name (e.g., "go", "go_qiniu", "go_vip")
        """
        self._mirror = mirror
    
    def build(
        self,
        source_dir: Path,
        output_dir: Path,
        *,
        environment: dict[str, str] | None = None,
        mirror_enabled: bool = True,
        extra_args: list[str] | None = None,
    ) -> BuildResult:
        """Execute the Go build process.
        
        Args:
            source_dir: Source code directory
            output_dir: Build output directory (for binary)
            environment: Additional environment variables
            mirror_enabled: Whether to use Go proxy mirror
            extra_args: Additional arguments to pass to go build
            
        Returns:
            BuildResult containing success status and output information.
        """
        go_executable = self._get_executable_path()
        
        # Validate directories
        source_dir = self._validate_directory(source_dir, create_if_not_exists=False)
        output_dir = self._validate_directory(output_dir, create_if_not_exists=True)
        
        # Prepare environment
        env = environment.copy() if environment else {}
        
        if mirror_enabled:
            mirror_key = self._mirror or "go"
            env = apply_mirror_environment(mirror_key, env)
        
        # Check for go.mod
        go_mod = source_dir / "go.mod"
        has_go_mod = go_mod.exists()
        
        # Download dependencies if go.mod exists
        if has_go_mod:
            deps_result = self._run_build(
                [go_executable, "mod", "download"],
                source_dir,
                output_dir,
                environment=env,
            )
            
            if not deps_result["success"]:
                return deps_result
        
        # Build the project
        build_args = [go_executable, "build", "-o", str(output_dir)]
        
        if extra_args:
            build_args.extend(extra_args)
        
        return self._run_build(
            build_args,
            source_dir,
            output_dir,
            environment=env,
        )
    
    def build_binary(
        self,
        source_dir: Path,
        output_path: Path,
        *,
        target: str | Path | None = None,
        environment: dict[str, str] | None = None,
        mirror_enabled: bool = True,
        ldflags: str | None = None,
        tags: list[str] | None = None,
    ) -> BuildResult:
        """Build a specific Go binary.
        
        Args:
            source_dir: Source code directory (working directory for build)
            output_path: Output path for the binary
            target: Build target - can be a .go file (e.g., "server.go", "cmd/server/main.go")
                   or a directory (e.g., "./cmd/server"). If None, builds current directory.
            environment: Additional environment variables
            mirror_enabled: Whether to use Go proxy mirror
            ldflags: Linker flags to pass to the compiler
            tags: Build tags to pass to the compiler
            
        Returns:
            BuildResult containing success status and output information.
        """
        go_executable = self._get_executable_path()
        
        source_dir = self._validate_directory(source_dir, create_if_not_exists=False)
        
        # Ensure output directory exists
        output_path.parent.mkdir(parents=True, exist_ok=True)
        
        env = environment.copy() if environment else {}
        
        if mirror_enabled:
            mirror_key = self._mirror or "go"
            env = apply_mirror_environment(mirror_key, env)
        
        build_args = [go_executable, "build", "-o", str(output_path)]
        
        if ldflags:
            build_args.extend(["-ldflags", ldflags])
        
        if tags:
            build_args.extend(["-tags", ",".join(tags)])
        
        # Add target if specified (target is relative to source_dir)
        if target:
            build_args.append(str(target))
        
        return self._run_build(
            build_args,
            source_dir,
            output_path.parent,
            environment=env,
        )
    
    def build_all(
        self,
        source_dir: Path,
        output_dir: Path,
        *,
        environment: dict[str, str] | None = None,
        mirror_enabled: bool = True,
        platform: str | None = None,
    ) -> BuildResult:
        """Build all binaries defined in a Makefile or build script.
        
        Args:
            source_dir: Source code directory
            output_dir: Output directory for all binaries
            environment: Additional environment variables
            mirror_enabled: Whether to use Go proxy mirror
            platform: Target platform (e.g., "linux/amd64", "windows/amd64")
            
        Returns:
            BuildResult containing success status and output information.
        """
        go_executable = self._get_executable_path()
        
        source_dir = self._validate_directory(source_dir, create_if_not_exists=False)
        output_dir = self._validate_directory(output_dir, create_if_not_exists=True)
        
        env = environment.copy() if environment else {}
        
        if mirror_enabled:
            mirror_key = self._mirror or "go"
            env = apply_mirror_environment(mirror_key, env)
        
        build_args = [go_executable, "build", "-o", str(output_dir), "./..."]
        
        if platform:
            env["GOOS"], env["GOARCH"] = platform.split("/")
        
        return self._run_build(
            build_args,
            source_dir,
            output_dir,
            environment=env,
        )
    
    def run_tests(
        self,
        source_dir: Path,
        *,
        environment: dict[str, str] | None = None,
        mirror_enabled: bool = True,
        verbose: bool = True,
        race: bool = False,
    ) -> BuildResult:
        """Run Go tests.
        
        Args:
            source_dir: Source code directory
            environment: Additional environment variables
            mirror_enabled: Whether to use Go proxy mirror
            verbose: Enable verbose test output
            race: Enable race detector
            
        Returns:
            BuildResult containing success status and output information.
        """
        go_executable = self._get_executable_path()
        
        source_dir = self._validate_directory(source_dir, create_if_not_exists=False)
        
        env = environment.copy() if environment else {}
        
        if mirror_enabled:
            mirror_key = self._mirror or "go"
            env = apply_mirror_environment(mirror_key, env)
        
        test_args = [go_executable, "test"]
        
        if verbose:
            test_args.append("-v")
        
        if race:
            test_args.append("-race")
        
        return self._run_build(
            test_args,
            source_dir,
            source_dir,
            environment=env,
        )
    
    def tidy_modules(
        self,
        source_dir: Path,
        *,
        environment: dict[str, str] | None = None,
        mirror_enabled: bool = True,
    ) -> BuildResult:
        """Run go mod tidy to clean up dependencies.
        
        Args:
            source_dir: Source code directory
            environment: Additional environment variables
            mirror_enabled: Whether to use Go proxy mirror
            
        Returns:
            BuildResult containing success status and output information.
        """
        go_executable = self._get_executable_path()
        
        source_dir = self._validate_directory(source_dir, create_if_not_exists=False)
        
        env = environment.copy() if environment else {}
        
        if mirror_enabled:
            mirror_key = self._mirror or "go"
            env = apply_mirror_environment(mirror_key, env)
        
        return self._run_build(
            [go_executable, "mod", "tidy"],
            source_dir,
            source_dir,
            environment=env,
        )
    
    def clean(self, directory: Path) -> bool:
        """Clean Go build artifacts in the specified directory.
        
        Args:
            directory: Directory to clean
            
        Returns:
            True if successful, False otherwise.
        """
        import shutil
        
        try:
            directory = self._validate_directory(directory, create_if_not_exists=False)
            
            # Remove go.sum
            go_sum = directory / "go.sum"
            if go_sum.exists():
                go_sum.unlink()
            
            # Remove vendor directory
            vendor = directory / "vendor"
            if vendor.exists():
                shutil.rmtree(vendor)
            
            # Remove bin directory
            bin_dir = directory / "bin"
            if bin_dir.exists():
                shutil.rmtree(bin_dir)
            
            return True
            
        except Exception:
            return False
    
    def _get_executable_path(self) -> str:
        """Get the go executable path."""
        if self._go_path:
            return self._go_path
        
        go_path = shutil.which("go")
        if go_path is None:
            raise RuntimeError("go not found in PATH. Please install Go or provide go_path.")
        
        return go_path
    
    @staticmethod
    def create(source_dir: Path, *, mirror_enabled: bool = True) -> "GoCompiler":
        """Factory method to create a GoCompiler instance.
        
        Args:
            source_dir: Source directory for the project
            mirror_enabled: Whether to enable mirror acceleration by default
            
        Returns:
            Configured GoCompiler instance
        """
        compiler = GoCompiler()
        return compiler


def main() -> None:
    """Go compiler CLI entry point."""
    import argparse
    import sys
    
    parser = argparse.ArgumentParser(description="Go Build Compiler")
    parser.add_argument("source_dir", type=Path, help="Source directory (working directory)")
    parser.add_argument("-o", "--output", type=Path, required=True, help="Output binary path")
    parser.add_argument("-t", "--target", type=str, help="Build target: .go file (e.g., server.go, cmd/main.go) or directory (e.g., ./cmd/server)")
    parser.add_argument("--mirror", action="store_true", default=True, help="Enable Go proxy mirror")
    parser.add_argument("--no-mirror", dest="mirror", action="store_false", help="Disable Go proxy mirror")
    parser.add_argument("--ldflags", type=str, help="Linker flags")
    parser.add_argument("--tags", type=str, help="Build tags (comma-separated)")
    parser.add_argument("--test", action="store_true", help="Run tests instead of building")
    parser.add_argument("--tidy", action="store_true", help="Run go mod tidy")
    parser.add_argument("--all", action="store_true", help="Build all packages")
    
    args = parser.parse_args()
    
    compiler = GoCompiler()
    
    if args.test:
        result = compiler.run_tests(args.source_dir, mirror_enabled=args.mirror)
    elif args.tidy:
        result = compiler.tidy_modules(args.source_dir, mirror_enabled=args.mirror)
    elif args.all:
        result = compiler.build_all(
            args.source_dir,
            args.output,
            mirror_enabled=args.mirror,
        )
    else:
        tags = args.tags.split(",") if args.tags else None
        result = compiler.build_binary(
            args.source_dir,
            args.output,
            target=args.target,
            mirror_enabled=args.mirror,
            ldflags=args.ldflags,
            tags=tags,
        )
    
    sys.exit(0 if result["success"] else 1)
