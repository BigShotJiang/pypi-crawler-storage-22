"""Type definitions for auto-build project."""

from typing import TypeAlias, TypedDict, NotRequired, Literal
from pathlib import Path


class BuildConfig(TypedDict, total=False):
    """Build configuration for compiler."""
    source_dir: Path
    output_dir: Path
    environment: dict[str, str]
    mirror_enabled: bool
    mirror_region: Literal["china", "global"]
    extra_args: list[str]


class BuildResult(TypedDict):
    """Result of a build operation."""
    success: bool
    return_code: int
    stdout: str
    stderr: str
    output_path: Path | None
    duration_seconds: float


class MirrorConfig(TypedDict, total=False):
    """Mirror configuration for package managers."""
    name: str
    url: str
    environment_prefix: str
    environment_variables: dict[str, str]


LanguageType: TypeAlias = Literal["pnpm", "npm", "yarn", "go", "python", "pip", "poetry"]


class CompilerInfo(TypedDict):
    """Information about a compiler."""
    name: str
    version: str
    supported_mirrors: list[str]
    default_mirror: str
