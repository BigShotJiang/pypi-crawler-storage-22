# 🚀 AutoBuild

<p align="center">
  <strong>多语言自动化构建工具</strong><br>
  支持前端 pnpm、后端 Go、Python，一键加速国内镜像
</p>

<p align="center">
  <a href="https://pypi.org/project/multi-lang-build/">
    <img src="https://img.shields.io/pypi/v/multi-lang-build.svg" alt="PyPI version">
  </a>
  <a href="https://pypi.org/project/multi-lang-build/">
    <img src="https://img.shields.io/pypi/pyversions/multi-lang-build.svg" alt="Python versions">
  </a>
  <a href="https://github.com/yourusername/multi-lang-build/blob/main/LICENSE">
    <img src="https://img.shields.io/badge/license-MIT-blue.svg" alt="License">
  </a>
  <a href="https://github.com/yourusername/multi-lang-build/actions">
    <img src="https://img.shields.io/badge/build-passing-brightgreen.svg" alt="Build Status">
  </a>
</p>

<p align="center">
  <a href="#特性">特性</a> •
  <a href="#快速开始">快速开始</a> •
  <a href="#ide-集成">IDE 集成</a> •
  <a href="#安装">安装</a> •
  <a href="#详细文档">详细文档</a> •
  <a href="#许可证">许可证</a>
</p>

---

## ✨ 特性

<table>
<tr>
<td width="33%" valign="top">

### 🎯 多语言支持
- **Go** - 支持多入口编译、交叉编译
- **Python** - 自动检测 Poetry/Setuptools/PDM
- **PNPM** - 自动检测项目根目录

</td>
<td width="33%" valign="top">

### ⚡ 镜像加速
- 自动配置国内镜像源
- 提升依赖下载速度
- 支持切换多种镜像

</td>
<td width="33%" valign="top">

### 🔧 开发者友好
- 完整的类型注解
- 统一的 API 接口
- CLI 命令行支持

</td>
</tr>
</table>

## 🚀 快速开始

### 安装

```bash
pip install multi-lang-build

# 升级到最新版本
pip install --upgrade multi-lang-build

# 配置国内镜像（可选）
multi-lang-build mirror set pip          # pip 使用清华镜像
multi-lang-build mirror set go           # Go 使用 goproxy.cn
multi-lang-build mirror set npm          # npm/pnpm 使用 npmmirror
```

### 1. 构建 Go 项目（支持多入口）

```python
from multi_lang_build import GoCompiler
from pathlib import Path

compiler = GoCompiler()

# 指定入口文件编译（同一目录多 main 文件）
compiler.build_binary(
    source_dir=Path("./myproject"),
    output_path=Path("./bin/server"),
    target="server.go",  # 🎯 指定入口文件
    mirror_enabled=True
)

# 指定子目录编译（cmd 结构）
compiler.build_binary(
    source_dir=Path("./myproject"),
    output_path=Path("./bin/client"),
    target="./cmd/client",  # 📁 指定包路径
    mirror_enabled=True
)
```

### 2. 构建 Python 项目

```python
from multi_lang_build import PythonCompiler

compiler = PythonCompiler()

# 自动检测并安装依赖（支持 Poetry/Setuptools/PDM）
compiler.install_dependencies(
    source_dir=Path("./myproject"),
    mirror_enabled=True,
    dev=True
)

# 构建项目
compiler.build(
    source_dir=Path("./myproject"),
    output_dir=Path("./dist"),
    mirror_enabled=True
)
```

### 3. 构建前端项目

```python
from multi_lang_build import PnpmCompiler

compiler = PnpmCompiler()

# 自动检测项目根目录（支持子目录调用）
compiler.build(
    source_dir=Path("./packages/ui/src"),  # 即使在子目录也能正确构建
    output_dir=Path("./dist"),
    mirror_enabled=True
)
```

## 🎯 IDE 集成

将 multi-lang-build 注册为 IDE 技能，获得更智能的构建体验。

### 支持的 IDE

| IDE | 命令 | 说明 |
|-----|------|------|
| 🤖 **Claude Code** | `multi-lang-build register` | 默认，AI 助手原生支持 |
| 💠 **OpenCode** | `multi-lang-build register opencode` | 智能代码助手集成 |
| 🔷 **Trae** | `multi-lang-build register trae` | 字节跳动 AI IDE |
| 🎯 **CodeBuddy** | `multi-lang-build register codebuddy` | 代码伙伴插件 |

### 注册 Claude Code（默认）

```bash
# 默认注册到项目级（.claude/multi-lang-build.md）
multi-lang-build register

# 或使用完整命令
multi-lang-build register claude

# 注册到全局配置
multi-lang-build register claude --global
```

### 注册其他 IDE

```bash
# 注册到 OpenCode
multi-lang-build register opencode

# 注册到 Trae
multi-lang-build register trae

# 注册到 CodeBuddy
multi-lang-build register codebuddy
```

### 注册功能说明

注册命令会将 skill 配置添加到指定 IDE 的配置目录：

| IDE | 命令 | 项目级配置 | 全局配置 |
|-----|------|-----------|---------|
| 🤖 **Claude Code** | `multi-lang-build register` | `.claude/multi-lang-build.md` | `~/.claude/CLAUDE.md` |
| 💠 **OpenCode** | `multi-lang-build register opencode` | `.opencode/skills.json` | `~/.config/opencode/skills.json` |
| 🔷 **Trae** | `multi-lang-build register trae` | `.trae/skills.json` | `~/.trae/skills.json` |
| 🎯 **CodeBuddy** | `multi-lang-build register codebuddy` | `.codebuddy/skills.yaml` | `~/.codebuddy/skills.yaml` |

注册后，IDE 将自动识别项目类型并提供智能构建建议。

## 📦 安装

### 使用 pip 安装

```bash
# 基础安装
pip install multi-lang-build

# 开发环境（包含测试工具）
pip install multi-lang-build[dev]
```

### 系统要求

- Python 3.11+
- 对应语言的构建工具：
  - **Go**: `go` 命令
  - **Python**: `python3` 和 `pip`
  - **PNPM**: `pnpm` 和 `node`

## 📚 详细文档

| 语言 | 文档 | 说明 |
|------|------|------|
| 🐹 **Go** | [go.md](go.md) | 多入口编译、交叉编译、target 参数详解 |
| 🐍 **Python** | [python.md](python.md) | 依赖管理、虚拟环境、构建系统检测 |
| 📦 **PNPM** | [pnpm.md](pnpm.md) | 项目根目录检测、Monorepo 支持、镜像配置 |

## 🛠️ CLI 命令行

```bash
# Go 项目构建（默认实时输出日志）
go-build ./myproject --output ./bin/app --target server.go --mirror

# 禁用实时输出
go-build ./myproject --output ./bin/app --no-stream

# Python 项目构建
python-build ./myproject --output ./dist --mirror

# PNPM 项目构建
pnpm-build ./myproject --output ./dist --mirror

# 注册到 IDE（默认 Claude Code）
multi-lang-build register

# 注册到指定 IDE
multi-lang-build register opencode
multi-lang-build register trae
multi-lang-build register codebuddy

# 镜像配置
multi-lang-build mirror list              # 列出可用镜像
multi-lang-build mirror set pip           # 配置 pip 镜像
multi-lang-build mirror set go            # 配置 Go 代理
multi-lang-build mirror show              # 查看当前配置
```

## 🌟 核心特性对比

<table>
<thead>
<tr>
<th>特性</th>
<th>GoCompiler</th>
<th>PythonCompiler</th>
<th>PnpmCompiler</th>
</tr>
</thead>
<tbody>
<tr>
<td>自动检测项目</td>
<td>✅ go.mod</td>
<td>✅ pyproject.toml/setup.py</td>
<td>✅ package.json</td>
</tr>
<tr>
<td>多入口支持</td>
<td>✅ <code>target</code> 参数</td>
<td>❌</td>
<td>✅ 自动检测</td>
</tr>
<tr>
<td>镜像加速</td>
<td>✅ goproxy.cn</td>
<td>✅ 清华/阿里云等</td>
<td>✅ npmmirror</td>
</tr>
<tr>
<td>CLI 支持</td>
<td>✅ go-build</td>
<td>✅ python-build</td>
<td>✅ pnpm-build</td>
</tr>
<tr>
<td>类型安全</td>
<td>✅ Type Hints</td>
<td>✅ Type Hints</td>
<td>✅ Type Hints</td>
</tr>
</tbody>
</table>

## 📝 示例项目

### Go 多入口项目

```
myproject/
├── go.mod
├── server.go          # package main - API 服务
├── client.go          # package main - CLI 工具
└── worker.go          # package main - 后台任务
```

```python
# 构建所有入口
compiler = GoCompiler()

entries = ["server.go", "client.go", "worker.go"]
for entry in entries:
    name = entry.replace(".go", "")
    compiler.build_binary(
        source_dir=Path("./myproject"),
        output_path=Path(f"./bin/{name}"),
        target=entry
    )
```

### Python Poetry 项目

```
myproject/
├── pyproject.toml     # Poetry 配置
├── poetry.lock
└── src/
    └── mypackage/
```

```python
# 一键安装依赖并构建
compiler = PythonCompiler()
compiler.install_dependencies(source_dir=Path("./myproject"), dev=True)
compiler.build(source_dir=Path("./myproject"), output_dir=Path("./dist"))
```

### 前端 Monorepo

```
monorepo/
├── package.json
├── pnpm-workspace.yaml
└── packages/
    ├── ui/
    ├── utils/
    └── app/
```

```python
# 批量构建所有包
compiler = PnpmCompiler()

for pkg in ["ui", "utils", "app"]:
    compiler.build(
        source_dir=Path(f"./packages/{pkg}"),
        output_dir=Path(f"./packages/{pkg}/dist")
    )
```

## 🤝 贡献

欢迎提交 Issue 和 Pull Request！

## 📄 许可证

[MIT](LICENSE) © Multi-Lang Build Team

---

<p align="center">
  用 ❤️ 构建 | 让多语言开发更简单
</p>
