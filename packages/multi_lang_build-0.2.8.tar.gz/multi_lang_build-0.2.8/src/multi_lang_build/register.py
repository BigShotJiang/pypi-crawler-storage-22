"""Register multi-lang-build as a skill for various IDEs."""

from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Literal


def get_cli_path() -> str:
    """Get the path to the multi-lang-build CLI."""
    # Try to find the CLI in PATH
    result = subprocess.run(
        ["which", "multi-lang-build"],
        capture_output=True,
        text=True,
    )
    if result.returncode == 0:
        return result.stdout.strip()
    
    # Fallback: use Python module
    return f"{sys.executable} -m multi_lang_build"


def register_claude_code(project_level: bool = True) -> bool:
    """Register as Claude Code skill.

    Args:
        project_level: If True (default), register to project-level .claude/multi-lang-build.md.
                      If False, register to global ~/.claude/CLAUDE.md.
    """
    try:
        # Determine registration path
        if project_level:
            # Project-level: .claude/multi-lang-build.md in current directory
            config_dir = Path.cwd() / ".claude"
            config_dir.mkdir(exist_ok=True)
            skill_file = config_dir / "multi-lang-build.md"
            level_name = "project-level"
            is_new = not skill_file.exists()
        else:
            # Global-level: ~/.claude/CLAUDE.md (only check CLI for global)
            result = subprocess.run(
                ["which", "claude"],
                capture_output=True,
                text=True,
            )

            if result.returncode != 0:
                print("❌ Claude Code CLI not found. Please install it first:")
                print("   npm install -g @anthropic-ai/claude-code")
                return False

            claude_dir = Path.home() / ".claude"
            claude_dir.mkdir(exist_ok=True)
            skill_file = claude_dir / "CLAUDE.md"
            level_name = "global"
            is_new = not skill_file.exists()

        skill_content = """## Multi-Lang Build Tool

You can use the `multi-lang-build` tool to compile projects:

### Available Commands:
- `multi-lang-build pnpm <source> --output <dir>` - Build pnpm projects
- `multi-lang-build go <source> --output <bin>` - Build Go projects
- `multi-lang-build python <source> --output <dir>` - Build Python projects
- `multi-lang-build mirror list|set|show` - Configure domestic mirrors

### Examples:
```bash
# Build Go project
multi-lang-build go ./src --output ./bin/app --mirror

# Build with specific target (multi-entry support)
multi-lang-build go ./src --output ./bin/server --target cmd/server/main.go

# Build Python project
multi-lang-build python ./src --output ./dist --mirror

# Build pnpm project
multi-lang-build pnpm ./src --output ./dist --mirror

# Configure mirror
multi-lang-build mirror set pip pip_aliyun
multi-lang-build mirror set go
```

When working with Go projects, check if there are multiple main packages and use the `--target` flag to specify which one to build.
"""

        if project_level:
            # Project-level: create dedicated file
            with open(skill_file, "w") as f:
                f.write(skill_content)
            print(f"✅ Registered with Claude Code ({level_name}, created {skill_file})")
        else:
            # Global-level: append to existing CLAUDE.md if not already present
            existing_content = ""
            if skill_file.exists():
                existing_content = skill_file.read_text()

            if "## Multi-Lang Build Tool" not in existing_content:
                with open(skill_file, "a") as f:
                    f.write(skill_content)
                print(f"✅ Registered with Claude Code ({level_name}, added to {skill_file})")
            else:
                print(f"ℹ️ Already registered with Claude Code ({level_name}, {skill_file})")

        return True

    except Exception as e:
        print(f"❌ Failed to register with Claude Code: {e}")
        return False
        return False


def register_opencode(project_level: bool = True) -> bool:
    """Register as OpenCode skill.

    Args:
        project_level: If True (default), register to project-level .opencode/skills.json.
                      If False, register to global ~/.config/opencode/skills.json.
    """
    try:
        # Determine registration path
        if project_level:
            # Project-level: .opencode/skills.json in current directory
            base_dir = Path.cwd()
            config_dir = base_dir / ".opencode"
            config_dir.mkdir(exist_ok=True)
            skills_file = config_dir / "skills.json"
            level_name = "project-level"
        else:
            # Global-level: ~/.config/opencode/skills.json
            config_dir = Path.home() / ".config" / "opencode"
            config_dir.mkdir(parents=True, exist_ok=True)
            skills_file = config_dir / "skills.json"
            level_name = "global"

        # Create or update skills.json
        skills: dict = {}

        if skills_file.exists():
            with open(skills_file) as f:
                skills = json.load(f)

        # Add multi-lang-build skill
        skills["multi-lang-build"] = {
            "name": "multi-lang-build",
            "description": "Multi-language automated build tool with mirror acceleration",
            "commands": {
                "build-go": "multi-lang-build go <source> --output <output> [--mirror] [--target <target>]",
                "build-python": "multi-lang-build python <source> --output <output> [--mirror]",
                "build-pnpm": "multi-lang-build pnpm <source> --output <output> [--mirror]",
            },
            "examples": [
                "multi-lang-build go ./src --output ./bin/app --mirror",
                "multi-lang-build go ./src --output ./bin/server --target cmd/server/main.go",
                "multi-lang-build python ./src --output ./dist --mirror",
                "multi-lang-build pnpm ./src --output ./dist --mirror",
            ]
        }

        with open(skills_file, "w") as f:
            json.dump(skills, f, indent=2)

        print(f"✅ Registered with OpenCode ({level_name}, config: {skills_file})")
        return True

    except Exception as e:
        print(f"❌ Failed to register with OpenCode: {e}")
        return False


def register_trae(project_level: bool = True) -> bool:
    """Register as Trae skill.

    Args:
        project_level: If True (default), register to project-level .trae/skills.json.
                      If False, register to global ~/.trae/skills.json.
    """
    try:
        # Determine registration path
        if project_level:
            # Project-level: .trae/skills.json in current directory
            base_dir = Path.cwd()
            config_dir = base_dir / ".trae"
            config_dir.mkdir(exist_ok=True)
            skills_file = config_dir / "skills.json"
            level_name = "project-level"
        else:
            # Global-level: ~/.trae/skills.json
            config_dir = Path.home() / ".trae"
            config_dir.mkdir(exist_ok=True)
            skills_file = config_dir / "skills.json"
            level_name = "global"

        # Create or update skills.json
        skills: dict = {}

        if skills_file.exists():
            with open(skills_file) as f:
                skills = json.load(f)

        # Add multi-lang-build skill
        skills["multi-lang-build"] = {
            "name": "Multi-Lang Build",
            "description": "Automated build tool for Go, Python, and pnpm projects",
            "category": "build",
            "commands": [
                {
                    "name": "build-go",
                    "command": "multi-lang-build go {source} --output {output}",
                    "description": "Build Go project",
                    "args": ["source", "output", "target", "mirror"]
                },
                {
                    "name": "build-python",
                    "command": "multi-lang-build python {source} --output {output}",
                    "description": "Build Python project",
                    "args": ["source", "output", "mirror"]
                },
                {
                    "name": "build-pnpm",
                    "command": "multi-lang-build pnpm {source} --output {output}",
                    "description": "Build pnpm project",
                    "args": ["source", "output", "mirror"]
                }
            ]
        }

        with open(skills_file, "w") as f:
            json.dump(skills, f, indent=2)

        print(f"✅ Registered with Trae ({level_name}, config: {skills_file})")
        return True

    except Exception as e:
        print(f"❌ Failed to register with Trae: {e}")
        return False


def register_codebuddy(project_level: bool = True) -> bool:
    """Register as CodeBuddy skill.

    Args:
        project_level: If True (default), register to project-level .codebuddy/skills.yaml.
                      If False, register to global ~/.codebuddy/skills.yaml.
    """
    try:
        # Determine registration path
        if project_level:
            # Project-level: .codebuddy/skills.yaml in current directory
            base_dir = Path.cwd()
            config_dir = base_dir / ".codebuddy"
            config_dir.mkdir(exist_ok=True)
            skills_file = config_dir / "skills.yaml"
            level_name = "project-level"
        else:
            # Global-level: ~/.codebuddy/skills.yaml
            config_dir = Path.home() / ".codebuddy"
            config_dir.mkdir(exist_ok=True)
            skills_file = config_dir / "skills.yaml"
            level_name = "global"

        skill_config = """# Multi-Lang Build Skill
skills:
  multi-lang-build:
    name: "Multi-Lang Build"
    description: "Multi-language automated build tool with mirror acceleration"
    version: "0.2.0"

    commands:
      build-go:
        description: "Build Go project"
        command: "multi-lang-build go {source} --output {output}"
        args:
          - name: source
            description: "Source directory"
            required: true
          - name: output
            description: "Output path"
            required: true
          - name: target
            description: "Build target (file or directory)"
            required: false
          - name: mirror
            description: "Enable mirror acceleration"
            type: flag

      build-python:
        description: "Build Python project"
        command: "multi-lang-build python {source} --output {output}"
        args:
          - name: source
            description: "Source directory"
            required: true
          - name: output
            description: "Output directory"
            required: true
          - name: mirror
            description: "Enable mirror acceleration"
            type: flag

      build-pnpm:
        description: "Build pnpm project"
        command: "multi-lang-build pnpm {source} --output {output}"
        args:
          - name: source
            description: "Source directory"
            required: true
          - name: output
            description: "Output directory"
            required: true
          - name: mirror
            description: "Enable mirror acceleration"
            type: flag
"""

        # Append or create
        if skills_file.exists():
            content = skills_file.read_text()
            if "multi-lang-build" not in content:
                with open(skills_file, "a") as f:
                    f.write("\n" + skill_config)
                print(f"✅ Registered with CodeBuddy ({level_name}, updated {skills_file})")
            else:
                print(f"ℹ️ Already registered with CodeBuddy ({level_name}, {skills_file})")
        else:
            skills_file.write_text(skill_config)
            print(f"✅ Registered with CodeBuddy ({level_name}, created {skills_file})")

        return True

    except Exception as e:
        print(f"❌ Failed to register with CodeBuddy: {e}")
        return False


def register_skill(
    ide: Literal["claude", "opencode", "trae", "codebuddy", "all"] = "claude",
    global_level: bool = False
) -> bool:
    """Register multi-lang-build as a skill for the specified IDE.

    Args:
        ide: The IDE to register with. Options: "claude", "opencode", "trae", "codebuddy", "all"
             Default is "claude".
        global_level: If True, register to global config. If False (default), register to project-level.

    Returns:
        True if registration succeeded, False otherwise.
    """
    print(f"📝 Registering multi-lang-build for {ide}...\n")

    if ide == "all":
        results = [
            ("Claude Code", register_claude_code(project_level=not global_level)),
            ("OpenCode", register_opencode(project_level=not global_level)),
            ("Trae", register_trae(project_level=not global_level)),
            ("CodeBuddy", register_codebuddy(project_level=not global_level)),
        ]

        print("\n" + "=" * 50)
        print("Registration Summary:")
        for name, success in results:
            status = "✅" if success else "❌"
            print(f"  {status} {name}")

        return all(success for _, success in results)

    elif ide == "claude":
        return register_claude_code(project_level=not global_level)
    elif ide == "opencode":
        return register_opencode(project_level=not global_level)
    elif ide == "trae":
        return register_trae(project_level=not global_level)
    elif ide == "codebuddy":
        return register_codebuddy(project_level=not global_level)
    else:
        print(f"❌ Unknown IDE: {ide}")
        print("Supported IDEs: claude, opencode, trae, codebuddy, all")
        return False


if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(
        description="Register multi-lang-build as an IDE skill"
    )
    parser.add_argument(
        "ide",
        nargs="?",
        default="claude",
        choices=["claude", "opencode", "trae", "codebuddy", "all"],
        help="IDE to register with (default: claude)",
    )
    parser.add_argument(
        "--global",
        dest="global_level",
        action="store_true",
        help="Register to global config instead of project-level",
    )

    args = parser.parse_args()
    success = register_skill(args.ide, global_level=args.global_level)
    sys.exit(0 if success else 1)
