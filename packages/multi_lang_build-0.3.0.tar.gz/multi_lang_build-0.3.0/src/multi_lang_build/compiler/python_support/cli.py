"""Python compiler CLI entry point."""

from pathlib import Path


def main() -> None:
    """Python compiler CLI entry point."""
    import argparse
    import sys

    parser = argparse.ArgumentParser(description="Python Build Compiler")
    parser.add_argument("source_dir", type=Path, help="Source directory")
    parser.add_argument("-o", "--output", type=Path, required=True, help="Output directory")
    parser.add_argument("--mirror", action="store_true", default=True, help="Enable PyPI mirror")
    parser.add_argument("--no-mirror", dest="mirror", action="store_false", help="Disable PyPI mirror")
    parser.add_argument("--install", action="store_true", help="Install dependencies only")
    parser.add_argument("--dev", action="store_true", help="Include dev dependencies")
    parser.add_argument("--poetry", action="store_true", help="Force using poetry")
    parser.add_argument("--create-venv", type=Path, help="Create virtual environment at path")

    args = parser.parse_args()

    from multi_lang_build.compiler.python import PythonCompiler

    compiler = PythonCompiler()

    if args.create_venv:
        result = compiler.create_venv(
            args.create_venv,
            mirror_enabled=args.mirror,
        )
    elif args.install:
        result = compiler.install_dependencies(
            args.source_dir,
            mirror_enabled=args.mirror,
            dev=args.dev,
            poetry=args.poetry,
        )
    else:
        result = compiler.build(
            args.source_dir,
            args.output,
            mirror_enabled=args.mirror,
        )

    sys.exit(0 if result["success"] else 1)
