""" Version info """

__title__ = 'multicaps'
__description__ = 'Python CAPTCHA solving for Humans.'
__url__ = 'https://github.com/sergey-scat/unicaps'
__version__ = '1.3.0'
__author__ = 'Sergey Scat'
__license__ = 'Apache 2.0'
__copyright__ = 'Copyright 2020-2024 Sergey Scat'
