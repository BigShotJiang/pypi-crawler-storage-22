# -*- coding: UTF-8 -*-
"""
Miscellaneous stuff
"""
