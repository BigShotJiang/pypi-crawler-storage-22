# -*- coding: UTF-8 -*-
"""
hCaptcha solving example
"""

import asyncio
import os

import httpx
from lxml import html  # type: ignore
from multicaps import AsyncCaptchaSolver, CaptchaSolvingService, exceptions  # type: ignore

URL = 'https://accounts.hcaptcha.com/demo'
API_KEY = os.getenv('API_KEY_2CAPTCHA', default='<PLACE_YOUR_API_KEY_HERE>')


async def main():
    """ Init AsyncCaptchaSolver and run the example """
    async with AsyncCaptchaSolver(CaptchaSolvingService.TWOCAPTCHA, API_KEY) as solver:
        await run(solver)


async def run(solver):
    """ Solve hCaptcha """

    # make a session and go to URL
    async with httpx.AsyncClient(http2=True) as session:
        response = await session.get(URL)

        # parse page and get site-key
        page = html.document_fromstring(response.text)
        site_key = page.cssselect('.h-captcha')[0].attrib['data-sitekey']

        # parse form data
        page_form_data = page.xpath('//form//input')
        form_data = {}
        for input_data in page_form_data:
            if input_data.xpath('@name'):
                form_data[input_data.xpath('@name')[0]] = next(
                    iter(input_data.xpath('@value')),
                    None
                )

        # solve hCaptcha
        try:
            solved = await solver.solve_hcaptcha(
                site_key=site_key,
                page_url=URL
            )
        except exceptions.UnicapsException as exc:
            print(f'hCaptcha solving exception: {str(exc)}')
            return False, None

        # add token to form data
        form_data['h-captcha-response'] = solved.solution.token
        form_data['g-recaptcha-response'] = solved.solution.token

        # post form data
        response = await session.post(URL, data=form_data)
        page = html.document_fromstring(response.text)

    # check the result
    if page.xpath('//div[text()="Verification Success!"]'):
        print('The hCaptcha has been solved correctly!')
        # report good CAPTCHA
        await solved.report_good()
        return True, solved

    print('The hCaptcha has not been solved correctly!')
    # report bad CAPTCHA
    await solved.report_bad()
    return False, solved


if __name__ == '__main__':
    asyncio.run(main())
