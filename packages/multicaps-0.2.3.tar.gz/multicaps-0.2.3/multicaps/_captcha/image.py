# -*- coding: UTF-8 -*-
"""
Image CAPTCHA
"""

import base64
import io
import pathlib
from dataclasses import dataclass
from typing import Union, Optional

from .._compat import enforce_types

from .base import BaseCaptcha, BaseCaptchaSolution
from ..common import CaptchaAlphabet, CaptchaCharType, WorkerLanguage
from ..exceptions import BadInputDataError


def _detect_image_type(image_bytes: bytes) -> Optional[str]:
    """Detect common image formats from file signatures."""

    if len(image_bytes) < 12:
        return None

    if image_bytes.startswith(b'\xff\xd8\xff'):
        return 'jpeg'
    # Backward-compatibility with old imghdr behavior used in tests.
    if image_bytes[6:10] == b'Exif':
        return 'jpeg'

    if image_bytes.startswith(b'\x89PNG\r\n\x1a\n'):
        return 'png'

    if image_bytes.startswith((b'GIF87a', b'GIF89a')):
        return 'gif'

    if image_bytes.startswith(b'BM'):
        return 'bmp'

    if image_bytes.startswith((b'II*\x00', b'MM\x00*')):
        return 'tiff'

    if image_bytes.startswith(b'RIFF') and image_bytes[8:12] == b'WEBP':
        return 'webp'

    return None


@enforce_types
@dataclass
class ImageCaptcha(BaseCaptcha):
    """ Image CAPTCHA """

    image: Union[bytes, io.RawIOBase, io.BufferedIOBase, pathlib.Path]
    char_type: Optional[CaptchaCharType] = None
    is_phrase: Optional[bool] = None
    is_case_sensitive: Optional[bool] = None
    is_math: Optional[bool] = None
    min_len: Optional[int] = None
    max_len: Optional[int] = None
    alphabet: Optional[CaptchaAlphabet] = None
    language: Optional[WorkerLanguage] = None
    comment: Optional[str] = None

    def __post_init__(self):
        self._image_bytes = None
        self.get_image_bytes()

    def get_image_bytes(self) -> bytes:
        """ Bytes image """

        if self._image_bytes is None:
            if isinstance(self.image, bytes):
                self._image_bytes = self.image  # type: ignore
            elif isinstance(self.image, (io.RawIOBase, io.BufferedIOBase)):
                self._image_bytes = self.image.read()
            elif isinstance(self.image, pathlib.Path):
                self._image_bytes = self.image.read_bytes()

            # check image type
            self.get_image_type()

        return self._image_bytes

    def get_image_base64(self) -> bytes:
        """ BASE64 image """

        return base64.b64encode(self.get_image_bytes())

    def get_image_type(self) -> str:
        """ Get type of image file/data """

        image_type = _detect_image_type(self._image_bytes)  # type: ignore[arg-type]

        if not image_type:
            raise BadInputDataError("Unable to recognize image type!")
        return image_type


@enforce_types
@dataclass
class ImageCaptchaSolution(BaseCaptchaSolution):
    """ Image CAPTCHA solution """

    text: str
