from multidb_mcp.server import mcp

print(mcp.name)
