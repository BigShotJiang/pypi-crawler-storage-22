from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.put_v1_workers_me_wallet_body import PutV1WorkersMeWalletBody
from ...models.put_v1_workers_me_wallet_response_200 import PutV1WorkersMeWalletResponse200
from ...types import Response


def _get_kwargs(
    *,
    body: PutV1WorkersMeWalletBody,
    authorization: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    headers["authorization"] = authorization

    _kwargs: dict[str, Any] = {
        "method": "put",
        "url": "/v1/workers/me/wallet",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> PutV1WorkersMeWalletResponse200 | None:
    if response.status_code == 200:
        response_200 = PutV1WorkersMeWalletResponse200.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[PutV1WorkersMeWalletResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: PutV1WorkersMeWalletBody,
    authorization: str,
) -> Response[PutV1WorkersMeWalletResponse200]:
    """
    Args:
        authorization (str):
        body (PutV1WorkersMeWalletBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PutV1WorkersMeWalletResponse200]
    """

    kwargs = _get_kwargs(
        body=body,
        authorization=authorization,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: PutV1WorkersMeWalletBody,
    authorization: str,
) -> PutV1WorkersMeWalletResponse200 | None:
    """
    Args:
        authorization (str):
        body (PutV1WorkersMeWalletBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PutV1WorkersMeWalletResponse200
    """

    return sync_detailed(
        client=client,
        body=body,
        authorization=authorization,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: PutV1WorkersMeWalletBody,
    authorization: str,
) -> Response[PutV1WorkersMeWalletResponse200]:
    """
    Args:
        authorization (str):
        body (PutV1WorkersMeWalletBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PutV1WorkersMeWalletResponse200]
    """

    kwargs = _get_kwargs(
        body=body,
        authorization=authorization,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: PutV1WorkersMeWalletBody,
    authorization: str,
) -> PutV1WorkersMeWalletResponse200 | None:
    """
    Args:
        authorization (str):
        body (PutV1WorkersMeWalletBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PutV1WorkersMeWalletResponse200
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
            authorization=authorization,
        )
    ).parsed
