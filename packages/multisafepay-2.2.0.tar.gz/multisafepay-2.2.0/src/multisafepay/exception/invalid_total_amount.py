# Copyright (c) MultiSafepay, Inc. All rights reserved.

# This file is licensed under the Open Software License (OSL) version 3.0.
# For a copy of the license, see the LICENSE.txt file in the project root.

# See the DISCLAIMER.md file for disclaimer details.

"""Invalid total amount exception for amount validation errors."""


class InvalidTotalAmountException(Exception):
    """
    Exception raised for invalid total amount.

    This exception is raised when the total amount provided is invalid.
    """
