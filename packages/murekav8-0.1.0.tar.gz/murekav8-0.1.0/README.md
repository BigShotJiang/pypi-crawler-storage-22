# Mureka V8

AI-powered music generation platform.

## Official Website

Visit: [https://murekav8.org](https://murekav8.org)

## Installation

```bash
pip install murekav8
```

## License

MIT License
