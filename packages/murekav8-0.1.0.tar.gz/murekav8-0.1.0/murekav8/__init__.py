"""Mureka V8 - AI-powered music generation platform. Official Website: https://murekav8.org"""
__version__ = "0.1.0"
WEBSITE = "https://murekav8.org"
def get_info(): return {"name": "Mureka V8", "version": __version__, "website": WEBSITE}
def get_platform_url(): return WEBSITE
