from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...types import UNSET, Response


def _get_kwargs(
    *,
    redirect_uri: str,
    authorization: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    headers["authorization"] = authorization

    params: dict[str, Any] = {}

    params["redirect_uri"] = redirect_uri

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/connections/facebook/authorize",
        "params": params,
    }

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = response.json()
        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    redirect_uri: str,
    authorization: str,
) -> Response[Any | HTTPValidationError]:
    """Connection Facebook Authorize

     Start Facebook OAuth flow to connect a user's Facebook account.

    Requires a valid session (user must be logged in).
    The app_id is determined from the session token.

    Args:
        redirect_uri (str): Final redirect URI after connection
        authorization (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        redirect_uri=redirect_uri,
        authorization=authorization,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    redirect_uri: str,
    authorization: str,
) -> Any | HTTPValidationError | None:
    """Connection Facebook Authorize

     Start Facebook OAuth flow to connect a user's Facebook account.

    Requires a valid session (user must be logged in).
    The app_id is determined from the session token.

    Args:
        redirect_uri (str): Final redirect URI after connection
        authorization (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError
    """

    return sync_detailed(
        client=client,
        redirect_uri=redirect_uri,
        authorization=authorization,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    redirect_uri: str,
    authorization: str,
) -> Response[Any | HTTPValidationError]:
    """Connection Facebook Authorize

     Start Facebook OAuth flow to connect a user's Facebook account.

    Requires a valid session (user must be logged in).
    The app_id is determined from the session token.

    Args:
        redirect_uri (str): Final redirect URI after connection
        authorization (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        redirect_uri=redirect_uri,
        authorization=authorization,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    redirect_uri: str,
    authorization: str,
) -> Any | HTTPValidationError | None:
    """Connection Facebook Authorize

     Start Facebook OAuth flow to connect a user's Facebook account.

    Requires a valid session (user must be logged in).
    The app_id is determined from the session token.

    Args:
        redirect_uri (str): Final redirect URI after connection
        authorization (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            client=client,
            redirect_uri=redirect_uri,
            authorization=authorization,
        )
    ).parsed
