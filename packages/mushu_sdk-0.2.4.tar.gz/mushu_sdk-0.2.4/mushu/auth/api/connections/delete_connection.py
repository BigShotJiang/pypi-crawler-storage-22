from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.connection_service import ConnectionService
from ...models.delete_connection_response_delete_connection import (
    DeleteConnectionResponseDeleteConnection,
)
from ...models.http_validation_error import HTTPValidationError
from ...types import Response


def _get_kwargs(
    app_id: str,
    service: ConnectionService,
    *,
    authorization: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    headers["authorization"] = authorization

    _kwargs: dict[str, Any] = {
        "method": "delete",
        "url": "/apps/{app_id}/connections/{service}".format(
            app_id=quote(str(app_id), safe=""),
            service=quote(str(service), safe=""),
        ),
    }

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> DeleteConnectionResponseDeleteConnection | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = DeleteConnectionResponseDeleteConnection.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[DeleteConnectionResponseDeleteConnection | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    app_id: str,
    service: ConnectionService,
    *,
    client: AuthenticatedClient | Client,
    authorization: str,
) -> Response[DeleteConnectionResponseDeleteConnection | HTTPValidationError]:
    """Delete Connection Config

     Delete a connection config.

    Args:
        app_id (str):
        service (ConnectionService): Supported connection service types.
        authorization (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeleteConnectionResponseDeleteConnection | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        app_id=app_id,
        service=service,
        authorization=authorization,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    app_id: str,
    service: ConnectionService,
    *,
    client: AuthenticatedClient | Client,
    authorization: str,
) -> DeleteConnectionResponseDeleteConnection | HTTPValidationError | None:
    """Delete Connection Config

     Delete a connection config.

    Args:
        app_id (str):
        service (ConnectionService): Supported connection service types.
        authorization (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeleteConnectionResponseDeleteConnection | HTTPValidationError
    """

    return sync_detailed(
        app_id=app_id,
        service=service,
        client=client,
        authorization=authorization,
    ).parsed


async def asyncio_detailed(
    app_id: str,
    service: ConnectionService,
    *,
    client: AuthenticatedClient | Client,
    authorization: str,
) -> Response[DeleteConnectionResponseDeleteConnection | HTTPValidationError]:
    """Delete Connection Config

     Delete a connection config.

    Args:
        app_id (str):
        service (ConnectionService): Supported connection service types.
        authorization (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeleteConnectionResponseDeleteConnection | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        app_id=app_id,
        service=service,
        authorization=authorization,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    app_id: str,
    service: ConnectionService,
    *,
    client: AuthenticatedClient | Client,
    authorization: str,
) -> DeleteConnectionResponseDeleteConnection | HTTPValidationError | None:
    """Delete Connection Config

     Delete a connection config.

    Args:
        app_id (str):
        service (ConnectionService): Supported connection service types.
        authorization (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeleteConnectionResponseDeleteConnection | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            app_id=app_id,
            service=service,
            client=client,
            authorization=authorization,
        )
    ).parsed
