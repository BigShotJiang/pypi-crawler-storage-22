from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.email_login_request import EmailLoginRequest
from ...models.http_validation_error import HTTPValidationError
from ...models.session_response import SessionResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    body: EmailLoginRequest,
    app_id: str | Unset = "app_platform",
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    params: dict[str, Any] = {}

    params["app_id"] = app_id

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/auth/email/login",
        "params": params,
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | SessionResponse | None:
    if response.status_code == 200:
        response_200 = SessionResponse.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | SessionResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: EmailLoginRequest,
    app_id: str | Unset = "app_platform",
) -> Response[HTTPValidationError | SessionResponse]:
    """Email Login

     Sign in with email and password.

    Returns session tokens on success. Account is locked after 5 failed
    attempts for 15 minutes.

    Args:
        app_id (str | Unset): App ID for multi-tenant auth Default: 'app_platform'.
        body (EmailLoginRequest): Request to sign in with email and password.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | SessionResponse]
    """

    kwargs = _get_kwargs(
        body=body,
        app_id=app_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: EmailLoginRequest,
    app_id: str | Unset = "app_platform",
) -> HTTPValidationError | SessionResponse | None:
    """Email Login

     Sign in with email and password.

    Returns session tokens on success. Account is locked after 5 failed
    attempts for 15 minutes.

    Args:
        app_id (str | Unset): App ID for multi-tenant auth Default: 'app_platform'.
        body (EmailLoginRequest): Request to sign in with email and password.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | SessionResponse
    """

    return sync_detailed(
        client=client,
        body=body,
        app_id=app_id,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: EmailLoginRequest,
    app_id: str | Unset = "app_platform",
) -> Response[HTTPValidationError | SessionResponse]:
    """Email Login

     Sign in with email and password.

    Returns session tokens on success. Account is locked after 5 failed
    attempts for 15 minutes.

    Args:
        app_id (str | Unset): App ID for multi-tenant auth Default: 'app_platform'.
        body (EmailLoginRequest): Request to sign in with email and password.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | SessionResponse]
    """

    kwargs = _get_kwargs(
        body=body,
        app_id=app_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: EmailLoginRequest,
    app_id: str | Unset = "app_platform",
) -> HTTPValidationError | SessionResponse | None:
    """Email Login

     Sign in with email and password.

    Returns session tokens on success. Account is locked after 5 failed
    attempts for 15 minutes.

    Args:
        app_id (str | Unset): App ID for multi-tenant auth Default: 'app_platform'.
        body (EmailLoginRequest): Request to sign in with email and password.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | SessionResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
            app_id=app_id,
        )
    ).parsed
