from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.email_resend_verification_response_email_resend_verification import (
    EmailResendVerificationResponseEmailResendVerification,
)
from ...models.http_validation_error import HTTPValidationError
from ...types import Response


def _get_kwargs(
    *,
    authorization: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    headers["authorization"] = authorization

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/auth/email/resend-verification",
    }

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> EmailResendVerificationResponseEmailResendVerification | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = EmailResendVerificationResponseEmailResendVerification.from_dict(
            response.json()
        )

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[EmailResendVerificationResponseEmailResendVerification | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    authorization: str,
) -> Response[EmailResendVerificationResponseEmailResendVerification | HTTPValidationError]:
    """Email Resend Verification

     Resend email verification link.

    Requires a valid session (user must be logged in).
    Creates a new verification token (invalidates any existing one).

    Args:
        authorization (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[EmailResendVerificationResponseEmailResendVerification | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        authorization=authorization,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    authorization: str,
) -> EmailResendVerificationResponseEmailResendVerification | HTTPValidationError | None:
    """Email Resend Verification

     Resend email verification link.

    Requires a valid session (user must be logged in).
    Creates a new verification token (invalidates any existing one).

    Args:
        authorization (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        EmailResendVerificationResponseEmailResendVerification | HTTPValidationError
    """

    return sync_detailed(
        client=client,
        authorization=authorization,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    authorization: str,
) -> Response[EmailResendVerificationResponseEmailResendVerification | HTTPValidationError]:
    """Email Resend Verification

     Resend email verification link.

    Requires a valid session (user must be logged in).
    Creates a new verification token (invalidates any existing one).

    Args:
        authorization (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[EmailResendVerificationResponseEmailResendVerification | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        authorization=authorization,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    authorization: str,
) -> EmailResendVerificationResponseEmailResendVerification | HTTPValidationError | None:
    """Email Resend Verification

     Resend email verification link.

    Requires a valid session (user must be logged in).
    Creates a new verification token (invalidates any existing one).

    Args:
        authorization (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        EmailResendVerificationResponseEmailResendVerification | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            client=client,
            authorization=authorization,
        )
    ).parsed
