from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.email_verify_request import EmailVerifyRequest
from ...models.email_verify_response_email_verify import EmailVerifyResponseEmailVerify
from ...models.http_validation_error import HTTPValidationError
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    body: EmailVerifyRequest,
    user_id: str,
    app_id: str | Unset = "app_platform",
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    params: dict[str, Any] = {}

    params["user_id"] = user_id

    params["app_id"] = app_id

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/auth/email/verify",
        "params": params,
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> EmailVerifyResponseEmailVerify | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = EmailVerifyResponseEmailVerify.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[EmailVerifyResponseEmailVerify | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: EmailVerifyRequest,
    user_id: str,
    app_id: str | Unset = "app_platform",
) -> Response[EmailVerifyResponseEmailVerify | HTTPValidationError]:
    """Email Verify

     Verify email address using the token from the verification email.

    The token is single-use and expires after 24 hours.

    Args:
        user_id (str): User ID from verification link
        app_id (str | Unset): App ID Default: 'app_platform'.
        body (EmailVerifyRequest): Request to verify email address.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[EmailVerifyResponseEmailVerify | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        body=body,
        user_id=user_id,
        app_id=app_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: EmailVerifyRequest,
    user_id: str,
    app_id: str | Unset = "app_platform",
) -> EmailVerifyResponseEmailVerify | HTTPValidationError | None:
    """Email Verify

     Verify email address using the token from the verification email.

    The token is single-use and expires after 24 hours.

    Args:
        user_id (str): User ID from verification link
        app_id (str | Unset): App ID Default: 'app_platform'.
        body (EmailVerifyRequest): Request to verify email address.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        EmailVerifyResponseEmailVerify | HTTPValidationError
    """

    return sync_detailed(
        client=client,
        body=body,
        user_id=user_id,
        app_id=app_id,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: EmailVerifyRequest,
    user_id: str,
    app_id: str | Unset = "app_platform",
) -> Response[EmailVerifyResponseEmailVerify | HTTPValidationError]:
    """Email Verify

     Verify email address using the token from the verification email.

    The token is single-use and expires after 24 hours.

    Args:
        user_id (str): User ID from verification link
        app_id (str | Unset): App ID Default: 'app_platform'.
        body (EmailVerifyRequest): Request to verify email address.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[EmailVerifyResponseEmailVerify | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        body=body,
        user_id=user_id,
        app_id=app_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: EmailVerifyRequest,
    user_id: str,
    app_id: str | Unset = "app_platform",
) -> EmailVerifyResponseEmailVerify | HTTPValidationError | None:
    """Email Verify

     Verify email address using the token from the verification email.

    The token is single-use and expires after 24 hours.

    Args:
        user_id (str): User ID from verification link
        app_id (str | Unset): App ID Default: 'app_platform'.
        body (EmailVerifyRequest): Request to verify email address.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        EmailVerifyResponseEmailVerify | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
            user_id=user_id,
            app_id=app_id,
        )
    ).parsed
