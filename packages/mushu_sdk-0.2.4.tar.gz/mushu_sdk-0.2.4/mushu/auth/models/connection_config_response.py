from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.connection_service import ConnectionService
from ..types import UNSET, Unset

T = TypeVar("T", bound="ConnectionConfigResponse")


@_attrs_define
class ConnectionConfigResponse:
    """Connection config response (non-sensitive).

    Attributes:
        app_id (str): App ID
        service (ConnectionService): Supported connection service types.
        enabled (bool): Whether the connection is enabled
        created_at (str): ISO timestamp of creation
        updated_at (str): ISO timestamp of last update
        is_configured (bool): Whether the connection has required config
        facebook_app_id (None | str | Unset): Facebook App ID
        facebook_scopes (list[str] | None | Unset): Facebook OAuth scopes
        uses_auth_provider_credentials (bool | Unset): Whether this connection uses auth provider credentials as
            fallback Default: False.
    """

    app_id: str
    service: ConnectionService
    enabled: bool
    created_at: str
    updated_at: str
    is_configured: bool
    facebook_app_id: None | str | Unset = UNSET
    facebook_scopes: list[str] | None | Unset = UNSET
    uses_auth_provider_credentials: bool | Unset = False
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        app_id = self.app_id

        service = self.service.value

        enabled = self.enabled

        created_at = self.created_at

        updated_at = self.updated_at

        is_configured = self.is_configured

        facebook_app_id: None | str | Unset
        if isinstance(self.facebook_app_id, Unset):
            facebook_app_id = UNSET
        else:
            facebook_app_id = self.facebook_app_id

        facebook_scopes: list[str] | None | Unset
        if isinstance(self.facebook_scopes, Unset):
            facebook_scopes = UNSET
        elif isinstance(self.facebook_scopes, list):
            facebook_scopes = self.facebook_scopes

        else:
            facebook_scopes = self.facebook_scopes

        uses_auth_provider_credentials = self.uses_auth_provider_credentials

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "app_id": app_id,
                "service": service,
                "enabled": enabled,
                "created_at": created_at,
                "updated_at": updated_at,
                "is_configured": is_configured,
            }
        )
        if facebook_app_id is not UNSET:
            field_dict["facebook_app_id"] = facebook_app_id
        if facebook_scopes is not UNSET:
            field_dict["facebook_scopes"] = facebook_scopes
        if uses_auth_provider_credentials is not UNSET:
            field_dict["uses_auth_provider_credentials"] = uses_auth_provider_credentials

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        app_id = d.pop("app_id")

        service = ConnectionService(d.pop("service"))

        enabled = d.pop("enabled")

        created_at = d.pop("created_at")

        updated_at = d.pop("updated_at")

        is_configured = d.pop("is_configured")

        def _parse_facebook_app_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        facebook_app_id = _parse_facebook_app_id(d.pop("facebook_app_id", UNSET))

        def _parse_facebook_scopes(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                facebook_scopes_type_0 = cast(list[str], data)

                return facebook_scopes_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        facebook_scopes = _parse_facebook_scopes(d.pop("facebook_scopes", UNSET))

        uses_auth_provider_credentials = d.pop("uses_auth_provider_credentials", UNSET)

        connection_config_response = cls(
            app_id=app_id,
            service=service,
            enabled=enabled,
            created_at=created_at,
            updated_at=updated_at,
            is_configured=is_configured,
            facebook_app_id=facebook_app_id,
            facebook_scopes=facebook_scopes,
            uses_auth_provider_credentials=uses_auth_provider_credentials,
        )

        connection_config_response.additional_properties = d
        return connection_config_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
