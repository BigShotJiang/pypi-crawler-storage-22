from enum import Enum


class ConnectionService(str, Enum):
    FACEBOOK = "facebook"

    def __str__(self) -> str:
        return str(self.value)
