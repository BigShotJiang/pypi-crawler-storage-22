from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.connection_service import ConnectionService
from ..types import UNSET, Unset

T = TypeVar("T", bound="CreateConnectionConfigRequest")


@_attrs_define
class CreateConnectionConfigRequest:
    """Request to create a connection config for an app.

    Attributes:
        service (ConnectionService): Supported connection service types.
        enabled (bool | Unset): Whether the connection is enabled Default: True.
        facebook_app_id (None | str | Unset): Facebook App ID (optional override)
        facebook_app_secret (None | str | Unset): Facebook App Secret (optional override)
        facebook_scopes (list[str] | None | Unset): Facebook OAuth scopes (e.g. ads_read, ads_management)
    """

    service: ConnectionService
    enabled: bool | Unset = True
    facebook_app_id: None | str | Unset = UNSET
    facebook_app_secret: None | str | Unset = UNSET
    facebook_scopes: list[str] | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        service = self.service.value

        enabled = self.enabled

        facebook_app_id: None | str | Unset
        if isinstance(self.facebook_app_id, Unset):
            facebook_app_id = UNSET
        else:
            facebook_app_id = self.facebook_app_id

        facebook_app_secret: None | str | Unset
        if isinstance(self.facebook_app_secret, Unset):
            facebook_app_secret = UNSET
        else:
            facebook_app_secret = self.facebook_app_secret

        facebook_scopes: list[str] | None | Unset
        if isinstance(self.facebook_scopes, Unset):
            facebook_scopes = UNSET
        elif isinstance(self.facebook_scopes, list):
            facebook_scopes = self.facebook_scopes

        else:
            facebook_scopes = self.facebook_scopes

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "service": service,
            }
        )
        if enabled is not UNSET:
            field_dict["enabled"] = enabled
        if facebook_app_id is not UNSET:
            field_dict["facebook_app_id"] = facebook_app_id
        if facebook_app_secret is not UNSET:
            field_dict["facebook_app_secret"] = facebook_app_secret
        if facebook_scopes is not UNSET:
            field_dict["facebook_scopes"] = facebook_scopes

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        service = ConnectionService(d.pop("service"))

        enabled = d.pop("enabled", UNSET)

        def _parse_facebook_app_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        facebook_app_id = _parse_facebook_app_id(d.pop("facebook_app_id", UNSET))

        def _parse_facebook_app_secret(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        facebook_app_secret = _parse_facebook_app_secret(d.pop("facebook_app_secret", UNSET))

        def _parse_facebook_scopes(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                facebook_scopes_type_0 = cast(list[str], data)

                return facebook_scopes_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        facebook_scopes = _parse_facebook_scopes(d.pop("facebook_scopes", UNSET))

        create_connection_config_request = cls(
            service=service,
            enabled=enabled,
            facebook_app_id=facebook_app_id,
            facebook_app_secret=facebook_app_secret,
            facebook_scopes=facebook_scopes,
        )

        create_connection_config_request.additional_properties = d
        return create_connection_config_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
