from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.connection_service import ConnectionService
from ..types import UNSET, Unset

T = TypeVar("T", bound="UserConnectionResponse")


@_attrs_define
class UserConnectionResponse:
    """User connection response.

    Attributes:
        user_id (str): User ID
        app_id (str): App ID
        service (ConnectionService): Supported connection service types.
        connected_at (str): ISO timestamp of when connection was established
        token_expires_at (None | str | Unset): ISO timestamp of token expiry
        scopes_granted (list[str] | None | Unset): OAuth scopes granted
        external_user_id (None | str | Unset): External service user ID
    """

    user_id: str
    app_id: str
    service: ConnectionService
    connected_at: str
    token_expires_at: None | str | Unset = UNSET
    scopes_granted: list[str] | None | Unset = UNSET
    external_user_id: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        user_id = self.user_id

        app_id = self.app_id

        service = self.service.value

        connected_at = self.connected_at

        token_expires_at: None | str | Unset
        if isinstance(self.token_expires_at, Unset):
            token_expires_at = UNSET
        else:
            token_expires_at = self.token_expires_at

        scopes_granted: list[str] | None | Unset
        if isinstance(self.scopes_granted, Unset):
            scopes_granted = UNSET
        elif isinstance(self.scopes_granted, list):
            scopes_granted = self.scopes_granted

        else:
            scopes_granted = self.scopes_granted

        external_user_id: None | str | Unset
        if isinstance(self.external_user_id, Unset):
            external_user_id = UNSET
        else:
            external_user_id = self.external_user_id

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "user_id": user_id,
                "app_id": app_id,
                "service": service,
                "connected_at": connected_at,
            }
        )
        if token_expires_at is not UNSET:
            field_dict["token_expires_at"] = token_expires_at
        if scopes_granted is not UNSET:
            field_dict["scopes_granted"] = scopes_granted
        if external_user_id is not UNSET:
            field_dict["external_user_id"] = external_user_id

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        user_id = d.pop("user_id")

        app_id = d.pop("app_id")

        service = ConnectionService(d.pop("service"))

        connected_at = d.pop("connected_at")

        def _parse_token_expires_at(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        token_expires_at = _parse_token_expires_at(d.pop("token_expires_at", UNSET))

        def _parse_scopes_granted(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                scopes_granted_type_0 = cast(list[str], data)

                return scopes_granted_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        scopes_granted = _parse_scopes_granted(d.pop("scopes_granted", UNSET))

        def _parse_external_user_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        external_user_id = _parse_external_user_id(d.pop("external_user_id", UNSET))

        user_connection_response = cls(
            user_id=user_id,
            app_id=app_id,
            service=service,
            connected_at=connected_at,
            token_expires_at=token_expires_at,
            scopes_granted=scopes_granted,
            external_user_id=external_user_id,
        )

        user_connection_response.additional_properties = d
        return user_connection_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
