from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.get_user_metrics_response_get_user_metrics import (
    GetUserMetricsResponseGetUserMetrics,
)
from ...models.http_validation_error import HTTPValidationError
from ...types import Response


def _get_kwargs(
    app_id: str,
    user_id: str,
    *,
    x_api_key: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    headers["x-api-key"] = x_api_key

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/apps/{app_id}/users/{user_id}/metrics".format(
            app_id=quote(str(app_id), safe=""),
            user_id=quote(str(user_id), safe=""),
        ),
    }

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> GetUserMetricsResponseGetUserMetrics | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = GetUserMetricsResponseGetUserMetrics.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[GetUserMetricsResponseGetUserMetrics | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    app_id: str,
    user_id: str,
    *,
    client: AuthenticatedClient | Client,
    x_api_key: str,
) -> Response[GetUserMetricsResponseGetUserMetrics | HTTPValidationError]:
    """Get User Metrics

     Get current user metrics.

    Args:
        app_id (str):
        user_id (str):
        x_api_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetUserMetricsResponseGetUserMetrics | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        app_id=app_id,
        user_id=user_id,
        x_api_key=x_api_key,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    app_id: str,
    user_id: str,
    *,
    client: AuthenticatedClient | Client,
    x_api_key: str,
) -> GetUserMetricsResponseGetUserMetrics | HTTPValidationError | None:
    """Get User Metrics

     Get current user metrics.

    Args:
        app_id (str):
        user_id (str):
        x_api_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetUserMetricsResponseGetUserMetrics | HTTPValidationError
    """

    return sync_detailed(
        app_id=app_id,
        user_id=user_id,
        client=client,
        x_api_key=x_api_key,
    ).parsed


async def asyncio_detailed(
    app_id: str,
    user_id: str,
    *,
    client: AuthenticatedClient | Client,
    x_api_key: str,
) -> Response[GetUserMetricsResponseGetUserMetrics | HTTPValidationError]:
    """Get User Metrics

     Get current user metrics.

    Args:
        app_id (str):
        user_id (str):
        x_api_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetUserMetricsResponseGetUserMetrics | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        app_id=app_id,
        user_id=user_id,
        x_api_key=x_api_key,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    app_id: str,
    user_id: str,
    *,
    client: AuthenticatedClient | Client,
    x_api_key: str,
) -> GetUserMetricsResponseGetUserMetrics | HTTPValidationError | None:
    """Get User Metrics

     Get current user metrics.

    Args:
        app_id (str):
        user_id (str):
        x_api_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetUserMetricsResponseGetUserMetrics | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            app_id=app_id,
            user_id=user_id,
            client=client,
            x_api_key=x_api_key,
        )
    ).parsed
