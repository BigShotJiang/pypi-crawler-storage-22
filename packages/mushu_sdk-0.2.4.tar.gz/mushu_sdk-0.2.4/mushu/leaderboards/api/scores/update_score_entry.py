from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.update_entry_request import UpdateEntryRequest
from ...models.update_score_entry_response_update_score_entry import (
    UpdateScoreEntryResponseUpdateScoreEntry,
)
from ...types import Response


def _get_kwargs(
    app_id: str,
    board_id: str,
    user_id: str,
    entry_id: str,
    *,
    body: UpdateEntryRequest,
    x_api_key: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    headers["x-api-key"] = x_api_key

    _kwargs: dict[str, Any] = {
        "method": "patch",
        "url": "/apps/{app_id}/boards/{board_id}/scores/{user_id}/entries/{entry_id}".format(
            app_id=quote(str(app_id), safe=""),
            board_id=quote(str(board_id), safe=""),
            user_id=quote(str(user_id), safe=""),
            entry_id=quote(str(entry_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | UpdateScoreEntryResponseUpdateScoreEntry | None:
    if response.status_code == 200:
        response_200 = UpdateScoreEntryResponseUpdateScoreEntry.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | UpdateScoreEntryResponseUpdateScoreEntry]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    app_id: str,
    board_id: str,
    user_id: str,
    entry_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateEntryRequest,
    x_api_key: str,
) -> Response[HTTPValidationError | UpdateScoreEntryResponseUpdateScoreEntry]:
    """Update Score Entry

     Update a specific score entry and recalculate aggregates.

    Args:
        app_id (str):
        board_id (str):
        user_id (str):
        entry_id (str):
        x_api_key (str):
        body (UpdateEntryRequest): Request to update an entry's score.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | UpdateScoreEntryResponseUpdateScoreEntry]
    """

    kwargs = _get_kwargs(
        app_id=app_id,
        board_id=board_id,
        user_id=user_id,
        entry_id=entry_id,
        body=body,
        x_api_key=x_api_key,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    app_id: str,
    board_id: str,
    user_id: str,
    entry_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateEntryRequest,
    x_api_key: str,
) -> HTTPValidationError | UpdateScoreEntryResponseUpdateScoreEntry | None:
    """Update Score Entry

     Update a specific score entry and recalculate aggregates.

    Args:
        app_id (str):
        board_id (str):
        user_id (str):
        entry_id (str):
        x_api_key (str):
        body (UpdateEntryRequest): Request to update an entry's score.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | UpdateScoreEntryResponseUpdateScoreEntry
    """

    return sync_detailed(
        app_id=app_id,
        board_id=board_id,
        user_id=user_id,
        entry_id=entry_id,
        client=client,
        body=body,
        x_api_key=x_api_key,
    ).parsed


async def asyncio_detailed(
    app_id: str,
    board_id: str,
    user_id: str,
    entry_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateEntryRequest,
    x_api_key: str,
) -> Response[HTTPValidationError | UpdateScoreEntryResponseUpdateScoreEntry]:
    """Update Score Entry

     Update a specific score entry and recalculate aggregates.

    Args:
        app_id (str):
        board_id (str):
        user_id (str):
        entry_id (str):
        x_api_key (str):
        body (UpdateEntryRequest): Request to update an entry's score.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | UpdateScoreEntryResponseUpdateScoreEntry]
    """

    kwargs = _get_kwargs(
        app_id=app_id,
        board_id=board_id,
        user_id=user_id,
        entry_id=entry_id,
        body=body,
        x_api_key=x_api_key,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    app_id: str,
    board_id: str,
    user_id: str,
    entry_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateEntryRequest,
    x_api_key: str,
) -> HTTPValidationError | UpdateScoreEntryResponseUpdateScoreEntry | None:
    """Update Score Entry

     Update a specific score entry and recalculate aggregates.

    Args:
        app_id (str):
        board_id (str):
        user_id (str):
        entry_id (str):
        x_api_key (str):
        body (UpdateEntryRequest): Request to update an entry's score.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | UpdateScoreEntryResponseUpdateScoreEntry
    """

    return (
        await asyncio_detailed(
            app_id=app_id,
            board_id=board_id,
            user_id=user_id,
            entry_id=entry_id,
            client=client,
            body=body,
            x_api_key=x_api_key,
        )
    ).parsed
