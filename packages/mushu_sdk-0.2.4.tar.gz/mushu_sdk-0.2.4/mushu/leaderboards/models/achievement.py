from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

if TYPE_CHECKING:
    from ..models.achievement_tier import AchievementTier
    from ..models.unlock_condition import UnlockCondition


T = TypeVar("T", bound="Achievement")


@_attrs_define
class Achievement:
    """Achievement definition response model.

    Attributes:
        achievement_id (str):
        app_id (str):
        name (str):
        description (str):
        icon_url (None | str):
        categories (list[str]):
        conditions (list[UnlockCondition]):
        tiers (list[AchievementTier] | None):
        created_at (datetime.datetime):
    """

    achievement_id: str
    app_id: str
    name: str
    description: str
    icon_url: None | str
    categories: list[str]
    conditions: list[UnlockCondition]
    tiers: list[AchievementTier] | None
    created_at: datetime.datetime
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        achievement_id = self.achievement_id

        app_id = self.app_id

        name = self.name

        description = self.description

        icon_url: None | str
        icon_url = self.icon_url

        categories = self.categories

        conditions = []
        for conditions_item_data in self.conditions:
            conditions_item = conditions_item_data.to_dict()
            conditions.append(conditions_item)

        tiers: list[dict[str, Any]] | None
        if isinstance(self.tiers, list):
            tiers = []
            for tiers_type_0_item_data in self.tiers:
                tiers_type_0_item = tiers_type_0_item_data.to_dict()
                tiers.append(tiers_type_0_item)

        else:
            tiers = self.tiers

        created_at = self.created_at.isoformat()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "achievement_id": achievement_id,
                "app_id": app_id,
                "name": name,
                "description": description,
                "icon_url": icon_url,
                "categories": categories,
                "conditions": conditions,
                "tiers": tiers,
                "created_at": created_at,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.achievement_tier import AchievementTier
        from ..models.unlock_condition import UnlockCondition

        d = dict(src_dict)
        achievement_id = d.pop("achievement_id")

        app_id = d.pop("app_id")

        name = d.pop("name")

        description = d.pop("description")

        def _parse_icon_url(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        icon_url = _parse_icon_url(d.pop("icon_url"))

        categories = cast(list[str], d.pop("categories"))

        conditions = []
        _conditions = d.pop("conditions")
        for conditions_item_data in _conditions:
            conditions_item = UnlockCondition.from_dict(conditions_item_data)

            conditions.append(conditions_item)

        def _parse_tiers(data: object) -> list[AchievementTier] | None:
            if data is None:
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                tiers_type_0 = []
                _tiers_type_0 = data
                for tiers_type_0_item_data in _tiers_type_0:
                    tiers_type_0_item = AchievementTier.from_dict(tiers_type_0_item_data)

                    tiers_type_0.append(tiers_type_0_item)

                return tiers_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[AchievementTier] | None, data)

        tiers = _parse_tiers(d.pop("tiers"))

        created_at = isoparse(d.pop("created_at"))

        achievement = cls(
            achievement_id=achievement_id,
            app_id=app_id,
            name=name,
            description=description,
            icon_url=icon_url,
            categories=categories,
            conditions=conditions,
            tiers=tiers,
            created_at=created_at,
        )

        achievement.additional_properties = d
        return achievement

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
