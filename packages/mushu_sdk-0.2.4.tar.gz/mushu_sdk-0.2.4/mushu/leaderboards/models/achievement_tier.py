from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.unlock_condition import UnlockCondition


T = TypeVar("T", bound="AchievementTier")


@_attrs_define
class AchievementTier:
    """A tier within an achievement (e.g. bronze/silver/gold).

    Attributes:
        tier_id (str):
        name (str):
        condition (UnlockCondition): Condition that must be met to unlock an achievement.
        icon_url (None | str | Unset):
    """

    tier_id: str
    name: str
    condition: UnlockCondition
    icon_url: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        tier_id = self.tier_id

        name = self.name

        condition = self.condition.to_dict()

        icon_url: None | str | Unset
        if isinstance(self.icon_url, Unset):
            icon_url = UNSET
        else:
            icon_url = self.icon_url

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "tier_id": tier_id,
                "name": name,
                "condition": condition,
            }
        )
        if icon_url is not UNSET:
            field_dict["icon_url"] = icon_url

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.unlock_condition import UnlockCondition

        d = dict(src_dict)
        tier_id = d.pop("tier_id")

        name = d.pop("name")

        condition = UnlockCondition.from_dict(d.pop("condition"))

        def _parse_icon_url(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        icon_url = _parse_icon_url(d.pop("icon_url", UNSET))

        achievement_tier = cls(
            tier_id=tier_id,
            name=name,
            condition=condition,
            icon_url=icon_url,
        )

        achievement_tier.additional_properties = d
        return achievement_tier

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
