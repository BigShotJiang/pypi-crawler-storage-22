from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="AchievementUnlockEvent")


@_attrs_define
class AchievementUnlockEvent:
    """An achievement (or tier) that was just unlocked.

    Attributes:
        achievement_id (str):
        name (str):
        tier_id (None | str | Unset):
    """

    achievement_id: str
    name: str
    tier_id: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        achievement_id = self.achievement_id

        name = self.name

        tier_id: None | str | Unset
        if isinstance(self.tier_id, Unset):
            tier_id = UNSET
        else:
            tier_id = self.tier_id

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "achievement_id": achievement_id,
                "name": name,
            }
        )
        if tier_id is not UNSET:
            field_dict["tier_id"] = tier_id

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        achievement_id = d.pop("achievement_id")

        name = d.pop("name")

        def _parse_tier_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        tier_id = _parse_tier_id(d.pop("tier_id", UNSET))

        achievement_unlock_event = cls(
            achievement_id=achievement_id,
            name=name,
            tier_id=tier_id,
        )

        achievement_unlock_event.additional_properties = d
        return achievement_unlock_event

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
