from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

T = TypeVar("T", bound="ASCConfigResponse")


@_attrs_define
class ASCConfigResponse:
    """ASC config response (without private key).

    Attributes:
        app_id (str):
        issuer_id (str):
        key_id (str):
        created_at (datetime.datetime):
    """

    app_id: str
    issuer_id: str
    key_id: str
    created_at: datetime.datetime
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        app_id = self.app_id

        issuer_id = self.issuer_id

        key_id = self.key_id

        created_at = self.created_at.isoformat()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "app_id": app_id,
                "issuer_id": issuer_id,
                "key_id": key_id,
                "created_at": created_at,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        app_id = d.pop("app_id")

        issuer_id = d.pop("issuer_id")

        key_id = d.pop("key_id")

        created_at = isoparse(d.pop("created_at"))

        asc_config_response = cls(
            app_id=app_id,
            issuer_id=issuer_id,
            key_id=key_id,
            created_at=created_at,
        )

        asc_config_response.additional_properties = d
        return asc_config_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
