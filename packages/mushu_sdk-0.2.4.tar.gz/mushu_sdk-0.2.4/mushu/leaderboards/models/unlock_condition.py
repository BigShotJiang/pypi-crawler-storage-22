from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="UnlockCondition")


@_attrs_define
class UnlockCondition:
    """Condition that must be met to unlock an achievement.

    Attributes:
        metric (str): Metric name to evaluate
        operator (str): Comparison operator (gte/lte/eq)
        threshold (float): Threshold value
    """

    metric: str
    operator: str
    threshold: float
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        metric = self.metric

        operator = self.operator

        threshold = self.threshold

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "metric": metric,
                "operator": operator,
                "threshold": threshold,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        metric = d.pop("metric")

        operator = d.pop("operator")

        threshold = d.pop("threshold")

        unlock_condition = cls(
            metric=metric,
            operator=operator,
            threshold=threshold,
        )

        unlock_condition.additional_properties = d
        return unlock_condition

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
