from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.achievement_unlock_event import AchievementUnlockEvent
    from ..models.update_metrics_response_metrics import UpdateMetricsResponseMetrics


T = TypeVar("T", bound="UpdateMetricsResponse")


@_attrs_define
class UpdateMetricsResponse:
    """Response after updating user metrics.

    Attributes:
        metrics (UpdateMetricsResponseMetrics): Current metric values after update
        achievements_unlocked (list[AchievementUnlockEvent] | Unset):
    """

    metrics: UpdateMetricsResponseMetrics
    achievements_unlocked: list[AchievementUnlockEvent] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        metrics = self.metrics.to_dict()

        achievements_unlocked: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.achievements_unlocked, Unset):
            achievements_unlocked = []
            for achievements_unlocked_item_data in self.achievements_unlocked:
                achievements_unlocked_item = achievements_unlocked_item_data.to_dict()
                achievements_unlocked.append(achievements_unlocked_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "metrics": metrics,
            }
        )
        if achievements_unlocked is not UNSET:
            field_dict["achievements_unlocked"] = achievements_unlocked

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.achievement_unlock_event import AchievementUnlockEvent
        from ..models.update_metrics_response_metrics import UpdateMetricsResponseMetrics

        d = dict(src_dict)
        metrics = UpdateMetricsResponseMetrics.from_dict(d.pop("metrics"))

        _achievements_unlocked = d.pop("achievements_unlocked", UNSET)
        achievements_unlocked: list[AchievementUnlockEvent] | Unset = UNSET
        if _achievements_unlocked is not UNSET:
            achievements_unlocked = []
            for achievements_unlocked_item_data in _achievements_unlocked:
                achievements_unlocked_item = AchievementUnlockEvent.from_dict(
                    achievements_unlocked_item_data
                )

                achievements_unlocked.append(achievements_unlocked_item)

        update_metrics_response = cls(
            metrics=metrics,
            achievements_unlocked=achievements_unlocked,
        )

        update_metrics_response.additional_properties = d
        return update_metrics_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
