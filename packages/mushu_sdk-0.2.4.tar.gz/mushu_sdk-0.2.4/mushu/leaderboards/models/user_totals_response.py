from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.user_totals_response_totals import UserTotalsResponseTotals


T = TypeVar("T", bound="UserTotalsResponse")


@_attrs_define
class UserTotalsResponse:
    """Cumulative totals across boards.

    Attributes:
        user_id (str):
        totals (UserTotalsResponseTotals): board_id → ALL_TIME total score
    """

    user_id: str
    totals: UserTotalsResponseTotals
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        user_id = self.user_id

        totals = self.totals.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "user_id": user_id,
                "totals": totals,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.user_totals_response_totals import UserTotalsResponseTotals

        d = dict(src_dict)
        user_id = d.pop("user_id")

        totals = UserTotalsResponseTotals.from_dict(d.pop("totals"))

        user_totals_response = cls(
            user_id=user_id,
            totals=totals,
        )

        user_totals_response.additional_properties = d
        return user_totals_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
