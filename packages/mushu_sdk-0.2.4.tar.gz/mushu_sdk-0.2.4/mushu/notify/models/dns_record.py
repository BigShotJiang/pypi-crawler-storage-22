from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.dns_record_purpose import DnsRecordPurpose

T = TypeVar("T", bound="DnsRecord")


@_attrs_define
class DnsRecord:
    """DNS record that tenant must add.

    Attributes:
        type_ (str): Record type (e.g., 'CNAME')
        name (str): Record name/host
        value (str): Record value
        purpose (DnsRecordPurpose): Purpose of DNS record.
    """

    type_: str
    name: str
    value: str
    purpose: DnsRecordPurpose
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        type_ = self.type_

        name = self.name

        value = self.value

        purpose = self.purpose.value

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "type": type_,
                "name": name,
                "value": value,
                "purpose": purpose,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        type_ = d.pop("type")

        name = d.pop("name")

        value = d.pop("value")

        purpose = DnsRecordPurpose(d.pop("purpose"))

        dns_record = cls(
            type_=type_,
            name=name,
            value=value,
            purpose=purpose,
        )

        dns_record.additional_properties = d
        return dns_record

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
