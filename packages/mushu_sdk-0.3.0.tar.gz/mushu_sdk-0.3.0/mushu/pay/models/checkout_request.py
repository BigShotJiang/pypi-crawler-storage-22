from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="CheckoutRequest")


@_attrs_define
class CheckoutRequest:
    """Request to create a checkout session.

    Attributes:
        product_id (str): Product to purchase
        success_url (str): URL to redirect on success
        cancel_url (str): URL to redirect on cancel
    """

    product_id: str
    success_url: str
    cancel_url: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        product_id = self.product_id

        success_url = self.success_url

        cancel_url = self.cancel_url

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "product_id": product_id,
                "success_url": success_url,
                "cancel_url": cancel_url,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        product_id = d.pop("product_id")

        success_url = d.pop("success_url")

        cancel_url = d.pop("cancel_url")

        checkout_request = cls(
            product_id=product_id,
            success_url=success_url,
            cancel_url=cancel_url,
        )

        checkout_request.additional_properties = d
        return checkout_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
