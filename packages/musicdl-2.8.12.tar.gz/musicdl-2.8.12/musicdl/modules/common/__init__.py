'''initialize'''
from .jbsou import JBSouMusicClient
from .tunehub import TuneHubMusicClient
from .mp3juice import MP3JuiceMusicClient
from .gdstudio import GDStudioMusicClient
from .myfreemp3 import MyFreeMP3MusicClient