"""mutagent.builtins.essential_tools_fs -- File system operations implementation."""

import os
import pathlib
import glob
import shutil
from datetime import datetime

import mutagent
from mutagent.essential_tools import EssentialTools


def _format_size(size: int) -> str:
    """Format file size in human-readable form."""
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if size < 1024.0:
            return f"{size:.1f} {unit}"
        size /= 1024.0
    return f"{size:.1f} PB"


@mutagent.impl(EssentialTools.read_file)
def read_file(self: EssentialTools, path: str, encoding: str = "utf-8") -> str:
    """Read the content of a file."""
    try:
        file_path = pathlib.Path(path).resolve()
        with open(file_path, 'r', encoding=encoding) as f:
            content = f.read()
        return f"✓ Read {len(content)} characters from: {file_path}\n\n{content}"
    except FileNotFoundError:
        return f"✗ Error: File not found: {path}"
    except PermissionError:
        return f"✗ Error: Permission denied: {path}"
    except Exception as e:
        return f"✗ Error reading file: {type(e).__name__}: {e}"


@mutagent.impl(EssentialTools.write_file)
def write_file(self: EssentialTools, path: str, content: str, encoding: str = "utf-8") -> str:
    """Write content to a file."""
    try:
        file_path = pathlib.Path(path).resolve()
        # 确保父目录存在
        file_path.parent.mkdir(parents=True, exist_ok=True)
        
        with open(file_path, 'w', encoding=encoding) as f:
            f.write(content)
        
        return f"✓ Written {len(content)} characters to: {file_path}"
    except PermissionError:
        return f"✗ Error: Permission denied: {path}"
    except Exception as e:
        return f"✗ Error writing file: {type(e).__name__}: {e}"


@mutagent.impl(EssentialTools.append_file)
def append_file(self: EssentialTools, path: str, content: str, encoding: str = "utf-8") -> str:
    """Append content to a file."""
    try:
        file_path = pathlib.Path(path).resolve()
        # 确保父目录存在
        file_path.parent.mkdir(parents=True, exist_ok=True)
        
        with open(file_path, 'a', encoding=encoding) as f:
            f.write(content)
        
        return f"✓ Appended {len(content)} characters to: {file_path}"
    except PermissionError:
        return f"✗ Error: Permission denied: {path}"
    except Exception as e:
        return f"✗ Error appending to file: {type(e).__name__}: {e}"


@mutagent.impl(EssentialTools.list_directory)
def list_directory(self: EssentialTools, path: str = ".", pattern: str = "*") -> str:
    """List files and directories in a given path."""
    try:
        dir_path = pathlib.Path(path).resolve()
        
        if not dir_path.exists():
            return f"✗ Error: Directory not found: {path}"
        
        if not dir_path.is_dir():
            return f"✗ Error: Not a directory: {path}"
        
        # 使用glob匹配
        matches = sorted(dir_path.glob(pattern))
        
        if not matches:
            return f"No files matching '{pattern}' in: {dir_path}"
        
        result = [f"Contents of {dir_path} (pattern: {pattern}):\n"]
        
        for item in matches:
            relative = item.relative_to(dir_path)
            if item.is_dir():
                result.append(f"  📁 {relative}/")
            else:
                size = item.stat().st_size
                result.append(f"  📄 {relative} ({_format_size(size)})")
        
        return "\n".join(result)
    
    except PermissionError:
        return f"✗ Error: Permission denied: {path}"
    except Exception as e:
        return f"✗ Error listing directory: {type(e).__name__}: {e}"


@mutagent.impl(EssentialTools.file_exists)
def file_exists(self: EssentialTools, path: str) -> str:
    """Check if a file or directory exists."""
    try:
        exists = pathlib.Path(path).exists()
        return "true" if exists else "false"
    except Exception as e:
        return f"✗ Error checking file: {type(e).__name__}: {e}"


@mutagent.impl(EssentialTools.create_directory)
def create_directory(self: EssentialTools, path: str) -> str:
    """Create a directory."""
    try:
        dir_path = pathlib.Path(path).resolve()
        dir_path.mkdir(parents=True, exist_ok=True)
        return f"✓ Directory created: {dir_path}"
    except PermissionError:
        return f"✗ Error: Permission denied: {path}"
    except Exception as e:
        return f"✗ Error creating directory: {type(e).__name__}: {e}"


@mutagent.impl(EssentialTools.delete_file)
def delete_file(self: EssentialTools, path: str) -> str:
    """Delete a file or empty directory."""
    try:
        file_path = pathlib.Path(path).resolve()
        
        if not file_path.exists():
            return f"✗ Error: Path not found: {path}"
        
        if file_path.is_dir():
            file_path.rmdir()  # 只删除空目录
            return f"✓ Directory deleted: {file_path}"
        else:
            file_path.unlink()
            return f"✓ File deleted: {file_path}"
    
    except PermissionError:
        return f"✗ Error: Permission denied: {path}"
    except OSError as e:
        if "Directory not empty" in str(e):
            return f"✗ Error: Directory not empty (use recursive delete if needed): {path}"
        return f"✗ Error deleting: {e}"
    except Exception as e:
        return f"✗ Error: {type(e).__name__}: {e}"


@mutagent.impl(EssentialTools.get_file_info)
def get_file_info(self: EssentialTools, path: str) -> str:
    """Get information about a file or directory."""
    try:
        file_path = pathlib.Path(path).resolve()
        
        if not file_path.exists():
            return f"✗ Error: Path not found: {path}"
        
        stat = file_path.stat()
        
        info = [f"Information for: {file_path}\n"]
        info.append(f"  Type: {'Directory' if file_path.is_dir() else 'File'}")
        info.append(f"  Size: {_format_size(stat.st_size)}")
        info.append(f"  Modified: {datetime.fromtimestamp(stat.st_mtime).strftime('%Y-%m-%d %H:%M:%S')}")
        info.append(f"  Created: {datetime.fromtimestamp(stat.st_ctime).strftime('%Y-%m-%d %H:%M:%S')}")
        info.append(f"  Permissions: {oct(stat.st_mode)[-3:]}")
        
        return "\n".join(info)
    
    except PermissionError:
        return f"✗ Error: Permission denied: {path}"
    except Exception as e:
        return f"✗ Error getting file info: {type(e).__name__}: {e}"
