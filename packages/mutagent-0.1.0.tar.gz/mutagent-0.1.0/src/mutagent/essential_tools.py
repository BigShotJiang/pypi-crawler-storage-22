"""mutagent.essential_tools -- Essential tool primitives for Agent self-evolution."""

from __future__ import annotations

from typing import TYPE_CHECKING

import mutagent

if TYPE_CHECKING:
    from mutagent.runtime.module_manager import ModuleManager


class EssentialTools(mutagent.Object):
    """Essential tool primitives -- the minimal operation set for Agent evolution.

    Each method is an independent tool declaration. An Agent can override
    any tool's implementation via ``@impl(EssentialTools.<method>, override=True)``,
    or patch this class to add/remove tool methods.

    Attributes:
        module_manager: The ModuleManager instance used for runtime patching.
    """

    module_manager: ModuleManager

    def inspect_module(self, module_path: str = "", depth: int = 2) -> str:
        """Inspect the structure of a Python module.

        Args:
            module_path: Dotted module path (e.g. "mutagent.essential_tools").
                Empty string lists top-level mutagent modules.
            depth: How deep to expand sub-modules/classes. Default 2.

        Returns:
            A formatted string showing the module structure.
        """
        ...

    def view_source(self, target: str) -> str:
        """View the source code of a module, class, or function.

        Args:
            target: Dotted path to the target (e.g. "mutagent.agent.Agent").

        Returns:
            The source code as a string.
        """
        ...

    def patch_module(self, module_path: str, source: str) -> str:
        """Patch a module with new source code at runtime.

        Args:
            module_path: Dotted module path to patch or create.
            source: Python source code for the module.

        Returns:
            A status message indicating success.
        """
        ...

    def save_module(self, module_path: str, file_path: str = "") -> str:
        """Persist a patched module to the filesystem.

        Args:
            module_path: Dotted module path to save.
            file_path: Optional target directory. Auto-derived if empty.

        Returns:
            A status message with the written file path.
        """
        ...

    def run_code(self, code: str) -> str:
        """Execute a Python code snippet and return the result.

        Args:
            code: Python code to execute.

        Returns:
            Captured stdout/stderr and return value, or error traceback.
        """
        ...

    # ========== 新增：文件系统操作能力 ==========
    
    def read_file(self, path: str, encoding: str = "utf-8") -> str:
        """Read the content of a file.

        Args:
            path: File path to read (absolute or relative).
            encoding: File encoding, default is utf-8.

        Returns:
            The file content as a string.
        """
        ...

    def write_file(self, path: str, content: str, encoding: str = "utf-8") -> str:
        """Write content to a file (overwrites if exists).

        Args:
            path: File path to write (absolute or relative).
            content: Content to write.
            encoding: File encoding, default is utf-8.

        Returns:
            A status message indicating success.
        """
        ...

    def append_file(self, path: str, content: str, encoding: str = "utf-8") -> str:
        """Append content to a file.

        Args:
            path: File path to append to.
            content: Content to append.
            encoding: File encoding, default is utf-8.

        Returns:
            A status message indicating success.
        """
        ...

    def list_directory(self, path: str = ".", pattern: str = "*") -> str:
        """List files and directories in a given path.

        Args:
            path: Directory path to list, default is current directory.
            pattern: Glob pattern to filter results (e.g. "*.py"), default is "*".

        Returns:
            A formatted string listing matching files and directories.
        """
        ...

    def file_exists(self, path: str) -> str:
        """Check if a file or directory exists.

        Args:
            path: File or directory path to check.

        Returns:
            "true" if exists, "false" otherwise.
        """
        ...

    def create_directory(self, path: str) -> str:
        """Create a directory (including parent directories if needed).

        Args:
            path: Directory path to create.

        Returns:
            A status message indicating success.
        """
        ...

    def delete_file(self, path: str) -> str:
        """Delete a file or empty directory.

        Args:
            path: File or directory path to delete.

        Returns:
            A status message indicating success.
        """
        ...

    def get_file_info(self, path: str) -> str:
        """Get information about a file or directory.

        Args:
            path: File or directory path.

        Returns:
            A formatted string with size, modification time, and type.
        """
        ...
