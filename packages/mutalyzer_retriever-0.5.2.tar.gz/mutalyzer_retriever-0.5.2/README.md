# Mutalyzer Retriever

![GitHub last commit](https://img.shields.io/github/last-commit/mutalyzer/retriever)
![Read the Docs](https://img.shields.io/readthedocs/mutalyzer-retriever)
![PyPI](https://img.shields.io/pypi/v/mutalyzer_retriever)
![GitHub code size in bytes](https://img.shields.io/github/languages/code-size/mutalyzer/retriever)
![GitHub language count](https://img.shields.io/github/languages/count/mutalyzer/retriever)
![GitHub top language](https://img.shields.io/github/languages/top/mutalyzer/retriever)
![GitHub](https://img.shields.io/github/license/mutalyzer/retriever)

---

Retrieve and parse genomic reference files.

Please see [ReadTheDocs][RTD] for the latest documentation.

[RTD]: https://mutalyzer-retriever.readthedocs.io/en/latest/