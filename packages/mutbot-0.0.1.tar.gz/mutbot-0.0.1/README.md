# mutagent

A Python AI Bot based on mutagent.

> **Note:** This package is in early development. Stay tuned for updates.

## Installation

```bash
pip install mutbot
```

## License

MIT
