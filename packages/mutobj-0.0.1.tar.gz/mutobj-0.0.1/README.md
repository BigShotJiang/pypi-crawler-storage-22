# mutobj

A Python framework for declaration-implementation seperated design pattern.

> **Note:** This package is in early development. Stay tuned for updates.

## Installation

```bash
pip install mutobj
```

## License

MIT
