# MVMP: 3D Multi-View MediaPipe

[![License](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE) [![Framework](https://img.shields.io/badge/Framework-Python_3.11-yellow)](https://www.python.org/downloads/release/python-3110/) [![Face Landmarker](https://img.shields.io/badge/Model-MediaPipe_Face_Landmarker-red)](https://developers.google.com/mediapipe/solutions/vision/face_landmarker)

## Description

MVMP (Multi-View MediaPipe) is a lightweight software designed for the 3D localization of facial landmarks starting from a static textured mesh. It generates multiple orthographic projections of the face mesh, estimates 2D landmarks using MediaPipe, and backprojects them into 3D space through a consensus-based method. The result is a robust prediction of 478 facial landmarks directly aligned with the 3D mesh geometry.

This method enables landmark estimation even without original scanning data or active vision systems, offering an efficient and flexible approach for 3D face modeling, recognition, and analysis.

<!--![alt text](./img/pipelineOverview.png)-->
<img src="./img/pipelineOverview.png">

## Table of Contents

- [Installation](#installation)
- [Usage](#usage)
- [Contributing](#contributing)
- [License](#license)
- [Contact](#contact)

## Installation

### From PyPI (when published)

```bash
pip install mvmp
```

### From Source

1. Clone the repository:
   ```bash
   git clone https://github.com/meminz/3d_face_landmarker.git
   cd 3d_face_landmarker
   ```

2. Install using pip:
   ```bash
   pip install .
   ```

   Or for development:
   ```bash
   pip install -e .
   ```

### From Wheel

If you have the `.whl` file:

```bash
pip install mvmp-0.1.0-py3-none-any.whl
```

**Note:** The MediaPipe Face Landmarker model is included in the package, so no separate download is needed!

## Usage

MVMP can be used both as a Python library and as a command-line tool.

### Python API

```python
from mvmp import Facemarker

# Initialize with a 3D mesh file
marker = Facemarker("path/to/mesh.obj")

# Detect landmarks (returns FacemarkerResult)
result = marker.predict(projections=100)

# Save results to JSON
result.save_json("output/landmarks.json")

# Access the landmarks directly
landmarks_3d = result.landmarks_3d  # numpy array of 478 3D coordinates
vertex_indices = result.closest_vertices_ids  # closest vertex index for each landmark

# Or use the marker methods
landmarks = marker.get_landmarks()
vertices = marker.get_vertex_indices()
```

### Command Line Interface

After installation, you can use the `mvmp` command:

```bash
mvmp path/to/mesh.obj --projections-number 100 --output-path output/
```

**Arguments:**
- `path`: Path to a single .obj file or directory (will process all .obj files recursively)
- `-p, --projections-number`: Number of projections to calculate (default: 500)
- `-o, --output-path`: Output directory for results
- `-r, --render`: Render the results in an external window
- `-d, --double`: Process mesh twice for better alignment

**Example:**
```bash
# Process a single mesh with 200 projections
mvmp face.obj -p 200 -o results/

# Process all meshes in a directory
mvmp meshes/ -p 100
```

### Output

For each processed mesh, a `<mesh>_landmarks.json` file will be generated:

```json
{
  "normalized_coordinates": [[x, y, z], ...],  // 478 landmark coordinates
  "closest_vertex_indexes": [idx1, idx2, ...], // Corresponding vertex indices
  "transform_params": {
    "center": [x, y, z],
    "scale": float
  }
}
```

### Results
<!--![alt text](./img/results.png)-->
<img src="results.png">

## Contributing

We welcome contributions! To contribute:

1. Fork the repository and create a feature branch.
2. Make your changes with clear and descriptive commit messages.
3. Push the branch to your fork.
4. Open a pull request describing your changes.

## License

This project is licensed under the [MIT License](LICENSE).

## Contact

If you have any questions or suggestions, feel free to get in touch!
