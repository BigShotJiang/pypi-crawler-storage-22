"""
Facemarker: Main API class for 3D face landmark detection
"""
import os
import json
import numpy as np
import open3d as o3d

from .predict import __predict as _predict_impl
from .io_utils import import_mesh, meshes_setup
from .rendering import render_result


class FacemarkerResult:
    """Container for face landmark detection results"""

    def __init__(self, landmarks_3d, closest_vertices_ids, camera_data=None,
                 landmark_candidates=None, transform_params=None):
        self.landmarks_3d = landmarks_3d
        self.closest_vertices_ids = closest_vertices_ids
        self.camera_data = camera_data
        self.landmark_candidates = landmark_candidates
        self.transform_params = transform_params

    def to_dict(self):
        """Convert result to dictionary format"""
        data = {
            "normalized_coordinates": self.landmarks_3d.tolist() if hasattr(self.landmarks_3d, 'tolist') else self.landmarks_3d,
            "closest_vertex_indexes": self.closest_vertices_ids,
        }

        if self.transform_params:
            data["transform_params"] = self.transform_params

        if self.camera_data:
            data["cameras"] = [
                pos.tolist() if hasattr(pos, 'tolist') else pos
                for pos in self.camera_data
            ]

        return data

    def save_json(self, output_path):
        """Save results to JSON file"""
        with open(output_path, "w") as f:
            json.dump(self.to_dict(), f, indent=4)
        print(f"Landmarks saved to: {output_path}")


class Facemarker:
    """
    Main class for detecting facial landmarks on 3D meshes.

    Example usage:
        >>> marker = Facemarker("path/to/mesh.obj")
        >>> result = marker.predict(projections=100)
        >>> result.save_json("output/landmarks.json")
        >>> print(f"Detected {len(result.landmarks_3d)} landmarks")
    """

    def __init__(self, mesh_path, auto_align=True):
        """
        Initialize Facemarker with a 3D mesh file.

        Args:
            mesh_path (str): Path to the .obj mesh file
            auto_align (bool): Whether to automatically align the mesh (default: True)
        """
        if not os.path.exists(mesh_path):
            raise FileNotFoundError(f"Mesh file not found: {mesh_path}")

        if not mesh_path.lower().endswith(".obj"):
            raise ValueError("Only .obj mesh files are supported")

        self.mesh_path = mesh_path
        self.auto_align = auto_align

        # Load and setup meshes
        meshes = import_mesh(mesh_path)
        self._meshes = meshes_setup(meshes, auto_align=auto_align)

        self._result = None

    def predict(self, projections=100):
        """
        Detect facial landmarks on the mesh.

        Args:
            projections (int): Number of projections to use (default: 100)
                             More projections = more accurate but slower

        Returns:
            FacemarkerResult: Object containing landmarks_3d, closest_vertices_ids, etc.
        """
        # Create minimal args object for __predict
        class Args:
            def __init__(self, projections_number):
                self.projections_number = projections_number
                self.output_path = None

        args = Args(projections)

        # Run prediction
        landmarks_3d, closest_vertices_ids, camera_data, landmark_candidates = _predict_impl(
            self._meshes, projections, args
        )

        if landmarks_3d is None or closest_vertices_ids is None:
            raise RuntimeError("Landmark detection failed")

        # Get transform parameters
        transform_params = {
            "center": self._meshes["transform_center"].tolist(),
            "scale": float(self._meshes["transform_scale"])
        }

        # Store result
        self._result = FacemarkerResult(
            landmarks_3d=landmarks_3d,
            closest_vertices_ids=closest_vertices_ids,
            camera_data=camera_data,
            landmark_candidates=landmark_candidates,
            transform_params=transform_params
        )

        return self._result

    def get_landmarks(self):
        """
        Get the detected landmarks (must call predict() first).

        Returns:
            numpy.ndarray: Array of 3D landmark coordinates (normalized)
        """
        if self._result is None:
            raise RuntimeError("No landmarks detected yet. Call predict() first.")
        return self._result.landmarks_3d

    def get_vertex_indices(self):
        """
        Get the mesh vertex indices closest to each landmark.

        Returns:
            list: List of vertex indices
        """
        if self._result is None:
            raise RuntimeError("No landmarks detected yet. Call predict() first.")
        return self._result.closest_vertices_ids

    def save_result(self, output_path):
        """
        Save landmarks to JSON file.

        Args:
            output_path (str): Path to save the JSON file
        """
        if self._result is None:
            raise RuntimeError("No landmarks detected yet. Call predict() first.")

        # Create output directory if needed
        os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)

        self._result.save_json(output_path)

    @property
    def result(self):
        """Get the current result (or None if predict hasn't been called)"""
        return self._result
