import open3d as o3d
import json
import numpy as np

def import_mesh(filename):
    import os
    
    # IMPORTANTE: cambia directory come fa il backend per far trovare i file texture a Open3D
    original_cwd = os.getcwd()
    
    try:
        # Cambia nella directory del mesh
        obj_dir = os.path.dirname(os.path.abspath(filename))
        os.chdir(obj_dir)
        
        # Carica con basename e enable_post_processing=True (come backend)
        # Open3D gestisce automaticamente texture e materiali
        basename = os.path.basename(filename)
        textured_mesh = o3d.io.read_triangle_mesh(basename, enable_post_processing=True)
    except Exception as e:
        print(f"Error importing mesh: {e}\n")
        os.chdir(original_cwd)
        return
    finally:
        # Ripristina sempre la directory originale
        os.chdir(original_cwd)

    if not textured_mesh.vertices: 
        print(f"Error loading mesh.")
        return

    # Log informazioni (come backend)
    has_textures = len(textured_mesh.textures) > 0 if hasattr(textured_mesh, 'textures') else False
    has_materials = textured_mesh.has_triangle_material_ids() if hasattr(textured_mesh, 'has_triangle_material_ids') else False
    has_vertex_colors = textured_mesh.has_vertex_colors()
    # Controlla sia il metodo che l'attributo diretto per triangle_uvs
    has_triangle_uvs = textured_mesh.has_triangle_uvs() if hasattr(textured_mesh, 'has_triangle_uvs') else False
    has_uvs_data = hasattr(textured_mesh, 'triangle_uvs') and len(textured_mesh.triangle_uvs) > 0
    
    print(f"Textures: {len(textured_mesh.textures) if hasattr(textured_mesh, 'textures') else 0}")
    print(f"Materials: {has_materials}")
    print(f"Vertex colors: {has_vertex_colors}")
    print(f"Triangle UVs: {has_triangle_uvs} (data: {has_uvs_data})")
    
    # NON convertire texture in vertex colors - usa direttamente le texture per rendering
    # Open3D Visualizer dovrebbe renderizzare automaticamente le texture se presenti
    # La conversione a vertex colors perde risoluzione perché ogni vertice ha 1 solo colore
    
    # Solo se NON ha texture E NON ha vertex colors, usa colore uniforme
    if not has_textures and len(textured_mesh.vertex_colors) == 0:
        print("Mesh senza colori o texture - genero colore uniforme")
        textured_mesh.paint_uniform_color([0.7, 0.7, 0.7])
    
    # Calcola le normali se non presenti (come backend)
    if len(textured_mesh.vertex_normals) == 0:
        print("Calcolo normali vertici...")
        textured_mesh.compute_vertex_normals()
    
    if len(textured_mesh.triangle_normals) == 0:
        print("Calcolo normali triangoli...")
        textured_mesh.compute_triangle_normals()

    return {
        "mesh": textured_mesh,
        "mesh_path": filename,  # Salva il path per ricaricare alla fine
        "tensor": None,
    }


def meshes_setup(meshes, auto_align=True):
    """Setup della mesh con normalizzazione, centramento e opzionale auto-allineamento
    
    Args:
        meshes: Dizionario con la mesh e il path
        auto_align: Se True, tenta di allineare automaticamente il viso
    
    Returns:
        Dizionario con mesh normalizzata, tensor mesh, e parametri di trasformazione
    """
    mesh = meshes["mesh"]
    
    # Calcola le normali se non presenti (necessario per rendering corretto)
    if len(mesh.vertex_normals) == 0:
        print("Computing vertex normals...")
        mesh.compute_vertex_normals()
    
    if len(mesh.triangle_normals) == 0:
        print("Computing triangle normals...")
        mesh.compute_triangle_normals()

    # 1. NORMALIZZAZIONE: Scala la mesh in un cubo unitario
    scale = max(mesh.get_max_bound() - mesh.get_min_bound())
    center = mesh.get_axis_aligned_bounding_box().get_center()
    
    print(f"Mesh scale: {scale:.4f}")
    print(f"Mesh center: {center}")
    print(f"Mesh bounds: min={mesh.get_min_bound()}, max={mesh.get_max_bound()}")
    
    # Applica le trasformazioni (come nel backend)
    mesh.scale(1/scale, center)
    mesh.translate(-center)
    
    # 2. AUTO-ALLINEAMENTO: Disabilitato
    print("Auto-alignment disabled (mesh assumed to be already oriented correctly)")
    
    # 3. Converti in tensor mesh per raycasting efficiente
    mesh_t = o3d.t.geometry.TriangleMesh(
        device=o3d.core.Device("CUDA:0" if o3d.core.cuda.is_available() else "CPU:0")
    ).from_legacy(mesh)

    # Salva i parametri di trasformazione per riapplicarli alla mesh originale alla fine
    meshes.update({
        "tensor": mesh_t,
        "transform_scale": 1/scale,
        "transform_center": center
    })

    return meshes


def save_facemarks_json(input_path, landmarks_3d, closest_vertices_ids, json_path, camera_data=None):
    data = {
        "model": input_path,
        "normalized coordinates": landmarks_3d.tolist() if hasattr(landmarks_3d, 'tolist') else landmarks_3d,
        "closest vertex indexes": closest_vertices_ids
    }
    
    if camera_data:
        data["cameras"] = [
            {
                "position": cam["position"].tolist() if hasattr(cam["position"], 'tolist') else cam["position"],
                "direction": cam["direction"].tolist() if hasattr(cam["direction"], 'tolist') else cam["direction"]
            }
            for cam in camera_data
        ]

    with open(json_path, "w") as f:
        json.dump(data, f, indent=4)
