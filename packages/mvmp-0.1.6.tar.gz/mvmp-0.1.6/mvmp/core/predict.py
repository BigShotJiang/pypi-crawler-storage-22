import open3d as o3d
import os as os_module
import json
import numpy as np
import scipy
import tempfile
import shutil

from .mp_utils import *
from .rendering import *

from .triangles import TRIANGLES
IMG_SIZE = 1440  # Increased from 720 for better texture detail in 2D renders


def hit_coords(ans, np_rays):
    """Calcola le coordinate dei punti colpiti dai raggi"""
    hit_coords_list = []

    for i, r in enumerate(np_rays):
        distance = ans["t_hit"][i].numpy()
        if distance == float("inf"): 
            continue

        hit_coords_list.append(r[:3] + r[3:] * distance)

    return np.asarray(hit_coords_list)


def hpr_mesh_based(mesh, eye=[0, 0, 0]):
    """Hidden Point Removal basato su mesh - OTTIMIZZATO con operazioni vettorializzate"""
    scene = o3d.t.geometry.RaycastingScene()
    scene.add_triangles(mesh)

    pcd_points = mesh.vertex.positions.numpy()
    eye = np.array(eye, dtype=np.float32)
    
    # Vettorializzato: calcola tutti i vettori distanza in una volta
    distance_vectors = pcd_points - eye
    
    # Vettorializzato: calcola norme e normalizza
    norms = np.linalg.norm(distance_vectors, axis=1, keepdims=True)
    directions = distance_vectors / norms
    
    # Crea i raggi: [eye_x, eye_y, eye_z, dir_x, dir_y, dir_z]
    eyes = np.tile(eye, (len(pcd_points), 1))
    rays = np.hstack([eyes, directions]).astype(np.float32)
    
    cast_results = scene.cast_rays(rays)

    hit_distances = cast_results["t_hit"].numpy()
    visibility_mask = (hit_distances + 0.00001) >= norms.squeeze()

    return np.where(visibility_mask)


def perspective_rays_directions(img_landmarks, size, intrinsic):
    """Calcola le direzioni dei raggi prospettici - OTTIMIZZATO"""
    # Converti landmarks in array numpy
    landmarks_array = np.asarray(img_landmarks, dtype=np.float32)
    
    # Scala le coordinate
    scaled = landmarks_array * size
    
    # Aggiungi la componente omogenea (z=1)
    homogeneous = np.hstack([scaled[:, :2], np.ones((len(scaled), 1))])
    
    # Applica l'inversa della matrice intrinseca
    inv_intrinsic = np.linalg.inv(intrinsic)
    rays = homogeneous @ inv_intrinsic.T
    
    # Normalizza i raggi
    norms = np.linalg.norm(rays, axis=1, keepdims=True)
    return rays / norms


def estimate_face_orientation(mesh):
    """Stima l'orientamento del viso e restituisce una matrice di rotazione per allinearlo"""
    # Calcola il bounding box orientato
    obb = mesh.get_oriented_bounding_box()
    
    # Estrai i punti della mesh
    vertices = np.asarray(mesh.vertices)
    
    # Trova l'asse principale usando PCA
    centered = vertices - np.mean(vertices, axis=0)
    cov_matrix = np.cov(centered.T)
    eigenvalues, eigenvectors = np.linalg.eig(cov_matrix)
    
    # Ordina per eigenvalues
    idx = eigenvalues.argsort()[::-1]
    eigenvectors = eigenvectors[:, idx]
    
    # L'asse Z dovrebbe puntare verso l'osservatore (asse con minore varianza)
    # L'asse Y dovrebbe puntare verso l'alto
    # L'asse X dovrebbe essere orizzontale
    
    # Crea una matrice di rotazione che allinea il viso
    # Assumiamo che l'asse con maggior varianza sia verticale (Y)
    # e quello con minor varianza sia la profondità (Z)
    
    return np.eye(3)  # Placeholder - ritorna identità per ora


def __predict(meshes, projections_number, args=None):
    mesh = meshes["mesh"]
    mesh_t = meshes["tensor"]
    
    # Verifica disponibilità GPU/CUDA
    cuda_available = o3d.core.cuda.is_available()
    device_str = "CUDA:0 (GPU)" if cuda_available else "CPU:0"
    print(f"🚀 Using device: {device_str}")
    if cuda_available:
        print(f"   GPU device count: {o3d.core.cuda.device_count()}")
    
    has_textures = hasattr(mesh, 'textures') and len(mesh.textures) > 0
    has_vertex_colors = mesh.has_vertex_colors()

    if not has_textures and not has_vertex_colors:
        print("WARNING: Mesh has no vertex colors or textures. Using default gray.")
        mesh.paint_uniform_color([0.7, 0.7, 0.7])

### PROJECTIONS AND LANDMARKS
    detector = detectorInit()

    # OffscreenRenderer: EGL-based headless rendering, no X11 or Xvfb required
    configure_headless_rendering()
    renderer = o3d.visualization.rendering.OffscreenRenderer(IMG_SIZE, IMG_SIZE)
    renderer.scene.set_background([0, 0, 0, 1])

    # For textured meshes, use read_triangle_model + add_model to preserve UV mapping.
    # add_geometry() ignores triangle_uvs, producing scrambled textures.
    _tmpdir = None
    if has_textures:
        _tmpdir = tempfile.mkdtemp()
        tmp_obj = os_module.path.join(_tmpdir, "mesh.obj")
        o3d.io.write_triangle_mesh(tmp_obj, mesh)
        model = o3d.io.read_triangle_model(tmp_obj)
        renderer.scene.add_model("face", model)
        print(f"Loaded textured model ({len(mesh.textures)} texture(s))")
    else:
        mat = o3d.visualization.rendering.MaterialRecord()
        mat.shader = "defaultUnlit"
        renderer.scene.add_geometry("face", mesh, mat)

    # FOV 50° = Visualizer default (60°) adjusted by change_field_of_view(step=-10)
    FOV_DEG = 50.0
    fov_rad = np.radians(FOV_DEG)

    # Position the camera so the mesh bounding sphere fills the frame
    bbox = mesh.get_axis_aligned_bounding_box()
    mesh_radius = np.linalg.norm(bbox.get_extent()) / 2
    camera_distance = mesh_radius / np.tan(fov_rad / 2)

    renderer.scene.camera.set_projection(
        FOV_DEG, 1.0,
        camera_distance * 0.01, camera_distance * 10,
        o3d.visualization.rendering.Camera.FovType.Vertical
    )

    # Intrinsic matrix used for perspective ray backprojection during raycasting
    f = (IMG_SIZE / 2) / np.tan(fov_rad / 2)
    intr_mat = np.array([[f, 0, IMG_SIZE / 2],
                         [0, f, IMG_SIZE / 2],
                         [0, 0, 1]])

    # Rotazioni camera per coprire meglio il viso, specialmente occhi e parte superiore
    # Yaw (rotazione sinistra-destra): -30° a +30° (ridotto per viste più frontali)
    y_rots = np.random.uniform(-np.pi/6, np.pi/6, projections_number)
    # Pitch (rotazione su-giù): -50° a +20° per enfatizzare fronte e occhi (viste dall'alto)
    x_rots = np.random.uniform(-5*np.pi/18, np.pi/9, projections_number)
    # Roll: manteniamo a 0 (non ruotiamo la testa)
    camera_rots = [ np.asarray(o3d.geometry.get_rotation_matrix_from_axis_angle([x,y,0])) for x,y in zip(x_rots, y_rots) ]

    print(f"📐 Camera angles: Yaw ±{np.degrees(np.pi/6):.0f}°, Pitch {np.degrees(-5*np.pi/18):.0f}° to +{np.degrees(np.pi/9):.0f}°")

    views = {i:[] for i in range(478)}
    camera_data = []  # Array per posizioni/direzioni camere
    landmark_candidates = {i: [] for i in range(478)}  # Candidati 3D per ogni landmark
    
    detection_count = 0

    print(f"\n🔄 Starting projection loop with {projections_number} rotations...")

    for idx, camera_r in enumerate(camera_rots):
        # Progress ogni 50 proiezioni
        if idx > 0 and idx % 50 == 0:
            print(f"Progress: {idx}/{projections_number} ({idx/projections_number*100:.1f}%) - {detection_count} faces detected so far")

        camera_pos = (camera_r @ np.array([0, 0, 1])) * camera_distance
        up = camera_r @ np.array([0, 1, 0])
        renderer.scene.camera.look_at([0, 0, 0], camera_pos.tolist(), up.tolist())

        img = np.asarray(renderer.render_to_image())[:, :, :3]

        detection_result = detector.detect(mpImage(img))

        if not detection_result.face_landmarks:
            continue

        detection_count += 1

    ### HPR
        mp_mesh = o3d.t.geometry.TriangleMesh(
            o3d.core.Tensor([[p.x,-p.y,-p.z] for p in detection_result.face_landmarks[0]], dtype=o3d.core.Dtype.Float32),
            o3d.core.Tensor(TRIANGLES)
        )
        mp_mesh.translate( - mp_mesh.get_axis_aligned_bounding_box().get_center().numpy()  )

        visible_points = hpr_mesh_based(mp_mesh, [0,0,1])

        landmarks = [ [p.x,p.y,0] for p in detection_result.face_landmarks[0] ]
        # visible_points può essere una tupla (np.where result) - estrai l'array
        visible_indices = visible_points[0] if isinstance(visible_points, tuple) else visible_points
        landmarks = np.asarray(landmarks)[visible_indices]

        persp_rays = perspective_rays_directions(landmarks, IMG_SIZE, intr_mat)

        world_rays = (persp_rays * [1,-1,-1]) @ np.linalg.inv(camera_r)

        # camera_pos already computed above as the eye position
        camera_data.append(camera_pos.copy())

        # Salva i raggi usando gli indici visibili - usa enumerate per indici corretti
        for idx, landmark_idx in enumerate(visible_indices):
            views[landmark_idx].append(
                np.asarray(
                    [*camera_pos, *world_rays[idx]],  # idx per world_rays, landmark_idx per views
                    dtype=np.float32
                )
            )

    del renderer
    
    print(f"\n📊 Detection statistics: {detection_count}/{projections_number} projections detected a face ({detection_count/projections_number*100:.1f}%)")
    
    # Conta quanti landmarks hanno almeno un raggio
    detected_landmarks = sum(1 for rays in views.values() if len(rays) > 0)
    print(f"📍 Landmarks with rays: {detected_landmarks}/{len(views)}")
    
    if detection_count == 0:
        print(f"\n❌ ERROR: No face detected in any projection.")
        print("   Suggestions:")
        print("   - Check that the mesh is a face and properly oriented")
        print("   - Try disabling auto-alignment with --no-auto-align")
        print("   - Increase field of view with --fov-adjustment -20 or -30")
        print("   - Increase number of projections with -p 1000")
        if _tmpdir is not None:
            shutil.rmtree(_tmpdir, ignore_errors=True)
        return None, None

    min_required = max(10, int(projections_number * 0.1))
    if detected_landmarks < min_required:
        print(f"\n❌ ERROR: Only {detected_landmarks} landmarks detected, minimum required: {min_required}")
        print("   Try increasing number of projections with -p 1000")
        if _tmpdir is not None:
            shutil.rmtree(_tmpdir, ignore_errors=True)
        return None, None


### RAYCASTING
    print(f"\n🎯 Starting raycasting for {detected_landmarks} landmarks...")
    landmarks_3d = []

    scene = o3d.t.geometry.RaycastingScene()
    scene.add_triangles(mesh_t)

    processed_landmarks = 0
    for i,rays in views.items():
        if len(rays)==0: continue  # Silenzioso per non spammare
        
        processed_landmarks += 1
        if processed_landmarks % 50 == 0:
            print(f"Raycasting progress: {processed_landmarks}/{detected_landmarks} landmarks")

        rays = np.asarray(rays)
        ans = scene.cast_rays(o3d.core.Tensor(rays,dtype=o3d.core.Dtype.Float32))

        hits = ans['t_hit'].numpy()
        origins = rays[:,:3]
        directions = rays[:,3:]

        points = origins + directions * hits.reshape(-1, 1)
        
        # Salva tutti i candidati per questo landmark
        valid_points = points[np.isfinite(hits)]
        for pt in valid_points:
            landmark_candidates[i].append(pt)
        
        landmarks_3d.append(np.median(points[np.isfinite(hits)], axis=0).tolist())

    # Controllo se sono stati trovati abbastanza landmarks
    if len(landmarks_3d) == 0:
        print(f"\n❌ ERROR: No landmarks detected. The face might not be visible from the camera angles.")
        print("   Suggestions:")
        print("   - Try disabling auto-alignment with --no-auto-align")
        print("   - Increase field of view with --fov-adjustment -20 or -30")
        print("   - Increase number of projections with -p 1000")
        if _tmpdir is not None:
            shutil.rmtree(_tmpdir, ignore_errors=True)
        return None, None

    if len(landmarks_3d) < 100:
        print(f"\n⚠️  WARNING: Only {len(landmarks_3d)}/478 landmarks detected. Results may be incomplete.")

    # Ricarica la mesh originale e applica le stesse trasformazioni (come nel backend)
    # Questo garantisce che le coordinate siano nello stesso spazio
    # IMPORTANTE: Usa enable_post_processing=True come nella import_mesh() per mantenere gli indici consistenti
    mesh_path = meshes["mesh_path"]
    original_cwd = os_module.getcwd()
    os_module.chdir(os_module.path.dirname(os_module.path.abspath(mesh_path)))
    
    try:
        actual_mesh = o3d.io.read_triangle_mesh(os_module.path.basename(mesh_path), enable_post_processing=True)
    finally:
        os_module.chdir(original_cwd)
    
    # Applica le stesse trasformazioni che abbiamo applicato alla mesh per rendering/raycasting
    scale = meshes["transform_scale"]
    center = meshes["transform_center"]
    actual_mesh.scale(scale, center)
    actual_mesh.translate(-center)
    
    vertices_distances = scipy.spatial.distance.cdist(np.asarray(landmarks_3d), np.asarray(actual_mesh.vertices))
    closest_vertices_ids = [ int(np.argmin(x)) for x in vertices_distances ]

    print(f"\n✅ Successfully detected {len(landmarks_3d)} landmarks")

    if _tmpdir is not None:
        shutil.rmtree(_tmpdir, ignore_errors=True)

    return landmarks_3d, closest_vertices_ids, camera_data, landmark_candidates


def predict(args):
    """Wrapper function che chiama __predict con i parametri corretti"""
    return __predict(args.meshes, args.projections_number, args)
