"""
测试使用Cookie（sessionid）进行FastAPI认证
"""

import sys
import os
import json
import redis
from fastapi import FastAPI, Depends, Request
from fastapi.testclient import TestClient
from mwauth.fastapi_auth import FastApiKongAuth, FastApiSessionMiddleware

# 添加项目路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# 创建应用实例
app = FastAPI(
    title="Cookie Authentication Test",
    description="测试使用Cookie sessionid的FastAPI认证",
    version="1.0.0"
)

# 您提供的JWT令牌作为sessionid
SESSION_ID = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJleHAiOjE3NTQyOTIxNTQsImlzcyI6ImZjT09NWlJXZlR1YmczM3ZiZk9DUWlFNUtpdW1MTFMxIn0.zb04GZOrrDLtibnK3vQZWbbUUQj4WFO6rrWkYd6L9_Q"

# Redis连接配置
redis_client = redis.Redis(host='192.168.101.78', port=30033, db=0, decode_responses=False)

# 初始化认证实例
auth = FastApiKongAuth(redis_client=redis_client)

# 添加会话中间件
app.add_middleware(FastApiSessionMiddleware, redis_client=redis_client)

@app.get("/")
async def root(request: Request, current_user = Depends(auth.get_current_user())):
    """
    需要认证的根路由
    """
    return {
        "message": "Hello World",
        "user": {
            "uid": current_user.uid,
            "uname": current_user.uname,
            "systemuser": current_user.systemuser,
            "manageuser": current_user.manageuser,
            "companyid": current_user.companyid,
            "type": current_user.type,
            "phone": current_user.phone
        }
    }

@app.get("/protected")
async def protected_route(
    request: Request,
    current_user = Depends(auth.get_current_user())
):
    """
    受保护的路由，需要认证
    """
    return {
        "message": "This is a protected route",
        "user_info": {
            "uid": current_user.uid,
            "uname": current_user.uname,
            "type": current_user.type
        }
    }

def test_with_cookie_sessionid():
    """
    使用Cookie中的sessionid测试认证功能
    """
    print("🍪 开始测试Cookie sessionid认证...")
    print(f"🔑 使用sessionid: {SESSION_ID[:20]}...{SESSION_ID[-10:]}")
    
    # 使用TestClient进行测试
    client = TestClient(app)
    
    # 准备带有sessionid cookie的请求
    cookies = {
        "sessionid": SESSION_ID
    }
    
    print("\n📋 测试步骤:")
    print("1. 使用Cookie sessionid测试根路由 (/)")
    response = client.get("/", cookies=cookies)
    print(f"   响应状态: {response.status_code}")
    if response.status_code == 200:
        print(f"   响应数据: {response.json()}")
    else:
        print(f"   错误信息: {response.text}")
    
    print("\n2. 使用Cookie sessionid测试保护路由 (/protected)")
    response = client.get("/protected", cookies=cookies)
    print(f"   响应状态: {response.status_code}")
    if response.status_code == 200:
        print(f"   响应数据: {response.json()}")
    else:
        print(f"   错误信息: {response.text}")

def test_manual_redis_verification():
    """
    手动验证Redis中的会话数据
    """
    print("\n🔍 手动验证Redis中的Cookie会话数据...")
    
    try:
        # 尝试获取sessionid对应的会话数据
        session_key = f"session:{SESSION_ID}"
        session_data = redis_client.get(session_key)
        
        if session_data:
            print(f"✅ 在Redis中找到会话数据，键: {session_key}")
            print(f"   会话数据: {session_data}")
            # 解析JSON数据
            try:
                parsed_data = json.loads(session_data)
                print(f"   解析后的数据: {parsed_data}")
            except json.JSONDecodeError:
                print("   ❌ 无法解析JSON数据")
        else:
            print(f"❌ 在Redis中未找到键为 '{session_key}' 的会话数据")
        
        # 预期的会话数据（根据您提供的用户信息）
        expected_session_data = {
            "uid": "349643",
            "uname": "13712363409",
            "systemuser": False,
            "manageuser": False,
            "manageuserid": "",
            "companyid": "",
            "type": "member",
            "locale": "zh-CN",
            "email": "cxhjet@qq.com",
            "phone": "13712363409",
            "timezone": None
        }
        
        print(f"\n📝 预期的会话数据: {expected_session_data}")
        
    except Exception as e:
        print(f"❌ 验证Redis数据时发生错误: {e}")

if __name__ == "__main__":
    print("🍪 FastAPI Cookie 认证测试工具")
    print("=" * 50)
    
    # 执行手动Redis验证
    test_manual_redis_verification()
    
    # 执行API测试
    test_with_cookie_sessionid()
    
    print("\n" + "=" * 50)
    print("✅ Cookie测试完成")