"""
快速测试 FastAPI 认证模块是否正确导入
"""
try:
    from mwauth.fastapi_auth import FastApiKongAuth, FastApiSessionMiddleware, FastApiRedisSession
    print("✅ FastAPI 认证模块导入成功!")
    
    # 检查主要组件是否存在
    print(f"✅ FastApiKongAuth 类存在: {FastApiKongAuth}")
    print(f"✅ FastApiSessionMiddleware 类存在: {FastApiSessionMiddleware}")
    print(f"✅ FastApiRedisSession 类存在: {FastApiRedisSession}")
    
    print("\n🎉 FastAPI 认证模块已成功实现!")
    print("\n主要功能:")
    print("- FastAPI Redis 会话管理")
    print("- Kong JWT 认证支持")
    print("- 签名验证功能")
    print("- 电话验证码验证")
    print("- 与 Flask 版本兼容的 API 设计")
    
except ImportError as e:
    print(f"❌ 导入失败: {e}")
except Exception as e:
    print(f"❌ 发生错误: {e}")