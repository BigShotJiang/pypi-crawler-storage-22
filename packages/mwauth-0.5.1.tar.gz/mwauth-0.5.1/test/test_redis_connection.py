"""
测试 Redis 连接和 JWT 数据
"""
from redis import Redis

# 初始化 Redis 客户端
redis_client = Redis(host='192.168.101.78', port=30033, db=0, decode_responses=False)

# JWT token
jwt_token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJleHAiOjE3NTQyOTIxNTQsImlzcyI6ImZjT09NWlJX" \
             "ZlR1YmczM3ZiZk9DUWlFNUtpdW1MTFMxIn0.zb04GZOrrDLtibnK3vQZWbbUUQj4WFO6rrWkYd6L9_Q"

print("测试 Redis 连接...")
try:
    # 测试连接
    redis_client.ping()
    print("✓ Redis 连接成功")
except Exception as e:
    print(f"✗ Redis 连接失败: {e}")
    exit(1)

print("\n检查 JWT 数据...")
# 尝试不同的 key 格式
keys_to_check = [
    jwt_token,
    f"session:{jwt_token}",
    f"session:{jwt_token}",
]

for key in keys_to_check:
    print(f"\n检查 key: {key}")
    try:
        value = redis_client.get(key)
        if value:
            print(f"✓ 找到数据: {value.decode()}")
        else:
            print(f"✗ 未找到数据")
    except Exception as e:
        print(f"✗ 查询失败: {e}")

print("\n列出所有 session 相关的 keys...")
try:
    keys = redis_client.keys("session:*")
    print(f"找到 {len(keys)} 个 session key")
    for key in keys[:10]:  # 只显示前10个
        print(f"  - { {key.decode()} }")
except Exception as e:
    print(f"✗ 查询失败: {e}")

print("\n尝试设置测试数据...")
test_data = {
    "uid": "349643",
    "uname": "13712363409",
    "systemuser": False,
    "manageuser": False,
    "manageuserid": "",
    "companyid": "",
    "type": "member",
    "locale": "zh-CN",
    "email": "cxhjet@qq.com",
    "phone": "13712363409",
    "timezone": None
}

import json
try:
    redis_client.set(jwt_token, json.dumps(test_data))
    print(f"✓ 成功设置 JWT 数据到 key: {jwt_token}")
    
    # 验证
    value = redis_client.get(jwt_token)
    if value:
        print(f"✓ 验证成功: {value.decode()}")
except Exception as e:
    print(f"✗ 设置失败: {e}")

redis_client.close()
