from .permission import Permission, PermissionError
from .permission_fastapi import FastAPIPermission  # 导入 permission-fastapi.py

__all__ = ['Permission', 'FastAPIPermission', 'PermissionError']
