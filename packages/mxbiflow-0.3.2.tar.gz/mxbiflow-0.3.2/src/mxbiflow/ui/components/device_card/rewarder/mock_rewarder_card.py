from pymxbi.rewarder import MockRewarderModel

from ..device_card import DeviceCard


class MockRewarderCard(DeviceCard[MockRewarderModel]):
    def __init__(self):
        super().__init__()
        self.set_title("Mock Rewarder")

    def load_config(self, model: MockRewarderModel) -> None:
        self.checkbox_enabled.setChecked(model.enabled)
        self.line_device_id.setText(str(model.id))

    @property
    def result(self) -> MockRewarderModel:
        return MockRewarderModel(
            enabled=self.checkbox_enabled.isChecked(),
            id=int(self.line_device_id.text()),
        )
