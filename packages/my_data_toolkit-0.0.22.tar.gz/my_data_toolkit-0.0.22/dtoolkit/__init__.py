import dtoolkit.accessor  # noqa: F401
from dtoolkit._version import get_versions

__version__ = get_versions()["version"]
del get_versions
