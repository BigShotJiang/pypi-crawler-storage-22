# my_sys_info

A beginner-friendly Python package that gathers system and network information.

## Features

- **Get Current Local Time**: Retrieve the current date and time in a readable format
- **Get Public IP Address**: Fetch your public IP using the ipify API
- **Get Location Information**: Determine your city, region, and country based on your IP using ip-api
- **Get Device OS Information**: Retrieve operating system details using the platform library
- **Get Author Name**: Returns a hardcoded author name

## Installation

### Install in Editable Mode (for development)

Navigate to the package directory and install it in editable mode:

```bash
cd e:\PROJECTS\demo-package
pip install -e .
```

This allows you to make changes to the code and test them immediately without reinstalling.

### Regular Installation

```bash
pip install .
```

## Usage

### Import and Use Individual Functions

```python
from my_sys_info import get_current_time, get_public_ip, get_location_from_ip, get_author_name, get_device_os

# Get current time
print(get_current_time())

# Get public IP
ip = get_public_ip()
print(ip)

# Get location
location = get_location_from_ip()
print(location)

# Get author name
print(get_author_name())

# Get OS information
os_info = get_device_os()
print(os_info)
```

### Get All Information at Once

```python
from my_sys_info import get_all_info

info = get_all_info()
print(info)
```

## Requirements

- Python 3.7 or higher
- requests library (automatically installed with the package)

## API Services Used

- **ipify API**: https://www.ipify.org/ - For getting public IP address
- **ip-api**: http://ip-api.com/ - For getting location information (free for non-commercial use)

## License

MIT License

## Author

Your Name
