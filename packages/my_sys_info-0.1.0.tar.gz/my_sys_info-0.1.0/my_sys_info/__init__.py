"""
my_sys_info - A simple package to gather system and network information
"""

from .info_tools import (
    get_current_time,
    get_public_ip,
    get_location_from_ip,
    get_author_name,
    get_device_os,
    get_all_info
)

__version__ = "0.1.0"

__all__ = [
    "get_current_time",
    "get_public_ip",
    "get_location_from_ip",
    "get_author_name",
    "get_device_os",
    "get_all_info"
]
