"""
Core functions for gathering system and network information
"""

import platform
from datetime import datetime
import requests


def get_current_time():
    """
    Get the current local time.
    
    Returns:
        str: Current local time in a readable format
    """
    now = datetime.now()
    return now.strftime("%Y-%m-%d %H:%M:%S")


def get_public_ip():
    """
    Get the user's public IP address using the ipify API.
    
    Returns:
        str: Public IP address or error message
    """
    try:
        response = requests.get("https://api.ipify.org?format=json", timeout=5)
        response.raise_for_status()
        return response.json()["ip"]
    except requests.RequestException as e:
        return f"Error fetching IP: {str(e)}"


def get_location_from_ip(ip_address=None):
    """
    Get the user's city/location based on their IP address using ip-api.
    
    Args:
        ip_address (str, optional): IP address to lookup. If None, uses current public IP.
    
    Returns:
        dict: Location information including city, region, country, etc.
    """
    if ip_address is None:
        ip_address = get_public_ip()
        if "Error" in ip_address:
            return {"error": "Could not determine IP address"}
    
    try:
        response = requests.get(f"http://ip-api.com/json/{ip_address}", timeout=5)
        response.raise_for_status()
        data = response.json()
        
        if data["status"] == "success":
            return {
                "city": data.get("city", "Unknown"),
                "region": data.get("regionName", "Unknown"),
                "country": data.get("country", "Unknown"),
                "zip": data.get("zip", "Unknown"),
                "lat": data.get("lat", "Unknown"),
                "lon": data.get("lon", "Unknown"),
                "timezone": data.get("timezone", "Unknown"),
                "isp": data.get("isp", "Unknown")
            }
        else:
            return {"error": data.get("message", "Failed to get location")}
    except requests.RequestException as e:
        return {"error": f"Error fetching location: {str(e)}"}


def get_author_name():
    """
    Return the hardcoded author name.
    
    Returns:
        str: Author name
    """
    return "John Doe"


def get_device_os():
    """
    Get the device operating system information.
    
    Returns:
        dict: OS information including system, release, version, and machine type
    """
    return {
        "system": platform.system(),
        "release": platform.release(),
        "version": platform.version(),
        "machine": platform.machine(),
        "processor": platform.processor()
    }


def get_all_info():
    """
    Gather all information in one convenient function.
    
    Returns:
        dict: Dictionary containing all system and network information
    """
    ip = get_public_ip()
    location = get_location_from_ip(ip)
    
    return {
        "current_time": get_current_time(),
        "public_ip": ip,
        "location": location,
        "author": get_author_name(),
        "os_info": get_device_os()
    }
