# Quick Release Script for v0.2.0
# Run this in PowerShell

Write-Host "=== mycontext v0.2.0 Release Script ===" -ForegroundColor Cyan
Write-Host ""

# Change to project directory
Set-Location "C:\Users\dpokh\Desktop\mycontext"

Write-Host "Step 1: Building package..." -ForegroundColor Yellow
Remove-Item -Recurse -Force dist -ErrorAction SilentlyContinue
python -m build
Write-Host "✅ Build complete!" -ForegroundColor Green
Write-Host ""

Write-Host "Step 2: Ready to upload to PyPI" -ForegroundColor Yellow
Write-Host "Run: twine upload dist/*" -ForegroundColor White
Write-Host ""

Write-Host "Step 3: Git commands (copy & paste):" -ForegroundColor Yellow
Write-Host @"
git init
git add .
git commit -m "feat: Release v0.2.0 - Complete context engineering platform"
git remote add origin https://github.com/SadhiraAI/mycontext.git
git push -u origin main
git tag -a v0.2.0 -m "Release v0.2.0"
git push origin v0.2.0
"@ -ForegroundColor White

Write-Host ""
Write-Host "📋 Full instructions in RELEASE_GUIDE.md" -ForegroundColor Cyan
Write-Host "🚀 Ready to release!" -ForegroundColor Green
