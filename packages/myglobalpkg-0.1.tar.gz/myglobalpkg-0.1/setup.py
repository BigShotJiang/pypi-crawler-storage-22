from setuptools import setup, find_packages

setup(
    name="myglobalpkg",
    version="0.1",
    packages=find_packages(),
)
from setuptools import setup, find_packages

setup(
    name="myglobalpkg",
    version="0.1",
    packages=find_packages(),
)
