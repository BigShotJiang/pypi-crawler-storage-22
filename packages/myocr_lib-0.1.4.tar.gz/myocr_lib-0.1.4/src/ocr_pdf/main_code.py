
import ocrmypdf
import fitz  # PyMuPDF
import subprocess
import os

class OCRDataExtractor:
    def __init__(self, input_pdf_path):

        # variables section
        self.input_pdf_path = input_pdf_path
        self.output_file_path = input_pdf_path.replace('.pdf','_output.pdf')
        self.pages_to_ocr = [] # holds the pages needing ocr 


    def _raise_for_ocr_results(self, result):
        """This function raises the corresponding and matching exceptions based on the value of thre result code."""
        # key for the exceptions code
        exceptions_codes = {exc:"" for exc in [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 15, 130]}

        return_code = result.returncode

        match return_code:
            case 1:
                raise Exception("Invalid arguments were provided.")

            case 2:
                raise Exception("The input file is not a valid PDF.")

            case 3:
                raise Exception("An external program (like Tesseract or Ghostscript) required by OCRmyPDF is missing.")
            
            case 4: 
                raise Exception("An output file was created, but it is invalid (the file will still be produced).")

            case 5: 
                raise Exception("Insufficient permissions to read the input or write the output file.")
            
            case 6:
                raise Exception("The file already contains text, and the command was not configured to force re-processing.")
            
            case 7: 
                raise Exception("An error occurred in an external program (e.g., Ghostscript).")
            
            case 8:
                raise Exception("The input PDF is encrypted and cannot be processed.")
            
            case 9:
                raise Exception("Tesseract rejected a custom configuration file.")
            
            case 10: 
                raise Exception("A valid PDF was created, but conversion to PDF/A failed.")

            case 15:
                raise Exception("An unexpected or other error occurred.")

            case 130:
                raise Exception("The program was interrupted by the user (Ctrl+C). ")


    def _apply_whole_pdf_ocr(self):
        # Define the Commands
        command = [
            "ocrmypdf",
            f"{self.input_pdf_path}",
            f"{self.output_file_path}",
            # "--force-ocr",
            "--tesseract-timeout", "1000" # increased timeout
        ]

        # run the command
        result = subprocess.run(command, capture_output=True, text=True)
        
        try:
            self._raise_for_ocr_results(result)

        except Exception as e:
            print("Error during OCR process:\n", str(e))

            if result.returncode == 6: # already has text
                print("Retrying using forcing..")
                # use force ocr 
                # Define the Commands
                command = [
                    "ocrmypdf",
                    f"{self.input_pdf_path}",
                    f"{self.output_file_path}",
                    "--force-ocr",
                    "--tesseract-timeout", "1000" # increased timeout
                ]

                # run the command
                result = subprocess.run(command, capture_output=True, text=True)

            else:
                raise e


        if result.returncode == 0:
            print("OCR Was applied on the PDF.")
        
            return True
        
        return False
    

    ########### Ratio Functions
    def _text_coverage_ratio(self,page):
        blocks = page.get_text("blocks")
        page_area = page.rect.width * page.rect.height

        text_area = 0
        for block in blocks:
            if block[6] == 0:  # text block
                x0, y0, x1, y1 = block[:4]
                text_area += (x1 - x0) * (y1 - y0)

        return text_area / page_area if page_area else 0

    def _image_coverage_ratio(self, page):
        images = page.get_images(full=True)
        page_area = page.rect.width * page.rect.height
        image_area = 0

        for img in images:
            xref = img[0]
            rects = page.get_image_rects(xref)
            for r in rects:
                image_area += r.width * r.height

        return image_area / page_area if page_area else 0

    def _is_whole_pdf_ocr(self):
        # read and extract the whole text from the pdf
        THRESHOLD_VALUE = 100 # minimum text
        is_whole_pdf_ocr_applicable = True

        with fitz.open(self.input_pdf_path) as doc:
            for page_num in range(len(doc)):
                page = doc.load_page(page_num)
                text = page.get_text()

                # add logic if the image and text ratio is above a certain threshold
                image_ratio = self._image_coverage_ratio(page)
                text_ratio = self._text_coverage_ratio(page)
                print(f"Image :\t{image_ratio*100:.2f}")


                # if len(text.strip()) > THRESHOLD_VALUE:
                if image_ratio > 0.45:
                    # print("Length of text:\n", len(text.strip()))
                    print(f"Image :\t{image_ratio*100:.2f}")
                    # append to the page list
                    self.pages_to_ocr.append(page_num)

                elif text_ratio < 0.05:
                    print(f"Text :\t{text_ratio*100:.2f}")
                    # append to the page list
                    self.pages_to_ocr.append(page_num)

                else:
                    is_whole_pdf_ocr_applicable = False
            
        return is_whole_pdf_ocr_applicable
    
    ########### Page by Page Functions
    def _is_page_by_page_ocr(self):
        return len(self.pages_to_ocr) > 0
    

    def _apply_page_by_page_ocr(self):
        # apply the ocr on all the pages needed ocr separately
        pages_str_format = ','.join(str(page+1) for page in self.pages_to_ocr)  # Convert to 1-based indexing

        print("Pages to extract text from...", pages_str_format)

        # Define the Commands
        command = [
            "ocrmypdf",
            f"{self.input_pdf_path}",
            f"{self.output_file_path}",
            # "--force-ocr",
            '--pages',pages_str_format,
            "--tesseract-timeout", "1000" # increased timeout
        ]

        # run the command
        result = subprocess.run(command, capture_output=True, text=True)
        
        if result.returncode == 0:
            print("Ocr was applied on the pages.")
        
            return True
        
        return False
    

    def _extract_text_whole_pdf(self):
        text = {}
        text = ""
        with fitz.open(self.output_file_path) as doc:
            # Iterate through each page
            for page_num in range(len(doc)):
                page = doc.load_page(page_num)
                # text[page_num] = page.get_text()
                text += f'Page {page_num + 1} Text\n' + '*' * 20 + page.get_text() + '\n\n'

        return text

    def _extract_text_page_by_page(self):
        text = {}

        with fitz.open(self.output_file_path) as doc:
            for page_num in self.pages_to_ocr:
                page = doc.load_page(page_num)
                text[page_num] = page.get_text()

        return text
    

    def get_ocr_results(self):
        # apply the whole pdf ocr if all the pages are extractable
        if self._is_whole_pdf_ocr():
            print("Applying whole Pdf ocr...")
            # empty the pages
            self.pages_to_ocr = []

            results = self._apply_whole_pdf_ocr()

            # apply the extraction for the whole pdf through fitz
            text = self._extract_text_whole_pdf() if results else None

            # print(text)

            # temporary store the text
            # ext = self.input_pdf_path.split('.')[-1]
            # with open(self.input_pdf_path.replace(ext,'txt'),'w') as file:
            #     file.write(text)

            # delete the output file
            self.delete_file(self.output_file_path)
            print("Done Successfully...")

            return text

        
        elif self._is_page_by_page_ocr():
            print("Applying page by page ocr...")

            # do page by page
            results = self._apply_page_by_page_ocr()

            # do the extraction for specific pages only throug fitz
            text = self._extract_text_page_by_page() if results else None

            # print(text)

            # delete the output file
            self.delete_file(self.output_file_path)
            print("Done...")

            return text

        else:
            # do normal extraction
            return None 

            print("No Ocr needed...")
            

        
    def delete_file(self, file):
        if os.path.exists(file):
            os.remove(file)
            

    def get_ocred_pages(self):
        return self.pages_to_ocr
    
    def run(self):

        text = self.get_ocr_results()
        pages_to_ignore = self.get_ocred_pages()

        return text, pages_to_ignore
    
    
    

        