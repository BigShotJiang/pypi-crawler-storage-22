"""Enable running the package as a module: python -m mysql_to_sheets"""

from mysql_to_sheets.cli.main import main

if __name__ == "__main__":
    main()
