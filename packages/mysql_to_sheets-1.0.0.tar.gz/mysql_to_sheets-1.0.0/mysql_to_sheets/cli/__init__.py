"""Command-line interface for MySQL to Google Sheets sync."""

from mysql_to_sheets.cli.main import cli, main

__all__ = ["main", "cli"]
