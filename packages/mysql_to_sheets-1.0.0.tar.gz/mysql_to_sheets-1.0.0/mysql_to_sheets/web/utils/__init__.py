"""Web utilities module."""

from mysql_to_sheets.web.utils.pagination import get_bounded_pagination

__all__ = ["get_bounded_pagination"]
