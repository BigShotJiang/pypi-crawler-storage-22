# myth-ai

Official Python SDK for the MYTH AI Public API - Programmatic access to MYTH AI's generative design capabilities.

## Installation

```bash
pip install myth-ai
```

## Authentication

All endpoints require a Bearer token. Get your API key from the MYTH AI dashboard.

```python
from myth_ai import ImagesApi, Configuration

config = Configuration(
    host='https://api.myth-ai.com',
    access_token='sk-myth-xxxxx'  # Your API key
)

images = ImagesApi(configuration=config)
```

## Quick Start

### List Images

```python
from myth_ai import ImagesApi, Configuration

config = Configuration(
    host='https://api.myth-ai.com',
    access_token='sk-myth-xxxxx'
)
images = ImagesApi(configuration=config)

result = images.list_images(page=1, page_size=10)

print(f'Total: {result.total}')
print('Images:', result.items)
```

### Create Image from Image

```python
import time
import uuid
from myth_ai import ImagesApi, Configuration, RepeatMode

config = Configuration(
    host='https://api.myth-ai.com',
    access_token='sk-myth-xxxxx'
)
images = ImagesApi(configuration=config)

# Create generation
result = images.create_image_to_image(
    idempotency_key=uuid.uuid4(),
    image_to_image_advanced_request={
        'url': 'https://example.com/inspiration.jpg',
        'width': 1024,
        'height': 1024,
        'sharpness': 7.5,
        'repeat_mode': RepeatMode.BLOCK
    }
)

print(f'Generation ID: {result.id}')

# Poll for completion
image = images.get_image(image_id=result.id)
while image.status in ('PENDING', 'PROCESSING'):
    time.sleep(2)
    image = images.get_image(image_id=result.id)
    print(f'Status: {image.status}')

if image.status == 'SUCCESS':
    print(f'Download URL: {image.url}')
```

### Upload and Generate

```python
import httpx
import uuid
from myth_ai import ImagesApi, UploadsApi, Configuration, RepeatMode

config = Configuration(
    host='https://api.myth-ai.com',
    access_token='sk-myth-xxxxx'
)
uploads = UploadsApi(configuration=config)
images = ImagesApi(configuration=config)

# Get presigned upload URL
upload_info = uploads.create_upload_url(
    idempotency_key=uuid.uuid4(),
    presigned_upload_request={
        'content_type': 'image/png'
    }
)

print(f'Artifact ID: {upload_info.artifact_id}')

# Upload file to S3
with open('inspiration.png', 'rb') as f:
    response = httpx.put(
        upload_info.presigned_url,
        content=f.read(),
        headers={'Content-Type': 'image/png'}
    )
    response.raise_for_status()

# Generate pattern using uploaded image
generation = images.create_image_to_image(
    idempotency_key=uuid.uuid4(),
    image_to_image_advanced_request={
        'url': upload_info.s3_url,
        'artifact_id': upload_info.artifact_id,
        'width': 1024,
        'height': 1024,
        'sharpness': 5.0,
        'repeat_mode': RepeatMode.HALF_DROP
    }
)

print(f'Generation ID: {generation.id}')
```

## API Endpoints

All URIs are relative to `https://api.myth-ai.com`

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/v1/images` | List images |
| `GET` | `/v1/images/{image_id}` | Get image details |
| `POST` | `/v1/images` | Image to Design (advanced) |
| `POST` | `/v1/images/extract` | Pattern extraction |
| `POST` | `/v1/images/prompt-to-image` | Image + Text to Design |
| `POST` | `/v1/images/seamless` | Make seamless |
| `POST` | `/v1/images/{image_id}/export` | Export image |
| `POST` | `/v1/uploads` | Get upload URL |

## Features

- **Full Type Hints** - Complete type annotations for IDE support
- **Async Support** - Works with async/await patterns
- **Idempotency** - Built-in support for idempotent requests
- **Context Managers** - Automatic connection cleanup

## Async Usage

```python
import asyncio
import uuid
from myth_ai import ImagesApi, Configuration, RepeatMode
from myth_ai.api_client import ApiClient

async def main():
    config = Configuration(
        host='https://api.myth-ai.com',
        access_token='sk-myth-xxxxx'
    )

    async with ApiClient(configuration=config) as client:
        images = ImagesApi(client)

        result = await images.create_image_to_image_async(
            idempotency_key=uuid.uuid4(),
            image_to_image_advanced_request={
                'url': 'https://example.com/image.jpg',
                'width': 1024,
                'height': 1024,
                'sharpness': 7.5,
                'repeat_mode': RepeatMode.BLOCK
            }
        )

        print(f'Generation ID: {result.id}')

asyncio.run(main())
```

## Rate Limiting

Rate limits are enforced based on your plan:
- **Free**: 100 requests/hour (GET), 10/hour (POST)
- **Pro**: 1000 requests/hour (GET), 100/hour (POST)

## Requirements

- Python 3.9+
- `urllib3` >= 2.1.0
- `python-dateutil` >= 2.8.2
- `pydantic` >= 2
- `typing-extensions` >= 4.7.1

## Documentation

- [API Reference](https://api.myth-ai.com/docs) - Interactive API docs
- [Website](https://myth-design.com/) - Learn more about MYTH AI

## License

MIT
