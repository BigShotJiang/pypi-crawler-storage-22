from typing import List, Dict
from aiohttp import web

from myth_design_api.models.http_validation_error import HTTPValidationError
from myth_design_api.models.presigned_upload import PresignedUpload
from myth_design_api.models.presigned_upload_request import PresignedUploadRequest
from myth_design_api import util


async def create_upload_url(request: web.Request, idempotency_key, body) -> web.Response:
    """Get upload URL

    Get presigned S3 URL for direct file uploads.  Use this endpoint to obtain a temporary upload URL before uploading your image. This two-step process allows direct uploads to S3 storage.  **Workflow:** 1. Call this endpoint with your content type to get a presigned URL and artifact_id 2. Use the presigned_url to upload your file directly via PUT request 3. Use the artifact_id in subsequent generation requests  **Parameters:** - &#x60;content_type&#x60;: MIME type of file to upload (e.g., &#39;image/png&#39;, &#39;image/jpeg&#39;)  **Returns:** - &#x60;artifact_id&#x60;: Unique identifier for your uploaded file (use in generation requests) - &#x60;presigned_url&#x60;: Temporary URL for uploading (expires after a short time)  **Example Upload:** &#x60;&#x60;&#x60;bash # Step 1: Get presigned URL curl -X POST \&quot;/v1/uploads\&quot; -H \&quot;Authorization: Bearer sk-myth-xxxxx\&quot; \\   -d &#39;{\&quot;content_type\&quot;: \&quot;image/png\&quot;}&#39;  # Step 2: Upload file curl -X PUT \&quot;{presigned_url}\&quot; -H \&quot;Content-Type: image/png\&quot; \\   --data-binary \&quot;@/path/to/image.png\&quot;  # Step 3: Use artifact_id in generation curl -X POST \&quot;/v1/images/image-to-image\&quot; \\   -d &#39;{\&quot;url\&quot;: \&quot;s3://...\&quot;, \&quot;artifact_id\&quot;: \&quot;...\&quot;}&#39; &#x60;&#x60;&#x60;

    :param idempotency_key: Unique key (UUID v4) for idempotent POST requests. Duplicate requests with the same key return cached response for 24 hours.
    :type idempotency_key: str
    :type idempotency_key: str
    :param body: 
    :type body: dict | bytes

    """
    body = PresignedUploadRequest.from_dict(body)
    return web.Response(status=200)
