# coding: utf-8

import pytest
import json
from aiohttp import web

from myth_design_api.models.created_image import CreatedImage
from myth_design_api.models.export_image_request import ExportImageRequest
from myth_design_api.models.http_validation_error import HTTPValidationError
from myth_design_api.models.image import Image
from myth_design_api.models.image_list import ImageList
from myth_design_api.models.image_to_image_advanced_request import ImageToImageAdvancedRequest
from myth_design_api.models.image_to_image_request import ImageToImageRequest
from myth_design_api.models.pattern_extractor_request import PatternExtractorRequest
from myth_design_api.models.prompt_to_image_request import PromptToImageRequest
from myth_design_api.models.seamless_request import SeamlessRequest


pytestmark = pytest.mark.asyncio

async def test_create_extractor(client):
    """Test case for create_extractor

    Extract patterns
    """
    body = {"prompt":"prompt","url":"url"}
    headers = { 
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'idempotency_key': UUID('550e8400-e29b-41d4-a716-446655440000'),
        'Authorization': 'Bearer special-key',
    }
    response = await client.request(
        method='POST',
        path='/v1/images/extract',
        headers=headers,
        json=body,
        )
    assert response.status == 200, 'Response body is : ' + (await response.read()).decode('utf-8')


pytestmark = pytest.mark.asyncio

async def test_create_image_to_image(client):
    """Test case for create_image_to_image

    Image to Design - Transform single image into patterns
    """
    body = {"repeat_mode":"","width":0,"sharpness":1.4658129805029452,"url":"url","height":6}
    headers = { 
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'idempotency_key': UUID('550e8400-e29b-41d4-a716-446655440000'),
        'Authorization': 'Bearer special-key',
    }
    response = await client.request(
        method='POST',
        path='/v1/images/image-to-image',
        headers=headers,
        json=body,
        )
    assert response.status == 200, 'Response body is : ' + (await response.read()).decode('utf-8')


pytestmark = pytest.mark.asyncio

async def test_create_image_to_image_legacy(client):
    """Test case for create_image_to_image_legacy

    Create image-to-image (legacy)
    """
    body = {"repeat_mode":"","sharpness":0.8008281904610115,"url":"url"}
    headers = { 
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'idempotency_key': UUID('550e8400-e29b-41d4-a716-446655440000'),
        'Authorization': 'Bearer special-key',
    }
    response = await client.request(
        method='POST',
        path='/v1/images/image-to-image/legacy',
        headers=headers,
        json=body,
        )
    assert response.status == 200, 'Response body is : ' + (await response.read()).decode('utf-8')


pytestmark = pytest.mark.asyncio

async def test_create_prompt_to_image(client):
    """Test case for create_prompt_to_image

    Image and Text to Design - Combine image with prompt
    """
    body = {"repeat_mode":"","negative_prompt":"negative_prompt","width":6,"scale":0.8008281904610115,"sharpness":5.962133916683182,"prompt":"prompt","url":"url","height":1}
    headers = { 
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'idempotency_key': UUID('550e8400-e29b-41d4-a716-446655440000'),
        'Authorization': 'Bearer special-key',
    }
    response = await client.request(
        method='POST',
        path='/v1/images/prompt-to-image',
        headers=headers,
        json=body,
        )
    assert response.status == 200, 'Response body is : ' + (await response.read()).decode('utf-8')


pytestmark = pytest.mark.asyncio

async def test_create_seamless(client):
    """Test case for create_seamless

    Create seamless pattern
    """
    body = {"creativity":0.8008281904610115,"url":"url"}
    headers = { 
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'idempotency_key': UUID('550e8400-e29b-41d4-a716-446655440000'),
        'Authorization': 'Bearer special-key',
    }
    response = await client.request(
        method='POST',
        path='/v1/images/seamless',
        headers=headers,
        json=body,
        )
    assert response.status == 200, 'Response body is : ' + (await response.read()).decode('utf-8')


pytestmark = pytest.mark.asyncio

async def test_export_image(client):
    """Test case for export_image

    Export image
    """
    body = {"canvas_size":[6,6],"tile_size":[1,1],"repeat_axis":"","num_of_images":6,"dpi":114,"image_file_format":"image_file_format"}
    headers = { 
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'idempotency_key': UUID('550e8400-e29b-41d4-a716-446655440000'),
        'Authorization': 'Bearer special-key',
    }
    response = await client.request(
        method='POST',
        path='/v1/images/{image_id}/export'.format(image_id='image_id_example'),
        headers=headers,
        json=body,
        )
    assert response.status == 200, 'Response body is : ' + (await response.read()).decode('utf-8')


pytestmark = pytest.mark.asyncio

async def test_get_image(client):
    """Test case for get_image

    Get image details
    """
    headers = { 
        'Accept': 'application/json',
        'Authorization': 'Bearer special-key',
    }
    response = await client.request(
        method='GET',
        path='/v1/images/{image_id}'.format(image_id='image_id_example'),
        headers=headers,
        )
    assert response.status == 200, 'Response body is : ' + (await response.read()).decode('utf-8')


pytestmark = pytest.mark.asyncio

async def test_list_images(client):
    """Test case for list_images

    List images
    """
    params = [('page', 1),
                    ('page_size', 10)]
    headers = { 
        'Accept': 'application/json',
        'Authorization': 'Bearer special-key',
    }
    response = await client.request(
        method='GET',
        path='/v1/images',
        headers=headers,
        params=params,
        )
    assert response.status == 200, 'Response body is : ' + (await response.read()).decode('utf-8')

