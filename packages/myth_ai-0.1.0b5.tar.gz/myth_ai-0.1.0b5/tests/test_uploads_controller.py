# coding: utf-8

import pytest
import json
from aiohttp import web

from myth_design_api.models.http_validation_error import HTTPValidationError
from myth_design_api.models.presigned_upload import PresignedUpload
from myth_design_api.models.presigned_upload_request import PresignedUploadRequest


pytestmark = pytest.mark.asyncio

async def test_create_upload_url(client):
    """Test case for create_upload_url

    Get upload URL
    """
    body = {"content_type":"content_type"}
    headers = { 
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'idempotency_key': UUID('550e8400-e29b-41d4-a716-446655440000'),
        'Authorization': 'Bearer special-key',
    }
    response = await client.request(
        method='POST',
        path='/v1/uploads',
        headers=headers,
        json=body,
        )
    assert response.status == 200, 'Response body is : ' + (await response.read()).decode('utf-8')

