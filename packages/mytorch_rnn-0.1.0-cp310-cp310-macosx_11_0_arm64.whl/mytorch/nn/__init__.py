from mytorch.nn.linear import Linear
from mytorch.nn.activation import Sigmoid, Tanh
from mytorch.nn.loss import Criterion, SoftmaxCrossEntropy
