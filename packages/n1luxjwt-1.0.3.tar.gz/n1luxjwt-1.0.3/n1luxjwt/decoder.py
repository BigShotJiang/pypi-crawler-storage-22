import jwt

class N1LUXJwtdecode:
    def decode(self, token):
        try:
            if not token:
                return {"status": "error", "message": "Token is empty"}
            decoded_payload = jwt.decode(token, options={"verify_signature": False})
            
            return {
                "status": "success",
                "payload": decoded_payload
            }
        except Exception as e:
            return {
                "status": "error",
                "message": f"Failed to decode: {str(e)}"
            }