import requests
import logging

logger = logging.getLogger(__name__)

BD_VERSION_URL = (
    "https://bdversion.ggbluefox.com/live/ver.php"
    "?version=1.120.1"
    "&lang=ar"
    "&device=android"
    "&channel=android"
    "&appstore=googleplay"
    "&region=ME"
    "&whitelist_version=1.3.0"
    "&whitelist_sp_version=1.0.0"
    "&device_name=google%20G011A"
    "&device_CPU=ARMv7%20VFPv3%20NEON%20VMH"
    "&device_GPU=Adreno%20(TM)%20640"
    "&device_mem=1993"
)


def get_ob_raw():
    try:
        response = requests.get(BD_VERSION_URL, timeout=10)

        if response.status_code == 200:
            return response.json()

        logger.error(f"Invalid status code: {response.status_code}")
        return None

    except Exception as e:
        logger.error(f"Error fetching OB version: {e}")
        return None

def fetch_ob_version():
    data = get_ob_raw()

    if data is None:
        print("Error Fetching OB Version! Retrying once...")
        data = get_ob_raw()

    if data and data.get("code") == 0:
        ob_version = data.get("latest_release_version")
        print(f" OB VERSION FETCHED => {ob_version}")
        return ob_version

    print(" Failed to fetch OB Version. Using fallback.")
    return "OB52"