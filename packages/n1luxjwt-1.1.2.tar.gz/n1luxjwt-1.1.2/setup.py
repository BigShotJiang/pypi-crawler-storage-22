from setuptools import setup, find_packages
import codecs
import os

VERSION = '1.1.2'
DESCRIPTION = 'FF JWT TOKEN'
LONG_DESCRIPTION = 'A package to gen jwt auth token for ff login by jwt'

# Setting up
setup(
    name="n1luxjwt",
    version=VERSION,
    author="NR CODEX",
    author_email="nilaysingh.official@gmail.com",
    description=DESCRIPTION,
    long_description_content_type="text/markdown",
    long_description=LONG_DESCRIPTION,
    packages=find_packages(),
    install_requires=[],
    keywords=['python', 'tutorial', 'free fire', 'jwt token', 'nr codex'],
    classifiers=[
        "Development Status :: 1 - Planning",
        "Intended Audience :: Developers",
        "Programming Language :: Python :: 3",
        "Operating System :: Unix",
        "Operating System :: MacOS :: MacOS X",
        "Operating System :: Microsoft :: Windows",
    ]
)