# NaalScan 

A professional local vulnerability scanner for Python dependencies. 

## Features
* **Local Database**: Scans against a pre-mapped `db.json` for high speed.
* **Security Audit**: Identifies vulnerable package versions in your requirements.
* **Advisory Details**: Provides specific security advice for found vulnerabilities.

## Installation
```bash
pip install naalscan