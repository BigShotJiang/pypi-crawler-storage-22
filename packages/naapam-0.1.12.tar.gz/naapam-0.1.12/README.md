# TODO

- [ ] 仔细调整max_freq_temN
- [ ] 实在不行，保底拟合矫正del长度
- [ ] 利用可视化技术精确定位不好的reads
- [ ] mermaid diagram README for workflow

# Package

- [ ] format jupyter-notebook
- [ ] github action

# Dependencies

- bowtie2
- gawk
