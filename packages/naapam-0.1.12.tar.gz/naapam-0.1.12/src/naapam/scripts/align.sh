rearr() {
    local query
    local ref
    read query ref <<<$@
    local align_dir="$(dirname "$(dirname "$(dirname "${query}")")")/align/raw"
    local align_file="$(basename "${query}")"
    align_file="${align_dir}/${align_file%.query}.alg"
    local line_num="$(wc -l < "${ref}")"

    mkdir -p ${align_dir}
    rearrangement \
        < ${query} \
        3< ${ref} |
    correct_micro_homology.awk -- \
        ${ref} \
        <(yes up | head -n${line_num}) \
        > ${align_file}
}

query_ref() {
    local root_dir=$1
    local query
    local chip
    local ref
    for query in $(find "${root_dir}/query/found" -name "*.query")
    do
        chip="$(
            basename "${query}" |
            sed -E \
                -e 's/.*/\L&/' \
                -e 's/^.+-(a1|a2|a3|g1n|g2n|g3n)-.+$/\1/'
        )"
        ref="${root_dir}/ref/${chip}.ref"
        printf "%s\t%s\n" ${query} ${ref}
    done
}

export -f rearr
root_dir=$1

parallel -a <(query_ref ${root_dir}) --jobs 24 rearr
