'''
| Author:   Ezio416
| Created:  2024-05-07
| Modified: 2026-02-04

- A library to assist with accessing Nadeo's web services API and the public Trackmania API (OAuth2).
- This is the main module - most of what you need is in sub-modules.
'''

from .util import *  # NOQA


__version__: tuple = 0, 8, 0
