# copyright @analytics with harry
"""
Discriminant Analysis for Nalyst.
"""

from nalyst.discriminant.lda import LinearDiscriminantAnalysis
from nalyst.discriminant.qda import QuadraticDiscriminantAnalysis

__all__ = [
    "LinearDiscriminantAnalysis",
    "QuadraticDiscriminantAnalysis",
]

# copyright @analytics with harry
