"""Pattern catalog and loaders."""
