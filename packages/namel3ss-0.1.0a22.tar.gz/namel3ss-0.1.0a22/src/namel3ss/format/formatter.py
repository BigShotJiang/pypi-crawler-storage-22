from __future__ import annotations

from namel3ss.format.grouping_rules import normalize_grouping_delimiters
from namel3ss.format.list_rules import normalize_list_literals, normalize_one_of_lists
from namel3ss.format.rules import (
    collapse_blank_lines,
    migrate_buttons,
    normalize_call_fields,
    normalize_contract_fields,
    normalize_function_fields,
    normalize_indentation,
    normalize_record_fields,
    normalize_spacing,
)


def format_source(source: str) -> str:
    lines = source.splitlines()
    lines = [line.rstrip() for line in lines]
    lines = migrate_buttons(lines)
    lines = [normalize_spacing(line) for line in lines]
    lines = normalize_grouping_delimiters(lines)
    lines = normalize_indentation(lines)
    lines = normalize_record_fields(lines)
    lines = normalize_function_fields(lines)
    lines = normalize_contract_fields(lines)
    lines = normalize_call_fields(lines)
    lines = normalize_one_of_lists(lines)
    lines = normalize_list_literals(lines)
    lines = collapse_blank_lines(lines)
    formatted = "\n".join(lines)
    if formatted and not formatted.endswith("\n"):
        formatted += "\n"
    if not formatted and source.endswith("\n"):
        formatted = "\n"
    return formatted
