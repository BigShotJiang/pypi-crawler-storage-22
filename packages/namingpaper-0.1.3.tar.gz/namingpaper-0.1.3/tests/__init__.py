"""Tests for namingpaper."""
