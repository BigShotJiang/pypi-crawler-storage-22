"""
Integration test for the MCP server.

Starts the simple calculator example server in a background thread,
then tests SSE connection, initialize, tools/list, tools/call,
resources/list, resources/read, prompts/list, and prompts/get
all via HTTP requests.
"""

from __future__ import print_function

import json
import os
import sys
import threading
import time

# Ensure the package is importable
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

try:
    from http.client import HTTPConnection
except ImportError:
    from httplib import HTTPConnection

from nanohubmcp import MCPServer, Context


# ---------------------------------------------------------------------------
# Build a small test server (mirrors examples/simple)
# ---------------------------------------------------------------------------

server = MCPServer("test-calculator", version="1.0.0")


@server.tool()
def add(a, b):
    # type: (float, float) -> float
    """Add two numbers together."""
    return float(a) + float(b)


@server.tool()
def divide(a, b):
    # type: (float, float) -> float
    """Divide a by b."""
    if float(b) == 0:
        raise ValueError("Cannot divide by zero")
    return float(a) / float(b)


@server.resource("config://calculator/settings")
def get_settings():
    """Get calculator settings."""
    return {"precision": 10}


@server.prompt()
def calculate(expression):
    # type: (str) -> list
    """Generate a calculation prompt."""
    return [
        {
            "role": "user",
            "content": {"type": "text", "text": "Please calculate: {}".format(expression)},
        }
    ]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

PORT = 18765  # High port to avoid conflicts


def _post(path, body):
    """Send a JSON-RPC POST and return the parsed response body."""
    conn = HTTPConnection("127.0.0.1", PORT, timeout=5)
    data = json.dumps(body).encode("utf-8")
    conn.request("POST", path, body=data, headers={"Content-Type": "application/json"})
    resp = conn.getresponse()
    raw = resp.read().decode("utf-8")
    conn.close()
    return resp.status, json.loads(raw)


def _read_sse(lines_to_read=4, timeout=3):
    """Open an SSE connection and read a few lines."""
    conn = HTTPConnection("127.0.0.1", PORT, timeout=timeout)
    conn.request("GET", "/sse")
    resp = conn.getresponse()
    content_type = resp.getheader("Content-Type")
    collected = []
    try:
        for _ in range(lines_to_read):
            line = resp.readline()
            if not line:
                break
            collected.append(line.decode("utf-8").rstrip("\r\n"))
    except Exception:
        pass
    conn.close()
    return resp.status, content_type, collected


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


def test_server_info():
    """GET / returns server info JSON."""
    conn = HTTPConnection("127.0.0.1", PORT, timeout=5)
    conn.request("GET", "/")
    resp = conn.getresponse()
    assert resp.status == 200
    body = json.loads(resp.read().decode("utf-8"))
    conn.close()
    assert body["name"] == "test-calculator"
    assert body["status"] == "running"
    assert body["tools"] == 2
    assert body["resources"] == 1
    assert body["prompts"] == 1


def test_sse_connection():
    """GET /sse returns an SSE stream with an open event."""
    status, content_type, lines = _read_sse()
    assert status == 200
    assert "text/event-stream" in content_type
    assert "event: open" in lines[0]


def test_initialize():
    """POST initialize returns protocol version and server info."""
    status, body = _post("/", {"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {}})
    assert status == 202
    assert body["status"] == "accepted"


def test_tools_list():
    """POST tools/list returns registered tools."""
    # We need to read the SSE to get the actual response
    # First connect SSE
    conn_sse = HTTPConnection("127.0.0.1", PORT, timeout=5)
    conn_sse.request("GET", "/sse")
    resp_sse = conn_sse.getresponse()
    # Read the open event
    resp_sse.readline()  # event: open
    resp_sse.readline()  # data: {}
    resp_sse.readline()  # empty line

    # Send the request
    status, _ = _post("/", {"jsonrpc": "2.0", "id": 10, "method": "tools/list", "params": {}})
    assert status == 202

    # Read response from SSE
    event_line = resp_sse.readline().decode("utf-8").strip()
    data_line = resp_sse.readline().decode("utf-8").strip()
    conn_sse.close()

    assert event_line == "event: message"
    assert data_line.startswith("data: ")
    response = json.loads(data_line[6:])
    assert response["id"] == 10
    tool_names = [t["name"] for t in response["result"]["tools"]]
    assert "add" in tool_names
    assert "divide" in tool_names


def test_tools_call_add():
    """POST tools/call with add returns correct result."""
    conn_sse = HTTPConnection("127.0.0.1", PORT, timeout=5)
    conn_sse.request("GET", "/sse")
    resp_sse = conn_sse.getresponse()
    resp_sse.readline()
    resp_sse.readline()
    resp_sse.readline()

    status, _ = _post(
        "/",
        {
            "jsonrpc": "2.0",
            "id": 20,
            "method": "tools/call",
            "params": {"name": "add", "arguments": {"a": 2, "b": 3}},
        },
    )
    assert status == 202

    resp_sse.readline()  # event: message
    data_line = resp_sse.readline().decode("utf-8").strip()
    conn_sse.close()

    response = json.loads(data_line[6:])
    assert response["id"] == 20
    assert response["result"]["isError"] is False
    assert "5" in response["result"]["content"][0]["text"]


def test_tools_call_divide_by_zero():
    """POST tools/call divide by zero returns isError=True."""
    conn_sse = HTTPConnection("127.0.0.1", PORT, timeout=5)
    conn_sse.request("GET", "/sse")
    resp_sse = conn_sse.getresponse()
    resp_sse.readline()
    resp_sse.readline()
    resp_sse.readline()

    status, _ = _post(
        "/",
        {
            "jsonrpc": "2.0",
            "id": 21,
            "method": "tools/call",
            "params": {"name": "divide", "arguments": {"a": 1, "b": 0}},
        },
    )
    assert status == 202

    resp_sse.readline()
    data_line = resp_sse.readline().decode("utf-8").strip()
    conn_sse.close()

    response = json.loads(data_line[6:])
    assert response["id"] == 21
    assert response["result"]["isError"] is True
    assert "zero" in response["result"]["content"][0]["text"].lower()


def test_resources_list():
    """POST resources/list returns registered resources."""
    conn_sse = HTTPConnection("127.0.0.1", PORT, timeout=5)
    conn_sse.request("GET", "/sse")
    resp_sse = conn_sse.getresponse()
    resp_sse.readline()
    resp_sse.readline()
    resp_sse.readline()

    status, _ = _post(
        "/", {"jsonrpc": "2.0", "id": 30, "method": "resources/list", "params": {}}
    )
    assert status == 202

    resp_sse.readline()
    data_line = resp_sse.readline().decode("utf-8").strip()
    conn_sse.close()

    response = json.loads(data_line[6:])
    assert response["id"] == 30
    uris = [r["uri"] for r in response["result"]["resources"]]
    assert "config://calculator/settings" in uris


def test_resources_read():
    """POST resources/read returns resource content."""
    conn_sse = HTTPConnection("127.0.0.1", PORT, timeout=5)
    conn_sse.request("GET", "/sse")
    resp_sse = conn_sse.getresponse()
    resp_sse.readline()
    resp_sse.readline()
    resp_sse.readline()

    status, _ = _post(
        "/",
        {
            "jsonrpc": "2.0",
            "id": 31,
            "method": "resources/read",
            "params": {"uri": "config://calculator/settings"},
        },
    )
    assert status == 202

    resp_sse.readline()
    data_line = resp_sse.readline().decode("utf-8").strip()
    conn_sse.close()

    response = json.loads(data_line[6:])
    assert response["id"] == 31
    content = json.loads(response["result"]["contents"][0]["text"])
    assert content["precision"] == 10


def test_prompts_list():
    """POST prompts/list returns registered prompts."""
    conn_sse = HTTPConnection("127.0.0.1", PORT, timeout=5)
    conn_sse.request("GET", "/sse")
    resp_sse = conn_sse.getresponse()
    resp_sse.readline()
    resp_sse.readline()
    resp_sse.readline()

    status, _ = _post(
        "/", {"jsonrpc": "2.0", "id": 40, "method": "prompts/list", "params": {}}
    )
    assert status == 202

    resp_sse.readline()
    data_line = resp_sse.readline().decode("utf-8").strip()
    conn_sse.close()

    response = json.loads(data_line[6:])
    assert response["id"] == 40
    names = [p["name"] for p in response["result"]["prompts"]]
    assert "calculate" in names


def test_prompts_get():
    """POST prompts/get returns prompt messages."""
    conn_sse = HTTPConnection("127.0.0.1", PORT, timeout=5)
    conn_sse.request("GET", "/sse")
    resp_sse = conn_sse.getresponse()
    resp_sse.readline()
    resp_sse.readline()
    resp_sse.readline()

    status, _ = _post(
        "/",
        {
            "jsonrpc": "2.0",
            "id": 41,
            "method": "prompts/get",
            "params": {"name": "calculate", "arguments": {"expression": "2+2"}},
        },
    )
    assert status == 202

    resp_sse.readline()
    data_line = resp_sse.readline().decode("utf-8").strip()
    conn_sse.close()

    response = json.loads(data_line[6:])
    assert response["id"] == 41
    assert "2+2" in str(response["result"]["messages"])


def test_ping():
    """POST ping returns empty result."""
    conn_sse = HTTPConnection("127.0.0.1", PORT, timeout=5)
    conn_sse.request("GET", "/sse")
    resp_sse = conn_sse.getresponse()
    resp_sse.readline()
    resp_sse.readline()
    resp_sse.readline()

    status, _ = _post("/", {"jsonrpc": "2.0", "id": 50, "method": "ping", "params": {}})
    assert status == 202

    resp_sse.readline()
    data_line = resp_sse.readline().decode("utf-8").strip()
    conn_sse.close()

    response = json.loads(data_line[6:])
    assert response["id"] == 50
    assert response["result"] == {}


def test_method_not_found():
    """POST unknown method returns error."""
    conn_sse = HTTPConnection("127.0.0.1", PORT, timeout=5)
    conn_sse.request("GET", "/sse")
    resp_sse = conn_sse.getresponse()
    resp_sse.readline()
    resp_sse.readline()
    resp_sse.readline()

    status, _ = _post(
        "/", {"jsonrpc": "2.0", "id": 60, "method": "nonexistent/method", "params": {}}
    )
    assert status == 202

    resp_sse.readline()
    data_line = resp_sse.readline().decode("utf-8").strip()
    conn_sse.close()

    response = json.loads(data_line[6:])
    assert response["id"] == 60
    assert "error" in response
    assert response["error"]["code"] == -32601


# ---------------------------------------------------------------------------
# Server lifecycle (start once for all tests)
# ---------------------------------------------------------------------------

def start_server():
    """Run the server in a daemon thread."""
    server.run(host="127.0.0.1", port=PORT)


_server_thread = None


def setup_module():
    """Start the test server before any tests run."""
    global _server_thread
    _server_thread = threading.Thread(target=start_server, daemon=True)
    _server_thread.start()
    # Wait for server to be ready
    for _ in range(50):
        try:
            conn = HTTPConnection("127.0.0.1", PORT, timeout=1)
            conn.request("GET", "/")
            resp = conn.getresponse()
            resp.read()
            conn.close()
            if resp.status == 200:
                return
        except Exception:
            pass
        time.sleep(0.1)
    raise RuntimeError("Test server did not start within 5 seconds")
