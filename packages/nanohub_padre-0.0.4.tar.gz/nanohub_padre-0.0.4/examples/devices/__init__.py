# Device factory examples
