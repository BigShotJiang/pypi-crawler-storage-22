# Enums

::: nanosynth.enums
