# Envelopes

::: nanosynth.envelopes
