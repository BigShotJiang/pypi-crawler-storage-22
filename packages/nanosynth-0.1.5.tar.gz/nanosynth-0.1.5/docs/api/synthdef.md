# SynthDef Builder

::: nanosynth.synthdef
