# Convolution

::: nanosynth.ugens.convolution
