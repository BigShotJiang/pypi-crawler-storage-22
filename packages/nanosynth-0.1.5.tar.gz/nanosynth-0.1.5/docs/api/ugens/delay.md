# Delays

::: nanosynth.ugens.delay
