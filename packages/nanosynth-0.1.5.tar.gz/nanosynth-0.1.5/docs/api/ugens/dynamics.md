# Dynamics

::: nanosynth.ugens.dynamics
