# Envelopes

::: nanosynth.ugens.envelopes
