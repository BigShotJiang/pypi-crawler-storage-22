# Lines

::: nanosynth.ugens.lines
