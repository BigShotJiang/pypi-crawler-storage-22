# Oscillators

::: nanosynth.ugens.osc
