# Panning

::: nanosynth.ugens.panning
