# Safety

::: nanosynth.ugens.safety
