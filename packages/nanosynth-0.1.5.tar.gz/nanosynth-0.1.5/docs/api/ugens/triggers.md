# Triggers

::: nanosynth.ugens.triggers
