"""Default smoke test to ensure test suite is non-empty."""

def test_default_passes() -> None:
    assert True
