# 🚀 NAPLY - The Most Powerful AI Framework

[![PyPI version](https://badge.fury.io/py/naply.svg)](https://badge.fury.io/py/naply)
[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Downloads](https://pepy.tech/badge/naply)](https://pepy.tech/project/naply)

**Build ChatGPT-level AI models from scratch. CPU-optimized. Production-ready. Lightweight.**

```bash
pip install naply --upgrade
```

---

## ⚡ Quick Start - Just 2 Lines!

### Standard Model
```python
import naply

# Train your AI (1 line!)
model = naply.Model("medium")
model.train("my_data/", epochs=5)

# Chat with your AI (1 line!)
response = model.chat("Hello! How are you?")
```

### Powerful Model (All 10 Methods!)
```python
from naply.powerful_text_model import PowerfulTextModel

# Most powerful model with all 10 training methods
model = PowerfulTextModel("medium")
model.train("my_data/", epochs=10, method="all")  # Uses all 10 methods!

# Natural language generation (no gibberish!)
response = model.chat("Hello! How are you?")
```

**That's it!** Super simple! 🎉

### Even Simpler - 1 Function!

```python
import naply.easy as ai

# Train and chat in one go!
ai.quick_start("my_data/", epochs=5)
# Then just type your questions!
```

---

## 🚀 NEW: Fine-tuning Framework (v4.3.0)

Fine-tune any AI model (LLaMA, GPT, Unsloth, etc.) on your own data with LoRA/QLoRA efficiency.

### One-Liner Fine-tuning
```python
import naply

# Fine-tune a base model on your data (auto-saves to "finetune_output")
# Supports: jsonl, csv, txt, parquet, folders
model = naply.finetune("unsloth/llama-3.2-1B", "my_data.jsonl", epochs=3)

# Chat with it
response = naply.chat(model, "Hello!")
```

### Advanced Control (LoRA & QLoRA)
```python
model = naply.load_for_finetune("small") # or "path/to/model"
naply.add_lora(model, rank=8, alpha=16)
naply.train_lora(model, "data.csv", epochs=5)
naply.merge_and_save(model, "final_model")
```

---

## 🌟 Why NAPLY?

| Feature | NAPLY | PyTorch | TensorFlow | Transformers |
|---------|-------|---------|------------|--------------|
| **From Scratch** | ✅ | ❌ | ❌ | ❌ |
| **CPU Optimized** | ✅ | ⚠️ | ⚠️ | ⚠️ |
| **Lightweight** | ✅ (2MB) | ❌ (500MB+) | ❌ (1GB+) | ❌ (200MB+) |
| **No Dependencies** | ✅ | ❌ | ❌ | ❌ |
| **10 Training Methods** | ✅ | ❌ | ❌ | ❌ |
| **Micro-Specialists** | ✅ (v4.0) | ❌ | ❌ | ❌ |
| **ChatGPT-Level** | ✅ | ⚠️ | ⚠️ | ⚠️ |
| **Natural English** | ✅ | ⚠️ | ⚠️ | ⚠️ |

---

## 🎯 Key Features

### 🚀 **Most Powerful Framework (v4.0 Octane)**
- **6-Specialist Cluster**: Syntax, Lexicon, Logic, Thought, Code, and Tech micro-specialists.
- **10 Advanced Training Methods**: CRC, DCL, ILC, MCU, P3, PPL, PTL, RDL, S3L, SGL.
- **Extreme Intelligence**: 32,000 vocab (BPE) for deep semantic understanding.
- **Parallel Training (PTL)**: Multi-threaded CPU execution for 2x faster learning.

### ⚡ **Lightweight & Fast**
- **2MB package size** (vs 500MB+ for PyTorch)
- **CPU-optimized** - Runs on any laptop
- **No GPU required** - Pure NumPy implementation
- **Fast inference** - Optimized tokenization

### 🎨 **Production-Ready**
- **PyTorch-like API** - Familiar interface
- **Automatic differentiation** - Full autograd engine
- **Checkpointing** - Save/resume training
- **CLI tools** - `naply train`, `naply chat`
- **Standalone** - Works after training without datasets

### 🔧 **Developer-Friendly**
- **No limits** - Build models of any size (10M to 1B+ params)
- **Any dataset** - Supports .txt, .json, .jsonl, .csv, folders
- **Easy to use** - 3 lines of code to get started
- **Well documented** - Comprehensive guides and examples

---

## 📦 Installation

```bash
pip install naply
```

**That's it!** Now use it super simply:

```python
import naply.easy as ai

# Build AI in 1 line!
model = ai.train("my_data/", epochs=5)

# Chat in 1 line!
response = ai.chat("Hello!")
```

### Install from Source (Development)

```bash
git clone https://github.com/naply-ai/naply.git
cd naply
pip install -e .
```

---

## 🎯 Super Simple API

### The Easiest Way (Recommended)

```python
import naply.easy as ai

# Train (1 line!)
model = ai.train("my_data/", epochs=10)

# Chat (1 line!)
response = ai.chat("Hello!")

# Build (1 line!)
model = ai.build("medium")
```

### Advanced API (More Control)

```python
import naply

# Create model
model = naply.Model("medium")

# Train
model.train("my_data/", epochs=10)

# Chat
model.chat("Hello!")
```

---

## 🏗️ Model Architectures

### Using Presets
```python
import naply

# Quick presets - choose your size
model = naply.Model("tiny")    # ~1M params, fast testing
model = naply.Model("small")   # ~10M params
model = naply.Model("medium")  # ~50M params
model = naply.Model("large")   # ~100M params
model = naply.Model("xl")      # ~300M params
model = naply.Model("xxl")     # ~1B params
```

### Custom Architecture (No Limits!)
```python
import naply

# Build exactly what you want
model = naply.Model(
    layers=24,        # Number of transformer layers
    heads=16,         # Attention heads
    embedding=1024,   # Embedding dimension
    vocab_size=50000, # Vocabulary size
    context=4096      # Context length
)
```

---

## 🎓 Training Methods

NAPLY includes **10 advanced training methods** for optimal learning:

1. **CRC** - Consistency-Retention Compression
2. **DCL** - Domain-Constrained Learning
3. **ILC** - Incremental Learning Consolidation
4. **MCU** - Memory Consolidation Unit
5. **P3** - Parallel Pipelined Processing
6. **PPL** - Progressive Prompt Learning
7. **PTL** - Parallel Training and Learning (Multi-threaded CPU)
8. **RDL** - Recursive Data Learning
9. **S3L** - Structured Selective Stabilized Learning
10. **SGL** - Sparse Gradient Learning

```python
import naply

model = naply.Model("medium")

# Use advanced training method
trainer = naply.PTLTrainer(model, num_workers=4)  # Parallel training
trainer.train(data_loader, epochs=10)
```

---

## 💬 ChatGPT-Level Chat Interface

```python
import naply

# Load trained model
model = naply.Model.load("my_model/")

# Chat with natural English
response = model.chat(
    "Hello! How are you?",
    max_tokens=200,
    temperature=0.8,
    top_k=50,
    top_p=0.95
)

print(response)
# Output: "Hello! I'm doing well, thank you for asking. How can I help you today?"
```

### Interactive Chat
```python
# Start interactive chat session
model.chat_interactive()
```

---

## 🛠️ Advanced Features

### Automatic Differentiation
```python
import naply
from naply import Tensor

x = Tensor([1.0, 2.0, 3.0], requires_grad=True)
y = x * 2
z = y.sum()

z.backward()
print(x.grad)  # [2.0, 2.0, 2.0]
```

### PyTorch-Style API
```python
import naply.nn as nn

class MyModel(nn.Module):
    def __init__(self):
        super().__init__()
        self.linear = nn.Linear(768, 768)
        self.norm = nn.LayerNorm(768)
    
    def forward(self, x):
        return self.norm(self.linear(x))
```

### Optimizers & Schedulers
```python
from naply.optim import AdamW, OneCycleScheduler

optimizer = AdamW(model.parameters(), lr=1e-4)
scheduler = OneCycleScheduler(optimizer, max_lr=1e-3, total_steps=1000)
```

### Checkpointing
```python
from naply.utils import Checkpoint

ckpt = Checkpoint("checkpoints/")
ckpt.save(model, optimizer, epoch=5, loss=0.5)

# Resume training
metadata = ckpt.load_latest(model, optimizer)
```

---

## 📚 Examples

### Train Your First AI
```python
import naply

# Create model
model = naply.Model("small")

# Train on your data
model.train("my_data/", epochs=10, batch_size=32)

# Save model
model.save("my_ai_model/")

# Chat
print(model.chat("Hello!"))
```

### Power AI Training (ChatGPT-Level)
```bash
python train_power_ai.py --data "final datasets/" --foundation "foundation_corpus/" --epochs 15
```

### Chat with Power AI
```bash
python chat_power_ai.py --model "final datasets/power_ai_model"
```

---

## 🎯 Use Cases

- **Build custom AI models** from scratch
- **Train on your own data** (any format)
- **Create ChatGPT-like assistants**
- **Educational purposes** - Learn how AI works
- **Research** - Experiment with new architectures
- **Production** - Deploy lightweight AI models

---

## 📖 Documentation

- **[Quick Start Guide](QUICK_START_GUIDE.md)**
- **[Training Methods](documents/)**
- **[API Reference](https://github.com/naply-ai/naply#api-reference)**
- **[Examples](examples/)**

---

## 🤝 Contributing

Contributions are welcome! Please see our [Contributing Guide](CONTRIBUTING.md).

---

## 📄 License

MIT License - see [LICENSE](LICENSE) file for details.

---

## 🙏 Acknowledgments

Built with ❤️ for the AI community. Inspired by PyTorch, Transformers, and the open-source spirit.

---

## ⭐ Star Us!

If you find NAPLY useful, please star us on GitHub!

```bash
# Install and try it now!
pip install naply
```

**Build the future of AI. One line at a time.** 🚀
