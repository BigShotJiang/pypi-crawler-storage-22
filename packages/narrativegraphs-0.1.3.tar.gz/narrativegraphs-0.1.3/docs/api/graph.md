# Graph Module

The core module containing the `NarrativeGraph` class and related data structures.

## NarrativeGraph

The main class for constructing and manipulating narrative graphs.

::: narrativegraphs.NarrativeGraph

