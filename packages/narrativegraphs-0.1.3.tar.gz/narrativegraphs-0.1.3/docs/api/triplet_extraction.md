# Extraction Module


## TripletExtractor

::: narrativegraphs.nlp.extraction.common.TripletExtractor

::: narrativegraphs.nlp.extraction.spacy.common.SpacyTripletExtractor

