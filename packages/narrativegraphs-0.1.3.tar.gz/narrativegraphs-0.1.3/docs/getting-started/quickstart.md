# Quick Start

This guide walks through the basic workflow of building and analyzing a narrative graph.

## Basic Workflow

### 1. Load Your Texts
