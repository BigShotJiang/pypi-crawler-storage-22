class EntryNotFoundError(Exception):
    pass
