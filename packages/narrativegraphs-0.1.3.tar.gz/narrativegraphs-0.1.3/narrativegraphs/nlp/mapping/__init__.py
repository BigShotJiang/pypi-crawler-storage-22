from narrativegraphs.nlp.mapping.common import Mapper

__all__ = [Mapper]
