#!/bin/bash

set -e

python -m spacy download en_core_web_sm