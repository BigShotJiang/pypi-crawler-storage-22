# Visualizing graphs

This React App visualizes an interactive narrative graph as output by the pipeline.
