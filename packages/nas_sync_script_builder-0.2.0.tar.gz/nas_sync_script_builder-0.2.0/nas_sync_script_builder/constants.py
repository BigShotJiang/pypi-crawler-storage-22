DEFAULT_EXCLUDE_ITEMS = [
    "$RECYCLE.BIN/",
    "System Volume Information/",
    "RECYCLER/",
    "Program Files/",
    "Program Files (x86)/",
    "Windows/",
    "PerfLogs/",
    "MSOCache/",
    "found.000/",

    "hiberfil.sys",
    "pagefile.sys",
    "swapfile.sys",
    "desktop.ini",
    "Desktop.ini",
    "Thumbs.db",
    "ehthumbs.db",
    "DumpStack.log*",
    "WPSettings.dat",
    "IndexerVolumeGuid",

    ".Trash-1000/",

    ".git/",
    ".vs/",
    ".vscode/",
]
