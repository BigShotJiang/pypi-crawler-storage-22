# nas_sync_script_builder/__init__.py

__version__ = "0.3.0"