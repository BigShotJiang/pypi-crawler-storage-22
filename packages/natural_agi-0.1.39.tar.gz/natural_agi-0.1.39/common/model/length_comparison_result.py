from enum import Enum

class LengthComparisonResult(Enum):
    LONGER = "longer"
    SHORTER = "shorter"
    EQUAL = "equal"
    N_A = "N/A"