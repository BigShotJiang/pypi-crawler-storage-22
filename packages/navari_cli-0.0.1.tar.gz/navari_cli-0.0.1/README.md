# Navari CLI

Command-line interface for Navari AI Agent - an enterprise-grade AI agent framework for pharmaceutical research.

## Installation

```bash
# For end users
uv tool install navari-cli
# or
pip install navari-cli

# For development
cd cli
uv pip install -e ".[dev]"
```

## Quick Start

```bash
# Login to Navari
navari login https://navari.example.com

# List conversations
navari conversations list

# Start interactive chat
navari chat --new --title "My Analysis"

# Get help
navari --help
```

## Features

- **Interactive Chat**: Real-time streaming chat with Navari agent
- **Conversation Management**: Create, list, get, update, delete conversations
- **File Operations**: Upload, download, and manage files
- **Multiple Servers**: Switch between servers with `navari config <url>`
- **Azure AD SSO**: Browser-based, device code, and password authentication flows
- **Beautiful Output**: Rich terminal output with colors and tables

## Commands

### Authentication

```bash
navari login <url>                         # Browser-based OAuth flow
navari login <url> --device-code           # Device code flow for headless
navari login <url> --token <jwt>           # Login with a pre-obtained JWT token
navari login <url> -u user@co.com -p pass  # Password login (CI/automation)
navari login                               # Re-login to last used server
navari logout                              # Logout from all servers
navari logout <url>                        # Logout from specific server
navari whoami                              # Show current user and server
```

### Conversations

```bash
navari conversations list                   # List all conversations
navari conversations create --title "Title" # Create new conversation
navari conversations get <id>               # Get conversation details
navari conversations messages <id>          # Show conversation messages
navari conversations delete <id>            # Delete conversation
```

### Interactive Chat

```bash
navari chat <conversation-id>               # Start chat session
navari chat --new --title "Title"           # Create new and start chat
navari chat -m "message"                    # Send single message (non-interactive)
navari chat --new -f data.csv -m "analyze"  # Attach file and send message
```

### Files

```bash
navari files upload --conversation <id> <path>  # Upload file
navari files list --conversation <id>           # List files
navari files download <file-id>                 # Download file
navari files delete <file-id>                   # Delete file
navari files workspace <conversation-id>        # Download workspace zip
```

### Configuration

```bash
navari config                               # Show current configuration
navari config <url>                         # Switch active server
```

### Global Options

```bash
--server <url>               # Override active server for this command
--format {json|table|plain}  # Output format
--debug                      # Enable debug logging
--no-color                   # Disable color output
--no-verify                  # Skip SSL certificate verification
```

## Configuration

The CLI stores credentials and configuration in `~/.navari/`:
- `credentials.json` - JWT tokens per server
- `config.json` - User preferences (last used server, output format)
- `msal_cache.json` - MSAL token cache for silent token refresh

## Development

### Generating OpenAPI Client

When the Navari API changes, regenerate the client:

```bash
./scripts/generate_api.sh --client-py
```
