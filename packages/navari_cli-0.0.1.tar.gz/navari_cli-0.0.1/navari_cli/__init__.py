"""Navari CLI - Command-line interface for Navari AI Agent."""

try:
    from navari_cli._version import __version__
except ImportError:
    __version__ = "0.0.0-dev"
