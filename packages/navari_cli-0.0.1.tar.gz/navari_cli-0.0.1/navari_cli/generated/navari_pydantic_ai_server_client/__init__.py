"""A client library for accessing Navari Pydantic-AI Server"""

from .client import AuthenticatedClient, Client

__all__ = (
    "AuthenticatedClient",
    "Client",
)
