from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.delete_conversation_response_delete_conversation_api_conversations_conversation_id_delete import (
    DeleteConversationResponseDeleteConversationApiConversationsConversationIdDelete,
)
from ...models.error_response import ErrorResponse
from ...models.http_validation_error import HTTPValidationError
from ...types import Response


def _get_kwargs(
    conversation_id: str,
) -> dict[str, Any]:
    _kwargs: dict[str, Any] = {
        "method": "delete",
        "url": "/api/conversations/{conversation_id}".format(
            conversation_id=quote(str(conversation_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    DeleteConversationResponseDeleteConversationApiConversationsConversationIdDelete
    | ErrorResponse
    | HTTPValidationError
    | None
):
    if response.status_code == 200:
        response_200 = DeleteConversationResponseDeleteConversationApiConversationsConversationIdDelete.from_dict(
            response.json()
        )

        return response_200

    if response.status_code == 404:
        response_404 = ErrorResponse.from_dict(response.json())

        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    DeleteConversationResponseDeleteConversationApiConversationsConversationIdDelete
    | ErrorResponse
    | HTTPValidationError
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    conversation_id: str,
    *,
    client: AuthenticatedClient,
) -> Response[
    DeleteConversationResponseDeleteConversationApiConversationsConversationIdDelete
    | ErrorResponse
    | HTTPValidationError
]:
    """Delete Conversation

     Delete a conversation and cancel any associated A2A tasks.

    This function properly stops all active resources before deletion:
    - Cancels any active runs
    - Removes active agents
    - Unregisters active connections
    - Cleans up conversation files
    - Deletes the conversation record

    Args:
        conversation_id: The ID of the conversation to delete
        current_user: The authenticated user

    Returns:
        Success message

    Args:
        conversation_id (str): The ID of the conversation to delete

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeleteConversationResponseDeleteConversationApiConversationsConversationIdDelete | ErrorResponse | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        conversation_id=conversation_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    conversation_id: str,
    *,
    client: AuthenticatedClient,
) -> (
    DeleteConversationResponseDeleteConversationApiConversationsConversationIdDelete
    | ErrorResponse
    | HTTPValidationError
    | None
):
    """Delete Conversation

     Delete a conversation and cancel any associated A2A tasks.

    This function properly stops all active resources before deletion:
    - Cancels any active runs
    - Removes active agents
    - Unregisters active connections
    - Cleans up conversation files
    - Deletes the conversation record

    Args:
        conversation_id: The ID of the conversation to delete
        current_user: The authenticated user

    Returns:
        Success message

    Args:
        conversation_id (str): The ID of the conversation to delete

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeleteConversationResponseDeleteConversationApiConversationsConversationIdDelete | ErrorResponse | HTTPValidationError
    """

    return sync_detailed(
        conversation_id=conversation_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    conversation_id: str,
    *,
    client: AuthenticatedClient,
) -> Response[
    DeleteConversationResponseDeleteConversationApiConversationsConversationIdDelete
    | ErrorResponse
    | HTTPValidationError
]:
    """Delete Conversation

     Delete a conversation and cancel any associated A2A tasks.

    This function properly stops all active resources before deletion:
    - Cancels any active runs
    - Removes active agents
    - Unregisters active connections
    - Cleans up conversation files
    - Deletes the conversation record

    Args:
        conversation_id: The ID of the conversation to delete
        current_user: The authenticated user

    Returns:
        Success message

    Args:
        conversation_id (str): The ID of the conversation to delete

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeleteConversationResponseDeleteConversationApiConversationsConversationIdDelete | ErrorResponse | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        conversation_id=conversation_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    conversation_id: str,
    *,
    client: AuthenticatedClient,
) -> (
    DeleteConversationResponseDeleteConversationApiConversationsConversationIdDelete
    | ErrorResponse
    | HTTPValidationError
    | None
):
    """Delete Conversation

     Delete a conversation and cancel any associated A2A tasks.

    This function properly stops all active resources before deletion:
    - Cancels any active runs
    - Removes active agents
    - Unregisters active connections
    - Cleans up conversation files
    - Deletes the conversation record

    Args:
        conversation_id: The ID of the conversation to delete
        current_user: The authenticated user

    Returns:
        Success message

    Args:
        conversation_id (str): The ID of the conversation to delete

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeleteConversationResponseDeleteConversationApiConversationsConversationIdDelete | ErrorResponse | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            conversation_id=conversation_id,
            client=client,
        )
    ).parsed
