from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.error_response import ErrorResponse
from ...models.http_validation_error import HTTPValidationError
from ...types import UNSET, Response, Unset


def _get_kwargs(
    conversation_id: str,
    *,
    limit: int | Unset = 10000000,
    offset: int | Unset = 0,
) -> dict[str, Any]:
    params: dict[str, Any] = {}

    params["limit"] = limit

    params["offset"] = offset

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/conversations/{conversation_id}/messages".format(
            conversation_id=quote(str(conversation_id), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ErrorResponse | HTTPValidationError | None:
    if response.status_code == 404:
        response_404 = ErrorResponse.from_dict(response.json())

        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ErrorResponse | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    conversation_id: str,
    *,
    client: AuthenticatedClient,
    limit: int | Unset = 10000000,
    offset: int | Unset = 0,
) -> Response[ErrorResponse | HTTPValidationError]:
    """Get Conversation Messages

     Get messages for a conversation as Pydantic events.

    This endpoint retrieves all pydantic events stored for the conversation.

    Args:
        conversation_id: The ID of the conversation to get messages for

    Returns:
        List of Pydantic events

    Args:
        conversation_id (str): The ID of the conversation to get messages for
        limit (int | Unset):  Default: 10000000.
        offset (int | Unset):  Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorResponse | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        conversation_id=conversation_id,
        limit=limit,
        offset=offset,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    conversation_id: str,
    *,
    client: AuthenticatedClient,
    limit: int | Unset = 10000000,
    offset: int | Unset = 0,
) -> ErrorResponse | HTTPValidationError | None:
    """Get Conversation Messages

     Get messages for a conversation as Pydantic events.

    This endpoint retrieves all pydantic events stored for the conversation.

    Args:
        conversation_id: The ID of the conversation to get messages for

    Returns:
        List of Pydantic events

    Args:
        conversation_id (str): The ID of the conversation to get messages for
        limit (int | Unset):  Default: 10000000.
        offset (int | Unset):  Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorResponse | HTTPValidationError
    """

    return sync_detailed(
        conversation_id=conversation_id,
        client=client,
        limit=limit,
        offset=offset,
    ).parsed


async def asyncio_detailed(
    conversation_id: str,
    *,
    client: AuthenticatedClient,
    limit: int | Unset = 10000000,
    offset: int | Unset = 0,
) -> Response[ErrorResponse | HTTPValidationError]:
    """Get Conversation Messages

     Get messages for a conversation as Pydantic events.

    This endpoint retrieves all pydantic events stored for the conversation.

    Args:
        conversation_id: The ID of the conversation to get messages for

    Returns:
        List of Pydantic events

    Args:
        conversation_id (str): The ID of the conversation to get messages for
        limit (int | Unset):  Default: 10000000.
        offset (int | Unset):  Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorResponse | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        conversation_id=conversation_id,
        limit=limit,
        offset=offset,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    conversation_id: str,
    *,
    client: AuthenticatedClient,
    limit: int | Unset = 10000000,
    offset: int | Unset = 0,
) -> ErrorResponse | HTTPValidationError | None:
    """Get Conversation Messages

     Get messages for a conversation as Pydantic events.

    This endpoint retrieves all pydantic events stored for the conversation.

    Args:
        conversation_id: The ID of the conversation to get messages for

    Returns:
        List of Pydantic events

    Args:
        conversation_id (str): The ID of the conversation to get messages for
        limit (int | Unset):  Default: 10000000.
        offset (int | Unset):  Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorResponse | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            conversation_id=conversation_id,
            client=client,
            limit=limit,
            offset=offset,
        )
    ).parsed
