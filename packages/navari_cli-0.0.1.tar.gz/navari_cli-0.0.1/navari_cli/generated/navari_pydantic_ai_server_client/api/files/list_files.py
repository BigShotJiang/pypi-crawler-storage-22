from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.file_list_response import FileListResponse
from ...models.http_validation_error import HTTPValidationError
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    conversation_id: None | str | Unset = UNSET,
    limit: int | Unset = 20,
    offset: int | Unset = 0,
) -> dict[str, Any]:
    params: dict[str, Any] = {}

    json_conversation_id: None | str | Unset
    if isinstance(conversation_id, Unset):
        json_conversation_id = UNSET
    else:
        json_conversation_id = conversation_id
    params["conversation_id"] = json_conversation_id

    params["limit"] = limit

    params["offset"] = offset

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/files/",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> FileListResponse | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = FileListResponse.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[FileListResponse | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    conversation_id: None | str | Unset = UNSET,
    limit: int | Unset = 20,
    offset: int | Unset = 0,
) -> Response[FileListResponse | HTTPValidationError]:
    """List Files

     List user's files with optional conversation filtering.

    Args:
        conversation_id: Optional conversation ID to filter files
        limit: Maximum number of files to return (1-100)
        offset: Number of files to skip for pagination
        current_user: Authenticated user

    Returns:
        FileListResponse with files and pagination info

    Raises:
        HTTPException: If listing fails

    Args:
        conversation_id (None | str | Unset): Filter files by conversation ID
        limit (int | Unset): Maximum number of files to return Default: 20.
        offset (int | Unset): Number of files to skip Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[FileListResponse | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        conversation_id=conversation_id,
        limit=limit,
        offset=offset,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    conversation_id: None | str | Unset = UNSET,
    limit: int | Unset = 20,
    offset: int | Unset = 0,
) -> FileListResponse | HTTPValidationError | None:
    """List Files

     List user's files with optional conversation filtering.

    Args:
        conversation_id: Optional conversation ID to filter files
        limit: Maximum number of files to return (1-100)
        offset: Number of files to skip for pagination
        current_user: Authenticated user

    Returns:
        FileListResponse with files and pagination info

    Raises:
        HTTPException: If listing fails

    Args:
        conversation_id (None | str | Unset): Filter files by conversation ID
        limit (int | Unset): Maximum number of files to return Default: 20.
        offset (int | Unset): Number of files to skip Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        FileListResponse | HTTPValidationError
    """

    return sync_detailed(
        client=client,
        conversation_id=conversation_id,
        limit=limit,
        offset=offset,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    conversation_id: None | str | Unset = UNSET,
    limit: int | Unset = 20,
    offset: int | Unset = 0,
) -> Response[FileListResponse | HTTPValidationError]:
    """List Files

     List user's files with optional conversation filtering.

    Args:
        conversation_id: Optional conversation ID to filter files
        limit: Maximum number of files to return (1-100)
        offset: Number of files to skip for pagination
        current_user: Authenticated user

    Returns:
        FileListResponse with files and pagination info

    Raises:
        HTTPException: If listing fails

    Args:
        conversation_id (None | str | Unset): Filter files by conversation ID
        limit (int | Unset): Maximum number of files to return Default: 20.
        offset (int | Unset): Number of files to skip Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[FileListResponse | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        conversation_id=conversation_id,
        limit=limit,
        offset=offset,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    conversation_id: None | str | Unset = UNSET,
    limit: int | Unset = 20,
    offset: int | Unset = 0,
) -> FileListResponse | HTTPValidationError | None:
    """List Files

     List user's files with optional conversation filtering.

    Args:
        conversation_id: Optional conversation ID to filter files
        limit: Maximum number of files to return (1-100)
        offset: Number of files to skip for pagination
        current_user: Authenticated user

    Returns:
        FileListResponse with files and pagination info

    Raises:
        HTTPException: If listing fails

    Args:
        conversation_id (None | str | Unset): Filter files by conversation ID
        limit (int | Unset): Maximum number of files to return Default: 20.
        offset (int | Unset): Number of files to skip Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        FileListResponse | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            client=client,
            conversation_id=conversation_id,
            limit=limit,
            offset=offset,
        )
    ).parsed
