from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.body_upload_file_api_files_post import BodyUploadFileApiFilesPost
from ...models.file_upload_response import FileUploadResponse
from ...models.http_validation_error import HTTPValidationError
from ...types import Response


def _get_kwargs(
    *,
    body: BodyUploadFileApiFilesPost,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/files/",
    }

    _kwargs["files"] = body.to_multipart()

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> FileUploadResponse | HTTPValidationError | None:
    if response.status_code == 201:
        response_201 = FileUploadResponse.from_dict(response.json())

        return response_201

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[FileUploadResponse | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: BodyUploadFileApiFilesPost,
) -> Response[FileUploadResponse | HTTPValidationError]:
    """Upload File

     Upload a new file.

    This endpoint accepts file uploads and stores them for use in conversations.
    The uploaded file must be associated with a specific conversation ID.

    Args:
        file: The uploaded file
        conversation_id: Required conversation ID to associate the file with
        current_user: Authenticated user

    Returns:
        FileUploadResponse with file metadata

    Raises:
        HTTPException: If upload fails or file is invalid

    Args:
        body (BodyUploadFileApiFilesPost):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[FileUploadResponse | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    body: BodyUploadFileApiFilesPost,
) -> FileUploadResponse | HTTPValidationError | None:
    """Upload File

     Upload a new file.

    This endpoint accepts file uploads and stores them for use in conversations.
    The uploaded file must be associated with a specific conversation ID.

    Args:
        file: The uploaded file
        conversation_id: Required conversation ID to associate the file with
        current_user: Authenticated user

    Returns:
        FileUploadResponse with file metadata

    Raises:
        HTTPException: If upload fails or file is invalid

    Args:
        body (BodyUploadFileApiFilesPost):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        FileUploadResponse | HTTPValidationError
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: BodyUploadFileApiFilesPost,
) -> Response[FileUploadResponse | HTTPValidationError]:
    """Upload File

     Upload a new file.

    This endpoint accepts file uploads and stores them for use in conversations.
    The uploaded file must be associated with a specific conversation ID.

    Args:
        file: The uploaded file
        conversation_id: Required conversation ID to associate the file with
        current_user: Authenticated user

    Returns:
        FileUploadResponse with file metadata

    Raises:
        HTTPException: If upload fails or file is invalid

    Args:
        body (BodyUploadFileApiFilesPost):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[FileUploadResponse | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    body: BodyUploadFileApiFilesPost,
) -> FileUploadResponse | HTTPValidationError | None:
    """Upload File

     Upload a new file.

    This endpoint accepts file uploads and stores them for use in conversations.
    The uploaded file must be associated with a specific conversation ID.

    Args:
        file: The uploaded file
        conversation_id: Required conversation ID to associate the file with
        current_user: Authenticated user

    Returns:
        FileUploadResponse with file metadata

    Raises:
        HTTPException: If upload fails or file is invalid

    Args:
        body (BodyUploadFileApiFilesPost):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        FileUploadResponse | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
