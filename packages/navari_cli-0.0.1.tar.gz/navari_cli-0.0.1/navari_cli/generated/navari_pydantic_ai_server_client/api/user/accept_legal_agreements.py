from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.accept_terms_request import AcceptTermsRequest
from ...models.accept_terms_response import AcceptTermsResponse
from ...models.http_validation_error import HTTPValidationError
from ...types import Response


def _get_kwargs(
    *,
    body: AcceptTermsRequest,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/user/legal-agreements/accept",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> AcceptTermsResponse | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = AcceptTermsResponse.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[AcceptTermsResponse | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: AcceptTermsRequest,
) -> Response[AcceptTermsResponse | HTTPValidationError]:
    """Accept Legal Agreements

     Accept terms and conditions and privacy policy.

    This endpoint allows users to accept legal agreements by providing the agreement IDs
    and their acceptance status. Both terms_and_conditions and privacy_policy must be
    accepted (set to true) for the request to succeed.

    Args:
        request: The acceptance request containing agreement IDs and acceptance status
        http_request: The HTTP request object for extracting client information
        current_user: The authenticated user

    Returns:
        AcceptTermsResponse: Success status and message

    Raises:
        HTTPException: If validation fails or there's an error processing the request

    Args:
        body (AcceptTermsRequest): Request model for accepting terms and conditions and privacy
            policy.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AcceptTermsResponse | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    body: AcceptTermsRequest,
) -> AcceptTermsResponse | HTTPValidationError | None:
    """Accept Legal Agreements

     Accept terms and conditions and privacy policy.

    This endpoint allows users to accept legal agreements by providing the agreement IDs
    and their acceptance status. Both terms_and_conditions and privacy_policy must be
    accepted (set to true) for the request to succeed.

    Args:
        request: The acceptance request containing agreement IDs and acceptance status
        http_request: The HTTP request object for extracting client information
        current_user: The authenticated user

    Returns:
        AcceptTermsResponse: Success status and message

    Raises:
        HTTPException: If validation fails or there's an error processing the request

    Args:
        body (AcceptTermsRequest): Request model for accepting terms and conditions and privacy
            policy.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AcceptTermsResponse | HTTPValidationError
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: AcceptTermsRequest,
) -> Response[AcceptTermsResponse | HTTPValidationError]:
    """Accept Legal Agreements

     Accept terms and conditions and privacy policy.

    This endpoint allows users to accept legal agreements by providing the agreement IDs
    and their acceptance status. Both terms_and_conditions and privacy_policy must be
    accepted (set to true) for the request to succeed.

    Args:
        request: The acceptance request containing agreement IDs and acceptance status
        http_request: The HTTP request object for extracting client information
        current_user: The authenticated user

    Returns:
        AcceptTermsResponse: Success status and message

    Raises:
        HTTPException: If validation fails or there's an error processing the request

    Args:
        body (AcceptTermsRequest): Request model for accepting terms and conditions and privacy
            policy.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AcceptTermsResponse | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    body: AcceptTermsRequest,
) -> AcceptTermsResponse | HTTPValidationError | None:
    """Accept Legal Agreements

     Accept terms and conditions and privacy policy.

    This endpoint allows users to accept legal agreements by providing the agreement IDs
    and their acceptance status. Both terms_and_conditions and privacy_policy must be
    accepted (set to true) for the request to succeed.

    Args:
        request: The acceptance request containing agreement IDs and acceptance status
        http_request: The HTTP request object for extracting client information
        current_user: The authenticated user

    Returns:
        AcceptTermsResponse: Success status and message

    Raises:
        HTTPException: If validation fails or there's an error processing the request

    Args:
        body (AcceptTermsRequest): Request model for accepting terms and conditions and privacy
            policy.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AcceptTermsResponse | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
