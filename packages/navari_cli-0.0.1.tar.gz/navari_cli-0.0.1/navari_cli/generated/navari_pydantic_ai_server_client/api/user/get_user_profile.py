from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.user_profile_response import UserProfileResponse
from ...types import Response


def _get_kwargs() -> dict[str, Any]:
    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/user/profile",
    }

    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> UserProfileResponse | None:
    if response.status_code == 200:
        response_200 = UserProfileResponse.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[UserProfileResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
) -> Response[UserProfileResponse]:
    """Get User Profile

     Get user profile information including user data, environment, legal agreements, and preferences.

    Returns comprehensive user information including:
    - User data (same as authorize endpoint)
    - NAVARI_ENV environment variable
    - Most recent accepted legal agreements
    - User preferences

    Args:
        current_user: The authenticated user

    Returns:
        UserProfileResponse: Complete user profile information

    Raises:
        HTTPException: If there's an error retrieving profile data

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[UserProfileResponse]
    """

    kwargs = _get_kwargs()

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
) -> UserProfileResponse | None:
    """Get User Profile

     Get user profile information including user data, environment, legal agreements, and preferences.

    Returns comprehensive user information including:
    - User data (same as authorize endpoint)
    - NAVARI_ENV environment variable
    - Most recent accepted legal agreements
    - User preferences

    Args:
        current_user: The authenticated user

    Returns:
        UserProfileResponse: Complete user profile information

    Raises:
        HTTPException: If there's an error retrieving profile data

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        UserProfileResponse
    """

    return sync_detailed(
        client=client,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
) -> Response[UserProfileResponse]:
    """Get User Profile

     Get user profile information including user data, environment, legal agreements, and preferences.

    Returns comprehensive user information including:
    - User data (same as authorize endpoint)
    - NAVARI_ENV environment variable
    - Most recent accepted legal agreements
    - User preferences

    Args:
        current_user: The authenticated user

    Returns:
        UserProfileResponse: Complete user profile information

    Raises:
        HTTPException: If there's an error retrieving profile data

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[UserProfileResponse]
    """

    kwargs = _get_kwargs()

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
) -> UserProfileResponse | None:
    """Get User Profile

     Get user profile information including user data, environment, legal agreements, and preferences.

    Returns comprehensive user information including:
    - User data (same as authorize endpoint)
    - NAVARI_ENV environment variable
    - Most recent accepted legal agreements
    - User preferences

    Args:
        current_user: The authenticated user

    Returns:
        UserProfileResponse: Complete user profile information

    Raises:
        HTTPException: If there's an error retrieving profile data

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        UserProfileResponse
    """

    return (
        await asyncio_detailed(
            client=client,
        )
    ).parsed
