from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.error_response import ErrorResponse
from ...models.http_validation_error import HTTPValidationError
from ...models.update_user_preference_request import UpdateUserPreferenceRequest
from ...models.user_preferences_response import UserPreferencesResponse
from ...types import Response


def _get_kwargs(
    *,
    body: UpdateUserPreferenceRequest,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "put",
        "url": "/api/user/profile",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ErrorResponse | HTTPValidationError | UserPreferencesResponse | None:
    if response.status_code == 200:
        response_200 = UserPreferencesResponse.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = ErrorResponse.from_dict(response.json())

        return response_400

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if response.status_code == 500:
        response_500 = ErrorResponse.from_dict(response.json())

        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ErrorResponse | HTTPValidationError | UserPreferencesResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: UpdateUserPreferenceRequest,
) -> Response[ErrorResponse | HTTPValidationError | UserPreferencesResponse]:
    """Update user preferences

     Update user preferences. Only provided fields will be updated.

    Args:
        body (UpdateUserPreferenceRequest): Request model for updating user preferences. Only
            provided fields will be updated.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorResponse | HTTPValidationError | UserPreferencesResponse]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    body: UpdateUserPreferenceRequest,
) -> ErrorResponse | HTTPValidationError | UserPreferencesResponse | None:
    """Update user preferences

     Update user preferences. Only provided fields will be updated.

    Args:
        body (UpdateUserPreferenceRequest): Request model for updating user preferences. Only
            provided fields will be updated.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorResponse | HTTPValidationError | UserPreferencesResponse
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: UpdateUserPreferenceRequest,
) -> Response[ErrorResponse | HTTPValidationError | UserPreferencesResponse]:
    """Update user preferences

     Update user preferences. Only provided fields will be updated.

    Args:
        body (UpdateUserPreferenceRequest): Request model for updating user preferences. Only
            provided fields will be updated.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorResponse | HTTPValidationError | UserPreferencesResponse]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    body: UpdateUserPreferenceRequest,
) -> ErrorResponse | HTTPValidationError | UserPreferencesResponse | None:
    """Update user preferences

     Update user preferences. Only provided fields will be updated.

    Args:
        body (UpdateUserPreferenceRequest): Request model for updating user preferences. Only
            provided fields will be updated.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorResponse | HTTPValidationError | UserPreferencesResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
