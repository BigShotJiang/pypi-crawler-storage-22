from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.a2a_task_event_status_type_0 import A2ATaskEventStatusType0


T = TypeVar("T", bound="A2ATaskEvent")


@_attrs_define
class A2ATaskEvent:
    """A2A Task event model for validation.

    Attributes:
        id (str): Task ID
        context_id (str): Context ID
        kind (Literal['task'] | Unset): A2A task kind Default: 'task'.
        status (A2ATaskEventStatusType0 | None | Unset): Task status object
        timestamp (None | str | Unset): ISO timestamp
    """

    id: str
    context_id: str
    kind: Literal["task"] | Unset = "task"
    status: A2ATaskEventStatusType0 | None | Unset = UNSET
    timestamp: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.a2a_task_event_status_type_0 import A2ATaskEventStatusType0

        id = self.id

        context_id = self.context_id

        kind = self.kind

        status: dict[str, Any] | None | Unset
        if isinstance(self.status, Unset):
            status = UNSET
        elif isinstance(self.status, A2ATaskEventStatusType0):
            status = self.status.to_dict()
        else:
            status = self.status

        timestamp: None | str | Unset
        if isinstance(self.timestamp, Unset):
            timestamp = UNSET
        else:
            timestamp = self.timestamp

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "contextId": context_id,
            }
        )
        if kind is not UNSET:
            field_dict["kind"] = kind
        if status is not UNSET:
            field_dict["status"] = status
        if timestamp is not UNSET:
            field_dict["timestamp"] = timestamp

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.a2a_task_event_status_type_0 import A2ATaskEventStatusType0

        d = dict(src_dict)
        id = d.pop("id")

        context_id = d.pop("contextId")

        kind = cast(Literal["task"] | Unset, d.pop("kind", UNSET))
        if kind != "task" and not isinstance(kind, Unset):
            raise ValueError(f"kind must match const 'task', got '{kind}'")

        def _parse_status(data: object) -> A2ATaskEventStatusType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                status_type_0 = A2ATaskEventStatusType0.from_dict(data)

                return status_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(A2ATaskEventStatusType0 | None | Unset, data)

        status = _parse_status(d.pop("status", UNSET))

        def _parse_timestamp(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        timestamp = _parse_timestamp(d.pop("timestamp", UNSET))

        a2a_task_event = cls(
            id=id,
            context_id=context_id,
            kind=kind,
            status=status,
            timestamp=timestamp,
        )

        a2a_task_event.additional_properties = d
        return a2a_task_event

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
