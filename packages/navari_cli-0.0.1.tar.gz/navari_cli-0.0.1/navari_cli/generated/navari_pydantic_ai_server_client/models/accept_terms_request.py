from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.legal_agreement_acceptance_request import LegalAgreementAcceptanceRequest


T = TypeVar("T", bound="AcceptTermsRequest")


@_attrs_define
class AcceptTermsRequest:
    """Request model for accepting terms and conditions and privacy policy.

    Attributes:
        terms_and_conditions (LegalAgreementAcceptanceRequest): Request model for accepting a legal agreement.
        privacy_policy (LegalAgreementAcceptanceRequest): Request model for accepting a legal agreement.
    """

    terms_and_conditions: LegalAgreementAcceptanceRequest
    privacy_policy: LegalAgreementAcceptanceRequest
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        terms_and_conditions = self.terms_and_conditions.to_dict()

        privacy_policy = self.privacy_policy.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "terms_and_conditions": terms_and_conditions,
                "privacy_policy": privacy_policy,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.legal_agreement_acceptance_request import LegalAgreementAcceptanceRequest

        d = dict(src_dict)
        terms_and_conditions = LegalAgreementAcceptanceRequest.from_dict(d.pop("terms_and_conditions"))

        privacy_policy = LegalAgreementAcceptanceRequest.from_dict(d.pop("privacy_policy"))

        accept_terms_request = cls(
            terms_and_conditions=terms_and_conditions,
            privacy_policy=privacy_policy,
        )

        accept_terms_request.additional_properties = d
        return accept_terms_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
