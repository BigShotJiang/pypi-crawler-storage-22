from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.agent_result_event_event_kind import AgentResultEventEventKind
from ..types import UNSET, Unset

T = TypeVar("T", bound="AgentResultEvent")


@_attrs_define
class AgentResultEvent:
    """Event sent when the agent produces a final result.

    Attributes:
        event_kind (AgentResultEventEventKind):
        timestamp (str):
        run_id (str):
        summary (str):
        deployment_url (None | str | Unset):
    """

    event_kind: AgentResultEventEventKind
    timestamp: str
    run_id: str
    summary: str
    deployment_url: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        event_kind = self.event_kind.value

        timestamp = self.timestamp

        run_id = self.run_id

        summary = self.summary

        deployment_url: None | str | Unset
        if isinstance(self.deployment_url, Unset):
            deployment_url = UNSET
        else:
            deployment_url = self.deployment_url

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "event_kind": event_kind,
                "timestamp": timestamp,
                "run_id": run_id,
                "summary": summary,
            }
        )
        if deployment_url is not UNSET:
            field_dict["deployment_url"] = deployment_url

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        event_kind = AgentResultEventEventKind(d.pop("event_kind"))

        timestamp = d.pop("timestamp")

        run_id = d.pop("run_id")

        summary = d.pop("summary")

        def _parse_deployment_url(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        deployment_url = _parse_deployment_url(d.pop("deployment_url", UNSET))

        agent_result_event = cls(
            event_kind=event_kind,
            timestamp=timestamp,
            run_id=run_id,
            summary=summary,
            deployment_url=deployment_url,
        )

        agent_result_event.additional_properties = d
        return agent_result_event

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
