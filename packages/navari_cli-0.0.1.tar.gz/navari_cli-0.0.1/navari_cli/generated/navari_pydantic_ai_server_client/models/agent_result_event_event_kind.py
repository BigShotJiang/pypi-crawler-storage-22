from enum import Enum


class AgentResultEventEventKind(str, Enum):
    AGENT_RESULT = "agent_result"

    def __str__(self) -> str:
        return str(self.value)
