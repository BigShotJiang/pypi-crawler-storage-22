from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.authorize_response_user import AuthorizeResponseUser


T = TypeVar("T", bound="AuthorizeResponse")


@_attrs_define
class AuthorizeResponse:
    """Response model for authorization requests.

    Attributes:
        user (AuthorizeResponseUser):
    """

    user: AuthorizeResponseUser
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        user = self.user.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "user": user,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.authorize_response_user import AuthorizeResponseUser

        d = dict(src_dict)
        user = AuthorizeResponseUser.from_dict(d.pop("user"))

        authorize_response = cls(
            user=user,
        )

        authorize_response.additional_properties = d
        return authorize_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
