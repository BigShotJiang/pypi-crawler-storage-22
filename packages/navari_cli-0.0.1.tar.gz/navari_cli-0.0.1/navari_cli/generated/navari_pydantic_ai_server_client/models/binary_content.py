from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.binary_content_media_type_type_0 import BinaryContentMediaTypeType0
from ..models.binary_content_media_type_type_1 import BinaryContentMediaTypeType1
from ..models.binary_content_media_type_type_2 import BinaryContentMediaTypeType2
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.binary_content_vendor_metadata_type_0 import BinaryContentVendorMetadataType0


T = TypeVar("T", bound="BinaryContent")


@_attrs_define
class BinaryContent:
    """Binary content, e.g. an audio or image file.

    Attributes:
        data (str):
        media_type (BinaryContentMediaTypeType0 | BinaryContentMediaTypeType1 | BinaryContentMediaTypeType2 | str):
        identifier (str): Identifier for the binary content, such as a unique ID.

            This identifier can be provided to the model in a message to allow it to refer to this file in a tool call
            argument,
            and the tool can look up the file in question by iterating over the message history and finding the matching
            `BinaryContent`.

            This identifier is only automatically passed to the model when the `BinaryContent` is returned by a tool.
            If you're passing the `BinaryContent` as a user message, it's up to you to include a separate text part with the
            identifier,
            e.g. "This is file <identifier>:" preceding the `BinaryContent`.

            It's also included in inline-text delimiters for providers that require inlining text documents, so the model
            can
            distinguish multiple files.
        vendor_metadata (BinaryContentVendorMetadataType0 | None | Unset):
        kind (Literal['binary'] | Unset):  Default: 'binary'.
    """

    data: str
    media_type: BinaryContentMediaTypeType0 | BinaryContentMediaTypeType1 | BinaryContentMediaTypeType2 | str
    identifier: str
    vendor_metadata: BinaryContentVendorMetadataType0 | None | Unset = UNSET
    kind: Literal["binary"] | Unset = "binary"
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.binary_content_vendor_metadata_type_0 import BinaryContentVendorMetadataType0

        data = self.data

        media_type: str
        if isinstance(self.media_type, BinaryContentMediaTypeType0):
            media_type = self.media_type.value
        elif isinstance(self.media_type, BinaryContentMediaTypeType1):
            media_type = self.media_type.value
        elif isinstance(self.media_type, BinaryContentMediaTypeType2):
            media_type = self.media_type.value
        else:
            media_type = self.media_type

        identifier = self.identifier

        vendor_metadata: dict[str, Any] | None | Unset
        if isinstance(self.vendor_metadata, Unset):
            vendor_metadata = UNSET
        elif isinstance(self.vendor_metadata, BinaryContentVendorMetadataType0):
            vendor_metadata = self.vendor_metadata.to_dict()
        else:
            vendor_metadata = self.vendor_metadata

        kind = self.kind

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "data": data,
                "media_type": media_type,
                "identifier": identifier,
            }
        )
        if vendor_metadata is not UNSET:
            field_dict["vendor_metadata"] = vendor_metadata
        if kind is not UNSET:
            field_dict["kind"] = kind

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.binary_content_vendor_metadata_type_0 import BinaryContentVendorMetadataType0

        d = dict(src_dict)
        data = d.pop("data")

        def _parse_media_type(
            data: object,
        ) -> BinaryContentMediaTypeType0 | BinaryContentMediaTypeType1 | BinaryContentMediaTypeType2 | str:
            try:
                if not isinstance(data, str):
                    raise TypeError()
                media_type_type_0 = BinaryContentMediaTypeType0(data)

                return media_type_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, str):
                    raise TypeError()
                media_type_type_1 = BinaryContentMediaTypeType1(data)

                return media_type_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, str):
                    raise TypeError()
                media_type_type_2 = BinaryContentMediaTypeType2(data)

                return media_type_type_2
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(
                BinaryContentMediaTypeType0 | BinaryContentMediaTypeType1 | BinaryContentMediaTypeType2 | str, data
            )

        media_type = _parse_media_type(d.pop("media_type"))

        identifier = d.pop("identifier")

        def _parse_vendor_metadata(data: object) -> BinaryContentVendorMetadataType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                vendor_metadata_type_0 = BinaryContentVendorMetadataType0.from_dict(data)

                return vendor_metadata_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(BinaryContentVendorMetadataType0 | None | Unset, data)

        vendor_metadata = _parse_vendor_metadata(d.pop("vendor_metadata", UNSET))

        kind = cast(Literal["binary"] | Unset, d.pop("kind", UNSET))
        if kind != "binary" and not isinstance(kind, Unset):
            raise ValueError(f"kind must match const 'binary', got '{kind}'")

        binary_content = cls(
            data=data,
            media_type=media_type,
            identifier=identifier,
            vendor_metadata=vendor_metadata,
            kind=kind,
        )

        binary_content.additional_properties = d
        return binary_content

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
