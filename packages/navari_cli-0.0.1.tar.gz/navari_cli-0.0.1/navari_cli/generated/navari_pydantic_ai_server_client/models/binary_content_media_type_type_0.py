from enum import Enum


class BinaryContentMediaTypeType0(str, Enum):
    AUDIOAAC = "audio/aac"
    AUDIOAIFF = "audio/aiff"
    AUDIOFLAC = "audio/flac"
    AUDIOMPEG = "audio/mpeg"
    AUDIOOGG = "audio/ogg"
    AUDIOWAV = "audio/wav"

    def __str__(self) -> str:
        return str(self.value)
