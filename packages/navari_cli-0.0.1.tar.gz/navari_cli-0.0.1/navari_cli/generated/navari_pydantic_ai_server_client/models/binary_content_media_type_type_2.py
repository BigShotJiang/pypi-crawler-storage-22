from enum import Enum


class BinaryContentMediaTypeType2(str, Enum):
    APPLICATIONMSWORD = "application/msword"
    APPLICATIONPDF = "application/pdf"
    APPLICATIONVND_MS_EXCEL = "application/vnd.ms-excel"
    APPLICATIONVND_OPENXMLFORMATS_OFFICEDOCUMENT_SPREADSHEETML_SHEET = (
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )
    APPLICATIONVND_OPENXMLFORMATS_OFFICEDOCUMENT_WORDPROCESSINGML_DOCUMENT = (
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    )
    TEXTCSV = "text/csv"
    TEXTHTML = "text/html"
    TEXTMARKDOWN = "text/markdown"
    TEXTPLAIN = "text/plain"

    def __str__(self) -> str:
        return str(self.value)
