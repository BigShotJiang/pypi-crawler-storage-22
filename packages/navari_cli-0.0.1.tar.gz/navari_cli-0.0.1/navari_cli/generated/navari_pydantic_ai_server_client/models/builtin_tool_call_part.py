from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.builtin_tool_call_part_args_type_1 import BuiltinToolCallPartArgsType1
    from ..models.builtin_tool_call_part_provider_details_type_0 import BuiltinToolCallPartProviderDetailsType0


T = TypeVar("T", bound="BuiltinToolCallPart")


@_attrs_define
class BuiltinToolCallPart:
    """
    Attributes:
        tool_name (str):
        args (BuiltinToolCallPartArgsType1 | None | str | Unset):
        tool_call_id (str | Unset):
        id (None | str | Unset):
        provider_name (None | str | Unset):
        provider_details (BuiltinToolCallPartProviderDetailsType0 | None | Unset):
        part_kind (Literal['builtin-tool-call'] | Unset):  Default: 'builtin-tool-call'.
    """

    tool_name: str
    args: BuiltinToolCallPartArgsType1 | None | str | Unset = UNSET
    tool_call_id: str | Unset = UNSET
    id: None | str | Unset = UNSET
    provider_name: None | str | Unset = UNSET
    provider_details: BuiltinToolCallPartProviderDetailsType0 | None | Unset = UNSET
    part_kind: Literal["builtin-tool-call"] | Unset = "builtin-tool-call"
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.builtin_tool_call_part_args_type_1 import BuiltinToolCallPartArgsType1
        from ..models.builtin_tool_call_part_provider_details_type_0 import BuiltinToolCallPartProviderDetailsType0

        tool_name = self.tool_name

        args: dict[str, Any] | None | str | Unset
        if isinstance(self.args, Unset):
            args = UNSET
        elif isinstance(self.args, BuiltinToolCallPartArgsType1):
            args = self.args.to_dict()
        else:
            args = self.args

        tool_call_id = self.tool_call_id

        id: None | str | Unset
        if isinstance(self.id, Unset):
            id = UNSET
        else:
            id = self.id

        provider_name: None | str | Unset
        if isinstance(self.provider_name, Unset):
            provider_name = UNSET
        else:
            provider_name = self.provider_name

        provider_details: dict[str, Any] | None | Unset
        if isinstance(self.provider_details, Unset):
            provider_details = UNSET
        elif isinstance(self.provider_details, BuiltinToolCallPartProviderDetailsType0):
            provider_details = self.provider_details.to_dict()
        else:
            provider_details = self.provider_details

        part_kind = self.part_kind

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "tool_name": tool_name,
            }
        )
        if args is not UNSET:
            field_dict["args"] = args
        if tool_call_id is not UNSET:
            field_dict["tool_call_id"] = tool_call_id
        if id is not UNSET:
            field_dict["id"] = id
        if provider_name is not UNSET:
            field_dict["provider_name"] = provider_name
        if provider_details is not UNSET:
            field_dict["provider_details"] = provider_details
        if part_kind is not UNSET:
            field_dict["part_kind"] = part_kind

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.builtin_tool_call_part_args_type_1 import BuiltinToolCallPartArgsType1
        from ..models.builtin_tool_call_part_provider_details_type_0 import BuiltinToolCallPartProviderDetailsType0

        d = dict(src_dict)
        tool_name = d.pop("tool_name")

        def _parse_args(data: object) -> BuiltinToolCallPartArgsType1 | None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                args_type_1 = BuiltinToolCallPartArgsType1.from_dict(data)

                return args_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(BuiltinToolCallPartArgsType1 | None | str | Unset, data)

        args = _parse_args(d.pop("args", UNSET))

        tool_call_id = d.pop("tool_call_id", UNSET)

        def _parse_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        id = _parse_id(d.pop("id", UNSET))

        def _parse_provider_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        provider_name = _parse_provider_name(d.pop("provider_name", UNSET))

        def _parse_provider_details(data: object) -> BuiltinToolCallPartProviderDetailsType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                provider_details_type_0 = BuiltinToolCallPartProviderDetailsType0.from_dict(data)

                return provider_details_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(BuiltinToolCallPartProviderDetailsType0 | None | Unset, data)

        provider_details = _parse_provider_details(d.pop("provider_details", UNSET))

        part_kind = cast(Literal["builtin-tool-call"] | Unset, d.pop("part_kind", UNSET))
        if part_kind != "builtin-tool-call" and not isinstance(part_kind, Unset):
            raise ValueError(f"part_kind must match const 'builtin-tool-call', got '{part_kind}'")

        builtin_tool_call_part = cls(
            tool_name=tool_name,
            args=args,
            tool_call_id=tool_call_id,
            id=id,
            provider_name=provider_name,
            provider_details=provider_details,
            part_kind=part_kind,
        )

        builtin_tool_call_part.additional_properties = d
        return builtin_tool_call_part

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
