from __future__ import annotations

from collections.abc import Mapping
from typing import Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.cache_point_ttl import CachePointTtl
from ..types import UNSET, Unset

T = TypeVar("T", bound="CachePoint")


@_attrs_define
class CachePoint:
    """
    Attributes:
        kind (Literal['cache-point'] | Unset):  Default: 'cache-point'.
        ttl (CachePointTtl | Unset):  Default: CachePointTtl.VALUE_0.
    """

    kind: Literal["cache-point"] | Unset = "cache-point"
    ttl: CachePointTtl | Unset = CachePointTtl.VALUE_0
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        kind = self.kind

        ttl: str | Unset = UNSET
        if not isinstance(self.ttl, Unset):
            ttl = self.ttl.value

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if kind is not UNSET:
            field_dict["kind"] = kind
        if ttl is not UNSET:
            field_dict["ttl"] = ttl

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        kind = cast(Literal["cache-point"] | Unset, d.pop("kind", UNSET))
        if kind != "cache-point" and not isinstance(kind, Unset):
            raise ValueError(f"kind must match const 'cache-point', got '{kind}'")

        _ttl = d.pop("ttl", UNSET)
        ttl: CachePointTtl | Unset
        if isinstance(_ttl, Unset):
            ttl = UNSET
        else:
            ttl = CachePointTtl(_ttl)

        cache_point = cls(
            kind=kind,
            ttl=ttl,
        )

        cache_point.additional_properties = d
        return cache_point

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
