from enum import Enum


class CachePointTtl(str, Enum):
    VALUE_0 = "5m"
    VALUE_1 = "1h"

    def __str__(self) -> str:
        return str(self.value)
