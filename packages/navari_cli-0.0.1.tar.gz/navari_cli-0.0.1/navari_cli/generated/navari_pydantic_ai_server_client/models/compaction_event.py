from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.compaction_event_event_kind import CompactionEventEventKind
from ..types import UNSET, Unset

T = TypeVar("T", bound="CompactionEvent")


@_attrs_define
class CompactionEvent:
    """History compaction event sent when conversation history is summarized.

    Attributes:
        original_messages (int): Number of messages before compaction
        compacted_messages (int): Number of messages after compaction
        original_tokens (int): Token count before compaction
        compacted_tokens (int): Token count after compaction
        summary (str): Summary of compacted conversation
        timestamp (str): ISO timestamp of compaction
        event_kind (CompactionEventEventKind | Unset):  Default: CompactionEventEventKind.COMPACTION.
        run_id (None | str | Unset): Run ID if available
    """

    original_messages: int
    compacted_messages: int
    original_tokens: int
    compacted_tokens: int
    summary: str
    timestamp: str
    event_kind: CompactionEventEventKind | Unset = CompactionEventEventKind.COMPACTION
    run_id: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        original_messages = self.original_messages

        compacted_messages = self.compacted_messages

        original_tokens = self.original_tokens

        compacted_tokens = self.compacted_tokens

        summary = self.summary

        timestamp = self.timestamp

        event_kind: str | Unset = UNSET
        if not isinstance(self.event_kind, Unset):
            event_kind = self.event_kind.value

        run_id: None | str | Unset
        if isinstance(self.run_id, Unset):
            run_id = UNSET
        else:
            run_id = self.run_id

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "original_messages": original_messages,
                "compacted_messages": compacted_messages,
                "original_tokens": original_tokens,
                "compacted_tokens": compacted_tokens,
                "summary": summary,
                "timestamp": timestamp,
            }
        )
        if event_kind is not UNSET:
            field_dict["event_kind"] = event_kind
        if run_id is not UNSET:
            field_dict["run_id"] = run_id

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        original_messages = d.pop("original_messages")

        compacted_messages = d.pop("compacted_messages")

        original_tokens = d.pop("original_tokens")

        compacted_tokens = d.pop("compacted_tokens")

        summary = d.pop("summary")

        timestamp = d.pop("timestamp")

        _event_kind = d.pop("event_kind", UNSET)
        event_kind: CompactionEventEventKind | Unset
        if isinstance(_event_kind, Unset):
            event_kind = UNSET
        else:
            event_kind = CompactionEventEventKind(_event_kind)

        def _parse_run_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        run_id = _parse_run_id(d.pop("run_id", UNSET))

        compaction_event = cls(
            original_messages=original_messages,
            compacted_messages=compacted_messages,
            original_tokens=original_tokens,
            compacted_tokens=compacted_tokens,
            summary=summary,
            timestamp=timestamp,
            event_kind=event_kind,
            run_id=run_id,
        )

        compaction_event.additional_properties = d
        return compaction_event

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
