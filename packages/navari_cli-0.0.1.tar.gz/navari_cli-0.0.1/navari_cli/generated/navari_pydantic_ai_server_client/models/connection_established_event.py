from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.connection_established_event_event_kind import ConnectionEstablishedEventEventKind
from ..models.run_state import RunState

T = TypeVar("T", bound="ConnectionEstablishedEvent")


@_attrs_define
class ConnectionEstablishedEvent:
    """Event sent when a WebSocket connection is established.

    Attributes:
        event_kind (ConnectionEstablishedEventEventKind):
        timestamp (str):
        run_id (str):
        conversation_id (str):
        run_state (RunState): Run state enumeration
    """

    event_kind: ConnectionEstablishedEventEventKind
    timestamp: str
    run_id: str
    conversation_id: str
    run_state: RunState
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        event_kind = self.event_kind.value

        timestamp = self.timestamp

        run_id = self.run_id

        conversation_id = self.conversation_id

        run_state = self.run_state.value

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "event_kind": event_kind,
                "timestamp": timestamp,
                "run_id": run_id,
                "conversation_id": conversation_id,
                "run_state": run_state,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        event_kind = ConnectionEstablishedEventEventKind(d.pop("event_kind"))

        timestamp = d.pop("timestamp")

        run_id = d.pop("run_id")

        conversation_id = d.pop("conversation_id")

        run_state = RunState(d.pop("run_state"))

        connection_established_event = cls(
            event_kind=event_kind,
            timestamp=timestamp,
            run_id=run_id,
            conversation_id=conversation_id,
            run_state=run_state,
        )

        connection_established_event.additional_properties = d
        return connection_established_event

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
