from enum import Enum


class ConnectionEstablishedEventEventKind(str, Enum):
    CONNECTION_ESTABLISHED = "connection_established"

    def __str__(self) -> str:
        return str(self.value)
