from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.conversation_mode import ConversationMode
from ..models.private_transition_reason import PrivateTransitionReason
from ..types import UNSET, Unset

T = TypeVar("T", bound="ConversationDetailResponse")


@_attrs_define
class ConversationDetailResponse:
    """Extended response model for single conversation GET with feature flags.

    Attributes:
        id (str): Unique identifier for the conversation
        user_id (str): User ID associated with the conversation
        title (str): Title of the conversation
        created_at (datetime.datetime): Creation timestamp
        last_active (datetime.datetime): Last activity timestamp
        mode (ConversationMode): Conversation privacy mode.
        active_run_id (None | str | Unset): Current active run ID, if any
        status (None | str | Unset): Current status of the conversation
        mode_changed_at (datetime.datetime | None | Unset): Timestamp when mode was last changed
        mode_change_reason (None | PrivateTransitionReason | Unset): Reason for mode change: 'upload',
            'user_preference', or 'tool_access'.
        available_features (list[str] | Unset): Available features for this conversation based on MCP capabilities
    """

    id: str
    user_id: str
    title: str
    created_at: datetime.datetime
    last_active: datetime.datetime
    mode: ConversationMode
    active_run_id: None | str | Unset = UNSET
    status: None | str | Unset = UNSET
    mode_changed_at: datetime.datetime | None | Unset = UNSET
    mode_change_reason: None | PrivateTransitionReason | Unset = UNSET
    available_features: list[str] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        user_id = self.user_id

        title = self.title

        created_at = self.created_at.isoformat()

        last_active = self.last_active.isoformat()

        mode = self.mode.value

        active_run_id: None | str | Unset
        if isinstance(self.active_run_id, Unset):
            active_run_id = UNSET
        else:
            active_run_id = self.active_run_id

        status: None | str | Unset
        if isinstance(self.status, Unset):
            status = UNSET
        else:
            status = self.status

        mode_changed_at: None | str | Unset
        if isinstance(self.mode_changed_at, Unset):
            mode_changed_at = UNSET
        elif isinstance(self.mode_changed_at, datetime.datetime):
            mode_changed_at = self.mode_changed_at.isoformat()
        else:
            mode_changed_at = self.mode_changed_at

        mode_change_reason: None | str | Unset
        if isinstance(self.mode_change_reason, Unset):
            mode_change_reason = UNSET
        elif isinstance(self.mode_change_reason, PrivateTransitionReason):
            mode_change_reason = self.mode_change_reason.value
        else:
            mode_change_reason = self.mode_change_reason

        available_features: list[str] | Unset = UNSET
        if not isinstance(self.available_features, Unset):
            available_features = self.available_features

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "user_id": user_id,
                "title": title,
                "created_at": created_at,
                "last_active": last_active,
                "mode": mode,
            }
        )
        if active_run_id is not UNSET:
            field_dict["active_run_id"] = active_run_id
        if status is not UNSET:
            field_dict["status"] = status
        if mode_changed_at is not UNSET:
            field_dict["mode_changed_at"] = mode_changed_at
        if mode_change_reason is not UNSET:
            field_dict["mode_change_reason"] = mode_change_reason
        if available_features is not UNSET:
            field_dict["available_features"] = available_features

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id")

        user_id = d.pop("user_id")

        title = d.pop("title")

        created_at = isoparse(d.pop("created_at"))

        last_active = isoparse(d.pop("last_active"))

        mode = ConversationMode(d.pop("mode"))

        def _parse_active_run_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        active_run_id = _parse_active_run_id(d.pop("active_run_id", UNSET))

        def _parse_status(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        status = _parse_status(d.pop("status", UNSET))

        def _parse_mode_changed_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                mode_changed_at_type_0 = isoparse(data)

                return mode_changed_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        mode_changed_at = _parse_mode_changed_at(d.pop("mode_changed_at", UNSET))

        def _parse_mode_change_reason(data: object) -> None | PrivateTransitionReason | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                mode_change_reason_type_0 = PrivateTransitionReason(data)

                return mode_change_reason_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | PrivateTransitionReason | Unset, data)

        mode_change_reason = _parse_mode_change_reason(d.pop("mode_change_reason", UNSET))

        available_features = cast(list[str], d.pop("available_features", UNSET))

        conversation_detail_response = cls(
            id=id,
            user_id=user_id,
            title=title,
            created_at=created_at,
            last_active=last_active,
            mode=mode,
            active_run_id=active_run_id,
            status=status,
            mode_changed_at=mode_changed_at,
            mode_change_reason=mode_change_reason,
            available_features=available_features,
        )

        conversation_detail_response.additional_properties = d
        return conversation_detail_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
