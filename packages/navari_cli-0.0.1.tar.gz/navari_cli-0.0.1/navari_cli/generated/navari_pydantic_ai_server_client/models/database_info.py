from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="DatabaseInfo")


@_attrs_define
class DatabaseInfo:
    """Information about a single database from mcp-sql.

    Attributes:
        name (str):
        description (None | str | Unset):
        table_count (int | None | Unset):
        database_type (None | str | Unset):
    """

    name: str
    description: None | str | Unset = UNSET
    table_count: int | None | Unset = UNSET
    database_type: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        table_count: int | None | Unset
        if isinstance(self.table_count, Unset):
            table_count = UNSET
        else:
            table_count = self.table_count

        database_type: None | str | Unset
        if isinstance(self.database_type, Unset):
            database_type = UNSET
        else:
            database_type = self.database_type

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
            }
        )
        if description is not UNSET:
            field_dict["description"] = description
        if table_count is not UNSET:
            field_dict["table_count"] = table_count
        if database_type is not UNSET:
            field_dict["database_type"] = database_type

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name")

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_table_count(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        table_count = _parse_table_count(d.pop("table_count", UNSET))

        def _parse_database_type(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        database_type = _parse_database_type(d.pop("database_type", UNSET))

        database_info = cls(
            name=name,
            description=description,
            table_count=table_count,
            database_type=database_type,
        )

        database_info.additional_properties = d
        return database_info

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
