from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.error_details_ctx import ErrorDetailsCtx


T = TypeVar("T", bound="ErrorDetails")


@_attrs_define
class ErrorDetails:
    """
    Attributes:
        type_ (str):
        loc (list[int | str]):
        msg (str):
        input_ (Any):
        ctx (ErrorDetailsCtx | Unset):
        url (str | Unset):
    """

    type_: str
    loc: list[int | str]
    msg: str
    input_: Any
    ctx: ErrorDetailsCtx | Unset = UNSET
    url: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        type_ = self.type_

        loc = []
        for loc_item_data in self.loc:
            loc_item: int | str
            loc_item = loc_item_data
            loc.append(loc_item)

        msg = self.msg

        input_ = self.input_

        ctx: dict[str, Any] | Unset = UNSET
        if not isinstance(self.ctx, Unset):
            ctx = self.ctx.to_dict()

        url = self.url

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "type": type_,
                "loc": loc,
                "msg": msg,
                "input": input_,
            }
        )
        if ctx is not UNSET:
            field_dict["ctx"] = ctx
        if url is not UNSET:
            field_dict["url"] = url

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.error_details_ctx import ErrorDetailsCtx

        d = dict(src_dict)
        type_ = d.pop("type")

        loc = []
        _loc = d.pop("loc")
        for loc_item_data in _loc:

            def _parse_loc_item(data: object) -> int | str:
                return cast(int | str, data)

            loc_item = _parse_loc_item(loc_item_data)

            loc.append(loc_item)

        msg = d.pop("msg")

        input_ = d.pop("input")

        _ctx = d.pop("ctx", UNSET)
        ctx: ErrorDetailsCtx | Unset
        if isinstance(_ctx, Unset):
            ctx = UNSET
        else:
            ctx = ErrorDetailsCtx.from_dict(_ctx)

        url = d.pop("url", UNSET)

        error_details = cls(
            type_=type_,
            loc=loc,
            msg=msg,
            input_=input_,
            ctx=ctx,
            url=url,
        )

        error_details.additional_properties = d
        return error_details

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
