from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.file_response import FileResponse
    from ..models.pagination_info import PaginationInfo


T = TypeVar("T", bound="FileListResponse")


@_attrs_define
class FileListResponse:
    """Response model for listing files.

    Attributes:
        files (list[FileResponse]): List of files
        total (int): Total number of files
        pagination (None | PaginationInfo | Unset): Pagination information
    """

    files: list[FileResponse]
    total: int
    pagination: None | PaginationInfo | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.pagination_info import PaginationInfo

        files = []
        for files_item_data in self.files:
            files_item = files_item_data.to_dict()
            files.append(files_item)

        total = self.total

        pagination: dict[str, Any] | None | Unset
        if isinstance(self.pagination, Unset):
            pagination = UNSET
        elif isinstance(self.pagination, PaginationInfo):
            pagination = self.pagination.to_dict()
        else:
            pagination = self.pagination

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "files": files,
                "total": total,
            }
        )
        if pagination is not UNSET:
            field_dict["pagination"] = pagination

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.file_response import FileResponse
        from ..models.pagination_info import PaginationInfo

        d = dict(src_dict)
        files = []
        _files = d.pop("files")
        for files_item_data in _files:
            files_item = FileResponse.from_dict(files_item_data)

            files.append(files_item)

        total = d.pop("total")

        def _parse_pagination(data: object) -> None | PaginationInfo | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                pagination_type_0 = PaginationInfo.from_dict(data)

                return pagination_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | PaginationInfo | Unset, data)

        pagination = _parse_pagination(d.pop("pagination", UNSET))

        file_list_response = cls(
            files=files,
            total=total,
            pagination=pagination,
        )

        file_list_response.additional_properties = d
        return file_list_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
