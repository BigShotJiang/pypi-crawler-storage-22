from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="FileResponse")


@_attrs_define
class FileResponse:
    """Enhanced response model for file data.

    Attributes:
        id (str): Unique file identifier
        filename (str): Original filename
        size (int): File size in bytes
        mime_type (str): MIME type of the file
        user_id (str): Owner user ID
        created_at (datetime.datetime): Upload timestamp
        download_url (str): URL to download file content
        conversation_id (None | str | Unset): Associated conversation ID
    """

    id: str
    filename: str
    size: int
    mime_type: str
    user_id: str
    created_at: datetime.datetime
    download_url: str
    conversation_id: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        filename = self.filename

        size = self.size

        mime_type = self.mime_type

        user_id = self.user_id

        created_at = self.created_at.isoformat()

        download_url = self.download_url

        conversation_id: None | str | Unset
        if isinstance(self.conversation_id, Unset):
            conversation_id = UNSET
        else:
            conversation_id = self.conversation_id

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "filename": filename,
                "size": size,
                "mime_type": mime_type,
                "user_id": user_id,
                "created_at": created_at,
                "download_url": download_url,
            }
        )
        if conversation_id is not UNSET:
            field_dict["conversation_id"] = conversation_id

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id")

        filename = d.pop("filename")

        size = d.pop("size")

        mime_type = d.pop("mime_type")

        user_id = d.pop("user_id")

        created_at = isoparse(d.pop("created_at"))

        download_url = d.pop("download_url")

        def _parse_conversation_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        conversation_id = _parse_conversation_id(d.pop("conversation_id", UNSET))

        file_response = cls(
            id=id,
            filename=filename,
            size=size,
            mime_type=mime_type,
            user_id=user_id,
            created_at=created_at,
            download_url=download_url,
            conversation_id=conversation_id,
        )

        file_response.additional_properties = d
        return file_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
