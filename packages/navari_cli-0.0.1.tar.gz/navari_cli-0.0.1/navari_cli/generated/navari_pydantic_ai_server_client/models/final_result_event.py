from __future__ import annotations

from collections.abc import Mapping
from typing import Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="FinalResultEvent")


@_attrs_define
class FinalResultEvent:
    """
    Attributes:
        tool_name (None | str):
        tool_call_id (None | str):
        event_kind (Literal['final_result'] | Unset):  Default: 'final_result'.
    """

    tool_name: None | str
    tool_call_id: None | str
    event_kind: Literal["final_result"] | Unset = "final_result"
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        tool_name: None | str
        tool_name = self.tool_name

        tool_call_id: None | str
        tool_call_id = self.tool_call_id

        event_kind = self.event_kind

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "tool_name": tool_name,
                "tool_call_id": tool_call_id,
            }
        )
        if event_kind is not UNSET:
            field_dict["event_kind"] = event_kind

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)

        def _parse_tool_name(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        tool_name = _parse_tool_name(d.pop("tool_name"))

        def _parse_tool_call_id(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        tool_call_id = _parse_tool_call_id(d.pop("tool_call_id"))

        event_kind = cast(Literal["final_result"] | Unset, d.pop("event_kind", UNSET))
        if event_kind != "final_result" and not isinstance(event_kind, Unset):
            raise ValueError(f"event_kind must match const 'final_result', got '{event_kind}'")

        final_result_event = cls(
            tool_name=tool_name,
            tool_call_id=tool_call_id,
            event_kind=event_kind,
        )

        final_result_event.additional_properties = d
        return final_result_event

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
