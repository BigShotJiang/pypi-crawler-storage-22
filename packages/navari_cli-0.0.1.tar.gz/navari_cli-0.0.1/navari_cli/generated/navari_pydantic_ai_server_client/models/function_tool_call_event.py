from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.tool_call_part import ToolCallPart


T = TypeVar("T", bound="FunctionToolCallEvent")


@_attrs_define
class FunctionToolCallEvent:
    """
    Attributes:
        part (ToolCallPart):
        event_kind (Literal['function_tool_call'] | Unset):  Default: 'function_tool_call'.
    """

    part: ToolCallPart
    event_kind: Literal["function_tool_call"] | Unset = "function_tool_call"
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        part = self.part.to_dict()

        event_kind = self.event_kind

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "part": part,
            }
        )
        if event_kind is not UNSET:
            field_dict["event_kind"] = event_kind

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.tool_call_part import ToolCallPart

        d = dict(src_dict)
        part = ToolCallPart.from_dict(d.pop("part"))

        event_kind = cast(Literal["function_tool_call"] | Unset, d.pop("event_kind", UNSET))
        if event_kind != "function_tool_call" and not isinstance(event_kind, Unset):
            raise ValueError(f"event_kind must match const 'function_tool_call', got '{event_kind}'")

        function_tool_call_event = cls(
            part=part,
            event_kind=event_kind,
        )

        function_tool_call_event.additional_properties = d
        return function_tool_call_event

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
