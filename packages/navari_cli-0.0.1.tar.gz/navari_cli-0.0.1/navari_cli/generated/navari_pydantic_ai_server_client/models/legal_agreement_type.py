from enum import Enum


class LegalAgreementType(str, Enum):
    LANDING_PAGE_CONTENT = "landing_page_content"
    PRIVACY_POLICY = "privacy_policy"
    TERMS_AND_CONDITIONS = "terms_and_conditions"

    def __str__(self) -> str:
        return str(self.value)
