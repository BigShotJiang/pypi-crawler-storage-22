from enum import Enum


class ModeChangedEventEventKind(str, Enum):
    MODE_CHANGED = "mode_changed"

    def __str__(self) -> str:
        return str(self.value)
