from enum import Enum


class ModelResponseFinishReasonType0(str, Enum):
    CONTENT_FILTER = "content_filter"
    ERROR = "error"
    LENGTH = "length"
    STOP = "stop"
    TOOL_CALL = "tool_call"

    def __str__(self) -> str:
        return str(self.value)
