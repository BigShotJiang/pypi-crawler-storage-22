from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.text_part_delta import TextPartDelta
    from ..models.thinking_part_delta import ThinkingPartDelta
    from ..models.tool_call_part_delta import ToolCallPartDelta


T = TypeVar("T", bound="PartDeltaEvent")


@_attrs_define
class PartDeltaEvent:
    """
    Attributes:
        index (int):
        delta (TextPartDelta | ThinkingPartDelta | ToolCallPartDelta):
        event_kind (Literal['part_delta'] | Unset):  Default: 'part_delta'.
    """

    index: int
    delta: TextPartDelta | ThinkingPartDelta | ToolCallPartDelta
    event_kind: Literal["part_delta"] | Unset = "part_delta"
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.text_part_delta import TextPartDelta
        from ..models.thinking_part_delta import ThinkingPartDelta

        index = self.index

        delta: dict[str, Any]
        if isinstance(self.delta, TextPartDelta):
            delta = self.delta.to_dict()
        elif isinstance(self.delta, ThinkingPartDelta):
            delta = self.delta.to_dict()
        else:
            delta = self.delta.to_dict()

        event_kind = self.event_kind

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "index": index,
                "delta": delta,
            }
        )
        if event_kind is not UNSET:
            field_dict["event_kind"] = event_kind

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.text_part_delta import TextPartDelta
        from ..models.thinking_part_delta import ThinkingPartDelta
        from ..models.tool_call_part_delta import ToolCallPartDelta

        d = dict(src_dict)
        index = d.pop("index")

        def _parse_delta(data: object) -> TextPartDelta | ThinkingPartDelta | ToolCallPartDelta:
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                delta_type_0 = TextPartDelta.from_dict(data)

                return delta_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                delta_type_1 = ThinkingPartDelta.from_dict(data)

                return delta_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            if not isinstance(data, dict):
                raise TypeError()
            delta_type_2 = ToolCallPartDelta.from_dict(data)

            return delta_type_2

        delta = _parse_delta(d.pop("delta"))

        event_kind = cast(Literal["part_delta"] | Unset, d.pop("event_kind", UNSET))
        if event_kind != "part_delta" and not isinstance(event_kind, Unset):
            raise ValueError(f"event_kind must match const 'part_delta', got '{event_kind}'")

        part_delta_event = cls(
            index=index,
            delta=delta,
            event_kind=event_kind,
        )

        part_delta_event.additional_properties = d
        return part_delta_event

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
