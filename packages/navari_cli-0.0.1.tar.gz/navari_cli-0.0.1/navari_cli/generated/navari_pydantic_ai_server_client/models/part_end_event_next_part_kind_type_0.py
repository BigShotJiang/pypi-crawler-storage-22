from enum import Enum


class PartEndEventNextPartKindType0(str, Enum):
    BUILTIN_TOOL_CALL = "builtin-tool-call"
    BUILTIN_TOOL_RETURN = "builtin-tool-return"
    FILE = "file"
    TEXT = "text"
    THINKING = "thinking"
    TOOL_CALL = "tool-call"

    def __str__(self) -> str:
        return str(self.value)
