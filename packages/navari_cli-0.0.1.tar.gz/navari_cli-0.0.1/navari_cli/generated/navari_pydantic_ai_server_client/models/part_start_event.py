from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.part_start_event_previous_part_kind_type_0 import PartStartEventPreviousPartKindType0
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.builtin_tool_call_part import BuiltinToolCallPart
    from ..models.builtin_tool_return_part import BuiltinToolReturnPart
    from ..models.file_part import FilePart
    from ..models.text_part import TextPart
    from ..models.thinking_part import ThinkingPart
    from ..models.tool_call_part import ToolCallPart


T = TypeVar("T", bound="PartStartEvent")


@_attrs_define
class PartStartEvent:
    """
    Attributes:
        index (int):
        part (BuiltinToolCallPart | BuiltinToolReturnPart | FilePart | TextPart | ThinkingPart | ToolCallPart):
        previous_part_kind (None | PartStartEventPreviousPartKindType0 | Unset):
        event_kind (Literal['part_start'] | Unset):  Default: 'part_start'.
    """

    index: int
    part: BuiltinToolCallPart | BuiltinToolReturnPart | FilePart | TextPart | ThinkingPart | ToolCallPart
    previous_part_kind: None | PartStartEventPreviousPartKindType0 | Unset = UNSET
    event_kind: Literal["part_start"] | Unset = "part_start"
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.builtin_tool_call_part import BuiltinToolCallPart
        from ..models.builtin_tool_return_part import BuiltinToolReturnPart
        from ..models.text_part import TextPart
        from ..models.thinking_part import ThinkingPart
        from ..models.tool_call_part import ToolCallPart

        index = self.index

        part: dict[str, Any]
        if isinstance(self.part, TextPart):
            part = self.part.to_dict()
        elif isinstance(self.part, ToolCallPart):
            part = self.part.to_dict()
        elif isinstance(self.part, BuiltinToolCallPart):
            part = self.part.to_dict()
        elif isinstance(self.part, BuiltinToolReturnPart):
            part = self.part.to_dict()
        elif isinstance(self.part, ThinkingPart):
            part = self.part.to_dict()
        else:
            part = self.part.to_dict()

        previous_part_kind: None | str | Unset
        if isinstance(self.previous_part_kind, Unset):
            previous_part_kind = UNSET
        elif isinstance(self.previous_part_kind, PartStartEventPreviousPartKindType0):
            previous_part_kind = self.previous_part_kind.value
        else:
            previous_part_kind = self.previous_part_kind

        event_kind = self.event_kind

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "index": index,
                "part": part,
            }
        )
        if previous_part_kind is not UNSET:
            field_dict["previous_part_kind"] = previous_part_kind
        if event_kind is not UNSET:
            field_dict["event_kind"] = event_kind

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.builtin_tool_call_part import BuiltinToolCallPart
        from ..models.builtin_tool_return_part import BuiltinToolReturnPart
        from ..models.file_part import FilePart
        from ..models.text_part import TextPart
        from ..models.thinking_part import ThinkingPart
        from ..models.tool_call_part import ToolCallPart

        d = dict(src_dict)
        index = d.pop("index")

        def _parse_part(
            data: object,
        ) -> BuiltinToolCallPart | BuiltinToolReturnPart | FilePart | TextPart | ThinkingPart | ToolCallPart:
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                part_type_0 = TextPart.from_dict(data)

                return part_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                part_type_1 = ToolCallPart.from_dict(data)

                return part_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                part_type_2 = BuiltinToolCallPart.from_dict(data)

                return part_type_2
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                part_type_3 = BuiltinToolReturnPart.from_dict(data)

                return part_type_3
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                part_type_4 = ThinkingPart.from_dict(data)

                return part_type_4
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            if not isinstance(data, dict):
                raise TypeError()
            part_type_5 = FilePart.from_dict(data)

            return part_type_5

        part = _parse_part(d.pop("part"))

        def _parse_previous_part_kind(data: object) -> None | PartStartEventPreviousPartKindType0 | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                previous_part_kind_type_0 = PartStartEventPreviousPartKindType0(data)

                return previous_part_kind_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | PartStartEventPreviousPartKindType0 | Unset, data)

        previous_part_kind = _parse_previous_part_kind(d.pop("previous_part_kind", UNSET))

        event_kind = cast(Literal["part_start"] | Unset, d.pop("event_kind", UNSET))
        if event_kind != "part_start" and not isinstance(event_kind, Unset):
            raise ValueError(f"event_kind must match const 'part_start', got '{event_kind}'")

        part_start_event = cls(
            index=index,
            part=part,
            previous_part_kind=previous_part_kind,
            event_kind=event_kind,
        )

        part_start_event.additional_properties = d
        return part_start_event

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
