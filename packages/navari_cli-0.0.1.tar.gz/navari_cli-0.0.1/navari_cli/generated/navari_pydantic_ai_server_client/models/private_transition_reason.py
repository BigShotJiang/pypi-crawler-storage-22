from enum import Enum


class PrivateTransitionReason(str, Enum):
    TOOL_ACCESS = "tool_access"
    UPLOAD = "upload"
    USER_PREFERENCE = "user_preference"

    def __str__(self) -> str:
        return str(self.value)
