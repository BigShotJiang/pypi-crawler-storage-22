from enum import Enum


class ProcessingCancelledEventEventKind(str, Enum):
    PROCESSING_CANCELLED = "processing_cancelled"

    def __str__(self) -> str:
        return str(self.value)
