from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.processing_finished_event_event_kind import ProcessingFinishedEventEventKind

T = TypeVar("T", bound="ProcessingFinishedEvent")


@_attrs_define
class ProcessingFinishedEvent:
    """Event sent when processing of a query finishes.

    Attributes:
        event_kind (ProcessingFinishedEventEventKind):
        timestamp (str):
        run_id (str):
    """

    event_kind: ProcessingFinishedEventEventKind
    timestamp: str
    run_id: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        event_kind = self.event_kind.value

        timestamp = self.timestamp

        run_id = self.run_id

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "event_kind": event_kind,
                "timestamp": timestamp,
                "run_id": run_id,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        event_kind = ProcessingFinishedEventEventKind(d.pop("event_kind"))

        timestamp = d.pop("timestamp")

        run_id = d.pop("run_id")

        processing_finished_event = cls(
            event_kind=event_kind,
            timestamp=timestamp,
            run_id=run_id,
        )

        processing_finished_event.additional_properties = d
        return processing_finished_event

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
