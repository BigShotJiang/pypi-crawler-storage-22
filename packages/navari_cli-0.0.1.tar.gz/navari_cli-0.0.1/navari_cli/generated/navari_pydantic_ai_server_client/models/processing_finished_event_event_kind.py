from enum import Enum


class ProcessingFinishedEventEventKind(str, Enum):
    PROCESSING_FINISHED = "processing_finished"

    def __str__(self) -> str:
        return str(self.value)
