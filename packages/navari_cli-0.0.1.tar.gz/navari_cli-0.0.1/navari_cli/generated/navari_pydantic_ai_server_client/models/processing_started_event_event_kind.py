from enum import Enum


class ProcessingStartedEventEventKind(str, Enum):
    PROCESSING_STARTED = "processing_started"

    def __str__(self) -> str:
        return str(self.value)
