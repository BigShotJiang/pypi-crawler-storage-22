from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.request_usage_details import RequestUsageDetails


T = TypeVar("T", bound="RequestUsage")


@_attrs_define
class RequestUsage:
    """
    Attributes:
        input_tokens (int | Unset):  Default: 0.
        cache_write_tokens (int | Unset):  Default: 0.
        cache_read_tokens (int | Unset):  Default: 0.
        output_tokens (int | Unset):  Default: 0.
        input_audio_tokens (int | Unset):  Default: 0.
        cache_audio_read_tokens (int | Unset):  Default: 0.
        output_audio_tokens (int | Unset):  Default: 0.
        details (RequestUsageDetails | Unset):
    """

    input_tokens: int | Unset = 0
    cache_write_tokens: int | Unset = 0
    cache_read_tokens: int | Unset = 0
    output_tokens: int | Unset = 0
    input_audio_tokens: int | Unset = 0
    cache_audio_read_tokens: int | Unset = 0
    output_audio_tokens: int | Unset = 0
    details: RequestUsageDetails | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        input_tokens = self.input_tokens

        cache_write_tokens = self.cache_write_tokens

        cache_read_tokens = self.cache_read_tokens

        output_tokens = self.output_tokens

        input_audio_tokens = self.input_audio_tokens

        cache_audio_read_tokens = self.cache_audio_read_tokens

        output_audio_tokens = self.output_audio_tokens

        details: dict[str, Any] | Unset = UNSET
        if not isinstance(self.details, Unset):
            details = self.details.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if input_tokens is not UNSET:
            field_dict["input_tokens"] = input_tokens
        if cache_write_tokens is not UNSET:
            field_dict["cache_write_tokens"] = cache_write_tokens
        if cache_read_tokens is not UNSET:
            field_dict["cache_read_tokens"] = cache_read_tokens
        if output_tokens is not UNSET:
            field_dict["output_tokens"] = output_tokens
        if input_audio_tokens is not UNSET:
            field_dict["input_audio_tokens"] = input_audio_tokens
        if cache_audio_read_tokens is not UNSET:
            field_dict["cache_audio_read_tokens"] = cache_audio_read_tokens
        if output_audio_tokens is not UNSET:
            field_dict["output_audio_tokens"] = output_audio_tokens
        if details is not UNSET:
            field_dict["details"] = details

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.request_usage_details import RequestUsageDetails

        d = dict(src_dict)
        input_tokens = d.pop("input_tokens", UNSET)

        cache_write_tokens = d.pop("cache_write_tokens", UNSET)

        cache_read_tokens = d.pop("cache_read_tokens", UNSET)

        output_tokens = d.pop("output_tokens", UNSET)

        input_audio_tokens = d.pop("input_audio_tokens", UNSET)

        cache_audio_read_tokens = d.pop("cache_audio_read_tokens", UNSET)

        output_audio_tokens = d.pop("output_audio_tokens", UNSET)

        _details = d.pop("details", UNSET)
        details: RequestUsageDetails | Unset
        if isinstance(_details, Unset):
            details = UNSET
        else:
            details = RequestUsageDetails.from_dict(_details)

        request_usage = cls(
            input_tokens=input_tokens,
            cache_write_tokens=cache_write_tokens,
            cache_read_tokens=cache_read_tokens,
            output_tokens=output_tokens,
            input_audio_tokens=input_audio_tokens,
            cache_audio_read_tokens=cache_audio_read_tokens,
            output_audio_tokens=output_audio_tokens,
            details=details,
        )

        request_usage.additional_properties = d
        return request_usage

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
