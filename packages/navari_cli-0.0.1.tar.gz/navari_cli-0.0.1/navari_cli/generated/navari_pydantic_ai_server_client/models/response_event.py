from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="ResponseEvent")


@_attrs_define
class ResponseEvent:
    """Event sent when a response is made.

    Attributes:
        response (str): The response text
        timestamp (str | Unset):
        file_ids (list[str] | None | Unset): List of file IDs attached to this response
    """

    response: str
    timestamp: str | Unset = UNSET
    file_ids: list[str] | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        response = self.response

        timestamp = self.timestamp

        file_ids: list[str] | None | Unset
        if isinstance(self.file_ids, Unset):
            file_ids = UNSET
        elif isinstance(self.file_ids, list):
            file_ids = self.file_ids

        else:
            file_ids = self.file_ids

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "response": response,
            }
        )
        if timestamp is not UNSET:
            field_dict["timestamp"] = timestamp
        if file_ids is not UNSET:
            field_dict["file_ids"] = file_ids

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        response = d.pop("response")

        timestamp = d.pop("timestamp", UNSET)

        def _parse_file_ids(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                file_ids_type_0 = cast(list[str], data)

                return file_ids_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        file_ids = _parse_file_ids(d.pop("file_ids", UNSET))

        response_event = cls(
            response=response,
            timestamp=timestamp,
            file_ids=file_ids,
        )

        response_event.additional_properties = d
        return response_event

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
