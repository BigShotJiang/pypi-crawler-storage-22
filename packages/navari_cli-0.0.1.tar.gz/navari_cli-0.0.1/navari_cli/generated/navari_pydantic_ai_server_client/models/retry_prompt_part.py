from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.error_details import ErrorDetails


T = TypeVar("T", bound="RetryPromptPart")


@_attrs_define
class RetryPromptPart:
    """
    Attributes:
        content (list[ErrorDetails] | str):
        tool_name (None | str | Unset):
        tool_call_id (str | Unset):
        timestamp (datetime.datetime | Unset):
        part_kind (Literal['retry-prompt'] | Unset):  Default: 'retry-prompt'.
    """

    content: list[ErrorDetails] | str
    tool_name: None | str | Unset = UNSET
    tool_call_id: str | Unset = UNSET
    timestamp: datetime.datetime | Unset = UNSET
    part_kind: Literal["retry-prompt"] | Unset = "retry-prompt"
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        content: list[dict[str, Any]] | str
        if isinstance(self.content, list):
            content = []
            for content_type_0_item_data in self.content:
                content_type_0_item = content_type_0_item_data.to_dict()
                content.append(content_type_0_item)

        else:
            content = self.content

        tool_name: None | str | Unset
        if isinstance(self.tool_name, Unset):
            tool_name = UNSET
        else:
            tool_name = self.tool_name

        tool_call_id = self.tool_call_id

        timestamp: str | Unset = UNSET
        if not isinstance(self.timestamp, Unset):
            timestamp = self.timestamp.isoformat()

        part_kind = self.part_kind

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "content": content,
            }
        )
        if tool_name is not UNSET:
            field_dict["tool_name"] = tool_name
        if tool_call_id is not UNSET:
            field_dict["tool_call_id"] = tool_call_id
        if timestamp is not UNSET:
            field_dict["timestamp"] = timestamp
        if part_kind is not UNSET:
            field_dict["part_kind"] = part_kind

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.error_details import ErrorDetails

        d = dict(src_dict)

        def _parse_content(data: object) -> list[ErrorDetails] | str:
            try:
                if not isinstance(data, list):
                    raise TypeError()
                content_type_0 = []
                _content_type_0 = data
                for content_type_0_item_data in _content_type_0:
                    content_type_0_item = ErrorDetails.from_dict(content_type_0_item_data)

                    content_type_0.append(content_type_0_item)

                return content_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[ErrorDetails] | str, data)

        content = _parse_content(d.pop("content"))

        def _parse_tool_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        tool_name = _parse_tool_name(d.pop("tool_name", UNSET))

        tool_call_id = d.pop("tool_call_id", UNSET)

        _timestamp = d.pop("timestamp", UNSET)
        timestamp: datetime.datetime | Unset
        if isinstance(_timestamp, Unset):
            timestamp = UNSET
        else:
            timestamp = isoparse(_timestamp)

        part_kind = cast(Literal["retry-prompt"] | Unset, d.pop("part_kind", UNSET))
        if part_kind != "retry-prompt" and not isinstance(part_kind, Unset):
            raise ValueError(f"part_kind must match const 'retry-prompt', got '{part_kind}'")

        retry_prompt_part = cls(
            content=content,
            tool_name=tool_name,
            tool_call_id=tool_call_id,
            timestamp=timestamp,
            part_kind=part_kind,
        )

        retry_prompt_part.additional_properties = d
        return retry_prompt_part

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
