from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.response_meta import ResponseMeta


T = TypeVar("T", bound="RunCancelResponse")


@_attrs_define
class RunCancelResponse:
    """Response model for run cancellation.

    Attributes:
        success (bool): Whether cancellation was successful
        message (str): Cancellation message
        conversation_id (str): Conversation ID of cancelled run
        meta (ResponseMeta | Unset): Response metadata.
    """

    success: bool
    message: str
    conversation_id: str
    meta: ResponseMeta | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        success = self.success

        message = self.message

        conversation_id = self.conversation_id

        meta: dict[str, Any] | Unset = UNSET
        if not isinstance(self.meta, Unset):
            meta = self.meta.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "success": success,
                "message": message,
                "conversation_id": conversation_id,
            }
        )
        if meta is not UNSET:
            field_dict["meta"] = meta

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.response_meta import ResponseMeta

        d = dict(src_dict)
        success = d.pop("success")

        message = d.pop("message")

        conversation_id = d.pop("conversation_id")

        _meta = d.pop("meta", UNSET)
        meta: ResponseMeta | Unset
        if isinstance(_meta, Unset):
            meta = UNSET
        else:
            meta = ResponseMeta.from_dict(_meta)

        run_cancel_response = cls(
            success=success,
            message=message,
            conversation_id=conversation_id,
            meta=meta,
        )

        run_cancel_response.additional_properties = d
        return run_cancel_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
