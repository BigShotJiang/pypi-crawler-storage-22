from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.pagination_info import PaginationInfo
    from ..models.run_status_response import RunStatusResponse


T = TypeVar("T", bound="RunListResponse")


@_attrs_define
class RunListResponse:
    """Enhanced response model for listing runs.

    Attributes:
        runs (list[RunStatusResponse]): List of runs
        total (int): Total number of runs
        pagination (None | PaginationInfo | Unset): Pagination information
    """

    runs: list[RunStatusResponse]
    total: int
    pagination: None | PaginationInfo | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.pagination_info import PaginationInfo

        runs = []
        for runs_item_data in self.runs:
            runs_item = runs_item_data.to_dict()
            runs.append(runs_item)

        total = self.total

        pagination: dict[str, Any] | None | Unset
        if isinstance(self.pagination, Unset):
            pagination = UNSET
        elif isinstance(self.pagination, PaginationInfo):
            pagination = self.pagination.to_dict()
        else:
            pagination = self.pagination

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "runs": runs,
                "total": total,
            }
        )
        if pagination is not UNSET:
            field_dict["pagination"] = pagination

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.pagination_info import PaginationInfo
        from ..models.run_status_response import RunStatusResponse

        d = dict(src_dict)
        runs = []
        _runs = d.pop("runs")
        for runs_item_data in _runs:
            runs_item = RunStatusResponse.from_dict(runs_item_data)

            runs.append(runs_item)

        total = d.pop("total")

        def _parse_pagination(data: object) -> None | PaginationInfo | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                pagination_type_0 = PaginationInfo.from_dict(data)

                return pagination_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | PaginationInfo | Unset, data)

        pagination = _parse_pagination(d.pop("pagination", UNSET))

        run_list_response = cls(
            runs=runs,
            total=total,
            pagination=pagination,
        )

        run_list_response.additional_properties = d
        return run_list_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
