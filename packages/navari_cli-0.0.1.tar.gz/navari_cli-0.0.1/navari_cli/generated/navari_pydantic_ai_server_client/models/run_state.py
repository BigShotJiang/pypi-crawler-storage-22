from enum import Enum


class RunState(str, Enum):
    CANCELLED = "cancelled"
    CANCELLING = "cancelling"
    COMPLETED = "completed"
    DISCONNECTED = "disconnected"
    ERROR = "error"
    IDLE = "idle"
    RUNNING = "running"
    WAITING_FOR_INPUT = "waiting_for_input"

    def __str__(self) -> str:
        return str(self.value)
