from enum import Enum


class SkillSource(str, Enum):
    UPLOAD = "upload"

    def __str__(self) -> str:
        return str(self.value)
