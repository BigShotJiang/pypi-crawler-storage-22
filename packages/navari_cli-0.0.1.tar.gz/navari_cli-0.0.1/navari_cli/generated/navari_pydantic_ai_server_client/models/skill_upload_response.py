from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.user_skill_entry import UserSkillEntry


T = TypeVar("T", bound="SkillUploadResponse")


@_attrs_define
class SkillUploadResponse:
    """Response for skill upload.

    Attributes:
        success (bool):
        skill (UserSkillEntry): Entry in the user's skills manifest.
        message (str):
    """

    success: bool
    skill: UserSkillEntry
    message: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        success = self.success

        skill = self.skill.to_dict()

        message = self.message

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "success": success,
                "skill": skill,
                "message": message,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.user_skill_entry import UserSkillEntry

        d = dict(src_dict)
        success = d.pop("success")

        skill = UserSkillEntry.from_dict(d.pop("skill"))

        message = d.pop("message")

        skill_upload_response = cls(
            success=success,
            skill=skill,
            message=message,
        )

        skill_upload_response.additional_properties = d
        return skill_upload_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
