from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.status_update_event_event_kind import StatusUpdateEventEventKind

T = TypeVar("T", bound="StatusUpdateEvent")


@_attrs_define
class StatusUpdateEvent:
    """Event sent when the status of a conversation changes.

    Attributes:
        event_kind (StatusUpdateEventEventKind):
        timestamp (str):
        run_id (str):
        status (str):
        message (str):
    """

    event_kind: StatusUpdateEventEventKind
    timestamp: str
    run_id: str
    status: str
    message: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        event_kind = self.event_kind.value

        timestamp = self.timestamp

        run_id = self.run_id

        status = self.status

        message = self.message

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "event_kind": event_kind,
                "timestamp": timestamp,
                "run_id": run_id,
                "status": status,
                "message": message,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        event_kind = StatusUpdateEventEventKind(d.pop("event_kind"))

        timestamp = d.pop("timestamp")

        run_id = d.pop("run_id")

        status = d.pop("status")

        message = d.pop("message")

        status_update_event = cls(
            event_kind=event_kind,
            timestamp=timestamp,
            run_id=run_id,
            status=status,
            message=message,
        )

        status_update_event.additional_properties = d
        return status_update_event

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
