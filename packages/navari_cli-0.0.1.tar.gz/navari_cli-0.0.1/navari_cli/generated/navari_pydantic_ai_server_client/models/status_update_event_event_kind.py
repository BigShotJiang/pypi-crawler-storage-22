from enum import Enum


class StatusUpdateEventEventKind(str, Enum):
    STATUS_UPDATE = "status_update"

    def __str__(self) -> str:
        return str(self.value)
