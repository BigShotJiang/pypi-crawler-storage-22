from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="SystemPromptPart")


@_attrs_define
class SystemPromptPart:
    """
    Attributes:
        content (str):
        timestamp (datetime.datetime | Unset):
        dynamic_ref (None | str | Unset):
        part_kind (Literal['system-prompt'] | Unset):  Default: 'system-prompt'.
    """

    content: str
    timestamp: datetime.datetime | Unset = UNSET
    dynamic_ref: None | str | Unset = UNSET
    part_kind: Literal["system-prompt"] | Unset = "system-prompt"
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        content = self.content

        timestamp: str | Unset = UNSET
        if not isinstance(self.timestamp, Unset):
            timestamp = self.timestamp.isoformat()

        dynamic_ref: None | str | Unset
        if isinstance(self.dynamic_ref, Unset):
            dynamic_ref = UNSET
        else:
            dynamic_ref = self.dynamic_ref

        part_kind = self.part_kind

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "content": content,
            }
        )
        if timestamp is not UNSET:
            field_dict["timestamp"] = timestamp
        if dynamic_ref is not UNSET:
            field_dict["dynamic_ref"] = dynamic_ref
        if part_kind is not UNSET:
            field_dict["part_kind"] = part_kind

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        content = d.pop("content")

        _timestamp = d.pop("timestamp", UNSET)
        timestamp: datetime.datetime | Unset
        if isinstance(_timestamp, Unset):
            timestamp = UNSET
        else:
            timestamp = isoparse(_timestamp)

        def _parse_dynamic_ref(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        dynamic_ref = _parse_dynamic_ref(d.pop("dynamic_ref", UNSET))

        part_kind = cast(Literal["system-prompt"] | Unset, d.pop("part_kind", UNSET))
        if part_kind != "system-prompt" and not isinstance(part_kind, Unset):
            raise ValueError(f"part_kind must match const 'system-prompt', got '{part_kind}'")

        system_prompt_part = cls(
            content=content,
            timestamp=timestamp,
            dynamic_ref=dynamic_ref,
            part_kind=part_kind,
        )

        system_prompt_part.additional_properties = d
        return system_prompt_part

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
