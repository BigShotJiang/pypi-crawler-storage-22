from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.text_part_delta_provider_details_type_0 import TextPartDeltaProviderDetailsType0


T = TypeVar("T", bound="TextPartDelta")


@_attrs_define
class TextPartDelta:
    """
    Attributes:
        content_delta (str):
        provider_name (None | str | Unset):
        provider_details (None | TextPartDeltaProviderDetailsType0 | Unset):
        part_delta_kind (Literal['text'] | Unset):  Default: 'text'.
    """

    content_delta: str
    provider_name: None | str | Unset = UNSET
    provider_details: None | TextPartDeltaProviderDetailsType0 | Unset = UNSET
    part_delta_kind: Literal["text"] | Unset = "text"
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.text_part_delta_provider_details_type_0 import TextPartDeltaProviderDetailsType0

        content_delta = self.content_delta

        provider_name: None | str | Unset
        if isinstance(self.provider_name, Unset):
            provider_name = UNSET
        else:
            provider_name = self.provider_name

        provider_details: dict[str, Any] | None | Unset
        if isinstance(self.provider_details, Unset):
            provider_details = UNSET
        elif isinstance(self.provider_details, TextPartDeltaProviderDetailsType0):
            provider_details = self.provider_details.to_dict()
        else:
            provider_details = self.provider_details

        part_delta_kind = self.part_delta_kind

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "content_delta": content_delta,
            }
        )
        if provider_name is not UNSET:
            field_dict["provider_name"] = provider_name
        if provider_details is not UNSET:
            field_dict["provider_details"] = provider_details
        if part_delta_kind is not UNSET:
            field_dict["part_delta_kind"] = part_delta_kind

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.text_part_delta_provider_details_type_0 import TextPartDeltaProviderDetailsType0

        d = dict(src_dict)
        content_delta = d.pop("content_delta")

        def _parse_provider_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        provider_name = _parse_provider_name(d.pop("provider_name", UNSET))

        def _parse_provider_details(data: object) -> None | TextPartDeltaProviderDetailsType0 | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                provider_details_type_0 = TextPartDeltaProviderDetailsType0.from_dict(data)

                return provider_details_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | TextPartDeltaProviderDetailsType0 | Unset, data)

        provider_details = _parse_provider_details(d.pop("provider_details", UNSET))

        part_delta_kind = cast(Literal["text"] | Unset, d.pop("part_delta_kind", UNSET))
        if part_delta_kind != "text" and not isinstance(part_delta_kind, Unset):
            raise ValueError(f"part_delta_kind must match const 'text', got '{part_delta_kind}'")

        text_part_delta = cls(
            content_delta=content_delta,
            provider_name=provider_name,
            provider_details=provider_details,
            part_delta_kind=part_delta_kind,
        )

        text_part_delta.additional_properties = d
        return text_part_delta

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
