from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.thinking_part_provider_details_type_0 import ThinkingPartProviderDetailsType0


T = TypeVar("T", bound="ThinkingPart")


@_attrs_define
class ThinkingPart:
    """
    Attributes:
        content (str):
        id (None | str | Unset):
        signature (None | str | Unset):
        provider_name (None | str | Unset):
        provider_details (None | ThinkingPartProviderDetailsType0 | Unset):
        part_kind (Literal['thinking'] | Unset):  Default: 'thinking'.
    """

    content: str
    id: None | str | Unset = UNSET
    signature: None | str | Unset = UNSET
    provider_name: None | str | Unset = UNSET
    provider_details: None | ThinkingPartProviderDetailsType0 | Unset = UNSET
    part_kind: Literal["thinking"] | Unset = "thinking"
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.thinking_part_provider_details_type_0 import ThinkingPartProviderDetailsType0

        content = self.content

        id: None | str | Unset
        if isinstance(self.id, Unset):
            id = UNSET
        else:
            id = self.id

        signature: None | str | Unset
        if isinstance(self.signature, Unset):
            signature = UNSET
        else:
            signature = self.signature

        provider_name: None | str | Unset
        if isinstance(self.provider_name, Unset):
            provider_name = UNSET
        else:
            provider_name = self.provider_name

        provider_details: dict[str, Any] | None | Unset
        if isinstance(self.provider_details, Unset):
            provider_details = UNSET
        elif isinstance(self.provider_details, ThinkingPartProviderDetailsType0):
            provider_details = self.provider_details.to_dict()
        else:
            provider_details = self.provider_details

        part_kind = self.part_kind

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "content": content,
            }
        )
        if id is not UNSET:
            field_dict["id"] = id
        if signature is not UNSET:
            field_dict["signature"] = signature
        if provider_name is not UNSET:
            field_dict["provider_name"] = provider_name
        if provider_details is not UNSET:
            field_dict["provider_details"] = provider_details
        if part_kind is not UNSET:
            field_dict["part_kind"] = part_kind

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.thinking_part_provider_details_type_0 import ThinkingPartProviderDetailsType0

        d = dict(src_dict)
        content = d.pop("content")

        def _parse_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        id = _parse_id(d.pop("id", UNSET))

        def _parse_signature(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        signature = _parse_signature(d.pop("signature", UNSET))

        def _parse_provider_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        provider_name = _parse_provider_name(d.pop("provider_name", UNSET))

        def _parse_provider_details(data: object) -> None | ThinkingPartProviderDetailsType0 | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                provider_details_type_0 = ThinkingPartProviderDetailsType0.from_dict(data)

                return provider_details_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | ThinkingPartProviderDetailsType0 | Unset, data)

        provider_details = _parse_provider_details(d.pop("provider_details", UNSET))

        part_kind = cast(Literal["thinking"] | Unset, d.pop("part_kind", UNSET))
        if part_kind != "thinking" and not isinstance(part_kind, Unset):
            raise ValueError(f"part_kind must match const 'thinking', got '{part_kind}'")

        thinking_part = cls(
            content=content,
            id=id,
            signature=signature,
            provider_name=provider_name,
            provider_details=provider_details,
            part_kind=part_kind,
        )

        thinking_part.additional_properties = d
        return thinking_part

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
