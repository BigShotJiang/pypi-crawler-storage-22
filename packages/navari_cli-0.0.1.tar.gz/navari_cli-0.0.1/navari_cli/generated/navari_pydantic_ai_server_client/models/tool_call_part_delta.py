from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.tool_call_part_delta_args_delta_type_1 import ToolCallPartDeltaArgsDeltaType1
    from ..models.tool_call_part_delta_provider_details_type_0 import ToolCallPartDeltaProviderDetailsType0


T = TypeVar("T", bound="ToolCallPartDelta")


@_attrs_define
class ToolCallPartDelta:
    """
    Attributes:
        tool_name_delta (None | str | Unset):
        args_delta (None | str | ToolCallPartDeltaArgsDeltaType1 | Unset):
        tool_call_id (None | str | Unset):
        provider_name (None | str | Unset):
        provider_details (None | ToolCallPartDeltaProviderDetailsType0 | Unset):
        part_delta_kind (Literal['tool_call'] | Unset):  Default: 'tool_call'.
    """

    tool_name_delta: None | str | Unset = UNSET
    args_delta: None | str | ToolCallPartDeltaArgsDeltaType1 | Unset = UNSET
    tool_call_id: None | str | Unset = UNSET
    provider_name: None | str | Unset = UNSET
    provider_details: None | ToolCallPartDeltaProviderDetailsType0 | Unset = UNSET
    part_delta_kind: Literal["tool_call"] | Unset = "tool_call"
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.tool_call_part_delta_args_delta_type_1 import ToolCallPartDeltaArgsDeltaType1
        from ..models.tool_call_part_delta_provider_details_type_0 import ToolCallPartDeltaProviderDetailsType0

        tool_name_delta: None | str | Unset
        if isinstance(self.tool_name_delta, Unset):
            tool_name_delta = UNSET
        else:
            tool_name_delta = self.tool_name_delta

        args_delta: dict[str, Any] | None | str | Unset
        if isinstance(self.args_delta, Unset):
            args_delta = UNSET
        elif isinstance(self.args_delta, ToolCallPartDeltaArgsDeltaType1):
            args_delta = self.args_delta.to_dict()
        else:
            args_delta = self.args_delta

        tool_call_id: None | str | Unset
        if isinstance(self.tool_call_id, Unset):
            tool_call_id = UNSET
        else:
            tool_call_id = self.tool_call_id

        provider_name: None | str | Unset
        if isinstance(self.provider_name, Unset):
            provider_name = UNSET
        else:
            provider_name = self.provider_name

        provider_details: dict[str, Any] | None | Unset
        if isinstance(self.provider_details, Unset):
            provider_details = UNSET
        elif isinstance(self.provider_details, ToolCallPartDeltaProviderDetailsType0):
            provider_details = self.provider_details.to_dict()
        else:
            provider_details = self.provider_details

        part_delta_kind = self.part_delta_kind

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if tool_name_delta is not UNSET:
            field_dict["tool_name_delta"] = tool_name_delta
        if args_delta is not UNSET:
            field_dict["args_delta"] = args_delta
        if tool_call_id is not UNSET:
            field_dict["tool_call_id"] = tool_call_id
        if provider_name is not UNSET:
            field_dict["provider_name"] = provider_name
        if provider_details is not UNSET:
            field_dict["provider_details"] = provider_details
        if part_delta_kind is not UNSET:
            field_dict["part_delta_kind"] = part_delta_kind

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.tool_call_part_delta_args_delta_type_1 import ToolCallPartDeltaArgsDeltaType1
        from ..models.tool_call_part_delta_provider_details_type_0 import ToolCallPartDeltaProviderDetailsType0

        d = dict(src_dict)

        def _parse_tool_name_delta(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        tool_name_delta = _parse_tool_name_delta(d.pop("tool_name_delta", UNSET))

        def _parse_args_delta(data: object) -> None | str | ToolCallPartDeltaArgsDeltaType1 | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                args_delta_type_1 = ToolCallPartDeltaArgsDeltaType1.from_dict(data)

                return args_delta_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | str | ToolCallPartDeltaArgsDeltaType1 | Unset, data)

        args_delta = _parse_args_delta(d.pop("args_delta", UNSET))

        def _parse_tool_call_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        tool_call_id = _parse_tool_call_id(d.pop("tool_call_id", UNSET))

        def _parse_provider_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        provider_name = _parse_provider_name(d.pop("provider_name", UNSET))

        def _parse_provider_details(data: object) -> None | ToolCallPartDeltaProviderDetailsType0 | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                provider_details_type_0 = ToolCallPartDeltaProviderDetailsType0.from_dict(data)

                return provider_details_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | ToolCallPartDeltaProviderDetailsType0 | Unset, data)

        provider_details = _parse_provider_details(d.pop("provider_details", UNSET))

        part_delta_kind = cast(Literal["tool_call"] | Unset, d.pop("part_delta_kind", UNSET))
        if part_delta_kind != "tool_call" and not isinstance(part_delta_kind, Unset):
            raise ValueError(f"part_delta_kind must match const 'tool_call', got '{part_delta_kind}'")

        tool_call_part_delta = cls(
            tool_name_delta=tool_name_delta,
            args_delta=args_delta,
            tool_call_id=tool_call_id,
            provider_name=provider_name,
            provider_details=provider_details,
            part_delta_kind=part_delta_kind,
        )

        tool_call_part_delta.additional_properties = d
        return tool_call_part_delta

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
