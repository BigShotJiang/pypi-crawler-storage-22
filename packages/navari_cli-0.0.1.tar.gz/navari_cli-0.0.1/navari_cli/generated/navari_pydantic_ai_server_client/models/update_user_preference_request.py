from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.conversation_mode import ConversationMode
from ..types import UNSET, Unset

T = TypeVar("T", bound="UpdateUserPreferenceRequest")


@_attrs_define
class UpdateUserPreferenceRequest:
    """Request model for updating user preferences. Only provided fields will be updated.

    Attributes:
        default_conversation_mode (ConversationMode | None | Unset): New default conversation mode
    """

    default_conversation_mode: ConversationMode | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        default_conversation_mode: None | str | Unset
        if isinstance(self.default_conversation_mode, Unset):
            default_conversation_mode = UNSET
        elif isinstance(self.default_conversation_mode, ConversationMode):
            default_conversation_mode = self.default_conversation_mode.value
        else:
            default_conversation_mode = self.default_conversation_mode

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if default_conversation_mode is not UNSET:
            field_dict["default_conversation_mode"] = default_conversation_mode

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)

        def _parse_default_conversation_mode(data: object) -> ConversationMode | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                default_conversation_mode_type_0 = ConversationMode(data)

                return default_conversation_mode_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ConversationMode | None | Unset, data)

        default_conversation_mode = _parse_default_conversation_mode(d.pop("default_conversation_mode", UNSET))

        update_user_preference_request = cls(
            default_conversation_mode=default_conversation_mode,
        )

        update_user_preference_request.additional_properties = d
        return update_user_preference_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
