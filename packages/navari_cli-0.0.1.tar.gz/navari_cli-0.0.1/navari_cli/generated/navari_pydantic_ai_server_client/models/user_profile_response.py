from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.accepted_legal_agreements import AcceptedLegalAgreements
    from ..models.user_preferences_response import UserPreferencesResponse
    from ..models.user_profile_response_user import UserProfileResponseUser


T = TypeVar("T", bound="UserProfileResponse")


@_attrs_define
class UserProfileResponse:
    """Response model for user profile information.

    Attributes:
        user (UserProfileResponseUser):
        navari_env (None | str):
        accepted_legal_agreements (AcceptedLegalAgreements | None):
        preferences (None | UserPreferencesResponse):
        is_legal_agreements_accepted (bool): Whether user has accepted current versions of all legal agreements
    """

    user: UserProfileResponseUser
    navari_env: None | str
    accepted_legal_agreements: AcceptedLegalAgreements | None
    preferences: None | UserPreferencesResponse
    is_legal_agreements_accepted: bool
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.accepted_legal_agreements import AcceptedLegalAgreements
        from ..models.user_preferences_response import UserPreferencesResponse

        user = self.user.to_dict()

        navari_env: None | str
        navari_env = self.navari_env

        accepted_legal_agreements: dict[str, Any] | None
        if isinstance(self.accepted_legal_agreements, AcceptedLegalAgreements):
            accepted_legal_agreements = self.accepted_legal_agreements.to_dict()
        else:
            accepted_legal_agreements = self.accepted_legal_agreements

        preferences: dict[str, Any] | None
        if isinstance(self.preferences, UserPreferencesResponse):
            preferences = self.preferences.to_dict()
        else:
            preferences = self.preferences

        is_legal_agreements_accepted = self.is_legal_agreements_accepted

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "user": user,
                "navari_env": navari_env,
                "accepted_legal_agreements": accepted_legal_agreements,
                "preferences": preferences,
                "is_legal_agreements_accepted": is_legal_agreements_accepted,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.accepted_legal_agreements import AcceptedLegalAgreements
        from ..models.user_preferences_response import UserPreferencesResponse
        from ..models.user_profile_response_user import UserProfileResponseUser

        d = dict(src_dict)
        user = UserProfileResponseUser.from_dict(d.pop("user"))

        def _parse_navari_env(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        navari_env = _parse_navari_env(d.pop("navari_env"))

        def _parse_accepted_legal_agreements(data: object) -> AcceptedLegalAgreements | None:
            if data is None:
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                accepted_legal_agreements_type_0 = AcceptedLegalAgreements.from_dict(data)

                return accepted_legal_agreements_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(AcceptedLegalAgreements | None, data)

        accepted_legal_agreements = _parse_accepted_legal_agreements(d.pop("accepted_legal_agreements"))

        def _parse_preferences(data: object) -> None | UserPreferencesResponse:
            if data is None:
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                preferences_type_0 = UserPreferencesResponse.from_dict(data)

                return preferences_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | UserPreferencesResponse, data)

        preferences = _parse_preferences(d.pop("preferences"))

        is_legal_agreements_accepted = d.pop("is_legal_agreements_accepted")

        user_profile_response = cls(
            user=user,
            navari_env=navari_env,
            accepted_legal_agreements=accepted_legal_agreements,
            preferences=preferences,
            is_legal_agreements_accepted=is_legal_agreements_accepted,
        )

        user_profile_response.additional_properties = d
        return user_profile_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
