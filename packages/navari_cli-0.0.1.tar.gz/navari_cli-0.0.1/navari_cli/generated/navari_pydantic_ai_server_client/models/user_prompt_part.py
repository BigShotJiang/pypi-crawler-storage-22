from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.audio_url import AudioUrl
    from ..models.binary_content import BinaryContent
    from ..models.cache_point import CachePoint
    from ..models.document_url import DocumentUrl
    from ..models.image_url import ImageUrl
    from ..models.video_url import VideoUrl


T = TypeVar("T", bound="UserPromptPart")


@_attrs_define
class UserPromptPart:
    """
    Attributes:
        content (list[AudioUrl | BinaryContent | CachePoint | DocumentUrl | ImageUrl | str | VideoUrl] | str):
        timestamp (datetime.datetime | Unset):
        part_kind (Literal['user-prompt'] | Unset):  Default: 'user-prompt'.
    """

    content: list[AudioUrl | BinaryContent | CachePoint | DocumentUrl | ImageUrl | str | VideoUrl] | str
    timestamp: datetime.datetime | Unset = UNSET
    part_kind: Literal["user-prompt"] | Unset = "user-prompt"
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.audio_url import AudioUrl
        from ..models.binary_content import BinaryContent
        from ..models.cache_point import CachePoint
        from ..models.document_url import DocumentUrl
        from ..models.image_url import ImageUrl
        from ..models.video_url import VideoUrl

        content: list[dict[str, Any] | str] | str
        if isinstance(self.content, list):
            content = []
            for content_type_1_item_data in self.content:
                content_type_1_item: dict[str, Any] | str
                if isinstance(content_type_1_item_data, ImageUrl):
                    content_type_1_item = content_type_1_item_data.to_dict()
                elif isinstance(content_type_1_item_data, AudioUrl):
                    content_type_1_item = content_type_1_item_data.to_dict()
                elif isinstance(content_type_1_item_data, DocumentUrl):
                    content_type_1_item = content_type_1_item_data.to_dict()
                elif isinstance(content_type_1_item_data, VideoUrl):
                    content_type_1_item = content_type_1_item_data.to_dict()
                elif isinstance(content_type_1_item_data, BinaryContent):
                    content_type_1_item = content_type_1_item_data.to_dict()
                elif isinstance(content_type_1_item_data, CachePoint):
                    content_type_1_item = content_type_1_item_data.to_dict()
                else:
                    content_type_1_item = content_type_1_item_data
                content.append(content_type_1_item)

        else:
            content = self.content

        timestamp: str | Unset = UNSET
        if not isinstance(self.timestamp, Unset):
            timestamp = self.timestamp.isoformat()

        part_kind = self.part_kind

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "content": content,
            }
        )
        if timestamp is not UNSET:
            field_dict["timestamp"] = timestamp
        if part_kind is not UNSET:
            field_dict["part_kind"] = part_kind

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.audio_url import AudioUrl
        from ..models.binary_content import BinaryContent
        from ..models.cache_point import CachePoint
        from ..models.document_url import DocumentUrl
        from ..models.image_url import ImageUrl
        from ..models.video_url import VideoUrl

        d = dict(src_dict)

        def _parse_content(
            data: object,
        ) -> list[AudioUrl | BinaryContent | CachePoint | DocumentUrl | ImageUrl | str | VideoUrl] | str:
            try:
                if not isinstance(data, list):
                    raise TypeError()
                content_type_1 = []
                _content_type_1 = data
                for content_type_1_item_data in _content_type_1:

                    def _parse_content_type_1_item(
                        data: object,
                    ) -> AudioUrl | BinaryContent | CachePoint | DocumentUrl | ImageUrl | str | VideoUrl:
                        try:
                            if not isinstance(data, dict):
                                raise TypeError()
                            content_type_1_item_type_1_type_0 = ImageUrl.from_dict(data)

                            return content_type_1_item_type_1_type_0
                        except (TypeError, ValueError, AttributeError, KeyError):
                            pass
                        try:
                            if not isinstance(data, dict):
                                raise TypeError()
                            content_type_1_item_type_1_type_1 = AudioUrl.from_dict(data)

                            return content_type_1_item_type_1_type_1
                        except (TypeError, ValueError, AttributeError, KeyError):
                            pass
                        try:
                            if not isinstance(data, dict):
                                raise TypeError()
                            content_type_1_item_type_1_type_2 = DocumentUrl.from_dict(data)

                            return content_type_1_item_type_1_type_2
                        except (TypeError, ValueError, AttributeError, KeyError):
                            pass
                        try:
                            if not isinstance(data, dict):
                                raise TypeError()
                            content_type_1_item_type_1_type_3 = VideoUrl.from_dict(data)

                            return content_type_1_item_type_1_type_3
                        except (TypeError, ValueError, AttributeError, KeyError):
                            pass
                        try:
                            if not isinstance(data, dict):
                                raise TypeError()
                            content_type_1_item_type_1_type_4 = BinaryContent.from_dict(data)

                            return content_type_1_item_type_1_type_4
                        except (TypeError, ValueError, AttributeError, KeyError):
                            pass
                        try:
                            if not isinstance(data, dict):
                                raise TypeError()
                            content_type_1_item_type_2 = CachePoint.from_dict(data)

                            return content_type_1_item_type_2
                        except (TypeError, ValueError, AttributeError, KeyError):
                            pass
                        return cast(
                            AudioUrl | BinaryContent | CachePoint | DocumentUrl | ImageUrl | str | VideoUrl, data
                        )

                    content_type_1_item = _parse_content_type_1_item(content_type_1_item_data)

                    content_type_1.append(content_type_1_item)

                return content_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(
                list[AudioUrl | BinaryContent | CachePoint | DocumentUrl | ImageUrl | str | VideoUrl] | str, data
            )

        content = _parse_content(d.pop("content"))

        _timestamp = d.pop("timestamp", UNSET)
        timestamp: datetime.datetime | Unset
        if isinstance(_timestamp, Unset):
            timestamp = UNSET
        else:
            timestamp = isoparse(_timestamp)

        part_kind = cast(Literal["user-prompt"] | Unset, d.pop("part_kind", UNSET))
        if part_kind != "user-prompt" and not isinstance(part_kind, Unset):
            raise ValueError(f"part_kind must match const 'user-prompt', got '{part_kind}'")

        user_prompt_part = cls(
            content=content,
            timestamp=timestamp,
            part_kind=part_kind,
        )

        user_prompt_part.additional_properties = d
        return user_prompt_part

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
