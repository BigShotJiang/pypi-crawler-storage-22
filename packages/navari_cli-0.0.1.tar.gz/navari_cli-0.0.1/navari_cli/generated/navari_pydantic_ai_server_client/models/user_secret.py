from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.user_secret_secrets_type_1 import UserSecretSecretsType1


T = TypeVar("T", bound="UserSecret")


@_attrs_define
class UserSecret:
    """User secret request model.

    Attributes:
        service_name (str):
        secrets (str | UserSecretSecretsType1): Either a single secret string or key-value pairs of secrets
    """

    service_name: str
    secrets: str | UserSecretSecretsType1
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.user_secret_secrets_type_1 import UserSecretSecretsType1

        service_name = self.service_name

        secrets: dict[str, Any] | str
        if isinstance(self.secrets, UserSecretSecretsType1):
            secrets = self.secrets.to_dict()
        else:
            secrets = self.secrets

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "service_name": service_name,
                "secrets": secrets,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.user_secret_secrets_type_1 import UserSecretSecretsType1

        d = dict(src_dict)
        service_name = d.pop("service_name")

        def _parse_secrets(data: object) -> str | UserSecretSecretsType1:
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                secrets_type_1 = UserSecretSecretsType1.from_dict(data)

                return secrets_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(str | UserSecretSecretsType1, data)

        secrets = _parse_secrets(d.pop("secrets"))

        user_secret = cls(
            service_name=service_name,
            secrets=secrets,
        )

        user_secret.additional_properties = d
        return user_secret

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
