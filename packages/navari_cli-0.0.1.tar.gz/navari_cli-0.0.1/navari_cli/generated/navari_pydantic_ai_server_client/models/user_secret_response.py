from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.user_secret_response_secrets_preview_type_1 import UserSecretResponseSecretsPreviewType1


T = TypeVar("T", bound="UserSecretResponse")


@_attrs_define
class UserSecretResponse:
    """User secret response model.

    Attributes:
        service_name (str):
        secrets_preview (str | UserSecretResponseSecretsPreviewType1): Either a masked string or key-value pairs with
            masked values
        created_at (str):
    """

    service_name: str
    secrets_preview: str | UserSecretResponseSecretsPreviewType1
    created_at: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.user_secret_response_secrets_preview_type_1 import UserSecretResponseSecretsPreviewType1

        service_name = self.service_name

        secrets_preview: dict[str, Any] | str
        if isinstance(self.secrets_preview, UserSecretResponseSecretsPreviewType1):
            secrets_preview = self.secrets_preview.to_dict()
        else:
            secrets_preview = self.secrets_preview

        created_at = self.created_at

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "service_name": service_name,
                "secrets_preview": secrets_preview,
                "created_at": created_at,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.user_secret_response_secrets_preview_type_1 import UserSecretResponseSecretsPreviewType1

        d = dict(src_dict)
        service_name = d.pop("service_name")

        def _parse_secrets_preview(data: object) -> str | UserSecretResponseSecretsPreviewType1:
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                secrets_preview_type_1 = UserSecretResponseSecretsPreviewType1.from_dict(data)

                return secrets_preview_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(str | UserSecretResponseSecretsPreviewType1, data)

        secrets_preview = _parse_secrets_preview(d.pop("secrets_preview"))

        created_at = d.pop("created_at")

        user_secret_response = cls(
            service_name=service_name,
            secrets_preview=secrets_preview,
            created_at=created_at,
        )

        user_secret_response.additional_properties = d
        return user_secret_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
