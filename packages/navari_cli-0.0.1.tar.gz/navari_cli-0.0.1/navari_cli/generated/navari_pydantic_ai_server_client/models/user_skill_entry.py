from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.skill_source import SkillSource
from ..types import UNSET, Unset

T = TypeVar("T", bound="UserSkillEntry")


@_attrs_define
class UserSkillEntry:
    """Entry in the user's skills manifest.

    Attributes:
        name (str): Skill name (from SKILL.md)
        description (str): Skill description (from SKILL.md)
        id (str | Unset): Unique skill identifier
        source (SkillSource | Unset): Source type for user skills.
        installed_at (datetime.datetime | Unset):
        version (None | str | Unset): Version if specified in SKILL.md
        has_custom_image (bool | Unset): Whether skill specifies a custom sandbox_image (vs default) Default: False.
        sandbox_image (None | str | Unset): Custom sandbox image if configured, None means use default
    """

    name: str
    description: str
    id: str | Unset = UNSET
    source: SkillSource | Unset = UNSET
    installed_at: datetime.datetime | Unset = UNSET
    version: None | str | Unset = UNSET
    has_custom_image: bool | Unset = False
    sandbox_image: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        description = self.description

        id = self.id

        source: str | Unset = UNSET
        if not isinstance(self.source, Unset):
            source = self.source.value

        installed_at: str | Unset = UNSET
        if not isinstance(self.installed_at, Unset):
            installed_at = self.installed_at.isoformat()

        version: None | str | Unset
        if isinstance(self.version, Unset):
            version = UNSET
        else:
            version = self.version

        has_custom_image = self.has_custom_image

        sandbox_image: None | str | Unset
        if isinstance(self.sandbox_image, Unset):
            sandbox_image = UNSET
        else:
            sandbox_image = self.sandbox_image

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
                "description": description,
            }
        )
        if id is not UNSET:
            field_dict["id"] = id
        if source is not UNSET:
            field_dict["source"] = source
        if installed_at is not UNSET:
            field_dict["installed_at"] = installed_at
        if version is not UNSET:
            field_dict["version"] = version
        if has_custom_image is not UNSET:
            field_dict["has_custom_image"] = has_custom_image
        if sandbox_image is not UNSET:
            field_dict["sandbox_image"] = sandbox_image

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name")

        description = d.pop("description")

        id = d.pop("id", UNSET)

        _source = d.pop("source", UNSET)
        source: SkillSource | Unset
        if isinstance(_source, Unset):
            source = UNSET
        else:
            source = SkillSource(_source)

        _installed_at = d.pop("installed_at", UNSET)
        installed_at: datetime.datetime | Unset
        if isinstance(_installed_at, Unset):
            installed_at = UNSET
        else:
            installed_at = isoparse(_installed_at)

        def _parse_version(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        version = _parse_version(d.pop("version", UNSET))

        has_custom_image = d.pop("has_custom_image", UNSET)

        def _parse_sandbox_image(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        sandbox_image = _parse_sandbox_image(d.pop("sandbox_image", UNSET))

        user_skill_entry = cls(
            name=name,
            description=description,
            id=id,
            source=source,
            installed_at=installed_at,
            version=version,
            has_custom_image=has_custom_image,
            sandbox_image=sandbox_image,
        )

        user_skill_entry.additional_properties = d
        return user_skill_entry

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
