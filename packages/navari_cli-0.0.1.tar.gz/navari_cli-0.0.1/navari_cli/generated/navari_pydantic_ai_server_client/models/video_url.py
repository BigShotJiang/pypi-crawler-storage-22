from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.video_url_vendor_metadata_type_0 import VideoUrlVendorMetadataType0


T = TypeVar("T", bound="VideoUrl")


@_attrs_define
class VideoUrl:
    """A URL to a video.

    Attributes:
        url (str):
        media_type (str): Return the media type of the file, based on the URL or the provided `media_type`.
        identifier (str): The identifier of the file, such as a unique ID.

            This identifier can be provided to the model in a message to allow it to refer to this file in a tool call
            argument,
            and the tool can look up the file in question by iterating over the message history and finding the matching
            `FileUrl`.

            This identifier is only automatically passed to the model when the `FileUrl` is returned by a tool.
            If you're passing the `FileUrl` as a user message, it's up to you to include a separate text part with the
            identifier,
            e.g. "This is file <identifier>:" preceding the `FileUrl`.

            It's also included in inline-text delimiters for providers that require inlining text documents, so the model
            can
            distinguish multiple files.
        force_download (bool | Literal['allow-local'] | Unset):  Default: False.
        vendor_metadata (None | Unset | VideoUrlVendorMetadataType0):
        kind (Literal['video-url'] | Unset):  Default: 'video-url'.
    """

    url: str
    media_type: str
    identifier: str
    force_download: bool | Literal["allow-local"] | Unset = False
    vendor_metadata: None | Unset | VideoUrlVendorMetadataType0 = UNSET
    kind: Literal["video-url"] | Unset = "video-url"
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.video_url_vendor_metadata_type_0 import VideoUrlVendorMetadataType0

        url = self.url

        media_type = self.media_type

        identifier = self.identifier

        force_download: bool | Literal["allow-local"] | Unset
        if isinstance(self.force_download, Unset):
            force_download = UNSET
        else:
            force_download = self.force_download

        vendor_metadata: dict[str, Any] | None | Unset
        if isinstance(self.vendor_metadata, Unset):
            vendor_metadata = UNSET
        elif isinstance(self.vendor_metadata, VideoUrlVendorMetadataType0):
            vendor_metadata = self.vendor_metadata.to_dict()
        else:
            vendor_metadata = self.vendor_metadata

        kind = self.kind

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "url": url,
                "media_type": media_type,
                "identifier": identifier,
            }
        )
        if force_download is not UNSET:
            field_dict["force_download"] = force_download
        if vendor_metadata is not UNSET:
            field_dict["vendor_metadata"] = vendor_metadata
        if kind is not UNSET:
            field_dict["kind"] = kind

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.video_url_vendor_metadata_type_0 import VideoUrlVendorMetadataType0

        d = dict(src_dict)
        url = d.pop("url")

        media_type = d.pop("media_type")

        identifier = d.pop("identifier")

        def _parse_force_download(data: object) -> bool | Literal["allow-local"] | Unset:
            if isinstance(data, Unset):
                return data
            force_download_type_1 = cast(Literal["allow-local"], data)
            if force_download_type_1 != "allow-local":
                raise ValueError(f"force_download_type_1 must match const 'allow-local', got '{force_download_type_1}'")
            return force_download_type_1
            return cast(bool | Literal["allow-local"] | Unset, data)

        force_download = _parse_force_download(d.pop("force_download", UNSET))

        def _parse_vendor_metadata(data: object) -> None | Unset | VideoUrlVendorMetadataType0:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                vendor_metadata_type_0 = VideoUrlVendorMetadataType0.from_dict(data)

                return vendor_metadata_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | VideoUrlVendorMetadataType0, data)

        vendor_metadata = _parse_vendor_metadata(d.pop("vendor_metadata", UNSET))

        kind = cast(Literal["video-url"] | Unset, d.pop("kind", UNSET))
        if kind != "video-url" and not isinstance(kind, Unset):
            raise ValueError(f"kind must match const 'video-url', got '{kind}'")

        video_url = cls(
            url=url,
            media_type=media_type,
            identifier=identifier,
            force_download=force_download,
            vendor_metadata=vendor_metadata,
            kind=kind,
        )

        video_url.additional_properties = d
        return video_url

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
