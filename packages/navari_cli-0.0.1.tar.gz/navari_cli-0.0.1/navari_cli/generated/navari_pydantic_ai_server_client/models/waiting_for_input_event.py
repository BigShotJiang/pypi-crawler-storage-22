from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.waiting_for_input_event_event_kind import WaitingForInputEventEventKind

T = TypeVar("T", bound="WaitingForInputEvent")


@_attrs_define
class WaitingForInputEvent:
    """Event sent when waiting for user input.

    Attributes:
        event_kind (WaitingForInputEventEventKind):
        timestamp (str):
        run_id (str):
        tool_call_id (str):
        tool_name (str):
    """

    event_kind: WaitingForInputEventEventKind
    timestamp: str
    run_id: str
    tool_call_id: str
    tool_name: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        event_kind = self.event_kind.value

        timestamp = self.timestamp

        run_id = self.run_id

        tool_call_id = self.tool_call_id

        tool_name = self.tool_name

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "event_kind": event_kind,
                "timestamp": timestamp,
                "run_id": run_id,
                "tool_call_id": tool_call_id,
                "tool_name": tool_name,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        event_kind = WaitingForInputEventEventKind(d.pop("event_kind"))

        timestamp = d.pop("timestamp")

        run_id = d.pop("run_id")

        tool_call_id = d.pop("tool_call_id")

        tool_name = d.pop("tool_name")

        waiting_for_input_event = cls(
            event_kind=event_kind,
            timestamp=timestamp,
            run_id=run_id,
            tool_call_id=tool_call_id,
            tool_name=tool_name,
        )

        waiting_for_input_event.additional_properties = d
        return waiting_for_input_event

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
