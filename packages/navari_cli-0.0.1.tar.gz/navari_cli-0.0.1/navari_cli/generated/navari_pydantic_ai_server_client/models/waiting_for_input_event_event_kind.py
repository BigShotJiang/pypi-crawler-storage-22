from enum import Enum


class WaitingForInputEventEventKind(str, Enum):
    WAITING_FOR_INPUT = "waiting_for_input"

    def __str__(self) -> str:
        return str(self.value)
