"""Fixtures for integration tests (require running server)."""

import pytest
from navari_cli.config import NavariConfig


@pytest.fixture
def server_url():
    """Server URL from last used server in config.

    Skips the test if no server is configured.
    """
    url = NavariConfig.get_last_used_server()
    if not url:
        pytest.skip("No server configured. Run `navari login <url>` first.")
    return url
