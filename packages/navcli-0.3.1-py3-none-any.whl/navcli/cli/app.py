"""NavCLI - Browser automation command line interface."""

import cmd2
from navcli.cli.client import NavClient
from navcli.cli.commands.navigation import NavigationCommands
from navcli.cli.commands.interaction import InteractionCommands
from navcli.cli.commands.query import QueryCommands
from navcli.cli.commands.explore import ExploreCommands
from navcli.cli.commands.control import ControlCommands
from navcli.cli.connection import DEFAULT_SERVER_URL, check_server_connection, get_server_error_msg


def _print_server_status():
    """Print server connection status."""
    import sys

    if check_server_connection():
        print(f"[OK] Connected to NavCLI server at {DEFAULT_SERVER_URL}")
        return True
    else:
        print(get_server_error_msg(), file=sys.stderr)
        return False


class NavCLI(
    NavigationCommands,
    InteractionCommands,
    QueryCommands,
    ExploreCommands,
    ControlCommands,
    cmd2.Cmd,
):
    """NavCLI main application class."""

    def __init__(self):
        super().__init__(client=NavClient())
        self.prompt = "(navcli) "
        self.doc_header = "Available commands"
        self._server_ok = _print_server_status()


def main():
    """Entry point for navcli command."""
    import sys

    cli = NavCLI()
    if len(sys.argv) > 1:
        if not cli._server_ok:
            sys.exit(1)
        cli.onecmd(" ".join(sys.argv[1:]))
    else:
        cli.cmdloop()


if __name__ == "__main__":
    main()
