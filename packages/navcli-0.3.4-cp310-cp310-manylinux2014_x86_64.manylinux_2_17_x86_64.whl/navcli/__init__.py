"""NavCLI - Interactive browser automation CLI for AI Agents."""

__version__ = "0.3.1"
