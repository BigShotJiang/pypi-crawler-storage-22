"""NavCLI - Browser automation CLI client."""

from navcli.cli.app import NavCLI, main

__all__ = ["NavCLI", "main"]
