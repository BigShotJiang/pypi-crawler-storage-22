"""HTTP client for NavCLI server communication."""

import urllib.parse
from typing import Optional
from urllib.parse import urljoin

import aiohttp

DEFAULT_BASE_URL = "http://127.0.0.1:8765"


class ServerError(Exception):
    """Raised when server returns a 500 error."""

    pass


class NavClient:
    """Async HTTP client for NavCLI server."""

    def __init__(self, base_url: str = DEFAULT_BASE_URL):
        self.base_url = base_url.rstrip("/")
        self.session: Optional[aiohttp.ClientSession] = None

    async def connect(self):
        """Create aiohttp session."""
        if self.session is None:
            self.session = aiohttp.ClientSession()

    async def close(self):
        """Close aiohttp session."""
        if self.session:
            await self.session.close()
            self.session = None

    async def _request(self, method: str, path: str, **kwargs):
        """Make HTTP request to server."""
        if self.session is None:
            await self.connect()

        url = urljoin(self.base_url + "/", path.lstrip("/"))
        async with self.session.request(method, url, **kwargs) as response:
            if response.status == 500:
                raise ServerError(
                    "Server encountered an internal error (500). Please restart the server."
                )
            return await response.json()

    # Navigation commands
    async def goto(self, url: str, wait_until: str = "networkidle"):
        """Navigate to URL."""
        encoded_url = urllib.parse.quote(url, safe="")
        return await self._request("POST", f"/cmd/goto?url={encoded_url}&wait_until={wait_until}")

    async def back(self):
        """Go back in history."""
        return await self._request("POST", "/cmd/back")

    async def forward(self):
        """Go forward in history."""
        return await self._request("POST", "/cmd/forward")

    async def reload(self):
        """Reload current page."""
        return await self._request("POST", "/cmd/reload")

    # Interaction commands
    async def click(self, selector: str, force: bool = False):
        """Click an element."""
        import urllib.parse

        encoded_selector = urllib.parse.quote(selector, safe="")
        return await self._request("POST", f"/cmd/click?selector={encoded_selector}&force={force}")

    async def type(self, selector: str, text: str):
        """Type text into input."""
        import urllib.parse

        encoded_text = urllib.parse.quote(text)
        return await self._request("POST", f"/cmd/type?selector={selector}&text={encoded_text}")

    async def clear(self, selector: str):
        """Clear input field."""
        return await self._request("POST", f"/cmd/clear?selector={selector}")

    async def upload(self, selector: str, file_path: str):
        """Upload file to input."""
        import urllib.parse

        encoded_path = urllib.parse.quote(file_path)
        return await self._request(
            "POST", f"/cmd/upload?selector={selector}&file_path={encoded_path}"
        )

    async def dblclick(self, selector: str):
        """Double-click an element."""
        return await self._request("POST", f"/cmd/dblclick?selector={selector}")

    async def rightclick(self, selector: str):
        """Right-click an element."""
        return await self._request("POST", f"/cmd/rightclick?selector={selector}")

    # Query commands
    async def get_elements(self):
        """Get interactive elements."""
        return await self._request("GET", "/query/elements")

    async def get_text(self):
        """Get page text."""
        return await self._request("GET", "/query/text")

    async def get_html(self):
        """Get page HTML."""
        return await self._request("GET", "/query/html")

    async def get_screenshot(self):
        """Get page screenshot."""
        return await self._request("GET", "/query/screenshot")

    async def get_state(self):
        """Get page state."""
        return await self._request("GET", "/query/state")

    async def get_url(self):
        """Get current URL."""
        return await self._request("GET", "/query/url")

    async def get_title(self):
        """Get page title."""
        return await self._request("GET", "/query/title")

    async def evaluate(self, expr: str):
        """Evaluate JavaScript expression."""
        import urllib.parse

        encoded = urllib.parse.quote(expr)
        return await self._request("GET", f"/query/evaluate?expr={encoded}")

    async def get_links(self):
        """Get all links on the page."""
        return await self._request("GET", "/query/links")

    async def get_forms(self):
        """Get all forms on the page."""
        return await self._request("GET", "/query/forms")

    async def get_tables(self):
        """Get all tables on the page with their data."""
        return await self._request("GET", "/query/tables")

    async def get_paragraphs(self, min_length: int = 200):
        """Get large text paragraphs (200+ chars) from the page.

        Args:
            min_length: Minimum paragraph length (default: 200)
        """
        return await self._request("GET", f"/query/paragraphs?min_length={min_length}")

    async def get_grids(self, min_repeat: int = 10):
        """Find grid patterns: divs with both <a> and <img> that repeat.

        Args:
            min_repeat: Minimum repetitions to qualify as a grid (default: 10)
        """
        return await self._request("GET", f"/query/grids?min_repeat={min_repeat}")

    # Explore commands
    async def find(self, text: str):
        """Find element by text."""
        import urllib.parse

        encoded_text = urllib.parse.quote(text)
        return await self._request("GET", f"/explore/find?text={encoded_text}")

    async def findall(self, text: str):
        """Find all elements by text."""
        import urllib.parse

        encoded_text = urllib.parse.quote(text)
        return await self._request("GET", f"/explore/findall?text={encoded_text}")

    async def inspect(self, selector: str):
        """Inspect element details."""
        import urllib.parse

        encoded_selector = urllib.parse.quote(selector)
        return await self._request("GET", f"/explore/inspect?selector={encoded_selector}")

    async def wait(self, selector: str = None, seconds: float = None):
        """Wait for selector or timeout."""
        if selector:
            import urllib.parse

            encoded = urllib.parse.quote(selector)
            return await self._request("POST", f"/explore/wait?selector={encoded}")
        elif seconds is not None:
            return await self._request("POST", f"/explore/wait?seconds={seconds}")
        else:
            return await self._request("POST", "/explore/wait")

    async def wait_idle(self, timeout: float = 3.0):
        """Wait for network idle."""
        return await self._request("POST", f"/explore/wait/idle?timeout={timeout}")

    async def scroll(
        self, direction: str = None, x: int = None, y: int = None, selector: str = None
    ):
        """Scroll the page.

        Args:
            direction: top, bottom, up, down
            x, y: coordinates
            selector: element selector to scroll into view
        """
        import urllib.parse

        params = []
        if direction:
            params.append(f"direction={direction}")
        elif x is not None and y is not None:
            params.append(f"x={x}&y={y}")
        elif selector:
            encoded = urllib.parse.quote(selector)
            params.append(f"selector={encoded}")

        if params:
            return await self._request("POST", f"/explore/scroll?{'&'.join(params)}")
        else:
            return await self._request("POST", "/explore/scroll?direction=down")

    # Control commands
    async def quit(self):
        """Quit browser."""
        return await self._request("POST", "/cmd/quit")

    async def shutdown(self):
        """Shutdown server."""
        return await self._request("POST", "/cmd/shutdown")

    # Session commands
    async def get_cookies(self):
        """Get all cookies."""
        return await self._request("GET", "/cmd/cookies")

    async def clear_cookies(self):
        """Clear all cookies."""
        return await self._request("DELETE", "/cmd/cookies/clear")

    async def set_cookie(
        self,
        name: str,
        value: str,
        domain: str,
        path: str = "/",
        expires: int = None,
        http_only: bool = False,
        secure: bool = False,
        same_site: str = None,
    ):
        """Set a cookie.

        Args:
            name: Cookie name
            value: Cookie value
            domain: Domain for cookie
            path: Cookie path (default: "/")
            expires: Expiration timestamp
            http_only: HttpOnly flag
            secure: Secure flag
            same_site: SameSite attribute
        """

        body = {
            "name": name,
            "value": value,
            "domain": domain,
            "path": path,
        }
        if expires is not None:
            body["expires"] = expires
        if http_only:
            body["httpOnly"] = http_only
        if secure:
            body["secure"] = secure
        if same_site:
            body["sameSite"] = same_site

        return await self._request("POST", "/cmd/cookies/set", json=body)

    async def save_session(self, name: str = None, path: str = None):
        """Save session to file.

        Args:
            name: Session name (saves to ~/.navcli/sessions/<name>.json)
            path: Full file path (alternative to name)
        """
        import urllib.parse

        if name:
            return await self._request("POST", f"/cmd/session/save?name={name}")
        elif path:
            encoded_path = urllib.parse.quote(path)
            return await self._request("POST", f"/cmd/session/save?path={encoded_path}")
        else:
            return await self._request("POST", "/cmd/session/save")

    async def load_session(self, name: str = None, path: str = None):
        """Load session from file.

        Args:
            name: Session name (loads from ~/.navcli/sessions/<name>.json)
            path: Full file path (alternative to name)
        """
        import urllib.parse

        if name:
            return await self._request("POST", f"/cmd/session/load?name={name}")
        elif path:
            encoded_path = urllib.parse.quote(path)
            return await self._request("POST", f"/cmd/session/load?path={encoded_path}")
        else:
            return await self._request("POST", "/cmd/session/load")


async def main():
    """Test client connection."""
    client = NavClient()
    try:
        await client.connect()
        result = await client.get_state()
        print(result)
    finally:
        await client.close()


if __name__ == "__main__":
    import asyncio

    asyncio.run(main())
