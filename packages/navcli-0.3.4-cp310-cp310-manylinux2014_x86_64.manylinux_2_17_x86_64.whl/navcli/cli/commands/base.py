"""Base command class for NavCLI commands."""

import cmd2

from navcli.cli.client import NavClient, ServerError


class BaseBrowserCommand(cmd2.Cmd):
    """Base class for browser commands with client connection."""

    def __init__(self, client: NavClient):
        super().__init__()
        self.client = client
        self.prompt = "(navcli) "
        self._show_suggestions = False
        self._suggestions_text = ""

    def _should_show_suggestions(self, result: dict) -> bool:
        """Check if result contains suggestions after navigation."""
        if not result or not result.get("success"):
            return False
        feedback = result.get("feedback", {})
        changes = feedback.get("changes", [])
        return len(changes) > 0

    def _get_suggestions_text(self, result: dict) -> str:
        """Get suggestions text from result."""
        feedback = result.get("feedback", {})
        changes = feedback.get("changes", [])
        if changes:
            return f"[Hint: {' | '.join(changes)}]"
        return ""

    @property
    def prompt(self):
        if self._show_suggestions:
            self._show_suggestions = False
            return f"(navcli) {self._suggestions_text} "
        return "(navcli) "

    @prompt.setter
    def prompt(self, value):
        self._prompt = value
        self._show_suggestions = False
        self._suggestions_text = ""

    def connect_client(self):
        """Ensure client is connected."""
        return self.client.connect()

    async def run_async_client(self, coro):
        """Run async client method."""
        await self.connect_client()
        try:
            return await coro
        except ServerError as e:
            self.perror(f"[FAIL] {e}")
            self.poutput("Please restart the server:")
            self.poutput("  pkill -f nav-server")
            self.poutput("  nav-server")
            return None
        finally:
            await self.client.close()

    def pretty_result(self, result: dict):
        """Format command result for display."""
        if result is None:
            self.perror("[FAIL] No response from server")
            return

        # Check if it's a QueryData response (no success field, but has text/html/url)
        if "success" not in result:
            # QueryData format - extract available fields
            url = result.get("url", "")
            title = result.get("title", "")
            text = result.get("text", "")
            error = result.get("error")

            if error:
                self.perror(f"[FAIL] {error}")
            elif text:
                self.poutput("[OK] Retrieved page text")
                if url:
                    self.poutput(f"  URL: {url}")
                if title:
                    self.poutput(f"  Title: {title}")
                # Print first 500 chars of text
                text_preview = text[:500].replace("\n", " ").strip()
                self.poutput(f"  Text: {text_preview}...")
            else:
                self.poutput("[OK] Retrieved page info")
                if url:
                    self.poutput(f"  URL: {url}")
                if title:
                    self.poutput(f"  Title: {title}")
            return

        # CommandResult format
        if result.get("success"):
            feedback = result.get("feedback", {})
            self.poutput(f"[OK] {feedback.get('action', 'done')}")
            if feedback.get("result"):
                self.poutput(f"  Result: {feedback.get('result')}")
            state = result.get("state", {})
            if state.get("url"):
                self.poutput(f"  URL: {state.get('url')}")
            if state.get("title"):
                self.poutput(f"  Title: {state.get('title')}")
        else:
            error = result.get("error", "Unknown error")
            self.perror(f"[FAIL] {error}")

    def complete_url(self, text, line, begidx, endidx):
        """Complete URL with common prefixes."""
        urls = ["http://", "https://", "http://www.", "https://www."]
        return [u for u in urls if u.startswith(text)]
