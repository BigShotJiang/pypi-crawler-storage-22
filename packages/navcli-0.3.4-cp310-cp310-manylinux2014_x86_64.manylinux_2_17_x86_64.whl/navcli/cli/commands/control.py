"""Control commands: quit, shutdown, save_session, load_session, cookies."""

import cmd2

from navcli.cli.commands.base import BaseBrowserCommand


class ControlCommands(BaseBrowserCommand):
    """Control command set."""

    def __init__(self, client):
        super().__init__(client)

    @cmd2.with_argparser(cmd2.Cmd2ArgumentParser())
    def do_quit(self, _):
        """Close the browser.

        Usage: quit
        """
        import asyncio

        async def _quit():
            return await self.client.quit()

        result = asyncio.run(self.run_async_client(_quit()))
        self.pretty_result(result)

    @cmd2.with_argparser(cmd2.Cmd2ArgumentParser())
    def do_shutdown(self, _):
        """Shutdown the server.

        Usage: shutdown
        """
        import asyncio

        async def _shutdown():
            return await self.client.shutdown()

        result = asyncio.run(self.run_async_client(_shutdown()))
        self.pretty_result(result)

    @cmd2.with_argparser(cmd2.Cmd2ArgumentParser())
    def do_exit(self, _):
        """Exit the CLI.

        Usage: exit
        """
        self.poutput("Goodbye!")
        return True

    # Session commands

    save_parser = cmd2.Cmd2ArgumentParser()
    save_parser.add_argument("name", nargs="?", default=None,
                             help="Session name (saves to ~/.navcli/sessions/<name>.json)")

    @cmd2.with_argparser(save_parser)
    def do_save_session(self, args):
        """Save session (cookies, storage) to file.

        Usage: save_session [name]
        Example: save_session jisilu
        """
        import asyncio

        async def _save():
            return await self.client.save_session(name=args.name)

        result = asyncio.run(self.run_async_client(_save()))
        self.pretty_result(result)

    load_parser = cmd2.Cmd2ArgumentParser()
    load_parser.add_argument("name", nargs="?", default=None,
                             help="Session name (loads from ~/.navcli/sessions/<name>.json)")

    @cmd2.with_argparser(load_parser)
    def do_load_session(self, args):
        """Load session (cookies, storage) from file.

        Usage: load_session [name]
        Example: load_session jisilu
        """
        import asyncio

        async def _load():
            return await self.client.load_session(name=args.name)

        result = asyncio.run(self.run_async_client(_load()))
        self.pretty_result(result)

    @cmd2.with_argparser(cmd2.Cmd2ArgumentParser())
    def do_cookies(self, _):
        """Show current cookies.

        Usage: cookies
        """
        import asyncio

        async def _get():
            return await self.client.get_cookies()

        result = asyncio.run(self.run_async_client(_get()))
        if result.get("success"):
            self.poutput("[OK] got cookies")
        else:
            self.perror(f"[FAIL] {result.get('error')}")

    @cmd2.with_argparser(cmd2.Cmd2ArgumentParser())
    def do_clear_cookies(self, _):
        """Clear all cookies.

        Usage: clear_cookies
        """
        import asyncio

        async def _clear():
            return await self.client.clear_cookies()

        result = asyncio.run(self.run_async_client(_clear()))
        self.pretty_result(result)
