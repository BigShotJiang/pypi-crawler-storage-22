"""Explore commands: find, findall, inspect, wait."""

import cmd2

from navcli.cli.commands.base import BaseBrowserCommand

# Parser for find commands
_find_parser = cmd2.Cmd2ArgumentParser()
_find_parser.add_argument("text", help="Text to search for")

# Parser for inspect command
_inspect_parser = cmd2.Cmd2ArgumentParser()
_inspect_parser.add_argument("selector", help="CSS selector")

# Parser for wait_idle command
_wait_idle_parser = cmd2.Cmd2ArgumentParser()
_wait_idle_parser.add_argument("timeout", nargs="?", help="Timeout in seconds (default: 3.0)")


class ExploreCommands(BaseBrowserCommand):
    """Explore command set."""

    def __init__(self, client):
        super().__init__(client)

    @cmd2.with_argparser(_find_parser)
    def do_find(self, args):
        """Find first element containing text.

        Usage: find <text>
        Example: find Submit
        """
        import asyncio

        async def _find():
            return await self.client.find(args.text)

        result = asyncio.run(self.run_async_client(_find()))
        self.pretty_result(result)

    @cmd2.with_argparser(_find_parser)
    def do_findall(self, args):
        """Find all elements containing text.

        Usage: findall <text>
        Example: findall button
        """
        import asyncio

        async def _findall():
            return await self.client.findall(args.text)

        result = asyncio.run(self.run_async_client(_findall()))
        self.pretty_result(result)

    @cmd2.with_argparser(_inspect_parser)
    def do_inspect(self, args):
        """Inspect element details.

        Usage: inspect <selector>
        Example: inspect #login-form
        """
        import asyncio

        async def _inspect():
            return await self.client.inspect(args.selector)

        result = asyncio.run(self.run_async_client(_inspect()))
        self.pretty_result(result)

    @cmd2.with_argparser(cmd2.Cmd2ArgumentParser())
    def do_wait(self, args):
        """Wait for selector or timeout.

        Usage: wait [--selector <selector>] [--seconds <seconds>]
        Example: wait --selector .modal
        Example: wait --seconds 5
        """
        import asyncio

        async def _wait():
            if args.selector:
                return await self.client.wait(selector=args.selector)
            elif args.seconds:
                return await self.client.wait(seconds=args.seconds)
            else:
                return await self.client.wait()

        result = asyncio.run(self.run_async_client(_wait()))
        self.pretty_result(result)

    @cmd2.with_argparser(_wait_idle_parser)
    def do_wait_idle(self, args):
        """Wait for network idle.

        Usage: wait_idle [timeout]
        Example: wait_idle 5
        """
        import asyncio

        async def _wait_idle():
            timeout = 3.0  # default timeout
            if args.timeout:
                try:
                    timeout = float(args.timeout)
                except ValueError:
                    pass
            return await self.client.wait_idle(timeout=timeout)

        result = asyncio.run(self.run_async_client(_wait_idle()))
        self.pretty_result(result)

    @cmd2.with_argparser(cmd2.Cmd2ArgumentParser())
    def do_scroll(self, args):
        """Scroll the page.

        Usage:
            scroll top|bottom|up|down
            scroll x=<num> y=<num>
            scroll --selector <selector>

        Examples:
            scroll top
            scroll bottom
            scroll up
            scroll down
            scroll x=0 y=500
            scroll --selector .footer
        """
        import asyncio

        async def _scroll():
            if args.direction:
                return await self.client.scroll(direction=args.direction)
            elif args.x is not None and args.y is not None:
                return await self.client.scroll(x=args.x, y=args.y)
            elif args.selector:
                return await self.client.scroll(selector=args.selector)
            else:
                return await self.client.scroll(direction="down")

        result = asyncio.run(self.run_async_client(_scroll()))
        self.pretty_result(result)
