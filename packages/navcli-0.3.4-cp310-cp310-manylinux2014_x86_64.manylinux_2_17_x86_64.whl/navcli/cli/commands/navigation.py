"""Navigation commands: goto, back, forward, reload."""

import cmd2

from navcli.cli.commands.base import BaseBrowserCommand

_goto_parser = cmd2.Cmd2ArgumentParser()
_goto_parser.add_argument("url", help="URL to navigate to")


class NavigationCommands(BaseBrowserCommand):
    """Navigation command set."""

    def __init__(self, client):
        super().__init__(client)

    @cmd2.with_argparser(_goto_parser)
    def do_goto(self, args):
        """Navigate to a URL and show page summary.

        Usage: goto <url>
        Example: goto https://example.com
        """
        import asyncio

        url = args.url
        if not url.startswith(("http://", "https://")):
            url = "https://" + url

        async def _goto():
            result = await self.client.goto(url)
            await self.client.get_paragraphs(min_length=200)

            return result

        result = asyncio.run(self.run_async_client(_goto()))
        self.pretty_result(result)
        if self._should_show_suggestions(result):
            self._show_suggestions = True
            self._suggestions_text = self._get_suggestions_text(result)
            self.poutput(self._suggestions_text)

    @cmd2.with_argparser(cmd2.Cmd2ArgumentParser())
    def do_back(self, _):
        """Go back in history.

        Usage: back
        """
        import asyncio

        async def _back():
            return await self.client.back()

        result = asyncio.run(self.run_async_client(_back()))
        self.pretty_result(result)

    @cmd2.with_argparser(cmd2.Cmd2ArgumentParser())
    def do_forward(self, _):
        """Go forward in history.

        Usage: forward
        """
        import asyncio

        async def _forward():
            return await self.client.forward()

        result = asyncio.run(self.run_async_client(_forward()))
        self.pretty_result(result)

    @cmd2.with_argparser(cmd2.Cmd2ArgumentParser())
    def do_reload(self, _):
        """Reload the current page.

        Usage: reload
        """
        import asyncio

        async def _reload():
            return await self.client.reload()

        result = asyncio.run(self.run_async_client(_reload()))
        self.pretty_result(result)

    do_b = do_back
    do_f = do_forward
    do_r = do_reload

    @cmd2.with_argparser(_goto_parser)
    def do_g(self, args):
        """Navigate to a URL (shortcut).

        Usage: g <url>
        """
        import asyncio

        url = args.url
        if not url.startswith(("http://", "https://")):
            url = "https://" + url

        async def _goto():
            result = await self.client.goto(url)
            await self.client.get_paragraphs(min_length=200)

            return result

        result = asyncio.run(self.run_async_client(_goto()))
        self.pretty_result(result)
        if self._should_show_suggestions(result):
            self._show_suggestions = True
            self._suggestions_text = self._get_suggestions_text(result)
            self.poutput(self._suggestions_text)
