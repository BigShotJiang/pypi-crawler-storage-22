"""Query commands: elements, text, html, screenshot, state, url, title."""

import cmd2

from navcli.cli.commands.base import BaseBrowserCommand

# Parser for evaluate command
_evaluate_parser = cmd2.Cmd2ArgumentParser()
_evaluate_parser.add_argument("expression", help="JavaScript expression")


class QueryCommands(BaseBrowserCommand):
    """Query command set."""

    def __init__(self, client):
        super().__init__(client)

    @cmd2.with_argparser(cmd2.Cmd2ArgumentParser())
    def do_elements(self, _):
        """Get interactive elements on the page.

        Usage: elements
        """
        import asyncio

        async def _elements():
            return await self.client.get_elements()

        result = asyncio.run(self.run_async_client(_elements()))
        self.pretty_result(result)
        elements = result.get("elements") or []
        for elem in elements:
            self.poutput(
                f"  {elem.get('tag')} | {elem.get('selector')} | {elem.get('text', '')[:50]}"
            )

    @cmd2.with_argparser(cmd2.Cmd2ArgumentParser())
    def do_text(self, _):
        """Get page text content.

        Usage: text
        """
        import asyncio

        async def _text():
            return await self.client.get_text()

        result = asyncio.run(self.run_async_client(_text()))
        self.pretty_result(result)
        if result and result.get("text"):
            # Print first 1000 chars of text
            text = result.get("text", "")
            preview = text[:1000].replace("\n", " ").strip()
            self.poutput(f"\n{'=' * 80}")
            self.poutput("Page Text Content:")
            self.poutput("=" * 80)
            self.poutput(preview + "..." if len(text) > 1000 else preview)

    @cmd2.with_argparser(cmd2.Cmd2ArgumentParser())
    def do_html(self, _):
        """Get page HTML content.

        Usage: html
        """
        import asyncio

        async def _html():
            return await self.client.get_html()

        result = asyncio.run(self.run_async_client(_html()))
        self.pretty_result(result)
        if result and result.get("html"):
            html = result.get("html", "")
            preview = html[:500].replace("\n", " ").strip()
            self.poutput(f"\nHTML length: {len(html)} chars")
            self.poutput(f"Preview: {preview}...")

    @cmd2.with_argparser(cmd2.Cmd2ArgumentParser())
    def do_screenshot(self, _):
        """Take a screenshot of the page.

        Usage: screenshot [output_file]
        Example: screenshot
        Example: screenshot page.png
        """
        import asyncio

        async def _screenshot():
            return await self.client.get_screenshot()

        result = asyncio.run(self.run_async_client(_screenshot()))
        self.pretty_result(result)

    @cmd2.with_argparser(cmd2.Cmd2ArgumentParser())
    def do_state(self, _):
        """Get full page state.

        Usage: state
        """
        import asyncio

        async def _state():
            return await self.client.get_state()

        result = asyncio.run(self.run_async_client(_state()))
        self.pretty_result(result)

    @cmd2.with_argparser(cmd2.Cmd2ArgumentParser())
    def do_url(self, _):
        """Get current URL.

        Usage: url
        """
        import asyncio

        async def _url():
            return await self.client.get_url()

        result = asyncio.run(self.run_async_client(_url()))
        self.pretty_result(result)

    @cmd2.with_argparser(cmd2.Cmd2ArgumentParser())
    def do_title(self, _):
        """Get page title.

        Usage: title
        """
        import asyncio

        async def _title():
            return await self.client.get_title()

        result = asyncio.run(self.run_async_client(_title()))
        self.pretty_result(result)

    @cmd2.with_argparser(_evaluate_parser)
    def do_evaluate(self, args):
        """Evaluate JavaScript expression.

        Usage: evaluate <js_expression>
        Example: evaluate document.title
        Example: evaluate window.innerHeight
        """
        import asyncio

        async def _evaluate():
            return await self.client.evaluate(args.expression)

        result = asyncio.run(self.run_async_client(_evaluate()))
        self.pretty_result(result)

    @cmd2.with_argparser(cmd2.Cmd2ArgumentParser())
    def do_links(self, _):
        """Get all links on the page.

        Usage: links
        """
        import asyncio

        async def _links():
            return await self.client.get_links()

        result = asyncio.run(self.run_async_client(_links()))
        self.pretty_result(result)
        links = result.get("links") or []
        for link in links:
            self.poutput(f"  {link}")

    @cmd2.with_argparser(cmd2.Cmd2ArgumentParser())
    def do_forms(self, _):
        """Get all forms on the page.

        Usage: forms
        """
        import asyncio

        async def _forms():
            return await self.client.get_forms()

        result = asyncio.run(self.run_async_client(_forms()))
        self.pretty_result(result)

    @cmd2.with_argparser(cmd2.Cmd2ArgumentParser())
    def do_tables(self, _):
        """Get all tables on the page with their data.

        Usage: tables
        """
        import asyncio

        async def _tables():
            return await self.client.get_tables()

        result = asyncio.run(self.run_async_client(_tables()))
        self.pretty_result(result)
        if result.get("success"):
            tables = result.get("tables") or []
            for t in tables:
                table_id = t.get("id", "N/A")
                row_count = t.get("rowCount", 0)
                self.poutput(f"\n{'=' * 100}")
                self.poutput(f"Table: {table_id} ({row_count} rows)")
                self.poutput("=" * 100)

                rows = t.get("rows") or []

                if not rows:
                    self.poutput("  (empty)")
                    continue

                # Format table
                for i, row in enumerate(rows):
                    if i == 0:
                        # Header row
                        header_line = "  " + " | ".join(
                            str(h).replace("\n", "").strip()[:15] for h in row
                        )
                        self.poutput(f"\n{header_line}")
                        self.poutput("-" * len(header_line))
                    else:
                        # Data row
                        row_line = "  " + " | ".join(
                            str(c).replace("\n", "").strip()[:15] for c in row
                        )
                        self.poutput(row_line)

    _paragraphs_parser = cmd2.Cmd2ArgumentParser()
    _paragraphs_parser.add_argument(
        "min_length",
        nargs="?",
        type=int,
        default=200,
        help="Minimum paragraph length (default: 200)",
    )

    @cmd2.with_argparser(_paragraphs_parser)
    def do_paragraphs(self, args):
        """Get large text paragraphs (200+ chars) from the page.

        Useful for extracting article content, policy documents, etc.

        Usage: paragraphs [min_length]
        Example: paragraphs
        Example: paragraphs 500
        """
        import asyncio

        async def _paragraphs():
            return await self.client.get_paragraphs(min_length=args.min_length)

        result = asyncio.run(self.run_async_client(_paragraphs()))
        self.pretty_result(result)
