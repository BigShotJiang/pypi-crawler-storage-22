"""Server connection management for NavCLI."""

import socket

DEFAULT_SERVER_URL = "http://127.0.0.1:8765"


def get_server_error_msg(url: str = DEFAULT_SERVER_URL) -> str:
    """Get server error message."""
    return f"""
[ERROR] Cannot connect to NavCLI server at {url}

The server may not be running or has crashed. Please restart it:

  1. Kill existing server processes:
     pkill -f nav-server

  2. Start a new server:
     nav-server                    # Headless (default)
     nav-server --no-headless      # With GUI visible

  3. If using GUI mode, the browser window should appear.

For more info, see: https://github.com/anomalyco/navcli
""".strip()


def check_server_connection(url: str = DEFAULT_SERVER_URL) -> bool:
    """Check if the NavCLI server is running.

    Returns:
        True if server is healthy, False otherwise
    """
    try:
        host = url.replace("http://", "").split(":")[0]
        port = int(url.replace("http://", "").split(":")[1]) if ":" in url else 8765
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(2)
        result = sock.connect_ex((host, port))
        sock.close()
        return result == 0
    except Exception:
        return False
