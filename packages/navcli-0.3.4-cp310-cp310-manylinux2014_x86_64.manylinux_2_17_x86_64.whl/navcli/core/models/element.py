"""Element model for interactive elements."""

from typing import Optional
from pydantic import BaseModel


class Element(BaseModel):
    """Represents an interactive element on the page.

    Only returns "actionable + meaningful" elements:
    - button, a (with href), input, select, textarea
    - h1-h3, img (with alt), nav, menu
    """

    selector: str          # CSS selector
    tag: str               # tag name
    text: str              # element text content
    clickable: bool        # is clickable
    input: bool            # is inputtable
    type: Optional[str] = None  # input type (for input elements)
    href: Optional[str] = None  # href (for anchor elements)
    alt: Optional[str] = None   # alt text (for img elements)
