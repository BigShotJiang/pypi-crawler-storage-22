"""Query result models - specialized results for query commands."""

from typing import Optional, List, Dict, Any
from pydantic import BaseModel


class QueryData(BaseModel):
    """Specialized result for query commands - no empty fields to avoid confusion."""

    text: Optional[str] = None
    html: Optional[str] = None
    elements: Optional[List[Dict[str, Any]]] = None
    paragraphs: Optional[List[Dict[str, Any]]] = None
    tables: Optional[List[Dict[str, Any]]] = None
    links: Optional[List[Dict[str, Any]]] = None
    forms: Optional[List[Dict[str, Any]]] = None
    screenshot: Optional[str] = None
    url: Optional[str] = None
    title: Optional[str] = None
    error: Optional[str] = None
