"""StateSnapshot model for page state."""

from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field

from .dom import DOMTree


class Paragraph(BaseModel):
    """Represents a large text paragraph."""

    index: int = 0
    text: str = ""
    length: int = 0
    selector: str = ""


class StateSnapshot(BaseModel):
    """Represents the current page state."""

    url: str = ""  # current URL
    title: str = ""  # page title
    text: str = ""  # page text content
    dom: DOMTree = Field(default_factory=DOMTree)  # DOM tree
    variables: dict = Field(default_factory=dict)  # page variables
    loading: bool = False  # is still loading
    network_idle: bool = True  # network is idle
    dom_stable: bool = True  # DOM is stable
    pending_requests: int = 0  # pending request count
    tables: List[Dict[str, Any]] = Field(default_factory=list)  # extracted tables
    paragraphs: List[Paragraph] = Field(default_factory=list)  # extracted paragraphs
    links: List[Dict[str, Any]] = Field(default_factory=list)  # page links
