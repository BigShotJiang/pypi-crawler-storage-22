"""NavCLI Browser Server."""

import asyncio
import os
import signal
import socket
import sys
import time
from typing import Optional

import uvicorn
from uvicorn.config import Config

from navcli.server.app import create_app
from navcli.server.browser import start_browser, close_browser, _SNAPSHOT_PATH, save_session
from navcli.server.idle import (
    update_activity,
    get_idle_time,
    get_idle_timeout,
    get_warning_time,
    get_idle_check_interval,
)

__version__ = "0.1.0"

# Session directory
_NAVCLI_HOME = os.path.expanduser("~/.navcli")
_NAVCLI_SESSIONS_DIR = os.path.join(_NAVCLI_HOME, "sessions")

# Server instance
_server: Optional[uvicorn.Server] = None
_idle_check_task: Optional[asyncio.Task] = None


async def _check_idle():
    """Background task to check idle time and trigger shutdown."""
    global _idle_check_task

    while True:
        await asyncio.sleep(get_idle_check_interval())

        idle_time = get_idle_time()
        remaining = get_idle_timeout() - idle_time

        if idle_time >= get_idle_timeout():
            print(f"\n[IDLE] Timeout reached ({get_idle_timeout()}s), shutting down...")
            await _idle_shutdown()
            break
        elif (
            remaining <= get_warning_time()
            and remaining > get_warning_time() - get_idle_check_interval()
        ):
            minutes_left = int(remaining // 60)
            print(f"\n[IDLE] Will shut down in {minutes_left} minute(s) due to inactivity...")


async def _idle_shutdown():
    """Handle idle timeout shutdown."""
    global _server, _idle_check_task

    if _idle_check_task:
        _idle_check_task.cancel()
        _idle_check_task = None

    try:
        print("[IDLE] Saving session before shutdown...")
        await save_session(_SNAPSHOT_PATH)
        print(f"[IDLE] Session saved to {_SNAPSHOT_PATH}")
    except Exception as e:
        print(f"[IDLE] Failed to save session: {e}")

    if _server:
        _server.should_exit = True

    await close_browser()


async def start_server(
    host: str = "127.0.0.1",
    port: int = 8765,
    headless: bool = True,
    browser_args: Optional[list] = None,
) -> uvicorn.Server:
    """Start the browser server.

    Args:
        host: Host to bind
        port: Port to listen
        headless: Run browser in headless mode (default: True)
        browser_args: Additional browser launch arguments

    Returns:
        Uvicorn server instance
    """
    global _server, _idle_check_task

    update_activity()

    # Start browser
    await start_browser(headless=headless, args=browser_args)

    # Create app
    app = create_app()

    # Configure uvicorn
    config = Config(app, host=host, port=port, log_level="info")
    _server = uvicorn.Server(config)

    # Register shutdown handler
    def signal_handler():
        asyncio.create_task(shutdown())

    config.lifespan = "on"

    # Start idle check task
    _idle_check_task = asyncio.create_task(_check_idle())

    # Start server
    try:
        await _server.serve()
    except Exception as e:
        await close_browser()
        raise e

    return _server


async def shutdown():
    """Shutdown the server."""
    global _server

    if _server:
        _server.should_exit = True

    # Close browser
    await close_browser()


def main():
    """Main entry point for nav-server command."""
    import argparse
    import os

    parser = argparse.ArgumentParser(description="NavCLI Browser Server")
    parser.add_argument("--host", default="127.0.0.1", help="Host to bind")
    parser.add_argument("--port", type=int, default=8765, help="Port to listen")
    parser.add_argument(
        "--headless", action="store_true", default=True, help="Run in headless mode (default)"
    )
    parser.add_argument(
        "--no-headless", dest="headless", action="store_false", help="Run with GUI (non-headless)"
    )
    parser.add_argument(
        "--memory-limit",
        type=int,
        default=None,
        help="Browser memory limit in MB (e.g., --memory-limit 512)",
    )

    args = parser.parse_args()

    # Build browser args for memory limit
    browser_args = None
    if args.memory_limit:
        browser_args = [
            f"--js-flags=--max-old-space-size={args.memory_limit}",
            "--disable-dev-shm-usage",
        ]
        print(f"Memory limit: {args.memory_limit}MB")

    print(f"Starting NavCLI Browser Server on {args.host}:{args.port}...")
    print(f"Headless: {args.headless}")
    print("-" * 60)

    if args.headless:
        # Headless mode: check for saved session
        session_files = []
        if os.path.isdir(_NAVCLI_SESSIONS_DIR):
            session_files = [
                f[:-5] for f in os.listdir(_NAVCLI_SESSIONS_DIR) if f.endswith(".json")
            ]

        if session_files:
            print(f"Saved sessions in {_NAVCLI_SESSIONS_DIR}:")
            for f in session_files:
                print(f"  - {f}")
            print("\nTo load a session:")
            print('  curl -X POST "http://localhost:8765/cmd/session/load?name=<name>"')
            print("  nav load_session <name>")
        else:
            print("No saved sessions found.")

        # Auto-save snapshot info
        print(f"\nAuto-save snapshot: {_SNAPSHOT_PATH}")
        if os.path.exists(_SNAPSHOT_PATH):
            print("Session snapshot: Will be loaded on startup (auto)")

        print("\nTo save a session after manual login:")
        print('  curl -X POST "http://localhost:8765/cmd/session/save?name=<name>"')
        print("  nav save_session <name>")
    else:
        # No-headless mode: remind to save session
        print("Human-in-the-loop mode: browser window will open")
        print("1. Manually log in to the website")
        print("\nWARNING: Session will be LOST when browser closes!")
        print("Before closing, save your session:")
        print('  curl -X POST "http://localhost:8765/cmd/session/save?name=<name>"')
        print("  nav save_session <name>")

    print("-" * 60)

    if is_port_in_use(args.port):
        print(f"[ERROR] Port {args.port} is already in use")
        print(f"        Is another nav-server running?")
        sys.exit(1)

    try:
        asyncio.run(
            start_server(args.host, args.port, headless=args.headless, browser_args=browser_args)
        )
        print(f"[SESSION] Session snapshot loaded from {_SNAPSHOT_PATH}")
    except KeyboardInterrupt:
        print("\nShutting down...")
        sys.exit(0)
    except Exception as e:
        error_msg = str(e)
        if "Address already in use" in error_msg or "bind" in error_msg.lower():
            print(f"[ERROR] Port {args.port} is already in use")
            print(f"        Is another nav-server running?")
        else:
            print(f"[ERROR] {e}")
        sys.exit(1)


def is_port_in_use(port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        return s.connect_ex(("localhost", port)) == 0


if __name__ == "__main__":
    main()
