"""Idle timeout management for NavCLI server."""

import time
from typing import Optional

_IDLE_TIMEOUT = 15 * 60  # 15 minutes in seconds
_WARNING_TIME = 5 * 60  # 5 minutes in seconds
_IDLE_CHECK_INTERVAL = 60  # Check every 60 seconds
_last_activity_time: float = time.time()


def update_activity():
    """Update the last activity time."""
    global _last_activity_time
    _last_activity_time = time.time()


def get_last_activity_time() -> float:
    """Get the last activity time."""
    return _last_activity_time


def get_idle_time() -> float:
    """Get current idle time."""
    return time.time() - _last_activity_time


def get_idle_timeout() -> int:
    """Get idle timeout in seconds."""
    return _IDLE_TIMEOUT


def get_warning_time() -> int:
    """Get warning time in seconds."""
    return _WARNING_TIME


def get_idle_check_interval() -> int:
    """Get idle check interval in seconds."""
    return _IDLE_CHECK_INTERVAL
