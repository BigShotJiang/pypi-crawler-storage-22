"""Server routes."""

from . import navigation, interaction, query, explore, control

__all__ = [
    'navigation',
    'interaction',
    'query',
    'explore',
    'control',
]
