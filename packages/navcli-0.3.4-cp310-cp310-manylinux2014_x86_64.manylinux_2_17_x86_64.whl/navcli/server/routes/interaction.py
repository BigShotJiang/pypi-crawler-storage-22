"""Interaction routes: click, type, clear, upload."""

import time
from typing import Optional
from fastapi import APIRouter, HTTPException, Query

from navcli.core.models import CommandResult, Feedback
from navcli.server.browser import get_page, get_current_state, start_browser, wait_for_network_idle

router = APIRouter()


def log_progress(message: str):
    """Print progress message with timestamp."""
    print(f"[PROGRESS {time.strftime('%H:%M:%S')}] {message}")


@router.post("/click")
async def click(
    selector: str = Query(..., description="CSS selector"),
    force: bool = Query(False, description="Force click without waiting"),
) -> CommandResult:
    """Click an element."""
    try:
        if not selector:
            raise HTTPException(status_code=400, detail="selector is required")

        log_progress(f"Clicking '{selector}'...")

        await start_browser()
        page = get_page()

        locator = page.locator(selector)

        # Check if element exists
        count = await locator.count()
        if count == 0:
            log_progress(f"Element not found: {selector}")
            return CommandResult(
                success=False,
                command="click",
                error=f"element not found: {selector}",
            )

        if count > 1:
            log_progress(f"Multiple elements found: {selector}")
            return CommandResult(
                success=False,
                command="click",
                error=f"multiple elements found: {selector}",
            )

        # Click with timeout protection
        try:
            if force:
                await locator.click(force=True, timeout=3000)
                log_progress(f"Force clicked '{selector}'")
            else:
                await locator.click(timeout=3000)
                log_progress(f"Clicked '{selector}'")
        except Exception as click_err:
            log_progress(f"Click failed: {click_err}")
            return CommandResult(
                success=False,
                command="click",
                error=f"click failed: {str(click_err)}",
            )

        # Return minimal state without expensive operations
        from navcli.core.models import StateSnapshot, DOMTree

        state = StateSnapshot(
            url=page.url,
            title="",
            dom=DOMTree(version=0, full=False, html="", elements=[]),
        )

        return CommandResult(
            success=True,
            command="click",
            state=state,
            feedback=Feedback(
                action=f"clicked {selector}",
                result="clicked",
            ),
        )
    except Exception as e:
        log_progress(f"Error: {e}")
        return CommandResult(
            success=False,
            command="click",
            error=str(e),
        )


@router.post("/type")
async def type_text(
    selector: str = Query(..., description="CSS selector"),
    text: str = Query(..., description="Text to type"),
) -> CommandResult:
    """Type text into an input."""
    try:
        if not selector:
            raise HTTPException(status_code=400, detail="selector is required")
        if not text:
            raise HTTPException(status_code=400, detail="text is required")

        log_progress(f"Typing into '{selector}': {text[:30]}...")

        await start_browser()
        page = get_page()

        locator = page.locator(selector)

        count = await locator.count()
        if count == 0:
            log_progress(f"Element not found: {selector}")
            return CommandResult(
                success=False,
                command="type",
                error=f"element not found: {selector}",
            )

        await page.evaluate(
            f"el = document.querySelector('{selector}'); if(el) el.value = '{text}';"
        )
        log_progress(f"Typed into '{selector}'")

        from navcli.core.models import StateSnapshot, DOMTree

        state = StateSnapshot(
            url=page.url,
            title="",
            dom=DOMTree(version=0, full=False, html="", elements=[]),
        )

        return CommandResult(
            success=True,
            command="type",
            state=state,
            feedback=Feedback(
                action=f"typed into {selector}",
                result=f"typed: {text[:20]}...",
            ),
        )
    except Exception as e:
        log_progress(f"Error: {e}")
        return CommandResult(
            success=False,
            command="type",
            error=str(e),
        )


@router.post("/clear")
async def clear_input(
    selector: str = Query(..., description="CSS selector"),
) -> CommandResult:
    """Clear an input field."""
    try:
        if not selector:
            raise HTTPException(status_code=400, detail="selector is required")

        log_progress(f"Clearing '{selector}'...")

        await start_browser()
        page = get_page()

        locator = page.locator(selector)

        # Check if element exists
        count = await locator.count()
        if count == 0:
            log_progress(f"Element not found: {selector}")
            return CommandResult(
                success=False,
                command="clear",
                error=f"element not found: {selector}",
            )

        # Clear
        await locator.clear()
        log_progress(f"Cleared '{selector}'")

        state = await get_current_state()

        return CommandResult(
            success=True,
            command="clear",
            state=state,
            feedback=Feedback(
                action=f"cleared {selector}",
                result="cleared",
            ),
        )
    except Exception as e:
        log_progress(f"Error: {e}")
        return CommandResult(
            success=False,
            command="clear",
            error=str(e),
        )


@router.post("/upload")
async def upload_file(
    selector: str = Query(..., description="CSS selector"),
    file_path: str = Query(..., description="Path to file"),
) -> CommandResult:
    """Upload a file to an input."""
    try:
        if not selector:
            raise HTTPException(status_code=400, detail="selector is required")
        if not file_path:
            raise HTTPException(status_code=400, detail="file_path is required")

        log_progress(f"Uploading '{file_path}' to '{selector}'...")

        # Check if file exists
        import os

        if not os.path.exists(file_path):
            log_progress(f"File not found: {file_path}")
            return CommandResult(
                success=False,
                command="upload",
                error=f"file not found: {file_path}",
            )

        await start_browser()
        page = get_page()

        locator = page.locator(selector)

        # Check if element exists
        count = await locator.count()
        if count == 0:
            log_progress(f"Element not found: {selector}")
            return CommandResult(
                success=False,
                command="upload",
                error=f"element not found: {selector}",
            )

        # Upload file
        await locator.set_input_files(file_path)
        log_progress(f"Uploaded '{file_path}'")

        state = await get_current_state()

        return CommandResult(
            success=True,
            command="upload",
            state=state,
            feedback=Feedback(
                action=f"uploaded {file_path} to {selector}",
                result="uploaded",
            ),
        )
    except Exception as e:
        log_progress(f"Error: {e}")
        return CommandResult(
            success=False,
            command="upload",
            error=str(e),
        )


@router.post("/dblclick")
async def dblclick(
    selector: str = Query(..., description="CSS selector"),
) -> CommandResult:
    """Double-click an element."""
    try:
        if not selector:
            raise HTTPException(status_code=400, detail="selector is required")

        log_progress(f"Double-clicking '{selector}'...")

        await start_browser()
        page = get_page()

        locator = page.locator(selector)
        count = await locator.count()
        if count == 0:
            log_progress(f"Element not found: {selector}")
            return CommandResult(
                success=False,
                command="dblclick",
                error=f"element not found: {selector}",
            )
        if count > 1:
            log_progress(f"Multiple elements found: {selector}")
            return CommandResult(
                success=False,
                command="dblclick",
                error=f"multiple elements found: {selector}",
            )

        await locator.dblclick()
        log_progress(f"Double-clicked '{selector}'")

        # get_current_state() includes its own wait_for_load_state
        state = await get_current_state()

        return CommandResult(
            success=True,
            command="dblclick",
            state=state,
            feedback=Feedback(
                action=f"double-clicked {selector}",
                result="clicked",
            ),
        )
    except Exception as e:
        log_progress(f"Error: {e}")
        return CommandResult(
            success=False,
            command="dblclick",
            error=str(e),
        )


@router.post("/rightclick")
async def rightclick(
    selector: str = Query(..., description="CSS selector"),
) -> CommandResult:
    """Right-click an element."""
    try:
        if not selector:
            raise HTTPException(status_code=400, detail="selector is required")

        log_progress(f"Right-clicking '{selector}'...")

        await start_browser()
        page = get_page()

        locator = page.locator(selector)
        count = await locator.count()
        if count == 0:
            log_progress(f"Element not found: {selector}")
            return CommandResult(
                success=False,
                command="rightclick",
                error=f"element not found: {selector}",
            )
        if count > 1:
            log_progress(f"Multiple elements found: {selector}")
            return CommandResult(
                success=False,
                command="rightclick",
                error=f"multiple elements found: {selector}",
            )

        await locator.click(button="right")
        log_progress(f"Right-clicked '{selector}'")

        # get_current_state() includes its own wait_for_load_state
        state = await get_current_state()

        return CommandResult(
            success=True,
            command="rightclick",
            state=state,
            feedback=Feedback(
                action=f"right-clicked {selector}",
                result="clicked",
            ),
        )
    except Exception as e:
        log_progress(f"Error: {e}")
        return CommandResult(
            success=False,
            command="rightclick",
            error=str(e),
        )
