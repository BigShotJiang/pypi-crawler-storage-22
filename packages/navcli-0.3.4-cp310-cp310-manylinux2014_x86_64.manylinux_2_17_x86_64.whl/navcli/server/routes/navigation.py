"""Navigation routes: goto, back, forward, reload."""

import asyncio
from fastapi import APIRouter, HTTPException, Query

from navcli.core.models import CommandResult, Feedback
from navcli.server.browser import (
    get_page,
    get_current_state,
    start_browser,
    wait_for_network_idle,
    auto_save_snapshot,
)
from navcli.utils import normalize_url
from navcli.server.utils import log_progress, get_navigation_hints

router = APIRouter()


@router.post("/goto")
async def goto(
    url: str = Query(..., description="URL to navigate to"),
    wait_until: str = Query(
        "networkidle", description="wait condition: load, domcontentloaded, networkidle"
    ),
) -> CommandResult:
    """Navigate to a URL."""
    try:
        if not url:
            raise HTTPException(status_code=400, detail="url is required")

        normalized_url = normalize_url(url)
        log_progress(f"Navigating to {normalized_url}...")

        await start_browser()
        page = get_page()

        await page.goto(normalized_url, wait_until="domcontentloaded")

        from navcli.core.models import StateSnapshot, DOMTree

        try:
            title = await asyncio.wait_for(page.title(), timeout=3000)
        except Exception:
            title = ""
        state = StateSnapshot(
            url=normalized_url,
            title=title,
            dom=DOMTree(version=0, full=False, html="", elements=[]),
        )
        log_progress(f"Page title: {state.title}")

        await auto_save_snapshot()

        hints = get_navigation_hints("goto")

        return CommandResult(
            success=True,
            command="goto",
            state=state,
            feedback=Feedback(
                action=f"navigated to {normalized_url}",
                result=f"page loaded: {state.title}",
                changes=hints,
            ),
        )
    except Exception as e:
        log_progress(f"Error: {e}")
        return CommandResult(
            success=False,
            command="goto",
            error=str(e),
        )


@router.post("/back")
async def back() -> CommandResult:
    """Go back in history."""
    try:
        log_progress("Going back...")
        page = get_page()
        await page.go_back()
        await wait_for_network_idle(3.0)

        state = await get_current_state()
        log_progress(f"Back to: {state.url}")

        await auto_save_snapshot()

        hints = get_navigation_hints("back")

        return CommandResult(
            success=True,
            command="back",
            state=state,
            feedback=Feedback(
                action="went back",
                result=f"navigated to {state.url}",
                changes=hints,
            ),
        )
    except Exception as e:
        log_progress(f"Error: {e}")
        return CommandResult(
            success=False,
            command="back",
            error=str(e),
        )


@router.post("/forward")
async def forward() -> CommandResult:
    """Go forward in history."""
    try:
        log_progress("Going forward...")
        page = get_page()
        await page.go_forward()
        await wait_for_network_idle(3.0)

        state = await get_current_state()
        log_progress(f"Forward to: {state.url}")

        await auto_save_snapshot()

        hints = get_navigation_hints("forward")

        return CommandResult(
            success=True,
            command="forward",
            state=state,
            feedback=Feedback(
                action="went forward",
                result=f"navigated to {state.url}",
                changes=hints,
            ),
        )
    except Exception as e:
        log_progress(f"Error: {e}")
        return CommandResult(
            success=False,
            command="forward",
            error=str(e),
        )


@router.post("/reload")
async def reload() -> CommandResult:
    """Reload the current page."""
    try:
        log_progress("Reloading page...")
        page = get_page()
        await page.reload()
        await wait_for_network_idle(3.0)

        state = await get_current_state()
        log_progress(f"Reloaded: {state.url}")

        await auto_save_snapshot()

        hints = get_navigation_hints("reload")

        return CommandResult(
            success=True,
            command="reload",
            state=state,
            feedback=Feedback(
                action="reloaded page",
                result=f"reloaded {state.url}",
                changes=hints,
            ),
        )
    except Exception as e:
        log_progress(f"Error: {e}")
        return CommandResult(
            success=False,
            command="reload",
            error=str(e),
        )
