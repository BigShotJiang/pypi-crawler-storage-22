"""Query routes: elements, text, html, screenshot, state."""

from fastapi import APIRouter

from navcli.core.models import QueryData
from navcli.server.browser import (
    get_page,
    get_current_state,
    start_browser,
)
from navcli.server.utils.dom import (
    get_paragraphs,
    get_links as js_get_links,
    get_forms as js_get_forms,
    get_tables as js_get_tables,
    extract_interactive_elements_fast,
)
from navcli.server.utils import log_progress, check_page_loaded

router = APIRouter(prefix="/query")


@router.get("/elements")
async def get_elements() -> QueryData:
    """Get interactive elements on the page."""
    try:
        log_progress("Getting elements...")
        await start_browser()

        if result := check_page_loaded():
            return result

        page = get_page()
        url = page.url
        title = await page.title()

        elements, _ = await extract_interactive_elements_fast(
            page, max_elements=100, include_html=False
        )
        log_progress(f"Found {len(elements)} elements")

        if elements:
            return QueryData(
                url=url,
                title=title,
                elements=[e.dict() for e in elements],
            )
        else:
            return QueryData(url=url, title=title)
    except Exception as e:
        log_progress(f"Error: {e}")
        return QueryData(error=str(e))


@router.get("/text")
async def get_text() -> QueryData:
    """Get page text content."""
    try:
        log_progress("Getting text content...")
        await start_browser()

        if result := check_page_loaded():
            return result

        page = get_page()
        text = await page.inner_text("body")
        log_progress(f"Text length: {len(text)} chars")

        if text:
            return QueryData(
                url=page.url,
                title=await page.title(),
                text=text,
            )
        else:
            return QueryData(url=page.url, title=await page.title())
    except Exception as e:
        log_progress(f"Error: {e}")
        return QueryData(error=str(e))


@router.get("/paragraphs")
async def get_paragraphs(min_length: int = 200) -> QueryData:
    """Get large text paragraphs (200+ chars) from the page."""
    try:
        log_progress(f"Extracting paragraphs (min {min_length} chars)...")
        await start_browser()

        if result := check_page_loaded():
            return result

        page = get_page()
        paragraphs_data = await get_paragraphs(page, min_length)
        log_progress(f"Found {len(paragraphs_data)} paragraphs")

        paragraphs = [
            {
                "index": p.get("index", 0),
                "text": p.get("text", ""),
                "length": p.get("length", 0),
                "selector": p.get("selector", ""),
            }
            for p in paragraphs_data[:50]
        ]
        log_progress(f"Found {len(paragraphs)} paragraphs")

        if paragraphs:
            return QueryData(
                url=page.url,
                title=await page.title(),
                paragraphs=paragraphs,
            )
        else:
            log_progress("No paragraphs found")
            return QueryData(
                url=page.url,
                title=await page.title(),
                error="No large paragraphs found. Try: nav text",
            )
    except Exception as e:
        log_progress(f"Error: {e}")
        return QueryData(error=str(e))


@router.get("/html")
async def get_html() -> QueryData:
    """Get page HTML content."""
    try:
        log_progress("Getting HTML content...")
        await start_browser()

        if result := check_page_loaded():
            return result

        page = get_page()
        html = await page.content()
        log_progress(f"HTML length: {len(html)} chars")

        if html:
            return QueryData(
                url=page.url,
                title=await page.title(),
                html=html,
            )
        else:
            return QueryData(url=page.url, title=await page.title())
    except Exception as e:
        log_progress(f"Error: {e}")
        return QueryData(error=str(e))


@router.get("/screenshot")
async def get_screenshot() -> QueryData:
    """Get page screenshot as base64."""
    try:
        log_progress("Taking screenshot...")
        await start_browser()

        if result := check_page_loaded():
            return result

        page = get_page()
        screenshot_bytes = await page.screenshot()
        from navcli.utils import encode_screenshot

        screenshot_base64 = encode_screenshot(screenshot_bytes)
        log_progress(f"Screenshot size: {len(screenshot_bytes)} bytes")

        return QueryData(
            url=page.url,
            title=await page.title(),
            screenshot=screenshot_base64,
        )
    except Exception as e:
        log_progress(f"Error: {e}")
        return QueryData(error=str(e))


@router.get("/state")
async def get_state() -> QueryData:
    """Get full page state (url and title only)."""
    try:
        log_progress("Getting page state...")
        await start_browser()

        if result := check_page_loaded():
            return result

        state = await get_current_state()
        log_progress(f"Page: {state.title} ({state.url})")

        return QueryData(
            url=state.url,
            title=state.title,
        )
    except Exception as e:
        log_progress(f"Error: {e}")
        return QueryData(error=str(e))


@router.get("/url")
async def get_url() -> QueryData:
    """Get current URL."""
    try:
        log_progress("Getting URL...")
        await start_browser()

        if result := check_page_loaded():
            return result

        page = get_page()
        url = page.url
        log_progress(f"URL: {url}")

        return QueryData(url=url)
    except Exception as e:
        log_progress(f"Error: {e}")
        return QueryData(error=str(e))


@router.get("/title")
async def get_title() -> QueryData:
    """Get page title."""
    try:
        log_progress("Getting title...")
        await start_browser()

        if result := check_page_loaded():
            return result

        page = get_page()
        title = await page.title()
        log_progress(f"Title: {title}")

        return QueryData(title=title)
    except Exception as e:
        log_progress(f"Error: {e}")
        return QueryData(error=str(e))


@router.get("/evaluate")
async def evaluate(expr: str) -> QueryData:
    """Evaluate JavaScript expression."""
    try:
        log_progress(f"Evaluating JS: {expr[:50]}...")
        await start_browser()

        if result := check_page_loaded():
            return result

        page = get_page()
        await page.evaluate(expr)

        return QueryData(
            url=page.url,
            title=await page.title(),
        )
    except Exception as e:
        log_progress(f"Error: {e}")
        return QueryData(error=str(e))


@router.get("/links")
async def get_links() -> QueryData:
    """Get all links on the page."""
    try:
        log_progress("Extracting links...")
        await start_browser()

        if result := check_page_loaded():
            return result

        page = get_page()
        links = await js_get_links(page)
        log_progress(f"Found {len(links)} links")

        if links:
            return QueryData(
                url=page.url,
                title=await page.title(),
                links=links,
            )
        else:
            return QueryData(url=page.url, title=await page.title())
    except Exception as e:
        log_progress(f"Error: {e}")
        return QueryData(error=str(e))


@router.get("/forms")
async def get_forms() -> QueryData:
    """Get all forms on the page."""
    try:
        log_progress("Extracting forms...")
        await start_browser()

        if result := check_page_loaded():
            return result

        page = get_page()
        forms = await js_get_forms(page)
        log_progress(f"Found {len(forms)} forms")

        if forms:
            return QueryData(
                url=page.url,
                title=await page.title(),
                forms=forms,
            )
        else:
            return QueryData(url=page.url, title=await page.title())
    except Exception as e:
        log_progress(f"Error: {e}")
        return QueryData(error=str(e))


@router.get("/tables")
async def get_tables() -> QueryData:
    """Get all tables on the page with their data."""
    try:
        log_progress("Extracting tables...")
        await start_browser()

        if result := check_page_loaded():
            return result

        page = get_page()
        tables = await js_get_tables(page)
        log_progress(f"Found {len(tables)} tables")

        if tables:
            total_rows = sum(t["rowCount"] for t in tables)
            log_progress(f"Found {len(tables)} tables, {total_rows} rows total")
            return QueryData(
                url=page.url,
                title=await page.title(),
                tables=tables,
            )
        else:
            log_progress("No tables found")
            return QueryData(
                url=page.url,
                title=await page.title(),
                error="No tables found. Try: nav links | nav elements | nav text",
            )
    except Exception as e:
        log_progress(f"Error: {e}")
        return QueryData(error=str(e))
