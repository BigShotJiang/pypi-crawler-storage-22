"""Session routes: cookies, save_session, load_session."""

import os
from typing import Optional, List, Dict, Any
from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel

from navcli.core.models import CommandResult, Feedback
from navcli.server.browser import (
    get_cookies,
    set_cookie,
    clear_cookies,
    save_session,
    load_session,
)

# Session directory
_NAVCLI_HOME = os.path.expanduser("~/.navcli")
_NAVCLI_SESSIONS_DIR = os.path.join(_NAVCLI_HOME, "sessions")

router = APIRouter()


def log_progress(message: str):
    """Print progress message."""
    print(f"[PROGRESS] {message}")


class CookieSetRequest(BaseModel):
    """Request body for setting a cookie."""
    name: str
    value: str
    domain: str
    path: str = "/"
    expires: Optional[int] = None
    http_only: bool = False
    secure: bool = False
    same_site: Optional[str] = None


@router.get("/cookies")
async def query_cookies() -> CommandResult:
    """Get all current cookies.

    Returns list of cookies with name, value, domain, path, etc.
    """
    try:
        log_progress("Getting cookies...")
        cookies = await get_cookies()
        log_progress(f"Found {len(cookies)} cookies")

        return CommandResult(
            success=True,
            command="cookies",
            feedback=Feedback(
                action="got cookies",
                result=f"found {len(cookies)} cookies",
            ),
        )
    except Exception as e:
        log_progress(f"Error: {e}")
        return CommandResult(
            success=False,
            command="cookies",
            error=str(e),
        )


@router.post("/cookies/set")
async def set_cookie_route(request: CookieSetRequest) -> CommandResult:
    """Set a single cookie.

    Usage: POST /cmd/cookies/set with JSON body
    """
    try:
        log_progress(f"Setting cookie: {request.name}")
        await set_cookie(
            name=request.name,
            value=request.value,
            domain=request.domain,
            path=request.path,
            expires=request.expires,
            http_only=request.http_only,
            secure=request.secure,
            same_site=request.same_site,
        )

        return CommandResult(
            success=True,
            command="set_cookie",
            feedback=Feedback(
                action="set cookie",
                result=f"cookie '{request.name}' set for {request.domain}",
            ),
        )
    except Exception as e:
        log_progress(f"Error: {e}")
        return CommandResult(
            success=False,
            command="set_cookie",
            error=str(e),
        )


@router.delete("/cookies/clear")
async def clear_cookies_route() -> CommandResult:
    """Clear all cookies.

    Returns the number of cookies that were cleared.
    """
    try:
        log_progress("Clearing cookies...")
        count = await clear_cookies()
        log_progress(f"Cleared {count} cookies")

        return CommandResult(
            success=True,
            command="clear_cookies",
            feedback=Feedback(
                action="cleared cookies",
                result=f"cleared {count} cookies",
            ),
        )
    except Exception as e:
        log_progress(f"Error: {e}")
        return CommandResult(
            success=False,
            command="clear_cookies",
            error=str(e),
        )


@router.post("/session/save")
async def save_session_route(
    path: str = Query(None),
    name: str = Query(None),
) -> CommandResult:
    """Save session to file.

    Saves cookies, localStorage, and sessionStorage to a JSON file.

    Args:
        path: Full file path to save session
        name: Session name (saves to ~/.navcli/sessions/<name>.json)
    """
    try:
        # Determine save path
        if name:
            save_path = os.path.join(_NAVCLI_SESSIONS_DIR, f"{name}.json")
        elif path:
            save_path = path
        else:
            save_path = os.path.join(_NAVCLI_SESSIONS_DIR, "session.json")

        log_progress(f"Saving session to {save_path}...")
        storage_state = await save_session(save_path)

        cookie_count = len(storage_state.get("cookies", []))
        origin_count = len(storage_state.get("origins", []))
        log_progress(f"Saved: {cookie_count} cookies, {origin_count} origins")

        return CommandResult(
            success=True,
            command="save_session",
            feedback=Feedback(
                action="saved session",
                result=f"saved to {save_path}: {cookie_count} cookies, {origin_count} origins",
            ),
        )
    except Exception as e:
        log_progress(f"Error: {e}")
        return CommandResult(
            success=False,
            command="save_session",
            error=str(e),
        )


@router.post("/session/load")
async def load_session_route(
    path: str = Query(None),
    name: str = Query(None),
) -> CommandResult:
    """Load session from file.

    Loads cookies, localStorage, and sessionStorage from a JSON file.

    Args:
        path: Full file path to load session from
        name: Session name (loads from ~/.navcli/sessions/<name>.json)
    """
    # Determine load path
    if name:
        load_path = os.path.join(_NAVCLI_SESSIONS_DIR, f"{name}.json")
    elif path:
        load_path = path
    else:
        load_path = os.path.join(_NAVCLI_SESSIONS_DIR, "session.json")

    try:
        log_progress(f"Loading session from {load_path}...")
        await load_session(load_path)
        log_progress("Session loaded")

        return CommandResult(
            success=True,
            command="load_session",
            feedback=Feedback(
                action="loaded session",
                result=f"loaded session from {load_path}",
            ),
        )
    except FileNotFoundError:
        log_progress(f"Session file not found: {load_path}")
        return CommandResult(
            success=False,
            command="load_session",
            error=f"Session file not found: {load_path}",
        )
    except Exception as e:
        log_progress(f"Error: {e}")
        return CommandResult(
            success=False,
            command="load_session",
            error=str(e),
        )
