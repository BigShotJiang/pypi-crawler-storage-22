"""Common utilities for NavCLI."""

from .selector import (
    build_selector,
    parse_selector,
    generate_stable_selector,
    generate_selector_path,
    build_selector_from_attrs,
)
from .image import decode_screenshot, encode_screenshot
from .url import normalize_url
from .js import escape_js_string
from .time import format_timeout, wait_for_condition
from .text import parse_key_value

__all__ = [
    "parse_selector",
    "build_selector",
    "generate_stable_selector",
    "generate_selector_path",
    "build_selector_from_attrs",
    "decode_screenshot",
    "encode_screenshot",
    "normalize_url",
    "escape_js_string",
    "format_timeout",
    "wait_for_condition",
    "parse_key_value",
]
