# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/), and this
project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [2.3.0] - 2022-10-03
* Add Support for Pluggable Extensions
* Extensions: LocaleSupport (babel+locale), DBConnection (based on asyncdb), Redis (based on aioredis), Memcache (based on aimcache), TemplateParser (based on jinja2), Auth (Authentication Support)
* Refactor Code.

## [2.2.0] - 2022-09-14
* Added python-datamodel as dependency for build Dataclasses.
* replaced rapidjson with orjson.
* fix some issues in publish-to-pypi GH.
* Support for aiohttp > 3.8

## [2.1.0] - 2021-10-20
* First stable version with support to Python +3.8
* Fixing issues over pyproject.toml
