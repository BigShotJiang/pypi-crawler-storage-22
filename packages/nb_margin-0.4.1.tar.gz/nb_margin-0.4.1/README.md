# nb-margin

A JupyterLab 4 extension that lets you annotate notebook cells with comments and submit them to [Claude Code](https://docs.anthropic.com/en/docs/claude-code) for automatic editing — without leaving the browser.

## How it works

1. Open a notebook in JupyterLab
2. Select a cell and press **Ctrl+Shift+A** (or right-click → "Annotate Cell for Claude")
3. Describe the change you want in the dialog
4. Annotate as many cells as you like — annotations accumulate in the sidebar
5. Press **Ctrl+Shift+Enter** (or click "Submit to Claude Code")
6. Claude Code edits the `.ipynb` file directly; the notebook reloads when done

## Requirements

- JupyterLab >= 4.0
- [Claude Code](https://docs.anthropic.com/en/docs/claude-code) CLI installed and available on `$PATH`

## Install

```bash
pip install nb-margin
```

## Development

```bash
# Clone and install in development mode
git clone https://github.com/anthropics/nb-margin.git
cd nb-margin
pip install -e "."
jupyter labextension develop . --overwrite
jlpm build

# Watch for changes (two terminals)
jlpm watch          # terminal 1
jupyter lab         # terminal 2
```

## Permission modes

The sidebar includes a permission mode selector:

- **Safe** (default) — Claude Code can only read and write files
- **Bash** — also allows shell commands (for linters, tests, etc.)
- **Skip** — no permission restrictions (`--dangerouslySkipPermissions`)

Set the default via the `NB_MARGIN_PERMISSION_MODE` environment variable (`safe`, `bash`, or `skip`).

## Keyboard shortcuts

| Shortcut | Action |
|---|---|
| `Ctrl+Shift+A` | Annotate the active cell |
| `Ctrl+Shift+Enter` | Submit annotations to Claude Code |

## Uninstall

```bash
pip uninstall nb-margin
```

## License

MIT
