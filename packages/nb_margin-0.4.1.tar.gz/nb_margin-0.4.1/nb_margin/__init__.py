"""nb-margin: Annotate notebook cells and have Claude Code edit them."""

from .handlers import setup_handlers


def _jupyter_labextension_paths():
    return [{"src": "labextension", "dest": "nb-margin"}]


def _jupyter_server_extension_points():
    return [{"module": "nb_margin"}]


def _load_jupyter_server_extension(server_app):
    """Register the API handlers."""
    setup_handlers(server_app.web_app)
    server_app.log.info("nb-margin server extension loaded.")
