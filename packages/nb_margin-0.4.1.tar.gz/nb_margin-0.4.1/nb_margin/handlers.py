"""Tornado handlers for nb-margin server extension."""

import asyncio
import json
import os
import shutil

import tornado.web
from jupyter_server.base.handlers import APIHandler
from jupyter_server.utils import url_path_join


# notebook_path -> session_id for reusing Claude conversations
_notebook_sessions: dict[str, str] = {}


def _find_claude_binary():
    """Locate the claude CLI binary."""
    path = shutil.which("claude")
    if path:
        return path
    # Common fallback locations
    fallbacks = [
        os.path.expanduser("~/.npm-global/bin/claude"),
        os.path.expanduser("~/.local/bin/claude"),
        "/usr/local/bin/claude",
    ]
    for fb in fallbacks:
        if os.path.isfile(fb) and os.access(fb, os.X_OK):
            return fb
    return None


SAFE_TOOLS = ["Read", "Edit", "Write", "NotebookEdit", "Glob", "Grep"]
BASH_TOOLS = SAFE_TOOLS + ["Bash"]


def _extract_primary_param(tool_name, tool_input):
    """Extract the most informative parameter from a tool_use block."""
    if tool_name in ("Read", "Edit", "Write", "NotebookEdit"):
        return tool_input.get("file_path", "") or tool_input.get("notebook_path", "")
    elif tool_name in ("Glob", "Grep"):
        return tool_input.get("pattern", "")
    elif tool_name == "Bash":
        cmd = tool_input.get("command", "")
        return (cmd[:80] + "...") if len(cmd) > 80 else cmd
    return ""


def _build_args(claude_bin, mode, session_id=None):
    """Build the command-line arguments for claude."""
    args = [claude_bin, "--print",
            "--output-format", "stream-json",
            "--verbose"]
    if session_id:
        args.extend(["--resume", session_id])
    if mode == "skip":
        args.append("--dangerously-skip-permissions")
    else:
        tools = BASH_TOOLS if mode == "bash" else SAFE_TOOLS
        for tool in tools:
            args.extend(["--allowedTools", tool])
    return args


def _build_prompt(notebook_path, annotations):
    """Build the prompt sent to Claude Code."""
    parts = [
        f"Edit the Jupyter notebook file `{notebook_path}`.",
        "",
        "Apply the following changes:",
        "",
    ]
    for ann in annotations:
        cell_index = ann["cellIndex"]
        cell_type = ann.get("cellType", "code")
        source = ann.get("source", "")
        comment = ann["comment"]
        parts.append(f"### Cell {cell_index} ({cell_type})")
        parts.append("Current source:")
        parts.append("```")
        parts.append(source)
        parts.append("```")
        parts.append(f"Requested change: {comment}")
        parts.append("")

    parts.extend(
        [
            "Important:",
            "- The notebook is a .ipynb file (JSON format).",
            "- Edit cells by their 0-based index in the `cells` array.",
            "- Each cell's `source` is a list of strings with \\n line endings.",
            "- Clear `outputs` and set `execution_count` to null for modified code cells.",
            "- Preserve all notebook metadata.",
            "- Do not create new files. Do not execute cells.",
        ]
    )
    return "\n".join(parts)


def _resolve_notebook_path(handler, relative_path):
    """Resolve a Jupyter-relative notebook path to an absolute filesystem path."""
    root_dir = handler.settings.get("server_root_dir", "")
    if not root_dir:
        root_dir = handler.settings.get("root_dir", os.getcwd())
    return os.path.expanduser(os.path.join(root_dir, relative_path))


class StatusHandler(APIHandler):
    """GET /api/nb-margin/status — check if claude binary is available."""

    @tornado.web.authenticated
    def get(self):
        claude_bin = _find_claude_binary()
        self.finish(
            json.dumps(
                {
                    "available": claude_bin is not None,
                    "path": claude_bin,
                }
            )
        )


class ApplyHandler(APIHandler):
    """POST /api/nb-margin/apply — non-streaming submit."""

    @tornado.web.authenticated
    async def post(self):
        claude_bin = _find_claude_binary()
        if not claude_bin:
            raise tornado.web.HTTPError(
                500, reason="claude binary not found. Install Claude Code first."
            )

        body = self.get_json_body()
        raw_path = body.get("notebookPath")
        annotations = body.get("annotations", [])
        mode = body.get("mode", os.environ.get("NB_MARGIN_PERMISSION_MODE", "safe"))

        if not raw_path or not annotations:
            raise tornado.web.HTTPError(400, reason="Missing notebookPath or annotations")

        notebook_path = _resolve_notebook_path(self, raw_path)
        if not os.path.isfile(notebook_path):
            raise tornado.web.HTTPError(404, reason=f"Notebook not found: {notebook_path}")

        prompt = _build_prompt(notebook_path, annotations)
        args = _build_args(claude_bin, mode)
        notebook_dir = os.path.dirname(os.path.abspath(notebook_path))

        proc = await asyncio.create_subprocess_exec(
            *args,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=notebook_dir,
        )
        stdout, stderr = await asyncio.wait_for(
            proc.communicate(input=prompt.encode()), timeout=300
        )

        if proc.returncode != 0:
            self.set_status(500)
            self.finish(
                json.dumps(
                    {
                        "success": False,
                        "error": stderr.decode(errors="replace"),
                        "stdout": stdout.decode(errors="replace"),
                    }
                )
            )
            return

        self.finish(
            json.dumps(
                {
                    "success": True,
                    "output": stdout.decode(errors="replace"),
                }
            )
        )


class StreamHandler(APIHandler):
    """POST /api/nb-margin/stream — SSE streaming submit."""

    @tornado.web.authenticated
    async def post(self):
        claude_bin = _find_claude_binary()
        if not claude_bin:
            self._write_sse("error", {"message": "claude binary not found"})
            return

        body = self.get_json_body()
        raw_path = body.get("notebookPath")
        annotations = body.get("annotations", [])
        mode = body.get("mode", os.environ.get("NB_MARGIN_PERMISSION_MODE", "safe"))
        timeout = min(max(int(body.get("timeout", 180)), 30), 600)

        if not raw_path or not annotations:
            self._write_sse("error", {"message": "Missing notebookPath or annotations"})
            return

        notebook_path = _resolve_notebook_path(self, raw_path)
        if not os.path.isfile(notebook_path):
            self._write_sse("error", {"message": f"Notebook not found: {notebook_path}"})
            return

        # Set SSE headers
        self.set_header("Content-Type", "text/event-stream")
        self.set_header("Cache-Control", "no-cache")
        self.set_header("X-Accel-Buffering", "no")

        prompt = _build_prompt(notebook_path, annotations)
        session_id = _notebook_sessions.get(notebook_path)
        was_resuming = session_id is not None
        args = _build_args(claude_bin, mode, session_id)
        notebook_dir = os.path.dirname(os.path.abspath(notebook_path))

        self._write_sse("start", {"message": "Starting Claude Code..."})
        await self.flush()

        # State for block-level delta tracking across assistant messages
        last_message_id = None
        tracked_blocks = []  # [{"type":"text","accumulated":""} | {"type":"tool_use","id":...,"last_keys":set()}]

        try:
            proc = await asyncio.create_subprocess_exec(
                *args,
                stdin=asyncio.subprocess.PIPE,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=notebook_dir,
            )

            proc.stdin.write(prompt.encode())
            await proc.stdin.drain()
            proc.stdin.close()

            # Stream stdout — each line is a JSON object (stream-json format)
            success = False
            while True:
                line = await asyncio.wait_for(
                    proc.stdout.readline(), timeout=timeout
                )
                if not line:
                    break
                text = line.decode(errors="replace").strip()
                if not text:
                    continue

                try:
                    event = json.loads(text)
                except json.JSONDecodeError:
                    continue

                event_type = event.get("type")

                if event_type == "system" and event.get("subtype") == "init":
                    sid = event.get("session_id")
                    if sid:
                        _notebook_sessions[notebook_path] = sid

                elif event_type == "assistant":
                    # Block-level tracking of assistant message content
                    message = event.get("message", {})
                    msg_id = message.get("id")
                    content_blocks = message.get("content", [])

                    # Reset tracking when a new assistant message starts
                    if msg_id != last_message_id:
                        tracked_blocks = []
                        last_message_id = msg_id
                        self._write_sse("message_start", {})
                        await self.flush()

                    for i, block in enumerate(content_blocks):
                        block_type = block.get("type")

                        # Grow tracked_blocks list to match
                        while len(tracked_blocks) <= i:
                            tracked_blocks.append(None)

                        if block_type == "text":
                            full_text = block.get("text", "")
                            prev = tracked_blocks[i]
                            if prev is None or prev.get("type") != "text":
                                tracked_blocks[i] = {"type": "text", "accumulated": ""}
                                prev = tracked_blocks[i]
                            acc = prev["accumulated"]
                            if len(full_text) > len(acc):
                                delta = full_text[len(acc):]
                                prev["accumulated"] = full_text
                                self._write_sse("output", {"text": delta, "blockIndex": i})
                                await self.flush()

                        elif block_type == "tool_use":
                            tool_name = block.get("name", "")
                            tool_input = block.get("input", {})
                            primary = _extract_primary_param(tool_name, tool_input)
                            cur_keys = set(tool_input.keys())

                            prev = tracked_blocks[i]
                            if prev is None or prev.get("type") != "tool_use":
                                # New tool_use block (or index previously held a text block)
                                tracked_blocks[i] = {
                                    "type": "tool_use",
                                    "id": block.get("id"),
                                    "last_keys": cur_keys,
                                }
                                self._write_sse("tool_use", {"name": tool_name, "primary_param": primary})
                                await self.flush()
                            elif cur_keys != prev["last_keys"]:
                                # Input params grew — update
                                prev["last_keys"] = cur_keys
                                self._write_sse("tool_update", {"name": tool_name, "primary_param": primary})
                                await self.flush()

                elif event_type == "result":
                    sid = event.get("session_id")
                    if sid:
                        _notebook_sessions[notebook_path] = sid

                    subtype = event.get("subtype")
                    if subtype == "success":
                        success = True
                        self._write_sse("done", {"message": "Claude Code finished successfully."})
                    else:
                        # Error result — clear session if we were resuming a stale one
                        error_msg = event.get("error", f"Claude Code result: {subtype}")
                        if was_resuming:
                            _notebook_sessions.pop(notebook_path, None)
                        self._write_sse("error", {"message": error_msg})
                    await self.flush()

                # Skip tool_use, tool_result, and other internal events

            await proc.wait()

            if not success:
                stderr_bytes = await proc.stderr.read()
                stderr_text = stderr_bytes.decode(errors="replace") if stderr_bytes else ""
                if proc.returncode != 0:
                    if was_resuming:
                        _notebook_sessions.pop(notebook_path, None)
                    self._write_sse(
                        "error",
                        {
                            "message": f"Claude Code exited with code {proc.returncode}",
                            "stderr": stderr_text,
                        },
                    )
        except asyncio.TimeoutError:
            self._write_sse(
                "error",
                {
                    "message": f"Claude Code timed out ({timeout}s). "
                    "Try a less restrictive permission mode or increase the timeout."
                },
            )
            try:
                proc.kill()
            except Exception:
                pass
        except Exception as exc:
            self._write_sse("error", {"message": str(exc)})

        await self.flush()
        self.finish()

    def _write_sse(self, event, data):
        """Write an SSE event to the response."""
        self.write(f"event: {event}\ndata: {json.dumps(data)}\n\n")


class ResetSessionHandler(APIHandler):
    """POST /api/nb-margin/reset-session — clear stored session for a notebook."""

    @tornado.web.authenticated
    async def post(self):
        body = self.get_json_body()
        raw_path = body.get("notebookPath")
        if not raw_path:
            raise tornado.web.HTTPError(400, reason="Missing notebookPath")

        notebook_path = _resolve_notebook_path(self, raw_path)
        _notebook_sessions.pop(notebook_path, None)
        self.finish(json.dumps({"ok": True}))


def setup_handlers(web_app):
    """Register the API handlers with the Jupyter server."""
    host_pattern = ".*$"
    base_url = web_app.settings["base_url"]
    route = lambda path: url_path_join(base_url, "api", "nb-margin", path)

    web_app.add_handlers(
        host_pattern,
        [
            (route("status"), StatusHandler),
            (route("apply"), ApplyHandler),
            (route("stream"), StreamHandler),
            (route("reset-session"), ResetSessionHandler),
        ],
    )
