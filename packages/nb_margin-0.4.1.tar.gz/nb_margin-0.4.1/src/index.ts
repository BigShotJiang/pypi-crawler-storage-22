import {
  ILabShell,
  JupyterFrontEnd,
  JupyterFrontEndPlugin
} from '@jupyterlab/application';
import { ICommandPalette, showDialog, Dialog } from '@jupyterlab/apputils';
import { INotebookTracker, NotebookPanel } from '@jupyterlab/notebook';
import { URLExt } from '@jupyterlab/coreutils';
import { ServerConnection } from '@jupyterlab/services';
import { Widget } from '@lumino/widgets';

/** A single annotation: cell index, type, source snapshot, and user comment. */
interface IAnnotation {
  cellIndex: number;
  cellType: string;
  source: string;
  comment: string;
}

// ---------------------------------------------------------------------------
// Annotation Dialog Body
// ---------------------------------------------------------------------------

class AnnotationDialogBody extends Widget {
  private _textarea: HTMLTextAreaElement;

  constructor(cellIndex: number, cellType: string) {
    super();
    this.addClass('nbm-dialog-body');

    const info = document.createElement('div');
    info.className = 'nbm-dialog-info';
    info.textContent = `Cell ${cellIndex} (${cellType})`;
    this.node.appendChild(info);

    this._textarea = document.createElement('textarea');
    this._textarea.className = 'nbm-dialog-textarea';
    this._textarea.placeholder = 'Describe the change you want...';
    this.node.appendChild(this._textarea);

    // Auto-focus after dialog renders
    requestAnimationFrame(() => this._textarea.focus());
  }

  getValue(): string {
    return this._textarea.value.trim();
  }
}

// ---------------------------------------------------------------------------
// Sidebar Panel
// ---------------------------------------------------------------------------

class MarginPanel extends Widget {
  private _annotations: IAnnotation[] = [];
  private _listEl: HTMLElement;
  private _badgeEl: HTMLElement;
  private _statusEl: HTMLElement;
  private _outputScrollEl: HTMLElement;
  private _structuredEl: HTMLElement;
  private _rawEl: HTMLPreElement;
  private _rawToggle: HTMLInputElement;
  private _currentBlocks: Map<number, HTMLElement> = new Map();
  private _toolCardCount = 0;
  private _submitBtn: HTMLButtonElement;
  private _clearBtn: HTMLButtonElement;
  private _newSessionBtn: HTMLButtonElement;
  private _modeSelect: HTMLSelectElement;
  private _timeoutInput: HTMLInputElement;
  private _working = false;
  private _onQuickSubmit: ((ann: IAnnotation) => void) | null = null;
  private _annSection: HTMLElement;
  private _outSection: HTMLElement;
  private _settingsSection: HTMLElement;
  private _annTab: HTMLButtonElement;
  private _outTab: HTMLButtonElement;
  private _settingsTab: HTMLButtonElement;

  constructor() {
    super();
    this.id = 'nbm-panel';
    this.title.label = 'nb-margin';
    this.title.closable = true;
    this.addClass('nbm-panel');

    // Header
    const header = document.createElement('div');
    header.className = 'nbm-panel-header';
    const titleWrap = document.createElement('div');
    titleWrap.className = 'nbm-panel-header-title';
    titleWrap.textContent = 'nb-margin';
    this._badgeEl = document.createElement('span');
    this._badgeEl.className = 'nbm-badge nbm-badge-zero';
    this._badgeEl.textContent = '0';
    titleWrap.appendChild(this._badgeEl);
    header.appendChild(titleWrap);
    this.node.appendChild(header);

    // Status
    this._statusEl = document.createElement('div');
    this._statusEl.className = 'nbm-status';
    this._statusEl.textContent = 'Ready';
    this.node.appendChild(this._statusEl);

    // Tab bar
    const tabBar = document.createElement('div');
    tabBar.className = 'nbm-tab-bar';
    this._annTab = document.createElement('button');
    this._annTab.className = 'nbm-tab nbm-tab-active';
    this._annTab.textContent = 'Annotations';
    this._annTab.addEventListener('click', () => this.showTab('annotations'));
    tabBar.appendChild(this._annTab);
    this._outTab = document.createElement('button');
    this._outTab.className = 'nbm-tab';
    this._outTab.textContent = 'Output';
    this._outTab.addEventListener('click', () => this.showTab('output'));
    tabBar.appendChild(this._outTab);
    this._settingsTab = document.createElement('button');
    this._settingsTab.className = 'nbm-tab';
    this._settingsTab.textContent = 'Settings';
    this._settingsTab.addEventListener('click', () => this.showTab('settings'));
    tabBar.appendChild(this._settingsTab);
    this.node.appendChild(tabBar);

    // Tab content wrapper
    const tabContent = document.createElement('div');
    tabContent.className = 'nbm-tab-content';

    // Annotations section
    this._annSection = document.createElement('div');
    this._annSection.className = 'nbm-annotations-section';
    this._listEl = document.createElement('div');
    this._listEl.className = 'nbm-annotations-list';
    this._annSection.appendChild(this._listEl);
    tabContent.appendChild(this._annSection);

    // Output section (hidden by default)
    this._outSection = document.createElement('div');
    this._outSection.className = 'nbm-output-section nbm-tab-hidden';

    // Toolbar with Raw toggle
    const toolbar = document.createElement('div');
    toolbar.className = 'nbm-output-toolbar';
    const rawLabel = document.createElement('label');
    rawLabel.className = 'nbm-raw-toggle';
    this._rawToggle = document.createElement('input');
    this._rawToggle.type = 'checkbox';
    this._rawToggle.addEventListener('change', () => this._toggleRawView());
    rawLabel.appendChild(this._rawToggle);
    rawLabel.appendChild(document.createTextNode(' Raw'));
    toolbar.appendChild(rawLabel);
    this._outSection.appendChild(toolbar);

    // Scrollable container
    this._outputScrollEl = document.createElement('div');
    this._outputScrollEl.className = 'nbm-output-scroll';

    // Structured view
    this._structuredEl = document.createElement('div');
    this._structuredEl.className = 'nbm-output-structured';
    this._outputScrollEl.appendChild(this._structuredEl);

    // Raw pre (hidden by default)
    this._rawEl = document.createElement('pre');
    this._rawEl.className = 'nbm-output-raw nbm-tab-hidden';
    this._outputScrollEl.appendChild(this._rawEl);

    this._outSection.appendChild(this._outputScrollEl);
    tabContent.appendChild(this._outSection);

    // Settings section (hidden by default)
    this._settingsSection = document.createElement('div');
    this._settingsSection.className = 'nbm-settings-section nbm-tab-hidden';

    // Permissions setting
    const permGroup = document.createElement('div');
    permGroup.className = 'nbm-settings-group';
    const permLabel = document.createElement('label');
    permLabel.textContent = 'Permissions';
    permGroup.appendChild(permLabel);
    this._modeSelect = document.createElement('select');
    this._modeSelect.className = 'nbm-mode-select';
    for (const [value, label] of [
      ['safe', 'Safe (read/write only)'],
      ['bash', 'Bash (+ shell commands)'],
      ['skip', 'Skip (no restrictions)']
    ]) {
      const opt = document.createElement('option');
      opt.value = value;
      opt.textContent = label;
      this._modeSelect.appendChild(opt);
    }
    permGroup.appendChild(this._modeSelect);
    this._settingsSection.appendChild(permGroup);

    // Timeout setting
    const timeoutGroup = document.createElement('div');
    timeoutGroup.className = 'nbm-settings-group';
    const timeoutLabel = document.createElement('label');
    timeoutLabel.textContent = 'Timeout (seconds)';
    timeoutGroup.appendChild(timeoutLabel);
    this._timeoutInput = document.createElement('input');
    this._timeoutInput.type = 'number';
    this._timeoutInput.className = 'nbm-settings-input';
    this._timeoutInput.value = '180';
    this._timeoutInput.min = '30';
    this._timeoutInput.max = '600';
    timeoutGroup.appendChild(this._timeoutInput);
    this._settingsSection.appendChild(timeoutGroup);

    // Session management
    const sessionGroup = document.createElement('div');
    sessionGroup.className = 'nbm-settings-group';
    const sessionLabel = document.createElement('label');
    sessionLabel.textContent = 'Session';
    sessionGroup.appendChild(sessionLabel);
    this._newSessionBtn = document.createElement('button');
    this._newSessionBtn.className = 'nbm-btn';
    this._newSessionBtn.textContent = 'New Session';
    sessionGroup.appendChild(this._newSessionBtn);
    this._settingsSection.appendChild(sessionGroup);

    tabContent.appendChild(this._settingsSection);

    this.node.appendChild(tabContent);

    // Actions
    const actions = document.createElement('div');
    actions.className = 'nbm-actions';
    this._clearBtn = document.createElement('button');
    this._clearBtn.className = 'nbm-btn';
    this._clearBtn.textContent = 'Clear';
    this._clearBtn.addEventListener('click', () => this.clearAnnotations());
    actions.appendChild(this._clearBtn);
    this._submitBtn = document.createElement('button');
    this._submitBtn.className = 'nbm-btn nbm-btn-primary';
    this._submitBtn.textContent = 'Submit to Claude Code';
    actions.appendChild(this._submitBtn);
    this.node.appendChild(actions);

    this._renderList();
  }

  get annotations(): IAnnotation[] {
    return this._annotations;
  }

  get mode(): string {
    return this._modeSelect.value;
  }

  get timeout(): number {
    return parseInt(this._timeoutInput.value, 10) || 180;
  }

  get submitButton(): HTMLButtonElement {
    return this._submitBtn;
  }

  get newSessionButton(): HTMLButtonElement {
    return this._newSessionBtn;
  }

  get working(): boolean {
    return this._working;
  }

  set onQuickSubmit(cb: ((ann: IAnnotation) => void) | null) {
    this._onQuickSubmit = cb;
  }

  showTab(tab: 'annotations' | 'output' | 'settings'): void {
    const sections = [this._annSection, this._outSection, this._settingsSection];
    const tabs = [this._annTab, this._outTab, this._settingsTab];
    const index = tab === 'annotations' ? 0 : tab === 'output' ? 1 : 2;
    for (let i = 0; i < sections.length; i++) {
      sections[i].classList.toggle('nbm-tab-hidden', i !== index);
      tabs[i].classList.toggle('nbm-tab-active', i === index);
    }
  }

  addAnnotation(ann: IAnnotation): void {
    // Replace existing annotation for same cell
    const idx = this._annotations.findIndex(a => a.cellIndex === ann.cellIndex);
    if (idx >= 0) {
      this._annotations[idx] = ann;
    } else {
      this._annotations.push(ann);
    }
    this._annotations.sort((a, b) => a.cellIndex - b.cellIndex);
    this._renderList();
    this.showTab('annotations');
  }

  removeAnnotation(cellIndex: number): void {
    this._annotations = this._annotations.filter(a => a.cellIndex !== cellIndex);
    this._renderList();
  }

  updateAnnotationComment(cellIndex: number, newComment: string): void {
    const ann = this._annotations.find(a => a.cellIndex === cellIndex);
    if (ann) {
      ann.comment = newComment;
    }
  }

  clearAnnotations(): void {
    this._annotations = [];
    this._renderList();
  }

  setStatus(text: string, kind: 'info' | 'working' | 'error' | 'success' = 'info'): void {
    this._statusEl.textContent = text;
    this._statusEl.className = 'nbm-status';
    if (kind === 'working') {
      this._statusEl.classList.add('nbm-status-working');
    } else if (kind === 'error') {
      this._statusEl.classList.add('nbm-status-error');
    } else if (kind === 'success') {
      this._statusEl.classList.add('nbm-status-success');
    }
  }

  appendOutput(text: string): void {
    this._rawEl.textContent += text;
    this._autoScroll();
  }

  clearOutput(): void {
    this._rawEl.textContent = '';
    this._structuredEl.innerHTML = '';
    this._currentBlocks.clear();
    this._toolCardCount = 0;
  }

  appendTextBlock(blockIndex: number, delta: string): void {
    let el = this._currentBlocks.get(blockIndex);
    if (!el) {
      el = document.createElement('div');
      el.className = 'nbm-out-text';
      this._structuredEl.appendChild(el);
      this._currentBlocks.set(blockIndex, el);
    }
    el.textContent += delta;
    this._autoScroll();
  }

  addToolCard(name: string, primaryParam: string): void {
    const card = document.createElement('div');
    card.className = 'nbm-out-tool';
    card.dataset.toolName = name;
    card.dataset.toolIndex = String(this._toolCardCount++);
    const nameEl = document.createElement('span');
    nameEl.className = 'nbm-out-tool-name';
    nameEl.textContent = name;
    card.appendChild(nameEl);
    const paramEl = document.createElement('span');
    paramEl.className = 'nbm-out-tool-param';
    paramEl.textContent = primaryParam;
    paramEl.title = primaryParam;
    card.appendChild(paramEl);
    this._structuredEl.appendChild(card);
    this._autoScroll();
  }

  updateToolCard(name: string, primaryParam: string): void {
    // Update the last tool card matching this name
    const cards = this._structuredEl.querySelectorAll<HTMLElement>('.nbm-out-tool');
    for (let i = cards.length - 1; i >= 0; i--) {
      if (cards[i].dataset.toolName === name) {
        const paramEl = cards[i].querySelector('.nbm-out-tool-param');
        if (paramEl) {
          paramEl.textContent = primaryParam;
          (paramEl as HTMLElement).title = primaryParam;
        }
        break;
      }
    }
  }

  addStatusMarker(kind: 'start' | 'done' | 'error', message: string): void {
    const el = document.createElement('div');
    el.className = `nbm-out-status nbm-out-status--${kind}`;
    el.textContent = message;
    this._structuredEl.appendChild(el);
    this._autoScroll();
  }

  resetBlockTracking(): void {
    this._currentBlocks.clear();
  }

  private _toggleRawView(): void {
    const showRaw = this._rawToggle.checked;
    this._structuredEl.classList.toggle('nbm-tab-hidden', showRaw);
    this._rawEl.classList.toggle('nbm-tab-hidden', !showRaw);
  }

  private _autoScroll(): void {
    this._outputScrollEl.scrollTop = this._outputScrollEl.scrollHeight;
  }

  setWorking(working: boolean): void {
    this._working = working;
    this._submitBtn.disabled = working || this._annotations.length === 0;
    this._clearBtn.disabled = working;
    this._newSessionBtn.disabled = working;
    this._modeSelect.disabled = working;
  }

  private _renderList(): void {
    this._listEl.innerHTML = '';
    this._badgeEl.textContent = String(this._annotations.length);
    this._badgeEl.className =
      this._annotations.length === 0 ? 'nbm-badge nbm-badge-zero' : 'nbm-badge';
    this._submitBtn.disabled = this._working || this._annotations.length === 0;

    if (this._annotations.length === 0) {
      const empty = document.createElement('div');
      empty.className = 'nbm-annotations-empty';
      empty.textContent = 'No annotations yet. Select a cell and press Ctrl+Shift+A.';
      this._listEl.appendChild(empty);
      return;
    }

    for (const ann of this._annotations) {
      const item = document.createElement('div');
      item.className = 'nbm-annotation-item';

      const info = document.createElement('div');
      info.className = 'nbm-annotation-cell-info';
      const label = document.createElement('span');
      label.className = 'nbm-annotation-cell-label';
      label.textContent = `Cell ${ann.cellIndex}`;
      info.appendChild(label);
      const typeEl = document.createElement('span');
      typeEl.className = 'nbm-annotation-cell-type';
      typeEl.textContent = ann.cellType;
      info.appendChild(typeEl);
      item.appendChild(info);

      const comment = document.createElement('div');
      comment.className = 'nbm-annotation-comment';
      comment.textContent = ann.comment;
      comment.title = 'Click to edit';

      const cellIdx2 = ann.cellIndex;
      comment.addEventListener('click', () => {
        if (this._working) return;
        // Replace text with textarea for inline editing
        const textarea = document.createElement('textarea');
        textarea.className = 'nbm-annotation-edit';
        textarea.value = ann.comment;
        comment.replaceWith(textarea);
        textarea.focus();
        textarea.setSelectionRange(textarea.value.length, textarea.value.length);

        const commit = () => {
          const newVal = textarea.value.trim();
          if (newVal && newVal !== ann.comment) {
            this.updateAnnotationComment(cellIdx2, newVal);
          }
          // Re-render to restore normal display
          this._renderList();
        };

        textarea.addEventListener('blur', commit);
        textarea.addEventListener('keydown', (e: KeyboardEvent) => {
          if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            textarea.blur();
          } else if (e.key === 'Escape') {
            // Cancel — re-render without saving
            this._renderList();
          }
        });
      });

      item.appendChild(comment);

      const actions = document.createElement('div');
      actions.className = 'nbm-annotation-actions';

      const sendBtn = document.createElement('button');
      sendBtn.className = 'nbm-annotation-send';
      sendBtn.textContent = '\u25B6';
      sendBtn.title = 'Submit this annotation only';
      const annCopy = { ...ann };
      sendBtn.addEventListener('click', () => {
        if (this._onQuickSubmit && !this._working) {
          this._onQuickSubmit(annCopy);
        }
      });
      actions.appendChild(sendBtn);

      const removeBtn = document.createElement('button');
      removeBtn.className = 'nbm-annotation-remove';
      removeBtn.textContent = '\u00d7';
      removeBtn.title = 'Remove annotation';
      const cellIdx = ann.cellIndex;
      removeBtn.addEventListener('click', () => this.removeAnnotation(cellIdx));
      actions.appendChild(removeBtn);

      item.appendChild(actions);

      this._listEl.appendChild(item);
    }
  }
}

// ---------------------------------------------------------------------------
// SSE helpers
// ---------------------------------------------------------------------------

async function streamSubmit(
  panel: MarginPanel,
  notebookPath: string,
  nbPanel: NotebookPanel,
  annotations?: IAnnotation[]
): Promise<void> {
  const toSubmit = annotations || panel.annotations;
  const settings = ServerConnection.makeSettings();
  const url = URLExt.join(settings.baseUrl, 'api', 'nb-margin', 'stream');

  panel.setWorking(true);
  panel.clearOutput();
  panel.showTab('output');
  panel.setStatus('Sending to Claude Code...', 'working');

  const body = JSON.stringify({
    notebookPath,
    annotations: toSubmit,
    mode: panel.mode,
    timeout: panel.timeout
  });

  let response: Response;
  try {
    response = await ServerConnection.makeRequest(url, { method: 'POST', body }, settings);
  } catch (err) {
    panel.setStatus(`Request failed: ${err}`, 'error');
    panel.setWorking(false);
    return;
  }

  if (!response.ok && response.headers.get('content-type')?.indexOf('text/event-stream') === -1) {
    const text = await response.text();
    panel.setStatus(`Server error: ${response.status}`, 'error');
    panel.appendOutput(text);
    panel.setWorking(false);
    return;
  }

  panel.setStatus('Claude Code is working...', 'working');

  const reader = response.body?.getReader();
  if (!reader) {
    panel.setStatus('No response stream', 'error');
    panel.setWorking(false);
    return;
  }

  const decoder = new TextDecoder();
  let buffer = '';
  let success = false;

  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });

      // Parse SSE events from buffer
      const parts = buffer.split('\n\n');
      buffer = parts.pop() || '';

      for (const part of parts) {
        const lines = part.split('\n');
        let eventType = '';
        let data = '';
        for (const line of lines) {
          if (line.startsWith('event: ')) {
            eventType = line.slice(7);
          } else if (line.startsWith('data: ')) {
            data = line.slice(6);
          }
        }
        if (!eventType || !data) continue;

        let parsed: Record<string, any>;
        try {
          parsed = JSON.parse(data);
        } catch {
          continue;
        }

        switch (eventType) {
          case 'start':
            panel.addStatusMarker('start', parsed.message || 'Starting...');
            panel.appendOutput((parsed.message || '') + '\n');
            break;
          case 'output':
            panel.appendTextBlock(parsed.blockIndex ?? 0, parsed.text || '');
            panel.appendOutput(parsed.text || '');
            break;
          case 'tool_use':
            panel.addToolCard(parsed.name || '?', parsed.primary_param || '');
            panel.appendOutput(`[${parsed.name}: ${parsed.primary_param || ''}]\n`);
            break;
          case 'tool_update':
            panel.updateToolCard(parsed.name || '?', parsed.primary_param || '');
            break;
          case 'message_start':
            panel.resetBlockTracking();
            break;
          case 'done':
            success = true;
            panel.addStatusMarker('done', parsed.message || 'Done.');
            panel.appendOutput('\n' + (parsed.message || 'Done.') + '\n');
            break;
          case 'error':
            panel.addStatusMarker('error', parsed.message || 'Unknown error');
            panel.appendOutput('\nERROR: ' + (parsed.message || 'Unknown error') + '\n');
            if (parsed.stderr) {
              panel.appendOutput(parsed.stderr);
            }
            break;
        }
      }
    }
  } catch (err) {
    panel.appendOutput(`\nStream error: ${err}\n`);
  }

  if (success) {
    panel.setStatus('Done! Reloading notebook...', 'success');
    try {
      await nbPanel.context.revert();
      // Give JupyterLab time to re-render after model update, then force
      // a widget update — without this, cells sometimes appear blank.
      await new Promise(resolve => setTimeout(resolve, 100));
      nbPanel.content.update();
      panel.setStatus('Notebook updated successfully.', 'success');
      // Remove only submitted annotations; clear all if it was a full batch
      if (annotations) {
        for (const ann of annotations) {
          panel.removeAnnotation(ann.cellIndex);
          const cell = nbPanel.content.widgets[ann.cellIndex];
          if (cell) {
            cell.removeClass('nbm-cell-annotated');
          }
        }
      } else {
        panel.clearAnnotations();
        clearCellMarkers(nbPanel);
      }
    } catch (err) {
      panel.setStatus(`Reload failed: ${err}`, 'error');
    }
  } else {
    panel.setStatus('Claude Code finished with errors.', 'error');
  }

  panel.setWorking(false);
}

// ---------------------------------------------------------------------------
// Cell marker helpers
// ---------------------------------------------------------------------------

function markCell(nbPanel: NotebookPanel, cellIndex: number): void {
  const cell = nbPanel.content.widgets[cellIndex];
  if (cell) {
    cell.addClass('nbm-cell-annotated');
  }
}

function clearCellMarkers(nbPanel: NotebookPanel): void {
  for (const cell of nbPanel.content.widgets) {
    cell.removeClass('nbm-cell-annotated');
  }
}

// ---------------------------------------------------------------------------
// Plugin
// ---------------------------------------------------------------------------

const plugin: JupyterFrontEndPlugin<void> = {
  id: 'nb-margin:plugin',
  autoStart: true,
  requires: [INotebookTracker],
  optional: [ILabShell, ICommandPalette],
  activate: (
    app: JupyterFrontEnd,
    tracker: INotebookTracker,
    labShell: ILabShell | null,
    palette: ICommandPalette | null
  ) => {
    const panel = new MarginPanel();

    // Check status on load
    const settings = ServerConnection.makeSettings();
    const statusUrl = URLExt.join(settings.baseUrl, 'api', 'nb-margin', 'status');
    ServerConnection.makeRequest(statusUrl, {}, settings)
      .then((resp: Response) => resp.json())
      .then((data: { available: boolean; path: string | null }) => {
        if (!data.available) {
          panel.setStatus(
            'Claude Code not found. Install it: npm install -g @anthropic-ai/claude-code',
            'error'
          );
        }
      })
      .catch(() => {
        panel.setStatus('Could not check Claude Code status.', 'error');
      });

    // Add panel to right sidebar
    if (labShell) {
      labShell.add(panel, 'right', { rank: 1000 });
    }

    // ---- Commands ----

    // Annotate cell
    app.commands.addCommand('nb-margin:annotate-cell', {
      label: 'Annotate Cell for Claude',
      isEnabled: () => !!tracker.currentWidget && !panel.working,
      execute: async () => {
        const nbPanel = tracker.currentWidget;
        if (!nbPanel) return;

        const activeCell = nbPanel.content.activeCell;
        if (!activeCell) return;

        const cellIndex = nbPanel.content.activeCellIndex;
        const cellType = activeCell.model.type;
        const source = activeCell.model.sharedModel.getSource();

        const dialogBody = new AnnotationDialogBody(cellIndex, cellType);
        const result = await showDialog({
          title: 'Annotate Cell for Claude',
          body: dialogBody,
          buttons: [Dialog.cancelButton(), Dialog.okButton({ label: 'Add Annotation' })]
        });

        if (result.button.accept) {
          const comment = dialogBody.getValue();
          if (comment) {
            panel.addAnnotation({ cellIndex, cellType, source, comment });
            markCell(nbPanel, cellIndex);
            if (labShell) {
              labShell.activateById(panel.id);
            }
          }
        }
      }
    });

    // Submit annotations
    app.commands.addCommand('nb-margin:submit', {
      label: 'Submit Annotations to Claude Code',
      isEnabled: () =>
        !!tracker.currentWidget &&
        panel.annotations.length > 0 &&
        !panel.working,
      execute: async () => {
        const nbPanel = tracker.currentWidget;
        if (!nbPanel) return;
        if (panel.annotations.length === 0) return;

        // Save before submitting so Claude Code sees the latest content
        await nbPanel.context.save();

        // Pass the Jupyter-relative path; the server handler resolves it
        // to an absolute filesystem path
        const notebookPath = nbPanel.context.path;
        await streamSubmit(panel, notebookPath, nbPanel);
      }
    });

    // Quick-submit single annotation for active cell
    app.commands.addCommand('nb-margin:quick-submit', {
      label: 'Quick Submit Active Cell Annotation',
      isEnabled: () => !!tracker.currentWidget && !panel.working,
      execute: async () => {
        const nbPanel = tracker.currentWidget;
        if (!nbPanel) return;

        const cellIndex = nbPanel.content.activeCellIndex;
        const ann = panel.annotations.find(a => a.cellIndex === cellIndex);
        if (!ann) return;

        await nbPanel.context.save();
        const notebookPath = nbPanel.context.path;
        await streamSubmit(panel, notebookPath, nbPanel, [ann]);
      }
    });

    // Clear annotations
    app.commands.addCommand('nb-margin:clear', {
      label: 'Clear All Annotations',
      isEnabled: () => panel.annotations.length > 0 && !panel.working,
      execute: () => {
        const nbPanel = tracker.currentWidget;
        if (nbPanel) {
          clearCellMarkers(nbPanel);
        }
        panel.clearAnnotations();
      }
    });

    // New session — reset stored Claude conversation for this notebook
    app.commands.addCommand('nb-margin:new-session', {
      label: 'New Claude Session',
      isEnabled: () => !panel.working,
      execute: async () => {
        const nbPanel = tracker.currentWidget;
        if (!nbPanel) return;
        const notebookPath = nbPanel.context.path;
        const resetUrl = URLExt.join(settings.baseUrl, 'api', 'nb-margin', 'reset-session');
        try {
          const resp = await ServerConnection.makeRequest(
            resetUrl,
            { method: 'POST', body: JSON.stringify({ notebookPath }) },
            settings
          );
          if (resp.ok) {
            panel.setStatus('New session started', 'success');
            panel.clearOutput();
          } else {
            panel.setStatus('Failed to reset session', 'error');
          }
        } catch (err) {
          panel.setStatus(`Reset failed: ${err}`, 'error');
        }
      }
    });

    // Toggle panel
    app.commands.addCommand('nb-margin:toggle-panel', {
      label: 'Toggle nb-margin Panel',
      execute: () => {
        if (labShell) {
          if (panel.isVisible) {
            panel.hide();
          } else {
            labShell.activateById(panel.id);
          }
        }
      }
    });

    // ---- Submit button click ----
    panel.submitButton.addEventListener('click', () => {
      app.commands.execute('nb-margin:submit');
    });

    // ---- New Session button click ----
    panel.newSessionButton.addEventListener('click', () => {
      app.commands.execute('nb-margin:new-session');
    });

    // ---- Quick-submit callback from annotation card send button ----
    panel.onQuickSubmit = (ann: IAnnotation) => {
      const nbPanel = tracker.currentWidget;
      if (!nbPanel || panel.working) return;
      nbPanel.context.save().then(() => {
        const notebookPath = nbPanel.context.path;
        streamSubmit(panel, notebookPath, nbPanel, [ann]);
      });
    };

    // ---- Keybindings ----
    app.commands.addKeyBinding({
      command: 'nb-margin:annotate-cell',
      keys: ['Ctrl Shift A'],
      selector: '.jp-Notebook'
    });

    app.commands.addKeyBinding({
      command: 'nb-margin:submit',
      keys: ['Ctrl Shift Enter'],
      selector: '.jp-Notebook'
    });

    app.commands.addKeyBinding({
      command: 'nb-margin:quick-submit',
      keys: ['Ctrl Q'],
      selector: '.jp-Notebook'
    });

    // ---- Context menu ----
    app.contextMenu.addItem({
      command: 'nb-margin:annotate-cell',
      selector: '.jp-Cell',
      rank: 100
    });

    // ---- Command palette ----
    if (palette) {
      const category = 'nb-margin';
      palette.addItem({ command: 'nb-margin:annotate-cell', category });
      palette.addItem({ command: 'nb-margin:submit', category });
      palette.addItem({ command: 'nb-margin:quick-submit', category });
      palette.addItem({ command: 'nb-margin:clear', category });
      palette.addItem({ command: 'nb-margin:toggle-panel', category });
      palette.addItem({ command: 'nb-margin:new-session', category });
    }

    console.log('nb-margin extension activated');
  }
};

export default plugin;
