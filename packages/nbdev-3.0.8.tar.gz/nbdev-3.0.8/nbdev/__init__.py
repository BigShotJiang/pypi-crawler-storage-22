__version__ = "3.0.8"

from .doclinks import nbdev_export
from .showdoc import show_doc

