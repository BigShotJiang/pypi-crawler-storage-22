from os import mkdir, path
import shutil

TEMPLATES_DIR = path.join("/tmp", "templates")


# set up the directories for holding generated templates
def set_up_templates_directories():
    if path.exists(TEMPLATES_DIR):
        shutil.rmtree(TEMPLATES_DIR)
    mkdir(TEMPLATES_DIR)
    for family in ["assays", "manifests", "analyses"]:
        family_dir = path.join(TEMPLATES_DIR, family)
        mkdir(family_dir)
