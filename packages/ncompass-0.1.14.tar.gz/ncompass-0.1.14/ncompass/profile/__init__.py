# Copyright 2025 nCompass Technologies
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""nCompass Profiling - Functions for running profilers like nsys."""

from ncompass.profile.nsys import (
    check_nsys_available,
    create_trace_directory,
    run_nsys_profile,
)
from ncompass.profile.ncu import (
    check_ncu_available,
    run_ncu_profile,
    convert_ncu_to_csv,
    NcuDefaults,
    load_ncu_kernel_targets,
    build_kernel_id_regex,
)

__all__ = [
    "check_nsys_available",
    "create_trace_directory",
    "run_nsys_profile",
    "check_ncu_available",
    "run_ncu_profile",
    "convert_ncu_to_csv",
    "NcuDefaults",
    "load_ncu_kernel_targets",
    "build_kernel_id_regex",
]

