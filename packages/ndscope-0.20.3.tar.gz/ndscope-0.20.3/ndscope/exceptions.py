class UnknownChannelError(Exception):
    pass
