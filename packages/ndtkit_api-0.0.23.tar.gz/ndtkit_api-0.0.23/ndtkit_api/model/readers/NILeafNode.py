from py4j.java_gateway import JavaObject
from ..NIEnumScanType import NIEnumScanType
from .NIHeaderNode import NIHeaderNode


class NILeafNode():
    def __init__(self, java_object: JavaObject):
        self._java_object = java_object

    def get_node_id(self): return self._java_object.getNodeID()
    def set_node_id(self, v): self._java_object.setNodeID(v)
    def get_name(self): return self._java_object.getName()
    def set_name(self, v): self._java_object.setName(v)
    def get_gate_name(self): return self._java_object.getGateName()
    def set_gate_name(self, v): self._java_object.setGateName(v)
    def get_scan_type(self) -> NIEnumScanType: return NIEnumScanType.from_java_enum(self._java_object.getScanType())  # type: ignore
    def set_scan_type(self, v): self._java_object.setScanType(NIEnumScanType.to_java_enum(v))  # type: ignore
    def get_children(self): return [NIHeaderNode(child) for child in self._java_object.getChildren()]
    def set_children(self, v: list[NIHeaderNode]): self._java_object.setChildren([child._java_object for child in v])
