from ...ndtkit_socket_connection import gateway
from .NILeafNode import NILeafNode


def getAvailableLeafNodes(file_path: str) -> list[NILeafNode]:
    """Get a list of available leaf nodes in the header tree."""
    list_leaf_nodes: list = gateway.jvm.agi.ndtkit.api.model.readers.NIReaderHelper.getAvailableLeafNodes(file_path)  # type: ignore
    return [NILeafNode(node) for node in list_leaf_nodes]
