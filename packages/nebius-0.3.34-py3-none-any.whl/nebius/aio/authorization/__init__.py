"""Authorization interfaces."""
