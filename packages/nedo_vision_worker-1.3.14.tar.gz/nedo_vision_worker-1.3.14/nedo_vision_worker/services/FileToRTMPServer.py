import subprocess
import logging
import os
import threading
from ..util.EncoderSelector import EncoderSelector
from ..util.RTMPUrl import RTMPUrl

class FileToRTMPStreamer:
    def __init__(self, video_path, stream_key, fps=30, resolution="1280x720", loop=False):
        """
        Initialize the file streamer.

        Args:
            video_path (str): Path to the local video file.
            rtmp_url (str): The RTMP server URL (without stream key).
            stream_key (str): The unique stream key for RTMP.
            fps (int): Frames per second for output stream.
            resolution (str): Resolution of the output stream.
            loop (bool): Loop the video until manually stopped.
        """
        self.video_path = video_path
        self.rtmp_url = RTMPUrl.get_publish_url(stream_key)
        self.fps = fps
        self.resolution = resolution
        self.loop = loop
        self.stream_key = stream_key
        self.process = None

    def start_stream(self):
        """Start streaming video file to RTMP using FFmpeg."""
        if not os.path.exists(self.video_path):
            logging.error(f"❌ [APP] Video file not found: {self.video_path}")
            return

        logging.info(f"📼 [APP] Starting file stream: {self.video_path} → {self.rtmp_url}")

        # Get optimal encoder for hardware
        encoder_args, encoder_name = EncoderSelector.get_encoder_args()
        logging.info(f"🎬 [APP] Using encoder: {encoder_name}")

        # FFmpeg command
        ffmpeg_command = [
            "ffmpeg",
            "-re",  # Read input at native frame rate
            "-stream_loop", "-1" if self.loop else "0",  # Loop if needed
            "-i", self.video_path,

            # Video encoding with optimal encoder
            *encoder_args,
            "-r", str(self.fps),
            "-b:v", "1500k",
            "-maxrate", "2000k",
            "-bufsize", "4000k",
            "-g", str(self.fps),
            "-vf", f"scale={self.resolution}",

            "-loglevel", "error",
            "-an",  # Disable audio

            "-f", "flv",
            self.rtmp_url
        ]

        try:
            with open(os.devnull, "w") as devnull:
                self.process = subprocess.Popen(
                    ffmpeg_command,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.PIPE,
                    text=True,
                    bufsize=1
                )

                threading.Thread(
                    target=self._monitor_ffmpeg_errors,
                    daemon=True
                ).start()

            logging.info("✅ [APP] FFmpeg file stream process started successfully.")
            self.process.wait()  # Block until process is terminated

        except Exception as e:
            logging.error(f"🚨 [APP] Failed to start FFmpeg file stream: {e}")
            self.stop_stream()

    def stop_stream(self):
        """Stop the streaming process."""
        if self.process:
            self.process.terminate()
            self.process.wait()
            logging.info("🛑 [APP] FFmpeg file stream process terminated.")

    def _classify_ffmpeg_error(self, msg: str):
        if "No such file or directory" in msg:
            return "FILE_NOT_FOUND"

        if "Invalid data found" in msg:
            return "INVALID_MEDIA"

        if "encoder" in msg.lower() or "nvenc" in msg.lower():
            return "ENCODER_ERROR"

        if "server returned" in msg.lower() or "rtmp" in msg.lower():
            return "RTMP_ERROR"

        if "broken pipe" in msg.lower():
            return "PIPE_BROKEN"

        return "UNKNOWN_ERROR"

    def _monitor_ffmpeg_errors(self):
        """Read FFmpeg stderr and log meaningful errors."""
        try:
            for line in iter(self.process.stderr.readline, ''):
                if not line:
                    break

                msg = line.strip()
                if not msg:
                    continue

                error_type = self._classify_ffmpeg_error(msg)
                logging.error(f"🔥 [FFMPEG][{error_type}] {msg}")

                # Stop on critical errors
                if error_type != "UNKNOWN_ERROR":
                    logging.error("🛑 [APP] Critical FFmpeg error detected. Stopping stream.")
                    self.stop_stream()
                    break
        except Exception as e:
            logging.error(f"🚨 [APP] Error while reading FFmpeg stderr: {e}")
