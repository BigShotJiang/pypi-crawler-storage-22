import subprocess
import logging
import time
import os
import threading
from urllib.parse import urlparse
from ..util.EncoderSelector import EncoderSelector
from ..util.RTMPUrl import RTMPUrl

logger = logging.getLogger(__name__)

class RTSPtoRTMPStreamer:
    def __init__(self, rtsp_url, stream_key, fps=30, resolution="1280x720", duration=120):
        """
        Initialize the streamer.

        Args:
            rtsp_url (str): The RTSP stream URL (e.g., from an IP camera).
            rtmp_url (str): The RTMP server URL (without stream key).
            stream_key (str): The unique stream key for RTMP.
            fps (int): Frames per second for output stream.
            resolution (str): Resolution of the output stream.
            duration (int): Duration in seconds to stream.
        """
        self.rtsp_url = rtsp_url
        self.rtmp_url = RTMPUrl.get_publish_url(stream_key)
        self.fps = fps
        self.resolution = resolution
        self.duration = duration
        self.stream_key = stream_key
        self.process = None

    def _detect_stream_type(self, url):
        """Detect the type of input stream."""
        parsed_url = urlparse(url)
        return "rtsp" if parsed_url.scheme == "rtsp" else "unknown"
    
    def start_stream(self):
        """Start streaming RTSP to RTMP using FFmpeg without logs."""
        if self._detect_stream_type(self.rtsp_url) == "unknown":
            logger.error(f"❌ [APP] Invalid RTSP URL: {self.rtsp_url}")
            return

        logger.info(f"📡 [APP] Starting RTSP to RTMP stream: {self.rtsp_url} → {self.rtmp_url} for {self.duration} seconds")

        # Get optimal encoder for hardware
        encoder_args, encoder_name = EncoderSelector.get_encoder_args()
        logger.info(f"🎬 [APP] Using encoder: {encoder_name}")

        # FFmpeg command
        ffmpeg_command = [
            "ffmpeg",
            "-rtsp_transport", "tcp",  # 🚀 Use TCP
            "-fflags", "nobuffer",  # 🚀 Reduce internal buffering
            "-flags", "low_delay",  # 🚀 Enable low-latency mode
            "-strict", "experimental",
            "-i", self.rtsp_url,

            # Video encoding with optimal encoder
            *encoder_args,
            "-r", "25",  # ⏳ Limit FPS to 25
            "-b:v", "1500k",  # ✅ Bitrate
            "-maxrate", "2000k",  # ✅ Set max bitrate
            "-bufsize", "4000k",  # ✅ Reduce buffer latency
            "-g", "25",  # ✅ Reduce GOP size for faster keyframes
            "-vf", "scale='min(1024,iw)':-2",  # ✅ Resize width to max 1024px

            "-loglevel", "error",

            # ❌ Disable Audio (Avoid unnecessary encoding overhead)
            "-an",

            # ✅ Output RTMP Stream
            "-f", "flv",
            self.rtmp_url
        ]

        try:
            with open(os.devnull, "w") as devnull:
                self.process = subprocess.Popen(
                    ffmpeg_command,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.PIPE,
                    text=True,
                    bufsize=1
                )

                threading.Thread(
                    target=self._monitor_ffmpeg_errors,
                    daemon=True
                ).start()


            logger.info("✅ [APP] FFmpeg process started successfully.")

            start_time = time.time()
            while self.process.poll() is None:
                if time.time() - start_time > self.duration:
                    logger.info(f"⏳ [APP] Streaming duration {self.duration}s reached. Stopping stream...")
                    self.stop_stream()
                    break
                time.sleep(1)

        except Exception as e:
            logger.error(f"🚨 [APP] Failed to start FFmpeg: {e}")
            self.stop_stream()
    
    def stop_stream(self):
        """Stop the streaming process."""
        if self.process:
            self.process.terminate()
            self.process.wait()
            logger.info("FFmpeg process terminated.")


    def _monitor_ffmpeg_errors(self):
        for line in iter(self.process.stderr.readline, ''):
            if not line:
                break

            msg = line.strip()
            if not msg:
                continue

            error_type = self._classify_ffmpeg_error(msg)

            logger.error(f"🔥 [FFMPEG][{error_type}] {msg}")

            if error_type != "UNKNOWN_ERROR":
                logger.error("🛑 [APP] Critical streaming error, stopping FFmpeg.")
                self.stop_stream()
                break


    def _classify_ffmpeg_error(self, msg: str):
        if "rtsp" in msg.lower() and "connection" in msg.lower():
            return "RTSP_CONNECTION_ERROR"

        if "server returned" in msg.lower():
            return "RTMP_SERVER_ERROR"

        if "encoder" in msg.lower() or "nvenc" in msg.lower():
            return "ENCODER_ERROR"

        if "broken pipe" in msg.lower():
            return "PIPE_BROKEN"

        return "UNKNOWN_ERROR"
