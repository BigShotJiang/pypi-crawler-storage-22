from .adapter import EmailAdapter

__all__ = ["EmailAdapter"]