"""
Telegram 适配器
"""

from .adapter import TelegramAdapter

__all__ = ["TelegramAdapter"]
