"""Nekro Agent Sandbox - 纯运行时依赖环境"""
