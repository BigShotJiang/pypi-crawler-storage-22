"""
nellienano - A lightweight AI agent framework
"""

__version__ = "0.1.0"
__logo__ = "🐈"

# © 2026 NellieNano powered by VibeCaaS.com a division of NeuralQuantum.ai LLC. All rights reserved.
