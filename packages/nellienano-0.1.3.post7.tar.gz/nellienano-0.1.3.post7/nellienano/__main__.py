"""
Entry point for running nellienano as a module: python -m nellienano
"""

from nellienano.cli.commands import app

if __name__ == "__main__":
    app()

# © 2026 NellieNano powered by VibeCaaS.com a division of NeuralQuantum.ai LLC. All rights reserved.
