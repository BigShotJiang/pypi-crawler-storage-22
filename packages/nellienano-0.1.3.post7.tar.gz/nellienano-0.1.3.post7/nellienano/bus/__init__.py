"""Message bus module for decoupled channel-agent communication."""

from nellienano.bus.events import InboundMessage, OutboundMessage
from nellienano.bus.queue import MessageBus

__all__ = ["MessageBus", "InboundMessage", "OutboundMessage"]

# © 2026 NellieNano powered by VibeCaaS.com a division of NeuralQuantum.ai LLC. All rights reserved.
