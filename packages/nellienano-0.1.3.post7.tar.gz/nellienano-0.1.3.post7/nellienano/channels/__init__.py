"""Chat channels module with plugin architecture."""

from nellienano.channels.base import BaseChannel
from nellienano.channels.manager import ChannelManager

__all__ = ["BaseChannel", "ChannelManager"]

# © 2026 NellieNano powered by VibeCaaS.com a division of NeuralQuantum.ai LLC. All rights reserved.
