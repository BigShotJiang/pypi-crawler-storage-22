from NEMO.serializers import ModelSerializer
from NEMO.views.api import ModelViewSet, key_filters, manykey_filters, string_filters, date_filters
from rest_flex_fields import FlexFieldsModelSerializer

from NEMO_billing.institution_agreements.models import InstitutionAgreement


class InstitutionAgreementSerializer(FlexFieldsModelSerializer, ModelSerializer):
    class Meta:
        model = InstitutionAgreement
        fields = "__all__"
        expandable_fields = {
            "institution": "NEMO_billing.api.InstitutionSerializer",
            "core_facilities": ("NEMO_billing.api.CoreFacilitySerializer", {"many": True}),
            "owner": "NEMO.serializers.UserSerializer",
        }


class InstitutionAgreementViewSet(ModelViewSet):
    filename = "service_agreements"
    queryset = InstitutionAgreement.objects.all()
    serializer_class = InstitutionAgreementSerializer
    filterset_fields = {
        "id": key_filters,
        "agreement_id": string_filters,
        "name": string_filters,
        "institution": key_filters,
        "core_facilities": manykey_filters,
        "start_date": date_filters,
        "expiration_date": date_filters,
        "reminder_date": date_filters,
        "owner": key_filters,
        "point_of_contact_name": string_filters,
        "point_of_contact_email": string_filters,
    }
