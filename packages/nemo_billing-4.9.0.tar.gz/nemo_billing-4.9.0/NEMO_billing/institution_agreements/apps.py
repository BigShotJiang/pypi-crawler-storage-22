from django.apps import AppConfig


class NEMOInstitutionAgreementsConfig(AppConfig):
    name = "NEMO_billing.institution_agreements"
    verbose_name = "Billing Service Agreements"
    default_auto_field = "django.db.models.AutoField"

    def ready(self):
        pass
