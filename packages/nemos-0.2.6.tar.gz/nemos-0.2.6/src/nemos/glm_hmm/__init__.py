"""GLM-HMM module."""

from .expectation_maximization import backward_pass, forward_backward, forward_pass
