"""Style for plotting."""

import importlib.resources as _pkg_resources

plot_style = _pkg_resources.files(__package__) / "nemos.mplstyle"
