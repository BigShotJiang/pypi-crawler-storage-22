# nemotron-quick

Just run `nemotron-quick "Your prompt here"`
