# Changelog

All notable changes to **temp-logger** will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.1.11] — 2026-02-08

## [0.1.10] — 2026-02-07

## [0.1.9] — 2026-02-07

## [0.1.8] — 2026-02-07

## [0.1.7] — 2026-02-07

## [0.1.6] — 2026-02-07

## [0.1.5] — 2026-02-07

## [0.1.4] — 2026-02-07

## [0.1.3] — 2026-02-07

### Added

- `pid-controller-gui` — PID temperature controller GUI with ramp control, tuning,
  TEC power monitoring, and live graphs.
- `scpi-client` — Interactive SCPI terminal with tab-completion, command history,
  pretty-printed output, and OPC synchronization.
- WiFi/TCP support across all four tools (auto-discovery, `wifi_config.txt`).
- `--version` flag on all entry points.
- Dark theme for `temp-logger-gui`.
- Dual-sensor synchronised logging with timing-skew subplot.

### Fixed

- Cross-talk between GUI logger and SCPI console (threading lock).
- Graph reset timing after reconnect.
- TCP server `max_clients=1` on firmware side.
- macOS soft-reboot prevention in `boot.py`.
- WiFi discover retry and serial drain logic.

## [0.1.0] — 2025-12-01

### Added

- Initial release with `temp-logger` CLI and `temp-logger-gui`.
- CSV logging with automatic timestamped filenames.
- Live matplotlib plots (4 subplots for dual sensor).
- Auto-detection of single vs. dual sensor mode.
- USB serial connection via `SCPISerial`.

[Unreleased]: https://gitlab.flavio.be/flavio/temp-logger/-/compare/v0.1.11...HEAD
[0.1.11]: https://gitlab.flavio.be/flavio/temp-logger/-/compare/v0.1.10...v0.1.11[0.1.10]: https://gitlab.flavio.be/flavio/temp-logger/-/compare/v0.1.9...v0.1.10[0.1.9]: https://gitlab.flavio.be/flavio/temp-logger/-/compare/v0.1.8...v0.1.9[0.1.8]: https://gitlab.flavio.be/flavio/temp-logger/-/compare/v0.1.7...v0.1.8[0.1.7]: https://gitlab.flavio.be/flavio/temp-logger/-/compare/v0.1.6...v0.1.7[0.1.6]: https://gitlab.flavio.be/flavio/temp-logger/-/compare/v0.1.5...v0.1.6[0.1.5]: https://gitlab.flavio.be/flavio/temp-logger/-/compare/v0.1.4...v0.1.5[0.1.4]: https://gitlab.flavio.be/flavio/temp-logger/-/compare/v0.1.3...v0.1.4[0.1.3]: <https://gitlab.flavio.be/flavio/temp-logger/-/compare/v0.1.2...v0.1.3[0.1.2>]: <https://gitlab.flavio.be/flavio/temp-logger/-/compare/v0.1.1...v0.1.2[0.1.1>]: <https://gitlab.flavio.be/flavio/temp-logger/-/compare/v0.1.0...v0.1.1>
[0.1.0]: <https://gitlab.flavio.be/flavio/temp-logger/-/releases/v0.1.0>
