# WiFi Support Implementation Summary

## Overview

Added WiFi/TCP connectivity support to the TMP117 Temperature Logger applications, allowing simultaneous data logging via WiFi while keeping USB port available for SCPI commands.

## Changes Made

### 1. New Module: `scpi_universal.py`

**Location**: `TMP117/Python/temp-logger/src/temp_logger/tools/myserial/scpi_universal.py`

**Purpose**: Unified SCPI interface supporting both Serial (USB) and WiFi/TCP connections

**Key Classes**:

- `TCPSocket`: Socket wrapper mimicking serial.Serial interface for TCP connections
- `SCPIUniversal`: Main interface class with automatic connection detection

**Features**:

- Auto-discovers WiFi IP address by querying `:WIFI:IP?` and `:WIFI:CONNECTED?` via USB
- Intelligent connection fallback: WiFi → USB or USB → WiFi (configurable)
- Same interface as `SCPISerial` for drop-in replacement
- Context manager support (`with` statement)
- OPC synchronization for reliable command completion

**Connection Logic**:

```python
if prefer_wifi:
    1. Try provided WiFi host (if given)
    2. Try auto-discovered WiFi IP (via USB query)
    3. Fall back to USB serial
else:
    1. Try USB serial
    2. Try provided WiFi host (if given)  
    3. Try auto-discovered WiFi IP
```

### 2. Updated: `pc_realtime_logger.py`

**Location**: `TMP117/Python/temp-logger/src/temp_logger/pc_realtime_logger.py`

**Changes**:

- Replaced `SCPISerial` import with `SCPIUniversal`
- Added WiFi parameters to `TemperatureLogger.__init__()`:
  - `wifi_host`: WiFi IP address (optional)
  - `wifi_port`: WiFi TCP port (default 5025)
  - `prefer_wifi`: Connection priority (default True)
- Simplified `connect()` method - now delegates to `SCPIUniversal`
- Updated `main()` function with new command-line arguments:
  - `--wifi IP[:PORT]` or `-w IP[:PORT]`: Force WiFi connection
  - `--port PORT` or `-p PORT`: Force USB connection
  - `--prefer-usb`: Try USB first (instead of WiFi)

**Backward Compatibility**: Existing usage still works (auto-detects connection type)

### 3. Updated: `gui_realtime_logger.py`

**Location**: `TMP117/Python/temp-logger/src/temp_logger/gui_realtime_logger.py`

**Changes**:

- Added "Connection Type" dropdown with 4 options:
  - "Auto (WiFi → USB)" - Default, tries WiFi first
  - "Auto (USB → WiFi)" - Tries USB first
  - "Force WiFi" - WiFi only (shows IP input field)
  - "Force USB" - USB only (shows port selection)
- Dynamic UI: Shows/hides WiFi IP and USB port fields based on selection
- Updated `_start_logging()` to parse connection settings and pass to logger
- Updated widget enable/disable logic for new fields
- Connection type callback: `_on_connection_type_changed()`

**UI Layout**:

```txt
Configuration Panel:
├── Connection: [Dropdown]
├── WiFi IP: [Text Entry] (conditional)
├── Serial Port: [Dropdown] (conditional)
├── Output File: [Text Area]
├── Max Points: [Spinbox]
├── AVG Level: [Dropdown]
└── Graph Scale: [Spinbox]
```

### 4. New Documentation: `WIFI_SUPPORT.md`

**Location**: `TMP117/Python/temp-logger/WIFI_SUPPORT.md`

**Contents**:

- Feature overview
- Command-line usage examples
- GUI usage guide
- Connection options explained
- WiFi auto-discovery details
- Use cases and troubleshooting
- Technical implementation details

## Usage Examples

### Command-Line

```bash
# Auto-detect (WiFi → USB priority)
temp-logger

# Prefer USB over WiFi
temp-logger --prefer-usb

# Force WiFi
temp-logger --wifi 192.168.132.123

# Force WiFi with custom port
temp-logger --wifi 192.168.132.123:5555

# Force USB
temp-logger --port /dev/cu.usbmodem2101

# With output file
temp-logger --prefer-usb --output my_log.csv

# Disable plotting
temp-logger --wifi 192.168.132.123 --no-plot
```

### GUI

1. **Default (Auto WiFi→USB)**:
   - Select "Auto (WiFi → USB)"
   - Click START
   - Logger auto-discovers and connects

2. **Force WiFi**:
   - Select "Force WiFi"
   - Enter IP: "192.168.132.123"
   - Click START

3. **Force USB**:
   - Select "Force USB"
   - Select port (or Auto-detect)
   - Click START

## Key Benefits

1. **Simultaneous USB + WiFi Use**:
   - Log data via WiFi (TCP port 5025)
   - Send SCPI commands via USB
   - No port conflicts

2. **Automatic Discovery**:
   - No manual IP configuration needed
   - Queries device for WiFi status and IP
   - Seamless WiFi adoption

3. **Intelligent Fallback**:
   - Tries multiple connection methods
   - Graceful degradation
   - Always connects if any method works

4. **Backward Compatible**:
   - Existing scripts work unchanged
   - Default behavior: auto-detect
   - No breaking changes

## Technical Details

### SCPI Commands Used

- `:WIFI:CONNECTED?` - Returns "1" if WiFi connected, "0" otherwise
- `:WIFI:IP?` - Returns IP address string (e.g., "192.168.1.100")

### Connection Timeout

- Default: 1.0 second
- Configurable via `timeout` parameter
- Adjusted for AVG level in logger (0.2-1.2s)

### TCP Socket Implementation

- Uses Python `socket` module
- Port 5025 (standard SCPI-over-TCP)
- Mimics `serial.Serial` interface for compatibility
- Implements: `write()`, `readline()`, `reset_input_buffer()`, `in_waiting`

### Thread Safety

- `SCPIUniversal` is thread-safe (same as `SCPISerial`)
- GUI uses threading for background logging
- Command-line logger uses data collection thread

## Testing Recommendations

1. **Test Auto-Discovery**:

   ```bash
   # With device connected via USB and WiFi enabled
   temp-logger
   # Should auto-discover WiFi IP and connect via TCP
   ```

2. **Test Force WiFi**:

   ```bash
   # Disconnect USB, use WiFi only
   temp-logger --wifi 192.168.132.123
   ```

3. **Test Force USB**:

   ```bash
   # Disable WiFi on device
   temp-logger --prefer-usb
   ```

4. **Test Simultaneous Use**:

   ```bash
   # Terminal 1: Start logger via WiFi
   temp-logger --wifi 192.168.132.123
   
   # Terminal 2: Send commands via USB
   cd ../../
   scpi-client ":PID:STAT?"
   ```

## Files Modified

- ✅ `TMP117/Python/temp-logger/src/temp_logger/tools/myserial/scpi_universal.py` (NEW)
- ✅ `TMP117/Python/temp-logger/src/temp_logger/pc_realtime_logger.py` (MODIFIED)
- ✅ `TMP117/Python/temp-logger/src/temp_logger/gui_realtime_logger.py` (MODIFIED)
- ✅ `TMP117/Python/temp-logger/WIFI_SUPPORT.md` (NEW)

## Next Steps

1. Test WiFi auto-discovery with device
2. Test GUI connection type switching
3. Verify simultaneous USB command + WiFi logging
4. Update main README with WiFi feature mention
5. Consider adding WiFi status indicator to GUI status bar

## Known Limitations

1. WiFi auto-discovery requires temporary USB connection
   - Opens USB briefly to query `:WIFI:IP?`
   - Closes USB before opening WiFi
   - Very fast (< 1 second)

2. No auto-retry on WiFi disconnection
   - If WiFi drops, logging stops
   - User must restart logger
   - Future: Add reconnection logic

3. GUI doesn't remember last connection type
   - Defaults to "Auto (WiFi → USB)" on startup
   - Future: Save preference to config file

## Implementation Notes

- All syntax checks passed ✓
- Backward compatible with existing code ✓
- No external dependencies added (uses standard library `socket`) ✓
- Thread-safe for GUI multi-threading ✓
- Context manager support for resource cleanup ✓
