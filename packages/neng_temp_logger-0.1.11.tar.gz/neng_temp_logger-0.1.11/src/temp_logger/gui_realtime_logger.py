"""Enhanced GUI Application for Real-time Temperature Data Logger with Embedded Plots.

Provides a professional tkinter interface with embedded matplotlib plots for live
temperature visualization.

Features:
- Real-time dual/single sensor temperature monitoring
- Embedded live temperature and difference plots
- Data logging to CSV with configurable sampling rates
- Pre-flight sensor detection and validation
- Dark-themed professional UI with green/dark color scheme
- Information panel with read-only logging output
- Copy/Clear buttons for log management

Known Refinements/TODOs:
- Info panel currently displays all text in white (monochrome)
  - Colored text support explored with tkinterweb/HtmlFrame but had rendering issues
  - Future: Re-implement color coding (green for success, red for errors, orange for warnings)
- Auto-detect port selection uses filtered USB port list (excludes Bluetooth devices)
- Sensor re-detection monitoring loop removed to prevent parsing interference
- Data validation includes range checking (-50 to +150°C) and sanity checks
- Buffer auto-reset on consecutive read errors (5 threshold) with auto-recovery

(c) 2025-26 Prof. Flavio ABREU ARAUJO. All rights reserved.
"""

from __future__ import annotations

import contextlib
import threading
import time
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

import matplotlib.animation as animation  # type: ignore
import matplotlib.gridspec as gridspec  # type: ignore
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg  # type: ignore
from matplotlib.figure import Figure  # type: ignore

from . import __version__
from .pc_realtime_logger import TemperatureLogger
from .tools.myserial.scpi_serial import SCPISerial

# Graph scaling factor - adjust text sizes in plots
TEXT_SCALE = 1.4  # 1.0 = default, 1.2 = 20% larger, 1.5 = 50% larger, etc.


class TemperatureLoggerGUIEnhanced:
    """Enhanced GUI Application with Live Plots."""

    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        self.root.title("Real-time Temperature Logger (© 2026 Prof. Flavio ABREU ARAUJO)")
        self.root.geometry("1200x800")
        self.root.resizable(True, True)

        self.logger: TemperatureLogger | None = None
        self.logger_thread: threading.Thread | None = None
        self.is_running = False
        self.plot_interval_ms = 200  # Default plot update interval in milliseconds
        self.text_scale = 1.4  # Graph text scaling factor (1.4 = default)

        # Color scheme
        self.BG_COLOR = "#2b2b2b"
        self.FG_COLOR = "#ffffff"
        self.ACCENT_COLOR = "#0078d4"
        self.SUCCESS_COLOR = "#107c10"
        self.ERROR_COLOR = "#d83b01"

        self.root.configure(bg=self.BG_COLOR)

        # Configure style
        self._setup_styles()

        # Create GUI layout
        self._create_widgets()

    def _scan_ports(self) -> list[str]:
        """Scan for available serial/USB ports (CircuitPython compatible).

        Filters out Bluetooth and other non-USB serial ports.
        """
        ports = ["Auto-detect"]
        try:
            import serial.tools.list_ports  # type: ignore
            for port in serial.tools.list_ports.comports():
                # Only include USB and serial ports, exclude Bluetooth
                device = port.device

                # Filter for CircuitPython compatible ports ONLY
                if device.startswith("/dev/cu.usbmodem") or \
                   device.startswith("/dev/cu.usbserial") or \
                   device.startswith("/dev/ttyUSB") or \
                   device.startswith("/dev/ttyACM") or \
                   device.startswith("COM"):
                    ports.append(device)
        except Exception:
            # Fallback to common port names if scanning fails
            import platform
            if platform.system() == "Darwin":  # macOS
                import glob
                ports.extend(glob.glob("/dev/cu.usbmodem*"))
                ports.extend(glob.glob("/dev/cu.usbserial*"))
            elif platform.system() == "Linux":
                import glob
                ports.extend(glob.glob("/dev/ttyUSB*"))
                ports.extend(glob.glob("/dev/ttyACM*"))
            elif platform.system() == "Windows":
                ports.extend([f"COM{i}" for i in range(1, 9)])

        # Remove duplicates while preserving order
        seen = set()
        unique_ports = []
        for port in ports:
            if port not in seen:
                seen.add(port)
                unique_ports.append(port)
        return unique_ports

    def _seconds_to_mmss(self, seconds: float) -> str:
        """Convert seconds to mm:ss format."""
        minutes = int(seconds) // 60
        secs = int(seconds) % 60
        return f"{minutes:02d}:{secs:02d}"

    def _get_elapsed_times(self) -> list[str]:
        """Get list of elapsed time strings from start of logging."""
        if not self.logger or not self.logger.timestamps:
            return []

        start_timestamp = self.logger.timestamps[0]
        elapsed_times = []
        for ts in self.logger.timestamps:
            elapsed = ts - start_timestamp
            elapsed_times.append(self._seconds_to_mmss(elapsed))
        return elapsed_times

    def _timestamp_to_hhmmss(self, timestamp: float) -> str:
        """Convert Unix timestamp to HH:MM:SS format."""
        import time
        return time.strftime('%H:%M:%S', time.localtime(timestamp))

    def _get_clock_times(self) -> list[str]:
        """Get list of clock time strings based on actual elapsed time from logging start.

        Uses the elapsed time values stored in logger.timestamps, which are already
        elapsed seconds from when logging started. Converts to compact format:
        - 0:05 for 5 seconds
        - 1:23 for 1 minute 23 seconds
        - 45:30 for 45 minutes 30 seconds

        Time continuously increments as new data arrives, even when data window wraps.
        """
        if not self.logger or not self.logger.timestamps:
            return []

        clock_times = []
        for elapsed_seconds in self.logger.timestamps:
            # elapsed_seconds is already the elapsed time from logging start
            minutes = int(elapsed_seconds) // 60
            seconds = int(elapsed_seconds) % 60
            time_str = f"{minutes}:{seconds:02d}"
            clock_times.append(time_str)

        return clock_times

    def _setup_styles(self) -> None:
        """Configure ttk styles."""
        style = ttk.Style()
        style.theme_use("clam")

        # Configure colors
        style.configure("TFrame", background=self.BG_COLOR)
        style.configure("TLabel", background=self.BG_COLOR, foreground=self.FG_COLOR)
        style.configure("TEntry", fieldbackground="#3c3c3c", foreground=self.FG_COLOR)
        style.configure("TButton", background=self.ACCENT_COLOR, foreground=self.FG_COLOR)
        style.map(
            "TButton",
            background=[("active", "#005a9e"), ("disabled", "#4a4a4a")],
        )

        # Configure label style for control panel (no background, black text)
        style.configure("Control.TLabel", background="#DDDDDD", foreground="#000000")

        # Configure green button style for START
        style.configure("Green.TButton", background="#556B2F", foreground=self.FG_COLOR)
        style.map(
            "Green.TButton",
            background=[("active", "#6B8E23"), ("disabled", "#4a4a4a")],
        )

        # Configure red button style for STOP
        style.configure("Red.TButton", background="#8B0000", foreground=self.FG_COLOR)
        style.map(
            "Red.TButton",
            background=[("active", "#DC143C"), ("disabled", "#4a4a4a")],
        )

    def _create_widgets(self) -> None:
        """Create GUI widgets."""
        # ========== BOTTOM STATUS BAR (pack first so it reserves space) ==========
        status_frame = ttk.Frame(self.root, relief=tk.SUNKEN, borderwidth=1)
        status_frame.pack(fill=tk.X, side=tk.BOTTOM)

        self.status_label = ttk.Label(
            status_frame,
            text="Ready",
            foreground=self.SUCCESS_COLOR,
            font=("Arial", 9),
        )
        self.status_label.pack(side=tk.LEFT, padx=10, pady=3)

        self.point_count_label = ttk.Label(
            status_frame,
            text=f"Points: 0  |  Sensors: -  |  Mode: -  |  v{__version__}",
            font=("Arial", 9),
        )
        self.point_count_label.pack(side=tk.RIGHT, padx=10, pady=3)

        # Top frame for main content (config/controls left, plots right)
        content_frame = ttk.Frame(self.root)
        content_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        # ========== LEFT PANEL: Configuration and Controls ==========
        left_panel = ttk.Frame(content_frame)
        left_panel.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 5))

        # Header
        header = ttk.Label(
            left_panel,
            text="Temperature Logger",
            font=("Arial", 14, "bold"),
        )
        header.pack(pady=(0, 15))

        # Configuration Panel
        config_frame = ttk.LabelFrame(left_panel, text="Configuration", padding=10)
        config_frame.pack(fill=tk.X, pady=(0, 10))

        # Connection type selection
        ttk.Label(config_frame, text="Connection:", style="Control.TLabel").grid(
            row=0, column=0, sticky=tk.W, pady=8
        )
        self.conn_type_var = tk.StringVar(value="Force USB")
        self.conn_type_combo = ttk.Combobox(
            config_frame,
            textvariable=self.conn_type_var,
            values=["Auto (WiFi → USB)", "Auto (USB → WiFi)", "Force WiFi", "Force USB"],
            state="readonly",
            width=22,
        )
        self.conn_type_combo.grid(row=0, column=1, columnspan=2, sticky=tk.W, padx=5)
        self.conn_type_combo.bind("<<ComboboxSelected>>", self._on_connection_type_changed)

        # WiFi IP address (conditionally visible)
        self.wifi_label = ttk.Label(config_frame, text="WiFi IP:", style="Control.TLabel")
        self.wifi_label.grid(row=1, column=0, sticky=tk.W, pady=8)
        self.wifi_ip_var = tk.StringVar(value="")
        self.wifi_entry = ttk.Entry(config_frame, textvariable=self.wifi_ip_var, width=20)
        self.wifi_entry.grid(row=1, column=1, sticky=tk.W, padx=5)

        # Add "Discover" button to auto-detect WiFi IP via USB
        self.discover_wifi_btn = ttk.Button(
            config_frame,
            text="🔍 Discover",
            command=self._discover_wifi_ip,
            style="TButton",
            width=10
        )
        self.discover_wifi_btn.grid(row=1, column=2, sticky=tk.W, padx=5)

        # Initially hidden (shown when Force WiFi selected)
        self.wifi_label.grid_remove()
        self.wifi_entry.grid_remove()
        self.discover_wifi_btn.grid_remove()

        # USB Port selection (conditionally visible)
        self.port_label = ttk.Label(config_frame, text="Serial Port:", style="Control.TLabel")
        self.port_label.grid(row=2, column=0, sticky=tk.W, pady=8)
        self.port_var = tk.StringVar(value="Auto-detect")
        self.port_combo = ttk.Combobox(
            config_frame,
            textvariable=self.port_var,
            values=self._scan_ports(),
            state="readonly",
            width=24,
        )
        self.port_combo.grid(row=2, column=1, sticky=tk.W, padx=5)
        self.refresh_ports_btn = ttk.Button(config_frame, text="↻", command=self._refresh_ports, width=2)
        self.refresh_ports_btn.grid(row=2, column=2, padx=2)
        # USB port widgets visible by default (Force USB is default connection)

        # Output file (spans 3 rows)
        ttk.Label(config_frame, text="Output File:", style="Control.TLabel").grid(
            row=3, column=0, sticky=tk.NW, pady=8
        )
        self.output_var = tk.StringVar(value="tmp117_log.csv")
        self.output_entry = tk.Text(
            config_frame,
            height=3,
            width=26,
            wrap=tk.WORD,
            relief=tk.SUNKEN,
            bd=1,
            bg="#ffffff",
            fg="#000000",
            font=("Arial", 9),
        )
        self.output_entry.grid(row=3, column=1, rowspan=3, sticky=tk.NSEW, padx=5)
        # Insert default text
        self.output_entry.insert("1.0", "tmp117_log.csv")
        self.browse_btn = ttk.Button(config_frame, text="...", command=self._browse_file, width=3)
        self.browse_btn.grid(row=3, column=2, padx=2)

        # Max data points
        ttk.Label(config_frame, text="Max Points:", style="Control.TLabel").grid(row=6, column=0, sticky=tk.W, pady=8)
        self.max_points_var = tk.StringVar(value="1501")
        self.max_points_spinbox = ttk.Spinbox(
            config_frame,
            from_=11,
            to=5001,
            textvariable=self.max_points_var,
            width=10,
        )
        self.max_points_spinbox.grid(row=6, column=1, sticky=tk.W, padx=5)

        # AVG level for SENS:SYNC
        ttk.Label(config_frame, text="AVG Level:", style="Control.TLabel").grid(row=7, column=0, sticky=tk.W, pady=8)
        self.avg_level_var = tk.StringVar(value="8 (Default, ~200ms/pt)")
        self.avg_level_combo = ttk.Combobox(
            config_frame,
            textvariable=self.avg_level_var,
            values=[
                "1 (Fast, ~120ms/pt)",
                "8 (Default, ~200ms/pt)",
                "32 (Precise, ~575ms/pt)",
                "64 (Very Precise, ~1.065s/pt)",
            ],
            state="readonly",
            width=22,
        )
        self.avg_level_combo.grid(row=7, column=1, sticky=tk.W, padx=5)

        # Graph scale factor
        ttk.Label(config_frame, text="Graph Scale:", style="Control.TLabel").grid(row=8, column=0, sticky=tk.W, pady=8)
        self.scale_var = tk.StringVar(value="1.4")
        self.scale_spinbox = ttk.Spinbox(
            config_frame,
            from_=0.8,
            to=2.0,
            increment=0.1,
            textvariable=self.scale_var,
            width=10,
            command=self._on_scale_changed,
        )
        self.scale_spinbox.grid(row=8, column=1, sticky=tk.W, padx=5)

        # Control Panel
        control_frame = ttk.LabelFrame(left_panel, text="Control", padding=10)
        control_frame.pack(fill=tk.X, pady=(0, 10))

        self.start_btn = ttk.Button(
            control_frame,
            text="▶ START",
            command=self._start_logging,
            style="Green.TButton",
        )
        self.start_btn.pack(side=tk.TOP, fill=tk.X, pady=(0, 5))

        self.stop_btn = ttk.Button(
            control_frame,
            text="⏹ STOP",
            command=self._stop_logging,
            style="Red.TButton",
            state=tk.DISABLED,
        )
        self.stop_btn.pack(side=tk.TOP, fill=tk.X)

        # SCPI Command Panel
        scpi_frame = ttk.LabelFrame(left_panel, text="SCPI Command", padding=10)
        scpi_frame.pack(fill=tk.X, pady=(0, 10))

        # Command entry with history
        self.scpi_entry = ttk.Entry(scpi_frame, width=30)
        self.scpi_entry.pack(fill=tk.X, pady=(0, 5))
        self.scpi_entry.bind('<Return>', self._send_scpi_command)
        self.scpi_entry.bind('<Up>', self._scpi_history_prev)
        self.scpi_entry.bind('<Down>', self._scpi_history_next)

        # Send button
        self.scpi_send_btn = ttk.Button(
            scpi_frame,
            text="📤 Send",
            command=self._send_scpi_command,
        )
        self.scpi_send_btn.pack(fill=tk.X)

        # SCPI command history
        self._scpi_history: list[str] = []
        self._scpi_history_index = 0

        # Common commands hint
        hint_label = ttk.Label(
            scpi_frame,
            text="e.g. *IDN?, :PID:STAT?, :PID:SETP 25",
            font=("Arial", 8),
            foreground="#888888",
        )
        hint_label.pack(pady=(5, 0))

        # Info Panel
        info_frame = ttk.LabelFrame(left_panel, text="Information", padding=10)
        info_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))

        # Text widget - simple and reliable white-on-black display
        self.info_text = tk.Text(
            info_frame,
            height=15,
            width=35,
            bg="#1e1e1e",
            fg="#ffffff",
            font=("Courier", 9),
            state=tk.DISABLED,  # Read-only
        )
        self.info_text.pack(fill=tk.BOTH, expand=True, pady=(0, 5))
        self.html_mode = False

        # Initialize with starting messages
        self._add_info("Temperature Logger Ready\n")
        self._add_info("Click START to begin\n")
        self._add_info("=" * 35 + "\n")

        # Button frame for actions
        button_frame = ttk.Frame(info_frame)
        button_frame.pack(fill=tk.X, pady=(5, 0))

        self.copy_btn = ttk.Button(button_frame, text="📋 Copy", command=self._copy_info, width=12)
        self.copy_btn.pack(side=tk.LEFT, padx=2)

        self.clear_btn = ttk.Button(button_frame, text="🗑 Clear", command=self._clear_info, width=12)
        self.clear_btn.pack(side=tk.LEFT, padx=2)

        # ========== RIGHT PANEL: Plots ==========
        right_panel = ttk.Frame(content_frame)
        right_panel.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        # Create matplotlib figure with 2 subplots
        self.fig = Figure(figsize=(8, 7), dpi=100)
        gs = gridspec.GridSpec(2, 1, figure=self.fig, hspace=0.05)
        self.fig.subplots_adjust(left=0.14, right=0.98, top=0.98, bottom=0.08)

        # Top subplot: Both temperatures
        self.ax_temps = self.fig.add_subplot(gs[0])
        self.ax_temps.set_ylabel('Temperature (°C)', fontsize=int(10 * self.text_scale))
        # self.ax_temps.set_xlabel('Time (HH:MM:SS)', fontsize=int(10 * self.text_scale))
        self.ax_temps.tick_params(labelsize=int(9 * self.text_scale))
        self.ax_temps.grid(True, alpha=0.3)
        self.line_temp1, = self.ax_temps.plot([], [], 'b-', label='Sensor 1 ($T_1$)', linewidth=2)
        self.line_temp2, = self.ax_temps.plot([], [], 'r-', label='Sensor 2 ($T_2$)', linewidth=2)
        self.ax_temps.legend(loc='best', ncol=2, fontsize=int(9 * self.text_scale))
        # Hide x-axis labels and ticks for upper graph
        self.ax_temps.set_xticklabels([])
        # self.ax_temps.set_xticks([])

        # Bottom subplot: Difference
        self.ax_diff = self.fig.add_subplot(gs[1])
        self.ax_diff.set_ylabel(r'$\Delta T = T_1 - T_2$ (°C)', fontsize=int(10 * self.text_scale))
        self.ax_diff.set_xlabel('Elapsed Time (m:ss)', fontsize=int(10 * self.text_scale))
        self.ax_diff.tick_params(labelsize=int(9 * self.text_scale))
        self.ax_diff.grid(True, alpha=0.3)
        self.line_diff, = self.ax_diff.plot([], [], 'g-', linewidth=2)

        # Embed matplotlib in tkinter
        self.canvas = FigureCanvasTkAgg(self.fig, master=right_panel)
        self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)

        # Connect figure close event to stop logging
        self.fig.canvas.mpl_connect('close_event', self._on_figure_close)

        # Initialize plot interval from GUI (will be updated when logging starts)
        self.plot_interval_ms = 200

        # Start animation
        self.ani = animation.FuncAnimation(
            self.fig,
            self._update_plots,
            interval=self.plot_interval_ms,
            blit=False,
            cache_frame_data=False,
            repeat=True,  # Explicitly set repeat to continue animation loop
        )
        # Draw initial frame to prevent "Animation was deleted without rendering" warning
        self.canvas.draw_idle()

    def _browse_file(self) -> None:
        """Open file browser for output file selection."""
        current_text = self.output_entry.get("1.0", tk.END).strip()
        filename = filedialog.asksaveasfilename(
            defaultextension=".csv",
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")],
            initialfile=current_text,
        )
        if filename:
            self.output_entry.delete("1.0", tk.END)
            self.output_entry.insert("1.0", filename)

    def _refresh_ports(self) -> None:
        """Refresh the list of available serial ports."""
        ports = self._scan_ports()
        self.port_combo.config(values=ports)
        # Keep current selection if it's still available, otherwise reset
        if self.port_var.get() not in ports:
            self.port_var.set("Auto-detect")

    def _on_connection_type_changed(self, event=None) -> None:
        """Handle connection type selection change."""
        conn_type = self.conn_type_var.get()

        if conn_type == "Force WiFi":
            # Show WiFi field, hide USB field
            self.wifi_label.grid()
            self.wifi_entry.grid()
            self.discover_wifi_btn.grid()
            self.port_label.grid_remove()
            self.port_combo.grid_remove()
            self.refresh_ports_btn.grid_remove()
        elif conn_type == "Force USB":
            # Show USB field, hide WiFi field
            self.port_label.grid()
            self.port_combo.grid()
            self.refresh_ports_btn.grid()
            self.wifi_label.grid_remove()
            self.wifi_entry.grid_remove()
            self.discover_wifi_btn.grid_remove()
        else:
            # Auto modes - hide both fields (will auto-detect)
            # Clear WiFi IP field so it doesn't interfere with auto-detection
            # (Keep the value but don't use it in Auto mode)
            self.wifi_label.grid_remove()
            self.wifi_entry.grid_remove()
            self.discover_wifi_btn.grid_remove()
            self.port_label.grid_remove()
            self.port_combo.grid_remove()
            self.refresh_ports_btn.grid_remove()

    def _discover_wifi_ip(self) -> None:
        """Auto-discover WiFi IP address via USB connection."""
        self._add_info("🔍 Discovering WiFi IP via USB...\n")
        self.discover_wifi_btn.config(state=tk.DISABLED, text="⏳ Discovering...")

        def _is_valid_ip(s: str) -> bool:
            """Check if string looks like a valid IPv4 address."""
            parts = s.split(".")
            if len(parts) != 4:
                return False
            for p in parts:
                try:
                    n = int(p)
                    if n < 0 or n > 255:
                        return False
                except ValueError:
                    return False
            return True

        def _do_discover():
            try:
                import serial.tools.list_ports  # type: ignore

                # Find available USB serial ports
                ports = [p.device for p in serial.tools.list_ports.comports()
                        if 'usb' in p.device.lower() or 'acm' in p.device.lower()
                        or 'usbmodem' in p.device.lower() or 'usbserial' in p.device.lower()]

                if not ports:
                    self._add_info("❌ No USB serial ports found. Connect device via USB first.\n")
                    self.discover_wifi_btn.config(state=tk.NORMAL, text="🔍 Discover")
                    return

                # Try each port
                wifi_ip = None
                wifi_connected = False

                for port in ports:
                    try:
                        self._add_info(f"  Trying {port}...\n")

                        # Connect via USB
                        with SCPISerial(port=port, timeout=2.0, sync_mode=True) as ser:
                            # Check if WiFi is connected
                            connected_resp = ser.query(":WIFI:CONNECTED?").strip()
                            if connected_resp.upper() in ['1', 'TRUE', 'YES', 'CONNECTED']:
                                wifi_connected = True

                                # Get WiFi IP
                                ip_resp = ser.query(":WIFI:IP?").strip()
                                if ip_resp and ip_resp != "0.0.0.0" and _is_valid_ip(ip_resp):
                                    wifi_ip = ip_resp
                                    self._add_info(f"✓ Found WiFi IP: {wifi_ip}\n")
                                    break
                                elif ip_resp:
                                    self._add_info(f"  ⚠ Invalid IP response: {ip_resp[:40]}\n")
                            else:
                                self._add_info("  WiFi not connected on this device\n")

                    except Exception as e:
                        self._add_info(f"  Failed: {e}\n")
                        continue

                # Update UI with result
                if wifi_ip:
                    self.wifi_ip_var.set(wifi_ip)
                    self._add_info(f"✓ WiFi IP populated: {wifi_ip}\n")
                elif wifi_connected:
                    self._add_info("❌ WiFi connected but no IP address available\n")
                else:
                    self._add_info("❌ WiFi not connected. Enable WiFi on device first.\n")
                    self._add_info("   Hint: Use :WIFI:ENABLE 1 command\n")

            except Exception as e:
                self._add_info(f"❌ Discovery failed: {e}\n")
            finally:
                self.discover_wifi_btn.config(state=tk.NORMAL, text="🔍 Discover")

        # Run discovery in background thread
        threading.Thread(target=_do_discover, daemon=True).start()

    def _add_info(self, text: str, tag: str = "default") -> None:
        """Add text to info display (thread-safe).

        Args:
            text: Text to add
            tag: Ignored - all text displays in white
        """
        print(text, end="")  # Also print to console for debugging

        def _do_add():
            try:
                # Check if widget still exists (may have been destroyed)
                if not self.info_text.winfo_exists():
                    return

                # Temporarily enable editing to insert text
                self.info_text.config(state=tk.NORMAL)
                # Insert text at end
                self.info_text.insert(tk.END, text)
                self.info_text.see(tk.END)  # Auto-scroll to bottom
                # Disable editing again
                self.info_text.config(state=tk.DISABLED)
            except tk.TclError:
                # Widget was destroyed, silently ignore
                pass

        # Schedule GUI update on main thread (thread-safe)
        with contextlib.suppress(Exception):
            self.root.after(0, _do_add)

    def _copy_info(self) -> None:
        """Copy all info text to clipboard."""
        try:
            content = self.info_text.get("1.0", tk.END)
            self.root.clipboard_clear()
            self.root.clipboard_append(content)
            self._add_info("✓ Info text copied to clipboard!\n")
        except Exception as e:
            self._add_info(f"❌ Failed to copy text: {e}\n")

    def _clear_info(self) -> None:
        """Clear all info text."""
        self.info_text.config(state=tk.NORMAL)
        self.info_text.delete("1.0", tk.END)
        self.info_text.config(state=tk.DISABLED)
        self._add_info("✓ Information panel cleared\n")

    def _reset_plots(self) -> None:
        """Reset plots and clear all plot data for a fresh start."""
        # Clear line data
        self.line_temp1.set_data([], [])
        self.line_temp2.set_data([], [])
        self.line_diff.set_data([], [])

        # Reset axes limits
        self.ax_temps.set_xlim(0, 1)
        self.ax_temps.set_ylim(0, 1)
        self.ax_diff.set_xlim(0, 1)
        self.ax_diff.set_ylim(-1, 1)

        # Reset status bar
        self.point_count_label.config(
            text=f"Points: 0  |  Sensors: -  |  Mode: -  |  v{__version__}"
        )

        # Restart animation if it was stopped
        try:
            if hasattr(self, "ani") and self.ani and self.ani.event_source:
                self.ani.event_source.start()
        except Exception:
            pass

        # Redraw canvas
        self.canvas.draw_idle()

    def _send_scpi_command(self, event=None) -> None:
        """Send SCPI command through the logger's serial connection."""
        command = self.scpi_entry.get().strip()
        if not command:
            return

        # Add to history
        if not self._scpi_history or self._scpi_history[-1] != command:
            self._scpi_history.append(command)
        self._scpi_history_index = len(self._scpi_history)

        # Clear entry
        self.scpi_entry.delete(0, tk.END)

        # Check if logger is connected
        if not self.logger or not hasattr(self.logger, 'instr') or not self.logger.instr:
            self._add_info(f"→ {command}\n")
            self._add_info("❌ Not connected. Start logging first.\n")
            return

        # Send command in a separate thread to avoid blocking GUI
        def send_cmd():
            try:
                self._add_info(f"→ {command}\n")

                # Pause data collection to prevent interference
                self.logger.pause_data_collection = True
                time.sleep(0.4)  # Wait long enough for in-flight command to complete (AVG8 = ~200ms + buffer)

                # Use the logger's instrument connection with lock to prevent
                # interference with the data collection thread
                with self.logger.data_lock:
                    instr = self.logger.instr
                    # SCPISerial uses 'serial' attribute for the pyserial object
                    ser = getattr(instr, 'serial', None)

                    if ser:
                        # Drain all pending data from input buffer
                        while ser.in_waiting > 0:
                            ser.read(ser.in_waiting)
                            time.sleep(0.01)

                    # Determine if this is a query
                    is_query = command.strip().endswith('?')

                    if is_query:
                        # Direct write + read for queries with proper blocking timeout
                        if ser:
                            # Save old timeout and set longer one for manual commands
                            old_timeout = ser.timeout
                            ser.timeout = 1.0  # 1 second blocking timeout

                            try:
                                # Write command directly
                                ser.write((command + '\n').encode('ascii'))
                                ser.flush()

                                # Read response (blocks until newline or timeout)
                                response = ser.readline().decode('ascii', errors='ignore').strip()

                                if response:
                                    self._add_info(f"← {response}\n")
                                else:
                                    self._add_info("← (no response)\n")
                            finally:
                                # Restore original timeout
                                ser.timeout = old_timeout
                        else:
                            # Fallback to query method
                            response = instr.query(command)
                            if response:
                                self._add_info(f"← {response}\n")
                            else:
                                self._add_info("← (no response)\n")
                    else:
                        # For commands, use write
                        instr.write(command)
                        self._add_info("← OK\n")

                # Resume data collection
                self.logger.pause_data_collection = False

            except Exception as e:
                # Make sure to resume data collection even on error
                if self.logger:
                    self.logger.pause_data_collection = False
                self._add_info(f"❌ Error: {e}\n")

        # Run in thread
        threading.Thread(target=send_cmd, daemon=True).start()

    def _scpi_history_prev(self, event=None) -> None:
        """Navigate to previous command in history."""
        if self._scpi_history and self._scpi_history_index > 0:
            self._scpi_history_index -= 1
            self.scpi_entry.delete(0, tk.END)
            self.scpi_entry.insert(0, self._scpi_history[self._scpi_history_index])

    def _scpi_history_next(self, event=None) -> None:
        """Navigate to next command in history."""
        if self._scpi_history and self._scpi_history_index < len(self._scpi_history) - 1:
            self._scpi_history_index += 1
            self.scpi_entry.delete(0, tk.END)
            self.scpi_entry.insert(0, self._scpi_history[self._scpi_history_index])
        elif self._scpi_history_index >= len(self._scpi_history) - 1:
            self._scpi_history_index = len(self._scpi_history)
            self.scpi_entry.delete(0, tk.END)

    def _update_status(self, text: str, color: str = None) -> None:  # type: ignore
        """Update status label (thread-safe)."""

        def _do_update():
            try:
                # Check if widget still exists (may have been destroyed)
                if not self.status_label.winfo_exists():
                    return

                actual_color = self.FG_COLOR if color is None else color
                self.status_label.config(text=text, foreground=actual_color)
            except tk.TclError:
                # Widget was destroyed, silently ignore
                pass

        # Schedule GUI update on main thread (thread-safe)
        with contextlib.suppress(Exception):
            self.root.after(0, _do_update)

    def _on_scale_changed(self) -> None:
        """Handle graph scale factor change."""
        try:
            new_scale = float(self.scale_var.get())
            if 0.8 <= new_scale <= 2.0:
                self.text_scale = new_scale
                # Update all plot labels and tick parameters immediately
                self.ax_temps.set_ylabel("Temperature (°C)", fontsize=int(10 * self.text_scale))
                self.ax_temps.tick_params(labelsize=int(9 * self.text_scale))
                self.ax_temps.legend(loc="best", ncol=2, fontsize=int(9 * self.text_scale))
                self.ax_diff.set_ylabel(r"$\Delta T = T_1 - T_2$ (°C)", fontsize=int(10 * self.text_scale))
                self.ax_diff.set_xlabel("Elapsed Time (m:ss)", fontsize=int(10 * self.text_scale))
                self.ax_diff.tick_params(labelsize=int(9 * self.text_scale))
                # Adjust margins to ensure all labels are visible
                self.fig.subplots_adjust(left=0.14, right=0.98)
                self.canvas.draw_idle()
        except (ValueError, AttributeError):
            pass  # Invalid input or scale_spinbox not yet created

    def _set_button_states_idle(self) -> None:
        """Set button states for idle (START enabled, STOP disabled)."""
        self._safe_widget_config(self.start_btn, state=tk.NORMAL)
        self._safe_widget_config(self.stop_btn, state=tk.DISABLED)

    def _set_button_states_running(self) -> None:
        """Set button states for running (START disabled, STOP enabled)."""
        self._safe_widget_config(self.start_btn, state=tk.DISABLED)
        self._safe_widget_config(self.stop_btn, state=tk.NORMAL)

    def _safe_widget_config(self, widget: tk.Widget, **kwargs) -> None:
        """Safely configure a widget, checking if it still exists.

        Args:
            widget: The widget to configure
            **kwargs: Configuration options to apply
        """
        try:
            if widget.winfo_exists():
                widget.config(**kwargs)
        except tk.TclError:
            # Widget was destroyed, silently ignore
            pass

    def _detect_and_verify_sensors(self, port: str | None) -> tuple[bool, str]:
        """Detect and verify sensors are working.

        Returns:
            Tuple of (success: bool, message: str)
        """
        # First check if serial is available
        try:
            import serial  # type: ignore
            import serial.tools.list_ports  # type: ignore
        except ImportError as e:
            return False, f"❌ pyserial not installed. Please install with: pip install pyserial (Error: {e})"

        try:
            # Determine port
            if port is None:
                # Auto-detect: use the filtered port list (excludes Bluetooth, etc.)
                filtered_ports = self._scan_ports()
                # Remove "Auto-detect" from the list
                available_ports = [p for p in filtered_ports if p != "Auto-detect"]
                if not available_ports:
                    return False, "❌ No USB serial ports found. Please connect the device."
                port = available_ports[0]
                self._add_info(f"Auto-detected port: {port}\n")
            else:
                # Verify port exists
                ports = [p.device for p in serial.tools.list_ports.comports()]
                if port not in ports:
                    return False, f"❌ Port {port} not found. Available ports: {', '.join(ports) if ports else 'None'}"

            self._add_info(f"✓ Port {port} is available\n")

            # Skip trying to open serial.Serial() directly due to environment issues
            # The actual connection will be tested when logging starts
            self._add_info("✓ Pre-flight checks passed. Sensor verification will occur during logging.\n")
            return True, "✓ Ready to log."

        except Exception as e:
            return False, f"❌ Error during port detection: {e}"

    def _on_figure_close(self, event) -> None:
        """Handle matplotlib figure close event - stop logging."""
        # If root is already destroyed, skip any further work
        try:
            if not self.root.winfo_exists():
                return
        except tk.TclError:
            return

        if self.is_running:
            self._add_info("⏹ Matplotlib window closed. Stopping data collection...\n")
            self._stop_logging()

    def _start_logging(self) -> None:
        """Start data logging in a separate thread."""
        if self.is_running:
            self._add_info("⚠️ Logging is already running\n")
            return

        # Get connection configuration based on connection type
        conn_type = self.conn_type_var.get()
        port = None
        wifi_host = None
        prefer_wifi = True

        if conn_type == "Auto (WiFi → USB)":
            prefer_wifi = True
            # Let SCPIUniversal auto-detect everything
        elif conn_type == "Auto (USB → WiFi)":
            prefer_wifi = False
            # Let SCPIUniversal auto-detect everything
        elif conn_type == "Force WiFi":
            prefer_wifi = True
            wifi_host = self.wifi_ip_var.get().strip()
            if not wifi_host:
                self._add_info("❌ WiFi IP address required for Force WiFi mode\n")
                self._update_status("Error", self.ERROR_COLOR)
                return
        elif conn_type == "Force USB":
            prefer_wifi = False
            port = None if self.port_var.get() == "Auto-detect" else self.port_var.get()

        output_file = (
            self.output_entry.get("1.0", tk.END).strip()
            if self.output_entry.get("1.0", tk.END).strip()
            else None
        )

        try:
            max_points = int(self.max_points_var.get())
            # Extract AVG level from combobox value (e.g., "8 (Default)" -> 8)
            avg_level_str = self.avg_level_var.get().split()[0]
            avg_level = int(avg_level_str)
        except ValueError:
            self._add_info("❌ Invalid max points or AVG level\n")
            self._update_status("Error", self.ERROR_COLOR)
            return

        # Validate output file
        if output_file:
            try:
                output_path = Path(output_file)
                if output_path.exists():
                    response = messagebox.askyesnocancel(
                        "File exists",
                        f"The file already exists:\n{output_path}\n\n"
                        "Yes: choose a new filename\n"
                        "No: overwrite and continue\n"
                        "Cancel: abort logging",
                    )
                    if response is None:
                        self._add_info("⚠️ Logging aborted (file already exists)\n")
                        self._update_status("Aborted", self.ERROR_COLOR)
                        return
                    if response:
                        new_filename = filedialog.asksaveasfilename(
                            defaultextension=".csv",
                            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")],
                            initialfile=output_path.name,
                            initialdir=str(output_path.parent),
                        )
                        if not new_filename:
                            self._add_info("⚠️ Logging aborted (no filename selected)\n")
                            self._update_status("Aborted", self.ERROR_COLOR)
                            return
                        output_file = new_filename
                        self.output_entry.delete("1.0", tk.END)
                        self.output_entry.insert("1.0", output_file)
                        output_path = Path(output_file)

                output_path.parent.mkdir(parents=True, exist_ok=True)
            except Exception as e:
                self._add_info(f"❌ Invalid output file path: {e}\n")
                self._update_status("Error", self.ERROR_COLOR)
                return

        # Pre-flight checks
        self._update_status("Pre-flight checks...", self.ACCENT_COLOR)
        self._add_info("=" * 28 + "\n", "separator")
        self._add_info("Starting pre-flight checks...\n")

        # Connection info
        if wifi_host:
            self._add_info(f"Connection: Force WiFi ({wifi_host})\n")
        elif prefer_wifi:
            self._add_info("Connection: Auto (WiFi → USB)\n")
        else:
            self._add_info("Connection: Auto (USB → WiFi)\n")

        # Reset plots for fresh start
        self._reset_plots()

        # Create logger
        try:
            self.logger = TemperatureLogger(
                port=port,
                wifi_host=wifi_host,
                prefer_wifi=prefer_wifi,
                output_file=output_file,
                show_plot=False,  # GUI handles plotting
                max_points=max_points,
                avg_level=avg_level,
            )
            self.is_running = True

            # Update UI - Disable configuration widgets (safely)
            self._update_status("Connecting to device...", self.ACCENT_COLOR)
            self._safe_widget_config(self.conn_type_combo, state="disabled")
            self._safe_widget_config(self.wifi_entry, state="disabled")
            self._safe_widget_config(self.discover_wifi_btn, state=tk.DISABLED)
            self._safe_widget_config(self.port_combo, state="disabled")
            self._safe_widget_config(self.refresh_ports_btn, state=tk.DISABLED)
            self._safe_widget_config(self.output_entry, state="disabled")
            self._safe_widget_config(self.browse_btn, state=tk.DISABLED)
            self._safe_widget_config(self.max_points_spinbox, state="disabled")
            self._safe_widget_config(self.avg_level_combo, state="disabled")
            self._set_button_states_running()

            # Run logger in separate thread
            self.logger_thread = threading.Thread(target=self._run_logger, daemon=True)
            self.logger_thread.start()

        except Exception as e:
            error_msg = str(e)
            self._add_info(f"❌ Failed to start logger: {error_msg}\n")
            self._update_status("Error", self.ERROR_COLOR)
            self.is_running = False
            # Re-enable configuration widgets (safely)
            self._safe_widget_config(self.conn_type_combo, state="readonly")
            self._safe_widget_config(self.wifi_entry, state="normal")
            self._safe_widget_config(self.discover_wifi_btn, state=tk.NORMAL)
            self._safe_widget_config(self.port_combo, state="readonly")
            self._safe_widget_config(self.refresh_ports_btn, state=tk.NORMAL)
            self._safe_widget_config(self.output_entry, state="normal")
            self._safe_widget_config(self.browse_btn, state=tk.NORMAL)
            self._safe_widget_config(self.max_points_spinbox, state="normal")
            self._safe_widget_config(self.avg_level_combo, state="readonly")
            self._set_button_states_idle()

    def _run_logger(self) -> None:
        """Run the logger (called in separate thread)."""
        if not self.logger:
            return

        try:
            # Connect first to initialize instr attribute (with timeout)
            self._add_info("Connecting to device (timeout: 2s)...\n")

            # Use a wrapper to catch timeout and errors
            connect_error = [None]  # Use list to allow modification in nested function
            connect_done = [False]

            def connect_wrapper():
                try:
                    self.logger.connect()
                    connect_done[0] = True
                except Exception as e:
                    connect_error[0] = e
                    connect_done[0] = True

            connect_thread = threading.Thread(target=connect_wrapper, daemon=True)
            connect_thread.start()
            connect_thread.join(timeout=3)  # Wait max 3 seconds for connection

            # Check if thread is still running or if there was an error
            if connect_thread.is_alive() or not connect_done[0]:
                raise TimeoutError("❌ Connection timed out after 3 seconds")

            if connect_error[0]:
                # Error message from connect() is already formatted, pass it through
                raise RuntimeError(str(connect_error[0]))

            port_name = self.logger.instr.port_name
            self._update_status(f"Connected: {port_name}", self.SUCCESS_COLOR)
            self._add_info(f"✓ Connected to: {port_name}\n")

            if self.logger.is_dual_sensor:
                self._add_info("✓ Dual sensor mode detected\n")
            else:
                self._add_info("✓ Single sensor mode detected\n")

            self._add_info("=" * 28 + "\n", "separator")
            self._add_info("Collecting data...\n")

            # Start data collection
            self.logger.open_csv_file()
            self.logger.running = True

            # Start the data collection thread
            self.logger.data_thread = threading.Thread(
                target=self.logger._data_collection_thread,
                daemon=True,
                name="DataCollectionThread",
            )
            self.logger.data_thread.start()

            # Keep thread alive while logging, but don't probe sensors (avoid parsing issues)
            # Sensor configuration is detected once at startup and doesn't change during normal operation
            while self.logger and self.logger.running:
                time.sleep(0.1)

            # After loop exits, data collection has stopped
            # Save point count before logger is cleared
            point_count = self.logger.point_count if self.logger else 0
            self._add_info("=" * 28 + "\n", "separator")
            self._add_info("✓ Data collection stopped\n")
            self._add_info(f"✓ Total points logged: {point_count}\n")

        except KeyboardInterrupt:
            self._add_info("=" * 28 + "\n", "separator")
            self._add_info("⏹ Logging stopped by user\n", "warning")
        except Exception as e:
            self._add_info("=" * 28 + "\n", "separator")
            error_msg = str(e).strip()
            # If error already has ❌ prefix, use it as-is; otherwise add prefix
            if error_msg.startswith("❌"):
                self._add_info(f"{error_msg}\n", "error")
            else:
                self._add_info(f"❌ {error_msg}\n", "error")
            self._update_status("Error during logging", self.ERROR_COLOR)
        finally:
            self.is_running = False
            # Re-enable configuration widgets (safely)
            self._safe_widget_config(self.port_combo, state="readonly")
            self._safe_widget_config(self.output_entry, state="normal")
            self._safe_widget_config(self.browse_btn, state=tk.NORMAL)
            self._set_button_states_idle()
            self._update_status("Ready", self.SUCCESS_COLOR)

    def _update_plots(self, frame) -> None:
        """Update plots with current logger data."""
        if not self.logger or not self.logger.running:
            return

        # Update status bar
        mode = "Dual Sync" if self.logger.is_dual_sensor else "Single"
        self.point_count_label.config(
            text=f"Points: {self.logger.point_count}  |  Sensors: {self.logger.sensor_count}  |  Mode: {mode}  |  v{__version__}"
        )

        # Get data from logger
        if len(self.logger.timestamps) > 0:
            temps1 = list(self.logger.temperatures_1)
            temps2 = list(self.logger.temperatures_2)
            diffs = list(self.logger.diff_data)
            clock_times = self._get_clock_times()

            # Create numeric x-axis for plotting (0, 1, 2, ...)
            x_indices = list(range(len(clock_times)))

            # Update both temperatures on same graph
            if temps1:
                self.line_temp1.set_data(x_indices, temps1)
            if temps2:
                self.line_temp2.set_data(x_indices, temps2)

            # Set xlim and ylim for temperature graph
            if temps1 or temps2:
                max_len = len(x_indices)
                self.ax_temps.set_xlim(0, max_len)

                # Calculate ylim from both datasets, filtering out None values
                all_temps = [t for t in (temps1 + temps2) if t is not None]
                if all_temps:
                    y_min, y_max = min(all_temps), max(all_temps)
                    margin = (y_max - y_min) * 0.1 if y_max > y_min else 1
                    self.ax_temps.set_ylim(y_min - margin, y_max + margin)

            # Update difference plot
            if diffs:
                # Filter out None values from diffs
                diffs_clean = [d for d in diffs if d is not None]
                if diffs_clean:
                    self.line_diff.set_data(x_indices, diffs)
                    self.ax_diff.set_xlim(0, len(x_indices))

                    # Set x-axis tick labels to actual clock time
                    if len(x_indices) > 0:
                        step = max(1, len(x_indices) // 10)
                        self.ax_diff.set_xticks(x_indices[::step])
                        self.ax_diff.set_xticklabels(clock_times[::step])

                    y_min, y_max = min(diffs_clean), max(diffs_clean)
                    margin = (y_max - y_min) * 0.1 if y_max > y_min else 1
                    self.ax_diff.set_ylim(y_min - margin, y_max + margin)

        # Ensure y-axis labels remain visible as tick labels grow (increased left margin for larger numbers)
        self.fig.subplots_adjust(left=0.14, right=0.98)

        # Request canvas redraw to update all changes
        self.canvas.draw_idle()

    def _stop_logging(self) -> None:
        """Stop data logging."""
        # If UI is already gone, just stop logger state and return
        try:
            if not self.root.winfo_exists():
                if self.logger:
                    self.logger.running = False
                self.is_running = False
                return
        except tk.TclError:
            if self.logger:
                self.logger.running = False
            self.is_running = False
            return

        if self.logger:
            self._add_info("⏹ Stopping data collection...\n", "warning")
            self.logger.running = False
            self._update_status("Stopping...", self.ACCENT_COLOR)

            if self.logger_thread and self.logger_thread.is_alive():
                self.logger_thread.join(timeout=3.0)

            self.logger = None
            self.is_running = False

        # Stop animation if still active
        try:
            if hasattr(self, "ani") and self.ani and self.ani.event_source:
                self.ani.event_source.stop()
        except Exception:
            pass

        # Re-enable configuration widgets safely
        self._safe_widget_config(self.conn_type_combo, state="readonly")
        self._safe_widget_config(self.wifi_entry, state="normal")
        self._safe_widget_config(self.discover_wifi_btn, state=tk.NORMAL)
        self._safe_widget_config(self.port_combo, state="readonly")
        self._safe_widget_config(self.refresh_ports_btn, state=tk.NORMAL)
        self._safe_widget_config(self.output_entry, state="normal")
        self._safe_widget_config(self.browse_btn, state=tk.NORMAL)
        self._safe_widget_config(self.max_points_spinbox, state="normal")
        self._safe_widget_config(self.avg_level_combo, state="readonly")
        self._set_button_states_idle()
        self._update_status("Ready", self.SUCCESS_COLOR)


def main() -> int:
    """Main entry point."""
    root = tk.Tk()
    app = TemperatureLoggerGUIEnhanced(root)

    try:
        root.mainloop()
    except KeyboardInterrupt:
        if app.logger:
            app.logger.running = False
        root.destroy()

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
