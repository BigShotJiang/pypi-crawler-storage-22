#!/usr/bin/env python3
"""
SCPI Client — Interactive SCPI terminal for TMP117 PID Controller.

Send SCPI commands via USB serial or WiFi/TCP. Supports single-command
and interactive modes with tab-completion, command history, pretty-printed
responses, and OPC synchronization.

Usage (installed via pip):
    # Interactive mode
    scpi-client

    # Single command
    scpi-client "*IDN?"
    scpi-client ":SENS:TEMP?"

    # WiFi/TCP mode
    scpi-client -w 192.168.1.100 "*IDN?"
    scpi-client -w 192.168.1.100  # interactive over WiFi

    # Specify serial port
    scpi-client -p /dev/cu.usbmodem1101 "*IDN?"

(c) 2026 Prof. Flavio ABREU ARAUJO. All rights reserved.
"""

from __future__ import annotations

import argparse
import contextlib
import os
import socket
import sys
import time

import serial  # type: ignore
import serial.tools.list_ports  # type: ignore

# ---------------------------------------------------------------------------
# ANSI helpers
# ---------------------------------------------------------------------------
CYAN = "\033[96m"
YELLOW = "\033[93m"
GREEN = "\033[92m"
MAGENTA = "\033[95m"
RED = "\033[91m"
BLUE = "\033[94m"
RESET = "\033[0m"
BOLD = "\033[1m"
DIM = "\033[2m"

DEFAULT_SCPI_PORT = 5025

# Try to import readline for history / tab-completion
try:
    import readline

    READLINE_AVAILABLE = True
    USING_LIBEDIT = "libedit" in (readline.__doc__ or "")
except ImportError:
    READLINE_AVAILABLE = False
    USING_LIBEDIT = False

HISTORY_FILE = os.path.expanduser("~/.scpi_send_history")


# ===================================================================
# TCP Socket wrapper (mirrors serial.Serial interface)
# ===================================================================
class TCPSocket:
    """TCP socket wrapper that mimics ``serial.Serial`` for SCPI over WiFi."""

    def __init__(self, host: str, port: int = DEFAULT_SCPI_PORT, timeout: float = 2.0):
        self.host = host
        self.tcp_port = port
        self.timeout = timeout
        self.sock: socket.socket | None = None
        self._buffer = b""

    # -- connection --------------------------------------------------------
    def connect(self):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.settimeout(self.timeout)
        self.sock.connect((self.host, self.tcp_port))

    def close(self):
        if self.sock:
            with contextlib.suppress(Exception):
                self.sock.close()
            self.sock = None

    # -- write / read ------------------------------------------------------
    def write(self, data, sync=True):
        if isinstance(data, str):
            data = data.encode("utf-8")
        if self.sock:
            self.sock.sendall(data)

    def read(self, size: int = 1) -> bytes:
        if not self.sock:
            return b""
        if len(self._buffer) >= size:
            data, self._buffer = self._buffer[:size], self._buffer[size:]
            return data
        data = self._buffer
        self._buffer = b""
        with contextlib.suppress(socket.timeout):
            data += self.sock.recv(size - len(data))
        return data

    def readline(self) -> bytes:
        if not self.sock:
            return b""
        while b"\n" not in self._buffer:
            try:
                chunk = self.sock.recv(1024)
                if not chunk:
                    break
                self._buffer += chunk
            except socket.timeout:
                break
        if b"\n" in self._buffer:
            line, self._buffer = self._buffer.split(b"\n", 1)
            return line + b"\n"
        line, self._buffer = self._buffer, b""
        return line

    # -- buffer management -------------------------------------------------
    def reset_input_buffer(self):
        self._buffer = b""
        if self.sock:
            self.sock.setblocking(False)
            try:
                while True:
                    chunk = self.sock.recv(1024)
                    if not chunk:
                        break
            except (OSError, BlockingIOError):
                pass
            finally:
                self.sock.setblocking(True)
                self.sock.settimeout(self.timeout)

    def reset_output_buffer(self):
        pass

    def flush(self):
        pass

    @property
    def in_waiting(self) -> int:
        if self._buffer:
            return len(self._buffer)
        if not self.sock:
            return 0
        self.sock.setblocking(False)
        try:
            chunk = self.sock.recv(1024, socket.MSG_PEEK)
            return len(chunk)
        except (OSError, BlockingIOError):
            return 0
        finally:
            self.sock.setblocking(True)
            self.sock.settimeout(self.timeout)


# ===================================================================
# Utility functions
# ===================================================================
def find_circuitpython_port() -> str | None:
    """Auto-detect CircuitPython serial port."""
    ports = serial.tools.list_ports.comports()
    for p in ports:
        if any(kw in p.description.lower() for kw in ("circuitpython", "arduino", "esp32", "nano")):
            return p.device
        if p.manufacturer and "arduino" in p.manufacturer.lower():
            return p.device
    if ports:
        print(f"\n{YELLOW}Available serial ports:{RESET}")
        for i, p in enumerate(ports, 1):
            print(f"  {CYAN}{i}.{RESET} {BOLD}{p.device}{RESET} - {p.description}")
    return None


def parse_wifi_address(addr_str: str) -> tuple[str, int]:
    """Parse ``"host"`` or ``"host:port"`` into *(host, port)* tuple."""
    if ":" in addr_str:
        host, port_str = addr_str.rsplit(":", 1)
        try:
            port = int(port_str)
        except ValueError:
            print(f"Warning: Invalid port '{port_str}', using default {DEFAULT_SCPI_PORT}")
            port = DEFAULT_SCPI_PORT
    else:
        host = addr_str
        port = DEFAULT_SCPI_PORT
    return host, port


# ===================================================================
# Pretty-print helpers
# ===================================================================
def format_response(command: str, response: str, pretty: bool = True) -> str:
    """Pretty-format known SCPI responses for human readability."""
    if not pretty or not response:
        return response

    cmd = command.strip().upper()

    # --- PID Status (:PID:STAT?) ---
    if cmd in (":PID:STAT?", ":PID:STATUS?"):
        try:
            parts = response.split(",")
            if len(parts) >= 7:
                en, sp, err, out = int(parts[0]), float(parts[1]), float(parts[2]), float(parts[3])
                p, i, d = float(parts[4]), float(parts[5]), float(parts[6])
                si = f"{GREEN}●{RESET}" if en else f"{DIM}○{RESET}"
                st = f"{GREEN}ENABLED{RESET}" if en else f"{DIM}DISABLED{RESET}"
                oc = RED if abs(out) > 0.8 else YELLOW if abs(out) > 0.5 else GREEN
                ob = "█" * int(abs(out) * 10)
                od = "HEAT" if out > 0 else "COOL" if out < 0 else "OFF"
                ec = RED if abs(err) > 2 else YELLOW if abs(err) > 0.5 else GREEN
                r = f"\n{BOLD}{CYAN}PID Controller Status:{RESET}\n"
                r += f"  {si} Status:      {st}\n"
                r += f"  🎯 Setpoint:    {MAGENTA}{sp:6.2f}°C{RESET}\n"
                r += f"  ⚠️  Error:       {ec}{err:+6.2f}°C{RESET}\n"
                r += f"  ⚡ Output:      {oc}{out:+6.2f}{RESET} ({od}) {oc}{ob}{RESET}\n"
                r += f"  📊 PID Terms:\n     P: {p:+7.4f}\n     I: {i:+7.4f}\n     D: {d:+7.4f}"
                return r
        except (ValueError, IndexError):
            pass

    # --- PID Telemetry (:PID:TELE?) ---
    elif cmd in (":PID:TELE?", ":PID:TELEMETRY?"):
        try:
            parts = response.split(",")
            if len(parts) >= 7:
                run, sens = int(parts[0]), int(parts[1])
                tmp, sp, out = float(parts[2]), float(parts[3]), float(parts[4])
                lc, ramp = int(parts[5]), int(parts[6])
                si = f"{GREEN}●{RESET}" if run else f"{DIM}○{RESET}"
                st = f"{GREEN}RUNNING{RESET}" if run else f"{DIM}STOPPED{RESET}"
                oc = RED if abs(out) > 0.8 else YELLOW if abs(out) > 0.5 else GREEN
                ob = "█" * int(abs(out) * 10)
                od = "HEAT" if out > 0 else "COOL" if out < 0 else "OFF"
                er = tmp - sp
                ec = RED if abs(er) > 2 else YELLOW if abs(er) > 0.5 else GREEN
                r = f"\n{BOLD}{CYAN}PID Controller Telemetry:{RESET}\n"
                r += f"  {si} Status:      {st}\n"
                r += f"  🔢 Sensor:       #{sens}\n"
                r += f"  🌡️  Temperature:  {CYAN}{tmp:7.3f}°C{RESET}\n"
                r += f"  🎯 Setpoint:     {MAGENTA}{sp:7.3f}°C{RESET}\n"
                r += f"  ⚠️  Error:        {ec}{er:+7.3f}°C{RESET}\n"
                r += f"  ⚡ Output:       {oc}{out:+7.3f}{RESET} ({od}) {oc}{ob}{RESET}\n"
                r += f"  🔄 Loop count:   {lc}\n"
                r += f"  🔥 Ramping:      {YELLOW}ACTIVE{RESET}" if ramp else f"  🔥 Ramping:      {DIM}INACTIVE{RESET}"
                return r
        except (ValueError, IndexError):
            pass

    # --- Ramp Status (:PID:RAMP:STAT?) ---
    elif cmd in (":PID:RAMP:STAT?", ":PID:RAMP:STATUS?"):
        try:
            parts = response.split(",")
            if len(parts) >= 9:
                act, ramp, hold, comp = int(parts[0]), int(parts[1]), int(parts[2]), int(parts[3])
                st_t, tgt, csp = float(parts[4]), float(parts[5]), float(parts[6])
                rate, prog = float(parts[7]), float(parts[8])
                if comp:
                    si, st = f"{GREEN}✓{RESET}", f"{GREEN}COMPLETED{RESET}"
                elif hold:
                    si, st = f"{YELLOW}⏸{RESET}", f"{YELLOW}HOLDING{RESET}"
                elif ramp:
                    si, st = f"{YELLOW}▶{RESET}", f"{YELLOW}RAMPING{RESET}"
                elif act:
                    si, st = f"{CYAN}●{RESET}", f"{CYAN}ACTIVE{RESET}"
                else:
                    si, st = f"{DIM}■{RESET}", f"{DIM}IDLE{RESET}"
                r = f"\n{BOLD}{CYAN}Temperature Ramp Status:{RESET}\n  {si} Phase:      {st}\n"
                if act:
                    r += f"  🎯 Target:     {MAGENTA}{tgt:6.2f}°C{RESET}\n"
                    r += f"  📍 Current SP: {CYAN}{csp:6.2f}°C{RESET}\n"
                    r += f"  📈 Rate:       {CYAN}{rate:6.2f}°C/min{RESET}\n"
                    if rate > 0 and ramp:
                        td = abs(tgt - st_t)
                        total = (td / rate) * 60.0
                        el = (prog / 100.0) * total
                        rem = total - el
                        r += f"  ⏱️  Elapsed:    {el:6.1f}s\n  ⏳ Remaining:  {rem:6.1f}s\n"
                    bw = 20
                    fi = int((prog / 100.0) * bw)
                    bar = "█" * fi + "░" * (bw - fi)
                    r += f"  Progress: [{CYAN}{bar}{RESET}] {prog:5.1f}%"
                else:
                    r += f"  {DIM}No active ramp{RESET}"
                return r
        except (ValueError, IndexError) as e:
            return f"{YELLOW}⚠ Ramp Status Parse Error:{RESET}\n{response}\n{DIM}Error: {e}{RESET}"

    # --- WiFi Status ---
    elif cmd in (":WIFI:STATUS?", ":WIFI:STAT?"):
        try:
            parts = response.split(",")
            if len(parts) >= 4:
                conn = int(parts[0])
                ssid, ip, rssi = parts[1], parts[2], int(parts[3])
                si = f"{GREEN}📶{RESET}" if conn else f"{DIM}📵{RESET}"
                st = f"{GREEN}CONNECTED{RESET}" if conn else f"{DIM}DISCONNECTED{RESET}"
                if rssi > -50:
                    sig = f"{GREEN}Excellent{RESET} ({rssi} dBm)"
                elif rssi > -60:
                    sig = f"{GREEN}Good{RESET} ({rssi} dBm)"
                elif rssi > -70:
                    sig = f"{YELLOW}Fair{RESET} ({rssi} dBm)"
                else:
                    sig = f"{RED}Weak{RESET} ({rssi} dBm)"
                r = f"\n{BOLD}{CYAN}WiFi Status:{RESET}\n  {si} Status:  {st}\n"
                if conn:
                    r += f"  🌐 Network:  {CYAN}{ssid}{RESET}\n"
                    r += f"  📍 Address:  {MAGENTA}{ip}{RESET}\n"
                    r += f"  📊 Signal:   {sig}"
                return r
        except (ValueError, IndexError):
            pass

    # --- Sensor temperatures ---
    elif cmd in (":PID:TEMPS?", ":PID:TEMP:ALL?"):
        try:
            temps = [float(t) for t in response.split(",")]
            r = f"\n{BOLD}{CYAN}Sensor Temperatures:{RESET}\n"
            for idx, t in enumerate(temps, 1):
                tc = RED if t > 40 else YELLOW if t > 30 else CYAN
                r += f"  🌡️  Sensor {idx}: {tc}{t:6.2f}°C{RESET}\n"
            return r.rstrip()
        except (ValueError, IndexError):
            pass

    # --- Simulation status ---
    elif cmd in (":SIM:STAT?", ":SIM:STATUS?"):
        try:
            pairs = {}
            for part in response.split(","):
                if ":" in part:
                    k, v = part.split(":", 1)
                    pairs[k] = float(v)
            if "ACTUAL" in pairs and "TEC" in pairs and "AMBIENT" in pairs:
                ac, tc, am = pairs["ACTUAL"], pairs["TEC"], pairs["AMBIENT"]
                tcc = RED if abs(tc) > 0.8 else YELLOW if abs(tc) > 0.5 else GREEN
                td = "HEATING" if tc > 0 else "COOLING" if tc < 0 else "OFF"
                tb = "█" * int(abs(tc) * 10)
                r = f"\n{BOLD}{CYAN}Thermal Simulation:{RESET}\n"
                r += f"  🌡️  Actual:   {CYAN}{ac:6.2f}°C{RESET}\n"
                r += f"  🌍 Ambient:  {DIM}{am:6.2f}°C{RESET}\n"
                r += f"  ⚡ TEC:      {tcc}{tc:+6.2f}{RESET} ({td}) {tcc}{tb}{RESET}"
                return r
        except (ValueError, KeyError):
            pass

    # --- :SENS:ALL? ---
    elif cmd in (":SENS:ALL?", ":SENS:TEMP:ALL?"):
        try:
            temps = [float(t) for t in response.split(",")]
            r = f"\n{BOLD}{CYAN}All Sensors:{RESET}\n"
            for idx, t in enumerate(temps, 1):
                tc = RED if t > 40 else YELLOW if t > 30 else CYAN
                r += f"  🌡️  Sensor {idx}: {tc}{t:6.2f}°C{RESET}\n"
            return r.rstrip()
        except (ValueError, IndexError):
            pass

    # --- Single temperature ---
    elif cmd in (":SENS:TEMP?", ":MEAS:TEMP?", ":TEMP?") or (
        cmd.startswith(":SENS") and cmd.endswith(":TEMP?")
    ):
        try:
            t = float(response.strip())
            tc = RED if t > 40 else YELLOW if t > 30 else CYAN
            return f"🌡️  {tc}{t:.2f}°C{RESET}"
        except ValueError:
            pass

    # --- TEC Output ---
    elif cmd in (":TEC:OUTP?", ":TEC:OUTPUT?"):
        try:
            o = float(response.strip())
            oc = RED if abs(o) > 0.8 else YELLOW if abs(o) > 0.5 else GREEN
            ob = "█" * int(abs(o) * 10)
            od = "HEATING" if o > 0 else "COOLING" if o < 0 else "OFF"
            r = f"⚡ TEC Output: {oc}{o:+6.2f}{RESET} ({od})"
            if ob:
                r += f" {oc}{ob}{RESET}"
            return r
        except ValueError:
            pass

    # --- PID Tuning ---
    elif cmd == ":PID:TUNE?":
        try:
            parts = response.split(",")
            if len(parts) >= 3:
                kp, ki, kd = float(parts[0]), float(parts[1]), float(parts[2])
                r = f"\n{BOLD}{CYAN}PID Tuning Parameters:{RESET}\n"
                r += f"  Kp: {GREEN}{kp:.6f}{RESET}\n"
                r += f"  Ki: {GREEN}{ki:.6f}{RESET}\n"
                r += f"  Kd: {GREEN}{kd:.6f}{RESET}"
                return r
        except (ValueError, IndexError):
            pass

    # --- Simple one-liners ---
    elif cmd in (":PID:SETP?", ":PID:SETPOINT?"):
        try:
            return f"🎯 Setpoint: {MAGENTA}{float(response.strip()):.2f}°C{RESET}"
        except ValueError:
            pass
    elif cmd in (":PID:ENAB?", ":PID:ENABLE?"):
        try:
            en = int(response.strip())
            return f"⚡ PID Control: {GREEN}ENABLED{RESET}" if en else f"⚡ PID Control: {DIM}DISABLED{RESET}"
        except ValueError:
            pass
    elif cmd in (":PID:SENS?", ":PID:SENSOR?"):
        try:
            return f"🔢 Selected Sensor: #{CYAN}{int(response.strip())}{RESET}"
        except ValueError:
            pass
    elif cmd in (":PID:SENS:COUN?", ":PID:SENS:COUNT?", ":PID:SENSOR:COUNT?", ":SENS:COUNT?"):
        try:
            return f"🔢 Sensor Count: {CYAN}{int(response.strip())}{RESET}"
        except ValueError:
            pass
    elif cmd == ":PID:RAMP?":
        try:
            return (f"🔥 Ramp: {YELLOW}ACTIVE{RESET}" if int(response.strip()) else f"🔥 Ramp: {DIM}INACTIVE{RESET}")
        except ValueError:
            pass
    elif cmd == ":WIFI:IP?":
        return f"📍 IP Address: {MAGENTA}{response.strip()}{RESET}"
    elif cmd == ":WIFI:MAC?":
        return f"🔖 MAC Address: {CYAN}{response.strip()}{RESET}"
    elif cmd == ":WIFI:SSID?":
        return f"🌐 SSID: {CYAN}{response.strip()}{RESET}"
    elif cmd == ":WIFI:RSSI?":
        try:
            rssi = int(response.strip())
            if rssi > -50:
                sig = f"{GREEN}Excellent{RESET}"
            elif rssi > -60:
                sig = f"{GREEN}Good{RESET}"
            elif rssi > -70:
                sig = f"{YELLOW}Fair{RESET}"
            else:
                sig = f"{RED}Weak{RESET}"
            return f"📊 Signal Strength: {sig} ({rssi} dBm)"
        except ValueError:
            pass
    elif cmd in (":WIFI:CONN?", ":WIFI:CONNECTED?"):
        try:
            c = int(response.strip())
            return f"📶 WiFi: {GREEN}CONNECTED{RESET}" if c else f"📵 WiFi: {DIM}DISCONNECTED{RESET}"
        except ValueError:
            pass
    elif cmd in (":WIFI:ENAB?", ":WIFI:ENABLE?"):
        try:
            e = int(response.strip())
            return f"📶 WiFi: {GREEN}ENABLED{RESET}" if e else f"📶 WiFi: {DIM}DISABLED{RESET}"
        except ValueError:
            pass
    elif cmd == ":WIFI:AVAILABLE?":
        try:
            a = int(response.strip())
            return (
                f"📶 WiFi Hardware: {GREEN}AVAILABLE{RESET}"
                if a
                else f"📶 WiFi Hardware: {RED}NOT AVAILABLE{RESET}"
            )
        except ValueError:
            pass
    elif cmd == ":TEC:STOP":
        rl = response.strip().lower()
        if "ok" in rl or rl == "0":
            return f"🛑 TEC: {RED}STOPPED{RESET} (output set to 0)"
        return f"🛑 TEC Stop: {response}"
    elif cmd in (":TEC:LIM?", ":TEC:LIMIT?", ":TEC:LIMITS?"):
        try:
            parts = response.split(",")
            if len(parts) >= 2:
                return f"🔒 TEC Limits: {CYAN}{float(parts[0]):+.2f}{RESET} to {CYAN}{float(parts[1]):+.2f}{RESET}"
        except (ValueError, IndexError):
            pass
    elif cmd.startswith(":SIM:RES"):
        rl = response.strip().lower()
        return f"🔄 Simulation: {GREEN}RESET{RESET}" if "ok" in rl else f"🔄 Simulation Reset: {response}"
    elif cmd.startswith(":SYST:LOG"):
        if response.strip():
            r = f"\n{BOLD}{CYAN}System Log:{RESET}\n{DIM}{'─' * 60}{RESET}\n"
            for line in response.strip().split("\n"):
                if "[ERROR]" in line or "ERROR" in line.upper():
                    r += f"{RED}{line}{RESET}\n"
                elif "[WARNING]" in line or "WARN" in line.upper():
                    r += f"{YELLOW}{line}{RESET}\n"
                elif "[INFO]" in line:
                    r += f"{CYAN}{line}{RESET}\n"
                elif "[DEBUG]" in line:
                    r += f"{DIM}{line}{RESET}\n"
                else:
                    r += f"{line}\n"
            r += f"{DIM}{'─' * 60}{RESET}"
            return r
        return f"{DIM}(no log entries){RESET}"
    elif cmd in (":SYST:CAL:SAVE",):
        rl = response.strip().lower()
        return f"💾 Calibration: {GREEN}SAVED{RESET}" if ("ok" in rl or "saved" in rl) else f"💾 Calibration Save: {response}"
    elif cmd in (":SYST:CAL:LOAD",):
        rl = response.strip().lower()
        return f"📂 Calibration: {GREEN}LOADED{RESET}" if ("ok" in rl or "loaded" in rl) else f"📂 Calibration Load: {response}"
    elif cmd in (":SYST:CAL:DEL", ":SYST:CAL:DELETE"):
        rl = response.strip().lower()
        return f"🗑️  Calibration: {YELLOW}DELETED{RESET}" if ("ok" in rl or "deleted" in rl) else f"🗑️  Calibration Delete: {response}"
    elif cmd in (":SYST:RES", ":SYST:RESET"):
        return f"🔄 System: {YELLOW}RESETTING...{RESET}"
    elif cmd == "*IDN?":
        parts = response.strip().split(",")
        if len(parts) >= 4:
            r = f"\n{BOLD}{CYAN}Device Identification:{RESET}\n"
            r += f"  Manufacturer: {GREEN}{parts[0].strip()}{RESET}\n"
            r += f"  Model:        {GREEN}{parts[1].strip()}{RESET}\n"
            r += f"  Serial:       {MAGENTA}{parts[2].strip()}{RESET}\n"
            r += f"  Version:      {CYAN}{parts[3].strip()}{RESET}"
            return r
    elif cmd.startswith(":HELP") or cmd.startswith("HELP"):
        return f"\n{BOLD}{CYAN}Help:{RESET}\n{response}"

    return response


# ===================================================================
# Command helpers
# ===================================================================
def get_command_confirmation(command: str) -> str:
    """Descriptive confirmation for write (non-query) commands."""
    cu = command.strip().upper()
    parts = cu.split()
    base = parts[0] if parts else cu
    param = " ".join(parts[1:]) if len(parts) > 1 else ""

    if base.startswith(":TEC:OUTP") or base.startswith(":TEC:OUTPUT"):
        if param:
            try:
                v = float(param)
                d = "HEATING" if v > 0 else "COOLING" if v < 0 else "OFF"
                vc = RED if abs(v) > 0.7 else YELLOW if abs(v) > 0.3 else GREEN
                return f"{GREEN}✓{RESET} TEC output set to {vc}{v:+.2f}{RESET} {DIM}({d}){RESET}"
            except ValueError:
                return f"{GREEN}✓{RESET} TEC output set to {CYAN}{param}{RESET}"
        return f"{GREEN}✓{RESET} TEC output configured"
    elif base == ":TEC:STOP":
        return f"{GREEN}✓{RESET} TEC stopped {DIM}(output set to 0){RESET}"
    elif base.startswith(":PID:ENAB"):
        if param in ("1", "ON"):
            return f"{GREEN}✓{RESET} PID control {GREEN}enabled{RESET}"
        elif param in ("0", "OFF"):
            return f"{GREEN}✓{RESET} PID control {YELLOW}disabled{RESET}"
        return f"{GREEN}✓{RESET} PID enable state changed"
    elif base.startswith(":PID:SETP"):
        return f"{GREEN}✓{RESET} PID setpoint set to {MAGENTA}{param}°C{RESET}" if param else f"{GREEN}✓{RESET} PID setpoint configured"
    elif base == ":PID:KP":
        return f"{GREEN}✓{RESET} Kp set to {CYAN}{param}{RESET}" if param else f"{GREEN}✓{RESET} Kp configured"
    elif base == ":PID:KI":
        return f"{GREEN}✓{RESET} Ki set to {CYAN}{param}{RESET}" if param else f"{GREEN}✓{RESET} Ki configured"
    elif base == ":PID:KD":
        return f"{GREEN}✓{RESET} Kd set to {CYAN}{param}{RESET}" if param else f"{GREEN}✓{RESET} Kd configured"
    elif base.startswith(":PID:TUNE"):
        return f"{GREEN}✓{RESET} PID tuning set: {CYAN}{param}{RESET}" if param else f"{GREEN}✓{RESET} PID tuning configured"
    elif base.startswith(":PID:RES"):
        return f"{GREEN}✓{RESET} PID controller reset {DIM}(integral term cleared){RESET}"
    elif base.startswith(":PID:SENS") and not base.endswith("?"):
        return f"{GREEN}✓{RESET} PID sensor {CYAN}#{param}{RESET} selected" if param else f"{GREEN}✓{RESET} PID sensor selected"
    elif base.startswith(":PID:RAMP") and not base.endswith("?"):
        if ":STOP" in base or ":CANC" in base:
            return f"{GREEN}✓{RESET} Temperature ramp {YELLOW}stopped{RESET}"
        if param:
            rp = param.split(",")
            if len(rp) >= 2:
                return f"{GREEN}✓{RESET} Ramp started: target {MAGENTA}{rp[0]}°C{RESET} at {CYAN}{rp[1]}°C/min{RESET} {DIM}(PID auto-enabled){RESET}"
            return f"{GREEN}✓{RESET} Ramp configured: {CYAN}{param}{RESET} {DIM}(PID auto-enabled){RESET}"
        return f"{GREEN}✓{RESET} Temperature ramp configured {DIM}(PID auto-enabled){RESET}"
    elif base.startswith(":SIM:RES"):
        ti = f" at {CYAN}{param}°C{RESET}" if param else f" to {DIM}ambient{RESET}"
        return f"{GREEN}✓{RESET} Thermal simulation reset{ti}"
    elif base.startswith(":SYST:CAL:SAVE"):
        return f"{GREEN}✓{RESET} Calibration {GREEN}saved{RESET}"
    elif base.startswith(":SYST:CAL:LOAD"):
        return f"{GREEN}✓{RESET} Calibration {GREEN}loaded{RESET}"
    elif base.startswith(":SYST:CAL:DEL"):
        return f"{GREEN}✓{RESET} Calibration file {YELLOW}deleted{RESET}"
    elif base.startswith(":SYST:RES"):
        return f"{GREEN}✓{RESET} System reset {YELLOW}initiated{RESET}"
    elif base == "*RST":
        return f"{GREEN}✓{RESET} Device reset {DIM}(status cleared, sensors reset){RESET}"
    elif base == "*CLS":
        return f"{GREEN}✓{RESET} Status registers cleared"
    elif base == "*OPC":
        return f"{GREEN}✓{RESET} Operation complete flag set"
    elif base.startswith(":WIFI:ENAB"):
        if param in ("1", "ON"):
            return f"{GREEN}✓{RESET} WiFi {GREEN}enabled{RESET}"
        elif param in ("0", "OFF"):
            return f"{GREEN}✓{RESET} WiFi {YELLOW}disabled{RESET}"
        return f"{GREEN}✓{RESET} WiFi state changed"
    elif base.startswith(":WIFI:CONN"):
        return f"{GREEN}✓{RESET} WiFi connection initiated"
    elif base.startswith(":WIFI:DISC"):
        return f"{GREEN}✓{RESET} WiFi {YELLOW}disconnected{RESET}"
    return f"{GREEN}✓{RESET} Command completed"


def send_scpi_command(
    ser, command: str, timeout: float = 2.0, retry_count: int = 3, sync_mode: bool = True
) -> str | None:
    """Send an SCPI command with optional OPC synchronization, return response."""
    cmd = command.strip()
    is_query = cmd.endswith("?")

    if sync_mode and not is_query and not cmd.startswith("*"):
        cmd_to_send = f"{cmd};*OPC?\n"
    else:
        cmd_to_send = cmd + "\n" if not cmd.endswith("\n") else cmd

    for attempt in range(retry_count):
        ser.reset_input_buffer()
        ser.write(cmd_to_send.encode("utf-8"))
        ser.flush()

        start = time.time()
        lines: list[str] = []

        while (time.time() - start) < timeout:
            if ser.in_waiting > 0:
                try:
                    line = ser.readline().decode("utf-8", errors="replace").strip()
                    if not line:
                        continue
                    if line == cmd or line == cmd_to_send.strip():
                        continue
                    lines.append(line)
                    if is_query:
                        return line
                    elif sync_mode:
                        if line == "1":
                            return get_command_confirmation(cmd)
                        elif line.startswith("-") or "error" in line.lower():
                            return line
                    else:
                        time.sleep(0.1)
                        if not ser.in_waiting:
                            return line if lines else get_command_confirmation(cmd)
                except Exception as e:
                    if attempt == retry_count - 1:
                        print(f"Error reading response: {e}")
                    break
            time.sleep(0.01)

        if lines:
            return "\n".join(lines)
        if attempt < retry_count - 1:
            time.sleep(0.2)

    return None


# ===================================================================
# Help text
# ===================================================================
def print_help() -> None:
    """Print common SCPI commands."""
    print(f"\n{BOLD}{CYAN}Common SCPI Commands:{RESET}")

    print(f"\n  {BOLD}{YELLOW}Standard Commands (IEEE-488.2):{RESET}")
    print(f"    {GREEN}*IDN?{RESET}           - Get device identification")
    print(f"    {GREEN}*RST{RESET}            - Reset device")
    print(f"    {GREEN}*CLS{RESET}            - Clear status")
    print(f"    {GREEN}*OPC?{RESET}           - Operation complete query")

    print(f"\n  {BOLD}{YELLOW}Temperature Measurement:{RESET}")
    print(f"    {GREEN}:SENS:TEMP?{RESET}     - Read current temperature")
    print(f"    {GREEN}:SENS:ALL?{RESET}      - Read all sensors")
    print(f"    {GREEN}:SENS:COUNT?{RESET}    - Get sensor count")

    print(f"\n  {BOLD}{YELLOW}PID Control:{RESET}")
    print(f"    {GREEN}:PID:SENS <n>{RESET}   - Select sensor (0-3)")
    print(f"    {GREEN}:PID:SETP <t>{RESET}   - Set target temperature (°C)")
    print(f"    {GREEN}:PID:ENAB <0|1>{RESET} - Enable/disable PID")
    print(f"    {GREEN}:PID:STAT?{RESET}      - Get PID status")
    print(f"    {GREEN}:PID:TELE?{RESET}      - Get telemetry")
    print(f"    {GREEN}:PID:TEMPS?{RESET}     - Get all sensor temperatures")

    print(f"\n  {BOLD}{YELLOW}Temperature Ramps:{RESET}")
    print(f"    {GREEN}:PID:RAMP <targ>,<rate>[,<unit>][,<hold>]{RESET}  - Start ramp")
    print(f"    {DIM}                                      unit: MIN (default) or SEC{RESET}")
    print(f"    {DIM}                                      hold: hold time at target (sec){RESET}")
    print(f"    {GREEN}:PID:RAMP:STAT?{RESET}                         - Detailed ramp status")
    print(f"    {GREEN}:PID:RAMP:STOP{RESET}                          - Stop current ramp")

    print(f"\n  {BOLD}{YELLOW}PID Tuning:{RESET}")
    print(f"    {GREEN}:PID:KP <val>{RESET}   - Set proportional gain")
    print(f"    {GREEN}:PID:KI <val>{RESET}   - Set integral gain")
    print(f"    {GREEN}:PID:KD <val>{RESET}   - Set derivative gain")
    print(f"    {GREEN}:PID:TUNE?{RESET}      - Query all tuning parameters")
    print(f"    {GREEN}:PID:RES{RESET}        - Reset PID (clear integral term)")

    print(f"\n  {BOLD}{YELLOW}TEC Control:{RESET}")
    print(f"    {GREEN}:TEC:OUTP <-1..1>{RESET} - Set TEC output (normalized)")
    print(f"    {GREEN}:TEC:OUTP?{RESET}         - Query TEC output")
    print(f"    {GREEN}:TEC:STOP{RESET}           - Stop TEC (set to 0)")

    print(f"\n  {BOLD}{YELLOW}System:{RESET}")
    print(f"    {GREEN}:SYST:USB:MODE <mode>{RESET}  - Set USB mode (PROD/DEBUG/DEV)")
    print(f"    {GREEN}:SYST:ERR?{RESET}             - Get last error")
    print(f"    {GREEN}:SYST:LOG? [n]{RESET}         - Get system log (last n lines)")

    print(f"\n  {BOLD}{YELLOW}WiFi (if available):{RESET}")
    print(f"    {GREEN}:WIFI:CONN?{RESET}     - WiFi connection status")
    print(f"    {GREEN}:WIFI:IP?{RESET}       - IP address")
    print(f"    {GREEN}:WIFI:STATUS?{RESET}   - Full WiFi status")

    print(f"\n  {BOLD}{YELLOW}Local Commands:{RESET}")
    print(f"    {MAGENTA}help{RESET}         - Show this help")
    print(f"    {MAGENTA}list{RESET}         - List tab-completion commands")
    print(f"    {MAGENTA}sync/nosync{RESET}  - Toggle OPC synchronization")
    print(f"    {MAGENTA}pretty/raw_response{RESET} - Toggle pretty formatting")
    print(f"    {MAGENTA}status{RESET}       - Show current settings")
    print(f"    {MAGENTA}raw{RESET}          - Monitor raw serial data (5 s)")
    print(f"    {MAGENTA}exit{RESET}         - Exit interactive mode")

    print(f"\n  {BOLD}{CYAN}OPC Synchronization:{RESET}")
    print(f"    {DIM}When enabled (default), non-query commands wait for *OPC?{RESET}")
    print(f"    {DIM}response to ensure completion before returning.{RESET}")
    print()


# ===================================================================
# Interactive REPL
# ===================================================================
# Comprehensive tab-completion list
SCPI_COMMANDS = [
    "*IDN?", "*RST", "*CLS", "*OPC?", "*OPC", "*ESR?", "*ESE", "*ESE?",
    "*STB?", "*SRE", "*SRE?", "*TST?", "*WAI",
    ":SENS:TEMP?", ":SENS:ALL?", ":SENS:RAW?", ":SENS:SER?",
    ":SENS:MEAS?", ":SENS:INIT", ":SENS:RESET",
    ":SENS:SYNC?", ":SENS:SYNC? 1", ":SENS:SYNC? 8", ":SENS:SYNC? 32", ":SENS:SYNC? 64",
    ":SENS:COUNT?",
    ":SENS1:TEMP?", ":SENS1:RAW?", ":SENS1:SER?", ":SENS1:MEAS?",
    ":SENS2:TEMP?", ":SENS2:RAW?", ":SENS2:SER?", ":SENS2:MEAS?",
    ":SENS3:TEMP?", ":SENS3:RAW?", ":SENS3:SER?", ":SENS3:MEAS?",
    ":SENS4:TEMP?", ":SENS4:RAW?", ":SENS4:SER?", ":SENS4:MEAS?",
    ":CONF:HIGH", ":CONF:HIGH?", ":CONF:LOW", ":CONF:LOW?",
    ":CONF:TEMP:OFFS", ":CONF:TEMP:OFFS?",
    ":CONF:ALRT:MODE", ":CONF:ALRT:MODE?",
    ":CONF:MEAS:AVG", ":CONF:MEAS:AVG?",
    ":CONF:MEAS:DEL", ":CONF:MEAS:DEL?",
    ":CONF:MEAS:MODE", ":CONF:MEAS:MODE?",
    ":PID:SENS", ":PID:SENS?", ":PID:SENSOR", ":PID:SENSOR?",
    ":PID:SENS:COUN?", ":PID:SENS:COUNT?", ":PID:SENSOR:COUNT?",
    ":PID:SETP", ":PID:SETP?", ":PID:SETPOINT", ":PID:SETPOINT?",
    ":PID:ENAB", ":PID:ENAB?", ":PID:ENABLE", ":PID:ENABLE?",
    ":PID:ENAB ON", ":PID:ENAB OFF", ":PID:ENAB 1", ":PID:ENAB 0",
    ":PID:STAT?", ":PID:STATUS?",
    ":PID:TELE?", ":PID:TELEMETRY?",
    ":PID:TEMPS?", ":PID:TEMP:ALL?",
    ":PID:KP", ":PID:KP?", ":PID:KI", ":PID:KI?", ":PID:KD", ":PID:KD?",
    ":PID:TUNE", ":PID:TUNE?",
    ":PID:RES", ":PID:RESET",
    ":PID:RAMP", ":PID:RAMP?",
    ":PID:RAMP:STOP", ":PID:RAMP:ABORT",
    ":PID:RAMP:STAT?", ":PID:RAMP:STATUS?",
    ":TEC:OUTP", ":TEC:OUTP?", ":TEC:OUTPUT", ":TEC:OUTPUT?",
    ":TEC:STOP",
    ":SIM:STAT?", ":SIM:STATUS?", ":SIM:RES", ":SIM:RESET",
    ":SYST:ERR?", ":SYST:ERROR?",
    ":SYST:VERS?", ":SYST:VERSION?",
    ":SYST:USB:MODE", ":SYST:USB:MODE?",
    ":SYST:USB:MODE PROD", ":SYST:USB:MODE DEBUG", ":SYST:USB:MODE DEV",
    ":SYST:RES",
    ":SYST:CAL:SAVE", ":SYST:CAL:LOAD", ":SYST:CAL:DEL",
    ":SYST:LOG?", ":SYST:LOG? 50", ":SYST:LOG? 100",
    ":WIFI:ENAB", ":WIFI:ENAB?", ":WIFI:ENABLE", ":WIFI:ENABLE?",
    ":WIFI:CONN?", ":WIFI:CONNECTED?",
    ":WIFI:CONNECT", ":WIFI:DISCONNECT",
    ":WIFI:IP?", ":WIFI:MAC?", ":WIFI:SSID?", ":WIFI:RSSI?",
    ":WIFI:STATUS?", ":WIFI:STAT?",
    ":WIFI:SCAN?", ":WIFI:CHANNEL?",
    ":WIFI:SSID", ":WIFI:PASSWORD", ":WIFI:PASS",
    ":WIFI:HOSTNAME", ":WIFI:HOSTNAME?",
    ":WIFI:AUTOCONNECT", ":WIFI:AUTOCONNECT?",
    ":WIFI:AVAILABLE?",
    ":WIFI:CONFIG:SAVE", ":WIFI:CONFIG:LOAD",
    ":WIFI:NETWORK:ADD", ":WIFI:NETWORK:REMOVE", ":WIFI:NETWORK:LIST?",
    "help", "exit", "quit", "q", "raw", "list", "commands",
    "sync", "nosync", "pretty", "raw_response", "status",
]


def interactive_mode(
    ser, *, sync_mode: bool = True, connection_info: dict | None = None, pretty_print: bool = True
) -> None:
    """Interactive SCPI prompt with history, tab-completion, and pretty output."""
    cur_sync = sync_mode
    cur_pretty = pretty_print

    if connection_info is None:
        if hasattr(ser, "port") and hasattr(ser, "baudrate"):
            connection_info = {"type": "serial", "port": ser.port, "baudrate": ser.baudrate}
        elif hasattr(ser, "host") and hasattr(ser, "tcp_port"):
            connection_info = {"type": "tcp", "host": ser.host, "tcp_port": ser.tcp_port}

    # readline setup
    if READLINE_AVAILABLE:

        def completer(text, state):
            opts = [c for c in SCPI_COMMANDS if c.upper().startswith(text.upper())] if text else list(SCPI_COMMANDS)
            return opts[state] if state < len(opts) else None

        readline.set_completer(completer)
        if USING_LIBEDIT:
            readline.parse_and_bind("bind ^I rl_complete")
        else:
            readline.parse_and_bind("tab: complete")
        readline.set_completer_delims(" \t\n")
        try:
            readline.read_history_file(HISTORY_FILE)
            readline.set_history_length(500)
        except (FileNotFoundError, Exception):
            pass

    print("\n" + "=" * 60)
    print(f"{BOLD}{CYAN}Interactive SCPI Mode (© 2026 Prof. Flavio ABREU ARAUJO){RESET}")
    print("=" * 60)
    if connection_info:
        if connection_info.get("type") == "tcp":
            print(f"{BOLD}Connection:{RESET} {GREEN}TCP{RESET} {connection_info.get('host')}:{connection_info.get('tcp_port')}")
        else:
            print(f"{BOLD}Connection:{RESET} {GREEN}Serial{RESET} {connection_info.get('port')} @ {connection_info.get('baudrate')} baud")
    print(f"{DIM}Type SCPI commands and press Enter.{RESET}")
    print(f"{DIM}Commands: 'help', 'list', 'sync', 'nosync', 'pretty', 'raw_response', 'status', 'exit'{RESET}")
    if READLINE_AVAILABLE:
        print(f"{DIM}Use ↑/↓ arrows for history, Tab for completion.{RESET}")
    sync_str = f"{GREEN}ON{RESET}" if cur_sync else f"{YELLOW}OFF{RESET}"
    pretty_str = f"{GREEN}ON{RESET}" if cur_pretty else f"{YELLOW}OFF{RESET}"
    print(f"{BOLD}OPC Sync Mode:{RESET} {sync_str}  {BOLD}Pretty Print:{RESET} {pretty_str}")
    print("=" * 60 + "\n")

    try:
        while True:
            try:
                # drain buffer before prompt
                if hasattr(ser, "in_waiting") and hasattr(ser, "reset_input_buffer"):
                    time.sleep(0.05)
                    if ser.in_waiting > 0:
                        ser.read(ser.in_waiting)
                    ser.reset_input_buffer()

                command = input("SCPI> ").strip()
                if command:
                    print(f"\033[1A\033[2K{BOLD}{MAGENTA}SCPI>{RESET} {CYAN}{command}{RESET}")
                if not command:
                    continue

                cl = command.lower()
                if cl in ("exit", "quit", "q"):
                    print(f"{YELLOW}Exiting...{RESET}")
                    break
                if cl == "help":
                    print_help()
                    continue
                if cl == "raw":
                    print(f"\n{CYAN}Listening for raw serial data (5 seconds)...{RESET}")
                    print("-" * 60)
                    start = time.time()
                    while time.time() - start < 5:
                        if ser.in_waiting > 0:
                            try:
                                data = ser.read(ser.in_waiting)
                                print(data.decode("utf-8", errors="replace"), end="", flush=True)
                            except Exception:
                                pass
                        time.sleep(0.01)
                    print("\n" + "-" * 60)
                    ser.reset_input_buffer()
                    continue
                if cl in ("list", "commands"):
                    print(f"\n{BOLD}{CYAN}Available SCPI commands for tab completion:{RESET}")
                    print("-" * 60)
                    groups: dict[str, list[str]] = {}
                    for c in sorted(SCPI_COMMANDS):
                        if c.startswith("*"):
                            key = "IEEE-488.2"
                        elif c.startswith(":"):
                            key = c.split(":")[1] if ":" in c[1:] else "Other"
                        else:
                            key = "Local"
                        groups.setdefault(key, []).append(c)
                    for grp in sorted(groups):
                        print(f"\n  {BOLD}{YELLOW}{grp}:{RESET}")
                        cmds = groups[grp]
                        cw = max(len(x) for x in cmds) + 2
                        cols = 80 // cw or 1
                        for i in range(0, len(cmds), cols):
                            row = cmds[i : i + cols]
                            print(f"    {GREEN}" + f"{RESET}  {GREEN}".join(x.ljust(cw - 2) for x in row) + RESET)
                    print()
                    continue
                if cl == "sync":
                    cur_sync = True
                    print(f"{GREEN}OPC synchronization: ON{RESET}")
                    continue
                if cl == "nosync":
                    cur_sync = False
                    print(f"{YELLOW}OPC synchronization: OFF{RESET}")
                    continue
                if cl == "pretty":
                    cur_pretty = True
                    print(f"{GREEN}Pretty print mode: ON{RESET}")
                    continue
                if cl == "raw_response":
                    cur_pretty = False
                    print(f"{YELLOW}Pretty print mode: OFF{RESET}")
                    continue
                if cl == "status":
                    ss = f"{GREEN}ON{RESET}" if cur_sync else f"{YELLOW}OFF{RESET}"
                    ps = f"{GREEN}ON{RESET}" if cur_pretty else f"{YELLOW}OFF{RESET}"
                    print(f"\n{BOLD}Current Settings:{RESET}")
                    print(f"  {BOLD}OPC Sync Mode:{RESET} {ss}")
                    print(f"  {BOLD}Pretty Print:{RESET}  {ps}")
                    if connection_info:
                        if connection_info.get("type") == "tcp":
                            print(f"  {BOLD}Connection:{RESET}    {GREEN}TCP{RESET}")
                            print(f"  {BOLD}Host:{RESET}          {connection_info.get('host')}")
                            print(f"  {BOLD}Port:{RESET}          {connection_info.get('tcp_port')}")
                        else:
                            print(f"  {BOLD}Connection:{RESET}    {GREEN}Serial{RESET}")
                            print(f"  {BOLD}Serial Port:{RESET}   {connection_info.get('port')}")
                            print(f"  {BOLD}Baudrate:{RESET}      {connection_info.get('baudrate')}")
                    continue

                # send the command
                print(f"{BLUE}→{RESET} {CYAN}{command}{RESET}")
                response = send_scpi_command(ser, command, sync_mode=cur_sync)
                if response:
                    if response.startswith("ERROR:") or response.startswith("-"):
                        print(f"{RED}←{RESET} {RED}{response}{RESET}")
                    else:
                        formatted = format_response(command, response, pretty=cur_pretty)
                        if "\n" in formatted:
                            print(f"{GREEN}←{RESET}{formatted}")
                        else:
                            print(f"{GREEN}←{RESET} {YELLOW}{formatted}{RESET}")
                else:
                    print(f"{RED}←{RESET} {DIM}(no response – try 'raw' to see device output){RESET}")
                print()

            except KeyboardInterrupt:
                print(f"\n\n{YELLOW}Interrupted by user. Exiting...{RESET}")
                break
            except EOFError:
                print(f"\n{YELLOW}EOF received. Exiting...{RESET}")
                break
    finally:
        if READLINE_AVAILABLE:
            with contextlib.suppress(Exception):
                readline.write_history_file(HISTORY_FILE)


# ===================================================================
# main() entry-point
# ===================================================================
def main() -> int:
    """CLI entry-point for the ``scpi-client`` command."""
    from . import __version__

    parser = argparse.ArgumentParser(
        description="Send SCPI commands to TMP117 PID Controller",
        epilog=(
            "Examples:\n"
            '  %(prog)s "*IDN?"\n'
            '  %(prog)s ":SENS:TEMP?"\n'
            '  %(prog)s --no-sync ":PID:SETP 25"\n'
            '  %(prog)s -w 192.168.1.100 "*IDN?"   (WiFi)\n'
            "  %(prog)s  (interactive mode)"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("-V", "--version", action="version",
                        version=f"%(prog)s {__version__}")
    parser.add_argument("command", nargs="?", help="SCPI command (omit for interactive mode)")

    conn = parser.add_mutually_exclusive_group()
    conn.add_argument("-p", "--port", help="Serial port path (auto-detects if not specified)")
    conn.add_argument(
        "-w", "--wifi", metavar="HOST[:PORT]",
        help=f"WiFi/TCP connection (default port: {DEFAULT_SCPI_PORT})",
    )

    parser.add_argument("-b", "--baud", type=int, default=115200, help="Baud rate (default: 115200)")
    parser.add_argument("-t", "--timeout", type=float, default=2.0, help="Timeout in seconds (default: 2.0)")
    parser.add_argument("--no-sync", action="store_true", help="Disable OPC synchronization")
    parser.add_argument("--no-pretty", action="store_true", help="Disable pretty printing")

    args = parser.parse_args()
    use_wifi = args.wifi is not None

    # ---- open connection ------------------------------------------------
    if use_wifi:
        host, port = parse_wifi_address(args.wifi)
        print(f"{CYAN}Connecting to {BOLD}{host}:{port}{RESET}{CYAN} via TCP...{RESET}")
        try:
            ser = TCPSocket(host, port, timeout=args.timeout)
            ser.connect()
            print(f"{GREEN}✓ Connected to {BOLD}{host}:{port}{RESET}")
            time.sleep(0.2)
        except OSError as e:
            print(f"\n{RED}✗ Error connecting to {host}:{port}: {e}{RESET}")
            if e.errno == 61 or "Connection refused" in str(e):
                print(f"\n{YELLOW}Connection refused – possible causes:{RESET}")
                print(f"  {DIM}1. TCP SCPI server not enabled in firmware{RESET}")
                print(f"  {DIM}2. Device not reachable at this IP{RESET}")
                print(f"  {DIM}3. Firewall blocking the connection{RESET}")
            return 1
        except Exception as e:
            print(f"\n{RED}✗ Unexpected error: {e}{RESET}")
            return 1
    else:
        if args.port:
            port_path = args.port
            print(f"{CYAN}Using specified port: {BOLD}{port_path}{RESET}")
        else:
            print(f"{CYAN}Auto-detecting CircuitPython device...{RESET}")
            port_path = find_circuitpython_port()
            if not port_path:
                print(f"\n{RED}✗ Could not auto-detect CircuitPython device.{RESET}")
                print(f"{YELLOW}Specify port with --port or use --wifi HOST.{RESET}")
                return 1
            print(f"{GREEN}✓ Found device on: {BOLD}{port_path}{RESET}")

        try:
            ser = serial.Serial(
                port=port_path,
                baudrate=args.baud,
                timeout=args.timeout,
                write_timeout=args.timeout,
            )
            print(f"{DIM}Waiting for device to initialize...{RESET}")
            time.sleep(1.5)

            # drain startup messages
            startup: list[str] = []
            while ser.in_waiting > 0:
                try:
                    line = ser.readline().decode("utf-8", errors="replace").strip()
                    if line:
                        startup.append(line)
                except Exception:
                    break
                time.sleep(0.01)
            if startup:
                print(f"\n{CYAN}Device startup messages:{RESET}")
                for ln in startup[-10:]:
                    print(f"  {DIM}{ln}{RESET}")
                print()
            ser.reset_input_buffer()
            ser.reset_output_buffer()
        except serial.SerialException as e:
            print(f"\n{RED}✗ Error opening serial port: {e}{RESET}")
            return 1

    # ---- send command(s) ------------------------------------------------
    try:
        if args.command:
            print(f"\n{CYAN}Sending:{RESET} {BOLD}{args.command}{RESET}")
            response = send_scpi_command(ser, args.command, args.timeout, sync_mode=not args.no_sync)
            if response:
                if response.startswith("ERROR:") or response.startswith("-"):
                    print(f"{RED}Error:{RESET} {RED}{response}{RESET}")
                    return 1
                formatted = format_response(args.command, response, pretty=not args.no_pretty)
                if "\n" in formatted:
                    print(f"{GREEN}Response:{RESET}{formatted}")
                else:
                    print(f"{GREEN}Response:{RESET} {YELLOW}{formatted}{RESET}")
            else:
                print(f"{RED}(no response){RESET}")
                return 1
        else:
            ci = (
                {"type": "tcp", "host": host, "tcp_port": port}
                if use_wifi
                else {"type": "serial", "port": port_path, "baudrate": args.baud}
            )
            interactive_mode(ser, sync_mode=not args.no_sync, connection_info=ci, pretty_print=not args.no_pretty)
    finally:
        ser.close()

    return 0


if __name__ == "__main__":
    sys.exit(main())
