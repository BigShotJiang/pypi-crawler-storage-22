# Changelog

All notable changes to **temp-logger** will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.2.2] — 2026-02-08

## [0.2.1] — 2026-02-08

## [0.2.0] — 2026-02-08

## [0.1.12] — 2026-02-08

## [0.1.11] — 2026-02-08

### Added in v0.1.11

- `pid-controller-gui` — PID temperature controller GUI with ramp control, tuning,
  TEC power monitoring, and live graphs.
- `scpi-client` — Interactive SCPI terminal with tab-completion, command history,
  pretty-printed output, and OPC synchronization.
- WiFi/TCP support across all four tools (auto-discovery, `wifi_config.txt`).
- `--version` flag on all entry points.
- Dark theme for `temp-logger-gui`.
- Dual-sensor synchronised logging with timing-skew subplot.

### Fixed

- Cross-talk between GUI logger and SCPI console (threading lock).
- Graph reset timing after reconnect.
- TCP server `max_clients=1` on firmware side.
- macOS soft-reboot prevention in `boot.py`.
- WiFi discover retry and serial drain logic.

## [0.1.0] — 2025-12-01

### Added in v0.1.0

- Initial release with `temp-logger` CLI and `temp-logger-gui`.
- CSV logging with automatic timestamped filenames.
- Live matplotlib plots (4 subplots for dual sensor).
- Auto-detection of single vs. dual sensor mode.
- USB serial connection via `SCPISerial`.

[Unreleased]: https://gitlab.flavio.be/flavio/temp-logger/-/compare/v0.2.2...HEAD
[0.2.2]: https://gitlab.flavio.be/flavio/temp-logger/-/compare/v0.2.1...v0.2.2[0.2.1]: https://gitlab.flavio.be/flavio/temp-logger/-/compare/v0.2.0...v0.2.1[0.2.0]: https://gitlab.flavio.be/flavio/temp-logger/-/compare/v0.1.12...v0.2.0[0.1.12]: <https://gitlab.flavio.be/flavio/temp-logger/-/compare/v0.1.11...v0.1.12[0.1.11>]: <https://gitlab.flavio.be/flavio/temp-logger/-/compare/v0.1.10...v0.1.11>
[0.1.0]: <https://gitlab.flavio.be/flavio/temp-logger/-/releases/v0.1.0>
