from .main import (
    prac1,
    prac2,
    prac3,
    prac4,
    prac5,
    prac6,
    prac7,
    prac8,
    prac9,
    prac10
)

__all__ = [
    "prac1",
    "prac2",
    "prac3",
    "prac4",
    "prac5",
    "prac6",
    "prac7",
    "prac8",
    "prac9",
    "prac10"
]
