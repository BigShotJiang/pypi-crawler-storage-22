def prac1():
  print("""

# ---------------------------------------------------
#Practical 1: Acquire and manipulate images (resize, crop,and format conversion) using OpenCV
# ---------------------------------------------------

import cv2
from google.colab.patches import cv2_imshow

# ---------------------------------------
# STEP 1: Image Acquisition
# ---------------------------------------

# Provide correct image path
image_path = 'test.jfif'

# Read the image
image = cv2.imread(image_path)

# Check if image is loaded successfully
if image is None:
    print("Error: Image not found. Please check the file path.")
else:
    # Display original image
    cv2_imshow(image)

    # ---------------------------------------
    # STEP 2: Resize the image
    # ---------------------------------------

    # Set new width
    new_width = 400

    # Calculate aspect ratio
    aspect_ratio = new_width / image.shape[1]

    # Calculate new height
    new_height = int(image.shape[0] * aspect_ratio)

    # Resize image
    resized_image = cv2.resize(image, (new_width, new_height))

    # Display resized image
    cv2_imshow(resized_image)

    # ---------------------------------------
    # STEP 3: Crop the image
    # ---------------------------------------

    # Crop top-left 100x100 pixels
    cropped_image = image[0:100, 0:100]

    # Display cropped image
    cv2_imshow(cropped_image)

    # ---------------------------------------
    # STEP 4: Convert image to Grayscale
    # ---------------------------------------

    # Convert BGR to Grayscale
    gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    # Display grayscale image
    cv2_imshow(gray_image)

    # ---------------------------------------
    # STEP 5: Format Conversion (Save Image)
    # ---------------------------------------

    # Save original image as PNG (format conversion)
    cv2.imwrite('/content/original_image.png', image)

    # Save grayscale image as JPG
    cv2.imwrite('/content/grayscale_image.jpg', gray_image)

    print("Image acquisition and basic processing completed successfully.")


    """)

def prac2():
  print("""

# Practical-2 Histogram Equalization: Enhance image contrast by applying histogram equalization techniques


import cv2
import numpy as np
from google.colab.patches import cv2_imshow

# ---------------------------------------
# STEP 1: Read image in grayscale
# ---------------------------------------

# Provide correct image path
image_path = 'test.jfif'

# Load image directly in grayscale mode
image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)

# Check if image is loaded successfully
if image is None:
    print("Error: Image not found. Please check the file path.")
else:
    # Display original grayscale image
    cv2_imshow(image)

    # ---------------------------------------
    # STEP 2: Apply Histogram Equalization
    # ---------------------------------------

    # Improve contrast using global histogram equalization
    equalized_image = cv2.equalizeHist(image)

    # Display histogram equalized image
    cv2_imshow(equalized_image)

    # ---------------------------------------
    # STEP 3: Save the output image
    # ---------------------------------------

    # Save equalized image to disk
    cv2.imwrite('/content/global_hist_equalized.jpg', equalized_image)

    print("Histogram equalization completed successfully.")

    """)

def prac3():
  print("""

# ---------------------------------------------------
# Practical 3 : Image Filtering and Edge Detection using OpenCV
# Apply filters and detect edges using
# Sobel and Canny methods
# ---------------------------------------------------

import cv2
import numpy as np
from google.colab.patches import cv2_imshow

# ---------------------------------------
# STEP 1: Read image in grayscale
# ---------------------------------------

image_path = 'test.jfif'

# Load image in grayscale
img = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)

# Check if image is loaded successfully
if img is None:
    print("Error: Image not found. Please check the file path.")
else:
    print("Original Grayscale Image:")
    cv2_imshow(img)

    # ---------------------------------------
    # STEP 2: Apply Gaussian Blur (Filtering)
    # ---------------------------------------

    print("Blurred Image (Gaussian Filter Applied):")
    blurred_img = cv2.GaussianBlur(img, (5, 5), 0)
    cv2_imshow(blurred_img)

    # ---------------------------------------
    # STEP 3: Sobel Edge Detection
    # ---------------------------------------

    print("Sobel Edge Detection (X and Y Combined):")
    sobel_x = cv2.Sobel(blurred_img, cv2.CV_64F, 1, 0, ksize=5)
    sobel_y = cv2.Sobel(blurred_img, cv2.CV_64F, 0, 1, ksize=5)

    sobel_combined = cv2.addWeighted(
        np.absolute(sobel_x), 0.5,
        np.absolute(sobel_y), 0.5,
        0
    )

    cv2_imshow(sobel_combined)

    # ---------------------------------------
    # STEP 4: Canny Edge Detection
    # ---------------------------------------

    print("Canny Edge Detection Output:")
    canny_edges = cv2.Canny(blurred_img, 100, 200)
    cv2_imshow(canny_edges)

    print("Image filtering and edge detection completed successfully.")

    """)

def prac4():
  print("""

# ---------------------------------------------------
# Practical 4: Image Segmentation using OpenCV
# Aim: Segment images using global thresholding,
#      adaptive thresholding, and K-means clustering
# ---------------------------------------------------

import cv2
import numpy as np
from matplotlib import pyplot as plt
from sklearn.cluster import KMeans

# ---------------------------------------
# 1. Global Thresholding
# ---------------------------------------

def global_thresholding(image_path, threshold_value=127):
    # Read image in grayscale
    img = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)

    # Apply global thresholding
    _, thresh = cv2.threshold(img, threshold_value, 255, cv2.THRESH_BINARY)
    return thresh

# ---------------------------------------
# 2. Adaptive Thresholding
# ---------------------------------------

def adaptive_thresholding(image_path, block_size=11, C=2):
    # Read image in grayscale
    img = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)

    # Apply adaptive thresholding
    thresh = cv2.adaptiveThreshold(
        img, 255,
        cv2.ADAPTIVE_THRESH_MEAN_C,
        cv2.THRESH_BINARY,
        block_size, C
    )
    return thresh

# ---------------------------------------
# 3. K-Means Clustering Segmentation
# ---------------------------------------

def kmeans_segmentation(image_path, num_clusters=3):
    # Read image in color
    img = cv2.imread(image_path)
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

    # Reshape image to a 2D array of pixels
    pixels = img.reshape((-1, 3))
    pixels = np.float32(pixels)

    # Apply K-Means clustering
    kmeans = KMeans(n_clusters=num_clusters, random_state=0)
    labels = kmeans.fit_predict(pixels)

    # Replace pixel values with cluster centers
    segmented_pixels = kmeans.cluster_centers_[labels]
    segmented_image = segmented_pixels.reshape(img.shape).astype(np.uint8)

    return segmented_image

# ---------------------------------------
# Example Usage
# ---------------------------------------

image_path = 'original_image.png'  # Replace with your image path

# Global Thresholding
print("Global Thresholding Output:")
global_img = global_thresholding(image_path)
plt.imshow(global_img, cmap='gray')
plt.title('Global Thresholding')
plt.axis('off')
plt.show()

# Adaptive Thresholding
print("Adaptive Thresholding Output:")
adaptive_img = adaptive_thresholding(image_path)
plt.imshow(adaptive_img, cmap='gray')
plt.title('Adaptive Thresholding')
plt.axis('off')
plt.show()

# K-Means Segmentation
print("K-Means Clustering Output:")
kmeans_img = kmeans_segmentation(image_path)
plt.imshow(kmeans_img)
plt.title('K-Means Segmentation')
plt.axis('off')
plt.show()
""")

def prac5():
  print("""

#Pracitcal 5: Feature Extraction and Matching: Extract keypoints and match features between images using SIFT or ORB.
import cv2
import matplotlib.pyplot as plt

# -------------------------------
# Step 1: Read images in grayscale
# -------------------------------
img1 = cv2.imread('grayscale_image.jpg', cv2.IMREAD_GRAYSCALE)
img2 = cv2.imread('original_image.png', cv2.IMREAD_GRAYSCALE)

# -------------------------------
# PART A: SIFT Feature Matching
# -------------------------------

# Create SIFT detector
sift = cv2.SIFT_create()

# Detect keypoints and compute descriptors
kp1, des1 = sift.detectAndCompute(img1, None)
kp2, des2 = sift.detectAndCompute(img2, None)

# Create Brute Force matcher (L2 norm for SIFT)
bf = cv2.BFMatcher(cv2.NORM_L2, crossCheck=True)

# Match descriptors
matches = bf.match(des1, des2)

# Sort matches based on distance (best matches first)
matches = sorted(matches, key=lambda x: x.distance)

# Draw top 50 matches
sift_matches = cv2.drawMatches(
    img1, kp1, img2, kp2, matches[:50], None,
    flags=cv2.DrawMatchesFlags_NOT_DRAW_SINGLE_POINTS
)

# Display result
plt.figure(figsize=(10, 6))
plt.imshow(sift_matches, cmap='gray')
plt.title("SIFT Feature Matching")
plt.axis('off')
plt.show()

# -------------------------------
# PART B: ORB Feature Matching
# -------------------------------

# Create ORB detector
orb = cv2.ORB_create()

# Detect keypoints and compute descriptors
kp1, des1 = orb.detectAndCompute(img1, None)
kp2, des2 = orb.detectAndCompute(img2, None)

# Create Brute Force matcher (Hamming norm for ORB)
bf = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True)

# Match descriptors
matches = bf.match(des1, des2)

# Sort matches by distance
matches = sorted(matches, key=lambda x: x.distance)

# Draw top 50 matches
orb_matches = cv2.drawMatches(
    img1, kp1, img2, kp2, matches[:50], None,
    flags=cv2.DrawMatchesFlags_NOT_DRAW_SINGLE_POINTS
)

# Display result
plt.figure(figsize=(10, 6))
plt.imshow(orb_matches, cmap='gray')
plt.title("ORB Feature Matching")
plt.axis('off')
plt.show()


  """)

def prac6():
  print("""

# Practical 6: Image Transformation and Morphology: Perform Fourier/Wavelet transforms and apply morphological operations.

import cv2
import numpy as np
import matplotlib.pyplot as plt
import pywt

print("Practical : Image Transformation and Morphology")
print("--------------------------------------------------")

# -------------------------------
# Step 1: Load Image
# -------------------------------
print("Loading image in grayscale...")
img = cv2.imread('/content/field-6574455_640.jpg', cv2.IMREAD_GRAYSCALE)

if img is None:
    print("Error: Image not found.")
    exit()

print("Image loaded successfully.")

# ==================================================
# PART A: Fourier Transform
# ==================================================
print("\nPerforming Fourier Transform...")

# Apply Discrete Fourier Transform
dft = cv2.dft(np.float32(img), flags=cv2.DFT_COMPLEX_OUTPUT)

# Shift zero frequency to center
dft_shift = np.fft.fftshift(dft)

# Compute magnitude spectrum
magnitude_spectrum = 20 * np.log(
    cv2.magnitude(dft_shift[:, :, 0], dft_shift[:, :, 1])
)

print("Fourier Transform completed.")

# Display Fourier results
plt.figure(figsize=(10, 6))
plt.subplot(121)
plt.imshow(img, cmap='gray')
plt.title("Original Image")

plt.subplot(122)
plt.imshow(magnitude_spectrum, cmap='gray')
plt.title("Magnitude Spectrum")
plt.show()

# ==================================================
# PART B: Wavelet Transform
# ==================================================
print("\nPerforming Wavelet Transform using Haar wavelet...")

# Apply Discrete Wavelet Transform
coeffs = pywt.dwt2(img, 'haar')
LL, (LH, HL, HH) = coeffs

print("Wavelet decomposition completed.")

# Display Wavelet components
plt.figure(figsize=(10, 6))

plt.subplot(221)
plt.imshow(LL, cmap='gray')
plt.title("Approximation (LL)")

plt.subplot(222)
plt.imshow(LH, cmap='gray')
plt.title("Horizontal Detail (LH)")

plt.subplot(223)
plt.imshow(HL, cmap='gray')
plt.title("Vertical Detail (HL)")

plt.subplot(224)
plt.imshow(HH, cmap='gray')
plt.title("Diagonal Detail (HH)")

plt.show()

# ==================================================
# PART C: Morphological Operations
# ==================================================
print("\nApplying Morphological Operations...")

# Define kernel
kernel = np.ones((5, 5), np.uint8)
print("Structuring element (5x5 kernel) created.")

# Erosion
erosion = cv2.erode(img, kernel, iterations=1)
print("Erosion operation applied.")

# Dilation
dilation = cv2.dilate(img, kernel, iterations=1)
print("Dilation operation applied.")

# Display Morphology results
plt.figure(figsize=(10, 6))

plt.subplot(121)
plt.imshow(erosion, cmap='gray')
plt.title("Erosion")

plt.subplot(122)
plt.imshow(dilation, cmap='gray')
plt.title("Dilation")

plt.show()

print("\nPractical execution completed successfully.")
""")

def prac7():
  print("""
import cv2
import os

print("Practical No. 7: Video Capture and Frame Extraction")
print("--------------------------------------------------")

def extract_frames(video_path, output_dir, frame_interval):
    #Captures video and extracts frames at regular intervals.

    #Parameters:
    #video_path     : Path of the input video file
    #output_dir     : Folder to store extracted frames
    #frame_interval : Number of frames to skip between extractions


    # Create output directory if it does not exist
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
        print(f"Output directory created: {output_dir}")

    # Open video file
    cap = cv2.VideoCapture(video_path)

    if not cap.isOpened():
        print("Error: Unable to open video file.")
        return

    print("Video opened successfully.")
    frame_count = 0
    saved_count = 0

    # Read video frame by frame
    while True:
        ret, frame = cap.read()

        # Stop if video ends
        if not ret:
            print("End of video reached.")
            break

        # Extract frame at given interval
        if frame_count % frame_interval == 0:
            frame_name = f"frame_{frame_count}.jpg"
            output_path = os.path.join(output_dir, frame_name)
            cv2.imwrite(output_path, frame)
            saved_count += 1
            print(f"Saved: {frame_name}")

        frame_count += 1

    # Release video object
    cap.release()
    cv2.destroyAllWindows()

    print(f"\nTotal frames processed: {frame_count}")
    print(f"Total frames saved: {saved_count}")
    print("Frame extraction completed successfully.")

# -------------------------------
# Example Usage
# -------------------------------

video_path = "sample-mp4-file.mp4"   # Input video path
output_dir = "/content/extracted_frames_2"             # Output folder
frame_interval = 30                                    # Extract every 30th frame

extract_frames(video_path, output_dir, frame_interval)

  """)

def prac8():
  print("""
import cv2
from google.colab.patches import cv2_imshow
import numpy as np

print("Practical 8: Motion Detection and Optical Flow")
print("--------------------------------------------")

# -------------------------------
# Step 1: Load video
# -------------------------------
video_path = 'sample-mp4-file.mp4'
cap = cv2.VideoCapture(video_path)

if not cap.isOpened():
    print("Error: Unable to open video file.")
    exit()

print("Video loaded successfully.")

# -------------------------------
# Step 2: Background Subtractor
# -------------------------------
print("Initializing Background Subtractor (MOG2)...")
bg_subtractor = cv2.createBackgroundSubtractorMOG2(
    history=500,
    varThreshold=16,
    detectShadows=True
)

# -------------------------------
# Step 3: Read first frame for Optical Flow
# -------------------------------
ret, first_frame = cap.read()
gray_prev = cv2.cvtColor(first_frame, cv2.COLOR_BGR2GRAY)

frame_count = 0

# -------------------------------
# Step 4: Process video frames
# -------------------------------
while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        print("End of video reached.")
        break

    frame_count += 1

    # -------------------------------
    # Motion Detection (Background Subtraction)
    # -------------------------------
    fg_mask = bg_subtractor.apply(frame)

    # -------------------------------
    # Optical Flow (Farneback Method)
    # -------------------------------
    gray_curr = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    flow = cv2.calcOpticalFlowFarneback(
        gray_prev, gray_curr,
        None,
        0.5, 3, 15, 3, 5, 1.2, 0
    )

    # Compute magnitude and angle of motion
    magnitude, angle = cv2.cartToPolar(flow[..., 0], flow[..., 1])

    # Normalize magnitude for display
    mag_display = cv2.normalize(
        magnitude, None, 0, 255, cv2.NORM_MINMAX
    ).astype(np.uint8)

    print(f"Processing frame: {frame_count}")

    # -------------------------------
    # Display results
    # -------------------------------
    print("Foreground Mask (Motion Detection):")
    cv2_imshow(fg_mask)

    print("Optical Flow Magnitude:")
    cv2_imshow(mag_display)

    # Update previous frame
    gray_prev = gray_curr

# -------------------------------
# Step 5: Release resources
# -------------------------------
cap.release()
cv2.destroyAllWindows()

print("Motion detection and optical flow analysis completed.")

""")

def prac9():
  print("""
import cv2
import torch
from google.colab.patches import cv2_imshow

print("Practical 9: Object Detection in Videos using YOLOv5")
#!pip install ultralytics
print("--------------------------------------------------")

# -------------------------------
# Step 1: Load YOLOv5 Model
# -------------------------------
print("Loading YOLOv5 model...")

# Load pre-trained YOLOv5 small model from Torch Hub
model = torch.hub.load('ultralytics/yolov5', 'yolov5s', pretrained=True)

# Set model to evaluation mode
model.eval()

print("YOLOv5 model loaded successfully.")

# -------------------------------
# Step 2: Open Video File
# -------------------------------
video_path = 'sample-mp4-file.mp4'
cap = cv2.VideoCapture(video_path)

if not cap.isOpened():
    print("Error: Unable to open video file.")
    exit()

print("Video opened successfully.")

frame_count = 0

# -------------------------------
# Step 3: Process Video Frames
# -------------------------------
while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        print("End of video reached.")
        break

    frame_count += 1
    print(f"Processing frame {frame_count}")

    # -------------------------------
    # Step 4: Object Detection
    # -------------------------------
    results = model(frame)

    # Render bounding boxes on the frame
    annotated_frame = results.render()[0]

    # -------------------------------
    # Step 5: Display Result
    # -------------------------------
    cv2_imshow(annotated_frame)

# -------------------------------
# Step 6: Release Resources
# -------------------------------
cap.release()
cv2.destroyAllWindows()

print("Object detection completed successfully.")
    """)

def prac10():
  print("""

import cv2
from ultralytics import YOLO
from deep_sort_realtime.deepsort_tracker import DeepSort
from google.colab.patches import cv2_imshow

print("Practical: Multi-Object Tracking using YOLO + Deep SORT")
print("------------------------------------------------------")

# -------------------------------
# Step 1: Load YOLO model
# -------------------------------
print("Loading YOLO model...")
model = YOLO("yolov8n.pt")   # Small & fast YOLO model
print("YOLO model loaded.")

# -------------------------------
# Step 2: Initialize Deep SORT tracker
# -------------------------------
tracker = DeepSort(
    max_age=30,
    n_init=3,
    nn_budget=100
)

print("Deep SORT tracker initialized.")

# -------------------------------
# Step 3: Open video file
# -------------------------------
video_path = "sample-mp4-file.mp4"
cap = cv2.VideoCapture(video_path)

if not cap.isOpened():
    print("Error: Cannot open video.")
    exit()

print("Video opened successfully.")

frame_count = 0

# -------------------------------
# Step 4: Process video frames
# -------------------------------
while True:
    ret, frame = cap.read()
    if not ret:
        print("End of video reached.")
        break

    frame_count += 1
    print(f"Processing frame {frame_count}")

    # -------------------------------
    # Step 5: Object Detection
    # -------------------------------
    results = model(frame)

    detections = []

    # Extract bounding boxes, confidence, and class
    for box in results[0].boxes:
        x1, y1, x2, y2 = map(int, box.xyxy[0])
        conf = float(box.conf[0])
        cls = int(box.cls[0])

        width = x2 - x1
        height = y2 - y1

        # Format: ([x, y, w, h], confidence, class)
        detections.append(([x1, y1, width, height], conf, cls))

    # -------------------------------
    # Step 6: Update tracker
    # -------------------------------
    tracks = tracker.update_tracks(detections, frame=frame)

    # -------------------------------
    # Step 7: Draw tracking results
    # -------------------------------
    for track in tracks:
        if not track.is_confirmed():
            continue

        track_id = track.track_id
        x1, y1, x2, y2 = map(int, track.to_tlbr())

        # Draw bounding box
        cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)

        # Draw track ID
        cv2.putText(
            frame,
            f"ID: {track_id}",
            (x1, y1 - 10),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.6,
            (0, 255, 0),
            2
        )

    # -------------------------------
    # Step 8: Display frame
    # -------------------------------
    cv2_imshow(frame)

# -------------------------------
# Step 9: Release resources
# -------------------------------
cap.release()
cv2.destroyAllWindows()

print("Multi-object tracking completed successfully.")


    """)

