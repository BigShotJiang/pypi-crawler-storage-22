from setuptools import setup, find_packages

setup(
    name="neo32j",
    version="0.2.4",
    packages=find_packages(),
    description="Python package",
    author="fbkebfvbke",
    install_requires=[
        
    ],
    python_requires=">=3.8",
)
