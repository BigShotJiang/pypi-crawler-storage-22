"""CLI module for Neo4j Agent Memory entity extraction."""

from neo4j_agent_memory.cli.main import cli, main

__all__ = ["cli", "main"]
