"""Embedding providers for vector representations."""

from neo4j_agent_memory.embeddings.base import Embedder

__all__ = [
    "Embedder",
]
