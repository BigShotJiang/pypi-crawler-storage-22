"""Claude Code adapter."""
