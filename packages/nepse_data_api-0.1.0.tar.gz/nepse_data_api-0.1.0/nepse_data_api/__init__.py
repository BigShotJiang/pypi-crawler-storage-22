"""
nepse_data - Advanced NEPSE Stock Market Data Library
======================================================

A clean, high-performance Python library for Nepal Stock Exchange (NEPSE) data.

Quick Start:
    >>> from nepse_data import Nepse
    >>> nepse = Nepse()
    >>> stocks = nepse.get_stocks()  # Get all live stocks
    >>> nabil = [s for s in stocks if s['symbol'] == 'NABIL'][0]

Features:
    - Live market data (OHLCV)
    - Sector indices
    - Corporate actions (Dividends, AGM)
    - News & alerts
    - Market depth & floorsheet
    - Built-in caching for performance
"""

from .market import Nepse, AsyncNepse
from .version import __version__

__author__ = "NEPSE Core Contributors"
__all__ = ["Nepse", "AsyncNepse"]
