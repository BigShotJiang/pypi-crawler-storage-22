import pytest
from unittest.mock import MagicMock, patch
from nepse_data_api.market import Nepse

class TestNepseMarket:
    
    @patch('nepse_data.market.requests.Session')
    def test_market_status(self, mock_session, mock_market_status):
        """Test fetching market status"""
        # Setup mock
        mock_instance = mock_session.return_value
        mock_instance.get.return_value.json.return_value = mock_market_status
        mock_instance.get.return_value.status_code = 200
        
        # Bypass forced authentication in __init__ for this test
        with patch.object(Nepse, 'authenticate'):
            nepse = Nepse()
            # Manually set token to avoid auth call
            nepse.access_token = "dummy"
            
            status = nepse.get_market_status()
            assert status['isOpen'] == "OPEN"
            assert status['asOf'] == "2026-02-15T12:00:00"

    @patch('nepse_data.market.requests.Session')
    def test_caching(self, mock_session):
        """Test that caching works"""
        mock_instance = mock_session.return_value
        mock_instance.get.return_value.json.return_value = {"data": "test"}
        mock_instance.get.return_value.status_code = 200
        
        with patch.object(Nepse, 'authenticate'):
            nepse = Nepse(enable_cache=True)
            nepse.access_token = "dummy"
            
            # First call - hits API
            nepse.get_market_summary()
            assert mock_instance.get.call_count == 1
            
            # Second call - should hit cache
            nepse.get_market_summary()
            assert mock_instance.get.call_count == 1
