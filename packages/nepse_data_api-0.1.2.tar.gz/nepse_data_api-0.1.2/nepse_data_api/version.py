"""Version information for nepse-data package."""

__version__ = "0.1.2"
