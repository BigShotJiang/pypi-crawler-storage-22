from setuptools import setup, find_packages
import os

# Read version from version.py
version = {}
with open(os.path.join("nepse_data_api", "version.py")) as f:
    exec(f.read(), version)

with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="nepse-data-api",
    version=version['__version__'],
    author="Rabin Katel",
    author_email="kattelrabinraja13@gmail.com",
    description="High-performance Python library for Nepal Stock Exchange (NEPSE) data",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/ra8in/nepse_data_api",
    project_urls={
        "Bug Tracker": "https://github.com/ra8in/nepse_data_api/issues",
        "Documentation": "https://github.com/ra8in/nepse_data_api#readme",
        "Source Code": "https://github.com/ra8in/nepse_data_api",
    },
    packages=find_packages(exclude=["tests", "examples", "docs"]),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: Financial and Insurance Industry",
        "Topic :: Office/Business :: Financial :: Investment",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    python_requires=">=3.8",
    install_requires=[
        "requests>=2.31.0",
        "pywasm>=1.0.8",
        "aiohttp>=3.9.0",
        "websockets>=10.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.4.0",
            "black>=23.0.0",
            "mypy>=1.5.0",
            "flake8>=6.0.0",
        ],
    },
    include_package_data=True,
    package_data={
        "nepse_data_api": ["assets/*.wasm"],
    },
    entry_points={
        "console_scripts": [
            "nepse=nepse_data_api.cli:main",
        ],
    },
    keywords=[
        "nepse",
        "nepal",
        "stock",
        "market",
        "finance",
        "trading",
        "data",
        "api",
        "share",
        "investment",
    ],
    license="MIT",
)
