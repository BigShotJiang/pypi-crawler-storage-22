Examples of use of different clustering recognition with different search methods.
For SLICE_SAMPLING, the cluster recognition is triggered periodically. For RANDOM_WALK is triggered when the efficiency for finding new live points is too low


Reference name of the example: 4gauss