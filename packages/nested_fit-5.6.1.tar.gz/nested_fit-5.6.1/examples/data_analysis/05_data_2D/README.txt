2D fit of a Gaussian on simulated data with characteristics

# Size
12x8

# Parameters
x0 = 1.5
y0 = 5.5
xsigma = 1
ysigma = 0.5
counts_peak = 1000
peak_to_background = 10

Reference name of the example: synthetic_gauss_2D