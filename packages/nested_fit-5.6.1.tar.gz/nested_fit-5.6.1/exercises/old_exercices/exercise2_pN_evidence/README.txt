From the present input file, construct two new files with

1) an additional peak between channels 235 and 245 (small range)
2) an additional peak between channels 200 and 245 (large range)


A) From the analysis without additional peak and with additional peak in a SMALL range what we can conclude? 

B) Evaluate the position of the mean peak using the two models outputs

C) From the analysis without additional peak and with additional peak in a LARGE range what we can conclude? 

D) What are the values of the complexity? What can we conclude?

E) Evaluate the position of the mean peak using the two models outputs

