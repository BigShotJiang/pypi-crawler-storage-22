import copy
import heapq
import math

from ..networkclass.mesonet import MesoNode, MesoLink, MesoNetwork
from ..networkclass.micronet import MicroNode, MicroLink, MicroNetwork
from ..utils.util_geo import offsetLine
from .. import settings as og_settings
from shapely import geometry
import sys


class NetGenerator:
    def __init__(self, macronet, generate_micro_net, exclusive_bike_walk_lanes, length_of_cell, width_of_lane):
        self.macronet = macronet
        self.generate_micro_net = generate_micro_net
        self.exclusive_bike_walk_lanes = False
        self.length_of_cell = length_of_cell
        self.width_of_lane = width_of_lane
        self._alignment_nodes = 8
        # Keep connector in micronet, but do not split connector into many cells.
        self._generate_connector_micro = True

        self.bike_lane_width = 0.5
        self.walk_lane_width = 0.5

        self.mesonet = MesoNetwork()
        self.micronet = MicroNetwork() if generate_micro_net else None

        self.number_of_expanded_mesonode = {}

    def getMultimoalUse(self, allowed_uses):
        if self.exclusive_bike_walk_lanes:
            if len(allowed_uses) <= 1:
                return {'mainlane_allowed_uses': allowed_uses, 'extra_bike': False, 'extra_walk': False}
            else:
                allowed_uses_set = set(allowed_uses).union({'auto','bike','walk'})
                if allowed_uses_set == {'auto','bike'}:
                    return {'mainlane_allowed_uses':['auto'], 'extra_bike':True, 'extra_walk':False}
                elif allowed_uses_set == {'auto','walk'}:
                    return {'mainlane_allowed_uses':['auto'], 'extra_bike':False, 'extra_walk':True}
                elif allowed_uses_set == {'bike','walk'}:
                    return {'mainlane_allowed_uses':['bike'], 'extra_bike':False, 'extra_walk':True}
                elif allowed_uses_set == {'auto','bike','walk'}:
                    return {'mainlane_allowed_uses':['auto'], 'extra_bike':True, 'extra_walk':True}
        else:
            return {'mainlane_allowed_uses':allowed_uses, 'extra_bike':False, 'extra_walk':False}

    def getLaneGeometry(self, original_geometry, lane_offset):
        if lane_offset < -1e-3 or lane_offset > 1e-3:

            lane_geometry_xy = original_geometry.offset_curve(distance=-1*lane_offset, join_style=2)
            if isinstance(lane_geometry_xy, geometry.MultiLineString):
                lane_geometry_xy = offsetLine(original_geometry, lane_offset)

            if lane_geometry_xy.is_empty:
                return self.getLaneGeometry(original_geometry, lane_offset*0.6)

            return lane_geometry_xy

        else:
            return copy.copy(original_geometry)

    def _movementAngleDeg(self, ib_mesolink, ob_mesolink):
        start_dir = self._lineEndDirection(ib_mesolink.geometry_xy) if ib_mesolink is not None else None
        end_dir = self._lineStartDirection(ob_mesolink.geometry_xy) if ob_mesolink is not None else None
        if start_dir is None or end_dir is None:
            return 180.0
        dot = max(-1.0, min(1.0, start_dir[0] * end_dir[0] + start_dir[1] * end_dir[1]))
        return math.degrees(math.acos(dot))

    def _isRampMovementByTopology(self, node, mvmt, ib_link, ob_link, ib_mesolink, ob_mesolink):
        # Signalized intersections are excluded from ramp alignment.
        if (node.ctrl_type or '').lower() == 'signal':
            return False

        incoming = len(node.incoming_link_list)
        outgoing = len(node.outgoing_link_list)
        is_merge = (incoming > 1 and outgoing == 1)
        is_diverge = (incoming == 1 and outgoing > 1)
        if not (is_merge or is_diverge):
            return False

        ib_lanes = ib_mesolink.lanes if ib_mesolink is not None else ib_link.outgoing_lanes
        ob_lanes = ob_mesolink.lanes if ob_mesolink is not None else ob_link.incoming_lanes
        if ib_lanes is None or ob_lanes is None or ib_lanes <= 0 or ob_lanes <= 0:
            return False

        start_ib = mvmt.start_ib_lane_seq_no
        end_ib = mvmt.start_ib_lane_seq_no + mvmt.lanes - 1
        start_ob = mvmt.start_ob_lane_seq_no
        end_ob = mvmt.start_ob_lane_seq_no + mvmt.lanes - 1

        ib_outer = (start_ib == 0) or (end_ib == ib_lanes - 1)
        ob_outer = (start_ob == 0) or (end_ob == ob_lanes - 1)
        small_mapped_lanes = mvmt.lanes <= 2

        if is_merge:
            ramp_like = small_mapped_lanes and ob_outer and (ib_lanes < ob_lanes)
        else:
            ramp_like = small_mapped_lanes and ib_outer and (ib_lanes > ob_lanes)
        if not ramp_like:
            return False

        # Ramp-like connectors are usually shallow to medium angle.
        return self._movementAngleDeg(ib_mesolink, ob_mesolink) <= 70.0

    def _getAlignmentMode(self, node, mvmt, ib_link, ob_link, ib_mesolink, ob_mesolink):
        if self._isRampMovementByTopology(node, mvmt, ib_link, ob_link, ib_mesolink, ob_mesolink):
            return 'ramp'

        # Signalized intersections should rely on movement connectors only.
        # Applying lane-transition translation repeatedly at signals can
        # over-shift downstream links and corrupt local topology.
        if (node.ctrl_type or '').lower() == 'signal':
            return 'none'

        # Mainline lane transition alignment only applies to thru movements.
        is_thru = (mvmt.type or '').lower() == 'thru'
        if is_thru and ib_link.outgoing_lanes != ob_link.incoming_lanes:
            return 'lane_transition'

        return 'none'

    def _shouldPropagateEqualLaneShift(self, node, mvmt, ib_link, ob_link, ib_mesolink, ob_mesolink):
        # Only for simple 1->1 continuity where lane mapping is full-lane straight-through.
        if (node.ctrl_type or '').lower() == 'signal':
            return False
        if len(node.incoming_link_list) != 1 or len(node.outgoing_link_list) != 1:
            return False
        if ib_link.outgoing_lanes != ob_link.incoming_lanes:
            return False
        if ib_link.outgoing_lanes <= 0 or ob_link.incoming_lanes <= 0:
            return False
        if mvmt.lanes != ib_link.outgoing_lanes:
            return False
        if mvmt.start_ib_lane_seq_no != 0 or mvmt.start_ob_lane_seq_no != 0:
            return False
        return self._movementAngleDeg(ib_mesolink, ob_mesolink) <= 20.0

    def _isPrimaryLaneTransitionAtMerge(self, node, mvmt, ib_link, ob_link, ib_mesolink, ob_mesolink):
        # Mainline-like lane transition at merge: keep downstream translation enabled.
        if len(node.incoming_link_list) <= 1 or len(node.outgoing_link_list) != 1:
            return False
        if ib_link.outgoing_lanes is None or ob_link.incoming_lanes is None:
            return False
        if ib_link.outgoing_lanes <= 0 or ob_link.incoming_lanes <= 0:
            return False
        if ib_link.outgoing_lanes > ob_link.incoming_lanes:
            return False
        if mvmt.start_ib_lane_seq_no != 0 or mvmt.start_ob_lane_seq_no != 0:
            return False
        if mvmt.lanes != ib_link.outgoing_lanes:
            return False
        return self._movementAngleDeg(ib_mesolink, ob_mesolink) <= 25.0

    def _getAdaptiveRampAlignmentNodes(self, node, mvmt, ib_link, ob_link, ib_mesolink, ob_mesolink):
        # Internal adaptive replacement for fixed num_nodes_for_ramp_alignment.
        if not self._isRampMovementByTopology(node, mvmt, ib_link, ob_link, ib_mesolink, ob_mesolink):
            return 0

        angle = self._movementAngleDeg(ib_mesolink, ob_mesolink)
        if angle <= 8.0:
            angle_bonus = 3
        elif angle <= 20.0:
            angle_bonus = 2
        elif angle <= 35.0:
            angle_bonus = 1
        elif angle <= 50.0:
            angle_bonus = 0
        else:
            angle_bonus = -1

        ib_lanes = ib_link.outgoing_lanes or 0
        ob_lanes = ob_link.incoming_lanes or 0
        lane_delta = abs(ob_lanes - ib_lanes)
        lane_delta_bonus = 3 if lane_delta >= 3 else (2 if lane_delta >= 2 else (1 if lane_delta >= 1 else 0))
        mapped_lane_bonus = 2 if mvmt.lanes == 1 else (1 if mvmt.lanes == 2 else 0)
        merge_bonus = 1 if len(node.incoming_link_list) > len(node.outgoing_link_list) else 0

        base_nodes = 8
        raw_nodes = base_nodes + angle_bonus + lane_delta_bonus + mapped_lane_bonus + merge_bonus

        # Normalize by cell size so behavior is stable across length_of_cell changes.
        cell_scale = 7.0 / max(self.length_of_cell, 1e-6)
        cell_scale = max(0.80, min(1.30, cell_scale))
        adapted_nodes = int(round(raw_nodes * cell_scale))
        return max(6, min(18, adapted_nodes))

    def _buildOrderedMovementTasks(self):
        """
        Build movement processing order by link dependency:
        movement A precedes movement B when A.ob_link == B.ib_link.
        Fallback to original order for cyclic components.
        """
        tasks = []
        index_by_mvmt = {}
        mvmt_by_idx = {}
        incoming_map = {}
        node_priority_sequences = []

        for macronode in self.macronet.node_dict.values():
            movement_list = list(macronode.movement_list)
            is_merge_node = (len(macronode.incoming_link_list) > 1 and len(macronode.outgoing_link_list) == 1)
            node_has_ramp_movement = False
            if is_merge_node and (not macronode.movement_link_needed):
                for mv in movement_list:
                    ib_meso = mv.ib_link.mesolink_list[-1] if mv.ib_link.mesolink_list else None
                    ob_meso = mv.ob_link.mesolink_list[0] if mv.ob_link.mesolink_list else None
                    if self._isRampMovementByTopology(macronode, mv, mv.ib_link, mv.ob_link, ib_meso, ob_meso):
                        node_has_ramp_movement = True
                        break
            if is_merge_node and (not macronode.movement_link_needed) and node_has_ramp_movement:
                # In merge nodes without movement mesolinks, process mainline-like movement first.
                movement_list.sort(key=lambda m: (
                    0 if self._isPrimaryLaneTransitionAtMerge(
                        macronode, m, m.ib_link, m.ob_link,
                        m.ib_link.mesolink_list[-1] if m.ib_link.mesolink_list else None,
                        m.ob_link.mesolink_list[0] if m.ob_link.mesolink_list else None
                    ) else 1,
                    -m.lanes,
                    m.start_ob_lane_seq_no,
                    m.movement_id
                ))
                node_priority_sequences.append(list(movement_list))
            for mvmt in movement_list:
                idx = len(tasks)
                tasks.append((macronode, mvmt))
                index_by_mvmt[mvmt] = idx
                mvmt_by_idx[idx] = (macronode, mvmt)
                incoming_map.setdefault(mvmt.ib_link.link_id, []).append(mvmt)

        if not tasks:
            return tasks

        indegree = {idx: 0 for idx in range(len(tasks))}
        outgoing = {idx: [] for idx in range(len(tasks))}
        edge_set = set()

        for _, mvmt in tasks:
            src_idx = index_by_mvmt[mvmt]
            for nxt_mvmt in incoming_map.get(mvmt.ob_link.link_id, []):
                dst_idx = index_by_mvmt[nxt_mvmt]
                if src_idx == dst_idx:
                    continue
                edge = (src_idx, dst_idx)
                if edge in edge_set:
                    continue
                edge_set.add(edge)
                outgoing[src_idx].append(dst_idx)
                indegree[dst_idx] += 1

        # Enforce within-node priority to avoid ramp being built before
        # mainline translation on the same merge node.
        for seq in node_priority_sequences:
            for i in range(len(seq) - 1):
                src_idx = index_by_mvmt[seq[i]]
                dst_idx = index_by_mvmt[seq[i + 1]]
                if src_idx == dst_idx:
                    continue
                edge = (src_idx, dst_idx)
                if edge in edge_set:
                    continue
                edge_set.add(edge)
                outgoing[src_idx].append(dst_idx)
                indegree[dst_idx] += 1

        zero_heap = []
        for idx, deg in indegree.items():
            if deg == 0:
                heapq.heappush(zero_heap, idx)

        ordered_indices = []
        while zero_heap:
            idx = heapq.heappop(zero_heap)
            ordered_indices.append(idx)
            for nxt_idx in outgoing[idx]:
                indegree[nxt_idx] -= 1
                if indegree[nxt_idx] == 0:
                    heapq.heappush(zero_heap, nxt_idx)

        if len(ordered_indices) < len(tasks):
            remaining = sorted(set(range(len(tasks))) - set(ordered_indices))
            ordered_indices.extend(remaining)

        return [mvmt_by_idx[idx] for idx in ordered_indices]

    def _appendUniqueLink(self, link_list, microlink):
        if microlink not in link_list:
            link_list.append(microlink)

    def _rebuildTurnConnectorMicroLinkGeometry(self, microlink):
        mesolink = getattr(microlink, 'mesolink', None)
        if mesolink is None or not getattr(mesolink, 'isconnector', False):
            return False

        mvmt = getattr(mesolink, 'movement', None)
        if mvmt is None or self._movementTurnCategory(mvmt) == 'other':
            return False

        lane_idx = None
        for idx, lane_links in enumerate(mesolink.microlink_list):
            if microlink in lane_links:
                lane_idx = idx
                break
        if lane_idx is None:
            return False

        ib_mesolink = mvmt.ib_link.mesolink_list[-1] if mvmt.ib_link.mesolink_list else None
        ob_mesolink = mvmt.ob_link.mesolink_list[0] if mvmt.ob_link.mesolink_list else None
        if ib_mesolink is None or ob_mesolink is None:
            return False

        ib_lane_idx = mvmt.start_ib_lane_seq_no + lane_idx
        ob_lane_idx = mvmt.start_ob_lane_seq_no + lane_idx
        if (ib_lane_idx < 0 or ib_lane_idx >= len(ib_mesolink.micronode_list) or
                ob_lane_idx < 0 or ob_lane_idx >= len(ob_mesolink.micronode_list)):
            return False

        lane_geometry_xy = self._buildConnectorLaneGeometry(
            start_micronode=microlink.from_node,
            end_micronode=microlink.to_node,
            ib_mesolink=ib_mesolink,
            ib_lane_idx=ib_lane_idx,
            ob_mesolink=ob_mesolink,
            ob_lane_idx=ob_lane_idx,
            mvmt=mvmt
        )
        microlink.geometry_xy = lane_geometry_xy
        microlink.geometry = self.macronet.GT.geo_to_latlon(lane_geometry_xy)
        return True

    def _refreshMicroLinkGeometry(self, link_ids):
        for lid in link_ids:
            microlink = self.micronet.link_dict.get(lid)
            if microlink is None:
                continue
            if self._rebuildTurnConnectorMicroLinkGeometry(microlink):
                continue
            microlink.geometry_xy = geometry.LineString([microlink.from_node.geometry_xy, microlink.to_node.geometry_xy])
            microlink.geometry = geometry.LineString([microlink.from_node.geometry, microlink.to_node.geometry])

    def _clipVectorMagnitude(self, x, y, max_norm):
        norm = math.hypot(x, y)
        if norm <= max_norm or norm < 1e-9:
            return x, y
        scale = max_norm / norm
        return x * scale, y * scale

    def _translationCapForMovement(self, mvmt, ib_link, ob_link, alignment_mode):
        ib_lanes = ib_link.outgoing_lanes or 0
        ob_lanes = ob_link.incoming_lanes or 0
        lane_delta = abs(ob_lanes - ib_lanes)
        lane_shift = abs(mvmt.start_ob_lane_seq_no - mvmt.start_ib_lane_seq_no)

        if alignment_mode == 'none':
            cap_lanes = 1.2 + 0.2 * lane_shift
        elif alignment_mode == 'lane_transition':
            cap_lanes = 1.6 + lane_delta + 0.4 * lane_shift
        else:
            cap_lanes = 2.0 + lane_delta + 0.5 * lane_shift

        cap_lanes = max(1.0, min(4.5, cap_lanes))
        return cap_lanes * self.width_of_lane * 0.85

    def _boundedWholeLinkTranslation(self, ob_mesolink, mvmt, ib_link, ob_link, alignment_mode, desired_dx, desired_dy):
        # Prevent cumulative drift: bound each mesolink's total translation magnitude.
        curr_dx, curr_dy = getattr(ob_mesolink, '_mr_shift_xy', (0.0, 0.0))
        target_dx = curr_dx + desired_dx
        target_dy = curr_dy + desired_dy
        # Constrain whole-link shift to the downstream link normal direction,
        # so translation will not change upstream/downstream position along link.
        target_dx, target_dy = self._projectVectorToLinkNormal(ob_mesolink.geometry_xy, target_dx, target_dy)
        cap = self._translationCapForMovement(mvmt, ib_link, ob_link, alignment_mode)
        bounded_dx, bounded_dy = self._clipVectorMagnitude(target_dx, target_dy, cap)
        apply_dx = bounded_dx - curr_dx
        apply_dy = bounded_dy - curr_dy
        ob_mesolink._mr_shift_xy = (bounded_dx, bounded_dy)
        return apply_dx, apply_dy

    def _translateWholeObMesoLinkNodes(self, ob_mesolink, dx, dy, affected):
        moved_nodes = set()
        for lane_nodes in ob_mesolink.micronode_list:
            for n in lane_nodes:
                if n.node_id in moved_nodes:
                    continue
                moved_nodes.add(n.node_id)
                n.geometry_xy = geometry.Point((n.geometry_xy.x + dx, n.geometry_xy.y + dy))
                n.geometry = self.macronet.GT.geo_to_latlon(n.geometry_xy)
                for lk in n.outgoing_link_list:
                    affected.add(lk.link_id)
                for lk in n.incoming_link_list:
                    affected.add(lk.link_id)

    def _boundedRampLocalShift(self, mvmt, dx, dy):
        lane_shift = abs(mvmt.start_ob_lane_seq_no - mvmt.start_ib_lane_seq_no)
        cap_lanes = max(1.5, min(3.0, lane_shift + 1.0))
        return self._clipVectorMagnitude(dx, dy, cap_lanes * self.width_of_lane)

    def _replaceObLaneStartsWithIbLaneEnds(self, mvmt, ib_mesolink, ob_mesolink):
        affected_links = set()
        for i in range(mvmt.lanes):
            ib_lane_index = mvmt.start_ib_lane_seq_no + i
            ob_lane_index = mvmt.start_ob_lane_seq_no + i
            if (ib_lane_index < 0 or ib_lane_index >= len(ib_mesolink.micronode_list) or
                    ob_lane_index < 0 or ob_lane_index >= len(ob_mesolink.micronode_list)):
                continue
            ib_out_node = ib_mesolink.micronode_list[ib_lane_index][-1]
            ob_in_node = ob_mesolink.micronode_list[ob_lane_index][0]
            ob_mesolink.micronode_list[ob_lane_index][0] = ib_out_node
            if ib_out_node.node_id == ob_in_node.node_id:
                continue
            for microlink in list(ob_in_node.outgoing_link_list):
                microlink.from_node = ib_out_node
                self._appendUniqueLink(ib_out_node.outgoing_link_list, microlink)
                affected_links.add(microlink.link_id)
            for microlink in list(ob_in_node.incoming_link_list):
                microlink.to_node = ib_out_node
                self._appendUniqueLink(ib_out_node.incoming_link_list, microlink)
                affected_links.add(microlink.link_id)
            ob_in_node.outgoing_link_list = []
            ob_in_node.incoming_link_list = []
            if ob_in_node.node_id in self.micronet.node_dict:
                del self.micronet.node_dict[ob_in_node.node_id]
        return affected_links

    def _replaceIbLaneEndsWithObLaneStarts(self, mvmt, ib_mesolink, ob_mesolink):
        affected_links = set()
        for i in range(mvmt.lanes):
            ib_lane_index = mvmt.start_ib_lane_seq_no + i
            ob_lane_index = mvmt.start_ob_lane_seq_no + i
            if (ib_lane_index < 0 or ib_lane_index >= len(ib_mesolink.micronode_list) or
                    ob_lane_index < 0 or ob_lane_index >= len(ob_mesolink.micronode_list)):
                continue
            ib_out_node = ib_mesolink.micronode_list[ib_lane_index][-1]
            ob_in_node = ob_mesolink.micronode_list[ob_lane_index][0]
            ib_mesolink.micronode_list[ib_lane_index][-1] = ob_in_node
            if ib_out_node.node_id == ob_in_node.node_id:
                continue
            for microlink in list(ib_out_node.incoming_link_list):
                microlink.to_node = ob_in_node
                self._appendUniqueLink(ob_in_node.incoming_link_list, microlink)
                affected_links.add(microlink.link_id)
            for microlink in list(ib_out_node.outgoing_link_list):
                microlink.from_node = ob_in_node
                self._appendUniqueLink(ob_in_node.outgoing_link_list, microlink)
                affected_links.add(microlink.link_id)
            ib_out_node.outgoing_link_list = []
            ib_out_node.incoming_link_list = []
            if ib_out_node.node_id in self.micronet.node_dict:
                del self.micronet.node_dict[ib_out_node.node_id]
        return affected_links

    def _getMainAllowedUses(self, mesolink):
        macrolink = mesolink.macrolink if hasattr(mesolink, 'macrolink') else None
        uses = macrolink.allowed_uses if macrolink is not None else None
        if not uses:
            return ['auto']
        return list(uses) if isinstance(uses, (list, tuple, set)) else [uses]

    def _createGuideLaneChangeMicroLink(self, from_node, to_node, mesolink):
        if from_node is None or to_node is None:
            return None
        if from_node.node_id == to_node.node_id:
            return None
        for lk in from_node.outgoing_link_list:
            if lk.to_node.node_id == to_node.node_id:
                return None
        microlink = MicroLink(self.micronet.max_link_id)
        self.micronet.max_link_id += 1
        microlink.from_node = from_node
        microlink.to_node = to_node
        microlink.geometry = geometry.LineString([from_node.geometry, to_node.geometry])
        microlink.geometry_xy = geometry.LineString([from_node.geometry_xy, to_node.geometry_xy])
        microlink.mesolink = mesolink
        microlink.cell_type = 2
        microlink.allowed_uses = self._getMainAllowedUses(mesolink)
        self.micronet.link_dict[microlink.link_id] = microlink
        from_node.outgoing_link_list.append(microlink)
        to_node.incoming_link_list.append(microlink)
        return microlink.link_id

    def _removeMicroLink(self, microlink):
        if microlink in microlink.from_node.outgoing_link_list:
            microlink.from_node.outgoing_link_list.remove(microlink)
        if microlink in microlink.to_node.incoming_link_list:
            microlink.to_node.incoming_link_list.remove(microlink)
        if microlink.link_id in self.micronet.link_dict:
            del self.micronet.link_dict[microlink.link_id]
        mesolink = microlink.mesolink
        if mesolink is not None and hasattr(mesolink, 'microlink_list'):
            for lane_links in mesolink.microlink_list:
                if microlink in lane_links:
                    lane_links.remove(microlink)

    def _trimLaneFront(self, mesolink, lane_idx, trim_count):
        if lane_idx < 0 or lane_idx >= len(mesolink.micronode_list):
            return set()

        lane_nodes = mesolink.micronode_list[lane_idx]
        max_trim = min(trim_count, max(0, len(lane_nodes) - 2))
        if max_trim <= 0:
            return set()

        nodes_to_remove = list(lane_nodes[:max_trim])
        mesolink.micronode_list[lane_idx] = lane_nodes[max_trim:]

        affected = set()
        for n in nodes_to_remove:
            incident_links = []
            incident_links.extend(list(n.outgoing_link_list))
            incident_links.extend(list(n.incoming_link_list))
            seen = set()
            for lk in incident_links:
                if lk.link_id in seen:
                    continue
                seen.add(lk.link_id)
                affected.add(lk.link_id)
                self._removeMicroLink(lk)
            n.outgoing_link_list = []
            n.incoming_link_list = []
            if n.node_id in self.micronet.node_dict:
                del self.micronet.node_dict[n.node_id]

        new_start = mesolink.micronode_list[lane_idx][0]
        new_start.is_link_upstream_end_node = True
        return affected

    def _smoothUnmappedDownstreamLanesByRange(self, ob_start, mapped_lanes, ob_mesolink, guide_ob_lane_idx):
        """
        For unmapped downstream lanes outside the guided lane, progressively trim
        leading micronodes/microlinks: outermost distance d trims d leading nodes.
        """
        if guide_ob_lane_idx is None:
            return set()

        ob_end = ob_start + mapped_lanes - 1
        affected = set()

        if guide_ob_lane_idx < ob_start:
            for lane_idx in range(guide_ob_lane_idx - 1, -1, -1):
                distance = guide_ob_lane_idx - lane_idx
                affected.update(self._trimLaneFront(ob_mesolink, lane_idx, distance))
        elif guide_ob_lane_idx > ob_end:
            for lane_idx in range(guide_ob_lane_idx + 1, len(ob_mesolink.micronode_list)):
                distance = lane_idx - guide_ob_lane_idx
                affected.update(self._trimLaneFront(ob_mesolink, lane_idx, distance))

        return affected

    def _smoothUnmappedDownstreamLanes(self, mvmt, ob_mesolink, guide_ob_lane_idx):
        return self._smoothUnmappedDownstreamLanesByRange(
            mvmt.start_ob_lane_seq_no, mvmt.lanes, ob_mesolink, guide_ob_lane_idx
        )

    def _addLaneTransitionGuideLinksByMapping(self, ib_start, ob_start, mapped_lanes, ib_mesolink, ob_mesolink):
        """
        Add optional lane-change guidance microlinks for a generic mapped block:
        ib [ib_start .. ib_start+mapped_lanes-1] -> ob [ob_start .. ob_start+mapped_lanes-1].
        """
        ib_end = ib_start + mapped_lanes - 1
        ob_end = ob_start + mapped_lanes - 1
        ib_total_lanes = len(ib_mesolink.micronode_list)
        ob_total_lanes = len(ob_mesolink.micronode_list)
        lane_shift = ob_start - ib_start
        guide_results = []

        def _appendGuide(ib_lane_idx, ob_lane_idx, use_merge_terminal_target=False):
            if (ib_lane_idx < 0 or ib_lane_idx >= len(ib_mesolink.micronode_list) or
                    ob_lane_idx < 0 or ob_lane_idx >= len(ob_mesolink.micronode_list)):
                return

            ib_lane_nodes = ib_mesolink.micronode_list[ib_lane_idx]
            ob_lane_nodes = ob_mesolink.micronode_list[ob_lane_idx]
            if len(ib_lane_nodes) < 1 or len(ob_lane_nodes) < 1:
                return

            # Connector mesolink node chains store interior nodes only (shared endpoints
            # belong to neighboring mesolinks). So "penultimate including shared end"
            # corresponds to the last interior node.
            if use_merge_terminal_target:
                from_node = ib_lane_nodes[-1]
                to_node = ob_lane_nodes[1] if len(ob_lane_nodes) > 1 else ob_lane_nodes[0]
            else:
                if getattr(ib_mesolink, 'isconnector', False):
                    from_node = ib_lane_nodes[-1]
                else:
                    if len(ib_lane_nodes) < 2:
                        return
                    from_node = ib_lane_nodes[-2]
                to_node = ob_lane_nodes[0]

            guide_link_id = self._createGuideLaneChangeMicroLink(from_node, to_node, ib_mesolink)
            if guide_link_id is not None:
                guide_results.append((guide_link_id, ob_lane_idx))

        if lane_shift > 0:
            # Primary: mapped block shifts right, add guide to left-side unmapped lane.
            if ob_start - 1 >= 0:
                _appendGuide(ib_start, ob_start - 1)
            # Secondary: if right side also has unmapped lanes, add symmetric guide.
            if ob_end + 1 < ob_total_lanes:
                _appendGuide(ib_end, ob_end + 1)
            # Fallback: upstream has an extra side lane to merge into mapped block.
            if (not guide_results) and (ib_end + 1 < ib_total_lanes):
                _appendGuide(ib_end + 1, ob_end, use_merge_terminal_target=True)
        elif lane_shift < 0:
            # Primary: mapped block shifts left, add guide to right-side unmapped lane.
            if ob_end + 1 < ob_total_lanes:
                _appendGuide(ib_end, ob_end + 1)
            # Secondary: if left side also has unmapped lanes, add symmetric guide.
            if ob_start - 1 >= 0:
                _appendGuide(ib_start, ob_start - 1)
            # Fallback: upstream has an extra side lane to merge into mapped block.
            if (not guide_results) and (ib_start - 1 >= 0):
                _appendGuide(ib_start - 1, ob_start, use_merge_terminal_target=True)
        else:
            has_right_extra = ob_end + 1 < ob_total_lanes
            has_left_extra = ob_start - 1 >= 0
            has_up_left_extra = ib_start - 1 >= 0
            has_up_right_extra = ib_end + 1 < ib_total_lanes

            if has_left_extra:
                _appendGuide(ib_start, ob_start - 1)
            if has_right_extra:
                _appendGuide(ib_end, ob_end + 1)
            if (not guide_results) and has_up_left_extra:
                _appendGuide(ib_start - 1, ob_start, use_merge_terminal_target=True)
            if (not guide_results) and has_up_right_extra:
                _appendGuide(ib_end + 1, ob_end, use_merge_terminal_target=True)

        return guide_results

    def _addLaneTransitionGuideLink(self, mvmt, ib_mesolink, ob_mesolink):
        """
        Add one optional lane-change guidance microlink for lane transitions.
        Example (shift right): ib lane 1 penultimate node -> ob lane 2 first node.
        Example (4->5 with 1-4->1-4): ib lane 4 penultimate node -> ob lane 5 first node.
        Example (2->1 with 2->1): ib lane 1 last node -> ob lane 1 second node.
        """
        guide_results = self._addLaneTransitionGuideLinksByMapping(
            mvmt.start_ib_lane_seq_no, mvmt.start_ob_lane_seq_no, mvmt.lanes, ib_mesolink, ob_mesolink
        )
        if not guide_results:
            return None
        return guide_results[0]

    def _unitVector(self, x, y):
        norm = math.hypot(x, y)
        if norm < 1e-9:
            return None
        return x / norm, y / norm

    def _lineStartDirection(self, line):
        coords = list(line.coords)
        if len(coords) < 2:
            return None
        return self._unitVector(coords[1][0] - coords[0][0], coords[1][1] - coords[0][1])

    def _lineEndDirection(self, line):
        coords = list(line.coords)
        if len(coords) < 2:
            return None
        return self._unitVector(coords[-1][0] - coords[-2][0], coords[-1][1] - coords[-2][1])

    def _lineOverallDirection(self, line):
        coords = list(line.coords)
        if len(coords) < 2:
            return None
        return self._unitVector(coords[-1][0] - coords[0][0], coords[-1][1] - coords[0][1])

    def _projectVectorToLinkNormal(self, link_geometry_xy, dx, dy):
        link_dir = self._lineOverallDirection(link_geometry_xy)
        if link_dir is None:
            link_dir = self._lineStartDirection(link_geometry_xy)
        if link_dir is None:
            return dx, dy

        nx = -link_dir[1]
        ny = link_dir[0]
        proj = dx * nx + dy * ny
        return proj * nx, proj * ny

    def _intersectInfiniteLines(self, p1, d1, p2, d2):
        a11, a12 = d1[0], -d2[0]
        a21, a22 = d1[1], -d2[1]
        det = a11 * a22 - a12 * a21
        if abs(det) < 1e-9:
            return None
        bx = p2[0] - p1[0]
        by = p2[1] - p1[1]
        t = (bx * a22 - a12 * by) / det
        return p1[0] + d1[0] * t, p1[1] + d1[1] * t

    def _sampleArcCoords(self, center, start_pt, end_pt, ccw, sample_n):
        a0 = math.atan2(start_pt[1] - center[1], start_pt[0] - center[0])
        a1 = math.atan2(end_pt[1] - center[1], end_pt[0] - center[0])
        delta = a1 - a0
        if ccw:
            while delta <= 0:
                delta += 2.0 * math.pi
        else:
            while delta >= 0:
                delta -= 2.0 * math.pi

        coords = []
        for i in range(sample_n + 1):
            t = i / sample_n
            a = a0 + delta * t
            x = center[0] + math.cos(a) * math.hypot(start_pt[0] - center[0], start_pt[1] - center[1])
            y = center[1] + math.sin(a) * math.hypot(start_pt[0] - center[0], start_pt[1] - center[1])
            coords.append((x, y))
        return coords, delta

    def _directionScore(self, coords, start_dir, end_dir):
        if len(coords) < 4:
            return -1e9
        sv = self._unitVector(coords[1][0] - coords[0][0], coords[1][1] - coords[0][1])
        ev = self._unitVector(coords[-1][0] - coords[-2][0], coords[-1][1] - coords[-2][1])
        if sv is None or ev is None:
            return -1e9
        return sv[0] * start_dir[0] + sv[1] * start_dir[1] + ev[0] * end_dir[0] + ev[1] * end_dir[1]

    def _curveTurnSign(self, coords):
        if len(coords) < 3:
            return 0
        total_cross = 0.0
        for i in range(1, len(coords) - 1):
            ax = coords[i][0] - coords[i - 1][0]
            ay = coords[i][1] - coords[i - 1][1]
            bx = coords[i + 1][0] - coords[i][0]
            by = coords[i + 1][1] - coords[i][1]
            total_cross += ax * by - ay * bx
        if total_cross > 1e-9:
            return 1
        if total_cross < -1e-9:
            return -1
        return 0

    def _movementTurnCategory(self, mvmt):
        txt = (mvmt.mvmt_txt_id or '').upper()
        typ = (mvmt.type or '').lower()
        if txt.endswith('U') or 'uturn' in typ or 'u_turn' in typ:
            return 'uturn'
        if txt.endswith('L') or typ == 'left':
            return 'left'
        if txt.endswith('R') or typ == 'right':
            return 'right'
        return 'other'

    def _buildEndpointTangentCurve(self, start_xy, end_xy, start_dir, end_dir, turn_cat='other', ref_start_xy=None, ref_end_xy=None):
        line_start = ref_start_xy if ref_start_xy is not None else start_xy
        line_end = ref_end_xy if ref_end_xy is not None else end_xy
        vertex = self._intersectInfiniteLines(line_start, start_dir, line_end, end_dir)
        if vertex is None:
            return None

        sx, sy = start_xy
        ex, ey = end_xy
        vx, vy = vertex
        direct_dist = math.hypot(ex - sx, ey - sy)
        if direct_dist < 1e-6:
            return geometry.LineString([start_xy, end_xy])

        dot = max(-1.0, min(1.0, start_dir[0] * end_dir[0] + start_dir[1] * end_dir[1]))
        turn_angle_deg = math.degrees(math.acos(dot))

        # Cubic Bezier with endpoint tangents:
        # P1 = P0 + T_in * dir_in, P2 = P3 - T_out * dir_out
        # where T_in/T_out are scaled by the available tangent reach to the intersection.
        reach_in = abs((vx - sx) * start_dir[0] + (vy - sy) * start_dir[1])
        reach_out = abs((vx - ex) * end_dir[0] + (vy - ey) * end_dir[1])
        if reach_in < 1e-6:
            reach_in = direct_dist * 0.5
        if reach_out < 1e-6:
            reach_out = direct_dist * 0.5

        # Internal adaptive T_in/T_out (not exposed as public API):
        # larger turn angle -> larger tangent handle, and asymmetry follows reach ratio.
        angle_factor = 0.45 + 0.35 * min(1.0, turn_angle_deg / 120.0)
        ratio_in = min(2.0, max(0.5, reach_out / max(reach_in, 1e-6)))
        ratio_out = min(2.0, max(0.5, reach_in / max(reach_out, 1e-6)))
        t_in_factor = angle_factor * (0.85 + 0.15 * ratio_in)
        t_out_factor = angle_factor * (0.85 + 0.15 * ratio_out)

        min_t = max(self.length_of_cell * 0.25, direct_dist * 0.10)
        max_t = max(min_t, direct_dist * 1.35)
        t_in = min(max(reach_in * t_in_factor, min_t), max_t)
        t_out = min(max(reach_out * t_out_factor, min_t), max_t)
        p1x = sx + start_dir[0] * t_in
        p1y = sy + start_dir[1] * t_in
        p2x = ex - end_dir[0] * t_out
        p2y = ey - end_dir[1] * t_out

        base_by_len = int(round(direct_dist / max(self.length_of_cell, 1e-6))) * 8
        base_by_angle = int(turn_angle_deg / 3.0) + 16
        sample_n = max(20, base_by_len, base_by_angle)
        coords = []
        for i in range(sample_n + 1):
            t = i / sample_n
            omt = 1.0 - t
            x = (omt ** 3) * sx + 3.0 * (omt ** 2) * t * p1x + 3.0 * omt * (t ** 2) * p2x + (t ** 3) * ex
            y = (omt ** 3) * sy + 3.0 * (omt ** 2) * t * p1y + 3.0 * omt * (t ** 2) * p2y + (t ** 3) * ey
            coords.append((x, y))

        curve = geometry.LineString(coords)
        if curve.is_empty or not curve.is_simple:
            return None
        if self._directionScore(coords, start_dir, end_dir) < 1.0:
            return None
        if turn_cat in ('left', 'right'):
            expected_sign = 1 if turn_cat == 'left' else -1
            curve_sign = self._curveTurnSign(coords)
            if curve_sign not in (expected_sign, 0):
                return None

        densify_n = max(sample_n, int(curve.length / max(self.length_of_cell * 0.35, 0.5)))
        dense_coords = [curve.interpolate(i / densify_n, normalized=True).coords[0] for i in range(densify_n + 1)]
        return geometry.LineString(dense_coords)

    def _buildTurnFilletCurve(self, start_xy, end_xy, start_dir, end_dir, turn_cat='other', ref_start_xy=None, ref_end_xy=None):
        line_start = ref_start_xy if ref_start_xy is not None else start_xy
        line_end = ref_end_xy if ref_end_xy is not None else end_xy

        vertex = self._intersectInfiniteLines(line_start, start_dir, line_end, end_dir)
        if vertex is None:
            return None

        vx, vy = vertex
        v_to_start = (start_xy[0] - vx, start_xy[1] - vy)
        v_to_end = (end_xy[0] - vx, end_xy[1] - vy)
        len_vs = math.hypot(v_to_start[0], v_to_start[1])
        len_ve = math.hypot(v_to_end[0], v_to_end[1])
        if len_vs < 1e-6 or len_ve < 1e-6:
            return None

        u_vs = (v_to_start[0] / len_vs, v_to_start[1] / len_vs)
        u_ve = (v_to_end[0] / len_ve, v_to_end[1] / len_ve)
        dot = max(-1.0, min(1.0, u_vs[0] * u_ve[0] + u_vs[1] * u_ve[1]))
        phi = math.acos(dot)
        if phi < math.radians(12.0) or phi > math.radians(168.0):
            return None

        d_max = min(len_vs * 0.9, len_ve * 0.9)
        direct_dist = math.hypot(end_xy[0] - start_xy[0], end_xy[1] - start_xy[1])
        d_target = max(self.length_of_cell * 1.2, direct_dist * 0.42)
        d = min(d_target, d_max)
        if d < 1e-3:
            return None

        t_in = (vx + u_vs[0] * d, vy + u_vs[1] * d)
        t_out = (vx + u_ve[0] * d, vy + u_ve[1] * d)

        half_phi = phi / 2.0
        if abs(math.sin(half_phi)) < 1e-6 or abs(math.tan(half_phi)) < 1e-6:
            return None
        radius = d / math.tan(half_phi)
        bis = (u_vs[0] + u_ve[0], u_vs[1] + u_ve[1])
        bis_u = self._unitVector(bis[0], bis[1])
        if bis_u is None:
            return None
        center_dist = radius / math.sin(half_phi)
        center1 = (vx + bis_u[0] * center_dist, vy + bis_u[1] * center_dist)
        center2 = (vx - bis_u[0] * center_dist, vy - bis_u[1] * center_dist)

        arc_len = radius * phi
        sample_n = max(16, int(arc_len / max(self.length_of_cell * 0.35, 0.5)))
        candidates = []
        for center in (center1, center2):
            coords_ccw, delta_ccw = self._sampleArcCoords(center, t_in, t_out, ccw=True, sample_n=sample_n)
            coords_cw, delta_cw = self._sampleArcCoords(center, t_in, t_out, ccw=False, sample_n=sample_n)
            candidates.append(('ccw', [start_xy, t_in] + coords_ccw[1:-1] + [t_out, end_xy], abs(delta_ccw), abs(math.degrees(delta_ccw))))
            candidates.append(('cw', [start_xy, t_in] + coords_cw[1:-1] + [t_out, end_xy], abs(delta_cw), abs(math.degrees(delta_cw))))

        filtered = []
        for arc_dir, coords, abs_delta, sweep_deg in candidates:
            score = self._directionScore(coords, start_dir, end_dir)
            # Skip long-loop arc and heavily reversed tangent fits.
            if abs_delta > math.pi * 1.05:
                continue
            if score < 0.5:
                continue
            if turn_cat in ('left', 'right'):
                expected_sign = 1 if turn_cat == 'left' else -1
                curve_sign = self._curveTurnSign(coords)
                if curve_sign not in (expected_sign, 0):
                    continue
            filtered.append((arc_dir, coords, abs_delta, score, sweep_deg))

        if not filtered:
            return None

        turn_angle_deg = math.degrees(math.acos(dot))
        if turn_cat in ('left', 'right'):
            lower = max(20.0, turn_angle_deg * 0.5)
            upper = min(170.0, turn_angle_deg * 1.25)
            angle_band = [c for c in filtered if lower <= c[4] <= upper]
            if angle_band:
                filtered = angle_band
            # Prefer arc sweep close to the true direction change.
            _, coords, _, _, _ = sorted(filtered, key=lambda x: (abs(x[4] - turn_angle_deg), -x[3]))[0]
        else:
            # Non-turn fallback.
            _, coords, _, _, _ = sorted(filtered, key=lambda x: (x[2], -x[3]))[0]

        curve = geometry.LineString(coords)
        if curve.is_empty or not curve.is_simple:
            return None
        if curve.length < direct_dist * 0.85:
            return None
        return curve

    def _buildConnectorCurveByPoints(self, start_xy, end_xy, start_dir, end_dir, mvmt, ref_start_xy=None, ref_end_xy=None):
        straight = geometry.LineString([start_xy, end_xy])
        if start_dir is None or end_dir is None:
            return straight

        sx, sy = start_xy
        ex, ey = end_xy
        dx = ex - sx
        dy = ey - sy
        direct_dist = math.hypot(dx, dy)
        if direct_dist < 1e-6:
            return straight

        dot = max(-1.0, min(1.0, start_dir[0] * end_dir[0] + start_dir[1] * end_dir[1]))
        turn_angle_deg = math.degrees(math.acos(dot))
        turn_cat = self._movementTurnCategory(mvmt)
        if turn_cat == 'other' and turn_angle_deg < 30.0:
            return straight

        if turn_cat in ('left', 'right'):
            tangent_curve = self._buildEndpointTangentCurve(
                start_xy=start_xy,
                end_xy=end_xy,
                start_dir=start_dir,
                end_dir=end_dir,
                turn_cat=turn_cat,
                ref_start_xy=ref_start_xy,
                ref_end_xy=ref_end_xy,
            )
            if tangent_curve is not None:
                return tangent_curve

        if turn_cat == 'uturn':
            strength = 0.85
        elif turn_cat in ('left', 'right'):
            strength = 0.35 + 0.55 * min(1.0, turn_angle_deg / 150.0)
        else:
            strength = 0.25 + 0.45 * min(1.0, turn_angle_deg / 120.0)

        base_control_len = direct_dist * strength
        min_control_len = max(self.length_of_cell * 0.6, direct_dist * 0.2)
        max_control_factor = 1.1 if turn_cat == 'uturn' else 0.9
        max_control_len = max(min_control_len, direct_dist * max_control_factor)
        control_len = min(max(base_control_len, min_control_len), max_control_len)
        p0 = (sx, sy)
        p1 = (sx + start_dir[0] * control_len, sy + start_dir[1] * control_len)
        p2 = (ex - end_dir[0] * control_len, ey - end_dir[1] * control_len)
        p3 = (ex, ey)

        base_by_len = int(round(direct_dist / max(self.length_of_cell, 1e-6))) * 8
        base_by_angle = int(turn_angle_deg / 4.0) + 16
        sample_n = max(24, base_by_len, base_by_angle)
        if turn_cat == 'uturn':
            sample_n = max(sample_n, 48)
        coords = []
        for i in range(sample_n + 1):
            t = i / sample_n
            omt = 1.0 - t
            x = (omt ** 3) * p0[0] + 3 * (omt ** 2) * t * p1[0] + 3 * omt * (t ** 2) * p2[0] + (t ** 3) * p3[0]
            y = (omt ** 3) * p0[1] + 3 * (omt ** 2) * t * p1[1] + 3 * omt * (t ** 2) * p2[1] + (t ** 3) * p3[1]
            coords.append((x, y))

        curve = geometry.LineString(coords)
        if curve.is_empty or curve.length < direct_dist * 0.8 or not curve.is_simple:
            return straight

        # Final densification for smoother mesolink rendering.
        densify_n = max(sample_n, int(curve.length / max(self.length_of_cell * 0.35, 0.5)))
        dense_coords = [curve.interpolate(i / densify_n, normalized=True).coords[0] for i in range(densify_n + 1)]
        curve = geometry.LineString(dense_coords)
        return curve

    def _buildConnectorCenterlineGeometry(self, ib_mesolink, ob_mesolink, mvmt):
        start_xy = ib_mesolink.geometry_xy.coords[-1]
        end_xy = ob_mesolink.geometry_xy.coords[0]
        start_dir = self._lineEndDirection(ib_mesolink.geometry_xy)
        end_dir = self._lineStartDirection(ob_mesolink.geometry_xy)
        return self._buildConnectorCurveByPoints(
            start_xy=start_xy,
            end_xy=end_xy,
            start_dir=start_dir,
            end_dir=end_dir,
            mvmt=mvmt,
            ref_start_xy=start_xy,
            ref_end_xy=end_xy,
        )

    def _buildConnectorLaneGeometry(self, start_micronode, end_micronode, ib_mesolink, ib_lane_idx, ob_mesolink, ob_lane_idx, mvmt):
        start_xy = (start_micronode.geometry_xy.x, start_micronode.geometry_xy.y)
        end_xy = (end_micronode.geometry_xy.x, end_micronode.geometry_xy.y)

        ib_lane_nodes = ib_mesolink.micronode_list[ib_lane_idx] if 0 <= ib_lane_idx < len(ib_mesolink.micronode_list) else None
        ob_lane_nodes = ob_mesolink.micronode_list[ob_lane_idx] if 0 <= ob_lane_idx < len(ob_mesolink.micronode_list) else None

        if ib_lane_nodes is None or len(ib_lane_nodes) < 2 or ob_lane_nodes is None or len(ob_lane_nodes) < 2:
            return geometry.LineString([start_xy, end_xy])

        start_dir = self._lineEndDirection(ib_mesolink.geometry_xy)
        end_dir = self._lineStartDirection(ob_mesolink.geometry_xy)
        if start_dir is None:
            start_dir = self._unitVector(
                ib_lane_nodes[-1].geometry_xy.x - ib_lane_nodes[-2].geometry_xy.x,
                ib_lane_nodes[-1].geometry_xy.y - ib_lane_nodes[-2].geometry_xy.y
            )
        if end_dir is None:
            end_dir = self._unitVector(
                ob_lane_nodes[1].geometry_xy.x - ob_lane_nodes[0].geometry_xy.x,
                ob_lane_nodes[1].geometry_xy.y - ob_lane_nodes[0].geometry_xy.y
            )
        ref_start_xy = ib_mesolink.geometry_xy.coords[-1]
        ref_end_xy = ob_mesolink.geometry_xy.coords[0]
        return self._buildConnectorCurveByPoints(
            start_xy=start_xy,
            end_xy=end_xy,
            start_dir=start_dir,
            end_dir=end_dir,
            mvmt=mvmt,
            ref_start_xy=ref_start_xy,
            ref_end_xy=ref_end_xy,
        )

    # The remaining methods mirror the original implementation closely

    def createMicroNetForConnector(self, mesolink, ib_mesolink, ib_lane_index_start, ob_mesolink, ob_lane_index_start):
        max_micronode_id = self.micronet.max_node_id
        max_microlink_id = self.micronet.max_link_id
        mvmt = mesolink.movement
        is_thru = (mvmt.type or '').lower() == 'thru'
        mvmt_ctrl = str(getattr(mvmt, 'ctrl_type', '') or '').lower()
        node_ctrl = str(getattr(getattr(mvmt, 'node', None), 'ctrl_type', '') or '').lower()
        is_signal = mvmt_ctrl in {'signal', '1'} or node_ctrl in {'signal', '1'}

        lane_node_chains = []
        for i in range(mesolink.lanes):
            start_micronode = ib_mesolink.micronode_list[ib_lane_index_start+i][-1]
            end_micronode = ob_mesolink.micronode_list[ob_lane_index_start+i][0]
            lane_geometry_xy = self._buildConnectorLaneGeometry(
                start_micronode=start_micronode,
                end_micronode=end_micronode,
                ib_mesolink=ib_mesolink,
                ib_lane_idx=ib_lane_index_start + i,
                ob_mesolink=ob_mesolink,
                ob_lane_idx=ob_lane_index_start + i,
                mvmt=mvmt
            )

            number_of_cells = 1
            if is_thru:
                number_of_cells = max(1, round(lane_geometry_xy.length / max(self.length_of_cell, 1e-6)))

            mesolink.micronode_list.append([])
            mesolink.microlink_list.append([])

            lane_nodes = [start_micronode]
            for cell_idx in range(1, number_of_cells):
                p_xy = lane_geometry_xy.interpolate(cell_idx / number_of_cells, normalized=True)
                micronode = MicroNode(max_micronode_id)
                micronode.geometry_xy = p_xy
                micronode.geometry = self.macronet.GT.geo_to_latlon(p_xy)
                micronode.mesolink = mesolink
                micronode.lane_no = i + 1
                self.micronet.node_dict[micronode.node_id] = micronode
                max_micronode_id += 1
                mesolink.micronode_list[-1].append(micronode)
                lane_nodes.append(micronode)
            lane_nodes.append(end_micronode)
            lane_node_chains.append(lane_nodes)

            for cell_idx in range(number_of_cells):
                from_node = lane_nodes[cell_idx]
                to_node = lane_nodes[cell_idx + 1]
                microlink = MicroLink(max_microlink_id)
                microlink.from_node = from_node
                microlink.to_node = to_node
                if is_thru:
                    microlink.geometry_xy = geometry.LineString([from_node.geometry_xy, to_node.geometry_xy])
                    microlink.geometry = geometry.LineString([from_node.geometry, to_node.geometry])
                else:
                    if cell_idx == 0:
                        microlink.geometry_xy = lane_geometry_xy
                        microlink.geometry = self.macronet.GT.geo_to_latlon(lane_geometry_xy)
                    else:
                        microlink.geometry_xy = geometry.LineString([from_node.geometry_xy, to_node.geometry_xy])
                        microlink.geometry = geometry.LineString([from_node.geometry, to_node.geometry])
                microlink.mesolink = mesolink
                microlink.cell_type = 1
                microlink.is_first_movement_cell = (cell_idx == 0)
                microlink.lane_no = i + 1

                mesolink.microlink_list[-1].append(microlink)
                self.micronet.link_dict[microlink.link_id] = microlink
                max_microlink_id += 1
                microlink.from_node.outgoing_link_list.append(microlink)
                microlink.to_node.incoming_link_list.append(microlink)

        # Add lane-changing microlinks for thru connectors, matching normal link topology.
        # Signalized intersections should not add connector lane-changing diagonals.
        if is_thru and (not is_signal) and mesolink.lanes >= 2:
            for i in range(mesolink.lanes):
                nodes_i = lane_node_chains[i]
                seg_i = len(nodes_i) - 1
                if seg_i <= 0:
                    continue
                if i <= mesolink.lanes - 2:
                    nodes_next = lane_node_chains[i + 1]
                    seg = min(seg_i, len(nodes_next) - 1)
                    for j in range(seg):
                        microlink = MicroLink(max_microlink_id)
                        max_microlink_id += 1
                        microlink.from_node = nodes_i[j]
                        microlink.to_node = nodes_next[j + 1]
                        microlink.geometry_xy = geometry.LineString([microlink.from_node.geometry_xy, microlink.to_node.geometry_xy])
                        microlink.geometry = geometry.LineString([microlink.from_node.geometry, microlink.to_node.geometry])
                        microlink.mesolink = mesolink
                        microlink.cell_type = 2
                        microlink.lane_no = i + 1
                        self.micronet.link_dict[microlink.link_id] = microlink
                        microlink.from_node.outgoing_link_list.append(microlink)
                        microlink.to_node.incoming_link_list.append(microlink)
                if i >= 1:
                    nodes_prev = lane_node_chains[i - 1]
                    seg = min(seg_i, len(nodes_prev) - 1)
                    for j in range(seg):
                        microlink = MicroLink(max_microlink_id)
                        max_microlink_id += 1
                        microlink.from_node = nodes_i[j]
                        microlink.to_node = nodes_prev[j + 1]
                        microlink.geometry_xy = geometry.LineString([microlink.from_node.geometry_xy, microlink.to_node.geometry_xy])
                        microlink.geometry = geometry.LineString([microlink.from_node.geometry, microlink.to_node.geometry])
                        microlink.mesolink = mesolink
                        microlink.cell_type = 2
                        microlink.lane_no = i + 1
                        self.micronet.link_dict[microlink.link_id] = microlink
                        microlink.from_node.outgoing_link_list.append(microlink)
                        microlink.to_node.incoming_link_list.append(microlink)

        self.micronet.max_node_id = max_micronode_id
        self.micronet.max_link_id = max_microlink_id
    def createMicroNetForNormalLink(self, link):
        max_micronode_id = self.micronet.max_node_id
        max_microlink_id = self.micronet.max_link_id

        MultimoalUse = self.getMultimoalUse(link.allowed_uses)
        mainlane_allowed_uses, extra_bike, extra_walk = MultimoalUse['mainlane_allowed_uses'], MultimoalUse['extra_bike'], MultimoalUse['extra_walk']

        for mesolink in link.mesolink_list:
            original_number_of_lanes = mesolink.macrolink.lanes
            lane_changes_left = mesolink.lanes_change[0]
            num_of_lane_offset_between_left_most_and_central = -1 * (original_number_of_lanes / 2 - 0.5 + lane_changes_left)

            lane_geometry_xy_list = []
            extra_bike_geometry_xy, extra_walk_geometry_xy = None, None
            lane_offset = 0
            for i in range(mesolink.lanes):
                lane_offset = (num_of_lane_offset_between_left_most_and_central + i) * self.width_of_lane
                lane_geometry_xy_list.append(self.getLaneGeometry(mesolink.geometry_xy, lane_offset))
            if extra_bike and not extra_walk:
                bike_lane_offset = lane_offset + self.bike_lane_width
                extra_bike_geometry_xy = self.getLaneGeometry(mesolink.geometry_xy, bike_lane_offset)
            if not extra_bike and extra_walk:
                walk_lane_offset = lane_offset + self.walk_lane_width
                extra_walk_geometry_xy = self.getLaneGeometry(mesolink.geometry_xy, walk_lane_offset)
            if extra_bike and extra_walk:
                bike_lane_offset = lane_offset + self.bike_lane_width
                walk_lane_offset = bike_lane_offset + self.walk_lane_width
                extra_bike_geometry_xy = self.getLaneGeometry(mesolink.geometry_xy, bike_lane_offset)
                extra_walk_geometry_xy = self.getLaneGeometry(mesolink.geometry_xy, walk_lane_offset)

            # anchor: parallel-translate current mesolink lane centerlines to upstream mapped lanes (LEFT-aligned)
            try:
                meso_index = link.mesolink_list.index(mesolink)
                if meso_index > 0:
                    upstream_mesolink = link.mesolink_list[meso_index - 1]
                    if hasattr(upstream_mesolink, 'lane_geometry_xy_list') and upstream_mesolink.lane_geometry_xy_list:
                        up_left_index = upstream_mesolink.lanes_change[0]
                        down_left_index = mesolink.lanes_change[0]
                        min_left_index = min(up_left_index, down_left_index)
                        up_lane_index_start = up_left_index - min_left_index
                        down_lane_index_start = down_left_index - min_left_index

                        number_of_connecting_lanes = min(
                            upstream_mesolink.lanes - up_lane_index_start,
                            mesolink.lanes - down_lane_index_start
                        )

                        for j in range(number_of_connecting_lanes):
                            up_lane_index = up_lane_index_start + j
                            down_lane_index = down_lane_index_start + j
                            up_end_x, up_end_y = upstream_mesolink.lane_geometry_xy_list[up_lane_index].coords[-1]
                            down_start_x, down_start_y = lane_geometry_xy_list[down_lane_index].coords[0]
                            dx, dy = up_end_x - down_start_x, up_end_y - down_start_y
                            if abs(dx) > 1e-9 or abs(dy) > 1e-9:
                                shifted = [(x + dx, y + dy) for (x, y) in lane_geometry_xy_list[down_lane_index].coords]
                                lane_geometry_xy_list[down_lane_index] = geometry.LineString(shifted)
            except Exception:
                pass

            number_of_cells = max(1, round(mesolink.length / self.length_of_cell))
            micronode_geometry_xy_list = [[lane_geometry_xy.interpolate(i/number_of_cells, normalized=True) for i in range(number_of_cells+1)] for lane_geometry_xy in lane_geometry_xy_list]
            micronode_geometry_xy_bike = [extra_bike_geometry_xy.interpolate(i / number_of_cells, normalized=True) for i in range(number_of_cells + 1)] if extra_bike_geometry_xy is not None else None
            micronode_geometry_xy_walk = [extra_walk_geometry_xy.interpolate(i / number_of_cells, normalized=True) for i in range(number_of_cells + 1)] if extra_walk_geometry_xy is not None else None

            for i in range(mesolink.lanes):
                micronode_list_lane = []
                for micronode_geometry_xy in micronode_geometry_xy_list[i]:
                    micronode = MicroNode(max_micronode_id)
                    micronode.geometry_xy = micronode_geometry_xy
                    micronode.geometry = self.macronet.GT.geo_to_latlon(micronode_geometry_xy)
                    micronode.mesolink = mesolink
                    micronode.lane_no = i + 1
                    micronode_list_lane.append(micronode)
                    self.micronet.node_dict[micronode.node_id] = micronode
                    max_micronode_id += 1
                mesolink.micronode_list.append(micronode_list_lane)

            # persist current lane centerlines for downstream anchoring
            mesolink.lane_geometry_xy_list = lane_geometry_xy_list

            if extra_bike:
                for micronode_geometry_xy in micronode_geometry_xy_bike:
                    micronode = MicroNode(max_micronode_id)
                    micronode.geometry_xy = micronode_geometry_xy
                    micronode.geometry = self.macronet.GT.geo_to_latlon(micronode_geometry_xy)
                    micronode.mesolink = mesolink
                    mesolink.micronode_bike.append(micronode)
                    self.micronet.node_dict[micronode.node_id] = micronode
                    max_micronode_id += 1

            if extra_walk:
                for micronode_geometry_xy in micronode_geometry_xy_walk:
                    micronode = MicroNode(max_micronode_id)
                    micronode.geometry_xy = micronode_geometry_xy
                    micronode.geometry = self.macronet.GT.geo_to_latlon(micronode_geometry_xy)
                    micronode.mesolink = mesolink
                    mesolink.micronode_walk.append(micronode)
                    self.micronet.node_dict[micronode.node_id] = micronode
                    max_micronode_id += 1

        first_mesolink = link.mesolink_list[0]
        for micronode_list_lane in first_mesolink.micronode_list:
            micronode_list_lane[0].is_link_upstream_end_node = True
        if extra_bike: first_mesolink.micronode_bike[0].is_link_upstream_end_node = True
        if extra_walk: first_mesolink.micronode_walk[0].is_link_upstream_end_node = True
        last_mesolink = link.mesolink_list[-1]
        for micronode_list_lane in last_mesolink.micronode_list:
            micronode_list_lane[-1].is_link_downstream_end_node = True
        if extra_bike: last_mesolink.micronode_bike[-1].is_link_downstream_end_node = True
        if extra_walk: last_mesolink.micronode_walk[-1].is_link_downstream_end_node = True

        for i in range(len(link.mesolink_list)-1):
            upstream_mesolink = link.mesolink_list[i]
            downstream_mesolink = link.mesolink_list[i+1]

            up_index_of_left_most_lane_of_original_link = upstream_mesolink.lanes_change[0]
            down_index_of_left_most_lane_of_original_link = downstream_mesolink.lanes_change[0]
            min_left_most_lane_index = min(up_index_of_left_most_lane_of_original_link, down_index_of_left_most_lane_of_original_link)
            up_lane_index_start = up_index_of_left_most_lane_of_original_link - min_left_most_lane_index
            down_lane_index_start = down_index_of_left_most_lane_of_original_link - min_left_most_lane_index

            number_of_connecting_lanes = min(upstream_mesolink.lanes-up_lane_index_start,
                                             downstream_mesolink.lanes-down_lane_index_start)

            for j in range(number_of_connecting_lanes):
                up_lane_index = up_lane_index_start + j
                down_lane_index = down_lane_index_start + j
                up_micronode = upstream_mesolink.micronode_list[up_lane_index][-1]
                down_micronode = downstream_mesolink.micronode_list[down_lane_index][0]
                upstream_mesolink.micronode_list[up_lane_index][-1] = down_micronode
                del self.micronet.node_dict[up_micronode.node_id]

            if extra_bike:
                up_micronode = upstream_mesolink.micronode_bike[-1]
                down_micronode = downstream_mesolink.micronode_bike[0]
                upstream_mesolink.micronode_bike[-1] = down_micronode
                del self.micronet.node_dict[up_micronode.node_id]
            if extra_walk:
                up_micronode = upstream_mesolink.micronode_walk[-1]
                down_micronode = downstream_mesolink.micronode_walk[0]
                upstream_mesolink.micronode_walk = down_micronode
                del self.micronet.node_dict[up_micronode.node_id]

        for mesolink in link.mesolink_list:
            for i in range(mesolink.lanes):
                for j in range(len(mesolink.micronode_list[i])-1):
                    microlink = MicroLink(self.micronet.max_link_id)
                    self.micronet.max_link_id += 1
                    microlink.from_node = mesolink.micronode_list[i][j]
                    microlink.to_node = mesolink.micronode_list[i][j+1]
                    microlink.geometry = geometry.LineString([microlink.from_node.geometry, microlink.to_node.geometry])
                    microlink.geometry_xy = geometry.LineString([microlink.from_node.geometry_xy, microlink.to_node.geometry_xy])
                    microlink.mesolink = mesolink
                    microlink.cell_type = 1
                    microlink.allowed_uses = mainlane_allowed_uses
                    self.micronet.link_dict[microlink.link_id] = microlink
                    microlink.from_node.outgoing_link_list.append(microlink)
                    microlink.to_node.incoming_link_list.append(microlink)

                if i <= mesolink.lanes - 2:
                    for j in range(len(mesolink.micronode_list[i])-1):
                        microlink = MicroLink(self.micronet.max_link_id)
                        self.micronet.max_link_id += 1
                        microlink.from_node = mesolink.micronode_list[i][j]
                        microlink.to_node = mesolink.micronode_list[i+1][j+1]
                        microlink.geometry = geometry.LineString([microlink.from_node.geometry, microlink.to_node.geometry])
                        microlink.geometry_xy = geometry.LineString([microlink.from_node.geometry_xy, microlink.to_node.geometry_xy])
                        microlink.mesolink = mesolink
                        microlink.cell_type = 2
                        microlink.allowed_uses = mainlane_allowed_uses
                        self.micronet.link_dict[microlink.link_id] = microlink
                        microlink.from_node.outgoing_link_list.append(microlink)
                        microlink.to_node.incoming_link_list.append(microlink)

                if i >= 1:
                    for j in range(len(mesolink.micronode_list[i])-1):
                        microlink = MicroLink(self.micronet.max_link_id)
                        self.micronet.max_link_id += 1
                        microlink.from_node = mesolink.micronode_list[i][j]
                        microlink.to_node = mesolink.micronode_list[i-1][j+1]
                        microlink.geometry = geometry.LineString([microlink.from_node.geometry, microlink.to_node.geometry])
                        microlink.geometry_xy = geometry.LineString([microlink.from_node.geometry_xy, microlink.to_node.geometry_xy])
                        microlink.mesolink = mesolink
                        microlink.cell_type = 2
                        microlink.allowed_uses = mainlane_allowed_uses
                        self.micronet.link_dict[microlink.link_id] = microlink
                        microlink.from_node.outgoing_link_list.append(microlink)
                        microlink.to_node.incoming_link_list.append(microlink)

            if extra_bike:
                for j in range(len(mesolink.micronode_bike) - 1):
                    microlink = MicroLink(self.micronet.max_link_id)
                    self.micronet.max_link_id += 1
                    microlink.from_node = mesolink.micronode_bike[j]
                    microlink.to_node = mesolink.micronode_bike[j + 1]
                    microlink.geometry = geometry.LineString([microlink.from_node.geometry, microlink.to_node.geometry])
                    microlink.geometry_xy = geometry.LineString([microlink.from_node.geometry_xy, microlink.to_node.geometry_xy])
                    microlink.mesolink = mesolink
                    microlink.cell_type = 1
                    microlink.allowed_uses = ['bike']
                    self.micronet.link_dict[microlink.link_id] = microlink
                    microlink.from_node.outgoing_link_list.append(microlink)
                    microlink.to_node.incoming_link_list.append(microlink)

            if extra_walk:
                for j in range(len(mesolink.micronode_walk) - 1):
                    microlink = MicroLink(self.micronet.max_link_id)
                    self.micronet.max_link_id += 1
                    microlink.from_node = mesolink.micronode_walk[j]
                    microlink.to_node = mesolink.micronode_walk[j + 1]
                    microlink.geometry = geometry.LineString([microlink.from_node.geometry, microlink.to_node.geometry])
                    microlink.geometry_xy = geometry.LineString([microlink.from_node.geometry_xy, microlink.to_node.geometry_xy])
                    microlink.mesolink = mesolink
                    microlink.cell_type = 1
                    microlink.allowed_uses = ['walk']
                    self.micronet.link_dict[microlink.link_id] = microlink
                    microlink.from_node.outgoing_link_list.append(microlink)
                    microlink.to_node.incoming_link_list.append(microlink)

        self.micronet.max_node_id = max(self.micronet.node_dict.keys()) + 1 if self.micronet.node_dict else 0
        self.micronet.max_link_id = max(self.micronet.link_dict.keys()) + 1 if self.micronet.link_dict else 0

    def createMesoNodeForCentriod(self):
        for node_id, node in self.macronet.node_dict.items():
            if node.is_centroid:
                if node not in self.number_of_expanded_mesonode.keys():
                    self.number_of_expanded_mesonode[node] = 0
                number_of_expanded_mesonode = self.number_of_expanded_mesonode[node]
                self.number_of_expanded_mesonode[node] += 1
                mesonode = MesoNode(node.node_id * 100 + number_of_expanded_mesonode)
                mesonode.geometry = node.geometry
                mesonode.geometry_xy = node.geometry_xy
                mesonode.macronode = node
                node.centroid_mesonode = mesonode
                self.mesonet.node_dict[mesonode.node_id] = mesonode

    def createNormalLinks(self):
        if og_settings.verbose:
            print('  generating normal meso links... (net2cell)')

        max_mesolink_id = self.mesonet.max_link_id

        for _, link in self.macronet.link_dict.items():
            macro_from_node = link.from_node
            if macro_from_node.is_centroid:
                upstream_node = macro_from_node.centroid_meso_node
            else:
                if macro_from_node not in self.number_of_expanded_mesonode.keys():
                    self.number_of_expanded_mesonode[macro_from_node] = 0
                number_of_expanded_mesonode = self.number_of_expanded_mesonode[macro_from_node]
                self.number_of_expanded_mesonode[macro_from_node] += 1

                upstream_node = MesoNode(macro_from_node.node_id * 100 + number_of_expanded_mesonode)
                upstream_node.geometry = geometry.Point(link.cutted_geometry_list[0].coords[0])
                upstream_node.geometry_xy = geometry.Point(link.cutted_geometry_xy_list[0].coords[0])
                upstream_node.macronode = macro_from_node

                self.mesonet.node_dict[upstream_node.node_id] = upstream_node

            cutted_number_of_segments = len(link.cutted_lanes_list)
            macro_to_node = link.to_node
            for section_no in range(cutted_number_of_segments):
                if macro_to_node.is_centroid and section_no == cutted_number_of_segments - 1:
                    downstream_node = macro_to_node.centroid_meso_node
                else:
                    if macro_to_node not in self.number_of_expanded_mesonode.keys():
                        self.number_of_expanded_mesonode[macro_to_node] = 0
                    number_of_expanded_mesonode = self.number_of_expanded_mesonode[macro_to_node]
                    self.number_of_expanded_mesonode[macro_to_node] += 1

                    downstream_node = MesoNode(macro_to_node.node_id * 100 + number_of_expanded_mesonode)
                    downstream_node.geometry = geometry.Point(link.cutted_geometry_list[section_no].coords[-1])
                    downstream_node.geometry_xy = geometry.Point(link.cutted_geometry_xy_list[section_no].coords[-1])
                    if section_no == cutted_number_of_segments - 1:
                        downstream_node.macronode = macro_to_node
                    else:
                        downstream_node.macrolink = link

                    self.mesonet.node_dict[downstream_node.node_id] = downstream_node

                mesolink = MesoLink(max_mesolink_id)
                mesolink.from_node = upstream_node
                mesolink.to_node = downstream_node
                mesolink.lanes = link.cutted_lanes_list[section_no]
                mesolink.lanes_change = link.cutted_lanes_change_list[section_no]
                mesolink.geometry = link.cutted_geometry_list[section_no]
                mesolink.geometry_xy = link.cutted_geometry_xy_list[section_no]
                mesolink.macrolink = link

                link.mesolink_list.append(mesolink)
                upstream_node.outgoing_link_list.append(mesolink)
                downstream_node.incoming_link_list.append(mesolink)

                self.mesonet.link_dict[mesolink.link_id] = mesolink
                max_mesolink_id += 1
                upstream_node = downstream_node

            if self.generate_micro_net:
                self.createMicroNetForNormalLink(link)

        self.mesonet.max_link_id = max_mesolink_id

    def connectMesoLinksMVMT(self):
        if og_settings.verbose:
            print('  generating movement meso links... (net2cell)')

        max_mesolink_id = self.mesonet.max_link_id
        node_has_ramp_movement_cache = {}

        for macronode, mvmt in self._buildOrderedMovementTasks():
            ib_link, ob_link = mvmt.ib_link, mvmt.ob_link
            ib_mesolink = ib_link.mesolink_list[-1]
            ob_mesolink = ob_link.mesolink_list[0]
            alignment_mode = self._getAlignmentMode(macronode, mvmt, ib_link, ob_link, ib_mesolink, ob_mesolink)
            is_merge_node = (len(macronode.incoming_link_list) > 1 and len(macronode.outgoing_link_list) == 1)
            if macronode.node_id not in node_has_ramp_movement_cache:
                has_ramp = False
                for candidate_mv in macronode.movement_list:
                    ib_meso_cand = candidate_mv.ib_link.mesolink_list[-1] if candidate_mv.ib_link.mesolink_list else None
                    ob_meso_cand = candidate_mv.ob_link.mesolink_list[0] if candidate_mv.ob_link.mesolink_list else None
                    if self._isRampMovementByTopology(macronode, candidate_mv, candidate_mv.ib_link, candidate_mv.ob_link, ib_meso_cand, ob_meso_cand):
                        has_ramp = True
                        break
                node_has_ramp_movement_cache[macronode.node_id] = has_ramp
            lane_transition_allowed = True
            if alignment_mode == 'lane_transition' and is_merge_node and node_has_ramp_movement_cache[macronode.node_id]:
                lane_transition_allowed = self._isPrimaryLaneTransitionAtMerge(
                    macronode, mvmt, ib_link, ob_link, ib_mesolink, ob_mesolink
                )
            use_lane_transition_alignment = (alignment_mode == 'lane_transition' and lane_transition_allowed)
            use_merge_primary_equal_lane_propagation = (
                (not macronode.movement_link_needed) and
                alignment_mode == 'none' and
                is_merge_node and
                node_has_ramp_movement_cache[macronode.node_id] and
                self._isPrimaryLaneTransitionAtMerge(macronode, mvmt, ib_link, ob_link, ib_mesolink, ob_mesolink)
            )
            use_equal_lane_propagation = (
                (not macronode.movement_link_needed) and
                alignment_mode == 'none' and
                self._shouldPropagateEqualLaneShift(macronode, mvmt, ib_link, ob_link, ib_mesolink, ob_mesolink)
            )
            use_whole_ob_translation = (
                use_lane_transition_alignment or
                use_equal_lane_propagation or
                use_merge_primary_equal_lane_propagation
            )
            ramp_alignment_nodes = self._getAdaptiveRampAlignmentNodes(
                macronode, mvmt, ib_link, ob_link, ib_mesolink, ob_mesolink
            ) if alignment_mode == 'ramp' else 0

            if macronode.movement_link_needed:
                mesolink = MesoLink(max_mesolink_id)
                mesolink.from_node = ib_mesolink.to_node
                mesolink.to_node = ob_mesolink.from_node
                mesolink.lanes = mvmt.lanes
                mesolink.isconnector = True
                mesolink.movement = mvmt
                mesolink.macronode = macronode

                connector_centerline_xy = self._buildConnectorCenterlineGeometry(ib_mesolink, ob_mesolink, mvmt)
                mesolink.geometry_xy = connector_centerline_xy
                mesolink.geometry = self.macronet.GT.geo_to_latlon(connector_centerline_xy)

                self.mesonet.link_dict[mesolink.link_id] = mesolink
                max_mesolink_id += 1

                mesolink.from_node.outgoing_link_list.append(mesolink)
                mesolink.to_node.incoming_link_list.append(mesolink)
                if self.generate_micro_net:
                    if self._generate_connector_micro:
                        self.createMicroNetForConnector(mesolink, ib_mesolink, mvmt.start_ib_lane_seq_no, ob_mesolink, mvmt.start_ob_lane_seq_no)
                    # Group-wise alignment: off ramp vs on ramp with gradual transition
                    try:
                        affected = set()
                        if use_whole_ob_translation:
                            if (0 <= mvmt.start_ib_lane_seq_no < len(ib_mesolink.micronode_list)
                                    and 0 <= mvmt.start_ob_lane_seq_no < len(ob_mesolink.micronode_list)):
                                ib_ref = ib_mesolink.micronode_list[mvmt.start_ib_lane_seq_no][-1]
                                ob_ref_nodes = ob_mesolink.micronode_list[mvmt.start_ob_lane_seq_no]
                                if ob_ref_nodes:
                                    ob_ref = ob_ref_nodes[0]
                                    desired_dx = ib_ref.geometry_xy.x - ob_ref.geometry_xy.x
                                    desired_dy = ib_ref.geometry_xy.y - ob_ref.geometry_xy.y
                                    dx, dy = self._boundedWholeLinkTranslation(
                                        ob_mesolink, mvmt, ib_link, ob_link, alignment_mode, desired_dx, desired_dy
                                    )
                                    if abs(dx) > 1e-9 or abs(dy) > 1e-9:
                                        self._translateWholeObMesoLinkNodes(ob_mesolink, dx, dy, affected)
                        # Ramp alignment keeps the original behavior with gradual transition.
                        elif ib_mesolink.lanes >= ob_mesolink.lanes:
                            num_nodes_to_shift = min(ramp_alignment_nodes, len(ob_mesolink.micronode_list[0]) if ob_mesolink.micronode_list else 0)
                            for i_lane in range(mvmt.lanes):
                                ib_idx = mvmt.start_ib_lane_seq_no + i_lane
                                ob_idx = mvmt.start_ob_lane_seq_no + i_lane
                                if ob_idx < 0 or ob_idx >= len(ob_mesolink.micronode_list):
                                    continue
                                if ib_idx < 0 or ib_idx >= len(ib_mesolink.micronode_list):
                                    continue
                                ib_end_node = ib_mesolink.micronode_list[ib_idx][-1]
                                ob_lane_nodes = ob_mesolink.micronode_list[ob_idx]
                                if not ob_lane_nodes:
                                    continue
                                dx = ib_end_node.geometry_xy.x - ob_lane_nodes[0].geometry_xy.x
                                dy = ib_end_node.geometry_xy.y - ob_lane_nodes[0].geometry_xy.y
                                if abs(dx) < 1e-9 and abs(dy) < 1e-9:
                                    continue
                                for idx in range(num_nodes_to_shift):
                                    if idx < len(ob_lane_nodes):
                                        n = ob_lane_nodes[idx]
                                        ratio = 1.0 - (idx / num_nodes_to_shift)
                                        n.geometry_xy = geometry.Point((n.geometry_xy.x + dx * ratio, n.geometry_xy.y + dy * ratio))
                                        n.geometry = self.macronet.GT.geo_to_latlon(n.geometry_xy)
                                        for lk in n.outgoing_link_list:
                                            affected.add(lk.link_id)
                                        for lk in n.incoming_link_list:
                                            affected.add(lk.link_id)
                        else:
                            num_nodes_to_shift = min(ramp_alignment_nodes, len(ib_mesolink.micronode_list[0]) if ib_mesolink.micronode_list else 0)
                            for i_lane in range(mvmt.lanes):
                                ib_lane_idx = mvmt.start_ib_lane_seq_no + i_lane
                                ob_lane_idx = mvmt.start_ob_lane_seq_no + i_lane
                                if ib_lane_idx < 0 or ib_lane_idx >= len(ib_mesolink.micronode_list):
                                    continue
                                if ob_lane_idx < 0 or ob_lane_idx >= len(ob_mesolink.micronode_list):
                                    continue
                                ib_lane_end = ib_mesolink.micronode_list[ib_lane_idx][-1]
                                ob_lane_start = ob_mesolink.micronode_list[ob_lane_idx][0]
                                lane_dx = ib_lane_end.geometry_xy.x - ob_lane_start.geometry_xy.x
                                lane_dy = ib_lane_end.geometry_xy.y - ob_lane_start.geometry_xy.y
                                if abs(lane_dx) < 1e-9 and abs(lane_dy) < 1e-9:
                                    continue
                                if alignment_mode == 'ramp':
                                    shift_dx, shift_dy = self._boundedRampLocalShift(mvmt, lane_dx, lane_dy)
                                    lane_nodes = ib_mesolink.micronode_list[ib_lane_idx]
                                    lane_len = len(lane_nodes)
                                    for idx in range(num_nodes_to_shift):
                                        node_idx = lane_len - num_nodes_to_shift + idx
                                        if 0 <= node_idx < lane_len:
                                            n = lane_nodes[node_idx]
                                            ratio = (idx + 1) / num_nodes_to_shift
                                            n.geometry_xy = geometry.Point((n.geometry_xy.x - shift_dx * ratio, n.geometry_xy.y - shift_dy * ratio))
                                            n.geometry = self.macronet.GT.geo_to_latlon(n.geometry_xy)
                                            for lk in n.outgoing_link_list:
                                                affected.add(lk.link_id)
                                            for lk in n.incoming_link_list:
                                                affected.add(lk.link_id)
                                else:
                                    lane_nodes = ib_mesolink.micronode_list[ib_lane_idx]
                                    lane_len = len(lane_nodes)
                                    for idx in range(num_nodes_to_shift):
                                        node_idx = lane_len - num_nodes_to_shift + idx
                                        if 0 <= node_idx < lane_len:
                                            n = lane_nodes[node_idx]
                                            ratio = (idx + 1) / num_nodes_to_shift
                                            n.geometry_xy = geometry.Point((n.geometry_xy.x - lane_dx * ratio, n.geometry_xy.y - lane_dy * ratio))
                                            n.geometry = self.macronet.GT.geo_to_latlon(n.geometry_xy)
                                            for lk in n.outgoing_link_list:
                                                affected.add(lk.link_id)
                                            for lk in n.incoming_link_list:
                                                affected.add(lk.link_id)
                        # Rebuild connector's intermediate nodes after alignment
                        # Both off ramp and on ramp need this, as endpoints have moved
                        if mesolink and mesolink.isconnector and hasattr(mesolink, 'micronode_list'):
                            for connector_lane_idx in range(len(mesolink.micronode_list)):
                                if connector_lane_idx < mvmt.lanes:
                                    ob_lane_idx = mvmt.start_ob_lane_seq_no + connector_lane_idx
                                    ib_lane_idx = mvmt.start_ib_lane_seq_no + connector_lane_idx
                                    if (0 <= ob_lane_idx < len(ob_mesolink.micronode_list) and
                                        0 <= ib_lane_idx < len(ib_mesolink.micronode_list)):
                                        connector_nodes = mesolink.micronode_list[connector_lane_idx]
                                        if len(connector_nodes) > 0:
                                            ib_end = ib_mesolink.micronode_list[ib_lane_idx][-1]
                                            ob_start = ob_mesolink.micronode_list[ob_lane_idx][0]
                                            lane_geometry_xy = self._buildConnectorLaneGeometry(
                                                start_micronode=ib_end,
                                                end_micronode=ob_start,
                                                ib_mesolink=ib_mesolink,
                                                ib_lane_idx=ib_lane_idx,
                                                ob_mesolink=ob_mesolink,
                                                ob_lane_idx=ob_lane_idx,
                                                mvmt=mvmt
                                            )
                                            total_nodes = len(connector_nodes) + 1
                                            for idx, n in enumerate(connector_nodes):
                                                t = (idx + 1) / total_nodes
                                                p = lane_geometry_xy.interpolate(t, normalized=True)
                                                n.geometry_xy = p
                                                n.geometry = self.macronet.GT.geo_to_latlon(n.geometry_xy)
                                                for lk in n.outgoing_link_list:
                                                    affected.add(lk.link_id)
                                                for lk in n.incoming_link_list:
                                                    affected.add(lk.link_id)
                        if use_lane_transition_alignment:
                            # For movement-link connectors, add guide on connector->downstream
                            # boundary (connector lanes are 1..mvmt.lanes).
                            guide_results = self._addLaneTransitionGuideLinksByMapping(
                                0, mvmt.start_ob_lane_seq_no, mvmt.lanes, mesolink, ob_mesolink
                            )
                            for guide_result in guide_results:
                                guide_link_id, guide_lane_idx = guide_result
                                affected.add(guide_link_id)
                                affected.update(self._smoothUnmappedDownstreamLanesByRange(
                                    mvmt.start_ob_lane_seq_no, mvmt.lanes, ob_mesolink, guide_lane_idx
                                ))
                        self._refreshMicroLinkGeometry(affected)
                    except Exception:
                        pass
            else:
                if ib_link.downstream_is_target and not ob_link.upstream_is_target:
                        ib_mesolink_to_node = ib_mesolink.to_node
                        ob_mesolink_from_node = ob_mesolink.from_node
                        ob_mesolink.from_node = ib_mesolink_to_node
                        ob_mesolink.geometry = geometry.LineString([ib_mesolink.geometry.coords[-1]] + ob_mesolink.geometry.coords[1:])
                        ob_mesolink.geometry_xy = geometry.LineString([ib_mesolink.geometry_xy.coords[-1]] + ob_mesolink.geometry_xy.coords[1:])
                        del self.mesonet.node_dict[ob_mesolink_from_node.node_id]
                        if self.generate_micro_net:
                            # Group-wise alignment: off ramp vs on ramp
                            try:
                                affected = set()
                                if use_whole_ob_translation:
                                    if (0 <= mvmt.start_ib_lane_seq_no < len(ib_mesolink.micronode_list)
                                            and 0 <= mvmt.start_ob_lane_seq_no < len(ob_mesolink.micronode_list)):
                                        ib_ref = ib_mesolink.micronode_list[mvmt.start_ib_lane_seq_no][-1]
                                        ob_ref_nodes = ob_mesolink.micronode_list[mvmt.start_ob_lane_seq_no]
                                        if ob_ref_nodes:
                                            ob_ref = ob_ref_nodes[0]
                                            desired_dx = ib_ref.geometry_xy.x - ob_ref.geometry_xy.x
                                            desired_dy = ib_ref.geometry_xy.y - ob_ref.geometry_xy.y
                                            dx, dy = self._boundedWholeLinkTranslation(
                                                ob_mesolink, mvmt, ib_link, ob_link, alignment_mode, desired_dx, desired_dy
                                            )
                                            if abs(dx) > 1e-9 or abs(dy) > 1e-9:
                                                self._translateWholeObMesoLinkNodes(ob_mesolink, dx, dy, affected)
                                elif ib_mesolink.lanes >= ob_mesolink.lanes:
                                    num_nodes_to_shift = min(ramp_alignment_nodes, len(ob_mesolink.micronode_list[0]) if ob_mesolink.micronode_list else 0)
                                    for i_lane in range(mvmt.lanes):
                                        ib_idx = mvmt.start_ib_lane_seq_no + i_lane
                                        ob_idx = mvmt.start_ob_lane_seq_no + i_lane
                                        if ob_idx < 0 or ob_idx >= len(ob_mesolink.micronode_list):
                                            continue
                                        if ib_idx < 0 or ib_idx >= len(ib_mesolink.micronode_list):
                                            continue
                                        ib_end_node = ib_mesolink.micronode_list[ib_idx][-1]
                                        ob_lane_nodes = ob_mesolink.micronode_list[ob_idx]
                                        if not ob_lane_nodes:
                                            continue
                                        dx = ib_end_node.geometry_xy.x - ob_lane_nodes[0].geometry_xy.x
                                        dy = ib_end_node.geometry_xy.y - ob_lane_nodes[0].geometry_xy.y
                                        if abs(dx) < 1e-9 and abs(dy) < 1e-9:
                                            continue
                                        for idx in range(num_nodes_to_shift):
                                            if idx < len(ob_lane_nodes):
                                                n = ob_lane_nodes[idx]
                                                ratio = 1.0 - (idx / num_nodes_to_shift)
                                                n.geometry_xy = geometry.Point((n.geometry_xy.x + dx * ratio, n.geometry_xy.y + dy * ratio))
                                                n.geometry = self.macronet.GT.geo_to_latlon(n.geometry_xy)
                                                for lk in n.outgoing_link_list:
                                                    affected.add(lk.link_id)
                                                for lk in n.incoming_link_list:
                                                    affected.add(lk.link_id)
                                else:
                                    num_nodes_to_shift = min(ramp_alignment_nodes, len(ib_mesolink.micronode_list[0]) if ib_mesolink.micronode_list else 0)
                                    for i_lane in range(mvmt.lanes):
                                        ib_lane_idx = mvmt.start_ib_lane_seq_no + i_lane
                                        ob_lane_idx = mvmt.start_ob_lane_seq_no + i_lane
                                        if ib_lane_idx < 0 or ib_lane_idx >= len(ib_mesolink.micronode_list):
                                            continue
                                        if ob_lane_idx < 0 or ob_lane_idx >= len(ob_mesolink.micronode_list):
                                            continue
                                        ib_lane_end = ib_mesolink.micronode_list[ib_lane_idx][-1]
                                        ob_lane_start = ob_mesolink.micronode_list[ob_lane_idx][0]
                                        lane_dx = ib_lane_end.geometry_xy.x - ob_lane_start.geometry_xy.x
                                        lane_dy = ib_lane_end.geometry_xy.y - ob_lane_start.geometry_xy.y
                                        if abs(lane_dx) < 1e-9 and abs(lane_dy) < 1e-9:
                                            continue
                                        if alignment_mode == 'ramp':
                                            shift_dx, shift_dy = self._boundedRampLocalShift(mvmt, lane_dx, lane_dy)
                                            lane_nodes = ib_mesolink.micronode_list[ib_lane_idx]
                                            lane_len = len(lane_nodes)
                                            for idx in range(num_nodes_to_shift):
                                                node_idx = lane_len - num_nodes_to_shift + idx
                                                if 0 <= node_idx < lane_len:
                                                    n = lane_nodes[node_idx]
                                                    ratio = (idx + 1) / num_nodes_to_shift
                                                    n.geometry_xy = geometry.Point((n.geometry_xy.x - shift_dx * ratio, n.geometry_xy.y - shift_dy * ratio))
                                                    n.geometry = self.macronet.GT.geo_to_latlon(n.geometry_xy)
                                                    for lk in n.outgoing_link_list:
                                                        affected.add(lk.link_id)
                                                    for lk in n.incoming_link_list:
                                                        affected.add(lk.link_id)
                                        else:
                                            lane_nodes = ib_mesolink.micronode_list[ib_lane_idx]
                                            lane_len = len(lane_nodes)
                                            for idx in range(num_nodes_to_shift):
                                                node_idx = lane_len - num_nodes_to_shift + idx
                                                if 0 <= node_idx < lane_len:
                                                    n = lane_nodes[node_idx]
                                                    ratio = (idx + 1) / num_nodes_to_shift
                                                    n.geometry_xy = geometry.Point((n.geometry_xy.x - lane_dx * ratio, n.geometry_xy.y - lane_dy * ratio))
                                                    n.geometry = self.macronet.GT.geo_to_latlon(n.geometry_xy)
                                                    for lk in n.outgoing_link_list:
                                                        affected.add(lk.link_id)
                                                    for lk in n.incoming_link_list:
                                                        affected.add(lk.link_id)
                                rewired_links = self._replaceObLaneStartsWithIbLaneEnds(mvmt, ib_mesolink, ob_mesolink)
                                affected.update(rewired_links)
                                if use_lane_transition_alignment:
                                    guide_result = self._addLaneTransitionGuideLink(mvmt, ib_mesolink, ob_mesolink)
                                    if guide_result is not None:
                                        guide_link_id, guide_lane_idx = guide_result
                                        affected.add(guide_link_id)
                                        affected.update(self._smoothUnmappedDownstreamLanes(mvmt, ob_mesolink, guide_lane_idx))
                                self._refreshMicroLinkGeometry(affected)
                            except Exception:
                                pass
                elif not ib_link.downstream_is_target and ob_link.upstream_is_target:
                        ib_mesolink_to_node = ib_mesolink.to_node
                        ob_mesolink_from_node = ob_mesolink.from_node
                        ib_mesolink.to_node = ob_mesolink_from_node
                        ib_mesolink.geometry = geometry.LineString(ib_mesolink.geometry.coords[:-1] + [ob_mesolink.geometry.coords[0]])
                        ib_mesolink.geometry_xy = geometry.LineString(ib_mesolink.geometry_xy.coords[:-1] + [ob_mesolink.geometry_xy.coords[0]])
                        del self.mesonet.node_dict[ib_mesolink_to_node.node_id]
                        if self.generate_micro_net:
                            # Group-wise alignment: off ramp vs on ramp
                            try:
                                affected = set()
                                if use_whole_ob_translation:
                                    if (0 <= mvmt.start_ib_lane_seq_no < len(ib_mesolink.micronode_list)
                                            and 0 <= mvmt.start_ob_lane_seq_no < len(ob_mesolink.micronode_list)):
                                        ib_ref = ib_mesolink.micronode_list[mvmt.start_ib_lane_seq_no][-1]
                                        ob_ref_nodes = ob_mesolink.micronode_list[mvmt.start_ob_lane_seq_no]
                                        if ob_ref_nodes:
                                            ob_ref = ob_ref_nodes[0]
                                            desired_dx = ib_ref.geometry_xy.x - ob_ref.geometry_xy.x
                                            desired_dy = ib_ref.geometry_xy.y - ob_ref.geometry_xy.y
                                            dx, dy = self._boundedWholeLinkTranslation(
                                                ob_mesolink, mvmt, ib_link, ob_link, alignment_mode, desired_dx, desired_dy
                                            )
                                            if abs(dx) > 1e-9 or abs(dy) > 1e-9:
                                                self._translateWholeObMesoLinkNodes(ob_mesolink, dx, dy, affected)
                                elif ib_mesolink.lanes >= ob_mesolink.lanes:
                                    num_nodes_to_shift = min(ramp_alignment_nodes, len(ob_mesolink.micronode_list[0]) if ob_mesolink.micronode_list else 0)
                                    for i_lane in range(mvmt.lanes):
                                        ib_idx = mvmt.start_ib_lane_seq_no + i_lane
                                        ob_idx = mvmt.start_ob_lane_seq_no + i_lane
                                        if ob_idx < 0 or ob_idx >= len(ob_mesolink.micronode_list):
                                            continue
                                        if ib_idx < 0 or ib_idx >= len(ib_mesolink.micronode_list):
                                            continue
                                        ib_end_node = ib_mesolink.micronode_list[ib_idx][-1]
                                        ob_lane_nodes = ob_mesolink.micronode_list[ob_idx]
                                        if not ob_lane_nodes:
                                            continue
                                        dx = ib_end_node.geometry_xy.x - ob_lane_nodes[0].geometry_xy.x
                                        dy = ib_end_node.geometry_xy.y - ob_lane_nodes[0].geometry_xy.y
                                        if abs(dx) < 1e-9 and abs(dy) < 1e-9:
                                            continue
                                        for idx in range(num_nodes_to_shift):
                                            if idx < len(ob_lane_nodes):
                                                n = ob_lane_nodes[idx]
                                                ratio = 1.0 - (idx / num_nodes_to_shift)
                                                n.geometry_xy = geometry.Point((n.geometry_xy.x + dx * ratio, n.geometry_xy.y + dy * ratio))
                                                n.geometry = self.macronet.GT.geo_to_latlon(n.geometry_xy)
                                                for lk in n.outgoing_link_list:
                                                    affected.add(lk.link_id)
                                                for lk in n.incoming_link_list:
                                                    affected.add(lk.link_id)
                                else:
                                    num_nodes_to_shift = min(ramp_alignment_nodes, len(ib_mesolink.micronode_list[0]) if ib_mesolink.micronode_list else 0)
                                    for i_lane in range(mvmt.lanes):
                                        ib_lane_idx = mvmt.start_ib_lane_seq_no + i_lane
                                        ob_lane_idx = mvmt.start_ob_lane_seq_no + i_lane
                                        if ib_lane_idx < 0 or ib_lane_idx >= len(ib_mesolink.micronode_list):
                                            continue
                                        if ob_lane_idx < 0 or ob_lane_idx >= len(ob_mesolink.micronode_list):
                                            continue
                                        ib_lane_end = ib_mesolink.micronode_list[ib_lane_idx][-1]
                                        ob_lane_start = ob_mesolink.micronode_list[ob_lane_idx][0]
                                        lane_dx = ib_lane_end.geometry_xy.x - ob_lane_start.geometry_xy.x
                                        lane_dy = ib_lane_end.geometry_xy.y - ob_lane_start.geometry_xy.y
                                        if abs(lane_dx) < 1e-9 and abs(lane_dy) < 1e-9:
                                            continue
                                        if alignment_mode == 'ramp':
                                            shift_dx, shift_dy = self._boundedRampLocalShift(mvmt, lane_dx, lane_dy)
                                            lane_nodes = ib_mesolink.micronode_list[ib_lane_idx]
                                            lane_len = len(lane_nodes)
                                            for idx in range(num_nodes_to_shift):
                                                node_idx = lane_len - num_nodes_to_shift + idx
                                                if 0 <= node_idx < lane_len:
                                                    n = lane_nodes[node_idx]
                                                    ratio = (idx + 1) / num_nodes_to_shift
                                                    n.geometry_xy = geometry.Point((n.geometry_xy.x - shift_dx * ratio, n.geometry_xy.y - shift_dy * ratio))
                                                    n.geometry = self.macronet.GT.geo_to_latlon(n.geometry_xy)
                                                    for lk in n.outgoing_link_list:
                                                        affected.add(lk.link_id)
                                                    for lk in n.incoming_link_list:
                                                        affected.add(lk.link_id)
                                        else:
                                            lane_nodes = ib_mesolink.micronode_list[ib_lane_idx]
                                            lane_len = len(lane_nodes)
                                            for idx in range(num_nodes_to_shift):
                                                node_idx = lane_len - num_nodes_to_shift + idx
                                                if 0 <= node_idx < lane_len:
                                                    n = lane_nodes[node_idx]
                                                    ratio = (idx + 1) / num_nodes_to_shift
                                                    n.geometry_xy = geometry.Point((n.geometry_xy.x - lane_dx * ratio, n.geometry_xy.y - lane_dy * ratio))
                                                    n.geometry = self.macronet.GT.geo_to_latlon(n.geometry_xy)
                                                    for lk in n.outgoing_link_list:
                                                        affected.add(lk.link_id)
                                                    for lk in n.incoming_link_list:
                                                        affected.add(lk.link_id)
                                rewired_links = self._replaceIbLaneEndsWithObLaneStarts(mvmt, ib_mesolink, ob_mesolink)
                                affected.update(rewired_links)
                                if use_lane_transition_alignment:
                                    guide_result = self._addLaneTransitionGuideLink(mvmt, ib_mesolink, ob_mesolink)
                                    if guide_result is not None:
                                        guide_link_id, guide_lane_idx = guide_result
                                        affected.add(guide_link_id)
                                        affected.update(self._smoothUnmappedDownstreamLanes(mvmt, ob_mesolink, guide_lane_idx))
                                self._refreshMicroLinkGeometry(affected)
                            except Exception:
                                pass
                else:
                    sys.exit('Target link defintion error')

        self.mesonet.max_link_id = max_mesolink_id

    def generateNet(self):
        self.createMesoNodeForCentriod()
        self.createNormalLinks()
        self.connectMesoLinksMVMT()
