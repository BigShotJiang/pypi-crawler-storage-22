# API module for notices plugin
