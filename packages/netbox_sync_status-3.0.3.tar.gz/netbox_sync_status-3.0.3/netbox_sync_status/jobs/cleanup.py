from core.choices import JobIntervalChoices
from netbox.jobs import JobRunner, system_job
from .. import models


@system_job(interval=JobIntervalChoices.INTERVAL_DAILY)
class HousekeepingJob(JobRunner):
    class Meta:
        name = "Sync Status Cleanup Job"

    def run(self, *args, **kwargs):
        for sync_status in models.SyncStatus.objects.all():
            if sync_status.object is None:
                sync_status.delete()
