from django.contrib.contenttypes.fields import GenericForeignKey
from django.core.exceptions import ValidationError
from django.db import models
from django.urls import reverse
from django.utils.translation import gettext_lazy as _
from netbox.models import NetBoxModel
from netbox.models.features import (
    CustomValidationMixin,
    EventRulesMixin,
    ExportTemplatesMixin,
    TagsMixin,
)
from utilities.choices import ChoiceSet
from utilities.querysets import RestrictedQuerySet


class StatusChoices(ChoiceSet):
    key = "SyncStatus.status"

    CHOICES = [
        ("success", "Success", "green"),
        ("failed", "Failed", "red"),
        ("skip", "Skipped", "primary"),
    ]


class SyncSystem(NetBoxModel):
    objects = RestrictedQuerySet.as_manager()

    name = models.CharField(max_length=100)

    description = models.TextField(blank=True)

    object_types = models.ManyToManyField(
        to="core.ObjectType",
        related_name="+",
        blank=True,
        help_text=_(
            "The object type(s) to which this system can report sync status to."
        ),
    )

    def get_absolute_url(self):
        return reverse("plugins:netbox_sync_status:syncsystem", args=[self.pk])

    def __str__(self):
        return self.name

    class Meta:
        ordering = ("name",)
        verbose_name = "Sync System"
        verbose_name_plural = "Sync Systems"


class SyncStatus(
    CustomValidationMixin,
    ExportTemplatesMixin,
    TagsMixin,
    EventRulesMixin,
    models.Model,
):
    objects = RestrictedQuerySet.as_manager()

    object_type = models.ForeignKey(
        to="contenttypes.ContentType",
        on_delete=models.PROTECT,
        related_name="+",
        blank=True,
        null=False,
    )

    object_id = models.PositiveBigIntegerField(blank=True, null=False)

    object = GenericForeignKey(ct_field="object_type", fk_field="object_id")

    last_updated = models.DateTimeField(
        verbose_name=_("last updated"), auto_now=True, blank=True, null=True
    )

    status = models.CharField(
        max_length=30,
        choices=StatusChoices,
    )

    system = models.ForeignKey(
        to=SyncSystem, on_delete=models.CASCADE, related_name="sync_events"
    )

    message = models.TextField(blank=True)

    def get_status_color(self):
        return StatusChoices.colors.get(self.status)

    def clean(self):
        super().clean()
        self._validate_generic_relation()

    def _validate_generic_relation(self):
        """Validate that the generic foreign key points to a real object."""
        if self.object_id and self.object_type:
            model_class = self.object_type.model_class()
            if (
                model_class
                and not model_class.objects.filter(pk=self.object_id).exists()
            ):
                raise ValidationError(
                    {
                        "object_id": f"No {self.object_type.model} found with id {self.object_id}"
                    }
                )

    def save(self, *args, **kwargs):
        # Ensure clean() is called on save
        self.clean()
        super().save(*args, **kwargs)

    class Meta:
        ordering = ("system", "last_updated")
        verbose_name = "Sync Status"
        verbose_name_plural = "Sync Status"
        constraints = [
            models.UniqueConstraint(
                fields=["object_id", "object_type", "system"],
                name="unique_sync_status_per_object_system",
            )
        ]

    def __str__(self):
        return f"{self.system} - {self.status}"
