"""Utilities for netconan."""
