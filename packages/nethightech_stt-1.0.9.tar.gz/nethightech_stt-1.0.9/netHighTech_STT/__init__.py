import time
import os
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

def listen():
    chrome_options = webdriver.ChromeOptions()
    chrome_options.add_argument("--use-fake-ui-for-media-stream")
    # ❌ HEADLESS OFF
    # chrome_options.add_argument("--headless=new")

    driver = webdriver.Chrome(
        service=Service(ChromeDriverManager().install()),
        options=chrome_options
    )

    html_path = f"file:///{os.path.join(BASE_DIR, 'index.html')}"
    driver.get(html_path)

    driver.find_element(By.ID, 'start-btn').click()
    print("🎤 Jarvis is Listening...")

    while True:
        output = driver.find_element(By.ID, 'result').text.strip()

        if len(output) > 1:
            print("Heard:", output)
            driver.execute_script(
                "document.getElementById('result').textContent = '';"
            )
            return output   # 🔥🔥 MOST IMPORTANT LINE 🔥🔥

        time.sleep(0.3)
import time
import os
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

def listen():
    chrome_options = webdriver.ChromeOptions()
    chrome_options.add_argument("--use-fake-ui-for-media-stream")
    # ❌ HEADLESS OFF
    chrome_options.add_argument("--headless=new")

    driver = webdriver.Chrome(
        service=Service(ChromeDriverManager().install()),
        options=chrome_options
    )

    html_path = f"file:///{os.path.join(BASE_DIR, 'index.html')}"
    driver.get(html_path)

    driver.find_element(By.ID, 'start-btn').click()
    print("🎤 Jarvis is Listening...")

    while True:
        output = driver.find_element(By.ID, 'result').text.strip()

        if len(output) > 1:
            print("Heard:", output)
            driver.execute_script(
                "document.getElementById('result').textContent = '';"
            )
            return output   # 🔥🔥 MOST IMPORTANT LINE 🔥🔥

        time.sleep(0.3)
