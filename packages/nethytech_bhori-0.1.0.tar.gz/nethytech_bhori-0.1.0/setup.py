from setuptools import setup, find_packages

setup(
    name='nethytech-bhori',
    version='0.1.0',
    author='Shabbir Bhori',
    author_email='bhorishabbir5253@gmail.com',
    description='this is speech to text package created by shabbir bhori'
)
packages = find_packages(),
install_requirements = [
    'selenium',
    'webdriver-manager'
]