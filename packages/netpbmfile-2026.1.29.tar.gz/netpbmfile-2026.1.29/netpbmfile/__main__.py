# netpbmfile/__main__.py

"""Netpbmfile package command line script."""

import sys

from .netpbmfile import main

sys.exit(main())
