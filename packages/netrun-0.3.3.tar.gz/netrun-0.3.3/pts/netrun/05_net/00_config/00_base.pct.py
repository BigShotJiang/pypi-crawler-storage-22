# ---
# jupyter:
#   kernelspec:
#     display_name: .venv
#     language: python
#     name: python3
# ---

# %%
#|default_exp net.config._base

# %%
#|hide
from nblite import nbl_export; nbl_export();

# %%
#|export
from pydantic import BaseModel, Field, PrivateAttr, model_validator, field_serializer, field_validator
from typing import Annotated, Literal, NewType, Any, get_origin
from types import ModuleType
from collections.abc import Callable
import importlib
import importlib.util
import json as _json_module
import os
import sys
import tomllib
from ulid import ULID

import netrun_sim
from netrun.execution_manager import RunAllocationMethod

# %%
#|export
def _get_callable_import_path(func: Callable) -> str:
    """Get the import path for a callable (function or method).

    Args:
        func: The callable to get the import path for.

    Returns:
        The import path as "module.qualname" (e.g., "myapp.utils.process_data").

    Raises:
        ValueError: If the callable cannot be serialized (lambda, closure, __main__).
    """
    module = getattr(func, "__module__", None)
    qualname = getattr(func, "__qualname__", None)

    if module is None or qualname is None:
        raise ValueError(
            f"Cannot serialize callable {func}: missing __module__ or __qualname__"
        )

    if module == "__main__":
        raise ValueError(
            f"Cannot serialize callable '{qualname}' defined in __main__. "
            "Move it to an importable module or use a string import path."
        )

    if "<lambda>" in qualname:
        raise ValueError(
            f"Cannot serialize lambda functions. "
            "Define a named function or use a string import path."
        )

    if "<locals>" in qualname:
        raise ValueError(
            f"Cannot serialize closure/local function '{qualname}'. "
            "Define it at module level or use a string import path."
        )

    return f"{module}.{qualname}"


def _get_type_import_path(type_obj: type) -> str:
    """Get the import path for a type.

    Args:
        type_obj: The type to get the import path for.

    Returns:
        The import path as "module.qualname" (e.g., "pandas.DataFrame").
        For builtin types, returns just the name (e.g., "int", "str").

    Raises:
        ValueError: If the type cannot be serialized (__main__).
    """
    module = getattr(type_obj, "__module__", None)
    qualname = getattr(type_obj, "__qualname__", None)

    if module is None or qualname is None:
        raise ValueError(
            f"Cannot serialize type {type_obj}: missing __module__ or __qualname__"
        )

    if module == "__main__":
        raise ValueError(
            f"Cannot serialize type '{qualname}' defined in __main__. "
            "Move it to an importable module or use a string import path."
        )

    if module == "builtins":
        # Built-in types like int, str, list, dict - just use name
        return qualname

    return f"{module}.{qualname}"


def _is_file_path_ref(s: str) -> bool:
    """Check if string is a file-path reference (vs dotted import path).

    A string is a file-path reference if any of:
    - Contains '::' (file path + attribute separator)
    - Contains '/' or '\\' (path separator)
    - Starts with '.' (relative path like './' or '../')
    """
    return '::' in s or '/' in s or '\\' in s or s.startswith('.')


def _import_from_file_path(file_ref: str, project_root: 'Path | None' = None) -> Any:
    """Import from a file-path reference.

    - "path/to/file.py::attr" -> load file, getattr(module, attr)
    - "path/to/file.py" -> load file, return module

    Relative paths resolve from project_root (or cwd).
    """
    if '::' in file_ref:
        file_path_str, attr_name = file_ref.split('::', 1)
    else:
        file_path_str = file_ref
        attr_name = None

    file_path = Path(file_path_str)
    if not file_path.is_absolute():
        base = project_root if project_root is not None else Path(os.getcwd())
        file_path = (base / file_path).resolve()
    else:
        file_path = file_path.resolve()

    if not file_path.exists():
        raise FileNotFoundError(f"Module file not found: {file_path}")

    module_name = f"_netrun_filemod_{file_path.stem}_{hash(str(file_path)) & 0xFFFFFFFF:08x}"

    spec = importlib.util.spec_from_file_location(module_name, str(file_path))
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot create module spec from: {file_path}")

    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)

    if attr_name is not None:
        return getattr(module, attr_name)
    return module


def _import_from_path(import_path: str, project_root: 'Path | None' = None) -> Any:
    """Import an object from a dotted import path or file-path reference.

    Args:
        import_path: Dotted import path (e.g., "myapp.utils.my_function")
                     or file-path reference (e.g., "./nodes.py::my_func").
        project_root: Base path for resolving relative file paths.

    Returns:
        The imported object.

    Raises:
        ImportError: If the module cannot be imported.
        AttributeError: If the object doesn't exist in the module.
    """
    if _is_file_path_ref(import_path):
        return _import_from_file_path(import_path, project_root=project_root)
    module_path, name = import_path.rsplit(".", 1)
    module = importlib.import_module(module_path)
    return getattr(module, name)

# %% [markdown]
# # Port Configuration
#
# These Pydantic models mirror the `netrun_sim` graph types, providing a serializable
# DSL for defining flow-based networks.

# %% [markdown]
# ## Port slot specification
#
# Defines the capacity of a port (how many packets it can hold).

# %%
#|export
class PortSlotSpecInfiniteConfig(BaseModel):
    """Port can hold unlimited packets."""
    type: Literal["infinite"] = "infinite"

    def to_netrun_sim(self) -> netrun_sim.PortSlotSpec:
        return netrun_sim.PortSlotSpec.infinite()


class PortSlotSpecFiniteConfig(BaseModel):
    """Port can hold at most `capacity` packets."""
    type: Literal["finite"] = "finite"
    capacity: int

    def to_netrun_sim(self) -> netrun_sim.PortSlotSpecFinite:
        return netrun_sim.PortSlotSpec.finite(self.capacity)


PortSlotSpecConfig = Annotated[
    PortSlotSpecInfiniteConfig | PortSlotSpecFiniteConfig,
    Field(discriminator="type")
]

# %% [markdown]
# ## Port type configuration
#
# Optional type validation for packets flowing through ports.

# %%
#|export
class PortTypeConfig(BaseModel):
    """Detailed port type configuration.

    Used when you need more control than a simple type name string.
    """
    name: str
    """Type name to match (e.g., "DataFrame", "dict", "MyClass")."""

    isinstance_check: bool = False
    """If True and a type object is available, use isinstance().
    If False, use type().__name__ match. Default is False (name match)."""


# Type specification union - supports multiple formats
PortTypeSpec = str | type | PortTypeConfig
"""Port type specification.

Can be:
- str: Type name to match against type(value).__name__
- type: Type object for isinstance() check
- PortTypeConfig: Detailed configuration
"""

# %% [markdown]
# ## Port configuration

# %%
#|export
class PortConfig(BaseModel):
    """Configuration for a port on a node."""
    model_config = {"arbitrary_types_allowed": True}

    slots_spec: PortSlotSpecConfig = Field(default_factory=PortSlotSpecInfiniteConfig)

    port_type: Any = None
    """Expected type for packets on this port.

    - None: No validation (default)
    - str: Match type(value).__name__ exactly
    - type: Use isinstance(value, port_type) or beartype for generics
    - PortTypeConfig: Detailed configuration

    Generic types like list[int], dict[str, int] are supported and use
    beartype for proper validation.

    Example:
        PortConfig(port_type="DataFrame")  # Match by name
        PortConfig(port_type=pd.DataFrame)  # Match with isinstance
        PortConfig(port_type=list[int])     # Match with beartype
    """

    @field_validator("port_type")
    @classmethod
    def validate_port_type(cls, v):
        if v is None:
            return v
        if isinstance(v, (str, type, PortTypeConfig)):
            return v
        if get_origin(v) is not None:
            return v  # Generic alias like list[int], dict[str, int]
        raise ValueError(
            f"port_type must be str, type, generic type, PortTypeConfig, or None, got {type(v).__name__}"
        )

    @field_serializer("port_type", when_used='json')
    def serialize_port_type(self, port_type: Any) -> str | dict | None:
        """Serialize port_type to import path for JSON roundtrip.

        Type objects are serialized to their full import path (e.g., "pandas.DataFrame")
        to preserve isinstance capability after deserialization.
        Generic types are serialized to their string representation (e.g., "list[int]").

        Note: Only called during JSON serialization (model_dump_json).

        Raises:
            ValueError: If type is defined in __main__ and cannot be imported.
        """
        if port_type is None:
            return None
        if isinstance(port_type, str):
            return port_type
        if isinstance(port_type, type):
            return _get_type_import_path(port_type)
        if isinstance(port_type, PortTypeConfig):
            return port_type.model_dump()
        if get_origin(port_type) is not None:
            return str(port_type)  # e.g., "list[int]"
        return None

    def to_netrun_sim(self) -> netrun_sim.Port:
        return netrun_sim.Port(self.slots_spec.to_netrun_sim())

# %% [markdown]
# ## Port state predicates
#
# Used in salvo condition terms to check the state of a port.

# %%
#|export
class PortStateEmptyConfig(BaseModel):
    """Port has zero packets."""
    type: Literal["empty"] = "empty"

    def to_netrun_sim(self) -> netrun_sim.PortState:
        return netrun_sim.PortState.empty()


class PortStateFullConfig(BaseModel):
    """Port is at capacity (always false for infinite ports)."""
    type: Literal["full"] = "full"

    def to_netrun_sim(self) -> netrun_sim.PortState:
        return netrun_sim.PortState.full()


class PortStateNonEmptyConfig(BaseModel):
    """Port has at least one packet."""
    type: Literal["non_empty"] = "non_empty"

    def to_netrun_sim(self) -> netrun_sim.PortState:
        return netrun_sim.PortState.non_empty()


class PortStateNonFullConfig(BaseModel):
    """Port is below capacity (always true for infinite ports)."""
    type: Literal["non_full"] = "non_full"

    def to_netrun_sim(self) -> netrun_sim.PortState:
        return netrun_sim.PortState.non_full()


class PortStateEqualsConfig(BaseModel):
    """Port has exactly `value` packets."""
    type: Literal["equals"] = "equals"
    value: int

    def to_netrun_sim(self) -> netrun_sim.PortStateNumeric:
        return netrun_sim.PortState.equals(self.value)


class PortStateLessThanConfig(BaseModel):
    """Port has fewer than `value` packets."""
    type: Literal["less_than"] = "less_than"
    value: int

    def to_netrun_sim(self) -> netrun_sim.PortStateNumeric:
        return netrun_sim.PortState.less_than(self.value)


class PortStateGreaterThanConfig(BaseModel):
    """Port has more than `value` packets."""
    type: Literal["greater_than"] = "greater_than"
    value: int

    def to_netrun_sim(self) -> netrun_sim.PortStateNumeric:
        return netrun_sim.PortState.greater_than(self.value)


class PortStateEqualsOrLessThanConfig(BaseModel):
    """Port has at most `value` packets."""
    type: Literal["equals_or_less_than"] = "equals_or_less_than"
    value: int

    def to_netrun_sim(self) -> netrun_sim.PortStateNumeric:
        return netrun_sim.PortState.equals_or_less_than(self.value)


class PortStateEqualsOrGreaterThanConfig(BaseModel):
    """Port has at least `value` packets."""
    type: Literal["equals_or_greater_than"] = "equals_or_greater_than"
    value: int

    def to_netrun_sim(self) -> netrun_sim.PortStateNumeric:
        return netrun_sim.PortState.equals_or_greater_than(self.value)


PortStateConfig = Annotated[
    PortStateEmptyConfig | PortStateFullConfig | PortStateNonEmptyConfig | PortStateNonFullConfig | PortStateEqualsConfig | PortStateLessThanConfig | PortStateGreaterThanConfig | PortStateEqualsOrLessThanConfig | PortStateEqualsOrGreaterThanConfig,
    Field(discriminator="type")
]

# %% [markdown]
# # Salvo Configuration

# %% [markdown]
# ## Packet count specification
#
# Specifies how many packets to take from a port in a salvo.

# %%
#|export
class PacketCountAllConfig(BaseModel):
    """Take all packets from the port."""
    type: Literal["all"] = "all"

    def to_netrun_sim(self) -> netrun_sim.PacketCount:
        return netrun_sim.PacketCount.all()


class PacketCountNConfig(BaseModel):
    """Take at most `count` packets (takes fewer if port has fewer)."""
    type: Literal["count"] = "count"
    count: int

    def to_netrun_sim(self) -> netrun_sim.PacketCountN:
        return netrun_sim.PacketCount.count(self.count)


PacketCountConfig = Annotated[
    PacketCountAllConfig | PacketCountNConfig,
    Field(discriminator="type")
]

# %% [markdown]
# ## Max salvos specification
#
# Specifies the maximum number of times a salvo condition can trigger.

# %%
#|export
class MaxSalvosInfiniteConfig(BaseModel):
    """No limit on how many times the condition can trigger."""
    type: Literal["infinite"] = "infinite"

    def to_netrun_sim(self) -> netrun_sim.MaxSalvos:
        return netrun_sim.MaxSalvos.infinite()


class MaxSalvosFiniteConfig(BaseModel):
    """Can trigger at most `max` times."""
    type: Literal["finite"] = "finite"
    max: int

    def to_netrun_sim(self) -> netrun_sim.MaxSalvosFinite:
        return netrun_sim.MaxSalvos.finite(self.max)


MaxSalvosConfig = Annotated[
    MaxSalvosInfiniteConfig | MaxSalvosFiniteConfig,
    Field(discriminator="type")
]

# %% [markdown]
# ## Salvo condition term
#
# Boolean expressions over port states, used to define when salvos can trigger.

# %%
#|export
class SalvoConditionTermTrueConfig(BaseModel):
    """Always true. Useful for source nodes with no input ports."""
    type: Literal["true"] = "true"

    def to_netrun_sim(self) -> netrun_sim.SalvoConditionTerm:
        return netrun_sim.SalvoConditionTerm.true_()


class SalvoConditionTermFalseConfig(BaseModel):
    """Always false. Useful as a placeholder or with Not."""
    type: Literal["false"] = "false"

    def to_netrun_sim(self) -> netrun_sim.SalvoConditionTerm:
        return netrun_sim.SalvoConditionTerm.false_()


class SalvoConditionTermPortConfig(BaseModel):
    """Check if a specific port matches a state predicate."""
    type: Literal["port"] = "port"
    port_name: str
    state: PortStateConfig

    def to_netrun_sim(self) -> netrun_sim.SalvoConditionTerm:
        return netrun_sim.SalvoConditionTerm.port(self.port_name, self.state.to_netrun_sim())


class SalvoConditionTermAndConfig(BaseModel):
    """All sub-terms must be true."""
    type: Literal["and"] = "and"
    terms: list["SalvoConditionTermConfig"]

    def to_netrun_sim(self) -> netrun_sim.SalvoConditionTerm:
        return netrun_sim.SalvoConditionTerm.and_([t.to_netrun_sim() for t in self.terms])


class SalvoConditionTermOrConfig(BaseModel):
    """At least one sub-term must be true."""
    type: Literal["or"] = "or"
    terms: list["SalvoConditionTermConfig"]

    def to_netrun_sim(self) -> netrun_sim.SalvoConditionTerm:
        return netrun_sim.SalvoConditionTerm.or_([t.to_netrun_sim() for t in self.terms])


class SalvoConditionTermNotConfig(BaseModel):
    """The sub-term must be false."""
    type: Literal["not"] = "not"
    term: "SalvoConditionTermConfig"

    def to_netrun_sim(self) -> netrun_sim.SalvoConditionTerm:
        return netrun_sim.SalvoConditionTerm.not_(self.term.to_netrun_sim())


SalvoConditionTermConfig = Annotated[
    SalvoConditionTermTrueConfig | SalvoConditionTermFalseConfig | SalvoConditionTermPortConfig | SalvoConditionTermAndConfig | SalvoConditionTermOrConfig | SalvoConditionTermNotConfig,
    Field(discriminator="type")
]

# Rebuild models to resolve forward references
SalvoConditionTermAndConfig.model_rebuild()
SalvoConditionTermOrConfig.model_rebuild()
SalvoConditionTermNotConfig.model_rebuild()

# %% [markdown]
# ## Salvo condition
#
# Defines when packets can trigger an epoch or be sent.

# %%
#|export
class SalvoConditionConfig(BaseModel):
    """A condition that defines when packets can trigger an epoch or be sent.

    Input salvo conditions must have max_salvos set to finite(1).
    """
    max_salvos: MaxSalvosConfig
    ports: dict[str, PacketCountConfig]
    term: SalvoConditionTermConfig

    def to_netrun_sim(self) -> netrun_sim.SalvoCondition:
        ports_dict = {name: pc.to_netrun_sim() for name, pc in self.ports.items()}
        return netrun_sim.SalvoCondition(
            max_salvos=self.max_salvos.to_netrun_sim(),
            ports=ports_dict,
            term=self.term.to_netrun_sim(),
        )

# %% [markdown]
# ## Default salvo condition generation
#
# Generate default salvo conditions when None is specified.

# %%
#|export
def _generate_default_in_salvo_conditions(
    in_ports: dict[str, PortConfig]
) -> dict[str, SalvoConditionConfig]:
    """Generate default input salvo condition.

    Default: Fires when all input ports have at least one packet.
    Takes all packets from all ports.

    Args:
        in_ports: The input port configurations.

    Returns:
        Dict with a single "default" salvo condition.
    """
    if not in_ports:
        # No input ports - use always-true condition
        return {
            "default": SalvoConditionConfig(
                max_salvos=MaxSalvosFiniteConfig(max=1),
                ports={},
                term=SalvoConditionTermTrueConfig(),
            )
        }

    # Build AND condition: all ports must be non-empty
    port_terms = [
        SalvoConditionTermPortConfig(port_name=name, state=PortStateNonEmptyConfig())
        for name in in_ports.keys()
    ]

    if len(port_terms) == 1:
        term = port_terms[0]
    else:
        term = SalvoConditionTermAndConfig(terms=port_terms)

    # Include all packets from all ports
    ports = {name: PacketCountAllConfig() for name in in_ports.keys()}

    return {
        "default": SalvoConditionConfig(
            max_salvos=MaxSalvosFiniteConfig(max=1),
            ports=ports,
            term=term,
        )
    }


def _generate_default_out_salvo_conditions(
    out_ports: dict[str, PortConfig]
) -> dict[str, SalvoConditionConfig]:
    """Generate default output salvo condition.

    Default: Fires once per epoch, sends all packets from all output ports.

    Args:
        out_ports: The output port configurations.

    Returns:
        Dict with a single "default" salvo condition, or empty dict if no output ports.
    """
    if not out_ports:
        return {}

    # Include all packets from all output ports
    ports = {name: PacketCountAllConfig() for name in out_ports.keys()}

    return {
        "default": SalvoConditionConfig(
            max_salvos=MaxSalvosFiniteConfig(max=1),
            ports=ports,
            term=SalvoConditionTermTrueConfig(),
        )
    }

# %%
#|export
from pathlib import Path
