# ---
# jupyter:
#   kernelspec:
#     display_name: .venv
#     language: python
#     name: python3
# ---

# %%
#|default_exp net._net._context

# %%
#|hide
from nblite import nbl_export; nbl_export();

# %% [markdown]
# # Net Context and Protocol Keys
#
# This module contains the protocol keys, context objects, and deferred action
# handling for Net execution.

# %%
#|export
import asyncio
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, NoReturn, get_origin
from collections.abc import Callable
import importlib

from beartype.door import is_bearable

from netrun.net.config import NodeExecutionConfig, NodeVariable, PortConfig, PortTypeConfig
from netrun._iutils import get_timestamp_utc
from netrun.storage import LazyPacketValueSpec

# %% [markdown]
# ## Net Protocol Keys
#
# Communication keys for Net <-> Worker messages.

# %%
#|export
class NetProtocolKeys(Enum):
    """Protocol keys for Net <-> Worker communication."""

    # Upstream (Worker -> Net) - sent via channel when send_channel=True
    UP_CREATE_PACKET = "net:create-packet"
    """Create a new packet. Args: (epoch_id, value_or_lazy)"""

    UP_CREATE_PACKET_RESPONSE = "net:create-packet-response"
    """Response with packet ID. Args: (packet_id,)"""

    UP_CONSUME_PACKET = "net:consume-packet"
    """Consume a packet. Args: (epoch_id, packet_id)"""

    UP_CONSUME_PACKET_RESPONSE = "net:consume-packet-response"
    """Response with packet value. Args: (value,)"""

    UP_LOAD_OUTPUT_PORT = "net:load-output-port"
    """Load packet into output port. Args: (epoch_id, port_name, packet_id)"""

    UP_LOAD_OUTPUT_PORT_RESPONSE = "net:load-output-port-response"
    """Acknowledgement. Args: ()"""

    UP_SEND_OUTPUT_SALVO = "net:send-salvo"
    """Send output salvo. Args: (epoch_id, salvo_condition_name)"""

    UP_SEND_OUTPUT_SALVO_RESPONSE = "net:send-salvo-response"
    """Acknowledgement. Args: ()"""

    UP_CANCEL_EPOCH = "net:cancel-epoch"
    """Cancel the current epoch. Args: (epoch_id,)"""

    UP_PRINT_BUFFER = "net:print-buffer"
    """Send captured print output. Args: (epoch_id, buffer: list[str])"""

# %% [markdown]
# ## NodeExecutionContext
#
# The context object passed to `exec_node_func(ctx, packets)`.

# %%
#|export
class EpochCancelled(Exception):
    """Raised when an epoch is cancelled via ctx.cancel_epoch()."""
    pass


class PacketTypeMismatch(Exception):
    """Raised when a packet value doesn't match the expected port type."""

    def __init__(
        self,
        port_name: str,
        expected: str,
        actual: str,
        packet_id: str,
        node_name: str,
        hint: str = "",
    ):
        self.port_name = port_name
        self.expected = expected
        self.actual = actual
        self.packet_id = packet_id
        self.node_name = node_name
        self.hint = hint
        msg = (
            f"Port '{node_name}.{port_name}' expects {expected}, got {actual} "
            f"(packet {packet_id})"
        )
        if hint:
            msg += hint
        super().__init__(msg)


class EpochError(Exception):
    """Wrapper for errors during epoch execution, with full context.

    The original exception is chained via __cause__.
    """
    def __init__(self, message: str, *, node_name: str, epoch_id: str,
                 pool_id: str | None = None, worker_id: int | None = None,
                 retry_count: int = 0):
        self.node_name = node_name
        self.epoch_id = epoch_id
        self.pool_id = pool_id
        self.worker_id = worker_id
        self.retry_count = retry_count
        super().__init__(message)

    def __str__(self) -> str:
        parts = [f"Epoch failed on node '{self.node_name}'"]
        if self.pool_id is not None:
            parts.append(f"pool='{self.pool_id}'")
        if self.worker_id is not None:
            parts.append(f"worker={self.worker_id}")
        if self.retry_count > 0:
            parts.append(f"retries={self.retry_count}")
        context = ", ".join(parts[1:])
        base = parts[0]
        if context:
            base += f" ({context})"
        if self.__cause__:
            base += f": {self.__cause__}"
        return base


@dataclass
class NodeExecutionContext:
    """Context object passed to node execution functions.

    This is the primary interface for nodes to interact with the Net during execution.
    All operations are deferred and committed when the function completes.

    Packet operations (create, consume, load_output_port, send_output_salvo) are
    queued locally and executed atomically when the epoch completes successfully.
    """

    # Identity
    epoch_id: str
    node_name: str

    # Retry info
    retry_count: int = 0
    retry_timestamps: list[datetime] = field(default_factory=list)
    retry_exceptions: list[Exception] = field(default_factory=list)

    # Internal (not for user access)
    _config: NodeExecutionConfig = field(repr=False, default=None)
    _print_buffer: list[tuple[datetime, str]] = field(default_factory=list, repr=False)
    _created_packets: list[str] = field(default_factory=list, repr=False)
    _consumed_packets: list[str] = field(default_factory=list, repr=False)

    # Input packet values passed from Net (packet_id -> value)
    _input_packet_values: dict[str, Any] = field(default_factory=dict, repr=False)

    # Output port configurations for type validation
    _out_ports: dict[str, PortConfig] = field(default_factory=dict, repr=False)

    # Deferred actions queue
    _deferred_actions: "DeferredActionQueue" = field(default_factory=lambda: DeferredActionQueue(), repr=False)

    # Track if epoch was cancelled
    _cancelled: bool = field(default=False, repr=False)

    # Node variables (merged net-level + node-level)
    _node_vars: dict[str, "NodeVariable"] | None = field(default=None, repr=False)

    # Type checking flag
    _type_checking_enabled: bool = field(default=True, repr=False)

    def create_packet(self, value: Any) -> str:
        """Create a new packet with the given value.

        Args:
            value: The value to store in the packet.

        Returns:
            A deferred packet ID (format: "deferred_{uuid}").
            This ID is valid within this epoch and will be mapped
            to a real packet ID when the epoch commits.
        """
        deferred_id = self._deferred_actions.add_create_packet(value)
        self._created_packets.append(deferred_id)
        return deferred_id

    def create_packet_from_value_func(
        self,
        func_import_path: str,
        args: tuple = (),
        kwargs: dict | None = None,
    ) -> str:
        """Create a packet with a lazy value that is evaluated on consumption.

        Args:
            func_import_path: Import path to the function that produces the value.
            args: Positional arguments to pass to the function.
            kwargs: Keyword arguments to pass to the function.

        Returns:
            A deferred packet ID.
        """
        if kwargs is None:
            kwargs = {}

        lazy_spec = LazyPacketValueSpec(
            func_import_path=func_import_path,
            args=args,
            kwargs=kwargs,
        )

        deferred_id = self._deferred_actions.add_create_packet(lazy_spec)
        self._created_packets.append(deferred_id)
        return deferred_id

    def consume_packet(self, packet_id: str) -> Any:
        """Consume a packet and return its value.

        The packet is removed from the network when the epoch commits.

        Args:
            packet_id: The ID of the packet to consume.

        Returns:
            The packet's value.

        Raises:
            KeyError: If the packet_id is not in the input packets for this epoch.
        """
        if packet_id not in self._input_packet_values:
            raise KeyError(f"Packet {packet_id} not found in input packets for epoch {self.epoch_id}")

        value = self._input_packet_values[packet_id]
        self._deferred_actions.add_consume_packet(packet_id)
        self._consumed_packets.append(packet_id)
        return value

    def load_output_port(self, port_name: str, packet_id: str) -> None:
        """Load a packet into an output port.

        Validates packet type if the port has a port_type configured.

        Args:
            port_name: The name of the output port.
            packet_id: The ID of the packet to load (can be a deferred ID).

        Raises:
            PacketTypeMismatch: If packet value doesn't match port's expected type.
        """
        # Validate type if port has type configured
        port_config = self._out_ports.get(port_name)
        if port_config and port_config.port_type is not None:
            value = self._get_packet_value(packet_id)
            # Skip validation for lazy values (not yet materialized)
            if not isinstance(value, LazyPacketValueSpec):
                self._validate_port_type(port_name, port_config.port_type, value, packet_id)

        self._deferred_actions.add_load_output_port(port_name, packet_id)

    def _get_packet_value(self, packet_id: str) -> Any:
        """Get the value of a packet by ID.

        Handles both input packets and deferred (created) packets.

        Args:
            packet_id: The packet ID (real or deferred).

        Returns:
            The packet's value.

        Raises:
            KeyError: If packet_id is unknown.
        """
        # Check if it's an input packet
        if packet_id in self._input_packet_values:
            return self._input_packet_values[packet_id]

        # Check if it's a deferred packet we created
        if packet_id in self._deferred_actions.packet_values:
            return self._deferred_actions.packet_values[packet_id]

        raise KeyError(f"Unknown packet ID: {packet_id}")

    def _validate_port_type(
        self,
        port_name: str,
        port_type: "str | type | PortTypeConfig",
        value: Any,
        packet_id: str,
    ) -> None:
        """Validate a value against a port type specification.

        Args:
            port_name: Name of the port being validated.
            port_type: The type specification.
            value: The value to validate.
            packet_id: The packet ID (for error messages).

        Raises:
            PacketTypeMismatch: If validation fails.
        """
        # Skip validation if type checking is disabled
        if not self._type_checking_enabled:
            return

        expected, matches, match_mode = self._check_type(port_type, value)

        if not matches:
            actual = type(value).__name__
            # Add hint about string matching if that's what was used
            hint = ""
            if match_mode == "string":
                hint = (
                    " (Note: type was specified as a string, so only __name__ matching was used. "
                    "For proper generic type checking like list[int], use actual Python types.)"
                )
            raise PacketTypeMismatch(
                port_name=port_name,
                expected=expected,
                actual=actual,
                packet_id=packet_id,
                node_name=self.node_name,
                hint=hint,
            )

    def _check_type(self, port_type: "str | type | PortTypeConfig", value: Any) -> tuple[str, bool, str]:
        """Check if value matches port type.

        Two modes of type checking:
        1. String types: Use __name__ matching (loose, for serialization)
        2. Type objects: Use beartype for proper type checking (strict, for generics)

        Args:
            port_type: The type specification.
            value: The value to check.

        Returns:
            Tuple of (expected_type_name, matches, match_mode).
            match_mode is one of: "string", "isinstance", "beartype"
        """
        # MODE 1: String-based - use __name__ matching
        if isinstance(port_type, str):
            if "." in port_type:
                # Full import path - try to import and use isinstance
                try:
                    type_obj = self._import_type(port_type)
                    type_name = port_type.rsplit(".", 1)[-1]
                    return (type_name, isinstance(value, type_obj), "isinstance")
                except (ImportError, AttributeError):
                    # Fall back to name match if import fails
                    type_name = port_type.rsplit(".", 1)[-1]
                    return (type_name, type(value).__name__ == type_name, "string")
            else:
                # Simple name - do name match
                return (port_type, type(value).__name__ == port_type, "string")

        # MODE 2: Type object (including generics like list[int]) - use beartype
        if isinstance(port_type, type) or get_origin(port_type) is not None:
            type_name = getattr(port_type, '__name__', repr(port_type))
            return (type_name, is_bearable(value, port_type), "beartype")

        # PortTypeConfig - delegate based on content
        if isinstance(port_type, PortTypeConfig):
            if port_type.isinstance_check and "." in port_type.name:
                try:
                    type_obj = self._import_type(port_type.name)
                    type_name = port_type.name.rsplit(".", 1)[-1]
                    return (type_name, isinstance(value, type_obj), "isinstance")
                except (ImportError, AttributeError):
                    pass
            # Fall back to name match
            type_name = port_type.name.rsplit(".", 1)[-1] if "." in port_type.name else port_type.name
            return (type_name, type(value).__name__ == type_name, "string")

        # Unknown type spec - no validation
        return ("any", True, "none")

    def _import_type(self, import_path: str) -> type:
        """Import a type from a dotted import path.

        Args:
            import_path: Dotted import path (e.g., "pandas.DataFrame").

        Returns:
            The imported type.

        Raises:
            ImportError: If the module cannot be imported.
            AttributeError: If the type doesn't exist in the module.
        """
        module_path, type_name = import_path.rsplit(".", 1)
        module = importlib.import_module(module_path)
        return getattr(module, type_name)

    def send_output_salvo(self, salvo_condition_name: str) -> None:
        """Send packets from output ports onto edges.

        Args:
            salvo_condition_name: The name of the output salvo condition to trigger.
        """
        self._deferred_actions.add_send_output_salvo(salvo_condition_name)

    def cancel_epoch(self) -> NoReturn:
        """Cancel the current epoch.

        This immediately terminates the epoch execution.
        All deferred actions are discarded.
        Raises EpochCancelled which should not be caught by user code.
        """
        self._cancelled = True
        self._deferred_actions.discard()
        raise EpochCancelled(f"Epoch {self.epoch_id} cancelled")

    def print(self, *args, sep: str = " ", end: str = "\n", flush: bool = False) -> None:
        """Capture print output.

        This method behaves like the built-in print() but captures output
        with timestamps. Each print is timestamped at the time it is called.
        All captured output is returned to the Net when the epoch completes.

        Args:
            *args: Values to print (same as builtin print).
            sep: Separator between values (default: " ").
            end: String to append at end (default: "\\n").
            flush: Ignored (kept for API compatibility with builtin print).
        """
        # Capture timestamp immediately when print is called
        timestamp = get_timestamp_utc()

        # Format the message (same as builtin print)
        message = sep.join(str(arg) for arg in args) + end

        # Optionally echo to stdout
        if self._config is not None and self._config.print_echo_stdout:
            import builtins
            builtins.print(*args, sep=sep, end=end, flush=True)

        # Add to buffer with timestamp
        self._print_buffer.append((timestamp, message))

    @property
    def vars(self) -> dict[str, Any]:
        """Resolved node variables (net-level merged with node-level overrides).

        Returns a dict mapping variable names to their resolved Python values.
        """
        if self._node_vars is None:
            return {}
        return {name: var.resolve_value() for name, var in self._node_vars.items()}

    def _get_execution_result(self) -> "NodeExecutionResult":
        """Get the execution result including deferred actions and print buffer.

        This is called by the func_preprocessor after the node function completes.
        """
        return NodeExecutionResult(
            cancelled=self._cancelled,
            deferred_actions=self._deferred_actions,
            print_buffer=self._print_buffer.copy(),
            created_packets=self._created_packets.copy(),
            consumed_packets=self._consumed_packets.copy(),
        )

# %% [markdown]
# ## NodeExecutionResult
#
# Result returned from a node function execution, containing deferred actions and print buffer.

# %%
#|export
@dataclass
class NodeExecutionResult:
    """Result of a node function execution.

    This is returned by the func_preprocessor wrapper and contains all the
    deferred actions and captured prints that need to be processed by Net.
    """
    cancelled: bool
    """Whether the epoch was cancelled via ctx.cancel_epoch()."""

    deferred_actions: "DeferredActionQueue"
    """Queue of deferred packet operations to commit."""

    print_buffer: list[tuple[datetime, str]]
    """Captured print output with timestamps."""

    created_packets: list[str]
    """List of deferred packet IDs that were created."""

    consumed_packets: list[str]
    """List of packet IDs that were consumed."""

    func_result: Any = None
    """The return value from the node function (if any)."""

    exception: Exception | None = None
    """Exception raised by the node function (if any)."""

# %% [markdown]
# ## NodeFailureContext
#
# Context passed to `on_node_failure` callbacks.

# %%
#|export
@dataclass
class NodeFailureContext:
    """Context object passed to on_node_failure callbacks."""
    epoch_id: str
    node_name: str
    retry_count: int
    exception: Exception
    retry_timestamps: list[datetime] = field(default_factory=list)
    retry_exceptions: list[Exception] = field(default_factory=list)
    input_salvo: dict[str, list[str]] = field(default_factory=dict)  # port_name -> list[packet_id]
    pool_id: str | None = None
    worker_id: int | None = None

# %% [markdown]
# ## ConsumedOutputPacket
#
# A packet retrieved from an output queue.

# %%
#|export
@dataclass
class ConsumedOutputPacket:
    """A packet retrieved from an output queue.

    Output packets are produced when packets are sent from unconnected output ports
    (ports with no downstream edges). They are routed to output queues based on the
    Net configuration.
    """

    packet_id: str
    """The packet's ULID."""

    value: Any
    """The packet's value."""

    from_node: str
    """The node that produced this packet."""

    from_port: str
    """The output port that produced this packet."""

    queue_name: str
    """The queue this packet was retrieved from."""

    timestamp: datetime
    """When the packet arrived in the queue."""

    epoch_id: str
    """The epoch that produced this packet."""

# %% [markdown]
# ## EpochRecord
#
# Wraps epoch data with lifecycle tracking (timestamps, cancellation, logs).

# %%
#|export
@dataclass
class EpochRecord:
    """Record of an epoch's full lifecycle."""
    id: str
    node_name: str
    in_salvo: Any
    out_salvos: list
    state: Any           # EpochState — updated at each transition
    orphaned_packets: list
    created_at: datetime
    logs: list[tuple[datetime, str]] = field(default_factory=list)
    was_cancelled: bool = False
    started_at: datetime | None = None
    ended_at: datetime | None = None
    destroyed_packets: list[str] = field(default_factory=list)

    @classmethod
    def from_epoch(cls, epoch) -> "EpochRecord":
        """Create an EpochRecord from a netrun_sim.Epoch object."""
        created_at = datetime.fromtimestamp(epoch.start_time() / 1000, tz=timezone.utc)
        return cls(
            id=epoch.id, node_name=epoch.node_name,
            in_salvo=epoch.in_salvo, out_salvos=list(epoch.out_salvos),
            state=epoch.state, orphaned_packets=list(epoch.orphaned_packets),
            created_at=created_at,
        )

    def start_time(self) -> int:
        """Creation timestamp in ms (compat with netrun_sim.Epoch)."""
        return int(self.created_at.timestamp() * 1000)

    def get_logs(self) -> list[tuple[datetime, str]]:
        """Return a copy of the print logs."""
        return list(self.logs)

    def print_logs(self, include_timestamps: bool = True) -> None:
        """Print the logs to stdout.

        Args:
            include_timestamps: If True (default), prefix each line with its timestamp.
        """
        for timestamp, message in self.logs:
            if include_timestamps:
                print(f"[{timestamp.strftime('%H:%M:%S.%f')[:-3]}] {message.strip()}")
            else:
                print(message.strip())

# %% [markdown]
# ## Deferred Action Queue
#
# For `defer_net_actions=True`, packet operations are queued and only committed on success.

# %%
#|export
@dataclass
class DeferredActionQueue:
    """Queue of net actions to be committed on success or discarded on failure."""

    actions: list[tuple[str, Any]] = field(default_factory=list)  # (action_type, args)
    packet_values: dict[str, Any] = field(default_factory=dict)   # deferred_id -> value
    deferred_to_real_ids: dict[str, str] = field(default_factory=dict)

    def add_create_packet(self, value: Any) -> str:
        """Queue a packet creation. Returns deferred ID."""
        deferred_id = f"deferred_{uuid.uuid4()}"
        self.actions.append(("create_packet", (deferred_id, value)))
        self.packet_values[deferred_id] = value
        return deferred_id

    def add_consume_packet(self, packet_id: str) -> None:
        """Queue a packet consumption."""
        self.actions.append(("consume_packet", (packet_id,)))

    def add_load_output_port(self, port_name: str, packet_id: str) -> None:
        """Queue loading a packet into an output port."""
        self.actions.append(("load_output_port", (port_name, packet_id)))

    def add_send_output_salvo(self, salvo_condition_name: str) -> None:
        """Queue sending an output salvo."""
        self.actions.append(("send_output_salvo", (salvo_condition_name,)))

    def discard(self) -> None:
        """Discard all queued actions (on failure/retry)."""
        self.actions.clear()
        self.packet_values.clear()
        self.deferred_to_real_ids.clear()

# %% [markdown]
# ## func_preprocessor and func_done_callback
#
# These functions transform node functions to accept context-creation arguments
# and return NodeExecutionResult with all deferred actions.

# %%
#|export
@dataclass
class NetFuncPreprocessorNodeConfig:
    """Picklable configuration for a node's preprocessor behavior.

    This captures only the serializable parts needed for preprocessing,
    avoiding closures that can't be pickled for multiprocess pools.
    """
    factory: str | None
    """Factory module path for lazy resolution (None if not factory-based)."""

    factory_args: dict[str, Any]
    """Arguments to pass to factory's get_node_funcs()."""

    out_ports: dict[str, dict[str, Any]]
    """Output port configs (serialized as dicts for pickling)."""

    # Copy of NodeExecutionConfig fields needed for context creation
    capture_prints: bool = True
    print_flush_interval: float = 0.1
    print_buffer_max_size: int | None = None
    print_echo_stdout: bool = False
    retries: int = 0
    retry_wait: float = 0.0
    timeout: float | None = None

    node_vars: dict[str, dict[str, str]] | None = None
    """Merged node variables (serialized as dicts for pickling)."""

    type_checking_enabled: bool = True
    """Whether type checking is enabled for this node."""

    @classmethod
    def from_node_config(
        cls,
        exec_config: NodeExecutionConfig,
        out_ports: dict[str, PortConfig],
        factory: str | None,
        factory_args: dict[str, Any],
        node_vars: dict[str, dict[str, str]] | None = None,
        type_checking_enabled: bool = True,
    ) -> "NetFuncPreprocessorNodeConfig":
        """Create from execution config, port configs, and factory info."""
        return cls(
            factory=factory,
            factory_args=factory_args,
            out_ports={name: port.model_dump() for name, port in out_ports.items()},
            capture_prints=exec_config.capture_prints,
            print_flush_interval=exec_config.print_flush_interval,
            print_buffer_max_size=exec_config.print_buffer_max_size,
            print_echo_stdout=exec_config.print_echo_stdout,
            retries=exec_config.retries,
            retry_wait=exec_config.retry_wait,
            timeout=exec_config.timeout,
            node_vars=node_vars,
            type_checking_enabled=type_checking_enabled,
        )


class NetFuncPreprocessor:
    """Picklable func_preprocessor for Net execution.

    Unlike the closure-based version, this class can be pickled for multiprocess pools.
    It resolves factory-based node functions lazily on each worker.
    """

    def __init__(
        self,
        node_configs: dict[str, NetFuncPreprocessorNodeConfig],
    ):
        """Initialize the preprocessor.

        Args:
            node_configs: Mapping of node names to their preprocessor configs.
        """
        self._node_configs = node_configs
        # Worker-local cache for resolved factory functions
        self._resolved_funcs: dict[str, Callable] = {}

    def _resolve_factory(self, node_name: str) -> Callable | None:
        """Resolve factory function on worker (lazy).

        Called on first use for each node on each worker.
        """
        if node_name in self._resolved_funcs:
            return self._resolved_funcs[node_name]

        config = self._node_configs.get(node_name)
        if config is None or config.factory is None:
            return None

        # Import factory module and call get_node_funcs
        module = importlib.import_module(config.factory)
        get_node_funcs = getattr(module, "get_node_funcs")
        exec_func, _, _, _ = get_node_funcs(**config.factory_args)

        self._resolved_funcs[node_name] = exec_func
        return exec_func

    def __call__(self, exec_node_func: Callable) -> Callable:
        """Transform exec_node_func -> wrapped function.

        If exec_node_func is a _FactoryPlaceholder, resolves the actual function
        from the factory on this worker.
        """
        preprocessor_self = self  # Capture for inner function

        def wrapped(
            epoch_id: str,
            node_name: str,
            packets: dict[str, list[str]],
            packet_values: dict[str, Any],
            retry_count: int = 0,
            retry_timestamps: list[datetime] | None = None,
            retry_exceptions: list[Exception] | None = None,
        ) -> NodeExecutionResult:
            config = preprocessor_self._node_configs.get(node_name)
            out_ports = {}
            if config:
                out_ports = {
                    name: PortConfig.model_validate(port_dict)
                    for name, port_dict in config.out_ports.items()
                }

            # Create execution config for context (with essential fields)
            exec_config = None
            if config:
                exec_config = NodeExecutionConfig(
                    capture_prints=config.capture_prints,
                    print_flush_interval=config.print_flush_interval,
                    print_buffer_max_size=config.print_buffer_max_size,
                    print_echo_stdout=config.print_echo_stdout,
                    retries=config.retries,
                    retry_wait=config.retry_wait,
                    timeout=config.timeout,
                )

            # Reconstruct NodeVariable objects from serialized dicts
            _node_vars = None
            if config and config.node_vars:
                _node_vars = {
                    n: NodeVariable.model_validate(v)
                    for n, v in config.node_vars.items()
                }

            # Get type checking enabled flag (default True if no config)
            type_checking_enabled = config.type_checking_enabled if config else True

            ctx = NodeExecutionContext(
                epoch_id=epoch_id,
                node_name=node_name,
                retry_count=retry_count,
                retry_timestamps=retry_timestamps or [],
                retry_exceptions=retry_exceptions or [],
                _config=exec_config,
                _input_packet_values=packet_values,
                _out_ports=out_ports,
                _node_vars=_node_vars,
                _type_checking_enabled=type_checking_enabled,
            )

            # Determine the actual function to call
            actual_func = exec_node_func
            if isinstance(exec_node_func, _FactoryPlaceholder):
                # Resolve factory function on this worker
                resolved = preprocessor_self._resolve_factory(node_name)
                if resolved is None:
                    raise RuntimeError(
                        f"Failed to resolve factory function for node '{node_name}'"
                    )
                actual_func = resolved

            func_result = None
            exception = None

            try:
                func_result = actual_func(ctx, packets)
            except EpochCancelled:
                # Expected when ctx.cancel_epoch() is called
                pass
            except Exception as e:
                exception = e

            # Get the execution result with all deferred actions
            result = ctx._get_execution_result()
            result.func_result = func_result
            result.exception = exception

            return result

        return wrapped


class _FactoryPlaceholder:
    """Placeholder for factory-based node functions.

    Registered with workers instead of actual functions when the node uses
    a factory. The NetFuncPreprocessor resolves the actual function lazily.
    """

    def __init__(self, node_name: str):
        self.node_name = node_name

    def __repr__(self) -> str:
        return f"_FactoryPlaceholder({self.node_name!r})"


def create_net_func_preprocessor(
    node_execution_configs: dict[str, NodeExecutionConfig],
    node_out_ports: dict[str, dict[str, PortConfig]] | None = None,
    node_factories: dict[str, tuple[str, dict[str, Any]]] | None = None,
    net_node_vars: dict[str, NodeVariable] | None = None,
    net_type_checking_enabled: bool = True,
) -> NetFuncPreprocessor:
    """Create a func_preprocessor for Net execution.

    The preprocessor transforms `exec_node_func(ctx, packets)` into a wrapped function
    that:
    1. Creates a NodeExecutionContext with input packet values
    2. Runs the node function (resolving factory functions lazily)
    3. Returns NodeExecutionResult with deferred actions and print buffer

    Args:
        node_execution_configs: Mapping of node names to their execution configs.
        node_out_ports: Mapping of node names to their output port configs (for type validation).
        node_factories: Mapping of node names to (factory_path, factory_args) tuples for
            factory-based nodes. Factory functions are resolved lazily on workers.
        net_node_vars: Net-level default node variables.
        net_type_checking_enabled: Net-level default for type checking (can be overridden per-node).

    Returns:
        A picklable NetFuncPreprocessor instance.
    """
    node_out_ports = node_out_ports or {}
    node_factories = node_factories or {}

    # Convert to picklable config format
    node_configs = {}
    for node_name, config in node_execution_configs.items():
        out_ports = node_out_ports.get(node_name, {})
        factory_info = node_factories.get(node_name)
        factory = factory_info[0] if factory_info else None
        factory_args = factory_info[1] if factory_info else {}

        # Merge net-level + node-level vars (node overrides net)
        merged_vars = None
        if net_node_vars or config.node_vars:
            merged = {}
            if net_node_vars:
                merged.update({k: v.model_dump() for k, v in net_node_vars.items()})
            if config.node_vars:
                merged.update({k: v.model_dump() for k, v in config.node_vars.items()})
            if merged:
                merged_vars = merged

        # Determine type checking: node-level overrides net-level
        if config.type_checking_enabled is not None:
            type_checking_enabled = config.type_checking_enabled
        else:
            type_checking_enabled = net_type_checking_enabled

        node_configs[node_name] = NetFuncPreprocessorNodeConfig.from_node_config(
            config, out_ports, factory, factory_args,
            node_vars=merged_vars,
            type_checking_enabled=type_checking_enabled,
        )

    return NetFuncPreprocessor(node_configs)


def _net_func_done_callback_noop(*args, **kwargs):
    """No-op done callback for Net execution.

    All work is done by the preprocessor wrapper, so this is a no-op.
    Defined at module level to be picklable for multiprocess pools.
    """
    pass


def create_net_func_done_callback() -> Callable:
    """Create func_done_callback for Net execution.

    This callback is no longer needed since all state is returned in NodeExecutionResult,
    but we provide a no-op for compatibility.

    Returns:
        A no-op callback function (module-level function for pickling).
    """
    return _net_func_done_callback_noop
