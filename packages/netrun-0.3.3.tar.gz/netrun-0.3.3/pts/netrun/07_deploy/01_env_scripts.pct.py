# ---
# jupyter:
#   kernelspec:
#     display_name: .venv
#     language: python
#     name: python3
# ---

# %% [markdown]
# # Environment Setup Script Generators

# %%
#|default_exp deploy._env_scripts

# %%
#|hide
from nblite import nbl_export; nbl_export();

# %%
#|export
from netrun.deploy._config import (
    UvEnvSetup,
    PixiEnvSetup,
    CondaEnvSetup,
    InlineScriptEnvSetup,
    ScriptFileEnvSetup,
    EnvSetupConfig,
)

# %% [markdown]
# ## Script Generators
#
# Each generator returns a shell command string for setting up the environment on the remote.

# %%
#|export
def get_uv_setup_script(config: UvEnvSetup, repo_dir: str) -> str:
    """Generate a shell script to set up an environment using uv.

    Installs uv if missing, optionally installs a Python version, then runs `uv sync`.
    """
    lines = [
        f"cd {repo_dir}",
        'command -v uv >/dev/null 2>&1 || curl -LsSf https://astral.sh/uv/install.sh | sh',
        'export PATH="$HOME/.local/bin:$PATH"',
    ]
    if config.python_version:
        lines.append(f"uv python install {config.python_version}")
    sync_cmd = "uv sync"
    if config.extra_args:
        sync_cmd += f" {config.extra_args}"
    lines.append(sync_cmd)
    return " && ".join(lines)


def get_pixi_setup_script(config: PixiEnvSetup, repo_dir: str) -> str:
    """Generate a shell script to set up an environment using pixi."""
    lines = [
        f"cd {repo_dir}",
        'command -v pixi >/dev/null 2>&1 || curl -fsSL https://pixi.sh/install.sh | sh',
        'export PATH="$HOME/.pixi/bin:$PATH"',
    ]
    install_cmd = "pixi install"
    if config.environment:
        install_cmd += f" -e {config.environment}"
    lines.append(install_cmd)
    return " && ".join(lines)


def get_conda_setup_script(config: CondaEnvSetup, repo_dir: str) -> str:
    """Generate a shell script to set up an environment using conda."""
    lines = [
        f"cd {repo_dir}",
        f"conda env update -n {config.env_name} -f {config.env_file} --prune",
    ]
    return " && ".join(lines)


def get_env_setup_script(config: "EnvSetupConfig", repo_dir: str) -> str:
    """Dispatch to the correct env setup script generator based on config type."""
    if isinstance(config, UvEnvSetup):
        return get_uv_setup_script(config, repo_dir)
    elif isinstance(config, PixiEnvSetup):
        return get_pixi_setup_script(config, repo_dir)
    elif isinstance(config, CondaEnvSetup):
        return get_conda_setup_script(config, repo_dir)
    elif isinstance(config, InlineScriptEnvSetup):
        return config.script
    elif isinstance(config, ScriptFileEnvSetup):
        return f"cd {repo_dir} && bash .netrun_env_setup.sh"
    else:
        raise ValueError(f"Unknown env setup type: {type(config)}")
