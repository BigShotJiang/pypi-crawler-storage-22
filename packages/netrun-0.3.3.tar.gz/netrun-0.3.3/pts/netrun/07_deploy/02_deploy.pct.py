# ---
# jupyter:
#   kernelspec:
#     display_name: .venv
#     language: python
#     name: python3
# ---

# %% [markdown]
# # Deploy Function
#
# Deploys a pool server to a remote machine via pyinfra (SSH-only).

# %%
#|default_exp deploy._deploy

# %%
#|hide
from nblite import nbl_export; nbl_export();

# %%
#|export
import io

from netrun.deploy._config import (
    DeployConfig,
    DeployResult,
    ImportPathNetSource,
    ConfigFileNetSource,
    FileVarNetSource,
    ScriptFileEnvSetup,
    UvEnvSetup,
    PixiEnvSetup,
    CondaEnvSetup,
)
from netrun.deploy._env_scripts import get_env_setup_script
from netrun.net.config._net_config import NetConfig, RemotePoolConfig

# %% [markdown]
# ## Helper: Build Serve Script
#
# Generates a Python script that will be uploaded to the remote and executed
# to start the pool server.

# %%
#|export
def _build_serve_script(config: DeployConfig) -> str:
    """Generate a Python script to run on the remote that starts a pool server.

    The script:
    1. Loads the Net config based on net_source type
    2. Calls Net.serve_pool() with pool_server settings
    3. Awaits wait_until_stopped() then stop()
    """
    ns = config.net_source
    ps = config.pool_server
    log_file_arg = f'"{ps.log_file}"' if ps.log_file else "None"

    lines = [
        "import asyncio",
        "import os, sys",
        "",
        "_script_dir = os.path.dirname(os.path.abspath(__file__))",
        "if _script_dir not in sys.path:",
        "    sys.path.insert(0, _script_dir)",
        'os.environ["PYTHONPATH"] = _script_dir + os.pathsep + os.environ.get("PYTHONPATH", "")',
        "",
        "from netrun.net import Net",
    ]

    if isinstance(ns, ImportPathNetSource):
        parts = ns.path.rsplit(".", 1)
        module_path, attr_name = parts[0], parts[1]
        lines.append(f"from {module_path} import {attr_name} as _net_config")
    elif isinstance(ns, ConfigFileNetSource):
        lines.append("from netrun.net.config import NetConfig")
        lines.append(f'_net_config = NetConfig.from_file("{ns.path}")')
    elif isinstance(ns, FileVarNetSource):
        file_path, var_name = ns.path.split("::")
        lines.append("import importlib.util, sys")
        lines.append(f'_spec = importlib.util.spec_from_file_location("_net_mod", "{file_path}")')
        lines.append("_mod = importlib.util.module_from_spec(_spec)")
        lines.append("sys.modules[_spec.name] = _mod")
        lines.append("_spec.loader.exec_module(_mod)")
        lines.append(f'_net_config = getattr(_mod, "{var_name}")')

    lines.append("")
    lines.append("async def main():")
    lines.append(f'    ctx = Net.serve_pool(_net_config, "{ps.host}", {ps.port}, '
                 f'log_file={log_file_arg}, worker_name="{ps.worker_name}")')
    lines.append("    await ctx.start()")
    lines.append("    await ctx.wait_until_stopped()")
    lines.append("    await ctx.stop()")
    lines.append("")
    lines.append('if __name__ == "__main__":')
    lines.append("    asyncio.run(main())")

    return "\n".join(lines) + "\n"

# %% [markdown]
# ## Helper: Get Environment Prefix

# %%
#|export
def _get_env_prefix(config: DeployConfig) -> str:
    """Return the shell prefix to activate the environment when running Python.

    Returns only the runner command (e.g. 'uv run '), NOT a cd. The caller
    (_build_nohup_command) already handles cd to repo_dir.

    - uv: 'uv run '
    - pixi: 'pixi run '
    - conda: 'conda run -n {env_name} '
    - inline_script/script_file/None: ''
    """
    env = config.env_setup
    if env is None:
        return ""
    if isinstance(env, UvEnvSetup):
        return "uv run "
    if isinstance(env, PixiEnvSetup):
        return "pixi run "
    if isinstance(env, CondaEnvSetup):
        return f"conda run -n {env.env_name} "
    return ""

# %% [markdown]
# ## Helper: Build nohup Command

# %%
#|export
def _build_nohup_command(config: DeployConfig, env_prefix: str) -> str:
    """Build the nohup command to start the pool server in the background.

    Uses a wrapper script to reliably capture the PID. Writing the PID and
    backgrounding in a single shell command is unreliable over SSH because
    paramiko/sshd may close the channel before $! is captured. Instead we
    write a small helper that launches the process and records its PID.
    """
    repo_dir = config.repo.remote_dir
    return (
        f"cd {repo_dir} && "
        f"printf '#!/bin/sh\\nexport PATH=\"$HOME/.local/bin:$PATH\"\\n"
        f"cd {repo_dir}\\n"
        f"nohup {env_prefix}python .netrun_serve_pool.py "
        f"> pool_server_stdout.log 2>&1 &\\necho $! > .netrun_serve_pool.pid\\n' "
        f"> .netrun_start.sh && chmod +x .netrun_start.sh && ./.netrun_start.sh"
    )

# %% [markdown]
# ## Deploy Function

# %%
#|export
def _run_deploy_operations(config: DeployConfig, state, dry_run: bool) -> None:
    """Generate and optionally execute pyinfra operations for the deployment.

    This function must be called within a pyinfra host context (via state.hosts loop).
    Operations are registered via pyinfra's context-based API, then executed with run_ops.
    """
    from pyinfra.api.operations import run_ops
    from pyinfra.operations import git, files, server

    repo = config.repo

    # Pre-deploy commands
    for cmd in config.pre_deploy_commands:
        server.shell(commands=[cmd])

    if repo.local_folder_path is not None:
        # Upload local folder directly (no git)
        files.sync(
            src=repo.local_folder_path,
            dest=repo.remote_dir,
        )
    else:
        # Clone/pull git repo (existing logic)
        git_url = repo.resolve_git_url()

        # SSH keyscan
        if repo.ssh_keyscan and git_url.startswith("git@"):
            git_host = git_url.split("@")[1].split(":")[0]
            server.shell(
                commands=[f"ssh-keyscan -H {git_host} >> ~/.ssh/known_hosts 2>/dev/null || true"],
            )

        branch_kwargs = {}
        if repo.branch:
            branch_kwargs["branch"] = repo.branch
        git.repo(
            src=git_url,
            dest=repo.remote_dir,
            **branch_kwargs,
        )

    # Upload additional files
    for upload in config.file_uploads:
        files.put(
            src=upload.local_path,
            dest=upload.remote_path,
        )

    # Upload env setup script file if needed
    if isinstance(config.env_setup, ScriptFileEnvSetup):
        files.put(
            src=config.env_setup.local_path,
            dest=f"{repo.remote_dir}/.netrun_env_setup.sh",
        )

    # Run env setup
    if config.env_setup is not None:
        env_script = get_env_setup_script(config.env_setup, repo.remote_dir)
        server.shell(commands=[env_script])

    # Post-deploy commands
    for cmd in config.post_deploy_commands:
        server.shell(commands=[cmd])

    # Upload serve script
    serve_script = _build_serve_script(config)
    serve_script_path = f"{repo.remote_dir}/.netrun_serve_pool.py"
    files.put(
        src=io.BytesIO(serve_script.encode()),
        dest=serve_script_path,
    )

    # Start server
    env_prefix = _get_env_prefix(config)
    nohup_cmd = _build_nohup_command(config, env_prefix)
    server.shell(commands=[nohup_cmd])

    if not dry_run:
        run_ops(state)


def deploy(config: DeployConfig, *, dry_run: bool = False) -> DeployResult:
    """Deploy a pool server to a remote machine via pyinfra.

    Uses SSH to clone/pull the repo, set up the environment, and start
    the pool server process.

    Args:
        config: Deployment configuration.
        dry_run: If True, generate operations but do not execute them.

    Returns:
        DeployResult with connection info and status.

    Raises:
        ImportError: If pyinfra is not installed (install via `pip install netrun[deploy]`).
    """
    try:
        from pyinfra.api import Inventory, State, Config
        from pyinfra.api.connect import connect_all
        from pyinfra.context import ctx_state, ctx_host, ctx_config
    except ImportError:
        raise ImportError(
            "pyinfra is required for deployment. Install it with: pip install netrun[deploy]"
        )

    errors: list[str] = []
    ssh = config.ssh
    ps = config.pool_server

    # Build pyinfra inventory
    ssh_kwargs: dict = {
        "ssh_user": ssh.user,
        "ssh_port": ssh.port,
    }
    if ssh.ssh_key:
        ssh_kwargs["ssh_key"] = ssh.ssh_key
    if ssh.ssh_key_password:
        ssh_kwargs["ssh_key_password"] = ssh.ssh_key_password

    pyinfra_config = Config()
    inventory = Inventory(
        ([(ssh.host, ssh_kwargs)], {})
    )
    state = State(inventory, pyinfra_config)

    if not dry_run:
        connect_all(state)

    # Set pyinfra context and register operations for each host
    ctx_state.set(state)
    ctx_config.set(pyinfra_config)
    try:
        for host in inventory:
            ctx_host.set(host)
            _run_deploy_operations(config, state, dry_run)
    finally:
        ctx_state.reset()
        ctx_config.reset()
        ctx_host.reset()

    return DeployResult(
        host=ssh.host,
        port=ps.port,
        pool_server_url=f"ws://{ssh.host}:{ps.port}",
        pid_file=f"{config.repo.remote_dir}/.netrun_serve_pool.pid",
        success=len(errors) == 0,
        errors=errors,
    )

# %% [markdown]
# ## Update Pool URL

# %%
#|export
def update_pool_url(config: NetConfig, pool_name: str, deploy_result: DeployResult) -> NetConfig:
    """Create a new NetConfig with the specified remote pool's URL updated.

    Args:
        config: The original NetConfig.
        pool_name: Name of the pool to update.
        deploy_result: Deployment result containing the new URL.

    Returns:
        A new NetConfig with the pool URL updated.

    Raises:
        KeyError: If pool_name is not found in config.pools.
        TypeError: If the pool is not a remote pool.
    """
    if config.pools is None or pool_name not in config.pools:
        raise KeyError(f"Pool '{pool_name}' not found in config. Available: {list(config.pools or {})}")

    pool_config = config.pools[pool_name]
    if not isinstance(pool_config.spec, RemotePoolConfig):
        raise TypeError(
            f"Pool '{pool_name}' is type '{pool_config.spec.type}', not 'remote'. "
            f"Only remote pools can have their URL updated."
        )

    new_spec = pool_config.spec.model_copy(update={"url": deploy_result.pool_server_url})
    new_pool = pool_config.model_copy(update={"spec": new_spec})
    new_pools = {**config.pools, pool_name: new_pool}
    return config.model_copy(update={"pools": new_pools})

# %% [markdown]
# ## Deploy and Connect

# %%
#|export
def deploy_and_connect(
    deploy_config: DeployConfig,
    net_config: NetConfig,
    pool_name: str,
) -> tuple[DeployResult, NetConfig]:
    """Deploy a pool server and update the NetConfig with the new URL.

    Convenience function that calls deploy() then update_pool_url().

    Args:
        deploy_config: Deployment configuration.
        net_config: The NetConfig to update.
        pool_name: Name of the remote pool to update.

    Returns:
        Tuple of (DeployResult, updated NetConfig).
    """
    result = deploy(deploy_config)
    updated_config = update_pool_url(net_config, pool_name, result)
    return result, updated_config
