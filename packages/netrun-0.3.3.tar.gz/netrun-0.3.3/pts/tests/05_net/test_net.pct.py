# ---
# jupyter:
#   kernelspec:
#     display_name: .venv
#     language: python
#     name: python3
# ---

# %% [markdown]
# # Tests for Net Module
#
# Comprehensive tests for the Net class and related components.

# %%
#|default_exp net.test_net

# %%
#|export
import pytest
import asyncio
import time
from datetime import datetime
from unittest.mock import Mock, MagicMock, patch
from dataclasses import dataclass

from netrun.net._net import (
    Net,
    NetProtocolKeys,
    NodeExecutionContext,
    NodeExecutionResult,
    NodeFailureContext,
    DeferredActionQueue,
    EpochCancelled,
    EpochError,
    EpochRecord,
    NodeInfo,
    EdgeInfo,
    create_net_func_preprocessor,
    create_net_func_done_callback,
)
from netrun.net.config import (
    NetConfig,
    GraphConfig,
    NodeConfig,
    NodeExecutionConfig,
    NodeVariable,
    PoolConfig,
    MainPoolConfig,
    ThreadPoolConfig,
    MultiprocessPoolConfig,
    PortConfig,
    EdgeConfig,
    SalvoConditionConfig,
    SalvoConditionTermTrueConfig,
    SalvoConditionTermPortConfig,
    MaxSalvosFiniteConfig,
    PacketCountAllConfig,
    PortStateNonEmptyConfig,
)
from netrun.execution_manager import RunAllocationMethod
from netrun.storage import LazyPacketValueSpec

# %% [markdown]
# ## NetProtocolKeys Tests

# %%
#|export
def test_net_protocol_keys_values():
    """Test that NetProtocolKeys have expected string values."""
    assert NetProtocolKeys.UP_CREATE_PACKET.value == "net:create-packet"
    assert NetProtocolKeys.UP_CREATE_PACKET_RESPONSE.value == "net:create-packet-response"
    assert NetProtocolKeys.UP_CONSUME_PACKET.value == "net:consume-packet"
    assert NetProtocolKeys.UP_CONSUME_PACKET_RESPONSE.value == "net:consume-packet-response"
    assert NetProtocolKeys.UP_LOAD_OUTPUT_PORT.value == "net:load-output-port"
    assert NetProtocolKeys.UP_LOAD_OUTPUT_PORT_RESPONSE.value == "net:load-output-port-response"
    assert NetProtocolKeys.UP_SEND_OUTPUT_SALVO.value == "net:send-salvo"
    assert NetProtocolKeys.UP_SEND_OUTPUT_SALVO_RESPONSE.value == "net:send-salvo-response"
    assert NetProtocolKeys.UP_CANCEL_EPOCH.value == "net:cancel-epoch"
    assert NetProtocolKeys.UP_PRINT_BUFFER.value == "net:print-buffer"

# %%
test_net_protocol_keys_values()

# %%
#|export
def test_net_protocol_keys_uniqueness():
    """Test that all protocol keys have unique values."""
    values = [key.value for key in NetProtocolKeys]
    assert len(values) == len(set(values)), "Protocol keys must have unique values"

# %%
test_net_protocol_keys_uniqueness()

# %% [markdown]
# ## NodeExecutionContext Tests

# %%
#|export
def test_node_execution_context_creation():
    """Test NodeExecutionContext can be created with required fields."""
    ctx = NodeExecutionContext(
        epoch_id="epoch_123",
        node_name="TestNode",
    )
    assert ctx.epoch_id == "epoch_123"
    assert ctx.node_name == "TestNode"
    assert ctx.retry_count == 0
    assert ctx.retry_timestamps == []
    assert ctx.retry_exceptions == []
    assert ctx._print_buffer == []
    assert ctx._created_packets == []
    assert ctx._consumed_packets == []

# %%
test_node_execution_context_creation()

# %%
#|export
def test_node_execution_context_with_retry_info():
    """Test NodeExecutionContext with retry information."""
    timestamps = [datetime.now()]
    exceptions = [ValueError("test error")]

    ctx = NodeExecutionContext(
        epoch_id="epoch_456",
        node_name="RetryNode",
        retry_count=2,
        retry_timestamps=timestamps,
        retry_exceptions=exceptions,
    )
    assert ctx.retry_count == 2
    assert ctx.retry_timestamps == timestamps
    assert ctx.retry_exceptions == exceptions

# %%
test_node_execution_context_with_retry_info()

# %% [markdown]
# ### Print Capture Tests

# %%
#|export
def test_context_print_basic():
    """Test basic print capture without config."""
    ctx = NodeExecutionContext(
        epoch_id="epoch_print",
        node_name="PrintNode",
    )

    ctx.print("Hello", "World")

    # Buffer should contain (timestamp, message) tuple
    assert len(ctx._print_buffer) == 1
    timestamp, message = ctx._print_buffer[0]
    assert isinstance(timestamp, datetime)
    assert message == "Hello World\n"

# %%
test_context_print_basic()

# %%
#|export
def test_context_print_custom_separators():
    """Test print with custom sep and end."""
    ctx = NodeExecutionContext(
        epoch_id="epoch_sep",
        node_name="SepNode",
    )

    ctx.print("a", "b", "c", sep="-", end="!")

    timestamp, message = ctx._print_buffer[0]
    assert isinstance(timestamp, datetime)
    assert message == "a-b-c!"

# %%
test_context_print_custom_separators()

# %%
#|export
def test_context_print_empty():
    """Test print with no arguments."""
    ctx = NodeExecutionContext(
        epoch_id="epoch_empty",
        node_name="EmptyNode",
    )

    ctx.print()

    timestamp, message = ctx._print_buffer[0]
    assert isinstance(timestamp, datetime)
    assert message == "\n"

# %%
test_context_print_empty()

# %%
#|export
def test_context_print_non_string():
    """Test print with non-string arguments."""
    ctx = NodeExecutionContext(
        epoch_id="epoch_types",
        node_name="TypesNode",
    )

    ctx.print(1, 2.5, True, None, [1, 2, 3])

    timestamp, message = ctx._print_buffer[0]
    assert isinstance(timestamp, datetime)
    assert message == "1 2.5 True None [1, 2, 3]\n"

# %%
test_context_print_non_string()

# %%
#|export
def test_context_print_accumulates():
    """Test print accumulates messages in buffer with timestamps."""
    config = NodeExecutionConfig(
        node_name="AccumNode",
    )

    ctx = NodeExecutionContext(
        epoch_id="epoch_accum",
        node_name="AccumNode",
        _config=config,
    )

    # Print multiple messages
    ctx.print("First message")
    ctx.print("Second message")
    ctx.print("Third message")

    # All messages should be accumulated in the buffer
    assert len(ctx._print_buffer) == 3

    messages = [msg for _, msg in ctx._print_buffer]
    assert "First message\n" in messages
    assert "Second message\n" in messages
    assert "Third message\n" in messages

    # Each entry should have a timestamp
    for timestamp, _ in ctx._print_buffer:
        assert isinstance(timestamp, datetime)

# %%
test_context_print_accumulates()

# %%
#|export
def test_context_print_multiple_timestamps():
    """Test that each print call captures its own timestamp."""
    ctx = NodeExecutionContext(
        epoch_id="epoch_timestamps",
        node_name="TimestampsNode",
    )

    # Print multiple messages
    ctx.print("Message 1")
    time.sleep(0.01)  # Small delay
    ctx.print("Message 2")
    time.sleep(0.01)
    ctx.print("Message 3")

    assert len(ctx._print_buffer) == 3

    # Each timestamp should be distinct and in order
    timestamps = [ts for ts, _ in ctx._print_buffer]
    assert timestamps[0] <= timestamps[1] <= timestamps[2]

# %%
test_context_print_multiple_timestamps()

# %%
#|export
def test_context_print_flush_ignored():
    """Test flush parameter is accepted but has no effect (deferred mode)."""
    ctx = NodeExecutionContext(
        epoch_id="epoch_flush",
        node_name="FlushNode",
    )

    # Print with flush=True - in deferred mode, this just adds to buffer
    ctx.print("Message with flush", flush=True)

    # Message should be in buffer
    assert len(ctx._print_buffer) == 1
    _, message = ctx._print_buffer[0]
    assert message == "Message with flush\n"

# %%
test_context_print_flush_ignored()

# %%
#|export
def test_context_print_echo_stdout(capsys):
    """Test print with stdout echo enabled."""
    config = NodeExecutionConfig(
        node_name="EchoNode",
        print_echo_stdout=True,
    )

    ctx = NodeExecutionContext(
        epoch_id="epoch_echo",
        node_name="EchoNode",
        _config=config,
    )

    ctx.print("Echo this message")

    # Check stdout
    captured = capsys.readouterr()
    assert "Echo this message" in captured.out

    # Also check buffer contains the timestamped message
    assert len(ctx._print_buffer) == 1
    timestamp, message = ctx._print_buffer[0]
    assert message == "Echo this message\n"

# %%
test_context_print_echo_stdout()

# %%
#|export
def test_context_get_execution_result():
    """Test _get_execution_result returns correct data."""
    ctx = NodeExecutionContext(
        epoch_id="epoch_result",
        node_name="ResultNode",
    )

    # Add some prints
    ctx.print("Test print")

    # Create and consume some packets
    deferred_id = ctx.create_packet({"data": "test"})
    ctx._input_packet_values["input_packet"] = {"input": "value"}
    ctx.consume_packet("input_packet")

    # Get execution result
    result = ctx._get_execution_result()

    assert result.cancelled is False
    assert len(result.print_buffer) == 1
    assert result.print_buffer[0][1] == "Test print\n"
    assert deferred_id in result.created_packets
    assert "input_packet" in result.consumed_packets

# %%
test_context_get_execution_result()

# %% [markdown]
# ### Packet Operation Tests

# %%
#|export
def test_context_create_packet():
    """Test create_packet returns deferred ID and queues action."""
    ctx = NodeExecutionContext(
        epoch_id="epoch_create",
        node_name="CreateNode",
    )

    packet_id = ctx.create_packet({"data": "test"})

    # Should return a deferred ID
    assert packet_id.startswith("deferred_")
    assert packet_id in ctx._created_packets

    # Should queue the action
    assert len(ctx._deferred_actions.actions) == 1
    action_type, args = ctx._deferred_actions.actions[0]
    assert action_type == "create_packet"
    assert args[0] == packet_id
    assert args[1] == {"data": "test"}

    # Value should be in packet_values
    assert ctx._deferred_actions.packet_values[packet_id] == {"data": "test"}

# %%
test_context_create_packet()

# %%
#|export
def test_context_create_packet_from_value_func():
    """Test create_packet_from_value_func queues LazyPacketValueSpec."""
    ctx = NodeExecutionContext(
        epoch_id="epoch_lazy",
        node_name="LazyNode",
    )

    packet_id = ctx.create_packet_from_value_func(
        func_import_path="mymodule.fetch_data",
        args=("arg1",),
        kwargs={"key": "value"},
    )

    # Should return a deferred ID
    assert packet_id.startswith("deferred_")
    assert packet_id in ctx._created_packets

    # Should queue the action with LazyPacketValueSpec
    assert len(ctx._deferred_actions.actions) == 1
    action_type, args = ctx._deferred_actions.actions[0]
    assert action_type == "create_packet"

    sent_value = ctx._deferred_actions.packet_values[packet_id]
    assert isinstance(sent_value, LazyPacketValueSpec)
    assert sent_value.func_import_path == "mymodule.fetch_data"
    assert sent_value.args == ("arg1",)
    assert sent_value.kwargs == {"key": "value"}

# %%
test_context_create_packet_from_value_func()

# %%
#|export
def test_context_consume_packet():
    """Test consume_packet returns value from input packets and queues action."""
    ctx = NodeExecutionContext(
        epoch_id="epoch_consume",
        node_name="ConsumeNode",
    )

    # Set up input packet value (normally passed from Net)
    ctx._input_packet_values["packet_xyz"] = {"consumed": "data"}

    value = ctx.consume_packet("packet_xyz")

    assert value == {"consumed": "data"}
    assert "packet_xyz" in ctx._consumed_packets

    # Should queue the consume action
    assert len(ctx._deferred_actions.actions) == 1
    action_type, args = ctx._deferred_actions.actions[0]
    assert action_type == "consume_packet"
    assert args == ("packet_xyz",)

# %%
test_context_consume_packet()

# %%
#|export
def test_context_consume_packet_not_found():
    """Test consume_packet raises KeyError for unknown packet."""
    ctx = NodeExecutionContext(
        epoch_id="epoch_missing",
        node_name="MissingNode",
    )

    with pytest.raises(KeyError) as exc_info:
        ctx.consume_packet("nonexistent_packet")

    assert "nonexistent_packet" in str(exc_info.value)

# %%
test_context_consume_packet_not_found()

# %%
#|export
def test_context_load_output_port():
    """Test load_output_port queues action."""
    ctx = NodeExecutionContext(
        epoch_id="epoch_load",
        node_name="LoadNode",
    )

    ctx.load_output_port("out", "packet_123")

    # Should queue the action
    assert len(ctx._deferred_actions.actions) == 1
    action_type, args = ctx._deferred_actions.actions[0]
    assert action_type == "load_output_port"
    assert args == ("out", "packet_123")

# %%
test_context_load_output_port()

# %%
#|export
def test_context_send_output_salvo():
    """Test send_output_salvo queues action."""
    ctx = NodeExecutionContext(
        epoch_id="epoch_salvo",
        node_name="SalvoNode",
    )

    ctx.send_output_salvo("send_condition")

    # Should queue the action
    assert len(ctx._deferred_actions.actions) == 1
    action_type, args = ctx._deferred_actions.actions[0]
    assert action_type == "send_output_salvo"
    assert args == ("send_condition",)

# %%
test_context_send_output_salvo()

# %%
#|export
def test_context_cancel_epoch():
    """Test cancel_epoch raises EpochCancelled and discards actions."""
    ctx = NodeExecutionContext(
        epoch_id="epoch_cancel",
        node_name="CancelNode",
    )

    # Add some actions first
    ctx.create_packet({"data": "test"})
    assert len(ctx._deferred_actions.actions) == 1

    with pytest.raises(EpochCancelled) as exc_info:
        ctx.cancel_epoch()

    assert "epoch_cancel" in str(exc_info.value)

    # Deferred actions should be discarded
    assert len(ctx._deferred_actions.actions) == 0
    assert ctx._cancelled is True

# %%
test_context_cancel_epoch()

# %%
#|export
def test_context_full_workflow():
    """Test a complete workflow with create, consume, load, and send."""
    ctx = NodeExecutionContext(
        epoch_id="epoch_workflow",
        node_name="WorkflowNode",
    )

    # Set up input packet
    ctx._input_packet_values["input_pkt"] = {"input": "data"}

    # Consume input
    input_value = ctx.consume_packet("input_pkt")
    assert input_value == {"input": "data"}

    # Create output packet
    output_id = ctx.create_packet({"output": "result"})
    assert output_id.startswith("deferred_")

    # Load into output port
    ctx.load_output_port("out", output_id)

    # Send salvo
    ctx.send_output_salvo("send")

    # Check all actions queued correctly
    assert len(ctx._deferred_actions.actions) == 4
    action_types = [a[0] for a in ctx._deferred_actions.actions]
    assert action_types == ["consume_packet", "create_packet", "load_output_port", "send_output_salvo"]

    # Get execution result
    result = ctx._get_execution_result()
    assert not result.cancelled
    assert "input_pkt" in result.consumed_packets
    assert output_id in result.created_packets

# %%
test_context_full_workflow()

# %% [markdown]
# ## Type Checking Tests
#
# Tests for the `_check_type` method which has two modes:
# 1. String mode: Uses `__name__` matching
# 2. Type mode: Uses beartype for proper generic checking

# %%
#|export
def test_check_type_string_simple():
    """Test string-based type checking with simple type names."""
    ctx = NodeExecutionContext(epoch_id="test", node_name="Test")

    # Simple type names use __name__ matching
    name, matches, mode = ctx._check_type("int", 42)
    assert name == "int"
    assert matches is True
    assert mode == "string"

    name, matches, mode = ctx._check_type("str", "hello")
    assert name == "str"
    assert matches is True
    assert mode == "string"

    name, matches, mode = ctx._check_type("list", [1, 2, 3])
    assert name == "list"
    assert matches is True
    assert mode == "string"

    # Mismatches
    name, matches, mode = ctx._check_type("int", "not an int")
    assert name == "int"
    assert matches is False
    assert mode == "string"

# %%
test_check_type_string_simple()

# %%
#|export
def test_check_type_string_generic_fails():
    """Test that string generic types like 'list[int]' fail with __name__ matching.

    This is expected behavior - string mode uses __name__ which is just 'list',
    not 'list[int]'. For proper generic checking, use actual type objects.
    """
    ctx = NodeExecutionContext(epoch_id="test", node_name="Test")

    # String "list[int]" will NOT match because type([1,2,3]).__name__ is "list"
    name, matches, mode = ctx._check_type("list[int]", [1, 2, 3])
    assert name == "list[int]"
    assert matches is False  # Expected! __name__ is "list", not "list[int]"
    assert mode == "string"

# %%
test_check_type_string_generic_fails()

# %%
#|export
def test_check_type_type_object_simple():
    """Test type-based checking with simple type objects."""
    ctx = NodeExecutionContext(epoch_id="test", node_name="Test")

    # Type objects use beartype's is_bearable
    name, matches, mode = ctx._check_type(int, 42)
    assert name == "int"
    assert matches is True
    assert mode == "beartype"

    name, matches, mode = ctx._check_type(str, "hello")
    assert name == "str"
    assert matches is True
    assert mode == "beartype"

    name, matches, mode = ctx._check_type(list, [1, 2, 3])
    assert name == "list"
    assert matches is True
    assert mode == "beartype"

    # Mismatches
    name, matches, mode = ctx._check_type(int, "not an int")
    assert name == "int"
    assert matches is False
    assert mode == "beartype"

# %%
test_check_type_type_object_simple()

# %%
#|export
def test_check_type_type_object_generic():
    """Test type-based checking with generic types like list[int].

    This uses beartype's is_bearable which properly handles generics.
    """
    ctx = NodeExecutionContext(epoch_id="test", node_name="Test")

    # Generic type objects use beartype
    name, matches, mode = ctx._check_type(list[int], [1, 2, 3])
    assert name == "list"  # __name__ of generic is base type
    assert matches is True
    assert mode == "beartype"

    name, matches, mode = ctx._check_type(list[str], ["a", "b", "c"])
    assert name == "list"
    assert matches is True
    assert mode == "beartype"

    name, matches, mode = ctx._check_type(dict[str, int], {"a": 1, "b": 2})
    assert name == "dict"
    assert matches is True
    assert mode == "beartype"

    # Empty containers match generic types
    name, matches, mode = ctx._check_type(list[int], [])
    assert matches is True
    assert mode == "beartype"

# %%
test_check_type_type_object_generic()

# %%
#|export
def test_check_type_type_object_generic_mismatch():
    """Test that generic type mismatches are detected by beartype.

    Note: beartype uses O(1) probabilistic sampling, so it may not catch
    every element mismatch in large collections. But it catches type mismatches.
    """
    ctx = NodeExecutionContext(epoch_id="test", node_name="Test")

    # Wrong base type
    name, matches, mode = ctx._check_type(list[int], "not a list")
    assert matches is False
    assert mode == "beartype"

    name, matches, mode = ctx._check_type(dict[str, int], [1, 2, 3])
    assert matches is False
    assert mode == "beartype"

# %%
test_check_type_type_object_generic_mismatch()

# %%
#|export
def test_check_type_distinguishes_modes():
    """Test that string vs type object triggers different checking modes."""
    ctx = NodeExecutionContext(epoch_id="test", node_name="Test")

    # String "list" matches via __name__
    name1, matches1, mode1 = ctx._check_type("list", [1, 2, 3])
    assert matches1 is True
    assert mode1 == "string"

    # Type object list matches via beartype
    name2, matches2, mode2 = ctx._check_type(list, [1, 2, 3])
    assert matches2 is True
    assert mode2 == "beartype"

    # String "list[int]" fails (no such __name__)
    name3, matches3, mode3 = ctx._check_type("list[int]", [1, 2, 3])
    assert matches3 is False
    assert mode3 == "string"

    # Type object list[int] succeeds via beartype
    name4, matches4, mode4 = ctx._check_type(list[int], [1, 2, 3])
    assert matches4 is True
    assert mode4 == "beartype"

# %%
test_check_type_distinguishes_modes()

# %%
#|export
def test_type_checking_disabled():
    """Test that type checking can be disabled via _type_checking_enabled."""
    from netrun.net._net import PacketTypeMismatch

    # Create context with type checking enabled (default)
    ctx_enabled = NodeExecutionContext(
        epoch_id="test",
        node_name="Test",
        _type_checking_enabled=True,
    )
    ctx_enabled._out_ports = {"out": PortConfig(port_type="int")}

    # Should raise on type mismatch
    try:
        ctx_enabled._validate_port_type("out", "int", "not an int", "pkt1")
        assert False, "Should have raised PacketTypeMismatch"
    except PacketTypeMismatch:
        pass  # Expected

    # Create context with type checking disabled
    ctx_disabled = NodeExecutionContext(
        epoch_id="test",
        node_name="Test",
        _type_checking_enabled=False,
    )
    ctx_disabled._out_ports = {"out": PortConfig(port_type="int")}

    # Should NOT raise on type mismatch
    ctx_disabled._validate_port_type("out", "int", "not an int", "pkt1")
    # If we get here without exception, the test passes

# %%
test_type_checking_disabled()

# %%
#|export
def test_node_execution_config_type_checking():
    """Test type_checking_enabled field in NodeExecutionConfig."""
    # Default should be None (inherit from Net)
    config = NodeExecutionConfig()
    assert config.type_checking_enabled is None

    # Can be set explicitly
    config_enabled = NodeExecutionConfig(type_checking_enabled=True)
    assert config_enabled.type_checking_enabled is True

    config_disabled = NodeExecutionConfig(type_checking_enabled=False)
    assert config_disabled.type_checking_enabled is False

# %%
test_node_execution_config_type_checking()

# %%
#|export
def test_net_config_type_checking():
    """Test type_checking_enabled field in NetConfig."""
    # Default should be True
    config = NetConfig(graph=GraphConfig(nodes=[], edges=[]))
    assert config.type_checking_enabled is True

    # Can be set explicitly
    config_disabled = NetConfig(
        graph=GraphConfig(nodes=[], edges=[]),
        type_checking_enabled=False,
    )
    assert config_disabled.type_checking_enabled is False

# %%
test_net_config_type_checking()

# %%
#|export
def test_preprocessor_type_checking_inheritance():
    """Test that preprocessor correctly inherits/overrides type_checking_enabled."""
    # Create node configs with different settings
    node_configs = {
        "inherit_node": NodeExecutionConfig(),  # None = inherit
        "enabled_node": NodeExecutionConfig(type_checking_enabled=True),
        "disabled_node": NodeExecutionConfig(type_checking_enabled=False),
    }

    # Test with net-level enabled (default)
    preprocessor_enabled = create_net_func_preprocessor(
        node_configs,
        net_type_checking_enabled=True,
    )

    # Check the configs passed through
    assert preprocessor_enabled._node_configs["inherit_node"].type_checking_enabled is True
    assert preprocessor_enabled._node_configs["enabled_node"].type_checking_enabled is True
    assert preprocessor_enabled._node_configs["disabled_node"].type_checking_enabled is False

    # Test with net-level disabled
    preprocessor_disabled = create_net_func_preprocessor(
        node_configs,
        net_type_checking_enabled=False,
    )

    # inherit_node should now be False, but explicit settings stay
    assert preprocessor_disabled._node_configs["inherit_node"].type_checking_enabled is False
    assert preprocessor_disabled._node_configs["enabled_node"].type_checking_enabled is True
    assert preprocessor_disabled._node_configs["disabled_node"].type_checking_enabled is False

# %%
test_preprocessor_type_checking_inheritance()

# %% [markdown]
# ## NodeFailureContext Tests

# %%
#|export
def test_node_failure_context_creation():
    """Test NodeFailureContext creation."""
    exc = ValueError("test error")
    ctx = NodeFailureContext(
        epoch_id="epoch_fail",
        node_name="FailNode",
        retry_count=1,
        exception=exc,
        input_salvo={"in": ["packet_1", "packet_2"]},
    )

    assert ctx.epoch_id == "epoch_fail"
    assert ctx.node_name == "FailNode"
    assert ctx.retry_count == 1
    assert ctx.exception == exc
    assert ctx.input_salvo == {"in": ["packet_1", "packet_2"]}

# %%
test_node_failure_context_creation()

# %% [markdown]
# ## DeferredActionQueue Tests

# %%
#|export
def test_deferred_queue_add_create_packet():
    """Test adding create_packet action to deferred queue."""
    queue = DeferredActionQueue()

    deferred_id = queue.add_create_packet({"value": 123})

    assert deferred_id.startswith("deferred_")
    assert len(queue.actions) == 1
    assert queue.actions[0][0] == "create_packet"
    assert deferred_id in queue.packet_values
    assert queue.packet_values[deferred_id] == {"value": 123}

# %%
test_deferred_queue_add_create_packet()

# %%
#|export
def test_deferred_queue_add_consume_packet():
    """Test adding consume_packet action to deferred queue."""
    queue = DeferredActionQueue()

    queue.add_consume_packet("packet_to_consume")

    assert len(queue.actions) == 1
    assert queue.actions[0] == ("consume_packet", ("packet_to_consume",))

# %%
test_deferred_queue_add_consume_packet()

# %%
#|export
def test_deferred_queue_add_load_output_port():
    """Test adding load_output_port action to deferred queue."""
    queue = DeferredActionQueue()

    queue.add_load_output_port("out", "packet_123")

    assert len(queue.actions) == 1
    assert queue.actions[0] == ("load_output_port", ("out", "packet_123"))

# %%
test_deferred_queue_add_load_output_port()

# %%
#|export
def test_deferred_queue_add_send_output_salvo():
    """Test adding send_output_salvo action to deferred queue."""
    queue = DeferredActionQueue()

    queue.add_send_output_salvo("send_condition")

    assert len(queue.actions) == 1
    assert queue.actions[0] == ("send_output_salvo", ("send_condition",))

# %%
test_deferred_queue_add_send_output_salvo()

# %%
#|export
def test_deferred_queue_discard():
    """Test discarding all queued actions."""
    queue = DeferredActionQueue()

    queue.add_create_packet("value1")
    queue.add_consume_packet("packet_1")
    queue.add_load_output_port("out", "packet_2")

    assert len(queue.actions) == 3
    assert len(queue.packet_values) == 1

    queue.discard()

    assert len(queue.actions) == 0
    assert len(queue.packet_values) == 0
    assert len(queue.deferred_to_real_ids) == 0

# %%
test_deferred_queue_discard()

# %%
#|export
def test_deferred_queue_multiple_creates():
    """Test creating multiple packets with deferred queue."""
    queue = DeferredActionQueue()

    id1 = queue.add_create_packet("value1")
    id2 = queue.add_create_packet("value2")
    id3 = queue.add_create_packet("value3")

    # All IDs should be unique
    assert len({id1, id2, id3}) == 3

    # All should start with deferred_
    assert all(id_.startswith("deferred_") for id_ in [id1, id2, id3])

# %%
test_deferred_queue_multiple_creates()

# %% [markdown]
# ## func_preprocessor Tests

# %%
#|export
def test_create_net_func_preprocessor_basic():
    """Test func_preprocessor transforms function correctly."""
    node_configs = {
        "TestNode": NodeExecutionConfig(
            node_name="TestNode",
        )
    }

    preprocessor = create_net_func_preprocessor(node_configs)

    call_log = []

    def test_func(ctx, packets):
        call_log.append((ctx.epoch_id, ctx.node_name, packets))
        return "result"

    wrapped = preprocessor(test_func)

    # Call wrapped function with packet values
    result = wrapped(
        epoch_id="epoch_test",
        node_name="TestNode",
        packets={"in": ["p1", "p2"]},
        packet_values={"p1": {"data": 1}, "p2": {"data": 2}},
    )

    # Result should be NodeExecutionResult
    assert isinstance(result, NodeExecutionResult)
    assert result.func_result == "result"
    assert result.exception is None
    assert not result.cancelled

    assert len(call_log) == 1
    assert call_log[0][0] == "epoch_test"
    assert call_log[0][1] == "TestNode"
    assert call_log[0][2] == {"in": ["p1", "p2"]}

# %%
test_create_net_func_preprocessor_basic()

# %%
#|export
def test_create_net_func_preprocessor_with_retry_info():
    """Test func_preprocessor passes retry information."""
    node_configs = {}
    preprocessor = create_net_func_preprocessor(node_configs)

    captured_ctx = None

    def test_func(ctx, packets):
        nonlocal captured_ctx
        captured_ctx = ctx
        return "ok"

    wrapped = preprocessor(test_func)

    retry_ts = [datetime.now()]
    retry_exc = [ValueError("retry error")]

    result = wrapped(
        epoch_id="epoch_retry",
        node_name="RetryNode",
        packets={},
        packet_values={},
        retry_count=2,
        retry_timestamps=retry_ts,
        retry_exceptions=retry_exc,
    )

    assert captured_ctx.retry_count == 2
    assert captured_ctx.retry_timestamps == retry_ts
    assert captured_ctx.retry_exceptions == retry_exc
    assert result.func_result == "ok"

# %%
test_create_net_func_preprocessor_with_retry_info()

# %%
#|export
def test_create_net_func_preprocessor_captures_prints():
    """Test func_preprocessor captures print buffer in result."""
    node_configs = {
        "PrintNode": NodeExecutionConfig(
            node_name="PrintNode",
        )
    }
    preprocessor = create_net_func_preprocessor(node_configs)

    def test_func(ctx, packets):
        ctx.print("Message 1")
        ctx.print("Message 2")
        return "done"

    wrapped = preprocessor(test_func)

    result = wrapped(
        epoch_id="epoch_print",
        node_name="PrintNode",
        packets={},
        packet_values={},
    )

    # Print buffer should be in the result
    assert isinstance(result, NodeExecutionResult)
    assert len(result.print_buffer) == 2
    messages = [msg for _, msg in result.print_buffer]
    assert "Message 1\n" in messages
    assert "Message 2\n" in messages
    assert result.func_result == "done"

# %%
test_create_net_func_preprocessor_captures_prints()

# %%
#|export
def test_create_net_func_preprocessor_captures_exception():
    """Test func_preprocessor captures exception in result."""
    node_configs = {
        "ExcNode": NodeExecutionConfig(
            node_name="ExcNode",
        )
    }
    preprocessor = create_net_func_preprocessor(node_configs)

    def test_func(ctx, packets):
        ctx.print("Before error")
        raise ValueError("test error")

    wrapped = preprocessor(test_func)

    # Should NOT raise - exception is captured in result
    result = wrapped(
        epoch_id="epoch_exc",
        node_name="ExcNode",
        packets={},
        packet_values={},
    )

    # Exception should be captured in result
    assert isinstance(result, NodeExecutionResult)
    assert result.exception is not None
    assert isinstance(result.exception, ValueError)
    assert "test error" in str(result.exception)

    # Print buffer should still be captured
    assert len(result.print_buffer) == 1
    _, message = result.print_buffer[0]
    assert message == "Before error\n"

# %%
test_create_net_func_preprocessor_captures_exception()

# %% [markdown]
# ## func_done_callback Tests

# %%
#|export
def test_create_net_func_done_callback():
    """Test func_done_callback creation."""
    callback = create_net_func_done_callback()

    # Should be callable
    assert callable(callback)

    # Should accept any arguments without error (it's a no-op)
    callback()
    callback("arg1", "arg2", kwarg="value")
    # No error = success

# %%
test_create_net_func_done_callback()

# %% [markdown]
# ## Net Class Tests

# %%
#|export
def create_simple_graph_config():
    """Helper to create a simple graph config for testing."""
    return GraphConfig(
        nodes=[
            NodeConfig(
                name="Source",
                out_ports={"out": PortConfig()},
                out_salvo_conditions={
                    "send": SalvoConditionConfig(
                        max_salvos=MaxSalvosFiniteConfig(max=1),
                        ports={"out": PacketCountAllConfig()},
                        term=SalvoConditionTermTrueConfig(),
                    ),
                },
            ),
            NodeConfig(
                name="Sink",
                in_ports={"in": PortConfig()},
                in_salvo_conditions={
                    "default": SalvoConditionConfig(
                        max_salvos=MaxSalvosFiniteConfig(max=1),
                        ports={"in": PacketCountAllConfig()},
                        term=SalvoConditionTermPortConfig(
                            port_name="in",
                            state=PortStateNonEmptyConfig(),
                        ),
                    ),
                },
            ),
        ],
        edges=[
            EdgeConfig(source_str="Source.out", target_str="Sink.in"),
        ],
    )

# %%
#|export
def create_simple_net_config():
    """Helper to create a simple net config for testing."""
    return NetConfig(
        pools={
            "main_pool": PoolConfig(
                id="main_pool",
                spec=MainPoolConfig(),
            ),
        },
        graph=create_simple_graph_config(),
    )

# %%
#|export
def test_net_creation():
    """Test Net can be created with valid config."""
    config = create_simple_net_config()
    net = Net(config)

    assert net.config == config
    assert net.graph is not None
    assert net.netsim is not None
    assert net.started is False
    assert net.paused is False

# %%
test_net_creation()

# %%
#|export
def test_net_config_property():
    """Test Net config property returns correct config."""
    config = create_simple_net_config()
    net = Net(config)

    assert net.config is config
    assert net.config.pools == config.pools

# %%
test_net_config_property()

# %%
#|export
def test_net_graph_property():
    """Test Net graph property returns netrun_sim.Graph."""
    import netrun_sim

    config = create_simple_net_config()
    net = Net(config)

    assert isinstance(net.graph, netrun_sim.Graph)

# %%
test_net_graph_property()

# %%
#|export
def test_net_with_multiple_pool_types():
    """Test Net can be created with multiple pool types."""
    config = NetConfig(
        pools={
            "main": PoolConfig(spec=MainPoolConfig()),
            "threads": PoolConfig(spec=ThreadPoolConfig(num_workers=2)),
        },
        graph=create_simple_graph_config(),
    )

    net = Net(config)
    assert len(config.pools) == 2

# %%
test_net_with_multiple_pool_types()

# %%
#|export
def test_net_with_node_execution_configs():
    """Test Net extracts node execution configs from graph."""
    def dummy_func(ctx, packets):
        pass

    graph_config = GraphConfig(
        nodes=[
            NodeConfig(
                name="NodeA",
                out_ports={"out": PortConfig()},
                execution_config=NodeExecutionConfig(
                    node_name="NodeA",
                    pools=["main"],
                    exec_node_func=dummy_func,
                ),
            ),
            NodeConfig(
                name="NodeB",
                in_ports={"in": PortConfig()},
                in_salvo_conditions={
                    "default": SalvoConditionConfig(
                        max_salvos=MaxSalvosFiniteConfig(max=1),
                        ports={"in": PacketCountAllConfig()},
                        term=SalvoConditionTermTrueConfig(),
                    ),
                },
                # No execution config
            ),
        ],
        edges=[EdgeConfig(source_str="NodeA.out", target_str="NodeB.in")],
    )

    config = NetConfig(
        pools={"main": PoolConfig(spec=MainPoolConfig())},
        graph=graph_config,
    )

    net = Net(config)

    # Should have extracted NodeA's config
    assert "NodeA" in net._node_execution_configs
    assert "NodeB" not in net._node_execution_configs

# %%
test_net_with_node_execution_configs()

# %%
#|export
@pytest.mark.asyncio
async def test_net_start_and_stop():
    """Test Net can be started and stopped."""
    config = create_simple_net_config()
    net = Net(config)

    assert net.started is False

    await net.start()
    assert net.started is True

    await net.stop()
    assert net.started is False

# %%
#|export
@pytest.mark.asyncio
async def test_net_start_twice_raises():
    """Test starting Net twice raises RuntimeError."""
    config = create_simple_net_config()
    net = Net(config)

    await net.start()

    with pytest.raises(RuntimeError) as exc_info:
        await net.start()

    assert "already started" in str(exc_info.value).lower()

    await net.stop()

# %%
#|export
@pytest.mark.asyncio
async def test_net_context_manager():
    """Test Net can be used as async context manager."""
    config = create_simple_net_config()

    async with Net(config) as net:
        assert net.started is True

    assert net.started is False

# %%
#|export
@pytest.mark.asyncio
async def test_net_pause_and_resume():
    """Test Net can be paused and resumed."""
    config = create_simple_net_config()

    async with Net(config) as net:
        assert net.paused is False

        await net.pause()
        assert net.paused is True

        await net.resume()
        assert net.paused is False

# %%
#|export
@pytest.mark.asyncio
async def test_net_run_step():
    """Test Net.run_step executes simulation step."""
    config = create_simple_net_config()

    async with Net(config) as net:
        # run_step returns (made_progress, events) tuple
        result = await net.run_step()
        assert isinstance(result, tuple)
        assert len(result) == 2
        made_progress, events = result
        assert isinstance(made_progress, bool)
        assert isinstance(events, list)

# %%
#|export
@pytest.mark.asyncio
async def test_net_run_until_blocked():
    """Test Net.run_until_blocked runs until no progress."""
    config = create_simple_net_config()

    async with Net(config) as net:
        # run_until_blocked should return (made_progress, events)
        made_progress, events = await net.run_until_blocked()
        assert isinstance(made_progress, bool)
        assert isinstance(events, list)

# %%
#|export
@pytest.mark.asyncio
async def test_net_get_startable_epochs():
    """Test Net.get_startable_epochs returns list."""
    config = create_simple_net_config()

    async with Net(config) as net:
        startable = net.get_startable_epochs()
        assert isinstance(startable, list)

# %%
#|export
@pytest.mark.asyncio
async def test_net_get_running_epochs():
    """Test Net.get_running_epochs returns list."""
    config = create_simple_net_config()

    async with Net(config) as net:
        running = net.get_running_epochs()
        assert isinstance(running, list)
        assert len(running) == 0  # No epochs running initially

# %%
#|export
def test_net_get_epoch_log_empty():
    """Test get_epoch_log returns empty list for unknown epoch."""
    config = create_simple_net_config()
    net = Net(config)

    log = net.get_epoch_log("nonexistent_epoch")
    assert log == []

# %%
test_net_get_epoch_log_empty()

# %%
#|export
def test_net_get_node_logs_empty():
    """Test get_node_logs returns empty list for unknown node."""
    config = create_simple_net_config()
    net = Net(config)

    log = net.get_node_logs("NonexistentNode")
    assert log == []

# %%
test_net_get_node_logs_empty()

# %%
#|export
def test_net_handle_print_buffer():
    """Test Net._handle_print_buffer stores prints correctly."""
    from datetime import timezone
    config = create_simple_net_config()
    net = Net(config)

    # Register an epoch record (as _execute_epoch would)
    net._epochs["epoch_123"] = EpochRecord(
        id="epoch_123", node_name="Source", in_salvo=None, out_salvos=[],
        state=None, orphaned_packets=[], created_at=datetime.now(tz=timezone.utc),
    )

    # Create timestamped print buffer (as would come from ctx.print())
    ts1 = datetime.now()
    ts2 = datetime.now()
    buffer = [(ts1, "Line 1\n"), (ts2, "Line 2\n")]

    # Manually call _handle_print_buffer (normally called when receiving from worker)
    net._handle_print_buffer("epoch_123", buffer)

    log = net.get_epoch_log("epoch_123")
    assert len(log) == 2
    assert log[0][1] == "Line 1\n"
    assert log[1][1] == "Line 2\n"
    # Timestamps should be preserved from the original buffer
    assert log[0][0] == ts1
    assert log[1][0] == ts2

# %%
test_net_handle_print_buffer()

# %% [markdown]
# ### Rate Limiting Tests

# %%
#|export
def test_net_check_rate_limit_no_config():
    """Test rate limiting allows when no config exists."""
    config = create_simple_net_config()
    net = Net(config)

    # No rate limit configured
    assert net._check_rate_limit("AnyNode") is True

# %%
test_net_check_rate_limit_no_config()

# %%
#|export
def test_net_check_rate_limit_none_limit():
    """Test rate limiting allows when limit is None."""
    def dummy(ctx, packets):
        pass

    graph_config = GraphConfig(
        nodes=[
            NodeConfig(
                name="LimitedNode",
                in_ports={"in": PortConfig()},
                in_salvo_conditions={
                    "default": SalvoConditionConfig(
                        max_salvos=MaxSalvosFiniteConfig(max=1),
                        ports={"in": PacketCountAllConfig()},
                        term=SalvoConditionTermTrueConfig(),
                    ),
                },
                execution_config=NodeExecutionConfig(
                    node_name="LimitedNode",
                    rate_limit_per_second=None,  # No limit
                ),
            ),
        ],
        edges=[],
    )

    config = NetConfig(
        pools={"main": PoolConfig(spec=MainPoolConfig())},
        graph=graph_config,
    )

    net = Net(config)

    # Should always allow
    for _ in range(10):
        assert net._check_rate_limit("LimitedNode") is True

# %%
test_net_check_rate_limit_none_limit()

# %%
#|export
def test_net_check_rate_limit_enforced():
    """Test rate limiting enforces limit per second."""
    def dummy(ctx, packets):
        pass

    graph_config = GraphConfig(
        nodes=[
            NodeConfig(
                name="RateLimited",
                in_ports={"in": PortConfig()},
                in_salvo_conditions={
                    "default": SalvoConditionConfig(
                        max_salvos=MaxSalvosFiniteConfig(max=1),
                        ports={"in": PacketCountAllConfig()},
                        term=SalvoConditionTermTrueConfig(),
                    ),
                },
                execution_config=NodeExecutionConfig(
                    node_name="RateLimited",
                    rate_limit_per_second=3,
                ),
            ),
        ],
        edges=[],
    )

    config = NetConfig(
        pools={"main": PoolConfig(spec=MainPoolConfig())},
        graph=graph_config,
    )

    net = Net(config)

    # First 3 should be allowed
    assert net._check_rate_limit("RateLimited") is True
    assert net._check_rate_limit("RateLimited") is True
    assert net._check_rate_limit("RateLimited") is True

    # 4th should be blocked
    assert net._check_rate_limit("RateLimited") is False

# %%
test_net_check_rate_limit_enforced()

# %%
#|export
def test_net_check_rate_limit_window_expires():
    """Test rate limit window expires after 1 second."""
    def dummy(ctx, packets):
        pass

    graph_config = GraphConfig(
        nodes=[
            NodeConfig(
                name="WindowNode",
                in_ports={"in": PortConfig()},
                in_salvo_conditions={
                    "default": SalvoConditionConfig(
                        max_salvos=MaxSalvosFiniteConfig(max=1),
                        ports={"in": PacketCountAllConfig()},
                        term=SalvoConditionTermTrueConfig(),
                    ),
                },
                execution_config=NodeExecutionConfig(
                    node_name="WindowNode",
                    rate_limit_per_second=2,
                ),
            ),
        ],
        edges=[],
    )

    config = NetConfig(
        pools={"main": PoolConfig(spec=MainPoolConfig())},
        graph=graph_config,
    )

    net = Net(config)

    # Use up the limit
    assert net._check_rate_limit("WindowNode") is True
    assert net._check_rate_limit("WindowNode") is True
    assert net._check_rate_limit("WindowNode") is False

    # Wait for window to expire
    time.sleep(1.1)

    # Should be allowed again
    assert net._check_rate_limit("WindowNode") is True

# %%
test_net_check_rate_limit_window_expires()

# %% [markdown]
# ### Config Field Tests

# %%
#|export
def test_node_execution_config_new_fields():
    """Test NodeExecutionConfig has new print config fields."""
    config = NodeExecutionConfig(
        node_name="TestNode",
        print_flush_interval=0.2,
        print_buffer_max_size=100,
        print_echo_stdout=True,
        pool_allocation_method=RunAllocationMethod.LEAST_BUSY,
    )

    assert config.print_flush_interval == 0.2
    assert config.print_buffer_max_size == 100
    assert config.print_echo_stdout is True
    assert config.pool_allocation_method == RunAllocationMethod.LEAST_BUSY

# %%
test_node_execution_config_new_fields()

# %%
#|export
def test_node_execution_config_defaults():
    """Test NodeExecutionConfig has correct defaults for new fields."""
    config = NodeExecutionConfig()

    assert config.print_flush_interval == 0.1
    assert config.print_buffer_max_size is None
    assert config.print_echo_stdout is False
    assert config.pool_allocation_method is None

# %%
test_node_execution_config_defaults()

# %%
#|export
def test_net_config_default_pool_allocation_method():
    """Test NetConfig has default_pool_allocation_method field."""
    config = NetConfig(
        pools={"main": PoolConfig(spec=MainPoolConfig())},
        graph=create_simple_graph_config(),
        default_pool_allocation_method=RunAllocationMethod.RANDOM,
    )

    assert config.default_pool_allocation_method == RunAllocationMethod.RANDOM

# %%
test_net_config_default_pool_allocation_method()

# %%
#|export
def test_net_config_default_pool_allocation_method_default():
    """Test NetConfig.default_pool_allocation_method defaults to ROUND_ROBIN."""
    config = NetConfig(
        pools={"main": PoolConfig(spec=MainPoolConfig())},
        graph=create_simple_graph_config(),
    )

    assert config.default_pool_allocation_method == RunAllocationMethod.ROUND_ROBIN

# %%
test_net_config_default_pool_allocation_method_default()

# %% [markdown]
# ## EpochCancelled Exception Tests

# %%
#|export
def test_epoch_cancelled_exception():
    """Test EpochCancelled exception."""
    exc = EpochCancelled("Epoch xyz cancelled")

    assert str(exc) == "Epoch xyz cancelled"
    assert isinstance(exc, Exception)

# %%
test_epoch_cancelled_exception()

# %%
#|export
def test_epoch_cancelled_can_be_raised_and_caught():
    """Test EpochCancelled can be raised and caught."""
    with pytest.raises(EpochCancelled):
        raise EpochCancelled("test")

# %%
test_epoch_cancelled_can_be_raised_and_caught()

# %% [markdown]
# ## Invalid Pool Type Test

# %%
#|export
def test_net_invalid_pool_type_raises():
    """Test Net raises ValueError for invalid pool type."""
    # Create a mock pool config with invalid type
    class InvalidPoolConfig:
        type = "invalid_type"
        def model_dump(self):
            return {"type": "invalid_type"}

    # We need to bypass pydantic validation, so we create the config differently
    # This test documents expected behavior but may need adjustment based on
    # how strictly pydantic validates
    pass  # Skip this test as pydantic prevents invalid pool types

# %%
# test_net_invalid_pool_type_raises() - Skipped

# %% [markdown]
# ## Sync Method Tests

# %%
#|export
def test_net_start_sync():
    """Test Net.start_sync works (synchronous wrapper)."""
    config = create_simple_net_config()
    net = Net(config)

    # This would actually start the net, so we just test it's callable
    assert callable(net.start_sync)

# %%
test_net_start_sync()

# %%
#|export
def test_net_stop_sync():
    """Test Net.stop_sync is callable."""
    config = create_simple_net_config()
    net = Net(config)

    assert callable(net.stop_sync)

# %%
test_net_stop_sync()

# %% [markdown]
# ## Dead Letter Queue Tests

# %%
#|export
def test_net_dead_letter_queue_empty():
    """Test dead letter queue is initially empty."""
    config = create_simple_net_config()
    net = Net(config)

    assert net.dead_letter_queue == []

# %%
test_net_dead_letter_queue_empty()

# %%
#|export
def test_net_dead_letter_queue_returns_copy():
    """Test dead_letter_queue returns a copy, not the internal list."""
    config = create_simple_net_config()
    net = Net(config)

    # Add an item to internal queue
    net._dead_letter_queue.append({"epoch_id": "test"})

    # Get queue
    queue = net.dead_letter_queue

    # Modify returned queue
    queue.append({"epoch_id": "test2"})

    # Internal queue should not be affected
    assert len(net._dead_letter_queue) == 1

# %%
test_net_dead_letter_queue_returns_copy()

# %%
#|export
def test_net_clear_dead_letter_queue():
    """Test clear_dead_letter_queue returns items and clears queue."""
    config = create_simple_net_config()
    net = Net(config)

    # Add items to internal queue
    net._dead_letter_queue.append({"epoch_id": "epoch1"})
    net._dead_letter_queue.append({"epoch_id": "epoch2"})

    # Clear and get items
    items = net.clear_dead_letter_queue()

    assert len(items) == 2
    assert items[0]["epoch_id"] == "epoch1"
    assert items[1]["epoch_id"] == "epoch2"

    # Queue should now be empty
    assert net.dead_letter_queue == []

# %%
test_net_clear_dead_letter_queue()

# %% [markdown]
# ## Retry Configuration Tests

# %%
#|export
def test_node_execution_config_retry_defaults():
    """Test NodeExecutionConfig retry defaults."""
    config = NodeExecutionConfig()

    assert config.retries == 0
    assert config.retry_wait == 0.0
    assert config.on_node_failure is None

# %%
test_node_execution_config_retry_defaults()

# %%
#|export
def test_node_execution_config_with_retries():
    """Test NodeExecutionConfig with retry settings."""
    config = NodeExecutionConfig(
        node_name="RetryNode",
        retries=3,
        retry_wait=0.5,
    )

    assert config.retries == 3
    assert config.retry_wait == 0.5

# %%
test_node_execution_config_with_retries()

# %%
#|export
def test_node_failure_context_full():
    """Test NodeFailureContext with all fields."""
    ts1 = datetime.now()
    ts2 = datetime.now()
    exc1 = ValueError("first error")
    exc2 = ValueError("second error")

    ctx = NodeFailureContext(
        epoch_id="epoch_fail",
        node_name="FailNode",
        retry_count=2,
        exception=exc2,
        retry_timestamps=[ts1, ts2],
        retry_exceptions=[exc1, exc2],
        input_salvo={"in": ["p1", "p2"]},
    )

    assert ctx.epoch_id == "epoch_fail"
    assert ctx.node_name == "FailNode"
    assert ctx.retry_count == 2
    assert ctx.exception == exc2
    assert ctx.retry_timestamps == [ts1, ts2]
    assert ctx.retry_exceptions == [exc1, exc2]
    assert ctx.input_salvo == {"in": ["p1", "p2"]}

# %%
test_node_failure_context_full()

# %% [markdown]
# ## Background Execution Tests

# %%
#|export
@pytest.mark.asyncio
async def test_net_start_background():
    """Test Net can start in background mode."""
    graph_config = GraphConfig(
        nodes=[
            NodeConfig(name="Node1"),
        ],
    )
    config = NetConfig(
        pools={"main": PoolConfig(spec=MainPoolConfig())},
        graph=graph_config,
    )

    net = Net(config)
    await net.start_background()

    assert net.started
    assert net._background_task is not None
    assert not net._background_task.done()

    await net.stop()
    assert not net.started

# %%
#|export
@pytest.mark.asyncio
async def test_net_start_background_already_running():
    """Test start_background raises if background task already running."""
    graph_config = GraphConfig(
        nodes=[
            NodeConfig(name="Node1"),
        ],
    )
    config = NetConfig(
        pools={"main": PoolConfig(spec=MainPoolConfig())},
        graph=graph_config,
    )

    net = Net(config)
    await net.start_background()

    try:
        with pytest.raises(RuntimeError, match="Background task already running"):
            await net.start_background()
    finally:
        await net.stop()

# %%
#|export
def test_net_is_blocked_empty_network():
    """Test is_blocked returns True for empty network."""
    graph_config = GraphConfig(
        nodes=[
            NodeConfig(name="Node1"),
        ],
    )
    config = NetConfig(
        pools={"main": PoolConfig(spec=MainPoolConfig())},
        graph=graph_config,
    )

    net = Net(config)
    assert net.is_blocked()

# %%
#|export
def test_net_is_blocked_with_running_epochs():
    """Test is_blocked returns False when epochs are running."""
    graph_config = GraphConfig(
        nodes=[
            NodeConfig(name="Node1"),
        ],
    )
    config = NetConfig(
        pools={"main": PoolConfig(spec=MainPoolConfig())},
        graph=graph_config,
    )

    net = Net(config)
    net._running_epochs.add("epoch_123")
    assert not net.is_blocked()

# %%
#|export
def test_net_install_sigint_handler():
    """Test _install_sigint_handler sets up handler."""
    graph_config = GraphConfig(
        nodes=[
            NodeConfig(name="Node1"),
        ],
    )
    config = NetConfig(
        pools={"main": PoolConfig(spec=MainPoolConfig())},
        graph=graph_config,
    )

    net = Net(config)
    net._install_sigint_handler()
    assert net._original_sigint_handler is not None
    net._restore_sigint_handler()
    assert net._original_sigint_handler is None

# %% [markdown]
# ## Integration Tests: Full Epoch Flow

# %%
#|export
@pytest.mark.asyncio
async def test_epoch_execution_simple_node():
    """Test executing a simple node function through the full flow."""
    execution_log = []

    def simple_node(ctx, packets):
        execution_log.append({
            "epoch_id": ctx.epoch_id,
            "node_name": ctx.node_name,
            "packets": packets,
        })
        ctx.print(f"Executing {ctx.node_name}")
        # Consume input packets
        for port_name, packet_ids in packets.items():
            for packet_id in packet_ids:
                value = ctx.consume_packet(packet_id)
                execution_log.append({"consumed": packet_id, "value": value})

    graph_config = GraphConfig(
        nodes=[
            NodeConfig(
                name="SimpleNode",
                in_ports={"in": PortConfig()},
                in_salvo_conditions={
                    "default": SalvoConditionConfig(
                        max_salvos=MaxSalvosFiniteConfig(max=1),
                        ports={"in": PacketCountAllConfig()},
                        term=SalvoConditionTermPortConfig(
                            port_name="in",
                            state=PortStateNonEmptyConfig(),
                        ),
                    ),
                },
                execution_config=NodeExecutionConfig(
                    node_name="SimpleNode",
                    pools=["main"],
                    exec_node_func=simple_node,
                ),
            ),
        ],
        edges=[],
    )

    config = NetConfig(
        pools={"main": PoolConfig(spec=MainPoolConfig())},
        graph=graph_config,
    )

    async with Net(config) as net:
        # Inject a packet into the node's input port
        import netrun_sim
        from ulid import ULID

        packet_id = str(ULID())
        net._packet_store.register(packet_id, {"test": "data"})

        # Create packet in netsim and transport to input port
        net._netsim.do_action(netrun_sim.NetAction.create_packet(None))
        # Get the created packet ID from netsim
        # For this test, we'll manually place the packet

        # Run until blocked to trigger epoch creation
        await net.run_until_blocked()

        # Execute any startable epochs
        results = await net.execute_startable_epochs()

        # Check execution happened (may be empty if no epochs were startable)
        # The key is that the infrastructure works

# %%
#|export
@pytest.mark.asyncio
async def test_epoch_execution_with_output():
    """Test node that creates output packets."""
    def producer_node(ctx, packets):
        ctx.print("Producing output")
        # Create an output packet
        out_id = ctx.create_packet({"produced": True})
        ctx.load_output_port("out", out_id)
        ctx.send_output_salvo("send")

    graph_config = GraphConfig(
        nodes=[
            NodeConfig(
                name="Producer",
                out_ports={"out": PortConfig()},
                out_salvo_conditions={
                    "send": SalvoConditionConfig(
                        max_salvos=MaxSalvosFiniteConfig(max=1),
                        ports={"out": PacketCountAllConfig()},
                        term=SalvoConditionTermPortConfig(
                            port_name="out",
                            state=PortStateNonEmptyConfig(),
                        ),
                    ),
                },
                execution_config=NodeExecutionConfig(
                    node_name="Producer",
                    pools=["main"],
                    exec_node_func=producer_node,
                ),
            ),
        ],
        edges=[],
    )

    config = NetConfig(
        pools={"main": PoolConfig(spec=MainPoolConfig())},
        graph=graph_config,
    )

    async with Net(config) as net:
        # Run and check print logs are captured
        await net.run_until_blocked()
        # Infrastructure test - verifies Net can be created and run

# %%
#|export
@pytest.mark.asyncio
async def test_epoch_record_out_salvos_populated():
    """Test EpochRecord.out_salvos is populated after epoch execution."""
    def producer_node(ctx, packets):
        # Consume the input packet
        for port_name, pkt_ids in packets.items():
            for pid in pkt_ids:
                ctx.consume_packet(pid)
        # Create and send an output packet
        out_id = ctx.create_packet(42)
        ctx.load_output_port("out", out_id)
        ctx.send_output_salvo("send")

    graph_config = GraphConfig(
        nodes=[
            NodeConfig(
                name="Producer",
                in_ports={"in": PortConfig()},
                out_ports={"out": PortConfig()},
                out_salvo_conditions={
                    "send": SalvoConditionConfig(
                        max_salvos=MaxSalvosFiniteConfig(max=1),
                        ports={"out": PacketCountAllConfig()},
                        term=SalvoConditionTermPortConfig(
                            port_name="out",
                            state=PortStateNonEmptyConfig(),
                        ),
                    ),
                },
                execution_config=NodeExecutionConfig(
                    node_name="Producer",
                    pools=["main"],
                    exec_node_func=producer_node,
                ),
            ),
        ],
        edges=[],
    )

    config = NetConfig(
        pools={"main": PoolConfig(spec=MainPoolConfig())},
        graph=graph_config,
    )

    async with Net(config) as net:
        net.inject_data("Producer", "in", [1])
        await net.run_until_blocked()

        # Check EpochRecord was created and out_salvos populated
        assert len(net._epochs) == 1
        record = list(net._epochs.values())[0]
        assert record.node_name == "Producer"
        assert len(record.out_salvos) == 1  # One salvo sent

# %%
#|export
@pytest.mark.asyncio
async def test_epoch_record_lifecycle_timestamps():
    """Test EpochRecord lifecycle timestamps are set after execution."""
    def simple_node(ctx, packets):
        # Consume all input packets
        for port_name, pkt_ids in packets.items():
            for pid in pkt_ids:
                ctx.consume_packet(pid)
        ctx.print("running")

    graph_config = GraphConfig(
        nodes=[
            NodeConfig(
                name="Node",
                in_ports={"in": PortConfig()},
                execution_config=NodeExecutionConfig(
                    node_name="Node",
                    pools=["main"],
                    exec_node_func=simple_node,
                ),
            ),
        ],
        edges=[],
    )

    config = NetConfig(
        pools={"main": PoolConfig(spec=MainPoolConfig())},
        graph=graph_config,
    )

    async with Net(config) as net:
        net.inject_data("Node", "in", [1])
        await net.run_until_blocked()

        assert len(net._epochs) == 1
        record = list(net._epochs.values())[0]
        assert record.created_at is not None
        assert record.started_at is not None
        assert record.ended_at is not None
        assert record.started_at >= record.created_at
        assert record.ended_at >= record.started_at
        assert record.was_cancelled is False
        import netrun_sim
        assert record.state == netrun_sim.EpochState.Finished

# %%
#|export
@pytest.mark.asyncio
async def test_epoch_record_cancellation_lifecycle():
    """Test EpochRecord tracks cancellation."""
    def cancelling_node(ctx, packets):
        ctx.cancel_epoch()

    graph_config = GraphConfig(
        nodes=[
            NodeConfig(
                name="Canceller",
                in_ports={"in": PortConfig()},
                execution_config=NodeExecutionConfig(
                    node_name="Canceller",
                    pools=["main"],
                    exec_node_func=cancelling_node,
                ),
            ),
        ],
        edges=[],
    )

    config = NetConfig(
        pools={"main": PoolConfig(spec=MainPoolConfig())},
        graph=graph_config,
    )

    async with Net(config) as net:
        net.inject_data("Canceller", "in", [1])
        await net.run_until_blocked()

        assert len(net._epochs) == 1
        record = list(net._epochs.values())[0]
        assert record.was_cancelled is True
        assert record.ended_at is not None
        assert record.started_at is not None

# %% [markdown]
# ## Retry Behavior Tests

# %%
#|export
@pytest.mark.asyncio
async def test_retry_on_failure():
    """Test that node failures trigger retries."""
    attempt_count = [0]

    def failing_node(ctx, packets):
        attempt_count[0] += 1
        ctx.print(f"Attempt {attempt_count[0]}, retry_count={ctx.retry_count}")
        if attempt_count[0] < 3:
            raise ValueError(f"Failing on attempt {attempt_count[0]}")
        # Succeed on 3rd attempt
        ctx.print("Success!")

    graph_config = GraphConfig(
        nodes=[
            NodeConfig(
                name="FailingNode",
                in_ports={"in": PortConfig()},
                in_salvo_conditions={
                    "default": SalvoConditionConfig(
                        max_salvos=MaxSalvosFiniteConfig(max=1),
                        ports={"in": PacketCountAllConfig()},
                        term=SalvoConditionTermPortConfig(
                            port_name="in",
                            state=PortStateNonEmptyConfig(),
                        ),
                    ),
                },
                execution_config=NodeExecutionConfig(
                    node_name="FailingNode",
                    pools=["main"],
                    exec_node_func=failing_node,
                    retries=3,
                    retry_wait=0.0,  # No delay for tests
                ),
            ),
        ],
        edges=[],
    )

    config = NetConfig(
        pools={"main": PoolConfig(spec=MainPoolConfig())},
        graph=graph_config,
    )

    net = Net(config)
    # Verify retry config is extracted
    assert "FailingNode" in net._node_execution_configs
    assert net._node_execution_configs["FailingNode"].retries == 3

# %%
#|export
@pytest.mark.asyncio
async def test_dead_letter_queue_after_max_retries():
    """Test that failed epochs go to dead letter queue after max retries."""
    def always_fails(ctx, packets):
        raise ValueError("Always fails")

    graph_config = GraphConfig(
        nodes=[
            NodeConfig(
                name="AlwaysFails",
                in_ports={"in": PortConfig()},
                in_salvo_conditions={
                    "default": SalvoConditionConfig(
                        max_salvos=MaxSalvosFiniteConfig(max=1),
                        ports={"in": PacketCountAllConfig()},
                        term=SalvoConditionTermPortConfig(
                            port_name="in",
                            state=PortStateNonEmptyConfig(),
                        ),
                    ),
                },
                execution_config=NodeExecutionConfig(
                    node_name="AlwaysFails",
                    pools=["main"],
                    exec_node_func=always_fails,
                    retries=2,
                    retry_wait=0.0,
                ),
            ),
        ],
        edges=[],
    )

    config = NetConfig(
        pools={"main": PoolConfig(spec=MainPoolConfig())},
        graph=graph_config,
    )

    net = Net(config)
    # Verify config
    assert net._node_execution_configs["AlwaysFails"].retries == 2
    # Dead letter queue starts empty
    assert len(net.dead_letter_queue) == 0

# %%
#|export
@pytest.mark.asyncio
async def test_on_node_failure_callback():
    """Test on_node_failure callback is called on failure."""
    failure_log = []

    def failure_callback(failure_ctx):
        failure_log.append({
            "epoch_id": failure_ctx.epoch_id,
            "node_name": failure_ctx.node_name,
            "retry_count": failure_ctx.retry_count,
            "exception": str(failure_ctx.exception),
        })

    def failing_node(ctx, packets):
        raise ValueError("Test failure")

    graph_config = GraphConfig(
        nodes=[
            NodeConfig(
                name="CallbackNode",
                in_ports={"in": PortConfig()},
                in_salvo_conditions={
                    "default": SalvoConditionConfig(
                        max_salvos=MaxSalvosFiniteConfig(max=1),
                        ports={"in": PacketCountAllConfig()},
                        term=SalvoConditionTermPortConfig(
                            port_name="in",
                            state=PortStateNonEmptyConfig(),
                        ),
                    ),
                },
                execution_config=NodeExecutionConfig(
                    node_name="CallbackNode",
                    pools=["main"],
                    exec_node_func=failing_node,
                    retries=1,
                    retry_wait=0.0,
                    on_node_failure=failure_callback,
                ),
            ),
        ],
        edges=[],
    )

    config = NetConfig(
        pools={"main": PoolConfig(spec=MainPoolConfig())},
        graph=graph_config,
    )

    net = Net(config)
    # Verify callback is stored
    assert net._node_execution_configs["CallbackNode"].on_node_failure is failure_callback

# %%
#|export
def test_node_execution_result_with_exception():
    """Test NodeExecutionResult correctly stores exception."""
    exc = ValueError("test error")
    result = NodeExecutionResult(
        cancelled=False,
        deferred_actions=DeferredActionQueue(),
        print_buffer=[],
        created_packets=[],
        consumed_packets=[],
        func_result=None,
        exception=exc,
    )

    assert result.exception is exc
    assert result.func_result is None
    assert not result.cancelled

# %%
test_node_execution_result_with_exception()

# %%
#|export
def test_node_execution_result_with_func_result():
    """Test NodeExecutionResult correctly stores function result."""
    result = NodeExecutionResult(
        cancelled=False,
        deferred_actions=DeferredActionQueue(),
        print_buffer=[],
        created_packets=["pkt1"],
        consumed_packets=["pkt2"],
        func_result={"output": "data"},
        exception=None,
    )

    assert result.func_result == {"output": "data"}
    assert result.exception is None
    assert result.created_packets == ["pkt1"]
    assert result.consumed_packets == ["pkt2"]

# %%
test_node_execution_result_with_func_result()

# %%
#|export
def test_preprocessor_handles_cancel_epoch():
    """Test preprocessor handles EpochCancelled correctly."""
    node_configs = {
        "CancelNode": NodeExecutionConfig()
    }
    preprocessor = create_net_func_preprocessor(node_configs)

    def cancelling_func(ctx, packets):
        ctx.print("Before cancel")
        ctx.cancel_epoch()
        ctx.print("After cancel")  # Should not execute

    wrapped = preprocessor(cancelling_func)

    result = wrapped(
        epoch_id="cancel_test",
        node_name="CancelNode",
        packets={},
        packet_values={},
    )

    assert result.cancelled is True
    assert result.exception is None  # EpochCancelled is expected, not an error
    assert len(result.print_buffer) == 1
    assert "Before cancel" in result.print_buffer[0][1]

# %%
test_preprocessor_handles_cancel_epoch()

# %%
#|export
def test_deferred_actions_preserved_in_result():
    """Test that deferred actions are preserved in execution result."""
    node_configs = {
        "ActionNode": NodeExecutionConfig()
    }
    preprocessor = create_net_func_preprocessor(node_configs)

    def action_func(ctx, packets):
        # Create some packets
        id1 = ctx.create_packet("value1")
        id2 = ctx.create_packet("value2")
        # Load and send
        ctx.load_output_port("out", id1)
        ctx.send_output_salvo("send")
        return "done"

    wrapped = preprocessor(action_func)

    result = wrapped(
        epoch_id="action_test",
        node_name="ActionNode",
        packets={},
        packet_values={},
    )

    assert result.func_result == "done"
    assert len(result.created_packets) == 2
    assert len(result.deferred_actions.actions) == 4  # 2 creates + load + send

# %% [markdown]
# ## Node Variables Tests

# %%
#|export
def test_ctx_vars_access():
    """Test ctx.vars returns resolved variable values."""
    ctx = NodeExecutionContext(
        epoch_id="epoch_vars",
        node_name="VarsNode",
        _node_vars={
            "name": NodeVariable(value="test", type="str"),
            "count": NodeVariable(value="42", type="int"),
            "rate": NodeVariable(value="3.14", type="float"),
            "debug": NodeVariable(value="true", type="bool"),
            "config": NodeVariable(value='{"key": "val"}', type="json"),
        },
    )

    v = ctx.vars
    assert v["name"] == "test"
    assert v["count"] == 42
    assert v["rate"] == 3.14
    assert v["debug"] is True
    assert v["config"] == {"key": "val"}

# %%
test_ctx_vars_access()

# %%
#|export
def test_ctx_vars_empty():
    """Test ctx.vars returns empty dict when no vars set."""
    ctx = NodeExecutionContext(
        epoch_id="epoch_empty_vars",
        node_name="EmptyVarsNode",
    )

    assert ctx.vars == {}
    assert isinstance(ctx.vars, dict)

# %%
test_ctx_vars_empty()

# %%
#|export
def test_ctx_vars_merging():
    """Test that node-level vars override net-level vars via preprocessor."""
    node_configs = {
        "MergeNode": NodeExecutionConfig(
            node_vars={
                "override_me": NodeVariable(value="node_value", type="str"),
                "node_only": NodeVariable(value="42", type="int"),
            }
        )
    }

    net_vars = {
        "override_me": NodeVariable(value="net_value", type="str"),
        "net_only": NodeVariable(value="true", type="bool"),
    }

    preprocessor = create_net_func_preprocessor(
        node_configs,
        net_node_vars=net_vars,
    )

    captured_ctx = None

    def test_func(ctx, packets):
        nonlocal captured_ctx
        captured_ctx = ctx
        return "ok"

    wrapped = preprocessor(test_func)

    result = wrapped(
        epoch_id="merge_test",
        node_name="MergeNode",
        packets={},
        packet_values={},
    )

    assert result.func_result == "ok"
    v = captured_ctx.vars
    # Node-level overrides net-level
    assert v["override_me"] == "node_value"
    # Node-only var
    assert v["node_only"] == 42
    # Net-only var
    assert v["net_only"] is True

# %%
test_ctx_vars_merging()

# %% [markdown]
# ## Net.from_file Tests

# %%
#|export
def test_net_from_file_json(tmp_path):
    """Test Net.from_file loads a Net from a JSON config file."""
    import json
    from pathlib import Path

    config_data = {
        "pools": {
            "main_pool": {"spec": {"type": "main"}},
        },
        "graph": {
            "nodes": [{"name": "Node1"}],
        },
    }

    config_file = tmp_path / "test_config.json"
    config_file.write_text(json.dumps(config_data))

    net = Net.from_file(config_file)

    assert isinstance(net, Net)
    assert net.config is not None
    assert net.started is False

# %%
#|export
def test_net_from_file_not_found():
    """Test Net.from_file raises FileNotFoundError for missing file."""
    with pytest.raises(FileNotFoundError):
        Net.from_file("/nonexistent/path/config.json")

# %%
test_net_from_file_not_found()

# %%
#|export
def test_net_from_file_unsupported_format(tmp_path):
    """Test Net.from_file raises ValueError for unsupported format."""
    bad_file = tmp_path / "config.yaml"
    bad_file.write_text("key: value")

    with pytest.raises(ValueError, match="Unsupported"):
        Net.from_file(bad_file)

# %% [markdown]
# ## NodeInfo and EdgeInfo Tests

# %%
#|export
def test_net_nodes_property():
    """Test Net.nodes returns dict of NodeInfo objects."""
    config = NetConfig(
        pools={},
        graph=GraphConfig(
            nodes=[
                NodeConfig(name="Source", in_ports={"in": PortConfig()}, out_ports={"out": PortConfig()}),
                NodeConfig(name="Sink", in_ports={"in": PortConfig()}),
            ],
            edges=[EdgeConfig(source_str="Source.out", target_str="Sink.in")],
        ),
    )
    net = Net(config)

    nodes = net.nodes
    assert isinstance(nodes, dict)
    assert "Source" in nodes
    assert "Sink" in nodes
    assert isinstance(nodes["Source"], NodeInfo)
    assert isinstance(nodes["Sink"], NodeInfo)

# %%
test_net_nodes_property()

# %%
#|export
def test_net_edges_property():
    """Test Net.edges returns list of EdgeInfo objects."""
    config = NetConfig(
        pools={},
        graph=GraphConfig(
            nodes=[
                NodeConfig(name="Source", out_ports={"out": PortConfig()}),
                NodeConfig(name="Sink", in_ports={"in": PortConfig()}),
            ],
            edges=[EdgeConfig(source_str="Source.out", target_str="Sink.in")],
        ),
    )
    net = Net(config)

    edges = net.edges
    assert isinstance(edges, list)
    assert len(edges) == 1
    assert isinstance(edges[0], EdgeInfo)

# %%
test_net_edges_property()

# %%
#|export
def test_node_info_name_and_cfg():
    """Test NodeInfo.name and NodeInfo.cfg properties."""
    config = NetConfig(
        pools={},
        graph=GraphConfig(
            nodes=[NodeConfig(name="TestNode", in_ports={"in": PortConfig()}, out_ports={"out": PortConfig()})],
        ),
    )
    net = Net(config)

    node_info = net.nodes["TestNode"]
    assert node_info.name == "TestNode"

    cfg = node_info.cfg
    assert cfg.name == "TestNode"
    assert "in" in cfg.in_ports
    assert "out" in cfg.out_ports

# %%
test_node_info_name_and_cfg()

# %%
#|export
def test_node_info_port_names():
    """Test NodeInfo.in_port_names and out_port_names."""
    config = NetConfig(
        pools={},
        graph=GraphConfig(
            nodes=[NodeConfig(
                name="TestNode",
                in_ports={"input1": PortConfig(), "input2": PortConfig()},
                out_ports={"output1": PortConfig()},
            )],
        ),
    )
    net = Net(config)

    node_info = net.nodes["TestNode"]
    assert set(node_info.in_port_names) == {"input1", "input2"}
    assert node_info.out_port_names == ["output1"]

# %%
test_node_info_port_names()

# %%
#|export
def test_node_info_epoch_properties_empty():
    """Test NodeInfo epoch properties when no epochs exist."""
    config = NetConfig(
        pools={},
        graph=GraphConfig(nodes=[NodeConfig(name="TestNode", in_ports={"in": PortConfig()})]),
    )
    net = Net(config)

    node_info = net.nodes["TestNode"]
    assert node_info.epochs == []
    assert node_info.running_epochs == []
    assert node_info.startable_epochs == []
    assert node_info.epoch_count == 0
    assert node_info.is_busy is False

# %%
test_node_info_epoch_properties_empty()

# %%
#|export
@pytest.mark.asyncio
async def test_node_info_inject_packets():
    """Test NodeInfo.inject_packets injects packets into input port."""
    config = NetConfig(
        pools={},
        graph=GraphConfig(nodes=[NodeConfig(name="TestNode", in_ports={"in": PortConfig()})]),
    )
    net = Net(config)

    node_info = net.nodes["TestNode"]
    packet_ids = node_info.inject_packets("in", [1, 2, 3])

    assert len(packet_ids) == 3
    # Run step to trigger salvo (without auto-starting epochs)
    await net.run_step(auto_start_epochs=False)
    # Packets should be in a startable epoch now
    assert len(node_info.startable_epochs) == 1

# %%
asyncio.get_event_loop().run_until_complete(test_node_info_inject_packets())

# %%
#|export
@pytest.mark.asyncio
async def test_node_info_packets_at_input_port():
    """Test NodeInfo.packets_at_input_port returns packets waiting at port."""
    config = NetConfig(
        pools={},
        graph=GraphConfig(nodes=[NodeConfig(name="TestNode", in_ports={"in": PortConfig()})]),
    )
    net = Net(config)

    node_info = net.nodes["TestNode"]
    # Inject packets
    node_info.inject_packets("in", [1, 2])

    # Check packets at port before run_step
    packets = node_info.packets_at_input_port("in")
    assert len(packets) == 2

    # After run_step (without auto-starting epochs), packets move into epoch
    await net.run_step(auto_start_epochs=False)
    packets = node_info.packets_at_input_port("in")
    assert len(packets) == 0

# %%
asyncio.get_event_loop().run_until_complete(test_node_info_packets_at_input_port())

# %%
#|export
@pytest.mark.asyncio
async def test_node_info_packets_at_all_input_ports():
    """Test NodeInfo.packets_at_all_input_ports returns dict of all ports."""
    config = NetConfig(
        pools={},
        graph=GraphConfig(nodes=[NodeConfig(
            name="TestNode",
            in_ports={"in1": PortConfig(), "in2": PortConfig()},
        )]),
    )
    net = Net(config)

    node_info = net.nodes["TestNode"]
    node_info.inject_packets("in1", [1])
    node_info.inject_packets("in2", [2, 3])

    all_packets = node_info.packets_at_all_input_ports()
    assert len(all_packets["in1"]) == 1
    assert len(all_packets["in2"]) == 2

# %%
asyncio.get_event_loop().run_until_complete(test_node_info_packets_at_all_input_ports())

# %%
#|export
@pytest.mark.asyncio
async def test_node_info_packets_in_epoch():
    """Test NodeInfo.packets_in_epoch returns packets inside an epoch."""
    config = NetConfig(
        pools={},
        graph=GraphConfig(nodes=[NodeConfig(name="TestNode", in_ports={"in": PortConfig()})]),
    )
    net = Net(config)

    node_info = net.nodes["TestNode"]
    node_info.inject_packets("in", [1, 2, 3])

    # Trigger salvo (without auto-starting epochs)
    await net.run_step(auto_start_epochs=False)

    # Get the startable epoch
    epochs = node_info.startable_epochs
    assert len(epochs) == 1

    # Check packets in epoch
    packets = node_info.packets_in_epoch(epochs[0].id)
    assert len(packets) == 3

# %%
asyncio.get_event_loop().run_until_complete(test_node_info_packets_in_epoch())

# %%
#|export
def test_node_info_incoming_outgoing_edges():
    """Test NodeInfo.incoming_edges and outgoing_edges."""
    config = NetConfig(
        pools={},
        graph=GraphConfig(
            nodes=[
                NodeConfig(name="Source", out_ports={"out": PortConfig()}),
                NodeConfig(name="Middle", in_ports={"in": PortConfig()}, out_ports={"out": PortConfig()}),
                NodeConfig(name="Sink", in_ports={"in": PortConfig()}),
            ],
            edges=[
                EdgeConfig(source_str="Source.out", target_str="Middle.in"),
                EdgeConfig(source_str="Middle.out", target_str="Sink.in"),
            ],
        ),
    )
    net = Net(config)

    source_info = net.nodes["Source"]
    middle_info = net.nodes["Middle"]
    sink_info = net.nodes["Sink"]

    assert len(source_info.incoming_edges) == 0
    assert len(source_info.outgoing_edges) == 1

    assert len(middle_info.incoming_edges) == 1
    assert len(middle_info.outgoing_edges) == 1

    assert len(sink_info.incoming_edges) == 1
    assert len(sink_info.outgoing_edges) == 0

# %%
test_node_info_incoming_outgoing_edges()

# %%
#|export
def test_node_info_execution_config():
    """Test NodeInfo.execution_config and pools properties."""
    config = NetConfig(
        pools={"main_pool": PoolConfig(id="main_pool", spec=MainPoolConfig())},
        graph=GraphConfig(
            nodes=[
                NodeConfig(
                    name="WithExec",
                    execution_config=NodeExecutionConfig(pools=["main_pool"]),
                ),
                NodeConfig(name="WithoutExec"),
            ],
        ),
    )
    net = Net(config)

    with_exec = net.nodes["WithExec"]
    without_exec = net.nodes["WithoutExec"]

    assert with_exec.execution_config is not None
    assert with_exec.pools == ["main_pool"]

    assert without_exec.execution_config is None
    assert without_exec.pools == []

# %%
test_node_info_execution_config()

# %%
#|export
def test_edge_info_properties():
    """Test EdgeInfo source/target properties."""
    config = NetConfig(
        pools={},
        graph=GraphConfig(
            nodes=[
                NodeConfig(name="Source", out_ports={"out": PortConfig()}),
                NodeConfig(name="Sink", in_ports={"in": PortConfig()}),
            ],
            edges=[EdgeConfig(source_str="Source.out", target_str="Sink.in")],
        ),
    )
    net = Net(config)

    edge_info = net.edges[0]
    assert edge_info.source_node == "Source"
    assert edge_info.source_port == "out"
    assert edge_info.target_node == "Sink"
    assert edge_info.target_port == "in"
    assert edge_info.source == ("Source", "out")
    assert edge_info.target == ("Sink", "in")

# %%
test_edge_info_properties()

# %%
#|export
def test_edge_info_cfg():
    """Test EdgeInfo.cfg returns edge configuration."""
    config = NetConfig(
        pools={},
        graph=GraphConfig(
            nodes=[
                NodeConfig(name="Source", out_ports={"out": PortConfig()}),
                NodeConfig(name="Sink", in_ports={"in": PortConfig()}),
            ],
            edges=[EdgeConfig(source_str="Source.out", target_str="Sink.in")],
        ),
    )
    net = Net(config)

    edge_info = net.edges[0]
    cfg = edge_info.cfg

    assert cfg.get_source().node_name == "Source"
    assert cfg.get_source().port_name == "out"
    assert cfg.get_target().node_name == "Sink"
    assert cfg.get_target().port_name == "in"

# %%
test_edge_info_cfg()

# %%
#|export
def test_edge_info_packet_tracking_empty():
    """Test EdgeInfo packet properties when no packets on edge."""
    config = NetConfig(
        pools={},
        graph=GraphConfig(
            nodes=[
                NodeConfig(name="Source", out_ports={"out": PortConfig()}),
                NodeConfig(name="Sink", in_ports={"in": PortConfig()}),
            ],
            edges=[EdgeConfig(source_str="Source.out", target_str="Sink.in")],
        ),
    )
    net = Net(config)

    edge_info = net.edges[0]
    assert edge_info.has_packets is False
    assert edge_info.packet_count == 0
    assert edge_info.packets_in_transit == []

# %%
test_edge_info_packet_tracking_empty()

# %%
#|export
def test_edge_info_packet_tracking_with_packets():
    """Test EdgeInfo packet tracking when packets are on edge."""
    import netrun_sim

    config = NetConfig(
        pools={},
        graph=GraphConfig(
            nodes=[
                NodeConfig(name="Source", out_ports={"out": PortConfig()}),
                NodeConfig(name="Sink", in_ports={"in": PortConfig()}),
            ],
            edges=[EdgeConfig(source_str="Source.out", target_str="Sink.in")],
        ),
    )
    net = Net(config)

    # Create packet and place on edge
    packet_id = net.create_external_packet({"value": 42})
    edge_obj = list(net.graph.edges())[0]
    net._netsim.do_action(netrun_sim.NetAction.transport_packet_to_location(
        packet_id,
        netrun_sim.PacketLocation.edge(edge_obj),
    ))

    edge_info = net.edges[0]
    assert edge_info.has_packets is True
    assert edge_info.packet_count == 1
    assert len(edge_info.packets_in_transit) == 1
    assert edge_info.packets_in_transit[0].id == packet_id

# %%
test_edge_info_packet_tracking_with_packets()

# %%
#|export
def test_edge_info_node_info_methods():
    """Test EdgeInfo.source_node_info and target_node_info methods."""
    config = NetConfig(
        pools={},
        graph=GraphConfig(
            nodes=[
                NodeConfig(name="Source", out_ports={"out": PortConfig()}),
                NodeConfig(name="Sink", in_ports={"in": PortConfig()}),
            ],
            edges=[EdgeConfig(source_str="Source.out", target_str="Sink.in")],
        ),
    )
    net = Net(config)

    edge_info = net.edges[0]

    source_info = edge_info.source_node_info()
    assert isinstance(source_info, NodeInfo)
    assert source_info.name == "Source"

    target_info = edge_info.target_node_info()
    assert isinstance(target_info, NodeInfo)
    assert target_info.name == "Sink"

# %%
test_edge_info_node_info_methods()

# %%
#|export
def test_node_info_repr():
    """Test NodeInfo.__repr__ returns meaningful string."""
    config = NetConfig(
        pools={},
        graph=GraphConfig(nodes=[NodeConfig(name="TestNode")]),
    )
    net = Net(config)

    node_info = net.nodes["TestNode"]
    assert "TestNode" in repr(node_info)
    assert "NodeInfo" in repr(node_info)

# %%
test_node_info_repr()

# %%
#|export
def test_edge_info_repr():
    """Test EdgeInfo.__repr__ returns meaningful string."""
    config = NetConfig(
        pools={},
        graph=GraphConfig(
            nodes=[
                NodeConfig(name="Source", out_ports={"out": PortConfig()}),
                NodeConfig(name="Sink", in_ports={"in": PortConfig()}),
            ],
            edges=[EdgeConfig(source_str="Source.out", target_str="Sink.in")],
        ),
    )
    net = Net(config)

    edge_info = net.edges[0]
    repr_str = repr(edge_info)
    assert "Source" in repr_str
    assert "Sink" in repr_str
    assert "EdgeInfo" in repr_str

# %%
test_edge_info_repr()

# %%
#|export
def test_node_info_inject():
    """Test NodeInfo.inject injects packets to multiple ports with plural=True."""
    config = NetConfig(
        pools={},
        graph=GraphConfig(nodes=[NodeConfig(
            name="TestNode",
            in_ports={"in1": PortConfig(), "in2": PortConfig()},
        )]),
    )
    net = Net(config)

    node_info = net.nodes["TestNode"]
    result = node_info.inject({
        "in1": [1, 2, 3],
        "in2": ["a", "b"],
    }, plural=True)

    # Check return value
    assert "in1" in result
    assert "in2" in result
    assert len(result["in1"]) == 3
    assert len(result["in2"]) == 2

    # Verify packets are at ports
    assert len(node_info.packets_at_input_port("in1")) == 3
    assert len(node_info.packets_at_input_port("in2")) == 2

# %%
test_node_info_inject()

# %%
#|export
def test_node_info_inject_packet_single():
    """Test NodeInfo.inject_packet returns single packet ID."""
    config = NetConfig(
        pools={},
        graph=GraphConfig(nodes=[NodeConfig(name="TestNode", in_ports={"in": PortConfig()})]),
    )
    net = Net(config)

    node_info = net.nodes["TestNode"]
    packet_id = node_info.inject_packet("in", {"value": 42})

    # Should return a string, not a list
    assert isinstance(packet_id, str)
    assert len(node_info.packets_at_input_port("in")) == 1

# %%
test_node_info_inject_packet_single()

# %%
#|export
def test_node_info_inject_default():
    """Test NodeInfo.inject default (plural=False) treats each value as single packet."""
    config = NetConfig(
        pools={},
        graph=GraphConfig(nodes=[NodeConfig(
            name="TestNode",
            in_ports={"in1": PortConfig(), "in2": PortConfig()},
        )]),
    )
    net = Net(config)

    node_info = net.nodes["TestNode"]
    result = node_info.inject({
        "in1": [1, 2, 3],  # This list becomes a single packet value
        "in2": "hello",    # Single string value
    })  # plural=False is default

    # Each port should have exactly 1 packet
    assert len(result["in1"]) == 1
    assert len(result["in2"]) == 1
    assert len(node_info.packets_at_input_port("in1")) == 1
    assert len(node_info.packets_at_input_port("in2")) == 1

# %%
test_node_info_inject_default()

# %%
#|export
def test_node_info_inject_plural_true_requires_list():
    """Test NodeInfo.inject with plural=True requires list values."""
    config = NetConfig(
        pools={},
        graph=GraphConfig(nodes=[NodeConfig(name="TestNode", in_ports={"in": PortConfig()})]),
    )
    net = Net(config)

    node_info = net.nodes["TestNode"]
    with pytest.raises(ValueError, match="must be a list"):
        node_info.inject({"in": "not a list"}, plural=True)

# %%
test_node_info_inject_plural_true_requires_list()

# %% [markdown]
# ## Exception Propagation Tests

# %%
#|export
@pytest.mark.asyncio
async def test_propagate_exceptions_true_raises():
    """Test that run_until_blocked raises EpochError when propagate_exceptions=True (default)."""
    def failing_node(ctx, packets):
        for port_name, pkt_ids in packets.items():
            for pid in pkt_ids:
                ctx.consume_packet(pid)
        raise ValueError("node failure")

    graph_config = GraphConfig(
        nodes=[
            NodeConfig(
                name="FailNode",
                in_ports={"in": PortConfig()},
                execution_config=NodeExecutionConfig(
                    pools=["main"],
                    exec_node_func=failing_node,
                ),
            ),
        ],
        edges=[],
    )

    config = NetConfig(
        pools={"main": PoolConfig(spec=MainPoolConfig())},
        graph=graph_config,
        # propagate_exceptions=True is the default
    )

    async with Net(config) as net:
        net.inject_data("FailNode", "in", [1])
        with pytest.raises(EpochError) as exc_info:
            await net.run_until_blocked()
        assert exc_info.value.node_name == "FailNode"
        assert isinstance(exc_info.value.__cause__, ValueError)
        assert "node failure" in str(exc_info.value.__cause__)

# %%
#|export
@pytest.mark.asyncio
async def test_propagate_exceptions_false_queues():
    """Test that run_until_blocked succeeds when propagate_exceptions=False, and EpochError is queued."""
    def failing_node(ctx, packets):
        for port_name, pkt_ids in packets.items():
            for pid in pkt_ids:
                ctx.consume_packet(pid)
        raise ValueError("queued failure")

    graph_config = GraphConfig(
        nodes=[
            NodeConfig(
                name="FailNode",
                in_ports={"in": PortConfig()},
                execution_config=NodeExecutionConfig(
                    pools=["main"],
                    exec_node_func=failing_node,
                ),
            ),
        ],
        edges=[],
    )

    config = NetConfig(
        pools={"main": PoolConfig(spec=MainPoolConfig())},
        graph=graph_config,
        propagate_exceptions=False,
    )

    async with Net(config) as net:
        net.inject_data("FailNode", "in", [1])
        # Should NOT raise
        await net.run_until_blocked()

        # Exception should be queued as EpochError
        assert len(net.exception_queue) == 1
        assert isinstance(net.exception_queue[0], EpochError)
        assert net.exception_queue[0].node_name == "FailNode"
        assert isinstance(net.exception_queue[0].__cause__, ValueError)
        assert "queued failure" in str(net.exception_queue[0].__cause__)

        # propagate_exceptions() should raise the EpochError
        with pytest.raises(EpochError) as exc_info:
            net.propagate_exceptions()
        assert isinstance(exc_info.value.__cause__, ValueError)

        # Queue should now be empty
        assert len(net.exception_queue) == 0

# %%
#|export
@pytest.mark.asyncio
async def test_print_exceptions_true_prints_to_stderr(capsys):
    """Test that print_exceptions=True prints to stderr with pool/worker info."""
    def failing_node(ctx, packets):
        for port_name, pkt_ids in packets.items():
            for pid in pkt_ids:
                ctx.consume_packet(pid)
        raise ValueError("stderr failure")

    graph_config = GraphConfig(
        nodes=[
            NodeConfig(
                name="FailNode",
                in_ports={"in": PortConfig()},
                execution_config=NodeExecutionConfig(
                    pools=["main"],
                    exec_node_func=failing_node,
                ),
            ),
        ],
        edges=[],
    )

    config = NetConfig(
        pools={"main": PoolConfig(spec=MainPoolConfig())},
        graph=graph_config,
        propagate_exceptions=False,
        print_exceptions=True,
    )

    async with Net(config) as net:
        net.inject_data("FailNode", "in", [1])
        await net.run_until_blocked()

        captured = capsys.readouterr()
        assert "stderr failure" in captured.err
        assert "FailNode" in captured.err
        assert "pool='main'" in captured.err

# %%
#|export
@pytest.mark.asyncio
async def test_node_level_override_propagate():
    """Test per-node override of propagate_exceptions."""
    def failing_node(ctx, packets):
        for port_name, pkt_ids in packets.items():
            for pid in pkt_ids:
                ctx.consume_packet(pid)
        raise ValueError(f"{ctx.node_name} failed")

    graph_config = GraphConfig(
        nodes=[
            NodeConfig(
                name="PropagatingNode",
                in_ports={"in": PortConfig()},
                execution_config=NodeExecutionConfig(
                    pools=["main"],
                    exec_node_func=failing_node,
                    # propagate_exceptions=None -> inherits True from NetConfig
                ),
            ),
            NodeConfig(
                name="QueuingNode",
                in_ports={"in": PortConfig()},
                execution_config=NodeExecutionConfig(
                    pools=["main"],
                    exec_node_func=failing_node,
                    propagate_exceptions=False,  # Override: queue instead
                ),
            ),
        ],
        edges=[],
    )

    config = NetConfig(
        pools={"main": PoolConfig(spec=MainPoolConfig())},
        graph=graph_config,
        propagate_exceptions=True,  # Global default
    )

    # Test QueuingNode: should queue, not raise
    async with Net(config) as net:
        net.inject_data("QueuingNode", "in", [1])
        await net.run_until_blocked()  # Should not raise
        assert len(net.exception_queue) == 1
        assert isinstance(net.exception_queue[0], EpochError)
        assert "QueuingNode failed" in str(net.exception_queue[0].__cause__)

    # Test PropagatingNode: should raise EpochError
    async with Net(config) as net:
        net.inject_data("PropagatingNode", "in", [1])
        with pytest.raises(EpochError) as exc_info:
            await net.run_until_blocked()
        assert exc_info.value.node_name == "PropagatingNode"
        assert isinstance(exc_info.value.__cause__, ValueError)
        assert "PropagatingNode failed" in str(exc_info.value.__cause__)

# %%
#|export
@pytest.mark.asyncio
async def test_node_level_override_print(capsys):
    """Test per-node override of print_exceptions."""
    def failing_node(ctx, packets):
        for port_name, pkt_ids in packets.items():
            for pid in pkt_ids:
                ctx.consume_packet(pid)
        raise ValueError(f"{ctx.node_name} failed")

    graph_config = GraphConfig(
        nodes=[
            NodeConfig(
                name="SilentNode",
                in_ports={"in": PortConfig()},
                execution_config=NodeExecutionConfig(
                    pools=["main"],
                    exec_node_func=failing_node,
                    # print_exceptions=None -> inherits False from NetConfig
                ),
            ),
            NodeConfig(
                name="PrintingNode",
                in_ports={"in": PortConfig()},
                execution_config=NodeExecutionConfig(
                    pools=["main"],
                    exec_node_func=failing_node,
                    print_exceptions=True,  # Override: print to stderr
                ),
            ),
        ],
        edges=[],
    )

    config = NetConfig(
        pools={"main": PoolConfig(spec=MainPoolConfig())},
        graph=graph_config,
        propagate_exceptions=False,  # Queue all so we can check stderr
        print_exceptions=False,  # Global default: don't print
    )

    async with Net(config) as net:
        net.inject_data("SilentNode", "in", [1])
        await net.run_until_blocked()

        captured = capsys.readouterr()
        # SilentNode should NOT print to stderr
        assert "SilentNode" not in captured.err

    async with Net(config) as net:
        net.inject_data("PrintingNode", "in", [1])
        await net.run_until_blocked()

        captured = capsys.readouterr()
        # PrintingNode SHOULD print to stderr
        assert "PrintingNode" in captured.err
        assert "PrintingNode failed" in captured.err

# %% [markdown]
# ## serve_pool and _PoolServerContext Tests

# %%
#|export
from netrun.net._net._net import _PoolServerContext, _ServerLogCallback
from netrun.net.config import RemotePoolConfig
from tests.net.workers import doubler_node, echo_node

# Port counter to avoid conflicts between tests
_serve_pool_test_port = 19500

def _get_next_serve_pool_port() -> int:
    global _serve_pool_test_port
    _serve_pool_test_port += 1
    return _serve_pool_test_port

# %%
#|export
def test_serve_pool_returns_pool_server_context():
    """Test that serve_pool returns a _PoolServerContext instance."""
    config = NetConfig(
        pools={"main": PoolConfig(spec=MainPoolConfig())},
        graph=GraphConfig(nodes=[], edges=[]),
    )
    ctx = Net.serve_pool(config, "127.0.0.1", 9999)
    assert isinstance(ctx, _PoolServerContext)
    assert ctx._host == "127.0.0.1"
    assert ctx._port == 9999
    assert ctx._server is not None

# %%
test_serve_pool_returns_pool_server_context()

# %%
#|export
def test_serve_pool_accepts_path(tmp_path):
    """Test that serve_pool accepts a file path string."""
    import json

    config_data = {
        "pools": {"main": {"spec": {"type": "main"}}},
        "graph": {"nodes": [], "edges": []},
    }
    config_file = tmp_path / "test_config.json"
    config_file.write_text(json.dumps(config_data))

    ctx = Net.serve_pool(str(config_file), "127.0.0.1", 9999)
    assert isinstance(ctx, _PoolServerContext)

# %%
#|export
def test_serve_pool_accepts_pathlib_path(tmp_path):
    """Test that serve_pool accepts a pathlib.Path."""
    import json
    from pathlib import Path

    config_data = {
        "pools": {"main": {"spec": {"type": "main"}}},
        "graph": {"nodes": [], "edges": []},
    }
    config_file = tmp_path / "test_config.json"
    config_file.write_text(json.dumps(config_data))

    ctx = Net.serve_pool(config_file, "127.0.0.1", 9999)
    assert isinstance(ctx, _PoolServerContext)

# %%
#|export
def test_serve_pool_custom_worker_name():
    """Test that serve_pool passes custom worker_name to the server."""
    config = NetConfig(
        pools={"main": PoolConfig(spec=MainPoolConfig())},
        graph=GraphConfig(nodes=[], edges=[]),
    )
    ctx = Net.serve_pool(config, "127.0.0.1", 9999, worker_name="custom_worker")
    assert isinstance(ctx, _PoolServerContext)

# %%
test_serve_pool_custom_worker_name()

# %%
#|export
def test_serve_pool_no_log_file():
    """Test that serve_pool without log_file does not create a done callback."""
    config = NetConfig(
        pools={"main": PoolConfig(spec=MainPoolConfig())},
        graph=GraphConfig(nodes=[], edges=[]),
    )
    ctx = Net.serve_pool(config, "127.0.0.1", 9999)
    assert ctx._log_file is None
    assert ctx._log_fh is None

# %%
test_serve_pool_no_log_file()

# %%
#|export
def test_serve_pool_with_log_file(tmp_path):
    """Test that serve_pool with log_file configures logging."""
    log_file = tmp_path / "server.log"
    config = NetConfig(
        pools={"main": PoolConfig(spec=MainPoolConfig())},
        graph=GraphConfig(nodes=[], edges=[]),
    )
    ctx = Net.serve_pool(config, "127.0.0.1", 9999, log_file=str(log_file))
    assert ctx._log_file == str(log_file)
    # File handle not opened until __aenter__
    assert ctx._log_fh is None

# %%
#|export
@pytest.mark.asyncio
async def test_serve_pool_starts_and_stops_server():
    """Test that serve_pool context manager starts and stops a working server."""
    port = _get_next_serve_pool_port()
    config = NetConfig(
        pools={"main": PoolConfig(spec=MainPoolConfig())},
        graph=GraphConfig(nodes=[], edges=[]),
    )

    async with Net.serve_pool(config, "127.0.0.1", port):
        # Server should be running - verify by connecting a client
        from netrun.pool.remote import RemotePoolClient
        client = RemotePoolClient(
            url=f"ws://127.0.0.1:{port}",
            worker_name="execution_manager",
            num_processes=1,
            threads_per_process=1,
        )
        await client.connect()
        await client.create_pool("execution_manager", num_processes=1, threads_per_process=1)
        await client.close()

    # After exiting context, server should be stopped

# %%
#|export
@pytest.mark.asyncio
async def test_serve_pool_log_file_writes(tmp_path):
    """Test that serve_pool writes start/stop messages to log file."""
    log_file = tmp_path / "server.log"
    port = _get_next_serve_pool_port()
    config = NetConfig(
        pools={"main": PoolConfig(spec=MainPoolConfig())},
        graph=GraphConfig(nodes=[], edges=[]),
    )

    async with Net.serve_pool(config, "127.0.0.1", port, log_file=str(log_file)):
        # Log file should exist and contain "started" message
        content = log_file.read_text()
        assert "Pool server started" in content
        assert f"127.0.0.1:{port}" in content

    # After exit, should also contain "stopped" message
    content = log_file.read_text()
    assert "Pool server stopped" in content

# %%
#|export
@pytest.mark.asyncio
async def test_serve_pool_end_to_end_with_net():
    """Test serve_pool with a Net that has a remote pool — full integration.

    Uses doubler_node from the workers module (importable, picklable for remote).
    """
    port = _get_next_serve_pool_port()

    graph_config = GraphConfig(
        nodes=[
            NodeConfig(
                name="Doubler",
                in_ports={"in": PortConfig()},
                out_ports={"out": PortConfig()},
                in_salvo_conditions={
                    "default": SalvoConditionConfig(
                        max_salvos=MaxSalvosFiniteConfig(max=1),
                        ports={"in": PacketCountAllConfig()},
                        term=SalvoConditionTermPortConfig(
                            port_name="in",
                            state=PortStateNonEmptyConfig(),
                        ),
                    ),
                },
                out_salvo_conditions={
                    "send": SalvoConditionConfig(
                        max_salvos=MaxSalvosFiniteConfig(max=1),
                        ports={"out": PacketCountAllConfig()},
                        term=SalvoConditionTermTrueConfig(),
                    ),
                },
                execution_config=NodeExecutionConfig(
                    pools=["remote"],
                    exec_node_func=doubler_node,
                ),
            ),
        ],
        edges=[],
    )

    server_config = NetConfig(
        pools={"main": PoolConfig(spec=MainPoolConfig())},
        graph=graph_config,
    )

    net_config = NetConfig(
        pools={
            "remote": PoolConfig(
                spec=RemotePoolConfig(
                    url=f"ws://127.0.0.1:{port}",
                    worker_name="execution_manager",
                    num_processes=1,
                    threads_per_process=1,
                ),
            ),
        },
        graph=graph_config,
    )

    async with Net.serve_pool(server_config, "127.0.0.1", port):
        async with Net(net_config) as net:
            net.inject_data("Doubler", "in", [5])
            await net.run_until_blocked()

            outputs = net.flush_all_output_queues()
            # Doubler sends 5 * 2 = 10 to unconnected "out" port -> output queue
            values = []
            for queue_vals in outputs.values():
                values.extend(queue_vals)
            assert 10 in values

# %%
#|export
def test_create_func_preprocessor_from_config():
    """Test _create_func_preprocessor_from_config returns a callable preprocessor."""
    def dummy_exec(ctx):
        pass

    config = NetConfig(
        pools={"main": PoolConfig(spec=MainPoolConfig())},
        graph=GraphConfig(
            nodes=[
                NodeConfig(
                    name="TestNode",
                    in_ports={"in": PortConfig()},
                    out_ports={"out": PortConfig()},
                    in_salvo_conditions={
                        "default": SalvoConditionConfig(
                            max_salvos=MaxSalvosFiniteConfig(max=1),
                            ports={"in": PacketCountAllConfig()},
                            term=SalvoConditionTermPortConfig(
                                port_name="in",
                                state=PortStateNonEmptyConfig(),
                            ),
                        ),
                    },
                    execution_config=NodeExecutionConfig(
                        pools=["main"],
                        exec_node_func=dummy_exec,
                    ),
                ),
            ],
            edges=[],
        ),
    )
    config_resolved = config.resolve()
    preprocessor = Net._create_func_preprocessor_from_config(config_resolved)
    assert callable(preprocessor)

# %%
test_create_func_preprocessor_from_config()

# %%
#|export
def test_create_func_preprocessor_from_config_empty():
    """Test _create_func_preprocessor_from_config with empty graph."""
    config = NetConfig(
        pools={"main": PoolConfig(spec=MainPoolConfig())},
        graph=GraphConfig(nodes=[], edges=[]),
    )
    config_resolved = config.resolve()
    preprocessor = Net._create_func_preprocessor_from_config(config_resolved)
    assert callable(preprocessor)

# %%
test_create_func_preprocessor_from_config_empty()

# %%
#|export
def test_pool_server_context_log_no_file():
    """Test _PoolServerContext._log is a no-op when no log file is open."""
    ctx = _PoolServerContext(None, "127.0.0.1", 8080, log_file=None)
    # Should not raise
    ctx._log("test message")

# %%
test_pool_server_context_log_no_file()

# %%
#|export
def test_server_log_callback():
    """Test _ServerLogCallback is callable and picklable."""
    import pickle
    callback = _ServerLogCallback("/tmp/test_netrun_log.log")
    assert callable(callback)
    # Calling with result=None should be a no-op
    callback("arg0", "test_node", result=None)
    # Must be picklable for multiprocess workers
    pickled = pickle.dumps(callback)
    restored = pickle.loads(pickled)
    assert callable(restored)

# %%
test_server_log_callback()

# %% [markdown]
# ## EpochError Tests

# %%
#|export
def test_epoch_error_basic():
    """Test EpochError fields and isinstance."""
    err = EpochError("bad input", node_name="MyNode", epoch_id="ep-123",
                     pool_id="main", worker_id=2, retry_count=1)
    assert isinstance(err, Exception)
    assert isinstance(err, EpochError)
    assert err.node_name == "MyNode"
    assert err.epoch_id == "ep-123"
    assert err.pool_id == "main"
    assert err.worker_id == 2
    assert err.retry_count == 1

# %%
test_epoch_error_basic()

# %%
#|export
def test_epoch_error_str():
    """Test EpochError __str__ includes node, pool, worker, and cause."""
    cause = ValueError("bad input")
    err = EpochError("bad input", node_name="MyNode", epoch_id="ep-123",
                     pool_id="main", worker_id=2, retry_count=1)
    err.__cause__ = cause
    s = str(err)
    assert "MyNode" in s
    assert "pool='main'" in s
    assert "worker=2" in s
    assert "retries=1" in s
    assert "bad input" in s

# %%
test_epoch_error_str()

# %%
#|export
def test_epoch_error_minimal():
    """Test EpochError with only required fields and defaults."""
    err = EpochError("fail", node_name="N", epoch_id="e1")
    assert err.pool_id is None
    assert err.worker_id is None
    assert err.retry_count == 0
    s = str(err)
    assert "node 'N'" in s
    # No pool/worker/retries info when defaults
    assert "pool=" not in s
    assert "worker=" not in s
    assert "retries=" not in s

# %%
test_epoch_error_minimal()

# %%
#|export
def test_epoch_error_can_be_caught():
    """Test that EpochError can be raised and caught."""
    with pytest.raises(EpochError):
        raise EpochError("fail", node_name="N", epoch_id="e1")

# %%
test_epoch_error_can_be_caught()

# %%
#|export
def test_epoch_error_chaining():
    """Test raise ... from preserves __cause__."""
    original = ValueError("original")
    try:
        raise EpochError("wrapped", node_name="N", epoch_id="e1") from original
    except EpochError as e:
        assert e.__cause__ is original
        assert isinstance(e.__cause__, ValueError)

# %%
test_epoch_error_chaining()

# %%
#|export
@pytest.mark.asyncio
async def test_propagate_exceptions_wraps_in_epoch_error():
    """Integration: run_until_blocked raises EpochError with correct fields."""
    def failing_node(ctx, packets):
        for port_name, pkt_ids in packets.items():
            for pid in pkt_ids:
                ctx.consume_packet(pid)
        raise RuntimeError("kaboom")

    graph_config = GraphConfig(
        nodes=[
            NodeConfig(
                name="Boom",
                in_ports={"in": PortConfig()},
                execution_config=NodeExecutionConfig(
                    pools=["main"],
                    exec_node_func=failing_node,
                ),
            ),
        ],
        edges=[],
    )

    config = NetConfig(
        pools={"main": PoolConfig(spec=MainPoolConfig())},
        graph=graph_config,
        propagate_exceptions=True,
    )

    async with Net(config) as net:
        net.inject_data("Boom", "in", [42])
        with pytest.raises(EpochError) as exc_info:
            await net.run_until_blocked()
        err = exc_info.value
        assert err.node_name == "Boom"
        assert err.pool_id == "main"
        assert err.worker_id is not None
        assert err.retry_count == 0
        assert isinstance(err.__cause__, RuntimeError)
        assert "kaboom" in str(err.__cause__)

# %%
#|export
@pytest.mark.asyncio
async def test_exception_queue_contains_epoch_error():
    """Integration: queued exceptions are EpochError with __cause__."""
    def failing_node(ctx, packets):
        for port_name, pkt_ids in packets.items():
            for pid in pkt_ids:
                ctx.consume_packet(pid)
        raise TypeError("bad type")

    graph_config = GraphConfig(
        nodes=[
            NodeConfig(
                name="TypeFail",
                in_ports={"in": PortConfig()},
                execution_config=NodeExecutionConfig(
                    pools=["main"],
                    exec_node_func=failing_node,
                ),
            ),
        ],
        edges=[],
    )

    config = NetConfig(
        pools={"main": PoolConfig(spec=MainPoolConfig())},
        graph=graph_config,
        propagate_exceptions=False,
    )

    async with Net(config) as net:
        net.inject_data("TypeFail", "in", [1])
        await net.run_until_blocked()
        assert len(net.exception_queue) == 1
        err = net.exception_queue[0]
        assert isinstance(err, EpochError)
        assert err.node_name == "TypeFail"
        assert isinstance(err.__cause__, TypeError)
        assert "bad type" in str(err.__cause__)

# %%
#|export
@pytest.mark.asyncio
async def test_dead_letter_queue_has_pool_and_worker():
    """Test dead letter queue entries include pool_id and worker_id."""
    def always_fails(ctx, packets):
        raise ValueError("always fails")

    graph_config = GraphConfig(
        nodes=[
            NodeConfig(
                name="DLQ",
                in_ports={"in": PortConfig()},
                execution_config=NodeExecutionConfig(
                    pools=["main"],
                    exec_node_func=always_fails,
                    propagate_exceptions=False,
                ),
            ),
        ],
        edges=[],
    )

    config = NetConfig(
        pools={"main": PoolConfig(spec=MainPoolConfig())},
        graph=graph_config,
        propagate_exceptions=False,
    )

    async with Net(config) as net:
        net.inject_data("DLQ", "in", [1])
        await net.run_until_blocked()
        assert len(net.dead_letter_queue) == 1
        entry = net.dead_letter_queue[0]
        assert "pool_id" in entry
        assert "worker_id" in entry
        assert entry["pool_id"] == "main"
        assert entry["node_name"] == "DLQ"

# %%
#|export
@pytest.mark.asyncio
async def test_node_failure_context_has_pool_and_worker():
    """Test on_node_failure callback receives pool_id and worker_id."""
    failure_log = []

    def failure_callback(failure_ctx):
        failure_log.append({
            "pool_id": failure_ctx.pool_id,
            "worker_id": failure_ctx.worker_id,
            "node_name": failure_ctx.node_name,
        })

    def failing_node(ctx, packets):
        raise ValueError("fail")

    graph_config = GraphConfig(
        nodes=[
            NodeConfig(
                name="CBNode",
                in_ports={"in": PortConfig()},
                execution_config=NodeExecutionConfig(
                    pools=["main"],
                    exec_node_func=failing_node,
                    on_node_failure=failure_callback,
                    propagate_exceptions=False,
                ),
            ),
        ],
        edges=[],
    )

    config = NetConfig(
        pools={"main": PoolConfig(spec=MainPoolConfig())},
        graph=graph_config,
        propagate_exceptions=False,
    )

    async with Net(config) as net:
        net.inject_data("CBNode", "in", [1])
        await net.run_until_blocked()
        assert len(failure_log) == 1
        assert failure_log[0]["pool_id"] == "main"
        assert failure_log[0]["worker_id"] is not None
        assert failure_log[0]["node_name"] == "CBNode"

# %%
#|export
@pytest.mark.asyncio
async def test_print_exceptions_includes_pool_worker(capsys):
    """Test that stderr output includes pool and worker info."""
    def failing_node(ctx, packets):
        for port_name, pkt_ids in packets.items():
            for pid in pkt_ids:
                ctx.consume_packet(pid)
        raise ValueError("print test")

    graph_config = GraphConfig(
        nodes=[
            NodeConfig(
                name="PrintNode",
                in_ports={"in": PortConfig()},
                execution_config=NodeExecutionConfig(
                    pools=["main"],
                    exec_node_func=failing_node,
                ),
            ),
        ],
        edges=[],
    )

    config = NetConfig(
        pools={"main": PoolConfig(spec=MainPoolConfig())},
        graph=graph_config,
        propagate_exceptions=False,
        print_exceptions=True,
    )

    async with Net(config) as net:
        net.inject_data("PrintNode", "in", [1])
        await net.run_until_blocked()
        captured = capsys.readouterr()
        assert "PrintNode" in captured.err
        assert "pool='main'" in captured.err
        assert "print test" in captured.err

# %% [markdown]
# ## Pool Server Start/Stop API Tests

# %%
#|export
@pytest.mark.asyncio
async def test_pool_server_context_start_stop():
    """Test _PoolServerContext.start() and stop() work without context manager."""
    port = _get_next_serve_pool_port()
    config = NetConfig(
        pools={"main": PoolConfig(spec=MainPoolConfig())},
        graph=GraphConfig(nodes=[], edges=[]),
    )

    pool_ctx = Net.serve_pool(config, "127.0.0.1", port)
    await pool_ctx.start()

    # Server should be running — verify by connecting a client
    from netrun.pool.remote import RemotePoolClient
    client = RemotePoolClient(
        url=f"ws://127.0.0.1:{port}",
        worker_name="execution_manager",
        num_processes=1,
        threads_per_process=1,
    )
    await client.connect()
    await client.create_pool("execution_manager", num_processes=1, threads_per_process=1)
    await client.close()

    await pool_ctx.stop()

# %%
#|export
@pytest.mark.asyncio
async def test_pool_server_context_as_context_manager_still_works():
    """Test _PoolServerContext still works as async context manager."""
    port = _get_next_serve_pool_port()
    config = NetConfig(
        pools={"main": PoolConfig(spec=MainPoolConfig())},
        graph=GraphConfig(nodes=[], edges=[]),
    )

    async with Net.serve_pool(config, "127.0.0.1", port):
        from netrun.pool.remote import RemotePoolClient
        client = RemotePoolClient(
            url=f"ws://127.0.0.1:{port}",
            worker_name="execution_manager",
            num_processes=1,
            threads_per_process=1,
        )
        await client.connect()
        await client.create_pool("execution_manager", num_processes=1, threads_per_process=1)
        await client.close()

# %%
#|export
@pytest.mark.asyncio
async def test_request_pool_shutdown_end_to_end():
    """Test that Net.request_pool_shutdown signals the server to stop."""
    port = _get_next_serve_pool_port()

    graph_config = GraphConfig(nodes=[], edges=[])

    server_config = NetConfig(
        pools={"main": PoolConfig(spec=MainPoolConfig())},
        graph=graph_config,
    )

    net_config = NetConfig(
        pools={
            "remote": PoolConfig(
                spec=RemotePoolConfig(
                    url=f"ws://127.0.0.1:{port}",
                    worker_name="execution_manager",
                    num_processes=1,
                    threads_per_process=1,
                ),
            ),
        },
        graph=graph_config,
    )

    pool_ctx = Net.serve_pool(server_config, "127.0.0.1", port)
    await pool_ctx.start()

    async with Net(net_config) as net:
        # Request shutdown
        await net.request_pool_shutdown("remote")

    # wait_until_stopped should resolve immediately since shutdown was requested
    # (use a timeout to avoid hanging if the test fails)
    await asyncio.wait_for(pool_ctx.wait_until_stopped(), timeout=5.0)

    await pool_ctx.stop()

# %%
#|export
@pytest.mark.asyncio
async def test_request_pool_shutdown_non_remote_raises():
    """Test request_pool_shutdown raises TypeError for non-remote pools."""
    config = NetConfig(
        pools={"main": PoolConfig(spec=MainPoolConfig())},
        graph=GraphConfig(nodes=[], edges=[]),
    )

    async with Net(config) as net:
        with pytest.raises(TypeError, match="not a RemotePoolClient"):
            await net.request_pool_shutdown("main")

# %%
#|export
@pytest.mark.asyncio
async def test_execution_manager_get_pool():
    """Test ExecutionManager.get_pool returns the pool instance."""
    from netrun.execution_manager import ExecutionManager
    from netrun.pool.thread import ThreadPool

    manager = ExecutionManager({
        "workers": (ThreadPool, {"num_workers": 1}),
    })

    async with manager:
        pool = manager.get_pool("workers")
        assert isinstance(pool, ThreadPool)

        with pytest.raises(KeyError, match="not found"):
            manager.get_pool("nonexistent")

# %%
#|export
@pytest.mark.asyncio
async def test_pool_server_context_start_stop_with_log_file(tmp_path):
    """Test start/stop writes log messages to file."""
    log_file = tmp_path / "server.log"
    port = _get_next_serve_pool_port()
    config = NetConfig(
        pools={"main": PoolConfig(spec=MainPoolConfig())},
        graph=GraphConfig(nodes=[], edges=[]),
    )

    pool_ctx = Net.serve_pool(config, "127.0.0.1", port, log_file=str(log_file))
    await pool_ctx.start()

    content = log_file.read_text()
    assert "Pool server started" in content

    await pool_ctx.stop()

    content = log_file.read_text()
    assert "Pool server stopped" in content
