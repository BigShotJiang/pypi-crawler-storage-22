# ---
# jupyter:
#   kernelspec:
#     display_name: .venv
#     language: python
#     name: python3
# ---

# %%
#|default_exp net.config._base

# %%
#|hide
from nblite import nbl_export; nbl_export();

# %%
#|export
from pydantic import BaseModel, Field, PrivateAttr, model_validator, field_serializer, field_validator
from typing import Annotated, Literal, NewType, Any, Union, get_origin, get_args
from types import ModuleType, UnionType
from collections.abc import Callable
from enum import Enum
import importlib
import importlib.util
import json as _json_module
import os
import sys
import tomllib
from ulid import ULID

import netrun_sim
from netrun.execution_manager import RunAllocationMethod

# %%
#|export
def _get_callable_import_path(func: Callable) -> str:
    """Get the import path for a callable (function or method).

    Args:
        func: The callable to get the import path for.

    Returns:
        The import path as "module.qualname" (e.g., "myapp.utils.process_data").

    Raises:
        ValueError: If the callable cannot be serialized (lambda, closure, __main__).
    """
    module = getattr(func, "__module__", None)
    qualname = getattr(func, "__qualname__", None)

    if module is None or qualname is None:
        raise ValueError(
            f"Cannot serialize callable {func}: missing __module__ or __qualname__"
        )

    if module == "__main__":
        raise ValueError(
            f"Cannot serialize callable '{qualname}' defined in __main__. "
            "Move it to an importable module or use a string import path."
        )

    if "<lambda>" in qualname:
        raise ValueError(
            f"Cannot serialize lambda functions. "
            "Define a named function or use a string import path."
        )

    if "<locals>" in qualname:
        raise ValueError(
            f"Cannot serialize closure/local function '{qualname}'. "
            "Define it at module level or use a string import path."
        )

    return f"{module}.{qualname}"


def _get_type_import_path(type_obj: type) -> str:
    """Get the import path for a type.

    Args:
        type_obj: The type to get the import path for.

    Returns:
        The import path as "module.qualname" (e.g., "pandas.DataFrame").
        For builtin types, returns just the name (e.g., "int", "str").

    Raises:
        ValueError: If the type cannot be serialized (__main__).
    """
    module = getattr(type_obj, "__module__", None)
    qualname = getattr(type_obj, "__qualname__", None)

    if module is None or qualname is None:
        raise ValueError(
            f"Cannot serialize type {type_obj}: missing __module__ or __qualname__"
        )

    if module == "__main__":
        raise ValueError(
            f"Cannot serialize type '{qualname}' defined in __main__. "
            "Move it to an importable module or use a string import path."
        )

    if module == "builtins":
        # Built-in types like int, str, list, dict - just use name
        return qualname

    return f"{module}.{qualname}"


def _is_file_path_ref(s: str) -> bool:
    """Check if string is a file-path reference (vs dotted import path).

    A string is a file-path reference if any of:
    - Contains '::' (file path + attribute separator)
    - Contains '/' or '\\' (path separator)
    - Starts with '.' (relative path like './' or '../')
    """
    return '::' in s or '/' in s or '\\' in s or s.startswith('.')


def _import_from_file_path(file_ref: str, project_root: 'Path | None' = None) -> Any:
    """Import from a file-path reference.

    - "path/to/file.py::attr" -> load file, getattr(module, attr)
    - "path/to/file.py" -> load file, return module

    Relative paths resolve from project_root (or cwd).
    """
    if '::' in file_ref:
        file_path_str, attr_name = file_ref.split('::', 1)
    else:
        file_path_str = file_ref
        attr_name = None

    file_path = Path(file_path_str)
    if not file_path.is_absolute():
        base = project_root if project_root is not None else Path(os.getcwd())
        file_path = (base / file_path).resolve()
    else:
        file_path = file_path.resolve()

    if not file_path.exists():
        raise FileNotFoundError(f"Module file not found: {file_path}")

    module_name = f"_netrun_filemod_{file_path.stem}_{hash(str(file_path)) & 0xFFFFFFFF:08x}"

    spec = importlib.util.spec_from_file_location(module_name, str(file_path))
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot create module spec from: {file_path}")

    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)

    if attr_name is not None:
        return getattr(module, attr_name)
    return module


def _import_from_path(import_path: str, project_root: 'Path | None' = None) -> Any:
    """Import an object from a dotted import path or file-path reference.

    Args:
        import_path: Dotted import path (e.g., "myapp.utils.my_function")
                     or file-path reference (e.g., "./nodes.py::my_func").
        project_root: Base path for resolving relative file paths.

    Returns:
        The imported object.

    Raises:
        ImportError: If the module cannot be imported.
        AttributeError: If the object doesn't exist in the module.
    """
    if _is_file_path_ref(import_path):
        return _import_from_file_path(import_path, project_root=project_root)
    module_path, name = import_path.rsplit(".", 1)
    module = importlib.import_module(module_path)
    return getattr(module, name)

# %% [markdown]
# # EnvVar Model
#
# Allows config fields to reference environment variables for deployment flexibility.

# %%
#|export
class EnvVar(BaseModel):
    """Reference to an environment variable for config field resolution.

    Serialised as ``{"$env": "VAR_NAME"}`` or ``{"$env": "VAR_NAME", "default": 42}``.
    """
    model_config = {"populate_by_name": True}
    env: str = Field(alias="$env")
    default: Any = None


def _cast_env_var_value(raw: str, target_type: type, env_name: str = "") -> Any:
    """Cast a raw string from os.environ to the target Python type.

    Args:
        raw: The raw string value from the environment.
        target_type: The Python type to cast to.
        env_name: Name of the env var (for error messages).

    Returns:
        The cast value.

    Raises:
        ValueError: If casting fails.
    """
    try:
        if target_type is str or target_type is Any:
            return raw
        if target_type is int:
            return int(raw)
        if target_type is float:
            return float(raw)
        if target_type is bool:
            lowered = raw.lower().strip()
            if lowered in ("true", "1", "yes"):
                return True
            if lowered in ("false", "0", "no"):
                return False
            raise ValueError(
                f"Cannot parse '{raw}' as bool. "
                f"Expected one of: true/false, 1/0, yes/no"
            )
        if isinstance(target_type, type) and issubclass(target_type, Enum):
            return target_type(raw)
        # Fallback: try JSON parsing for complex types (list, dict, tuple, etc.)
        parsed = _json_module.loads(raw)
        return parsed
    except (ValueError, TypeError, _json_module.JSONDecodeError) as exc:
        raise ValueError(
            f"Cannot cast env var '{env_name}' value {raw!r} to {target_type.__name__ if hasattr(target_type, '__name__') else target_type}: {exc}"
        ) from exc


def _extract_target_type(annotation: Any) -> type:
    """Extract the actual target type from a union annotation, stripping EnvVar and None.

    For ``Callable | str | EnvVar | None`` returns ``str`` (env vars provide import
    path strings; callable resolution happens later).

    Args:
        annotation: The field type annotation.

    Returns:
        The target type for env var casting.
    """
    origin = get_origin(annotation)

    # Handle Annotated[X, ...] — unwrap to X
    if origin is Annotated:
        inner_args = get_args(annotation)
        if inner_args:
            return _extract_target_type(inner_args[0])

    # Handle Union / X | Y
    if origin is Union or isinstance(annotation, UnionType):
        args = get_args(annotation)
        # Filter out EnvVar and NoneType
        candidates = [
            a for a in args
            if a is not type(None) and a is not EnvVar
        ]
        if not candidates:
            return str
        # If Callable is among candidates alongside str, prefer str
        # (env vars provide import path strings)
        non_callable = [a for a in candidates if a is not Callable and not (isinstance(a, type) and issubclass(a, Callable))]
        if non_callable:
            # Prefer the simplest scalar type
            for preferred in (str, int, float, bool):
                if preferred in non_callable:
                    return preferred
            return non_callable[0]
        return str  # All callable → return str

    # Not a union — return as-is
    if isinstance(annotation, type):
        return annotation
    return str


def _resolve_env_vars_in_list(lst: list) -> tuple[list, bool]:
    """Recursively resolve EnvVar instances in a list of EnvVarResolvableModel items."""
    changed = False
    new_list = []
    for item in lst:
        if isinstance(item, EnvVarResolvableModel):
            resolved = item.resolve_env_vars()
            if resolved is not item:
                changed = True
            new_list.append(resolved)
        else:
            new_list.append(item)
    return new_list, changed


def _resolve_env_vars_in_dict(d: dict) -> tuple[dict, bool]:
    """Recursively resolve EnvVar instances in a dict of EnvVarResolvableModel values."""
    changed = False
    new_dict = {}
    for key, value in d.items():
        if isinstance(value, EnvVarResolvableModel):
            resolved = value.resolve_env_vars()
            if resolved is not value:
                changed = True
            new_dict[key] = resolved
        else:
            new_dict[key] = value
    return new_dict, changed


class EnvVarResolvableModel(BaseModel):
    """Base class for config models that may contain EnvVar fields."""

    def resolve_env_vars(self) -> "EnvVarResolvableModel":
        """Return a copy with all EnvVar fields resolved from os.environ."""
        updates = {}
        for field_name, field_info in type(self).model_fields.items():
            value = getattr(self, field_name)
            if isinstance(value, EnvVar):
                target_type = _extract_target_type(field_info.annotation)
                raw = os.environ.get(value.env)
                if raw is None:
                    if value.default is not None:
                        updates[field_name] = value.default
                    else:
                        raise ValueError(
                            f"Environment variable '{value.env}' is not set "
                            f"and no default provided (field: {type(self).__name__}.{field_name})"
                        )
                else:
                    updates[field_name] = _cast_env_var_value(raw, target_type, env_name=value.env)
            elif isinstance(value, EnvVarResolvableModel):
                resolved = value.resolve_env_vars()
                if resolved is not value:
                    updates[field_name] = resolved
            elif isinstance(value, list):
                new_list, changed = _resolve_env_vars_in_list(value)
                if changed:
                    updates[field_name] = new_list
            elif isinstance(value, dict):
                new_dict, changed = _resolve_env_vars_in_dict(value)
                if changed:
                    updates[field_name] = new_dict
        if updates:
            return self.model_copy(update=updates)
        return self

# %% [markdown]
# # Port Configuration
#
# These Pydantic models mirror the `netrun_sim` graph types, providing a serializable
# DSL for defining flow-based networks.

# %% [markdown]
# ## Port slot specification
#
# Defines the capacity of a port (how many packets it can hold).

# %%
#|export
class PortSlotSpecInfiniteConfig(EnvVarResolvableModel):
    """Port can hold unlimited packets."""
    type: Literal["infinite"] = "infinite"

    def to_netrun_sim(self) -> netrun_sim.PortSlotSpec:
        return netrun_sim.PortSlotSpec.infinite()


class PortSlotSpecFiniteConfig(EnvVarResolvableModel):
    """Port can hold at most `capacity` packets."""
    type: Literal["finite"] = "finite"
    capacity: int | EnvVar

    def to_netrun_sim(self) -> netrun_sim.PortSlotSpecFinite:
        return netrun_sim.PortSlotSpec.finite(self.capacity)


PortSlotSpecConfig = Annotated[
    PortSlotSpecInfiniteConfig | PortSlotSpecFiniteConfig,
    Field(discriminator="type")
]

# %% [markdown]
# ## Port type configuration
#
# Optional type validation for packets flowing through ports.

# %%
#|export
class PortTypeConfig(EnvVarResolvableModel):
    """Detailed port type configuration.

    Used when you need more control than a simple type name string.
    """
    name: str | EnvVar
    """Type name to match (e.g., "DataFrame", "dict", "MyClass")."""

    isinstance_check: bool | EnvVar = False
    """If True and a type object is available, use isinstance().
    If False, use type().__name__ match. Default is False (name match)."""


# Type specification union - supports multiple formats
PortTypeSpec = str | type | PortTypeConfig
"""Port type specification.

Can be:
- str: Type name to match against type(value).__name__
- type: Type object for isinstance() check
- PortTypeConfig: Detailed configuration
"""

# %% [markdown]
# ## Port configuration

# %%
#|export
class PortConfig(EnvVarResolvableModel):
    """Configuration for a port on a node."""
    model_config = {"arbitrary_types_allowed": True}

    slots_spec: PortSlotSpecConfig = Field(default_factory=PortSlotSpecInfiniteConfig)

    port_type: Any = None
    """Expected type for packets on this port.

    - None: No validation (default)
    - str: Match type(value).__name__ exactly
    - type: Use isinstance(value, port_type) or beartype for generics
    - PortTypeConfig: Detailed configuration

    Generic types like list[int], dict[str, int] are supported and use
    beartype for proper validation.

    Example:
        PortConfig(port_type="DataFrame")  # Match by name
        PortConfig(port_type=pd.DataFrame)  # Match with isinstance
        PortConfig(port_type=list[int])     # Match with beartype
    """

    @field_validator("port_type")
    @classmethod
    def validate_port_type(cls, v):
        if v is None:
            return v
        if isinstance(v, (str, type, PortTypeConfig)):
            return v
        if get_origin(v) is not None:
            return v  # Generic alias like list[int], dict[str, int]
        raise ValueError(
            f"port_type must be str, type, generic type, PortTypeConfig, or None, got {type(v).__name__}"
        )

    @field_serializer("port_type", when_used='json')
    def serialize_port_type(self, port_type: Any) -> str | dict | None:
        """Serialize port_type to import path for JSON roundtrip.

        Type objects are serialized to their full import path (e.g., "pandas.DataFrame")
        to preserve isinstance capability after deserialization.
        Generic types are serialized to their string representation (e.g., "list[int]").

        Note: Only called during JSON serialization (model_dump_json).

        Raises:
            ValueError: If type is defined in __main__ and cannot be imported.
        """
        if port_type is None:
            return None
        if isinstance(port_type, str):
            return port_type
        if isinstance(port_type, type):
            return _get_type_import_path(port_type)
        if isinstance(port_type, PortTypeConfig):
            return port_type.model_dump()
        if get_origin(port_type) is not None:
            return str(port_type)  # e.g., "list[int]"
        return None

    def to_netrun_sim(self) -> netrun_sim.Port:
        return netrun_sim.Port(self.slots_spec.to_netrun_sim())

# %% [markdown]
# ## Port state predicates
#
# Used in salvo condition terms to check the state of a port.

# %%
#|export
class PortStateEmptyConfig(EnvVarResolvableModel):
    """Port has zero packets."""
    type: Literal["empty"] = "empty"

    def to_netrun_sim(self) -> netrun_sim.PortState:
        return netrun_sim.PortState.empty()


class PortStateFullConfig(EnvVarResolvableModel):
    """Port is at capacity (always false for infinite ports)."""
    type: Literal["full"] = "full"

    def to_netrun_sim(self) -> netrun_sim.PortState:
        return netrun_sim.PortState.full()


class PortStateNonEmptyConfig(EnvVarResolvableModel):
    """Port has at least one packet."""
    type: Literal["non_empty"] = "non_empty"

    def to_netrun_sim(self) -> netrun_sim.PortState:
        return netrun_sim.PortState.non_empty()


class PortStateNonFullConfig(EnvVarResolvableModel):
    """Port is below capacity (always true for infinite ports)."""
    type: Literal["non_full"] = "non_full"

    def to_netrun_sim(self) -> netrun_sim.PortState:
        return netrun_sim.PortState.non_full()


class PortStateEqualsConfig(EnvVarResolvableModel):
    """Port has exactly `value` packets."""
    type: Literal["equals"] = "equals"
    value: int | EnvVar

    def to_netrun_sim(self) -> netrun_sim.PortStateNumeric:
        return netrun_sim.PortState.equals(self.value)


class PortStateLessThanConfig(EnvVarResolvableModel):
    """Port has fewer than `value` packets."""
    type: Literal["less_than"] = "less_than"
    value: int | EnvVar

    def to_netrun_sim(self) -> netrun_sim.PortStateNumeric:
        return netrun_sim.PortState.less_than(self.value)


class PortStateGreaterThanConfig(EnvVarResolvableModel):
    """Port has more than `value` packets."""
    type: Literal["greater_than"] = "greater_than"
    value: int | EnvVar

    def to_netrun_sim(self) -> netrun_sim.PortStateNumeric:
        return netrun_sim.PortState.greater_than(self.value)


class PortStateEqualsOrLessThanConfig(EnvVarResolvableModel):
    """Port has at most `value` packets."""
    type: Literal["equals_or_less_than"] = "equals_or_less_than"
    value: int | EnvVar

    def to_netrun_sim(self) -> netrun_sim.PortStateNumeric:
        return netrun_sim.PortState.equals_or_less_than(self.value)


class PortStateEqualsOrGreaterThanConfig(EnvVarResolvableModel):
    """Port has at least `value` packets."""
    type: Literal["equals_or_greater_than"] = "equals_or_greater_than"
    value: int | EnvVar

    def to_netrun_sim(self) -> netrun_sim.PortStateNumeric:
        return netrun_sim.PortState.equals_or_greater_than(self.value)


PortStateConfig = Annotated[
    PortStateEmptyConfig | PortStateFullConfig | PortStateNonEmptyConfig | PortStateNonFullConfig | PortStateEqualsConfig | PortStateLessThanConfig | PortStateGreaterThanConfig | PortStateEqualsOrLessThanConfig | PortStateEqualsOrGreaterThanConfig,
    Field(discriminator="type")
]

# %% [markdown]
# # Salvo Configuration

# %% [markdown]
# ## Packet count specification
#
# Specifies how many packets to take from a port in a salvo.

# %%
#|export
class PacketCountAllConfig(EnvVarResolvableModel):
    """Take all packets from the port."""
    type: Literal["all"] = "all"

    def to_netrun_sim(self) -> netrun_sim.PacketCount:
        return netrun_sim.PacketCount.all()


class PacketCountNConfig(EnvVarResolvableModel):
    """Take at most `count` packets (takes fewer if port has fewer)."""
    type: Literal["count"] = "count"
    count: int | EnvVar

    def to_netrun_sim(self) -> netrun_sim.PacketCountN:
        return netrun_sim.PacketCount.count(self.count)


PacketCountConfig = Annotated[
    PacketCountAllConfig | PacketCountNConfig,
    Field(discriminator="type")
]

# %% [markdown]
# ## Max salvos specification
#
# Specifies the maximum number of times a salvo condition can trigger.

# %%
#|export
class MaxSalvosInfiniteConfig(EnvVarResolvableModel):
    """No limit on how many times the condition can trigger."""
    type: Literal["infinite"] = "infinite"

    def to_netrun_sim(self) -> netrun_sim.MaxSalvos:
        return netrun_sim.MaxSalvos.infinite()


class MaxSalvosFiniteConfig(EnvVarResolvableModel):
    """Can trigger at most `max` times."""
    type: Literal["finite"] = "finite"
    max: int | EnvVar

    def to_netrun_sim(self) -> netrun_sim.MaxSalvosFinite:
        return netrun_sim.MaxSalvos.finite(self.max)


MaxSalvosConfig = Annotated[
    MaxSalvosInfiniteConfig | MaxSalvosFiniteConfig,
    Field(discriminator="type")
]

# %% [markdown]
# ## Salvo condition term
#
# Boolean expressions over port states, used to define when salvos can trigger.

# %%
#|export
class SalvoConditionTermTrueConfig(EnvVarResolvableModel):
    """Always true. Useful for source nodes with no input ports."""
    type: Literal["true"] = "true"

    def to_netrun_sim(self) -> netrun_sim.SalvoConditionTerm:
        return netrun_sim.SalvoConditionTerm.true_()


class SalvoConditionTermFalseConfig(EnvVarResolvableModel):
    """Always false. Useful as a placeholder or with Not."""
    type: Literal["false"] = "false"

    def to_netrun_sim(self) -> netrun_sim.SalvoConditionTerm:
        return netrun_sim.SalvoConditionTerm.false_()


class SalvoConditionTermPortConfig(EnvVarResolvableModel):
    """Check if a specific port matches a state predicate."""
    type: Literal["port"] = "port"
    port_name: str | EnvVar
    state: PortStateConfig

    def to_netrun_sim(self) -> netrun_sim.SalvoConditionTerm:
        return netrun_sim.SalvoConditionTerm.port(self.port_name, self.state.to_netrun_sim())


class SalvoConditionTermAndConfig(EnvVarResolvableModel):
    """All sub-terms must be true."""
    type: Literal["and"] = "and"
    terms: list["SalvoConditionTermConfig"]

    def to_netrun_sim(self) -> netrun_sim.SalvoConditionTerm:
        return netrun_sim.SalvoConditionTerm.and_([t.to_netrun_sim() for t in self.terms])


class SalvoConditionTermOrConfig(EnvVarResolvableModel):
    """At least one sub-term must be true."""
    type: Literal["or"] = "or"
    terms: list["SalvoConditionTermConfig"]

    def to_netrun_sim(self) -> netrun_sim.SalvoConditionTerm:
        return netrun_sim.SalvoConditionTerm.or_([t.to_netrun_sim() for t in self.terms])


class SalvoConditionTermNotConfig(EnvVarResolvableModel):
    """The sub-term must be false."""
    type: Literal["not"] = "not"
    term: "SalvoConditionTermConfig"

    def to_netrun_sim(self) -> netrun_sim.SalvoConditionTerm:
        return netrun_sim.SalvoConditionTerm.not_(self.term.to_netrun_sim())


SalvoConditionTermConfig = Annotated[
    SalvoConditionTermTrueConfig | SalvoConditionTermFalseConfig | SalvoConditionTermPortConfig | SalvoConditionTermAndConfig | SalvoConditionTermOrConfig | SalvoConditionTermNotConfig,
    Field(discriminator="type")
]

# Rebuild models to resolve forward references
SalvoConditionTermAndConfig.model_rebuild()
SalvoConditionTermOrConfig.model_rebuild()
SalvoConditionTermNotConfig.model_rebuild()

# %% [markdown]
# ## Salvo condition
#
# Defines when packets can trigger an epoch or be sent.

# %%
#|export
class SalvoConditionConfig(EnvVarResolvableModel):
    """A condition that defines when packets can trigger an epoch or be sent.

    Input salvo conditions must have max_salvos set to finite(1).
    """
    max_salvos: MaxSalvosConfig
    ports: dict[str, PacketCountConfig]
    term: SalvoConditionTermConfig

    def to_netrun_sim(self) -> netrun_sim.SalvoCondition:
        ports_dict = {name: pc.to_netrun_sim() for name, pc in self.ports.items()}
        return netrun_sim.SalvoCondition(
            max_salvos=self.max_salvos.to_netrun_sim(),
            ports=ports_dict,
            term=self.term.to_netrun_sim(),
        )

# %% [markdown]
# ## Default salvo condition generation
#
# Generate default salvo conditions when None is specified.

# %%
#|export
def _generate_default_in_salvo_conditions(
    in_ports: dict[str, PortConfig]
) -> dict[str, SalvoConditionConfig]:
    """Generate default input salvo condition.

    Default: Fires when all input ports have at least one packet.
    Takes all packets from all ports.

    Args:
        in_ports: The input port configurations.

    Returns:
        Dict with a single "default" salvo condition.
    """
    if not in_ports:
        # No input ports - use always-true condition
        return {
            "default": SalvoConditionConfig(
                max_salvos=MaxSalvosFiniteConfig(max=1),
                ports={},
                term=SalvoConditionTermTrueConfig(),
            )
        }

    # Build AND condition: all ports must be non-empty
    port_terms = [
        SalvoConditionTermPortConfig(port_name=name, state=PortStateNonEmptyConfig())
        for name in in_ports.keys()
    ]

    if len(port_terms) == 1:
        term = port_terms[0]
    else:
        term = SalvoConditionTermAndConfig(terms=port_terms)

    # Include all packets from all ports
    ports = {name: PacketCountAllConfig() for name in in_ports.keys()}

    return {
        "default": SalvoConditionConfig(
            max_salvos=MaxSalvosFiniteConfig(max=1),
            ports=ports,
            term=term,
        )
    }


def _generate_default_out_salvo_conditions(
    out_ports: dict[str, PortConfig]
) -> dict[str, SalvoConditionConfig]:
    """Generate default output salvo condition.

    Default: Fires once per epoch, sends all packets from all output ports.

    Args:
        out_ports: The output port configurations.

    Returns:
        Dict with a single "default" salvo condition, or empty dict if no output ports.
    """
    if not out_ports:
        return {}

    # Include all packets from all output ports
    ports = {name: PacketCountAllConfig() for name in out_ports.keys()}

    return {
        "default": SalvoConditionConfig(
            max_salvos=MaxSalvosFiniteConfig(max=1),
            ports=ports,
            term=SalvoConditionTermTrueConfig(),
        )
    }

# %%
#|export
from pathlib import Path
