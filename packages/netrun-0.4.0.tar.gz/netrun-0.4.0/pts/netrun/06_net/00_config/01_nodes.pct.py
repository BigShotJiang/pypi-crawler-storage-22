# ---
# jupyter:
#   kernelspec:
#     display_name: .venv
#     language: python
#     name: python3
# ---

# %%
#|default_exp net.config._nodes

# %%
#|hide
from nblite import nbl_export; nbl_export();

# %%
#|export
from pydantic import BaseModel, Field, model_validator, field_serializer
from typing import Annotated, Literal, Any
from types import ModuleType
from collections.abc import Callable
from pathlib import Path
import importlib
import json

from netrun.net.config._base import (
    _get_callable_import_path,
    _is_file_path_ref,
    _import_from_file_path,
    _import_from_path,
    EnvVar,
    EnvVarResolvableModel,
    PortConfig,
    SalvoConditionConfig,
    _generate_default_in_salvo_conditions,
    _generate_default_out_salvo_conditions,
)
from netrun.execution_manager import RunAllocationMethod
from netrun.caching.config import NodeCacheConfig
import netrun_sim
import json as _json_module

# %% [markdown]
# # Edge Configuration

# %%
#|export
class PortRefConfig(EnvVarResolvableModel):
    """Reference to a specific port on a node."""
    node_name: str
    port_type: Literal["input", "output"]
    port_name: str

    def to_netrun_sim(self) -> netrun_sim.PortRef:
        port_type = netrun_sim.PortType.Input if self.port_type == "input" else netrun_sim.PortType.Output
        return netrun_sim.PortRef(self.node_name, port_type, self.port_name)


class EdgeConfig(EnvVarResolvableModel):
    """A connection between an output port and an input port.

    Can be specified as:
    - Full form: source and target PortRefConfig objects
    - Shorthand: source_str and target_str as "node.port" strings
    """
    source: PortRefConfig | None = None
    target: PortRefConfig | None = None
    # Shorthand notation: "NodeA.out" -> "NodeB.in"
    source_str: str | None = None
    target_str: str | None = None

    def model_post_init(self, __context):
        # Validate that either full form or shorthand is provided
        has_full = self.source is not None and self.target is not None
        has_short = self.source_str is not None and self.target_str is not None
        if not (has_full or has_short):
            raise ValueError("Must provide either (source, target) or (source_str, target_str)")
        if has_full and has_short:
            raise ValueError("Cannot provide both (source, target) and (source_str, target_str)")

    def _parse_port_str(self, s: str, port_type: Literal["input", "output"]) -> PortRefConfig:
        parts = s.split(".")
        if len(parts) != 2:
            raise ValueError(f"Invalid port string '{s}', expected 'NodeName.port_name'")
        return PortRefConfig(node_name=parts[0], port_type=port_type, port_name=parts[1])

    def get_source(self) -> PortRefConfig:
        if self.source is not None:
            return self.source
        return self._parse_port_str(self.source_str, "output")

    def get_target(self) -> PortRefConfig:
        if self.target is not None:
            return self.target
        return self._parse_port_str(self.target_str, "input")

    def to_netrun_sim(self) -> netrun_sim.Edge:
        return netrun_sim.Edge(
            self.get_source().to_netrun_sim(),
            self.get_target().to_netrun_sim(),
        )

# %% [markdown]
# # Node Configuration
#
# This is the node configuration, defining ports and salvo conditions, and how it is executed.
#
# The execution config can be left out when defining a node, in which case it will still be in the Net but will not executed or crash when packets are incoming.

# %% [markdown]
# ## Node execution config
#
# Runtime configuration for node execution (separate from graph structure).

# %%
#|export
from ulid import ULID
from typing import NewType

PacketID = NewType("PacketID", ULID)

NodeExecutionFunc = Callable
"""
Function that executes a node.

Args:
    ctx: NodeExecutionContext
    packets: dict[str, PacketID]
"""

NodeStartFunc = Callable
"""
Function that starts a node.

Args:
    net: Net
"""

NodeStopFunc = Callable
"""
Function that stops a node.

Args:
    net: Net
"""

OnNodeFailureFunc = Callable
"""
Function that is called when a node execution fails.

Args:
    ctx: NodeFailureContext
""";

# %%
#|export
class NodeVariable(EnvVarResolvableModel):
    """A typed variable accessible to nodes via ctx.vars."""
    value: str | EnvVar
    type: str = "str"  # "str", "int", "float", "bool", "json"

    def resolve_value(self) -> Any:
        """Resolve the string value to the appropriate Python type."""
        match self.type:
            case "str" | "":
                return self.value
            case "int":
                return int(self.value)
            case "float":
                return float(self.value)
            case "bool":
                l = self.value.lower().strip()
                if l in ("true", "1", "yes"):
                    return True
                if l in ("false", "0", "no"):
                    return False
                raise ValueError(f"Cannot parse '{self.value}' as bool")
            case "json":
                return _json_module.loads(self.value)
            case _:
                raise ValueError(f"Unsupported NodeVariable type: '{self.type}'")

# %%
#|export
class NodeExecutionConfig(EnvVarResolvableModel):
    """Runtime configuration for a node's execution behavior."""
    model_config = {"arbitrary_types_allowed": True}

    pools: list[str] | EnvVar = Field(default_factory=lambda: ["main"], description="Which pools can execute this node.")
    exec_node_func: NodeExecutionFunc | str | EnvVar | None = Field(default=None, description="Function to execute the node. Can be a callable or import path string.")

    start_node_func: NodeStartFunc | str | EnvVar | None = Field(default=None, description="Function called when the node starts up.")
    stop_node_func: NodeStopFunc | str | EnvVar | None = Field(default=None, description="Function called when the node shuts down.")
    on_node_failure: OnNodeFailureFunc | str | EnvVar | None = Field(default=None, description="Callback when node execution fails.")

    # Additional execution options (from PROJECT_SPEC.md)
    defer_startup: bool | EnvVar = Field(default=False, description="Defer start_node_func until the node's first epoch instead of during Net.start().")

    max_parallel_epochs: int | EnvVar | None = Field(default=None, description="Maximum concurrent epochs for this node.")
    max_epochs: int | EnvVar | None = Field(default=None, description="Maximum total epochs across this node's lifetime. None = unlimited.")

    rate_limit_per_second: float | EnvVar | None = Field(default=None, description="Maximum epoch triggers per second.")

    defer_net_actions: bool | EnvVar | None = Field(default=None, description="Defer net action notifications until epoch completes successfully. Required if retries enabled.")

    retries: int | EnvVar = Field(default=0, description="Number of retry attempts on failure.")
    retry_wait: float | EnvVar = Field(default=0.0, description="Wait time in seconds between retries.")
    timeout: float | EnvVar | None = Field(default=None, description="Epoch execution timeout in seconds.")

    capture_prints: bool | EnvVar = Field(default=True, description="Capture print statements in the node.")

    print_flush_interval: float | EnvVar = Field(default=0.1, description="How often to flush the print buffer in seconds.")

    print_buffer_max_size: int | EnvVar | None = Field(default=None, description="Max print buffer size before forced flush. None = unlimited.")

    print_echo_stdout: bool | EnvVar = Field(default=False, description="Also print to actual stdout when ctx.print() is called.")

    pool_allocation_method: RunAllocationMethod | EnvVar | None = Field(default=None, description="Worker selection method when node has multiple pools. None inherits Net default.")

    node_vars: dict[str, NodeVariable] | None = Field(default=None, description="Per-node variables, override net-level vars with the same name.")

    type_checking_enabled: bool | EnvVar | None = Field(default=None, description="Enable/disable type checking for this node. None inherits from NetConfig.")

    propagate_exceptions: bool | EnvVar | None = Field(default=None, description="Override NetConfig.propagate_exceptions for this node. None inherits.")

    print_exceptions: bool | EnvVar | None = Field(default=None, description="Override NetConfig.print_exceptions for this node. None inherits.")

    cache: NodeCacheConfig | None = Field(default=None, description="Per-node cache overrides.")

    @field_serializer("exec_node_func", "start_node_func", "stop_node_func", "on_node_failure", when_used='json')
    def serialize_func(self, func: Callable | str | EnvVar | None) -> str | dict | None:
        """Serialize functions to their import path for JSON.

        Function objects are serialized to their full import path
        (e.g., "myapp.nodes.process_data") for JSON roundtripping.
        EnvVar instances are serialized to their dict form.

        Note: Only called during JSON serialization (model_dump_json), not
        during Python serialization (model_dump). This allows factories to
        return closures that work at runtime but fail if serialized to JSON.

        Raises:
            ValueError: If function is defined in __main__, is a lambda, or is a closure.
        """
        if func is None:
            return None
        if isinstance(func, EnvVar):
            return func.model_dump(by_alias=True)
        if isinstance(func, str):
            return func
        return _get_callable_import_path(func)

    def resolve(self, project_root: 'Path | None' = None) -> "NodeExecutionConfig":
        """Return a resolved copy with string import paths converted to callables.

        Resolves env vars first, then resolves string import paths.

        Args:
            project_root: Base path for resolving relative file-path references.

        Returns:
            A new NodeExecutionConfig with all string function references
            resolved to actual callable objects.
        """
        # Resolve env vars first
        self = self.resolve_env_vars()

        updates = {}

        for field_name in ("exec_node_func", "start_node_func", "stop_node_func", "on_node_failure"):
            value = getattr(self, field_name)
            if isinstance(value, str):
                updates[field_name] = _import_from_path(value, project_root=project_root)

        if updates:
            return self.model_copy(update=updates)
        return self

# %%
#|export
class NodeConfig(EnvVarResolvableModel):
    """Configuration for a node's graph structure (ports and salvo conditions).

    Can be created directly or from a factory module using the `factory` field
    or the `from_factory()` class method.

    Example with factory:
        # Using factory field
        config = NodeConfig(
            factory="myapp.nodes.worker",
            factory_args={"name": "Worker1", "threshold": 0.5},
        )

        # Using from_factory class method
        config = NodeConfig.from_factory(
            factory="myapp.nodes.worker",
            args={"name": "Worker1", "threshold": 0.5},
        )
    """
    model_config = {"arbitrary_types_allowed": True}

    type: Literal["node"] = Field(default="node", description="Discriminator to distinguish from SubgraphConfig.")

    name: str = Field(default="", description="Node name, unique within the graph.")
    in_ports: dict[str, PortConfig] = Field(default_factory=dict, description="Input port configurations.")
    out_ports: dict[str, PortConfig] = Field(default_factory=dict, description="Output port configurations.")
    in_salvo_conditions: dict[str, SalvoConditionConfig] | None = Field(default=None, description="Input salvo conditions. None generates defaults on resolve().")
    out_salvo_conditions: dict[str, SalvoConditionConfig] | None = Field(default=None, description="Output salvo conditions. None generates defaults on resolve().")

    execution_config: NodeExecutionConfig | None = Field(default=None, description="Runtime execution configuration for this node.")

    extra: dict[str, Any] = Field(default_factory=dict, description="Arbitrary extra data (UI position, tags, documentation).")

    # Factory support
    factory: str | ModuleType | None = Field(default=None, description="Factory module or import path for dynamic node config generation.")

    factory_args: dict[str, Any] = Field(default_factory=dict, description="Arguments passed to factory functions.")

    @field_serializer("factory", when_used='json')
    def serialize_factory(self, factory: str | ModuleType | None) -> str | None:
        """Serialize factory to import path string for JSON.

        Note: Only called during JSON serialization (model_dump_json).

        Raises:
            ValueError: If factory module is __main__.
        """
        if factory is None:
            return None
        if isinstance(factory, str):
            return factory
        # Convert module to import path
        module_name = factory.__name__
        if module_name == "__main__":
            raise ValueError(
                "Cannot serialize factory module '__main__'. "
                "Use a string import path or import the factory from a module."
            )
        return module_name

    @classmethod
    def from_factory(
        cls,
        factory: str | ModuleType,
        args: dict[str, Any] | None = None,
        name: str | None = None,
        project_root: 'Path | None' = None,
        net_config: Any = None,
    ) -> "NodeConfig":
        """Create a NodeConfig from a factory module.

        Args:
            factory: Factory module or import path to module containing
                     get_node_config() and get_node_funcs().
            args: Arguments passed to both factory functions.
            name: Optional explicit node name. If provided, overrides the
                  factory-generated name. If None, uses the factory's default name.
            project_root: Base path for resolving relative file-path references.
            net_config: NetConfig instance passed to factory functions as _net_config.

        Returns:
            Complete NodeConfig with execution_config populated.

        Raises:
            ImportError: If factory module cannot be imported.
            AttributeError: If module missing get_node_config or get_node_funcs.
        """
        args = args or {}

        # Import module if string
        if isinstance(factory, str):
            if _is_file_path_ref(factory):
                module = _import_from_file_path(factory, project_root=project_root)
            else:
                module = importlib.import_module(factory)
        else:
            module = factory

        # Get factory functions
        get_node_config = getattr(module, "get_node_config")
        get_node_funcs = getattr(module, "get_node_funcs")

        # Call factories
        base_config = get_node_config(_net_config=net_config, **args)

        if isinstance(base_config, SubgraphConfig):
            raise ValueError(
                "from_factory() does not support subgraph factories. "
                "Use the 'factory' field in config instead."
            )

        exec_func, start_func, stop_func, on_failure_func = get_node_funcs(_net_config=net_config, **args)

        # Build execution config from functions
        execution_config = NodeExecutionConfig(
            exec_node_func=exec_func,
            start_node_func=start_func,
            stop_node_func=stop_func,
            on_node_failure=on_failure_func,
        )

        # Use explicit name if provided, otherwise use factory's default name
        node_name = name if name is not None else base_config.name

        # Return complete config (don't set factory/factory_args here - that's for the field-based path)
        return cls.model_construct(
            name=node_name,
            in_ports=base_config.in_ports,
            out_ports=base_config.out_ports,
            in_salvo_conditions=base_config.in_salvo_conditions,
            out_salvo_conditions=base_config.out_salvo_conditions,
            execution_config=execution_config,
            extra=base_config.extra,
        )

    def resolve(self, net_config: Any = None) -> "NodeConfig | SubgraphConfig":
        """Return a resolved copy with factory expanded and imports resolved.

        If this node has a factory set, expands it to generate the full config.
        Also resolves any string import paths in execution_config to callables.

        If the factory returns a SubgraphConfig, returns it directly with the
        NodeConfig's name and extra applied.

        Args:
            net_config: NetConfig instance for resolving project root and passed
                        to factory functions as _net_config.

        Returns:
            A NodeConfig with factory expanded and functions resolved,
            or a SubgraphConfig if the factory returned one.
            If no resolution is needed, returns self.
        """
        project_root = net_config.project_root_path if net_config is not None else None
        result = self

        # If factory is set, expand it
        if self.factory is not None:
            # Import module if string
            if isinstance(self.factory, str):
                factory_path = self.factory
                if _is_file_path_ref(self.factory):
                    module = _import_from_file_path(self.factory, project_root=project_root)
                else:
                    module = importlib.import_module(self.factory)
            else:
                factory_path = self.factory.__name__
                module = self.factory

            # Get node config factory function
            get_node_config_fn = getattr(module, "get_node_config")

            # Call get_node_config only (NOT get_node_funcs - that's resolved lazily on workers)
            # This avoids creating closures that can't be pickled for multiprocess pools.
            base_config = get_node_config_fn(_net_config=net_config, **self.factory_args)

            # If factory returned a SubgraphConfig, return it with name/extra applied
            if isinstance(base_config, SubgraphConfig):
                name = self.name if self.name else base_config.name
                merged_extra = {**base_config.extra, **self.extra}
                return base_config.model_copy(update={
                    "name": name,
                    "extra": merged_extra,
                })

            # Build execution config - exec_node_func is None because it will be
            # resolved lazily on workers using the factory info from NodeConfig
            factory_exec_config = NodeExecutionConfig(
                exec_node_func=None,
                start_node_func=None,
                stop_node_func=None,
                on_node_failure=None,
            )

            # Merge: base config first, then any explicit overrides from self
            merged_in_ports = {**base_config.in_ports, **self.in_ports}
            merged_out_ports = {**base_config.out_ports, **self.out_ports}

            # Merge salvo conditions (None means "use factory's", {} means "override with empty")
            if self.in_salvo_conditions is not None:
                merged_in_salvo = {**(base_config.in_salvo_conditions or {}), **self.in_salvo_conditions}
            else:
                merged_in_salvo = base_config.in_salvo_conditions  # Keep None or factory value

            if self.out_salvo_conditions is not None:
                merged_out_salvo = {**(base_config.out_salvo_conditions or {}), **self.out_salvo_conditions}
            else:
                merged_out_salvo = base_config.out_salvo_conditions  # Keep None or factory value

            # Use explicit name if provided, else factory name
            name = self.name if self.name else base_config.name

            # Merge execution configs if both exist
            if self.execution_config is not None:
                # Override factory exec_config with explicit fields
                exec_config_dict = factory_exec_config.model_dump()
                for field_name, value in self.execution_config.model_dump(exclude_defaults=True).items():
                    exec_config_dict[field_name] = value
                merged_exec_config = NodeExecutionConfig.model_validate(exec_config_dict)
            else:
                merged_exec_config = factory_exec_config

            # Merge extra: base config first, then explicit overrides from self
            merged_extra = {**base_config.extra, **self.extra}

            # Keep factory and factory_args in resolved config for lazy resolution on workers
            result = NodeConfig.model_construct(
                name=name,
                in_ports=merged_in_ports,
                out_ports=merged_out_ports,
                in_salvo_conditions=merged_in_salvo,
                out_salvo_conditions=merged_out_salvo,
                execution_config=merged_exec_config,
                extra=merged_extra,
                factory=factory_path,
                factory_args=self.factory_args,
            )

        # Resolve execution_config import paths
        if result.execution_config is not None:
            resolved_exec = result.execution_config.resolve(project_root=project_root)
            if resolved_exec is not result.execution_config:
                result = result.model_copy(update={"execution_config": resolved_exec})

        # Generate default salvo conditions if None
        updates = {}
        if result.in_salvo_conditions is None:
            updates["in_salvo_conditions"] = _generate_default_in_salvo_conditions(result.in_ports)
        if result.out_salvo_conditions is None:
            updates["out_salvo_conditions"] = _generate_default_out_salvo_conditions(result.out_ports)
        if updates:
            result = result.model_copy(update=updates)

        return result

    def to_netrun_sim(self) -> netrun_sim.Node:
        # Salvo conditions should be resolved before calling to_netrun_sim
        # but handle None gracefully by treating as empty dict
        in_salvos = self.in_salvo_conditions or {}
        out_salvos = self.out_salvo_conditions or {}

        return netrun_sim.Node(
            name=self.name,
            in_ports={name: port.to_netrun_sim() for name, port in self.in_ports.items()},
            out_ports={name: port.to_netrun_sim() for name, port in self.out_ports.items()},
            in_salvo_conditions={name: sc.to_netrun_sim() for name, sc in in_salvos.items()},
            out_salvo_conditions={name: sc.to_netrun_sim() for name, sc in out_salvos.items()},
        )

# %% [markdown]
# # Subgraph Configuration

# %% [markdown]
# ## Exposed Port Configuration
#
# Maps an exposed port on a subgraph to an internal node's port.

# %%
#|export
class ExposedPortConfig(EnvVarResolvableModel):
    """Maps an exposed port to an internal node's port.

    When a subgraph exposes a port, this config defines which internal
    node and port it maps to.

    Example:
        # Expose internal node "Processor"'s "input" port as "in"
        ExposedPortConfig(
            internal_node="Processor",
            internal_port="input",
            rename="in",  # Optional: exposed name (defaults to internal_port)
        )
    """
    internal_node: str
    """Name of the internal node (within the subgraph)."""

    internal_port: str
    """Name of the port on the internal node."""

    rename: str | None = None
    """Optional exposed name. If None, uses internal_port as the exposed name."""

    def get_exposed_name(self) -> str:
        """Get the name used for the exposed port."""
        return self.rename if self.rename is not None else self.internal_port

# %% [markdown]
# ## Subgraph Configuration
#
# A subgraph is a group of nodes that acts as a single node in the parent graph.
# Subgraphs can be defined inline (with nodes and edges) or by referencing an
# external .netrun.json file.

# %%
#|export
class SubgraphConfig(EnvVarResolvableModel):
    """A group of nodes that acts as a single node.

    Subgraphs can be defined in two ways:
    1. Inline: nodes and edges defined directly
    2. File reference: path to external .netrun.json file

    When resolved, all internal node names are prefixed with the subgraph name
    (e.g., "subgraph.internal_node"), and edges are rewritten accordingly.

    Example (inline):
        SubgraphConfig(
            name="preprocess",
            nodes=[
                NodeConfig(name="A", ...),
                NodeConfig(name="B", ...),
            ],
            edges=[EdgeConfig(source_str="A.out", target_str="B.in")],
            exposed_in_ports={"input": ExposedPortConfig(internal_node="A", internal_port="in")},
            exposed_out_ports={"output": ExposedPortConfig(internal_node="B", internal_port="out")},
        )

    Example (file reference):
        SubgraphConfig(
            name="preprocess",
            path="./subgraphs/preprocess.netrun.json",
            exposed_in_ports={"input": ExposedPortConfig(internal_node="A", internal_port="in")},
            exposed_out_ports={"output": ExposedPortConfig(internal_node="B", internal_port="out")},
        )
    """
    model_config = {"arbitrary_types_allowed": True}

    type: Literal["subgraph"] = "subgraph"
    """Discriminator field to distinguish from NodeConfig."""

    name: str
    """Name of this subgraph in the parent graph."""

    # Either inline OR file reference (not both)
    nodes: list["NodeConfig | SubgraphConfig"] | None = None
    """Inline nodes (mutually exclusive with path)."""

    edges: list[EdgeConfig] = Field(default_factory=list)
    """Internal edges between nodes in this subgraph."""

    path: str | None = None
    """Path to external .netrun.json file (mutually exclusive with nodes)."""

    # Exposed ports
    exposed_in_ports: dict[str, ExposedPortConfig] = Field(default_factory=dict)
    """Input ports exposed to the parent graph."""

    exposed_out_ports: dict[str, ExposedPortConfig] = Field(default_factory=dict)
    """Output ports exposed to the parent graph."""

    extra: dict[str, Any] = Field(default_factory=dict)
    """Arbitrary extra data for this subgraph."""

    @model_validator(mode='after')
    def validate_inline_or_path(self) -> "SubgraphConfig":
        """Validate that either inline nodes or path is provided, not both."""
        has_inline = self.nodes is not None
        has_path = self.path is not None

        if has_inline and has_path:
            raise ValueError(
                f"SubgraphConfig '{self.name}': cannot specify both 'nodes' and 'path'. "
                "Use either inline definition or file reference."
            )
        if not has_inline and not has_path:
            raise ValueError(
                f"SubgraphConfig '{self.name}': must specify either 'nodes' (inline) or 'path' (file reference)."
            )
        return self

    def _load_from_file(self, base_path: Path | None = None) -> tuple[list["NodeConfig | SubgraphConfig"], list[EdgeConfig]]:
        """Load nodes and edges from external file.

        Args:
            base_path: Base path for resolving relative file paths.

        Returns:
            Tuple of (nodes, edges) from the external file.

        Raises:
            FileNotFoundError: If the file doesn't exist.
            ValueError: If the file doesn't contain valid graph config.
        """
        if self.path is None:
            raise ValueError("No path specified for file-based subgraph")

        file_path = Path(self.path)
        if not file_path.is_absolute() and base_path is not None:
            file_path = base_path / file_path

        if not file_path.exists():
            raise FileNotFoundError(f"Subgraph file not found: {file_path}")

        with open(file_path) as f:
            data = json.load(f)

        # The file should contain a GraphConfig or NetConfig structure
        # We extract just the graph portion
        if "graph" in data:
            # NetConfig format
            graph_data = data["graph"]
        else:
            # GraphConfig format
            graph_data = data

        if "nodes" not in graph_data:
            raise ValueError(f"Subgraph file {file_path} must contain 'nodes' field")

        # Parse nodes - need to handle both NodeConfig and SubgraphConfig
        nodes = []
        for node_data in graph_data.get("nodes", []):
            if node_data.get("type") == "subgraph":
                nodes.append(SubgraphConfig.model_validate(node_data))
            else:
                nodes.append(NodeConfig.model_validate(node_data))

        edges = [EdgeConfig.model_validate(e) for e in graph_data.get("edges", [])]

        return nodes, edges

    def resolve(
        self,
        base_path: Path | None = None,
        _seen_paths: set[str] | None = None,
    ) -> tuple[list["NodeConfig"], list[EdgeConfig], dict[str, str], dict[str, str]]:
        """Resolve this subgraph to flat nodes and edges with prefixed names.

        Args:
            base_path: Base path for resolving relative file paths.
            _seen_paths: Set of already-seen file paths (for circular reference detection).

        Returns:
            Tuple of:
            - nodes: List of resolved NodeConfig with prefixed names
            - edges: List of EdgeConfig with prefixed node references
            - in_port_mapping: Dict mapping exposed port name to "prefixed_node.port"
            - out_port_mapping: Dict mapping exposed port name to "prefixed_node.port"

        Raises:
            ValueError: If circular reference detected or validation fails.
        """
        _seen_paths = _seen_paths or set()

        # Detect circular references for file-based subgraphs
        if self.path is not None:
            abs_path = str(Path(self.path).resolve() if Path(self.path).is_absolute()
                          else (base_path / self.path).resolve() if base_path else Path(self.path).resolve())
            if abs_path in _seen_paths:
                raise ValueError(f"Circular subgraph reference detected: {abs_path}")
            _seen_paths = _seen_paths | {abs_path}

        # Get nodes and edges (from inline or file)
        if self.nodes is not None:
            nodes_to_resolve = self.nodes
            edges_to_resolve = self.edges
        else:
            nodes_to_resolve, edges_to_resolve = self._load_from_file(base_path)

        # Resolve nested subgraphs and flatten
        resolved_nodes: list[NodeConfig] = []
        # Track name mappings for nested subgraphs
        nested_in_mappings: dict[str, dict[str, str]] = {}
        nested_out_mappings: dict[str, dict[str, str]] = {}

        for node in nodes_to_resolve:
            if isinstance(node, SubgraphConfig):
                # Recursively resolve nested subgraph
                nested_nodes, nested_edges, nested_in_map, nested_out_map = node.resolve(
                    base_path=base_path,
                    _seen_paths=_seen_paths,
                )
                resolved_nodes.extend(nested_nodes)
                edges_to_resolve = list(edges_to_resolve) + nested_edges
                nested_in_mappings[node.name] = nested_in_map
                nested_out_mappings[node.name] = nested_out_map
            else:
                resolved_nodes.append(node)

        # Prefix all node names with subgraph name
        prefixed_nodes: list[NodeConfig] = []
        for node in resolved_nodes:
            prefixed_name = f"{self.name}.{node.name}"
            prefixed_node = node.model_copy(update={"name": prefixed_name})
            prefixed_nodes.append(prefixed_node)

        # Rewrite edges with prefixed names
        prefixed_edges: list[EdgeConfig] = []
        for edge in edges_to_resolve:
            source = edge.get_source()
            target = edge.get_target()

            # Check if source/target refers to a nested subgraph's exposed port
            source_node = source.node_name
            target_node = target.node_name

            # Handle nested subgraph port references
            if source_node in nested_out_mappings:
                # Source is a nested subgraph - map to actual internal port
                mapping = nested_out_mappings[source_node]
                if source.port_name in mapping:
                    mapped = mapping[source.port_name]
                    node_name, port_name = mapped.rsplit(".", 1)
                    source_node = node_name
                    source = PortRefConfig(node_name=source_node, port_type="output", port_name=port_name)

            if target_node in nested_in_mappings:
                # Target is a nested subgraph - map to actual internal port
                mapping = nested_in_mappings[target_node]
                if target.port_name in mapping:
                    mapped = mapping[target.port_name]
                    node_name, port_name = mapped.rsplit(".", 1)
                    target_node = node_name
                    target = PortRefConfig(node_name=target_node, port_type="input", port_name=port_name)

            prefixed_edge = EdgeConfig(
                source=PortRefConfig(
                    node_name=f"{self.name}.{source.node_name}",
                    port_type=source.port_type,
                    port_name=source.port_name,
                ),
                target=PortRefConfig(
                    node_name=f"{self.name}.{target.node_name}",
                    port_type=target.port_type,
                    port_name=target.port_name,
                ),
            )
            prefixed_edges.append(prefixed_edge)

        # Build port mappings for exposed ports
        in_port_mapping: dict[str, str] = {}
        for exposed_name, config in self.exposed_in_ports.items():
            internal_node = config.internal_node
            # Check if internal_node is a nested subgraph
            if internal_node in nested_in_mappings:
                mapping = nested_in_mappings[internal_node]
                if config.internal_port in mapping:
                    # Map through nested subgraph
                    mapped = mapping[config.internal_port]
                    in_port_mapping[exposed_name] = f"{self.name}.{mapped}"
                    continue
            in_port_mapping[exposed_name] = f"{self.name}.{internal_node}.{config.internal_port}"

        out_port_mapping: dict[str, str] = {}
        for exposed_name, config in self.exposed_out_ports.items():
            internal_node = config.internal_node
            # Check if internal_node is a nested subgraph
            if internal_node in nested_out_mappings:
                mapping = nested_out_mappings[internal_node]
                if config.internal_port in mapping:
                    # Map through nested subgraph
                    mapped = mapping[config.internal_port]
                    out_port_mapping[exposed_name] = f"{self.name}.{mapped}"
                    continue
            out_port_mapping[exposed_name] = f"{self.name}.{internal_node}.{config.internal_port}"

        return prefixed_nodes, prefixed_edges, in_port_mapping, out_port_mapping


# Need to rebuild models for forward references
SubgraphConfig.model_rebuild()
