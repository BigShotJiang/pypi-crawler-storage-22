# ---
# jupyter:
#   kernelspec:
#     display_name: .venv
#     language: python
#     name: python3
# ---

# %%
#|default_exp net._net._net

# %%
#|hide
from nblite import nbl_export; nbl_export();

# %% [markdown]
# # Net Class
#
# The `Net` class is the main orchestrator that:
# 1. Wraps `netrun-sim` to manage packet flow simulation
# 2. Executes node functions via `ExecutionManager`
# 3. Manages packet values in `PacketStore`
# 4. Handles errors, retries, and print capture

# %%
#|export
import asyncio
import signal
import time
from datetime import datetime
from pathlib import Path
from typing import Any
from collections.abc import Callable

import netrun_sim
from netrun.pool.thread import ThreadPool
from netrun.pool.multiprocess import MultiprocessPool
from netrun.pool.aio import SingleWorkerPool
from netrun.pool.remote import RemotePoolClient
from netrun.net.config import NetConfig, NodeExecutionConfig, PortConfig, RemotePoolConfig
from netrun.execution_manager import ExecutionManager, PoolType, RunAllocationMethod
from netrun._iutils import get_timestamp_utc
from netrun.storage import PacketStore
from netrun.caching._store import NetCacheStore, CachedEpochData
from netrun.caching.config import CacheWhat

from netrun.net._net._context import (
    EpochError,
    MaxEpochsExceeded,
    EpochRecord,
    NodeExecutionResult,
    NodeFailureContext,
    ConsumedOutputPacket,
    create_net_func_preprocessor,
    _FactoryPlaceholder,
)
from netrun.net._net._info import NodeInfo, EdgeInfo
from netrun.net._net._run_to_targets import (
    TargetInputSalvo,
    _compute_upstream_nodes,
    _classify_epoch,
)

# %%
#|export
class _ServerLogCallback:
    """Picklable callback that logs execution results to a file.

    Unlike a closure, this can be pickled and sent to subprocess workers.
    Each process lazily opens its own file handle in append mode.
    """

    def __init__(self, log_file_path: str):
        self._path = log_file_path
        self._fh = None

    def _log(self, message: str):
        if self._fh is None:
            self._fh = open(self._path, "a")
        self._fh.write(f"[{datetime.now().strftime('%H:%M:%S.%f')[:-3]}] {message}\n")
        self._fh.flush()

    def __call__(self, *args, result=None, **kwargs):
        if result is None:
            return
        node_name = args[1] if len(args) > 1 else "unknown"
        status = "error" if result.exception else "ok"
        self._log(f"[{node_name}] execution {status}")
        if hasattr(result, "print_buffer") and result.print_buffer:
            for _ts, msg in result.print_buffer:
                self._log(f"[{node_name}] {msg}")

    def close(self):
        """Close the file handle if open."""
        if self._fh is not None:
            self._fh.close()
            self._fh = None

    def __getstate__(self):
        # Don't pickle the file handle — each process opens its own
        state = self.__dict__.copy()
        state["_fh"] = None
        return state

# %%
#|export
class _PoolServerContext:
    """Async context manager for Net.serve_pool.

    Wraps RemotePoolServer.serve_background() and adds optional log file output.
    """

    def __init__(self, server, host, port, log_file=None, done_callback=None):
        self._server = server
        self._host = host
        self._port = port
        self._log_file = log_file
        self._log_fh = None
        self._inner_ctx = None
        self._done_callback = done_callback

    def _log(self, message: str):
        if self._log_fh:
            self._log_fh.write(f"[{datetime.now().strftime('%H:%M:%S.%f')[:-3]}] {message}\n")
            self._log_fh.flush()

    async def start(self):
        """Start the pool server."""
        if self._log_file:
            self._log_fh = open(self._log_file, 'a')
        self._inner_ctx = self._server.serve_background(self._host, self._port)
        server = await self._inner_ctx.__aenter__()
        self._log(f"Pool server started on {self._host}:{self._port}")
        return server

    async def stop(self):
        """Stop the pool server."""
        try:
            if self._inner_ctx is not None:
                await self._inner_ctx.__aexit__(None, None, None)
        finally:
            self._log("Pool server stopped")
            if self._log_fh:
                self._log_fh.close()
                self._log_fh = None
            if self._done_callback is not None:
                self._done_callback.close()

    async def wait_until_stopped(self) -> None:
        """Wait until a client requests shutdown via Net.request_pool_shutdown()."""
        await self._server.wait_for_shutdown()

    async def __aenter__(self):
        return await self.start()

    async def __aexit__(self, *exc_info):
        await self.stop()

# %%
#|export
class Net:
    """Main orchestrator for flow-based network execution.

    The Net class bridges netrun-sim (packet flow simulation) with actual node
    function execution via ExecutionManager.
    """

    def __init__(self, config: NetConfig):
        """Initialize the Net with the given configuration.

        Args:
            config: The NetConfig defining pools, graph, and execution settings.
        """
        self._config: NetConfig = config
        self._config_resolved: NetConfig = config.resolve()
        self._graph: netrun_sim.Graph = self._config_resolved.graph.get_graph()
        self._netsim = netrun_sim.NetSim(self._graph)
        self._started: bool = False
        self._paused: bool = False
        self._stopping: bool = False

        # Packet value storage
        self._packet_store = PacketStore()

        # Rate limiting tracking
        self._epoch_start_times: dict[str, list[float]] = {}  # node_name -> list of timestamps

        # Running epoch tracking
        self._running_epochs: set[str] = set()

        # Epoch records (persists after epoch finishes in netsim)
        self._epochs: dict[str, EpochRecord] = {}  # epoch_id -> EpochRecord

        # Total epoch counts per node (for max_epochs enforcement)
        self._node_epoch_counts: dict[str, int] = {}  # node_name -> count

        # Dead letter queue for failed epochs
        self._dead_letter_queue: list[dict[str, Any]] = []

        # Exception queue for non-propagating epoch failures
        self._exception_queue: list[Exception] = []

        # Track which nodes have had start_node_func called
        self._started_nodes: set[str] = set()

        # Build node execution configs lookup (using resolved config for runtime)
        self._node_execution_configs: dict[str, NodeExecutionConfig] = {}
        for node_config in self._config_resolved.graph.nodes:
            if node_config.execution_config is not None:
                self._node_execution_configs[node_config.name] = node_config.execution_config

        # Build node output ports lookup (for type validation)
        self._node_out_ports: dict[str, dict[str, PortConfig]] = {}
        for node_config in self._config_resolved.graph.nodes:
            if node_config.out_ports:
                self._node_out_ports[node_config.name] = node_config.out_ports

        # Build node factories lookup (for lazy resolution on workers)
        self._node_factories: dict[str, tuple[str, dict[str, Any]]] = {}
        for node_config in self._config_resolved.graph.nodes:
            if node_config.factory:
                self._node_factories[node_config.name] = (
                    node_config.factory,
                    node_config.factory_args,
                )

        # Create func_preprocessor with node configs
        func_preprocessor = create_net_func_preprocessor(
            self._node_execution_configs,
            self._node_out_ports,
            self._node_factories,
            net_node_vars=self._config_resolved.node_vars,
            net_type_checking_enabled=self._config_resolved.type_checking_enabled,
            net_config_data=self._config.model_dump(),
        )
        # Validate RemotePoolConfig fields are set before constructing pools
        for pool_name, pool_config in self._config_resolved.pools.items():
            spec = pool_config.spec
            if isinstance(spec, RemotePoolConfig):
                missing = []
                if spec.url is None:
                    missing.append("url")
                if spec.worker_name is None:
                    missing.append("worker_name")
                if missing:
                    raise ValueError(
                        f"Pool '{pool_name}': RemotePoolConfig fields "
                        f"{', '.join(missing)} must be set before running the Net"
                    )

        # Build ExecutionManager config
        _exec_manager_config = {}
        for pool_name, pool_config in self._config_resolved.pools.items():
            match pool_config.spec.type:
                case "main":
                    pool_type = SingleWorkerPool
                case "thread":
                    pool_type = ThreadPool
                case "multiprocess":
                    pool_type = MultiprocessPool
                case "remote":
                    pool_type = RemotePoolClient
                case _:
                    raise ValueError(f"Invalid pool type: {pool_config.spec.type}")

            _init_kwargs = pool_config.spec.model_dump()
            _init_kwargs.pop("type")
            _init_kwargs["func_preprocessor"] = func_preprocessor
            _exec_manager_config[pool_name] = (pool_type, _init_kwargs)

        self._execution_manager = ExecutionManager(_exec_manager_config)

        # Background task for main loop
        self._background_task: asyncio.Task | None = None

        # SIGINT handling
        self._sigint_received: bool = False
        self._original_sigint_handler = None

        # Output queues for collecting packets from unconnected output ports
        self._output_queues: dict[str, asyncio.Queue[ConsumedOutputPacket]] = {}
        self._port_to_queue: dict[tuple[str, str], str] = {}  # (node_name, port_name) -> queue_name

        # Initialize queues from resolved config (includes auto-generated queues)
        resolved_output_queues = self._config_resolved.output_queues or {}
        for queue_name, queue_config in resolved_output_queues.items():
            self._output_queues[queue_name] = asyncio.Queue()
            for node_name, port_name in queue_config.ports:
                self._port_to_queue[(node_name, port_name)] = queue_name

        # Cache store
        cache_config = self._config_resolved.cache
        self._cache_store = NetCacheStore(cache_config)
        for node_config in self._config_resolved.graph.nodes:
            node_cache = None
            if node_config.execution_config and node_config.execution_config.cache:
                node_cache = node_config.execution_config.cache
            self._cache_store.register_node(node_config.name, node_cache)


    @classmethod
    def from_file(cls, path: 'str | Path') -> "Net":
        """Load a Net from a JSON or TOML configuration file.

        Args:
            path: Path to the config file (.json or .toml).

        Returns:
            A Net instance initialized from the config file.

        Raises:
            FileNotFoundError: If the file does not exist.
            ValueError: If the file format is unsupported.
        """
        config = NetConfig.from_file(path)
        return cls(config)

    @staticmethod
    def _create_func_preprocessor_from_config(config_resolved: NetConfig):
        """Create a func_preprocessor from a resolved NetConfig.

        Extracts node execution configs, output ports, and factory info from
        the resolved config and creates a NetFuncPreprocessor.

        Args:
            config_resolved: A resolved NetConfig (after calling .resolve()).

        Returns:
            A func_preprocessor callable for use with ExecutionManager/RemotePoolServer.
        """
        node_execution_configs = {}
        node_out_ports = {}
        node_factories = {}

        for node_config in config_resolved.graph.nodes:
            if node_config.execution_config is not None:
                node_execution_configs[node_config.name] = node_config.execution_config
            if node_config.out_ports:
                node_out_ports[node_config.name] = node_config.out_ports
            if node_config.factory:
                node_factories[node_config.name] = (
                    node_config.factory,
                    node_config.factory_args,
                )

        return create_net_func_preprocessor(
            node_execution_configs,
            node_out_ports,
            node_factories,
            net_node_vars=config_resolved.node_vars,
            net_type_checking_enabled=config_resolved.type_checking_enabled,
            net_config_data=config_resolved.model_dump(),
        )

    @classmethod
    def serve_pool(
        cls,
        config: 'NetConfig | str | Path',
        host: str = "0.0.0.0",
        port: int = 8080,
        *,
        log_file: 'str | Path | None' = None,
        worker_name: str = "execution_manager",
    ) -> _PoolServerContext:
        """Create a remote pool server from a Net config.

        The server uses the same func_preprocessor as Net, enabling factory-based
        nodes and NodeExecutionContext on remote workers.

        Returns an async context manager. Use as::

            async with Net.serve_pool(config_path, host, port):
                ...  # server is running

        Or for Jupyter (non-blocking)::

            pool_ctx = Net.serve_pool(config_path, host, port)
            await pool_ctx.start()
            # ... later ...
            await pool_ctx.stop()

        Or wait for a client to request shutdown::

            pool_ctx = Net.serve_pool(config_path, host, port)
            await pool_ctx.start()
            await pool_ctx.wait_until_stopped()
            await pool_ctx.stop()

        Args:
            config: NetConfig, or path to a .json/.toml config file.
            host: Host to bind to.
            port: Port to listen on.
            log_file: Optional path to write server logs to.
            worker_name: Worker name for the execution manager protocol.

        Returns:
            An async context manager (_PoolServerContext) that starts/stops the server.
        """
        from netrun.execution_manager import create_execution_manager_server as _create_em_server

        if isinstance(config, (str, Path)):
            config = NetConfig.from_file(config)
        config_resolved = config.resolve()

        func_preprocessor = cls._create_func_preprocessor_from_config(config_resolved)

        done_callback = _ServerLogCallback(log_file) if log_file else None
        ctx = _PoolServerContext(None, host, port, log_file, done_callback)

        server = _create_em_server(
            worker_name=worker_name,
            func_preprocessor=func_preprocessor,
            func_done_callback=done_callback,
        )
        ctx._server = server

        return ctx

    @property
    def config(self) -> NetConfig:
        """Get the original (unresolved) Net configuration.

        This returns the config as it was passed to the constructor, before
        any factory expansion or import path resolution. Use this for
        serialization or introspection of the original config.
        """
        return self._config

    @property
    def config_resolved(self) -> NetConfig:
        """Get the resolved Net configuration.

        This returns the config with all factories expanded and import paths
        resolved to actual callables. This is used internally for execution.
        """
        return self._config_resolved

    @property
    def graph(self) -> netrun_sim.Graph:
        """Get the netrun-sim Graph."""
        return self._graph

    @property
    def netsim(self) -> netrun_sim.NetSim:
        """Get the netrun-sim NetSim instance."""
        return self._netsim

    @property
    def pools(self) -> list[tuple[str, type[PoolType]]]:
        """Get list of (pool_id, pool_type) tuples."""
        return self._execution_manager.pools

    @property
    def started(self) -> bool:
        """Check if the Net has been started."""
        return self._started

    @property
    def paused(self) -> bool:
        """Check if the Net is paused."""
        return self._paused

    @property
    def dead_letter_queue(self) -> list[dict[str, Any]]:
        """Get the dead letter queue containing failed epochs.

        Each entry contains:
        - epoch_id: The failed epoch ID
        - node_name: The node name
        - error: The exception that caused failure
        - retry_count: Number of retries attempted
        - retry_timestamps: Timestamps of each retry attempt
        - retry_exceptions: Exceptions from each retry attempt
        - packets: The input packets for the epoch
        """
        return list(self._dead_letter_queue)

    @property
    def epochs(self) -> dict[str, EpochRecord]:
        """Get all epoch records (including completed and cancelled).

        Returns a shallow copy of the internal epochs dict.
        """
        return dict(self._epochs)

    def clear_dead_letter_queue(self) -> list[dict[str, Any]]:
        """Clear the dead letter queue and return its contents.

        Returns:
            The contents of the dead letter queue before clearing.
        """
        items = self._dead_letter_queue.copy()
        self._dead_letter_queue.clear()
        return items

    @property
    def exception_queue(self) -> list[Exception]:
        """Get queued exceptions (from nodes with propagate_exceptions=False).

        Returns a copy of the internal exception queue.
        """
        return list(self._exception_queue)

    def propagate_exceptions(self) -> None:
        """Raise all queued exceptions, clearing the queue.

        Raises:
            ExceptionGroup: If multiple exceptions are queued.
            Exception: If exactly one exception is queued.
        """
        if not self._exception_queue:
            return
        exceptions = self._exception_queue.copy()
        self._exception_queue.clear()
        if len(exceptions) == 1:
            raise exceptions[0]
        raise ExceptionGroup("Multiple epoch failures", exceptions)

    def _get_effective_exception_config(self, config: 'NodeExecutionConfig | None') -> tuple[bool, bool]:
        """Resolve effective (propagate_exceptions, print_exceptions) for a node.

        Args:
            config: The node's execution config, or None.

        Returns:
            Tuple of (propagate_exceptions, print_exceptions).
        """
        propagate = self._config_resolved.propagate_exceptions
        print_exc = self._config_resolved.print_exceptions
        if config is not None:
            if config.propagate_exceptions is not None:
                propagate = config.propagate_exceptions
            if config.print_exceptions is not None:
                print_exc = config.print_exceptions
        return propagate, print_exc

    def _route_orphaned_packet(
        self,
        packet_id: str,
        from_node: str,
        from_port: str,
        epoch_id: str,
    ) -> None:
        """Route an orphaned packet to the appropriate output queue.

        Called when a packet is sent from an unconnected output port.

        Args:
            packet_id: The packet ID.
            from_node: The node that produced this packet.
            from_port: The output port that produced this packet.
            epoch_id: The epoch that produced this packet.
        """
        # Check if port is configured for a specific queue
        queue_name = self._port_to_queue.get((from_node, from_port))

        if queue_name is None:
            if self._config.error_on_undeclared_output:
                raise RuntimeError(
                    f"Packet {packet_id} sent from unconnected output port "
                    f"'{from_port}' on node '{from_node}' but no output queue configured"
                )
            else:
                # Discard: consume value and return
                self._packet_store.consume(packet_id)
                return

        # Get value and create ConsumedOutputPacket
        value = self._packet_store.consume(packet_id)
        output_packet = ConsumedOutputPacket(
            packet_id=packet_id,
            value=value,
            from_node=from_node,
            from_port=from_port,
            queue_name=queue_name,
            timestamp=get_timestamp_utc(),
            epoch_id=epoch_id,
        )

        # Add to queue
        self._output_queues[queue_name].put_nowait(output_packet)

    # --- Output Queue Retrieval API ---

    async def get_output(
        self,
        queue_name: str | None = None,
        *,
        node: str | None = None,
        port: str | None = None,
        timeout: float | None = None,
        include_metadata: bool = False,
    ) -> Any:
        """Get the next output value from an output queue.

        Args:
            queue_name: Name of the output queue. Mutually exclusive with node/port.
            node: Node name (keyword-only). Must be used with port.
            port: Port name (keyword-only). Must be used with node.
            timeout: Max seconds to wait. None = wait forever.
            include_metadata: If True, return a ConsumedOutputPacket with full
                metadata. If False (default), return just the value.

        Returns:
            The packet value (default), or ConsumedOutputPacket if include_metadata=True.

        Raises:
            ValueError: If neither queue_name nor node/port specified.
            ValueError: If both queue_name and node/port specified.
            KeyError: If queue_name not found or node/port not configured.
            asyncio.TimeoutError: If timeout exceeded.
        """
        queue_name = self._resolve_queue_name(queue_name, node, port)
        queue = self._output_queues.get(queue_name)
        if queue is None:
            raise KeyError(f"Output queue '{queue_name}' not found")

        if timeout is not None:
            packet = await asyncio.wait_for(queue.get(), timeout=timeout)
        else:
            packet = await queue.get()
        return packet if include_metadata else packet.value

    def try_get_output(
        self,
        queue_name: str | None = None,
        *,
        node: str | None = None,
        port: str | None = None,
        include_metadata: bool = False,
    ) -> Any:
        """Get an output value if available, otherwise return None.

        Non-blocking - returns immediately.

        Args:
            queue_name: Name of the output queue. Mutually exclusive with node/port.
            node: Node name (keyword-only). Must be used with port.
            port: Port name (keyword-only). Must be used with node.
            include_metadata: If True, return a ConsumedOutputPacket with full
                metadata. If False (default), return just the value.

        Returns:
            The packet value (default), ConsumedOutputPacket if include_metadata=True,
            or None if queue is empty.
        """
        queue_name = self._resolve_queue_name(queue_name, node, port)
        queue = self._output_queues.get(queue_name)
        if queue is None:
            raise KeyError(f"Output queue '{queue_name}' not found")

        try:
            packet = queue.get_nowait()
            return packet if include_metadata else packet.value
        except asyncio.QueueEmpty:
            return None

    def flush_output_queue(
        self,
        queue_name: str | None = None,
        *,
        node: str | None = None,
        port: str | None = None,
        include_metadata: bool = False,
    ) -> list[Any]:
        """Get all currently available output values from a single queue.

        Non-blocking - returns whatever is currently in the queue.

        Args:
            queue_name: Name of the output queue. Mutually exclusive with node/port.
            node: Node name (keyword-only). Must be used with port.
            port: Port name (keyword-only). Must be used with node.
            include_metadata: If True, return ConsumedOutputPacket objects with full
                metadata. If False (default), return just the values.

        Returns:
            List of values (default), or list of ConsumedOutputPackets if
            include_metadata=True.
        """
        queue_name = self._resolve_queue_name(queue_name, node, port)
        queue = self._output_queues.get(queue_name)
        if queue is None:
            raise KeyError(f"Output queue '{queue_name}' not found")

        packets = []
        while True:
            try:
                packets.append(queue.get_nowait())
            except asyncio.QueueEmpty:
                break
        if include_metadata:
            return packets
        return [p.value for p in packets]

    def flush_all_output_queues(
        self,
        *,
        include_metadata: bool = False,
    ) -> dict[str, list[Any]]:
        """Get all currently available output values from all queues.

        Non-blocking - drains all queues and returns their contents.

        Args:
            include_metadata: If True, return ConsumedOutputPacket objects with full
                metadata. If False (default), return just the values.

        Returns:
            Dict mapping queue_name -> list of values (default), or
            dict mapping queue_name -> list of ConsumedOutputPackets if
            include_metadata=True.
        """
        result = {}
        for queue_name in list(self._output_queues.keys()):
            items = self.flush_output_queue(queue_name, include_metadata=include_metadata)
            if items:  # Only include non-empty queues
                result[queue_name] = items
        return result

    def has_output(
        self,
        queue_name: str | None = None,
        *,
        node: str | None = None,
        port: str | None = None,
    ) -> bool:
        """Check if the queue has any packets available.

        Args:
            queue_name: Name of the output queue. Mutually exclusive with node/port.
            node: Node name (keyword-only). Must be used with port.
            port: Port name (keyword-only). Must be used with node.

        Returns:
            True if the queue has packets, False otherwise.
        """
        queue_name = self._resolve_queue_name(queue_name, node, port)
        queue = self._output_queues.get(queue_name)
        if queue is None:
            raise KeyError(f"Output queue '{queue_name}' not found")
        return not queue.empty()

    def output_count(
        self,
        queue_name: str | None = None,
        *,
        node: str | None = None,
        port: str | None = None,
    ) -> int:
        """Get the number of packets in the queue.

        Args:
            queue_name: Name of the output queue. Mutually exclusive with node/port.
            node: Node name (keyword-only). Must be used with port.
            port: Port name (keyword-only). Must be used with node.

        Returns:
            Number of packets currently in the queue.
        """
        queue_name = self._resolve_queue_name(queue_name, node, port)
        queue = self._output_queues.get(queue_name)
        if queue is None:
            raise KeyError(f"Output queue '{queue_name}' not found")
        return queue.qsize()

    def list_output_queues(self) -> list[str]:
        """List all configured output queue names.

        Returns:
            List of output queue names.
        """
        return list(self._output_queues.keys())

    def _resolve_queue_name(
        self,
        queue_name: str | None,
        node: str | None,
        port: str | None,
    ) -> str:
        """Resolve queue name from either queue_name or node/port.

        Args:
            queue_name: Direct queue name.
            node: Node name (requires port).
            port: Port name (requires node).

        Returns:
            The resolved queue name.

        Raises:
            ValueError: If arguments are invalid.
            KeyError: If node/port not configured for any queue.
        """
        has_queue_name = queue_name is not None
        has_node_port = node is not None or port is not None

        if has_queue_name and has_node_port:
            raise ValueError("Cannot specify both queue_name and node/port")
        if not has_queue_name and not has_node_port:
            raise ValueError("Must specify either queue_name or node/port")

        if has_queue_name:
            return queue_name

        if node is None or port is None:
            raise ValueError("Must specify both node and port")

        resolved = self._port_to_queue.get((node, port))
        if resolved is None:
            raise KeyError(f"No output queue configured for port '{port}' on node '{node}'")
        return resolved

    # --- Graph Query API ---

    def get_edges_from_port(self, node_name: str, port_name: str) -> list:
        """Get all edges connected to an output port.

        Useful for checking if an output port has downstream connections.

        Args:
            node_name: The node name.
            port_name: The output port name.

        Returns:
            List of Edge objects connected to this port.
            Empty list if port is unconnected (dangling).
        """
        edges = []
        for edge in self._graph.edges():
            if edge.source.node_name == node_name and edge.source.port_name == port_name:
                edges.append(edge)
        return edges

    def has_downstream_connection(self, node_name: str, port_name: str) -> bool:
        """Check if an output port has any downstream connections.

        Returns False if the port is "dangling" (no edges connected).

        Args:
            node_name: The node name.
            port_name: The output port name.

        Returns:
            True if the port has at least one downstream edge, False otherwise.
        """
        return len(self.get_edges_from_port(node_name, port_name)) > 0

    # --- Packet Creation & Injection API ---

    def create_external_packet(self, value: Any) -> str:
        """Create a packet outside the network with a value.

        The packet is created in the OutsideNet location and can be
        transported to input ports using inject_packet().

        Args:
            value: The value to store in the packet.

        Returns:
            The packet ID (ULID string).
        """
        response, _ = self._netsim.do_action(netrun_sim.NetAction.create_packet(None))
        packet_id = str(response.packet_id)
        self._packet_store.register(packet_id, value)
        return packet_id

    def create_external_packets(self, values: list[Any]) -> list[str]:
        """Create multiple packets outside the network.

        Args:
            values: List of values to store in packets.

        Returns:
            List of packet IDs in the same order as values.
        """
        packet_ids = []
        for value in values:
            packet_id = self.create_external_packet(value)
            packet_ids.append(packet_id)
        return packet_ids

    def inject_packet(self, packet_id: str, node_name: str, port_name: str) -> None:
        """Transport a packet to a node's input port.

        Args:
            packet_id: The packet ID to transport.
            node_name: Target node name.
            port_name: Target input port name.

        Raises:
            RuntimeError: If the transport fails (e.g., port doesn't exist or is full).
        """
        response, _ = self._netsim.do_action(
            netrun_sim.NetAction.transport_packet_to_location(
                packet_id,
                netrun_sim.PacketLocation.input_port(node_name, port_name),
            )
        )
        # Check for errors in response
        if hasattr(response, 'error') and response.error:
            raise RuntimeError(f"Failed to inject packet: {response.error}")

    def inject_data(self, node_name: str, port_name: str, values: list[Any]) -> list[str]:
        """Create packets with values and inject them into a node's input port.

        This is a convenience method that combines create_external_packets()
        and inject_packet() into a single call.

        Args:
            node_name: Target node name.
            port_name: Target input port name.
            values: List of values to create packets for.

        Returns:
            List of created packet IDs.

        Example:
            packet_ids = net.inject_data("Source", "in", [
                {"id": 1, "data": "hello"},
                {"id": 2, "data": "world"},
            ])
        """
        packet_ids = self.create_external_packets(values)
        for packet_id in packet_ids:
            self.inject_packet(packet_id, node_name, port_name)
        return packet_ids

    def _get_node_execution_config(self, node_name: str) -> NodeExecutionConfig | None:
        """Get the execution config for a node."""
        return self._node_execution_configs.get(node_name)

    def _check_rate_limit(self, node_name: str) -> bool:
        """Check if node can start a new epoch based on rate limit.

        Rate limit is global across all pools for the node.

        Args:
            node_name: The name of the node.

        Returns:
            True if the node can start a new epoch, False otherwise.
        """
        config = self._get_node_execution_config(node_name)
        if config is None or config.rate_limit_per_second is None:
            return True

        now = time.time()
        window_start = now - 1.0  # 1 second window

        # Clean old entries
        self._epoch_start_times[node_name] = [
            t for t in self._epoch_start_times.get(node_name, [])
            if t > window_start
        ]

        # Check limit
        if len(self._epoch_start_times[node_name]) >= config.rate_limit_per_second:
            return False

        # Record this start
        self._epoch_start_times.setdefault(node_name, []).append(now)
        return True

    def _handle_print_buffer(self, epoch_id: str, buffer: list[tuple[datetime, str]]) -> None:
        """Handle print buffer received from a worker.

        Args:
            epoch_id: The epoch that sent the prints.
            buffer: List of (timestamp, message) tuples. Timestamps are captured
                    at the time ctx.print() was called in the worker.
        """
        # Store on epoch record
        record = self._epochs.get(epoch_id)
        if record is not None:
            record.logs.extend(buffer)


    def get_epoch_log(self, epoch_id: str) -> list[tuple[datetime, str]]:
        """Get print output for a specific epoch.

        Args:
            epoch_id: The epoch ID.

        Returns:
            List of (timestamp, message) tuples.
        """
        record = self._epochs.get(epoch_id)
        if record is None:
            return []
        return list(record.logs)

    def get_node_logs(self, node_name: str) -> list[tuple[datetime, str]]:
        """Get all print output for a node (across all epochs).

        Args:
            node_name: The node name.

        Returns:
            List of (timestamp, message) tuples.
        """
        logs = []
        for record in self._epochs.values():
            if record.node_name == node_name:
                logs.extend(record.logs)
        return logs

    def get_all_logs(self) -> dict[str, dict[str, list[tuple[datetime, str]]]]:
        """Get all print logs across all epochs and nodes.

        Returns:
            Dictionary mapping node_name -> epoch_id -> list of (timestamp, message) tuples.
        """
        logs = {}
        for epoch_id, record in self._epochs.items():
            if record.logs:
                logs.setdefault(record.node_name, {})[epoch_id] = list(record.logs)
        return logs

    def get_all_logs_chronological(self) -> list[tuple[datetime, str, str, str]]:
        """Get all print logs across all epochs, sorted by timestamp.

        Returns:
            List of (timestamp, epoch_id, node_name, message) tuples,
            sorted by timestamp ascending.
        """
        all_logs = []

        for epoch_id, record in self._epochs.items():
            for timestamp, message in record.logs:
                all_logs.append((timestamp, epoch_id, record.node_name, message))

        # Sort by timestamp
        all_logs.sort(key=lambda x: x[0])
        return all_logs

    def list_epoch_log_ids(self) -> list[str]:
        """Get all epoch IDs that have print logs.

        Returns:
            List of epoch IDs with logs.
        """
        return [eid for eid, r in self._epochs.items() if r.logs]

    def list_node_log_names(self) -> list[str]:
        """Get all node names that have print logs.

        Returns:
            List of node names with logs.
        """
        names = []
        seen = set()
        for record in self._epochs.values():
            if record.logs and record.node_name not in seen:
                seen.add(record.node_name)
                names.append(record.node_name)
        return names

    def print_epoch_logs(self, epoch_id: str, include_timestamps: bool = True) -> None:
        """Print the logs for a specific epoch."""
        logs = self.get_epoch_log(epoch_id)
        for timestamp, message in logs:
            if include_timestamps:
                print(f"[{timestamp.strftime('%H:%M:%S.%f')[:-3]}] {message.strip()}")
            else:
                print(message.strip())

    def _epoch_header(self, record: EpochRecord) -> str:
        """Format an epoch header line with optional pool/worker info."""
        header = f"--- Epoch {record.id}"
        if record.pool_worker_label is not None:
            header += f" [{record.pool_worker_label}]"
        header += " ---"
        return header

    def print_node_logs(self, node_name: str, include_timestamps: bool = True, chronological: bool = False) -> None:
        """Print all logs for a node, grouped by epoch or chronologically."""
        if chronological:
            logs = self.get_node_logs(node_name)
            for record in self._epochs.values():
                if record.node_name != node_name:
                    continue
                for timestamp, message in record.logs:
                    if include_timestamps:
                        print(f"[{timestamp.strftime('%H:%M:%S.%f')[:-3]}] [{record.id}] {message.strip()}")
                    else:
                        print(f"[{record.id}] {message.strip()}")
        else:
            for record in self._epochs.values():
                if record.node_name != node_name or not record.logs:
                    continue
                print(self._epoch_header(record))
                record.print_logs(include_timestamps=include_timestamps)

    def print_all_logs(self, include_timestamps: bool = True, chronological: bool = False) -> None:
        """Print all logs, grouped by node/epoch or chronologically."""
        if chronological:
            logs = self.get_all_logs_chronological()
            for timestamp, epoch_id, node_name, message in logs:
                if include_timestamps:
                    print(f"[{timestamp.strftime('%H:%M:%S.%f')[:-3]}] [{node_name}] {message.strip()}")
                else:
                    print(f"[{node_name}] {message.strip()}")
        else:
            for node_name in self.list_node_log_names():
                print(f"=== {node_name} ===")
                for record in self._epochs.values():
                    if record.node_name != node_name or not record.logs:
                        continue
                    print(self._epoch_header(record))
                    record.print_logs(include_timestamps=include_timestamps)

    async def start(self) -> None:
        """Start the Net.

        This starts the ExecutionManager, all pools, registers node functions,
        and calls start_node_func for nodes that don't have defer_startup.
        """
        if self._started:
            raise RuntimeError("Net already started")

        await self._execution_manager.start()

        # Register node functions with all workers
        await self._register_node_functions()

        # Call start_node_func for non-deferred nodes
        await self._start_all_nodes()

        self._started = True

    def start_sync(self) -> None:
        """Start the Net synchronously.

        Blocking wrapper for start().
        """
        asyncio.run(self.start())

    async def stop(self) -> None:
        """Stop the Net gracefully.

        This calls stop_node_func for all started nodes, stops the background
        task, and closes the ExecutionManager.
        """
        self._stopping = True

        # Call stop_node_func for all started nodes
        await self._stop_all_nodes()

        # Cancel background task if running
        if self._background_task is not None:
            self._background_task.cancel()
            try:
                await self._background_task
            except asyncio.CancelledError:
                pass
            self._background_task = None

        await self._execution_manager.close()
        self._cache_store.close()
        self._started = False
        self._stopping = False

    async def request_pool_shutdown(self, pool_id: str, timeout: float = 10.0) -> None:
        """Request a remote pool server to shut down.

        Sends a shutdown request to the remote server and waits for acknowledgement.
        The server-side ``_PoolServerContext.wait_until_stopped()`` will resolve
        once this request is received.

        Args:
            pool_id: The ID of the remote pool.
            timeout: Timeout in seconds for waiting for the acknowledgement.

        Raises:
            TypeError: If the pool is not a RemotePoolClient.
        """
        pool = self._execution_manager.get_pool(pool_id)
        if not isinstance(pool, RemotePoolClient):
            raise TypeError(f"Pool '{pool_id}' is not a RemotePoolClient")
        await pool.request_shutdown(timeout=timeout)

    def stop_sync(self) -> None:
        """Stop the Net synchronously.

        Blocking wrapper for stop().
        """
        asyncio.run(self.stop())

    async def pause(self) -> None:
        """Pause the Net.

        Finish running epochs but don't start new ones.
        """
        self._paused = True

    async def resume(self) -> None:
        """Resume the Net after pausing."""
        self._paused = False

    async def start_background(self) -> None:
        """Start the Net in a background task.

        This starts the Net and creates a background task that continuously
        runs the execution loop. The loop will:
        - Run simulation steps to move packets
        - Execute startable epochs
        - Handle SIGINT for graceful shutdown

        Use `stop()` to gracefully stop the background execution.
        """
        if not self._started:
            await self.start()

        if self._background_task is not None:
            raise RuntimeError("Background task already running")

        # Install SIGINT handler
        self._install_sigint_handler()

        # Start the background loop
        self._background_task = asyncio.create_task(self._run_loop())

    async def _run_loop(self) -> None:
        """Main execution loop for background mode.

        This loop:
        1. Checks if we should stop or pause
        2. Runs simulation steps (which moves packets and executes epochs)
        3. Yields to allow other tasks to run
        """
        try:
            while not self._stopping and not self._sigint_received:
                if self._paused:
                    # When paused, just sleep and check again
                    await asyncio.sleep(0.01)
                    continue

                # Run simulation step (auto-starts epochs by default)
                made_progress, _ = await self.run_step()

                # Small yield to allow other tasks
                if not made_progress:
                    # If nothing happened, sleep a bit to avoid busy-waiting
                    await asyncio.sleep(0.001)
                else:
                    # Just yield to allow other tasks
                    await asyncio.sleep(0)
        finally:
            # Restore SIGINT handler
            self._restore_sigint_handler()

    def _install_sigint_handler(self) -> None:
        """Install a SIGINT handler for graceful shutdown."""
        def sigint_handler(signum, frame):
            self._sigint_received = True

        self._original_sigint_handler = signal.signal(signal.SIGINT, sigint_handler)

    def _restore_sigint_handler(self) -> None:
        """Restore the original SIGINT handler."""
        if self._original_sigint_handler is not None:
            signal.signal(signal.SIGINT, self._original_sigint_handler)
            self._original_sigint_handler = None

    async def wait_until_done(self) -> None:
        """Wait for the background task to complete.

        This blocks until:
        - All epochs have finished and no packets can move
        - SIGINT is received
        - `stop()` is called from another task
        """
        if self._background_task is not None:
            await self._background_task

    def is_blocked(self) -> bool:
        """Check if the network is blocked (no progress can be made).

        Returns:
            True if no packets can move and no epochs are running.
        """
        # Check if there are any startable or running epochs
        if self.get_startable_epochs():
            return False
        if self._running_epochs:
            return False

        # Check if any packets can move from edges to input ports
        return self._netsim.is_blocked()

    async def run_step(self, *, auto_start_epochs: bool = True) -> tuple[bool, list]:
        """Run one simulation step.

        This moves packets through the network and optionally executes
        any startable epochs.

        Args:
            auto_start_epochs: If True (default), automatically execute any
                startable epochs after moving packets. Set to False to only
                move packets without executing epochs.

        Returns:
            Tuple of (made_progress, events) where:
            - made_progress: True if any packets were moved or epochs executed
            - events: List of NetEvents that occurred during the step
        """
        result = self._netsim.run_step()
        # netrun-sim returns (bool, events)
        if isinstance(result, tuple):
            made_progress, events = result
            events = list(events) if not isinstance(events, list) else events
        else:
            # Fallback for direct list return
            events = list(result) if not isinstance(result, list) else result
            made_progress = len(events) > 0

        # Auto-start epochs if enabled
        if auto_start_epochs:
            startable = self.get_startable_epochs()
            if startable:
                startable = self._filter_by_max_parallel_epochs(startable)
            if startable:
                # Execute epochs concurrently
                tasks = [
                    asyncio.create_task(self._execute_epoch(epoch_id))
                    for epoch_id in startable
                ]
                if tasks:
                    results = await asyncio.gather(*tasks, return_exceptions=True)
                    # Collect exceptions that propagated (propagate_exceptions=True nodes)
                    exceptions = [r for r in results if isinstance(r, Exception)]
                    made_progress = True

                    if exceptions:
                        if len(exceptions) == 1:
                            raise exceptions[0]
                        raise ExceptionGroup("Multiple epoch failures", exceptions)

        return (made_progress, events)

    async def run_until_blocked(self, *, auto_start_epochs: bool = True) -> tuple[bool, list]:
        """Run the simulation until no more progress can be made.

        Args:
            auto_start_epochs: If True (default), automatically execute any
                startable epochs after moving packets. Set to False to only
                move packets without executing epochs.

        Returns:
            Tuple of (made_progress, events) where:
            - made_progress: True if any run_step made progress
            - events: All NetEvents that occurred
        """
        all_events = []
        any_progress = False
        while True:
            made_progress, events = await self.run_step(auto_start_epochs=auto_start_epochs)
            all_events.extend(events)
            if made_progress:
                any_progress = True
            if not made_progress:
                break
        return (any_progress, all_events)

    def get_startable_epochs(self) -> list[str]:
        """Get list of epoch IDs that are ready to start."""
        epochs = self._netsim.get_startable_epochs()
        return list(epochs) if not isinstance(epochs, list) else epochs

    def get_running_epochs(self) -> list[str]:
        """Get list of currently running epoch IDs."""
        return list(self._running_epochs)

    def _filter_by_max_parallel_epochs(self, epoch_ids: list[str]) -> list[str]:
        """Filter startable epochs based on max_parallel_epochs limits.

        For each node, only allows up to max_parallel_epochs concurrent
        running epochs. Epochs beyond the limit are skipped and will remain
        startable for future run_step() calls.

        Args:
            epoch_ids: List of startable epoch IDs.

        Returns:
            Filtered list of epoch IDs that are allowed to start.
        """
        # Count currently running epochs per node
        running_per_node: dict[str, int] = {}
        for eid in self._running_epochs:
            record = self._epochs.get(eid)
            if record:
                running_per_node[record.node_name] = running_per_node.get(record.node_name, 0) + 1

        allowed = []
        # Track how many new epochs we're allowing per node (within this batch)
        new_per_node: dict[str, int] = {}

        for epoch_id in epoch_ids:
            epoch = self._netsim.get_epoch(epoch_id)
            node_name = epoch.node_name
            config = self._get_node_execution_config(node_name)
            max_parallel = config.max_parallel_epochs if config else None

            if max_parallel is not None:
                current = running_per_node.get(node_name, 0) + new_per_node.get(node_name, 0)
                if current >= max_parallel:
                    continue  # Skip — at the limit

            new_per_node[node_name] = new_per_node.get(node_name, 0) + 1
            allowed.append(epoch_id)

        return allowed

    def _get_func_key(self, node_name: str) -> str:
        """Get the function key for a node's exec_node_func.

        Args:
            node_name: The node name.

        Returns:
            A unique function key for this node.
        """
        return f"net:node:{node_name}"

    def _get_input_packet_values(self, epoch_id: str) -> tuple[dict[str, list[str]], dict[str, Any]]:
        """Get the input packets and their values for an epoch.

        Args:
            epoch_id: The epoch ID.

        Returns:
            Tuple of (packets, packet_values) where:
            - packets: dict mapping port_name -> list of packet_ids
            - packet_values: dict mapping packet_id -> value
        """
        epoch = self._netsim.get_epoch(epoch_id)

        # Get input salvo (packets by port)
        packets: dict[str, list[str]] = {}
        packet_values: dict[str, Any] = {}

        # The epoch's in_salvo is a Salvo object with .packets as list of (port_name, packet_id) tuples
        in_salvo = epoch.in_salvo
        if in_salvo:
            # Convert list of (port_name, packet_id) tuples to dict[port_name, list[packet_id]]
            for port_name, packet_id in in_salvo.packets:
                if port_name not in packets:
                    packets[port_name] = []
                packets[port_name].append(str(packet_id))
                # Peek at the value from PacketStore (don't consume yet - that happens in _commit_epoch_result)
                value = self._packet_store._get(packet_id)
                packet_values[str(packet_id)] = value

        return packets, packet_values

    def _commit_epoch_result(self, epoch_id: str, result: NodeExecutionResult) -> dict[str, str]:
        """Commit the deferred actions from an epoch's execution result.

        Args:
            epoch_id: The epoch ID.
            result: The NodeExecutionResult from the worker.

        Returns:
            Mapping of deferred packet IDs to real packet IDs.
        """
        deferred_to_real: dict[str, str] = {}

        # Process each deferred action in order
        for action_type, args in result.deferred_actions.actions:
            if action_type == "create_packet":
                deferred_id, value = args

                # Create packet in netsim (inside the epoch) - netsim assigns the real ID
                response, _ = self._netsim.do_action(netrun_sim.NetAction.create_packet(epoch_id))
                real_id = str(response.packet_id)
                deferred_to_real[deferred_id] = real_id

                # Store value in PacketStore using the netsim-assigned ID
                self._packet_store.register(real_id, value)

            elif action_type == "consume_packet":
                packet_id, = args
                # Map deferred IDs if needed (though consume usually uses real IDs)
                real_packet_id = deferred_to_real.get(packet_id, packet_id)

                # Consume from PacketStore
                self._packet_store.consume(real_packet_id)

                # Consume in netsim
                self._netsim.do_action(netrun_sim.NetAction.consume_packet(real_packet_id))

            elif action_type == "load_output_port":
                port_name, packet_id = args
                # Map deferred ID to real ID
                real_packet_id = deferred_to_real.get(packet_id, packet_id)

                # Load into output port in netsim
                self._netsim.do_action(
                    netrun_sim.NetAction.load_packet_into_output_port(real_packet_id, port_name)
                )

            elif action_type == "send_output_salvo":
                salvo_condition_name, = args

                # Send output salvo in netsim
                self._netsim.do_action(
                    netrun_sim.NetAction.send_output_salvo(epoch_id, salvo_condition_name)
                )

                # Check for orphaned packets (sent to unconnected output ports)
                # and route them to output queues
                epoch = self._netsim.get_epoch(epoch_id)
                if epoch.orphaned_packets:
                    for orphaned_info in epoch.orphaned_packets:
                        self._route_orphaned_packet(
                            packet_id=orphaned_info.packet_id,
                            from_node=epoch.node_name,
                            from_port=orphaned_info.from_port,
                            epoch_id=epoch_id,
                        )

        return deferred_to_real

    async def execute_epoch(self, epoch_id: str) -> NodeExecutionResult | None:
        """Execute a single startable epoch.

        This is the public API for manually executing epochs. It:
        1. Checks rate limiting
        2. Starts the epoch in netsim
        3. Dispatches the node function to a worker
        4. Waits for completion
        5. Commits deferred actions (on success) or handles failure with retries

        Args:
            epoch_id: The ID of the epoch to execute. Must be a startable epoch.

        Returns:
            The NodeExecutionResult if execution succeeded, None if skipped
            (e.g., due to rate limiting or no execution function).

        Raises:
            Exception: If the node function raises and max retries exceeded.

        Example:
            startable = net.get_startable_epochs()
            if startable:
                result = await net.execute_epoch(startable[0])
        """
        return await self._execute_epoch(epoch_id)

    async def _execute_epoch(self, epoch_id: str) -> NodeExecutionResult | None:
        """Internal: Execute a single startable epoch with retry support.

        Args:
            epoch_id: The ID of the epoch to execute.

        Returns:
            The NodeExecutionResult if execution succeeded, None if skipped.
        """
        epoch = self._netsim.get_epoch(epoch_id)
        node_name = epoch.node_name
        self._epochs[epoch_id] = EpochRecord.from_epoch(epoch)
        config = self._get_node_execution_config(node_name)

        # Check if node has an execution function (either direct or via factory)
        has_exec_func = (
            config is not None and
            (config.exec_node_func is not None or node_name in self._node_factories)
        )
        if not has_exec_func:
            # No execution function - just mark as running and finish immediately
            self._netsim.do_action(netrun_sim.NetAction.start_epoch(epoch_id))
            self._epochs[epoch_id].started_at = get_timestamp_utc()
            self._netsim.do_action(netrun_sim.NetAction.finish_epoch(epoch_id))
            self._epochs[epoch_id].ended_at = get_timestamp_utc()
            self._epochs[epoch_id].state = netrun_sim.EpochState.Finished
            return None

        # Deferred startup: call start_node_func on first epoch if not yet started
        if node_name not in self._started_nodes:
            await self._start_node(node_name)

        # Check rate limiting
        if not self._check_rate_limit(node_name):
            return None  # Will be retried on next call

        # Check max_epochs limit
        self._node_epoch_counts[node_name] = self._node_epoch_counts.get(node_name, 0) + 1
        if config is not None and config.max_epochs is not None:
            if self._node_epoch_counts[node_name] > config.max_epochs:
                # Cancel the epoch and raise
                response, _ = self._netsim.do_action(netrun_sim.NetAction.cancel_epoch(epoch_id))
                record = self._epochs[epoch_id]
                record.was_cancelled = True
                record.ended_at = get_timestamp_utc()
                record.destroyed_packets = list(response.destroyed_packets)

                error = MaxEpochsExceeded(node_name, config.max_epochs)
                propagate, print_exc = self._get_effective_exception_config(config)

                if print_exc:
                    import sys
                    print(f"MaxEpochsExceeded: {error}", file=sys.stderr)

                epoch_error = EpochError(
                    str(error), node_name=node_name, epoch_id=epoch_id,
                )
                epoch_error.__cause__ = error

                if propagate:
                    raise epoch_error from error
                else:
                    self._exception_queue.append(epoch_error)
                    return None

        # Get input packet values
        packets, packet_values = self._get_input_packet_values(epoch_id)

        # Cache check
        input_hash = None
        if self._cache_store.is_cache_enabled(node_name):
            effective_cache = self._cache_store.get_effective_config(node_name)
            cache_what = effective_cache["cache_what"]
            input_hash = self._cache_store.hash_input_salvo(
                node_name, packets, self._packet_store,
            )

            if cache_what == CacheWhat.BOTH:
                cached = self._cache_store.lookup(node_name, input_hash)
                if cached is not None:
                    return await self._replay_cached_epoch(epoch_id, node_name, cached, packets)

        # Transition epoch to Running
        self._netsim.do_action(netrun_sim.NetAction.start_epoch(epoch_id))
        self._epochs[epoch_id].started_at = get_timestamp_utc()
        self._epochs[epoch_id].state = netrun_sim.EpochState.Running
        self._running_epochs.add(epoch_id)

        try:
            return await self._execute_epoch_with_retry(
                epoch_id=epoch_id,
                node_name=node_name,
                config=config,
                packets=packets,
                packet_values=packet_values,
                retry_count=0,
                retry_timestamps=[],
                retry_exceptions=[],
                input_hash=input_hash,
            )
        finally:
            self._running_epochs.discard(epoch_id)

    async def _execute_epoch_with_retry(
        self,
        epoch_id: str,
        node_name: str,
        config: NodeExecutionConfig,
        packets: dict[str, list[str]],
        packet_values: dict[str, Any],
        retry_count: int,
        retry_timestamps: list[datetime],
        retry_exceptions: list[Exception],
        input_hash: int | None = None,
    ) -> NodeExecutionResult | None:
        """Execute an epoch with retry support.

        Args:
            epoch_id: The epoch ID.
            node_name: The node name.
            config: The node's execution config.
            packets: Input packets by port name.
            packet_values: Packet ID to value mapping.
            retry_count: Current retry count.
            retry_timestamps: Timestamps of previous retry attempts.
            retry_exceptions: Exceptions from previous retry attempts.
            input_hash: Hash of input salvo for caching (None if caching disabled).

        Returns:
            The NodeExecutionResult if successful, None if cancelled.
        """
        # Determine allocation method
        allocation_method = (
            config.pool_allocation_method or
            self._config.default_pool_allocation_method
        )

        # Get func key for this node
        func_key = self._get_func_key(node_name)

        # Dispatch to worker (with optional timeout)
        try:
            coro = self._execution_manager.run_allocate(
                pool_worker_ids=config.pools,
                allocation_method=allocation_method,
                func_import_path_or_key=func_key,
                send_channel=False,  # Deferred mode doesn't need channel
                func_args=(epoch_id, node_name, packets, packet_values),
                func_kwargs={
                    "retry_count": retry_count,
                    "retry_timestamps": retry_timestamps,
                    "retry_exceptions": retry_exceptions,
                },
            )
            if config.timeout is not None:
                job_result = await asyncio.wait_for(coro, timeout=config.timeout)
            else:
                job_result = await coro
        except asyncio.TimeoutError:
            return await self._handle_epoch_failure(
                epoch_id=epoch_id,
                node_name=node_name,
                config=config,
                packets=packets,
                packet_values=packet_values,
                error=TimeoutError(
                    f"Node '{node_name}' exceeded timeout of {config.timeout}s"
                ),
                retry_count=retry_count,
                retry_timestamps=retry_timestamps,
                retry_exceptions=retry_exceptions,
                input_hash=input_hash,
            )

        # Extract NodeExecutionResult from job result
        execution_result: NodeExecutionResult = job_result.result

        # Record which pool/worker ran this epoch
        self._epochs[epoch_id].pool_id = job_result.pool_id
        self._epochs[epoch_id].worker_id = job_result.worker_id

        # Handle print buffer
        if execution_result.print_buffer:
            self._handle_print_buffer(epoch_id, execution_result.print_buffer)

        # Check for errors
        if execution_result.exception is not None:
            return await self._handle_epoch_failure(
                epoch_id=epoch_id,
                node_name=node_name,
                config=config,
                packets=packets,
                packet_values=packet_values,
                error=execution_result.exception,
                retry_count=retry_count,
                retry_timestamps=retry_timestamps,
                retry_exceptions=retry_exceptions,
                pool_id=job_result.pool_id,
                worker_id=job_result.worker_id,
                input_hash=input_hash,
            )

        if execution_result.cancelled:
            # Epoch was cancelled via ctx.cancel_epoch()
            response, _ = self._netsim.do_action(netrun_sim.NetAction.cancel_epoch(epoch_id))
            record = self._epochs[epoch_id]
            record.was_cancelled = True
            record.ended_at = get_timestamp_utc()
            record.destroyed_packets = list(response.destroyed_packets)
            return execution_result

        # Success - commit deferred actions
        self._commit_epoch_result(epoch_id, execution_result)

        # Refresh fields that changed during commit (before finish removes the epoch)
        epoch_snapshot = self._netsim.get_epoch(epoch_id)
        self._epochs[epoch_id].out_salvos = list(epoch_snapshot.out_salvos)
        self._epochs[epoch_id].orphaned_packets = list(epoch_snapshot.orphaned_packets)

        # Cache storage after successful execution
        if input_hash is not None and self._cache_store.is_cache_enabled(node_name):
            self._store_epoch_in_cache(
                epoch_id, node_name, input_hash, packets, packet_values, execution_result,
            )

        # Finish the epoch
        self._netsim.do_action(netrun_sim.NetAction.finish_epoch(epoch_id))
        self._epochs[epoch_id].ended_at = get_timestamp_utc()
        self._epochs[epoch_id].state = netrun_sim.EpochState.Finished

        return execution_result

    async def _replay_cached_epoch(
        self,
        epoch_id: str,
        node_name: str,
        cached: CachedEpochData,
        packets: dict[str, list[str]],
    ) -> NodeExecutionResult:
        """Replay a cached epoch without executing the node function.

        Args:
            epoch_id: The epoch ID.
            node_name: The node name.
            cached: The cached epoch data.
            packets: Input packets by port name (current epoch's packets).

        Returns:
            A synthetic NodeExecutionResult representing the replayed epoch.
        """
        # Start epoch in netsim
        self._netsim.do_action(netrun_sim.NetAction.start_epoch(epoch_id))
        self._epochs[epoch_id].started_at = get_timestamp_utc()
        self._epochs[epoch_id].state = netrun_sim.EpochState.Running

        # Consume input packets
        for port_name in cached.consumed_input_ports:
            if port_name in packets:
                for packet_id in packets[port_name]:
                    self._packet_store.consume(packet_id)
                    self._netsim.do_action(netrun_sim.NetAction.consume_packet(packet_id))

        # Create output packets and load into output ports
        for port_name, values in cached.output_port_values.items():
            for value in values:
                response, _ = self._netsim.do_action(netrun_sim.NetAction.create_packet(epoch_id))
                real_id = str(response.packet_id)
                self._packet_store.register(real_id, value)
                self._netsim.do_action(
                    netrun_sim.NetAction.load_packet_into_output_port(real_id, port_name)
                )

        # Send output salvos
        for salvo_name in cached.output_salvo_names:
            self._netsim.do_action(
                netrun_sim.NetAction.send_output_salvo(epoch_id, salvo_name)
            )
            # Handle orphaned packets
            epoch = self._netsim.get_epoch(epoch_id)
            if epoch.orphaned_packets:
                for orphaned_info in epoch.orphaned_packets:
                    self._route_orphaned_packet(
                        packet_id=orphaned_info.packet_id,
                        from_node=node_name,
                        from_port=orphaned_info.from_port,
                        epoch_id=epoch_id,
                    )

        # Snapshot and finish
        epoch_snapshot = self._netsim.get_epoch(epoch_id)
        self._epochs[epoch_id].out_salvos = list(epoch_snapshot.out_salvos)
        self._epochs[epoch_id].orphaned_packets = list(epoch_snapshot.orphaned_packets)
        self._epochs[epoch_id].was_cache_hit = True

        self._netsim.do_action(netrun_sim.NetAction.finish_epoch(epoch_id))
        self._epochs[epoch_id].ended_at = get_timestamp_utc()
        self._epochs[epoch_id].state = netrun_sim.EpochState.Finished

        # Return a synthetic result
        from netrun.net._net._context import DeferredActionQueue
        return NodeExecutionResult(
            cancelled=False,
            deferred_actions=DeferredActionQueue(),
            print_buffer=[],
            created_packets=[],
            consumed_packets=[],
            exception=None,
        )

    def _store_epoch_in_cache(
        self,
        epoch_id: str,
        node_name: str,
        input_hash: int,
        packets: dict[str, list[str]],
        packet_values: dict[str, Any],
        execution_result: NodeExecutionResult,
    ) -> None:
        """Build and store CachedEpochData from a successful execution.

        Args:
            epoch_id: The epoch ID.
            node_name: The node name.
            input_hash: Hash of the input salvo.
            packets: Input packets by port name.
            packet_values: Packet ID to value mapping.
            execution_result: The successful execution result.
        """
        effective_cache = self._cache_store.get_effective_config(node_name)
        cache_what = effective_cache["cache_what"]

        # Build input values by port
        input_values_by_port: dict[str, list[Any]] = {}
        for port_name, pkt_ids in packets.items():
            input_values_by_port[port_name] = [packet_values[pid] for pid in pkt_ids]

        if cache_what == CacheWhat.INPUT_ONLY:
            cached_data = CachedEpochData(
                input_salvo_hash=input_hash,
                net_version=effective_cache["net_version"],
                node_version=effective_cache["node_version"],
                input_values_by_port=input_values_by_port,
                output_port_values={},
                output_salvo_names=[],
                consumed_input_ports=set(),
                node_name=node_name,
                original_epoch_id=epoch_id,
            )
            self._cache_store.store(cached_data)
            return

        # BOTH or OUTPUT_ONLY: extract outputs from deferred actions
        output_port_values: dict[str, list[Any]] = {}
        output_salvo_names: list[str] = []
        consumed_input_ports: set[str] = set()
        # Map deferred packet IDs to their values
        deferred_packet_values: dict[str, Any] = {}

        for action_type, args in execution_result.deferred_actions.actions:
            if action_type == "create_packet":
                deferred_id, value = args
                deferred_packet_values[deferred_id] = value
            elif action_type == "consume_packet":
                packet_id, = args
                # Find which port this packet belonged to
                for port_name, pkt_ids in packets.items():
                    if packet_id in pkt_ids:
                        consumed_input_ports.add(port_name)
                        break
            elif action_type == "load_output_port":
                port_name, packet_id = args
                if port_name not in output_port_values:
                    output_port_values[port_name] = []
                value = deferred_packet_values.get(packet_id, packet_values.get(packet_id))
                output_port_values[port_name].append(value)
            elif action_type == "send_output_salvo":
                salvo_name, = args
                output_salvo_names.append(salvo_name)

        cached_data = CachedEpochData(
            input_salvo_hash=input_hash,
            net_version=effective_cache["net_version"],
            node_version=effective_cache["node_version"],
            input_values_by_port=input_values_by_port,
            output_port_values=output_port_values,
            output_salvo_names=output_salvo_names,
            consumed_input_ports=consumed_input_ports,
            node_name=node_name,
            original_epoch_id=epoch_id,
        )
        self._cache_store.store(cached_data)

    async def _handle_epoch_failure(
        self,
        epoch_id: str,
        node_name: str,
        config: NodeExecutionConfig,
        packets: dict[str, list[str]],
        packet_values: dict[str, Any],
        error: Exception,
        retry_count: int,
        retry_timestamps: list[datetime],
        retry_exceptions: list[Exception],
        pool_id: str | None = None,
        worker_id: int | None = None,
        input_hash: int | None = None,
    ) -> NodeExecutionResult | None:
        """Handle a failed epoch execution with retry logic.

        Args:
            epoch_id: The epoch ID.
            node_name: The node name.
            config: The node's execution config.
            packets: Input packets by port name.
            packet_values: Packet ID to value mapping.
            error: The exception that occurred.
            retry_count: Current retry count.
            retry_timestamps: Timestamps of previous retry attempts.
            retry_exceptions: Exceptions from previous retry attempts.
            pool_id: The pool that ran the epoch.
            worker_id: The worker that ran the epoch.
            input_hash: Hash of input salvo for caching (None if caching disabled).

        Returns:
            NodeExecutionResult if retry succeeds, None if max retries exceeded.

        Raises:
            EpochError: If propagate_exceptions is True and max retries exceeded.
        """
        # Update retry tracking
        new_retry_timestamps = retry_timestamps + [get_timestamp_utc()]
        new_retry_exceptions = retry_exceptions + [error]

        # Call on_node_failure callback if configured
        if config.on_node_failure is not None:
            failure_ctx = NodeFailureContext(
                epoch_id=epoch_id,
                node_name=node_name,
                retry_count=retry_count,
                exception=error,
                retry_timestamps=new_retry_timestamps,
                retry_exceptions=new_retry_exceptions,
                input_salvo=packets,
                pool_id=pool_id,
                worker_id=worker_id,
            )
            await self._call_failure_callback(config.on_node_failure, failure_ctx)

        # Check if we should retry
        if retry_count < config.retries:
            # Wait before retry
            if config.retry_wait > 0:
                await asyncio.sleep(config.retry_wait)

            # Retry (deferred actions were discarded, so we start fresh)
            return await self._execute_epoch_with_retry(
                epoch_id=epoch_id,
                node_name=node_name,
                config=config,
                packets=packets,
                packet_values=packet_values,
                retry_count=retry_count + 1,
                retry_timestamps=new_retry_timestamps,
                retry_exceptions=new_retry_exceptions,
                input_hash=input_hash,
            )
        else:
            # Max retries exceeded - cancel the epoch
            response, _ = self._netsim.do_action(netrun_sim.NetAction.cancel_epoch(epoch_id))
            record = self._epochs[epoch_id]
            record.was_cancelled = True
            record.ended_at = get_timestamp_utc()
            record.destroyed_packets = list(response.destroyed_packets)

            # Store in dead letter queue
            self._dead_letter_queue.append({
                "epoch_id": epoch_id,
                "node_name": node_name,
                "error": error,
                "retry_count": retry_count,
                "retry_timestamps": new_retry_timestamps,
                "retry_exceptions": new_retry_exceptions,
                "packets": packets,
                "pool_id": pool_id,
                "worker_id": worker_id,
            })

            # Resolve effective exception config
            propagate, print_exc = self._get_effective_exception_config(config)

            if print_exc:
                import sys
                import traceback
                pool_info = f", pool='{pool_id}'" if pool_id is not None else ""
                worker_info = f", worker={worker_id}" if worker_id is not None else ""
                print(f"Exception in epoch {epoch_id} (node '{node_name}'{pool_info}{worker_info}):", file=sys.stderr)
                traceback.print_exception(type(error), error, error.__traceback__, file=sys.stderr)

            # Wrap the error in EpochError with full context
            epoch_error = EpochError(
                str(error), node_name=node_name, epoch_id=epoch_id,
                pool_id=pool_id, worker_id=worker_id,
                retry_count=retry_count,
            )
            epoch_error.__cause__ = error

            if propagate:
                raise epoch_error from error
            else:
                self._exception_queue.append(epoch_error)
                return None

    async def _call_failure_callback(
        self,
        callback: Callable | str,
        failure_ctx: NodeFailureContext,
    ) -> None:
        """Call an on_node_failure callback.

        Args:
            callback: The callback function or import path.
            failure_ctx: The failure context.
        """
        if isinstance(callback, str):
            # Import from path
            import importlib
            module_path, func_name = callback.rsplit(".", 1)
            module = importlib.import_module(module_path)
            callback = getattr(module, func_name)

        # Call the callback (may be sync or async)
        result = callback(failure_ctx)
        if asyncio.iscoroutine(result):
            await result

        # Collect any prints from the failure callback into the epoch's logs
        if failure_ctx._print_buffer:
            self._handle_print_buffer(failure_ctx.epoch_id, failure_ctx._print_buffer)

    async def execute_startable_epochs(self) -> list[tuple[str, NodeExecutionResult | None]]:
        """Execute all currently startable epochs.

        Returns:
            List of (epoch_id, result) tuples for epochs that were executed.
            Results may be None if the epoch was skipped (no exec func or rate limited).
        """
        results = []
        startable = self.get_startable_epochs()

        for epoch_id in startable:
            try:
                result = await self._execute_epoch(epoch_id)
                results.append((epoch_id, result))
            except Exception as e:
                # Store error but continue with other epochs
                results.append((epoch_id, None))
                # Re-raise if on_error is "raise"
                # For now, just log the error
                import sys
                print(f"Error executing epoch {epoch_id}: {e}", file=sys.stderr)

        return results

    def _import_from_path(self, import_path: str) -> Any:
        """Import a function or type from a dotted import path.

        Args:
            import_path: Dotted import path (e.g., "myapp.utils.process_data").

        Returns:
            The imported object.

        Raises:
            ImportError: If the module cannot be imported.
            AttributeError: If the attribute doesn't exist in the module.
        """
        import importlib
        module_path, name = import_path.rsplit(".", 1)
        module = importlib.import_module(module_path)
        return getattr(module, name)

    def _get_node_start_func(self, node_name: str) -> Callable | None:
        """Get the start_node_func for a node, resolving from config or factory.

        Args:
            node_name: The node name.

        Returns:
            The start function, or None if not configured.
        """
        config = self._get_node_execution_config(node_name)
        if config is None:
            return None

        func = config.start_node_func
        if func is not None:
            if isinstance(func, str):
                func = self._import_from_path(func)
            return func

        # Check factory
        if node_name in self._node_factories:
            factory_path, factory_args = self._node_factories[node_name]
            import importlib
            module = importlib.import_module(factory_path)
            get_node_funcs = getattr(module, "get_node_funcs", None)
            if get_node_funcs is not None:
                _, start_func, _, _ = get_node_funcs(_net_config=self._config, **factory_args)
                return start_func

        return None

    def _get_node_stop_func(self, node_name: str) -> Callable | None:
        """Get the stop_node_func for a node, resolving from config or factory.

        Args:
            node_name: The node name.

        Returns:
            The stop function, or None if not configured.
        """
        config = self._get_node_execution_config(node_name)
        if config is None:
            return None

        func = config.stop_node_func
        if func is not None:
            if isinstance(func, str):
                func = self._import_from_path(func)
            return func

        # Check factory
        if node_name in self._node_factories:
            factory_path, factory_args = self._node_factories[node_name]
            import importlib
            module = importlib.import_module(factory_path)
            get_node_funcs = getattr(module, "get_node_funcs", None)
            if get_node_funcs is not None:
                _, _, stop_func, _ = get_node_funcs(_net_config=self._config, **factory_args)
                return stop_func

        return None

    async def _call_lifecycle_func(self, func: Callable, node_name: str) -> None:
        """Call a node lifecycle function (start or stop), handling sync/async.

        Args:
            func: The lifecycle function to call.
            node_name: The node name (for error messages).
        """
        result = func(self)
        if asyncio.iscoroutine(result):
            await result

    async def _start_node(self, node_name: str) -> None:
        """Call start_node_func for a node if configured and not yet started.

        Args:
            node_name: The node to start.
        """
        if node_name in self._started_nodes:
            return

        func = self._get_node_start_func(node_name)
        if func is not None:
            await self._call_lifecycle_func(func, node_name)

        self._started_nodes.add(node_name)

    async def _stop_node(self, node_name: str) -> None:
        """Call stop_node_func for a node if configured and was started.

        Args:
            node_name: The node to stop.
        """
        if node_name not in self._started_nodes:
            return

        func = self._get_node_stop_func(node_name)
        if func is not None:
            await self._call_lifecycle_func(func, node_name)

        self._started_nodes.discard(node_name)

    async def _start_all_nodes(self) -> None:
        """Call start_node_func for all nodes that don't have defer_startup.

        Called during Net.start() after registering node functions.
        """
        for node_config in self._config_resolved.graph.nodes:
            config = self._get_node_execution_config(node_config.name)
            if config is not None and not config.defer_startup:
                await self._start_node(node_config.name)

    async def _stop_all_nodes(self) -> None:
        """Call stop_node_func for all started nodes.

        Called during Net.stop() before closing the execution manager.
        """
        # Copy since _stop_node modifies the set
        for node_name in list(self._started_nodes):
            await self._stop_node(node_name)

    async def _register_node_functions(self) -> None:
        """Register all node functions with the execution manager pools.

        This sends the exec_node_func for each node to all workers in the
        configured pools, so they can be called by function key.

        If execution_config has an explicit exec_node_func, it takes priority
        (even for factory nodes). Otherwise, factory-based nodes get a
        _FactoryPlaceholder that the NetFuncPreprocessor resolves lazily.

        String import paths are resolved to actual functions before registration.
        """
        for node_config in self._config_resolved.graph.nodes:
            if node_config.execution_config is None:
                continue

            config = node_config.execution_config
            func_key = self._get_func_key(node_config.name)

            # Determine what to register
            if config.exec_node_func is not None:
                # Explicit exec function (overrides factory default)
                exec_func = config.exec_node_func
                # Resolve string import path if needed
                if isinstance(exec_func, str):
                    exec_func = self._import_from_path(exec_func)
            elif node_config.name in self._node_factories:
                # Factory-based node: register placeholder for lazy resolution
                exec_func = _FactoryPlaceholder(node_config.name)
            else:
                # No function to register
                continue

            # Register with each pool the node can use
            for pool_id in config.pools:
                await self._execution_manager.send_function_to_pool(
                    pool_id=pool_id,
                    func_key=func_key,
                    func=exec_func,
                )

    # --- NodeInfo and EdgeInfo API ---

    @property
    def nodes(self) -> dict[str, NodeInfo]:
        """Return a dict of node_name -> NodeInfo for all nodes.

        Provides convenient access to node configuration and runtime state.
        NodeInfo objects are created on each access (not cached).

        Returns:
            Dict mapping node names to NodeInfo objects.

        Example:
            node = net.nodes["my_node"]
            print(f"Input ports: {node.in_port_names}")
            print(f"Running epochs: {len(node.running_epochs)}")
        """
        result = {}
        for node_config in self._config_resolved.graph.nodes:
            result[node_config.name] = NodeInfo(self, node_config.name)
        return result

    @property
    def edges(self) -> list[EdgeInfo]:
        """Return a list of EdgeInfo for all edges.

        Provides convenient access to edge configuration and packets in transit.
        EdgeInfo objects are created on each access (not cached).

        Returns:
            List of EdgeInfo objects for all edges in the graph.

        Example:
            for edge in net.edges:
                print(f"{edge.source_node}.{edge.source_port} -> {edge.target_node}.{edge.target_port}")
                if edge.has_packets:
                    print(f"  {edge.packet_count} packets in transit")
        """
        return [EdgeInfo(self, edge) for edge in self._graph.edges()]

    async def run_to_targets(
        self,
        targets: 'str | list[str | tuple[str, str]]',
        *,
        max_iterations: int = 1000,
    ) -> list[TargetInputSalvo]:
        """Run upstream nodes and collect input salvos at target nodes.

        Executes only the upstream nodes needed to deliver packets to the
        target nodes, then returns the input salvos that would fire at
        those targets without executing them. Useful for testing downstream
        nodes by inspecting exactly what inputs they would receive.

        Args:
            targets: Target node specification. Can be:
                - A single node name: ``"C"``
                - A list of node names: ``["B", "C"]``
                - A list mixing names and (name, salvo_condition) tuples:
                  ``[("B", "cond_1"), "C"]``
            max_iterations: Safety limit for the execution loop (for cyclic graphs).

        Returns:
            List of TargetInputSalvo objects, one per triggered input salvo
            at a target node. Each includes the node name, salvo condition name,
            epoch ID, and packet values by port.

        Raises:
            ValueError: If a target node name is not found in the graph.

        Example:
            async with Net(config) as net:
                net.inject_data("Source", "in", [1, 2, 3])
                salvos = await net.run_to_targets("Sink")
                for salvo in salvos:
                    print(f"{salvo.node_name}.{salvo.salvo_condition}: {salvo.packets}")
        """
        # 1. Normalize targets to set of (node_name, salvo_condition | None)
        if isinstance(targets, str):
            targets = [targets]
        target_specs: set[tuple[str, str | None]] = set()
        for t in targets:
            if isinstance(t, str):
                target_specs.add((t, None))
            else:
                target_specs.add(t)

        # 2. Validate target node names exist
        graph_node_names = set(self._graph.nodes().keys())
        for node_name, _ in target_specs:
            if node_name not in graph_node_names:
                raise ValueError(f"Target node '{node_name}' not found in graph")

        # 3. Compute upstream set
        target_node_names = {spec[0] for spec in target_specs}
        upstream_nodes = _compute_upstream_nodes(list(self._graph.edges()), target_node_names)
        # Include specific-condition target nodes in upstream set
        # so their non-targeted salvo conditions still execute
        blanket_targets = {n for n, c in target_specs if c is None}
        specific_targets = {n for n, c in target_specs if c is not None} - blanket_targets
        upstream_nodes |= specific_targets

        # 4. Execution loop
        collected_salvos: list[TargetInputSalvo] = []
        for _ in range(max_iterations):
            await self.run_until_blocked(auto_start_epochs=False)
            startable = self.get_startable_epochs()
            if not startable:
                break

            upstream_epochs = []
            for epoch_id in startable:
                epoch = self._netsim.get_epoch(epoch_id)
                classification = _classify_epoch(epoch, target_specs, upstream_nodes)
                if classification == "target":
                    # Collect salvo values
                    packets, packet_values = self._get_input_packet_values(epoch_id)
                    port_values: dict[str, list[Any]] = {}
                    for port_name, pkt_ids in packets.items():
                        port_values[port_name] = [packet_values[pid] for pid in pkt_ids]
                    collected_salvos.append(TargetInputSalvo(
                        node_name=epoch.node_name,
                        salvo_condition=epoch.in_salvo.salvo_condition,
                        epoch_id=epoch_id,
                        packets=port_values,
                    ))
                elif classification == "upstream":
                    upstream_epochs.append(epoch_id)

            if not upstream_epochs:
                break

            # Execute upstream epochs (respecting max_parallel_epochs)
            upstream_epochs = self._filter_by_max_parallel_epochs(upstream_epochs)
            if not upstream_epochs:
                break
            tasks = [asyncio.create_task(self._execute_epoch(eid)) for eid in upstream_epochs]
            results = await asyncio.gather(*tasks, return_exceptions=True)
            exceptions = [r for r in results if isinstance(r, Exception)]
            if exceptions:
                if len(exceptions) == 1:
                    raise exceptions[0]
                raise ExceptionGroup("Upstream epoch failures", exceptions)

        return collected_salvos

    # --- Cache Retrieval & Clearing API ---

    def get_cached_entries(self, node_name: str) -> list[CachedEpochData]:
        """Get all cached entries for a node."""
        return self._cache_store.get_entries(node_name)

    def get_cached_input_salvos(self, node_name: str) -> list[dict[str, list[Any]]]:
        """Get input salvos from all cached entries for a node."""
        return [e.input_values_by_port for e in self._cache_store.get_entries(node_name)]

    def get_cached_output_salvos(self, node_name: str) -> list[dict[str, list[Any]]]:
        """Get output salvos from all cached entries for a node."""
        return [e.output_port_values for e in self._cache_store.get_entries(node_name)]

    def get_cached_output_for_input(
        self, node_name: str, input_values: dict[str, list[Any]],
    ) -> CachedEpochData | None:
        """Look up cached output for specific input values.

        Hashes the provided values using the same algorithm and looks up the result.
        """
        if not self._cache_store.is_cache_enabled(node_name):
            return None
        # Build a fake packets dict and packet store for hashing
        from netrun.storage import PacketStore
        temp_store = PacketStore()
        packets: dict[str, list[str]] = {}
        for port_name in sorted(input_values.keys()):
            pkt_ids = []
            for value in input_values[port_name]:
                pid = f"_tmp_{port_name}_{len(pkt_ids)}"
                temp_store.register(pid, value)
                pkt_ids.append(pid)
            packets[port_name] = pkt_ids
        input_hash = self._cache_store.hash_input_salvo(node_name, packets, temp_store)
        return self._cache_store.lookup(node_name, input_hash)

    def cache_stats(self) -> dict[str, dict[str, Any]]:
        """Get per-node cache statistics."""
        return self._cache_store.cache_stats()

    def clear_cache(self) -> None:
        """Clear all cached entries for all nodes."""
        self._cache_store.clear_all()

    def clear_node_cache(self, node_name: str) -> None:
        """Clear all cached entries for a specific node."""
        self._cache_store.clear_node(node_name)

    def clear_cache_by_version(
        self,
        net_version: int | None = None,
        node_name: str | None = None,
        node_version: int | None = None,
    ) -> None:
        """Clear cached entries matching version criteria."""
        self._cache_store.clear_version(net_version, node_name, node_version)

    def clear_cached_output_for_input(
        self, node_name: str, input_values: dict[str, list[Any]],
    ) -> None:
        """Clear the cached output for a specific input salvo."""
        from netrun.storage import PacketStore
        temp_store = PacketStore()
        packets: dict[str, list[str]] = {}
        for port_name in sorted(input_values.keys()):
            pkt_ids = []
            for value in input_values[port_name]:
                pid = f"_tmp_{port_name}_{len(pkt_ids)}"
                temp_store.register(pid, value)
                pkt_ids.append(pid)
            packets[port_name] = pkt_ids
        input_hash = self._cache_store.hash_input_salvo(node_name, packets, temp_store)
        self._cache_store.clear_output_for_input(node_name, input_hash)

    def clear_cached_inputs(self, node_name: str | None = None) -> None:
        """Clear input-only cache entries."""
        self._cache_store.clear_inputs(node_name)

    async def __aenter__(self) -> "Net":
        """Context manager entry - starts the Net."""
        await self.start()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        """Context manager exit - stops the Net."""
        await self.stop()
