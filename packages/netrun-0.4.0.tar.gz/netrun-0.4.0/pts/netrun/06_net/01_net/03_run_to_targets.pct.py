# ---
# jupyter:
#   kernelspec:
#     display_name: .venv
#     language: python
#     name: python3
# ---

# %%
#|default_exp net._net._run_to_targets

# %%
#|hide
from nblite import nbl_export; nbl_export();

# %% [markdown]
# # Run-to-Targets Helpers
#
# Utilities for `Net.run_to_targets()`: upstream graph traversal and epoch classification.

# %%
#|export
from dataclasses import dataclass, field
from typing import Any

# %%
#|export
@dataclass
class TargetInputSalvo:
    """A fireable input salvo captured at a target node."""
    node_name: str
    salvo_condition: str
    epoch_id: str
    packets: dict[str, list[Any]]  # port_name -> [values]

# %%
#|export
def _compute_upstream_nodes(graph_edges: list, target_node_names: set[str]) -> set[str]:
    """Compute all upstream nodes via reverse BFS from target nodes.

    Follows edges backward from target nodes to find all nodes that can
    reach any target. Works on cyclic graphs.

    Args:
        graph_edges: List of netrun_sim Edge objects.
        target_node_names: Set of target node names to compute upstream for.

    Returns:
        Set of upstream node names (excluding target nodes themselves).
    """
    from collections import deque

    # Build reverse adjacency: node -> set of predecessors
    reverse_adj: dict[str, set[str]] = {}
    for edge in graph_edges:
        tgt = edge.target.node_name
        src = edge.source.node_name
        reverse_adj.setdefault(tgt, set()).add(src)

    # BFS from targets, following reverse edges
    upstream = set()
    queue = deque(target_node_names)
    visited = set(target_node_names)
    while queue:
        node = queue.popleft()
        for pred in reverse_adj.get(node, set()):
            if pred not in visited:
                visited.add(pred)
                upstream.add(pred)
                queue.append(pred)
    return upstream

# %%
#|export
def _classify_epoch(epoch, target_specs: set[tuple[str, 'str | None']], upstream_nodes: set[str]) -> str:
    """Classify an epoch as 'target', 'upstream', or 'irrelevant'.

    Checks target match first (priority), then upstream membership.

    Args:
        epoch: A netrun_sim Epoch object.
        target_specs: Set of (node_name, salvo_condition | None) tuples.
        upstream_nodes: Set of upstream node names.

    Returns:
        One of 'target', 'upstream', or 'irrelevant'.
    """
    node_name = epoch.node_name
    salvo_cond = epoch.in_salvo.salvo_condition if epoch.in_salvo else None

    for spec_node, spec_cond in target_specs:
        if spec_node == node_name:
            if spec_cond is None or spec_cond == salvo_cond:
                return "target"

    if node_name in upstream_nodes:
        return "upstream"

    return "irrelevant"
