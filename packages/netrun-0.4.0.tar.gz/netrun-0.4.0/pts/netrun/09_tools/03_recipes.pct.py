# ---
# jupyter:
#   kernelspec:
#     display_name: .venv
#     language: python
#     name: python3
# ---

# %%
#|default_exp tools._recipes

# %%
#|hide
from nblite import nbl_export; nbl_export();

# %%
#|export
import importlib.util
import sys
from pathlib import Path
from types import ModuleType
from typing import Any

from netrun.tools._models import RecipePrompt

# %% [markdown]
# # Recipe Loading and Execution
#
# Load and execute Python recipe scripts that transform configs.

# %%
#|export
def load_recipe_module(path: str | Path) -> ModuleType:
    """Hot-load a Python recipe module from a file path.

    Each invocation creates a fresh module to ensure code changes are picked up.

    Args:
        path: Path to the .py recipe file.

    Returns:
        The loaded module.

    Raises:
        FileNotFoundError: If the file does not exist.
        ValueError: If the file is not a .py file.
        ImportError: If the module fails to load.
    """
    path_obj = Path(path)
    if not path_obj.exists():
        raise FileNotFoundError(f"Recipe not found: {path}")

    if not path_obj.suffix == '.py':
        raise ValueError(f"Recipe must be a .py file: {path}")

    module_name = f"_recipe_{path_obj.stem}_{id(path_obj)}_{hash(str(path))}"

    if module_name in sys.modules:
        del sys.modules[module_name]

    try:
        spec = importlib.util.spec_from_file_location(module_name, path_obj)
        if spec is None or spec.loader is None:
            raise ImportError(f"Failed to load recipe module: {path}")

        module = importlib.util.module_from_spec(spec)
        sys.modules[module_name] = module
        spec.loader.exec_module(module)

        return module
    except (FileNotFoundError, ValueError, ImportError):
        raise
    except Exception as e:
        raise ImportError(f"Error loading recipe: {e}") from e
    finally:
        if module_name in sys.modules:
            del sys.modules[module_name]


def get_recipe_prompts(
    recipe_path: str | Path,
    config: dict[str, Any],
) -> list[RecipePrompt]:
    """Load a recipe and return its prompts.

    If the recipe has a ``get_prompts(config)`` function, calls it.
    Otherwise returns an empty list (recipe runs immediately).

    Args:
        recipe_path: Path to the .py recipe file.
        config: Current config dict to pass to get_prompts.

    Returns:
        List of RecipePrompt objects.
    """
    module = load_recipe_module(recipe_path)

    if hasattr(module, 'get_prompts'):
        prompts = module.get_prompts(config)
        if not isinstance(prompts, list):
            raise TypeError("get_prompts() must return a list")
        return [RecipePrompt.model_validate(p) if isinstance(p, dict) else p for p in prompts]

    return []


def execute_recipe(
    recipe_path: str | Path,
    config: dict[str, Any],
    inputs: dict[str, Any],
) -> dict[str, Any]:
    """Execute a recipe with the given inputs and return the modified config.

    The recipe must have a ``run(config, inputs)`` function.

    Args:
        recipe_path: Path to the .py recipe file.
        config: Current config dict.
        inputs: User-provided inputs from prompts.

    Returns:
        Modified config dict.

    Raises:
        AttributeError: If the recipe has no ``run`` function.
        TypeError: If ``run`` does not return a dict.
    """
    module = load_recipe_module(recipe_path)

    if not hasattr(module, 'run'):
        raise AttributeError("Recipe missing required 'run' function")

    result = module.run(config, inputs)
    if not isinstance(result, dict):
        raise TypeError("run() must return a dict")

    return result
