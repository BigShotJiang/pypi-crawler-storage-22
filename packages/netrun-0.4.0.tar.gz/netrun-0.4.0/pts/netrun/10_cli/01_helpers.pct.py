# ---
# jupyter:
#   kernelspec:
#     display_name: .venv
#     language: python
#     name: python3
# ---

# %%
#|default_exp cli._helpers

# %%
#|hide
from nblite import nbl_export; nbl_export();

# %%
#|export
import json
import sys
import tomllib
from pathlib import Path
from typing import Annotated, Any, Optional

import typer

from netrun.net.config._net_config import NetConfig
from netrun.net.config._nodes import NodeConfig

# %% [markdown]
# # CLI Helpers
#
# Shared utilities for the netrun CLI commands.

# %%
#|export
ConfigOpt = Annotated[Optional[str], typer.Option("--config", "-c", help="Path to netrun config file.")]
PrettyOpt = Annotated[bool, typer.Option("--pretty/--compact", help="Pretty-print or compact JSON output.")]

# %%
#|export
NETRUN_EXTENSIONS = (".netrun.json", ".netrun.toml")


def find_config(path: str | None) -> Path:
    """Find a netrun config file.

    If *path* is given, resolve and return it.
    Otherwise search the current directory for files ending with
    ``*.netrun.json`` or ``*.netrun.toml``.

    Raises:
        typer.Exit: If no config found, multiple found, or path doesn't exist.
    """
    if path is not None:
        p = Path(path).resolve()
        if not p.exists():
            typer.echo(f"Error: config file not found: {p}", err=True)
            raise typer.Exit(1)
        return p

    cwd = Path.cwd()
    matches = [
        f for f in cwd.iterdir()
        if f.is_file() and any(f.name.endswith(ext) for ext in NETRUN_EXTENSIONS)
    ]

    if len(matches) == 0:
        typer.echo("Error: no *netrun.json or *netrun.toml found in current directory.", err=True)
        raise typer.Exit(1)
    if len(matches) > 1:
        names = ", ".join(f.name for f in matches)
        typer.echo(f"Error: multiple config files found: {names}. Use --config to specify one.", err=True)
        raise typer.Exit(1)

    return matches[0].resolve()


def load_config(path: str | None) -> tuple[NetConfig, Path]:
    """Find and load a ``NetConfig`` from a file.

    Returns:
        Tuple of (config, resolved_file_path).
    """
    config_path = find_config(path)
    try:
        config = NetConfig.from_file(config_path)
    except Exception as e:
        typer.echo(f"Error loading config: {e}", err=True)
        raise typer.Exit(1)
    return config, config_path


def load_resolved_config(path: str | None) -> tuple[NetConfig, Path]:
    """Load and resolve a ``NetConfig`` (expanding factories).

    Temporarily adds ``project_root_path`` to ``sys.path`` so that
    dotted import paths relative to the project root (e.g.
    ``"nodes.double"``) can be resolved.

    Falls back to unresolved config if resolution still fails.

    Returns:
        Tuple of (config, resolved_file_path).
    """
    config, config_path = load_config(path)
    project_root = str(config.project_root_path)
    added = False
    if project_root not in sys.path:
        sys.path.insert(0, project_root)
        added = True
    try:
        config = config.resolve()
    except Exception as e:
        typer.echo(
            f"Warning: could not resolve config (factories may not be importable): {e}",
            err=True,
        )
    finally:
        if added:
            sys.path.remove(project_root)
    return config, config_path


def load_raw_data(path: str | None) -> tuple[dict[str, Any], Path]:
    """Find and load a config file as a raw dict.

    Needed for accessing top-level keys (like ``recipes``) that are
    not part of the ``NetConfig`` pydantic model.

    Returns:
        Tuple of (raw_dict, resolved_file_path).
    """
    config_path = find_config(path)
    try:
        content = config_path.read_text()
        suffix = config_path.suffix.lower()
        if suffix == ".json":
            data = json.loads(content)
        elif suffix == ".toml":
            data = tomllib.loads(content)
        else:
            typer.echo(f"Error: unsupported format {suffix}", err=True)
            raise typer.Exit(1)
    except (json.JSONDecodeError, tomllib.TOMLDecodeError) as e:
        typer.echo(f"Error parsing config: {e}", err=True)
        raise typer.Exit(1)
    return data, config_path


def output_json(data: Any, pretty: bool) -> None:
    """Print *data* as JSON to stdout."""
    indent = 2 if pretty else None
    typer.echo(json.dumps(data, indent=indent, default=str))


def get_node_by_name(config: NetConfig, name: str) -> NodeConfig:
    """Look up a node by name, exiting with code 1 if not found."""
    for n in config.graph.nodes:
        if n.name == name:
            if isinstance(n, NodeConfig):
                return n
    typer.echo(f"Error: node '{name}' not found.", err=True)
    raise typer.Exit(1)


def port_type_str(port_type: Any) -> str | None:
    """Convert a ``PortTypeSpec`` to a human-readable string."""
    if port_type is None:
        return None
    if isinstance(port_type, str):
        return port_type
    if isinstance(port_type, type):
        return port_type.__name__
    # PortTypeConfig
    if hasattr(port_type, "name"):
        return port_type.name
    return str(port_type)
